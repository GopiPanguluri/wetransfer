INFO - 2018-07-19 02:19:50 --> Config Class Initialized
INFO - 2018-07-19 02:19:50 --> Hooks Class Initialized
DEBUG - 2018-07-19 02:19:50 --> UTF-8 Support Enabled
INFO - 2018-07-19 02:19:51 --> Utf8 Class Initialized
INFO - 2018-07-19 02:19:51 --> URI Class Initialized
INFO - 2018-07-19 02:19:51 --> Router Class Initialized
INFO - 2018-07-19 02:19:51 --> Output Class Initialized
INFO - 2018-07-19 02:19:51 --> Security Class Initialized
DEBUG - 2018-07-19 02:19:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-19 02:19:51 --> Input Class Initialized
INFO - 2018-07-19 02:19:51 --> Language Class Initialized
INFO - 2018-07-19 02:19:51 --> Language Class Initialized
INFO - 2018-07-19 02:19:51 --> Config Class Initialized
INFO - 2018-07-19 02:19:51 --> Loader Class Initialized
DEBUG - 2018-07-19 02:19:51 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-19 02:19:51 --> Helper loaded: url_helper
INFO - 2018-07-19 02:19:51 --> Helper loaded: form_helper
INFO - 2018-07-19 02:19:51 --> Helper loaded: date_helper
INFO - 2018-07-19 02:19:51 --> Helper loaded: util_helper
INFO - 2018-07-19 02:19:51 --> Helper loaded: text_helper
INFO - 2018-07-19 02:19:51 --> Helper loaded: string_helper
INFO - 2018-07-19 02:19:51 --> Database Driver Class Initialized
DEBUG - 2018-07-19 02:19:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-19 02:19:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-19 02:19:51 --> Email Class Initialized
INFO - 2018-07-19 02:19:51 --> Controller Class Initialized
DEBUG - 2018-07-19 02:19:51 --> Users MX_Controller Initialized
DEBUG - 2018-07-19 02:19:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-19 02:19:51 --> Helper loaded: file_helper
DEBUG - 2018-07-19 02:19:51 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-19 02:19:51 --> Login MX_Controller Initialized
INFO - 2018-07-19 02:19:51 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-19 02:19:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-19 02:19:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
DEBUG - 2018-07-19 02:19:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
INFO - 2018-07-19 02:19:51 --> Upload Class Initialized
INFO - 2018-07-19 02:19:51 --> Passsword for email - gopaltesting@yopmail.com - is :: Testing1278
DEBUG - 2018-07-19 02:19:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/templates/credentials.php
DEBUG - 2018-07-19 02:19:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Mail_model.php
DEBUG - 2018-07-19 02:19:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/mail_view.php
INFO - 2018-07-19 02:19:51 --> Mail logged successfully
INFO - 2018-07-19 02:19:51 --> Config Class Initialized
INFO - 2018-07-19 02:19:51 --> Hooks Class Initialized
DEBUG - 2018-07-19 02:19:51 --> UTF-8 Support Enabled
INFO - 2018-07-19 02:19:51 --> Utf8 Class Initialized
INFO - 2018-07-19 02:19:51 --> URI Class Initialized
INFO - 2018-07-19 02:19:51 --> Router Class Initialized
INFO - 2018-07-19 02:19:51 --> Output Class Initialized
INFO - 2018-07-19 02:19:51 --> Security Class Initialized
DEBUG - 2018-07-19 02:19:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-19 02:19:51 --> Input Class Initialized
INFO - 2018-07-19 02:19:51 --> Language Class Initialized
INFO - 2018-07-19 02:19:51 --> Language Class Initialized
INFO - 2018-07-19 02:19:51 --> Config Class Initialized
INFO - 2018-07-19 02:19:51 --> Loader Class Initialized
DEBUG - 2018-07-19 02:19:51 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-19 02:19:51 --> Helper loaded: url_helper
INFO - 2018-07-19 02:19:51 --> Helper loaded: form_helper
INFO - 2018-07-19 02:19:51 --> Helper loaded: date_helper
INFO - 2018-07-19 02:19:51 --> Helper loaded: util_helper
INFO - 2018-07-19 02:19:51 --> Helper loaded: text_helper
INFO - 2018-07-19 02:19:51 --> Helper loaded: string_helper
INFO - 2018-07-19 02:19:51 --> Database Driver Class Initialized
DEBUG - 2018-07-19 02:19:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-19 02:19:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-19 02:19:51 --> Email Class Initialized
INFO - 2018-07-19 02:19:51 --> Controller Class Initialized
DEBUG - 2018-07-19 02:19:51 --> Users MX_Controller Initialized
DEBUG - 2018-07-19 02:19:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-19 02:19:51 --> Helper loaded: file_helper
DEBUG - 2018-07-19 02:19:51 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-19 02:19:51 --> Login MX_Controller Initialized
INFO - 2018-07-19 02:19:51 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-19 02:19:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-19 02:19:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-19 02:19:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-19 02:19:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-19 02:19:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-19 02:19:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-19 02:19:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/users.php
INFO - 2018-07-19 02:19:51 --> Final output sent to browser
DEBUG - 2018-07-19 02:19:51 --> Total execution time: 0.3005
INFO - 2018-07-19 02:19:52 --> Config Class Initialized
INFO - 2018-07-19 02:19:52 --> Hooks Class Initialized
DEBUG - 2018-07-19 02:19:52 --> UTF-8 Support Enabled
INFO - 2018-07-19 02:19:52 --> Utf8 Class Initialized
INFO - 2018-07-19 02:19:52 --> URI Class Initialized
INFO - 2018-07-19 02:19:52 --> Router Class Initialized
INFO - 2018-07-19 02:19:52 --> Output Class Initialized
INFO - 2018-07-19 02:19:52 --> Security Class Initialized
DEBUG - 2018-07-19 02:19:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-19 02:19:52 --> Input Class Initialized
INFO - 2018-07-19 02:19:52 --> Language Class Initialized
INFO - 2018-07-19 02:19:52 --> Language Class Initialized
INFO - 2018-07-19 02:19:52 --> Config Class Initialized
INFO - 2018-07-19 02:19:52 --> Loader Class Initialized
DEBUG - 2018-07-19 02:19:52 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-19 02:19:52 --> Helper loaded: url_helper
INFO - 2018-07-19 02:19:52 --> Helper loaded: form_helper
INFO - 2018-07-19 02:19:52 --> Helper loaded: date_helper
INFO - 2018-07-19 02:19:52 --> Helper loaded: util_helper
INFO - 2018-07-19 02:19:52 --> Helper loaded: text_helper
INFO - 2018-07-19 02:19:52 --> Helper loaded: string_helper
INFO - 2018-07-19 02:19:52 --> Database Driver Class Initialized
DEBUG - 2018-07-19 02:19:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-19 02:19:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-19 02:19:52 --> Email Class Initialized
INFO - 2018-07-19 02:19:52 --> Controller Class Initialized
DEBUG - 2018-07-19 02:19:52 --> Users MX_Controller Initialized
DEBUG - 2018-07-19 02:19:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-19 02:19:52 --> Helper loaded: file_helper
DEBUG - 2018-07-19 02:19:52 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-19 02:19:52 --> Login MX_Controller Initialized
INFO - 2018-07-19 02:19:52 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-19 02:19:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-19 02:19:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-07-19 02:19:52 --> Final output sent to browser
DEBUG - 2018-07-19 02:19:52 --> Total execution time: 0.4343
INFO - 2018-07-19 02:20:34 --> Config Class Initialized
INFO - 2018-07-19 02:20:34 --> Hooks Class Initialized
DEBUG - 2018-07-19 02:20:34 --> UTF-8 Support Enabled
INFO - 2018-07-19 02:20:34 --> Utf8 Class Initialized
INFO - 2018-07-19 02:20:34 --> URI Class Initialized
INFO - 2018-07-19 02:20:34 --> Router Class Initialized
INFO - 2018-07-19 02:20:34 --> Output Class Initialized
INFO - 2018-07-19 02:20:34 --> Security Class Initialized
DEBUG - 2018-07-19 02:20:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-19 02:20:34 --> Input Class Initialized
INFO - 2018-07-19 02:20:34 --> Language Class Initialized
INFO - 2018-07-19 02:20:35 --> Language Class Initialized
INFO - 2018-07-19 02:20:35 --> Config Class Initialized
INFO - 2018-07-19 02:20:35 --> Loader Class Initialized
DEBUG - 2018-07-19 02:20:35 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-19 02:20:35 --> Helper loaded: url_helper
INFO - 2018-07-19 02:20:35 --> Helper loaded: form_helper
INFO - 2018-07-19 02:20:35 --> Helper loaded: date_helper
INFO - 2018-07-19 02:20:35 --> Helper loaded: util_helper
INFO - 2018-07-19 02:20:35 --> Helper loaded: text_helper
INFO - 2018-07-19 02:20:35 --> Helper loaded: string_helper
INFO - 2018-07-19 02:20:35 --> Database Driver Class Initialized
DEBUG - 2018-07-19 02:20:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-19 02:20:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-19 02:20:35 --> Email Class Initialized
INFO - 2018-07-19 02:20:35 --> Controller Class Initialized
DEBUG - 2018-07-19 02:20:35 --> Admin MX_Controller Initialized
INFO - 2018-07-19 02:20:35 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-19 02:20:35 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-19 02:20:35 --> Login MX_Controller Initialized
DEBUG - 2018-07-19 02:20:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-19 02:20:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-19 02:20:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/logins/login.php
INFO - 2018-07-19 02:20:35 --> Config Class Initialized
INFO - 2018-07-19 02:20:35 --> Hooks Class Initialized
DEBUG - 2018-07-19 02:20:35 --> UTF-8 Support Enabled
INFO - 2018-07-19 02:20:35 --> Utf8 Class Initialized
INFO - 2018-07-19 02:20:35 --> URI Class Initialized
INFO - 2018-07-19 02:20:35 --> Router Class Initialized
INFO - 2018-07-19 02:20:35 --> Output Class Initialized
INFO - 2018-07-19 02:20:35 --> Security Class Initialized
DEBUG - 2018-07-19 02:20:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-19 02:20:35 --> Input Class Initialized
INFO - 2018-07-19 02:20:35 --> Language Class Initialized
ERROR - 2018-07-19 02:20:35 --> 404 Page Not Found: /index
INFO - 2018-07-19 02:20:35 --> Config Class Initialized
INFO - 2018-07-19 02:20:35 --> Hooks Class Initialized
DEBUG - 2018-07-19 02:20:35 --> UTF-8 Support Enabled
INFO - 2018-07-19 02:20:35 --> Utf8 Class Initialized
INFO - 2018-07-19 02:20:35 --> URI Class Initialized
INFO - 2018-07-19 02:20:35 --> Router Class Initialized
INFO - 2018-07-19 02:20:35 --> Output Class Initialized
INFO - 2018-07-19 02:20:35 --> Security Class Initialized
DEBUG - 2018-07-19 02:20:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-19 02:20:35 --> Input Class Initialized
INFO - 2018-07-19 02:20:35 --> Language Class Initialized
ERROR - 2018-07-19 02:20:35 --> 404 Page Not Found: /index
INFO - 2018-07-19 02:20:46 --> Config Class Initialized
INFO - 2018-07-19 02:20:46 --> Hooks Class Initialized
DEBUG - 2018-07-19 02:20:46 --> UTF-8 Support Enabled
INFO - 2018-07-19 02:20:46 --> Utf8 Class Initialized
INFO - 2018-07-19 02:20:46 --> URI Class Initialized
INFO - 2018-07-19 02:20:46 --> Router Class Initialized
INFO - 2018-07-19 02:20:46 --> Output Class Initialized
INFO - 2018-07-19 02:20:46 --> Security Class Initialized
DEBUG - 2018-07-19 02:20:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-19 02:20:46 --> Input Class Initialized
INFO - 2018-07-19 02:20:46 --> Language Class Initialized
INFO - 2018-07-19 02:20:46 --> Language Class Initialized
INFO - 2018-07-19 02:20:46 --> Config Class Initialized
INFO - 2018-07-19 02:20:46 --> Loader Class Initialized
DEBUG - 2018-07-19 02:20:46 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-19 02:20:46 --> Helper loaded: url_helper
INFO - 2018-07-19 02:20:46 --> Helper loaded: form_helper
INFO - 2018-07-19 02:20:46 --> Helper loaded: date_helper
INFO - 2018-07-19 02:20:46 --> Helper loaded: util_helper
INFO - 2018-07-19 02:20:46 --> Helper loaded: text_helper
INFO - 2018-07-19 02:20:46 --> Helper loaded: string_helper
INFO - 2018-07-19 02:20:46 --> Database Driver Class Initialized
DEBUG - 2018-07-19 02:20:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-19 02:20:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-19 02:20:46 --> Email Class Initialized
INFO - 2018-07-19 02:20:46 --> Controller Class Initialized
DEBUG - 2018-07-19 02:20:46 --> Login MX_Controller Initialized
INFO - 2018-07-19 02:20:46 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-19 02:20:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-19 02:20:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-19 02:20:46 --> Email starts for gopaltesting@yopmail.com fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-07-19 02:20:46 --> User session created for 38
INFO - 2018-07-19 02:20:46 --> Login status gopaltesting@yopmail.com - success
INFO - 2018-07-19 02:20:46 --> Final output sent to browser
DEBUG - 2018-07-19 02:20:46 --> Total execution time: 0.2822
INFO - 2018-07-19 02:20:46 --> Config Class Initialized
INFO - 2018-07-19 02:20:46 --> Hooks Class Initialized
DEBUG - 2018-07-19 02:20:46 --> UTF-8 Support Enabled
INFO - 2018-07-19 02:20:46 --> Utf8 Class Initialized
INFO - 2018-07-19 02:20:46 --> URI Class Initialized
INFO - 2018-07-19 02:20:46 --> Router Class Initialized
INFO - 2018-07-19 02:20:46 --> Output Class Initialized
INFO - 2018-07-19 02:20:46 --> Security Class Initialized
DEBUG - 2018-07-19 02:20:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-19 02:20:46 --> Input Class Initialized
INFO - 2018-07-19 02:20:46 --> Language Class Initialized
INFO - 2018-07-19 02:20:46 --> Language Class Initialized
INFO - 2018-07-19 02:20:47 --> Config Class Initialized
INFO - 2018-07-19 02:20:47 --> Loader Class Initialized
DEBUG - 2018-07-19 02:20:47 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-19 02:20:47 --> Helper loaded: url_helper
INFO - 2018-07-19 02:20:47 --> Helper loaded: form_helper
INFO - 2018-07-19 02:20:47 --> Helper loaded: date_helper
INFO - 2018-07-19 02:20:47 --> Helper loaded: util_helper
INFO - 2018-07-19 02:20:47 --> Helper loaded: text_helper
INFO - 2018-07-19 02:20:47 --> Helper loaded: string_helper
INFO - 2018-07-19 02:20:47 --> Database Driver Class Initialized
DEBUG - 2018-07-19 02:20:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-19 02:20:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-19 02:20:47 --> Email Class Initialized
INFO - 2018-07-19 02:20:47 --> Controller Class Initialized
DEBUG - 2018-07-19 02:20:47 --> Admin MX_Controller Initialized
INFO - 2018-07-19 02:20:47 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-19 02:20:47 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-19 02:20:47 --> Login MX_Controller Initialized
DEBUG - 2018-07-19 02:20:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-19 02:20:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-19 02:20:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-19 02:20:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-19 02:20:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-19 02:20:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-19 02:20:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-19 02:20:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/dashboard.php
INFO - 2018-07-19 02:20:47 --> Final output sent to browser
DEBUG - 2018-07-19 02:20:47 --> Total execution time: 0.2580
INFO - 2018-07-19 02:20:47 --> Config Class Initialized
INFO - 2018-07-19 02:20:47 --> Hooks Class Initialized
DEBUG - 2018-07-19 02:20:47 --> UTF-8 Support Enabled
INFO - 2018-07-19 02:20:47 --> Utf8 Class Initialized
INFO - 2018-07-19 02:20:47 --> URI Class Initialized
INFO - 2018-07-19 02:20:47 --> Router Class Initialized
INFO - 2018-07-19 02:20:47 --> Output Class Initialized
INFO - 2018-07-19 02:20:47 --> Security Class Initialized
DEBUG - 2018-07-19 02:20:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-19 02:20:47 --> Input Class Initialized
INFO - 2018-07-19 02:20:47 --> Language Class Initialized
ERROR - 2018-07-19 02:20:47 --> 404 Page Not Found: /index
INFO - 2018-07-19 02:20:48 --> Config Class Initialized
INFO - 2018-07-19 02:20:48 --> Hooks Class Initialized
DEBUG - 2018-07-19 02:20:48 --> UTF-8 Support Enabled
INFO - 2018-07-19 02:20:48 --> Utf8 Class Initialized
INFO - 2018-07-19 02:20:48 --> URI Class Initialized
INFO - 2018-07-19 02:20:48 --> Router Class Initialized
INFO - 2018-07-19 02:20:48 --> Output Class Initialized
INFO - 2018-07-19 02:20:48 --> Security Class Initialized
DEBUG - 2018-07-19 02:20:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-19 02:20:48 --> Input Class Initialized
INFO - 2018-07-19 02:20:48 --> Language Class Initialized
ERROR - 2018-07-19 02:20:48 --> 404 Page Not Found: /index
INFO - 2018-07-19 02:21:16 --> Config Class Initialized
INFO - 2018-07-19 02:21:16 --> Hooks Class Initialized
DEBUG - 2018-07-19 02:21:16 --> UTF-8 Support Enabled
INFO - 2018-07-19 02:21:16 --> Utf8 Class Initialized
INFO - 2018-07-19 02:21:16 --> URI Class Initialized
INFO - 2018-07-19 02:21:16 --> Router Class Initialized
INFO - 2018-07-19 02:21:16 --> Output Class Initialized
INFO - 2018-07-19 02:21:16 --> Security Class Initialized
DEBUG - 2018-07-19 02:21:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-19 02:21:16 --> Input Class Initialized
INFO - 2018-07-19 02:21:16 --> Language Class Initialized
INFO - 2018-07-19 02:21:16 --> Language Class Initialized
INFO - 2018-07-19 02:21:16 --> Config Class Initialized
INFO - 2018-07-19 02:21:16 --> Loader Class Initialized
DEBUG - 2018-07-19 02:21:16 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-19 02:21:16 --> Helper loaded: url_helper
INFO - 2018-07-19 02:21:16 --> Helper loaded: form_helper
INFO - 2018-07-19 02:21:16 --> Helper loaded: date_helper
INFO - 2018-07-19 02:21:16 --> Helper loaded: util_helper
INFO - 2018-07-19 02:21:16 --> Helper loaded: text_helper
INFO - 2018-07-19 02:21:16 --> Helper loaded: string_helper
INFO - 2018-07-19 02:21:16 --> Database Driver Class Initialized
DEBUG - 2018-07-19 02:21:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-19 02:21:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-19 02:21:16 --> Email Class Initialized
INFO - 2018-07-19 02:21:16 --> Controller Class Initialized
DEBUG - 2018-07-19 02:21:16 --> Login MX_Controller Initialized
INFO - 2018-07-19 02:21:16 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-19 02:21:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-19 02:21:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-19 02:21:16 --> 38 Loggedout
INFO - 2018-07-19 02:21:16 --> Config Class Initialized
INFO - 2018-07-19 02:21:16 --> Hooks Class Initialized
DEBUG - 2018-07-19 02:21:16 --> UTF-8 Support Enabled
INFO - 2018-07-19 02:21:16 --> Utf8 Class Initialized
INFO - 2018-07-19 02:21:16 --> URI Class Initialized
INFO - 2018-07-19 02:21:16 --> Router Class Initialized
INFO - 2018-07-19 02:21:16 --> Output Class Initialized
INFO - 2018-07-19 02:21:16 --> Security Class Initialized
DEBUG - 2018-07-19 02:21:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-19 02:21:16 --> Input Class Initialized
INFO - 2018-07-19 02:21:16 --> Language Class Initialized
INFO - 2018-07-19 02:21:16 --> Language Class Initialized
INFO - 2018-07-19 02:21:16 --> Config Class Initialized
INFO - 2018-07-19 02:21:16 --> Loader Class Initialized
DEBUG - 2018-07-19 02:21:16 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-19 02:21:16 --> Helper loaded: url_helper
INFO - 2018-07-19 02:21:16 --> Helper loaded: form_helper
INFO - 2018-07-19 02:21:16 --> Helper loaded: date_helper
INFO - 2018-07-19 02:21:16 --> Helper loaded: util_helper
INFO - 2018-07-19 02:21:16 --> Helper loaded: text_helper
INFO - 2018-07-19 02:21:16 --> Helper loaded: string_helper
INFO - 2018-07-19 02:21:16 --> Database Driver Class Initialized
DEBUG - 2018-07-19 02:21:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-19 02:21:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-19 02:21:16 --> Email Class Initialized
INFO - 2018-07-19 02:21:17 --> Controller Class Initialized
DEBUG - 2018-07-19 02:21:17 --> Admin MX_Controller Initialized
INFO - 2018-07-19 02:21:17 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-19 02:21:17 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-19 02:21:17 --> Login MX_Controller Initialized
DEBUG - 2018-07-19 02:21:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-19 02:21:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-19 02:21:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/logins/login.php
INFO - 2018-07-19 02:21:17 --> Config Class Initialized
INFO - 2018-07-19 02:21:17 --> Hooks Class Initialized
DEBUG - 2018-07-19 02:21:17 --> UTF-8 Support Enabled
INFO - 2018-07-19 02:21:17 --> Utf8 Class Initialized
INFO - 2018-07-19 02:21:17 --> URI Class Initialized
INFO - 2018-07-19 02:21:17 --> Router Class Initialized
INFO - 2018-07-19 02:21:17 --> Output Class Initialized
INFO - 2018-07-19 02:21:17 --> Security Class Initialized
DEBUG - 2018-07-19 02:21:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-19 02:21:17 --> Input Class Initialized
INFO - 2018-07-19 02:21:17 --> Language Class Initialized
ERROR - 2018-07-19 02:21:17 --> 404 Page Not Found: /index
INFO - 2018-07-19 02:21:17 --> Config Class Initialized
INFO - 2018-07-19 02:21:17 --> Hooks Class Initialized
DEBUG - 2018-07-19 02:21:17 --> UTF-8 Support Enabled
INFO - 2018-07-19 02:21:17 --> Utf8 Class Initialized
INFO - 2018-07-19 02:21:17 --> URI Class Initialized
INFO - 2018-07-19 02:21:17 --> Router Class Initialized
INFO - 2018-07-19 02:21:17 --> Output Class Initialized
INFO - 2018-07-19 02:21:17 --> Security Class Initialized
DEBUG - 2018-07-19 02:21:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-19 02:21:17 --> Input Class Initialized
INFO - 2018-07-19 02:21:17 --> Language Class Initialized
ERROR - 2018-07-19 02:21:17 --> 404 Page Not Found: /index
INFO - 2018-07-19 02:21:58 --> Config Class Initialized
INFO - 2018-07-19 02:21:58 --> Hooks Class Initialized
DEBUG - 2018-07-19 02:21:58 --> UTF-8 Support Enabled
INFO - 2018-07-19 02:21:58 --> Utf8 Class Initialized
INFO - 2018-07-19 02:21:58 --> URI Class Initialized
INFO - 2018-07-19 02:21:58 --> Router Class Initialized
INFO - 2018-07-19 02:21:58 --> Output Class Initialized
INFO - 2018-07-19 02:21:58 --> Security Class Initialized
DEBUG - 2018-07-19 02:21:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-19 02:21:58 --> Input Class Initialized
INFO - 2018-07-19 02:21:58 --> Language Class Initialized
INFO - 2018-07-19 02:21:58 --> Language Class Initialized
INFO - 2018-07-19 02:21:58 --> Config Class Initialized
INFO - 2018-07-19 02:21:58 --> Loader Class Initialized
DEBUG - 2018-07-19 02:21:58 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-19 02:21:58 --> Helper loaded: url_helper
INFO - 2018-07-19 02:21:58 --> Helper loaded: form_helper
INFO - 2018-07-19 02:21:58 --> Helper loaded: date_helper
INFO - 2018-07-19 02:21:58 --> Helper loaded: util_helper
INFO - 2018-07-19 02:21:58 --> Helper loaded: text_helper
INFO - 2018-07-19 02:21:58 --> Helper loaded: string_helper
INFO - 2018-07-19 02:21:58 --> Database Driver Class Initialized
DEBUG - 2018-07-19 02:21:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-19 02:21:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-19 02:21:58 --> Email Class Initialized
INFO - 2018-07-19 02:21:58 --> Controller Class Initialized
DEBUG - 2018-07-19 02:21:58 --> Users MX_Controller Initialized
DEBUG - 2018-07-19 02:21:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-19 02:21:58 --> Helper loaded: file_helper
DEBUG - 2018-07-19 02:21:58 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-19 02:21:58 --> Login MX_Controller Initialized
INFO - 2018-07-19 02:21:58 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-19 02:21:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-19 02:21:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-19 02:21:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-19 02:21:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-19 02:21:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-19 02:21:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-19 02:21:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/users.php
INFO - 2018-07-19 02:21:58 --> Final output sent to browser
DEBUG - 2018-07-19 02:21:58 --> Total execution time: 0.2484
INFO - 2018-07-19 02:21:59 --> Config Class Initialized
INFO - 2018-07-19 02:21:59 --> Hooks Class Initialized
DEBUG - 2018-07-19 02:21:59 --> UTF-8 Support Enabled
INFO - 2018-07-19 02:21:59 --> Utf8 Class Initialized
INFO - 2018-07-19 02:21:59 --> URI Class Initialized
INFO - 2018-07-19 02:21:59 --> Router Class Initialized
INFO - 2018-07-19 02:21:59 --> Output Class Initialized
INFO - 2018-07-19 02:21:59 --> Security Class Initialized
DEBUG - 2018-07-19 02:21:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-19 02:21:59 --> Input Class Initialized
INFO - 2018-07-19 02:21:59 --> Language Class Initialized
INFO - 2018-07-19 02:21:59 --> Language Class Initialized
INFO - 2018-07-19 02:21:59 --> Config Class Initialized
INFO - 2018-07-19 02:21:59 --> Loader Class Initialized
DEBUG - 2018-07-19 02:21:59 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-19 02:21:59 --> Helper loaded: url_helper
INFO - 2018-07-19 02:21:59 --> Helper loaded: form_helper
INFO - 2018-07-19 02:21:59 --> Helper loaded: date_helper
INFO - 2018-07-19 02:21:59 --> Helper loaded: util_helper
INFO - 2018-07-19 02:21:59 --> Helper loaded: text_helper
INFO - 2018-07-19 02:21:59 --> Helper loaded: string_helper
INFO - 2018-07-19 02:21:59 --> Database Driver Class Initialized
DEBUG - 2018-07-19 02:21:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-19 02:21:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-19 02:21:59 --> Email Class Initialized
INFO - 2018-07-19 02:21:59 --> Controller Class Initialized
DEBUG - 2018-07-19 02:21:59 --> Users MX_Controller Initialized
DEBUG - 2018-07-19 02:21:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-19 02:21:59 --> Helper loaded: file_helper
DEBUG - 2018-07-19 02:21:59 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-19 02:21:59 --> Login MX_Controller Initialized
INFO - 2018-07-19 02:21:59 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-19 02:21:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-19 02:21:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-07-19 02:21:59 --> Final output sent to browser
DEBUG - 2018-07-19 02:21:59 --> Total execution time: 0.3072
INFO - 2018-07-19 04:49:46 --> Config Class Initialized
INFO - 2018-07-19 04:49:46 --> Hooks Class Initialized
DEBUG - 2018-07-19 04:49:46 --> UTF-8 Support Enabled
INFO - 2018-07-19 04:49:46 --> Utf8 Class Initialized
INFO - 2018-07-19 04:49:46 --> URI Class Initialized
INFO - 2018-07-19 04:49:46 --> Router Class Initialized
INFO - 2018-07-19 04:49:46 --> Output Class Initialized
INFO - 2018-07-19 04:49:46 --> Security Class Initialized
DEBUG - 2018-07-19 04:49:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-19 04:49:46 --> Input Class Initialized
INFO - 2018-07-19 04:49:46 --> Language Class Initialized
INFO - 2018-07-19 04:49:46 --> Language Class Initialized
INFO - 2018-07-19 04:49:46 --> Config Class Initialized
INFO - 2018-07-19 04:49:46 --> Loader Class Initialized
DEBUG - 2018-07-19 04:49:46 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-19 04:49:46 --> Helper loaded: url_helper
INFO - 2018-07-19 04:49:46 --> Helper loaded: form_helper
INFO - 2018-07-19 04:49:46 --> Helper loaded: date_helper
INFO - 2018-07-19 04:49:46 --> Helper loaded: util_helper
INFO - 2018-07-19 04:49:46 --> Helper loaded: text_helper
INFO - 2018-07-19 04:49:46 --> Helper loaded: string_helper
INFO - 2018-07-19 04:49:46 --> Database Driver Class Initialized
DEBUG - 2018-07-19 04:49:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-19 04:49:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-19 04:49:46 --> Email Class Initialized
INFO - 2018-07-19 04:49:46 --> Controller Class Initialized
DEBUG - 2018-07-19 04:49:46 --> Home MX_Controller Initialized
DEBUG - 2018-07-19 04:49:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-19 04:49:46 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-19 04:49:46 --> Login MX_Controller Initialized
INFO - 2018-07-19 04:49:46 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-19 04:49:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-19 04:49:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-19 04:49:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/login.php
INFO - 2018-07-19 04:50:06 --> Config Class Initialized
INFO - 2018-07-19 04:50:06 --> Hooks Class Initialized
DEBUG - 2018-07-19 04:50:06 --> UTF-8 Support Enabled
INFO - 2018-07-19 04:50:06 --> Utf8 Class Initialized
INFO - 2018-07-19 04:50:06 --> URI Class Initialized
INFO - 2018-07-19 04:50:06 --> Router Class Initialized
INFO - 2018-07-19 04:50:06 --> Output Class Initialized
INFO - 2018-07-19 04:50:06 --> Security Class Initialized
DEBUG - 2018-07-19 04:50:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-19 04:50:06 --> Input Class Initialized
INFO - 2018-07-19 04:50:06 --> Language Class Initialized
INFO - 2018-07-19 04:50:06 --> Language Class Initialized
INFO - 2018-07-19 04:50:06 --> Config Class Initialized
INFO - 2018-07-19 04:50:06 --> Loader Class Initialized
DEBUG - 2018-07-19 04:50:06 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-19 04:50:06 --> Helper loaded: url_helper
INFO - 2018-07-19 04:50:06 --> Helper loaded: form_helper
INFO - 2018-07-19 04:50:06 --> Helper loaded: date_helper
INFO - 2018-07-19 04:50:06 --> Helper loaded: util_helper
INFO - 2018-07-19 04:50:06 --> Helper loaded: text_helper
INFO - 2018-07-19 04:50:06 --> Helper loaded: string_helper
INFO - 2018-07-19 04:50:06 --> Database Driver Class Initialized
DEBUG - 2018-07-19 04:50:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-19 04:50:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-19 04:50:06 --> Email Class Initialized
INFO - 2018-07-19 04:50:06 --> Controller Class Initialized
DEBUG - 2018-07-19 04:50:06 --> Login MX_Controller Initialized
INFO - 2018-07-19 04:50:06 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-19 04:50:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-19 04:50:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-19 04:50:07 --> Email starts for user@colin.com fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-07-19 04:50:07 --> User session created for 4
INFO - 2018-07-19 04:50:07 --> Login status user@colin.com - success
INFO - 2018-07-19 04:50:07 --> Final output sent to browser
DEBUG - 2018-07-19 04:50:07 --> Total execution time: 0.2507
INFO - 2018-07-19 04:50:07 --> Config Class Initialized
INFO - 2018-07-19 04:50:07 --> Hooks Class Initialized
DEBUG - 2018-07-19 04:50:07 --> UTF-8 Support Enabled
INFO - 2018-07-19 04:50:07 --> Utf8 Class Initialized
INFO - 2018-07-19 04:50:07 --> URI Class Initialized
INFO - 2018-07-19 04:50:07 --> Router Class Initialized
INFO - 2018-07-19 04:50:07 --> Output Class Initialized
INFO - 2018-07-19 04:50:07 --> Security Class Initialized
DEBUG - 2018-07-19 04:50:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-19 04:50:07 --> Input Class Initialized
INFO - 2018-07-19 04:50:07 --> Language Class Initialized
INFO - 2018-07-19 04:50:07 --> Language Class Initialized
INFO - 2018-07-19 04:50:07 --> Config Class Initialized
INFO - 2018-07-19 04:50:07 --> Loader Class Initialized
DEBUG - 2018-07-19 04:50:07 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-19 04:50:07 --> Helper loaded: url_helper
INFO - 2018-07-19 04:50:07 --> Helper loaded: form_helper
INFO - 2018-07-19 04:50:07 --> Helper loaded: date_helper
INFO - 2018-07-19 04:50:07 --> Helper loaded: util_helper
INFO - 2018-07-19 04:50:07 --> Helper loaded: text_helper
INFO - 2018-07-19 04:50:07 --> Helper loaded: string_helper
INFO - 2018-07-19 04:50:07 --> Database Driver Class Initialized
DEBUG - 2018-07-19 04:50:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-19 04:50:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-19 04:50:07 --> Email Class Initialized
INFO - 2018-07-19 04:50:07 --> Controller Class Initialized
DEBUG - 2018-07-19 04:50:07 --> Home MX_Controller Initialized
DEBUG - 2018-07-19 04:50:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-19 04:50:07 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-19 04:50:07 --> Login MX_Controller Initialized
INFO - 2018-07-19 04:50:07 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-19 04:50:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-19 04:50:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-19 04:50:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-07-19 04:50:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-07-19 04:50:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-07-19 04:50:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-07-19 04:50:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-07-19 04:50:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-07-19 04:50:07 --> Final output sent to browser
DEBUG - 2018-07-19 04:50:07 --> Total execution time: 0.4498
INFO - 2018-07-19 04:50:08 --> Config Class Initialized
INFO - 2018-07-19 04:50:08 --> Hooks Class Initialized
INFO - 2018-07-19 04:50:08 --> Config Class Initialized
INFO - 2018-07-19 04:50:08 --> Hooks Class Initialized
DEBUG - 2018-07-19 04:50:08 --> UTF-8 Support Enabled
INFO - 2018-07-19 04:50:08 --> Utf8 Class Initialized
DEBUG - 2018-07-19 04:50:08 --> UTF-8 Support Enabled
INFO - 2018-07-19 04:50:08 --> Utf8 Class Initialized
INFO - 2018-07-19 04:50:08 --> URI Class Initialized
INFO - 2018-07-19 04:50:08 --> URI Class Initialized
INFO - 2018-07-19 04:50:08 --> Router Class Initialized
INFO - 2018-07-19 04:50:08 --> Router Class Initialized
INFO - 2018-07-19 04:50:08 --> Output Class Initialized
INFO - 2018-07-19 04:50:08 --> Security Class Initialized
DEBUG - 2018-07-19 04:50:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-19 04:50:08 --> Input Class Initialized
INFO - 2018-07-19 04:50:08 --> Language Class Initialized
ERROR - 2018-07-19 04:50:08 --> 404 Page Not Found: /index
INFO - 2018-07-19 04:50:08 --> Output Class Initialized
INFO - 2018-07-19 04:50:08 --> Security Class Initialized
DEBUG - 2018-07-19 04:50:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-19 04:50:08 --> Input Class Initialized
INFO - 2018-07-19 04:50:08 --> Language Class Initialized
ERROR - 2018-07-19 04:50:08 --> 404 Page Not Found: /index
INFO - 2018-07-19 04:50:08 --> Config Class Initialized
INFO - 2018-07-19 04:50:08 --> Hooks Class Initialized
DEBUG - 2018-07-19 04:50:08 --> UTF-8 Support Enabled
INFO - 2018-07-19 04:50:08 --> Utf8 Class Initialized
INFO - 2018-07-19 04:50:08 --> URI Class Initialized
INFO - 2018-07-19 04:50:08 --> Router Class Initialized
INFO - 2018-07-19 04:50:08 --> Output Class Initialized
INFO - 2018-07-19 04:50:08 --> Security Class Initialized
DEBUG - 2018-07-19 04:50:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-19 04:50:08 --> Input Class Initialized
INFO - 2018-07-19 04:50:08 --> Language Class Initialized
ERROR - 2018-07-19 04:50:08 --> 404 Page Not Found: /index
INFO - 2018-07-19 04:50:08 --> Config Class Initialized
INFO - 2018-07-19 04:50:08 --> Hooks Class Initialized
DEBUG - 2018-07-19 04:50:08 --> UTF-8 Support Enabled
INFO - 2018-07-19 04:50:08 --> Utf8 Class Initialized
INFO - 2018-07-19 04:50:08 --> URI Class Initialized
INFO - 2018-07-19 04:50:08 --> Router Class Initialized
INFO - 2018-07-19 04:50:08 --> Output Class Initialized
INFO - 2018-07-19 04:50:08 --> Security Class Initialized
DEBUG - 2018-07-19 04:50:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-19 04:50:08 --> Input Class Initialized
INFO - 2018-07-19 04:50:08 --> Language Class Initialized
ERROR - 2018-07-19 04:50:08 --> 404 Page Not Found: /index
INFO - 2018-07-19 04:50:09 --> Config Class Initialized
INFO - 2018-07-19 04:50:09 --> Hooks Class Initialized
DEBUG - 2018-07-19 04:50:09 --> UTF-8 Support Enabled
INFO - 2018-07-19 04:50:09 --> Utf8 Class Initialized
INFO - 2018-07-19 04:50:09 --> URI Class Initialized
INFO - 2018-07-19 04:50:09 --> Router Class Initialized
INFO - 2018-07-19 04:50:09 --> Output Class Initialized
INFO - 2018-07-19 04:50:09 --> Security Class Initialized
DEBUG - 2018-07-19 04:50:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-19 04:50:09 --> Input Class Initialized
INFO - 2018-07-19 04:50:09 --> Language Class Initialized
ERROR - 2018-07-19 04:50:09 --> 404 Page Not Found: /index
INFO - 2018-07-19 04:50:09 --> Config Class Initialized
INFO - 2018-07-19 04:50:09 --> Hooks Class Initialized
DEBUG - 2018-07-19 04:50:09 --> UTF-8 Support Enabled
INFO - 2018-07-19 04:50:09 --> Utf8 Class Initialized
INFO - 2018-07-19 04:50:09 --> URI Class Initialized
INFO - 2018-07-19 04:50:09 --> Router Class Initialized
INFO - 2018-07-19 04:50:09 --> Output Class Initialized
INFO - 2018-07-19 04:50:09 --> Security Class Initialized
DEBUG - 2018-07-19 04:50:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-19 04:50:09 --> Input Class Initialized
INFO - 2018-07-19 04:50:09 --> Language Class Initialized
ERROR - 2018-07-19 04:50:09 --> 404 Page Not Found: /index
INFO - 2018-07-19 04:50:09 --> Config Class Initialized
INFO - 2018-07-19 04:50:09 --> Hooks Class Initialized
DEBUG - 2018-07-19 04:50:09 --> UTF-8 Support Enabled
INFO - 2018-07-19 04:50:09 --> Utf8 Class Initialized
INFO - 2018-07-19 04:50:09 --> URI Class Initialized
INFO - 2018-07-19 04:50:09 --> Router Class Initialized
INFO - 2018-07-19 04:50:09 --> Output Class Initialized
INFO - 2018-07-19 04:50:09 --> Security Class Initialized
DEBUG - 2018-07-19 04:50:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-19 04:50:09 --> Input Class Initialized
INFO - 2018-07-19 04:50:09 --> Language Class Initialized
ERROR - 2018-07-19 04:50:09 --> 404 Page Not Found: /index
INFO - 2018-07-19 21:56:28 --> Config Class Initialized
INFO - 2018-07-19 21:56:28 --> Hooks Class Initialized
DEBUG - 2018-07-19 21:56:29 --> UTF-8 Support Enabled
INFO - 2018-07-19 21:56:29 --> Utf8 Class Initialized
INFO - 2018-07-19 21:56:29 --> URI Class Initialized
INFO - 2018-07-19 21:56:29 --> Router Class Initialized
INFO - 2018-07-19 21:56:29 --> Output Class Initialized
INFO - 2018-07-19 21:56:29 --> Security Class Initialized
DEBUG - 2018-07-19 21:56:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-19 21:56:29 --> Input Class Initialized
INFO - 2018-07-19 21:56:29 --> Language Class Initialized
INFO - 2018-07-19 21:56:29 --> Language Class Initialized
INFO - 2018-07-19 21:56:29 --> Config Class Initialized
INFO - 2018-07-19 21:56:30 --> Loader Class Initialized
DEBUG - 2018-07-19 21:56:30 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-19 21:56:30 --> Helper loaded: url_helper
INFO - 2018-07-19 21:56:30 --> Helper loaded: form_helper
INFO - 2018-07-19 21:56:30 --> Helper loaded: date_helper
INFO - 2018-07-19 21:56:30 --> Helper loaded: util_helper
INFO - 2018-07-19 21:56:30 --> Helper loaded: text_helper
INFO - 2018-07-19 21:56:30 --> Helper loaded: string_helper
INFO - 2018-07-19 21:56:31 --> Database Driver Class Initialized
DEBUG - 2018-07-19 21:56:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-19 21:56:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-19 21:56:31 --> Email Class Initialized
INFO - 2018-07-19 21:56:31 --> Controller Class Initialized
DEBUG - 2018-07-19 21:56:31 --> Home MX_Controller Initialized
DEBUG - 2018-07-19 21:56:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-19 21:56:31 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-19 21:56:31 --> Login MX_Controller Initialized
INFO - 2018-07-19 21:56:31 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-19 21:56:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-19 21:56:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-19 21:56:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/login.php
INFO - 2018-07-19 21:58:34 --> Config Class Initialized
INFO - 2018-07-19 21:58:34 --> Hooks Class Initialized
DEBUG - 2018-07-19 21:58:34 --> UTF-8 Support Enabled
INFO - 2018-07-19 21:58:34 --> Utf8 Class Initialized
INFO - 2018-07-19 21:58:34 --> URI Class Initialized
INFO - 2018-07-19 21:58:34 --> Router Class Initialized
INFO - 2018-07-19 21:58:34 --> Output Class Initialized
INFO - 2018-07-19 21:58:34 --> Security Class Initialized
DEBUG - 2018-07-19 21:58:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-19 21:58:34 --> Input Class Initialized
INFO - 2018-07-19 21:58:34 --> Language Class Initialized
INFO - 2018-07-19 21:58:34 --> Language Class Initialized
INFO - 2018-07-19 21:58:34 --> Config Class Initialized
INFO - 2018-07-19 21:58:34 --> Loader Class Initialized
DEBUG - 2018-07-19 21:58:34 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-19 21:58:34 --> Helper loaded: url_helper
INFO - 2018-07-19 21:58:34 --> Helper loaded: form_helper
INFO - 2018-07-19 21:58:34 --> Helper loaded: date_helper
INFO - 2018-07-19 21:58:34 --> Helper loaded: util_helper
INFO - 2018-07-19 21:58:34 --> Helper loaded: text_helper
INFO - 2018-07-19 21:58:34 --> Helper loaded: string_helper
INFO - 2018-07-19 21:58:34 --> Database Driver Class Initialized
DEBUG - 2018-07-19 21:58:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-19 21:58:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-19 21:58:34 --> Email Class Initialized
INFO - 2018-07-19 21:58:34 --> Controller Class Initialized
DEBUG - 2018-07-19 21:58:34 --> Login MX_Controller Initialized
INFO - 2018-07-19 21:58:34 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-19 21:58:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-19 21:58:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-19 21:58:34 --> Email starts for user@colin.com fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-07-19 21:58:34 --> User session created for 4
INFO - 2018-07-19 21:58:34 --> Login status user@colin.com - success
INFO - 2018-07-19 21:58:34 --> Final output sent to browser
DEBUG - 2018-07-19 21:58:34 --> Total execution time: 0.3604
INFO - 2018-07-19 21:58:34 --> Config Class Initialized
INFO - 2018-07-19 21:58:34 --> Hooks Class Initialized
DEBUG - 2018-07-19 21:58:34 --> UTF-8 Support Enabled
INFO - 2018-07-19 21:58:34 --> Utf8 Class Initialized
INFO - 2018-07-19 21:58:34 --> URI Class Initialized
INFO - 2018-07-19 21:58:34 --> Router Class Initialized
INFO - 2018-07-19 21:58:34 --> Output Class Initialized
INFO - 2018-07-19 21:58:34 --> Security Class Initialized
DEBUG - 2018-07-19 21:58:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-19 21:58:34 --> Input Class Initialized
INFO - 2018-07-19 21:58:34 --> Language Class Initialized
INFO - 2018-07-19 21:58:34 --> Language Class Initialized
INFO - 2018-07-19 21:58:34 --> Config Class Initialized
INFO - 2018-07-19 21:58:34 --> Loader Class Initialized
DEBUG - 2018-07-19 21:58:34 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-19 21:58:34 --> Helper loaded: url_helper
INFO - 2018-07-19 21:58:34 --> Helper loaded: form_helper
INFO - 2018-07-19 21:58:34 --> Helper loaded: date_helper
INFO - 2018-07-19 21:58:34 --> Helper loaded: util_helper
INFO - 2018-07-19 21:58:34 --> Helper loaded: text_helper
INFO - 2018-07-19 21:58:34 --> Helper loaded: string_helper
INFO - 2018-07-19 21:58:34 --> Database Driver Class Initialized
DEBUG - 2018-07-19 21:58:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-19 21:58:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-19 21:58:34 --> Email Class Initialized
INFO - 2018-07-19 21:58:34 --> Controller Class Initialized
DEBUG - 2018-07-19 21:58:34 --> Home MX_Controller Initialized
DEBUG - 2018-07-19 21:58:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-19 21:58:34 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-19 21:58:34 --> Login MX_Controller Initialized
INFO - 2018-07-19 21:58:34 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-19 21:58:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-19 21:58:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-19 21:58:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-07-19 21:58:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-07-19 21:58:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-07-19 21:58:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-07-19 21:58:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-07-19 21:58:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-07-19 21:58:35 --> Final output sent to browser
DEBUG - 2018-07-19 21:58:35 --> Total execution time: 0.7838
INFO - 2018-07-19 21:58:36 --> Config Class Initialized
INFO - 2018-07-19 21:58:36 --> Config Class Initialized
INFO - 2018-07-19 21:58:36 --> Hooks Class Initialized
INFO - 2018-07-19 21:58:36 --> Hooks Class Initialized
DEBUG - 2018-07-19 21:58:36 --> UTF-8 Support Enabled
INFO - 2018-07-19 21:58:36 --> Utf8 Class Initialized
DEBUG - 2018-07-19 21:58:36 --> UTF-8 Support Enabled
INFO - 2018-07-19 21:58:36 --> Utf8 Class Initialized
INFO - 2018-07-19 21:58:36 --> URI Class Initialized
INFO - 2018-07-19 21:58:36 --> URI Class Initialized
INFO - 2018-07-19 21:58:36 --> Router Class Initialized
INFO - 2018-07-19 21:58:36 --> Router Class Initialized
INFO - 2018-07-19 21:58:36 --> Output Class Initialized
INFO - 2018-07-19 21:58:36 --> Output Class Initialized
INFO - 2018-07-19 21:58:36 --> Security Class Initialized
INFO - 2018-07-19 21:58:36 --> Security Class Initialized
DEBUG - 2018-07-19 21:58:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-07-19 21:58:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-19 21:58:36 --> Input Class Initialized
INFO - 2018-07-19 21:58:36 --> Input Class Initialized
INFO - 2018-07-19 21:58:36 --> Language Class Initialized
INFO - 2018-07-19 21:58:36 --> Language Class Initialized
ERROR - 2018-07-19 21:58:36 --> 404 Page Not Found: /index
ERROR - 2018-07-19 21:58:36 --> 404 Page Not Found: /index
INFO - 2018-07-19 21:58:37 --> Config Class Initialized
INFO - 2018-07-19 21:58:37 --> Hooks Class Initialized
DEBUG - 2018-07-19 21:58:37 --> UTF-8 Support Enabled
INFO - 2018-07-19 21:58:37 --> Utf8 Class Initialized
INFO - 2018-07-19 21:58:37 --> URI Class Initialized
INFO - 2018-07-19 21:58:37 --> Router Class Initialized
INFO - 2018-07-19 21:58:37 --> Output Class Initialized
INFO - 2018-07-19 21:58:37 --> Security Class Initialized
DEBUG - 2018-07-19 21:58:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-19 21:58:37 --> Input Class Initialized
INFO - 2018-07-19 21:58:37 --> Language Class Initialized
ERROR - 2018-07-19 21:58:37 --> 404 Page Not Found: /index
INFO - 2018-07-19 21:58:37 --> Config Class Initialized
INFO - 2018-07-19 21:58:37 --> Hooks Class Initialized
DEBUG - 2018-07-19 21:58:37 --> UTF-8 Support Enabled
INFO - 2018-07-19 21:58:37 --> Utf8 Class Initialized
INFO - 2018-07-19 21:58:37 --> URI Class Initialized
INFO - 2018-07-19 21:58:37 --> Router Class Initialized
INFO - 2018-07-19 21:58:37 --> Output Class Initialized
INFO - 2018-07-19 21:58:37 --> Security Class Initialized
DEBUG - 2018-07-19 21:58:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-19 21:58:37 --> Input Class Initialized
INFO - 2018-07-19 21:58:37 --> Language Class Initialized
ERROR - 2018-07-19 21:58:37 --> 404 Page Not Found: /index
INFO - 2018-07-19 21:58:38 --> Config Class Initialized
INFO - 2018-07-19 21:58:38 --> Hooks Class Initialized
DEBUG - 2018-07-19 21:58:38 --> UTF-8 Support Enabled
INFO - 2018-07-19 21:58:38 --> Utf8 Class Initialized
INFO - 2018-07-19 21:58:38 --> URI Class Initialized
INFO - 2018-07-19 21:58:38 --> Router Class Initialized
INFO - 2018-07-19 21:58:38 --> Output Class Initialized
INFO - 2018-07-19 21:58:38 --> Security Class Initialized
DEBUG - 2018-07-19 21:58:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-19 21:58:38 --> Input Class Initialized
INFO - 2018-07-19 21:58:38 --> Language Class Initialized
ERROR - 2018-07-19 21:58:38 --> 404 Page Not Found: /index
INFO - 2018-07-19 21:58:38 --> Config Class Initialized
INFO - 2018-07-19 21:58:38 --> Hooks Class Initialized
DEBUG - 2018-07-19 21:58:38 --> UTF-8 Support Enabled
INFO - 2018-07-19 21:58:38 --> Utf8 Class Initialized
INFO - 2018-07-19 21:58:38 --> URI Class Initialized
INFO - 2018-07-19 21:58:38 --> Router Class Initialized
INFO - 2018-07-19 21:58:38 --> Output Class Initialized
INFO - 2018-07-19 21:58:38 --> Security Class Initialized
DEBUG - 2018-07-19 21:58:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-19 21:58:38 --> Input Class Initialized
INFO - 2018-07-19 21:58:38 --> Language Class Initialized
ERROR - 2018-07-19 21:58:38 --> 404 Page Not Found: /index
INFO - 2018-07-19 21:58:38 --> Config Class Initialized
INFO - 2018-07-19 21:58:38 --> Hooks Class Initialized
DEBUG - 2018-07-19 21:58:38 --> UTF-8 Support Enabled
INFO - 2018-07-19 21:58:38 --> Utf8 Class Initialized
INFO - 2018-07-19 21:58:38 --> URI Class Initialized
INFO - 2018-07-19 21:58:38 --> Router Class Initialized
INFO - 2018-07-19 21:58:38 --> Output Class Initialized
INFO - 2018-07-19 21:58:38 --> Security Class Initialized
DEBUG - 2018-07-19 21:58:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-19 21:58:38 --> Input Class Initialized
INFO - 2018-07-19 21:58:38 --> Language Class Initialized
ERROR - 2018-07-19 21:58:38 --> 404 Page Not Found: /index
INFO - 2018-07-19 21:58:44 --> Config Class Initialized
INFO - 2018-07-19 21:58:44 --> Hooks Class Initialized
DEBUG - 2018-07-19 21:58:44 --> UTF-8 Support Enabled
INFO - 2018-07-19 21:58:44 --> Utf8 Class Initialized
INFO - 2018-07-19 21:58:44 --> URI Class Initialized
INFO - 2018-07-19 21:58:44 --> Router Class Initialized
INFO - 2018-07-19 21:58:44 --> Output Class Initialized
INFO - 2018-07-19 21:58:44 --> Security Class Initialized
DEBUG - 2018-07-19 21:58:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-19 21:58:44 --> Input Class Initialized
INFO - 2018-07-19 21:58:44 --> Language Class Initialized
INFO - 2018-07-19 21:58:44 --> Language Class Initialized
INFO - 2018-07-19 21:58:44 --> Config Class Initialized
INFO - 2018-07-19 21:58:44 --> Loader Class Initialized
DEBUG - 2018-07-19 21:58:44 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-19 21:58:44 --> Helper loaded: url_helper
INFO - 2018-07-19 21:58:44 --> Helper loaded: form_helper
INFO - 2018-07-19 21:58:44 --> Helper loaded: date_helper
INFO - 2018-07-19 21:58:44 --> Helper loaded: util_helper
INFO - 2018-07-19 21:58:44 --> Helper loaded: text_helper
INFO - 2018-07-19 21:58:44 --> Helper loaded: string_helper
INFO - 2018-07-19 21:58:44 --> Database Driver Class Initialized
DEBUG - 2018-07-19 21:58:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-19 21:58:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-19 21:58:44 --> Email Class Initialized
INFO - 2018-07-19 21:58:44 --> Controller Class Initialized
DEBUG - 2018-07-19 21:58:44 --> Home MX_Controller Initialized
DEBUG - 2018-07-19 21:58:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-19 21:58:44 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-19 21:58:44 --> Login MX_Controller Initialized
INFO - 2018-07-19 21:58:44 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-19 21:58:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-19 21:58:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-19 21:58:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/login.php
INFO - 2018-07-19 21:58:47 --> Config Class Initialized
INFO - 2018-07-19 21:58:47 --> Hooks Class Initialized
DEBUG - 2018-07-19 21:58:47 --> UTF-8 Support Enabled
INFO - 2018-07-19 21:58:47 --> Utf8 Class Initialized
INFO - 2018-07-19 21:58:47 --> URI Class Initialized
INFO - 2018-07-19 21:58:47 --> Router Class Initialized
INFO - 2018-07-19 21:58:47 --> Output Class Initialized
INFO - 2018-07-19 21:58:47 --> Security Class Initialized
DEBUG - 2018-07-19 21:58:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-19 21:58:47 --> Input Class Initialized
INFO - 2018-07-19 21:58:47 --> Language Class Initialized
INFO - 2018-07-19 21:58:47 --> Language Class Initialized
INFO - 2018-07-19 21:58:47 --> Config Class Initialized
INFO - 2018-07-19 21:58:47 --> Loader Class Initialized
DEBUG - 2018-07-19 21:58:47 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-19 21:58:47 --> Helper loaded: url_helper
INFO - 2018-07-19 21:58:47 --> Helper loaded: form_helper
INFO - 2018-07-19 21:58:47 --> Helper loaded: date_helper
INFO - 2018-07-19 21:58:47 --> Helper loaded: util_helper
INFO - 2018-07-19 21:58:47 --> Helper loaded: text_helper
INFO - 2018-07-19 21:58:47 --> Helper loaded: string_helper
INFO - 2018-07-19 21:58:47 --> Database Driver Class Initialized
DEBUG - 2018-07-19 21:58:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-19 21:58:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-19 21:58:47 --> Email Class Initialized
INFO - 2018-07-19 21:58:47 --> Controller Class Initialized
DEBUG - 2018-07-19 21:58:47 --> Admin MX_Controller Initialized
INFO - 2018-07-19 21:58:47 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-19 21:58:47 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-19 21:58:47 --> Login MX_Controller Initialized
DEBUG - 2018-07-19 21:58:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-19 21:58:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-19 21:58:47 --> Config Class Initialized
INFO - 2018-07-19 21:58:47 --> Hooks Class Initialized
DEBUG - 2018-07-19 21:58:47 --> UTF-8 Support Enabled
INFO - 2018-07-19 21:58:47 --> Utf8 Class Initialized
DEBUG - 2018-07-19 21:58:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/logins/login.php
INFO - 2018-07-19 21:58:47 --> Config Class Initialized
INFO - 2018-07-19 21:58:47 --> Hooks Class Initialized
DEBUG - 2018-07-19 21:58:47 --> UTF-8 Support Enabled
INFO - 2018-07-19 21:58:47 --> Utf8 Class Initialized
INFO - 2018-07-19 21:58:47 --> URI Class Initialized
INFO - 2018-07-19 21:58:47 --> Router Class Initialized
INFO - 2018-07-19 21:58:47 --> Output Class Initialized
INFO - 2018-07-19 21:58:48 --> Security Class Initialized
DEBUG - 2018-07-19 21:58:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-19 21:58:48 --> Input Class Initialized
INFO - 2018-07-19 21:58:48 --> Language Class Initialized
ERROR - 2018-07-19 21:58:48 --> 404 Page Not Found: /index
INFO - 2018-07-19 21:58:49 --> Config Class Initialized
INFO - 2018-07-19 21:58:49 --> Hooks Class Initialized
DEBUG - 2018-07-19 21:58:49 --> UTF-8 Support Enabled
INFO - 2018-07-19 21:58:49 --> Utf8 Class Initialized
INFO - 2018-07-19 21:58:49 --> URI Class Initialized
INFO - 2018-07-19 21:58:49 --> Router Class Initialized
INFO - 2018-07-19 21:58:49 --> Output Class Initialized
INFO - 2018-07-19 21:58:49 --> Security Class Initialized
DEBUG - 2018-07-19 21:58:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-19 21:58:49 --> Input Class Initialized
INFO - 2018-07-19 21:58:49 --> Language Class Initialized
INFO - 2018-07-19 21:58:49 --> Language Class Initialized
INFO - 2018-07-19 21:58:49 --> Config Class Initialized
INFO - 2018-07-19 21:58:49 --> Loader Class Initialized
DEBUG - 2018-07-19 21:58:49 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-19 21:58:49 --> Helper loaded: url_helper
INFO - 2018-07-19 21:58:49 --> Helper loaded: form_helper
INFO - 2018-07-19 21:58:49 --> Helper loaded: date_helper
INFO - 2018-07-19 21:58:49 --> Helper loaded: util_helper
INFO - 2018-07-19 21:58:49 --> Helper loaded: text_helper
INFO - 2018-07-19 21:58:49 --> Helper loaded: string_helper
INFO - 2018-07-19 21:58:49 --> Database Driver Class Initialized
DEBUG - 2018-07-19 21:58:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-19 21:58:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-19 21:58:49 --> Email Class Initialized
INFO - 2018-07-19 21:58:49 --> Controller Class Initialized
DEBUG - 2018-07-19 21:58:49 --> Admin MX_Controller Initialized
INFO - 2018-07-19 21:58:49 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-19 21:58:49 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-19 21:58:49 --> Login MX_Controller Initialized
DEBUG - 2018-07-19 21:58:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-19 21:58:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-19 21:58:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/logins/login.php
INFO - 2018-07-19 21:58:50 --> Config Class Initialized
INFO - 2018-07-19 21:58:50 --> Hooks Class Initialized
DEBUG - 2018-07-19 21:58:50 --> UTF-8 Support Enabled
INFO - 2018-07-19 21:58:50 --> Utf8 Class Initialized
INFO - 2018-07-19 21:58:50 --> URI Class Initialized
INFO - 2018-07-19 21:58:50 --> Router Class Initialized
INFO - 2018-07-19 21:58:50 --> Output Class Initialized
INFO - 2018-07-19 21:58:50 --> Security Class Initialized
DEBUG - 2018-07-19 21:58:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-19 21:58:50 --> Input Class Initialized
INFO - 2018-07-19 21:58:50 --> Language Class Initialized
ERROR - 2018-07-19 21:58:50 --> 404 Page Not Found: /index
INFO - 2018-07-19 21:58:53 --> Config Class Initialized
INFO - 2018-07-19 21:58:53 --> Hooks Class Initialized
DEBUG - 2018-07-19 21:58:53 --> UTF-8 Support Enabled
INFO - 2018-07-19 21:58:53 --> Utf8 Class Initialized
INFO - 2018-07-19 21:58:53 --> URI Class Initialized
INFO - 2018-07-19 21:58:53 --> Router Class Initialized
INFO - 2018-07-19 21:58:53 --> Output Class Initialized
INFO - 2018-07-19 21:58:53 --> Security Class Initialized
DEBUG - 2018-07-19 21:58:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-19 21:58:53 --> Input Class Initialized
INFO - 2018-07-19 21:58:53 --> Language Class Initialized
INFO - 2018-07-19 21:58:53 --> Language Class Initialized
INFO - 2018-07-19 21:58:53 --> Config Class Initialized
INFO - 2018-07-19 21:58:53 --> Loader Class Initialized
DEBUG - 2018-07-19 21:58:53 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-19 21:58:53 --> Helper loaded: url_helper
INFO - 2018-07-19 21:58:53 --> Helper loaded: form_helper
INFO - 2018-07-19 21:58:53 --> Helper loaded: date_helper
INFO - 2018-07-19 21:58:53 --> Helper loaded: util_helper
INFO - 2018-07-19 21:58:53 --> Helper loaded: text_helper
INFO - 2018-07-19 21:58:53 --> Helper loaded: string_helper
INFO - 2018-07-19 21:58:53 --> Database Driver Class Initialized
DEBUG - 2018-07-19 21:58:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-19 21:58:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-19 21:58:53 --> Email Class Initialized
INFO - 2018-07-19 21:58:53 --> Controller Class Initialized
DEBUG - 2018-07-19 21:58:53 --> Login MX_Controller Initialized
INFO - 2018-07-19 21:58:53 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-19 21:58:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-19 21:58:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-19 21:58:53 --> Email starts for admin@colin.com fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-07-19 21:58:53 --> User session created for 1
INFO - 2018-07-19 21:58:54 --> Login status admin@colin.com - success
INFO - 2018-07-19 21:58:54 --> Final output sent to browser
DEBUG - 2018-07-19 21:58:54 --> Total execution time: 0.2723
INFO - 2018-07-19 21:58:54 --> Config Class Initialized
INFO - 2018-07-19 21:58:54 --> Hooks Class Initialized
DEBUG - 2018-07-19 21:58:54 --> UTF-8 Support Enabled
INFO - 2018-07-19 21:58:54 --> Utf8 Class Initialized
INFO - 2018-07-19 21:58:54 --> URI Class Initialized
INFO - 2018-07-19 21:58:54 --> Router Class Initialized
INFO - 2018-07-19 21:58:54 --> Output Class Initialized
INFO - 2018-07-19 21:58:54 --> Security Class Initialized
DEBUG - 2018-07-19 21:58:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-19 21:58:54 --> Input Class Initialized
INFO - 2018-07-19 21:58:54 --> Language Class Initialized
INFO - 2018-07-19 21:58:54 --> Language Class Initialized
INFO - 2018-07-19 21:58:54 --> Config Class Initialized
INFO - 2018-07-19 21:58:54 --> Loader Class Initialized
DEBUG - 2018-07-19 21:58:54 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-19 21:58:54 --> Helper loaded: url_helper
INFO - 2018-07-19 21:58:54 --> Helper loaded: form_helper
INFO - 2018-07-19 21:58:54 --> Helper loaded: date_helper
INFO - 2018-07-19 21:58:54 --> Helper loaded: util_helper
INFO - 2018-07-19 21:58:54 --> Helper loaded: text_helper
INFO - 2018-07-19 21:58:54 --> Helper loaded: string_helper
INFO - 2018-07-19 21:58:54 --> Database Driver Class Initialized
DEBUG - 2018-07-19 21:58:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-19 21:58:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-19 21:58:54 --> Email Class Initialized
INFO - 2018-07-19 21:58:54 --> Controller Class Initialized
DEBUG - 2018-07-19 21:58:54 --> Admin MX_Controller Initialized
INFO - 2018-07-19 21:58:54 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-19 21:58:54 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-19 21:58:54 --> Login MX_Controller Initialized
DEBUG - 2018-07-19 21:58:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-19 21:58:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-19 21:58:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-19 21:58:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-19 21:58:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-19 21:58:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-19 21:58:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-19 21:58:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/dashboard.php
INFO - 2018-07-19 21:58:54 --> Final output sent to browser
DEBUG - 2018-07-19 21:58:54 --> Total execution time: 0.7321
INFO - 2018-07-19 21:58:54 --> Config Class Initialized
INFO - 2018-07-19 21:58:54 --> Hooks Class Initialized
DEBUG - 2018-07-19 21:58:54 --> UTF-8 Support Enabled
INFO - 2018-07-19 21:58:54 --> Utf8 Class Initialized
INFO - 2018-07-19 21:58:54 --> URI Class Initialized
INFO - 2018-07-19 21:58:55 --> Router Class Initialized
INFO - 2018-07-19 21:58:55 --> Output Class Initialized
INFO - 2018-07-19 21:58:55 --> Security Class Initialized
DEBUG - 2018-07-19 21:58:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-19 21:58:55 --> Input Class Initialized
INFO - 2018-07-19 21:58:55 --> Language Class Initialized
ERROR - 2018-07-19 21:58:55 --> 404 Page Not Found: /index
INFO - 2018-07-19 21:58:55 --> Config Class Initialized
INFO - 2018-07-19 21:58:55 --> Hooks Class Initialized
DEBUG - 2018-07-19 21:58:55 --> UTF-8 Support Enabled
INFO - 2018-07-19 21:58:55 --> Utf8 Class Initialized
INFO - 2018-07-19 21:58:55 --> URI Class Initialized
INFO - 2018-07-19 21:58:55 --> Router Class Initialized
INFO - 2018-07-19 21:58:55 --> Output Class Initialized
INFO - 2018-07-19 21:58:55 --> Security Class Initialized
DEBUG - 2018-07-19 21:58:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-19 21:58:55 --> Input Class Initialized
INFO - 2018-07-19 21:58:55 --> Language Class Initialized
ERROR - 2018-07-19 21:58:55 --> 404 Page Not Found: /index
INFO - 2018-07-19 21:59:08 --> Config Class Initialized
INFO - 2018-07-19 21:59:08 --> Hooks Class Initialized
DEBUG - 2018-07-19 21:59:08 --> UTF-8 Support Enabled
INFO - 2018-07-19 21:59:08 --> Utf8 Class Initialized
INFO - 2018-07-19 21:59:08 --> URI Class Initialized
INFO - 2018-07-19 21:59:08 --> Router Class Initialized
INFO - 2018-07-19 21:59:08 --> Output Class Initialized
INFO - 2018-07-19 21:59:08 --> Security Class Initialized
DEBUG - 2018-07-19 21:59:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-19 21:59:08 --> Input Class Initialized
INFO - 2018-07-19 21:59:08 --> Language Class Initialized
INFO - 2018-07-19 21:59:08 --> Language Class Initialized
INFO - 2018-07-19 21:59:08 --> Config Class Initialized
INFO - 2018-07-19 21:59:08 --> Loader Class Initialized
DEBUG - 2018-07-19 21:59:08 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-19 21:59:08 --> Helper loaded: url_helper
INFO - 2018-07-19 21:59:08 --> Helper loaded: form_helper
INFO - 2018-07-19 21:59:08 --> Helper loaded: date_helper
INFO - 2018-07-19 21:59:08 --> Helper loaded: util_helper
INFO - 2018-07-19 21:59:08 --> Helper loaded: text_helper
INFO - 2018-07-19 21:59:08 --> Helper loaded: string_helper
INFO - 2018-07-19 21:59:08 --> Database Driver Class Initialized
DEBUG - 2018-07-19 21:59:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-19 21:59:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-19 21:59:08 --> Email Class Initialized
INFO - 2018-07-19 21:59:08 --> Controller Class Initialized
DEBUG - 2018-07-19 21:59:08 --> Home MX_Controller Initialized
DEBUG - 2018-07-19 21:59:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-19 21:59:09 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-19 21:59:09 --> Login MX_Controller Initialized
INFO - 2018-07-19 21:59:09 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-19 21:59:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-19 21:59:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-19 21:59:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-07-19 21:59:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-07-19 21:59:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-07-19 21:59:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-07-19 21:59:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-07-19 21:59:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-07-19 21:59:09 --> Final output sent to browser
DEBUG - 2018-07-19 21:59:09 --> Total execution time: 0.6321
INFO - 2018-07-19 21:59:09 --> Config Class Initialized
INFO - 2018-07-19 21:59:09 --> Hooks Class Initialized
INFO - 2018-07-19 21:59:09 --> Config Class Initialized
INFO - 2018-07-19 21:59:09 --> Hooks Class Initialized
DEBUG - 2018-07-19 21:59:09 --> UTF-8 Support Enabled
INFO - 2018-07-19 21:59:09 --> Utf8 Class Initialized
DEBUG - 2018-07-19 21:59:09 --> UTF-8 Support Enabled
INFO - 2018-07-19 21:59:09 --> URI Class Initialized
INFO - 2018-07-19 21:59:09 --> Router Class Initialized
INFO - 2018-07-19 21:59:09 --> Output Class Initialized
INFO - 2018-07-19 21:59:09 --> Security Class Initialized
DEBUG - 2018-07-19 21:59:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-19 21:59:09 --> Input Class Initialized
INFO - 2018-07-19 21:59:09 --> Language Class Initialized
ERROR - 2018-07-19 21:59:09 --> 404 Page Not Found: /index
INFO - 2018-07-19 21:59:09 --> Utf8 Class Initialized
INFO - 2018-07-19 21:59:09 --> URI Class Initialized
INFO - 2018-07-19 21:59:09 --> Router Class Initialized
INFO - 2018-07-19 21:59:10 --> Output Class Initialized
INFO - 2018-07-19 21:59:10 --> Security Class Initialized
DEBUG - 2018-07-19 21:59:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-19 21:59:10 --> Input Class Initialized
INFO - 2018-07-19 21:59:10 --> Language Class Initialized
ERROR - 2018-07-19 21:59:10 --> 404 Page Not Found: /index
INFO - 2018-07-19 21:59:10 --> Config Class Initialized
INFO - 2018-07-19 21:59:10 --> Hooks Class Initialized
DEBUG - 2018-07-19 21:59:10 --> UTF-8 Support Enabled
INFO - 2018-07-19 21:59:10 --> Utf8 Class Initialized
INFO - 2018-07-19 21:59:10 --> URI Class Initialized
INFO - 2018-07-19 21:59:10 --> Router Class Initialized
INFO - 2018-07-19 21:59:10 --> Output Class Initialized
INFO - 2018-07-19 21:59:10 --> Security Class Initialized
DEBUG - 2018-07-19 21:59:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-19 21:59:10 --> Input Class Initialized
INFO - 2018-07-19 21:59:10 --> Language Class Initialized
ERROR - 2018-07-19 21:59:10 --> 404 Page Not Found: /index
INFO - 2018-07-19 21:59:10 --> Config Class Initialized
INFO - 2018-07-19 21:59:10 --> Hooks Class Initialized
DEBUG - 2018-07-19 21:59:10 --> UTF-8 Support Enabled
INFO - 2018-07-19 21:59:10 --> Utf8 Class Initialized
INFO - 2018-07-19 21:59:10 --> URI Class Initialized
INFO - 2018-07-19 21:59:10 --> Router Class Initialized
INFO - 2018-07-19 21:59:10 --> Output Class Initialized
INFO - 2018-07-19 21:59:10 --> Security Class Initialized
DEBUG - 2018-07-19 21:59:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-19 21:59:10 --> Input Class Initialized
INFO - 2018-07-19 21:59:10 --> Language Class Initialized
ERROR - 2018-07-19 21:59:10 --> 404 Page Not Found: /index
INFO - 2018-07-19 21:59:43 --> Config Class Initialized
INFO - 2018-07-19 21:59:43 --> Hooks Class Initialized
DEBUG - 2018-07-19 21:59:43 --> UTF-8 Support Enabled
INFO - 2018-07-19 21:59:43 --> Utf8 Class Initialized
INFO - 2018-07-19 21:59:43 --> URI Class Initialized
INFO - 2018-07-19 21:59:43 --> Router Class Initialized
INFO - 2018-07-19 21:59:43 --> Output Class Initialized
INFO - 2018-07-19 21:59:43 --> Security Class Initialized
DEBUG - 2018-07-19 21:59:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-19 21:59:43 --> Input Class Initialized
INFO - 2018-07-19 21:59:43 --> Language Class Initialized
INFO - 2018-07-19 21:59:43 --> Language Class Initialized
INFO - 2018-07-19 21:59:43 --> Config Class Initialized
INFO - 2018-07-19 21:59:43 --> Loader Class Initialized
DEBUG - 2018-07-19 21:59:43 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-19 21:59:43 --> Helper loaded: url_helper
INFO - 2018-07-19 21:59:43 --> Helper loaded: form_helper
INFO - 2018-07-19 21:59:43 --> Helper loaded: date_helper
INFO - 2018-07-19 21:59:43 --> Helper loaded: util_helper
INFO - 2018-07-19 21:59:43 --> Helper loaded: text_helper
INFO - 2018-07-19 21:59:43 --> Helper loaded: string_helper
INFO - 2018-07-19 21:59:43 --> Database Driver Class Initialized
DEBUG - 2018-07-19 21:59:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-19 21:59:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-19 21:59:43 --> Email Class Initialized
INFO - 2018-07-19 21:59:43 --> Controller Class Initialized
DEBUG - 2018-07-19 21:59:43 --> Users MX_Controller Initialized
DEBUG - 2018-07-19 21:59:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-19 21:59:43 --> Helper loaded: file_helper
DEBUG - 2018-07-19 21:59:43 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-19 21:59:43 --> Login MX_Controller Initialized
INFO - 2018-07-19 21:59:43 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-19 21:59:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-19 21:59:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-19 21:59:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-19 21:59:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-19 21:59:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-19 21:59:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-19 21:59:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/users.php
INFO - 2018-07-19 21:59:43 --> Final output sent to browser
DEBUG - 2018-07-19 21:59:43 --> Total execution time: 0.4052
INFO - 2018-07-19 21:59:44 --> Config Class Initialized
INFO - 2018-07-19 21:59:44 --> Hooks Class Initialized
DEBUG - 2018-07-19 21:59:44 --> UTF-8 Support Enabled
INFO - 2018-07-19 21:59:44 --> Utf8 Class Initialized
INFO - 2018-07-19 21:59:44 --> URI Class Initialized
INFO - 2018-07-19 21:59:44 --> Router Class Initialized
INFO - 2018-07-19 21:59:44 --> Output Class Initialized
INFO - 2018-07-19 21:59:44 --> Security Class Initialized
DEBUG - 2018-07-19 21:59:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-19 21:59:44 --> Input Class Initialized
INFO - 2018-07-19 21:59:44 --> Language Class Initialized
INFO - 2018-07-19 21:59:44 --> Language Class Initialized
INFO - 2018-07-19 21:59:44 --> Config Class Initialized
INFO - 2018-07-19 21:59:44 --> Loader Class Initialized
DEBUG - 2018-07-19 21:59:44 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-19 21:59:44 --> Helper loaded: url_helper
INFO - 2018-07-19 21:59:44 --> Helper loaded: form_helper
INFO - 2018-07-19 21:59:44 --> Helper loaded: date_helper
INFO - 2018-07-19 21:59:44 --> Helper loaded: util_helper
INFO - 2018-07-19 21:59:44 --> Helper loaded: text_helper
INFO - 2018-07-19 21:59:44 --> Helper loaded: string_helper
INFO - 2018-07-19 21:59:44 --> Database Driver Class Initialized
DEBUG - 2018-07-19 21:59:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-19 21:59:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-19 21:59:44 --> Email Class Initialized
INFO - 2018-07-19 21:59:44 --> Controller Class Initialized
DEBUG - 2018-07-19 21:59:44 --> Users MX_Controller Initialized
DEBUG - 2018-07-19 21:59:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-19 21:59:44 --> Helper loaded: file_helper
DEBUG - 2018-07-19 21:59:44 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-19 21:59:44 --> Login MX_Controller Initialized
INFO - 2018-07-19 21:59:44 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-19 21:59:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-19 21:59:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-07-19 21:59:45 --> Final output sent to browser
DEBUG - 2018-07-19 21:59:45 --> Total execution time: 0.7646
INFO - 2018-07-19 22:32:31 --> Config Class Initialized
INFO - 2018-07-19 22:32:31 --> Hooks Class Initialized
DEBUG - 2018-07-19 22:32:31 --> UTF-8 Support Enabled
INFO - 2018-07-19 22:32:31 --> Utf8 Class Initialized
INFO - 2018-07-19 22:32:31 --> URI Class Initialized
INFO - 2018-07-19 22:32:31 --> Router Class Initialized
INFO - 2018-07-19 22:32:31 --> Output Class Initialized
INFO - 2018-07-19 22:32:31 --> Security Class Initialized
DEBUG - 2018-07-19 22:32:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-19 22:32:31 --> Input Class Initialized
INFO - 2018-07-19 22:32:31 --> Language Class Initialized
INFO - 2018-07-19 22:32:31 --> Language Class Initialized
INFO - 2018-07-19 22:32:31 --> Config Class Initialized
INFO - 2018-07-19 22:32:31 --> Loader Class Initialized
DEBUG - 2018-07-19 22:32:31 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-19 22:32:31 --> Helper loaded: url_helper
INFO - 2018-07-19 22:32:31 --> Helper loaded: form_helper
INFO - 2018-07-19 22:32:31 --> Helper loaded: date_helper
INFO - 2018-07-19 22:32:31 --> Helper loaded: util_helper
INFO - 2018-07-19 22:32:31 --> Helper loaded: text_helper
INFO - 2018-07-19 22:32:31 --> Helper loaded: string_helper
INFO - 2018-07-19 22:32:31 --> Database Driver Class Initialized
DEBUG - 2018-07-19 22:32:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-19 22:32:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-19 22:32:31 --> Email Class Initialized
INFO - 2018-07-19 22:32:31 --> Controller Class Initialized
DEBUG - 2018-07-19 22:32:31 --> Users MX_Controller Initialized
DEBUG - 2018-07-19 22:32:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-19 22:32:31 --> Helper loaded: file_helper
DEBUG - 2018-07-19 22:32:32 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-19 22:32:32 --> Login MX_Controller Initialized
INFO - 2018-07-19 22:32:32 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-19 22:32:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-19 22:32:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
DEBUG - 2018-07-19 22:32:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-19 22:32:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-19 22:32:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-19 22:32:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-19 22:32:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-19 22:32:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/create_user.php
INFO - 2018-07-19 22:32:32 --> Final output sent to browser
DEBUG - 2018-07-19 22:32:32 --> Total execution time: 1.2034
INFO - 2018-07-19 22:34:41 --> Config Class Initialized
INFO - 2018-07-19 22:34:41 --> Hooks Class Initialized
DEBUG - 2018-07-19 22:34:41 --> UTF-8 Support Enabled
INFO - 2018-07-19 22:34:41 --> Utf8 Class Initialized
INFO - 2018-07-19 22:34:41 --> URI Class Initialized
INFO - 2018-07-19 22:34:41 --> Router Class Initialized
INFO - 2018-07-19 22:34:41 --> Output Class Initialized
INFO - 2018-07-19 22:34:41 --> Security Class Initialized
DEBUG - 2018-07-19 22:34:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-19 22:34:41 --> Input Class Initialized
INFO - 2018-07-19 22:34:41 --> Language Class Initialized
INFO - 2018-07-19 22:34:41 --> Language Class Initialized
INFO - 2018-07-19 22:34:41 --> Config Class Initialized
INFO - 2018-07-19 22:34:41 --> Loader Class Initialized
DEBUG - 2018-07-19 22:34:41 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-19 22:34:41 --> Helper loaded: url_helper
INFO - 2018-07-19 22:34:41 --> Helper loaded: form_helper
INFO - 2018-07-19 22:34:41 --> Helper loaded: date_helper
INFO - 2018-07-19 22:34:41 --> Helper loaded: util_helper
INFO - 2018-07-19 22:34:41 --> Helper loaded: text_helper
INFO - 2018-07-19 22:34:41 --> Helper loaded: string_helper
INFO - 2018-07-19 22:34:41 --> Database Driver Class Initialized
DEBUG - 2018-07-19 22:34:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-19 22:34:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-19 22:34:41 --> Email Class Initialized
INFO - 2018-07-19 22:34:41 --> Controller Class Initialized
DEBUG - 2018-07-19 22:34:41 --> Users MX_Controller Initialized
DEBUG - 2018-07-19 22:34:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-19 22:34:41 --> Helper loaded: file_helper
DEBUG - 2018-07-19 22:34:41 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-19 22:34:41 --> Login MX_Controller Initialized
INFO - 2018-07-19 22:34:41 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-19 22:34:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-19 22:34:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
DEBUG - 2018-07-19 22:34:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-19 22:34:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-19 22:34:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-19 22:34:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-19 22:34:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-19 22:34:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/create_user.php
INFO - 2018-07-19 22:34:41 --> Final output sent to browser
DEBUG - 2018-07-19 22:34:42 --> Total execution time: 0.2606
INFO - 2018-07-19 22:34:48 --> Config Class Initialized
INFO - 2018-07-19 22:34:48 --> Hooks Class Initialized
DEBUG - 2018-07-19 22:34:48 --> UTF-8 Support Enabled
INFO - 2018-07-19 22:34:48 --> Utf8 Class Initialized
INFO - 2018-07-19 22:34:48 --> URI Class Initialized
INFO - 2018-07-19 22:34:48 --> Router Class Initialized
INFO - 2018-07-19 22:34:48 --> Output Class Initialized
INFO - 2018-07-19 22:34:48 --> Security Class Initialized
DEBUG - 2018-07-19 22:34:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-19 22:34:48 --> Input Class Initialized
INFO - 2018-07-19 22:34:48 --> Language Class Initialized
INFO - 2018-07-19 22:34:48 --> Language Class Initialized
INFO - 2018-07-19 22:34:48 --> Config Class Initialized
INFO - 2018-07-19 22:34:48 --> Loader Class Initialized
DEBUG - 2018-07-19 22:34:48 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-19 22:34:48 --> Helper loaded: url_helper
INFO - 2018-07-19 22:34:48 --> Helper loaded: form_helper
INFO - 2018-07-19 22:34:48 --> Helper loaded: date_helper
INFO - 2018-07-19 22:34:48 --> Helper loaded: util_helper
INFO - 2018-07-19 22:34:48 --> Helper loaded: text_helper
INFO - 2018-07-19 22:34:48 --> Helper loaded: string_helper
INFO - 2018-07-19 22:34:48 --> Database Driver Class Initialized
DEBUG - 2018-07-19 22:34:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-19 22:34:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-19 22:34:48 --> Email Class Initialized
INFO - 2018-07-19 22:34:48 --> Controller Class Initialized
DEBUG - 2018-07-19 22:34:48 --> Users MX_Controller Initialized
DEBUG - 2018-07-19 22:34:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-19 22:34:48 --> Helper loaded: file_helper
DEBUG - 2018-07-19 22:34:48 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-19 22:34:48 --> Login MX_Controller Initialized
INFO - 2018-07-19 22:34:48 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-19 22:34:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-19 22:34:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
DEBUG - 2018-07-19 22:34:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-19 22:34:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-19 22:34:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-19 22:34:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-19 22:34:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-19 22:34:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/create_user.php
INFO - 2018-07-19 22:34:48 --> Final output sent to browser
DEBUG - 2018-07-19 22:34:48 --> Total execution time: 0.3260
INFO - 2018-07-19 22:35:12 --> Config Class Initialized
INFO - 2018-07-19 22:35:12 --> Hooks Class Initialized
DEBUG - 2018-07-19 22:35:12 --> UTF-8 Support Enabled
INFO - 2018-07-19 22:35:12 --> Utf8 Class Initialized
INFO - 2018-07-19 22:35:12 --> URI Class Initialized
INFO - 2018-07-19 22:35:12 --> Router Class Initialized
INFO - 2018-07-19 22:35:12 --> Output Class Initialized
INFO - 2018-07-19 22:35:12 --> Security Class Initialized
DEBUG - 2018-07-19 22:35:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-19 22:35:12 --> Input Class Initialized
INFO - 2018-07-19 22:35:12 --> Language Class Initialized
INFO - 2018-07-19 22:35:12 --> Language Class Initialized
INFO - 2018-07-19 22:35:12 --> Config Class Initialized
INFO - 2018-07-19 22:35:12 --> Loader Class Initialized
DEBUG - 2018-07-19 22:35:12 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-19 22:35:12 --> Helper loaded: url_helper
INFO - 2018-07-19 22:35:12 --> Helper loaded: form_helper
INFO - 2018-07-19 22:35:12 --> Helper loaded: date_helper
INFO - 2018-07-19 22:35:12 --> Helper loaded: util_helper
INFO - 2018-07-19 22:35:12 --> Helper loaded: text_helper
INFO - 2018-07-19 22:35:12 --> Helper loaded: string_helper
INFO - 2018-07-19 22:35:12 --> Database Driver Class Initialized
DEBUG - 2018-07-19 22:35:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-19 22:35:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-19 22:35:12 --> Email Class Initialized
INFO - 2018-07-19 22:35:12 --> Controller Class Initialized
DEBUG - 2018-07-19 22:35:12 --> Users MX_Controller Initialized
DEBUG - 2018-07-19 22:35:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-19 22:35:12 --> Helper loaded: file_helper
DEBUG - 2018-07-19 22:35:12 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-19 22:35:12 --> Login MX_Controller Initialized
INFO - 2018-07-19 22:35:12 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-19 22:35:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-19 22:35:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
DEBUG - 2018-07-19 22:35:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-19 22:35:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-19 22:35:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-19 22:35:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-19 22:35:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-19 22:35:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/create_user.php
INFO - 2018-07-19 22:35:12 --> Final output sent to browser
DEBUG - 2018-07-19 22:35:12 --> Total execution time: 0.2598
INFO - 2018-07-19 22:38:14 --> Config Class Initialized
INFO - 2018-07-19 22:38:14 --> Hooks Class Initialized
DEBUG - 2018-07-19 22:38:14 --> UTF-8 Support Enabled
INFO - 2018-07-19 22:38:14 --> Utf8 Class Initialized
INFO - 2018-07-19 22:38:14 --> URI Class Initialized
INFO - 2018-07-19 22:38:14 --> Router Class Initialized
INFO - 2018-07-19 22:38:14 --> Output Class Initialized
INFO - 2018-07-19 22:38:14 --> Security Class Initialized
DEBUG - 2018-07-19 22:38:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-19 22:38:14 --> Input Class Initialized
INFO - 2018-07-19 22:38:14 --> Language Class Initialized
INFO - 2018-07-19 22:38:14 --> Language Class Initialized
INFO - 2018-07-19 22:38:14 --> Config Class Initialized
INFO - 2018-07-19 22:38:14 --> Loader Class Initialized
DEBUG - 2018-07-19 22:38:14 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-19 22:38:14 --> Helper loaded: url_helper
INFO - 2018-07-19 22:38:14 --> Helper loaded: form_helper
INFO - 2018-07-19 22:38:14 --> Helper loaded: date_helper
INFO - 2018-07-19 22:38:14 --> Helper loaded: util_helper
INFO - 2018-07-19 22:38:14 --> Helper loaded: text_helper
INFO - 2018-07-19 22:38:14 --> Helper loaded: string_helper
INFO - 2018-07-19 22:38:14 --> Database Driver Class Initialized
DEBUG - 2018-07-19 22:38:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-19 22:38:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-19 22:38:14 --> Email Class Initialized
INFO - 2018-07-19 22:38:14 --> Controller Class Initialized
DEBUG - 2018-07-19 22:38:14 --> Users MX_Controller Initialized
DEBUG - 2018-07-19 22:38:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-19 22:38:14 --> Helper loaded: file_helper
DEBUG - 2018-07-19 22:38:14 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-19 22:38:14 --> Login MX_Controller Initialized
INFO - 2018-07-19 22:38:14 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-19 22:38:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-19 22:38:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
DEBUG - 2018-07-19 22:38:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-19 22:38:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-19 22:38:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-19 22:38:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-19 22:38:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-19 22:38:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/create_user.php
INFO - 2018-07-19 22:38:14 --> Final output sent to browser
DEBUG - 2018-07-19 22:38:14 --> Total execution time: 0.2644
INFO - 2018-07-19 22:39:42 --> Config Class Initialized
INFO - 2018-07-19 22:39:42 --> Hooks Class Initialized
DEBUG - 2018-07-19 22:39:42 --> UTF-8 Support Enabled
INFO - 2018-07-19 22:39:42 --> Utf8 Class Initialized
INFO - 2018-07-19 22:39:42 --> URI Class Initialized
INFO - 2018-07-19 22:39:42 --> Router Class Initialized
INFO - 2018-07-19 22:39:42 --> Output Class Initialized
INFO - 2018-07-19 22:39:42 --> Security Class Initialized
DEBUG - 2018-07-19 22:39:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-19 22:39:42 --> Input Class Initialized
INFO - 2018-07-19 22:39:42 --> Language Class Initialized
INFO - 2018-07-19 22:39:42 --> Language Class Initialized
INFO - 2018-07-19 22:39:42 --> Config Class Initialized
INFO - 2018-07-19 22:39:42 --> Loader Class Initialized
DEBUG - 2018-07-19 22:39:42 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-19 22:39:42 --> Helper loaded: url_helper
INFO - 2018-07-19 22:39:42 --> Helper loaded: form_helper
INFO - 2018-07-19 22:39:42 --> Helper loaded: date_helper
INFO - 2018-07-19 22:39:42 --> Helper loaded: util_helper
INFO - 2018-07-19 22:39:42 --> Helper loaded: text_helper
INFO - 2018-07-19 22:39:43 --> Helper loaded: string_helper
INFO - 2018-07-19 22:39:43 --> Database Driver Class Initialized
DEBUG - 2018-07-19 22:39:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-19 22:39:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-19 22:39:43 --> Email Class Initialized
INFO - 2018-07-19 22:39:43 --> Controller Class Initialized
DEBUG - 2018-07-19 22:39:43 --> Users MX_Controller Initialized
DEBUG - 2018-07-19 22:39:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-19 22:39:43 --> Helper loaded: file_helper
DEBUG - 2018-07-19 22:39:43 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-19 22:39:43 --> Login MX_Controller Initialized
INFO - 2018-07-19 22:39:43 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-19 22:39:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-19 22:39:43 --> Final output sent to browser
DEBUG - 2018-07-19 22:39:43 --> Total execution time: 0.9693
INFO - 2018-07-19 22:40:33 --> Config Class Initialized
INFO - 2018-07-19 22:40:33 --> Hooks Class Initialized
DEBUG - 2018-07-19 22:40:33 --> UTF-8 Support Enabled
INFO - 2018-07-19 22:40:33 --> Utf8 Class Initialized
INFO - 2018-07-19 22:40:33 --> URI Class Initialized
INFO - 2018-07-19 22:40:33 --> Router Class Initialized
INFO - 2018-07-19 22:40:33 --> Output Class Initialized
INFO - 2018-07-19 22:40:33 --> Security Class Initialized
DEBUG - 2018-07-19 22:40:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-19 22:40:33 --> Input Class Initialized
INFO - 2018-07-19 22:40:33 --> Language Class Initialized
INFO - 2018-07-19 22:40:33 --> Language Class Initialized
INFO - 2018-07-19 22:40:33 --> Config Class Initialized
INFO - 2018-07-19 22:40:33 --> Loader Class Initialized
DEBUG - 2018-07-19 22:40:33 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-19 22:40:33 --> Helper loaded: url_helper
INFO - 2018-07-19 22:40:34 --> Helper loaded: form_helper
INFO - 2018-07-19 22:40:34 --> Helper loaded: date_helper
INFO - 2018-07-19 22:40:34 --> Helper loaded: util_helper
INFO - 2018-07-19 22:40:34 --> Helper loaded: text_helper
INFO - 2018-07-19 22:40:34 --> Helper loaded: string_helper
INFO - 2018-07-19 22:40:34 --> Database Driver Class Initialized
DEBUG - 2018-07-19 22:40:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-19 22:40:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-19 22:40:34 --> Email Class Initialized
INFO - 2018-07-19 22:40:34 --> Controller Class Initialized
DEBUG - 2018-07-19 22:40:34 --> Users MX_Controller Initialized
DEBUG - 2018-07-19 22:40:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-19 22:40:34 --> Helper loaded: file_helper
DEBUG - 2018-07-19 22:40:34 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-19 22:40:34 --> Login MX_Controller Initialized
INFO - 2018-07-19 22:40:34 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-19 22:40:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-19 22:40:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-07-19 23:09:55 --> Config Class Initialized
INFO - 2018-07-19 23:09:55 --> Hooks Class Initialized
DEBUG - 2018-07-19 23:09:55 --> UTF-8 Support Enabled
INFO - 2018-07-19 23:09:55 --> Utf8 Class Initialized
INFO - 2018-07-19 23:09:55 --> URI Class Initialized
INFO - 2018-07-19 23:09:55 --> Router Class Initialized
INFO - 2018-07-19 23:09:55 --> Output Class Initialized
INFO - 2018-07-19 23:09:55 --> Security Class Initialized
DEBUG - 2018-07-19 23:09:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-19 23:09:55 --> Input Class Initialized
INFO - 2018-07-19 23:09:55 --> Language Class Initialized
INFO - 2018-07-19 23:09:55 --> Language Class Initialized
INFO - 2018-07-19 23:09:55 --> Config Class Initialized
INFO - 2018-07-19 23:09:55 --> Loader Class Initialized
DEBUG - 2018-07-19 23:09:55 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-19 23:09:55 --> Helper loaded: url_helper
INFO - 2018-07-19 23:09:55 --> Helper loaded: form_helper
INFO - 2018-07-19 23:09:55 --> Helper loaded: date_helper
INFO - 2018-07-19 23:09:55 --> Helper loaded: util_helper
INFO - 2018-07-19 23:09:55 --> Helper loaded: text_helper
INFO - 2018-07-19 23:09:55 --> Helper loaded: string_helper
INFO - 2018-07-19 23:09:55 --> Database Driver Class Initialized
DEBUG - 2018-07-19 23:09:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-19 23:09:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-19 23:09:55 --> Email Class Initialized
INFO - 2018-07-19 23:09:55 --> Controller Class Initialized
DEBUG - 2018-07-19 23:09:55 --> Users MX_Controller Initialized
DEBUG - 2018-07-19 23:09:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-19 23:09:55 --> Helper loaded: file_helper
DEBUG - 2018-07-19 23:09:55 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-19 23:09:55 --> Login MX_Controller Initialized
INFO - 2018-07-19 23:09:55 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-19 23:09:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-19 23:09:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
DEBUG - 2018-07-19 23:09:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-19 23:09:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-19 23:09:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-19 23:09:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-19 23:09:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-19 23:09:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/create_user.php
INFO - 2018-07-19 23:09:56 --> Final output sent to browser
DEBUG - 2018-07-19 23:09:56 --> Total execution time: 0.3963
INFO - 2018-07-19 23:14:46 --> Config Class Initialized
INFO - 2018-07-19 23:14:46 --> Hooks Class Initialized
DEBUG - 2018-07-19 23:14:46 --> UTF-8 Support Enabled
INFO - 2018-07-19 23:14:46 --> Utf8 Class Initialized
INFO - 2018-07-19 23:14:46 --> URI Class Initialized
INFO - 2018-07-19 23:14:46 --> Router Class Initialized
INFO - 2018-07-19 23:14:46 --> Output Class Initialized
INFO - 2018-07-19 23:14:46 --> Security Class Initialized
DEBUG - 2018-07-19 23:14:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-19 23:14:46 --> Input Class Initialized
INFO - 2018-07-19 23:14:46 --> Language Class Initialized
INFO - 2018-07-19 23:14:46 --> Language Class Initialized
INFO - 2018-07-19 23:14:46 --> Config Class Initialized
INFO - 2018-07-19 23:14:46 --> Loader Class Initialized
DEBUG - 2018-07-19 23:14:46 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-19 23:14:46 --> Helper loaded: url_helper
INFO - 2018-07-19 23:14:46 --> Helper loaded: form_helper
INFO - 2018-07-19 23:14:46 --> Helper loaded: date_helper
INFO - 2018-07-19 23:14:46 --> Helper loaded: util_helper
INFO - 2018-07-19 23:14:46 --> Helper loaded: text_helper
INFO - 2018-07-19 23:14:46 --> Helper loaded: string_helper
INFO - 2018-07-19 23:14:46 --> Database Driver Class Initialized
DEBUG - 2018-07-19 23:14:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-19 23:14:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-19 23:14:46 --> Email Class Initialized
INFO - 2018-07-19 23:14:46 --> Controller Class Initialized
DEBUG - 2018-07-19 23:14:46 --> Users MX_Controller Initialized
DEBUG - 2018-07-19 23:14:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-19 23:14:46 --> Helper loaded: file_helper
DEBUG - 2018-07-19 23:14:46 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-19 23:14:46 --> Login MX_Controller Initialized
INFO - 2018-07-19 23:14:46 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-19 23:14:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-19 23:14:46 --> Final output sent to browser
DEBUG - 2018-07-19 23:14:46 --> Total execution time: 0.2386
INFO - 2018-07-19 23:14:52 --> Config Class Initialized
INFO - 2018-07-19 23:14:52 --> Hooks Class Initialized
DEBUG - 2018-07-19 23:14:52 --> UTF-8 Support Enabled
INFO - 2018-07-19 23:14:52 --> Utf8 Class Initialized
INFO - 2018-07-19 23:14:52 --> URI Class Initialized
INFO - 2018-07-19 23:14:52 --> Router Class Initialized
INFO - 2018-07-19 23:14:52 --> Output Class Initialized
INFO - 2018-07-19 23:14:52 --> Security Class Initialized
DEBUG - 2018-07-19 23:14:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-19 23:14:52 --> Input Class Initialized
INFO - 2018-07-19 23:14:52 --> Language Class Initialized
INFO - 2018-07-19 23:14:52 --> Language Class Initialized
INFO - 2018-07-19 23:14:52 --> Config Class Initialized
INFO - 2018-07-19 23:14:52 --> Loader Class Initialized
DEBUG - 2018-07-19 23:14:52 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-19 23:14:52 --> Helper loaded: url_helper
INFO - 2018-07-19 23:14:52 --> Helper loaded: form_helper
INFO - 2018-07-19 23:14:53 --> Helper loaded: date_helper
INFO - 2018-07-19 23:14:53 --> Helper loaded: util_helper
INFO - 2018-07-19 23:14:53 --> Helper loaded: text_helper
INFO - 2018-07-19 23:14:53 --> Helper loaded: string_helper
INFO - 2018-07-19 23:14:53 --> Database Driver Class Initialized
DEBUG - 2018-07-19 23:14:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-19 23:14:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-19 23:14:53 --> Email Class Initialized
INFO - 2018-07-19 23:14:53 --> Controller Class Initialized
DEBUG - 2018-07-19 23:14:53 --> Users MX_Controller Initialized
DEBUG - 2018-07-19 23:14:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-19 23:14:53 --> Helper loaded: file_helper
DEBUG - 2018-07-19 23:14:53 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-19 23:14:53 --> Login MX_Controller Initialized
INFO - 2018-07-19 23:14:53 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-19 23:14:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-19 23:14:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-07-19 23:15:07 --> Config Class Initialized
INFO - 2018-07-19 23:15:07 --> Hooks Class Initialized
DEBUG - 2018-07-19 23:15:07 --> UTF-8 Support Enabled
INFO - 2018-07-19 23:15:07 --> Utf8 Class Initialized
INFO - 2018-07-19 23:15:07 --> URI Class Initialized
INFO - 2018-07-19 23:15:07 --> Router Class Initialized
INFO - 2018-07-19 23:15:07 --> Output Class Initialized
INFO - 2018-07-19 23:15:07 --> Security Class Initialized
DEBUG - 2018-07-19 23:15:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-19 23:15:07 --> Input Class Initialized
INFO - 2018-07-19 23:15:07 --> Language Class Initialized
INFO - 2018-07-19 23:15:07 --> Language Class Initialized
INFO - 2018-07-19 23:15:07 --> Config Class Initialized
INFO - 2018-07-19 23:15:07 --> Loader Class Initialized
DEBUG - 2018-07-19 23:15:07 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-19 23:15:07 --> Helper loaded: url_helper
INFO - 2018-07-19 23:15:07 --> Helper loaded: form_helper
INFO - 2018-07-19 23:15:07 --> Helper loaded: date_helper
INFO - 2018-07-19 23:15:07 --> Helper loaded: util_helper
INFO - 2018-07-19 23:15:07 --> Helper loaded: text_helper
INFO - 2018-07-19 23:15:07 --> Helper loaded: string_helper
INFO - 2018-07-19 23:15:07 --> Database Driver Class Initialized
DEBUG - 2018-07-19 23:15:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-19 23:15:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-19 23:15:07 --> Email Class Initialized
INFO - 2018-07-19 23:15:07 --> Controller Class Initialized
DEBUG - 2018-07-19 23:15:07 --> Users MX_Controller Initialized
DEBUG - 2018-07-19 23:15:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-19 23:15:07 --> Helper loaded: file_helper
DEBUG - 2018-07-19 23:15:07 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-19 23:15:07 --> Login MX_Controller Initialized
INFO - 2018-07-19 23:15:07 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-19 23:15:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-19 23:15:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-07-19 23:15:09 --> Config Class Initialized
INFO - 2018-07-19 23:15:09 --> Hooks Class Initialized
DEBUG - 2018-07-19 23:15:09 --> UTF-8 Support Enabled
INFO - 2018-07-19 23:15:09 --> Utf8 Class Initialized
INFO - 2018-07-19 23:15:09 --> URI Class Initialized
INFO - 2018-07-19 23:15:09 --> Router Class Initialized
INFO - 2018-07-19 23:15:09 --> Output Class Initialized
INFO - 2018-07-19 23:15:09 --> Security Class Initialized
DEBUG - 2018-07-19 23:15:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-19 23:15:09 --> Input Class Initialized
INFO - 2018-07-19 23:15:09 --> Language Class Initialized
INFO - 2018-07-19 23:15:09 --> Language Class Initialized
INFO - 2018-07-19 23:15:09 --> Config Class Initialized
INFO - 2018-07-19 23:15:09 --> Loader Class Initialized
DEBUG - 2018-07-19 23:15:09 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-19 23:15:09 --> Helper loaded: url_helper
INFO - 2018-07-19 23:15:09 --> Helper loaded: form_helper
INFO - 2018-07-19 23:15:09 --> Helper loaded: date_helper
INFO - 2018-07-19 23:15:09 --> Helper loaded: util_helper
INFO - 2018-07-19 23:15:09 --> Helper loaded: text_helper
INFO - 2018-07-19 23:15:09 --> Helper loaded: string_helper
INFO - 2018-07-19 23:15:09 --> Database Driver Class Initialized
DEBUG - 2018-07-19 23:15:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-19 23:15:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-19 23:15:09 --> Email Class Initialized
INFO - 2018-07-19 23:15:09 --> Controller Class Initialized
DEBUG - 2018-07-19 23:15:09 --> Users MX_Controller Initialized
DEBUG - 2018-07-19 23:15:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-19 23:15:09 --> Helper loaded: file_helper
DEBUG - 2018-07-19 23:15:09 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-19 23:15:09 --> Login MX_Controller Initialized
INFO - 2018-07-19 23:15:09 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-19 23:15:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-19 23:15:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
DEBUG - 2018-07-19 23:15:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-19 23:15:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-19 23:15:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-19 23:15:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-19 23:15:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-19 23:15:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/create_user.php
INFO - 2018-07-19 23:15:09 --> Final output sent to browser
DEBUG - 2018-07-19 23:15:09 --> Total execution time: 0.2990
INFO - 2018-07-19 23:38:13 --> Config Class Initialized
INFO - 2018-07-19 23:38:13 --> Hooks Class Initialized
DEBUG - 2018-07-19 23:38:13 --> UTF-8 Support Enabled
INFO - 2018-07-19 23:38:13 --> Utf8 Class Initialized
INFO - 2018-07-19 23:38:13 --> URI Class Initialized
INFO - 2018-07-19 23:38:13 --> Router Class Initialized
INFO - 2018-07-19 23:38:13 --> Output Class Initialized
INFO - 2018-07-19 23:38:13 --> Security Class Initialized
DEBUG - 2018-07-19 23:38:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-19 23:38:13 --> Input Class Initialized
INFO - 2018-07-19 23:38:13 --> Language Class Initialized
INFO - 2018-07-19 23:38:13 --> Language Class Initialized
INFO - 2018-07-19 23:38:13 --> Config Class Initialized
INFO - 2018-07-19 23:38:13 --> Loader Class Initialized
DEBUG - 2018-07-19 23:38:13 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-19 23:38:13 --> Helper loaded: url_helper
INFO - 2018-07-19 23:38:13 --> Helper loaded: form_helper
INFO - 2018-07-19 23:38:13 --> Helper loaded: date_helper
INFO - 2018-07-19 23:38:13 --> Helper loaded: util_helper
INFO - 2018-07-19 23:38:13 --> Helper loaded: text_helper
INFO - 2018-07-19 23:38:13 --> Helper loaded: string_helper
INFO - 2018-07-19 23:38:13 --> Database Driver Class Initialized
DEBUG - 2018-07-19 23:38:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-19 23:38:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-19 23:38:13 --> Email Class Initialized
INFO - 2018-07-19 23:38:13 --> Controller Class Initialized
DEBUG - 2018-07-19 23:38:13 --> Users MX_Controller Initialized
DEBUG - 2018-07-19 23:38:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-19 23:38:13 --> Helper loaded: file_helper
DEBUG - 2018-07-19 23:38:13 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-19 23:38:13 --> Login MX_Controller Initialized
INFO - 2018-07-19 23:38:13 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-19 23:38:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-19 23:38:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
DEBUG - 2018-07-19 23:38:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-19 23:38:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-19 23:38:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-19 23:38:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-19 23:38:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-19 23:38:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/create_user.php
INFO - 2018-07-19 23:38:13 --> Final output sent to browser
DEBUG - 2018-07-19 23:38:14 --> Total execution time: 0.3470
INFO - 2018-07-19 23:38:27 --> Config Class Initialized
INFO - 2018-07-19 23:38:27 --> Hooks Class Initialized
DEBUG - 2018-07-19 23:38:27 --> UTF-8 Support Enabled
INFO - 2018-07-19 23:38:27 --> Utf8 Class Initialized
INFO - 2018-07-19 23:38:27 --> URI Class Initialized
INFO - 2018-07-19 23:38:27 --> Router Class Initialized
INFO - 2018-07-19 23:38:27 --> Output Class Initialized
INFO - 2018-07-19 23:38:27 --> Security Class Initialized
DEBUG - 2018-07-19 23:38:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-19 23:38:27 --> Input Class Initialized
INFO - 2018-07-19 23:38:27 --> Language Class Initialized
INFO - 2018-07-19 23:38:27 --> Language Class Initialized
INFO - 2018-07-19 23:38:27 --> Config Class Initialized
INFO - 2018-07-19 23:38:27 --> Loader Class Initialized
DEBUG - 2018-07-19 23:38:27 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-19 23:38:27 --> Helper loaded: url_helper
INFO - 2018-07-19 23:38:27 --> Helper loaded: form_helper
INFO - 2018-07-19 23:38:27 --> Helper loaded: date_helper
INFO - 2018-07-19 23:38:27 --> Helper loaded: util_helper
INFO - 2018-07-19 23:38:27 --> Helper loaded: text_helper
INFO - 2018-07-19 23:38:27 --> Helper loaded: string_helper
INFO - 2018-07-19 23:38:27 --> Database Driver Class Initialized
DEBUG - 2018-07-19 23:38:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-19 23:38:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-19 23:38:27 --> Email Class Initialized
INFO - 2018-07-19 23:38:27 --> Controller Class Initialized
DEBUG - 2018-07-19 23:38:27 --> Home MX_Controller Initialized
DEBUG - 2018-07-19 23:38:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-19 23:38:27 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-19 23:38:27 --> Login MX_Controller Initialized
INFO - 2018-07-19 23:38:27 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-19 23:38:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-19 23:38:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-19 23:38:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-07-19 23:38:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-07-19 23:38:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-07-19 23:38:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-07-19 23:38:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-07-19 23:38:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-07-19 23:38:27 --> Final output sent to browser
DEBUG - 2018-07-19 23:38:28 --> Total execution time: 0.4257
INFO - 2018-07-19 23:38:28 --> Config Class Initialized
INFO - 2018-07-19 23:38:28 --> Hooks Class Initialized
INFO - 2018-07-19 23:38:28 --> Config Class Initialized
INFO - 2018-07-19 23:38:28 --> Hooks Class Initialized
DEBUG - 2018-07-19 23:38:28 --> UTF-8 Support Enabled
INFO - 2018-07-19 23:38:28 --> Utf8 Class Initialized
DEBUG - 2018-07-19 23:38:28 --> UTF-8 Support Enabled
INFO - 2018-07-19 23:38:28 --> Utf8 Class Initialized
INFO - 2018-07-19 23:38:28 --> URI Class Initialized
INFO - 2018-07-19 23:38:28 --> URI Class Initialized
INFO - 2018-07-19 23:38:28 --> Router Class Initialized
INFO - 2018-07-19 23:38:28 --> Router Class Initialized
INFO - 2018-07-19 23:38:28 --> Output Class Initialized
INFO - 2018-07-19 23:38:28 --> Security Class Initialized
DEBUG - 2018-07-19 23:38:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-19 23:38:28 --> Output Class Initialized
INFO - 2018-07-19 23:38:28 --> Input Class Initialized
INFO - 2018-07-19 23:38:28 --> Language Class Initialized
INFO - 2018-07-19 23:38:28 --> Security Class Initialized
DEBUG - 2018-07-19 23:38:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-19 23:38:28 --> Input Class Initialized
ERROR - 2018-07-19 23:38:28 --> 404 Page Not Found: /index
INFO - 2018-07-19 23:38:28 --> Language Class Initialized
ERROR - 2018-07-19 23:38:28 --> 404 Page Not Found: /index
INFO - 2018-07-19 23:38:28 --> Config Class Initialized
INFO - 2018-07-19 23:38:28 --> Hooks Class Initialized
DEBUG - 2018-07-19 23:38:28 --> UTF-8 Support Enabled
INFO - 2018-07-19 23:38:28 --> Utf8 Class Initialized
INFO - 2018-07-19 23:38:28 --> URI Class Initialized
INFO - 2018-07-19 23:38:28 --> Router Class Initialized
INFO - 2018-07-19 23:38:28 --> Output Class Initialized
INFO - 2018-07-19 23:38:28 --> Security Class Initialized
INFO - 2018-07-19 23:38:28 --> Config Class Initialized
INFO - 2018-07-19 23:38:28 --> Hooks Class Initialized
DEBUG - 2018-07-19 23:38:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-19 23:38:28 --> Input Class Initialized
DEBUG - 2018-07-19 23:38:28 --> UTF-8 Support Enabled
INFO - 2018-07-19 23:38:28 --> Language Class Initialized
INFO - 2018-07-19 23:38:28 --> Utf8 Class Initialized
ERROR - 2018-07-19 23:38:28 --> 404 Page Not Found: /index
INFO - 2018-07-19 23:38:28 --> URI Class Initialized
INFO - 2018-07-19 23:38:28 --> Config Class Initialized
INFO - 2018-07-19 23:38:28 --> Hooks Class Initialized
INFO - 2018-07-19 23:38:28 --> Router Class Initialized
DEBUG - 2018-07-19 23:38:28 --> UTF-8 Support Enabled
INFO - 2018-07-19 23:38:28 --> Utf8 Class Initialized
INFO - 2018-07-19 23:38:28 --> Output Class Initialized
INFO - 2018-07-19 23:38:28 --> URI Class Initialized
INFO - 2018-07-19 23:38:28 --> Security Class Initialized
INFO - 2018-07-19 23:38:28 --> Router Class Initialized
DEBUG - 2018-07-19 23:38:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-19 23:38:28 --> Input Class Initialized
INFO - 2018-07-19 23:38:28 --> Output Class Initialized
INFO - 2018-07-19 23:38:28 --> Language Class Initialized
INFO - 2018-07-19 23:38:28 --> Security Class Initialized
DEBUG - 2018-07-19 23:38:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-19 23:38:28 --> Language Class Initialized
INFO - 2018-07-19 23:38:28 --> Input Class Initialized
INFO - 2018-07-19 23:38:28 --> Config Class Initialized
INFO - 2018-07-19 23:38:28 --> Language Class Initialized
INFO - 2018-07-19 23:38:28 --> Loader Class Initialized
DEBUG - 2018-07-19 23:38:28 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
ERROR - 2018-07-19 23:38:28 --> 404 Page Not Found: /index
INFO - 2018-07-19 23:38:28 --> Helper loaded: url_helper
INFO - 2018-07-19 23:38:28 --> Helper loaded: form_helper
INFO - 2018-07-19 23:38:28 --> Helper loaded: date_helper
INFO - 2018-07-19 23:38:28 --> Helper loaded: util_helper
INFO - 2018-07-19 23:38:28 --> Helper loaded: text_helper
INFO - 2018-07-19 23:38:28 --> Helper loaded: string_helper
INFO - 2018-07-19 23:38:28 --> Database Driver Class Initialized
DEBUG - 2018-07-19 23:38:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-19 23:38:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-19 23:38:29 --> Email Class Initialized
INFO - 2018-07-19 23:38:29 --> Controller Class Initialized
DEBUG - 2018-07-19 23:38:29 --> Home MX_Controller Initialized
DEBUG - 2018-07-19 23:38:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-19 23:38:29 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-19 23:38:29 --> Login MX_Controller Initialized
INFO - 2018-07-19 23:38:29 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-19 23:38:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-19 23:38:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-19 23:38:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-07-19 23:38:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-07-19 23:38:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-07-19 23:38:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-07-19 23:38:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-07-19 23:38:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-07-19 23:38:29 --> Final output sent to browser
DEBUG - 2018-07-19 23:38:29 --> Total execution time: 0.4064
INFO - 2018-07-19 23:38:29 --> Config Class Initialized
INFO - 2018-07-19 23:38:29 --> Hooks Class Initialized
DEBUG - 2018-07-19 23:38:29 --> UTF-8 Support Enabled
INFO - 2018-07-19 23:38:29 --> Utf8 Class Initialized
INFO - 2018-07-19 23:38:29 --> Config Class Initialized
INFO - 2018-07-19 23:38:29 --> Hooks Class Initialized
INFO - 2018-07-19 23:38:29 --> URI Class Initialized
DEBUG - 2018-07-19 23:38:29 --> UTF-8 Support Enabled
INFO - 2018-07-19 23:38:29 --> Router Class Initialized
INFO - 2018-07-19 23:38:29 --> Utf8 Class Initialized
INFO - 2018-07-19 23:38:29 --> URI Class Initialized
INFO - 2018-07-19 23:38:29 --> Router Class Initialized
INFO - 2018-07-19 23:38:29 --> Output Class Initialized
INFO - 2018-07-19 23:38:29 --> Security Class Initialized
DEBUG - 2018-07-19 23:38:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-19 23:38:29 --> Input Class Initialized
INFO - 2018-07-19 23:38:29 --> Language Class Initialized
ERROR - 2018-07-19 23:38:29 --> 404 Page Not Found: /index
INFO - 2018-07-19 23:38:29 --> Output Class Initialized
INFO - 2018-07-19 23:38:29 --> Config Class Initialized
INFO - 2018-07-19 23:38:29 --> Hooks Class Initialized
INFO - 2018-07-19 23:38:29 --> Security Class Initialized
DEBUG - 2018-07-19 23:38:29 --> UTF-8 Support Enabled
DEBUG - 2018-07-19 23:38:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-19 23:38:29 --> Utf8 Class Initialized
INFO - 2018-07-19 23:38:29 --> Input Class Initialized
INFO - 2018-07-19 23:38:29 --> Language Class Initialized
INFO - 2018-07-19 23:38:29 --> URI Class Initialized
ERROR - 2018-07-19 23:38:29 --> 404 Page Not Found: /index
INFO - 2018-07-19 23:38:29 --> Router Class Initialized
INFO - 2018-07-19 23:38:29 --> Output Class Initialized
INFO - 2018-07-19 23:38:29 --> Security Class Initialized
DEBUG - 2018-07-19 23:38:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-19 23:38:29 --> Input Class Initialized
INFO - 2018-07-19 23:38:29 --> Language Class Initialized
ERROR - 2018-07-19 23:38:29 --> 404 Page Not Found: /index
INFO - 2018-07-19 23:38:29 --> Config Class Initialized
INFO - 2018-07-19 23:38:29 --> Hooks Class Initialized
DEBUG - 2018-07-19 23:38:29 --> UTF-8 Support Enabled
INFO - 2018-07-19 23:38:29 --> Utf8 Class Initialized
INFO - 2018-07-19 23:38:29 --> URI Class Initialized
INFO - 2018-07-19 23:38:29 --> Router Class Initialized
INFO - 2018-07-19 23:38:29 --> Output Class Initialized
INFO - 2018-07-19 23:38:29 --> Security Class Initialized
DEBUG - 2018-07-19 23:38:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-19 23:38:29 --> Input Class Initialized
INFO - 2018-07-19 23:38:29 --> Language Class Initialized
ERROR - 2018-07-19 23:38:29 --> 404 Page Not Found: /index
INFO - 2018-07-19 23:38:32 --> Config Class Initialized
INFO - 2018-07-19 23:38:32 --> Hooks Class Initialized
DEBUG - 2018-07-19 23:38:32 --> UTF-8 Support Enabled
INFO - 2018-07-19 23:38:32 --> Utf8 Class Initialized
INFO - 2018-07-19 23:38:33 --> URI Class Initialized
INFO - 2018-07-19 23:38:33 --> Router Class Initialized
INFO - 2018-07-19 23:38:33 --> Output Class Initialized
INFO - 2018-07-19 23:38:33 --> Security Class Initialized
DEBUG - 2018-07-19 23:38:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-19 23:38:33 --> Input Class Initialized
INFO - 2018-07-19 23:38:33 --> Language Class Initialized
ERROR - 2018-07-19 23:38:33 --> 404 Page Not Found: /index
INFO - 2018-07-19 23:38:33 --> Config Class Initialized
INFO - 2018-07-19 23:38:33 --> Hooks Class Initialized
DEBUG - 2018-07-19 23:38:33 --> UTF-8 Support Enabled
INFO - 2018-07-19 23:38:33 --> Utf8 Class Initialized
INFO - 2018-07-19 23:38:33 --> URI Class Initialized
INFO - 2018-07-19 23:38:33 --> Router Class Initialized
INFO - 2018-07-19 23:38:33 --> Output Class Initialized
INFO - 2018-07-19 23:38:33 --> Security Class Initialized
DEBUG - 2018-07-19 23:38:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-19 23:38:33 --> Input Class Initialized
INFO - 2018-07-19 23:38:33 --> Language Class Initialized
ERROR - 2018-07-19 23:38:33 --> 404 Page Not Found: /index
INFO - 2018-07-19 23:38:33 --> Config Class Initialized
INFO - 2018-07-19 23:38:33 --> Hooks Class Initialized
DEBUG - 2018-07-19 23:38:33 --> UTF-8 Support Enabled
INFO - 2018-07-19 23:38:33 --> Utf8 Class Initialized
INFO - 2018-07-19 23:38:33 --> URI Class Initialized
INFO - 2018-07-19 23:38:33 --> Router Class Initialized
INFO - 2018-07-19 23:38:33 --> Output Class Initialized
INFO - 2018-07-19 23:38:33 --> Security Class Initialized
DEBUG - 2018-07-19 23:38:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-19 23:38:33 --> Input Class Initialized
INFO - 2018-07-19 23:38:33 --> Language Class Initialized
ERROR - 2018-07-19 23:38:33 --> 404 Page Not Found: /index
INFO - 2018-07-19 23:45:30 --> Config Class Initialized
INFO - 2018-07-19 23:45:30 --> Hooks Class Initialized
DEBUG - 2018-07-19 23:45:30 --> UTF-8 Support Enabled
INFO - 2018-07-19 23:45:30 --> Utf8 Class Initialized
INFO - 2018-07-19 23:45:30 --> URI Class Initialized
INFO - 2018-07-19 23:45:30 --> Router Class Initialized
INFO - 2018-07-19 23:45:30 --> Output Class Initialized
INFO - 2018-07-19 23:45:30 --> Security Class Initialized
DEBUG - 2018-07-19 23:45:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-19 23:45:30 --> Input Class Initialized
INFO - 2018-07-19 23:45:30 --> Language Class Initialized
INFO - 2018-07-19 23:45:30 --> Language Class Initialized
INFO - 2018-07-19 23:45:30 --> Config Class Initialized
INFO - 2018-07-19 23:45:30 --> Loader Class Initialized
DEBUG - 2018-07-19 23:45:30 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-19 23:45:30 --> Helper loaded: url_helper
INFO - 2018-07-19 23:45:30 --> Helper loaded: form_helper
INFO - 2018-07-19 23:45:30 --> Helper loaded: date_helper
INFO - 2018-07-19 23:45:30 --> Helper loaded: util_helper
INFO - 2018-07-19 23:45:30 --> Helper loaded: text_helper
INFO - 2018-07-19 23:45:30 --> Helper loaded: string_helper
INFO - 2018-07-19 23:45:30 --> Database Driver Class Initialized
DEBUG - 2018-07-19 23:45:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-19 23:45:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-19 23:45:30 --> Email Class Initialized
INFO - 2018-07-19 23:45:30 --> Controller Class Initialized
DEBUG - 2018-07-19 23:45:30 --> Users MX_Controller Initialized
DEBUG - 2018-07-19 23:45:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-19 23:45:30 --> Helper loaded: file_helper
DEBUG - 2018-07-19 23:45:30 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-19 23:45:30 --> Login MX_Controller Initialized
INFO - 2018-07-19 23:45:30 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-19 23:45:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-19 23:45:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
DEBUG - 2018-07-19 23:45:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-19 23:45:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-19 23:45:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-19 23:45:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-19 23:45:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-19 23:45:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/create_user.php
INFO - 2018-07-19 23:45:30 --> Final output sent to browser
DEBUG - 2018-07-19 23:45:30 --> Total execution time: 0.2993
INFO - 2018-07-19 23:45:34 --> Config Class Initialized
INFO - 2018-07-19 23:45:34 --> Hooks Class Initialized
DEBUG - 2018-07-19 23:45:34 --> UTF-8 Support Enabled
INFO - 2018-07-19 23:45:34 --> Utf8 Class Initialized
INFO - 2018-07-19 23:45:34 --> URI Class Initialized
INFO - 2018-07-19 23:45:34 --> Router Class Initialized
INFO - 2018-07-19 23:45:34 --> Output Class Initialized
INFO - 2018-07-19 23:45:34 --> Security Class Initialized
DEBUG - 2018-07-19 23:45:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-19 23:45:34 --> Input Class Initialized
INFO - 2018-07-19 23:45:34 --> Language Class Initialized
INFO - 2018-07-19 23:45:34 --> Language Class Initialized
INFO - 2018-07-19 23:45:34 --> Config Class Initialized
INFO - 2018-07-19 23:45:34 --> Loader Class Initialized
DEBUG - 2018-07-19 23:45:34 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-19 23:45:34 --> Helper loaded: url_helper
INFO - 2018-07-19 23:45:34 --> Helper loaded: form_helper
INFO - 2018-07-19 23:45:34 --> Helper loaded: date_helper
INFO - 2018-07-19 23:45:34 --> Helper loaded: util_helper
INFO - 2018-07-19 23:45:34 --> Helper loaded: text_helper
INFO - 2018-07-19 23:45:34 --> Helper loaded: string_helper
INFO - 2018-07-19 23:45:34 --> Database Driver Class Initialized
DEBUG - 2018-07-19 23:45:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-19 23:45:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-19 23:45:34 --> Email Class Initialized
INFO - 2018-07-19 23:45:34 --> Controller Class Initialized
DEBUG - 2018-07-19 23:45:34 --> Users MX_Controller Initialized
DEBUG - 2018-07-19 23:45:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-19 23:45:34 --> Helper loaded: file_helper
DEBUG - 2018-07-19 23:45:34 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-19 23:45:34 --> Login MX_Controller Initialized
INFO - 2018-07-19 23:45:34 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-19 23:45:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-19 23:45:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
DEBUG - 2018-07-19 23:45:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-19 23:45:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-19 23:45:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-19 23:45:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-19 23:45:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-19 23:45:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/create_user.php
INFO - 2018-07-19 23:45:34 --> Final output sent to browser
DEBUG - 2018-07-19 23:45:34 --> Total execution time: 0.2580
INFO - 2018-07-19 23:45:37 --> Config Class Initialized
INFO - 2018-07-19 23:45:37 --> Hooks Class Initialized
DEBUG - 2018-07-19 23:45:37 --> UTF-8 Support Enabled
INFO - 2018-07-19 23:45:37 --> Utf8 Class Initialized
INFO - 2018-07-19 23:45:37 --> URI Class Initialized
INFO - 2018-07-19 23:45:37 --> Router Class Initialized
INFO - 2018-07-19 23:45:37 --> Output Class Initialized
INFO - 2018-07-19 23:45:37 --> Security Class Initialized
DEBUG - 2018-07-19 23:45:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-19 23:45:37 --> Input Class Initialized
INFO - 2018-07-19 23:45:37 --> Language Class Initialized
INFO - 2018-07-19 23:45:37 --> Language Class Initialized
INFO - 2018-07-19 23:45:37 --> Config Class Initialized
INFO - 2018-07-19 23:45:37 --> Loader Class Initialized
DEBUG - 2018-07-19 23:45:37 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-19 23:45:37 --> Helper loaded: url_helper
INFO - 2018-07-19 23:45:37 --> Helper loaded: form_helper
INFO - 2018-07-19 23:45:37 --> Helper loaded: date_helper
INFO - 2018-07-19 23:45:37 --> Helper loaded: util_helper
INFO - 2018-07-19 23:45:37 --> Helper loaded: text_helper
INFO - 2018-07-19 23:45:37 --> Helper loaded: string_helper
INFO - 2018-07-19 23:45:37 --> Database Driver Class Initialized
DEBUG - 2018-07-19 23:45:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-19 23:45:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-19 23:45:37 --> Email Class Initialized
INFO - 2018-07-19 23:45:37 --> Controller Class Initialized
DEBUG - 2018-07-19 23:45:37 --> Users MX_Controller Initialized
DEBUG - 2018-07-19 23:45:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-19 23:45:37 --> Helper loaded: file_helper
DEBUG - 2018-07-19 23:45:37 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-19 23:45:37 --> Login MX_Controller Initialized
INFO - 2018-07-19 23:45:37 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-19 23:45:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-19 23:45:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
DEBUG - 2018-07-19 23:45:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-19 23:45:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-19 23:45:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-19 23:45:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-19 23:45:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-19 23:45:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/create_user.php
INFO - 2018-07-19 23:45:37 --> Final output sent to browser
DEBUG - 2018-07-19 23:45:37 --> Total execution time: 0.2609
INFO - 2018-07-19 23:45:44 --> Config Class Initialized
INFO - 2018-07-19 23:45:44 --> Hooks Class Initialized
DEBUG - 2018-07-19 23:45:44 --> UTF-8 Support Enabled
INFO - 2018-07-19 23:45:44 --> Utf8 Class Initialized
INFO - 2018-07-19 23:45:44 --> URI Class Initialized
INFO - 2018-07-19 23:45:44 --> Router Class Initialized
INFO - 2018-07-19 23:45:44 --> Output Class Initialized
INFO - 2018-07-19 23:45:44 --> Security Class Initialized
DEBUG - 2018-07-19 23:45:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-19 23:45:44 --> Input Class Initialized
INFO - 2018-07-19 23:45:44 --> Language Class Initialized
INFO - 2018-07-19 23:45:44 --> Language Class Initialized
INFO - 2018-07-19 23:45:44 --> Config Class Initialized
INFO - 2018-07-19 23:45:44 --> Loader Class Initialized
DEBUG - 2018-07-19 23:45:44 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-19 23:45:44 --> Helper loaded: url_helper
INFO - 2018-07-19 23:45:44 --> Helper loaded: form_helper
INFO - 2018-07-19 23:45:45 --> Helper loaded: date_helper
INFO - 2018-07-19 23:45:45 --> Helper loaded: util_helper
INFO - 2018-07-19 23:45:45 --> Helper loaded: text_helper
INFO - 2018-07-19 23:45:45 --> Helper loaded: string_helper
INFO - 2018-07-19 23:45:45 --> Database Driver Class Initialized
DEBUG - 2018-07-19 23:45:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-19 23:45:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-19 23:45:45 --> Email Class Initialized
INFO - 2018-07-19 23:45:45 --> Controller Class Initialized
DEBUG - 2018-07-19 23:45:45 --> Users MX_Controller Initialized
DEBUG - 2018-07-19 23:45:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-19 23:45:45 --> Helper loaded: file_helper
DEBUG - 2018-07-19 23:45:45 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-19 23:45:45 --> Login MX_Controller Initialized
INFO - 2018-07-19 23:45:45 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-19 23:45:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-19 23:45:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
DEBUG - 2018-07-19 23:45:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-19 23:45:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-19 23:45:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-19 23:45:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-19 23:45:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-19 23:45:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/create_user.php
INFO - 2018-07-19 23:45:45 --> Final output sent to browser
DEBUG - 2018-07-19 23:45:45 --> Total execution time: 0.2589
INFO - 2018-07-19 23:45:52 --> Config Class Initialized
INFO - 2018-07-19 23:45:52 --> Hooks Class Initialized
DEBUG - 2018-07-19 23:45:52 --> UTF-8 Support Enabled
INFO - 2018-07-19 23:45:52 --> Utf8 Class Initialized
INFO - 2018-07-19 23:45:52 --> URI Class Initialized
INFO - 2018-07-19 23:45:52 --> Router Class Initialized
INFO - 2018-07-19 23:45:52 --> Output Class Initialized
INFO - 2018-07-19 23:45:52 --> Security Class Initialized
DEBUG - 2018-07-19 23:45:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-19 23:45:52 --> Input Class Initialized
INFO - 2018-07-19 23:45:52 --> Language Class Initialized
INFO - 2018-07-19 23:45:52 --> Language Class Initialized
INFO - 2018-07-19 23:45:52 --> Config Class Initialized
INFO - 2018-07-19 23:45:52 --> Loader Class Initialized
DEBUG - 2018-07-19 23:45:52 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-19 23:45:52 --> Helper loaded: url_helper
INFO - 2018-07-19 23:45:52 --> Helper loaded: form_helper
INFO - 2018-07-19 23:45:52 --> Helper loaded: date_helper
INFO - 2018-07-19 23:45:52 --> Helper loaded: util_helper
INFO - 2018-07-19 23:45:52 --> Helper loaded: text_helper
INFO - 2018-07-19 23:45:52 --> Helper loaded: string_helper
INFO - 2018-07-19 23:45:52 --> Database Driver Class Initialized
DEBUG - 2018-07-19 23:45:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-19 23:45:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-19 23:45:52 --> Email Class Initialized
INFO - 2018-07-19 23:45:52 --> Controller Class Initialized
DEBUG - 2018-07-19 23:45:52 --> Users MX_Controller Initialized
DEBUG - 2018-07-19 23:45:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-19 23:45:52 --> Helper loaded: file_helper
DEBUG - 2018-07-19 23:45:52 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-19 23:45:52 --> Login MX_Controller Initialized
INFO - 2018-07-19 23:45:52 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-19 23:45:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-19 23:45:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
DEBUG - 2018-07-19 23:45:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-19 23:45:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-19 23:45:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-19 23:45:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-19 23:45:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-19 23:45:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/create_user.php
INFO - 2018-07-19 23:45:52 --> Final output sent to browser
DEBUG - 2018-07-19 23:45:52 --> Total execution time: 0.2531
