<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-07-21 01:58:43 --> Config Class Initialized
INFO - 2018-07-21 01:58:43 --> Hooks Class Initialized
DEBUG - 2018-07-21 01:58:43 --> UTF-8 Support Enabled
INFO - 2018-07-21 01:58:43 --> Utf8 Class Initialized
INFO - 2018-07-21 01:58:43 --> URI Class Initialized
INFO - 2018-07-21 01:58:43 --> Router Class Initialized
INFO - 2018-07-21 01:58:43 --> Output Class Initialized
INFO - 2018-07-21 01:58:43 --> Security Class Initialized
DEBUG - 2018-07-21 01:58:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 01:58:43 --> Input Class Initialized
INFO - 2018-07-21 01:58:43 --> Language Class Initialized
INFO - 2018-07-21 01:58:43 --> Language Class Initialized
INFO - 2018-07-21 01:58:43 --> Config Class Initialized
INFO - 2018-07-21 01:58:43 --> Loader Class Initialized
DEBUG - 2018-07-21 01:58:43 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-21 01:58:43 --> Helper loaded: url_helper
INFO - 2018-07-21 01:58:43 --> Helper loaded: form_helper
INFO - 2018-07-21 01:58:43 --> Helper loaded: date_helper
INFO - 2018-07-21 01:58:43 --> Helper loaded: util_helper
INFO - 2018-07-21 01:58:43 --> Helper loaded: text_helper
INFO - 2018-07-21 01:58:43 --> Helper loaded: string_helper
INFO - 2018-07-21 01:58:43 --> Database Driver Class Initialized
DEBUG - 2018-07-21 01:58:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-21 01:58:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-21 01:58:43 --> Email Class Initialized
INFO - 2018-07-21 01:58:43 --> Controller Class Initialized
DEBUG - 2018-07-21 01:58:43 --> Users MX_Controller Initialized
DEBUG - 2018-07-21 01:58:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-21 01:58:43 --> Helper loaded: file_helper
DEBUG - 2018-07-21 01:58:43 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-21 01:58:43 --> Login MX_Controller Initialized
INFO - 2018-07-21 01:58:43 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-21 01:58:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-21 01:58:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/logins/login.php
INFO - 2018-07-21 01:59:24 --> Config Class Initialized
INFO - 2018-07-21 01:59:24 --> Hooks Class Initialized
DEBUG - 2018-07-21 01:59:24 --> UTF-8 Support Enabled
INFO - 2018-07-21 01:59:24 --> Utf8 Class Initialized
INFO - 2018-07-21 01:59:24 --> URI Class Initialized
INFO - 2018-07-21 01:59:24 --> Router Class Initialized
INFO - 2018-07-21 01:59:24 --> Output Class Initialized
INFO - 2018-07-21 01:59:24 --> Security Class Initialized
DEBUG - 2018-07-21 01:59:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 01:59:24 --> Input Class Initialized
INFO - 2018-07-21 01:59:24 --> Language Class Initialized
INFO - 2018-07-21 01:59:24 --> Language Class Initialized
INFO - 2018-07-21 01:59:24 --> Config Class Initialized
INFO - 2018-07-21 01:59:24 --> Loader Class Initialized
DEBUG - 2018-07-21 01:59:24 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-21 01:59:24 --> Helper loaded: url_helper
INFO - 2018-07-21 01:59:24 --> Helper loaded: form_helper
INFO - 2018-07-21 01:59:24 --> Helper loaded: date_helper
INFO - 2018-07-21 01:59:24 --> Helper loaded: util_helper
INFO - 2018-07-21 01:59:24 --> Helper loaded: text_helper
INFO - 2018-07-21 01:59:24 --> Helper loaded: string_helper
INFO - 2018-07-21 01:59:24 --> Database Driver Class Initialized
DEBUG - 2018-07-21 01:59:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-21 01:59:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-21 01:59:24 --> Email Class Initialized
INFO - 2018-07-21 01:59:24 --> Controller Class Initialized
DEBUG - 2018-07-21 01:59:24 --> Users MX_Controller Initialized
DEBUG - 2018-07-21 01:59:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-21 01:59:24 --> Helper loaded: file_helper
DEBUG - 2018-07-21 01:59:24 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-21 01:59:24 --> Login MX_Controller Initialized
INFO - 2018-07-21 01:59:24 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-21 01:59:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-21 01:59:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/logins/login.php
INFO - 2018-07-21 01:59:27 --> Config Class Initialized
INFO - 2018-07-21 01:59:27 --> Hooks Class Initialized
DEBUG - 2018-07-21 01:59:27 --> UTF-8 Support Enabled
INFO - 2018-07-21 01:59:27 --> Utf8 Class Initialized
INFO - 2018-07-21 01:59:27 --> URI Class Initialized
INFO - 2018-07-21 01:59:27 --> Router Class Initialized
INFO - 2018-07-21 01:59:27 --> Output Class Initialized
INFO - 2018-07-21 01:59:27 --> Security Class Initialized
DEBUG - 2018-07-21 01:59:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 01:59:27 --> Input Class Initialized
INFO - 2018-07-21 01:59:27 --> Language Class Initialized
INFO - 2018-07-21 01:59:27 --> Language Class Initialized
INFO - 2018-07-21 01:59:27 --> Config Class Initialized
INFO - 2018-07-21 01:59:27 --> Loader Class Initialized
DEBUG - 2018-07-21 01:59:27 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-21 01:59:27 --> Helper loaded: url_helper
INFO - 2018-07-21 01:59:27 --> Helper loaded: form_helper
INFO - 2018-07-21 01:59:27 --> Helper loaded: date_helper
INFO - 2018-07-21 01:59:27 --> Helper loaded: util_helper
INFO - 2018-07-21 01:59:27 --> Helper loaded: text_helper
INFO - 2018-07-21 01:59:27 --> Helper loaded: string_helper
INFO - 2018-07-21 01:59:27 --> Database Driver Class Initialized
DEBUG - 2018-07-21 01:59:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-21 01:59:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-21 01:59:27 --> Email Class Initialized
INFO - 2018-07-21 01:59:27 --> Controller Class Initialized
DEBUG - 2018-07-21 01:59:27 --> Users MX_Controller Initialized
DEBUG - 2018-07-21 01:59:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-21 01:59:27 --> Helper loaded: file_helper
DEBUG - 2018-07-21 01:59:27 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-21 01:59:27 --> Login MX_Controller Initialized
INFO - 2018-07-21 01:59:27 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-21 01:59:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-21 01:59:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/logins/login.php
INFO - 2018-07-21 01:59:38 --> Config Class Initialized
INFO - 2018-07-21 01:59:38 --> Hooks Class Initialized
DEBUG - 2018-07-21 01:59:38 --> UTF-8 Support Enabled
INFO - 2018-07-21 01:59:38 --> Utf8 Class Initialized
INFO - 2018-07-21 01:59:38 --> URI Class Initialized
INFO - 2018-07-21 01:59:38 --> Router Class Initialized
INFO - 2018-07-21 01:59:38 --> Output Class Initialized
INFO - 2018-07-21 01:59:38 --> Security Class Initialized
DEBUG - 2018-07-21 01:59:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 01:59:38 --> Input Class Initialized
INFO - 2018-07-21 01:59:38 --> Language Class Initialized
INFO - 2018-07-21 01:59:38 --> Language Class Initialized
INFO - 2018-07-21 01:59:38 --> Config Class Initialized
INFO - 2018-07-21 01:59:38 --> Loader Class Initialized
DEBUG - 2018-07-21 01:59:38 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-21 01:59:38 --> Helper loaded: url_helper
INFO - 2018-07-21 01:59:38 --> Helper loaded: form_helper
INFO - 2018-07-21 01:59:38 --> Helper loaded: date_helper
INFO - 2018-07-21 01:59:38 --> Helper loaded: util_helper
INFO - 2018-07-21 01:59:38 --> Helper loaded: text_helper
INFO - 2018-07-21 01:59:38 --> Helper loaded: string_helper
INFO - 2018-07-21 01:59:38 --> Database Driver Class Initialized
DEBUG - 2018-07-21 01:59:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-21 01:59:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-21 01:59:38 --> Email Class Initialized
INFO - 2018-07-21 01:59:38 --> Controller Class Initialized
DEBUG - 2018-07-21 01:59:38 --> Users MX_Controller Initialized
DEBUG - 2018-07-21 01:59:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-21 01:59:38 --> Helper loaded: file_helper
DEBUG - 2018-07-21 01:59:38 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-21 01:59:38 --> Login MX_Controller Initialized
INFO - 2018-07-21 01:59:38 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-21 01:59:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-21 01:59:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/logins/login.php
INFO - 2018-07-21 01:59:44 --> Config Class Initialized
INFO - 2018-07-21 01:59:44 --> Hooks Class Initialized
DEBUG - 2018-07-21 01:59:44 --> UTF-8 Support Enabled
INFO - 2018-07-21 01:59:44 --> Utf8 Class Initialized
INFO - 2018-07-21 01:59:44 --> URI Class Initialized
INFO - 2018-07-21 01:59:44 --> Router Class Initialized
INFO - 2018-07-21 01:59:44 --> Output Class Initialized
INFO - 2018-07-21 01:59:44 --> Security Class Initialized
DEBUG - 2018-07-21 01:59:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 01:59:45 --> Input Class Initialized
INFO - 2018-07-21 01:59:45 --> Language Class Initialized
INFO - 2018-07-21 01:59:45 --> Language Class Initialized
INFO - 2018-07-21 01:59:45 --> Config Class Initialized
INFO - 2018-07-21 01:59:45 --> Loader Class Initialized
DEBUG - 2018-07-21 01:59:45 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-21 01:59:45 --> Helper loaded: url_helper
INFO - 2018-07-21 01:59:45 --> Helper loaded: form_helper
INFO - 2018-07-21 01:59:45 --> Helper loaded: date_helper
INFO - 2018-07-21 01:59:45 --> Helper loaded: util_helper
INFO - 2018-07-21 01:59:45 --> Helper loaded: text_helper
INFO - 2018-07-21 01:59:45 --> Helper loaded: string_helper
INFO - 2018-07-21 01:59:45 --> Database Driver Class Initialized
DEBUG - 2018-07-21 01:59:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-21 01:59:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-21 01:59:45 --> Email Class Initialized
INFO - 2018-07-21 01:59:45 --> Controller Class Initialized
DEBUG - 2018-07-21 01:59:45 --> Users MX_Controller Initialized
DEBUG - 2018-07-21 01:59:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-21 01:59:45 --> Helper loaded: file_helper
DEBUG - 2018-07-21 01:59:45 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-21 01:59:45 --> Login MX_Controller Initialized
INFO - 2018-07-21 01:59:45 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-21 01:59:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-21 01:59:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/logins/login.php
INFO - 2018-07-21 01:59:45 --> Config Class Initialized
INFO - 2018-07-21 01:59:45 --> Hooks Class Initialized
DEBUG - 2018-07-21 01:59:45 --> UTF-8 Support Enabled
INFO - 2018-07-21 01:59:45 --> Utf8 Class Initialized
INFO - 2018-07-21 01:59:45 --> URI Class Initialized
INFO - 2018-07-21 01:59:45 --> Router Class Initialized
INFO - 2018-07-21 01:59:45 --> Output Class Initialized
INFO - 2018-07-21 01:59:45 --> Security Class Initialized
DEBUG - 2018-07-21 01:59:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 01:59:45 --> Input Class Initialized
INFO - 2018-07-21 01:59:45 --> Language Class Initialized
ERROR - 2018-07-21 01:59:45 --> 404 Page Not Found: /index
INFO - 2018-07-21 01:59:50 --> Config Class Initialized
INFO - 2018-07-21 01:59:50 --> Hooks Class Initialized
DEBUG - 2018-07-21 01:59:50 --> UTF-8 Support Enabled
INFO - 2018-07-21 01:59:50 --> Utf8 Class Initialized
INFO - 2018-07-21 01:59:50 --> URI Class Initialized
INFO - 2018-07-21 01:59:50 --> Router Class Initialized
INFO - 2018-07-21 01:59:50 --> Output Class Initialized
INFO - 2018-07-21 01:59:50 --> Security Class Initialized
DEBUG - 2018-07-21 01:59:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 01:59:50 --> Input Class Initialized
INFO - 2018-07-21 01:59:50 --> Language Class Initialized
INFO - 2018-07-21 01:59:50 --> Language Class Initialized
INFO - 2018-07-21 01:59:50 --> Config Class Initialized
INFO - 2018-07-21 01:59:50 --> Loader Class Initialized
DEBUG - 2018-07-21 01:59:50 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-21 01:59:50 --> Helper loaded: url_helper
INFO - 2018-07-21 01:59:50 --> Helper loaded: form_helper
INFO - 2018-07-21 01:59:50 --> Helper loaded: date_helper
INFO - 2018-07-21 01:59:50 --> Helper loaded: util_helper
INFO - 2018-07-21 01:59:50 --> Helper loaded: text_helper
INFO - 2018-07-21 01:59:50 --> Helper loaded: string_helper
INFO - 2018-07-21 01:59:50 --> Database Driver Class Initialized
DEBUG - 2018-07-21 01:59:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-21 01:59:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-21 01:59:50 --> Email Class Initialized
INFO - 2018-07-21 01:59:50 --> Controller Class Initialized
DEBUG - 2018-07-21 01:59:50 --> Login MX_Controller Initialized
INFO - 2018-07-21 01:59:50 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-21 01:59:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-21 01:59:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-21 01:59:50 --> Email starts for admin@colin.com fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-07-21 01:59:50 --> User session created for 1
INFO - 2018-07-21 01:59:50 --> Login status admin@colin.com - success
INFO - 2018-07-21 01:59:50 --> Final output sent to browser
DEBUG - 2018-07-21 01:59:50 --> Total execution time: 0.3298
INFO - 2018-07-21 01:59:50 --> Config Class Initialized
INFO - 2018-07-21 01:59:50 --> Hooks Class Initialized
DEBUG - 2018-07-21 01:59:50 --> UTF-8 Support Enabled
INFO - 2018-07-21 01:59:50 --> Utf8 Class Initialized
INFO - 2018-07-21 01:59:50 --> URI Class Initialized
INFO - 2018-07-21 01:59:50 --> Router Class Initialized
INFO - 2018-07-21 01:59:50 --> Output Class Initialized
INFO - 2018-07-21 01:59:50 --> Security Class Initialized
DEBUG - 2018-07-21 01:59:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 01:59:50 --> Input Class Initialized
INFO - 2018-07-21 01:59:50 --> Language Class Initialized
INFO - 2018-07-21 01:59:50 --> Language Class Initialized
INFO - 2018-07-21 01:59:50 --> Config Class Initialized
INFO - 2018-07-21 01:59:50 --> Loader Class Initialized
DEBUG - 2018-07-21 01:59:50 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-21 01:59:50 --> Helper loaded: url_helper
INFO - 2018-07-21 01:59:51 --> Helper loaded: form_helper
INFO - 2018-07-21 01:59:51 --> Helper loaded: date_helper
INFO - 2018-07-21 01:59:51 --> Helper loaded: util_helper
INFO - 2018-07-21 01:59:51 --> Helper loaded: text_helper
INFO - 2018-07-21 01:59:51 --> Helper loaded: string_helper
INFO - 2018-07-21 01:59:51 --> Database Driver Class Initialized
DEBUG - 2018-07-21 01:59:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-21 01:59:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-21 01:59:51 --> Email Class Initialized
INFO - 2018-07-21 01:59:51 --> Controller Class Initialized
DEBUG - 2018-07-21 01:59:51 --> Users MX_Controller Initialized
DEBUG - 2018-07-21 01:59:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-21 01:59:51 --> Helper loaded: file_helper
DEBUG - 2018-07-21 01:59:51 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-21 01:59:51 --> Login MX_Controller Initialized
INFO - 2018-07-21 01:59:51 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-21 01:59:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-21 01:59:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
DEBUG - 2018-07-21 01:59:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-21 01:59:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-21 01:59:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-21 01:59:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-21 01:59:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-21 01:59:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-21 01:59:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/create_user.php
INFO - 2018-07-21 01:59:51 --> Final output sent to browser
DEBUG - 2018-07-21 01:59:51 --> Total execution time: 0.4151
INFO - 2018-07-21 02:00:27 --> Config Class Initialized
INFO - 2018-07-21 02:00:27 --> Hooks Class Initialized
DEBUG - 2018-07-21 02:00:28 --> UTF-8 Support Enabled
INFO - 2018-07-21 02:00:28 --> Utf8 Class Initialized
INFO - 2018-07-21 02:00:28 --> URI Class Initialized
INFO - 2018-07-21 02:00:28 --> Router Class Initialized
INFO - 2018-07-21 02:00:28 --> Output Class Initialized
INFO - 2018-07-21 02:00:28 --> Security Class Initialized
DEBUG - 2018-07-21 02:00:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 02:00:28 --> Input Class Initialized
INFO - 2018-07-21 02:00:28 --> Language Class Initialized
INFO - 2018-07-21 02:00:28 --> Language Class Initialized
INFO - 2018-07-21 02:00:28 --> Config Class Initialized
INFO - 2018-07-21 02:00:28 --> Loader Class Initialized
DEBUG - 2018-07-21 02:00:28 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-21 02:00:28 --> Helper loaded: url_helper
INFO - 2018-07-21 02:00:28 --> Helper loaded: form_helper
INFO - 2018-07-21 02:00:28 --> Helper loaded: date_helper
INFO - 2018-07-21 02:00:28 --> Helper loaded: util_helper
INFO - 2018-07-21 02:00:28 --> Helper loaded: text_helper
INFO - 2018-07-21 02:00:28 --> Helper loaded: string_helper
INFO - 2018-07-21 02:00:28 --> Database Driver Class Initialized
DEBUG - 2018-07-21 02:00:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-21 02:00:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-21 02:00:28 --> Email Class Initialized
INFO - 2018-07-21 02:00:28 --> Controller Class Initialized
DEBUG - 2018-07-21 02:00:28 --> Users MX_Controller Initialized
DEBUG - 2018-07-21 02:00:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-21 02:00:28 --> Helper loaded: file_helper
DEBUG - 2018-07-21 02:00:28 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-21 02:00:28 --> Login MX_Controller Initialized
INFO - 2018-07-21 02:00:28 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-21 02:00:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-21 02:00:28 --> Final output sent to browser
DEBUG - 2018-07-21 02:00:28 --> Total execution time: 0.3355
INFO - 2018-07-21 02:00:32 --> Config Class Initialized
INFO - 2018-07-21 02:00:32 --> Hooks Class Initialized
DEBUG - 2018-07-21 02:00:32 --> UTF-8 Support Enabled
INFO - 2018-07-21 02:00:32 --> Utf8 Class Initialized
INFO - 2018-07-21 02:00:32 --> URI Class Initialized
INFO - 2018-07-21 02:00:32 --> Router Class Initialized
INFO - 2018-07-21 02:00:32 --> Output Class Initialized
INFO - 2018-07-21 02:00:32 --> Security Class Initialized
DEBUG - 2018-07-21 02:00:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 02:00:32 --> Input Class Initialized
INFO - 2018-07-21 02:00:32 --> Language Class Initialized
INFO - 2018-07-21 02:00:32 --> Language Class Initialized
INFO - 2018-07-21 02:00:32 --> Config Class Initialized
INFO - 2018-07-21 02:00:32 --> Loader Class Initialized
DEBUG - 2018-07-21 02:00:32 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-21 02:00:32 --> Helper loaded: url_helper
INFO - 2018-07-21 02:00:32 --> Helper loaded: form_helper
INFO - 2018-07-21 02:00:32 --> Helper loaded: date_helper
INFO - 2018-07-21 02:00:32 --> Helper loaded: util_helper
INFO - 2018-07-21 02:00:32 --> Helper loaded: text_helper
INFO - 2018-07-21 02:00:32 --> Helper loaded: string_helper
INFO - 2018-07-21 02:00:32 --> Database Driver Class Initialized
DEBUG - 2018-07-21 02:00:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-21 02:00:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-21 02:00:32 --> Email Class Initialized
INFO - 2018-07-21 02:00:32 --> Controller Class Initialized
DEBUG - 2018-07-21 02:00:32 --> Users MX_Controller Initialized
DEBUG - 2018-07-21 02:00:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-21 02:00:32 --> Helper loaded: file_helper
DEBUG - 2018-07-21 02:00:32 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-21 02:00:32 --> Login MX_Controller Initialized
INFO - 2018-07-21 02:00:32 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-21 02:00:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-21 02:00:32 --> Final output sent to browser
DEBUG - 2018-07-21 02:00:32 --> Total execution time: 0.3461
INFO - 2018-07-21 02:00:34 --> Config Class Initialized
INFO - 2018-07-21 02:00:34 --> Hooks Class Initialized
DEBUG - 2018-07-21 02:00:34 --> UTF-8 Support Enabled
INFO - 2018-07-21 02:00:34 --> Utf8 Class Initialized
INFO - 2018-07-21 02:00:34 --> URI Class Initialized
INFO - 2018-07-21 02:00:34 --> Router Class Initialized
INFO - 2018-07-21 02:00:34 --> Output Class Initialized
INFO - 2018-07-21 02:00:34 --> Security Class Initialized
DEBUG - 2018-07-21 02:00:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 02:00:34 --> Input Class Initialized
INFO - 2018-07-21 02:00:34 --> Language Class Initialized
INFO - 2018-07-21 02:00:34 --> Language Class Initialized
INFO - 2018-07-21 02:00:34 --> Config Class Initialized
INFO - 2018-07-21 02:00:34 --> Loader Class Initialized
DEBUG - 2018-07-21 02:00:34 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-21 02:00:34 --> Helper loaded: url_helper
INFO - 2018-07-21 02:00:34 --> Helper loaded: form_helper
INFO - 2018-07-21 02:00:34 --> Helper loaded: date_helper
INFO - 2018-07-21 02:00:34 --> Helper loaded: util_helper
INFO - 2018-07-21 02:00:34 --> Helper loaded: text_helper
INFO - 2018-07-21 02:00:34 --> Helper loaded: string_helper
INFO - 2018-07-21 02:00:34 --> Database Driver Class Initialized
DEBUG - 2018-07-21 02:00:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-21 02:00:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-21 02:00:34 --> Email Class Initialized
INFO - 2018-07-21 02:00:34 --> Controller Class Initialized
DEBUG - 2018-07-21 02:00:34 --> Users MX_Controller Initialized
DEBUG - 2018-07-21 02:00:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-21 02:00:34 --> Helper loaded: file_helper
DEBUG - 2018-07-21 02:00:34 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-21 02:00:34 --> Login MX_Controller Initialized
INFO - 2018-07-21 02:00:34 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-21 02:00:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-21 02:00:34 --> Final output sent to browser
DEBUG - 2018-07-21 02:00:35 --> Total execution time: 0.3320
INFO - 2018-07-21 02:00:38 --> Config Class Initialized
INFO - 2018-07-21 02:00:38 --> Hooks Class Initialized
DEBUG - 2018-07-21 02:00:38 --> UTF-8 Support Enabled
INFO - 2018-07-21 02:00:38 --> Utf8 Class Initialized
INFO - 2018-07-21 02:00:38 --> URI Class Initialized
INFO - 2018-07-21 02:00:38 --> Router Class Initialized
INFO - 2018-07-21 02:00:38 --> Output Class Initialized
INFO - 2018-07-21 02:00:38 --> Security Class Initialized
DEBUG - 2018-07-21 02:00:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 02:00:38 --> Input Class Initialized
INFO - 2018-07-21 02:00:38 --> Language Class Initialized
INFO - 2018-07-21 02:00:38 --> Language Class Initialized
INFO - 2018-07-21 02:00:38 --> Config Class Initialized
INFO - 2018-07-21 02:00:38 --> Loader Class Initialized
DEBUG - 2018-07-21 02:00:38 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-21 02:00:39 --> Helper loaded: url_helper
INFO - 2018-07-21 02:00:39 --> Helper loaded: form_helper
INFO - 2018-07-21 02:00:39 --> Helper loaded: date_helper
INFO - 2018-07-21 02:00:39 --> Helper loaded: util_helper
INFO - 2018-07-21 02:00:39 --> Helper loaded: text_helper
INFO - 2018-07-21 02:00:39 --> Helper loaded: string_helper
INFO - 2018-07-21 02:00:39 --> Database Driver Class Initialized
DEBUG - 2018-07-21 02:00:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-21 02:00:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-21 02:00:39 --> Email Class Initialized
INFO - 2018-07-21 02:00:39 --> Controller Class Initialized
DEBUG - 2018-07-21 02:00:39 --> Users MX_Controller Initialized
DEBUG - 2018-07-21 02:00:39 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-21 02:00:39 --> Helper loaded: file_helper
DEBUG - 2018-07-21 02:00:39 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-21 02:00:39 --> Login MX_Controller Initialized
INFO - 2018-07-21 02:00:39 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-21 02:00:39 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-21 02:00:39 --> Final output sent to browser
DEBUG - 2018-07-21 02:00:39 --> Total execution time: 0.3338
INFO - 2018-07-21 02:00:42 --> Config Class Initialized
INFO - 2018-07-21 02:00:42 --> Hooks Class Initialized
DEBUG - 2018-07-21 02:00:42 --> UTF-8 Support Enabled
INFO - 2018-07-21 02:00:43 --> Utf8 Class Initialized
INFO - 2018-07-21 02:00:43 --> URI Class Initialized
INFO - 2018-07-21 02:00:43 --> Router Class Initialized
INFO - 2018-07-21 02:00:43 --> Output Class Initialized
INFO - 2018-07-21 02:00:43 --> Security Class Initialized
DEBUG - 2018-07-21 02:00:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 02:00:43 --> Input Class Initialized
INFO - 2018-07-21 02:00:43 --> Language Class Initialized
INFO - 2018-07-21 02:00:43 --> Language Class Initialized
INFO - 2018-07-21 02:00:43 --> Config Class Initialized
INFO - 2018-07-21 02:00:43 --> Loader Class Initialized
DEBUG - 2018-07-21 02:00:43 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-21 02:00:43 --> Helper loaded: url_helper
INFO - 2018-07-21 02:00:43 --> Helper loaded: form_helper
INFO - 2018-07-21 02:00:43 --> Helper loaded: date_helper
INFO - 2018-07-21 02:00:43 --> Helper loaded: util_helper
INFO - 2018-07-21 02:00:43 --> Helper loaded: text_helper
INFO - 2018-07-21 02:00:43 --> Helper loaded: string_helper
INFO - 2018-07-21 02:00:43 --> Database Driver Class Initialized
DEBUG - 2018-07-21 02:00:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-21 02:00:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-21 02:00:43 --> Email Class Initialized
INFO - 2018-07-21 02:00:43 --> Controller Class Initialized
DEBUG - 2018-07-21 02:00:43 --> Users MX_Controller Initialized
DEBUG - 2018-07-21 02:00:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-21 02:00:43 --> Helper loaded: file_helper
DEBUG - 2018-07-21 02:00:43 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-21 02:00:43 --> Login MX_Controller Initialized
INFO - 2018-07-21 02:00:43 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-21 02:00:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-21 02:00:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
DEBUG - 2018-07-21 02:00:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-07-21 02:55:03 --> Config Class Initialized
INFO - 2018-07-21 02:55:03 --> Hooks Class Initialized
DEBUG - 2018-07-21 02:55:03 --> UTF-8 Support Enabled
INFO - 2018-07-21 02:55:03 --> Utf8 Class Initialized
INFO - 2018-07-21 02:55:03 --> URI Class Initialized
INFO - 2018-07-21 02:55:03 --> Router Class Initialized
INFO - 2018-07-21 02:55:03 --> Output Class Initialized
INFO - 2018-07-21 02:55:03 --> Security Class Initialized
DEBUG - 2018-07-21 02:55:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 02:55:03 --> Input Class Initialized
INFO - 2018-07-21 02:55:03 --> Language Class Initialized
INFO - 2018-07-21 02:55:03 --> Language Class Initialized
INFO - 2018-07-21 02:55:03 --> Config Class Initialized
INFO - 2018-07-21 02:55:03 --> Loader Class Initialized
DEBUG - 2018-07-21 02:55:03 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-21 02:55:03 --> Helper loaded: url_helper
INFO - 2018-07-21 02:55:03 --> Helper loaded: form_helper
INFO - 2018-07-21 02:55:03 --> Helper loaded: date_helper
INFO - 2018-07-21 02:55:03 --> Helper loaded: util_helper
INFO - 2018-07-21 02:55:03 --> Helper loaded: text_helper
INFO - 2018-07-21 02:55:03 --> Helper loaded: string_helper
INFO - 2018-07-21 02:55:03 --> Database Driver Class Initialized
DEBUG - 2018-07-21 02:55:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-21 02:55:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-21 02:55:03 --> Email Class Initialized
INFO - 2018-07-21 02:55:03 --> Controller Class Initialized
DEBUG - 2018-07-21 02:55:03 --> Users MX_Controller Initialized
DEBUG - 2018-07-21 02:55:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-21 02:55:03 --> Helper loaded: file_helper
DEBUG - 2018-07-21 02:55:03 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-21 02:55:03 --> Login MX_Controller Initialized
INFO - 2018-07-21 02:55:03 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-21 02:55:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-21 02:55:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
DEBUG - 2018-07-21 02:55:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-07-21 03:01:53 --> Config Class Initialized
INFO - 2018-07-21 03:01:53 --> Hooks Class Initialized
DEBUG - 2018-07-21 03:01:53 --> UTF-8 Support Enabled
INFO - 2018-07-21 03:01:53 --> Utf8 Class Initialized
INFO - 2018-07-21 03:01:53 --> URI Class Initialized
INFO - 2018-07-21 03:01:53 --> Router Class Initialized
INFO - 2018-07-21 03:01:53 --> Output Class Initialized
INFO - 2018-07-21 03:01:53 --> Security Class Initialized
DEBUG - 2018-07-21 03:01:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 03:01:53 --> Input Class Initialized
INFO - 2018-07-21 03:01:53 --> Language Class Initialized
INFO - 2018-07-21 03:01:53 --> Language Class Initialized
INFO - 2018-07-21 03:01:53 --> Config Class Initialized
INFO - 2018-07-21 03:01:53 --> Loader Class Initialized
DEBUG - 2018-07-21 03:01:53 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-21 03:01:53 --> Helper loaded: url_helper
INFO - 2018-07-21 03:01:53 --> Helper loaded: form_helper
INFO - 2018-07-21 03:01:53 --> Helper loaded: date_helper
INFO - 2018-07-21 03:01:53 --> Helper loaded: util_helper
INFO - 2018-07-21 03:01:53 --> Helper loaded: text_helper
INFO - 2018-07-21 03:01:53 --> Helper loaded: string_helper
INFO - 2018-07-21 03:01:53 --> Database Driver Class Initialized
DEBUG - 2018-07-21 03:01:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-21 03:01:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-21 03:01:53 --> Email Class Initialized
INFO - 2018-07-21 03:01:53 --> Controller Class Initialized
DEBUG - 2018-07-21 03:01:54 --> Users MX_Controller Initialized
DEBUG - 2018-07-21 03:01:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-21 03:01:54 --> Helper loaded: file_helper
DEBUG - 2018-07-21 03:01:54 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-21 03:01:54 --> Login MX_Controller Initialized
INFO - 2018-07-21 03:01:54 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-21 03:01:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-21 03:01:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
DEBUG - 2018-07-21 03:01:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-21 03:01:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
INFO - 2018-07-21 03:01:54 --> Upload Class Initialized
ERROR - 2018-07-21 03:01:54 --> Query error: Unknown column 'payment_method' in 'field list' - Invalid query: INSERT INTO `users` (`first_name`, `last_name`, `payment_method`, `payment_method_date`, `username`, `email`, `role_id`, `password`, `image`) VALUES ('Gopi', 'Testing', '1', '07/25/2018', 'GopiTesting', 'gopaltesting1@yopmail.com', '2', '21ccf4fb48b1aaf9f0e3f558708cd8e5', 'Gopi-hv7YAjxyS0r31MCw.jpg')
INFO - 2018-07-21 03:01:54 --> Language file loaded: language/english/db_lang.php
INFO - 2018-07-21 03:02:50 --> Config Class Initialized
INFO - 2018-07-21 03:02:50 --> Hooks Class Initialized
DEBUG - 2018-07-21 03:02:50 --> UTF-8 Support Enabled
INFO - 2018-07-21 03:02:50 --> Utf8 Class Initialized
INFO - 2018-07-21 03:02:50 --> URI Class Initialized
INFO - 2018-07-21 03:02:50 --> Router Class Initialized
INFO - 2018-07-21 03:02:50 --> Output Class Initialized
INFO - 2018-07-21 03:02:50 --> Security Class Initialized
DEBUG - 2018-07-21 03:02:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 03:02:50 --> Input Class Initialized
INFO - 2018-07-21 03:02:50 --> Language Class Initialized
INFO - 2018-07-21 03:02:50 --> Language Class Initialized
INFO - 2018-07-21 03:02:50 --> Config Class Initialized
INFO - 2018-07-21 03:02:50 --> Loader Class Initialized
DEBUG - 2018-07-21 03:02:50 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-21 03:02:50 --> Helper loaded: url_helper
INFO - 2018-07-21 03:02:50 --> Helper loaded: form_helper
INFO - 2018-07-21 03:02:50 --> Helper loaded: date_helper
INFO - 2018-07-21 03:02:50 --> Helper loaded: util_helper
INFO - 2018-07-21 03:02:50 --> Helper loaded: text_helper
INFO - 2018-07-21 03:02:50 --> Helper loaded: string_helper
INFO - 2018-07-21 03:02:50 --> Database Driver Class Initialized
DEBUG - 2018-07-21 03:02:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-21 03:02:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-21 03:02:50 --> Email Class Initialized
INFO - 2018-07-21 03:02:50 --> Controller Class Initialized
DEBUG - 2018-07-21 03:02:50 --> Users MX_Controller Initialized
DEBUG - 2018-07-21 03:02:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-21 03:02:50 --> Helper loaded: file_helper
DEBUG - 2018-07-21 03:02:50 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-21 03:02:50 --> Login MX_Controller Initialized
INFO - 2018-07-21 03:02:50 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-21 03:02:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-21 03:02:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
DEBUG - 2018-07-21 03:02:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-21 03:02:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-21 03:02:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-21 03:02:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-21 03:02:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-21 03:02:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-21 03:02:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/create_user.php
INFO - 2018-07-21 03:02:50 --> Final output sent to browser
DEBUG - 2018-07-21 03:02:50 --> Total execution time: 0.4019
INFO - 2018-07-21 03:02:53 --> Config Class Initialized
INFO - 2018-07-21 03:02:53 --> Hooks Class Initialized
DEBUG - 2018-07-21 03:02:53 --> UTF-8 Support Enabled
INFO - 2018-07-21 03:02:53 --> Utf8 Class Initialized
INFO - 2018-07-21 03:02:53 --> URI Class Initialized
INFO - 2018-07-21 03:02:53 --> Router Class Initialized
INFO - 2018-07-21 03:02:54 --> Output Class Initialized
INFO - 2018-07-21 03:02:54 --> Security Class Initialized
DEBUG - 2018-07-21 03:02:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 03:02:54 --> Input Class Initialized
INFO - 2018-07-21 03:02:54 --> Language Class Initialized
INFO - 2018-07-21 03:02:54 --> Language Class Initialized
INFO - 2018-07-21 03:02:54 --> Config Class Initialized
INFO - 2018-07-21 03:02:54 --> Loader Class Initialized
DEBUG - 2018-07-21 03:02:54 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-21 03:02:54 --> Helper loaded: url_helper
INFO - 2018-07-21 03:02:54 --> Helper loaded: form_helper
INFO - 2018-07-21 03:02:54 --> Helper loaded: date_helper
INFO - 2018-07-21 03:02:54 --> Helper loaded: util_helper
INFO - 2018-07-21 03:02:54 --> Helper loaded: text_helper
INFO - 2018-07-21 03:02:54 --> Helper loaded: string_helper
INFO - 2018-07-21 03:02:54 --> Database Driver Class Initialized
DEBUG - 2018-07-21 03:02:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-21 03:02:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-21 03:02:54 --> Email Class Initialized
INFO - 2018-07-21 03:02:54 --> Controller Class Initialized
DEBUG - 2018-07-21 03:02:54 --> Users MX_Controller Initialized
DEBUG - 2018-07-21 03:02:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-21 03:02:54 --> Helper loaded: file_helper
DEBUG - 2018-07-21 03:02:54 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-21 03:02:54 --> Login MX_Controller Initialized
INFO - 2018-07-21 03:02:54 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-21 03:02:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-21 03:02:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
DEBUG - 2018-07-21 03:02:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-21 03:02:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
INFO - 2018-07-21 03:02:54 --> Upload Class Initialized
ERROR - 2018-07-21 03:02:54 --> Query error: Unknown column 'payment_method_date' in 'field list' - Invalid query: INSERT INTO `users` (`first_name`, `last_name`, `payment_method_fin`, `payment_method_date`, `username`, `email`, `role_id`, `password`, `image`) VALUES ('Gopi', 'Testing', '1', '07/25/2018', 'GopiTesting', 'gopaltesting1@yopmail.com', '2', '8390365eec978e466e30be7a423fe163', 'Gopi-me8gJv0CEjwfBcWP.jpg')
INFO - 2018-07-21 03:02:54 --> Language file loaded: language/english/db_lang.php
INFO - 2018-07-21 03:10:07 --> Config Class Initialized
INFO - 2018-07-21 03:10:07 --> Hooks Class Initialized
DEBUG - 2018-07-21 03:10:07 --> UTF-8 Support Enabled
INFO - 2018-07-21 03:10:07 --> Utf8 Class Initialized
INFO - 2018-07-21 03:10:07 --> URI Class Initialized
INFO - 2018-07-21 03:10:07 --> Router Class Initialized
INFO - 2018-07-21 03:10:07 --> Output Class Initialized
INFO - 2018-07-21 03:10:07 --> Security Class Initialized
DEBUG - 2018-07-21 03:10:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 03:10:07 --> Input Class Initialized
INFO - 2018-07-21 03:10:07 --> Language Class Initialized
INFO - 2018-07-21 03:10:07 --> Language Class Initialized
INFO - 2018-07-21 03:10:07 --> Config Class Initialized
INFO - 2018-07-21 03:10:07 --> Loader Class Initialized
DEBUG - 2018-07-21 03:10:07 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-21 03:10:07 --> Helper loaded: url_helper
INFO - 2018-07-21 03:10:07 --> Helper loaded: form_helper
INFO - 2018-07-21 03:10:07 --> Helper loaded: date_helper
INFO - 2018-07-21 03:10:07 --> Helper loaded: util_helper
INFO - 2018-07-21 03:10:07 --> Helper loaded: text_helper
INFO - 2018-07-21 03:10:07 --> Helper loaded: string_helper
INFO - 2018-07-21 03:10:07 --> Database Driver Class Initialized
DEBUG - 2018-07-21 03:10:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-21 03:10:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-21 03:10:07 --> Email Class Initialized
INFO - 2018-07-21 03:10:07 --> Controller Class Initialized
DEBUG - 2018-07-21 03:10:07 --> Users MX_Controller Initialized
DEBUG - 2018-07-21 03:10:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-21 03:10:07 --> Helper loaded: file_helper
DEBUG - 2018-07-21 03:10:07 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-21 03:10:07 --> Login MX_Controller Initialized
INFO - 2018-07-21 03:10:07 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-21 03:10:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-21 03:10:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
DEBUG - 2018-07-21 03:10:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-21 03:10:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
INFO - 2018-07-21 03:10:08 --> Upload Class Initialized
ERROR - 2018-07-21 03:10:08 --> Query error: Duplicate entry '0' for key 'PRIMARY' - Invalid query: INSERT INTO `users_programs` (`program_id`, `user_id`) VALUES ('2', '1')
INFO - 2018-07-21 03:10:08 --> Language file loaded: language/english/db_lang.php
INFO - 2018-07-21 03:10:43 --> Config Class Initialized
INFO - 2018-07-21 03:10:43 --> Hooks Class Initialized
DEBUG - 2018-07-21 03:10:43 --> UTF-8 Support Enabled
INFO - 2018-07-21 03:10:43 --> Utf8 Class Initialized
INFO - 2018-07-21 03:10:43 --> URI Class Initialized
INFO - 2018-07-21 03:10:43 --> Router Class Initialized
INFO - 2018-07-21 03:10:43 --> Output Class Initialized
INFO - 2018-07-21 03:10:43 --> Security Class Initialized
DEBUG - 2018-07-21 03:10:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 03:10:43 --> Input Class Initialized
INFO - 2018-07-21 03:10:43 --> Language Class Initialized
INFO - 2018-07-21 03:10:43 --> Language Class Initialized
INFO - 2018-07-21 03:10:43 --> Config Class Initialized
INFO - 2018-07-21 03:10:43 --> Loader Class Initialized
DEBUG - 2018-07-21 03:10:43 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-21 03:10:43 --> Helper loaded: url_helper
INFO - 2018-07-21 03:10:43 --> Helper loaded: form_helper
INFO - 2018-07-21 03:10:43 --> Helper loaded: date_helper
INFO - 2018-07-21 03:10:43 --> Helper loaded: util_helper
INFO - 2018-07-21 03:10:43 --> Helper loaded: text_helper
INFO - 2018-07-21 03:10:43 --> Helper loaded: string_helper
INFO - 2018-07-21 03:10:43 --> Database Driver Class Initialized
DEBUG - 2018-07-21 03:10:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-21 03:10:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-21 03:10:43 --> Email Class Initialized
INFO - 2018-07-21 03:10:43 --> Controller Class Initialized
DEBUG - 2018-07-21 03:10:43 --> Users MX_Controller Initialized
DEBUG - 2018-07-21 03:10:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-21 03:10:43 --> Helper loaded: file_helper
DEBUG - 2018-07-21 03:10:43 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-21 03:10:43 --> Login MX_Controller Initialized
INFO - 2018-07-21 03:10:43 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-21 03:10:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-21 03:10:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
DEBUG - 2018-07-21 03:10:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-21 03:10:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
INFO - 2018-07-21 03:10:44 --> Upload Class Initialized
INFO - 2018-07-21 03:10:44 --> Passsword for email - gopaltesting1@yopmail.com - is :: Testing2389
DEBUG - 2018-07-21 03:10:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/templates/credentials.php
DEBUG - 2018-07-21 03:10:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Mail_model.php
DEBUG - 2018-07-21 03:10:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/mail_view.php
INFO - 2018-07-21 03:10:44 --> Mail logged successfully
INFO - 2018-07-21 03:10:44 --> Config Class Initialized
INFO - 2018-07-21 03:10:44 --> Hooks Class Initialized
DEBUG - 2018-07-21 03:10:44 --> UTF-8 Support Enabled
INFO - 2018-07-21 03:10:44 --> Utf8 Class Initialized
INFO - 2018-07-21 03:10:44 --> URI Class Initialized
INFO - 2018-07-21 03:10:44 --> Router Class Initialized
INFO - 2018-07-21 03:10:44 --> Output Class Initialized
INFO - 2018-07-21 03:10:44 --> Security Class Initialized
DEBUG - 2018-07-21 03:10:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 03:10:44 --> Input Class Initialized
INFO - 2018-07-21 03:10:44 --> Language Class Initialized
INFO - 2018-07-21 03:10:44 --> Language Class Initialized
INFO - 2018-07-21 03:10:44 --> Config Class Initialized
INFO - 2018-07-21 03:10:44 --> Loader Class Initialized
DEBUG - 2018-07-21 03:10:44 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-21 03:10:44 --> Helper loaded: url_helper
INFO - 2018-07-21 03:10:44 --> Helper loaded: form_helper
INFO - 2018-07-21 03:10:44 --> Helper loaded: date_helper
INFO - 2018-07-21 03:10:44 --> Helper loaded: util_helper
INFO - 2018-07-21 03:10:44 --> Helper loaded: text_helper
INFO - 2018-07-21 03:10:44 --> Helper loaded: string_helper
INFO - 2018-07-21 03:10:44 --> Database Driver Class Initialized
DEBUG - 2018-07-21 03:10:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-21 03:10:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-21 03:10:44 --> Email Class Initialized
INFO - 2018-07-21 03:10:44 --> Controller Class Initialized
DEBUG - 2018-07-21 03:10:44 --> Users MX_Controller Initialized
DEBUG - 2018-07-21 03:10:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-21 03:10:44 --> Helper loaded: file_helper
DEBUG - 2018-07-21 03:10:44 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-21 03:10:44 --> Login MX_Controller Initialized
INFO - 2018-07-21 03:10:44 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-21 03:10:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-21 03:10:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-21 03:10:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-21 03:10:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-21 03:10:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-21 03:10:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-21 03:10:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/users.php
INFO - 2018-07-21 03:10:44 --> Final output sent to browser
DEBUG - 2018-07-21 03:10:44 --> Total execution time: 0.3914
INFO - 2018-07-21 03:10:45 --> Config Class Initialized
INFO - 2018-07-21 03:10:45 --> Hooks Class Initialized
DEBUG - 2018-07-21 03:10:45 --> UTF-8 Support Enabled
INFO - 2018-07-21 03:10:45 --> Utf8 Class Initialized
INFO - 2018-07-21 03:10:45 --> URI Class Initialized
INFO - 2018-07-21 03:10:45 --> Router Class Initialized
INFO - 2018-07-21 03:10:45 --> Output Class Initialized
INFO - 2018-07-21 03:10:45 --> Security Class Initialized
DEBUG - 2018-07-21 03:10:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 03:10:45 --> Input Class Initialized
INFO - 2018-07-21 03:10:45 --> Language Class Initialized
INFO - 2018-07-21 03:10:45 --> Language Class Initialized
INFO - 2018-07-21 03:10:45 --> Config Class Initialized
INFO - 2018-07-21 03:10:45 --> Loader Class Initialized
DEBUG - 2018-07-21 03:10:45 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-21 03:10:45 --> Helper loaded: url_helper
INFO - 2018-07-21 03:10:45 --> Helper loaded: form_helper
INFO - 2018-07-21 03:10:45 --> Helper loaded: date_helper
INFO - 2018-07-21 03:10:45 --> Helper loaded: util_helper
INFO - 2018-07-21 03:10:45 --> Helper loaded: text_helper
INFO - 2018-07-21 03:10:45 --> Helper loaded: string_helper
INFO - 2018-07-21 03:10:45 --> Database Driver Class Initialized
DEBUG - 2018-07-21 03:10:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-21 03:10:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-21 03:10:45 --> Email Class Initialized
INFO - 2018-07-21 03:10:45 --> Controller Class Initialized
DEBUG - 2018-07-21 03:10:45 --> Users MX_Controller Initialized
DEBUG - 2018-07-21 03:10:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-21 03:10:45 --> Helper loaded: file_helper
DEBUG - 2018-07-21 03:10:45 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-21 03:10:45 --> Login MX_Controller Initialized
INFO - 2018-07-21 03:10:45 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-21 03:10:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-21 03:10:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-07-21 03:10:45 --> Final output sent to browser
DEBUG - 2018-07-21 03:10:45 --> Total execution time: 0.5136
INFO - 2018-07-21 03:15:19 --> Config Class Initialized
INFO - 2018-07-21 03:15:19 --> Hooks Class Initialized
DEBUG - 2018-07-21 03:15:19 --> UTF-8 Support Enabled
INFO - 2018-07-21 03:15:19 --> Utf8 Class Initialized
INFO - 2018-07-21 03:15:19 --> URI Class Initialized
INFO - 2018-07-21 03:15:19 --> Router Class Initialized
INFO - 2018-07-21 03:15:19 --> Output Class Initialized
INFO - 2018-07-21 03:15:19 --> Security Class Initialized
DEBUG - 2018-07-21 03:15:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 03:15:19 --> Input Class Initialized
INFO - 2018-07-21 03:15:19 --> Language Class Initialized
INFO - 2018-07-21 03:15:19 --> Language Class Initialized
INFO - 2018-07-21 03:15:19 --> Config Class Initialized
INFO - 2018-07-21 03:15:19 --> Loader Class Initialized
DEBUG - 2018-07-21 03:15:19 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-21 03:15:19 --> Helper loaded: url_helper
INFO - 2018-07-21 03:15:19 --> Helper loaded: form_helper
INFO - 2018-07-21 03:15:19 --> Helper loaded: date_helper
INFO - 2018-07-21 03:15:19 --> Helper loaded: util_helper
INFO - 2018-07-21 03:15:19 --> Helper loaded: text_helper
INFO - 2018-07-21 03:15:19 --> Helper loaded: string_helper
INFO - 2018-07-21 03:15:19 --> Database Driver Class Initialized
DEBUG - 2018-07-21 03:15:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-21 03:15:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-21 03:15:19 --> Email Class Initialized
INFO - 2018-07-21 03:15:19 --> Controller Class Initialized
DEBUG - 2018-07-21 03:15:19 --> Users MX_Controller Initialized
DEBUG - 2018-07-21 03:15:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-21 03:15:19 --> Helper loaded: file_helper
DEBUG - 2018-07-21 03:15:19 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-21 03:15:19 --> Login MX_Controller Initialized
INFO - 2018-07-21 03:15:19 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-21 03:15:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-21 03:15:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-21 03:15:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-21 03:15:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-21 03:15:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-21 03:15:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-21 03:15:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/users.php
INFO - 2018-07-21 03:15:19 --> Final output sent to browser
DEBUG - 2018-07-21 03:15:19 --> Total execution time: 0.4014
INFO - 2018-07-21 03:15:20 --> Config Class Initialized
INFO - 2018-07-21 03:15:20 --> Hooks Class Initialized
DEBUG - 2018-07-21 03:15:20 --> UTF-8 Support Enabled
INFO - 2018-07-21 03:15:20 --> Utf8 Class Initialized
INFO - 2018-07-21 03:15:20 --> URI Class Initialized
INFO - 2018-07-21 03:15:20 --> Router Class Initialized
INFO - 2018-07-21 03:15:20 --> Output Class Initialized
INFO - 2018-07-21 03:15:20 --> Security Class Initialized
DEBUG - 2018-07-21 03:15:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 03:15:20 --> Input Class Initialized
INFO - 2018-07-21 03:15:20 --> Language Class Initialized
INFO - 2018-07-21 03:15:20 --> Language Class Initialized
INFO - 2018-07-21 03:15:20 --> Config Class Initialized
INFO - 2018-07-21 03:15:20 --> Loader Class Initialized
DEBUG - 2018-07-21 03:15:20 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-21 03:15:20 --> Helper loaded: url_helper
INFO - 2018-07-21 03:15:20 --> Helper loaded: form_helper
INFO - 2018-07-21 03:15:20 --> Helper loaded: date_helper
INFO - 2018-07-21 03:15:20 --> Helper loaded: util_helper
INFO - 2018-07-21 03:15:20 --> Helper loaded: text_helper
INFO - 2018-07-21 03:15:20 --> Helper loaded: string_helper
INFO - 2018-07-21 03:15:20 --> Database Driver Class Initialized
DEBUG - 2018-07-21 03:15:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-21 03:15:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-21 03:15:20 --> Email Class Initialized
INFO - 2018-07-21 03:15:20 --> Controller Class Initialized
DEBUG - 2018-07-21 03:15:20 --> Users MX_Controller Initialized
DEBUG - 2018-07-21 03:15:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-21 03:15:20 --> Helper loaded: file_helper
DEBUG - 2018-07-21 03:15:20 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-21 03:15:20 --> Login MX_Controller Initialized
INFO - 2018-07-21 03:15:20 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-21 03:15:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-21 03:15:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-07-21 03:15:20 --> Final output sent to browser
DEBUG - 2018-07-21 03:15:20 --> Total execution time: 0.4025
INFO - 2018-07-21 03:31:06 --> Config Class Initialized
INFO - 2018-07-21 03:31:06 --> Hooks Class Initialized
DEBUG - 2018-07-21 03:31:06 --> UTF-8 Support Enabled
INFO - 2018-07-21 03:31:06 --> Utf8 Class Initialized
INFO - 2018-07-21 03:31:06 --> URI Class Initialized
INFO - 2018-07-21 03:31:06 --> Router Class Initialized
INFO - 2018-07-21 03:31:06 --> Output Class Initialized
INFO - 2018-07-21 03:31:06 --> Security Class Initialized
DEBUG - 2018-07-21 03:31:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 03:31:06 --> Input Class Initialized
INFO - 2018-07-21 03:31:06 --> Language Class Initialized
INFO - 2018-07-21 03:31:06 --> Language Class Initialized
INFO - 2018-07-21 03:31:06 --> Config Class Initialized
INFO - 2018-07-21 03:31:06 --> Loader Class Initialized
DEBUG - 2018-07-21 03:31:06 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-21 03:31:06 --> Helper loaded: url_helper
INFO - 2018-07-21 03:31:06 --> Helper loaded: form_helper
INFO - 2018-07-21 03:31:06 --> Helper loaded: date_helper
INFO - 2018-07-21 03:31:06 --> Helper loaded: util_helper
INFO - 2018-07-21 03:31:06 --> Helper loaded: text_helper
INFO - 2018-07-21 03:31:06 --> Helper loaded: string_helper
INFO - 2018-07-21 03:31:06 --> Database Driver Class Initialized
DEBUG - 2018-07-21 03:31:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-21 03:31:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-21 03:31:06 --> Email Class Initialized
INFO - 2018-07-21 03:31:06 --> Controller Class Initialized
DEBUG - 2018-07-21 03:31:06 --> Admin MX_Controller Initialized
INFO - 2018-07-21 03:31:06 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-21 03:31:06 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-21 03:31:06 --> Login MX_Controller Initialized
DEBUG - 2018-07-21 03:31:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-21 03:31:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-21 03:31:06 --> Final output sent to browser
DEBUG - 2018-07-21 03:31:06 --> Total execution time: 0.4449
INFO - 2018-07-21 03:31:08 --> Config Class Initialized
INFO - 2018-07-21 03:31:08 --> Hooks Class Initialized
DEBUG - 2018-07-21 03:31:08 --> UTF-8 Support Enabled
INFO - 2018-07-21 03:31:08 --> Utf8 Class Initialized
INFO - 2018-07-21 03:31:09 --> URI Class Initialized
INFO - 2018-07-21 03:31:09 --> Router Class Initialized
INFO - 2018-07-21 03:31:09 --> Output Class Initialized
INFO - 2018-07-21 03:31:09 --> Security Class Initialized
DEBUG - 2018-07-21 03:31:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 03:31:09 --> Input Class Initialized
INFO - 2018-07-21 03:31:09 --> Language Class Initialized
INFO - 2018-07-21 03:31:09 --> Language Class Initialized
INFO - 2018-07-21 03:31:09 --> Config Class Initialized
INFO - 2018-07-21 03:31:09 --> Loader Class Initialized
DEBUG - 2018-07-21 03:31:09 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-21 03:31:09 --> Helper loaded: url_helper
INFO - 2018-07-21 03:31:09 --> Helper loaded: form_helper
INFO - 2018-07-21 03:31:09 --> Helper loaded: date_helper
INFO - 2018-07-21 03:31:09 --> Helper loaded: util_helper
INFO - 2018-07-21 03:31:09 --> Helper loaded: text_helper
INFO - 2018-07-21 03:31:09 --> Helper loaded: string_helper
INFO - 2018-07-21 03:31:09 --> Database Driver Class Initialized
DEBUG - 2018-07-21 03:31:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-21 03:31:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-21 03:31:09 --> Email Class Initialized
INFO - 2018-07-21 03:31:09 --> Controller Class Initialized
DEBUG - 2018-07-21 03:31:09 --> Admin MX_Controller Initialized
INFO - 2018-07-21 03:31:09 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-21 03:31:09 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-21 03:31:09 --> Login MX_Controller Initialized
DEBUG - 2018-07-21 03:31:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-21 03:31:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-21 03:31:09 --> Final output sent to browser
DEBUG - 2018-07-21 03:31:09 --> Total execution time: 0.4433
INFO - 2018-07-21 03:31:23 --> Config Class Initialized
INFO - 2018-07-21 03:31:23 --> Hooks Class Initialized
DEBUG - 2018-07-21 03:31:23 --> UTF-8 Support Enabled
INFO - 2018-07-21 03:31:23 --> Utf8 Class Initialized
INFO - 2018-07-21 03:31:23 --> URI Class Initialized
INFO - 2018-07-21 03:31:23 --> Router Class Initialized
INFO - 2018-07-21 03:31:23 --> Output Class Initialized
INFO - 2018-07-21 03:31:23 --> Security Class Initialized
DEBUG - 2018-07-21 03:31:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 03:31:23 --> Input Class Initialized
INFO - 2018-07-21 03:31:23 --> Language Class Initialized
INFO - 2018-07-21 03:31:23 --> Language Class Initialized
INFO - 2018-07-21 03:31:23 --> Config Class Initialized
INFO - 2018-07-21 03:31:23 --> Loader Class Initialized
DEBUG - 2018-07-21 03:31:23 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-21 03:31:23 --> Helper loaded: url_helper
INFO - 2018-07-21 03:31:23 --> Helper loaded: form_helper
INFO - 2018-07-21 03:31:23 --> Helper loaded: date_helper
INFO - 2018-07-21 03:31:23 --> Helper loaded: util_helper
INFO - 2018-07-21 03:31:23 --> Helper loaded: text_helper
INFO - 2018-07-21 03:31:23 --> Helper loaded: string_helper
INFO - 2018-07-21 03:31:23 --> Database Driver Class Initialized
DEBUG - 2018-07-21 03:31:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-21 03:31:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-21 03:31:23 --> Email Class Initialized
INFO - 2018-07-21 03:31:23 --> Controller Class Initialized
DEBUG - 2018-07-21 03:31:23 --> Users MX_Controller Initialized
DEBUG - 2018-07-21 03:31:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-21 03:31:23 --> Helper loaded: file_helper
DEBUG - 2018-07-21 03:31:23 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-21 03:31:23 --> Login MX_Controller Initialized
INFO - 2018-07-21 03:31:23 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-21 03:31:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-21 03:31:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-21 03:31:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-21 03:31:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-21 03:31:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-21 03:31:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-21 03:31:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/users.php
INFO - 2018-07-21 03:31:23 --> Final output sent to browser
DEBUG - 2018-07-21 03:31:23 --> Total execution time: 0.3768
INFO - 2018-07-21 03:31:24 --> Config Class Initialized
INFO - 2018-07-21 03:31:24 --> Hooks Class Initialized
DEBUG - 2018-07-21 03:31:24 --> UTF-8 Support Enabled
INFO - 2018-07-21 03:31:24 --> Utf8 Class Initialized
INFO - 2018-07-21 03:31:24 --> URI Class Initialized
INFO - 2018-07-21 03:31:24 --> Router Class Initialized
INFO - 2018-07-21 03:31:24 --> Output Class Initialized
INFO - 2018-07-21 03:31:24 --> Security Class Initialized
DEBUG - 2018-07-21 03:31:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 03:31:24 --> Input Class Initialized
INFO - 2018-07-21 03:31:24 --> Language Class Initialized
INFO - 2018-07-21 03:31:24 --> Language Class Initialized
INFO - 2018-07-21 03:31:24 --> Config Class Initialized
INFO - 2018-07-21 03:31:24 --> Loader Class Initialized
DEBUG - 2018-07-21 03:31:24 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-21 03:31:24 --> Helper loaded: url_helper
INFO - 2018-07-21 03:31:24 --> Helper loaded: form_helper
INFO - 2018-07-21 03:31:24 --> Helper loaded: date_helper
INFO - 2018-07-21 03:31:24 --> Helper loaded: util_helper
INFO - 2018-07-21 03:31:24 --> Helper loaded: text_helper
INFO - 2018-07-21 03:31:24 --> Helper loaded: string_helper
INFO - 2018-07-21 03:31:24 --> Database Driver Class Initialized
DEBUG - 2018-07-21 03:31:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-21 03:31:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-21 03:31:24 --> Email Class Initialized
INFO - 2018-07-21 03:31:24 --> Controller Class Initialized
DEBUG - 2018-07-21 03:31:24 --> Users MX_Controller Initialized
DEBUG - 2018-07-21 03:31:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-21 03:31:24 --> Helper loaded: file_helper
DEBUG - 2018-07-21 03:31:24 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-21 03:31:24 --> Login MX_Controller Initialized
INFO - 2018-07-21 03:31:24 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-21 03:31:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-21 03:31:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-07-21 03:31:24 --> Final output sent to browser
DEBUG - 2018-07-21 03:31:24 --> Total execution time: 0.4312
INFO - 2018-07-21 03:32:16 --> Config Class Initialized
INFO - 2018-07-21 03:32:16 --> Hooks Class Initialized
DEBUG - 2018-07-21 03:32:16 --> UTF-8 Support Enabled
INFO - 2018-07-21 03:32:16 --> Utf8 Class Initialized
INFO - 2018-07-21 03:32:16 --> URI Class Initialized
INFO - 2018-07-21 03:32:16 --> Router Class Initialized
INFO - 2018-07-21 03:32:16 --> Output Class Initialized
INFO - 2018-07-21 03:32:16 --> Security Class Initialized
DEBUG - 2018-07-21 03:32:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 03:32:16 --> Input Class Initialized
INFO - 2018-07-21 03:32:16 --> Language Class Initialized
INFO - 2018-07-21 03:32:16 --> Language Class Initialized
INFO - 2018-07-21 03:32:16 --> Config Class Initialized
INFO - 2018-07-21 03:32:16 --> Loader Class Initialized
DEBUG - 2018-07-21 03:32:16 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-21 03:32:16 --> Helper loaded: url_helper
INFO - 2018-07-21 03:32:16 --> Helper loaded: form_helper
INFO - 2018-07-21 03:32:16 --> Helper loaded: date_helper
INFO - 2018-07-21 03:32:16 --> Helper loaded: util_helper
INFO - 2018-07-21 03:32:16 --> Helper loaded: text_helper
INFO - 2018-07-21 03:32:16 --> Helper loaded: string_helper
INFO - 2018-07-21 03:32:16 --> Database Driver Class Initialized
DEBUG - 2018-07-21 03:32:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-21 03:32:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-21 03:32:16 --> Email Class Initialized
INFO - 2018-07-21 03:32:16 --> Controller Class Initialized
DEBUG - 2018-07-21 03:32:16 --> Users MX_Controller Initialized
DEBUG - 2018-07-21 03:32:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-21 03:32:16 --> Helper loaded: file_helper
DEBUG - 2018-07-21 03:32:16 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-21 03:32:16 --> Login MX_Controller Initialized
INFO - 2018-07-21 03:32:16 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-21 03:32:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-21 03:32:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-21 03:32:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-21 03:32:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-21 03:32:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-21 03:32:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-21 03:32:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/users.php
INFO - 2018-07-21 03:32:16 --> Final output sent to browser
DEBUG - 2018-07-21 03:32:16 --> Total execution time: 0.3780
INFO - 2018-07-21 03:32:17 --> Config Class Initialized
INFO - 2018-07-21 03:32:17 --> Hooks Class Initialized
DEBUG - 2018-07-21 03:32:17 --> UTF-8 Support Enabled
INFO - 2018-07-21 03:32:17 --> Utf8 Class Initialized
INFO - 2018-07-21 03:32:17 --> URI Class Initialized
INFO - 2018-07-21 03:32:17 --> Router Class Initialized
INFO - 2018-07-21 03:32:17 --> Output Class Initialized
INFO - 2018-07-21 03:32:17 --> Security Class Initialized
DEBUG - 2018-07-21 03:32:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 03:32:17 --> Input Class Initialized
INFO - 2018-07-21 03:32:17 --> Language Class Initialized
INFO - 2018-07-21 03:32:17 --> Language Class Initialized
INFO - 2018-07-21 03:32:17 --> Config Class Initialized
INFO - 2018-07-21 03:32:17 --> Loader Class Initialized
DEBUG - 2018-07-21 03:32:17 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-21 03:32:17 --> Helper loaded: url_helper
INFO - 2018-07-21 03:32:17 --> Helper loaded: form_helper
INFO - 2018-07-21 03:32:17 --> Helper loaded: date_helper
INFO - 2018-07-21 03:32:17 --> Helper loaded: util_helper
INFO - 2018-07-21 03:32:17 --> Helper loaded: text_helper
INFO - 2018-07-21 03:32:17 --> Helper loaded: string_helper
INFO - 2018-07-21 03:32:17 --> Database Driver Class Initialized
DEBUG - 2018-07-21 03:32:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-21 03:32:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-21 03:32:17 --> Email Class Initialized
INFO - 2018-07-21 03:32:17 --> Controller Class Initialized
DEBUG - 2018-07-21 03:32:17 --> Users MX_Controller Initialized
DEBUG - 2018-07-21 03:32:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-21 03:32:17 --> Helper loaded: file_helper
DEBUG - 2018-07-21 03:32:17 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-21 03:32:17 --> Login MX_Controller Initialized
INFO - 2018-07-21 03:32:17 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-21 03:32:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-21 03:32:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-07-21 03:32:17 --> Final output sent to browser
DEBUG - 2018-07-21 03:32:17 --> Total execution time: 0.4213
INFO - 2018-07-21 03:33:37 --> Config Class Initialized
INFO - 2018-07-21 03:33:37 --> Hooks Class Initialized
DEBUG - 2018-07-21 03:33:37 --> UTF-8 Support Enabled
INFO - 2018-07-21 03:33:37 --> Utf8 Class Initialized
INFO - 2018-07-21 03:33:37 --> URI Class Initialized
INFO - 2018-07-21 03:33:37 --> Router Class Initialized
INFO - 2018-07-21 03:33:37 --> Output Class Initialized
INFO - 2018-07-21 03:33:37 --> Security Class Initialized
DEBUG - 2018-07-21 03:33:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 03:33:37 --> Input Class Initialized
INFO - 2018-07-21 03:33:37 --> Language Class Initialized
INFO - 2018-07-21 03:33:37 --> Language Class Initialized
INFO - 2018-07-21 03:33:37 --> Config Class Initialized
INFO - 2018-07-21 03:33:37 --> Loader Class Initialized
DEBUG - 2018-07-21 03:33:37 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-21 03:33:37 --> Helper loaded: url_helper
INFO - 2018-07-21 03:33:37 --> Helper loaded: form_helper
INFO - 2018-07-21 03:33:37 --> Helper loaded: date_helper
INFO - 2018-07-21 03:33:37 --> Helper loaded: util_helper
INFO - 2018-07-21 03:33:37 --> Helper loaded: text_helper
INFO - 2018-07-21 03:33:37 --> Helper loaded: string_helper
INFO - 2018-07-21 03:33:37 --> Database Driver Class Initialized
DEBUG - 2018-07-21 03:33:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-21 03:33:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-21 03:33:37 --> Email Class Initialized
INFO - 2018-07-21 03:33:37 --> Controller Class Initialized
DEBUG - 2018-07-21 03:33:37 --> Users MX_Controller Initialized
DEBUG - 2018-07-21 03:33:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-21 03:33:37 --> Helper loaded: file_helper
DEBUG - 2018-07-21 03:33:37 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-21 03:33:37 --> Login MX_Controller Initialized
INFO - 2018-07-21 03:33:37 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-21 03:33:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-21 03:33:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-21 03:33:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-21 03:33:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-21 03:33:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-21 03:33:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-21 03:33:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/users.php
INFO - 2018-07-21 03:33:37 --> Final output sent to browser
DEBUG - 2018-07-21 03:33:37 --> Total execution time: 0.3826
INFO - 2018-07-21 03:33:37 --> Config Class Initialized
INFO - 2018-07-21 03:33:37 --> Hooks Class Initialized
DEBUG - 2018-07-21 03:33:37 --> UTF-8 Support Enabled
INFO - 2018-07-21 03:33:37 --> Utf8 Class Initialized
INFO - 2018-07-21 03:33:37 --> URI Class Initialized
INFO - 2018-07-21 03:33:37 --> Router Class Initialized
INFO - 2018-07-21 03:33:37 --> Output Class Initialized
INFO - 2018-07-21 03:33:37 --> Security Class Initialized
DEBUG - 2018-07-21 03:33:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 03:33:37 --> Input Class Initialized
INFO - 2018-07-21 03:33:37 --> Language Class Initialized
INFO - 2018-07-21 03:33:37 --> Language Class Initialized
INFO - 2018-07-21 03:33:37 --> Config Class Initialized
INFO - 2018-07-21 03:33:37 --> Loader Class Initialized
DEBUG - 2018-07-21 03:33:37 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-21 03:33:37 --> Helper loaded: url_helper
INFO - 2018-07-21 03:33:37 --> Helper loaded: form_helper
INFO - 2018-07-21 03:33:37 --> Helper loaded: date_helper
INFO - 2018-07-21 03:33:37 --> Helper loaded: util_helper
INFO - 2018-07-21 03:33:37 --> Helper loaded: text_helper
INFO - 2018-07-21 03:33:37 --> Helper loaded: string_helper
INFO - 2018-07-21 03:33:37 --> Database Driver Class Initialized
DEBUG - 2018-07-21 03:33:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-21 03:33:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-21 03:33:38 --> Email Class Initialized
INFO - 2018-07-21 03:33:38 --> Controller Class Initialized
DEBUG - 2018-07-21 03:33:38 --> Users MX_Controller Initialized
DEBUG - 2018-07-21 03:33:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-21 03:33:38 --> Helper loaded: file_helper
DEBUG - 2018-07-21 03:33:38 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-21 03:33:38 --> Login MX_Controller Initialized
INFO - 2018-07-21 03:33:38 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-21 03:33:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-21 03:33:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-07-21 03:33:38 --> Final output sent to browser
DEBUG - 2018-07-21 03:33:38 --> Total execution time: 0.4247
INFO - 2018-07-21 03:35:35 --> Config Class Initialized
INFO - 2018-07-21 03:35:35 --> Hooks Class Initialized
DEBUG - 2018-07-21 03:35:35 --> UTF-8 Support Enabled
INFO - 2018-07-21 03:35:35 --> Utf8 Class Initialized
INFO - 2018-07-21 03:35:35 --> URI Class Initialized
INFO - 2018-07-21 03:35:35 --> Router Class Initialized
INFO - 2018-07-21 03:35:35 --> Output Class Initialized
INFO - 2018-07-21 03:35:35 --> Security Class Initialized
DEBUG - 2018-07-21 03:35:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 03:35:35 --> Input Class Initialized
INFO - 2018-07-21 03:35:35 --> Language Class Initialized
INFO - 2018-07-21 03:35:35 --> Language Class Initialized
INFO - 2018-07-21 03:35:35 --> Config Class Initialized
INFO - 2018-07-21 03:35:35 --> Loader Class Initialized
DEBUG - 2018-07-21 03:35:35 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-21 03:35:35 --> Helper loaded: url_helper
INFO - 2018-07-21 03:35:35 --> Helper loaded: form_helper
INFO - 2018-07-21 03:35:35 --> Helper loaded: date_helper
INFO - 2018-07-21 03:35:35 --> Helper loaded: util_helper
INFO - 2018-07-21 03:35:35 --> Helper loaded: text_helper
INFO - 2018-07-21 03:35:35 --> Helper loaded: string_helper
INFO - 2018-07-21 03:35:35 --> Database Driver Class Initialized
DEBUG - 2018-07-21 03:35:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-21 03:35:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-21 03:35:35 --> Email Class Initialized
INFO - 2018-07-21 03:35:35 --> Controller Class Initialized
DEBUG - 2018-07-21 03:35:35 --> Users MX_Controller Initialized
DEBUG - 2018-07-21 03:35:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-21 03:35:35 --> Helper loaded: file_helper
DEBUG - 2018-07-21 03:35:35 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-21 03:35:35 --> Login MX_Controller Initialized
INFO - 2018-07-21 03:35:35 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-21 03:35:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-21 03:35:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
DEBUG - 2018-07-21 03:35:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-21 03:35:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-21 03:35:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-21 03:35:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-21 03:35:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-21 03:35:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-21 03:35:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/create_user.php
INFO - 2018-07-21 03:35:35 --> Final output sent to browser
DEBUG - 2018-07-21 03:35:36 --> Total execution time: 0.4304
INFO - 2018-07-21 03:35:39 --> Config Class Initialized
INFO - 2018-07-21 03:35:39 --> Hooks Class Initialized
DEBUG - 2018-07-21 03:35:39 --> UTF-8 Support Enabled
INFO - 2018-07-21 03:35:39 --> Utf8 Class Initialized
INFO - 2018-07-21 03:35:39 --> URI Class Initialized
INFO - 2018-07-21 03:35:39 --> Router Class Initialized
INFO - 2018-07-21 03:35:39 --> Output Class Initialized
INFO - 2018-07-21 03:35:39 --> Security Class Initialized
DEBUG - 2018-07-21 03:35:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 03:35:39 --> Input Class Initialized
INFO - 2018-07-21 03:35:39 --> Language Class Initialized
INFO - 2018-07-21 03:35:39 --> Language Class Initialized
INFO - 2018-07-21 03:35:39 --> Config Class Initialized
INFO - 2018-07-21 03:35:39 --> Loader Class Initialized
DEBUG - 2018-07-21 03:35:39 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-21 03:35:39 --> Helper loaded: url_helper
INFO - 2018-07-21 03:35:39 --> Helper loaded: form_helper
INFO - 2018-07-21 03:35:39 --> Helper loaded: date_helper
INFO - 2018-07-21 03:35:39 --> Helper loaded: util_helper
INFO - 2018-07-21 03:35:39 --> Helper loaded: text_helper
INFO - 2018-07-21 03:35:39 --> Helper loaded: string_helper
INFO - 2018-07-21 03:35:39 --> Database Driver Class Initialized
DEBUG - 2018-07-21 03:35:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-21 03:35:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-21 03:35:39 --> Email Class Initialized
INFO - 2018-07-21 03:35:39 --> Controller Class Initialized
DEBUG - 2018-07-21 03:35:39 --> Users MX_Controller Initialized
DEBUG - 2018-07-21 03:35:39 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-21 03:35:39 --> Helper loaded: file_helper
DEBUG - 2018-07-21 03:35:39 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-21 03:35:39 --> Login MX_Controller Initialized
INFO - 2018-07-21 03:35:39 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-21 03:35:39 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-21 03:35:39 --> Final output sent to browser
DEBUG - 2018-07-21 03:35:39 --> Total execution time: 0.3907
INFO - 2018-07-21 03:35:42 --> Config Class Initialized
INFO - 2018-07-21 03:35:42 --> Hooks Class Initialized
DEBUG - 2018-07-21 03:35:42 --> UTF-8 Support Enabled
INFO - 2018-07-21 03:35:42 --> Utf8 Class Initialized
INFO - 2018-07-21 03:35:42 --> URI Class Initialized
INFO - 2018-07-21 03:35:42 --> Router Class Initialized
INFO - 2018-07-21 03:35:42 --> Output Class Initialized
INFO - 2018-07-21 03:35:42 --> Security Class Initialized
DEBUG - 2018-07-21 03:35:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 03:35:42 --> Input Class Initialized
INFO - 2018-07-21 03:35:42 --> Language Class Initialized
INFO - 2018-07-21 03:35:42 --> Language Class Initialized
INFO - 2018-07-21 03:35:42 --> Config Class Initialized
INFO - 2018-07-21 03:35:42 --> Loader Class Initialized
DEBUG - 2018-07-21 03:35:42 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-21 03:35:42 --> Helper loaded: url_helper
INFO - 2018-07-21 03:35:42 --> Helper loaded: form_helper
INFO - 2018-07-21 03:35:42 --> Helper loaded: date_helper
INFO - 2018-07-21 03:35:43 --> Helper loaded: util_helper
INFO - 2018-07-21 03:35:43 --> Helper loaded: text_helper
INFO - 2018-07-21 03:35:43 --> Helper loaded: string_helper
INFO - 2018-07-21 03:35:43 --> Database Driver Class Initialized
DEBUG - 2018-07-21 03:35:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-21 03:35:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-21 03:35:43 --> Email Class Initialized
INFO - 2018-07-21 03:35:43 --> Controller Class Initialized
DEBUG - 2018-07-21 03:35:43 --> Users MX_Controller Initialized
DEBUG - 2018-07-21 03:35:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-21 03:35:43 --> Helper loaded: file_helper
DEBUG - 2018-07-21 03:35:43 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-21 03:35:43 --> Login MX_Controller Initialized
INFO - 2018-07-21 03:35:43 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-21 03:35:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-21 03:35:43 --> Final output sent to browser
DEBUG - 2018-07-21 03:35:43 --> Total execution time: 0.3468
INFO - 2018-07-21 03:39:10 --> Config Class Initialized
INFO - 2018-07-21 03:39:10 --> Hooks Class Initialized
DEBUG - 2018-07-21 03:39:10 --> UTF-8 Support Enabled
INFO - 2018-07-21 03:39:10 --> Utf8 Class Initialized
INFO - 2018-07-21 03:39:10 --> URI Class Initialized
INFO - 2018-07-21 03:39:10 --> Router Class Initialized
INFO - 2018-07-21 03:39:10 --> Output Class Initialized
INFO - 2018-07-21 03:39:10 --> Security Class Initialized
DEBUG - 2018-07-21 03:39:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 03:39:10 --> Input Class Initialized
INFO - 2018-07-21 03:39:10 --> Language Class Initialized
INFO - 2018-07-21 03:39:10 --> Language Class Initialized
INFO - 2018-07-21 03:39:10 --> Config Class Initialized
INFO - 2018-07-21 03:39:10 --> Loader Class Initialized
DEBUG - 2018-07-21 03:39:10 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-21 03:39:10 --> Helper loaded: url_helper
INFO - 2018-07-21 03:39:10 --> Helper loaded: form_helper
INFO - 2018-07-21 03:39:10 --> Helper loaded: date_helper
INFO - 2018-07-21 03:39:10 --> Helper loaded: util_helper
INFO - 2018-07-21 03:39:10 --> Helper loaded: text_helper
INFO - 2018-07-21 03:39:10 --> Helper loaded: string_helper
INFO - 2018-07-21 03:39:10 --> Database Driver Class Initialized
DEBUG - 2018-07-21 03:39:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-21 03:39:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-21 03:39:10 --> Email Class Initialized
INFO - 2018-07-21 03:39:10 --> Controller Class Initialized
DEBUG - 2018-07-21 03:39:10 --> Users MX_Controller Initialized
DEBUG - 2018-07-21 03:39:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-21 03:39:10 --> Helper loaded: file_helper
DEBUG - 2018-07-21 03:39:10 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-21 03:39:10 --> Login MX_Controller Initialized
INFO - 2018-07-21 03:39:10 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-21 03:39:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-21 03:39:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
DEBUG - 2018-07-21 03:39:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-21 03:39:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-21 03:39:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-21 03:39:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-21 03:39:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-21 03:39:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-21 03:39:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/create_user.php
INFO - 2018-07-21 03:39:10 --> Final output sent to browser
DEBUG - 2018-07-21 03:39:11 --> Total execution time: 0.4525
INFO - 2018-07-21 03:39:20 --> Config Class Initialized
INFO - 2018-07-21 03:39:20 --> Hooks Class Initialized
DEBUG - 2018-07-21 03:39:20 --> UTF-8 Support Enabled
INFO - 2018-07-21 03:39:20 --> Utf8 Class Initialized
INFO - 2018-07-21 03:39:20 --> URI Class Initialized
INFO - 2018-07-21 03:39:20 --> Router Class Initialized
INFO - 2018-07-21 03:39:20 --> Output Class Initialized
INFO - 2018-07-21 03:39:20 --> Security Class Initialized
DEBUG - 2018-07-21 03:39:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 03:39:20 --> Input Class Initialized
INFO - 2018-07-21 03:39:20 --> Language Class Initialized
INFO - 2018-07-21 03:39:20 --> Language Class Initialized
INFO - 2018-07-21 03:39:20 --> Config Class Initialized
INFO - 2018-07-21 03:39:21 --> Loader Class Initialized
DEBUG - 2018-07-21 03:39:21 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-21 03:39:21 --> Helper loaded: url_helper
INFO - 2018-07-21 03:39:21 --> Helper loaded: form_helper
INFO - 2018-07-21 03:39:21 --> Helper loaded: date_helper
INFO - 2018-07-21 03:39:21 --> Helper loaded: util_helper
INFO - 2018-07-21 03:39:21 --> Helper loaded: text_helper
INFO - 2018-07-21 03:39:21 --> Helper loaded: string_helper
INFO - 2018-07-21 03:39:21 --> Database Driver Class Initialized
DEBUG - 2018-07-21 03:39:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-21 03:39:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-21 03:39:21 --> Email Class Initialized
INFO - 2018-07-21 03:39:21 --> Controller Class Initialized
DEBUG - 2018-07-21 03:39:21 --> Users MX_Controller Initialized
DEBUG - 2018-07-21 03:39:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-21 03:39:21 --> Helper loaded: file_helper
DEBUG - 2018-07-21 03:39:21 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-21 03:39:21 --> Login MX_Controller Initialized
INFO - 2018-07-21 03:39:21 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-21 03:39:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-21 03:39:21 --> Final output sent to browser
DEBUG - 2018-07-21 03:39:21 --> Total execution time: 0.3954
INFO - 2018-07-21 03:48:06 --> Config Class Initialized
INFO - 2018-07-21 03:48:06 --> Hooks Class Initialized
DEBUG - 2018-07-21 03:48:06 --> UTF-8 Support Enabled
INFO - 2018-07-21 03:48:06 --> Utf8 Class Initialized
INFO - 2018-07-21 03:48:06 --> URI Class Initialized
INFO - 2018-07-21 03:48:06 --> Router Class Initialized
INFO - 2018-07-21 03:48:06 --> Output Class Initialized
INFO - 2018-07-21 03:48:06 --> Security Class Initialized
DEBUG - 2018-07-21 03:48:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 03:48:06 --> Input Class Initialized
INFO - 2018-07-21 03:48:06 --> Language Class Initialized
INFO - 2018-07-21 03:48:06 --> Language Class Initialized
INFO - 2018-07-21 03:48:06 --> Config Class Initialized
INFO - 2018-07-21 03:48:06 --> Loader Class Initialized
DEBUG - 2018-07-21 03:48:06 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-21 03:48:06 --> Helper loaded: url_helper
INFO - 2018-07-21 03:48:06 --> Helper loaded: form_helper
INFO - 2018-07-21 03:48:07 --> Helper loaded: date_helper
INFO - 2018-07-21 03:48:07 --> Helper loaded: util_helper
INFO - 2018-07-21 03:48:07 --> Helper loaded: text_helper
INFO - 2018-07-21 03:48:07 --> Helper loaded: string_helper
INFO - 2018-07-21 03:48:07 --> Database Driver Class Initialized
DEBUG - 2018-07-21 03:48:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-21 03:48:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-21 03:48:07 --> Email Class Initialized
INFO - 2018-07-21 03:48:07 --> Controller Class Initialized
DEBUG - 2018-07-21 03:48:07 --> Users MX_Controller Initialized
DEBUG - 2018-07-21 03:48:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-21 03:48:07 --> Helper loaded: file_helper
DEBUG - 2018-07-21 03:48:07 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-21 03:48:07 --> Login MX_Controller Initialized
INFO - 2018-07-21 03:48:07 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-21 03:48:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-21 03:48:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
DEBUG - 2018-07-21 03:48:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-21 03:48:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-21 03:48:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-21 03:48:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-21 03:48:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-21 03:48:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-21 03:48:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/create_user.php
INFO - 2018-07-21 03:48:07 --> Final output sent to browser
DEBUG - 2018-07-21 03:48:07 --> Total execution time: 0.4299
INFO - 2018-07-21 03:48:09 --> Config Class Initialized
INFO - 2018-07-21 03:48:09 --> Hooks Class Initialized
DEBUG - 2018-07-21 03:48:09 --> UTF-8 Support Enabled
INFO - 2018-07-21 03:48:09 --> Utf8 Class Initialized
INFO - 2018-07-21 03:48:10 --> URI Class Initialized
INFO - 2018-07-21 03:48:10 --> Router Class Initialized
INFO - 2018-07-21 03:48:10 --> Output Class Initialized
INFO - 2018-07-21 03:48:10 --> Security Class Initialized
DEBUG - 2018-07-21 03:48:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 03:48:10 --> Input Class Initialized
INFO - 2018-07-21 03:48:10 --> Language Class Initialized
INFO - 2018-07-21 03:48:10 --> Language Class Initialized
INFO - 2018-07-21 03:48:10 --> Config Class Initialized
INFO - 2018-07-21 03:48:10 --> Loader Class Initialized
DEBUG - 2018-07-21 03:48:10 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-21 03:48:10 --> Helper loaded: url_helper
INFO - 2018-07-21 03:48:10 --> Helper loaded: form_helper
INFO - 2018-07-21 03:48:10 --> Helper loaded: date_helper
INFO - 2018-07-21 03:48:10 --> Helper loaded: util_helper
INFO - 2018-07-21 03:48:10 --> Helper loaded: text_helper
INFO - 2018-07-21 03:48:10 --> Helper loaded: string_helper
INFO - 2018-07-21 03:48:10 --> Database Driver Class Initialized
DEBUG - 2018-07-21 03:48:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-21 03:48:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-21 03:48:10 --> Email Class Initialized
INFO - 2018-07-21 03:48:10 --> Controller Class Initialized
DEBUG - 2018-07-21 03:48:10 --> Users MX_Controller Initialized
DEBUG - 2018-07-21 03:48:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-21 03:48:10 --> Helper loaded: file_helper
DEBUG - 2018-07-21 03:48:10 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-21 03:48:10 --> Login MX_Controller Initialized
INFO - 2018-07-21 03:48:10 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-21 03:48:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-21 03:48:10 --> Final output sent to browser
DEBUG - 2018-07-21 03:48:10 --> Total execution time: 0.3955
INFO - 2018-07-21 03:48:12 --> Config Class Initialized
INFO - 2018-07-21 03:48:12 --> Hooks Class Initialized
DEBUG - 2018-07-21 03:48:12 --> UTF-8 Support Enabled
INFO - 2018-07-21 03:48:12 --> Utf8 Class Initialized
INFO - 2018-07-21 03:48:12 --> URI Class Initialized
INFO - 2018-07-21 03:48:12 --> Router Class Initialized
INFO - 2018-07-21 03:48:12 --> Output Class Initialized
INFO - 2018-07-21 03:48:12 --> Security Class Initialized
DEBUG - 2018-07-21 03:48:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 03:48:12 --> Input Class Initialized
INFO - 2018-07-21 03:48:12 --> Language Class Initialized
INFO - 2018-07-21 03:48:12 --> Language Class Initialized
INFO - 2018-07-21 03:48:12 --> Config Class Initialized
INFO - 2018-07-21 03:48:12 --> Loader Class Initialized
DEBUG - 2018-07-21 03:48:12 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-21 03:48:12 --> Helper loaded: url_helper
INFO - 2018-07-21 03:48:12 --> Helper loaded: form_helper
INFO - 2018-07-21 03:48:12 --> Helper loaded: date_helper
INFO - 2018-07-21 03:48:12 --> Helper loaded: util_helper
INFO - 2018-07-21 03:48:12 --> Helper loaded: text_helper
INFO - 2018-07-21 03:48:12 --> Helper loaded: string_helper
INFO - 2018-07-21 03:48:12 --> Database Driver Class Initialized
DEBUG - 2018-07-21 03:48:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-21 03:48:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-21 03:48:12 --> Email Class Initialized
INFO - 2018-07-21 03:48:12 --> Controller Class Initialized
DEBUG - 2018-07-21 03:48:12 --> Users MX_Controller Initialized
DEBUG - 2018-07-21 03:48:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-21 03:48:12 --> Helper loaded: file_helper
DEBUG - 2018-07-21 03:48:12 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-21 03:48:12 --> Login MX_Controller Initialized
INFO - 2018-07-21 03:48:12 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-21 03:48:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-21 03:48:12 --> Final output sent to browser
DEBUG - 2018-07-21 03:48:12 --> Total execution time: 0.3935
INFO - 2018-07-21 03:48:46 --> Config Class Initialized
INFO - 2018-07-21 03:48:46 --> Hooks Class Initialized
DEBUG - 2018-07-21 03:48:46 --> UTF-8 Support Enabled
INFO - 2018-07-21 03:48:46 --> Utf8 Class Initialized
INFO - 2018-07-21 03:48:46 --> URI Class Initialized
INFO - 2018-07-21 03:48:46 --> Router Class Initialized
INFO - 2018-07-21 03:48:46 --> Output Class Initialized
INFO - 2018-07-21 03:48:46 --> Security Class Initialized
DEBUG - 2018-07-21 03:48:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 03:48:46 --> Input Class Initialized
INFO - 2018-07-21 03:48:46 --> Language Class Initialized
INFO - 2018-07-21 03:48:46 --> Language Class Initialized
INFO - 2018-07-21 03:48:46 --> Config Class Initialized
INFO - 2018-07-21 03:48:46 --> Loader Class Initialized
DEBUG - 2018-07-21 03:48:46 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-21 03:48:46 --> Helper loaded: url_helper
INFO - 2018-07-21 03:48:46 --> Helper loaded: form_helper
INFO - 2018-07-21 03:48:46 --> Helper loaded: date_helper
INFO - 2018-07-21 03:48:46 --> Helper loaded: util_helper
INFO - 2018-07-21 03:48:46 --> Helper loaded: text_helper
INFO - 2018-07-21 03:48:46 --> Helper loaded: string_helper
INFO - 2018-07-21 03:48:46 --> Database Driver Class Initialized
DEBUG - 2018-07-21 03:48:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-21 03:48:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-21 03:48:46 --> Email Class Initialized
INFO - 2018-07-21 03:48:46 --> Controller Class Initialized
DEBUG - 2018-07-21 03:48:46 --> Users MX_Controller Initialized
DEBUG - 2018-07-21 03:48:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-21 03:48:46 --> Helper loaded: file_helper
DEBUG - 2018-07-21 03:48:46 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-21 03:48:46 --> Login MX_Controller Initialized
INFO - 2018-07-21 03:48:46 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-21 03:48:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-21 03:48:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
DEBUG - 2018-07-21 03:48:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-21 03:48:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
INFO - 2018-07-21 03:48:46 --> Upload Class Initialized
ERROR - 2018-07-21 03:48:46 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\consulting\application\modules\admin\controllers\Users.php 171
INFO - 2018-07-21 03:48:46 --> Passsword for email - gopaltesting1@yopmail.com - is :: Testing6626
DEBUG - 2018-07-21 03:48:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/templates/credentials.php
DEBUG - 2018-07-21 03:48:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Mail_model.php
DEBUG - 2018-07-21 03:48:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/mail_view.php
INFO - 2018-07-21 03:48:46 --> Mail logged successfully
INFO - 2018-07-21 03:48:46 --> Config Class Initialized
INFO - 2018-07-21 03:48:46 --> Hooks Class Initialized
DEBUG - 2018-07-21 03:48:46 --> UTF-8 Support Enabled
INFO - 2018-07-21 03:48:46 --> Utf8 Class Initialized
INFO - 2018-07-21 03:48:46 --> URI Class Initialized
INFO - 2018-07-21 03:48:46 --> Router Class Initialized
INFO - 2018-07-21 03:48:46 --> Output Class Initialized
INFO - 2018-07-21 03:48:46 --> Security Class Initialized
DEBUG - 2018-07-21 03:48:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 03:48:46 --> Input Class Initialized
INFO - 2018-07-21 03:48:46 --> Language Class Initialized
INFO - 2018-07-21 03:48:46 --> Language Class Initialized
INFO - 2018-07-21 03:48:46 --> Config Class Initialized
INFO - 2018-07-21 03:48:46 --> Loader Class Initialized
DEBUG - 2018-07-21 03:48:46 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-21 03:48:46 --> Helper loaded: url_helper
INFO - 2018-07-21 03:48:46 --> Helper loaded: form_helper
INFO - 2018-07-21 03:48:46 --> Helper loaded: date_helper
INFO - 2018-07-21 03:48:46 --> Helper loaded: util_helper
INFO - 2018-07-21 03:48:46 --> Helper loaded: text_helper
INFO - 2018-07-21 03:48:46 --> Helper loaded: string_helper
INFO - 2018-07-21 03:48:46 --> Database Driver Class Initialized
DEBUG - 2018-07-21 03:48:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-21 03:48:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-21 03:48:46 --> Email Class Initialized
INFO - 2018-07-21 03:48:46 --> Controller Class Initialized
DEBUG - 2018-07-21 03:48:46 --> Users MX_Controller Initialized
DEBUG - 2018-07-21 03:48:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-21 03:48:47 --> Helper loaded: file_helper
DEBUG - 2018-07-21 03:48:47 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-21 03:48:47 --> Login MX_Controller Initialized
INFO - 2018-07-21 03:48:47 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-21 03:48:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-21 03:48:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-21 03:48:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-21 03:48:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-21 03:48:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-21 03:48:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-21 03:48:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/users.php
INFO - 2018-07-21 03:48:47 --> Final output sent to browser
DEBUG - 2018-07-21 03:48:47 --> Total execution time: 0.4068
INFO - 2018-07-21 03:48:47 --> Config Class Initialized
INFO - 2018-07-21 03:48:47 --> Hooks Class Initialized
DEBUG - 2018-07-21 03:48:47 --> UTF-8 Support Enabled
INFO - 2018-07-21 03:48:47 --> Utf8 Class Initialized
INFO - 2018-07-21 03:48:47 --> URI Class Initialized
INFO - 2018-07-21 03:48:47 --> Router Class Initialized
INFO - 2018-07-21 03:48:47 --> Output Class Initialized
INFO - 2018-07-21 03:48:47 --> Security Class Initialized
DEBUG - 2018-07-21 03:48:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 03:48:47 --> Input Class Initialized
INFO - 2018-07-21 03:48:47 --> Language Class Initialized
INFO - 2018-07-21 03:48:47 --> Language Class Initialized
INFO - 2018-07-21 03:48:47 --> Config Class Initialized
INFO - 2018-07-21 03:48:47 --> Loader Class Initialized
DEBUG - 2018-07-21 03:48:47 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-21 03:48:47 --> Helper loaded: url_helper
INFO - 2018-07-21 03:48:47 --> Helper loaded: form_helper
INFO - 2018-07-21 03:48:47 --> Helper loaded: date_helper
INFO - 2018-07-21 03:48:47 --> Helper loaded: util_helper
INFO - 2018-07-21 03:48:47 --> Helper loaded: text_helper
INFO - 2018-07-21 03:48:47 --> Helper loaded: string_helper
INFO - 2018-07-21 03:48:47 --> Database Driver Class Initialized
DEBUG - 2018-07-21 03:48:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-21 03:48:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-21 03:48:47 --> Email Class Initialized
INFO - 2018-07-21 03:48:47 --> Controller Class Initialized
DEBUG - 2018-07-21 03:48:47 --> Users MX_Controller Initialized
DEBUG - 2018-07-21 03:48:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-21 03:48:47 --> Helper loaded: file_helper
DEBUG - 2018-07-21 03:48:47 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-21 03:48:47 --> Login MX_Controller Initialized
INFO - 2018-07-21 03:48:47 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-21 03:48:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-21 03:48:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-07-21 03:48:48 --> Final output sent to browser
DEBUG - 2018-07-21 03:48:48 --> Total execution time: 0.4842
INFO - 2018-07-21 03:55:17 --> Config Class Initialized
INFO - 2018-07-21 03:55:17 --> Hooks Class Initialized
DEBUG - 2018-07-21 03:55:17 --> UTF-8 Support Enabled
INFO - 2018-07-21 03:55:17 --> Utf8 Class Initialized
INFO - 2018-07-21 03:55:17 --> URI Class Initialized
INFO - 2018-07-21 03:55:17 --> Router Class Initialized
INFO - 2018-07-21 03:55:17 --> Output Class Initialized
INFO - 2018-07-21 03:55:17 --> Security Class Initialized
DEBUG - 2018-07-21 03:55:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 03:55:17 --> Input Class Initialized
INFO - 2018-07-21 03:55:17 --> Language Class Initialized
INFO - 2018-07-21 03:55:17 --> Language Class Initialized
INFO - 2018-07-21 03:55:17 --> Config Class Initialized
INFO - 2018-07-21 03:55:17 --> Loader Class Initialized
DEBUG - 2018-07-21 03:55:17 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-21 03:55:17 --> Helper loaded: url_helper
INFO - 2018-07-21 03:55:17 --> Helper loaded: form_helper
INFO - 2018-07-21 03:55:17 --> Helper loaded: date_helper
INFO - 2018-07-21 03:55:17 --> Helper loaded: util_helper
INFO - 2018-07-21 03:55:17 --> Helper loaded: text_helper
INFO - 2018-07-21 03:55:17 --> Helper loaded: string_helper
INFO - 2018-07-21 03:55:17 --> Database Driver Class Initialized
DEBUG - 2018-07-21 03:55:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-21 03:55:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-21 03:55:17 --> Email Class Initialized
INFO - 2018-07-21 03:55:17 --> Controller Class Initialized
DEBUG - 2018-07-21 03:55:17 --> Home MX_Controller Initialized
DEBUG - 2018-07-21 03:55:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-21 03:55:17 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-21 03:55:17 --> Login MX_Controller Initialized
INFO - 2018-07-21 03:55:17 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-21 03:55:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-21 03:55:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-21 03:55:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/login.php
INFO - 2018-07-21 03:58:20 --> Config Class Initialized
INFO - 2018-07-21 03:58:20 --> Hooks Class Initialized
DEBUG - 2018-07-21 03:58:20 --> UTF-8 Support Enabled
INFO - 2018-07-21 03:58:20 --> Utf8 Class Initialized
INFO - 2018-07-21 03:58:20 --> URI Class Initialized
INFO - 2018-07-21 03:58:20 --> Router Class Initialized
INFO - 2018-07-21 03:58:20 --> Output Class Initialized
INFO - 2018-07-21 03:58:20 --> Security Class Initialized
DEBUG - 2018-07-21 03:58:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 03:58:20 --> Input Class Initialized
INFO - 2018-07-21 03:58:20 --> Language Class Initialized
INFO - 2018-07-21 03:58:20 --> Language Class Initialized
INFO - 2018-07-21 03:58:20 --> Config Class Initialized
INFO - 2018-07-21 03:58:20 --> Loader Class Initialized
DEBUG - 2018-07-21 03:58:20 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-21 03:58:20 --> Helper loaded: url_helper
INFO - 2018-07-21 03:58:20 --> Helper loaded: form_helper
INFO - 2018-07-21 03:58:20 --> Helper loaded: date_helper
INFO - 2018-07-21 03:58:20 --> Helper loaded: util_helper
INFO - 2018-07-21 03:58:20 --> Helper loaded: text_helper
INFO - 2018-07-21 03:58:20 --> Helper loaded: string_helper
INFO - 2018-07-21 03:58:20 --> Database Driver Class Initialized
DEBUG - 2018-07-21 03:58:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-21 03:58:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-21 03:58:20 --> Email Class Initialized
INFO - 2018-07-21 03:58:20 --> Controller Class Initialized
DEBUG - 2018-07-21 03:58:20 --> Users MX_Controller Initialized
DEBUG - 2018-07-21 03:58:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-21 03:58:20 --> Helper loaded: file_helper
DEBUG - 2018-07-21 03:58:20 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-21 03:58:20 --> Login MX_Controller Initialized
INFO - 2018-07-21 03:58:20 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-21 03:58:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-21 03:58:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
DEBUG - 2018-07-21 03:58:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-21 03:58:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-21 03:58:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-21 03:58:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-21 03:58:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-21 03:58:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-21 03:58:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/create_user.php
INFO - 2018-07-21 03:58:20 --> Final output sent to browser
DEBUG - 2018-07-21 03:58:21 --> Total execution time: 0.4376
INFO - 2018-07-21 03:58:25 --> Config Class Initialized
INFO - 2018-07-21 03:58:25 --> Hooks Class Initialized
DEBUG - 2018-07-21 03:58:25 --> UTF-8 Support Enabled
INFO - 2018-07-21 03:58:25 --> Utf8 Class Initialized
INFO - 2018-07-21 03:58:25 --> URI Class Initialized
INFO - 2018-07-21 03:58:25 --> Router Class Initialized
INFO - 2018-07-21 03:58:25 --> Output Class Initialized
INFO - 2018-07-21 03:58:25 --> Security Class Initialized
DEBUG - 2018-07-21 03:58:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 03:58:25 --> Input Class Initialized
INFO - 2018-07-21 03:58:25 --> Language Class Initialized
INFO - 2018-07-21 03:58:25 --> Language Class Initialized
INFO - 2018-07-21 03:58:25 --> Config Class Initialized
INFO - 2018-07-21 03:58:25 --> Loader Class Initialized
DEBUG - 2018-07-21 03:58:25 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-21 03:58:25 --> Helper loaded: url_helper
INFO - 2018-07-21 03:58:25 --> Helper loaded: form_helper
INFO - 2018-07-21 03:58:25 --> Helper loaded: date_helper
INFO - 2018-07-21 03:58:25 --> Helper loaded: util_helper
INFO - 2018-07-21 03:58:25 --> Helper loaded: text_helper
INFO - 2018-07-21 03:58:25 --> Helper loaded: string_helper
INFO - 2018-07-21 03:58:25 --> Database Driver Class Initialized
DEBUG - 2018-07-21 03:58:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-21 03:58:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-21 03:58:25 --> Email Class Initialized
INFO - 2018-07-21 03:58:25 --> Controller Class Initialized
DEBUG - 2018-07-21 03:58:25 --> Users MX_Controller Initialized
DEBUG - 2018-07-21 03:58:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-21 03:58:25 --> Helper loaded: file_helper
DEBUG - 2018-07-21 03:58:25 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-21 03:58:25 --> Login MX_Controller Initialized
INFO - 2018-07-21 03:58:25 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-21 03:58:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-21 03:58:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
DEBUG - 2018-07-21 03:58:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-21 03:58:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-21 03:58:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-21 03:58:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-21 03:58:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-21 03:58:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-21 03:58:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/create_user.php
INFO - 2018-07-21 03:58:25 --> Final output sent to browser
DEBUG - 2018-07-21 03:58:25 --> Total execution time: 0.5507
INFO - 2018-07-21 03:58:28 --> Config Class Initialized
INFO - 2018-07-21 03:58:28 --> Hooks Class Initialized
DEBUG - 2018-07-21 03:58:28 --> UTF-8 Support Enabled
INFO - 2018-07-21 03:58:28 --> Utf8 Class Initialized
INFO - 2018-07-21 03:58:28 --> URI Class Initialized
INFO - 2018-07-21 03:58:28 --> Router Class Initialized
INFO - 2018-07-21 03:58:28 --> Output Class Initialized
INFO - 2018-07-21 03:58:28 --> Security Class Initialized
DEBUG - 2018-07-21 03:58:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 03:58:28 --> Input Class Initialized
INFO - 2018-07-21 03:58:28 --> Language Class Initialized
INFO - 2018-07-21 03:58:28 --> Language Class Initialized
INFO - 2018-07-21 03:58:28 --> Config Class Initialized
INFO - 2018-07-21 03:58:28 --> Loader Class Initialized
DEBUG - 2018-07-21 03:58:28 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-21 03:58:28 --> Helper loaded: url_helper
INFO - 2018-07-21 03:58:28 --> Helper loaded: form_helper
INFO - 2018-07-21 03:58:28 --> Helper loaded: date_helper
INFO - 2018-07-21 03:58:28 --> Helper loaded: util_helper
INFO - 2018-07-21 03:58:28 --> Helper loaded: text_helper
INFO - 2018-07-21 03:58:28 --> Helper loaded: string_helper
INFO - 2018-07-21 03:58:29 --> Database Driver Class Initialized
DEBUG - 2018-07-21 03:58:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-21 03:58:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-21 03:58:29 --> Email Class Initialized
INFO - 2018-07-21 03:58:29 --> Controller Class Initialized
DEBUG - 2018-07-21 03:58:29 --> Users MX_Controller Initialized
DEBUG - 2018-07-21 03:58:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-21 03:58:29 --> Helper loaded: file_helper
DEBUG - 2018-07-21 03:58:29 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-21 03:58:29 --> Login MX_Controller Initialized
INFO - 2018-07-21 03:58:29 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-21 03:58:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-21 03:58:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
DEBUG - 2018-07-21 03:58:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-21 03:58:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-21 03:58:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-21 03:58:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-21 03:58:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-21 03:58:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-21 03:58:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/create_user.php
INFO - 2018-07-21 03:58:29 --> Final output sent to browser
DEBUG - 2018-07-21 03:58:29 --> Total execution time: 0.5375
INFO - 2018-07-21 04:23:09 --> Config Class Initialized
INFO - 2018-07-21 04:23:09 --> Hooks Class Initialized
DEBUG - 2018-07-21 04:23:09 --> UTF-8 Support Enabled
INFO - 2018-07-21 04:23:09 --> Utf8 Class Initialized
INFO - 2018-07-21 04:23:09 --> URI Class Initialized
INFO - 2018-07-21 04:23:09 --> Router Class Initialized
INFO - 2018-07-21 04:23:09 --> Output Class Initialized
INFO - 2018-07-21 04:23:09 --> Security Class Initialized
DEBUG - 2018-07-21 04:23:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 04:23:09 --> Input Class Initialized
INFO - 2018-07-21 04:23:09 --> Language Class Initialized
INFO - 2018-07-21 04:23:09 --> Language Class Initialized
INFO - 2018-07-21 04:23:09 --> Config Class Initialized
INFO - 2018-07-21 04:23:09 --> Loader Class Initialized
DEBUG - 2018-07-21 04:23:09 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-21 04:23:09 --> Helper loaded: url_helper
INFO - 2018-07-21 04:23:09 --> Helper loaded: form_helper
INFO - 2018-07-21 04:23:09 --> Helper loaded: date_helper
INFO - 2018-07-21 04:23:09 --> Helper loaded: util_helper
INFO - 2018-07-21 04:23:09 --> Helper loaded: text_helper
INFO - 2018-07-21 04:23:09 --> Helper loaded: string_helper
INFO - 2018-07-21 04:23:09 --> Database Driver Class Initialized
DEBUG - 2018-07-21 04:23:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-21 04:23:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-21 04:23:09 --> Email Class Initialized
INFO - 2018-07-21 04:23:09 --> Controller Class Initialized
DEBUG - 2018-07-21 04:23:09 --> Users MX_Controller Initialized
DEBUG - 2018-07-21 04:23:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-21 04:23:09 --> Helper loaded: file_helper
DEBUG - 2018-07-21 04:23:09 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-21 04:23:09 --> Login MX_Controller Initialized
INFO - 2018-07-21 04:23:09 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-21 04:23:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-21 04:23:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
DEBUG - 2018-07-21 04:23:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-21 04:23:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-21 04:23:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-21 04:23:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-21 04:23:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-21 04:23:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-21 04:23:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/create_user.php
INFO - 2018-07-21 04:23:09 --> Final output sent to browser
DEBUG - 2018-07-21 04:23:09 --> Total execution time: 0.4740
INFO - 2018-07-21 04:25:29 --> Config Class Initialized
INFO - 2018-07-21 04:25:29 --> Hooks Class Initialized
DEBUG - 2018-07-21 04:25:29 --> UTF-8 Support Enabled
INFO - 2018-07-21 04:25:29 --> Utf8 Class Initialized
INFO - 2018-07-21 04:25:29 --> URI Class Initialized
INFO - 2018-07-21 04:25:29 --> Router Class Initialized
INFO - 2018-07-21 04:25:29 --> Output Class Initialized
INFO - 2018-07-21 04:25:29 --> Security Class Initialized
DEBUG - 2018-07-21 04:25:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 04:25:29 --> Input Class Initialized
INFO - 2018-07-21 04:25:29 --> Language Class Initialized
INFO - 2018-07-21 04:25:29 --> Language Class Initialized
INFO - 2018-07-21 04:25:29 --> Config Class Initialized
INFO - 2018-07-21 04:25:29 --> Loader Class Initialized
DEBUG - 2018-07-21 04:25:29 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-21 04:25:29 --> Helper loaded: url_helper
INFO - 2018-07-21 04:25:30 --> Helper loaded: form_helper
INFO - 2018-07-21 04:25:30 --> Helper loaded: date_helper
INFO - 2018-07-21 04:25:30 --> Helper loaded: util_helper
INFO - 2018-07-21 04:25:30 --> Helper loaded: text_helper
INFO - 2018-07-21 04:25:30 --> Helper loaded: string_helper
INFO - 2018-07-21 04:25:30 --> Database Driver Class Initialized
DEBUG - 2018-07-21 04:25:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-21 04:25:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-21 04:25:30 --> Email Class Initialized
INFO - 2018-07-21 04:25:30 --> Controller Class Initialized
DEBUG - 2018-07-21 04:25:30 --> Users MX_Controller Initialized
DEBUG - 2018-07-21 04:25:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-21 04:25:30 --> Helper loaded: file_helper
DEBUG - 2018-07-21 04:25:30 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-21 04:25:30 --> Login MX_Controller Initialized
INFO - 2018-07-21 04:25:30 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-21 04:25:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-21 04:25:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
DEBUG - 2018-07-21 04:25:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-21 04:25:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-21 04:25:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-21 04:25:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-21 04:25:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-21 04:25:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-21 04:25:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/create_user.php
INFO - 2018-07-21 04:25:30 --> Final output sent to browser
DEBUG - 2018-07-21 04:25:30 --> Total execution time: 0.4851
INFO - 2018-07-21 04:27:06 --> Config Class Initialized
INFO - 2018-07-21 04:27:06 --> Hooks Class Initialized
DEBUG - 2018-07-21 04:27:06 --> UTF-8 Support Enabled
INFO - 2018-07-21 04:27:06 --> Utf8 Class Initialized
INFO - 2018-07-21 04:27:06 --> URI Class Initialized
INFO - 2018-07-21 04:27:06 --> Router Class Initialized
INFO - 2018-07-21 04:27:06 --> Output Class Initialized
INFO - 2018-07-21 04:27:06 --> Security Class Initialized
DEBUG - 2018-07-21 04:27:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 04:27:06 --> Input Class Initialized
INFO - 2018-07-21 04:27:06 --> Language Class Initialized
INFO - 2018-07-21 04:27:06 --> Language Class Initialized
INFO - 2018-07-21 04:27:06 --> Config Class Initialized
INFO - 2018-07-21 04:27:06 --> Loader Class Initialized
DEBUG - 2018-07-21 04:27:06 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-21 04:27:06 --> Helper loaded: url_helper
INFO - 2018-07-21 04:27:06 --> Helper loaded: form_helper
INFO - 2018-07-21 04:27:06 --> Helper loaded: date_helper
INFO - 2018-07-21 04:27:06 --> Helper loaded: util_helper
INFO - 2018-07-21 04:27:06 --> Helper loaded: text_helper
INFO - 2018-07-21 04:27:06 --> Helper loaded: string_helper
INFO - 2018-07-21 04:27:06 --> Database Driver Class Initialized
DEBUG - 2018-07-21 04:27:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-21 04:27:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-21 04:27:06 --> Email Class Initialized
INFO - 2018-07-21 04:27:06 --> Controller Class Initialized
DEBUG - 2018-07-21 04:27:06 --> Users MX_Controller Initialized
DEBUG - 2018-07-21 04:27:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-21 04:27:06 --> Helper loaded: file_helper
DEBUG - 2018-07-21 04:27:06 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-21 04:27:06 --> Login MX_Controller Initialized
INFO - 2018-07-21 04:27:06 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-21 04:27:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-21 04:27:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
DEBUG - 2018-07-21 04:27:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-21 04:27:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-21 04:27:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-21 04:27:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-21 04:27:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-21 04:27:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-21 04:27:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/create_user.php
INFO - 2018-07-21 04:27:06 --> Final output sent to browser
DEBUG - 2018-07-21 04:27:06 --> Total execution time: 0.4708
INFO - 2018-07-21 04:27:18 --> Config Class Initialized
INFO - 2018-07-21 04:27:18 --> Hooks Class Initialized
DEBUG - 2018-07-21 04:27:18 --> UTF-8 Support Enabled
INFO - 2018-07-21 04:27:18 --> Utf8 Class Initialized
INFO - 2018-07-21 04:27:18 --> URI Class Initialized
INFO - 2018-07-21 04:27:18 --> Router Class Initialized
INFO - 2018-07-21 04:27:18 --> Output Class Initialized
INFO - 2018-07-21 04:27:18 --> Security Class Initialized
DEBUG - 2018-07-21 04:27:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 04:27:18 --> Input Class Initialized
INFO - 2018-07-21 04:27:18 --> Language Class Initialized
INFO - 2018-07-21 04:27:18 --> Language Class Initialized
INFO - 2018-07-21 04:27:18 --> Config Class Initialized
INFO - 2018-07-21 04:27:19 --> Loader Class Initialized
DEBUG - 2018-07-21 04:27:19 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-21 04:27:19 --> Helper loaded: url_helper
INFO - 2018-07-21 04:27:19 --> Helper loaded: form_helper
INFO - 2018-07-21 04:27:19 --> Helper loaded: date_helper
INFO - 2018-07-21 04:27:19 --> Helper loaded: util_helper
INFO - 2018-07-21 04:27:19 --> Helper loaded: text_helper
INFO - 2018-07-21 04:27:19 --> Helper loaded: string_helper
INFO - 2018-07-21 04:27:19 --> Database Driver Class Initialized
DEBUG - 2018-07-21 04:27:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-21 04:27:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-21 04:27:19 --> Email Class Initialized
INFO - 2018-07-21 04:27:19 --> Controller Class Initialized
DEBUG - 2018-07-21 04:27:19 --> Users MX_Controller Initialized
DEBUG - 2018-07-21 04:27:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-21 04:27:19 --> Helper loaded: file_helper
DEBUG - 2018-07-21 04:27:19 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-21 04:27:19 --> Login MX_Controller Initialized
INFO - 2018-07-21 04:27:19 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-21 04:27:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-21 04:27:19 --> Final output sent to browser
DEBUG - 2018-07-21 04:27:19 --> Total execution time: 0.3989
INFO - 2018-07-21 04:27:21 --> Config Class Initialized
INFO - 2018-07-21 04:27:21 --> Hooks Class Initialized
DEBUG - 2018-07-21 04:27:21 --> UTF-8 Support Enabled
INFO - 2018-07-21 04:27:21 --> Utf8 Class Initialized
INFO - 2018-07-21 04:27:21 --> URI Class Initialized
INFO - 2018-07-21 04:27:21 --> Router Class Initialized
INFO - 2018-07-21 04:27:21 --> Output Class Initialized
INFO - 2018-07-21 04:27:21 --> Security Class Initialized
DEBUG - 2018-07-21 04:27:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 04:27:21 --> Input Class Initialized
INFO - 2018-07-21 04:27:21 --> Language Class Initialized
INFO - 2018-07-21 04:27:21 --> Language Class Initialized
INFO - 2018-07-21 04:27:21 --> Config Class Initialized
INFO - 2018-07-21 04:27:21 --> Loader Class Initialized
DEBUG - 2018-07-21 04:27:21 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-21 04:27:21 --> Helper loaded: url_helper
INFO - 2018-07-21 04:27:21 --> Helper loaded: form_helper
INFO - 2018-07-21 04:27:21 --> Helper loaded: date_helper
INFO - 2018-07-21 04:27:21 --> Helper loaded: util_helper
INFO - 2018-07-21 04:27:21 --> Helper loaded: text_helper
INFO - 2018-07-21 04:27:21 --> Helper loaded: string_helper
INFO - 2018-07-21 04:27:21 --> Database Driver Class Initialized
DEBUG - 2018-07-21 04:27:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-21 04:27:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-21 04:27:21 --> Email Class Initialized
INFO - 2018-07-21 04:27:21 --> Controller Class Initialized
DEBUG - 2018-07-21 04:27:21 --> Users MX_Controller Initialized
DEBUG - 2018-07-21 04:27:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-21 04:27:21 --> Helper loaded: file_helper
DEBUG - 2018-07-21 04:27:21 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-21 04:27:21 --> Login MX_Controller Initialized
INFO - 2018-07-21 04:27:21 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-21 04:27:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-21 04:27:21 --> Final output sent to browser
DEBUG - 2018-07-21 04:27:21 --> Total execution time: 0.4128
INFO - 2018-07-21 04:27:32 --> Config Class Initialized
INFO - 2018-07-21 04:27:32 --> Hooks Class Initialized
DEBUG - 2018-07-21 04:27:32 --> UTF-8 Support Enabled
INFO - 2018-07-21 04:27:32 --> Utf8 Class Initialized
INFO - 2018-07-21 04:27:32 --> URI Class Initialized
INFO - 2018-07-21 04:27:32 --> Router Class Initialized
INFO - 2018-07-21 04:27:32 --> Output Class Initialized
INFO - 2018-07-21 04:27:32 --> Security Class Initialized
DEBUG - 2018-07-21 04:27:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 04:27:32 --> Input Class Initialized
INFO - 2018-07-21 04:27:32 --> Language Class Initialized
INFO - 2018-07-21 04:27:32 --> Language Class Initialized
INFO - 2018-07-21 04:27:32 --> Config Class Initialized
INFO - 2018-07-21 04:27:32 --> Loader Class Initialized
DEBUG - 2018-07-21 04:27:32 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-21 04:27:32 --> Helper loaded: url_helper
INFO - 2018-07-21 04:27:32 --> Helper loaded: form_helper
INFO - 2018-07-21 04:27:32 --> Helper loaded: date_helper
INFO - 2018-07-21 04:27:32 --> Helper loaded: util_helper
INFO - 2018-07-21 04:27:32 --> Helper loaded: text_helper
INFO - 2018-07-21 04:27:32 --> Helper loaded: string_helper
INFO - 2018-07-21 04:27:32 --> Database Driver Class Initialized
DEBUG - 2018-07-21 04:27:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-21 04:27:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-21 04:27:32 --> Email Class Initialized
INFO - 2018-07-21 04:27:32 --> Controller Class Initialized
DEBUG - 2018-07-21 04:27:32 --> Users MX_Controller Initialized
DEBUG - 2018-07-21 04:27:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-21 04:27:32 --> Helper loaded: file_helper
DEBUG - 2018-07-21 04:27:32 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-21 04:27:32 --> Login MX_Controller Initialized
INFO - 2018-07-21 04:27:32 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-21 04:27:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-21 04:27:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-21 04:27:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-21 04:27:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-21 04:27:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-21 04:27:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-21 04:27:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/users.php
INFO - 2018-07-21 04:27:32 --> Final output sent to browser
DEBUG - 2018-07-21 04:27:32 --> Total execution time: 0.5649
INFO - 2018-07-21 04:27:33 --> Config Class Initialized
INFO - 2018-07-21 04:27:33 --> Hooks Class Initialized
DEBUG - 2018-07-21 04:27:33 --> UTF-8 Support Enabled
INFO - 2018-07-21 04:27:33 --> Utf8 Class Initialized
INFO - 2018-07-21 04:27:33 --> URI Class Initialized
INFO - 2018-07-21 04:27:33 --> Router Class Initialized
INFO - 2018-07-21 04:27:33 --> Output Class Initialized
INFO - 2018-07-21 04:27:33 --> Security Class Initialized
DEBUG - 2018-07-21 04:27:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 04:27:33 --> Input Class Initialized
INFO - 2018-07-21 04:27:33 --> Language Class Initialized
INFO - 2018-07-21 04:27:33 --> Language Class Initialized
INFO - 2018-07-21 04:27:33 --> Config Class Initialized
INFO - 2018-07-21 04:27:33 --> Loader Class Initialized
DEBUG - 2018-07-21 04:27:33 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-21 04:27:33 --> Helper loaded: url_helper
INFO - 2018-07-21 04:27:33 --> Helper loaded: form_helper
INFO - 2018-07-21 04:27:33 --> Helper loaded: date_helper
INFO - 2018-07-21 04:27:33 --> Helper loaded: util_helper
INFO - 2018-07-21 04:27:33 --> Helper loaded: text_helper
INFO - 2018-07-21 04:27:33 --> Helper loaded: string_helper
INFO - 2018-07-21 04:27:33 --> Database Driver Class Initialized
DEBUG - 2018-07-21 04:27:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-21 04:27:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-21 04:27:33 --> Email Class Initialized
INFO - 2018-07-21 04:27:33 --> Controller Class Initialized
DEBUG - 2018-07-21 04:27:33 --> Users MX_Controller Initialized
DEBUG - 2018-07-21 04:27:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-21 04:27:33 --> Helper loaded: file_helper
DEBUG - 2018-07-21 04:27:33 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-21 04:27:33 --> Login MX_Controller Initialized
INFO - 2018-07-21 04:27:33 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-21 04:27:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-21 04:27:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-07-21 04:27:33 --> Final output sent to browser
DEBUG - 2018-07-21 04:27:33 --> Total execution time: 0.5135
INFO - 2018-07-21 04:27:45 --> Config Class Initialized
INFO - 2018-07-21 04:27:45 --> Hooks Class Initialized
DEBUG - 2018-07-21 04:27:45 --> UTF-8 Support Enabled
INFO - 2018-07-21 04:27:45 --> Utf8 Class Initialized
INFO - 2018-07-21 04:27:45 --> URI Class Initialized
INFO - 2018-07-21 04:27:45 --> Router Class Initialized
INFO - 2018-07-21 04:27:45 --> Output Class Initialized
INFO - 2018-07-21 04:27:45 --> Security Class Initialized
DEBUG - 2018-07-21 04:27:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 04:27:45 --> Input Class Initialized
INFO - 2018-07-21 04:27:45 --> Language Class Initialized
INFO - 2018-07-21 04:27:45 --> Language Class Initialized
INFO - 2018-07-21 04:27:45 --> Config Class Initialized
INFO - 2018-07-21 04:27:45 --> Loader Class Initialized
DEBUG - 2018-07-21 04:27:45 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-21 04:27:45 --> Helper loaded: url_helper
INFO - 2018-07-21 04:27:45 --> Helper loaded: form_helper
INFO - 2018-07-21 04:27:45 --> Helper loaded: date_helper
INFO - 2018-07-21 04:27:45 --> Helper loaded: util_helper
INFO - 2018-07-21 04:27:45 --> Helper loaded: text_helper
INFO - 2018-07-21 04:27:45 --> Helper loaded: string_helper
INFO - 2018-07-21 04:27:45 --> Database Driver Class Initialized
DEBUG - 2018-07-21 04:27:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-21 04:27:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-21 04:27:45 --> Email Class Initialized
INFO - 2018-07-21 04:27:45 --> Controller Class Initialized
DEBUG - 2018-07-21 04:27:45 --> Admin MX_Controller Initialized
INFO - 2018-07-21 04:27:45 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-21 04:27:45 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-21 04:27:45 --> Login MX_Controller Initialized
DEBUG - 2018-07-21 04:27:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-21 04:27:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-21 04:27:45 --> Final output sent to browser
DEBUG - 2018-07-21 04:27:45 --> Total execution time: 0.4828
INFO - 2018-07-21 04:27:49 --> Config Class Initialized
INFO - 2018-07-21 04:27:49 --> Hooks Class Initialized
DEBUG - 2018-07-21 04:27:49 --> UTF-8 Support Enabled
INFO - 2018-07-21 04:27:49 --> Utf8 Class Initialized
INFO - 2018-07-21 04:27:49 --> URI Class Initialized
INFO - 2018-07-21 04:27:49 --> Router Class Initialized
INFO - 2018-07-21 04:27:50 --> Output Class Initialized
INFO - 2018-07-21 04:27:50 --> Security Class Initialized
DEBUG - 2018-07-21 04:27:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 04:27:50 --> Input Class Initialized
INFO - 2018-07-21 04:27:50 --> Language Class Initialized
INFO - 2018-07-21 04:27:50 --> Language Class Initialized
INFO - 2018-07-21 04:27:50 --> Config Class Initialized
INFO - 2018-07-21 04:27:50 --> Loader Class Initialized
DEBUG - 2018-07-21 04:27:50 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-21 04:27:50 --> Helper loaded: url_helper
INFO - 2018-07-21 04:27:50 --> Helper loaded: form_helper
INFO - 2018-07-21 04:27:50 --> Helper loaded: date_helper
INFO - 2018-07-21 04:27:50 --> Helper loaded: util_helper
INFO - 2018-07-21 04:27:50 --> Helper loaded: text_helper
INFO - 2018-07-21 04:27:50 --> Helper loaded: string_helper
INFO - 2018-07-21 04:27:50 --> Database Driver Class Initialized
DEBUG - 2018-07-21 04:27:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-21 04:27:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-21 04:27:50 --> Email Class Initialized
INFO - 2018-07-21 04:27:50 --> Controller Class Initialized
DEBUG - 2018-07-21 04:27:50 --> Users MX_Controller Initialized
DEBUG - 2018-07-21 04:27:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-21 04:27:50 --> Helper loaded: file_helper
DEBUG - 2018-07-21 04:27:50 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-21 04:27:50 --> Login MX_Controller Initialized
INFO - 2018-07-21 04:27:50 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-21 04:27:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-21 04:27:50 --> Final output sent to browser
DEBUG - 2018-07-21 04:27:50 --> Total execution time: 0.3988
INFO - 2018-07-21 04:27:51 --> Config Class Initialized
INFO - 2018-07-21 04:27:51 --> Hooks Class Initialized
DEBUG - 2018-07-21 04:27:51 --> UTF-8 Support Enabled
INFO - 2018-07-21 04:27:51 --> Utf8 Class Initialized
INFO - 2018-07-21 04:27:51 --> URI Class Initialized
INFO - 2018-07-21 04:27:51 --> Router Class Initialized
INFO - 2018-07-21 04:27:51 --> Output Class Initialized
INFO - 2018-07-21 04:27:51 --> Security Class Initialized
DEBUG - 2018-07-21 04:27:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 04:27:51 --> Input Class Initialized
INFO - 2018-07-21 04:27:51 --> Language Class Initialized
INFO - 2018-07-21 04:27:51 --> Language Class Initialized
INFO - 2018-07-21 04:27:51 --> Config Class Initialized
INFO - 2018-07-21 04:27:51 --> Loader Class Initialized
DEBUG - 2018-07-21 04:27:51 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-21 04:27:51 --> Helper loaded: url_helper
INFO - 2018-07-21 04:27:51 --> Helper loaded: form_helper
INFO - 2018-07-21 04:27:51 --> Helper loaded: date_helper
INFO - 2018-07-21 04:27:51 --> Helper loaded: util_helper
INFO - 2018-07-21 04:27:51 --> Helper loaded: text_helper
INFO - 2018-07-21 04:27:51 --> Helper loaded: string_helper
INFO - 2018-07-21 04:27:51 --> Database Driver Class Initialized
DEBUG - 2018-07-21 04:27:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-21 04:27:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-21 04:27:51 --> Email Class Initialized
INFO - 2018-07-21 04:27:51 --> Controller Class Initialized
DEBUG - 2018-07-21 04:27:51 --> Users MX_Controller Initialized
DEBUG - 2018-07-21 04:27:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-21 04:27:51 --> Helper loaded: file_helper
DEBUG - 2018-07-21 04:27:51 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-21 04:27:51 --> Login MX_Controller Initialized
INFO - 2018-07-21 04:27:51 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-21 04:27:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-21 04:27:51 --> Final output sent to browser
DEBUG - 2018-07-21 04:27:51 --> Total execution time: 0.3909
INFO - 2018-07-21 04:27:57 --> Config Class Initialized
INFO - 2018-07-21 04:27:57 --> Hooks Class Initialized
DEBUG - 2018-07-21 04:27:57 --> UTF-8 Support Enabled
INFO - 2018-07-21 04:27:57 --> Utf8 Class Initialized
INFO - 2018-07-21 04:27:57 --> URI Class Initialized
INFO - 2018-07-21 04:27:57 --> Router Class Initialized
INFO - 2018-07-21 04:27:57 --> Output Class Initialized
INFO - 2018-07-21 04:27:57 --> Security Class Initialized
DEBUG - 2018-07-21 04:27:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 04:27:57 --> Input Class Initialized
INFO - 2018-07-21 04:27:57 --> Language Class Initialized
INFO - 2018-07-21 04:27:57 --> Language Class Initialized
INFO - 2018-07-21 04:27:57 --> Config Class Initialized
INFO - 2018-07-21 04:27:57 --> Loader Class Initialized
DEBUG - 2018-07-21 04:27:57 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-21 04:27:57 --> Helper loaded: url_helper
INFO - 2018-07-21 04:27:57 --> Helper loaded: form_helper
INFO - 2018-07-21 04:27:57 --> Helper loaded: date_helper
INFO - 2018-07-21 04:27:57 --> Helper loaded: util_helper
INFO - 2018-07-21 04:27:57 --> Helper loaded: text_helper
INFO - 2018-07-21 04:27:57 --> Helper loaded: string_helper
INFO - 2018-07-21 04:27:57 --> Database Driver Class Initialized
DEBUG - 2018-07-21 04:27:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-21 04:27:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-21 04:27:57 --> Email Class Initialized
INFO - 2018-07-21 04:27:57 --> Controller Class Initialized
DEBUG - 2018-07-21 04:27:57 --> Users MX_Controller Initialized
DEBUG - 2018-07-21 04:27:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-21 04:27:57 --> Helper loaded: file_helper
DEBUG - 2018-07-21 04:27:57 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-21 04:27:57 --> Login MX_Controller Initialized
INFO - 2018-07-21 04:27:57 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-21 04:27:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-21 04:27:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
DEBUG - 2018-07-21 04:27:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-21 04:27:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
INFO - 2018-07-21 04:27:57 --> Upload Class Initialized
INFO - 2018-07-21 04:27:58 --> Passsword for email - gopaltesting1@yopmail.com - is :: Testing6649
DEBUG - 2018-07-21 04:27:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/templates/credentials.php
DEBUG - 2018-07-21 04:27:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Mail_model.php
DEBUG - 2018-07-21 04:27:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/mail_view.php
INFO - 2018-07-21 04:27:58 --> Mail logged successfully
INFO - 2018-07-21 04:27:58 --> Config Class Initialized
INFO - 2018-07-21 04:27:58 --> Hooks Class Initialized
DEBUG - 2018-07-21 04:27:58 --> UTF-8 Support Enabled
INFO - 2018-07-21 04:27:58 --> Utf8 Class Initialized
INFO - 2018-07-21 04:27:58 --> URI Class Initialized
INFO - 2018-07-21 04:27:58 --> Router Class Initialized
INFO - 2018-07-21 04:27:58 --> Output Class Initialized
INFO - 2018-07-21 04:27:58 --> Security Class Initialized
DEBUG - 2018-07-21 04:27:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 04:27:58 --> Input Class Initialized
INFO - 2018-07-21 04:27:58 --> Language Class Initialized
INFO - 2018-07-21 04:27:58 --> Language Class Initialized
INFO - 2018-07-21 04:27:58 --> Config Class Initialized
INFO - 2018-07-21 04:27:58 --> Loader Class Initialized
DEBUG - 2018-07-21 04:27:58 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-21 04:27:58 --> Helper loaded: url_helper
INFO - 2018-07-21 04:27:58 --> Helper loaded: form_helper
INFO - 2018-07-21 04:27:58 --> Helper loaded: date_helper
INFO - 2018-07-21 04:27:58 --> Helper loaded: util_helper
INFO - 2018-07-21 04:27:58 --> Helper loaded: text_helper
INFO - 2018-07-21 04:27:58 --> Helper loaded: string_helper
INFO - 2018-07-21 04:27:58 --> Database Driver Class Initialized
DEBUG - 2018-07-21 04:27:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-21 04:27:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-21 04:27:58 --> Email Class Initialized
INFO - 2018-07-21 04:27:58 --> Controller Class Initialized
DEBUG - 2018-07-21 04:27:58 --> Users MX_Controller Initialized
DEBUG - 2018-07-21 04:27:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-21 04:27:58 --> Helper loaded: file_helper
DEBUG - 2018-07-21 04:27:58 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-21 04:27:58 --> Login MX_Controller Initialized
INFO - 2018-07-21 04:27:58 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-21 04:27:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-21 04:27:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-21 04:27:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-21 04:27:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-21 04:27:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-21 04:27:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-21 04:27:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/users.php
INFO - 2018-07-21 04:27:58 --> Final output sent to browser
DEBUG - 2018-07-21 04:27:58 --> Total execution time: 0.4263
INFO - 2018-07-21 04:27:58 --> Config Class Initialized
INFO - 2018-07-21 04:27:58 --> Hooks Class Initialized
DEBUG - 2018-07-21 04:27:58 --> UTF-8 Support Enabled
INFO - 2018-07-21 04:27:58 --> Utf8 Class Initialized
INFO - 2018-07-21 04:27:59 --> URI Class Initialized
INFO - 2018-07-21 04:27:59 --> Router Class Initialized
INFO - 2018-07-21 04:27:59 --> Output Class Initialized
INFO - 2018-07-21 04:27:59 --> Security Class Initialized
DEBUG - 2018-07-21 04:27:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 04:27:59 --> Input Class Initialized
INFO - 2018-07-21 04:27:59 --> Language Class Initialized
INFO - 2018-07-21 04:27:59 --> Language Class Initialized
INFO - 2018-07-21 04:27:59 --> Config Class Initialized
INFO - 2018-07-21 04:27:59 --> Loader Class Initialized
DEBUG - 2018-07-21 04:27:59 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-21 04:27:59 --> Helper loaded: url_helper
INFO - 2018-07-21 04:27:59 --> Helper loaded: form_helper
INFO - 2018-07-21 04:27:59 --> Helper loaded: date_helper
INFO - 2018-07-21 04:27:59 --> Helper loaded: util_helper
INFO - 2018-07-21 04:27:59 --> Helper loaded: text_helper
INFO - 2018-07-21 04:27:59 --> Helper loaded: string_helper
INFO - 2018-07-21 04:27:59 --> Database Driver Class Initialized
DEBUG - 2018-07-21 04:27:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-21 04:27:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-21 04:27:59 --> Email Class Initialized
INFO - 2018-07-21 04:27:59 --> Controller Class Initialized
DEBUG - 2018-07-21 04:27:59 --> Users MX_Controller Initialized
DEBUG - 2018-07-21 04:27:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-21 04:27:59 --> Helper loaded: file_helper
DEBUG - 2018-07-21 04:27:59 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-21 04:27:59 --> Login MX_Controller Initialized
INFO - 2018-07-21 04:27:59 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-21 04:27:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-21 04:27:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-07-21 04:27:59 --> Final output sent to browser
DEBUG - 2018-07-21 04:27:59 --> Total execution time: 0.4950
INFO - 2018-07-21 04:28:08 --> Config Class Initialized
INFO - 2018-07-21 04:28:08 --> Hooks Class Initialized
DEBUG - 2018-07-21 04:28:08 --> UTF-8 Support Enabled
INFO - 2018-07-21 04:28:08 --> Utf8 Class Initialized
INFO - 2018-07-21 04:28:08 --> URI Class Initialized
INFO - 2018-07-21 04:28:08 --> Router Class Initialized
INFO - 2018-07-21 04:28:08 --> Output Class Initialized
INFO - 2018-07-21 04:28:08 --> Security Class Initialized
DEBUG - 2018-07-21 04:28:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 04:28:08 --> Input Class Initialized
INFO - 2018-07-21 04:28:08 --> Language Class Initialized
INFO - 2018-07-21 04:28:08 --> Language Class Initialized
INFO - 2018-07-21 04:28:08 --> Config Class Initialized
INFO - 2018-07-21 04:28:08 --> Loader Class Initialized
DEBUG - 2018-07-21 04:28:08 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-21 04:28:08 --> Helper loaded: url_helper
INFO - 2018-07-21 04:28:08 --> Helper loaded: form_helper
INFO - 2018-07-21 04:28:08 --> Helper loaded: date_helper
INFO - 2018-07-21 04:28:08 --> Helper loaded: util_helper
INFO - 2018-07-21 04:28:08 --> Helper loaded: text_helper
INFO - 2018-07-21 04:28:08 --> Helper loaded: string_helper
INFO - 2018-07-21 04:28:08 --> Database Driver Class Initialized
DEBUG - 2018-07-21 04:28:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-21 04:28:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-21 04:28:08 --> Email Class Initialized
INFO - 2018-07-21 04:28:08 --> Controller Class Initialized
DEBUG - 2018-07-21 04:28:08 --> Admin MX_Controller Initialized
INFO - 2018-07-21 04:28:08 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-21 04:28:08 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-21 04:28:08 --> Login MX_Controller Initialized
DEBUG - 2018-07-21 04:28:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-21 04:28:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
ERROR - 2018-07-21 04:28:08 --> Query error: Cannot delete or update a parent row: a foreign key constraint fails (`consulting`.`users_programs`, CONSTRAINT `users_programs_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`)) - Invalid query: DELETE FROM users WHERE user_id IN(42)
INFO - 2018-07-21 04:28:08 --> Language file loaded: language/english/db_lang.php
INFO - 2018-07-21 04:28:14 --> Config Class Initialized
INFO - 2018-07-21 04:28:14 --> Hooks Class Initialized
DEBUG - 2018-07-21 04:28:14 --> UTF-8 Support Enabled
INFO - 2018-07-21 04:28:14 --> Utf8 Class Initialized
INFO - 2018-07-21 04:28:14 --> URI Class Initialized
INFO - 2018-07-21 04:28:14 --> Router Class Initialized
INFO - 2018-07-21 04:28:14 --> Output Class Initialized
INFO - 2018-07-21 04:28:14 --> Security Class Initialized
DEBUG - 2018-07-21 04:28:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 04:28:14 --> Input Class Initialized
INFO - 2018-07-21 04:28:14 --> Language Class Initialized
INFO - 2018-07-21 04:28:14 --> Language Class Initialized
INFO - 2018-07-21 04:28:14 --> Config Class Initialized
INFO - 2018-07-21 04:28:14 --> Loader Class Initialized
DEBUG - 2018-07-21 04:28:14 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-21 04:28:15 --> Helper loaded: url_helper
INFO - 2018-07-21 04:28:15 --> Helper loaded: form_helper
INFO - 2018-07-21 04:28:15 --> Helper loaded: date_helper
INFO - 2018-07-21 04:28:15 --> Helper loaded: util_helper
INFO - 2018-07-21 04:28:15 --> Helper loaded: text_helper
INFO - 2018-07-21 04:28:15 --> Helper loaded: string_helper
INFO - 2018-07-21 04:28:15 --> Database Driver Class Initialized
DEBUG - 2018-07-21 04:28:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-21 04:28:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-21 04:28:15 --> Email Class Initialized
INFO - 2018-07-21 04:28:15 --> Controller Class Initialized
DEBUG - 2018-07-21 04:28:15 --> Users MX_Controller Initialized
DEBUG - 2018-07-21 04:28:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-21 04:28:15 --> Helper loaded: file_helper
DEBUG - 2018-07-21 04:28:15 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-21 04:28:15 --> Login MX_Controller Initialized
INFO - 2018-07-21 04:28:15 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-21 04:28:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-21 04:28:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-21 04:28:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-21 04:28:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-21 04:28:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-21 04:28:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-21 04:28:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/users.php
INFO - 2018-07-21 04:28:15 --> Final output sent to browser
DEBUG - 2018-07-21 04:28:15 --> Total execution time: 0.4445
INFO - 2018-07-21 04:28:15 --> Config Class Initialized
INFO - 2018-07-21 04:28:15 --> Hooks Class Initialized
DEBUG - 2018-07-21 04:28:15 --> UTF-8 Support Enabled
INFO - 2018-07-21 04:28:15 --> Utf8 Class Initialized
INFO - 2018-07-21 04:28:15 --> URI Class Initialized
INFO - 2018-07-21 04:28:15 --> Router Class Initialized
INFO - 2018-07-21 04:28:15 --> Output Class Initialized
INFO - 2018-07-21 04:28:15 --> Security Class Initialized
DEBUG - 2018-07-21 04:28:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 04:28:15 --> Input Class Initialized
INFO - 2018-07-21 04:28:15 --> Language Class Initialized
INFO - 2018-07-21 04:28:15 --> Language Class Initialized
INFO - 2018-07-21 04:28:15 --> Config Class Initialized
INFO - 2018-07-21 04:28:15 --> Loader Class Initialized
DEBUG - 2018-07-21 04:28:15 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-21 04:28:15 --> Helper loaded: url_helper
INFO - 2018-07-21 04:28:15 --> Helper loaded: form_helper
INFO - 2018-07-21 04:28:15 --> Helper loaded: date_helper
INFO - 2018-07-21 04:28:15 --> Helper loaded: util_helper
INFO - 2018-07-21 04:28:15 --> Helper loaded: text_helper
INFO - 2018-07-21 04:28:15 --> Helper loaded: string_helper
INFO - 2018-07-21 04:28:15 --> Database Driver Class Initialized
DEBUG - 2018-07-21 04:28:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-21 04:28:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-21 04:28:15 --> Email Class Initialized
INFO - 2018-07-21 04:28:15 --> Controller Class Initialized
DEBUG - 2018-07-21 04:28:16 --> Users MX_Controller Initialized
DEBUG - 2018-07-21 04:28:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-21 04:28:16 --> Helper loaded: file_helper
DEBUG - 2018-07-21 04:28:16 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-21 04:28:16 --> Login MX_Controller Initialized
INFO - 2018-07-21 04:28:16 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-21 04:28:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-21 04:28:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-07-21 04:28:16 --> Final output sent to browser
DEBUG - 2018-07-21 04:28:16 --> Total execution time: 0.5103
INFO - 2018-07-21 04:28:16 --> Config Class Initialized
INFO - 2018-07-21 04:28:16 --> Hooks Class Initialized
DEBUG - 2018-07-21 04:28:16 --> UTF-8 Support Enabled
INFO - 2018-07-21 04:28:16 --> Utf8 Class Initialized
INFO - 2018-07-21 04:28:16 --> URI Class Initialized
INFO - 2018-07-21 04:28:16 --> Router Class Initialized
INFO - 2018-07-21 04:28:16 --> Output Class Initialized
INFO - 2018-07-21 04:28:16 --> Security Class Initialized
DEBUG - 2018-07-21 04:28:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 04:28:16 --> Input Class Initialized
INFO - 2018-07-21 04:28:16 --> Language Class Initialized
ERROR - 2018-07-21 04:28:16 --> 404 Page Not Found: /index
INFO - 2018-07-21 04:28:19 --> Config Class Initialized
INFO - 2018-07-21 04:28:19 --> Hooks Class Initialized
DEBUG - 2018-07-21 04:28:19 --> UTF-8 Support Enabled
INFO - 2018-07-21 04:28:19 --> Utf8 Class Initialized
INFO - 2018-07-21 04:28:20 --> URI Class Initialized
INFO - 2018-07-21 04:28:20 --> Router Class Initialized
INFO - 2018-07-21 04:28:20 --> Output Class Initialized
INFO - 2018-07-21 04:28:20 --> Security Class Initialized
DEBUG - 2018-07-21 04:28:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 04:28:20 --> Input Class Initialized
INFO - 2018-07-21 04:28:20 --> Language Class Initialized
INFO - 2018-07-21 04:28:20 --> Language Class Initialized
INFO - 2018-07-21 04:28:20 --> Config Class Initialized
INFO - 2018-07-21 04:28:20 --> Loader Class Initialized
DEBUG - 2018-07-21 04:28:20 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-21 04:28:20 --> Helper loaded: url_helper
INFO - 2018-07-21 04:28:20 --> Helper loaded: form_helper
INFO - 2018-07-21 04:28:20 --> Helper loaded: date_helper
INFO - 2018-07-21 04:28:20 --> Helper loaded: util_helper
INFO - 2018-07-21 04:28:20 --> Helper loaded: text_helper
INFO - 2018-07-21 04:28:20 --> Helper loaded: string_helper
INFO - 2018-07-21 04:28:20 --> Database Driver Class Initialized
DEBUG - 2018-07-21 04:28:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-21 04:28:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-21 04:28:20 --> Email Class Initialized
INFO - 2018-07-21 04:28:20 --> Controller Class Initialized
DEBUG - 2018-07-21 04:28:20 --> Admin MX_Controller Initialized
INFO - 2018-07-21 04:28:20 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-21 04:28:20 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-21 04:28:20 --> Login MX_Controller Initialized
DEBUG - 2018-07-21 04:28:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-21 04:28:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
ERROR - 2018-07-21 04:28:20 --> Severity: Warning --> unlink(E:\xampp\htdocs\consulting\assets/images/users/Gopi-PanHNdJ1Gpl3jyZF.jpg): No such file or directory E:\xampp\htdocs\consulting\application\modules\common\models\Common_model.php 94
ERROR - 2018-07-21 04:28:20 --> Query error: Cannot delete or update a parent row: a foreign key constraint fails (`consulting`.`users_programs`, CONSTRAINT `users_programs_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`)) - Invalid query: DELETE FROM users WHERE user_id IN(42)
INFO - 2018-07-21 04:28:20 --> Language file loaded: language/english/db_lang.php
INFO - 2018-07-21 04:28:22 --> Config Class Initialized
INFO - 2018-07-21 04:28:22 --> Hooks Class Initialized
DEBUG - 2018-07-21 04:28:22 --> UTF-8 Support Enabled
INFO - 2018-07-21 04:28:22 --> Utf8 Class Initialized
INFO - 2018-07-21 04:28:22 --> URI Class Initialized
INFO - 2018-07-21 04:28:22 --> Router Class Initialized
INFO - 2018-07-21 04:28:22 --> Output Class Initialized
INFO - 2018-07-21 04:28:22 --> Security Class Initialized
DEBUG - 2018-07-21 04:28:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 04:28:22 --> Input Class Initialized
INFO - 2018-07-21 04:28:22 --> Language Class Initialized
INFO - 2018-07-21 04:28:22 --> Language Class Initialized
INFO - 2018-07-21 04:28:22 --> Config Class Initialized
INFO - 2018-07-21 04:28:22 --> Loader Class Initialized
DEBUG - 2018-07-21 04:28:22 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-21 04:28:22 --> Helper loaded: url_helper
INFO - 2018-07-21 04:28:23 --> Helper loaded: form_helper
INFO - 2018-07-21 04:28:23 --> Helper loaded: date_helper
INFO - 2018-07-21 04:28:23 --> Helper loaded: util_helper
INFO - 2018-07-21 04:28:23 --> Helper loaded: text_helper
INFO - 2018-07-21 04:28:23 --> Helper loaded: string_helper
INFO - 2018-07-21 04:28:23 --> Database Driver Class Initialized
DEBUG - 2018-07-21 04:28:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-21 04:28:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-21 04:28:23 --> Email Class Initialized
INFO - 2018-07-21 04:28:23 --> Controller Class Initialized
DEBUG - 2018-07-21 04:28:23 --> Users MX_Controller Initialized
DEBUG - 2018-07-21 04:28:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-21 04:28:23 --> Helper loaded: file_helper
DEBUG - 2018-07-21 04:28:23 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-21 04:28:23 --> Login MX_Controller Initialized
INFO - 2018-07-21 04:28:23 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-21 04:28:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-21 04:28:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-21 04:28:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-21 04:28:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-21 04:28:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-21 04:28:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-21 04:28:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/users.php
INFO - 2018-07-21 04:28:23 --> Final output sent to browser
DEBUG - 2018-07-21 04:28:23 --> Total execution time: 0.4538
INFO - 2018-07-21 04:28:23 --> Config Class Initialized
INFO - 2018-07-21 04:28:23 --> Hooks Class Initialized
DEBUG - 2018-07-21 04:28:23 --> UTF-8 Support Enabled
INFO - 2018-07-21 04:28:23 --> Utf8 Class Initialized
INFO - 2018-07-21 04:28:23 --> URI Class Initialized
INFO - 2018-07-21 04:28:23 --> Router Class Initialized
INFO - 2018-07-21 04:28:23 --> Output Class Initialized
INFO - 2018-07-21 04:28:23 --> Security Class Initialized
DEBUG - 2018-07-21 04:28:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 04:28:23 --> Input Class Initialized
INFO - 2018-07-21 04:28:23 --> Language Class Initialized
INFO - 2018-07-21 04:28:23 --> Language Class Initialized
INFO - 2018-07-21 04:28:23 --> Config Class Initialized
INFO - 2018-07-21 04:28:23 --> Loader Class Initialized
DEBUG - 2018-07-21 04:28:23 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-21 04:28:23 --> Helper loaded: url_helper
INFO - 2018-07-21 04:28:23 --> Helper loaded: form_helper
INFO - 2018-07-21 04:28:23 --> Helper loaded: date_helper
INFO - 2018-07-21 04:28:23 --> Helper loaded: util_helper
INFO - 2018-07-21 04:28:23 --> Helper loaded: text_helper
INFO - 2018-07-21 04:28:23 --> Helper loaded: string_helper
INFO - 2018-07-21 04:28:23 --> Database Driver Class Initialized
DEBUG - 2018-07-21 04:28:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-21 04:28:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-21 04:28:23 --> Email Class Initialized
INFO - 2018-07-21 04:28:23 --> Controller Class Initialized
DEBUG - 2018-07-21 04:28:23 --> Users MX_Controller Initialized
DEBUG - 2018-07-21 04:28:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-21 04:28:23 --> Helper loaded: file_helper
DEBUG - 2018-07-21 04:28:23 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-21 04:28:23 --> Login MX_Controller Initialized
INFO - 2018-07-21 04:28:23 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-21 04:28:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-21 04:28:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-07-21 04:28:23 --> Final output sent to browser
DEBUG - 2018-07-21 04:28:24 --> Total execution time: 0.4997
INFO - 2018-07-21 04:28:24 --> Config Class Initialized
INFO - 2018-07-21 04:28:24 --> Hooks Class Initialized
DEBUG - 2018-07-21 04:28:24 --> UTF-8 Support Enabled
INFO - 2018-07-21 04:28:24 --> Utf8 Class Initialized
INFO - 2018-07-21 04:28:24 --> URI Class Initialized
INFO - 2018-07-21 04:28:24 --> Router Class Initialized
INFO - 2018-07-21 04:28:24 --> Output Class Initialized
INFO - 2018-07-21 04:28:24 --> Security Class Initialized
DEBUG - 2018-07-21 04:28:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 04:28:24 --> Input Class Initialized
INFO - 2018-07-21 04:28:24 --> Language Class Initialized
ERROR - 2018-07-21 04:28:24 --> 404 Page Not Found: /index
INFO - 2018-07-21 04:30:33 --> Config Class Initialized
INFO - 2018-07-21 04:30:33 --> Hooks Class Initialized
DEBUG - 2018-07-21 04:30:33 --> UTF-8 Support Enabled
INFO - 2018-07-21 04:30:33 --> Utf8 Class Initialized
INFO - 2018-07-21 04:30:33 --> URI Class Initialized
INFO - 2018-07-21 04:30:33 --> Router Class Initialized
INFO - 2018-07-21 04:30:33 --> Output Class Initialized
INFO - 2018-07-21 04:30:33 --> Security Class Initialized
DEBUG - 2018-07-21 04:30:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 04:30:33 --> Input Class Initialized
INFO - 2018-07-21 04:30:33 --> Language Class Initialized
INFO - 2018-07-21 04:30:33 --> Language Class Initialized
INFO - 2018-07-21 04:30:33 --> Config Class Initialized
INFO - 2018-07-21 04:30:33 --> Loader Class Initialized
DEBUG - 2018-07-21 04:30:33 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-21 04:30:33 --> Helper loaded: url_helper
INFO - 2018-07-21 04:30:33 --> Helper loaded: form_helper
INFO - 2018-07-21 04:30:33 --> Helper loaded: date_helper
INFO - 2018-07-21 04:30:33 --> Helper loaded: util_helper
INFO - 2018-07-21 04:30:33 --> Helper loaded: text_helper
INFO - 2018-07-21 04:30:33 --> Helper loaded: string_helper
INFO - 2018-07-21 04:30:33 --> Database Driver Class Initialized
DEBUG - 2018-07-21 04:30:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-21 04:30:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-21 04:30:33 --> Email Class Initialized
INFO - 2018-07-21 04:30:33 --> Controller Class Initialized
DEBUG - 2018-07-21 04:30:34 --> Users MX_Controller Initialized
DEBUG - 2018-07-21 04:30:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-21 04:30:34 --> Helper loaded: file_helper
DEBUG - 2018-07-21 04:30:34 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-21 04:30:34 --> Login MX_Controller Initialized
INFO - 2018-07-21 04:30:34 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-21 04:30:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-21 04:30:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-21 04:30:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-21 04:30:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-21 04:30:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-21 04:30:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-21 04:30:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/users.php
INFO - 2018-07-21 04:30:34 --> Final output sent to browser
DEBUG - 2018-07-21 04:30:34 --> Total execution time: 0.4775
INFO - 2018-07-21 04:30:34 --> Config Class Initialized
INFO - 2018-07-21 04:30:34 --> Hooks Class Initialized
DEBUG - 2018-07-21 04:30:34 --> UTF-8 Support Enabled
INFO - 2018-07-21 04:30:34 --> Utf8 Class Initialized
INFO - 2018-07-21 04:30:34 --> URI Class Initialized
INFO - 2018-07-21 04:30:34 --> Router Class Initialized
INFO - 2018-07-21 04:30:34 --> Output Class Initialized
INFO - 2018-07-21 04:30:34 --> Security Class Initialized
DEBUG - 2018-07-21 04:30:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 04:30:34 --> Input Class Initialized
INFO - 2018-07-21 04:30:34 --> Language Class Initialized
INFO - 2018-07-21 04:30:34 --> Language Class Initialized
INFO - 2018-07-21 04:30:34 --> Config Class Initialized
INFO - 2018-07-21 04:30:34 --> Loader Class Initialized
DEBUG - 2018-07-21 04:30:34 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-21 04:30:34 --> Helper loaded: url_helper
INFO - 2018-07-21 04:30:34 --> Helper loaded: form_helper
INFO - 2018-07-21 04:30:34 --> Helper loaded: date_helper
INFO - 2018-07-21 04:30:34 --> Helper loaded: util_helper
INFO - 2018-07-21 04:30:34 --> Helper loaded: text_helper
INFO - 2018-07-21 04:30:34 --> Helper loaded: string_helper
INFO - 2018-07-21 04:30:34 --> Database Driver Class Initialized
DEBUG - 2018-07-21 04:30:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-21 04:30:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-21 04:30:34 --> Email Class Initialized
INFO - 2018-07-21 04:30:34 --> Controller Class Initialized
DEBUG - 2018-07-21 04:30:34 --> Users MX_Controller Initialized
DEBUG - 2018-07-21 04:30:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-21 04:30:34 --> Helper loaded: file_helper
DEBUG - 2018-07-21 04:30:34 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-21 04:30:34 --> Login MX_Controller Initialized
INFO - 2018-07-21 04:30:34 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-21 04:30:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-21 04:30:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-07-21 04:30:34 --> Final output sent to browser
DEBUG - 2018-07-21 04:30:35 --> Total execution time: 0.5228
INFO - 2018-07-21 04:30:35 --> Config Class Initialized
INFO - 2018-07-21 04:30:35 --> Hooks Class Initialized
DEBUG - 2018-07-21 04:30:35 --> UTF-8 Support Enabled
INFO - 2018-07-21 04:30:35 --> Utf8 Class Initialized
INFO - 2018-07-21 04:30:35 --> URI Class Initialized
INFO - 2018-07-21 04:30:35 --> Router Class Initialized
INFO - 2018-07-21 04:30:35 --> Output Class Initialized
INFO - 2018-07-21 04:30:35 --> Security Class Initialized
DEBUG - 2018-07-21 04:30:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 04:30:35 --> Input Class Initialized
INFO - 2018-07-21 04:30:35 --> Language Class Initialized
ERROR - 2018-07-21 04:30:35 --> 404 Page Not Found: /index
INFO - 2018-07-21 04:30:45 --> Config Class Initialized
INFO - 2018-07-21 04:30:45 --> Hooks Class Initialized
DEBUG - 2018-07-21 04:30:45 --> UTF-8 Support Enabled
INFO - 2018-07-21 04:30:45 --> Utf8 Class Initialized
INFO - 2018-07-21 04:30:45 --> URI Class Initialized
INFO - 2018-07-21 04:30:45 --> Router Class Initialized
INFO - 2018-07-21 04:30:45 --> Output Class Initialized
INFO - 2018-07-21 04:30:45 --> Security Class Initialized
DEBUG - 2018-07-21 04:30:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 04:30:45 --> Input Class Initialized
INFO - 2018-07-21 04:30:45 --> Language Class Initialized
INFO - 2018-07-21 04:30:45 --> Language Class Initialized
INFO - 2018-07-21 04:30:45 --> Config Class Initialized
INFO - 2018-07-21 04:30:45 --> Loader Class Initialized
DEBUG - 2018-07-21 04:30:45 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-21 04:30:45 --> Helper loaded: url_helper
INFO - 2018-07-21 04:30:45 --> Helper loaded: form_helper
INFO - 2018-07-21 04:30:45 --> Helper loaded: date_helper
INFO - 2018-07-21 04:30:45 --> Helper loaded: util_helper
INFO - 2018-07-21 04:30:45 --> Helper loaded: text_helper
INFO - 2018-07-21 04:30:45 --> Helper loaded: string_helper
INFO - 2018-07-21 04:30:45 --> Database Driver Class Initialized
DEBUG - 2018-07-21 04:30:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-21 04:30:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-21 04:30:45 --> Email Class Initialized
INFO - 2018-07-21 04:30:45 --> Controller Class Initialized
DEBUG - 2018-07-21 04:30:45 --> Admin MX_Controller Initialized
INFO - 2018-07-21 04:30:45 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-21 04:30:45 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-21 04:30:45 --> Login MX_Controller Initialized
DEBUG - 2018-07-21 04:30:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-21 04:30:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
ERROR - 2018-07-21 04:30:45 --> Severity: Warning --> unlink(E:\xampp\htdocs\consulting\assets/images/users/Gopi-PanHNdJ1Gpl3jyZF.jpg): No such file or directory E:\xampp\htdocs\consulting\application\modules\common\models\Common_model.php 94
ERROR - 2018-07-21 04:30:45 --> Query error: Cannot delete or update a parent row: a foreign key constraint fails (`consulting`.`users_programs`, CONSTRAINT `users_programs_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON UPDATE CASCADE) - Invalid query: DELETE FROM users WHERE user_id IN(42)
INFO - 2018-07-21 04:30:45 --> Language file loaded: language/english/db_lang.php
INFO - 2018-07-21 04:31:12 --> Config Class Initialized
INFO - 2018-07-21 04:31:12 --> Hooks Class Initialized
DEBUG - 2018-07-21 04:31:12 --> UTF-8 Support Enabled
INFO - 2018-07-21 04:31:12 --> Utf8 Class Initialized
INFO - 2018-07-21 04:31:12 --> URI Class Initialized
INFO - 2018-07-21 04:31:12 --> Router Class Initialized
INFO - 2018-07-21 04:31:12 --> Output Class Initialized
INFO - 2018-07-21 04:31:12 --> Security Class Initialized
DEBUG - 2018-07-21 04:31:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 04:31:12 --> Input Class Initialized
INFO - 2018-07-21 04:31:12 --> Language Class Initialized
INFO - 2018-07-21 04:31:12 --> Language Class Initialized
INFO - 2018-07-21 04:31:12 --> Config Class Initialized
INFO - 2018-07-21 04:31:12 --> Loader Class Initialized
DEBUG - 2018-07-21 04:31:12 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-21 04:31:12 --> Helper loaded: url_helper
INFO - 2018-07-21 04:31:12 --> Helper loaded: form_helper
INFO - 2018-07-21 04:31:12 --> Helper loaded: date_helper
INFO - 2018-07-21 04:31:12 --> Helper loaded: util_helper
INFO - 2018-07-21 04:31:12 --> Helper loaded: text_helper
INFO - 2018-07-21 04:31:12 --> Helper loaded: string_helper
INFO - 2018-07-21 04:31:12 --> Database Driver Class Initialized
DEBUG - 2018-07-21 04:31:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-21 04:31:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-21 04:31:12 --> Email Class Initialized
INFO - 2018-07-21 04:31:12 --> Controller Class Initialized
DEBUG - 2018-07-21 04:31:12 --> Users MX_Controller Initialized
DEBUG - 2018-07-21 04:31:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-21 04:31:12 --> Helper loaded: file_helper
DEBUG - 2018-07-21 04:31:12 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-21 04:31:12 --> Login MX_Controller Initialized
INFO - 2018-07-21 04:31:12 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-21 04:31:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-21 04:31:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-21 04:31:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-21 04:31:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-21 04:31:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-21 04:31:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-21 04:31:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/users.php
INFO - 2018-07-21 04:31:12 --> Final output sent to browser
DEBUG - 2018-07-21 04:31:12 --> Total execution time: 0.4727
INFO - 2018-07-21 04:31:13 --> Config Class Initialized
INFO - 2018-07-21 04:31:13 --> Hooks Class Initialized
DEBUG - 2018-07-21 04:31:13 --> UTF-8 Support Enabled
INFO - 2018-07-21 04:31:13 --> Utf8 Class Initialized
INFO - 2018-07-21 04:31:13 --> URI Class Initialized
INFO - 2018-07-21 04:31:13 --> Router Class Initialized
INFO - 2018-07-21 04:31:13 --> Output Class Initialized
INFO - 2018-07-21 04:31:13 --> Security Class Initialized
DEBUG - 2018-07-21 04:31:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 04:31:13 --> Input Class Initialized
INFO - 2018-07-21 04:31:13 --> Language Class Initialized
INFO - 2018-07-21 04:31:13 --> Language Class Initialized
INFO - 2018-07-21 04:31:13 --> Config Class Initialized
INFO - 2018-07-21 04:31:13 --> Loader Class Initialized
DEBUG - 2018-07-21 04:31:13 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-21 04:31:13 --> Helper loaded: url_helper
INFO - 2018-07-21 04:31:13 --> Helper loaded: form_helper
INFO - 2018-07-21 04:31:13 --> Helper loaded: date_helper
INFO - 2018-07-21 04:31:13 --> Helper loaded: util_helper
INFO - 2018-07-21 04:31:13 --> Helper loaded: text_helper
INFO - 2018-07-21 04:31:13 --> Helper loaded: string_helper
INFO - 2018-07-21 04:31:13 --> Database Driver Class Initialized
DEBUG - 2018-07-21 04:31:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-21 04:31:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-21 04:31:13 --> Email Class Initialized
INFO - 2018-07-21 04:31:13 --> Controller Class Initialized
DEBUG - 2018-07-21 04:31:13 --> Users MX_Controller Initialized
DEBUG - 2018-07-21 04:31:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-21 04:31:13 --> Helper loaded: file_helper
DEBUG - 2018-07-21 04:31:13 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-21 04:31:13 --> Login MX_Controller Initialized
INFO - 2018-07-21 04:31:13 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-21 04:31:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-21 04:31:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-07-21 04:31:13 --> Final output sent to browser
DEBUG - 2018-07-21 04:31:13 --> Total execution time: 0.5425
INFO - 2018-07-21 04:31:14 --> Config Class Initialized
INFO - 2018-07-21 04:31:14 --> Hooks Class Initialized
DEBUG - 2018-07-21 04:31:14 --> UTF-8 Support Enabled
INFO - 2018-07-21 04:31:14 --> Utf8 Class Initialized
INFO - 2018-07-21 04:31:14 --> URI Class Initialized
INFO - 2018-07-21 04:31:14 --> Router Class Initialized
INFO - 2018-07-21 04:31:14 --> Output Class Initialized
INFO - 2018-07-21 04:31:14 --> Security Class Initialized
DEBUG - 2018-07-21 04:31:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 04:31:14 --> Input Class Initialized
INFO - 2018-07-21 04:31:14 --> Language Class Initialized
ERROR - 2018-07-21 04:31:14 --> 404 Page Not Found: /index
INFO - 2018-07-21 04:31:17 --> Config Class Initialized
INFO - 2018-07-21 04:31:17 --> Hooks Class Initialized
DEBUG - 2018-07-21 04:31:17 --> UTF-8 Support Enabled
INFO - 2018-07-21 04:31:17 --> Utf8 Class Initialized
INFO - 2018-07-21 04:31:17 --> URI Class Initialized
INFO - 2018-07-21 04:31:17 --> Router Class Initialized
INFO - 2018-07-21 04:31:17 --> Output Class Initialized
INFO - 2018-07-21 04:31:17 --> Security Class Initialized
DEBUG - 2018-07-21 04:31:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 04:31:17 --> Input Class Initialized
INFO - 2018-07-21 04:31:17 --> Language Class Initialized
INFO - 2018-07-21 04:31:17 --> Language Class Initialized
INFO - 2018-07-21 04:31:17 --> Config Class Initialized
INFO - 2018-07-21 04:31:17 --> Loader Class Initialized
DEBUG - 2018-07-21 04:31:17 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-21 04:31:17 --> Helper loaded: url_helper
INFO - 2018-07-21 04:31:17 --> Helper loaded: form_helper
INFO - 2018-07-21 04:31:17 --> Helper loaded: date_helper
INFO - 2018-07-21 04:31:17 --> Helper loaded: util_helper
INFO - 2018-07-21 04:31:17 --> Helper loaded: text_helper
INFO - 2018-07-21 04:31:17 --> Helper loaded: string_helper
INFO - 2018-07-21 04:31:17 --> Database Driver Class Initialized
DEBUG - 2018-07-21 04:31:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-21 04:31:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-21 04:31:17 --> Email Class Initialized
INFO - 2018-07-21 04:31:17 --> Controller Class Initialized
DEBUG - 2018-07-21 04:31:17 --> Admin MX_Controller Initialized
INFO - 2018-07-21 04:31:17 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-21 04:31:17 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-21 04:31:17 --> Login MX_Controller Initialized
DEBUG - 2018-07-21 04:31:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-21 04:31:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
ERROR - 2018-07-21 04:31:17 --> Severity: Warning --> unlink(E:\xampp\htdocs\consulting\assets/images/users/Gopi-PanHNdJ1Gpl3jyZF.jpg): No such file or directory E:\xampp\htdocs\consulting\application\modules\common\models\Common_model.php 94
INFO - 2018-07-21 04:31:17 --> Final output sent to browser
DEBUG - 2018-07-21 04:31:17 --> Total execution time: 0.6055
INFO - 2018-07-21 04:40:21 --> Config Class Initialized
INFO - 2018-07-21 04:40:21 --> Hooks Class Initialized
DEBUG - 2018-07-21 04:40:21 --> UTF-8 Support Enabled
INFO - 2018-07-21 04:40:21 --> Utf8 Class Initialized
INFO - 2018-07-21 04:40:21 --> URI Class Initialized
INFO - 2018-07-21 04:40:21 --> Router Class Initialized
INFO - 2018-07-21 04:40:21 --> Output Class Initialized
INFO - 2018-07-21 04:40:21 --> Security Class Initialized
DEBUG - 2018-07-21 04:40:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 04:40:21 --> Input Class Initialized
INFO - 2018-07-21 04:40:21 --> Language Class Initialized
INFO - 2018-07-21 04:40:21 --> Language Class Initialized
INFO - 2018-07-21 04:40:21 --> Config Class Initialized
INFO - 2018-07-21 04:40:22 --> Loader Class Initialized
DEBUG - 2018-07-21 04:40:22 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-21 04:40:22 --> Helper loaded: url_helper
INFO - 2018-07-21 04:40:22 --> Helper loaded: form_helper
INFO - 2018-07-21 04:40:22 --> Helper loaded: date_helper
INFO - 2018-07-21 04:40:22 --> Helper loaded: util_helper
INFO - 2018-07-21 04:40:22 --> Helper loaded: text_helper
INFO - 2018-07-21 04:40:22 --> Helper loaded: string_helper
INFO - 2018-07-21 04:40:22 --> Database Driver Class Initialized
DEBUG - 2018-07-21 04:40:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-21 04:40:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-21 04:40:22 --> Email Class Initialized
INFO - 2018-07-21 04:40:22 --> Controller Class Initialized
DEBUG - 2018-07-21 04:40:22 --> Users MX_Controller Initialized
DEBUG - 2018-07-21 04:40:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-21 04:40:22 --> Helper loaded: file_helper
DEBUG - 2018-07-21 04:40:22 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-21 04:40:22 --> Login MX_Controller Initialized
INFO - 2018-07-21 04:40:22 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-21 04:40:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-21 04:40:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-21 04:40:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-21 04:40:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-21 04:40:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-21 04:40:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-21 04:40:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/users.php
INFO - 2018-07-21 04:40:22 --> Final output sent to browser
DEBUG - 2018-07-21 04:40:22 --> Total execution time: 0.5063
INFO - 2018-07-21 04:40:23 --> Config Class Initialized
INFO - 2018-07-21 04:40:23 --> Hooks Class Initialized
DEBUG - 2018-07-21 04:40:23 --> UTF-8 Support Enabled
INFO - 2018-07-21 04:40:23 --> Utf8 Class Initialized
INFO - 2018-07-21 04:40:23 --> URI Class Initialized
INFO - 2018-07-21 04:40:23 --> Router Class Initialized
INFO - 2018-07-21 04:40:23 --> Output Class Initialized
INFO - 2018-07-21 04:40:23 --> Security Class Initialized
DEBUG - 2018-07-21 04:40:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 04:40:23 --> Input Class Initialized
INFO - 2018-07-21 04:40:23 --> Language Class Initialized
INFO - 2018-07-21 04:40:23 --> Language Class Initialized
INFO - 2018-07-21 04:40:23 --> Config Class Initialized
INFO - 2018-07-21 04:40:23 --> Loader Class Initialized
DEBUG - 2018-07-21 04:40:23 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-21 04:40:23 --> Helper loaded: url_helper
INFO - 2018-07-21 04:40:23 --> Helper loaded: form_helper
INFO - 2018-07-21 04:40:23 --> Helper loaded: date_helper
INFO - 2018-07-21 04:40:23 --> Helper loaded: util_helper
INFO - 2018-07-21 04:40:23 --> Helper loaded: text_helper
INFO - 2018-07-21 04:40:23 --> Helper loaded: string_helper
INFO - 2018-07-21 04:40:23 --> Database Driver Class Initialized
DEBUG - 2018-07-21 04:40:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-21 04:40:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-21 04:40:23 --> Email Class Initialized
INFO - 2018-07-21 04:40:23 --> Controller Class Initialized
DEBUG - 2018-07-21 04:40:23 --> Users MX_Controller Initialized
DEBUG - 2018-07-21 04:40:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-21 04:40:23 --> Helper loaded: file_helper
DEBUG - 2018-07-21 04:40:23 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-21 04:40:23 --> Login MX_Controller Initialized
INFO - 2018-07-21 04:40:23 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-21 04:40:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-21 04:40:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-07-21 04:40:23 --> Final output sent to browser
DEBUG - 2018-07-21 04:40:23 --> Total execution time: 0.6450
INFO - 2018-07-21 04:40:29 --> Config Class Initialized
INFO - 2018-07-21 04:40:29 --> Hooks Class Initialized
DEBUG - 2018-07-21 04:40:29 --> UTF-8 Support Enabled
INFO - 2018-07-21 04:40:29 --> Utf8 Class Initialized
INFO - 2018-07-21 04:40:29 --> URI Class Initialized
INFO - 2018-07-21 04:40:29 --> Router Class Initialized
INFO - 2018-07-21 04:40:29 --> Output Class Initialized
INFO - 2018-07-21 04:40:29 --> Security Class Initialized
DEBUG - 2018-07-21 04:40:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 04:40:29 --> Input Class Initialized
INFO - 2018-07-21 04:40:29 --> Language Class Initialized
INFO - 2018-07-21 04:40:29 --> Language Class Initialized
INFO - 2018-07-21 04:40:29 --> Config Class Initialized
INFO - 2018-07-21 04:40:29 --> Loader Class Initialized
DEBUG - 2018-07-21 04:40:29 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-21 04:40:29 --> Helper loaded: url_helper
INFO - 2018-07-21 04:40:29 --> Helper loaded: form_helper
INFO - 2018-07-21 04:40:30 --> Helper loaded: date_helper
INFO - 2018-07-21 04:40:30 --> Helper loaded: util_helper
INFO - 2018-07-21 04:40:30 --> Helper loaded: text_helper
INFO - 2018-07-21 04:40:30 --> Helper loaded: string_helper
INFO - 2018-07-21 04:40:30 --> Database Driver Class Initialized
DEBUG - 2018-07-21 04:40:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-21 04:40:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-21 04:40:30 --> Email Class Initialized
INFO - 2018-07-21 04:40:30 --> Controller Class Initialized
DEBUG - 2018-07-21 04:40:30 --> Users MX_Controller Initialized
DEBUG - 2018-07-21 04:40:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-21 04:40:30 --> Helper loaded: file_helper
DEBUG - 2018-07-21 04:40:30 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-21 04:40:30 --> Login MX_Controller Initialized
INFO - 2018-07-21 04:40:30 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-21 04:40:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-21 04:40:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
DEBUG - 2018-07-21 04:40:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-21 04:40:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-21 04:40:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-21 04:40:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-21 04:40:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-21 04:40:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-21 04:40:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/create_user.php
INFO - 2018-07-21 04:40:30 --> Final output sent to browser
DEBUG - 2018-07-21 04:40:30 --> Total execution time: 0.6085
INFO - 2018-07-21 04:42:14 --> Config Class Initialized
INFO - 2018-07-21 04:42:14 --> Hooks Class Initialized
DEBUG - 2018-07-21 04:42:14 --> UTF-8 Support Enabled
INFO - 2018-07-21 04:42:14 --> Utf8 Class Initialized
INFO - 2018-07-21 04:42:14 --> URI Class Initialized
INFO - 2018-07-21 04:42:14 --> Router Class Initialized
INFO - 2018-07-21 04:42:14 --> Output Class Initialized
INFO - 2018-07-21 04:42:14 --> Security Class Initialized
DEBUG - 2018-07-21 04:42:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 04:42:14 --> Input Class Initialized
INFO - 2018-07-21 04:42:14 --> Language Class Initialized
INFO - 2018-07-21 04:42:14 --> Language Class Initialized
INFO - 2018-07-21 04:42:14 --> Config Class Initialized
INFO - 2018-07-21 04:42:14 --> Loader Class Initialized
DEBUG - 2018-07-21 04:42:14 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-21 04:42:14 --> Helper loaded: url_helper
INFO - 2018-07-21 04:42:14 --> Helper loaded: form_helper
INFO - 2018-07-21 04:42:14 --> Helper loaded: date_helper
INFO - 2018-07-21 04:42:14 --> Helper loaded: util_helper
INFO - 2018-07-21 04:42:14 --> Helper loaded: text_helper
INFO - 2018-07-21 04:42:14 --> Helper loaded: string_helper
INFO - 2018-07-21 04:42:14 --> Database Driver Class Initialized
DEBUG - 2018-07-21 04:42:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-21 04:42:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-21 04:42:14 --> Email Class Initialized
INFO - 2018-07-21 04:42:14 --> Controller Class Initialized
DEBUG - 2018-07-21 04:42:14 --> Users MX_Controller Initialized
DEBUG - 2018-07-21 04:42:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-21 04:42:14 --> Helper loaded: file_helper
DEBUG - 2018-07-21 04:42:14 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-21 04:42:14 --> Login MX_Controller Initialized
INFO - 2018-07-21 04:42:14 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-21 04:42:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-21 04:42:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
DEBUG - 2018-07-21 04:42:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-21 04:42:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-21 04:42:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-21 04:42:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-21 04:42:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-21 04:42:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-21 04:42:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/create_user.php
INFO - 2018-07-21 04:42:14 --> Final output sent to browser
DEBUG - 2018-07-21 04:42:14 --> Total execution time: 0.4882
INFO - 2018-07-21 04:46:12 --> Config Class Initialized
INFO - 2018-07-21 04:46:12 --> Hooks Class Initialized
DEBUG - 2018-07-21 04:46:12 --> UTF-8 Support Enabled
INFO - 2018-07-21 04:46:12 --> Utf8 Class Initialized
INFO - 2018-07-21 04:46:12 --> URI Class Initialized
INFO - 2018-07-21 04:46:12 --> Router Class Initialized
INFO - 2018-07-21 04:46:12 --> Output Class Initialized
INFO - 2018-07-21 04:46:12 --> Security Class Initialized
DEBUG - 2018-07-21 04:46:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 04:46:12 --> Input Class Initialized
INFO - 2018-07-21 04:46:12 --> Language Class Initialized
INFO - 2018-07-21 04:46:12 --> Language Class Initialized
INFO - 2018-07-21 04:46:12 --> Config Class Initialized
INFO - 2018-07-21 04:46:12 --> Loader Class Initialized
DEBUG - 2018-07-21 04:46:12 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-21 04:46:12 --> Helper loaded: url_helper
INFO - 2018-07-21 04:46:12 --> Helper loaded: form_helper
INFO - 2018-07-21 04:46:12 --> Helper loaded: date_helper
INFO - 2018-07-21 04:46:12 --> Helper loaded: util_helper
INFO - 2018-07-21 04:46:12 --> Helper loaded: text_helper
INFO - 2018-07-21 04:46:12 --> Helper loaded: string_helper
INFO - 2018-07-21 04:46:12 --> Database Driver Class Initialized
DEBUG - 2018-07-21 04:46:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-21 04:46:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-21 04:46:12 --> Email Class Initialized
INFO - 2018-07-21 04:46:12 --> Controller Class Initialized
DEBUG - 2018-07-21 04:46:12 --> Users MX_Controller Initialized
DEBUG - 2018-07-21 04:46:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-21 04:46:12 --> Helper loaded: file_helper
DEBUG - 2018-07-21 04:46:12 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-21 04:46:12 --> Login MX_Controller Initialized
INFO - 2018-07-21 04:46:12 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-21 04:46:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-21 04:46:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
DEBUG - 2018-07-21 04:46:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-07-21 04:46:34 --> Config Class Initialized
INFO - 2018-07-21 04:46:34 --> Hooks Class Initialized
DEBUG - 2018-07-21 04:46:34 --> UTF-8 Support Enabled
INFO - 2018-07-21 04:46:34 --> Utf8 Class Initialized
INFO - 2018-07-21 04:46:34 --> URI Class Initialized
INFO - 2018-07-21 04:46:34 --> Router Class Initialized
INFO - 2018-07-21 04:46:34 --> Output Class Initialized
INFO - 2018-07-21 04:46:35 --> Security Class Initialized
DEBUG - 2018-07-21 04:46:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 04:46:35 --> Input Class Initialized
INFO - 2018-07-21 04:46:35 --> Language Class Initialized
INFO - 2018-07-21 04:46:35 --> Language Class Initialized
INFO - 2018-07-21 04:46:35 --> Config Class Initialized
INFO - 2018-07-21 04:46:35 --> Loader Class Initialized
DEBUG - 2018-07-21 04:46:35 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-21 04:46:35 --> Helper loaded: url_helper
INFO - 2018-07-21 04:46:35 --> Helper loaded: form_helper
INFO - 2018-07-21 04:46:35 --> Helper loaded: date_helper
INFO - 2018-07-21 04:46:35 --> Helper loaded: util_helper
INFO - 2018-07-21 04:46:35 --> Helper loaded: text_helper
INFO - 2018-07-21 04:46:35 --> Helper loaded: string_helper
INFO - 2018-07-21 04:46:35 --> Database Driver Class Initialized
DEBUG - 2018-07-21 04:46:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-21 04:46:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-21 04:46:35 --> Email Class Initialized
INFO - 2018-07-21 04:46:35 --> Controller Class Initialized
DEBUG - 2018-07-21 04:46:35 --> Users MX_Controller Initialized
DEBUG - 2018-07-21 04:46:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-21 04:46:35 --> Helper loaded: file_helper
DEBUG - 2018-07-21 04:46:35 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-21 04:46:35 --> Login MX_Controller Initialized
INFO - 2018-07-21 04:46:35 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-21 04:46:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-21 04:46:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
DEBUG - 2018-07-21 04:46:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-07-21 04:46:39 --> Config Class Initialized
INFO - 2018-07-21 04:46:39 --> Hooks Class Initialized
DEBUG - 2018-07-21 04:46:39 --> UTF-8 Support Enabled
INFO - 2018-07-21 04:46:40 --> Utf8 Class Initialized
INFO - 2018-07-21 04:46:40 --> URI Class Initialized
INFO - 2018-07-21 04:46:40 --> Router Class Initialized
INFO - 2018-07-21 04:46:40 --> Output Class Initialized
INFO - 2018-07-21 04:46:40 --> Security Class Initialized
DEBUG - 2018-07-21 04:46:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 04:46:40 --> Input Class Initialized
INFO - 2018-07-21 04:46:40 --> Language Class Initialized
INFO - 2018-07-21 04:46:40 --> Language Class Initialized
INFO - 2018-07-21 04:46:40 --> Config Class Initialized
INFO - 2018-07-21 04:46:40 --> Loader Class Initialized
DEBUG - 2018-07-21 04:46:40 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-21 04:46:40 --> Helper loaded: url_helper
INFO - 2018-07-21 04:46:40 --> Helper loaded: form_helper
INFO - 2018-07-21 04:46:40 --> Helper loaded: date_helper
INFO - 2018-07-21 04:46:40 --> Helper loaded: util_helper
INFO - 2018-07-21 04:46:40 --> Helper loaded: text_helper
INFO - 2018-07-21 04:46:40 --> Helper loaded: string_helper
INFO - 2018-07-21 04:46:40 --> Database Driver Class Initialized
DEBUG - 2018-07-21 04:46:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-21 04:46:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-21 04:46:40 --> Email Class Initialized
INFO - 2018-07-21 04:46:40 --> Controller Class Initialized
DEBUG - 2018-07-21 04:46:40 --> Users MX_Controller Initialized
DEBUG - 2018-07-21 04:46:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-21 04:46:40 --> Helper loaded: file_helper
DEBUG - 2018-07-21 04:46:40 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-21 04:46:40 --> Login MX_Controller Initialized
INFO - 2018-07-21 04:46:40 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-21 04:46:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-21 04:46:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-21 04:46:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-21 04:46:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-21 04:46:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-21 04:46:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-21 04:46:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/users.php
INFO - 2018-07-21 04:46:40 --> Final output sent to browser
DEBUG - 2018-07-21 04:46:40 --> Total execution time: 0.5902
INFO - 2018-07-21 04:46:40 --> Config Class Initialized
INFO - 2018-07-21 04:46:40 --> Hooks Class Initialized
DEBUG - 2018-07-21 04:46:40 --> UTF-8 Support Enabled
INFO - 2018-07-21 04:46:41 --> Utf8 Class Initialized
INFO - 2018-07-21 04:46:41 --> URI Class Initialized
INFO - 2018-07-21 04:46:41 --> Router Class Initialized
INFO - 2018-07-21 04:46:41 --> Output Class Initialized
INFO - 2018-07-21 04:46:41 --> Security Class Initialized
DEBUG - 2018-07-21 04:46:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 04:46:41 --> Input Class Initialized
INFO - 2018-07-21 04:46:41 --> Language Class Initialized
INFO - 2018-07-21 04:46:41 --> Language Class Initialized
INFO - 2018-07-21 04:46:41 --> Config Class Initialized
INFO - 2018-07-21 04:46:41 --> Loader Class Initialized
DEBUG - 2018-07-21 04:46:41 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-21 04:46:41 --> Helper loaded: url_helper
INFO - 2018-07-21 04:46:41 --> Helper loaded: form_helper
INFO - 2018-07-21 04:46:41 --> Helper loaded: date_helper
INFO - 2018-07-21 04:46:41 --> Helper loaded: util_helper
INFO - 2018-07-21 04:46:41 --> Helper loaded: text_helper
INFO - 2018-07-21 04:46:41 --> Helper loaded: string_helper
INFO - 2018-07-21 04:46:41 --> Database Driver Class Initialized
DEBUG - 2018-07-21 04:46:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-21 04:46:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-21 04:46:41 --> Email Class Initialized
INFO - 2018-07-21 04:46:41 --> Controller Class Initialized
DEBUG - 2018-07-21 04:46:41 --> Users MX_Controller Initialized
DEBUG - 2018-07-21 04:46:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-21 04:46:41 --> Helper loaded: file_helper
DEBUG - 2018-07-21 04:46:41 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-21 04:46:41 --> Login MX_Controller Initialized
INFO - 2018-07-21 04:46:41 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-21 04:46:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-21 04:46:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-07-21 04:46:41 --> Final output sent to browser
DEBUG - 2018-07-21 04:46:41 --> Total execution time: 0.6099
INFO - 2018-07-21 04:46:42 --> Config Class Initialized
INFO - 2018-07-21 04:46:42 --> Hooks Class Initialized
DEBUG - 2018-07-21 04:46:42 --> UTF-8 Support Enabled
INFO - 2018-07-21 04:46:42 --> Utf8 Class Initialized
INFO - 2018-07-21 04:46:42 --> URI Class Initialized
INFO - 2018-07-21 04:46:42 --> Router Class Initialized
INFO - 2018-07-21 04:46:42 --> Output Class Initialized
INFO - 2018-07-21 04:46:42 --> Security Class Initialized
DEBUG - 2018-07-21 04:46:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 04:46:42 --> Input Class Initialized
INFO - 2018-07-21 04:46:42 --> Language Class Initialized
INFO - 2018-07-21 04:46:42 --> Language Class Initialized
INFO - 2018-07-21 04:46:42 --> Config Class Initialized
INFO - 2018-07-21 04:46:42 --> Loader Class Initialized
DEBUG - 2018-07-21 04:46:42 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-21 04:46:42 --> Helper loaded: url_helper
INFO - 2018-07-21 04:46:42 --> Helper loaded: form_helper
INFO - 2018-07-21 04:46:42 --> Helper loaded: date_helper
INFO - 2018-07-21 04:46:42 --> Helper loaded: util_helper
INFO - 2018-07-21 04:46:42 --> Helper loaded: text_helper
INFO - 2018-07-21 04:46:43 --> Helper loaded: string_helper
INFO - 2018-07-21 04:46:43 --> Database Driver Class Initialized
DEBUG - 2018-07-21 04:46:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-21 04:46:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-21 04:46:43 --> Email Class Initialized
INFO - 2018-07-21 04:46:43 --> Controller Class Initialized
DEBUG - 2018-07-21 04:46:43 --> Users MX_Controller Initialized
DEBUG - 2018-07-21 04:46:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-21 04:46:43 --> Helper loaded: file_helper
DEBUG - 2018-07-21 04:46:43 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-21 04:46:43 --> Login MX_Controller Initialized
INFO - 2018-07-21 04:46:43 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-21 04:46:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-21 04:46:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
DEBUG - 2018-07-21 04:46:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-21 04:46:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-21 04:46:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-21 04:46:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-21 04:46:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-21 04:46:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-21 04:46:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/create_user.php
INFO - 2018-07-21 04:46:43 --> Final output sent to browser
DEBUG - 2018-07-21 04:46:43 --> Total execution time: 0.4939
INFO - 2018-07-21 04:46:45 --> Config Class Initialized
INFO - 2018-07-21 04:46:45 --> Hooks Class Initialized
DEBUG - 2018-07-21 04:46:45 --> UTF-8 Support Enabled
INFO - 2018-07-21 04:46:45 --> Utf8 Class Initialized
INFO - 2018-07-21 04:46:45 --> URI Class Initialized
INFO - 2018-07-21 04:46:45 --> Router Class Initialized
INFO - 2018-07-21 04:46:45 --> Output Class Initialized
INFO - 2018-07-21 04:46:45 --> Security Class Initialized
DEBUG - 2018-07-21 04:46:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 04:46:45 --> Input Class Initialized
INFO - 2018-07-21 04:46:45 --> Language Class Initialized
INFO - 2018-07-21 04:46:45 --> Language Class Initialized
INFO - 2018-07-21 04:46:45 --> Config Class Initialized
INFO - 2018-07-21 04:46:45 --> Loader Class Initialized
DEBUG - 2018-07-21 04:46:45 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-21 04:46:45 --> Helper loaded: url_helper
INFO - 2018-07-21 04:46:45 --> Helper loaded: form_helper
INFO - 2018-07-21 04:46:45 --> Helper loaded: date_helper
INFO - 2018-07-21 04:46:45 --> Helper loaded: util_helper
INFO - 2018-07-21 04:46:45 --> Helper loaded: text_helper
INFO - 2018-07-21 04:46:45 --> Helper loaded: string_helper
INFO - 2018-07-21 04:46:46 --> Database Driver Class Initialized
DEBUG - 2018-07-21 04:46:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-21 04:46:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-21 04:46:46 --> Email Class Initialized
INFO - 2018-07-21 04:46:46 --> Controller Class Initialized
DEBUG - 2018-07-21 04:46:46 --> Users MX_Controller Initialized
DEBUG - 2018-07-21 04:46:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-21 04:46:46 --> Helper loaded: file_helper
DEBUG - 2018-07-21 04:46:46 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-21 04:46:46 --> Login MX_Controller Initialized
INFO - 2018-07-21 04:46:46 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-21 04:46:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-21 04:46:46 --> Final output sent to browser
DEBUG - 2018-07-21 04:46:46 --> Total execution time: 0.4441
INFO - 2018-07-21 04:46:47 --> Config Class Initialized
INFO - 2018-07-21 04:46:47 --> Hooks Class Initialized
DEBUG - 2018-07-21 04:46:47 --> UTF-8 Support Enabled
INFO - 2018-07-21 04:46:47 --> Utf8 Class Initialized
INFO - 2018-07-21 04:46:47 --> URI Class Initialized
INFO - 2018-07-21 04:46:47 --> Router Class Initialized
INFO - 2018-07-21 04:46:47 --> Output Class Initialized
INFO - 2018-07-21 04:46:47 --> Security Class Initialized
DEBUG - 2018-07-21 04:46:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 04:46:47 --> Input Class Initialized
INFO - 2018-07-21 04:46:47 --> Language Class Initialized
INFO - 2018-07-21 04:46:47 --> Language Class Initialized
INFO - 2018-07-21 04:46:47 --> Config Class Initialized
INFO - 2018-07-21 04:46:47 --> Loader Class Initialized
DEBUG - 2018-07-21 04:46:47 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-21 04:46:47 --> Helper loaded: url_helper
INFO - 2018-07-21 04:46:47 --> Helper loaded: form_helper
INFO - 2018-07-21 04:46:47 --> Helper loaded: date_helper
INFO - 2018-07-21 04:46:47 --> Helper loaded: util_helper
INFO - 2018-07-21 04:46:47 --> Helper loaded: text_helper
INFO - 2018-07-21 04:46:47 --> Helper loaded: string_helper
INFO - 2018-07-21 04:46:47 --> Database Driver Class Initialized
DEBUG - 2018-07-21 04:46:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-21 04:46:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-21 04:46:47 --> Email Class Initialized
INFO - 2018-07-21 04:46:47 --> Controller Class Initialized
DEBUG - 2018-07-21 04:46:48 --> Users MX_Controller Initialized
DEBUG - 2018-07-21 04:46:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-21 04:46:48 --> Helper loaded: file_helper
DEBUG - 2018-07-21 04:46:48 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-21 04:46:48 --> Login MX_Controller Initialized
INFO - 2018-07-21 04:46:48 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-21 04:46:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-21 04:46:48 --> Final output sent to browser
DEBUG - 2018-07-21 04:46:48 --> Total execution time: 0.4267
INFO - 2018-07-21 04:47:02 --> Config Class Initialized
INFO - 2018-07-21 04:47:03 --> Hooks Class Initialized
DEBUG - 2018-07-21 04:47:03 --> UTF-8 Support Enabled
INFO - 2018-07-21 04:47:03 --> Utf8 Class Initialized
INFO - 2018-07-21 04:47:03 --> URI Class Initialized
INFO - 2018-07-21 04:47:03 --> Router Class Initialized
INFO - 2018-07-21 04:47:03 --> Output Class Initialized
INFO - 2018-07-21 04:47:03 --> Security Class Initialized
DEBUG - 2018-07-21 04:47:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 04:47:03 --> Input Class Initialized
INFO - 2018-07-21 04:47:03 --> Language Class Initialized
INFO - 2018-07-21 04:47:03 --> Language Class Initialized
INFO - 2018-07-21 04:47:03 --> Config Class Initialized
INFO - 2018-07-21 04:47:03 --> Loader Class Initialized
DEBUG - 2018-07-21 04:47:03 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-21 04:47:03 --> Helper loaded: url_helper
INFO - 2018-07-21 04:47:03 --> Helper loaded: form_helper
INFO - 2018-07-21 04:47:03 --> Helper loaded: date_helper
INFO - 2018-07-21 04:47:03 --> Helper loaded: util_helper
INFO - 2018-07-21 04:47:03 --> Helper loaded: text_helper
INFO - 2018-07-21 04:47:03 --> Helper loaded: string_helper
INFO - 2018-07-21 04:47:03 --> Database Driver Class Initialized
DEBUG - 2018-07-21 04:47:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-21 04:47:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-21 04:47:03 --> Email Class Initialized
INFO - 2018-07-21 04:47:03 --> Controller Class Initialized
DEBUG - 2018-07-21 04:47:03 --> Users MX_Controller Initialized
DEBUG - 2018-07-21 04:47:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-21 04:47:03 --> Helper loaded: file_helper
DEBUG - 2018-07-21 04:47:03 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-21 04:47:03 --> Login MX_Controller Initialized
INFO - 2018-07-21 04:47:03 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-21 04:47:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-21 04:47:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
DEBUG - 2018-07-21 04:47:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-21 04:47:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
INFO - 2018-07-21 04:47:03 --> Upload Class Initialized
INFO - 2018-07-21 04:47:03 --> Passsword for email - gopaltesting1@yopmail.com - is :: Testing3632
DEBUG - 2018-07-21 04:47:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/templates/credentials.php
DEBUG - 2018-07-21 04:47:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Mail_model.php
DEBUG - 2018-07-21 04:47:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/mail_view.php
INFO - 2018-07-21 04:47:03 --> Mail logged successfully
INFO - 2018-07-21 04:47:03 --> Config Class Initialized
INFO - 2018-07-21 04:47:03 --> Hooks Class Initialized
DEBUG - 2018-07-21 04:47:03 --> UTF-8 Support Enabled
INFO - 2018-07-21 04:47:03 --> Utf8 Class Initialized
INFO - 2018-07-21 04:47:03 --> URI Class Initialized
INFO - 2018-07-21 04:47:03 --> Router Class Initialized
INFO - 2018-07-21 04:47:03 --> Output Class Initialized
INFO - 2018-07-21 04:47:04 --> Security Class Initialized
DEBUG - 2018-07-21 04:47:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 04:47:04 --> Input Class Initialized
INFO - 2018-07-21 04:47:04 --> Language Class Initialized
INFO - 2018-07-21 04:47:04 --> Language Class Initialized
INFO - 2018-07-21 04:47:04 --> Config Class Initialized
INFO - 2018-07-21 04:47:04 --> Loader Class Initialized
DEBUG - 2018-07-21 04:47:04 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-21 04:47:04 --> Helper loaded: url_helper
INFO - 2018-07-21 04:47:04 --> Helper loaded: form_helper
INFO - 2018-07-21 04:47:04 --> Helper loaded: date_helper
INFO - 2018-07-21 04:47:04 --> Helper loaded: util_helper
INFO - 2018-07-21 04:47:04 --> Helper loaded: text_helper
INFO - 2018-07-21 04:47:04 --> Helper loaded: string_helper
INFO - 2018-07-21 04:47:04 --> Database Driver Class Initialized
DEBUG - 2018-07-21 04:47:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-21 04:47:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-21 04:47:04 --> Email Class Initialized
INFO - 2018-07-21 04:47:04 --> Controller Class Initialized
DEBUG - 2018-07-21 04:47:04 --> Users MX_Controller Initialized
DEBUG - 2018-07-21 04:47:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-21 04:47:04 --> Helper loaded: file_helper
DEBUG - 2018-07-21 04:47:04 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-21 04:47:04 --> Login MX_Controller Initialized
INFO - 2018-07-21 04:47:04 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-21 04:47:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-21 04:47:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-21 04:47:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-21 04:47:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-21 04:47:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-21 04:47:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-21 04:47:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/users.php
INFO - 2018-07-21 04:47:04 --> Final output sent to browser
DEBUG - 2018-07-21 04:47:04 --> Total execution time: 0.4977
INFO - 2018-07-21 04:47:04 --> Config Class Initialized
INFO - 2018-07-21 04:47:04 --> Hooks Class Initialized
DEBUG - 2018-07-21 04:47:04 --> UTF-8 Support Enabled
INFO - 2018-07-21 04:47:04 --> Utf8 Class Initialized
INFO - 2018-07-21 04:47:05 --> URI Class Initialized
INFO - 2018-07-21 04:47:05 --> Router Class Initialized
INFO - 2018-07-21 04:47:05 --> Output Class Initialized
INFO - 2018-07-21 04:47:05 --> Security Class Initialized
DEBUG - 2018-07-21 04:47:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 04:47:05 --> Input Class Initialized
INFO - 2018-07-21 04:47:05 --> Language Class Initialized
INFO - 2018-07-21 04:47:05 --> Language Class Initialized
INFO - 2018-07-21 04:47:05 --> Config Class Initialized
INFO - 2018-07-21 04:47:05 --> Loader Class Initialized
DEBUG - 2018-07-21 04:47:05 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-21 04:47:05 --> Helper loaded: url_helper
INFO - 2018-07-21 04:47:05 --> Helper loaded: form_helper
INFO - 2018-07-21 04:47:05 --> Helper loaded: date_helper
INFO - 2018-07-21 04:47:05 --> Helper loaded: util_helper
INFO - 2018-07-21 04:47:05 --> Helper loaded: text_helper
INFO - 2018-07-21 04:47:05 --> Helper loaded: string_helper
INFO - 2018-07-21 04:47:05 --> Database Driver Class Initialized
DEBUG - 2018-07-21 04:47:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-21 04:47:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-21 04:47:05 --> Email Class Initialized
INFO - 2018-07-21 04:47:05 --> Controller Class Initialized
DEBUG - 2018-07-21 04:47:05 --> Users MX_Controller Initialized
DEBUG - 2018-07-21 04:47:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-21 04:47:05 --> Helper loaded: file_helper
DEBUG - 2018-07-21 04:47:05 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-21 04:47:05 --> Login MX_Controller Initialized
INFO - 2018-07-21 04:47:05 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-21 04:47:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-21 04:47:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-07-21 04:47:05 --> Final output sent to browser
DEBUG - 2018-07-21 04:47:05 --> Total execution time: 0.5685
INFO - 2018-07-21 04:47:11 --> Config Class Initialized
INFO - 2018-07-21 04:47:11 --> Hooks Class Initialized
DEBUG - 2018-07-21 04:47:11 --> UTF-8 Support Enabled
INFO - 2018-07-21 04:47:11 --> Utf8 Class Initialized
INFO - 2018-07-21 04:47:11 --> URI Class Initialized
INFO - 2018-07-21 04:47:11 --> Router Class Initialized
INFO - 2018-07-21 04:47:12 --> Output Class Initialized
INFO - 2018-07-21 04:47:12 --> Security Class Initialized
DEBUG - 2018-07-21 04:47:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 04:47:12 --> Input Class Initialized
INFO - 2018-07-21 04:47:12 --> Language Class Initialized
INFO - 2018-07-21 04:47:12 --> Language Class Initialized
INFO - 2018-07-21 04:47:12 --> Config Class Initialized
INFO - 2018-07-21 04:47:12 --> Loader Class Initialized
DEBUG - 2018-07-21 04:47:12 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-21 04:47:12 --> Helper loaded: url_helper
INFO - 2018-07-21 04:47:12 --> Helper loaded: form_helper
INFO - 2018-07-21 04:47:12 --> Helper loaded: date_helper
INFO - 2018-07-21 04:47:12 --> Helper loaded: util_helper
INFO - 2018-07-21 04:47:12 --> Helper loaded: text_helper
INFO - 2018-07-21 04:47:12 --> Helper loaded: string_helper
INFO - 2018-07-21 04:47:12 --> Database Driver Class Initialized
DEBUG - 2018-07-21 04:47:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-21 04:47:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-21 04:47:12 --> Email Class Initialized
INFO - 2018-07-21 04:47:12 --> Controller Class Initialized
DEBUG - 2018-07-21 04:47:12 --> Users MX_Controller Initialized
DEBUG - 2018-07-21 04:47:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-21 04:47:12 --> Helper loaded: file_helper
DEBUG - 2018-07-21 04:47:12 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-21 04:47:12 --> Login MX_Controller Initialized
INFO - 2018-07-21 04:47:12 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-21 04:47:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-21 04:47:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-21 04:47:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-21 04:47:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-21 04:47:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-21 04:47:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-21 04:47:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/users.php
INFO - 2018-07-21 04:47:12 --> Final output sent to browser
DEBUG - 2018-07-21 04:47:12 --> Total execution time: 0.5904
INFO - 2018-07-21 04:47:12 --> Config Class Initialized
INFO - 2018-07-21 04:47:12 --> Hooks Class Initialized
DEBUG - 2018-07-21 04:47:12 --> UTF-8 Support Enabled
INFO - 2018-07-21 04:47:12 --> Utf8 Class Initialized
INFO - 2018-07-21 04:47:13 --> URI Class Initialized
INFO - 2018-07-21 04:47:13 --> Router Class Initialized
INFO - 2018-07-21 04:47:13 --> Output Class Initialized
INFO - 2018-07-21 04:47:13 --> Security Class Initialized
DEBUG - 2018-07-21 04:47:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 04:47:13 --> Input Class Initialized
INFO - 2018-07-21 04:47:13 --> Language Class Initialized
INFO - 2018-07-21 04:47:13 --> Language Class Initialized
INFO - 2018-07-21 04:47:13 --> Config Class Initialized
INFO - 2018-07-21 04:47:13 --> Loader Class Initialized
DEBUG - 2018-07-21 04:47:13 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-21 04:47:13 --> Helper loaded: url_helper
INFO - 2018-07-21 04:47:13 --> Helper loaded: form_helper
INFO - 2018-07-21 04:47:13 --> Helper loaded: date_helper
INFO - 2018-07-21 04:47:13 --> Helper loaded: util_helper
INFO - 2018-07-21 04:47:13 --> Helper loaded: text_helper
INFO - 2018-07-21 04:47:13 --> Helper loaded: string_helper
INFO - 2018-07-21 04:47:13 --> Database Driver Class Initialized
DEBUG - 2018-07-21 04:47:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-21 04:47:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-21 04:47:13 --> Email Class Initialized
INFO - 2018-07-21 04:47:13 --> Controller Class Initialized
DEBUG - 2018-07-21 04:47:13 --> Users MX_Controller Initialized
DEBUG - 2018-07-21 04:47:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-21 04:47:13 --> Helper loaded: file_helper
DEBUG - 2018-07-21 04:47:13 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-21 04:47:13 --> Login MX_Controller Initialized
INFO - 2018-07-21 04:47:13 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-21 04:47:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-21 04:47:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-07-21 04:47:13 --> Final output sent to browser
DEBUG - 2018-07-21 04:47:13 --> Total execution time: 0.5717
INFO - 2018-07-21 04:47:28 --> Config Class Initialized
INFO - 2018-07-21 04:47:28 --> Hooks Class Initialized
DEBUG - 2018-07-21 04:47:28 --> UTF-8 Support Enabled
INFO - 2018-07-21 04:47:28 --> Utf8 Class Initialized
INFO - 2018-07-21 04:47:28 --> URI Class Initialized
INFO - 2018-07-21 04:47:28 --> Router Class Initialized
INFO - 2018-07-21 04:47:28 --> Output Class Initialized
INFO - 2018-07-21 04:47:28 --> Security Class Initialized
DEBUG - 2018-07-21 04:47:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 04:47:28 --> Input Class Initialized
INFO - 2018-07-21 04:47:28 --> Language Class Initialized
INFO - 2018-07-21 04:47:28 --> Language Class Initialized
INFO - 2018-07-21 04:47:28 --> Config Class Initialized
INFO - 2018-07-21 04:47:28 --> Loader Class Initialized
DEBUG - 2018-07-21 04:47:28 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-21 04:47:28 --> Helper loaded: url_helper
INFO - 2018-07-21 04:47:28 --> Helper loaded: form_helper
INFO - 2018-07-21 04:47:28 --> Helper loaded: date_helper
INFO - 2018-07-21 04:47:28 --> Helper loaded: util_helper
INFO - 2018-07-21 04:47:28 --> Helper loaded: text_helper
INFO - 2018-07-21 04:47:28 --> Helper loaded: string_helper
INFO - 2018-07-21 04:47:28 --> Database Driver Class Initialized
DEBUG - 2018-07-21 04:47:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-21 04:47:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-21 04:47:28 --> Email Class Initialized
INFO - 2018-07-21 04:47:28 --> Controller Class Initialized
DEBUG - 2018-07-21 04:47:28 --> Users MX_Controller Initialized
DEBUG - 2018-07-21 04:47:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-21 04:47:28 --> Helper loaded: file_helper
DEBUG - 2018-07-21 04:47:28 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-21 04:47:28 --> Login MX_Controller Initialized
INFO - 2018-07-21 04:47:28 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-21 04:47:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-21 04:47:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
DEBUG - 2018-07-21 04:47:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-07-21 04:47:49 --> Config Class Initialized
INFO - 2018-07-21 04:47:49 --> Hooks Class Initialized
DEBUG - 2018-07-21 04:47:50 --> UTF-8 Support Enabled
INFO - 2018-07-21 04:47:50 --> Utf8 Class Initialized
INFO - 2018-07-21 04:47:50 --> URI Class Initialized
INFO - 2018-07-21 04:47:50 --> Router Class Initialized
INFO - 2018-07-21 04:47:50 --> Output Class Initialized
INFO - 2018-07-21 04:47:50 --> Security Class Initialized
DEBUG - 2018-07-21 04:47:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 04:47:50 --> Input Class Initialized
INFO - 2018-07-21 04:47:50 --> Language Class Initialized
INFO - 2018-07-21 04:47:50 --> Language Class Initialized
INFO - 2018-07-21 04:47:50 --> Config Class Initialized
INFO - 2018-07-21 04:47:50 --> Loader Class Initialized
DEBUG - 2018-07-21 04:47:50 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-21 04:47:50 --> Helper loaded: url_helper
INFO - 2018-07-21 04:47:50 --> Helper loaded: form_helper
INFO - 2018-07-21 04:47:50 --> Helper loaded: date_helper
INFO - 2018-07-21 04:47:50 --> Helper loaded: util_helper
INFO - 2018-07-21 04:47:50 --> Helper loaded: text_helper
INFO - 2018-07-21 04:47:50 --> Helper loaded: string_helper
INFO - 2018-07-21 04:47:50 --> Database Driver Class Initialized
DEBUG - 2018-07-21 04:47:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-21 04:47:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-21 04:47:50 --> Email Class Initialized
INFO - 2018-07-21 04:47:50 --> Controller Class Initialized
DEBUG - 2018-07-21 04:47:50 --> Users MX_Controller Initialized
DEBUG - 2018-07-21 04:47:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-21 04:47:50 --> Helper loaded: file_helper
DEBUG - 2018-07-21 04:47:50 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-21 04:47:50 --> Login MX_Controller Initialized
INFO - 2018-07-21 04:47:50 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-21 04:47:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-21 04:47:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
DEBUG - 2018-07-21 04:47:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-07-21 04:49:08 --> Config Class Initialized
INFO - 2018-07-21 04:49:08 --> Hooks Class Initialized
DEBUG - 2018-07-21 04:49:08 --> UTF-8 Support Enabled
INFO - 2018-07-21 04:49:08 --> Utf8 Class Initialized
INFO - 2018-07-21 04:49:08 --> URI Class Initialized
INFO - 2018-07-21 04:49:08 --> Router Class Initialized
INFO - 2018-07-21 04:49:08 --> Output Class Initialized
INFO - 2018-07-21 04:49:08 --> Security Class Initialized
DEBUG - 2018-07-21 04:49:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 04:49:08 --> Input Class Initialized
INFO - 2018-07-21 04:49:08 --> Language Class Initialized
INFO - 2018-07-21 04:49:08 --> Language Class Initialized
INFO - 2018-07-21 04:49:08 --> Config Class Initialized
INFO - 2018-07-21 04:49:08 --> Loader Class Initialized
DEBUG - 2018-07-21 04:49:08 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-21 04:49:08 --> Helper loaded: url_helper
INFO - 2018-07-21 04:49:08 --> Helper loaded: form_helper
INFO - 2018-07-21 04:49:08 --> Helper loaded: date_helper
INFO - 2018-07-21 04:49:08 --> Helper loaded: util_helper
INFO - 2018-07-21 04:49:08 --> Helper loaded: text_helper
INFO - 2018-07-21 04:49:08 --> Helper loaded: string_helper
INFO - 2018-07-21 04:49:08 --> Database Driver Class Initialized
DEBUG - 2018-07-21 04:49:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-21 04:49:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-21 04:49:08 --> Email Class Initialized
INFO - 2018-07-21 04:49:08 --> Controller Class Initialized
DEBUG - 2018-07-21 04:49:08 --> Users MX_Controller Initialized
DEBUG - 2018-07-21 04:49:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-21 04:49:08 --> Helper loaded: file_helper
DEBUG - 2018-07-21 04:49:08 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-21 04:49:08 --> Login MX_Controller Initialized
INFO - 2018-07-21 04:49:08 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-21 04:49:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-21 04:49:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
DEBUG - 2018-07-21 04:49:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-07-21 04:49:43 --> Config Class Initialized
INFO - 2018-07-21 04:49:43 --> Hooks Class Initialized
DEBUG - 2018-07-21 04:49:43 --> UTF-8 Support Enabled
INFO - 2018-07-21 04:49:43 --> Utf8 Class Initialized
INFO - 2018-07-21 04:49:43 --> URI Class Initialized
INFO - 2018-07-21 04:49:43 --> Router Class Initialized
INFO - 2018-07-21 04:49:43 --> Output Class Initialized
INFO - 2018-07-21 04:49:43 --> Security Class Initialized
DEBUG - 2018-07-21 04:49:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 04:49:43 --> Input Class Initialized
INFO - 2018-07-21 04:49:43 --> Language Class Initialized
INFO - 2018-07-21 04:49:43 --> Language Class Initialized
INFO - 2018-07-21 04:49:43 --> Config Class Initialized
INFO - 2018-07-21 04:49:43 --> Loader Class Initialized
DEBUG - 2018-07-21 04:49:43 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-21 04:49:43 --> Helper loaded: url_helper
INFO - 2018-07-21 04:49:43 --> Helper loaded: form_helper
INFO - 2018-07-21 04:49:43 --> Helper loaded: date_helper
INFO - 2018-07-21 04:49:43 --> Helper loaded: util_helper
INFO - 2018-07-21 04:49:43 --> Helper loaded: text_helper
INFO - 2018-07-21 04:49:43 --> Helper loaded: string_helper
INFO - 2018-07-21 04:49:44 --> Database Driver Class Initialized
DEBUG - 2018-07-21 04:49:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-21 04:49:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-21 04:49:44 --> Email Class Initialized
INFO - 2018-07-21 04:49:44 --> Controller Class Initialized
DEBUG - 2018-07-21 04:49:44 --> Users MX_Controller Initialized
DEBUG - 2018-07-21 04:49:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-21 04:49:44 --> Helper loaded: file_helper
DEBUG - 2018-07-21 04:49:44 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-21 04:49:44 --> Login MX_Controller Initialized
INFO - 2018-07-21 04:49:44 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-21 04:49:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-21 04:49:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
DEBUG - 2018-07-21 04:49:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-07-21 04:49:47 --> Config Class Initialized
INFO - 2018-07-21 04:49:47 --> Hooks Class Initialized
DEBUG - 2018-07-21 04:49:47 --> UTF-8 Support Enabled
INFO - 2018-07-21 04:49:47 --> Utf8 Class Initialized
INFO - 2018-07-21 04:49:47 --> URI Class Initialized
INFO - 2018-07-21 04:49:47 --> Router Class Initialized
INFO - 2018-07-21 04:49:47 --> Output Class Initialized
INFO - 2018-07-21 04:49:47 --> Security Class Initialized
DEBUG - 2018-07-21 04:49:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 04:49:47 --> Input Class Initialized
INFO - 2018-07-21 04:49:48 --> Language Class Initialized
INFO - 2018-07-21 04:49:48 --> Language Class Initialized
INFO - 2018-07-21 04:49:48 --> Config Class Initialized
INFO - 2018-07-21 04:49:48 --> Loader Class Initialized
DEBUG - 2018-07-21 04:49:48 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-21 04:49:48 --> Helper loaded: url_helper
INFO - 2018-07-21 04:49:48 --> Helper loaded: form_helper
INFO - 2018-07-21 04:49:48 --> Helper loaded: date_helper
INFO - 2018-07-21 04:49:48 --> Helper loaded: util_helper
INFO - 2018-07-21 04:49:48 --> Helper loaded: text_helper
INFO - 2018-07-21 04:49:48 --> Helper loaded: string_helper
INFO - 2018-07-21 04:49:48 --> Database Driver Class Initialized
DEBUG - 2018-07-21 04:49:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-21 04:49:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-21 04:49:48 --> Email Class Initialized
INFO - 2018-07-21 04:49:48 --> Controller Class Initialized
DEBUG - 2018-07-21 04:49:48 --> Users MX_Controller Initialized
DEBUG - 2018-07-21 04:49:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-21 04:49:48 --> Helper loaded: file_helper
DEBUG - 2018-07-21 04:49:48 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-21 04:49:48 --> Login MX_Controller Initialized
INFO - 2018-07-21 04:49:48 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-21 04:49:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-21 04:49:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
DEBUG - 2018-07-21 04:49:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-07-21 04:49:55 --> Config Class Initialized
INFO - 2018-07-21 04:49:55 --> Hooks Class Initialized
DEBUG - 2018-07-21 04:49:55 --> UTF-8 Support Enabled
INFO - 2018-07-21 04:49:55 --> Utf8 Class Initialized
INFO - 2018-07-21 04:49:55 --> URI Class Initialized
INFO - 2018-07-21 04:49:55 --> Router Class Initialized
INFO - 2018-07-21 04:49:55 --> Output Class Initialized
INFO - 2018-07-21 04:49:55 --> Security Class Initialized
DEBUG - 2018-07-21 04:49:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 04:49:55 --> Input Class Initialized
INFO - 2018-07-21 04:49:55 --> Language Class Initialized
INFO - 2018-07-21 04:49:55 --> Language Class Initialized
INFO - 2018-07-21 04:49:55 --> Config Class Initialized
INFO - 2018-07-21 04:49:55 --> Loader Class Initialized
DEBUG - 2018-07-21 04:49:55 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-21 04:49:55 --> Helper loaded: url_helper
INFO - 2018-07-21 04:49:55 --> Helper loaded: form_helper
INFO - 2018-07-21 04:49:55 --> Helper loaded: date_helper
INFO - 2018-07-21 04:49:55 --> Helper loaded: util_helper
INFO - 2018-07-21 04:49:55 --> Helper loaded: text_helper
INFO - 2018-07-21 04:49:55 --> Helper loaded: string_helper
INFO - 2018-07-21 04:49:55 --> Database Driver Class Initialized
DEBUG - 2018-07-21 04:49:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-21 04:49:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-21 04:49:55 --> Email Class Initialized
INFO - 2018-07-21 04:49:55 --> Controller Class Initialized
DEBUG - 2018-07-21 04:49:55 --> Users MX_Controller Initialized
DEBUG - 2018-07-21 04:49:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-21 04:49:55 --> Helper loaded: file_helper
DEBUG - 2018-07-21 04:49:55 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-21 04:49:55 --> Login MX_Controller Initialized
INFO - 2018-07-21 04:49:55 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-21 04:49:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-21 04:49:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
DEBUG - 2018-07-21 04:49:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-07-21 04:55:42 --> Config Class Initialized
INFO - 2018-07-21 04:55:42 --> Hooks Class Initialized
DEBUG - 2018-07-21 04:55:42 --> UTF-8 Support Enabled
INFO - 2018-07-21 04:55:42 --> Utf8 Class Initialized
INFO - 2018-07-21 04:55:42 --> URI Class Initialized
INFO - 2018-07-21 04:55:42 --> Router Class Initialized
INFO - 2018-07-21 04:55:42 --> Output Class Initialized
INFO - 2018-07-21 04:55:42 --> Security Class Initialized
DEBUG - 2018-07-21 04:55:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 04:55:42 --> Input Class Initialized
INFO - 2018-07-21 04:55:42 --> Language Class Initialized
INFO - 2018-07-21 04:55:42 --> Language Class Initialized
INFO - 2018-07-21 04:55:42 --> Config Class Initialized
INFO - 2018-07-21 04:55:42 --> Loader Class Initialized
DEBUG - 2018-07-21 04:55:42 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-21 04:55:42 --> Helper loaded: url_helper
INFO - 2018-07-21 04:55:42 --> Helper loaded: form_helper
INFO - 2018-07-21 04:55:42 --> Helper loaded: date_helper
INFO - 2018-07-21 04:55:42 --> Helper loaded: util_helper
INFO - 2018-07-21 04:55:42 --> Helper loaded: text_helper
INFO - 2018-07-21 04:55:42 --> Helper loaded: string_helper
INFO - 2018-07-21 04:55:42 --> Database Driver Class Initialized
DEBUG - 2018-07-21 04:55:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-21 04:55:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-21 04:55:42 --> Email Class Initialized
INFO - 2018-07-21 04:55:42 --> Controller Class Initialized
DEBUG - 2018-07-21 04:55:42 --> Users MX_Controller Initialized
DEBUG - 2018-07-21 04:55:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-21 04:55:42 --> Helper loaded: file_helper
DEBUG - 2018-07-21 04:55:42 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-21 04:55:42 --> Login MX_Controller Initialized
INFO - 2018-07-21 04:55:42 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-21 04:55:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-21 04:55:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
DEBUG - 2018-07-21 04:55:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-07-21 04:56:09 --> Config Class Initialized
INFO - 2018-07-21 04:56:09 --> Hooks Class Initialized
DEBUG - 2018-07-21 04:56:09 --> UTF-8 Support Enabled
INFO - 2018-07-21 04:56:09 --> Utf8 Class Initialized
INFO - 2018-07-21 04:56:09 --> URI Class Initialized
INFO - 2018-07-21 04:56:09 --> Router Class Initialized
INFO - 2018-07-21 04:56:09 --> Output Class Initialized
INFO - 2018-07-21 04:56:09 --> Security Class Initialized
DEBUG - 2018-07-21 04:56:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 04:56:09 --> Input Class Initialized
INFO - 2018-07-21 04:56:09 --> Language Class Initialized
INFO - 2018-07-21 04:56:09 --> Language Class Initialized
INFO - 2018-07-21 04:56:09 --> Config Class Initialized
INFO - 2018-07-21 04:56:09 --> Loader Class Initialized
DEBUG - 2018-07-21 04:56:09 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-21 04:56:09 --> Helper loaded: url_helper
INFO - 2018-07-21 04:56:09 --> Helper loaded: form_helper
INFO - 2018-07-21 04:56:09 --> Helper loaded: date_helper
INFO - 2018-07-21 04:56:09 --> Helper loaded: util_helper
INFO - 2018-07-21 04:56:09 --> Helper loaded: text_helper
INFO - 2018-07-21 04:56:09 --> Helper loaded: string_helper
INFO - 2018-07-21 04:56:09 --> Database Driver Class Initialized
DEBUG - 2018-07-21 04:56:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-21 04:56:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-21 04:56:09 --> Email Class Initialized
INFO - 2018-07-21 04:56:09 --> Controller Class Initialized
DEBUG - 2018-07-21 04:56:09 --> Users MX_Controller Initialized
DEBUG - 2018-07-21 04:56:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-21 04:56:09 --> Helper loaded: file_helper
DEBUG - 2018-07-21 04:56:09 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-21 04:56:09 --> Login MX_Controller Initialized
INFO - 2018-07-21 04:56:09 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-21 04:56:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-21 04:56:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
DEBUG - 2018-07-21 04:56:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-07-21 04:56:44 --> Config Class Initialized
INFO - 2018-07-21 04:56:44 --> Hooks Class Initialized
DEBUG - 2018-07-21 04:56:44 --> UTF-8 Support Enabled
INFO - 2018-07-21 04:56:44 --> Utf8 Class Initialized
INFO - 2018-07-21 04:56:44 --> URI Class Initialized
INFO - 2018-07-21 04:56:44 --> Router Class Initialized
INFO - 2018-07-21 04:56:44 --> Output Class Initialized
INFO - 2018-07-21 04:56:44 --> Security Class Initialized
DEBUG - 2018-07-21 04:56:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 04:56:44 --> Input Class Initialized
INFO - 2018-07-21 04:56:44 --> Language Class Initialized
INFO - 2018-07-21 04:56:44 --> Language Class Initialized
INFO - 2018-07-21 04:56:44 --> Config Class Initialized
INFO - 2018-07-21 04:56:44 --> Loader Class Initialized
DEBUG - 2018-07-21 04:56:44 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-21 04:56:44 --> Helper loaded: url_helper
INFO - 2018-07-21 04:56:44 --> Helper loaded: form_helper
INFO - 2018-07-21 04:56:44 --> Helper loaded: date_helper
INFO - 2018-07-21 04:56:44 --> Helper loaded: util_helper
INFO - 2018-07-21 04:56:44 --> Helper loaded: text_helper
INFO - 2018-07-21 04:56:44 --> Helper loaded: string_helper
INFO - 2018-07-21 04:56:44 --> Database Driver Class Initialized
DEBUG - 2018-07-21 04:56:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-21 04:56:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-21 04:56:44 --> Email Class Initialized
INFO - 2018-07-21 04:56:44 --> Controller Class Initialized
DEBUG - 2018-07-21 04:56:44 --> Users MX_Controller Initialized
DEBUG - 2018-07-21 04:56:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-21 04:56:44 --> Helper loaded: file_helper
DEBUG - 2018-07-21 04:56:44 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-21 04:56:44 --> Login MX_Controller Initialized
INFO - 2018-07-21 04:56:44 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-21 04:56:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-21 04:56:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
DEBUG - 2018-07-21 04:56:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-07-21 04:57:12 --> Config Class Initialized
INFO - 2018-07-21 04:57:12 --> Hooks Class Initialized
DEBUG - 2018-07-21 04:57:12 --> UTF-8 Support Enabled
INFO - 2018-07-21 04:57:12 --> Utf8 Class Initialized
INFO - 2018-07-21 04:57:12 --> URI Class Initialized
INFO - 2018-07-21 04:57:12 --> Router Class Initialized
INFO - 2018-07-21 04:57:12 --> Output Class Initialized
INFO - 2018-07-21 04:57:12 --> Security Class Initialized
DEBUG - 2018-07-21 04:57:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 04:57:12 --> Input Class Initialized
INFO - 2018-07-21 04:57:12 --> Language Class Initialized
INFO - 2018-07-21 04:57:12 --> Language Class Initialized
INFO - 2018-07-21 04:57:12 --> Config Class Initialized
INFO - 2018-07-21 04:57:12 --> Loader Class Initialized
DEBUG - 2018-07-21 04:57:12 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-21 04:57:12 --> Helper loaded: url_helper
INFO - 2018-07-21 04:57:12 --> Helper loaded: form_helper
INFO - 2018-07-21 04:57:12 --> Helper loaded: date_helper
INFO - 2018-07-21 04:57:12 --> Helper loaded: util_helper
INFO - 2018-07-21 04:57:12 --> Helper loaded: text_helper
INFO - 2018-07-21 04:57:12 --> Helper loaded: string_helper
INFO - 2018-07-21 04:57:12 --> Database Driver Class Initialized
DEBUG - 2018-07-21 04:57:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-21 04:57:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-21 04:57:12 --> Email Class Initialized
INFO - 2018-07-21 04:57:12 --> Controller Class Initialized
DEBUG - 2018-07-21 04:57:12 --> Users MX_Controller Initialized
DEBUG - 2018-07-21 04:57:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-21 04:57:12 --> Helper loaded: file_helper
DEBUG - 2018-07-21 04:57:12 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-21 04:57:12 --> Login MX_Controller Initialized
INFO - 2018-07-21 04:57:12 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-21 04:57:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-21 04:57:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
DEBUG - 2018-07-21 04:57:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-21 04:57:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-21 04:57:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-21 04:57:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
ERROR - 2018-07-21 04:57:12 --> Severity: Notice --> Undefined variable: course_selection E:\xampp\htdocs\consulting\application\modules\admin\views\users\create_user.php 111
DEBUG - 2018-07-21 04:57:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-21 04:57:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-21 04:57:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/create_user.php
INFO - 2018-07-21 04:57:12 --> Final output sent to browser
DEBUG - 2018-07-21 04:57:12 --> Total execution time: 0.5477
INFO - 2018-07-21 04:57:42 --> Config Class Initialized
INFO - 2018-07-21 04:57:42 --> Hooks Class Initialized
DEBUG - 2018-07-21 04:57:42 --> UTF-8 Support Enabled
INFO - 2018-07-21 04:57:42 --> Utf8 Class Initialized
INFO - 2018-07-21 04:57:42 --> URI Class Initialized
INFO - 2018-07-21 04:57:42 --> Router Class Initialized
INFO - 2018-07-21 04:57:42 --> Output Class Initialized
INFO - 2018-07-21 04:57:42 --> Security Class Initialized
DEBUG - 2018-07-21 04:57:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 04:57:42 --> Input Class Initialized
INFO - 2018-07-21 04:57:42 --> Language Class Initialized
INFO - 2018-07-21 04:57:42 --> Language Class Initialized
INFO - 2018-07-21 04:57:42 --> Config Class Initialized
INFO - 2018-07-21 04:57:42 --> Loader Class Initialized
DEBUG - 2018-07-21 04:57:42 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-21 04:57:42 --> Helper loaded: url_helper
INFO - 2018-07-21 04:57:42 --> Helper loaded: form_helper
INFO - 2018-07-21 04:57:42 --> Helper loaded: date_helper
INFO - 2018-07-21 04:57:42 --> Helper loaded: util_helper
INFO - 2018-07-21 04:57:42 --> Helper loaded: text_helper
INFO - 2018-07-21 04:57:42 --> Helper loaded: string_helper
INFO - 2018-07-21 04:57:42 --> Database Driver Class Initialized
DEBUG - 2018-07-21 04:57:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-21 04:57:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-21 04:57:42 --> Email Class Initialized
INFO - 2018-07-21 04:57:42 --> Controller Class Initialized
DEBUG - 2018-07-21 04:57:42 --> Users MX_Controller Initialized
DEBUG - 2018-07-21 04:57:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-21 04:57:42 --> Helper loaded: file_helper
DEBUG - 2018-07-21 04:57:42 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-21 04:57:42 --> Login MX_Controller Initialized
INFO - 2018-07-21 04:57:42 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-21 04:57:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-21 04:57:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
DEBUG - 2018-07-21 04:57:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-21 04:57:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-21 04:57:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-21 04:57:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-21 04:57:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-21 04:57:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-21 04:57:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/create_user.php
INFO - 2018-07-21 04:57:43 --> Final output sent to browser
DEBUG - 2018-07-21 04:57:43 --> Total execution time: 0.5344
INFO - 2018-07-21 04:58:09 --> Config Class Initialized
INFO - 2018-07-21 04:58:09 --> Hooks Class Initialized
DEBUG - 2018-07-21 04:58:09 --> UTF-8 Support Enabled
INFO - 2018-07-21 04:58:09 --> Utf8 Class Initialized
INFO - 2018-07-21 04:58:09 --> URI Class Initialized
INFO - 2018-07-21 04:58:09 --> Router Class Initialized
INFO - 2018-07-21 04:58:09 --> Output Class Initialized
INFO - 2018-07-21 04:58:09 --> Security Class Initialized
DEBUG - 2018-07-21 04:58:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 04:58:09 --> Input Class Initialized
INFO - 2018-07-21 04:58:09 --> Language Class Initialized
INFO - 2018-07-21 04:58:09 --> Language Class Initialized
INFO - 2018-07-21 04:58:09 --> Config Class Initialized
INFO - 2018-07-21 04:58:09 --> Loader Class Initialized
DEBUG - 2018-07-21 04:58:09 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-21 04:58:09 --> Helper loaded: url_helper
INFO - 2018-07-21 04:58:09 --> Helper loaded: form_helper
INFO - 2018-07-21 04:58:09 --> Helper loaded: date_helper
INFO - 2018-07-21 04:58:09 --> Helper loaded: util_helper
INFO - 2018-07-21 04:58:09 --> Helper loaded: text_helper
INFO - 2018-07-21 04:58:09 --> Helper loaded: string_helper
INFO - 2018-07-21 04:58:09 --> Database Driver Class Initialized
DEBUG - 2018-07-21 04:58:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-21 04:58:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-21 04:58:09 --> Email Class Initialized
INFO - 2018-07-21 04:58:09 --> Controller Class Initialized
DEBUG - 2018-07-21 04:58:09 --> Users MX_Controller Initialized
DEBUG - 2018-07-21 04:58:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-21 04:58:09 --> Helper loaded: file_helper
DEBUG - 2018-07-21 04:58:09 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-21 04:58:09 --> Login MX_Controller Initialized
INFO - 2018-07-21 04:58:09 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-21 04:58:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-21 04:58:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
DEBUG - 2018-07-21 04:58:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-21 04:58:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-21 04:58:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-21 04:58:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-21 04:58:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-21 04:58:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-21 04:58:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/create_user.php
INFO - 2018-07-21 04:58:09 --> Final output sent to browser
DEBUG - 2018-07-21 04:58:09 --> Total execution time: 0.5371
INFO - 2018-07-21 05:02:44 --> Config Class Initialized
INFO - 2018-07-21 05:02:44 --> Hooks Class Initialized
DEBUG - 2018-07-21 05:02:44 --> UTF-8 Support Enabled
INFO - 2018-07-21 05:02:44 --> Utf8 Class Initialized
INFO - 2018-07-21 05:02:44 --> URI Class Initialized
INFO - 2018-07-21 05:02:44 --> Router Class Initialized
INFO - 2018-07-21 05:02:44 --> Output Class Initialized
INFO - 2018-07-21 05:02:44 --> Security Class Initialized
DEBUG - 2018-07-21 05:02:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 05:02:44 --> Input Class Initialized
INFO - 2018-07-21 05:02:45 --> Language Class Initialized
INFO - 2018-07-21 05:02:45 --> Language Class Initialized
INFO - 2018-07-21 05:02:45 --> Config Class Initialized
INFO - 2018-07-21 05:02:45 --> Loader Class Initialized
DEBUG - 2018-07-21 05:02:45 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-21 05:02:45 --> Helper loaded: url_helper
INFO - 2018-07-21 05:02:45 --> Helper loaded: form_helper
INFO - 2018-07-21 05:02:45 --> Helper loaded: date_helper
INFO - 2018-07-21 05:02:45 --> Helper loaded: util_helper
INFO - 2018-07-21 05:02:45 --> Helper loaded: text_helper
INFO - 2018-07-21 05:02:45 --> Helper loaded: string_helper
INFO - 2018-07-21 05:02:45 --> Database Driver Class Initialized
DEBUG - 2018-07-21 05:02:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-21 05:02:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-21 05:02:45 --> Email Class Initialized
INFO - 2018-07-21 05:02:45 --> Controller Class Initialized
DEBUG - 2018-07-21 05:02:45 --> Users MX_Controller Initialized
DEBUG - 2018-07-21 05:02:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-21 05:02:45 --> Helper loaded: file_helper
DEBUG - 2018-07-21 05:02:45 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-21 05:02:45 --> Login MX_Controller Initialized
INFO - 2018-07-21 05:02:45 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-21 05:02:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-21 05:02:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-21 05:02:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-21 05:02:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-21 05:02:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-21 05:02:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-21 05:02:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/users.php
INFO - 2018-07-21 05:02:45 --> Final output sent to browser
DEBUG - 2018-07-21 05:02:45 --> Total execution time: 0.6652
INFO - 2018-07-21 05:02:46 --> Config Class Initialized
INFO - 2018-07-21 05:02:46 --> Hooks Class Initialized
DEBUG - 2018-07-21 05:02:46 --> UTF-8 Support Enabled
INFO - 2018-07-21 05:02:46 --> Utf8 Class Initialized
INFO - 2018-07-21 05:02:46 --> URI Class Initialized
INFO - 2018-07-21 05:02:46 --> Router Class Initialized
INFO - 2018-07-21 05:02:46 --> Output Class Initialized
INFO - 2018-07-21 05:02:46 --> Security Class Initialized
DEBUG - 2018-07-21 05:02:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 05:02:46 --> Input Class Initialized
INFO - 2018-07-21 05:02:46 --> Language Class Initialized
INFO - 2018-07-21 05:02:46 --> Language Class Initialized
INFO - 2018-07-21 05:02:46 --> Config Class Initialized
INFO - 2018-07-21 05:02:46 --> Loader Class Initialized
DEBUG - 2018-07-21 05:02:46 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-21 05:02:46 --> Helper loaded: url_helper
INFO - 2018-07-21 05:02:46 --> Helper loaded: form_helper
INFO - 2018-07-21 05:02:46 --> Helper loaded: date_helper
INFO - 2018-07-21 05:02:46 --> Helper loaded: util_helper
INFO - 2018-07-21 05:02:46 --> Helper loaded: text_helper
INFO - 2018-07-21 05:02:46 --> Helper loaded: string_helper
INFO - 2018-07-21 05:02:46 --> Database Driver Class Initialized
DEBUG - 2018-07-21 05:02:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-21 05:02:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-21 05:02:46 --> Email Class Initialized
INFO - 2018-07-21 05:02:46 --> Controller Class Initialized
DEBUG - 2018-07-21 05:02:46 --> Users MX_Controller Initialized
DEBUG - 2018-07-21 05:02:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-21 05:02:46 --> Helper loaded: file_helper
DEBUG - 2018-07-21 05:02:46 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-21 05:02:46 --> Login MX_Controller Initialized
INFO - 2018-07-21 05:02:46 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-21 05:02:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-21 05:02:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-07-21 05:02:46 --> Final output sent to browser
DEBUG - 2018-07-21 05:02:46 --> Total execution time: 0.7371
INFO - 2018-07-21 05:04:06 --> Config Class Initialized
INFO - 2018-07-21 05:04:06 --> Hooks Class Initialized
DEBUG - 2018-07-21 05:04:06 --> UTF-8 Support Enabled
INFO - 2018-07-21 05:04:06 --> Utf8 Class Initialized
INFO - 2018-07-21 05:04:06 --> URI Class Initialized
INFO - 2018-07-21 05:04:06 --> Router Class Initialized
INFO - 2018-07-21 05:04:06 --> Output Class Initialized
INFO - 2018-07-21 05:04:06 --> Security Class Initialized
DEBUG - 2018-07-21 05:04:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 05:04:06 --> Input Class Initialized
INFO - 2018-07-21 05:04:06 --> Language Class Initialized
INFO - 2018-07-21 05:04:06 --> Language Class Initialized
INFO - 2018-07-21 05:04:06 --> Config Class Initialized
INFO - 2018-07-21 05:04:06 --> Loader Class Initialized
DEBUG - 2018-07-21 05:04:06 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-21 05:04:06 --> Helper loaded: url_helper
INFO - 2018-07-21 05:04:06 --> Helper loaded: form_helper
INFO - 2018-07-21 05:04:06 --> Helper loaded: date_helper
INFO - 2018-07-21 05:04:06 --> Helper loaded: util_helper
INFO - 2018-07-21 05:04:06 --> Helper loaded: text_helper
INFO - 2018-07-21 05:04:06 --> Helper loaded: string_helper
INFO - 2018-07-21 05:04:06 --> Database Driver Class Initialized
DEBUG - 2018-07-21 05:04:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-21 05:04:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-21 05:04:06 --> Email Class Initialized
INFO - 2018-07-21 05:04:06 --> Controller Class Initialized
DEBUG - 2018-07-21 05:04:06 --> Users MX_Controller Initialized
DEBUG - 2018-07-21 05:04:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-21 05:04:06 --> Helper loaded: file_helper
DEBUG - 2018-07-21 05:04:06 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-21 05:04:06 --> Login MX_Controller Initialized
INFO - 2018-07-21 05:04:06 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-21 05:04:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-21 05:04:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
DEBUG - 2018-07-21 05:04:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-21 05:04:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-21 05:04:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-21 05:04:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-21 05:04:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-21 05:04:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-21 05:04:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/create_user.php
INFO - 2018-07-21 05:04:07 --> Final output sent to browser
DEBUG - 2018-07-21 05:04:07 --> Total execution time: 0.5600
INFO - 2018-07-21 05:06:33 --> Config Class Initialized
INFO - 2018-07-21 05:06:33 --> Hooks Class Initialized
DEBUG - 2018-07-21 05:06:33 --> UTF-8 Support Enabled
INFO - 2018-07-21 05:06:33 --> Utf8 Class Initialized
INFO - 2018-07-21 05:06:33 --> URI Class Initialized
INFO - 2018-07-21 05:06:33 --> Router Class Initialized
INFO - 2018-07-21 05:06:33 --> Output Class Initialized
INFO - 2018-07-21 05:06:33 --> Security Class Initialized
DEBUG - 2018-07-21 05:06:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 05:06:33 --> Input Class Initialized
INFO - 2018-07-21 05:06:33 --> Language Class Initialized
INFO - 2018-07-21 05:06:33 --> Language Class Initialized
INFO - 2018-07-21 05:06:33 --> Config Class Initialized
INFO - 2018-07-21 05:06:34 --> Loader Class Initialized
DEBUG - 2018-07-21 05:06:34 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-21 05:06:34 --> Helper loaded: url_helper
INFO - 2018-07-21 05:06:34 --> Helper loaded: form_helper
INFO - 2018-07-21 05:06:34 --> Helper loaded: date_helper
INFO - 2018-07-21 05:06:34 --> Helper loaded: util_helper
INFO - 2018-07-21 05:06:34 --> Helper loaded: text_helper
INFO - 2018-07-21 05:06:34 --> Helper loaded: string_helper
INFO - 2018-07-21 05:06:34 --> Database Driver Class Initialized
DEBUG - 2018-07-21 05:06:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-21 05:06:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-21 05:06:34 --> Email Class Initialized
INFO - 2018-07-21 05:06:34 --> Controller Class Initialized
DEBUG - 2018-07-21 05:06:34 --> Users MX_Controller Initialized
DEBUG - 2018-07-21 05:06:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-21 05:06:34 --> Helper loaded: file_helper
DEBUG - 2018-07-21 05:06:34 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-21 05:06:34 --> Login MX_Controller Initialized
INFO - 2018-07-21 05:06:34 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-21 05:06:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-21 05:06:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
DEBUG - 2018-07-21 05:06:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-21 05:06:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-21 05:06:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-21 05:06:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-21 05:06:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-21 05:06:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-21 05:06:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/create_user.php
INFO - 2018-07-21 05:06:34 --> Final output sent to browser
DEBUG - 2018-07-21 05:06:34 --> Total execution time: 0.5704
INFO - 2018-07-21 05:10:25 --> Config Class Initialized
INFO - 2018-07-21 05:10:25 --> Hooks Class Initialized
DEBUG - 2018-07-21 05:10:25 --> UTF-8 Support Enabled
INFO - 2018-07-21 05:10:25 --> Utf8 Class Initialized
INFO - 2018-07-21 05:10:25 --> URI Class Initialized
INFO - 2018-07-21 05:10:25 --> Router Class Initialized
INFO - 2018-07-21 05:10:25 --> Output Class Initialized
INFO - 2018-07-21 05:10:25 --> Security Class Initialized
DEBUG - 2018-07-21 05:10:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 05:10:25 --> Input Class Initialized
INFO - 2018-07-21 05:10:25 --> Language Class Initialized
INFO - 2018-07-21 05:10:25 --> Language Class Initialized
INFO - 2018-07-21 05:10:25 --> Config Class Initialized
INFO - 2018-07-21 05:10:25 --> Loader Class Initialized
DEBUG - 2018-07-21 05:10:25 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-21 05:10:25 --> Helper loaded: url_helper
INFO - 2018-07-21 05:10:25 --> Helper loaded: form_helper
INFO - 2018-07-21 05:10:25 --> Helper loaded: date_helper
INFO - 2018-07-21 05:10:25 --> Helper loaded: util_helper
INFO - 2018-07-21 05:10:25 --> Helper loaded: text_helper
INFO - 2018-07-21 05:10:25 --> Helper loaded: string_helper
INFO - 2018-07-21 05:10:25 --> Database Driver Class Initialized
DEBUG - 2018-07-21 05:10:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-21 05:10:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-21 05:10:25 --> Email Class Initialized
INFO - 2018-07-21 05:10:25 --> Controller Class Initialized
DEBUG - 2018-07-21 05:10:26 --> Users MX_Controller Initialized
DEBUG - 2018-07-21 05:10:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-21 05:10:26 --> Helper loaded: file_helper
DEBUG - 2018-07-21 05:10:26 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-21 05:10:26 --> Login MX_Controller Initialized
INFO - 2018-07-21 05:10:26 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-21 05:10:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-21 05:10:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
DEBUG - 2018-07-21 05:10:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-21 05:10:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-21 05:10:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-21 05:10:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-21 05:10:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-21 05:10:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-21 05:10:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/create_user.php
INFO - 2018-07-21 05:10:26 --> Final output sent to browser
DEBUG - 2018-07-21 05:10:26 --> Total execution time: 0.6674
INFO - 2018-07-21 05:11:02 --> Config Class Initialized
INFO - 2018-07-21 05:11:02 --> Hooks Class Initialized
DEBUG - 2018-07-21 05:11:02 --> UTF-8 Support Enabled
INFO - 2018-07-21 05:11:02 --> Utf8 Class Initialized
INFO - 2018-07-21 05:11:02 --> URI Class Initialized
INFO - 2018-07-21 05:11:02 --> Router Class Initialized
INFO - 2018-07-21 05:11:02 --> Output Class Initialized
INFO - 2018-07-21 05:11:02 --> Security Class Initialized
DEBUG - 2018-07-21 05:11:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 05:11:02 --> Input Class Initialized
INFO - 2018-07-21 05:11:02 --> Language Class Initialized
INFO - 2018-07-21 05:11:02 --> Language Class Initialized
INFO - 2018-07-21 05:11:02 --> Config Class Initialized
INFO - 2018-07-21 05:11:02 --> Loader Class Initialized
DEBUG - 2018-07-21 05:11:02 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-21 05:11:02 --> Helper loaded: url_helper
INFO - 2018-07-21 05:11:02 --> Helper loaded: form_helper
INFO - 2018-07-21 05:11:02 --> Helper loaded: date_helper
INFO - 2018-07-21 05:11:02 --> Helper loaded: util_helper
INFO - 2018-07-21 05:11:02 --> Helper loaded: text_helper
INFO - 2018-07-21 05:11:02 --> Helper loaded: string_helper
INFO - 2018-07-21 05:11:02 --> Database Driver Class Initialized
DEBUG - 2018-07-21 05:11:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-21 05:11:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-21 05:11:02 --> Email Class Initialized
INFO - 2018-07-21 05:11:02 --> Controller Class Initialized
DEBUG - 2018-07-21 05:11:02 --> Users MX_Controller Initialized
DEBUG - 2018-07-21 05:11:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-21 05:11:02 --> Helper loaded: file_helper
DEBUG - 2018-07-21 05:11:03 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-21 05:11:03 --> Login MX_Controller Initialized
INFO - 2018-07-21 05:11:03 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-21 05:11:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-21 05:11:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
DEBUG - 2018-07-21 05:11:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-21 05:11:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-21 05:11:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-21 05:11:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-21 05:11:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-21 05:11:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-21 05:11:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/create_user.php
INFO - 2018-07-21 05:11:03 --> Final output sent to browser
DEBUG - 2018-07-21 05:11:03 --> Total execution time: 0.5706
INFO - 2018-07-21 05:11:09 --> Config Class Initialized
INFO - 2018-07-21 05:11:09 --> Hooks Class Initialized
DEBUG - 2018-07-21 05:11:09 --> UTF-8 Support Enabled
INFO - 2018-07-21 05:11:09 --> Utf8 Class Initialized
INFO - 2018-07-21 05:11:09 --> URI Class Initialized
INFO - 2018-07-21 05:11:09 --> Router Class Initialized
INFO - 2018-07-21 05:11:09 --> Output Class Initialized
INFO - 2018-07-21 05:11:09 --> Security Class Initialized
DEBUG - 2018-07-21 05:11:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 05:11:09 --> Input Class Initialized
INFO - 2018-07-21 05:11:09 --> Language Class Initialized
INFO - 2018-07-21 05:11:09 --> Language Class Initialized
INFO - 2018-07-21 05:11:09 --> Config Class Initialized
INFO - 2018-07-21 05:11:09 --> Loader Class Initialized
DEBUG - 2018-07-21 05:11:09 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-21 05:11:09 --> Helper loaded: url_helper
INFO - 2018-07-21 05:11:09 --> Helper loaded: form_helper
INFO - 2018-07-21 05:11:09 --> Helper loaded: date_helper
INFO - 2018-07-21 05:11:09 --> Helper loaded: util_helper
INFO - 2018-07-21 05:11:09 --> Helper loaded: text_helper
INFO - 2018-07-21 05:11:09 --> Helper loaded: string_helper
INFO - 2018-07-21 05:11:09 --> Database Driver Class Initialized
DEBUG - 2018-07-21 05:11:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-21 05:11:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-21 05:11:09 --> Email Class Initialized
INFO - 2018-07-21 05:11:09 --> Controller Class Initialized
DEBUG - 2018-07-21 05:11:09 --> Users MX_Controller Initialized
DEBUG - 2018-07-21 05:11:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-21 05:11:09 --> Helper loaded: file_helper
DEBUG - 2018-07-21 05:11:09 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-21 05:11:09 --> Login MX_Controller Initialized
INFO - 2018-07-21 05:11:09 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-21 05:11:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-21 05:11:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
DEBUG - 2018-07-21 05:11:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-21 05:11:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
INFO - 2018-07-21 05:11:09 --> Upload Class Initialized
INFO - 2018-07-21 05:11:09 --> Language file loaded: language/english/upload_lang.php
DEBUG - 2018-07-21 05:11:09 --> You did not select a file to upload.
INFO - 2018-07-21 05:11:09 --> Config Class Initialized
INFO - 2018-07-21 05:11:09 --> Hooks Class Initialized
DEBUG - 2018-07-21 05:11:09 --> UTF-8 Support Enabled
INFO - 2018-07-21 05:11:09 --> Utf8 Class Initialized
INFO - 2018-07-21 05:11:09 --> URI Class Initialized
INFO - 2018-07-21 05:11:09 --> Router Class Initialized
INFO - 2018-07-21 05:11:09 --> Output Class Initialized
INFO - 2018-07-21 05:11:09 --> Security Class Initialized
DEBUG - 2018-07-21 05:11:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 05:11:09 --> Input Class Initialized
INFO - 2018-07-21 05:11:09 --> Language Class Initialized
INFO - 2018-07-21 05:11:09 --> Language Class Initialized
INFO - 2018-07-21 05:11:09 --> Config Class Initialized
INFO - 2018-07-21 05:11:09 --> Loader Class Initialized
DEBUG - 2018-07-21 05:11:09 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-21 05:11:09 --> Helper loaded: url_helper
INFO - 2018-07-21 05:11:09 --> Helper loaded: form_helper
INFO - 2018-07-21 05:11:09 --> Helper loaded: date_helper
INFO - 2018-07-21 05:11:09 --> Helper loaded: util_helper
INFO - 2018-07-21 05:11:09 --> Helper loaded: text_helper
INFO - 2018-07-21 05:11:09 --> Helper loaded: string_helper
INFO - 2018-07-21 05:11:09 --> Database Driver Class Initialized
DEBUG - 2018-07-21 05:11:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-21 05:11:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-21 05:11:09 --> Email Class Initialized
INFO - 2018-07-21 05:11:09 --> Controller Class Initialized
DEBUG - 2018-07-21 05:11:10 --> Users MX_Controller Initialized
DEBUG - 2018-07-21 05:11:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-21 05:11:10 --> Helper loaded: file_helper
DEBUG - 2018-07-21 05:11:10 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-21 05:11:10 --> Login MX_Controller Initialized
INFO - 2018-07-21 05:11:10 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-21 05:11:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-21 05:11:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
DEBUG - 2018-07-21 05:11:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-21 05:11:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-21 05:11:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-21 05:11:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-21 05:11:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-21 05:11:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-21 05:11:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/create_user.php
INFO - 2018-07-21 05:11:10 --> Final output sent to browser
DEBUG - 2018-07-21 05:11:10 --> Total execution time: 0.5791
INFO - 2018-07-21 05:12:35 --> Config Class Initialized
INFO - 2018-07-21 05:12:36 --> Hooks Class Initialized
DEBUG - 2018-07-21 05:12:36 --> UTF-8 Support Enabled
INFO - 2018-07-21 05:12:36 --> Utf8 Class Initialized
INFO - 2018-07-21 05:12:36 --> URI Class Initialized
INFO - 2018-07-21 05:12:36 --> Router Class Initialized
INFO - 2018-07-21 05:12:36 --> Output Class Initialized
INFO - 2018-07-21 05:12:36 --> Security Class Initialized
DEBUG - 2018-07-21 05:12:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 05:12:36 --> Input Class Initialized
INFO - 2018-07-21 05:12:36 --> Language Class Initialized
INFO - 2018-07-21 05:12:36 --> Language Class Initialized
INFO - 2018-07-21 05:12:36 --> Config Class Initialized
INFO - 2018-07-21 05:12:36 --> Loader Class Initialized
DEBUG - 2018-07-21 05:12:36 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-21 05:12:36 --> Helper loaded: url_helper
INFO - 2018-07-21 05:12:36 --> Helper loaded: form_helper
INFO - 2018-07-21 05:12:36 --> Helper loaded: date_helper
INFO - 2018-07-21 05:12:36 --> Helper loaded: util_helper
INFO - 2018-07-21 05:12:36 --> Helper loaded: text_helper
INFO - 2018-07-21 05:12:36 --> Helper loaded: string_helper
INFO - 2018-07-21 05:12:36 --> Database Driver Class Initialized
DEBUG - 2018-07-21 05:12:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-21 05:12:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-21 05:12:36 --> Email Class Initialized
INFO - 2018-07-21 05:12:36 --> Controller Class Initialized
DEBUG - 2018-07-21 05:12:36 --> Users MX_Controller Initialized
DEBUG - 2018-07-21 05:12:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-21 05:12:36 --> Helper loaded: file_helper
DEBUG - 2018-07-21 05:12:36 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-21 05:12:36 --> Login MX_Controller Initialized
INFO - 2018-07-21 05:12:36 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-21 05:12:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-21 05:12:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
DEBUG - 2018-07-21 05:12:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-21 05:12:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-21 05:12:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-21 05:12:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-21 05:12:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-21 05:12:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-21 05:12:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/create_user.php
INFO - 2018-07-21 05:12:36 --> Final output sent to browser
DEBUG - 2018-07-21 05:12:36 --> Total execution time: 0.5722
INFO - 2018-07-21 05:12:52 --> Config Class Initialized
INFO - 2018-07-21 05:12:52 --> Hooks Class Initialized
DEBUG - 2018-07-21 05:12:52 --> UTF-8 Support Enabled
INFO - 2018-07-21 05:12:52 --> Utf8 Class Initialized
INFO - 2018-07-21 05:12:52 --> URI Class Initialized
INFO - 2018-07-21 05:12:52 --> Router Class Initialized
INFO - 2018-07-21 05:12:52 --> Output Class Initialized
INFO - 2018-07-21 05:12:52 --> Security Class Initialized
DEBUG - 2018-07-21 05:12:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 05:12:52 --> Input Class Initialized
INFO - 2018-07-21 05:12:52 --> Language Class Initialized
INFO - 2018-07-21 05:12:52 --> Language Class Initialized
INFO - 2018-07-21 05:12:52 --> Config Class Initialized
INFO - 2018-07-21 05:12:52 --> Loader Class Initialized
DEBUG - 2018-07-21 05:12:52 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-21 05:12:52 --> Helper loaded: url_helper
INFO - 2018-07-21 05:12:52 --> Helper loaded: form_helper
INFO - 2018-07-21 05:12:52 --> Helper loaded: date_helper
INFO - 2018-07-21 05:12:52 --> Helper loaded: util_helper
INFO - 2018-07-21 05:12:52 --> Helper loaded: text_helper
INFO - 2018-07-21 05:12:52 --> Helper loaded: string_helper
INFO - 2018-07-21 05:12:52 --> Database Driver Class Initialized
DEBUG - 2018-07-21 05:12:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-21 05:12:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-21 05:12:52 --> Email Class Initialized
INFO - 2018-07-21 05:12:52 --> Controller Class Initialized
DEBUG - 2018-07-21 05:12:52 --> Users MX_Controller Initialized
DEBUG - 2018-07-21 05:12:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-21 05:12:52 --> Helper loaded: file_helper
DEBUG - 2018-07-21 05:12:52 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-21 05:12:52 --> Login MX_Controller Initialized
INFO - 2018-07-21 05:12:52 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-21 05:12:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-21 05:12:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
DEBUG - 2018-07-21 05:12:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-21 05:12:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-21 05:12:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-21 05:12:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-21 05:12:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-21 05:12:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-21 05:12:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/create_user.php
INFO - 2018-07-21 05:12:52 --> Final output sent to browser
DEBUG - 2018-07-21 05:12:52 --> Total execution time: 0.5754
INFO - 2018-07-21 05:12:57 --> Config Class Initialized
INFO - 2018-07-21 05:12:57 --> Hooks Class Initialized
DEBUG - 2018-07-21 05:12:57 --> UTF-8 Support Enabled
INFO - 2018-07-21 05:12:58 --> Utf8 Class Initialized
INFO - 2018-07-21 05:12:58 --> URI Class Initialized
INFO - 2018-07-21 05:12:58 --> Router Class Initialized
INFO - 2018-07-21 05:12:58 --> Output Class Initialized
INFO - 2018-07-21 05:12:58 --> Security Class Initialized
DEBUG - 2018-07-21 05:12:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 05:12:58 --> Input Class Initialized
INFO - 2018-07-21 05:12:58 --> Language Class Initialized
INFO - 2018-07-21 05:12:58 --> Language Class Initialized
INFO - 2018-07-21 05:12:58 --> Config Class Initialized
INFO - 2018-07-21 05:12:58 --> Loader Class Initialized
DEBUG - 2018-07-21 05:12:58 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-21 05:12:58 --> Helper loaded: url_helper
INFO - 2018-07-21 05:12:58 --> Helper loaded: form_helper
INFO - 2018-07-21 05:12:58 --> Helper loaded: date_helper
INFO - 2018-07-21 05:12:58 --> Helper loaded: util_helper
INFO - 2018-07-21 05:12:58 --> Helper loaded: text_helper
INFO - 2018-07-21 05:12:58 --> Helper loaded: string_helper
INFO - 2018-07-21 05:12:58 --> Database Driver Class Initialized
DEBUG - 2018-07-21 05:12:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-21 05:12:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-21 05:12:58 --> Email Class Initialized
INFO - 2018-07-21 05:12:58 --> Controller Class Initialized
DEBUG - 2018-07-21 05:12:58 --> Users MX_Controller Initialized
DEBUG - 2018-07-21 05:12:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-21 05:12:58 --> Helper loaded: file_helper
DEBUG - 2018-07-21 05:12:58 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-21 05:12:58 --> Login MX_Controller Initialized
INFO - 2018-07-21 05:12:58 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-21 05:12:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-21 05:12:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
DEBUG - 2018-07-21 05:12:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-21 05:12:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-21 05:12:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-21 05:12:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-21 05:12:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-21 05:12:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-21 05:12:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/create_user.php
INFO - 2018-07-21 05:12:58 --> Final output sent to browser
DEBUG - 2018-07-21 05:12:58 --> Total execution time: 0.5718
INFO - 2018-07-21 05:15:50 --> Config Class Initialized
INFO - 2018-07-21 05:15:50 --> Hooks Class Initialized
DEBUG - 2018-07-21 05:15:50 --> UTF-8 Support Enabled
INFO - 2018-07-21 05:15:50 --> Utf8 Class Initialized
INFO - 2018-07-21 05:15:50 --> URI Class Initialized
INFO - 2018-07-21 05:15:50 --> Router Class Initialized
INFO - 2018-07-21 05:15:50 --> Output Class Initialized
INFO - 2018-07-21 05:15:50 --> Security Class Initialized
DEBUG - 2018-07-21 05:15:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 05:15:50 --> Input Class Initialized
INFO - 2018-07-21 05:15:50 --> Language Class Initialized
INFO - 2018-07-21 05:15:50 --> Language Class Initialized
INFO - 2018-07-21 05:15:50 --> Config Class Initialized
INFO - 2018-07-21 05:15:50 --> Loader Class Initialized
DEBUG - 2018-07-21 05:15:50 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-21 05:15:50 --> Helper loaded: url_helper
INFO - 2018-07-21 05:15:50 --> Helper loaded: form_helper
INFO - 2018-07-21 05:15:50 --> Helper loaded: date_helper
INFO - 2018-07-21 05:15:50 --> Helper loaded: util_helper
INFO - 2018-07-21 05:15:50 --> Helper loaded: text_helper
INFO - 2018-07-21 05:15:50 --> Helper loaded: string_helper
INFO - 2018-07-21 05:15:50 --> Database Driver Class Initialized
DEBUG - 2018-07-21 05:15:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-21 05:15:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-21 05:15:50 --> Email Class Initialized
INFO - 2018-07-21 05:15:50 --> Controller Class Initialized
DEBUG - 2018-07-21 05:15:50 --> Users MX_Controller Initialized
DEBUG - 2018-07-21 05:15:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-21 05:15:50 --> Helper loaded: file_helper
DEBUG - 2018-07-21 05:15:50 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-21 05:15:50 --> Login MX_Controller Initialized
INFO - 2018-07-21 05:15:50 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-21 05:15:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-21 05:15:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
DEBUG - 2018-07-21 05:15:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-21 05:15:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-21 05:15:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-21 05:15:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-21 05:15:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-21 05:15:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-21 05:15:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/create_user.php
INFO - 2018-07-21 05:15:50 --> Final output sent to browser
DEBUG - 2018-07-21 05:15:50 --> Total execution time: 0.5812
INFO - 2018-07-21 05:16:10 --> Config Class Initialized
INFO - 2018-07-21 05:16:10 --> Hooks Class Initialized
DEBUG - 2018-07-21 05:16:10 --> UTF-8 Support Enabled
INFO - 2018-07-21 05:16:10 --> Utf8 Class Initialized
INFO - 2018-07-21 05:16:10 --> URI Class Initialized
INFO - 2018-07-21 05:16:10 --> Router Class Initialized
INFO - 2018-07-21 05:16:10 --> Output Class Initialized
INFO - 2018-07-21 05:16:10 --> Security Class Initialized
DEBUG - 2018-07-21 05:16:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 05:16:10 --> Input Class Initialized
INFO - 2018-07-21 05:16:10 --> Language Class Initialized
INFO - 2018-07-21 05:16:10 --> Language Class Initialized
INFO - 2018-07-21 05:16:10 --> Config Class Initialized
INFO - 2018-07-21 05:16:10 --> Loader Class Initialized
DEBUG - 2018-07-21 05:16:10 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-21 05:16:10 --> Helper loaded: url_helper
INFO - 2018-07-21 05:16:10 --> Helper loaded: form_helper
INFO - 2018-07-21 05:16:10 --> Helper loaded: date_helper
INFO - 2018-07-21 05:16:10 --> Helper loaded: util_helper
INFO - 2018-07-21 05:16:10 --> Helper loaded: text_helper
INFO - 2018-07-21 05:16:10 --> Helper loaded: string_helper
INFO - 2018-07-21 05:16:10 --> Database Driver Class Initialized
DEBUG - 2018-07-21 05:16:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-21 05:16:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-21 05:16:10 --> Email Class Initialized
INFO - 2018-07-21 05:16:10 --> Controller Class Initialized
DEBUG - 2018-07-21 05:16:10 --> Users MX_Controller Initialized
DEBUG - 2018-07-21 05:16:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-21 05:16:10 --> Helper loaded: file_helper
DEBUG - 2018-07-21 05:16:10 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-21 05:16:10 --> Login MX_Controller Initialized
INFO - 2018-07-21 05:16:10 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-21 05:16:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-21 05:16:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
DEBUG - 2018-07-21 05:16:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-21 05:16:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-21 05:16:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-21 05:16:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-21 05:16:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-21 05:16:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-21 05:16:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/create_user.php
INFO - 2018-07-21 05:16:10 --> Final output sent to browser
DEBUG - 2018-07-21 05:16:10 --> Total execution time: 0.5858
INFO - 2018-07-21 05:30:40 --> Config Class Initialized
INFO - 2018-07-21 05:30:40 --> Hooks Class Initialized
DEBUG - 2018-07-21 05:30:40 --> UTF-8 Support Enabled
INFO - 2018-07-21 05:30:40 --> Utf8 Class Initialized
INFO - 2018-07-21 05:30:40 --> URI Class Initialized
INFO - 2018-07-21 05:30:40 --> Router Class Initialized
INFO - 2018-07-21 05:30:40 --> Output Class Initialized
INFO - 2018-07-21 05:30:40 --> Security Class Initialized
DEBUG - 2018-07-21 05:30:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 05:30:40 --> Input Class Initialized
INFO - 2018-07-21 05:30:40 --> Language Class Initialized
INFO - 2018-07-21 05:30:40 --> Language Class Initialized
INFO - 2018-07-21 05:30:40 --> Config Class Initialized
INFO - 2018-07-21 05:30:40 --> Loader Class Initialized
DEBUG - 2018-07-21 05:30:40 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-21 05:30:40 --> Helper loaded: url_helper
INFO - 2018-07-21 05:30:40 --> Helper loaded: form_helper
INFO - 2018-07-21 05:30:40 --> Helper loaded: date_helper
INFO - 2018-07-21 05:30:40 --> Helper loaded: util_helper
INFO - 2018-07-21 05:30:40 --> Helper loaded: text_helper
INFO - 2018-07-21 05:30:40 --> Helper loaded: string_helper
INFO - 2018-07-21 05:30:40 --> Database Driver Class Initialized
DEBUG - 2018-07-21 05:30:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-21 05:30:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-21 05:30:40 --> Email Class Initialized
INFO - 2018-07-21 05:30:40 --> Controller Class Initialized
DEBUG - 2018-07-21 05:30:40 --> Users MX_Controller Initialized
DEBUG - 2018-07-21 05:30:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-21 05:30:40 --> Helper loaded: file_helper
DEBUG - 2018-07-21 05:30:40 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-21 05:30:40 --> Login MX_Controller Initialized
INFO - 2018-07-21 05:30:40 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-21 05:30:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-21 05:30:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
DEBUG - 2018-07-21 05:30:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-21 05:30:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-21 05:30:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-21 05:30:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-21 05:30:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-21 05:30:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-21 05:30:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/create_user.php
INFO - 2018-07-21 05:30:40 --> Final output sent to browser
DEBUG - 2018-07-21 05:30:41 --> Total execution time: 0.5772
INFO - 2018-07-21 05:32:48 --> Config Class Initialized
INFO - 2018-07-21 05:32:48 --> Hooks Class Initialized
DEBUG - 2018-07-21 05:32:48 --> UTF-8 Support Enabled
INFO - 2018-07-21 05:32:48 --> Utf8 Class Initialized
INFO - 2018-07-21 05:32:48 --> URI Class Initialized
INFO - 2018-07-21 05:32:48 --> Router Class Initialized
INFO - 2018-07-21 05:32:48 --> Output Class Initialized
INFO - 2018-07-21 05:32:48 --> Security Class Initialized
DEBUG - 2018-07-21 05:32:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 05:32:48 --> Input Class Initialized
INFO - 2018-07-21 05:32:48 --> Language Class Initialized
INFO - 2018-07-21 05:32:48 --> Language Class Initialized
INFO - 2018-07-21 05:32:48 --> Config Class Initialized
INFO - 2018-07-21 05:32:48 --> Loader Class Initialized
DEBUG - 2018-07-21 05:32:48 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-21 05:32:48 --> Helper loaded: url_helper
INFO - 2018-07-21 05:32:48 --> Helper loaded: form_helper
INFO - 2018-07-21 05:32:48 --> Helper loaded: date_helper
INFO - 2018-07-21 05:32:48 --> Helper loaded: util_helper
INFO - 2018-07-21 05:32:48 --> Helper loaded: text_helper
INFO - 2018-07-21 05:32:48 --> Helper loaded: string_helper
INFO - 2018-07-21 05:32:48 --> Database Driver Class Initialized
DEBUG - 2018-07-21 05:32:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-21 05:32:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-21 05:32:48 --> Email Class Initialized
INFO - 2018-07-21 05:32:48 --> Controller Class Initialized
DEBUG - 2018-07-21 05:32:48 --> Users MX_Controller Initialized
DEBUG - 2018-07-21 05:32:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-21 05:32:48 --> Helper loaded: file_helper
DEBUG - 2018-07-21 05:32:48 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-21 05:32:48 --> Login MX_Controller Initialized
INFO - 2018-07-21 05:32:48 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-21 05:32:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-21 05:32:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
DEBUG - 2018-07-21 05:32:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-21 05:32:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-21 05:32:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-21 05:32:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-21 05:32:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-21 05:32:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-21 05:32:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/create_user.php
INFO - 2018-07-21 05:32:48 --> Final output sent to browser
DEBUG - 2018-07-21 05:32:48 --> Total execution time: 0.5999
INFO - 2018-07-21 05:33:01 --> Config Class Initialized
INFO - 2018-07-21 05:33:01 --> Hooks Class Initialized
DEBUG - 2018-07-21 05:33:01 --> UTF-8 Support Enabled
INFO - 2018-07-21 05:33:02 --> Utf8 Class Initialized
INFO - 2018-07-21 05:33:02 --> URI Class Initialized
INFO - 2018-07-21 05:33:02 --> Router Class Initialized
INFO - 2018-07-21 05:33:02 --> Output Class Initialized
INFO - 2018-07-21 05:33:02 --> Security Class Initialized
DEBUG - 2018-07-21 05:33:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 05:33:02 --> Input Class Initialized
INFO - 2018-07-21 05:33:02 --> Language Class Initialized
INFO - 2018-07-21 05:33:02 --> Language Class Initialized
INFO - 2018-07-21 05:33:02 --> Config Class Initialized
INFO - 2018-07-21 05:33:02 --> Loader Class Initialized
DEBUG - 2018-07-21 05:33:02 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-21 05:33:02 --> Helper loaded: url_helper
INFO - 2018-07-21 05:33:02 --> Helper loaded: form_helper
INFO - 2018-07-21 05:33:02 --> Helper loaded: date_helper
INFO - 2018-07-21 05:33:02 --> Helper loaded: util_helper
INFO - 2018-07-21 05:33:02 --> Helper loaded: text_helper
INFO - 2018-07-21 05:33:02 --> Helper loaded: string_helper
INFO - 2018-07-21 05:33:02 --> Database Driver Class Initialized
DEBUG - 2018-07-21 05:33:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-21 05:33:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-21 05:33:02 --> Email Class Initialized
INFO - 2018-07-21 05:33:02 --> Controller Class Initialized
DEBUG - 2018-07-21 05:33:02 --> Users MX_Controller Initialized
DEBUG - 2018-07-21 05:33:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-21 05:33:02 --> Helper loaded: file_helper
DEBUG - 2018-07-21 05:33:02 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-21 05:33:02 --> Login MX_Controller Initialized
INFO - 2018-07-21 05:33:02 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-21 05:33:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-21 05:33:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
DEBUG - 2018-07-21 05:33:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-21 05:33:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-21 05:33:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-21 05:33:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-21 05:33:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-21 05:33:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-21 05:33:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/create_user.php
INFO - 2018-07-21 05:33:02 --> Final output sent to browser
DEBUG - 2018-07-21 05:33:02 --> Total execution time: 0.5783
INFO - 2018-07-21 05:33:05 --> Config Class Initialized
INFO - 2018-07-21 05:33:05 --> Hooks Class Initialized
DEBUG - 2018-07-21 05:33:05 --> UTF-8 Support Enabled
INFO - 2018-07-21 05:33:05 --> Utf8 Class Initialized
INFO - 2018-07-21 05:33:05 --> URI Class Initialized
INFO - 2018-07-21 05:33:05 --> Router Class Initialized
INFO - 2018-07-21 05:33:05 --> Output Class Initialized
INFO - 2018-07-21 05:33:05 --> Security Class Initialized
DEBUG - 2018-07-21 05:33:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 05:33:05 --> Input Class Initialized
INFO - 2018-07-21 05:33:05 --> Language Class Initialized
INFO - 2018-07-21 05:33:05 --> Language Class Initialized
INFO - 2018-07-21 05:33:05 --> Config Class Initialized
INFO - 2018-07-21 05:33:05 --> Loader Class Initialized
DEBUG - 2018-07-21 05:33:05 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-21 05:33:05 --> Helper loaded: url_helper
INFO - 2018-07-21 05:33:05 --> Helper loaded: form_helper
INFO - 2018-07-21 05:33:05 --> Helper loaded: date_helper
INFO - 2018-07-21 05:33:05 --> Helper loaded: util_helper
INFO - 2018-07-21 05:33:05 --> Helper loaded: text_helper
INFO - 2018-07-21 05:33:05 --> Helper loaded: string_helper
INFO - 2018-07-21 05:33:05 --> Database Driver Class Initialized
DEBUG - 2018-07-21 05:33:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-21 05:33:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-21 05:33:05 --> Email Class Initialized
INFO - 2018-07-21 05:33:05 --> Controller Class Initialized
DEBUG - 2018-07-21 05:33:05 --> Users MX_Controller Initialized
DEBUG - 2018-07-21 05:33:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-21 05:33:05 --> Helper loaded: file_helper
DEBUG - 2018-07-21 05:33:05 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-21 05:33:05 --> Login MX_Controller Initialized
INFO - 2018-07-21 05:33:05 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-21 05:33:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-21 05:33:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
DEBUG - 2018-07-21 05:33:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-21 05:33:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-21 05:33:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-21 05:33:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-21 05:33:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-21 05:33:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-21 05:33:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/create_user.php
INFO - 2018-07-21 05:33:05 --> Final output sent to browser
DEBUG - 2018-07-21 05:33:05 --> Total execution time: 0.7151
INFO - 2018-07-21 05:38:47 --> Config Class Initialized
INFO - 2018-07-21 05:38:47 --> Hooks Class Initialized
DEBUG - 2018-07-21 05:38:47 --> UTF-8 Support Enabled
INFO - 2018-07-21 05:38:47 --> Utf8 Class Initialized
INFO - 2018-07-21 05:38:47 --> URI Class Initialized
INFO - 2018-07-21 05:38:47 --> Router Class Initialized
INFO - 2018-07-21 05:38:47 --> Output Class Initialized
INFO - 2018-07-21 05:38:47 --> Security Class Initialized
DEBUG - 2018-07-21 05:38:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 05:38:47 --> Input Class Initialized
INFO - 2018-07-21 05:38:47 --> Language Class Initialized
INFO - 2018-07-21 05:38:47 --> Language Class Initialized
INFO - 2018-07-21 05:38:47 --> Config Class Initialized
INFO - 2018-07-21 05:38:47 --> Loader Class Initialized
DEBUG - 2018-07-21 05:38:47 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-21 05:38:47 --> Helper loaded: url_helper
INFO - 2018-07-21 05:38:47 --> Helper loaded: form_helper
INFO - 2018-07-21 05:38:47 --> Helper loaded: date_helper
INFO - 2018-07-21 05:38:47 --> Helper loaded: util_helper
INFO - 2018-07-21 05:38:47 --> Helper loaded: text_helper
INFO - 2018-07-21 05:38:47 --> Helper loaded: string_helper
INFO - 2018-07-21 05:38:47 --> Database Driver Class Initialized
DEBUG - 2018-07-21 05:38:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-21 05:38:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-21 05:38:48 --> Email Class Initialized
INFO - 2018-07-21 05:38:48 --> Controller Class Initialized
DEBUG - 2018-07-21 05:38:48 --> Users MX_Controller Initialized
DEBUG - 2018-07-21 05:38:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-21 05:38:48 --> Helper loaded: file_helper
DEBUG - 2018-07-21 05:38:48 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-21 05:38:48 --> Login MX_Controller Initialized
INFO - 2018-07-21 05:38:48 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-21 05:38:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-21 05:38:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
DEBUG - 2018-07-21 05:38:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-21 05:38:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-21 05:38:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-21 05:38:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-21 05:38:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-21 05:38:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-21 05:38:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/create_user.php
INFO - 2018-07-21 05:38:48 --> Final output sent to browser
DEBUG - 2018-07-21 05:38:48 --> Total execution time: 0.6216
INFO - 2018-07-21 05:39:13 --> Config Class Initialized
INFO - 2018-07-21 05:39:13 --> Hooks Class Initialized
DEBUG - 2018-07-21 05:39:13 --> UTF-8 Support Enabled
INFO - 2018-07-21 05:39:13 --> Utf8 Class Initialized
INFO - 2018-07-21 05:39:13 --> URI Class Initialized
INFO - 2018-07-21 05:39:13 --> Router Class Initialized
INFO - 2018-07-21 05:39:13 --> Output Class Initialized
INFO - 2018-07-21 05:39:13 --> Security Class Initialized
DEBUG - 2018-07-21 05:39:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 05:39:13 --> Input Class Initialized
INFO - 2018-07-21 05:39:13 --> Language Class Initialized
INFO - 2018-07-21 05:39:13 --> Language Class Initialized
INFO - 2018-07-21 05:39:13 --> Config Class Initialized
INFO - 2018-07-21 05:39:13 --> Loader Class Initialized
DEBUG - 2018-07-21 05:39:13 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-21 05:39:13 --> Helper loaded: url_helper
INFO - 2018-07-21 05:39:13 --> Helper loaded: form_helper
INFO - 2018-07-21 05:39:13 --> Helper loaded: date_helper
INFO - 2018-07-21 05:39:13 --> Helper loaded: util_helper
INFO - 2018-07-21 05:39:13 --> Helper loaded: text_helper
INFO - 2018-07-21 05:39:13 --> Helper loaded: string_helper
INFO - 2018-07-21 05:39:13 --> Database Driver Class Initialized
DEBUG - 2018-07-21 05:39:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-21 05:39:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-21 05:39:13 --> Email Class Initialized
INFO - 2018-07-21 05:39:13 --> Controller Class Initialized
DEBUG - 2018-07-21 05:39:13 --> Users MX_Controller Initialized
DEBUG - 2018-07-21 05:39:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-21 05:39:13 --> Helper loaded: file_helper
DEBUG - 2018-07-21 05:39:13 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-21 05:39:13 --> Login MX_Controller Initialized
INFO - 2018-07-21 05:39:13 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-21 05:39:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-21 05:39:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
DEBUG - 2018-07-21 05:39:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-21 05:39:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-21 05:39:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-21 05:39:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-21 05:39:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-21 05:39:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-21 05:39:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/create_user.php
INFO - 2018-07-21 05:39:13 --> Final output sent to browser
DEBUG - 2018-07-21 05:39:13 --> Total execution time: 0.5888
INFO - 2018-07-21 05:39:19 --> Config Class Initialized
INFO - 2018-07-21 05:39:19 --> Hooks Class Initialized
DEBUG - 2018-07-21 05:39:19 --> UTF-8 Support Enabled
INFO - 2018-07-21 05:39:19 --> Utf8 Class Initialized
INFO - 2018-07-21 05:39:19 --> URI Class Initialized
INFO - 2018-07-21 05:39:20 --> Router Class Initialized
INFO - 2018-07-21 05:39:20 --> Output Class Initialized
INFO - 2018-07-21 05:39:20 --> Security Class Initialized
DEBUG - 2018-07-21 05:39:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 05:39:20 --> Input Class Initialized
INFO - 2018-07-21 05:39:20 --> Language Class Initialized
INFO - 2018-07-21 05:39:20 --> Language Class Initialized
INFO - 2018-07-21 05:39:20 --> Config Class Initialized
INFO - 2018-07-21 05:39:20 --> Loader Class Initialized
DEBUG - 2018-07-21 05:39:20 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-21 05:39:20 --> Helper loaded: url_helper
INFO - 2018-07-21 05:39:20 --> Helper loaded: form_helper
INFO - 2018-07-21 05:39:20 --> Helper loaded: date_helper
INFO - 2018-07-21 05:39:20 --> Helper loaded: util_helper
INFO - 2018-07-21 05:39:20 --> Helper loaded: text_helper
INFO - 2018-07-21 05:39:20 --> Helper loaded: string_helper
INFO - 2018-07-21 05:39:20 --> Database Driver Class Initialized
DEBUG - 2018-07-21 05:39:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-21 05:39:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-21 05:39:20 --> Email Class Initialized
INFO - 2018-07-21 05:39:20 --> Controller Class Initialized
DEBUG - 2018-07-21 05:39:20 --> Users MX_Controller Initialized
DEBUG - 2018-07-21 05:39:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-21 05:39:20 --> Helper loaded: file_helper
DEBUG - 2018-07-21 05:39:20 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-21 05:39:20 --> Login MX_Controller Initialized
INFO - 2018-07-21 05:39:20 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-21 05:39:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-21 05:39:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
DEBUG - 2018-07-21 05:39:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-21 05:39:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-21 05:39:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-21 05:39:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-21 05:39:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-21 05:39:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-21 05:39:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/create_user.php
INFO - 2018-07-21 05:39:20 --> Final output sent to browser
DEBUG - 2018-07-21 05:39:20 --> Total execution time: 0.5982
INFO - 2018-07-21 05:39:35 --> Config Class Initialized
INFO - 2018-07-21 05:39:35 --> Hooks Class Initialized
DEBUG - 2018-07-21 05:39:35 --> UTF-8 Support Enabled
INFO - 2018-07-21 05:39:35 --> Utf8 Class Initialized
INFO - 2018-07-21 05:39:35 --> URI Class Initialized
INFO - 2018-07-21 05:39:35 --> Router Class Initialized
INFO - 2018-07-21 05:39:35 --> Output Class Initialized
INFO - 2018-07-21 05:39:35 --> Security Class Initialized
DEBUG - 2018-07-21 05:39:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 05:39:35 --> Input Class Initialized
INFO - 2018-07-21 05:39:35 --> Language Class Initialized
INFO - 2018-07-21 05:39:35 --> Language Class Initialized
INFO - 2018-07-21 05:39:35 --> Config Class Initialized
INFO - 2018-07-21 05:39:35 --> Loader Class Initialized
DEBUG - 2018-07-21 05:39:35 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-21 05:39:35 --> Helper loaded: url_helper
INFO - 2018-07-21 05:39:35 --> Helper loaded: form_helper
INFO - 2018-07-21 05:39:35 --> Helper loaded: date_helper
INFO - 2018-07-21 05:39:35 --> Helper loaded: util_helper
INFO - 2018-07-21 05:39:35 --> Helper loaded: text_helper
INFO - 2018-07-21 05:39:35 --> Helper loaded: string_helper
INFO - 2018-07-21 05:39:36 --> Database Driver Class Initialized
DEBUG - 2018-07-21 05:39:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-21 05:39:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-21 05:39:36 --> Email Class Initialized
INFO - 2018-07-21 05:39:36 --> Controller Class Initialized
DEBUG - 2018-07-21 05:39:36 --> Users MX_Controller Initialized
DEBUG - 2018-07-21 05:39:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-21 05:39:36 --> Helper loaded: file_helper
DEBUG - 2018-07-21 05:39:36 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-21 05:39:36 --> Login MX_Controller Initialized
INFO - 2018-07-21 05:39:36 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-21 05:39:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-21 05:39:36 --> Final output sent to browser
DEBUG - 2018-07-21 05:39:36 --> Total execution time: 0.6153
INFO - 2018-07-21 05:39:40 --> Config Class Initialized
INFO - 2018-07-21 05:39:40 --> Hooks Class Initialized
DEBUG - 2018-07-21 05:39:40 --> UTF-8 Support Enabled
INFO - 2018-07-21 05:39:40 --> Utf8 Class Initialized
INFO - 2018-07-21 05:39:40 --> URI Class Initialized
INFO - 2018-07-21 05:39:40 --> Router Class Initialized
INFO - 2018-07-21 05:39:40 --> Output Class Initialized
INFO - 2018-07-21 05:39:40 --> Security Class Initialized
DEBUG - 2018-07-21 05:39:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 05:39:40 --> Input Class Initialized
INFO - 2018-07-21 05:39:40 --> Language Class Initialized
INFO - 2018-07-21 05:39:40 --> Language Class Initialized
INFO - 2018-07-21 05:39:40 --> Config Class Initialized
INFO - 2018-07-21 05:39:40 --> Loader Class Initialized
DEBUG - 2018-07-21 05:39:40 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-21 05:39:40 --> Helper loaded: url_helper
INFO - 2018-07-21 05:39:40 --> Helper loaded: form_helper
INFO - 2018-07-21 05:39:40 --> Helper loaded: date_helper
INFO - 2018-07-21 05:39:40 --> Helper loaded: util_helper
INFO - 2018-07-21 05:39:40 --> Helper loaded: text_helper
INFO - 2018-07-21 05:39:40 --> Helper loaded: string_helper
INFO - 2018-07-21 05:39:40 --> Database Driver Class Initialized
DEBUG - 2018-07-21 05:39:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-21 05:39:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-21 05:39:40 --> Email Class Initialized
INFO - 2018-07-21 05:39:40 --> Controller Class Initialized
DEBUG - 2018-07-21 05:39:40 --> Users MX_Controller Initialized
DEBUG - 2018-07-21 05:39:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-21 05:39:40 --> Helper loaded: file_helper
DEBUG - 2018-07-21 05:39:40 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-21 05:39:40 --> Login MX_Controller Initialized
INFO - 2018-07-21 05:39:40 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-21 05:39:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-21 05:39:40 --> Final output sent to browser
DEBUG - 2018-07-21 05:39:40 --> Total execution time: 0.7207
INFO - 2018-07-21 05:39:44 --> Config Class Initialized
INFO - 2018-07-21 05:39:44 --> Hooks Class Initialized
DEBUG - 2018-07-21 05:39:44 --> UTF-8 Support Enabled
INFO - 2018-07-21 05:39:44 --> Utf8 Class Initialized
INFO - 2018-07-21 05:39:44 --> URI Class Initialized
INFO - 2018-07-21 05:39:44 --> Router Class Initialized
INFO - 2018-07-21 05:39:44 --> Output Class Initialized
INFO - 2018-07-21 05:39:44 --> Security Class Initialized
DEBUG - 2018-07-21 05:39:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 05:39:44 --> Input Class Initialized
INFO - 2018-07-21 05:39:44 --> Language Class Initialized
INFO - 2018-07-21 05:39:44 --> Language Class Initialized
INFO - 2018-07-21 05:39:44 --> Config Class Initialized
INFO - 2018-07-21 05:39:44 --> Loader Class Initialized
DEBUG - 2018-07-21 05:39:44 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-21 05:39:44 --> Helper loaded: url_helper
INFO - 2018-07-21 05:39:44 --> Helper loaded: form_helper
INFO - 2018-07-21 05:39:44 --> Helper loaded: date_helper
INFO - 2018-07-21 05:39:44 --> Helper loaded: util_helper
INFO - 2018-07-21 05:39:44 --> Helper loaded: text_helper
INFO - 2018-07-21 05:39:44 --> Helper loaded: string_helper
INFO - 2018-07-21 05:39:44 --> Database Driver Class Initialized
DEBUG - 2018-07-21 05:39:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-21 05:39:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-21 05:39:44 --> Email Class Initialized
INFO - 2018-07-21 05:39:44 --> Controller Class Initialized
DEBUG - 2018-07-21 05:39:44 --> Users MX_Controller Initialized
DEBUG - 2018-07-21 05:39:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-21 05:39:44 --> Helper loaded: file_helper
DEBUG - 2018-07-21 05:39:44 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-21 05:39:44 --> Login MX_Controller Initialized
INFO - 2018-07-21 05:39:44 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-21 05:39:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-21 05:39:44 --> Final output sent to browser
DEBUG - 2018-07-21 05:39:44 --> Total execution time: 0.6456
INFO - 2018-07-21 05:39:46 --> Config Class Initialized
INFO - 2018-07-21 05:39:46 --> Hooks Class Initialized
DEBUG - 2018-07-21 05:39:46 --> UTF-8 Support Enabled
INFO - 2018-07-21 05:39:46 --> Utf8 Class Initialized
INFO - 2018-07-21 05:39:46 --> URI Class Initialized
INFO - 2018-07-21 05:39:46 --> Router Class Initialized
INFO - 2018-07-21 05:39:46 --> Output Class Initialized
INFO - 2018-07-21 05:39:46 --> Security Class Initialized
DEBUG - 2018-07-21 05:39:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 05:39:46 --> Input Class Initialized
INFO - 2018-07-21 05:39:46 --> Language Class Initialized
INFO - 2018-07-21 05:39:46 --> Language Class Initialized
INFO - 2018-07-21 05:39:46 --> Config Class Initialized
INFO - 2018-07-21 05:39:46 --> Loader Class Initialized
DEBUG - 2018-07-21 05:39:46 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-21 05:39:46 --> Helper loaded: url_helper
INFO - 2018-07-21 05:39:46 --> Helper loaded: form_helper
INFO - 2018-07-21 05:39:46 --> Helper loaded: date_helper
INFO - 2018-07-21 05:39:46 --> Helper loaded: util_helper
INFO - 2018-07-21 05:39:46 --> Helper loaded: text_helper
INFO - 2018-07-21 05:39:46 --> Helper loaded: string_helper
INFO - 2018-07-21 05:39:46 --> Database Driver Class Initialized
DEBUG - 2018-07-21 05:39:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-21 05:39:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-21 05:39:46 --> Email Class Initialized
INFO - 2018-07-21 05:39:46 --> Controller Class Initialized
DEBUG - 2018-07-21 05:39:46 --> Users MX_Controller Initialized
DEBUG - 2018-07-21 05:39:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-21 05:39:46 --> Helper loaded: file_helper
DEBUG - 2018-07-21 05:39:46 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-21 05:39:46 --> Login MX_Controller Initialized
INFO - 2018-07-21 05:39:46 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-21 05:39:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-21 05:39:47 --> Final output sent to browser
DEBUG - 2018-07-21 05:39:47 --> Total execution time: 0.5802
INFO - 2018-07-21 05:39:48 --> Config Class Initialized
INFO - 2018-07-21 05:39:48 --> Hooks Class Initialized
DEBUG - 2018-07-21 05:39:48 --> UTF-8 Support Enabled
INFO - 2018-07-21 05:39:48 --> Utf8 Class Initialized
INFO - 2018-07-21 05:39:48 --> URI Class Initialized
INFO - 2018-07-21 05:39:48 --> Router Class Initialized
INFO - 2018-07-21 05:39:48 --> Output Class Initialized
INFO - 2018-07-21 05:39:48 --> Security Class Initialized
DEBUG - 2018-07-21 05:39:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 05:39:48 --> Input Class Initialized
INFO - 2018-07-21 05:39:48 --> Language Class Initialized
INFO - 2018-07-21 05:39:48 --> Language Class Initialized
INFO - 2018-07-21 05:39:48 --> Config Class Initialized
INFO - 2018-07-21 05:39:48 --> Loader Class Initialized
DEBUG - 2018-07-21 05:39:48 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-21 05:39:48 --> Helper loaded: url_helper
INFO - 2018-07-21 05:39:48 --> Helper loaded: form_helper
INFO - 2018-07-21 05:39:48 --> Helper loaded: date_helper
INFO - 2018-07-21 05:39:48 --> Helper loaded: util_helper
INFO - 2018-07-21 05:39:48 --> Helper loaded: text_helper
INFO - 2018-07-21 05:39:48 --> Helper loaded: string_helper
INFO - 2018-07-21 05:39:48 --> Database Driver Class Initialized
DEBUG - 2018-07-21 05:39:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-21 05:39:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-21 05:39:48 --> Email Class Initialized
INFO - 2018-07-21 05:39:48 --> Controller Class Initialized
DEBUG - 2018-07-21 05:39:48 --> Users MX_Controller Initialized
DEBUG - 2018-07-21 05:39:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-21 05:39:48 --> Helper loaded: file_helper
DEBUG - 2018-07-21 05:39:48 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-21 05:39:48 --> Login MX_Controller Initialized
INFO - 2018-07-21 05:39:48 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-21 05:39:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-21 05:39:48 --> Final output sent to browser
DEBUG - 2018-07-21 05:39:48 --> Total execution time: 0.5971
INFO - 2018-07-21 05:40:03 --> Config Class Initialized
INFO - 2018-07-21 05:40:03 --> Hooks Class Initialized
DEBUG - 2018-07-21 05:40:04 --> UTF-8 Support Enabled
INFO - 2018-07-21 05:40:04 --> Utf8 Class Initialized
INFO - 2018-07-21 05:40:04 --> URI Class Initialized
INFO - 2018-07-21 05:40:04 --> Router Class Initialized
INFO - 2018-07-21 05:40:04 --> Output Class Initialized
INFO - 2018-07-21 05:40:04 --> Security Class Initialized
DEBUG - 2018-07-21 05:40:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 05:40:04 --> Input Class Initialized
INFO - 2018-07-21 05:40:04 --> Language Class Initialized
INFO - 2018-07-21 05:40:04 --> Language Class Initialized
INFO - 2018-07-21 05:40:04 --> Config Class Initialized
INFO - 2018-07-21 05:40:04 --> Loader Class Initialized
DEBUG - 2018-07-21 05:40:04 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-21 05:40:04 --> Helper loaded: url_helper
INFO - 2018-07-21 05:40:04 --> Helper loaded: form_helper
INFO - 2018-07-21 05:40:04 --> Helper loaded: date_helper
INFO - 2018-07-21 05:40:04 --> Helper loaded: util_helper
INFO - 2018-07-21 05:40:04 --> Helper loaded: text_helper
INFO - 2018-07-21 05:40:04 --> Helper loaded: string_helper
INFO - 2018-07-21 05:40:04 --> Database Driver Class Initialized
DEBUG - 2018-07-21 05:40:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-21 05:40:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-21 05:40:04 --> Email Class Initialized
INFO - 2018-07-21 05:40:04 --> Controller Class Initialized
DEBUG - 2018-07-21 05:40:04 --> Users MX_Controller Initialized
DEBUG - 2018-07-21 05:40:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-21 05:40:04 --> Helper loaded: file_helper
DEBUG - 2018-07-21 05:40:04 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-21 05:40:04 --> Login MX_Controller Initialized
INFO - 2018-07-21 05:40:04 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-21 05:40:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-21 05:40:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
DEBUG - 2018-07-21 05:40:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-21 05:40:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
INFO - 2018-07-21 05:40:04 --> Upload Class Initialized
INFO - 2018-07-21 05:40:04 --> Passsword for email - gopaltesting12@yopmail.com - is :: Testing4489
DEBUG - 2018-07-21 05:40:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/templates/credentials.php
DEBUG - 2018-07-21 05:40:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Mail_model.php
DEBUG - 2018-07-21 05:40:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/mail_view.php
INFO - 2018-07-21 05:40:04 --> Mail logged successfully
INFO - 2018-07-21 05:40:04 --> Config Class Initialized
INFO - 2018-07-21 05:40:04 --> Hooks Class Initialized
DEBUG - 2018-07-21 05:40:04 --> UTF-8 Support Enabled
INFO - 2018-07-21 05:40:04 --> Utf8 Class Initialized
INFO - 2018-07-21 05:40:04 --> URI Class Initialized
INFO - 2018-07-21 05:40:04 --> Router Class Initialized
INFO - 2018-07-21 05:40:04 --> Output Class Initialized
INFO - 2018-07-21 05:40:04 --> Security Class Initialized
DEBUG - 2018-07-21 05:40:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 05:40:04 --> Input Class Initialized
INFO - 2018-07-21 05:40:04 --> Language Class Initialized
INFO - 2018-07-21 05:40:04 --> Language Class Initialized
INFO - 2018-07-21 05:40:04 --> Config Class Initialized
INFO - 2018-07-21 05:40:04 --> Loader Class Initialized
DEBUG - 2018-07-21 05:40:04 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-21 05:40:04 --> Helper loaded: url_helper
INFO - 2018-07-21 05:40:04 --> Helper loaded: form_helper
INFO - 2018-07-21 05:40:04 --> Helper loaded: date_helper
INFO - 2018-07-21 05:40:04 --> Helper loaded: util_helper
INFO - 2018-07-21 05:40:04 --> Helper loaded: text_helper
INFO - 2018-07-21 05:40:04 --> Helper loaded: string_helper
INFO - 2018-07-21 05:40:04 --> Database Driver Class Initialized
DEBUG - 2018-07-21 05:40:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-21 05:40:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-21 05:40:05 --> Email Class Initialized
INFO - 2018-07-21 05:40:05 --> Controller Class Initialized
DEBUG - 2018-07-21 05:40:05 --> Users MX_Controller Initialized
DEBUG - 2018-07-21 05:40:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-21 05:40:05 --> Helper loaded: file_helper
DEBUG - 2018-07-21 05:40:05 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-21 05:40:05 --> Login MX_Controller Initialized
INFO - 2018-07-21 05:40:05 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-21 05:40:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-21 05:40:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-21 05:40:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-21 05:40:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-21 05:40:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-21 05:40:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-21 05:40:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/users.php
INFO - 2018-07-21 05:40:05 --> Final output sent to browser
DEBUG - 2018-07-21 05:40:05 --> Total execution time: 0.5719
INFO - 2018-07-21 05:40:05 --> Config Class Initialized
INFO - 2018-07-21 05:40:05 --> Hooks Class Initialized
DEBUG - 2018-07-21 05:40:05 --> UTF-8 Support Enabled
INFO - 2018-07-21 05:40:05 --> Utf8 Class Initialized
INFO - 2018-07-21 05:40:06 --> URI Class Initialized
INFO - 2018-07-21 05:40:06 --> Router Class Initialized
INFO - 2018-07-21 05:40:06 --> Output Class Initialized
INFO - 2018-07-21 05:40:06 --> Security Class Initialized
DEBUG - 2018-07-21 05:40:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 05:40:06 --> Input Class Initialized
INFO - 2018-07-21 05:40:06 --> Language Class Initialized
INFO - 2018-07-21 05:40:06 --> Language Class Initialized
INFO - 2018-07-21 05:40:06 --> Config Class Initialized
INFO - 2018-07-21 05:40:06 --> Loader Class Initialized
DEBUG - 2018-07-21 05:40:06 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-21 05:40:06 --> Helper loaded: url_helper
INFO - 2018-07-21 05:40:06 --> Helper loaded: form_helper
INFO - 2018-07-21 05:40:06 --> Helper loaded: date_helper
INFO - 2018-07-21 05:40:06 --> Helper loaded: util_helper
INFO - 2018-07-21 05:40:06 --> Helper loaded: text_helper
INFO - 2018-07-21 05:40:06 --> Helper loaded: string_helper
INFO - 2018-07-21 05:40:06 --> Database Driver Class Initialized
DEBUG - 2018-07-21 05:40:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-21 05:40:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-21 05:40:06 --> Email Class Initialized
INFO - 2018-07-21 05:40:06 --> Controller Class Initialized
DEBUG - 2018-07-21 05:40:06 --> Users MX_Controller Initialized
DEBUG - 2018-07-21 05:40:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-21 05:40:06 --> Helper loaded: file_helper
DEBUG - 2018-07-21 05:40:06 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-21 05:40:06 --> Login MX_Controller Initialized
INFO - 2018-07-21 05:40:06 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-21 05:40:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-21 05:40:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-07-21 05:40:06 --> Final output sent to browser
DEBUG - 2018-07-21 05:40:06 --> Total execution time: 0.8399
INFO - 2018-07-21 05:40:17 --> Config Class Initialized
INFO - 2018-07-21 05:40:17 --> Hooks Class Initialized
DEBUG - 2018-07-21 05:40:17 --> UTF-8 Support Enabled
INFO - 2018-07-21 05:40:17 --> Utf8 Class Initialized
INFO - 2018-07-21 05:40:17 --> URI Class Initialized
INFO - 2018-07-21 05:40:17 --> Router Class Initialized
INFO - 2018-07-21 05:40:17 --> Output Class Initialized
INFO - 2018-07-21 05:40:17 --> Security Class Initialized
DEBUG - 2018-07-21 05:40:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 05:40:17 --> Input Class Initialized
INFO - 2018-07-21 05:40:17 --> Language Class Initialized
INFO - 2018-07-21 05:40:17 --> Language Class Initialized
INFO - 2018-07-21 05:40:17 --> Config Class Initialized
INFO - 2018-07-21 05:40:17 --> Loader Class Initialized
DEBUG - 2018-07-21 05:40:17 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-21 05:40:17 --> Helper loaded: url_helper
INFO - 2018-07-21 05:40:17 --> Helper loaded: form_helper
INFO - 2018-07-21 05:40:17 --> Helper loaded: date_helper
INFO - 2018-07-21 05:40:17 --> Helper loaded: util_helper
INFO - 2018-07-21 05:40:17 --> Helper loaded: text_helper
INFO - 2018-07-21 05:40:17 --> Helper loaded: string_helper
INFO - 2018-07-21 05:40:17 --> Database Driver Class Initialized
DEBUG - 2018-07-21 05:40:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-21 05:40:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-21 05:40:17 --> Email Class Initialized
INFO - 2018-07-21 05:40:17 --> Controller Class Initialized
DEBUG - 2018-07-21 05:40:17 --> Admin MX_Controller Initialized
INFO - 2018-07-21 05:40:17 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-21 05:40:17 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-21 05:40:17 --> Login MX_Controller Initialized
DEBUG - 2018-07-21 05:40:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-21 05:40:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-21 05:40:18 --> Final output sent to browser
DEBUG - 2018-07-21 05:40:18 --> Total execution time: 0.8910
INFO - 2018-07-21 05:52:56 --> Config Class Initialized
INFO - 2018-07-21 05:52:56 --> Hooks Class Initialized
DEBUG - 2018-07-21 05:52:56 --> UTF-8 Support Enabled
INFO - 2018-07-21 05:52:56 --> Utf8 Class Initialized
INFO - 2018-07-21 05:52:56 --> URI Class Initialized
INFO - 2018-07-21 05:52:56 --> Router Class Initialized
INFO - 2018-07-21 05:52:56 --> Output Class Initialized
INFO - 2018-07-21 05:52:56 --> Security Class Initialized
DEBUG - 2018-07-21 05:52:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 05:52:56 --> Input Class Initialized
INFO - 2018-07-21 05:52:56 --> Language Class Initialized
INFO - 2018-07-21 05:52:56 --> Language Class Initialized
INFO - 2018-07-21 05:52:56 --> Config Class Initialized
INFO - 2018-07-21 05:52:56 --> Loader Class Initialized
DEBUG - 2018-07-21 05:52:56 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-21 05:52:56 --> Helper loaded: url_helper
INFO - 2018-07-21 05:52:56 --> Helper loaded: form_helper
INFO - 2018-07-21 05:52:56 --> Helper loaded: date_helper
INFO - 2018-07-21 05:52:56 --> Helper loaded: util_helper
INFO - 2018-07-21 05:52:56 --> Helper loaded: text_helper
INFO - 2018-07-21 05:52:56 --> Helper loaded: string_helper
INFO - 2018-07-21 05:52:56 --> Database Driver Class Initialized
DEBUG - 2018-07-21 05:52:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-21 05:52:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-21 05:52:56 --> Email Class Initialized
INFO - 2018-07-21 05:52:56 --> Controller Class Initialized
DEBUG - 2018-07-21 05:52:56 --> Users MX_Controller Initialized
DEBUG - 2018-07-21 05:52:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-21 05:52:56 --> Helper loaded: file_helper
DEBUG - 2018-07-21 05:52:56 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-21 05:52:56 --> Login MX_Controller Initialized
INFO - 2018-07-21 05:52:56 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-21 05:52:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-21 05:52:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-21 05:52:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-21 05:52:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-21 05:52:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-21 05:52:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-21 05:52:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/users.php
INFO - 2018-07-21 05:52:56 --> Final output sent to browser
DEBUG - 2018-07-21 05:52:56 --> Total execution time: 0.5696
INFO - 2018-07-21 05:52:57 --> Config Class Initialized
INFO - 2018-07-21 05:52:57 --> Hooks Class Initialized
DEBUG - 2018-07-21 05:52:57 --> UTF-8 Support Enabled
INFO - 2018-07-21 05:52:57 --> Utf8 Class Initialized
INFO - 2018-07-21 05:52:57 --> URI Class Initialized
INFO - 2018-07-21 05:52:57 --> Router Class Initialized
INFO - 2018-07-21 05:52:57 --> Output Class Initialized
INFO - 2018-07-21 05:52:57 --> Security Class Initialized
DEBUG - 2018-07-21 05:52:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 05:52:57 --> Input Class Initialized
INFO - 2018-07-21 05:52:57 --> Language Class Initialized
INFO - 2018-07-21 05:52:57 --> Language Class Initialized
INFO - 2018-07-21 05:52:57 --> Config Class Initialized
INFO - 2018-07-21 05:52:57 --> Loader Class Initialized
DEBUG - 2018-07-21 05:52:57 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-21 05:52:57 --> Helper loaded: url_helper
INFO - 2018-07-21 05:52:57 --> Helper loaded: form_helper
INFO - 2018-07-21 05:52:57 --> Helper loaded: date_helper
INFO - 2018-07-21 05:52:57 --> Helper loaded: util_helper
INFO - 2018-07-21 05:52:57 --> Helper loaded: text_helper
INFO - 2018-07-21 05:52:57 --> Helper loaded: string_helper
INFO - 2018-07-21 05:52:57 --> Database Driver Class Initialized
DEBUG - 2018-07-21 05:52:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-21 05:52:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-21 05:52:57 --> Email Class Initialized
INFO - 2018-07-21 05:52:57 --> Controller Class Initialized
DEBUG - 2018-07-21 05:52:57 --> Users MX_Controller Initialized
DEBUG - 2018-07-21 05:52:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-21 05:52:57 --> Helper loaded: file_helper
DEBUG - 2018-07-21 05:52:57 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-21 05:52:57 --> Login MX_Controller Initialized
INFO - 2018-07-21 05:52:57 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-21 05:52:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-21 05:52:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-07-21 05:52:57 --> Final output sent to browser
DEBUG - 2018-07-21 05:52:57 --> Total execution time: 0.6235
INFO - 2018-07-21 05:53:00 --> Config Class Initialized
INFO - 2018-07-21 05:53:00 --> Hooks Class Initialized
DEBUG - 2018-07-21 05:53:00 --> UTF-8 Support Enabled
INFO - 2018-07-21 05:53:00 --> Utf8 Class Initialized
INFO - 2018-07-21 05:53:00 --> URI Class Initialized
INFO - 2018-07-21 05:53:01 --> Router Class Initialized
INFO - 2018-07-21 05:53:01 --> Output Class Initialized
INFO - 2018-07-21 05:53:01 --> Security Class Initialized
DEBUG - 2018-07-21 05:53:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 05:53:01 --> Input Class Initialized
INFO - 2018-07-21 05:53:01 --> Language Class Initialized
INFO - 2018-07-21 05:53:01 --> Language Class Initialized
INFO - 2018-07-21 05:53:01 --> Config Class Initialized
INFO - 2018-07-21 05:53:01 --> Loader Class Initialized
DEBUG - 2018-07-21 05:53:01 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-21 05:53:01 --> Helper loaded: url_helper
INFO - 2018-07-21 05:53:01 --> Helper loaded: form_helper
INFO - 2018-07-21 05:53:01 --> Helper loaded: date_helper
INFO - 2018-07-21 05:53:01 --> Helper loaded: util_helper
INFO - 2018-07-21 05:53:01 --> Helper loaded: text_helper
INFO - 2018-07-21 05:53:01 --> Helper loaded: string_helper
INFO - 2018-07-21 05:53:01 --> Database Driver Class Initialized
DEBUG - 2018-07-21 05:53:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-21 05:53:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-21 05:53:01 --> Email Class Initialized
INFO - 2018-07-21 05:53:01 --> Controller Class Initialized
DEBUG - 2018-07-21 05:53:01 --> Users MX_Controller Initialized
DEBUG - 2018-07-21 05:53:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-21 05:53:01 --> Helper loaded: file_helper
DEBUG - 2018-07-21 05:53:01 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-21 05:53:01 --> Login MX_Controller Initialized
INFO - 2018-07-21 05:53:01 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-21 05:53:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-21 05:53:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
DEBUG - 2018-07-21 05:53:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
ERROR - 2018-07-21 05:53:01 --> Severity: Notice --> Undefined variable: dt_cour_sel_ls E:\xampp\htdocs\consulting\application\modules\admin\controllers\Users.php 131
DEBUG - 2018-07-21 05:53:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-21 05:53:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-21 05:53:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-21 05:53:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-21 05:53:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-21 05:53:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/create_user.php
INFO - 2018-07-21 05:53:01 --> Final output sent to browser
DEBUG - 2018-07-21 05:53:01 --> Total execution time: 0.6929
INFO - 2018-07-21 05:53:42 --> Config Class Initialized
INFO - 2018-07-21 05:53:42 --> Hooks Class Initialized
DEBUG - 2018-07-21 05:53:42 --> UTF-8 Support Enabled
INFO - 2018-07-21 05:53:42 --> Utf8 Class Initialized
INFO - 2018-07-21 05:53:42 --> URI Class Initialized
INFO - 2018-07-21 05:53:43 --> Router Class Initialized
INFO - 2018-07-21 05:53:43 --> Output Class Initialized
INFO - 2018-07-21 05:53:43 --> Security Class Initialized
DEBUG - 2018-07-21 05:53:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 05:53:43 --> Input Class Initialized
INFO - 2018-07-21 05:53:43 --> Language Class Initialized
INFO - 2018-07-21 05:53:43 --> Language Class Initialized
INFO - 2018-07-21 05:53:43 --> Config Class Initialized
INFO - 2018-07-21 05:53:43 --> Loader Class Initialized
DEBUG - 2018-07-21 05:53:43 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-21 05:53:43 --> Helper loaded: url_helper
INFO - 2018-07-21 05:53:43 --> Helper loaded: form_helper
INFO - 2018-07-21 05:53:43 --> Helper loaded: date_helper
INFO - 2018-07-21 05:53:43 --> Helper loaded: util_helper
INFO - 2018-07-21 05:53:43 --> Helper loaded: text_helper
INFO - 2018-07-21 05:53:43 --> Helper loaded: string_helper
INFO - 2018-07-21 05:53:43 --> Database Driver Class Initialized
DEBUG - 2018-07-21 05:53:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-21 05:53:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-21 05:53:43 --> Email Class Initialized
INFO - 2018-07-21 05:53:43 --> Controller Class Initialized
DEBUG - 2018-07-21 05:53:43 --> Users MX_Controller Initialized
DEBUG - 2018-07-21 05:53:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-21 05:53:43 --> Helper loaded: file_helper
DEBUG - 2018-07-21 05:53:43 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-21 05:53:43 --> Login MX_Controller Initialized
INFO - 2018-07-21 05:53:43 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-21 05:53:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-21 05:53:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
DEBUG - 2018-07-21 05:53:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-21 05:53:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-21 05:53:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-21 05:53:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-21 05:53:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-21 05:53:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-21 05:53:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/create_user.php
INFO - 2018-07-21 05:53:43 --> Final output sent to browser
DEBUG - 2018-07-21 05:53:43 --> Total execution time: 0.6061
INFO - 2018-07-21 05:54:49 --> Config Class Initialized
INFO - 2018-07-21 05:54:49 --> Hooks Class Initialized
DEBUG - 2018-07-21 05:54:49 --> UTF-8 Support Enabled
INFO - 2018-07-21 05:54:49 --> Utf8 Class Initialized
INFO - 2018-07-21 05:54:49 --> URI Class Initialized
INFO - 2018-07-21 05:54:49 --> Router Class Initialized
INFO - 2018-07-21 05:54:49 --> Output Class Initialized
INFO - 2018-07-21 05:54:49 --> Security Class Initialized
DEBUG - 2018-07-21 05:54:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 05:54:49 --> Input Class Initialized
INFO - 2018-07-21 05:54:49 --> Language Class Initialized
INFO - 2018-07-21 05:54:50 --> Language Class Initialized
INFO - 2018-07-21 05:54:50 --> Config Class Initialized
INFO - 2018-07-21 05:54:50 --> Loader Class Initialized
DEBUG - 2018-07-21 05:54:50 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-21 05:54:50 --> Helper loaded: url_helper
INFO - 2018-07-21 05:54:50 --> Helper loaded: form_helper
INFO - 2018-07-21 05:54:50 --> Helper loaded: date_helper
INFO - 2018-07-21 05:54:50 --> Helper loaded: util_helper
INFO - 2018-07-21 05:54:50 --> Helper loaded: text_helper
INFO - 2018-07-21 05:54:50 --> Helper loaded: string_helper
INFO - 2018-07-21 05:54:50 --> Database Driver Class Initialized
DEBUG - 2018-07-21 05:54:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-21 05:54:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-21 05:54:50 --> Email Class Initialized
INFO - 2018-07-21 05:54:50 --> Controller Class Initialized
DEBUG - 2018-07-21 05:54:50 --> Users MX_Controller Initialized
DEBUG - 2018-07-21 05:54:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-21 05:54:50 --> Helper loaded: file_helper
DEBUG - 2018-07-21 05:54:50 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-21 05:54:50 --> Login MX_Controller Initialized
INFO - 2018-07-21 05:54:50 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-21 05:54:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-21 05:54:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
DEBUG - 2018-07-21 05:54:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-21 05:54:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
INFO - 2018-07-21 06:06:00 --> Config Class Initialized
INFO - 2018-07-21 06:06:00 --> Hooks Class Initialized
DEBUG - 2018-07-21 06:06:00 --> UTF-8 Support Enabled
INFO - 2018-07-21 06:06:00 --> Utf8 Class Initialized
INFO - 2018-07-21 06:06:00 --> URI Class Initialized
INFO - 2018-07-21 06:06:00 --> Router Class Initialized
INFO - 2018-07-21 06:06:00 --> Output Class Initialized
INFO - 2018-07-21 06:06:00 --> Security Class Initialized
DEBUG - 2018-07-21 06:06:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 06:06:00 --> Input Class Initialized
INFO - 2018-07-21 06:06:00 --> Language Class Initialized
INFO - 2018-07-21 06:06:00 --> Language Class Initialized
INFO - 2018-07-21 06:06:00 --> Config Class Initialized
INFO - 2018-07-21 06:06:00 --> Loader Class Initialized
DEBUG - 2018-07-21 06:06:00 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-21 06:06:00 --> Helper loaded: url_helper
INFO - 2018-07-21 06:06:00 --> Helper loaded: form_helper
INFO - 2018-07-21 06:06:00 --> Helper loaded: date_helper
INFO - 2018-07-21 06:06:00 --> Helper loaded: util_helper
INFO - 2018-07-21 06:06:00 --> Helper loaded: text_helper
INFO - 2018-07-21 06:06:00 --> Helper loaded: string_helper
INFO - 2018-07-21 06:06:00 --> Database Driver Class Initialized
DEBUG - 2018-07-21 06:06:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-21 06:06:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-21 06:06:00 --> Email Class Initialized
INFO - 2018-07-21 06:06:00 --> Controller Class Initialized
DEBUG - 2018-07-21 06:06:00 --> Users MX_Controller Initialized
DEBUG - 2018-07-21 06:06:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-21 06:06:00 --> Helper loaded: file_helper
DEBUG - 2018-07-21 06:06:00 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-21 06:06:00 --> Login MX_Controller Initialized
INFO - 2018-07-21 06:06:00 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-21 06:06:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-21 06:06:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
DEBUG - 2018-07-21 06:06:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-21 06:06:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
ERROR - 2018-07-21 06:06:00 --> Severity: Notice --> Undefined property: CI::$user_model E:\xampp\htdocs\consulting\application\third_party\MX\Controller.php 59
ERROR - 2018-07-21 06:06:00 --> Severity: error --> Exception: Call to a member function delete_course_sel() on null E:\xampp\htdocs\consulting\application\modules\admin\controllers\Users.php 299
INFO - 2018-07-21 06:06:34 --> Config Class Initialized
INFO - 2018-07-21 06:06:34 --> Hooks Class Initialized
DEBUG - 2018-07-21 06:06:34 --> UTF-8 Support Enabled
INFO - 2018-07-21 06:06:34 --> Utf8 Class Initialized
INFO - 2018-07-21 06:06:34 --> URI Class Initialized
INFO - 2018-07-21 06:06:34 --> Router Class Initialized
INFO - 2018-07-21 06:06:34 --> Output Class Initialized
INFO - 2018-07-21 06:06:35 --> Security Class Initialized
DEBUG - 2018-07-21 06:06:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 06:06:35 --> Input Class Initialized
INFO - 2018-07-21 06:06:35 --> Language Class Initialized
INFO - 2018-07-21 06:06:35 --> Language Class Initialized
INFO - 2018-07-21 06:06:35 --> Config Class Initialized
INFO - 2018-07-21 06:06:35 --> Loader Class Initialized
DEBUG - 2018-07-21 06:06:35 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-21 06:06:35 --> Helper loaded: url_helper
INFO - 2018-07-21 06:06:35 --> Helper loaded: form_helper
INFO - 2018-07-21 06:06:35 --> Helper loaded: date_helper
INFO - 2018-07-21 06:06:35 --> Helper loaded: util_helper
INFO - 2018-07-21 06:06:35 --> Helper loaded: text_helper
INFO - 2018-07-21 06:06:35 --> Helper loaded: string_helper
INFO - 2018-07-21 06:06:35 --> Database Driver Class Initialized
DEBUG - 2018-07-21 06:06:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-21 06:06:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-21 06:06:35 --> Email Class Initialized
INFO - 2018-07-21 06:06:35 --> Controller Class Initialized
DEBUG - 2018-07-21 06:06:35 --> Users MX_Controller Initialized
DEBUG - 2018-07-21 06:06:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
ERROR - 2018-07-21 06:06:35 --> Severity: error --> Exception: Unable to locate the model you have specified: User_model E:\xampp\htdocs\consulting\system\core\Loader.php 348
INFO - 2018-07-21 06:06:56 --> Config Class Initialized
INFO - 2018-07-21 06:06:56 --> Hooks Class Initialized
DEBUG - 2018-07-21 06:06:56 --> UTF-8 Support Enabled
INFO - 2018-07-21 06:06:56 --> Utf8 Class Initialized
INFO - 2018-07-21 06:06:56 --> URI Class Initialized
INFO - 2018-07-21 06:06:56 --> Router Class Initialized
INFO - 2018-07-21 06:06:56 --> Output Class Initialized
INFO - 2018-07-21 06:06:56 --> Security Class Initialized
DEBUG - 2018-07-21 06:06:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 06:06:56 --> Input Class Initialized
INFO - 2018-07-21 06:06:56 --> Language Class Initialized
INFO - 2018-07-21 06:06:56 --> Language Class Initialized
INFO - 2018-07-21 06:06:56 --> Config Class Initialized
INFO - 2018-07-21 06:06:56 --> Loader Class Initialized
DEBUG - 2018-07-21 06:06:56 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-21 06:06:56 --> Helper loaded: url_helper
INFO - 2018-07-21 06:06:56 --> Helper loaded: form_helper
INFO - 2018-07-21 06:06:56 --> Helper loaded: date_helper
INFO - 2018-07-21 06:06:56 --> Helper loaded: util_helper
INFO - 2018-07-21 06:06:56 --> Helper loaded: text_helper
INFO - 2018-07-21 06:06:56 --> Helper loaded: string_helper
INFO - 2018-07-21 06:06:56 --> Database Driver Class Initialized
DEBUG - 2018-07-21 06:06:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-21 06:06:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-21 06:06:56 --> Email Class Initialized
INFO - 2018-07-21 06:06:56 --> Controller Class Initialized
DEBUG - 2018-07-21 06:06:56 --> Users MX_Controller Initialized
DEBUG - 2018-07-21 06:06:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-21 06:06:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-07-21 06:06:56 --> Helper loaded: file_helper
DEBUG - 2018-07-21 06:06:56 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-21 06:06:56 --> Login MX_Controller Initialized
INFO - 2018-07-21 06:06:56 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-21 06:06:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-21 06:06:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-21 06:06:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
INFO - 2018-07-21 06:07:08 --> Config Class Initialized
INFO - 2018-07-21 06:07:08 --> Hooks Class Initialized
DEBUG - 2018-07-21 06:07:08 --> UTF-8 Support Enabled
INFO - 2018-07-21 06:07:08 --> Utf8 Class Initialized
INFO - 2018-07-21 06:07:08 --> URI Class Initialized
INFO - 2018-07-21 06:07:08 --> Router Class Initialized
INFO - 2018-07-21 06:07:08 --> Output Class Initialized
INFO - 2018-07-21 06:07:08 --> Security Class Initialized
DEBUG - 2018-07-21 06:07:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 06:07:08 --> Input Class Initialized
INFO - 2018-07-21 06:07:08 --> Language Class Initialized
INFO - 2018-07-21 06:07:08 --> Language Class Initialized
INFO - 2018-07-21 06:07:08 --> Config Class Initialized
INFO - 2018-07-21 06:07:08 --> Loader Class Initialized
DEBUG - 2018-07-21 06:07:08 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-21 06:07:08 --> Helper loaded: url_helper
INFO - 2018-07-21 06:07:08 --> Helper loaded: form_helper
INFO - 2018-07-21 06:07:08 --> Helper loaded: date_helper
INFO - 2018-07-21 06:07:08 --> Helper loaded: util_helper
INFO - 2018-07-21 06:07:08 --> Helper loaded: text_helper
INFO - 2018-07-21 06:07:08 --> Helper loaded: string_helper
INFO - 2018-07-21 06:07:08 --> Database Driver Class Initialized
DEBUG - 2018-07-21 06:07:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-21 06:07:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-21 06:07:08 --> Email Class Initialized
INFO - 2018-07-21 06:07:08 --> Controller Class Initialized
DEBUG - 2018-07-21 06:07:08 --> Users MX_Controller Initialized
DEBUG - 2018-07-21 06:07:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-21 06:07:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-07-21 06:07:08 --> Helper loaded: file_helper
DEBUG - 2018-07-21 06:07:08 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-21 06:07:08 --> Login MX_Controller Initialized
INFO - 2018-07-21 06:07:08 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-21 06:07:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-21 06:07:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-21 06:07:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
INFO - 2018-07-21 06:07:13 --> Config Class Initialized
INFO - 2018-07-21 06:07:13 --> Hooks Class Initialized
DEBUG - 2018-07-21 06:07:13 --> UTF-8 Support Enabled
INFO - 2018-07-21 06:07:13 --> Utf8 Class Initialized
INFO - 2018-07-21 06:07:13 --> URI Class Initialized
INFO - 2018-07-21 06:07:13 --> Router Class Initialized
INFO - 2018-07-21 06:07:13 --> Output Class Initialized
INFO - 2018-07-21 06:07:13 --> Security Class Initialized
DEBUG - 2018-07-21 06:07:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 06:07:13 --> Input Class Initialized
INFO - 2018-07-21 06:07:13 --> Language Class Initialized
INFO - 2018-07-21 06:07:13 --> Language Class Initialized
INFO - 2018-07-21 06:07:13 --> Config Class Initialized
INFO - 2018-07-21 06:07:13 --> Loader Class Initialized
DEBUG - 2018-07-21 06:07:13 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-21 06:07:13 --> Helper loaded: url_helper
INFO - 2018-07-21 06:07:13 --> Helper loaded: form_helper
INFO - 2018-07-21 06:07:13 --> Helper loaded: date_helper
INFO - 2018-07-21 06:07:13 --> Helper loaded: util_helper
INFO - 2018-07-21 06:07:13 --> Helper loaded: text_helper
INFO - 2018-07-21 06:07:13 --> Helper loaded: string_helper
INFO - 2018-07-21 06:07:13 --> Database Driver Class Initialized
DEBUG - 2018-07-21 06:07:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-21 06:07:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-21 06:07:13 --> Email Class Initialized
INFO - 2018-07-21 06:07:13 --> Controller Class Initialized
DEBUG - 2018-07-21 06:07:13 --> Users MX_Controller Initialized
DEBUG - 2018-07-21 06:07:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-21 06:07:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-07-21 06:07:13 --> Helper loaded: file_helper
DEBUG - 2018-07-21 06:07:13 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-21 06:07:13 --> Login MX_Controller Initialized
INFO - 2018-07-21 06:07:13 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-21 06:07:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-21 06:07:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-21 06:07:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
ERROR - 2018-07-21 06:07:13 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable E:\xampp\htdocs\consulting\application\modules\admin\controllers\Users.php 311
ERROR - 2018-07-21 06:07:13 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable E:\xampp\htdocs\consulting\application\modules\admin\controllers\Users.php 311
INFO - 2018-07-21 06:07:13 --> Config Class Initialized
INFO - 2018-07-21 06:07:13 --> Hooks Class Initialized
DEBUG - 2018-07-21 06:07:13 --> UTF-8 Support Enabled
INFO - 2018-07-21 06:07:13 --> Utf8 Class Initialized
INFO - 2018-07-21 06:07:13 --> URI Class Initialized
INFO - 2018-07-21 06:07:13 --> Router Class Initialized
INFO - 2018-07-21 06:07:13 --> Output Class Initialized
INFO - 2018-07-21 06:07:13 --> Security Class Initialized
DEBUG - 2018-07-21 06:07:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 06:07:13 --> Input Class Initialized
INFO - 2018-07-21 06:07:13 --> Language Class Initialized
INFO - 2018-07-21 06:07:13 --> Language Class Initialized
INFO - 2018-07-21 06:07:13 --> Config Class Initialized
INFO - 2018-07-21 06:07:13 --> Loader Class Initialized
DEBUG - 2018-07-21 06:07:13 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-21 06:07:13 --> Helper loaded: url_helper
INFO - 2018-07-21 06:07:13 --> Helper loaded: form_helper
INFO - 2018-07-21 06:07:14 --> Helper loaded: date_helper
INFO - 2018-07-21 06:07:14 --> Helper loaded: util_helper
INFO - 2018-07-21 06:07:14 --> Helper loaded: text_helper
INFO - 2018-07-21 06:07:14 --> Helper loaded: string_helper
INFO - 2018-07-21 06:07:14 --> Database Driver Class Initialized
DEBUG - 2018-07-21 06:07:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-21 06:07:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-21 06:07:14 --> Email Class Initialized
INFO - 2018-07-21 06:07:14 --> Controller Class Initialized
DEBUG - 2018-07-21 06:07:14 --> Users MX_Controller Initialized
DEBUG - 2018-07-21 06:07:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-21 06:07:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-07-21 06:07:14 --> Helper loaded: file_helper
DEBUG - 2018-07-21 06:07:14 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-21 06:07:14 --> Login MX_Controller Initialized
INFO - 2018-07-21 06:07:14 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-21 06:07:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-21 06:07:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-21 06:07:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-21 06:07:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-21 06:07:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-21 06:07:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-21 06:07:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/users.php
INFO - 2018-07-21 06:07:14 --> Final output sent to browser
DEBUG - 2018-07-21 06:07:14 --> Total execution time: 0.6154
INFO - 2018-07-21 06:07:14 --> Config Class Initialized
INFO - 2018-07-21 06:07:14 --> Hooks Class Initialized
DEBUG - 2018-07-21 06:07:14 --> UTF-8 Support Enabled
INFO - 2018-07-21 06:07:15 --> Utf8 Class Initialized
INFO - 2018-07-21 06:07:15 --> URI Class Initialized
INFO - 2018-07-21 06:07:15 --> Router Class Initialized
INFO - 2018-07-21 06:07:15 --> Output Class Initialized
INFO - 2018-07-21 06:07:15 --> Security Class Initialized
DEBUG - 2018-07-21 06:07:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 06:07:15 --> Input Class Initialized
INFO - 2018-07-21 06:07:15 --> Language Class Initialized
INFO - 2018-07-21 06:07:15 --> Language Class Initialized
INFO - 2018-07-21 06:07:15 --> Config Class Initialized
INFO - 2018-07-21 06:07:15 --> Loader Class Initialized
DEBUG - 2018-07-21 06:07:15 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-21 06:07:15 --> Helper loaded: url_helper
INFO - 2018-07-21 06:07:15 --> Helper loaded: form_helper
INFO - 2018-07-21 06:07:15 --> Helper loaded: date_helper
INFO - 2018-07-21 06:07:15 --> Helper loaded: util_helper
INFO - 2018-07-21 06:07:15 --> Helper loaded: text_helper
INFO - 2018-07-21 06:07:15 --> Helper loaded: string_helper
INFO - 2018-07-21 06:07:15 --> Database Driver Class Initialized
DEBUG - 2018-07-21 06:07:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-21 06:07:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-21 06:07:15 --> Email Class Initialized
INFO - 2018-07-21 06:07:15 --> Controller Class Initialized
DEBUG - 2018-07-21 06:07:15 --> Users MX_Controller Initialized
DEBUG - 2018-07-21 06:07:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-21 06:07:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-07-21 06:07:15 --> Helper loaded: file_helper
DEBUG - 2018-07-21 06:07:15 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-21 06:07:15 --> Login MX_Controller Initialized
INFO - 2018-07-21 06:07:15 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-21 06:07:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-21 06:07:15 --> Final output sent to browser
DEBUG - 2018-07-21 06:07:15 --> Total execution time: 0.6601
INFO - 2018-07-21 06:07:16 --> Config Class Initialized
INFO - 2018-07-21 06:07:16 --> Hooks Class Initialized
DEBUG - 2018-07-21 06:07:16 --> UTF-8 Support Enabled
INFO - 2018-07-21 06:07:16 --> Utf8 Class Initialized
INFO - 2018-07-21 06:07:16 --> URI Class Initialized
INFO - 2018-07-21 06:07:16 --> Router Class Initialized
INFO - 2018-07-21 06:07:16 --> Output Class Initialized
INFO - 2018-07-21 06:07:16 --> Security Class Initialized
DEBUG - 2018-07-21 06:07:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 06:07:16 --> Input Class Initialized
INFO - 2018-07-21 06:07:16 --> Language Class Initialized
INFO - 2018-07-21 06:07:16 --> Language Class Initialized
INFO - 2018-07-21 06:07:16 --> Config Class Initialized
INFO - 2018-07-21 06:07:16 --> Loader Class Initialized
DEBUG - 2018-07-21 06:07:16 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-21 06:07:16 --> Helper loaded: url_helper
INFO - 2018-07-21 06:07:16 --> Helper loaded: form_helper
INFO - 2018-07-21 06:07:16 --> Helper loaded: date_helper
INFO - 2018-07-21 06:07:16 --> Helper loaded: util_helper
INFO - 2018-07-21 06:07:16 --> Helper loaded: text_helper
INFO - 2018-07-21 06:07:16 --> Helper loaded: string_helper
INFO - 2018-07-21 06:07:16 --> Database Driver Class Initialized
DEBUG - 2018-07-21 06:07:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-21 06:07:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-21 06:07:16 --> Email Class Initialized
INFO - 2018-07-21 06:07:16 --> Controller Class Initialized
DEBUG - 2018-07-21 06:07:16 --> Users MX_Controller Initialized
DEBUG - 2018-07-21 06:07:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-21 06:07:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-07-21 06:07:16 --> Helper loaded: file_helper
DEBUG - 2018-07-21 06:07:16 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-21 06:07:16 --> Login MX_Controller Initialized
INFO - 2018-07-21 06:07:17 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-21 06:07:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-21 06:07:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-21 06:07:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-21 06:07:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-21 06:07:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-21 06:07:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-21 06:07:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-21 06:07:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/create_user.php
INFO - 2018-07-21 06:07:17 --> Final output sent to browser
DEBUG - 2018-07-21 06:07:17 --> Total execution time: 0.6402
INFO - 2018-07-21 06:07:23 --> Config Class Initialized
INFO - 2018-07-21 06:07:23 --> Hooks Class Initialized
DEBUG - 2018-07-21 06:07:23 --> UTF-8 Support Enabled
INFO - 2018-07-21 06:07:23 --> Utf8 Class Initialized
INFO - 2018-07-21 06:07:23 --> URI Class Initialized
INFO - 2018-07-21 06:07:23 --> Router Class Initialized
INFO - 2018-07-21 06:07:23 --> Output Class Initialized
INFO - 2018-07-21 06:07:23 --> Security Class Initialized
DEBUG - 2018-07-21 06:07:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 06:07:23 --> Input Class Initialized
INFO - 2018-07-21 06:07:23 --> Language Class Initialized
INFO - 2018-07-21 06:07:23 --> Language Class Initialized
INFO - 2018-07-21 06:07:23 --> Config Class Initialized
INFO - 2018-07-21 06:07:23 --> Loader Class Initialized
DEBUG - 2018-07-21 06:07:23 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-21 06:07:23 --> Helper loaded: url_helper
INFO - 2018-07-21 06:07:23 --> Helper loaded: form_helper
INFO - 2018-07-21 06:07:23 --> Helper loaded: date_helper
INFO - 2018-07-21 06:07:23 --> Helper loaded: util_helper
INFO - 2018-07-21 06:07:24 --> Helper loaded: text_helper
INFO - 2018-07-21 06:07:24 --> Helper loaded: string_helper
INFO - 2018-07-21 06:07:24 --> Database Driver Class Initialized
DEBUG - 2018-07-21 06:07:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-21 06:07:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-21 06:07:24 --> Email Class Initialized
INFO - 2018-07-21 06:07:24 --> Controller Class Initialized
DEBUG - 2018-07-21 06:07:24 --> Users MX_Controller Initialized
DEBUG - 2018-07-21 06:07:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-21 06:07:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-07-21 06:07:24 --> Helper loaded: file_helper
DEBUG - 2018-07-21 06:07:24 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-21 06:07:24 --> Login MX_Controller Initialized
INFO - 2018-07-21 06:07:24 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-21 06:07:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-21 06:07:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-21 06:07:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
INFO - 2018-07-21 06:07:24 --> Config Class Initialized
INFO - 2018-07-21 06:07:24 --> Hooks Class Initialized
DEBUG - 2018-07-21 06:07:24 --> UTF-8 Support Enabled
INFO - 2018-07-21 06:07:24 --> Utf8 Class Initialized
INFO - 2018-07-21 06:07:24 --> URI Class Initialized
INFO - 2018-07-21 06:07:24 --> Router Class Initialized
INFO - 2018-07-21 06:07:24 --> Output Class Initialized
INFO - 2018-07-21 06:07:24 --> Security Class Initialized
DEBUG - 2018-07-21 06:07:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 06:07:24 --> Input Class Initialized
INFO - 2018-07-21 06:07:24 --> Language Class Initialized
INFO - 2018-07-21 06:07:24 --> Language Class Initialized
INFO - 2018-07-21 06:07:24 --> Config Class Initialized
INFO - 2018-07-21 06:07:24 --> Loader Class Initialized
DEBUG - 2018-07-21 06:07:24 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-21 06:07:24 --> Helper loaded: url_helper
INFO - 2018-07-21 06:07:24 --> Helper loaded: form_helper
INFO - 2018-07-21 06:07:24 --> Helper loaded: date_helper
INFO - 2018-07-21 06:07:24 --> Helper loaded: util_helper
INFO - 2018-07-21 06:07:24 --> Helper loaded: text_helper
INFO - 2018-07-21 06:07:24 --> Helper loaded: string_helper
INFO - 2018-07-21 06:07:24 --> Database Driver Class Initialized
DEBUG - 2018-07-21 06:07:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-21 06:07:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-21 06:07:24 --> Email Class Initialized
INFO - 2018-07-21 06:07:24 --> Controller Class Initialized
DEBUG - 2018-07-21 06:07:24 --> Users MX_Controller Initialized
DEBUG - 2018-07-21 06:07:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-21 06:07:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-07-21 06:07:24 --> Helper loaded: file_helper
DEBUG - 2018-07-21 06:07:24 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-21 06:07:24 --> Login MX_Controller Initialized
INFO - 2018-07-21 06:07:24 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-21 06:07:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-21 06:07:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-21 06:07:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-21 06:07:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-21 06:07:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-21 06:07:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-21 06:07:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/users.php
INFO - 2018-07-21 06:07:24 --> Final output sent to browser
DEBUG - 2018-07-21 06:07:24 --> Total execution time: 0.6089
INFO - 2018-07-21 06:07:25 --> Config Class Initialized
INFO - 2018-07-21 06:07:25 --> Hooks Class Initialized
DEBUG - 2018-07-21 06:07:25 --> UTF-8 Support Enabled
INFO - 2018-07-21 06:07:25 --> Utf8 Class Initialized
INFO - 2018-07-21 06:07:25 --> URI Class Initialized
INFO - 2018-07-21 06:07:25 --> Router Class Initialized
INFO - 2018-07-21 06:07:25 --> Output Class Initialized
INFO - 2018-07-21 06:07:25 --> Security Class Initialized
DEBUG - 2018-07-21 06:07:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 06:07:25 --> Input Class Initialized
INFO - 2018-07-21 06:07:25 --> Language Class Initialized
INFO - 2018-07-21 06:07:25 --> Language Class Initialized
INFO - 2018-07-21 06:07:25 --> Config Class Initialized
INFO - 2018-07-21 06:07:25 --> Loader Class Initialized
DEBUG - 2018-07-21 06:07:25 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-21 06:07:25 --> Helper loaded: url_helper
INFO - 2018-07-21 06:07:25 --> Helper loaded: form_helper
INFO - 2018-07-21 06:07:25 --> Helper loaded: date_helper
INFO - 2018-07-21 06:07:25 --> Helper loaded: util_helper
INFO - 2018-07-21 06:07:25 --> Helper loaded: text_helper
INFO - 2018-07-21 06:07:25 --> Helper loaded: string_helper
INFO - 2018-07-21 06:07:25 --> Database Driver Class Initialized
DEBUG - 2018-07-21 06:07:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-21 06:07:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-21 06:07:25 --> Email Class Initialized
INFO - 2018-07-21 06:07:25 --> Controller Class Initialized
DEBUG - 2018-07-21 06:07:25 --> Users MX_Controller Initialized
DEBUG - 2018-07-21 06:07:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-21 06:07:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-07-21 06:07:25 --> Helper loaded: file_helper
DEBUG - 2018-07-21 06:07:25 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-21 06:07:25 --> Login MX_Controller Initialized
INFO - 2018-07-21 06:07:25 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-21 06:07:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-21 06:07:25 --> Final output sent to browser
DEBUG - 2018-07-21 06:07:25 --> Total execution time: 0.6379
INFO - 2018-07-21 06:07:25 --> Config Class Initialized
INFO - 2018-07-21 06:07:25 --> Hooks Class Initialized
DEBUG - 2018-07-21 06:07:25 --> UTF-8 Support Enabled
INFO - 2018-07-21 06:07:25 --> Utf8 Class Initialized
INFO - 2018-07-21 06:07:25 --> URI Class Initialized
INFO - 2018-07-21 06:07:25 --> Router Class Initialized
INFO - 2018-07-21 06:07:25 --> Output Class Initialized
INFO - 2018-07-21 06:07:25 --> Security Class Initialized
DEBUG - 2018-07-21 06:07:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 06:07:26 --> Input Class Initialized
INFO - 2018-07-21 06:07:26 --> Language Class Initialized
INFO - 2018-07-21 06:07:26 --> Language Class Initialized
INFO - 2018-07-21 06:07:26 --> Config Class Initialized
INFO - 2018-07-21 06:07:26 --> Loader Class Initialized
DEBUG - 2018-07-21 06:07:26 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-21 06:07:26 --> Helper loaded: url_helper
INFO - 2018-07-21 06:07:26 --> Helper loaded: form_helper
INFO - 2018-07-21 06:07:26 --> Helper loaded: date_helper
INFO - 2018-07-21 06:07:26 --> Helper loaded: util_helper
INFO - 2018-07-21 06:07:26 --> Helper loaded: text_helper
INFO - 2018-07-21 06:07:26 --> Helper loaded: string_helper
INFO - 2018-07-21 06:07:26 --> Database Driver Class Initialized
DEBUG - 2018-07-21 06:07:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-21 06:07:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-21 06:07:26 --> Email Class Initialized
INFO - 2018-07-21 06:07:26 --> Controller Class Initialized
DEBUG - 2018-07-21 06:07:26 --> Users MX_Controller Initialized
DEBUG - 2018-07-21 06:07:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-21 06:07:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-07-21 06:07:26 --> Helper loaded: file_helper
DEBUG - 2018-07-21 06:07:26 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-21 06:07:26 --> Login MX_Controller Initialized
INFO - 2018-07-21 06:07:26 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-21 06:07:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-21 06:07:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-21 06:07:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-21 06:07:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-21 06:07:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-21 06:07:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-21 06:07:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-21 06:07:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/create_user.php
INFO - 2018-07-21 06:07:26 --> Final output sent to browser
DEBUG - 2018-07-21 06:07:26 --> Total execution time: 0.7106
INFO - 2018-07-21 06:07:28 --> Config Class Initialized
INFO - 2018-07-21 06:07:28 --> Hooks Class Initialized
DEBUG - 2018-07-21 06:07:29 --> UTF-8 Support Enabled
INFO - 2018-07-21 06:07:29 --> Utf8 Class Initialized
INFO - 2018-07-21 06:07:29 --> URI Class Initialized
INFO - 2018-07-21 06:07:29 --> Router Class Initialized
INFO - 2018-07-21 06:07:29 --> Output Class Initialized
INFO - 2018-07-21 06:07:29 --> Security Class Initialized
DEBUG - 2018-07-21 06:07:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 06:07:29 --> Input Class Initialized
INFO - 2018-07-21 06:07:29 --> Language Class Initialized
INFO - 2018-07-21 06:07:29 --> Language Class Initialized
INFO - 2018-07-21 06:07:29 --> Config Class Initialized
INFO - 2018-07-21 06:07:29 --> Loader Class Initialized
DEBUG - 2018-07-21 06:07:29 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-21 06:07:29 --> Helper loaded: url_helper
INFO - 2018-07-21 06:07:29 --> Helper loaded: form_helper
INFO - 2018-07-21 06:07:29 --> Helper loaded: date_helper
INFO - 2018-07-21 06:07:29 --> Helper loaded: util_helper
INFO - 2018-07-21 06:07:29 --> Helper loaded: text_helper
INFO - 2018-07-21 06:07:29 --> Helper loaded: string_helper
INFO - 2018-07-21 06:07:29 --> Database Driver Class Initialized
DEBUG - 2018-07-21 06:07:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-21 06:07:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-21 06:07:29 --> Email Class Initialized
INFO - 2018-07-21 06:07:29 --> Controller Class Initialized
DEBUG - 2018-07-21 06:07:29 --> Users MX_Controller Initialized
DEBUG - 2018-07-21 06:07:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-21 06:07:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-07-21 06:07:29 --> Helper loaded: file_helper
DEBUG - 2018-07-21 06:07:29 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-21 06:07:29 --> Login MX_Controller Initialized
INFO - 2018-07-21 06:07:29 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-21 06:07:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-21 06:07:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-21 06:07:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-21 06:07:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-21 06:07:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-21 06:07:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-21 06:07:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-21 06:07:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/create_user.php
INFO - 2018-07-21 06:07:29 --> Final output sent to browser
DEBUG - 2018-07-21 06:07:29 --> Total execution time: 0.6455
INFO - 2018-07-21 06:07:32 --> Config Class Initialized
INFO - 2018-07-21 06:07:32 --> Hooks Class Initialized
DEBUG - 2018-07-21 06:07:32 --> UTF-8 Support Enabled
INFO - 2018-07-21 06:07:32 --> Utf8 Class Initialized
INFO - 2018-07-21 06:07:32 --> URI Class Initialized
INFO - 2018-07-21 06:07:32 --> Router Class Initialized
INFO - 2018-07-21 06:07:32 --> Output Class Initialized
INFO - 2018-07-21 06:07:32 --> Security Class Initialized
DEBUG - 2018-07-21 06:07:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 06:07:32 --> Input Class Initialized
INFO - 2018-07-21 06:07:32 --> Language Class Initialized
INFO - 2018-07-21 06:07:32 --> Language Class Initialized
INFO - 2018-07-21 06:07:32 --> Config Class Initialized
INFO - 2018-07-21 06:07:32 --> Loader Class Initialized
DEBUG - 2018-07-21 06:07:32 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-21 06:07:32 --> Helper loaded: url_helper
INFO - 2018-07-21 06:07:32 --> Helper loaded: form_helper
INFO - 2018-07-21 06:07:32 --> Helper loaded: date_helper
INFO - 2018-07-21 06:07:32 --> Helper loaded: util_helper
INFO - 2018-07-21 06:07:32 --> Helper loaded: text_helper
INFO - 2018-07-21 06:07:32 --> Helper loaded: string_helper
INFO - 2018-07-21 06:07:32 --> Database Driver Class Initialized
DEBUG - 2018-07-21 06:07:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-21 06:07:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-21 06:07:32 --> Email Class Initialized
INFO - 2018-07-21 06:07:32 --> Controller Class Initialized
DEBUG - 2018-07-21 06:07:32 --> Users MX_Controller Initialized
DEBUG - 2018-07-21 06:07:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-21 06:07:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-07-21 06:07:32 --> Helper loaded: file_helper
DEBUG - 2018-07-21 06:07:32 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-21 06:07:32 --> Login MX_Controller Initialized
INFO - 2018-07-21 06:07:32 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-21 06:07:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-21 06:07:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-21 06:07:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-21 06:07:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-21 06:07:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-21 06:07:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-21 06:07:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/users.php
INFO - 2018-07-21 06:07:33 --> Final output sent to browser
DEBUG - 2018-07-21 06:07:33 --> Total execution time: 0.6394
INFO - 2018-07-21 06:07:33 --> Config Class Initialized
INFO - 2018-07-21 06:07:33 --> Hooks Class Initialized
DEBUG - 2018-07-21 06:07:33 --> UTF-8 Support Enabled
INFO - 2018-07-21 06:07:33 --> Utf8 Class Initialized
INFO - 2018-07-21 06:07:33 --> URI Class Initialized
INFO - 2018-07-21 06:07:33 --> Router Class Initialized
INFO - 2018-07-21 06:07:33 --> Output Class Initialized
INFO - 2018-07-21 06:07:33 --> Security Class Initialized
DEBUG - 2018-07-21 06:07:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 06:07:33 --> Input Class Initialized
INFO - 2018-07-21 06:07:33 --> Language Class Initialized
INFO - 2018-07-21 06:07:33 --> Language Class Initialized
INFO - 2018-07-21 06:07:33 --> Config Class Initialized
INFO - 2018-07-21 06:07:33 --> Loader Class Initialized
DEBUG - 2018-07-21 06:07:33 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-21 06:07:33 --> Helper loaded: url_helper
INFO - 2018-07-21 06:07:33 --> Helper loaded: form_helper
INFO - 2018-07-21 06:07:33 --> Helper loaded: date_helper
INFO - 2018-07-21 06:07:33 --> Helper loaded: util_helper
INFO - 2018-07-21 06:07:33 --> Helper loaded: text_helper
INFO - 2018-07-21 06:07:33 --> Helper loaded: string_helper
INFO - 2018-07-21 06:07:33 --> Database Driver Class Initialized
DEBUG - 2018-07-21 06:07:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-21 06:07:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-21 06:07:33 --> Email Class Initialized
INFO - 2018-07-21 06:07:33 --> Controller Class Initialized
DEBUG - 2018-07-21 06:07:33 --> Users MX_Controller Initialized
DEBUG - 2018-07-21 06:07:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-21 06:07:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-07-21 06:07:33 --> Helper loaded: file_helper
DEBUG - 2018-07-21 06:07:33 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-21 06:07:33 --> Login MX_Controller Initialized
INFO - 2018-07-21 06:07:33 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-21 06:07:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-21 06:07:33 --> Final output sent to browser
DEBUG - 2018-07-21 06:07:33 --> Total execution time: 0.6884
