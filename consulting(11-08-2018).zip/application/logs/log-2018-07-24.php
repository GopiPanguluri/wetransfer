<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-07-24 21:32:39 --> Config Class Initialized
INFO - 2018-07-24 21:32:39 --> Hooks Class Initialized
DEBUG - 2018-07-24 21:32:39 --> UTF-8 Support Enabled
INFO - 2018-07-24 21:32:39 --> Utf8 Class Initialized
INFO - 2018-07-24 21:32:40 --> URI Class Initialized
INFO - 2018-07-24 21:32:40 --> Router Class Initialized
INFO - 2018-07-24 21:32:40 --> Output Class Initialized
INFO - 2018-07-24 21:32:40 --> Security Class Initialized
DEBUG - 2018-07-24 21:32:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 21:32:40 --> Input Class Initialized
INFO - 2018-07-24 21:32:40 --> Language Class Initialized
INFO - 2018-07-24 21:32:40 --> Language Class Initialized
INFO - 2018-07-24 21:32:40 --> Config Class Initialized
INFO - 2018-07-24 21:32:41 --> Loader Class Initialized
DEBUG - 2018-07-24 21:32:41 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-24 21:32:41 --> Helper loaded: url_helper
INFO - 2018-07-24 21:32:41 --> Helper loaded: form_helper
INFO - 2018-07-24 21:32:41 --> Helper loaded: date_helper
INFO - 2018-07-24 21:32:41 --> Helper loaded: util_helper
INFO - 2018-07-24 21:32:41 --> Helper loaded: text_helper
INFO - 2018-07-24 21:32:42 --> Helper loaded: string_helper
INFO - 2018-07-24 21:32:43 --> Database Driver Class Initialized
DEBUG - 2018-07-24 21:32:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-24 21:32:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-24 21:32:45 --> Email Class Initialized
INFO - 2018-07-24 21:32:45 --> Controller Class Initialized
DEBUG - 2018-07-24 21:32:45 --> Home MX_Controller Initialized
INFO - 2018-07-24 21:32:45 --> Config Class Initialized
INFO - 2018-07-24 21:32:45 --> Hooks Class Initialized
DEBUG - 2018-07-24 21:32:45 --> UTF-8 Support Enabled
DEBUG - 2018-07-24 21:32:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-07-24 21:32:45 --> Utf8 Class Initialized
INFO - 2018-07-24 21:32:45 --> URI Class Initialized
INFO - 2018-07-24 21:32:45 --> Router Class Initialized
INFO - 2018-07-24 21:32:45 --> Output Class Initialized
INFO - 2018-07-24 21:32:45 --> Security Class Initialized
DEBUG - 2018-07-24 21:32:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 21:32:45 --> Input Class Initialized
INFO - 2018-07-24 21:32:45 --> Language Class Initialized
INFO - 2018-07-24 21:32:45 --> Language Class Initialized
INFO - 2018-07-24 21:32:45 --> Config Class Initialized
INFO - 2018-07-24 21:32:45 --> Loader Class Initialized
DEBUG - 2018-07-24 21:32:45 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-24 21:32:45 --> Helper loaded: url_helper
INFO - 2018-07-24 21:32:45 --> Helper loaded: form_helper
INFO - 2018-07-24 21:32:45 --> Helper loaded: date_helper
INFO - 2018-07-24 21:32:45 --> Helper loaded: util_helper
INFO - 2018-07-24 21:32:45 --> Helper loaded: text_helper
INFO - 2018-07-24 21:32:45 --> Helper loaded: string_helper
INFO - 2018-07-24 21:32:45 --> Database Driver Class Initialized
DEBUG - 2018-07-24 21:32:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-24 21:32:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-24 21:32:46 --> Email Class Initialized
INFO - 2018-07-24 21:32:46 --> Controller Class Initialized
DEBUG - 2018-07-24 21:32:46 --> Admin MX_Controller Initialized
INFO - 2018-07-24 21:32:46 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-24 21:32:46 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-24 21:32:46 --> Login MX_Controller Initialized
DEBUG - 2018-07-24 21:32:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-24 21:32:46 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-24 21:32:46 --> Login MX_Controller Initialized
INFO - 2018-07-24 21:32:46 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-24 21:32:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-24 21:32:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-24 21:32:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-24 21:32:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/login.php
DEBUG - 2018-07-24 21:32:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/logins/login.php
INFO - 2018-07-24 21:32:48 --> Config Class Initialized
INFO - 2018-07-24 21:32:48 --> Hooks Class Initialized
DEBUG - 2018-07-24 21:32:48 --> UTF-8 Support Enabled
INFO - 2018-07-24 21:32:48 --> Utf8 Class Initialized
INFO - 2018-07-24 21:32:48 --> URI Class Initialized
INFO - 2018-07-24 21:32:48 --> Router Class Initialized
INFO - 2018-07-24 21:32:48 --> Output Class Initialized
INFO - 2018-07-24 21:32:48 --> Security Class Initialized
DEBUG - 2018-07-24 21:32:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 21:32:48 --> Input Class Initialized
INFO - 2018-07-24 21:32:48 --> Language Class Initialized
INFO - 2018-07-24 21:32:48 --> Language Class Initialized
INFO - 2018-07-24 21:32:48 --> Config Class Initialized
INFO - 2018-07-24 21:32:48 --> Loader Class Initialized
DEBUG - 2018-07-24 21:32:48 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-24 21:32:48 --> Helper loaded: url_helper
INFO - 2018-07-24 21:32:48 --> Helper loaded: form_helper
INFO - 2018-07-24 21:32:48 --> Helper loaded: date_helper
INFO - 2018-07-24 21:32:48 --> Helper loaded: util_helper
INFO - 2018-07-24 21:32:48 --> Helper loaded: text_helper
INFO - 2018-07-24 21:32:48 --> Helper loaded: string_helper
INFO - 2018-07-24 21:32:48 --> Database Driver Class Initialized
DEBUG - 2018-07-24 21:32:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-24 21:32:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-24 21:32:48 --> Email Class Initialized
INFO - 2018-07-24 21:32:48 --> Controller Class Initialized
DEBUG - 2018-07-24 21:32:48 --> Admin MX_Controller Initialized
INFO - 2018-07-24 21:32:48 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-24 21:32:48 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-24 21:32:48 --> Login MX_Controller Initialized
DEBUG - 2018-07-24 21:32:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-24 21:32:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-24 21:32:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/logins/login.php
INFO - 2018-07-24 21:32:49 --> Config Class Initialized
INFO - 2018-07-24 21:32:49 --> Hooks Class Initialized
DEBUG - 2018-07-24 21:32:49 --> UTF-8 Support Enabled
INFO - 2018-07-24 21:32:49 --> Utf8 Class Initialized
INFO - 2018-07-24 21:32:49 --> URI Class Initialized
INFO - 2018-07-24 21:32:49 --> Router Class Initialized
INFO - 2018-07-24 21:32:49 --> Output Class Initialized
INFO - 2018-07-24 21:32:49 --> Security Class Initialized
DEBUG - 2018-07-24 21:32:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 21:32:49 --> Input Class Initialized
INFO - 2018-07-24 21:32:49 --> Language Class Initialized
ERROR - 2018-07-24 21:32:49 --> 404 Page Not Found: /index
INFO - 2018-07-24 21:32:52 --> Config Class Initialized
INFO - 2018-07-24 21:32:52 --> Hooks Class Initialized
DEBUG - 2018-07-24 21:32:52 --> UTF-8 Support Enabled
INFO - 2018-07-24 21:32:52 --> Utf8 Class Initialized
INFO - 2018-07-24 21:32:52 --> URI Class Initialized
INFO - 2018-07-24 21:32:52 --> Router Class Initialized
INFO - 2018-07-24 21:32:52 --> Output Class Initialized
INFO - 2018-07-24 21:32:52 --> Security Class Initialized
DEBUG - 2018-07-24 21:32:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 21:32:52 --> Input Class Initialized
INFO - 2018-07-24 21:32:52 --> Language Class Initialized
ERROR - 2018-07-24 21:32:52 --> 404 Page Not Found: /index
INFO - 2018-07-24 21:36:15 --> Config Class Initialized
INFO - 2018-07-24 21:36:15 --> Hooks Class Initialized
DEBUG - 2018-07-24 21:36:15 --> UTF-8 Support Enabled
INFO - 2018-07-24 21:36:15 --> Utf8 Class Initialized
INFO - 2018-07-24 21:36:15 --> URI Class Initialized
INFO - 2018-07-24 21:36:15 --> Router Class Initialized
INFO - 2018-07-24 21:36:15 --> Output Class Initialized
INFO - 2018-07-24 21:36:15 --> Security Class Initialized
DEBUG - 2018-07-24 21:36:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 21:36:15 --> Input Class Initialized
INFO - 2018-07-24 21:36:15 --> Language Class Initialized
INFO - 2018-07-24 21:36:15 --> Language Class Initialized
INFO - 2018-07-24 21:36:15 --> Config Class Initialized
INFO - 2018-07-24 21:36:15 --> Loader Class Initialized
DEBUG - 2018-07-24 21:36:15 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-24 21:36:15 --> Helper loaded: url_helper
INFO - 2018-07-24 21:36:15 --> Helper loaded: form_helper
INFO - 2018-07-24 21:36:15 --> Helper loaded: date_helper
INFO - 2018-07-24 21:36:15 --> Helper loaded: util_helper
INFO - 2018-07-24 21:36:15 --> Helper loaded: text_helper
INFO - 2018-07-24 21:36:15 --> Helper loaded: string_helper
INFO - 2018-07-24 21:36:15 --> Database Driver Class Initialized
DEBUG - 2018-07-24 21:36:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-24 21:36:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-24 21:36:15 --> Email Class Initialized
INFO - 2018-07-24 21:36:15 --> Controller Class Initialized
DEBUG - 2018-07-24 21:36:15 --> Login MX_Controller Initialized
INFO - 2018-07-24 21:36:15 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-24 21:36:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-24 21:36:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-24 21:36:15 --> Email starts for admin@colin.com fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-07-24 21:36:15 --> User session created for 1
INFO - 2018-07-24 21:36:16 --> Login status admin@colin.com - success
INFO - 2018-07-24 21:36:16 --> Final output sent to browser
DEBUG - 2018-07-24 21:36:16 --> Total execution time: 0.5660
INFO - 2018-07-24 21:36:16 --> Config Class Initialized
INFO - 2018-07-24 21:36:16 --> Hooks Class Initialized
DEBUG - 2018-07-24 21:36:16 --> UTF-8 Support Enabled
INFO - 2018-07-24 21:36:16 --> Utf8 Class Initialized
INFO - 2018-07-24 21:36:16 --> URI Class Initialized
INFO - 2018-07-24 21:36:16 --> Router Class Initialized
INFO - 2018-07-24 21:36:16 --> Output Class Initialized
INFO - 2018-07-24 21:36:16 --> Security Class Initialized
DEBUG - 2018-07-24 21:36:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 21:36:16 --> Input Class Initialized
INFO - 2018-07-24 21:36:16 --> Language Class Initialized
INFO - 2018-07-24 21:36:16 --> Language Class Initialized
INFO - 2018-07-24 21:36:16 --> Config Class Initialized
INFO - 2018-07-24 21:36:16 --> Loader Class Initialized
DEBUG - 2018-07-24 21:36:16 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-24 21:36:16 --> Helper loaded: url_helper
INFO - 2018-07-24 21:36:16 --> Helper loaded: form_helper
INFO - 2018-07-24 21:36:16 --> Helper loaded: date_helper
INFO - 2018-07-24 21:36:16 --> Helper loaded: util_helper
INFO - 2018-07-24 21:36:16 --> Helper loaded: text_helper
INFO - 2018-07-24 21:36:16 --> Helper loaded: string_helper
INFO - 2018-07-24 21:36:16 --> Database Driver Class Initialized
DEBUG - 2018-07-24 21:36:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-24 21:36:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-24 21:36:16 --> Email Class Initialized
INFO - 2018-07-24 21:36:16 --> Controller Class Initialized
DEBUG - 2018-07-24 21:36:16 --> Admin MX_Controller Initialized
INFO - 2018-07-24 21:36:16 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-24 21:36:16 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-24 21:36:16 --> Login MX_Controller Initialized
DEBUG - 2018-07-24 21:36:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-24 21:36:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-24 21:36:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-24 21:36:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-24 21:36:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-24 21:36:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-24 21:36:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-24 21:36:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/dashboard.php
INFO - 2018-07-24 21:36:16 --> Final output sent to browser
DEBUG - 2018-07-24 21:36:16 --> Total execution time: 0.6527
INFO - 2018-07-24 21:36:16 --> Config Class Initialized
INFO - 2018-07-24 21:36:16 --> Hooks Class Initialized
DEBUG - 2018-07-24 21:36:17 --> UTF-8 Support Enabled
INFO - 2018-07-24 21:36:17 --> Utf8 Class Initialized
INFO - 2018-07-24 21:36:17 --> URI Class Initialized
INFO - 2018-07-24 21:36:17 --> Router Class Initialized
INFO - 2018-07-24 21:36:17 --> Output Class Initialized
INFO - 2018-07-24 21:36:17 --> Security Class Initialized
DEBUG - 2018-07-24 21:36:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 21:36:17 --> Input Class Initialized
INFO - 2018-07-24 21:36:17 --> Language Class Initialized
ERROR - 2018-07-24 21:36:17 --> 404 Page Not Found: /index
INFO - 2018-07-24 21:36:19 --> Config Class Initialized
INFO - 2018-07-24 21:36:19 --> Hooks Class Initialized
DEBUG - 2018-07-24 21:36:19 --> UTF-8 Support Enabled
INFO - 2018-07-24 21:36:19 --> Utf8 Class Initialized
INFO - 2018-07-24 21:36:19 --> URI Class Initialized
INFO - 2018-07-24 21:36:19 --> Router Class Initialized
INFO - 2018-07-24 21:36:19 --> Output Class Initialized
INFO - 2018-07-24 21:36:19 --> Security Class Initialized
DEBUG - 2018-07-24 21:36:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 21:36:19 --> Input Class Initialized
INFO - 2018-07-24 21:36:19 --> Language Class Initialized
ERROR - 2018-07-24 21:36:19 --> 404 Page Not Found: /index
INFO - 2018-07-24 21:36:20 --> Config Class Initialized
INFO - 2018-07-24 21:36:20 --> Hooks Class Initialized
DEBUG - 2018-07-24 21:36:20 --> UTF-8 Support Enabled
INFO - 2018-07-24 21:36:20 --> Utf8 Class Initialized
INFO - 2018-07-24 21:36:20 --> URI Class Initialized
INFO - 2018-07-24 21:36:20 --> Router Class Initialized
INFO - 2018-07-24 21:36:20 --> Output Class Initialized
INFO - 2018-07-24 21:36:20 --> Security Class Initialized
DEBUG - 2018-07-24 21:36:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 21:36:20 --> Input Class Initialized
INFO - 2018-07-24 21:36:20 --> Language Class Initialized
INFO - 2018-07-24 21:36:20 --> Language Class Initialized
INFO - 2018-07-24 21:36:20 --> Config Class Initialized
INFO - 2018-07-24 21:36:20 --> Loader Class Initialized
DEBUG - 2018-07-24 21:36:20 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-24 21:36:20 --> Helper loaded: url_helper
INFO - 2018-07-24 21:36:20 --> Helper loaded: form_helper
INFO - 2018-07-24 21:36:20 --> Helper loaded: date_helper
INFO - 2018-07-24 21:36:20 --> Helper loaded: util_helper
INFO - 2018-07-24 21:36:20 --> Helper loaded: text_helper
INFO - 2018-07-24 21:36:20 --> Helper loaded: string_helper
INFO - 2018-07-24 21:36:20 --> Database Driver Class Initialized
DEBUG - 2018-07-24 21:36:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-24 21:36:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-24 21:36:21 --> Email Class Initialized
INFO - 2018-07-24 21:36:21 --> Controller Class Initialized
DEBUG - 2018-07-24 21:36:21 --> Login MX_Controller Initialized
INFO - 2018-07-24 21:36:21 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-24 21:36:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-24 21:36:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-24 21:36:21 --> Email starts for user@colin.com fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-07-24 21:36:21 --> User session created for 4
INFO - 2018-07-24 21:36:21 --> Login status user@colin.com - success
INFO - 2018-07-24 21:36:21 --> Final output sent to browser
DEBUG - 2018-07-24 21:36:21 --> Total execution time: 0.4249
INFO - 2018-07-24 21:36:21 --> Config Class Initialized
INFO - 2018-07-24 21:36:21 --> Hooks Class Initialized
DEBUG - 2018-07-24 21:36:21 --> UTF-8 Support Enabled
INFO - 2018-07-24 21:36:21 --> Utf8 Class Initialized
INFO - 2018-07-24 21:36:21 --> URI Class Initialized
INFO - 2018-07-24 21:36:21 --> Router Class Initialized
INFO - 2018-07-24 21:36:21 --> Output Class Initialized
INFO - 2018-07-24 21:36:21 --> Security Class Initialized
DEBUG - 2018-07-24 21:36:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 21:36:21 --> Input Class Initialized
INFO - 2018-07-24 21:36:21 --> Language Class Initialized
INFO - 2018-07-24 21:36:21 --> Language Class Initialized
INFO - 2018-07-24 21:36:21 --> Config Class Initialized
INFO - 2018-07-24 21:36:21 --> Loader Class Initialized
DEBUG - 2018-07-24 21:36:21 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-24 21:36:21 --> Helper loaded: url_helper
INFO - 2018-07-24 21:36:21 --> Helper loaded: form_helper
INFO - 2018-07-24 21:36:21 --> Helper loaded: date_helper
INFO - 2018-07-24 21:36:21 --> Helper loaded: util_helper
INFO - 2018-07-24 21:36:21 --> Helper loaded: text_helper
INFO - 2018-07-24 21:36:21 --> Helper loaded: string_helper
INFO - 2018-07-24 21:36:21 --> Database Driver Class Initialized
DEBUG - 2018-07-24 21:36:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-24 21:36:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-24 21:36:21 --> Email Class Initialized
INFO - 2018-07-24 21:36:21 --> Controller Class Initialized
DEBUG - 2018-07-24 21:36:21 --> Home MX_Controller Initialized
DEBUG - 2018-07-24 21:36:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-24 21:36:21 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-24 21:36:21 --> Login MX_Controller Initialized
INFO - 2018-07-24 21:36:21 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-24 21:36:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-24 21:36:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-24 21:36:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-07-24 21:36:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-07-24 21:36:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-07-24 21:36:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-07-24 21:36:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-07-24 21:36:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-07-24 21:36:22 --> Final output sent to browser
DEBUG - 2018-07-24 21:36:22 --> Total execution time: 1.4530
INFO - 2018-07-24 21:36:23 --> Config Class Initialized
INFO - 2018-07-24 21:36:23 --> Hooks Class Initialized
DEBUG - 2018-07-24 21:36:23 --> UTF-8 Support Enabled
INFO - 2018-07-24 21:36:23 --> Utf8 Class Initialized
INFO - 2018-07-24 21:36:23 --> URI Class Initialized
INFO - 2018-07-24 21:36:23 --> Router Class Initialized
INFO - 2018-07-24 21:36:23 --> Output Class Initialized
INFO - 2018-07-24 21:36:23 --> Config Class Initialized
INFO - 2018-07-24 21:36:23 --> Security Class Initialized
INFO - 2018-07-24 21:36:23 --> Hooks Class Initialized
DEBUG - 2018-07-24 21:36:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 21:36:23 --> Input Class Initialized
DEBUG - 2018-07-24 21:36:23 --> UTF-8 Support Enabled
INFO - 2018-07-24 21:36:23 --> Utf8 Class Initialized
INFO - 2018-07-24 21:36:23 --> Language Class Initialized
ERROR - 2018-07-24 21:36:23 --> 404 Page Not Found: /index
INFO - 2018-07-24 21:36:23 --> URI Class Initialized
INFO - 2018-07-24 21:36:23 --> Router Class Initialized
INFO - 2018-07-24 21:36:23 --> Output Class Initialized
INFO - 2018-07-24 21:36:23 --> Security Class Initialized
DEBUG - 2018-07-24 21:36:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 21:36:23 --> Input Class Initialized
INFO - 2018-07-24 21:36:23 --> Language Class Initialized
ERROR - 2018-07-24 21:36:23 --> 404 Page Not Found: /index
INFO - 2018-07-24 21:36:24 --> Config Class Initialized
INFO - 2018-07-24 21:36:24 --> Hooks Class Initialized
DEBUG - 2018-07-24 21:36:24 --> UTF-8 Support Enabled
INFO - 2018-07-24 21:36:24 --> Utf8 Class Initialized
INFO - 2018-07-24 21:36:24 --> URI Class Initialized
INFO - 2018-07-24 21:36:24 --> Router Class Initialized
INFO - 2018-07-24 21:36:24 --> Output Class Initialized
INFO - 2018-07-24 21:36:24 --> Security Class Initialized
DEBUG - 2018-07-24 21:36:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 21:36:24 --> Input Class Initialized
INFO - 2018-07-24 21:36:24 --> Language Class Initialized
ERROR - 2018-07-24 21:36:24 --> 404 Page Not Found: /index
INFO - 2018-07-24 21:36:24 --> Config Class Initialized
INFO - 2018-07-24 21:36:24 --> Hooks Class Initialized
DEBUG - 2018-07-24 21:36:24 --> UTF-8 Support Enabled
INFO - 2018-07-24 21:36:24 --> Utf8 Class Initialized
INFO - 2018-07-24 21:36:24 --> URI Class Initialized
INFO - 2018-07-24 21:36:24 --> Router Class Initialized
INFO - 2018-07-24 21:36:24 --> Output Class Initialized
INFO - 2018-07-24 21:36:24 --> Security Class Initialized
DEBUG - 2018-07-24 21:36:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 21:36:24 --> Input Class Initialized
INFO - 2018-07-24 21:36:24 --> Language Class Initialized
ERROR - 2018-07-24 21:36:24 --> 404 Page Not Found: /index
INFO - 2018-07-24 21:36:26 --> Config Class Initialized
INFO - 2018-07-24 21:36:26 --> Hooks Class Initialized
DEBUG - 2018-07-24 21:36:26 --> UTF-8 Support Enabled
INFO - 2018-07-24 21:36:26 --> Utf8 Class Initialized
INFO - 2018-07-24 21:36:26 --> URI Class Initialized
INFO - 2018-07-24 21:36:26 --> Router Class Initialized
INFO - 2018-07-24 21:36:26 --> Output Class Initialized
INFO - 2018-07-24 21:36:26 --> Security Class Initialized
DEBUG - 2018-07-24 21:36:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 21:36:26 --> Input Class Initialized
INFO - 2018-07-24 21:36:26 --> Language Class Initialized
ERROR - 2018-07-24 21:36:26 --> 404 Page Not Found: /index
INFO - 2018-07-24 21:36:26 --> Config Class Initialized
INFO - 2018-07-24 21:36:26 --> Hooks Class Initialized
DEBUG - 2018-07-24 21:36:26 --> UTF-8 Support Enabled
INFO - 2018-07-24 21:36:26 --> Utf8 Class Initialized
INFO - 2018-07-24 21:36:26 --> URI Class Initialized
INFO - 2018-07-24 21:36:26 --> Router Class Initialized
INFO - 2018-07-24 21:36:26 --> Output Class Initialized
INFO - 2018-07-24 21:36:26 --> Security Class Initialized
DEBUG - 2018-07-24 21:36:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 21:36:26 --> Input Class Initialized
INFO - 2018-07-24 21:36:26 --> Language Class Initialized
ERROR - 2018-07-24 21:36:26 --> 404 Page Not Found: /index
INFO - 2018-07-24 21:36:27 --> Config Class Initialized
INFO - 2018-07-24 21:36:27 --> Hooks Class Initialized
DEBUG - 2018-07-24 21:36:27 --> UTF-8 Support Enabled
INFO - 2018-07-24 21:36:27 --> Utf8 Class Initialized
INFO - 2018-07-24 21:36:27 --> URI Class Initialized
INFO - 2018-07-24 21:36:27 --> Router Class Initialized
INFO - 2018-07-24 21:36:27 --> Output Class Initialized
INFO - 2018-07-24 21:36:27 --> Security Class Initialized
DEBUG - 2018-07-24 21:36:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 21:36:27 --> Input Class Initialized
INFO - 2018-07-24 21:36:27 --> Language Class Initialized
ERROR - 2018-07-24 21:36:27 --> 404 Page Not Found: /index
INFO - 2018-07-24 22:54:42 --> Config Class Initialized
INFO - 2018-07-24 22:54:42 --> Hooks Class Initialized
DEBUG - 2018-07-24 22:54:42 --> UTF-8 Support Enabled
INFO - 2018-07-24 22:54:42 --> Utf8 Class Initialized
INFO - 2018-07-24 22:54:42 --> URI Class Initialized
INFO - 2018-07-24 22:54:42 --> Router Class Initialized
INFO - 2018-07-24 22:54:42 --> Output Class Initialized
INFO - 2018-07-24 22:54:42 --> Security Class Initialized
DEBUG - 2018-07-24 22:54:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 22:54:42 --> Input Class Initialized
INFO - 2018-07-24 22:54:42 --> Language Class Initialized
INFO - 2018-07-24 22:54:42 --> Language Class Initialized
INFO - 2018-07-24 22:54:42 --> Config Class Initialized
INFO - 2018-07-24 22:54:42 --> Loader Class Initialized
DEBUG - 2018-07-24 22:54:42 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-24 22:54:42 --> Helper loaded: url_helper
INFO - 2018-07-24 22:54:42 --> Helper loaded: form_helper
INFO - 2018-07-24 22:54:42 --> Helper loaded: date_helper
INFO - 2018-07-24 22:54:42 --> Helper loaded: util_helper
INFO - 2018-07-24 22:54:42 --> Helper loaded: text_helper
INFO - 2018-07-24 22:54:42 --> Helper loaded: string_helper
INFO - 2018-07-24 22:54:42 --> Database Driver Class Initialized
DEBUG - 2018-07-24 22:54:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-24 22:54:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-24 22:54:42 --> Email Class Initialized
INFO - 2018-07-24 22:54:42 --> Controller Class Initialized
DEBUG - 2018-07-24 22:54:42 --> Home MX_Controller Initialized
DEBUG - 2018-07-24 22:54:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-24 22:54:43 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-24 22:54:43 --> Login MX_Controller Initialized
INFO - 2018-07-24 22:54:43 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-24 22:54:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-24 22:54:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-24 22:54:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-07-24 22:54:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-07-24 22:54:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-07-24 22:54:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-07-24 22:54:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-07-24 22:54:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-07-24 22:54:43 --> Final output sent to browser
DEBUG - 2018-07-24 22:54:43 --> Total execution time: 1.2638
INFO - 2018-07-24 22:54:43 --> Config Class Initialized
INFO - 2018-07-24 22:54:43 --> Config Class Initialized
INFO - 2018-07-24 22:54:43 --> Config Class Initialized
INFO - 2018-07-24 22:54:43 --> Config Class Initialized
INFO - 2018-07-24 22:54:43 --> Config Class Initialized
INFO - 2018-07-24 22:54:43 --> Hooks Class Initialized
INFO - 2018-07-24 22:54:43 --> Hooks Class Initialized
INFO - 2018-07-24 22:54:43 --> Hooks Class Initialized
INFO - 2018-07-24 22:54:43 --> Hooks Class Initialized
INFO - 2018-07-24 22:54:43 --> Hooks Class Initialized
DEBUG - 2018-07-24 22:54:43 --> UTF-8 Support Enabled
DEBUG - 2018-07-24 22:54:43 --> UTF-8 Support Enabled
DEBUG - 2018-07-24 22:54:43 --> UTF-8 Support Enabled
DEBUG - 2018-07-24 22:54:43 --> UTF-8 Support Enabled
DEBUG - 2018-07-24 22:54:43 --> UTF-8 Support Enabled
INFO - 2018-07-24 22:54:43 --> Config Class Initialized
INFO - 2018-07-24 22:54:43 --> Hooks Class Initialized
INFO - 2018-07-24 22:54:43 --> Utf8 Class Initialized
INFO - 2018-07-24 22:54:43 --> Utf8 Class Initialized
INFO - 2018-07-24 22:54:43 --> Utf8 Class Initialized
INFO - 2018-07-24 22:54:43 --> Utf8 Class Initialized
INFO - 2018-07-24 22:54:43 --> Utf8 Class Initialized
INFO - 2018-07-24 22:54:43 --> URI Class Initialized
INFO - 2018-07-24 22:54:43 --> URI Class Initialized
DEBUG - 2018-07-24 22:54:43 --> UTF-8 Support Enabled
INFO - 2018-07-24 22:54:43 --> URI Class Initialized
INFO - 2018-07-24 22:54:43 --> URI Class Initialized
INFO - 2018-07-24 22:54:43 --> URI Class Initialized
INFO - 2018-07-24 22:54:43 --> Utf8 Class Initialized
INFO - 2018-07-24 22:54:43 --> Router Class Initialized
INFO - 2018-07-24 22:54:43 --> Router Class Initialized
INFO - 2018-07-24 22:54:43 --> Router Class Initialized
INFO - 2018-07-24 22:54:43 --> Router Class Initialized
INFO - 2018-07-24 22:54:43 --> Router Class Initialized
INFO - 2018-07-24 22:54:43 --> URI Class Initialized
INFO - 2018-07-24 22:54:43 --> Output Class Initialized
INFO - 2018-07-24 22:54:43 --> Output Class Initialized
INFO - 2018-07-24 22:54:43 --> Output Class Initialized
INFO - 2018-07-24 22:54:43 --> Output Class Initialized
INFO - 2018-07-24 22:54:43 --> Security Class Initialized
INFO - 2018-07-24 22:54:43 --> Router Class Initialized
INFO - 2018-07-24 22:54:43 --> Security Class Initialized
INFO - 2018-07-24 22:54:43 --> Output Class Initialized
INFO - 2018-07-24 22:54:43 --> Security Class Initialized
INFO - 2018-07-24 22:54:43 --> Security Class Initialized
INFO - 2018-07-24 22:54:43 --> Output Class Initialized
DEBUG - 2018-07-24 22:54:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-07-24 22:54:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 22:54:43 --> Security Class Initialized
DEBUG - 2018-07-24 22:54:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-07-24 22:54:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 22:54:43 --> Input Class Initialized
INFO - 2018-07-24 22:54:43 --> Input Class Initialized
INFO - 2018-07-24 22:54:43 --> Security Class Initialized
INFO - 2018-07-24 22:54:43 --> Input Class Initialized
INFO - 2018-07-24 22:54:43 --> Input Class Initialized
DEBUG - 2018-07-24 22:54:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 22:54:43 --> Language Class Initialized
DEBUG - 2018-07-24 22:54:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 22:54:43 --> Language Class Initialized
INFO - 2018-07-24 22:54:43 --> Input Class Initialized
INFO - 2018-07-24 22:54:43 --> Language Class Initialized
INFO - 2018-07-24 22:54:43 --> Language Class Initialized
INFO - 2018-07-24 22:54:43 --> Input Class Initialized
ERROR - 2018-07-24 22:54:43 --> 404 Page Not Found: /index
ERROR - 2018-07-24 22:54:43 --> 404 Page Not Found: /index
ERROR - 2018-07-24 22:54:43 --> 404 Page Not Found: /index
ERROR - 2018-07-24 22:54:43 --> 404 Page Not Found: /index
INFO - 2018-07-24 22:54:43 --> Language Class Initialized
INFO - 2018-07-24 22:54:43 --> Language Class Initialized
ERROR - 2018-07-24 22:54:43 --> 404 Page Not Found: /index
ERROR - 2018-07-24 22:54:43 --> 404 Page Not Found: /index
INFO - 2018-07-24 22:54:43 --> Config Class Initialized
INFO - 2018-07-24 22:54:43 --> Config Class Initialized
INFO - 2018-07-24 22:54:43 --> Config Class Initialized
INFO - 2018-07-24 22:54:43 --> Hooks Class Initialized
INFO - 2018-07-24 22:54:43 --> Hooks Class Initialized
INFO - 2018-07-24 22:54:43 --> Hooks Class Initialized
DEBUG - 2018-07-24 22:54:43 --> UTF-8 Support Enabled
DEBUG - 2018-07-24 22:54:43 --> UTF-8 Support Enabled
DEBUG - 2018-07-24 22:54:43 --> UTF-8 Support Enabled
INFO - 2018-07-24 22:54:43 --> Utf8 Class Initialized
INFO - 2018-07-24 22:54:43 --> Utf8 Class Initialized
INFO - 2018-07-24 22:54:43 --> Utf8 Class Initialized
INFO - 2018-07-24 22:54:43 --> URI Class Initialized
INFO - 2018-07-24 22:54:43 --> URI Class Initialized
INFO - 2018-07-24 22:54:43 --> URI Class Initialized
INFO - 2018-07-24 22:54:43 --> Router Class Initialized
INFO - 2018-07-24 22:54:43 --> Router Class Initialized
INFO - 2018-07-24 22:54:43 --> Router Class Initialized
INFO - 2018-07-24 22:54:43 --> Output Class Initialized
INFO - 2018-07-24 22:54:43 --> Output Class Initialized
INFO - 2018-07-24 22:54:43 --> Output Class Initialized
INFO - 2018-07-24 22:54:43 --> Security Class Initialized
INFO - 2018-07-24 22:54:43 --> Security Class Initialized
INFO - 2018-07-24 22:54:43 --> Security Class Initialized
DEBUG - 2018-07-24 22:54:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-07-24 22:54:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-07-24 22:54:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 22:54:43 --> Input Class Initialized
INFO - 2018-07-24 22:54:43 --> Input Class Initialized
INFO - 2018-07-24 22:54:43 --> Input Class Initialized
INFO - 2018-07-24 22:54:43 --> Language Class Initialized
INFO - 2018-07-24 22:54:43 --> Language Class Initialized
INFO - 2018-07-24 22:54:43 --> Language Class Initialized
ERROR - 2018-07-24 22:54:43 --> 404 Page Not Found: /index
ERROR - 2018-07-24 22:54:43 --> 404 Page Not Found: /index
ERROR - 2018-07-24 22:54:43 --> 404 Page Not Found: /index
INFO - 2018-07-24 22:54:44 --> Config Class Initialized
INFO - 2018-07-24 22:54:44 --> Hooks Class Initialized
INFO - 2018-07-24 22:54:44 --> Config Class Initialized
INFO - 2018-07-24 22:54:44 --> Hooks Class Initialized
DEBUG - 2018-07-24 22:54:44 --> UTF-8 Support Enabled
INFO - 2018-07-24 22:54:44 --> Utf8 Class Initialized
DEBUG - 2018-07-24 22:54:44 --> UTF-8 Support Enabled
INFO - 2018-07-24 22:54:44 --> Utf8 Class Initialized
INFO - 2018-07-24 22:54:44 --> URI Class Initialized
INFO - 2018-07-24 22:54:44 --> URI Class Initialized
INFO - 2018-07-24 22:54:44 --> Router Class Initialized
INFO - 2018-07-24 22:54:44 --> Output Class Initialized
INFO - 2018-07-24 22:54:44 --> Router Class Initialized
INFO - 2018-07-24 22:54:44 --> Output Class Initialized
INFO - 2018-07-24 22:54:44 --> Security Class Initialized
INFO - 2018-07-24 22:54:44 --> Security Class Initialized
DEBUG - 2018-07-24 22:54:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 22:54:44 --> Input Class Initialized
DEBUG - 2018-07-24 22:54:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 22:54:44 --> Input Class Initialized
INFO - 2018-07-24 22:54:44 --> Language Class Initialized
INFO - 2018-07-24 22:54:44 --> Language Class Initialized
ERROR - 2018-07-24 22:54:44 --> 404 Page Not Found: /index
ERROR - 2018-07-24 22:54:44 --> 404 Page Not Found: /index
INFO - 2018-07-24 22:54:44 --> Config Class Initialized
INFO - 2018-07-24 22:54:44 --> Hooks Class Initialized
DEBUG - 2018-07-24 22:54:44 --> UTF-8 Support Enabled
INFO - 2018-07-24 22:54:44 --> Utf8 Class Initialized
INFO - 2018-07-24 22:54:45 --> URI Class Initialized
INFO - 2018-07-24 22:54:45 --> Router Class Initialized
INFO - 2018-07-24 22:54:45 --> Output Class Initialized
INFO - 2018-07-24 22:54:45 --> Security Class Initialized
DEBUG - 2018-07-24 22:54:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 22:54:45 --> Input Class Initialized
INFO - 2018-07-24 22:54:45 --> Language Class Initialized
ERROR - 2018-07-24 22:54:45 --> 404 Page Not Found: /index
INFO - 2018-07-24 22:54:45 --> Config Class Initialized
INFO - 2018-07-24 22:54:45 --> Hooks Class Initialized
DEBUG - 2018-07-24 22:54:45 --> UTF-8 Support Enabled
INFO - 2018-07-24 22:54:45 --> Utf8 Class Initialized
INFO - 2018-07-24 22:54:45 --> URI Class Initialized
INFO - 2018-07-24 22:54:45 --> Router Class Initialized
INFO - 2018-07-24 22:54:45 --> Output Class Initialized
INFO - 2018-07-24 22:54:45 --> Security Class Initialized
DEBUG - 2018-07-24 22:54:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 22:54:45 --> Input Class Initialized
INFO - 2018-07-24 22:54:45 --> Language Class Initialized
ERROR - 2018-07-24 22:54:45 --> 404 Page Not Found: /index
INFO - 2018-07-24 22:54:47 --> Config Class Initialized
INFO - 2018-07-24 22:54:47 --> Hooks Class Initialized
DEBUG - 2018-07-24 22:54:47 --> UTF-8 Support Enabled
INFO - 2018-07-24 22:54:47 --> Utf8 Class Initialized
INFO - 2018-07-24 22:54:47 --> URI Class Initialized
INFO - 2018-07-24 22:54:47 --> Router Class Initialized
INFO - 2018-07-24 22:54:47 --> Output Class Initialized
INFO - 2018-07-24 22:54:47 --> Security Class Initialized
DEBUG - 2018-07-24 22:54:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 22:54:47 --> Input Class Initialized
INFO - 2018-07-24 22:54:47 --> Language Class Initialized
ERROR - 2018-07-24 22:54:47 --> 404 Page Not Found: /index
INFO - 2018-07-24 22:54:49 --> Config Class Initialized
INFO - 2018-07-24 22:54:49 --> Hooks Class Initialized
DEBUG - 2018-07-24 22:54:49 --> UTF-8 Support Enabled
INFO - 2018-07-24 22:54:49 --> Utf8 Class Initialized
INFO - 2018-07-24 22:54:50 --> URI Class Initialized
INFO - 2018-07-24 22:54:50 --> Router Class Initialized
INFO - 2018-07-24 22:54:50 --> Output Class Initialized
INFO - 2018-07-24 22:54:50 --> Security Class Initialized
DEBUG - 2018-07-24 22:54:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 22:54:50 --> Input Class Initialized
INFO - 2018-07-24 22:54:50 --> Language Class Initialized
INFO - 2018-07-24 22:54:50 --> Language Class Initialized
INFO - 2018-07-24 22:54:50 --> Config Class Initialized
INFO - 2018-07-24 22:54:50 --> Loader Class Initialized
DEBUG - 2018-07-24 22:54:50 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-24 22:54:50 --> Helper loaded: url_helper
INFO - 2018-07-24 22:54:50 --> Helper loaded: form_helper
INFO - 2018-07-24 22:54:50 --> Helper loaded: date_helper
INFO - 2018-07-24 22:54:50 --> Helper loaded: util_helper
INFO - 2018-07-24 22:54:50 --> Helper loaded: text_helper
INFO - 2018-07-24 22:54:50 --> Helper loaded: string_helper
INFO - 2018-07-24 22:54:50 --> Database Driver Class Initialized
DEBUG - 2018-07-24 22:54:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-24 22:54:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-24 22:54:50 --> Email Class Initialized
INFO - 2018-07-24 22:54:50 --> Controller Class Initialized
DEBUG - 2018-07-24 22:54:50 --> Home MX_Controller Initialized
DEBUG - 2018-07-24 22:54:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-24 22:54:50 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-24 22:54:50 --> Login MX_Controller Initialized
INFO - 2018-07-24 22:54:50 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-24 22:54:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-24 22:54:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-24 22:54:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-07-24 22:54:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-07-24 22:54:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-07-24 22:54:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-07-24 22:54:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-07-24 22:54:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-07-24 22:54:50 --> Final output sent to browser
DEBUG - 2018-07-24 22:54:50 --> Total execution time: 0.3806
INFO - 2018-07-24 22:54:50 --> Config Class Initialized
INFO - 2018-07-24 22:54:50 --> Config Class Initialized
INFO - 2018-07-24 22:54:50 --> Config Class Initialized
INFO - 2018-07-24 22:54:50 --> Config Class Initialized
INFO - 2018-07-24 22:54:50 --> Config Class Initialized
INFO - 2018-07-24 22:54:50 --> Hooks Class Initialized
INFO - 2018-07-24 22:54:50 --> Hooks Class Initialized
INFO - 2018-07-24 22:54:50 --> Hooks Class Initialized
INFO - 2018-07-24 22:54:50 --> Hooks Class Initialized
INFO - 2018-07-24 22:54:50 --> Hooks Class Initialized
INFO - 2018-07-24 22:54:50 --> Config Class Initialized
INFO - 2018-07-24 22:54:50 --> Hooks Class Initialized
DEBUG - 2018-07-24 22:54:50 --> UTF-8 Support Enabled
DEBUG - 2018-07-24 22:54:50 --> UTF-8 Support Enabled
DEBUG - 2018-07-24 22:54:50 --> UTF-8 Support Enabled
DEBUG - 2018-07-24 22:54:50 --> UTF-8 Support Enabled
DEBUG - 2018-07-24 22:54:50 --> UTF-8 Support Enabled
INFO - 2018-07-24 22:54:50 --> Utf8 Class Initialized
DEBUG - 2018-07-24 22:54:50 --> UTF-8 Support Enabled
INFO - 2018-07-24 22:54:50 --> Utf8 Class Initialized
INFO - 2018-07-24 22:54:50 --> Utf8 Class Initialized
INFO - 2018-07-24 22:54:50 --> Utf8 Class Initialized
INFO - 2018-07-24 22:54:50 --> Utf8 Class Initialized
INFO - 2018-07-24 22:54:50 --> URI Class Initialized
INFO - 2018-07-24 22:54:50 --> Utf8 Class Initialized
INFO - 2018-07-24 22:54:50 --> URI Class Initialized
INFO - 2018-07-24 22:54:50 --> URI Class Initialized
INFO - 2018-07-24 22:54:50 --> Router Class Initialized
INFO - 2018-07-24 22:54:50 --> URI Class Initialized
INFO - 2018-07-24 22:54:50 --> URI Class Initialized
INFO - 2018-07-24 22:54:50 --> URI Class Initialized
INFO - 2018-07-24 22:54:50 --> Router Class Initialized
INFO - 2018-07-24 22:54:50 --> Output Class Initialized
INFO - 2018-07-24 22:54:50 --> Router Class Initialized
INFO - 2018-07-24 22:54:50 --> Router Class Initialized
INFO - 2018-07-24 22:54:50 --> Router Class Initialized
INFO - 2018-07-24 22:54:50 --> Router Class Initialized
INFO - 2018-07-24 22:54:50 --> Security Class Initialized
INFO - 2018-07-24 22:54:50 --> Output Class Initialized
INFO - 2018-07-24 22:54:50 --> Output Class Initialized
INFO - 2018-07-24 22:54:50 --> Output Class Initialized
INFO - 2018-07-24 22:54:50 --> Output Class Initialized
INFO - 2018-07-24 22:54:50 --> Output Class Initialized
DEBUG - 2018-07-24 22:54:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 22:54:50 --> Security Class Initialized
INFO - 2018-07-24 22:54:50 --> Security Class Initialized
INFO - 2018-07-24 22:54:50 --> Security Class Initialized
INFO - 2018-07-24 22:54:50 --> Security Class Initialized
INFO - 2018-07-24 22:54:50 --> Security Class Initialized
INFO - 2018-07-24 22:54:50 --> Input Class Initialized
DEBUG - 2018-07-24 22:54:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-07-24 22:54:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-07-24 22:54:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 22:54:50 --> Input Class Initialized
INFO - 2018-07-24 22:54:50 --> Input Class Initialized
DEBUG - 2018-07-24 22:54:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 22:54:50 --> Language Class Initialized
DEBUG - 2018-07-24 22:54:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 22:54:50 --> Input Class Initialized
INFO - 2018-07-24 22:54:50 --> Input Class Initialized
ERROR - 2018-07-24 22:54:50 --> 404 Page Not Found: /index
INFO - 2018-07-24 22:54:50 --> Input Class Initialized
INFO - 2018-07-24 22:54:50 --> Language Class Initialized
INFO - 2018-07-24 22:54:50 --> Language Class Initialized
INFO - 2018-07-24 22:54:50 --> Language Class Initialized
INFO - 2018-07-24 22:54:50 --> Language Class Initialized
INFO - 2018-07-24 22:54:50 --> Language Class Initialized
ERROR - 2018-07-24 22:54:50 --> 404 Page Not Found: /index
ERROR - 2018-07-24 22:54:50 --> 404 Page Not Found: /index
INFO - 2018-07-24 22:54:50 --> Config Class Initialized
ERROR - 2018-07-24 22:54:50 --> 404 Page Not Found: /index
ERROR - 2018-07-24 22:54:50 --> 404 Page Not Found: /index
INFO - 2018-07-24 22:54:50 --> Hooks Class Initialized
ERROR - 2018-07-24 22:54:50 --> 404 Page Not Found: /index
INFO - 2018-07-24 22:54:50 --> Config Class Initialized
INFO - 2018-07-24 22:54:50 --> Config Class Initialized
INFO - 2018-07-24 22:54:50 --> Hooks Class Initialized
INFO - 2018-07-24 22:54:50 --> Hooks Class Initialized
DEBUG - 2018-07-24 22:54:50 --> UTF-8 Support Enabled
DEBUG - 2018-07-24 22:54:50 --> UTF-8 Support Enabled
INFO - 2018-07-24 22:54:50 --> Utf8 Class Initialized
INFO - 2018-07-24 22:54:50 --> Utf8 Class Initialized
DEBUG - 2018-07-24 22:54:50 --> UTF-8 Support Enabled
INFO - 2018-07-24 22:54:50 --> URI Class Initialized
INFO - 2018-07-24 22:54:50 --> URI Class Initialized
INFO - 2018-07-24 22:54:50 --> Utf8 Class Initialized
INFO - 2018-07-24 22:54:50 --> Router Class Initialized
INFO - 2018-07-24 22:54:50 --> Router Class Initialized
INFO - 2018-07-24 22:54:50 --> URI Class Initialized
INFO - 2018-07-24 22:54:50 --> Output Class Initialized
INFO - 2018-07-24 22:54:50 --> Output Class Initialized
INFO - 2018-07-24 22:54:50 --> Security Class Initialized
INFO - 2018-07-24 22:54:50 --> Router Class Initialized
DEBUG - 2018-07-24 22:54:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 22:54:50 --> Output Class Initialized
INFO - 2018-07-24 22:54:50 --> Input Class Initialized
INFO - 2018-07-24 22:54:50 --> Security Class Initialized
DEBUG - 2018-07-24 22:54:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 22:54:50 --> Language Class Initialized
INFO - 2018-07-24 22:54:50 --> Security Class Initialized
INFO - 2018-07-24 22:54:50 --> Input Class Initialized
INFO - 2018-07-24 22:54:50 --> Language Class Initialized
ERROR - 2018-07-24 22:54:50 --> 404 Page Not Found: /index
DEBUG - 2018-07-24 22:54:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 22:54:50 --> Input Class Initialized
ERROR - 2018-07-24 22:54:50 --> 404 Page Not Found: /index
INFO - 2018-07-24 22:54:50 --> Language Class Initialized
ERROR - 2018-07-24 22:54:50 --> 404 Page Not Found: /index
INFO - 2018-07-24 22:54:50 --> Config Class Initialized
INFO - 2018-07-24 22:54:50 --> Config Class Initialized
INFO - 2018-07-24 22:54:50 --> Hooks Class Initialized
INFO - 2018-07-24 22:54:50 --> Hooks Class Initialized
DEBUG - 2018-07-24 22:54:50 --> UTF-8 Support Enabled
DEBUG - 2018-07-24 22:54:50 --> UTF-8 Support Enabled
INFO - 2018-07-24 22:54:50 --> Utf8 Class Initialized
INFO - 2018-07-24 22:54:50 --> Config Class Initialized
INFO - 2018-07-24 22:54:50 --> Hooks Class Initialized
INFO - 2018-07-24 22:54:50 --> Utf8 Class Initialized
INFO - 2018-07-24 22:54:50 --> URI Class Initialized
INFO - 2018-07-24 22:54:50 --> Router Class Initialized
DEBUG - 2018-07-24 22:54:50 --> UTF-8 Support Enabled
INFO - 2018-07-24 22:54:50 --> URI Class Initialized
INFO - 2018-07-24 22:54:50 --> Utf8 Class Initialized
INFO - 2018-07-24 22:54:50 --> Output Class Initialized
INFO - 2018-07-24 22:54:50 --> URI Class Initialized
INFO - 2018-07-24 22:54:50 --> Security Class Initialized
INFO - 2018-07-24 22:54:50 --> Router Class Initialized
INFO - 2018-07-24 22:54:50 --> Router Class Initialized
INFO - 2018-07-24 22:54:50 --> Output Class Initialized
DEBUG - 2018-07-24 22:54:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 22:54:51 --> Input Class Initialized
INFO - 2018-07-24 22:54:51 --> Security Class Initialized
INFO - 2018-07-24 22:54:51 --> Output Class Initialized
INFO - 2018-07-24 22:54:51 --> Security Class Initialized
DEBUG - 2018-07-24 22:54:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 22:54:51 --> Language Class Initialized
DEBUG - 2018-07-24 22:54:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 22:54:51 --> Input Class Initialized
INFO - 2018-07-24 22:54:51 --> Language Class Initialized
ERROR - 2018-07-24 22:54:51 --> 404 Page Not Found: /index
INFO - 2018-07-24 22:54:51 --> Input Class Initialized
INFO - 2018-07-24 22:54:51 --> Language Class Initialized
ERROR - 2018-07-24 22:54:51 --> 404 Page Not Found: /index
ERROR - 2018-07-24 22:54:51 --> 404 Page Not Found: /index
INFO - 2018-07-24 22:54:51 --> Config Class Initialized
INFO - 2018-07-24 22:54:51 --> Hooks Class Initialized
DEBUG - 2018-07-24 22:54:51 --> UTF-8 Support Enabled
INFO - 2018-07-24 22:54:51 --> Utf8 Class Initialized
INFO - 2018-07-24 22:54:51 --> URI Class Initialized
INFO - 2018-07-24 22:54:51 --> Router Class Initialized
INFO - 2018-07-24 22:54:51 --> Output Class Initialized
INFO - 2018-07-24 22:54:51 --> Security Class Initialized
DEBUG - 2018-07-24 22:54:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 22:54:51 --> Input Class Initialized
INFO - 2018-07-24 22:54:51 --> Language Class Initialized
ERROR - 2018-07-24 22:54:51 --> 404 Page Not Found: /index
INFO - 2018-07-24 22:54:51 --> Config Class Initialized
INFO - 2018-07-24 22:54:51 --> Hooks Class Initialized
DEBUG - 2018-07-24 22:54:51 --> UTF-8 Support Enabled
INFO - 2018-07-24 22:54:51 --> Utf8 Class Initialized
INFO - 2018-07-24 22:54:51 --> URI Class Initialized
INFO - 2018-07-24 22:54:51 --> Router Class Initialized
INFO - 2018-07-24 22:54:51 --> Output Class Initialized
INFO - 2018-07-24 22:54:51 --> Security Class Initialized
DEBUG - 2018-07-24 22:54:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 22:54:51 --> Input Class Initialized
INFO - 2018-07-24 22:54:51 --> Language Class Initialized
ERROR - 2018-07-24 22:54:51 --> 404 Page Not Found: /index
INFO - 2018-07-24 22:55:55 --> Config Class Initialized
INFO - 2018-07-24 22:55:55 --> Hooks Class Initialized
DEBUG - 2018-07-24 22:55:55 --> UTF-8 Support Enabled
INFO - 2018-07-24 22:55:55 --> Utf8 Class Initialized
INFO - 2018-07-24 22:55:55 --> URI Class Initialized
INFO - 2018-07-24 22:55:55 --> Router Class Initialized
INFO - 2018-07-24 22:55:55 --> Output Class Initialized
INFO - 2018-07-24 22:55:55 --> Security Class Initialized
DEBUG - 2018-07-24 22:55:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 22:55:55 --> Input Class Initialized
INFO - 2018-07-24 22:55:55 --> Language Class Initialized
INFO - 2018-07-24 22:55:55 --> Language Class Initialized
INFO - 2018-07-24 22:55:55 --> Config Class Initialized
INFO - 2018-07-24 22:55:55 --> Loader Class Initialized
DEBUG - 2018-07-24 22:55:55 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-24 22:55:55 --> Helper loaded: url_helper
INFO - 2018-07-24 22:55:55 --> Helper loaded: form_helper
INFO - 2018-07-24 22:55:55 --> Helper loaded: date_helper
INFO - 2018-07-24 22:55:55 --> Helper loaded: util_helper
INFO - 2018-07-24 22:55:55 --> Helper loaded: text_helper
INFO - 2018-07-24 22:55:55 --> Helper loaded: string_helper
INFO - 2018-07-24 22:55:55 --> Database Driver Class Initialized
DEBUG - 2018-07-24 22:55:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-24 22:55:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-24 22:55:55 --> Email Class Initialized
INFO - 2018-07-24 22:55:55 --> Controller Class Initialized
DEBUG - 2018-07-24 22:55:55 --> Home MX_Controller Initialized
DEBUG - 2018-07-24 22:55:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-24 22:55:55 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-24 22:55:55 --> Login MX_Controller Initialized
INFO - 2018-07-24 22:55:55 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-24 22:55:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-24 22:55:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-24 22:55:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-07-24 22:55:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-07-24 22:55:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-07-24 22:55:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-07-24 22:55:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-07-24 22:55:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-07-24 22:55:55 --> Final output sent to browser
DEBUG - 2018-07-24 22:55:55 --> Total execution time: 0.3626
INFO - 2018-07-24 22:55:56 --> Config Class Initialized
INFO - 2018-07-24 22:55:56 --> Config Class Initialized
INFO - 2018-07-24 22:55:56 --> Hooks Class Initialized
INFO - 2018-07-24 22:55:56 --> Hooks Class Initialized
DEBUG - 2018-07-24 22:55:56 --> UTF-8 Support Enabled
DEBUG - 2018-07-24 22:55:56 --> UTF-8 Support Enabled
INFO - 2018-07-24 22:55:56 --> Utf8 Class Initialized
INFO - 2018-07-24 22:55:56 --> Utf8 Class Initialized
INFO - 2018-07-24 22:55:56 --> URI Class Initialized
INFO - 2018-07-24 22:55:56 --> URI Class Initialized
INFO - 2018-07-24 22:55:56 --> Router Class Initialized
INFO - 2018-07-24 22:55:56 --> Router Class Initialized
INFO - 2018-07-24 22:55:56 --> Output Class Initialized
INFO - 2018-07-24 22:55:56 --> Output Class Initialized
INFO - 2018-07-24 22:55:56 --> Security Class Initialized
DEBUG - 2018-07-24 22:55:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 22:55:56 --> Input Class Initialized
INFO - 2018-07-24 22:55:56 --> Language Class Initialized
ERROR - 2018-07-24 22:55:56 --> 404 Page Not Found: /index
INFO - 2018-07-24 22:55:56 --> Security Class Initialized
INFO - 2018-07-24 22:55:56 --> Config Class Initialized
INFO - 2018-07-24 22:55:56 --> Hooks Class Initialized
DEBUG - 2018-07-24 22:55:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 22:55:56 --> Input Class Initialized
DEBUG - 2018-07-24 22:55:56 --> UTF-8 Support Enabled
INFO - 2018-07-24 22:55:56 --> Utf8 Class Initialized
INFO - 2018-07-24 22:55:56 --> Language Class Initialized
INFO - 2018-07-24 22:55:56 --> URI Class Initialized
ERROR - 2018-07-24 22:55:56 --> 404 Page Not Found: /index
INFO - 2018-07-24 22:55:56 --> Router Class Initialized
INFO - 2018-07-24 22:55:56 --> Output Class Initialized
INFO - 2018-07-24 22:55:56 --> Security Class Initialized
DEBUG - 2018-07-24 22:55:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 22:55:56 --> Input Class Initialized
INFO - 2018-07-24 22:55:56 --> Language Class Initialized
ERROR - 2018-07-24 22:55:56 --> 404 Page Not Found: /index
INFO - 2018-07-24 22:55:56 --> Config Class Initialized
INFO - 2018-07-24 22:55:56 --> Hooks Class Initialized
DEBUG - 2018-07-24 22:55:56 --> UTF-8 Support Enabled
INFO - 2018-07-24 22:55:56 --> Utf8 Class Initialized
INFO - 2018-07-24 22:55:56 --> URI Class Initialized
INFO - 2018-07-24 22:55:56 --> Router Class Initialized
INFO - 2018-07-24 22:55:56 --> Output Class Initialized
INFO - 2018-07-24 22:55:56 --> Security Class Initialized
DEBUG - 2018-07-24 22:55:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 22:55:56 --> Input Class Initialized
INFO - 2018-07-24 22:55:56 --> Language Class Initialized
ERROR - 2018-07-24 22:55:56 --> 404 Page Not Found: /index
INFO - 2018-07-24 22:56:02 --> Config Class Initialized
INFO - 2018-07-24 22:56:02 --> Config Class Initialized
INFO - 2018-07-24 22:56:02 --> Hooks Class Initialized
INFO - 2018-07-24 22:56:02 --> Hooks Class Initialized
DEBUG - 2018-07-24 22:56:02 --> UTF-8 Support Enabled
DEBUG - 2018-07-24 22:56:02 --> UTF-8 Support Enabled
INFO - 2018-07-24 22:56:02 --> Utf8 Class Initialized
INFO - 2018-07-24 22:56:02 --> Utf8 Class Initialized
INFO - 2018-07-24 22:56:02 --> URI Class Initialized
INFO - 2018-07-24 22:56:02 --> URI Class Initialized
INFO - 2018-07-24 22:56:02 --> Router Class Initialized
INFO - 2018-07-24 22:56:02 --> Router Class Initialized
INFO - 2018-07-24 22:56:02 --> Output Class Initialized
INFO - 2018-07-24 22:56:02 --> Output Class Initialized
INFO - 2018-07-24 22:56:02 --> Security Class Initialized
INFO - 2018-07-24 22:56:02 --> Security Class Initialized
DEBUG - 2018-07-24 22:56:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-07-24 22:56:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 22:56:02 --> Input Class Initialized
INFO - 2018-07-24 22:56:02 --> Input Class Initialized
INFO - 2018-07-24 22:56:02 --> Language Class Initialized
ERROR - 2018-07-24 22:56:02 --> 404 Page Not Found: /index
INFO - 2018-07-24 22:56:02 --> Language Class Initialized
ERROR - 2018-07-24 22:56:02 --> 404 Page Not Found: /index
INFO - 2018-07-24 22:56:02 --> Config Class Initialized
INFO - 2018-07-24 22:56:02 --> Hooks Class Initialized
DEBUG - 2018-07-24 22:56:02 --> UTF-8 Support Enabled
INFO - 2018-07-24 22:56:02 --> Utf8 Class Initialized
INFO - 2018-07-24 22:56:02 --> URI Class Initialized
INFO - 2018-07-24 22:56:02 --> Router Class Initialized
INFO - 2018-07-24 22:56:02 --> Output Class Initialized
INFO - 2018-07-24 22:56:02 --> Security Class Initialized
DEBUG - 2018-07-24 22:56:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 22:56:02 --> Input Class Initialized
INFO - 2018-07-24 22:56:02 --> Language Class Initialized
ERROR - 2018-07-24 22:56:02 --> 404 Page Not Found: /index
INFO - 2018-07-24 22:56:02 --> Config Class Initialized
INFO - 2018-07-24 22:56:02 --> Hooks Class Initialized
DEBUG - 2018-07-24 22:56:02 --> UTF-8 Support Enabled
INFO - 2018-07-24 22:56:02 --> Utf8 Class Initialized
INFO - 2018-07-24 22:56:02 --> URI Class Initialized
INFO - 2018-07-24 22:56:02 --> Router Class Initialized
INFO - 2018-07-24 22:56:02 --> Output Class Initialized
INFO - 2018-07-24 22:56:02 --> Security Class Initialized
DEBUG - 2018-07-24 22:56:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 22:56:02 --> Input Class Initialized
INFO - 2018-07-24 22:56:02 --> Language Class Initialized
ERROR - 2018-07-24 22:56:02 --> 404 Page Not Found: /index
INFO - 2018-07-24 22:56:02 --> Config Class Initialized
INFO - 2018-07-24 22:56:02 --> Hooks Class Initialized
DEBUG - 2018-07-24 22:56:02 --> UTF-8 Support Enabled
INFO - 2018-07-24 22:56:02 --> Utf8 Class Initialized
INFO - 2018-07-24 22:56:02 --> URI Class Initialized
INFO - 2018-07-24 22:56:02 --> Router Class Initialized
INFO - 2018-07-24 22:56:02 --> Output Class Initialized
INFO - 2018-07-24 22:56:02 --> Security Class Initialized
DEBUG - 2018-07-24 22:56:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 22:56:02 --> Input Class Initialized
INFO - 2018-07-24 22:56:02 --> Language Class Initialized
ERROR - 2018-07-24 22:56:02 --> 404 Page Not Found: /index
INFO - 2018-07-24 22:56:02 --> Config Class Initialized
INFO - 2018-07-24 22:56:03 --> Hooks Class Initialized
DEBUG - 2018-07-24 22:56:03 --> UTF-8 Support Enabled
INFO - 2018-07-24 22:56:03 --> Utf8 Class Initialized
INFO - 2018-07-24 22:56:03 --> URI Class Initialized
INFO - 2018-07-24 22:56:03 --> Router Class Initialized
INFO - 2018-07-24 22:56:03 --> Output Class Initialized
INFO - 2018-07-24 22:56:03 --> Security Class Initialized
DEBUG - 2018-07-24 22:56:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 22:56:03 --> Input Class Initialized
INFO - 2018-07-24 22:56:03 --> Language Class Initialized
ERROR - 2018-07-24 22:56:03 --> 404 Page Not Found: /index
INFO - 2018-07-24 22:56:03 --> Config Class Initialized
INFO - 2018-07-24 22:56:03 --> Hooks Class Initialized
DEBUG - 2018-07-24 22:56:03 --> UTF-8 Support Enabled
INFO - 2018-07-24 22:56:03 --> Utf8 Class Initialized
INFO - 2018-07-24 22:56:03 --> URI Class Initialized
INFO - 2018-07-24 22:56:03 --> Router Class Initialized
INFO - 2018-07-24 22:56:03 --> Output Class Initialized
INFO - 2018-07-24 22:56:03 --> Security Class Initialized
DEBUG - 2018-07-24 22:56:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 22:56:03 --> Input Class Initialized
INFO - 2018-07-24 22:56:03 --> Language Class Initialized
ERROR - 2018-07-24 22:56:03 --> 404 Page Not Found: /index
INFO - 2018-07-24 22:56:09 --> Config Class Initialized
INFO - 2018-07-24 22:56:09 --> Hooks Class Initialized
DEBUG - 2018-07-24 22:56:09 --> UTF-8 Support Enabled
INFO - 2018-07-24 22:56:09 --> Utf8 Class Initialized
INFO - 2018-07-24 22:56:09 --> URI Class Initialized
INFO - 2018-07-24 22:56:09 --> Router Class Initialized
INFO - 2018-07-24 22:56:09 --> Output Class Initialized
INFO - 2018-07-24 22:56:09 --> Security Class Initialized
DEBUG - 2018-07-24 22:56:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 22:56:09 --> Input Class Initialized
INFO - 2018-07-24 22:56:09 --> Language Class Initialized
INFO - 2018-07-24 22:56:09 --> Language Class Initialized
INFO - 2018-07-24 22:56:09 --> Config Class Initialized
INFO - 2018-07-24 22:56:09 --> Loader Class Initialized
DEBUG - 2018-07-24 22:56:09 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-24 22:56:09 --> Helper loaded: url_helper
INFO - 2018-07-24 22:56:09 --> Helper loaded: form_helper
INFO - 2018-07-24 22:56:09 --> Helper loaded: date_helper
INFO - 2018-07-24 22:56:09 --> Helper loaded: util_helper
INFO - 2018-07-24 22:56:09 --> Helper loaded: text_helper
INFO - 2018-07-24 22:56:09 --> Helper loaded: string_helper
INFO - 2018-07-24 22:56:09 --> Database Driver Class Initialized
DEBUG - 2018-07-24 22:56:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-24 22:56:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-24 22:56:09 --> Email Class Initialized
INFO - 2018-07-24 22:56:09 --> Controller Class Initialized
DEBUG - 2018-07-24 22:56:09 --> Home MX_Controller Initialized
DEBUG - 2018-07-24 22:56:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-24 22:56:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-24 22:56:09 --> Final output sent to browser
DEBUG - 2018-07-24 22:56:10 --> Total execution time: 0.3711
INFO - 2018-07-24 22:56:10 --> Config Class Initialized
INFO - 2018-07-24 22:56:10 --> Hooks Class Initialized
DEBUG - 2018-07-24 22:56:10 --> UTF-8 Support Enabled
INFO - 2018-07-24 22:56:10 --> Utf8 Class Initialized
INFO - 2018-07-24 22:56:10 --> URI Class Initialized
INFO - 2018-07-24 22:56:10 --> Router Class Initialized
INFO - 2018-07-24 22:56:10 --> Output Class Initialized
INFO - 2018-07-24 22:56:10 --> Security Class Initialized
DEBUG - 2018-07-24 22:56:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 22:56:10 --> Input Class Initialized
INFO - 2018-07-24 22:56:10 --> Language Class Initialized
INFO - 2018-07-24 22:56:10 --> Language Class Initialized
INFO - 2018-07-24 22:56:10 --> Config Class Initialized
INFO - 2018-07-24 22:56:10 --> Loader Class Initialized
DEBUG - 2018-07-24 22:56:10 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-24 22:56:10 --> Helper loaded: url_helper
INFO - 2018-07-24 22:56:10 --> Helper loaded: form_helper
INFO - 2018-07-24 22:56:10 --> Helper loaded: date_helper
INFO - 2018-07-24 22:56:10 --> Config Class Initialized
INFO - 2018-07-24 22:56:10 --> Hooks Class Initialized
INFO - 2018-07-24 22:56:10 --> Helper loaded: util_helper
INFO - 2018-07-24 22:56:10 --> Helper loaded: text_helper
DEBUG - 2018-07-24 22:56:10 --> UTF-8 Support Enabled
INFO - 2018-07-24 22:56:10 --> Utf8 Class Initialized
INFO - 2018-07-24 22:56:10 --> Helper loaded: string_helper
INFO - 2018-07-24 22:56:10 --> URI Class Initialized
INFO - 2018-07-24 22:56:10 --> Database Driver Class Initialized
INFO - 2018-07-24 22:56:10 --> Router Class Initialized
DEBUG - 2018-07-24 22:56:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-24 22:56:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-24 22:56:10 --> Output Class Initialized
INFO - 2018-07-24 22:56:10 --> Security Class Initialized
INFO - 2018-07-24 22:56:10 --> Email Class Initialized
INFO - 2018-07-24 22:56:10 --> Controller Class Initialized
DEBUG - 2018-07-24 22:56:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-07-24 22:56:10 --> Home MX_Controller Initialized
INFO - 2018-07-24 22:56:10 --> Input Class Initialized
INFO - 2018-07-24 22:56:10 --> Language Class Initialized
DEBUG - 2018-07-24 22:56:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-07-24 22:56:10 --> Language Class Initialized
INFO - 2018-07-24 22:56:10 --> Config Class Initialized
INFO - 2018-07-24 22:56:10 --> Loader Class Initialized
DEBUG - 2018-07-24 22:56:10 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-24 22:56:10 --> Helper loaded: url_helper
INFO - 2018-07-24 22:56:10 --> Helper loaded: form_helper
INFO - 2018-07-24 22:56:10 --> Helper loaded: date_helper
INFO - 2018-07-24 22:56:10 --> Helper loaded: util_helper
INFO - 2018-07-24 22:56:10 --> Helper loaded: text_helper
INFO - 2018-07-24 22:56:10 --> Helper loaded: string_helper
INFO - 2018-07-24 22:56:10 --> Database Driver Class Initialized
DEBUG - 2018-07-24 22:56:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-24 22:56:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-24 22:56:10 --> Email Class Initialized
INFO - 2018-07-24 22:56:10 --> Controller Class Initialized
DEBUG - 2018-07-24 22:56:10 --> Home MX_Controller Initialized
DEBUG - 2018-07-24 22:56:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-24 22:56:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-24 22:56:10 --> Final output sent to browser
DEBUG - 2018-07-24 22:56:10 --> Total execution time: 0.3076
INFO - 2018-07-24 22:56:10 --> Config Class Initialized
INFO - 2018-07-24 22:56:10 --> Hooks Class Initialized
DEBUG - 2018-07-24 22:56:10 --> UTF-8 Support Enabled
INFO - 2018-07-24 22:56:10 --> Utf8 Class Initialized
INFO - 2018-07-24 22:56:10 --> URI Class Initialized
INFO - 2018-07-24 22:56:10 --> Router Class Initialized
INFO - 2018-07-24 22:56:10 --> Output Class Initialized
INFO - 2018-07-24 22:56:10 --> Security Class Initialized
DEBUG - 2018-07-24 22:56:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 22:56:10 --> Input Class Initialized
INFO - 2018-07-24 22:56:10 --> Language Class Initialized
INFO - 2018-07-24 22:56:10 --> Language Class Initialized
INFO - 2018-07-24 22:56:10 --> Config Class Initialized
INFO - 2018-07-24 22:56:10 --> Loader Class Initialized
DEBUG - 2018-07-24 22:56:10 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-24 22:56:10 --> Helper loaded: url_helper
INFO - 2018-07-24 22:56:10 --> Helper loaded: form_helper
INFO - 2018-07-24 22:56:10 --> Helper loaded: date_helper
INFO - 2018-07-24 22:56:10 --> Helper loaded: util_helper
INFO - 2018-07-24 22:56:10 --> Helper loaded: text_helper
INFO - 2018-07-24 22:56:10 --> Helper loaded: string_helper
INFO - 2018-07-24 22:56:10 --> Database Driver Class Initialized
INFO - 2018-07-24 22:56:10 --> Config Class Initialized
INFO - 2018-07-24 22:56:10 --> Hooks Class Initialized
DEBUG - 2018-07-24 22:56:10 --> UTF-8 Support Enabled
DEBUG - 2018-07-24 22:56:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-24 22:56:10 --> Utf8 Class Initialized
INFO - 2018-07-24 22:56:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-24 22:56:10 --> URI Class Initialized
INFO - 2018-07-24 22:56:10 --> Email Class Initialized
INFO - 2018-07-24 22:56:10 --> Controller Class Initialized
INFO - 2018-07-24 22:56:10 --> Router Class Initialized
DEBUG - 2018-07-24 22:56:10 --> Home MX_Controller Initialized
INFO - 2018-07-24 22:56:10 --> Output Class Initialized
DEBUG - 2018-07-24 22:56:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-07-24 22:56:10 --> Security Class Initialized
DEBUG - 2018-07-24 22:56:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 22:56:10 --> Input Class Initialized
INFO - 2018-07-24 22:56:10 --> Language Class Initialized
INFO - 2018-07-24 22:56:10 --> Language Class Initialized
INFO - 2018-07-24 22:56:10 --> Config Class Initialized
INFO - 2018-07-24 22:56:10 --> Loader Class Initialized
DEBUG - 2018-07-24 22:56:10 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-24 22:56:10 --> Helper loaded: url_helper
INFO - 2018-07-24 22:56:10 --> Helper loaded: form_helper
INFO - 2018-07-24 22:56:10 --> Helper loaded: date_helper
INFO - 2018-07-24 22:56:10 --> Helper loaded: util_helper
INFO - 2018-07-24 22:56:10 --> Helper loaded: text_helper
INFO - 2018-07-24 22:56:10 --> Helper loaded: string_helper
INFO - 2018-07-24 22:56:10 --> Database Driver Class Initialized
DEBUG - 2018-07-24 22:56:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-24 22:56:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-24 22:56:10 --> Email Class Initialized
INFO - 2018-07-24 22:56:10 --> Controller Class Initialized
DEBUG - 2018-07-24 22:56:11 --> Home MX_Controller Initialized
DEBUG - 2018-07-24 22:56:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-24 22:56:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-24 22:56:11 --> Final output sent to browser
DEBUG - 2018-07-24 22:56:11 --> Total execution time: 0.2979
INFO - 2018-07-24 22:56:11 --> Config Class Initialized
INFO - 2018-07-24 22:56:11 --> Hooks Class Initialized
DEBUG - 2018-07-24 22:56:11 --> UTF-8 Support Enabled
INFO - 2018-07-24 22:56:11 --> Utf8 Class Initialized
INFO - 2018-07-24 22:56:11 --> URI Class Initialized
INFO - 2018-07-24 22:56:11 --> Router Class Initialized
INFO - 2018-07-24 22:56:11 --> Output Class Initialized
INFO - 2018-07-24 22:56:11 --> Security Class Initialized
DEBUG - 2018-07-24 22:56:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 22:56:11 --> Input Class Initialized
INFO - 2018-07-24 22:56:11 --> Language Class Initialized
INFO - 2018-07-24 22:56:11 --> Language Class Initialized
INFO - 2018-07-24 22:56:11 --> Config Class Initialized
INFO - 2018-07-24 22:56:11 --> Loader Class Initialized
DEBUG - 2018-07-24 22:56:11 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-24 22:56:11 --> Helper loaded: url_helper
INFO - 2018-07-24 22:56:11 --> Helper loaded: form_helper
INFO - 2018-07-24 22:56:11 --> Helper loaded: date_helper
INFO - 2018-07-24 22:56:11 --> Helper loaded: util_helper
INFO - 2018-07-24 22:56:11 --> Helper loaded: text_helper
INFO - 2018-07-24 22:56:11 --> Helper loaded: string_helper
INFO - 2018-07-24 22:56:11 --> Database Driver Class Initialized
DEBUG - 2018-07-24 22:56:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-24 22:56:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-24 22:56:11 --> Email Class Initialized
INFO - 2018-07-24 22:56:11 --> Controller Class Initialized
DEBUG - 2018-07-24 22:56:11 --> Home MX_Controller Initialized
DEBUG - 2018-07-24 22:56:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-07-24 22:56:11 --> Config Class Initialized
INFO - 2018-07-24 22:56:11 --> Hooks Class Initialized
DEBUG - 2018-07-24 22:56:11 --> UTF-8 Support Enabled
INFO - 2018-07-24 22:56:11 --> Utf8 Class Initialized
INFO - 2018-07-24 22:56:11 --> URI Class Initialized
INFO - 2018-07-24 22:56:11 --> Router Class Initialized
INFO - 2018-07-24 22:56:11 --> Output Class Initialized
INFO - 2018-07-24 22:56:11 --> Security Class Initialized
DEBUG - 2018-07-24 22:56:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 22:56:11 --> Input Class Initialized
INFO - 2018-07-24 22:56:11 --> Language Class Initialized
INFO - 2018-07-24 22:56:11 --> Language Class Initialized
INFO - 2018-07-24 22:56:11 --> Config Class Initialized
INFO - 2018-07-24 22:56:11 --> Loader Class Initialized
DEBUG - 2018-07-24 22:56:11 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-24 22:56:11 --> Helper loaded: url_helper
INFO - 2018-07-24 22:56:11 --> Helper loaded: form_helper
INFO - 2018-07-24 22:56:11 --> Helper loaded: date_helper
INFO - 2018-07-24 22:56:11 --> Helper loaded: util_helper
INFO - 2018-07-24 22:56:11 --> Helper loaded: text_helper
INFO - 2018-07-24 22:56:11 --> Helper loaded: string_helper
INFO - 2018-07-24 22:56:11 --> Database Driver Class Initialized
DEBUG - 2018-07-24 22:56:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-24 22:56:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-24 22:56:11 --> Email Class Initialized
INFO - 2018-07-24 22:56:11 --> Controller Class Initialized
DEBUG - 2018-07-24 22:56:11 --> Home MX_Controller Initialized
DEBUG - 2018-07-24 22:56:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-24 22:56:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-24 22:56:11 --> Final output sent to browser
DEBUG - 2018-07-24 22:56:11 --> Total execution time: 0.2902
INFO - 2018-07-24 22:56:11 --> Config Class Initialized
INFO - 2018-07-24 22:56:11 --> Hooks Class Initialized
DEBUG - 2018-07-24 22:56:11 --> UTF-8 Support Enabled
INFO - 2018-07-24 22:56:11 --> Utf8 Class Initialized
INFO - 2018-07-24 22:56:11 --> URI Class Initialized
INFO - 2018-07-24 22:56:11 --> Router Class Initialized
INFO - 2018-07-24 22:56:11 --> Output Class Initialized
INFO - 2018-07-24 22:56:11 --> Security Class Initialized
DEBUG - 2018-07-24 22:56:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 22:56:11 --> Input Class Initialized
INFO - 2018-07-24 22:56:11 --> Language Class Initialized
INFO - 2018-07-24 22:56:11 --> Language Class Initialized
INFO - 2018-07-24 22:56:11 --> Config Class Initialized
INFO - 2018-07-24 22:56:11 --> Config Class Initialized
INFO - 2018-07-24 22:56:11 --> Hooks Class Initialized
INFO - 2018-07-24 22:56:11 --> Loader Class Initialized
DEBUG - 2018-07-24 22:56:11 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
DEBUG - 2018-07-24 22:56:11 --> UTF-8 Support Enabled
INFO - 2018-07-24 22:56:11 --> Utf8 Class Initialized
INFO - 2018-07-24 22:56:11 --> Helper loaded: url_helper
INFO - 2018-07-24 22:56:11 --> URI Class Initialized
INFO - 2018-07-24 22:56:11 --> Helper loaded: form_helper
INFO - 2018-07-24 22:56:11 --> Helper loaded: date_helper
INFO - 2018-07-24 22:56:11 --> Router Class Initialized
INFO - 2018-07-24 22:56:11 --> Helper loaded: util_helper
INFO - 2018-07-24 22:56:11 --> Output Class Initialized
INFO - 2018-07-24 22:56:11 --> Helper loaded: text_helper
INFO - 2018-07-24 22:56:11 --> Security Class Initialized
INFO - 2018-07-24 22:56:11 --> Helper loaded: string_helper
DEBUG - 2018-07-24 22:56:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 22:56:11 --> Input Class Initialized
INFO - 2018-07-24 22:56:11 --> Database Driver Class Initialized
INFO - 2018-07-24 22:56:11 --> Language Class Initialized
DEBUG - 2018-07-24 22:56:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-24 22:56:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-24 22:56:11 --> Language Class Initialized
INFO - 2018-07-24 22:56:11 --> Config Class Initialized
INFO - 2018-07-24 22:56:11 --> Email Class Initialized
INFO - 2018-07-24 22:56:11 --> Controller Class Initialized
INFO - 2018-07-24 22:56:11 --> Loader Class Initialized
DEBUG - 2018-07-24 22:56:11 --> Home MX_Controller Initialized
DEBUG - 2018-07-24 22:56:11 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
DEBUG - 2018-07-24 22:56:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-07-24 22:56:11 --> Helper loaded: url_helper
INFO - 2018-07-24 22:56:11 --> Helper loaded: form_helper
INFO - 2018-07-24 22:56:12 --> Helper loaded: date_helper
INFO - 2018-07-24 22:56:12 --> Helper loaded: util_helper
INFO - 2018-07-24 22:56:12 --> Helper loaded: text_helper
INFO - 2018-07-24 22:56:12 --> Helper loaded: string_helper
INFO - 2018-07-24 22:56:12 --> Database Driver Class Initialized
DEBUG - 2018-07-24 22:56:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-24 22:56:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-24 22:56:12 --> Email Class Initialized
INFO - 2018-07-24 22:56:12 --> Controller Class Initialized
DEBUG - 2018-07-24 22:56:12 --> Home MX_Controller Initialized
DEBUG - 2018-07-24 22:56:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-24 22:56:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-24 22:56:12 --> Final output sent to browser
DEBUG - 2018-07-24 22:56:12 --> Total execution time: 0.3078
INFO - 2018-07-24 22:56:12 --> Config Class Initialized
INFO - 2018-07-24 22:56:12 --> Hooks Class Initialized
DEBUG - 2018-07-24 22:56:12 --> UTF-8 Support Enabled
INFO - 2018-07-24 22:56:12 --> Utf8 Class Initialized
INFO - 2018-07-24 22:56:12 --> URI Class Initialized
INFO - 2018-07-24 22:56:12 --> Router Class Initialized
INFO - 2018-07-24 22:56:12 --> Output Class Initialized
INFO - 2018-07-24 22:56:12 --> Security Class Initialized
DEBUG - 2018-07-24 22:56:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 22:56:12 --> Input Class Initialized
INFO - 2018-07-24 22:56:12 --> Language Class Initialized
INFO - 2018-07-24 22:56:12 --> Language Class Initialized
INFO - 2018-07-24 22:56:12 --> Config Class Initialized
INFO - 2018-07-24 22:56:12 --> Loader Class Initialized
DEBUG - 2018-07-24 22:56:12 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-24 22:56:12 --> Helper loaded: url_helper
INFO - 2018-07-24 22:56:12 --> Helper loaded: form_helper
INFO - 2018-07-24 22:56:12 --> Helper loaded: date_helper
INFO - 2018-07-24 22:56:12 --> Helper loaded: util_helper
INFO - 2018-07-24 22:56:12 --> Helper loaded: text_helper
INFO - 2018-07-24 22:56:12 --> Helper loaded: string_helper
INFO - 2018-07-24 22:56:12 --> Database Driver Class Initialized
DEBUG - 2018-07-24 22:56:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-24 22:56:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-24 22:56:12 --> Email Class Initialized
INFO - 2018-07-24 22:56:12 --> Controller Class Initialized
DEBUG - 2018-07-24 22:56:12 --> Home MX_Controller Initialized
DEBUG - 2018-07-24 22:56:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-07-24 22:56:12 --> Config Class Initialized
INFO - 2018-07-24 22:56:12 --> Hooks Class Initialized
DEBUG - 2018-07-24 22:56:12 --> UTF-8 Support Enabled
INFO - 2018-07-24 22:56:12 --> Utf8 Class Initialized
INFO - 2018-07-24 22:56:12 --> URI Class Initialized
INFO - 2018-07-24 22:56:12 --> Router Class Initialized
INFO - 2018-07-24 22:56:12 --> Output Class Initialized
INFO - 2018-07-24 22:56:12 --> Security Class Initialized
DEBUG - 2018-07-24 22:56:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 22:56:12 --> Input Class Initialized
INFO - 2018-07-24 22:56:12 --> Language Class Initialized
INFO - 2018-07-24 22:56:12 --> Language Class Initialized
INFO - 2018-07-24 22:56:12 --> Config Class Initialized
INFO - 2018-07-24 22:56:12 --> Loader Class Initialized
DEBUG - 2018-07-24 22:56:12 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-24 22:56:12 --> Helper loaded: url_helper
INFO - 2018-07-24 22:56:12 --> Helper loaded: form_helper
INFO - 2018-07-24 22:56:12 --> Helper loaded: date_helper
INFO - 2018-07-24 22:56:12 --> Helper loaded: util_helper
INFO - 2018-07-24 22:56:12 --> Helper loaded: text_helper
INFO - 2018-07-24 22:56:12 --> Helper loaded: string_helper
INFO - 2018-07-24 22:56:12 --> Database Driver Class Initialized
DEBUG - 2018-07-24 22:56:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-24 22:56:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-24 22:56:12 --> Email Class Initialized
INFO - 2018-07-24 22:56:12 --> Controller Class Initialized
DEBUG - 2018-07-24 22:56:12 --> Home MX_Controller Initialized
DEBUG - 2018-07-24 22:56:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-24 22:56:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-24 22:56:12 --> Final output sent to browser
DEBUG - 2018-07-24 22:56:12 --> Total execution time: 0.3056
INFO - 2018-07-24 22:56:12 --> Config Class Initialized
INFO - 2018-07-24 22:56:12 --> Hooks Class Initialized
DEBUG - 2018-07-24 22:56:12 --> UTF-8 Support Enabled
INFO - 2018-07-24 22:56:12 --> Utf8 Class Initialized
INFO - 2018-07-24 22:56:12 --> URI Class Initialized
INFO - 2018-07-24 22:56:12 --> Router Class Initialized
INFO - 2018-07-24 22:56:12 --> Output Class Initialized
INFO - 2018-07-24 22:56:12 --> Security Class Initialized
DEBUG - 2018-07-24 22:56:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 22:56:12 --> Input Class Initialized
INFO - 2018-07-24 22:56:12 --> Language Class Initialized
INFO - 2018-07-24 22:56:12 --> Language Class Initialized
INFO - 2018-07-24 22:56:12 --> Config Class Initialized
INFO - 2018-07-24 22:56:12 --> Loader Class Initialized
DEBUG - 2018-07-24 22:56:12 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-24 22:56:13 --> Helper loaded: url_helper
INFO - 2018-07-24 22:56:13 --> Helper loaded: form_helper
INFO - 2018-07-24 22:56:13 --> Helper loaded: date_helper
INFO - 2018-07-24 22:56:13 --> Helper loaded: util_helper
INFO - 2018-07-24 22:56:13 --> Helper loaded: text_helper
INFO - 2018-07-24 22:56:13 --> Helper loaded: string_helper
INFO - 2018-07-24 22:56:13 --> Database Driver Class Initialized
DEBUG - 2018-07-24 22:56:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-24 22:56:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-24 22:56:13 --> Email Class Initialized
INFO - 2018-07-24 22:56:13 --> Controller Class Initialized
DEBUG - 2018-07-24 22:56:13 --> Home MX_Controller Initialized
DEBUG - 2018-07-24 22:56:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-07-24 22:56:13 --> Config Class Initialized
INFO - 2018-07-24 22:56:13 --> Hooks Class Initialized
DEBUG - 2018-07-24 22:56:13 --> UTF-8 Support Enabled
INFO - 2018-07-24 22:56:13 --> Utf8 Class Initialized
INFO - 2018-07-24 22:56:13 --> URI Class Initialized
INFO - 2018-07-24 22:56:13 --> Router Class Initialized
INFO - 2018-07-24 22:56:13 --> Output Class Initialized
INFO - 2018-07-24 22:56:13 --> Security Class Initialized
DEBUG - 2018-07-24 22:56:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 22:56:13 --> Input Class Initialized
INFO - 2018-07-24 22:56:13 --> Language Class Initialized
INFO - 2018-07-24 22:56:13 --> Language Class Initialized
INFO - 2018-07-24 22:56:13 --> Config Class Initialized
INFO - 2018-07-24 22:56:13 --> Loader Class Initialized
DEBUG - 2018-07-24 22:56:13 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-24 22:56:13 --> Helper loaded: url_helper
INFO - 2018-07-24 22:56:13 --> Helper loaded: form_helper
INFO - 2018-07-24 22:56:13 --> Helper loaded: date_helper
INFO - 2018-07-24 22:56:13 --> Helper loaded: util_helper
INFO - 2018-07-24 22:56:13 --> Helper loaded: text_helper
INFO - 2018-07-24 22:56:13 --> Helper loaded: string_helper
INFO - 2018-07-24 22:56:13 --> Database Driver Class Initialized
DEBUG - 2018-07-24 22:56:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-24 22:56:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-24 22:56:13 --> Email Class Initialized
INFO - 2018-07-24 22:56:13 --> Controller Class Initialized
DEBUG - 2018-07-24 22:56:13 --> Home MX_Controller Initialized
DEBUG - 2018-07-24 22:56:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-24 22:56:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-24 22:56:13 --> Final output sent to browser
DEBUG - 2018-07-24 22:56:13 --> Total execution time: 0.3186
INFO - 2018-07-24 22:56:13 --> Config Class Initialized
INFO - 2018-07-24 22:56:13 --> Hooks Class Initialized
DEBUG - 2018-07-24 22:56:13 --> UTF-8 Support Enabled
INFO - 2018-07-24 22:56:13 --> Utf8 Class Initialized
INFO - 2018-07-24 22:56:14 --> URI Class Initialized
INFO - 2018-07-24 22:56:14 --> Router Class Initialized
INFO - 2018-07-24 22:56:14 --> Output Class Initialized
INFO - 2018-07-24 22:56:14 --> Security Class Initialized
DEBUG - 2018-07-24 22:56:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 22:56:14 --> Input Class Initialized
INFO - 2018-07-24 22:56:14 --> Language Class Initialized
INFO - 2018-07-24 22:56:14 --> Language Class Initialized
INFO - 2018-07-24 22:56:14 --> Config Class Initialized
INFO - 2018-07-24 22:56:14 --> Loader Class Initialized
DEBUG - 2018-07-24 22:56:14 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-24 22:56:14 --> Helper loaded: url_helper
INFO - 2018-07-24 22:56:14 --> Helper loaded: form_helper
INFO - 2018-07-24 22:56:14 --> Helper loaded: date_helper
INFO - 2018-07-24 22:56:14 --> Helper loaded: util_helper
INFO - 2018-07-24 22:56:14 --> Helper loaded: text_helper
INFO - 2018-07-24 22:56:14 --> Helper loaded: string_helper
INFO - 2018-07-24 22:56:14 --> Database Driver Class Initialized
DEBUG - 2018-07-24 22:56:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-24 22:56:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-24 22:56:14 --> Email Class Initialized
INFO - 2018-07-24 22:56:14 --> Controller Class Initialized
DEBUG - 2018-07-24 22:56:14 --> Home MX_Controller Initialized
DEBUG - 2018-07-24 22:56:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-07-24 22:56:14 --> Config Class Initialized
INFO - 2018-07-24 22:56:14 --> Hooks Class Initialized
DEBUG - 2018-07-24 22:56:14 --> UTF-8 Support Enabled
INFO - 2018-07-24 22:56:14 --> Utf8 Class Initialized
INFO - 2018-07-24 22:56:14 --> URI Class Initialized
INFO - 2018-07-24 22:56:14 --> Router Class Initialized
INFO - 2018-07-24 22:56:14 --> Output Class Initialized
INFO - 2018-07-24 22:56:14 --> Security Class Initialized
DEBUG - 2018-07-24 22:56:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 22:56:14 --> Input Class Initialized
INFO - 2018-07-24 22:56:14 --> Language Class Initialized
INFO - 2018-07-24 22:56:14 --> Language Class Initialized
INFO - 2018-07-24 22:56:14 --> Config Class Initialized
INFO - 2018-07-24 22:56:14 --> Loader Class Initialized
DEBUG - 2018-07-24 22:56:14 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-24 22:56:14 --> Helper loaded: url_helper
INFO - 2018-07-24 22:56:14 --> Helper loaded: form_helper
INFO - 2018-07-24 22:56:14 --> Helper loaded: date_helper
INFO - 2018-07-24 22:56:14 --> Helper loaded: util_helper
INFO - 2018-07-24 22:56:14 --> Helper loaded: text_helper
INFO - 2018-07-24 22:56:14 --> Helper loaded: string_helper
INFO - 2018-07-24 22:56:14 --> Database Driver Class Initialized
DEBUG - 2018-07-24 22:56:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-24 22:56:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-24 22:56:14 --> Email Class Initialized
INFO - 2018-07-24 22:56:14 --> Controller Class Initialized
DEBUG - 2018-07-24 22:56:14 --> Home MX_Controller Initialized
DEBUG - 2018-07-24 22:56:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-24 22:56:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-24 22:56:14 --> Final output sent to browser
DEBUG - 2018-07-24 22:56:14 --> Total execution time: 0.3110
INFO - 2018-07-24 22:56:14 --> Config Class Initialized
INFO - 2018-07-24 22:56:14 --> Hooks Class Initialized
DEBUG - 2018-07-24 22:56:14 --> UTF-8 Support Enabled
INFO - 2018-07-24 22:56:14 --> Utf8 Class Initialized
INFO - 2018-07-24 22:56:14 --> URI Class Initialized
INFO - 2018-07-24 22:56:14 --> Router Class Initialized
INFO - 2018-07-24 22:56:14 --> Output Class Initialized
INFO - 2018-07-24 22:56:14 --> Security Class Initialized
DEBUG - 2018-07-24 22:56:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 22:56:14 --> Input Class Initialized
INFO - 2018-07-24 22:56:14 --> Language Class Initialized
INFO - 2018-07-24 22:56:14 --> Language Class Initialized
INFO - 2018-07-24 22:56:14 --> Config Class Initialized
INFO - 2018-07-24 22:56:14 --> Loader Class Initialized
DEBUG - 2018-07-24 22:56:14 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-24 22:56:14 --> Helper loaded: url_helper
INFO - 2018-07-24 22:56:14 --> Helper loaded: form_helper
INFO - 2018-07-24 22:56:14 --> Helper loaded: date_helper
INFO - 2018-07-24 22:56:14 --> Helper loaded: util_helper
INFO - 2018-07-24 22:56:14 --> Helper loaded: text_helper
INFO - 2018-07-24 22:56:14 --> Helper loaded: string_helper
INFO - 2018-07-24 22:56:15 --> Database Driver Class Initialized
DEBUG - 2018-07-24 22:56:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-24 22:56:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-24 22:56:15 --> Email Class Initialized
INFO - 2018-07-24 22:56:15 --> Controller Class Initialized
DEBUG - 2018-07-24 22:56:15 --> Home MX_Controller Initialized
DEBUG - 2018-07-24 22:56:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-07-24 22:56:18 --> Config Class Initialized
INFO - 2018-07-24 22:56:18 --> Hooks Class Initialized
DEBUG - 2018-07-24 22:56:18 --> UTF-8 Support Enabled
INFO - 2018-07-24 22:56:18 --> Utf8 Class Initialized
INFO - 2018-07-24 22:56:18 --> URI Class Initialized
INFO - 2018-07-24 22:56:18 --> Router Class Initialized
INFO - 2018-07-24 22:56:18 --> Output Class Initialized
INFO - 2018-07-24 22:56:18 --> Security Class Initialized
DEBUG - 2018-07-24 22:56:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 22:56:18 --> Input Class Initialized
INFO - 2018-07-24 22:56:18 --> Language Class Initialized
INFO - 2018-07-24 22:56:18 --> Language Class Initialized
INFO - 2018-07-24 22:56:18 --> Config Class Initialized
INFO - 2018-07-24 22:56:18 --> Loader Class Initialized
DEBUG - 2018-07-24 22:56:18 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-24 22:56:18 --> Helper loaded: url_helper
INFO - 2018-07-24 22:56:18 --> Helper loaded: form_helper
INFO - 2018-07-24 22:56:18 --> Helper loaded: date_helper
INFO - 2018-07-24 22:56:18 --> Helper loaded: util_helper
INFO - 2018-07-24 22:56:18 --> Helper loaded: text_helper
INFO - 2018-07-24 22:56:18 --> Helper loaded: string_helper
INFO - 2018-07-24 22:56:18 --> Database Driver Class Initialized
DEBUG - 2018-07-24 22:56:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-24 22:56:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-24 22:56:18 --> Email Class Initialized
INFO - 2018-07-24 22:56:18 --> Controller Class Initialized
DEBUG - 2018-07-24 22:56:18 --> Home MX_Controller Initialized
DEBUG - 2018-07-24 22:56:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-24 22:56:18 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-24 22:56:18 --> Login MX_Controller Initialized
INFO - 2018-07-24 22:56:18 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-24 22:56:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-24 22:56:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-24 22:56:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-07-24 22:56:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-07-24 22:56:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-07-24 22:56:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-07-24 22:56:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-07-24 22:56:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-07-24 22:56:18 --> Final output sent to browser
DEBUG - 2018-07-24 22:56:18 --> Total execution time: 0.4035
INFO - 2018-07-24 22:56:19 --> Config Class Initialized
INFO - 2018-07-24 22:56:19 --> Config Class Initialized
INFO - 2018-07-24 22:56:19 --> Hooks Class Initialized
INFO - 2018-07-24 22:56:19 --> Hooks Class Initialized
DEBUG - 2018-07-24 22:56:19 --> UTF-8 Support Enabled
INFO - 2018-07-24 22:56:19 --> Utf8 Class Initialized
INFO - 2018-07-24 22:56:19 --> URI Class Initialized
INFO - 2018-07-24 22:56:19 --> Router Class Initialized
INFO - 2018-07-24 22:56:19 --> Output Class Initialized
DEBUG - 2018-07-24 22:56:19 --> UTF-8 Support Enabled
INFO - 2018-07-24 22:56:19 --> Security Class Initialized
DEBUG - 2018-07-24 22:56:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 22:56:19 --> Input Class Initialized
INFO - 2018-07-24 22:56:19 --> Language Class Initialized
ERROR - 2018-07-24 22:56:19 --> 404 Page Not Found: /index
INFO - 2018-07-24 22:56:19 --> Utf8 Class Initialized
INFO - 2018-07-24 22:56:19 --> URI Class Initialized
INFO - 2018-07-24 22:56:19 --> Config Class Initialized
INFO - 2018-07-24 22:56:19 --> Router Class Initialized
INFO - 2018-07-24 22:56:19 --> Hooks Class Initialized
DEBUG - 2018-07-24 22:56:19 --> UTF-8 Support Enabled
INFO - 2018-07-24 22:56:19 --> Utf8 Class Initialized
INFO - 2018-07-24 22:56:19 --> URI Class Initialized
INFO - 2018-07-24 22:56:19 --> Output Class Initialized
INFO - 2018-07-24 22:56:19 --> Security Class Initialized
INFO - 2018-07-24 22:56:19 --> Router Class Initialized
DEBUG - 2018-07-24 22:56:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 22:56:19 --> Output Class Initialized
INFO - 2018-07-24 22:56:19 --> Input Class Initialized
INFO - 2018-07-24 22:56:19 --> Security Class Initialized
INFO - 2018-07-24 22:56:19 --> Language Class Initialized
DEBUG - 2018-07-24 22:56:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 22:56:19 --> Input Class Initialized
ERROR - 2018-07-24 22:56:19 --> 404 Page Not Found: /index
INFO - 2018-07-24 22:56:19 --> Language Class Initialized
ERROR - 2018-07-24 22:56:19 --> 404 Page Not Found: /index
INFO - 2018-07-24 22:56:19 --> Config Class Initialized
INFO - 2018-07-24 22:56:19 --> Hooks Class Initialized
DEBUG - 2018-07-24 22:56:19 --> UTF-8 Support Enabled
INFO - 2018-07-24 22:56:19 --> Utf8 Class Initialized
INFO - 2018-07-24 22:56:19 --> URI Class Initialized
INFO - 2018-07-24 22:56:19 --> Router Class Initialized
INFO - 2018-07-24 22:56:19 --> Output Class Initialized
INFO - 2018-07-24 22:56:19 --> Security Class Initialized
DEBUG - 2018-07-24 22:56:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 22:56:19 --> Input Class Initialized
INFO - 2018-07-24 22:56:19 --> Language Class Initialized
ERROR - 2018-07-24 22:56:19 --> 404 Page Not Found: /index
INFO - 2018-07-24 22:56:22 --> Config Class Initialized
INFO - 2018-07-24 22:56:22 --> Hooks Class Initialized
DEBUG - 2018-07-24 22:56:22 --> UTF-8 Support Enabled
INFO - 2018-07-24 22:56:22 --> Utf8 Class Initialized
INFO - 2018-07-24 22:56:22 --> URI Class Initialized
INFO - 2018-07-24 22:56:22 --> Router Class Initialized
INFO - 2018-07-24 22:56:22 --> Output Class Initialized
INFO - 2018-07-24 22:56:22 --> Security Class Initialized
DEBUG - 2018-07-24 22:56:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 22:56:22 --> Input Class Initialized
INFO - 2018-07-24 22:56:22 --> Language Class Initialized
ERROR - 2018-07-24 22:56:22 --> 404 Page Not Found: /index
INFO - 2018-07-24 22:56:22 --> Config Class Initialized
INFO - 2018-07-24 22:56:22 --> Hooks Class Initialized
DEBUG - 2018-07-24 22:56:22 --> UTF-8 Support Enabled
INFO - 2018-07-24 22:56:22 --> Utf8 Class Initialized
INFO - 2018-07-24 22:56:22 --> URI Class Initialized
INFO - 2018-07-24 22:56:22 --> Router Class Initialized
INFO - 2018-07-24 22:56:22 --> Output Class Initialized
INFO - 2018-07-24 22:56:22 --> Security Class Initialized
DEBUG - 2018-07-24 22:56:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 22:56:22 --> Input Class Initialized
INFO - 2018-07-24 22:56:22 --> Language Class Initialized
ERROR - 2018-07-24 22:56:22 --> 404 Page Not Found: /index
INFO - 2018-07-24 22:56:22 --> Config Class Initialized
INFO - 2018-07-24 22:56:22 --> Hooks Class Initialized
DEBUG - 2018-07-24 22:56:22 --> UTF-8 Support Enabled
INFO - 2018-07-24 22:56:22 --> Utf8 Class Initialized
INFO - 2018-07-24 22:56:22 --> URI Class Initialized
INFO - 2018-07-24 22:56:22 --> Router Class Initialized
INFO - 2018-07-24 22:56:22 --> Output Class Initialized
INFO - 2018-07-24 22:56:22 --> Security Class Initialized
DEBUG - 2018-07-24 22:56:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 22:56:22 --> Input Class Initialized
INFO - 2018-07-24 22:56:22 --> Language Class Initialized
ERROR - 2018-07-24 22:56:22 --> 404 Page Not Found: /index
INFO - 2018-07-24 22:56:33 --> Config Class Initialized
INFO - 2018-07-24 22:56:33 --> Hooks Class Initialized
INFO - 2018-07-24 22:56:33 --> Config Class Initialized
INFO - 2018-07-24 22:56:33 --> Hooks Class Initialized
DEBUG - 2018-07-24 22:56:33 --> UTF-8 Support Enabled
INFO - 2018-07-24 22:56:33 --> Utf8 Class Initialized
DEBUG - 2018-07-24 22:56:33 --> UTF-8 Support Enabled
INFO - 2018-07-24 22:56:33 --> Utf8 Class Initialized
INFO - 2018-07-24 22:56:33 --> URI Class Initialized
INFO - 2018-07-24 22:56:33 --> URI Class Initialized
INFO - 2018-07-24 22:56:33 --> Router Class Initialized
INFO - 2018-07-24 22:56:33 --> Output Class Initialized
INFO - 2018-07-24 22:56:33 --> Router Class Initialized
INFO - 2018-07-24 22:56:33 --> Security Class Initialized
INFO - 2018-07-24 22:56:33 --> Output Class Initialized
DEBUG - 2018-07-24 22:56:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 22:56:33 --> Security Class Initialized
INFO - 2018-07-24 22:56:33 --> Input Class Initialized
INFO - 2018-07-24 22:56:33 --> Language Class Initialized
DEBUG - 2018-07-24 22:56:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 22:56:33 --> Input Class Initialized
ERROR - 2018-07-24 22:56:33 --> 404 Page Not Found: /index
INFO - 2018-07-24 22:56:33 --> Language Class Initialized
INFO - 2018-07-24 22:56:33 --> Config Class Initialized
INFO - 2018-07-24 22:56:33 --> Hooks Class Initialized
ERROR - 2018-07-24 22:56:33 --> 404 Page Not Found: /index
DEBUG - 2018-07-24 22:56:33 --> UTF-8 Support Enabled
INFO - 2018-07-24 22:56:33 --> Utf8 Class Initialized
INFO - 2018-07-24 22:56:33 --> URI Class Initialized
INFO - 2018-07-24 22:56:33 --> Router Class Initialized
INFO - 2018-07-24 22:56:33 --> Output Class Initialized
INFO - 2018-07-24 22:56:33 --> Security Class Initialized
DEBUG - 2018-07-24 22:56:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 22:56:33 --> Input Class Initialized
INFO - 2018-07-24 22:56:34 --> Language Class Initialized
ERROR - 2018-07-24 22:56:34 --> 404 Page Not Found: /index
INFO - 2018-07-24 22:56:34 --> Config Class Initialized
INFO - 2018-07-24 22:56:34 --> Hooks Class Initialized
DEBUG - 2018-07-24 22:56:34 --> UTF-8 Support Enabled
INFO - 2018-07-24 22:56:34 --> Utf8 Class Initialized
INFO - 2018-07-24 22:56:34 --> URI Class Initialized
INFO - 2018-07-24 22:56:34 --> Router Class Initialized
INFO - 2018-07-24 22:56:34 --> Output Class Initialized
INFO - 2018-07-24 22:56:34 --> Security Class Initialized
DEBUG - 2018-07-24 22:56:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 22:56:34 --> Input Class Initialized
INFO - 2018-07-24 22:56:34 --> Language Class Initialized
ERROR - 2018-07-24 22:56:34 --> 404 Page Not Found: /index
INFO - 2018-07-24 22:56:35 --> Config Class Initialized
INFO - 2018-07-24 22:56:35 --> Hooks Class Initialized
DEBUG - 2018-07-24 22:56:35 --> UTF-8 Support Enabled
INFO - 2018-07-24 22:56:35 --> Utf8 Class Initialized
INFO - 2018-07-24 22:56:36 --> URI Class Initialized
INFO - 2018-07-24 22:56:36 --> Router Class Initialized
INFO - 2018-07-24 22:56:36 --> Output Class Initialized
INFO - 2018-07-24 22:56:36 --> Security Class Initialized
DEBUG - 2018-07-24 22:56:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 22:56:36 --> Input Class Initialized
INFO - 2018-07-24 22:56:36 --> Language Class Initialized
INFO - 2018-07-24 22:56:36 --> Language Class Initialized
INFO - 2018-07-24 22:56:36 --> Config Class Initialized
INFO - 2018-07-24 22:56:36 --> Loader Class Initialized
DEBUG - 2018-07-24 22:56:36 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-24 22:56:36 --> Helper loaded: url_helper
INFO - 2018-07-24 22:56:36 --> Helper loaded: form_helper
INFO - 2018-07-24 22:56:36 --> Helper loaded: date_helper
INFO - 2018-07-24 22:56:36 --> Helper loaded: util_helper
INFO - 2018-07-24 22:56:36 --> Helper loaded: text_helper
INFO - 2018-07-24 22:56:36 --> Helper loaded: string_helper
INFO - 2018-07-24 22:56:36 --> Database Driver Class Initialized
DEBUG - 2018-07-24 22:56:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-24 22:56:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-24 22:56:36 --> Email Class Initialized
INFO - 2018-07-24 22:56:36 --> Controller Class Initialized
DEBUG - 2018-07-24 22:56:36 --> Home MX_Controller Initialized
DEBUG - 2018-07-24 22:56:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-24 22:56:36 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-24 22:56:36 --> Login MX_Controller Initialized
INFO - 2018-07-24 22:56:36 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-24 22:56:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-24 22:56:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-24 22:56:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-07-24 22:56:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-07-24 22:56:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-07-24 22:56:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-07-24 22:56:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-07-24 22:56:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-07-24 22:56:36 --> Final output sent to browser
DEBUG - 2018-07-24 22:56:36 --> Total execution time: 0.3996
INFO - 2018-07-24 22:56:36 --> Config Class Initialized
INFO - 2018-07-24 22:56:36 --> Config Class Initialized
INFO - 2018-07-24 22:56:36 --> Hooks Class Initialized
INFO - 2018-07-24 22:56:36 --> Hooks Class Initialized
DEBUG - 2018-07-24 22:56:36 --> UTF-8 Support Enabled
DEBUG - 2018-07-24 22:56:36 --> UTF-8 Support Enabled
INFO - 2018-07-24 22:56:36 --> Utf8 Class Initialized
INFO - 2018-07-24 22:56:36 --> Utf8 Class Initialized
INFO - 2018-07-24 22:56:37 --> URI Class Initialized
INFO - 2018-07-24 22:56:37 --> URI Class Initialized
INFO - 2018-07-24 22:56:37 --> Router Class Initialized
INFO - 2018-07-24 22:56:37 --> Router Class Initialized
INFO - 2018-07-24 22:56:37 --> Output Class Initialized
INFO - 2018-07-24 22:56:37 --> Output Class Initialized
INFO - 2018-07-24 22:56:37 --> Security Class Initialized
DEBUG - 2018-07-24 22:56:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 22:56:37 --> Input Class Initialized
INFO - 2018-07-24 22:56:37 --> Security Class Initialized
INFO - 2018-07-24 22:56:37 --> Language Class Initialized
DEBUG - 2018-07-24 22:56:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-07-24 22:56:37 --> 404 Page Not Found: /index
INFO - 2018-07-24 22:56:37 --> Input Class Initialized
INFO - 2018-07-24 22:56:37 --> Language Class Initialized
ERROR - 2018-07-24 22:56:37 --> 404 Page Not Found: /index
INFO - 2018-07-24 22:56:37 --> Config Class Initialized
INFO - 2018-07-24 22:56:37 --> Hooks Class Initialized
DEBUG - 2018-07-24 22:56:37 --> UTF-8 Support Enabled
INFO - 2018-07-24 22:56:37 --> Utf8 Class Initialized
INFO - 2018-07-24 22:56:37 --> URI Class Initialized
INFO - 2018-07-24 22:56:37 --> Router Class Initialized
INFO - 2018-07-24 22:56:37 --> Output Class Initialized
INFO - 2018-07-24 22:56:37 --> Security Class Initialized
DEBUG - 2018-07-24 22:56:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 22:56:37 --> Input Class Initialized
INFO - 2018-07-24 22:56:37 --> Language Class Initialized
ERROR - 2018-07-24 22:56:37 --> 404 Page Not Found: /index
INFO - 2018-07-24 22:56:37 --> Config Class Initialized
INFO - 2018-07-24 22:56:37 --> Hooks Class Initialized
DEBUG - 2018-07-24 22:56:37 --> UTF-8 Support Enabled
INFO - 2018-07-24 22:56:37 --> Utf8 Class Initialized
INFO - 2018-07-24 22:56:37 --> URI Class Initialized
INFO - 2018-07-24 22:56:37 --> Router Class Initialized
INFO - 2018-07-24 22:56:37 --> Output Class Initialized
INFO - 2018-07-24 22:56:37 --> Security Class Initialized
DEBUG - 2018-07-24 22:56:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 22:56:37 --> Input Class Initialized
INFO - 2018-07-24 22:56:37 --> Language Class Initialized
ERROR - 2018-07-24 22:56:37 --> 404 Page Not Found: /index
INFO - 2018-07-24 22:56:38 --> Config Class Initialized
INFO - 2018-07-24 22:56:38 --> Hooks Class Initialized
DEBUG - 2018-07-24 22:56:38 --> UTF-8 Support Enabled
INFO - 2018-07-24 22:56:38 --> Utf8 Class Initialized
INFO - 2018-07-24 22:56:38 --> URI Class Initialized
INFO - 2018-07-24 22:56:38 --> Router Class Initialized
INFO - 2018-07-24 22:56:38 --> Output Class Initialized
INFO - 2018-07-24 22:56:38 --> Security Class Initialized
DEBUG - 2018-07-24 22:56:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 22:56:38 --> Input Class Initialized
INFO - 2018-07-24 22:56:38 --> Language Class Initialized
ERROR - 2018-07-24 22:56:38 --> 404 Page Not Found: /index
INFO - 2018-07-24 22:56:38 --> Config Class Initialized
INFO - 2018-07-24 22:56:38 --> Hooks Class Initialized
DEBUG - 2018-07-24 22:56:38 --> UTF-8 Support Enabled
INFO - 2018-07-24 22:56:38 --> Utf8 Class Initialized
INFO - 2018-07-24 22:56:38 --> URI Class Initialized
INFO - 2018-07-24 22:56:38 --> Router Class Initialized
INFO - 2018-07-24 22:56:38 --> Output Class Initialized
INFO - 2018-07-24 22:56:38 --> Security Class Initialized
DEBUG - 2018-07-24 22:56:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 22:56:38 --> Input Class Initialized
INFO - 2018-07-24 22:56:38 --> Language Class Initialized
ERROR - 2018-07-24 22:56:38 --> 404 Page Not Found: /index
INFO - 2018-07-24 22:56:38 --> Config Class Initialized
INFO - 2018-07-24 22:56:38 --> Hooks Class Initialized
DEBUG - 2018-07-24 22:56:38 --> UTF-8 Support Enabled
INFO - 2018-07-24 22:56:38 --> Utf8 Class Initialized
INFO - 2018-07-24 22:56:38 --> URI Class Initialized
INFO - 2018-07-24 22:56:38 --> Router Class Initialized
INFO - 2018-07-24 22:56:38 --> Output Class Initialized
INFO - 2018-07-24 22:56:38 --> Security Class Initialized
DEBUG - 2018-07-24 22:56:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 22:56:38 --> Input Class Initialized
INFO - 2018-07-24 22:56:38 --> Language Class Initialized
ERROR - 2018-07-24 22:56:38 --> 404 Page Not Found: /index
INFO - 2018-07-24 23:08:21 --> Config Class Initialized
INFO - 2018-07-24 23:08:21 --> Hooks Class Initialized
DEBUG - 2018-07-24 23:08:21 --> UTF-8 Support Enabled
INFO - 2018-07-24 23:08:21 --> Utf8 Class Initialized
INFO - 2018-07-24 23:08:21 --> URI Class Initialized
DEBUG - 2018-07-24 23:08:21 --> No URI present. Default controller set.
INFO - 2018-07-24 23:08:21 --> Router Class Initialized
INFO - 2018-07-24 23:08:21 --> Output Class Initialized
INFO - 2018-07-24 23:08:21 --> Security Class Initialized
DEBUG - 2018-07-24 23:08:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 23:08:21 --> Input Class Initialized
INFO - 2018-07-24 23:08:21 --> Language Class Initialized
INFO - 2018-07-24 23:08:21 --> Language Class Initialized
INFO - 2018-07-24 23:08:21 --> Config Class Initialized
INFO - 2018-07-24 23:08:21 --> Loader Class Initialized
DEBUG - 2018-07-24 23:08:21 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-24 23:08:21 --> Helper loaded: url_helper
INFO - 2018-07-24 23:08:21 --> Helper loaded: form_helper
INFO - 2018-07-24 23:08:21 --> Helper loaded: date_helper
INFO - 2018-07-24 23:08:21 --> Helper loaded: util_helper
INFO - 2018-07-24 23:08:21 --> Helper loaded: text_helper
INFO - 2018-07-24 23:08:21 --> Helper loaded: string_helper
INFO - 2018-07-24 23:08:21 --> Database Driver Class Initialized
DEBUG - 2018-07-24 23:08:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-24 23:08:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-24 23:08:21 --> Email Class Initialized
INFO - 2018-07-24 23:08:21 --> Controller Class Initialized
DEBUG - 2018-07-24 23:08:21 --> Home MX_Controller Initialized
DEBUG - 2018-07-24 23:08:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-24 23:08:21 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-24 23:08:21 --> Login MX_Controller Initialized
INFO - 2018-07-24 23:08:21 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-24 23:08:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-24 23:08:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-24 23:08:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/login.php
INFO - 2018-07-24 23:08:28 --> Config Class Initialized
INFO - 2018-07-24 23:08:28 --> Hooks Class Initialized
DEBUG - 2018-07-24 23:08:28 --> UTF-8 Support Enabled
INFO - 2018-07-24 23:08:28 --> Utf8 Class Initialized
INFO - 2018-07-24 23:08:28 --> URI Class Initialized
INFO - 2018-07-24 23:08:28 --> Router Class Initialized
INFO - 2018-07-24 23:08:28 --> Output Class Initialized
INFO - 2018-07-24 23:08:28 --> Security Class Initialized
DEBUG - 2018-07-24 23:08:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 23:08:28 --> Input Class Initialized
INFO - 2018-07-24 23:08:28 --> Language Class Initialized
INFO - 2018-07-24 23:08:29 --> Language Class Initialized
INFO - 2018-07-24 23:08:29 --> Config Class Initialized
INFO - 2018-07-24 23:08:29 --> Loader Class Initialized
DEBUG - 2018-07-24 23:08:29 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-24 23:08:29 --> Helper loaded: url_helper
INFO - 2018-07-24 23:08:29 --> Helper loaded: form_helper
INFO - 2018-07-24 23:08:29 --> Helper loaded: date_helper
INFO - 2018-07-24 23:08:29 --> Helper loaded: util_helper
INFO - 2018-07-24 23:08:29 --> Helper loaded: text_helper
INFO - 2018-07-24 23:08:29 --> Helper loaded: string_helper
INFO - 2018-07-24 23:08:29 --> Database Driver Class Initialized
DEBUG - 2018-07-24 23:08:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-24 23:08:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-24 23:08:29 --> Email Class Initialized
INFO - 2018-07-24 23:08:29 --> Controller Class Initialized
DEBUG - 2018-07-24 23:08:29 --> Login MX_Controller Initialized
INFO - 2018-07-24 23:08:29 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-24 23:08:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-24 23:08:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-24 23:08:29 --> Email starts for user@colin.com fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-07-24 23:08:29 --> User session created for 4
INFO - 2018-07-24 23:08:29 --> Login status user@colin.com - success
INFO - 2018-07-24 23:08:29 --> Final output sent to browser
DEBUG - 2018-07-24 23:08:29 --> Total execution time: 0.3898
INFO - 2018-07-24 23:08:29 --> Config Class Initialized
INFO - 2018-07-24 23:08:29 --> Hooks Class Initialized
DEBUG - 2018-07-24 23:08:29 --> UTF-8 Support Enabled
INFO - 2018-07-24 23:08:29 --> Utf8 Class Initialized
INFO - 2018-07-24 23:08:29 --> URI Class Initialized
DEBUG - 2018-07-24 23:08:29 --> No URI present. Default controller set.
INFO - 2018-07-24 23:08:29 --> Router Class Initialized
INFO - 2018-07-24 23:08:29 --> Output Class Initialized
INFO - 2018-07-24 23:08:29 --> Security Class Initialized
DEBUG - 2018-07-24 23:08:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 23:08:29 --> Input Class Initialized
INFO - 2018-07-24 23:08:29 --> Language Class Initialized
INFO - 2018-07-24 23:08:29 --> Language Class Initialized
INFO - 2018-07-24 23:08:29 --> Config Class Initialized
INFO - 2018-07-24 23:08:29 --> Loader Class Initialized
DEBUG - 2018-07-24 23:08:29 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-24 23:08:29 --> Helper loaded: url_helper
INFO - 2018-07-24 23:08:29 --> Helper loaded: form_helper
INFO - 2018-07-24 23:08:29 --> Helper loaded: date_helper
INFO - 2018-07-24 23:08:29 --> Helper loaded: util_helper
INFO - 2018-07-24 23:08:29 --> Helper loaded: text_helper
INFO - 2018-07-24 23:08:29 --> Helper loaded: string_helper
INFO - 2018-07-24 23:08:29 --> Database Driver Class Initialized
DEBUG - 2018-07-24 23:08:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-24 23:08:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-24 23:08:29 --> Email Class Initialized
INFO - 2018-07-24 23:08:29 --> Controller Class Initialized
DEBUG - 2018-07-24 23:08:29 --> Home MX_Controller Initialized
DEBUG - 2018-07-24 23:08:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-24 23:08:29 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-24 23:08:29 --> Login MX_Controller Initialized
INFO - 2018-07-24 23:08:29 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-24 23:08:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-24 23:08:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-24 23:08:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-07-24 23:08:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-07-24 23:08:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-07-24 23:08:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-07-24 23:08:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-07-24 23:08:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-07-24 23:08:29 --> Final output sent to browser
DEBUG - 2018-07-24 23:08:29 --> Total execution time: 0.4850
INFO - 2018-07-24 23:08:31 --> Config Class Initialized
INFO - 2018-07-24 23:08:31 --> Hooks Class Initialized
DEBUG - 2018-07-24 23:08:31 --> UTF-8 Support Enabled
INFO - 2018-07-24 23:08:31 --> Utf8 Class Initialized
INFO - 2018-07-24 23:08:31 --> URI Class Initialized
INFO - 2018-07-24 23:08:31 --> Router Class Initialized
INFO - 2018-07-24 23:08:31 --> Output Class Initialized
INFO - 2018-07-24 23:08:31 --> Security Class Initialized
DEBUG - 2018-07-24 23:08:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 23:08:31 --> Input Class Initialized
INFO - 2018-07-24 23:08:31 --> Language Class Initialized
ERROR - 2018-07-24 23:08:31 --> 404 Page Not Found: /index
INFO - 2018-07-24 23:08:31 --> Config Class Initialized
INFO - 2018-07-24 23:08:31 --> Hooks Class Initialized
DEBUG - 2018-07-24 23:08:31 --> UTF-8 Support Enabled
INFO - 2018-07-24 23:08:31 --> Utf8 Class Initialized
INFO - 2018-07-24 23:08:31 --> URI Class Initialized
INFO - 2018-07-24 23:08:31 --> Router Class Initialized
INFO - 2018-07-24 23:08:31 --> Output Class Initialized
INFO - 2018-07-24 23:08:31 --> Security Class Initialized
DEBUG - 2018-07-24 23:08:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 23:08:31 --> Input Class Initialized
INFO - 2018-07-24 23:08:31 --> Language Class Initialized
ERROR - 2018-07-24 23:08:31 --> 404 Page Not Found: /index
INFO - 2018-07-24 23:08:31 --> Config Class Initialized
INFO - 2018-07-24 23:08:31 --> Hooks Class Initialized
DEBUG - 2018-07-24 23:08:31 --> UTF-8 Support Enabled
INFO - 2018-07-24 23:08:31 --> Utf8 Class Initialized
INFO - 2018-07-24 23:08:31 --> URI Class Initialized
INFO - 2018-07-24 23:08:31 --> Router Class Initialized
INFO - 2018-07-24 23:08:31 --> Output Class Initialized
INFO - 2018-07-24 23:08:31 --> Security Class Initialized
DEBUG - 2018-07-24 23:08:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 23:08:31 --> Input Class Initialized
INFO - 2018-07-24 23:08:31 --> Language Class Initialized
ERROR - 2018-07-24 23:08:31 --> 404 Page Not Found: /index
INFO - 2018-07-24 23:08:47 --> Config Class Initialized
INFO - 2018-07-24 23:08:47 --> Hooks Class Initialized
DEBUG - 2018-07-24 23:08:47 --> UTF-8 Support Enabled
INFO - 2018-07-24 23:08:47 --> Utf8 Class Initialized
INFO - 2018-07-24 23:08:47 --> URI Class Initialized
INFO - 2018-07-24 23:08:47 --> Router Class Initialized
INFO - 2018-07-24 23:08:47 --> Output Class Initialized
INFO - 2018-07-24 23:08:47 --> Security Class Initialized
DEBUG - 2018-07-24 23:08:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 23:08:47 --> Input Class Initialized
INFO - 2018-07-24 23:08:47 --> Language Class Initialized
ERROR - 2018-07-24 23:08:47 --> 404 Page Not Found: /index
INFO - 2018-07-24 23:08:47 --> Config Class Initialized
INFO - 2018-07-24 23:08:47 --> Hooks Class Initialized
DEBUG - 2018-07-24 23:08:47 --> UTF-8 Support Enabled
INFO - 2018-07-24 23:08:47 --> Utf8 Class Initialized
INFO - 2018-07-24 23:08:47 --> URI Class Initialized
INFO - 2018-07-24 23:08:47 --> Router Class Initialized
INFO - 2018-07-24 23:08:47 --> Output Class Initialized
INFO - 2018-07-24 23:08:47 --> Security Class Initialized
DEBUG - 2018-07-24 23:08:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 23:08:47 --> Input Class Initialized
INFO - 2018-07-24 23:08:47 --> Language Class Initialized
ERROR - 2018-07-24 23:08:47 --> 404 Page Not Found: /index
INFO - 2018-07-24 23:08:47 --> Config Class Initialized
INFO - 2018-07-24 23:08:47 --> Hooks Class Initialized
DEBUG - 2018-07-24 23:08:47 --> UTF-8 Support Enabled
INFO - 2018-07-24 23:08:47 --> Utf8 Class Initialized
INFO - 2018-07-24 23:08:47 --> URI Class Initialized
INFO - 2018-07-24 23:08:47 --> Router Class Initialized
INFO - 2018-07-24 23:08:47 --> Output Class Initialized
INFO - 2018-07-24 23:08:47 --> Security Class Initialized
DEBUG - 2018-07-24 23:08:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 23:08:47 --> Input Class Initialized
INFO - 2018-07-24 23:08:47 --> Language Class Initialized
ERROR - 2018-07-24 23:08:47 --> 404 Page Not Found: /index
INFO - 2018-07-24 23:08:52 --> Config Class Initialized
INFO - 2018-07-24 23:08:52 --> Hooks Class Initialized
DEBUG - 2018-07-24 23:08:52 --> UTF-8 Support Enabled
INFO - 2018-07-24 23:08:52 --> Utf8 Class Initialized
INFO - 2018-07-24 23:08:52 --> URI Class Initialized
INFO - 2018-07-24 23:08:52 --> Router Class Initialized
INFO - 2018-07-24 23:08:52 --> Output Class Initialized
INFO - 2018-07-24 23:08:52 --> Security Class Initialized
DEBUG - 2018-07-24 23:08:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 23:08:52 --> Input Class Initialized
INFO - 2018-07-24 23:08:52 --> Language Class Initialized
ERROR - 2018-07-24 23:08:52 --> 404 Page Not Found: /index
INFO - 2018-07-24 23:08:52 --> Config Class Initialized
INFO - 2018-07-24 23:08:52 --> Hooks Class Initialized
DEBUG - 2018-07-24 23:08:52 --> UTF-8 Support Enabled
INFO - 2018-07-24 23:08:52 --> Utf8 Class Initialized
INFO - 2018-07-24 23:08:52 --> URI Class Initialized
INFO - 2018-07-24 23:08:52 --> Router Class Initialized
INFO - 2018-07-24 23:08:52 --> Output Class Initialized
INFO - 2018-07-24 23:08:52 --> Security Class Initialized
DEBUG - 2018-07-24 23:08:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 23:08:52 --> Input Class Initialized
INFO - 2018-07-24 23:08:52 --> Language Class Initialized
ERROR - 2018-07-24 23:08:52 --> 404 Page Not Found: /index
INFO - 2018-07-24 23:08:52 --> Config Class Initialized
INFO - 2018-07-24 23:08:52 --> Hooks Class Initialized
DEBUG - 2018-07-24 23:08:52 --> UTF-8 Support Enabled
INFO - 2018-07-24 23:08:52 --> Utf8 Class Initialized
INFO - 2018-07-24 23:08:52 --> URI Class Initialized
INFO - 2018-07-24 23:08:52 --> Router Class Initialized
INFO - 2018-07-24 23:08:52 --> Output Class Initialized
INFO - 2018-07-24 23:08:52 --> Security Class Initialized
DEBUG - 2018-07-24 23:08:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 23:08:52 --> Input Class Initialized
INFO - 2018-07-24 23:08:52 --> Language Class Initialized
ERROR - 2018-07-24 23:08:52 --> 404 Page Not Found: /index
INFO - 2018-07-24 23:08:54 --> Config Class Initialized
INFO - 2018-07-24 23:08:54 --> Hooks Class Initialized
DEBUG - 2018-07-24 23:08:54 --> UTF-8 Support Enabled
INFO - 2018-07-24 23:08:54 --> Utf8 Class Initialized
INFO - 2018-07-24 23:08:54 --> URI Class Initialized
INFO - 2018-07-24 23:08:54 --> Router Class Initialized
INFO - 2018-07-24 23:08:54 --> Output Class Initialized
INFO - 2018-07-24 23:08:54 --> Security Class Initialized
DEBUG - 2018-07-24 23:08:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 23:08:54 --> Input Class Initialized
INFO - 2018-07-24 23:08:54 --> Language Class Initialized
ERROR - 2018-07-24 23:08:54 --> 404 Page Not Found: /index
INFO - 2018-07-24 23:08:54 --> Config Class Initialized
INFO - 2018-07-24 23:08:54 --> Hooks Class Initialized
DEBUG - 2018-07-24 23:08:54 --> UTF-8 Support Enabled
INFO - 2018-07-24 23:08:54 --> Utf8 Class Initialized
INFO - 2018-07-24 23:08:54 --> URI Class Initialized
INFO - 2018-07-24 23:08:54 --> Router Class Initialized
INFO - 2018-07-24 23:08:54 --> Output Class Initialized
INFO - 2018-07-24 23:08:54 --> Security Class Initialized
DEBUG - 2018-07-24 23:08:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 23:08:54 --> Input Class Initialized
INFO - 2018-07-24 23:08:54 --> Language Class Initialized
ERROR - 2018-07-24 23:08:54 --> 404 Page Not Found: /index
INFO - 2018-07-24 23:08:54 --> Config Class Initialized
INFO - 2018-07-24 23:08:54 --> Hooks Class Initialized
DEBUG - 2018-07-24 23:08:54 --> UTF-8 Support Enabled
INFO - 2018-07-24 23:08:54 --> Utf8 Class Initialized
INFO - 2018-07-24 23:08:54 --> URI Class Initialized
INFO - 2018-07-24 23:08:54 --> Router Class Initialized
INFO - 2018-07-24 23:08:54 --> Output Class Initialized
INFO - 2018-07-24 23:08:54 --> Security Class Initialized
DEBUG - 2018-07-24 23:08:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 23:08:54 --> Input Class Initialized
INFO - 2018-07-24 23:08:54 --> Language Class Initialized
ERROR - 2018-07-24 23:08:54 --> 404 Page Not Found: /index
INFO - 2018-07-24 23:09:16 --> Config Class Initialized
INFO - 2018-07-24 23:09:16 --> Hooks Class Initialized
DEBUG - 2018-07-24 23:09:16 --> UTF-8 Support Enabled
INFO - 2018-07-24 23:09:16 --> Utf8 Class Initialized
INFO - 2018-07-24 23:09:16 --> URI Class Initialized
INFO - 2018-07-24 23:09:16 --> Router Class Initialized
INFO - 2018-07-24 23:09:16 --> Output Class Initialized
INFO - 2018-07-24 23:09:16 --> Security Class Initialized
DEBUG - 2018-07-24 23:09:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 23:09:16 --> Input Class Initialized
INFO - 2018-07-24 23:09:16 --> Language Class Initialized
ERROR - 2018-07-24 23:09:16 --> 404 Page Not Found: /index
INFO - 2018-07-24 23:09:16 --> Config Class Initialized
INFO - 2018-07-24 23:09:16 --> Hooks Class Initialized
DEBUG - 2018-07-24 23:09:16 --> UTF-8 Support Enabled
INFO - 2018-07-24 23:09:16 --> Utf8 Class Initialized
INFO - 2018-07-24 23:09:16 --> URI Class Initialized
INFO - 2018-07-24 23:09:17 --> Router Class Initialized
INFO - 2018-07-24 23:09:17 --> Output Class Initialized
INFO - 2018-07-24 23:09:17 --> Security Class Initialized
DEBUG - 2018-07-24 23:09:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 23:09:17 --> Input Class Initialized
INFO - 2018-07-24 23:09:17 --> Language Class Initialized
ERROR - 2018-07-24 23:09:17 --> 404 Page Not Found: /index
INFO - 2018-07-24 23:09:17 --> Config Class Initialized
INFO - 2018-07-24 23:09:17 --> Hooks Class Initialized
DEBUG - 2018-07-24 23:09:17 --> UTF-8 Support Enabled
INFO - 2018-07-24 23:09:17 --> Utf8 Class Initialized
INFO - 2018-07-24 23:09:17 --> URI Class Initialized
INFO - 2018-07-24 23:09:17 --> Router Class Initialized
INFO - 2018-07-24 23:09:17 --> Output Class Initialized
INFO - 2018-07-24 23:09:17 --> Security Class Initialized
DEBUG - 2018-07-24 23:09:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 23:09:17 --> Input Class Initialized
INFO - 2018-07-24 23:09:17 --> Language Class Initialized
ERROR - 2018-07-24 23:09:17 --> 404 Page Not Found: /index
INFO - 2018-07-24 23:09:17 --> Config Class Initialized
INFO - 2018-07-24 23:09:17 --> Hooks Class Initialized
DEBUG - 2018-07-24 23:09:17 --> UTF-8 Support Enabled
INFO - 2018-07-24 23:09:17 --> Utf8 Class Initialized
INFO - 2018-07-24 23:09:17 --> URI Class Initialized
INFO - 2018-07-24 23:09:17 --> Router Class Initialized
INFO - 2018-07-24 23:09:17 --> Output Class Initialized
INFO - 2018-07-24 23:09:17 --> Security Class Initialized
DEBUG - 2018-07-24 23:09:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 23:09:17 --> Input Class Initialized
INFO - 2018-07-24 23:09:17 --> Language Class Initialized
ERROR - 2018-07-24 23:09:17 --> 404 Page Not Found: /index
INFO - 2018-07-24 23:09:17 --> Config Class Initialized
INFO - 2018-07-24 23:09:17 --> Hooks Class Initialized
DEBUG - 2018-07-24 23:09:17 --> UTF-8 Support Enabled
INFO - 2018-07-24 23:09:17 --> Utf8 Class Initialized
INFO - 2018-07-24 23:09:17 --> URI Class Initialized
INFO - 2018-07-24 23:09:17 --> Router Class Initialized
INFO - 2018-07-24 23:09:17 --> Output Class Initialized
INFO - 2018-07-24 23:09:17 --> Security Class Initialized
DEBUG - 2018-07-24 23:09:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 23:09:17 --> Input Class Initialized
INFO - 2018-07-24 23:09:17 --> Language Class Initialized
ERROR - 2018-07-24 23:09:17 --> 404 Page Not Found: /index
INFO - 2018-07-24 23:09:17 --> Config Class Initialized
INFO - 2018-07-24 23:09:17 --> Hooks Class Initialized
DEBUG - 2018-07-24 23:09:17 --> UTF-8 Support Enabled
INFO - 2018-07-24 23:09:17 --> Utf8 Class Initialized
INFO - 2018-07-24 23:09:17 --> URI Class Initialized
INFO - 2018-07-24 23:09:17 --> Router Class Initialized
INFO - 2018-07-24 23:09:17 --> Output Class Initialized
INFO - 2018-07-24 23:09:17 --> Security Class Initialized
DEBUG - 2018-07-24 23:09:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 23:09:17 --> Input Class Initialized
INFO - 2018-07-24 23:09:17 --> Language Class Initialized
ERROR - 2018-07-24 23:09:17 --> 404 Page Not Found: /index
INFO - 2018-07-24 23:09:50 --> Config Class Initialized
INFO - 2018-07-24 23:09:50 --> Hooks Class Initialized
DEBUG - 2018-07-24 23:09:50 --> UTF-8 Support Enabled
INFO - 2018-07-24 23:09:50 --> Utf8 Class Initialized
INFO - 2018-07-24 23:09:50 --> URI Class Initialized
INFO - 2018-07-24 23:09:50 --> Router Class Initialized
INFO - 2018-07-24 23:09:50 --> Output Class Initialized
INFO - 2018-07-24 23:09:50 --> Security Class Initialized
DEBUG - 2018-07-24 23:09:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 23:09:50 --> Input Class Initialized
INFO - 2018-07-24 23:09:50 --> Language Class Initialized
ERROR - 2018-07-24 23:09:50 --> 404 Page Not Found: /index
INFO - 2018-07-24 23:19:01 --> Config Class Initialized
INFO - 2018-07-24 23:19:01 --> Hooks Class Initialized
DEBUG - 2018-07-24 23:19:01 --> UTF-8 Support Enabled
INFO - 2018-07-24 23:19:01 --> Utf8 Class Initialized
INFO - 2018-07-24 23:19:01 --> URI Class Initialized
INFO - 2018-07-24 23:19:01 --> Router Class Initialized
INFO - 2018-07-24 23:19:01 --> Output Class Initialized
INFO - 2018-07-24 23:19:01 --> Security Class Initialized
DEBUG - 2018-07-24 23:19:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 23:19:01 --> Input Class Initialized
INFO - 2018-07-24 23:19:01 --> Language Class Initialized
INFO - 2018-07-24 23:19:01 --> Language Class Initialized
INFO - 2018-07-24 23:19:01 --> Config Class Initialized
INFO - 2018-07-24 23:19:01 --> Loader Class Initialized
DEBUG - 2018-07-24 23:19:01 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-24 23:19:01 --> Helper loaded: url_helper
INFO - 2018-07-24 23:19:01 --> Helper loaded: form_helper
INFO - 2018-07-24 23:19:01 --> Helper loaded: date_helper
INFO - 2018-07-24 23:19:01 --> Helper loaded: util_helper
INFO - 2018-07-24 23:19:01 --> Helper loaded: text_helper
INFO - 2018-07-24 23:19:01 --> Helper loaded: string_helper
INFO - 2018-07-24 23:19:01 --> Database Driver Class Initialized
DEBUG - 2018-07-24 23:19:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-24 23:19:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-24 23:19:01 --> Email Class Initialized
INFO - 2018-07-24 23:19:02 --> Controller Class Initialized
DEBUG - 2018-07-24 23:19:02 --> Home MX_Controller Initialized
DEBUG - 2018-07-24 23:19:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-24 23:19:02 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-24 23:19:02 --> Login MX_Controller Initialized
INFO - 2018-07-24 23:19:02 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-24 23:19:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-24 23:19:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-24 23:19:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-07-24 23:19:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-07-24 23:19:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-07-24 23:19:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-07-24 23:19:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-07-24 23:19:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-07-24 23:19:02 --> Final output sent to browser
DEBUG - 2018-07-24 23:19:02 --> Total execution time: 0.4448
INFO - 2018-07-24 23:19:02 --> Config Class Initialized
INFO - 2018-07-24 23:19:02 --> Config Class Initialized
INFO - 2018-07-24 23:19:02 --> Hooks Class Initialized
INFO - 2018-07-24 23:19:02 --> Hooks Class Initialized
DEBUG - 2018-07-24 23:19:02 --> UTF-8 Support Enabled
DEBUG - 2018-07-24 23:19:02 --> UTF-8 Support Enabled
INFO - 2018-07-24 23:19:02 --> Utf8 Class Initialized
INFO - 2018-07-24 23:19:02 --> Utf8 Class Initialized
INFO - 2018-07-24 23:19:02 --> URI Class Initialized
INFO - 2018-07-24 23:19:02 --> URI Class Initialized
INFO - 2018-07-24 23:19:02 --> Router Class Initialized
INFO - 2018-07-24 23:19:02 --> Router Class Initialized
INFO - 2018-07-24 23:19:02 --> Output Class Initialized
INFO - 2018-07-24 23:19:02 --> Output Class Initialized
INFO - 2018-07-24 23:19:02 --> Security Class Initialized
INFO - 2018-07-24 23:19:02 --> Security Class Initialized
DEBUG - 2018-07-24 23:19:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 23:19:02 --> Input Class Initialized
INFO - 2018-07-24 23:19:03 --> Language Class Initialized
ERROR - 2018-07-24 23:19:03 --> 404 Page Not Found: /index
DEBUG - 2018-07-24 23:19:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 23:19:03 --> Input Class Initialized
INFO - 2018-07-24 23:19:03 --> Language Class Initialized
ERROR - 2018-07-24 23:19:03 --> 404 Page Not Found: /index
INFO - 2018-07-24 23:19:03 --> Config Class Initialized
INFO - 2018-07-24 23:19:03 --> Hooks Class Initialized
DEBUG - 2018-07-24 23:19:03 --> UTF-8 Support Enabled
INFO - 2018-07-24 23:19:03 --> Utf8 Class Initialized
INFO - 2018-07-24 23:19:03 --> URI Class Initialized
INFO - 2018-07-24 23:19:03 --> Router Class Initialized
INFO - 2018-07-24 23:19:03 --> Output Class Initialized
INFO - 2018-07-24 23:19:03 --> Security Class Initialized
DEBUG - 2018-07-24 23:19:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 23:19:03 --> Input Class Initialized
INFO - 2018-07-24 23:19:03 --> Language Class Initialized
ERROR - 2018-07-24 23:19:03 --> 404 Page Not Found: /index
INFO - 2018-07-24 23:19:03 --> Config Class Initialized
INFO - 2018-07-24 23:19:03 --> Hooks Class Initialized
DEBUG - 2018-07-24 23:19:03 --> UTF-8 Support Enabled
INFO - 2018-07-24 23:19:03 --> Utf8 Class Initialized
INFO - 2018-07-24 23:19:03 --> URI Class Initialized
INFO - 2018-07-24 23:19:03 --> Router Class Initialized
INFO - 2018-07-24 23:19:03 --> Output Class Initialized
INFO - 2018-07-24 23:19:03 --> Security Class Initialized
DEBUG - 2018-07-24 23:19:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 23:19:03 --> Input Class Initialized
INFO - 2018-07-24 23:19:03 --> Language Class Initialized
ERROR - 2018-07-24 23:19:03 --> 404 Page Not Found: /index
INFO - 2018-07-24 23:19:27 --> Config Class Initialized
INFO - 2018-07-24 23:19:27 --> Hooks Class Initialized
DEBUG - 2018-07-24 23:19:27 --> UTF-8 Support Enabled
INFO - 2018-07-24 23:19:27 --> Utf8 Class Initialized
INFO - 2018-07-24 23:19:27 --> URI Class Initialized
DEBUG - 2018-07-24 23:19:27 --> No URI present. Default controller set.
INFO - 2018-07-24 23:19:27 --> Router Class Initialized
INFO - 2018-07-24 23:19:27 --> Output Class Initialized
INFO - 2018-07-24 23:19:27 --> Security Class Initialized
DEBUG - 2018-07-24 23:19:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 23:19:27 --> Input Class Initialized
INFO - 2018-07-24 23:19:27 --> Language Class Initialized
INFO - 2018-07-24 23:19:28 --> Language Class Initialized
INFO - 2018-07-24 23:19:28 --> Config Class Initialized
INFO - 2018-07-24 23:19:28 --> Loader Class Initialized
DEBUG - 2018-07-24 23:19:28 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-24 23:19:28 --> Helper loaded: url_helper
INFO - 2018-07-24 23:19:28 --> Helper loaded: form_helper
INFO - 2018-07-24 23:19:28 --> Helper loaded: date_helper
INFO - 2018-07-24 23:19:28 --> Helper loaded: util_helper
INFO - 2018-07-24 23:19:28 --> Helper loaded: text_helper
INFO - 2018-07-24 23:19:28 --> Helper loaded: string_helper
INFO - 2018-07-24 23:19:28 --> Database Driver Class Initialized
DEBUG - 2018-07-24 23:19:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-24 23:19:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-24 23:19:28 --> Email Class Initialized
INFO - 2018-07-24 23:19:28 --> Controller Class Initialized
DEBUG - 2018-07-24 23:19:28 --> Home MX_Controller Initialized
DEBUG - 2018-07-24 23:19:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-24 23:19:28 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-24 23:19:28 --> Login MX_Controller Initialized
INFO - 2018-07-24 23:19:28 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-24 23:19:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-24 23:19:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-24 23:19:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-07-24 23:19:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-07-24 23:19:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-07-24 23:19:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-07-24 23:19:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-07-24 23:19:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-07-24 23:19:28 --> Final output sent to browser
DEBUG - 2018-07-24 23:19:28 --> Total execution time: 0.4331
INFO - 2018-07-24 23:19:28 --> Config Class Initialized
INFO - 2018-07-24 23:19:28 --> Hooks Class Initialized
DEBUG - 2018-07-24 23:19:28 --> UTF-8 Support Enabled
INFO - 2018-07-24 23:19:28 --> Utf8 Class Initialized
INFO - 2018-07-24 23:19:28 --> URI Class Initialized
INFO - 2018-07-24 23:19:28 --> Router Class Initialized
INFO - 2018-07-24 23:19:28 --> Output Class Initialized
INFO - 2018-07-24 23:19:28 --> Security Class Initialized
DEBUG - 2018-07-24 23:19:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 23:19:29 --> Input Class Initialized
INFO - 2018-07-24 23:19:29 --> Language Class Initialized
ERROR - 2018-07-24 23:19:29 --> 404 Page Not Found: /index
INFO - 2018-07-24 23:19:29 --> Config Class Initialized
INFO - 2018-07-24 23:19:29 --> Hooks Class Initialized
DEBUG - 2018-07-24 23:19:29 --> UTF-8 Support Enabled
INFO - 2018-07-24 23:19:29 --> Utf8 Class Initialized
INFO - 2018-07-24 23:19:29 --> URI Class Initialized
INFO - 2018-07-24 23:19:29 --> Router Class Initialized
INFO - 2018-07-24 23:19:29 --> Output Class Initialized
INFO - 2018-07-24 23:19:29 --> Security Class Initialized
DEBUG - 2018-07-24 23:19:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 23:19:29 --> Input Class Initialized
INFO - 2018-07-24 23:19:29 --> Language Class Initialized
ERROR - 2018-07-24 23:19:29 --> 404 Page Not Found: /index
INFO - 2018-07-24 23:19:29 --> Config Class Initialized
INFO - 2018-07-24 23:19:29 --> Hooks Class Initialized
DEBUG - 2018-07-24 23:19:29 --> UTF-8 Support Enabled
INFO - 2018-07-24 23:19:29 --> Utf8 Class Initialized
INFO - 2018-07-24 23:19:29 --> URI Class Initialized
INFO - 2018-07-24 23:19:29 --> Router Class Initialized
INFO - 2018-07-24 23:19:29 --> Output Class Initialized
INFO - 2018-07-24 23:19:29 --> Security Class Initialized
DEBUG - 2018-07-24 23:19:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 23:19:29 --> Input Class Initialized
INFO - 2018-07-24 23:19:29 --> Language Class Initialized
ERROR - 2018-07-24 23:19:29 --> 404 Page Not Found: /index
INFO - 2018-07-24 23:19:33 --> Config Class Initialized
INFO - 2018-07-24 23:19:33 --> Hooks Class Initialized
DEBUG - 2018-07-24 23:19:33 --> UTF-8 Support Enabled
INFO - 2018-07-24 23:19:33 --> Utf8 Class Initialized
INFO - 2018-07-24 23:19:33 --> URI Class Initialized
DEBUG - 2018-07-24 23:19:33 --> No URI present. Default controller set.
INFO - 2018-07-24 23:19:33 --> Router Class Initialized
INFO - 2018-07-24 23:19:33 --> Output Class Initialized
INFO - 2018-07-24 23:19:33 --> Security Class Initialized
DEBUG - 2018-07-24 23:19:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 23:19:33 --> Input Class Initialized
INFO - 2018-07-24 23:19:33 --> Language Class Initialized
INFO - 2018-07-24 23:19:33 --> Language Class Initialized
INFO - 2018-07-24 23:19:33 --> Config Class Initialized
INFO - 2018-07-24 23:19:33 --> Loader Class Initialized
DEBUG - 2018-07-24 23:19:33 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-24 23:19:33 --> Helper loaded: url_helper
INFO - 2018-07-24 23:19:33 --> Helper loaded: form_helper
INFO - 2018-07-24 23:19:33 --> Helper loaded: date_helper
INFO - 2018-07-24 23:19:33 --> Helper loaded: util_helper
INFO - 2018-07-24 23:19:33 --> Helper loaded: text_helper
INFO - 2018-07-24 23:19:33 --> Helper loaded: string_helper
INFO - 2018-07-24 23:19:33 --> Database Driver Class Initialized
DEBUG - 2018-07-24 23:19:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-24 23:19:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-24 23:19:33 --> Email Class Initialized
INFO - 2018-07-24 23:19:33 --> Controller Class Initialized
DEBUG - 2018-07-24 23:19:33 --> Home MX_Controller Initialized
DEBUG - 2018-07-24 23:19:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-24 23:19:33 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-24 23:19:33 --> Login MX_Controller Initialized
INFO - 2018-07-24 23:19:33 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-24 23:19:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-24 23:19:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-24 23:19:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-07-24 23:19:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-07-24 23:19:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-07-24 23:19:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-07-24 23:19:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-07-24 23:19:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-07-24 23:19:33 --> Final output sent to browser
DEBUG - 2018-07-24 23:19:33 --> Total execution time: 0.4355
INFO - 2018-07-24 23:19:34 --> Config Class Initialized
INFO - 2018-07-24 23:19:34 --> Hooks Class Initialized
DEBUG - 2018-07-24 23:19:34 --> UTF-8 Support Enabled
INFO - 2018-07-24 23:19:34 --> Utf8 Class Initialized
INFO - 2018-07-24 23:19:34 --> URI Class Initialized
INFO - 2018-07-24 23:19:34 --> Router Class Initialized
INFO - 2018-07-24 23:19:34 --> Output Class Initialized
INFO - 2018-07-24 23:19:34 --> Security Class Initialized
DEBUG - 2018-07-24 23:19:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 23:19:34 --> Input Class Initialized
INFO - 2018-07-24 23:19:34 --> Language Class Initialized
ERROR - 2018-07-24 23:19:34 --> 404 Page Not Found: /index
INFO - 2018-07-24 23:19:34 --> Config Class Initialized
INFO - 2018-07-24 23:19:34 --> Hooks Class Initialized
DEBUG - 2018-07-24 23:19:34 --> UTF-8 Support Enabled
INFO - 2018-07-24 23:19:34 --> Utf8 Class Initialized
INFO - 2018-07-24 23:19:34 --> URI Class Initialized
INFO - 2018-07-24 23:19:34 --> Router Class Initialized
INFO - 2018-07-24 23:19:34 --> Output Class Initialized
INFO - 2018-07-24 23:19:34 --> Security Class Initialized
DEBUG - 2018-07-24 23:19:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 23:19:34 --> Input Class Initialized
INFO - 2018-07-24 23:19:34 --> Language Class Initialized
ERROR - 2018-07-24 23:19:34 --> 404 Page Not Found: /index
INFO - 2018-07-24 23:19:34 --> Config Class Initialized
INFO - 2018-07-24 23:19:34 --> Hooks Class Initialized
DEBUG - 2018-07-24 23:19:34 --> UTF-8 Support Enabled
INFO - 2018-07-24 23:19:34 --> Utf8 Class Initialized
INFO - 2018-07-24 23:19:34 --> URI Class Initialized
INFO - 2018-07-24 23:19:34 --> Router Class Initialized
INFO - 2018-07-24 23:19:34 --> Output Class Initialized
INFO - 2018-07-24 23:19:34 --> Security Class Initialized
DEBUG - 2018-07-24 23:19:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 23:19:34 --> Input Class Initialized
INFO - 2018-07-24 23:19:34 --> Language Class Initialized
ERROR - 2018-07-24 23:19:34 --> 404 Page Not Found: /index
INFO - 2018-07-24 23:19:37 --> Config Class Initialized
INFO - 2018-07-24 23:19:37 --> Hooks Class Initialized
DEBUG - 2018-07-24 23:19:37 --> UTF-8 Support Enabled
INFO - 2018-07-24 23:19:37 --> Utf8 Class Initialized
INFO - 2018-07-24 23:19:37 --> URI Class Initialized
INFO - 2018-07-24 23:19:37 --> Router Class Initialized
INFO - 2018-07-24 23:19:37 --> Output Class Initialized
INFO - 2018-07-24 23:19:37 --> Security Class Initialized
DEBUG - 2018-07-24 23:19:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 23:19:37 --> Input Class Initialized
INFO - 2018-07-24 23:19:37 --> Language Class Initialized
ERROR - 2018-07-24 23:19:37 --> 404 Page Not Found: /index
INFO - 2018-07-24 23:19:37 --> Config Class Initialized
INFO - 2018-07-24 23:19:37 --> Hooks Class Initialized
DEBUG - 2018-07-24 23:19:37 --> UTF-8 Support Enabled
INFO - 2018-07-24 23:19:37 --> Utf8 Class Initialized
INFO - 2018-07-24 23:19:37 --> URI Class Initialized
INFO - 2018-07-24 23:19:37 --> Router Class Initialized
INFO - 2018-07-24 23:19:37 --> Output Class Initialized
INFO - 2018-07-24 23:19:37 --> Security Class Initialized
DEBUG - 2018-07-24 23:19:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 23:19:37 --> Input Class Initialized
INFO - 2018-07-24 23:19:37 --> Language Class Initialized
ERROR - 2018-07-24 23:19:37 --> 404 Page Not Found: /index
INFO - 2018-07-24 23:19:37 --> Config Class Initialized
INFO - 2018-07-24 23:19:37 --> Hooks Class Initialized
DEBUG - 2018-07-24 23:19:37 --> UTF-8 Support Enabled
INFO - 2018-07-24 23:19:37 --> Utf8 Class Initialized
INFO - 2018-07-24 23:19:37 --> URI Class Initialized
INFO - 2018-07-24 23:19:37 --> Router Class Initialized
INFO - 2018-07-24 23:19:37 --> Output Class Initialized
INFO - 2018-07-24 23:19:37 --> Security Class Initialized
DEBUG - 2018-07-24 23:19:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 23:19:37 --> Input Class Initialized
INFO - 2018-07-24 23:19:37 --> Language Class Initialized
ERROR - 2018-07-24 23:19:37 --> 404 Page Not Found: /index
INFO - 2018-07-24 23:19:43 --> Config Class Initialized
INFO - 2018-07-24 23:19:43 --> Hooks Class Initialized
DEBUG - 2018-07-24 23:19:43 --> UTF-8 Support Enabled
INFO - 2018-07-24 23:19:43 --> Utf8 Class Initialized
INFO - 2018-07-24 23:19:43 --> URI Class Initialized
INFO - 2018-07-24 23:19:43 --> Router Class Initialized
INFO - 2018-07-24 23:19:43 --> Output Class Initialized
INFO - 2018-07-24 23:19:43 --> Security Class Initialized
DEBUG - 2018-07-24 23:19:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 23:19:43 --> Input Class Initialized
INFO - 2018-07-24 23:19:43 --> Language Class Initialized
ERROR - 2018-07-24 23:19:43 --> 404 Page Not Found: /index
INFO - 2018-07-24 23:19:43 --> Config Class Initialized
INFO - 2018-07-24 23:19:43 --> Hooks Class Initialized
DEBUG - 2018-07-24 23:19:43 --> UTF-8 Support Enabled
INFO - 2018-07-24 23:19:43 --> Utf8 Class Initialized
INFO - 2018-07-24 23:19:43 --> URI Class Initialized
INFO - 2018-07-24 23:19:43 --> Router Class Initialized
INFO - 2018-07-24 23:19:43 --> Output Class Initialized
INFO - 2018-07-24 23:19:43 --> Security Class Initialized
DEBUG - 2018-07-24 23:19:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 23:19:43 --> Input Class Initialized
INFO - 2018-07-24 23:19:43 --> Language Class Initialized
ERROR - 2018-07-24 23:19:43 --> 404 Page Not Found: /index
INFO - 2018-07-24 23:19:43 --> Config Class Initialized
INFO - 2018-07-24 23:19:43 --> Hooks Class Initialized
DEBUG - 2018-07-24 23:19:43 --> UTF-8 Support Enabled
INFO - 2018-07-24 23:19:43 --> Utf8 Class Initialized
INFO - 2018-07-24 23:19:43 --> URI Class Initialized
INFO - 2018-07-24 23:19:43 --> Router Class Initialized
INFO - 2018-07-24 23:19:43 --> Output Class Initialized
INFO - 2018-07-24 23:19:43 --> Security Class Initialized
DEBUG - 2018-07-24 23:19:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 23:19:43 --> Input Class Initialized
INFO - 2018-07-24 23:19:43 --> Language Class Initialized
ERROR - 2018-07-24 23:19:43 --> 404 Page Not Found: /index
INFO - 2018-07-24 23:20:10 --> Config Class Initialized
INFO - 2018-07-24 23:20:10 --> Hooks Class Initialized
DEBUG - 2018-07-24 23:20:10 --> UTF-8 Support Enabled
INFO - 2018-07-24 23:20:10 --> Utf8 Class Initialized
INFO - 2018-07-24 23:20:10 --> URI Class Initialized
INFO - 2018-07-24 23:20:10 --> Router Class Initialized
INFO - 2018-07-24 23:20:10 --> Output Class Initialized
INFO - 2018-07-24 23:20:10 --> Security Class Initialized
DEBUG - 2018-07-24 23:20:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 23:20:10 --> Input Class Initialized
INFO - 2018-07-24 23:20:10 --> Language Class Initialized
INFO - 2018-07-24 23:20:10 --> Language Class Initialized
INFO - 2018-07-24 23:20:10 --> Config Class Initialized
INFO - 2018-07-24 23:20:10 --> Loader Class Initialized
DEBUG - 2018-07-24 23:20:10 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-24 23:20:10 --> Helper loaded: url_helper
INFO - 2018-07-24 23:20:10 --> Helper loaded: form_helper
INFO - 2018-07-24 23:20:10 --> Helper loaded: date_helper
INFO - 2018-07-24 23:20:10 --> Helper loaded: util_helper
INFO - 2018-07-24 23:20:10 --> Helper loaded: text_helper
INFO - 2018-07-24 23:20:10 --> Helper loaded: string_helper
INFO - 2018-07-24 23:20:10 --> Database Driver Class Initialized
DEBUG - 2018-07-24 23:20:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-24 23:20:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-24 23:20:10 --> Email Class Initialized
INFO - 2018-07-24 23:20:10 --> Controller Class Initialized
DEBUG - 2018-07-24 23:20:10 --> Home MX_Controller Initialized
DEBUG - 2018-07-24 23:20:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-24 23:20:10 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-24 23:20:10 --> Login MX_Controller Initialized
INFO - 2018-07-24 23:20:10 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-24 23:20:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-24 23:20:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-24 23:20:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-07-24 23:20:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-07-24 23:20:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-07-24 23:20:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-07-24 23:20:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-07-24 23:20:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-07-24 23:20:10 --> Final output sent to browser
DEBUG - 2018-07-24 23:20:10 --> Total execution time: 0.4430
INFO - 2018-07-24 23:20:11 --> Config Class Initialized
INFO - 2018-07-24 23:20:11 --> Config Class Initialized
INFO - 2018-07-24 23:20:11 --> Hooks Class Initialized
INFO - 2018-07-24 23:20:11 --> Hooks Class Initialized
DEBUG - 2018-07-24 23:20:11 --> UTF-8 Support Enabled
DEBUG - 2018-07-24 23:20:11 --> UTF-8 Support Enabled
INFO - 2018-07-24 23:20:11 --> Utf8 Class Initialized
INFO - 2018-07-24 23:20:11 --> Utf8 Class Initialized
INFO - 2018-07-24 23:20:11 --> URI Class Initialized
INFO - 2018-07-24 23:20:11 --> URI Class Initialized
INFO - 2018-07-24 23:20:11 --> Router Class Initialized
INFO - 2018-07-24 23:20:11 --> Router Class Initialized
INFO - 2018-07-24 23:20:11 --> Output Class Initialized
INFO - 2018-07-24 23:20:11 --> Output Class Initialized
INFO - 2018-07-24 23:20:11 --> Security Class Initialized
INFO - 2018-07-24 23:20:11 --> Security Class Initialized
DEBUG - 2018-07-24 23:20:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-07-24 23:20:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 23:20:11 --> Input Class Initialized
INFO - 2018-07-24 23:20:11 --> Input Class Initialized
INFO - 2018-07-24 23:20:11 --> Language Class Initialized
INFO - 2018-07-24 23:20:11 --> Language Class Initialized
ERROR - 2018-07-24 23:20:11 --> 404 Page Not Found: /index
ERROR - 2018-07-24 23:20:11 --> 404 Page Not Found: /index
INFO - 2018-07-24 23:20:11 --> Config Class Initialized
INFO - 2018-07-24 23:20:11 --> Hooks Class Initialized
DEBUG - 2018-07-24 23:20:11 --> UTF-8 Support Enabled
INFO - 2018-07-24 23:20:11 --> Utf8 Class Initialized
INFO - 2018-07-24 23:20:11 --> URI Class Initialized
INFO - 2018-07-24 23:20:11 --> Router Class Initialized
INFO - 2018-07-24 23:20:11 --> Output Class Initialized
INFO - 2018-07-24 23:20:11 --> Security Class Initialized
DEBUG - 2018-07-24 23:20:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 23:20:11 --> Input Class Initialized
INFO - 2018-07-24 23:20:11 --> Language Class Initialized
ERROR - 2018-07-24 23:20:11 --> 404 Page Not Found: /index
INFO - 2018-07-24 23:20:12 --> Config Class Initialized
INFO - 2018-07-24 23:20:12 --> Hooks Class Initialized
DEBUG - 2018-07-24 23:20:12 --> UTF-8 Support Enabled
INFO - 2018-07-24 23:20:12 --> Utf8 Class Initialized
INFO - 2018-07-24 23:20:12 --> URI Class Initialized
INFO - 2018-07-24 23:20:12 --> Router Class Initialized
INFO - 2018-07-24 23:20:12 --> Output Class Initialized
INFO - 2018-07-24 23:20:12 --> Security Class Initialized
DEBUG - 2018-07-24 23:20:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 23:20:12 --> Input Class Initialized
INFO - 2018-07-24 23:20:12 --> Language Class Initialized
ERROR - 2018-07-24 23:20:12 --> 404 Page Not Found: /index
INFO - 2018-07-24 23:21:33 --> Config Class Initialized
INFO - 2018-07-24 23:21:33 --> Hooks Class Initialized
DEBUG - 2018-07-24 23:21:33 --> UTF-8 Support Enabled
INFO - 2018-07-24 23:21:33 --> Utf8 Class Initialized
INFO - 2018-07-24 23:21:33 --> URI Class Initialized
INFO - 2018-07-24 23:21:33 --> Router Class Initialized
INFO - 2018-07-24 23:21:33 --> Output Class Initialized
INFO - 2018-07-24 23:21:33 --> Security Class Initialized
DEBUG - 2018-07-24 23:21:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 23:21:33 --> Input Class Initialized
INFO - 2018-07-24 23:21:33 --> Language Class Initialized
INFO - 2018-07-24 23:21:33 --> Language Class Initialized
INFO - 2018-07-24 23:21:33 --> Config Class Initialized
INFO - 2018-07-24 23:21:33 --> Loader Class Initialized
DEBUG - 2018-07-24 23:21:33 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-24 23:21:33 --> Helper loaded: url_helper
INFO - 2018-07-24 23:21:33 --> Helper loaded: form_helper
INFO - 2018-07-24 23:21:33 --> Helper loaded: date_helper
INFO - 2018-07-24 23:21:33 --> Helper loaded: util_helper
INFO - 2018-07-24 23:21:33 --> Helper loaded: text_helper
INFO - 2018-07-24 23:21:33 --> Helper loaded: string_helper
INFO - 2018-07-24 23:21:33 --> Database Driver Class Initialized
DEBUG - 2018-07-24 23:21:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-24 23:21:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-24 23:21:33 --> Email Class Initialized
INFO - 2018-07-24 23:21:33 --> Controller Class Initialized
DEBUG - 2018-07-24 23:21:33 --> Home MX_Controller Initialized
DEBUG - 2018-07-24 23:21:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-24 23:21:33 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-24 23:21:33 --> Login MX_Controller Initialized
INFO - 2018-07-24 23:21:33 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-24 23:21:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-24 23:21:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-24 23:21:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-07-24 23:21:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-07-24 23:21:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-07-24 23:21:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-07-24 23:21:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-07-24 23:21:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-07-24 23:21:34 --> Final output sent to browser
DEBUG - 2018-07-24 23:21:34 --> Total execution time: 0.4379
INFO - 2018-07-24 23:21:34 --> Config Class Initialized
INFO - 2018-07-24 23:21:34 --> Config Class Initialized
INFO - 2018-07-24 23:21:34 --> Hooks Class Initialized
INFO - 2018-07-24 23:21:34 --> Hooks Class Initialized
DEBUG - 2018-07-24 23:21:34 --> UTF-8 Support Enabled
DEBUG - 2018-07-24 23:21:34 --> UTF-8 Support Enabled
INFO - 2018-07-24 23:21:34 --> Utf8 Class Initialized
INFO - 2018-07-24 23:21:34 --> URI Class Initialized
INFO - 2018-07-24 23:21:34 --> Router Class Initialized
INFO - 2018-07-24 23:21:34 --> Output Class Initialized
INFO - 2018-07-24 23:21:34 --> Security Class Initialized
DEBUG - 2018-07-24 23:21:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 23:21:34 --> Input Class Initialized
INFO - 2018-07-24 23:21:34 --> Utf8 Class Initialized
INFO - 2018-07-24 23:21:34 --> Language Class Initialized
INFO - 2018-07-24 23:21:34 --> URI Class Initialized
ERROR - 2018-07-24 23:21:34 --> 404 Page Not Found: /index
INFO - 2018-07-24 23:21:34 --> Router Class Initialized
INFO - 2018-07-24 23:21:34 --> Output Class Initialized
INFO - 2018-07-24 23:21:34 --> Security Class Initialized
DEBUG - 2018-07-24 23:21:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 23:21:34 --> Input Class Initialized
INFO - 2018-07-24 23:21:34 --> Language Class Initialized
ERROR - 2018-07-24 23:21:35 --> 404 Page Not Found: /index
INFO - 2018-07-24 23:21:35 --> Config Class Initialized
INFO - 2018-07-24 23:21:35 --> Hooks Class Initialized
DEBUG - 2018-07-24 23:21:35 --> UTF-8 Support Enabled
INFO - 2018-07-24 23:21:35 --> Utf8 Class Initialized
INFO - 2018-07-24 23:21:35 --> URI Class Initialized
INFO - 2018-07-24 23:21:35 --> Router Class Initialized
INFO - 2018-07-24 23:21:35 --> Output Class Initialized
INFO - 2018-07-24 23:21:35 --> Security Class Initialized
DEBUG - 2018-07-24 23:21:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 23:21:35 --> Input Class Initialized
INFO - 2018-07-24 23:21:35 --> Language Class Initialized
ERROR - 2018-07-24 23:21:35 --> 404 Page Not Found: /index
INFO - 2018-07-24 23:21:35 --> Config Class Initialized
INFO - 2018-07-24 23:21:35 --> Hooks Class Initialized
DEBUG - 2018-07-24 23:21:35 --> UTF-8 Support Enabled
INFO - 2018-07-24 23:21:35 --> Utf8 Class Initialized
INFO - 2018-07-24 23:21:35 --> URI Class Initialized
INFO - 2018-07-24 23:21:35 --> Router Class Initialized
INFO - 2018-07-24 23:21:35 --> Output Class Initialized
INFO - 2018-07-24 23:21:35 --> Security Class Initialized
DEBUG - 2018-07-24 23:21:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 23:21:35 --> Input Class Initialized
INFO - 2018-07-24 23:21:35 --> Language Class Initialized
ERROR - 2018-07-24 23:21:35 --> 404 Page Not Found: /index
INFO - 2018-07-24 23:25:12 --> Config Class Initialized
INFO - 2018-07-24 23:25:12 --> Hooks Class Initialized
DEBUG - 2018-07-24 23:25:12 --> UTF-8 Support Enabled
INFO - 2018-07-24 23:25:12 --> Utf8 Class Initialized
INFO - 2018-07-24 23:25:12 --> URI Class Initialized
INFO - 2018-07-24 23:25:12 --> Router Class Initialized
INFO - 2018-07-24 23:25:12 --> Output Class Initialized
INFO - 2018-07-24 23:25:12 --> Security Class Initialized
DEBUG - 2018-07-24 23:25:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 23:25:12 --> Input Class Initialized
INFO - 2018-07-24 23:25:12 --> Language Class Initialized
INFO - 2018-07-24 23:25:13 --> Language Class Initialized
INFO - 2018-07-24 23:25:13 --> Config Class Initialized
INFO - 2018-07-24 23:25:13 --> Loader Class Initialized
DEBUG - 2018-07-24 23:25:13 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-24 23:25:13 --> Helper loaded: url_helper
INFO - 2018-07-24 23:25:13 --> Helper loaded: form_helper
INFO - 2018-07-24 23:25:13 --> Helper loaded: date_helper
INFO - 2018-07-24 23:25:13 --> Helper loaded: util_helper
INFO - 2018-07-24 23:25:13 --> Helper loaded: text_helper
INFO - 2018-07-24 23:25:13 --> Helper loaded: string_helper
INFO - 2018-07-24 23:25:13 --> Database Driver Class Initialized
DEBUG - 2018-07-24 23:25:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-24 23:25:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-24 23:25:13 --> Email Class Initialized
INFO - 2018-07-24 23:25:13 --> Controller Class Initialized
DEBUG - 2018-07-24 23:25:13 --> Home MX_Controller Initialized
DEBUG - 2018-07-24 23:25:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-24 23:25:13 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-24 23:25:13 --> Login MX_Controller Initialized
INFO - 2018-07-24 23:25:13 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-24 23:25:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-24 23:25:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-24 23:25:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-07-24 23:25:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-07-24 23:25:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-07-24 23:25:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-07-24 23:25:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-07-24 23:25:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-07-24 23:25:13 --> Final output sent to browser
DEBUG - 2018-07-24 23:25:13 --> Total execution time: 0.4609
INFO - 2018-07-24 23:25:14 --> Config Class Initialized
INFO - 2018-07-24 23:25:14 --> Hooks Class Initialized
DEBUG - 2018-07-24 23:25:14 --> UTF-8 Support Enabled
INFO - 2018-07-24 23:25:14 --> Utf8 Class Initialized
INFO - 2018-07-24 23:25:14 --> Config Class Initialized
INFO - 2018-07-24 23:25:14 --> URI Class Initialized
INFO - 2018-07-24 23:25:14 --> Hooks Class Initialized
INFO - 2018-07-24 23:25:14 --> Router Class Initialized
INFO - 2018-07-24 23:25:14 --> Output Class Initialized
DEBUG - 2018-07-24 23:25:14 --> UTF-8 Support Enabled
INFO - 2018-07-24 23:25:14 --> Security Class Initialized
INFO - 2018-07-24 23:25:14 --> Utf8 Class Initialized
INFO - 2018-07-24 23:25:14 --> URI Class Initialized
DEBUG - 2018-07-24 23:25:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 23:25:14 --> Input Class Initialized
INFO - 2018-07-24 23:25:14 --> Router Class Initialized
INFO - 2018-07-24 23:25:14 --> Language Class Initialized
ERROR - 2018-07-24 23:25:14 --> 404 Page Not Found: /index
INFO - 2018-07-24 23:25:14 --> Output Class Initialized
INFO - 2018-07-24 23:25:14 --> Security Class Initialized
DEBUG - 2018-07-24 23:25:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 23:25:14 --> Input Class Initialized
INFO - 2018-07-24 23:25:14 --> Language Class Initialized
ERROR - 2018-07-24 23:25:14 --> 404 Page Not Found: /index
INFO - 2018-07-24 23:25:15 --> Config Class Initialized
INFO - 2018-07-24 23:25:15 --> Hooks Class Initialized
DEBUG - 2018-07-24 23:25:15 --> UTF-8 Support Enabled
INFO - 2018-07-24 23:25:15 --> Utf8 Class Initialized
INFO - 2018-07-24 23:25:15 --> URI Class Initialized
INFO - 2018-07-24 23:25:15 --> Router Class Initialized
INFO - 2018-07-24 23:25:15 --> Output Class Initialized
INFO - 2018-07-24 23:25:15 --> Security Class Initialized
DEBUG - 2018-07-24 23:25:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 23:25:15 --> Input Class Initialized
INFO - 2018-07-24 23:25:15 --> Language Class Initialized
ERROR - 2018-07-24 23:25:15 --> 404 Page Not Found: /index
INFO - 2018-07-24 23:25:15 --> Config Class Initialized
INFO - 2018-07-24 23:25:15 --> Hooks Class Initialized
DEBUG - 2018-07-24 23:25:15 --> UTF-8 Support Enabled
INFO - 2018-07-24 23:25:15 --> Utf8 Class Initialized
INFO - 2018-07-24 23:25:15 --> URI Class Initialized
INFO - 2018-07-24 23:25:15 --> Router Class Initialized
INFO - 2018-07-24 23:25:15 --> Output Class Initialized
INFO - 2018-07-24 23:25:15 --> Security Class Initialized
DEBUG - 2018-07-24 23:25:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 23:25:15 --> Input Class Initialized
INFO - 2018-07-24 23:25:15 --> Language Class Initialized
ERROR - 2018-07-24 23:25:15 --> 404 Page Not Found: /index
INFO - 2018-07-24 23:25:19 --> Config Class Initialized
INFO - 2018-07-24 23:25:19 --> Config Class Initialized
INFO - 2018-07-24 23:25:19 --> Hooks Class Initialized
INFO - 2018-07-24 23:25:19 --> Hooks Class Initialized
DEBUG - 2018-07-24 23:25:19 --> UTF-8 Support Enabled
DEBUG - 2018-07-24 23:25:19 --> UTF-8 Support Enabled
INFO - 2018-07-24 23:25:19 --> Utf8 Class Initialized
INFO - 2018-07-24 23:25:19 --> Utf8 Class Initialized
INFO - 2018-07-24 23:25:20 --> URI Class Initialized
INFO - 2018-07-24 23:25:20 --> URI Class Initialized
INFO - 2018-07-24 23:25:20 --> Router Class Initialized
INFO - 2018-07-24 23:25:20 --> Router Class Initialized
INFO - 2018-07-24 23:25:20 --> Output Class Initialized
INFO - 2018-07-24 23:25:20 --> Output Class Initialized
INFO - 2018-07-24 23:25:20 --> Security Class Initialized
INFO - 2018-07-24 23:25:20 --> Security Class Initialized
DEBUG - 2018-07-24 23:25:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-07-24 23:25:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 23:25:20 --> Input Class Initialized
INFO - 2018-07-24 23:25:20 --> Input Class Initialized
INFO - 2018-07-24 23:25:20 --> Language Class Initialized
INFO - 2018-07-24 23:25:20 --> Language Class Initialized
ERROR - 2018-07-24 23:25:20 --> 404 Page Not Found: /index
ERROR - 2018-07-24 23:25:20 --> 404 Page Not Found: /index
INFO - 2018-07-24 23:25:20 --> Config Class Initialized
INFO - 2018-07-24 23:25:20 --> Hooks Class Initialized
DEBUG - 2018-07-24 23:25:20 --> UTF-8 Support Enabled
INFO - 2018-07-24 23:25:20 --> Utf8 Class Initialized
INFO - 2018-07-24 23:25:20 --> URI Class Initialized
INFO - 2018-07-24 23:25:20 --> Router Class Initialized
INFO - 2018-07-24 23:25:20 --> Output Class Initialized
INFO - 2018-07-24 23:25:20 --> Security Class Initialized
DEBUG - 2018-07-24 23:25:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 23:25:20 --> Input Class Initialized
INFO - 2018-07-24 23:25:20 --> Language Class Initialized
ERROR - 2018-07-24 23:25:20 --> 404 Page Not Found: /index
INFO - 2018-07-24 23:25:20 --> Config Class Initialized
INFO - 2018-07-24 23:25:20 --> Hooks Class Initialized
DEBUG - 2018-07-24 23:25:20 --> UTF-8 Support Enabled
INFO - 2018-07-24 23:25:20 --> Utf8 Class Initialized
INFO - 2018-07-24 23:25:20 --> URI Class Initialized
INFO - 2018-07-24 23:25:20 --> Router Class Initialized
INFO - 2018-07-24 23:25:20 --> Output Class Initialized
INFO - 2018-07-24 23:25:20 --> Security Class Initialized
DEBUG - 2018-07-24 23:25:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 23:25:20 --> Input Class Initialized
INFO - 2018-07-24 23:25:20 --> Language Class Initialized
ERROR - 2018-07-24 23:25:20 --> 404 Page Not Found: /index
INFO - 2018-07-24 23:25:24 --> Config Class Initialized
INFO - 2018-07-24 23:25:24 --> Config Class Initialized
INFO - 2018-07-24 23:25:24 --> Hooks Class Initialized
INFO - 2018-07-24 23:25:24 --> Hooks Class Initialized
DEBUG - 2018-07-24 23:25:24 --> UTF-8 Support Enabled
DEBUG - 2018-07-24 23:25:24 --> UTF-8 Support Enabled
INFO - 2018-07-24 23:25:24 --> Utf8 Class Initialized
INFO - 2018-07-24 23:25:24 --> Utf8 Class Initialized
INFO - 2018-07-24 23:25:24 --> URI Class Initialized
INFO - 2018-07-24 23:25:24 --> URI Class Initialized
INFO - 2018-07-24 23:25:24 --> Router Class Initialized
INFO - 2018-07-24 23:25:24 --> Router Class Initialized
INFO - 2018-07-24 23:25:24 --> Output Class Initialized
INFO - 2018-07-24 23:25:24 --> Security Class Initialized
DEBUG - 2018-07-24 23:25:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 23:25:24 --> Input Class Initialized
INFO - 2018-07-24 23:25:24 --> Language Class Initialized
ERROR - 2018-07-24 23:25:24 --> 404 Page Not Found: /index
INFO - 2018-07-24 23:25:24 --> Output Class Initialized
INFO - 2018-07-24 23:25:24 --> Security Class Initialized
DEBUG - 2018-07-24 23:25:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 23:25:24 --> Input Class Initialized
INFO - 2018-07-24 23:25:24 --> Language Class Initialized
ERROR - 2018-07-24 23:25:24 --> 404 Page Not Found: /index
INFO - 2018-07-24 23:25:24 --> Config Class Initialized
INFO - 2018-07-24 23:25:24 --> Hooks Class Initialized
DEBUG - 2018-07-24 23:25:24 --> UTF-8 Support Enabled
INFO - 2018-07-24 23:25:24 --> Utf8 Class Initialized
INFO - 2018-07-24 23:25:24 --> URI Class Initialized
INFO - 2018-07-24 23:25:24 --> Router Class Initialized
INFO - 2018-07-24 23:25:24 --> Output Class Initialized
INFO - 2018-07-24 23:25:24 --> Security Class Initialized
DEBUG - 2018-07-24 23:25:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 23:25:24 --> Input Class Initialized
INFO - 2018-07-24 23:25:24 --> Language Class Initialized
ERROR - 2018-07-24 23:25:24 --> 404 Page Not Found: /index
INFO - 2018-07-24 23:25:24 --> Config Class Initialized
INFO - 2018-07-24 23:25:24 --> Hooks Class Initialized
DEBUG - 2018-07-24 23:25:24 --> UTF-8 Support Enabled
INFO - 2018-07-24 23:25:24 --> Utf8 Class Initialized
INFO - 2018-07-24 23:25:25 --> URI Class Initialized
INFO - 2018-07-24 23:25:25 --> Router Class Initialized
INFO - 2018-07-24 23:25:25 --> Output Class Initialized
INFO - 2018-07-24 23:25:25 --> Security Class Initialized
DEBUG - 2018-07-24 23:25:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 23:25:25 --> Input Class Initialized
INFO - 2018-07-24 23:25:25 --> Language Class Initialized
ERROR - 2018-07-24 23:25:25 --> 404 Page Not Found: /index
INFO - 2018-07-24 23:25:25 --> Config Class Initialized
INFO - 2018-07-24 23:25:25 --> Hooks Class Initialized
DEBUG - 2018-07-24 23:25:25 --> UTF-8 Support Enabled
INFO - 2018-07-24 23:25:25 --> Utf8 Class Initialized
INFO - 2018-07-24 23:25:25 --> URI Class Initialized
INFO - 2018-07-24 23:25:25 --> Router Class Initialized
INFO - 2018-07-24 23:25:25 --> Output Class Initialized
INFO - 2018-07-24 23:25:25 --> Security Class Initialized
DEBUG - 2018-07-24 23:25:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 23:25:25 --> Input Class Initialized
INFO - 2018-07-24 23:25:25 --> Language Class Initialized
ERROR - 2018-07-24 23:25:25 --> 404 Page Not Found: /index
INFO - 2018-07-24 23:25:25 --> Config Class Initialized
INFO - 2018-07-24 23:25:25 --> Hooks Class Initialized
DEBUG - 2018-07-24 23:25:25 --> UTF-8 Support Enabled
INFO - 2018-07-24 23:25:25 --> Utf8 Class Initialized
INFO - 2018-07-24 23:25:25 --> URI Class Initialized
INFO - 2018-07-24 23:25:25 --> Router Class Initialized
INFO - 2018-07-24 23:25:25 --> Output Class Initialized
INFO - 2018-07-24 23:25:25 --> Security Class Initialized
DEBUG - 2018-07-24 23:25:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 23:25:25 --> Input Class Initialized
INFO - 2018-07-24 23:25:25 --> Language Class Initialized
ERROR - 2018-07-24 23:25:25 --> 404 Page Not Found: /index
INFO - 2018-07-24 23:25:25 --> Config Class Initialized
INFO - 2018-07-24 23:25:25 --> Hooks Class Initialized
DEBUG - 2018-07-24 23:25:26 --> UTF-8 Support Enabled
INFO - 2018-07-24 23:25:26 --> Utf8 Class Initialized
INFO - 2018-07-24 23:25:26 --> URI Class Initialized
INFO - 2018-07-24 23:25:26 --> Router Class Initialized
INFO - 2018-07-24 23:25:26 --> Output Class Initialized
INFO - 2018-07-24 23:25:26 --> Security Class Initialized
DEBUG - 2018-07-24 23:25:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 23:25:26 --> Input Class Initialized
INFO - 2018-07-24 23:25:26 --> Language Class Initialized
ERROR - 2018-07-24 23:25:26 --> 404 Page Not Found: /index
INFO - 2018-07-24 23:25:27 --> Config Class Initialized
INFO - 2018-07-24 23:25:27 --> Config Class Initialized
INFO - 2018-07-24 23:25:27 --> Hooks Class Initialized
INFO - 2018-07-24 23:25:27 --> Hooks Class Initialized
DEBUG - 2018-07-24 23:25:27 --> UTF-8 Support Enabled
DEBUG - 2018-07-24 23:25:27 --> UTF-8 Support Enabled
INFO - 2018-07-24 23:25:27 --> Utf8 Class Initialized
INFO - 2018-07-24 23:25:27 --> Utf8 Class Initialized
INFO - 2018-07-24 23:25:27 --> URI Class Initialized
INFO - 2018-07-24 23:25:27 --> URI Class Initialized
INFO - 2018-07-24 23:25:27 --> Router Class Initialized
INFO - 2018-07-24 23:25:27 --> Router Class Initialized
INFO - 2018-07-24 23:25:27 --> Output Class Initialized
INFO - 2018-07-24 23:25:27 --> Output Class Initialized
INFO - 2018-07-24 23:25:27 --> Security Class Initialized
INFO - 2018-07-24 23:25:27 --> Security Class Initialized
DEBUG - 2018-07-24 23:25:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-07-24 23:25:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 23:25:27 --> Input Class Initialized
INFO - 2018-07-24 23:25:27 --> Input Class Initialized
INFO - 2018-07-24 23:25:27 --> Language Class Initialized
INFO - 2018-07-24 23:25:27 --> Language Class Initialized
ERROR - 2018-07-24 23:25:27 --> 404 Page Not Found: /index
ERROR - 2018-07-24 23:25:27 --> 404 Page Not Found: /index
INFO - 2018-07-24 23:25:27 --> Config Class Initialized
INFO - 2018-07-24 23:25:27 --> Hooks Class Initialized
DEBUG - 2018-07-24 23:25:27 --> UTF-8 Support Enabled
INFO - 2018-07-24 23:25:27 --> Utf8 Class Initialized
INFO - 2018-07-24 23:25:27 --> URI Class Initialized
INFO - 2018-07-24 23:25:27 --> Router Class Initialized
INFO - 2018-07-24 23:25:27 --> Output Class Initialized
INFO - 2018-07-24 23:25:27 --> Security Class Initialized
DEBUG - 2018-07-24 23:25:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 23:25:27 --> Input Class Initialized
INFO - 2018-07-24 23:25:27 --> Language Class Initialized
ERROR - 2018-07-24 23:25:27 --> 404 Page Not Found: /index
INFO - 2018-07-24 23:25:27 --> Config Class Initialized
INFO - 2018-07-24 23:25:27 --> Hooks Class Initialized
DEBUG - 2018-07-24 23:25:27 --> UTF-8 Support Enabled
INFO - 2018-07-24 23:25:27 --> Utf8 Class Initialized
INFO - 2018-07-24 23:25:27 --> URI Class Initialized
INFO - 2018-07-24 23:25:27 --> Router Class Initialized
INFO - 2018-07-24 23:25:27 --> Output Class Initialized
INFO - 2018-07-24 23:25:27 --> Security Class Initialized
DEBUG - 2018-07-24 23:25:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 23:25:27 --> Input Class Initialized
INFO - 2018-07-24 23:25:27 --> Language Class Initialized
ERROR - 2018-07-24 23:25:27 --> 404 Page Not Found: /index
INFO - 2018-07-24 23:25:31 --> Config Class Initialized
INFO - 2018-07-24 23:25:31 --> Config Class Initialized
INFO - 2018-07-24 23:25:31 --> Hooks Class Initialized
INFO - 2018-07-24 23:25:31 --> Hooks Class Initialized
DEBUG - 2018-07-24 23:25:31 --> UTF-8 Support Enabled
DEBUG - 2018-07-24 23:25:31 --> UTF-8 Support Enabled
INFO - 2018-07-24 23:25:31 --> Utf8 Class Initialized
INFO - 2018-07-24 23:25:31 --> Utf8 Class Initialized
INFO - 2018-07-24 23:25:31 --> URI Class Initialized
INFO - 2018-07-24 23:25:31 --> URI Class Initialized
INFO - 2018-07-24 23:25:31 --> Router Class Initialized
INFO - 2018-07-24 23:25:31 --> Router Class Initialized
INFO - 2018-07-24 23:25:31 --> Output Class Initialized
INFO - 2018-07-24 23:25:31 --> Output Class Initialized
INFO - 2018-07-24 23:25:31 --> Security Class Initialized
INFO - 2018-07-24 23:25:31 --> Security Class Initialized
DEBUG - 2018-07-24 23:25:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-07-24 23:25:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 23:25:31 --> Input Class Initialized
INFO - 2018-07-24 23:25:31 --> Input Class Initialized
INFO - 2018-07-24 23:25:31 --> Language Class Initialized
INFO - 2018-07-24 23:25:32 --> Language Class Initialized
ERROR - 2018-07-24 23:25:32 --> 404 Page Not Found: /index
ERROR - 2018-07-24 23:25:32 --> 404 Page Not Found: /index
INFO - 2018-07-24 23:25:32 --> Config Class Initialized
INFO - 2018-07-24 23:25:32 --> Hooks Class Initialized
DEBUG - 2018-07-24 23:25:32 --> UTF-8 Support Enabled
INFO - 2018-07-24 23:25:32 --> Utf8 Class Initialized
INFO - 2018-07-24 23:25:32 --> URI Class Initialized
INFO - 2018-07-24 23:25:32 --> Router Class Initialized
INFO - 2018-07-24 23:25:32 --> Output Class Initialized
INFO - 2018-07-24 23:25:32 --> Security Class Initialized
DEBUG - 2018-07-24 23:25:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 23:25:32 --> Input Class Initialized
INFO - 2018-07-24 23:25:32 --> Language Class Initialized
ERROR - 2018-07-24 23:25:32 --> 404 Page Not Found: /index
INFO - 2018-07-24 23:25:32 --> Config Class Initialized
INFO - 2018-07-24 23:25:32 --> Hooks Class Initialized
DEBUG - 2018-07-24 23:25:32 --> UTF-8 Support Enabled
INFO - 2018-07-24 23:25:32 --> Utf8 Class Initialized
INFO - 2018-07-24 23:25:32 --> URI Class Initialized
INFO - 2018-07-24 23:25:32 --> Router Class Initialized
INFO - 2018-07-24 23:25:32 --> Output Class Initialized
INFO - 2018-07-24 23:25:32 --> Security Class Initialized
DEBUG - 2018-07-24 23:25:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 23:25:32 --> Input Class Initialized
INFO - 2018-07-24 23:25:32 --> Language Class Initialized
ERROR - 2018-07-24 23:25:32 --> 404 Page Not Found: /index
INFO - 2018-07-24 23:25:33 --> Config Class Initialized
INFO - 2018-07-24 23:25:33 --> Config Class Initialized
INFO - 2018-07-24 23:25:33 --> Hooks Class Initialized
INFO - 2018-07-24 23:25:33 --> Hooks Class Initialized
DEBUG - 2018-07-24 23:25:33 --> UTF-8 Support Enabled
DEBUG - 2018-07-24 23:25:33 --> UTF-8 Support Enabled
INFO - 2018-07-24 23:25:33 --> Utf8 Class Initialized
INFO - 2018-07-24 23:25:33 --> Utf8 Class Initialized
INFO - 2018-07-24 23:25:33 --> URI Class Initialized
INFO - 2018-07-24 23:25:33 --> URI Class Initialized
INFO - 2018-07-24 23:25:33 --> Router Class Initialized
INFO - 2018-07-24 23:25:33 --> Output Class Initialized
INFO - 2018-07-24 23:25:33 --> Router Class Initialized
INFO - 2018-07-24 23:25:33 --> Security Class Initialized
DEBUG - 2018-07-24 23:25:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 23:25:33 --> Input Class Initialized
INFO - 2018-07-24 23:25:33 --> Language Class Initialized
INFO - 2018-07-24 23:25:33 --> Output Class Initialized
ERROR - 2018-07-24 23:25:33 --> 404 Page Not Found: /index
INFO - 2018-07-24 23:25:33 --> Security Class Initialized
INFO - 2018-07-24 23:25:33 --> Config Class Initialized
INFO - 2018-07-24 23:25:33 --> Hooks Class Initialized
DEBUG - 2018-07-24 23:25:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 23:25:33 --> Input Class Initialized
DEBUG - 2018-07-24 23:25:33 --> UTF-8 Support Enabled
INFO - 2018-07-24 23:25:33 --> Language Class Initialized
ERROR - 2018-07-24 23:25:33 --> 404 Page Not Found: /index
INFO - 2018-07-24 23:25:33 --> Utf8 Class Initialized
INFO - 2018-07-24 23:25:33 --> URI Class Initialized
INFO - 2018-07-24 23:25:33 --> Router Class Initialized
INFO - 2018-07-24 23:25:33 --> Output Class Initialized
INFO - 2018-07-24 23:25:33 --> Security Class Initialized
DEBUG - 2018-07-24 23:25:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 23:25:34 --> Input Class Initialized
INFO - 2018-07-24 23:25:34 --> Language Class Initialized
ERROR - 2018-07-24 23:25:34 --> 404 Page Not Found: /index
INFO - 2018-07-24 23:25:34 --> Config Class Initialized
INFO - 2018-07-24 23:25:34 --> Hooks Class Initialized
DEBUG - 2018-07-24 23:25:34 --> UTF-8 Support Enabled
INFO - 2018-07-24 23:25:34 --> Utf8 Class Initialized
INFO - 2018-07-24 23:25:34 --> URI Class Initialized
INFO - 2018-07-24 23:25:34 --> Router Class Initialized
INFO - 2018-07-24 23:25:34 --> Output Class Initialized
INFO - 2018-07-24 23:25:34 --> Security Class Initialized
DEBUG - 2018-07-24 23:25:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 23:25:34 --> Input Class Initialized
INFO - 2018-07-24 23:25:34 --> Language Class Initialized
ERROR - 2018-07-24 23:25:34 --> 404 Page Not Found: /index
INFO - 2018-07-24 23:25:35 --> Config Class Initialized
INFO - 2018-07-24 23:25:35 --> Config Class Initialized
INFO - 2018-07-24 23:25:35 --> Hooks Class Initialized
INFO - 2018-07-24 23:25:35 --> Hooks Class Initialized
DEBUG - 2018-07-24 23:25:35 --> UTF-8 Support Enabled
INFO - 2018-07-24 23:25:35 --> Utf8 Class Initialized
DEBUG - 2018-07-24 23:25:35 --> UTF-8 Support Enabled
INFO - 2018-07-24 23:25:35 --> URI Class Initialized
INFO - 2018-07-24 23:25:35 --> Utf8 Class Initialized
INFO - 2018-07-24 23:25:35 --> Router Class Initialized
INFO - 2018-07-24 23:25:35 --> URI Class Initialized
INFO - 2018-07-24 23:25:35 --> Output Class Initialized
INFO - 2018-07-24 23:25:35 --> Security Class Initialized
INFO - 2018-07-24 23:25:35 --> Router Class Initialized
DEBUG - 2018-07-24 23:25:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 23:25:35 --> Output Class Initialized
INFO - 2018-07-24 23:25:35 --> Input Class Initialized
INFO - 2018-07-24 23:25:35 --> Security Class Initialized
INFO - 2018-07-24 23:25:35 --> Language Class Initialized
DEBUG - 2018-07-24 23:25:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-07-24 23:25:35 --> 404 Page Not Found: /index
INFO - 2018-07-24 23:25:35 --> Input Class Initialized
INFO - 2018-07-24 23:25:35 --> Config Class Initialized
INFO - 2018-07-24 23:25:35 --> Hooks Class Initialized
INFO - 2018-07-24 23:25:35 --> Language Class Initialized
DEBUG - 2018-07-24 23:25:35 --> UTF-8 Support Enabled
INFO - 2018-07-24 23:25:35 --> Utf8 Class Initialized
INFO - 2018-07-24 23:25:35 --> URI Class Initialized
INFO - 2018-07-24 23:25:35 --> Router Class Initialized
ERROR - 2018-07-24 23:25:35 --> 404 Page Not Found: /index
INFO - 2018-07-24 23:25:35 --> Output Class Initialized
INFO - 2018-07-24 23:25:35 --> Security Class Initialized
DEBUG - 2018-07-24 23:25:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 23:25:35 --> Input Class Initialized
INFO - 2018-07-24 23:25:35 --> Language Class Initialized
ERROR - 2018-07-24 23:25:35 --> 404 Page Not Found: /index
INFO - 2018-07-24 23:25:35 --> Config Class Initialized
INFO - 2018-07-24 23:25:35 --> Hooks Class Initialized
DEBUG - 2018-07-24 23:25:35 --> UTF-8 Support Enabled
INFO - 2018-07-24 23:25:35 --> Utf8 Class Initialized
INFO - 2018-07-24 23:25:35 --> URI Class Initialized
INFO - 2018-07-24 23:25:35 --> Router Class Initialized
INFO - 2018-07-24 23:25:35 --> Output Class Initialized
INFO - 2018-07-24 23:25:35 --> Security Class Initialized
DEBUG - 2018-07-24 23:25:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 23:25:35 --> Input Class Initialized
INFO - 2018-07-24 23:25:35 --> Language Class Initialized
ERROR - 2018-07-24 23:25:35 --> 404 Page Not Found: /index
INFO - 2018-07-24 23:32:28 --> Config Class Initialized
INFO - 2018-07-24 23:32:28 --> Hooks Class Initialized
DEBUG - 2018-07-24 23:32:28 --> UTF-8 Support Enabled
INFO - 2018-07-24 23:32:28 --> Utf8 Class Initialized
INFO - 2018-07-24 23:32:28 --> URI Class Initialized
INFO - 2018-07-24 23:32:28 --> Router Class Initialized
INFO - 2018-07-24 23:32:28 --> Output Class Initialized
INFO - 2018-07-24 23:32:28 --> Security Class Initialized
DEBUG - 2018-07-24 23:32:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 23:32:28 --> Input Class Initialized
INFO - 2018-07-24 23:32:28 --> Language Class Initialized
INFO - 2018-07-24 23:32:28 --> Language Class Initialized
INFO - 2018-07-24 23:32:28 --> Config Class Initialized
INFO - 2018-07-24 23:32:28 --> Loader Class Initialized
DEBUG - 2018-07-24 23:32:28 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-24 23:32:28 --> Helper loaded: url_helper
INFO - 2018-07-24 23:32:29 --> Helper loaded: form_helper
INFO - 2018-07-24 23:32:29 --> Helper loaded: date_helper
INFO - 2018-07-24 23:32:29 --> Helper loaded: util_helper
INFO - 2018-07-24 23:32:29 --> Helper loaded: text_helper
INFO - 2018-07-24 23:32:29 --> Helper loaded: string_helper
INFO - 2018-07-24 23:32:29 --> Database Driver Class Initialized
DEBUG - 2018-07-24 23:32:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-24 23:32:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-24 23:32:29 --> Email Class Initialized
INFO - 2018-07-24 23:32:29 --> Controller Class Initialized
DEBUG - 2018-07-24 23:32:29 --> Home MX_Controller Initialized
DEBUG - 2018-07-24 23:32:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-24 23:32:29 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-24 23:32:29 --> Login MX_Controller Initialized
INFO - 2018-07-24 23:32:29 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-24 23:32:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-24 23:32:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-24 23:32:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-07-24 23:32:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-07-24 23:32:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-07-24 23:32:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-07-24 23:32:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-07-24 23:32:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-07-24 23:32:29 --> Final output sent to browser
DEBUG - 2018-07-24 23:32:29 --> Total execution time: 0.4693
INFO - 2018-07-24 23:32:29 --> Config Class Initialized
INFO - 2018-07-24 23:32:29 --> Config Class Initialized
INFO - 2018-07-24 23:32:29 --> Hooks Class Initialized
INFO - 2018-07-24 23:32:29 --> Hooks Class Initialized
DEBUG - 2018-07-24 23:32:29 --> UTF-8 Support Enabled
DEBUG - 2018-07-24 23:32:29 --> UTF-8 Support Enabled
INFO - 2018-07-24 23:32:29 --> Utf8 Class Initialized
INFO - 2018-07-24 23:32:29 --> Utf8 Class Initialized
INFO - 2018-07-24 23:32:29 --> URI Class Initialized
INFO - 2018-07-24 23:32:29 --> URI Class Initialized
INFO - 2018-07-24 23:32:29 --> Router Class Initialized
INFO - 2018-07-24 23:32:29 --> Output Class Initialized
INFO - 2018-07-24 23:32:29 --> Router Class Initialized
INFO - 2018-07-24 23:32:29 --> Security Class Initialized
DEBUG - 2018-07-24 23:32:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 23:32:30 --> Output Class Initialized
INFO - 2018-07-24 23:32:30 --> Input Class Initialized
INFO - 2018-07-24 23:32:30 --> Security Class Initialized
INFO - 2018-07-24 23:32:30 --> Language Class Initialized
ERROR - 2018-07-24 23:32:30 --> 404 Page Not Found: /index
DEBUG - 2018-07-24 23:32:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 23:32:30 --> Input Class Initialized
INFO - 2018-07-24 23:32:30 --> Config Class Initialized
INFO - 2018-07-24 23:32:30 --> Hooks Class Initialized
INFO - 2018-07-24 23:32:30 --> Language Class Initialized
DEBUG - 2018-07-24 23:32:30 --> UTF-8 Support Enabled
ERROR - 2018-07-24 23:32:30 --> 404 Page Not Found: /index
INFO - 2018-07-24 23:32:30 --> Utf8 Class Initialized
INFO - 2018-07-24 23:32:30 --> URI Class Initialized
INFO - 2018-07-24 23:32:30 --> Router Class Initialized
INFO - 2018-07-24 23:32:30 --> Output Class Initialized
INFO - 2018-07-24 23:32:30 --> Security Class Initialized
DEBUG - 2018-07-24 23:32:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 23:32:30 --> Input Class Initialized
INFO - 2018-07-24 23:32:30 --> Language Class Initialized
ERROR - 2018-07-24 23:32:30 --> 404 Page Not Found: /index
INFO - 2018-07-24 23:32:30 --> Config Class Initialized
INFO - 2018-07-24 23:32:30 --> Hooks Class Initialized
DEBUG - 2018-07-24 23:32:30 --> UTF-8 Support Enabled
INFO - 2018-07-24 23:32:30 --> Utf8 Class Initialized
INFO - 2018-07-24 23:32:30 --> URI Class Initialized
INFO - 2018-07-24 23:32:30 --> Router Class Initialized
INFO - 2018-07-24 23:32:30 --> Output Class Initialized
INFO - 2018-07-24 23:32:30 --> Security Class Initialized
DEBUG - 2018-07-24 23:32:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 23:32:30 --> Input Class Initialized
INFO - 2018-07-24 23:32:30 --> Language Class Initialized
ERROR - 2018-07-24 23:32:30 --> 404 Page Not Found: /index
INFO - 2018-07-24 23:32:32 --> Config Class Initialized
INFO - 2018-07-24 23:32:32 --> Config Class Initialized
INFO - 2018-07-24 23:32:32 --> Hooks Class Initialized
INFO - 2018-07-24 23:32:32 --> Hooks Class Initialized
DEBUG - 2018-07-24 23:32:32 --> UTF-8 Support Enabled
DEBUG - 2018-07-24 23:32:32 --> UTF-8 Support Enabled
INFO - 2018-07-24 23:32:32 --> Utf8 Class Initialized
INFO - 2018-07-24 23:32:32 --> Utf8 Class Initialized
INFO - 2018-07-24 23:32:32 --> URI Class Initialized
INFO - 2018-07-24 23:32:32 --> URI Class Initialized
INFO - 2018-07-24 23:32:32 --> Router Class Initialized
INFO - 2018-07-24 23:32:33 --> Router Class Initialized
INFO - 2018-07-24 23:32:33 --> Output Class Initialized
INFO - 2018-07-24 23:32:33 --> Security Class Initialized
INFO - 2018-07-24 23:32:33 --> Output Class Initialized
DEBUG - 2018-07-24 23:32:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 23:32:33 --> Security Class Initialized
INFO - 2018-07-24 23:32:33 --> Input Class Initialized
DEBUG - 2018-07-24 23:32:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 23:32:33 --> Input Class Initialized
INFO - 2018-07-24 23:32:33 --> Language Class Initialized
ERROR - 2018-07-24 23:32:33 --> 404 Page Not Found: /index
INFO - 2018-07-24 23:32:33 --> Language Class Initialized
ERROR - 2018-07-24 23:32:33 --> 404 Page Not Found: /index
INFO - 2018-07-24 23:32:33 --> Config Class Initialized
INFO - 2018-07-24 23:32:33 --> Hooks Class Initialized
DEBUG - 2018-07-24 23:32:33 --> UTF-8 Support Enabled
INFO - 2018-07-24 23:32:33 --> Utf8 Class Initialized
INFO - 2018-07-24 23:32:33 --> URI Class Initialized
INFO - 2018-07-24 23:32:33 --> Router Class Initialized
INFO - 2018-07-24 23:32:33 --> Output Class Initialized
INFO - 2018-07-24 23:32:33 --> Security Class Initialized
DEBUG - 2018-07-24 23:32:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 23:32:33 --> Input Class Initialized
INFO - 2018-07-24 23:32:33 --> Language Class Initialized
ERROR - 2018-07-24 23:32:33 --> 404 Page Not Found: /index
INFO - 2018-07-24 23:32:33 --> Config Class Initialized
INFO - 2018-07-24 23:32:33 --> Hooks Class Initialized
DEBUG - 2018-07-24 23:32:33 --> UTF-8 Support Enabled
INFO - 2018-07-24 23:32:33 --> Utf8 Class Initialized
INFO - 2018-07-24 23:32:33 --> URI Class Initialized
INFO - 2018-07-24 23:32:33 --> Router Class Initialized
INFO - 2018-07-24 23:32:33 --> Output Class Initialized
INFO - 2018-07-24 23:32:33 --> Security Class Initialized
DEBUG - 2018-07-24 23:32:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 23:32:33 --> Input Class Initialized
INFO - 2018-07-24 23:32:33 --> Language Class Initialized
ERROR - 2018-07-24 23:32:33 --> 404 Page Not Found: /index
INFO - 2018-07-24 23:34:43 --> Config Class Initialized
INFO - 2018-07-24 23:34:43 --> Hooks Class Initialized
DEBUG - 2018-07-24 23:34:43 --> UTF-8 Support Enabled
INFO - 2018-07-24 23:34:43 --> Utf8 Class Initialized
INFO - 2018-07-24 23:34:43 --> URI Class Initialized
INFO - 2018-07-24 23:34:43 --> Router Class Initialized
INFO - 2018-07-24 23:34:43 --> Output Class Initialized
INFO - 2018-07-24 23:34:43 --> Security Class Initialized
DEBUG - 2018-07-24 23:34:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 23:34:43 --> Input Class Initialized
INFO - 2018-07-24 23:34:43 --> Language Class Initialized
INFO - 2018-07-24 23:34:43 --> Language Class Initialized
INFO - 2018-07-24 23:34:43 --> Config Class Initialized
INFO - 2018-07-24 23:34:43 --> Loader Class Initialized
DEBUG - 2018-07-24 23:34:43 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-24 23:34:43 --> Helper loaded: url_helper
INFO - 2018-07-24 23:34:43 --> Helper loaded: form_helper
INFO - 2018-07-24 23:34:43 --> Helper loaded: date_helper
INFO - 2018-07-24 23:34:43 --> Helper loaded: util_helper
INFO - 2018-07-24 23:34:43 --> Helper loaded: text_helper
INFO - 2018-07-24 23:34:43 --> Helper loaded: string_helper
INFO - 2018-07-24 23:34:43 --> Database Driver Class Initialized
DEBUG - 2018-07-24 23:34:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-24 23:34:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-24 23:34:44 --> Email Class Initialized
INFO - 2018-07-24 23:34:44 --> Controller Class Initialized
DEBUG - 2018-07-24 23:34:44 --> Home MX_Controller Initialized
DEBUG - 2018-07-24 23:34:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-24 23:34:44 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-24 23:34:44 --> Login MX_Controller Initialized
INFO - 2018-07-24 23:34:44 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-24 23:34:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-24 23:34:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-24 23:34:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-07-24 23:34:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-07-24 23:34:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-07-24 23:34:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-07-24 23:34:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-07-24 23:34:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-07-24 23:34:44 --> Final output sent to browser
DEBUG - 2018-07-24 23:34:44 --> Total execution time: 0.4958
INFO - 2018-07-24 23:34:45 --> Config Class Initialized
INFO - 2018-07-24 23:34:45 --> Hooks Class Initialized
INFO - 2018-07-24 23:34:45 --> Config Class Initialized
INFO - 2018-07-24 23:34:45 --> Hooks Class Initialized
DEBUG - 2018-07-24 23:34:45 --> UTF-8 Support Enabled
DEBUG - 2018-07-24 23:34:45 --> UTF-8 Support Enabled
INFO - 2018-07-24 23:34:45 --> Utf8 Class Initialized
INFO - 2018-07-24 23:34:45 --> URI Class Initialized
INFO - 2018-07-24 23:34:45 --> Router Class Initialized
INFO - 2018-07-24 23:34:45 --> Output Class Initialized
INFO - 2018-07-24 23:34:45 --> Security Class Initialized
DEBUG - 2018-07-24 23:34:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 23:34:45 --> Input Class Initialized
INFO - 2018-07-24 23:34:45 --> Language Class Initialized
INFO - 2018-07-24 23:34:45 --> Utf8 Class Initialized
ERROR - 2018-07-24 23:34:45 --> 404 Page Not Found: /index
INFO - 2018-07-24 23:34:45 --> URI Class Initialized
INFO - 2018-07-24 23:34:45 --> Router Class Initialized
INFO - 2018-07-24 23:34:45 --> Config Class Initialized
INFO - 2018-07-24 23:34:45 --> Output Class Initialized
INFO - 2018-07-24 23:34:45 --> Hooks Class Initialized
DEBUG - 2018-07-24 23:34:45 --> UTF-8 Support Enabled
INFO - 2018-07-24 23:34:45 --> Utf8 Class Initialized
INFO - 2018-07-24 23:34:45 --> Security Class Initialized
INFO - 2018-07-24 23:34:45 --> URI Class Initialized
DEBUG - 2018-07-24 23:34:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 23:34:46 --> Input Class Initialized
INFO - 2018-07-24 23:34:46 --> Language Class Initialized
ERROR - 2018-07-24 23:34:46 --> 404 Page Not Found: /index
INFO - 2018-07-24 23:34:46 --> Router Class Initialized
INFO - 2018-07-24 23:34:46 --> Output Class Initialized
INFO - 2018-07-24 23:34:46 --> Security Class Initialized
DEBUG - 2018-07-24 23:34:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 23:34:46 --> Input Class Initialized
INFO - 2018-07-24 23:34:46 --> Language Class Initialized
ERROR - 2018-07-24 23:34:46 --> 404 Page Not Found: /index
INFO - 2018-07-24 23:34:46 --> Config Class Initialized
INFO - 2018-07-24 23:34:46 --> Hooks Class Initialized
DEBUG - 2018-07-24 23:34:46 --> UTF-8 Support Enabled
INFO - 2018-07-24 23:34:46 --> Utf8 Class Initialized
INFO - 2018-07-24 23:34:46 --> URI Class Initialized
INFO - 2018-07-24 23:34:46 --> Router Class Initialized
INFO - 2018-07-24 23:34:46 --> Output Class Initialized
INFO - 2018-07-24 23:34:46 --> Security Class Initialized
DEBUG - 2018-07-24 23:34:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-24 23:34:46 --> Input Class Initialized
INFO - 2018-07-24 23:34:46 --> Language Class Initialized
ERROR - 2018-07-24 23:34:46 --> 404 Page Not Found: /index
