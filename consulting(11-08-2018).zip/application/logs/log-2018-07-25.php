<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-07-25 00:05:33 --> Config Class Initialized
INFO - 2018-07-25 00:05:33 --> Config Class Initialized
INFO - 2018-07-25 00:05:33 --> Hooks Class Initialized
INFO - 2018-07-25 00:05:33 --> Hooks Class Initialized
DEBUG - 2018-07-25 00:05:33 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:05:33 --> Utf8 Class Initialized
DEBUG - 2018-07-25 00:05:33 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:05:34 --> URI Class Initialized
INFO - 2018-07-25 00:05:34 --> Router Class Initialized
INFO - 2018-07-25 00:05:34 --> Output Class Initialized
INFO - 2018-07-25 00:05:34 --> Security Class Initialized
DEBUG - 2018-07-25 00:05:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:05:34 --> Input Class Initialized
INFO - 2018-07-25 00:05:34 --> Utf8 Class Initialized
INFO - 2018-07-25 00:05:34 --> Language Class Initialized
INFO - 2018-07-25 00:05:34 --> URI Class Initialized
ERROR - 2018-07-25 00:05:34 --> 404 Page Not Found: /index
INFO - 2018-07-25 00:05:34 --> Router Class Initialized
INFO - 2018-07-25 00:05:34 --> Output Class Initialized
INFO - 2018-07-25 00:05:34 --> Config Class Initialized
INFO - 2018-07-25 00:05:34 --> Hooks Class Initialized
INFO - 2018-07-25 00:05:34 --> Security Class Initialized
DEBUG - 2018-07-25 00:05:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-07-25 00:05:34 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:05:34 --> Utf8 Class Initialized
INFO - 2018-07-25 00:05:34 --> Input Class Initialized
INFO - 2018-07-25 00:05:34 --> Language Class Initialized
INFO - 2018-07-25 00:05:34 --> URI Class Initialized
ERROR - 2018-07-25 00:05:34 --> 404 Page Not Found: /index
INFO - 2018-07-25 00:05:34 --> Router Class Initialized
INFO - 2018-07-25 00:05:34 --> Output Class Initialized
INFO - 2018-07-25 00:05:34 --> Security Class Initialized
DEBUG - 2018-07-25 00:05:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:05:34 --> Input Class Initialized
INFO - 2018-07-25 00:05:34 --> Language Class Initialized
ERROR - 2018-07-25 00:05:34 --> 404 Page Not Found: /index
INFO - 2018-07-25 00:05:34 --> Config Class Initialized
INFO - 2018-07-25 00:05:34 --> Hooks Class Initialized
DEBUG - 2018-07-25 00:05:34 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:05:34 --> Utf8 Class Initialized
INFO - 2018-07-25 00:05:34 --> URI Class Initialized
INFO - 2018-07-25 00:05:34 --> Router Class Initialized
INFO - 2018-07-25 00:05:34 --> Output Class Initialized
INFO - 2018-07-25 00:05:34 --> Security Class Initialized
DEBUG - 2018-07-25 00:05:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:05:34 --> Input Class Initialized
INFO - 2018-07-25 00:05:34 --> Language Class Initialized
ERROR - 2018-07-25 00:05:34 --> 404 Page Not Found: /index
INFO - 2018-07-25 00:05:35 --> Config Class Initialized
INFO - 2018-07-25 00:05:35 --> Hooks Class Initialized
DEBUG - 2018-07-25 00:05:35 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:05:35 --> Utf8 Class Initialized
INFO - 2018-07-25 00:05:35 --> URI Class Initialized
INFO - 2018-07-25 00:05:35 --> Router Class Initialized
INFO - 2018-07-25 00:05:35 --> Output Class Initialized
INFO - 2018-07-25 00:05:35 --> Security Class Initialized
DEBUG - 2018-07-25 00:05:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:05:35 --> Input Class Initialized
INFO - 2018-07-25 00:05:35 --> Language Class Initialized
INFO - 2018-07-25 00:05:35 --> Language Class Initialized
INFO - 2018-07-25 00:05:35 --> Config Class Initialized
INFO - 2018-07-25 00:05:35 --> Loader Class Initialized
DEBUG - 2018-07-25 00:05:35 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-25 00:05:35 --> Helper loaded: url_helper
INFO - 2018-07-25 00:05:35 --> Helper loaded: form_helper
INFO - 2018-07-25 00:05:35 --> Helper loaded: date_helper
INFO - 2018-07-25 00:05:35 --> Helper loaded: util_helper
INFO - 2018-07-25 00:05:35 --> Helper loaded: text_helper
INFO - 2018-07-25 00:05:35 --> Helper loaded: string_helper
INFO - 2018-07-25 00:05:35 --> Database Driver Class Initialized
DEBUG - 2018-07-25 00:05:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 00:05:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 00:05:35 --> Email Class Initialized
INFO - 2018-07-25 00:05:35 --> Controller Class Initialized
DEBUG - 2018-07-25 00:05:35 --> Home MX_Controller Initialized
DEBUG - 2018-07-25 00:05:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-25 00:05:35 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-25 00:05:35 --> Login MX_Controller Initialized
INFO - 2018-07-25 00:05:35 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-25 00:05:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-25 00:05:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-25 00:05:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-07-25 00:05:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-07-25 00:05:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-07-25 00:05:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-07-25 00:05:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-07-25 00:05:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-07-25 00:05:35 --> Final output sent to browser
DEBUG - 2018-07-25 00:05:35 --> Total execution time: 0.3462
INFO - 2018-07-25 00:05:36 --> Config Class Initialized
INFO - 2018-07-25 00:05:36 --> Config Class Initialized
INFO - 2018-07-25 00:05:36 --> Hooks Class Initialized
INFO - 2018-07-25 00:05:36 --> Hooks Class Initialized
DEBUG - 2018-07-25 00:05:36 --> UTF-8 Support Enabled
DEBUG - 2018-07-25 00:05:36 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:05:36 --> Utf8 Class Initialized
INFO - 2018-07-25 00:05:36 --> Utf8 Class Initialized
INFO - 2018-07-25 00:05:36 --> URI Class Initialized
INFO - 2018-07-25 00:05:36 --> URI Class Initialized
INFO - 2018-07-25 00:05:36 --> Router Class Initialized
INFO - 2018-07-25 00:05:36 --> Router Class Initialized
INFO - 2018-07-25 00:05:36 --> Output Class Initialized
INFO - 2018-07-25 00:05:36 --> Output Class Initialized
INFO - 2018-07-25 00:05:36 --> Security Class Initialized
INFO - 2018-07-25 00:05:36 --> Security Class Initialized
DEBUG - 2018-07-25 00:05:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-07-25 00:05:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:05:36 --> Input Class Initialized
INFO - 2018-07-25 00:05:36 --> Input Class Initialized
INFO - 2018-07-25 00:05:36 --> Language Class Initialized
INFO - 2018-07-25 00:05:36 --> Language Class Initialized
ERROR - 2018-07-25 00:05:36 --> 404 Page Not Found: /index
ERROR - 2018-07-25 00:05:36 --> 404 Page Not Found: /index
INFO - 2018-07-25 00:05:36 --> Config Class Initialized
INFO - 2018-07-25 00:05:36 --> Hooks Class Initialized
DEBUG - 2018-07-25 00:05:36 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:05:36 --> Utf8 Class Initialized
INFO - 2018-07-25 00:05:36 --> URI Class Initialized
INFO - 2018-07-25 00:05:36 --> Router Class Initialized
INFO - 2018-07-25 00:05:36 --> Output Class Initialized
INFO - 2018-07-25 00:05:36 --> Security Class Initialized
DEBUG - 2018-07-25 00:05:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:05:36 --> Input Class Initialized
INFO - 2018-07-25 00:05:36 --> Language Class Initialized
ERROR - 2018-07-25 00:05:36 --> 404 Page Not Found: /index
INFO - 2018-07-25 00:05:36 --> Config Class Initialized
INFO - 2018-07-25 00:05:36 --> Hooks Class Initialized
DEBUG - 2018-07-25 00:05:36 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:05:36 --> Utf8 Class Initialized
INFO - 2018-07-25 00:05:36 --> URI Class Initialized
INFO - 2018-07-25 00:05:36 --> Router Class Initialized
INFO - 2018-07-25 00:05:36 --> Output Class Initialized
INFO - 2018-07-25 00:05:36 --> Security Class Initialized
DEBUG - 2018-07-25 00:05:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:05:36 --> Input Class Initialized
INFO - 2018-07-25 00:05:36 --> Language Class Initialized
ERROR - 2018-07-25 00:05:36 --> 404 Page Not Found: /index
INFO - 2018-07-25 00:05:50 --> Config Class Initialized
INFO - 2018-07-25 00:05:50 --> Config Class Initialized
INFO - 2018-07-25 00:05:50 --> Hooks Class Initialized
INFO - 2018-07-25 00:05:50 --> Hooks Class Initialized
DEBUG - 2018-07-25 00:05:50 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:05:50 --> Utf8 Class Initialized
DEBUG - 2018-07-25 00:05:50 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:05:50 --> URI Class Initialized
INFO - 2018-07-25 00:05:50 --> Utf8 Class Initialized
INFO - 2018-07-25 00:05:50 --> Router Class Initialized
INFO - 2018-07-25 00:05:50 --> Output Class Initialized
INFO - 2018-07-25 00:05:50 --> URI Class Initialized
INFO - 2018-07-25 00:05:50 --> Security Class Initialized
DEBUG - 2018-07-25 00:05:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:05:50 --> Input Class Initialized
INFO - 2018-07-25 00:05:50 --> Language Class Initialized
ERROR - 2018-07-25 00:05:50 --> 404 Page Not Found: /index
INFO - 2018-07-25 00:05:50 --> Config Class Initialized
INFO - 2018-07-25 00:05:50 --> Hooks Class Initialized
DEBUG - 2018-07-25 00:05:50 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:05:50 --> Router Class Initialized
INFO - 2018-07-25 00:05:50 --> Utf8 Class Initialized
INFO - 2018-07-25 00:05:50 --> URI Class Initialized
INFO - 2018-07-25 00:05:50 --> Router Class Initialized
INFO - 2018-07-25 00:05:50 --> Output Class Initialized
INFO - 2018-07-25 00:05:50 --> Output Class Initialized
INFO - 2018-07-25 00:05:50 --> Security Class Initialized
DEBUG - 2018-07-25 00:05:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:05:50 --> Input Class Initialized
INFO - 2018-07-25 00:05:50 --> Language Class Initialized
ERROR - 2018-07-25 00:05:50 --> 404 Page Not Found: /index
INFO - 2018-07-25 00:05:50 --> Config Class Initialized
INFO - 2018-07-25 00:05:50 --> Hooks Class Initialized
DEBUG - 2018-07-25 00:05:50 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:05:50 --> Security Class Initialized
INFO - 2018-07-25 00:05:50 --> Utf8 Class Initialized
DEBUG - 2018-07-25 00:05:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:05:50 --> Input Class Initialized
INFO - 2018-07-25 00:05:50 --> URI Class Initialized
INFO - 2018-07-25 00:05:50 --> Language Class Initialized
INFO - 2018-07-25 00:05:50 --> Router Class Initialized
INFO - 2018-07-25 00:05:50 --> Output Class Initialized
ERROR - 2018-07-25 00:05:50 --> 404 Page Not Found: /index
INFO - 2018-07-25 00:05:50 --> Security Class Initialized
DEBUG - 2018-07-25 00:05:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:05:50 --> Input Class Initialized
INFO - 2018-07-25 00:05:50 --> Language Class Initialized
ERROR - 2018-07-25 00:05:50 --> 404 Page Not Found: /index
INFO - 2018-07-25 00:06:04 --> Config Class Initialized
INFO - 2018-07-25 00:06:04 --> Hooks Class Initialized
INFO - 2018-07-25 00:06:04 --> Config Class Initialized
DEBUG - 2018-07-25 00:06:04 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:06:04 --> Utf8 Class Initialized
INFO - 2018-07-25 00:06:04 --> URI Class Initialized
INFO - 2018-07-25 00:06:04 --> Router Class Initialized
INFO - 2018-07-25 00:06:04 --> Output Class Initialized
INFO - 2018-07-25 00:06:04 --> Security Class Initialized
DEBUG - 2018-07-25 00:06:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:06:04 --> Input Class Initialized
INFO - 2018-07-25 00:06:04 --> Language Class Initialized
ERROR - 2018-07-25 00:06:04 --> 404 Page Not Found: /index
INFO - 2018-07-25 00:06:04 --> Hooks Class Initialized
INFO - 2018-07-25 00:06:04 --> Config Class Initialized
DEBUG - 2018-07-25 00:06:04 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:06:04 --> Hooks Class Initialized
DEBUG - 2018-07-25 00:06:04 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:06:04 --> Utf8 Class Initialized
INFO - 2018-07-25 00:06:04 --> URI Class Initialized
INFO - 2018-07-25 00:06:04 --> Utf8 Class Initialized
INFO - 2018-07-25 00:06:04 --> Router Class Initialized
INFO - 2018-07-25 00:06:04 --> Output Class Initialized
INFO - 2018-07-25 00:06:04 --> URI Class Initialized
INFO - 2018-07-25 00:06:04 --> Security Class Initialized
INFO - 2018-07-25 00:06:04 --> Router Class Initialized
DEBUG - 2018-07-25 00:06:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:06:04 --> Output Class Initialized
INFO - 2018-07-25 00:06:04 --> Security Class Initialized
INFO - 2018-07-25 00:06:04 --> Input Class Initialized
INFO - 2018-07-25 00:06:04 --> Language Class Initialized
DEBUG - 2018-07-25 00:06:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-07-25 00:06:04 --> 404 Page Not Found: /index
INFO - 2018-07-25 00:06:04 --> Input Class Initialized
INFO - 2018-07-25 00:06:04 --> Language Class Initialized
INFO - 2018-07-25 00:06:04 --> Config Class Initialized
INFO - 2018-07-25 00:06:04 --> Hooks Class Initialized
ERROR - 2018-07-25 00:06:04 --> 404 Page Not Found: /index
DEBUG - 2018-07-25 00:06:04 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:06:04 --> Utf8 Class Initialized
INFO - 2018-07-25 00:06:04 --> URI Class Initialized
INFO - 2018-07-25 00:06:04 --> Router Class Initialized
INFO - 2018-07-25 00:06:04 --> Output Class Initialized
INFO - 2018-07-25 00:06:04 --> Security Class Initialized
DEBUG - 2018-07-25 00:06:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:06:04 --> Input Class Initialized
INFO - 2018-07-25 00:06:04 --> Language Class Initialized
ERROR - 2018-07-25 00:06:04 --> 404 Page Not Found: /index
INFO - 2018-07-25 00:06:12 --> Config Class Initialized
INFO - 2018-07-25 00:06:12 --> Config Class Initialized
INFO - 2018-07-25 00:06:12 --> Hooks Class Initialized
DEBUG - 2018-07-25 00:06:12 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:06:12 --> Utf8 Class Initialized
INFO - 2018-07-25 00:06:12 --> URI Class Initialized
INFO - 2018-07-25 00:06:12 --> Router Class Initialized
INFO - 2018-07-25 00:06:12 --> Output Class Initialized
INFO - 2018-07-25 00:06:12 --> Security Class Initialized
DEBUG - 2018-07-25 00:06:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:06:12 --> Input Class Initialized
INFO - 2018-07-25 00:06:12 --> Language Class Initialized
INFO - 2018-07-25 00:06:12 --> Hooks Class Initialized
ERROR - 2018-07-25 00:06:12 --> 404 Page Not Found: /index
INFO - 2018-07-25 00:06:12 --> Config Class Initialized
INFO - 2018-07-25 00:06:12 --> Hooks Class Initialized
DEBUG - 2018-07-25 00:06:12 --> UTF-8 Support Enabled
DEBUG - 2018-07-25 00:06:12 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:06:12 --> Utf8 Class Initialized
INFO - 2018-07-25 00:06:12 --> URI Class Initialized
INFO - 2018-07-25 00:06:12 --> Utf8 Class Initialized
INFO - 2018-07-25 00:06:12 --> Router Class Initialized
INFO - 2018-07-25 00:06:12 --> URI Class Initialized
INFO - 2018-07-25 00:06:12 --> Output Class Initialized
INFO - 2018-07-25 00:06:12 --> Router Class Initialized
INFO - 2018-07-25 00:06:12 --> Security Class Initialized
DEBUG - 2018-07-25 00:06:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:06:12 --> Output Class Initialized
INFO - 2018-07-25 00:06:12 --> Input Class Initialized
INFO - 2018-07-25 00:06:12 --> Security Class Initialized
DEBUG - 2018-07-25 00:06:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:06:12 --> Language Class Initialized
ERROR - 2018-07-25 00:06:12 --> 404 Page Not Found: /index
INFO - 2018-07-25 00:06:12 --> Input Class Initialized
INFO - 2018-07-25 00:06:12 --> Language Class Initialized
INFO - 2018-07-25 00:06:12 --> Config Class Initialized
INFO - 2018-07-25 00:06:12 --> Hooks Class Initialized
ERROR - 2018-07-25 00:06:12 --> 404 Page Not Found: /index
DEBUG - 2018-07-25 00:06:12 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:06:12 --> Utf8 Class Initialized
INFO - 2018-07-25 00:06:12 --> URI Class Initialized
INFO - 2018-07-25 00:06:12 --> Router Class Initialized
INFO - 2018-07-25 00:06:12 --> Output Class Initialized
INFO - 2018-07-25 00:06:12 --> Security Class Initialized
DEBUG - 2018-07-25 00:06:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:06:12 --> Input Class Initialized
INFO - 2018-07-25 00:06:12 --> Language Class Initialized
ERROR - 2018-07-25 00:06:12 --> 404 Page Not Found: /index
INFO - 2018-07-25 00:07:40 --> Config Class Initialized
INFO - 2018-07-25 00:07:40 --> Hooks Class Initialized
DEBUG - 2018-07-25 00:07:40 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:07:40 --> Utf8 Class Initialized
INFO - 2018-07-25 00:07:40 --> URI Class Initialized
INFO - 2018-07-25 00:07:40 --> Router Class Initialized
INFO - 2018-07-25 00:07:40 --> Output Class Initialized
INFO - 2018-07-25 00:07:40 --> Security Class Initialized
DEBUG - 2018-07-25 00:07:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:07:40 --> Input Class Initialized
INFO - 2018-07-25 00:07:40 --> Language Class Initialized
INFO - 2018-07-25 00:07:40 --> Language Class Initialized
INFO - 2018-07-25 00:07:40 --> Config Class Initialized
INFO - 2018-07-25 00:07:40 --> Loader Class Initialized
DEBUG - 2018-07-25 00:07:40 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-25 00:07:40 --> Helper loaded: url_helper
INFO - 2018-07-25 00:07:40 --> Helper loaded: form_helper
INFO - 2018-07-25 00:07:40 --> Helper loaded: date_helper
INFO - 2018-07-25 00:07:40 --> Helper loaded: util_helper
INFO - 2018-07-25 00:07:40 --> Helper loaded: text_helper
INFO - 2018-07-25 00:07:40 --> Helper loaded: string_helper
INFO - 2018-07-25 00:07:40 --> Database Driver Class Initialized
DEBUG - 2018-07-25 00:07:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 00:07:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 00:07:40 --> Email Class Initialized
INFO - 2018-07-25 00:07:40 --> Controller Class Initialized
DEBUG - 2018-07-25 00:07:40 --> Home MX_Controller Initialized
DEBUG - 2018-07-25 00:07:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-25 00:07:40 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-25 00:07:40 --> Login MX_Controller Initialized
INFO - 2018-07-25 00:07:40 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-25 00:07:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-25 00:07:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-25 00:07:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-07-25 00:07:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-07-25 00:07:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-07-25 00:07:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-07-25 00:07:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-07-25 00:07:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-07-25 00:07:40 --> Final output sent to browser
DEBUG - 2018-07-25 00:07:40 --> Total execution time: 0.3691
INFO - 2018-07-25 00:07:41 --> Config Class Initialized
INFO - 2018-07-25 00:07:41 --> Config Class Initialized
INFO - 2018-07-25 00:07:41 --> Hooks Class Initialized
INFO - 2018-07-25 00:07:41 --> Hooks Class Initialized
DEBUG - 2018-07-25 00:07:41 --> UTF-8 Support Enabled
DEBUG - 2018-07-25 00:07:41 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:07:41 --> Utf8 Class Initialized
INFO - 2018-07-25 00:07:41 --> URI Class Initialized
INFO - 2018-07-25 00:07:41 --> Router Class Initialized
INFO - 2018-07-25 00:07:41 --> Output Class Initialized
INFO - 2018-07-25 00:07:41 --> Security Class Initialized
DEBUG - 2018-07-25 00:07:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:07:41 --> Input Class Initialized
INFO - 2018-07-25 00:07:41 --> Language Class Initialized
ERROR - 2018-07-25 00:07:41 --> 404 Page Not Found: /index
INFO - 2018-07-25 00:07:41 --> Utf8 Class Initialized
INFO - 2018-07-25 00:07:41 --> URI Class Initialized
INFO - 2018-07-25 00:07:41 --> Config Class Initialized
INFO - 2018-07-25 00:07:41 --> Router Class Initialized
INFO - 2018-07-25 00:07:41 --> Hooks Class Initialized
DEBUG - 2018-07-25 00:07:41 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:07:41 --> Utf8 Class Initialized
INFO - 2018-07-25 00:07:41 --> URI Class Initialized
INFO - 2018-07-25 00:07:41 --> Router Class Initialized
INFO - 2018-07-25 00:07:41 --> Output Class Initialized
INFO - 2018-07-25 00:07:41 --> Output Class Initialized
INFO - 2018-07-25 00:07:41 --> Security Class Initialized
DEBUG - 2018-07-25 00:07:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:07:41 --> Input Class Initialized
INFO - 2018-07-25 00:07:41 --> Language Class Initialized
ERROR - 2018-07-25 00:07:41 --> 404 Page Not Found: /index
INFO - 2018-07-25 00:07:41 --> Security Class Initialized
DEBUG - 2018-07-25 00:07:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:07:42 --> Input Class Initialized
INFO - 2018-07-25 00:07:42 --> Language Class Initialized
ERROR - 2018-07-25 00:07:42 --> 404 Page Not Found: /index
INFO - 2018-07-25 00:07:42 --> Config Class Initialized
INFO - 2018-07-25 00:07:42 --> Hooks Class Initialized
DEBUG - 2018-07-25 00:07:42 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:07:42 --> Utf8 Class Initialized
INFO - 2018-07-25 00:07:42 --> URI Class Initialized
INFO - 2018-07-25 00:07:42 --> Router Class Initialized
INFO - 2018-07-25 00:07:42 --> Output Class Initialized
INFO - 2018-07-25 00:07:42 --> Security Class Initialized
DEBUG - 2018-07-25 00:07:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:07:42 --> Input Class Initialized
INFO - 2018-07-25 00:07:42 --> Language Class Initialized
ERROR - 2018-07-25 00:07:42 --> 404 Page Not Found: /index
INFO - 2018-07-25 00:07:47 --> Config Class Initialized
INFO - 2018-07-25 00:07:47 --> Hooks Class Initialized
DEBUG - 2018-07-25 00:07:47 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:07:47 --> Utf8 Class Initialized
INFO - 2018-07-25 00:07:47 --> URI Class Initialized
DEBUG - 2018-07-25 00:07:47 --> No URI present. Default controller set.
INFO - 2018-07-25 00:07:47 --> Router Class Initialized
INFO - 2018-07-25 00:07:47 --> Output Class Initialized
INFO - 2018-07-25 00:07:47 --> Security Class Initialized
DEBUG - 2018-07-25 00:07:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:07:47 --> Input Class Initialized
INFO - 2018-07-25 00:07:47 --> Language Class Initialized
INFO - 2018-07-25 00:07:47 --> Language Class Initialized
INFO - 2018-07-25 00:07:47 --> Config Class Initialized
INFO - 2018-07-25 00:07:47 --> Loader Class Initialized
DEBUG - 2018-07-25 00:07:47 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-25 00:07:47 --> Helper loaded: url_helper
INFO - 2018-07-25 00:07:47 --> Helper loaded: form_helper
INFO - 2018-07-25 00:07:47 --> Helper loaded: date_helper
INFO - 2018-07-25 00:07:47 --> Helper loaded: util_helper
INFO - 2018-07-25 00:07:47 --> Helper loaded: text_helper
INFO - 2018-07-25 00:07:47 --> Helper loaded: string_helper
INFO - 2018-07-25 00:07:47 --> Database Driver Class Initialized
DEBUG - 2018-07-25 00:07:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 00:07:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 00:07:47 --> Email Class Initialized
INFO - 2018-07-25 00:07:47 --> Controller Class Initialized
DEBUG - 2018-07-25 00:07:47 --> Home MX_Controller Initialized
DEBUG - 2018-07-25 00:07:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-25 00:07:47 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-25 00:07:47 --> Login MX_Controller Initialized
INFO - 2018-07-25 00:07:47 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-25 00:07:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-25 00:07:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-25 00:07:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-07-25 00:07:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-07-25 00:07:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-07-25 00:07:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-07-25 00:07:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-07-25 00:07:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-07-25 00:07:47 --> Final output sent to browser
DEBUG - 2018-07-25 00:07:47 --> Total execution time: 0.3589
INFO - 2018-07-25 00:07:48 --> Config Class Initialized
INFO - 2018-07-25 00:07:48 --> Hooks Class Initialized
DEBUG - 2018-07-25 00:07:48 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:07:48 --> Utf8 Class Initialized
INFO - 2018-07-25 00:07:48 --> URI Class Initialized
INFO - 2018-07-25 00:07:48 --> Router Class Initialized
INFO - 2018-07-25 00:07:48 --> Output Class Initialized
INFO - 2018-07-25 00:07:48 --> Security Class Initialized
DEBUG - 2018-07-25 00:07:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:07:48 --> Input Class Initialized
INFO - 2018-07-25 00:07:48 --> Language Class Initialized
ERROR - 2018-07-25 00:07:48 --> 404 Page Not Found: /index
INFO - 2018-07-25 00:07:48 --> Config Class Initialized
INFO - 2018-07-25 00:07:48 --> Hooks Class Initialized
DEBUG - 2018-07-25 00:07:48 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:07:48 --> Utf8 Class Initialized
INFO - 2018-07-25 00:07:48 --> URI Class Initialized
INFO - 2018-07-25 00:07:48 --> Router Class Initialized
INFO - 2018-07-25 00:07:48 --> Output Class Initialized
INFO - 2018-07-25 00:07:48 --> Security Class Initialized
DEBUG - 2018-07-25 00:07:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:07:48 --> Input Class Initialized
INFO - 2018-07-25 00:07:48 --> Language Class Initialized
ERROR - 2018-07-25 00:07:48 --> 404 Page Not Found: /index
INFO - 2018-07-25 00:07:48 --> Config Class Initialized
INFO - 2018-07-25 00:07:48 --> Hooks Class Initialized
DEBUG - 2018-07-25 00:07:48 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:07:48 --> Utf8 Class Initialized
INFO - 2018-07-25 00:07:48 --> URI Class Initialized
INFO - 2018-07-25 00:07:48 --> Router Class Initialized
INFO - 2018-07-25 00:07:48 --> Output Class Initialized
INFO - 2018-07-25 00:07:48 --> Security Class Initialized
DEBUG - 2018-07-25 00:07:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:07:48 --> Input Class Initialized
INFO - 2018-07-25 00:07:48 --> Language Class Initialized
ERROR - 2018-07-25 00:07:48 --> 404 Page Not Found: /index
INFO - 2018-07-25 00:08:53 --> Config Class Initialized
INFO - 2018-07-25 00:08:53 --> Hooks Class Initialized
DEBUG - 2018-07-25 00:08:53 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:08:53 --> Utf8 Class Initialized
INFO - 2018-07-25 00:08:53 --> URI Class Initialized
DEBUG - 2018-07-25 00:08:53 --> No URI present. Default controller set.
INFO - 2018-07-25 00:08:53 --> Router Class Initialized
INFO - 2018-07-25 00:08:53 --> Output Class Initialized
INFO - 2018-07-25 00:08:53 --> Security Class Initialized
DEBUG - 2018-07-25 00:08:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:08:53 --> Input Class Initialized
INFO - 2018-07-25 00:08:53 --> Language Class Initialized
INFO - 2018-07-25 00:08:53 --> Language Class Initialized
INFO - 2018-07-25 00:08:53 --> Config Class Initialized
INFO - 2018-07-25 00:08:53 --> Loader Class Initialized
DEBUG - 2018-07-25 00:08:53 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-25 00:08:53 --> Helper loaded: url_helper
INFO - 2018-07-25 00:08:53 --> Helper loaded: form_helper
INFO - 2018-07-25 00:08:53 --> Helper loaded: date_helper
INFO - 2018-07-25 00:08:53 --> Helper loaded: util_helper
INFO - 2018-07-25 00:08:53 --> Helper loaded: text_helper
INFO - 2018-07-25 00:08:53 --> Helper loaded: string_helper
INFO - 2018-07-25 00:08:53 --> Database Driver Class Initialized
DEBUG - 2018-07-25 00:08:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 00:08:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 00:08:53 --> Email Class Initialized
INFO - 2018-07-25 00:08:53 --> Controller Class Initialized
DEBUG - 2018-07-25 00:08:53 --> Home MX_Controller Initialized
DEBUG - 2018-07-25 00:08:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-25 00:08:53 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-25 00:08:53 --> Login MX_Controller Initialized
INFO - 2018-07-25 00:08:53 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-25 00:08:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-25 00:08:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-25 00:08:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-07-25 00:08:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-07-25 00:08:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-07-25 00:08:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-07-25 00:08:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-07-25 00:08:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-07-25 00:08:53 --> Final output sent to browser
DEBUG - 2018-07-25 00:08:53 --> Total execution time: 0.4112
INFO - 2018-07-25 00:08:54 --> Config Class Initialized
INFO - 2018-07-25 00:08:54 --> Hooks Class Initialized
DEBUG - 2018-07-25 00:08:54 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:08:54 --> Utf8 Class Initialized
INFO - 2018-07-25 00:08:54 --> URI Class Initialized
INFO - 2018-07-25 00:08:54 --> Router Class Initialized
INFO - 2018-07-25 00:08:54 --> Output Class Initialized
INFO - 2018-07-25 00:08:54 --> Security Class Initialized
DEBUG - 2018-07-25 00:08:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:08:54 --> Input Class Initialized
INFO - 2018-07-25 00:08:54 --> Language Class Initialized
ERROR - 2018-07-25 00:08:54 --> 404 Page Not Found: /index
INFO - 2018-07-25 00:08:54 --> Config Class Initialized
INFO - 2018-07-25 00:08:54 --> Hooks Class Initialized
DEBUG - 2018-07-25 00:08:54 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:08:54 --> Utf8 Class Initialized
INFO - 2018-07-25 00:08:54 --> URI Class Initialized
INFO - 2018-07-25 00:08:54 --> Router Class Initialized
INFO - 2018-07-25 00:08:54 --> Output Class Initialized
INFO - 2018-07-25 00:08:54 --> Security Class Initialized
DEBUG - 2018-07-25 00:08:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:08:54 --> Input Class Initialized
INFO - 2018-07-25 00:08:54 --> Language Class Initialized
ERROR - 2018-07-25 00:08:54 --> 404 Page Not Found: /index
INFO - 2018-07-25 00:08:54 --> Config Class Initialized
INFO - 2018-07-25 00:08:54 --> Hooks Class Initialized
DEBUG - 2018-07-25 00:08:54 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:08:54 --> Utf8 Class Initialized
INFO - 2018-07-25 00:08:54 --> URI Class Initialized
INFO - 2018-07-25 00:08:54 --> Router Class Initialized
INFO - 2018-07-25 00:08:54 --> Output Class Initialized
INFO - 2018-07-25 00:08:54 --> Security Class Initialized
DEBUG - 2018-07-25 00:08:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:08:54 --> Input Class Initialized
INFO - 2018-07-25 00:08:54 --> Language Class Initialized
ERROR - 2018-07-25 00:08:54 --> 404 Page Not Found: /index
INFO - 2018-07-25 00:09:08 --> Config Class Initialized
INFO - 2018-07-25 00:09:08 --> Hooks Class Initialized
DEBUG - 2018-07-25 00:09:08 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:09:08 --> Utf8 Class Initialized
INFO - 2018-07-25 00:09:08 --> URI Class Initialized
DEBUG - 2018-07-25 00:09:08 --> No URI present. Default controller set.
INFO - 2018-07-25 00:09:08 --> Router Class Initialized
INFO - 2018-07-25 00:09:08 --> Output Class Initialized
INFO - 2018-07-25 00:09:08 --> Security Class Initialized
DEBUG - 2018-07-25 00:09:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:09:08 --> Input Class Initialized
INFO - 2018-07-25 00:09:08 --> Language Class Initialized
INFO - 2018-07-25 00:09:08 --> Language Class Initialized
INFO - 2018-07-25 00:09:08 --> Config Class Initialized
INFO - 2018-07-25 00:09:08 --> Loader Class Initialized
DEBUG - 2018-07-25 00:09:08 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-25 00:09:08 --> Helper loaded: url_helper
INFO - 2018-07-25 00:09:08 --> Helper loaded: form_helper
INFO - 2018-07-25 00:09:08 --> Helper loaded: date_helper
INFO - 2018-07-25 00:09:08 --> Helper loaded: util_helper
INFO - 2018-07-25 00:09:08 --> Helper loaded: text_helper
INFO - 2018-07-25 00:09:08 --> Helper loaded: string_helper
INFO - 2018-07-25 00:09:08 --> Database Driver Class Initialized
DEBUG - 2018-07-25 00:09:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 00:09:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 00:09:08 --> Email Class Initialized
INFO - 2018-07-25 00:09:08 --> Controller Class Initialized
DEBUG - 2018-07-25 00:09:08 --> Home MX_Controller Initialized
DEBUG - 2018-07-25 00:09:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-25 00:09:08 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-25 00:09:08 --> Login MX_Controller Initialized
INFO - 2018-07-25 00:09:08 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-25 00:09:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-25 00:09:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-25 00:09:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-07-25 00:09:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-07-25 00:09:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-07-25 00:09:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-07-25 00:09:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-07-25 00:09:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-07-25 00:09:08 --> Final output sent to browser
DEBUG - 2018-07-25 00:09:09 --> Total execution time: 0.3853
INFO - 2018-07-25 00:09:09 --> Config Class Initialized
INFO - 2018-07-25 00:09:09 --> Hooks Class Initialized
DEBUG - 2018-07-25 00:09:09 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:09:09 --> Utf8 Class Initialized
INFO - 2018-07-25 00:09:09 --> URI Class Initialized
INFO - 2018-07-25 00:09:09 --> Router Class Initialized
INFO - 2018-07-25 00:09:09 --> Output Class Initialized
INFO - 2018-07-25 00:09:09 --> Security Class Initialized
DEBUG - 2018-07-25 00:09:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:09:09 --> Input Class Initialized
INFO - 2018-07-25 00:09:09 --> Language Class Initialized
ERROR - 2018-07-25 00:09:09 --> 404 Page Not Found: /index
INFO - 2018-07-25 00:09:09 --> Config Class Initialized
INFO - 2018-07-25 00:09:09 --> Hooks Class Initialized
DEBUG - 2018-07-25 00:09:09 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:09:09 --> Utf8 Class Initialized
INFO - 2018-07-25 00:09:09 --> URI Class Initialized
INFO - 2018-07-25 00:09:09 --> Router Class Initialized
INFO - 2018-07-25 00:09:09 --> Output Class Initialized
INFO - 2018-07-25 00:09:09 --> Security Class Initialized
DEBUG - 2018-07-25 00:09:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:09:09 --> Input Class Initialized
INFO - 2018-07-25 00:09:09 --> Language Class Initialized
ERROR - 2018-07-25 00:09:09 --> 404 Page Not Found: /index
INFO - 2018-07-25 00:09:09 --> Config Class Initialized
INFO - 2018-07-25 00:09:09 --> Hooks Class Initialized
DEBUG - 2018-07-25 00:09:09 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:09:09 --> Utf8 Class Initialized
INFO - 2018-07-25 00:09:09 --> URI Class Initialized
INFO - 2018-07-25 00:09:09 --> Router Class Initialized
INFO - 2018-07-25 00:09:09 --> Output Class Initialized
INFO - 2018-07-25 00:09:09 --> Security Class Initialized
DEBUG - 2018-07-25 00:09:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:09:09 --> Input Class Initialized
INFO - 2018-07-25 00:09:09 --> Language Class Initialized
ERROR - 2018-07-25 00:09:09 --> 404 Page Not Found: /index
INFO - 2018-07-25 00:09:12 --> Config Class Initialized
INFO - 2018-07-25 00:09:12 --> Hooks Class Initialized
DEBUG - 2018-07-25 00:09:12 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:09:12 --> Utf8 Class Initialized
INFO - 2018-07-25 00:09:12 --> URI Class Initialized
INFO - 2018-07-25 00:09:12 --> Router Class Initialized
INFO - 2018-07-25 00:09:12 --> Output Class Initialized
INFO - 2018-07-25 00:09:12 --> Security Class Initialized
DEBUG - 2018-07-25 00:09:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:09:12 --> Input Class Initialized
INFO - 2018-07-25 00:09:12 --> Language Class Initialized
ERROR - 2018-07-25 00:09:12 --> 404 Page Not Found: /index
INFO - 2018-07-25 00:09:12 --> Config Class Initialized
INFO - 2018-07-25 00:09:12 --> Hooks Class Initialized
DEBUG - 2018-07-25 00:09:12 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:09:12 --> Utf8 Class Initialized
INFO - 2018-07-25 00:09:12 --> URI Class Initialized
INFO - 2018-07-25 00:09:12 --> Router Class Initialized
INFO - 2018-07-25 00:09:12 --> Output Class Initialized
INFO - 2018-07-25 00:09:12 --> Security Class Initialized
DEBUG - 2018-07-25 00:09:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:09:12 --> Input Class Initialized
INFO - 2018-07-25 00:09:12 --> Language Class Initialized
ERROR - 2018-07-25 00:09:12 --> 404 Page Not Found: /index
INFO - 2018-07-25 00:09:12 --> Config Class Initialized
INFO - 2018-07-25 00:09:12 --> Hooks Class Initialized
DEBUG - 2018-07-25 00:09:12 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:09:12 --> Utf8 Class Initialized
INFO - 2018-07-25 00:09:12 --> URI Class Initialized
INFO - 2018-07-25 00:09:12 --> Router Class Initialized
INFO - 2018-07-25 00:09:12 --> Output Class Initialized
INFO - 2018-07-25 00:09:12 --> Security Class Initialized
DEBUG - 2018-07-25 00:09:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:09:12 --> Input Class Initialized
INFO - 2018-07-25 00:09:12 --> Language Class Initialized
ERROR - 2018-07-25 00:09:12 --> 404 Page Not Found: /index
INFO - 2018-07-25 00:11:33 --> Config Class Initialized
INFO - 2018-07-25 00:11:33 --> Hooks Class Initialized
DEBUG - 2018-07-25 00:11:33 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:11:33 --> Utf8 Class Initialized
INFO - 2018-07-25 00:11:33 --> URI Class Initialized
DEBUG - 2018-07-25 00:11:33 --> No URI present. Default controller set.
INFO - 2018-07-25 00:11:33 --> Router Class Initialized
INFO - 2018-07-25 00:11:33 --> Output Class Initialized
INFO - 2018-07-25 00:11:33 --> Security Class Initialized
DEBUG - 2018-07-25 00:11:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:11:33 --> Input Class Initialized
INFO - 2018-07-25 00:11:33 --> Language Class Initialized
INFO - 2018-07-25 00:11:33 --> Language Class Initialized
INFO - 2018-07-25 00:11:33 --> Config Class Initialized
INFO - 2018-07-25 00:11:33 --> Loader Class Initialized
DEBUG - 2018-07-25 00:11:33 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-25 00:11:33 --> Helper loaded: url_helper
INFO - 2018-07-25 00:11:33 --> Helper loaded: form_helper
INFO - 2018-07-25 00:11:33 --> Helper loaded: date_helper
INFO - 2018-07-25 00:11:33 --> Helper loaded: util_helper
INFO - 2018-07-25 00:11:33 --> Helper loaded: text_helper
INFO - 2018-07-25 00:11:33 --> Helper loaded: string_helper
INFO - 2018-07-25 00:11:33 --> Database Driver Class Initialized
DEBUG - 2018-07-25 00:11:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 00:11:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 00:11:33 --> Email Class Initialized
INFO - 2018-07-25 00:11:33 --> Controller Class Initialized
DEBUG - 2018-07-25 00:11:33 --> Home MX_Controller Initialized
DEBUG - 2018-07-25 00:11:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-25 00:11:33 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-25 00:11:33 --> Login MX_Controller Initialized
INFO - 2018-07-25 00:11:33 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-25 00:11:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-25 00:11:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-25 00:11:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-07-25 00:11:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-07-25 00:11:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-07-25 00:11:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-07-25 00:11:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-07-25 00:11:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-07-25 00:11:33 --> Final output sent to browser
DEBUG - 2018-07-25 00:11:33 --> Total execution time: 0.3878
INFO - 2018-07-25 00:11:33 --> Config Class Initialized
INFO - 2018-07-25 00:11:33 --> Config Class Initialized
INFO - 2018-07-25 00:11:33 --> Config Class Initialized
INFO - 2018-07-25 00:11:33 --> Hooks Class Initialized
INFO - 2018-07-25 00:11:33 --> Hooks Class Initialized
INFO - 2018-07-25 00:11:33 --> Hooks Class Initialized
DEBUG - 2018-07-25 00:11:33 --> UTF-8 Support Enabled
DEBUG - 2018-07-25 00:11:33 --> UTF-8 Support Enabled
DEBUG - 2018-07-25 00:11:33 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:11:33 --> Utf8 Class Initialized
INFO - 2018-07-25 00:11:33 --> Utf8 Class Initialized
INFO - 2018-07-25 00:11:33 --> Utf8 Class Initialized
INFO - 2018-07-25 00:11:33 --> URI Class Initialized
INFO - 2018-07-25 00:11:33 --> URI Class Initialized
INFO - 2018-07-25 00:11:33 --> URI Class Initialized
INFO - 2018-07-25 00:11:33 --> Router Class Initialized
INFO - 2018-07-25 00:11:33 --> Router Class Initialized
INFO - 2018-07-25 00:11:33 --> Router Class Initialized
INFO - 2018-07-25 00:11:33 --> Output Class Initialized
INFO - 2018-07-25 00:11:33 --> Output Class Initialized
INFO - 2018-07-25 00:11:33 --> Output Class Initialized
INFO - 2018-07-25 00:11:33 --> Security Class Initialized
INFO - 2018-07-25 00:11:33 --> Security Class Initialized
INFO - 2018-07-25 00:11:33 --> Security Class Initialized
DEBUG - 2018-07-25 00:11:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-07-25 00:11:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-07-25 00:11:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:11:33 --> Input Class Initialized
INFO - 2018-07-25 00:11:33 --> Input Class Initialized
INFO - 2018-07-25 00:11:33 --> Input Class Initialized
INFO - 2018-07-25 00:11:33 --> Language Class Initialized
INFO - 2018-07-25 00:11:33 --> Language Class Initialized
INFO - 2018-07-25 00:11:33 --> Language Class Initialized
ERROR - 2018-07-25 00:11:33 --> 404 Page Not Found: /index
ERROR - 2018-07-25 00:11:33 --> 404 Page Not Found: /index
ERROR - 2018-07-25 00:11:33 --> 404 Page Not Found: /index
INFO - 2018-07-25 00:11:34 --> Config Class Initialized
INFO - 2018-07-25 00:11:34 --> Hooks Class Initialized
DEBUG - 2018-07-25 00:11:34 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:11:34 --> Utf8 Class Initialized
INFO - 2018-07-25 00:11:34 --> URI Class Initialized
INFO - 2018-07-25 00:11:34 --> Router Class Initialized
INFO - 2018-07-25 00:11:34 --> Output Class Initialized
INFO - 2018-07-25 00:11:34 --> Security Class Initialized
DEBUG - 2018-07-25 00:11:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:11:34 --> Input Class Initialized
INFO - 2018-07-25 00:11:34 --> Language Class Initialized
ERROR - 2018-07-25 00:11:34 --> 404 Page Not Found: /index
INFO - 2018-07-25 00:11:34 --> Config Class Initialized
INFO - 2018-07-25 00:11:34 --> Hooks Class Initialized
DEBUG - 2018-07-25 00:11:34 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:11:34 --> Utf8 Class Initialized
INFO - 2018-07-25 00:11:34 --> URI Class Initialized
INFO - 2018-07-25 00:11:34 --> Router Class Initialized
INFO - 2018-07-25 00:11:34 --> Output Class Initialized
INFO - 2018-07-25 00:11:34 --> Security Class Initialized
DEBUG - 2018-07-25 00:11:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:11:34 --> Input Class Initialized
INFO - 2018-07-25 00:11:34 --> Language Class Initialized
ERROR - 2018-07-25 00:11:34 --> 404 Page Not Found: /index
INFO - 2018-07-25 00:11:34 --> Config Class Initialized
INFO - 2018-07-25 00:11:34 --> Hooks Class Initialized
DEBUG - 2018-07-25 00:11:34 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:11:34 --> Utf8 Class Initialized
INFO - 2018-07-25 00:11:34 --> URI Class Initialized
INFO - 2018-07-25 00:11:34 --> Router Class Initialized
INFO - 2018-07-25 00:11:34 --> Output Class Initialized
INFO - 2018-07-25 00:11:34 --> Security Class Initialized
DEBUG - 2018-07-25 00:11:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:11:34 --> Input Class Initialized
INFO - 2018-07-25 00:11:34 --> Language Class Initialized
ERROR - 2018-07-25 00:11:34 --> 404 Page Not Found: /index
INFO - 2018-07-25 00:11:34 --> Config Class Initialized
INFO - 2018-07-25 00:11:34 --> Hooks Class Initialized
DEBUG - 2018-07-25 00:11:34 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:11:34 --> Utf8 Class Initialized
INFO - 2018-07-25 00:11:34 --> URI Class Initialized
INFO - 2018-07-25 00:11:35 --> Router Class Initialized
INFO - 2018-07-25 00:11:35 --> Output Class Initialized
INFO - 2018-07-25 00:11:35 --> Security Class Initialized
DEBUG - 2018-07-25 00:11:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:11:35 --> Input Class Initialized
INFO - 2018-07-25 00:11:35 --> Language Class Initialized
ERROR - 2018-07-25 00:11:35 --> 404 Page Not Found: /index
INFO - 2018-07-25 00:11:35 --> Config Class Initialized
INFO - 2018-07-25 00:11:35 --> Hooks Class Initialized
DEBUG - 2018-07-25 00:11:35 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:11:35 --> Utf8 Class Initialized
INFO - 2018-07-25 00:11:35 --> URI Class Initialized
INFO - 2018-07-25 00:11:35 --> Router Class Initialized
INFO - 2018-07-25 00:11:35 --> Output Class Initialized
INFO - 2018-07-25 00:11:35 --> Security Class Initialized
DEBUG - 2018-07-25 00:11:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:11:35 --> Input Class Initialized
INFO - 2018-07-25 00:11:35 --> Language Class Initialized
ERROR - 2018-07-25 00:11:35 --> 404 Page Not Found: /index
INFO - 2018-07-25 00:11:35 --> Config Class Initialized
INFO - 2018-07-25 00:11:35 --> Hooks Class Initialized
DEBUG - 2018-07-25 00:11:35 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:11:35 --> Utf8 Class Initialized
INFO - 2018-07-25 00:11:35 --> URI Class Initialized
INFO - 2018-07-25 00:11:35 --> Router Class Initialized
INFO - 2018-07-25 00:11:35 --> Output Class Initialized
INFO - 2018-07-25 00:11:35 --> Security Class Initialized
DEBUG - 2018-07-25 00:11:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:11:35 --> Input Class Initialized
INFO - 2018-07-25 00:11:35 --> Language Class Initialized
ERROR - 2018-07-25 00:11:35 --> 404 Page Not Found: /index
INFO - 2018-07-25 00:12:01 --> Config Class Initialized
INFO - 2018-07-25 00:12:01 --> Hooks Class Initialized
DEBUG - 2018-07-25 00:12:01 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:12:01 --> Utf8 Class Initialized
INFO - 2018-07-25 00:12:01 --> URI Class Initialized
DEBUG - 2018-07-25 00:12:01 --> No URI present. Default controller set.
INFO - 2018-07-25 00:12:01 --> Router Class Initialized
INFO - 2018-07-25 00:12:01 --> Output Class Initialized
INFO - 2018-07-25 00:12:01 --> Security Class Initialized
DEBUG - 2018-07-25 00:12:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:12:01 --> Input Class Initialized
INFO - 2018-07-25 00:12:01 --> Language Class Initialized
INFO - 2018-07-25 00:12:01 --> Language Class Initialized
INFO - 2018-07-25 00:12:01 --> Config Class Initialized
INFO - 2018-07-25 00:12:01 --> Loader Class Initialized
DEBUG - 2018-07-25 00:12:01 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-25 00:12:01 --> Helper loaded: url_helper
INFO - 2018-07-25 00:12:01 --> Helper loaded: form_helper
INFO - 2018-07-25 00:12:01 --> Helper loaded: date_helper
INFO - 2018-07-25 00:12:01 --> Helper loaded: util_helper
INFO - 2018-07-25 00:12:01 --> Helper loaded: text_helper
INFO - 2018-07-25 00:12:01 --> Helper loaded: string_helper
INFO - 2018-07-25 00:12:01 --> Database Driver Class Initialized
DEBUG - 2018-07-25 00:12:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 00:12:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 00:12:01 --> Email Class Initialized
INFO - 2018-07-25 00:12:01 --> Controller Class Initialized
DEBUG - 2018-07-25 00:12:01 --> Home MX_Controller Initialized
DEBUG - 2018-07-25 00:12:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-25 00:12:01 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-25 00:12:01 --> Login MX_Controller Initialized
INFO - 2018-07-25 00:12:01 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-25 00:12:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-25 00:12:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-25 00:12:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-07-25 00:12:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-07-25 00:12:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-07-25 00:12:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-07-25 00:12:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-07-25 00:12:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-07-25 00:12:01 --> Final output sent to browser
DEBUG - 2018-07-25 00:12:01 --> Total execution time: 0.3953
INFO - 2018-07-25 00:12:01 --> Config Class Initialized
INFO - 2018-07-25 00:12:01 --> Config Class Initialized
INFO - 2018-07-25 00:12:01 --> Config Class Initialized
INFO - 2018-07-25 00:12:01 --> Hooks Class Initialized
INFO - 2018-07-25 00:12:01 --> Hooks Class Initialized
INFO - 2018-07-25 00:12:01 --> Hooks Class Initialized
DEBUG - 2018-07-25 00:12:01 --> UTF-8 Support Enabled
DEBUG - 2018-07-25 00:12:01 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:12:01 --> Utf8 Class Initialized
DEBUG - 2018-07-25 00:12:01 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:12:01 --> URI Class Initialized
INFO - 2018-07-25 00:12:01 --> Utf8 Class Initialized
INFO - 2018-07-25 00:12:01 --> Utf8 Class Initialized
INFO - 2018-07-25 00:12:01 --> URI Class Initialized
INFO - 2018-07-25 00:12:01 --> Router Class Initialized
INFO - 2018-07-25 00:12:01 --> URI Class Initialized
INFO - 2018-07-25 00:12:01 --> Router Class Initialized
INFO - 2018-07-25 00:12:01 --> Router Class Initialized
INFO - 2018-07-25 00:12:01 --> Output Class Initialized
INFO - 2018-07-25 00:12:01 --> Security Class Initialized
INFO - 2018-07-25 00:12:01 --> Output Class Initialized
INFO - 2018-07-25 00:12:01 --> Output Class Initialized
INFO - 2018-07-25 00:12:01 --> Security Class Initialized
INFO - 2018-07-25 00:12:01 --> Security Class Initialized
DEBUG - 2018-07-25 00:12:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:12:01 --> Input Class Initialized
DEBUG - 2018-07-25 00:12:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-07-25 00:12:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:12:01 --> Input Class Initialized
INFO - 2018-07-25 00:12:01 --> Language Class Initialized
ERROR - 2018-07-25 00:12:01 --> 404 Page Not Found: /index
INFO - 2018-07-25 00:12:01 --> Input Class Initialized
INFO - 2018-07-25 00:12:02 --> Language Class Initialized
INFO - 2018-07-25 00:12:02 --> Language Class Initialized
ERROR - 2018-07-25 00:12:02 --> 404 Page Not Found: /index
ERROR - 2018-07-25 00:12:02 --> 404 Page Not Found: /index
INFO - 2018-07-25 00:12:02 --> Config Class Initialized
INFO - 2018-07-25 00:12:02 --> Hooks Class Initialized
DEBUG - 2018-07-25 00:12:02 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:12:02 --> Utf8 Class Initialized
INFO - 2018-07-25 00:12:02 --> URI Class Initialized
INFO - 2018-07-25 00:12:02 --> Router Class Initialized
INFO - 2018-07-25 00:12:02 --> Output Class Initialized
INFO - 2018-07-25 00:12:02 --> Security Class Initialized
DEBUG - 2018-07-25 00:12:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:12:02 --> Input Class Initialized
INFO - 2018-07-25 00:12:02 --> Language Class Initialized
ERROR - 2018-07-25 00:12:02 --> 404 Page Not Found: /index
INFO - 2018-07-25 00:12:02 --> Config Class Initialized
INFO - 2018-07-25 00:12:02 --> Hooks Class Initialized
DEBUG - 2018-07-25 00:12:02 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:12:02 --> Utf8 Class Initialized
INFO - 2018-07-25 00:12:02 --> URI Class Initialized
INFO - 2018-07-25 00:12:02 --> Router Class Initialized
INFO - 2018-07-25 00:12:02 --> Output Class Initialized
INFO - 2018-07-25 00:12:02 --> Security Class Initialized
DEBUG - 2018-07-25 00:12:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:12:02 --> Input Class Initialized
INFO - 2018-07-25 00:12:02 --> Language Class Initialized
ERROR - 2018-07-25 00:12:02 --> 404 Page Not Found: /index
INFO - 2018-07-25 00:12:02 --> Config Class Initialized
INFO - 2018-07-25 00:12:02 --> Hooks Class Initialized
DEBUG - 2018-07-25 00:12:02 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:12:02 --> Utf8 Class Initialized
INFO - 2018-07-25 00:12:02 --> URI Class Initialized
INFO - 2018-07-25 00:12:02 --> Router Class Initialized
INFO - 2018-07-25 00:12:02 --> Output Class Initialized
INFO - 2018-07-25 00:12:02 --> Security Class Initialized
DEBUG - 2018-07-25 00:12:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:12:02 --> Input Class Initialized
INFO - 2018-07-25 00:12:02 --> Language Class Initialized
ERROR - 2018-07-25 00:12:02 --> 404 Page Not Found: /index
INFO - 2018-07-25 00:12:02 --> Config Class Initialized
INFO - 2018-07-25 00:12:02 --> Hooks Class Initialized
DEBUG - 2018-07-25 00:12:02 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:12:02 --> Utf8 Class Initialized
INFO - 2018-07-25 00:12:02 --> URI Class Initialized
INFO - 2018-07-25 00:12:02 --> Router Class Initialized
INFO - 2018-07-25 00:12:02 --> Output Class Initialized
INFO - 2018-07-25 00:12:02 --> Security Class Initialized
DEBUG - 2018-07-25 00:12:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:12:02 --> Input Class Initialized
INFO - 2018-07-25 00:12:02 --> Language Class Initialized
ERROR - 2018-07-25 00:12:02 --> 404 Page Not Found: /index
INFO - 2018-07-25 00:12:03 --> Config Class Initialized
INFO - 2018-07-25 00:12:03 --> Hooks Class Initialized
DEBUG - 2018-07-25 00:12:03 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:12:03 --> Utf8 Class Initialized
INFO - 2018-07-25 00:12:03 --> URI Class Initialized
INFO - 2018-07-25 00:12:03 --> Router Class Initialized
INFO - 2018-07-25 00:12:03 --> Output Class Initialized
INFO - 2018-07-25 00:12:03 --> Security Class Initialized
DEBUG - 2018-07-25 00:12:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:12:03 --> Input Class Initialized
INFO - 2018-07-25 00:12:03 --> Language Class Initialized
ERROR - 2018-07-25 00:12:03 --> 404 Page Not Found: /index
INFO - 2018-07-25 00:12:03 --> Config Class Initialized
INFO - 2018-07-25 00:12:03 --> Hooks Class Initialized
DEBUG - 2018-07-25 00:12:03 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:12:03 --> Utf8 Class Initialized
INFO - 2018-07-25 00:12:03 --> URI Class Initialized
INFO - 2018-07-25 00:12:03 --> Router Class Initialized
INFO - 2018-07-25 00:12:03 --> Output Class Initialized
INFO - 2018-07-25 00:12:03 --> Security Class Initialized
DEBUG - 2018-07-25 00:12:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:12:03 --> Input Class Initialized
INFO - 2018-07-25 00:12:03 --> Language Class Initialized
ERROR - 2018-07-25 00:12:03 --> 404 Page Not Found: /index
INFO - 2018-07-25 00:12:18 --> Config Class Initialized
INFO - 2018-07-25 00:12:18 --> Hooks Class Initialized
DEBUG - 2018-07-25 00:12:18 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:12:18 --> Utf8 Class Initialized
INFO - 2018-07-25 00:12:18 --> URI Class Initialized
DEBUG - 2018-07-25 00:12:18 --> No URI present. Default controller set.
INFO - 2018-07-25 00:12:18 --> Router Class Initialized
INFO - 2018-07-25 00:12:18 --> Output Class Initialized
INFO - 2018-07-25 00:12:18 --> Security Class Initialized
DEBUG - 2018-07-25 00:12:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:12:18 --> Input Class Initialized
INFO - 2018-07-25 00:12:18 --> Language Class Initialized
INFO - 2018-07-25 00:12:18 --> Language Class Initialized
INFO - 2018-07-25 00:12:18 --> Config Class Initialized
INFO - 2018-07-25 00:12:18 --> Loader Class Initialized
DEBUG - 2018-07-25 00:12:18 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-25 00:12:18 --> Helper loaded: url_helper
INFO - 2018-07-25 00:12:18 --> Helper loaded: form_helper
INFO - 2018-07-25 00:12:18 --> Helper loaded: date_helper
INFO - 2018-07-25 00:12:18 --> Helper loaded: util_helper
INFO - 2018-07-25 00:12:18 --> Helper loaded: text_helper
INFO - 2018-07-25 00:12:18 --> Helper loaded: string_helper
INFO - 2018-07-25 00:12:18 --> Database Driver Class Initialized
DEBUG - 2018-07-25 00:12:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 00:12:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 00:12:18 --> Email Class Initialized
INFO - 2018-07-25 00:12:18 --> Controller Class Initialized
DEBUG - 2018-07-25 00:12:18 --> Home MX_Controller Initialized
DEBUG - 2018-07-25 00:12:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-25 00:12:18 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-25 00:12:18 --> Login MX_Controller Initialized
INFO - 2018-07-25 00:12:18 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-25 00:12:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-25 00:12:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-25 00:12:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-07-25 00:12:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-07-25 00:12:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-07-25 00:12:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-07-25 00:12:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-07-25 00:12:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-07-25 00:12:18 --> Final output sent to browser
DEBUG - 2018-07-25 00:12:18 --> Total execution time: 0.4006
INFO - 2018-07-25 00:12:18 --> Config Class Initialized
INFO - 2018-07-25 00:12:18 --> Config Class Initialized
INFO - 2018-07-25 00:12:18 --> Config Class Initialized
INFO - 2018-07-25 00:12:18 --> Hooks Class Initialized
INFO - 2018-07-25 00:12:18 --> Hooks Class Initialized
INFO - 2018-07-25 00:12:18 --> Hooks Class Initialized
DEBUG - 2018-07-25 00:12:18 --> UTF-8 Support Enabled
DEBUG - 2018-07-25 00:12:18 --> UTF-8 Support Enabled
DEBUG - 2018-07-25 00:12:18 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:12:18 --> Utf8 Class Initialized
INFO - 2018-07-25 00:12:18 --> Utf8 Class Initialized
INFO - 2018-07-25 00:12:18 --> Utf8 Class Initialized
INFO - 2018-07-25 00:12:18 --> URI Class Initialized
INFO - 2018-07-25 00:12:18 --> URI Class Initialized
INFO - 2018-07-25 00:12:18 --> URI Class Initialized
INFO - 2018-07-25 00:12:18 --> Router Class Initialized
INFO - 2018-07-25 00:12:18 --> Router Class Initialized
INFO - 2018-07-25 00:12:19 --> Router Class Initialized
INFO - 2018-07-25 00:12:19 --> Output Class Initialized
INFO - 2018-07-25 00:12:19 --> Output Class Initialized
INFO - 2018-07-25 00:12:19 --> Output Class Initialized
INFO - 2018-07-25 00:12:19 --> Security Class Initialized
INFO - 2018-07-25 00:12:19 --> Security Class Initialized
INFO - 2018-07-25 00:12:19 --> Security Class Initialized
DEBUG - 2018-07-25 00:12:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-07-25 00:12:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-07-25 00:12:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:12:19 --> Input Class Initialized
INFO - 2018-07-25 00:12:19 --> Input Class Initialized
INFO - 2018-07-25 00:12:19 --> Input Class Initialized
INFO - 2018-07-25 00:12:19 --> Language Class Initialized
INFO - 2018-07-25 00:12:19 --> Language Class Initialized
INFO - 2018-07-25 00:12:19 --> Language Class Initialized
ERROR - 2018-07-25 00:12:19 --> 404 Page Not Found: /index
ERROR - 2018-07-25 00:12:19 --> 404 Page Not Found: /index
ERROR - 2018-07-25 00:12:19 --> 404 Page Not Found: /index
INFO - 2018-07-25 00:12:19 --> Config Class Initialized
INFO - 2018-07-25 00:12:19 --> Hooks Class Initialized
DEBUG - 2018-07-25 00:12:19 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:12:19 --> Utf8 Class Initialized
INFO - 2018-07-25 00:12:19 --> URI Class Initialized
INFO - 2018-07-25 00:12:19 --> Router Class Initialized
INFO - 2018-07-25 00:12:19 --> Output Class Initialized
INFO - 2018-07-25 00:12:19 --> Security Class Initialized
DEBUG - 2018-07-25 00:12:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:12:19 --> Input Class Initialized
INFO - 2018-07-25 00:12:19 --> Language Class Initialized
ERROR - 2018-07-25 00:12:19 --> 404 Page Not Found: /index
INFO - 2018-07-25 00:12:19 --> Config Class Initialized
INFO - 2018-07-25 00:12:19 --> Hooks Class Initialized
DEBUG - 2018-07-25 00:12:19 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:12:19 --> Utf8 Class Initialized
INFO - 2018-07-25 00:12:19 --> URI Class Initialized
INFO - 2018-07-25 00:12:19 --> Router Class Initialized
INFO - 2018-07-25 00:12:19 --> Output Class Initialized
INFO - 2018-07-25 00:12:19 --> Security Class Initialized
DEBUG - 2018-07-25 00:12:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:12:19 --> Input Class Initialized
INFO - 2018-07-25 00:12:19 --> Language Class Initialized
ERROR - 2018-07-25 00:12:19 --> 404 Page Not Found: /index
INFO - 2018-07-25 00:12:19 --> Config Class Initialized
INFO - 2018-07-25 00:12:19 --> Hooks Class Initialized
DEBUG - 2018-07-25 00:12:19 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:12:19 --> Utf8 Class Initialized
INFO - 2018-07-25 00:12:19 --> URI Class Initialized
INFO - 2018-07-25 00:12:19 --> Router Class Initialized
INFO - 2018-07-25 00:12:19 --> Output Class Initialized
INFO - 2018-07-25 00:12:19 --> Security Class Initialized
DEBUG - 2018-07-25 00:12:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:12:19 --> Input Class Initialized
INFO - 2018-07-25 00:12:19 --> Language Class Initialized
ERROR - 2018-07-25 00:12:19 --> 404 Page Not Found: /index
INFO - 2018-07-25 00:12:19 --> Config Class Initialized
INFO - 2018-07-25 00:12:19 --> Hooks Class Initialized
DEBUG - 2018-07-25 00:12:19 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:12:19 --> Utf8 Class Initialized
INFO - 2018-07-25 00:12:19 --> URI Class Initialized
INFO - 2018-07-25 00:12:19 --> Router Class Initialized
INFO - 2018-07-25 00:12:19 --> Output Class Initialized
INFO - 2018-07-25 00:12:20 --> Security Class Initialized
DEBUG - 2018-07-25 00:12:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:12:20 --> Input Class Initialized
INFO - 2018-07-25 00:12:20 --> Language Class Initialized
ERROR - 2018-07-25 00:12:20 --> 404 Page Not Found: /index
INFO - 2018-07-25 00:12:20 --> Config Class Initialized
INFO - 2018-07-25 00:12:20 --> Hooks Class Initialized
DEBUG - 2018-07-25 00:12:20 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:12:20 --> Utf8 Class Initialized
INFO - 2018-07-25 00:12:20 --> URI Class Initialized
INFO - 2018-07-25 00:12:20 --> Router Class Initialized
INFO - 2018-07-25 00:12:20 --> Output Class Initialized
INFO - 2018-07-25 00:12:20 --> Security Class Initialized
DEBUG - 2018-07-25 00:12:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:12:20 --> Input Class Initialized
INFO - 2018-07-25 00:12:20 --> Language Class Initialized
ERROR - 2018-07-25 00:12:20 --> 404 Page Not Found: /index
INFO - 2018-07-25 00:12:20 --> Config Class Initialized
INFO - 2018-07-25 00:12:20 --> Hooks Class Initialized
DEBUG - 2018-07-25 00:12:20 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:12:20 --> Utf8 Class Initialized
INFO - 2018-07-25 00:12:20 --> URI Class Initialized
INFO - 2018-07-25 00:12:20 --> Router Class Initialized
INFO - 2018-07-25 00:12:20 --> Output Class Initialized
INFO - 2018-07-25 00:12:20 --> Security Class Initialized
DEBUG - 2018-07-25 00:12:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:12:20 --> Input Class Initialized
INFO - 2018-07-25 00:12:20 --> Language Class Initialized
ERROR - 2018-07-25 00:12:20 --> 404 Page Not Found: /index
INFO - 2018-07-25 00:12:46 --> Config Class Initialized
INFO - 2018-07-25 00:12:46 --> Hooks Class Initialized
DEBUG - 2018-07-25 00:12:46 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:12:46 --> Utf8 Class Initialized
INFO - 2018-07-25 00:12:46 --> URI Class Initialized
DEBUG - 2018-07-25 00:12:46 --> No URI present. Default controller set.
INFO - 2018-07-25 00:12:46 --> Router Class Initialized
INFO - 2018-07-25 00:12:46 --> Output Class Initialized
INFO - 2018-07-25 00:12:46 --> Security Class Initialized
DEBUG - 2018-07-25 00:12:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:12:46 --> Input Class Initialized
INFO - 2018-07-25 00:12:46 --> Language Class Initialized
INFO - 2018-07-25 00:12:46 --> Language Class Initialized
INFO - 2018-07-25 00:12:46 --> Config Class Initialized
INFO - 2018-07-25 00:12:46 --> Loader Class Initialized
DEBUG - 2018-07-25 00:12:46 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-25 00:12:46 --> Helper loaded: url_helper
INFO - 2018-07-25 00:12:46 --> Helper loaded: form_helper
INFO - 2018-07-25 00:12:46 --> Helper loaded: date_helper
INFO - 2018-07-25 00:12:46 --> Helper loaded: util_helper
INFO - 2018-07-25 00:12:46 --> Helper loaded: text_helper
INFO - 2018-07-25 00:12:46 --> Helper loaded: string_helper
INFO - 2018-07-25 00:12:46 --> Database Driver Class Initialized
DEBUG - 2018-07-25 00:12:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 00:12:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 00:12:46 --> Email Class Initialized
INFO - 2018-07-25 00:12:46 --> Controller Class Initialized
DEBUG - 2018-07-25 00:12:47 --> Home MX_Controller Initialized
DEBUG - 2018-07-25 00:12:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-25 00:12:47 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-25 00:12:47 --> Login MX_Controller Initialized
INFO - 2018-07-25 00:12:47 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-25 00:12:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-25 00:12:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-25 00:12:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-07-25 00:12:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-07-25 00:12:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-07-25 00:12:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-07-25 00:12:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-07-25 00:12:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-07-25 00:12:47 --> Final output sent to browser
DEBUG - 2018-07-25 00:12:47 --> Total execution time: 0.4836
INFO - 2018-07-25 00:12:47 --> Config Class Initialized
INFO - 2018-07-25 00:12:47 --> Config Class Initialized
INFO - 2018-07-25 00:12:47 --> Config Class Initialized
INFO - 2018-07-25 00:12:47 --> Hooks Class Initialized
INFO - 2018-07-25 00:12:47 --> Hooks Class Initialized
INFO - 2018-07-25 00:12:47 --> Hooks Class Initialized
DEBUG - 2018-07-25 00:12:47 --> UTF-8 Support Enabled
DEBUG - 2018-07-25 00:12:47 --> UTF-8 Support Enabled
DEBUG - 2018-07-25 00:12:47 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:12:47 --> Utf8 Class Initialized
INFO - 2018-07-25 00:12:47 --> Utf8 Class Initialized
INFO - 2018-07-25 00:12:47 --> Utf8 Class Initialized
INFO - 2018-07-25 00:12:47 --> URI Class Initialized
INFO - 2018-07-25 00:12:47 --> URI Class Initialized
INFO - 2018-07-25 00:12:47 --> URI Class Initialized
INFO - 2018-07-25 00:12:47 --> Router Class Initialized
INFO - 2018-07-25 00:12:47 --> Output Class Initialized
INFO - 2018-07-25 00:12:47 --> Router Class Initialized
INFO - 2018-07-25 00:12:47 --> Output Class Initialized
INFO - 2018-07-25 00:12:47 --> Security Class Initialized
INFO - 2018-07-25 00:12:47 --> Router Class Initialized
INFO - 2018-07-25 00:12:47 --> Output Class Initialized
INFO - 2018-07-25 00:12:47 --> Security Class Initialized
DEBUG - 2018-07-25 00:12:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:12:47 --> Security Class Initialized
DEBUG - 2018-07-25 00:12:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:12:47 --> Input Class Initialized
INFO - 2018-07-25 00:12:47 --> Input Class Initialized
DEBUG - 2018-07-25 00:12:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:12:47 --> Language Class Initialized
INFO - 2018-07-25 00:12:47 --> Input Class Initialized
INFO - 2018-07-25 00:12:47 --> Language Class Initialized
INFO - 2018-07-25 00:12:47 --> Config Class Initialized
INFO - 2018-07-25 00:12:47 --> Hooks Class Initialized
ERROR - 2018-07-25 00:12:47 --> 404 Page Not Found: /index
ERROR - 2018-07-25 00:12:47 --> 404 Page Not Found: /index
INFO - 2018-07-25 00:12:47 --> Language Class Initialized
DEBUG - 2018-07-25 00:12:47 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:12:47 --> Utf8 Class Initialized
INFO - 2018-07-25 00:12:47 --> URI Class Initialized
INFO - 2018-07-25 00:12:47 --> Router Class Initialized
INFO - 2018-07-25 00:12:47 --> Output Class Initialized
INFO - 2018-07-25 00:12:47 --> Security Class Initialized
DEBUG - 2018-07-25 00:12:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:12:47 --> Input Class Initialized
INFO - 2018-07-25 00:12:47 --> Language Class Initialized
ERROR - 2018-07-25 00:12:47 --> 404 Page Not Found: /index
ERROR - 2018-07-25 00:12:47 --> 404 Page Not Found: /index
INFO - 2018-07-25 00:12:48 --> Config Class Initialized
INFO - 2018-07-25 00:12:48 --> Hooks Class Initialized
DEBUG - 2018-07-25 00:12:48 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:12:48 --> Utf8 Class Initialized
INFO - 2018-07-25 00:12:48 --> URI Class Initialized
INFO - 2018-07-25 00:12:48 --> Router Class Initialized
INFO - 2018-07-25 00:12:48 --> Output Class Initialized
INFO - 2018-07-25 00:12:48 --> Security Class Initialized
DEBUG - 2018-07-25 00:12:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:12:48 --> Input Class Initialized
INFO - 2018-07-25 00:12:48 --> Language Class Initialized
ERROR - 2018-07-25 00:12:48 --> 404 Page Not Found: /index
INFO - 2018-07-25 00:12:48 --> Config Class Initialized
INFO - 2018-07-25 00:12:48 --> Hooks Class Initialized
DEBUG - 2018-07-25 00:12:48 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:12:48 --> Utf8 Class Initialized
INFO - 2018-07-25 00:12:48 --> URI Class Initialized
INFO - 2018-07-25 00:12:48 --> Router Class Initialized
INFO - 2018-07-25 00:12:48 --> Output Class Initialized
INFO - 2018-07-25 00:12:48 --> Security Class Initialized
DEBUG - 2018-07-25 00:12:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:12:48 --> Input Class Initialized
INFO - 2018-07-25 00:12:48 --> Language Class Initialized
ERROR - 2018-07-25 00:12:48 --> 404 Page Not Found: /index
INFO - 2018-07-25 00:12:48 --> Config Class Initialized
INFO - 2018-07-25 00:12:48 --> Hooks Class Initialized
DEBUG - 2018-07-25 00:12:48 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:12:48 --> Utf8 Class Initialized
INFO - 2018-07-25 00:12:48 --> URI Class Initialized
INFO - 2018-07-25 00:12:48 --> Router Class Initialized
INFO - 2018-07-25 00:12:48 --> Output Class Initialized
INFO - 2018-07-25 00:12:48 --> Security Class Initialized
DEBUG - 2018-07-25 00:12:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:12:48 --> Input Class Initialized
INFO - 2018-07-25 00:12:48 --> Language Class Initialized
ERROR - 2018-07-25 00:12:48 --> 404 Page Not Found: /index
INFO - 2018-07-25 00:12:48 --> Config Class Initialized
INFO - 2018-07-25 00:12:48 --> Hooks Class Initialized
DEBUG - 2018-07-25 00:12:48 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:12:48 --> Utf8 Class Initialized
INFO - 2018-07-25 00:12:48 --> URI Class Initialized
INFO - 2018-07-25 00:12:48 --> Router Class Initialized
INFO - 2018-07-25 00:12:48 --> Output Class Initialized
INFO - 2018-07-25 00:12:48 --> Security Class Initialized
DEBUG - 2018-07-25 00:12:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:12:48 --> Input Class Initialized
INFO - 2018-07-25 00:12:48 --> Language Class Initialized
ERROR - 2018-07-25 00:12:48 --> 404 Page Not Found: /index
INFO - 2018-07-25 00:12:48 --> Config Class Initialized
INFO - 2018-07-25 00:12:48 --> Hooks Class Initialized
DEBUG - 2018-07-25 00:12:48 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:12:48 --> Utf8 Class Initialized
INFO - 2018-07-25 00:12:48 --> URI Class Initialized
INFO - 2018-07-25 00:12:48 --> Router Class Initialized
INFO - 2018-07-25 00:12:48 --> Output Class Initialized
INFO - 2018-07-25 00:12:48 --> Security Class Initialized
DEBUG - 2018-07-25 00:12:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:12:48 --> Input Class Initialized
INFO - 2018-07-25 00:12:48 --> Language Class Initialized
ERROR - 2018-07-25 00:12:48 --> 404 Page Not Found: /index
INFO - 2018-07-25 00:15:45 --> Config Class Initialized
INFO - 2018-07-25 00:15:45 --> Hooks Class Initialized
DEBUG - 2018-07-25 00:15:45 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:15:45 --> Utf8 Class Initialized
INFO - 2018-07-25 00:15:45 --> URI Class Initialized
DEBUG - 2018-07-25 00:15:45 --> No URI present. Default controller set.
INFO - 2018-07-25 00:15:45 --> Router Class Initialized
INFO - 2018-07-25 00:15:45 --> Output Class Initialized
INFO - 2018-07-25 00:15:45 --> Security Class Initialized
DEBUG - 2018-07-25 00:15:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:15:45 --> Input Class Initialized
INFO - 2018-07-25 00:15:45 --> Language Class Initialized
INFO - 2018-07-25 00:15:45 --> Language Class Initialized
INFO - 2018-07-25 00:15:45 --> Config Class Initialized
INFO - 2018-07-25 00:15:45 --> Loader Class Initialized
DEBUG - 2018-07-25 00:15:45 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-25 00:15:45 --> Helper loaded: url_helper
INFO - 2018-07-25 00:15:45 --> Helper loaded: form_helper
INFO - 2018-07-25 00:15:45 --> Helper loaded: date_helper
INFO - 2018-07-25 00:15:46 --> Helper loaded: util_helper
INFO - 2018-07-25 00:15:46 --> Helper loaded: text_helper
INFO - 2018-07-25 00:15:46 --> Helper loaded: string_helper
INFO - 2018-07-25 00:15:46 --> Database Driver Class Initialized
DEBUG - 2018-07-25 00:15:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 00:15:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 00:15:46 --> Email Class Initialized
INFO - 2018-07-25 00:15:46 --> Controller Class Initialized
DEBUG - 2018-07-25 00:15:46 --> Home MX_Controller Initialized
DEBUG - 2018-07-25 00:15:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-25 00:15:46 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-25 00:15:46 --> Login MX_Controller Initialized
INFO - 2018-07-25 00:15:46 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-25 00:15:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-25 00:15:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-25 00:15:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-07-25 00:15:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-07-25 00:15:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-07-25 00:15:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-07-25 00:15:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-07-25 00:15:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-07-25 00:15:46 --> Final output sent to browser
DEBUG - 2018-07-25 00:15:46 --> Total execution time: 0.4131
INFO - 2018-07-25 00:15:46 --> Config Class Initialized
INFO - 2018-07-25 00:15:46 --> Config Class Initialized
INFO - 2018-07-25 00:15:46 --> Config Class Initialized
INFO - 2018-07-25 00:15:46 --> Hooks Class Initialized
INFO - 2018-07-25 00:15:46 --> Hooks Class Initialized
DEBUG - 2018-07-25 00:15:46 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:15:46 --> Hooks Class Initialized
INFO - 2018-07-25 00:15:46 --> Utf8 Class Initialized
DEBUG - 2018-07-25 00:15:46 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:15:46 --> Utf8 Class Initialized
INFO - 2018-07-25 00:15:46 --> URI Class Initialized
DEBUG - 2018-07-25 00:15:46 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:15:46 --> Utf8 Class Initialized
INFO - 2018-07-25 00:15:46 --> URI Class Initialized
INFO - 2018-07-25 00:15:46 --> Router Class Initialized
INFO - 2018-07-25 00:15:46 --> Output Class Initialized
INFO - 2018-07-25 00:15:46 --> Router Class Initialized
INFO - 2018-07-25 00:15:46 --> URI Class Initialized
INFO - 2018-07-25 00:15:46 --> Security Class Initialized
INFO - 2018-07-25 00:15:46 --> Output Class Initialized
INFO - 2018-07-25 00:15:46 --> Router Class Initialized
INFO - 2018-07-25 00:15:46 --> Security Class Initialized
INFO - 2018-07-25 00:15:46 --> Output Class Initialized
DEBUG - 2018-07-25 00:15:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:15:46 --> Security Class Initialized
INFO - 2018-07-25 00:15:46 --> Input Class Initialized
DEBUG - 2018-07-25 00:15:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:15:46 --> Language Class Initialized
INFO - 2018-07-25 00:15:46 --> Input Class Initialized
DEBUG - 2018-07-25 00:15:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:15:46 --> Input Class Initialized
INFO - 2018-07-25 00:15:46 --> Language Class Initialized
ERROR - 2018-07-25 00:15:46 --> 404 Page Not Found: /index
ERROR - 2018-07-25 00:15:46 --> 404 Page Not Found: /index
INFO - 2018-07-25 00:15:46 --> Language Class Initialized
ERROR - 2018-07-25 00:15:46 --> 404 Page Not Found: /index
INFO - 2018-07-25 00:15:46 --> Config Class Initialized
INFO - 2018-07-25 00:15:46 --> Hooks Class Initialized
DEBUG - 2018-07-25 00:15:46 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:15:46 --> Utf8 Class Initialized
INFO - 2018-07-25 00:15:46 --> URI Class Initialized
INFO - 2018-07-25 00:15:46 --> Router Class Initialized
INFO - 2018-07-25 00:15:46 --> Output Class Initialized
INFO - 2018-07-25 00:15:46 --> Security Class Initialized
DEBUG - 2018-07-25 00:15:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:15:46 --> Input Class Initialized
INFO - 2018-07-25 00:15:46 --> Language Class Initialized
ERROR - 2018-07-25 00:15:46 --> 404 Page Not Found: /index
INFO - 2018-07-25 00:15:47 --> Config Class Initialized
INFO - 2018-07-25 00:15:47 --> Hooks Class Initialized
DEBUG - 2018-07-25 00:15:47 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:15:47 --> Utf8 Class Initialized
INFO - 2018-07-25 00:15:47 --> URI Class Initialized
INFO - 2018-07-25 00:15:47 --> Router Class Initialized
INFO - 2018-07-25 00:15:47 --> Output Class Initialized
INFO - 2018-07-25 00:15:47 --> Security Class Initialized
DEBUG - 2018-07-25 00:15:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:15:47 --> Input Class Initialized
INFO - 2018-07-25 00:15:47 --> Language Class Initialized
ERROR - 2018-07-25 00:15:47 --> 404 Page Not Found: /index
INFO - 2018-07-25 00:15:47 --> Config Class Initialized
INFO - 2018-07-25 00:15:47 --> Hooks Class Initialized
DEBUG - 2018-07-25 00:15:47 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:15:47 --> Utf8 Class Initialized
INFO - 2018-07-25 00:15:47 --> URI Class Initialized
INFO - 2018-07-25 00:15:47 --> Router Class Initialized
INFO - 2018-07-25 00:15:47 --> Output Class Initialized
INFO - 2018-07-25 00:15:47 --> Security Class Initialized
DEBUG - 2018-07-25 00:15:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:15:47 --> Input Class Initialized
INFO - 2018-07-25 00:15:47 --> Language Class Initialized
ERROR - 2018-07-25 00:15:47 --> 404 Page Not Found: /index
INFO - 2018-07-25 00:15:47 --> Config Class Initialized
INFO - 2018-07-25 00:15:47 --> Hooks Class Initialized
DEBUG - 2018-07-25 00:15:47 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:15:47 --> Utf8 Class Initialized
INFO - 2018-07-25 00:15:47 --> URI Class Initialized
INFO - 2018-07-25 00:15:47 --> Router Class Initialized
INFO - 2018-07-25 00:15:47 --> Output Class Initialized
INFO - 2018-07-25 00:15:47 --> Security Class Initialized
DEBUG - 2018-07-25 00:15:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:15:47 --> Input Class Initialized
INFO - 2018-07-25 00:15:47 --> Language Class Initialized
ERROR - 2018-07-25 00:15:47 --> 404 Page Not Found: /index
INFO - 2018-07-25 00:15:47 --> Config Class Initialized
INFO - 2018-07-25 00:15:47 --> Hooks Class Initialized
DEBUG - 2018-07-25 00:15:47 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:15:47 --> Utf8 Class Initialized
INFO - 2018-07-25 00:15:47 --> URI Class Initialized
INFO - 2018-07-25 00:15:47 --> Router Class Initialized
INFO - 2018-07-25 00:15:47 --> Output Class Initialized
INFO - 2018-07-25 00:15:47 --> Security Class Initialized
DEBUG - 2018-07-25 00:15:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:15:47 --> Input Class Initialized
INFO - 2018-07-25 00:15:47 --> Language Class Initialized
ERROR - 2018-07-25 00:15:47 --> 404 Page Not Found: /index
INFO - 2018-07-25 00:15:47 --> Config Class Initialized
INFO - 2018-07-25 00:15:47 --> Hooks Class Initialized
DEBUG - 2018-07-25 00:15:47 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:15:47 --> Utf8 Class Initialized
INFO - 2018-07-25 00:15:47 --> URI Class Initialized
INFO - 2018-07-25 00:15:47 --> Router Class Initialized
INFO - 2018-07-25 00:15:47 --> Output Class Initialized
INFO - 2018-07-25 00:15:47 --> Security Class Initialized
DEBUG - 2018-07-25 00:15:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:15:47 --> Input Class Initialized
INFO - 2018-07-25 00:15:47 --> Language Class Initialized
ERROR - 2018-07-25 00:15:47 --> 404 Page Not Found: /index
INFO - 2018-07-25 00:18:16 --> Config Class Initialized
INFO - 2018-07-25 00:18:16 --> Hooks Class Initialized
DEBUG - 2018-07-25 00:18:16 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:18:16 --> Utf8 Class Initialized
INFO - 2018-07-25 00:18:16 --> URI Class Initialized
DEBUG - 2018-07-25 00:18:16 --> No URI present. Default controller set.
INFO - 2018-07-25 00:18:16 --> Router Class Initialized
INFO - 2018-07-25 00:18:17 --> Output Class Initialized
INFO - 2018-07-25 00:18:17 --> Security Class Initialized
DEBUG - 2018-07-25 00:18:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:18:17 --> Input Class Initialized
INFO - 2018-07-25 00:18:17 --> Language Class Initialized
INFO - 2018-07-25 00:18:17 --> Language Class Initialized
INFO - 2018-07-25 00:18:17 --> Config Class Initialized
INFO - 2018-07-25 00:18:17 --> Loader Class Initialized
DEBUG - 2018-07-25 00:18:17 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-25 00:18:17 --> Helper loaded: url_helper
INFO - 2018-07-25 00:18:17 --> Helper loaded: form_helper
INFO - 2018-07-25 00:18:17 --> Helper loaded: date_helper
INFO - 2018-07-25 00:18:17 --> Helper loaded: util_helper
INFO - 2018-07-25 00:18:17 --> Helper loaded: text_helper
INFO - 2018-07-25 00:18:17 --> Helper loaded: string_helper
INFO - 2018-07-25 00:18:17 --> Database Driver Class Initialized
DEBUG - 2018-07-25 00:18:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 00:18:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 00:18:17 --> Email Class Initialized
INFO - 2018-07-25 00:18:17 --> Controller Class Initialized
DEBUG - 2018-07-25 00:18:17 --> Home MX_Controller Initialized
DEBUG - 2018-07-25 00:18:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-25 00:18:17 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-25 00:18:17 --> Login MX_Controller Initialized
INFO - 2018-07-25 00:18:17 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-25 00:18:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-25 00:18:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-25 00:18:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-07-25 00:18:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-07-25 00:18:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-07-25 00:18:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-07-25 00:18:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-07-25 00:18:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-07-25 00:18:17 --> Final output sent to browser
DEBUG - 2018-07-25 00:18:17 --> Total execution time: 0.4347
INFO - 2018-07-25 00:18:17 --> Config Class Initialized
INFO - 2018-07-25 00:18:17 --> Hooks Class Initialized
DEBUG - 2018-07-25 00:18:17 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:18:17 --> Utf8 Class Initialized
INFO - 2018-07-25 00:18:17 --> URI Class Initialized
INFO - 2018-07-25 00:18:17 --> Router Class Initialized
INFO - 2018-07-25 00:18:17 --> Output Class Initialized
INFO - 2018-07-25 00:18:17 --> Security Class Initialized
DEBUG - 2018-07-25 00:18:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:18:17 --> Input Class Initialized
INFO - 2018-07-25 00:18:17 --> Language Class Initialized
INFO - 2018-07-25 00:18:18 --> Config Class Initialized
INFO - 2018-07-25 00:18:18 --> Hooks Class Initialized
ERROR - 2018-07-25 00:18:18 --> 404 Page Not Found: /index
DEBUG - 2018-07-25 00:18:18 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:18:18 --> Config Class Initialized
INFO - 2018-07-25 00:18:18 --> Hooks Class Initialized
INFO - 2018-07-25 00:18:18 --> Utf8 Class Initialized
DEBUG - 2018-07-25 00:18:18 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:18:18 --> URI Class Initialized
INFO - 2018-07-25 00:18:18 --> Utf8 Class Initialized
INFO - 2018-07-25 00:18:18 --> URI Class Initialized
INFO - 2018-07-25 00:18:18 --> Router Class Initialized
INFO - 2018-07-25 00:18:18 --> Output Class Initialized
INFO - 2018-07-25 00:18:18 --> Security Class Initialized
DEBUG - 2018-07-25 00:18:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:18:18 --> Input Class Initialized
INFO - 2018-07-25 00:18:18 --> Router Class Initialized
INFO - 2018-07-25 00:18:18 --> Output Class Initialized
INFO - 2018-07-25 00:18:18 --> Language Class Initialized
INFO - 2018-07-25 00:18:18 --> Security Class Initialized
DEBUG - 2018-07-25 00:18:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:18:18 --> Input Class Initialized
INFO - 2018-07-25 00:18:18 --> Language Class Initialized
ERROR - 2018-07-25 00:18:18 --> 404 Page Not Found: /index
ERROR - 2018-07-25 00:18:18 --> 404 Page Not Found: /index
INFO - 2018-07-25 00:18:18 --> Config Class Initialized
INFO - 2018-07-25 00:18:18 --> Hooks Class Initialized
INFO - 2018-07-25 00:18:18 --> Config Class Initialized
INFO - 2018-07-25 00:18:18 --> Hooks Class Initialized
DEBUG - 2018-07-25 00:18:18 --> UTF-8 Support Enabled
DEBUG - 2018-07-25 00:18:18 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:18:18 --> Utf8 Class Initialized
INFO - 2018-07-25 00:18:18 --> URI Class Initialized
INFO - 2018-07-25 00:18:18 --> Router Class Initialized
INFO - 2018-07-25 00:18:18 --> Output Class Initialized
INFO - 2018-07-25 00:18:18 --> Security Class Initialized
DEBUG - 2018-07-25 00:18:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:18:18 --> Input Class Initialized
INFO - 2018-07-25 00:18:18 --> Language Class Initialized
INFO - 2018-07-25 00:18:18 --> Utf8 Class Initialized
ERROR - 2018-07-25 00:18:18 --> 404 Page Not Found: /index
INFO - 2018-07-25 00:18:18 --> URI Class Initialized
INFO - 2018-07-25 00:18:18 --> Router Class Initialized
INFO - 2018-07-25 00:18:18 --> Output Class Initialized
INFO - 2018-07-25 00:18:18 --> Security Class Initialized
DEBUG - 2018-07-25 00:18:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:18:18 --> Input Class Initialized
INFO - 2018-07-25 00:18:18 --> Config Class Initialized
INFO - 2018-07-25 00:18:18 --> Hooks Class Initialized
INFO - 2018-07-25 00:18:18 --> Language Class Initialized
DEBUG - 2018-07-25 00:18:18 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:18:18 --> Utf8 Class Initialized
INFO - 2018-07-25 00:18:18 --> URI Class Initialized
INFO - 2018-07-25 00:18:18 --> Router Class Initialized
INFO - 2018-07-25 00:18:18 --> Output Class Initialized
INFO - 2018-07-25 00:18:18 --> Security Class Initialized
DEBUG - 2018-07-25 00:18:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:18:18 --> Input Class Initialized
INFO - 2018-07-25 00:18:18 --> Language Class Initialized
ERROR - 2018-07-25 00:18:18 --> 404 Page Not Found: /index
ERROR - 2018-07-25 00:18:18 --> 404 Page Not Found: /index
INFO - 2018-07-25 00:22:59 --> Config Class Initialized
INFO - 2018-07-25 00:22:59 --> Hooks Class Initialized
DEBUG - 2018-07-25 00:22:59 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:22:59 --> Utf8 Class Initialized
INFO - 2018-07-25 00:22:59 --> URI Class Initialized
DEBUG - 2018-07-25 00:22:59 --> No URI present. Default controller set.
INFO - 2018-07-25 00:22:59 --> Router Class Initialized
INFO - 2018-07-25 00:22:59 --> Output Class Initialized
INFO - 2018-07-25 00:22:59 --> Security Class Initialized
DEBUG - 2018-07-25 00:22:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:22:59 --> Input Class Initialized
INFO - 2018-07-25 00:22:59 --> Language Class Initialized
INFO - 2018-07-25 00:22:59 --> Language Class Initialized
INFO - 2018-07-25 00:22:59 --> Config Class Initialized
INFO - 2018-07-25 00:22:59 --> Loader Class Initialized
DEBUG - 2018-07-25 00:22:59 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-25 00:22:59 --> Helper loaded: url_helper
INFO - 2018-07-25 00:22:59 --> Helper loaded: form_helper
INFO - 2018-07-25 00:22:59 --> Helper loaded: date_helper
INFO - 2018-07-25 00:22:59 --> Helper loaded: util_helper
INFO - 2018-07-25 00:22:59 --> Helper loaded: text_helper
INFO - 2018-07-25 00:22:59 --> Helper loaded: string_helper
INFO - 2018-07-25 00:22:59 --> Database Driver Class Initialized
DEBUG - 2018-07-25 00:22:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 00:22:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 00:22:59 --> Email Class Initialized
INFO - 2018-07-25 00:22:59 --> Controller Class Initialized
DEBUG - 2018-07-25 00:22:59 --> Home MX_Controller Initialized
DEBUG - 2018-07-25 00:22:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-25 00:23:00 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-25 00:23:00 --> Login MX_Controller Initialized
INFO - 2018-07-25 00:23:00 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-25 00:23:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-25 00:23:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-25 00:23:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-07-25 00:23:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-07-25 00:23:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-07-25 00:23:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-07-25 00:23:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-07-25 00:23:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-07-25 00:23:00 --> Final output sent to browser
DEBUG - 2018-07-25 00:23:00 --> Total execution time: 0.4091
INFO - 2018-07-25 00:23:00 --> Config Class Initialized
INFO - 2018-07-25 00:23:00 --> Config Class Initialized
INFO - 2018-07-25 00:23:00 --> Config Class Initialized
INFO - 2018-07-25 00:23:00 --> Hooks Class Initialized
INFO - 2018-07-25 00:23:00 --> Hooks Class Initialized
INFO - 2018-07-25 00:23:00 --> Hooks Class Initialized
DEBUG - 2018-07-25 00:23:00 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:23:00 --> Utf8 Class Initialized
DEBUG - 2018-07-25 00:23:00 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:23:00 --> URI Class Initialized
DEBUG - 2018-07-25 00:23:00 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:23:00 --> Utf8 Class Initialized
INFO - 2018-07-25 00:23:00 --> Utf8 Class Initialized
INFO - 2018-07-25 00:23:00 --> Router Class Initialized
INFO - 2018-07-25 00:23:00 --> URI Class Initialized
INFO - 2018-07-25 00:23:00 --> URI Class Initialized
INFO - 2018-07-25 00:23:00 --> Output Class Initialized
INFO - 2018-07-25 00:23:00 --> Router Class Initialized
INFO - 2018-07-25 00:23:00 --> Router Class Initialized
INFO - 2018-07-25 00:23:00 --> Security Class Initialized
DEBUG - 2018-07-25 00:23:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:23:00 --> Output Class Initialized
INFO - 2018-07-25 00:23:00 --> Output Class Initialized
INFO - 2018-07-25 00:23:00 --> Input Class Initialized
INFO - 2018-07-25 00:23:00 --> Security Class Initialized
INFO - 2018-07-25 00:23:00 --> Security Class Initialized
DEBUG - 2018-07-25 00:23:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-07-25 00:23:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:23:00 --> Language Class Initialized
INFO - 2018-07-25 00:23:00 --> Input Class Initialized
INFO - 2018-07-25 00:23:00 --> Input Class Initialized
ERROR - 2018-07-25 00:23:00 --> 404 Page Not Found: /index
INFO - 2018-07-25 00:23:00 --> Language Class Initialized
INFO - 2018-07-25 00:23:00 --> Language Class Initialized
ERROR - 2018-07-25 00:23:00 --> 404 Page Not Found: /index
ERROR - 2018-07-25 00:23:00 --> 404 Page Not Found: /index
INFO - 2018-07-25 00:23:01 --> Config Class Initialized
INFO - 2018-07-25 00:23:01 --> Hooks Class Initialized
DEBUG - 2018-07-25 00:23:01 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:23:01 --> Utf8 Class Initialized
INFO - 2018-07-25 00:23:01 --> URI Class Initialized
INFO - 2018-07-25 00:23:01 --> Router Class Initialized
INFO - 2018-07-25 00:23:01 --> Output Class Initialized
INFO - 2018-07-25 00:23:01 --> Security Class Initialized
DEBUG - 2018-07-25 00:23:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:23:01 --> Input Class Initialized
INFO - 2018-07-25 00:23:01 --> Language Class Initialized
ERROR - 2018-07-25 00:23:01 --> 404 Page Not Found: /index
INFO - 2018-07-25 00:23:01 --> Config Class Initialized
INFO - 2018-07-25 00:23:01 --> Hooks Class Initialized
DEBUG - 2018-07-25 00:23:01 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:23:01 --> Utf8 Class Initialized
INFO - 2018-07-25 00:23:01 --> URI Class Initialized
INFO - 2018-07-25 00:23:01 --> Router Class Initialized
INFO - 2018-07-25 00:23:01 --> Output Class Initialized
INFO - 2018-07-25 00:23:01 --> Security Class Initialized
DEBUG - 2018-07-25 00:23:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:23:01 --> Input Class Initialized
INFO - 2018-07-25 00:23:01 --> Language Class Initialized
ERROR - 2018-07-25 00:23:01 --> 404 Page Not Found: /index
INFO - 2018-07-25 00:23:02 --> Config Class Initialized
INFO - 2018-07-25 00:23:02 --> Hooks Class Initialized
DEBUG - 2018-07-25 00:23:02 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:23:02 --> Utf8 Class Initialized
INFO - 2018-07-25 00:23:02 --> URI Class Initialized
INFO - 2018-07-25 00:23:02 --> Router Class Initialized
INFO - 2018-07-25 00:23:02 --> Output Class Initialized
INFO - 2018-07-25 00:23:02 --> Security Class Initialized
DEBUG - 2018-07-25 00:23:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:23:02 --> Input Class Initialized
INFO - 2018-07-25 00:23:02 --> Language Class Initialized
ERROR - 2018-07-25 00:23:02 --> 404 Page Not Found: /index
INFO - 2018-07-25 00:24:15 --> Config Class Initialized
INFO - 2018-07-25 00:24:15 --> Hooks Class Initialized
DEBUG - 2018-07-25 00:24:15 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:24:15 --> Utf8 Class Initialized
INFO - 2018-07-25 00:24:15 --> URI Class Initialized
DEBUG - 2018-07-25 00:24:15 --> No URI present. Default controller set.
INFO - 2018-07-25 00:24:15 --> Router Class Initialized
INFO - 2018-07-25 00:24:15 --> Output Class Initialized
INFO - 2018-07-25 00:24:15 --> Security Class Initialized
DEBUG - 2018-07-25 00:24:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:24:15 --> Input Class Initialized
INFO - 2018-07-25 00:24:15 --> Language Class Initialized
INFO - 2018-07-25 00:24:15 --> Language Class Initialized
INFO - 2018-07-25 00:24:15 --> Config Class Initialized
INFO - 2018-07-25 00:24:15 --> Loader Class Initialized
DEBUG - 2018-07-25 00:24:15 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-25 00:24:15 --> Helper loaded: url_helper
INFO - 2018-07-25 00:24:15 --> Helper loaded: form_helper
INFO - 2018-07-25 00:24:15 --> Helper loaded: date_helper
INFO - 2018-07-25 00:24:15 --> Helper loaded: util_helper
INFO - 2018-07-25 00:24:15 --> Helper loaded: text_helper
INFO - 2018-07-25 00:24:15 --> Helper loaded: string_helper
INFO - 2018-07-25 00:24:15 --> Database Driver Class Initialized
DEBUG - 2018-07-25 00:24:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 00:24:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 00:24:15 --> Email Class Initialized
INFO - 2018-07-25 00:24:15 --> Controller Class Initialized
DEBUG - 2018-07-25 00:24:15 --> Home MX_Controller Initialized
DEBUG - 2018-07-25 00:24:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-25 00:24:15 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-25 00:24:15 --> Login MX_Controller Initialized
INFO - 2018-07-25 00:24:15 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-25 00:24:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-25 00:24:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-25 00:24:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-07-25 00:24:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-07-25 00:24:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-07-25 00:24:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-07-25 00:24:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-07-25 00:24:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-07-25 00:24:15 --> Final output sent to browser
DEBUG - 2018-07-25 00:24:15 --> Total execution time: 0.5411
INFO - 2018-07-25 00:24:16 --> Config Class Initialized
INFO - 2018-07-25 00:24:16 --> Config Class Initialized
INFO - 2018-07-25 00:24:16 --> Config Class Initialized
INFO - 2018-07-25 00:24:16 --> Hooks Class Initialized
INFO - 2018-07-25 00:24:16 --> Hooks Class Initialized
INFO - 2018-07-25 00:24:16 --> Hooks Class Initialized
DEBUG - 2018-07-25 00:24:16 --> UTF-8 Support Enabled
DEBUG - 2018-07-25 00:24:16 --> UTF-8 Support Enabled
DEBUG - 2018-07-25 00:24:16 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:24:16 --> Utf8 Class Initialized
INFO - 2018-07-25 00:24:16 --> Utf8 Class Initialized
INFO - 2018-07-25 00:24:16 --> Utf8 Class Initialized
INFO - 2018-07-25 00:24:16 --> URI Class Initialized
INFO - 2018-07-25 00:24:16 --> URI Class Initialized
INFO - 2018-07-25 00:24:16 --> Router Class Initialized
INFO - 2018-07-25 00:24:16 --> URI Class Initialized
INFO - 2018-07-25 00:24:16 --> Router Class Initialized
INFO - 2018-07-25 00:24:16 --> Output Class Initialized
INFO - 2018-07-25 00:24:16 --> Security Class Initialized
INFO - 2018-07-25 00:24:16 --> Router Class Initialized
INFO - 2018-07-25 00:24:16 --> Output Class Initialized
DEBUG - 2018-07-25 00:24:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:24:16 --> Input Class Initialized
INFO - 2018-07-25 00:24:16 --> Security Class Initialized
INFO - 2018-07-25 00:24:16 --> Output Class Initialized
INFO - 2018-07-25 00:24:16 --> Config Class Initialized
INFO - 2018-07-25 00:24:16 --> Hooks Class Initialized
INFO - 2018-07-25 00:24:16 --> Language Class Initialized
INFO - 2018-07-25 00:24:16 --> Security Class Initialized
DEBUG - 2018-07-25 00:24:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-07-25 00:24:16 --> 404 Page Not Found: /index
DEBUG - 2018-07-25 00:24:16 --> UTF-8 Support Enabled
DEBUG - 2018-07-25 00:24:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:24:16 --> Input Class Initialized
INFO - 2018-07-25 00:24:16 --> Utf8 Class Initialized
INFO - 2018-07-25 00:24:16 --> URI Class Initialized
INFO - 2018-07-25 00:24:16 --> Router Class Initialized
INFO - 2018-07-25 00:24:16 --> Output Class Initialized
INFO - 2018-07-25 00:24:16 --> Security Class Initialized
DEBUG - 2018-07-25 00:24:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:24:16 --> Input Class Initialized
INFO - 2018-07-25 00:24:16 --> Language Class Initialized
ERROR - 2018-07-25 00:24:16 --> 404 Page Not Found: /index
INFO - 2018-07-25 00:24:16 --> Language Class Initialized
ERROR - 2018-07-25 00:24:16 --> 404 Page Not Found: /index
INFO - 2018-07-25 00:24:16 --> Input Class Initialized
INFO - 2018-07-25 00:24:16 --> Language Class Initialized
ERROR - 2018-07-25 00:24:16 --> 404 Page Not Found: /index
INFO - 2018-07-25 00:24:16 --> Config Class Initialized
INFO - 2018-07-25 00:24:16 --> Hooks Class Initialized
DEBUG - 2018-07-25 00:24:16 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:24:16 --> Utf8 Class Initialized
INFO - 2018-07-25 00:24:16 --> URI Class Initialized
INFO - 2018-07-25 00:24:16 --> Router Class Initialized
INFO - 2018-07-25 00:24:16 --> Output Class Initialized
INFO - 2018-07-25 00:24:16 --> Security Class Initialized
DEBUG - 2018-07-25 00:24:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:24:17 --> Input Class Initialized
INFO - 2018-07-25 00:24:17 --> Language Class Initialized
ERROR - 2018-07-25 00:24:17 --> 404 Page Not Found: /index
INFO - 2018-07-25 00:24:17 --> Config Class Initialized
INFO - 2018-07-25 00:24:17 --> Hooks Class Initialized
DEBUG - 2018-07-25 00:24:17 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:24:17 --> Utf8 Class Initialized
INFO - 2018-07-25 00:24:17 --> URI Class Initialized
INFO - 2018-07-25 00:24:17 --> Router Class Initialized
INFO - 2018-07-25 00:24:17 --> Output Class Initialized
INFO - 2018-07-25 00:24:17 --> Security Class Initialized
DEBUG - 2018-07-25 00:24:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:24:17 --> Input Class Initialized
INFO - 2018-07-25 00:24:17 --> Language Class Initialized
ERROR - 2018-07-25 00:24:17 --> 404 Page Not Found: /index
INFO - 2018-07-25 00:24:26 --> Config Class Initialized
INFO - 2018-07-25 00:24:26 --> Hooks Class Initialized
DEBUG - 2018-07-25 00:24:26 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:24:26 --> Utf8 Class Initialized
INFO - 2018-07-25 00:24:26 --> URI Class Initialized
DEBUG - 2018-07-25 00:24:26 --> No URI present. Default controller set.
INFO - 2018-07-25 00:24:26 --> Router Class Initialized
INFO - 2018-07-25 00:24:26 --> Output Class Initialized
INFO - 2018-07-25 00:24:26 --> Security Class Initialized
DEBUG - 2018-07-25 00:24:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:24:26 --> Input Class Initialized
INFO - 2018-07-25 00:24:26 --> Language Class Initialized
INFO - 2018-07-25 00:24:26 --> Language Class Initialized
INFO - 2018-07-25 00:24:26 --> Config Class Initialized
INFO - 2018-07-25 00:24:26 --> Loader Class Initialized
DEBUG - 2018-07-25 00:24:26 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-25 00:24:26 --> Helper loaded: url_helper
INFO - 2018-07-25 00:24:27 --> Helper loaded: form_helper
INFO - 2018-07-25 00:24:27 --> Helper loaded: date_helper
INFO - 2018-07-25 00:24:27 --> Helper loaded: util_helper
INFO - 2018-07-25 00:24:27 --> Helper loaded: text_helper
INFO - 2018-07-25 00:24:27 --> Helper loaded: string_helper
INFO - 2018-07-25 00:24:27 --> Database Driver Class Initialized
DEBUG - 2018-07-25 00:24:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 00:24:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 00:24:27 --> Email Class Initialized
INFO - 2018-07-25 00:24:27 --> Controller Class Initialized
DEBUG - 2018-07-25 00:24:27 --> Home MX_Controller Initialized
DEBUG - 2018-07-25 00:24:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-25 00:24:27 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-25 00:24:27 --> Login MX_Controller Initialized
INFO - 2018-07-25 00:24:27 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-25 00:24:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-25 00:24:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-25 00:24:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-07-25 00:24:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-07-25 00:24:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-07-25 00:24:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-07-25 00:24:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-07-25 00:24:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-07-25 00:24:27 --> Final output sent to browser
DEBUG - 2018-07-25 00:24:27 --> Total execution time: 0.5131
INFO - 2018-07-25 00:24:27 --> Config Class Initialized
INFO - 2018-07-25 00:24:27 --> Hooks Class Initialized
DEBUG - 2018-07-25 00:24:27 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:24:27 --> Utf8 Class Initialized
INFO - 2018-07-25 00:24:27 --> URI Class Initialized
INFO - 2018-07-25 00:24:27 --> Router Class Initialized
INFO - 2018-07-25 00:24:27 --> Output Class Initialized
INFO - 2018-07-25 00:24:27 --> Security Class Initialized
DEBUG - 2018-07-25 00:24:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:24:27 --> Input Class Initialized
INFO - 2018-07-25 00:24:27 --> Language Class Initialized
ERROR - 2018-07-25 00:24:27 --> 404 Page Not Found: /index
INFO - 2018-07-25 00:24:27 --> Config Class Initialized
INFO - 2018-07-25 00:24:27 --> Hooks Class Initialized
DEBUG - 2018-07-25 00:24:27 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:24:27 --> Utf8 Class Initialized
INFO - 2018-07-25 00:24:27 --> URI Class Initialized
INFO - 2018-07-25 00:24:27 --> Router Class Initialized
INFO - 2018-07-25 00:24:27 --> Output Class Initialized
INFO - 2018-07-25 00:24:27 --> Config Class Initialized
INFO - 2018-07-25 00:24:27 --> Hooks Class Initialized
INFO - 2018-07-25 00:24:27 --> Security Class Initialized
DEBUG - 2018-07-25 00:24:27 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:24:27 --> Utf8 Class Initialized
INFO - 2018-07-25 00:24:27 --> URI Class Initialized
INFO - 2018-07-25 00:24:27 --> Router Class Initialized
INFO - 2018-07-25 00:24:27 --> Output Class Initialized
INFO - 2018-07-25 00:24:27 --> Security Class Initialized
DEBUG - 2018-07-25 00:24:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:24:27 --> Input Class Initialized
INFO - 2018-07-25 00:24:27 --> Language Class Initialized
ERROR - 2018-07-25 00:24:27 --> 404 Page Not Found: /index
DEBUG - 2018-07-25 00:24:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:24:28 --> Input Class Initialized
INFO - 2018-07-25 00:24:28 --> Config Class Initialized
INFO - 2018-07-25 00:24:28 --> Hooks Class Initialized
INFO - 2018-07-25 00:24:28 --> Language Class Initialized
DEBUG - 2018-07-25 00:24:28 --> UTF-8 Support Enabled
ERROR - 2018-07-25 00:24:28 --> 404 Page Not Found: /index
INFO - 2018-07-25 00:24:28 --> Utf8 Class Initialized
INFO - 2018-07-25 00:24:28 --> URI Class Initialized
INFO - 2018-07-25 00:24:28 --> Config Class Initialized
INFO - 2018-07-25 00:24:28 --> Hooks Class Initialized
INFO - 2018-07-25 00:24:28 --> Router Class Initialized
DEBUG - 2018-07-25 00:24:28 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:24:28 --> Output Class Initialized
INFO - 2018-07-25 00:24:28 --> Security Class Initialized
INFO - 2018-07-25 00:24:28 --> Utf8 Class Initialized
INFO - 2018-07-25 00:24:28 --> URI Class Initialized
DEBUG - 2018-07-25 00:24:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:24:28 --> Input Class Initialized
INFO - 2018-07-25 00:24:28 --> Router Class Initialized
INFO - 2018-07-25 00:24:28 --> Language Class Initialized
INFO - 2018-07-25 00:24:28 --> Output Class Initialized
ERROR - 2018-07-25 00:24:28 --> 404 Page Not Found: /index
INFO - 2018-07-25 00:24:28 --> Security Class Initialized
DEBUG - 2018-07-25 00:24:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:24:28 --> Config Class Initialized
INFO - 2018-07-25 00:24:28 --> Hooks Class Initialized
INFO - 2018-07-25 00:24:28 --> Input Class Initialized
DEBUG - 2018-07-25 00:24:28 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:24:28 --> Utf8 Class Initialized
INFO - 2018-07-25 00:24:28 --> Language Class Initialized
INFO - 2018-07-25 00:24:28 --> URI Class Initialized
ERROR - 2018-07-25 00:24:28 --> 404 Page Not Found: /index
INFO - 2018-07-25 00:24:28 --> Router Class Initialized
INFO - 2018-07-25 00:24:28 --> Output Class Initialized
INFO - 2018-07-25 00:24:28 --> Security Class Initialized
DEBUG - 2018-07-25 00:24:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:24:28 --> Input Class Initialized
INFO - 2018-07-25 00:24:28 --> Language Class Initialized
ERROR - 2018-07-25 00:24:28 --> 404 Page Not Found: /index
INFO - 2018-07-25 00:25:39 --> Config Class Initialized
INFO - 2018-07-25 00:25:39 --> Hooks Class Initialized
DEBUG - 2018-07-25 00:25:39 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:25:39 --> Utf8 Class Initialized
INFO - 2018-07-25 00:25:39 --> URI Class Initialized
DEBUG - 2018-07-25 00:25:39 --> No URI present. Default controller set.
INFO - 2018-07-25 00:25:39 --> Router Class Initialized
INFO - 2018-07-25 00:25:39 --> Output Class Initialized
INFO - 2018-07-25 00:25:39 --> Security Class Initialized
DEBUG - 2018-07-25 00:25:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:25:39 --> Input Class Initialized
INFO - 2018-07-25 00:25:39 --> Language Class Initialized
INFO - 2018-07-25 00:25:39 --> Language Class Initialized
INFO - 2018-07-25 00:25:39 --> Config Class Initialized
INFO - 2018-07-25 00:25:39 --> Loader Class Initialized
DEBUG - 2018-07-25 00:25:39 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-25 00:25:39 --> Helper loaded: url_helper
INFO - 2018-07-25 00:25:39 --> Helper loaded: form_helper
INFO - 2018-07-25 00:25:39 --> Helper loaded: date_helper
INFO - 2018-07-25 00:25:39 --> Helper loaded: util_helper
INFO - 2018-07-25 00:25:39 --> Helper loaded: text_helper
INFO - 2018-07-25 00:25:39 --> Helper loaded: string_helper
INFO - 2018-07-25 00:25:39 --> Database Driver Class Initialized
DEBUG - 2018-07-25 00:25:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 00:25:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 00:25:39 --> Email Class Initialized
INFO - 2018-07-25 00:25:39 --> Controller Class Initialized
DEBUG - 2018-07-25 00:25:39 --> Home MX_Controller Initialized
DEBUG - 2018-07-25 00:25:39 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-25 00:25:39 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-25 00:25:39 --> Login MX_Controller Initialized
INFO - 2018-07-25 00:25:39 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-25 00:25:39 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-25 00:25:39 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-25 00:25:39 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-07-25 00:25:39 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-07-25 00:25:39 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-07-25 00:25:39 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-07-25 00:25:39 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-07-25 00:25:39 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-07-25 00:25:39 --> Final output sent to browser
DEBUG - 2018-07-25 00:25:39 --> Total execution time: 0.4697
INFO - 2018-07-25 00:25:40 --> Config Class Initialized
INFO - 2018-07-25 00:25:40 --> Config Class Initialized
INFO - 2018-07-25 00:25:40 --> Config Class Initialized
INFO - 2018-07-25 00:25:40 --> Hooks Class Initialized
INFO - 2018-07-25 00:25:40 --> Hooks Class Initialized
INFO - 2018-07-25 00:25:40 --> Hooks Class Initialized
DEBUG - 2018-07-25 00:25:40 --> UTF-8 Support Enabled
DEBUG - 2018-07-25 00:25:40 --> UTF-8 Support Enabled
DEBUG - 2018-07-25 00:25:40 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:25:40 --> Utf8 Class Initialized
INFO - 2018-07-25 00:25:40 --> Utf8 Class Initialized
INFO - 2018-07-25 00:25:40 --> Utf8 Class Initialized
INFO - 2018-07-25 00:25:40 --> URI Class Initialized
INFO - 2018-07-25 00:25:40 --> URI Class Initialized
INFO - 2018-07-25 00:25:40 --> URI Class Initialized
INFO - 2018-07-25 00:25:40 --> Router Class Initialized
INFO - 2018-07-25 00:25:40 --> Router Class Initialized
INFO - 2018-07-25 00:25:40 --> Output Class Initialized
INFO - 2018-07-25 00:25:40 --> Router Class Initialized
INFO - 2018-07-25 00:25:40 --> Security Class Initialized
INFO - 2018-07-25 00:25:40 --> Output Class Initialized
INFO - 2018-07-25 00:25:40 --> Output Class Initialized
INFO - 2018-07-25 00:25:40 --> Security Class Initialized
INFO - 2018-07-25 00:25:40 --> Security Class Initialized
DEBUG - 2018-07-25 00:25:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:25:40 --> Input Class Initialized
DEBUG - 2018-07-25 00:25:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-07-25 00:25:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:25:40 --> Language Class Initialized
INFO - 2018-07-25 00:25:40 --> Input Class Initialized
INFO - 2018-07-25 00:25:40 --> Input Class Initialized
ERROR - 2018-07-25 00:25:40 --> 404 Page Not Found: /index
INFO - 2018-07-25 00:25:40 --> Language Class Initialized
INFO - 2018-07-25 00:25:40 --> Language Class Initialized
ERROR - 2018-07-25 00:25:40 --> 404 Page Not Found: /index
ERROR - 2018-07-25 00:25:40 --> 404 Page Not Found: /index
INFO - 2018-07-25 00:25:40 --> Config Class Initialized
INFO - 2018-07-25 00:25:40 --> Hooks Class Initialized
DEBUG - 2018-07-25 00:25:40 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:25:40 --> Utf8 Class Initialized
INFO - 2018-07-25 00:25:40 --> URI Class Initialized
INFO - 2018-07-25 00:25:40 --> Router Class Initialized
INFO - 2018-07-25 00:25:40 --> Output Class Initialized
INFO - 2018-07-25 00:25:40 --> Security Class Initialized
DEBUG - 2018-07-25 00:25:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:25:40 --> Input Class Initialized
INFO - 2018-07-25 00:25:40 --> Language Class Initialized
ERROR - 2018-07-25 00:25:40 --> 404 Page Not Found: /index
INFO - 2018-07-25 00:25:40 --> Config Class Initialized
INFO - 2018-07-25 00:25:40 --> Hooks Class Initialized
DEBUG - 2018-07-25 00:25:40 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:25:40 --> Utf8 Class Initialized
INFO - 2018-07-25 00:25:40 --> URI Class Initialized
INFO - 2018-07-25 00:25:40 --> Router Class Initialized
INFO - 2018-07-25 00:25:40 --> Output Class Initialized
INFO - 2018-07-25 00:25:40 --> Security Class Initialized
DEBUG - 2018-07-25 00:25:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:25:40 --> Input Class Initialized
INFO - 2018-07-25 00:25:40 --> Language Class Initialized
ERROR - 2018-07-25 00:25:40 --> 404 Page Not Found: /index
INFO - 2018-07-25 00:25:40 --> Config Class Initialized
INFO - 2018-07-25 00:25:41 --> Hooks Class Initialized
DEBUG - 2018-07-25 00:25:41 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:25:41 --> Utf8 Class Initialized
INFO - 2018-07-25 00:25:41 --> URI Class Initialized
INFO - 2018-07-25 00:25:41 --> Router Class Initialized
INFO - 2018-07-25 00:25:41 --> Output Class Initialized
INFO - 2018-07-25 00:25:41 --> Security Class Initialized
DEBUG - 2018-07-25 00:25:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:25:41 --> Input Class Initialized
INFO - 2018-07-25 00:25:41 --> Language Class Initialized
ERROR - 2018-07-25 00:25:41 --> 404 Page Not Found: /index
INFO - 2018-07-25 00:25:41 --> Config Class Initialized
INFO - 2018-07-25 00:25:41 --> Hooks Class Initialized
DEBUG - 2018-07-25 00:25:41 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:25:41 --> Utf8 Class Initialized
INFO - 2018-07-25 00:25:41 --> URI Class Initialized
INFO - 2018-07-25 00:25:41 --> Router Class Initialized
INFO - 2018-07-25 00:25:41 --> Output Class Initialized
INFO - 2018-07-25 00:25:41 --> Security Class Initialized
DEBUG - 2018-07-25 00:25:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:25:41 --> Input Class Initialized
INFO - 2018-07-25 00:25:41 --> Language Class Initialized
ERROR - 2018-07-25 00:25:41 --> 404 Page Not Found: /index
INFO - 2018-07-25 00:25:41 --> Config Class Initialized
INFO - 2018-07-25 00:25:41 --> Hooks Class Initialized
DEBUG - 2018-07-25 00:25:41 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:25:41 --> Utf8 Class Initialized
INFO - 2018-07-25 00:25:41 --> URI Class Initialized
INFO - 2018-07-25 00:25:41 --> Router Class Initialized
INFO - 2018-07-25 00:25:41 --> Output Class Initialized
INFO - 2018-07-25 00:25:41 --> Security Class Initialized
DEBUG - 2018-07-25 00:25:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:25:41 --> Input Class Initialized
INFO - 2018-07-25 00:25:41 --> Language Class Initialized
ERROR - 2018-07-25 00:25:41 --> 404 Page Not Found: /index
INFO - 2018-07-25 00:25:41 --> Config Class Initialized
INFO - 2018-07-25 00:25:41 --> Hooks Class Initialized
DEBUG - 2018-07-25 00:25:41 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:25:41 --> Utf8 Class Initialized
INFO - 2018-07-25 00:25:41 --> URI Class Initialized
INFO - 2018-07-25 00:25:41 --> Router Class Initialized
INFO - 2018-07-25 00:25:41 --> Output Class Initialized
INFO - 2018-07-25 00:25:41 --> Security Class Initialized
DEBUG - 2018-07-25 00:25:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:25:42 --> Input Class Initialized
INFO - 2018-07-25 00:25:42 --> Language Class Initialized
ERROR - 2018-07-25 00:25:42 --> 404 Page Not Found: /index
INFO - 2018-07-25 00:28:04 --> Config Class Initialized
INFO - 2018-07-25 00:28:04 --> Hooks Class Initialized
DEBUG - 2018-07-25 00:28:04 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:28:04 --> Utf8 Class Initialized
INFO - 2018-07-25 00:28:04 --> URI Class Initialized
DEBUG - 2018-07-25 00:28:04 --> No URI present. Default controller set.
INFO - 2018-07-25 00:28:04 --> Router Class Initialized
INFO - 2018-07-25 00:28:04 --> Output Class Initialized
INFO - 2018-07-25 00:28:04 --> Security Class Initialized
DEBUG - 2018-07-25 00:28:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:28:04 --> Input Class Initialized
INFO - 2018-07-25 00:28:04 --> Language Class Initialized
INFO - 2018-07-25 00:28:04 --> Language Class Initialized
INFO - 2018-07-25 00:28:04 --> Config Class Initialized
INFO - 2018-07-25 00:28:04 --> Loader Class Initialized
DEBUG - 2018-07-25 00:28:04 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-25 00:28:04 --> Helper loaded: url_helper
INFO - 2018-07-25 00:28:04 --> Helper loaded: form_helper
INFO - 2018-07-25 00:28:04 --> Helper loaded: date_helper
INFO - 2018-07-25 00:28:04 --> Helper loaded: util_helper
INFO - 2018-07-25 00:28:04 --> Helper loaded: text_helper
INFO - 2018-07-25 00:28:04 --> Helper loaded: string_helper
INFO - 2018-07-25 00:28:04 --> Database Driver Class Initialized
DEBUG - 2018-07-25 00:28:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 00:28:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 00:28:04 --> Email Class Initialized
INFO - 2018-07-25 00:28:04 --> Controller Class Initialized
DEBUG - 2018-07-25 00:28:04 --> Home MX_Controller Initialized
DEBUG - 2018-07-25 00:28:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-25 00:28:04 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-25 00:28:04 --> Login MX_Controller Initialized
INFO - 2018-07-25 00:28:04 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-25 00:28:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-25 00:28:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-25 00:28:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-07-25 00:28:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-07-25 00:28:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-07-25 00:28:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-07-25 00:28:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-07-25 00:28:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-07-25 00:28:04 --> Final output sent to browser
DEBUG - 2018-07-25 00:28:05 --> Total execution time: 0.4486
INFO - 2018-07-25 00:28:05 --> Config Class Initialized
INFO - 2018-07-25 00:28:05 --> Hooks Class Initialized
DEBUG - 2018-07-25 00:28:05 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:28:05 --> Utf8 Class Initialized
INFO - 2018-07-25 00:28:05 --> URI Class Initialized
INFO - 2018-07-25 00:28:05 --> Router Class Initialized
INFO - 2018-07-25 00:28:05 --> Output Class Initialized
INFO - 2018-07-25 00:28:05 --> Security Class Initialized
DEBUG - 2018-07-25 00:28:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:28:05 --> Input Class Initialized
INFO - 2018-07-25 00:28:05 --> Language Class Initialized
INFO - 2018-07-25 00:28:05 --> Config Class Initialized
INFO - 2018-07-25 00:28:05 --> Hooks Class Initialized
ERROR - 2018-07-25 00:28:05 --> 404 Page Not Found: /index
DEBUG - 2018-07-25 00:28:05 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:28:05 --> Utf8 Class Initialized
INFO - 2018-07-25 00:28:05 --> URI Class Initialized
INFO - 2018-07-25 00:28:05 --> Router Class Initialized
INFO - 2018-07-25 00:28:05 --> Output Class Initialized
INFO - 2018-07-25 00:28:05 --> Security Class Initialized
DEBUG - 2018-07-25 00:28:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:28:05 --> Input Class Initialized
INFO - 2018-07-25 00:28:05 --> Language Class Initialized
ERROR - 2018-07-25 00:28:05 --> 404 Page Not Found: /index
INFO - 2018-07-25 00:28:05 --> Config Class Initialized
INFO - 2018-07-25 00:28:05 --> Hooks Class Initialized
DEBUG - 2018-07-25 00:28:05 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:28:05 --> Utf8 Class Initialized
INFO - 2018-07-25 00:28:05 --> URI Class Initialized
INFO - 2018-07-25 00:28:05 --> Router Class Initialized
INFO - 2018-07-25 00:28:05 --> Output Class Initialized
INFO - 2018-07-25 00:28:05 --> Security Class Initialized
INFO - 2018-07-25 00:28:05 --> Config Class Initialized
INFO - 2018-07-25 00:28:05 --> Hooks Class Initialized
DEBUG - 2018-07-25 00:28:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-07-25 00:28:05 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:28:06 --> Utf8 Class Initialized
INFO - 2018-07-25 00:28:06 --> URI Class Initialized
INFO - 2018-07-25 00:28:06 --> Router Class Initialized
INFO - 2018-07-25 00:28:06 --> Output Class Initialized
INFO - 2018-07-25 00:28:06 --> Security Class Initialized
DEBUG - 2018-07-25 00:28:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:28:06 --> Input Class Initialized
INFO - 2018-07-25 00:28:06 --> Language Class Initialized
ERROR - 2018-07-25 00:28:06 --> 404 Page Not Found: /index
INFO - 2018-07-25 00:28:06 --> Input Class Initialized
INFO - 2018-07-25 00:28:06 --> Language Class Initialized
ERROR - 2018-07-25 00:28:06 --> 404 Page Not Found: /index
INFO - 2018-07-25 00:28:06 --> Config Class Initialized
INFO - 2018-07-25 00:28:06 --> Config Class Initialized
INFO - 2018-07-25 00:28:06 --> Hooks Class Initialized
INFO - 2018-07-25 00:28:06 --> Hooks Class Initialized
DEBUG - 2018-07-25 00:28:06 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:28:06 --> Utf8 Class Initialized
DEBUG - 2018-07-25 00:28:06 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:28:06 --> URI Class Initialized
INFO - 2018-07-25 00:28:06 --> Utf8 Class Initialized
INFO - 2018-07-25 00:28:06 --> URI Class Initialized
INFO - 2018-07-25 00:28:06 --> Router Class Initialized
INFO - 2018-07-25 00:28:06 --> Output Class Initialized
INFO - 2018-07-25 00:28:06 --> Security Class Initialized
DEBUG - 2018-07-25 00:28:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:28:06 --> Router Class Initialized
INFO - 2018-07-25 00:28:06 --> Input Class Initialized
INFO - 2018-07-25 00:28:06 --> Language Class Initialized
ERROR - 2018-07-25 00:28:06 --> 404 Page Not Found: /index
INFO - 2018-07-25 00:28:06 --> Output Class Initialized
INFO - 2018-07-25 00:28:06 --> Security Class Initialized
DEBUG - 2018-07-25 00:28:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:28:06 --> Input Class Initialized
INFO - 2018-07-25 00:28:06 --> Language Class Initialized
ERROR - 2018-07-25 00:28:06 --> 404 Page Not Found: /index
INFO - 2018-07-25 00:29:20 --> Config Class Initialized
INFO - 2018-07-25 00:29:20 --> Hooks Class Initialized
DEBUG - 2018-07-25 00:29:20 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:29:20 --> Utf8 Class Initialized
INFO - 2018-07-25 00:29:20 --> URI Class Initialized
DEBUG - 2018-07-25 00:29:20 --> No URI present. Default controller set.
INFO - 2018-07-25 00:29:20 --> Router Class Initialized
INFO - 2018-07-25 00:29:20 --> Output Class Initialized
INFO - 2018-07-25 00:29:20 --> Security Class Initialized
DEBUG - 2018-07-25 00:29:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:29:20 --> Input Class Initialized
INFO - 2018-07-25 00:29:20 --> Language Class Initialized
INFO - 2018-07-25 00:29:20 --> Language Class Initialized
INFO - 2018-07-25 00:29:20 --> Config Class Initialized
INFO - 2018-07-25 00:29:20 --> Loader Class Initialized
DEBUG - 2018-07-25 00:29:20 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-25 00:29:20 --> Helper loaded: url_helper
INFO - 2018-07-25 00:29:20 --> Helper loaded: form_helper
INFO - 2018-07-25 00:29:20 --> Helper loaded: date_helper
INFO - 2018-07-25 00:29:20 --> Helper loaded: util_helper
INFO - 2018-07-25 00:29:20 --> Helper loaded: text_helper
INFO - 2018-07-25 00:29:20 --> Helper loaded: string_helper
INFO - 2018-07-25 00:29:20 --> Database Driver Class Initialized
DEBUG - 2018-07-25 00:29:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 00:29:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 00:29:20 --> Email Class Initialized
INFO - 2018-07-25 00:29:20 --> Controller Class Initialized
DEBUG - 2018-07-25 00:29:20 --> Home MX_Controller Initialized
DEBUG - 2018-07-25 00:29:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-25 00:29:20 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-25 00:29:20 --> Login MX_Controller Initialized
INFO - 2018-07-25 00:29:20 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-25 00:29:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-25 00:29:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-25 00:29:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-07-25 00:29:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-07-25 00:29:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-07-25 00:29:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-07-25 00:29:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-07-25 00:29:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-07-25 00:29:20 --> Final output sent to browser
DEBUG - 2018-07-25 00:29:20 --> Total execution time: 0.5475
INFO - 2018-07-25 00:29:20 --> Config Class Initialized
INFO - 2018-07-25 00:29:20 --> Hooks Class Initialized
DEBUG - 2018-07-25 00:29:20 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:29:20 --> Utf8 Class Initialized
INFO - 2018-07-25 00:29:21 --> URI Class Initialized
INFO - 2018-07-25 00:29:21 --> Router Class Initialized
INFO - 2018-07-25 00:29:21 --> Output Class Initialized
INFO - 2018-07-25 00:29:21 --> Security Class Initialized
DEBUG - 2018-07-25 00:29:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:29:21 --> Input Class Initialized
INFO - 2018-07-25 00:29:21 --> Language Class Initialized
ERROR - 2018-07-25 00:29:21 --> 404 Page Not Found: /index
INFO - 2018-07-25 00:29:21 --> Config Class Initialized
INFO - 2018-07-25 00:29:21 --> Hooks Class Initialized
DEBUG - 2018-07-25 00:29:21 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:29:21 --> Utf8 Class Initialized
INFO - 2018-07-25 00:29:21 --> URI Class Initialized
INFO - 2018-07-25 00:29:21 --> Router Class Initialized
INFO - 2018-07-25 00:29:21 --> Config Class Initialized
INFO - 2018-07-25 00:29:21 --> Hooks Class Initialized
INFO - 2018-07-25 00:29:21 --> Output Class Initialized
DEBUG - 2018-07-25 00:29:21 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:29:21 --> Utf8 Class Initialized
INFO - 2018-07-25 00:29:21 --> Security Class Initialized
INFO - 2018-07-25 00:29:21 --> URI Class Initialized
INFO - 2018-07-25 00:29:21 --> Router Class Initialized
INFO - 2018-07-25 00:29:21 --> Output Class Initialized
INFO - 2018-07-25 00:29:21 --> Security Class Initialized
DEBUG - 2018-07-25 00:29:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:29:21 --> Input Class Initialized
INFO - 2018-07-25 00:29:21 --> Language Class Initialized
ERROR - 2018-07-25 00:29:21 --> 404 Page Not Found: /index
DEBUG - 2018-07-25 00:29:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:29:21 --> Input Class Initialized
INFO - 2018-07-25 00:29:21 --> Language Class Initialized
ERROR - 2018-07-25 00:29:21 --> 404 Page Not Found: /index
INFO - 2018-07-25 00:29:21 --> Config Class Initialized
INFO - 2018-07-25 00:29:21 --> Hooks Class Initialized
INFO - 2018-07-25 00:29:21 --> Config Class Initialized
INFO - 2018-07-25 00:29:21 --> Hooks Class Initialized
DEBUG - 2018-07-25 00:29:21 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:29:21 --> Utf8 Class Initialized
DEBUG - 2018-07-25 00:29:21 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:29:21 --> URI Class Initialized
INFO - 2018-07-25 00:29:21 --> Utf8 Class Initialized
INFO - 2018-07-25 00:29:21 --> Router Class Initialized
INFO - 2018-07-25 00:29:21 --> URI Class Initialized
INFO - 2018-07-25 00:29:21 --> Output Class Initialized
INFO - 2018-07-25 00:29:21 --> Router Class Initialized
INFO - 2018-07-25 00:29:21 --> Security Class Initialized
INFO - 2018-07-25 00:29:21 --> Output Class Initialized
INFO - 2018-07-25 00:29:21 --> Security Class Initialized
DEBUG - 2018-07-25 00:29:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:29:21 --> Input Class Initialized
INFO - 2018-07-25 00:29:22 --> Language Class Initialized
DEBUG - 2018-07-25 00:29:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-07-25 00:29:22 --> 404 Page Not Found: /index
INFO - 2018-07-25 00:29:22 --> Input Class Initialized
INFO - 2018-07-25 00:29:22 --> Language Class Initialized
ERROR - 2018-07-25 00:29:22 --> 404 Page Not Found: /index
INFO - 2018-07-25 00:29:24 --> Config Class Initialized
INFO - 2018-07-25 00:29:24 --> Hooks Class Initialized
DEBUG - 2018-07-25 00:29:24 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:29:24 --> Utf8 Class Initialized
INFO - 2018-07-25 00:29:24 --> URI Class Initialized
INFO - 2018-07-25 00:29:24 --> Router Class Initialized
INFO - 2018-07-25 00:29:24 --> Output Class Initialized
INFO - 2018-07-25 00:29:24 --> Security Class Initialized
DEBUG - 2018-07-25 00:29:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:29:24 --> Input Class Initialized
INFO - 2018-07-25 00:29:24 --> Language Class Initialized
ERROR - 2018-07-25 00:29:24 --> 404 Page Not Found: /index
INFO - 2018-07-25 00:30:12 --> Config Class Initialized
INFO - 2018-07-25 00:30:12 --> Hooks Class Initialized
DEBUG - 2018-07-25 00:30:12 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:30:12 --> Utf8 Class Initialized
INFO - 2018-07-25 00:30:12 --> URI Class Initialized
DEBUG - 2018-07-25 00:30:12 --> No URI present. Default controller set.
INFO - 2018-07-25 00:30:12 --> Router Class Initialized
INFO - 2018-07-25 00:30:12 --> Output Class Initialized
INFO - 2018-07-25 00:30:12 --> Security Class Initialized
DEBUG - 2018-07-25 00:30:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:30:12 --> Input Class Initialized
INFO - 2018-07-25 00:30:12 --> Language Class Initialized
INFO - 2018-07-25 00:30:12 --> Language Class Initialized
INFO - 2018-07-25 00:30:12 --> Config Class Initialized
INFO - 2018-07-25 00:30:13 --> Loader Class Initialized
DEBUG - 2018-07-25 00:30:13 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-25 00:30:13 --> Helper loaded: url_helper
INFO - 2018-07-25 00:30:13 --> Helper loaded: form_helper
INFO - 2018-07-25 00:30:13 --> Helper loaded: date_helper
INFO - 2018-07-25 00:30:13 --> Helper loaded: util_helper
INFO - 2018-07-25 00:30:13 --> Helper loaded: text_helper
INFO - 2018-07-25 00:30:13 --> Helper loaded: string_helper
INFO - 2018-07-25 00:30:13 --> Database Driver Class Initialized
DEBUG - 2018-07-25 00:30:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 00:30:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 00:30:13 --> Email Class Initialized
INFO - 2018-07-25 00:30:13 --> Controller Class Initialized
DEBUG - 2018-07-25 00:30:13 --> Home MX_Controller Initialized
DEBUG - 2018-07-25 00:30:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-25 00:30:13 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-25 00:30:13 --> Login MX_Controller Initialized
INFO - 2018-07-25 00:30:13 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-25 00:30:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-25 00:30:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-25 00:30:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-07-25 00:30:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-07-25 00:30:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-07-25 00:30:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-07-25 00:30:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-07-25 00:30:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-07-25 00:30:13 --> Final output sent to browser
DEBUG - 2018-07-25 00:30:13 --> Total execution time: 0.5209
INFO - 2018-07-25 00:30:13 --> Config Class Initialized
INFO - 2018-07-25 00:30:13 --> Config Class Initialized
INFO - 2018-07-25 00:30:13 --> Config Class Initialized
INFO - 2018-07-25 00:30:13 --> Hooks Class Initialized
INFO - 2018-07-25 00:30:13 --> Hooks Class Initialized
INFO - 2018-07-25 00:30:13 --> Hooks Class Initialized
DEBUG - 2018-07-25 00:30:13 --> UTF-8 Support Enabled
DEBUG - 2018-07-25 00:30:13 --> UTF-8 Support Enabled
DEBUG - 2018-07-25 00:30:13 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:30:13 --> Utf8 Class Initialized
INFO - 2018-07-25 00:30:13 --> Utf8 Class Initialized
INFO - 2018-07-25 00:30:13 --> Utf8 Class Initialized
INFO - 2018-07-25 00:30:13 --> URI Class Initialized
INFO - 2018-07-25 00:30:13 --> URI Class Initialized
INFO - 2018-07-25 00:30:13 --> Router Class Initialized
INFO - 2018-07-25 00:30:13 --> URI Class Initialized
INFO - 2018-07-25 00:30:13 --> Output Class Initialized
INFO - 2018-07-25 00:30:13 --> Router Class Initialized
INFO - 2018-07-25 00:30:13 --> Router Class Initialized
INFO - 2018-07-25 00:30:13 --> Security Class Initialized
INFO - 2018-07-25 00:30:13 --> Output Class Initialized
INFO - 2018-07-25 00:30:13 --> Output Class Initialized
INFO - 2018-07-25 00:30:13 --> Security Class Initialized
DEBUG - 2018-07-25 00:30:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:30:13 --> Security Class Initialized
DEBUG - 2018-07-25 00:30:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:30:13 --> Input Class Initialized
DEBUG - 2018-07-25 00:30:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:30:13 --> Language Class Initialized
INFO - 2018-07-25 00:30:13 --> Input Class Initialized
INFO - 2018-07-25 00:30:13 --> Input Class Initialized
ERROR - 2018-07-25 00:30:13 --> 404 Page Not Found: /index
INFO - 2018-07-25 00:30:13 --> Language Class Initialized
INFO - 2018-07-25 00:30:13 --> Language Class Initialized
ERROR - 2018-07-25 00:30:13 --> 404 Page Not Found: /index
ERROR - 2018-07-25 00:30:13 --> 404 Page Not Found: /index
INFO - 2018-07-25 00:30:14 --> Config Class Initialized
INFO - 2018-07-25 00:30:14 --> Hooks Class Initialized
DEBUG - 2018-07-25 00:30:14 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:30:14 --> Utf8 Class Initialized
INFO - 2018-07-25 00:30:14 --> URI Class Initialized
INFO - 2018-07-25 00:30:14 --> Router Class Initialized
INFO - 2018-07-25 00:30:14 --> Output Class Initialized
INFO - 2018-07-25 00:30:14 --> Security Class Initialized
DEBUG - 2018-07-25 00:30:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:30:14 --> Input Class Initialized
INFO - 2018-07-25 00:30:14 --> Language Class Initialized
ERROR - 2018-07-25 00:30:14 --> 404 Page Not Found: /index
INFO - 2018-07-25 00:30:14 --> Config Class Initialized
INFO - 2018-07-25 00:30:14 --> Hooks Class Initialized
DEBUG - 2018-07-25 00:30:14 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:30:14 --> Utf8 Class Initialized
INFO - 2018-07-25 00:30:14 --> URI Class Initialized
INFO - 2018-07-25 00:30:14 --> Router Class Initialized
INFO - 2018-07-25 00:30:14 --> Output Class Initialized
INFO - 2018-07-25 00:30:14 --> Security Class Initialized
DEBUG - 2018-07-25 00:30:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:30:14 --> Input Class Initialized
INFO - 2018-07-25 00:30:14 --> Language Class Initialized
ERROR - 2018-07-25 00:30:14 --> 404 Page Not Found: /index
INFO - 2018-07-25 00:30:14 --> Config Class Initialized
INFO - 2018-07-25 00:30:14 --> Hooks Class Initialized
DEBUG - 2018-07-25 00:30:14 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:30:14 --> Utf8 Class Initialized
INFO - 2018-07-25 00:30:14 --> URI Class Initialized
INFO - 2018-07-25 00:30:14 --> Router Class Initialized
INFO - 2018-07-25 00:30:15 --> Output Class Initialized
INFO - 2018-07-25 00:30:15 --> Security Class Initialized
DEBUG - 2018-07-25 00:30:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:30:15 --> Input Class Initialized
INFO - 2018-07-25 00:30:15 --> Language Class Initialized
ERROR - 2018-07-25 00:30:15 --> 404 Page Not Found: /index
INFO - 2018-07-25 00:30:37 --> Config Class Initialized
INFO - 2018-07-25 00:30:37 --> Hooks Class Initialized
DEBUG - 2018-07-25 00:30:37 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:30:37 --> Utf8 Class Initialized
INFO - 2018-07-25 00:30:37 --> URI Class Initialized
DEBUG - 2018-07-25 00:30:37 --> No URI present. Default controller set.
INFO - 2018-07-25 00:30:37 --> Router Class Initialized
INFO - 2018-07-25 00:30:37 --> Output Class Initialized
INFO - 2018-07-25 00:30:37 --> Security Class Initialized
DEBUG - 2018-07-25 00:30:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:30:37 --> Input Class Initialized
INFO - 2018-07-25 00:30:37 --> Language Class Initialized
INFO - 2018-07-25 00:30:37 --> Language Class Initialized
INFO - 2018-07-25 00:30:37 --> Config Class Initialized
INFO - 2018-07-25 00:30:37 --> Loader Class Initialized
DEBUG - 2018-07-25 00:30:37 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-25 00:30:37 --> Helper loaded: url_helper
INFO - 2018-07-25 00:30:37 --> Helper loaded: form_helper
INFO - 2018-07-25 00:30:37 --> Helper loaded: date_helper
INFO - 2018-07-25 00:30:37 --> Helper loaded: util_helper
INFO - 2018-07-25 00:30:37 --> Helper loaded: text_helper
INFO - 2018-07-25 00:30:37 --> Helper loaded: string_helper
INFO - 2018-07-25 00:30:37 --> Database Driver Class Initialized
DEBUG - 2018-07-25 00:30:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 00:30:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 00:30:37 --> Email Class Initialized
INFO - 2018-07-25 00:30:37 --> Controller Class Initialized
DEBUG - 2018-07-25 00:30:37 --> Home MX_Controller Initialized
DEBUG - 2018-07-25 00:30:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-25 00:30:37 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-25 00:30:37 --> Login MX_Controller Initialized
INFO - 2018-07-25 00:30:37 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-25 00:30:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-25 00:30:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-25 00:30:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-07-25 00:30:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-07-25 00:30:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-07-25 00:30:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-07-25 00:30:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-07-25 00:30:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-07-25 00:30:37 --> Final output sent to browser
DEBUG - 2018-07-25 00:30:37 --> Total execution time: 0.5277
INFO - 2018-07-25 00:30:37 --> Config Class Initialized
INFO - 2018-07-25 00:30:37 --> Config Class Initialized
INFO - 2018-07-25 00:30:38 --> Config Class Initialized
INFO - 2018-07-25 00:30:38 --> Hooks Class Initialized
INFO - 2018-07-25 00:30:38 --> Hooks Class Initialized
INFO - 2018-07-25 00:30:38 --> Hooks Class Initialized
DEBUG - 2018-07-25 00:30:38 --> UTF-8 Support Enabled
DEBUG - 2018-07-25 00:30:38 --> UTF-8 Support Enabled
DEBUG - 2018-07-25 00:30:38 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:30:38 --> Utf8 Class Initialized
INFO - 2018-07-25 00:30:38 --> Utf8 Class Initialized
INFO - 2018-07-25 00:30:38 --> Utf8 Class Initialized
INFO - 2018-07-25 00:30:38 --> URI Class Initialized
INFO - 2018-07-25 00:30:38 --> URI Class Initialized
INFO - 2018-07-25 00:30:38 --> URI Class Initialized
INFO - 2018-07-25 00:30:38 --> Router Class Initialized
INFO - 2018-07-25 00:30:38 --> Router Class Initialized
INFO - 2018-07-25 00:30:38 --> Router Class Initialized
INFO - 2018-07-25 00:30:38 --> Output Class Initialized
INFO - 2018-07-25 00:30:38 --> Output Class Initialized
INFO - 2018-07-25 00:30:38 --> Output Class Initialized
INFO - 2018-07-25 00:30:38 --> Security Class Initialized
INFO - 2018-07-25 00:30:38 --> Security Class Initialized
INFO - 2018-07-25 00:30:38 --> Security Class Initialized
DEBUG - 2018-07-25 00:30:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-07-25 00:30:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-07-25 00:30:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:30:38 --> Input Class Initialized
INFO - 2018-07-25 00:30:38 --> Input Class Initialized
INFO - 2018-07-25 00:30:38 --> Input Class Initialized
INFO - 2018-07-25 00:30:38 --> Language Class Initialized
INFO - 2018-07-25 00:30:38 --> Language Class Initialized
INFO - 2018-07-25 00:30:38 --> Language Class Initialized
ERROR - 2018-07-25 00:30:38 --> 404 Page Not Found: /index
ERROR - 2018-07-25 00:30:38 --> 404 Page Not Found: /index
ERROR - 2018-07-25 00:30:38 --> 404 Page Not Found: /index
INFO - 2018-07-25 00:30:38 --> Config Class Initialized
INFO - 2018-07-25 00:30:38 --> Hooks Class Initialized
DEBUG - 2018-07-25 00:30:38 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:30:38 --> Utf8 Class Initialized
INFO - 2018-07-25 00:30:38 --> URI Class Initialized
INFO - 2018-07-25 00:30:38 --> Router Class Initialized
INFO - 2018-07-25 00:30:38 --> Output Class Initialized
INFO - 2018-07-25 00:30:38 --> Security Class Initialized
DEBUG - 2018-07-25 00:30:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:30:38 --> Input Class Initialized
INFO - 2018-07-25 00:30:38 --> Language Class Initialized
ERROR - 2018-07-25 00:30:38 --> 404 Page Not Found: /index
INFO - 2018-07-25 00:30:38 --> Config Class Initialized
INFO - 2018-07-25 00:30:38 --> Hooks Class Initialized
DEBUG - 2018-07-25 00:30:38 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:30:38 --> Utf8 Class Initialized
INFO - 2018-07-25 00:30:38 --> URI Class Initialized
INFO - 2018-07-25 00:30:38 --> Router Class Initialized
INFO - 2018-07-25 00:30:38 --> Output Class Initialized
INFO - 2018-07-25 00:30:38 --> Security Class Initialized
DEBUG - 2018-07-25 00:30:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:30:38 --> Input Class Initialized
INFO - 2018-07-25 00:30:38 --> Language Class Initialized
ERROR - 2018-07-25 00:30:38 --> 404 Page Not Found: /index
INFO - 2018-07-25 00:30:38 --> Config Class Initialized
INFO - 2018-07-25 00:30:38 --> Hooks Class Initialized
DEBUG - 2018-07-25 00:30:38 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:30:38 --> Utf8 Class Initialized
INFO - 2018-07-25 00:30:38 --> URI Class Initialized
INFO - 2018-07-25 00:30:38 --> Router Class Initialized
INFO - 2018-07-25 00:30:39 --> Output Class Initialized
INFO - 2018-07-25 00:30:39 --> Security Class Initialized
DEBUG - 2018-07-25 00:30:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:30:39 --> Input Class Initialized
INFO - 2018-07-25 00:30:39 --> Language Class Initialized
ERROR - 2018-07-25 00:30:39 --> 404 Page Not Found: /index
INFO - 2018-07-25 00:30:39 --> Config Class Initialized
INFO - 2018-07-25 00:30:39 --> Hooks Class Initialized
DEBUG - 2018-07-25 00:30:39 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:30:39 --> Utf8 Class Initialized
INFO - 2018-07-25 00:30:39 --> URI Class Initialized
INFO - 2018-07-25 00:30:39 --> Router Class Initialized
INFO - 2018-07-25 00:30:39 --> Output Class Initialized
INFO - 2018-07-25 00:30:39 --> Security Class Initialized
DEBUG - 2018-07-25 00:30:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:30:39 --> Input Class Initialized
INFO - 2018-07-25 00:30:39 --> Language Class Initialized
ERROR - 2018-07-25 00:30:39 --> 404 Page Not Found: /index
INFO - 2018-07-25 00:30:39 --> Config Class Initialized
INFO - 2018-07-25 00:30:39 --> Hooks Class Initialized
DEBUG - 2018-07-25 00:30:39 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:30:39 --> Utf8 Class Initialized
INFO - 2018-07-25 00:30:39 --> URI Class Initialized
INFO - 2018-07-25 00:30:39 --> Router Class Initialized
INFO - 2018-07-25 00:30:39 --> Output Class Initialized
INFO - 2018-07-25 00:30:39 --> Security Class Initialized
DEBUG - 2018-07-25 00:30:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:30:39 --> Input Class Initialized
INFO - 2018-07-25 00:30:39 --> Language Class Initialized
ERROR - 2018-07-25 00:30:39 --> 404 Page Not Found: /index
INFO - 2018-07-25 00:30:39 --> Config Class Initialized
INFO - 2018-07-25 00:30:39 --> Hooks Class Initialized
DEBUG - 2018-07-25 00:30:39 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:30:39 --> Utf8 Class Initialized
INFO - 2018-07-25 00:30:39 --> URI Class Initialized
INFO - 2018-07-25 00:30:39 --> Router Class Initialized
INFO - 2018-07-25 00:30:39 --> Output Class Initialized
INFO - 2018-07-25 00:30:39 --> Security Class Initialized
DEBUG - 2018-07-25 00:30:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:30:39 --> Input Class Initialized
INFO - 2018-07-25 00:30:39 --> Language Class Initialized
ERROR - 2018-07-25 00:30:39 --> 404 Page Not Found: /index
INFO - 2018-07-25 00:30:44 --> Config Class Initialized
INFO - 2018-07-25 00:30:44 --> Hooks Class Initialized
DEBUG - 2018-07-25 00:30:44 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:30:44 --> Utf8 Class Initialized
INFO - 2018-07-25 00:30:44 --> URI Class Initialized
DEBUG - 2018-07-25 00:30:44 --> No URI present. Default controller set.
INFO - 2018-07-25 00:30:44 --> Router Class Initialized
INFO - 2018-07-25 00:30:44 --> Output Class Initialized
INFO - 2018-07-25 00:30:44 --> Security Class Initialized
DEBUG - 2018-07-25 00:30:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:30:44 --> Input Class Initialized
INFO - 2018-07-25 00:30:44 --> Language Class Initialized
INFO - 2018-07-25 00:30:44 --> Language Class Initialized
INFO - 2018-07-25 00:30:45 --> Config Class Initialized
INFO - 2018-07-25 00:30:45 --> Loader Class Initialized
DEBUG - 2018-07-25 00:30:45 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-25 00:30:45 --> Helper loaded: url_helper
INFO - 2018-07-25 00:30:45 --> Helper loaded: form_helper
INFO - 2018-07-25 00:30:45 --> Helper loaded: date_helper
INFO - 2018-07-25 00:30:45 --> Helper loaded: util_helper
INFO - 2018-07-25 00:30:45 --> Helper loaded: text_helper
INFO - 2018-07-25 00:30:45 --> Helper loaded: string_helper
INFO - 2018-07-25 00:30:45 --> Database Driver Class Initialized
DEBUG - 2018-07-25 00:30:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 00:30:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 00:30:45 --> Email Class Initialized
INFO - 2018-07-25 00:30:45 --> Controller Class Initialized
DEBUG - 2018-07-25 00:30:45 --> Home MX_Controller Initialized
DEBUG - 2018-07-25 00:30:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-25 00:30:45 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-25 00:30:45 --> Login MX_Controller Initialized
INFO - 2018-07-25 00:30:45 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-25 00:30:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-25 00:30:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-25 00:30:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-07-25 00:30:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-07-25 00:30:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-07-25 00:30:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-07-25 00:30:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-07-25 00:30:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-07-25 00:30:45 --> Final output sent to browser
DEBUG - 2018-07-25 00:30:45 --> Total execution time: 0.4921
INFO - 2018-07-25 00:30:45 --> Config Class Initialized
INFO - 2018-07-25 00:30:45 --> Config Class Initialized
INFO - 2018-07-25 00:30:45 --> Config Class Initialized
INFO - 2018-07-25 00:30:45 --> Hooks Class Initialized
INFO - 2018-07-25 00:30:45 --> Hooks Class Initialized
INFO - 2018-07-25 00:30:45 --> Hooks Class Initialized
DEBUG - 2018-07-25 00:30:45 --> UTF-8 Support Enabled
DEBUG - 2018-07-25 00:30:45 --> UTF-8 Support Enabled
DEBUG - 2018-07-25 00:30:45 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:30:45 --> Utf8 Class Initialized
INFO - 2018-07-25 00:30:45 --> Utf8 Class Initialized
INFO - 2018-07-25 00:30:45 --> Utf8 Class Initialized
INFO - 2018-07-25 00:30:45 --> URI Class Initialized
INFO - 2018-07-25 00:30:45 --> URI Class Initialized
INFO - 2018-07-25 00:30:45 --> URI Class Initialized
INFO - 2018-07-25 00:30:45 --> Router Class Initialized
INFO - 2018-07-25 00:30:45 --> Router Class Initialized
INFO - 2018-07-25 00:30:45 --> Router Class Initialized
INFO - 2018-07-25 00:30:45 --> Output Class Initialized
INFO - 2018-07-25 00:30:45 --> Output Class Initialized
INFO - 2018-07-25 00:30:45 --> Output Class Initialized
INFO - 2018-07-25 00:30:45 --> Security Class Initialized
DEBUG - 2018-07-25 00:30:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:30:45 --> Config Class Initialized
INFO - 2018-07-25 00:30:45 --> Hooks Class Initialized
INFO - 2018-07-25 00:30:45 --> Input Class Initialized
INFO - 2018-07-25 00:30:45 --> Security Class Initialized
INFO - 2018-07-25 00:30:45 --> Security Class Initialized
DEBUG - 2018-07-25 00:30:45 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:30:45 --> Utf8 Class Initialized
INFO - 2018-07-25 00:30:45 --> URI Class Initialized
INFO - 2018-07-25 00:30:45 --> Router Class Initialized
INFO - 2018-07-25 00:30:45 --> Output Class Initialized
INFO - 2018-07-25 00:30:45 --> Security Class Initialized
DEBUG - 2018-07-25 00:30:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:30:45 --> Input Class Initialized
INFO - 2018-07-25 00:30:45 --> Language Class Initialized
ERROR - 2018-07-25 00:30:45 --> 404 Page Not Found: /index
INFO - 2018-07-25 00:30:45 --> Language Class Initialized
INFO - 2018-07-25 00:30:45 --> Config Class Initialized
DEBUG - 2018-07-25 00:30:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-07-25 00:30:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:30:45 --> Hooks Class Initialized
ERROR - 2018-07-25 00:30:45 --> 404 Page Not Found: /index
INFO - 2018-07-25 00:30:45 --> Input Class Initialized
INFO - 2018-07-25 00:30:45 --> Input Class Initialized
DEBUG - 2018-07-25 00:30:46 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:30:46 --> Utf8 Class Initialized
INFO - 2018-07-25 00:30:46 --> Language Class Initialized
INFO - 2018-07-25 00:30:46 --> Language Class Initialized
INFO - 2018-07-25 00:30:46 --> URI Class Initialized
ERROR - 2018-07-25 00:30:46 --> 404 Page Not Found: /index
ERROR - 2018-07-25 00:30:46 --> 404 Page Not Found: /index
INFO - 2018-07-25 00:30:46 --> Router Class Initialized
INFO - 2018-07-25 00:30:46 --> Output Class Initialized
INFO - 2018-07-25 00:30:46 --> Security Class Initialized
DEBUG - 2018-07-25 00:30:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:30:46 --> Input Class Initialized
INFO - 2018-07-25 00:30:46 --> Language Class Initialized
ERROR - 2018-07-25 00:30:46 --> 404 Page Not Found: /index
INFO - 2018-07-25 00:30:46 --> Config Class Initialized
INFO - 2018-07-25 00:30:46 --> Hooks Class Initialized
DEBUG - 2018-07-25 00:30:46 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:30:46 --> Utf8 Class Initialized
INFO - 2018-07-25 00:30:46 --> URI Class Initialized
INFO - 2018-07-25 00:30:46 --> Router Class Initialized
INFO - 2018-07-25 00:30:46 --> Output Class Initialized
INFO - 2018-07-25 00:30:46 --> Security Class Initialized
DEBUG - 2018-07-25 00:30:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:30:46 --> Input Class Initialized
INFO - 2018-07-25 00:30:46 --> Language Class Initialized
ERROR - 2018-07-25 00:30:46 --> 404 Page Not Found: /index
INFO - 2018-07-25 00:30:46 --> Config Class Initialized
INFO - 2018-07-25 00:30:46 --> Hooks Class Initialized
DEBUG - 2018-07-25 00:30:46 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:30:46 --> Utf8 Class Initialized
INFO - 2018-07-25 00:30:46 --> URI Class Initialized
INFO - 2018-07-25 00:30:46 --> Router Class Initialized
INFO - 2018-07-25 00:30:46 --> Output Class Initialized
INFO - 2018-07-25 00:30:46 --> Security Class Initialized
DEBUG - 2018-07-25 00:30:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:30:46 --> Input Class Initialized
INFO - 2018-07-25 00:30:46 --> Language Class Initialized
ERROR - 2018-07-25 00:30:46 --> 404 Page Not Found: /index
INFO - 2018-07-25 00:30:47 --> Config Class Initialized
INFO - 2018-07-25 00:30:47 --> Hooks Class Initialized
DEBUG - 2018-07-25 00:30:47 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:30:47 --> Utf8 Class Initialized
INFO - 2018-07-25 00:30:47 --> URI Class Initialized
INFO - 2018-07-25 00:30:47 --> Router Class Initialized
INFO - 2018-07-25 00:30:47 --> Output Class Initialized
INFO - 2018-07-25 00:30:47 --> Security Class Initialized
DEBUG - 2018-07-25 00:30:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:30:47 --> Input Class Initialized
INFO - 2018-07-25 00:30:47 --> Language Class Initialized
ERROR - 2018-07-25 00:30:47 --> 404 Page Not Found: /index
INFO - 2018-07-25 00:30:47 --> Config Class Initialized
INFO - 2018-07-25 00:30:47 --> Hooks Class Initialized
DEBUG - 2018-07-25 00:30:47 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:30:47 --> Utf8 Class Initialized
INFO - 2018-07-25 00:30:47 --> URI Class Initialized
INFO - 2018-07-25 00:30:47 --> Router Class Initialized
INFO - 2018-07-25 00:30:47 --> Output Class Initialized
INFO - 2018-07-25 00:30:47 --> Security Class Initialized
DEBUG - 2018-07-25 00:30:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:30:47 --> Input Class Initialized
INFO - 2018-07-25 00:30:47 --> Language Class Initialized
ERROR - 2018-07-25 00:30:47 --> 404 Page Not Found: /index
INFO - 2018-07-25 00:31:50 --> Config Class Initialized
INFO - 2018-07-25 00:31:50 --> Hooks Class Initialized
DEBUG - 2018-07-25 00:31:50 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:31:50 --> Utf8 Class Initialized
INFO - 2018-07-25 00:31:50 --> URI Class Initialized
DEBUG - 2018-07-25 00:31:50 --> No URI present. Default controller set.
INFO - 2018-07-25 00:31:50 --> Router Class Initialized
INFO - 2018-07-25 00:31:50 --> Output Class Initialized
INFO - 2018-07-25 00:31:50 --> Security Class Initialized
DEBUG - 2018-07-25 00:31:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:31:50 --> Input Class Initialized
INFO - 2018-07-25 00:31:50 --> Language Class Initialized
INFO - 2018-07-25 00:31:50 --> Language Class Initialized
INFO - 2018-07-25 00:31:50 --> Config Class Initialized
INFO - 2018-07-25 00:31:50 --> Loader Class Initialized
DEBUG - 2018-07-25 00:31:50 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-25 00:31:50 --> Helper loaded: url_helper
INFO - 2018-07-25 00:31:51 --> Helper loaded: form_helper
INFO - 2018-07-25 00:31:51 --> Helper loaded: date_helper
INFO - 2018-07-25 00:31:51 --> Helper loaded: util_helper
INFO - 2018-07-25 00:31:51 --> Helper loaded: text_helper
INFO - 2018-07-25 00:31:51 --> Helper loaded: string_helper
INFO - 2018-07-25 00:31:51 --> Database Driver Class Initialized
DEBUG - 2018-07-25 00:31:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 00:31:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 00:31:51 --> Email Class Initialized
INFO - 2018-07-25 00:31:51 --> Controller Class Initialized
DEBUG - 2018-07-25 00:31:51 --> Home MX_Controller Initialized
DEBUG - 2018-07-25 00:31:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-25 00:31:51 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-25 00:31:51 --> Login MX_Controller Initialized
INFO - 2018-07-25 00:31:51 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-25 00:31:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-25 00:31:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-25 00:31:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-07-25 00:31:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-07-25 00:31:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-07-25 00:31:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-07-25 00:31:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-07-25 00:31:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-07-25 00:31:51 --> Final output sent to browser
DEBUG - 2018-07-25 00:31:51 --> Total execution time: 0.5485
INFO - 2018-07-25 00:36:08 --> Config Class Initialized
INFO - 2018-07-25 00:36:08 --> Hooks Class Initialized
DEBUG - 2018-07-25 00:36:08 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:36:08 --> Utf8 Class Initialized
INFO - 2018-07-25 00:36:08 --> URI Class Initialized
DEBUG - 2018-07-25 00:36:08 --> No URI present. Default controller set.
INFO - 2018-07-25 00:36:08 --> Router Class Initialized
INFO - 2018-07-25 00:36:08 --> Output Class Initialized
INFO - 2018-07-25 00:36:08 --> Security Class Initialized
DEBUG - 2018-07-25 00:36:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:36:08 --> Input Class Initialized
INFO - 2018-07-25 00:36:08 --> Language Class Initialized
INFO - 2018-07-25 00:36:08 --> Language Class Initialized
INFO - 2018-07-25 00:36:08 --> Config Class Initialized
INFO - 2018-07-25 00:36:08 --> Loader Class Initialized
DEBUG - 2018-07-25 00:36:08 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-25 00:36:08 --> Helper loaded: url_helper
INFO - 2018-07-25 00:36:08 --> Helper loaded: form_helper
INFO - 2018-07-25 00:36:08 --> Helper loaded: date_helper
INFO - 2018-07-25 00:36:08 --> Helper loaded: util_helper
INFO - 2018-07-25 00:36:08 --> Helper loaded: text_helper
INFO - 2018-07-25 00:36:08 --> Helper loaded: string_helper
INFO - 2018-07-25 00:36:08 --> Database Driver Class Initialized
DEBUG - 2018-07-25 00:36:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 00:36:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 00:36:08 --> Email Class Initialized
INFO - 2018-07-25 00:36:08 --> Controller Class Initialized
DEBUG - 2018-07-25 00:36:08 --> Home MX_Controller Initialized
DEBUG - 2018-07-25 00:36:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-25 00:36:08 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-25 00:36:08 --> Login MX_Controller Initialized
INFO - 2018-07-25 00:36:08 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-25 00:36:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-25 00:36:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-25 00:36:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-07-25 00:36:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-07-25 00:36:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-07-25 00:36:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-07-25 00:36:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-07-25 00:36:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-07-25 00:36:08 --> Final output sent to browser
DEBUG - 2018-07-25 00:36:08 --> Total execution time: 0.4752
INFO - 2018-07-25 00:36:08 --> Config Class Initialized
INFO - 2018-07-25 00:36:08 --> Config Class Initialized
INFO - 2018-07-25 00:36:08 --> Config Class Initialized
INFO - 2018-07-25 00:36:08 --> Hooks Class Initialized
INFO - 2018-07-25 00:36:08 --> Hooks Class Initialized
INFO - 2018-07-25 00:36:08 --> Hooks Class Initialized
DEBUG - 2018-07-25 00:36:08 --> UTF-8 Support Enabled
DEBUG - 2018-07-25 00:36:08 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:36:08 --> Utf8 Class Initialized
DEBUG - 2018-07-25 00:36:08 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:36:08 --> Utf8 Class Initialized
INFO - 2018-07-25 00:36:08 --> Utf8 Class Initialized
INFO - 2018-07-25 00:36:08 --> URI Class Initialized
INFO - 2018-07-25 00:36:08 --> URI Class Initialized
INFO - 2018-07-25 00:36:08 --> URI Class Initialized
INFO - 2018-07-25 00:36:08 --> Router Class Initialized
INFO - 2018-07-25 00:36:08 --> Router Class Initialized
INFO - 2018-07-25 00:36:08 --> Output Class Initialized
INFO - 2018-07-25 00:36:08 --> Output Class Initialized
INFO - 2018-07-25 00:36:08 --> Router Class Initialized
INFO - 2018-07-25 00:36:08 --> Security Class Initialized
INFO - 2018-07-25 00:36:08 --> Output Class Initialized
INFO - 2018-07-25 00:36:08 --> Security Class Initialized
INFO - 2018-07-25 00:36:08 --> Security Class Initialized
DEBUG - 2018-07-25 00:36:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:36:08 --> Input Class Initialized
DEBUG - 2018-07-25 00:36:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-07-25 00:36:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:36:09 --> Input Class Initialized
INFO - 2018-07-25 00:36:09 --> Language Class Initialized
INFO - 2018-07-25 00:36:09 --> Input Class Initialized
INFO - 2018-07-25 00:36:09 --> Language Class Initialized
ERROR - 2018-07-25 00:36:09 --> 404 Page Not Found: /index
ERROR - 2018-07-25 00:36:09 --> 404 Page Not Found: /index
INFO - 2018-07-25 00:36:09 --> Config Class Initialized
INFO - 2018-07-25 00:36:09 --> Language Class Initialized
ERROR - 2018-07-25 00:36:09 --> 404 Page Not Found: /index
INFO - 2018-07-25 00:36:09 --> Hooks Class Initialized
DEBUG - 2018-07-25 00:36:09 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:36:09 --> Utf8 Class Initialized
INFO - 2018-07-25 00:36:09 --> URI Class Initialized
INFO - 2018-07-25 00:36:09 --> Router Class Initialized
INFO - 2018-07-25 00:36:09 --> Output Class Initialized
INFO - 2018-07-25 00:36:09 --> Security Class Initialized
DEBUG - 2018-07-25 00:36:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:36:09 --> Input Class Initialized
INFO - 2018-07-25 00:36:09 --> Language Class Initialized
ERROR - 2018-07-25 00:36:09 --> 404 Page Not Found: /index
INFO - 2018-07-25 00:36:09 --> Config Class Initialized
INFO - 2018-07-25 00:36:09 --> Hooks Class Initialized
DEBUG - 2018-07-25 00:36:09 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:36:09 --> Utf8 Class Initialized
INFO - 2018-07-25 00:36:09 --> URI Class Initialized
INFO - 2018-07-25 00:36:09 --> Router Class Initialized
INFO - 2018-07-25 00:36:09 --> Output Class Initialized
INFO - 2018-07-25 00:36:09 --> Security Class Initialized
DEBUG - 2018-07-25 00:36:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:36:09 --> Input Class Initialized
INFO - 2018-07-25 00:36:09 --> Language Class Initialized
ERROR - 2018-07-25 00:36:09 --> 404 Page Not Found: /index
INFO - 2018-07-25 00:36:09 --> Config Class Initialized
INFO - 2018-07-25 00:36:09 --> Hooks Class Initialized
DEBUG - 2018-07-25 00:36:09 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:36:09 --> Utf8 Class Initialized
INFO - 2018-07-25 00:36:09 --> URI Class Initialized
INFO - 2018-07-25 00:36:09 --> Router Class Initialized
INFO - 2018-07-25 00:36:09 --> Output Class Initialized
INFO - 2018-07-25 00:36:09 --> Security Class Initialized
DEBUG - 2018-07-25 00:36:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:36:09 --> Input Class Initialized
INFO - 2018-07-25 00:36:09 --> Language Class Initialized
ERROR - 2018-07-25 00:36:09 --> 404 Page Not Found: /index
INFO - 2018-07-25 00:36:09 --> Config Class Initialized
INFO - 2018-07-25 00:36:09 --> Hooks Class Initialized
DEBUG - 2018-07-25 00:36:09 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:36:09 --> Utf8 Class Initialized
INFO - 2018-07-25 00:36:09 --> URI Class Initialized
INFO - 2018-07-25 00:36:09 --> Router Class Initialized
INFO - 2018-07-25 00:36:09 --> Output Class Initialized
INFO - 2018-07-25 00:36:09 --> Security Class Initialized
DEBUG - 2018-07-25 00:36:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:36:09 --> Input Class Initialized
INFO - 2018-07-25 00:36:09 --> Language Class Initialized
ERROR - 2018-07-25 00:36:09 --> 404 Page Not Found: /index
INFO - 2018-07-25 00:36:09 --> Config Class Initialized
INFO - 2018-07-25 00:36:09 --> Hooks Class Initialized
DEBUG - 2018-07-25 00:36:09 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:36:09 --> Utf8 Class Initialized
INFO - 2018-07-25 00:36:09 --> URI Class Initialized
INFO - 2018-07-25 00:36:09 --> Router Class Initialized
INFO - 2018-07-25 00:36:09 --> Output Class Initialized
INFO - 2018-07-25 00:36:09 --> Security Class Initialized
DEBUG - 2018-07-25 00:36:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:36:09 --> Input Class Initialized
INFO - 2018-07-25 00:36:09 --> Language Class Initialized
ERROR - 2018-07-25 00:36:09 --> 404 Page Not Found: /index
INFO - 2018-07-25 00:36:09 --> Config Class Initialized
INFO - 2018-07-25 00:36:10 --> Hooks Class Initialized
DEBUG - 2018-07-25 00:36:10 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:36:10 --> Utf8 Class Initialized
INFO - 2018-07-25 00:36:10 --> URI Class Initialized
INFO - 2018-07-25 00:36:10 --> Router Class Initialized
INFO - 2018-07-25 00:36:10 --> Output Class Initialized
INFO - 2018-07-25 00:36:10 --> Security Class Initialized
DEBUG - 2018-07-25 00:36:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:36:10 --> Input Class Initialized
INFO - 2018-07-25 00:36:10 --> Language Class Initialized
ERROR - 2018-07-25 00:36:10 --> 404 Page Not Found: /index
INFO - 2018-07-25 00:36:17 --> Config Class Initialized
INFO - 2018-07-25 00:36:17 --> Hooks Class Initialized
DEBUG - 2018-07-25 00:36:17 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:36:17 --> Utf8 Class Initialized
INFO - 2018-07-25 00:36:17 --> URI Class Initialized
DEBUG - 2018-07-25 00:36:17 --> No URI present. Default controller set.
INFO - 2018-07-25 00:36:17 --> Router Class Initialized
INFO - 2018-07-25 00:36:17 --> Output Class Initialized
INFO - 2018-07-25 00:36:17 --> Security Class Initialized
DEBUG - 2018-07-25 00:36:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:36:17 --> Input Class Initialized
INFO - 2018-07-25 00:36:17 --> Language Class Initialized
INFO - 2018-07-25 00:36:17 --> Language Class Initialized
INFO - 2018-07-25 00:36:17 --> Config Class Initialized
INFO - 2018-07-25 00:36:17 --> Loader Class Initialized
DEBUG - 2018-07-25 00:36:17 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-25 00:36:17 --> Helper loaded: url_helper
INFO - 2018-07-25 00:36:17 --> Helper loaded: form_helper
INFO - 2018-07-25 00:36:17 --> Helper loaded: date_helper
INFO - 2018-07-25 00:36:17 --> Helper loaded: util_helper
INFO - 2018-07-25 00:36:17 --> Helper loaded: text_helper
INFO - 2018-07-25 00:36:17 --> Helper loaded: string_helper
INFO - 2018-07-25 00:36:17 --> Database Driver Class Initialized
DEBUG - 2018-07-25 00:36:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 00:36:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 00:36:17 --> Email Class Initialized
INFO - 2018-07-25 00:36:17 --> Controller Class Initialized
DEBUG - 2018-07-25 00:36:17 --> Home MX_Controller Initialized
DEBUG - 2018-07-25 00:36:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-25 00:36:17 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-25 00:36:17 --> Login MX_Controller Initialized
INFO - 2018-07-25 00:36:17 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-25 00:36:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-25 00:36:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-25 00:36:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-07-25 00:36:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-07-25 00:36:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-07-25 00:36:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-07-25 00:36:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-07-25 00:36:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-07-25 00:36:17 --> Final output sent to browser
DEBUG - 2018-07-25 00:36:17 --> Total execution time: 0.4697
INFO - 2018-07-25 00:36:17 --> Config Class Initialized
INFO - 2018-07-25 00:36:17 --> Config Class Initialized
INFO - 2018-07-25 00:36:17 --> Config Class Initialized
INFO - 2018-07-25 00:36:17 --> Hooks Class Initialized
INFO - 2018-07-25 00:36:17 --> Hooks Class Initialized
INFO - 2018-07-25 00:36:17 --> Hooks Class Initialized
DEBUG - 2018-07-25 00:36:18 --> UTF-8 Support Enabled
DEBUG - 2018-07-25 00:36:18 --> UTF-8 Support Enabled
DEBUG - 2018-07-25 00:36:18 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:36:18 --> Utf8 Class Initialized
INFO - 2018-07-25 00:36:18 --> Utf8 Class Initialized
INFO - 2018-07-25 00:36:18 --> Utf8 Class Initialized
INFO - 2018-07-25 00:36:18 --> URI Class Initialized
INFO - 2018-07-25 00:36:18 --> URI Class Initialized
INFO - 2018-07-25 00:36:18 --> URI Class Initialized
INFO - 2018-07-25 00:36:18 --> Router Class Initialized
INFO - 2018-07-25 00:36:18 --> Router Class Initialized
INFO - 2018-07-25 00:36:18 --> Router Class Initialized
INFO - 2018-07-25 00:36:18 --> Output Class Initialized
INFO - 2018-07-25 00:36:18 --> Output Class Initialized
INFO - 2018-07-25 00:36:18 --> Output Class Initialized
INFO - 2018-07-25 00:36:18 --> Security Class Initialized
INFO - 2018-07-25 00:36:18 --> Config Class Initialized
DEBUG - 2018-07-25 00:36:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:36:18 --> Security Class Initialized
INFO - 2018-07-25 00:36:18 --> Security Class Initialized
INFO - 2018-07-25 00:36:18 --> Hooks Class Initialized
DEBUG - 2018-07-25 00:36:18 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:36:18 --> Utf8 Class Initialized
INFO - 2018-07-25 00:36:18 --> Input Class Initialized
INFO - 2018-07-25 00:36:18 --> URI Class Initialized
DEBUG - 2018-07-25 00:36:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-07-25 00:36:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:36:18 --> Router Class Initialized
INFO - 2018-07-25 00:36:18 --> Language Class Initialized
INFO - 2018-07-25 00:36:18 --> Output Class Initialized
INFO - 2018-07-25 00:36:18 --> Security Class Initialized
DEBUG - 2018-07-25 00:36:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:36:18 --> Input Class Initialized
INFO - 2018-07-25 00:36:18 --> Language Class Initialized
ERROR - 2018-07-25 00:36:18 --> 404 Page Not Found: /index
INFO - 2018-07-25 00:36:18 --> Input Class Initialized
INFO - 2018-07-25 00:36:18 --> Input Class Initialized
INFO - 2018-07-25 00:36:18 --> Language Class Initialized
INFO - 2018-07-25 00:36:18 --> Language Class Initialized
ERROR - 2018-07-25 00:36:18 --> 404 Page Not Found: /index
ERROR - 2018-07-25 00:36:18 --> 404 Page Not Found: /index
ERROR - 2018-07-25 00:36:18 --> 404 Page Not Found: /index
INFO - 2018-07-25 00:36:18 --> Config Class Initialized
INFO - 2018-07-25 00:36:18 --> Hooks Class Initialized
DEBUG - 2018-07-25 00:36:18 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:36:18 --> Utf8 Class Initialized
INFO - 2018-07-25 00:36:18 --> URI Class Initialized
INFO - 2018-07-25 00:36:18 --> Router Class Initialized
INFO - 2018-07-25 00:36:18 --> Output Class Initialized
INFO - 2018-07-25 00:36:18 --> Security Class Initialized
DEBUG - 2018-07-25 00:36:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:36:18 --> Input Class Initialized
INFO - 2018-07-25 00:36:18 --> Language Class Initialized
ERROR - 2018-07-25 00:36:18 --> 404 Page Not Found: /index
INFO - 2018-07-25 00:36:18 --> Config Class Initialized
INFO - 2018-07-25 00:36:18 --> Hooks Class Initialized
DEBUG - 2018-07-25 00:36:18 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:36:18 --> Utf8 Class Initialized
INFO - 2018-07-25 00:36:18 --> URI Class Initialized
INFO - 2018-07-25 00:36:18 --> Router Class Initialized
INFO - 2018-07-25 00:36:18 --> Output Class Initialized
INFO - 2018-07-25 00:36:18 --> Security Class Initialized
DEBUG - 2018-07-25 00:36:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:36:18 --> Input Class Initialized
INFO - 2018-07-25 00:36:18 --> Language Class Initialized
ERROR - 2018-07-25 00:36:18 --> 404 Page Not Found: /index
INFO - 2018-07-25 00:36:18 --> Config Class Initialized
INFO - 2018-07-25 00:36:18 --> Hooks Class Initialized
DEBUG - 2018-07-25 00:36:18 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:36:18 --> Utf8 Class Initialized
INFO - 2018-07-25 00:36:18 --> URI Class Initialized
INFO - 2018-07-25 00:36:18 --> Router Class Initialized
INFO - 2018-07-25 00:36:18 --> Output Class Initialized
INFO - 2018-07-25 00:36:18 --> Security Class Initialized
DEBUG - 2018-07-25 00:36:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:36:18 --> Input Class Initialized
INFO - 2018-07-25 00:36:18 --> Language Class Initialized
ERROR - 2018-07-25 00:36:18 --> 404 Page Not Found: /index
INFO - 2018-07-25 00:36:19 --> Config Class Initialized
INFO - 2018-07-25 00:36:19 --> Hooks Class Initialized
DEBUG - 2018-07-25 00:36:19 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:36:19 --> Utf8 Class Initialized
INFO - 2018-07-25 00:36:19 --> URI Class Initialized
INFO - 2018-07-25 00:36:19 --> Router Class Initialized
INFO - 2018-07-25 00:36:19 --> Output Class Initialized
INFO - 2018-07-25 00:36:19 --> Security Class Initialized
DEBUG - 2018-07-25 00:36:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:36:19 --> Input Class Initialized
INFO - 2018-07-25 00:36:19 --> Language Class Initialized
ERROR - 2018-07-25 00:36:19 --> 404 Page Not Found: /index
INFO - 2018-07-25 00:36:19 --> Config Class Initialized
INFO - 2018-07-25 00:36:19 --> Hooks Class Initialized
DEBUG - 2018-07-25 00:36:19 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:36:19 --> Utf8 Class Initialized
INFO - 2018-07-25 00:36:19 --> URI Class Initialized
INFO - 2018-07-25 00:36:19 --> Router Class Initialized
INFO - 2018-07-25 00:36:19 --> Output Class Initialized
INFO - 2018-07-25 00:36:19 --> Security Class Initialized
DEBUG - 2018-07-25 00:36:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:36:19 --> Input Class Initialized
INFO - 2018-07-25 00:36:19 --> Language Class Initialized
ERROR - 2018-07-25 00:36:19 --> 404 Page Not Found: /index
INFO - 2018-07-25 00:36:21 --> Config Class Initialized
INFO - 2018-07-25 00:36:21 --> Hooks Class Initialized
DEBUG - 2018-07-25 00:36:21 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:36:21 --> Utf8 Class Initialized
INFO - 2018-07-25 00:36:21 --> URI Class Initialized
INFO - 2018-07-25 00:36:21 --> Router Class Initialized
INFO - 2018-07-25 00:36:21 --> Output Class Initialized
INFO - 2018-07-25 00:36:21 --> Security Class Initialized
DEBUG - 2018-07-25 00:36:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:36:21 --> Input Class Initialized
INFO - 2018-07-25 00:36:21 --> Language Class Initialized
INFO - 2018-07-25 00:36:21 --> Language Class Initialized
INFO - 2018-07-25 00:36:21 --> Config Class Initialized
INFO - 2018-07-25 00:36:21 --> Loader Class Initialized
DEBUG - 2018-07-25 00:36:21 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-25 00:36:21 --> Helper loaded: url_helper
INFO - 2018-07-25 00:36:21 --> Helper loaded: form_helper
INFO - 2018-07-25 00:36:21 --> Helper loaded: date_helper
INFO - 2018-07-25 00:36:21 --> Helper loaded: util_helper
INFO - 2018-07-25 00:36:21 --> Helper loaded: text_helper
INFO - 2018-07-25 00:36:21 --> Helper loaded: string_helper
INFO - 2018-07-25 00:36:21 --> Database Driver Class Initialized
DEBUG - 2018-07-25 00:36:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 00:36:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 00:36:21 --> Email Class Initialized
INFO - 2018-07-25 00:36:21 --> Controller Class Initialized
DEBUG - 2018-07-25 00:36:21 --> Home MX_Controller Initialized
DEBUG - 2018-07-25 00:36:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-25 00:36:21 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-25 00:36:21 --> Login MX_Controller Initialized
INFO - 2018-07-25 00:36:21 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-25 00:36:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-25 00:36:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-25 00:36:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-07-25 00:36:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-07-25 00:36:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-07-25 00:36:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-07-25 00:36:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-07-25 00:36:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-07-25 00:36:21 --> Final output sent to browser
DEBUG - 2018-07-25 00:36:21 --> Total execution time: 0.4757
INFO - 2018-07-25 00:36:22 --> Config Class Initialized
INFO - 2018-07-25 00:36:22 --> Config Class Initialized
INFO - 2018-07-25 00:36:22 --> Hooks Class Initialized
INFO - 2018-07-25 00:36:22 --> Hooks Class Initialized
DEBUG - 2018-07-25 00:36:22 --> UTF-8 Support Enabled
DEBUG - 2018-07-25 00:36:22 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:36:22 --> Utf8 Class Initialized
INFO - 2018-07-25 00:36:22 --> Utf8 Class Initialized
INFO - 2018-07-25 00:36:22 --> URI Class Initialized
INFO - 2018-07-25 00:36:22 --> URI Class Initialized
INFO - 2018-07-25 00:36:22 --> Router Class Initialized
INFO - 2018-07-25 00:36:22 --> Output Class Initialized
INFO - 2018-07-25 00:36:22 --> Security Class Initialized
INFO - 2018-07-25 00:36:22 --> Router Class Initialized
DEBUG - 2018-07-25 00:36:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:36:22 --> Output Class Initialized
INFO - 2018-07-25 00:36:22 --> Input Class Initialized
INFO - 2018-07-25 00:36:22 --> Language Class Initialized
ERROR - 2018-07-25 00:36:22 --> 404 Page Not Found: /index
INFO - 2018-07-25 00:36:22 --> Config Class Initialized
INFO - 2018-07-25 00:36:22 --> Hooks Class Initialized
DEBUG - 2018-07-25 00:36:22 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:36:22 --> Utf8 Class Initialized
INFO - 2018-07-25 00:36:22 --> URI Class Initialized
INFO - 2018-07-25 00:36:22 --> Router Class Initialized
INFO - 2018-07-25 00:36:22 --> Security Class Initialized
INFO - 2018-07-25 00:36:22 --> Output Class Initialized
DEBUG - 2018-07-25 00:36:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:36:22 --> Security Class Initialized
INFO - 2018-07-25 00:36:22 --> Input Class Initialized
INFO - 2018-07-25 00:36:22 --> Language Class Initialized
DEBUG - 2018-07-25 00:36:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-07-25 00:36:22 --> 404 Page Not Found: /index
INFO - 2018-07-25 00:36:22 --> Input Class Initialized
INFO - 2018-07-25 00:36:22 --> Language Class Initialized
ERROR - 2018-07-25 00:36:22 --> 404 Page Not Found: /index
INFO - 2018-07-25 00:36:22 --> Config Class Initialized
INFO - 2018-07-25 00:36:22 --> Hooks Class Initialized
DEBUG - 2018-07-25 00:36:22 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:36:22 --> Utf8 Class Initialized
INFO - 2018-07-25 00:36:22 --> URI Class Initialized
INFO - 2018-07-25 00:36:22 --> Router Class Initialized
INFO - 2018-07-25 00:36:22 --> Output Class Initialized
INFO - 2018-07-25 00:36:22 --> Security Class Initialized
DEBUG - 2018-07-25 00:36:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:36:22 --> Input Class Initialized
INFO - 2018-07-25 00:36:22 --> Language Class Initialized
ERROR - 2018-07-25 00:36:22 --> 404 Page Not Found: /index
INFO - 2018-07-25 00:37:03 --> Config Class Initialized
INFO - 2018-07-25 00:37:03 --> Hooks Class Initialized
DEBUG - 2018-07-25 00:37:03 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:37:03 --> Utf8 Class Initialized
INFO - 2018-07-25 00:37:03 --> URI Class Initialized
DEBUG - 2018-07-25 00:37:03 --> No URI present. Default controller set.
INFO - 2018-07-25 00:37:03 --> Router Class Initialized
INFO - 2018-07-25 00:37:03 --> Output Class Initialized
INFO - 2018-07-25 00:37:03 --> Security Class Initialized
DEBUG - 2018-07-25 00:37:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:37:03 --> Input Class Initialized
INFO - 2018-07-25 00:37:03 --> Language Class Initialized
INFO - 2018-07-25 00:37:03 --> Language Class Initialized
INFO - 2018-07-25 00:37:03 --> Config Class Initialized
INFO - 2018-07-25 00:37:03 --> Loader Class Initialized
DEBUG - 2018-07-25 00:37:03 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-25 00:37:03 --> Helper loaded: url_helper
INFO - 2018-07-25 00:37:03 --> Helper loaded: form_helper
INFO - 2018-07-25 00:37:03 --> Helper loaded: date_helper
INFO - 2018-07-25 00:37:03 --> Helper loaded: util_helper
INFO - 2018-07-25 00:37:03 --> Helper loaded: text_helper
INFO - 2018-07-25 00:37:03 --> Helper loaded: string_helper
INFO - 2018-07-25 00:37:03 --> Database Driver Class Initialized
DEBUG - 2018-07-25 00:37:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 00:37:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 00:37:03 --> Email Class Initialized
INFO - 2018-07-25 00:37:03 --> Controller Class Initialized
DEBUG - 2018-07-25 00:37:03 --> Home MX_Controller Initialized
DEBUG - 2018-07-25 00:37:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-25 00:37:03 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-25 00:37:03 --> Login MX_Controller Initialized
INFO - 2018-07-25 00:37:03 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-25 00:37:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-25 00:37:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-25 00:37:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-07-25 00:37:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-07-25 00:37:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-07-25 00:37:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-07-25 00:37:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-07-25 00:37:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-07-25 00:37:03 --> Final output sent to browser
DEBUG - 2018-07-25 00:37:03 --> Total execution time: 0.4939
INFO - 2018-07-25 00:45:32 --> Config Class Initialized
INFO - 2018-07-25 00:45:32 --> Hooks Class Initialized
DEBUG - 2018-07-25 00:45:32 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:45:32 --> Utf8 Class Initialized
INFO - 2018-07-25 00:45:32 --> URI Class Initialized
DEBUG - 2018-07-25 00:45:32 --> No URI present. Default controller set.
INFO - 2018-07-25 00:45:32 --> Router Class Initialized
INFO - 2018-07-25 00:45:32 --> Output Class Initialized
INFO - 2018-07-25 00:45:32 --> Security Class Initialized
DEBUG - 2018-07-25 00:45:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:45:32 --> Input Class Initialized
INFO - 2018-07-25 00:45:32 --> Language Class Initialized
INFO - 2018-07-25 00:45:32 --> Language Class Initialized
INFO - 2018-07-25 00:45:32 --> Config Class Initialized
INFO - 2018-07-25 00:45:32 --> Loader Class Initialized
DEBUG - 2018-07-25 00:45:32 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-25 00:45:32 --> Helper loaded: url_helper
INFO - 2018-07-25 00:45:32 --> Helper loaded: form_helper
INFO - 2018-07-25 00:45:32 --> Helper loaded: date_helper
INFO - 2018-07-25 00:45:32 --> Helper loaded: util_helper
INFO - 2018-07-25 00:45:32 --> Helper loaded: text_helper
INFO - 2018-07-25 00:45:32 --> Helper loaded: string_helper
INFO - 2018-07-25 00:45:32 --> Database Driver Class Initialized
DEBUG - 2018-07-25 00:45:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 00:45:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 00:45:32 --> Email Class Initialized
INFO - 2018-07-25 00:45:32 --> Controller Class Initialized
DEBUG - 2018-07-25 00:45:32 --> Home MX_Controller Initialized
DEBUG - 2018-07-25 00:45:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-25 00:45:32 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-25 00:45:32 --> Login MX_Controller Initialized
INFO - 2018-07-25 00:45:32 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-25 00:45:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-25 00:45:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-25 00:45:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-07-25 00:45:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-07-25 00:45:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-07-25 00:45:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-07-25 00:45:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-07-25 00:45:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-07-25 00:45:32 --> Final output sent to browser
DEBUG - 2018-07-25 00:45:32 --> Total execution time: 0.4944
INFO - 2018-07-25 00:45:33 --> Config Class Initialized
INFO - 2018-07-25 00:45:33 --> Config Class Initialized
INFO - 2018-07-25 00:45:33 --> Config Class Initialized
INFO - 2018-07-25 00:45:33 --> Hooks Class Initialized
INFO - 2018-07-25 00:45:33 --> Hooks Class Initialized
INFO - 2018-07-25 00:45:33 --> Hooks Class Initialized
DEBUG - 2018-07-25 00:45:33 --> UTF-8 Support Enabled
DEBUG - 2018-07-25 00:45:33 --> UTF-8 Support Enabled
DEBUG - 2018-07-25 00:45:33 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:45:33 --> Utf8 Class Initialized
INFO - 2018-07-25 00:45:33 --> Utf8 Class Initialized
INFO - 2018-07-25 00:45:33 --> Utf8 Class Initialized
INFO - 2018-07-25 00:45:33 --> URI Class Initialized
INFO - 2018-07-25 00:45:33 --> URI Class Initialized
INFO - 2018-07-25 00:45:33 --> URI Class Initialized
INFO - 2018-07-25 00:45:33 --> Router Class Initialized
INFO - 2018-07-25 00:45:33 --> Router Class Initialized
INFO - 2018-07-25 00:45:33 --> Router Class Initialized
INFO - 2018-07-25 00:45:33 --> Output Class Initialized
INFO - 2018-07-25 00:45:33 --> Output Class Initialized
INFO - 2018-07-25 00:45:33 --> Output Class Initialized
INFO - 2018-07-25 00:45:33 --> Security Class Initialized
INFO - 2018-07-25 00:45:33 --> Security Class Initialized
INFO - 2018-07-25 00:45:33 --> Security Class Initialized
DEBUG - 2018-07-25 00:45:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-07-25 00:45:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-07-25 00:45:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:45:33 --> Input Class Initialized
INFO - 2018-07-25 00:45:33 --> Input Class Initialized
INFO - 2018-07-25 00:45:33 --> Input Class Initialized
INFO - 2018-07-25 00:45:33 --> Language Class Initialized
INFO - 2018-07-25 00:45:33 --> Language Class Initialized
INFO - 2018-07-25 00:45:33 --> Language Class Initialized
ERROR - 2018-07-25 00:45:33 --> 404 Page Not Found: /index
ERROR - 2018-07-25 00:45:33 --> 404 Page Not Found: /index
ERROR - 2018-07-25 00:45:33 --> 404 Page Not Found: /index
INFO - 2018-07-25 00:45:36 --> Config Class Initialized
INFO - 2018-07-25 00:45:36 --> Hooks Class Initialized
DEBUG - 2018-07-25 00:45:36 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:45:36 --> Utf8 Class Initialized
INFO - 2018-07-25 00:45:36 --> URI Class Initialized
INFO - 2018-07-25 00:45:36 --> Router Class Initialized
INFO - 2018-07-25 00:45:36 --> Output Class Initialized
INFO - 2018-07-25 00:45:36 --> Security Class Initialized
DEBUG - 2018-07-25 00:45:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:45:36 --> Input Class Initialized
INFO - 2018-07-25 00:45:36 --> Language Class Initialized
ERROR - 2018-07-25 00:45:36 --> 404 Page Not Found: /index
INFO - 2018-07-25 00:45:36 --> Config Class Initialized
INFO - 2018-07-25 00:45:36 --> Hooks Class Initialized
DEBUG - 2018-07-25 00:45:36 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:45:36 --> Utf8 Class Initialized
INFO - 2018-07-25 00:45:36 --> URI Class Initialized
INFO - 2018-07-25 00:45:37 --> Router Class Initialized
INFO - 2018-07-25 00:45:37 --> Output Class Initialized
INFO - 2018-07-25 00:45:37 --> Security Class Initialized
DEBUG - 2018-07-25 00:45:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:45:37 --> Input Class Initialized
INFO - 2018-07-25 00:45:37 --> Language Class Initialized
ERROR - 2018-07-25 00:45:37 --> 404 Page Not Found: /index
INFO - 2018-07-25 00:45:37 --> Config Class Initialized
INFO - 2018-07-25 00:45:37 --> Hooks Class Initialized
DEBUG - 2018-07-25 00:45:37 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:45:37 --> Utf8 Class Initialized
INFO - 2018-07-25 00:45:37 --> URI Class Initialized
INFO - 2018-07-25 00:45:37 --> Router Class Initialized
INFO - 2018-07-25 00:45:37 --> Output Class Initialized
INFO - 2018-07-25 00:45:37 --> Security Class Initialized
DEBUG - 2018-07-25 00:45:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:45:37 --> Input Class Initialized
INFO - 2018-07-25 00:45:37 --> Language Class Initialized
ERROR - 2018-07-25 00:45:37 --> 404 Page Not Found: /index
INFO - 2018-07-25 00:45:37 --> Config Class Initialized
INFO - 2018-07-25 00:45:37 --> Hooks Class Initialized
DEBUG - 2018-07-25 00:45:37 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:45:37 --> Utf8 Class Initialized
INFO - 2018-07-25 00:45:37 --> URI Class Initialized
INFO - 2018-07-25 00:45:37 --> Router Class Initialized
INFO - 2018-07-25 00:45:37 --> Output Class Initialized
INFO - 2018-07-25 00:45:37 --> Security Class Initialized
DEBUG - 2018-07-25 00:45:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:45:37 --> Input Class Initialized
INFO - 2018-07-25 00:45:37 --> Language Class Initialized
ERROR - 2018-07-25 00:45:37 --> 404 Page Not Found: /index
INFO - 2018-07-25 00:45:37 --> Config Class Initialized
INFO - 2018-07-25 00:45:37 --> Hooks Class Initialized
DEBUG - 2018-07-25 00:45:37 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:45:37 --> Utf8 Class Initialized
INFO - 2018-07-25 00:45:37 --> URI Class Initialized
INFO - 2018-07-25 00:45:37 --> Router Class Initialized
INFO - 2018-07-25 00:45:37 --> Output Class Initialized
INFO - 2018-07-25 00:45:37 --> Security Class Initialized
DEBUG - 2018-07-25 00:45:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:45:37 --> Input Class Initialized
INFO - 2018-07-25 00:45:37 --> Language Class Initialized
ERROR - 2018-07-25 00:45:37 --> 404 Page Not Found: /index
INFO - 2018-07-25 00:45:37 --> Config Class Initialized
INFO - 2018-07-25 00:45:37 --> Hooks Class Initialized
DEBUG - 2018-07-25 00:45:37 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:45:37 --> Utf8 Class Initialized
INFO - 2018-07-25 00:45:37 --> URI Class Initialized
INFO - 2018-07-25 00:45:37 --> Router Class Initialized
INFO - 2018-07-25 00:45:37 --> Output Class Initialized
INFO - 2018-07-25 00:45:37 --> Security Class Initialized
DEBUG - 2018-07-25 00:45:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:45:37 --> Input Class Initialized
INFO - 2018-07-25 00:45:37 --> Language Class Initialized
ERROR - 2018-07-25 00:45:37 --> 404 Page Not Found: /index
INFO - 2018-07-25 00:45:45 --> Config Class Initialized
INFO - 2018-07-25 00:45:45 --> Hooks Class Initialized
DEBUG - 2018-07-25 00:45:45 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:45:45 --> Utf8 Class Initialized
INFO - 2018-07-25 00:45:45 --> URI Class Initialized
INFO - 2018-07-25 00:45:45 --> Router Class Initialized
INFO - 2018-07-25 00:45:45 --> Output Class Initialized
INFO - 2018-07-25 00:45:45 --> Security Class Initialized
DEBUG - 2018-07-25 00:45:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:45:45 --> Input Class Initialized
INFO - 2018-07-25 00:45:45 --> Language Class Initialized
INFO - 2018-07-25 00:45:45 --> Language Class Initialized
INFO - 2018-07-25 00:45:45 --> Config Class Initialized
INFO - 2018-07-25 00:45:45 --> Loader Class Initialized
DEBUG - 2018-07-25 00:45:45 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-25 00:45:45 --> Helper loaded: url_helper
INFO - 2018-07-25 00:45:45 --> Helper loaded: form_helper
INFO - 2018-07-25 00:45:45 --> Helper loaded: date_helper
INFO - 2018-07-25 00:45:45 --> Helper loaded: util_helper
INFO - 2018-07-25 00:45:45 --> Helper loaded: text_helper
INFO - 2018-07-25 00:45:45 --> Helper loaded: string_helper
INFO - 2018-07-25 00:45:45 --> Database Driver Class Initialized
DEBUG - 2018-07-25 00:45:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 00:45:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 00:45:45 --> Email Class Initialized
INFO - 2018-07-25 00:45:45 --> Controller Class Initialized
DEBUG - 2018-07-25 00:45:45 --> Home MX_Controller Initialized
DEBUG - 2018-07-25 00:45:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-25 00:45:45 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-25 00:45:45 --> Login MX_Controller Initialized
INFO - 2018-07-25 00:45:45 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-25 00:45:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-25 00:45:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-25 00:45:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-07-25 00:45:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-07-25 00:45:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-07-25 00:45:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-07-25 00:45:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-07-25 00:45:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-07-25 00:45:45 --> Final output sent to browser
DEBUG - 2018-07-25 00:45:45 --> Total execution time: 0.5137
INFO - 2018-07-25 00:45:46 --> Config Class Initialized
INFO - 2018-07-25 00:45:46 --> Hooks Class Initialized
INFO - 2018-07-25 00:45:46 --> Config Class Initialized
INFO - 2018-07-25 00:45:46 --> Hooks Class Initialized
DEBUG - 2018-07-25 00:45:46 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:45:46 --> Utf8 Class Initialized
DEBUG - 2018-07-25 00:45:46 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:45:46 --> Utf8 Class Initialized
INFO - 2018-07-25 00:45:46 --> URI Class Initialized
INFO - 2018-07-25 00:45:46 --> URI Class Initialized
INFO - 2018-07-25 00:45:46 --> Router Class Initialized
INFO - 2018-07-25 00:45:46 --> Output Class Initialized
INFO - 2018-07-25 00:45:46 --> Security Class Initialized
DEBUG - 2018-07-25 00:45:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:45:46 --> Router Class Initialized
INFO - 2018-07-25 00:45:46 --> Output Class Initialized
INFO - 2018-07-25 00:45:46 --> Input Class Initialized
INFO - 2018-07-25 00:45:46 --> Security Class Initialized
DEBUG - 2018-07-25 00:45:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:45:46 --> Input Class Initialized
INFO - 2018-07-25 00:45:46 --> Language Class Initialized
INFO - 2018-07-25 00:45:46 --> Language Class Initialized
ERROR - 2018-07-25 00:45:46 --> 404 Page Not Found: /index
ERROR - 2018-07-25 00:45:46 --> 404 Page Not Found: /index
INFO - 2018-07-25 00:45:46 --> Config Class Initialized
INFO - 2018-07-25 00:45:46 --> Hooks Class Initialized
DEBUG - 2018-07-25 00:45:46 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:45:46 --> Utf8 Class Initialized
INFO - 2018-07-25 00:45:46 --> URI Class Initialized
INFO - 2018-07-25 00:45:46 --> Router Class Initialized
INFO - 2018-07-25 00:45:46 --> Output Class Initialized
INFO - 2018-07-25 00:45:46 --> Security Class Initialized
DEBUG - 2018-07-25 00:45:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:45:46 --> Input Class Initialized
INFO - 2018-07-25 00:45:46 --> Language Class Initialized
ERROR - 2018-07-25 00:45:46 --> 404 Page Not Found: /index
INFO - 2018-07-25 00:45:46 --> Config Class Initialized
INFO - 2018-07-25 00:45:46 --> Hooks Class Initialized
DEBUG - 2018-07-25 00:45:46 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:45:46 --> Utf8 Class Initialized
INFO - 2018-07-25 00:45:46 --> URI Class Initialized
INFO - 2018-07-25 00:45:46 --> Router Class Initialized
INFO - 2018-07-25 00:45:47 --> Output Class Initialized
INFO - 2018-07-25 00:45:47 --> Security Class Initialized
DEBUG - 2018-07-25 00:45:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:45:47 --> Input Class Initialized
INFO - 2018-07-25 00:45:47 --> Language Class Initialized
ERROR - 2018-07-25 00:45:47 --> 404 Page Not Found: /index
INFO - 2018-07-25 00:45:52 --> Config Class Initialized
INFO - 2018-07-25 00:45:52 --> Hooks Class Initialized
DEBUG - 2018-07-25 00:45:52 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:45:52 --> Utf8 Class Initialized
INFO - 2018-07-25 00:45:52 --> URI Class Initialized
DEBUG - 2018-07-25 00:45:52 --> No URI present. Default controller set.
INFO - 2018-07-25 00:45:52 --> Router Class Initialized
INFO - 2018-07-25 00:45:52 --> Output Class Initialized
INFO - 2018-07-25 00:45:52 --> Security Class Initialized
DEBUG - 2018-07-25 00:45:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:45:52 --> Input Class Initialized
INFO - 2018-07-25 00:45:52 --> Language Class Initialized
INFO - 2018-07-25 00:45:52 --> Language Class Initialized
INFO - 2018-07-25 00:45:52 --> Config Class Initialized
INFO - 2018-07-25 00:45:52 --> Loader Class Initialized
DEBUG - 2018-07-25 00:45:52 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-25 00:45:52 --> Helper loaded: url_helper
INFO - 2018-07-25 00:45:52 --> Helper loaded: form_helper
INFO - 2018-07-25 00:45:52 --> Helper loaded: date_helper
INFO - 2018-07-25 00:45:52 --> Helper loaded: util_helper
INFO - 2018-07-25 00:45:52 --> Helper loaded: text_helper
INFO - 2018-07-25 00:45:52 --> Helper loaded: string_helper
INFO - 2018-07-25 00:45:52 --> Database Driver Class Initialized
DEBUG - 2018-07-25 00:45:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 00:45:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 00:45:52 --> Email Class Initialized
INFO - 2018-07-25 00:45:52 --> Controller Class Initialized
DEBUG - 2018-07-25 00:45:52 --> Home MX_Controller Initialized
DEBUG - 2018-07-25 00:45:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-25 00:45:52 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-25 00:45:52 --> Login MX_Controller Initialized
INFO - 2018-07-25 00:45:52 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-25 00:45:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-25 00:45:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-25 00:45:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-07-25 00:45:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-07-25 00:45:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-07-25 00:45:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-07-25 00:45:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-07-25 00:45:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-07-25 00:45:53 --> Final output sent to browser
DEBUG - 2018-07-25 00:45:53 --> Total execution time: 0.4852
INFO - 2018-07-25 00:45:53 --> Config Class Initialized
INFO - 2018-07-25 00:45:53 --> Hooks Class Initialized
DEBUG - 2018-07-25 00:45:53 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:45:53 --> Utf8 Class Initialized
INFO - 2018-07-25 00:45:53 --> URI Class Initialized
INFO - 2018-07-25 00:45:53 --> Router Class Initialized
INFO - 2018-07-25 00:45:53 --> Output Class Initialized
INFO - 2018-07-25 00:45:53 --> Security Class Initialized
DEBUG - 2018-07-25 00:45:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:45:53 --> Input Class Initialized
INFO - 2018-07-25 00:45:53 --> Language Class Initialized
ERROR - 2018-07-25 00:45:53 --> 404 Page Not Found: /index
INFO - 2018-07-25 00:45:53 --> Config Class Initialized
INFO - 2018-07-25 00:45:53 --> Hooks Class Initialized
INFO - 2018-07-25 00:45:53 --> Config Class Initialized
INFO - 2018-07-25 00:45:53 --> Hooks Class Initialized
DEBUG - 2018-07-25 00:45:53 --> UTF-8 Support Enabled
DEBUG - 2018-07-25 00:45:53 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:45:53 --> Utf8 Class Initialized
INFO - 2018-07-25 00:45:53 --> URI Class Initialized
INFO - 2018-07-25 00:45:53 --> Router Class Initialized
INFO - 2018-07-25 00:45:53 --> Utf8 Class Initialized
INFO - 2018-07-25 00:45:53 --> Output Class Initialized
INFO - 2018-07-25 00:45:53 --> URI Class Initialized
INFO - 2018-07-25 00:45:53 --> Security Class Initialized
INFO - 2018-07-25 00:45:53 --> Router Class Initialized
DEBUG - 2018-07-25 00:45:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:45:53 --> Input Class Initialized
INFO - 2018-07-25 00:45:53 --> Language Class Initialized
ERROR - 2018-07-25 00:45:53 --> 404 Page Not Found: /index
INFO - 2018-07-25 00:45:53 --> Config Class Initialized
INFO - 2018-07-25 00:45:53 --> Hooks Class Initialized
DEBUG - 2018-07-25 00:45:53 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:45:53 --> Output Class Initialized
INFO - 2018-07-25 00:45:53 --> Utf8 Class Initialized
INFO - 2018-07-25 00:45:53 --> URI Class Initialized
INFO - 2018-07-25 00:45:53 --> Router Class Initialized
INFO - 2018-07-25 00:45:53 --> Security Class Initialized
INFO - 2018-07-25 00:45:53 --> Output Class Initialized
INFO - 2018-07-25 00:45:53 --> Security Class Initialized
DEBUG - 2018-07-25 00:45:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:45:53 --> Input Class Initialized
INFO - 2018-07-25 00:45:53 --> Language Class Initialized
ERROR - 2018-07-25 00:45:53 --> 404 Page Not Found: /index
INFO - 2018-07-25 00:45:53 --> Config Class Initialized
INFO - 2018-07-25 00:45:53 --> Hooks Class Initialized
DEBUG - 2018-07-25 00:45:53 --> UTF-8 Support Enabled
DEBUG - 2018-07-25 00:45:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:45:53 --> Utf8 Class Initialized
INFO - 2018-07-25 00:45:53 --> URI Class Initialized
INFO - 2018-07-25 00:45:53 --> Input Class Initialized
INFO - 2018-07-25 00:45:53 --> Router Class Initialized
INFO - 2018-07-25 00:45:53 --> Output Class Initialized
INFO - 2018-07-25 00:45:53 --> Language Class Initialized
INFO - 2018-07-25 00:45:53 --> Security Class Initialized
ERROR - 2018-07-25 00:45:53 --> 404 Page Not Found: /index
DEBUG - 2018-07-25 00:45:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:45:53 --> Input Class Initialized
INFO - 2018-07-25 00:45:53 --> Language Class Initialized
ERROR - 2018-07-25 00:45:54 --> 404 Page Not Found: /index
INFO - 2018-07-25 00:45:54 --> Config Class Initialized
INFO - 2018-07-25 00:45:54 --> Hooks Class Initialized
DEBUG - 2018-07-25 00:45:54 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:45:54 --> Utf8 Class Initialized
INFO - 2018-07-25 00:45:54 --> URI Class Initialized
INFO - 2018-07-25 00:45:54 --> Router Class Initialized
INFO - 2018-07-25 00:45:54 --> Output Class Initialized
INFO - 2018-07-25 00:45:54 --> Security Class Initialized
DEBUG - 2018-07-25 00:45:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:45:54 --> Input Class Initialized
INFO - 2018-07-25 00:45:54 --> Language Class Initialized
ERROR - 2018-07-25 00:45:54 --> 404 Page Not Found: /index
INFO - 2018-07-25 00:47:05 --> Config Class Initialized
INFO - 2018-07-25 00:47:05 --> Hooks Class Initialized
DEBUG - 2018-07-25 00:47:05 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:47:05 --> Utf8 Class Initialized
INFO - 2018-07-25 00:47:05 --> URI Class Initialized
DEBUG - 2018-07-25 00:47:05 --> No URI present. Default controller set.
INFO - 2018-07-25 00:47:05 --> Router Class Initialized
INFO - 2018-07-25 00:47:05 --> Output Class Initialized
INFO - 2018-07-25 00:47:05 --> Security Class Initialized
DEBUG - 2018-07-25 00:47:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:47:05 --> Input Class Initialized
INFO - 2018-07-25 00:47:05 --> Language Class Initialized
INFO - 2018-07-25 00:47:05 --> Language Class Initialized
INFO - 2018-07-25 00:47:05 --> Config Class Initialized
INFO - 2018-07-25 00:47:05 --> Loader Class Initialized
DEBUG - 2018-07-25 00:47:05 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-25 00:47:05 --> Helper loaded: url_helper
INFO - 2018-07-25 00:47:05 --> Helper loaded: form_helper
INFO - 2018-07-25 00:47:05 --> Helper loaded: date_helper
INFO - 2018-07-25 00:47:05 --> Helper loaded: util_helper
INFO - 2018-07-25 00:47:05 --> Helper loaded: text_helper
INFO - 2018-07-25 00:47:05 --> Helper loaded: string_helper
INFO - 2018-07-25 00:47:05 --> Database Driver Class Initialized
DEBUG - 2018-07-25 00:47:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 00:47:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 00:47:05 --> Email Class Initialized
INFO - 2018-07-25 00:47:05 --> Controller Class Initialized
DEBUG - 2018-07-25 00:47:05 --> Home MX_Controller Initialized
DEBUG - 2018-07-25 00:47:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-25 00:47:05 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-25 00:47:05 --> Login MX_Controller Initialized
INFO - 2018-07-25 00:47:05 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-25 00:47:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-25 00:47:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-25 00:47:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-07-25 00:47:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-07-25 00:47:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-07-25 00:47:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-07-25 00:47:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-07-25 00:47:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-07-25 00:47:05 --> Final output sent to browser
DEBUG - 2018-07-25 00:47:05 --> Total execution time: 0.5122
INFO - 2018-07-25 00:47:05 --> Config Class Initialized
INFO - 2018-07-25 00:47:05 --> Config Class Initialized
INFO - 2018-07-25 00:47:05 --> Config Class Initialized
INFO - 2018-07-25 00:47:06 --> Hooks Class Initialized
INFO - 2018-07-25 00:47:06 --> Hooks Class Initialized
INFO - 2018-07-25 00:47:06 --> Hooks Class Initialized
DEBUG - 2018-07-25 00:47:06 --> UTF-8 Support Enabled
DEBUG - 2018-07-25 00:47:06 --> UTF-8 Support Enabled
DEBUG - 2018-07-25 00:47:06 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:47:06 --> Utf8 Class Initialized
INFO - 2018-07-25 00:47:06 --> Utf8 Class Initialized
INFO - 2018-07-25 00:47:06 --> Utf8 Class Initialized
INFO - 2018-07-25 00:47:06 --> URI Class Initialized
INFO - 2018-07-25 00:47:06 --> URI Class Initialized
INFO - 2018-07-25 00:47:06 --> URI Class Initialized
INFO - 2018-07-25 00:47:06 --> Router Class Initialized
INFO - 2018-07-25 00:47:06 --> Router Class Initialized
INFO - 2018-07-25 00:47:06 --> Output Class Initialized
INFO - 2018-07-25 00:47:06 --> Router Class Initialized
INFO - 2018-07-25 00:47:06 --> Output Class Initialized
INFO - 2018-07-25 00:47:06 --> Output Class Initialized
INFO - 2018-07-25 00:47:06 --> Security Class Initialized
INFO - 2018-07-25 00:47:06 --> Security Class Initialized
DEBUG - 2018-07-25 00:47:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:47:06 --> Security Class Initialized
DEBUG - 2018-07-25 00:47:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:47:06 --> Input Class Initialized
INFO - 2018-07-25 00:47:06 --> Language Class Initialized
INFO - 2018-07-25 00:47:06 --> Input Class Initialized
DEBUG - 2018-07-25 00:47:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:47:06 --> Input Class Initialized
INFO - 2018-07-25 00:47:06 --> Language Class Initialized
ERROR - 2018-07-25 00:47:06 --> 404 Page Not Found: /index
INFO - 2018-07-25 00:47:06 --> Language Class Initialized
ERROR - 2018-07-25 00:47:06 --> 404 Page Not Found: /index
ERROR - 2018-07-25 00:47:06 --> 404 Page Not Found: /index
INFO - 2018-07-25 00:47:06 --> Config Class Initialized
INFO - 2018-07-25 00:47:07 --> Hooks Class Initialized
DEBUG - 2018-07-25 00:47:07 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:47:07 --> Utf8 Class Initialized
INFO - 2018-07-25 00:47:07 --> URI Class Initialized
INFO - 2018-07-25 00:47:07 --> Router Class Initialized
INFO - 2018-07-25 00:47:07 --> Output Class Initialized
INFO - 2018-07-25 00:47:07 --> Security Class Initialized
DEBUG - 2018-07-25 00:47:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:47:07 --> Input Class Initialized
INFO - 2018-07-25 00:47:07 --> Language Class Initialized
ERROR - 2018-07-25 00:47:07 --> 404 Page Not Found: /index
INFO - 2018-07-25 00:47:07 --> Config Class Initialized
INFO - 2018-07-25 00:47:07 --> Hooks Class Initialized
DEBUG - 2018-07-25 00:47:07 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:47:07 --> Utf8 Class Initialized
INFO - 2018-07-25 00:47:07 --> URI Class Initialized
INFO - 2018-07-25 00:47:07 --> Router Class Initialized
INFO - 2018-07-25 00:47:07 --> Output Class Initialized
INFO - 2018-07-25 00:47:07 --> Security Class Initialized
DEBUG - 2018-07-25 00:47:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:47:07 --> Input Class Initialized
INFO - 2018-07-25 00:47:07 --> Language Class Initialized
ERROR - 2018-07-25 00:47:07 --> 404 Page Not Found: /index
INFO - 2018-07-25 00:47:07 --> Config Class Initialized
INFO - 2018-07-25 00:47:07 --> Hooks Class Initialized
DEBUG - 2018-07-25 00:47:07 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:47:07 --> Utf8 Class Initialized
INFO - 2018-07-25 00:47:07 --> URI Class Initialized
INFO - 2018-07-25 00:47:07 --> Router Class Initialized
INFO - 2018-07-25 00:47:07 --> Output Class Initialized
INFO - 2018-07-25 00:47:08 --> Security Class Initialized
DEBUG - 2018-07-25 00:47:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:47:08 --> Input Class Initialized
INFO - 2018-07-25 00:47:08 --> Language Class Initialized
ERROR - 2018-07-25 00:47:08 --> 404 Page Not Found: /index
INFO - 2018-07-25 00:48:11 --> Config Class Initialized
INFO - 2018-07-25 00:48:11 --> Hooks Class Initialized
DEBUG - 2018-07-25 00:48:11 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:48:11 --> Utf8 Class Initialized
INFO - 2018-07-25 00:48:11 --> URI Class Initialized
DEBUG - 2018-07-25 00:48:11 --> No URI present. Default controller set.
INFO - 2018-07-25 00:48:11 --> Router Class Initialized
INFO - 2018-07-25 00:48:11 --> Output Class Initialized
INFO - 2018-07-25 00:48:11 --> Security Class Initialized
DEBUG - 2018-07-25 00:48:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:48:11 --> Input Class Initialized
INFO - 2018-07-25 00:48:11 --> Language Class Initialized
INFO - 2018-07-25 00:48:11 --> Language Class Initialized
INFO - 2018-07-25 00:48:11 --> Config Class Initialized
INFO - 2018-07-25 00:48:11 --> Loader Class Initialized
DEBUG - 2018-07-25 00:48:11 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-25 00:48:11 --> Helper loaded: url_helper
INFO - 2018-07-25 00:48:11 --> Helper loaded: form_helper
INFO - 2018-07-25 00:48:11 --> Helper loaded: date_helper
INFO - 2018-07-25 00:48:11 --> Helper loaded: util_helper
INFO - 2018-07-25 00:48:11 --> Helper loaded: text_helper
INFO - 2018-07-25 00:48:11 --> Helper loaded: string_helper
INFO - 2018-07-25 00:48:11 --> Database Driver Class Initialized
DEBUG - 2018-07-25 00:48:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 00:48:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 00:48:11 --> Email Class Initialized
INFO - 2018-07-25 00:48:11 --> Controller Class Initialized
DEBUG - 2018-07-25 00:48:11 --> Home MX_Controller Initialized
DEBUG - 2018-07-25 00:48:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-25 00:48:11 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-25 00:48:11 --> Login MX_Controller Initialized
INFO - 2018-07-25 00:48:11 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-25 00:48:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-25 00:48:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-25 00:48:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-07-25 00:48:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-07-25 00:48:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-07-25 00:48:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-07-25 00:48:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-07-25 00:48:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-07-25 00:48:11 --> Final output sent to browser
DEBUG - 2018-07-25 00:48:11 --> Total execution time: 0.5029
INFO - 2018-07-25 00:48:11 --> Config Class Initialized
INFO - 2018-07-25 00:48:11 --> Config Class Initialized
INFO - 2018-07-25 00:48:11 --> Config Class Initialized
INFO - 2018-07-25 00:48:11 --> Hooks Class Initialized
INFO - 2018-07-25 00:48:11 --> Hooks Class Initialized
INFO - 2018-07-25 00:48:11 --> Hooks Class Initialized
DEBUG - 2018-07-25 00:48:12 --> UTF-8 Support Enabled
DEBUG - 2018-07-25 00:48:12 --> UTF-8 Support Enabled
DEBUG - 2018-07-25 00:48:12 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:48:12 --> Utf8 Class Initialized
INFO - 2018-07-25 00:48:12 --> Utf8 Class Initialized
INFO - 2018-07-25 00:48:12 --> Utf8 Class Initialized
INFO - 2018-07-25 00:48:12 --> URI Class Initialized
INFO - 2018-07-25 00:48:12 --> URI Class Initialized
INFO - 2018-07-25 00:48:12 --> URI Class Initialized
INFO - 2018-07-25 00:48:12 --> Router Class Initialized
INFO - 2018-07-25 00:48:12 --> Router Class Initialized
INFO - 2018-07-25 00:48:12 --> Router Class Initialized
INFO - 2018-07-25 00:48:12 --> Output Class Initialized
INFO - 2018-07-25 00:48:12 --> Output Class Initialized
INFO - 2018-07-25 00:48:12 --> Output Class Initialized
INFO - 2018-07-25 00:48:12 --> Security Class Initialized
INFO - 2018-07-25 00:48:12 --> Security Class Initialized
INFO - 2018-07-25 00:48:12 --> Security Class Initialized
DEBUG - 2018-07-25 00:48:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-07-25 00:48:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-07-25 00:48:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:48:12 --> Input Class Initialized
INFO - 2018-07-25 00:48:12 --> Input Class Initialized
INFO - 2018-07-25 00:48:12 --> Input Class Initialized
INFO - 2018-07-25 00:48:12 --> Language Class Initialized
INFO - 2018-07-25 00:48:12 --> Language Class Initialized
INFO - 2018-07-25 00:48:12 --> Language Class Initialized
ERROR - 2018-07-25 00:48:12 --> 404 Page Not Found: /index
ERROR - 2018-07-25 00:48:12 --> 404 Page Not Found: /index
ERROR - 2018-07-25 00:48:12 --> 404 Page Not Found: /index
INFO - 2018-07-25 00:48:12 --> Config Class Initialized
INFO - 2018-07-25 00:48:12 --> Hooks Class Initialized
DEBUG - 2018-07-25 00:48:12 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:48:12 --> Utf8 Class Initialized
INFO - 2018-07-25 00:48:12 --> URI Class Initialized
INFO - 2018-07-25 00:48:13 --> Router Class Initialized
INFO - 2018-07-25 00:48:13 --> Output Class Initialized
INFO - 2018-07-25 00:48:13 --> Security Class Initialized
DEBUG - 2018-07-25 00:48:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:48:13 --> Input Class Initialized
INFO - 2018-07-25 00:48:13 --> Language Class Initialized
ERROR - 2018-07-25 00:48:13 --> 404 Page Not Found: /index
INFO - 2018-07-25 00:48:13 --> Config Class Initialized
INFO - 2018-07-25 00:48:13 --> Hooks Class Initialized
DEBUG - 2018-07-25 00:48:13 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:48:13 --> Utf8 Class Initialized
INFO - 2018-07-25 00:48:13 --> URI Class Initialized
INFO - 2018-07-25 00:48:13 --> Router Class Initialized
INFO - 2018-07-25 00:48:13 --> Output Class Initialized
INFO - 2018-07-25 00:48:13 --> Security Class Initialized
DEBUG - 2018-07-25 00:48:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:48:13 --> Input Class Initialized
INFO - 2018-07-25 00:48:13 --> Language Class Initialized
ERROR - 2018-07-25 00:48:13 --> 404 Page Not Found: /index
INFO - 2018-07-25 00:48:13 --> Config Class Initialized
INFO - 2018-07-25 00:48:13 --> Hooks Class Initialized
DEBUG - 2018-07-25 00:48:13 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:48:13 --> Utf8 Class Initialized
INFO - 2018-07-25 00:48:13 --> URI Class Initialized
INFO - 2018-07-25 00:48:13 --> Router Class Initialized
INFO - 2018-07-25 00:48:13 --> Output Class Initialized
INFO - 2018-07-25 00:48:13 --> Security Class Initialized
DEBUG - 2018-07-25 00:48:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:48:13 --> Input Class Initialized
INFO - 2018-07-25 00:48:13 --> Language Class Initialized
ERROR - 2018-07-25 00:48:13 --> 404 Page Not Found: /index
INFO - 2018-07-25 00:49:42 --> Config Class Initialized
INFO - 2018-07-25 00:49:42 --> Hooks Class Initialized
DEBUG - 2018-07-25 00:49:42 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:49:42 --> Utf8 Class Initialized
INFO - 2018-07-25 00:49:42 --> URI Class Initialized
DEBUG - 2018-07-25 00:49:42 --> No URI present. Default controller set.
INFO - 2018-07-25 00:49:42 --> Router Class Initialized
INFO - 2018-07-25 00:49:42 --> Output Class Initialized
INFO - 2018-07-25 00:49:42 --> Security Class Initialized
DEBUG - 2018-07-25 00:49:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:49:42 --> Input Class Initialized
INFO - 2018-07-25 00:49:42 --> Language Class Initialized
INFO - 2018-07-25 00:49:42 --> Language Class Initialized
INFO - 2018-07-25 00:49:42 --> Config Class Initialized
INFO - 2018-07-25 00:49:42 --> Loader Class Initialized
DEBUG - 2018-07-25 00:49:42 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-25 00:49:42 --> Helper loaded: url_helper
INFO - 2018-07-25 00:49:42 --> Helper loaded: form_helper
INFO - 2018-07-25 00:49:42 --> Helper loaded: date_helper
INFO - 2018-07-25 00:49:42 --> Helper loaded: util_helper
INFO - 2018-07-25 00:49:42 --> Helper loaded: text_helper
INFO - 2018-07-25 00:49:42 --> Helper loaded: string_helper
INFO - 2018-07-25 00:49:42 --> Database Driver Class Initialized
DEBUG - 2018-07-25 00:49:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 00:49:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 00:49:42 --> Email Class Initialized
INFO - 2018-07-25 00:49:42 --> Controller Class Initialized
DEBUG - 2018-07-25 00:49:42 --> Home MX_Controller Initialized
DEBUG - 2018-07-25 00:49:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-25 00:49:42 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-25 00:49:42 --> Login MX_Controller Initialized
INFO - 2018-07-25 00:49:42 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-25 00:49:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-25 00:49:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-25 00:49:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-07-25 00:49:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-07-25 00:49:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-07-25 00:49:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-07-25 00:49:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-07-25 00:49:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-07-25 00:49:42 --> Final output sent to browser
DEBUG - 2018-07-25 00:49:42 --> Total execution time: 0.5642
INFO - 2018-07-25 00:49:42 --> Config Class Initialized
INFO - 2018-07-25 00:49:42 --> Config Class Initialized
INFO - 2018-07-25 00:49:43 --> Hooks Class Initialized
INFO - 2018-07-25 00:49:43 --> Hooks Class Initialized
INFO - 2018-07-25 00:49:43 --> Config Class Initialized
INFO - 2018-07-25 00:49:43 --> Hooks Class Initialized
DEBUG - 2018-07-25 00:49:43 --> UTF-8 Support Enabled
DEBUG - 2018-07-25 00:49:43 --> UTF-8 Support Enabled
DEBUG - 2018-07-25 00:49:43 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:49:43 --> Utf8 Class Initialized
INFO - 2018-07-25 00:49:43 --> Utf8 Class Initialized
INFO - 2018-07-25 00:49:43 --> Utf8 Class Initialized
INFO - 2018-07-25 00:49:43 --> URI Class Initialized
INFO - 2018-07-25 00:49:43 --> Router Class Initialized
INFO - 2018-07-25 00:49:43 --> Output Class Initialized
INFO - 2018-07-25 00:49:43 --> URI Class Initialized
INFO - 2018-07-25 00:49:43 --> URI Class Initialized
INFO - 2018-07-25 00:49:43 --> Router Class Initialized
INFO - 2018-07-25 00:49:43 --> Security Class Initialized
INFO - 2018-07-25 00:49:43 --> Output Class Initialized
DEBUG - 2018-07-25 00:49:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:49:43 --> Router Class Initialized
INFO - 2018-07-25 00:49:43 --> Output Class Initialized
INFO - 2018-07-25 00:49:43 --> Input Class Initialized
INFO - 2018-07-25 00:49:43 --> Security Class Initialized
DEBUG - 2018-07-25 00:49:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:49:43 --> Language Class Initialized
INFO - 2018-07-25 00:49:43 --> Security Class Initialized
INFO - 2018-07-25 00:49:43 --> Input Class Initialized
ERROR - 2018-07-25 00:49:43 --> 404 Page Not Found: /index
DEBUG - 2018-07-25 00:49:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:49:43 --> Input Class Initialized
INFO - 2018-07-25 00:49:43 --> Language Class Initialized
INFO - 2018-07-25 00:49:43 --> Language Class Initialized
ERROR - 2018-07-25 00:49:43 --> 404 Page Not Found: /index
ERROR - 2018-07-25 00:49:43 --> 404 Page Not Found: /index
INFO - 2018-07-25 00:49:44 --> Config Class Initialized
INFO - 2018-07-25 00:49:44 --> Hooks Class Initialized
DEBUG - 2018-07-25 00:49:44 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:49:44 --> Utf8 Class Initialized
INFO - 2018-07-25 00:49:44 --> URI Class Initialized
INFO - 2018-07-25 00:49:44 --> Router Class Initialized
INFO - 2018-07-25 00:49:44 --> Output Class Initialized
INFO - 2018-07-25 00:49:44 --> Security Class Initialized
DEBUG - 2018-07-25 00:49:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:49:44 --> Input Class Initialized
INFO - 2018-07-25 00:49:44 --> Language Class Initialized
ERROR - 2018-07-25 00:49:44 --> 404 Page Not Found: /index
INFO - 2018-07-25 00:49:44 --> Config Class Initialized
INFO - 2018-07-25 00:49:44 --> Hooks Class Initialized
DEBUG - 2018-07-25 00:49:44 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:49:44 --> Utf8 Class Initialized
INFO - 2018-07-25 00:49:44 --> URI Class Initialized
INFO - 2018-07-25 00:49:44 --> Router Class Initialized
INFO - 2018-07-25 00:49:44 --> Output Class Initialized
INFO - 2018-07-25 00:49:44 --> Security Class Initialized
DEBUG - 2018-07-25 00:49:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:49:44 --> Input Class Initialized
INFO - 2018-07-25 00:49:44 --> Language Class Initialized
ERROR - 2018-07-25 00:49:44 --> 404 Page Not Found: /index
INFO - 2018-07-25 00:49:44 --> Config Class Initialized
INFO - 2018-07-25 00:49:45 --> Hooks Class Initialized
DEBUG - 2018-07-25 00:49:45 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:49:45 --> Utf8 Class Initialized
INFO - 2018-07-25 00:49:45 --> URI Class Initialized
INFO - 2018-07-25 00:49:45 --> Router Class Initialized
INFO - 2018-07-25 00:49:45 --> Output Class Initialized
INFO - 2018-07-25 00:49:45 --> Security Class Initialized
DEBUG - 2018-07-25 00:49:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:49:45 --> Input Class Initialized
INFO - 2018-07-25 00:49:45 --> Language Class Initialized
ERROR - 2018-07-25 00:49:45 --> 404 Page Not Found: /index
INFO - 2018-07-25 00:50:30 --> Config Class Initialized
INFO - 2018-07-25 00:50:30 --> Hooks Class Initialized
DEBUG - 2018-07-25 00:50:30 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:50:30 --> Utf8 Class Initialized
INFO - 2018-07-25 00:50:30 --> URI Class Initialized
DEBUG - 2018-07-25 00:50:30 --> No URI present. Default controller set.
INFO - 2018-07-25 00:50:30 --> Router Class Initialized
INFO - 2018-07-25 00:50:30 --> Output Class Initialized
INFO - 2018-07-25 00:50:30 --> Security Class Initialized
DEBUG - 2018-07-25 00:50:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:50:30 --> Input Class Initialized
INFO - 2018-07-25 00:50:30 --> Language Class Initialized
INFO - 2018-07-25 00:50:30 --> Language Class Initialized
INFO - 2018-07-25 00:50:30 --> Config Class Initialized
INFO - 2018-07-25 00:50:30 --> Loader Class Initialized
DEBUG - 2018-07-25 00:50:30 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-25 00:50:30 --> Helper loaded: url_helper
INFO - 2018-07-25 00:50:30 --> Helper loaded: form_helper
INFO - 2018-07-25 00:50:30 --> Helper loaded: date_helper
INFO - 2018-07-25 00:50:30 --> Helper loaded: util_helper
INFO - 2018-07-25 00:50:30 --> Helper loaded: text_helper
INFO - 2018-07-25 00:50:30 --> Helper loaded: string_helper
INFO - 2018-07-25 00:50:30 --> Database Driver Class Initialized
DEBUG - 2018-07-25 00:50:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 00:50:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 00:50:30 --> Email Class Initialized
INFO - 2018-07-25 00:50:30 --> Controller Class Initialized
DEBUG - 2018-07-25 00:50:30 --> Home MX_Controller Initialized
DEBUG - 2018-07-25 00:50:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-25 00:50:30 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-25 00:50:30 --> Login MX_Controller Initialized
INFO - 2018-07-25 00:50:30 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-25 00:50:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-25 00:50:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-25 00:50:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-07-25 00:50:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-07-25 00:50:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-07-25 00:50:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-07-25 00:50:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-07-25 00:50:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-07-25 00:50:30 --> Final output sent to browser
DEBUG - 2018-07-25 00:50:31 --> Total execution time: 0.5030
INFO - 2018-07-25 00:50:31 --> Config Class Initialized
INFO - 2018-07-25 00:50:31 --> Config Class Initialized
INFO - 2018-07-25 00:50:31 --> Config Class Initialized
INFO - 2018-07-25 00:50:31 --> Hooks Class Initialized
INFO - 2018-07-25 00:50:31 --> Hooks Class Initialized
INFO - 2018-07-25 00:50:31 --> Hooks Class Initialized
DEBUG - 2018-07-25 00:50:31 --> UTF-8 Support Enabled
DEBUG - 2018-07-25 00:50:31 --> UTF-8 Support Enabled
DEBUG - 2018-07-25 00:50:31 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:50:31 --> Utf8 Class Initialized
INFO - 2018-07-25 00:50:31 --> Utf8 Class Initialized
INFO - 2018-07-25 00:50:31 --> Utf8 Class Initialized
INFO - 2018-07-25 00:50:31 --> URI Class Initialized
INFO - 2018-07-25 00:50:31 --> URI Class Initialized
INFO - 2018-07-25 00:50:31 --> URI Class Initialized
INFO - 2018-07-25 00:50:31 --> Router Class Initialized
INFO - 2018-07-25 00:50:31 --> Output Class Initialized
INFO - 2018-07-25 00:50:31 --> Router Class Initialized
INFO - 2018-07-25 00:50:31 --> Router Class Initialized
INFO - 2018-07-25 00:50:31 --> Output Class Initialized
INFO - 2018-07-25 00:50:31 --> Security Class Initialized
INFO - 2018-07-25 00:50:31 --> Output Class Initialized
INFO - 2018-07-25 00:50:31 --> Security Class Initialized
INFO - 2018-07-25 00:50:31 --> Security Class Initialized
DEBUG - 2018-07-25 00:50:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:50:31 --> Input Class Initialized
DEBUG - 2018-07-25 00:50:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-07-25 00:50:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:50:31 --> Input Class Initialized
INFO - 2018-07-25 00:50:31 --> Input Class Initialized
INFO - 2018-07-25 00:50:31 --> Language Class Initialized
INFO - 2018-07-25 00:50:31 --> Language Class Initialized
ERROR - 2018-07-25 00:50:31 --> 404 Page Not Found: /index
INFO - 2018-07-25 00:50:31 --> Language Class Initialized
ERROR - 2018-07-25 00:50:31 --> 404 Page Not Found: /index
ERROR - 2018-07-25 00:50:31 --> 404 Page Not Found: /index
INFO - 2018-07-25 00:50:32 --> Config Class Initialized
INFO - 2018-07-25 00:50:32 --> Hooks Class Initialized
DEBUG - 2018-07-25 00:50:32 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:50:32 --> Utf8 Class Initialized
INFO - 2018-07-25 00:50:32 --> URI Class Initialized
INFO - 2018-07-25 00:50:32 --> Router Class Initialized
INFO - 2018-07-25 00:50:32 --> Output Class Initialized
INFO - 2018-07-25 00:50:32 --> Security Class Initialized
DEBUG - 2018-07-25 00:50:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:50:32 --> Input Class Initialized
INFO - 2018-07-25 00:50:32 --> Language Class Initialized
ERROR - 2018-07-25 00:50:32 --> 404 Page Not Found: /index
INFO - 2018-07-25 00:50:32 --> Config Class Initialized
INFO - 2018-07-25 00:50:32 --> Hooks Class Initialized
DEBUG - 2018-07-25 00:50:32 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:50:32 --> Utf8 Class Initialized
INFO - 2018-07-25 00:50:32 --> URI Class Initialized
INFO - 2018-07-25 00:50:32 --> Router Class Initialized
INFO - 2018-07-25 00:50:32 --> Output Class Initialized
INFO - 2018-07-25 00:50:32 --> Security Class Initialized
DEBUG - 2018-07-25 00:50:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:50:32 --> Input Class Initialized
INFO - 2018-07-25 00:50:32 --> Language Class Initialized
ERROR - 2018-07-25 00:50:32 --> 404 Page Not Found: /index
INFO - 2018-07-25 00:50:32 --> Config Class Initialized
INFO - 2018-07-25 00:50:32 --> Hooks Class Initialized
DEBUG - 2018-07-25 00:50:32 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:50:32 --> Utf8 Class Initialized
INFO - 2018-07-25 00:50:32 --> URI Class Initialized
INFO - 2018-07-25 00:50:32 --> Router Class Initialized
INFO - 2018-07-25 00:50:33 --> Output Class Initialized
INFO - 2018-07-25 00:50:33 --> Security Class Initialized
DEBUG - 2018-07-25 00:50:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:50:33 --> Input Class Initialized
INFO - 2018-07-25 00:50:33 --> Language Class Initialized
ERROR - 2018-07-25 00:50:33 --> 404 Page Not Found: /index
INFO - 2018-07-25 00:51:43 --> Config Class Initialized
INFO - 2018-07-25 00:51:43 --> Hooks Class Initialized
DEBUG - 2018-07-25 00:51:44 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:51:44 --> Utf8 Class Initialized
INFO - 2018-07-25 00:51:44 --> URI Class Initialized
DEBUG - 2018-07-25 00:51:44 --> No URI present. Default controller set.
INFO - 2018-07-25 00:51:44 --> Router Class Initialized
INFO - 2018-07-25 00:51:44 --> Output Class Initialized
INFO - 2018-07-25 00:51:44 --> Security Class Initialized
DEBUG - 2018-07-25 00:51:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:51:44 --> Input Class Initialized
INFO - 2018-07-25 00:51:44 --> Language Class Initialized
INFO - 2018-07-25 00:51:44 --> Language Class Initialized
INFO - 2018-07-25 00:51:44 --> Config Class Initialized
INFO - 2018-07-25 00:51:44 --> Loader Class Initialized
DEBUG - 2018-07-25 00:51:44 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-25 00:51:44 --> Helper loaded: url_helper
INFO - 2018-07-25 00:51:44 --> Helper loaded: form_helper
INFO - 2018-07-25 00:51:44 --> Helper loaded: date_helper
INFO - 2018-07-25 00:51:44 --> Helper loaded: util_helper
INFO - 2018-07-25 00:51:44 --> Helper loaded: text_helper
INFO - 2018-07-25 00:51:44 --> Helper loaded: string_helper
INFO - 2018-07-25 00:51:44 --> Database Driver Class Initialized
DEBUG - 2018-07-25 00:51:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 00:51:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 00:51:44 --> Email Class Initialized
INFO - 2018-07-25 00:51:44 --> Controller Class Initialized
DEBUG - 2018-07-25 00:51:44 --> Home MX_Controller Initialized
DEBUG - 2018-07-25 00:51:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-25 00:51:44 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-25 00:51:44 --> Login MX_Controller Initialized
INFO - 2018-07-25 00:51:44 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-25 00:51:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-25 00:51:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-25 00:51:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-07-25 00:51:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-07-25 00:51:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-07-25 00:51:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-07-25 00:51:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-07-25 00:51:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-07-25 00:51:44 --> Final output sent to browser
DEBUG - 2018-07-25 00:51:44 --> Total execution time: 0.5272
INFO - 2018-07-25 00:51:44 --> Config Class Initialized
INFO - 2018-07-25 00:51:44 --> Config Class Initialized
INFO - 2018-07-25 00:51:44 --> Config Class Initialized
INFO - 2018-07-25 00:51:45 --> Hooks Class Initialized
INFO - 2018-07-25 00:51:45 --> Hooks Class Initialized
INFO - 2018-07-25 00:51:45 --> Hooks Class Initialized
DEBUG - 2018-07-25 00:51:45 --> UTF-8 Support Enabled
DEBUG - 2018-07-25 00:51:45 --> UTF-8 Support Enabled
DEBUG - 2018-07-25 00:51:45 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:51:45 --> Utf8 Class Initialized
INFO - 2018-07-25 00:51:45 --> Utf8 Class Initialized
INFO - 2018-07-25 00:51:45 --> Utf8 Class Initialized
INFO - 2018-07-25 00:51:45 --> URI Class Initialized
INFO - 2018-07-25 00:51:45 --> URI Class Initialized
INFO - 2018-07-25 00:51:45 --> URI Class Initialized
INFO - 2018-07-25 00:51:45 --> Router Class Initialized
INFO - 2018-07-25 00:51:45 --> Router Class Initialized
INFO - 2018-07-25 00:51:45 --> Router Class Initialized
INFO - 2018-07-25 00:51:45 --> Output Class Initialized
INFO - 2018-07-25 00:51:45 --> Output Class Initialized
INFO - 2018-07-25 00:51:45 --> Output Class Initialized
INFO - 2018-07-25 00:51:45 --> Security Class Initialized
DEBUG - 2018-07-25 00:51:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:51:45 --> Input Class Initialized
INFO - 2018-07-25 00:51:45 --> Security Class Initialized
INFO - 2018-07-25 00:51:45 --> Security Class Initialized
INFO - 2018-07-25 00:51:45 --> Language Class Initialized
DEBUG - 2018-07-25 00:51:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-07-25 00:51:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-07-25 00:51:45 --> 404 Page Not Found: /index
INFO - 2018-07-25 00:51:45 --> Input Class Initialized
INFO - 2018-07-25 00:51:45 --> Input Class Initialized
INFO - 2018-07-25 00:51:45 --> Language Class Initialized
INFO - 2018-07-25 00:51:45 --> Language Class Initialized
ERROR - 2018-07-25 00:51:45 --> 404 Page Not Found: /index
ERROR - 2018-07-25 00:51:45 --> 404 Page Not Found: /index
INFO - 2018-07-25 00:51:46 --> Config Class Initialized
INFO - 2018-07-25 00:51:46 --> Hooks Class Initialized
DEBUG - 2018-07-25 00:51:46 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:51:46 --> Utf8 Class Initialized
INFO - 2018-07-25 00:51:46 --> URI Class Initialized
INFO - 2018-07-25 00:51:46 --> Router Class Initialized
INFO - 2018-07-25 00:51:46 --> Output Class Initialized
INFO - 2018-07-25 00:51:46 --> Security Class Initialized
DEBUG - 2018-07-25 00:51:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:51:46 --> Input Class Initialized
INFO - 2018-07-25 00:51:46 --> Language Class Initialized
ERROR - 2018-07-25 00:51:46 --> 404 Page Not Found: /index
INFO - 2018-07-25 00:51:46 --> Config Class Initialized
INFO - 2018-07-25 00:51:46 --> Hooks Class Initialized
DEBUG - 2018-07-25 00:51:46 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:51:46 --> Utf8 Class Initialized
INFO - 2018-07-25 00:51:46 --> URI Class Initialized
INFO - 2018-07-25 00:51:46 --> Router Class Initialized
INFO - 2018-07-25 00:51:46 --> Output Class Initialized
INFO - 2018-07-25 00:51:46 --> Security Class Initialized
DEBUG - 2018-07-25 00:51:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:51:46 --> Input Class Initialized
INFO - 2018-07-25 00:51:46 --> Language Class Initialized
ERROR - 2018-07-25 00:51:46 --> 404 Page Not Found: /index
INFO - 2018-07-25 00:51:46 --> Config Class Initialized
INFO - 2018-07-25 00:51:46 --> Hooks Class Initialized
DEBUG - 2018-07-25 00:51:46 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:51:46 --> Utf8 Class Initialized
INFO - 2018-07-25 00:51:46 --> URI Class Initialized
INFO - 2018-07-25 00:51:46 --> Router Class Initialized
INFO - 2018-07-25 00:51:46 --> Output Class Initialized
INFO - 2018-07-25 00:51:46 --> Security Class Initialized
DEBUG - 2018-07-25 00:51:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:51:46 --> Input Class Initialized
INFO - 2018-07-25 00:51:46 --> Language Class Initialized
ERROR - 2018-07-25 00:51:46 --> 404 Page Not Found: /index
INFO - 2018-07-25 00:51:47 --> Config Class Initialized
INFO - 2018-07-25 00:51:47 --> Hooks Class Initialized
DEBUG - 2018-07-25 00:51:47 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:51:47 --> Utf8 Class Initialized
INFO - 2018-07-25 00:51:47 --> URI Class Initialized
INFO - 2018-07-25 00:51:47 --> Router Class Initialized
INFO - 2018-07-25 00:51:47 --> Output Class Initialized
INFO - 2018-07-25 00:51:47 --> Security Class Initialized
DEBUG - 2018-07-25 00:51:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:51:47 --> Input Class Initialized
INFO - 2018-07-25 00:51:47 --> Language Class Initialized
ERROR - 2018-07-25 00:51:47 --> 404 Page Not Found: /index
INFO - 2018-07-25 00:51:49 --> Config Class Initialized
INFO - 2018-07-25 00:51:49 --> Hooks Class Initialized
DEBUG - 2018-07-25 00:51:49 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:51:49 --> Utf8 Class Initialized
INFO - 2018-07-25 00:51:49 --> URI Class Initialized
INFO - 2018-07-25 00:51:49 --> Router Class Initialized
INFO - 2018-07-25 00:51:49 --> Output Class Initialized
INFO - 2018-07-25 00:51:49 --> Security Class Initialized
DEBUG - 2018-07-25 00:51:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:51:49 --> Input Class Initialized
INFO - 2018-07-25 00:51:49 --> Language Class Initialized
ERROR - 2018-07-25 00:51:49 --> 404 Page Not Found: /index
INFO - 2018-07-25 00:51:49 --> Config Class Initialized
INFO - 2018-07-25 00:51:49 --> Hooks Class Initialized
DEBUG - 2018-07-25 00:51:49 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:51:49 --> Utf8 Class Initialized
INFO - 2018-07-25 00:51:49 --> URI Class Initialized
INFO - 2018-07-25 00:51:49 --> Router Class Initialized
INFO - 2018-07-25 00:51:50 --> Output Class Initialized
INFO - 2018-07-25 00:51:50 --> Security Class Initialized
DEBUG - 2018-07-25 00:51:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:51:50 --> Input Class Initialized
INFO - 2018-07-25 00:51:50 --> Language Class Initialized
ERROR - 2018-07-25 00:51:50 --> 404 Page Not Found: /index
INFO - 2018-07-25 00:52:09 --> Config Class Initialized
INFO - 2018-07-25 00:52:09 --> Hooks Class Initialized
DEBUG - 2018-07-25 00:52:09 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:52:09 --> Utf8 Class Initialized
INFO - 2018-07-25 00:52:09 --> URI Class Initialized
DEBUG - 2018-07-25 00:52:09 --> No URI present. Default controller set.
INFO - 2018-07-25 00:52:09 --> Router Class Initialized
INFO - 2018-07-25 00:52:09 --> Output Class Initialized
INFO - 2018-07-25 00:52:09 --> Security Class Initialized
DEBUG - 2018-07-25 00:52:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:52:09 --> Input Class Initialized
INFO - 2018-07-25 00:52:09 --> Language Class Initialized
INFO - 2018-07-25 00:52:09 --> Language Class Initialized
INFO - 2018-07-25 00:52:09 --> Config Class Initialized
INFO - 2018-07-25 00:52:09 --> Loader Class Initialized
DEBUG - 2018-07-25 00:52:09 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-25 00:52:09 --> Helper loaded: url_helper
INFO - 2018-07-25 00:52:09 --> Helper loaded: form_helper
INFO - 2018-07-25 00:52:09 --> Helper loaded: date_helper
INFO - 2018-07-25 00:52:09 --> Helper loaded: util_helper
INFO - 2018-07-25 00:52:09 --> Helper loaded: text_helper
INFO - 2018-07-25 00:52:09 --> Helper loaded: string_helper
INFO - 2018-07-25 00:52:09 --> Database Driver Class Initialized
DEBUG - 2018-07-25 00:52:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 00:52:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 00:52:09 --> Email Class Initialized
INFO - 2018-07-25 00:52:09 --> Controller Class Initialized
DEBUG - 2018-07-25 00:52:09 --> Home MX_Controller Initialized
DEBUG - 2018-07-25 00:52:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-25 00:52:09 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-25 00:52:09 --> Login MX_Controller Initialized
INFO - 2018-07-25 00:52:09 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-25 00:52:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-25 00:52:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-25 00:52:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-07-25 00:52:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-07-25 00:52:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-07-25 00:52:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-07-25 00:52:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-07-25 00:52:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-07-25 00:52:09 --> Final output sent to browser
DEBUG - 2018-07-25 00:52:09 --> Total execution time: 0.5293
INFO - 2018-07-25 00:52:09 --> Config Class Initialized
INFO - 2018-07-25 00:52:09 --> Config Class Initialized
INFO - 2018-07-25 00:52:09 --> Config Class Initialized
INFO - 2018-07-25 00:52:09 --> Hooks Class Initialized
INFO - 2018-07-25 00:52:09 --> Hooks Class Initialized
DEBUG - 2018-07-25 00:52:09 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:52:09 --> Hooks Class Initialized
INFO - 2018-07-25 00:52:09 --> Utf8 Class Initialized
DEBUG - 2018-07-25 00:52:09 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:52:10 --> Utf8 Class Initialized
DEBUG - 2018-07-25 00:52:10 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:52:10 --> Utf8 Class Initialized
INFO - 2018-07-25 00:52:10 --> URI Class Initialized
INFO - 2018-07-25 00:52:10 --> URI Class Initialized
INFO - 2018-07-25 00:52:10 --> Router Class Initialized
INFO - 2018-07-25 00:52:10 --> Router Class Initialized
INFO - 2018-07-25 00:52:10 --> URI Class Initialized
INFO - 2018-07-25 00:52:10 --> Router Class Initialized
INFO - 2018-07-25 00:52:10 --> Output Class Initialized
INFO - 2018-07-25 00:52:10 --> Output Class Initialized
INFO - 2018-07-25 00:52:10 --> Output Class Initialized
INFO - 2018-07-25 00:52:10 --> Security Class Initialized
INFO - 2018-07-25 00:52:10 --> Security Class Initialized
DEBUG - 2018-07-25 00:52:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:52:10 --> Security Class Initialized
INFO - 2018-07-25 00:52:10 --> Input Class Initialized
DEBUG - 2018-07-25 00:52:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-07-25 00:52:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:52:10 --> Input Class Initialized
INFO - 2018-07-25 00:52:10 --> Input Class Initialized
INFO - 2018-07-25 00:52:10 --> Language Class Initialized
INFO - 2018-07-25 00:52:10 --> Language Class Initialized
ERROR - 2018-07-25 00:52:10 --> 404 Page Not Found: /index
INFO - 2018-07-25 00:52:10 --> Language Class Initialized
ERROR - 2018-07-25 00:52:10 --> 404 Page Not Found: /index
ERROR - 2018-07-25 00:52:10 --> 404 Page Not Found: /index
INFO - 2018-07-25 00:52:10 --> Config Class Initialized
INFO - 2018-07-25 00:52:10 --> Hooks Class Initialized
DEBUG - 2018-07-25 00:52:10 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:52:10 --> Utf8 Class Initialized
INFO - 2018-07-25 00:52:10 --> URI Class Initialized
INFO - 2018-07-25 00:52:11 --> Router Class Initialized
INFO - 2018-07-25 00:52:11 --> Output Class Initialized
INFO - 2018-07-25 00:52:11 --> Security Class Initialized
DEBUG - 2018-07-25 00:52:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:52:11 --> Input Class Initialized
INFO - 2018-07-25 00:52:11 --> Language Class Initialized
ERROR - 2018-07-25 00:52:11 --> 404 Page Not Found: /index
INFO - 2018-07-25 00:52:11 --> Config Class Initialized
INFO - 2018-07-25 00:52:11 --> Hooks Class Initialized
DEBUG - 2018-07-25 00:52:11 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:52:11 --> Utf8 Class Initialized
INFO - 2018-07-25 00:52:11 --> URI Class Initialized
INFO - 2018-07-25 00:52:11 --> Router Class Initialized
INFO - 2018-07-25 00:52:11 --> Output Class Initialized
INFO - 2018-07-25 00:52:11 --> Security Class Initialized
DEBUG - 2018-07-25 00:52:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:52:11 --> Input Class Initialized
INFO - 2018-07-25 00:52:11 --> Language Class Initialized
ERROR - 2018-07-25 00:52:11 --> 404 Page Not Found: /index
INFO - 2018-07-25 00:52:13 --> Config Class Initialized
INFO - 2018-07-25 00:52:13 --> Hooks Class Initialized
DEBUG - 2018-07-25 00:52:13 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:52:13 --> Utf8 Class Initialized
INFO - 2018-07-25 00:52:13 --> URI Class Initialized
INFO - 2018-07-25 00:52:13 --> Router Class Initialized
INFO - 2018-07-25 00:52:13 --> Output Class Initialized
INFO - 2018-07-25 00:52:13 --> Security Class Initialized
DEBUG - 2018-07-25 00:52:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:52:13 --> Input Class Initialized
INFO - 2018-07-25 00:52:13 --> Language Class Initialized
ERROR - 2018-07-25 00:52:13 --> 404 Page Not Found: /index
INFO - 2018-07-25 00:53:16 --> Config Class Initialized
INFO - 2018-07-25 00:53:16 --> Hooks Class Initialized
DEBUG - 2018-07-25 00:53:16 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:53:16 --> Utf8 Class Initialized
INFO - 2018-07-25 00:53:16 --> URI Class Initialized
DEBUG - 2018-07-25 00:53:16 --> No URI present. Default controller set.
INFO - 2018-07-25 00:53:16 --> Router Class Initialized
INFO - 2018-07-25 00:53:16 --> Output Class Initialized
INFO - 2018-07-25 00:53:16 --> Security Class Initialized
DEBUG - 2018-07-25 00:53:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:53:16 --> Input Class Initialized
INFO - 2018-07-25 00:53:16 --> Language Class Initialized
INFO - 2018-07-25 00:53:16 --> Language Class Initialized
INFO - 2018-07-25 00:53:16 --> Config Class Initialized
INFO - 2018-07-25 00:53:16 --> Loader Class Initialized
DEBUG - 2018-07-25 00:53:16 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-25 00:53:16 --> Helper loaded: url_helper
INFO - 2018-07-25 00:53:16 --> Helper loaded: form_helper
INFO - 2018-07-25 00:53:16 --> Helper loaded: date_helper
INFO - 2018-07-25 00:53:17 --> Helper loaded: util_helper
INFO - 2018-07-25 00:53:17 --> Helper loaded: text_helper
INFO - 2018-07-25 00:53:17 --> Helper loaded: string_helper
INFO - 2018-07-25 00:53:17 --> Database Driver Class Initialized
DEBUG - 2018-07-25 00:53:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 00:53:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 00:53:17 --> Email Class Initialized
INFO - 2018-07-25 00:53:17 --> Controller Class Initialized
DEBUG - 2018-07-25 00:53:17 --> Home MX_Controller Initialized
DEBUG - 2018-07-25 00:53:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-25 00:53:17 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-25 00:53:17 --> Login MX_Controller Initialized
INFO - 2018-07-25 00:53:17 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-25 00:53:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-25 00:53:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-25 00:53:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-07-25 00:53:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-07-25 00:53:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-07-25 00:53:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-07-25 00:53:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-07-25 00:53:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-07-25 00:53:17 --> Final output sent to browser
DEBUG - 2018-07-25 00:53:17 --> Total execution time: 0.5880
INFO - 2018-07-25 00:53:17 --> Config Class Initialized
INFO - 2018-07-25 00:53:17 --> Config Class Initialized
INFO - 2018-07-25 00:53:17 --> Config Class Initialized
INFO - 2018-07-25 00:53:17 --> Config Class Initialized
INFO - 2018-07-25 00:53:17 --> Hooks Class Initialized
INFO - 2018-07-25 00:53:17 --> Hooks Class Initialized
INFO - 2018-07-25 00:53:17 --> Hooks Class Initialized
INFO - 2018-07-25 00:53:17 --> Hooks Class Initialized
DEBUG - 2018-07-25 00:53:17 --> UTF-8 Support Enabled
DEBUG - 2018-07-25 00:53:17 --> UTF-8 Support Enabled
DEBUG - 2018-07-25 00:53:17 --> UTF-8 Support Enabled
DEBUG - 2018-07-25 00:53:17 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:53:17 --> Utf8 Class Initialized
INFO - 2018-07-25 00:53:17 --> URI Class Initialized
INFO - 2018-07-25 00:53:17 --> Utf8 Class Initialized
INFO - 2018-07-25 00:53:17 --> Utf8 Class Initialized
INFO - 2018-07-25 00:53:17 --> Utf8 Class Initialized
INFO - 2018-07-25 00:53:17 --> URI Class Initialized
INFO - 2018-07-25 00:53:17 --> URI Class Initialized
INFO - 2018-07-25 00:53:17 --> Router Class Initialized
INFO - 2018-07-25 00:53:17 --> URI Class Initialized
INFO - 2018-07-25 00:53:17 --> Output Class Initialized
INFO - 2018-07-25 00:53:17 --> Router Class Initialized
INFO - 2018-07-25 00:53:17 --> Router Class Initialized
INFO - 2018-07-25 00:53:17 --> Router Class Initialized
INFO - 2018-07-25 00:53:17 --> Output Class Initialized
INFO - 2018-07-25 00:53:17 --> Security Class Initialized
INFO - 2018-07-25 00:53:17 --> Output Class Initialized
INFO - 2018-07-25 00:53:17 --> Output Class Initialized
INFO - 2018-07-25 00:53:17 --> Security Class Initialized
INFO - 2018-07-25 00:53:17 --> Security Class Initialized
DEBUG - 2018-07-25 00:53:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-07-25 00:53:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-07-25 00:53:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:53:17 --> Security Class Initialized
INFO - 2018-07-25 00:53:17 --> Input Class Initialized
INFO - 2018-07-25 00:53:17 --> Input Class Initialized
DEBUG - 2018-07-25 00:53:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:53:17 --> Input Class Initialized
INFO - 2018-07-25 00:53:17 --> Language Class Initialized
INFO - 2018-07-25 00:53:17 --> Language Class Initialized
INFO - 2018-07-25 00:53:17 --> Language Class Initialized
INFO - 2018-07-25 00:53:17 --> Input Class Initialized
ERROR - 2018-07-25 00:53:17 --> 404 Page Not Found: /index
INFO - 2018-07-25 00:53:17 --> Language Class Initialized
ERROR - 2018-07-25 00:53:17 --> 404 Page Not Found: /index
ERROR - 2018-07-25 00:53:17 --> 404 Page Not Found: /index
ERROR - 2018-07-25 00:53:17 --> 404 Page Not Found: /index
INFO - 2018-07-25 00:53:17 --> Config Class Initialized
INFO - 2018-07-25 00:53:17 --> Hooks Class Initialized
DEBUG - 2018-07-25 00:53:17 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:53:17 --> Utf8 Class Initialized
INFO - 2018-07-25 00:53:17 --> URI Class Initialized
INFO - 2018-07-25 00:53:17 --> Router Class Initialized
INFO - 2018-07-25 00:53:17 --> Output Class Initialized
INFO - 2018-07-25 00:53:17 --> Security Class Initialized
DEBUG - 2018-07-25 00:53:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:53:17 --> Input Class Initialized
INFO - 2018-07-25 00:53:17 --> Language Class Initialized
ERROR - 2018-07-25 00:53:17 --> 404 Page Not Found: /index
INFO - 2018-07-25 00:53:18 --> Config Class Initialized
INFO - 2018-07-25 00:53:18 --> Hooks Class Initialized
DEBUG - 2018-07-25 00:53:18 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:53:18 --> Utf8 Class Initialized
INFO - 2018-07-25 00:53:18 --> URI Class Initialized
INFO - 2018-07-25 00:53:18 --> Router Class Initialized
INFO - 2018-07-25 00:53:18 --> Output Class Initialized
INFO - 2018-07-25 00:53:18 --> Security Class Initialized
DEBUG - 2018-07-25 00:53:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:53:18 --> Input Class Initialized
INFO - 2018-07-25 00:53:18 --> Language Class Initialized
ERROR - 2018-07-25 00:53:18 --> 404 Page Not Found: /index
INFO - 2018-07-25 00:53:18 --> Config Class Initialized
INFO - 2018-07-25 00:53:18 --> Hooks Class Initialized
DEBUG - 2018-07-25 00:53:18 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:53:18 --> Utf8 Class Initialized
INFO - 2018-07-25 00:53:19 --> URI Class Initialized
INFO - 2018-07-25 00:53:19 --> Router Class Initialized
INFO - 2018-07-25 00:53:19 --> Output Class Initialized
INFO - 2018-07-25 00:53:19 --> Security Class Initialized
DEBUG - 2018-07-25 00:53:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:53:19 --> Input Class Initialized
INFO - 2018-07-25 00:53:19 --> Language Class Initialized
ERROR - 2018-07-25 00:53:19 --> 404 Page Not Found: /index
INFO - 2018-07-25 00:53:19 --> Config Class Initialized
INFO - 2018-07-25 00:53:19 --> Hooks Class Initialized
DEBUG - 2018-07-25 00:53:19 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:53:19 --> Utf8 Class Initialized
INFO - 2018-07-25 00:53:19 --> URI Class Initialized
INFO - 2018-07-25 00:53:19 --> Router Class Initialized
INFO - 2018-07-25 00:53:19 --> Output Class Initialized
INFO - 2018-07-25 00:53:19 --> Security Class Initialized
DEBUG - 2018-07-25 00:53:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:53:19 --> Input Class Initialized
INFO - 2018-07-25 00:53:19 --> Language Class Initialized
ERROR - 2018-07-25 00:53:19 --> 404 Page Not Found: /index
INFO - 2018-07-25 00:53:19 --> Config Class Initialized
INFO - 2018-07-25 00:53:19 --> Hooks Class Initialized
DEBUG - 2018-07-25 00:53:19 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:53:19 --> Utf8 Class Initialized
INFO - 2018-07-25 00:53:19 --> URI Class Initialized
INFO - 2018-07-25 00:53:19 --> Router Class Initialized
INFO - 2018-07-25 00:53:19 --> Output Class Initialized
INFO - 2018-07-25 00:53:19 --> Security Class Initialized
DEBUG - 2018-07-25 00:53:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:53:19 --> Input Class Initialized
INFO - 2018-07-25 00:53:19 --> Language Class Initialized
ERROR - 2018-07-25 00:53:19 --> 404 Page Not Found: /index
INFO - 2018-07-25 00:53:19 --> Config Class Initialized
INFO - 2018-07-25 00:53:19 --> Hooks Class Initialized
DEBUG - 2018-07-25 00:53:19 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:53:19 --> Utf8 Class Initialized
INFO - 2018-07-25 00:53:19 --> URI Class Initialized
INFO - 2018-07-25 00:53:19 --> Router Class Initialized
INFO - 2018-07-25 00:53:19 --> Output Class Initialized
INFO - 2018-07-25 00:53:19 --> Security Class Initialized
DEBUG - 2018-07-25 00:53:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:53:19 --> Input Class Initialized
INFO - 2018-07-25 00:53:19 --> Language Class Initialized
ERROR - 2018-07-25 00:53:19 --> 404 Page Not Found: /index
INFO - 2018-07-25 00:53:19 --> Config Class Initialized
INFO - 2018-07-25 00:53:19 --> Hooks Class Initialized
DEBUG - 2018-07-25 00:53:19 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:53:19 --> Utf8 Class Initialized
INFO - 2018-07-25 00:53:19 --> URI Class Initialized
INFO - 2018-07-25 00:53:19 --> Router Class Initialized
INFO - 2018-07-25 00:53:19 --> Output Class Initialized
INFO - 2018-07-25 00:53:19 --> Security Class Initialized
DEBUG - 2018-07-25 00:53:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:53:19 --> Input Class Initialized
INFO - 2018-07-25 00:53:19 --> Language Class Initialized
ERROR - 2018-07-25 00:53:19 --> 404 Page Not Found: /index
INFO - 2018-07-25 00:53:45 --> Config Class Initialized
INFO - 2018-07-25 00:53:45 --> Hooks Class Initialized
DEBUG - 2018-07-25 00:53:45 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:53:45 --> Utf8 Class Initialized
INFO - 2018-07-25 00:53:45 --> URI Class Initialized
DEBUG - 2018-07-25 00:53:45 --> No URI present. Default controller set.
INFO - 2018-07-25 00:53:45 --> Router Class Initialized
INFO - 2018-07-25 00:53:45 --> Output Class Initialized
INFO - 2018-07-25 00:53:45 --> Security Class Initialized
DEBUG - 2018-07-25 00:53:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:53:45 --> Input Class Initialized
INFO - 2018-07-25 00:53:45 --> Language Class Initialized
INFO - 2018-07-25 00:53:45 --> Language Class Initialized
INFO - 2018-07-25 00:53:45 --> Config Class Initialized
INFO - 2018-07-25 00:53:45 --> Loader Class Initialized
DEBUG - 2018-07-25 00:53:45 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-25 00:53:45 --> Helper loaded: url_helper
INFO - 2018-07-25 00:53:45 --> Helper loaded: form_helper
INFO - 2018-07-25 00:53:45 --> Helper loaded: date_helper
INFO - 2018-07-25 00:53:45 --> Helper loaded: util_helper
INFO - 2018-07-25 00:53:45 --> Helper loaded: text_helper
INFO - 2018-07-25 00:53:45 --> Helper loaded: string_helper
INFO - 2018-07-25 00:53:45 --> Database Driver Class Initialized
DEBUG - 2018-07-25 00:53:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 00:53:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 00:53:45 --> Email Class Initialized
INFO - 2018-07-25 00:53:45 --> Controller Class Initialized
DEBUG - 2018-07-25 00:53:45 --> Home MX_Controller Initialized
DEBUG - 2018-07-25 00:53:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-25 00:53:45 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-25 00:53:45 --> Login MX_Controller Initialized
INFO - 2018-07-25 00:53:45 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-25 00:53:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-25 00:53:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-25 00:53:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-07-25 00:53:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-07-25 00:53:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-07-25 00:53:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-07-25 00:53:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-07-25 00:53:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-07-25 00:53:46 --> Final output sent to browser
DEBUG - 2018-07-25 00:53:46 --> Total execution time: 0.5230
INFO - 2018-07-25 00:53:46 --> Config Class Initialized
INFO - 2018-07-25 00:53:46 --> Config Class Initialized
INFO - 2018-07-25 00:53:46 --> Config Class Initialized
INFO - 2018-07-25 00:53:46 --> Hooks Class Initialized
INFO - 2018-07-25 00:53:46 --> Hooks Class Initialized
INFO - 2018-07-25 00:53:46 --> Hooks Class Initialized
DEBUG - 2018-07-25 00:53:46 --> UTF-8 Support Enabled
DEBUG - 2018-07-25 00:53:46 --> UTF-8 Support Enabled
DEBUG - 2018-07-25 00:53:46 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:53:46 --> Utf8 Class Initialized
INFO - 2018-07-25 00:53:46 --> Utf8 Class Initialized
INFO - 2018-07-25 00:53:46 --> Utf8 Class Initialized
INFO - 2018-07-25 00:53:46 --> URI Class Initialized
INFO - 2018-07-25 00:53:46 --> URI Class Initialized
INFO - 2018-07-25 00:53:46 --> URI Class Initialized
INFO - 2018-07-25 00:53:46 --> Router Class Initialized
INFO - 2018-07-25 00:53:46 --> Router Class Initialized
INFO - 2018-07-25 00:53:46 --> Router Class Initialized
INFO - 2018-07-25 00:53:46 --> Output Class Initialized
INFO - 2018-07-25 00:53:46 --> Output Class Initialized
INFO - 2018-07-25 00:53:46 --> Output Class Initialized
INFO - 2018-07-25 00:53:46 --> Security Class Initialized
INFO - 2018-07-25 00:53:46 --> Security Class Initialized
INFO - 2018-07-25 00:53:46 --> Security Class Initialized
DEBUG - 2018-07-25 00:53:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-07-25 00:53:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-07-25 00:53:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:53:46 --> Input Class Initialized
INFO - 2018-07-25 00:53:46 --> Input Class Initialized
INFO - 2018-07-25 00:53:46 --> Input Class Initialized
INFO - 2018-07-25 00:53:46 --> Language Class Initialized
INFO - 2018-07-25 00:53:46 --> Language Class Initialized
INFO - 2018-07-25 00:53:46 --> Language Class Initialized
ERROR - 2018-07-25 00:53:46 --> 404 Page Not Found: /index
ERROR - 2018-07-25 00:53:46 --> 404 Page Not Found: /index
ERROR - 2018-07-25 00:53:46 --> 404 Page Not Found: /index
INFO - 2018-07-25 00:53:46 --> Config Class Initialized
INFO - 2018-07-25 00:53:46 --> Config Class Initialized
INFO - 2018-07-25 00:53:46 --> Config Class Initialized
INFO - 2018-07-25 00:53:46 --> Hooks Class Initialized
INFO - 2018-07-25 00:53:46 --> Hooks Class Initialized
INFO - 2018-07-25 00:53:46 --> Hooks Class Initialized
DEBUG - 2018-07-25 00:53:46 --> UTF-8 Support Enabled
DEBUG - 2018-07-25 00:53:46 --> UTF-8 Support Enabled
DEBUG - 2018-07-25 00:53:46 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:53:46 --> Utf8 Class Initialized
INFO - 2018-07-25 00:53:46 --> Utf8 Class Initialized
INFO - 2018-07-25 00:53:46 --> Utf8 Class Initialized
INFO - 2018-07-25 00:53:46 --> URI Class Initialized
INFO - 2018-07-25 00:53:46 --> URI Class Initialized
INFO - 2018-07-25 00:53:46 --> URI Class Initialized
INFO - 2018-07-25 00:53:46 --> Router Class Initialized
INFO - 2018-07-25 00:53:46 --> Router Class Initialized
INFO - 2018-07-25 00:53:46 --> Router Class Initialized
INFO - 2018-07-25 00:53:46 --> Output Class Initialized
INFO - 2018-07-25 00:53:46 --> Output Class Initialized
INFO - 2018-07-25 00:53:46 --> Output Class Initialized
INFO - 2018-07-25 00:53:46 --> Security Class Initialized
INFO - 2018-07-25 00:53:46 --> Security Class Initialized
INFO - 2018-07-25 00:53:46 --> Security Class Initialized
DEBUG - 2018-07-25 00:53:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-07-25 00:53:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-07-25 00:53:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:53:46 --> Input Class Initialized
INFO - 2018-07-25 00:53:46 --> Input Class Initialized
INFO - 2018-07-25 00:53:46 --> Input Class Initialized
INFO - 2018-07-25 00:53:46 --> Language Class Initialized
INFO - 2018-07-25 00:53:46 --> Language Class Initialized
INFO - 2018-07-25 00:53:46 --> Language Class Initialized
ERROR - 2018-07-25 00:53:46 --> 404 Page Not Found: /index
ERROR - 2018-07-25 00:53:46 --> 404 Page Not Found: /index
ERROR - 2018-07-25 00:53:46 --> 404 Page Not Found: /index
INFO - 2018-07-25 00:53:48 --> Config Class Initialized
INFO - 2018-07-25 00:53:48 --> Hooks Class Initialized
DEBUG - 2018-07-25 00:53:48 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:53:48 --> Utf8 Class Initialized
INFO - 2018-07-25 00:53:48 --> URI Class Initialized
INFO - 2018-07-25 00:53:48 --> Router Class Initialized
INFO - 2018-07-25 00:53:48 --> Output Class Initialized
INFO - 2018-07-25 00:53:48 --> Security Class Initialized
DEBUG - 2018-07-25 00:53:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:53:48 --> Input Class Initialized
INFO - 2018-07-25 00:53:48 --> Language Class Initialized
ERROR - 2018-07-25 00:53:48 --> 404 Page Not Found: /index
INFO - 2018-07-25 00:53:48 --> Config Class Initialized
INFO - 2018-07-25 00:53:48 --> Hooks Class Initialized
DEBUG - 2018-07-25 00:53:48 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:53:48 --> Utf8 Class Initialized
INFO - 2018-07-25 00:53:48 --> URI Class Initialized
INFO - 2018-07-25 00:53:48 --> Router Class Initialized
INFO - 2018-07-25 00:53:48 --> Output Class Initialized
INFO - 2018-07-25 00:53:48 --> Security Class Initialized
DEBUG - 2018-07-25 00:53:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:53:48 --> Input Class Initialized
INFO - 2018-07-25 00:53:49 --> Language Class Initialized
ERROR - 2018-07-25 00:53:49 --> 404 Page Not Found: /index
INFO - 2018-07-25 00:53:49 --> Config Class Initialized
INFO - 2018-07-25 00:53:49 --> Hooks Class Initialized
DEBUG - 2018-07-25 00:53:49 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:53:49 --> Utf8 Class Initialized
INFO - 2018-07-25 00:53:49 --> URI Class Initialized
INFO - 2018-07-25 00:53:49 --> Router Class Initialized
INFO - 2018-07-25 00:53:49 --> Output Class Initialized
INFO - 2018-07-25 00:53:49 --> Security Class Initialized
DEBUG - 2018-07-25 00:53:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:53:49 --> Input Class Initialized
INFO - 2018-07-25 00:53:49 --> Language Class Initialized
ERROR - 2018-07-25 00:53:49 --> 404 Page Not Found: /index
INFO - 2018-07-25 00:53:50 --> Config Class Initialized
INFO - 2018-07-25 00:53:50 --> Hooks Class Initialized
DEBUG - 2018-07-25 00:53:51 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:53:51 --> Utf8 Class Initialized
INFO - 2018-07-25 00:53:51 --> URI Class Initialized
INFO - 2018-07-25 00:53:51 --> Router Class Initialized
INFO - 2018-07-25 00:53:51 --> Output Class Initialized
INFO - 2018-07-25 00:53:51 --> Security Class Initialized
DEBUG - 2018-07-25 00:53:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:53:51 --> Input Class Initialized
INFO - 2018-07-25 00:53:51 --> Language Class Initialized
ERROR - 2018-07-25 00:53:51 --> 404 Page Not Found: /index
INFO - 2018-07-25 00:53:51 --> Config Class Initialized
INFO - 2018-07-25 00:53:51 --> Hooks Class Initialized
DEBUG - 2018-07-25 00:53:51 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:53:51 --> Utf8 Class Initialized
INFO - 2018-07-25 00:53:51 --> URI Class Initialized
INFO - 2018-07-25 00:53:51 --> Router Class Initialized
INFO - 2018-07-25 00:53:51 --> Output Class Initialized
INFO - 2018-07-25 00:53:51 --> Security Class Initialized
DEBUG - 2018-07-25 00:53:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:53:51 --> Input Class Initialized
INFO - 2018-07-25 00:53:51 --> Language Class Initialized
ERROR - 2018-07-25 00:53:51 --> 404 Page Not Found: /index
INFO - 2018-07-25 00:53:53 --> Config Class Initialized
INFO - 2018-07-25 00:53:53 --> Hooks Class Initialized
DEBUG - 2018-07-25 00:53:53 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:53:53 --> Utf8 Class Initialized
INFO - 2018-07-25 00:53:53 --> URI Class Initialized
INFO - 2018-07-25 00:53:53 --> Router Class Initialized
INFO - 2018-07-25 00:53:53 --> Output Class Initialized
INFO - 2018-07-25 00:53:53 --> Security Class Initialized
DEBUG - 2018-07-25 00:53:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:53:53 --> Input Class Initialized
INFO - 2018-07-25 00:53:53 --> Language Class Initialized
ERROR - 2018-07-25 00:53:53 --> 404 Page Not Found: /index
INFO - 2018-07-25 00:53:59 --> Config Class Initialized
INFO - 2018-07-25 00:53:59 --> Hooks Class Initialized
DEBUG - 2018-07-25 00:53:59 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:53:59 --> Utf8 Class Initialized
INFO - 2018-07-25 00:53:59 --> URI Class Initialized
DEBUG - 2018-07-25 00:53:59 --> No URI present. Default controller set.
INFO - 2018-07-25 00:53:59 --> Router Class Initialized
INFO - 2018-07-25 00:53:59 --> Output Class Initialized
INFO - 2018-07-25 00:53:59 --> Security Class Initialized
DEBUG - 2018-07-25 00:53:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:53:59 --> Input Class Initialized
INFO - 2018-07-25 00:53:59 --> Language Class Initialized
INFO - 2018-07-25 00:53:59 --> Language Class Initialized
INFO - 2018-07-25 00:53:59 --> Config Class Initialized
INFO - 2018-07-25 00:53:59 --> Loader Class Initialized
DEBUG - 2018-07-25 00:53:59 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-25 00:53:59 --> Helper loaded: url_helper
INFO - 2018-07-25 00:53:59 --> Helper loaded: form_helper
INFO - 2018-07-25 00:53:59 --> Helper loaded: date_helper
INFO - 2018-07-25 00:53:59 --> Helper loaded: util_helper
INFO - 2018-07-25 00:53:59 --> Helper loaded: text_helper
INFO - 2018-07-25 00:53:59 --> Helper loaded: string_helper
INFO - 2018-07-25 00:53:59 --> Database Driver Class Initialized
DEBUG - 2018-07-25 00:53:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 00:53:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 00:53:59 --> Email Class Initialized
INFO - 2018-07-25 00:53:59 --> Controller Class Initialized
DEBUG - 2018-07-25 00:53:59 --> Home MX_Controller Initialized
DEBUG - 2018-07-25 00:53:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-25 00:53:59 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-25 00:53:59 --> Login MX_Controller Initialized
INFO - 2018-07-25 00:53:59 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-25 00:53:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-25 00:53:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-25 00:53:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-07-25 00:53:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-07-25 00:53:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-07-25 00:53:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-07-25 00:53:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-07-25 00:53:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-07-25 00:53:59 --> Final output sent to browser
DEBUG - 2018-07-25 00:53:59 --> Total execution time: 0.5340
INFO - 2018-07-25 00:54:00 --> Config Class Initialized
INFO - 2018-07-25 00:54:00 --> Config Class Initialized
INFO - 2018-07-25 00:54:00 --> Config Class Initialized
INFO - 2018-07-25 00:54:00 --> Hooks Class Initialized
INFO - 2018-07-25 00:54:00 --> Hooks Class Initialized
INFO - 2018-07-25 00:54:00 --> Hooks Class Initialized
DEBUG - 2018-07-25 00:54:00 --> UTF-8 Support Enabled
DEBUG - 2018-07-25 00:54:00 --> UTF-8 Support Enabled
DEBUG - 2018-07-25 00:54:00 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:54:00 --> Utf8 Class Initialized
INFO - 2018-07-25 00:54:00 --> Utf8 Class Initialized
INFO - 2018-07-25 00:54:00 --> Utf8 Class Initialized
INFO - 2018-07-25 00:54:00 --> URI Class Initialized
INFO - 2018-07-25 00:54:00 --> URI Class Initialized
INFO - 2018-07-25 00:54:00 --> URI Class Initialized
INFO - 2018-07-25 00:54:00 --> Router Class Initialized
INFO - 2018-07-25 00:54:00 --> Router Class Initialized
INFO - 2018-07-25 00:54:00 --> Router Class Initialized
INFO - 2018-07-25 00:54:00 --> Output Class Initialized
INFO - 2018-07-25 00:54:00 --> Output Class Initialized
INFO - 2018-07-25 00:54:00 --> Output Class Initialized
INFO - 2018-07-25 00:54:00 --> Security Class Initialized
DEBUG - 2018-07-25 00:54:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:54:00 --> Security Class Initialized
INFO - 2018-07-25 00:54:00 --> Security Class Initialized
INFO - 2018-07-25 00:54:00 --> Input Class Initialized
DEBUG - 2018-07-25 00:54:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-07-25 00:54:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:54:00 --> Language Class Initialized
INFO - 2018-07-25 00:54:00 --> Input Class Initialized
ERROR - 2018-07-25 00:54:00 --> 404 Page Not Found: /index
INFO - 2018-07-25 00:54:00 --> Input Class Initialized
INFO - 2018-07-25 00:54:00 --> Language Class Initialized
INFO - 2018-07-25 00:54:00 --> Language Class Initialized
ERROR - 2018-07-25 00:54:00 --> 404 Page Not Found: /index
ERROR - 2018-07-25 00:54:00 --> 404 Page Not Found: /index
INFO - 2018-07-25 00:54:01 --> Config Class Initialized
INFO - 2018-07-25 00:54:01 --> Hooks Class Initialized
DEBUG - 2018-07-25 00:54:01 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:54:01 --> Utf8 Class Initialized
INFO - 2018-07-25 00:54:01 --> URI Class Initialized
INFO - 2018-07-25 00:54:01 --> Router Class Initialized
INFO - 2018-07-25 00:54:01 --> Output Class Initialized
INFO - 2018-07-25 00:54:01 --> Security Class Initialized
DEBUG - 2018-07-25 00:54:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:54:01 --> Input Class Initialized
INFO - 2018-07-25 00:54:01 --> Language Class Initialized
ERROR - 2018-07-25 00:54:01 --> 404 Page Not Found: /index
INFO - 2018-07-25 00:54:01 --> Config Class Initialized
INFO - 2018-07-25 00:54:01 --> Hooks Class Initialized
DEBUG - 2018-07-25 00:54:01 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:54:01 --> Utf8 Class Initialized
INFO - 2018-07-25 00:54:01 --> URI Class Initialized
INFO - 2018-07-25 00:54:01 --> Router Class Initialized
INFO - 2018-07-25 00:54:01 --> Output Class Initialized
INFO - 2018-07-25 00:54:01 --> Security Class Initialized
DEBUG - 2018-07-25 00:54:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:54:01 --> Input Class Initialized
INFO - 2018-07-25 00:54:01 --> Language Class Initialized
ERROR - 2018-07-25 00:54:01 --> 404 Page Not Found: /index
INFO - 2018-07-25 00:54:01 --> Config Class Initialized
INFO - 2018-07-25 00:54:01 --> Hooks Class Initialized
DEBUG - 2018-07-25 00:54:01 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:54:01 --> Utf8 Class Initialized
INFO - 2018-07-25 00:54:01 --> URI Class Initialized
INFO - 2018-07-25 00:54:01 --> Router Class Initialized
INFO - 2018-07-25 00:54:01 --> Output Class Initialized
INFO - 2018-07-25 00:54:01 --> Security Class Initialized
DEBUG - 2018-07-25 00:54:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:54:01 --> Input Class Initialized
INFO - 2018-07-25 00:54:01 --> Language Class Initialized
ERROR - 2018-07-25 00:54:01 --> 404 Page Not Found: /index
INFO - 2018-07-25 00:54:01 --> Config Class Initialized
INFO - 2018-07-25 00:54:01 --> Hooks Class Initialized
DEBUG - 2018-07-25 00:54:01 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:54:01 --> Utf8 Class Initialized
INFO - 2018-07-25 00:54:01 --> URI Class Initialized
INFO - 2018-07-25 00:54:01 --> Router Class Initialized
INFO - 2018-07-25 00:54:01 --> Output Class Initialized
INFO - 2018-07-25 00:54:01 --> Security Class Initialized
DEBUG - 2018-07-25 00:54:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:54:01 --> Input Class Initialized
INFO - 2018-07-25 00:54:01 --> Language Class Initialized
ERROR - 2018-07-25 00:54:01 --> 404 Page Not Found: /index
INFO - 2018-07-25 00:54:02 --> Config Class Initialized
INFO - 2018-07-25 00:54:02 --> Hooks Class Initialized
DEBUG - 2018-07-25 00:54:02 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:54:02 --> Utf8 Class Initialized
INFO - 2018-07-25 00:54:02 --> URI Class Initialized
INFO - 2018-07-25 00:54:02 --> Router Class Initialized
INFO - 2018-07-25 00:54:02 --> Output Class Initialized
INFO - 2018-07-25 00:54:02 --> Security Class Initialized
DEBUG - 2018-07-25 00:54:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:54:02 --> Input Class Initialized
INFO - 2018-07-25 00:54:02 --> Language Class Initialized
ERROR - 2018-07-25 00:54:02 --> 404 Page Not Found: /index
INFO - 2018-07-25 00:54:02 --> Config Class Initialized
INFO - 2018-07-25 00:54:02 --> Hooks Class Initialized
DEBUG - 2018-07-25 00:54:02 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:54:02 --> Utf8 Class Initialized
INFO - 2018-07-25 00:54:02 --> URI Class Initialized
INFO - 2018-07-25 00:54:02 --> Router Class Initialized
INFO - 2018-07-25 00:54:02 --> Output Class Initialized
INFO - 2018-07-25 00:54:02 --> Security Class Initialized
DEBUG - 2018-07-25 00:54:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:54:02 --> Input Class Initialized
INFO - 2018-07-25 00:54:02 --> Language Class Initialized
ERROR - 2018-07-25 00:54:02 --> 404 Page Not Found: /index
INFO - 2018-07-25 00:54:20 --> Config Class Initialized
INFO - 2018-07-25 00:54:20 --> Hooks Class Initialized
DEBUG - 2018-07-25 00:54:20 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:54:20 --> Utf8 Class Initialized
INFO - 2018-07-25 00:54:20 --> URI Class Initialized
DEBUG - 2018-07-25 00:54:20 --> No URI present. Default controller set.
INFO - 2018-07-25 00:54:20 --> Router Class Initialized
INFO - 2018-07-25 00:54:20 --> Output Class Initialized
INFO - 2018-07-25 00:54:20 --> Security Class Initialized
DEBUG - 2018-07-25 00:54:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:54:20 --> Input Class Initialized
INFO - 2018-07-25 00:54:20 --> Language Class Initialized
INFO - 2018-07-25 00:54:20 --> Language Class Initialized
INFO - 2018-07-25 00:54:20 --> Config Class Initialized
INFO - 2018-07-25 00:54:21 --> Loader Class Initialized
DEBUG - 2018-07-25 00:54:21 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-25 00:54:21 --> Helper loaded: url_helper
INFO - 2018-07-25 00:54:21 --> Helper loaded: form_helper
INFO - 2018-07-25 00:54:21 --> Helper loaded: date_helper
INFO - 2018-07-25 00:54:21 --> Helper loaded: util_helper
INFO - 2018-07-25 00:54:21 --> Helper loaded: text_helper
INFO - 2018-07-25 00:54:21 --> Helper loaded: string_helper
INFO - 2018-07-25 00:54:21 --> Database Driver Class Initialized
DEBUG - 2018-07-25 00:54:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 00:54:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 00:54:21 --> Email Class Initialized
INFO - 2018-07-25 00:54:21 --> Controller Class Initialized
DEBUG - 2018-07-25 00:54:21 --> Home MX_Controller Initialized
DEBUG - 2018-07-25 00:54:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-25 00:54:21 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-25 00:54:21 --> Login MX_Controller Initialized
INFO - 2018-07-25 00:54:21 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-25 00:54:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-25 00:54:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-25 00:54:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-07-25 00:54:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-07-25 00:54:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-07-25 00:54:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-07-25 00:54:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-07-25 00:54:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-07-25 00:54:21 --> Final output sent to browser
DEBUG - 2018-07-25 00:54:21 --> Total execution time: 0.5345
INFO - 2018-07-25 00:54:21 --> Config Class Initialized
INFO - 2018-07-25 00:54:21 --> Config Class Initialized
INFO - 2018-07-25 00:54:21 --> Config Class Initialized
INFO - 2018-07-25 00:54:21 --> Hooks Class Initialized
INFO - 2018-07-25 00:54:21 --> Hooks Class Initialized
INFO - 2018-07-25 00:54:21 --> Hooks Class Initialized
DEBUG - 2018-07-25 00:54:21 --> UTF-8 Support Enabled
DEBUG - 2018-07-25 00:54:21 --> UTF-8 Support Enabled
DEBUG - 2018-07-25 00:54:21 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:54:21 --> Utf8 Class Initialized
INFO - 2018-07-25 00:54:21 --> Utf8 Class Initialized
INFO - 2018-07-25 00:54:21 --> Utf8 Class Initialized
INFO - 2018-07-25 00:54:21 --> URI Class Initialized
INFO - 2018-07-25 00:54:21 --> URI Class Initialized
INFO - 2018-07-25 00:54:21 --> Router Class Initialized
INFO - 2018-07-25 00:54:21 --> URI Class Initialized
INFO - 2018-07-25 00:54:21 --> Router Class Initialized
INFO - 2018-07-25 00:54:21 --> Output Class Initialized
INFO - 2018-07-25 00:54:21 --> Router Class Initialized
INFO - 2018-07-25 00:54:21 --> Output Class Initialized
INFO - 2018-07-25 00:54:21 --> Security Class Initialized
INFO - 2018-07-25 00:54:21 --> Security Class Initialized
DEBUG - 2018-07-25 00:54:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:54:21 --> Output Class Initialized
DEBUG - 2018-07-25 00:54:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:54:21 --> Input Class Initialized
INFO - 2018-07-25 00:54:21 --> Input Class Initialized
INFO - 2018-07-25 00:54:21 --> Security Class Initialized
DEBUG - 2018-07-25 00:54:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:54:21 --> Language Class Initialized
INFO - 2018-07-25 00:54:21 --> Language Class Initialized
INFO - 2018-07-25 00:54:21 --> Input Class Initialized
ERROR - 2018-07-25 00:54:21 --> 404 Page Not Found: /index
ERROR - 2018-07-25 00:54:21 --> 404 Page Not Found: /index
INFO - 2018-07-25 00:54:21 --> Language Class Initialized
INFO - 2018-07-25 00:54:21 --> Config Class Initialized
INFO - 2018-07-25 00:54:21 --> Config Class Initialized
INFO - 2018-07-25 00:54:21 --> Hooks Class Initialized
INFO - 2018-07-25 00:54:21 --> Hooks Class Initialized
ERROR - 2018-07-25 00:54:21 --> 404 Page Not Found: /index
DEBUG - 2018-07-25 00:54:21 --> UTF-8 Support Enabled
DEBUG - 2018-07-25 00:54:21 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:54:21 --> Config Class Initialized
INFO - 2018-07-25 00:54:21 --> Hooks Class Initialized
INFO - 2018-07-25 00:54:21 --> Utf8 Class Initialized
INFO - 2018-07-25 00:54:21 --> Utf8 Class Initialized
INFO - 2018-07-25 00:54:21 --> URI Class Initialized
INFO - 2018-07-25 00:54:21 --> URI Class Initialized
DEBUG - 2018-07-25 00:54:21 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:54:21 --> Router Class Initialized
INFO - 2018-07-25 00:54:21 --> Utf8 Class Initialized
INFO - 2018-07-25 00:54:21 --> Router Class Initialized
INFO - 2018-07-25 00:54:21 --> Output Class Initialized
INFO - 2018-07-25 00:54:21 --> Output Class Initialized
INFO - 2018-07-25 00:54:21 --> URI Class Initialized
INFO - 2018-07-25 00:54:21 --> Security Class Initialized
INFO - 2018-07-25 00:54:21 --> Security Class Initialized
INFO - 2018-07-25 00:54:21 --> Router Class Initialized
DEBUG - 2018-07-25 00:54:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:54:21 --> Output Class Initialized
DEBUG - 2018-07-25 00:54:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:54:21 --> Input Class Initialized
INFO - 2018-07-25 00:54:21 --> Security Class Initialized
INFO - 2018-07-25 00:54:21 --> Input Class Initialized
INFO - 2018-07-25 00:54:21 --> Language Class Initialized
DEBUG - 2018-07-25 00:54:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:54:21 --> Language Class Initialized
INFO - 2018-07-25 00:54:21 --> Input Class Initialized
ERROR - 2018-07-25 00:54:21 --> 404 Page Not Found: /index
ERROR - 2018-07-25 00:54:21 --> 404 Page Not Found: /index
INFO - 2018-07-25 00:54:21 --> Language Class Initialized
ERROR - 2018-07-25 00:54:21 --> 404 Page Not Found: /index
INFO - 2018-07-25 00:54:24 --> Config Class Initialized
INFO - 2018-07-25 00:54:24 --> Hooks Class Initialized
DEBUG - 2018-07-25 00:54:24 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:54:24 --> Utf8 Class Initialized
INFO - 2018-07-25 00:54:24 --> URI Class Initialized
INFO - 2018-07-25 00:54:24 --> Router Class Initialized
INFO - 2018-07-25 00:54:24 --> Output Class Initialized
INFO - 2018-07-25 00:54:24 --> Security Class Initialized
DEBUG - 2018-07-25 00:54:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:54:24 --> Input Class Initialized
INFO - 2018-07-25 00:54:24 --> Language Class Initialized
ERROR - 2018-07-25 00:54:24 --> 404 Page Not Found: /index
INFO - 2018-07-25 00:54:24 --> Config Class Initialized
INFO - 2018-07-25 00:54:24 --> Hooks Class Initialized
DEBUG - 2018-07-25 00:54:24 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:54:24 --> Utf8 Class Initialized
INFO - 2018-07-25 00:54:24 --> URI Class Initialized
INFO - 2018-07-25 00:54:24 --> Router Class Initialized
INFO - 2018-07-25 00:54:24 --> Output Class Initialized
INFO - 2018-07-25 00:54:24 --> Security Class Initialized
DEBUG - 2018-07-25 00:54:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:54:24 --> Input Class Initialized
INFO - 2018-07-25 00:54:24 --> Language Class Initialized
ERROR - 2018-07-25 00:54:24 --> 404 Page Not Found: /index
INFO - 2018-07-25 00:54:26 --> Config Class Initialized
INFO - 2018-07-25 00:54:26 --> Hooks Class Initialized
DEBUG - 2018-07-25 00:54:26 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:54:26 --> Utf8 Class Initialized
INFO - 2018-07-25 00:54:26 --> URI Class Initialized
INFO - 2018-07-25 00:54:26 --> Router Class Initialized
INFO - 2018-07-25 00:54:26 --> Output Class Initialized
INFO - 2018-07-25 00:54:26 --> Security Class Initialized
DEBUG - 2018-07-25 00:54:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:54:26 --> Input Class Initialized
INFO - 2018-07-25 00:54:26 --> Language Class Initialized
ERROR - 2018-07-25 00:54:26 --> 404 Page Not Found: /index
INFO - 2018-07-25 00:54:26 --> Config Class Initialized
INFO - 2018-07-25 00:54:26 --> Hooks Class Initialized
DEBUG - 2018-07-25 00:54:26 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:54:26 --> Utf8 Class Initialized
INFO - 2018-07-25 00:54:26 --> URI Class Initialized
INFO - 2018-07-25 00:54:26 --> Router Class Initialized
INFO - 2018-07-25 00:54:26 --> Output Class Initialized
INFO - 2018-07-25 00:54:26 --> Security Class Initialized
DEBUG - 2018-07-25 00:54:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:54:26 --> Input Class Initialized
INFO - 2018-07-25 00:54:26 --> Language Class Initialized
ERROR - 2018-07-25 00:54:26 --> 404 Page Not Found: /index
INFO - 2018-07-25 00:54:26 --> Config Class Initialized
INFO - 2018-07-25 00:54:26 --> Hooks Class Initialized
DEBUG - 2018-07-25 00:54:26 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:54:26 --> Utf8 Class Initialized
INFO - 2018-07-25 00:54:26 --> URI Class Initialized
INFO - 2018-07-25 00:54:26 --> Router Class Initialized
INFO - 2018-07-25 00:54:26 --> Output Class Initialized
INFO - 2018-07-25 00:54:26 --> Security Class Initialized
DEBUG - 2018-07-25 00:54:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:54:26 --> Input Class Initialized
INFO - 2018-07-25 00:54:26 --> Language Class Initialized
ERROR - 2018-07-25 00:54:26 --> 404 Page Not Found: /index
INFO - 2018-07-25 00:54:26 --> Config Class Initialized
INFO - 2018-07-25 00:54:26 --> Hooks Class Initialized
DEBUG - 2018-07-25 00:54:26 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:54:26 --> Utf8 Class Initialized
INFO - 2018-07-25 00:54:26 --> URI Class Initialized
INFO - 2018-07-25 00:54:26 --> Router Class Initialized
INFO - 2018-07-25 00:54:26 --> Output Class Initialized
INFO - 2018-07-25 00:54:26 --> Security Class Initialized
DEBUG - 2018-07-25 00:54:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:54:26 --> Input Class Initialized
INFO - 2018-07-25 00:54:26 --> Language Class Initialized
ERROR - 2018-07-25 00:54:26 --> 404 Page Not Found: /index
INFO - 2018-07-25 00:55:07 --> Config Class Initialized
INFO - 2018-07-25 00:55:07 --> Hooks Class Initialized
DEBUG - 2018-07-25 00:55:07 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:55:07 --> Utf8 Class Initialized
INFO - 2018-07-25 00:55:07 --> URI Class Initialized
DEBUG - 2018-07-25 00:55:07 --> No URI present. Default controller set.
INFO - 2018-07-25 00:55:07 --> Router Class Initialized
INFO - 2018-07-25 00:55:07 --> Output Class Initialized
INFO - 2018-07-25 00:55:07 --> Security Class Initialized
DEBUG - 2018-07-25 00:55:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:55:07 --> Input Class Initialized
INFO - 2018-07-25 00:55:07 --> Language Class Initialized
INFO - 2018-07-25 00:55:07 --> Language Class Initialized
INFO - 2018-07-25 00:55:07 --> Config Class Initialized
INFO - 2018-07-25 00:55:07 --> Loader Class Initialized
DEBUG - 2018-07-25 00:55:07 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-25 00:55:07 --> Helper loaded: url_helper
INFO - 2018-07-25 00:55:07 --> Helper loaded: form_helper
INFO - 2018-07-25 00:55:07 --> Helper loaded: date_helper
INFO - 2018-07-25 00:55:07 --> Helper loaded: util_helper
INFO - 2018-07-25 00:55:07 --> Helper loaded: text_helper
INFO - 2018-07-25 00:55:07 --> Helper loaded: string_helper
INFO - 2018-07-25 00:55:07 --> Database Driver Class Initialized
DEBUG - 2018-07-25 00:55:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 00:55:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 00:55:07 --> Email Class Initialized
INFO - 2018-07-25 00:55:07 --> Controller Class Initialized
DEBUG - 2018-07-25 00:55:07 --> Home MX_Controller Initialized
DEBUG - 2018-07-25 00:55:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-25 00:55:07 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-25 00:55:07 --> Login MX_Controller Initialized
INFO - 2018-07-25 00:55:07 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-25 00:55:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-25 00:55:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-25 00:55:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-07-25 00:55:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-07-25 00:55:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-07-25 00:55:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-07-25 00:55:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-07-25 00:55:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-07-25 00:55:08 --> Final output sent to browser
DEBUG - 2018-07-25 00:55:08 --> Total execution time: 0.5809
INFO - 2018-07-25 00:55:08 --> Config Class Initialized
INFO - 2018-07-25 00:55:08 --> Hooks Class Initialized
DEBUG - 2018-07-25 00:55:08 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:55:08 --> Utf8 Class Initialized
INFO - 2018-07-25 00:55:08 --> URI Class Initialized
INFO - 2018-07-25 00:55:08 --> Router Class Initialized
INFO - 2018-07-25 00:55:08 --> Output Class Initialized
INFO - 2018-07-25 00:55:08 --> Security Class Initialized
DEBUG - 2018-07-25 00:55:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:55:08 --> Input Class Initialized
INFO - 2018-07-25 00:55:08 --> Language Class Initialized
ERROR - 2018-07-25 00:55:08 --> 404 Page Not Found: /index
INFO - 2018-07-25 00:55:09 --> Config Class Initialized
INFO - 2018-07-25 00:55:09 --> Hooks Class Initialized
DEBUG - 2018-07-25 00:55:09 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:55:09 --> Utf8 Class Initialized
INFO - 2018-07-25 00:55:09 --> URI Class Initialized
INFO - 2018-07-25 00:55:09 --> Router Class Initialized
INFO - 2018-07-25 00:55:09 --> Output Class Initialized
INFO - 2018-07-25 00:55:09 --> Security Class Initialized
DEBUG - 2018-07-25 00:55:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:55:09 --> Input Class Initialized
INFO - 2018-07-25 00:55:09 --> Language Class Initialized
ERROR - 2018-07-25 00:55:09 --> 404 Page Not Found: /index
INFO - 2018-07-25 00:55:09 --> Config Class Initialized
INFO - 2018-07-25 00:55:09 --> Hooks Class Initialized
DEBUG - 2018-07-25 00:55:09 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:55:09 --> Utf8 Class Initialized
INFO - 2018-07-25 00:55:09 --> URI Class Initialized
INFO - 2018-07-25 00:55:09 --> Router Class Initialized
INFO - 2018-07-25 00:55:09 --> Output Class Initialized
INFO - 2018-07-25 00:55:09 --> Security Class Initialized
DEBUG - 2018-07-25 00:55:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:55:09 --> Input Class Initialized
INFO - 2018-07-25 00:55:09 --> Language Class Initialized
ERROR - 2018-07-25 00:55:09 --> 404 Page Not Found: /index
INFO - 2018-07-25 00:58:36 --> Config Class Initialized
INFO - 2018-07-25 00:58:36 --> Hooks Class Initialized
DEBUG - 2018-07-25 00:58:36 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:58:36 --> Utf8 Class Initialized
INFO - 2018-07-25 00:58:36 --> URI Class Initialized
DEBUG - 2018-07-25 00:58:36 --> No URI present. Default controller set.
INFO - 2018-07-25 00:58:36 --> Router Class Initialized
INFO - 2018-07-25 00:58:36 --> Output Class Initialized
INFO - 2018-07-25 00:58:36 --> Security Class Initialized
DEBUG - 2018-07-25 00:58:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:58:36 --> Input Class Initialized
INFO - 2018-07-25 00:58:36 --> Language Class Initialized
INFO - 2018-07-25 00:58:36 --> Language Class Initialized
INFO - 2018-07-25 00:58:36 --> Config Class Initialized
INFO - 2018-07-25 00:58:36 --> Loader Class Initialized
DEBUG - 2018-07-25 00:58:36 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-25 00:58:36 --> Helper loaded: url_helper
INFO - 2018-07-25 00:58:36 --> Helper loaded: form_helper
INFO - 2018-07-25 00:58:36 --> Helper loaded: date_helper
INFO - 2018-07-25 00:58:36 --> Helper loaded: util_helper
INFO - 2018-07-25 00:58:36 --> Helper loaded: text_helper
INFO - 2018-07-25 00:58:36 --> Helper loaded: string_helper
INFO - 2018-07-25 00:58:36 --> Database Driver Class Initialized
DEBUG - 2018-07-25 00:58:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 00:58:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 00:58:36 --> Email Class Initialized
INFO - 2018-07-25 00:58:36 --> Controller Class Initialized
DEBUG - 2018-07-25 00:58:36 --> Home MX_Controller Initialized
DEBUG - 2018-07-25 00:58:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-25 00:58:36 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-25 00:58:36 --> Login MX_Controller Initialized
INFO - 2018-07-25 00:58:36 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-25 00:58:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-25 00:58:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-25 00:58:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-07-25 00:58:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-07-25 00:58:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-07-25 00:58:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-07-25 00:58:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-07-25 00:58:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-07-25 00:58:37 --> Final output sent to browser
DEBUG - 2018-07-25 00:58:37 --> Total execution time: 0.5950
INFO - 2018-07-25 00:58:38 --> Config Class Initialized
INFO - 2018-07-25 00:58:38 --> Hooks Class Initialized
DEBUG - 2018-07-25 00:58:38 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:58:38 --> Utf8 Class Initialized
INFO - 2018-07-25 00:58:38 --> URI Class Initialized
INFO - 2018-07-25 00:58:38 --> Router Class Initialized
INFO - 2018-07-25 00:58:38 --> Output Class Initialized
INFO - 2018-07-25 00:58:38 --> Security Class Initialized
DEBUG - 2018-07-25 00:58:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:58:38 --> Input Class Initialized
INFO - 2018-07-25 00:58:38 --> Language Class Initialized
ERROR - 2018-07-25 00:58:38 --> 404 Page Not Found: /index
INFO - 2018-07-25 00:58:38 --> Config Class Initialized
INFO - 2018-07-25 00:58:38 --> Hooks Class Initialized
DEBUG - 2018-07-25 00:58:38 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:58:38 --> Utf8 Class Initialized
INFO - 2018-07-25 00:58:38 --> URI Class Initialized
INFO - 2018-07-25 00:58:38 --> Router Class Initialized
INFO - 2018-07-25 00:58:38 --> Output Class Initialized
INFO - 2018-07-25 00:58:38 --> Security Class Initialized
DEBUG - 2018-07-25 00:58:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:58:38 --> Input Class Initialized
INFO - 2018-07-25 00:58:38 --> Language Class Initialized
ERROR - 2018-07-25 00:58:38 --> 404 Page Not Found: /index
INFO - 2018-07-25 00:58:38 --> Config Class Initialized
INFO - 2018-07-25 00:58:38 --> Hooks Class Initialized
DEBUG - 2018-07-25 00:58:39 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:58:39 --> Utf8 Class Initialized
INFO - 2018-07-25 00:58:39 --> URI Class Initialized
INFO - 2018-07-25 00:58:39 --> Router Class Initialized
INFO - 2018-07-25 00:58:39 --> Output Class Initialized
INFO - 2018-07-25 00:58:39 --> Security Class Initialized
DEBUG - 2018-07-25 00:58:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:58:39 --> Input Class Initialized
INFO - 2018-07-25 00:58:39 --> Language Class Initialized
ERROR - 2018-07-25 00:58:39 --> 404 Page Not Found: /index
INFO - 2018-07-25 00:59:17 --> Config Class Initialized
INFO - 2018-07-25 00:59:17 --> Hooks Class Initialized
DEBUG - 2018-07-25 00:59:17 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:59:17 --> Utf8 Class Initialized
INFO - 2018-07-25 00:59:17 --> URI Class Initialized
DEBUG - 2018-07-25 00:59:17 --> No URI present. Default controller set.
INFO - 2018-07-25 00:59:17 --> Router Class Initialized
INFO - 2018-07-25 00:59:17 --> Output Class Initialized
INFO - 2018-07-25 00:59:17 --> Security Class Initialized
DEBUG - 2018-07-25 00:59:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:59:17 --> Input Class Initialized
INFO - 2018-07-25 00:59:17 --> Language Class Initialized
INFO - 2018-07-25 00:59:17 --> Language Class Initialized
INFO - 2018-07-25 00:59:17 --> Config Class Initialized
INFO - 2018-07-25 00:59:17 --> Loader Class Initialized
DEBUG - 2018-07-25 00:59:17 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-25 00:59:17 --> Helper loaded: url_helper
INFO - 2018-07-25 00:59:17 --> Helper loaded: form_helper
INFO - 2018-07-25 00:59:17 --> Helper loaded: date_helper
INFO - 2018-07-25 00:59:17 --> Helper loaded: util_helper
INFO - 2018-07-25 00:59:17 --> Helper loaded: text_helper
INFO - 2018-07-25 00:59:17 --> Helper loaded: string_helper
INFO - 2018-07-25 00:59:17 --> Database Driver Class Initialized
DEBUG - 2018-07-25 00:59:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 00:59:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 00:59:17 --> Email Class Initialized
INFO - 2018-07-25 00:59:17 --> Controller Class Initialized
DEBUG - 2018-07-25 00:59:17 --> Home MX_Controller Initialized
DEBUG - 2018-07-25 00:59:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-25 00:59:17 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-25 00:59:17 --> Login MX_Controller Initialized
INFO - 2018-07-25 00:59:17 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-25 00:59:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-25 00:59:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-25 00:59:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-07-25 00:59:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-07-25 00:59:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-07-25 00:59:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-07-25 00:59:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-07-25 00:59:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-07-25 00:59:17 --> Final output sent to browser
DEBUG - 2018-07-25 00:59:17 --> Total execution time: 0.6180
INFO - 2018-07-25 00:59:18 --> Config Class Initialized
INFO - 2018-07-25 00:59:18 --> Hooks Class Initialized
DEBUG - 2018-07-25 00:59:18 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:59:18 --> Utf8 Class Initialized
INFO - 2018-07-25 00:59:18 --> URI Class Initialized
INFO - 2018-07-25 00:59:18 --> Router Class Initialized
INFO - 2018-07-25 00:59:18 --> Output Class Initialized
INFO - 2018-07-25 00:59:18 --> Security Class Initialized
DEBUG - 2018-07-25 00:59:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:59:18 --> Input Class Initialized
INFO - 2018-07-25 00:59:18 --> Language Class Initialized
ERROR - 2018-07-25 00:59:18 --> 404 Page Not Found: /index
INFO - 2018-07-25 00:59:18 --> Config Class Initialized
INFO - 2018-07-25 00:59:18 --> Hooks Class Initialized
DEBUG - 2018-07-25 00:59:18 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:59:18 --> Utf8 Class Initialized
INFO - 2018-07-25 00:59:18 --> URI Class Initialized
INFO - 2018-07-25 00:59:18 --> Router Class Initialized
INFO - 2018-07-25 00:59:18 --> Output Class Initialized
INFO - 2018-07-25 00:59:18 --> Security Class Initialized
DEBUG - 2018-07-25 00:59:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:59:19 --> Input Class Initialized
INFO - 2018-07-25 00:59:19 --> Language Class Initialized
ERROR - 2018-07-25 00:59:19 --> 404 Page Not Found: /index
INFO - 2018-07-25 00:59:19 --> Config Class Initialized
INFO - 2018-07-25 00:59:19 --> Hooks Class Initialized
DEBUG - 2018-07-25 00:59:19 --> UTF-8 Support Enabled
INFO - 2018-07-25 00:59:19 --> Utf8 Class Initialized
INFO - 2018-07-25 00:59:19 --> URI Class Initialized
INFO - 2018-07-25 00:59:19 --> Router Class Initialized
INFO - 2018-07-25 00:59:19 --> Output Class Initialized
INFO - 2018-07-25 00:59:19 --> Security Class Initialized
DEBUG - 2018-07-25 00:59:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 00:59:19 --> Input Class Initialized
INFO - 2018-07-25 00:59:19 --> Language Class Initialized
ERROR - 2018-07-25 00:59:19 --> 404 Page Not Found: /index
INFO - 2018-07-25 01:15:53 --> Config Class Initialized
INFO - 2018-07-25 01:15:53 --> Hooks Class Initialized
DEBUG - 2018-07-25 01:15:53 --> UTF-8 Support Enabled
INFO - 2018-07-25 01:15:53 --> Utf8 Class Initialized
INFO - 2018-07-25 01:15:53 --> URI Class Initialized
DEBUG - 2018-07-25 01:15:53 --> No URI present. Default controller set.
INFO - 2018-07-25 01:15:53 --> Router Class Initialized
INFO - 2018-07-25 01:15:54 --> Output Class Initialized
INFO - 2018-07-25 01:15:54 --> Security Class Initialized
DEBUG - 2018-07-25 01:15:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 01:15:54 --> Input Class Initialized
INFO - 2018-07-25 01:15:54 --> Language Class Initialized
INFO - 2018-07-25 01:15:54 --> Language Class Initialized
INFO - 2018-07-25 01:15:54 --> Config Class Initialized
INFO - 2018-07-25 01:15:54 --> Loader Class Initialized
DEBUG - 2018-07-25 01:15:54 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-25 01:15:54 --> Helper loaded: url_helper
INFO - 2018-07-25 01:15:54 --> Helper loaded: form_helper
INFO - 2018-07-25 01:15:54 --> Helper loaded: date_helper
INFO - 2018-07-25 01:15:54 --> Helper loaded: util_helper
INFO - 2018-07-25 01:15:54 --> Helper loaded: text_helper
INFO - 2018-07-25 01:15:54 --> Helper loaded: string_helper
INFO - 2018-07-25 01:15:54 --> Database Driver Class Initialized
DEBUG - 2018-07-25 01:15:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 01:15:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 01:15:54 --> Email Class Initialized
INFO - 2018-07-25 01:15:54 --> Controller Class Initialized
DEBUG - 2018-07-25 01:15:54 --> Home MX_Controller Initialized
DEBUG - 2018-07-25 01:15:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-25 01:15:54 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-25 01:15:54 --> Login MX_Controller Initialized
INFO - 2018-07-25 01:15:54 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-25 01:15:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-25 01:15:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-25 01:15:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-07-25 01:15:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-07-25 01:15:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-07-25 01:15:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-07-25 01:15:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-07-25 01:15:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-07-25 01:15:54 --> Final output sent to browser
DEBUG - 2018-07-25 01:15:54 --> Total execution time: 0.5705
INFO - 2018-07-25 01:15:55 --> Config Class Initialized
INFO - 2018-07-25 01:15:55 --> Hooks Class Initialized
DEBUG - 2018-07-25 01:15:55 --> UTF-8 Support Enabled
INFO - 2018-07-25 01:15:55 --> Utf8 Class Initialized
INFO - 2018-07-25 01:15:55 --> URI Class Initialized
INFO - 2018-07-25 01:15:55 --> Router Class Initialized
INFO - 2018-07-25 01:15:55 --> Output Class Initialized
INFO - 2018-07-25 01:15:55 --> Security Class Initialized
DEBUG - 2018-07-25 01:15:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 01:15:55 --> Input Class Initialized
INFO - 2018-07-25 01:15:56 --> Language Class Initialized
ERROR - 2018-07-25 01:15:56 --> 404 Page Not Found: /index
INFO - 2018-07-25 01:15:56 --> Config Class Initialized
INFO - 2018-07-25 01:15:56 --> Hooks Class Initialized
DEBUG - 2018-07-25 01:15:56 --> UTF-8 Support Enabled
INFO - 2018-07-25 01:15:56 --> Utf8 Class Initialized
INFO - 2018-07-25 01:15:56 --> URI Class Initialized
INFO - 2018-07-25 01:15:56 --> Router Class Initialized
INFO - 2018-07-25 01:15:56 --> Output Class Initialized
INFO - 2018-07-25 01:15:56 --> Security Class Initialized
DEBUG - 2018-07-25 01:15:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 01:15:56 --> Input Class Initialized
INFO - 2018-07-25 01:15:56 --> Language Class Initialized
ERROR - 2018-07-25 01:15:56 --> 404 Page Not Found: /index
INFO - 2018-07-25 01:15:56 --> Config Class Initialized
INFO - 2018-07-25 01:15:56 --> Hooks Class Initialized
DEBUG - 2018-07-25 01:15:56 --> UTF-8 Support Enabled
INFO - 2018-07-25 01:15:56 --> Utf8 Class Initialized
INFO - 2018-07-25 01:15:56 --> URI Class Initialized
INFO - 2018-07-25 01:15:56 --> Router Class Initialized
INFO - 2018-07-25 01:15:56 --> Output Class Initialized
INFO - 2018-07-25 01:15:56 --> Security Class Initialized
DEBUG - 2018-07-25 01:15:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 01:15:56 --> Input Class Initialized
INFO - 2018-07-25 01:15:56 --> Language Class Initialized
ERROR - 2018-07-25 01:15:56 --> 404 Page Not Found: /index
INFO - 2018-07-25 01:15:56 --> Config Class Initialized
INFO - 2018-07-25 01:15:56 --> Hooks Class Initialized
DEBUG - 2018-07-25 01:15:56 --> UTF-8 Support Enabled
INFO - 2018-07-25 01:15:56 --> Utf8 Class Initialized
INFO - 2018-07-25 01:15:56 --> URI Class Initialized
INFO - 2018-07-25 01:15:56 --> Router Class Initialized
INFO - 2018-07-25 01:15:56 --> Output Class Initialized
INFO - 2018-07-25 01:15:56 --> Security Class Initialized
DEBUG - 2018-07-25 01:15:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 01:15:56 --> Input Class Initialized
INFO - 2018-07-25 01:15:56 --> Language Class Initialized
ERROR - 2018-07-25 01:15:56 --> 404 Page Not Found: /index
INFO - 2018-07-25 01:15:56 --> Config Class Initialized
INFO - 2018-07-25 01:15:56 --> Hooks Class Initialized
DEBUG - 2018-07-25 01:15:56 --> UTF-8 Support Enabled
INFO - 2018-07-25 01:15:56 --> Utf8 Class Initialized
INFO - 2018-07-25 01:15:56 --> URI Class Initialized
INFO - 2018-07-25 01:15:56 --> Router Class Initialized
INFO - 2018-07-25 01:15:56 --> Output Class Initialized
INFO - 2018-07-25 01:15:56 --> Security Class Initialized
DEBUG - 2018-07-25 01:15:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 01:15:56 --> Input Class Initialized
INFO - 2018-07-25 01:15:56 --> Language Class Initialized
ERROR - 2018-07-25 01:15:56 --> 404 Page Not Found: /index
INFO - 2018-07-25 01:15:56 --> Config Class Initialized
INFO - 2018-07-25 01:15:56 --> Hooks Class Initialized
DEBUG - 2018-07-25 01:15:56 --> UTF-8 Support Enabled
INFO - 2018-07-25 01:15:56 --> Utf8 Class Initialized
INFO - 2018-07-25 01:15:56 --> URI Class Initialized
INFO - 2018-07-25 01:15:56 --> Router Class Initialized
INFO - 2018-07-25 01:15:56 --> Output Class Initialized
INFO - 2018-07-25 01:15:56 --> Security Class Initialized
DEBUG - 2018-07-25 01:15:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 01:15:56 --> Input Class Initialized
INFO - 2018-07-25 01:15:56 --> Language Class Initialized
ERROR - 2018-07-25 01:15:56 --> 404 Page Not Found: /index
INFO - 2018-07-25 01:16:32 --> Config Class Initialized
INFO - 2018-07-25 01:16:32 --> Hooks Class Initialized
DEBUG - 2018-07-25 01:16:32 --> UTF-8 Support Enabled
INFO - 2018-07-25 01:16:32 --> Utf8 Class Initialized
INFO - 2018-07-25 01:16:32 --> URI Class Initialized
DEBUG - 2018-07-25 01:16:32 --> No URI present. Default controller set.
INFO - 2018-07-25 01:16:32 --> Router Class Initialized
INFO - 2018-07-25 01:16:32 --> Output Class Initialized
INFO - 2018-07-25 01:16:32 --> Security Class Initialized
DEBUG - 2018-07-25 01:16:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 01:16:32 --> Input Class Initialized
INFO - 2018-07-25 01:16:32 --> Language Class Initialized
INFO - 2018-07-25 01:16:32 --> Language Class Initialized
INFO - 2018-07-25 01:16:32 --> Config Class Initialized
INFO - 2018-07-25 01:16:32 --> Loader Class Initialized
DEBUG - 2018-07-25 01:16:32 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-25 01:16:32 --> Helper loaded: url_helper
INFO - 2018-07-25 01:16:32 --> Helper loaded: form_helper
INFO - 2018-07-25 01:16:32 --> Helper loaded: date_helper
INFO - 2018-07-25 01:16:32 --> Helper loaded: util_helper
INFO - 2018-07-25 01:16:32 --> Helper loaded: text_helper
INFO - 2018-07-25 01:16:32 --> Helper loaded: string_helper
INFO - 2018-07-25 01:16:32 --> Database Driver Class Initialized
DEBUG - 2018-07-25 01:16:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 01:16:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 01:16:32 --> Email Class Initialized
INFO - 2018-07-25 01:16:32 --> Controller Class Initialized
DEBUG - 2018-07-25 01:16:32 --> Home MX_Controller Initialized
DEBUG - 2018-07-25 01:16:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-25 01:16:32 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-25 01:16:32 --> Login MX_Controller Initialized
INFO - 2018-07-25 01:16:32 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-25 01:16:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-25 01:16:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-25 01:16:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-07-25 01:16:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-07-25 01:16:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-07-25 01:16:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-07-25 01:16:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-07-25 01:16:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-07-25 01:16:32 --> Final output sent to browser
DEBUG - 2018-07-25 01:16:32 --> Total execution time: 0.6761
INFO - 2018-07-25 01:16:33 --> Config Class Initialized
INFO - 2018-07-25 01:16:33 --> Hooks Class Initialized
DEBUG - 2018-07-25 01:16:33 --> UTF-8 Support Enabled
INFO - 2018-07-25 01:16:33 --> Utf8 Class Initialized
INFO - 2018-07-25 01:16:33 --> URI Class Initialized
INFO - 2018-07-25 01:16:33 --> Router Class Initialized
INFO - 2018-07-25 01:16:33 --> Output Class Initialized
INFO - 2018-07-25 01:16:33 --> Security Class Initialized
DEBUG - 2018-07-25 01:16:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 01:16:33 --> Input Class Initialized
INFO - 2018-07-25 01:16:33 --> Language Class Initialized
ERROR - 2018-07-25 01:16:33 --> 404 Page Not Found: /index
INFO - 2018-07-25 01:16:34 --> Config Class Initialized
INFO - 2018-07-25 01:16:34 --> Hooks Class Initialized
DEBUG - 2018-07-25 01:16:34 --> UTF-8 Support Enabled
INFO - 2018-07-25 01:16:34 --> Utf8 Class Initialized
INFO - 2018-07-25 01:16:34 --> URI Class Initialized
INFO - 2018-07-25 01:16:34 --> Router Class Initialized
INFO - 2018-07-25 01:16:34 --> Output Class Initialized
INFO - 2018-07-25 01:16:34 --> Security Class Initialized
DEBUG - 2018-07-25 01:16:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 01:16:34 --> Input Class Initialized
INFO - 2018-07-25 01:16:34 --> Language Class Initialized
ERROR - 2018-07-25 01:16:34 --> 404 Page Not Found: /index
INFO - 2018-07-25 01:16:34 --> Config Class Initialized
INFO - 2018-07-25 01:16:34 --> Hooks Class Initialized
DEBUG - 2018-07-25 01:16:34 --> UTF-8 Support Enabled
INFO - 2018-07-25 01:16:34 --> Utf8 Class Initialized
INFO - 2018-07-25 01:16:34 --> URI Class Initialized
INFO - 2018-07-25 01:16:34 --> Router Class Initialized
INFO - 2018-07-25 01:16:34 --> Output Class Initialized
INFO - 2018-07-25 01:16:34 --> Security Class Initialized
DEBUG - 2018-07-25 01:16:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 01:16:34 --> Input Class Initialized
INFO - 2018-07-25 01:16:34 --> Language Class Initialized
ERROR - 2018-07-25 01:16:34 --> 404 Page Not Found: /index
INFO - 2018-07-25 01:16:41 --> Config Class Initialized
INFO - 2018-07-25 01:16:42 --> Hooks Class Initialized
DEBUG - 2018-07-25 01:16:42 --> UTF-8 Support Enabled
INFO - 2018-07-25 01:16:42 --> Utf8 Class Initialized
INFO - 2018-07-25 01:16:42 --> URI Class Initialized
DEBUG - 2018-07-25 01:16:42 --> No URI present. Default controller set.
INFO - 2018-07-25 01:16:42 --> Router Class Initialized
INFO - 2018-07-25 01:16:42 --> Output Class Initialized
INFO - 2018-07-25 01:16:42 --> Security Class Initialized
DEBUG - 2018-07-25 01:16:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 01:16:42 --> Input Class Initialized
INFO - 2018-07-25 01:16:42 --> Language Class Initialized
INFO - 2018-07-25 01:16:42 --> Language Class Initialized
INFO - 2018-07-25 01:16:42 --> Config Class Initialized
INFO - 2018-07-25 01:16:42 --> Loader Class Initialized
DEBUG - 2018-07-25 01:16:42 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-25 01:16:42 --> Helper loaded: url_helper
INFO - 2018-07-25 01:16:42 --> Helper loaded: form_helper
INFO - 2018-07-25 01:16:42 --> Helper loaded: date_helper
INFO - 2018-07-25 01:16:42 --> Helper loaded: util_helper
INFO - 2018-07-25 01:16:42 --> Helper loaded: text_helper
INFO - 2018-07-25 01:16:42 --> Helper loaded: string_helper
INFO - 2018-07-25 01:16:42 --> Database Driver Class Initialized
DEBUG - 2018-07-25 01:16:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 01:16:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 01:16:42 --> Email Class Initialized
INFO - 2018-07-25 01:16:42 --> Controller Class Initialized
DEBUG - 2018-07-25 01:16:42 --> Home MX_Controller Initialized
DEBUG - 2018-07-25 01:16:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-25 01:16:42 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-25 01:16:42 --> Login MX_Controller Initialized
INFO - 2018-07-25 01:16:42 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-25 01:16:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-25 01:16:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-25 01:16:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-07-25 01:16:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-07-25 01:16:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-07-25 01:16:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-07-25 01:16:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-07-25 01:16:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-07-25 01:16:42 --> Final output sent to browser
DEBUG - 2018-07-25 01:16:42 --> Total execution time: 0.6857
INFO - 2018-07-25 01:16:42 --> Config Class Initialized
INFO - 2018-07-25 01:16:42 --> Hooks Class Initialized
DEBUG - 2018-07-25 01:16:42 --> UTF-8 Support Enabled
INFO - 2018-07-25 01:16:42 --> Utf8 Class Initialized
INFO - 2018-07-25 01:16:42 --> URI Class Initialized
DEBUG - 2018-07-25 01:16:42 --> No URI present. Default controller set.
INFO - 2018-07-25 01:16:42 --> Router Class Initialized
INFO - 2018-07-25 01:16:42 --> Output Class Initialized
INFO - 2018-07-25 01:16:42 --> Security Class Initialized
DEBUG - 2018-07-25 01:16:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 01:16:42 --> Input Class Initialized
INFO - 2018-07-25 01:16:42 --> Language Class Initialized
INFO - 2018-07-25 01:16:42 --> Language Class Initialized
INFO - 2018-07-25 01:16:42 --> Config Class Initialized
INFO - 2018-07-25 01:16:43 --> Loader Class Initialized
DEBUG - 2018-07-25 01:16:43 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-25 01:16:43 --> Helper loaded: url_helper
INFO - 2018-07-25 01:16:43 --> Helper loaded: form_helper
INFO - 2018-07-25 01:16:43 --> Helper loaded: date_helper
INFO - 2018-07-25 01:16:43 --> Helper loaded: util_helper
INFO - 2018-07-25 01:16:43 --> Helper loaded: text_helper
INFO - 2018-07-25 01:16:43 --> Helper loaded: string_helper
INFO - 2018-07-25 01:16:43 --> Database Driver Class Initialized
DEBUG - 2018-07-25 01:16:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 01:16:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 01:16:43 --> Email Class Initialized
INFO - 2018-07-25 01:16:43 --> Controller Class Initialized
DEBUG - 2018-07-25 01:16:43 --> Home MX_Controller Initialized
DEBUG - 2018-07-25 01:16:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-25 01:16:43 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-25 01:16:43 --> Login MX_Controller Initialized
INFO - 2018-07-25 01:16:43 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-25 01:16:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-25 01:16:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-25 01:16:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-07-25 01:16:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-07-25 01:16:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-07-25 01:16:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-07-25 01:16:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-07-25 01:16:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-07-25 01:16:43 --> Final output sent to browser
DEBUG - 2018-07-25 01:16:43 --> Total execution time: 0.6400
INFO - 2018-07-25 01:16:44 --> Config Class Initialized
INFO - 2018-07-25 01:16:44 --> Hooks Class Initialized
DEBUG - 2018-07-25 01:16:44 --> UTF-8 Support Enabled
INFO - 2018-07-25 01:16:44 --> Utf8 Class Initialized
INFO - 2018-07-25 01:16:44 --> URI Class Initialized
INFO - 2018-07-25 01:16:44 --> Router Class Initialized
INFO - 2018-07-25 01:16:44 --> Output Class Initialized
INFO - 2018-07-25 01:16:44 --> Security Class Initialized
DEBUG - 2018-07-25 01:16:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 01:16:44 --> Input Class Initialized
INFO - 2018-07-25 01:16:44 --> Language Class Initialized
ERROR - 2018-07-25 01:16:44 --> 404 Page Not Found: /index
INFO - 2018-07-25 01:16:44 --> Config Class Initialized
INFO - 2018-07-25 01:16:44 --> Hooks Class Initialized
DEBUG - 2018-07-25 01:16:44 --> UTF-8 Support Enabled
INFO - 2018-07-25 01:16:44 --> Utf8 Class Initialized
INFO - 2018-07-25 01:16:44 --> URI Class Initialized
INFO - 2018-07-25 01:16:44 --> Router Class Initialized
INFO - 2018-07-25 01:16:44 --> Output Class Initialized
INFO - 2018-07-25 01:16:44 --> Security Class Initialized
DEBUG - 2018-07-25 01:16:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 01:16:44 --> Input Class Initialized
INFO - 2018-07-25 01:16:44 --> Language Class Initialized
ERROR - 2018-07-25 01:16:44 --> 404 Page Not Found: /index
INFO - 2018-07-25 01:16:44 --> Config Class Initialized
INFO - 2018-07-25 01:16:44 --> Hooks Class Initialized
DEBUG - 2018-07-25 01:16:44 --> UTF-8 Support Enabled
INFO - 2018-07-25 01:16:44 --> Utf8 Class Initialized
INFO - 2018-07-25 01:16:44 --> URI Class Initialized
INFO - 2018-07-25 01:16:44 --> Router Class Initialized
INFO - 2018-07-25 01:16:44 --> Output Class Initialized
INFO - 2018-07-25 01:16:44 --> Security Class Initialized
DEBUG - 2018-07-25 01:16:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 01:16:44 --> Input Class Initialized
INFO - 2018-07-25 01:16:44 --> Language Class Initialized
ERROR - 2018-07-25 01:16:44 --> 404 Page Not Found: /index
INFO - 2018-07-25 01:16:56 --> Config Class Initialized
INFO - 2018-07-25 01:16:56 --> Hooks Class Initialized
DEBUG - 2018-07-25 01:16:56 --> UTF-8 Support Enabled
INFO - 2018-07-25 01:16:56 --> Utf8 Class Initialized
INFO - 2018-07-25 01:16:56 --> URI Class Initialized
DEBUG - 2018-07-25 01:16:56 --> No URI present. Default controller set.
INFO - 2018-07-25 01:16:56 --> Router Class Initialized
INFO - 2018-07-25 01:16:56 --> Output Class Initialized
INFO - 2018-07-25 01:16:56 --> Security Class Initialized
DEBUG - 2018-07-25 01:16:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 01:16:56 --> Input Class Initialized
INFO - 2018-07-25 01:16:56 --> Language Class Initialized
INFO - 2018-07-25 01:16:56 --> Language Class Initialized
INFO - 2018-07-25 01:16:56 --> Config Class Initialized
INFO - 2018-07-25 01:16:56 --> Loader Class Initialized
DEBUG - 2018-07-25 01:16:56 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-25 01:16:56 --> Helper loaded: url_helper
INFO - 2018-07-25 01:16:56 --> Helper loaded: form_helper
INFO - 2018-07-25 01:16:56 --> Helper loaded: date_helper
INFO - 2018-07-25 01:16:56 --> Helper loaded: util_helper
INFO - 2018-07-25 01:16:57 --> Helper loaded: text_helper
INFO - 2018-07-25 01:16:57 --> Helper loaded: string_helper
INFO - 2018-07-25 01:16:57 --> Database Driver Class Initialized
DEBUG - 2018-07-25 01:16:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 01:16:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 01:16:57 --> Email Class Initialized
INFO - 2018-07-25 01:16:57 --> Controller Class Initialized
DEBUG - 2018-07-25 01:16:57 --> Home MX_Controller Initialized
DEBUG - 2018-07-25 01:16:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-25 01:16:57 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-25 01:16:57 --> Login MX_Controller Initialized
INFO - 2018-07-25 01:16:57 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-25 01:16:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-25 01:16:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-25 01:16:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-07-25 01:16:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-07-25 01:16:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-07-25 01:16:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-07-25 01:16:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-07-25 01:16:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-07-25 01:16:57 --> Final output sent to browser
DEBUG - 2018-07-25 01:16:57 --> Total execution time: 0.6109
INFO - 2018-07-25 01:16:57 --> Config Class Initialized
INFO - 2018-07-25 01:16:57 --> Hooks Class Initialized
DEBUG - 2018-07-25 01:16:57 --> UTF-8 Support Enabled
INFO - 2018-07-25 01:16:57 --> Utf8 Class Initialized
INFO - 2018-07-25 01:16:57 --> URI Class Initialized
INFO - 2018-07-25 01:16:57 --> Router Class Initialized
INFO - 2018-07-25 01:16:57 --> Output Class Initialized
INFO - 2018-07-25 01:16:58 --> Security Class Initialized
DEBUG - 2018-07-25 01:16:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 01:16:58 --> Input Class Initialized
INFO - 2018-07-25 01:16:58 --> Language Class Initialized
ERROR - 2018-07-25 01:16:58 --> 404 Page Not Found: /index
INFO - 2018-07-25 01:16:58 --> Config Class Initialized
INFO - 2018-07-25 01:16:58 --> Hooks Class Initialized
DEBUG - 2018-07-25 01:16:58 --> UTF-8 Support Enabled
INFO - 2018-07-25 01:16:58 --> Utf8 Class Initialized
INFO - 2018-07-25 01:16:58 --> URI Class Initialized
INFO - 2018-07-25 01:16:58 --> Router Class Initialized
INFO - 2018-07-25 01:16:58 --> Output Class Initialized
INFO - 2018-07-25 01:16:58 --> Security Class Initialized
DEBUG - 2018-07-25 01:16:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 01:16:58 --> Input Class Initialized
INFO - 2018-07-25 01:16:58 --> Language Class Initialized
ERROR - 2018-07-25 01:16:58 --> 404 Page Not Found: /index
INFO - 2018-07-25 01:16:58 --> Config Class Initialized
INFO - 2018-07-25 01:16:58 --> Hooks Class Initialized
DEBUG - 2018-07-25 01:16:58 --> UTF-8 Support Enabled
INFO - 2018-07-25 01:16:58 --> Utf8 Class Initialized
INFO - 2018-07-25 01:16:58 --> URI Class Initialized
INFO - 2018-07-25 01:16:58 --> Router Class Initialized
INFO - 2018-07-25 01:16:58 --> Output Class Initialized
INFO - 2018-07-25 01:16:58 --> Security Class Initialized
DEBUG - 2018-07-25 01:16:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 01:16:58 --> Input Class Initialized
INFO - 2018-07-25 01:16:58 --> Language Class Initialized
ERROR - 2018-07-25 01:16:58 --> 404 Page Not Found: /index
INFO - 2018-07-25 01:17:09 --> Config Class Initialized
INFO - 2018-07-25 01:17:09 --> Hooks Class Initialized
DEBUG - 2018-07-25 01:17:09 --> UTF-8 Support Enabled
INFO - 2018-07-25 01:17:09 --> Utf8 Class Initialized
INFO - 2018-07-25 01:17:09 --> URI Class Initialized
DEBUG - 2018-07-25 01:17:09 --> No URI present. Default controller set.
INFO - 2018-07-25 01:17:09 --> Router Class Initialized
INFO - 2018-07-25 01:17:09 --> Output Class Initialized
INFO - 2018-07-25 01:17:09 --> Security Class Initialized
DEBUG - 2018-07-25 01:17:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 01:17:09 --> Input Class Initialized
INFO - 2018-07-25 01:17:09 --> Language Class Initialized
INFO - 2018-07-25 01:17:09 --> Language Class Initialized
INFO - 2018-07-25 01:17:09 --> Config Class Initialized
INFO - 2018-07-25 01:17:09 --> Loader Class Initialized
DEBUG - 2018-07-25 01:17:09 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-25 01:17:09 --> Helper loaded: url_helper
INFO - 2018-07-25 01:17:09 --> Helper loaded: form_helper
INFO - 2018-07-25 01:17:09 --> Helper loaded: date_helper
INFO - 2018-07-25 01:17:09 --> Helper loaded: util_helper
INFO - 2018-07-25 01:17:09 --> Helper loaded: text_helper
INFO - 2018-07-25 01:17:09 --> Helper loaded: string_helper
INFO - 2018-07-25 01:17:09 --> Database Driver Class Initialized
DEBUG - 2018-07-25 01:17:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 01:17:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 01:17:09 --> Email Class Initialized
INFO - 2018-07-25 01:17:09 --> Controller Class Initialized
DEBUG - 2018-07-25 01:17:09 --> Home MX_Controller Initialized
DEBUG - 2018-07-25 01:17:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-25 01:17:09 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-25 01:17:09 --> Login MX_Controller Initialized
INFO - 2018-07-25 01:17:09 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-25 01:17:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-25 01:17:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-25 01:17:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-07-25 01:17:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-07-25 01:17:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-07-25 01:17:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-07-25 01:17:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-07-25 01:17:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-07-25 01:17:09 --> Final output sent to browser
DEBUG - 2018-07-25 01:17:09 --> Total execution time: 0.6217
INFO - 2018-07-25 01:17:10 --> Config Class Initialized
INFO - 2018-07-25 01:17:10 --> Hooks Class Initialized
DEBUG - 2018-07-25 01:17:10 --> UTF-8 Support Enabled
INFO - 2018-07-25 01:17:10 --> Utf8 Class Initialized
INFO - 2018-07-25 01:17:10 --> URI Class Initialized
INFO - 2018-07-25 01:17:10 --> Router Class Initialized
INFO - 2018-07-25 01:17:10 --> Output Class Initialized
INFO - 2018-07-25 01:17:10 --> Security Class Initialized
DEBUG - 2018-07-25 01:17:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 01:17:10 --> Input Class Initialized
INFO - 2018-07-25 01:17:10 --> Language Class Initialized
ERROR - 2018-07-25 01:17:10 --> 404 Page Not Found: /index
INFO - 2018-07-25 01:17:10 --> Config Class Initialized
INFO - 2018-07-25 01:17:10 --> Hooks Class Initialized
DEBUG - 2018-07-25 01:17:10 --> UTF-8 Support Enabled
INFO - 2018-07-25 01:17:10 --> Utf8 Class Initialized
INFO - 2018-07-25 01:17:10 --> URI Class Initialized
INFO - 2018-07-25 01:17:10 --> Router Class Initialized
INFO - 2018-07-25 01:17:10 --> Output Class Initialized
INFO - 2018-07-25 01:17:10 --> Security Class Initialized
DEBUG - 2018-07-25 01:17:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 01:17:10 --> Input Class Initialized
INFO - 2018-07-25 01:17:10 --> Language Class Initialized
ERROR - 2018-07-25 01:17:10 --> 404 Page Not Found: /index
INFO - 2018-07-25 01:17:10 --> Config Class Initialized
INFO - 2018-07-25 01:17:10 --> Hooks Class Initialized
DEBUG - 2018-07-25 01:17:10 --> UTF-8 Support Enabled
INFO - 2018-07-25 01:17:10 --> Utf8 Class Initialized
INFO - 2018-07-25 01:17:10 --> URI Class Initialized
INFO - 2018-07-25 01:17:10 --> Router Class Initialized
INFO - 2018-07-25 01:17:10 --> Output Class Initialized
INFO - 2018-07-25 01:17:10 --> Security Class Initialized
DEBUG - 2018-07-25 01:17:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 01:17:10 --> Input Class Initialized
INFO - 2018-07-25 01:17:10 --> Language Class Initialized
ERROR - 2018-07-25 01:17:10 --> 404 Page Not Found: /index
INFO - 2018-07-25 01:19:30 --> Config Class Initialized
INFO - 2018-07-25 01:19:30 --> Hooks Class Initialized
DEBUG - 2018-07-25 01:19:30 --> UTF-8 Support Enabled
INFO - 2018-07-25 01:19:30 --> Utf8 Class Initialized
INFO - 2018-07-25 01:19:30 --> URI Class Initialized
DEBUG - 2018-07-25 01:19:30 --> No URI present. Default controller set.
INFO - 2018-07-25 01:19:30 --> Router Class Initialized
INFO - 2018-07-25 01:19:30 --> Output Class Initialized
INFO - 2018-07-25 01:19:30 --> Security Class Initialized
DEBUG - 2018-07-25 01:19:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 01:19:30 --> Input Class Initialized
INFO - 2018-07-25 01:19:30 --> Language Class Initialized
INFO - 2018-07-25 01:19:30 --> Language Class Initialized
INFO - 2018-07-25 01:19:30 --> Config Class Initialized
INFO - 2018-07-25 01:19:30 --> Loader Class Initialized
DEBUG - 2018-07-25 01:19:30 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-25 01:19:30 --> Helper loaded: url_helper
INFO - 2018-07-25 01:19:30 --> Helper loaded: form_helper
INFO - 2018-07-25 01:19:30 --> Helper loaded: date_helper
INFO - 2018-07-25 01:19:30 --> Helper loaded: util_helper
INFO - 2018-07-25 01:19:30 --> Helper loaded: text_helper
INFO - 2018-07-25 01:19:30 --> Helper loaded: string_helper
INFO - 2018-07-25 01:19:30 --> Database Driver Class Initialized
DEBUG - 2018-07-25 01:19:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 01:19:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 01:19:30 --> Email Class Initialized
INFO - 2018-07-25 01:19:30 --> Controller Class Initialized
DEBUG - 2018-07-25 01:19:30 --> Home MX_Controller Initialized
DEBUG - 2018-07-25 01:19:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-25 01:19:30 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-25 01:19:30 --> Login MX_Controller Initialized
INFO - 2018-07-25 01:19:30 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-25 01:19:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-25 01:19:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-25 01:19:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-07-25 01:19:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-07-25 01:19:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-07-25 01:19:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-07-25 01:19:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-07-25 01:19:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-07-25 01:19:30 --> Final output sent to browser
DEBUG - 2018-07-25 01:19:30 --> Total execution time: 0.6585
INFO - 2018-07-25 01:19:31 --> Config Class Initialized
INFO - 2018-07-25 01:19:31 --> Hooks Class Initialized
DEBUG - 2018-07-25 01:19:31 --> UTF-8 Support Enabled
INFO - 2018-07-25 01:19:31 --> Utf8 Class Initialized
INFO - 2018-07-25 01:19:31 --> URI Class Initialized
INFO - 2018-07-25 01:19:31 --> Router Class Initialized
INFO - 2018-07-25 01:19:31 --> Output Class Initialized
INFO - 2018-07-25 01:19:31 --> Security Class Initialized
DEBUG - 2018-07-25 01:19:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 01:19:31 --> Input Class Initialized
INFO - 2018-07-25 01:19:31 --> Language Class Initialized
ERROR - 2018-07-25 01:19:31 --> 404 Page Not Found: /index
INFO - 2018-07-25 01:19:31 --> Config Class Initialized
INFO - 2018-07-25 01:19:31 --> Hooks Class Initialized
DEBUG - 2018-07-25 01:19:32 --> UTF-8 Support Enabled
INFO - 2018-07-25 01:19:32 --> Utf8 Class Initialized
INFO - 2018-07-25 01:19:32 --> URI Class Initialized
INFO - 2018-07-25 01:19:32 --> Router Class Initialized
INFO - 2018-07-25 01:19:32 --> Output Class Initialized
INFO - 2018-07-25 01:19:32 --> Security Class Initialized
DEBUG - 2018-07-25 01:19:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 01:19:32 --> Input Class Initialized
INFO - 2018-07-25 01:19:32 --> Language Class Initialized
ERROR - 2018-07-25 01:19:32 --> 404 Page Not Found: /index
INFO - 2018-07-25 01:19:32 --> Config Class Initialized
INFO - 2018-07-25 01:19:32 --> Hooks Class Initialized
DEBUG - 2018-07-25 01:19:32 --> UTF-8 Support Enabled
INFO - 2018-07-25 01:19:32 --> Utf8 Class Initialized
INFO - 2018-07-25 01:19:32 --> URI Class Initialized
INFO - 2018-07-25 01:19:32 --> Router Class Initialized
INFO - 2018-07-25 01:19:32 --> Output Class Initialized
INFO - 2018-07-25 01:19:32 --> Security Class Initialized
DEBUG - 2018-07-25 01:19:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 01:19:32 --> Input Class Initialized
INFO - 2018-07-25 01:19:32 --> Language Class Initialized
ERROR - 2018-07-25 01:19:32 --> 404 Page Not Found: /index
INFO - 2018-07-25 01:20:42 --> Config Class Initialized
INFO - 2018-07-25 01:20:42 --> Hooks Class Initialized
DEBUG - 2018-07-25 01:20:42 --> UTF-8 Support Enabled
INFO - 2018-07-25 01:20:42 --> Utf8 Class Initialized
INFO - 2018-07-25 01:20:42 --> URI Class Initialized
DEBUG - 2018-07-25 01:20:42 --> No URI present. Default controller set.
INFO - 2018-07-25 01:20:42 --> Router Class Initialized
INFO - 2018-07-25 01:20:42 --> Output Class Initialized
INFO - 2018-07-25 01:20:42 --> Security Class Initialized
DEBUG - 2018-07-25 01:20:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 01:20:42 --> Input Class Initialized
INFO - 2018-07-25 01:20:43 --> Language Class Initialized
INFO - 2018-07-25 01:20:43 --> Language Class Initialized
INFO - 2018-07-25 01:20:43 --> Config Class Initialized
INFO - 2018-07-25 01:20:43 --> Loader Class Initialized
DEBUG - 2018-07-25 01:20:43 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-25 01:20:43 --> Helper loaded: url_helper
INFO - 2018-07-25 01:20:43 --> Helper loaded: form_helper
INFO - 2018-07-25 01:20:43 --> Helper loaded: date_helper
INFO - 2018-07-25 01:20:43 --> Helper loaded: util_helper
INFO - 2018-07-25 01:20:43 --> Helper loaded: text_helper
INFO - 2018-07-25 01:20:43 --> Helper loaded: string_helper
INFO - 2018-07-25 01:20:43 --> Database Driver Class Initialized
DEBUG - 2018-07-25 01:20:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 01:20:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 01:20:43 --> Email Class Initialized
INFO - 2018-07-25 01:20:43 --> Controller Class Initialized
DEBUG - 2018-07-25 01:20:43 --> Home MX_Controller Initialized
DEBUG - 2018-07-25 01:20:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-25 01:20:43 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-25 01:20:43 --> Login MX_Controller Initialized
INFO - 2018-07-25 01:20:43 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-25 01:20:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-25 01:20:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-25 01:20:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-07-25 01:20:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-07-25 01:20:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-07-25 01:20:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-07-25 01:20:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-07-25 01:20:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-07-25 01:20:43 --> Final output sent to browser
DEBUG - 2018-07-25 01:20:43 --> Total execution time: 0.7428
INFO - 2018-07-25 01:20:44 --> Config Class Initialized
INFO - 2018-07-25 01:20:44 --> Hooks Class Initialized
DEBUG - 2018-07-25 01:20:44 --> UTF-8 Support Enabled
INFO - 2018-07-25 01:20:44 --> Utf8 Class Initialized
INFO - 2018-07-25 01:20:44 --> URI Class Initialized
INFO - 2018-07-25 01:20:44 --> Router Class Initialized
INFO - 2018-07-25 01:20:44 --> Output Class Initialized
INFO - 2018-07-25 01:20:44 --> Security Class Initialized
DEBUG - 2018-07-25 01:20:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 01:20:44 --> Input Class Initialized
INFO - 2018-07-25 01:20:44 --> Language Class Initialized
ERROR - 2018-07-25 01:20:44 --> 404 Page Not Found: /index
INFO - 2018-07-25 01:20:44 --> Config Class Initialized
INFO - 2018-07-25 01:20:44 --> Hooks Class Initialized
DEBUG - 2018-07-25 01:20:44 --> UTF-8 Support Enabled
INFO - 2018-07-25 01:20:44 --> Utf8 Class Initialized
INFO - 2018-07-25 01:20:44 --> URI Class Initialized
INFO - 2018-07-25 01:20:44 --> Router Class Initialized
INFO - 2018-07-25 01:20:44 --> Output Class Initialized
INFO - 2018-07-25 01:20:45 --> Security Class Initialized
DEBUG - 2018-07-25 01:20:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 01:20:45 --> Input Class Initialized
INFO - 2018-07-25 01:20:45 --> Language Class Initialized
ERROR - 2018-07-25 01:20:45 --> 404 Page Not Found: /index
INFO - 2018-07-25 01:20:45 --> Config Class Initialized
INFO - 2018-07-25 01:20:45 --> Hooks Class Initialized
DEBUG - 2018-07-25 01:20:45 --> UTF-8 Support Enabled
INFO - 2018-07-25 01:20:45 --> Utf8 Class Initialized
INFO - 2018-07-25 01:20:45 --> URI Class Initialized
INFO - 2018-07-25 01:20:45 --> Router Class Initialized
INFO - 2018-07-25 01:20:45 --> Output Class Initialized
INFO - 2018-07-25 01:20:45 --> Security Class Initialized
DEBUG - 2018-07-25 01:20:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 01:20:45 --> Input Class Initialized
INFO - 2018-07-25 01:20:45 --> Language Class Initialized
ERROR - 2018-07-25 01:20:45 --> 404 Page Not Found: /index
INFO - 2018-07-25 01:23:14 --> Config Class Initialized
INFO - 2018-07-25 01:23:14 --> Hooks Class Initialized
DEBUG - 2018-07-25 01:23:14 --> UTF-8 Support Enabled
INFO - 2018-07-25 01:23:14 --> Utf8 Class Initialized
INFO - 2018-07-25 01:23:14 --> URI Class Initialized
DEBUG - 2018-07-25 01:23:14 --> No URI present. Default controller set.
INFO - 2018-07-25 01:23:14 --> Router Class Initialized
INFO - 2018-07-25 01:23:14 --> Output Class Initialized
INFO - 2018-07-25 01:23:14 --> Security Class Initialized
DEBUG - 2018-07-25 01:23:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 01:23:14 --> Input Class Initialized
INFO - 2018-07-25 01:23:14 --> Language Class Initialized
INFO - 2018-07-25 01:23:14 --> Language Class Initialized
INFO - 2018-07-25 01:23:14 --> Config Class Initialized
INFO - 2018-07-25 01:23:14 --> Loader Class Initialized
DEBUG - 2018-07-25 01:23:14 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-25 01:23:14 --> Helper loaded: url_helper
INFO - 2018-07-25 01:23:14 --> Helper loaded: form_helper
INFO - 2018-07-25 01:23:14 --> Helper loaded: date_helper
INFO - 2018-07-25 01:23:14 --> Helper loaded: util_helper
INFO - 2018-07-25 01:23:14 --> Helper loaded: text_helper
INFO - 2018-07-25 01:23:14 --> Helper loaded: string_helper
INFO - 2018-07-25 01:23:14 --> Database Driver Class Initialized
DEBUG - 2018-07-25 01:23:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 01:23:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 01:23:14 --> Email Class Initialized
INFO - 2018-07-25 01:23:14 --> Controller Class Initialized
DEBUG - 2018-07-25 01:23:14 --> Home MX_Controller Initialized
DEBUG - 2018-07-25 01:23:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-25 01:23:14 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-25 01:23:14 --> Login MX_Controller Initialized
INFO - 2018-07-25 01:23:14 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-25 01:23:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-25 01:23:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-25 01:23:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-07-25 01:23:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-07-25 01:23:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-07-25 01:23:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-07-25 01:23:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-07-25 01:23:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-07-25 01:23:14 --> Final output sent to browser
DEBUG - 2018-07-25 01:23:14 --> Total execution time: 0.5951
INFO - 2018-07-25 01:23:15 --> Config Class Initialized
INFO - 2018-07-25 01:23:15 --> Hooks Class Initialized
DEBUG - 2018-07-25 01:23:16 --> UTF-8 Support Enabled
INFO - 2018-07-25 01:23:16 --> Utf8 Class Initialized
INFO - 2018-07-25 01:23:16 --> URI Class Initialized
INFO - 2018-07-25 01:23:16 --> Router Class Initialized
INFO - 2018-07-25 01:23:16 --> Output Class Initialized
INFO - 2018-07-25 01:23:16 --> Security Class Initialized
DEBUG - 2018-07-25 01:23:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 01:23:16 --> Input Class Initialized
INFO - 2018-07-25 01:23:16 --> Language Class Initialized
ERROR - 2018-07-25 01:23:16 --> 404 Page Not Found: /index
INFO - 2018-07-25 01:23:16 --> Config Class Initialized
INFO - 2018-07-25 01:23:16 --> Hooks Class Initialized
DEBUG - 2018-07-25 01:23:16 --> UTF-8 Support Enabled
INFO - 2018-07-25 01:23:16 --> Utf8 Class Initialized
INFO - 2018-07-25 01:23:16 --> URI Class Initialized
INFO - 2018-07-25 01:23:16 --> Router Class Initialized
INFO - 2018-07-25 01:23:16 --> Output Class Initialized
INFO - 2018-07-25 01:23:16 --> Security Class Initialized
DEBUG - 2018-07-25 01:23:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 01:23:16 --> Input Class Initialized
INFO - 2018-07-25 01:23:16 --> Language Class Initialized
ERROR - 2018-07-25 01:23:16 --> 404 Page Not Found: /index
INFO - 2018-07-25 01:23:16 --> Config Class Initialized
INFO - 2018-07-25 01:23:16 --> Hooks Class Initialized
DEBUG - 2018-07-25 01:23:16 --> UTF-8 Support Enabled
INFO - 2018-07-25 01:23:16 --> Utf8 Class Initialized
INFO - 2018-07-25 01:23:16 --> URI Class Initialized
INFO - 2018-07-25 01:23:16 --> Router Class Initialized
INFO - 2018-07-25 01:23:16 --> Output Class Initialized
INFO - 2018-07-25 01:23:16 --> Security Class Initialized
DEBUG - 2018-07-25 01:23:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 01:23:16 --> Input Class Initialized
INFO - 2018-07-25 01:23:16 --> Language Class Initialized
ERROR - 2018-07-25 01:23:16 --> 404 Page Not Found: /index
INFO - 2018-07-25 01:23:45 --> Config Class Initialized
INFO - 2018-07-25 01:23:45 --> Hooks Class Initialized
DEBUG - 2018-07-25 01:23:45 --> UTF-8 Support Enabled
INFO - 2018-07-25 01:23:45 --> Utf8 Class Initialized
INFO - 2018-07-25 01:23:45 --> URI Class Initialized
DEBUG - 2018-07-25 01:23:45 --> No URI present. Default controller set.
INFO - 2018-07-25 01:23:45 --> Router Class Initialized
INFO - 2018-07-25 01:23:45 --> Output Class Initialized
INFO - 2018-07-25 01:23:45 --> Security Class Initialized
DEBUG - 2018-07-25 01:23:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 01:23:45 --> Input Class Initialized
INFO - 2018-07-25 01:23:45 --> Language Class Initialized
INFO - 2018-07-25 01:23:45 --> Language Class Initialized
INFO - 2018-07-25 01:23:45 --> Config Class Initialized
INFO - 2018-07-25 01:23:45 --> Loader Class Initialized
DEBUG - 2018-07-25 01:23:45 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-25 01:23:45 --> Helper loaded: url_helper
INFO - 2018-07-25 01:23:45 --> Helper loaded: form_helper
INFO - 2018-07-25 01:23:45 --> Helper loaded: date_helper
INFO - 2018-07-25 01:23:45 --> Helper loaded: util_helper
INFO - 2018-07-25 01:23:45 --> Helper loaded: text_helper
INFO - 2018-07-25 01:23:45 --> Helper loaded: string_helper
INFO - 2018-07-25 01:23:45 --> Database Driver Class Initialized
DEBUG - 2018-07-25 01:23:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 01:23:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 01:23:45 --> Email Class Initialized
INFO - 2018-07-25 01:23:45 --> Controller Class Initialized
DEBUG - 2018-07-25 01:23:45 --> Home MX_Controller Initialized
DEBUG - 2018-07-25 01:23:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-25 01:23:45 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-25 01:23:45 --> Login MX_Controller Initialized
INFO - 2018-07-25 01:23:45 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-25 01:23:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-25 01:23:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-25 01:23:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-07-25 01:23:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-07-25 01:23:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-07-25 01:23:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-07-25 01:23:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-07-25 01:23:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-07-25 01:23:45 --> Final output sent to browser
DEBUG - 2018-07-25 01:23:45 --> Total execution time: 0.6434
INFO - 2018-07-25 01:23:46 --> Config Class Initialized
INFO - 2018-07-25 01:23:46 --> Hooks Class Initialized
DEBUG - 2018-07-25 01:23:46 --> UTF-8 Support Enabled
INFO - 2018-07-25 01:23:46 --> Utf8 Class Initialized
INFO - 2018-07-25 01:23:46 --> URI Class Initialized
INFO - 2018-07-25 01:23:46 --> Router Class Initialized
INFO - 2018-07-25 01:23:46 --> Output Class Initialized
INFO - 2018-07-25 01:23:46 --> Security Class Initialized
DEBUG - 2018-07-25 01:23:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 01:23:46 --> Input Class Initialized
INFO - 2018-07-25 01:23:46 --> Language Class Initialized
ERROR - 2018-07-25 01:23:46 --> 404 Page Not Found: /index
INFO - 2018-07-25 01:23:46 --> Config Class Initialized
INFO - 2018-07-25 01:23:46 --> Hooks Class Initialized
DEBUG - 2018-07-25 01:23:46 --> UTF-8 Support Enabled
INFO - 2018-07-25 01:23:46 --> Utf8 Class Initialized
INFO - 2018-07-25 01:23:46 --> URI Class Initialized
INFO - 2018-07-25 01:23:46 --> Router Class Initialized
INFO - 2018-07-25 01:23:46 --> Output Class Initialized
INFO - 2018-07-25 01:23:47 --> Security Class Initialized
DEBUG - 2018-07-25 01:23:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 01:23:47 --> Input Class Initialized
INFO - 2018-07-25 01:23:47 --> Language Class Initialized
ERROR - 2018-07-25 01:23:47 --> 404 Page Not Found: /index
INFO - 2018-07-25 01:23:47 --> Config Class Initialized
INFO - 2018-07-25 01:23:47 --> Hooks Class Initialized
DEBUG - 2018-07-25 01:23:47 --> UTF-8 Support Enabled
INFO - 2018-07-25 01:23:47 --> Utf8 Class Initialized
INFO - 2018-07-25 01:23:47 --> URI Class Initialized
INFO - 2018-07-25 01:23:47 --> Router Class Initialized
INFO - 2018-07-25 01:23:47 --> Output Class Initialized
INFO - 2018-07-25 01:23:47 --> Security Class Initialized
DEBUG - 2018-07-25 01:23:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 01:23:47 --> Input Class Initialized
INFO - 2018-07-25 01:23:47 --> Language Class Initialized
ERROR - 2018-07-25 01:23:47 --> 404 Page Not Found: /index
INFO - 2018-07-25 01:23:55 --> Config Class Initialized
INFO - 2018-07-25 01:23:55 --> Hooks Class Initialized
DEBUG - 2018-07-25 01:23:55 --> UTF-8 Support Enabled
INFO - 2018-07-25 01:23:55 --> Utf8 Class Initialized
INFO - 2018-07-25 01:23:55 --> URI Class Initialized
DEBUG - 2018-07-25 01:23:55 --> No URI present. Default controller set.
INFO - 2018-07-25 01:23:55 --> Router Class Initialized
INFO - 2018-07-25 01:23:55 --> Output Class Initialized
INFO - 2018-07-25 01:23:55 --> Security Class Initialized
DEBUG - 2018-07-25 01:23:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 01:23:56 --> Input Class Initialized
INFO - 2018-07-25 01:23:56 --> Language Class Initialized
INFO - 2018-07-25 01:23:56 --> Language Class Initialized
INFO - 2018-07-25 01:23:56 --> Config Class Initialized
INFO - 2018-07-25 01:23:56 --> Loader Class Initialized
DEBUG - 2018-07-25 01:23:56 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-25 01:23:56 --> Helper loaded: url_helper
INFO - 2018-07-25 01:23:56 --> Helper loaded: form_helper
INFO - 2018-07-25 01:23:56 --> Helper loaded: date_helper
INFO - 2018-07-25 01:23:56 --> Helper loaded: util_helper
INFO - 2018-07-25 01:23:56 --> Helper loaded: text_helper
INFO - 2018-07-25 01:23:56 --> Helper loaded: string_helper
INFO - 2018-07-25 01:23:56 --> Database Driver Class Initialized
DEBUG - 2018-07-25 01:23:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 01:23:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 01:23:56 --> Email Class Initialized
INFO - 2018-07-25 01:23:56 --> Controller Class Initialized
DEBUG - 2018-07-25 01:23:56 --> Home MX_Controller Initialized
DEBUG - 2018-07-25 01:23:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-25 01:23:56 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-25 01:23:56 --> Login MX_Controller Initialized
INFO - 2018-07-25 01:23:56 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-25 01:23:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-25 01:23:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-25 01:23:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-07-25 01:23:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-07-25 01:23:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-07-25 01:23:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-07-25 01:23:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-07-25 01:23:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-07-25 01:23:56 --> Final output sent to browser
DEBUG - 2018-07-25 01:23:56 --> Total execution time: 0.6610
INFO - 2018-07-25 01:23:57 --> Config Class Initialized
INFO - 2018-07-25 01:23:57 --> Hooks Class Initialized
DEBUG - 2018-07-25 01:23:57 --> UTF-8 Support Enabled
INFO - 2018-07-25 01:23:57 --> Utf8 Class Initialized
INFO - 2018-07-25 01:23:57 --> URI Class Initialized
INFO - 2018-07-25 01:23:57 --> Router Class Initialized
INFO - 2018-07-25 01:23:57 --> Output Class Initialized
INFO - 2018-07-25 01:23:57 --> Security Class Initialized
DEBUG - 2018-07-25 01:23:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 01:23:57 --> Input Class Initialized
INFO - 2018-07-25 01:23:57 --> Language Class Initialized
ERROR - 2018-07-25 01:23:57 --> 404 Page Not Found: /index
INFO - 2018-07-25 01:23:57 --> Config Class Initialized
INFO - 2018-07-25 01:23:57 --> Hooks Class Initialized
DEBUG - 2018-07-25 01:23:57 --> UTF-8 Support Enabled
INFO - 2018-07-25 01:23:57 --> Utf8 Class Initialized
INFO - 2018-07-25 01:23:57 --> URI Class Initialized
INFO - 2018-07-25 01:23:57 --> Router Class Initialized
INFO - 2018-07-25 01:23:57 --> Output Class Initialized
INFO - 2018-07-25 01:23:57 --> Security Class Initialized
DEBUG - 2018-07-25 01:23:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 01:23:57 --> Input Class Initialized
INFO - 2018-07-25 01:23:57 --> Language Class Initialized
ERROR - 2018-07-25 01:23:57 --> 404 Page Not Found: /index
INFO - 2018-07-25 01:23:57 --> Config Class Initialized
INFO - 2018-07-25 01:23:57 --> Hooks Class Initialized
DEBUG - 2018-07-25 01:23:58 --> UTF-8 Support Enabled
INFO - 2018-07-25 01:23:58 --> Utf8 Class Initialized
INFO - 2018-07-25 01:23:58 --> URI Class Initialized
INFO - 2018-07-25 01:23:58 --> Router Class Initialized
INFO - 2018-07-25 01:23:58 --> Output Class Initialized
INFO - 2018-07-25 01:23:58 --> Security Class Initialized
DEBUG - 2018-07-25 01:23:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 01:23:58 --> Input Class Initialized
INFO - 2018-07-25 01:23:58 --> Language Class Initialized
ERROR - 2018-07-25 01:23:58 --> 404 Page Not Found: /index
INFO - 2018-07-25 01:25:32 --> Config Class Initialized
INFO - 2018-07-25 01:25:32 --> Hooks Class Initialized
DEBUG - 2018-07-25 01:25:32 --> UTF-8 Support Enabled
INFO - 2018-07-25 01:25:32 --> Utf8 Class Initialized
INFO - 2018-07-25 01:25:32 --> URI Class Initialized
DEBUG - 2018-07-25 01:25:32 --> No URI present. Default controller set.
INFO - 2018-07-25 01:25:32 --> Router Class Initialized
INFO - 2018-07-25 01:25:32 --> Output Class Initialized
INFO - 2018-07-25 01:25:32 --> Security Class Initialized
DEBUG - 2018-07-25 01:25:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 01:25:32 --> Input Class Initialized
INFO - 2018-07-25 01:25:32 --> Language Class Initialized
INFO - 2018-07-25 01:25:32 --> Language Class Initialized
INFO - 2018-07-25 01:25:32 --> Config Class Initialized
INFO - 2018-07-25 01:25:32 --> Loader Class Initialized
DEBUG - 2018-07-25 01:25:32 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-25 01:25:32 --> Helper loaded: url_helper
INFO - 2018-07-25 01:25:32 --> Helper loaded: form_helper
INFO - 2018-07-25 01:25:32 --> Helper loaded: date_helper
INFO - 2018-07-25 01:25:32 --> Helper loaded: util_helper
INFO - 2018-07-25 01:25:32 --> Helper loaded: text_helper
INFO - 2018-07-25 01:25:32 --> Helper loaded: string_helper
INFO - 2018-07-25 01:25:32 --> Database Driver Class Initialized
DEBUG - 2018-07-25 01:25:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 01:25:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 01:25:32 --> Email Class Initialized
INFO - 2018-07-25 01:25:32 --> Controller Class Initialized
DEBUG - 2018-07-25 01:25:32 --> Home MX_Controller Initialized
DEBUG - 2018-07-25 01:25:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-25 01:25:32 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-25 01:25:32 --> Login MX_Controller Initialized
INFO - 2018-07-25 01:25:32 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-25 01:25:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-25 01:25:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-25 01:25:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-07-25 01:25:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-07-25 01:25:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-07-25 01:25:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-07-25 01:25:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-07-25 01:25:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-07-25 01:25:32 --> Final output sent to browser
DEBUG - 2018-07-25 01:25:33 --> Total execution time: 0.6308
INFO - 2018-07-25 01:25:33 --> Config Class Initialized
INFO - 2018-07-25 01:25:33 --> Hooks Class Initialized
DEBUG - 2018-07-25 01:25:33 --> UTF-8 Support Enabled
INFO - 2018-07-25 01:25:33 --> Utf8 Class Initialized
INFO - 2018-07-25 01:25:33 --> URI Class Initialized
INFO - 2018-07-25 01:25:33 --> Router Class Initialized
INFO - 2018-07-25 01:25:33 --> Output Class Initialized
INFO - 2018-07-25 01:25:33 --> Security Class Initialized
DEBUG - 2018-07-25 01:25:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 01:25:33 --> Input Class Initialized
INFO - 2018-07-25 01:25:33 --> Language Class Initialized
ERROR - 2018-07-25 01:25:33 --> 404 Page Not Found: /index
INFO - 2018-07-25 01:25:34 --> Config Class Initialized
INFO - 2018-07-25 01:25:34 --> Hooks Class Initialized
DEBUG - 2018-07-25 01:25:34 --> UTF-8 Support Enabled
INFO - 2018-07-25 01:25:34 --> Utf8 Class Initialized
INFO - 2018-07-25 01:25:34 --> URI Class Initialized
INFO - 2018-07-25 01:25:34 --> Router Class Initialized
INFO - 2018-07-25 01:25:34 --> Output Class Initialized
INFO - 2018-07-25 01:25:34 --> Security Class Initialized
DEBUG - 2018-07-25 01:25:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 01:25:34 --> Input Class Initialized
INFO - 2018-07-25 01:25:34 --> Language Class Initialized
ERROR - 2018-07-25 01:25:34 --> 404 Page Not Found: /index
INFO - 2018-07-25 01:25:34 --> Config Class Initialized
INFO - 2018-07-25 01:25:34 --> Hooks Class Initialized
DEBUG - 2018-07-25 01:25:34 --> UTF-8 Support Enabled
INFO - 2018-07-25 01:25:34 --> Utf8 Class Initialized
INFO - 2018-07-25 01:25:34 --> URI Class Initialized
INFO - 2018-07-25 01:25:34 --> Router Class Initialized
INFO - 2018-07-25 01:25:34 --> Output Class Initialized
INFO - 2018-07-25 01:25:34 --> Security Class Initialized
DEBUG - 2018-07-25 01:25:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 01:25:34 --> Input Class Initialized
INFO - 2018-07-25 01:25:34 --> Language Class Initialized
ERROR - 2018-07-25 01:25:34 --> 404 Page Not Found: /index
INFO - 2018-07-25 01:28:00 --> Config Class Initialized
INFO - 2018-07-25 01:28:00 --> Hooks Class Initialized
DEBUG - 2018-07-25 01:28:00 --> UTF-8 Support Enabled
INFO - 2018-07-25 01:28:00 --> Utf8 Class Initialized
INFO - 2018-07-25 01:28:00 --> URI Class Initialized
DEBUG - 2018-07-25 01:28:00 --> No URI present. Default controller set.
INFO - 2018-07-25 01:28:01 --> Router Class Initialized
INFO - 2018-07-25 01:28:01 --> Output Class Initialized
INFO - 2018-07-25 01:28:01 --> Security Class Initialized
DEBUG - 2018-07-25 01:28:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 01:28:01 --> Input Class Initialized
INFO - 2018-07-25 01:28:01 --> Language Class Initialized
INFO - 2018-07-25 01:28:01 --> Language Class Initialized
INFO - 2018-07-25 01:28:01 --> Config Class Initialized
INFO - 2018-07-25 01:28:01 --> Loader Class Initialized
DEBUG - 2018-07-25 01:28:01 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-25 01:28:01 --> Helper loaded: url_helper
INFO - 2018-07-25 01:28:01 --> Helper loaded: form_helper
INFO - 2018-07-25 01:28:01 --> Helper loaded: date_helper
INFO - 2018-07-25 01:28:01 --> Helper loaded: util_helper
INFO - 2018-07-25 01:28:01 --> Helper loaded: text_helper
INFO - 2018-07-25 01:28:01 --> Helper loaded: string_helper
INFO - 2018-07-25 01:28:01 --> Database Driver Class Initialized
DEBUG - 2018-07-25 01:28:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 01:28:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 01:28:01 --> Email Class Initialized
INFO - 2018-07-25 01:28:01 --> Controller Class Initialized
DEBUG - 2018-07-25 01:28:01 --> Home MX_Controller Initialized
DEBUG - 2018-07-25 01:28:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-25 01:28:01 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-25 01:28:01 --> Login MX_Controller Initialized
INFO - 2018-07-25 01:28:01 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-25 01:28:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-25 01:28:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-25 01:28:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-07-25 01:28:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-07-25 01:28:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-07-25 01:28:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-07-25 01:28:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-07-25 01:28:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-07-25 01:28:01 --> Final output sent to browser
DEBUG - 2018-07-25 01:28:01 --> Total execution time: 0.6084
INFO - 2018-07-25 01:28:02 --> Config Class Initialized
INFO - 2018-07-25 01:28:02 --> Hooks Class Initialized
DEBUG - 2018-07-25 01:28:02 --> UTF-8 Support Enabled
INFO - 2018-07-25 01:28:02 --> Utf8 Class Initialized
INFO - 2018-07-25 01:28:02 --> URI Class Initialized
INFO - 2018-07-25 01:28:02 --> Router Class Initialized
INFO - 2018-07-25 01:28:02 --> Output Class Initialized
INFO - 2018-07-25 01:28:02 --> Security Class Initialized
DEBUG - 2018-07-25 01:28:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 01:28:03 --> Input Class Initialized
INFO - 2018-07-25 01:28:03 --> Language Class Initialized
ERROR - 2018-07-25 01:28:03 --> 404 Page Not Found: /index
INFO - 2018-07-25 01:28:03 --> Config Class Initialized
INFO - 2018-07-25 01:28:03 --> Hooks Class Initialized
DEBUG - 2018-07-25 01:28:03 --> UTF-8 Support Enabled
INFO - 2018-07-25 01:28:03 --> Utf8 Class Initialized
INFO - 2018-07-25 01:28:03 --> URI Class Initialized
INFO - 2018-07-25 01:28:03 --> Router Class Initialized
INFO - 2018-07-25 01:28:03 --> Output Class Initialized
INFO - 2018-07-25 01:28:03 --> Security Class Initialized
DEBUG - 2018-07-25 01:28:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 01:28:03 --> Input Class Initialized
INFO - 2018-07-25 01:28:03 --> Language Class Initialized
ERROR - 2018-07-25 01:28:03 --> 404 Page Not Found: /index
INFO - 2018-07-25 01:28:03 --> Config Class Initialized
INFO - 2018-07-25 01:28:03 --> Hooks Class Initialized
DEBUG - 2018-07-25 01:28:03 --> UTF-8 Support Enabled
INFO - 2018-07-25 01:28:03 --> Utf8 Class Initialized
INFO - 2018-07-25 01:28:03 --> URI Class Initialized
INFO - 2018-07-25 01:28:03 --> Router Class Initialized
INFO - 2018-07-25 01:28:03 --> Output Class Initialized
INFO - 2018-07-25 01:28:03 --> Security Class Initialized
DEBUG - 2018-07-25 01:28:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 01:28:03 --> Input Class Initialized
INFO - 2018-07-25 01:28:03 --> Language Class Initialized
ERROR - 2018-07-25 01:28:03 --> 404 Page Not Found: /index
INFO - 2018-07-25 01:28:53 --> Config Class Initialized
INFO - 2018-07-25 01:28:53 --> Hooks Class Initialized
DEBUG - 2018-07-25 01:28:53 --> UTF-8 Support Enabled
INFO - 2018-07-25 01:28:53 --> Utf8 Class Initialized
INFO - 2018-07-25 01:28:53 --> URI Class Initialized
INFO - 2018-07-25 01:28:53 --> Router Class Initialized
INFO - 2018-07-25 01:28:53 --> Output Class Initialized
INFO - 2018-07-25 01:28:53 --> Security Class Initialized
DEBUG - 2018-07-25 01:28:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 01:28:53 --> Input Class Initialized
INFO - 2018-07-25 01:28:53 --> Language Class Initialized
ERROR - 2018-07-25 01:28:53 --> 404 Page Not Found: /index
INFO - 2018-07-25 01:28:53 --> Config Class Initialized
INFO - 2018-07-25 01:28:53 --> Hooks Class Initialized
DEBUG - 2018-07-25 01:28:53 --> UTF-8 Support Enabled
INFO - 2018-07-25 01:28:53 --> Utf8 Class Initialized
INFO - 2018-07-25 01:28:53 --> URI Class Initialized
INFO - 2018-07-25 01:28:53 --> Router Class Initialized
INFO - 2018-07-25 01:28:53 --> Output Class Initialized
INFO - 2018-07-25 01:28:53 --> Security Class Initialized
DEBUG - 2018-07-25 01:28:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 01:28:53 --> Input Class Initialized
INFO - 2018-07-25 01:28:53 --> Language Class Initialized
ERROR - 2018-07-25 01:28:53 --> 404 Page Not Found: /index
INFO - 2018-07-25 01:28:53 --> Config Class Initialized
INFO - 2018-07-25 01:28:53 --> Hooks Class Initialized
DEBUG - 2018-07-25 01:28:53 --> UTF-8 Support Enabled
INFO - 2018-07-25 01:28:53 --> Utf8 Class Initialized
INFO - 2018-07-25 01:28:53 --> URI Class Initialized
INFO - 2018-07-25 01:28:53 --> Router Class Initialized
INFO - 2018-07-25 01:28:53 --> Output Class Initialized
INFO - 2018-07-25 01:28:53 --> Security Class Initialized
DEBUG - 2018-07-25 01:28:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 01:28:53 --> Input Class Initialized
INFO - 2018-07-25 01:28:53 --> Language Class Initialized
ERROR - 2018-07-25 01:28:53 --> 404 Page Not Found: /index
INFO - 2018-07-25 01:30:10 --> Config Class Initialized
INFO - 2018-07-25 01:30:10 --> Hooks Class Initialized
DEBUG - 2018-07-25 01:30:10 --> UTF-8 Support Enabled
INFO - 2018-07-25 01:30:10 --> Utf8 Class Initialized
INFO - 2018-07-25 01:30:10 --> URI Class Initialized
DEBUG - 2018-07-25 01:30:10 --> No URI present. Default controller set.
INFO - 2018-07-25 01:30:10 --> Router Class Initialized
INFO - 2018-07-25 01:30:10 --> Output Class Initialized
INFO - 2018-07-25 01:30:10 --> Security Class Initialized
DEBUG - 2018-07-25 01:30:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 01:30:10 --> Input Class Initialized
INFO - 2018-07-25 01:30:10 --> Language Class Initialized
INFO - 2018-07-25 01:30:10 --> Language Class Initialized
INFO - 2018-07-25 01:30:10 --> Config Class Initialized
INFO - 2018-07-25 01:30:10 --> Loader Class Initialized
DEBUG - 2018-07-25 01:30:10 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-25 01:30:10 --> Helper loaded: url_helper
INFO - 2018-07-25 01:30:10 --> Helper loaded: form_helper
INFO - 2018-07-25 01:30:10 --> Helper loaded: date_helper
INFO - 2018-07-25 01:30:10 --> Helper loaded: util_helper
INFO - 2018-07-25 01:30:10 --> Helper loaded: text_helper
INFO - 2018-07-25 01:30:10 --> Helper loaded: string_helper
INFO - 2018-07-25 01:30:10 --> Database Driver Class Initialized
DEBUG - 2018-07-25 01:30:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 01:30:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 01:30:10 --> Email Class Initialized
INFO - 2018-07-25 01:30:10 --> Controller Class Initialized
DEBUG - 2018-07-25 01:30:10 --> Home MX_Controller Initialized
DEBUG - 2018-07-25 01:30:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-25 01:30:11 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-25 01:30:11 --> Login MX_Controller Initialized
INFO - 2018-07-25 01:30:11 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-25 01:30:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-25 01:30:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-25 01:30:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-07-25 01:30:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-07-25 01:30:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-07-25 01:30:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-07-25 01:30:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-07-25 01:30:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-07-25 01:30:11 --> Final output sent to browser
DEBUG - 2018-07-25 01:30:11 --> Total execution time: 0.6021
INFO - 2018-07-25 01:30:11 --> Config Class Initialized
INFO - 2018-07-25 01:30:11 --> Hooks Class Initialized
DEBUG - 2018-07-25 01:30:11 --> UTF-8 Support Enabled
INFO - 2018-07-25 01:30:11 --> Utf8 Class Initialized
INFO - 2018-07-25 01:30:11 --> URI Class Initialized
INFO - 2018-07-25 01:30:12 --> Router Class Initialized
INFO - 2018-07-25 01:30:12 --> Output Class Initialized
INFO - 2018-07-25 01:30:12 --> Security Class Initialized
DEBUG - 2018-07-25 01:30:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 01:30:12 --> Input Class Initialized
INFO - 2018-07-25 01:30:12 --> Language Class Initialized
ERROR - 2018-07-25 01:30:12 --> 404 Page Not Found: /index
INFO - 2018-07-25 01:30:12 --> Config Class Initialized
INFO - 2018-07-25 01:30:12 --> Hooks Class Initialized
DEBUG - 2018-07-25 01:30:12 --> UTF-8 Support Enabled
INFO - 2018-07-25 01:30:12 --> Utf8 Class Initialized
INFO - 2018-07-25 01:30:12 --> URI Class Initialized
INFO - 2018-07-25 01:30:12 --> Router Class Initialized
INFO - 2018-07-25 01:30:12 --> Output Class Initialized
INFO - 2018-07-25 01:30:12 --> Security Class Initialized
DEBUG - 2018-07-25 01:30:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 01:30:12 --> Input Class Initialized
INFO - 2018-07-25 01:30:12 --> Language Class Initialized
ERROR - 2018-07-25 01:30:12 --> 404 Page Not Found: /index
INFO - 2018-07-25 01:30:12 --> Config Class Initialized
INFO - 2018-07-25 01:30:12 --> Hooks Class Initialized
DEBUG - 2018-07-25 01:30:12 --> UTF-8 Support Enabled
INFO - 2018-07-25 01:30:12 --> Utf8 Class Initialized
INFO - 2018-07-25 01:30:12 --> URI Class Initialized
INFO - 2018-07-25 01:30:12 --> Router Class Initialized
INFO - 2018-07-25 01:30:12 --> Output Class Initialized
INFO - 2018-07-25 01:30:12 --> Security Class Initialized
DEBUG - 2018-07-25 01:30:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 01:30:12 --> Input Class Initialized
INFO - 2018-07-25 01:30:12 --> Language Class Initialized
ERROR - 2018-07-25 01:30:12 --> 404 Page Not Found: /index
INFO - 2018-07-25 01:54:01 --> Config Class Initialized
INFO - 2018-07-25 01:54:01 --> Hooks Class Initialized
DEBUG - 2018-07-25 01:54:01 --> UTF-8 Support Enabled
INFO - 2018-07-25 01:54:01 --> Utf8 Class Initialized
INFO - 2018-07-25 01:54:01 --> URI Class Initialized
DEBUG - 2018-07-25 01:54:01 --> No URI present. Default controller set.
INFO - 2018-07-25 01:54:01 --> Router Class Initialized
INFO - 2018-07-25 01:54:01 --> Output Class Initialized
INFO - 2018-07-25 01:54:01 --> Security Class Initialized
DEBUG - 2018-07-25 01:54:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 01:54:01 --> Input Class Initialized
INFO - 2018-07-25 01:54:01 --> Language Class Initialized
INFO - 2018-07-25 01:54:01 --> Language Class Initialized
INFO - 2018-07-25 01:54:01 --> Config Class Initialized
INFO - 2018-07-25 01:54:01 --> Loader Class Initialized
DEBUG - 2018-07-25 01:54:01 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-25 01:54:01 --> Helper loaded: url_helper
INFO - 2018-07-25 01:54:01 --> Helper loaded: form_helper
INFO - 2018-07-25 01:54:01 --> Helper loaded: date_helper
INFO - 2018-07-25 01:54:01 --> Helper loaded: util_helper
INFO - 2018-07-25 01:54:01 --> Helper loaded: text_helper
INFO - 2018-07-25 01:54:01 --> Helper loaded: string_helper
INFO - 2018-07-25 01:54:01 --> Database Driver Class Initialized
DEBUG - 2018-07-25 01:54:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 01:54:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 01:54:01 --> Email Class Initialized
INFO - 2018-07-25 01:54:01 --> Controller Class Initialized
DEBUG - 2018-07-25 01:54:01 --> Home MX_Controller Initialized
DEBUG - 2018-07-25 01:54:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-25 01:54:01 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-25 01:54:01 --> Login MX_Controller Initialized
INFO - 2018-07-25 01:54:01 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-25 01:54:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-25 01:54:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-25 01:54:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-07-25 01:54:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-07-25 01:54:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-07-25 01:54:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-07-25 01:54:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-07-25 01:54:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-07-25 01:54:01 --> Final output sent to browser
DEBUG - 2018-07-25 01:54:02 --> Total execution time: 0.6706
INFO - 2018-07-25 01:54:03 --> Config Class Initialized
INFO - 2018-07-25 01:54:03 --> Hooks Class Initialized
DEBUG - 2018-07-25 01:54:03 --> UTF-8 Support Enabled
INFO - 2018-07-25 01:54:03 --> Utf8 Class Initialized
INFO - 2018-07-25 01:54:03 --> URI Class Initialized
INFO - 2018-07-25 01:54:03 --> Router Class Initialized
INFO - 2018-07-25 01:54:03 --> Output Class Initialized
INFO - 2018-07-25 01:54:03 --> Security Class Initialized
DEBUG - 2018-07-25 01:54:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 01:54:03 --> Input Class Initialized
INFO - 2018-07-25 01:54:03 --> Language Class Initialized
ERROR - 2018-07-25 01:54:03 --> 404 Page Not Found: /index
INFO - 2018-07-25 01:54:03 --> Config Class Initialized
INFO - 2018-07-25 01:54:03 --> Hooks Class Initialized
DEBUG - 2018-07-25 01:54:03 --> UTF-8 Support Enabled
INFO - 2018-07-25 01:54:03 --> Utf8 Class Initialized
INFO - 2018-07-25 01:54:03 --> URI Class Initialized
INFO - 2018-07-25 01:54:03 --> Router Class Initialized
INFO - 2018-07-25 01:54:03 --> Output Class Initialized
INFO - 2018-07-25 01:54:03 --> Security Class Initialized
DEBUG - 2018-07-25 01:54:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 01:54:03 --> Input Class Initialized
INFO - 2018-07-25 01:54:03 --> Language Class Initialized
ERROR - 2018-07-25 01:54:03 --> 404 Page Not Found: /index
INFO - 2018-07-25 01:54:03 --> Config Class Initialized
INFO - 2018-07-25 01:54:03 --> Hooks Class Initialized
DEBUG - 2018-07-25 01:54:03 --> UTF-8 Support Enabled
INFO - 2018-07-25 01:54:03 --> Utf8 Class Initialized
INFO - 2018-07-25 01:54:03 --> URI Class Initialized
INFO - 2018-07-25 01:54:03 --> Router Class Initialized
INFO - 2018-07-25 01:54:03 --> Output Class Initialized
INFO - 2018-07-25 01:54:03 --> Security Class Initialized
DEBUG - 2018-07-25 01:54:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 01:54:03 --> Input Class Initialized
INFO - 2018-07-25 01:54:03 --> Language Class Initialized
ERROR - 2018-07-25 01:54:03 --> 404 Page Not Found: /index
INFO - 2018-07-25 01:54:43 --> Config Class Initialized
INFO - 2018-07-25 01:54:43 --> Hooks Class Initialized
DEBUG - 2018-07-25 01:54:43 --> UTF-8 Support Enabled
INFO - 2018-07-25 01:54:43 --> Utf8 Class Initialized
INFO - 2018-07-25 01:54:43 --> URI Class Initialized
DEBUG - 2018-07-25 01:54:43 --> No URI present. Default controller set.
INFO - 2018-07-25 01:54:43 --> Router Class Initialized
INFO - 2018-07-25 01:54:43 --> Output Class Initialized
INFO - 2018-07-25 01:54:43 --> Security Class Initialized
DEBUG - 2018-07-25 01:54:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 01:54:43 --> Input Class Initialized
INFO - 2018-07-25 01:54:43 --> Language Class Initialized
INFO - 2018-07-25 01:54:43 --> Language Class Initialized
INFO - 2018-07-25 01:54:43 --> Config Class Initialized
INFO - 2018-07-25 01:54:43 --> Loader Class Initialized
DEBUG - 2018-07-25 01:54:43 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-25 01:54:43 --> Helper loaded: url_helper
INFO - 2018-07-25 01:54:43 --> Helper loaded: form_helper
INFO - 2018-07-25 01:54:43 --> Helper loaded: date_helper
INFO - 2018-07-25 01:54:43 --> Helper loaded: util_helper
INFO - 2018-07-25 01:54:43 --> Helper loaded: text_helper
INFO - 2018-07-25 01:54:43 --> Helper loaded: string_helper
INFO - 2018-07-25 01:54:43 --> Database Driver Class Initialized
DEBUG - 2018-07-25 01:54:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 01:54:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 01:54:43 --> Email Class Initialized
INFO - 2018-07-25 01:54:43 --> Controller Class Initialized
DEBUG - 2018-07-25 01:54:43 --> Home MX_Controller Initialized
DEBUG - 2018-07-25 01:54:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-25 01:54:43 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-25 01:54:43 --> Login MX_Controller Initialized
INFO - 2018-07-25 01:54:43 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-25 01:54:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-25 01:54:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-25 01:54:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-07-25 01:54:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-07-25 01:54:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-07-25 01:54:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-07-25 01:54:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-07-25 01:54:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-07-25 01:54:43 --> Final output sent to browser
DEBUG - 2018-07-25 01:54:43 --> Total execution time: 0.7622
INFO - 2018-07-25 01:54:45 --> Config Class Initialized
INFO - 2018-07-25 01:54:45 --> Hooks Class Initialized
DEBUG - 2018-07-25 01:54:45 --> UTF-8 Support Enabled
INFO - 2018-07-25 01:54:45 --> Utf8 Class Initialized
INFO - 2018-07-25 01:54:45 --> URI Class Initialized
INFO - 2018-07-25 01:54:45 --> Router Class Initialized
INFO - 2018-07-25 01:54:45 --> Output Class Initialized
INFO - 2018-07-25 01:54:45 --> Security Class Initialized
DEBUG - 2018-07-25 01:54:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 01:54:45 --> Input Class Initialized
INFO - 2018-07-25 01:54:45 --> Language Class Initialized
ERROR - 2018-07-25 01:54:45 --> 404 Page Not Found: /index
INFO - 2018-07-25 01:54:45 --> Config Class Initialized
INFO - 2018-07-25 01:54:45 --> Hooks Class Initialized
DEBUG - 2018-07-25 01:54:45 --> UTF-8 Support Enabled
INFO - 2018-07-25 01:54:45 --> Utf8 Class Initialized
INFO - 2018-07-25 01:54:45 --> URI Class Initialized
INFO - 2018-07-25 01:54:45 --> Router Class Initialized
INFO - 2018-07-25 01:54:45 --> Output Class Initialized
INFO - 2018-07-25 01:54:45 --> Security Class Initialized
DEBUG - 2018-07-25 01:54:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 01:54:45 --> Input Class Initialized
INFO - 2018-07-25 01:54:45 --> Language Class Initialized
ERROR - 2018-07-25 01:54:45 --> 404 Page Not Found: /index
INFO - 2018-07-25 01:54:45 --> Config Class Initialized
INFO - 2018-07-25 01:54:45 --> Hooks Class Initialized
DEBUG - 2018-07-25 01:54:45 --> UTF-8 Support Enabled
INFO - 2018-07-25 01:54:45 --> Utf8 Class Initialized
INFO - 2018-07-25 01:54:45 --> URI Class Initialized
INFO - 2018-07-25 01:54:45 --> Router Class Initialized
INFO - 2018-07-25 01:54:45 --> Output Class Initialized
INFO - 2018-07-25 01:54:45 --> Security Class Initialized
DEBUG - 2018-07-25 01:54:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 01:54:45 --> Input Class Initialized
INFO - 2018-07-25 01:54:45 --> Language Class Initialized
ERROR - 2018-07-25 01:54:45 --> 404 Page Not Found: /index
INFO - 2018-07-25 01:54:45 --> Config Class Initialized
INFO - 2018-07-25 01:54:45 --> Hooks Class Initialized
DEBUG - 2018-07-25 01:54:45 --> UTF-8 Support Enabled
INFO - 2018-07-25 01:54:45 --> Utf8 Class Initialized
INFO - 2018-07-25 01:54:45 --> URI Class Initialized
INFO - 2018-07-25 01:54:45 --> Router Class Initialized
INFO - 2018-07-25 01:54:45 --> Output Class Initialized
INFO - 2018-07-25 01:54:45 --> Security Class Initialized
DEBUG - 2018-07-25 01:54:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 01:54:45 --> Input Class Initialized
INFO - 2018-07-25 01:54:45 --> Language Class Initialized
ERROR - 2018-07-25 01:54:45 --> 404 Page Not Found: /index
INFO - 2018-07-25 01:54:46 --> Config Class Initialized
INFO - 2018-07-25 01:54:46 --> Hooks Class Initialized
DEBUG - 2018-07-25 01:54:46 --> UTF-8 Support Enabled
INFO - 2018-07-25 01:54:46 --> Utf8 Class Initialized
INFO - 2018-07-25 01:54:46 --> URI Class Initialized
INFO - 2018-07-25 01:54:46 --> Router Class Initialized
INFO - 2018-07-25 01:54:46 --> Output Class Initialized
INFO - 2018-07-25 01:54:46 --> Security Class Initialized
DEBUG - 2018-07-25 01:54:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 01:54:46 --> Input Class Initialized
INFO - 2018-07-25 01:54:46 --> Language Class Initialized
ERROR - 2018-07-25 01:54:46 --> 404 Page Not Found: /index
INFO - 2018-07-25 01:54:46 --> Config Class Initialized
INFO - 2018-07-25 01:54:46 --> Hooks Class Initialized
DEBUG - 2018-07-25 01:54:46 --> UTF-8 Support Enabled
INFO - 2018-07-25 01:54:46 --> Utf8 Class Initialized
INFO - 2018-07-25 01:54:46 --> URI Class Initialized
INFO - 2018-07-25 01:54:46 --> Router Class Initialized
INFO - 2018-07-25 01:54:46 --> Output Class Initialized
INFO - 2018-07-25 01:54:46 --> Security Class Initialized
DEBUG - 2018-07-25 01:54:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 01:54:46 --> Input Class Initialized
INFO - 2018-07-25 01:54:46 --> Language Class Initialized
ERROR - 2018-07-25 01:54:46 --> 404 Page Not Found: /index
INFO - 2018-07-25 01:54:57 --> Config Class Initialized
INFO - 2018-07-25 01:54:57 --> Hooks Class Initialized
DEBUG - 2018-07-25 01:54:57 --> UTF-8 Support Enabled
INFO - 2018-07-25 01:54:57 --> Utf8 Class Initialized
INFO - 2018-07-25 01:54:57 --> URI Class Initialized
DEBUG - 2018-07-25 01:54:57 --> No URI present. Default controller set.
INFO - 2018-07-25 01:54:57 --> Router Class Initialized
INFO - 2018-07-25 01:54:57 --> Output Class Initialized
INFO - 2018-07-25 01:54:57 --> Security Class Initialized
DEBUG - 2018-07-25 01:54:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 01:54:57 --> Input Class Initialized
INFO - 2018-07-25 01:54:57 --> Language Class Initialized
INFO - 2018-07-25 01:54:57 --> Language Class Initialized
INFO - 2018-07-25 01:54:57 --> Config Class Initialized
INFO - 2018-07-25 01:54:57 --> Loader Class Initialized
DEBUG - 2018-07-25 01:54:57 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-25 01:54:57 --> Helper loaded: url_helper
INFO - 2018-07-25 01:54:57 --> Helper loaded: form_helper
INFO - 2018-07-25 01:54:57 --> Helper loaded: date_helper
INFO - 2018-07-25 01:54:57 --> Helper loaded: util_helper
INFO - 2018-07-25 01:54:57 --> Helper loaded: text_helper
INFO - 2018-07-25 01:54:57 --> Helper loaded: string_helper
INFO - 2018-07-25 01:54:57 --> Database Driver Class Initialized
DEBUG - 2018-07-25 01:54:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 01:54:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 01:54:57 --> Email Class Initialized
INFO - 2018-07-25 01:54:57 --> Controller Class Initialized
DEBUG - 2018-07-25 01:54:57 --> Home MX_Controller Initialized
DEBUG - 2018-07-25 01:54:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-25 01:54:58 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-25 01:54:58 --> Login MX_Controller Initialized
INFO - 2018-07-25 01:54:58 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-25 01:54:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-25 01:54:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-25 01:54:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-07-25 01:54:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-07-25 01:54:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-07-25 01:54:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-07-25 01:54:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-07-25 01:54:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-07-25 01:54:58 --> Final output sent to browser
DEBUG - 2018-07-25 01:54:58 --> Total execution time: 0.6345
INFO - 2018-07-25 01:54:58 --> Config Class Initialized
INFO - 2018-07-25 01:54:58 --> Hooks Class Initialized
DEBUG - 2018-07-25 01:54:58 --> UTF-8 Support Enabled
INFO - 2018-07-25 01:54:58 --> Utf8 Class Initialized
INFO - 2018-07-25 01:54:58 --> URI Class Initialized
DEBUG - 2018-07-25 01:54:58 --> No URI present. Default controller set.
INFO - 2018-07-25 01:54:59 --> Router Class Initialized
INFO - 2018-07-25 01:54:59 --> Output Class Initialized
INFO - 2018-07-25 01:54:59 --> Security Class Initialized
DEBUG - 2018-07-25 01:54:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 01:54:59 --> Input Class Initialized
INFO - 2018-07-25 01:54:59 --> Language Class Initialized
INFO - 2018-07-25 01:54:59 --> Language Class Initialized
INFO - 2018-07-25 01:54:59 --> Config Class Initialized
INFO - 2018-07-25 01:54:59 --> Loader Class Initialized
DEBUG - 2018-07-25 01:54:59 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-25 01:54:59 --> Helper loaded: url_helper
INFO - 2018-07-25 01:54:59 --> Helper loaded: form_helper
INFO - 2018-07-25 01:54:59 --> Helper loaded: date_helper
INFO - 2018-07-25 01:54:59 --> Helper loaded: util_helper
INFO - 2018-07-25 01:54:59 --> Helper loaded: text_helper
INFO - 2018-07-25 01:54:59 --> Helper loaded: string_helper
INFO - 2018-07-25 01:54:59 --> Database Driver Class Initialized
DEBUG - 2018-07-25 01:54:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 01:54:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 01:54:59 --> Email Class Initialized
INFO - 2018-07-25 01:54:59 --> Controller Class Initialized
DEBUG - 2018-07-25 01:54:59 --> Home MX_Controller Initialized
DEBUG - 2018-07-25 01:54:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-25 01:54:59 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-25 01:54:59 --> Login MX_Controller Initialized
INFO - 2018-07-25 01:54:59 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-25 01:54:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-25 01:54:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-25 01:54:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-07-25 01:54:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-07-25 01:54:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-07-25 01:54:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-07-25 01:54:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-07-25 01:54:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-07-25 01:54:59 --> Final output sent to browser
DEBUG - 2018-07-25 01:54:59 --> Total execution time: 0.7158
INFO - 2018-07-25 01:55:01 --> Config Class Initialized
INFO - 2018-07-25 01:55:01 --> Hooks Class Initialized
DEBUG - 2018-07-25 01:55:01 --> UTF-8 Support Enabled
INFO - 2018-07-25 01:55:01 --> Utf8 Class Initialized
INFO - 2018-07-25 01:55:01 --> URI Class Initialized
INFO - 2018-07-25 01:55:01 --> Router Class Initialized
INFO - 2018-07-25 01:55:01 --> Output Class Initialized
INFO - 2018-07-25 01:55:01 --> Security Class Initialized
DEBUG - 2018-07-25 01:55:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 01:55:01 --> Input Class Initialized
INFO - 2018-07-25 01:55:01 --> Language Class Initialized
ERROR - 2018-07-25 01:55:01 --> 404 Page Not Found: /index
INFO - 2018-07-25 01:55:01 --> Config Class Initialized
INFO - 2018-07-25 01:55:01 --> Hooks Class Initialized
DEBUG - 2018-07-25 01:55:01 --> UTF-8 Support Enabled
INFO - 2018-07-25 01:55:01 --> Utf8 Class Initialized
INFO - 2018-07-25 01:55:01 --> URI Class Initialized
INFO - 2018-07-25 01:55:01 --> Router Class Initialized
INFO - 2018-07-25 01:55:01 --> Output Class Initialized
INFO - 2018-07-25 01:55:01 --> Security Class Initialized
DEBUG - 2018-07-25 01:55:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 01:55:01 --> Input Class Initialized
INFO - 2018-07-25 01:55:01 --> Language Class Initialized
ERROR - 2018-07-25 01:55:01 --> 404 Page Not Found: /index
INFO - 2018-07-25 01:55:01 --> Config Class Initialized
INFO - 2018-07-25 01:55:01 --> Hooks Class Initialized
DEBUG - 2018-07-25 01:55:01 --> UTF-8 Support Enabled
INFO - 2018-07-25 01:55:01 --> Utf8 Class Initialized
INFO - 2018-07-25 01:55:01 --> URI Class Initialized
INFO - 2018-07-25 01:55:01 --> Router Class Initialized
INFO - 2018-07-25 01:55:01 --> Output Class Initialized
INFO - 2018-07-25 01:55:01 --> Security Class Initialized
DEBUG - 2018-07-25 01:55:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 01:55:01 --> Input Class Initialized
INFO - 2018-07-25 01:55:01 --> Language Class Initialized
ERROR - 2018-07-25 01:55:01 --> 404 Page Not Found: /index
INFO - 2018-07-25 01:56:09 --> Config Class Initialized
INFO - 2018-07-25 01:56:10 --> Hooks Class Initialized
DEBUG - 2018-07-25 01:56:10 --> UTF-8 Support Enabled
INFO - 2018-07-25 01:56:10 --> Utf8 Class Initialized
INFO - 2018-07-25 01:56:10 --> URI Class Initialized
INFO - 2018-07-25 01:56:10 --> Router Class Initialized
INFO - 2018-07-25 01:56:10 --> Output Class Initialized
INFO - 2018-07-25 01:56:10 --> Security Class Initialized
DEBUG - 2018-07-25 01:56:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 01:56:10 --> Input Class Initialized
INFO - 2018-07-25 01:56:10 --> Language Class Initialized
ERROR - 2018-07-25 01:56:10 --> 404 Page Not Found: /index
INFO - 2018-07-25 01:56:10 --> Config Class Initialized
INFO - 2018-07-25 01:56:10 --> Hooks Class Initialized
DEBUG - 2018-07-25 01:56:10 --> UTF-8 Support Enabled
INFO - 2018-07-25 01:56:10 --> Utf8 Class Initialized
INFO - 2018-07-25 01:56:10 --> URI Class Initialized
INFO - 2018-07-25 01:56:10 --> Router Class Initialized
INFO - 2018-07-25 01:56:10 --> Output Class Initialized
INFO - 2018-07-25 01:56:10 --> Security Class Initialized
DEBUG - 2018-07-25 01:56:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 01:56:10 --> Input Class Initialized
INFO - 2018-07-25 01:56:10 --> Language Class Initialized
ERROR - 2018-07-25 01:56:10 --> 404 Page Not Found: /index
INFO - 2018-07-25 01:56:10 --> Config Class Initialized
INFO - 2018-07-25 01:56:10 --> Hooks Class Initialized
DEBUG - 2018-07-25 01:56:10 --> UTF-8 Support Enabled
INFO - 2018-07-25 01:56:10 --> Utf8 Class Initialized
INFO - 2018-07-25 01:56:10 --> URI Class Initialized
INFO - 2018-07-25 01:56:10 --> Router Class Initialized
INFO - 2018-07-25 01:56:10 --> Output Class Initialized
INFO - 2018-07-25 01:56:10 --> Security Class Initialized
DEBUG - 2018-07-25 01:56:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 01:56:10 --> Input Class Initialized
INFO - 2018-07-25 01:56:10 --> Language Class Initialized
ERROR - 2018-07-25 01:56:10 --> 404 Page Not Found: /index
INFO - 2018-07-25 01:56:10 --> Config Class Initialized
INFO - 2018-07-25 01:56:10 --> Hooks Class Initialized
DEBUG - 2018-07-25 01:56:10 --> UTF-8 Support Enabled
INFO - 2018-07-25 01:56:10 --> Utf8 Class Initialized
INFO - 2018-07-25 01:56:10 --> URI Class Initialized
INFO - 2018-07-25 01:56:10 --> Router Class Initialized
INFO - 2018-07-25 01:56:10 --> Output Class Initialized
INFO - 2018-07-25 01:56:10 --> Security Class Initialized
DEBUG - 2018-07-25 01:56:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 01:56:10 --> Input Class Initialized
INFO - 2018-07-25 01:56:10 --> Language Class Initialized
ERROR - 2018-07-25 01:56:10 --> 404 Page Not Found: /index
INFO - 2018-07-25 01:56:10 --> Config Class Initialized
INFO - 2018-07-25 01:56:10 --> Hooks Class Initialized
DEBUG - 2018-07-25 01:56:10 --> UTF-8 Support Enabled
INFO - 2018-07-25 01:56:10 --> Utf8 Class Initialized
INFO - 2018-07-25 01:56:10 --> URI Class Initialized
INFO - 2018-07-25 01:56:10 --> Router Class Initialized
INFO - 2018-07-25 01:56:10 --> Output Class Initialized
INFO - 2018-07-25 01:56:10 --> Security Class Initialized
DEBUG - 2018-07-25 01:56:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 01:56:10 --> Input Class Initialized
INFO - 2018-07-25 01:56:10 --> Language Class Initialized
ERROR - 2018-07-25 01:56:10 --> 404 Page Not Found: /index
INFO - 2018-07-25 01:56:10 --> Config Class Initialized
INFO - 2018-07-25 01:56:10 --> Hooks Class Initialized
DEBUG - 2018-07-25 01:56:10 --> UTF-8 Support Enabled
INFO - 2018-07-25 01:56:10 --> Utf8 Class Initialized
INFO - 2018-07-25 01:56:11 --> URI Class Initialized
INFO - 2018-07-25 01:56:11 --> Router Class Initialized
INFO - 2018-07-25 01:56:11 --> Output Class Initialized
INFO - 2018-07-25 01:56:11 --> Security Class Initialized
DEBUG - 2018-07-25 01:56:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 01:56:11 --> Input Class Initialized
INFO - 2018-07-25 01:56:11 --> Language Class Initialized
ERROR - 2018-07-25 01:56:11 --> 404 Page Not Found: /index
INFO - 2018-07-25 01:56:24 --> Config Class Initialized
INFO - 2018-07-25 01:56:24 --> Hooks Class Initialized
DEBUG - 2018-07-25 01:56:24 --> UTF-8 Support Enabled
INFO - 2018-07-25 01:56:24 --> Utf8 Class Initialized
INFO - 2018-07-25 01:56:24 --> URI Class Initialized
DEBUG - 2018-07-25 01:56:24 --> No URI present. Default controller set.
INFO - 2018-07-25 01:56:24 --> Router Class Initialized
INFO - 2018-07-25 01:56:24 --> Output Class Initialized
INFO - 2018-07-25 01:56:24 --> Security Class Initialized
DEBUG - 2018-07-25 01:56:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 01:56:24 --> Input Class Initialized
INFO - 2018-07-25 01:56:24 --> Language Class Initialized
INFO - 2018-07-25 01:56:24 --> Language Class Initialized
INFO - 2018-07-25 01:56:24 --> Config Class Initialized
INFO - 2018-07-25 01:56:24 --> Loader Class Initialized
DEBUG - 2018-07-25 01:56:24 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-25 01:56:24 --> Helper loaded: url_helper
INFO - 2018-07-25 01:56:24 --> Helper loaded: form_helper
INFO - 2018-07-25 01:56:24 --> Helper loaded: date_helper
INFO - 2018-07-25 01:56:24 --> Helper loaded: util_helper
INFO - 2018-07-25 01:56:24 --> Helper loaded: text_helper
INFO - 2018-07-25 01:56:24 --> Helper loaded: string_helper
INFO - 2018-07-25 01:56:24 --> Database Driver Class Initialized
DEBUG - 2018-07-25 01:56:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 01:56:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 01:56:24 --> Email Class Initialized
INFO - 2018-07-25 01:56:24 --> Controller Class Initialized
DEBUG - 2018-07-25 01:56:24 --> Home MX_Controller Initialized
DEBUG - 2018-07-25 01:56:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-25 01:56:24 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-25 01:56:24 --> Login MX_Controller Initialized
INFO - 2018-07-25 01:56:24 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-25 01:56:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-25 01:56:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-25 01:56:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-07-25 01:56:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-07-25 01:56:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-07-25 01:56:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-07-25 01:56:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-07-25 01:56:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-07-25 01:56:24 --> Final output sent to browser
DEBUG - 2018-07-25 01:56:24 --> Total execution time: 0.6237
INFO - 2018-07-25 01:56:25 --> Config Class Initialized
INFO - 2018-07-25 01:56:25 --> Hooks Class Initialized
DEBUG - 2018-07-25 01:56:25 --> UTF-8 Support Enabled
INFO - 2018-07-25 01:56:25 --> Utf8 Class Initialized
INFO - 2018-07-25 01:56:25 --> URI Class Initialized
INFO - 2018-07-25 01:56:25 --> Router Class Initialized
INFO - 2018-07-25 01:56:25 --> Output Class Initialized
INFO - 2018-07-25 01:56:25 --> Security Class Initialized
DEBUG - 2018-07-25 01:56:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 01:56:25 --> Input Class Initialized
INFO - 2018-07-25 01:56:25 --> Language Class Initialized
ERROR - 2018-07-25 01:56:25 --> 404 Page Not Found: /index
INFO - 2018-07-25 01:56:25 --> Config Class Initialized
INFO - 2018-07-25 01:56:25 --> Hooks Class Initialized
DEBUG - 2018-07-25 01:56:25 --> UTF-8 Support Enabled
INFO - 2018-07-25 01:56:25 --> Utf8 Class Initialized
INFO - 2018-07-25 01:56:25 --> URI Class Initialized
INFO - 2018-07-25 01:56:25 --> Router Class Initialized
INFO - 2018-07-25 01:56:25 --> Output Class Initialized
INFO - 2018-07-25 01:56:25 --> Security Class Initialized
DEBUG - 2018-07-25 01:56:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 01:56:25 --> Input Class Initialized
INFO - 2018-07-25 01:56:25 --> Language Class Initialized
ERROR - 2018-07-25 01:56:25 --> 404 Page Not Found: /index
INFO - 2018-07-25 01:56:25 --> Config Class Initialized
INFO - 2018-07-25 01:56:25 --> Hooks Class Initialized
DEBUG - 2018-07-25 01:56:25 --> UTF-8 Support Enabled
INFO - 2018-07-25 01:56:25 --> Utf8 Class Initialized
INFO - 2018-07-25 01:56:25 --> URI Class Initialized
INFO - 2018-07-25 01:56:25 --> Router Class Initialized
INFO - 2018-07-25 01:56:25 --> Output Class Initialized
INFO - 2018-07-25 01:56:25 --> Security Class Initialized
DEBUG - 2018-07-25 01:56:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 01:56:25 --> Input Class Initialized
INFO - 2018-07-25 01:56:25 --> Language Class Initialized
ERROR - 2018-07-25 01:56:25 --> 404 Page Not Found: /index
INFO - 2018-07-25 05:17:33 --> Config Class Initialized
INFO - 2018-07-25 05:17:33 --> Hooks Class Initialized
DEBUG - 2018-07-25 05:17:33 --> UTF-8 Support Enabled
INFO - 2018-07-25 05:17:33 --> Utf8 Class Initialized
INFO - 2018-07-25 05:17:33 --> URI Class Initialized
INFO - 2018-07-25 05:17:33 --> Router Class Initialized
INFO - 2018-07-25 05:17:33 --> Output Class Initialized
INFO - 2018-07-25 05:17:33 --> Security Class Initialized
DEBUG - 2018-07-25 05:17:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 05:17:33 --> Input Class Initialized
INFO - 2018-07-25 05:17:33 --> Language Class Initialized
INFO - 2018-07-25 05:17:33 --> Language Class Initialized
INFO - 2018-07-25 05:17:33 --> Config Class Initialized
INFO - 2018-07-25 05:17:33 --> Loader Class Initialized
DEBUG - 2018-07-25 05:17:33 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-25 05:17:33 --> Helper loaded: url_helper
INFO - 2018-07-25 05:17:33 --> Helper loaded: form_helper
INFO - 2018-07-25 05:17:33 --> Helper loaded: date_helper
INFO - 2018-07-25 05:17:33 --> Helper loaded: util_helper
INFO - 2018-07-25 05:17:33 --> Helper loaded: text_helper
INFO - 2018-07-25 05:17:33 --> Helper loaded: string_helper
INFO - 2018-07-25 05:17:33 --> Database Driver Class Initialized
DEBUG - 2018-07-25 05:17:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 05:17:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 05:17:33 --> Email Class Initialized
INFO - 2018-07-25 05:17:33 --> Controller Class Initialized
DEBUG - 2018-07-25 05:17:33 --> Admin MX_Controller Initialized
INFO - 2018-07-25 05:17:33 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-25 05:17:33 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-25 05:17:33 --> Login MX_Controller Initialized
DEBUG - 2018-07-25 05:17:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-25 05:17:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-25 05:17:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/logins/login.php
INFO - 2018-07-25 05:17:34 --> Config Class Initialized
INFO - 2018-07-25 05:17:34 --> Hooks Class Initialized
DEBUG - 2018-07-25 05:17:34 --> UTF-8 Support Enabled
INFO - 2018-07-25 05:17:34 --> Utf8 Class Initialized
INFO - 2018-07-25 05:17:34 --> URI Class Initialized
INFO - 2018-07-25 05:17:34 --> Router Class Initialized
INFO - 2018-07-25 05:17:34 --> Output Class Initialized
INFO - 2018-07-25 05:17:34 --> Security Class Initialized
DEBUG - 2018-07-25 05:17:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 05:17:34 --> Input Class Initialized
INFO - 2018-07-25 05:17:34 --> Language Class Initialized
ERROR - 2018-07-25 05:17:34 --> 404 Page Not Found: /index
INFO - 2018-07-25 05:17:38 --> Config Class Initialized
INFO - 2018-07-25 05:17:38 --> Hooks Class Initialized
DEBUG - 2018-07-25 05:17:38 --> UTF-8 Support Enabled
INFO - 2018-07-25 05:17:38 --> Utf8 Class Initialized
INFO - 2018-07-25 05:17:38 --> URI Class Initialized
INFO - 2018-07-25 05:17:38 --> Router Class Initialized
INFO - 2018-07-25 05:17:38 --> Output Class Initialized
INFO - 2018-07-25 05:17:38 --> Security Class Initialized
DEBUG - 2018-07-25 05:17:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 05:17:39 --> Input Class Initialized
INFO - 2018-07-25 05:17:39 --> Language Class Initialized
INFO - 2018-07-25 05:17:39 --> Language Class Initialized
INFO - 2018-07-25 05:17:39 --> Config Class Initialized
INFO - 2018-07-25 05:17:39 --> Loader Class Initialized
DEBUG - 2018-07-25 05:17:39 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-25 05:17:39 --> Helper loaded: url_helper
INFO - 2018-07-25 05:17:39 --> Helper loaded: form_helper
INFO - 2018-07-25 05:17:39 --> Helper loaded: date_helper
INFO - 2018-07-25 05:17:39 --> Helper loaded: util_helper
INFO - 2018-07-25 05:17:39 --> Helper loaded: text_helper
INFO - 2018-07-25 05:17:39 --> Helper loaded: string_helper
INFO - 2018-07-25 05:17:39 --> Database Driver Class Initialized
DEBUG - 2018-07-25 05:17:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 05:17:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 05:17:39 --> Email Class Initialized
INFO - 2018-07-25 05:17:39 --> Controller Class Initialized
DEBUG - 2018-07-25 05:17:39 --> Login MX_Controller Initialized
INFO - 2018-07-25 05:17:39 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-25 05:17:39 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-25 05:17:39 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-25 05:17:39 --> Email starts for gopaltesting@yopmail.com fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-07-25 05:17:39 --> Login status gopaltesting@yopmail.com - failure
INFO - 2018-07-25 05:17:39 --> Final output sent to browser
DEBUG - 2018-07-25 05:17:39 --> Total execution time: 0.5271
INFO - 2018-07-25 05:17:42 --> Config Class Initialized
INFO - 2018-07-25 05:17:42 --> Hooks Class Initialized
DEBUG - 2018-07-25 05:17:42 --> UTF-8 Support Enabled
INFO - 2018-07-25 05:17:42 --> Utf8 Class Initialized
INFO - 2018-07-25 05:17:42 --> URI Class Initialized
INFO - 2018-07-25 05:17:42 --> Router Class Initialized
INFO - 2018-07-25 05:17:42 --> Output Class Initialized
INFO - 2018-07-25 05:17:42 --> Security Class Initialized
DEBUG - 2018-07-25 05:17:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 05:17:42 --> Input Class Initialized
INFO - 2018-07-25 05:17:42 --> Language Class Initialized
INFO - 2018-07-25 05:17:42 --> Language Class Initialized
INFO - 2018-07-25 05:17:42 --> Config Class Initialized
INFO - 2018-07-25 05:17:42 --> Loader Class Initialized
DEBUG - 2018-07-25 05:17:42 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-25 05:17:42 --> Helper loaded: url_helper
INFO - 2018-07-25 05:17:42 --> Helper loaded: form_helper
INFO - 2018-07-25 05:17:42 --> Helper loaded: date_helper
INFO - 2018-07-25 05:17:42 --> Helper loaded: util_helper
INFO - 2018-07-25 05:17:42 --> Helper loaded: text_helper
INFO - 2018-07-25 05:17:42 --> Helper loaded: string_helper
INFO - 2018-07-25 05:17:42 --> Database Driver Class Initialized
DEBUG - 2018-07-25 05:17:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 05:17:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 05:17:42 --> Email Class Initialized
INFO - 2018-07-25 05:17:42 --> Controller Class Initialized
DEBUG - 2018-07-25 05:17:42 --> Login MX_Controller Initialized
INFO - 2018-07-25 05:17:42 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-25 05:17:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-25 05:17:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-25 05:17:42 --> Email starts for gopaltesting@yopmail.com fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-07-25 05:17:42 --> Login status gopaltesting@yopmail.com - failure
INFO - 2018-07-25 05:17:42 --> Final output sent to browser
DEBUG - 2018-07-25 05:17:42 --> Total execution time: 0.4727
INFO - 2018-07-25 05:17:49 --> Config Class Initialized
INFO - 2018-07-25 05:17:49 --> Hooks Class Initialized
DEBUG - 2018-07-25 05:17:49 --> UTF-8 Support Enabled
INFO - 2018-07-25 05:17:49 --> Utf8 Class Initialized
INFO - 2018-07-25 05:17:49 --> URI Class Initialized
INFO - 2018-07-25 05:17:49 --> Router Class Initialized
INFO - 2018-07-25 05:17:49 --> Output Class Initialized
INFO - 2018-07-25 05:17:49 --> Security Class Initialized
DEBUG - 2018-07-25 05:17:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 05:17:49 --> Input Class Initialized
INFO - 2018-07-25 05:17:49 --> Language Class Initialized
INFO - 2018-07-25 05:17:49 --> Language Class Initialized
INFO - 2018-07-25 05:17:49 --> Config Class Initialized
INFO - 2018-07-25 05:17:49 --> Loader Class Initialized
DEBUG - 2018-07-25 05:17:49 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-25 05:17:49 --> Helper loaded: url_helper
INFO - 2018-07-25 05:17:49 --> Helper loaded: form_helper
INFO - 2018-07-25 05:17:49 --> Helper loaded: date_helper
INFO - 2018-07-25 05:17:49 --> Helper loaded: util_helper
INFO - 2018-07-25 05:17:49 --> Helper loaded: text_helper
INFO - 2018-07-25 05:17:49 --> Helper loaded: string_helper
INFO - 2018-07-25 05:17:49 --> Database Driver Class Initialized
DEBUG - 2018-07-25 05:17:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 05:17:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 05:17:49 --> Email Class Initialized
INFO - 2018-07-25 05:17:49 --> Controller Class Initialized
DEBUG - 2018-07-25 05:17:49 --> Login MX_Controller Initialized
INFO - 2018-07-25 05:17:49 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-25 05:17:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-25 05:17:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-25 05:17:49 --> Email starts for admin@colin.com fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-07-25 05:17:49 --> User session created for 1
INFO - 2018-07-25 05:17:49 --> Login status admin@colin.com - success
INFO - 2018-07-25 05:17:49 --> Final output sent to browser
DEBUG - 2018-07-25 05:17:49 --> Total execution time: 0.5556
INFO - 2018-07-25 05:17:49 --> Config Class Initialized
INFO - 2018-07-25 05:17:49 --> Hooks Class Initialized
DEBUG - 2018-07-25 05:17:49 --> UTF-8 Support Enabled
INFO - 2018-07-25 05:17:49 --> Utf8 Class Initialized
INFO - 2018-07-25 05:17:49 --> URI Class Initialized
INFO - 2018-07-25 05:17:49 --> Router Class Initialized
INFO - 2018-07-25 05:17:49 --> Output Class Initialized
INFO - 2018-07-25 05:17:49 --> Security Class Initialized
DEBUG - 2018-07-25 05:17:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 05:17:49 --> Input Class Initialized
INFO - 2018-07-25 05:17:49 --> Language Class Initialized
INFO - 2018-07-25 05:17:49 --> Language Class Initialized
INFO - 2018-07-25 05:17:49 --> Config Class Initialized
INFO - 2018-07-25 05:17:50 --> Loader Class Initialized
DEBUG - 2018-07-25 05:17:50 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-25 05:17:50 --> Helper loaded: url_helper
INFO - 2018-07-25 05:17:50 --> Helper loaded: form_helper
INFO - 2018-07-25 05:17:50 --> Helper loaded: date_helper
INFO - 2018-07-25 05:17:50 --> Helper loaded: util_helper
INFO - 2018-07-25 05:17:50 --> Helper loaded: text_helper
INFO - 2018-07-25 05:17:50 --> Helper loaded: string_helper
INFO - 2018-07-25 05:17:50 --> Database Driver Class Initialized
DEBUG - 2018-07-25 05:17:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 05:17:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 05:17:50 --> Email Class Initialized
INFO - 2018-07-25 05:17:50 --> Controller Class Initialized
DEBUG - 2018-07-25 05:17:50 --> Admin MX_Controller Initialized
INFO - 2018-07-25 05:17:50 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-25 05:17:50 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-25 05:17:50 --> Login MX_Controller Initialized
DEBUG - 2018-07-25 05:17:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-25 05:17:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-25 05:17:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-25 05:17:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-25 05:17:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-25 05:17:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-25 05:17:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-25 05:17:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/dashboard.php
INFO - 2018-07-25 05:17:50 --> Final output sent to browser
DEBUG - 2018-07-25 05:17:50 --> Total execution time: 0.7692
INFO - 2018-07-25 05:17:50 --> Config Class Initialized
INFO - 2018-07-25 05:17:50 --> Hooks Class Initialized
DEBUG - 2018-07-25 05:17:50 --> UTF-8 Support Enabled
INFO - 2018-07-25 05:17:50 --> Utf8 Class Initialized
INFO - 2018-07-25 05:17:50 --> URI Class Initialized
INFO - 2018-07-25 05:17:50 --> Router Class Initialized
INFO - 2018-07-25 05:17:50 --> Output Class Initialized
INFO - 2018-07-25 05:17:50 --> Security Class Initialized
DEBUG - 2018-07-25 05:17:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 05:17:50 --> Input Class Initialized
INFO - 2018-07-25 05:17:50 --> Language Class Initialized
ERROR - 2018-07-25 05:17:50 --> 404 Page Not Found: /index
INFO - 2018-07-25 05:17:51 --> Config Class Initialized
INFO - 2018-07-25 05:17:51 --> Hooks Class Initialized
DEBUG - 2018-07-25 05:17:51 --> UTF-8 Support Enabled
INFO - 2018-07-25 05:17:51 --> Utf8 Class Initialized
INFO - 2018-07-25 05:17:51 --> URI Class Initialized
INFO - 2018-07-25 05:17:51 --> Router Class Initialized
INFO - 2018-07-25 05:17:51 --> Output Class Initialized
INFO - 2018-07-25 05:17:51 --> Security Class Initialized
DEBUG - 2018-07-25 05:17:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 05:17:51 --> Input Class Initialized
INFO - 2018-07-25 05:17:51 --> Language Class Initialized
ERROR - 2018-07-25 05:17:51 --> 404 Page Not Found: /index
INFO - 2018-07-25 05:17:52 --> Config Class Initialized
INFO - 2018-07-25 05:17:52 --> Hooks Class Initialized
DEBUG - 2018-07-25 05:17:52 --> UTF-8 Support Enabled
INFO - 2018-07-25 05:17:52 --> Utf8 Class Initialized
INFO - 2018-07-25 05:17:52 --> URI Class Initialized
INFO - 2018-07-25 05:17:52 --> Router Class Initialized
INFO - 2018-07-25 05:17:52 --> Output Class Initialized
INFO - 2018-07-25 05:17:52 --> Security Class Initialized
DEBUG - 2018-07-25 05:17:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 05:17:52 --> Input Class Initialized
INFO - 2018-07-25 05:17:52 --> Language Class Initialized
INFO - 2018-07-25 05:17:52 --> Language Class Initialized
INFO - 2018-07-25 05:17:52 --> Config Class Initialized
INFO - 2018-07-25 05:17:52 --> Loader Class Initialized
DEBUG - 2018-07-25 05:17:52 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-25 05:17:52 --> Helper loaded: url_helper
INFO - 2018-07-25 05:17:52 --> Helper loaded: form_helper
INFO - 2018-07-25 05:17:52 --> Helper loaded: date_helper
INFO - 2018-07-25 05:17:52 --> Helper loaded: util_helper
INFO - 2018-07-25 05:17:52 --> Helper loaded: text_helper
INFO - 2018-07-25 05:17:52 --> Helper loaded: string_helper
INFO - 2018-07-25 05:17:52 --> Database Driver Class Initialized
DEBUG - 2018-07-25 05:17:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 05:17:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 05:17:52 --> Email Class Initialized
INFO - 2018-07-25 05:17:52 --> Controller Class Initialized
DEBUG - 2018-07-25 05:17:52 --> Users MX_Controller Initialized
DEBUG - 2018-07-25 05:17:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-25 05:17:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-07-25 05:17:52 --> Helper loaded: file_helper
DEBUG - 2018-07-25 05:17:52 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-25 05:17:52 --> Login MX_Controller Initialized
INFO - 2018-07-25 05:17:52 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-25 05:17:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-25 05:17:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-25 05:17:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-25 05:17:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-25 05:17:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-25 05:17:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-25 05:17:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/users.php
INFO - 2018-07-25 05:17:53 --> Final output sent to browser
DEBUG - 2018-07-25 05:17:53 --> Total execution time: 0.9725
INFO - 2018-07-25 05:17:53 --> Config Class Initialized
INFO - 2018-07-25 05:17:53 --> Hooks Class Initialized
DEBUG - 2018-07-25 05:17:53 --> UTF-8 Support Enabled
INFO - 2018-07-25 05:17:53 --> Utf8 Class Initialized
INFO - 2018-07-25 05:17:53 --> URI Class Initialized
INFO - 2018-07-25 05:17:53 --> Router Class Initialized
INFO - 2018-07-25 05:17:53 --> Output Class Initialized
INFO - 2018-07-25 05:17:53 --> Security Class Initialized
DEBUG - 2018-07-25 05:17:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 05:17:53 --> Input Class Initialized
INFO - 2018-07-25 05:17:53 --> Language Class Initialized
INFO - 2018-07-25 05:17:53 --> Language Class Initialized
INFO - 2018-07-25 05:17:53 --> Config Class Initialized
INFO - 2018-07-25 05:17:53 --> Loader Class Initialized
DEBUG - 2018-07-25 05:17:53 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-25 05:17:53 --> Helper loaded: url_helper
INFO - 2018-07-25 05:17:54 --> Helper loaded: form_helper
INFO - 2018-07-25 05:17:54 --> Helper loaded: date_helper
INFO - 2018-07-25 05:17:54 --> Helper loaded: util_helper
INFO - 2018-07-25 05:17:54 --> Helper loaded: text_helper
INFO - 2018-07-25 05:17:54 --> Helper loaded: string_helper
INFO - 2018-07-25 05:17:54 --> Database Driver Class Initialized
DEBUG - 2018-07-25 05:17:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 05:17:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 05:17:54 --> Email Class Initialized
INFO - 2018-07-25 05:17:54 --> Controller Class Initialized
DEBUG - 2018-07-25 05:17:54 --> Users MX_Controller Initialized
DEBUG - 2018-07-25 05:17:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-25 05:17:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-07-25 05:17:54 --> Helper loaded: file_helper
DEBUG - 2018-07-25 05:17:54 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-25 05:17:54 --> Login MX_Controller Initialized
INFO - 2018-07-25 05:17:54 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-25 05:17:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-25 05:17:54 --> Final output sent to browser
DEBUG - 2018-07-25 05:17:54 --> Total execution time: 1.1094
INFO - 2018-07-25 05:17:59 --> Config Class Initialized
INFO - 2018-07-25 05:17:59 --> Hooks Class Initialized
DEBUG - 2018-07-25 05:17:59 --> UTF-8 Support Enabled
INFO - 2018-07-25 05:17:59 --> Utf8 Class Initialized
INFO - 2018-07-25 05:17:59 --> URI Class Initialized
INFO - 2018-07-25 05:17:59 --> Router Class Initialized
INFO - 2018-07-25 05:17:59 --> Output Class Initialized
INFO - 2018-07-25 05:17:59 --> Security Class Initialized
DEBUG - 2018-07-25 05:17:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 05:17:59 --> Input Class Initialized
INFO - 2018-07-25 05:17:59 --> Language Class Initialized
INFO - 2018-07-25 05:17:59 --> Language Class Initialized
INFO - 2018-07-25 05:17:59 --> Config Class Initialized
INFO - 2018-07-25 05:17:59 --> Loader Class Initialized
DEBUG - 2018-07-25 05:17:59 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-25 05:17:59 --> Helper loaded: url_helper
INFO - 2018-07-25 05:17:59 --> Helper loaded: form_helper
INFO - 2018-07-25 05:17:59 --> Helper loaded: date_helper
INFO - 2018-07-25 05:17:59 --> Helper loaded: util_helper
INFO - 2018-07-25 05:17:59 --> Helper loaded: text_helper
INFO - 2018-07-25 05:17:59 --> Helper loaded: string_helper
INFO - 2018-07-25 05:17:59 --> Database Driver Class Initialized
DEBUG - 2018-07-25 05:17:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 05:17:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 05:17:59 --> Email Class Initialized
INFO - 2018-07-25 05:17:59 --> Controller Class Initialized
DEBUG - 2018-07-25 05:17:59 --> Users MX_Controller Initialized
DEBUG - 2018-07-25 05:17:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-25 05:17:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-07-25 05:17:59 --> Helper loaded: file_helper
DEBUG - 2018-07-25 05:17:59 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-25 05:17:59 --> Login MX_Controller Initialized
INFO - 2018-07-25 05:17:59 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-25 05:17:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-25 05:17:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-25 05:17:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-25 05:17:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-25 05:17:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-25 05:17:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-25 05:17:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-25 05:17:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/create_user.php
INFO - 2018-07-25 05:17:59 --> Final output sent to browser
DEBUG - 2018-07-25 05:17:59 --> Total execution time: 0.7455
INFO - 2018-07-25 05:18:44 --> Config Class Initialized
INFO - 2018-07-25 05:18:44 --> Hooks Class Initialized
DEBUG - 2018-07-25 05:18:44 --> UTF-8 Support Enabled
INFO - 2018-07-25 05:18:44 --> Utf8 Class Initialized
INFO - 2018-07-25 05:18:44 --> URI Class Initialized
INFO - 2018-07-25 05:18:44 --> Router Class Initialized
INFO - 2018-07-25 05:18:44 --> Output Class Initialized
INFO - 2018-07-25 05:18:44 --> Security Class Initialized
DEBUG - 2018-07-25 05:18:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 05:18:44 --> Input Class Initialized
INFO - 2018-07-25 05:18:44 --> Language Class Initialized
INFO - 2018-07-25 05:18:44 --> Language Class Initialized
INFO - 2018-07-25 05:18:44 --> Config Class Initialized
INFO - 2018-07-25 05:18:44 --> Loader Class Initialized
DEBUG - 2018-07-25 05:18:44 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-25 05:18:44 --> Helper loaded: url_helper
INFO - 2018-07-25 05:18:44 --> Helper loaded: form_helper
INFO - 2018-07-25 05:18:44 --> Helper loaded: date_helper
INFO - 2018-07-25 05:18:44 --> Helper loaded: util_helper
INFO - 2018-07-25 05:18:44 --> Helper loaded: text_helper
INFO - 2018-07-25 05:18:44 --> Helper loaded: string_helper
INFO - 2018-07-25 05:18:44 --> Database Driver Class Initialized
DEBUG - 2018-07-25 05:18:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 05:18:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 05:18:44 --> Email Class Initialized
INFO - 2018-07-25 05:18:44 --> Controller Class Initialized
DEBUG - 2018-07-25 05:18:44 --> Users MX_Controller Initialized
DEBUG - 2018-07-25 05:18:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-25 05:18:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-07-25 05:18:44 --> Helper loaded: file_helper
DEBUG - 2018-07-25 05:18:44 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-25 05:18:44 --> Login MX_Controller Initialized
INFO - 2018-07-25 05:18:44 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-25 05:18:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-25 05:18:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-25 05:18:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
ERROR - 2018-07-25 05:18:44 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable E:\xampp\htdocs\consulting\application\modules\admin\controllers\Users.php 311
ERROR - 2018-07-25 05:18:44 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable E:\xampp\htdocs\consulting\application\modules\admin\controllers\Users.php 311
INFO - 2018-07-25 05:18:44 --> Config Class Initialized
INFO - 2018-07-25 05:18:44 --> Hooks Class Initialized
DEBUG - 2018-07-25 05:18:44 --> UTF-8 Support Enabled
INFO - 2018-07-25 05:18:44 --> Utf8 Class Initialized
INFO - 2018-07-25 05:18:45 --> URI Class Initialized
INFO - 2018-07-25 05:18:45 --> Router Class Initialized
INFO - 2018-07-25 05:18:45 --> Output Class Initialized
INFO - 2018-07-25 05:18:45 --> Security Class Initialized
DEBUG - 2018-07-25 05:18:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 05:18:45 --> Input Class Initialized
INFO - 2018-07-25 05:18:45 --> Language Class Initialized
INFO - 2018-07-25 05:18:45 --> Language Class Initialized
INFO - 2018-07-25 05:18:45 --> Config Class Initialized
INFO - 2018-07-25 05:18:45 --> Loader Class Initialized
DEBUG - 2018-07-25 05:18:45 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-25 05:18:45 --> Helper loaded: url_helper
INFO - 2018-07-25 05:18:45 --> Helper loaded: form_helper
INFO - 2018-07-25 05:18:45 --> Helper loaded: date_helper
INFO - 2018-07-25 05:18:45 --> Helper loaded: util_helper
INFO - 2018-07-25 05:18:45 --> Helper loaded: text_helper
INFO - 2018-07-25 05:18:45 --> Helper loaded: string_helper
INFO - 2018-07-25 05:18:45 --> Database Driver Class Initialized
DEBUG - 2018-07-25 05:18:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 05:18:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 05:18:45 --> Email Class Initialized
INFO - 2018-07-25 05:18:45 --> Controller Class Initialized
DEBUG - 2018-07-25 05:18:45 --> Users MX_Controller Initialized
DEBUG - 2018-07-25 05:18:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-25 05:18:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-07-25 05:18:45 --> Helper loaded: file_helper
DEBUG - 2018-07-25 05:18:45 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-25 05:18:45 --> Login MX_Controller Initialized
INFO - 2018-07-25 05:18:45 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-25 05:18:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-25 05:18:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-25 05:18:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-25 05:18:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-25 05:18:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-25 05:18:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-25 05:18:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/users.php
INFO - 2018-07-25 05:18:45 --> Final output sent to browser
DEBUG - 2018-07-25 05:18:45 --> Total execution time: 0.6283
INFO - 2018-07-25 05:18:45 --> Config Class Initialized
INFO - 2018-07-25 05:18:45 --> Hooks Class Initialized
DEBUG - 2018-07-25 05:18:46 --> UTF-8 Support Enabled
INFO - 2018-07-25 05:18:46 --> Utf8 Class Initialized
INFO - 2018-07-25 05:18:46 --> URI Class Initialized
INFO - 2018-07-25 05:18:46 --> Router Class Initialized
INFO - 2018-07-25 05:18:46 --> Output Class Initialized
INFO - 2018-07-25 05:18:46 --> Security Class Initialized
DEBUG - 2018-07-25 05:18:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 05:18:46 --> Input Class Initialized
INFO - 2018-07-25 05:18:46 --> Language Class Initialized
INFO - 2018-07-25 05:18:46 --> Language Class Initialized
INFO - 2018-07-25 05:18:46 --> Config Class Initialized
INFO - 2018-07-25 05:18:46 --> Loader Class Initialized
DEBUG - 2018-07-25 05:18:46 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-25 05:18:46 --> Helper loaded: url_helper
INFO - 2018-07-25 05:18:46 --> Helper loaded: form_helper
INFO - 2018-07-25 05:18:46 --> Helper loaded: date_helper
INFO - 2018-07-25 05:18:46 --> Helper loaded: util_helper
INFO - 2018-07-25 05:18:46 --> Helper loaded: text_helper
INFO - 2018-07-25 05:18:46 --> Helper loaded: string_helper
INFO - 2018-07-25 05:18:46 --> Database Driver Class Initialized
DEBUG - 2018-07-25 05:18:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 05:18:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 05:18:46 --> Email Class Initialized
INFO - 2018-07-25 05:18:46 --> Controller Class Initialized
DEBUG - 2018-07-25 05:18:46 --> Users MX_Controller Initialized
DEBUG - 2018-07-25 05:18:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-25 05:18:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-07-25 05:18:46 --> Helper loaded: file_helper
DEBUG - 2018-07-25 05:18:46 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-25 05:18:46 --> Login MX_Controller Initialized
INFO - 2018-07-25 05:18:46 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-25 05:18:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-25 05:18:46 --> Final output sent to browser
DEBUG - 2018-07-25 05:18:46 --> Total execution time: 1.0644
INFO - 2018-07-25 05:18:47 --> Config Class Initialized
INFO - 2018-07-25 05:18:47 --> Hooks Class Initialized
DEBUG - 2018-07-25 05:18:47 --> UTF-8 Support Enabled
INFO - 2018-07-25 05:18:47 --> Utf8 Class Initialized
INFO - 2018-07-25 05:18:47 --> URI Class Initialized
INFO - 2018-07-25 05:18:47 --> Router Class Initialized
INFO - 2018-07-25 05:18:47 --> Output Class Initialized
INFO - 2018-07-25 05:18:47 --> Security Class Initialized
DEBUG - 2018-07-25 05:18:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 05:18:47 --> Input Class Initialized
INFO - 2018-07-25 05:18:47 --> Language Class Initialized
INFO - 2018-07-25 05:18:47 --> Language Class Initialized
INFO - 2018-07-25 05:18:47 --> Config Class Initialized
INFO - 2018-07-25 05:18:47 --> Loader Class Initialized
DEBUG - 2018-07-25 05:18:47 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-25 05:18:47 --> Helper loaded: url_helper
INFO - 2018-07-25 05:18:47 --> Helper loaded: form_helper
INFO - 2018-07-25 05:18:47 --> Helper loaded: date_helper
INFO - 2018-07-25 05:18:47 --> Helper loaded: util_helper
INFO - 2018-07-25 05:18:47 --> Helper loaded: text_helper
INFO - 2018-07-25 05:18:47 --> Helper loaded: string_helper
INFO - 2018-07-25 05:18:47 --> Database Driver Class Initialized
DEBUG - 2018-07-25 05:18:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 05:18:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 05:18:47 --> Email Class Initialized
INFO - 2018-07-25 05:18:47 --> Controller Class Initialized
DEBUG - 2018-07-25 05:18:47 --> Users MX_Controller Initialized
DEBUG - 2018-07-25 05:18:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-25 05:18:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-07-25 05:18:47 --> Helper loaded: file_helper
DEBUG - 2018-07-25 05:18:47 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-25 05:18:47 --> Login MX_Controller Initialized
INFO - 2018-07-25 05:18:47 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-25 05:18:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-25 05:18:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-25 05:18:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-25 05:18:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-25 05:18:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-25 05:18:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-25 05:18:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-25 05:18:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/create_user.php
INFO - 2018-07-25 05:18:47 --> Final output sent to browser
DEBUG - 2018-07-25 05:18:47 --> Total execution time: 0.7745
INFO - 2018-07-25 05:18:51 --> Config Class Initialized
INFO - 2018-07-25 05:18:51 --> Hooks Class Initialized
DEBUG - 2018-07-25 05:18:51 --> UTF-8 Support Enabled
INFO - 2018-07-25 05:18:51 --> Utf8 Class Initialized
INFO - 2018-07-25 05:18:51 --> URI Class Initialized
INFO - 2018-07-25 05:18:51 --> Router Class Initialized
INFO - 2018-07-25 05:18:51 --> Output Class Initialized
INFO - 2018-07-25 05:18:51 --> Security Class Initialized
DEBUG - 2018-07-25 05:18:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 05:18:51 --> Input Class Initialized
INFO - 2018-07-25 05:18:51 --> Language Class Initialized
INFO - 2018-07-25 05:18:51 --> Language Class Initialized
INFO - 2018-07-25 05:18:51 --> Config Class Initialized
INFO - 2018-07-25 05:18:51 --> Loader Class Initialized
DEBUG - 2018-07-25 05:18:51 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-25 05:18:51 --> Helper loaded: url_helper
INFO - 2018-07-25 05:18:51 --> Helper loaded: form_helper
INFO - 2018-07-25 05:18:51 --> Helper loaded: date_helper
INFO - 2018-07-25 05:18:51 --> Helper loaded: util_helper
INFO - 2018-07-25 05:18:51 --> Helper loaded: text_helper
INFO - 2018-07-25 05:18:51 --> Helper loaded: string_helper
INFO - 2018-07-25 05:18:51 --> Database Driver Class Initialized
DEBUG - 2018-07-25 05:18:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 05:18:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 05:18:51 --> Email Class Initialized
INFO - 2018-07-25 05:18:51 --> Controller Class Initialized
DEBUG - 2018-07-25 05:18:51 --> Users MX_Controller Initialized
DEBUG - 2018-07-25 05:18:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-25 05:18:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-07-25 05:18:51 --> Helper loaded: file_helper
DEBUG - 2018-07-25 05:18:51 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-25 05:18:51 --> Login MX_Controller Initialized
INFO - 2018-07-25 05:18:51 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-25 05:18:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-25 05:18:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-25 05:18:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-25 05:18:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-25 05:18:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-25 05:18:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-25 05:18:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-25 05:18:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/create_user.php
INFO - 2018-07-25 05:18:51 --> Final output sent to browser
DEBUG - 2018-07-25 05:18:51 --> Total execution time: 0.6724
INFO - 2018-07-25 05:19:10 --> Config Class Initialized
INFO - 2018-07-25 05:19:10 --> Hooks Class Initialized
DEBUG - 2018-07-25 05:19:10 --> UTF-8 Support Enabled
INFO - 2018-07-25 05:19:10 --> Utf8 Class Initialized
INFO - 2018-07-25 05:19:10 --> URI Class Initialized
INFO - 2018-07-25 05:19:10 --> Router Class Initialized
INFO - 2018-07-25 05:19:10 --> Output Class Initialized
INFO - 2018-07-25 05:19:10 --> Security Class Initialized
DEBUG - 2018-07-25 05:19:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 05:19:10 --> Input Class Initialized
INFO - 2018-07-25 05:19:10 --> Language Class Initialized
INFO - 2018-07-25 05:19:11 --> Language Class Initialized
INFO - 2018-07-25 05:19:11 --> Config Class Initialized
INFO - 2018-07-25 05:19:11 --> Loader Class Initialized
DEBUG - 2018-07-25 05:19:11 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-25 05:19:11 --> Helper loaded: url_helper
INFO - 2018-07-25 05:19:11 --> Helper loaded: form_helper
INFO - 2018-07-25 05:19:11 --> Helper loaded: date_helper
INFO - 2018-07-25 05:19:11 --> Helper loaded: util_helper
INFO - 2018-07-25 05:19:11 --> Helper loaded: text_helper
INFO - 2018-07-25 05:19:11 --> Helper loaded: string_helper
INFO - 2018-07-25 05:19:11 --> Database Driver Class Initialized
DEBUG - 2018-07-25 05:19:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 05:19:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 05:19:11 --> Email Class Initialized
INFO - 2018-07-25 05:19:11 --> Controller Class Initialized
DEBUG - 2018-07-25 05:19:11 --> Admin MX_Controller Initialized
INFO - 2018-07-25 05:19:11 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-25 05:19:11 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-25 05:19:11 --> Login MX_Controller Initialized
DEBUG - 2018-07-25 05:19:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-25 05:19:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-25 05:19:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/logins/login.php
INFO - 2018-07-25 05:19:11 --> Config Class Initialized
INFO - 2018-07-25 05:19:11 --> Hooks Class Initialized
DEBUG - 2018-07-25 05:19:11 --> UTF-8 Support Enabled
INFO - 2018-07-25 05:19:11 --> Utf8 Class Initialized
INFO - 2018-07-25 05:19:11 --> URI Class Initialized
INFO - 2018-07-25 05:19:11 --> Router Class Initialized
INFO - 2018-07-25 05:19:11 --> Output Class Initialized
INFO - 2018-07-25 05:19:11 --> Config Class Initialized
INFO - 2018-07-25 05:19:11 --> Hooks Class Initialized
INFO - 2018-07-25 05:19:11 --> Security Class Initialized
DEBUG - 2018-07-25 05:19:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-07-25 05:19:11 --> UTF-8 Support Enabled
INFO - 2018-07-25 05:19:11 --> Utf8 Class Initialized
INFO - 2018-07-25 05:19:11 --> Input Class Initialized
INFO - 2018-07-25 05:19:11 --> URI Class Initialized
INFO - 2018-07-25 05:19:11 --> Language Class Initialized
INFO - 2018-07-25 05:19:11 --> Router Class Initialized
INFO - 2018-07-25 05:19:11 --> Language Class Initialized
INFO - 2018-07-25 05:19:11 --> Config Class Initialized
INFO - 2018-07-25 05:19:11 --> Output Class Initialized
INFO - 2018-07-25 05:19:11 --> Security Class Initialized
INFO - 2018-07-25 05:19:11 --> Loader Class Initialized
DEBUG - 2018-07-25 05:19:11 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
DEBUG - 2018-07-25 05:19:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 05:19:11 --> Input Class Initialized
INFO - 2018-07-25 05:19:11 --> Helper loaded: url_helper
INFO - 2018-07-25 05:19:11 --> Language Class Initialized
INFO - 2018-07-25 05:19:11 --> Helper loaded: form_helper
ERROR - 2018-07-25 05:19:11 --> 404 Page Not Found: /index
INFO - 2018-07-25 05:19:11 --> Helper loaded: date_helper
INFO - 2018-07-25 05:19:11 --> Helper loaded: util_helper
INFO - 2018-07-25 05:19:11 --> Helper loaded: text_helper
INFO - 2018-07-25 05:19:11 --> Helper loaded: string_helper
INFO - 2018-07-25 05:19:11 --> Database Driver Class Initialized
DEBUG - 2018-07-25 05:19:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 05:19:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 05:19:11 --> Email Class Initialized
INFO - 2018-07-25 05:19:11 --> Controller Class Initialized
DEBUG - 2018-07-25 05:19:11 --> Admin MX_Controller Initialized
INFO - 2018-07-25 05:19:11 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-25 05:19:11 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-25 05:19:11 --> Login MX_Controller Initialized
DEBUG - 2018-07-25 05:19:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-25 05:19:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-25 05:19:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/logins/login.php
INFO - 2018-07-25 05:19:12 --> Config Class Initialized
INFO - 2018-07-25 05:19:12 --> Hooks Class Initialized
DEBUG - 2018-07-25 05:19:12 --> UTF-8 Support Enabled
INFO - 2018-07-25 05:19:12 --> Utf8 Class Initialized
INFO - 2018-07-25 05:19:12 --> URI Class Initialized
INFO - 2018-07-25 05:19:12 --> Router Class Initialized
INFO - 2018-07-25 05:19:12 --> Output Class Initialized
INFO - 2018-07-25 05:19:12 --> Security Class Initialized
DEBUG - 2018-07-25 05:19:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 05:19:12 --> Input Class Initialized
INFO - 2018-07-25 05:19:12 --> Language Class Initialized
ERROR - 2018-07-25 05:19:12 --> 404 Page Not Found: /index
INFO - 2018-07-25 05:19:17 --> Config Class Initialized
INFO - 2018-07-25 05:19:17 --> Hooks Class Initialized
DEBUG - 2018-07-25 05:19:17 --> UTF-8 Support Enabled
INFO - 2018-07-25 05:19:17 --> Utf8 Class Initialized
INFO - 2018-07-25 05:19:17 --> URI Class Initialized
INFO - 2018-07-25 05:19:17 --> Router Class Initialized
INFO - 2018-07-25 05:19:17 --> Output Class Initialized
INFO - 2018-07-25 05:19:17 --> Security Class Initialized
DEBUG - 2018-07-25 05:19:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 05:19:17 --> Input Class Initialized
INFO - 2018-07-25 05:19:17 --> Language Class Initialized
INFO - 2018-07-25 05:19:17 --> Language Class Initialized
INFO - 2018-07-25 05:19:17 --> Config Class Initialized
INFO - 2018-07-25 05:19:17 --> Loader Class Initialized
DEBUG - 2018-07-25 05:19:17 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-25 05:19:17 --> Helper loaded: url_helper
INFO - 2018-07-25 05:19:17 --> Helper loaded: form_helper
INFO - 2018-07-25 05:19:17 --> Helper loaded: date_helper
INFO - 2018-07-25 05:19:17 --> Helper loaded: util_helper
INFO - 2018-07-25 05:19:17 --> Helper loaded: text_helper
INFO - 2018-07-25 05:19:17 --> Helper loaded: string_helper
INFO - 2018-07-25 05:19:17 --> Database Driver Class Initialized
DEBUG - 2018-07-25 05:19:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 05:19:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 05:19:17 --> Email Class Initialized
INFO - 2018-07-25 05:19:17 --> Controller Class Initialized
DEBUG - 2018-07-25 05:19:17 --> Login MX_Controller Initialized
INFO - 2018-07-25 05:19:17 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-25 05:19:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-25 05:19:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-25 05:19:17 --> Email starts for gopaltesting@yopmail.com fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-07-25 05:19:17 --> Login status gopaltesting@yopmail.com - failure
INFO - 2018-07-25 05:19:17 --> Final output sent to browser
DEBUG - 2018-07-25 05:19:17 --> Total execution time: 0.4880
INFO - 2018-07-25 05:19:21 --> Config Class Initialized
INFO - 2018-07-25 05:19:21 --> Hooks Class Initialized
DEBUG - 2018-07-25 05:19:21 --> UTF-8 Support Enabled
INFO - 2018-07-25 05:19:21 --> Utf8 Class Initialized
INFO - 2018-07-25 05:19:21 --> URI Class Initialized
INFO - 2018-07-25 05:19:21 --> Router Class Initialized
INFO - 2018-07-25 05:19:21 --> Output Class Initialized
INFO - 2018-07-25 05:19:21 --> Security Class Initialized
DEBUG - 2018-07-25 05:19:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 05:19:21 --> Input Class Initialized
INFO - 2018-07-25 05:19:21 --> Language Class Initialized
INFO - 2018-07-25 05:19:21 --> Language Class Initialized
INFO - 2018-07-25 05:19:21 --> Config Class Initialized
INFO - 2018-07-25 05:19:21 --> Loader Class Initialized
DEBUG - 2018-07-25 05:19:21 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-25 05:19:21 --> Helper loaded: url_helper
INFO - 2018-07-25 05:19:21 --> Helper loaded: form_helper
INFO - 2018-07-25 05:19:21 --> Helper loaded: date_helper
INFO - 2018-07-25 05:19:21 --> Helper loaded: util_helper
INFO - 2018-07-25 05:19:21 --> Helper loaded: text_helper
INFO - 2018-07-25 05:19:21 --> Helper loaded: string_helper
INFO - 2018-07-25 05:19:21 --> Database Driver Class Initialized
DEBUG - 2018-07-25 05:19:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 05:19:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 05:19:21 --> Email Class Initialized
INFO - 2018-07-25 05:19:21 --> Controller Class Initialized
DEBUG - 2018-07-25 05:19:21 --> Login MX_Controller Initialized
INFO - 2018-07-25 05:19:21 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-25 05:19:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-25 05:19:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-25 05:19:21 --> Email starts for gopaltesting@yopmail.com fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-07-25 05:19:21 --> Login status gopaltesting@yopmail.com - failure
INFO - 2018-07-25 05:19:21 --> Final output sent to browser
DEBUG - 2018-07-25 05:19:21 --> Total execution time: 0.4904
INFO - 2018-07-25 05:20:29 --> Config Class Initialized
INFO - 2018-07-25 05:20:29 --> Hooks Class Initialized
DEBUG - 2018-07-25 05:20:29 --> UTF-8 Support Enabled
INFO - 2018-07-25 05:20:29 --> Utf8 Class Initialized
INFO - 2018-07-25 05:20:29 --> URI Class Initialized
INFO - 2018-07-25 05:20:29 --> Router Class Initialized
INFO - 2018-07-25 05:20:29 --> Output Class Initialized
INFO - 2018-07-25 05:20:29 --> Security Class Initialized
DEBUG - 2018-07-25 05:20:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 05:20:29 --> Input Class Initialized
INFO - 2018-07-25 05:20:29 --> Language Class Initialized
INFO - 2018-07-25 05:20:29 --> Language Class Initialized
INFO - 2018-07-25 05:20:29 --> Config Class Initialized
INFO - 2018-07-25 05:20:29 --> Loader Class Initialized
DEBUG - 2018-07-25 05:20:29 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-25 05:20:29 --> Helper loaded: url_helper
INFO - 2018-07-25 05:20:29 --> Helper loaded: form_helper
INFO - 2018-07-25 05:20:29 --> Helper loaded: date_helper
INFO - 2018-07-25 05:20:29 --> Helper loaded: util_helper
INFO - 2018-07-25 05:20:29 --> Helper loaded: text_helper
INFO - 2018-07-25 05:20:29 --> Helper loaded: string_helper
INFO - 2018-07-25 05:20:29 --> Database Driver Class Initialized
DEBUG - 2018-07-25 05:20:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 05:20:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 05:20:29 --> Email Class Initialized
INFO - 2018-07-25 05:20:29 --> Controller Class Initialized
DEBUG - 2018-07-25 05:20:29 --> Login MX_Controller Initialized
INFO - 2018-07-25 05:20:29 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-25 05:20:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-25 05:20:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-25 05:20:29 --> Email starts for gopaltesting@yopmail.com fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-07-25 05:20:29 --> Login status gopaltesting@yopmail.com - failure
INFO - 2018-07-25 05:20:29 --> Final output sent to browser
DEBUG - 2018-07-25 05:20:29 --> Total execution time: 0.5069
INFO - 2018-07-25 05:20:39 --> Config Class Initialized
INFO - 2018-07-25 05:20:39 --> Hooks Class Initialized
DEBUG - 2018-07-25 05:20:39 --> UTF-8 Support Enabled
INFO - 2018-07-25 05:20:39 --> Utf8 Class Initialized
INFO - 2018-07-25 05:20:39 --> URI Class Initialized
INFO - 2018-07-25 05:20:39 --> Router Class Initialized
INFO - 2018-07-25 05:20:39 --> Output Class Initialized
INFO - 2018-07-25 05:20:39 --> Security Class Initialized
DEBUG - 2018-07-25 05:20:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 05:20:39 --> Input Class Initialized
INFO - 2018-07-25 05:20:39 --> Language Class Initialized
INFO - 2018-07-25 05:20:39 --> Language Class Initialized
INFO - 2018-07-25 05:20:39 --> Config Class Initialized
INFO - 2018-07-25 05:20:39 --> Loader Class Initialized
DEBUG - 2018-07-25 05:20:39 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-25 05:20:39 --> Helper loaded: url_helper
INFO - 2018-07-25 05:20:39 --> Helper loaded: form_helper
INFO - 2018-07-25 05:20:39 --> Helper loaded: date_helper
INFO - 2018-07-25 05:20:39 --> Helper loaded: util_helper
INFO - 2018-07-25 05:20:39 --> Helper loaded: text_helper
INFO - 2018-07-25 05:20:39 --> Helper loaded: string_helper
INFO - 2018-07-25 05:20:39 --> Database Driver Class Initialized
DEBUG - 2018-07-25 05:20:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 05:20:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 05:20:39 --> Email Class Initialized
INFO - 2018-07-25 05:20:40 --> Controller Class Initialized
DEBUG - 2018-07-25 05:20:40 --> Login MX_Controller Initialized
INFO - 2018-07-25 05:20:40 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-25 05:20:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-25 05:20:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-25 05:20:40 --> Email starts for gopaltesting@yopmail.com fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-07-25 05:20:40 --> Login status gopaltesting@yopmail.com - failure
INFO - 2018-07-25 05:20:40 --> Final output sent to browser
DEBUG - 2018-07-25 05:20:40 --> Total execution time: 0.5763
INFO - 2018-07-25 05:21:09 --> Config Class Initialized
INFO - 2018-07-25 05:21:09 --> Hooks Class Initialized
DEBUG - 2018-07-25 05:21:09 --> UTF-8 Support Enabled
INFO - 2018-07-25 05:21:09 --> Utf8 Class Initialized
INFO - 2018-07-25 05:21:09 --> URI Class Initialized
INFO - 2018-07-25 05:21:09 --> Router Class Initialized
INFO - 2018-07-25 05:21:09 --> Output Class Initialized
INFO - 2018-07-25 05:21:09 --> Security Class Initialized
DEBUG - 2018-07-25 05:21:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 05:21:09 --> Input Class Initialized
INFO - 2018-07-25 05:21:09 --> Language Class Initialized
INFO - 2018-07-25 05:21:09 --> Language Class Initialized
INFO - 2018-07-25 05:21:09 --> Config Class Initialized
INFO - 2018-07-25 05:21:09 --> Loader Class Initialized
DEBUG - 2018-07-25 05:21:09 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-25 05:21:09 --> Helper loaded: url_helper
INFO - 2018-07-25 05:21:09 --> Helper loaded: form_helper
INFO - 2018-07-25 05:21:09 --> Helper loaded: date_helper
INFO - 2018-07-25 05:21:09 --> Helper loaded: util_helper
INFO - 2018-07-25 05:21:09 --> Helper loaded: text_helper
INFO - 2018-07-25 05:21:09 --> Helper loaded: string_helper
INFO - 2018-07-25 05:21:09 --> Database Driver Class Initialized
DEBUG - 2018-07-25 05:21:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 05:21:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 05:21:09 --> Email Class Initialized
INFO - 2018-07-25 05:21:09 --> Controller Class Initialized
DEBUG - 2018-07-25 05:21:09 --> Login MX_Controller Initialized
INFO - 2018-07-25 05:21:09 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-25 05:21:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-25 05:21:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-25 05:21:09 --> Email starts for gopaltesting@yopmail.com fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-07-25 05:25:18 --> Config Class Initialized
INFO - 2018-07-25 05:25:18 --> Hooks Class Initialized
DEBUG - 2018-07-25 05:25:18 --> UTF-8 Support Enabled
INFO - 2018-07-25 05:25:18 --> Utf8 Class Initialized
INFO - 2018-07-25 05:25:18 --> URI Class Initialized
INFO - 2018-07-25 05:25:18 --> Router Class Initialized
INFO - 2018-07-25 05:25:18 --> Output Class Initialized
INFO - 2018-07-25 05:25:18 --> Security Class Initialized
DEBUG - 2018-07-25 05:25:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 05:25:18 --> Input Class Initialized
INFO - 2018-07-25 05:25:18 --> Language Class Initialized
INFO - 2018-07-25 05:25:18 --> Language Class Initialized
INFO - 2018-07-25 05:25:18 --> Config Class Initialized
INFO - 2018-07-25 05:25:18 --> Loader Class Initialized
DEBUG - 2018-07-25 05:25:18 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-25 05:25:18 --> Helper loaded: url_helper
INFO - 2018-07-25 05:25:18 --> Helper loaded: form_helper
INFO - 2018-07-25 05:25:18 --> Helper loaded: date_helper
INFO - 2018-07-25 05:25:18 --> Helper loaded: util_helper
INFO - 2018-07-25 05:25:18 --> Helper loaded: text_helper
INFO - 2018-07-25 05:25:18 --> Helper loaded: string_helper
INFO - 2018-07-25 05:25:18 --> Database Driver Class Initialized
DEBUG - 2018-07-25 05:25:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 05:25:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 05:25:18 --> Email Class Initialized
INFO - 2018-07-25 05:25:18 --> Controller Class Initialized
DEBUG - 2018-07-25 05:25:18 --> Users MX_Controller Initialized
DEBUG - 2018-07-25 05:25:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-25 05:25:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-07-25 05:25:19 --> Helper loaded: file_helper
DEBUG - 2018-07-25 05:25:19 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-25 05:25:19 --> Login MX_Controller Initialized
INFO - 2018-07-25 05:25:19 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-25 05:25:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-25 05:25:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-25 05:25:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
INFO - 2018-07-25 05:25:42 --> Config Class Initialized
INFO - 2018-07-25 05:25:42 --> Hooks Class Initialized
DEBUG - 2018-07-25 05:25:42 --> UTF-8 Support Enabled
INFO - 2018-07-25 05:25:42 --> Utf8 Class Initialized
INFO - 2018-07-25 05:25:42 --> URI Class Initialized
INFO - 2018-07-25 05:25:42 --> Router Class Initialized
INFO - 2018-07-25 05:25:42 --> Output Class Initialized
INFO - 2018-07-25 05:25:42 --> Security Class Initialized
DEBUG - 2018-07-25 05:25:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 05:25:42 --> Input Class Initialized
INFO - 2018-07-25 05:25:42 --> Language Class Initialized
INFO - 2018-07-25 05:25:42 --> Language Class Initialized
INFO - 2018-07-25 05:25:42 --> Config Class Initialized
INFO - 2018-07-25 05:25:42 --> Loader Class Initialized
DEBUG - 2018-07-25 05:25:42 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-25 05:25:42 --> Helper loaded: url_helper
INFO - 2018-07-25 05:25:42 --> Helper loaded: form_helper
INFO - 2018-07-25 05:25:42 --> Helper loaded: date_helper
INFO - 2018-07-25 05:25:42 --> Helper loaded: util_helper
INFO - 2018-07-25 05:25:42 --> Helper loaded: text_helper
INFO - 2018-07-25 05:25:42 --> Helper loaded: string_helper
INFO - 2018-07-25 05:25:42 --> Database Driver Class Initialized
DEBUG - 2018-07-25 05:25:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 05:25:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 05:25:42 --> Email Class Initialized
INFO - 2018-07-25 05:25:42 --> Controller Class Initialized
DEBUG - 2018-07-25 05:25:42 --> Users MX_Controller Initialized
DEBUG - 2018-07-25 05:25:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-25 05:25:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-07-25 05:25:42 --> Helper loaded: file_helper
DEBUG - 2018-07-25 05:25:42 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-25 05:25:42 --> Login MX_Controller Initialized
INFO - 2018-07-25 05:25:42 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-25 05:25:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-25 05:25:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-25 05:25:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
INFO - 2018-07-25 05:25:59 --> Config Class Initialized
INFO - 2018-07-25 05:25:59 --> Hooks Class Initialized
DEBUG - 2018-07-25 05:25:59 --> UTF-8 Support Enabled
INFO - 2018-07-25 05:25:59 --> Utf8 Class Initialized
INFO - 2018-07-25 05:25:59 --> URI Class Initialized
INFO - 2018-07-25 05:25:59 --> Router Class Initialized
INFO - 2018-07-25 05:25:59 --> Output Class Initialized
INFO - 2018-07-25 05:25:59 --> Security Class Initialized
DEBUG - 2018-07-25 05:25:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 05:25:59 --> Input Class Initialized
INFO - 2018-07-25 05:25:59 --> Language Class Initialized
INFO - 2018-07-25 05:25:59 --> Language Class Initialized
INFO - 2018-07-25 05:25:59 --> Config Class Initialized
INFO - 2018-07-25 05:25:59 --> Loader Class Initialized
DEBUG - 2018-07-25 05:25:59 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-25 05:25:59 --> Helper loaded: url_helper
INFO - 2018-07-25 05:25:59 --> Helper loaded: form_helper
INFO - 2018-07-25 05:25:59 --> Helper loaded: date_helper
INFO - 2018-07-25 05:25:59 --> Helper loaded: util_helper
INFO - 2018-07-25 05:25:59 --> Helper loaded: text_helper
INFO - 2018-07-25 05:26:00 --> Helper loaded: string_helper
INFO - 2018-07-25 05:26:00 --> Database Driver Class Initialized
DEBUG - 2018-07-25 05:26:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 05:26:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 05:26:00 --> Email Class Initialized
INFO - 2018-07-25 05:26:00 --> Controller Class Initialized
DEBUG - 2018-07-25 05:26:00 --> Users MX_Controller Initialized
DEBUG - 2018-07-25 05:26:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-25 05:26:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-07-25 05:26:00 --> Helper loaded: file_helper
DEBUG - 2018-07-25 05:26:00 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-25 05:26:00 --> Login MX_Controller Initialized
INFO - 2018-07-25 05:26:00 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-25 05:26:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-25 05:26:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-07-25 05:26:32 --> Config Class Initialized
INFO - 2018-07-25 05:26:32 --> Hooks Class Initialized
DEBUG - 2018-07-25 05:26:32 --> UTF-8 Support Enabled
INFO - 2018-07-25 05:26:32 --> Utf8 Class Initialized
INFO - 2018-07-25 05:26:32 --> URI Class Initialized
INFO - 2018-07-25 05:26:32 --> Router Class Initialized
INFO - 2018-07-25 05:26:32 --> Output Class Initialized
INFO - 2018-07-25 05:26:32 --> Security Class Initialized
DEBUG - 2018-07-25 05:26:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 05:26:32 --> Input Class Initialized
INFO - 2018-07-25 05:26:32 --> Language Class Initialized
INFO - 2018-07-25 05:26:32 --> Language Class Initialized
INFO - 2018-07-25 05:26:32 --> Config Class Initialized
INFO - 2018-07-25 05:26:32 --> Loader Class Initialized
DEBUG - 2018-07-25 05:26:32 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-25 05:26:32 --> Helper loaded: url_helper
INFO - 2018-07-25 05:26:32 --> Helper loaded: form_helper
INFO - 2018-07-25 05:26:32 --> Helper loaded: date_helper
INFO - 2018-07-25 05:26:32 --> Helper loaded: util_helper
INFO - 2018-07-25 05:26:32 --> Helper loaded: text_helper
INFO - 2018-07-25 05:26:32 --> Helper loaded: string_helper
INFO - 2018-07-25 05:26:32 --> Database Driver Class Initialized
DEBUG - 2018-07-25 05:26:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 05:26:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 05:26:32 --> Email Class Initialized
INFO - 2018-07-25 05:26:32 --> Controller Class Initialized
DEBUG - 2018-07-25 05:26:32 --> Users MX_Controller Initialized
DEBUG - 2018-07-25 05:26:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-25 05:26:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-07-25 05:26:32 --> Helper loaded: file_helper
DEBUG - 2018-07-25 05:26:32 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-25 05:26:32 --> Login MX_Controller Initialized
INFO - 2018-07-25 05:26:32 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-25 05:26:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-25 05:26:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-25 05:26:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
INFO - 2018-07-25 05:26:32 --> Config Class Initialized
INFO - 2018-07-25 05:26:32 --> Hooks Class Initialized
DEBUG - 2018-07-25 05:26:32 --> UTF-8 Support Enabled
INFO - 2018-07-25 05:26:32 --> Utf8 Class Initialized
INFO - 2018-07-25 05:26:32 --> URI Class Initialized
INFO - 2018-07-25 05:26:33 --> Router Class Initialized
INFO - 2018-07-25 05:26:33 --> Output Class Initialized
INFO - 2018-07-25 05:26:33 --> Security Class Initialized
DEBUG - 2018-07-25 05:26:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 05:26:33 --> Input Class Initialized
INFO - 2018-07-25 05:26:33 --> Language Class Initialized
INFO - 2018-07-25 05:26:33 --> Language Class Initialized
INFO - 2018-07-25 05:26:33 --> Config Class Initialized
INFO - 2018-07-25 05:26:33 --> Loader Class Initialized
DEBUG - 2018-07-25 05:26:33 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-25 05:26:33 --> Helper loaded: url_helper
INFO - 2018-07-25 05:26:33 --> Helper loaded: form_helper
INFO - 2018-07-25 05:26:33 --> Helper loaded: date_helper
INFO - 2018-07-25 05:26:33 --> Helper loaded: util_helper
INFO - 2018-07-25 05:26:33 --> Helper loaded: text_helper
INFO - 2018-07-25 05:26:33 --> Helper loaded: string_helper
INFO - 2018-07-25 05:26:33 --> Database Driver Class Initialized
DEBUG - 2018-07-25 05:26:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 05:26:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 05:26:33 --> Email Class Initialized
INFO - 2018-07-25 05:26:33 --> Controller Class Initialized
DEBUG - 2018-07-25 05:26:33 --> Users MX_Controller Initialized
DEBUG - 2018-07-25 05:26:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-25 05:26:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-07-25 05:26:33 --> Helper loaded: file_helper
DEBUG - 2018-07-25 05:26:33 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-25 05:26:33 --> Login MX_Controller Initialized
INFO - 2018-07-25 05:26:33 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-25 05:26:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-25 05:26:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-25 05:26:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-25 05:26:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-25 05:26:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-25 05:26:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-25 05:26:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/users.php
INFO - 2018-07-25 05:26:33 --> Final output sent to browser
DEBUG - 2018-07-25 05:26:33 --> Total execution time: 0.6670
INFO - 2018-07-25 05:26:34 --> Config Class Initialized
INFO - 2018-07-25 05:26:34 --> Hooks Class Initialized
DEBUG - 2018-07-25 05:26:34 --> UTF-8 Support Enabled
INFO - 2018-07-25 05:26:34 --> Utf8 Class Initialized
INFO - 2018-07-25 05:26:34 --> URI Class Initialized
INFO - 2018-07-25 05:26:34 --> Router Class Initialized
INFO - 2018-07-25 05:26:34 --> Output Class Initialized
INFO - 2018-07-25 05:26:34 --> Security Class Initialized
DEBUG - 2018-07-25 05:26:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 05:26:34 --> Input Class Initialized
INFO - 2018-07-25 05:26:34 --> Language Class Initialized
INFO - 2018-07-25 05:26:34 --> Language Class Initialized
INFO - 2018-07-25 05:26:34 --> Config Class Initialized
INFO - 2018-07-25 05:26:34 --> Loader Class Initialized
DEBUG - 2018-07-25 05:26:34 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-25 05:26:34 --> Helper loaded: url_helper
INFO - 2018-07-25 05:26:34 --> Helper loaded: form_helper
INFO - 2018-07-25 05:26:34 --> Helper loaded: date_helper
INFO - 2018-07-25 05:26:34 --> Helper loaded: util_helper
INFO - 2018-07-25 05:26:34 --> Helper loaded: text_helper
INFO - 2018-07-25 05:26:34 --> Helper loaded: string_helper
INFO - 2018-07-25 05:26:34 --> Database Driver Class Initialized
DEBUG - 2018-07-25 05:26:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 05:26:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 05:26:34 --> Email Class Initialized
INFO - 2018-07-25 05:26:34 --> Controller Class Initialized
DEBUG - 2018-07-25 05:26:34 --> Users MX_Controller Initialized
DEBUG - 2018-07-25 05:26:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-25 05:26:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-07-25 05:26:34 --> Helper loaded: file_helper
DEBUG - 2018-07-25 05:26:34 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-25 05:26:34 --> Login MX_Controller Initialized
INFO - 2018-07-25 05:26:34 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-25 05:26:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-25 05:26:34 --> Final output sent to browser
DEBUG - 2018-07-25 05:26:34 --> Total execution time: 0.7491
INFO - 2018-07-25 05:26:39 --> Config Class Initialized
INFO - 2018-07-25 05:26:39 --> Hooks Class Initialized
DEBUG - 2018-07-25 05:26:39 --> UTF-8 Support Enabled
INFO - 2018-07-25 05:26:39 --> Utf8 Class Initialized
INFO - 2018-07-25 05:26:39 --> URI Class Initialized
INFO - 2018-07-25 05:26:39 --> Router Class Initialized
INFO - 2018-07-25 05:26:39 --> Output Class Initialized
INFO - 2018-07-25 05:26:39 --> Security Class Initialized
DEBUG - 2018-07-25 05:26:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 05:26:39 --> Input Class Initialized
INFO - 2018-07-25 05:26:39 --> Language Class Initialized
INFO - 2018-07-25 05:26:39 --> Language Class Initialized
INFO - 2018-07-25 05:26:39 --> Config Class Initialized
INFO - 2018-07-25 05:26:40 --> Loader Class Initialized
DEBUG - 2018-07-25 05:26:40 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-25 05:26:40 --> Helper loaded: url_helper
INFO - 2018-07-25 05:26:40 --> Helper loaded: form_helper
INFO - 2018-07-25 05:26:40 --> Helper loaded: date_helper
INFO - 2018-07-25 05:26:40 --> Helper loaded: util_helper
INFO - 2018-07-25 05:26:40 --> Helper loaded: text_helper
INFO - 2018-07-25 05:26:40 --> Helper loaded: string_helper
INFO - 2018-07-25 05:26:40 --> Database Driver Class Initialized
DEBUG - 2018-07-25 05:26:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 05:26:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 05:26:40 --> Email Class Initialized
INFO - 2018-07-25 05:26:40 --> Controller Class Initialized
DEBUG - 2018-07-25 05:26:40 --> Login MX_Controller Initialized
INFO - 2018-07-25 05:26:40 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-25 05:26:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-25 05:26:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-25 05:26:40 --> Email starts for gopaltesting@yopmail.com fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-07-25 05:27:01 --> Config Class Initialized
INFO - 2018-07-25 05:27:01 --> Hooks Class Initialized
DEBUG - 2018-07-25 05:27:01 --> UTF-8 Support Enabled
INFO - 2018-07-25 05:27:01 --> Utf8 Class Initialized
INFO - 2018-07-25 05:27:01 --> URI Class Initialized
INFO - 2018-07-25 05:27:01 --> Router Class Initialized
INFO - 2018-07-25 05:27:01 --> Output Class Initialized
INFO - 2018-07-25 05:27:01 --> Security Class Initialized
DEBUG - 2018-07-25 05:27:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 05:27:01 --> Input Class Initialized
INFO - 2018-07-25 05:27:01 --> Language Class Initialized
INFO - 2018-07-25 05:27:01 --> Language Class Initialized
INFO - 2018-07-25 05:27:01 --> Config Class Initialized
INFO - 2018-07-25 05:27:01 --> Loader Class Initialized
DEBUG - 2018-07-25 05:27:01 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-25 05:27:01 --> Helper loaded: url_helper
INFO - 2018-07-25 05:27:01 --> Helper loaded: form_helper
INFO - 2018-07-25 05:27:01 --> Helper loaded: date_helper
INFO - 2018-07-25 05:27:01 --> Helper loaded: util_helper
INFO - 2018-07-25 05:27:01 --> Helper loaded: text_helper
INFO - 2018-07-25 05:27:01 --> Helper loaded: string_helper
INFO - 2018-07-25 05:27:01 --> Database Driver Class Initialized
DEBUG - 2018-07-25 05:27:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 05:27:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 05:27:01 --> Email Class Initialized
INFO - 2018-07-25 05:27:01 --> Controller Class Initialized
DEBUG - 2018-07-25 05:27:01 --> Login MX_Controller Initialized
INFO - 2018-07-25 05:27:01 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-25 05:27:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-25 05:27:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-25 05:27:01 --> Email starts for gopaltesting@yopmail.com fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-07-25 05:27:01 --> User session created for 38
INFO - 2018-07-25 05:27:01 --> Login status gopaltesting@yopmail.com - success
INFO - 2018-07-25 05:27:01 --> Final output sent to browser
DEBUG - 2018-07-25 05:27:01 --> Total execution time: 0.5676
INFO - 2018-07-25 05:27:01 --> Config Class Initialized
INFO - 2018-07-25 05:27:01 --> Hooks Class Initialized
DEBUG - 2018-07-25 05:27:01 --> UTF-8 Support Enabled
INFO - 2018-07-25 05:27:01 --> Utf8 Class Initialized
INFO - 2018-07-25 05:27:01 --> URI Class Initialized
INFO - 2018-07-25 05:27:01 --> Router Class Initialized
INFO - 2018-07-25 05:27:01 --> Output Class Initialized
INFO - 2018-07-25 05:27:01 --> Security Class Initialized
DEBUG - 2018-07-25 05:27:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 05:27:01 --> Input Class Initialized
INFO - 2018-07-25 05:27:01 --> Language Class Initialized
INFO - 2018-07-25 05:27:01 --> Language Class Initialized
INFO - 2018-07-25 05:27:01 --> Config Class Initialized
INFO - 2018-07-25 05:27:01 --> Loader Class Initialized
DEBUG - 2018-07-25 05:27:01 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-25 05:27:02 --> Helper loaded: url_helper
INFO - 2018-07-25 05:27:02 --> Helper loaded: form_helper
INFO - 2018-07-25 05:27:02 --> Helper loaded: date_helper
INFO - 2018-07-25 05:27:02 --> Helper loaded: util_helper
INFO - 2018-07-25 05:27:02 --> Helper loaded: text_helper
INFO - 2018-07-25 05:27:02 --> Helper loaded: string_helper
INFO - 2018-07-25 05:27:02 --> Database Driver Class Initialized
DEBUG - 2018-07-25 05:27:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 05:27:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 05:27:02 --> Email Class Initialized
INFO - 2018-07-25 05:27:02 --> Controller Class Initialized
DEBUG - 2018-07-25 05:27:02 --> Admin MX_Controller Initialized
INFO - 2018-07-25 05:27:02 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-25 05:27:02 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-25 05:27:02 --> Login MX_Controller Initialized
DEBUG - 2018-07-25 05:27:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-25 05:27:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-25 05:27:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-25 05:27:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-25 05:27:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-25 05:27:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-25 05:27:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-25 05:27:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/dashboard.php
INFO - 2018-07-25 05:27:02 --> Final output sent to browser
DEBUG - 2018-07-25 05:27:02 --> Total execution time: 0.6474
INFO - 2018-07-25 05:27:02 --> Config Class Initialized
INFO - 2018-07-25 05:27:02 --> Hooks Class Initialized
DEBUG - 2018-07-25 05:27:02 --> UTF-8 Support Enabled
INFO - 2018-07-25 05:27:02 --> Config Class Initialized
INFO - 2018-07-25 05:27:02 --> Hooks Class Initialized
INFO - 2018-07-25 05:27:02 --> Utf8 Class Initialized
DEBUG - 2018-07-25 05:27:02 --> UTF-8 Support Enabled
INFO - 2018-07-25 05:27:02 --> Utf8 Class Initialized
INFO - 2018-07-25 05:27:02 --> URI Class Initialized
INFO - 2018-07-25 05:27:02 --> URI Class Initialized
INFO - 2018-07-25 05:27:02 --> Router Class Initialized
INFO - 2018-07-25 05:27:02 --> Router Class Initialized
INFO - 2018-07-25 05:27:02 --> Output Class Initialized
INFO - 2018-07-25 05:27:02 --> Output Class Initialized
INFO - 2018-07-25 05:27:02 --> Security Class Initialized
DEBUG - 2018-07-25 05:27:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 05:27:03 --> Input Class Initialized
INFO - 2018-07-25 05:27:03 --> Language Class Initialized
ERROR - 2018-07-25 05:27:03 --> 404 Page Not Found: /index
INFO - 2018-07-25 05:27:03 --> Security Class Initialized
DEBUG - 2018-07-25 05:27:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 05:27:03 --> Input Class Initialized
INFO - 2018-07-25 05:27:03 --> Language Class Initialized
ERROR - 2018-07-25 05:27:03 --> 404 Page Not Found: /index
INFO - 2018-07-25 05:27:03 --> Config Class Initialized
INFO - 2018-07-25 05:27:03 --> Hooks Class Initialized
DEBUG - 2018-07-25 05:27:03 --> UTF-8 Support Enabled
INFO - 2018-07-25 05:27:03 --> Utf8 Class Initialized
INFO - 2018-07-25 05:27:03 --> URI Class Initialized
INFO - 2018-07-25 05:27:03 --> Router Class Initialized
INFO - 2018-07-25 05:27:03 --> Output Class Initialized
INFO - 2018-07-25 05:27:03 --> Security Class Initialized
DEBUG - 2018-07-25 05:27:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 05:27:03 --> Input Class Initialized
INFO - 2018-07-25 05:27:03 --> Language Class Initialized
ERROR - 2018-07-25 05:27:03 --> 404 Page Not Found: /index
INFO - 2018-07-25 05:33:41 --> Config Class Initialized
INFO - 2018-07-25 05:33:41 --> Hooks Class Initialized
DEBUG - 2018-07-25 05:33:41 --> UTF-8 Support Enabled
INFO - 2018-07-25 05:33:41 --> Utf8 Class Initialized
INFO - 2018-07-25 05:33:41 --> URI Class Initialized
INFO - 2018-07-25 05:33:41 --> Router Class Initialized
INFO - 2018-07-25 05:33:41 --> Output Class Initialized
INFO - 2018-07-25 05:33:41 --> Security Class Initialized
DEBUG - 2018-07-25 05:33:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 05:33:42 --> Input Class Initialized
INFO - 2018-07-25 05:33:42 --> Language Class Initialized
INFO - 2018-07-25 05:33:42 --> Language Class Initialized
INFO - 2018-07-25 05:33:42 --> Config Class Initialized
INFO - 2018-07-25 05:33:42 --> Loader Class Initialized
DEBUG - 2018-07-25 05:33:42 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-25 05:33:42 --> Helper loaded: url_helper
INFO - 2018-07-25 05:33:42 --> Helper loaded: form_helper
INFO - 2018-07-25 05:33:42 --> Helper loaded: date_helper
INFO - 2018-07-25 05:33:42 --> Helper loaded: util_helper
INFO - 2018-07-25 05:33:42 --> Helper loaded: text_helper
INFO - 2018-07-25 05:33:42 --> Helper loaded: string_helper
INFO - 2018-07-25 05:33:42 --> Database Driver Class Initialized
DEBUG - 2018-07-25 05:33:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 05:33:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 05:33:42 --> Email Class Initialized
INFO - 2018-07-25 05:33:42 --> Controller Class Initialized
DEBUG - 2018-07-25 05:33:42 --> Admin MX_Controller Initialized
INFO - 2018-07-25 05:33:42 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-25 05:33:42 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-25 05:33:42 --> Login MX_Controller Initialized
DEBUG - 2018-07-25 05:33:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-25 05:33:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-25 05:33:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-25 05:33:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-25 05:33:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-25 05:33:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-25 05:33:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-25 05:33:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/dashboard.php
INFO - 2018-07-25 05:33:42 --> Final output sent to browser
DEBUG - 2018-07-25 05:33:42 --> Total execution time: 0.6376
INFO - 2018-07-25 05:33:42 --> Config Class Initialized
INFO - 2018-07-25 05:33:42 --> Config Class Initialized
INFO - 2018-07-25 05:33:42 --> Hooks Class Initialized
INFO - 2018-07-25 05:33:42 --> Hooks Class Initialized
DEBUG - 2018-07-25 05:33:42 --> UTF-8 Support Enabled
DEBUG - 2018-07-25 05:33:42 --> UTF-8 Support Enabled
INFO - 2018-07-25 05:33:42 --> Utf8 Class Initialized
INFO - 2018-07-25 05:33:42 --> Utf8 Class Initialized
INFO - 2018-07-25 05:33:42 --> URI Class Initialized
INFO - 2018-07-25 05:33:42 --> URI Class Initialized
INFO - 2018-07-25 05:33:42 --> Router Class Initialized
INFO - 2018-07-25 05:33:42 --> Router Class Initialized
INFO - 2018-07-25 05:33:42 --> Output Class Initialized
INFO - 2018-07-25 05:33:42 --> Output Class Initialized
INFO - 2018-07-25 05:33:42 --> Security Class Initialized
INFO - 2018-07-25 05:33:42 --> Security Class Initialized
DEBUG - 2018-07-25 05:33:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-07-25 05:33:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 05:33:42 --> Input Class Initialized
INFO - 2018-07-25 05:33:42 --> Input Class Initialized
INFO - 2018-07-25 05:33:42 --> Language Class Initialized
INFO - 2018-07-25 05:33:42 --> Language Class Initialized
ERROR - 2018-07-25 05:33:42 --> 404 Page Not Found: /index
ERROR - 2018-07-25 05:33:42 --> 404 Page Not Found: /index
INFO - 2018-07-25 05:33:43 --> Config Class Initialized
INFO - 2018-07-25 05:33:43 --> Hooks Class Initialized
DEBUG - 2018-07-25 05:33:43 --> UTF-8 Support Enabled
INFO - 2018-07-25 05:33:43 --> Utf8 Class Initialized
INFO - 2018-07-25 05:33:43 --> URI Class Initialized
INFO - 2018-07-25 05:33:43 --> Router Class Initialized
INFO - 2018-07-25 05:33:43 --> Output Class Initialized
INFO - 2018-07-25 05:33:43 --> Security Class Initialized
DEBUG - 2018-07-25 05:33:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 05:33:43 --> Input Class Initialized
INFO - 2018-07-25 05:33:43 --> Language Class Initialized
ERROR - 2018-07-25 05:33:43 --> 404 Page Not Found: /index
INFO - 2018-07-25 05:33:50 --> Config Class Initialized
INFO - 2018-07-25 05:33:50 --> Hooks Class Initialized
DEBUG - 2018-07-25 05:33:50 --> UTF-8 Support Enabled
INFO - 2018-07-25 05:33:50 --> Utf8 Class Initialized
INFO - 2018-07-25 05:33:50 --> URI Class Initialized
INFO - 2018-07-25 05:33:50 --> Router Class Initialized
INFO - 2018-07-25 05:33:50 --> Output Class Initialized
INFO - 2018-07-25 05:33:50 --> Security Class Initialized
DEBUG - 2018-07-25 05:33:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 05:33:50 --> Input Class Initialized
INFO - 2018-07-25 05:33:50 --> Language Class Initialized
INFO - 2018-07-25 05:33:50 --> Language Class Initialized
INFO - 2018-07-25 05:33:50 --> Config Class Initialized
INFO - 2018-07-25 05:33:50 --> Loader Class Initialized
DEBUG - 2018-07-25 05:33:50 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-25 05:33:50 --> Helper loaded: url_helper
INFO - 2018-07-25 05:33:50 --> Helper loaded: form_helper
INFO - 2018-07-25 05:33:50 --> Helper loaded: date_helper
INFO - 2018-07-25 05:33:50 --> Helper loaded: util_helper
INFO - 2018-07-25 05:33:50 --> Helper loaded: text_helper
INFO - 2018-07-25 05:33:50 --> Helper loaded: string_helper
INFO - 2018-07-25 05:33:50 --> Database Driver Class Initialized
DEBUG - 2018-07-25 05:33:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 05:33:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 05:33:50 --> Email Class Initialized
INFO - 2018-07-25 05:33:50 --> Controller Class Initialized
DEBUG - 2018-07-25 05:33:50 --> Users MX_Controller Initialized
DEBUG - 2018-07-25 05:33:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-25 05:33:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-07-25 05:33:50 --> Helper loaded: file_helper
DEBUG - 2018-07-25 05:33:50 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-25 05:33:50 --> Login MX_Controller Initialized
INFO - 2018-07-25 05:33:50 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-25 05:33:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-25 05:33:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-25 05:33:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-25 05:33:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-25 05:33:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-25 05:33:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-25 05:33:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/users.php
INFO - 2018-07-25 05:33:50 --> Final output sent to browser
DEBUG - 2018-07-25 05:33:50 --> Total execution time: 0.7025
INFO - 2018-07-25 05:33:51 --> Config Class Initialized
INFO - 2018-07-25 05:33:51 --> Hooks Class Initialized
DEBUG - 2018-07-25 05:33:51 --> UTF-8 Support Enabled
INFO - 2018-07-25 05:33:51 --> Utf8 Class Initialized
INFO - 2018-07-25 05:33:51 --> URI Class Initialized
INFO - 2018-07-25 05:33:51 --> Router Class Initialized
INFO - 2018-07-25 05:33:51 --> Output Class Initialized
INFO - 2018-07-25 05:33:51 --> Security Class Initialized
DEBUG - 2018-07-25 05:33:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 05:33:51 --> Input Class Initialized
INFO - 2018-07-25 05:33:51 --> Language Class Initialized
INFO - 2018-07-25 05:33:51 --> Language Class Initialized
INFO - 2018-07-25 05:33:51 --> Config Class Initialized
INFO - 2018-07-25 05:33:51 --> Loader Class Initialized
DEBUG - 2018-07-25 05:33:51 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-25 05:33:51 --> Helper loaded: url_helper
INFO - 2018-07-25 05:33:51 --> Helper loaded: form_helper
INFO - 2018-07-25 05:33:51 --> Helper loaded: date_helper
INFO - 2018-07-25 05:33:51 --> Helper loaded: util_helper
INFO - 2018-07-25 05:33:51 --> Helper loaded: text_helper
INFO - 2018-07-25 05:33:51 --> Helper loaded: string_helper
INFO - 2018-07-25 05:33:51 --> Database Driver Class Initialized
DEBUG - 2018-07-25 05:33:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 05:33:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 05:33:51 --> Email Class Initialized
INFO - 2018-07-25 05:33:51 --> Controller Class Initialized
DEBUG - 2018-07-25 05:33:51 --> Users MX_Controller Initialized
DEBUG - 2018-07-25 05:33:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-25 05:33:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-07-25 05:33:51 --> Helper loaded: file_helper
DEBUG - 2018-07-25 05:33:51 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-25 05:33:51 --> Login MX_Controller Initialized
INFO - 2018-07-25 05:33:51 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-25 05:33:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-25 05:33:51 --> Final output sent to browser
DEBUG - 2018-07-25 05:33:51 --> Total execution time: 0.7119
INFO - 2018-07-25 05:34:59 --> Config Class Initialized
INFO - 2018-07-25 05:34:59 --> Hooks Class Initialized
DEBUG - 2018-07-25 05:34:59 --> UTF-8 Support Enabled
INFO - 2018-07-25 05:34:59 --> Utf8 Class Initialized
INFO - 2018-07-25 05:34:59 --> URI Class Initialized
INFO - 2018-07-25 05:34:59 --> Router Class Initialized
INFO - 2018-07-25 05:34:59 --> Output Class Initialized
INFO - 2018-07-25 05:34:59 --> Security Class Initialized
DEBUG - 2018-07-25 05:34:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 05:34:59 --> Input Class Initialized
INFO - 2018-07-25 05:34:59 --> Language Class Initialized
INFO - 2018-07-25 05:34:59 --> Language Class Initialized
INFO - 2018-07-25 05:34:59 --> Config Class Initialized
INFO - 2018-07-25 05:34:59 --> Loader Class Initialized
DEBUG - 2018-07-25 05:34:59 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-25 05:34:59 --> Helper loaded: url_helper
INFO - 2018-07-25 05:34:59 --> Helper loaded: form_helper
INFO - 2018-07-25 05:34:59 --> Helper loaded: date_helper
INFO - 2018-07-25 05:34:59 --> Helper loaded: util_helper
INFO - 2018-07-25 05:34:59 --> Helper loaded: text_helper
INFO - 2018-07-25 05:34:59 --> Helper loaded: string_helper
INFO - 2018-07-25 05:34:59 --> Database Driver Class Initialized
DEBUG - 2018-07-25 05:34:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 05:34:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 05:34:59 --> Email Class Initialized
INFO - 2018-07-25 05:34:59 --> Controller Class Initialized
DEBUG - 2018-07-25 05:34:59 --> Admin MX_Controller Initialized
INFO - 2018-07-25 05:34:59 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-25 05:34:59 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-25 05:34:59 --> Login MX_Controller Initialized
DEBUG - 2018-07-25 05:34:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-25 05:34:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-25 05:34:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-25 05:34:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-25 05:35:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-25 05:35:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-25 05:35:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-25 05:35:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/dashboard.php
INFO - 2018-07-25 05:35:00 --> Final output sent to browser
DEBUG - 2018-07-25 05:35:00 --> Total execution time: 0.6865
INFO - 2018-07-25 05:35:00 --> Config Class Initialized
INFO - 2018-07-25 05:35:00 --> Config Class Initialized
INFO - 2018-07-25 05:35:00 --> Hooks Class Initialized
DEBUG - 2018-07-25 05:35:00 --> UTF-8 Support Enabled
INFO - 2018-07-25 05:35:00 --> Utf8 Class Initialized
INFO - 2018-07-25 05:35:00 --> Hooks Class Initialized
INFO - 2018-07-25 05:35:00 --> URI Class Initialized
DEBUG - 2018-07-25 05:35:00 --> UTF-8 Support Enabled
INFO - 2018-07-25 05:35:00 --> Utf8 Class Initialized
INFO - 2018-07-25 05:35:00 --> Router Class Initialized
INFO - 2018-07-25 05:35:00 --> URI Class Initialized
INFO - 2018-07-25 05:35:00 --> Output Class Initialized
INFO - 2018-07-25 05:35:00 --> Security Class Initialized
INFO - 2018-07-25 05:35:00 --> Router Class Initialized
INFO - 2018-07-25 05:35:00 --> Output Class Initialized
DEBUG - 2018-07-25 05:35:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 05:35:00 --> Security Class Initialized
DEBUG - 2018-07-25 05:35:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 05:35:00 --> Input Class Initialized
INFO - 2018-07-25 05:35:00 --> Language Class Initialized
ERROR - 2018-07-25 05:35:00 --> 404 Page Not Found: /index
INFO - 2018-07-25 05:35:00 --> Input Class Initialized
INFO - 2018-07-25 05:35:00 --> Language Class Initialized
ERROR - 2018-07-25 05:35:00 --> 404 Page Not Found: /index
INFO - 2018-07-25 05:44:56 --> Config Class Initialized
INFO - 2018-07-25 05:44:56 --> Hooks Class Initialized
DEBUG - 2018-07-25 05:44:56 --> UTF-8 Support Enabled
INFO - 2018-07-25 05:44:56 --> Utf8 Class Initialized
INFO - 2018-07-25 05:44:56 --> URI Class Initialized
INFO - 2018-07-25 05:44:56 --> Router Class Initialized
INFO - 2018-07-25 05:44:56 --> Output Class Initialized
INFO - 2018-07-25 05:44:56 --> Security Class Initialized
DEBUG - 2018-07-25 05:44:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 05:44:56 --> Input Class Initialized
INFO - 2018-07-25 05:44:56 --> Language Class Initialized
INFO - 2018-07-25 05:44:56 --> Language Class Initialized
INFO - 2018-07-25 05:44:56 --> Config Class Initialized
INFO - 2018-07-25 05:44:56 --> Loader Class Initialized
DEBUG - 2018-07-25 05:44:56 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-25 05:44:56 --> Helper loaded: url_helper
INFO - 2018-07-25 05:44:56 --> Helper loaded: form_helper
INFO - 2018-07-25 05:44:56 --> Helper loaded: date_helper
INFO - 2018-07-25 05:44:56 --> Helper loaded: util_helper
INFO - 2018-07-25 05:44:56 --> Helper loaded: text_helper
INFO - 2018-07-25 05:44:56 --> Helper loaded: string_helper
INFO - 2018-07-25 05:44:56 --> Database Driver Class Initialized
DEBUG - 2018-07-25 05:44:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 05:44:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 05:44:56 --> Email Class Initialized
INFO - 2018-07-25 05:44:56 --> Controller Class Initialized
DEBUG - 2018-07-25 05:44:56 --> Users MX_Controller Initialized
DEBUG - 2018-07-25 05:44:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-25 05:44:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-07-25 05:44:56 --> Helper loaded: file_helper
DEBUG - 2018-07-25 05:44:56 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-25 05:44:56 --> Login MX_Controller Initialized
INFO - 2018-07-25 05:44:57 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-25 05:44:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-25 05:44:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-25 05:44:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-25 05:44:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-25 05:44:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-25 05:44:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-25 05:44:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/users.php
INFO - 2018-07-25 05:44:57 --> Final output sent to browser
DEBUG - 2018-07-25 05:44:57 --> Total execution time: 0.6769
INFO - 2018-07-25 05:44:57 --> Config Class Initialized
INFO - 2018-07-25 05:44:57 --> Hooks Class Initialized
DEBUG - 2018-07-25 05:44:57 --> UTF-8 Support Enabled
INFO - 2018-07-25 05:44:57 --> Utf8 Class Initialized
INFO - 2018-07-25 05:44:57 --> URI Class Initialized
INFO - 2018-07-25 05:44:57 --> Router Class Initialized
INFO - 2018-07-25 05:44:57 --> Output Class Initialized
INFO - 2018-07-25 05:44:57 --> Security Class Initialized
DEBUG - 2018-07-25 05:44:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 05:44:57 --> Input Class Initialized
INFO - 2018-07-25 05:44:57 --> Language Class Initialized
INFO - 2018-07-25 05:44:57 --> Language Class Initialized
INFO - 2018-07-25 05:44:57 --> Config Class Initialized
INFO - 2018-07-25 05:44:57 --> Loader Class Initialized
DEBUG - 2018-07-25 05:44:57 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-25 05:44:57 --> Helper loaded: url_helper
INFO - 2018-07-25 05:44:57 --> Helper loaded: form_helper
INFO - 2018-07-25 05:44:57 --> Helper loaded: date_helper
INFO - 2018-07-25 05:44:57 --> Helper loaded: util_helper
INFO - 2018-07-25 05:44:57 --> Helper loaded: text_helper
INFO - 2018-07-25 05:44:58 --> Helper loaded: string_helper
INFO - 2018-07-25 05:44:58 --> Database Driver Class Initialized
DEBUG - 2018-07-25 05:44:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 05:44:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 05:44:58 --> Email Class Initialized
INFO - 2018-07-25 05:44:58 --> Controller Class Initialized
DEBUG - 2018-07-25 05:44:58 --> Users MX_Controller Initialized
DEBUG - 2018-07-25 05:44:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-25 05:44:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-07-25 05:44:58 --> Helper loaded: file_helper
DEBUG - 2018-07-25 05:44:58 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-25 05:44:58 --> Login MX_Controller Initialized
INFO - 2018-07-25 05:44:58 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-25 05:44:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-25 05:44:58 --> Final output sent to browser
DEBUG - 2018-07-25 05:44:58 --> Total execution time: 0.7178
INFO - 2018-07-25 05:47:42 --> Config Class Initialized
INFO - 2018-07-25 05:47:42 --> Hooks Class Initialized
DEBUG - 2018-07-25 05:47:42 --> UTF-8 Support Enabled
INFO - 2018-07-25 05:47:42 --> Utf8 Class Initialized
INFO - 2018-07-25 05:47:42 --> URI Class Initialized
INFO - 2018-07-25 05:47:42 --> Router Class Initialized
INFO - 2018-07-25 05:47:42 --> Output Class Initialized
INFO - 2018-07-25 05:47:42 --> Security Class Initialized
DEBUG - 2018-07-25 05:47:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 05:47:42 --> Input Class Initialized
INFO - 2018-07-25 05:47:42 --> Language Class Initialized
INFO - 2018-07-25 05:47:42 --> Language Class Initialized
INFO - 2018-07-25 05:47:43 --> Config Class Initialized
INFO - 2018-07-25 05:47:43 --> Loader Class Initialized
DEBUG - 2018-07-25 05:47:43 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-25 05:47:43 --> Helper loaded: url_helper
INFO - 2018-07-25 05:47:43 --> Helper loaded: form_helper
INFO - 2018-07-25 05:47:43 --> Helper loaded: date_helper
INFO - 2018-07-25 05:47:43 --> Helper loaded: util_helper
INFO - 2018-07-25 05:47:43 --> Helper loaded: text_helper
INFO - 2018-07-25 05:47:43 --> Helper loaded: string_helper
INFO - 2018-07-25 05:47:43 --> Database Driver Class Initialized
DEBUG - 2018-07-25 05:47:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 05:47:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 05:47:43 --> Email Class Initialized
INFO - 2018-07-25 05:47:43 --> Controller Class Initialized
DEBUG - 2018-07-25 05:47:43 --> Users MX_Controller Initialized
DEBUG - 2018-07-25 05:47:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-25 05:47:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-07-25 05:47:43 --> Helper loaded: file_helper
DEBUG - 2018-07-25 05:47:43 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-25 05:47:43 --> Login MX_Controller Initialized
INFO - 2018-07-25 05:47:43 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-25 05:47:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-25 05:47:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-25 05:47:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-25 05:47:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-25 05:47:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-25 05:47:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-25 05:47:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/users.php
INFO - 2018-07-25 05:47:43 --> Final output sent to browser
DEBUG - 2018-07-25 05:47:43 --> Total execution time: 0.6929
INFO - 2018-07-25 05:47:44 --> Config Class Initialized
INFO - 2018-07-25 05:47:44 --> Hooks Class Initialized
DEBUG - 2018-07-25 05:47:44 --> UTF-8 Support Enabled
INFO - 2018-07-25 05:47:44 --> Utf8 Class Initialized
INFO - 2018-07-25 05:47:44 --> URI Class Initialized
INFO - 2018-07-25 05:47:44 --> Router Class Initialized
INFO - 2018-07-25 05:47:44 --> Output Class Initialized
INFO - 2018-07-25 05:47:44 --> Security Class Initialized
DEBUG - 2018-07-25 05:47:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 05:47:44 --> Input Class Initialized
INFO - 2018-07-25 05:47:44 --> Language Class Initialized
INFO - 2018-07-25 05:47:44 --> Language Class Initialized
INFO - 2018-07-25 05:47:44 --> Config Class Initialized
INFO - 2018-07-25 05:47:44 --> Loader Class Initialized
DEBUG - 2018-07-25 05:47:44 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-25 05:47:44 --> Helper loaded: url_helper
INFO - 2018-07-25 05:47:44 --> Helper loaded: form_helper
INFO - 2018-07-25 05:47:44 --> Helper loaded: date_helper
INFO - 2018-07-25 05:47:44 --> Helper loaded: util_helper
INFO - 2018-07-25 05:47:44 --> Helper loaded: text_helper
INFO - 2018-07-25 05:47:44 --> Helper loaded: string_helper
INFO - 2018-07-25 05:47:44 --> Database Driver Class Initialized
DEBUG - 2018-07-25 05:47:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 05:47:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 05:47:44 --> Email Class Initialized
INFO - 2018-07-25 05:47:44 --> Controller Class Initialized
DEBUG - 2018-07-25 05:47:44 --> Users MX_Controller Initialized
DEBUG - 2018-07-25 05:47:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-25 05:47:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-07-25 05:47:44 --> Helper loaded: file_helper
DEBUG - 2018-07-25 05:47:44 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-25 05:47:44 --> Login MX_Controller Initialized
INFO - 2018-07-25 05:47:44 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-25 05:47:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-25 05:47:44 --> Final output sent to browser
DEBUG - 2018-07-25 05:47:44 --> Total execution time: 0.7282
INFO - 2018-07-25 05:47:56 --> Config Class Initialized
INFO - 2018-07-25 05:47:56 --> Hooks Class Initialized
DEBUG - 2018-07-25 05:47:56 --> UTF-8 Support Enabled
INFO - 2018-07-25 05:47:56 --> Utf8 Class Initialized
INFO - 2018-07-25 05:47:56 --> URI Class Initialized
INFO - 2018-07-25 05:47:56 --> Router Class Initialized
INFO - 2018-07-25 05:47:56 --> Output Class Initialized
INFO - 2018-07-25 05:47:56 --> Security Class Initialized
DEBUG - 2018-07-25 05:47:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 05:47:56 --> Input Class Initialized
INFO - 2018-07-25 05:47:56 --> Language Class Initialized
INFO - 2018-07-25 05:47:56 --> Language Class Initialized
INFO - 2018-07-25 05:47:56 --> Config Class Initialized
INFO - 2018-07-25 05:47:56 --> Loader Class Initialized
DEBUG - 2018-07-25 05:47:56 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-25 05:47:56 --> Helper loaded: url_helper
INFO - 2018-07-25 05:47:56 --> Helper loaded: form_helper
INFO - 2018-07-25 05:47:56 --> Helper loaded: date_helper
INFO - 2018-07-25 05:47:56 --> Helper loaded: util_helper
INFO - 2018-07-25 05:47:56 --> Helper loaded: text_helper
INFO - 2018-07-25 05:47:56 --> Helper loaded: string_helper
INFO - 2018-07-25 05:47:56 --> Database Driver Class Initialized
DEBUG - 2018-07-25 05:47:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 05:47:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 05:47:56 --> Email Class Initialized
INFO - 2018-07-25 05:47:56 --> Controller Class Initialized
DEBUG - 2018-07-25 05:47:56 --> Users MX_Controller Initialized
DEBUG - 2018-07-25 05:47:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-25 05:47:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-07-25 05:47:56 --> Helper loaded: file_helper
DEBUG - 2018-07-25 05:47:56 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-25 05:47:56 --> Login MX_Controller Initialized
INFO - 2018-07-25 05:47:56 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-25 05:47:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-25 05:47:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-25 05:47:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-25 05:47:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-25 05:47:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-25 05:47:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-25 05:47:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/users.php
INFO - 2018-07-25 05:47:56 --> Final output sent to browser
DEBUG - 2018-07-25 05:47:56 --> Total execution time: 0.6955
INFO - 2018-07-25 05:47:57 --> Config Class Initialized
INFO - 2018-07-25 05:47:57 --> Hooks Class Initialized
DEBUG - 2018-07-25 05:47:57 --> UTF-8 Support Enabled
INFO - 2018-07-25 05:47:57 --> Utf8 Class Initialized
INFO - 2018-07-25 05:47:57 --> URI Class Initialized
INFO - 2018-07-25 05:47:57 --> Router Class Initialized
INFO - 2018-07-25 05:47:57 --> Output Class Initialized
INFO - 2018-07-25 05:47:57 --> Security Class Initialized
DEBUG - 2018-07-25 05:47:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 05:47:57 --> Input Class Initialized
INFO - 2018-07-25 05:47:57 --> Language Class Initialized
INFO - 2018-07-25 05:47:57 --> Language Class Initialized
INFO - 2018-07-25 05:47:57 --> Config Class Initialized
INFO - 2018-07-25 05:47:57 --> Loader Class Initialized
DEBUG - 2018-07-25 05:47:57 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-25 05:47:57 --> Helper loaded: url_helper
INFO - 2018-07-25 05:47:57 --> Helper loaded: form_helper
INFO - 2018-07-25 05:47:57 --> Helper loaded: date_helper
INFO - 2018-07-25 05:47:57 --> Helper loaded: util_helper
INFO - 2018-07-25 05:47:57 --> Helper loaded: text_helper
INFO - 2018-07-25 05:47:57 --> Helper loaded: string_helper
INFO - 2018-07-25 05:47:57 --> Database Driver Class Initialized
DEBUG - 2018-07-25 05:47:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 05:47:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 05:47:58 --> Email Class Initialized
INFO - 2018-07-25 05:47:58 --> Controller Class Initialized
DEBUG - 2018-07-25 05:47:58 --> Users MX_Controller Initialized
DEBUG - 2018-07-25 05:47:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-25 05:47:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-07-25 05:47:58 --> Helper loaded: file_helper
DEBUG - 2018-07-25 05:47:58 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-25 05:47:58 --> Login MX_Controller Initialized
INFO - 2018-07-25 05:47:58 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-25 05:47:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-25 05:47:58 --> Final output sent to browser
DEBUG - 2018-07-25 05:47:58 --> Total execution time: 0.7178
INFO - 2018-07-25 21:35:17 --> Config Class Initialized
INFO - 2018-07-25 21:35:17 --> Hooks Class Initialized
DEBUG - 2018-07-25 21:35:17 --> UTF-8 Support Enabled
INFO - 2018-07-25 21:35:17 --> Utf8 Class Initialized
INFO - 2018-07-25 21:35:17 --> URI Class Initialized
INFO - 2018-07-25 21:35:18 --> Router Class Initialized
INFO - 2018-07-25 21:35:18 --> Output Class Initialized
INFO - 2018-07-25 21:35:18 --> Security Class Initialized
DEBUG - 2018-07-25 21:35:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 21:35:18 --> Input Class Initialized
INFO - 2018-07-25 21:35:18 --> Language Class Initialized
INFO - 2018-07-25 21:35:18 --> Language Class Initialized
INFO - 2018-07-25 21:35:18 --> Config Class Initialized
INFO - 2018-07-25 21:35:18 --> Loader Class Initialized
DEBUG - 2018-07-25 21:35:18 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-25 21:35:18 --> Helper loaded: url_helper
INFO - 2018-07-25 21:35:18 --> Helper loaded: form_helper
INFO - 2018-07-25 21:35:18 --> Helper loaded: date_helper
INFO - 2018-07-25 21:35:18 --> Helper loaded: util_helper
INFO - 2018-07-25 21:35:18 --> Helper loaded: text_helper
INFO - 2018-07-25 21:35:18 --> Helper loaded: string_helper
INFO - 2018-07-25 21:35:18 --> Database Driver Class Initialized
ERROR - 2018-07-25 21:35:20 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 E:\xampp\htdocs\consulting\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2018-07-25 21:35:20 --> Unable to connect to the database
INFO - 2018-07-25 21:35:20 --> Language file loaded: language/english/db_lang.php
INFO - 2018-07-25 21:40:47 --> Config Class Initialized
INFO - 2018-07-25 21:40:47 --> Hooks Class Initialized
DEBUG - 2018-07-25 21:40:47 --> UTF-8 Support Enabled
INFO - 2018-07-25 21:40:47 --> Utf8 Class Initialized
INFO - 2018-07-25 21:40:47 --> URI Class Initialized
INFO - 2018-07-25 21:40:47 --> Router Class Initialized
INFO - 2018-07-25 21:40:47 --> Output Class Initialized
INFO - 2018-07-25 21:40:47 --> Security Class Initialized
DEBUG - 2018-07-25 21:40:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 21:40:47 --> Input Class Initialized
INFO - 2018-07-25 21:40:47 --> Language Class Initialized
INFO - 2018-07-25 21:40:47 --> Language Class Initialized
INFO - 2018-07-25 21:40:47 --> Config Class Initialized
INFO - 2018-07-25 21:40:47 --> Loader Class Initialized
DEBUG - 2018-07-25 21:40:47 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-25 21:40:47 --> Helper loaded: url_helper
INFO - 2018-07-25 21:40:47 --> Helper loaded: form_helper
INFO - 2018-07-25 21:40:47 --> Helper loaded: date_helper
INFO - 2018-07-25 21:40:47 --> Helper loaded: util_helper
INFO - 2018-07-25 21:40:47 --> Helper loaded: text_helper
INFO - 2018-07-25 21:40:47 --> Helper loaded: string_helper
INFO - 2018-07-25 21:40:47 --> Database Driver Class Initialized
DEBUG - 2018-07-25 21:40:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 21:40:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 21:40:48 --> Email Class Initialized
INFO - 2018-07-25 21:40:48 --> Controller Class Initialized
DEBUG - 2018-07-25 21:40:48 --> Users MX_Controller Initialized
DEBUG - 2018-07-25 21:40:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-25 21:40:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-07-25 21:40:48 --> Helper loaded: file_helper
DEBUG - 2018-07-25 21:40:48 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-25 21:40:48 --> Login MX_Controller Initialized
INFO - 2018-07-25 21:40:48 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-25 21:40:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-25 21:40:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/logins/login.php
INFO - 2018-07-25 21:40:48 --> Config Class Initialized
INFO - 2018-07-25 21:40:48 --> Hooks Class Initialized
DEBUG - 2018-07-25 21:40:48 --> UTF-8 Support Enabled
INFO - 2018-07-25 21:40:48 --> Utf8 Class Initialized
INFO - 2018-07-25 21:40:48 --> URI Class Initialized
INFO - 2018-07-25 21:40:48 --> Router Class Initialized
INFO - 2018-07-25 21:40:48 --> Output Class Initialized
INFO - 2018-07-25 21:40:48 --> Security Class Initialized
DEBUG - 2018-07-25 21:40:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 21:40:48 --> Input Class Initialized
INFO - 2018-07-25 21:40:48 --> Language Class Initialized
ERROR - 2018-07-25 21:40:48 --> 404 Page Not Found: /index
INFO - 2018-07-25 21:57:24 --> Config Class Initialized
INFO - 2018-07-25 21:57:24 --> Hooks Class Initialized
DEBUG - 2018-07-25 21:57:24 --> UTF-8 Support Enabled
INFO - 2018-07-25 21:57:24 --> Utf8 Class Initialized
INFO - 2018-07-25 21:57:24 --> URI Class Initialized
INFO - 2018-07-25 21:57:24 --> Router Class Initialized
INFO - 2018-07-25 21:57:24 --> Output Class Initialized
INFO - 2018-07-25 21:57:24 --> Security Class Initialized
DEBUG - 2018-07-25 21:57:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 21:57:24 --> Input Class Initialized
INFO - 2018-07-25 21:57:24 --> Language Class Initialized
INFO - 2018-07-25 21:57:24 --> Language Class Initialized
INFO - 2018-07-25 21:57:24 --> Config Class Initialized
INFO - 2018-07-25 21:57:24 --> Loader Class Initialized
DEBUG - 2018-07-25 21:57:24 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-25 21:57:24 --> Helper loaded: url_helper
INFO - 2018-07-25 21:57:24 --> Helper loaded: form_helper
INFO - 2018-07-25 21:57:24 --> Helper loaded: date_helper
INFO - 2018-07-25 21:57:24 --> Helper loaded: util_helper
INFO - 2018-07-25 21:57:25 --> Helper loaded: text_helper
INFO - 2018-07-25 21:57:25 --> Helper loaded: string_helper
INFO - 2018-07-25 21:57:25 --> Database Driver Class Initialized
DEBUG - 2018-07-25 21:57:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 21:57:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 21:57:25 --> Email Class Initialized
INFO - 2018-07-25 21:57:25 --> Controller Class Initialized
DEBUG - 2018-07-25 21:57:25 --> Users MX_Controller Initialized
DEBUG - 2018-07-25 21:57:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-25 21:57:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-07-25 21:57:25 --> Helper loaded: file_helper
DEBUG - 2018-07-25 21:57:25 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-25 21:57:25 --> Login MX_Controller Initialized
INFO - 2018-07-25 21:57:25 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-25 21:57:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-25 21:57:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/logins/login.php
INFO - 2018-07-25 21:57:25 --> Config Class Initialized
INFO - 2018-07-25 21:57:25 --> Hooks Class Initialized
DEBUG - 2018-07-25 21:57:25 --> UTF-8 Support Enabled
INFO - 2018-07-25 21:57:25 --> Utf8 Class Initialized
INFO - 2018-07-25 21:57:25 --> URI Class Initialized
INFO - 2018-07-25 21:57:25 --> Router Class Initialized
INFO - 2018-07-25 21:57:25 --> Output Class Initialized
INFO - 2018-07-25 21:57:25 --> Security Class Initialized
DEBUG - 2018-07-25 21:57:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 21:57:25 --> Input Class Initialized
INFO - 2018-07-25 21:57:25 --> Language Class Initialized
ERROR - 2018-07-25 21:57:25 --> 404 Page Not Found: /index
INFO - 2018-07-25 21:57:31 --> Config Class Initialized
INFO - 2018-07-25 21:57:31 --> Hooks Class Initialized
DEBUG - 2018-07-25 21:57:31 --> UTF-8 Support Enabled
INFO - 2018-07-25 21:57:31 --> Utf8 Class Initialized
INFO - 2018-07-25 21:57:31 --> URI Class Initialized
INFO - 2018-07-25 21:57:31 --> Router Class Initialized
INFO - 2018-07-25 21:57:31 --> Output Class Initialized
INFO - 2018-07-25 21:57:31 --> Security Class Initialized
DEBUG - 2018-07-25 21:57:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 21:57:31 --> Input Class Initialized
INFO - 2018-07-25 21:57:31 --> Language Class Initialized
INFO - 2018-07-25 21:57:32 --> Language Class Initialized
INFO - 2018-07-25 21:57:32 --> Config Class Initialized
INFO - 2018-07-25 21:57:32 --> Loader Class Initialized
DEBUG - 2018-07-25 21:57:32 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-25 21:57:32 --> Helper loaded: url_helper
INFO - 2018-07-25 21:57:32 --> Helper loaded: form_helper
INFO - 2018-07-25 21:57:32 --> Helper loaded: date_helper
INFO - 2018-07-25 21:57:32 --> Helper loaded: util_helper
INFO - 2018-07-25 21:57:32 --> Helper loaded: text_helper
INFO - 2018-07-25 21:57:32 --> Helper loaded: string_helper
INFO - 2018-07-25 21:57:32 --> Database Driver Class Initialized
DEBUG - 2018-07-25 21:57:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 21:57:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 21:57:32 --> Email Class Initialized
INFO - 2018-07-25 21:57:32 --> Controller Class Initialized
DEBUG - 2018-07-25 21:57:32 --> Login MX_Controller Initialized
INFO - 2018-07-25 21:57:32 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-25 21:57:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-25 21:57:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-25 21:57:32 --> Email starts for admin@colin.com fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-07-25 21:57:32 --> User session created for 1
INFO - 2018-07-25 21:57:32 --> Login status admin@colin.com - success
INFO - 2018-07-25 21:57:32 --> Final output sent to browser
DEBUG - 2018-07-25 21:57:32 --> Total execution time: 0.6816
INFO - 2018-07-25 21:57:32 --> Config Class Initialized
INFO - 2018-07-25 21:57:32 --> Hooks Class Initialized
DEBUG - 2018-07-25 21:57:32 --> UTF-8 Support Enabled
INFO - 2018-07-25 21:57:32 --> Utf8 Class Initialized
INFO - 2018-07-25 21:57:32 --> URI Class Initialized
INFO - 2018-07-25 21:57:32 --> Router Class Initialized
INFO - 2018-07-25 21:57:32 --> Output Class Initialized
INFO - 2018-07-25 21:57:32 --> Security Class Initialized
DEBUG - 2018-07-25 21:57:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 21:57:32 --> Input Class Initialized
INFO - 2018-07-25 21:57:32 --> Language Class Initialized
INFO - 2018-07-25 21:57:32 --> Language Class Initialized
INFO - 2018-07-25 21:57:32 --> Config Class Initialized
INFO - 2018-07-25 21:57:32 --> Loader Class Initialized
DEBUG - 2018-07-25 21:57:32 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-25 21:57:32 --> Helper loaded: url_helper
INFO - 2018-07-25 21:57:32 --> Helper loaded: form_helper
INFO - 2018-07-25 21:57:32 --> Helper loaded: date_helper
INFO - 2018-07-25 21:57:32 --> Helper loaded: util_helper
INFO - 2018-07-25 21:57:32 --> Helper loaded: text_helper
INFO - 2018-07-25 21:57:32 --> Helper loaded: string_helper
INFO - 2018-07-25 21:57:32 --> Database Driver Class Initialized
DEBUG - 2018-07-25 21:57:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 21:57:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 21:57:32 --> Email Class Initialized
INFO - 2018-07-25 21:57:33 --> Controller Class Initialized
DEBUG - 2018-07-25 21:57:33 --> Users MX_Controller Initialized
DEBUG - 2018-07-25 21:57:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-25 21:57:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-07-25 21:57:33 --> Helper loaded: file_helper
DEBUG - 2018-07-25 21:57:33 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-25 21:57:33 --> Login MX_Controller Initialized
INFO - 2018-07-25 21:57:33 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-25 21:57:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-25 21:57:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-25 21:57:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-25 21:57:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-25 21:57:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-25 21:57:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-25 21:57:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-25 21:57:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/create_user.php
INFO - 2018-07-25 21:57:33 --> Final output sent to browser
DEBUG - 2018-07-25 21:57:33 --> Total execution time: 0.9908
INFO - 2018-07-25 21:57:34 --> Config Class Initialized
INFO - 2018-07-25 21:57:34 --> Hooks Class Initialized
DEBUG - 2018-07-25 21:57:34 --> UTF-8 Support Enabled
INFO - 2018-07-25 21:57:34 --> Utf8 Class Initialized
INFO - 2018-07-25 21:57:34 --> URI Class Initialized
INFO - 2018-07-25 21:57:34 --> Router Class Initialized
INFO - 2018-07-25 21:57:34 --> Output Class Initialized
INFO - 2018-07-25 21:57:34 --> Security Class Initialized
DEBUG - 2018-07-25 21:57:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 21:57:34 --> Input Class Initialized
INFO - 2018-07-25 21:57:34 --> Language Class Initialized
INFO - 2018-07-25 21:57:34 --> Language Class Initialized
INFO - 2018-07-25 21:57:34 --> Config Class Initialized
INFO - 2018-07-25 21:57:34 --> Loader Class Initialized
DEBUG - 2018-07-25 21:57:34 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-25 21:57:34 --> Helper loaded: url_helper
INFO - 2018-07-25 21:57:34 --> Helper loaded: form_helper
INFO - 2018-07-25 21:57:34 --> Helper loaded: date_helper
INFO - 2018-07-25 21:57:34 --> Helper loaded: util_helper
INFO - 2018-07-25 21:57:34 --> Helper loaded: text_helper
INFO - 2018-07-25 21:57:34 --> Helper loaded: string_helper
INFO - 2018-07-25 21:57:34 --> Database Driver Class Initialized
DEBUG - 2018-07-25 21:57:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 21:57:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 21:57:34 --> Email Class Initialized
INFO - 2018-07-25 21:57:34 --> Controller Class Initialized
DEBUG - 2018-07-25 21:57:34 --> Users MX_Controller Initialized
DEBUG - 2018-07-25 21:57:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-25 21:57:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-07-25 21:57:34 --> Helper loaded: file_helper
DEBUG - 2018-07-25 21:57:34 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-25 21:57:34 --> Login MX_Controller Initialized
INFO - 2018-07-25 21:57:34 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-25 21:57:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-25 21:57:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-25 21:57:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-25 21:57:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-25 21:57:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-25 21:57:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-25 21:57:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/users.php
INFO - 2018-07-25 21:57:35 --> Final output sent to browser
DEBUG - 2018-07-25 21:57:35 --> Total execution time: 0.9598
INFO - 2018-07-25 21:57:35 --> Config Class Initialized
INFO - 2018-07-25 21:57:35 --> Hooks Class Initialized
DEBUG - 2018-07-25 21:57:35 --> UTF-8 Support Enabled
INFO - 2018-07-25 21:57:35 --> Utf8 Class Initialized
INFO - 2018-07-25 21:57:35 --> URI Class Initialized
INFO - 2018-07-25 21:57:35 --> Router Class Initialized
INFO - 2018-07-25 21:57:35 --> Output Class Initialized
INFO - 2018-07-25 21:57:36 --> Security Class Initialized
DEBUG - 2018-07-25 21:57:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 21:57:36 --> Input Class Initialized
INFO - 2018-07-25 21:57:36 --> Language Class Initialized
INFO - 2018-07-25 21:57:36 --> Language Class Initialized
INFO - 2018-07-25 21:57:36 --> Config Class Initialized
INFO - 2018-07-25 21:57:36 --> Loader Class Initialized
DEBUG - 2018-07-25 21:57:36 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-25 21:57:36 --> Helper loaded: url_helper
INFO - 2018-07-25 21:57:36 --> Helper loaded: form_helper
INFO - 2018-07-25 21:57:36 --> Helper loaded: date_helper
INFO - 2018-07-25 21:57:36 --> Helper loaded: util_helper
INFO - 2018-07-25 21:57:36 --> Helper loaded: text_helper
INFO - 2018-07-25 21:57:36 --> Helper loaded: string_helper
INFO - 2018-07-25 21:57:36 --> Database Driver Class Initialized
DEBUG - 2018-07-25 21:57:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 21:57:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 21:57:36 --> Email Class Initialized
INFO - 2018-07-25 21:57:36 --> Controller Class Initialized
DEBUG - 2018-07-25 21:57:36 --> Users MX_Controller Initialized
DEBUG - 2018-07-25 21:57:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-25 21:57:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-07-25 21:57:36 --> Helper loaded: file_helper
DEBUG - 2018-07-25 21:57:36 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-25 21:57:36 --> Login MX_Controller Initialized
INFO - 2018-07-25 21:57:36 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-25 21:57:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-25 21:57:36 --> Final output sent to browser
DEBUG - 2018-07-25 21:57:36 --> Total execution time: 1.0538
INFO - 2018-07-25 22:01:30 --> Config Class Initialized
INFO - 2018-07-25 22:01:30 --> Hooks Class Initialized
DEBUG - 2018-07-25 22:01:30 --> UTF-8 Support Enabled
INFO - 2018-07-25 22:01:30 --> Utf8 Class Initialized
INFO - 2018-07-25 22:01:30 --> URI Class Initialized
INFO - 2018-07-25 22:01:30 --> Router Class Initialized
INFO - 2018-07-25 22:01:30 --> Output Class Initialized
INFO - 2018-07-25 22:01:30 --> Security Class Initialized
DEBUG - 2018-07-25 22:01:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 22:01:30 --> Input Class Initialized
INFO - 2018-07-25 22:01:30 --> Language Class Initialized
INFO - 2018-07-25 22:01:30 --> Language Class Initialized
INFO - 2018-07-25 22:01:30 --> Config Class Initialized
INFO - 2018-07-25 22:01:30 --> Loader Class Initialized
DEBUG - 2018-07-25 22:01:30 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-25 22:01:30 --> Helper loaded: url_helper
INFO - 2018-07-25 22:01:30 --> Helper loaded: form_helper
INFO - 2018-07-25 22:01:30 --> Helper loaded: date_helper
INFO - 2018-07-25 22:01:30 --> Helper loaded: util_helper
INFO - 2018-07-25 22:01:30 --> Helper loaded: text_helper
INFO - 2018-07-25 22:01:31 --> Helper loaded: string_helper
INFO - 2018-07-25 22:01:31 --> Database Driver Class Initialized
DEBUG - 2018-07-25 22:01:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 22:01:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 22:01:31 --> Email Class Initialized
INFO - 2018-07-25 22:01:31 --> Controller Class Initialized
DEBUG - 2018-07-25 22:01:31 --> Users MX_Controller Initialized
DEBUG - 2018-07-25 22:01:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-25 22:01:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-07-25 22:01:31 --> Helper loaded: file_helper
DEBUG - 2018-07-25 22:01:31 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-25 22:01:31 --> Login MX_Controller Initialized
INFO - 2018-07-25 22:01:31 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-25 22:01:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-25 22:01:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-25 22:01:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-25 22:01:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-25 22:01:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-25 22:01:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-25 22:01:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/users.php
INFO - 2018-07-25 22:01:31 --> Final output sent to browser
DEBUG - 2018-07-25 22:01:31 --> Total execution time: 0.6837
INFO - 2018-07-25 22:01:31 --> Config Class Initialized
INFO - 2018-07-25 22:01:31 --> Hooks Class Initialized
DEBUG - 2018-07-25 22:01:31 --> UTF-8 Support Enabled
INFO - 2018-07-25 22:01:31 --> Utf8 Class Initialized
INFO - 2018-07-25 22:01:31 --> URI Class Initialized
INFO - 2018-07-25 22:01:31 --> Router Class Initialized
INFO - 2018-07-25 22:01:32 --> Output Class Initialized
INFO - 2018-07-25 22:01:32 --> Security Class Initialized
DEBUG - 2018-07-25 22:01:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 22:01:32 --> Input Class Initialized
INFO - 2018-07-25 22:01:32 --> Language Class Initialized
INFO - 2018-07-25 22:01:32 --> Language Class Initialized
INFO - 2018-07-25 22:01:32 --> Config Class Initialized
INFO - 2018-07-25 22:01:32 --> Loader Class Initialized
DEBUG - 2018-07-25 22:01:32 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-25 22:01:32 --> Helper loaded: url_helper
INFO - 2018-07-25 22:01:32 --> Helper loaded: form_helper
INFO - 2018-07-25 22:01:32 --> Helper loaded: date_helper
INFO - 2018-07-25 22:01:32 --> Helper loaded: util_helper
INFO - 2018-07-25 22:01:32 --> Helper loaded: text_helper
INFO - 2018-07-25 22:01:32 --> Helper loaded: string_helper
INFO - 2018-07-25 22:01:32 --> Database Driver Class Initialized
DEBUG - 2018-07-25 22:01:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 22:01:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 22:01:32 --> Email Class Initialized
INFO - 2018-07-25 22:01:32 --> Controller Class Initialized
DEBUG - 2018-07-25 22:01:32 --> Users MX_Controller Initialized
DEBUG - 2018-07-25 22:01:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-25 22:01:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-07-25 22:01:32 --> Helper loaded: file_helper
DEBUG - 2018-07-25 22:01:32 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-25 22:01:32 --> Login MX_Controller Initialized
INFO - 2018-07-25 22:01:32 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-25 22:01:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-25 22:01:32 --> Final output sent to browser
DEBUG - 2018-07-25 22:01:32 --> Total execution time: 0.7734
INFO - 2018-07-25 22:04:37 --> Config Class Initialized
INFO - 2018-07-25 22:04:38 --> Hooks Class Initialized
DEBUG - 2018-07-25 22:04:38 --> UTF-8 Support Enabled
INFO - 2018-07-25 22:04:38 --> Utf8 Class Initialized
INFO - 2018-07-25 22:04:38 --> URI Class Initialized
DEBUG - 2018-07-25 22:04:38 --> No URI present. Default controller set.
INFO - 2018-07-25 22:04:38 --> Router Class Initialized
INFO - 2018-07-25 22:04:38 --> Output Class Initialized
INFO - 2018-07-25 22:04:38 --> Security Class Initialized
DEBUG - 2018-07-25 22:04:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 22:04:38 --> Input Class Initialized
INFO - 2018-07-25 22:04:38 --> Language Class Initialized
INFO - 2018-07-25 22:04:38 --> Language Class Initialized
INFO - 2018-07-25 22:04:38 --> Config Class Initialized
INFO - 2018-07-25 22:04:38 --> Loader Class Initialized
DEBUG - 2018-07-25 22:04:38 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-25 22:04:38 --> Helper loaded: url_helper
INFO - 2018-07-25 22:04:38 --> Helper loaded: form_helper
INFO - 2018-07-25 22:04:38 --> Helper loaded: date_helper
INFO - 2018-07-25 22:04:38 --> Helper loaded: util_helper
INFO - 2018-07-25 22:04:38 --> Helper loaded: text_helper
INFO - 2018-07-25 22:04:38 --> Helper loaded: string_helper
INFO - 2018-07-25 22:04:38 --> Database Driver Class Initialized
DEBUG - 2018-07-25 22:04:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 22:04:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 22:04:38 --> Email Class Initialized
INFO - 2018-07-25 22:04:38 --> Controller Class Initialized
DEBUG - 2018-07-25 22:04:38 --> Home MX_Controller Initialized
DEBUG - 2018-07-25 22:04:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-25 22:04:38 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-25 22:04:38 --> Login MX_Controller Initialized
INFO - 2018-07-25 22:04:38 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-25 22:04:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-25 22:04:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-25 22:04:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/login.php
INFO - 2018-07-25 22:04:46 --> Config Class Initialized
INFO - 2018-07-25 22:04:46 --> Hooks Class Initialized
DEBUG - 2018-07-25 22:04:46 --> UTF-8 Support Enabled
INFO - 2018-07-25 22:04:46 --> Utf8 Class Initialized
INFO - 2018-07-25 22:04:47 --> URI Class Initialized
INFO - 2018-07-25 22:04:47 --> Router Class Initialized
INFO - 2018-07-25 22:04:47 --> Output Class Initialized
INFO - 2018-07-25 22:04:47 --> Security Class Initialized
DEBUG - 2018-07-25 22:04:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 22:04:47 --> Input Class Initialized
INFO - 2018-07-25 22:04:47 --> Language Class Initialized
INFO - 2018-07-25 22:04:47 --> Language Class Initialized
INFO - 2018-07-25 22:04:47 --> Config Class Initialized
INFO - 2018-07-25 22:04:47 --> Loader Class Initialized
DEBUG - 2018-07-25 22:04:47 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-25 22:04:47 --> Helper loaded: url_helper
INFO - 2018-07-25 22:04:47 --> Helper loaded: form_helper
INFO - 2018-07-25 22:04:47 --> Helper loaded: date_helper
INFO - 2018-07-25 22:04:47 --> Helper loaded: util_helper
INFO - 2018-07-25 22:04:47 --> Helper loaded: text_helper
INFO - 2018-07-25 22:04:47 --> Helper loaded: string_helper
INFO - 2018-07-25 22:04:47 --> Database Driver Class Initialized
DEBUG - 2018-07-25 22:04:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 22:04:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 22:04:47 --> Email Class Initialized
INFO - 2018-07-25 22:04:47 --> Controller Class Initialized
DEBUG - 2018-07-25 22:04:47 --> Login MX_Controller Initialized
INFO - 2018-07-25 22:04:47 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-25 22:04:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-25 22:04:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-25 22:04:47 --> Email starts for user@colin.com fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-07-25 22:04:47 --> User session created for 4
INFO - 2018-07-25 22:04:47 --> Login status user@colin.com - success
INFO - 2018-07-25 22:04:47 --> Final output sent to browser
DEBUG - 2018-07-25 22:04:47 --> Total execution time: 0.6121
INFO - 2018-07-25 22:04:47 --> Config Class Initialized
INFO - 2018-07-25 22:04:47 --> Hooks Class Initialized
DEBUG - 2018-07-25 22:04:47 --> UTF-8 Support Enabled
INFO - 2018-07-25 22:04:47 --> Utf8 Class Initialized
INFO - 2018-07-25 22:04:47 --> URI Class Initialized
DEBUG - 2018-07-25 22:04:47 --> No URI present. Default controller set.
INFO - 2018-07-25 22:04:47 --> Router Class Initialized
INFO - 2018-07-25 22:04:47 --> Output Class Initialized
INFO - 2018-07-25 22:04:47 --> Security Class Initialized
DEBUG - 2018-07-25 22:04:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 22:04:47 --> Input Class Initialized
INFO - 2018-07-25 22:04:47 --> Language Class Initialized
INFO - 2018-07-25 22:04:47 --> Language Class Initialized
INFO - 2018-07-25 22:04:47 --> Config Class Initialized
INFO - 2018-07-25 22:04:47 --> Loader Class Initialized
DEBUG - 2018-07-25 22:04:47 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-25 22:04:47 --> Helper loaded: url_helper
INFO - 2018-07-25 22:04:47 --> Helper loaded: form_helper
INFO - 2018-07-25 22:04:47 --> Helper loaded: date_helper
INFO - 2018-07-25 22:04:47 --> Helper loaded: util_helper
INFO - 2018-07-25 22:04:47 --> Helper loaded: text_helper
INFO - 2018-07-25 22:04:47 --> Helper loaded: string_helper
INFO - 2018-07-25 22:04:47 --> Database Driver Class Initialized
DEBUG - 2018-07-25 22:04:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 22:04:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 22:04:48 --> Email Class Initialized
INFO - 2018-07-25 22:04:48 --> Controller Class Initialized
DEBUG - 2018-07-25 22:04:48 --> Home MX_Controller Initialized
DEBUG - 2018-07-25 22:04:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-25 22:04:48 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-25 22:04:48 --> Login MX_Controller Initialized
INFO - 2018-07-25 22:04:48 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-25 22:04:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-25 22:04:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-25 22:04:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-07-25 22:04:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-07-25 22:04:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-07-25 22:04:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-07-25 22:04:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-07-25 22:04:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-07-25 22:04:48 --> Final output sent to browser
DEBUG - 2018-07-25 22:04:48 --> Total execution time: 0.9481
INFO - 2018-07-25 22:04:49 --> Config Class Initialized
INFO - 2018-07-25 22:04:49 --> Hooks Class Initialized
DEBUG - 2018-07-25 22:04:49 --> UTF-8 Support Enabled
INFO - 2018-07-25 22:04:50 --> Utf8 Class Initialized
INFO - 2018-07-25 22:04:50 --> URI Class Initialized
INFO - 2018-07-25 22:04:50 --> Router Class Initialized
INFO - 2018-07-25 22:04:50 --> Output Class Initialized
INFO - 2018-07-25 22:04:50 --> Security Class Initialized
DEBUG - 2018-07-25 22:04:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 22:04:50 --> Input Class Initialized
INFO - 2018-07-25 22:04:50 --> Language Class Initialized
ERROR - 2018-07-25 22:04:50 --> 404 Page Not Found: /index
INFO - 2018-07-25 22:04:50 --> Config Class Initialized
INFO - 2018-07-25 22:04:50 --> Hooks Class Initialized
DEBUG - 2018-07-25 22:04:50 --> UTF-8 Support Enabled
INFO - 2018-07-25 22:04:50 --> Utf8 Class Initialized
INFO - 2018-07-25 22:04:50 --> URI Class Initialized
INFO - 2018-07-25 22:04:50 --> Router Class Initialized
INFO - 2018-07-25 22:04:50 --> Output Class Initialized
INFO - 2018-07-25 22:04:50 --> Security Class Initialized
DEBUG - 2018-07-25 22:04:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 22:04:50 --> Input Class Initialized
INFO - 2018-07-25 22:04:50 --> Language Class Initialized
ERROR - 2018-07-25 22:04:50 --> 404 Page Not Found: /index
INFO - 2018-07-25 22:04:50 --> Config Class Initialized
INFO - 2018-07-25 22:04:50 --> Hooks Class Initialized
DEBUG - 2018-07-25 22:04:50 --> UTF-8 Support Enabled
INFO - 2018-07-25 22:04:50 --> Utf8 Class Initialized
INFO - 2018-07-25 22:04:50 --> URI Class Initialized
INFO - 2018-07-25 22:04:50 --> Router Class Initialized
INFO - 2018-07-25 22:04:50 --> Output Class Initialized
INFO - 2018-07-25 22:04:50 --> Security Class Initialized
DEBUG - 2018-07-25 22:04:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 22:04:50 --> Input Class Initialized
INFO - 2018-07-25 22:04:50 --> Language Class Initialized
ERROR - 2018-07-25 22:04:50 --> 404 Page Not Found: /index
INFO - 2018-07-25 22:04:50 --> Config Class Initialized
INFO - 2018-07-25 22:04:50 --> Hooks Class Initialized
DEBUG - 2018-07-25 22:04:51 --> UTF-8 Support Enabled
INFO - 2018-07-25 22:04:51 --> Utf8 Class Initialized
INFO - 2018-07-25 22:04:51 --> URI Class Initialized
INFO - 2018-07-25 22:04:51 --> Router Class Initialized
INFO - 2018-07-25 22:04:51 --> Output Class Initialized
INFO - 2018-07-25 22:04:51 --> Security Class Initialized
DEBUG - 2018-07-25 22:04:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 22:04:51 --> Input Class Initialized
INFO - 2018-07-25 22:04:51 --> Language Class Initialized
ERROR - 2018-07-25 22:04:51 --> 404 Page Not Found: /index
INFO - 2018-07-25 22:04:51 --> Config Class Initialized
INFO - 2018-07-25 22:04:51 --> Hooks Class Initialized
DEBUG - 2018-07-25 22:04:51 --> UTF-8 Support Enabled
INFO - 2018-07-25 22:04:51 --> Utf8 Class Initialized
INFO - 2018-07-25 22:04:51 --> URI Class Initialized
INFO - 2018-07-25 22:04:51 --> Router Class Initialized
INFO - 2018-07-25 22:04:51 --> Output Class Initialized
INFO - 2018-07-25 22:04:51 --> Security Class Initialized
DEBUG - 2018-07-25 22:04:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 22:04:51 --> Input Class Initialized
INFO - 2018-07-25 22:04:51 --> Language Class Initialized
ERROR - 2018-07-25 22:04:51 --> 404 Page Not Found: /index
INFO - 2018-07-25 22:04:51 --> Config Class Initialized
INFO - 2018-07-25 22:04:51 --> Hooks Class Initialized
DEBUG - 2018-07-25 22:04:51 --> UTF-8 Support Enabled
INFO - 2018-07-25 22:04:51 --> Utf8 Class Initialized
INFO - 2018-07-25 22:04:51 --> URI Class Initialized
INFO - 2018-07-25 22:04:51 --> Router Class Initialized
INFO - 2018-07-25 22:04:51 --> Output Class Initialized
INFO - 2018-07-25 22:04:51 --> Security Class Initialized
DEBUG - 2018-07-25 22:04:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 22:04:51 --> Input Class Initialized
INFO - 2018-07-25 22:04:51 --> Language Class Initialized
ERROR - 2018-07-25 22:04:51 --> 404 Page Not Found: /index
INFO - 2018-07-25 22:04:53 --> Config Class Initialized
INFO - 2018-07-25 22:04:53 --> Hooks Class Initialized
DEBUG - 2018-07-25 22:04:53 --> UTF-8 Support Enabled
INFO - 2018-07-25 22:04:53 --> Utf8 Class Initialized
INFO - 2018-07-25 22:04:53 --> URI Class Initialized
INFO - 2018-07-25 22:04:53 --> Router Class Initialized
INFO - 2018-07-25 22:04:53 --> Output Class Initialized
INFO - 2018-07-25 22:04:53 --> Security Class Initialized
DEBUG - 2018-07-25 22:04:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 22:04:53 --> Input Class Initialized
INFO - 2018-07-25 22:04:53 --> Language Class Initialized
ERROR - 2018-07-25 22:04:53 --> 404 Page Not Found: /index
INFO - 2018-07-25 22:04:53 --> Config Class Initialized
INFO - 2018-07-25 22:04:53 --> Hooks Class Initialized
DEBUG - 2018-07-25 22:04:53 --> UTF-8 Support Enabled
INFO - 2018-07-25 22:04:53 --> Utf8 Class Initialized
INFO - 2018-07-25 22:04:53 --> URI Class Initialized
INFO - 2018-07-25 22:04:53 --> Router Class Initialized
INFO - 2018-07-25 22:04:53 --> Output Class Initialized
INFO - 2018-07-25 22:04:53 --> Security Class Initialized
DEBUG - 2018-07-25 22:04:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 22:04:53 --> Input Class Initialized
INFO - 2018-07-25 22:04:53 --> Language Class Initialized
ERROR - 2018-07-25 22:04:53 --> 404 Page Not Found: /index
INFO - 2018-07-25 22:04:53 --> Config Class Initialized
INFO - 2018-07-25 22:04:53 --> Hooks Class Initialized
DEBUG - 2018-07-25 22:04:53 --> UTF-8 Support Enabled
INFO - 2018-07-25 22:04:53 --> Utf8 Class Initialized
INFO - 2018-07-25 22:04:53 --> URI Class Initialized
INFO - 2018-07-25 22:04:53 --> Router Class Initialized
INFO - 2018-07-25 22:04:53 --> Output Class Initialized
INFO - 2018-07-25 22:04:53 --> Security Class Initialized
DEBUG - 2018-07-25 22:04:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 22:04:53 --> Input Class Initialized
INFO - 2018-07-25 22:04:54 --> Language Class Initialized
ERROR - 2018-07-25 22:04:54 --> 404 Page Not Found: /index
INFO - 2018-07-25 22:04:56 --> Config Class Initialized
INFO - 2018-07-25 22:04:56 --> Hooks Class Initialized
DEBUG - 2018-07-25 22:04:56 --> UTF-8 Support Enabled
INFO - 2018-07-25 22:04:56 --> Utf8 Class Initialized
INFO - 2018-07-25 22:04:56 --> URI Class Initialized
DEBUG - 2018-07-25 22:04:56 --> No URI present. Default controller set.
INFO - 2018-07-25 22:04:56 --> Router Class Initialized
INFO - 2018-07-25 22:04:56 --> Output Class Initialized
INFO - 2018-07-25 22:04:56 --> Security Class Initialized
DEBUG - 2018-07-25 22:04:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 22:04:56 --> Input Class Initialized
INFO - 2018-07-25 22:04:56 --> Language Class Initialized
INFO - 2018-07-25 22:04:56 --> Language Class Initialized
INFO - 2018-07-25 22:04:56 --> Config Class Initialized
INFO - 2018-07-25 22:04:56 --> Loader Class Initialized
DEBUG - 2018-07-25 22:04:56 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-25 22:04:56 --> Helper loaded: url_helper
INFO - 2018-07-25 22:04:56 --> Helper loaded: form_helper
INFO - 2018-07-25 22:04:56 --> Helper loaded: date_helper
INFO - 2018-07-25 22:04:56 --> Helper loaded: util_helper
INFO - 2018-07-25 22:04:56 --> Helper loaded: text_helper
INFO - 2018-07-25 22:04:56 --> Helper loaded: string_helper
INFO - 2018-07-25 22:04:56 --> Database Driver Class Initialized
DEBUG - 2018-07-25 22:04:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 22:04:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 22:04:56 --> Email Class Initialized
INFO - 2018-07-25 22:04:56 --> Controller Class Initialized
DEBUG - 2018-07-25 22:04:56 --> Home MX_Controller Initialized
DEBUG - 2018-07-25 22:04:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-25 22:04:56 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-25 22:04:56 --> Login MX_Controller Initialized
INFO - 2018-07-25 22:04:56 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-25 22:04:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-25 22:04:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-25 22:04:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-07-25 22:04:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-07-25 22:04:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-07-25 22:04:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-07-25 22:04:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-07-25 22:04:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-07-25 22:04:56 --> Final output sent to browser
DEBUG - 2018-07-25 22:04:56 --> Total execution time: 0.7220
INFO - 2018-07-25 22:04:57 --> Config Class Initialized
INFO - 2018-07-25 22:04:57 --> Hooks Class Initialized
DEBUG - 2018-07-25 22:04:57 --> UTF-8 Support Enabled
INFO - 2018-07-25 22:04:57 --> Utf8 Class Initialized
INFO - 2018-07-25 22:04:57 --> URI Class Initialized
INFO - 2018-07-25 22:04:57 --> Router Class Initialized
INFO - 2018-07-25 22:04:57 --> Output Class Initialized
INFO - 2018-07-25 22:04:57 --> Security Class Initialized
DEBUG - 2018-07-25 22:04:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 22:04:57 --> Input Class Initialized
INFO - 2018-07-25 22:04:57 --> Language Class Initialized
ERROR - 2018-07-25 22:04:57 --> 404 Page Not Found: /index
INFO - 2018-07-25 22:04:57 --> Config Class Initialized
INFO - 2018-07-25 22:04:57 --> Hooks Class Initialized
DEBUG - 2018-07-25 22:04:57 --> UTF-8 Support Enabled
INFO - 2018-07-25 22:04:57 --> Utf8 Class Initialized
INFO - 2018-07-25 22:04:57 --> URI Class Initialized
INFO - 2018-07-25 22:04:57 --> Router Class Initialized
INFO - 2018-07-25 22:04:57 --> Output Class Initialized
INFO - 2018-07-25 22:04:57 --> Security Class Initialized
DEBUG - 2018-07-25 22:04:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 22:04:57 --> Input Class Initialized
INFO - 2018-07-25 22:04:57 --> Language Class Initialized
ERROR - 2018-07-25 22:04:57 --> 404 Page Not Found: /index
INFO - 2018-07-25 22:04:57 --> Config Class Initialized
INFO - 2018-07-25 22:04:57 --> Hooks Class Initialized
DEBUG - 2018-07-25 22:04:57 --> UTF-8 Support Enabled
INFO - 2018-07-25 22:04:57 --> Utf8 Class Initialized
INFO - 2018-07-25 22:04:57 --> URI Class Initialized
INFO - 2018-07-25 22:04:57 --> Router Class Initialized
INFO - 2018-07-25 22:04:57 --> Output Class Initialized
INFO - 2018-07-25 22:04:57 --> Security Class Initialized
DEBUG - 2018-07-25 22:04:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 22:04:57 --> Input Class Initialized
INFO - 2018-07-25 22:04:57 --> Language Class Initialized
ERROR - 2018-07-25 22:04:57 --> 404 Page Not Found: /index
INFO - 2018-07-25 22:05:48 --> Config Class Initialized
INFO - 2018-07-25 22:05:48 --> Hooks Class Initialized
DEBUG - 2018-07-25 22:05:48 --> UTF-8 Support Enabled
INFO - 2018-07-25 22:05:48 --> Utf8 Class Initialized
INFO - 2018-07-25 22:05:48 --> URI Class Initialized
INFO - 2018-07-25 22:05:48 --> Router Class Initialized
INFO - 2018-07-25 22:05:48 --> Output Class Initialized
INFO - 2018-07-25 22:05:48 --> Security Class Initialized
DEBUG - 2018-07-25 22:05:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 22:05:48 --> Input Class Initialized
INFO - 2018-07-25 22:05:48 --> Language Class Initialized
ERROR - 2018-07-25 22:05:48 --> 404 Page Not Found: /index
INFO - 2018-07-25 22:05:48 --> Config Class Initialized
INFO - 2018-07-25 22:05:48 --> Hooks Class Initialized
DEBUG - 2018-07-25 22:05:48 --> UTF-8 Support Enabled
INFO - 2018-07-25 22:05:48 --> Utf8 Class Initialized
INFO - 2018-07-25 22:05:48 --> URI Class Initialized
INFO - 2018-07-25 22:05:48 --> Router Class Initialized
INFO - 2018-07-25 22:05:48 --> Output Class Initialized
INFO - 2018-07-25 22:05:48 --> Security Class Initialized
DEBUG - 2018-07-25 22:05:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 22:05:48 --> Input Class Initialized
INFO - 2018-07-25 22:05:48 --> Language Class Initialized
ERROR - 2018-07-25 22:05:48 --> 404 Page Not Found: /index
INFO - 2018-07-25 22:05:49 --> Config Class Initialized
INFO - 2018-07-25 22:05:49 --> Hooks Class Initialized
DEBUG - 2018-07-25 22:05:49 --> UTF-8 Support Enabled
INFO - 2018-07-25 22:05:49 --> Utf8 Class Initialized
INFO - 2018-07-25 22:05:49 --> URI Class Initialized
INFO - 2018-07-25 22:05:49 --> Router Class Initialized
INFO - 2018-07-25 22:05:49 --> Output Class Initialized
INFO - 2018-07-25 22:05:49 --> Security Class Initialized
DEBUG - 2018-07-25 22:05:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 22:05:49 --> Input Class Initialized
INFO - 2018-07-25 22:05:49 --> Language Class Initialized
ERROR - 2018-07-25 22:05:49 --> 404 Page Not Found: /index
INFO - 2018-07-25 22:05:49 --> Config Class Initialized
INFO - 2018-07-25 22:05:49 --> Hooks Class Initialized
DEBUG - 2018-07-25 22:05:49 --> UTF-8 Support Enabled
INFO - 2018-07-25 22:05:49 --> Utf8 Class Initialized
INFO - 2018-07-25 22:05:49 --> URI Class Initialized
INFO - 2018-07-25 22:05:49 --> Router Class Initialized
INFO - 2018-07-25 22:05:49 --> Output Class Initialized
INFO - 2018-07-25 22:05:49 --> Security Class Initialized
DEBUG - 2018-07-25 22:05:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 22:05:49 --> Input Class Initialized
INFO - 2018-07-25 22:05:49 --> Language Class Initialized
ERROR - 2018-07-25 22:05:49 --> 404 Page Not Found: /index
INFO - 2018-07-25 22:05:49 --> Config Class Initialized
INFO - 2018-07-25 22:05:49 --> Hooks Class Initialized
DEBUG - 2018-07-25 22:05:49 --> UTF-8 Support Enabled
INFO - 2018-07-25 22:05:49 --> Utf8 Class Initialized
INFO - 2018-07-25 22:05:49 --> URI Class Initialized
INFO - 2018-07-25 22:05:49 --> Router Class Initialized
INFO - 2018-07-25 22:05:49 --> Output Class Initialized
INFO - 2018-07-25 22:05:49 --> Security Class Initialized
DEBUG - 2018-07-25 22:05:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 22:05:49 --> Input Class Initialized
INFO - 2018-07-25 22:05:49 --> Language Class Initialized
ERROR - 2018-07-25 22:05:49 --> 404 Page Not Found: /index
INFO - 2018-07-25 22:05:49 --> Config Class Initialized
INFO - 2018-07-25 22:05:49 --> Hooks Class Initialized
DEBUG - 2018-07-25 22:05:49 --> UTF-8 Support Enabled
INFO - 2018-07-25 22:05:49 --> Utf8 Class Initialized
INFO - 2018-07-25 22:05:49 --> URI Class Initialized
INFO - 2018-07-25 22:05:49 --> Router Class Initialized
INFO - 2018-07-25 22:05:49 --> Output Class Initialized
INFO - 2018-07-25 22:05:49 --> Security Class Initialized
DEBUG - 2018-07-25 22:05:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 22:05:49 --> Input Class Initialized
INFO - 2018-07-25 22:05:49 --> Language Class Initialized
ERROR - 2018-07-25 22:05:49 --> 404 Page Not Found: /index
INFO - 2018-07-25 22:05:53 --> Config Class Initialized
INFO - 2018-07-25 22:05:53 --> Hooks Class Initialized
DEBUG - 2018-07-25 22:05:53 --> UTF-8 Support Enabled
INFO - 2018-07-25 22:05:53 --> Utf8 Class Initialized
INFO - 2018-07-25 22:05:53 --> URI Class Initialized
INFO - 2018-07-25 22:05:53 --> Router Class Initialized
INFO - 2018-07-25 22:05:53 --> Output Class Initialized
INFO - 2018-07-25 22:05:53 --> Security Class Initialized
DEBUG - 2018-07-25 22:05:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 22:05:53 --> Input Class Initialized
INFO - 2018-07-25 22:05:53 --> Language Class Initialized
INFO - 2018-07-25 22:05:53 --> Language Class Initialized
INFO - 2018-07-25 22:05:53 --> Config Class Initialized
INFO - 2018-07-25 22:05:53 --> Loader Class Initialized
DEBUG - 2018-07-25 22:05:53 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-25 22:05:54 --> Helper loaded: url_helper
INFO - 2018-07-25 22:05:54 --> Helper loaded: form_helper
INFO - 2018-07-25 22:05:54 --> Helper loaded: date_helper
INFO - 2018-07-25 22:05:54 --> Helper loaded: util_helper
INFO - 2018-07-25 22:05:54 --> Helper loaded: text_helper
INFO - 2018-07-25 22:05:54 --> Helper loaded: string_helper
INFO - 2018-07-25 22:05:54 --> Database Driver Class Initialized
DEBUG - 2018-07-25 22:05:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 22:05:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 22:05:54 --> Email Class Initialized
INFO - 2018-07-25 22:05:54 --> Controller Class Initialized
DEBUG - 2018-07-25 22:05:54 --> Home MX_Controller Initialized
DEBUG - 2018-07-25 22:05:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-25 22:05:54 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-25 22:05:54 --> Login MX_Controller Initialized
INFO - 2018-07-25 22:05:54 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-25 22:05:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-25 22:05:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-25 22:05:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-07-25 22:05:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-07-25 22:05:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-07-25 22:05:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-07-25 22:05:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-07-25 22:05:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-07-25 22:05:54 --> Final output sent to browser
DEBUG - 2018-07-25 22:05:54 --> Total execution time: 0.8474
INFO - 2018-07-25 22:05:54 --> Config Class Initialized
INFO - 2018-07-25 22:05:54 --> Hooks Class Initialized
DEBUG - 2018-07-25 22:05:54 --> UTF-8 Support Enabled
INFO - 2018-07-25 22:05:54 --> Utf8 Class Initialized
INFO - 2018-07-25 22:05:54 --> URI Class Initialized
INFO - 2018-07-25 22:05:54 --> Router Class Initialized
INFO - 2018-07-25 22:05:55 --> Output Class Initialized
INFO - 2018-07-25 22:05:55 --> Security Class Initialized
DEBUG - 2018-07-25 22:05:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 22:05:55 --> Input Class Initialized
INFO - 2018-07-25 22:05:55 --> Language Class Initialized
ERROR - 2018-07-25 22:05:55 --> 404 Page Not Found: /index
INFO - 2018-07-25 22:05:55 --> Config Class Initialized
INFO - 2018-07-25 22:05:55 --> Hooks Class Initialized
DEBUG - 2018-07-25 22:05:55 --> UTF-8 Support Enabled
INFO - 2018-07-25 22:05:55 --> Utf8 Class Initialized
INFO - 2018-07-25 22:05:55 --> URI Class Initialized
INFO - 2018-07-25 22:05:55 --> Router Class Initialized
INFO - 2018-07-25 22:05:55 --> Output Class Initialized
INFO - 2018-07-25 22:05:55 --> Security Class Initialized
DEBUG - 2018-07-25 22:05:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 22:05:55 --> Input Class Initialized
INFO - 2018-07-25 22:05:55 --> Language Class Initialized
ERROR - 2018-07-25 22:05:55 --> 404 Page Not Found: /index
INFO - 2018-07-25 22:05:55 --> Config Class Initialized
INFO - 2018-07-25 22:05:55 --> Hooks Class Initialized
DEBUG - 2018-07-25 22:05:55 --> UTF-8 Support Enabled
INFO - 2018-07-25 22:05:55 --> Utf8 Class Initialized
INFO - 2018-07-25 22:05:55 --> URI Class Initialized
INFO - 2018-07-25 22:05:55 --> Router Class Initialized
INFO - 2018-07-25 22:05:55 --> Output Class Initialized
INFO - 2018-07-25 22:05:55 --> Security Class Initialized
DEBUG - 2018-07-25 22:05:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 22:05:55 --> Input Class Initialized
INFO - 2018-07-25 22:05:55 --> Language Class Initialized
ERROR - 2018-07-25 22:05:55 --> 404 Page Not Found: /index
INFO - 2018-07-25 22:05:57 --> Config Class Initialized
INFO - 2018-07-25 22:05:57 --> Hooks Class Initialized
DEBUG - 2018-07-25 22:05:57 --> UTF-8 Support Enabled
INFO - 2018-07-25 22:05:57 --> Utf8 Class Initialized
INFO - 2018-07-25 22:05:57 --> URI Class Initialized
INFO - 2018-07-25 22:05:57 --> Router Class Initialized
INFO - 2018-07-25 22:05:57 --> Output Class Initialized
INFO - 2018-07-25 22:05:57 --> Security Class Initialized
DEBUG - 2018-07-25 22:05:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 22:05:57 --> Input Class Initialized
INFO - 2018-07-25 22:05:57 --> Language Class Initialized
INFO - 2018-07-25 22:05:58 --> Language Class Initialized
INFO - 2018-07-25 22:05:58 --> Config Class Initialized
INFO - 2018-07-25 22:05:58 --> Loader Class Initialized
DEBUG - 2018-07-25 22:05:58 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-25 22:05:58 --> Helper loaded: url_helper
INFO - 2018-07-25 22:05:58 --> Helper loaded: form_helper
INFO - 2018-07-25 22:05:58 --> Helper loaded: date_helper
INFO - 2018-07-25 22:05:58 --> Helper loaded: util_helper
INFO - 2018-07-25 22:05:58 --> Helper loaded: text_helper
INFO - 2018-07-25 22:05:58 --> Helper loaded: string_helper
INFO - 2018-07-25 22:05:58 --> Database Driver Class Initialized
DEBUG - 2018-07-25 22:05:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 22:05:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 22:05:58 --> Email Class Initialized
INFO - 2018-07-25 22:05:58 --> Controller Class Initialized
DEBUG - 2018-07-25 22:05:58 --> Home MX_Controller Initialized
DEBUG - 2018-07-25 22:05:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-25 22:05:58 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-25 22:05:58 --> Login MX_Controller Initialized
INFO - 2018-07-25 22:05:58 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-25 22:05:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-25 22:05:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-25 22:05:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-07-25 22:05:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-07-25 22:05:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-07-25 22:05:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-07-25 22:05:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-07-25 22:05:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/progress.php
INFO - 2018-07-25 22:05:58 --> Final output sent to browser
DEBUG - 2018-07-25 22:05:58 --> Total execution time: 0.7532
INFO - 2018-07-25 22:05:58 --> Config Class Initialized
INFO - 2018-07-25 22:05:58 --> Hooks Class Initialized
DEBUG - 2018-07-25 22:05:58 --> UTF-8 Support Enabled
INFO - 2018-07-25 22:05:58 --> Utf8 Class Initialized
INFO - 2018-07-25 22:05:58 --> URI Class Initialized
INFO - 2018-07-25 22:05:58 --> Router Class Initialized
INFO - 2018-07-25 22:05:58 --> Output Class Initialized
INFO - 2018-07-25 22:05:58 --> Security Class Initialized
DEBUG - 2018-07-25 22:05:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 22:05:59 --> Input Class Initialized
INFO - 2018-07-25 22:05:59 --> Language Class Initialized
ERROR - 2018-07-25 22:05:59 --> 404 Page Not Found: /index
INFO - 2018-07-25 22:05:59 --> Config Class Initialized
INFO - 2018-07-25 22:05:59 --> Hooks Class Initialized
DEBUG - 2018-07-25 22:05:59 --> UTF-8 Support Enabled
INFO - 2018-07-25 22:05:59 --> Utf8 Class Initialized
INFO - 2018-07-25 22:05:59 --> URI Class Initialized
INFO - 2018-07-25 22:05:59 --> Router Class Initialized
INFO - 2018-07-25 22:05:59 --> Output Class Initialized
INFO - 2018-07-25 22:05:59 --> Security Class Initialized
DEBUG - 2018-07-25 22:05:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 22:05:59 --> Input Class Initialized
INFO - 2018-07-25 22:05:59 --> Language Class Initialized
ERROR - 2018-07-25 22:05:59 --> 404 Page Not Found: /index
INFO - 2018-07-25 22:05:59 --> Config Class Initialized
INFO - 2018-07-25 22:05:59 --> Hooks Class Initialized
DEBUG - 2018-07-25 22:05:59 --> UTF-8 Support Enabled
INFO - 2018-07-25 22:05:59 --> Utf8 Class Initialized
INFO - 2018-07-25 22:05:59 --> URI Class Initialized
INFO - 2018-07-25 22:05:59 --> Router Class Initialized
INFO - 2018-07-25 22:05:59 --> Output Class Initialized
INFO - 2018-07-25 22:05:59 --> Security Class Initialized
DEBUG - 2018-07-25 22:05:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 22:05:59 --> Input Class Initialized
INFO - 2018-07-25 22:05:59 --> Language Class Initialized
ERROR - 2018-07-25 22:05:59 --> 404 Page Not Found: /index
INFO - 2018-07-25 22:06:26 --> Config Class Initialized
INFO - 2018-07-25 22:06:26 --> Hooks Class Initialized
DEBUG - 2018-07-25 22:06:26 --> UTF-8 Support Enabled
INFO - 2018-07-25 22:06:26 --> Utf8 Class Initialized
INFO - 2018-07-25 22:06:26 --> URI Class Initialized
INFO - 2018-07-25 22:06:26 --> Router Class Initialized
INFO - 2018-07-25 22:06:26 --> Output Class Initialized
INFO - 2018-07-25 22:06:26 --> Security Class Initialized
DEBUG - 2018-07-25 22:06:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 22:06:26 --> Input Class Initialized
INFO - 2018-07-25 22:06:26 --> Language Class Initialized
INFO - 2018-07-25 22:06:26 --> Language Class Initialized
INFO - 2018-07-25 22:06:26 --> Config Class Initialized
INFO - 2018-07-25 22:06:26 --> Loader Class Initialized
DEBUG - 2018-07-25 22:06:26 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-25 22:06:26 --> Helper loaded: url_helper
INFO - 2018-07-25 22:06:26 --> Helper loaded: form_helper
INFO - 2018-07-25 22:06:26 --> Helper loaded: date_helper
INFO - 2018-07-25 22:06:26 --> Helper loaded: util_helper
INFO - 2018-07-25 22:06:26 --> Helper loaded: text_helper
INFO - 2018-07-25 22:06:26 --> Helper loaded: string_helper
INFO - 2018-07-25 22:06:26 --> Database Driver Class Initialized
DEBUG - 2018-07-25 22:06:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 22:06:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 22:06:26 --> Email Class Initialized
INFO - 2018-07-25 22:06:26 --> Controller Class Initialized
DEBUG - 2018-07-25 22:06:26 --> Home MX_Controller Initialized
DEBUG - 2018-07-25 22:06:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-25 22:06:26 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-25 22:06:26 --> Login MX_Controller Initialized
INFO - 2018-07-25 22:06:26 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-25 22:06:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-25 22:06:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-25 22:06:26 --> Config Class Initialized
INFO - 2018-07-25 22:06:26 --> Hooks Class Initialized
DEBUG - 2018-07-25 22:06:27 --> UTF-8 Support Enabled
INFO - 2018-07-25 22:06:27 --> Utf8 Class Initialized
INFO - 2018-07-25 22:06:27 --> URI Class Initialized
INFO - 2018-07-25 22:06:27 --> Router Class Initialized
INFO - 2018-07-25 22:06:27 --> Output Class Initialized
INFO - 2018-07-25 22:06:27 --> Security Class Initialized
DEBUG - 2018-07-25 22:06:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 22:06:27 --> Input Class Initialized
INFO - 2018-07-25 22:06:27 --> Language Class Initialized
INFO - 2018-07-25 22:06:27 --> Language Class Initialized
INFO - 2018-07-25 22:06:27 --> Config Class Initialized
INFO - 2018-07-25 22:06:27 --> Loader Class Initialized
DEBUG - 2018-07-25 22:06:27 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-25 22:06:27 --> Helper loaded: url_helper
INFO - 2018-07-25 22:06:27 --> Helper loaded: form_helper
INFO - 2018-07-25 22:06:27 --> Helper loaded: date_helper
INFO - 2018-07-25 22:06:27 --> Helper loaded: util_helper
INFO - 2018-07-25 22:06:27 --> Helper loaded: text_helper
INFO - 2018-07-25 22:06:27 --> Helper loaded: string_helper
INFO - 2018-07-25 22:06:27 --> Database Driver Class Initialized
DEBUG - 2018-07-25 22:06:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 22:06:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 22:06:27 --> Email Class Initialized
INFO - 2018-07-25 22:06:27 --> Controller Class Initialized
DEBUG - 2018-07-25 22:06:27 --> Home MX_Controller Initialized
DEBUG - 2018-07-25 22:06:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-25 22:06:27 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-25 22:06:27 --> Login MX_Controller Initialized
INFO - 2018-07-25 22:06:27 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-25 22:06:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-25 22:06:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-25 22:06:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-07-25 22:06:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-07-25 22:06:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-07-25 22:06:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-07-25 22:06:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-07-25 22:06:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-07-25 22:06:27 --> Final output sent to browser
DEBUG - 2018-07-25 22:06:27 --> Total execution time: 0.6941
INFO - 2018-07-25 22:06:28 --> Config Class Initialized
INFO - 2018-07-25 22:06:28 --> Hooks Class Initialized
DEBUG - 2018-07-25 22:06:28 --> UTF-8 Support Enabled
INFO - 2018-07-25 22:06:28 --> Utf8 Class Initialized
INFO - 2018-07-25 22:06:28 --> URI Class Initialized
INFO - 2018-07-25 22:06:28 --> Router Class Initialized
INFO - 2018-07-25 22:06:28 --> Output Class Initialized
INFO - 2018-07-25 22:06:28 --> Security Class Initialized
DEBUG - 2018-07-25 22:06:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 22:06:28 --> Input Class Initialized
INFO - 2018-07-25 22:06:28 --> Language Class Initialized
ERROR - 2018-07-25 22:06:28 --> 404 Page Not Found: /index
INFO - 2018-07-25 22:06:28 --> Config Class Initialized
INFO - 2018-07-25 22:06:28 --> Hooks Class Initialized
DEBUG - 2018-07-25 22:06:28 --> UTF-8 Support Enabled
INFO - 2018-07-25 22:06:28 --> Utf8 Class Initialized
INFO - 2018-07-25 22:06:28 --> URI Class Initialized
INFO - 2018-07-25 22:06:28 --> Router Class Initialized
INFO - 2018-07-25 22:06:28 --> Output Class Initialized
INFO - 2018-07-25 22:06:28 --> Security Class Initialized
DEBUG - 2018-07-25 22:06:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 22:06:28 --> Input Class Initialized
INFO - 2018-07-25 22:06:28 --> Language Class Initialized
ERROR - 2018-07-25 22:06:28 --> 404 Page Not Found: /index
INFO - 2018-07-25 22:06:28 --> Config Class Initialized
INFO - 2018-07-25 22:06:28 --> Hooks Class Initialized
DEBUG - 2018-07-25 22:06:28 --> UTF-8 Support Enabled
INFO - 2018-07-25 22:06:28 --> Utf8 Class Initialized
INFO - 2018-07-25 22:06:28 --> URI Class Initialized
INFO - 2018-07-25 22:06:28 --> Router Class Initialized
INFO - 2018-07-25 22:06:28 --> Output Class Initialized
INFO - 2018-07-25 22:06:28 --> Security Class Initialized
DEBUG - 2018-07-25 22:06:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 22:06:28 --> Input Class Initialized
INFO - 2018-07-25 22:06:28 --> Language Class Initialized
ERROR - 2018-07-25 22:06:28 --> 404 Page Not Found: /index
INFO - 2018-07-25 22:10:40 --> Config Class Initialized
INFO - 2018-07-25 22:10:40 --> Hooks Class Initialized
DEBUG - 2018-07-25 22:10:40 --> UTF-8 Support Enabled
INFO - 2018-07-25 22:10:40 --> Utf8 Class Initialized
INFO - 2018-07-25 22:10:40 --> URI Class Initialized
INFO - 2018-07-25 22:10:40 --> Router Class Initialized
INFO - 2018-07-25 22:10:40 --> Output Class Initialized
INFO - 2018-07-25 22:10:40 --> Security Class Initialized
DEBUG - 2018-07-25 22:10:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 22:10:40 --> Input Class Initialized
INFO - 2018-07-25 22:10:40 --> Language Class Initialized
INFO - 2018-07-25 22:10:40 --> Language Class Initialized
INFO - 2018-07-25 22:10:40 --> Config Class Initialized
INFO - 2018-07-25 22:10:40 --> Loader Class Initialized
DEBUG - 2018-07-25 22:10:40 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-25 22:10:40 --> Helper loaded: url_helper
INFO - 2018-07-25 22:10:40 --> Helper loaded: form_helper
INFO - 2018-07-25 22:10:40 --> Helper loaded: date_helper
INFO - 2018-07-25 22:10:40 --> Helper loaded: util_helper
INFO - 2018-07-25 22:10:40 --> Helper loaded: text_helper
INFO - 2018-07-25 22:10:40 --> Helper loaded: string_helper
INFO - 2018-07-25 22:10:40 --> Database Driver Class Initialized
DEBUG - 2018-07-25 22:10:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 22:10:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 22:10:40 --> Email Class Initialized
INFO - 2018-07-25 22:10:41 --> Controller Class Initialized
DEBUG - 2018-07-25 22:10:41 --> Users MX_Controller Initialized
DEBUG - 2018-07-25 22:10:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-25 22:10:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-07-25 22:10:41 --> Helper loaded: file_helper
DEBUG - 2018-07-25 22:10:41 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-25 22:10:41 --> Login MX_Controller Initialized
INFO - 2018-07-25 22:10:41 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-25 22:10:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-25 22:10:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-25 22:10:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-25 22:10:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-25 22:10:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-25 22:10:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-25 22:10:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/users.php
INFO - 2018-07-25 22:10:41 --> Final output sent to browser
DEBUG - 2018-07-25 22:10:41 --> Total execution time: 0.7238
INFO - 2018-07-25 22:10:41 --> Config Class Initialized
INFO - 2018-07-25 22:10:41 --> Hooks Class Initialized
DEBUG - 2018-07-25 22:10:41 --> UTF-8 Support Enabled
INFO - 2018-07-25 22:10:41 --> Utf8 Class Initialized
INFO - 2018-07-25 22:10:41 --> URI Class Initialized
INFO - 2018-07-25 22:10:41 --> Router Class Initialized
INFO - 2018-07-25 22:10:42 --> Output Class Initialized
INFO - 2018-07-25 22:10:42 --> Security Class Initialized
DEBUG - 2018-07-25 22:10:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 22:10:42 --> Input Class Initialized
INFO - 2018-07-25 22:10:42 --> Language Class Initialized
INFO - 2018-07-25 22:10:42 --> Language Class Initialized
INFO - 2018-07-25 22:10:42 --> Config Class Initialized
INFO - 2018-07-25 22:10:42 --> Loader Class Initialized
DEBUG - 2018-07-25 22:10:42 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-25 22:10:42 --> Helper loaded: url_helper
INFO - 2018-07-25 22:10:42 --> Helper loaded: form_helper
INFO - 2018-07-25 22:10:42 --> Helper loaded: date_helper
INFO - 2018-07-25 22:10:42 --> Helper loaded: util_helper
INFO - 2018-07-25 22:10:42 --> Helper loaded: text_helper
INFO - 2018-07-25 22:10:42 --> Helper loaded: string_helper
INFO - 2018-07-25 22:10:42 --> Database Driver Class Initialized
DEBUG - 2018-07-25 22:10:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 22:10:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 22:10:42 --> Email Class Initialized
INFO - 2018-07-25 22:10:42 --> Controller Class Initialized
DEBUG - 2018-07-25 22:10:42 --> Users MX_Controller Initialized
DEBUG - 2018-07-25 22:10:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-25 22:10:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-07-25 22:10:42 --> Helper loaded: file_helper
DEBUG - 2018-07-25 22:10:42 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-25 22:10:42 --> Login MX_Controller Initialized
INFO - 2018-07-25 22:10:42 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-25 22:10:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-25 22:10:42 --> Final output sent to browser
DEBUG - 2018-07-25 22:10:42 --> Total execution time: 0.7464
INFO - 2018-07-25 22:43:47 --> Config Class Initialized
INFO - 2018-07-25 22:43:48 --> Hooks Class Initialized
DEBUG - 2018-07-25 22:43:48 --> UTF-8 Support Enabled
INFO - 2018-07-25 22:43:48 --> Utf8 Class Initialized
INFO - 2018-07-25 22:43:48 --> URI Class Initialized
INFO - 2018-07-25 22:43:48 --> Router Class Initialized
INFO - 2018-07-25 22:43:48 --> Output Class Initialized
INFO - 2018-07-25 22:43:48 --> Security Class Initialized
DEBUG - 2018-07-25 22:43:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 22:43:48 --> Input Class Initialized
INFO - 2018-07-25 22:43:48 --> Language Class Initialized
INFO - 2018-07-25 22:43:48 --> Language Class Initialized
INFO - 2018-07-25 22:43:48 --> Config Class Initialized
INFO - 2018-07-25 22:43:48 --> Loader Class Initialized
DEBUG - 2018-07-25 22:43:48 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-25 22:43:48 --> Helper loaded: url_helper
INFO - 2018-07-25 22:43:48 --> Helper loaded: form_helper
INFO - 2018-07-25 22:43:48 --> Helper loaded: date_helper
INFO - 2018-07-25 22:43:48 --> Helper loaded: util_helper
INFO - 2018-07-25 22:43:48 --> Helper loaded: text_helper
INFO - 2018-07-25 22:43:49 --> Helper loaded: string_helper
INFO - 2018-07-25 22:43:49 --> Database Driver Class Initialized
DEBUG - 2018-07-25 22:43:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 22:43:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 22:43:49 --> Email Class Initialized
INFO - 2018-07-25 22:43:49 --> Controller Class Initialized
DEBUG - 2018-07-25 22:43:49 --> Users MX_Controller Initialized
DEBUG - 2018-07-25 22:43:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-25 22:43:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-07-25 22:43:49 --> Helper loaded: file_helper
DEBUG - 2018-07-25 22:43:49 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-25 22:43:49 --> Login MX_Controller Initialized
INFO - 2018-07-25 22:43:49 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-25 22:43:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-25 22:43:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-25 22:43:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-25 22:43:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-25 22:43:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-25 22:43:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-25 22:43:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/users.php
INFO - 2018-07-25 22:43:49 --> Final output sent to browser
DEBUG - 2018-07-25 22:43:49 --> Total execution time: 1.7551
INFO - 2018-07-25 22:43:50 --> Config Class Initialized
INFO - 2018-07-25 22:43:50 --> Hooks Class Initialized
DEBUG - 2018-07-25 22:43:50 --> UTF-8 Support Enabled
INFO - 2018-07-25 22:43:50 --> Utf8 Class Initialized
INFO - 2018-07-25 22:43:50 --> URI Class Initialized
INFO - 2018-07-25 22:43:50 --> Router Class Initialized
INFO - 2018-07-25 22:43:51 --> Output Class Initialized
INFO - 2018-07-25 22:43:51 --> Security Class Initialized
DEBUG - 2018-07-25 22:43:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 22:43:51 --> Input Class Initialized
INFO - 2018-07-25 22:43:51 --> Language Class Initialized
INFO - 2018-07-25 22:43:51 --> Language Class Initialized
INFO - 2018-07-25 22:43:51 --> Config Class Initialized
INFO - 2018-07-25 22:43:51 --> Loader Class Initialized
DEBUG - 2018-07-25 22:43:51 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-25 22:43:51 --> Helper loaded: url_helper
INFO - 2018-07-25 22:43:51 --> Helper loaded: form_helper
INFO - 2018-07-25 22:43:51 --> Helper loaded: date_helper
INFO - 2018-07-25 22:43:51 --> Helper loaded: util_helper
INFO - 2018-07-25 22:43:51 --> Helper loaded: text_helper
INFO - 2018-07-25 22:43:51 --> Helper loaded: string_helper
INFO - 2018-07-25 22:43:51 --> Database Driver Class Initialized
DEBUG - 2018-07-25 22:43:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 22:43:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 22:43:51 --> Email Class Initialized
INFO - 2018-07-25 22:43:51 --> Controller Class Initialized
DEBUG - 2018-07-25 22:43:51 --> Users MX_Controller Initialized
DEBUG - 2018-07-25 22:43:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-25 22:43:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-07-25 22:43:51 --> Helper loaded: file_helper
DEBUG - 2018-07-25 22:43:51 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-25 22:43:51 --> Login MX_Controller Initialized
INFO - 2018-07-25 22:43:51 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-25 22:43:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-25 22:43:51 --> Final output sent to browser
DEBUG - 2018-07-25 22:43:51 --> Total execution time: 0.8316
INFO - 2018-07-25 22:57:46 --> Config Class Initialized
INFO - 2018-07-25 22:57:46 --> Hooks Class Initialized
DEBUG - 2018-07-25 22:57:46 --> UTF-8 Support Enabled
INFO - 2018-07-25 22:57:46 --> Utf8 Class Initialized
INFO - 2018-07-25 22:57:46 --> URI Class Initialized
INFO - 2018-07-25 22:57:46 --> Router Class Initialized
INFO - 2018-07-25 22:57:46 --> Output Class Initialized
INFO - 2018-07-25 22:57:46 --> Security Class Initialized
DEBUG - 2018-07-25 22:57:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 22:57:46 --> Input Class Initialized
INFO - 2018-07-25 22:57:46 --> Language Class Initialized
INFO - 2018-07-25 22:57:46 --> Language Class Initialized
INFO - 2018-07-25 22:57:46 --> Config Class Initialized
INFO - 2018-07-25 22:57:46 --> Loader Class Initialized
DEBUG - 2018-07-25 22:57:46 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-25 22:57:46 --> Helper loaded: url_helper
INFO - 2018-07-25 22:57:46 --> Helper loaded: form_helper
INFO - 2018-07-25 22:57:46 --> Helper loaded: date_helper
INFO - 2018-07-25 22:57:46 --> Helper loaded: util_helper
INFO - 2018-07-25 22:57:46 --> Helper loaded: text_helper
INFO - 2018-07-25 22:57:46 --> Helper loaded: string_helper
INFO - 2018-07-25 22:57:47 --> Database Driver Class Initialized
DEBUG - 2018-07-25 22:57:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 22:57:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 22:57:47 --> Email Class Initialized
INFO - 2018-07-25 22:57:47 --> Controller Class Initialized
DEBUG - 2018-07-25 22:57:47 --> Users MX_Controller Initialized
DEBUG - 2018-07-25 22:57:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-25 22:57:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-07-25 22:57:47 --> Helper loaded: file_helper
DEBUG - 2018-07-25 22:57:47 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-25 22:57:47 --> Login MX_Controller Initialized
INFO - 2018-07-25 22:57:47 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-25 22:57:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
ERROR - 2018-07-25 22:57:47 --> Severity: Notice --> Undefined offset: 8 E:\xampp\htdocs\consulting\application\modules\admin\controllers\Users.php 79
ERROR - 2018-07-25 22:57:47 --> Severity: Notice --> Undefined offset: 8 E:\xampp\htdocs\consulting\application\modules\admin\controllers\Users.php 82
ERROR - 2018-07-25 22:57:47 --> Severity: Notice --> Undefined offset: 8 E:\xampp\htdocs\consulting\application\modules\admin\controllers\Users.php 79
ERROR - 2018-07-25 22:57:47 --> Severity: Notice --> Undefined offset: 8 E:\xampp\htdocs\consulting\application\modules\admin\controllers\Users.php 82
ERROR - 2018-07-25 22:57:47 --> Severity: Notice --> Undefined offset: 8 E:\xampp\htdocs\consulting\application\modules\admin\controllers\Users.php 79
ERROR - 2018-07-25 22:57:47 --> Severity: Notice --> Undefined offset: 8 E:\xampp\htdocs\consulting\application\modules\admin\controllers\Users.php 82
ERROR - 2018-07-25 22:57:47 --> Severity: Notice --> Undefined offset: 8 E:\xampp\htdocs\consulting\application\modules\admin\controllers\Users.php 79
ERROR - 2018-07-25 22:57:47 --> Severity: Notice --> Undefined offset: 8 E:\xampp\htdocs\consulting\application\modules\admin\controllers\Users.php 82
ERROR - 2018-07-25 22:57:47 --> Severity: Notice --> Undefined offset: 8 E:\xampp\htdocs\consulting\application\modules\admin\controllers\Users.php 79
ERROR - 2018-07-25 22:57:47 --> Severity: Notice --> Undefined offset: 8 E:\xampp\htdocs\consulting\application\modules\admin\controllers\Users.php 82
ERROR - 2018-07-25 22:57:47 --> Severity: Notice --> Undefined offset: 8 E:\xampp\htdocs\consulting\application\modules\admin\controllers\Users.php 79
ERROR - 2018-07-25 22:57:47 --> Severity: Notice --> Undefined offset: 8 E:\xampp\htdocs\consulting\application\modules\admin\controllers\Users.php 82
INFO - 2018-07-25 22:57:51 --> Config Class Initialized
INFO - 2018-07-25 22:57:51 --> Hooks Class Initialized
DEBUG - 2018-07-25 22:57:51 --> UTF-8 Support Enabled
INFO - 2018-07-25 22:57:51 --> Utf8 Class Initialized
INFO - 2018-07-25 22:57:51 --> URI Class Initialized
INFO - 2018-07-25 22:57:51 --> Router Class Initialized
INFO - 2018-07-25 22:57:51 --> Output Class Initialized
INFO - 2018-07-25 22:57:51 --> Security Class Initialized
DEBUG - 2018-07-25 22:57:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 22:57:51 --> Input Class Initialized
INFO - 2018-07-25 22:57:51 --> Language Class Initialized
INFO - 2018-07-25 22:57:51 --> Language Class Initialized
INFO - 2018-07-25 22:57:51 --> Config Class Initialized
INFO - 2018-07-25 22:57:51 --> Loader Class Initialized
DEBUG - 2018-07-25 22:57:52 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-25 22:57:52 --> Helper loaded: url_helper
INFO - 2018-07-25 22:57:52 --> Helper loaded: form_helper
INFO - 2018-07-25 22:57:52 --> Helper loaded: date_helper
INFO - 2018-07-25 22:57:52 --> Helper loaded: util_helper
INFO - 2018-07-25 22:57:52 --> Helper loaded: text_helper
INFO - 2018-07-25 22:57:52 --> Helper loaded: string_helper
INFO - 2018-07-25 22:57:52 --> Database Driver Class Initialized
DEBUG - 2018-07-25 22:57:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 22:57:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 22:57:52 --> Email Class Initialized
INFO - 2018-07-25 22:57:52 --> Controller Class Initialized
DEBUG - 2018-07-25 22:57:52 --> Users MX_Controller Initialized
DEBUG - 2018-07-25 22:57:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-25 22:57:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-07-25 22:57:52 --> Helper loaded: file_helper
DEBUG - 2018-07-25 22:57:52 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-25 22:57:52 --> Login MX_Controller Initialized
INFO - 2018-07-25 22:57:52 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-25 22:57:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
ERROR - 2018-07-25 22:57:52 --> Severity: Notice --> Undefined index: sEcho E:\xampp\htdocs\consulting\system\database\DB_query_builder.php 2920
ERROR - 2018-07-25 22:57:52 --> Severity: Notice --> Undefined offset: 8 E:\xampp\htdocs\consulting\application\modules\admin\controllers\Users.php 79
ERROR - 2018-07-25 22:57:52 --> Severity: Notice --> Undefined offset: 8 E:\xampp\htdocs\consulting\application\modules\admin\controllers\Users.php 82
ERROR - 2018-07-25 22:57:52 --> Severity: Notice --> Undefined offset: 8 E:\xampp\htdocs\consulting\application\modules\admin\controllers\Users.php 79
ERROR - 2018-07-25 22:57:52 --> Severity: Notice --> Undefined offset: 8 E:\xampp\htdocs\consulting\application\modules\admin\controllers\Users.php 82
ERROR - 2018-07-25 22:57:52 --> Severity: Notice --> Undefined offset: 8 E:\xampp\htdocs\consulting\application\modules\admin\controllers\Users.php 79
ERROR - 2018-07-25 22:57:52 --> Severity: Notice --> Undefined offset: 8 E:\xampp\htdocs\consulting\application\modules\admin\controllers\Users.php 82
ERROR - 2018-07-25 22:57:52 --> Severity: Notice --> Undefined offset: 8 E:\xampp\htdocs\consulting\application\modules\admin\controllers\Users.php 79
ERROR - 2018-07-25 22:57:52 --> Severity: Notice --> Undefined offset: 8 E:\xampp\htdocs\consulting\application\modules\admin\controllers\Users.php 82
ERROR - 2018-07-25 22:57:52 --> Severity: Notice --> Undefined offset: 8 E:\xampp\htdocs\consulting\application\modules\admin\controllers\Users.php 79
ERROR - 2018-07-25 22:57:52 --> Severity: Notice --> Undefined offset: 8 E:\xampp\htdocs\consulting\application\modules\admin\controllers\Users.php 82
ERROR - 2018-07-25 22:57:52 --> Severity: Notice --> Undefined offset: 8 E:\xampp\htdocs\consulting\application\modules\admin\controllers\Users.php 79
ERROR - 2018-07-25 22:57:52 --> Severity: Notice --> Undefined offset: 8 E:\xampp\htdocs\consulting\application\modules\admin\controllers\Users.php 82
INFO - 2018-07-25 22:58:05 --> Config Class Initialized
INFO - 2018-07-25 22:58:05 --> Hooks Class Initialized
DEBUG - 2018-07-25 22:58:05 --> UTF-8 Support Enabled
INFO - 2018-07-25 22:58:05 --> Utf8 Class Initialized
INFO - 2018-07-25 22:58:05 --> URI Class Initialized
INFO - 2018-07-25 22:58:05 --> Router Class Initialized
INFO - 2018-07-25 22:58:05 --> Output Class Initialized
INFO - 2018-07-25 22:58:05 --> Security Class Initialized
DEBUG - 2018-07-25 22:58:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 22:58:05 --> Input Class Initialized
INFO - 2018-07-25 22:58:05 --> Language Class Initialized
INFO - 2018-07-25 22:58:05 --> Language Class Initialized
INFO - 2018-07-25 22:58:05 --> Config Class Initialized
INFO - 2018-07-25 22:58:05 --> Loader Class Initialized
DEBUG - 2018-07-25 22:58:05 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-25 22:58:05 --> Helper loaded: url_helper
INFO - 2018-07-25 22:58:05 --> Helper loaded: form_helper
INFO - 2018-07-25 22:58:05 --> Helper loaded: date_helper
INFO - 2018-07-25 22:58:05 --> Helper loaded: util_helper
INFO - 2018-07-25 22:58:05 --> Helper loaded: text_helper
INFO - 2018-07-25 22:58:05 --> Helper loaded: string_helper
INFO - 2018-07-25 22:58:05 --> Database Driver Class Initialized
DEBUG - 2018-07-25 22:58:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 22:58:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 22:58:06 --> Email Class Initialized
INFO - 2018-07-25 22:58:06 --> Controller Class Initialized
DEBUG - 2018-07-25 22:58:06 --> Users MX_Controller Initialized
DEBUG - 2018-07-25 22:58:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-25 22:58:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-07-25 22:58:06 --> Helper loaded: file_helper
DEBUG - 2018-07-25 22:58:06 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-25 22:58:06 --> Login MX_Controller Initialized
INFO - 2018-07-25 22:58:06 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-25 22:58:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
ERROR - 2018-07-25 22:58:06 --> Severity: Notice --> Undefined index: sEcho E:\xampp\htdocs\consulting\system\database\DB_query_builder.php 2920
INFO - 2018-07-25 22:58:29 --> Config Class Initialized
INFO - 2018-07-25 22:58:29 --> Hooks Class Initialized
DEBUG - 2018-07-25 22:58:29 --> UTF-8 Support Enabled
INFO - 2018-07-25 22:58:29 --> Utf8 Class Initialized
INFO - 2018-07-25 22:58:29 --> URI Class Initialized
INFO - 2018-07-25 22:58:29 --> Router Class Initialized
INFO - 2018-07-25 22:58:29 --> Output Class Initialized
INFO - 2018-07-25 22:58:29 --> Security Class Initialized
DEBUG - 2018-07-25 22:58:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 22:58:29 --> Input Class Initialized
INFO - 2018-07-25 22:58:29 --> Language Class Initialized
ERROR - 2018-07-25 22:58:29 --> Severity: error --> Exception: syntax error, unexpected '=' E:\xampp\htdocs\consulting\application\modules\admin\controllers\Users.php 79
INFO - 2018-07-25 22:58:35 --> Config Class Initialized
INFO - 2018-07-25 22:58:35 --> Hooks Class Initialized
DEBUG - 2018-07-25 22:58:35 --> UTF-8 Support Enabled
INFO - 2018-07-25 22:58:35 --> Utf8 Class Initialized
INFO - 2018-07-25 22:58:35 --> URI Class Initialized
INFO - 2018-07-25 22:58:35 --> Router Class Initialized
INFO - 2018-07-25 22:58:35 --> Output Class Initialized
INFO - 2018-07-25 22:58:35 --> Security Class Initialized
DEBUG - 2018-07-25 22:58:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-25 22:58:35 --> Input Class Initialized
INFO - 2018-07-25 22:58:35 --> Language Class Initialized
INFO - 2018-07-25 22:58:35 --> Language Class Initialized
INFO - 2018-07-25 22:58:35 --> Config Class Initialized
INFO - 2018-07-25 22:58:35 --> Loader Class Initialized
DEBUG - 2018-07-25 22:58:35 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-25 22:58:35 --> Helper loaded: url_helper
INFO - 2018-07-25 22:58:35 --> Helper loaded: form_helper
INFO - 2018-07-25 22:58:35 --> Helper loaded: date_helper
INFO - 2018-07-25 22:58:35 --> Helper loaded: util_helper
INFO - 2018-07-25 22:58:35 --> Helper loaded: text_helper
INFO - 2018-07-25 22:58:35 --> Helper loaded: string_helper
INFO - 2018-07-25 22:58:35 --> Database Driver Class Initialized
DEBUG - 2018-07-25 22:58:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-25 22:58:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-25 22:58:35 --> Email Class Initialized
INFO - 2018-07-25 22:58:35 --> Controller Class Initialized
DEBUG - 2018-07-25 22:58:35 --> Users MX_Controller Initialized
DEBUG - 2018-07-25 22:58:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-25 22:58:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-07-25 22:58:35 --> Helper loaded: file_helper
DEBUG - 2018-07-25 22:58:35 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-25 22:58:35 --> Login MX_Controller Initialized
INFO - 2018-07-25 22:58:35 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-25 22:58:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
ERROR - 2018-07-25 22:58:35 --> Severity: Notice --> Undefined index: sEcho E:\xampp\htdocs\consulting\system\database\DB_query_builder.php 2920
