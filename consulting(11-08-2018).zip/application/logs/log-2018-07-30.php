<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-07-30 21:26:55 --> Config Class Initialized
INFO - 2018-07-30 21:26:55 --> Hooks Class Initialized
DEBUG - 2018-07-30 21:26:55 --> UTF-8 Support Enabled
INFO - 2018-07-30 21:26:55 --> Utf8 Class Initialized
INFO - 2018-07-30 21:26:55 --> URI Class Initialized
INFO - 2018-07-30 21:26:56 --> Router Class Initialized
INFO - 2018-07-30 21:26:56 --> Output Class Initialized
INFO - 2018-07-30 21:26:56 --> Security Class Initialized
DEBUG - 2018-07-30 21:26:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 21:26:56 --> Input Class Initialized
INFO - 2018-07-30 21:26:56 --> Language Class Initialized
INFO - 2018-07-30 21:26:56 --> Language Class Initialized
INFO - 2018-07-30 21:26:56 --> Config Class Initialized
INFO - 2018-07-30 21:26:56 --> Loader Class Initialized
DEBUG - 2018-07-30 21:26:56 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-30 21:26:56 --> Helper loaded: url_helper
INFO - 2018-07-30 21:26:56 --> Helper loaded: form_helper
INFO - 2018-07-30 21:26:56 --> Helper loaded: date_helper
INFO - 2018-07-30 21:26:56 --> Helper loaded: util_helper
INFO - 2018-07-30 21:26:56 --> Helper loaded: text_helper
INFO - 2018-07-30 21:26:56 --> Helper loaded: string_helper
INFO - 2018-07-30 21:26:56 --> Database Driver Class Initialized
ERROR - 2018-07-30 21:26:58 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 E:\xampp\htdocs\consulting\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2018-07-30 21:26:58 --> Unable to connect to the database
INFO - 2018-07-30 21:26:58 --> Language file loaded: language/english/db_lang.php
INFO - 2018-07-30 21:27:01 --> Config Class Initialized
INFO - 2018-07-30 21:27:01 --> Hooks Class Initialized
DEBUG - 2018-07-30 21:27:01 --> UTF-8 Support Enabled
INFO - 2018-07-30 21:27:01 --> Utf8 Class Initialized
INFO - 2018-07-30 21:27:01 --> URI Class Initialized
INFO - 2018-07-30 21:27:01 --> Router Class Initialized
INFO - 2018-07-30 21:27:01 --> Output Class Initialized
INFO - 2018-07-30 21:27:01 --> Security Class Initialized
DEBUG - 2018-07-30 21:27:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 21:27:01 --> Input Class Initialized
INFO - 2018-07-30 21:27:01 --> Language Class Initialized
INFO - 2018-07-30 21:27:01 --> Language Class Initialized
INFO - 2018-07-30 21:27:01 --> Config Class Initialized
INFO - 2018-07-30 21:27:01 --> Loader Class Initialized
DEBUG - 2018-07-30 21:27:01 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-30 21:27:01 --> Helper loaded: url_helper
INFO - 2018-07-30 21:27:01 --> Helper loaded: form_helper
INFO - 2018-07-30 21:27:01 --> Helper loaded: date_helper
INFO - 2018-07-30 21:27:01 --> Helper loaded: util_helper
INFO - 2018-07-30 21:27:01 --> Helper loaded: text_helper
INFO - 2018-07-30 21:27:01 --> Helper loaded: string_helper
INFO - 2018-07-30 21:27:01 --> Database Driver Class Initialized
DEBUG - 2018-07-30 21:27:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 21:27:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 21:27:02 --> Email Class Initialized
INFO - 2018-07-30 21:27:02 --> Controller Class Initialized
DEBUG - 2018-07-30 21:27:02 --> Home MX_Controller Initialized
INFO - 2018-07-30 21:27:02 --> Config Class Initialized
INFO - 2018-07-30 21:27:02 --> Hooks Class Initialized
DEBUG - 2018-07-30 21:27:02 --> UTF-8 Support Enabled
INFO - 2018-07-30 21:27:02 --> Utf8 Class Initialized
DEBUG - 2018-07-30 21:27:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-07-30 21:27:02 --> URI Class Initialized
INFO - 2018-07-30 21:27:02 --> Router Class Initialized
INFO - 2018-07-30 21:27:02 --> Output Class Initialized
INFO - 2018-07-30 21:27:02 --> Security Class Initialized
DEBUG - 2018-07-30 21:27:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 21:27:02 --> Input Class Initialized
INFO - 2018-07-30 21:27:02 --> Language Class Initialized
DEBUG - 2018-07-30 21:27:02 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-30 21:27:02 --> Login MX_Controller Initialized
ERROR - 2018-07-30 21:27:02 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC) E:\xampp\htdocs\consulting\application\modules\admin\controllers\Programs.php 236
INFO - 2018-07-30 21:27:02 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-30 21:27:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-30 21:27:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-30 21:27:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/login.php
INFO - 2018-07-30 21:27:06 --> Config Class Initialized
INFO - 2018-07-30 21:27:06 --> Hooks Class Initialized
DEBUG - 2018-07-30 21:27:06 --> UTF-8 Support Enabled
INFO - 2018-07-30 21:27:06 --> Utf8 Class Initialized
INFO - 2018-07-30 21:27:06 --> URI Class Initialized
INFO - 2018-07-30 21:27:06 --> Router Class Initialized
INFO - 2018-07-30 21:27:06 --> Output Class Initialized
INFO - 2018-07-30 21:27:06 --> Security Class Initialized
DEBUG - 2018-07-30 21:27:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 21:27:06 --> Input Class Initialized
INFO - 2018-07-30 21:27:06 --> Language Class Initialized
ERROR - 2018-07-30 21:27:06 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC) E:\xampp\htdocs\consulting\application\modules\admin\controllers\Programs.php 236
INFO - 2018-07-30 21:27:07 --> Config Class Initialized
INFO - 2018-07-30 21:27:07 --> Hooks Class Initialized
DEBUG - 2018-07-30 21:27:07 --> UTF-8 Support Enabled
INFO - 2018-07-30 21:27:07 --> Utf8 Class Initialized
INFO - 2018-07-30 21:27:07 --> URI Class Initialized
INFO - 2018-07-30 21:27:07 --> Router Class Initialized
INFO - 2018-07-30 21:27:07 --> Output Class Initialized
INFO - 2018-07-30 21:27:07 --> Security Class Initialized
DEBUG - 2018-07-30 21:27:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 21:27:07 --> Input Class Initialized
INFO - 2018-07-30 21:27:07 --> Language Class Initialized
ERROR - 2018-07-30 21:27:07 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC) E:\xampp\htdocs\consulting\application\modules\admin\controllers\Programs.php 236
INFO - 2018-07-30 21:27:08 --> Config Class Initialized
INFO - 2018-07-30 21:27:08 --> Hooks Class Initialized
DEBUG - 2018-07-30 21:27:08 --> UTF-8 Support Enabled
INFO - 2018-07-30 21:27:08 --> Utf8 Class Initialized
INFO - 2018-07-30 21:27:08 --> URI Class Initialized
INFO - 2018-07-30 21:27:08 --> Router Class Initialized
INFO - 2018-07-30 21:27:08 --> Output Class Initialized
INFO - 2018-07-30 21:27:08 --> Security Class Initialized
DEBUG - 2018-07-30 21:27:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 21:27:08 --> Input Class Initialized
INFO - 2018-07-30 21:27:08 --> Language Class Initialized
ERROR - 2018-07-30 21:27:08 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC) E:\xampp\htdocs\consulting\application\modules\admin\controllers\Programs.php 236
INFO - 2018-07-30 21:27:08 --> Config Class Initialized
INFO - 2018-07-30 21:27:08 --> Hooks Class Initialized
DEBUG - 2018-07-30 21:27:08 --> UTF-8 Support Enabled
INFO - 2018-07-30 21:27:08 --> Utf8 Class Initialized
INFO - 2018-07-30 21:27:08 --> URI Class Initialized
INFO - 2018-07-30 21:27:08 --> Router Class Initialized
INFO - 2018-07-30 21:27:08 --> Output Class Initialized
INFO - 2018-07-30 21:27:08 --> Security Class Initialized
DEBUG - 2018-07-30 21:27:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 21:27:08 --> Input Class Initialized
INFO - 2018-07-30 21:27:08 --> Language Class Initialized
ERROR - 2018-07-30 21:27:08 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC) E:\xampp\htdocs\consulting\application\modules\admin\controllers\Programs.php 236
INFO - 2018-07-30 21:27:08 --> Config Class Initialized
INFO - 2018-07-30 21:27:08 --> Hooks Class Initialized
DEBUG - 2018-07-30 21:27:08 --> UTF-8 Support Enabled
INFO - 2018-07-30 21:27:08 --> Utf8 Class Initialized
INFO - 2018-07-30 21:27:09 --> URI Class Initialized
INFO - 2018-07-30 21:27:09 --> Router Class Initialized
INFO - 2018-07-30 21:27:09 --> Output Class Initialized
INFO - 2018-07-30 21:27:09 --> Security Class Initialized
DEBUG - 2018-07-30 21:27:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 21:27:09 --> Input Class Initialized
INFO - 2018-07-30 21:27:09 --> Language Class Initialized
ERROR - 2018-07-30 21:27:09 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC) E:\xampp\htdocs\consulting\application\modules\admin\controllers\Programs.php 236
INFO - 2018-07-30 21:27:09 --> Config Class Initialized
INFO - 2018-07-30 21:27:09 --> Hooks Class Initialized
DEBUG - 2018-07-30 21:27:09 --> UTF-8 Support Enabled
INFO - 2018-07-30 21:27:09 --> Utf8 Class Initialized
INFO - 2018-07-30 21:27:09 --> URI Class Initialized
INFO - 2018-07-30 21:27:09 --> Router Class Initialized
INFO - 2018-07-30 21:27:09 --> Output Class Initialized
INFO - 2018-07-30 21:27:09 --> Security Class Initialized
DEBUG - 2018-07-30 21:27:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 21:27:09 --> Input Class Initialized
INFO - 2018-07-30 21:27:09 --> Language Class Initialized
ERROR - 2018-07-30 21:27:09 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC) E:\xampp\htdocs\consulting\application\modules\admin\controllers\Programs.php 236
INFO - 2018-07-30 21:27:09 --> Config Class Initialized
INFO - 2018-07-30 21:27:09 --> Hooks Class Initialized
DEBUG - 2018-07-30 21:27:09 --> UTF-8 Support Enabled
INFO - 2018-07-30 21:27:09 --> Utf8 Class Initialized
INFO - 2018-07-30 21:27:09 --> URI Class Initialized
INFO - 2018-07-30 21:27:09 --> Router Class Initialized
INFO - 2018-07-30 21:27:09 --> Output Class Initialized
INFO - 2018-07-30 21:27:09 --> Security Class Initialized
DEBUG - 2018-07-30 21:27:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 21:27:09 --> Input Class Initialized
INFO - 2018-07-30 21:27:09 --> Language Class Initialized
ERROR - 2018-07-30 21:27:09 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC) E:\xampp\htdocs\consulting\application\modules\admin\controllers\Programs.php 236
INFO - 2018-07-30 21:27:09 --> Config Class Initialized
INFO - 2018-07-30 21:27:09 --> Hooks Class Initialized
DEBUG - 2018-07-30 21:27:09 --> UTF-8 Support Enabled
INFO - 2018-07-30 21:27:09 --> Utf8 Class Initialized
INFO - 2018-07-30 21:27:09 --> URI Class Initialized
INFO - 2018-07-30 21:27:10 --> Router Class Initialized
INFO - 2018-07-30 21:27:10 --> Output Class Initialized
INFO - 2018-07-30 21:27:10 --> Security Class Initialized
DEBUG - 2018-07-30 21:27:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 21:27:10 --> Input Class Initialized
INFO - 2018-07-30 21:27:10 --> Language Class Initialized
ERROR - 2018-07-30 21:27:10 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC) E:\xampp\htdocs\consulting\application\modules\admin\controllers\Programs.php 236
INFO - 2018-07-30 21:27:18 --> Config Class Initialized
INFO - 2018-07-30 21:27:18 --> Hooks Class Initialized
DEBUG - 2018-07-30 21:27:18 --> UTF-8 Support Enabled
INFO - 2018-07-30 21:27:18 --> Utf8 Class Initialized
INFO - 2018-07-30 21:27:18 --> URI Class Initialized
INFO - 2018-07-30 21:27:18 --> Router Class Initialized
INFO - 2018-07-30 21:27:18 --> Output Class Initialized
INFO - 2018-07-30 21:27:18 --> Security Class Initialized
DEBUG - 2018-07-30 21:27:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 21:27:18 --> Input Class Initialized
INFO - 2018-07-30 21:27:18 --> Language Class Initialized
ERROR - 2018-07-30 21:27:18 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC) E:\xampp\htdocs\consulting\application\modules\admin\controllers\Programs.php 236
INFO - 2018-07-30 21:27:21 --> Config Class Initialized
INFO - 2018-07-30 21:27:21 --> Hooks Class Initialized
DEBUG - 2018-07-30 21:27:21 --> UTF-8 Support Enabled
INFO - 2018-07-30 21:27:21 --> Utf8 Class Initialized
INFO - 2018-07-30 21:27:21 --> URI Class Initialized
INFO - 2018-07-30 21:27:21 --> Router Class Initialized
INFO - 2018-07-30 21:27:21 --> Output Class Initialized
INFO - 2018-07-30 21:27:21 --> Security Class Initialized
DEBUG - 2018-07-30 21:27:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 21:27:21 --> Input Class Initialized
INFO - 2018-07-30 21:27:21 --> Language Class Initialized
ERROR - 2018-07-30 21:27:21 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC) E:\xampp\htdocs\consulting\application\modules\admin\controllers\Programs.php 236
INFO - 2018-07-30 21:27:23 --> Config Class Initialized
INFO - 2018-07-30 21:27:23 --> Hooks Class Initialized
DEBUG - 2018-07-30 21:27:23 --> UTF-8 Support Enabled
INFO - 2018-07-30 21:27:23 --> Utf8 Class Initialized
INFO - 2018-07-30 21:27:23 --> URI Class Initialized
INFO - 2018-07-30 21:27:23 --> Router Class Initialized
INFO - 2018-07-30 21:27:23 --> Output Class Initialized
INFO - 2018-07-30 21:27:23 --> Security Class Initialized
DEBUG - 2018-07-30 21:27:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 21:27:23 --> Input Class Initialized
INFO - 2018-07-30 21:27:23 --> Language Class Initialized
ERROR - 2018-07-30 21:27:23 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC) E:\xampp\htdocs\consulting\application\modules\admin\controllers\Programs.php 236
INFO - 2018-07-30 21:27:24 --> Config Class Initialized
INFO - 2018-07-30 21:27:24 --> Hooks Class Initialized
DEBUG - 2018-07-30 21:27:24 --> UTF-8 Support Enabled
INFO - 2018-07-30 21:27:24 --> Utf8 Class Initialized
INFO - 2018-07-30 21:27:24 --> URI Class Initialized
INFO - 2018-07-30 21:27:24 --> Router Class Initialized
INFO - 2018-07-30 21:27:24 --> Output Class Initialized
INFO - 2018-07-30 21:27:24 --> Security Class Initialized
DEBUG - 2018-07-30 21:27:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 21:27:24 --> Input Class Initialized
INFO - 2018-07-30 21:27:24 --> Language Class Initialized
ERROR - 2018-07-30 21:27:24 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC) E:\xampp\htdocs\consulting\application\modules\admin\controllers\Programs.php 236
INFO - 2018-07-30 21:27:29 --> Config Class Initialized
INFO - 2018-07-30 21:27:29 --> Hooks Class Initialized
DEBUG - 2018-07-30 21:27:29 --> UTF-8 Support Enabled
INFO - 2018-07-30 21:27:30 --> Utf8 Class Initialized
INFO - 2018-07-30 21:27:30 --> URI Class Initialized
INFO - 2018-07-30 21:27:30 --> Router Class Initialized
INFO - 2018-07-30 21:27:30 --> Output Class Initialized
INFO - 2018-07-30 21:27:30 --> Security Class Initialized
DEBUG - 2018-07-30 21:27:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 21:27:30 --> Input Class Initialized
INFO - 2018-07-30 21:27:30 --> Language Class Initialized
INFO - 2018-07-30 21:27:30 --> Language Class Initialized
INFO - 2018-07-30 21:27:30 --> Config Class Initialized
INFO - 2018-07-30 21:27:30 --> Loader Class Initialized
DEBUG - 2018-07-30 21:27:30 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-30 21:27:30 --> Helper loaded: url_helper
INFO - 2018-07-30 21:27:30 --> Helper loaded: form_helper
INFO - 2018-07-30 21:27:30 --> Helper loaded: date_helper
INFO - 2018-07-30 21:27:30 --> Helper loaded: util_helper
INFO - 2018-07-30 21:27:30 --> Helper loaded: text_helper
INFO - 2018-07-30 21:27:30 --> Helper loaded: string_helper
INFO - 2018-07-30 21:27:30 --> Database Driver Class Initialized
DEBUG - 2018-07-30 21:27:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 21:27:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 21:27:30 --> Email Class Initialized
INFO - 2018-07-30 21:27:30 --> Controller Class Initialized
DEBUG - 2018-07-30 21:27:30 --> Admin MX_Controller Initialized
INFO - 2018-07-30 21:27:30 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-30 21:27:30 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-30 21:27:30 --> Login MX_Controller Initialized
DEBUG - 2018-07-30 21:27:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-30 21:27:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-30 21:27:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/logins/login.php
INFO - 2018-07-30 21:27:30 --> Config Class Initialized
INFO - 2018-07-30 21:27:30 --> Hooks Class Initialized
DEBUG - 2018-07-30 21:27:30 --> UTF-8 Support Enabled
INFO - 2018-07-30 21:27:30 --> Utf8 Class Initialized
INFO - 2018-07-30 21:27:30 --> URI Class Initialized
INFO - 2018-07-30 21:27:30 --> Router Class Initialized
INFO - 2018-07-30 21:27:30 --> Output Class Initialized
INFO - 2018-07-30 21:27:30 --> Security Class Initialized
DEBUG - 2018-07-30 21:27:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 21:27:30 --> Input Class Initialized
INFO - 2018-07-30 21:27:30 --> Language Class Initialized
ERROR - 2018-07-30 21:27:30 --> 404 Page Not Found: /index
INFO - 2018-07-30 21:27:31 --> Config Class Initialized
INFO - 2018-07-30 21:27:31 --> Hooks Class Initialized
DEBUG - 2018-07-30 21:27:31 --> UTF-8 Support Enabled
INFO - 2018-07-30 21:27:31 --> Utf8 Class Initialized
INFO - 2018-07-30 21:27:31 --> URI Class Initialized
INFO - 2018-07-30 21:27:31 --> Router Class Initialized
INFO - 2018-07-30 21:27:31 --> Output Class Initialized
INFO - 2018-07-30 21:27:31 --> Security Class Initialized
DEBUG - 2018-07-30 21:27:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 21:27:31 --> Input Class Initialized
INFO - 2018-07-30 21:27:31 --> Language Class Initialized
ERROR - 2018-07-30 21:27:31 --> 404 Page Not Found: /index
INFO - 2018-07-30 21:27:35 --> Config Class Initialized
INFO - 2018-07-30 21:27:35 --> Hooks Class Initialized
DEBUG - 2018-07-30 21:27:35 --> UTF-8 Support Enabled
INFO - 2018-07-30 21:27:35 --> Utf8 Class Initialized
INFO - 2018-07-30 21:27:35 --> URI Class Initialized
INFO - 2018-07-30 21:27:35 --> Router Class Initialized
INFO - 2018-07-30 21:27:35 --> Output Class Initialized
INFO - 2018-07-30 21:27:35 --> Security Class Initialized
DEBUG - 2018-07-30 21:27:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 21:27:35 --> Input Class Initialized
INFO - 2018-07-30 21:27:35 --> Language Class Initialized
INFO - 2018-07-30 21:27:35 --> Language Class Initialized
INFO - 2018-07-30 21:27:35 --> Config Class Initialized
INFO - 2018-07-30 21:27:35 --> Loader Class Initialized
DEBUG - 2018-07-30 21:27:35 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-30 21:27:35 --> Helper loaded: url_helper
INFO - 2018-07-30 21:27:35 --> Helper loaded: form_helper
INFO - 2018-07-30 21:27:35 --> Helper loaded: date_helper
INFO - 2018-07-30 21:27:35 --> Helper loaded: util_helper
INFO - 2018-07-30 21:27:35 --> Helper loaded: text_helper
INFO - 2018-07-30 21:27:35 --> Helper loaded: string_helper
INFO - 2018-07-30 21:27:35 --> Database Driver Class Initialized
DEBUG - 2018-07-30 21:27:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 21:27:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 21:27:35 --> Email Class Initialized
INFO - 2018-07-30 21:27:35 --> Controller Class Initialized
DEBUG - 2018-07-30 21:27:35 --> Login MX_Controller Initialized
INFO - 2018-07-30 21:27:35 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-30 21:27:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-30 21:27:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-30 21:27:35 --> Email starts for admin@colin.com fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-07-30 21:27:35 --> Login status admin@colin.com - failure
INFO - 2018-07-30 21:27:35 --> Final output sent to browser
DEBUG - 2018-07-30 21:27:35 --> Total execution time: 0.2783
INFO - 2018-07-30 21:27:39 --> Config Class Initialized
INFO - 2018-07-30 21:27:39 --> Hooks Class Initialized
DEBUG - 2018-07-30 21:27:39 --> UTF-8 Support Enabled
INFO - 2018-07-30 21:27:39 --> Utf8 Class Initialized
INFO - 2018-07-30 21:27:39 --> URI Class Initialized
INFO - 2018-07-30 21:27:39 --> Router Class Initialized
INFO - 2018-07-30 21:27:39 --> Output Class Initialized
INFO - 2018-07-30 21:27:39 --> Security Class Initialized
DEBUG - 2018-07-30 21:27:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 21:27:40 --> Input Class Initialized
INFO - 2018-07-30 21:27:40 --> Language Class Initialized
INFO - 2018-07-30 21:27:40 --> Language Class Initialized
INFO - 2018-07-30 21:27:40 --> Config Class Initialized
INFO - 2018-07-30 21:27:40 --> Loader Class Initialized
DEBUG - 2018-07-30 21:27:40 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-30 21:27:40 --> Helper loaded: url_helper
INFO - 2018-07-30 21:27:40 --> Helper loaded: form_helper
INFO - 2018-07-30 21:27:40 --> Helper loaded: date_helper
INFO - 2018-07-30 21:27:40 --> Helper loaded: util_helper
INFO - 2018-07-30 21:27:40 --> Helper loaded: text_helper
INFO - 2018-07-30 21:27:40 --> Helper loaded: string_helper
INFO - 2018-07-30 21:27:40 --> Database Driver Class Initialized
DEBUG - 2018-07-30 21:27:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 21:27:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 21:27:40 --> Email Class Initialized
INFO - 2018-07-30 21:27:40 --> Controller Class Initialized
DEBUG - 2018-07-30 21:27:40 --> Login MX_Controller Initialized
INFO - 2018-07-30 21:27:40 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-30 21:27:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-30 21:27:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-30 21:27:40 --> Email starts for colin-admin fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-07-30 21:27:40 --> User session created for 1
INFO - 2018-07-30 21:27:40 --> Login status colin-admin - success
INFO - 2018-07-30 21:27:40 --> Final output sent to browser
DEBUG - 2018-07-30 21:27:40 --> Total execution time: 0.3267
INFO - 2018-07-30 21:27:40 --> Config Class Initialized
INFO - 2018-07-30 21:27:40 --> Hooks Class Initialized
DEBUG - 2018-07-30 21:27:40 --> UTF-8 Support Enabled
INFO - 2018-07-30 21:27:40 --> Utf8 Class Initialized
INFO - 2018-07-30 21:27:40 --> URI Class Initialized
INFO - 2018-07-30 21:27:40 --> Router Class Initialized
INFO - 2018-07-30 21:27:40 --> Output Class Initialized
INFO - 2018-07-30 21:27:40 --> Security Class Initialized
DEBUG - 2018-07-30 21:27:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 21:27:40 --> Input Class Initialized
INFO - 2018-07-30 21:27:40 --> Language Class Initialized
INFO - 2018-07-30 21:27:40 --> Language Class Initialized
INFO - 2018-07-30 21:27:40 --> Config Class Initialized
INFO - 2018-07-30 21:27:40 --> Loader Class Initialized
DEBUG - 2018-07-30 21:27:40 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-30 21:27:40 --> Helper loaded: url_helper
INFO - 2018-07-30 21:27:40 --> Helper loaded: form_helper
INFO - 2018-07-30 21:27:40 --> Helper loaded: date_helper
INFO - 2018-07-30 21:27:40 --> Helper loaded: util_helper
INFO - 2018-07-30 21:27:40 --> Helper loaded: text_helper
INFO - 2018-07-30 21:27:40 --> Helper loaded: string_helper
INFO - 2018-07-30 21:27:40 --> Database Driver Class Initialized
DEBUG - 2018-07-30 21:27:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 21:27:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 21:27:40 --> Email Class Initialized
INFO - 2018-07-30 21:27:40 --> Controller Class Initialized
DEBUG - 2018-07-30 21:27:40 --> Admin MX_Controller Initialized
INFO - 2018-07-30 21:27:40 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-30 21:27:40 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-30 21:27:40 --> Login MX_Controller Initialized
DEBUG - 2018-07-30 21:27:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-30 21:27:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-30 21:27:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-30 21:27:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-30 21:27:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-30 21:27:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-30 21:27:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-30 21:27:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/dashboard.php
INFO - 2018-07-30 21:27:40 --> Final output sent to browser
DEBUG - 2018-07-30 21:27:40 --> Total execution time: 0.5876
INFO - 2018-07-30 21:27:41 --> Config Class Initialized
INFO - 2018-07-30 21:27:41 --> Hooks Class Initialized
DEBUG - 2018-07-30 21:27:41 --> UTF-8 Support Enabled
INFO - 2018-07-30 21:27:41 --> Utf8 Class Initialized
INFO - 2018-07-30 21:27:41 --> URI Class Initialized
INFO - 2018-07-30 21:27:41 --> Router Class Initialized
INFO - 2018-07-30 21:27:41 --> Output Class Initialized
INFO - 2018-07-30 21:27:41 --> Security Class Initialized
DEBUG - 2018-07-30 21:27:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 21:27:41 --> Input Class Initialized
INFO - 2018-07-30 21:27:41 --> Language Class Initialized
ERROR - 2018-07-30 21:27:41 --> 404 Page Not Found: /index
INFO - 2018-07-30 21:27:42 --> Config Class Initialized
INFO - 2018-07-30 21:27:42 --> Hooks Class Initialized
DEBUG - 2018-07-30 21:27:42 --> UTF-8 Support Enabled
INFO - 2018-07-30 21:27:42 --> Utf8 Class Initialized
INFO - 2018-07-30 21:27:42 --> URI Class Initialized
INFO - 2018-07-30 21:27:42 --> Router Class Initialized
INFO - 2018-07-30 21:27:42 --> Output Class Initialized
INFO - 2018-07-30 21:27:42 --> Security Class Initialized
DEBUG - 2018-07-30 21:27:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 21:27:42 --> Input Class Initialized
INFO - 2018-07-30 21:27:42 --> Language Class Initialized
ERROR - 2018-07-30 21:27:42 --> 404 Page Not Found: /index
INFO - 2018-07-30 21:27:42 --> Config Class Initialized
INFO - 2018-07-30 21:27:42 --> Hooks Class Initialized
DEBUG - 2018-07-30 21:27:42 --> UTF-8 Support Enabled
INFO - 2018-07-30 21:27:42 --> Utf8 Class Initialized
INFO - 2018-07-30 21:27:42 --> URI Class Initialized
INFO - 2018-07-30 21:27:42 --> Router Class Initialized
INFO - 2018-07-30 21:27:42 --> Output Class Initialized
INFO - 2018-07-30 21:27:42 --> Security Class Initialized
DEBUG - 2018-07-30 21:27:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 21:27:42 --> Input Class Initialized
INFO - 2018-07-30 21:27:42 --> Language Class Initialized
ERROR - 2018-07-30 21:27:42 --> 404 Page Not Found: /index
INFO - 2018-07-30 21:27:44 --> Config Class Initialized
INFO - 2018-07-30 21:27:44 --> Hooks Class Initialized
DEBUG - 2018-07-30 21:27:44 --> UTF-8 Support Enabled
INFO - 2018-07-30 21:27:44 --> Utf8 Class Initialized
INFO - 2018-07-30 21:27:44 --> URI Class Initialized
INFO - 2018-07-30 21:27:45 --> Router Class Initialized
INFO - 2018-07-30 21:27:45 --> Output Class Initialized
INFO - 2018-07-30 21:27:45 --> Security Class Initialized
DEBUG - 2018-07-30 21:27:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 21:27:45 --> Input Class Initialized
INFO - 2018-07-30 21:27:45 --> Language Class Initialized
INFO - 2018-07-30 21:27:45 --> Language Class Initialized
INFO - 2018-07-30 21:27:45 --> Config Class Initialized
INFO - 2018-07-30 21:27:45 --> Loader Class Initialized
DEBUG - 2018-07-30 21:27:45 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-30 21:27:45 --> Helper loaded: url_helper
INFO - 2018-07-30 21:27:45 --> Helper loaded: form_helper
INFO - 2018-07-30 21:27:45 --> Helper loaded: date_helper
INFO - 2018-07-30 21:27:45 --> Helper loaded: util_helper
INFO - 2018-07-30 21:27:45 --> Helper loaded: text_helper
INFO - 2018-07-30 21:27:45 --> Helper loaded: string_helper
INFO - 2018-07-30 21:27:45 --> Database Driver Class Initialized
DEBUG - 2018-07-30 21:27:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 21:27:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 21:27:45 --> Email Class Initialized
INFO - 2018-07-30 21:27:45 --> Controller Class Initialized
DEBUG - 2018-07-30 21:27:45 --> Users MX_Controller Initialized
DEBUG - 2018-07-30 21:27:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-30 21:27:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-07-30 21:27:45 --> Helper loaded: file_helper
DEBUG - 2018-07-30 21:27:45 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-30 21:27:45 --> Login MX_Controller Initialized
INFO - 2018-07-30 21:27:45 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-30 21:27:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-30 21:27:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-30 21:27:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-30 21:27:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-30 21:27:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-30 21:27:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-30 21:27:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/users.php
INFO - 2018-07-30 21:27:45 --> Final output sent to browser
DEBUG - 2018-07-30 21:27:45 --> Total execution time: 0.4710
INFO - 2018-07-30 21:27:45 --> Config Class Initialized
INFO - 2018-07-30 21:27:45 --> Hooks Class Initialized
DEBUG - 2018-07-30 21:27:45 --> UTF-8 Support Enabled
INFO - 2018-07-30 21:27:45 --> Utf8 Class Initialized
INFO - 2018-07-30 21:27:45 --> URI Class Initialized
INFO - 2018-07-30 21:27:45 --> Router Class Initialized
INFO - 2018-07-30 21:27:45 --> Output Class Initialized
INFO - 2018-07-30 21:27:45 --> Security Class Initialized
DEBUG - 2018-07-30 21:27:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 21:27:45 --> Input Class Initialized
INFO - 2018-07-30 21:27:45 --> Language Class Initialized
INFO - 2018-07-30 21:27:45 --> Language Class Initialized
INFO - 2018-07-30 21:27:45 --> Config Class Initialized
INFO - 2018-07-30 21:27:45 --> Loader Class Initialized
DEBUG - 2018-07-30 21:27:45 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-30 21:27:45 --> Helper loaded: url_helper
INFO - 2018-07-30 21:27:45 --> Helper loaded: form_helper
INFO - 2018-07-30 21:27:45 --> Helper loaded: date_helper
INFO - 2018-07-30 21:27:45 --> Helper loaded: util_helper
INFO - 2018-07-30 21:27:45 --> Helper loaded: text_helper
INFO - 2018-07-30 21:27:45 --> Helper loaded: string_helper
INFO - 2018-07-30 21:27:45 --> Database Driver Class Initialized
DEBUG - 2018-07-30 21:27:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 21:27:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 21:27:45 --> Email Class Initialized
INFO - 2018-07-30 21:27:45 --> Controller Class Initialized
DEBUG - 2018-07-30 21:27:45 --> Users MX_Controller Initialized
DEBUG - 2018-07-30 21:27:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-30 21:27:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-07-30 21:27:46 --> Helper loaded: file_helper
DEBUG - 2018-07-30 21:27:46 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-30 21:27:46 --> Login MX_Controller Initialized
INFO - 2018-07-30 21:27:46 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-30 21:27:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-30 21:27:46 --> Final output sent to browser
DEBUG - 2018-07-30 21:27:46 --> Total execution time: 0.4284
INFO - 2018-07-30 21:27:48 --> Config Class Initialized
INFO - 2018-07-30 21:27:48 --> Hooks Class Initialized
DEBUG - 2018-07-30 21:27:48 --> UTF-8 Support Enabled
INFO - 2018-07-30 21:27:48 --> Utf8 Class Initialized
INFO - 2018-07-30 21:27:48 --> URI Class Initialized
INFO - 2018-07-30 21:27:48 --> Router Class Initialized
INFO - 2018-07-30 21:27:48 --> Output Class Initialized
INFO - 2018-07-30 21:27:48 --> Security Class Initialized
DEBUG - 2018-07-30 21:27:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 21:27:48 --> Input Class Initialized
INFO - 2018-07-30 21:27:48 --> Language Class Initialized
ERROR - 2018-07-30 21:27:48 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC) E:\xampp\htdocs\consulting\application\modules\admin\controllers\Programs.php 236
INFO - 2018-07-30 21:32:53 --> Config Class Initialized
INFO - 2018-07-30 21:32:53 --> Hooks Class Initialized
DEBUG - 2018-07-30 21:32:53 --> UTF-8 Support Enabled
INFO - 2018-07-30 21:32:53 --> Utf8 Class Initialized
INFO - 2018-07-30 21:32:53 --> URI Class Initialized
INFO - 2018-07-30 21:32:53 --> Router Class Initialized
INFO - 2018-07-30 21:32:53 --> Output Class Initialized
INFO - 2018-07-30 21:32:53 --> Security Class Initialized
DEBUG - 2018-07-30 21:32:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 21:32:54 --> Input Class Initialized
INFO - 2018-07-30 21:32:54 --> Language Class Initialized
ERROR - 2018-07-30 21:32:54 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC) E:\xampp\htdocs\consulting\application\modules\admin\controllers\Programs.php 237
INFO - 2018-07-30 21:32:56 --> Config Class Initialized
INFO - 2018-07-30 21:32:56 --> Hooks Class Initialized
DEBUG - 2018-07-30 21:32:56 --> UTF-8 Support Enabled
INFO - 2018-07-30 21:32:56 --> Utf8 Class Initialized
INFO - 2018-07-30 21:32:56 --> URI Class Initialized
INFO - 2018-07-30 21:32:56 --> Router Class Initialized
INFO - 2018-07-30 21:32:56 --> Output Class Initialized
INFO - 2018-07-30 21:32:56 --> Security Class Initialized
DEBUG - 2018-07-30 21:32:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 21:32:56 --> Input Class Initialized
INFO - 2018-07-30 21:32:56 --> Language Class Initialized
ERROR - 2018-07-30 21:32:56 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC) E:\xampp\htdocs\consulting\application\modules\admin\controllers\Programs.php 237
INFO - 2018-07-30 21:35:01 --> Config Class Initialized
INFO - 2018-07-30 21:35:01 --> Hooks Class Initialized
DEBUG - 2018-07-30 21:35:01 --> UTF-8 Support Enabled
INFO - 2018-07-30 21:35:01 --> Utf8 Class Initialized
INFO - 2018-07-30 21:35:01 --> URI Class Initialized
INFO - 2018-07-30 21:35:01 --> Router Class Initialized
INFO - 2018-07-30 21:35:01 --> Output Class Initialized
INFO - 2018-07-30 21:35:01 --> Security Class Initialized
DEBUG - 2018-07-30 21:35:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 21:35:01 --> Input Class Initialized
INFO - 2018-07-30 21:35:01 --> Language Class Initialized
ERROR - 2018-07-30 21:35:01 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC) E:\xampp\htdocs\consulting\application\modules\admin\controllers\Programs.php 238
INFO - 2018-07-30 21:35:56 --> Config Class Initialized
INFO - 2018-07-30 21:35:56 --> Hooks Class Initialized
DEBUG - 2018-07-30 21:35:56 --> UTF-8 Support Enabled
INFO - 2018-07-30 21:35:56 --> Utf8 Class Initialized
INFO - 2018-07-30 21:35:56 --> URI Class Initialized
INFO - 2018-07-30 21:35:56 --> Router Class Initialized
INFO - 2018-07-30 21:35:56 --> Output Class Initialized
INFO - 2018-07-30 21:35:56 --> Security Class Initialized
DEBUG - 2018-07-30 21:35:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 21:35:56 --> Input Class Initialized
INFO - 2018-07-30 21:35:56 --> Language Class Initialized
INFO - 2018-07-30 21:35:56 --> Language Class Initialized
INFO - 2018-07-30 21:35:56 --> Config Class Initialized
INFO - 2018-07-30 21:35:56 --> Loader Class Initialized
DEBUG - 2018-07-30 21:35:56 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-30 21:35:56 --> Helper loaded: url_helper
INFO - 2018-07-30 21:35:56 --> Helper loaded: form_helper
INFO - 2018-07-30 21:35:56 --> Helper loaded: date_helper
INFO - 2018-07-30 21:35:56 --> Helper loaded: util_helper
INFO - 2018-07-30 21:35:56 --> Helper loaded: text_helper
INFO - 2018-07-30 21:35:56 --> Helper loaded: string_helper
INFO - 2018-07-30 21:35:56 --> Database Driver Class Initialized
DEBUG - 2018-07-30 21:35:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 21:35:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 21:35:56 --> Email Class Initialized
INFO - 2018-07-30 21:35:56 --> Controller Class Initialized
DEBUG - 2018-07-30 21:35:56 --> Programs MX_Controller Initialized
INFO - 2018-07-30 21:35:56 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-30 21:35:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-07-30 21:35:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-30 21:35:56 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-30 21:35:56 --> Login MX_Controller Initialized
DEBUG - 2018-07-30 21:35:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-30 21:36:04 --> Config Class Initialized
INFO - 2018-07-30 21:36:04 --> Hooks Class Initialized
DEBUG - 2018-07-30 21:36:04 --> UTF-8 Support Enabled
INFO - 2018-07-30 21:36:04 --> Utf8 Class Initialized
INFO - 2018-07-30 21:36:04 --> URI Class Initialized
INFO - 2018-07-30 21:36:04 --> Router Class Initialized
INFO - 2018-07-30 21:36:04 --> Output Class Initialized
INFO - 2018-07-30 21:36:04 --> Security Class Initialized
DEBUG - 2018-07-30 21:36:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 21:36:04 --> Input Class Initialized
INFO - 2018-07-30 21:36:04 --> Language Class Initialized
INFO - 2018-07-30 21:36:04 --> Language Class Initialized
INFO - 2018-07-30 21:36:04 --> Config Class Initialized
INFO - 2018-07-30 21:36:04 --> Loader Class Initialized
DEBUG - 2018-07-30 21:36:04 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-30 21:36:04 --> Helper loaded: url_helper
INFO - 2018-07-30 21:36:04 --> Helper loaded: form_helper
INFO - 2018-07-30 21:36:04 --> Helper loaded: date_helper
INFO - 2018-07-30 21:36:04 --> Helper loaded: util_helper
INFO - 2018-07-30 21:36:04 --> Helper loaded: text_helper
INFO - 2018-07-30 21:36:04 --> Helper loaded: string_helper
INFO - 2018-07-30 21:36:04 --> Database Driver Class Initialized
DEBUG - 2018-07-30 21:36:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 21:36:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 21:36:04 --> Email Class Initialized
INFO - 2018-07-30 21:36:04 --> Controller Class Initialized
DEBUG - 2018-07-30 21:36:04 --> Programs MX_Controller Initialized
INFO - 2018-07-30 21:36:04 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-30 21:36:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-07-30 21:36:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-30 21:36:04 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-30 21:36:04 --> Login MX_Controller Initialized
DEBUG - 2018-07-30 21:36:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-30 21:36:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-30 21:36:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-30 21:36:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-30 21:36:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-30 21:36:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-30 21:36:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/programs/programs.php
INFO - 2018-07-30 21:36:04 --> Final output sent to browser
DEBUG - 2018-07-30 21:36:04 --> Total execution time: 0.3710
INFO - 2018-07-30 21:36:04 --> Config Class Initialized
INFO - 2018-07-30 21:36:04 --> Hooks Class Initialized
DEBUG - 2018-07-30 21:36:05 --> UTF-8 Support Enabled
INFO - 2018-07-30 21:36:05 --> Utf8 Class Initialized
INFO - 2018-07-30 21:36:05 --> URI Class Initialized
INFO - 2018-07-30 21:36:05 --> Router Class Initialized
INFO - 2018-07-30 21:36:05 --> Output Class Initialized
INFO - 2018-07-30 21:36:05 --> Security Class Initialized
DEBUG - 2018-07-30 21:36:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 21:36:05 --> Input Class Initialized
INFO - 2018-07-30 21:36:05 --> Language Class Initialized
INFO - 2018-07-30 21:36:05 --> Language Class Initialized
INFO - 2018-07-30 21:36:05 --> Config Class Initialized
INFO - 2018-07-30 21:36:05 --> Loader Class Initialized
DEBUG - 2018-07-30 21:36:05 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-30 21:36:05 --> Helper loaded: url_helper
INFO - 2018-07-30 21:36:05 --> Helper loaded: form_helper
INFO - 2018-07-30 21:36:05 --> Helper loaded: date_helper
INFO - 2018-07-30 21:36:05 --> Helper loaded: util_helper
INFO - 2018-07-30 21:36:05 --> Helper loaded: text_helper
INFO - 2018-07-30 21:36:05 --> Helper loaded: string_helper
INFO - 2018-07-30 21:36:05 --> Database Driver Class Initialized
DEBUG - 2018-07-30 21:36:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 21:36:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 21:36:05 --> Email Class Initialized
INFO - 2018-07-30 21:36:05 --> Controller Class Initialized
DEBUG - 2018-07-30 21:36:05 --> Programs MX_Controller Initialized
INFO - 2018-07-30 21:36:05 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-30 21:36:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-07-30 21:36:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-30 21:36:05 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-30 21:36:05 --> Login MX_Controller Initialized
DEBUG - 2018-07-30 21:36:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-30 21:36:05 --> Final output sent to browser
DEBUG - 2018-07-30 21:36:05 --> Total execution time: 0.4441
INFO - 2018-07-30 21:36:44 --> Config Class Initialized
INFO - 2018-07-30 21:36:44 --> Hooks Class Initialized
DEBUG - 2018-07-30 21:36:44 --> UTF-8 Support Enabled
INFO - 2018-07-30 21:36:44 --> Utf8 Class Initialized
INFO - 2018-07-30 21:36:44 --> URI Class Initialized
INFO - 2018-07-30 21:36:44 --> Router Class Initialized
INFO - 2018-07-30 21:36:44 --> Output Class Initialized
INFO - 2018-07-30 21:36:44 --> Security Class Initialized
DEBUG - 2018-07-30 21:36:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 21:36:44 --> Input Class Initialized
INFO - 2018-07-30 21:36:44 --> Language Class Initialized
INFO - 2018-07-30 21:36:44 --> Language Class Initialized
INFO - 2018-07-30 21:36:44 --> Config Class Initialized
INFO - 2018-07-30 21:36:44 --> Loader Class Initialized
DEBUG - 2018-07-30 21:36:44 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-30 21:36:44 --> Helper loaded: url_helper
INFO - 2018-07-30 21:36:44 --> Helper loaded: form_helper
INFO - 2018-07-30 21:36:44 --> Helper loaded: date_helper
INFO - 2018-07-30 21:36:44 --> Helper loaded: util_helper
INFO - 2018-07-30 21:36:44 --> Helper loaded: text_helper
INFO - 2018-07-30 21:36:44 --> Helper loaded: string_helper
INFO - 2018-07-30 21:36:44 --> Database Driver Class Initialized
DEBUG - 2018-07-30 21:36:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 21:36:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 21:36:44 --> Email Class Initialized
INFO - 2018-07-30 21:36:44 --> Controller Class Initialized
DEBUG - 2018-07-30 21:36:44 --> Login MX_Controller Initialized
INFO - 2018-07-30 21:36:44 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-30 21:36:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-30 21:36:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-30 21:36:44 --> Email starts for colin fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-07-30 21:36:44 --> Login status colin - failure
INFO - 2018-07-30 21:36:44 --> Final output sent to browser
DEBUG - 2018-07-30 21:36:44 --> Total execution time: 0.3163
INFO - 2018-07-30 21:36:48 --> Config Class Initialized
INFO - 2018-07-30 21:36:48 --> Hooks Class Initialized
DEBUG - 2018-07-30 21:36:48 --> UTF-8 Support Enabled
INFO - 2018-07-30 21:36:48 --> Utf8 Class Initialized
INFO - 2018-07-30 21:36:48 --> URI Class Initialized
INFO - 2018-07-30 21:36:48 --> Router Class Initialized
INFO - 2018-07-30 21:36:48 --> Output Class Initialized
INFO - 2018-07-30 21:36:48 --> Security Class Initialized
DEBUG - 2018-07-30 21:36:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 21:36:48 --> Input Class Initialized
INFO - 2018-07-30 21:36:48 --> Language Class Initialized
INFO - 2018-07-30 21:36:48 --> Language Class Initialized
INFO - 2018-07-30 21:36:48 --> Config Class Initialized
INFO - 2018-07-30 21:36:48 --> Loader Class Initialized
DEBUG - 2018-07-30 21:36:48 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-30 21:36:48 --> Helper loaded: url_helper
INFO - 2018-07-30 21:36:48 --> Helper loaded: form_helper
INFO - 2018-07-30 21:36:48 --> Helper loaded: date_helper
INFO - 2018-07-30 21:36:48 --> Helper loaded: util_helper
INFO - 2018-07-30 21:36:48 --> Helper loaded: text_helper
INFO - 2018-07-30 21:36:48 --> Helper loaded: string_helper
INFO - 2018-07-30 21:36:48 --> Database Driver Class Initialized
DEBUG - 2018-07-30 21:36:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 21:36:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 21:36:48 --> Email Class Initialized
INFO - 2018-07-30 21:36:48 --> Controller Class Initialized
DEBUG - 2018-07-30 21:36:48 --> Login MX_Controller Initialized
INFO - 2018-07-30 21:36:48 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-30 21:36:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-30 21:36:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-30 21:36:48 --> Email starts for colin fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-07-30 21:36:48 --> Login status colin - failure
INFO - 2018-07-30 21:36:48 --> Final output sent to browser
DEBUG - 2018-07-30 21:36:48 --> Total execution time: 0.2993
INFO - 2018-07-30 21:37:22 --> Config Class Initialized
INFO - 2018-07-30 21:37:22 --> Hooks Class Initialized
DEBUG - 2018-07-30 21:37:22 --> UTF-8 Support Enabled
INFO - 2018-07-30 21:37:22 --> Utf8 Class Initialized
INFO - 2018-07-30 21:37:22 --> URI Class Initialized
INFO - 2018-07-30 21:37:22 --> Router Class Initialized
INFO - 2018-07-30 21:37:22 --> Output Class Initialized
INFO - 2018-07-30 21:37:22 --> Security Class Initialized
DEBUG - 2018-07-30 21:37:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 21:37:22 --> Input Class Initialized
INFO - 2018-07-30 21:37:22 --> Language Class Initialized
INFO - 2018-07-30 21:37:22 --> Language Class Initialized
INFO - 2018-07-30 21:37:22 --> Config Class Initialized
INFO - 2018-07-30 21:37:22 --> Loader Class Initialized
DEBUG - 2018-07-30 21:37:22 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-30 21:37:22 --> Helper loaded: url_helper
INFO - 2018-07-30 21:37:22 --> Helper loaded: form_helper
INFO - 2018-07-30 21:37:22 --> Helper loaded: date_helper
INFO - 2018-07-30 21:37:22 --> Helper loaded: util_helper
INFO - 2018-07-30 21:37:22 --> Helper loaded: text_helper
INFO - 2018-07-30 21:37:22 --> Helper loaded: string_helper
INFO - 2018-07-30 21:37:22 --> Database Driver Class Initialized
DEBUG - 2018-07-30 21:37:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 21:37:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 21:37:22 --> Email Class Initialized
INFO - 2018-07-30 21:37:22 --> Controller Class Initialized
DEBUG - 2018-07-30 21:37:22 --> Login MX_Controller Initialized
INFO - 2018-07-30 21:37:22 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-30 21:37:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-30 21:37:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-30 21:37:22 --> Email starts for ColinUser fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-07-30 21:37:22 --> User session created for 4
INFO - 2018-07-30 21:37:22 --> Login status ColinUser - success
INFO - 2018-07-30 21:37:22 --> Final output sent to browser
DEBUG - 2018-07-30 21:37:22 --> Total execution time: 0.3415
INFO - 2018-07-30 21:37:22 --> Config Class Initialized
INFO - 2018-07-30 21:37:22 --> Hooks Class Initialized
DEBUG - 2018-07-30 21:37:22 --> UTF-8 Support Enabled
INFO - 2018-07-30 21:37:22 --> Utf8 Class Initialized
INFO - 2018-07-30 21:37:22 --> URI Class Initialized
INFO - 2018-07-30 21:37:22 --> Router Class Initialized
INFO - 2018-07-30 21:37:22 --> Output Class Initialized
INFO - 2018-07-30 21:37:22 --> Security Class Initialized
DEBUG - 2018-07-30 21:37:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 21:37:22 --> Input Class Initialized
INFO - 2018-07-30 21:37:22 --> Language Class Initialized
INFO - 2018-07-30 21:37:22 --> Language Class Initialized
INFO - 2018-07-30 21:37:22 --> Config Class Initialized
INFO - 2018-07-30 21:37:22 --> Loader Class Initialized
DEBUG - 2018-07-30 21:37:22 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-30 21:37:22 --> Helper loaded: url_helper
INFO - 2018-07-30 21:37:22 --> Helper loaded: form_helper
INFO - 2018-07-30 21:37:22 --> Helper loaded: date_helper
INFO - 2018-07-30 21:37:22 --> Helper loaded: util_helper
INFO - 2018-07-30 21:37:22 --> Helper loaded: text_helper
INFO - 2018-07-30 21:37:22 --> Helper loaded: string_helper
INFO - 2018-07-30 21:37:22 --> Database Driver Class Initialized
DEBUG - 2018-07-30 21:37:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 21:37:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 21:37:22 --> Email Class Initialized
INFO - 2018-07-30 21:37:22 --> Controller Class Initialized
DEBUG - 2018-07-30 21:37:22 --> Home MX_Controller Initialized
DEBUG - 2018-07-30 21:37:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-30 21:37:22 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-30 21:37:22 --> Login MX_Controller Initialized
INFO - 2018-07-30 21:37:22 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-30 21:37:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-30 21:37:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-30 21:37:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-07-30 21:37:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-07-30 21:37:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-07-30 21:37:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-07-30 21:37:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-07-30 21:37:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-07-30 21:37:22 --> Final output sent to browser
DEBUG - 2018-07-30 21:37:23 --> Total execution time: 0.4162
INFO - 2018-07-30 21:37:24 --> Config Class Initialized
INFO - 2018-07-30 21:37:25 --> Hooks Class Initialized
DEBUG - 2018-07-30 21:37:25 --> UTF-8 Support Enabled
INFO - 2018-07-30 21:37:25 --> Utf8 Class Initialized
INFO - 2018-07-30 21:37:25 --> URI Class Initialized
INFO - 2018-07-30 21:37:25 --> Router Class Initialized
INFO - 2018-07-30 21:37:25 --> Output Class Initialized
INFO - 2018-07-30 21:37:25 --> Security Class Initialized
DEBUG - 2018-07-30 21:37:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 21:37:25 --> Input Class Initialized
INFO - 2018-07-30 21:37:25 --> Language Class Initialized
ERROR - 2018-07-30 21:37:25 --> 404 Page Not Found: /index
INFO - 2018-07-30 21:37:25 --> Config Class Initialized
INFO - 2018-07-30 21:37:25 --> Hooks Class Initialized
DEBUG - 2018-07-30 21:37:25 --> UTF-8 Support Enabled
INFO - 2018-07-30 21:37:25 --> Config Class Initialized
INFO - 2018-07-30 21:37:25 --> Utf8 Class Initialized
INFO - 2018-07-30 21:37:25 --> Hooks Class Initialized
INFO - 2018-07-30 21:37:25 --> URI Class Initialized
DEBUG - 2018-07-30 21:37:25 --> UTF-8 Support Enabled
INFO - 2018-07-30 21:37:25 --> Utf8 Class Initialized
INFO - 2018-07-30 21:37:25 --> Router Class Initialized
INFO - 2018-07-30 21:37:25 --> URI Class Initialized
INFO - 2018-07-30 21:37:25 --> Router Class Initialized
INFO - 2018-07-30 21:37:25 --> Output Class Initialized
INFO - 2018-07-30 21:37:25 --> Output Class Initialized
INFO - 2018-07-30 21:37:25 --> Security Class Initialized
DEBUG - 2018-07-30 21:37:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 21:37:25 --> Security Class Initialized
DEBUG - 2018-07-30 21:37:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 21:37:25 --> Input Class Initialized
INFO - 2018-07-30 21:37:25 --> Input Class Initialized
INFO - 2018-07-30 21:37:25 --> Language Class Initialized
INFO - 2018-07-30 21:37:25 --> Language Class Initialized
ERROR - 2018-07-30 21:37:25 --> 404 Page Not Found: /index
INFO - 2018-07-30 21:37:25 --> Language Class Initialized
INFO - 2018-07-30 21:37:25 --> Config Class Initialized
INFO - 2018-07-30 21:37:25 --> Hooks Class Initialized
INFO - 2018-07-30 21:37:25 --> Config Class Initialized
DEBUG - 2018-07-30 21:37:25 --> UTF-8 Support Enabled
INFO - 2018-07-30 21:37:25 --> Utf8 Class Initialized
INFO - 2018-07-30 21:37:25 --> URI Class Initialized
INFO - 2018-07-30 21:37:25 --> Router Class Initialized
INFO - 2018-07-30 21:37:25 --> Output Class Initialized
INFO - 2018-07-30 21:37:25 --> Loader Class Initialized
INFO - 2018-07-30 21:37:25 --> Security Class Initialized
DEBUG - 2018-07-30 21:37:25 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
DEBUG - 2018-07-30 21:37:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 21:37:25 --> Input Class Initialized
INFO - 2018-07-30 21:37:25 --> Language Class Initialized
INFO - 2018-07-30 21:37:25 --> Helper loaded: url_helper
ERROR - 2018-07-30 21:37:25 --> 404 Page Not Found: /index
INFO - 2018-07-30 21:37:25 --> Helper loaded: form_helper
INFO - 2018-07-30 21:37:25 --> Helper loaded: date_helper
INFO - 2018-07-30 21:37:25 --> Helper loaded: util_helper
INFO - 2018-07-30 21:37:25 --> Helper loaded: text_helper
INFO - 2018-07-30 21:37:25 --> Helper loaded: string_helper
INFO - 2018-07-30 21:37:25 --> Database Driver Class Initialized
DEBUG - 2018-07-30 21:37:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 21:37:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 21:37:25 --> Email Class Initialized
INFO - 2018-07-30 21:37:25 --> Controller Class Initialized
DEBUG - 2018-07-30 21:37:25 --> Home MX_Controller Initialized
DEBUG - 2018-07-30 21:37:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-30 21:37:25 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-30 21:37:25 --> Login MX_Controller Initialized
INFO - 2018-07-30 21:37:25 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-30 21:37:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-30 21:37:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-30 21:37:26 --> Config Class Initialized
INFO - 2018-07-30 21:37:26 --> Hooks Class Initialized
DEBUG - 2018-07-30 21:37:26 --> UTF-8 Support Enabled
INFO - 2018-07-30 21:37:26 --> Utf8 Class Initialized
INFO - 2018-07-30 21:37:26 --> URI Class Initialized
INFO - 2018-07-30 21:37:26 --> Router Class Initialized
INFO - 2018-07-30 21:37:26 --> Output Class Initialized
INFO - 2018-07-30 21:37:26 --> Security Class Initialized
DEBUG - 2018-07-30 21:37:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 21:37:26 --> Input Class Initialized
INFO - 2018-07-30 21:37:26 --> Config Class Initialized
INFO - 2018-07-30 21:37:26 --> Hooks Class Initialized
INFO - 2018-07-30 21:37:26 --> Language Class Initialized
ERROR - 2018-07-30 21:37:26 --> 404 Page Not Found: /index
DEBUG - 2018-07-30 21:37:26 --> UTF-8 Support Enabled
INFO - 2018-07-30 21:37:26 --> Utf8 Class Initialized
INFO - 2018-07-30 21:37:26 --> Config Class Initialized
INFO - 2018-07-30 21:37:26 --> Hooks Class Initialized
INFO - 2018-07-30 21:37:26 --> URI Class Initialized
DEBUG - 2018-07-30 21:37:26 --> UTF-8 Support Enabled
INFO - 2018-07-30 21:37:26 --> Utf8 Class Initialized
INFO - 2018-07-30 21:37:26 --> Router Class Initialized
INFO - 2018-07-30 21:37:26 --> URI Class Initialized
INFO - 2018-07-30 21:37:26 --> Output Class Initialized
INFO - 2018-07-30 21:37:26 --> Security Class Initialized
INFO - 2018-07-30 21:37:26 --> Router Class Initialized
DEBUG - 2018-07-30 21:37:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 21:37:26 --> Output Class Initialized
INFO - 2018-07-30 21:37:26 --> Input Class Initialized
INFO - 2018-07-30 21:37:26 --> Security Class Initialized
INFO - 2018-07-30 21:37:26 --> Language Class Initialized
DEBUG - 2018-07-30 21:37:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 21:37:26 --> Input Class Initialized
ERROR - 2018-07-30 21:37:26 --> 404 Page Not Found: /index
INFO - 2018-07-30 21:37:26 --> Language Class Initialized
INFO - 2018-07-30 21:37:26 --> Config Class Initialized
INFO - 2018-07-30 21:37:26 --> Hooks Class Initialized
ERROR - 2018-07-30 21:37:26 --> 404 Page Not Found: /index
DEBUG - 2018-07-30 21:37:26 --> UTF-8 Support Enabled
INFO - 2018-07-30 21:37:26 --> Config Class Initialized
INFO - 2018-07-30 21:37:26 --> Utf8 Class Initialized
INFO - 2018-07-30 21:37:26 --> Hooks Class Initialized
INFO - 2018-07-30 21:37:26 --> URI Class Initialized
INFO - 2018-07-30 21:37:26 --> Router Class Initialized
DEBUG - 2018-07-30 21:37:26 --> UTF-8 Support Enabled
INFO - 2018-07-30 21:37:26 --> Utf8 Class Initialized
INFO - 2018-07-30 21:37:26 --> Output Class Initialized
INFO - 2018-07-30 21:37:26 --> Security Class Initialized
INFO - 2018-07-30 21:37:26 --> URI Class Initialized
DEBUG - 2018-07-30 21:37:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 21:37:26 --> Input Class Initialized
INFO - 2018-07-30 21:37:26 --> Language Class Initialized
ERROR - 2018-07-30 21:37:26 --> 404 Page Not Found: /index
INFO - 2018-07-30 21:37:26 --> Router Class Initialized
INFO - 2018-07-30 21:37:26 --> Config Class Initialized
INFO - 2018-07-30 21:37:26 --> Hooks Class Initialized
INFO - 2018-07-30 21:37:26 --> Output Class Initialized
DEBUG - 2018-07-30 21:37:26 --> UTF-8 Support Enabled
INFO - 2018-07-30 21:37:26 --> Security Class Initialized
INFO - 2018-07-30 21:37:26 --> Utf8 Class Initialized
INFO - 2018-07-30 21:37:26 --> URI Class Initialized
INFO - 2018-07-30 21:37:26 --> Router Class Initialized
DEBUG - 2018-07-30 21:37:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 21:37:26 --> Output Class Initialized
INFO - 2018-07-30 21:37:26 --> Security Class Initialized
DEBUG - 2018-07-30 21:37:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 21:37:26 --> Input Class Initialized
INFO - 2018-07-30 21:37:26 --> Language Class Initialized
ERROR - 2018-07-30 21:37:26 --> 404 Page Not Found: /index
INFO - 2018-07-30 21:37:26 --> Input Class Initialized
INFO - 2018-07-30 21:37:26 --> Language Class Initialized
ERROR - 2018-07-30 21:37:26 --> 404 Page Not Found: /index
INFO - 2018-07-30 21:37:26 --> Config Class Initialized
INFO - 2018-07-30 21:37:26 --> Hooks Class Initialized
DEBUG - 2018-07-30 21:37:26 --> UTF-8 Support Enabled
INFO - 2018-07-30 21:37:26 --> Utf8 Class Initialized
INFO - 2018-07-30 21:37:26 --> URI Class Initialized
INFO - 2018-07-30 21:37:26 --> Router Class Initialized
INFO - 2018-07-30 21:37:26 --> Output Class Initialized
INFO - 2018-07-30 21:37:26 --> Security Class Initialized
DEBUG - 2018-07-30 21:37:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 21:37:26 --> Input Class Initialized
INFO - 2018-07-30 21:37:26 --> Language Class Initialized
ERROR - 2018-07-30 21:37:26 --> 404 Page Not Found: /index
INFO - 2018-07-30 21:37:30 --> Config Class Initialized
INFO - 2018-07-30 21:37:30 --> Hooks Class Initialized
DEBUG - 2018-07-30 21:37:30 --> UTF-8 Support Enabled
INFO - 2018-07-30 21:37:30 --> Utf8 Class Initialized
INFO - 2018-07-30 21:37:30 --> URI Class Initialized
INFO - 2018-07-30 21:37:30 --> Router Class Initialized
INFO - 2018-07-30 21:37:30 --> Output Class Initialized
INFO - 2018-07-30 21:37:30 --> Security Class Initialized
DEBUG - 2018-07-30 21:37:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 21:37:30 --> Input Class Initialized
INFO - 2018-07-30 21:37:30 --> Language Class Initialized
INFO - 2018-07-30 21:37:30 --> Language Class Initialized
INFO - 2018-07-30 21:37:30 --> Config Class Initialized
INFO - 2018-07-30 21:37:30 --> Loader Class Initialized
DEBUG - 2018-07-30 21:37:30 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-30 21:37:30 --> Helper loaded: url_helper
INFO - 2018-07-30 21:37:30 --> Helper loaded: form_helper
INFO - 2018-07-30 21:37:30 --> Helper loaded: date_helper
INFO - 2018-07-30 21:37:30 --> Helper loaded: util_helper
INFO - 2018-07-30 21:37:30 --> Helper loaded: text_helper
INFO - 2018-07-30 21:37:30 --> Helper loaded: string_helper
INFO - 2018-07-30 21:37:30 --> Database Driver Class Initialized
DEBUG - 2018-07-30 21:37:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 21:37:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 21:37:30 --> Email Class Initialized
INFO - 2018-07-30 21:37:30 --> Controller Class Initialized
DEBUG - 2018-07-30 21:37:30 --> Home MX_Controller Initialized
DEBUG - 2018-07-30 21:37:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-30 21:37:30 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-30 21:37:30 --> Login MX_Controller Initialized
INFO - 2018-07-30 21:37:30 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-30 21:37:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-30 21:37:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-30 21:37:30 --> Config Class Initialized
INFO - 2018-07-30 21:37:30 --> Hooks Class Initialized
DEBUG - 2018-07-30 21:37:30 --> UTF-8 Support Enabled
INFO - 2018-07-30 21:37:30 --> Utf8 Class Initialized
INFO - 2018-07-30 21:37:30 --> URI Class Initialized
INFO - 2018-07-30 21:37:30 --> Router Class Initialized
INFO - 2018-07-30 21:37:30 --> Output Class Initialized
INFO - 2018-07-30 21:37:30 --> Security Class Initialized
DEBUG - 2018-07-30 21:37:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 21:37:30 --> Input Class Initialized
INFO - 2018-07-30 21:37:30 --> Language Class Initialized
ERROR - 2018-07-30 21:37:30 --> 404 Page Not Found: /index
INFO - 2018-07-30 21:37:30 --> Config Class Initialized
INFO - 2018-07-30 21:37:30 --> Hooks Class Initialized
DEBUG - 2018-07-30 21:37:30 --> UTF-8 Support Enabled
INFO - 2018-07-30 21:37:30 --> Utf8 Class Initialized
INFO - 2018-07-30 21:37:30 --> URI Class Initialized
INFO - 2018-07-30 21:37:30 --> Router Class Initialized
INFO - 2018-07-30 21:37:30 --> Output Class Initialized
INFO - 2018-07-30 21:37:30 --> Security Class Initialized
DEBUG - 2018-07-30 21:37:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 21:37:30 --> Input Class Initialized
INFO - 2018-07-30 21:37:30 --> Language Class Initialized
ERROR - 2018-07-30 21:37:31 --> 404 Page Not Found: /index
INFO - 2018-07-30 21:37:31 --> Config Class Initialized
INFO - 2018-07-30 21:37:31 --> Hooks Class Initialized
DEBUG - 2018-07-30 21:37:31 --> UTF-8 Support Enabled
INFO - 2018-07-30 21:37:31 --> Utf8 Class Initialized
INFO - 2018-07-30 21:37:31 --> URI Class Initialized
INFO - 2018-07-30 21:37:31 --> Router Class Initialized
INFO - 2018-07-30 21:37:31 --> Output Class Initialized
INFO - 2018-07-30 21:37:31 --> Security Class Initialized
DEBUG - 2018-07-30 21:37:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 21:37:31 --> Input Class Initialized
INFO - 2018-07-30 21:37:31 --> Language Class Initialized
ERROR - 2018-07-30 21:37:31 --> 404 Page Not Found: /index
INFO - 2018-07-30 21:39:02 --> Config Class Initialized
INFO - 2018-07-30 21:39:02 --> Hooks Class Initialized
DEBUG - 2018-07-30 21:39:02 --> UTF-8 Support Enabled
INFO - 2018-07-30 21:39:02 --> Utf8 Class Initialized
INFO - 2018-07-30 21:39:02 --> URI Class Initialized
INFO - 2018-07-30 21:39:02 --> Router Class Initialized
INFO - 2018-07-30 21:39:02 --> Output Class Initialized
INFO - 2018-07-30 21:39:02 --> Security Class Initialized
DEBUG - 2018-07-30 21:39:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 21:39:02 --> Input Class Initialized
INFO - 2018-07-30 21:39:02 --> Language Class Initialized
INFO - 2018-07-30 21:39:02 --> Language Class Initialized
INFO - 2018-07-30 21:39:02 --> Config Class Initialized
INFO - 2018-07-30 21:39:02 --> Loader Class Initialized
DEBUG - 2018-07-30 21:39:02 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-30 21:39:02 --> Helper loaded: url_helper
INFO - 2018-07-30 21:39:02 --> Helper loaded: form_helper
INFO - 2018-07-30 21:39:02 --> Helper loaded: date_helper
INFO - 2018-07-30 21:39:02 --> Helper loaded: util_helper
INFO - 2018-07-30 21:39:02 --> Helper loaded: text_helper
INFO - 2018-07-30 21:39:02 --> Helper loaded: string_helper
INFO - 2018-07-30 21:39:02 --> Database Driver Class Initialized
DEBUG - 2018-07-30 21:39:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 21:39:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 21:39:02 --> Email Class Initialized
INFO - 2018-07-30 21:39:02 --> Controller Class Initialized
DEBUG - 2018-07-30 21:39:02 --> Home MX_Controller Initialized
DEBUG - 2018-07-30 21:39:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-30 21:39:02 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-30 21:39:02 --> Login MX_Controller Initialized
INFO - 2018-07-30 21:39:02 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-30 21:39:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-30 21:39:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-30 21:39:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-07-30 21:39:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-07-30 21:39:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-07-30 21:39:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-07-30 21:39:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-07-30 21:39:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-07-30 21:39:02 --> Final output sent to browser
DEBUG - 2018-07-30 21:39:02 --> Total execution time: 0.3936
INFO - 2018-07-30 21:39:04 --> Config Class Initialized
INFO - 2018-07-30 21:39:05 --> Hooks Class Initialized
DEBUG - 2018-07-30 21:39:05 --> UTF-8 Support Enabled
INFO - 2018-07-30 21:39:05 --> Utf8 Class Initialized
INFO - 2018-07-30 21:39:05 --> URI Class Initialized
INFO - 2018-07-30 21:39:05 --> Router Class Initialized
INFO - 2018-07-30 21:39:05 --> Output Class Initialized
INFO - 2018-07-30 21:39:05 --> Security Class Initialized
INFO - 2018-07-30 21:39:05 --> Config Class Initialized
INFO - 2018-07-30 21:39:05 --> Hooks Class Initialized
DEBUG - 2018-07-30 21:39:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 21:39:05 --> Input Class Initialized
DEBUG - 2018-07-30 21:39:05 --> UTF-8 Support Enabled
INFO - 2018-07-30 21:39:05 --> Utf8 Class Initialized
INFO - 2018-07-30 21:39:05 --> Language Class Initialized
INFO - 2018-07-30 21:39:05 --> URI Class Initialized
ERROR - 2018-07-30 21:39:05 --> 404 Page Not Found: /index
INFO - 2018-07-30 21:39:05 --> Router Class Initialized
INFO - 2018-07-30 21:39:05 --> Output Class Initialized
INFO - 2018-07-30 21:39:05 --> Security Class Initialized
DEBUG - 2018-07-30 21:39:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 21:39:05 --> Input Class Initialized
INFO - 2018-07-30 21:39:05 --> Language Class Initialized
INFO - 2018-07-30 21:39:05 --> Language Class Initialized
INFO - 2018-07-30 21:39:05 --> Config Class Initialized
INFO - 2018-07-30 21:39:05 --> Loader Class Initialized
DEBUG - 2018-07-30 21:39:05 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-30 21:39:05 --> Helper loaded: url_helper
INFO - 2018-07-30 21:39:05 --> Helper loaded: form_helper
INFO - 2018-07-30 21:39:05 --> Helper loaded: date_helper
INFO - 2018-07-30 21:39:05 --> Config Class Initialized
INFO - 2018-07-30 21:39:05 --> Hooks Class Initialized
INFO - 2018-07-30 21:39:05 --> Helper loaded: util_helper
INFO - 2018-07-30 21:39:05 --> Helper loaded: text_helper
DEBUG - 2018-07-30 21:39:05 --> UTF-8 Support Enabled
INFO - 2018-07-30 21:39:05 --> Utf8 Class Initialized
INFO - 2018-07-30 21:39:05 --> Helper loaded: string_helper
INFO - 2018-07-30 21:39:05 --> URI Class Initialized
INFO - 2018-07-30 21:39:05 --> Database Driver Class Initialized
INFO - 2018-07-30 21:39:05 --> Router Class Initialized
INFO - 2018-07-30 21:39:05 --> Output Class Initialized
DEBUG - 2018-07-30 21:39:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 21:39:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 21:39:05 --> Security Class Initialized
INFO - 2018-07-30 21:39:05 --> Email Class Initialized
DEBUG - 2018-07-30 21:39:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 21:39:05 --> Controller Class Initialized
DEBUG - 2018-07-30 21:39:05 --> Home MX_Controller Initialized
DEBUG - 2018-07-30 21:39:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-07-30 21:39:05 --> Input Class Initialized
DEBUG - 2018-07-30 21:39:05 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-30 21:39:05 --> Login MX_Controller Initialized
INFO - 2018-07-30 21:39:05 --> Language Class Initialized
INFO - 2018-07-30 21:39:05 --> Language file loaded: language/english/data_lang.php
ERROR - 2018-07-30 21:39:05 --> 404 Page Not Found: /index
DEBUG - 2018-07-30 21:39:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-30 21:39:05 --> Config Class Initialized
INFO - 2018-07-30 21:39:05 --> Hooks Class Initialized
DEBUG - 2018-07-30 21:39:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-30 21:39:05 --> UTF-8 Support Enabled
INFO - 2018-07-30 21:39:05 --> Utf8 Class Initialized
INFO - 2018-07-30 21:39:05 --> URI Class Initialized
INFO - 2018-07-30 21:39:05 --> Router Class Initialized
INFO - 2018-07-30 21:39:05 --> Output Class Initialized
INFO - 2018-07-30 21:39:05 --> Security Class Initialized
DEBUG - 2018-07-30 21:39:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 21:39:05 --> Input Class Initialized
INFO - 2018-07-30 21:39:05 --> Language Class Initialized
ERROR - 2018-07-30 21:39:05 --> 404 Page Not Found: /index
INFO - 2018-07-30 21:40:03 --> Config Class Initialized
INFO - 2018-07-30 21:40:03 --> Hooks Class Initialized
DEBUG - 2018-07-30 21:40:03 --> UTF-8 Support Enabled
INFO - 2018-07-30 21:40:03 --> Utf8 Class Initialized
INFO - 2018-07-30 21:40:03 --> URI Class Initialized
INFO - 2018-07-30 21:40:03 --> Router Class Initialized
INFO - 2018-07-30 21:40:03 --> Output Class Initialized
INFO - 2018-07-30 21:40:03 --> Security Class Initialized
DEBUG - 2018-07-30 21:40:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 21:40:03 --> Input Class Initialized
INFO - 2018-07-30 21:40:03 --> Language Class Initialized
INFO - 2018-07-30 21:40:03 --> Language Class Initialized
INFO - 2018-07-30 21:40:03 --> Config Class Initialized
INFO - 2018-07-30 21:40:03 --> Loader Class Initialized
DEBUG - 2018-07-30 21:40:03 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-30 21:40:03 --> Helper loaded: url_helper
INFO - 2018-07-30 21:40:03 --> Helper loaded: form_helper
INFO - 2018-07-30 21:40:03 --> Helper loaded: date_helper
INFO - 2018-07-30 21:40:03 --> Helper loaded: util_helper
INFO - 2018-07-30 21:40:03 --> Helper loaded: text_helper
INFO - 2018-07-30 21:40:03 --> Helper loaded: string_helper
INFO - 2018-07-30 21:40:03 --> Database Driver Class Initialized
DEBUG - 2018-07-30 21:40:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 21:40:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 21:40:03 --> Email Class Initialized
INFO - 2018-07-30 21:40:03 --> Controller Class Initialized
DEBUG - 2018-07-30 21:40:03 --> Home MX_Controller Initialized
DEBUG - 2018-07-30 21:40:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-30 21:40:03 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-30 21:40:03 --> Login MX_Controller Initialized
INFO - 2018-07-30 21:40:03 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-30 21:40:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-30 21:40:03 --> Config Class Initialized
INFO - 2018-07-30 21:40:03 --> Hooks Class Initialized
DEBUG - 2018-07-30 21:40:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-30 21:40:03 --> UTF-8 Support Enabled
INFO - 2018-07-30 21:40:03 --> Utf8 Class Initialized
INFO - 2018-07-30 21:40:03 --> URI Class Initialized
INFO - 2018-07-30 21:40:03 --> Router Class Initialized
INFO - 2018-07-30 21:40:03 --> Output Class Initialized
INFO - 2018-07-30 21:40:03 --> Security Class Initialized
DEBUG - 2018-07-30 21:40:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 21:40:03 --> Input Class Initialized
INFO - 2018-07-30 21:40:03 --> Language Class Initialized
ERROR - 2018-07-30 21:40:03 --> 404 Page Not Found: /index
INFO - 2018-07-30 21:40:03 --> Config Class Initialized
INFO - 2018-07-30 21:40:03 --> Hooks Class Initialized
DEBUG - 2018-07-30 21:40:03 --> UTF-8 Support Enabled
INFO - 2018-07-30 21:40:03 --> Utf8 Class Initialized
INFO - 2018-07-30 21:40:03 --> URI Class Initialized
INFO - 2018-07-30 21:40:03 --> Router Class Initialized
INFO - 2018-07-30 21:40:03 --> Output Class Initialized
INFO - 2018-07-30 21:40:03 --> Security Class Initialized
DEBUG - 2018-07-30 21:40:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 21:40:03 --> Input Class Initialized
INFO - 2018-07-30 21:40:03 --> Language Class Initialized
ERROR - 2018-07-30 21:40:03 --> 404 Page Not Found: /index
INFO - 2018-07-30 21:40:03 --> Config Class Initialized
INFO - 2018-07-30 21:40:03 --> Hooks Class Initialized
DEBUG - 2018-07-30 21:40:03 --> UTF-8 Support Enabled
INFO - 2018-07-30 21:40:03 --> Utf8 Class Initialized
INFO - 2018-07-30 21:40:03 --> URI Class Initialized
INFO - 2018-07-30 21:40:03 --> Router Class Initialized
INFO - 2018-07-30 21:40:03 --> Output Class Initialized
INFO - 2018-07-30 21:40:03 --> Security Class Initialized
DEBUG - 2018-07-30 21:40:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 21:40:03 --> Input Class Initialized
INFO - 2018-07-30 21:40:03 --> Language Class Initialized
ERROR - 2018-07-30 21:40:03 --> 404 Page Not Found: /index
INFO - 2018-07-30 21:49:54 --> Config Class Initialized
INFO - 2018-07-30 21:49:54 --> Hooks Class Initialized
DEBUG - 2018-07-30 21:49:54 --> UTF-8 Support Enabled
INFO - 2018-07-30 21:49:54 --> Utf8 Class Initialized
INFO - 2018-07-30 21:49:54 --> URI Class Initialized
INFO - 2018-07-30 21:49:54 --> Router Class Initialized
INFO - 2018-07-30 21:49:54 --> Output Class Initialized
INFO - 2018-07-30 21:49:54 --> Security Class Initialized
DEBUG - 2018-07-30 21:49:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 21:49:54 --> Input Class Initialized
INFO - 2018-07-30 21:49:54 --> Language Class Initialized
INFO - 2018-07-30 21:49:54 --> Language Class Initialized
INFO - 2018-07-30 21:49:54 --> Config Class Initialized
INFO - 2018-07-30 21:49:54 --> Loader Class Initialized
DEBUG - 2018-07-30 21:49:54 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-30 21:49:54 --> Helper loaded: url_helper
INFO - 2018-07-30 21:49:54 --> Helper loaded: form_helper
INFO - 2018-07-30 21:49:54 --> Helper loaded: date_helper
INFO - 2018-07-30 21:49:54 --> Helper loaded: util_helper
INFO - 2018-07-30 21:49:54 --> Helper loaded: text_helper
INFO - 2018-07-30 21:49:55 --> Helper loaded: string_helper
INFO - 2018-07-30 21:49:55 --> Database Driver Class Initialized
DEBUG - 2018-07-30 21:49:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 21:49:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 21:49:55 --> Email Class Initialized
INFO - 2018-07-30 21:49:55 --> Controller Class Initialized
DEBUG - 2018-07-30 21:49:55 --> Home MX_Controller Initialized
DEBUG - 2018-07-30 21:49:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-30 21:49:55 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-30 21:49:55 --> Login MX_Controller Initialized
INFO - 2018-07-30 21:49:55 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-30 21:49:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-30 21:49:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-30 21:50:00 --> Config Class Initialized
INFO - 2018-07-30 21:50:00 --> Hooks Class Initialized
DEBUG - 2018-07-30 21:50:00 --> UTF-8 Support Enabled
INFO - 2018-07-30 21:50:00 --> Utf8 Class Initialized
INFO - 2018-07-30 21:50:00 --> URI Class Initialized
INFO - 2018-07-30 21:50:00 --> Router Class Initialized
INFO - 2018-07-30 21:50:00 --> Output Class Initialized
INFO - 2018-07-30 21:50:00 --> Security Class Initialized
DEBUG - 2018-07-30 21:50:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 21:50:00 --> Input Class Initialized
INFO - 2018-07-30 21:50:00 --> Language Class Initialized
INFO - 2018-07-30 21:50:00 --> Language Class Initialized
INFO - 2018-07-30 21:50:00 --> Config Class Initialized
INFO - 2018-07-30 21:50:00 --> Loader Class Initialized
DEBUG - 2018-07-30 21:50:00 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-30 21:50:00 --> Helper loaded: url_helper
INFO - 2018-07-30 21:50:00 --> Helper loaded: form_helper
INFO - 2018-07-30 21:50:00 --> Helper loaded: date_helper
INFO - 2018-07-30 21:50:00 --> Helper loaded: util_helper
INFO - 2018-07-30 21:50:00 --> Helper loaded: text_helper
INFO - 2018-07-30 21:50:00 --> Helper loaded: string_helper
INFO - 2018-07-30 21:50:00 --> Database Driver Class Initialized
DEBUG - 2018-07-30 21:50:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 21:50:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 21:50:00 --> Email Class Initialized
INFO - 2018-07-30 21:50:00 --> Controller Class Initialized
DEBUG - 2018-07-30 21:50:00 --> Home MX_Controller Initialized
DEBUG - 2018-07-30 21:50:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-30 21:50:00 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-30 21:50:00 --> Login MX_Controller Initialized
INFO - 2018-07-30 21:50:00 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-30 21:50:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-30 21:50:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-30 21:50:01 --> Config Class Initialized
INFO - 2018-07-30 21:50:01 --> Hooks Class Initialized
DEBUG - 2018-07-30 21:50:01 --> UTF-8 Support Enabled
INFO - 2018-07-30 21:50:01 --> Utf8 Class Initialized
INFO - 2018-07-30 21:50:01 --> URI Class Initialized
INFO - 2018-07-30 21:50:01 --> Router Class Initialized
INFO - 2018-07-30 21:50:01 --> Output Class Initialized
INFO - 2018-07-30 21:50:01 --> Security Class Initialized
DEBUG - 2018-07-30 21:50:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 21:50:01 --> Input Class Initialized
INFO - 2018-07-30 21:50:01 --> Language Class Initialized
ERROR - 2018-07-30 21:50:01 --> 404 Page Not Found: /index
INFO - 2018-07-30 21:50:01 --> Config Class Initialized
INFO - 2018-07-30 21:50:01 --> Hooks Class Initialized
DEBUG - 2018-07-30 21:50:01 --> UTF-8 Support Enabled
INFO - 2018-07-30 21:50:01 --> Utf8 Class Initialized
INFO - 2018-07-30 21:50:01 --> URI Class Initialized
INFO - 2018-07-30 21:50:01 --> Router Class Initialized
INFO - 2018-07-30 21:50:01 --> Output Class Initialized
INFO - 2018-07-30 21:50:01 --> Security Class Initialized
DEBUG - 2018-07-30 21:50:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 21:50:01 --> Input Class Initialized
INFO - 2018-07-30 21:50:01 --> Language Class Initialized
ERROR - 2018-07-30 21:50:01 --> 404 Page Not Found: /index
INFO - 2018-07-30 21:50:01 --> Config Class Initialized
INFO - 2018-07-30 21:50:01 --> Hooks Class Initialized
DEBUG - 2018-07-30 21:50:01 --> UTF-8 Support Enabled
INFO - 2018-07-30 21:50:01 --> Utf8 Class Initialized
INFO - 2018-07-30 21:50:01 --> URI Class Initialized
INFO - 2018-07-30 21:50:01 --> Router Class Initialized
INFO - 2018-07-30 21:50:01 --> Output Class Initialized
INFO - 2018-07-30 21:50:01 --> Security Class Initialized
DEBUG - 2018-07-30 21:50:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 21:50:01 --> Input Class Initialized
INFO - 2018-07-30 21:50:01 --> Language Class Initialized
ERROR - 2018-07-30 21:50:01 --> 404 Page Not Found: /index
INFO - 2018-07-30 21:50:02 --> Config Class Initialized
INFO - 2018-07-30 21:50:02 --> Hooks Class Initialized
DEBUG - 2018-07-30 21:50:02 --> UTF-8 Support Enabled
INFO - 2018-07-30 21:50:02 --> Utf8 Class Initialized
INFO - 2018-07-30 21:50:02 --> URI Class Initialized
INFO - 2018-07-30 21:50:02 --> Router Class Initialized
INFO - 2018-07-30 21:50:02 --> Output Class Initialized
INFO - 2018-07-30 21:50:02 --> Security Class Initialized
DEBUG - 2018-07-30 21:50:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 21:50:02 --> Input Class Initialized
INFO - 2018-07-30 21:50:02 --> Language Class Initialized
INFO - 2018-07-30 21:50:02 --> Language Class Initialized
INFO - 2018-07-30 21:50:02 --> Config Class Initialized
INFO - 2018-07-30 21:50:02 --> Loader Class Initialized
DEBUG - 2018-07-30 21:50:02 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-30 21:50:02 --> Helper loaded: url_helper
INFO - 2018-07-30 21:50:02 --> Helper loaded: form_helper
INFO - 2018-07-30 21:50:02 --> Helper loaded: date_helper
INFO - 2018-07-30 21:50:02 --> Helper loaded: util_helper
INFO - 2018-07-30 21:50:02 --> Helper loaded: text_helper
INFO - 2018-07-30 21:50:02 --> Helper loaded: string_helper
INFO - 2018-07-30 21:50:02 --> Database Driver Class Initialized
DEBUG - 2018-07-30 21:50:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 21:50:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 21:50:02 --> Email Class Initialized
INFO - 2018-07-30 21:50:02 --> Config Class Initialized
INFO - 2018-07-30 21:50:02 --> Hooks Class Initialized
INFO - 2018-07-30 21:50:02 --> Controller Class Initialized
DEBUG - 2018-07-30 21:50:02 --> Home MX_Controller Initialized
DEBUG - 2018-07-30 21:50:02 --> UTF-8 Support Enabled
INFO - 2018-07-30 21:50:02 --> Utf8 Class Initialized
DEBUG - 2018-07-30 21:50:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-07-30 21:50:02 --> URI Class Initialized
DEBUG - 2018-07-30 21:50:02 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-30 21:50:02 --> Login MX_Controller Initialized
INFO - 2018-07-30 21:50:02 --> Router Class Initialized
INFO - 2018-07-30 21:50:02 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-30 21:50:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-30 21:50:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-30 21:50:02 --> Output Class Initialized
INFO - 2018-07-30 21:50:03 --> Security Class Initialized
DEBUG - 2018-07-30 21:50:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 21:50:03 --> Input Class Initialized
INFO - 2018-07-30 21:50:03 --> Language Class Initialized
ERROR - 2018-07-30 21:50:03 --> 404 Page Not Found: /index
INFO - 2018-07-30 21:50:03 --> Config Class Initialized
INFO - 2018-07-30 21:50:03 --> Hooks Class Initialized
DEBUG - 2018-07-30 21:50:03 --> UTF-8 Support Enabled
INFO - 2018-07-30 21:50:03 --> Utf8 Class Initialized
INFO - 2018-07-30 21:50:03 --> URI Class Initialized
INFO - 2018-07-30 21:50:03 --> Router Class Initialized
INFO - 2018-07-30 21:50:03 --> Output Class Initialized
INFO - 2018-07-30 21:50:03 --> Security Class Initialized
DEBUG - 2018-07-30 21:50:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 21:50:03 --> Input Class Initialized
INFO - 2018-07-30 21:50:03 --> Language Class Initialized
ERROR - 2018-07-30 21:50:03 --> 404 Page Not Found: /index
INFO - 2018-07-30 21:50:03 --> Config Class Initialized
INFO - 2018-07-30 21:50:03 --> Hooks Class Initialized
DEBUG - 2018-07-30 21:50:03 --> UTF-8 Support Enabled
INFO - 2018-07-30 21:50:03 --> Utf8 Class Initialized
INFO - 2018-07-30 21:50:03 --> URI Class Initialized
INFO - 2018-07-30 21:50:03 --> Router Class Initialized
INFO - 2018-07-30 21:50:03 --> Output Class Initialized
INFO - 2018-07-30 21:50:03 --> Security Class Initialized
DEBUG - 2018-07-30 21:50:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 21:50:03 --> Input Class Initialized
INFO - 2018-07-30 21:50:03 --> Language Class Initialized
ERROR - 2018-07-30 21:50:03 --> 404 Page Not Found: /index
INFO - 2018-07-30 21:50:03 --> Config Class Initialized
INFO - 2018-07-30 21:50:03 --> Hooks Class Initialized
DEBUG - 2018-07-30 21:50:03 --> UTF-8 Support Enabled
INFO - 2018-07-30 21:50:03 --> Utf8 Class Initialized
INFO - 2018-07-30 21:50:03 --> URI Class Initialized
INFO - 2018-07-30 21:50:03 --> Router Class Initialized
INFO - 2018-07-30 21:50:03 --> Output Class Initialized
INFO - 2018-07-30 21:50:03 --> Security Class Initialized
DEBUG - 2018-07-30 21:50:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 21:50:03 --> Input Class Initialized
INFO - 2018-07-30 21:50:03 --> Language Class Initialized
ERROR - 2018-07-30 21:50:03 --> 404 Page Not Found: /index
INFO - 2018-07-30 21:50:03 --> Config Class Initialized
INFO - 2018-07-30 21:50:03 --> Hooks Class Initialized
DEBUG - 2018-07-30 21:50:03 --> UTF-8 Support Enabled
INFO - 2018-07-30 21:50:03 --> Utf8 Class Initialized
INFO - 2018-07-30 21:50:03 --> URI Class Initialized
INFO - 2018-07-30 21:50:03 --> Router Class Initialized
INFO - 2018-07-30 21:50:03 --> Output Class Initialized
INFO - 2018-07-30 21:50:03 --> Security Class Initialized
DEBUG - 2018-07-30 21:50:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 21:50:03 --> Input Class Initialized
INFO - 2018-07-30 21:50:03 --> Language Class Initialized
ERROR - 2018-07-30 21:50:03 --> 404 Page Not Found: /index
INFO - 2018-07-30 21:50:03 --> Config Class Initialized
INFO - 2018-07-30 21:50:03 --> Hooks Class Initialized
DEBUG - 2018-07-30 21:50:03 --> UTF-8 Support Enabled
INFO - 2018-07-30 21:50:03 --> Utf8 Class Initialized
INFO - 2018-07-30 21:50:03 --> URI Class Initialized
INFO - 2018-07-30 21:50:03 --> Router Class Initialized
INFO - 2018-07-30 21:50:03 --> Output Class Initialized
INFO - 2018-07-30 21:50:03 --> Security Class Initialized
DEBUG - 2018-07-30 21:50:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 21:50:03 --> Input Class Initialized
INFO - 2018-07-30 21:50:03 --> Language Class Initialized
ERROR - 2018-07-30 21:50:03 --> 404 Page Not Found: /index
INFO - 2018-07-30 21:50:03 --> Config Class Initialized
INFO - 2018-07-30 21:50:03 --> Hooks Class Initialized
DEBUG - 2018-07-30 21:50:03 --> UTF-8 Support Enabled
INFO - 2018-07-30 21:50:03 --> Utf8 Class Initialized
INFO - 2018-07-30 21:50:03 --> URI Class Initialized
INFO - 2018-07-30 21:50:04 --> Router Class Initialized
INFO - 2018-07-30 21:50:04 --> Output Class Initialized
INFO - 2018-07-30 21:50:04 --> Security Class Initialized
DEBUG - 2018-07-30 21:50:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 21:50:04 --> Input Class Initialized
INFO - 2018-07-30 21:50:04 --> Language Class Initialized
INFO - 2018-07-30 21:50:04 --> Language Class Initialized
INFO - 2018-07-30 21:50:04 --> Config Class Initialized
INFO - 2018-07-30 21:50:04 --> Loader Class Initialized
DEBUG - 2018-07-30 21:50:04 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-30 21:50:04 --> Helper loaded: url_helper
INFO - 2018-07-30 21:50:04 --> Helper loaded: form_helper
INFO - 2018-07-30 21:50:04 --> Helper loaded: date_helper
INFO - 2018-07-30 21:50:04 --> Helper loaded: util_helper
INFO - 2018-07-30 21:50:04 --> Helper loaded: text_helper
INFO - 2018-07-30 21:50:04 --> Helper loaded: string_helper
INFO - 2018-07-30 21:50:04 --> Database Driver Class Initialized
DEBUG - 2018-07-30 21:50:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 21:50:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 21:50:04 --> Email Class Initialized
INFO - 2018-07-30 21:50:04 --> Controller Class Initialized
DEBUG - 2018-07-30 21:50:04 --> Home MX_Controller Initialized
DEBUG - 2018-07-30 21:50:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-30 21:50:04 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-30 21:50:04 --> Login MX_Controller Initialized
INFO - 2018-07-30 21:50:04 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-30 21:50:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-30 21:50:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-30 21:50:05 --> Config Class Initialized
INFO - 2018-07-30 21:50:05 --> Hooks Class Initialized
DEBUG - 2018-07-30 21:50:05 --> UTF-8 Support Enabled
INFO - 2018-07-30 21:50:05 --> Utf8 Class Initialized
INFO - 2018-07-30 21:50:05 --> URI Class Initialized
INFO - 2018-07-30 21:50:05 --> Router Class Initialized
INFO - 2018-07-30 21:50:05 --> Output Class Initialized
INFO - 2018-07-30 21:50:05 --> Security Class Initialized
DEBUG - 2018-07-30 21:50:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 21:50:05 --> Input Class Initialized
INFO - 2018-07-30 21:50:05 --> Language Class Initialized
INFO - 2018-07-30 21:50:05 --> Language Class Initialized
INFO - 2018-07-30 21:50:05 --> Config Class Initialized
INFO - 2018-07-30 21:50:05 --> Loader Class Initialized
DEBUG - 2018-07-30 21:50:05 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-30 21:50:05 --> Helper loaded: url_helper
INFO - 2018-07-30 21:50:05 --> Helper loaded: form_helper
INFO - 2018-07-30 21:50:05 --> Helper loaded: date_helper
INFO - 2018-07-30 21:50:05 --> Helper loaded: util_helper
INFO - 2018-07-30 21:50:05 --> Helper loaded: text_helper
INFO - 2018-07-30 21:50:05 --> Helper loaded: string_helper
INFO - 2018-07-30 21:50:05 --> Database Driver Class Initialized
DEBUG - 2018-07-30 21:50:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 21:50:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 21:50:05 --> Email Class Initialized
INFO - 2018-07-30 21:50:05 --> Controller Class Initialized
DEBUG - 2018-07-30 21:50:05 --> Home MX_Controller Initialized
DEBUG - 2018-07-30 21:50:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-30 21:50:05 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
INFO - 2018-07-30 21:50:05 --> Config Class Initialized
INFO - 2018-07-30 21:50:05 --> Hooks Class Initialized
DEBUG - 2018-07-30 21:50:05 --> Login MX_Controller Initialized
DEBUG - 2018-07-30 21:50:05 --> UTF-8 Support Enabled
INFO - 2018-07-30 21:50:05 --> Language file loaded: language/english/data_lang.php
INFO - 2018-07-30 21:50:05 --> Utf8 Class Initialized
DEBUG - 2018-07-30 21:50:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-30 21:50:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-30 21:50:05 --> URI Class Initialized
INFO - 2018-07-30 21:50:05 --> Router Class Initialized
INFO - 2018-07-30 21:50:05 --> Output Class Initialized
INFO - 2018-07-30 21:50:05 --> Security Class Initialized
DEBUG - 2018-07-30 21:50:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 21:50:05 --> Input Class Initialized
INFO - 2018-07-30 21:50:05 --> Language Class Initialized
ERROR - 2018-07-30 21:50:06 --> 404 Page Not Found: /index
INFO - 2018-07-30 21:50:06 --> Config Class Initialized
INFO - 2018-07-30 21:50:06 --> Hooks Class Initialized
DEBUG - 2018-07-30 21:50:06 --> UTF-8 Support Enabled
INFO - 2018-07-30 21:50:06 --> Utf8 Class Initialized
INFO - 2018-07-30 21:50:06 --> URI Class Initialized
INFO - 2018-07-30 21:50:06 --> Router Class Initialized
INFO - 2018-07-30 21:50:06 --> Output Class Initialized
INFO - 2018-07-30 21:50:06 --> Security Class Initialized
DEBUG - 2018-07-30 21:50:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 21:50:06 --> Input Class Initialized
INFO - 2018-07-30 21:50:06 --> Language Class Initialized
ERROR - 2018-07-30 21:50:06 --> 404 Page Not Found: /index
INFO - 2018-07-30 21:50:06 --> Config Class Initialized
INFO - 2018-07-30 21:50:06 --> Hooks Class Initialized
DEBUG - 2018-07-30 21:50:06 --> UTF-8 Support Enabled
INFO - 2018-07-30 21:50:06 --> Utf8 Class Initialized
INFO - 2018-07-30 21:50:06 --> URI Class Initialized
INFO - 2018-07-30 21:50:06 --> Router Class Initialized
INFO - 2018-07-30 21:50:06 --> Output Class Initialized
INFO - 2018-07-30 21:50:06 --> Security Class Initialized
DEBUG - 2018-07-30 21:50:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 21:50:06 --> Input Class Initialized
INFO - 2018-07-30 21:50:06 --> Language Class Initialized
ERROR - 2018-07-30 21:50:06 --> 404 Page Not Found: /index
INFO - 2018-07-30 21:50:07 --> Config Class Initialized
INFO - 2018-07-30 21:50:07 --> Hooks Class Initialized
DEBUG - 2018-07-30 21:50:07 --> UTF-8 Support Enabled
INFO - 2018-07-30 21:50:07 --> Utf8 Class Initialized
INFO - 2018-07-30 21:50:07 --> URI Class Initialized
INFO - 2018-07-30 21:50:07 --> Router Class Initialized
INFO - 2018-07-30 21:50:07 --> Output Class Initialized
INFO - 2018-07-30 21:50:07 --> Security Class Initialized
DEBUG - 2018-07-30 21:50:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 21:50:07 --> Input Class Initialized
INFO - 2018-07-30 21:50:07 --> Language Class Initialized
INFO - 2018-07-30 21:50:07 --> Language Class Initialized
INFO - 2018-07-30 21:50:07 --> Config Class Initialized
INFO - 2018-07-30 21:50:07 --> Loader Class Initialized
DEBUG - 2018-07-30 21:50:07 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-30 21:50:07 --> Helper loaded: url_helper
INFO - 2018-07-30 21:50:07 --> Helper loaded: form_helper
INFO - 2018-07-30 21:50:07 --> Helper loaded: date_helper
INFO - 2018-07-30 21:50:07 --> Helper loaded: util_helper
INFO - 2018-07-30 21:50:07 --> Helper loaded: text_helper
INFO - 2018-07-30 21:50:07 --> Helper loaded: string_helper
INFO - 2018-07-30 21:50:07 --> Database Driver Class Initialized
DEBUG - 2018-07-30 21:50:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 21:50:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 21:50:07 --> Email Class Initialized
INFO - 2018-07-30 21:50:07 --> Controller Class Initialized
DEBUG - 2018-07-30 21:50:07 --> Home MX_Controller Initialized
DEBUG - 2018-07-30 21:50:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-07-30 21:50:07 --> Config Class Initialized
INFO - 2018-07-30 21:50:07 --> Hooks Class Initialized
DEBUG - 2018-07-30 21:50:07 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-30 21:50:07 --> Login MX_Controller Initialized
DEBUG - 2018-07-30 21:50:07 --> UTF-8 Support Enabled
INFO - 2018-07-30 21:50:07 --> Language file loaded: language/english/data_lang.php
INFO - 2018-07-30 21:50:07 --> Utf8 Class Initialized
DEBUG - 2018-07-30 21:50:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-30 21:50:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-30 21:50:07 --> URI Class Initialized
INFO - 2018-07-30 21:50:07 --> Router Class Initialized
INFO - 2018-07-30 21:50:07 --> Output Class Initialized
INFO - 2018-07-30 21:50:07 --> Security Class Initialized
DEBUG - 2018-07-30 21:50:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 21:50:07 --> Input Class Initialized
INFO - 2018-07-30 21:50:07 --> Language Class Initialized
ERROR - 2018-07-30 21:50:07 --> 404 Page Not Found: /index
INFO - 2018-07-30 21:50:07 --> Config Class Initialized
INFO - 2018-07-30 21:50:07 --> Hooks Class Initialized
DEBUG - 2018-07-30 21:50:07 --> UTF-8 Support Enabled
INFO - 2018-07-30 21:50:07 --> Utf8 Class Initialized
INFO - 2018-07-30 21:50:07 --> URI Class Initialized
INFO - 2018-07-30 21:50:07 --> Router Class Initialized
INFO - 2018-07-30 21:50:07 --> Output Class Initialized
INFO - 2018-07-30 21:50:07 --> Security Class Initialized
DEBUG - 2018-07-30 21:50:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 21:50:07 --> Input Class Initialized
INFO - 2018-07-30 21:50:07 --> Language Class Initialized
ERROR - 2018-07-30 21:50:07 --> 404 Page Not Found: /index
INFO - 2018-07-30 21:50:07 --> Config Class Initialized
INFO - 2018-07-30 21:50:07 --> Hooks Class Initialized
DEBUG - 2018-07-30 21:50:07 --> UTF-8 Support Enabled
INFO - 2018-07-30 21:50:07 --> Utf8 Class Initialized
INFO - 2018-07-30 21:50:07 --> URI Class Initialized
INFO - 2018-07-30 21:50:07 --> Router Class Initialized
INFO - 2018-07-30 21:50:07 --> Output Class Initialized
INFO - 2018-07-30 21:50:07 --> Security Class Initialized
DEBUG - 2018-07-30 21:50:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 21:50:07 --> Input Class Initialized
INFO - 2018-07-30 21:50:07 --> Language Class Initialized
ERROR - 2018-07-30 21:50:07 --> 404 Page Not Found: /index
INFO - 2018-07-30 21:50:23 --> Config Class Initialized
INFO - 2018-07-30 21:50:23 --> Hooks Class Initialized
DEBUG - 2018-07-30 21:50:23 --> UTF-8 Support Enabled
INFO - 2018-07-30 21:50:23 --> Utf8 Class Initialized
INFO - 2018-07-30 21:50:23 --> URI Class Initialized
INFO - 2018-07-30 21:50:23 --> Router Class Initialized
INFO - 2018-07-30 21:50:23 --> Output Class Initialized
INFO - 2018-07-30 21:50:23 --> Security Class Initialized
DEBUG - 2018-07-30 21:50:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 21:50:23 --> Input Class Initialized
INFO - 2018-07-30 21:50:23 --> Language Class Initialized
INFO - 2018-07-30 21:50:23 --> Language Class Initialized
INFO - 2018-07-30 21:50:23 --> Config Class Initialized
INFO - 2018-07-30 21:50:23 --> Loader Class Initialized
DEBUG - 2018-07-30 21:50:23 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-30 21:50:23 --> Helper loaded: url_helper
INFO - 2018-07-30 21:50:23 --> Helper loaded: form_helper
INFO - 2018-07-30 21:50:23 --> Helper loaded: date_helper
INFO - 2018-07-30 21:50:23 --> Helper loaded: util_helper
INFO - 2018-07-30 21:50:23 --> Helper loaded: text_helper
INFO - 2018-07-30 21:50:23 --> Helper loaded: string_helper
INFO - 2018-07-30 21:50:23 --> Database Driver Class Initialized
DEBUG - 2018-07-30 21:50:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 21:50:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 21:50:23 --> Email Class Initialized
INFO - 2018-07-30 21:50:23 --> Controller Class Initialized
DEBUG - 2018-07-30 21:50:23 --> Home MX_Controller Initialized
DEBUG - 2018-07-30 21:50:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-30 21:50:23 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-30 21:50:23 --> Login MX_Controller Initialized
INFO - 2018-07-30 21:50:24 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-30 21:50:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-30 21:50:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-30 21:50:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-07-30 21:50:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-07-30 21:50:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-07-30 21:50:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-07-30 21:50:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-07-30 21:50:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-07-30 21:50:24 --> Final output sent to browser
DEBUG - 2018-07-30 21:50:24 --> Total execution time: 0.5794
INFO - 2018-07-30 21:50:24 --> Config Class Initialized
INFO - 2018-07-30 21:50:24 --> Hooks Class Initialized
DEBUG - 2018-07-30 21:50:24 --> UTF-8 Support Enabled
INFO - 2018-07-30 21:50:24 --> Utf8 Class Initialized
INFO - 2018-07-30 21:50:24 --> URI Class Initialized
INFO - 2018-07-30 21:50:24 --> Config Class Initialized
INFO - 2018-07-30 21:50:24 --> Hooks Class Initialized
INFO - 2018-07-30 21:50:24 --> Router Class Initialized
DEBUG - 2018-07-30 21:50:24 --> UTF-8 Support Enabled
INFO - 2018-07-30 21:50:24 --> Utf8 Class Initialized
INFO - 2018-07-30 21:50:24 --> URI Class Initialized
INFO - 2018-07-30 21:50:24 --> Router Class Initialized
INFO - 2018-07-30 21:50:24 --> Output Class Initialized
INFO - 2018-07-30 21:50:24 --> Security Class Initialized
INFO - 2018-07-30 21:50:25 --> Output Class Initialized
INFO - 2018-07-30 21:50:25 --> Security Class Initialized
DEBUG - 2018-07-30 21:50:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 21:50:25 --> Input Class Initialized
DEBUG - 2018-07-30 21:50:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 21:50:25 --> Input Class Initialized
INFO - 2018-07-30 21:50:25 --> Language Class Initialized
INFO - 2018-07-30 21:50:25 --> Language Class Initialized
INFO - 2018-07-30 21:50:25 --> Language Class Initialized
ERROR - 2018-07-30 21:50:25 --> 404 Page Not Found: /index
INFO - 2018-07-30 21:50:25 --> Config Class Initialized
INFO - 2018-07-30 21:50:25 --> Config Class Initialized
INFO - 2018-07-30 21:50:25 --> Hooks Class Initialized
INFO - 2018-07-30 21:50:25 --> Loader Class Initialized
DEBUG - 2018-07-30 21:50:25 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
DEBUG - 2018-07-30 21:50:25 --> UTF-8 Support Enabled
INFO - 2018-07-30 21:50:25 --> Utf8 Class Initialized
INFO - 2018-07-30 21:50:25 --> Helper loaded: url_helper
INFO - 2018-07-30 21:50:25 --> URI Class Initialized
INFO - 2018-07-30 21:50:25 --> Helper loaded: form_helper
INFO - 2018-07-30 21:50:25 --> Router Class Initialized
INFO - 2018-07-30 21:50:25 --> Helper loaded: date_helper
INFO - 2018-07-30 21:50:25 --> Helper loaded: util_helper
INFO - 2018-07-30 21:50:25 --> Helper loaded: text_helper
INFO - 2018-07-30 21:50:25 --> Output Class Initialized
INFO - 2018-07-30 21:50:25 --> Helper loaded: string_helper
INFO - 2018-07-30 21:50:25 --> Security Class Initialized
DEBUG - 2018-07-30 21:50:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 21:50:25 --> Database Driver Class Initialized
INFO - 2018-07-30 21:50:25 --> Input Class Initialized
DEBUG - 2018-07-30 21:50:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 21:50:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 21:50:25 --> Language Class Initialized
ERROR - 2018-07-30 21:50:25 --> 404 Page Not Found: /index
INFO - 2018-07-30 21:50:25 --> Email Class Initialized
INFO - 2018-07-30 21:50:25 --> Controller Class Initialized
INFO - 2018-07-30 21:50:25 --> Config Class Initialized
INFO - 2018-07-30 21:50:25 --> Hooks Class Initialized
DEBUG - 2018-07-30 21:50:25 --> Home MX_Controller Initialized
DEBUG - 2018-07-30 21:50:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-30 21:50:25 --> UTF-8 Support Enabled
INFO - 2018-07-30 21:50:25 --> Utf8 Class Initialized
DEBUG - 2018-07-30 21:50:25 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-30 21:50:25 --> Login MX_Controller Initialized
INFO - 2018-07-30 21:50:25 --> URI Class Initialized
INFO - 2018-07-30 21:50:25 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-30 21:50:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-30 21:50:25 --> Router Class Initialized
DEBUG - 2018-07-30 21:50:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-30 21:50:25 --> Output Class Initialized
INFO - 2018-07-30 21:50:25 --> Security Class Initialized
DEBUG - 2018-07-30 21:50:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 21:50:25 --> Input Class Initialized
INFO - 2018-07-30 21:50:25 --> Language Class Initialized
ERROR - 2018-07-30 21:50:25 --> 404 Page Not Found: /index
INFO - 2018-07-30 21:51:13 --> Config Class Initialized
INFO - 2018-07-30 21:51:13 --> Hooks Class Initialized
DEBUG - 2018-07-30 21:51:13 --> UTF-8 Support Enabled
INFO - 2018-07-30 21:51:13 --> Utf8 Class Initialized
INFO - 2018-07-30 21:51:13 --> URI Class Initialized
INFO - 2018-07-30 21:51:13 --> Router Class Initialized
INFO - 2018-07-30 21:51:13 --> Output Class Initialized
INFO - 2018-07-30 21:51:13 --> Security Class Initialized
DEBUG - 2018-07-30 21:51:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 21:51:14 --> Input Class Initialized
INFO - 2018-07-30 21:51:14 --> Language Class Initialized
INFO - 2018-07-30 21:51:14 --> Language Class Initialized
INFO - 2018-07-30 21:51:14 --> Config Class Initialized
INFO - 2018-07-30 21:51:14 --> Loader Class Initialized
DEBUG - 2018-07-30 21:51:14 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-30 21:51:14 --> Helper loaded: url_helper
INFO - 2018-07-30 21:51:14 --> Helper loaded: form_helper
INFO - 2018-07-30 21:51:14 --> Helper loaded: date_helper
INFO - 2018-07-30 21:51:14 --> Helper loaded: util_helper
INFO - 2018-07-30 21:51:14 --> Helper loaded: text_helper
INFO - 2018-07-30 21:51:14 --> Helper loaded: string_helper
INFO - 2018-07-30 21:51:14 --> Database Driver Class Initialized
DEBUG - 2018-07-30 21:51:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 21:51:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 21:51:14 --> Email Class Initialized
INFO - 2018-07-30 21:51:14 --> Controller Class Initialized
DEBUG - 2018-07-30 21:51:14 --> Home MX_Controller Initialized
DEBUG - 2018-07-30 21:51:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-30 21:51:14 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-30 21:51:14 --> Login MX_Controller Initialized
INFO - 2018-07-30 21:51:14 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-30 21:51:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-30 21:51:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-30 21:51:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-07-30 21:51:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-07-30 21:51:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-07-30 21:51:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-07-30 21:51:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-07-30 21:51:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-07-30 21:51:14 --> Final output sent to browser
DEBUG - 2018-07-30 21:51:14 --> Total execution time: 0.4675
INFO - 2018-07-30 21:51:16 --> Config Class Initialized
INFO - 2018-07-30 21:51:16 --> Hooks Class Initialized
DEBUG - 2018-07-30 21:51:16 --> UTF-8 Support Enabled
INFO - 2018-07-30 21:51:16 --> Utf8 Class Initialized
INFO - 2018-07-30 21:51:16 --> URI Class Initialized
INFO - 2018-07-30 21:51:16 --> Config Class Initialized
INFO - 2018-07-30 21:51:16 --> Hooks Class Initialized
INFO - 2018-07-30 21:51:16 --> Router Class Initialized
INFO - 2018-07-30 21:51:16 --> Output Class Initialized
DEBUG - 2018-07-30 21:51:16 --> UTF-8 Support Enabled
INFO - 2018-07-30 21:51:16 --> Utf8 Class Initialized
INFO - 2018-07-30 21:51:16 --> Security Class Initialized
INFO - 2018-07-30 21:51:16 --> URI Class Initialized
DEBUG - 2018-07-30 21:51:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 21:51:16 --> Input Class Initialized
INFO - 2018-07-30 21:51:16 --> Router Class Initialized
INFO - 2018-07-30 21:51:16 --> Output Class Initialized
INFO - 2018-07-30 21:51:16 --> Language Class Initialized
INFO - 2018-07-30 21:51:16 --> Security Class Initialized
DEBUG - 2018-07-30 21:51:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 21:51:16 --> Input Class Initialized
INFO - 2018-07-30 21:51:16 --> Language Class Initialized
ERROR - 2018-07-30 21:51:16 --> 404 Page Not Found: /index
INFO - 2018-07-30 21:51:16 --> Language Class Initialized
INFO - 2018-07-30 21:51:16 --> Config Class Initialized
INFO - 2018-07-30 21:51:16 --> Config Class Initialized
INFO - 2018-07-30 21:51:16 --> Hooks Class Initialized
INFO - 2018-07-30 21:51:16 --> Loader Class Initialized
DEBUG - 2018-07-30 21:51:17 --> UTF-8 Support Enabled
INFO - 2018-07-30 21:51:17 --> Utf8 Class Initialized
INFO - 2018-07-30 21:51:17 --> URI Class Initialized
DEBUG - 2018-07-30 21:51:17 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-30 21:51:17 --> Router Class Initialized
INFO - 2018-07-30 21:51:17 --> Output Class Initialized
INFO - 2018-07-30 21:51:17 --> Security Class Initialized
DEBUG - 2018-07-30 21:51:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 21:51:17 --> Input Class Initialized
INFO - 2018-07-30 21:51:17 --> Language Class Initialized
INFO - 2018-07-30 21:51:17 --> Helper loaded: url_helper
INFO - 2018-07-30 21:51:17 --> Helper loaded: form_helper
ERROR - 2018-07-30 21:51:17 --> 404 Page Not Found: /index
INFO - 2018-07-30 21:51:17 --> Helper loaded: date_helper
INFO - 2018-07-30 21:51:17 --> Helper loaded: util_helper
INFO - 2018-07-30 21:51:17 --> Config Class Initialized
INFO - 2018-07-30 21:51:17 --> Hooks Class Initialized
INFO - 2018-07-30 21:51:17 --> Helper loaded: text_helper
DEBUG - 2018-07-30 21:51:17 --> UTF-8 Support Enabled
INFO - 2018-07-30 21:51:17 --> Utf8 Class Initialized
INFO - 2018-07-30 21:51:17 --> URI Class Initialized
INFO - 2018-07-30 21:51:17 --> Helper loaded: string_helper
INFO - 2018-07-30 21:51:17 --> Router Class Initialized
INFO - 2018-07-30 21:51:17 --> Database Driver Class Initialized
INFO - 2018-07-30 21:51:17 --> Output Class Initialized
INFO - 2018-07-30 21:51:17 --> Security Class Initialized
DEBUG - 2018-07-30 21:51:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 21:51:17 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-07-30 21:51:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 21:51:17 --> Input Class Initialized
INFO - 2018-07-30 21:51:17 --> Email Class Initialized
INFO - 2018-07-30 21:51:17 --> Controller Class Initialized
INFO - 2018-07-30 21:51:17 --> Language Class Initialized
DEBUG - 2018-07-30 21:51:17 --> Home MX_Controller Initialized
ERROR - 2018-07-30 21:51:17 --> 404 Page Not Found: /index
DEBUG - 2018-07-30 21:51:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-30 21:51:17 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-30 21:51:17 --> Login MX_Controller Initialized
INFO - 2018-07-30 21:51:17 --> Language file loaded: language/english/data_lang.php
INFO - 2018-07-30 21:51:17 --> Config Class Initialized
INFO - 2018-07-30 21:51:17 --> Hooks Class Initialized
DEBUG - 2018-07-30 21:51:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-30 21:51:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-30 21:51:17 --> UTF-8 Support Enabled
INFO - 2018-07-30 21:51:17 --> Utf8 Class Initialized
INFO - 2018-07-30 21:51:17 --> URI Class Initialized
INFO - 2018-07-30 21:51:17 --> Router Class Initialized
INFO - 2018-07-30 21:51:17 --> Output Class Initialized
INFO - 2018-07-30 21:51:17 --> Security Class Initialized
DEBUG - 2018-07-30 21:51:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 21:51:17 --> Input Class Initialized
INFO - 2018-07-30 21:51:17 --> Language Class Initialized
ERROR - 2018-07-30 21:51:17 --> 404 Page Not Found: /index
INFO - 2018-07-30 21:51:17 --> Config Class Initialized
INFO - 2018-07-30 21:51:17 --> Hooks Class Initialized
DEBUG - 2018-07-30 21:51:17 --> UTF-8 Support Enabled
INFO - 2018-07-30 21:51:17 --> Utf8 Class Initialized
INFO - 2018-07-30 21:51:17 --> URI Class Initialized
INFO - 2018-07-30 21:51:17 --> Router Class Initialized
INFO - 2018-07-30 21:51:17 --> Output Class Initialized
INFO - 2018-07-30 21:51:17 --> Security Class Initialized
DEBUG - 2018-07-30 21:51:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 21:51:17 --> Input Class Initialized
INFO - 2018-07-30 21:51:17 --> Language Class Initialized
ERROR - 2018-07-30 21:51:17 --> 404 Page Not Found: /index
INFO - 2018-07-30 21:51:17 --> Config Class Initialized
INFO - 2018-07-30 21:51:17 --> Hooks Class Initialized
DEBUG - 2018-07-30 21:51:17 --> UTF-8 Support Enabled
INFO - 2018-07-30 21:51:17 --> Utf8 Class Initialized
INFO - 2018-07-30 21:51:17 --> URI Class Initialized
INFO - 2018-07-30 21:51:17 --> Router Class Initialized
INFO - 2018-07-30 21:51:18 --> Output Class Initialized
INFO - 2018-07-30 21:51:18 --> Security Class Initialized
DEBUG - 2018-07-30 21:51:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 21:51:18 --> Input Class Initialized
INFO - 2018-07-30 21:51:18 --> Language Class Initialized
ERROR - 2018-07-30 21:51:18 --> 404 Page Not Found: /index
INFO - 2018-07-30 21:56:10 --> Config Class Initialized
INFO - 2018-07-30 21:56:10 --> Hooks Class Initialized
DEBUG - 2018-07-30 21:56:10 --> UTF-8 Support Enabled
INFO - 2018-07-30 21:56:10 --> Utf8 Class Initialized
INFO - 2018-07-30 21:56:10 --> URI Class Initialized
INFO - 2018-07-30 21:56:10 --> Router Class Initialized
INFO - 2018-07-30 21:56:10 --> Output Class Initialized
INFO - 2018-07-30 21:56:10 --> Security Class Initialized
DEBUG - 2018-07-30 21:56:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 21:56:10 --> Input Class Initialized
INFO - 2018-07-30 21:56:10 --> Language Class Initialized
INFO - 2018-07-30 21:56:10 --> Language Class Initialized
INFO - 2018-07-30 21:56:10 --> Config Class Initialized
INFO - 2018-07-30 21:56:10 --> Loader Class Initialized
DEBUG - 2018-07-30 21:56:10 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-30 21:56:10 --> Helper loaded: url_helper
INFO - 2018-07-30 21:56:10 --> Helper loaded: form_helper
INFO - 2018-07-30 21:56:10 --> Helper loaded: date_helper
INFO - 2018-07-30 21:56:10 --> Helper loaded: util_helper
INFO - 2018-07-30 21:56:10 --> Helper loaded: text_helper
INFO - 2018-07-30 21:56:10 --> Helper loaded: string_helper
INFO - 2018-07-30 21:56:10 --> Database Driver Class Initialized
DEBUG - 2018-07-30 21:56:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 21:56:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 21:56:10 --> Email Class Initialized
INFO - 2018-07-30 21:56:10 --> Controller Class Initialized
DEBUG - 2018-07-30 21:56:10 --> Home MX_Controller Initialized
DEBUG - 2018-07-30 21:56:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-30 21:56:10 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-30 21:56:10 --> Login MX_Controller Initialized
INFO - 2018-07-30 21:56:10 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-30 21:56:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-30 21:56:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-30 21:56:11 --> Config Class Initialized
INFO - 2018-07-30 21:56:11 --> Hooks Class Initialized
DEBUG - 2018-07-30 21:56:11 --> UTF-8 Support Enabled
INFO - 2018-07-30 21:56:11 --> Utf8 Class Initialized
INFO - 2018-07-30 21:56:11 --> URI Class Initialized
INFO - 2018-07-30 21:56:11 --> Router Class Initialized
INFO - 2018-07-30 21:56:11 --> Output Class Initialized
INFO - 2018-07-30 21:56:11 --> Security Class Initialized
DEBUG - 2018-07-30 21:56:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 21:56:11 --> Input Class Initialized
INFO - 2018-07-30 21:56:11 --> Language Class Initialized
ERROR - 2018-07-30 21:56:11 --> 404 Page Not Found: /index
INFO - 2018-07-30 21:56:11 --> Config Class Initialized
INFO - 2018-07-30 21:56:11 --> Hooks Class Initialized
DEBUG - 2018-07-30 21:56:11 --> UTF-8 Support Enabled
INFO - 2018-07-30 21:56:11 --> Utf8 Class Initialized
INFO - 2018-07-30 21:56:11 --> URI Class Initialized
INFO - 2018-07-30 21:56:11 --> Router Class Initialized
INFO - 2018-07-30 21:56:11 --> Output Class Initialized
INFO - 2018-07-30 21:56:11 --> Security Class Initialized
DEBUG - 2018-07-30 21:56:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 21:56:11 --> Input Class Initialized
INFO - 2018-07-30 21:56:11 --> Language Class Initialized
ERROR - 2018-07-30 21:56:11 --> 404 Page Not Found: /index
INFO - 2018-07-30 21:56:11 --> Config Class Initialized
INFO - 2018-07-30 21:56:11 --> Hooks Class Initialized
DEBUG - 2018-07-30 21:56:11 --> UTF-8 Support Enabled
INFO - 2018-07-30 21:56:11 --> Utf8 Class Initialized
INFO - 2018-07-30 21:56:11 --> URI Class Initialized
INFO - 2018-07-30 21:56:11 --> Router Class Initialized
INFO - 2018-07-30 21:56:11 --> Output Class Initialized
INFO - 2018-07-30 21:56:11 --> Security Class Initialized
DEBUG - 2018-07-30 21:56:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 21:56:11 --> Input Class Initialized
INFO - 2018-07-30 21:56:11 --> Language Class Initialized
ERROR - 2018-07-30 21:56:11 --> 404 Page Not Found: /index
INFO - 2018-07-30 21:56:11 --> Config Class Initialized
INFO - 2018-07-30 21:56:11 --> Hooks Class Initialized
DEBUG - 2018-07-30 21:56:11 --> UTF-8 Support Enabled
INFO - 2018-07-30 21:56:11 --> Utf8 Class Initialized
INFO - 2018-07-30 21:56:11 --> URI Class Initialized
INFO - 2018-07-30 21:56:11 --> Router Class Initialized
INFO - 2018-07-30 21:56:11 --> Output Class Initialized
INFO - 2018-07-30 21:56:11 --> Security Class Initialized
DEBUG - 2018-07-30 21:56:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 21:56:11 --> Input Class Initialized
INFO - 2018-07-30 21:56:11 --> Language Class Initialized
ERROR - 2018-07-30 21:56:11 --> 404 Page Not Found: /index
INFO - 2018-07-30 21:56:11 --> Config Class Initialized
INFO - 2018-07-30 21:56:11 --> Hooks Class Initialized
DEBUG - 2018-07-30 21:56:11 --> UTF-8 Support Enabled
INFO - 2018-07-30 21:56:11 --> Utf8 Class Initialized
INFO - 2018-07-30 21:56:11 --> URI Class Initialized
INFO - 2018-07-30 21:56:11 --> Router Class Initialized
INFO - 2018-07-30 21:56:11 --> Output Class Initialized
INFO - 2018-07-30 21:56:11 --> Security Class Initialized
DEBUG - 2018-07-30 21:56:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 21:56:12 --> Input Class Initialized
INFO - 2018-07-30 21:56:12 --> Language Class Initialized
ERROR - 2018-07-30 21:56:12 --> 404 Page Not Found: /index
INFO - 2018-07-30 21:56:12 --> Config Class Initialized
INFO - 2018-07-30 21:56:12 --> Hooks Class Initialized
DEBUG - 2018-07-30 21:56:12 --> UTF-8 Support Enabled
INFO - 2018-07-30 21:56:12 --> Utf8 Class Initialized
INFO - 2018-07-30 21:56:12 --> URI Class Initialized
INFO - 2018-07-30 21:56:12 --> Router Class Initialized
INFO - 2018-07-30 21:56:12 --> Output Class Initialized
INFO - 2018-07-30 21:56:12 --> Security Class Initialized
DEBUG - 2018-07-30 21:56:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 21:56:12 --> Input Class Initialized
INFO - 2018-07-30 21:56:12 --> Language Class Initialized
ERROR - 2018-07-30 21:56:12 --> 404 Page Not Found: /index
INFO - 2018-07-30 21:56:14 --> Config Class Initialized
INFO - 2018-07-30 21:56:14 --> Hooks Class Initialized
DEBUG - 2018-07-30 21:56:14 --> UTF-8 Support Enabled
INFO - 2018-07-30 21:56:14 --> Utf8 Class Initialized
INFO - 2018-07-30 21:56:14 --> URI Class Initialized
INFO - 2018-07-30 21:56:14 --> Router Class Initialized
INFO - 2018-07-30 21:56:14 --> Output Class Initialized
INFO - 2018-07-30 21:56:14 --> Security Class Initialized
DEBUG - 2018-07-30 21:56:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 21:56:14 --> Input Class Initialized
INFO - 2018-07-30 21:56:14 --> Language Class Initialized
INFO - 2018-07-30 21:56:14 --> Language Class Initialized
INFO - 2018-07-30 21:56:14 --> Config Class Initialized
INFO - 2018-07-30 21:56:14 --> Loader Class Initialized
DEBUG - 2018-07-30 21:56:14 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-30 21:56:14 --> Helper loaded: url_helper
INFO - 2018-07-30 21:56:14 --> Helper loaded: form_helper
INFO - 2018-07-30 21:56:14 --> Helper loaded: date_helper
INFO - 2018-07-30 21:56:14 --> Helper loaded: util_helper
INFO - 2018-07-30 21:56:14 --> Helper loaded: text_helper
INFO - 2018-07-30 21:56:14 --> Helper loaded: string_helper
INFO - 2018-07-30 21:56:14 --> Database Driver Class Initialized
DEBUG - 2018-07-30 21:56:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 21:56:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 21:56:14 --> Config Class Initialized
INFO - 2018-07-30 21:56:14 --> Hooks Class Initialized
INFO - 2018-07-30 21:56:14 --> Email Class Initialized
INFO - 2018-07-30 21:56:14 --> Controller Class Initialized
DEBUG - 2018-07-30 21:56:14 --> UTF-8 Support Enabled
INFO - 2018-07-30 21:56:14 --> Utf8 Class Initialized
DEBUG - 2018-07-30 21:56:14 --> Home MX_Controller Initialized
INFO - 2018-07-30 21:56:14 --> URI Class Initialized
DEBUG - 2018-07-30 21:56:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-07-30 21:56:14 --> Router Class Initialized
DEBUG - 2018-07-30 21:56:14 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-30 21:56:14 --> Login MX_Controller Initialized
INFO - 2018-07-30 21:56:14 --> Output Class Initialized
INFO - 2018-07-30 21:56:14 --> Language file loaded: language/english/data_lang.php
INFO - 2018-07-30 21:56:14 --> Security Class Initialized
DEBUG - 2018-07-30 21:56:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-30 21:56:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 21:56:14 --> Input Class Initialized
DEBUG - 2018-07-30 21:56:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-30 21:56:14 --> Language Class Initialized
ERROR - 2018-07-30 21:56:14 --> 404 Page Not Found: /index
INFO - 2018-07-30 21:56:14 --> Config Class Initialized
INFO - 2018-07-30 21:56:14 --> Hooks Class Initialized
DEBUG - 2018-07-30 21:56:14 --> UTF-8 Support Enabled
INFO - 2018-07-30 21:56:14 --> Utf8 Class Initialized
INFO - 2018-07-30 21:56:14 --> URI Class Initialized
INFO - 2018-07-30 21:56:14 --> Router Class Initialized
INFO - 2018-07-30 21:56:14 --> Output Class Initialized
INFO - 2018-07-30 21:56:14 --> Security Class Initialized
DEBUG - 2018-07-30 21:56:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 21:56:14 --> Input Class Initialized
INFO - 2018-07-30 21:56:14 --> Language Class Initialized
ERROR - 2018-07-30 21:56:14 --> 404 Page Not Found: /index
INFO - 2018-07-30 21:56:14 --> Config Class Initialized
INFO - 2018-07-30 21:56:14 --> Hooks Class Initialized
DEBUG - 2018-07-30 21:56:14 --> UTF-8 Support Enabled
INFO - 2018-07-30 21:56:14 --> Utf8 Class Initialized
INFO - 2018-07-30 21:56:14 --> URI Class Initialized
INFO - 2018-07-30 21:56:14 --> Router Class Initialized
INFO - 2018-07-30 21:56:14 --> Output Class Initialized
INFO - 2018-07-30 21:56:14 --> Security Class Initialized
DEBUG - 2018-07-30 21:56:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 21:56:14 --> Input Class Initialized
INFO - 2018-07-30 21:56:14 --> Language Class Initialized
ERROR - 2018-07-30 21:56:14 --> 404 Page Not Found: /index
INFO - 2018-07-30 21:56:17 --> Config Class Initialized
INFO - 2018-07-30 21:56:17 --> Hooks Class Initialized
DEBUG - 2018-07-30 21:56:17 --> UTF-8 Support Enabled
INFO - 2018-07-30 21:56:17 --> Utf8 Class Initialized
INFO - 2018-07-30 21:56:17 --> URI Class Initialized
INFO - 2018-07-30 21:56:17 --> Router Class Initialized
INFO - 2018-07-30 21:56:17 --> Output Class Initialized
INFO - 2018-07-30 21:56:17 --> Security Class Initialized
DEBUG - 2018-07-30 21:56:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 21:56:17 --> Input Class Initialized
INFO - 2018-07-30 21:56:17 --> Language Class Initialized
INFO - 2018-07-30 21:56:17 --> Language Class Initialized
INFO - 2018-07-30 21:56:17 --> Config Class Initialized
INFO - 2018-07-30 21:56:17 --> Loader Class Initialized
DEBUG - 2018-07-30 21:56:17 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-30 21:56:17 --> Helper loaded: url_helper
INFO - 2018-07-30 21:56:17 --> Helper loaded: form_helper
INFO - 2018-07-30 21:56:17 --> Helper loaded: date_helper
INFO - 2018-07-30 21:56:17 --> Helper loaded: util_helper
INFO - 2018-07-30 21:56:17 --> Helper loaded: text_helper
INFO - 2018-07-30 21:56:17 --> Helper loaded: string_helper
INFO - 2018-07-30 21:56:17 --> Database Driver Class Initialized
DEBUG - 2018-07-30 21:56:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 21:56:18 --> Config Class Initialized
INFO - 2018-07-30 21:56:18 --> Hooks Class Initialized
INFO - 2018-07-30 21:56:18 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-07-30 21:56:18 --> UTF-8 Support Enabled
INFO - 2018-07-30 21:56:18 --> Email Class Initialized
INFO - 2018-07-30 21:56:18 --> Utf8 Class Initialized
INFO - 2018-07-30 21:56:18 --> Controller Class Initialized
DEBUG - 2018-07-30 21:56:18 --> Home MX_Controller Initialized
INFO - 2018-07-30 21:56:18 --> URI Class Initialized
DEBUG - 2018-07-30 21:56:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-07-30 21:56:18 --> Router Class Initialized
DEBUG - 2018-07-30 21:56:18 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-30 21:56:18 --> Login MX_Controller Initialized
INFO - 2018-07-30 21:56:18 --> Output Class Initialized
INFO - 2018-07-30 21:56:18 --> Language file loaded: language/english/data_lang.php
INFO - 2018-07-30 21:56:18 --> Security Class Initialized
DEBUG - 2018-07-30 21:56:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-30 21:56:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 21:56:18 --> Input Class Initialized
DEBUG - 2018-07-30 21:56:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-30 21:56:18 --> Language Class Initialized
ERROR - 2018-07-30 21:56:18 --> 404 Page Not Found: /index
INFO - 2018-07-30 21:56:18 --> Config Class Initialized
INFO - 2018-07-30 21:56:18 --> Hooks Class Initialized
DEBUG - 2018-07-30 21:56:18 --> UTF-8 Support Enabled
INFO - 2018-07-30 21:56:18 --> Utf8 Class Initialized
INFO - 2018-07-30 21:56:18 --> URI Class Initialized
INFO - 2018-07-30 21:56:18 --> Router Class Initialized
INFO - 2018-07-30 21:56:18 --> Output Class Initialized
INFO - 2018-07-30 21:56:18 --> Security Class Initialized
DEBUG - 2018-07-30 21:56:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 21:56:18 --> Input Class Initialized
INFO - 2018-07-30 21:56:18 --> Language Class Initialized
ERROR - 2018-07-30 21:56:18 --> 404 Page Not Found: /index
INFO - 2018-07-30 21:56:18 --> Config Class Initialized
INFO - 2018-07-30 21:56:18 --> Hooks Class Initialized
DEBUG - 2018-07-30 21:56:18 --> UTF-8 Support Enabled
INFO - 2018-07-30 21:56:18 --> Utf8 Class Initialized
INFO - 2018-07-30 21:56:18 --> URI Class Initialized
INFO - 2018-07-30 21:56:18 --> Router Class Initialized
INFO - 2018-07-30 21:56:18 --> Output Class Initialized
INFO - 2018-07-30 21:56:18 --> Security Class Initialized
DEBUG - 2018-07-30 21:56:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 21:56:18 --> Input Class Initialized
INFO - 2018-07-30 21:56:18 --> Language Class Initialized
ERROR - 2018-07-30 21:56:18 --> 404 Page Not Found: /index
INFO - 2018-07-30 21:56:21 --> Config Class Initialized
INFO - 2018-07-30 21:56:21 --> Hooks Class Initialized
DEBUG - 2018-07-30 21:56:21 --> UTF-8 Support Enabled
INFO - 2018-07-30 21:56:21 --> Utf8 Class Initialized
INFO - 2018-07-30 21:56:21 --> URI Class Initialized
INFO - 2018-07-30 21:56:21 --> Router Class Initialized
INFO - 2018-07-30 21:56:21 --> Output Class Initialized
INFO - 2018-07-30 21:56:21 --> Security Class Initialized
DEBUG - 2018-07-30 21:56:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 21:56:21 --> Input Class Initialized
INFO - 2018-07-30 21:56:21 --> Language Class Initialized
INFO - 2018-07-30 21:56:21 --> Language Class Initialized
INFO - 2018-07-30 21:56:21 --> Config Class Initialized
INFO - 2018-07-30 21:56:21 --> Loader Class Initialized
DEBUG - 2018-07-30 21:56:21 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-30 21:56:21 --> Helper loaded: url_helper
INFO - 2018-07-30 21:56:21 --> Helper loaded: form_helper
INFO - 2018-07-30 21:56:21 --> Helper loaded: date_helper
INFO - 2018-07-30 21:56:21 --> Helper loaded: util_helper
INFO - 2018-07-30 21:56:21 --> Helper loaded: text_helper
INFO - 2018-07-30 21:56:21 --> Helper loaded: string_helper
INFO - 2018-07-30 21:56:21 --> Database Driver Class Initialized
DEBUG - 2018-07-30 21:56:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 21:56:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 21:56:21 --> Config Class Initialized
INFO - 2018-07-30 21:56:21 --> Hooks Class Initialized
INFO - 2018-07-30 21:56:21 --> Email Class Initialized
INFO - 2018-07-30 21:56:21 --> Controller Class Initialized
DEBUG - 2018-07-30 21:56:21 --> UTF-8 Support Enabled
INFO - 2018-07-30 21:56:21 --> Utf8 Class Initialized
DEBUG - 2018-07-30 21:56:21 --> Home MX_Controller Initialized
INFO - 2018-07-30 21:56:21 --> URI Class Initialized
INFO - 2018-07-30 21:56:21 --> Router Class Initialized
INFO - 2018-07-30 21:56:21 --> Output Class Initialized
INFO - 2018-07-30 21:56:21 --> Security Class Initialized
DEBUG - 2018-07-30 21:56:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 21:56:21 --> Input Class Initialized
INFO - 2018-07-30 21:56:21 --> Language Class Initialized
DEBUG - 2018-07-30 21:56:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
ERROR - 2018-07-30 21:56:21 --> 404 Page Not Found: /index
INFO - 2018-07-30 21:56:21 --> Config Class Initialized
DEBUG - 2018-07-30 21:56:21 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-30 21:56:21 --> Login MX_Controller Initialized
INFO - 2018-07-30 21:56:21 --> Hooks Class Initialized
INFO - 2018-07-30 21:56:21 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-30 21:56:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-30 21:56:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-30 21:56:21 --> UTF-8 Support Enabled
INFO - 2018-07-30 21:56:22 --> Utf8 Class Initialized
INFO - 2018-07-30 21:56:22 --> URI Class Initialized
INFO - 2018-07-30 21:56:22 --> Router Class Initialized
INFO - 2018-07-30 21:56:22 --> Output Class Initialized
INFO - 2018-07-30 21:56:22 --> Security Class Initialized
DEBUG - 2018-07-30 21:56:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 21:56:22 --> Input Class Initialized
INFO - 2018-07-30 21:56:22 --> Language Class Initialized
ERROR - 2018-07-30 21:56:22 --> 404 Page Not Found: /index
INFO - 2018-07-30 21:56:22 --> Config Class Initialized
INFO - 2018-07-30 21:56:22 --> Hooks Class Initialized
DEBUG - 2018-07-30 21:56:22 --> UTF-8 Support Enabled
INFO - 2018-07-30 21:56:22 --> Utf8 Class Initialized
INFO - 2018-07-30 21:56:22 --> URI Class Initialized
INFO - 2018-07-30 21:56:22 --> Router Class Initialized
INFO - 2018-07-30 21:56:22 --> Output Class Initialized
INFO - 2018-07-30 21:56:22 --> Security Class Initialized
DEBUG - 2018-07-30 21:56:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 21:56:22 --> Input Class Initialized
INFO - 2018-07-30 21:56:22 --> Language Class Initialized
ERROR - 2018-07-30 21:56:22 --> 404 Page Not Found: /index
INFO - 2018-07-30 21:56:23 --> Config Class Initialized
INFO - 2018-07-30 21:56:23 --> Hooks Class Initialized
DEBUG - 2018-07-30 21:56:23 --> UTF-8 Support Enabled
INFO - 2018-07-30 21:56:23 --> Utf8 Class Initialized
INFO - 2018-07-30 21:56:23 --> URI Class Initialized
INFO - 2018-07-30 21:56:23 --> Router Class Initialized
INFO - 2018-07-30 21:56:23 --> Output Class Initialized
INFO - 2018-07-30 21:56:23 --> Security Class Initialized
DEBUG - 2018-07-30 21:56:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 21:56:23 --> Input Class Initialized
INFO - 2018-07-30 21:56:23 --> Language Class Initialized
INFO - 2018-07-30 21:56:23 --> Language Class Initialized
INFO - 2018-07-30 21:56:23 --> Config Class Initialized
INFO - 2018-07-30 21:56:23 --> Loader Class Initialized
DEBUG - 2018-07-30 21:56:23 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-30 21:56:23 --> Helper loaded: url_helper
INFO - 2018-07-30 21:56:23 --> Helper loaded: form_helper
INFO - 2018-07-30 21:56:23 --> Helper loaded: date_helper
INFO - 2018-07-30 21:56:23 --> Helper loaded: util_helper
INFO - 2018-07-30 21:56:23 --> Helper loaded: text_helper
INFO - 2018-07-30 21:56:23 --> Helper loaded: string_helper
INFO - 2018-07-30 21:56:23 --> Database Driver Class Initialized
DEBUG - 2018-07-30 21:56:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 21:56:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 21:56:23 --> Email Class Initialized
INFO - 2018-07-30 21:56:23 --> Controller Class Initialized
DEBUG - 2018-07-30 21:56:24 --> Home MX_Controller Initialized
DEBUG - 2018-07-30 21:56:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-30 21:56:24 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-30 21:56:24 --> Login MX_Controller Initialized
INFO - 2018-07-30 21:56:24 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-30 21:56:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-30 21:56:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-30 21:56:25 --> Config Class Initialized
INFO - 2018-07-30 21:56:25 --> Hooks Class Initialized
DEBUG - 2018-07-30 21:56:25 --> UTF-8 Support Enabled
INFO - 2018-07-30 21:56:25 --> Utf8 Class Initialized
INFO - 2018-07-30 21:56:25 --> URI Class Initialized
INFO - 2018-07-30 21:56:25 --> Router Class Initialized
INFO - 2018-07-30 21:56:25 --> Output Class Initialized
INFO - 2018-07-30 21:56:25 --> Security Class Initialized
DEBUG - 2018-07-30 21:56:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 21:56:25 --> Input Class Initialized
INFO - 2018-07-30 21:56:25 --> Language Class Initialized
INFO - 2018-07-30 21:56:26 --> Language Class Initialized
INFO - 2018-07-30 21:56:26 --> Config Class Initialized
INFO - 2018-07-30 21:56:26 --> Loader Class Initialized
DEBUG - 2018-07-30 21:56:26 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-30 21:56:26 --> Helper loaded: url_helper
INFO - 2018-07-30 21:56:26 --> Helper loaded: form_helper
INFO - 2018-07-30 21:56:26 --> Helper loaded: date_helper
INFO - 2018-07-30 21:56:26 --> Helper loaded: util_helper
INFO - 2018-07-30 21:56:26 --> Helper loaded: text_helper
INFO - 2018-07-30 21:56:26 --> Helper loaded: string_helper
INFO - 2018-07-30 21:56:26 --> Database Driver Class Initialized
DEBUG - 2018-07-30 21:56:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 21:56:26 --> Config Class Initialized
INFO - 2018-07-30 21:56:26 --> Hooks Class Initialized
INFO - 2018-07-30 21:56:26 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-07-30 21:56:26 --> UTF-8 Support Enabled
INFO - 2018-07-30 21:56:26 --> Email Class Initialized
INFO - 2018-07-30 21:56:26 --> Utf8 Class Initialized
INFO - 2018-07-30 21:56:26 --> Controller Class Initialized
DEBUG - 2018-07-30 21:56:26 --> Home MX_Controller Initialized
INFO - 2018-07-30 21:56:26 --> URI Class Initialized
INFO - 2018-07-30 21:56:26 --> Router Class Initialized
DEBUG - 2018-07-30 21:56:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-07-30 21:56:26 --> Output Class Initialized
DEBUG - 2018-07-30 21:56:26 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-30 21:56:26 --> Login MX_Controller Initialized
INFO - 2018-07-30 21:56:26 --> Security Class Initialized
INFO - 2018-07-30 21:56:26 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-30 21:56:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 21:56:26 --> Input Class Initialized
DEBUG - 2018-07-30 21:56:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-30 21:56:26 --> Language Class Initialized
DEBUG - 2018-07-30 21:56:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
ERROR - 2018-07-30 21:56:26 --> 404 Page Not Found: /index
INFO - 2018-07-30 21:56:26 --> Config Class Initialized
INFO - 2018-07-30 21:56:26 --> Hooks Class Initialized
DEBUG - 2018-07-30 21:56:26 --> UTF-8 Support Enabled
INFO - 2018-07-30 21:56:26 --> Utf8 Class Initialized
INFO - 2018-07-30 21:56:26 --> URI Class Initialized
INFO - 2018-07-30 21:56:26 --> Router Class Initialized
INFO - 2018-07-30 21:56:26 --> Output Class Initialized
INFO - 2018-07-30 21:56:26 --> Security Class Initialized
DEBUG - 2018-07-30 21:56:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 21:56:26 --> Input Class Initialized
INFO - 2018-07-30 21:56:26 --> Language Class Initialized
ERROR - 2018-07-30 21:56:26 --> 404 Page Not Found: /index
INFO - 2018-07-30 21:56:26 --> Config Class Initialized
INFO - 2018-07-30 21:56:26 --> Hooks Class Initialized
DEBUG - 2018-07-30 21:56:26 --> UTF-8 Support Enabled
INFO - 2018-07-30 21:56:26 --> Utf8 Class Initialized
INFO - 2018-07-30 21:56:26 --> URI Class Initialized
INFO - 2018-07-30 21:56:26 --> Router Class Initialized
INFO - 2018-07-30 21:56:26 --> Output Class Initialized
INFO - 2018-07-30 21:56:26 --> Security Class Initialized
DEBUG - 2018-07-30 21:56:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 21:56:26 --> Input Class Initialized
INFO - 2018-07-30 21:56:26 --> Language Class Initialized
ERROR - 2018-07-30 21:56:26 --> 404 Page Not Found: /index
INFO - 2018-07-30 21:56:28 --> Config Class Initialized
INFO - 2018-07-30 21:56:28 --> Hooks Class Initialized
DEBUG - 2018-07-30 21:56:28 --> UTF-8 Support Enabled
INFO - 2018-07-30 21:56:28 --> Utf8 Class Initialized
INFO - 2018-07-30 21:56:28 --> URI Class Initialized
INFO - 2018-07-30 21:56:28 --> Router Class Initialized
INFO - 2018-07-30 21:56:28 --> Output Class Initialized
INFO - 2018-07-30 21:56:28 --> Security Class Initialized
DEBUG - 2018-07-30 21:56:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 21:56:28 --> Input Class Initialized
INFO - 2018-07-30 21:56:28 --> Language Class Initialized
INFO - 2018-07-30 21:56:28 --> Language Class Initialized
INFO - 2018-07-30 21:56:28 --> Config Class Initialized
INFO - 2018-07-30 21:56:28 --> Loader Class Initialized
DEBUG - 2018-07-30 21:56:28 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-30 21:56:28 --> Helper loaded: url_helper
INFO - 2018-07-30 21:56:28 --> Helper loaded: form_helper
INFO - 2018-07-30 21:56:28 --> Helper loaded: date_helper
INFO - 2018-07-30 21:56:28 --> Helper loaded: util_helper
INFO - 2018-07-30 21:56:28 --> Helper loaded: text_helper
INFO - 2018-07-30 21:56:28 --> Helper loaded: string_helper
INFO - 2018-07-30 21:56:28 --> Database Driver Class Initialized
DEBUG - 2018-07-30 21:56:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 21:56:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 21:56:28 --> Email Class Initialized
INFO - 2018-07-30 21:56:28 --> Controller Class Initialized
DEBUG - 2018-07-30 21:56:28 --> Home MX_Controller Initialized
DEBUG - 2018-07-30 21:56:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-30 21:56:28 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-30 21:56:28 --> Login MX_Controller Initialized
INFO - 2018-07-30 21:56:28 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-30 21:56:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-30 21:56:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-30 21:56:30 --> Config Class Initialized
INFO - 2018-07-30 21:56:30 --> Hooks Class Initialized
DEBUG - 2018-07-30 21:56:30 --> UTF-8 Support Enabled
INFO - 2018-07-30 21:56:30 --> Utf8 Class Initialized
INFO - 2018-07-30 21:56:30 --> URI Class Initialized
INFO - 2018-07-30 21:56:30 --> Router Class Initialized
INFO - 2018-07-30 21:56:30 --> Output Class Initialized
INFO - 2018-07-30 21:56:30 --> Security Class Initialized
DEBUG - 2018-07-30 21:56:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 21:56:30 --> Input Class Initialized
INFO - 2018-07-30 21:56:30 --> Language Class Initialized
INFO - 2018-07-30 21:56:30 --> Language Class Initialized
INFO - 2018-07-30 21:56:30 --> Config Class Initialized
INFO - 2018-07-30 21:56:30 --> Loader Class Initialized
DEBUG - 2018-07-30 21:56:30 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-30 21:56:30 --> Helper loaded: url_helper
INFO - 2018-07-30 21:56:30 --> Helper loaded: form_helper
INFO - 2018-07-30 21:56:30 --> Helper loaded: date_helper
INFO - 2018-07-30 21:56:30 --> Helper loaded: util_helper
INFO - 2018-07-30 21:56:30 --> Helper loaded: text_helper
INFO - 2018-07-30 21:56:30 --> Helper loaded: string_helper
INFO - 2018-07-30 21:56:30 --> Database Driver Class Initialized
DEBUG - 2018-07-30 21:56:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 21:56:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 21:56:30 --> Email Class Initialized
INFO - 2018-07-30 21:56:30 --> Controller Class Initialized
DEBUG - 2018-07-30 21:56:30 --> Home MX_Controller Initialized
DEBUG - 2018-07-30 21:56:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-30 21:56:30 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-30 21:56:30 --> Login MX_Controller Initialized
INFO - 2018-07-30 21:56:30 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-30 21:56:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-30 21:56:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-30 21:56:32 --> Config Class Initialized
INFO - 2018-07-30 21:56:32 --> Hooks Class Initialized
DEBUG - 2018-07-30 21:56:32 --> UTF-8 Support Enabled
INFO - 2018-07-30 21:56:32 --> Utf8 Class Initialized
INFO - 2018-07-30 21:56:32 --> URI Class Initialized
INFO - 2018-07-30 21:56:32 --> Router Class Initialized
INFO - 2018-07-30 21:56:32 --> Output Class Initialized
INFO - 2018-07-30 21:56:32 --> Security Class Initialized
DEBUG - 2018-07-30 21:56:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 21:56:32 --> Input Class Initialized
INFO - 2018-07-30 21:56:32 --> Language Class Initialized
INFO - 2018-07-30 21:56:32 --> Language Class Initialized
INFO - 2018-07-30 21:56:32 --> Config Class Initialized
INFO - 2018-07-30 21:56:32 --> Loader Class Initialized
DEBUG - 2018-07-30 21:56:32 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-30 21:56:32 --> Helper loaded: url_helper
INFO - 2018-07-30 21:56:32 --> Helper loaded: form_helper
INFO - 2018-07-30 21:56:32 --> Helper loaded: date_helper
INFO - 2018-07-30 21:56:32 --> Helper loaded: util_helper
INFO - 2018-07-30 21:56:32 --> Helper loaded: text_helper
INFO - 2018-07-30 21:56:32 --> Helper loaded: string_helper
INFO - 2018-07-30 21:56:32 --> Database Driver Class Initialized
DEBUG - 2018-07-30 21:56:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 21:56:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 21:56:32 --> Email Class Initialized
INFO - 2018-07-30 21:56:32 --> Config Class Initialized
INFO - 2018-07-30 21:56:32 --> Hooks Class Initialized
INFO - 2018-07-30 21:56:32 --> Controller Class Initialized
DEBUG - 2018-07-30 21:56:32 --> Home MX_Controller Initialized
DEBUG - 2018-07-30 21:56:32 --> UTF-8 Support Enabled
INFO - 2018-07-30 21:56:32 --> Utf8 Class Initialized
DEBUG - 2018-07-30 21:56:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-07-30 21:56:32 --> URI Class Initialized
DEBUG - 2018-07-30 21:56:32 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-30 21:56:32 --> Login MX_Controller Initialized
INFO - 2018-07-30 21:56:32 --> Router Class Initialized
INFO - 2018-07-30 21:56:32 --> Output Class Initialized
INFO - 2018-07-30 21:56:32 --> Language file loaded: language/english/data_lang.php
INFO - 2018-07-30 21:56:32 --> Security Class Initialized
DEBUG - 2018-07-30 21:56:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 21:56:32 --> Input Class Initialized
INFO - 2018-07-30 21:56:32 --> Language Class Initialized
ERROR - 2018-07-30 21:56:32 --> 404 Page Not Found: /index
DEBUG - 2018-07-30 21:56:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-30 21:56:33 --> Config Class Initialized
INFO - 2018-07-30 21:56:33 --> Hooks Class Initialized
DEBUG - 2018-07-30 21:56:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-30 21:56:33 --> UTF-8 Support Enabled
INFO - 2018-07-30 21:56:33 --> Utf8 Class Initialized
INFO - 2018-07-30 21:56:33 --> URI Class Initialized
INFO - 2018-07-30 21:56:33 --> Router Class Initialized
INFO - 2018-07-30 21:56:33 --> Output Class Initialized
INFO - 2018-07-30 21:56:33 --> Security Class Initialized
DEBUG - 2018-07-30 21:56:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 21:56:33 --> Input Class Initialized
INFO - 2018-07-30 21:56:33 --> Language Class Initialized
ERROR - 2018-07-30 21:56:33 --> 404 Page Not Found: /index
INFO - 2018-07-30 21:56:33 --> Config Class Initialized
INFO - 2018-07-30 21:56:33 --> Hooks Class Initialized
DEBUG - 2018-07-30 21:56:33 --> UTF-8 Support Enabled
INFO - 2018-07-30 21:56:33 --> Utf8 Class Initialized
INFO - 2018-07-30 21:56:33 --> URI Class Initialized
INFO - 2018-07-30 21:56:33 --> Router Class Initialized
INFO - 2018-07-30 21:56:33 --> Output Class Initialized
INFO - 2018-07-30 21:56:33 --> Security Class Initialized
DEBUG - 2018-07-30 21:56:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 21:56:33 --> Input Class Initialized
INFO - 2018-07-30 21:56:33 --> Language Class Initialized
ERROR - 2018-07-30 21:56:33 --> 404 Page Not Found: /index
INFO - 2018-07-30 21:56:34 --> Config Class Initialized
INFO - 2018-07-30 21:56:34 --> Hooks Class Initialized
DEBUG - 2018-07-30 21:56:34 --> UTF-8 Support Enabled
INFO - 2018-07-30 21:56:34 --> Utf8 Class Initialized
INFO - 2018-07-30 21:56:34 --> URI Class Initialized
INFO - 2018-07-30 21:56:34 --> Router Class Initialized
INFO - 2018-07-30 21:56:34 --> Output Class Initialized
INFO - 2018-07-30 21:56:34 --> Security Class Initialized
DEBUG - 2018-07-30 21:56:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 21:56:34 --> Input Class Initialized
INFO - 2018-07-30 21:56:34 --> Language Class Initialized
INFO - 2018-07-30 21:56:34 --> Language Class Initialized
INFO - 2018-07-30 21:56:34 --> Config Class Initialized
INFO - 2018-07-30 21:56:34 --> Loader Class Initialized
DEBUG - 2018-07-30 21:56:34 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-30 21:56:34 --> Helper loaded: url_helper
INFO - 2018-07-30 21:56:34 --> Helper loaded: form_helper
INFO - 2018-07-30 21:56:34 --> Helper loaded: date_helper
INFO - 2018-07-30 21:56:34 --> Helper loaded: util_helper
INFO - 2018-07-30 21:56:34 --> Helper loaded: text_helper
INFO - 2018-07-30 21:56:34 --> Helper loaded: string_helper
INFO - 2018-07-30 21:56:34 --> Database Driver Class Initialized
DEBUG - 2018-07-30 21:56:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 21:56:34 --> Config Class Initialized
INFO - 2018-07-30 21:56:34 --> Hooks Class Initialized
INFO - 2018-07-30 21:56:34 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-07-30 21:56:34 --> UTF-8 Support Enabled
INFO - 2018-07-30 21:56:34 --> Email Class Initialized
INFO - 2018-07-30 21:56:34 --> Utf8 Class Initialized
INFO - 2018-07-30 21:56:34 --> Controller Class Initialized
DEBUG - 2018-07-30 21:56:34 --> Home MX_Controller Initialized
INFO - 2018-07-30 21:56:34 --> URI Class Initialized
INFO - 2018-07-30 21:56:34 --> Router Class Initialized
DEBUG - 2018-07-30 21:56:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-07-30 21:56:34 --> Output Class Initialized
DEBUG - 2018-07-30 21:56:34 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-30 21:56:34 --> Login MX_Controller Initialized
INFO - 2018-07-30 21:56:34 --> Security Class Initialized
INFO - 2018-07-30 21:56:34 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-30 21:56:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-07-30 21:56:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-30 21:56:35 --> Input Class Initialized
DEBUG - 2018-07-30 21:56:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-30 21:56:35 --> Language Class Initialized
ERROR - 2018-07-30 21:56:35 --> 404 Page Not Found: /index
INFO - 2018-07-30 21:56:35 --> Config Class Initialized
INFO - 2018-07-30 21:56:35 --> Hooks Class Initialized
DEBUG - 2018-07-30 21:56:35 --> UTF-8 Support Enabled
INFO - 2018-07-30 21:56:35 --> Utf8 Class Initialized
INFO - 2018-07-30 21:56:35 --> URI Class Initialized
INFO - 2018-07-30 21:56:35 --> Router Class Initialized
INFO - 2018-07-30 21:56:35 --> Output Class Initialized
INFO - 2018-07-30 21:56:35 --> Security Class Initialized
DEBUG - 2018-07-30 21:56:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 21:56:35 --> Input Class Initialized
INFO - 2018-07-30 21:56:35 --> Language Class Initialized
ERROR - 2018-07-30 21:56:35 --> 404 Page Not Found: /index
INFO - 2018-07-30 21:56:35 --> Config Class Initialized
INFO - 2018-07-30 21:56:35 --> Hooks Class Initialized
DEBUG - 2018-07-30 21:56:35 --> UTF-8 Support Enabled
INFO - 2018-07-30 21:56:35 --> Utf8 Class Initialized
INFO - 2018-07-30 21:56:35 --> URI Class Initialized
INFO - 2018-07-30 21:56:35 --> Router Class Initialized
INFO - 2018-07-30 21:56:35 --> Output Class Initialized
INFO - 2018-07-30 21:56:35 --> Security Class Initialized
DEBUG - 2018-07-30 21:56:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 21:56:35 --> Input Class Initialized
INFO - 2018-07-30 21:56:35 --> Language Class Initialized
ERROR - 2018-07-30 21:56:35 --> 404 Page Not Found: /index
INFO - 2018-07-30 21:56:37 --> Config Class Initialized
INFO - 2018-07-30 21:56:37 --> Hooks Class Initialized
DEBUG - 2018-07-30 21:56:37 --> UTF-8 Support Enabled
INFO - 2018-07-30 21:56:37 --> Utf8 Class Initialized
INFO - 2018-07-30 21:56:37 --> URI Class Initialized
INFO - 2018-07-30 21:56:37 --> Router Class Initialized
INFO - 2018-07-30 21:56:37 --> Output Class Initialized
INFO - 2018-07-30 21:56:37 --> Security Class Initialized
DEBUG - 2018-07-30 21:56:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 21:56:37 --> Input Class Initialized
INFO - 2018-07-30 21:56:37 --> Language Class Initialized
INFO - 2018-07-30 21:56:37 --> Language Class Initialized
INFO - 2018-07-30 21:56:37 --> Config Class Initialized
INFO - 2018-07-30 21:56:37 --> Loader Class Initialized
DEBUG - 2018-07-30 21:56:37 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-30 21:56:37 --> Helper loaded: url_helper
INFO - 2018-07-30 21:56:37 --> Helper loaded: form_helper
INFO - 2018-07-30 21:56:37 --> Helper loaded: date_helper
INFO - 2018-07-30 21:56:37 --> Helper loaded: util_helper
INFO - 2018-07-30 21:56:37 --> Helper loaded: text_helper
INFO - 2018-07-30 21:56:37 --> Helper loaded: string_helper
INFO - 2018-07-30 21:56:37 --> Database Driver Class Initialized
DEBUG - 2018-07-30 21:56:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 21:56:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 21:56:37 --> Email Class Initialized
INFO - 2018-07-30 21:56:37 --> Controller Class Initialized
DEBUG - 2018-07-30 21:56:37 --> Home MX_Controller Initialized
DEBUG - 2018-07-30 21:56:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-30 21:56:37 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-30 21:56:37 --> Login MX_Controller Initialized
INFO - 2018-07-30 21:56:37 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-30 21:56:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-30 21:56:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-30 21:56:40 --> Config Class Initialized
INFO - 2018-07-30 21:56:40 --> Hooks Class Initialized
DEBUG - 2018-07-30 21:56:40 --> UTF-8 Support Enabled
INFO - 2018-07-30 21:56:40 --> Utf8 Class Initialized
INFO - 2018-07-30 21:56:40 --> URI Class Initialized
INFO - 2018-07-30 21:56:40 --> Router Class Initialized
INFO - 2018-07-30 21:56:40 --> Output Class Initialized
INFO - 2018-07-30 21:56:40 --> Security Class Initialized
DEBUG - 2018-07-30 21:56:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 21:56:40 --> Input Class Initialized
INFO - 2018-07-30 21:56:40 --> Language Class Initialized
INFO - 2018-07-30 21:56:40 --> Language Class Initialized
INFO - 2018-07-30 21:56:40 --> Config Class Initialized
INFO - 2018-07-30 21:56:40 --> Loader Class Initialized
DEBUG - 2018-07-30 21:56:40 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-30 21:56:40 --> Helper loaded: url_helper
INFO - 2018-07-30 21:56:40 --> Helper loaded: form_helper
INFO - 2018-07-30 21:56:40 --> Helper loaded: date_helper
INFO - 2018-07-30 21:56:40 --> Helper loaded: util_helper
INFO - 2018-07-30 21:56:40 --> Helper loaded: text_helper
INFO - 2018-07-30 21:56:40 --> Helper loaded: string_helper
INFO - 2018-07-30 21:56:40 --> Database Driver Class Initialized
DEBUG - 2018-07-30 21:56:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 21:56:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 21:56:40 --> Email Class Initialized
INFO - 2018-07-30 21:56:41 --> Controller Class Initialized
DEBUG - 2018-07-30 21:56:41 --> Home MX_Controller Initialized
DEBUG - 2018-07-30 21:56:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-30 21:56:41 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-30 21:56:41 --> Login MX_Controller Initialized
INFO - 2018-07-30 21:56:41 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-30 21:56:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-30 21:56:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-30 21:56:43 --> Config Class Initialized
INFO - 2018-07-30 21:56:43 --> Hooks Class Initialized
DEBUG - 2018-07-30 21:56:43 --> UTF-8 Support Enabled
INFO - 2018-07-30 21:56:43 --> Utf8 Class Initialized
INFO - 2018-07-30 21:56:43 --> URI Class Initialized
INFO - 2018-07-30 21:56:43 --> Router Class Initialized
INFO - 2018-07-30 21:56:43 --> Output Class Initialized
INFO - 2018-07-30 21:56:43 --> Security Class Initialized
DEBUG - 2018-07-30 21:56:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 21:56:43 --> Input Class Initialized
INFO - 2018-07-30 21:56:43 --> Language Class Initialized
INFO - 2018-07-30 21:56:43 --> Language Class Initialized
INFO - 2018-07-30 21:56:43 --> Config Class Initialized
INFO - 2018-07-30 21:56:43 --> Loader Class Initialized
DEBUG - 2018-07-30 21:56:43 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-30 21:56:43 --> Helper loaded: url_helper
INFO - 2018-07-30 21:56:43 --> Helper loaded: form_helper
INFO - 2018-07-30 21:56:43 --> Helper loaded: date_helper
INFO - 2018-07-30 21:56:43 --> Helper loaded: util_helper
INFO - 2018-07-30 21:56:43 --> Helper loaded: text_helper
INFO - 2018-07-30 21:56:43 --> Helper loaded: string_helper
INFO - 2018-07-30 21:56:43 --> Database Driver Class Initialized
DEBUG - 2018-07-30 21:56:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 21:56:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 21:56:43 --> Email Class Initialized
INFO - 2018-07-30 21:56:43 --> Controller Class Initialized
DEBUG - 2018-07-30 21:56:43 --> Home MX_Controller Initialized
DEBUG - 2018-07-30 21:56:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-30 21:56:43 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-30 21:56:43 --> Login MX_Controller Initialized
INFO - 2018-07-30 21:56:43 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-30 21:56:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-30 21:56:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-30 21:56:44 --> Config Class Initialized
INFO - 2018-07-30 21:56:44 --> Hooks Class Initialized
DEBUG - 2018-07-30 21:56:44 --> UTF-8 Support Enabled
INFO - 2018-07-30 21:56:44 --> Utf8 Class Initialized
INFO - 2018-07-30 21:56:44 --> URI Class Initialized
INFO - 2018-07-30 21:56:45 --> Router Class Initialized
INFO - 2018-07-30 21:56:45 --> Output Class Initialized
INFO - 2018-07-30 21:56:45 --> Security Class Initialized
DEBUG - 2018-07-30 21:56:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 21:56:45 --> Input Class Initialized
INFO - 2018-07-30 21:56:45 --> Language Class Initialized
INFO - 2018-07-30 21:56:45 --> Language Class Initialized
INFO - 2018-07-30 21:56:45 --> Config Class Initialized
INFO - 2018-07-30 21:56:45 --> Loader Class Initialized
DEBUG - 2018-07-30 21:56:45 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-30 21:56:45 --> Helper loaded: url_helper
INFO - 2018-07-30 21:56:45 --> Helper loaded: form_helper
INFO - 2018-07-30 21:56:45 --> Helper loaded: date_helper
INFO - 2018-07-30 21:56:45 --> Helper loaded: util_helper
INFO - 2018-07-30 21:56:45 --> Helper loaded: text_helper
INFO - 2018-07-30 21:56:45 --> Helper loaded: string_helper
INFO - 2018-07-30 21:56:45 --> Database Driver Class Initialized
DEBUG - 2018-07-30 21:56:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 21:56:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 21:56:45 --> Email Class Initialized
INFO - 2018-07-30 21:56:45 --> Controller Class Initialized
DEBUG - 2018-07-30 21:56:45 --> Home MX_Controller Initialized
DEBUG - 2018-07-30 21:56:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-30 21:56:45 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-30 21:56:45 --> Login MX_Controller Initialized
INFO - 2018-07-30 21:56:45 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-30 21:56:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-30 21:56:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-30 21:56:46 --> Config Class Initialized
INFO - 2018-07-30 21:56:46 --> Hooks Class Initialized
DEBUG - 2018-07-30 21:56:46 --> UTF-8 Support Enabled
INFO - 2018-07-30 21:56:46 --> Utf8 Class Initialized
INFO - 2018-07-30 21:56:46 --> URI Class Initialized
INFO - 2018-07-30 21:56:46 --> Router Class Initialized
INFO - 2018-07-30 21:56:46 --> Output Class Initialized
INFO - 2018-07-30 21:56:46 --> Security Class Initialized
DEBUG - 2018-07-30 21:56:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 21:56:46 --> Input Class Initialized
INFO - 2018-07-30 21:56:46 --> Language Class Initialized
INFO - 2018-07-30 21:56:46 --> Language Class Initialized
INFO - 2018-07-30 21:56:46 --> Config Class Initialized
INFO - 2018-07-30 21:56:46 --> Loader Class Initialized
DEBUG - 2018-07-30 21:56:46 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-30 21:56:46 --> Helper loaded: url_helper
INFO - 2018-07-30 21:56:46 --> Helper loaded: form_helper
INFO - 2018-07-30 21:56:46 --> Helper loaded: date_helper
INFO - 2018-07-30 21:56:46 --> Helper loaded: util_helper
INFO - 2018-07-30 21:56:46 --> Helper loaded: text_helper
INFO - 2018-07-30 21:56:46 --> Helper loaded: string_helper
INFO - 2018-07-30 21:56:46 --> Database Driver Class Initialized
DEBUG - 2018-07-30 21:56:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 21:56:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 21:56:46 --> Email Class Initialized
INFO - 2018-07-30 21:56:46 --> Controller Class Initialized
DEBUG - 2018-07-30 21:56:46 --> Home MX_Controller Initialized
DEBUG - 2018-07-30 21:56:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-30 21:56:46 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-30 21:56:46 --> Login MX_Controller Initialized
INFO - 2018-07-30 21:56:46 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-30 21:56:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-30 21:56:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-30 21:56:48 --> Config Class Initialized
INFO - 2018-07-30 21:56:48 --> Hooks Class Initialized
DEBUG - 2018-07-30 21:56:48 --> UTF-8 Support Enabled
INFO - 2018-07-30 21:56:48 --> Utf8 Class Initialized
INFO - 2018-07-30 21:56:48 --> URI Class Initialized
INFO - 2018-07-30 21:56:48 --> Router Class Initialized
INFO - 2018-07-30 21:56:48 --> Output Class Initialized
INFO - 2018-07-30 21:56:48 --> Security Class Initialized
DEBUG - 2018-07-30 21:56:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 21:56:48 --> Input Class Initialized
INFO - 2018-07-30 21:56:48 --> Language Class Initialized
INFO - 2018-07-30 21:56:48 --> Language Class Initialized
INFO - 2018-07-30 21:56:48 --> Config Class Initialized
INFO - 2018-07-30 21:56:48 --> Loader Class Initialized
DEBUG - 2018-07-30 21:56:48 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-30 21:56:48 --> Helper loaded: url_helper
INFO - 2018-07-30 21:56:48 --> Helper loaded: form_helper
INFO - 2018-07-30 21:56:48 --> Helper loaded: date_helper
INFO - 2018-07-30 21:56:48 --> Helper loaded: util_helper
INFO - 2018-07-30 21:56:48 --> Helper loaded: text_helper
INFO - 2018-07-30 21:56:48 --> Helper loaded: string_helper
INFO - 2018-07-30 21:56:48 --> Database Driver Class Initialized
DEBUG - 2018-07-30 21:56:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 21:56:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 21:56:48 --> Email Class Initialized
INFO - 2018-07-30 21:56:48 --> Controller Class Initialized
DEBUG - 2018-07-30 21:56:48 --> Home MX_Controller Initialized
DEBUG - 2018-07-30 21:56:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-30 21:56:48 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-30 21:56:48 --> Login MX_Controller Initialized
INFO - 2018-07-30 21:56:48 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-30 21:56:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-30 21:56:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-30 21:56:49 --> Config Class Initialized
INFO - 2018-07-30 21:56:49 --> Hooks Class Initialized
DEBUG - 2018-07-30 21:56:49 --> UTF-8 Support Enabled
INFO - 2018-07-30 21:56:49 --> Utf8 Class Initialized
INFO - 2018-07-30 21:56:49 --> URI Class Initialized
INFO - 2018-07-30 21:56:49 --> Router Class Initialized
INFO - 2018-07-30 21:56:49 --> Output Class Initialized
INFO - 2018-07-30 21:56:49 --> Security Class Initialized
DEBUG - 2018-07-30 21:56:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 21:56:49 --> Input Class Initialized
INFO - 2018-07-30 21:56:49 --> Language Class Initialized
INFO - 2018-07-30 21:56:49 --> Language Class Initialized
INFO - 2018-07-30 21:56:49 --> Config Class Initialized
INFO - 2018-07-30 21:56:49 --> Loader Class Initialized
DEBUG - 2018-07-30 21:56:49 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-30 21:56:49 --> Helper loaded: url_helper
INFO - 2018-07-30 21:56:49 --> Helper loaded: form_helper
INFO - 2018-07-30 21:56:49 --> Helper loaded: date_helper
INFO - 2018-07-30 21:56:49 --> Helper loaded: util_helper
INFO - 2018-07-30 21:56:49 --> Helper loaded: text_helper
INFO - 2018-07-30 21:56:49 --> Helper loaded: string_helper
INFO - 2018-07-30 21:56:49 --> Database Driver Class Initialized
DEBUG - 2018-07-30 21:56:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 21:56:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 21:56:49 --> Email Class Initialized
INFO - 2018-07-30 21:56:49 --> Controller Class Initialized
DEBUG - 2018-07-30 21:56:49 --> Home MX_Controller Initialized
DEBUG - 2018-07-30 21:56:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-30 21:56:49 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-30 21:56:49 --> Login MX_Controller Initialized
INFO - 2018-07-30 21:56:49 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-30 21:56:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-30 21:56:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-30 21:56:50 --> Config Class Initialized
INFO - 2018-07-30 21:56:50 --> Hooks Class Initialized
DEBUG - 2018-07-30 21:56:50 --> UTF-8 Support Enabled
INFO - 2018-07-30 21:56:50 --> Utf8 Class Initialized
INFO - 2018-07-30 21:56:50 --> URI Class Initialized
INFO - 2018-07-30 21:56:50 --> Router Class Initialized
INFO - 2018-07-30 21:56:50 --> Output Class Initialized
INFO - 2018-07-30 21:56:50 --> Security Class Initialized
DEBUG - 2018-07-30 21:56:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 21:56:50 --> Input Class Initialized
INFO - 2018-07-30 21:56:50 --> Language Class Initialized
INFO - 2018-07-30 21:56:50 --> Language Class Initialized
INFO - 2018-07-30 21:56:50 --> Config Class Initialized
INFO - 2018-07-30 21:56:50 --> Loader Class Initialized
DEBUG - 2018-07-30 21:56:50 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-30 21:56:50 --> Helper loaded: url_helper
INFO - 2018-07-30 21:56:50 --> Helper loaded: form_helper
INFO - 2018-07-30 21:56:50 --> Helper loaded: date_helper
INFO - 2018-07-30 21:56:50 --> Helper loaded: util_helper
INFO - 2018-07-30 21:56:50 --> Helper loaded: text_helper
INFO - 2018-07-30 21:56:50 --> Helper loaded: string_helper
INFO - 2018-07-30 21:56:50 --> Database Driver Class Initialized
DEBUG - 2018-07-30 21:56:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 21:56:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 21:56:50 --> Email Class Initialized
INFO - 2018-07-30 21:56:50 --> Controller Class Initialized
DEBUG - 2018-07-30 21:56:50 --> Home MX_Controller Initialized
DEBUG - 2018-07-30 21:56:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-30 21:56:50 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-30 21:56:50 --> Login MX_Controller Initialized
INFO - 2018-07-30 21:56:50 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-30 21:56:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-30 21:56:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-30 21:56:51 --> Config Class Initialized
INFO - 2018-07-30 21:56:51 --> Hooks Class Initialized
DEBUG - 2018-07-30 21:56:51 --> UTF-8 Support Enabled
INFO - 2018-07-30 21:56:51 --> Utf8 Class Initialized
INFO - 2018-07-30 21:56:51 --> URI Class Initialized
INFO - 2018-07-30 21:56:51 --> Router Class Initialized
INFO - 2018-07-30 21:56:51 --> Output Class Initialized
INFO - 2018-07-30 21:56:51 --> Security Class Initialized
DEBUG - 2018-07-30 21:56:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 21:56:51 --> Input Class Initialized
INFO - 2018-07-30 21:56:51 --> Language Class Initialized
INFO - 2018-07-30 21:56:51 --> Language Class Initialized
INFO - 2018-07-30 21:56:51 --> Config Class Initialized
INFO - 2018-07-30 21:56:51 --> Loader Class Initialized
DEBUG - 2018-07-30 21:56:51 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-30 21:56:51 --> Helper loaded: url_helper
INFO - 2018-07-30 21:56:51 --> Helper loaded: form_helper
INFO - 2018-07-30 21:56:51 --> Helper loaded: date_helper
INFO - 2018-07-30 21:56:51 --> Helper loaded: util_helper
INFO - 2018-07-30 21:56:51 --> Helper loaded: text_helper
INFO - 2018-07-30 21:56:51 --> Helper loaded: string_helper
INFO - 2018-07-30 21:56:51 --> Database Driver Class Initialized
DEBUG - 2018-07-30 21:56:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 21:56:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 21:56:52 --> Email Class Initialized
INFO - 2018-07-30 21:56:52 --> Controller Class Initialized
DEBUG - 2018-07-30 21:56:52 --> Home MX_Controller Initialized
DEBUG - 2018-07-30 21:56:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-30 21:56:52 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-30 21:56:52 --> Login MX_Controller Initialized
INFO - 2018-07-30 21:56:52 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-30 21:56:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-30 21:56:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-30 21:56:55 --> Config Class Initialized
INFO - 2018-07-30 21:56:55 --> Hooks Class Initialized
DEBUG - 2018-07-30 21:56:55 --> UTF-8 Support Enabled
INFO - 2018-07-30 21:56:55 --> Utf8 Class Initialized
INFO - 2018-07-30 21:56:55 --> URI Class Initialized
INFO - 2018-07-30 21:56:55 --> Router Class Initialized
INFO - 2018-07-30 21:56:55 --> Output Class Initialized
INFO - 2018-07-30 21:56:55 --> Security Class Initialized
DEBUG - 2018-07-30 21:56:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 21:56:55 --> Input Class Initialized
INFO - 2018-07-30 21:56:55 --> Language Class Initialized
INFO - 2018-07-30 21:56:55 --> Language Class Initialized
INFO - 2018-07-30 21:56:55 --> Config Class Initialized
INFO - 2018-07-30 21:56:55 --> Loader Class Initialized
DEBUG - 2018-07-30 21:56:55 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-30 21:56:55 --> Helper loaded: url_helper
INFO - 2018-07-30 21:56:55 --> Helper loaded: form_helper
INFO - 2018-07-30 21:56:55 --> Helper loaded: date_helper
INFO - 2018-07-30 21:56:55 --> Helper loaded: util_helper
INFO - 2018-07-30 21:56:55 --> Helper loaded: text_helper
INFO - 2018-07-30 21:56:55 --> Helper loaded: string_helper
INFO - 2018-07-30 21:56:55 --> Database Driver Class Initialized
DEBUG - 2018-07-30 21:56:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 21:56:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 21:56:55 --> Email Class Initialized
INFO - 2018-07-30 21:56:55 --> Controller Class Initialized
DEBUG - 2018-07-30 21:56:55 --> Home MX_Controller Initialized
DEBUG - 2018-07-30 21:56:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-30 21:56:55 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-30 21:56:55 --> Login MX_Controller Initialized
INFO - 2018-07-30 21:56:55 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-30 21:56:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-30 21:56:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-30 21:56:57 --> Config Class Initialized
INFO - 2018-07-30 21:56:57 --> Hooks Class Initialized
DEBUG - 2018-07-30 21:56:57 --> UTF-8 Support Enabled
INFO - 2018-07-30 21:56:57 --> Utf8 Class Initialized
INFO - 2018-07-30 21:56:57 --> URI Class Initialized
INFO - 2018-07-30 21:56:57 --> Router Class Initialized
INFO - 2018-07-30 21:56:57 --> Output Class Initialized
INFO - 2018-07-30 21:56:57 --> Security Class Initialized
DEBUG - 2018-07-30 21:56:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 21:56:57 --> Input Class Initialized
INFO - 2018-07-30 21:56:57 --> Language Class Initialized
INFO - 2018-07-30 21:56:57 --> Language Class Initialized
INFO - 2018-07-30 21:56:57 --> Config Class Initialized
INFO - 2018-07-30 21:56:57 --> Loader Class Initialized
DEBUG - 2018-07-30 21:56:57 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-30 21:56:57 --> Helper loaded: url_helper
INFO - 2018-07-30 21:56:57 --> Helper loaded: form_helper
INFO - 2018-07-30 21:56:57 --> Helper loaded: date_helper
INFO - 2018-07-30 21:56:57 --> Helper loaded: util_helper
INFO - 2018-07-30 21:56:57 --> Helper loaded: text_helper
INFO - 2018-07-30 21:56:57 --> Helper loaded: string_helper
INFO - 2018-07-30 21:56:57 --> Database Driver Class Initialized
DEBUG - 2018-07-30 21:56:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 21:56:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 21:56:57 --> Email Class Initialized
INFO - 2018-07-30 21:56:57 --> Controller Class Initialized
DEBUG - 2018-07-30 21:56:57 --> Home MX_Controller Initialized
DEBUG - 2018-07-30 21:56:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-30 21:56:57 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-30 21:56:57 --> Login MX_Controller Initialized
INFO - 2018-07-30 21:56:57 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-30 21:56:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-30 21:56:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-30 21:56:58 --> Config Class Initialized
INFO - 2018-07-30 21:56:58 --> Hooks Class Initialized
DEBUG - 2018-07-30 21:56:58 --> UTF-8 Support Enabled
INFO - 2018-07-30 21:56:58 --> Utf8 Class Initialized
INFO - 2018-07-30 21:56:58 --> URI Class Initialized
INFO - 2018-07-30 21:56:58 --> Router Class Initialized
INFO - 2018-07-30 21:56:58 --> Output Class Initialized
INFO - 2018-07-30 21:56:58 --> Security Class Initialized
DEBUG - 2018-07-30 21:56:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 21:56:58 --> Input Class Initialized
INFO - 2018-07-30 21:56:58 --> Language Class Initialized
INFO - 2018-07-30 21:56:58 --> Language Class Initialized
INFO - 2018-07-30 21:56:58 --> Config Class Initialized
INFO - 2018-07-30 21:56:58 --> Loader Class Initialized
DEBUG - 2018-07-30 21:56:58 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-30 21:56:58 --> Helper loaded: url_helper
INFO - 2018-07-30 21:56:58 --> Helper loaded: form_helper
INFO - 2018-07-30 21:56:58 --> Helper loaded: date_helper
INFO - 2018-07-30 21:56:58 --> Helper loaded: util_helper
INFO - 2018-07-30 21:56:58 --> Helper loaded: text_helper
INFO - 2018-07-30 21:56:58 --> Helper loaded: string_helper
INFO - 2018-07-30 21:56:58 --> Database Driver Class Initialized
DEBUG - 2018-07-30 21:56:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 21:56:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 21:56:58 --> Email Class Initialized
INFO - 2018-07-30 21:56:58 --> Controller Class Initialized
DEBUG - 2018-07-30 21:56:58 --> Home MX_Controller Initialized
DEBUG - 2018-07-30 21:56:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-30 21:56:58 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-30 21:56:58 --> Login MX_Controller Initialized
INFO - 2018-07-30 21:56:58 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-30 21:56:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-30 21:56:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-30 21:56:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-07-30 21:56:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-07-30 21:56:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-07-30 21:56:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-07-30 21:56:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-07-30 21:56:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-07-30 21:56:59 --> Final output sent to browser
DEBUG - 2018-07-30 21:56:59 --> Total execution time: 0.5291
INFO - 2018-07-30 21:56:59 --> Config Class Initialized
INFO - 2018-07-30 21:56:59 --> Hooks Class Initialized
DEBUG - 2018-07-30 21:56:59 --> UTF-8 Support Enabled
INFO - 2018-07-30 21:56:59 --> Utf8 Class Initialized
INFO - 2018-07-30 21:56:59 --> URI Class Initialized
INFO - 2018-07-30 21:56:59 --> Config Class Initialized
INFO - 2018-07-30 21:56:59 --> Hooks Class Initialized
INFO - 2018-07-30 21:56:59 --> Router Class Initialized
DEBUG - 2018-07-30 21:56:59 --> UTF-8 Support Enabled
INFO - 2018-07-30 21:56:59 --> Utf8 Class Initialized
INFO - 2018-07-30 21:56:59 --> URI Class Initialized
INFO - 2018-07-30 21:56:59 --> Output Class Initialized
INFO - 2018-07-30 21:56:59 --> Router Class Initialized
INFO - 2018-07-30 21:56:59 --> Output Class Initialized
INFO - 2018-07-30 21:56:59 --> Security Class Initialized
INFO - 2018-07-30 21:56:59 --> Security Class Initialized
DEBUG - 2018-07-30 21:56:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 21:57:00 --> Input Class Initialized
DEBUG - 2018-07-30 21:57:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 21:57:00 --> Language Class Initialized
INFO - 2018-07-30 21:57:00 --> Language Class Initialized
INFO - 2018-07-30 21:57:00 --> Config Class Initialized
INFO - 2018-07-30 21:57:00 --> Input Class Initialized
INFO - 2018-07-30 21:57:00 --> Loader Class Initialized
INFO - 2018-07-30 21:57:00 --> Language Class Initialized
DEBUG - 2018-07-30 21:57:00 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
ERROR - 2018-07-30 21:57:00 --> 404 Page Not Found: /index
INFO - 2018-07-30 21:57:00 --> Helper loaded: url_helper
INFO - 2018-07-30 21:57:00 --> Helper loaded: form_helper
INFO - 2018-07-30 21:57:00 --> Config Class Initialized
INFO - 2018-07-30 21:57:00 --> Hooks Class Initialized
INFO - 2018-07-30 21:57:00 --> Helper loaded: date_helper
INFO - 2018-07-30 21:57:00 --> Helper loaded: util_helper
DEBUG - 2018-07-30 21:57:00 --> UTF-8 Support Enabled
INFO - 2018-07-30 21:57:00 --> Helper loaded: text_helper
INFO - 2018-07-30 21:57:00 --> Utf8 Class Initialized
INFO - 2018-07-30 21:57:00 --> Helper loaded: string_helper
INFO - 2018-07-30 21:57:00 --> URI Class Initialized
INFO - 2018-07-30 21:57:00 --> Router Class Initialized
INFO - 2018-07-30 21:57:00 --> Database Driver Class Initialized
INFO - 2018-07-30 21:57:00 --> Output Class Initialized
DEBUG - 2018-07-30 21:57:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 21:57:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 21:57:00 --> Security Class Initialized
INFO - 2018-07-30 21:57:00 --> Email Class Initialized
DEBUG - 2018-07-30 21:57:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 21:57:00 --> Input Class Initialized
INFO - 2018-07-30 21:57:00 --> Controller Class Initialized
DEBUG - 2018-07-30 21:57:00 --> Home MX_Controller Initialized
INFO - 2018-07-30 21:57:00 --> Language Class Initialized
ERROR - 2018-07-30 21:57:00 --> 404 Page Not Found: /index
DEBUG - 2018-07-30 21:57:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-30 21:57:00 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
INFO - 2018-07-30 21:57:00 --> Config Class Initialized
INFO - 2018-07-30 21:57:00 --> Hooks Class Initialized
DEBUG - 2018-07-30 21:57:00 --> Login MX_Controller Initialized
INFO - 2018-07-30 21:57:00 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-30 21:57:00 --> UTF-8 Support Enabled
DEBUG - 2018-07-30 21:57:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-30 21:57:00 --> Utf8 Class Initialized
DEBUG - 2018-07-30 21:57:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-30 21:57:00 --> URI Class Initialized
INFO - 2018-07-30 21:57:00 --> Router Class Initialized
INFO - 2018-07-30 21:57:00 --> Output Class Initialized
INFO - 2018-07-30 21:57:00 --> Security Class Initialized
DEBUG - 2018-07-30 21:57:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 21:57:00 --> Input Class Initialized
INFO - 2018-07-30 21:57:00 --> Language Class Initialized
ERROR - 2018-07-30 21:57:00 --> 404 Page Not Found: /index
INFO - 2018-07-30 22:52:19 --> Config Class Initialized
INFO - 2018-07-30 22:52:19 --> Hooks Class Initialized
DEBUG - 2018-07-30 22:52:19 --> UTF-8 Support Enabled
INFO - 2018-07-30 22:52:19 --> Utf8 Class Initialized
INFO - 2018-07-30 22:52:19 --> URI Class Initialized
INFO - 2018-07-30 22:52:19 --> Router Class Initialized
INFO - 2018-07-30 22:52:19 --> Output Class Initialized
INFO - 2018-07-30 22:52:19 --> Security Class Initialized
DEBUG - 2018-07-30 22:52:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 22:52:19 --> Input Class Initialized
INFO - 2018-07-30 22:52:19 --> Language Class Initialized
INFO - 2018-07-30 22:52:19 --> Language Class Initialized
INFO - 2018-07-30 22:52:19 --> Config Class Initialized
INFO - 2018-07-30 22:52:19 --> Loader Class Initialized
DEBUG - 2018-07-30 22:52:19 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-30 22:52:19 --> Helper loaded: url_helper
INFO - 2018-07-30 22:52:19 --> Helper loaded: form_helper
INFO - 2018-07-30 22:52:19 --> Helper loaded: date_helper
INFO - 2018-07-30 22:52:19 --> Helper loaded: util_helper
INFO - 2018-07-30 22:52:19 --> Helper loaded: text_helper
INFO - 2018-07-30 22:52:20 --> Helper loaded: string_helper
INFO - 2018-07-30 22:52:20 --> Database Driver Class Initialized
DEBUG - 2018-07-30 22:52:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 22:52:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 22:52:20 --> Email Class Initialized
INFO - 2018-07-30 22:52:20 --> Controller Class Initialized
DEBUG - 2018-07-30 22:52:20 --> Programs MX_Controller Initialized
INFO - 2018-07-30 22:52:20 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-30 22:52:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-07-30 22:52:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-30 22:52:20 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-30 22:52:20 --> Login MX_Controller Initialized
DEBUG - 2018-07-30 22:52:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-30 22:52:20 --> Final output sent to browser
DEBUG - 2018-07-30 22:52:20 --> Total execution time: 0.8792
INFO - 2018-07-30 22:52:33 --> Config Class Initialized
INFO - 2018-07-30 22:52:33 --> Hooks Class Initialized
DEBUG - 2018-07-30 22:52:33 --> UTF-8 Support Enabled
INFO - 2018-07-30 22:52:33 --> Utf8 Class Initialized
INFO - 2018-07-30 22:52:34 --> URI Class Initialized
INFO - 2018-07-30 22:52:34 --> Router Class Initialized
INFO - 2018-07-30 22:52:34 --> Output Class Initialized
INFO - 2018-07-30 22:52:34 --> Security Class Initialized
DEBUG - 2018-07-30 22:52:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 22:52:34 --> Input Class Initialized
INFO - 2018-07-30 22:52:34 --> Language Class Initialized
INFO - 2018-07-30 22:52:34 --> Language Class Initialized
INFO - 2018-07-30 22:52:34 --> Config Class Initialized
INFO - 2018-07-30 22:52:34 --> Loader Class Initialized
DEBUG - 2018-07-30 22:52:34 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-30 22:52:34 --> Helper loaded: url_helper
INFO - 2018-07-30 22:52:34 --> Helper loaded: form_helper
INFO - 2018-07-30 22:52:34 --> Helper loaded: date_helper
INFO - 2018-07-30 22:52:34 --> Helper loaded: util_helper
INFO - 2018-07-30 22:52:34 --> Helper loaded: text_helper
INFO - 2018-07-30 22:52:34 --> Helper loaded: string_helper
INFO - 2018-07-30 22:52:34 --> Database Driver Class Initialized
DEBUG - 2018-07-30 22:52:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 22:52:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 22:52:34 --> Email Class Initialized
INFO - 2018-07-30 22:52:34 --> Controller Class Initialized
DEBUG - 2018-07-30 22:52:34 --> Programs MX_Controller Initialized
INFO - 2018-07-30 22:52:34 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-30 22:52:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-07-30 22:52:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-30 22:52:34 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-30 22:52:34 --> Login MX_Controller Initialized
DEBUG - 2018-07-30 22:52:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-30 22:52:34 --> Final output sent to browser
DEBUG - 2018-07-30 22:52:34 --> Total execution time: 0.4132
INFO - 2018-07-30 22:52:44 --> Config Class Initialized
INFO - 2018-07-30 22:52:44 --> Hooks Class Initialized
DEBUG - 2018-07-30 22:52:44 --> UTF-8 Support Enabled
INFO - 2018-07-30 22:52:44 --> Utf8 Class Initialized
INFO - 2018-07-30 22:52:44 --> URI Class Initialized
INFO - 2018-07-30 22:52:44 --> Router Class Initialized
INFO - 2018-07-30 22:52:44 --> Output Class Initialized
INFO - 2018-07-30 22:52:44 --> Security Class Initialized
DEBUG - 2018-07-30 22:52:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 22:52:44 --> Input Class Initialized
INFO - 2018-07-30 22:52:44 --> Language Class Initialized
INFO - 2018-07-30 22:52:44 --> Language Class Initialized
INFO - 2018-07-30 22:52:44 --> Config Class Initialized
INFO - 2018-07-30 22:52:44 --> Loader Class Initialized
DEBUG - 2018-07-30 22:52:44 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-30 22:52:44 --> Helper loaded: url_helper
INFO - 2018-07-30 22:52:44 --> Helper loaded: form_helper
INFO - 2018-07-30 22:52:44 --> Helper loaded: date_helper
INFO - 2018-07-30 22:52:44 --> Helper loaded: util_helper
INFO - 2018-07-30 22:52:44 --> Helper loaded: text_helper
INFO - 2018-07-30 22:52:44 --> Helper loaded: string_helper
INFO - 2018-07-30 22:52:44 --> Database Driver Class Initialized
DEBUG - 2018-07-30 22:52:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 22:52:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 22:52:44 --> Email Class Initialized
INFO - 2018-07-30 22:52:44 --> Controller Class Initialized
DEBUG - 2018-07-30 22:52:44 --> Programs MX_Controller Initialized
INFO - 2018-07-30 22:52:44 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-30 22:52:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-07-30 22:52:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-30 22:52:44 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-30 22:52:44 --> Login MX_Controller Initialized
DEBUG - 2018-07-30 22:52:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-30 22:52:44 --> Final output sent to browser
DEBUG - 2018-07-30 22:52:44 --> Total execution time: 0.4019
INFO - 2018-07-30 22:52:51 --> Config Class Initialized
INFO - 2018-07-30 22:52:51 --> Hooks Class Initialized
DEBUG - 2018-07-30 22:52:51 --> UTF-8 Support Enabled
INFO - 2018-07-30 22:52:51 --> Utf8 Class Initialized
INFO - 2018-07-30 22:52:51 --> URI Class Initialized
INFO - 2018-07-30 22:52:51 --> Router Class Initialized
INFO - 2018-07-30 22:52:51 --> Output Class Initialized
INFO - 2018-07-30 22:52:51 --> Security Class Initialized
DEBUG - 2018-07-30 22:52:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 22:52:51 --> Input Class Initialized
INFO - 2018-07-30 22:52:51 --> Language Class Initialized
INFO - 2018-07-30 22:52:51 --> Language Class Initialized
INFO - 2018-07-30 22:52:51 --> Config Class Initialized
INFO - 2018-07-30 22:52:51 --> Loader Class Initialized
DEBUG - 2018-07-30 22:52:51 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-30 22:52:51 --> Helper loaded: url_helper
INFO - 2018-07-30 22:52:51 --> Helper loaded: form_helper
INFO - 2018-07-30 22:52:51 --> Helper loaded: date_helper
INFO - 2018-07-30 22:52:51 --> Helper loaded: util_helper
INFO - 2018-07-30 22:52:51 --> Helper loaded: text_helper
INFO - 2018-07-30 22:52:51 --> Helper loaded: string_helper
INFO - 2018-07-30 22:52:51 --> Database Driver Class Initialized
DEBUG - 2018-07-30 22:52:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 22:52:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 22:52:51 --> Email Class Initialized
INFO - 2018-07-30 22:52:51 --> Controller Class Initialized
DEBUG - 2018-07-30 22:52:51 --> Programs MX_Controller Initialized
INFO - 2018-07-30 22:52:51 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-30 22:52:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-07-30 22:52:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-30 22:52:51 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-30 22:52:51 --> Login MX_Controller Initialized
DEBUG - 2018-07-30 22:52:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-30 22:53:35 --> Config Class Initialized
INFO - 2018-07-30 22:53:35 --> Hooks Class Initialized
DEBUG - 2018-07-30 22:53:35 --> UTF-8 Support Enabled
INFO - 2018-07-30 22:53:36 --> Utf8 Class Initialized
INFO - 2018-07-30 22:53:36 --> URI Class Initialized
INFO - 2018-07-30 22:53:36 --> Router Class Initialized
INFO - 2018-07-30 22:53:36 --> Output Class Initialized
INFO - 2018-07-30 22:53:36 --> Security Class Initialized
DEBUG - 2018-07-30 22:53:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 22:53:36 --> Input Class Initialized
INFO - 2018-07-30 22:53:36 --> Language Class Initialized
INFO - 2018-07-30 22:53:36 --> Language Class Initialized
INFO - 2018-07-30 22:53:36 --> Config Class Initialized
INFO - 2018-07-30 22:53:36 --> Loader Class Initialized
DEBUG - 2018-07-30 22:53:36 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-30 22:53:36 --> Helper loaded: url_helper
INFO - 2018-07-30 22:53:36 --> Helper loaded: form_helper
INFO - 2018-07-30 22:53:36 --> Helper loaded: date_helper
INFO - 2018-07-30 22:53:36 --> Helper loaded: util_helper
INFO - 2018-07-30 22:53:36 --> Helper loaded: text_helper
INFO - 2018-07-30 22:53:36 --> Helper loaded: string_helper
INFO - 2018-07-30 22:53:36 --> Database Driver Class Initialized
DEBUG - 2018-07-30 22:53:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 22:53:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 22:53:36 --> Email Class Initialized
INFO - 2018-07-30 22:53:36 --> Controller Class Initialized
DEBUG - 2018-07-30 22:53:36 --> Programs MX_Controller Initialized
INFO - 2018-07-30 22:53:36 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-30 22:53:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-07-30 22:53:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-30 22:53:36 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-30 22:53:36 --> Login MX_Controller Initialized
DEBUG - 2018-07-30 22:53:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-30 22:53:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-30 22:53:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-30 22:53:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-30 22:53:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-30 22:53:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-30 22:53:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/programs/create_program.php
INFO - 2018-07-30 22:53:36 --> Final output sent to browser
DEBUG - 2018-07-30 22:53:36 --> Total execution time: 0.4731
INFO - 2018-07-30 22:54:03 --> Config Class Initialized
INFO - 2018-07-30 22:54:03 --> Hooks Class Initialized
DEBUG - 2018-07-30 22:54:03 --> UTF-8 Support Enabled
INFO - 2018-07-30 22:54:03 --> Utf8 Class Initialized
INFO - 2018-07-30 22:54:03 --> URI Class Initialized
INFO - 2018-07-30 22:54:03 --> Router Class Initialized
INFO - 2018-07-30 22:54:03 --> Output Class Initialized
INFO - 2018-07-30 22:54:03 --> Security Class Initialized
DEBUG - 2018-07-30 22:54:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 22:54:03 --> Input Class Initialized
INFO - 2018-07-30 22:54:03 --> Language Class Initialized
INFO - 2018-07-30 22:54:03 --> Language Class Initialized
INFO - 2018-07-30 22:54:03 --> Config Class Initialized
INFO - 2018-07-30 22:54:03 --> Loader Class Initialized
DEBUG - 2018-07-30 22:54:03 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-30 22:54:03 --> Helper loaded: url_helper
INFO - 2018-07-30 22:54:03 --> Helper loaded: form_helper
INFO - 2018-07-30 22:54:03 --> Helper loaded: date_helper
INFO - 2018-07-30 22:54:03 --> Helper loaded: util_helper
INFO - 2018-07-30 22:54:03 --> Helper loaded: text_helper
INFO - 2018-07-30 22:54:03 --> Helper loaded: string_helper
INFO - 2018-07-30 22:54:03 --> Database Driver Class Initialized
DEBUG - 2018-07-30 22:54:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 22:54:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 22:54:04 --> Email Class Initialized
INFO - 2018-07-30 22:54:04 --> Controller Class Initialized
DEBUG - 2018-07-30 22:54:04 --> Programs MX_Controller Initialized
INFO - 2018-07-30 22:54:04 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-30 22:54:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-07-30 22:54:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-30 22:54:04 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-30 22:54:04 --> Login MX_Controller Initialized
DEBUG - 2018-07-30 22:54:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-30 22:54:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-30 22:54:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-30 22:54:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-30 22:54:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-30 22:54:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-30 22:54:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/programs/programs.php
INFO - 2018-07-30 22:54:04 --> Final output sent to browser
DEBUG - 2018-07-30 22:54:04 --> Total execution time: 0.5663
INFO - 2018-07-30 22:54:04 --> Config Class Initialized
INFO - 2018-07-30 22:54:04 --> Hooks Class Initialized
DEBUG - 2018-07-30 22:54:04 --> UTF-8 Support Enabled
INFO - 2018-07-30 22:54:04 --> Utf8 Class Initialized
INFO - 2018-07-30 22:54:04 --> URI Class Initialized
INFO - 2018-07-30 22:54:04 --> Router Class Initialized
INFO - 2018-07-30 22:54:04 --> Output Class Initialized
INFO - 2018-07-30 22:54:04 --> Security Class Initialized
DEBUG - 2018-07-30 22:54:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 22:54:04 --> Input Class Initialized
INFO - 2018-07-30 22:54:04 --> Language Class Initialized
INFO - 2018-07-30 22:54:04 --> Language Class Initialized
INFO - 2018-07-30 22:54:04 --> Config Class Initialized
INFO - 2018-07-30 22:54:04 --> Loader Class Initialized
DEBUG - 2018-07-30 22:54:04 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-30 22:54:04 --> Helper loaded: url_helper
INFO - 2018-07-30 22:54:05 --> Helper loaded: form_helper
INFO - 2018-07-30 22:54:05 --> Helper loaded: date_helper
INFO - 2018-07-30 22:54:05 --> Helper loaded: util_helper
INFO - 2018-07-30 22:54:05 --> Helper loaded: text_helper
INFO - 2018-07-30 22:54:05 --> Helper loaded: string_helper
INFO - 2018-07-30 22:54:05 --> Database Driver Class Initialized
DEBUG - 2018-07-30 22:54:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 22:54:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 22:54:05 --> Email Class Initialized
INFO - 2018-07-30 22:54:05 --> Controller Class Initialized
DEBUG - 2018-07-30 22:54:05 --> Programs MX_Controller Initialized
INFO - 2018-07-30 22:54:05 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-30 22:54:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-07-30 22:54:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-30 22:54:05 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-30 22:54:05 --> Login MX_Controller Initialized
DEBUG - 2018-07-30 22:54:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-30 22:54:05 --> Final output sent to browser
DEBUG - 2018-07-30 22:54:05 --> Total execution time: 0.6467
INFO - 2018-07-30 22:54:07 --> Config Class Initialized
INFO - 2018-07-30 22:54:07 --> Hooks Class Initialized
DEBUG - 2018-07-30 22:54:07 --> UTF-8 Support Enabled
INFO - 2018-07-30 22:54:07 --> Utf8 Class Initialized
INFO - 2018-07-30 22:54:07 --> URI Class Initialized
INFO - 2018-07-30 22:54:07 --> Router Class Initialized
INFO - 2018-07-30 22:54:07 --> Output Class Initialized
INFO - 2018-07-30 22:54:07 --> Security Class Initialized
DEBUG - 2018-07-30 22:54:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 22:54:07 --> Input Class Initialized
INFO - 2018-07-30 22:54:07 --> Language Class Initialized
INFO - 2018-07-30 22:54:07 --> Language Class Initialized
INFO - 2018-07-30 22:54:07 --> Config Class Initialized
INFO - 2018-07-30 22:54:07 --> Loader Class Initialized
DEBUG - 2018-07-30 22:54:07 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-30 22:54:07 --> Helper loaded: url_helper
INFO - 2018-07-30 22:54:07 --> Helper loaded: form_helper
INFO - 2018-07-30 22:54:07 --> Helper loaded: date_helper
INFO - 2018-07-30 22:54:08 --> Helper loaded: util_helper
INFO - 2018-07-30 22:54:08 --> Helper loaded: text_helper
INFO - 2018-07-30 22:54:08 --> Helper loaded: string_helper
INFO - 2018-07-30 22:54:08 --> Database Driver Class Initialized
DEBUG - 2018-07-30 22:54:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 22:54:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 22:54:08 --> Email Class Initialized
INFO - 2018-07-30 22:54:08 --> Controller Class Initialized
DEBUG - 2018-07-30 22:54:08 --> Admin MX_Controller Initialized
INFO - 2018-07-30 22:54:08 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-30 22:54:08 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-30 22:54:08 --> Login MX_Controller Initialized
DEBUG - 2018-07-30 22:54:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-30 22:54:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-30 22:54:14 --> Config Class Initialized
INFO - 2018-07-30 22:54:14 --> Hooks Class Initialized
DEBUG - 2018-07-30 22:54:14 --> UTF-8 Support Enabled
INFO - 2018-07-30 22:54:14 --> Utf8 Class Initialized
INFO - 2018-07-30 22:54:14 --> URI Class Initialized
INFO - 2018-07-30 22:54:14 --> Router Class Initialized
INFO - 2018-07-30 22:54:14 --> Output Class Initialized
INFO - 2018-07-30 22:54:14 --> Security Class Initialized
DEBUG - 2018-07-30 22:54:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 22:54:14 --> Input Class Initialized
INFO - 2018-07-30 22:54:14 --> Language Class Initialized
INFO - 2018-07-30 22:54:14 --> Language Class Initialized
INFO - 2018-07-30 22:54:14 --> Config Class Initialized
INFO - 2018-07-30 22:54:14 --> Loader Class Initialized
DEBUG - 2018-07-30 22:54:14 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-30 22:54:14 --> Helper loaded: url_helper
INFO - 2018-07-30 22:54:14 --> Helper loaded: form_helper
INFO - 2018-07-30 22:54:14 --> Helper loaded: date_helper
INFO - 2018-07-30 22:54:14 --> Helper loaded: util_helper
INFO - 2018-07-30 22:54:14 --> Helper loaded: text_helper
INFO - 2018-07-30 22:54:14 --> Helper loaded: string_helper
INFO - 2018-07-30 22:54:14 --> Database Driver Class Initialized
DEBUG - 2018-07-30 22:54:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 22:54:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 22:54:14 --> Email Class Initialized
INFO - 2018-07-30 22:54:14 --> Controller Class Initialized
DEBUG - 2018-07-30 22:54:14 --> Admin MX_Controller Initialized
INFO - 2018-07-30 22:54:14 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-30 22:54:14 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-30 22:54:14 --> Login MX_Controller Initialized
DEBUG - 2018-07-30 22:54:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-30 22:54:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-30 22:54:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-30 22:54:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-30 22:54:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-30 22:54:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-30 22:54:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-30 22:54:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/dashboard.php
INFO - 2018-07-30 22:54:14 --> Final output sent to browser
INFO - 2018-07-30 22:54:14 --> Config Class Initialized
INFO - 2018-07-30 22:54:14 --> Hooks Class Initialized
DEBUG - 2018-07-30 22:54:14 --> Total execution time: 0.5135
DEBUG - 2018-07-30 22:54:14 --> UTF-8 Support Enabled
INFO - 2018-07-30 22:54:14 --> Utf8 Class Initialized
INFO - 2018-07-30 22:54:14 --> URI Class Initialized
INFO - 2018-07-30 22:54:14 --> Router Class Initialized
INFO - 2018-07-30 22:54:14 --> Output Class Initialized
INFO - 2018-07-30 22:54:15 --> Security Class Initialized
DEBUG - 2018-07-30 22:54:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 22:54:15 --> Config Class Initialized
INFO - 2018-07-30 22:54:15 --> Hooks Class Initialized
INFO - 2018-07-30 22:54:15 --> Input Class Initialized
INFO - 2018-07-30 22:54:15 --> Language Class Initialized
DEBUG - 2018-07-30 22:54:15 --> UTF-8 Support Enabled
INFO - 2018-07-30 22:54:15 --> Utf8 Class Initialized
ERROR - 2018-07-30 22:54:15 --> 404 Page Not Found: /index
INFO - 2018-07-30 22:54:15 --> URI Class Initialized
INFO - 2018-07-30 22:54:15 --> Router Class Initialized
INFO - 2018-07-30 22:54:15 --> Output Class Initialized
INFO - 2018-07-30 22:54:15 --> Security Class Initialized
DEBUG - 2018-07-30 22:54:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 22:54:15 --> Input Class Initialized
INFO - 2018-07-30 22:54:15 --> Language Class Initialized
ERROR - 2018-07-30 22:54:15 --> 404 Page Not Found: /index
INFO - 2018-07-30 22:56:14 --> Config Class Initialized
INFO - 2018-07-30 22:56:14 --> Hooks Class Initialized
DEBUG - 2018-07-30 22:56:14 --> UTF-8 Support Enabled
INFO - 2018-07-30 22:56:14 --> Utf8 Class Initialized
INFO - 2018-07-30 22:56:14 --> URI Class Initialized
INFO - 2018-07-30 22:56:14 --> Router Class Initialized
INFO - 2018-07-30 22:56:14 --> Output Class Initialized
INFO - 2018-07-30 22:56:15 --> Security Class Initialized
DEBUG - 2018-07-30 22:56:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 22:56:15 --> Input Class Initialized
INFO - 2018-07-30 22:56:15 --> Language Class Initialized
INFO - 2018-07-30 22:56:15 --> Language Class Initialized
INFO - 2018-07-30 22:56:15 --> Config Class Initialized
INFO - 2018-07-30 22:56:15 --> Loader Class Initialized
DEBUG - 2018-07-30 22:56:15 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-30 22:56:15 --> Helper loaded: url_helper
INFO - 2018-07-30 22:56:15 --> Helper loaded: form_helper
INFO - 2018-07-30 22:56:15 --> Helper loaded: date_helper
INFO - 2018-07-30 22:56:15 --> Helper loaded: util_helper
INFO - 2018-07-30 22:56:15 --> Helper loaded: text_helper
INFO - 2018-07-30 22:56:15 --> Helper loaded: string_helper
INFO - 2018-07-30 22:56:15 --> Database Driver Class Initialized
DEBUG - 2018-07-30 22:56:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 22:56:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 22:56:15 --> Email Class Initialized
INFO - 2018-07-30 22:56:15 --> Controller Class Initialized
DEBUG - 2018-07-30 22:56:15 --> Admin MX_Controller Initialized
INFO - 2018-07-30 22:56:15 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-30 22:56:15 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-30 22:56:15 --> Login MX_Controller Initialized
DEBUG - 2018-07-30 22:56:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-30 22:56:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-30 22:56:16 --> Config Class Initialized
INFO - 2018-07-30 22:56:16 --> Hooks Class Initialized
DEBUG - 2018-07-30 22:56:16 --> UTF-8 Support Enabled
INFO - 2018-07-30 22:56:16 --> Utf8 Class Initialized
INFO - 2018-07-30 22:56:16 --> URI Class Initialized
INFO - 2018-07-30 22:56:16 --> Router Class Initialized
INFO - 2018-07-30 22:56:16 --> Output Class Initialized
INFO - 2018-07-30 22:56:16 --> Security Class Initialized
DEBUG - 2018-07-30 22:56:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 22:56:16 --> Input Class Initialized
INFO - 2018-07-30 22:56:16 --> Language Class Initialized
INFO - 2018-07-30 22:56:16 --> Language Class Initialized
INFO - 2018-07-30 22:56:16 --> Config Class Initialized
INFO - 2018-07-30 22:56:16 --> Loader Class Initialized
DEBUG - 2018-07-30 22:56:16 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-30 22:56:16 --> Helper loaded: url_helper
INFO - 2018-07-30 22:56:16 --> Helper loaded: form_helper
INFO - 2018-07-30 22:56:16 --> Helper loaded: date_helper
INFO - 2018-07-30 22:56:16 --> Helper loaded: util_helper
INFO - 2018-07-30 22:56:16 --> Helper loaded: text_helper
INFO - 2018-07-30 22:56:16 --> Helper loaded: string_helper
INFO - 2018-07-30 22:56:16 --> Database Driver Class Initialized
DEBUG - 2018-07-30 22:56:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 22:56:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 22:56:16 --> Email Class Initialized
INFO - 2018-07-30 22:56:16 --> Controller Class Initialized
DEBUG - 2018-07-30 22:56:16 --> Programs MX_Controller Initialized
INFO - 2018-07-30 22:56:16 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-30 22:56:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-07-30 22:56:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-30 22:56:16 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-30 22:56:16 --> Login MX_Controller Initialized
DEBUG - 2018-07-30 22:56:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-30 22:56:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-30 22:56:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-30 22:56:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-30 22:56:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-30 22:56:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-30 22:56:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/programs/programs.php
INFO - 2018-07-30 22:56:16 --> Final output sent to browser
DEBUG - 2018-07-30 22:56:16 --> Total execution time: 0.5019
INFO - 2018-07-30 22:56:16 --> Config Class Initialized
INFO - 2018-07-30 22:56:16 --> Hooks Class Initialized
DEBUG - 2018-07-30 22:56:16 --> UTF-8 Support Enabled
INFO - 2018-07-30 22:56:16 --> Utf8 Class Initialized
INFO - 2018-07-30 22:56:16 --> URI Class Initialized
INFO - 2018-07-30 22:56:17 --> Router Class Initialized
INFO - 2018-07-30 22:56:17 --> Output Class Initialized
INFO - 2018-07-30 22:56:17 --> Security Class Initialized
DEBUG - 2018-07-30 22:56:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 22:56:17 --> Input Class Initialized
INFO - 2018-07-30 22:56:17 --> Language Class Initialized
INFO - 2018-07-30 22:56:17 --> Language Class Initialized
INFO - 2018-07-30 22:56:17 --> Config Class Initialized
INFO - 2018-07-30 22:56:17 --> Loader Class Initialized
DEBUG - 2018-07-30 22:56:17 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-30 22:56:17 --> Helper loaded: url_helper
INFO - 2018-07-30 22:56:17 --> Helper loaded: form_helper
INFO - 2018-07-30 22:56:17 --> Helper loaded: date_helper
INFO - 2018-07-30 22:56:17 --> Helper loaded: util_helper
INFO - 2018-07-30 22:56:17 --> Helper loaded: text_helper
INFO - 2018-07-30 22:56:17 --> Helper loaded: string_helper
INFO - 2018-07-30 22:56:17 --> Database Driver Class Initialized
DEBUG - 2018-07-30 22:56:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 22:56:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 22:56:17 --> Email Class Initialized
INFO - 2018-07-30 22:56:17 --> Controller Class Initialized
DEBUG - 2018-07-30 22:56:17 --> Programs MX_Controller Initialized
INFO - 2018-07-30 22:56:17 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-30 22:56:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-07-30 22:56:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-30 22:56:17 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-30 22:56:17 --> Login MX_Controller Initialized
DEBUG - 2018-07-30 22:56:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-30 22:56:17 --> Final output sent to browser
DEBUG - 2018-07-30 22:56:17 --> Total execution time: 0.5656
INFO - 2018-07-30 22:56:17 --> Config Class Initialized
INFO - 2018-07-30 22:56:17 --> Hooks Class Initialized
DEBUG - 2018-07-30 22:56:17 --> UTF-8 Support Enabled
INFO - 2018-07-30 22:56:17 --> Utf8 Class Initialized
INFO - 2018-07-30 22:56:17 --> URI Class Initialized
INFO - 2018-07-30 22:56:17 --> Router Class Initialized
INFO - 2018-07-30 22:56:17 --> Output Class Initialized
INFO - 2018-07-30 22:56:17 --> Security Class Initialized
DEBUG - 2018-07-30 22:56:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 22:56:17 --> Input Class Initialized
INFO - 2018-07-30 22:56:17 --> Language Class Initialized
INFO - 2018-07-30 22:56:17 --> Language Class Initialized
INFO - 2018-07-30 22:56:17 --> Config Class Initialized
INFO - 2018-07-30 22:56:17 --> Loader Class Initialized
DEBUG - 2018-07-30 22:56:17 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-30 22:56:17 --> Helper loaded: url_helper
INFO - 2018-07-30 22:56:18 --> Helper loaded: form_helper
INFO - 2018-07-30 22:56:18 --> Helper loaded: date_helper
INFO - 2018-07-30 22:56:18 --> Helper loaded: util_helper
INFO - 2018-07-30 22:56:18 --> Helper loaded: text_helper
INFO - 2018-07-30 22:56:18 --> Helper loaded: string_helper
INFO - 2018-07-30 22:56:18 --> Database Driver Class Initialized
DEBUG - 2018-07-30 22:56:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 22:56:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 22:56:18 --> Email Class Initialized
INFO - 2018-07-30 22:56:18 --> Controller Class Initialized
DEBUG - 2018-07-30 22:56:18 --> Programs MX_Controller Initialized
INFO - 2018-07-30 22:56:18 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-30 22:56:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-07-30 22:56:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-30 22:56:18 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-30 22:56:18 --> Login MX_Controller Initialized
DEBUG - 2018-07-30 22:56:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-30 22:56:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-30 22:56:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-30 22:56:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-30 22:56:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-30 22:56:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-30 22:56:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/programs/create_program.php
INFO - 2018-07-30 22:56:18 --> Final output sent to browser
DEBUG - 2018-07-30 22:56:18 --> Total execution time: 0.5204
INFO - 2018-07-30 23:01:46 --> Config Class Initialized
INFO - 2018-07-30 23:01:46 --> Hooks Class Initialized
DEBUG - 2018-07-30 23:01:46 --> UTF-8 Support Enabled
INFO - 2018-07-30 23:01:46 --> Utf8 Class Initialized
INFO - 2018-07-30 23:01:46 --> URI Class Initialized
INFO - 2018-07-30 23:01:46 --> Router Class Initialized
INFO - 2018-07-30 23:01:46 --> Output Class Initialized
INFO - 2018-07-30 23:01:46 --> Security Class Initialized
DEBUG - 2018-07-30 23:01:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 23:01:46 --> Input Class Initialized
INFO - 2018-07-30 23:01:46 --> Language Class Initialized
INFO - 2018-07-30 23:01:46 --> Language Class Initialized
INFO - 2018-07-30 23:01:46 --> Config Class Initialized
INFO - 2018-07-30 23:01:46 --> Loader Class Initialized
DEBUG - 2018-07-30 23:01:46 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-30 23:01:47 --> Helper loaded: url_helper
INFO - 2018-07-30 23:01:47 --> Helper loaded: form_helper
INFO - 2018-07-30 23:01:47 --> Helper loaded: date_helper
INFO - 2018-07-30 23:01:47 --> Helper loaded: util_helper
INFO - 2018-07-30 23:01:47 --> Helper loaded: text_helper
INFO - 2018-07-30 23:01:47 --> Helper loaded: string_helper
INFO - 2018-07-30 23:01:47 --> Database Driver Class Initialized
DEBUG - 2018-07-30 23:01:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 23:01:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 23:01:47 --> Email Class Initialized
INFO - 2018-07-30 23:01:47 --> Controller Class Initialized
DEBUG - 2018-07-30 23:01:47 --> Programs MX_Controller Initialized
INFO - 2018-07-30 23:01:47 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-30 23:01:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-07-30 23:01:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-30 23:01:47 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-30 23:01:47 --> Login MX_Controller Initialized
DEBUG - 2018-07-30 23:01:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-30 23:01:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-30 23:01:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-30 23:01:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-30 23:01:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-30 23:01:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-30 23:01:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/programs/create_program.php
INFO - 2018-07-30 23:01:47 --> Final output sent to browser
DEBUG - 2018-07-30 23:01:47 --> Total execution time: 0.5327
INFO - 2018-07-30 23:01:48 --> Config Class Initialized
INFO - 2018-07-30 23:01:48 --> Hooks Class Initialized
DEBUG - 2018-07-30 23:01:48 --> UTF-8 Support Enabled
INFO - 2018-07-30 23:01:48 --> Utf8 Class Initialized
INFO - 2018-07-30 23:01:48 --> URI Class Initialized
INFO - 2018-07-30 23:01:48 --> Router Class Initialized
INFO - 2018-07-30 23:01:48 --> Output Class Initialized
INFO - 2018-07-30 23:01:48 --> Security Class Initialized
DEBUG - 2018-07-30 23:01:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 23:01:48 --> Input Class Initialized
INFO - 2018-07-30 23:01:48 --> Language Class Initialized
INFO - 2018-07-30 23:01:48 --> Language Class Initialized
INFO - 2018-07-30 23:01:48 --> Config Class Initialized
INFO - 2018-07-30 23:01:48 --> Loader Class Initialized
DEBUG - 2018-07-30 23:01:48 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-30 23:01:48 --> Helper loaded: url_helper
INFO - 2018-07-30 23:01:48 --> Helper loaded: form_helper
INFO - 2018-07-30 23:01:48 --> Helper loaded: date_helper
INFO - 2018-07-30 23:01:48 --> Helper loaded: util_helper
INFO - 2018-07-30 23:01:48 --> Helper loaded: text_helper
INFO - 2018-07-30 23:01:48 --> Helper loaded: string_helper
INFO - 2018-07-30 23:01:48 --> Database Driver Class Initialized
DEBUG - 2018-07-30 23:01:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 23:01:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 23:01:48 --> Email Class Initialized
INFO - 2018-07-30 23:01:48 --> Controller Class Initialized
DEBUG - 2018-07-30 23:01:48 --> Programs MX_Controller Initialized
INFO - 2018-07-30 23:01:48 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-30 23:01:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-07-30 23:01:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-30 23:01:48 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-30 23:01:48 --> Login MX_Controller Initialized
DEBUG - 2018-07-30 23:01:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-30 23:01:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-30 23:01:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-30 23:01:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-30 23:01:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-30 23:01:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-30 23:01:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/programs/create_program.php
INFO - 2018-07-30 23:01:48 --> Final output sent to browser
DEBUG - 2018-07-30 23:01:48 --> Total execution time: 0.5395
INFO - 2018-07-30 23:01:55 --> Config Class Initialized
INFO - 2018-07-30 23:01:55 --> Hooks Class Initialized
DEBUG - 2018-07-30 23:01:55 --> UTF-8 Support Enabled
INFO - 2018-07-30 23:01:55 --> Utf8 Class Initialized
INFO - 2018-07-30 23:01:55 --> URI Class Initialized
INFO - 2018-07-30 23:01:55 --> Router Class Initialized
INFO - 2018-07-30 23:01:55 --> Output Class Initialized
INFO - 2018-07-30 23:01:55 --> Security Class Initialized
DEBUG - 2018-07-30 23:01:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 23:01:55 --> Input Class Initialized
INFO - 2018-07-30 23:01:55 --> Language Class Initialized
INFO - 2018-07-30 23:01:55 --> Language Class Initialized
INFO - 2018-07-30 23:01:55 --> Config Class Initialized
INFO - 2018-07-30 23:01:55 --> Loader Class Initialized
DEBUG - 2018-07-30 23:01:55 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-30 23:01:55 --> Helper loaded: url_helper
INFO - 2018-07-30 23:01:55 --> Helper loaded: form_helper
INFO - 2018-07-30 23:01:55 --> Helper loaded: date_helper
INFO - 2018-07-30 23:01:55 --> Helper loaded: util_helper
INFO - 2018-07-30 23:01:55 --> Helper loaded: text_helper
INFO - 2018-07-30 23:01:55 --> Helper loaded: string_helper
INFO - 2018-07-30 23:01:55 --> Database Driver Class Initialized
DEBUG - 2018-07-30 23:01:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 23:01:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 23:01:55 --> Email Class Initialized
INFO - 2018-07-30 23:01:55 --> Controller Class Initialized
DEBUG - 2018-07-30 23:01:55 --> Programs MX_Controller Initialized
INFO - 2018-07-30 23:01:55 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-30 23:01:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-07-30 23:01:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-30 23:01:55 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-30 23:01:55 --> Login MX_Controller Initialized
DEBUG - 2018-07-30 23:01:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-30 23:01:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-30 23:01:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-30 23:01:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-30 23:01:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-30 23:01:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-30 23:01:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/programs/create_program.php
INFO - 2018-07-30 23:01:55 --> Final output sent to browser
DEBUG - 2018-07-30 23:01:55 --> Total execution time: 0.5599
INFO - 2018-07-30 23:02:09 --> Config Class Initialized
INFO - 2018-07-30 23:02:09 --> Hooks Class Initialized
DEBUG - 2018-07-30 23:02:09 --> UTF-8 Support Enabled
INFO - 2018-07-30 23:02:09 --> Utf8 Class Initialized
INFO - 2018-07-30 23:02:09 --> URI Class Initialized
INFO - 2018-07-30 23:02:09 --> Router Class Initialized
INFO - 2018-07-30 23:02:09 --> Output Class Initialized
INFO - 2018-07-30 23:02:09 --> Security Class Initialized
DEBUG - 2018-07-30 23:02:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 23:02:09 --> Input Class Initialized
INFO - 2018-07-30 23:02:09 --> Language Class Initialized
INFO - 2018-07-30 23:02:09 --> Language Class Initialized
INFO - 2018-07-30 23:02:09 --> Config Class Initialized
INFO - 2018-07-30 23:02:09 --> Loader Class Initialized
DEBUG - 2018-07-30 23:02:09 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-30 23:02:09 --> Helper loaded: url_helper
INFO - 2018-07-30 23:02:09 --> Helper loaded: form_helper
INFO - 2018-07-30 23:02:09 --> Helper loaded: date_helper
INFO - 2018-07-30 23:02:09 --> Helper loaded: util_helper
INFO - 2018-07-30 23:02:09 --> Helper loaded: text_helper
INFO - 2018-07-30 23:02:09 --> Helper loaded: string_helper
INFO - 2018-07-30 23:02:09 --> Database Driver Class Initialized
DEBUG - 2018-07-30 23:02:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 23:02:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 23:02:09 --> Email Class Initialized
INFO - 2018-07-30 23:02:09 --> Controller Class Initialized
DEBUG - 2018-07-30 23:02:09 --> Programs MX_Controller Initialized
INFO - 2018-07-30 23:02:09 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-30 23:02:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-07-30 23:02:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-30 23:02:09 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-30 23:02:09 --> Login MX_Controller Initialized
DEBUG - 2018-07-30 23:02:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-30 23:02:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-30 23:02:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-30 23:02:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-30 23:02:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-30 23:02:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-30 23:02:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/programs/programs.php
INFO - 2018-07-30 23:02:09 --> Final output sent to browser
DEBUG - 2018-07-30 23:02:09 --> Total execution time: 0.5839
INFO - 2018-07-30 23:02:10 --> Config Class Initialized
INFO - 2018-07-30 23:02:10 --> Hooks Class Initialized
DEBUG - 2018-07-30 23:02:10 --> UTF-8 Support Enabled
INFO - 2018-07-30 23:02:10 --> Utf8 Class Initialized
INFO - 2018-07-30 23:02:10 --> URI Class Initialized
INFO - 2018-07-30 23:02:10 --> Router Class Initialized
INFO - 2018-07-30 23:02:10 --> Output Class Initialized
INFO - 2018-07-30 23:02:10 --> Security Class Initialized
DEBUG - 2018-07-30 23:02:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 23:02:10 --> Input Class Initialized
INFO - 2018-07-30 23:02:10 --> Language Class Initialized
INFO - 2018-07-30 23:02:10 --> Language Class Initialized
INFO - 2018-07-30 23:02:10 --> Config Class Initialized
INFO - 2018-07-30 23:02:10 --> Loader Class Initialized
DEBUG - 2018-07-30 23:02:10 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-30 23:02:10 --> Helper loaded: url_helper
INFO - 2018-07-30 23:02:10 --> Helper loaded: form_helper
INFO - 2018-07-30 23:02:10 --> Helper loaded: date_helper
INFO - 2018-07-30 23:02:10 --> Helper loaded: util_helper
INFO - 2018-07-30 23:02:10 --> Helper loaded: text_helper
INFO - 2018-07-30 23:02:10 --> Helper loaded: string_helper
INFO - 2018-07-30 23:02:10 --> Database Driver Class Initialized
DEBUG - 2018-07-30 23:02:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 23:02:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 23:02:10 --> Email Class Initialized
INFO - 2018-07-30 23:02:10 --> Controller Class Initialized
DEBUG - 2018-07-30 23:02:10 --> Programs MX_Controller Initialized
INFO - 2018-07-30 23:02:10 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-30 23:02:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-07-30 23:02:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-30 23:02:10 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-30 23:02:10 --> Login MX_Controller Initialized
DEBUG - 2018-07-30 23:02:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-30 23:02:10 --> Final output sent to browser
DEBUG - 2018-07-30 23:02:10 --> Total execution time: 0.5969
INFO - 2018-07-30 23:05:19 --> Config Class Initialized
INFO - 2018-07-30 23:05:19 --> Hooks Class Initialized
DEBUG - 2018-07-30 23:05:19 --> UTF-8 Support Enabled
INFO - 2018-07-30 23:05:19 --> Utf8 Class Initialized
INFO - 2018-07-30 23:05:19 --> URI Class Initialized
INFO - 2018-07-30 23:05:19 --> Router Class Initialized
INFO - 2018-07-30 23:05:19 --> Output Class Initialized
INFO - 2018-07-30 23:05:19 --> Security Class Initialized
DEBUG - 2018-07-30 23:05:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 23:05:20 --> Input Class Initialized
INFO - 2018-07-30 23:05:20 --> Language Class Initialized
INFO - 2018-07-30 23:05:20 --> Language Class Initialized
INFO - 2018-07-30 23:05:20 --> Config Class Initialized
INFO - 2018-07-30 23:05:20 --> Loader Class Initialized
DEBUG - 2018-07-30 23:05:20 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-30 23:05:20 --> Helper loaded: url_helper
INFO - 2018-07-30 23:05:20 --> Helper loaded: form_helper
INFO - 2018-07-30 23:05:20 --> Helper loaded: date_helper
INFO - 2018-07-30 23:05:20 --> Helper loaded: util_helper
INFO - 2018-07-30 23:05:20 --> Helper loaded: text_helper
INFO - 2018-07-30 23:05:20 --> Helper loaded: string_helper
INFO - 2018-07-30 23:05:20 --> Database Driver Class Initialized
DEBUG - 2018-07-30 23:05:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 23:05:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 23:05:20 --> Email Class Initialized
INFO - 2018-07-30 23:05:20 --> Controller Class Initialized
DEBUG - 2018-07-30 23:05:20 --> Home MX_Controller Initialized
DEBUG - 2018-07-30 23:05:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-30 23:05:20 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-30 23:05:20 --> Login MX_Controller Initialized
INFO - 2018-07-30 23:05:20 --> Language file loaded: language/english/data_lang.php
INFO - 2018-07-30 23:05:20 --> Config Class Initialized
DEBUG - 2018-07-30 23:05:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-30 23:05:20 --> Hooks Class Initialized
DEBUG - 2018-07-30 23:05:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-30 23:05:20 --> UTF-8 Support Enabled
INFO - 2018-07-30 23:05:20 --> Utf8 Class Initialized
INFO - 2018-07-30 23:05:20 --> URI Class Initialized
INFO - 2018-07-30 23:05:20 --> Router Class Initialized
INFO - 2018-07-30 23:05:20 --> Output Class Initialized
INFO - 2018-07-30 23:05:20 --> Security Class Initialized
DEBUG - 2018-07-30 23:05:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 23:05:20 --> Input Class Initialized
INFO - 2018-07-30 23:05:20 --> Language Class Initialized
ERROR - 2018-07-30 23:05:20 --> 404 Page Not Found: /index
INFO - 2018-07-30 23:05:20 --> Config Class Initialized
INFO - 2018-07-30 23:05:20 --> Hooks Class Initialized
DEBUG - 2018-07-30 23:05:20 --> UTF-8 Support Enabled
INFO - 2018-07-30 23:05:20 --> Utf8 Class Initialized
INFO - 2018-07-30 23:05:20 --> URI Class Initialized
INFO - 2018-07-30 23:05:20 --> Router Class Initialized
INFO - 2018-07-30 23:05:20 --> Output Class Initialized
INFO - 2018-07-30 23:05:20 --> Security Class Initialized
DEBUG - 2018-07-30 23:05:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 23:05:20 --> Input Class Initialized
INFO - 2018-07-30 23:05:20 --> Language Class Initialized
ERROR - 2018-07-30 23:05:20 --> 404 Page Not Found: /index
INFO - 2018-07-30 23:05:20 --> Config Class Initialized
INFO - 2018-07-30 23:05:20 --> Hooks Class Initialized
DEBUG - 2018-07-30 23:05:20 --> UTF-8 Support Enabled
INFO - 2018-07-30 23:05:20 --> Utf8 Class Initialized
INFO - 2018-07-30 23:05:20 --> URI Class Initialized
INFO - 2018-07-30 23:05:20 --> Router Class Initialized
INFO - 2018-07-30 23:05:20 --> Output Class Initialized
INFO - 2018-07-30 23:05:20 --> Security Class Initialized
DEBUG - 2018-07-30 23:05:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 23:05:20 --> Input Class Initialized
INFO - 2018-07-30 23:05:20 --> Language Class Initialized
ERROR - 2018-07-30 23:05:20 --> 404 Page Not Found: /index
INFO - 2018-07-30 23:05:22 --> Config Class Initialized
INFO - 2018-07-30 23:05:22 --> Hooks Class Initialized
DEBUG - 2018-07-30 23:05:22 --> UTF-8 Support Enabled
INFO - 2018-07-30 23:05:22 --> Config Class Initialized
INFO - 2018-07-30 23:05:22 --> Utf8 Class Initialized
INFO - 2018-07-30 23:05:22 --> Hooks Class Initialized
DEBUG - 2018-07-30 23:05:22 --> UTF-8 Support Enabled
INFO - 2018-07-30 23:05:22 --> URI Class Initialized
INFO - 2018-07-30 23:05:22 --> Utf8 Class Initialized
INFO - 2018-07-30 23:05:22 --> URI Class Initialized
INFO - 2018-07-30 23:05:22 --> Router Class Initialized
INFO - 2018-07-30 23:05:22 --> Router Class Initialized
INFO - 2018-07-30 23:05:22 --> Output Class Initialized
INFO - 2018-07-30 23:05:22 --> Security Class Initialized
DEBUG - 2018-07-30 23:05:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 23:05:22 --> Input Class Initialized
INFO - 2018-07-30 23:05:22 --> Language Class Initialized
ERROR - 2018-07-30 23:05:22 --> 404 Page Not Found: /index
INFO - 2018-07-30 23:05:22 --> Output Class Initialized
INFO - 2018-07-30 23:05:22 --> Config Class Initialized
INFO - 2018-07-30 23:05:22 --> Hooks Class Initialized
INFO - 2018-07-30 23:05:22 --> Security Class Initialized
DEBUG - 2018-07-30 23:05:22 --> UTF-8 Support Enabled
DEBUG - 2018-07-30 23:05:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 23:05:22 --> Utf8 Class Initialized
INFO - 2018-07-30 23:05:22 --> URI Class Initialized
INFO - 2018-07-30 23:05:22 --> Input Class Initialized
INFO - 2018-07-30 23:05:22 --> Router Class Initialized
INFO - 2018-07-30 23:05:22 --> Output Class Initialized
INFO - 2018-07-30 23:05:22 --> Language Class Initialized
INFO - 2018-07-30 23:05:22 --> Language Class Initialized
INFO - 2018-07-30 23:05:22 --> Security Class Initialized
INFO - 2018-07-30 23:05:22 --> Config Class Initialized
DEBUG - 2018-07-30 23:05:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 23:05:22 --> Input Class Initialized
INFO - 2018-07-30 23:05:22 --> Loader Class Initialized
INFO - 2018-07-30 23:05:22 --> Language Class Initialized
ERROR - 2018-07-30 23:05:22 --> 404 Page Not Found: /index
DEBUG - 2018-07-30 23:05:22 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-30 23:05:22 --> Config Class Initialized
INFO - 2018-07-30 23:05:22 --> Hooks Class Initialized
INFO - 2018-07-30 23:05:22 --> Helper loaded: url_helper
DEBUG - 2018-07-30 23:05:22 --> UTF-8 Support Enabled
INFO - 2018-07-30 23:05:22 --> Helper loaded: form_helper
INFO - 2018-07-30 23:05:22 --> Utf8 Class Initialized
INFO - 2018-07-30 23:05:22 --> URI Class Initialized
INFO - 2018-07-30 23:05:22 --> Router Class Initialized
INFO - 2018-07-30 23:05:22 --> Helper loaded: date_helper
INFO - 2018-07-30 23:05:22 --> Output Class Initialized
INFO - 2018-07-30 23:05:22 --> Security Class Initialized
DEBUG - 2018-07-30 23:05:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 23:05:22 --> Input Class Initialized
INFO - 2018-07-30 23:05:22 --> Language Class Initialized
ERROR - 2018-07-30 23:05:22 --> 404 Page Not Found: /index
INFO - 2018-07-30 23:05:22 --> Helper loaded: util_helper
INFO - 2018-07-30 23:05:22 --> Helper loaded: text_helper
INFO - 2018-07-30 23:05:22 --> Helper loaded: string_helper
INFO - 2018-07-30 23:05:22 --> Database Driver Class Initialized
DEBUG - 2018-07-30 23:05:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 23:05:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 23:05:22 --> Email Class Initialized
INFO - 2018-07-30 23:05:22 --> Controller Class Initialized
DEBUG - 2018-07-30 23:05:22 --> Home MX_Controller Initialized
DEBUG - 2018-07-30 23:05:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-30 23:05:22 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-30 23:05:22 --> Login MX_Controller Initialized
INFO - 2018-07-30 23:05:22 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-30 23:05:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-30 23:05:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-30 23:05:23 --> Config Class Initialized
INFO - 2018-07-30 23:05:23 --> Hooks Class Initialized
DEBUG - 2018-07-30 23:05:23 --> UTF-8 Support Enabled
INFO - 2018-07-30 23:05:23 --> Config Class Initialized
INFO - 2018-07-30 23:05:23 --> Hooks Class Initialized
INFO - 2018-07-30 23:05:24 --> Utf8 Class Initialized
DEBUG - 2018-07-30 23:05:24 --> UTF-8 Support Enabled
INFO - 2018-07-30 23:05:24 --> Utf8 Class Initialized
INFO - 2018-07-30 23:05:24 --> URI Class Initialized
INFO - 2018-07-30 23:05:24 --> Router Class Initialized
INFO - 2018-07-30 23:05:24 --> URI Class Initialized
INFO - 2018-07-30 23:05:24 --> Output Class Initialized
INFO - 2018-07-30 23:05:24 --> Security Class Initialized
DEBUG - 2018-07-30 23:05:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 23:05:24 --> Input Class Initialized
INFO - 2018-07-30 23:05:24 --> Language Class Initialized
ERROR - 2018-07-30 23:05:24 --> 404 Page Not Found: /index
INFO - 2018-07-30 23:05:24 --> Router Class Initialized
INFO - 2018-07-30 23:05:24 --> Config Class Initialized
INFO - 2018-07-30 23:05:24 --> Hooks Class Initialized
INFO - 2018-07-30 23:05:24 --> Output Class Initialized
DEBUG - 2018-07-30 23:05:24 --> UTF-8 Support Enabled
INFO - 2018-07-30 23:05:24 --> Utf8 Class Initialized
INFO - 2018-07-30 23:05:24 --> URI Class Initialized
INFO - 2018-07-30 23:05:24 --> Router Class Initialized
INFO - 2018-07-30 23:05:24 --> Output Class Initialized
INFO - 2018-07-30 23:05:24 --> Security Class Initialized
DEBUG - 2018-07-30 23:05:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 23:05:24 --> Input Class Initialized
INFO - 2018-07-30 23:05:24 --> Language Class Initialized
ERROR - 2018-07-30 23:05:24 --> 404 Page Not Found: /index
INFO - 2018-07-30 23:05:24 --> Config Class Initialized
INFO - 2018-07-30 23:05:24 --> Security Class Initialized
INFO - 2018-07-30 23:05:24 --> Hooks Class Initialized
DEBUG - 2018-07-30 23:05:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-07-30 23:05:24 --> UTF-8 Support Enabled
INFO - 2018-07-30 23:05:24 --> Utf8 Class Initialized
INFO - 2018-07-30 23:05:24 --> Input Class Initialized
INFO - 2018-07-30 23:05:24 --> URI Class Initialized
INFO - 2018-07-30 23:05:24 --> Language Class Initialized
INFO - 2018-07-30 23:05:24 --> Router Class Initialized
INFO - 2018-07-30 23:05:24 --> Output Class Initialized
INFO - 2018-07-30 23:05:24 --> Language Class Initialized
INFO - 2018-07-30 23:05:24 --> Security Class Initialized
DEBUG - 2018-07-30 23:05:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 23:05:24 --> Config Class Initialized
INFO - 2018-07-30 23:05:24 --> Input Class Initialized
INFO - 2018-07-30 23:05:24 --> Loader Class Initialized
INFO - 2018-07-30 23:05:24 --> Language Class Initialized
DEBUG - 2018-07-30 23:05:24 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
ERROR - 2018-07-30 23:05:24 --> 404 Page Not Found: /index
INFO - 2018-07-30 23:05:24 --> Helper loaded: url_helper
INFO - 2018-07-30 23:05:24 --> Helper loaded: form_helper
INFO - 2018-07-30 23:05:24 --> Config Class Initialized
INFO - 2018-07-30 23:05:24 --> Hooks Class Initialized
INFO - 2018-07-30 23:05:24 --> Helper loaded: date_helper
INFO - 2018-07-30 23:05:24 --> Helper loaded: util_helper
DEBUG - 2018-07-30 23:05:24 --> UTF-8 Support Enabled
INFO - 2018-07-30 23:05:24 --> Utf8 Class Initialized
INFO - 2018-07-30 23:05:24 --> Helper loaded: text_helper
INFO - 2018-07-30 23:05:24 --> Helper loaded: string_helper
INFO - 2018-07-30 23:05:24 --> URI Class Initialized
INFO - 2018-07-30 23:05:24 --> Router Class Initialized
INFO - 2018-07-30 23:05:24 --> Database Driver Class Initialized
INFO - 2018-07-30 23:05:24 --> Output Class Initialized
DEBUG - 2018-07-30 23:05:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 23:05:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 23:05:24 --> Security Class Initialized
DEBUG - 2018-07-30 23:05:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 23:05:24 --> Email Class Initialized
INFO - 2018-07-30 23:05:24 --> Controller Class Initialized
INFO - 2018-07-30 23:05:24 --> Input Class Initialized
DEBUG - 2018-07-30 23:05:24 --> Home MX_Controller Initialized
INFO - 2018-07-30 23:05:24 --> Language Class Initialized
ERROR - 2018-07-30 23:05:24 --> 404 Page Not Found: /index
DEBUG - 2018-07-30 23:05:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-07-30 23:05:24 --> Config Class Initialized
DEBUG - 2018-07-30 23:05:24 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-30 23:05:24 --> Login MX_Controller Initialized
INFO - 2018-07-30 23:05:24 --> Hooks Class Initialized
INFO - 2018-07-30 23:05:24 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-30 23:05:24 --> UTF-8 Support Enabled
INFO - 2018-07-30 23:05:24 --> Utf8 Class Initialized
DEBUG - 2018-07-30 23:05:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-30 23:05:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-30 23:05:24 --> URI Class Initialized
INFO - 2018-07-30 23:05:24 --> Router Class Initialized
INFO - 2018-07-30 23:05:24 --> Output Class Initialized
INFO - 2018-07-30 23:05:24 --> Security Class Initialized
DEBUG - 2018-07-30 23:05:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 23:05:24 --> Input Class Initialized
INFO - 2018-07-30 23:05:24 --> Language Class Initialized
ERROR - 2018-07-30 23:05:24 --> 404 Page Not Found: /index
INFO - 2018-07-30 23:05:25 --> Config Class Initialized
INFO - 2018-07-30 23:05:25 --> Hooks Class Initialized
DEBUG - 2018-07-30 23:05:25 --> UTF-8 Support Enabled
INFO - 2018-07-30 23:05:25 --> Utf8 Class Initialized
INFO - 2018-07-30 23:05:25 --> URI Class Initialized
INFO - 2018-07-30 23:05:25 --> Router Class Initialized
INFO - 2018-07-30 23:05:25 --> Output Class Initialized
INFO - 2018-07-30 23:05:25 --> Security Class Initialized
DEBUG - 2018-07-30 23:05:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 23:05:25 --> Input Class Initialized
INFO - 2018-07-30 23:05:25 --> Language Class Initialized
ERROR - 2018-07-30 23:05:25 --> 404 Page Not Found: /index
INFO - 2018-07-30 23:05:25 --> Config Class Initialized
INFO - 2018-07-30 23:05:25 --> Hooks Class Initialized
INFO - 2018-07-30 23:05:25 --> Config Class Initialized
INFO - 2018-07-30 23:05:25 --> Hooks Class Initialized
DEBUG - 2018-07-30 23:05:25 --> UTF-8 Support Enabled
INFO - 2018-07-30 23:05:25 --> Utf8 Class Initialized
DEBUG - 2018-07-30 23:05:25 --> UTF-8 Support Enabled
INFO - 2018-07-30 23:05:25 --> URI Class Initialized
INFO - 2018-07-30 23:05:25 --> Utf8 Class Initialized
INFO - 2018-07-30 23:05:25 --> URI Class Initialized
INFO - 2018-07-30 23:05:25 --> Router Class Initialized
INFO - 2018-07-30 23:05:25 --> Output Class Initialized
INFO - 2018-07-30 23:05:25 --> Router Class Initialized
INFO - 2018-07-30 23:05:25 --> Output Class Initialized
INFO - 2018-07-30 23:05:25 --> Security Class Initialized
DEBUG - 2018-07-30 23:05:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 23:05:25 --> Security Class Initialized
DEBUG - 2018-07-30 23:05:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 23:05:25 --> Input Class Initialized
INFO - 2018-07-30 23:05:25 --> Input Class Initialized
INFO - 2018-07-30 23:05:25 --> Language Class Initialized
INFO - 2018-07-30 23:05:25 --> Language Class Initialized
INFO - 2018-07-30 23:05:25 --> Language Class Initialized
INFO - 2018-07-30 23:05:25 --> Config Class Initialized
ERROR - 2018-07-30 23:05:25 --> 404 Page Not Found: /index
INFO - 2018-07-30 23:05:25 --> Loader Class Initialized
INFO - 2018-07-30 23:05:25 --> Config Class Initialized
INFO - 2018-07-30 23:05:25 --> Hooks Class Initialized
DEBUG - 2018-07-30 23:05:25 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-30 23:05:25 --> Helper loaded: url_helper
DEBUG - 2018-07-30 23:05:25 --> UTF-8 Support Enabled
INFO - 2018-07-30 23:05:25 --> Utf8 Class Initialized
INFO - 2018-07-30 23:05:25 --> Helper loaded: form_helper
INFO - 2018-07-30 23:05:25 --> URI Class Initialized
INFO - 2018-07-30 23:05:25 --> Helper loaded: date_helper
INFO - 2018-07-30 23:05:25 --> Helper loaded: util_helper
INFO - 2018-07-30 23:05:25 --> Router Class Initialized
INFO - 2018-07-30 23:05:25 --> Output Class Initialized
INFO - 2018-07-30 23:05:25 --> Helper loaded: text_helper
INFO - 2018-07-30 23:05:25 --> Helper loaded: string_helper
INFO - 2018-07-30 23:05:25 --> Security Class Initialized
DEBUG - 2018-07-30 23:05:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 23:05:25 --> Database Driver Class Initialized
INFO - 2018-07-30 23:05:25 --> Input Class Initialized
INFO - 2018-07-30 23:05:25 --> Language Class Initialized
ERROR - 2018-07-30 23:05:25 --> 404 Page Not Found: /index
DEBUG - 2018-07-30 23:05:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 23:05:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 23:05:25 --> Config Class Initialized
INFO - 2018-07-30 23:05:25 --> Hooks Class Initialized
INFO - 2018-07-30 23:05:25 --> Email Class Initialized
INFO - 2018-07-30 23:05:25 --> Controller Class Initialized
DEBUG - 2018-07-30 23:05:25 --> UTF-8 Support Enabled
INFO - 2018-07-30 23:05:25 --> Utf8 Class Initialized
DEBUG - 2018-07-30 23:05:25 --> Home MX_Controller Initialized
INFO - 2018-07-30 23:05:25 --> URI Class Initialized
DEBUG - 2018-07-30 23:05:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-07-30 23:05:25 --> Router Class Initialized
DEBUG - 2018-07-30 23:05:25 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-30 23:05:25 --> Login MX_Controller Initialized
INFO - 2018-07-30 23:05:25 --> Output Class Initialized
INFO - 2018-07-30 23:05:25 --> Language file loaded: language/english/data_lang.php
INFO - 2018-07-30 23:05:25 --> Security Class Initialized
DEBUG - 2018-07-30 23:05:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-30 23:05:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 23:05:25 --> Input Class Initialized
DEBUG - 2018-07-30 23:05:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-30 23:05:25 --> Language Class Initialized
ERROR - 2018-07-30 23:05:26 --> 404 Page Not Found: /index
INFO - 2018-07-30 23:05:27 --> Config Class Initialized
INFO - 2018-07-30 23:05:27 --> Hooks Class Initialized
INFO - 2018-07-30 23:05:27 --> Config Class Initialized
INFO - 2018-07-30 23:05:27 --> Hooks Class Initialized
DEBUG - 2018-07-30 23:05:27 --> UTF-8 Support Enabled
INFO - 2018-07-30 23:05:27 --> Utf8 Class Initialized
DEBUG - 2018-07-30 23:05:27 --> UTF-8 Support Enabled
INFO - 2018-07-30 23:05:27 --> Utf8 Class Initialized
INFO - 2018-07-30 23:05:27 --> URI Class Initialized
INFO - 2018-07-30 23:05:27 --> URI Class Initialized
INFO - 2018-07-30 23:05:27 --> Router Class Initialized
INFO - 2018-07-30 23:05:27 --> Output Class Initialized
INFO - 2018-07-30 23:05:27 --> Router Class Initialized
INFO - 2018-07-30 23:05:27 --> Output Class Initialized
INFO - 2018-07-30 23:05:27 --> Security Class Initialized
INFO - 2018-07-30 23:05:27 --> Security Class Initialized
DEBUG - 2018-07-30 23:05:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-07-30 23:05:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 23:05:27 --> Input Class Initialized
INFO - 2018-07-30 23:05:27 --> Language Class Initialized
ERROR - 2018-07-30 23:05:27 --> 404 Page Not Found: /index
INFO - 2018-07-30 23:05:27 --> Input Class Initialized
INFO - 2018-07-30 23:05:27 --> Config Class Initialized
INFO - 2018-07-30 23:05:27 --> Hooks Class Initialized
INFO - 2018-07-30 23:05:27 --> Language Class Initialized
INFO - 2018-07-30 23:05:27 --> Language Class Initialized
DEBUG - 2018-07-30 23:05:27 --> UTF-8 Support Enabled
INFO - 2018-07-30 23:05:27 --> Config Class Initialized
INFO - 2018-07-30 23:05:27 --> Utf8 Class Initialized
INFO - 2018-07-30 23:05:27 --> Loader Class Initialized
INFO - 2018-07-30 23:05:27 --> URI Class Initialized
DEBUG - 2018-07-30 23:05:27 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-30 23:05:27 --> Router Class Initialized
INFO - 2018-07-30 23:05:27 --> Helper loaded: url_helper
INFO - 2018-07-30 23:05:27 --> Helper loaded: form_helper
INFO - 2018-07-30 23:05:27 --> Output Class Initialized
INFO - 2018-07-30 23:05:27 --> Helper loaded: date_helper
INFO - 2018-07-30 23:05:27 --> Security Class Initialized
INFO - 2018-07-30 23:05:27 --> Helper loaded: util_helper
DEBUG - 2018-07-30 23:05:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 23:05:27 --> Helper loaded: text_helper
INFO - 2018-07-30 23:05:27 --> Input Class Initialized
INFO - 2018-07-30 23:05:27 --> Helper loaded: string_helper
INFO - 2018-07-30 23:05:27 --> Language Class Initialized
INFO - 2018-07-30 23:05:27 --> Database Driver Class Initialized
ERROR - 2018-07-30 23:05:27 --> 404 Page Not Found: /index
INFO - 2018-07-30 23:05:27 --> Config Class Initialized
INFO - 2018-07-30 23:05:27 --> Hooks Class Initialized
DEBUG - 2018-07-30 23:05:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 23:05:27 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-07-30 23:05:27 --> UTF-8 Support Enabled
INFO - 2018-07-30 23:05:27 --> Utf8 Class Initialized
INFO - 2018-07-30 23:05:27 --> Email Class Initialized
INFO - 2018-07-30 23:05:27 --> Controller Class Initialized
INFO - 2018-07-30 23:05:27 --> URI Class Initialized
DEBUG - 2018-07-30 23:05:27 --> Home MX_Controller Initialized
INFO - 2018-07-30 23:05:27 --> Router Class Initialized
DEBUG - 2018-07-30 23:05:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-07-30 23:05:27 --> Output Class Initialized
INFO - 2018-07-30 23:05:27 --> Security Class Initialized
DEBUG - 2018-07-30 23:05:27 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-30 23:05:27 --> Login MX_Controller Initialized
DEBUG - 2018-07-30 23:05:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 23:05:27 --> Language file loaded: language/english/data_lang.php
INFO - 2018-07-30 23:05:27 --> Input Class Initialized
INFO - 2018-07-30 23:05:27 --> Language Class Initialized
DEBUG - 2018-07-30 23:05:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-30 23:05:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
ERROR - 2018-07-30 23:05:27 --> 404 Page Not Found: /index
INFO - 2018-07-30 23:05:28 --> Config Class Initialized
INFO - 2018-07-30 23:05:28 --> Hooks Class Initialized
DEBUG - 2018-07-30 23:05:28 --> UTF-8 Support Enabled
INFO - 2018-07-30 23:05:28 --> Config Class Initialized
INFO - 2018-07-30 23:05:28 --> Hooks Class Initialized
INFO - 2018-07-30 23:05:28 --> Utf8 Class Initialized
DEBUG - 2018-07-30 23:05:28 --> UTF-8 Support Enabled
INFO - 2018-07-30 23:05:28 --> URI Class Initialized
INFO - 2018-07-30 23:05:28 --> Utf8 Class Initialized
INFO - 2018-07-30 23:05:28 --> Router Class Initialized
INFO - 2018-07-30 23:05:28 --> URI Class Initialized
INFO - 2018-07-30 23:05:28 --> Output Class Initialized
INFO - 2018-07-30 23:05:28 --> Router Class Initialized
INFO - 2018-07-30 23:05:28 --> Security Class Initialized
DEBUG - 2018-07-30 23:05:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 23:05:28 --> Output Class Initialized
INFO - 2018-07-30 23:05:28 --> Input Class Initialized
INFO - 2018-07-30 23:05:28 --> Security Class Initialized
DEBUG - 2018-07-30 23:05:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 23:05:28 --> Language Class Initialized
INFO - 2018-07-30 23:05:28 --> Input Class Initialized
INFO - 2018-07-30 23:05:28 --> Language Class Initialized
INFO - 2018-07-30 23:05:28 --> Config Class Initialized
INFO - 2018-07-30 23:05:28 --> Language Class Initialized
ERROR - 2018-07-30 23:05:28 --> 404 Page Not Found: /index
INFO - 2018-07-30 23:05:28 --> Loader Class Initialized
DEBUG - 2018-07-30 23:05:28 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-30 23:05:28 --> Config Class Initialized
INFO - 2018-07-30 23:05:28 --> Hooks Class Initialized
INFO - 2018-07-30 23:05:28 --> Helper loaded: url_helper
DEBUG - 2018-07-30 23:05:28 --> UTF-8 Support Enabled
INFO - 2018-07-30 23:05:28 --> Helper loaded: form_helper
INFO - 2018-07-30 23:05:28 --> Utf8 Class Initialized
INFO - 2018-07-30 23:05:28 --> URI Class Initialized
INFO - 2018-07-30 23:05:28 --> Router Class Initialized
INFO - 2018-07-30 23:05:28 --> Helper loaded: date_helper
INFO - 2018-07-30 23:05:28 --> Output Class Initialized
INFO - 2018-07-30 23:05:28 --> Security Class Initialized
DEBUG - 2018-07-30 23:05:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 23:05:28 --> Input Class Initialized
INFO - 2018-07-30 23:05:28 --> Language Class Initialized
ERROR - 2018-07-30 23:05:28 --> 404 Page Not Found: /index
INFO - 2018-07-30 23:05:28 --> Helper loaded: util_helper
INFO - 2018-07-30 23:05:28 --> Config Class Initialized
INFO - 2018-07-30 23:05:28 --> Hooks Class Initialized
INFO - 2018-07-30 23:05:28 --> Helper loaded: text_helper
DEBUG - 2018-07-30 23:05:29 --> UTF-8 Support Enabled
INFO - 2018-07-30 23:05:29 --> Utf8 Class Initialized
INFO - 2018-07-30 23:05:29 --> URI Class Initialized
INFO - 2018-07-30 23:05:29 --> Router Class Initialized
INFO - 2018-07-30 23:05:29 --> Helper loaded: string_helper
INFO - 2018-07-30 23:05:29 --> Output Class Initialized
INFO - 2018-07-30 23:05:29 --> Database Driver Class Initialized
INFO - 2018-07-30 23:05:29 --> Security Class Initialized
DEBUG - 2018-07-30 23:05:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 23:05:29 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-07-30 23:05:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 23:05:29 --> Input Class Initialized
INFO - 2018-07-30 23:05:29 --> Email Class Initialized
INFO - 2018-07-30 23:05:29 --> Controller Class Initialized
INFO - 2018-07-30 23:05:29 --> Language Class Initialized
DEBUG - 2018-07-30 23:05:29 --> Home MX_Controller Initialized
ERROR - 2018-07-30 23:05:29 --> 404 Page Not Found: /index
DEBUG - 2018-07-30 23:05:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-30 23:05:29 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-30 23:05:29 --> Login MX_Controller Initialized
INFO - 2018-07-30 23:05:29 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-30 23:05:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-30 23:05:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-30 23:05:30 --> Config Class Initialized
INFO - 2018-07-30 23:05:30 --> Hooks Class Initialized
INFO - 2018-07-30 23:05:30 --> Config Class Initialized
INFO - 2018-07-30 23:05:30 --> Hooks Class Initialized
DEBUG - 2018-07-30 23:05:30 --> UTF-8 Support Enabled
INFO - 2018-07-30 23:05:30 --> Utf8 Class Initialized
DEBUG - 2018-07-30 23:05:30 --> UTF-8 Support Enabled
INFO - 2018-07-30 23:05:30 --> Utf8 Class Initialized
INFO - 2018-07-30 23:05:30 --> URI Class Initialized
INFO - 2018-07-30 23:05:30 --> URI Class Initialized
INFO - 2018-07-30 23:05:30 --> Router Class Initialized
INFO - 2018-07-30 23:05:30 --> Router Class Initialized
INFO - 2018-07-30 23:05:30 --> Output Class Initialized
INFO - 2018-07-30 23:05:30 --> Output Class Initialized
INFO - 2018-07-30 23:05:30 --> Security Class Initialized
INFO - 2018-07-30 23:05:30 --> Security Class Initialized
DEBUG - 2018-07-30 23:05:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 23:05:30 --> Input Class Initialized
INFO - 2018-07-30 23:05:30 --> Language Class Initialized
DEBUG - 2018-07-30 23:05:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 23:05:30 --> Input Class Initialized
ERROR - 2018-07-30 23:05:30 --> 404 Page Not Found: /index
INFO - 2018-07-30 23:05:30 --> Language Class Initialized
INFO - 2018-07-30 23:05:30 --> Config Class Initialized
INFO - 2018-07-30 23:05:30 --> Hooks Class Initialized
INFO - 2018-07-30 23:05:30 --> Language Class Initialized
INFO - 2018-07-30 23:05:30 --> Config Class Initialized
DEBUG - 2018-07-30 23:05:30 --> UTF-8 Support Enabled
INFO - 2018-07-30 23:05:30 --> Utf8 Class Initialized
INFO - 2018-07-30 23:05:30 --> Loader Class Initialized
DEBUG - 2018-07-30 23:05:30 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-30 23:05:30 --> URI Class Initialized
INFO - 2018-07-30 23:05:30 --> Helper loaded: url_helper
INFO - 2018-07-30 23:05:30 --> Router Class Initialized
INFO - 2018-07-30 23:05:30 --> Helper loaded: form_helper
INFO - 2018-07-30 23:05:30 --> Output Class Initialized
INFO - 2018-07-30 23:05:30 --> Helper loaded: date_helper
INFO - 2018-07-30 23:05:30 --> Security Class Initialized
INFO - 2018-07-30 23:05:30 --> Helper loaded: util_helper
DEBUG - 2018-07-30 23:05:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 23:05:30 --> Helper loaded: text_helper
INFO - 2018-07-30 23:05:30 --> Input Class Initialized
INFO - 2018-07-30 23:05:30 --> Language Class Initialized
INFO - 2018-07-30 23:05:30 --> Helper loaded: string_helper
ERROR - 2018-07-30 23:05:30 --> 404 Page Not Found: /index
INFO - 2018-07-30 23:05:30 --> Database Driver Class Initialized
INFO - 2018-07-30 23:05:30 --> Config Class Initialized
INFO - 2018-07-30 23:05:30 --> Hooks Class Initialized
DEBUG - 2018-07-30 23:05:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 23:05:30 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-07-30 23:05:30 --> UTF-8 Support Enabled
INFO - 2018-07-30 23:05:30 --> Utf8 Class Initialized
INFO - 2018-07-30 23:05:30 --> Email Class Initialized
INFO - 2018-07-30 23:05:30 --> Controller Class Initialized
INFO - 2018-07-30 23:05:30 --> URI Class Initialized
DEBUG - 2018-07-30 23:05:30 --> Home MX_Controller Initialized
INFO - 2018-07-30 23:05:30 --> Router Class Initialized
DEBUG - 2018-07-30 23:05:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-07-30 23:05:30 --> Output Class Initialized
INFO - 2018-07-30 23:05:30 --> Security Class Initialized
DEBUG - 2018-07-30 23:05:30 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-30 23:05:30 --> Login MX_Controller Initialized
DEBUG - 2018-07-30 23:05:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 23:05:30 --> Language file loaded: language/english/data_lang.php
INFO - 2018-07-30 23:05:30 --> Input Class Initialized
DEBUG - 2018-07-30 23:05:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-30 23:05:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-30 23:05:30 --> Language Class Initialized
ERROR - 2018-07-30 23:05:30 --> 404 Page Not Found: /index
INFO - 2018-07-30 23:05:32 --> Config Class Initialized
INFO - 2018-07-30 23:05:32 --> Hooks Class Initialized
DEBUG - 2018-07-30 23:05:32 --> UTF-8 Support Enabled
INFO - 2018-07-30 23:05:32 --> Utf8 Class Initialized
INFO - 2018-07-30 23:05:32 --> URI Class Initialized
INFO - 2018-07-30 23:05:32 --> Router Class Initialized
INFO - 2018-07-30 23:05:32 --> Output Class Initialized
INFO - 2018-07-30 23:05:32 --> Security Class Initialized
DEBUG - 2018-07-30 23:05:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 23:05:32 --> Input Class Initialized
INFO - 2018-07-30 23:05:32 --> Language Class Initialized
INFO - 2018-07-30 23:05:32 --> Language Class Initialized
INFO - 2018-07-30 23:05:32 --> Config Class Initialized
INFO - 2018-07-30 23:05:32 --> Loader Class Initialized
DEBUG - 2018-07-30 23:05:32 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-30 23:05:32 --> Helper loaded: url_helper
INFO - 2018-07-30 23:05:32 --> Helper loaded: form_helper
INFO - 2018-07-30 23:05:32 --> Helper loaded: date_helper
INFO - 2018-07-30 23:05:32 --> Helper loaded: util_helper
INFO - 2018-07-30 23:05:32 --> Helper loaded: text_helper
INFO - 2018-07-30 23:05:32 --> Helper loaded: string_helper
INFO - 2018-07-30 23:05:32 --> Database Driver Class Initialized
DEBUG - 2018-07-30 23:05:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 23:05:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 23:05:32 --> Email Class Initialized
INFO - 2018-07-30 23:05:32 --> Controller Class Initialized
DEBUG - 2018-07-30 23:05:32 --> Home MX_Controller Initialized
DEBUG - 2018-07-30 23:05:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-30 23:05:32 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-30 23:05:32 --> Login MX_Controller Initialized
INFO - 2018-07-30 23:05:32 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-30 23:05:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-30 23:05:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-30 23:05:51 --> Config Class Initialized
INFO - 2018-07-30 23:05:51 --> Hooks Class Initialized
DEBUG - 2018-07-30 23:05:51 --> UTF-8 Support Enabled
INFO - 2018-07-30 23:05:51 --> Utf8 Class Initialized
INFO - 2018-07-30 23:05:51 --> URI Class Initialized
INFO - 2018-07-30 23:05:51 --> Router Class Initialized
INFO - 2018-07-30 23:05:51 --> Output Class Initialized
INFO - 2018-07-30 23:05:51 --> Security Class Initialized
DEBUG - 2018-07-30 23:05:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 23:05:51 --> Input Class Initialized
INFO - 2018-07-30 23:05:51 --> Language Class Initialized
INFO - 2018-07-30 23:05:51 --> Language Class Initialized
INFO - 2018-07-30 23:05:51 --> Config Class Initialized
INFO - 2018-07-30 23:05:51 --> Loader Class Initialized
DEBUG - 2018-07-30 23:05:51 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-30 23:05:51 --> Helper loaded: url_helper
INFO - 2018-07-30 23:05:51 --> Helper loaded: form_helper
INFO - 2018-07-30 23:05:51 --> Helper loaded: date_helper
INFO - 2018-07-30 23:05:52 --> Helper loaded: util_helper
INFO - 2018-07-30 23:05:52 --> Helper loaded: text_helper
INFO - 2018-07-30 23:05:52 --> Helper loaded: string_helper
INFO - 2018-07-30 23:05:52 --> Database Driver Class Initialized
DEBUG - 2018-07-30 23:05:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 23:05:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 23:05:52 --> Email Class Initialized
INFO - 2018-07-30 23:05:52 --> Controller Class Initialized
DEBUG - 2018-07-30 23:05:52 --> Programs MX_Controller Initialized
INFO - 2018-07-30 23:05:52 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-30 23:05:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-07-30 23:05:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-30 23:05:52 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-30 23:05:52 --> Login MX_Controller Initialized
DEBUG - 2018-07-30 23:05:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-30 23:05:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-30 23:05:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-30 23:05:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-30 23:05:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-30 23:05:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-30 23:05:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/programs/create_program.php
INFO - 2018-07-30 23:05:52 --> Final output sent to browser
DEBUG - 2018-07-30 23:05:52 --> Total execution time: 0.5459
INFO - 2018-07-30 23:08:25 --> Config Class Initialized
INFO - 2018-07-30 23:08:25 --> Hooks Class Initialized
DEBUG - 2018-07-30 23:08:25 --> UTF-8 Support Enabled
INFO - 2018-07-30 23:08:25 --> Utf8 Class Initialized
INFO - 2018-07-30 23:08:25 --> URI Class Initialized
INFO - 2018-07-30 23:08:25 --> Router Class Initialized
INFO - 2018-07-30 23:08:25 --> Output Class Initialized
INFO - 2018-07-30 23:08:25 --> Security Class Initialized
DEBUG - 2018-07-30 23:08:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 23:08:25 --> Input Class Initialized
INFO - 2018-07-30 23:08:25 --> Language Class Initialized
INFO - 2018-07-30 23:08:25 --> Language Class Initialized
INFO - 2018-07-30 23:08:25 --> Config Class Initialized
INFO - 2018-07-30 23:08:25 --> Loader Class Initialized
DEBUG - 2018-07-30 23:08:25 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-30 23:08:25 --> Helper loaded: url_helper
INFO - 2018-07-30 23:08:25 --> Helper loaded: form_helper
INFO - 2018-07-30 23:08:25 --> Helper loaded: date_helper
INFO - 2018-07-30 23:08:25 --> Helper loaded: util_helper
INFO - 2018-07-30 23:08:25 --> Helper loaded: text_helper
INFO - 2018-07-30 23:08:25 --> Helper loaded: string_helper
INFO - 2018-07-30 23:08:25 --> Database Driver Class Initialized
DEBUG - 2018-07-30 23:08:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 23:08:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 23:08:25 --> Email Class Initialized
INFO - 2018-07-30 23:08:25 --> Controller Class Initialized
DEBUG - 2018-07-30 23:08:25 --> Programs MX_Controller Initialized
INFO - 2018-07-30 23:08:25 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-30 23:08:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-07-30 23:08:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-30 23:08:25 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-30 23:08:25 --> Login MX_Controller Initialized
DEBUG - 2018-07-30 23:08:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-30 23:08:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-30 23:08:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-30 23:08:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-30 23:08:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-30 23:08:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-30 23:08:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/programs/create_program.php
INFO - 2018-07-30 23:08:25 --> Final output sent to browser
DEBUG - 2018-07-30 23:08:25 --> Total execution time: 0.6073
INFO - 2018-07-30 23:08:42 --> Config Class Initialized
INFO - 2018-07-30 23:08:42 --> Hooks Class Initialized
DEBUG - 2018-07-30 23:08:42 --> UTF-8 Support Enabled
INFO - 2018-07-30 23:08:42 --> Utf8 Class Initialized
INFO - 2018-07-30 23:08:42 --> URI Class Initialized
INFO - 2018-07-30 23:08:42 --> Router Class Initialized
INFO - 2018-07-30 23:08:42 --> Output Class Initialized
INFO - 2018-07-30 23:08:42 --> Security Class Initialized
DEBUG - 2018-07-30 23:08:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 23:08:42 --> Input Class Initialized
INFO - 2018-07-30 23:08:42 --> Language Class Initialized
INFO - 2018-07-30 23:08:42 --> Language Class Initialized
INFO - 2018-07-30 23:08:42 --> Config Class Initialized
INFO - 2018-07-30 23:08:42 --> Loader Class Initialized
DEBUG - 2018-07-30 23:08:42 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-30 23:08:42 --> Helper loaded: url_helper
INFO - 2018-07-30 23:08:42 --> Helper loaded: form_helper
INFO - 2018-07-30 23:08:42 --> Helper loaded: date_helper
INFO - 2018-07-30 23:08:42 --> Helper loaded: util_helper
INFO - 2018-07-30 23:08:42 --> Helper loaded: text_helper
INFO - 2018-07-30 23:08:42 --> Helper loaded: string_helper
INFO - 2018-07-30 23:08:42 --> Database Driver Class Initialized
DEBUG - 2018-07-30 23:08:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 23:08:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 23:08:42 --> Email Class Initialized
INFO - 2018-07-30 23:08:43 --> Controller Class Initialized
DEBUG - 2018-07-30 23:08:43 --> Programs MX_Controller Initialized
INFO - 2018-07-30 23:08:43 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-30 23:08:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-07-30 23:08:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-30 23:08:43 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-30 23:08:43 --> Login MX_Controller Initialized
DEBUG - 2018-07-30 23:08:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-30 23:08:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-30 23:08:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-30 23:08:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-30 23:08:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-30 23:08:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-30 23:08:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/programs/create_program.php
INFO - 2018-07-30 23:08:43 --> Final output sent to browser
DEBUG - 2018-07-30 23:08:43 --> Total execution time: 0.5351
INFO - 2018-07-30 23:19:22 --> Config Class Initialized
INFO - 2018-07-30 23:19:22 --> Hooks Class Initialized
DEBUG - 2018-07-30 23:19:22 --> UTF-8 Support Enabled
INFO - 2018-07-30 23:19:22 --> Utf8 Class Initialized
INFO - 2018-07-30 23:19:22 --> URI Class Initialized
INFO - 2018-07-30 23:19:22 --> Router Class Initialized
INFO - 2018-07-30 23:19:22 --> Output Class Initialized
INFO - 2018-07-30 23:19:22 --> Security Class Initialized
DEBUG - 2018-07-30 23:19:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 23:19:22 --> Input Class Initialized
INFO - 2018-07-30 23:19:22 --> Language Class Initialized
INFO - 2018-07-30 23:19:22 --> Language Class Initialized
INFO - 2018-07-30 23:19:22 --> Config Class Initialized
INFO - 2018-07-30 23:19:22 --> Loader Class Initialized
DEBUG - 2018-07-30 23:19:22 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-30 23:19:22 --> Helper loaded: url_helper
INFO - 2018-07-30 23:19:22 --> Helper loaded: form_helper
INFO - 2018-07-30 23:19:22 --> Helper loaded: date_helper
INFO - 2018-07-30 23:19:22 --> Helper loaded: util_helper
INFO - 2018-07-30 23:19:22 --> Helper loaded: text_helper
INFO - 2018-07-30 23:19:22 --> Helper loaded: string_helper
INFO - 2018-07-30 23:19:22 --> Database Driver Class Initialized
DEBUG - 2018-07-30 23:19:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 23:19:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 23:19:22 --> Email Class Initialized
INFO - 2018-07-30 23:19:22 --> Controller Class Initialized
DEBUG - 2018-07-30 23:19:22 --> Admin MX_Controller Initialized
INFO - 2018-07-30 23:19:22 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-30 23:19:22 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-30 23:19:22 --> Login MX_Controller Initialized
DEBUG - 2018-07-30 23:19:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-30 23:19:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-30 23:19:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-30 23:19:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-30 23:19:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-30 23:19:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-30 23:19:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-30 23:19:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/dashboard.php
INFO - 2018-07-30 23:19:22 --> Final output sent to browser
DEBUG - 2018-07-30 23:19:22 --> Total execution time: 0.5279
INFO - 2018-07-30 23:19:22 --> Config Class Initialized
INFO - 2018-07-30 23:19:22 --> Hooks Class Initialized
INFO - 2018-07-30 23:19:22 --> Config Class Initialized
DEBUG - 2018-07-30 23:19:22 --> UTF-8 Support Enabled
INFO - 2018-07-30 23:19:22 --> Hooks Class Initialized
INFO - 2018-07-30 23:19:22 --> Utf8 Class Initialized
DEBUG - 2018-07-30 23:19:22 --> UTF-8 Support Enabled
INFO - 2018-07-30 23:19:22 --> URI Class Initialized
INFO - 2018-07-30 23:19:22 --> Utf8 Class Initialized
INFO - 2018-07-30 23:19:22 --> URI Class Initialized
INFO - 2018-07-30 23:19:23 --> Router Class Initialized
INFO - 2018-07-30 23:19:23 --> Output Class Initialized
INFO - 2018-07-30 23:19:23 --> Router Class Initialized
INFO - 2018-07-30 23:19:23 --> Output Class Initialized
INFO - 2018-07-30 23:19:23 --> Security Class Initialized
INFO - 2018-07-30 23:19:23 --> Security Class Initialized
DEBUG - 2018-07-30 23:19:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 23:19:23 --> Input Class Initialized
DEBUG - 2018-07-30 23:19:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 23:19:23 --> Language Class Initialized
INFO - 2018-07-30 23:19:23 --> Input Class Initialized
ERROR - 2018-07-30 23:19:23 --> 404 Page Not Found: /index
INFO - 2018-07-30 23:19:23 --> Language Class Initialized
ERROR - 2018-07-30 23:19:23 --> 404 Page Not Found: /index
INFO - 2018-07-30 23:19:24 --> Config Class Initialized
INFO - 2018-07-30 23:19:24 --> Hooks Class Initialized
DEBUG - 2018-07-30 23:19:24 --> UTF-8 Support Enabled
INFO - 2018-07-30 23:19:24 --> Utf8 Class Initialized
INFO - 2018-07-30 23:19:24 --> URI Class Initialized
INFO - 2018-07-30 23:19:24 --> Router Class Initialized
INFO - 2018-07-30 23:19:24 --> Output Class Initialized
INFO - 2018-07-30 23:19:24 --> Security Class Initialized
DEBUG - 2018-07-30 23:19:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 23:19:24 --> Input Class Initialized
INFO - 2018-07-30 23:19:24 --> Language Class Initialized
INFO - 2018-07-30 23:19:24 --> Language Class Initialized
INFO - 2018-07-30 23:19:24 --> Config Class Initialized
INFO - 2018-07-30 23:19:24 --> Loader Class Initialized
DEBUG - 2018-07-30 23:19:24 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-30 23:19:24 --> Helper loaded: url_helper
INFO - 2018-07-30 23:19:24 --> Helper loaded: form_helper
INFO - 2018-07-30 23:19:24 --> Helper loaded: date_helper
INFO - 2018-07-30 23:19:24 --> Helper loaded: util_helper
INFO - 2018-07-30 23:19:24 --> Helper loaded: text_helper
INFO - 2018-07-30 23:19:24 --> Helper loaded: string_helper
INFO - 2018-07-30 23:19:24 --> Database Driver Class Initialized
DEBUG - 2018-07-30 23:19:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 23:19:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 23:19:24 --> Email Class Initialized
INFO - 2018-07-30 23:19:24 --> Controller Class Initialized
DEBUG - 2018-07-30 23:19:24 --> Users MX_Controller Initialized
DEBUG - 2018-07-30 23:19:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-30 23:19:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-07-30 23:19:24 --> Helper loaded: file_helper
DEBUG - 2018-07-30 23:19:24 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-30 23:19:24 --> Login MX_Controller Initialized
INFO - 2018-07-30 23:19:24 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-30 23:19:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-30 23:19:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-30 23:19:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-30 23:19:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-30 23:19:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-30 23:19:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-30 23:19:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/users.php
INFO - 2018-07-30 23:19:24 --> Final output sent to browser
DEBUG - 2018-07-30 23:19:24 --> Total execution time: 0.5779
INFO - 2018-07-30 23:19:24 --> Config Class Initialized
INFO - 2018-07-30 23:19:24 --> Hooks Class Initialized
DEBUG - 2018-07-30 23:19:25 --> UTF-8 Support Enabled
INFO - 2018-07-30 23:19:25 --> Utf8 Class Initialized
INFO - 2018-07-30 23:19:25 --> URI Class Initialized
INFO - 2018-07-30 23:19:25 --> Router Class Initialized
INFO - 2018-07-30 23:19:25 --> Output Class Initialized
INFO - 2018-07-30 23:19:25 --> Security Class Initialized
DEBUG - 2018-07-30 23:19:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 23:19:25 --> Input Class Initialized
INFO - 2018-07-30 23:19:25 --> Language Class Initialized
INFO - 2018-07-30 23:19:25 --> Language Class Initialized
INFO - 2018-07-30 23:19:25 --> Config Class Initialized
INFO - 2018-07-30 23:19:25 --> Loader Class Initialized
DEBUG - 2018-07-30 23:19:25 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-30 23:19:25 --> Helper loaded: url_helper
INFO - 2018-07-30 23:19:25 --> Helper loaded: form_helper
INFO - 2018-07-30 23:19:25 --> Helper loaded: date_helper
INFO - 2018-07-30 23:19:25 --> Helper loaded: util_helper
INFO - 2018-07-30 23:19:25 --> Helper loaded: text_helper
INFO - 2018-07-30 23:19:25 --> Helper loaded: string_helper
INFO - 2018-07-30 23:19:25 --> Database Driver Class Initialized
DEBUG - 2018-07-30 23:19:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 23:19:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 23:19:25 --> Email Class Initialized
INFO - 2018-07-30 23:19:25 --> Controller Class Initialized
DEBUG - 2018-07-30 23:19:25 --> Users MX_Controller Initialized
INFO - 2018-07-30 23:19:25 --> Config Class Initialized
INFO - 2018-07-30 23:19:25 --> Hooks Class Initialized
DEBUG - 2018-07-30 23:19:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-30 23:19:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
DEBUG - 2018-07-30 23:19:25 --> UTF-8 Support Enabled
INFO - 2018-07-30 23:19:25 --> Utf8 Class Initialized
INFO - 2018-07-30 23:19:25 --> Helper loaded: file_helper
INFO - 2018-07-30 23:19:25 --> URI Class Initialized
DEBUG - 2018-07-30 23:19:25 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-30 23:19:25 --> Login MX_Controller Initialized
INFO - 2018-07-30 23:19:25 --> Router Class Initialized
INFO - 2018-07-30 23:19:25 --> Output Class Initialized
INFO - 2018-07-30 23:19:25 --> Language file loaded: language/english/data_lang.php
INFO - 2018-07-30 23:19:25 --> Security Class Initialized
DEBUG - 2018-07-30 23:19:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-30 23:19:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 23:19:25 --> Input Class Initialized
INFO - 2018-07-30 23:19:25 --> Language Class Initialized
INFO - 2018-07-30 23:19:25 --> Language Class Initialized
INFO - 2018-07-30 23:19:25 --> Config Class Initialized
INFO - 2018-07-30 23:19:25 --> Final output sent to browser
DEBUG - 2018-07-30 23:19:25 --> Total execution time: 0.7088
INFO - 2018-07-30 23:19:25 --> Loader Class Initialized
DEBUG - 2018-07-30 23:19:25 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-30 23:19:25 --> Helper loaded: url_helper
INFO - 2018-07-30 23:19:25 --> Helper loaded: form_helper
INFO - 2018-07-30 23:19:25 --> Helper loaded: date_helper
INFO - 2018-07-30 23:19:25 --> Helper loaded: util_helper
INFO - 2018-07-30 23:19:25 --> Helper loaded: text_helper
INFO - 2018-07-30 23:19:25 --> Helper loaded: string_helper
INFO - 2018-07-30 23:19:25 --> Database Driver Class Initialized
DEBUG - 2018-07-30 23:19:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 23:19:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 23:19:25 --> Email Class Initialized
INFO - 2018-07-30 23:19:25 --> Controller Class Initialized
DEBUG - 2018-07-30 23:19:25 --> Programs MX_Controller Initialized
INFO - 2018-07-30 23:19:25 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-30 23:19:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-07-30 23:19:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-30 23:19:25 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-30 23:19:25 --> Login MX_Controller Initialized
DEBUG - 2018-07-30 23:19:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-30 23:19:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-30 23:19:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-30 23:19:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-30 23:19:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-30 23:19:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-30 23:19:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/programs/programs.php
INFO - 2018-07-30 23:19:26 --> Final output sent to browser
DEBUG - 2018-07-30 23:19:26 --> Total execution time: 0.6226
INFO - 2018-07-30 23:19:26 --> Config Class Initialized
INFO - 2018-07-30 23:19:26 --> Hooks Class Initialized
DEBUG - 2018-07-30 23:19:26 --> UTF-8 Support Enabled
INFO - 2018-07-30 23:19:26 --> Utf8 Class Initialized
INFO - 2018-07-30 23:19:26 --> URI Class Initialized
INFO - 2018-07-30 23:19:26 --> Router Class Initialized
INFO - 2018-07-30 23:19:26 --> Output Class Initialized
INFO - 2018-07-30 23:19:26 --> Security Class Initialized
DEBUG - 2018-07-30 23:19:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 23:19:26 --> Input Class Initialized
INFO - 2018-07-30 23:19:26 --> Language Class Initialized
INFO - 2018-07-30 23:19:26 --> Config Class Initialized
INFO - 2018-07-30 23:19:26 --> Hooks Class Initialized
INFO - 2018-07-30 23:19:26 --> Language Class Initialized
INFO - 2018-07-30 23:19:26 --> Config Class Initialized
DEBUG - 2018-07-30 23:19:26 --> UTF-8 Support Enabled
INFO - 2018-07-30 23:19:26 --> Utf8 Class Initialized
INFO - 2018-07-30 23:19:26 --> Loader Class Initialized
INFO - 2018-07-30 23:19:26 --> URI Class Initialized
DEBUG - 2018-07-30 23:19:26 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-30 23:19:26 --> Router Class Initialized
INFO - 2018-07-30 23:19:26 --> Output Class Initialized
INFO - 2018-07-30 23:19:26 --> Helper loaded: url_helper
INFO - 2018-07-30 23:19:26 --> Helper loaded: form_helper
INFO - 2018-07-30 23:19:26 --> Security Class Initialized
INFO - 2018-07-30 23:19:26 --> Helper loaded: date_helper
DEBUG - 2018-07-30 23:19:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 23:19:26 --> Helper loaded: util_helper
INFO - 2018-07-30 23:19:26 --> Input Class Initialized
INFO - 2018-07-30 23:19:26 --> Helper loaded: text_helper
INFO - 2018-07-30 23:19:26 --> Language Class Initialized
INFO - 2018-07-30 23:19:26 --> Helper loaded: string_helper
INFO - 2018-07-30 23:19:26 --> Language Class Initialized
INFO - 2018-07-30 23:19:26 --> Config Class Initialized
INFO - 2018-07-30 23:19:26 --> Database Driver Class Initialized
INFO - 2018-07-30 23:19:26 --> Loader Class Initialized
DEBUG - 2018-07-30 23:19:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 23:19:26 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-07-30 23:19:26 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-30 23:19:26 --> Email Class Initialized
INFO - 2018-07-30 23:19:26 --> Helper loaded: url_helper
INFO - 2018-07-30 23:19:26 --> Controller Class Initialized
INFO - 2018-07-30 23:19:26 --> Helper loaded: form_helper
DEBUG - 2018-07-30 23:19:26 --> Programs MX_Controller Initialized
INFO - 2018-07-30 23:19:26 --> Helper loaded: date_helper
INFO - 2018-07-30 23:19:26 --> Language file loaded: language/english/data_lang.php
INFO - 2018-07-30 23:19:26 --> Helper loaded: util_helper
INFO - 2018-07-30 23:19:26 --> Helper loaded: text_helper
DEBUG - 2018-07-30 23:19:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-07-30 23:19:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-30 23:19:26 --> Helper loaded: string_helper
DEBUG - 2018-07-30 23:19:26 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
INFO - 2018-07-30 23:19:26 --> Database Driver Class Initialized
DEBUG - 2018-07-30 23:19:26 --> Login MX_Controller Initialized
DEBUG - 2018-07-30 23:19:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-07-30 23:19:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-30 23:19:26 --> Final output sent to browser
DEBUG - 2018-07-30 23:19:26 --> Total execution time: 0.6802
INFO - 2018-07-30 23:19:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 23:19:27 --> Email Class Initialized
INFO - 2018-07-30 23:19:27 --> Controller Class Initialized
DEBUG - 2018-07-30 23:19:27 --> Chapters MX_Controller Initialized
INFO - 2018-07-30 23:19:27 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-30 23:19:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Chapters_model.php
DEBUG - 2018-07-30 23:19:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-30 23:19:27 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-30 23:19:27 --> Login MX_Controller Initialized
DEBUG - 2018-07-30 23:19:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-30 23:19:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-30 23:19:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-30 23:19:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-30 23:19:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-30 23:19:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-30 23:19:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/chapters/chapters.php
INFO - 2018-07-30 23:19:27 --> Final output sent to browser
DEBUG - 2018-07-30 23:19:27 --> Total execution time: 0.6701
INFO - 2018-07-30 23:19:27 --> Config Class Initialized
INFO - 2018-07-30 23:19:27 --> Hooks Class Initialized
DEBUG - 2018-07-30 23:19:27 --> UTF-8 Support Enabled
INFO - 2018-07-30 23:19:27 --> Utf8 Class Initialized
INFO - 2018-07-30 23:19:27 --> URI Class Initialized
INFO - 2018-07-30 23:19:27 --> Router Class Initialized
INFO - 2018-07-30 23:19:27 --> Output Class Initialized
INFO - 2018-07-30 23:19:27 --> Security Class Initialized
DEBUG - 2018-07-30 23:19:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 23:19:27 --> Input Class Initialized
INFO - 2018-07-30 23:19:27 --> Language Class Initialized
INFO - 2018-07-30 23:19:27 --> Language Class Initialized
INFO - 2018-07-30 23:19:27 --> Config Class Initialized
INFO - 2018-07-30 23:19:27 --> Loader Class Initialized
DEBUG - 2018-07-30 23:19:27 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-30 23:19:27 --> Helper loaded: url_helper
INFO - 2018-07-30 23:19:27 --> Helper loaded: form_helper
INFO - 2018-07-30 23:19:27 --> Helper loaded: date_helper
INFO - 2018-07-30 23:19:27 --> Helper loaded: util_helper
INFO - 2018-07-30 23:19:27 --> Helper loaded: text_helper
INFO - 2018-07-30 23:19:27 --> Helper loaded: string_helper
INFO - 2018-07-30 23:19:27 --> Database Driver Class Initialized
DEBUG - 2018-07-30 23:19:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 23:19:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 23:19:27 --> Email Class Initialized
INFO - 2018-07-30 23:19:28 --> Controller Class Initialized
DEBUG - 2018-07-30 23:19:28 --> Chapters MX_Controller Initialized
INFO - 2018-07-30 23:19:28 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-30 23:19:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Chapters_model.php
DEBUG - 2018-07-30 23:19:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-30 23:19:28 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-30 23:19:28 --> Login MX_Controller Initialized
DEBUG - 2018-07-30 23:19:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-30 23:19:28 --> Final output sent to browser
DEBUG - 2018-07-30 23:19:28 --> Total execution time: 0.6872
INFO - 2018-07-30 23:19:29 --> Config Class Initialized
INFO - 2018-07-30 23:19:29 --> Hooks Class Initialized
DEBUG - 2018-07-30 23:19:29 --> UTF-8 Support Enabled
INFO - 2018-07-30 23:19:29 --> Utf8 Class Initialized
INFO - 2018-07-30 23:19:29 --> URI Class Initialized
INFO - 2018-07-30 23:19:29 --> Router Class Initialized
INFO - 2018-07-30 23:19:29 --> Output Class Initialized
INFO - 2018-07-30 23:19:29 --> Security Class Initialized
DEBUG - 2018-07-30 23:19:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 23:19:29 --> Input Class Initialized
INFO - 2018-07-30 23:19:29 --> Language Class Initialized
INFO - 2018-07-30 23:19:29 --> Language Class Initialized
INFO - 2018-07-30 23:19:29 --> Config Class Initialized
INFO - 2018-07-30 23:19:29 --> Loader Class Initialized
DEBUG - 2018-07-30 23:19:29 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-30 23:19:29 --> Helper loaded: url_helper
INFO - 2018-07-30 23:19:29 --> Helper loaded: form_helper
INFO - 2018-07-30 23:19:29 --> Helper loaded: date_helper
INFO - 2018-07-30 23:19:29 --> Helper loaded: util_helper
INFO - 2018-07-30 23:19:29 --> Helper loaded: text_helper
INFO - 2018-07-30 23:19:29 --> Helper loaded: string_helper
INFO - 2018-07-30 23:19:29 --> Database Driver Class Initialized
DEBUG - 2018-07-30 23:19:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 23:19:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 23:19:29 --> Email Class Initialized
INFO - 2018-07-30 23:19:29 --> Controller Class Initialized
DEBUG - 2018-07-30 23:19:29 --> Lessions MX_Controller Initialized
INFO - 2018-07-30 23:19:29 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-30 23:19:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Lessions_model.php
DEBUG - 2018-07-30 23:19:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-30 23:19:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-07-30 23:19:29 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-30 23:19:29 --> Login MX_Controller Initialized
DEBUG - 2018-07-30 23:19:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-30 23:19:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-30 23:19:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-30 23:19:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-30 23:19:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-30 23:19:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-30 23:19:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/lessions/lessions.php
INFO - 2018-07-30 23:19:29 --> Final output sent to browser
DEBUG - 2018-07-30 23:19:29 --> Total execution time: 0.6414
INFO - 2018-07-30 23:19:30 --> Config Class Initialized
INFO - 2018-07-30 23:19:30 --> Hooks Class Initialized
DEBUG - 2018-07-30 23:19:30 --> UTF-8 Support Enabled
INFO - 2018-07-30 23:19:30 --> Utf8 Class Initialized
INFO - 2018-07-30 23:19:30 --> URI Class Initialized
INFO - 2018-07-30 23:19:30 --> Router Class Initialized
INFO - 2018-07-30 23:19:30 --> Output Class Initialized
INFO - 2018-07-30 23:19:30 --> Security Class Initialized
DEBUG - 2018-07-30 23:19:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 23:19:30 --> Input Class Initialized
INFO - 2018-07-30 23:19:30 --> Language Class Initialized
INFO - 2018-07-30 23:19:30 --> Language Class Initialized
INFO - 2018-07-30 23:19:30 --> Config Class Initialized
INFO - 2018-07-30 23:19:30 --> Loader Class Initialized
DEBUG - 2018-07-30 23:19:30 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-30 23:19:30 --> Helper loaded: url_helper
INFO - 2018-07-30 23:19:30 --> Helper loaded: form_helper
INFO - 2018-07-30 23:19:30 --> Helper loaded: date_helper
INFO - 2018-07-30 23:19:30 --> Helper loaded: util_helper
INFO - 2018-07-30 23:19:30 --> Helper loaded: text_helper
INFO - 2018-07-30 23:19:30 --> Helper loaded: string_helper
INFO - 2018-07-30 23:19:30 --> Database Driver Class Initialized
DEBUG - 2018-07-30 23:19:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 23:19:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 23:19:30 --> Email Class Initialized
INFO - 2018-07-30 23:19:30 --> Controller Class Initialized
DEBUG - 2018-07-30 23:19:30 --> Lessions MX_Controller Initialized
INFO - 2018-07-30 23:19:30 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-30 23:19:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Lessions_model.php
DEBUG - 2018-07-30 23:19:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-30 23:19:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-07-30 23:19:30 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-30 23:19:30 --> Login MX_Controller Initialized
DEBUG - 2018-07-30 23:19:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-30 23:19:30 --> Final output sent to browser
DEBUG - 2018-07-30 23:19:30 --> Total execution time: 0.6577
INFO - 2018-07-30 23:19:31 --> Config Class Initialized
INFO - 2018-07-30 23:19:31 --> Hooks Class Initialized
DEBUG - 2018-07-30 23:19:31 --> UTF-8 Support Enabled
INFO - 2018-07-30 23:19:31 --> Utf8 Class Initialized
INFO - 2018-07-30 23:19:31 --> URI Class Initialized
INFO - 2018-07-30 23:19:31 --> Router Class Initialized
INFO - 2018-07-30 23:19:31 --> Output Class Initialized
INFO - 2018-07-30 23:19:31 --> Security Class Initialized
DEBUG - 2018-07-30 23:19:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 23:19:31 --> Input Class Initialized
INFO - 2018-07-30 23:19:31 --> Language Class Initialized
INFO - 2018-07-30 23:19:31 --> Language Class Initialized
INFO - 2018-07-30 23:19:31 --> Config Class Initialized
INFO - 2018-07-30 23:19:31 --> Loader Class Initialized
DEBUG - 2018-07-30 23:19:31 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-30 23:19:31 --> Helper loaded: url_helper
INFO - 2018-07-30 23:19:31 --> Helper loaded: form_helper
INFO - 2018-07-30 23:19:31 --> Helper loaded: date_helper
INFO - 2018-07-30 23:19:31 --> Helper loaded: util_helper
INFO - 2018-07-30 23:19:31 --> Helper loaded: text_helper
INFO - 2018-07-30 23:19:31 --> Helper loaded: string_helper
INFO - 2018-07-30 23:19:31 --> Database Driver Class Initialized
DEBUG - 2018-07-30 23:19:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 23:19:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 23:19:31 --> Email Class Initialized
INFO - 2018-07-30 23:19:31 --> Controller Class Initialized
DEBUG - 2018-07-30 23:19:31 --> videos MX_Controller Initialized
INFO - 2018-07-30 23:19:31 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-30 23:19:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-07-30 23:19:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-30 23:19:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-07-30 23:19:31 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-30 23:19:31 --> Login MX_Controller Initialized
DEBUG - 2018-07-30 23:19:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-30 23:19:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-30 23:19:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-30 23:19:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-30 23:19:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-30 23:19:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-30 23:19:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/videos/videos.php
INFO - 2018-07-30 23:19:31 --> Final output sent to browser
DEBUG - 2018-07-30 23:19:31 --> Total execution time: 0.5755
INFO - 2018-07-30 23:19:32 --> Config Class Initialized
INFO - 2018-07-30 23:19:32 --> Hooks Class Initialized
DEBUG - 2018-07-30 23:19:32 --> UTF-8 Support Enabled
INFO - 2018-07-30 23:19:32 --> Utf8 Class Initialized
INFO - 2018-07-30 23:19:32 --> URI Class Initialized
INFO - 2018-07-30 23:19:32 --> Router Class Initialized
INFO - 2018-07-30 23:19:32 --> Output Class Initialized
INFO - 2018-07-30 23:19:32 --> Security Class Initialized
DEBUG - 2018-07-30 23:19:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 23:19:32 --> Input Class Initialized
INFO - 2018-07-30 23:19:32 --> Language Class Initialized
INFO - 2018-07-30 23:19:32 --> Language Class Initialized
INFO - 2018-07-30 23:19:32 --> Config Class Initialized
INFO - 2018-07-30 23:19:32 --> Loader Class Initialized
DEBUG - 2018-07-30 23:19:32 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-30 23:19:32 --> Helper loaded: url_helper
INFO - 2018-07-30 23:19:32 --> Helper loaded: form_helper
INFO - 2018-07-30 23:19:32 --> Helper loaded: date_helper
INFO - 2018-07-30 23:19:32 --> Helper loaded: util_helper
INFO - 2018-07-30 23:19:32 --> Helper loaded: text_helper
INFO - 2018-07-30 23:19:32 --> Helper loaded: string_helper
INFO - 2018-07-30 23:19:32 --> Database Driver Class Initialized
DEBUG - 2018-07-30 23:19:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 23:19:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 23:19:32 --> Email Class Initialized
INFO - 2018-07-30 23:19:32 --> Controller Class Initialized
DEBUG - 2018-07-30 23:19:32 --> videos MX_Controller Initialized
INFO - 2018-07-30 23:19:32 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-30 23:19:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-07-30 23:19:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-30 23:19:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-07-30 23:19:32 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-30 23:19:32 --> Login MX_Controller Initialized
DEBUG - 2018-07-30 23:19:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-30 23:19:32 --> Final output sent to browser
DEBUG - 2018-07-30 23:19:32 --> Total execution time: 0.6841
INFO - 2018-07-30 23:19:33 --> Config Class Initialized
INFO - 2018-07-30 23:19:33 --> Hooks Class Initialized
DEBUG - 2018-07-30 23:19:33 --> UTF-8 Support Enabled
INFO - 2018-07-30 23:19:33 --> Utf8 Class Initialized
INFO - 2018-07-30 23:19:33 --> URI Class Initialized
INFO - 2018-07-30 23:19:33 --> Router Class Initialized
INFO - 2018-07-30 23:19:33 --> Output Class Initialized
INFO - 2018-07-30 23:19:33 --> Security Class Initialized
DEBUG - 2018-07-30 23:19:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 23:19:33 --> Input Class Initialized
INFO - 2018-07-30 23:19:33 --> Language Class Initialized
INFO - 2018-07-30 23:19:33 --> Language Class Initialized
INFO - 2018-07-30 23:19:33 --> Config Class Initialized
INFO - 2018-07-30 23:19:33 --> Loader Class Initialized
DEBUG - 2018-07-30 23:19:33 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-30 23:19:33 --> Helper loaded: url_helper
INFO - 2018-07-30 23:19:33 --> Helper loaded: form_helper
INFO - 2018-07-30 23:19:33 --> Helper loaded: date_helper
INFO - 2018-07-30 23:19:33 --> Helper loaded: util_helper
INFO - 2018-07-30 23:19:33 --> Helper loaded: text_helper
INFO - 2018-07-30 23:19:33 --> Helper loaded: string_helper
INFO - 2018-07-30 23:19:33 --> Database Driver Class Initialized
DEBUG - 2018-07-30 23:19:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 23:19:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 23:19:33 --> Email Class Initialized
INFO - 2018-07-30 23:19:33 --> Controller Class Initialized
DEBUG - 2018-07-30 23:19:33 --> Profile MX_Controller Initialized
INFO - 2018-07-30 23:19:33 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-30 23:19:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-30 23:19:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Profile_model.php
DEBUG - 2018-07-30 23:19:33 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-30 23:19:33 --> Login MX_Controller Initialized
DEBUG - 2018-07-30 23:19:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-30 23:19:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-30 23:19:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-30 23:19:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-30 23:19:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-30 23:19:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-30 23:19:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/profile.php
INFO - 2018-07-30 23:19:33 --> Final output sent to browser
DEBUG - 2018-07-30 23:19:33 --> Total execution time: 0.5733
INFO - 2018-07-30 23:19:35 --> Config Class Initialized
INFO - 2018-07-30 23:19:35 --> Hooks Class Initialized
DEBUG - 2018-07-30 23:19:35 --> UTF-8 Support Enabled
INFO - 2018-07-30 23:19:35 --> Utf8 Class Initialized
INFO - 2018-07-30 23:19:35 --> URI Class Initialized
INFO - 2018-07-30 23:19:35 --> Router Class Initialized
INFO - 2018-07-30 23:19:35 --> Output Class Initialized
INFO - 2018-07-30 23:19:35 --> Security Class Initialized
DEBUG - 2018-07-30 23:19:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 23:19:35 --> Input Class Initialized
INFO - 2018-07-30 23:19:35 --> Language Class Initialized
INFO - 2018-07-30 23:19:35 --> Language Class Initialized
INFO - 2018-07-30 23:19:35 --> Config Class Initialized
INFO - 2018-07-30 23:19:35 --> Loader Class Initialized
DEBUG - 2018-07-30 23:19:35 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-30 23:19:35 --> Helper loaded: url_helper
INFO - 2018-07-30 23:19:35 --> Helper loaded: form_helper
INFO - 2018-07-30 23:19:35 --> Helper loaded: date_helper
INFO - 2018-07-30 23:19:35 --> Helper loaded: util_helper
INFO - 2018-07-30 23:19:35 --> Helper loaded: text_helper
INFO - 2018-07-30 23:19:35 --> Helper loaded: string_helper
INFO - 2018-07-30 23:19:35 --> Database Driver Class Initialized
DEBUG - 2018-07-30 23:19:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 23:19:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 23:19:35 --> Email Class Initialized
INFO - 2018-07-30 23:19:35 --> Controller Class Initialized
DEBUG - 2018-07-30 23:19:35 --> Profile MX_Controller Initialized
INFO - 2018-07-30 23:19:35 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-30 23:19:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-30 23:19:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Profile_model.php
DEBUG - 2018-07-30 23:19:35 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-30 23:19:35 --> Login MX_Controller Initialized
DEBUG - 2018-07-30 23:19:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-30 23:19:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-30 23:19:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-30 23:19:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-30 23:19:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-30 23:19:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-30 23:19:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/admin_password.php
INFO - 2018-07-30 23:19:35 --> Final output sent to browser
DEBUG - 2018-07-30 23:19:35 --> Total execution time: 0.5756
INFO - 2018-07-30 23:19:39 --> Config Class Initialized
INFO - 2018-07-30 23:19:39 --> Hooks Class Initialized
DEBUG - 2018-07-30 23:19:39 --> UTF-8 Support Enabled
INFO - 2018-07-30 23:19:39 --> Utf8 Class Initialized
INFO - 2018-07-30 23:19:39 --> URI Class Initialized
INFO - 2018-07-30 23:19:39 --> Router Class Initialized
INFO - 2018-07-30 23:19:39 --> Output Class Initialized
INFO - 2018-07-30 23:19:39 --> Security Class Initialized
DEBUG - 2018-07-30 23:19:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 23:19:39 --> Input Class Initialized
INFO - 2018-07-30 23:19:39 --> Language Class Initialized
INFO - 2018-07-30 23:19:39 --> Language Class Initialized
INFO - 2018-07-30 23:19:39 --> Config Class Initialized
INFO - 2018-07-30 23:19:39 --> Loader Class Initialized
DEBUG - 2018-07-30 23:19:39 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-30 23:19:39 --> Helper loaded: url_helper
INFO - 2018-07-30 23:19:39 --> Helper loaded: form_helper
INFO - 2018-07-30 23:19:39 --> Helper loaded: date_helper
INFO - 2018-07-30 23:19:39 --> Helper loaded: util_helper
INFO - 2018-07-30 23:19:39 --> Helper loaded: text_helper
INFO - 2018-07-30 23:19:39 --> Helper loaded: string_helper
INFO - 2018-07-30 23:19:39 --> Database Driver Class Initialized
DEBUG - 2018-07-30 23:19:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 23:19:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 23:19:39 --> Email Class Initialized
INFO - 2018-07-30 23:19:39 --> Controller Class Initialized
DEBUG - 2018-07-30 23:19:39 --> Home MX_Controller Initialized
DEBUG - 2018-07-30 23:19:39 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-30 23:19:39 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-30 23:19:39 --> Login MX_Controller Initialized
INFO - 2018-07-30 23:19:39 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-30 23:19:39 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-30 23:19:39 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-30 23:19:39 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-07-30 23:19:39 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-07-30 23:19:39 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-07-30 23:19:39 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-07-30 23:19:39 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-07-30 23:19:39 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-07-30 23:19:39 --> Final output sent to browser
DEBUG - 2018-07-30 23:19:39 --> Total execution time: 0.5839
INFO - 2018-07-30 23:19:40 --> Config Class Initialized
INFO - 2018-07-30 23:19:40 --> Hooks Class Initialized
INFO - 2018-07-30 23:19:40 --> Config Class Initialized
DEBUG - 2018-07-30 23:19:40 --> UTF-8 Support Enabled
INFO - 2018-07-30 23:19:40 --> Utf8 Class Initialized
INFO - 2018-07-30 23:19:40 --> URI Class Initialized
INFO - 2018-07-30 23:19:40 --> Router Class Initialized
INFO - 2018-07-30 23:19:40 --> Output Class Initialized
INFO - 2018-07-30 23:19:40 --> Security Class Initialized
DEBUG - 2018-07-30 23:19:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 23:19:40 --> Input Class Initialized
INFO - 2018-07-30 23:19:40 --> Hooks Class Initialized
INFO - 2018-07-30 23:19:40 --> Language Class Initialized
DEBUG - 2018-07-30 23:19:40 --> UTF-8 Support Enabled
ERROR - 2018-07-30 23:19:40 --> 404 Page Not Found: /index
INFO - 2018-07-30 23:19:40 --> Utf8 Class Initialized
INFO - 2018-07-30 23:19:40 --> URI Class Initialized
INFO - 2018-07-30 23:19:40 --> Config Class Initialized
INFO - 2018-07-30 23:19:40 --> Hooks Class Initialized
INFO - 2018-07-30 23:19:40 --> Router Class Initialized
DEBUG - 2018-07-30 23:19:40 --> UTF-8 Support Enabled
INFO - 2018-07-30 23:19:40 --> Utf8 Class Initialized
INFO - 2018-07-30 23:19:40 --> URI Class Initialized
INFO - 2018-07-30 23:19:41 --> Output Class Initialized
INFO - 2018-07-30 23:19:41 --> Router Class Initialized
INFO - 2018-07-30 23:19:41 --> Security Class Initialized
INFO - 2018-07-30 23:19:41 --> Output Class Initialized
DEBUG - 2018-07-30 23:19:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 23:19:41 --> Input Class Initialized
INFO - 2018-07-30 23:19:41 --> Security Class Initialized
DEBUG - 2018-07-30 23:19:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 23:19:41 --> Language Class Initialized
INFO - 2018-07-30 23:19:41 --> Input Class Initialized
INFO - 2018-07-30 23:19:41 --> Language Class Initialized
ERROR - 2018-07-30 23:19:41 --> 404 Page Not Found: /index
INFO - 2018-07-30 23:19:41 --> Language Class Initialized
INFO - 2018-07-30 23:19:41 --> Config Class Initialized
INFO - 2018-07-30 23:19:41 --> Config Class Initialized
INFO - 2018-07-30 23:19:41 --> Hooks Class Initialized
INFO - 2018-07-30 23:19:41 --> Loader Class Initialized
DEBUG - 2018-07-30 23:19:41 --> UTF-8 Support Enabled
DEBUG - 2018-07-30 23:19:41 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-30 23:19:41 --> Utf8 Class Initialized
INFO - 2018-07-30 23:19:41 --> Helper loaded: url_helper
INFO - 2018-07-30 23:19:41 --> URI Class Initialized
INFO - 2018-07-30 23:19:41 --> Helper loaded: form_helper
INFO - 2018-07-30 23:19:41 --> Helper loaded: date_helper
INFO - 2018-07-30 23:19:41 --> Helper loaded: util_helper
INFO - 2018-07-30 23:19:41 --> Router Class Initialized
INFO - 2018-07-30 23:19:41 --> Output Class Initialized
INFO - 2018-07-30 23:19:41 --> Helper loaded: text_helper
INFO - 2018-07-30 23:19:41 --> Security Class Initialized
DEBUG - 2018-07-30 23:19:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 23:19:41 --> Input Class Initialized
INFO - 2018-07-30 23:19:41 --> Language Class Initialized
ERROR - 2018-07-30 23:19:41 --> 404 Page Not Found: /index
INFO - 2018-07-30 23:19:41 --> Helper loaded: string_helper
INFO - 2018-07-30 23:19:41 --> Database Driver Class Initialized
INFO - 2018-07-30 23:19:41 --> Config Class Initialized
INFO - 2018-07-30 23:19:41 --> Hooks Class Initialized
DEBUG - 2018-07-30 23:19:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 23:19:41 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-07-30 23:19:41 --> UTF-8 Support Enabled
INFO - 2018-07-30 23:19:41 --> Utf8 Class Initialized
INFO - 2018-07-30 23:19:41 --> Email Class Initialized
INFO - 2018-07-30 23:19:41 --> URI Class Initialized
INFO - 2018-07-30 23:19:41 --> Controller Class Initialized
INFO - 2018-07-30 23:19:41 --> Router Class Initialized
INFO - 2018-07-30 23:19:41 --> Output Class Initialized
DEBUG - 2018-07-30 23:19:41 --> Home MX_Controller Initialized
INFO - 2018-07-30 23:19:41 --> Security Class Initialized
DEBUG - 2018-07-30 23:19:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 23:19:41 --> Input Class Initialized
INFO - 2018-07-30 23:19:41 --> Language Class Initialized
ERROR - 2018-07-30 23:19:41 --> 404 Page Not Found: /index
DEBUG - 2018-07-30 23:19:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-07-30 23:19:41 --> Config Class Initialized
INFO - 2018-07-30 23:19:41 --> Hooks Class Initialized
DEBUG - 2018-07-30 23:19:41 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-30 23:19:41 --> Login MX_Controller Initialized
DEBUG - 2018-07-30 23:19:41 --> UTF-8 Support Enabled
INFO - 2018-07-30 23:19:41 --> Utf8 Class Initialized
INFO - 2018-07-30 23:19:41 --> Language file loaded: language/english/data_lang.php
INFO - 2018-07-30 23:19:41 --> URI Class Initialized
INFO - 2018-07-30 23:19:41 --> Router Class Initialized
DEBUG - 2018-07-30 23:19:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-30 23:19:41 --> Output Class Initialized
DEBUG - 2018-07-30 23:19:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-30 23:19:41 --> Security Class Initialized
DEBUG - 2018-07-30 23:19:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 23:19:42 --> Input Class Initialized
INFO - 2018-07-30 23:19:42 --> Language Class Initialized
ERROR - 2018-07-30 23:19:42 --> 404 Page Not Found: /index
INFO - 2018-07-30 23:19:42 --> Config Class Initialized
INFO - 2018-07-30 23:19:42 --> Hooks Class Initialized
DEBUG - 2018-07-30 23:19:42 --> UTF-8 Support Enabled
INFO - 2018-07-30 23:19:42 --> Utf8 Class Initialized
INFO - 2018-07-30 23:19:42 --> URI Class Initialized
INFO - 2018-07-30 23:19:42 --> Router Class Initialized
INFO - 2018-07-30 23:19:42 --> Output Class Initialized
INFO - 2018-07-30 23:19:42 --> Security Class Initialized
DEBUG - 2018-07-30 23:19:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 23:19:42 --> Input Class Initialized
INFO - 2018-07-30 23:19:42 --> Language Class Initialized
ERROR - 2018-07-30 23:19:42 --> 404 Page Not Found: /index
INFO - 2018-07-30 23:19:43 --> Config Class Initialized
INFO - 2018-07-30 23:19:44 --> Hooks Class Initialized
DEBUG - 2018-07-30 23:19:44 --> UTF-8 Support Enabled
INFO - 2018-07-30 23:19:44 --> Utf8 Class Initialized
INFO - 2018-07-30 23:19:44 --> URI Class Initialized
INFO - 2018-07-30 23:19:44 --> Router Class Initialized
INFO - 2018-07-30 23:19:44 --> Output Class Initialized
INFO - 2018-07-30 23:19:44 --> Security Class Initialized
DEBUG - 2018-07-30 23:19:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 23:19:44 --> Input Class Initialized
INFO - 2018-07-30 23:19:44 --> Language Class Initialized
INFO - 2018-07-30 23:19:44 --> Language Class Initialized
INFO - 2018-07-30 23:19:44 --> Config Class Initialized
INFO - 2018-07-30 23:19:44 --> Loader Class Initialized
DEBUG - 2018-07-30 23:19:44 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-30 23:19:44 --> Helper loaded: url_helper
INFO - 2018-07-30 23:19:44 --> Helper loaded: form_helper
INFO - 2018-07-30 23:19:44 --> Helper loaded: date_helper
INFO - 2018-07-30 23:19:44 --> Helper loaded: util_helper
INFO - 2018-07-30 23:19:44 --> Helper loaded: text_helper
INFO - 2018-07-30 23:19:44 --> Helper loaded: string_helper
INFO - 2018-07-30 23:19:44 --> Database Driver Class Initialized
DEBUG - 2018-07-30 23:19:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 23:19:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 23:19:44 --> Email Class Initialized
INFO - 2018-07-30 23:19:44 --> Controller Class Initialized
DEBUG - 2018-07-30 23:19:44 --> Home MX_Controller Initialized
DEBUG - 2018-07-30 23:19:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-30 23:19:44 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-30 23:19:44 --> Login MX_Controller Initialized
INFO - 2018-07-30 23:19:44 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-30 23:19:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-30 23:19:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-30 23:19:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-07-30 23:19:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-07-30 23:19:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-07-30 23:19:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-07-30 23:19:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-07-30 23:19:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/progress.php
INFO - 2018-07-30 23:19:44 --> Final output sent to browser
DEBUG - 2018-07-30 23:19:44 --> Total execution time: 0.5892
INFO - 2018-07-30 23:19:44 --> Config Class Initialized
INFO - 2018-07-30 23:19:44 --> Hooks Class Initialized
DEBUG - 2018-07-30 23:19:44 --> UTF-8 Support Enabled
INFO - 2018-07-30 23:19:44 --> Config Class Initialized
INFO - 2018-07-30 23:19:44 --> Hooks Class Initialized
INFO - 2018-07-30 23:19:44 --> Utf8 Class Initialized
DEBUG - 2018-07-30 23:19:44 --> UTF-8 Support Enabled
INFO - 2018-07-30 23:19:44 --> Utf8 Class Initialized
INFO - 2018-07-30 23:19:44 --> URI Class Initialized
INFO - 2018-07-30 23:19:44 --> URI Class Initialized
INFO - 2018-07-30 23:19:45 --> Router Class Initialized
INFO - 2018-07-30 23:19:45 --> Output Class Initialized
INFO - 2018-07-30 23:19:45 --> Router Class Initialized
INFO - 2018-07-30 23:19:45 --> Security Class Initialized
INFO - 2018-07-30 23:19:45 --> Output Class Initialized
DEBUG - 2018-07-30 23:19:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 23:19:45 --> Security Class Initialized
DEBUG - 2018-07-30 23:19:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 23:19:45 --> Input Class Initialized
INFO - 2018-07-30 23:19:45 --> Input Class Initialized
INFO - 2018-07-30 23:19:45 --> Language Class Initialized
INFO - 2018-07-30 23:19:45 --> Language Class Initialized
ERROR - 2018-07-30 23:19:45 --> 404 Page Not Found: /index
INFO - 2018-07-30 23:19:45 --> Language Class Initialized
INFO - 2018-07-30 23:19:45 --> Config Class Initialized
INFO - 2018-07-30 23:19:45 --> Config Class Initialized
INFO - 2018-07-30 23:19:45 --> Hooks Class Initialized
INFO - 2018-07-30 23:19:45 --> Loader Class Initialized
DEBUG - 2018-07-30 23:19:45 --> UTF-8 Support Enabled
INFO - 2018-07-30 23:19:45 --> Utf8 Class Initialized
INFO - 2018-07-30 23:19:45 --> URI Class Initialized
DEBUG - 2018-07-30 23:19:45 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-30 23:19:45 --> Router Class Initialized
INFO - 2018-07-30 23:19:45 --> Helper loaded: url_helper
INFO - 2018-07-30 23:19:45 --> Helper loaded: form_helper
INFO - 2018-07-30 23:19:45 --> Helper loaded: date_helper
INFO - 2018-07-30 23:19:45 --> Helper loaded: util_helper
INFO - 2018-07-30 23:19:45 --> Helper loaded: text_helper
INFO - 2018-07-30 23:19:45 --> Helper loaded: string_helper
INFO - 2018-07-30 23:19:45 --> Output Class Initialized
INFO - 2018-07-30 23:19:45 --> Security Class Initialized
INFO - 2018-07-30 23:19:45 --> Database Driver Class Initialized
DEBUG - 2018-07-30 23:19:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-07-30 23:19:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 23:19:45 --> Input Class Initialized
INFO - 2018-07-30 23:19:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 23:19:45 --> Email Class Initialized
INFO - 2018-07-30 23:19:45 --> Language Class Initialized
INFO - 2018-07-30 23:19:45 --> Controller Class Initialized
DEBUG - 2018-07-30 23:19:45 --> Home MX_Controller Initialized
DEBUG - 2018-07-30 23:19:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
ERROR - 2018-07-30 23:19:45 --> 404 Page Not Found: /index
DEBUG - 2018-07-30 23:19:45 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
INFO - 2018-07-30 23:19:45 --> Config Class Initialized
INFO - 2018-07-30 23:19:45 --> Hooks Class Initialized
DEBUG - 2018-07-30 23:19:45 --> Login MX_Controller Initialized
DEBUG - 2018-07-30 23:19:45 --> UTF-8 Support Enabled
INFO - 2018-07-30 23:19:45 --> Utf8 Class Initialized
INFO - 2018-07-30 23:19:45 --> URI Class Initialized
INFO - 2018-07-30 23:19:45 --> Language file loaded: language/english/data_lang.php
INFO - 2018-07-30 23:19:45 --> Router Class Initialized
DEBUG - 2018-07-30 23:19:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-30 23:19:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-30 23:19:45 --> Output Class Initialized
INFO - 2018-07-30 23:19:45 --> Security Class Initialized
DEBUG - 2018-07-30 23:19:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 23:19:45 --> Input Class Initialized
INFO - 2018-07-30 23:19:45 --> Language Class Initialized
ERROR - 2018-07-30 23:19:45 --> 404 Page Not Found: /index
INFO - 2018-07-30 23:19:47 --> Config Class Initialized
INFO - 2018-07-30 23:19:47 --> Hooks Class Initialized
DEBUG - 2018-07-30 23:19:47 --> UTF-8 Support Enabled
INFO - 2018-07-30 23:19:47 --> Utf8 Class Initialized
INFO - 2018-07-30 23:19:47 --> URI Class Initialized
INFO - 2018-07-30 23:19:47 --> Router Class Initialized
INFO - 2018-07-30 23:19:47 --> Output Class Initialized
INFO - 2018-07-30 23:19:47 --> Security Class Initialized
DEBUG - 2018-07-30 23:19:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 23:19:47 --> Input Class Initialized
INFO - 2018-07-30 23:19:47 --> Language Class Initialized
INFO - 2018-07-30 23:19:47 --> Language Class Initialized
INFO - 2018-07-30 23:19:47 --> Config Class Initialized
INFO - 2018-07-30 23:19:47 --> Loader Class Initialized
DEBUG - 2018-07-30 23:19:47 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-30 23:19:47 --> Helper loaded: url_helper
INFO - 2018-07-30 23:19:47 --> Helper loaded: form_helper
INFO - 2018-07-30 23:19:47 --> Helper loaded: date_helper
INFO - 2018-07-30 23:19:47 --> Helper loaded: util_helper
INFO - 2018-07-30 23:19:47 --> Helper loaded: text_helper
INFO - 2018-07-30 23:19:47 --> Helper loaded: string_helper
INFO - 2018-07-30 23:19:47 --> Database Driver Class Initialized
DEBUG - 2018-07-30 23:19:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 23:19:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 23:19:47 --> Email Class Initialized
INFO - 2018-07-30 23:19:47 --> Controller Class Initialized
DEBUG - 2018-07-30 23:19:47 --> Home MX_Controller Initialized
DEBUG - 2018-07-30 23:19:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-30 23:19:47 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-30 23:19:47 --> Login MX_Controller Initialized
INFO - 2018-07-30 23:19:47 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-30 23:19:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-30 23:19:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-30 23:19:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-07-30 23:19:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-07-30 23:19:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-07-30 23:19:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-07-30 23:19:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-07-30 23:19:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/progress_product.php
INFO - 2018-07-30 23:19:48 --> Final output sent to browser
DEBUG - 2018-07-30 23:19:48 --> Total execution time: 0.5885
INFO - 2018-07-30 23:19:48 --> Config Class Initialized
INFO - 2018-07-30 23:19:48 --> Hooks Class Initialized
INFO - 2018-07-30 23:19:48 --> Config Class Initialized
INFO - 2018-07-30 23:19:48 --> Hooks Class Initialized
DEBUG - 2018-07-30 23:19:48 --> UTF-8 Support Enabled
INFO - 2018-07-30 23:19:48 --> Utf8 Class Initialized
DEBUG - 2018-07-30 23:19:48 --> UTF-8 Support Enabled
INFO - 2018-07-30 23:19:48 --> URI Class Initialized
INFO - 2018-07-30 23:19:48 --> Utf8 Class Initialized
INFO - 2018-07-30 23:19:48 --> Router Class Initialized
INFO - 2018-07-30 23:19:48 --> URI Class Initialized
INFO - 2018-07-30 23:19:48 --> Output Class Initialized
INFO - 2018-07-30 23:19:48 --> Router Class Initialized
INFO - 2018-07-30 23:19:48 --> Security Class Initialized
INFO - 2018-07-30 23:19:48 --> Output Class Initialized
DEBUG - 2018-07-30 23:19:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 23:19:48 --> Security Class Initialized
INFO - 2018-07-30 23:19:48 --> Input Class Initialized
DEBUG - 2018-07-30 23:19:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 23:19:48 --> Input Class Initialized
INFO - 2018-07-30 23:19:48 --> Language Class Initialized
INFO - 2018-07-30 23:19:48 --> Language Class Initialized
INFO - 2018-07-30 23:19:48 --> Language Class Initialized
ERROR - 2018-07-30 23:19:48 --> 404 Page Not Found: /index
INFO - 2018-07-30 23:19:48 --> Config Class Initialized
INFO - 2018-07-30 23:19:48 --> Config Class Initialized
INFO - 2018-07-30 23:19:48 --> Hooks Class Initialized
INFO - 2018-07-30 23:19:48 --> Loader Class Initialized
DEBUG - 2018-07-30 23:19:48 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
DEBUG - 2018-07-30 23:19:48 --> UTF-8 Support Enabled
INFO - 2018-07-30 23:19:48 --> Utf8 Class Initialized
INFO - 2018-07-30 23:19:48 --> Helper loaded: url_helper
INFO - 2018-07-30 23:19:48 --> URI Class Initialized
INFO - 2018-07-30 23:19:48 --> Helper loaded: form_helper
INFO - 2018-07-30 23:19:48 --> Helper loaded: date_helper
INFO - 2018-07-30 23:19:48 --> Router Class Initialized
INFO - 2018-07-30 23:19:48 --> Helper loaded: util_helper
INFO - 2018-07-30 23:19:48 --> Output Class Initialized
INFO - 2018-07-30 23:19:48 --> Security Class Initialized
INFO - 2018-07-30 23:19:48 --> Helper loaded: text_helper
INFO - 2018-07-30 23:19:48 --> Helper loaded: string_helper
DEBUG - 2018-07-30 23:19:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 23:19:48 --> Input Class Initialized
INFO - 2018-07-30 23:19:48 --> Database Driver Class Initialized
INFO - 2018-07-30 23:19:48 --> Language Class Initialized
DEBUG - 2018-07-30 23:19:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2018-07-30 23:19:48 --> 404 Page Not Found: /index
INFO - 2018-07-30 23:19:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 23:19:48 --> Email Class Initialized
INFO - 2018-07-30 23:19:48 --> Config Class Initialized
INFO - 2018-07-30 23:19:48 --> Hooks Class Initialized
INFO - 2018-07-30 23:19:48 --> Controller Class Initialized
DEBUG - 2018-07-30 23:19:48 --> Home MX_Controller Initialized
DEBUG - 2018-07-30 23:19:48 --> UTF-8 Support Enabled
INFO - 2018-07-30 23:19:48 --> Utf8 Class Initialized
DEBUG - 2018-07-30 23:19:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-07-30 23:19:48 --> URI Class Initialized
DEBUG - 2018-07-30 23:19:48 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
INFO - 2018-07-30 23:19:48 --> Router Class Initialized
DEBUG - 2018-07-30 23:19:48 --> Login MX_Controller Initialized
INFO - 2018-07-30 23:19:48 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-30 23:19:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-30 23:19:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-30 23:19:49 --> Output Class Initialized
INFO - 2018-07-30 23:19:49 --> Security Class Initialized
DEBUG - 2018-07-30 23:19:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 23:19:49 --> Input Class Initialized
INFO - 2018-07-30 23:19:49 --> Language Class Initialized
ERROR - 2018-07-30 23:19:49 --> 404 Page Not Found: /index
INFO - 2018-07-30 23:19:50 --> Config Class Initialized
INFO - 2018-07-30 23:19:50 --> Hooks Class Initialized
DEBUG - 2018-07-30 23:19:50 --> UTF-8 Support Enabled
INFO - 2018-07-30 23:19:50 --> Utf8 Class Initialized
INFO - 2018-07-30 23:19:50 --> URI Class Initialized
INFO - 2018-07-30 23:19:50 --> Router Class Initialized
INFO - 2018-07-30 23:19:50 --> Output Class Initialized
INFO - 2018-07-30 23:19:50 --> Security Class Initialized
DEBUG - 2018-07-30 23:19:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 23:19:50 --> Input Class Initialized
INFO - 2018-07-30 23:19:50 --> Language Class Initialized
INFO - 2018-07-30 23:19:50 --> Language Class Initialized
INFO - 2018-07-30 23:19:50 --> Config Class Initialized
INFO - 2018-07-30 23:19:50 --> Loader Class Initialized
DEBUG - 2018-07-30 23:19:50 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-30 23:19:50 --> Helper loaded: url_helper
INFO - 2018-07-30 23:19:50 --> Helper loaded: form_helper
INFO - 2018-07-30 23:19:50 --> Helper loaded: date_helper
INFO - 2018-07-30 23:19:50 --> Helper loaded: util_helper
INFO - 2018-07-30 23:19:50 --> Helper loaded: text_helper
INFO - 2018-07-30 23:19:51 --> Helper loaded: string_helper
INFO - 2018-07-30 23:19:51 --> Database Driver Class Initialized
DEBUG - 2018-07-30 23:19:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 23:19:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 23:19:51 --> Email Class Initialized
INFO - 2018-07-30 23:19:51 --> Controller Class Initialized
DEBUG - 2018-07-30 23:19:51 --> Home MX_Controller Initialized
DEBUG - 2018-07-30 23:19:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-30 23:19:51 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-30 23:19:51 --> Login MX_Controller Initialized
INFO - 2018-07-30 23:19:51 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-30 23:19:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-30 23:19:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-30 23:19:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-07-30 23:19:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-07-30 23:19:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-07-30 23:19:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-07-30 23:19:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-07-30 23:19:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/progress.php
INFO - 2018-07-30 23:19:51 --> Final output sent to browser
DEBUG - 2018-07-30 23:19:51 --> Total execution time: 0.6574
INFO - 2018-07-30 23:19:51 --> Config Class Initialized
INFO - 2018-07-30 23:19:51 --> Hooks Class Initialized
INFO - 2018-07-30 23:19:51 --> Config Class Initialized
INFO - 2018-07-30 23:19:51 --> Hooks Class Initialized
DEBUG - 2018-07-30 23:19:51 --> UTF-8 Support Enabled
INFO - 2018-07-30 23:19:51 --> Utf8 Class Initialized
DEBUG - 2018-07-30 23:19:51 --> UTF-8 Support Enabled
INFO - 2018-07-30 23:19:51 --> Utf8 Class Initialized
INFO - 2018-07-30 23:19:51 --> URI Class Initialized
INFO - 2018-07-30 23:19:51 --> URI Class Initialized
INFO - 2018-07-30 23:19:51 --> Router Class Initialized
INFO - 2018-07-30 23:19:51 --> Router Class Initialized
INFO - 2018-07-30 23:19:51 --> Output Class Initialized
INFO - 2018-07-30 23:19:51 --> Output Class Initialized
INFO - 2018-07-30 23:19:51 --> Security Class Initialized
DEBUG - 2018-07-30 23:19:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 23:19:51 --> Input Class Initialized
INFO - 2018-07-30 23:19:51 --> Security Class Initialized
INFO - 2018-07-30 23:19:51 --> Language Class Initialized
DEBUG - 2018-07-30 23:19:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 23:19:51 --> Input Class Initialized
INFO - 2018-07-30 23:19:51 --> Language Class Initialized
ERROR - 2018-07-30 23:19:51 --> 404 Page Not Found: /index
INFO - 2018-07-30 23:19:51 --> Language Class Initialized
INFO - 2018-07-30 23:19:51 --> Config Class Initialized
INFO - 2018-07-30 23:19:51 --> Hooks Class Initialized
INFO - 2018-07-30 23:19:51 --> Config Class Initialized
DEBUG - 2018-07-30 23:19:51 --> UTF-8 Support Enabled
INFO - 2018-07-30 23:19:51 --> Loader Class Initialized
INFO - 2018-07-30 23:19:52 --> Utf8 Class Initialized
DEBUG - 2018-07-30 23:19:52 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-30 23:19:52 --> URI Class Initialized
INFO - 2018-07-30 23:19:52 --> Helper loaded: url_helper
INFO - 2018-07-30 23:19:52 --> Router Class Initialized
INFO - 2018-07-30 23:19:52 --> Helper loaded: form_helper
INFO - 2018-07-30 23:19:52 --> Helper loaded: date_helper
INFO - 2018-07-30 23:19:52 --> Output Class Initialized
INFO - 2018-07-30 23:19:52 --> Helper loaded: util_helper
INFO - 2018-07-30 23:19:52 --> Security Class Initialized
INFO - 2018-07-30 23:19:52 --> Helper loaded: text_helper
INFO - 2018-07-30 23:19:52 --> Helper loaded: string_helper
DEBUG - 2018-07-30 23:19:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 23:19:52 --> Input Class Initialized
INFO - 2018-07-30 23:19:52 --> Database Driver Class Initialized
INFO - 2018-07-30 23:19:52 --> Language Class Initialized
DEBUG - 2018-07-30 23:19:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 23:19:52 --> Session: Class initialized using 'files' driver.
ERROR - 2018-07-30 23:19:52 --> 404 Page Not Found: /index
INFO - 2018-07-30 23:19:52 --> Email Class Initialized
INFO - 2018-07-30 23:19:52 --> Config Class Initialized
INFO - 2018-07-30 23:19:52 --> Hooks Class Initialized
INFO - 2018-07-30 23:19:52 --> Controller Class Initialized
DEBUG - 2018-07-30 23:19:52 --> Home MX_Controller Initialized
DEBUG - 2018-07-30 23:19:52 --> UTF-8 Support Enabled
INFO - 2018-07-30 23:19:52 --> Utf8 Class Initialized
DEBUG - 2018-07-30 23:19:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-07-30 23:19:52 --> URI Class Initialized
INFO - 2018-07-30 23:19:52 --> Router Class Initialized
DEBUG - 2018-07-30 23:19:52 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
INFO - 2018-07-30 23:19:52 --> Config Class Initialized
INFO - 2018-07-30 23:19:52 --> Hooks Class Initialized
INFO - 2018-07-30 23:19:52 --> Output Class Initialized
DEBUG - 2018-07-30 23:19:52 --> Login MX_Controller Initialized
DEBUG - 2018-07-30 23:19:52 --> UTF-8 Support Enabled
INFO - 2018-07-30 23:19:52 --> Utf8 Class Initialized
INFO - 2018-07-30 23:19:52 --> URI Class Initialized
INFO - 2018-07-30 23:19:52 --> Router Class Initialized
INFO - 2018-07-30 23:19:52 --> Security Class Initialized
INFO - 2018-07-30 23:19:52 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-30 23:19:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 23:19:52 --> Output Class Initialized
DEBUG - 2018-07-30 23:19:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-30 23:19:52 --> Input Class Initialized
INFO - 2018-07-30 23:19:52 --> Language Class Initialized
ERROR - 2018-07-30 23:19:52 --> 404 Page Not Found: /index
INFO - 2018-07-30 23:19:52 --> Security Class Initialized
DEBUG - 2018-07-30 23:19:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 23:19:52 --> Input Class Initialized
DEBUG - 2018-07-30 23:19:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-30 23:19:52 --> Language Class Initialized
INFO - 2018-07-30 23:19:52 --> Language Class Initialized
INFO - 2018-07-30 23:19:52 --> Config Class Initialized
INFO - 2018-07-30 23:19:52 --> Loader Class Initialized
DEBUG - 2018-07-30 23:19:52 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-30 23:19:52 --> Helper loaded: url_helper
INFO - 2018-07-30 23:19:52 --> Helper loaded: form_helper
INFO - 2018-07-30 23:19:52 --> Helper loaded: date_helper
INFO - 2018-07-30 23:19:52 --> Helper loaded: util_helper
INFO - 2018-07-30 23:19:52 --> Helper loaded: text_helper
INFO - 2018-07-30 23:19:52 --> Helper loaded: string_helper
INFO - 2018-07-30 23:19:52 --> Database Driver Class Initialized
DEBUG - 2018-07-30 23:19:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 23:19:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 23:19:52 --> Email Class Initialized
INFO - 2018-07-30 23:19:52 --> Controller Class Initialized
DEBUG - 2018-07-30 23:19:52 --> Profile MX_Controller Initialized
DEBUG - 2018-07-30 23:19:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-30 23:19:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-30 23:19:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-07-30 23:19:53 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-30 23:19:53 --> Login MX_Controller Initialized
INFO - 2018-07-30 23:19:53 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-30 23:19:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-30 23:19:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-07-30 23:19:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-07-30 23:19:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-07-30 23:19:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/profile_left_nav.php
DEBUG - 2018-07-30 23:19:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-07-30 23:19:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-07-30 23:19:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/profile.php
INFO - 2018-07-30 23:19:53 --> Final output sent to browser
DEBUG - 2018-07-30 23:19:53 --> Total execution time: 0.8060
INFO - 2018-07-30 23:19:53 --> Config Class Initialized
INFO - 2018-07-30 23:19:53 --> Hooks Class Initialized
INFO - 2018-07-30 23:19:53 --> Config Class Initialized
INFO - 2018-07-30 23:19:53 --> Hooks Class Initialized
DEBUG - 2018-07-30 23:19:53 --> UTF-8 Support Enabled
INFO - 2018-07-30 23:19:53 --> Utf8 Class Initialized
DEBUG - 2018-07-30 23:19:53 --> UTF-8 Support Enabled
INFO - 2018-07-30 23:19:53 --> URI Class Initialized
INFO - 2018-07-30 23:19:53 --> Utf8 Class Initialized
INFO - 2018-07-30 23:19:53 --> URI Class Initialized
INFO - 2018-07-30 23:19:53 --> Router Class Initialized
INFO - 2018-07-30 23:19:53 --> Output Class Initialized
INFO - 2018-07-30 23:19:53 --> Router Class Initialized
INFO - 2018-07-30 23:19:53 --> Output Class Initialized
INFO - 2018-07-30 23:19:53 --> Security Class Initialized
INFO - 2018-07-30 23:19:53 --> Security Class Initialized
DEBUG - 2018-07-30 23:19:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 23:19:53 --> Input Class Initialized
INFO - 2018-07-30 23:19:53 --> Language Class Initialized
INFO - 2018-07-30 23:19:53 --> Language Class Initialized
DEBUG - 2018-07-30 23:19:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 23:19:53 --> Config Class Initialized
INFO - 2018-07-30 23:19:53 --> Input Class Initialized
INFO - 2018-07-30 23:19:53 --> Loader Class Initialized
INFO - 2018-07-30 23:19:53 --> Language Class Initialized
DEBUG - 2018-07-30 23:19:53 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-30 23:19:53 --> Helper loaded: url_helper
ERROR - 2018-07-30 23:19:53 --> 404 Page Not Found: /index
INFO - 2018-07-30 23:19:53 --> Helper loaded: form_helper
INFO - 2018-07-30 23:19:53 --> Helper loaded: date_helper
INFO - 2018-07-30 23:19:53 --> Helper loaded: util_helper
INFO - 2018-07-30 23:19:53 --> Helper loaded: text_helper
INFO - 2018-07-30 23:19:53 --> Helper loaded: string_helper
INFO - 2018-07-30 23:19:53 --> Database Driver Class Initialized
DEBUG - 2018-07-30 23:19:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 23:19:53 --> Config Class Initialized
INFO - 2018-07-30 23:19:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 23:19:53 --> Hooks Class Initialized
INFO - 2018-07-30 23:19:53 --> Email Class Initialized
INFO - 2018-07-30 23:19:53 --> Controller Class Initialized
DEBUG - 2018-07-30 23:19:53 --> UTF-8 Support Enabled
DEBUG - 2018-07-30 23:19:54 --> Home MX_Controller Initialized
INFO - 2018-07-30 23:19:54 --> Utf8 Class Initialized
DEBUG - 2018-07-30 23:19:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-07-30 23:19:54 --> URI Class Initialized
INFO - 2018-07-30 23:19:54 --> Router Class Initialized
DEBUG - 2018-07-30 23:19:54 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-30 23:19:54 --> Login MX_Controller Initialized
INFO - 2018-07-30 23:19:54 --> Output Class Initialized
INFO - 2018-07-30 23:19:54 --> Language file loaded: language/english/data_lang.php
INFO - 2018-07-30 23:19:54 --> Security Class Initialized
DEBUG - 2018-07-30 23:19:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-30 23:19:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-07-30 23:19:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-30 23:19:54 --> Input Class Initialized
INFO - 2018-07-30 23:19:54 --> Language Class Initialized
ERROR - 2018-07-30 23:19:54 --> 404 Page Not Found: /index
INFO - 2018-07-30 23:19:54 --> Config Class Initialized
INFO - 2018-07-30 23:19:54 --> Hooks Class Initialized
DEBUG - 2018-07-30 23:19:54 --> UTF-8 Support Enabled
INFO - 2018-07-30 23:19:54 --> Utf8 Class Initialized
INFO - 2018-07-30 23:19:54 --> URI Class Initialized
INFO - 2018-07-30 23:19:54 --> Router Class Initialized
INFO - 2018-07-30 23:19:54 --> Output Class Initialized
INFO - 2018-07-30 23:19:54 --> Security Class Initialized
DEBUG - 2018-07-30 23:19:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 23:19:54 --> Input Class Initialized
INFO - 2018-07-30 23:19:54 --> Language Class Initialized
ERROR - 2018-07-30 23:19:54 --> 404 Page Not Found: /index
INFO - 2018-07-30 23:19:55 --> Config Class Initialized
INFO - 2018-07-30 23:19:55 --> Hooks Class Initialized
DEBUG - 2018-07-30 23:19:55 --> UTF-8 Support Enabled
INFO - 2018-07-30 23:19:55 --> Utf8 Class Initialized
INFO - 2018-07-30 23:19:55 --> URI Class Initialized
INFO - 2018-07-30 23:19:55 --> Router Class Initialized
INFO - 2018-07-30 23:19:55 --> Output Class Initialized
INFO - 2018-07-30 23:19:55 --> Security Class Initialized
DEBUG - 2018-07-30 23:19:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 23:19:56 --> Input Class Initialized
INFO - 2018-07-30 23:19:56 --> Language Class Initialized
INFO - 2018-07-30 23:19:56 --> Language Class Initialized
INFO - 2018-07-30 23:19:56 --> Config Class Initialized
INFO - 2018-07-30 23:19:56 --> Loader Class Initialized
DEBUG - 2018-07-30 23:19:56 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-30 23:19:56 --> Helper loaded: url_helper
INFO - 2018-07-30 23:19:56 --> Helper loaded: form_helper
INFO - 2018-07-30 23:19:56 --> Helper loaded: date_helper
INFO - 2018-07-30 23:19:56 --> Helper loaded: util_helper
INFO - 2018-07-30 23:19:56 --> Helper loaded: text_helper
INFO - 2018-07-30 23:19:56 --> Helper loaded: string_helper
INFO - 2018-07-30 23:19:56 --> Database Driver Class Initialized
DEBUG - 2018-07-30 23:19:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 23:19:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 23:19:56 --> Email Class Initialized
INFO - 2018-07-30 23:19:56 --> Controller Class Initialized
DEBUG - 2018-07-30 23:19:56 --> Profile MX_Controller Initialized
DEBUG - 2018-07-30 23:19:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-30 23:19:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-30 23:19:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-07-30 23:19:56 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-30 23:19:56 --> Login MX_Controller Initialized
INFO - 2018-07-30 23:19:56 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-30 23:19:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-30 23:19:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-07-30 23:19:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-07-30 23:19:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-07-30 23:19:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/profile_left_nav.php
DEBUG - 2018-07-30 23:19:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-07-30 23:19:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-07-30 23:19:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/reset_password.php
INFO - 2018-07-30 23:19:56 --> Final output sent to browser
DEBUG - 2018-07-30 23:19:56 --> Total execution time: 0.6301
INFO - 2018-07-30 23:19:56 --> Config Class Initialized
INFO - 2018-07-30 23:19:56 --> Hooks Class Initialized
INFO - 2018-07-30 23:19:56 --> Config Class Initialized
INFO - 2018-07-30 23:19:56 --> Hooks Class Initialized
DEBUG - 2018-07-30 23:19:56 --> UTF-8 Support Enabled
DEBUG - 2018-07-30 23:19:56 --> UTF-8 Support Enabled
INFO - 2018-07-30 23:19:56 --> Utf8 Class Initialized
INFO - 2018-07-30 23:19:56 --> Utf8 Class Initialized
INFO - 2018-07-30 23:19:56 --> URI Class Initialized
INFO - 2018-07-30 23:19:56 --> URI Class Initialized
INFO - 2018-07-30 23:19:56 --> Router Class Initialized
INFO - 2018-07-30 23:19:56 --> Output Class Initialized
INFO - 2018-07-30 23:19:56 --> Router Class Initialized
INFO - 2018-07-30 23:19:56 --> Output Class Initialized
INFO - 2018-07-30 23:19:56 --> Security Class Initialized
DEBUG - 2018-07-30 23:19:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 23:19:56 --> Security Class Initialized
INFO - 2018-07-30 23:19:56 --> Input Class Initialized
DEBUG - 2018-07-30 23:19:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 23:19:56 --> Language Class Initialized
INFO - 2018-07-30 23:19:56 --> Input Class Initialized
INFO - 2018-07-30 23:19:57 --> Language Class Initialized
INFO - 2018-07-30 23:19:57 --> Language Class Initialized
ERROR - 2018-07-30 23:19:57 --> 404 Page Not Found: /index
INFO - 2018-07-30 23:19:57 --> Config Class Initialized
INFO - 2018-07-30 23:19:57 --> Config Class Initialized
INFO - 2018-07-30 23:19:57 --> Hooks Class Initialized
INFO - 2018-07-30 23:19:57 --> Loader Class Initialized
DEBUG - 2018-07-30 23:19:57 --> UTF-8 Support Enabled
DEBUG - 2018-07-30 23:19:57 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-30 23:19:57 --> Utf8 Class Initialized
INFO - 2018-07-30 23:19:57 --> URI Class Initialized
INFO - 2018-07-30 23:19:57 --> Router Class Initialized
INFO - 2018-07-30 23:19:57 --> Helper loaded: url_helper
INFO - 2018-07-30 23:19:57 --> Output Class Initialized
INFO - 2018-07-30 23:19:57 --> Security Class Initialized
DEBUG - 2018-07-30 23:19:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 23:19:57 --> Input Class Initialized
INFO - 2018-07-30 23:19:57 --> Language Class Initialized
ERROR - 2018-07-30 23:19:57 --> 404 Page Not Found: /index
INFO - 2018-07-30 23:19:57 --> Config Class Initialized
INFO - 2018-07-30 23:19:57 --> Hooks Class Initialized
DEBUG - 2018-07-30 23:19:57 --> UTF-8 Support Enabled
INFO - 2018-07-30 23:19:57 --> Utf8 Class Initialized
INFO - 2018-07-30 23:19:57 --> Helper loaded: form_helper
INFO - 2018-07-30 23:19:57 --> URI Class Initialized
INFO - 2018-07-30 23:19:57 --> Router Class Initialized
INFO - 2018-07-30 23:19:57 --> Helper loaded: date_helper
INFO - 2018-07-30 23:19:57 --> Output Class Initialized
INFO - 2018-07-30 23:19:57 --> Security Class Initialized
DEBUG - 2018-07-30 23:19:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 23:19:57 --> Input Class Initialized
INFO - 2018-07-30 23:19:57 --> Language Class Initialized
ERROR - 2018-07-30 23:19:57 --> 404 Page Not Found: /index
INFO - 2018-07-30 23:19:57 --> Helper loaded: util_helper
INFO - 2018-07-30 23:19:57 --> Helper loaded: text_helper
INFO - 2018-07-30 23:19:57 --> Helper loaded: string_helper
INFO - 2018-07-30 23:19:57 --> Database Driver Class Initialized
DEBUG - 2018-07-30 23:19:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 23:19:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 23:19:57 --> Email Class Initialized
INFO - 2018-07-30 23:19:57 --> Controller Class Initialized
DEBUG - 2018-07-30 23:19:57 --> Home MX_Controller Initialized
DEBUG - 2018-07-30 23:19:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-30 23:19:57 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-30 23:19:57 --> Login MX_Controller Initialized
INFO - 2018-07-30 23:19:57 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-30 23:19:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-30 23:19:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-30 23:19:58 --> Config Class Initialized
INFO - 2018-07-30 23:19:58 --> Hooks Class Initialized
DEBUG - 2018-07-30 23:19:58 --> UTF-8 Support Enabled
INFO - 2018-07-30 23:19:58 --> Utf8 Class Initialized
INFO - 2018-07-30 23:19:58 --> URI Class Initialized
INFO - 2018-07-30 23:19:58 --> Router Class Initialized
INFO - 2018-07-30 23:19:58 --> Output Class Initialized
INFO - 2018-07-30 23:19:58 --> Security Class Initialized
DEBUG - 2018-07-30 23:19:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 23:19:58 --> Input Class Initialized
INFO - 2018-07-30 23:19:58 --> Language Class Initialized
INFO - 2018-07-30 23:19:58 --> Language Class Initialized
INFO - 2018-07-30 23:19:58 --> Config Class Initialized
INFO - 2018-07-30 23:19:58 --> Loader Class Initialized
DEBUG - 2018-07-30 23:19:58 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-30 23:19:58 --> Helper loaded: url_helper
INFO - 2018-07-30 23:19:58 --> Helper loaded: form_helper
INFO - 2018-07-30 23:19:58 --> Helper loaded: date_helper
INFO - 2018-07-30 23:19:58 --> Helper loaded: util_helper
INFO - 2018-07-30 23:19:59 --> Helper loaded: text_helper
INFO - 2018-07-30 23:19:59 --> Helper loaded: string_helper
INFO - 2018-07-30 23:19:59 --> Database Driver Class Initialized
DEBUG - 2018-07-30 23:19:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 23:19:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 23:19:59 --> Email Class Initialized
INFO - 2018-07-30 23:19:59 --> Controller Class Initialized
DEBUG - 2018-07-30 23:19:59 --> Profile MX_Controller Initialized
DEBUG - 2018-07-30 23:19:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-30 23:19:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-30 23:19:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-07-30 23:19:59 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-30 23:19:59 --> Login MX_Controller Initialized
INFO - 2018-07-30 23:19:59 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-30 23:19:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-30 23:19:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-07-30 23:19:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-07-30 23:19:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-07-30 23:19:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/profile_left_nav.php
DEBUG - 2018-07-30 23:19:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-07-30 23:19:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-07-30 23:19:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/addresses.php
INFO - 2018-07-30 23:19:59 --> Final output sent to browser
DEBUG - 2018-07-30 23:19:59 --> Total execution time: 0.6577
INFO - 2018-07-30 23:19:59 --> Config Class Initialized
INFO - 2018-07-30 23:19:59 --> Hooks Class Initialized
DEBUG - 2018-07-30 23:19:59 --> UTF-8 Support Enabled
INFO - 2018-07-30 23:19:59 --> Config Class Initialized
INFO - 2018-07-30 23:19:59 --> Hooks Class Initialized
INFO - 2018-07-30 23:19:59 --> Utf8 Class Initialized
DEBUG - 2018-07-30 23:19:59 --> UTF-8 Support Enabled
INFO - 2018-07-30 23:19:59 --> Utf8 Class Initialized
INFO - 2018-07-30 23:19:59 --> URI Class Initialized
INFO - 2018-07-30 23:19:59 --> Router Class Initialized
INFO - 2018-07-30 23:19:59 --> Output Class Initialized
INFO - 2018-07-30 23:19:59 --> URI Class Initialized
INFO - 2018-07-30 23:19:59 --> Security Class Initialized
DEBUG - 2018-07-30 23:19:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 23:19:59 --> Router Class Initialized
INFO - 2018-07-30 23:19:59 --> Input Class Initialized
INFO - 2018-07-30 23:19:59 --> Output Class Initialized
INFO - 2018-07-30 23:19:59 --> Language Class Initialized
INFO - 2018-07-30 23:19:59 --> Security Class Initialized
DEBUG - 2018-07-30 23:19:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 23:19:59 --> Language Class Initialized
INFO - 2018-07-30 23:19:59 --> Input Class Initialized
INFO - 2018-07-30 23:19:59 --> Config Class Initialized
INFO - 2018-07-30 23:19:59 --> Language Class Initialized
ERROR - 2018-07-30 23:19:59 --> 404 Page Not Found: /index
INFO - 2018-07-30 23:19:59 --> Loader Class Initialized
INFO - 2018-07-30 23:19:59 --> Config Class Initialized
INFO - 2018-07-30 23:20:00 --> Hooks Class Initialized
DEBUG - 2018-07-30 23:20:00 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
DEBUG - 2018-07-30 23:20:00 --> UTF-8 Support Enabled
INFO - 2018-07-30 23:20:00 --> Utf8 Class Initialized
INFO - 2018-07-30 23:20:00 --> URI Class Initialized
INFO - 2018-07-30 23:20:00 --> Helper loaded: url_helper
INFO - 2018-07-30 23:20:00 --> Helper loaded: form_helper
INFO - 2018-07-30 23:20:00 --> Router Class Initialized
INFO - 2018-07-30 23:20:00 --> Helper loaded: date_helper
INFO - 2018-07-30 23:20:00 --> Output Class Initialized
INFO - 2018-07-30 23:20:00 --> Security Class Initialized
INFO - 2018-07-30 23:20:00 --> Helper loaded: util_helper
INFO - 2018-07-30 23:20:00 --> Helper loaded: text_helper
DEBUG - 2018-07-30 23:20:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 23:20:00 --> Input Class Initialized
INFO - 2018-07-30 23:20:00 --> Helper loaded: string_helper
INFO - 2018-07-30 23:20:00 --> Language Class Initialized
INFO - 2018-07-30 23:20:00 --> Database Driver Class Initialized
ERROR - 2018-07-30 23:20:00 --> 404 Page Not Found: /index
DEBUG - 2018-07-30 23:20:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 23:20:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 23:20:00 --> Config Class Initialized
INFO - 2018-07-30 23:20:00 --> Hooks Class Initialized
INFO - 2018-07-30 23:20:00 --> Email Class Initialized
INFO - 2018-07-30 23:20:00 --> Controller Class Initialized
DEBUG - 2018-07-30 23:20:00 --> UTF-8 Support Enabled
INFO - 2018-07-30 23:20:00 --> Utf8 Class Initialized
DEBUG - 2018-07-30 23:20:00 --> Home MX_Controller Initialized
INFO - 2018-07-30 23:20:00 --> URI Class Initialized
DEBUG - 2018-07-30 23:20:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-07-30 23:20:00 --> Router Class Initialized
DEBUG - 2018-07-30 23:20:00 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-30 23:20:00 --> Login MX_Controller Initialized
INFO - 2018-07-30 23:20:00 --> Output Class Initialized
INFO - 2018-07-30 23:20:00 --> Language file loaded: language/english/data_lang.php
INFO - 2018-07-30 23:20:00 --> Security Class Initialized
DEBUG - 2018-07-30 23:20:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-30 23:20:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-30 23:20:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 23:20:00 --> Input Class Initialized
INFO - 2018-07-30 23:20:00 --> Language Class Initialized
ERROR - 2018-07-30 23:20:00 --> 404 Page Not Found: /index
INFO - 2018-07-30 23:20:01 --> Config Class Initialized
INFO - 2018-07-30 23:20:01 --> Hooks Class Initialized
DEBUG - 2018-07-30 23:20:01 --> UTF-8 Support Enabled
INFO - 2018-07-30 23:20:01 --> Utf8 Class Initialized
INFO - 2018-07-30 23:20:01 --> URI Class Initialized
INFO - 2018-07-30 23:20:01 --> Router Class Initialized
INFO - 2018-07-30 23:20:01 --> Output Class Initialized
INFO - 2018-07-30 23:20:01 --> Security Class Initialized
DEBUG - 2018-07-30 23:20:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 23:20:01 --> Input Class Initialized
INFO - 2018-07-30 23:20:01 --> Language Class Initialized
INFO - 2018-07-30 23:20:01 --> Language Class Initialized
INFO - 2018-07-30 23:20:01 --> Config Class Initialized
INFO - 2018-07-30 23:20:01 --> Loader Class Initialized
DEBUG - 2018-07-30 23:20:01 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-30 23:20:01 --> Helper loaded: url_helper
INFO - 2018-07-30 23:20:01 --> Helper loaded: form_helper
INFO - 2018-07-30 23:20:01 --> Helper loaded: date_helper
INFO - 2018-07-30 23:20:01 --> Helper loaded: util_helper
INFO - 2018-07-30 23:20:01 --> Helper loaded: text_helper
INFO - 2018-07-30 23:20:01 --> Helper loaded: string_helper
INFO - 2018-07-30 23:20:01 --> Database Driver Class Initialized
DEBUG - 2018-07-30 23:20:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 23:20:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 23:20:01 --> Email Class Initialized
INFO - 2018-07-30 23:20:02 --> Controller Class Initialized
DEBUG - 2018-07-30 23:20:02 --> Home MX_Controller Initialized
DEBUG - 2018-07-30 23:20:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-30 23:20:02 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-30 23:20:02 --> Login MX_Controller Initialized
INFO - 2018-07-30 23:20:02 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-30 23:20:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-30 23:20:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-30 23:20:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-07-30 23:20:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-07-30 23:20:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-07-30 23:20:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-07-30 23:20:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-07-30 23:20:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-07-30 23:20:02 --> Final output sent to browser
DEBUG - 2018-07-30 23:20:02 --> Total execution time: 0.6005
INFO - 2018-07-30 23:20:02 --> Config Class Initialized
INFO - 2018-07-30 23:20:02 --> Hooks Class Initialized
DEBUG - 2018-07-30 23:20:02 --> UTF-8 Support Enabled
INFO - 2018-07-30 23:20:02 --> Config Class Initialized
INFO - 2018-07-30 23:20:02 --> Hooks Class Initialized
INFO - 2018-07-30 23:20:02 --> Utf8 Class Initialized
INFO - 2018-07-30 23:20:02 --> URI Class Initialized
DEBUG - 2018-07-30 23:20:02 --> UTF-8 Support Enabled
INFO - 2018-07-30 23:20:02 --> Utf8 Class Initialized
INFO - 2018-07-30 23:20:02 --> Router Class Initialized
INFO - 2018-07-30 23:20:02 --> URI Class Initialized
INFO - 2018-07-30 23:20:02 --> Router Class Initialized
INFO - 2018-07-30 23:20:02 --> Output Class Initialized
INFO - 2018-07-30 23:20:02 --> Security Class Initialized
DEBUG - 2018-07-30 23:20:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 23:20:02 --> Input Class Initialized
INFO - 2018-07-30 23:20:02 --> Language Class Initialized
INFO - 2018-07-30 23:20:02 --> Language Class Initialized
INFO - 2018-07-30 23:20:02 --> Output Class Initialized
INFO - 2018-07-30 23:20:02 --> Security Class Initialized
INFO - 2018-07-30 23:20:02 --> Config Class Initialized
DEBUG - 2018-07-30 23:20:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 23:20:03 --> Input Class Initialized
INFO - 2018-07-30 23:20:03 --> Loader Class Initialized
INFO - 2018-07-30 23:20:03 --> Language Class Initialized
DEBUG - 2018-07-30 23:20:03 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-30 23:20:03 --> Helper loaded: url_helper
ERROR - 2018-07-30 23:20:03 --> 404 Page Not Found: /index
INFO - 2018-07-30 23:20:03 --> Config Class Initialized
INFO - 2018-07-30 23:20:03 --> Helper loaded: form_helper
INFO - 2018-07-30 23:20:03 --> Helper loaded: date_helper
INFO - 2018-07-30 23:20:03 --> Hooks Class Initialized
DEBUG - 2018-07-30 23:20:03 --> UTF-8 Support Enabled
INFO - 2018-07-30 23:20:03 --> Helper loaded: util_helper
INFO - 2018-07-30 23:20:03 --> Utf8 Class Initialized
INFO - 2018-07-30 23:20:03 --> Helper loaded: text_helper
INFO - 2018-07-30 23:20:03 --> Helper loaded: string_helper
INFO - 2018-07-30 23:20:03 --> URI Class Initialized
INFO - 2018-07-30 23:20:03 --> Router Class Initialized
INFO - 2018-07-30 23:20:03 --> Database Driver Class Initialized
INFO - 2018-07-30 23:20:03 --> Output Class Initialized
INFO - 2018-07-30 23:20:03 --> Security Class Initialized
DEBUG - 2018-07-30 23:20:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 23:20:03 --> Input Class Initialized
INFO - 2018-07-30 23:20:03 --> Language Class Initialized
ERROR - 2018-07-30 23:20:03 --> 404 Page Not Found: /index
INFO - 2018-07-30 23:20:03 --> Config Class Initialized
INFO - 2018-07-30 23:20:03 --> Hooks Class Initialized
DEBUG - 2018-07-30 23:20:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 23:20:03 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-07-30 23:20:03 --> UTF-8 Support Enabled
INFO - 2018-07-30 23:20:03 --> Config Class Initialized
INFO - 2018-07-30 23:20:03 --> Hooks Class Initialized
INFO - 2018-07-30 23:20:03 --> Email Class Initialized
INFO - 2018-07-30 23:20:03 --> Utf8 Class Initialized
INFO - 2018-07-30 23:20:03 --> Controller Class Initialized
DEBUG - 2018-07-30 23:20:03 --> UTF-8 Support Enabled
INFO - 2018-07-30 23:20:03 --> URI Class Initialized
INFO - 2018-07-30 23:20:03 --> Utf8 Class Initialized
DEBUG - 2018-07-30 23:20:03 --> Home MX_Controller Initialized
INFO - 2018-07-30 23:20:03 --> Router Class Initialized
INFO - 2018-07-30 23:20:03 --> URI Class Initialized
DEBUG - 2018-07-30 23:20:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-30 23:20:03 --> No URI present. Default controller set.
INFO - 2018-07-30 23:20:03 --> Output Class Initialized
INFO - 2018-07-30 23:20:03 --> Router Class Initialized
INFO - 2018-07-30 23:20:03 --> Security Class Initialized
DEBUG - 2018-07-30 23:20:03 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-30 23:20:03 --> Login MX_Controller Initialized
INFO - 2018-07-30 23:20:03 --> Output Class Initialized
DEBUG - 2018-07-30 23:20:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 23:20:03 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-30 23:20:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-30 23:20:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-30 23:20:03 --> Input Class Initialized
INFO - 2018-07-30 23:20:03 --> Security Class Initialized
INFO - 2018-07-30 23:20:03 --> Language Class Initialized
ERROR - 2018-07-30 23:20:04 --> 404 Page Not Found: /index
DEBUG - 2018-07-30 23:20:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 23:20:04 --> Input Class Initialized
INFO - 2018-07-30 23:20:04 --> Language Class Initialized
INFO - 2018-07-30 23:20:04 --> Language Class Initialized
INFO - 2018-07-30 23:20:04 --> Config Class Initialized
INFO - 2018-07-30 23:20:04 --> Loader Class Initialized
DEBUG - 2018-07-30 23:20:04 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-30 23:20:04 --> Helper loaded: url_helper
INFO - 2018-07-30 23:20:04 --> Helper loaded: form_helper
INFO - 2018-07-30 23:20:04 --> Helper loaded: date_helper
INFO - 2018-07-30 23:20:04 --> Helper loaded: util_helper
INFO - 2018-07-30 23:20:04 --> Helper loaded: text_helper
INFO - 2018-07-30 23:20:04 --> Helper loaded: string_helper
INFO - 2018-07-30 23:20:04 --> Database Driver Class Initialized
DEBUG - 2018-07-30 23:20:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 23:20:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 23:20:04 --> Email Class Initialized
INFO - 2018-07-30 23:20:04 --> Controller Class Initialized
DEBUG - 2018-07-30 23:20:04 --> Home MX_Controller Initialized
DEBUG - 2018-07-30 23:20:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-30 23:20:04 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-30 23:20:04 --> Login MX_Controller Initialized
INFO - 2018-07-30 23:20:04 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-30 23:20:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-30 23:20:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-30 23:20:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-07-30 23:20:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-07-30 23:20:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-07-30 23:20:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-07-30 23:20:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-07-30 23:20:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-07-30 23:20:04 --> Final output sent to browser
DEBUG - 2018-07-30 23:20:04 --> Total execution time: 0.8639
INFO - 2018-07-30 23:20:04 --> Config Class Initialized
INFO - 2018-07-30 23:20:04 --> Hooks Class Initialized
DEBUG - 2018-07-30 23:20:04 --> UTF-8 Support Enabled
INFO - 2018-07-30 23:20:04 --> Config Class Initialized
INFO - 2018-07-30 23:20:04 --> Hooks Class Initialized
INFO - 2018-07-30 23:20:04 --> Utf8 Class Initialized
DEBUG - 2018-07-30 23:20:04 --> UTF-8 Support Enabled
INFO - 2018-07-30 23:20:04 --> Utf8 Class Initialized
INFO - 2018-07-30 23:20:04 --> URI Class Initialized
INFO - 2018-07-30 23:20:04 --> URI Class Initialized
INFO - 2018-07-30 23:20:04 --> Router Class Initialized
INFO - 2018-07-30 23:20:04 --> Router Class Initialized
INFO - 2018-07-30 23:20:05 --> Output Class Initialized
INFO - 2018-07-30 23:20:05 --> Security Class Initialized
DEBUG - 2018-07-30 23:20:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 23:20:05 --> Output Class Initialized
INFO - 2018-07-30 23:20:05 --> Input Class Initialized
INFO - 2018-07-30 23:20:05 --> Language Class Initialized
INFO - 2018-07-30 23:20:05 --> Security Class Initialized
INFO - 2018-07-30 23:20:05 --> Language Class Initialized
DEBUG - 2018-07-30 23:20:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 23:20:05 --> Config Class Initialized
INFO - 2018-07-30 23:20:05 --> Loader Class Initialized
INFO - 2018-07-30 23:20:05 --> Input Class Initialized
DEBUG - 2018-07-30 23:20:05 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-30 23:20:05 --> Helper loaded: url_helper
INFO - 2018-07-30 23:20:05 --> Language Class Initialized
ERROR - 2018-07-30 23:20:05 --> 404 Page Not Found: /index
INFO - 2018-07-30 23:20:05 --> Helper loaded: form_helper
INFO - 2018-07-30 23:20:05 --> Config Class Initialized
INFO - 2018-07-30 23:20:05 --> Hooks Class Initialized
DEBUG - 2018-07-30 23:20:05 --> UTF-8 Support Enabled
INFO - 2018-07-30 23:20:05 --> Utf8 Class Initialized
INFO - 2018-07-30 23:20:05 --> URI Class Initialized
INFO - 2018-07-30 23:20:05 --> Router Class Initialized
INFO - 2018-07-30 23:20:05 --> Helper loaded: date_helper
INFO - 2018-07-30 23:20:05 --> Output Class Initialized
INFO - 2018-07-30 23:20:05 --> Helper loaded: util_helper
INFO - 2018-07-30 23:20:05 --> Security Class Initialized
INFO - 2018-07-30 23:20:05 --> Helper loaded: text_helper
DEBUG - 2018-07-30 23:20:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 23:20:05 --> Helper loaded: string_helper
INFO - 2018-07-30 23:20:05 --> Input Class Initialized
INFO - 2018-07-30 23:20:05 --> Database Driver Class Initialized
INFO - 2018-07-30 23:20:05 --> Language Class Initialized
DEBUG - 2018-07-30 23:20:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 23:20:05 --> Session: Class initialized using 'files' driver.
ERROR - 2018-07-30 23:20:05 --> 404 Page Not Found: /index
INFO - 2018-07-30 23:20:05 --> Email Class Initialized
INFO - 2018-07-30 23:20:05 --> Config Class Initialized
INFO - 2018-07-30 23:20:05 --> Hooks Class Initialized
INFO - 2018-07-30 23:20:05 --> Controller Class Initialized
DEBUG - 2018-07-30 23:20:05 --> UTF-8 Support Enabled
DEBUG - 2018-07-30 23:20:05 --> Home MX_Controller Initialized
INFO - 2018-07-30 23:20:05 --> Utf8 Class Initialized
DEBUG - 2018-07-30 23:20:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-07-30 23:20:05 --> URI Class Initialized
DEBUG - 2018-07-30 23:20:05 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-30 23:20:05 --> Login MX_Controller Initialized
INFO - 2018-07-30 23:20:05 --> Router Class Initialized
INFO - 2018-07-30 23:20:05 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-30 23:20:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-30 23:20:05 --> Output Class Initialized
DEBUG - 2018-07-30 23:20:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-30 23:20:05 --> Security Class Initialized
DEBUG - 2018-07-30 23:20:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 23:20:05 --> Input Class Initialized
INFO - 2018-07-30 23:20:06 --> Language Class Initialized
ERROR - 2018-07-30 23:20:06 --> 404 Page Not Found: /index
INFO - 2018-07-30 23:40:53 --> Config Class Initialized
INFO - 2018-07-30 23:40:53 --> Hooks Class Initialized
DEBUG - 2018-07-30 23:40:53 --> UTF-8 Support Enabled
INFO - 2018-07-30 23:40:53 --> Utf8 Class Initialized
INFO - 2018-07-30 23:40:53 --> URI Class Initialized
INFO - 2018-07-30 23:40:53 --> Router Class Initialized
INFO - 2018-07-30 23:40:53 --> Output Class Initialized
INFO - 2018-07-30 23:40:53 --> Security Class Initialized
DEBUG - 2018-07-30 23:40:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 23:40:53 --> Input Class Initialized
INFO - 2018-07-30 23:40:53 --> Language Class Initialized
INFO - 2018-07-30 23:40:53 --> Language Class Initialized
INFO - 2018-07-30 23:40:53 --> Config Class Initialized
INFO - 2018-07-30 23:40:53 --> Loader Class Initialized
DEBUG - 2018-07-30 23:40:53 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-30 23:40:53 --> Helper loaded: url_helper
INFO - 2018-07-30 23:40:53 --> Helper loaded: form_helper
INFO - 2018-07-30 23:40:53 --> Helper loaded: date_helper
INFO - 2018-07-30 23:40:53 --> Helper loaded: util_helper
INFO - 2018-07-30 23:40:53 --> Helper loaded: text_helper
INFO - 2018-07-30 23:40:53 --> Helper loaded: string_helper
INFO - 2018-07-30 23:40:53 --> Database Driver Class Initialized
DEBUG - 2018-07-30 23:40:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 23:40:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 23:40:53 --> Email Class Initialized
INFO - 2018-07-30 23:40:53 --> Controller Class Initialized
DEBUG - 2018-07-30 23:40:53 --> Programs MX_Controller Initialized
INFO - 2018-07-30 23:40:53 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-30 23:40:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-07-30 23:40:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-30 23:40:53 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-30 23:40:53 --> Login MX_Controller Initialized
DEBUG - 2018-07-30 23:40:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-30 23:40:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-30 23:40:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-30 23:40:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-30 23:40:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-30 23:40:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-30 23:40:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/programs/programs.php
INFO - 2018-07-30 23:40:54 --> Final output sent to browser
DEBUG - 2018-07-30 23:40:54 --> Total execution time: 0.6366
INFO - 2018-07-30 23:40:54 --> Config Class Initialized
INFO - 2018-07-30 23:40:54 --> Hooks Class Initialized
DEBUG - 2018-07-30 23:40:54 --> UTF-8 Support Enabled
INFO - 2018-07-30 23:40:54 --> Utf8 Class Initialized
INFO - 2018-07-30 23:40:54 --> URI Class Initialized
INFO - 2018-07-30 23:40:54 --> Router Class Initialized
INFO - 2018-07-30 23:40:54 --> Output Class Initialized
INFO - 2018-07-30 23:40:54 --> Security Class Initialized
DEBUG - 2018-07-30 23:40:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-30 23:40:55 --> Input Class Initialized
INFO - 2018-07-30 23:40:55 --> Language Class Initialized
INFO - 2018-07-30 23:40:55 --> Language Class Initialized
INFO - 2018-07-30 23:40:55 --> Config Class Initialized
INFO - 2018-07-30 23:40:55 --> Loader Class Initialized
DEBUG - 2018-07-30 23:40:55 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-30 23:40:55 --> Helper loaded: url_helper
INFO - 2018-07-30 23:40:55 --> Helper loaded: form_helper
INFO - 2018-07-30 23:40:55 --> Helper loaded: date_helper
INFO - 2018-07-30 23:40:55 --> Helper loaded: util_helper
INFO - 2018-07-30 23:40:55 --> Helper loaded: text_helper
INFO - 2018-07-30 23:40:55 --> Helper loaded: string_helper
INFO - 2018-07-30 23:40:55 --> Database Driver Class Initialized
DEBUG - 2018-07-30 23:40:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-30 23:40:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-30 23:40:55 --> Email Class Initialized
INFO - 2018-07-30 23:40:55 --> Controller Class Initialized
DEBUG - 2018-07-30 23:40:55 --> Programs MX_Controller Initialized
INFO - 2018-07-30 23:40:55 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-30 23:40:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-07-30 23:40:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-30 23:40:55 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-30 23:40:55 --> Login MX_Controller Initialized
DEBUG - 2018-07-30 23:40:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-30 23:40:55 --> Final output sent to browser
DEBUG - 2018-07-30 23:40:55 --> Total execution time: 0.7067
