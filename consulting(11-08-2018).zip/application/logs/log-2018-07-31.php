<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-07-31 00:21:00 --> Config Class Initialized
INFO - 2018-07-31 00:21:00 --> Hooks Class Initialized
DEBUG - 2018-07-31 00:21:00 --> UTF-8 Support Enabled
INFO - 2018-07-31 00:21:00 --> Utf8 Class Initialized
INFO - 2018-07-31 00:21:00 --> URI Class Initialized
INFO - 2018-07-31 00:21:00 --> Router Class Initialized
INFO - 2018-07-31 00:21:00 --> Output Class Initialized
INFO - 2018-07-31 00:21:00 --> Security Class Initialized
DEBUG - 2018-07-31 00:21:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 00:21:00 --> Input Class Initialized
INFO - 2018-07-31 00:21:00 --> Language Class Initialized
INFO - 2018-07-31 00:21:00 --> Language Class Initialized
INFO - 2018-07-31 00:21:00 --> Config Class Initialized
INFO - 2018-07-31 00:21:00 --> Loader Class Initialized
DEBUG - 2018-07-31 00:21:00 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-31 00:21:00 --> Helper loaded: url_helper
INFO - 2018-07-31 00:21:00 --> Helper loaded: form_helper
INFO - 2018-07-31 00:21:00 --> Helper loaded: date_helper
INFO - 2018-07-31 00:21:00 --> Helper loaded: util_helper
INFO - 2018-07-31 00:21:00 --> Helper loaded: text_helper
INFO - 2018-07-31 00:21:00 --> Helper loaded: string_helper
INFO - 2018-07-31 00:21:00 --> Database Driver Class Initialized
DEBUG - 2018-07-31 00:21:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 00:21:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 00:21:00 --> Email Class Initialized
INFO - 2018-07-31 00:21:00 --> Controller Class Initialized
DEBUG - 2018-07-31 00:21:00 --> Programs MX_Controller Initialized
INFO - 2018-07-31 00:21:00 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-31 00:21:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-07-31 00:21:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-31 00:21:00 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-31 00:21:00 --> Login MX_Controller Initialized
DEBUG - 2018-07-31 00:21:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-31 00:21:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-31 00:21:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-31 00:21:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-31 00:21:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-31 00:21:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-31 00:21:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/programs/create_program.php
INFO - 2018-07-31 00:21:00 --> Final output sent to browser
DEBUG - 2018-07-31 00:21:00 --> Total execution time: 0.3719
INFO - 2018-07-31 00:27:48 --> Config Class Initialized
INFO - 2018-07-31 00:27:49 --> Hooks Class Initialized
DEBUG - 2018-07-31 00:27:49 --> UTF-8 Support Enabled
INFO - 2018-07-31 00:27:49 --> Utf8 Class Initialized
INFO - 2018-07-31 00:27:49 --> URI Class Initialized
INFO - 2018-07-31 00:27:49 --> Router Class Initialized
INFO - 2018-07-31 00:27:49 --> Output Class Initialized
INFO - 2018-07-31 00:27:49 --> Security Class Initialized
DEBUG - 2018-07-31 00:27:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 00:27:49 --> Input Class Initialized
INFO - 2018-07-31 00:27:49 --> Language Class Initialized
ERROR - 2018-07-31 00:27:49 --> 404 Page Not Found: /index
INFO - 2018-07-31 00:27:59 --> Config Class Initialized
INFO - 2018-07-31 00:27:59 --> Hooks Class Initialized
DEBUG - 2018-07-31 00:27:59 --> UTF-8 Support Enabled
INFO - 2018-07-31 00:27:59 --> Utf8 Class Initialized
INFO - 2018-07-31 00:27:59 --> URI Class Initialized
INFO - 2018-07-31 00:27:59 --> Router Class Initialized
INFO - 2018-07-31 00:27:59 --> Output Class Initialized
INFO - 2018-07-31 00:27:59 --> Security Class Initialized
DEBUG - 2018-07-31 00:27:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 00:27:59 --> Input Class Initialized
INFO - 2018-07-31 00:27:59 --> Language Class Initialized
INFO - 2018-07-31 00:27:59 --> Language Class Initialized
INFO - 2018-07-31 00:27:59 --> Config Class Initialized
INFO - 2018-07-31 00:27:59 --> Loader Class Initialized
DEBUG - 2018-07-31 00:27:59 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-31 00:27:59 --> Helper loaded: url_helper
INFO - 2018-07-31 00:27:59 --> Helper loaded: form_helper
INFO - 2018-07-31 00:27:59 --> Helper loaded: date_helper
INFO - 2018-07-31 00:27:59 --> Helper loaded: util_helper
INFO - 2018-07-31 00:27:59 --> Helper loaded: text_helper
INFO - 2018-07-31 00:27:59 --> Helper loaded: string_helper
INFO - 2018-07-31 00:27:59 --> Database Driver Class Initialized
DEBUG - 2018-07-31 00:27:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 00:27:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 00:27:59 --> Email Class Initialized
INFO - 2018-07-31 00:27:59 --> Controller Class Initialized
DEBUG - 2018-07-31 00:27:59 --> Programs MX_Controller Initialized
INFO - 2018-07-31 00:27:59 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-31 00:27:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-07-31 00:27:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-31 00:27:59 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-31 00:27:59 --> Login MX_Controller Initialized
DEBUG - 2018-07-31 00:27:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-31 00:27:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-31 00:27:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-31 00:27:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-31 00:27:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-31 00:27:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-31 00:27:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/programs/create_program.php
INFO - 2018-07-31 00:27:59 --> Final output sent to browser
INFO - 2018-07-31 00:27:59 --> Config Class Initialized
DEBUG - 2018-07-31 00:28:00 --> Total execution time: 0.4098
INFO - 2018-07-31 00:28:00 --> Hooks Class Initialized
DEBUG - 2018-07-31 00:28:00 --> UTF-8 Support Enabled
INFO - 2018-07-31 00:28:00 --> Utf8 Class Initialized
INFO - 2018-07-31 00:28:00 --> URI Class Initialized
DEBUG - 2018-07-31 00:28:00 --> No URI present. Default controller set.
INFO - 2018-07-31 00:28:00 --> Router Class Initialized
INFO - 2018-07-31 00:28:00 --> Output Class Initialized
INFO - 2018-07-31 00:28:00 --> Security Class Initialized
DEBUG - 2018-07-31 00:28:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 00:28:00 --> Input Class Initialized
INFO - 2018-07-31 00:28:00 --> Language Class Initialized
INFO - 2018-07-31 00:28:00 --> Language Class Initialized
INFO - 2018-07-31 00:28:00 --> Config Class Initialized
INFO - 2018-07-31 00:28:00 --> Loader Class Initialized
DEBUG - 2018-07-31 00:28:00 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-31 00:28:00 --> Helper loaded: url_helper
INFO - 2018-07-31 00:28:00 --> Helper loaded: form_helper
INFO - 2018-07-31 00:28:00 --> Helper loaded: date_helper
INFO - 2018-07-31 00:28:00 --> Helper loaded: util_helper
INFO - 2018-07-31 00:28:00 --> Helper loaded: text_helper
INFO - 2018-07-31 00:28:00 --> Helper loaded: string_helper
INFO - 2018-07-31 00:28:00 --> Database Driver Class Initialized
DEBUG - 2018-07-31 00:28:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 00:28:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 00:28:00 --> Email Class Initialized
INFO - 2018-07-31 00:28:00 --> Controller Class Initialized
INFO - 2018-07-31 00:28:00 --> Config Class Initialized
INFO - 2018-07-31 00:28:00 --> Hooks Class Initialized
DEBUG - 2018-07-31 00:28:00 --> Home MX_Controller Initialized
DEBUG - 2018-07-31 00:28:00 --> UTF-8 Support Enabled
INFO - 2018-07-31 00:28:00 --> Utf8 Class Initialized
INFO - 2018-07-31 00:28:00 --> URI Class Initialized
DEBUG - 2018-07-31 00:28:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-07-31 00:28:00 --> Router Class Initialized
DEBUG - 2018-07-31 00:28:00 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-31 00:28:00 --> Login MX_Controller Initialized
INFO - 2018-07-31 00:28:00 --> Output Class Initialized
INFO - 2018-07-31 00:28:00 --> Security Class Initialized
INFO - 2018-07-31 00:28:00 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-31 00:28:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 00:28:00 --> Input Class Initialized
INFO - 2018-07-31 00:28:00 --> Language Class Initialized
DEBUG - 2018-07-31 00:28:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
ERROR - 2018-07-31 00:28:00 --> 404 Page Not Found: /index
DEBUG - 2018-07-31 00:28:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-31 00:28:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-07-31 00:28:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-07-31 00:28:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-07-31 00:28:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-07-31 00:28:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-07-31 00:28:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-07-31 00:28:01 --> Final output sent to browser
DEBUG - 2018-07-31 00:28:01 --> Total execution time: 1.1102
INFO - 2018-07-31 00:28:17 --> Config Class Initialized
INFO - 2018-07-31 00:28:17 --> Hooks Class Initialized
DEBUG - 2018-07-31 00:28:17 --> UTF-8 Support Enabled
INFO - 2018-07-31 00:28:17 --> Utf8 Class Initialized
INFO - 2018-07-31 00:28:17 --> URI Class Initialized
INFO - 2018-07-31 00:28:17 --> Router Class Initialized
INFO - 2018-07-31 00:28:17 --> Output Class Initialized
INFO - 2018-07-31 00:28:17 --> Security Class Initialized
DEBUG - 2018-07-31 00:28:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 00:28:17 --> Input Class Initialized
INFO - 2018-07-31 00:28:17 --> Language Class Initialized
INFO - 2018-07-31 00:28:17 --> Language Class Initialized
INFO - 2018-07-31 00:28:17 --> Config Class Initialized
INFO - 2018-07-31 00:28:17 --> Loader Class Initialized
DEBUG - 2018-07-31 00:28:17 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-31 00:28:17 --> Helper loaded: url_helper
INFO - 2018-07-31 00:28:17 --> Helper loaded: form_helper
INFO - 2018-07-31 00:28:17 --> Helper loaded: date_helper
INFO - 2018-07-31 00:28:17 --> Helper loaded: util_helper
INFO - 2018-07-31 00:28:17 --> Helper loaded: text_helper
INFO - 2018-07-31 00:28:17 --> Helper loaded: string_helper
INFO - 2018-07-31 00:28:17 --> Database Driver Class Initialized
DEBUG - 2018-07-31 00:28:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 00:28:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 00:28:17 --> Email Class Initialized
INFO - 2018-07-31 00:28:17 --> Controller Class Initialized
DEBUG - 2018-07-31 00:28:17 --> Programs MX_Controller Initialized
INFO - 2018-07-31 00:28:17 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-31 00:28:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-07-31 00:28:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-31 00:28:18 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-31 00:28:18 --> Login MX_Controller Initialized
DEBUG - 2018-07-31 00:28:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-31 00:28:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-31 00:28:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-31 00:28:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-31 00:28:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-31 00:28:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-31 00:28:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/programs/programs.php
INFO - 2018-07-31 00:28:18 --> Final output sent to browser
DEBUG - 2018-07-31 00:28:18 --> Total execution time: 0.3775
INFO - 2018-07-31 00:28:18 --> Config Class Initialized
INFO - 2018-07-31 00:28:18 --> Hooks Class Initialized
DEBUG - 2018-07-31 00:28:18 --> UTF-8 Support Enabled
INFO - 2018-07-31 00:28:18 --> Utf8 Class Initialized
INFO - 2018-07-31 00:28:18 --> URI Class Initialized
INFO - 2018-07-31 00:28:18 --> Router Class Initialized
INFO - 2018-07-31 00:28:18 --> Output Class Initialized
INFO - 2018-07-31 00:28:18 --> Security Class Initialized
DEBUG - 2018-07-31 00:28:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 00:28:18 --> Input Class Initialized
INFO - 2018-07-31 00:28:18 --> Language Class Initialized
INFO - 2018-07-31 00:28:18 --> Language Class Initialized
INFO - 2018-07-31 00:28:18 --> Config Class Initialized
INFO - 2018-07-31 00:28:19 --> Loader Class Initialized
DEBUG - 2018-07-31 00:28:19 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-31 00:28:19 --> Helper loaded: url_helper
INFO - 2018-07-31 00:28:19 --> Helper loaded: form_helper
INFO - 2018-07-31 00:28:19 --> Helper loaded: date_helper
INFO - 2018-07-31 00:28:19 --> Helper loaded: util_helper
INFO - 2018-07-31 00:28:19 --> Helper loaded: text_helper
INFO - 2018-07-31 00:28:19 --> Helper loaded: string_helper
INFO - 2018-07-31 00:28:19 --> Database Driver Class Initialized
DEBUG - 2018-07-31 00:28:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 00:28:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 00:28:19 --> Email Class Initialized
INFO - 2018-07-31 00:28:19 --> Controller Class Initialized
DEBUG - 2018-07-31 00:28:19 --> Programs MX_Controller Initialized
INFO - 2018-07-31 00:28:19 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-31 00:28:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-07-31 00:28:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-31 00:28:19 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-31 00:28:19 --> Login MX_Controller Initialized
DEBUG - 2018-07-31 00:28:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-31 00:28:19 --> Final output sent to browser
DEBUG - 2018-07-31 00:28:19 --> Total execution time: 0.6563
INFO - 2018-07-31 00:28:20 --> Config Class Initialized
INFO - 2018-07-31 00:28:20 --> Hooks Class Initialized
DEBUG - 2018-07-31 00:28:20 --> UTF-8 Support Enabled
INFO - 2018-07-31 00:28:20 --> Utf8 Class Initialized
INFO - 2018-07-31 00:28:20 --> URI Class Initialized
INFO - 2018-07-31 00:28:20 --> Router Class Initialized
INFO - 2018-07-31 00:28:20 --> Output Class Initialized
INFO - 2018-07-31 00:28:20 --> Security Class Initialized
DEBUG - 2018-07-31 00:28:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 00:28:20 --> Input Class Initialized
INFO - 2018-07-31 00:28:20 --> Language Class Initialized
INFO - 2018-07-31 00:28:20 --> Language Class Initialized
INFO - 2018-07-31 00:28:20 --> Config Class Initialized
INFO - 2018-07-31 00:28:20 --> Loader Class Initialized
DEBUG - 2018-07-31 00:28:20 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-31 00:28:20 --> Helper loaded: url_helper
INFO - 2018-07-31 00:28:20 --> Helper loaded: form_helper
INFO - 2018-07-31 00:28:20 --> Helper loaded: date_helper
INFO - 2018-07-31 00:28:20 --> Helper loaded: util_helper
INFO - 2018-07-31 00:28:20 --> Helper loaded: text_helper
INFO - 2018-07-31 00:28:20 --> Helper loaded: string_helper
INFO - 2018-07-31 00:28:20 --> Database Driver Class Initialized
DEBUG - 2018-07-31 00:28:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 00:28:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 00:28:20 --> Email Class Initialized
INFO - 2018-07-31 00:28:20 --> Controller Class Initialized
DEBUG - 2018-07-31 00:28:20 --> Programs MX_Controller Initialized
INFO - 2018-07-31 00:28:21 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-31 00:28:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-07-31 00:28:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-31 00:28:21 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-31 00:28:21 --> Login MX_Controller Initialized
DEBUG - 2018-07-31 00:28:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-31 00:28:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-31 00:28:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-31 00:28:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-31 00:28:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-31 00:28:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-31 00:28:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/programs/programs.php
INFO - 2018-07-31 00:28:21 --> Final output sent to browser
DEBUG - 2018-07-31 00:28:21 --> Total execution time: 0.4322
INFO - 2018-07-31 00:28:21 --> Config Class Initialized
INFO - 2018-07-31 00:28:21 --> Hooks Class Initialized
DEBUG - 2018-07-31 00:28:21 --> UTF-8 Support Enabled
INFO - 2018-07-31 00:28:22 --> Utf8 Class Initialized
INFO - 2018-07-31 00:28:22 --> URI Class Initialized
INFO - 2018-07-31 00:28:22 --> Router Class Initialized
INFO - 2018-07-31 00:28:22 --> Output Class Initialized
INFO - 2018-07-31 00:28:22 --> Security Class Initialized
DEBUG - 2018-07-31 00:28:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 00:28:22 --> Input Class Initialized
INFO - 2018-07-31 00:28:22 --> Language Class Initialized
INFO - 2018-07-31 00:28:22 --> Language Class Initialized
INFO - 2018-07-31 00:28:22 --> Config Class Initialized
INFO - 2018-07-31 00:28:22 --> Loader Class Initialized
DEBUG - 2018-07-31 00:28:22 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-31 00:28:22 --> Helper loaded: url_helper
INFO - 2018-07-31 00:28:22 --> Helper loaded: form_helper
INFO - 2018-07-31 00:28:22 --> Helper loaded: date_helper
INFO - 2018-07-31 00:28:22 --> Helper loaded: util_helper
INFO - 2018-07-31 00:28:22 --> Helper loaded: text_helper
INFO - 2018-07-31 00:28:22 --> Helper loaded: string_helper
INFO - 2018-07-31 00:28:22 --> Database Driver Class Initialized
DEBUG - 2018-07-31 00:28:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 00:28:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 00:28:22 --> Email Class Initialized
INFO - 2018-07-31 00:28:22 --> Controller Class Initialized
DEBUG - 2018-07-31 00:28:22 --> Programs MX_Controller Initialized
INFO - 2018-07-31 00:28:22 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-31 00:28:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-07-31 00:28:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-31 00:28:22 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-31 00:28:22 --> Login MX_Controller Initialized
DEBUG - 2018-07-31 00:28:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-31 00:28:22 --> Final output sent to browser
DEBUG - 2018-07-31 00:28:22 --> Total execution time: 0.8993
INFO - 2018-07-31 00:28:25 --> Config Class Initialized
INFO - 2018-07-31 00:28:25 --> Hooks Class Initialized
DEBUG - 2018-07-31 00:28:25 --> UTF-8 Support Enabled
INFO - 2018-07-31 00:28:25 --> Utf8 Class Initialized
INFO - 2018-07-31 00:28:25 --> URI Class Initialized
INFO - 2018-07-31 00:28:25 --> Router Class Initialized
INFO - 2018-07-31 00:28:25 --> Output Class Initialized
INFO - 2018-07-31 00:28:25 --> Security Class Initialized
DEBUG - 2018-07-31 00:28:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 00:28:25 --> Input Class Initialized
INFO - 2018-07-31 00:28:25 --> Language Class Initialized
INFO - 2018-07-31 00:28:25 --> Language Class Initialized
INFO - 2018-07-31 00:28:25 --> Config Class Initialized
INFO - 2018-07-31 00:28:25 --> Loader Class Initialized
DEBUG - 2018-07-31 00:28:25 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-31 00:28:25 --> Helper loaded: url_helper
INFO - 2018-07-31 00:28:25 --> Helper loaded: form_helper
INFO - 2018-07-31 00:28:25 --> Helper loaded: date_helper
INFO - 2018-07-31 00:28:25 --> Helper loaded: util_helper
INFO - 2018-07-31 00:28:25 --> Helper loaded: text_helper
INFO - 2018-07-31 00:28:25 --> Helper loaded: string_helper
INFO - 2018-07-31 00:28:25 --> Database Driver Class Initialized
DEBUG - 2018-07-31 00:28:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 00:28:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 00:28:25 --> Email Class Initialized
INFO - 2018-07-31 00:28:25 --> Controller Class Initialized
DEBUG - 2018-07-31 00:28:25 --> Programs MX_Controller Initialized
INFO - 2018-07-31 00:28:25 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-31 00:28:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-07-31 00:28:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-31 00:28:25 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-31 00:28:25 --> Login MX_Controller Initialized
DEBUG - 2018-07-31 00:28:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-31 00:28:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-31 00:28:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-31 00:28:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-31 00:28:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-31 00:28:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-31 00:28:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/programs/create_program.php
INFO - 2018-07-31 00:28:25 --> Final output sent to browser
DEBUG - 2018-07-31 00:28:26 --> Total execution time: 0.5014
INFO - 2018-07-31 00:28:26 --> Config Class Initialized
INFO - 2018-07-31 00:28:26 --> Hooks Class Initialized
DEBUG - 2018-07-31 00:28:26 --> UTF-8 Support Enabled
INFO - 2018-07-31 00:28:26 --> Utf8 Class Initialized
INFO - 2018-07-31 00:28:26 --> URI Class Initialized
DEBUG - 2018-07-31 00:28:26 --> No URI present. Default controller set.
INFO - 2018-07-31 00:28:26 --> Router Class Initialized
INFO - 2018-07-31 00:28:26 --> Output Class Initialized
INFO - 2018-07-31 00:28:26 --> Security Class Initialized
DEBUG - 2018-07-31 00:28:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 00:28:26 --> Input Class Initialized
INFO - 2018-07-31 00:28:26 --> Language Class Initialized
INFO - 2018-07-31 00:28:26 --> Language Class Initialized
INFO - 2018-07-31 00:28:26 --> Config Class Initialized
INFO - 2018-07-31 00:28:26 --> Loader Class Initialized
DEBUG - 2018-07-31 00:28:26 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-31 00:28:26 --> Helper loaded: url_helper
INFO - 2018-07-31 00:28:26 --> Helper loaded: form_helper
INFO - 2018-07-31 00:28:26 --> Helper loaded: date_helper
INFO - 2018-07-31 00:28:26 --> Helper loaded: util_helper
INFO - 2018-07-31 00:28:26 --> Helper loaded: text_helper
INFO - 2018-07-31 00:28:26 --> Helper loaded: string_helper
INFO - 2018-07-31 00:28:26 --> Database Driver Class Initialized
DEBUG - 2018-07-31 00:28:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 00:28:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 00:28:26 --> Email Class Initialized
INFO - 2018-07-31 00:28:26 --> Controller Class Initialized
DEBUG - 2018-07-31 00:28:26 --> Home MX_Controller Initialized
DEBUG - 2018-07-31 00:28:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-31 00:28:26 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-31 00:28:26 --> Login MX_Controller Initialized
INFO - 2018-07-31 00:28:26 --> Config Class Initialized
INFO - 2018-07-31 00:28:26 --> Hooks Class Initialized
INFO - 2018-07-31 00:28:26 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-31 00:28:26 --> UTF-8 Support Enabled
INFO - 2018-07-31 00:28:26 --> Utf8 Class Initialized
INFO - 2018-07-31 00:28:26 --> URI Class Initialized
DEBUG - 2018-07-31 00:28:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-31 00:28:26 --> Router Class Initialized
INFO - 2018-07-31 00:28:26 --> Output Class Initialized
DEBUG - 2018-07-31 00:28:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-31 00:28:26 --> Security Class Initialized
DEBUG - 2018-07-31 00:28:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 00:28:26 --> Input Class Initialized
INFO - 2018-07-31 00:28:27 --> Language Class Initialized
DEBUG - 2018-07-31 00:28:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-07-31 00:28:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
ERROR - 2018-07-31 00:28:27 --> 404 Page Not Found: /index
DEBUG - 2018-07-31 00:28:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-07-31 00:28:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-07-31 00:28:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-07-31 00:28:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-07-31 00:28:27 --> Final output sent to browser
DEBUG - 2018-07-31 00:28:27 --> Total execution time: 0.9875
INFO - 2018-07-31 00:28:31 --> Config Class Initialized
INFO - 2018-07-31 00:28:31 --> Hooks Class Initialized
DEBUG - 2018-07-31 00:28:31 --> UTF-8 Support Enabled
INFO - 2018-07-31 00:28:31 --> Utf8 Class Initialized
INFO - 2018-07-31 00:28:31 --> URI Class Initialized
INFO - 2018-07-31 00:28:31 --> Router Class Initialized
INFO - 2018-07-31 00:28:31 --> Output Class Initialized
INFO - 2018-07-31 00:28:31 --> Security Class Initialized
DEBUG - 2018-07-31 00:28:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 00:28:31 --> Input Class Initialized
INFO - 2018-07-31 00:28:31 --> Language Class Initialized
INFO - 2018-07-31 00:28:31 --> Language Class Initialized
INFO - 2018-07-31 00:28:31 --> Config Class Initialized
INFO - 2018-07-31 00:28:31 --> Loader Class Initialized
DEBUG - 2018-07-31 00:28:31 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-31 00:28:31 --> Helper loaded: url_helper
INFO - 2018-07-31 00:28:31 --> Helper loaded: form_helper
INFO - 2018-07-31 00:28:31 --> Helper loaded: date_helper
INFO - 2018-07-31 00:28:31 --> Helper loaded: util_helper
INFO - 2018-07-31 00:28:31 --> Helper loaded: text_helper
INFO - 2018-07-31 00:28:31 --> Helper loaded: string_helper
INFO - 2018-07-31 00:28:31 --> Database Driver Class Initialized
DEBUG - 2018-07-31 00:28:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 00:28:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 00:28:31 --> Email Class Initialized
INFO - 2018-07-31 00:28:31 --> Controller Class Initialized
DEBUG - 2018-07-31 00:28:31 --> Programs MX_Controller Initialized
INFO - 2018-07-31 00:28:31 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-31 00:28:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-07-31 00:28:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-31 00:28:31 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-31 00:28:31 --> Login MX_Controller Initialized
DEBUG - 2018-07-31 00:28:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-31 00:28:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
ERROR - 2018-07-31 00:28:31 --> Severity: Notice --> Undefined index: image E:\xampp\htdocs\consulting\application\modules\admin\controllers\Programs.php 169
INFO - 2018-07-31 00:34:20 --> Config Class Initialized
INFO - 2018-07-31 00:34:20 --> Hooks Class Initialized
DEBUG - 2018-07-31 00:34:20 --> UTF-8 Support Enabled
INFO - 2018-07-31 00:34:20 --> Utf8 Class Initialized
INFO - 2018-07-31 00:34:20 --> URI Class Initialized
INFO - 2018-07-31 00:34:20 --> Router Class Initialized
INFO - 2018-07-31 00:34:20 --> Output Class Initialized
INFO - 2018-07-31 00:34:20 --> Security Class Initialized
DEBUG - 2018-07-31 00:34:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 00:34:20 --> Input Class Initialized
INFO - 2018-07-31 00:34:20 --> Language Class Initialized
INFO - 2018-07-31 00:34:21 --> Language Class Initialized
INFO - 2018-07-31 00:34:21 --> Config Class Initialized
INFO - 2018-07-31 00:34:21 --> Loader Class Initialized
DEBUG - 2018-07-31 00:34:21 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-31 00:34:21 --> Helper loaded: url_helper
INFO - 2018-07-31 00:34:21 --> Helper loaded: form_helper
INFO - 2018-07-31 00:34:21 --> Helper loaded: date_helper
INFO - 2018-07-31 00:34:21 --> Helper loaded: util_helper
INFO - 2018-07-31 00:34:21 --> Helper loaded: text_helper
INFO - 2018-07-31 00:34:21 --> Helper loaded: string_helper
INFO - 2018-07-31 00:34:21 --> Database Driver Class Initialized
DEBUG - 2018-07-31 00:34:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 00:34:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 00:34:21 --> Email Class Initialized
INFO - 2018-07-31 00:34:21 --> Controller Class Initialized
DEBUG - 2018-07-31 00:34:21 --> Programs MX_Controller Initialized
INFO - 2018-07-31 00:34:21 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-31 00:34:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-07-31 00:34:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-31 00:34:21 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-31 00:34:21 --> Login MX_Controller Initialized
DEBUG - 2018-07-31 00:34:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-31 00:34:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-31 00:34:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-31 00:34:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-31 00:34:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-31 00:34:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-31 00:34:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/programs/create_program.php
INFO - 2018-07-31 00:34:21 --> Final output sent to browser
DEBUG - 2018-07-31 00:34:21 --> Total execution time: 0.4145
INFO - 2018-07-31 00:34:23 --> Config Class Initialized
INFO - 2018-07-31 00:34:23 --> Hooks Class Initialized
DEBUG - 2018-07-31 00:34:23 --> UTF-8 Support Enabled
INFO - 2018-07-31 00:34:23 --> Utf8 Class Initialized
INFO - 2018-07-31 00:34:23 --> URI Class Initialized
INFO - 2018-07-31 00:34:23 --> Router Class Initialized
INFO - 2018-07-31 00:34:23 --> Output Class Initialized
INFO - 2018-07-31 00:34:23 --> Security Class Initialized
DEBUG - 2018-07-31 00:34:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 00:34:23 --> Input Class Initialized
INFO - 2018-07-31 00:34:23 --> Language Class Initialized
INFO - 2018-07-31 00:34:23 --> Language Class Initialized
INFO - 2018-07-31 00:34:23 --> Config Class Initialized
INFO - 2018-07-31 00:34:23 --> Loader Class Initialized
DEBUG - 2018-07-31 00:34:23 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-31 00:34:23 --> Helper loaded: url_helper
INFO - 2018-07-31 00:34:23 --> Helper loaded: form_helper
INFO - 2018-07-31 00:34:23 --> Helper loaded: date_helper
INFO - 2018-07-31 00:34:23 --> Helper loaded: util_helper
INFO - 2018-07-31 00:34:23 --> Helper loaded: text_helper
INFO - 2018-07-31 00:34:23 --> Helper loaded: string_helper
INFO - 2018-07-31 00:34:23 --> Database Driver Class Initialized
DEBUG - 2018-07-31 00:34:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 00:34:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 00:34:23 --> Email Class Initialized
INFO - 2018-07-31 00:34:23 --> Controller Class Initialized
DEBUG - 2018-07-31 00:34:23 --> Programs MX_Controller Initialized
INFO - 2018-07-31 00:34:23 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-31 00:34:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-07-31 00:34:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-31 00:34:23 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-31 00:34:23 --> Login MX_Controller Initialized
DEBUG - 2018-07-31 00:34:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-31 00:34:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-31 00:34:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-31 00:34:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-31 00:34:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-31 00:34:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-31 00:34:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/programs/create_program.php
INFO - 2018-07-31 00:34:23 --> Final output sent to browser
DEBUG - 2018-07-31 00:34:23 --> Total execution time: 0.4628
INFO - 2018-07-31 00:34:54 --> Config Class Initialized
INFO - 2018-07-31 00:34:54 --> Hooks Class Initialized
DEBUG - 2018-07-31 00:34:54 --> UTF-8 Support Enabled
INFO - 2018-07-31 00:34:54 --> Utf8 Class Initialized
INFO - 2018-07-31 00:34:54 --> URI Class Initialized
INFO - 2018-07-31 00:34:54 --> Router Class Initialized
INFO - 2018-07-31 00:34:54 --> Output Class Initialized
INFO - 2018-07-31 00:34:54 --> Security Class Initialized
DEBUG - 2018-07-31 00:34:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 00:34:54 --> Input Class Initialized
INFO - 2018-07-31 00:34:54 --> Language Class Initialized
INFO - 2018-07-31 00:34:54 --> Language Class Initialized
INFO - 2018-07-31 00:34:54 --> Config Class Initialized
INFO - 2018-07-31 00:34:54 --> Loader Class Initialized
DEBUG - 2018-07-31 00:34:54 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-31 00:34:54 --> Helper loaded: url_helper
INFO - 2018-07-31 00:34:54 --> Helper loaded: form_helper
INFO - 2018-07-31 00:34:54 --> Helper loaded: date_helper
INFO - 2018-07-31 00:34:54 --> Helper loaded: util_helper
INFO - 2018-07-31 00:34:54 --> Helper loaded: text_helper
INFO - 2018-07-31 00:34:54 --> Helper loaded: string_helper
INFO - 2018-07-31 00:34:54 --> Database Driver Class Initialized
DEBUG - 2018-07-31 00:34:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 00:34:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 00:34:54 --> Email Class Initialized
INFO - 2018-07-31 00:34:54 --> Controller Class Initialized
DEBUG - 2018-07-31 00:34:54 --> Programs MX_Controller Initialized
INFO - 2018-07-31 00:34:54 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-31 00:34:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-07-31 00:34:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-31 00:34:55 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-31 00:34:55 --> Login MX_Controller Initialized
DEBUG - 2018-07-31 00:34:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-31 00:34:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-31 00:34:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-31 00:34:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-31 00:34:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-31 00:34:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-31 00:34:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/programs/create_program.php
INFO - 2018-07-31 00:34:55 --> Final output sent to browser
DEBUG - 2018-07-31 00:34:55 --> Total execution time: 0.4054
INFO - 2018-07-31 00:37:46 --> Config Class Initialized
INFO - 2018-07-31 00:37:46 --> Hooks Class Initialized
DEBUG - 2018-07-31 00:37:46 --> UTF-8 Support Enabled
INFO - 2018-07-31 00:37:46 --> Utf8 Class Initialized
INFO - 2018-07-31 00:37:46 --> URI Class Initialized
INFO - 2018-07-31 00:37:46 --> Router Class Initialized
INFO - 2018-07-31 00:37:46 --> Output Class Initialized
INFO - 2018-07-31 00:37:46 --> Security Class Initialized
DEBUG - 2018-07-31 00:37:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 00:37:46 --> Input Class Initialized
INFO - 2018-07-31 00:37:46 --> Language Class Initialized
INFO - 2018-07-31 00:37:46 --> Language Class Initialized
INFO - 2018-07-31 00:37:46 --> Config Class Initialized
INFO - 2018-07-31 00:37:46 --> Loader Class Initialized
DEBUG - 2018-07-31 00:37:46 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-31 00:37:46 --> Helper loaded: url_helper
INFO - 2018-07-31 00:37:46 --> Helper loaded: form_helper
INFO - 2018-07-31 00:37:46 --> Helper loaded: date_helper
INFO - 2018-07-31 00:37:46 --> Helper loaded: util_helper
INFO - 2018-07-31 00:37:46 --> Helper loaded: text_helper
INFO - 2018-07-31 00:37:46 --> Helper loaded: string_helper
INFO - 2018-07-31 00:37:46 --> Database Driver Class Initialized
DEBUG - 2018-07-31 00:37:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 00:37:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 00:37:46 --> Email Class Initialized
INFO - 2018-07-31 00:37:46 --> Controller Class Initialized
DEBUG - 2018-07-31 00:37:46 --> Programs MX_Controller Initialized
INFO - 2018-07-31 00:37:46 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-31 00:37:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-07-31 00:37:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-31 00:37:46 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-31 00:37:46 --> Login MX_Controller Initialized
DEBUG - 2018-07-31 00:37:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-31 00:37:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-31 00:37:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-31 00:37:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-31 00:37:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-31 00:37:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-31 00:37:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/programs/create_program.php
INFO - 2018-07-31 00:37:47 --> Final output sent to browser
DEBUG - 2018-07-31 00:37:47 --> Total execution time: 0.4883
INFO - 2018-07-31 00:39:01 --> Config Class Initialized
INFO - 2018-07-31 00:39:01 --> Hooks Class Initialized
DEBUG - 2018-07-31 00:39:01 --> UTF-8 Support Enabled
INFO - 2018-07-31 00:39:01 --> Utf8 Class Initialized
INFO - 2018-07-31 00:39:01 --> URI Class Initialized
INFO - 2018-07-31 00:39:01 --> Router Class Initialized
INFO - 2018-07-31 00:39:01 --> Output Class Initialized
INFO - 2018-07-31 00:39:01 --> Security Class Initialized
DEBUG - 2018-07-31 00:39:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 00:39:01 --> Input Class Initialized
INFO - 2018-07-31 00:39:01 --> Language Class Initialized
INFO - 2018-07-31 00:39:01 --> Language Class Initialized
INFO - 2018-07-31 00:39:01 --> Config Class Initialized
INFO - 2018-07-31 00:39:01 --> Loader Class Initialized
DEBUG - 2018-07-31 00:39:01 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-31 00:39:01 --> Helper loaded: url_helper
INFO - 2018-07-31 00:39:01 --> Helper loaded: form_helper
INFO - 2018-07-31 00:39:01 --> Helper loaded: date_helper
INFO - 2018-07-31 00:39:01 --> Helper loaded: util_helper
INFO - 2018-07-31 00:39:01 --> Helper loaded: text_helper
INFO - 2018-07-31 00:39:01 --> Helper loaded: string_helper
INFO - 2018-07-31 00:39:01 --> Database Driver Class Initialized
DEBUG - 2018-07-31 00:39:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 00:39:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 00:39:01 --> Email Class Initialized
INFO - 2018-07-31 00:39:01 --> Controller Class Initialized
DEBUG - 2018-07-31 00:39:01 --> Programs MX_Controller Initialized
INFO - 2018-07-31 00:39:01 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-31 00:39:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-07-31 00:39:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-31 00:39:01 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-31 00:39:01 --> Login MX_Controller Initialized
DEBUG - 2018-07-31 00:39:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-31 01:34:02 --> Config Class Initialized
INFO - 2018-07-31 01:34:02 --> Hooks Class Initialized
DEBUG - 2018-07-31 01:34:02 --> UTF-8 Support Enabled
INFO - 2018-07-31 01:34:02 --> Utf8 Class Initialized
INFO - 2018-07-31 01:34:02 --> URI Class Initialized
INFO - 2018-07-31 01:34:02 --> Router Class Initialized
INFO - 2018-07-31 01:34:02 --> Output Class Initialized
INFO - 2018-07-31 01:34:02 --> Security Class Initialized
DEBUG - 2018-07-31 01:34:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 01:34:02 --> Input Class Initialized
INFO - 2018-07-31 01:34:02 --> Language Class Initialized
INFO - 2018-07-31 01:34:02 --> Language Class Initialized
INFO - 2018-07-31 01:34:02 --> Config Class Initialized
INFO - 2018-07-31 01:34:02 --> Loader Class Initialized
DEBUG - 2018-07-31 01:34:02 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-31 01:34:02 --> Helper loaded: url_helper
INFO - 2018-07-31 01:34:02 --> Helper loaded: form_helper
INFO - 2018-07-31 01:34:03 --> Helper loaded: date_helper
INFO - 2018-07-31 01:34:03 --> Helper loaded: util_helper
INFO - 2018-07-31 01:34:03 --> Helper loaded: text_helper
INFO - 2018-07-31 01:34:03 --> Helper loaded: string_helper
INFO - 2018-07-31 01:34:03 --> Database Driver Class Initialized
DEBUG - 2018-07-31 01:34:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 01:34:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 01:34:03 --> Email Class Initialized
INFO - 2018-07-31 01:34:03 --> Controller Class Initialized
DEBUG - 2018-07-31 01:34:03 --> Programs MX_Controller Initialized
INFO - 2018-07-31 01:34:03 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-31 01:34:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-07-31 01:34:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-31 01:34:03 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-31 01:34:03 --> Login MX_Controller Initialized
DEBUG - 2018-07-31 01:34:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-31 01:34:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
ERROR - 2018-07-31 01:34:03 --> Severity: Notice --> Undefined index: prg_img_vid_name E:\xampp\htdocs\consulting\application\modules\admin\controllers\Programs.php 169
INFO - 2018-07-31 02:01:29 --> Config Class Initialized
INFO - 2018-07-31 02:01:29 --> Hooks Class Initialized
DEBUG - 2018-07-31 02:01:29 --> UTF-8 Support Enabled
INFO - 2018-07-31 02:01:29 --> Utf8 Class Initialized
INFO - 2018-07-31 02:01:29 --> URI Class Initialized
INFO - 2018-07-31 02:01:29 --> Router Class Initialized
INFO - 2018-07-31 02:01:29 --> Output Class Initialized
INFO - 2018-07-31 02:01:29 --> Security Class Initialized
DEBUG - 2018-07-31 02:01:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 02:01:29 --> Input Class Initialized
INFO - 2018-07-31 02:01:29 --> Language Class Initialized
INFO - 2018-07-31 02:01:29 --> Language Class Initialized
INFO - 2018-07-31 02:01:29 --> Config Class Initialized
INFO - 2018-07-31 02:01:29 --> Loader Class Initialized
DEBUG - 2018-07-31 02:01:29 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-31 02:01:29 --> Helper loaded: url_helper
INFO - 2018-07-31 02:01:29 --> Helper loaded: form_helper
INFO - 2018-07-31 02:01:29 --> Helper loaded: date_helper
INFO - 2018-07-31 02:01:30 --> Helper loaded: util_helper
INFO - 2018-07-31 02:01:30 --> Helper loaded: text_helper
INFO - 2018-07-31 02:01:30 --> Helper loaded: string_helper
INFO - 2018-07-31 02:01:30 --> Database Driver Class Initialized
DEBUG - 2018-07-31 02:01:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 02:01:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 02:01:30 --> Email Class Initialized
INFO - 2018-07-31 02:01:30 --> Controller Class Initialized
DEBUG - 2018-07-31 02:01:30 --> Home MX_Controller Initialized
DEBUG - 2018-07-31 02:01:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-31 02:01:30 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-31 02:01:30 --> Login MX_Controller Initialized
INFO - 2018-07-31 02:01:30 --> Language file loaded: language/english/data_lang.php
INFO - 2018-07-31 02:01:30 --> Config Class Initialized
INFO - 2018-07-31 02:01:30 --> Hooks Class Initialized
DEBUG - 2018-07-31 02:01:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-31 02:01:30 --> UTF-8 Support Enabled
DEBUG - 2018-07-31 02:01:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-31 02:01:30 --> Utf8 Class Initialized
INFO - 2018-07-31 02:01:30 --> URI Class Initialized
INFO - 2018-07-31 02:01:30 --> Router Class Initialized
INFO - 2018-07-31 02:01:30 --> Output Class Initialized
INFO - 2018-07-31 02:01:30 --> Security Class Initialized
DEBUG - 2018-07-31 02:01:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 02:01:30 --> Input Class Initialized
INFO - 2018-07-31 02:01:30 --> Language Class Initialized
ERROR - 2018-07-31 02:01:30 --> 404 Page Not Found: /index
INFO - 2018-07-31 02:01:30 --> Config Class Initialized
INFO - 2018-07-31 02:01:30 --> Hooks Class Initialized
DEBUG - 2018-07-31 02:01:30 --> UTF-8 Support Enabled
INFO - 2018-07-31 02:01:30 --> Utf8 Class Initialized
INFO - 2018-07-31 02:01:30 --> URI Class Initialized
INFO - 2018-07-31 02:01:30 --> Router Class Initialized
INFO - 2018-07-31 02:01:30 --> Output Class Initialized
INFO - 2018-07-31 02:01:30 --> Security Class Initialized
DEBUG - 2018-07-31 02:01:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 02:01:30 --> Input Class Initialized
INFO - 2018-07-31 02:01:30 --> Language Class Initialized
ERROR - 2018-07-31 02:01:30 --> 404 Page Not Found: /index
INFO - 2018-07-31 02:01:30 --> Config Class Initialized
INFO - 2018-07-31 02:01:30 --> Hooks Class Initialized
DEBUG - 2018-07-31 02:01:30 --> UTF-8 Support Enabled
INFO - 2018-07-31 02:01:30 --> Utf8 Class Initialized
INFO - 2018-07-31 02:01:30 --> URI Class Initialized
INFO - 2018-07-31 02:01:30 --> Router Class Initialized
INFO - 2018-07-31 02:01:30 --> Output Class Initialized
INFO - 2018-07-31 02:01:30 --> Security Class Initialized
DEBUG - 2018-07-31 02:01:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 02:01:30 --> Input Class Initialized
INFO - 2018-07-31 02:01:30 --> Language Class Initialized
ERROR - 2018-07-31 02:01:30 --> 404 Page Not Found: /index
INFO - 2018-07-31 02:01:31 --> Config Class Initialized
INFO - 2018-07-31 02:01:31 --> Hooks Class Initialized
DEBUG - 2018-07-31 02:01:31 --> UTF-8 Support Enabled
INFO - 2018-07-31 02:01:31 --> Utf8 Class Initialized
INFO - 2018-07-31 02:01:31 --> URI Class Initialized
INFO - 2018-07-31 02:01:31 --> Router Class Initialized
INFO - 2018-07-31 02:01:31 --> Output Class Initialized
INFO - 2018-07-31 02:01:31 --> Security Class Initialized
DEBUG - 2018-07-31 02:01:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 02:01:31 --> Input Class Initialized
INFO - 2018-07-31 02:01:31 --> Language Class Initialized
INFO - 2018-07-31 02:01:31 --> Language Class Initialized
INFO - 2018-07-31 02:01:31 --> Config Class Initialized
INFO - 2018-07-31 02:01:31 --> Loader Class Initialized
DEBUG - 2018-07-31 02:01:31 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-31 02:01:31 --> Helper loaded: url_helper
INFO - 2018-07-31 02:01:32 --> Helper loaded: form_helper
INFO - 2018-07-31 02:01:32 --> Helper loaded: date_helper
INFO - 2018-07-31 02:01:32 --> Helper loaded: util_helper
INFO - 2018-07-31 02:01:32 --> Helper loaded: text_helper
INFO - 2018-07-31 02:01:32 --> Helper loaded: string_helper
INFO - 2018-07-31 02:01:32 --> Database Driver Class Initialized
DEBUG - 2018-07-31 02:01:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 02:01:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 02:01:32 --> Email Class Initialized
INFO - 2018-07-31 02:01:32 --> Controller Class Initialized
DEBUG - 2018-07-31 02:01:32 --> Home MX_Controller Initialized
DEBUG - 2018-07-31 02:01:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-31 02:01:32 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-31 02:01:32 --> Login MX_Controller Initialized
INFO - 2018-07-31 02:01:32 --> Language file loaded: language/english/data_lang.php
INFO - 2018-07-31 02:01:32 --> Config Class Initialized
DEBUG - 2018-07-31 02:01:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-31 02:01:32 --> Hooks Class Initialized
DEBUG - 2018-07-31 02:01:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-31 02:01:32 --> UTF-8 Support Enabled
INFO - 2018-07-31 02:01:32 --> Utf8 Class Initialized
INFO - 2018-07-31 02:01:32 --> URI Class Initialized
INFO - 2018-07-31 02:01:32 --> Router Class Initialized
INFO - 2018-07-31 02:01:32 --> Output Class Initialized
INFO - 2018-07-31 02:01:32 --> Security Class Initialized
DEBUG - 2018-07-31 02:01:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 02:01:32 --> Input Class Initialized
INFO - 2018-07-31 02:01:32 --> Language Class Initialized
ERROR - 2018-07-31 02:01:32 --> 404 Page Not Found: /index
INFO - 2018-07-31 02:01:32 --> Config Class Initialized
INFO - 2018-07-31 02:01:32 --> Hooks Class Initialized
DEBUG - 2018-07-31 02:01:32 --> UTF-8 Support Enabled
INFO - 2018-07-31 02:01:32 --> Utf8 Class Initialized
INFO - 2018-07-31 02:01:32 --> URI Class Initialized
INFO - 2018-07-31 02:01:32 --> Router Class Initialized
INFO - 2018-07-31 02:01:32 --> Output Class Initialized
INFO - 2018-07-31 02:01:32 --> Security Class Initialized
DEBUG - 2018-07-31 02:01:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 02:01:32 --> Input Class Initialized
INFO - 2018-07-31 02:01:32 --> Language Class Initialized
ERROR - 2018-07-31 02:01:32 --> 404 Page Not Found: /index
INFO - 2018-07-31 02:01:32 --> Config Class Initialized
INFO - 2018-07-31 02:01:32 --> Hooks Class Initialized
DEBUG - 2018-07-31 02:01:32 --> UTF-8 Support Enabled
INFO - 2018-07-31 02:01:32 --> Utf8 Class Initialized
INFO - 2018-07-31 02:01:32 --> URI Class Initialized
INFO - 2018-07-31 02:01:32 --> Router Class Initialized
INFO - 2018-07-31 02:01:32 --> Output Class Initialized
INFO - 2018-07-31 02:01:32 --> Security Class Initialized
DEBUG - 2018-07-31 02:01:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 02:01:32 --> Input Class Initialized
INFO - 2018-07-31 02:01:32 --> Language Class Initialized
ERROR - 2018-07-31 02:01:32 --> 404 Page Not Found: /index
INFO - 2018-07-31 02:01:34 --> Config Class Initialized
INFO - 2018-07-31 02:01:34 --> Hooks Class Initialized
DEBUG - 2018-07-31 02:01:34 --> UTF-8 Support Enabled
INFO - 2018-07-31 02:01:34 --> Utf8 Class Initialized
INFO - 2018-07-31 02:01:34 --> URI Class Initialized
INFO - 2018-07-31 02:01:34 --> Router Class Initialized
INFO - 2018-07-31 02:01:34 --> Config Class Initialized
INFO - 2018-07-31 02:01:34 --> Hooks Class Initialized
INFO - 2018-07-31 02:01:34 --> Output Class Initialized
DEBUG - 2018-07-31 02:01:34 --> UTF-8 Support Enabled
INFO - 2018-07-31 02:01:34 --> Security Class Initialized
INFO - 2018-07-31 02:01:34 --> Utf8 Class Initialized
DEBUG - 2018-07-31 02:01:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 02:01:34 --> URI Class Initialized
INFO - 2018-07-31 02:01:34 --> Input Class Initialized
INFO - 2018-07-31 02:01:34 --> Router Class Initialized
INFO - 2018-07-31 02:01:34 --> Output Class Initialized
INFO - 2018-07-31 02:01:34 --> Security Class Initialized
DEBUG - 2018-07-31 02:01:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 02:01:34 --> Input Class Initialized
INFO - 2018-07-31 02:01:34 --> Language Class Initialized
ERROR - 2018-07-31 02:01:34 --> 404 Page Not Found: /index
INFO - 2018-07-31 02:01:34 --> Config Class Initialized
INFO - 2018-07-31 02:01:34 --> Hooks Class Initialized
INFO - 2018-07-31 02:01:34 --> Language Class Initialized
DEBUG - 2018-07-31 02:01:34 --> UTF-8 Support Enabled
INFO - 2018-07-31 02:01:34 --> Utf8 Class Initialized
INFO - 2018-07-31 02:01:34 --> Language Class Initialized
INFO - 2018-07-31 02:01:34 --> URI Class Initialized
INFO - 2018-07-31 02:01:34 --> Config Class Initialized
INFO - 2018-07-31 02:01:34 --> Loader Class Initialized
INFO - 2018-07-31 02:01:34 --> Router Class Initialized
INFO - 2018-07-31 02:01:34 --> Output Class Initialized
DEBUG - 2018-07-31 02:01:34 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-31 02:01:34 --> Helper loaded: url_helper
INFO - 2018-07-31 02:01:34 --> Security Class Initialized
DEBUG - 2018-07-31 02:01:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 02:01:34 --> Helper loaded: form_helper
INFO - 2018-07-31 02:01:34 --> Input Class Initialized
INFO - 2018-07-31 02:01:34 --> Helper loaded: date_helper
INFO - 2018-07-31 02:01:34 --> Language Class Initialized
INFO - 2018-07-31 02:01:34 --> Helper loaded: util_helper
ERROR - 2018-07-31 02:01:34 --> 404 Page Not Found: /index
INFO - 2018-07-31 02:01:34 --> Helper loaded: text_helper
INFO - 2018-07-31 02:01:34 --> Helper loaded: string_helper
INFO - 2018-07-31 02:01:34 --> Config Class Initialized
INFO - 2018-07-31 02:01:34 --> Hooks Class Initialized
INFO - 2018-07-31 02:01:34 --> Database Driver Class Initialized
DEBUG - 2018-07-31 02:01:34 --> UTF-8 Support Enabled
DEBUG - 2018-07-31 02:01:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 02:01:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 02:01:34 --> Utf8 Class Initialized
INFO - 2018-07-31 02:01:34 --> URI Class Initialized
INFO - 2018-07-31 02:01:34 --> Email Class Initialized
INFO - 2018-07-31 02:01:34 --> Controller Class Initialized
INFO - 2018-07-31 02:01:34 --> Router Class Initialized
DEBUG - 2018-07-31 02:01:34 --> Home MX_Controller Initialized
DEBUG - 2018-07-31 02:01:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-07-31 02:01:34 --> Output Class Initialized
INFO - 2018-07-31 02:01:34 --> Security Class Initialized
DEBUG - 2018-07-31 02:01:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-07-31 02:01:34 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-31 02:01:34 --> Login MX_Controller Initialized
INFO - 2018-07-31 02:01:34 --> Input Class Initialized
INFO - 2018-07-31 02:01:34 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-31 02:01:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-31 02:01:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-31 02:01:34 --> Language Class Initialized
ERROR - 2018-07-31 02:01:35 --> 404 Page Not Found: /index
INFO - 2018-07-31 02:01:36 --> Config Class Initialized
INFO - 2018-07-31 02:01:36 --> Hooks Class Initialized
DEBUG - 2018-07-31 02:01:36 --> UTF-8 Support Enabled
INFO - 2018-07-31 02:01:36 --> Utf8 Class Initialized
INFO - 2018-07-31 02:01:36 --> URI Class Initialized
INFO - 2018-07-31 02:01:36 --> Router Class Initialized
INFO - 2018-07-31 02:01:36 --> Output Class Initialized
INFO - 2018-07-31 02:01:36 --> Config Class Initialized
INFO - 2018-07-31 02:01:36 --> Hooks Class Initialized
INFO - 2018-07-31 02:01:36 --> Security Class Initialized
DEBUG - 2018-07-31 02:01:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-07-31 02:01:36 --> UTF-8 Support Enabled
INFO - 2018-07-31 02:01:36 --> Utf8 Class Initialized
INFO - 2018-07-31 02:01:36 --> Input Class Initialized
INFO - 2018-07-31 02:01:36 --> URI Class Initialized
INFO - 2018-07-31 02:01:36 --> Language Class Initialized
INFO - 2018-07-31 02:01:36 --> Router Class Initialized
INFO - 2018-07-31 02:01:36 --> Language Class Initialized
INFO - 2018-07-31 02:01:36 --> Config Class Initialized
INFO - 2018-07-31 02:01:36 --> Output Class Initialized
INFO - 2018-07-31 02:01:36 --> Loader Class Initialized
INFO - 2018-07-31 02:01:36 --> Security Class Initialized
DEBUG - 2018-07-31 02:01:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-07-31 02:01:36 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-31 02:01:36 --> Input Class Initialized
INFO - 2018-07-31 02:01:36 --> Language Class Initialized
ERROR - 2018-07-31 02:01:36 --> 404 Page Not Found: /index
INFO - 2018-07-31 02:01:36 --> Config Class Initialized
INFO - 2018-07-31 02:01:36 --> Helper loaded: url_helper
INFO - 2018-07-31 02:01:36 --> Hooks Class Initialized
DEBUG - 2018-07-31 02:01:36 --> UTF-8 Support Enabled
INFO - 2018-07-31 02:01:36 --> Helper loaded: form_helper
INFO - 2018-07-31 02:01:36 --> Utf8 Class Initialized
INFO - 2018-07-31 02:01:37 --> URI Class Initialized
INFO - 2018-07-31 02:01:37 --> Router Class Initialized
INFO - 2018-07-31 02:01:37 --> Helper loaded: date_helper
INFO - 2018-07-31 02:01:37 --> Output Class Initialized
INFO - 2018-07-31 02:01:37 --> Security Class Initialized
DEBUG - 2018-07-31 02:01:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 02:01:37 --> Input Class Initialized
INFO - 2018-07-31 02:01:37 --> Language Class Initialized
ERROR - 2018-07-31 02:01:37 --> 404 Page Not Found: /index
INFO - 2018-07-31 02:01:37 --> Helper loaded: util_helper
INFO - 2018-07-31 02:01:37 --> Config Class Initialized
INFO - 2018-07-31 02:01:37 --> Hooks Class Initialized
INFO - 2018-07-31 02:01:37 --> Helper loaded: text_helper
DEBUG - 2018-07-31 02:01:37 --> UTF-8 Support Enabled
INFO - 2018-07-31 02:01:37 --> Helper loaded: string_helper
INFO - 2018-07-31 02:01:37 --> Utf8 Class Initialized
INFO - 2018-07-31 02:01:37 --> URI Class Initialized
INFO - 2018-07-31 02:01:37 --> Database Driver Class Initialized
INFO - 2018-07-31 02:01:37 --> Router Class Initialized
DEBUG - 2018-07-31 02:01:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 02:01:37 --> Output Class Initialized
INFO - 2018-07-31 02:01:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 02:01:37 --> Security Class Initialized
DEBUG - 2018-07-31 02:01:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 02:01:37 --> Email Class Initialized
INFO - 2018-07-31 02:01:37 --> Input Class Initialized
INFO - 2018-07-31 02:01:37 --> Controller Class Initialized
INFO - 2018-07-31 02:01:37 --> Language Class Initialized
DEBUG - 2018-07-31 02:01:37 --> Home MX_Controller Initialized
ERROR - 2018-07-31 02:01:37 --> 404 Page Not Found: /index
DEBUG - 2018-07-31 02:01:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-31 02:01:37 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-31 02:01:37 --> Login MX_Controller Initialized
INFO - 2018-07-31 02:01:37 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-31 02:01:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-31 02:01:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-31 02:01:38 --> Config Class Initialized
INFO - 2018-07-31 02:01:38 --> Hooks Class Initialized
DEBUG - 2018-07-31 02:01:38 --> UTF-8 Support Enabled
INFO - 2018-07-31 02:01:38 --> Utf8 Class Initialized
INFO - 2018-07-31 02:01:38 --> URI Class Initialized
INFO - 2018-07-31 02:01:38 --> Router Class Initialized
INFO - 2018-07-31 02:01:38 --> Output Class Initialized
INFO - 2018-07-31 02:01:38 --> Security Class Initialized
DEBUG - 2018-07-31 02:01:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 02:01:38 --> Input Class Initialized
INFO - 2018-07-31 02:01:38 --> Language Class Initialized
INFO - 2018-07-31 02:01:38 --> Language Class Initialized
INFO - 2018-07-31 02:01:38 --> Config Class Initialized
INFO - 2018-07-31 02:01:38 --> Loader Class Initialized
DEBUG - 2018-07-31 02:01:38 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-31 02:01:38 --> Helper loaded: url_helper
INFO - 2018-07-31 02:01:38 --> Helper loaded: form_helper
INFO - 2018-07-31 02:01:38 --> Helper loaded: date_helper
INFO - 2018-07-31 02:01:38 --> Helper loaded: util_helper
INFO - 2018-07-31 02:01:38 --> Helper loaded: text_helper
INFO - 2018-07-31 02:01:38 --> Helper loaded: string_helper
INFO - 2018-07-31 02:01:38 --> Database Driver Class Initialized
DEBUG - 2018-07-31 02:01:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 02:01:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 02:01:38 --> Email Class Initialized
INFO - 2018-07-31 02:01:38 --> Controller Class Initialized
DEBUG - 2018-07-31 02:01:38 --> Home MX_Controller Initialized
DEBUG - 2018-07-31 02:01:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-31 02:01:38 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-31 02:01:38 --> Login MX_Controller Initialized
INFO - 2018-07-31 02:01:38 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-31 02:01:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-31 02:01:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-31 02:01:39 --> Config Class Initialized
INFO - 2018-07-31 02:01:39 --> Hooks Class Initialized
DEBUG - 2018-07-31 02:01:39 --> UTF-8 Support Enabled
INFO - 2018-07-31 02:01:39 --> Utf8 Class Initialized
INFO - 2018-07-31 02:01:39 --> URI Class Initialized
INFO - 2018-07-31 02:01:39 --> Router Class Initialized
INFO - 2018-07-31 02:01:39 --> Output Class Initialized
INFO - 2018-07-31 02:01:39 --> Security Class Initialized
DEBUG - 2018-07-31 02:01:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 02:01:39 --> Input Class Initialized
INFO - 2018-07-31 02:01:39 --> Language Class Initialized
INFO - 2018-07-31 02:01:39 --> Language Class Initialized
INFO - 2018-07-31 02:01:39 --> Config Class Initialized
INFO - 2018-07-31 02:01:39 --> Loader Class Initialized
DEBUG - 2018-07-31 02:01:39 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-31 02:01:39 --> Helper loaded: url_helper
INFO - 2018-07-31 02:01:39 --> Helper loaded: form_helper
INFO - 2018-07-31 02:01:39 --> Helper loaded: date_helper
INFO - 2018-07-31 02:01:39 --> Helper loaded: util_helper
INFO - 2018-07-31 02:01:39 --> Helper loaded: text_helper
INFO - 2018-07-31 02:01:39 --> Helper loaded: string_helper
INFO - 2018-07-31 02:01:39 --> Database Driver Class Initialized
DEBUG - 2018-07-31 02:01:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 02:01:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 02:01:39 --> Email Class Initialized
INFO - 2018-07-31 02:01:39 --> Controller Class Initialized
DEBUG - 2018-07-31 02:01:39 --> Home MX_Controller Initialized
DEBUG - 2018-07-31 02:01:39 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-31 02:01:39 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-31 02:01:39 --> Login MX_Controller Initialized
INFO - 2018-07-31 02:01:39 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-31 02:01:39 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-31 02:01:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-31 02:01:41 --> Config Class Initialized
INFO - 2018-07-31 02:01:41 --> Hooks Class Initialized
DEBUG - 2018-07-31 02:01:41 --> UTF-8 Support Enabled
INFO - 2018-07-31 02:01:41 --> Utf8 Class Initialized
INFO - 2018-07-31 02:01:41 --> URI Class Initialized
INFO - 2018-07-31 02:01:41 --> Router Class Initialized
INFO - 2018-07-31 02:01:41 --> Output Class Initialized
INFO - 2018-07-31 02:01:41 --> Security Class Initialized
DEBUG - 2018-07-31 02:01:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 02:01:41 --> Input Class Initialized
INFO - 2018-07-31 02:01:41 --> Language Class Initialized
INFO - 2018-07-31 02:01:41 --> Language Class Initialized
INFO - 2018-07-31 02:01:41 --> Config Class Initialized
INFO - 2018-07-31 02:01:41 --> Loader Class Initialized
DEBUG - 2018-07-31 02:01:41 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-31 02:01:41 --> Helper loaded: url_helper
INFO - 2018-07-31 02:01:41 --> Helper loaded: form_helper
INFO - 2018-07-31 02:01:41 --> Helper loaded: date_helper
INFO - 2018-07-31 02:01:41 --> Helper loaded: util_helper
INFO - 2018-07-31 02:01:41 --> Helper loaded: text_helper
INFO - 2018-07-31 02:01:41 --> Helper loaded: string_helper
INFO - 2018-07-31 02:01:41 --> Database Driver Class Initialized
DEBUG - 2018-07-31 02:01:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 02:01:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 02:01:41 --> Email Class Initialized
INFO - 2018-07-31 02:01:41 --> Controller Class Initialized
DEBUG - 2018-07-31 02:01:41 --> Home MX_Controller Initialized
DEBUG - 2018-07-31 02:01:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-31 02:01:41 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-31 02:01:41 --> Login MX_Controller Initialized
INFO - 2018-07-31 02:01:41 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-31 02:01:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-31 02:01:41 --> Config Class Initialized
INFO - 2018-07-31 02:01:41 --> Hooks Class Initialized
DEBUG - 2018-07-31 02:01:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-31 02:01:41 --> UTF-8 Support Enabled
INFO - 2018-07-31 02:01:41 --> Utf8 Class Initialized
INFO - 2018-07-31 02:01:41 --> URI Class Initialized
INFO - 2018-07-31 02:01:41 --> Router Class Initialized
INFO - 2018-07-31 02:01:41 --> Output Class Initialized
INFO - 2018-07-31 02:01:41 --> Security Class Initialized
DEBUG - 2018-07-31 02:01:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 02:01:41 --> Input Class Initialized
INFO - 2018-07-31 02:01:41 --> Language Class Initialized
ERROR - 2018-07-31 02:01:41 --> 404 Page Not Found: /index
INFO - 2018-07-31 02:01:41 --> Config Class Initialized
INFO - 2018-07-31 02:01:41 --> Hooks Class Initialized
DEBUG - 2018-07-31 02:01:41 --> UTF-8 Support Enabled
INFO - 2018-07-31 02:01:41 --> Utf8 Class Initialized
INFO - 2018-07-31 02:01:41 --> URI Class Initialized
INFO - 2018-07-31 02:01:41 --> Router Class Initialized
INFO - 2018-07-31 02:01:41 --> Output Class Initialized
INFO - 2018-07-31 02:01:41 --> Security Class Initialized
DEBUG - 2018-07-31 02:01:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 02:01:41 --> Input Class Initialized
INFO - 2018-07-31 02:01:41 --> Language Class Initialized
ERROR - 2018-07-31 02:01:41 --> 404 Page Not Found: /index
INFO - 2018-07-31 02:01:41 --> Config Class Initialized
INFO - 2018-07-31 02:01:41 --> Hooks Class Initialized
DEBUG - 2018-07-31 02:01:41 --> UTF-8 Support Enabled
INFO - 2018-07-31 02:01:41 --> Utf8 Class Initialized
INFO - 2018-07-31 02:01:41 --> URI Class Initialized
INFO - 2018-07-31 02:01:41 --> Router Class Initialized
INFO - 2018-07-31 02:01:41 --> Output Class Initialized
INFO - 2018-07-31 02:01:41 --> Security Class Initialized
DEBUG - 2018-07-31 02:01:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 02:01:41 --> Input Class Initialized
INFO - 2018-07-31 02:01:41 --> Language Class Initialized
ERROR - 2018-07-31 02:01:41 --> 404 Page Not Found: /index
INFO - 2018-07-31 02:01:41 --> Config Class Initialized
INFO - 2018-07-31 02:01:41 --> Hooks Class Initialized
DEBUG - 2018-07-31 02:01:41 --> UTF-8 Support Enabled
INFO - 2018-07-31 02:01:41 --> Utf8 Class Initialized
INFO - 2018-07-31 02:01:41 --> URI Class Initialized
INFO - 2018-07-31 02:01:41 --> Router Class Initialized
INFO - 2018-07-31 02:01:41 --> Output Class Initialized
INFO - 2018-07-31 02:01:42 --> Security Class Initialized
DEBUG - 2018-07-31 02:01:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 02:01:42 --> Input Class Initialized
INFO - 2018-07-31 02:01:42 --> Language Class Initialized
ERROR - 2018-07-31 02:01:42 --> 404 Page Not Found: /index
INFO - 2018-07-31 02:01:42 --> Config Class Initialized
INFO - 2018-07-31 02:01:42 --> Hooks Class Initialized
DEBUG - 2018-07-31 02:01:42 --> UTF-8 Support Enabled
INFO - 2018-07-31 02:01:42 --> Utf8 Class Initialized
INFO - 2018-07-31 02:01:42 --> URI Class Initialized
INFO - 2018-07-31 02:01:42 --> Router Class Initialized
INFO - 2018-07-31 02:01:42 --> Output Class Initialized
INFO - 2018-07-31 02:01:42 --> Security Class Initialized
DEBUG - 2018-07-31 02:01:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 02:01:42 --> Input Class Initialized
INFO - 2018-07-31 02:01:42 --> Language Class Initialized
ERROR - 2018-07-31 02:01:42 --> 404 Page Not Found: /index
INFO - 2018-07-31 02:01:42 --> Config Class Initialized
INFO - 2018-07-31 02:01:42 --> Hooks Class Initialized
DEBUG - 2018-07-31 02:01:42 --> UTF-8 Support Enabled
INFO - 2018-07-31 02:01:42 --> Utf8 Class Initialized
INFO - 2018-07-31 02:01:42 --> URI Class Initialized
INFO - 2018-07-31 02:01:42 --> Router Class Initialized
INFO - 2018-07-31 02:01:42 --> Output Class Initialized
INFO - 2018-07-31 02:01:42 --> Security Class Initialized
DEBUG - 2018-07-31 02:01:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 02:01:42 --> Input Class Initialized
INFO - 2018-07-31 02:01:42 --> Language Class Initialized
ERROR - 2018-07-31 02:01:42 --> 404 Page Not Found: /index
INFO - 2018-07-31 02:03:31 --> Config Class Initialized
INFO - 2018-07-31 02:03:31 --> Hooks Class Initialized
DEBUG - 2018-07-31 02:03:31 --> UTF-8 Support Enabled
INFO - 2018-07-31 02:03:31 --> Utf8 Class Initialized
INFO - 2018-07-31 02:03:31 --> Config Class Initialized
INFO - 2018-07-31 02:03:31 --> URI Class Initialized
INFO - 2018-07-31 02:03:31 --> Hooks Class Initialized
DEBUG - 2018-07-31 02:03:31 --> UTF-8 Support Enabled
INFO - 2018-07-31 02:03:31 --> Router Class Initialized
INFO - 2018-07-31 02:03:31 --> Utf8 Class Initialized
INFO - 2018-07-31 02:03:31 --> URI Class Initialized
INFO - 2018-07-31 02:03:31 --> Router Class Initialized
INFO - 2018-07-31 02:03:31 --> Output Class Initialized
INFO - 2018-07-31 02:03:31 --> Output Class Initialized
INFO - 2018-07-31 02:03:31 --> Security Class Initialized
DEBUG - 2018-07-31 02:03:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 02:03:31 --> Input Class Initialized
INFO - 2018-07-31 02:03:31 --> Security Class Initialized
INFO - 2018-07-31 02:03:31 --> Language Class Initialized
ERROR - 2018-07-31 02:03:31 --> 404 Page Not Found: /index
DEBUG - 2018-07-31 02:03:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 02:03:31 --> Config Class Initialized
INFO - 2018-07-31 02:03:31 --> Hooks Class Initialized
INFO - 2018-07-31 02:03:31 --> Input Class Initialized
DEBUG - 2018-07-31 02:03:31 --> UTF-8 Support Enabled
INFO - 2018-07-31 02:03:31 --> Language Class Initialized
INFO - 2018-07-31 02:03:31 --> Utf8 Class Initialized
INFO - 2018-07-31 02:03:31 --> URI Class Initialized
INFO - 2018-07-31 02:03:31 --> Router Class Initialized
INFO - 2018-07-31 02:03:31 --> Output Class Initialized
INFO - 2018-07-31 02:03:32 --> Security Class Initialized
DEBUG - 2018-07-31 02:03:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 02:03:32 --> Input Class Initialized
INFO - 2018-07-31 02:03:32 --> Language Class Initialized
ERROR - 2018-07-31 02:03:32 --> 404 Page Not Found: /index
INFO - 2018-07-31 02:03:32 --> Config Class Initialized
INFO - 2018-07-31 02:03:32 --> Hooks Class Initialized
INFO - 2018-07-31 02:03:32 --> Language Class Initialized
INFO - 2018-07-31 02:03:32 --> Config Class Initialized
DEBUG - 2018-07-31 02:03:32 --> UTF-8 Support Enabled
INFO - 2018-07-31 02:03:32 --> Utf8 Class Initialized
INFO - 2018-07-31 02:03:32 --> Loader Class Initialized
INFO - 2018-07-31 02:03:32 --> URI Class Initialized
INFO - 2018-07-31 02:03:32 --> Router Class Initialized
DEBUG - 2018-07-31 02:03:32 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-31 02:03:32 --> Output Class Initialized
INFO - 2018-07-31 02:03:32 --> Security Class Initialized
DEBUG - 2018-07-31 02:03:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 02:03:32 --> Input Class Initialized
INFO - 2018-07-31 02:03:32 --> Language Class Initialized
ERROR - 2018-07-31 02:03:32 --> 404 Page Not Found: /index
INFO - 2018-07-31 02:03:32 --> Helper loaded: url_helper
INFO - 2018-07-31 02:03:32 --> Helper loaded: form_helper
INFO - 2018-07-31 02:03:32 --> Helper loaded: date_helper
INFO - 2018-07-31 02:03:32 --> Helper loaded: util_helper
INFO - 2018-07-31 02:03:32 --> Helper loaded: text_helper
INFO - 2018-07-31 02:03:32 --> Helper loaded: string_helper
INFO - 2018-07-31 02:03:32 --> Database Driver Class Initialized
DEBUG - 2018-07-31 02:03:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 02:03:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 02:03:32 --> Email Class Initialized
INFO - 2018-07-31 02:03:32 --> Controller Class Initialized
DEBUG - 2018-07-31 02:03:32 --> Home MX_Controller Initialized
DEBUG - 2018-07-31 02:03:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-31 02:03:32 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-31 02:03:32 --> Login MX_Controller Initialized
INFO - 2018-07-31 02:03:32 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-31 02:03:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-31 02:03:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-31 02:03:33 --> Config Class Initialized
INFO - 2018-07-31 02:03:33 --> Hooks Class Initialized
DEBUG - 2018-07-31 02:03:33 --> UTF-8 Support Enabled
INFO - 2018-07-31 02:03:33 --> Utf8 Class Initialized
INFO - 2018-07-31 02:03:33 --> URI Class Initialized
INFO - 2018-07-31 02:03:33 --> Router Class Initialized
INFO - 2018-07-31 02:03:33 --> Output Class Initialized
INFO - 2018-07-31 02:03:33 --> Security Class Initialized
DEBUG - 2018-07-31 02:03:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 02:03:33 --> Input Class Initialized
INFO - 2018-07-31 02:03:33 --> Language Class Initialized
INFO - 2018-07-31 02:03:33 --> Language Class Initialized
INFO - 2018-07-31 02:03:33 --> Config Class Initialized
INFO - 2018-07-31 02:03:33 --> Loader Class Initialized
DEBUG - 2018-07-31 02:03:33 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-31 02:03:33 --> Helper loaded: url_helper
INFO - 2018-07-31 02:03:33 --> Helper loaded: form_helper
INFO - 2018-07-31 02:03:33 --> Helper loaded: date_helper
INFO - 2018-07-31 02:03:33 --> Helper loaded: util_helper
INFO - 2018-07-31 02:03:33 --> Helper loaded: text_helper
INFO - 2018-07-31 02:03:33 --> Helper loaded: string_helper
INFO - 2018-07-31 02:03:33 --> Database Driver Class Initialized
DEBUG - 2018-07-31 02:03:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 02:03:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 02:03:33 --> Email Class Initialized
INFO - 2018-07-31 02:03:33 --> Controller Class Initialized
DEBUG - 2018-07-31 02:03:33 --> Home MX_Controller Initialized
DEBUG - 2018-07-31 02:03:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-31 02:03:33 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-31 02:03:33 --> Login MX_Controller Initialized
INFO - 2018-07-31 02:03:33 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-31 02:03:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-31 02:03:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-31 02:15:21 --> Config Class Initialized
INFO - 2018-07-31 02:15:21 --> Hooks Class Initialized
DEBUG - 2018-07-31 02:15:21 --> UTF-8 Support Enabled
INFO - 2018-07-31 02:15:21 --> Utf8 Class Initialized
INFO - 2018-07-31 02:15:21 --> URI Class Initialized
INFO - 2018-07-31 02:15:21 --> Router Class Initialized
INFO - 2018-07-31 02:15:21 --> Output Class Initialized
INFO - 2018-07-31 02:15:21 --> Security Class Initialized
DEBUG - 2018-07-31 02:15:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 02:15:21 --> Input Class Initialized
INFO - 2018-07-31 02:15:21 --> Language Class Initialized
INFO - 2018-07-31 02:15:21 --> Language Class Initialized
INFO - 2018-07-31 02:15:21 --> Config Class Initialized
INFO - 2018-07-31 02:15:21 --> Loader Class Initialized
DEBUG - 2018-07-31 02:15:21 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-31 02:15:21 --> Helper loaded: url_helper
INFO - 2018-07-31 02:15:21 --> Helper loaded: form_helper
INFO - 2018-07-31 02:15:21 --> Helper loaded: date_helper
INFO - 2018-07-31 02:15:21 --> Helper loaded: util_helper
INFO - 2018-07-31 02:15:21 --> Helper loaded: text_helper
INFO - 2018-07-31 02:15:21 --> Helper loaded: string_helper
INFO - 2018-07-31 02:15:21 --> Database Driver Class Initialized
DEBUG - 2018-07-31 02:15:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 02:15:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 02:15:21 --> Email Class Initialized
INFO - 2018-07-31 02:15:21 --> Controller Class Initialized
DEBUG - 2018-07-31 02:15:21 --> Programs MX_Controller Initialized
INFO - 2018-07-31 02:15:21 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-31 02:15:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-07-31 02:15:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-31 02:15:21 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-31 02:15:21 --> Login MX_Controller Initialized
DEBUG - 2018-07-31 02:15:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-31 02:15:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-31 02:15:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-31 02:15:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-31 02:15:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-31 02:15:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-31 02:15:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/programs/create_program.php
INFO - 2018-07-31 02:15:21 --> Final output sent to browser
DEBUG - 2018-07-31 02:15:21 --> Total execution time: 0.6721
INFO - 2018-07-31 02:15:23 --> Config Class Initialized
INFO - 2018-07-31 02:15:23 --> Hooks Class Initialized
DEBUG - 2018-07-31 02:15:23 --> UTF-8 Support Enabled
INFO - 2018-07-31 02:15:23 --> Utf8 Class Initialized
INFO - 2018-07-31 02:15:23 --> URI Class Initialized
INFO - 2018-07-31 02:15:23 --> Router Class Initialized
INFO - 2018-07-31 02:15:23 --> Output Class Initialized
INFO - 2018-07-31 02:15:23 --> Security Class Initialized
DEBUG - 2018-07-31 02:15:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 02:15:23 --> Input Class Initialized
INFO - 2018-07-31 02:15:23 --> Language Class Initialized
ERROR - 2018-07-31 02:15:23 --> 404 Page Not Found: /index
INFO - 2018-07-31 02:23:51 --> Config Class Initialized
INFO - 2018-07-31 02:23:51 --> Hooks Class Initialized
DEBUG - 2018-07-31 02:23:51 --> UTF-8 Support Enabled
INFO - 2018-07-31 02:23:51 --> Utf8 Class Initialized
INFO - 2018-07-31 02:23:51 --> URI Class Initialized
INFO - 2018-07-31 02:23:51 --> Router Class Initialized
INFO - 2018-07-31 02:23:51 --> Output Class Initialized
INFO - 2018-07-31 02:23:51 --> Security Class Initialized
DEBUG - 2018-07-31 02:23:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 02:23:51 --> Input Class Initialized
INFO - 2018-07-31 02:23:51 --> Language Class Initialized
INFO - 2018-07-31 02:23:51 --> Language Class Initialized
INFO - 2018-07-31 02:23:51 --> Config Class Initialized
INFO - 2018-07-31 02:23:51 --> Loader Class Initialized
DEBUG - 2018-07-31 02:23:51 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-31 02:23:51 --> Helper loaded: url_helper
INFO - 2018-07-31 02:23:51 --> Helper loaded: form_helper
INFO - 2018-07-31 02:23:51 --> Helper loaded: date_helper
INFO - 2018-07-31 02:23:51 --> Helper loaded: util_helper
INFO - 2018-07-31 02:23:51 --> Helper loaded: text_helper
INFO - 2018-07-31 02:23:51 --> Helper loaded: string_helper
INFO - 2018-07-31 02:23:51 --> Database Driver Class Initialized
DEBUG - 2018-07-31 02:23:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 02:23:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 02:23:51 --> Email Class Initialized
INFO - 2018-07-31 02:23:51 --> Controller Class Initialized
DEBUG - 2018-07-31 02:23:51 --> Programs MX_Controller Initialized
INFO - 2018-07-31 02:23:51 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-31 02:23:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-07-31 02:23:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-31 02:23:51 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-31 02:23:51 --> Login MX_Controller Initialized
DEBUG - 2018-07-31 02:23:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-31 02:23:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-31 02:23:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-31 02:23:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-31 02:23:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-31 02:23:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-31 02:23:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/programs/create_program.php
INFO - 2018-07-31 02:23:51 --> Final output sent to browser
DEBUG - 2018-07-31 02:23:51 --> Total execution time: 0.5064
INFO - 2018-07-31 02:23:51 --> Config Class Initialized
INFO - 2018-07-31 02:23:51 --> Hooks Class Initialized
DEBUG - 2018-07-31 02:23:51 --> UTF-8 Support Enabled
INFO - 2018-07-31 02:23:51 --> Utf8 Class Initialized
INFO - 2018-07-31 02:23:51 --> URI Class Initialized
INFO - 2018-07-31 02:23:51 --> Router Class Initialized
INFO - 2018-07-31 02:23:51 --> Output Class Initialized
INFO - 2018-07-31 02:23:51 --> Security Class Initialized
DEBUG - 2018-07-31 02:23:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 02:23:51 --> Input Class Initialized
INFO - 2018-07-31 02:23:51 --> Language Class Initialized
ERROR - 2018-07-31 02:23:51 --> 404 Page Not Found: /index
INFO - 2018-07-31 02:23:52 --> Config Class Initialized
INFO - 2018-07-31 02:23:52 --> Hooks Class Initialized
DEBUG - 2018-07-31 02:23:52 --> UTF-8 Support Enabled
INFO - 2018-07-31 02:23:52 --> Utf8 Class Initialized
INFO - 2018-07-31 02:23:52 --> URI Class Initialized
INFO - 2018-07-31 02:23:52 --> Router Class Initialized
INFO - 2018-07-31 02:23:52 --> Output Class Initialized
INFO - 2018-07-31 02:23:52 --> Security Class Initialized
DEBUG - 2018-07-31 02:23:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 02:23:52 --> Input Class Initialized
INFO - 2018-07-31 02:23:52 --> Language Class Initialized
ERROR - 2018-07-31 02:23:52 --> 404 Page Not Found: /index
INFO - 2018-07-31 02:24:48 --> Config Class Initialized
INFO - 2018-07-31 02:24:48 --> Hooks Class Initialized
DEBUG - 2018-07-31 02:24:48 --> UTF-8 Support Enabled
INFO - 2018-07-31 02:24:48 --> Utf8 Class Initialized
INFO - 2018-07-31 02:24:48 --> URI Class Initialized
INFO - 2018-07-31 02:24:48 --> Router Class Initialized
INFO - 2018-07-31 02:24:48 --> Output Class Initialized
INFO - 2018-07-31 02:24:48 --> Security Class Initialized
DEBUG - 2018-07-31 02:24:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 02:24:48 --> Input Class Initialized
INFO - 2018-07-31 02:24:48 --> Language Class Initialized
INFO - 2018-07-31 02:24:48 --> Language Class Initialized
INFO - 2018-07-31 02:24:48 --> Config Class Initialized
INFO - 2018-07-31 02:24:48 --> Loader Class Initialized
DEBUG - 2018-07-31 02:24:48 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-31 02:24:49 --> Helper loaded: url_helper
INFO - 2018-07-31 02:24:49 --> Helper loaded: form_helper
INFO - 2018-07-31 02:24:49 --> Helper loaded: date_helper
INFO - 2018-07-31 02:24:49 --> Helper loaded: util_helper
INFO - 2018-07-31 02:24:49 --> Helper loaded: text_helper
INFO - 2018-07-31 02:24:49 --> Helper loaded: string_helper
INFO - 2018-07-31 02:24:49 --> Database Driver Class Initialized
DEBUG - 2018-07-31 02:24:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 02:24:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 02:24:49 --> Email Class Initialized
INFO - 2018-07-31 02:24:49 --> Controller Class Initialized
DEBUG - 2018-07-31 02:24:49 --> Programs MX_Controller Initialized
INFO - 2018-07-31 02:24:49 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-31 02:24:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-07-31 02:24:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-31 02:24:49 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-31 02:24:49 --> Login MX_Controller Initialized
DEBUG - 2018-07-31 02:24:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-31 02:24:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-31 02:24:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-31 02:24:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-31 02:24:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-31 02:24:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-31 02:24:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/programs/create_program.php
INFO - 2018-07-31 02:24:49 --> Final output sent to browser
DEBUG - 2018-07-31 02:24:49 --> Total execution time: 0.4859
INFO - 2018-07-31 02:24:50 --> Config Class Initialized
INFO - 2018-07-31 02:24:50 --> Hooks Class Initialized
DEBUG - 2018-07-31 02:24:50 --> UTF-8 Support Enabled
INFO - 2018-07-31 02:24:50 --> Utf8 Class Initialized
INFO - 2018-07-31 02:24:50 --> URI Class Initialized
INFO - 2018-07-31 02:24:50 --> Router Class Initialized
INFO - 2018-07-31 02:24:50 --> Output Class Initialized
INFO - 2018-07-31 02:24:50 --> Security Class Initialized
DEBUG - 2018-07-31 02:24:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 02:24:50 --> Input Class Initialized
INFO - 2018-07-31 02:24:50 --> Language Class Initialized
ERROR - 2018-07-31 02:24:50 --> 404 Page Not Found: /index
INFO - 2018-07-31 02:25:08 --> Config Class Initialized
INFO - 2018-07-31 02:25:08 --> Hooks Class Initialized
DEBUG - 2018-07-31 02:25:08 --> UTF-8 Support Enabled
INFO - 2018-07-31 02:25:08 --> Utf8 Class Initialized
INFO - 2018-07-31 02:25:08 --> URI Class Initialized
INFO - 2018-07-31 02:25:08 --> Router Class Initialized
INFO - 2018-07-31 02:25:08 --> Output Class Initialized
INFO - 2018-07-31 02:25:08 --> Security Class Initialized
DEBUG - 2018-07-31 02:25:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 02:25:08 --> Input Class Initialized
INFO - 2018-07-31 02:25:08 --> Language Class Initialized
INFO - 2018-07-31 02:25:08 --> Language Class Initialized
INFO - 2018-07-31 02:25:08 --> Config Class Initialized
INFO - 2018-07-31 02:25:08 --> Loader Class Initialized
DEBUG - 2018-07-31 02:25:08 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-31 02:25:08 --> Helper loaded: url_helper
INFO - 2018-07-31 02:25:08 --> Helper loaded: form_helper
INFO - 2018-07-31 02:25:08 --> Helper loaded: date_helper
INFO - 2018-07-31 02:25:08 --> Helper loaded: util_helper
INFO - 2018-07-31 02:25:08 --> Helper loaded: text_helper
INFO - 2018-07-31 02:25:08 --> Helper loaded: string_helper
INFO - 2018-07-31 02:25:08 --> Database Driver Class Initialized
DEBUG - 2018-07-31 02:25:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 02:25:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 02:25:08 --> Email Class Initialized
INFO - 2018-07-31 02:25:08 --> Controller Class Initialized
DEBUG - 2018-07-31 02:25:08 --> Programs MX_Controller Initialized
INFO - 2018-07-31 02:25:08 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-31 02:25:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-07-31 02:25:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-31 02:25:08 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-31 02:25:08 --> Login MX_Controller Initialized
DEBUG - 2018-07-31 02:25:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-31 02:25:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-31 02:25:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-31 02:25:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-31 02:25:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-31 02:25:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-31 02:25:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/programs/create_program.php
INFO - 2018-07-31 02:25:08 --> Final output sent to browser
DEBUG - 2018-07-31 02:25:08 --> Total execution time: 0.4878
INFO - 2018-07-31 02:25:09 --> Config Class Initialized
INFO - 2018-07-31 02:25:09 --> Hooks Class Initialized
DEBUG - 2018-07-31 02:25:09 --> UTF-8 Support Enabled
INFO - 2018-07-31 02:25:09 --> Utf8 Class Initialized
INFO - 2018-07-31 02:25:09 --> URI Class Initialized
INFO - 2018-07-31 02:25:09 --> Router Class Initialized
INFO - 2018-07-31 02:25:09 --> Output Class Initialized
INFO - 2018-07-31 02:25:09 --> Security Class Initialized
DEBUG - 2018-07-31 02:25:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 02:25:09 --> Input Class Initialized
INFO - 2018-07-31 02:25:09 --> Language Class Initialized
ERROR - 2018-07-31 02:25:09 --> 404 Page Not Found: /index
INFO - 2018-07-31 02:25:22 --> Config Class Initialized
INFO - 2018-07-31 02:25:22 --> Hooks Class Initialized
DEBUG - 2018-07-31 02:25:22 --> UTF-8 Support Enabled
INFO - 2018-07-31 02:25:22 --> Utf8 Class Initialized
INFO - 2018-07-31 02:25:22 --> URI Class Initialized
INFO - 2018-07-31 02:25:22 --> Router Class Initialized
INFO - 2018-07-31 02:25:22 --> Output Class Initialized
INFO - 2018-07-31 02:25:22 --> Security Class Initialized
DEBUG - 2018-07-31 02:25:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 02:25:22 --> Input Class Initialized
INFO - 2018-07-31 02:25:22 --> Language Class Initialized
INFO - 2018-07-31 02:25:22 --> Language Class Initialized
INFO - 2018-07-31 02:25:22 --> Config Class Initialized
INFO - 2018-07-31 02:25:22 --> Loader Class Initialized
DEBUG - 2018-07-31 02:25:22 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-31 02:25:22 --> Helper loaded: url_helper
INFO - 2018-07-31 02:25:22 --> Helper loaded: form_helper
INFO - 2018-07-31 02:25:22 --> Helper loaded: date_helper
INFO - 2018-07-31 02:25:22 --> Helper loaded: util_helper
INFO - 2018-07-31 02:25:22 --> Helper loaded: text_helper
INFO - 2018-07-31 02:25:22 --> Helper loaded: string_helper
INFO - 2018-07-31 02:25:22 --> Database Driver Class Initialized
DEBUG - 2018-07-31 02:25:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 02:25:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 02:25:22 --> Email Class Initialized
INFO - 2018-07-31 02:25:22 --> Controller Class Initialized
DEBUG - 2018-07-31 02:25:22 --> Programs MX_Controller Initialized
INFO - 2018-07-31 02:25:22 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-31 02:25:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-07-31 02:25:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-31 02:25:22 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-31 02:25:22 --> Login MX_Controller Initialized
DEBUG - 2018-07-31 02:25:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-31 02:25:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-31 02:25:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-31 02:25:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-31 02:25:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-31 02:25:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-31 02:25:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/programs/create_program.php
INFO - 2018-07-31 02:25:22 --> Final output sent to browser
DEBUG - 2018-07-31 02:25:22 --> Total execution time: 0.5001
INFO - 2018-07-31 02:25:23 --> Config Class Initialized
INFO - 2018-07-31 02:25:23 --> Hooks Class Initialized
DEBUG - 2018-07-31 02:25:23 --> UTF-8 Support Enabled
INFO - 2018-07-31 02:25:23 --> Utf8 Class Initialized
INFO - 2018-07-31 02:25:24 --> URI Class Initialized
INFO - 2018-07-31 02:25:24 --> Router Class Initialized
INFO - 2018-07-31 02:25:24 --> Output Class Initialized
INFO - 2018-07-31 02:25:24 --> Security Class Initialized
DEBUG - 2018-07-31 02:25:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 02:25:24 --> Input Class Initialized
INFO - 2018-07-31 02:25:24 --> Language Class Initialized
ERROR - 2018-07-31 02:25:24 --> 404 Page Not Found: /index
INFO - 2018-07-31 02:26:33 --> Config Class Initialized
INFO - 2018-07-31 02:26:33 --> Hooks Class Initialized
DEBUG - 2018-07-31 02:26:33 --> UTF-8 Support Enabled
INFO - 2018-07-31 02:26:33 --> Utf8 Class Initialized
INFO - 2018-07-31 02:26:33 --> URI Class Initialized
INFO - 2018-07-31 02:26:33 --> Router Class Initialized
INFO - 2018-07-31 02:26:33 --> Output Class Initialized
INFO - 2018-07-31 02:26:33 --> Security Class Initialized
DEBUG - 2018-07-31 02:26:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 02:26:33 --> Input Class Initialized
INFO - 2018-07-31 02:26:33 --> Language Class Initialized
INFO - 2018-07-31 02:26:33 --> Language Class Initialized
INFO - 2018-07-31 02:26:33 --> Config Class Initialized
INFO - 2018-07-31 02:26:33 --> Loader Class Initialized
DEBUG - 2018-07-31 02:26:33 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-31 02:26:33 --> Helper loaded: url_helper
INFO - 2018-07-31 02:26:33 --> Helper loaded: form_helper
INFO - 2018-07-31 02:26:33 --> Helper loaded: date_helper
INFO - 2018-07-31 02:26:33 --> Helper loaded: util_helper
INFO - 2018-07-31 02:26:33 --> Helper loaded: text_helper
INFO - 2018-07-31 02:26:33 --> Helper loaded: string_helper
INFO - 2018-07-31 02:26:33 --> Database Driver Class Initialized
DEBUG - 2018-07-31 02:26:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 02:26:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 02:26:33 --> Email Class Initialized
INFO - 2018-07-31 02:26:33 --> Controller Class Initialized
DEBUG - 2018-07-31 02:26:33 --> Programs MX_Controller Initialized
INFO - 2018-07-31 02:26:33 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-31 02:26:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-07-31 02:26:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-31 02:26:33 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-31 02:26:33 --> Login MX_Controller Initialized
DEBUG - 2018-07-31 02:26:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-31 02:26:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
ERROR - 2018-07-31 02:26:33 --> Severity: Notice --> Undefined index: prg_img_vid_name E:\xampp\htdocs\consulting\application\modules\admin\controllers\Programs.php 169
INFO - 2018-07-31 02:27:18 --> Config Class Initialized
INFO - 2018-07-31 02:27:18 --> Hooks Class Initialized
DEBUG - 2018-07-31 02:27:18 --> UTF-8 Support Enabled
INFO - 2018-07-31 02:27:18 --> Utf8 Class Initialized
INFO - 2018-07-31 02:27:18 --> URI Class Initialized
INFO - 2018-07-31 02:27:18 --> Router Class Initialized
INFO - 2018-07-31 02:27:18 --> Output Class Initialized
INFO - 2018-07-31 02:27:18 --> Security Class Initialized
DEBUG - 2018-07-31 02:27:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 02:27:18 --> Input Class Initialized
INFO - 2018-07-31 02:27:18 --> Language Class Initialized
INFO - 2018-07-31 02:27:18 --> Language Class Initialized
INFO - 2018-07-31 02:27:18 --> Config Class Initialized
INFO - 2018-07-31 02:27:18 --> Loader Class Initialized
DEBUG - 2018-07-31 02:27:18 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-31 02:27:18 --> Helper loaded: url_helper
INFO - 2018-07-31 02:27:18 --> Helper loaded: form_helper
INFO - 2018-07-31 02:27:18 --> Helper loaded: date_helper
INFO - 2018-07-31 02:27:18 --> Helper loaded: util_helper
INFO - 2018-07-31 02:27:18 --> Helper loaded: text_helper
INFO - 2018-07-31 02:27:18 --> Helper loaded: string_helper
INFO - 2018-07-31 02:27:18 --> Database Driver Class Initialized
DEBUG - 2018-07-31 02:27:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 02:27:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 02:27:18 --> Email Class Initialized
INFO - 2018-07-31 02:27:18 --> Controller Class Initialized
DEBUG - 2018-07-31 02:27:18 --> Programs MX_Controller Initialized
INFO - 2018-07-31 02:27:19 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-31 02:27:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-07-31 02:27:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-31 02:27:19 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-31 02:27:19 --> Login MX_Controller Initialized
DEBUG - 2018-07-31 02:27:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-31 02:27:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
INFO - 2018-07-31 02:27:19 --> Config Class Initialized
INFO - 2018-07-31 02:27:19 --> Hooks Class Initialized
DEBUG - 2018-07-31 02:27:19 --> UTF-8 Support Enabled
INFO - 2018-07-31 02:27:19 --> Utf8 Class Initialized
INFO - 2018-07-31 02:27:19 --> URI Class Initialized
INFO - 2018-07-31 02:27:19 --> Router Class Initialized
INFO - 2018-07-31 02:27:19 --> Output Class Initialized
INFO - 2018-07-31 02:27:19 --> Security Class Initialized
DEBUG - 2018-07-31 02:27:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 02:27:19 --> Input Class Initialized
INFO - 2018-07-31 02:27:19 --> Language Class Initialized
INFO - 2018-07-31 02:27:19 --> Language Class Initialized
INFO - 2018-07-31 02:27:19 --> Config Class Initialized
INFO - 2018-07-31 02:27:19 --> Loader Class Initialized
DEBUG - 2018-07-31 02:27:19 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-31 02:27:19 --> Helper loaded: url_helper
INFO - 2018-07-31 02:27:19 --> Helper loaded: form_helper
INFO - 2018-07-31 02:27:19 --> Helper loaded: date_helper
INFO - 2018-07-31 02:27:19 --> Helper loaded: util_helper
INFO - 2018-07-31 02:27:19 --> Helper loaded: text_helper
INFO - 2018-07-31 02:27:19 --> Helper loaded: string_helper
INFO - 2018-07-31 02:27:19 --> Database Driver Class Initialized
DEBUG - 2018-07-31 02:27:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 02:27:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 02:27:19 --> Email Class Initialized
INFO - 2018-07-31 02:27:19 --> Controller Class Initialized
DEBUG - 2018-07-31 02:27:19 --> Programs MX_Controller Initialized
INFO - 2018-07-31 02:27:19 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-31 02:27:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-07-31 02:27:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-31 02:27:19 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-31 02:27:19 --> Login MX_Controller Initialized
DEBUG - 2018-07-31 02:27:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-31 02:27:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-31 02:27:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-31 02:27:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-31 02:27:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-31 02:27:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-31 02:27:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/programs/programs.php
INFO - 2018-07-31 02:27:19 --> Final output sent to browser
DEBUG - 2018-07-31 02:27:20 --> Total execution time: 0.7934
INFO - 2018-07-31 02:27:20 --> Config Class Initialized
INFO - 2018-07-31 02:27:20 --> Hooks Class Initialized
DEBUG - 2018-07-31 02:27:20 --> UTF-8 Support Enabled
INFO - 2018-07-31 02:27:20 --> Utf8 Class Initialized
INFO - 2018-07-31 02:27:21 --> URI Class Initialized
INFO - 2018-07-31 02:27:21 --> Router Class Initialized
INFO - 2018-07-31 02:27:21 --> Output Class Initialized
INFO - 2018-07-31 02:27:21 --> Security Class Initialized
DEBUG - 2018-07-31 02:27:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 02:27:21 --> Input Class Initialized
INFO - 2018-07-31 02:27:21 --> Language Class Initialized
INFO - 2018-07-31 02:27:21 --> Language Class Initialized
INFO - 2018-07-31 02:27:21 --> Config Class Initialized
INFO - 2018-07-31 02:27:21 --> Loader Class Initialized
DEBUG - 2018-07-31 02:27:21 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-31 02:27:21 --> Helper loaded: url_helper
INFO - 2018-07-31 02:27:21 --> Helper loaded: form_helper
INFO - 2018-07-31 02:27:21 --> Helper loaded: date_helper
INFO - 2018-07-31 02:27:21 --> Helper loaded: util_helper
INFO - 2018-07-31 02:27:21 --> Helper loaded: text_helper
INFO - 2018-07-31 02:27:21 --> Helper loaded: string_helper
INFO - 2018-07-31 02:27:21 --> Database Driver Class Initialized
DEBUG - 2018-07-31 02:27:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 02:27:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 02:27:21 --> Email Class Initialized
INFO - 2018-07-31 02:27:21 --> Controller Class Initialized
DEBUG - 2018-07-31 02:27:21 --> Programs MX_Controller Initialized
INFO - 2018-07-31 02:27:21 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-31 02:27:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-07-31 02:27:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-31 02:27:21 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-31 02:27:21 --> Login MX_Controller Initialized
DEBUG - 2018-07-31 02:27:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-31 02:27:21 --> Final output sent to browser
DEBUG - 2018-07-31 02:27:21 --> Total execution time: 0.6549
INFO - 2018-07-31 02:27:23 --> Config Class Initialized
INFO - 2018-07-31 02:27:23 --> Hooks Class Initialized
DEBUG - 2018-07-31 02:27:23 --> UTF-8 Support Enabled
INFO - 2018-07-31 02:27:23 --> Utf8 Class Initialized
INFO - 2018-07-31 02:27:23 --> URI Class Initialized
INFO - 2018-07-31 02:27:23 --> Router Class Initialized
INFO - 2018-07-31 02:27:23 --> Output Class Initialized
INFO - 2018-07-31 02:27:23 --> Security Class Initialized
DEBUG - 2018-07-31 02:27:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 02:27:23 --> Input Class Initialized
INFO - 2018-07-31 02:27:23 --> Language Class Initialized
INFO - 2018-07-31 02:27:23 --> Language Class Initialized
INFO - 2018-07-31 02:27:23 --> Config Class Initialized
INFO - 2018-07-31 02:27:23 --> Loader Class Initialized
DEBUG - 2018-07-31 02:27:23 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-31 02:27:23 --> Helper loaded: url_helper
INFO - 2018-07-31 02:27:23 --> Helper loaded: form_helper
INFO - 2018-07-31 02:27:23 --> Helper loaded: date_helper
INFO - 2018-07-31 02:27:23 --> Helper loaded: util_helper
INFO - 2018-07-31 02:27:24 --> Helper loaded: text_helper
INFO - 2018-07-31 02:27:24 --> Helper loaded: string_helper
INFO - 2018-07-31 02:27:24 --> Database Driver Class Initialized
DEBUG - 2018-07-31 02:27:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 02:27:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 02:27:24 --> Email Class Initialized
INFO - 2018-07-31 02:27:24 --> Controller Class Initialized
DEBUG - 2018-07-31 02:27:24 --> Programs MX_Controller Initialized
INFO - 2018-07-31 02:27:24 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-31 02:27:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-07-31 02:27:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-31 02:27:24 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-31 02:27:24 --> Login MX_Controller Initialized
DEBUG - 2018-07-31 02:27:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-31 02:27:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-31 02:27:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-31 02:27:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-31 02:27:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-31 02:27:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-31 02:27:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/programs/create_program.php
INFO - 2018-07-31 02:27:24 --> Final output sent to browser
DEBUG - 2018-07-31 02:27:24 --> Total execution time: 0.6425
INFO - 2018-07-31 02:27:25 --> Config Class Initialized
INFO - 2018-07-31 02:27:25 --> Hooks Class Initialized
DEBUG - 2018-07-31 02:27:25 --> UTF-8 Support Enabled
INFO - 2018-07-31 02:27:25 --> Utf8 Class Initialized
INFO - 2018-07-31 02:27:25 --> URI Class Initialized
INFO - 2018-07-31 02:27:25 --> Router Class Initialized
INFO - 2018-07-31 02:27:25 --> Output Class Initialized
INFO - 2018-07-31 02:27:25 --> Security Class Initialized
DEBUG - 2018-07-31 02:27:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 02:27:25 --> Input Class Initialized
INFO - 2018-07-31 02:27:25 --> Language Class Initialized
ERROR - 2018-07-31 02:27:25 --> 404 Page Not Found: /index
INFO - 2018-07-31 02:27:33 --> Config Class Initialized
INFO - 2018-07-31 02:27:33 --> Hooks Class Initialized
DEBUG - 2018-07-31 02:27:33 --> UTF-8 Support Enabled
INFO - 2018-07-31 02:27:33 --> Utf8 Class Initialized
INFO - 2018-07-31 02:27:33 --> URI Class Initialized
INFO - 2018-07-31 02:27:33 --> Router Class Initialized
INFO - 2018-07-31 02:27:33 --> Output Class Initialized
INFO - 2018-07-31 02:27:33 --> Security Class Initialized
DEBUG - 2018-07-31 02:27:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 02:27:33 --> Input Class Initialized
INFO - 2018-07-31 02:27:33 --> Language Class Initialized
INFO - 2018-07-31 02:27:34 --> Language Class Initialized
INFO - 2018-07-31 02:27:34 --> Config Class Initialized
INFO - 2018-07-31 02:27:34 --> Loader Class Initialized
DEBUG - 2018-07-31 02:27:34 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-31 02:27:34 --> Helper loaded: url_helper
INFO - 2018-07-31 02:27:34 --> Helper loaded: form_helper
INFO - 2018-07-31 02:27:34 --> Helper loaded: date_helper
INFO - 2018-07-31 02:27:34 --> Helper loaded: util_helper
INFO - 2018-07-31 02:27:34 --> Helper loaded: text_helper
INFO - 2018-07-31 02:27:34 --> Helper loaded: string_helper
INFO - 2018-07-31 02:27:34 --> Database Driver Class Initialized
DEBUG - 2018-07-31 02:27:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 02:27:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 02:27:34 --> Email Class Initialized
INFO - 2018-07-31 02:27:34 --> Controller Class Initialized
DEBUG - 2018-07-31 02:27:34 --> Programs MX_Controller Initialized
INFO - 2018-07-31 02:27:34 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-31 02:27:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-07-31 02:27:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-31 02:27:34 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-31 02:27:34 --> Login MX_Controller Initialized
DEBUG - 2018-07-31 02:27:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-31 02:27:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
INFO - 2018-07-31 02:27:34 --> Config Class Initialized
INFO - 2018-07-31 02:27:34 --> Hooks Class Initialized
DEBUG - 2018-07-31 02:27:34 --> UTF-8 Support Enabled
INFO - 2018-07-31 02:27:34 --> Utf8 Class Initialized
INFO - 2018-07-31 02:27:34 --> URI Class Initialized
INFO - 2018-07-31 02:27:34 --> Router Class Initialized
INFO - 2018-07-31 02:27:34 --> Output Class Initialized
INFO - 2018-07-31 02:27:34 --> Security Class Initialized
DEBUG - 2018-07-31 02:27:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 02:27:34 --> Input Class Initialized
INFO - 2018-07-31 02:27:34 --> Language Class Initialized
INFO - 2018-07-31 02:27:34 --> Language Class Initialized
INFO - 2018-07-31 02:27:34 --> Config Class Initialized
INFO - 2018-07-31 02:27:34 --> Loader Class Initialized
DEBUG - 2018-07-31 02:27:34 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-31 02:27:34 --> Helper loaded: url_helper
INFO - 2018-07-31 02:27:34 --> Helper loaded: form_helper
INFO - 2018-07-31 02:27:34 --> Helper loaded: date_helper
INFO - 2018-07-31 02:27:34 --> Helper loaded: util_helper
INFO - 2018-07-31 02:27:34 --> Helper loaded: text_helper
INFO - 2018-07-31 02:27:34 --> Helper loaded: string_helper
INFO - 2018-07-31 02:27:34 --> Database Driver Class Initialized
DEBUG - 2018-07-31 02:27:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 02:27:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 02:27:34 --> Email Class Initialized
INFO - 2018-07-31 02:27:34 --> Controller Class Initialized
DEBUG - 2018-07-31 02:27:34 --> Programs MX_Controller Initialized
INFO - 2018-07-31 02:27:34 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-31 02:27:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-07-31 02:27:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-31 02:27:34 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-31 02:27:34 --> Login MX_Controller Initialized
DEBUG - 2018-07-31 02:27:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-31 02:27:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-31 02:27:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-31 02:27:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-31 02:27:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-31 02:27:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-31 02:27:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/programs/programs.php
INFO - 2018-07-31 02:27:34 --> Final output sent to browser
DEBUG - 2018-07-31 02:27:35 --> Total execution time: 0.5749
INFO - 2018-07-31 02:27:35 --> Config Class Initialized
INFO - 2018-07-31 02:27:35 --> Hooks Class Initialized
DEBUG - 2018-07-31 02:27:35 --> UTF-8 Support Enabled
INFO - 2018-07-31 02:27:35 --> Utf8 Class Initialized
INFO - 2018-07-31 02:27:35 --> URI Class Initialized
INFO - 2018-07-31 02:27:35 --> Router Class Initialized
INFO - 2018-07-31 02:27:35 --> Output Class Initialized
INFO - 2018-07-31 02:27:35 --> Security Class Initialized
DEBUG - 2018-07-31 02:27:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 02:27:36 --> Input Class Initialized
INFO - 2018-07-31 02:27:36 --> Language Class Initialized
INFO - 2018-07-31 02:27:36 --> Language Class Initialized
INFO - 2018-07-31 02:27:36 --> Config Class Initialized
INFO - 2018-07-31 02:27:36 --> Loader Class Initialized
DEBUG - 2018-07-31 02:27:36 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-31 02:27:36 --> Helper loaded: url_helper
INFO - 2018-07-31 02:27:36 --> Helper loaded: form_helper
INFO - 2018-07-31 02:27:36 --> Helper loaded: date_helper
INFO - 2018-07-31 02:27:36 --> Helper loaded: util_helper
INFO - 2018-07-31 02:27:36 --> Helper loaded: text_helper
INFO - 2018-07-31 02:27:36 --> Helper loaded: string_helper
INFO - 2018-07-31 02:27:36 --> Database Driver Class Initialized
DEBUG - 2018-07-31 02:27:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 02:27:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 02:27:36 --> Email Class Initialized
INFO - 2018-07-31 02:27:36 --> Controller Class Initialized
DEBUG - 2018-07-31 02:27:36 --> Programs MX_Controller Initialized
INFO - 2018-07-31 02:27:36 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-31 02:27:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-07-31 02:27:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-31 02:27:36 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-31 02:27:36 --> Login MX_Controller Initialized
DEBUG - 2018-07-31 02:27:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-31 02:27:36 --> Final output sent to browser
DEBUG - 2018-07-31 02:27:36 --> Total execution time: 0.9040
INFO - 2018-07-31 02:27:43 --> Config Class Initialized
INFO - 2018-07-31 02:27:43 --> Hooks Class Initialized
DEBUG - 2018-07-31 02:27:43 --> UTF-8 Support Enabled
INFO - 2018-07-31 02:27:43 --> Utf8 Class Initialized
INFO - 2018-07-31 02:27:43 --> URI Class Initialized
INFO - 2018-07-31 02:27:43 --> Router Class Initialized
INFO - 2018-07-31 02:27:43 --> Output Class Initialized
INFO - 2018-07-31 02:27:43 --> Security Class Initialized
DEBUG - 2018-07-31 02:27:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 02:27:43 --> Input Class Initialized
INFO - 2018-07-31 02:27:43 --> Language Class Initialized
INFO - 2018-07-31 02:27:43 --> Language Class Initialized
INFO - 2018-07-31 02:27:43 --> Config Class Initialized
INFO - 2018-07-31 02:27:43 --> Loader Class Initialized
DEBUG - 2018-07-31 02:27:43 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-31 02:27:43 --> Helper loaded: url_helper
INFO - 2018-07-31 02:27:43 --> Helper loaded: form_helper
INFO - 2018-07-31 02:27:43 --> Helper loaded: date_helper
INFO - 2018-07-31 02:27:43 --> Helper loaded: util_helper
INFO - 2018-07-31 02:27:43 --> Helper loaded: text_helper
INFO - 2018-07-31 02:27:43 --> Helper loaded: string_helper
INFO - 2018-07-31 02:27:43 --> Database Driver Class Initialized
DEBUG - 2018-07-31 02:27:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 02:27:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 02:27:43 --> Email Class Initialized
INFO - 2018-07-31 02:27:43 --> Controller Class Initialized
DEBUG - 2018-07-31 02:27:43 --> Programs MX_Controller Initialized
INFO - 2018-07-31 02:27:43 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-31 02:27:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-07-31 02:27:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-31 02:27:43 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-31 02:27:43 --> Login MX_Controller Initialized
DEBUG - 2018-07-31 02:27:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-31 02:27:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-31 02:27:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-31 02:27:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-31 02:27:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-31 02:27:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-31 02:27:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/programs/create_program.php
INFO - 2018-07-31 02:27:44 --> Final output sent to browser
DEBUG - 2018-07-31 02:27:44 --> Total execution time: 0.6070
INFO - 2018-07-31 02:27:44 --> Config Class Initialized
INFO - 2018-07-31 02:27:44 --> Hooks Class Initialized
DEBUG - 2018-07-31 02:27:45 --> UTF-8 Support Enabled
INFO - 2018-07-31 02:27:45 --> Utf8 Class Initialized
INFO - 2018-07-31 02:27:45 --> URI Class Initialized
INFO - 2018-07-31 02:27:45 --> Router Class Initialized
INFO - 2018-07-31 02:27:45 --> Output Class Initialized
INFO - 2018-07-31 02:27:45 --> Security Class Initialized
DEBUG - 2018-07-31 02:27:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 02:27:45 --> Input Class Initialized
INFO - 2018-07-31 02:27:45 --> Language Class Initialized
ERROR - 2018-07-31 02:27:45 --> 404 Page Not Found: /index
INFO - 2018-07-31 02:28:31 --> Config Class Initialized
INFO - 2018-07-31 02:28:31 --> Hooks Class Initialized
DEBUG - 2018-07-31 02:28:31 --> UTF-8 Support Enabled
INFO - 2018-07-31 02:28:31 --> Utf8 Class Initialized
INFO - 2018-07-31 02:28:31 --> URI Class Initialized
INFO - 2018-07-31 02:28:31 --> Router Class Initialized
INFO - 2018-07-31 02:28:31 --> Output Class Initialized
INFO - 2018-07-31 02:28:31 --> Security Class Initialized
DEBUG - 2018-07-31 02:28:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 02:28:31 --> Input Class Initialized
INFO - 2018-07-31 02:28:31 --> Language Class Initialized
INFO - 2018-07-31 02:28:31 --> Language Class Initialized
INFO - 2018-07-31 02:28:31 --> Config Class Initialized
INFO - 2018-07-31 02:28:31 --> Loader Class Initialized
DEBUG - 2018-07-31 02:28:31 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-31 02:28:31 --> Helper loaded: url_helper
INFO - 2018-07-31 02:28:31 --> Helper loaded: form_helper
INFO - 2018-07-31 02:28:31 --> Helper loaded: date_helper
INFO - 2018-07-31 02:28:31 --> Helper loaded: util_helper
INFO - 2018-07-31 02:28:31 --> Helper loaded: text_helper
INFO - 2018-07-31 02:28:31 --> Helper loaded: string_helper
INFO - 2018-07-31 02:28:31 --> Database Driver Class Initialized
DEBUG - 2018-07-31 02:28:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 02:28:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 02:28:31 --> Email Class Initialized
INFO - 2018-07-31 02:28:31 --> Controller Class Initialized
DEBUG - 2018-07-31 02:28:31 --> Programs MX_Controller Initialized
INFO - 2018-07-31 02:28:31 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-31 02:28:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-07-31 02:28:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-31 02:28:31 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-31 02:28:31 --> Login MX_Controller Initialized
DEBUG - 2018-07-31 02:28:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-31 02:28:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
INFO - 2018-07-31 02:28:31 --> Config Class Initialized
INFO - 2018-07-31 02:28:31 --> Hooks Class Initialized
DEBUG - 2018-07-31 02:28:31 --> UTF-8 Support Enabled
INFO - 2018-07-31 02:28:31 --> Utf8 Class Initialized
INFO - 2018-07-31 02:28:32 --> URI Class Initialized
INFO - 2018-07-31 02:28:32 --> Router Class Initialized
INFO - 2018-07-31 02:28:32 --> Output Class Initialized
INFO - 2018-07-31 02:28:32 --> Security Class Initialized
DEBUG - 2018-07-31 02:28:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 02:28:32 --> Input Class Initialized
INFO - 2018-07-31 02:28:32 --> Language Class Initialized
INFO - 2018-07-31 02:28:32 --> Language Class Initialized
INFO - 2018-07-31 02:28:32 --> Config Class Initialized
INFO - 2018-07-31 02:28:32 --> Loader Class Initialized
DEBUG - 2018-07-31 02:28:32 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-31 02:28:32 --> Helper loaded: url_helper
INFO - 2018-07-31 02:28:32 --> Helper loaded: form_helper
INFO - 2018-07-31 02:28:32 --> Helper loaded: date_helper
INFO - 2018-07-31 02:28:32 --> Helper loaded: util_helper
INFO - 2018-07-31 02:28:32 --> Helper loaded: text_helper
INFO - 2018-07-31 02:28:32 --> Helper loaded: string_helper
INFO - 2018-07-31 02:28:32 --> Database Driver Class Initialized
DEBUG - 2018-07-31 02:28:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 02:28:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 02:28:32 --> Email Class Initialized
INFO - 2018-07-31 02:28:32 --> Controller Class Initialized
DEBUG - 2018-07-31 02:28:32 --> Programs MX_Controller Initialized
INFO - 2018-07-31 02:28:32 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-31 02:28:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-07-31 02:28:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-31 02:28:32 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-31 02:28:32 --> Login MX_Controller Initialized
DEBUG - 2018-07-31 02:28:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-31 02:28:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-31 02:28:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-31 02:28:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-31 02:28:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-31 02:28:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-31 02:28:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/programs/programs.php
INFO - 2018-07-31 02:28:32 --> Final output sent to browser
DEBUG - 2018-07-31 02:28:32 --> Total execution time: 0.7305
INFO - 2018-07-31 02:28:33 --> Config Class Initialized
INFO - 2018-07-31 02:28:33 --> Hooks Class Initialized
DEBUG - 2018-07-31 02:28:33 --> UTF-8 Support Enabled
INFO - 2018-07-31 02:28:33 --> Utf8 Class Initialized
INFO - 2018-07-31 02:28:33 --> URI Class Initialized
INFO - 2018-07-31 02:28:33 --> Router Class Initialized
INFO - 2018-07-31 02:28:33 --> Output Class Initialized
INFO - 2018-07-31 02:28:33 --> Security Class Initialized
DEBUG - 2018-07-31 02:28:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 02:28:33 --> Input Class Initialized
INFO - 2018-07-31 02:28:33 --> Language Class Initialized
INFO - 2018-07-31 02:28:33 --> Language Class Initialized
INFO - 2018-07-31 02:28:33 --> Config Class Initialized
INFO - 2018-07-31 02:28:33 --> Loader Class Initialized
DEBUG - 2018-07-31 02:28:33 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-31 02:28:33 --> Helper loaded: url_helper
INFO - 2018-07-31 02:28:33 --> Helper loaded: form_helper
INFO - 2018-07-31 02:28:33 --> Helper loaded: date_helper
INFO - 2018-07-31 02:28:33 --> Helper loaded: util_helper
INFO - 2018-07-31 02:28:33 --> Helper loaded: text_helper
INFO - 2018-07-31 02:28:33 --> Helper loaded: string_helper
INFO - 2018-07-31 02:28:33 --> Database Driver Class Initialized
DEBUG - 2018-07-31 02:28:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 02:28:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 02:28:33 --> Email Class Initialized
INFO - 2018-07-31 02:28:33 --> Controller Class Initialized
DEBUG - 2018-07-31 02:28:34 --> Programs MX_Controller Initialized
INFO - 2018-07-31 02:28:34 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-31 02:28:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-07-31 02:28:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-31 02:28:34 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-31 02:28:34 --> Login MX_Controller Initialized
DEBUG - 2018-07-31 02:28:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-31 02:28:34 --> Final output sent to browser
DEBUG - 2018-07-31 02:28:34 --> Total execution time: 0.6941
INFO - 2018-07-31 02:28:44 --> Config Class Initialized
INFO - 2018-07-31 02:28:44 --> Hooks Class Initialized
DEBUG - 2018-07-31 02:28:44 --> UTF-8 Support Enabled
INFO - 2018-07-31 02:28:44 --> Utf8 Class Initialized
INFO - 2018-07-31 02:28:44 --> URI Class Initialized
INFO - 2018-07-31 02:28:44 --> Router Class Initialized
INFO - 2018-07-31 02:28:44 --> Output Class Initialized
INFO - 2018-07-31 02:28:44 --> Security Class Initialized
DEBUG - 2018-07-31 02:28:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 02:28:44 --> Input Class Initialized
INFO - 2018-07-31 02:28:44 --> Language Class Initialized
INFO - 2018-07-31 02:28:44 --> Language Class Initialized
INFO - 2018-07-31 02:28:44 --> Config Class Initialized
INFO - 2018-07-31 02:28:44 --> Loader Class Initialized
DEBUG - 2018-07-31 02:28:44 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-31 02:28:44 --> Helper loaded: url_helper
INFO - 2018-07-31 02:28:44 --> Helper loaded: form_helper
INFO - 2018-07-31 02:28:44 --> Helper loaded: date_helper
INFO - 2018-07-31 02:28:44 --> Helper loaded: util_helper
INFO - 2018-07-31 02:28:44 --> Helper loaded: text_helper
INFO - 2018-07-31 02:28:44 --> Helper loaded: string_helper
INFO - 2018-07-31 02:28:44 --> Database Driver Class Initialized
DEBUG - 2018-07-31 02:28:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 02:28:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 02:28:45 --> Email Class Initialized
INFO - 2018-07-31 02:28:45 --> Controller Class Initialized
DEBUG - 2018-07-31 02:28:45 --> Programs MX_Controller Initialized
INFO - 2018-07-31 02:28:45 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-31 02:28:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-07-31 02:28:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-31 02:28:45 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-31 02:28:45 --> Login MX_Controller Initialized
DEBUG - 2018-07-31 02:28:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-31 02:28:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-31 02:28:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-31 02:28:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-31 02:28:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-31 02:28:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-31 02:28:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/programs/create_program.php
INFO - 2018-07-31 02:28:45 --> Final output sent to browser
DEBUG - 2018-07-31 02:28:45 --> Total execution time: 0.5371
INFO - 2018-07-31 02:28:45 --> Config Class Initialized
INFO - 2018-07-31 02:28:46 --> Hooks Class Initialized
DEBUG - 2018-07-31 02:28:46 --> UTF-8 Support Enabled
INFO - 2018-07-31 02:28:46 --> Utf8 Class Initialized
INFO - 2018-07-31 02:28:46 --> URI Class Initialized
INFO - 2018-07-31 02:28:46 --> Router Class Initialized
INFO - 2018-07-31 02:28:46 --> Output Class Initialized
INFO - 2018-07-31 02:28:46 --> Security Class Initialized
DEBUG - 2018-07-31 02:28:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 02:28:46 --> Input Class Initialized
INFO - 2018-07-31 02:28:46 --> Language Class Initialized
ERROR - 2018-07-31 02:28:46 --> 404 Page Not Found: /index
INFO - 2018-07-31 02:28:47 --> Config Class Initialized
INFO - 2018-07-31 02:28:47 --> Hooks Class Initialized
DEBUG - 2018-07-31 02:28:47 --> UTF-8 Support Enabled
INFO - 2018-07-31 02:28:47 --> Utf8 Class Initialized
INFO - 2018-07-31 02:28:47 --> URI Class Initialized
INFO - 2018-07-31 02:28:47 --> Router Class Initialized
INFO - 2018-07-31 02:28:47 --> Output Class Initialized
INFO - 2018-07-31 02:28:47 --> Security Class Initialized
DEBUG - 2018-07-31 02:28:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 02:28:47 --> Input Class Initialized
INFO - 2018-07-31 02:28:47 --> Language Class Initialized
INFO - 2018-07-31 02:28:47 --> Language Class Initialized
INFO - 2018-07-31 02:28:47 --> Config Class Initialized
INFO - 2018-07-31 02:28:47 --> Loader Class Initialized
DEBUG - 2018-07-31 02:28:47 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-31 02:28:47 --> Helper loaded: url_helper
INFO - 2018-07-31 02:28:47 --> Helper loaded: form_helper
INFO - 2018-07-31 02:28:47 --> Helper loaded: date_helper
INFO - 2018-07-31 02:28:47 --> Helper loaded: util_helper
INFO - 2018-07-31 02:28:47 --> Helper loaded: text_helper
INFO - 2018-07-31 02:28:47 --> Helper loaded: string_helper
INFO - 2018-07-31 02:28:47 --> Database Driver Class Initialized
DEBUG - 2018-07-31 02:28:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 02:28:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 02:28:47 --> Email Class Initialized
INFO - 2018-07-31 02:28:47 --> Controller Class Initialized
DEBUG - 2018-07-31 02:28:47 --> Programs MX_Controller Initialized
INFO - 2018-07-31 02:28:47 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-31 02:28:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-07-31 02:28:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-31 02:28:47 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-31 02:28:47 --> Login MX_Controller Initialized
DEBUG - 2018-07-31 02:28:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-31 02:28:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-31 02:28:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-31 02:28:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-31 02:28:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-31 02:28:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-31 02:28:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/programs/create_program.php
INFO - 2018-07-31 02:28:48 --> Final output sent to browser
DEBUG - 2018-07-31 02:28:48 --> Total execution time: 0.5266
INFO - 2018-07-31 02:28:48 --> Config Class Initialized
INFO - 2018-07-31 02:28:48 --> Hooks Class Initialized
DEBUG - 2018-07-31 02:28:48 --> UTF-8 Support Enabled
INFO - 2018-07-31 02:28:49 --> Utf8 Class Initialized
INFO - 2018-07-31 02:28:49 --> URI Class Initialized
INFO - 2018-07-31 02:28:49 --> Router Class Initialized
INFO - 2018-07-31 02:28:49 --> Output Class Initialized
INFO - 2018-07-31 02:28:49 --> Security Class Initialized
DEBUG - 2018-07-31 02:28:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 02:28:49 --> Input Class Initialized
INFO - 2018-07-31 02:28:49 --> Language Class Initialized
ERROR - 2018-07-31 02:28:49 --> 404 Page Not Found: /index
INFO - 2018-07-31 02:28:53 --> Config Class Initialized
INFO - 2018-07-31 02:28:53 --> Hooks Class Initialized
DEBUG - 2018-07-31 02:28:53 --> UTF-8 Support Enabled
INFO - 2018-07-31 02:28:53 --> Utf8 Class Initialized
INFO - 2018-07-31 02:28:53 --> URI Class Initialized
INFO - 2018-07-31 02:28:53 --> Router Class Initialized
INFO - 2018-07-31 02:28:53 --> Output Class Initialized
INFO - 2018-07-31 02:28:53 --> Security Class Initialized
DEBUG - 2018-07-31 02:28:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 02:28:53 --> Input Class Initialized
INFO - 2018-07-31 02:28:53 --> Language Class Initialized
INFO - 2018-07-31 02:28:53 --> Language Class Initialized
INFO - 2018-07-31 02:28:53 --> Config Class Initialized
INFO - 2018-07-31 02:28:53 --> Loader Class Initialized
DEBUG - 2018-07-31 02:28:53 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-31 02:28:53 --> Helper loaded: url_helper
INFO - 2018-07-31 02:28:53 --> Helper loaded: form_helper
INFO - 2018-07-31 02:28:53 --> Helper loaded: date_helper
INFO - 2018-07-31 02:28:53 --> Helper loaded: util_helper
INFO - 2018-07-31 02:28:53 --> Helper loaded: text_helper
INFO - 2018-07-31 02:28:53 --> Helper loaded: string_helper
INFO - 2018-07-31 02:28:53 --> Database Driver Class Initialized
DEBUG - 2018-07-31 02:28:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 02:28:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 02:28:53 --> Email Class Initialized
INFO - 2018-07-31 02:28:53 --> Controller Class Initialized
DEBUG - 2018-07-31 02:28:53 --> Programs MX_Controller Initialized
INFO - 2018-07-31 02:28:53 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-31 02:28:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-07-31 02:28:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-31 02:28:53 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-31 02:28:53 --> Login MX_Controller Initialized
DEBUG - 2018-07-31 02:28:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-31 02:29:42 --> Config Class Initialized
INFO - 2018-07-31 02:29:42 --> Hooks Class Initialized
DEBUG - 2018-07-31 02:29:42 --> UTF-8 Support Enabled
INFO - 2018-07-31 02:29:42 --> Utf8 Class Initialized
INFO - 2018-07-31 02:29:42 --> URI Class Initialized
INFO - 2018-07-31 02:29:42 --> Router Class Initialized
INFO - 2018-07-31 02:29:42 --> Output Class Initialized
INFO - 2018-07-31 02:29:42 --> Security Class Initialized
DEBUG - 2018-07-31 02:29:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 02:29:42 --> Input Class Initialized
INFO - 2018-07-31 02:29:42 --> Language Class Initialized
INFO - 2018-07-31 02:29:42 --> Language Class Initialized
INFO - 2018-07-31 02:29:42 --> Config Class Initialized
INFO - 2018-07-31 02:29:42 --> Loader Class Initialized
DEBUG - 2018-07-31 02:29:42 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-31 02:29:42 --> Helper loaded: url_helper
INFO - 2018-07-31 02:29:42 --> Helper loaded: form_helper
INFO - 2018-07-31 02:29:42 --> Helper loaded: date_helper
INFO - 2018-07-31 02:29:42 --> Helper loaded: util_helper
INFO - 2018-07-31 02:29:42 --> Helper loaded: text_helper
INFO - 2018-07-31 02:29:42 --> Helper loaded: string_helper
INFO - 2018-07-31 02:29:42 --> Database Driver Class Initialized
DEBUG - 2018-07-31 02:29:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 02:29:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 02:29:42 --> Email Class Initialized
INFO - 2018-07-31 02:29:42 --> Controller Class Initialized
DEBUG - 2018-07-31 02:29:42 --> Programs MX_Controller Initialized
INFO - 2018-07-31 02:29:42 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-31 02:29:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-07-31 02:29:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-31 02:29:42 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-31 02:29:42 --> Login MX_Controller Initialized
DEBUG - 2018-07-31 02:29:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-31 02:29:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
INFO - 2018-07-31 02:29:43 --> Upload Class Initialized
INFO - 2018-07-31 02:29:56 --> Config Class Initialized
INFO - 2018-07-31 02:29:56 --> Hooks Class Initialized
DEBUG - 2018-07-31 02:29:56 --> UTF-8 Support Enabled
INFO - 2018-07-31 02:29:56 --> Utf8 Class Initialized
INFO - 2018-07-31 02:29:56 --> URI Class Initialized
INFO - 2018-07-31 02:29:56 --> Router Class Initialized
INFO - 2018-07-31 02:29:56 --> Output Class Initialized
INFO - 2018-07-31 02:29:56 --> Security Class Initialized
DEBUG - 2018-07-31 02:29:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 02:29:56 --> Input Class Initialized
INFO - 2018-07-31 02:29:56 --> Language Class Initialized
INFO - 2018-07-31 02:29:56 --> Language Class Initialized
INFO - 2018-07-31 02:29:56 --> Config Class Initialized
INFO - 2018-07-31 02:29:56 --> Loader Class Initialized
DEBUG - 2018-07-31 02:29:56 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-31 02:29:56 --> Helper loaded: url_helper
INFO - 2018-07-31 02:29:56 --> Helper loaded: form_helper
INFO - 2018-07-31 02:29:56 --> Helper loaded: date_helper
INFO - 2018-07-31 02:29:56 --> Helper loaded: util_helper
INFO - 2018-07-31 02:29:56 --> Helper loaded: text_helper
INFO - 2018-07-31 02:29:56 --> Helper loaded: string_helper
INFO - 2018-07-31 02:29:56 --> Database Driver Class Initialized
DEBUG - 2018-07-31 02:29:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 02:29:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 02:29:56 --> Email Class Initialized
INFO - 2018-07-31 02:29:56 --> Controller Class Initialized
DEBUG - 2018-07-31 02:29:56 --> Programs MX_Controller Initialized
INFO - 2018-07-31 02:29:56 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-31 02:29:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-07-31 02:29:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-31 02:29:56 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-31 02:29:56 --> Login MX_Controller Initialized
DEBUG - 2018-07-31 02:29:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-31 02:29:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
INFO - 2018-07-31 02:29:56 --> Upload Class Initialized
ERROR - 2018-07-31 02:29:56 --> Severity: Warning --> unlink(E:\xampp\htdocs\consulting\assets/images/users/1532732370.jpg): No such file or directory E:\xampp\htdocs\consulting\application\modules\admin\controllers\Programs.php 180
INFO - 2018-07-31 02:30:42 --> Config Class Initialized
INFO - 2018-07-31 02:30:42 --> Hooks Class Initialized
DEBUG - 2018-07-31 02:30:42 --> UTF-8 Support Enabled
INFO - 2018-07-31 02:30:42 --> Utf8 Class Initialized
INFO - 2018-07-31 02:30:42 --> URI Class Initialized
INFO - 2018-07-31 02:30:42 --> Router Class Initialized
INFO - 2018-07-31 02:30:42 --> Output Class Initialized
INFO - 2018-07-31 02:30:42 --> Security Class Initialized
DEBUG - 2018-07-31 02:30:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 02:30:42 --> Input Class Initialized
INFO - 2018-07-31 02:30:42 --> Language Class Initialized
INFO - 2018-07-31 02:30:42 --> Language Class Initialized
INFO - 2018-07-31 02:30:42 --> Config Class Initialized
INFO - 2018-07-31 02:30:42 --> Loader Class Initialized
DEBUG - 2018-07-31 02:30:42 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-31 02:30:42 --> Helper loaded: url_helper
INFO - 2018-07-31 02:30:42 --> Helper loaded: form_helper
INFO - 2018-07-31 02:30:42 --> Helper loaded: date_helper
INFO - 2018-07-31 02:30:42 --> Helper loaded: util_helper
INFO - 2018-07-31 02:30:42 --> Helper loaded: text_helper
INFO - 2018-07-31 02:30:42 --> Helper loaded: string_helper
INFO - 2018-07-31 02:30:42 --> Database Driver Class Initialized
DEBUG - 2018-07-31 02:30:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 02:30:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 02:30:42 --> Email Class Initialized
INFO - 2018-07-31 02:30:42 --> Controller Class Initialized
DEBUG - 2018-07-31 02:30:42 --> Programs MX_Controller Initialized
INFO - 2018-07-31 02:30:42 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-31 02:30:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-07-31 02:30:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-31 02:30:42 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-31 02:30:42 --> Login MX_Controller Initialized
DEBUG - 2018-07-31 02:30:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-31 02:30:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
INFO - 2018-07-31 02:30:42 --> Upload Class Initialized
INFO - 2018-07-31 02:30:42 --> Config Class Initialized
INFO - 2018-07-31 02:30:42 --> Hooks Class Initialized
DEBUG - 2018-07-31 02:30:42 --> UTF-8 Support Enabled
INFO - 2018-07-31 02:30:42 --> Utf8 Class Initialized
INFO - 2018-07-31 02:30:42 --> URI Class Initialized
INFO - 2018-07-31 02:30:42 --> Router Class Initialized
INFO - 2018-07-31 02:30:42 --> Output Class Initialized
INFO - 2018-07-31 02:30:42 --> Security Class Initialized
DEBUG - 2018-07-31 02:30:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 02:30:42 --> Input Class Initialized
INFO - 2018-07-31 02:30:42 --> Language Class Initialized
INFO - 2018-07-31 02:30:42 --> Language Class Initialized
INFO - 2018-07-31 02:30:42 --> Config Class Initialized
INFO - 2018-07-31 02:30:43 --> Loader Class Initialized
DEBUG - 2018-07-31 02:30:43 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-31 02:30:43 --> Helper loaded: url_helper
INFO - 2018-07-31 02:30:43 --> Helper loaded: form_helper
INFO - 2018-07-31 02:30:43 --> Helper loaded: date_helper
INFO - 2018-07-31 02:30:43 --> Helper loaded: util_helper
INFO - 2018-07-31 02:30:43 --> Helper loaded: text_helper
INFO - 2018-07-31 02:30:43 --> Helper loaded: string_helper
INFO - 2018-07-31 02:30:43 --> Database Driver Class Initialized
DEBUG - 2018-07-31 02:30:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 02:30:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 02:30:43 --> Email Class Initialized
INFO - 2018-07-31 02:30:43 --> Controller Class Initialized
DEBUG - 2018-07-31 02:30:43 --> Programs MX_Controller Initialized
INFO - 2018-07-31 02:30:43 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-31 02:30:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-07-31 02:30:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-31 02:30:43 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-31 02:30:43 --> Login MX_Controller Initialized
DEBUG - 2018-07-31 02:30:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-31 02:30:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-31 02:30:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-31 02:30:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-31 02:30:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-31 02:30:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-31 02:30:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/programs/programs.php
INFO - 2018-07-31 02:30:43 --> Final output sent to browser
DEBUG - 2018-07-31 02:30:43 --> Total execution time: 0.5906
INFO - 2018-07-31 02:30:44 --> Config Class Initialized
INFO - 2018-07-31 02:30:44 --> Hooks Class Initialized
DEBUG - 2018-07-31 02:30:44 --> UTF-8 Support Enabled
INFO - 2018-07-31 02:30:44 --> Utf8 Class Initialized
INFO - 2018-07-31 02:30:44 --> URI Class Initialized
INFO - 2018-07-31 02:30:44 --> Router Class Initialized
INFO - 2018-07-31 02:30:44 --> Output Class Initialized
INFO - 2018-07-31 02:30:44 --> Security Class Initialized
DEBUG - 2018-07-31 02:30:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 02:30:44 --> Input Class Initialized
INFO - 2018-07-31 02:30:44 --> Language Class Initialized
INFO - 2018-07-31 02:30:44 --> Language Class Initialized
INFO - 2018-07-31 02:30:44 --> Config Class Initialized
INFO - 2018-07-31 02:30:44 --> Loader Class Initialized
DEBUG - 2018-07-31 02:30:44 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-31 02:30:44 --> Helper loaded: url_helper
INFO - 2018-07-31 02:30:44 --> Helper loaded: form_helper
INFO - 2018-07-31 02:30:44 --> Helper loaded: date_helper
INFO - 2018-07-31 02:30:44 --> Helper loaded: util_helper
INFO - 2018-07-31 02:30:44 --> Helper loaded: text_helper
INFO - 2018-07-31 02:30:44 --> Helper loaded: string_helper
INFO - 2018-07-31 02:30:44 --> Database Driver Class Initialized
DEBUG - 2018-07-31 02:30:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 02:30:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 02:30:44 --> Email Class Initialized
INFO - 2018-07-31 02:30:44 --> Controller Class Initialized
DEBUG - 2018-07-31 02:30:44 --> Programs MX_Controller Initialized
INFO - 2018-07-31 02:30:44 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-31 02:30:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-07-31 02:30:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-31 02:30:44 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-31 02:30:44 --> Login MX_Controller Initialized
DEBUG - 2018-07-31 02:30:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-31 02:30:44 --> Final output sent to browser
DEBUG - 2018-07-31 02:30:44 --> Total execution time: 0.7436
INFO - 2018-07-31 02:30:52 --> Config Class Initialized
INFO - 2018-07-31 02:30:52 --> Hooks Class Initialized
DEBUG - 2018-07-31 02:30:52 --> UTF-8 Support Enabled
INFO - 2018-07-31 02:30:52 --> Utf8 Class Initialized
INFO - 2018-07-31 02:30:52 --> URI Class Initialized
INFO - 2018-07-31 02:30:52 --> Router Class Initialized
INFO - 2018-07-31 02:30:52 --> Output Class Initialized
INFO - 2018-07-31 02:30:52 --> Security Class Initialized
DEBUG - 2018-07-31 02:30:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 02:30:52 --> Input Class Initialized
INFO - 2018-07-31 02:30:52 --> Language Class Initialized
INFO - 2018-07-31 02:30:52 --> Language Class Initialized
INFO - 2018-07-31 02:30:52 --> Config Class Initialized
INFO - 2018-07-31 02:30:52 --> Loader Class Initialized
DEBUG - 2018-07-31 02:30:52 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-31 02:30:52 --> Helper loaded: url_helper
INFO - 2018-07-31 02:30:52 --> Helper loaded: form_helper
INFO - 2018-07-31 02:30:52 --> Helper loaded: date_helper
INFO - 2018-07-31 02:30:52 --> Helper loaded: util_helper
INFO - 2018-07-31 02:30:52 --> Helper loaded: text_helper
INFO - 2018-07-31 02:30:52 --> Helper loaded: string_helper
INFO - 2018-07-31 02:30:52 --> Database Driver Class Initialized
DEBUG - 2018-07-31 02:30:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 02:30:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 02:30:53 --> Email Class Initialized
INFO - 2018-07-31 02:30:53 --> Controller Class Initialized
DEBUG - 2018-07-31 02:30:53 --> Programs MX_Controller Initialized
INFO - 2018-07-31 02:30:53 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-31 02:30:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-07-31 02:30:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-31 02:30:53 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-31 02:30:53 --> Login MX_Controller Initialized
DEBUG - 2018-07-31 02:30:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-31 02:30:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-31 02:30:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-31 02:30:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-31 02:30:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-31 02:30:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-31 02:30:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/programs/create_program.php
INFO - 2018-07-31 02:30:53 --> Final output sent to browser
DEBUG - 2018-07-31 02:30:53 --> Total execution time: 0.5677
INFO - 2018-07-31 02:30:53 --> Config Class Initialized
INFO - 2018-07-31 02:30:54 --> Hooks Class Initialized
DEBUG - 2018-07-31 02:30:54 --> UTF-8 Support Enabled
INFO - 2018-07-31 02:30:54 --> Utf8 Class Initialized
INFO - 2018-07-31 02:30:54 --> URI Class Initialized
INFO - 2018-07-31 02:30:54 --> Router Class Initialized
INFO - 2018-07-31 02:30:54 --> Output Class Initialized
INFO - 2018-07-31 02:30:54 --> Security Class Initialized
DEBUG - 2018-07-31 02:30:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 02:30:54 --> Input Class Initialized
INFO - 2018-07-31 02:30:54 --> Language Class Initialized
ERROR - 2018-07-31 02:30:54 --> 404 Page Not Found: /index
INFO - 2018-07-31 02:46:25 --> Config Class Initialized
INFO - 2018-07-31 02:46:25 --> Hooks Class Initialized
DEBUG - 2018-07-31 02:46:25 --> UTF-8 Support Enabled
INFO - 2018-07-31 02:46:25 --> Utf8 Class Initialized
INFO - 2018-07-31 02:46:25 --> URI Class Initialized
INFO - 2018-07-31 02:46:25 --> Router Class Initialized
INFO - 2018-07-31 02:46:25 --> Output Class Initialized
INFO - 2018-07-31 02:46:25 --> Security Class Initialized
DEBUG - 2018-07-31 02:46:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 02:46:25 --> Input Class Initialized
INFO - 2018-07-31 02:46:25 --> Language Class Initialized
INFO - 2018-07-31 02:46:25 --> Language Class Initialized
INFO - 2018-07-31 02:46:25 --> Config Class Initialized
INFO - 2018-07-31 02:46:25 --> Loader Class Initialized
DEBUG - 2018-07-31 02:46:25 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-31 02:46:25 --> Helper loaded: url_helper
INFO - 2018-07-31 02:46:25 --> Helper loaded: form_helper
INFO - 2018-07-31 02:46:25 --> Helper loaded: date_helper
INFO - 2018-07-31 02:46:25 --> Helper loaded: util_helper
INFO - 2018-07-31 02:46:25 --> Helper loaded: text_helper
INFO - 2018-07-31 02:46:25 --> Helper loaded: string_helper
INFO - 2018-07-31 02:46:25 --> Database Driver Class Initialized
DEBUG - 2018-07-31 02:46:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 02:46:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 02:46:25 --> Email Class Initialized
INFO - 2018-07-31 02:46:25 --> Controller Class Initialized
DEBUG - 2018-07-31 02:46:25 --> Programs MX_Controller Initialized
INFO - 2018-07-31 02:46:25 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-31 02:46:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-07-31 02:46:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-31 02:46:25 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-31 02:46:25 --> Login MX_Controller Initialized
DEBUG - 2018-07-31 02:46:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-31 02:46:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-31 02:46:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-31 02:46:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-31 02:46:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-31 02:46:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-31 02:46:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/programs/programs.php
INFO - 2018-07-31 02:46:25 --> Final output sent to browser
DEBUG - 2018-07-31 02:46:25 --> Total execution time: 0.6504
INFO - 2018-07-31 02:46:27 --> Config Class Initialized
INFO - 2018-07-31 02:46:27 --> Hooks Class Initialized
DEBUG - 2018-07-31 02:46:27 --> UTF-8 Support Enabled
INFO - 2018-07-31 02:46:27 --> Utf8 Class Initialized
INFO - 2018-07-31 02:46:27 --> URI Class Initialized
INFO - 2018-07-31 02:46:27 --> Router Class Initialized
INFO - 2018-07-31 02:46:27 --> Output Class Initialized
INFO - 2018-07-31 02:46:27 --> Security Class Initialized
DEBUG - 2018-07-31 02:46:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 02:46:27 --> Input Class Initialized
INFO - 2018-07-31 02:46:27 --> Language Class Initialized
INFO - 2018-07-31 02:46:27 --> Language Class Initialized
INFO - 2018-07-31 02:46:27 --> Config Class Initialized
INFO - 2018-07-31 02:46:27 --> Loader Class Initialized
DEBUG - 2018-07-31 02:46:27 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-31 02:46:27 --> Helper loaded: url_helper
INFO - 2018-07-31 02:46:27 --> Helper loaded: form_helper
INFO - 2018-07-31 02:46:27 --> Helper loaded: date_helper
INFO - 2018-07-31 02:46:27 --> Helper loaded: util_helper
INFO - 2018-07-31 02:46:27 --> Helper loaded: text_helper
INFO - 2018-07-31 02:46:27 --> Helper loaded: string_helper
INFO - 2018-07-31 02:46:27 --> Database Driver Class Initialized
DEBUG - 2018-07-31 02:46:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 02:46:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 02:46:27 --> Email Class Initialized
INFO - 2018-07-31 02:46:27 --> Controller Class Initialized
DEBUG - 2018-07-31 02:46:27 --> Programs MX_Controller Initialized
INFO - 2018-07-31 02:46:27 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-31 02:46:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-07-31 02:46:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-31 02:46:27 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-31 02:46:27 --> Login MX_Controller Initialized
DEBUG - 2018-07-31 02:46:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-31 02:46:27 --> Final output sent to browser
DEBUG - 2018-07-31 02:46:27 --> Total execution time: 0.9050
INFO - 2018-07-31 02:52:50 --> Config Class Initialized
INFO - 2018-07-31 02:52:50 --> Hooks Class Initialized
DEBUG - 2018-07-31 02:52:50 --> UTF-8 Support Enabled
INFO - 2018-07-31 02:52:50 --> Utf8 Class Initialized
INFO - 2018-07-31 02:52:50 --> URI Class Initialized
INFO - 2018-07-31 02:52:50 --> Router Class Initialized
INFO - 2018-07-31 02:52:50 --> Output Class Initialized
INFO - 2018-07-31 02:52:50 --> Security Class Initialized
DEBUG - 2018-07-31 02:52:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 02:52:50 --> Input Class Initialized
INFO - 2018-07-31 02:52:50 --> Language Class Initialized
INFO - 2018-07-31 02:52:50 --> Language Class Initialized
INFO - 2018-07-31 02:52:50 --> Config Class Initialized
INFO - 2018-07-31 02:52:50 --> Loader Class Initialized
DEBUG - 2018-07-31 02:52:50 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-31 02:52:50 --> Helper loaded: url_helper
INFO - 2018-07-31 02:52:50 --> Helper loaded: form_helper
INFO - 2018-07-31 02:52:50 --> Helper loaded: date_helper
INFO - 2018-07-31 02:52:50 --> Helper loaded: util_helper
INFO - 2018-07-31 02:52:50 --> Helper loaded: text_helper
INFO - 2018-07-31 02:52:50 --> Helper loaded: string_helper
INFO - 2018-07-31 02:52:50 --> Database Driver Class Initialized
DEBUG - 2018-07-31 02:52:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 02:52:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 02:52:51 --> Email Class Initialized
INFO - 2018-07-31 02:52:51 --> Controller Class Initialized
DEBUG - 2018-07-31 02:52:51 --> Programs MX_Controller Initialized
INFO - 2018-07-31 02:52:51 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-31 02:52:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-07-31 02:52:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-31 02:52:51 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-31 02:52:51 --> Login MX_Controller Initialized
DEBUG - 2018-07-31 02:52:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-31 02:52:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-31 02:52:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-31 02:52:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-31 02:52:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-31 02:52:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-31 02:52:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/programs/create_program.php
INFO - 2018-07-31 02:52:51 --> Final output sent to browser
DEBUG - 2018-07-31 02:52:51 --> Total execution time: 0.6530
INFO - 2018-07-31 02:52:54 --> Config Class Initialized
INFO - 2018-07-31 02:52:54 --> Hooks Class Initialized
DEBUG - 2018-07-31 02:52:54 --> UTF-8 Support Enabled
INFO - 2018-07-31 02:52:54 --> Utf8 Class Initialized
INFO - 2018-07-31 02:52:54 --> URI Class Initialized
INFO - 2018-07-31 02:52:54 --> Router Class Initialized
INFO - 2018-07-31 02:52:54 --> Output Class Initialized
INFO - 2018-07-31 02:52:54 --> Security Class Initialized
DEBUG - 2018-07-31 02:52:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 02:52:55 --> Input Class Initialized
INFO - 2018-07-31 02:52:55 --> Language Class Initialized
INFO - 2018-07-31 02:52:55 --> Language Class Initialized
INFO - 2018-07-31 02:52:55 --> Config Class Initialized
INFO - 2018-07-31 02:52:55 --> Loader Class Initialized
DEBUG - 2018-07-31 02:52:55 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-31 02:52:55 --> Helper loaded: url_helper
INFO - 2018-07-31 02:52:55 --> Helper loaded: form_helper
INFO - 2018-07-31 02:52:55 --> Helper loaded: date_helper
INFO - 2018-07-31 02:52:55 --> Helper loaded: util_helper
INFO - 2018-07-31 02:52:55 --> Helper loaded: text_helper
INFO - 2018-07-31 02:52:55 --> Helper loaded: string_helper
INFO - 2018-07-31 02:52:55 --> Database Driver Class Initialized
DEBUG - 2018-07-31 02:52:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 02:52:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 02:52:55 --> Email Class Initialized
INFO - 2018-07-31 02:52:55 --> Controller Class Initialized
DEBUG - 2018-07-31 02:52:55 --> Programs MX_Controller Initialized
INFO - 2018-07-31 02:52:55 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-31 02:52:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-07-31 02:52:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-31 02:52:55 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-31 02:52:55 --> Login MX_Controller Initialized
DEBUG - 2018-07-31 02:52:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-31 02:52:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-31 02:52:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-31 02:52:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-31 02:52:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-31 02:52:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-31 02:52:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/programs/programs.php
INFO - 2018-07-31 02:52:55 --> Final output sent to browser
DEBUG - 2018-07-31 02:52:55 --> Total execution time: 0.6573
INFO - 2018-07-31 02:52:56 --> Config Class Initialized
INFO - 2018-07-31 02:52:56 --> Hooks Class Initialized
DEBUG - 2018-07-31 02:52:56 --> UTF-8 Support Enabled
INFO - 2018-07-31 02:52:56 --> Utf8 Class Initialized
INFO - 2018-07-31 02:52:56 --> URI Class Initialized
INFO - 2018-07-31 02:52:56 --> Router Class Initialized
INFO - 2018-07-31 02:52:56 --> Output Class Initialized
INFO - 2018-07-31 02:52:56 --> Security Class Initialized
DEBUG - 2018-07-31 02:52:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 02:52:56 --> Input Class Initialized
INFO - 2018-07-31 02:52:56 --> Language Class Initialized
INFO - 2018-07-31 02:52:56 --> Language Class Initialized
INFO - 2018-07-31 02:52:56 --> Config Class Initialized
INFO - 2018-07-31 02:52:56 --> Loader Class Initialized
DEBUG - 2018-07-31 02:52:56 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-31 02:52:56 --> Helper loaded: url_helper
INFO - 2018-07-31 02:52:56 --> Helper loaded: form_helper
INFO - 2018-07-31 02:52:56 --> Helper loaded: date_helper
INFO - 2018-07-31 02:52:56 --> Helper loaded: util_helper
INFO - 2018-07-31 02:52:56 --> Helper loaded: text_helper
INFO - 2018-07-31 02:52:56 --> Helper loaded: string_helper
INFO - 2018-07-31 02:52:56 --> Database Driver Class Initialized
DEBUG - 2018-07-31 02:52:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 02:52:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 02:52:56 --> Email Class Initialized
INFO - 2018-07-31 02:52:56 --> Controller Class Initialized
DEBUG - 2018-07-31 02:52:56 --> Programs MX_Controller Initialized
INFO - 2018-07-31 02:52:56 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-31 02:52:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-07-31 02:52:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-31 02:52:56 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-31 02:52:56 --> Login MX_Controller Initialized
DEBUG - 2018-07-31 02:52:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-31 02:52:56 --> Final output sent to browser
DEBUG - 2018-07-31 02:52:56 --> Total execution time: 0.7345
INFO - 2018-07-31 02:52:58 --> Config Class Initialized
INFO - 2018-07-31 02:52:59 --> Hooks Class Initialized
DEBUG - 2018-07-31 02:52:59 --> UTF-8 Support Enabled
INFO - 2018-07-31 02:52:59 --> Utf8 Class Initialized
INFO - 2018-07-31 02:52:59 --> URI Class Initialized
INFO - 2018-07-31 02:52:59 --> Router Class Initialized
INFO - 2018-07-31 02:52:59 --> Output Class Initialized
INFO - 2018-07-31 02:52:59 --> Security Class Initialized
DEBUG - 2018-07-31 02:52:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 02:52:59 --> Input Class Initialized
INFO - 2018-07-31 02:52:59 --> Language Class Initialized
INFO - 2018-07-31 02:52:59 --> Language Class Initialized
INFO - 2018-07-31 02:52:59 --> Config Class Initialized
INFO - 2018-07-31 02:52:59 --> Loader Class Initialized
DEBUG - 2018-07-31 02:52:59 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-31 02:52:59 --> Helper loaded: url_helper
INFO - 2018-07-31 02:52:59 --> Helper loaded: form_helper
INFO - 2018-07-31 02:52:59 --> Helper loaded: date_helper
INFO - 2018-07-31 02:52:59 --> Helper loaded: util_helper
INFO - 2018-07-31 02:52:59 --> Helper loaded: text_helper
INFO - 2018-07-31 02:52:59 --> Helper loaded: string_helper
INFO - 2018-07-31 02:52:59 --> Database Driver Class Initialized
DEBUG - 2018-07-31 02:52:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 02:52:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 02:52:59 --> Email Class Initialized
INFO - 2018-07-31 02:52:59 --> Controller Class Initialized
DEBUG - 2018-07-31 02:52:59 --> Admin MX_Controller Initialized
INFO - 2018-07-31 02:52:59 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-31 02:52:59 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-31 02:52:59 --> Login MX_Controller Initialized
DEBUG - 2018-07-31 02:52:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-31 02:52:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-31 02:52:59 --> Final output sent to browser
DEBUG - 2018-07-31 02:52:59 --> Total execution time: 0.6549
INFO - 2018-07-31 02:53:03 --> Config Class Initialized
INFO - 2018-07-31 02:53:03 --> Hooks Class Initialized
DEBUG - 2018-07-31 02:53:03 --> UTF-8 Support Enabled
INFO - 2018-07-31 02:53:03 --> Utf8 Class Initialized
INFO - 2018-07-31 02:53:03 --> URI Class Initialized
INFO - 2018-07-31 02:53:03 --> Router Class Initialized
INFO - 2018-07-31 02:53:03 --> Output Class Initialized
INFO - 2018-07-31 02:53:03 --> Security Class Initialized
DEBUG - 2018-07-31 02:53:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 02:53:03 --> Input Class Initialized
INFO - 2018-07-31 02:53:03 --> Language Class Initialized
INFO - 2018-07-31 02:53:03 --> Language Class Initialized
INFO - 2018-07-31 02:53:03 --> Config Class Initialized
INFO - 2018-07-31 02:53:03 --> Loader Class Initialized
DEBUG - 2018-07-31 02:53:03 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-31 02:53:03 --> Helper loaded: url_helper
INFO - 2018-07-31 02:53:03 --> Helper loaded: form_helper
INFO - 2018-07-31 02:53:03 --> Helper loaded: date_helper
INFO - 2018-07-31 02:53:03 --> Helper loaded: util_helper
INFO - 2018-07-31 02:53:03 --> Helper loaded: text_helper
INFO - 2018-07-31 02:53:03 --> Helper loaded: string_helper
INFO - 2018-07-31 02:53:03 --> Database Driver Class Initialized
DEBUG - 2018-07-31 02:53:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 02:53:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 02:53:03 --> Email Class Initialized
INFO - 2018-07-31 02:53:03 --> Controller Class Initialized
DEBUG - 2018-07-31 02:53:03 --> Programs MX_Controller Initialized
INFO - 2018-07-31 02:53:03 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-31 02:53:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-07-31 02:53:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-31 02:53:03 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-31 02:53:03 --> Login MX_Controller Initialized
DEBUG - 2018-07-31 02:53:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-31 02:53:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-31 02:53:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-31 02:53:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-31 02:53:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-31 02:53:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-31 02:53:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/programs/programs.php
INFO - 2018-07-31 02:53:03 --> Final output sent to browser
DEBUG - 2018-07-31 02:53:03 --> Total execution time: 0.8567
INFO - 2018-07-31 02:53:04 --> Config Class Initialized
INFO - 2018-07-31 02:53:04 --> Hooks Class Initialized
DEBUG - 2018-07-31 02:53:04 --> UTF-8 Support Enabled
INFO - 2018-07-31 02:53:04 --> Utf8 Class Initialized
INFO - 2018-07-31 02:53:04 --> URI Class Initialized
INFO - 2018-07-31 02:53:04 --> Router Class Initialized
INFO - 2018-07-31 02:53:04 --> Output Class Initialized
INFO - 2018-07-31 02:53:04 --> Security Class Initialized
DEBUG - 2018-07-31 02:53:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 02:53:04 --> Input Class Initialized
INFO - 2018-07-31 02:53:04 --> Language Class Initialized
INFO - 2018-07-31 02:53:04 --> Language Class Initialized
INFO - 2018-07-31 02:53:04 --> Config Class Initialized
INFO - 2018-07-31 02:53:04 --> Loader Class Initialized
DEBUG - 2018-07-31 02:53:04 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-31 02:53:04 --> Helper loaded: url_helper
INFO - 2018-07-31 02:53:04 --> Helper loaded: form_helper
INFO - 2018-07-31 02:53:04 --> Helper loaded: date_helper
INFO - 2018-07-31 02:53:04 --> Helper loaded: util_helper
INFO - 2018-07-31 02:53:04 --> Helper loaded: text_helper
INFO - 2018-07-31 02:53:04 --> Helper loaded: string_helper
INFO - 2018-07-31 02:53:04 --> Database Driver Class Initialized
DEBUG - 2018-07-31 02:53:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 02:53:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 02:53:04 --> Email Class Initialized
INFO - 2018-07-31 02:53:04 --> Controller Class Initialized
DEBUG - 2018-07-31 02:53:04 --> Programs MX_Controller Initialized
INFO - 2018-07-31 02:53:04 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-31 02:53:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-07-31 02:53:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-31 02:53:04 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-31 02:53:04 --> Login MX_Controller Initialized
DEBUG - 2018-07-31 02:53:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-31 02:53:04 --> Final output sent to browser
DEBUG - 2018-07-31 02:53:04 --> Total execution time: 0.6285
INFO - 2018-07-31 02:53:05 --> Config Class Initialized
INFO - 2018-07-31 02:53:05 --> Hooks Class Initialized
DEBUG - 2018-07-31 02:53:05 --> UTF-8 Support Enabled
INFO - 2018-07-31 02:53:05 --> Utf8 Class Initialized
INFO - 2018-07-31 02:53:05 --> URI Class Initialized
INFO - 2018-07-31 02:53:05 --> Router Class Initialized
INFO - 2018-07-31 02:53:05 --> Output Class Initialized
INFO - 2018-07-31 02:53:05 --> Security Class Initialized
DEBUG - 2018-07-31 02:53:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 02:53:05 --> Input Class Initialized
INFO - 2018-07-31 02:53:05 --> Language Class Initialized
ERROR - 2018-07-31 02:53:05 --> 404 Page Not Found: /index
INFO - 2018-07-31 02:53:17 --> Config Class Initialized
INFO - 2018-07-31 02:53:17 --> Hooks Class Initialized
DEBUG - 2018-07-31 02:53:17 --> UTF-8 Support Enabled
INFO - 2018-07-31 02:53:17 --> Utf8 Class Initialized
INFO - 2018-07-31 02:53:17 --> URI Class Initialized
INFO - 2018-07-31 02:53:17 --> Router Class Initialized
INFO - 2018-07-31 02:53:17 --> Output Class Initialized
INFO - 2018-07-31 02:53:17 --> Security Class Initialized
DEBUG - 2018-07-31 02:53:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 02:53:17 --> Input Class Initialized
INFO - 2018-07-31 02:53:17 --> Language Class Initialized
INFO - 2018-07-31 02:53:17 --> Language Class Initialized
INFO - 2018-07-31 02:53:17 --> Config Class Initialized
INFO - 2018-07-31 02:53:17 --> Loader Class Initialized
DEBUG - 2018-07-31 02:53:17 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-31 02:53:17 --> Helper loaded: url_helper
INFO - 2018-07-31 02:53:17 --> Helper loaded: form_helper
INFO - 2018-07-31 02:53:17 --> Helper loaded: date_helper
INFO - 2018-07-31 02:53:17 --> Helper loaded: util_helper
INFO - 2018-07-31 02:53:17 --> Helper loaded: text_helper
INFO - 2018-07-31 02:53:17 --> Helper loaded: string_helper
INFO - 2018-07-31 02:53:17 --> Database Driver Class Initialized
DEBUG - 2018-07-31 02:53:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 02:53:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 02:53:17 --> Email Class Initialized
INFO - 2018-07-31 02:53:17 --> Controller Class Initialized
DEBUG - 2018-07-31 02:53:17 --> Programs MX_Controller Initialized
INFO - 2018-07-31 02:53:17 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-31 02:53:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-07-31 02:53:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-31 02:53:17 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-31 02:53:17 --> Login MX_Controller Initialized
DEBUG - 2018-07-31 02:53:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-31 02:53:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-31 02:53:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-31 02:53:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-31 02:53:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-31 02:53:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-31 02:53:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/programs/create_program.php
INFO - 2018-07-31 02:53:18 --> Final output sent to browser
DEBUG - 2018-07-31 02:53:18 --> Total execution time: 0.6327
INFO - 2018-07-31 02:53:36 --> Config Class Initialized
INFO - 2018-07-31 02:53:36 --> Hooks Class Initialized
DEBUG - 2018-07-31 02:53:36 --> UTF-8 Support Enabled
INFO - 2018-07-31 02:53:36 --> Utf8 Class Initialized
INFO - 2018-07-31 02:53:36 --> URI Class Initialized
INFO - 2018-07-31 02:53:36 --> Router Class Initialized
INFO - 2018-07-31 02:53:36 --> Output Class Initialized
INFO - 2018-07-31 02:53:36 --> Security Class Initialized
DEBUG - 2018-07-31 02:53:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 02:53:36 --> Input Class Initialized
INFO - 2018-07-31 02:53:36 --> Language Class Initialized
INFO - 2018-07-31 02:53:36 --> Language Class Initialized
INFO - 2018-07-31 02:53:36 --> Config Class Initialized
INFO - 2018-07-31 02:53:36 --> Loader Class Initialized
DEBUG - 2018-07-31 02:53:36 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-31 02:53:36 --> Helper loaded: url_helper
INFO - 2018-07-31 02:53:36 --> Helper loaded: form_helper
INFO - 2018-07-31 02:53:36 --> Helper loaded: date_helper
INFO - 2018-07-31 02:53:36 --> Helper loaded: util_helper
INFO - 2018-07-31 02:53:36 --> Helper loaded: text_helper
INFO - 2018-07-31 02:53:36 --> Helper loaded: string_helper
INFO - 2018-07-31 02:53:36 --> Database Driver Class Initialized
DEBUG - 2018-07-31 02:53:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 02:53:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 02:53:36 --> Email Class Initialized
INFO - 2018-07-31 02:53:36 --> Controller Class Initialized
DEBUG - 2018-07-31 02:53:36 --> Programs MX_Controller Initialized
INFO - 2018-07-31 02:53:36 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-31 02:53:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-07-31 02:53:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-31 02:53:36 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-31 02:53:36 --> Login MX_Controller Initialized
DEBUG - 2018-07-31 02:53:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-31 02:53:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
INFO - 2018-07-31 02:53:36 --> Upload Class Initialized
INFO - 2018-07-31 02:53:36 --> Config Class Initialized
INFO - 2018-07-31 02:53:36 --> Hooks Class Initialized
DEBUG - 2018-07-31 02:53:36 --> UTF-8 Support Enabled
INFO - 2018-07-31 02:53:36 --> Utf8 Class Initialized
INFO - 2018-07-31 02:53:36 --> URI Class Initialized
INFO - 2018-07-31 02:53:37 --> Router Class Initialized
INFO - 2018-07-31 02:53:37 --> Output Class Initialized
INFO - 2018-07-31 02:53:37 --> Security Class Initialized
DEBUG - 2018-07-31 02:53:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 02:53:37 --> Input Class Initialized
INFO - 2018-07-31 02:53:37 --> Language Class Initialized
INFO - 2018-07-31 02:53:37 --> Language Class Initialized
INFO - 2018-07-31 02:53:37 --> Config Class Initialized
INFO - 2018-07-31 02:53:37 --> Loader Class Initialized
DEBUG - 2018-07-31 02:53:37 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-31 02:53:37 --> Helper loaded: url_helper
INFO - 2018-07-31 02:53:37 --> Helper loaded: form_helper
INFO - 2018-07-31 02:53:37 --> Helper loaded: date_helper
INFO - 2018-07-31 02:53:37 --> Helper loaded: util_helper
INFO - 2018-07-31 02:53:37 --> Helper loaded: text_helper
INFO - 2018-07-31 02:53:37 --> Helper loaded: string_helper
INFO - 2018-07-31 02:53:37 --> Database Driver Class Initialized
DEBUG - 2018-07-31 02:53:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 02:53:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 02:53:37 --> Email Class Initialized
INFO - 2018-07-31 02:53:37 --> Controller Class Initialized
DEBUG - 2018-07-31 02:53:37 --> Programs MX_Controller Initialized
INFO - 2018-07-31 02:53:37 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-31 02:53:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-07-31 02:53:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-31 02:53:37 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-31 02:53:37 --> Login MX_Controller Initialized
DEBUG - 2018-07-31 02:53:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-31 02:53:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-31 02:53:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-31 02:53:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-31 02:53:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-31 02:53:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-31 02:53:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/programs/programs.php
INFO - 2018-07-31 02:53:37 --> Final output sent to browser
DEBUG - 2018-07-31 02:53:37 --> Total execution time: 0.7002
INFO - 2018-07-31 02:53:38 --> Config Class Initialized
INFO - 2018-07-31 02:53:38 --> Hooks Class Initialized
DEBUG - 2018-07-31 02:53:38 --> UTF-8 Support Enabled
INFO - 2018-07-31 02:53:38 --> Utf8 Class Initialized
INFO - 2018-07-31 02:53:38 --> URI Class Initialized
INFO - 2018-07-31 02:53:38 --> Router Class Initialized
INFO - 2018-07-31 02:53:38 --> Output Class Initialized
INFO - 2018-07-31 02:53:38 --> Security Class Initialized
DEBUG - 2018-07-31 02:53:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 02:53:38 --> Input Class Initialized
INFO - 2018-07-31 02:53:38 --> Language Class Initialized
INFO - 2018-07-31 02:53:38 --> Language Class Initialized
INFO - 2018-07-31 02:53:38 --> Config Class Initialized
INFO - 2018-07-31 02:53:38 --> Loader Class Initialized
DEBUG - 2018-07-31 02:53:38 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-31 02:53:38 --> Helper loaded: url_helper
INFO - 2018-07-31 02:53:38 --> Helper loaded: form_helper
INFO - 2018-07-31 02:53:38 --> Helper loaded: date_helper
INFO - 2018-07-31 02:53:38 --> Helper loaded: util_helper
INFO - 2018-07-31 02:53:38 --> Helper loaded: text_helper
INFO - 2018-07-31 02:53:38 --> Helper loaded: string_helper
INFO - 2018-07-31 02:53:38 --> Database Driver Class Initialized
DEBUG - 2018-07-31 02:53:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 02:53:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 02:53:38 --> Email Class Initialized
INFO - 2018-07-31 02:53:38 --> Controller Class Initialized
DEBUG - 2018-07-31 02:53:38 --> Programs MX_Controller Initialized
INFO - 2018-07-31 02:53:38 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-31 02:53:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-07-31 02:53:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-31 02:53:38 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-31 02:53:38 --> Login MX_Controller Initialized
DEBUG - 2018-07-31 02:53:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-31 02:53:38 --> Final output sent to browser
DEBUG - 2018-07-31 02:53:38 --> Total execution time: 0.7468
INFO - 2018-07-31 02:56:00 --> Config Class Initialized
INFO - 2018-07-31 02:56:00 --> Hooks Class Initialized
DEBUG - 2018-07-31 02:56:01 --> UTF-8 Support Enabled
INFO - 2018-07-31 02:56:01 --> Utf8 Class Initialized
INFO - 2018-07-31 02:56:01 --> URI Class Initialized
INFO - 2018-07-31 02:56:01 --> Router Class Initialized
INFO - 2018-07-31 02:56:01 --> Output Class Initialized
INFO - 2018-07-31 02:56:01 --> Security Class Initialized
DEBUG - 2018-07-31 02:56:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 02:56:01 --> Input Class Initialized
INFO - 2018-07-31 02:56:01 --> Language Class Initialized
INFO - 2018-07-31 02:56:01 --> Language Class Initialized
INFO - 2018-07-31 02:56:01 --> Config Class Initialized
INFO - 2018-07-31 02:56:01 --> Loader Class Initialized
DEBUG - 2018-07-31 02:56:01 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-31 02:56:01 --> Helper loaded: url_helper
INFO - 2018-07-31 02:56:01 --> Helper loaded: form_helper
INFO - 2018-07-31 02:56:01 --> Helper loaded: date_helper
INFO - 2018-07-31 02:56:01 --> Helper loaded: util_helper
INFO - 2018-07-31 02:56:01 --> Helper loaded: text_helper
INFO - 2018-07-31 02:56:01 --> Helper loaded: string_helper
INFO - 2018-07-31 02:56:01 --> Database Driver Class Initialized
DEBUG - 2018-07-31 02:56:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 02:56:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 02:56:01 --> Email Class Initialized
INFO - 2018-07-31 02:56:01 --> Controller Class Initialized
DEBUG - 2018-07-31 02:56:01 --> Programs MX_Controller Initialized
INFO - 2018-07-31 02:56:01 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-31 02:56:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-07-31 02:56:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-31 02:56:01 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-31 02:56:01 --> Login MX_Controller Initialized
DEBUG - 2018-07-31 02:56:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-31 02:56:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-31 02:56:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-31 02:56:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-31 02:56:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-31 02:56:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-31 02:56:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/programs/create_program.php
INFO - 2018-07-31 02:56:01 --> Final output sent to browser
DEBUG - 2018-07-31 02:56:01 --> Total execution time: 0.6595
INFO - 2018-07-31 03:00:36 --> Config Class Initialized
INFO - 2018-07-31 03:00:36 --> Hooks Class Initialized
DEBUG - 2018-07-31 03:00:36 --> UTF-8 Support Enabled
INFO - 2018-07-31 03:00:36 --> Utf8 Class Initialized
INFO - 2018-07-31 03:00:36 --> URI Class Initialized
INFO - 2018-07-31 03:00:36 --> Router Class Initialized
INFO - 2018-07-31 03:00:36 --> Output Class Initialized
INFO - 2018-07-31 03:00:37 --> Security Class Initialized
DEBUG - 2018-07-31 03:00:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 03:00:37 --> Input Class Initialized
INFO - 2018-07-31 03:00:37 --> Language Class Initialized
INFO - 2018-07-31 03:00:37 --> Language Class Initialized
INFO - 2018-07-31 03:00:37 --> Config Class Initialized
INFO - 2018-07-31 03:00:37 --> Loader Class Initialized
DEBUG - 2018-07-31 03:00:37 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-31 03:00:37 --> Helper loaded: url_helper
INFO - 2018-07-31 03:00:37 --> Helper loaded: form_helper
INFO - 2018-07-31 03:00:37 --> Helper loaded: date_helper
INFO - 2018-07-31 03:00:37 --> Helper loaded: util_helper
INFO - 2018-07-31 03:00:37 --> Helper loaded: text_helper
INFO - 2018-07-31 03:00:37 --> Helper loaded: string_helper
INFO - 2018-07-31 03:00:37 --> Database Driver Class Initialized
DEBUG - 2018-07-31 03:00:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 03:00:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 03:00:37 --> Email Class Initialized
INFO - 2018-07-31 03:00:37 --> Controller Class Initialized
DEBUG - 2018-07-31 03:00:37 --> Programs MX_Controller Initialized
INFO - 2018-07-31 03:00:37 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-31 03:00:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-07-31 03:00:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-31 03:00:37 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-31 03:00:37 --> Login MX_Controller Initialized
DEBUG - 2018-07-31 03:00:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-31 03:00:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-31 03:00:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-31 03:00:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-31 03:00:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-31 03:00:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-31 03:00:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/programs/create_program.php
INFO - 2018-07-31 03:00:37 --> Final output sent to browser
DEBUG - 2018-07-31 03:00:37 --> Total execution time: 0.6295
INFO - 2018-07-31 03:00:37 --> Config Class Initialized
INFO - 2018-07-31 03:00:37 --> Hooks Class Initialized
DEBUG - 2018-07-31 03:00:37 --> UTF-8 Support Enabled
INFO - 2018-07-31 03:00:37 --> Utf8 Class Initialized
INFO - 2018-07-31 03:00:37 --> URI Class Initialized
INFO - 2018-07-31 03:00:37 --> Router Class Initialized
INFO - 2018-07-31 03:00:37 --> Output Class Initialized
INFO - 2018-07-31 03:00:37 --> Security Class Initialized
DEBUG - 2018-07-31 03:00:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 03:00:37 --> Input Class Initialized
INFO - 2018-07-31 03:00:37 --> Language Class Initialized
ERROR - 2018-07-31 03:00:38 --> 404 Page Not Found: /index
INFO - 2018-07-31 03:03:37 --> Config Class Initialized
INFO - 2018-07-31 03:03:37 --> Hooks Class Initialized
DEBUG - 2018-07-31 03:03:38 --> UTF-8 Support Enabled
INFO - 2018-07-31 03:03:38 --> Utf8 Class Initialized
INFO - 2018-07-31 03:03:38 --> URI Class Initialized
INFO - 2018-07-31 03:03:38 --> Router Class Initialized
INFO - 2018-07-31 03:03:38 --> Output Class Initialized
INFO - 2018-07-31 03:03:38 --> Security Class Initialized
DEBUG - 2018-07-31 03:03:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 03:03:38 --> Input Class Initialized
INFO - 2018-07-31 03:03:38 --> Language Class Initialized
INFO - 2018-07-31 03:03:38 --> Language Class Initialized
INFO - 2018-07-31 03:03:38 --> Config Class Initialized
INFO - 2018-07-31 03:03:38 --> Loader Class Initialized
DEBUG - 2018-07-31 03:03:38 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-31 03:03:38 --> Helper loaded: url_helper
INFO - 2018-07-31 03:03:38 --> Helper loaded: form_helper
INFO - 2018-07-31 03:03:38 --> Helper loaded: date_helper
INFO - 2018-07-31 03:03:38 --> Helper loaded: util_helper
INFO - 2018-07-31 03:03:38 --> Helper loaded: text_helper
INFO - 2018-07-31 03:03:38 --> Helper loaded: string_helper
INFO - 2018-07-31 03:03:38 --> Database Driver Class Initialized
DEBUG - 2018-07-31 03:03:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 03:03:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 03:03:38 --> Email Class Initialized
INFO - 2018-07-31 03:03:38 --> Controller Class Initialized
DEBUG - 2018-07-31 03:03:38 --> Programs MX_Controller Initialized
INFO - 2018-07-31 03:03:38 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-31 03:03:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-07-31 03:03:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-31 03:03:38 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-31 03:03:38 --> Login MX_Controller Initialized
DEBUG - 2018-07-31 03:03:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-31 03:03:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-31 03:03:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-31 03:03:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-31 03:03:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-31 03:03:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-31 03:03:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/programs/create_program.php
INFO - 2018-07-31 03:03:38 --> Final output sent to browser
DEBUG - 2018-07-31 03:03:38 --> Total execution time: 0.6398
INFO - 2018-07-31 03:03:39 --> Config Class Initialized
INFO - 2018-07-31 03:03:39 --> Hooks Class Initialized
DEBUG - 2018-07-31 03:03:39 --> UTF-8 Support Enabled
INFO - 2018-07-31 03:03:39 --> Utf8 Class Initialized
INFO - 2018-07-31 03:03:39 --> URI Class Initialized
INFO - 2018-07-31 03:03:39 --> Router Class Initialized
INFO - 2018-07-31 03:03:39 --> Output Class Initialized
INFO - 2018-07-31 03:03:39 --> Security Class Initialized
DEBUG - 2018-07-31 03:03:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 03:03:39 --> Input Class Initialized
INFO - 2018-07-31 03:03:39 --> Language Class Initialized
ERROR - 2018-07-31 03:03:39 --> 404 Page Not Found: /index
INFO - 2018-07-31 03:03:45 --> Config Class Initialized
INFO - 2018-07-31 03:03:45 --> Hooks Class Initialized
DEBUG - 2018-07-31 03:03:45 --> UTF-8 Support Enabled
INFO - 2018-07-31 03:03:45 --> Utf8 Class Initialized
INFO - 2018-07-31 03:03:45 --> URI Class Initialized
INFO - 2018-07-31 03:03:45 --> Router Class Initialized
INFO - 2018-07-31 03:03:45 --> Output Class Initialized
INFO - 2018-07-31 03:03:45 --> Security Class Initialized
DEBUG - 2018-07-31 03:03:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 03:03:45 --> Input Class Initialized
INFO - 2018-07-31 03:03:45 --> Language Class Initialized
INFO - 2018-07-31 03:03:45 --> Language Class Initialized
INFO - 2018-07-31 03:03:45 --> Config Class Initialized
INFO - 2018-07-31 03:03:45 --> Loader Class Initialized
DEBUG - 2018-07-31 03:03:45 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-31 03:03:45 --> Helper loaded: url_helper
INFO - 2018-07-31 03:03:45 --> Helper loaded: form_helper
INFO - 2018-07-31 03:03:45 --> Helper loaded: date_helper
INFO - 2018-07-31 03:03:45 --> Helper loaded: util_helper
INFO - 2018-07-31 03:03:45 --> Helper loaded: text_helper
INFO - 2018-07-31 03:03:45 --> Helper loaded: string_helper
INFO - 2018-07-31 03:03:45 --> Database Driver Class Initialized
DEBUG - 2018-07-31 03:03:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 03:03:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 03:03:45 --> Email Class Initialized
INFO - 2018-07-31 03:03:45 --> Controller Class Initialized
DEBUG - 2018-07-31 03:03:45 --> Programs MX_Controller Initialized
INFO - 2018-07-31 03:03:45 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-31 03:03:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-07-31 03:03:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-31 03:03:45 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-31 03:03:45 --> Login MX_Controller Initialized
DEBUG - 2018-07-31 03:03:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-31 03:03:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
INFO - 2018-07-31 03:03:45 --> Upload Class Initialized
ERROR - 2018-07-31 03:03:45 --> Severity: Warning --> unlink(E:\xampp\htdocs\consulting\assets/images/programs/1532985816.mp4): No such file or directory E:\xampp\htdocs\consulting\application\modules\admin\controllers\Programs.php 186
INFO - 2018-07-31 03:03:50 --> Config Class Initialized
INFO - 2018-07-31 03:03:50 --> Hooks Class Initialized
DEBUG - 2018-07-31 03:03:50 --> UTF-8 Support Enabled
INFO - 2018-07-31 03:03:50 --> Utf8 Class Initialized
INFO - 2018-07-31 03:03:50 --> URI Class Initialized
INFO - 2018-07-31 03:03:50 --> Router Class Initialized
INFO - 2018-07-31 03:03:50 --> Output Class Initialized
INFO - 2018-07-31 03:03:51 --> Security Class Initialized
DEBUG - 2018-07-31 03:03:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 03:03:51 --> Input Class Initialized
INFO - 2018-07-31 03:03:51 --> Language Class Initialized
ERROR - 2018-07-31 03:03:51 --> 404 Page Not Found: /index
INFO - 2018-07-31 03:03:55 --> Config Class Initialized
INFO - 2018-07-31 03:03:55 --> Hooks Class Initialized
DEBUG - 2018-07-31 03:03:55 --> UTF-8 Support Enabled
INFO - 2018-07-31 03:03:55 --> Utf8 Class Initialized
INFO - 2018-07-31 03:03:55 --> URI Class Initialized
INFO - 2018-07-31 03:03:55 --> Router Class Initialized
INFO - 2018-07-31 03:03:55 --> Output Class Initialized
INFO - 2018-07-31 03:03:55 --> Security Class Initialized
DEBUG - 2018-07-31 03:03:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 03:03:55 --> Input Class Initialized
INFO - 2018-07-31 03:03:55 --> Language Class Initialized
INFO - 2018-07-31 03:03:55 --> Language Class Initialized
INFO - 2018-07-31 03:03:55 --> Config Class Initialized
INFO - 2018-07-31 03:03:55 --> Loader Class Initialized
DEBUG - 2018-07-31 03:03:55 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-31 03:03:55 --> Helper loaded: url_helper
INFO - 2018-07-31 03:03:55 --> Helper loaded: form_helper
INFO - 2018-07-31 03:03:55 --> Helper loaded: date_helper
INFO - 2018-07-31 03:03:55 --> Helper loaded: util_helper
INFO - 2018-07-31 03:03:55 --> Helper loaded: text_helper
INFO - 2018-07-31 03:03:55 --> Helper loaded: string_helper
INFO - 2018-07-31 03:03:55 --> Database Driver Class Initialized
DEBUG - 2018-07-31 03:03:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 03:03:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 03:03:55 --> Email Class Initialized
INFO - 2018-07-31 03:03:55 --> Controller Class Initialized
DEBUG - 2018-07-31 03:03:55 --> Programs MX_Controller Initialized
INFO - 2018-07-31 03:03:55 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-31 03:03:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-07-31 03:03:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-31 03:03:55 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-31 03:03:55 --> Login MX_Controller Initialized
DEBUG - 2018-07-31 03:03:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-31 03:03:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
INFO - 2018-07-31 03:03:55 --> Upload Class Initialized
ERROR - 2018-07-31 03:03:55 --> Severity: Warning --> unlink(E:\xampp\htdocs\consulting\assets/images/programs/1532985816.mp4): No such file or directory E:\xampp\htdocs\consulting\application\modules\admin\controllers\Programs.php 186
INFO - 2018-07-31 03:17:50 --> Config Class Initialized
INFO - 2018-07-31 03:17:50 --> Hooks Class Initialized
DEBUG - 2018-07-31 03:17:50 --> UTF-8 Support Enabled
INFO - 2018-07-31 03:17:50 --> Utf8 Class Initialized
INFO - 2018-07-31 03:17:50 --> URI Class Initialized
INFO - 2018-07-31 03:17:50 --> Router Class Initialized
INFO - 2018-07-31 03:17:50 --> Output Class Initialized
INFO - 2018-07-31 03:17:50 --> Security Class Initialized
DEBUG - 2018-07-31 03:17:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 03:17:50 --> Input Class Initialized
INFO - 2018-07-31 03:17:50 --> Language Class Initialized
INFO - 2018-07-31 03:17:50 --> Language Class Initialized
INFO - 2018-07-31 03:17:50 --> Config Class Initialized
INFO - 2018-07-31 03:17:50 --> Loader Class Initialized
DEBUG - 2018-07-31 03:17:50 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-31 03:17:50 --> Helper loaded: url_helper
INFO - 2018-07-31 03:17:50 --> Helper loaded: form_helper
INFO - 2018-07-31 03:17:50 --> Helper loaded: date_helper
INFO - 2018-07-31 03:17:50 --> Helper loaded: util_helper
INFO - 2018-07-31 03:17:50 --> Helper loaded: text_helper
INFO - 2018-07-31 03:17:50 --> Helper loaded: string_helper
INFO - 2018-07-31 03:17:50 --> Database Driver Class Initialized
DEBUG - 2018-07-31 03:17:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 03:17:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 03:17:50 --> Email Class Initialized
INFO - 2018-07-31 03:17:50 --> Controller Class Initialized
DEBUG - 2018-07-31 03:17:50 --> Programs MX_Controller Initialized
INFO - 2018-07-31 03:17:50 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-31 03:17:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-07-31 03:17:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-31 03:17:50 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-31 03:17:50 --> Login MX_Controller Initialized
DEBUG - 2018-07-31 03:17:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-31 03:17:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
INFO - 2018-07-31 03:17:50 --> Upload Class Initialized
ERROR - 2018-07-31 03:17:50 --> Severity: Warning --> unlink(E:\xampp\htdocs\consulting\assets/images/programs/1532985816.mp4): No such file or directory E:\xampp\htdocs\consulting\application\modules\admin\controllers\Programs.php 186
ERROR - 2018-07-31 03:17:50 --> Severity: Notice --> Array to string conversion E:\xampp\htdocs\consulting\system\database\DB_driver.php 1525
ERROR - 2018-07-31 03:17:50 --> Query error: Unknown column 'Array' in 'field list' - Invalid query: UPDATE `programs` SET `program_name` = 'Name1', `program_description` = 'Description1', `prg_img_or_vid` = '0', `prg_img_vid_name` = Array
WHERE `program_id` = '5'
INFO - 2018-07-31 03:17:50 --> Language file loaded: language/english/db_lang.php
INFO - 2018-07-31 03:24:41 --> Config Class Initialized
INFO - 2018-07-31 03:24:41 --> Hooks Class Initialized
DEBUG - 2018-07-31 03:24:41 --> UTF-8 Support Enabled
INFO - 2018-07-31 03:24:41 --> Utf8 Class Initialized
INFO - 2018-07-31 03:24:41 --> URI Class Initialized
INFO - 2018-07-31 03:24:41 --> Router Class Initialized
INFO - 2018-07-31 03:24:41 --> Output Class Initialized
INFO - 2018-07-31 03:24:41 --> Security Class Initialized
DEBUG - 2018-07-31 03:24:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 03:24:41 --> Input Class Initialized
INFO - 2018-07-31 03:24:41 --> Language Class Initialized
INFO - 2018-07-31 03:24:41 --> Language Class Initialized
INFO - 2018-07-31 03:24:41 --> Config Class Initialized
INFO - 2018-07-31 03:24:41 --> Loader Class Initialized
DEBUG - 2018-07-31 03:24:41 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-31 03:24:41 --> Helper loaded: url_helper
INFO - 2018-07-31 03:24:41 --> Helper loaded: form_helper
INFO - 2018-07-31 03:24:41 --> Helper loaded: date_helper
INFO - 2018-07-31 03:24:41 --> Helper loaded: util_helper
INFO - 2018-07-31 03:24:41 --> Helper loaded: text_helper
INFO - 2018-07-31 03:24:41 --> Helper loaded: string_helper
INFO - 2018-07-31 03:24:41 --> Database Driver Class Initialized
DEBUG - 2018-07-31 03:24:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 03:24:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 03:24:41 --> Email Class Initialized
INFO - 2018-07-31 03:24:41 --> Controller Class Initialized
DEBUG - 2018-07-31 03:24:41 --> Programs MX_Controller Initialized
INFO - 2018-07-31 03:24:41 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-31 03:24:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-07-31 03:24:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-31 03:24:41 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-31 03:24:41 --> Login MX_Controller Initialized
DEBUG - 2018-07-31 03:24:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-31 03:24:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
INFO - 2018-07-31 03:24:41 --> Upload Class Initialized
INFO - 2018-07-31 03:26:44 --> Config Class Initialized
INFO - 2018-07-31 03:26:44 --> Hooks Class Initialized
DEBUG - 2018-07-31 03:26:44 --> UTF-8 Support Enabled
INFO - 2018-07-31 03:26:44 --> Utf8 Class Initialized
INFO - 2018-07-31 03:26:44 --> URI Class Initialized
INFO - 2018-07-31 03:26:44 --> Router Class Initialized
INFO - 2018-07-31 03:26:44 --> Output Class Initialized
INFO - 2018-07-31 03:26:44 --> Security Class Initialized
DEBUG - 2018-07-31 03:26:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 03:26:44 --> Input Class Initialized
INFO - 2018-07-31 03:26:44 --> Language Class Initialized
INFO - 2018-07-31 03:26:44 --> Language Class Initialized
INFO - 2018-07-31 03:26:44 --> Config Class Initialized
INFO - 2018-07-31 03:26:44 --> Loader Class Initialized
DEBUG - 2018-07-31 03:26:44 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-31 03:26:44 --> Helper loaded: url_helper
INFO - 2018-07-31 03:26:44 --> Helper loaded: form_helper
INFO - 2018-07-31 03:26:44 --> Helper loaded: date_helper
INFO - 2018-07-31 03:26:44 --> Helper loaded: util_helper
INFO - 2018-07-31 03:26:44 --> Helper loaded: text_helper
INFO - 2018-07-31 03:26:44 --> Helper loaded: string_helper
INFO - 2018-07-31 03:26:44 --> Database Driver Class Initialized
DEBUG - 2018-07-31 03:26:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 03:26:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 03:26:44 --> Email Class Initialized
INFO - 2018-07-31 03:26:44 --> Controller Class Initialized
DEBUG - 2018-07-31 03:26:44 --> Programs MX_Controller Initialized
INFO - 2018-07-31 03:26:44 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-31 03:26:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-07-31 03:26:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-31 03:26:44 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-31 03:26:44 --> Login MX_Controller Initialized
DEBUG - 2018-07-31 03:26:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-31 03:26:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
INFO - 2018-07-31 03:26:44 --> Upload Class Initialized
ERROR - 2018-07-31 03:26:44 --> Severity: Notice --> Array to string conversion E:\xampp\htdocs\consulting\system\database\DB_driver.php 1525
ERROR - 2018-07-31 03:26:44 --> Query error: Unknown column 'Array' in 'field list' - Invalid query: UPDATE `programs` SET `program_name` = 'Name1', `program_description` = 'Description1', `prg_img_or_vid` = '0', `prg_img_vid_name` = Array
WHERE `program_id` = '5'
INFO - 2018-07-31 03:26:44 --> Language file loaded: language/english/db_lang.php
INFO - 2018-07-31 03:27:19 --> Config Class Initialized
INFO - 2018-07-31 03:27:19 --> Hooks Class Initialized
DEBUG - 2018-07-31 03:27:19 --> UTF-8 Support Enabled
INFO - 2018-07-31 03:27:19 --> Utf8 Class Initialized
INFO - 2018-07-31 03:27:19 --> URI Class Initialized
INFO - 2018-07-31 03:27:19 --> Router Class Initialized
INFO - 2018-07-31 03:27:19 --> Output Class Initialized
INFO - 2018-07-31 03:27:19 --> Security Class Initialized
DEBUG - 2018-07-31 03:27:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 03:27:19 --> Input Class Initialized
INFO - 2018-07-31 03:27:19 --> Language Class Initialized
INFO - 2018-07-31 03:27:19 --> Language Class Initialized
INFO - 2018-07-31 03:27:19 --> Config Class Initialized
INFO - 2018-07-31 03:27:19 --> Loader Class Initialized
DEBUG - 2018-07-31 03:27:19 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-31 03:27:19 --> Helper loaded: url_helper
INFO - 2018-07-31 03:27:19 --> Helper loaded: form_helper
INFO - 2018-07-31 03:27:19 --> Helper loaded: date_helper
INFO - 2018-07-31 03:27:19 --> Helper loaded: util_helper
INFO - 2018-07-31 03:27:19 --> Helper loaded: text_helper
INFO - 2018-07-31 03:27:19 --> Helper loaded: string_helper
INFO - 2018-07-31 03:27:19 --> Database Driver Class Initialized
DEBUG - 2018-07-31 03:27:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 03:27:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 03:27:19 --> Email Class Initialized
INFO - 2018-07-31 03:27:19 --> Controller Class Initialized
DEBUG - 2018-07-31 03:27:19 --> Programs MX_Controller Initialized
INFO - 2018-07-31 03:27:19 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-31 03:27:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-07-31 03:27:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-31 03:27:19 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-31 03:27:19 --> Login MX_Controller Initialized
DEBUG - 2018-07-31 03:27:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-31 03:27:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
INFO - 2018-07-31 03:27:19 --> Upload Class Initialized
INFO - 2018-07-31 03:27:50 --> Config Class Initialized
INFO - 2018-07-31 03:27:50 --> Hooks Class Initialized
DEBUG - 2018-07-31 03:27:50 --> UTF-8 Support Enabled
INFO - 2018-07-31 03:27:50 --> Utf8 Class Initialized
INFO - 2018-07-31 03:27:50 --> URI Class Initialized
INFO - 2018-07-31 03:27:50 --> Router Class Initialized
INFO - 2018-07-31 03:27:50 --> Output Class Initialized
INFO - 2018-07-31 03:27:50 --> Security Class Initialized
DEBUG - 2018-07-31 03:27:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 03:27:50 --> Input Class Initialized
INFO - 2018-07-31 03:27:50 --> Language Class Initialized
INFO - 2018-07-31 03:27:50 --> Language Class Initialized
INFO - 2018-07-31 03:27:50 --> Config Class Initialized
INFO - 2018-07-31 03:27:50 --> Loader Class Initialized
DEBUG - 2018-07-31 03:27:50 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-31 03:27:50 --> Helper loaded: url_helper
INFO - 2018-07-31 03:27:50 --> Helper loaded: form_helper
INFO - 2018-07-31 03:27:50 --> Helper loaded: date_helper
INFO - 2018-07-31 03:27:50 --> Helper loaded: util_helper
INFO - 2018-07-31 03:27:50 --> Helper loaded: text_helper
INFO - 2018-07-31 03:27:50 --> Helper loaded: string_helper
INFO - 2018-07-31 03:27:51 --> Database Driver Class Initialized
DEBUG - 2018-07-31 03:27:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 03:27:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 03:27:51 --> Email Class Initialized
INFO - 2018-07-31 03:27:51 --> Controller Class Initialized
DEBUG - 2018-07-31 03:27:51 --> Programs MX_Controller Initialized
INFO - 2018-07-31 03:27:51 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-31 03:27:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-07-31 03:27:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-31 03:27:51 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-31 03:27:51 --> Login MX_Controller Initialized
DEBUG - 2018-07-31 03:27:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-31 03:27:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
INFO - 2018-07-31 03:27:51 --> Upload Class Initialized
INFO - 2018-07-31 03:28:23 --> Config Class Initialized
INFO - 2018-07-31 03:28:23 --> Hooks Class Initialized
DEBUG - 2018-07-31 03:28:23 --> UTF-8 Support Enabled
INFO - 2018-07-31 03:28:23 --> Utf8 Class Initialized
INFO - 2018-07-31 03:28:23 --> URI Class Initialized
INFO - 2018-07-31 03:28:23 --> Router Class Initialized
INFO - 2018-07-31 03:28:23 --> Output Class Initialized
INFO - 2018-07-31 03:28:23 --> Security Class Initialized
DEBUG - 2018-07-31 03:28:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 03:28:23 --> Input Class Initialized
INFO - 2018-07-31 03:28:23 --> Language Class Initialized
INFO - 2018-07-31 03:28:23 --> Language Class Initialized
INFO - 2018-07-31 03:28:23 --> Config Class Initialized
INFO - 2018-07-31 03:28:23 --> Loader Class Initialized
DEBUG - 2018-07-31 03:28:23 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-31 03:28:23 --> Helper loaded: url_helper
INFO - 2018-07-31 03:28:23 --> Helper loaded: form_helper
INFO - 2018-07-31 03:28:23 --> Helper loaded: date_helper
INFO - 2018-07-31 03:28:23 --> Helper loaded: util_helper
INFO - 2018-07-31 03:28:23 --> Helper loaded: text_helper
INFO - 2018-07-31 03:28:23 --> Helper loaded: string_helper
INFO - 2018-07-31 03:28:23 --> Database Driver Class Initialized
DEBUG - 2018-07-31 03:28:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 03:28:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 03:28:23 --> Email Class Initialized
INFO - 2018-07-31 03:28:23 --> Controller Class Initialized
DEBUG - 2018-07-31 03:28:23 --> Programs MX_Controller Initialized
INFO - 2018-07-31 03:28:23 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-31 03:28:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-07-31 03:28:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-31 03:28:23 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-31 03:28:23 --> Login MX_Controller Initialized
DEBUG - 2018-07-31 03:28:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-31 03:28:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
INFO - 2018-07-31 03:28:23 --> Upload Class Initialized
INFO - 2018-07-31 03:28:24 --> Config Class Initialized
INFO - 2018-07-31 03:28:24 --> Hooks Class Initialized
DEBUG - 2018-07-31 03:28:24 --> UTF-8 Support Enabled
INFO - 2018-07-31 03:28:24 --> Utf8 Class Initialized
INFO - 2018-07-31 03:28:24 --> URI Class Initialized
INFO - 2018-07-31 03:28:24 --> Router Class Initialized
INFO - 2018-07-31 03:28:24 --> Output Class Initialized
INFO - 2018-07-31 03:28:24 --> Security Class Initialized
DEBUG - 2018-07-31 03:28:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 03:28:24 --> Input Class Initialized
INFO - 2018-07-31 03:28:24 --> Language Class Initialized
INFO - 2018-07-31 03:28:24 --> Language Class Initialized
INFO - 2018-07-31 03:28:24 --> Config Class Initialized
INFO - 2018-07-31 03:28:24 --> Loader Class Initialized
DEBUG - 2018-07-31 03:28:24 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-31 03:28:24 --> Helper loaded: url_helper
INFO - 2018-07-31 03:28:24 --> Helper loaded: form_helper
INFO - 2018-07-31 03:28:24 --> Helper loaded: date_helper
INFO - 2018-07-31 03:28:24 --> Helper loaded: util_helper
INFO - 2018-07-31 03:28:24 --> Helper loaded: text_helper
INFO - 2018-07-31 03:28:24 --> Helper loaded: string_helper
INFO - 2018-07-31 03:28:24 --> Database Driver Class Initialized
DEBUG - 2018-07-31 03:28:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 03:28:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 03:28:24 --> Email Class Initialized
INFO - 2018-07-31 03:28:24 --> Controller Class Initialized
DEBUG - 2018-07-31 03:28:24 --> Programs MX_Controller Initialized
INFO - 2018-07-31 03:28:24 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-31 03:28:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-07-31 03:28:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-31 03:28:24 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-31 03:28:24 --> Login MX_Controller Initialized
DEBUG - 2018-07-31 03:28:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-31 03:28:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-31 03:28:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-31 03:28:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-31 03:28:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-31 03:28:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-31 03:28:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/programs/programs.php
INFO - 2018-07-31 03:28:24 --> Final output sent to browser
DEBUG - 2018-07-31 03:28:24 --> Total execution time: 0.7191
INFO - 2018-07-31 03:28:26 --> Config Class Initialized
INFO - 2018-07-31 03:28:26 --> Hooks Class Initialized
DEBUG - 2018-07-31 03:28:26 --> UTF-8 Support Enabled
INFO - 2018-07-31 03:28:26 --> Utf8 Class Initialized
INFO - 2018-07-31 03:28:26 --> URI Class Initialized
INFO - 2018-07-31 03:28:26 --> Router Class Initialized
INFO - 2018-07-31 03:28:26 --> Output Class Initialized
INFO - 2018-07-31 03:28:26 --> Security Class Initialized
DEBUG - 2018-07-31 03:28:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 03:28:26 --> Input Class Initialized
INFO - 2018-07-31 03:28:26 --> Language Class Initialized
INFO - 2018-07-31 03:28:26 --> Language Class Initialized
INFO - 2018-07-31 03:28:26 --> Config Class Initialized
INFO - 2018-07-31 03:28:26 --> Loader Class Initialized
DEBUG - 2018-07-31 03:28:26 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-31 03:28:26 --> Helper loaded: url_helper
INFO - 2018-07-31 03:28:26 --> Helper loaded: form_helper
INFO - 2018-07-31 03:28:26 --> Helper loaded: date_helper
INFO - 2018-07-31 03:28:26 --> Helper loaded: util_helper
INFO - 2018-07-31 03:28:26 --> Helper loaded: text_helper
INFO - 2018-07-31 03:28:26 --> Helper loaded: string_helper
INFO - 2018-07-31 03:28:26 --> Database Driver Class Initialized
DEBUG - 2018-07-31 03:28:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 03:28:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 03:28:26 --> Email Class Initialized
INFO - 2018-07-31 03:28:26 --> Controller Class Initialized
DEBUG - 2018-07-31 03:28:26 --> Programs MX_Controller Initialized
INFO - 2018-07-31 03:28:26 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-31 03:28:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-07-31 03:28:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-31 03:28:26 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-31 03:28:26 --> Login MX_Controller Initialized
DEBUG - 2018-07-31 03:28:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-31 03:28:26 --> Final output sent to browser
DEBUG - 2018-07-31 03:28:26 --> Total execution time: 0.7673
INFO - 2018-07-31 03:28:30 --> Config Class Initialized
INFO - 2018-07-31 03:28:30 --> Hooks Class Initialized
DEBUG - 2018-07-31 03:28:30 --> UTF-8 Support Enabled
INFO - 2018-07-31 03:28:30 --> Utf8 Class Initialized
INFO - 2018-07-31 03:28:30 --> URI Class Initialized
INFO - 2018-07-31 03:28:30 --> Router Class Initialized
INFO - 2018-07-31 03:28:30 --> Output Class Initialized
INFO - 2018-07-31 03:28:30 --> Security Class Initialized
DEBUG - 2018-07-31 03:28:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 03:28:30 --> Input Class Initialized
INFO - 2018-07-31 03:28:31 --> Language Class Initialized
INFO - 2018-07-31 03:28:31 --> Language Class Initialized
INFO - 2018-07-31 03:28:31 --> Config Class Initialized
INFO - 2018-07-31 03:28:31 --> Loader Class Initialized
DEBUG - 2018-07-31 03:28:31 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-31 03:28:31 --> Helper loaded: url_helper
INFO - 2018-07-31 03:28:31 --> Helper loaded: form_helper
INFO - 2018-07-31 03:28:31 --> Helper loaded: date_helper
INFO - 2018-07-31 03:28:31 --> Helper loaded: util_helper
INFO - 2018-07-31 03:28:31 --> Helper loaded: text_helper
INFO - 2018-07-31 03:28:31 --> Helper loaded: string_helper
INFO - 2018-07-31 03:28:31 --> Database Driver Class Initialized
DEBUG - 2018-07-31 03:28:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 03:28:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 03:28:31 --> Email Class Initialized
INFO - 2018-07-31 03:28:31 --> Controller Class Initialized
DEBUG - 2018-07-31 03:28:31 --> Programs MX_Controller Initialized
INFO - 2018-07-31 03:28:31 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-31 03:28:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-07-31 03:28:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-31 03:28:31 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-31 03:28:31 --> Login MX_Controller Initialized
DEBUG - 2018-07-31 03:28:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-31 03:28:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-31 03:28:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-31 03:28:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-31 03:28:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-31 03:28:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-31 03:28:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/programs/create_program.php
INFO - 2018-07-31 03:28:31 --> Final output sent to browser
DEBUG - 2018-07-31 03:28:31 --> Total execution time: 0.6303
INFO - 2018-07-31 03:28:55 --> Config Class Initialized
INFO - 2018-07-31 03:28:55 --> Hooks Class Initialized
DEBUG - 2018-07-31 03:28:55 --> UTF-8 Support Enabled
INFO - 2018-07-31 03:28:55 --> Utf8 Class Initialized
INFO - 2018-07-31 03:28:55 --> URI Class Initialized
INFO - 2018-07-31 03:28:55 --> Router Class Initialized
INFO - 2018-07-31 03:28:55 --> Output Class Initialized
INFO - 2018-07-31 03:28:55 --> Security Class Initialized
DEBUG - 2018-07-31 03:28:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 03:28:55 --> Input Class Initialized
INFO - 2018-07-31 03:28:55 --> Language Class Initialized
INFO - 2018-07-31 03:28:55 --> Language Class Initialized
INFO - 2018-07-31 03:28:55 --> Config Class Initialized
INFO - 2018-07-31 03:28:55 --> Loader Class Initialized
DEBUG - 2018-07-31 03:28:55 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-31 03:28:55 --> Helper loaded: url_helper
INFO - 2018-07-31 03:28:55 --> Helper loaded: form_helper
INFO - 2018-07-31 03:28:55 --> Helper loaded: date_helper
INFO - 2018-07-31 03:28:55 --> Helper loaded: util_helper
INFO - 2018-07-31 03:28:56 --> Helper loaded: text_helper
INFO - 2018-07-31 03:28:56 --> Helper loaded: string_helper
INFO - 2018-07-31 03:28:56 --> Database Driver Class Initialized
DEBUG - 2018-07-31 03:28:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 03:28:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 03:28:56 --> Email Class Initialized
INFO - 2018-07-31 03:28:56 --> Controller Class Initialized
DEBUG - 2018-07-31 03:28:56 --> Programs MX_Controller Initialized
INFO - 2018-07-31 03:28:56 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-31 03:28:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-07-31 03:28:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-31 03:28:56 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-31 03:28:56 --> Login MX_Controller Initialized
DEBUG - 2018-07-31 03:28:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-31 03:28:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
INFO - 2018-07-31 03:28:56 --> Upload Class Initialized
INFO - 2018-07-31 03:28:56 --> Config Class Initialized
INFO - 2018-07-31 03:28:56 --> Hooks Class Initialized
DEBUG - 2018-07-31 03:28:56 --> UTF-8 Support Enabled
INFO - 2018-07-31 03:28:56 --> Utf8 Class Initialized
INFO - 2018-07-31 03:28:56 --> URI Class Initialized
INFO - 2018-07-31 03:28:56 --> Router Class Initialized
INFO - 2018-07-31 03:28:56 --> Output Class Initialized
INFO - 2018-07-31 03:28:56 --> Security Class Initialized
DEBUG - 2018-07-31 03:28:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 03:28:56 --> Input Class Initialized
INFO - 2018-07-31 03:28:56 --> Language Class Initialized
INFO - 2018-07-31 03:28:56 --> Language Class Initialized
INFO - 2018-07-31 03:28:56 --> Config Class Initialized
INFO - 2018-07-31 03:28:56 --> Loader Class Initialized
DEBUG - 2018-07-31 03:28:56 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-31 03:28:56 --> Helper loaded: url_helper
INFO - 2018-07-31 03:28:56 --> Helper loaded: form_helper
INFO - 2018-07-31 03:28:56 --> Helper loaded: date_helper
INFO - 2018-07-31 03:28:56 --> Helper loaded: util_helper
INFO - 2018-07-31 03:28:56 --> Helper loaded: text_helper
INFO - 2018-07-31 03:28:56 --> Helper loaded: string_helper
INFO - 2018-07-31 03:28:56 --> Database Driver Class Initialized
DEBUG - 2018-07-31 03:28:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 03:28:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 03:28:56 --> Email Class Initialized
INFO - 2018-07-31 03:28:56 --> Controller Class Initialized
DEBUG - 2018-07-31 03:28:56 --> Programs MX_Controller Initialized
INFO - 2018-07-31 03:28:56 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-31 03:28:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-07-31 03:28:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-31 03:28:56 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-31 03:28:56 --> Login MX_Controller Initialized
DEBUG - 2018-07-31 03:28:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-31 03:28:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-31 03:28:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-31 03:28:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-31 03:28:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-31 03:28:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-31 03:28:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/programs/programs.php
INFO - 2018-07-31 03:28:57 --> Final output sent to browser
DEBUG - 2018-07-31 03:28:57 --> Total execution time: 0.7109
INFO - 2018-07-31 03:28:57 --> Config Class Initialized
INFO - 2018-07-31 03:28:57 --> Hooks Class Initialized
DEBUG - 2018-07-31 03:28:57 --> UTF-8 Support Enabled
INFO - 2018-07-31 03:28:57 --> Utf8 Class Initialized
INFO - 2018-07-31 03:28:57 --> URI Class Initialized
INFO - 2018-07-31 03:28:57 --> Router Class Initialized
INFO - 2018-07-31 03:28:57 --> Output Class Initialized
INFO - 2018-07-31 03:28:57 --> Security Class Initialized
DEBUG - 2018-07-31 03:28:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 03:28:57 --> Input Class Initialized
INFO - 2018-07-31 03:28:57 --> Language Class Initialized
INFO - 2018-07-31 03:28:57 --> Language Class Initialized
INFO - 2018-07-31 03:28:57 --> Config Class Initialized
INFO - 2018-07-31 03:28:57 --> Loader Class Initialized
DEBUG - 2018-07-31 03:28:58 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-31 03:28:58 --> Helper loaded: url_helper
INFO - 2018-07-31 03:28:58 --> Helper loaded: form_helper
INFO - 2018-07-31 03:28:58 --> Helper loaded: date_helper
INFO - 2018-07-31 03:28:58 --> Helper loaded: util_helper
INFO - 2018-07-31 03:28:58 --> Helper loaded: text_helper
INFO - 2018-07-31 03:28:58 --> Helper loaded: string_helper
INFO - 2018-07-31 03:28:58 --> Database Driver Class Initialized
DEBUG - 2018-07-31 03:28:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 03:28:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 03:28:58 --> Email Class Initialized
INFO - 2018-07-31 03:28:58 --> Controller Class Initialized
DEBUG - 2018-07-31 03:28:58 --> Programs MX_Controller Initialized
INFO - 2018-07-31 03:28:58 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-31 03:28:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-07-31 03:28:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-31 03:28:58 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-31 03:28:58 --> Login MX_Controller Initialized
DEBUG - 2018-07-31 03:28:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-31 03:28:58 --> Final output sent to browser
DEBUG - 2018-07-31 03:28:58 --> Total execution time: 0.7589
INFO - 2018-07-31 03:28:59 --> Config Class Initialized
INFO - 2018-07-31 03:28:59 --> Hooks Class Initialized
DEBUG - 2018-07-31 03:28:59 --> UTF-8 Support Enabled
INFO - 2018-07-31 03:28:59 --> Utf8 Class Initialized
INFO - 2018-07-31 03:28:59 --> URI Class Initialized
INFO - 2018-07-31 03:28:59 --> Router Class Initialized
INFO - 2018-07-31 03:28:59 --> Output Class Initialized
INFO - 2018-07-31 03:28:59 --> Security Class Initialized
DEBUG - 2018-07-31 03:28:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 03:28:59 --> Input Class Initialized
INFO - 2018-07-31 03:28:59 --> Language Class Initialized
INFO - 2018-07-31 03:28:59 --> Language Class Initialized
INFO - 2018-07-31 03:28:59 --> Config Class Initialized
INFO - 2018-07-31 03:28:59 --> Loader Class Initialized
DEBUG - 2018-07-31 03:28:59 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-31 03:28:59 --> Helper loaded: url_helper
INFO - 2018-07-31 03:28:59 --> Helper loaded: form_helper
INFO - 2018-07-31 03:28:59 --> Helper loaded: date_helper
INFO - 2018-07-31 03:28:59 --> Helper loaded: util_helper
INFO - 2018-07-31 03:28:59 --> Helper loaded: text_helper
INFO - 2018-07-31 03:28:59 --> Helper loaded: string_helper
INFO - 2018-07-31 03:28:59 --> Database Driver Class Initialized
DEBUG - 2018-07-31 03:28:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 03:28:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 03:29:00 --> Email Class Initialized
INFO - 2018-07-31 03:29:00 --> Controller Class Initialized
DEBUG - 2018-07-31 03:29:00 --> Programs MX_Controller Initialized
INFO - 2018-07-31 03:29:00 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-31 03:29:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-07-31 03:29:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-31 03:29:00 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-31 03:29:00 --> Login MX_Controller Initialized
DEBUG - 2018-07-31 03:29:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-31 03:29:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-31 03:29:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-31 03:29:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-31 03:29:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-31 03:29:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-31 03:29:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/programs/create_program.php
INFO - 2018-07-31 03:29:00 --> Final output sent to browser
DEBUG - 2018-07-31 03:29:00 --> Total execution time: 0.6532
INFO - 2018-07-31 03:29:50 --> Config Class Initialized
INFO - 2018-07-31 03:29:50 --> Hooks Class Initialized
DEBUG - 2018-07-31 03:29:50 --> UTF-8 Support Enabled
INFO - 2018-07-31 03:29:50 --> Utf8 Class Initialized
INFO - 2018-07-31 03:29:50 --> URI Class Initialized
INFO - 2018-07-31 03:29:50 --> Router Class Initialized
INFO - 2018-07-31 03:29:50 --> Output Class Initialized
INFO - 2018-07-31 03:29:50 --> Security Class Initialized
DEBUG - 2018-07-31 03:29:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 03:29:50 --> Input Class Initialized
INFO - 2018-07-31 03:29:50 --> Language Class Initialized
INFO - 2018-07-31 03:29:50 --> Language Class Initialized
INFO - 2018-07-31 03:29:50 --> Config Class Initialized
INFO - 2018-07-31 03:29:50 --> Loader Class Initialized
DEBUG - 2018-07-31 03:29:50 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-31 03:29:50 --> Helper loaded: url_helper
INFO - 2018-07-31 03:29:50 --> Helper loaded: form_helper
INFO - 2018-07-31 03:29:50 --> Helper loaded: date_helper
INFO - 2018-07-31 03:29:50 --> Helper loaded: util_helper
INFO - 2018-07-31 03:29:50 --> Helper loaded: text_helper
INFO - 2018-07-31 03:29:50 --> Helper loaded: string_helper
INFO - 2018-07-31 03:29:50 --> Database Driver Class Initialized
DEBUG - 2018-07-31 03:29:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 03:29:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 03:29:51 --> Email Class Initialized
INFO - 2018-07-31 03:29:51 --> Controller Class Initialized
DEBUG - 2018-07-31 03:29:51 --> Programs MX_Controller Initialized
INFO - 2018-07-31 03:29:51 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-31 03:29:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-07-31 03:29:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-31 03:29:51 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-31 03:29:51 --> Login MX_Controller Initialized
DEBUG - 2018-07-31 03:29:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-31 03:29:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-31 03:29:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-31 03:29:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-31 03:29:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-31 03:29:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-31 03:29:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/programs/create_program.php
INFO - 2018-07-31 03:29:51 --> Final output sent to browser
DEBUG - 2018-07-31 03:29:51 --> Total execution time: 0.6200
INFO - 2018-07-31 03:30:08 --> Config Class Initialized
INFO - 2018-07-31 03:30:08 --> Hooks Class Initialized
DEBUG - 2018-07-31 03:30:08 --> UTF-8 Support Enabled
INFO - 2018-07-31 03:30:08 --> Utf8 Class Initialized
INFO - 2018-07-31 03:30:09 --> URI Class Initialized
INFO - 2018-07-31 03:30:09 --> Router Class Initialized
INFO - 2018-07-31 03:30:09 --> Output Class Initialized
INFO - 2018-07-31 03:30:09 --> Security Class Initialized
DEBUG - 2018-07-31 03:30:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 03:30:09 --> Input Class Initialized
INFO - 2018-07-31 03:30:09 --> Language Class Initialized
ERROR - 2018-07-31 03:30:09 --> 404 Page Not Found: /index
INFO - 2018-07-31 03:30:16 --> Config Class Initialized
INFO - 2018-07-31 03:30:16 --> Hooks Class Initialized
DEBUG - 2018-07-31 03:30:16 --> UTF-8 Support Enabled
INFO - 2018-07-31 03:30:16 --> Utf8 Class Initialized
INFO - 2018-07-31 03:30:16 --> URI Class Initialized
INFO - 2018-07-31 03:30:16 --> Router Class Initialized
INFO - 2018-07-31 03:30:16 --> Output Class Initialized
INFO - 2018-07-31 03:30:16 --> Security Class Initialized
DEBUG - 2018-07-31 03:30:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 03:30:16 --> Input Class Initialized
INFO - 2018-07-31 03:30:16 --> Language Class Initialized
INFO - 2018-07-31 03:30:16 --> Language Class Initialized
INFO - 2018-07-31 03:30:16 --> Config Class Initialized
INFO - 2018-07-31 03:30:16 --> Loader Class Initialized
DEBUG - 2018-07-31 03:30:16 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-31 03:30:16 --> Helper loaded: url_helper
INFO - 2018-07-31 03:30:16 --> Helper loaded: form_helper
INFO - 2018-07-31 03:30:16 --> Helper loaded: date_helper
INFO - 2018-07-31 03:30:16 --> Helper loaded: util_helper
INFO - 2018-07-31 03:30:16 --> Helper loaded: text_helper
INFO - 2018-07-31 03:30:16 --> Helper loaded: string_helper
INFO - 2018-07-31 03:30:16 --> Database Driver Class Initialized
DEBUG - 2018-07-31 03:30:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 03:30:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 03:30:16 --> Email Class Initialized
INFO - 2018-07-31 03:30:17 --> Controller Class Initialized
DEBUG - 2018-07-31 03:30:17 --> Programs MX_Controller Initialized
INFO - 2018-07-31 03:30:17 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-31 03:30:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-07-31 03:30:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-31 03:30:17 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-31 03:30:17 --> Login MX_Controller Initialized
DEBUG - 2018-07-31 03:30:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-31 03:30:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
INFO - 2018-07-31 03:30:17 --> Upload Class Initialized
INFO - 2018-07-31 03:30:33 --> Config Class Initialized
INFO - 2018-07-31 03:30:33 --> Hooks Class Initialized
DEBUG - 2018-07-31 03:30:33 --> UTF-8 Support Enabled
INFO - 2018-07-31 03:30:33 --> Utf8 Class Initialized
INFO - 2018-07-31 03:30:33 --> URI Class Initialized
INFO - 2018-07-31 03:30:33 --> Router Class Initialized
INFO - 2018-07-31 03:30:33 --> Output Class Initialized
INFO - 2018-07-31 03:30:33 --> Security Class Initialized
DEBUG - 2018-07-31 03:30:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 03:30:33 --> Input Class Initialized
INFO - 2018-07-31 03:30:33 --> Language Class Initialized
INFO - 2018-07-31 03:30:33 --> Language Class Initialized
INFO - 2018-07-31 03:30:33 --> Config Class Initialized
INFO - 2018-07-31 03:30:33 --> Loader Class Initialized
DEBUG - 2018-07-31 03:30:33 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-31 03:30:33 --> Helper loaded: url_helper
INFO - 2018-07-31 03:30:33 --> Helper loaded: form_helper
INFO - 2018-07-31 03:30:33 --> Helper loaded: date_helper
INFO - 2018-07-31 03:30:33 --> Helper loaded: util_helper
INFO - 2018-07-31 03:30:33 --> Helper loaded: text_helper
INFO - 2018-07-31 03:30:33 --> Helper loaded: string_helper
INFO - 2018-07-31 03:30:33 --> Database Driver Class Initialized
DEBUG - 2018-07-31 03:30:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 03:30:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 03:30:33 --> Email Class Initialized
INFO - 2018-07-31 03:30:33 --> Controller Class Initialized
DEBUG - 2018-07-31 03:30:33 --> Programs MX_Controller Initialized
INFO - 2018-07-31 03:30:33 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-31 03:30:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-07-31 03:30:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-31 03:30:33 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-31 03:30:33 --> Login MX_Controller Initialized
DEBUG - 2018-07-31 03:30:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-31 03:30:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
INFO - 2018-07-31 03:30:33 --> Upload Class Initialized
INFO - 2018-07-31 03:30:59 --> Config Class Initialized
INFO - 2018-07-31 03:30:59 --> Hooks Class Initialized
DEBUG - 2018-07-31 03:30:59 --> UTF-8 Support Enabled
INFO - 2018-07-31 03:30:59 --> Utf8 Class Initialized
INFO - 2018-07-31 03:30:59 --> URI Class Initialized
INFO - 2018-07-31 03:30:59 --> Router Class Initialized
INFO - 2018-07-31 03:30:59 --> Output Class Initialized
INFO - 2018-07-31 03:30:59 --> Security Class Initialized
DEBUG - 2018-07-31 03:30:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 03:30:59 --> Input Class Initialized
INFO - 2018-07-31 03:30:59 --> Language Class Initialized
INFO - 2018-07-31 03:30:59 --> Language Class Initialized
INFO - 2018-07-31 03:30:59 --> Config Class Initialized
INFO - 2018-07-31 03:30:59 --> Loader Class Initialized
DEBUG - 2018-07-31 03:30:59 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-31 03:30:59 --> Helper loaded: url_helper
INFO - 2018-07-31 03:30:59 --> Helper loaded: form_helper
INFO - 2018-07-31 03:30:59 --> Helper loaded: date_helper
INFO - 2018-07-31 03:30:59 --> Helper loaded: util_helper
INFO - 2018-07-31 03:30:59 --> Helper loaded: text_helper
INFO - 2018-07-31 03:30:59 --> Helper loaded: string_helper
INFO - 2018-07-31 03:30:59 --> Database Driver Class Initialized
DEBUG - 2018-07-31 03:30:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 03:30:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 03:30:59 --> Email Class Initialized
INFO - 2018-07-31 03:30:59 --> Controller Class Initialized
DEBUG - 2018-07-31 03:30:59 --> Programs MX_Controller Initialized
INFO - 2018-07-31 03:30:59 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-31 03:31:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-07-31 03:31:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-31 03:31:00 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-31 03:31:00 --> Login MX_Controller Initialized
DEBUG - 2018-07-31 03:31:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-31 03:31:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
INFO - 2018-07-31 03:31:00 --> Upload Class Initialized
INFO - 2018-07-31 03:31:25 --> Config Class Initialized
INFO - 2018-07-31 03:31:25 --> Hooks Class Initialized
DEBUG - 2018-07-31 03:31:25 --> UTF-8 Support Enabled
INFO - 2018-07-31 03:31:25 --> Utf8 Class Initialized
INFO - 2018-07-31 03:31:25 --> URI Class Initialized
INFO - 2018-07-31 03:31:25 --> Router Class Initialized
INFO - 2018-07-31 03:31:25 --> Output Class Initialized
INFO - 2018-07-31 03:31:25 --> Security Class Initialized
DEBUG - 2018-07-31 03:31:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 03:31:25 --> Input Class Initialized
INFO - 2018-07-31 03:31:25 --> Language Class Initialized
INFO - 2018-07-31 03:31:25 --> Language Class Initialized
INFO - 2018-07-31 03:31:25 --> Config Class Initialized
INFO - 2018-07-31 03:31:25 --> Loader Class Initialized
DEBUG - 2018-07-31 03:31:25 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-31 03:31:25 --> Helper loaded: url_helper
INFO - 2018-07-31 03:31:25 --> Helper loaded: form_helper
INFO - 2018-07-31 03:31:25 --> Helper loaded: date_helper
INFO - 2018-07-31 03:31:25 --> Helper loaded: util_helper
INFO - 2018-07-31 03:31:25 --> Helper loaded: text_helper
INFO - 2018-07-31 03:31:25 --> Helper loaded: string_helper
INFO - 2018-07-31 03:31:25 --> Database Driver Class Initialized
DEBUG - 2018-07-31 03:31:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 03:31:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 03:31:25 --> Email Class Initialized
INFO - 2018-07-31 03:31:25 --> Controller Class Initialized
DEBUG - 2018-07-31 03:31:25 --> Programs MX_Controller Initialized
INFO - 2018-07-31 03:31:25 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-31 03:31:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-07-31 03:31:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-31 03:31:26 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-31 03:31:26 --> Login MX_Controller Initialized
DEBUG - 2018-07-31 03:31:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-31 03:31:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
INFO - 2018-07-31 03:31:26 --> Upload Class Initialized
INFO - 2018-07-31 03:31:40 --> Config Class Initialized
INFO - 2018-07-31 03:31:40 --> Hooks Class Initialized
DEBUG - 2018-07-31 03:31:40 --> UTF-8 Support Enabled
INFO - 2018-07-31 03:31:40 --> Utf8 Class Initialized
INFO - 2018-07-31 03:31:40 --> URI Class Initialized
INFO - 2018-07-31 03:31:40 --> Router Class Initialized
INFO - 2018-07-31 03:31:40 --> Output Class Initialized
INFO - 2018-07-31 03:31:40 --> Security Class Initialized
DEBUG - 2018-07-31 03:31:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 03:31:40 --> Input Class Initialized
INFO - 2018-07-31 03:31:40 --> Language Class Initialized
INFO - 2018-07-31 03:31:40 --> Language Class Initialized
INFO - 2018-07-31 03:31:40 --> Config Class Initialized
INFO - 2018-07-31 03:31:40 --> Loader Class Initialized
DEBUG - 2018-07-31 03:31:40 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-31 03:31:40 --> Helper loaded: url_helper
INFO - 2018-07-31 03:31:40 --> Helper loaded: form_helper
INFO - 2018-07-31 03:31:40 --> Helper loaded: date_helper
INFO - 2018-07-31 03:31:40 --> Helper loaded: util_helper
INFO - 2018-07-31 03:31:40 --> Helper loaded: text_helper
INFO - 2018-07-31 03:31:40 --> Helper loaded: string_helper
INFO - 2018-07-31 03:31:40 --> Database Driver Class Initialized
DEBUG - 2018-07-31 03:31:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 03:31:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 03:31:40 --> Email Class Initialized
INFO - 2018-07-31 03:31:40 --> Controller Class Initialized
DEBUG - 2018-07-31 03:31:40 --> Programs MX_Controller Initialized
INFO - 2018-07-31 03:31:40 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-31 03:31:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-07-31 03:31:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-31 03:31:40 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-31 03:31:41 --> Login MX_Controller Initialized
DEBUG - 2018-07-31 03:31:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-31 03:31:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
INFO - 2018-07-31 03:31:41 --> Upload Class Initialized
INFO - 2018-07-31 03:31:41 --> Config Class Initialized
INFO - 2018-07-31 03:31:41 --> Hooks Class Initialized
DEBUG - 2018-07-31 03:31:41 --> UTF-8 Support Enabled
INFO - 2018-07-31 03:31:41 --> Utf8 Class Initialized
INFO - 2018-07-31 03:31:41 --> URI Class Initialized
INFO - 2018-07-31 03:31:41 --> Router Class Initialized
INFO - 2018-07-31 03:31:41 --> Output Class Initialized
INFO - 2018-07-31 03:31:41 --> Security Class Initialized
DEBUG - 2018-07-31 03:31:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 03:31:41 --> Input Class Initialized
INFO - 2018-07-31 03:31:41 --> Language Class Initialized
INFO - 2018-07-31 03:31:41 --> Language Class Initialized
INFO - 2018-07-31 03:31:41 --> Config Class Initialized
INFO - 2018-07-31 03:31:41 --> Loader Class Initialized
DEBUG - 2018-07-31 03:31:41 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-31 03:31:41 --> Helper loaded: url_helper
INFO - 2018-07-31 03:31:41 --> Helper loaded: form_helper
INFO - 2018-07-31 03:31:41 --> Helper loaded: date_helper
INFO - 2018-07-31 03:31:41 --> Helper loaded: util_helper
INFO - 2018-07-31 03:31:41 --> Helper loaded: text_helper
INFO - 2018-07-31 03:31:41 --> Helper loaded: string_helper
INFO - 2018-07-31 03:31:41 --> Database Driver Class Initialized
DEBUG - 2018-07-31 03:31:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 03:31:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 03:31:41 --> Email Class Initialized
INFO - 2018-07-31 03:31:41 --> Controller Class Initialized
DEBUG - 2018-07-31 03:31:41 --> Programs MX_Controller Initialized
INFO - 2018-07-31 03:31:41 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-31 03:31:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-07-31 03:31:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-31 03:31:41 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-31 03:31:41 --> Login MX_Controller Initialized
DEBUG - 2018-07-31 03:31:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-31 03:31:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-31 03:31:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-31 03:31:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-31 03:31:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-31 03:31:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-31 03:31:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/programs/programs.php
INFO - 2018-07-31 03:31:41 --> Final output sent to browser
DEBUG - 2018-07-31 03:31:41 --> Total execution time: 0.7258
INFO - 2018-07-31 03:31:42 --> Config Class Initialized
INFO - 2018-07-31 03:31:42 --> Hooks Class Initialized
DEBUG - 2018-07-31 03:31:42 --> UTF-8 Support Enabled
INFO - 2018-07-31 03:31:42 --> Utf8 Class Initialized
INFO - 2018-07-31 03:31:42 --> URI Class Initialized
INFO - 2018-07-31 03:31:42 --> Router Class Initialized
INFO - 2018-07-31 03:31:42 --> Output Class Initialized
INFO - 2018-07-31 03:31:42 --> Security Class Initialized
DEBUG - 2018-07-31 03:31:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 03:31:42 --> Input Class Initialized
INFO - 2018-07-31 03:31:42 --> Language Class Initialized
INFO - 2018-07-31 03:31:42 --> Language Class Initialized
INFO - 2018-07-31 03:31:42 --> Config Class Initialized
INFO - 2018-07-31 03:31:42 --> Loader Class Initialized
DEBUG - 2018-07-31 03:31:42 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-31 03:31:42 --> Helper loaded: url_helper
INFO - 2018-07-31 03:31:42 --> Helper loaded: form_helper
INFO - 2018-07-31 03:31:43 --> Helper loaded: date_helper
INFO - 2018-07-31 03:31:43 --> Helper loaded: util_helper
INFO - 2018-07-31 03:31:43 --> Helper loaded: text_helper
INFO - 2018-07-31 03:31:43 --> Helper loaded: string_helper
INFO - 2018-07-31 03:31:43 --> Database Driver Class Initialized
DEBUG - 2018-07-31 03:31:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 03:31:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 03:31:43 --> Email Class Initialized
INFO - 2018-07-31 03:31:43 --> Controller Class Initialized
DEBUG - 2018-07-31 03:31:43 --> Programs MX_Controller Initialized
INFO - 2018-07-31 03:31:43 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-31 03:31:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-07-31 03:31:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-31 03:31:43 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-31 03:31:43 --> Login MX_Controller Initialized
DEBUG - 2018-07-31 03:31:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-31 03:31:43 --> Final output sent to browser
DEBUG - 2018-07-31 03:31:43 --> Total execution time: 0.7683
INFO - 2018-07-31 03:31:44 --> Config Class Initialized
INFO - 2018-07-31 03:31:44 --> Hooks Class Initialized
DEBUG - 2018-07-31 03:31:44 --> UTF-8 Support Enabled
INFO - 2018-07-31 03:31:44 --> Utf8 Class Initialized
INFO - 2018-07-31 03:31:44 --> URI Class Initialized
INFO - 2018-07-31 03:31:44 --> Router Class Initialized
INFO - 2018-07-31 03:31:44 --> Output Class Initialized
INFO - 2018-07-31 03:31:44 --> Security Class Initialized
DEBUG - 2018-07-31 03:31:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 03:31:44 --> Input Class Initialized
INFO - 2018-07-31 03:31:45 --> Language Class Initialized
INFO - 2018-07-31 03:31:45 --> Language Class Initialized
INFO - 2018-07-31 03:31:45 --> Config Class Initialized
INFO - 2018-07-31 03:31:45 --> Loader Class Initialized
DEBUG - 2018-07-31 03:31:45 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-31 03:31:45 --> Helper loaded: url_helper
INFO - 2018-07-31 03:31:45 --> Helper loaded: form_helper
INFO - 2018-07-31 03:31:45 --> Helper loaded: date_helper
INFO - 2018-07-31 03:31:45 --> Helper loaded: util_helper
INFO - 2018-07-31 03:31:45 --> Helper loaded: text_helper
INFO - 2018-07-31 03:31:45 --> Helper loaded: string_helper
INFO - 2018-07-31 03:31:45 --> Database Driver Class Initialized
DEBUG - 2018-07-31 03:31:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 03:31:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 03:31:45 --> Email Class Initialized
INFO - 2018-07-31 03:31:45 --> Controller Class Initialized
DEBUG - 2018-07-31 03:31:45 --> Programs MX_Controller Initialized
INFO - 2018-07-31 03:31:45 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-31 03:31:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-07-31 03:31:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-31 03:31:45 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-31 03:31:45 --> Login MX_Controller Initialized
DEBUG - 2018-07-31 03:31:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-31 03:31:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-31 03:31:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-31 03:31:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-31 03:31:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-31 03:31:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-31 03:31:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/programs/create_program.php
INFO - 2018-07-31 03:31:45 --> Final output sent to browser
DEBUG - 2018-07-31 03:31:45 --> Total execution time: 0.6268
INFO - 2018-07-31 03:32:03 --> Config Class Initialized
INFO - 2018-07-31 03:32:03 --> Hooks Class Initialized
DEBUG - 2018-07-31 03:32:03 --> UTF-8 Support Enabled
INFO - 2018-07-31 03:32:03 --> Utf8 Class Initialized
INFO - 2018-07-31 03:32:03 --> URI Class Initialized
INFO - 2018-07-31 03:32:03 --> Router Class Initialized
INFO - 2018-07-31 03:32:03 --> Output Class Initialized
INFO - 2018-07-31 03:32:04 --> Security Class Initialized
DEBUG - 2018-07-31 03:32:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 03:32:04 --> Input Class Initialized
INFO - 2018-07-31 03:32:04 --> Language Class Initialized
INFO - 2018-07-31 03:32:04 --> Language Class Initialized
INFO - 2018-07-31 03:32:04 --> Config Class Initialized
INFO - 2018-07-31 03:32:04 --> Loader Class Initialized
DEBUG - 2018-07-31 03:32:04 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-31 03:32:04 --> Helper loaded: url_helper
INFO - 2018-07-31 03:32:04 --> Helper loaded: form_helper
INFO - 2018-07-31 03:32:04 --> Helper loaded: date_helper
INFO - 2018-07-31 03:32:04 --> Helper loaded: util_helper
INFO - 2018-07-31 03:32:04 --> Helper loaded: text_helper
INFO - 2018-07-31 03:32:04 --> Helper loaded: string_helper
INFO - 2018-07-31 03:32:04 --> Database Driver Class Initialized
DEBUG - 2018-07-31 03:32:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 03:32:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 03:32:04 --> Email Class Initialized
INFO - 2018-07-31 03:32:04 --> Controller Class Initialized
DEBUG - 2018-07-31 03:32:04 --> Programs MX_Controller Initialized
INFO - 2018-07-31 03:32:04 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-31 03:32:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-07-31 03:32:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-31 03:32:04 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-31 03:32:04 --> Login MX_Controller Initialized
DEBUG - 2018-07-31 03:32:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-31 03:32:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-31 03:32:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-31 03:32:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-31 03:32:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-31 03:32:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-31 03:32:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/programs/create_program.php
INFO - 2018-07-31 03:32:04 --> Final output sent to browser
DEBUG - 2018-07-31 03:32:04 --> Total execution time: 0.6981
INFO - 2018-07-31 03:32:08 --> Config Class Initialized
INFO - 2018-07-31 03:32:08 --> Hooks Class Initialized
DEBUG - 2018-07-31 03:32:08 --> UTF-8 Support Enabled
INFO - 2018-07-31 03:32:08 --> Utf8 Class Initialized
INFO - 2018-07-31 03:32:09 --> URI Class Initialized
INFO - 2018-07-31 03:32:09 --> Router Class Initialized
INFO - 2018-07-31 03:32:09 --> Output Class Initialized
INFO - 2018-07-31 03:32:09 --> Security Class Initialized
DEBUG - 2018-07-31 03:32:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 03:32:09 --> Input Class Initialized
INFO - 2018-07-31 03:32:09 --> Language Class Initialized
ERROR - 2018-07-31 03:32:09 --> 404 Page Not Found: /index
INFO - 2018-07-31 03:32:14 --> Config Class Initialized
INFO - 2018-07-31 03:32:14 --> Hooks Class Initialized
DEBUG - 2018-07-31 03:32:14 --> UTF-8 Support Enabled
INFO - 2018-07-31 03:32:14 --> Utf8 Class Initialized
INFO - 2018-07-31 03:32:14 --> URI Class Initialized
INFO - 2018-07-31 03:32:14 --> Router Class Initialized
INFO - 2018-07-31 03:32:14 --> Output Class Initialized
INFO - 2018-07-31 03:32:14 --> Security Class Initialized
DEBUG - 2018-07-31 03:32:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 03:32:14 --> Input Class Initialized
INFO - 2018-07-31 03:32:14 --> Language Class Initialized
INFO - 2018-07-31 03:32:14 --> Language Class Initialized
INFO - 2018-07-31 03:32:14 --> Config Class Initialized
INFO - 2018-07-31 03:32:14 --> Loader Class Initialized
DEBUG - 2018-07-31 03:32:14 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-31 03:32:14 --> Helper loaded: url_helper
INFO - 2018-07-31 03:32:14 --> Helper loaded: form_helper
INFO - 2018-07-31 03:32:14 --> Helper loaded: date_helper
INFO - 2018-07-31 03:32:14 --> Helper loaded: util_helper
INFO - 2018-07-31 03:32:14 --> Helper loaded: text_helper
INFO - 2018-07-31 03:32:14 --> Helper loaded: string_helper
INFO - 2018-07-31 03:32:14 --> Database Driver Class Initialized
DEBUG - 2018-07-31 03:32:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 03:32:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 03:32:14 --> Email Class Initialized
INFO - 2018-07-31 03:32:14 --> Controller Class Initialized
DEBUG - 2018-07-31 03:32:14 --> Programs MX_Controller Initialized
INFO - 2018-07-31 03:32:14 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-31 03:32:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-07-31 03:32:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-31 03:32:14 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-31 03:32:14 --> Login MX_Controller Initialized
DEBUG - 2018-07-31 03:32:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-31 03:32:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
INFO - 2018-07-31 03:32:26 --> Config Class Initialized
INFO - 2018-07-31 03:32:26 --> Hooks Class Initialized
DEBUG - 2018-07-31 03:32:26 --> UTF-8 Support Enabled
INFO - 2018-07-31 03:32:26 --> Utf8 Class Initialized
INFO - 2018-07-31 03:32:26 --> URI Class Initialized
INFO - 2018-07-31 03:32:26 --> Router Class Initialized
INFO - 2018-07-31 03:32:26 --> Output Class Initialized
INFO - 2018-07-31 03:32:26 --> Security Class Initialized
DEBUG - 2018-07-31 03:32:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 03:32:26 --> Input Class Initialized
INFO - 2018-07-31 03:32:26 --> Language Class Initialized
INFO - 2018-07-31 03:32:26 --> Language Class Initialized
INFO - 2018-07-31 03:32:26 --> Config Class Initialized
INFO - 2018-07-31 03:32:26 --> Loader Class Initialized
DEBUG - 2018-07-31 03:32:26 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-31 03:32:26 --> Helper loaded: url_helper
INFO - 2018-07-31 03:32:26 --> Helper loaded: form_helper
INFO - 2018-07-31 03:32:26 --> Helper loaded: date_helper
INFO - 2018-07-31 03:32:26 --> Helper loaded: util_helper
INFO - 2018-07-31 03:32:26 --> Helper loaded: text_helper
INFO - 2018-07-31 03:32:26 --> Helper loaded: string_helper
INFO - 2018-07-31 03:32:26 --> Database Driver Class Initialized
DEBUG - 2018-07-31 03:32:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 03:32:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 03:32:27 --> Email Class Initialized
INFO - 2018-07-31 03:32:27 --> Controller Class Initialized
DEBUG - 2018-07-31 03:32:27 --> Programs MX_Controller Initialized
INFO - 2018-07-31 03:32:27 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-31 03:32:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-07-31 03:32:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-31 03:32:27 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-31 03:32:27 --> Login MX_Controller Initialized
DEBUG - 2018-07-31 03:32:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-31 03:32:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
INFO - 2018-07-31 03:32:27 --> Config Class Initialized
INFO - 2018-07-31 03:32:27 --> Hooks Class Initialized
DEBUG - 2018-07-31 03:32:27 --> UTF-8 Support Enabled
INFO - 2018-07-31 03:32:27 --> Utf8 Class Initialized
INFO - 2018-07-31 03:32:27 --> URI Class Initialized
INFO - 2018-07-31 03:32:27 --> Router Class Initialized
INFO - 2018-07-31 03:32:27 --> Output Class Initialized
INFO - 2018-07-31 03:32:27 --> Security Class Initialized
DEBUG - 2018-07-31 03:32:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 03:32:27 --> Input Class Initialized
INFO - 2018-07-31 03:32:27 --> Language Class Initialized
INFO - 2018-07-31 03:32:27 --> Language Class Initialized
INFO - 2018-07-31 03:32:27 --> Config Class Initialized
INFO - 2018-07-31 03:32:27 --> Loader Class Initialized
DEBUG - 2018-07-31 03:32:27 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-31 03:32:27 --> Helper loaded: url_helper
INFO - 2018-07-31 03:32:27 --> Helper loaded: form_helper
INFO - 2018-07-31 03:32:27 --> Helper loaded: date_helper
INFO - 2018-07-31 03:32:27 --> Helper loaded: util_helper
INFO - 2018-07-31 03:32:27 --> Helper loaded: text_helper
INFO - 2018-07-31 03:32:27 --> Helper loaded: string_helper
INFO - 2018-07-31 03:32:27 --> Database Driver Class Initialized
DEBUG - 2018-07-31 03:32:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 03:32:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 03:32:27 --> Email Class Initialized
INFO - 2018-07-31 03:32:27 --> Controller Class Initialized
DEBUG - 2018-07-31 03:32:27 --> Programs MX_Controller Initialized
INFO - 2018-07-31 03:32:27 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-31 03:32:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-07-31 03:32:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-31 03:32:27 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-31 03:32:27 --> Login MX_Controller Initialized
DEBUG - 2018-07-31 03:32:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-31 03:32:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-31 03:32:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-31 03:32:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-31 03:32:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-31 03:32:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-31 03:32:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/programs/programs.php
INFO - 2018-07-31 03:32:28 --> Final output sent to browser
DEBUG - 2018-07-31 03:32:28 --> Total execution time: 0.8194
INFO - 2018-07-31 03:32:28 --> Config Class Initialized
INFO - 2018-07-31 03:32:28 --> Hooks Class Initialized
DEBUG - 2018-07-31 03:32:29 --> UTF-8 Support Enabled
INFO - 2018-07-31 03:32:29 --> Utf8 Class Initialized
INFO - 2018-07-31 03:32:29 --> URI Class Initialized
INFO - 2018-07-31 03:32:29 --> Router Class Initialized
INFO - 2018-07-31 03:32:29 --> Output Class Initialized
INFO - 2018-07-31 03:32:29 --> Security Class Initialized
DEBUG - 2018-07-31 03:32:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 03:32:29 --> Input Class Initialized
INFO - 2018-07-31 03:32:29 --> Language Class Initialized
INFO - 2018-07-31 03:32:29 --> Language Class Initialized
INFO - 2018-07-31 03:32:29 --> Config Class Initialized
INFO - 2018-07-31 03:32:29 --> Loader Class Initialized
DEBUG - 2018-07-31 03:32:29 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-31 03:32:29 --> Helper loaded: url_helper
INFO - 2018-07-31 03:32:29 --> Helper loaded: form_helper
INFO - 2018-07-31 03:32:29 --> Config Class Initialized
INFO - 2018-07-31 03:32:29 --> Hooks Class Initialized
INFO - 2018-07-31 03:32:29 --> Helper loaded: date_helper
INFO - 2018-07-31 03:32:29 --> Helper loaded: util_helper
DEBUG - 2018-07-31 03:32:29 --> UTF-8 Support Enabled
INFO - 2018-07-31 03:32:29 --> Helper loaded: text_helper
INFO - 2018-07-31 03:32:29 --> Utf8 Class Initialized
INFO - 2018-07-31 03:32:29 --> URI Class Initialized
INFO - 2018-07-31 03:32:29 --> Helper loaded: string_helper
INFO - 2018-07-31 03:32:29 --> Router Class Initialized
INFO - 2018-07-31 03:32:29 --> Database Driver Class Initialized
INFO - 2018-07-31 03:32:29 --> Output Class Initialized
DEBUG - 2018-07-31 03:32:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 03:32:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 03:32:29 --> Security Class Initialized
DEBUG - 2018-07-31 03:32:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 03:32:29 --> Email Class Initialized
INFO - 2018-07-31 03:32:29 --> Input Class Initialized
INFO - 2018-07-31 03:32:29 --> Controller Class Initialized
INFO - 2018-07-31 03:32:29 --> Language Class Initialized
DEBUG - 2018-07-31 03:32:29 --> Programs MX_Controller Initialized
INFO - 2018-07-31 03:32:29 --> Language file loaded: language/english/data_lang.php
INFO - 2018-07-31 03:32:29 --> Language Class Initialized
INFO - 2018-07-31 03:32:29 --> Config Class Initialized
DEBUG - 2018-07-31 03:32:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-07-31 03:32:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-31 03:32:29 --> Loader Class Initialized
DEBUG - 2018-07-31 03:32:29 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
DEBUG - 2018-07-31 03:32:29 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
INFO - 2018-07-31 03:32:29 --> Helper loaded: url_helper
DEBUG - 2018-07-31 03:32:29 --> Login MX_Controller Initialized
INFO - 2018-07-31 03:32:29 --> Helper loaded: form_helper
DEBUG - 2018-07-31 03:32:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-31 03:32:29 --> Helper loaded: date_helper
INFO - 2018-07-31 03:32:29 --> Final output sent to browser
DEBUG - 2018-07-31 03:32:29 --> Total execution time: 1.0066
INFO - 2018-07-31 03:32:29 --> Helper loaded: util_helper
INFO - 2018-07-31 03:32:29 --> Helper loaded: text_helper
INFO - 2018-07-31 03:32:30 --> Helper loaded: string_helper
INFO - 2018-07-31 03:32:30 --> Database Driver Class Initialized
DEBUG - 2018-07-31 03:32:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 03:32:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 03:32:30 --> Email Class Initialized
INFO - 2018-07-31 03:32:30 --> Controller Class Initialized
DEBUG - 2018-07-31 03:32:30 --> Programs MX_Controller Initialized
INFO - 2018-07-31 03:32:30 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-31 03:32:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-07-31 03:32:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-31 03:32:30 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-31 03:32:30 --> Login MX_Controller Initialized
DEBUG - 2018-07-31 03:32:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-31 03:32:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-31 03:32:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-31 03:32:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-31 03:32:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-31 03:32:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-31 03:32:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/programs/create_program.php
INFO - 2018-07-31 03:32:30 --> Final output sent to browser
DEBUG - 2018-07-31 03:32:30 --> Total execution time: 0.8897
INFO - 2018-07-31 03:32:31 --> Config Class Initialized
INFO - 2018-07-31 03:32:31 --> Hooks Class Initialized
DEBUG - 2018-07-31 03:32:31 --> UTF-8 Support Enabled
INFO - 2018-07-31 03:32:31 --> Utf8 Class Initialized
INFO - 2018-07-31 03:32:31 --> URI Class Initialized
INFO - 2018-07-31 03:32:31 --> Router Class Initialized
INFO - 2018-07-31 03:32:31 --> Output Class Initialized
INFO - 2018-07-31 03:32:31 --> Security Class Initialized
DEBUG - 2018-07-31 03:32:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 03:32:31 --> Input Class Initialized
INFO - 2018-07-31 03:32:31 --> Language Class Initialized
ERROR - 2018-07-31 03:32:31 --> 404 Page Not Found: /index
INFO - 2018-07-31 03:32:33 --> Config Class Initialized
INFO - 2018-07-31 03:32:33 --> Hooks Class Initialized
DEBUG - 2018-07-31 03:32:33 --> UTF-8 Support Enabled
INFO - 2018-07-31 03:32:33 --> Utf8 Class Initialized
INFO - 2018-07-31 03:32:33 --> URI Class Initialized
INFO - 2018-07-31 03:32:33 --> Router Class Initialized
INFO - 2018-07-31 03:32:33 --> Output Class Initialized
INFO - 2018-07-31 03:32:33 --> Security Class Initialized
DEBUG - 2018-07-31 03:32:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 03:32:33 --> Input Class Initialized
INFO - 2018-07-31 03:32:33 --> Language Class Initialized
INFO - 2018-07-31 03:32:33 --> Language Class Initialized
INFO - 2018-07-31 03:32:33 --> Config Class Initialized
INFO - 2018-07-31 03:32:33 --> Loader Class Initialized
DEBUG - 2018-07-31 03:32:33 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-31 03:32:33 --> Helper loaded: url_helper
INFO - 2018-07-31 03:32:34 --> Helper loaded: form_helper
INFO - 2018-07-31 03:32:34 --> Helper loaded: date_helper
INFO - 2018-07-31 03:32:34 --> Helper loaded: util_helper
INFO - 2018-07-31 03:32:34 --> Helper loaded: text_helper
INFO - 2018-07-31 03:32:34 --> Helper loaded: string_helper
INFO - 2018-07-31 03:32:34 --> Database Driver Class Initialized
DEBUG - 2018-07-31 03:32:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 03:32:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 03:32:34 --> Email Class Initialized
INFO - 2018-07-31 03:32:34 --> Controller Class Initialized
DEBUG - 2018-07-31 03:32:34 --> Programs MX_Controller Initialized
INFO - 2018-07-31 03:32:34 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-31 03:32:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-07-31 03:32:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-31 03:32:34 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-31 03:32:34 --> Login MX_Controller Initialized
DEBUG - 2018-07-31 03:32:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-31 03:32:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-31 03:32:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-31 03:32:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-31 03:32:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-31 03:32:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-31 03:32:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/programs/create_program.php
INFO - 2018-07-31 03:32:34 --> Final output sent to browser
DEBUG - 2018-07-31 03:32:34 --> Total execution time: 0.7611
INFO - 2018-07-31 03:32:35 --> Config Class Initialized
INFO - 2018-07-31 03:32:35 --> Hooks Class Initialized
DEBUG - 2018-07-31 03:32:35 --> UTF-8 Support Enabled
INFO - 2018-07-31 03:32:35 --> Utf8 Class Initialized
INFO - 2018-07-31 03:32:35 --> URI Class Initialized
INFO - 2018-07-31 03:32:35 --> Router Class Initialized
INFO - 2018-07-31 03:32:35 --> Output Class Initialized
INFO - 2018-07-31 03:32:35 --> Security Class Initialized
DEBUG - 2018-07-31 03:32:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 03:32:35 --> Input Class Initialized
INFO - 2018-07-31 03:32:35 --> Language Class Initialized
ERROR - 2018-07-31 03:32:35 --> 404 Page Not Found: /index
INFO - 2018-07-31 03:32:51 --> Config Class Initialized
INFO - 2018-07-31 03:32:51 --> Hooks Class Initialized
DEBUG - 2018-07-31 03:32:51 --> UTF-8 Support Enabled
INFO - 2018-07-31 03:32:51 --> Utf8 Class Initialized
INFO - 2018-07-31 03:32:51 --> URI Class Initialized
INFO - 2018-07-31 03:32:51 --> Router Class Initialized
INFO - 2018-07-31 03:32:52 --> Output Class Initialized
INFO - 2018-07-31 03:32:52 --> Security Class Initialized
DEBUG - 2018-07-31 03:32:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 03:32:52 --> Input Class Initialized
INFO - 2018-07-31 03:32:52 --> Language Class Initialized
INFO - 2018-07-31 03:32:52 --> Language Class Initialized
INFO - 2018-07-31 03:32:52 --> Config Class Initialized
INFO - 2018-07-31 03:32:52 --> Loader Class Initialized
DEBUG - 2018-07-31 03:32:52 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-31 03:32:52 --> Helper loaded: url_helper
INFO - 2018-07-31 03:32:52 --> Helper loaded: form_helper
INFO - 2018-07-31 03:32:52 --> Helper loaded: date_helper
INFO - 2018-07-31 03:32:52 --> Helper loaded: util_helper
INFO - 2018-07-31 03:32:52 --> Helper loaded: text_helper
INFO - 2018-07-31 03:32:52 --> Helper loaded: string_helper
INFO - 2018-07-31 03:32:52 --> Database Driver Class Initialized
DEBUG - 2018-07-31 03:32:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 03:32:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 03:32:52 --> Email Class Initialized
INFO - 2018-07-31 03:32:52 --> Controller Class Initialized
DEBUG - 2018-07-31 03:32:52 --> Programs MX_Controller Initialized
INFO - 2018-07-31 03:32:52 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-31 03:32:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-07-31 03:32:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-31 03:32:52 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-31 03:32:52 --> Login MX_Controller Initialized
DEBUG - 2018-07-31 03:32:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-31 03:32:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
INFO - 2018-07-31 03:33:48 --> Config Class Initialized
INFO - 2018-07-31 03:33:48 --> Hooks Class Initialized
DEBUG - 2018-07-31 03:33:48 --> UTF-8 Support Enabled
INFO - 2018-07-31 03:33:48 --> Utf8 Class Initialized
INFO - 2018-07-31 03:33:48 --> URI Class Initialized
INFO - 2018-07-31 03:33:48 --> Router Class Initialized
INFO - 2018-07-31 03:33:48 --> Output Class Initialized
INFO - 2018-07-31 03:33:48 --> Security Class Initialized
DEBUG - 2018-07-31 03:33:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 03:33:48 --> Input Class Initialized
INFO - 2018-07-31 03:33:48 --> Language Class Initialized
INFO - 2018-07-31 03:33:48 --> Language Class Initialized
INFO - 2018-07-31 03:33:48 --> Config Class Initialized
INFO - 2018-07-31 03:33:48 --> Loader Class Initialized
DEBUG - 2018-07-31 03:33:48 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-31 03:33:48 --> Helper loaded: url_helper
INFO - 2018-07-31 03:33:48 --> Helper loaded: form_helper
INFO - 2018-07-31 03:33:48 --> Helper loaded: date_helper
INFO - 2018-07-31 03:33:48 --> Helper loaded: util_helper
INFO - 2018-07-31 03:33:48 --> Helper loaded: text_helper
INFO - 2018-07-31 03:33:48 --> Helper loaded: string_helper
INFO - 2018-07-31 03:33:48 --> Database Driver Class Initialized
DEBUG - 2018-07-31 03:33:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 03:33:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 03:33:48 --> Email Class Initialized
INFO - 2018-07-31 03:33:48 --> Controller Class Initialized
DEBUG - 2018-07-31 03:33:48 --> Programs MX_Controller Initialized
INFO - 2018-07-31 03:33:48 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-31 03:33:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-07-31 03:33:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-31 03:33:48 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-31 03:33:48 --> Login MX_Controller Initialized
DEBUG - 2018-07-31 03:33:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-31 03:33:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
INFO - 2018-07-31 03:34:00 --> Config Class Initialized
INFO - 2018-07-31 03:34:01 --> Hooks Class Initialized
DEBUG - 2018-07-31 03:34:01 --> UTF-8 Support Enabled
INFO - 2018-07-31 03:34:01 --> Utf8 Class Initialized
INFO - 2018-07-31 03:34:01 --> URI Class Initialized
INFO - 2018-07-31 03:34:01 --> Router Class Initialized
INFO - 2018-07-31 03:34:01 --> Output Class Initialized
INFO - 2018-07-31 03:34:01 --> Security Class Initialized
DEBUG - 2018-07-31 03:34:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 03:34:01 --> Input Class Initialized
INFO - 2018-07-31 03:34:01 --> Language Class Initialized
INFO - 2018-07-31 03:34:01 --> Language Class Initialized
INFO - 2018-07-31 03:34:01 --> Config Class Initialized
INFO - 2018-07-31 03:34:01 --> Loader Class Initialized
DEBUG - 2018-07-31 03:34:01 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-31 03:34:01 --> Helper loaded: url_helper
INFO - 2018-07-31 03:34:01 --> Helper loaded: form_helper
INFO - 2018-07-31 03:34:01 --> Helper loaded: date_helper
INFO - 2018-07-31 03:34:01 --> Helper loaded: util_helper
INFO - 2018-07-31 03:34:01 --> Helper loaded: text_helper
INFO - 2018-07-31 03:34:01 --> Helper loaded: string_helper
INFO - 2018-07-31 03:34:01 --> Database Driver Class Initialized
DEBUG - 2018-07-31 03:34:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 03:34:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 03:34:01 --> Email Class Initialized
INFO - 2018-07-31 03:34:01 --> Controller Class Initialized
DEBUG - 2018-07-31 03:34:01 --> Programs MX_Controller Initialized
INFO - 2018-07-31 03:34:01 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-31 03:34:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-07-31 03:34:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-31 03:34:01 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-31 03:34:01 --> Login MX_Controller Initialized
DEBUG - 2018-07-31 03:34:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-31 03:34:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
INFO - 2018-07-31 03:34:01 --> Config Class Initialized
INFO - 2018-07-31 03:34:01 --> Hooks Class Initialized
DEBUG - 2018-07-31 03:34:01 --> UTF-8 Support Enabled
INFO - 2018-07-31 03:34:01 --> Utf8 Class Initialized
INFO - 2018-07-31 03:34:01 --> URI Class Initialized
INFO - 2018-07-31 03:34:01 --> Router Class Initialized
INFO - 2018-07-31 03:34:01 --> Output Class Initialized
INFO - 2018-07-31 03:34:01 --> Security Class Initialized
DEBUG - 2018-07-31 03:34:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 03:34:01 --> Input Class Initialized
INFO - 2018-07-31 03:34:01 --> Language Class Initialized
INFO - 2018-07-31 03:34:01 --> Language Class Initialized
INFO - 2018-07-31 03:34:01 --> Config Class Initialized
INFO - 2018-07-31 03:34:01 --> Loader Class Initialized
DEBUG - 2018-07-31 03:34:01 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-31 03:34:01 --> Helper loaded: url_helper
INFO - 2018-07-31 03:34:01 --> Helper loaded: form_helper
INFO - 2018-07-31 03:34:01 --> Helper loaded: date_helper
INFO - 2018-07-31 03:34:01 --> Helper loaded: util_helper
INFO - 2018-07-31 03:34:01 --> Helper loaded: text_helper
INFO - 2018-07-31 03:34:01 --> Helper loaded: string_helper
INFO - 2018-07-31 03:34:02 --> Database Driver Class Initialized
DEBUG - 2018-07-31 03:34:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 03:34:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 03:34:02 --> Email Class Initialized
INFO - 2018-07-31 03:34:02 --> Controller Class Initialized
DEBUG - 2018-07-31 03:34:02 --> Programs MX_Controller Initialized
INFO - 2018-07-31 03:34:02 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-31 03:34:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-07-31 03:34:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-31 03:34:02 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-31 03:34:02 --> Login MX_Controller Initialized
DEBUG - 2018-07-31 03:34:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-31 03:34:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-31 03:34:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-31 03:34:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-31 03:34:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-31 03:34:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-31 03:34:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/programs/programs.php
INFO - 2018-07-31 03:34:02 --> Final output sent to browser
DEBUG - 2018-07-31 03:34:02 --> Total execution time: 0.7696
INFO - 2018-07-31 03:34:03 --> Config Class Initialized
INFO - 2018-07-31 03:34:03 --> Hooks Class Initialized
DEBUG - 2018-07-31 03:34:03 --> UTF-8 Support Enabled
INFO - 2018-07-31 03:34:03 --> Utf8 Class Initialized
INFO - 2018-07-31 03:34:03 --> URI Class Initialized
INFO - 2018-07-31 03:34:03 --> Router Class Initialized
INFO - 2018-07-31 03:34:03 --> Output Class Initialized
INFO - 2018-07-31 03:34:03 --> Security Class Initialized
DEBUG - 2018-07-31 03:34:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 03:34:03 --> Input Class Initialized
INFO - 2018-07-31 03:34:03 --> Language Class Initialized
INFO - 2018-07-31 03:34:03 --> Language Class Initialized
INFO - 2018-07-31 03:34:03 --> Config Class Initialized
INFO - 2018-07-31 03:34:03 --> Loader Class Initialized
DEBUG - 2018-07-31 03:34:03 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-31 03:34:03 --> Helper loaded: url_helper
INFO - 2018-07-31 03:34:03 --> Helper loaded: form_helper
INFO - 2018-07-31 03:34:03 --> Helper loaded: date_helper
INFO - 2018-07-31 03:34:03 --> Helper loaded: util_helper
INFO - 2018-07-31 03:34:03 --> Helper loaded: text_helper
INFO - 2018-07-31 03:34:03 --> Helper loaded: string_helper
INFO - 2018-07-31 03:34:03 --> Database Driver Class Initialized
DEBUG - 2018-07-31 03:34:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 03:34:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 03:34:03 --> Email Class Initialized
INFO - 2018-07-31 03:34:03 --> Controller Class Initialized
DEBUG - 2018-07-31 03:34:03 --> Programs MX_Controller Initialized
INFO - 2018-07-31 03:34:03 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-31 03:34:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-07-31 03:34:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-31 03:34:03 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-31 03:34:03 --> Login MX_Controller Initialized
DEBUG - 2018-07-31 03:34:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-31 03:34:03 --> Final output sent to browser
DEBUG - 2018-07-31 03:34:03 --> Total execution time: 0.7682
INFO - 2018-07-31 03:34:03 --> Config Class Initialized
INFO - 2018-07-31 03:34:03 --> Hooks Class Initialized
DEBUG - 2018-07-31 03:34:04 --> UTF-8 Support Enabled
INFO - 2018-07-31 03:34:04 --> Utf8 Class Initialized
INFO - 2018-07-31 03:34:04 --> URI Class Initialized
INFO - 2018-07-31 03:34:04 --> Router Class Initialized
INFO - 2018-07-31 03:34:04 --> Output Class Initialized
INFO - 2018-07-31 03:34:04 --> Security Class Initialized
DEBUG - 2018-07-31 03:34:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 03:34:04 --> Input Class Initialized
INFO - 2018-07-31 03:34:04 --> Language Class Initialized
INFO - 2018-07-31 03:34:04 --> Language Class Initialized
INFO - 2018-07-31 03:34:04 --> Config Class Initialized
INFO - 2018-07-31 03:34:04 --> Loader Class Initialized
DEBUG - 2018-07-31 03:34:04 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-31 03:34:04 --> Helper loaded: url_helper
INFO - 2018-07-31 03:34:04 --> Helper loaded: form_helper
INFO - 2018-07-31 03:34:04 --> Helper loaded: date_helper
INFO - 2018-07-31 03:34:04 --> Helper loaded: util_helper
INFO - 2018-07-31 03:34:04 --> Helper loaded: text_helper
INFO - 2018-07-31 03:34:04 --> Helper loaded: string_helper
INFO - 2018-07-31 03:34:04 --> Database Driver Class Initialized
DEBUG - 2018-07-31 03:34:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 03:34:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 03:34:04 --> Email Class Initialized
INFO - 2018-07-31 03:34:04 --> Controller Class Initialized
DEBUG - 2018-07-31 03:34:04 --> Programs MX_Controller Initialized
INFO - 2018-07-31 03:34:04 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-31 03:34:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-07-31 03:34:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-31 03:34:04 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-31 03:34:04 --> Login MX_Controller Initialized
DEBUG - 2018-07-31 03:34:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-31 03:34:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-31 03:34:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-31 03:34:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-31 03:34:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-31 03:34:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-31 03:34:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/programs/create_program.php
INFO - 2018-07-31 03:34:04 --> Final output sent to browser
DEBUG - 2018-07-31 03:34:04 --> Total execution time: 0.6813
INFO - 2018-07-31 03:34:05 --> Config Class Initialized
INFO - 2018-07-31 03:34:05 --> Hooks Class Initialized
DEBUG - 2018-07-31 03:34:05 --> UTF-8 Support Enabled
INFO - 2018-07-31 03:34:05 --> Utf8 Class Initialized
INFO - 2018-07-31 03:34:05 --> URI Class Initialized
INFO - 2018-07-31 03:34:05 --> Router Class Initialized
INFO - 2018-07-31 03:34:05 --> Output Class Initialized
INFO - 2018-07-31 03:34:05 --> Security Class Initialized
DEBUG - 2018-07-31 03:34:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 03:34:05 --> Input Class Initialized
INFO - 2018-07-31 03:34:05 --> Language Class Initialized
ERROR - 2018-07-31 03:34:05 --> 404 Page Not Found: /index
INFO - 2018-07-31 03:34:37 --> Config Class Initialized
INFO - 2018-07-31 03:34:37 --> Hooks Class Initialized
DEBUG - 2018-07-31 03:34:37 --> UTF-8 Support Enabled
INFO - 2018-07-31 03:34:37 --> Utf8 Class Initialized
INFO - 2018-07-31 03:34:37 --> URI Class Initialized
INFO - 2018-07-31 03:34:37 --> Router Class Initialized
INFO - 2018-07-31 03:34:37 --> Output Class Initialized
INFO - 2018-07-31 03:34:37 --> Security Class Initialized
DEBUG - 2018-07-31 03:34:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 03:34:37 --> Input Class Initialized
INFO - 2018-07-31 03:34:37 --> Language Class Initialized
ERROR - 2018-07-31 03:34:37 --> 404 Page Not Found: /index
INFO - 2018-07-31 03:34:46 --> Config Class Initialized
INFO - 2018-07-31 03:34:46 --> Hooks Class Initialized
DEBUG - 2018-07-31 03:34:46 --> UTF-8 Support Enabled
INFO - 2018-07-31 03:34:46 --> Utf8 Class Initialized
INFO - 2018-07-31 03:34:46 --> URI Class Initialized
INFO - 2018-07-31 03:34:46 --> Router Class Initialized
INFO - 2018-07-31 03:34:46 --> Output Class Initialized
INFO - 2018-07-31 03:34:46 --> Security Class Initialized
DEBUG - 2018-07-31 03:34:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 03:34:46 --> Input Class Initialized
INFO - 2018-07-31 03:34:46 --> Language Class Initialized
INFO - 2018-07-31 03:34:46 --> Language Class Initialized
INFO - 2018-07-31 03:34:46 --> Config Class Initialized
INFO - 2018-07-31 03:34:46 --> Loader Class Initialized
DEBUG - 2018-07-31 03:34:46 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-31 03:34:46 --> Helper loaded: url_helper
INFO - 2018-07-31 03:34:46 --> Helper loaded: form_helper
INFO - 2018-07-31 03:34:46 --> Helper loaded: date_helper
INFO - 2018-07-31 03:34:46 --> Helper loaded: util_helper
INFO - 2018-07-31 03:34:46 --> Helper loaded: text_helper
INFO - 2018-07-31 03:34:47 --> Helper loaded: string_helper
INFO - 2018-07-31 03:34:47 --> Database Driver Class Initialized
DEBUG - 2018-07-31 03:34:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 03:34:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 03:34:47 --> Email Class Initialized
INFO - 2018-07-31 03:34:47 --> Controller Class Initialized
DEBUG - 2018-07-31 03:34:47 --> Programs MX_Controller Initialized
INFO - 2018-07-31 03:34:47 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-31 03:34:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-07-31 03:34:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-31 03:34:47 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-31 03:34:47 --> Login MX_Controller Initialized
DEBUG - 2018-07-31 03:34:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-31 03:34:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
INFO - 2018-07-31 03:34:47 --> Upload Class Initialized
INFO - 2018-07-31 03:34:47 --> Config Class Initialized
INFO - 2018-07-31 03:34:47 --> Hooks Class Initialized
DEBUG - 2018-07-31 03:34:47 --> UTF-8 Support Enabled
INFO - 2018-07-31 03:34:47 --> Utf8 Class Initialized
INFO - 2018-07-31 03:34:47 --> URI Class Initialized
INFO - 2018-07-31 03:34:47 --> Router Class Initialized
INFO - 2018-07-31 03:34:47 --> Output Class Initialized
INFO - 2018-07-31 03:34:47 --> Security Class Initialized
DEBUG - 2018-07-31 03:34:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 03:34:47 --> Input Class Initialized
INFO - 2018-07-31 03:34:47 --> Language Class Initialized
INFO - 2018-07-31 03:34:47 --> Language Class Initialized
INFO - 2018-07-31 03:34:47 --> Config Class Initialized
INFO - 2018-07-31 03:34:47 --> Loader Class Initialized
DEBUG - 2018-07-31 03:34:47 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-31 03:34:47 --> Helper loaded: url_helper
INFO - 2018-07-31 03:34:47 --> Helper loaded: form_helper
INFO - 2018-07-31 03:34:47 --> Helper loaded: date_helper
INFO - 2018-07-31 03:34:47 --> Helper loaded: util_helper
INFO - 2018-07-31 03:34:47 --> Helper loaded: text_helper
INFO - 2018-07-31 03:34:47 --> Helper loaded: string_helper
INFO - 2018-07-31 03:34:47 --> Database Driver Class Initialized
DEBUG - 2018-07-31 03:34:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 03:34:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 03:34:47 --> Email Class Initialized
INFO - 2018-07-31 03:34:47 --> Controller Class Initialized
DEBUG - 2018-07-31 03:34:47 --> Programs MX_Controller Initialized
INFO - 2018-07-31 03:34:47 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-31 03:34:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-07-31 03:34:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-31 03:34:47 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-31 03:34:47 --> Login MX_Controller Initialized
DEBUG - 2018-07-31 03:34:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-31 03:34:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-31 03:34:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-31 03:34:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-31 03:34:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-31 03:34:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-31 03:34:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/programs/programs.php
INFO - 2018-07-31 03:34:48 --> Final output sent to browser
DEBUG - 2018-07-31 03:34:48 --> Total execution time: 0.6593
INFO - 2018-07-31 03:34:48 --> Config Class Initialized
INFO - 2018-07-31 03:34:48 --> Hooks Class Initialized
DEBUG - 2018-07-31 03:34:48 --> UTF-8 Support Enabled
INFO - 2018-07-31 03:34:48 --> Utf8 Class Initialized
INFO - 2018-07-31 03:34:48 --> URI Class Initialized
INFO - 2018-07-31 03:34:48 --> Router Class Initialized
INFO - 2018-07-31 03:34:48 --> Output Class Initialized
INFO - 2018-07-31 03:34:49 --> Security Class Initialized
DEBUG - 2018-07-31 03:34:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 03:34:49 --> Input Class Initialized
INFO - 2018-07-31 03:34:49 --> Language Class Initialized
INFO - 2018-07-31 03:34:49 --> Language Class Initialized
INFO - 2018-07-31 03:34:49 --> Config Class Initialized
INFO - 2018-07-31 03:34:49 --> Loader Class Initialized
DEBUG - 2018-07-31 03:34:49 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-31 03:34:49 --> Helper loaded: url_helper
INFO - 2018-07-31 03:34:49 --> Helper loaded: form_helper
INFO - 2018-07-31 03:34:49 --> Helper loaded: date_helper
INFO - 2018-07-31 03:34:49 --> Helper loaded: util_helper
INFO - 2018-07-31 03:34:49 --> Helper loaded: text_helper
INFO - 2018-07-31 03:34:49 --> Helper loaded: string_helper
INFO - 2018-07-31 03:34:49 --> Database Driver Class Initialized
DEBUG - 2018-07-31 03:34:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 03:34:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 03:34:49 --> Email Class Initialized
INFO - 2018-07-31 03:34:49 --> Controller Class Initialized
DEBUG - 2018-07-31 03:34:49 --> Programs MX_Controller Initialized
INFO - 2018-07-31 03:34:49 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-31 03:34:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-07-31 03:34:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-31 03:34:49 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-31 03:34:49 --> Login MX_Controller Initialized
DEBUG - 2018-07-31 03:34:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-31 03:34:49 --> Final output sent to browser
DEBUG - 2018-07-31 03:34:49 --> Total execution time: 0.7079
INFO - 2018-07-31 03:34:51 --> Config Class Initialized
INFO - 2018-07-31 03:34:51 --> Hooks Class Initialized
DEBUG - 2018-07-31 03:34:51 --> UTF-8 Support Enabled
INFO - 2018-07-31 03:34:51 --> Utf8 Class Initialized
INFO - 2018-07-31 03:34:51 --> URI Class Initialized
INFO - 2018-07-31 03:34:51 --> Router Class Initialized
INFO - 2018-07-31 03:34:51 --> Output Class Initialized
INFO - 2018-07-31 03:34:51 --> Security Class Initialized
DEBUG - 2018-07-31 03:34:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 03:34:51 --> Input Class Initialized
INFO - 2018-07-31 03:34:51 --> Language Class Initialized
INFO - 2018-07-31 03:34:51 --> Language Class Initialized
INFO - 2018-07-31 03:34:51 --> Config Class Initialized
INFO - 2018-07-31 03:34:52 --> Loader Class Initialized
DEBUG - 2018-07-31 03:34:52 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-31 03:34:52 --> Helper loaded: url_helper
INFO - 2018-07-31 03:34:52 --> Helper loaded: form_helper
INFO - 2018-07-31 03:34:52 --> Helper loaded: date_helper
INFO - 2018-07-31 03:34:52 --> Helper loaded: util_helper
INFO - 2018-07-31 03:34:52 --> Helper loaded: text_helper
INFO - 2018-07-31 03:34:52 --> Helper loaded: string_helper
INFO - 2018-07-31 03:34:52 --> Database Driver Class Initialized
DEBUG - 2018-07-31 03:34:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 03:34:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 03:34:52 --> Email Class Initialized
INFO - 2018-07-31 03:34:52 --> Controller Class Initialized
DEBUG - 2018-07-31 03:34:52 --> Programs MX_Controller Initialized
INFO - 2018-07-31 03:34:52 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-31 03:34:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-07-31 03:34:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-31 03:34:52 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-31 03:34:52 --> Login MX_Controller Initialized
DEBUG - 2018-07-31 03:34:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-31 03:34:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-31 03:34:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-31 03:34:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-31 03:34:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-31 03:34:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-31 03:34:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/programs/create_program.php
INFO - 2018-07-31 03:34:52 --> Final output sent to browser
DEBUG - 2018-07-31 03:34:52 --> Total execution time: 0.6584
INFO - 2018-07-31 03:35:15 --> Config Class Initialized
INFO - 2018-07-31 03:35:15 --> Hooks Class Initialized
DEBUG - 2018-07-31 03:35:15 --> UTF-8 Support Enabled
INFO - 2018-07-31 03:35:15 --> Utf8 Class Initialized
INFO - 2018-07-31 03:35:15 --> URI Class Initialized
INFO - 2018-07-31 03:35:15 --> Router Class Initialized
INFO - 2018-07-31 03:35:15 --> Output Class Initialized
INFO - 2018-07-31 03:35:15 --> Security Class Initialized
DEBUG - 2018-07-31 03:35:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 03:35:15 --> Input Class Initialized
INFO - 2018-07-31 03:35:15 --> Language Class Initialized
INFO - 2018-07-31 03:35:15 --> Language Class Initialized
INFO - 2018-07-31 03:35:15 --> Config Class Initialized
INFO - 2018-07-31 03:35:15 --> Loader Class Initialized
DEBUG - 2018-07-31 03:35:16 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-31 03:35:16 --> Helper loaded: url_helper
INFO - 2018-07-31 03:35:16 --> Helper loaded: form_helper
INFO - 2018-07-31 03:35:16 --> Helper loaded: date_helper
INFO - 2018-07-31 03:35:16 --> Helper loaded: util_helper
INFO - 2018-07-31 03:35:16 --> Helper loaded: text_helper
INFO - 2018-07-31 03:35:16 --> Helper loaded: string_helper
INFO - 2018-07-31 03:35:16 --> Database Driver Class Initialized
DEBUG - 2018-07-31 03:35:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 03:35:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 03:35:16 --> Email Class Initialized
INFO - 2018-07-31 03:35:16 --> Controller Class Initialized
DEBUG - 2018-07-31 03:35:16 --> Programs MX_Controller Initialized
INFO - 2018-07-31 03:35:16 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-31 03:35:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-07-31 03:35:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-31 03:35:16 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-31 03:35:16 --> Login MX_Controller Initialized
DEBUG - 2018-07-31 03:35:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-31 03:35:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
INFO - 2018-07-31 03:35:16 --> Config Class Initialized
INFO - 2018-07-31 03:35:16 --> Hooks Class Initialized
DEBUG - 2018-07-31 03:35:16 --> UTF-8 Support Enabled
INFO - 2018-07-31 03:35:16 --> Utf8 Class Initialized
INFO - 2018-07-31 03:35:16 --> URI Class Initialized
INFO - 2018-07-31 03:35:16 --> Router Class Initialized
INFO - 2018-07-31 03:35:16 --> Output Class Initialized
INFO - 2018-07-31 03:35:16 --> Security Class Initialized
DEBUG - 2018-07-31 03:35:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 03:35:16 --> Input Class Initialized
INFO - 2018-07-31 03:35:16 --> Language Class Initialized
INFO - 2018-07-31 03:35:16 --> Language Class Initialized
INFO - 2018-07-31 03:35:16 --> Config Class Initialized
INFO - 2018-07-31 03:35:16 --> Loader Class Initialized
DEBUG - 2018-07-31 03:35:16 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-31 03:35:16 --> Helper loaded: url_helper
INFO - 2018-07-31 03:35:16 --> Helper loaded: form_helper
INFO - 2018-07-31 03:35:16 --> Helper loaded: date_helper
INFO - 2018-07-31 03:35:16 --> Helper loaded: util_helper
INFO - 2018-07-31 03:35:16 --> Helper loaded: text_helper
INFO - 2018-07-31 03:35:16 --> Helper loaded: string_helper
INFO - 2018-07-31 03:35:16 --> Database Driver Class Initialized
DEBUG - 2018-07-31 03:35:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 03:35:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 03:35:16 --> Email Class Initialized
INFO - 2018-07-31 03:35:16 --> Controller Class Initialized
DEBUG - 2018-07-31 03:35:16 --> Programs MX_Controller Initialized
INFO - 2018-07-31 03:35:16 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-31 03:35:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-07-31 03:35:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-31 03:35:16 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-31 03:35:16 --> Login MX_Controller Initialized
DEBUG - 2018-07-31 03:35:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-31 03:35:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-31 03:35:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-31 03:35:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-31 03:35:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-31 03:35:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-31 03:35:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/programs/programs.php
INFO - 2018-07-31 03:35:17 --> Final output sent to browser
DEBUG - 2018-07-31 03:35:17 --> Total execution time: 0.7232
INFO - 2018-07-31 03:35:17 --> Config Class Initialized
INFO - 2018-07-31 03:35:17 --> Hooks Class Initialized
DEBUG - 2018-07-31 03:35:17 --> UTF-8 Support Enabled
INFO - 2018-07-31 03:35:17 --> Utf8 Class Initialized
INFO - 2018-07-31 03:35:17 --> URI Class Initialized
INFO - 2018-07-31 03:35:17 --> Router Class Initialized
INFO - 2018-07-31 03:35:17 --> Output Class Initialized
INFO - 2018-07-31 03:35:17 --> Security Class Initialized
DEBUG - 2018-07-31 03:35:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 03:35:17 --> Input Class Initialized
INFO - 2018-07-31 03:35:17 --> Config Class Initialized
INFO - 2018-07-31 03:35:17 --> Hooks Class Initialized
INFO - 2018-07-31 03:35:17 --> Language Class Initialized
DEBUG - 2018-07-31 03:35:17 --> UTF-8 Support Enabled
INFO - 2018-07-31 03:35:17 --> Language Class Initialized
INFO - 2018-07-31 03:35:17 --> Utf8 Class Initialized
INFO - 2018-07-31 03:35:17 --> URI Class Initialized
INFO - 2018-07-31 03:35:17 --> Router Class Initialized
INFO - 2018-07-31 03:35:17 --> Output Class Initialized
INFO - 2018-07-31 03:35:17 --> Security Class Initialized
DEBUG - 2018-07-31 03:35:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 03:35:18 --> Input Class Initialized
INFO - 2018-07-31 03:35:18 --> Language Class Initialized
INFO - 2018-07-31 03:35:18 --> Config Class Initialized
INFO - 2018-07-31 03:35:18 --> Language Class Initialized
INFO - 2018-07-31 03:35:18 --> Config Class Initialized
INFO - 2018-07-31 03:35:18 --> Loader Class Initialized
DEBUG - 2018-07-31 03:35:18 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-31 03:35:18 --> Loader Class Initialized
DEBUG - 2018-07-31 03:35:18 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-31 03:35:18 --> Helper loaded: url_helper
INFO - 2018-07-31 03:35:18 --> Helper loaded: url_helper
INFO - 2018-07-31 03:35:18 --> Helper loaded: form_helper
INFO - 2018-07-31 03:35:18 --> Helper loaded: form_helper
INFO - 2018-07-31 03:35:18 --> Helper loaded: date_helper
INFO - 2018-07-31 03:35:18 --> Helper loaded: date_helper
INFO - 2018-07-31 03:35:18 --> Helper loaded: util_helper
INFO - 2018-07-31 03:35:18 --> Helper loaded: util_helper
INFO - 2018-07-31 03:35:18 --> Helper loaded: text_helper
INFO - 2018-07-31 03:35:18 --> Helper loaded: text_helper
INFO - 2018-07-31 03:35:18 --> Helper loaded: string_helper
INFO - 2018-07-31 03:35:18 --> Helper loaded: string_helper
INFO - 2018-07-31 03:35:18 --> Database Driver Class Initialized
INFO - 2018-07-31 03:35:18 --> Database Driver Class Initialized
DEBUG - 2018-07-31 03:35:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-07-31 03:35:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 03:35:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 03:35:18 --> Email Class Initialized
INFO - 2018-07-31 03:35:18 --> Controller Class Initialized
DEBUG - 2018-07-31 03:35:18 --> Programs MX_Controller Initialized
INFO - 2018-07-31 03:35:18 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-31 03:35:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-07-31 03:35:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-31 03:35:18 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-31 03:35:18 --> Login MX_Controller Initialized
DEBUG - 2018-07-31 03:35:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-31 03:35:18 --> Final output sent to browser
DEBUG - 2018-07-31 03:35:18 --> Total execution time: 0.9610
INFO - 2018-07-31 03:35:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 03:35:18 --> Email Class Initialized
INFO - 2018-07-31 03:35:18 --> Controller Class Initialized
DEBUG - 2018-07-31 03:35:18 --> Programs MX_Controller Initialized
INFO - 2018-07-31 03:35:18 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-31 03:35:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-07-31 03:35:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-31 03:35:18 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-31 03:35:18 --> Login MX_Controller Initialized
DEBUG - 2018-07-31 03:35:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-31 03:35:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-31 03:35:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-31 03:35:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-31 03:35:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-31 03:35:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-31 03:35:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/programs/create_program.php
INFO - 2018-07-31 03:35:18 --> Final output sent to browser
DEBUG - 2018-07-31 03:35:18 --> Total execution time: 0.9417
INFO - 2018-07-31 03:35:20 --> Config Class Initialized
INFO - 2018-07-31 03:35:20 --> Hooks Class Initialized
DEBUG - 2018-07-31 03:35:20 --> UTF-8 Support Enabled
INFO - 2018-07-31 03:35:20 --> Utf8 Class Initialized
INFO - 2018-07-31 03:35:20 --> URI Class Initialized
INFO - 2018-07-31 03:35:20 --> Router Class Initialized
INFO - 2018-07-31 03:35:20 --> Output Class Initialized
INFO - 2018-07-31 03:35:20 --> Security Class Initialized
DEBUG - 2018-07-31 03:35:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 03:35:20 --> Input Class Initialized
INFO - 2018-07-31 03:35:20 --> Language Class Initialized
INFO - 2018-07-31 03:35:20 --> Language Class Initialized
INFO - 2018-07-31 03:35:20 --> Config Class Initialized
INFO - 2018-07-31 03:35:20 --> Loader Class Initialized
DEBUG - 2018-07-31 03:35:20 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-31 03:35:20 --> Helper loaded: url_helper
INFO - 2018-07-31 03:35:20 --> Helper loaded: form_helper
INFO - 2018-07-31 03:35:20 --> Helper loaded: date_helper
INFO - 2018-07-31 03:35:20 --> Helper loaded: util_helper
INFO - 2018-07-31 03:35:20 --> Helper loaded: text_helper
INFO - 2018-07-31 03:35:20 --> Helper loaded: string_helper
INFO - 2018-07-31 03:35:20 --> Database Driver Class Initialized
DEBUG - 2018-07-31 03:35:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 03:35:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 03:35:20 --> Email Class Initialized
INFO - 2018-07-31 03:35:20 --> Controller Class Initialized
DEBUG - 2018-07-31 03:35:20 --> Programs MX_Controller Initialized
INFO - 2018-07-31 03:35:20 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-31 03:35:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-07-31 03:35:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-31 03:35:20 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-31 03:35:20 --> Login MX_Controller Initialized
DEBUG - 2018-07-31 03:35:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-31 03:35:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-31 03:35:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-31 03:35:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-31 03:35:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-31 03:35:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-31 03:35:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/programs/create_program.php
INFO - 2018-07-31 03:35:20 --> Final output sent to browser
DEBUG - 2018-07-31 03:35:20 --> Total execution time: 0.6049
INFO - 2018-07-31 03:35:37 --> Config Class Initialized
INFO - 2018-07-31 03:35:38 --> Hooks Class Initialized
DEBUG - 2018-07-31 03:35:38 --> UTF-8 Support Enabled
INFO - 2018-07-31 03:35:38 --> Utf8 Class Initialized
INFO - 2018-07-31 03:35:38 --> URI Class Initialized
INFO - 2018-07-31 03:35:38 --> Router Class Initialized
INFO - 2018-07-31 03:35:38 --> Output Class Initialized
INFO - 2018-07-31 03:35:38 --> Security Class Initialized
DEBUG - 2018-07-31 03:35:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 03:35:38 --> Input Class Initialized
INFO - 2018-07-31 03:35:38 --> Language Class Initialized
ERROR - 2018-07-31 03:35:38 --> 404 Page Not Found: /index
INFO - 2018-07-31 03:35:41 --> Config Class Initialized
INFO - 2018-07-31 03:35:41 --> Hooks Class Initialized
DEBUG - 2018-07-31 03:35:41 --> UTF-8 Support Enabled
INFO - 2018-07-31 03:35:41 --> Utf8 Class Initialized
INFO - 2018-07-31 03:35:41 --> URI Class Initialized
INFO - 2018-07-31 03:35:41 --> Router Class Initialized
INFO - 2018-07-31 03:35:41 --> Output Class Initialized
INFO - 2018-07-31 03:35:41 --> Security Class Initialized
DEBUG - 2018-07-31 03:35:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 03:35:41 --> Input Class Initialized
INFO - 2018-07-31 03:35:41 --> Language Class Initialized
INFO - 2018-07-31 03:35:41 --> Language Class Initialized
INFO - 2018-07-31 03:35:41 --> Config Class Initialized
INFO - 2018-07-31 03:35:41 --> Loader Class Initialized
DEBUG - 2018-07-31 03:35:41 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-31 03:35:41 --> Helper loaded: url_helper
INFO - 2018-07-31 03:35:41 --> Helper loaded: form_helper
INFO - 2018-07-31 03:35:41 --> Helper loaded: date_helper
INFO - 2018-07-31 03:35:41 --> Helper loaded: util_helper
INFO - 2018-07-31 03:35:41 --> Helper loaded: text_helper
INFO - 2018-07-31 03:35:41 --> Helper loaded: string_helper
INFO - 2018-07-31 03:35:41 --> Database Driver Class Initialized
DEBUG - 2018-07-31 03:35:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 03:35:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 03:35:41 --> Email Class Initialized
INFO - 2018-07-31 03:35:41 --> Controller Class Initialized
DEBUG - 2018-07-31 03:35:41 --> Programs MX_Controller Initialized
INFO - 2018-07-31 03:35:41 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-31 03:35:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-07-31 03:35:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-31 03:35:41 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-31 03:35:41 --> Login MX_Controller Initialized
DEBUG - 2018-07-31 03:35:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-31 03:35:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
INFO - 2018-07-31 03:36:05 --> Config Class Initialized
INFO - 2018-07-31 03:36:05 --> Hooks Class Initialized
DEBUG - 2018-07-31 03:36:05 --> UTF-8 Support Enabled
INFO - 2018-07-31 03:36:06 --> Utf8 Class Initialized
INFO - 2018-07-31 03:36:06 --> URI Class Initialized
INFO - 2018-07-31 03:36:06 --> Router Class Initialized
INFO - 2018-07-31 03:36:06 --> Output Class Initialized
INFO - 2018-07-31 03:36:06 --> Security Class Initialized
DEBUG - 2018-07-31 03:36:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 03:36:06 --> Input Class Initialized
INFO - 2018-07-31 03:36:06 --> Language Class Initialized
INFO - 2018-07-31 03:36:06 --> Language Class Initialized
INFO - 2018-07-31 03:36:06 --> Config Class Initialized
INFO - 2018-07-31 03:36:06 --> Loader Class Initialized
DEBUG - 2018-07-31 03:36:06 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-31 03:36:06 --> Helper loaded: url_helper
INFO - 2018-07-31 03:36:06 --> Helper loaded: form_helper
INFO - 2018-07-31 03:36:06 --> Helper loaded: date_helper
INFO - 2018-07-31 03:36:06 --> Helper loaded: util_helper
INFO - 2018-07-31 03:36:06 --> Helper loaded: text_helper
INFO - 2018-07-31 03:36:06 --> Helper loaded: string_helper
INFO - 2018-07-31 03:36:06 --> Database Driver Class Initialized
DEBUG - 2018-07-31 03:36:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 03:36:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 03:36:06 --> Email Class Initialized
INFO - 2018-07-31 03:36:06 --> Controller Class Initialized
DEBUG - 2018-07-31 03:36:06 --> Programs MX_Controller Initialized
INFO - 2018-07-31 03:36:06 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-31 03:36:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-07-31 03:36:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-31 03:36:06 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-31 03:36:06 --> Login MX_Controller Initialized
DEBUG - 2018-07-31 03:36:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-31 03:36:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
INFO - 2018-07-31 03:36:48 --> Config Class Initialized
INFO - 2018-07-31 03:36:48 --> Hooks Class Initialized
DEBUG - 2018-07-31 03:36:48 --> UTF-8 Support Enabled
INFO - 2018-07-31 03:36:48 --> Utf8 Class Initialized
INFO - 2018-07-31 03:36:48 --> URI Class Initialized
INFO - 2018-07-31 03:36:48 --> Router Class Initialized
INFO - 2018-07-31 03:36:48 --> Output Class Initialized
INFO - 2018-07-31 03:36:48 --> Security Class Initialized
DEBUG - 2018-07-31 03:36:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 03:36:48 --> Input Class Initialized
INFO - 2018-07-31 03:36:48 --> Language Class Initialized
INFO - 2018-07-31 03:36:48 --> Language Class Initialized
INFO - 2018-07-31 03:36:49 --> Config Class Initialized
INFO - 2018-07-31 03:36:49 --> Loader Class Initialized
DEBUG - 2018-07-31 03:36:49 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-31 03:36:49 --> Helper loaded: url_helper
INFO - 2018-07-31 03:36:49 --> Helper loaded: form_helper
INFO - 2018-07-31 03:36:49 --> Helper loaded: date_helper
INFO - 2018-07-31 03:36:49 --> Helper loaded: util_helper
INFO - 2018-07-31 03:36:49 --> Helper loaded: text_helper
INFO - 2018-07-31 03:36:49 --> Helper loaded: string_helper
INFO - 2018-07-31 03:36:49 --> Database Driver Class Initialized
DEBUG - 2018-07-31 03:36:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 03:36:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 03:36:49 --> Email Class Initialized
INFO - 2018-07-31 03:36:49 --> Controller Class Initialized
DEBUG - 2018-07-31 03:36:49 --> Programs MX_Controller Initialized
INFO - 2018-07-31 03:36:49 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-31 03:36:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-07-31 03:36:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-31 03:36:49 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-31 03:36:49 --> Login MX_Controller Initialized
DEBUG - 2018-07-31 03:36:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-31 03:36:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
INFO - 2018-07-31 03:37:11 --> Config Class Initialized
INFO - 2018-07-31 03:37:11 --> Hooks Class Initialized
DEBUG - 2018-07-31 03:37:11 --> UTF-8 Support Enabled
INFO - 2018-07-31 03:37:11 --> Utf8 Class Initialized
INFO - 2018-07-31 03:37:11 --> URI Class Initialized
INFO - 2018-07-31 03:37:11 --> Router Class Initialized
INFO - 2018-07-31 03:37:11 --> Output Class Initialized
INFO - 2018-07-31 03:37:11 --> Security Class Initialized
DEBUG - 2018-07-31 03:37:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 03:37:11 --> Input Class Initialized
INFO - 2018-07-31 03:37:11 --> Language Class Initialized
INFO - 2018-07-31 03:37:11 --> Language Class Initialized
INFO - 2018-07-31 03:37:11 --> Config Class Initialized
INFO - 2018-07-31 03:37:11 --> Loader Class Initialized
DEBUG - 2018-07-31 03:37:11 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-31 03:37:11 --> Helper loaded: url_helper
INFO - 2018-07-31 03:37:11 --> Helper loaded: form_helper
INFO - 2018-07-31 03:37:11 --> Helper loaded: date_helper
INFO - 2018-07-31 03:37:11 --> Helper loaded: util_helper
INFO - 2018-07-31 03:37:11 --> Helper loaded: text_helper
INFO - 2018-07-31 03:37:11 --> Helper loaded: string_helper
INFO - 2018-07-31 03:37:11 --> Database Driver Class Initialized
DEBUG - 2018-07-31 03:37:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 03:37:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 03:37:11 --> Email Class Initialized
INFO - 2018-07-31 03:37:11 --> Controller Class Initialized
DEBUG - 2018-07-31 03:37:11 --> Programs MX_Controller Initialized
INFO - 2018-07-31 03:37:11 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-31 03:37:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-07-31 03:37:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-31 03:37:11 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-31 03:37:11 --> Login MX_Controller Initialized
DEBUG - 2018-07-31 03:37:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-31 03:37:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
INFO - 2018-07-31 03:37:32 --> Config Class Initialized
INFO - 2018-07-31 03:37:32 --> Hooks Class Initialized
DEBUG - 2018-07-31 03:37:32 --> UTF-8 Support Enabled
INFO - 2018-07-31 03:37:32 --> Utf8 Class Initialized
INFO - 2018-07-31 03:37:32 --> URI Class Initialized
INFO - 2018-07-31 03:37:32 --> Router Class Initialized
INFO - 2018-07-31 03:37:32 --> Output Class Initialized
INFO - 2018-07-31 03:37:32 --> Security Class Initialized
DEBUG - 2018-07-31 03:37:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 03:37:32 --> Input Class Initialized
INFO - 2018-07-31 03:37:32 --> Language Class Initialized
INFO - 2018-07-31 03:37:32 --> Language Class Initialized
INFO - 2018-07-31 03:37:32 --> Config Class Initialized
INFO - 2018-07-31 03:37:32 --> Loader Class Initialized
DEBUG - 2018-07-31 03:37:32 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-31 03:37:32 --> Helper loaded: url_helper
INFO - 2018-07-31 03:37:32 --> Helper loaded: form_helper
INFO - 2018-07-31 03:37:32 --> Helper loaded: date_helper
INFO - 2018-07-31 03:37:32 --> Helper loaded: util_helper
INFO - 2018-07-31 03:37:32 --> Helper loaded: text_helper
INFO - 2018-07-31 03:37:32 --> Helper loaded: string_helper
INFO - 2018-07-31 03:37:32 --> Database Driver Class Initialized
DEBUG - 2018-07-31 03:37:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 03:37:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 03:37:32 --> Email Class Initialized
INFO - 2018-07-31 03:37:32 --> Controller Class Initialized
DEBUG - 2018-07-31 03:37:32 --> Programs MX_Controller Initialized
INFO - 2018-07-31 03:37:32 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-31 03:37:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-07-31 03:37:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-31 03:37:32 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-31 03:37:32 --> Login MX_Controller Initialized
DEBUG - 2018-07-31 03:37:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-31 03:37:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
INFO - 2018-07-31 03:37:41 --> Config Class Initialized
INFO - 2018-07-31 03:37:41 --> Hooks Class Initialized
DEBUG - 2018-07-31 03:37:41 --> UTF-8 Support Enabled
INFO - 2018-07-31 03:37:41 --> Utf8 Class Initialized
INFO - 2018-07-31 03:37:41 --> URI Class Initialized
INFO - 2018-07-31 03:37:41 --> Router Class Initialized
INFO - 2018-07-31 03:37:41 --> Output Class Initialized
INFO - 2018-07-31 03:37:41 --> Security Class Initialized
DEBUG - 2018-07-31 03:37:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 03:37:41 --> Input Class Initialized
INFO - 2018-07-31 03:37:41 --> Language Class Initialized
INFO - 2018-07-31 03:37:41 --> Language Class Initialized
INFO - 2018-07-31 03:37:41 --> Config Class Initialized
INFO - 2018-07-31 03:37:41 --> Loader Class Initialized
DEBUG - 2018-07-31 03:37:41 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-31 03:37:41 --> Helper loaded: url_helper
INFO - 2018-07-31 03:37:41 --> Helper loaded: form_helper
INFO - 2018-07-31 03:37:41 --> Helper loaded: date_helper
INFO - 2018-07-31 03:37:41 --> Helper loaded: util_helper
INFO - 2018-07-31 03:37:41 --> Helper loaded: text_helper
INFO - 2018-07-31 03:37:41 --> Helper loaded: string_helper
INFO - 2018-07-31 03:37:41 --> Database Driver Class Initialized
DEBUG - 2018-07-31 03:37:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 03:37:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 03:37:41 --> Email Class Initialized
INFO - 2018-07-31 03:37:41 --> Controller Class Initialized
DEBUG - 2018-07-31 03:37:41 --> Programs MX_Controller Initialized
INFO - 2018-07-31 03:37:41 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-31 03:37:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-07-31 03:37:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-31 03:37:41 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-31 03:37:42 --> Login MX_Controller Initialized
DEBUG - 2018-07-31 03:37:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-31 03:37:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
INFO - 2018-07-31 03:37:43 --> Config Class Initialized
INFO - 2018-07-31 03:37:43 --> Hooks Class Initialized
DEBUG - 2018-07-31 03:37:43 --> UTF-8 Support Enabled
INFO - 2018-07-31 03:37:43 --> Utf8 Class Initialized
INFO - 2018-07-31 03:37:43 --> URI Class Initialized
INFO - 2018-07-31 03:37:43 --> Router Class Initialized
INFO - 2018-07-31 03:37:43 --> Output Class Initialized
INFO - 2018-07-31 03:37:43 --> Security Class Initialized
DEBUG - 2018-07-31 03:37:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 03:37:43 --> Input Class Initialized
INFO - 2018-07-31 03:37:43 --> Language Class Initialized
INFO - 2018-07-31 03:37:43 --> Language Class Initialized
INFO - 2018-07-31 03:37:43 --> Config Class Initialized
INFO - 2018-07-31 03:37:43 --> Loader Class Initialized
DEBUG - 2018-07-31 03:37:43 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-31 03:37:43 --> Helper loaded: url_helper
INFO - 2018-07-31 03:37:43 --> Helper loaded: form_helper
INFO - 2018-07-31 03:37:43 --> Helper loaded: date_helper
INFO - 2018-07-31 03:37:43 --> Helper loaded: util_helper
INFO - 2018-07-31 03:37:43 --> Helper loaded: text_helper
INFO - 2018-07-31 03:37:43 --> Helper loaded: string_helper
INFO - 2018-07-31 03:37:43 --> Database Driver Class Initialized
DEBUG - 2018-07-31 03:37:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 03:37:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 03:37:43 --> Email Class Initialized
INFO - 2018-07-31 03:37:43 --> Controller Class Initialized
DEBUG - 2018-07-31 03:37:43 --> Programs MX_Controller Initialized
INFO - 2018-07-31 03:37:43 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-31 03:37:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-07-31 03:37:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-31 03:37:43 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-31 03:37:43 --> Login MX_Controller Initialized
DEBUG - 2018-07-31 03:37:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-31 03:37:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
INFO - 2018-07-31 03:37:44 --> Config Class Initialized
INFO - 2018-07-31 03:37:44 --> Hooks Class Initialized
DEBUG - 2018-07-31 03:37:44 --> UTF-8 Support Enabled
INFO - 2018-07-31 03:37:44 --> Utf8 Class Initialized
INFO - 2018-07-31 03:37:44 --> URI Class Initialized
INFO - 2018-07-31 03:37:44 --> Router Class Initialized
INFO - 2018-07-31 03:37:44 --> Output Class Initialized
INFO - 2018-07-31 03:37:44 --> Security Class Initialized
DEBUG - 2018-07-31 03:37:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 03:37:44 --> Input Class Initialized
INFO - 2018-07-31 03:37:44 --> Language Class Initialized
INFO - 2018-07-31 03:37:44 --> Language Class Initialized
INFO - 2018-07-31 03:37:44 --> Config Class Initialized
INFO - 2018-07-31 03:37:44 --> Loader Class Initialized
DEBUG - 2018-07-31 03:37:44 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-31 03:37:44 --> Helper loaded: url_helper
INFO - 2018-07-31 03:37:44 --> Helper loaded: form_helper
INFO - 2018-07-31 03:37:44 --> Helper loaded: date_helper
INFO - 2018-07-31 03:37:44 --> Helper loaded: util_helper
INFO - 2018-07-31 03:37:44 --> Helper loaded: text_helper
INFO - 2018-07-31 03:37:44 --> Helper loaded: string_helper
INFO - 2018-07-31 03:37:44 --> Database Driver Class Initialized
DEBUG - 2018-07-31 03:37:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 03:37:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 03:37:44 --> Email Class Initialized
INFO - 2018-07-31 03:37:44 --> Controller Class Initialized
DEBUG - 2018-07-31 03:37:44 --> Programs MX_Controller Initialized
INFO - 2018-07-31 03:37:44 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-31 03:37:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-07-31 03:37:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-31 03:37:44 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-31 03:37:44 --> Login MX_Controller Initialized
DEBUG - 2018-07-31 03:37:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-31 03:37:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-31 03:37:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-31 03:37:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-31 03:37:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-31 03:37:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-31 03:37:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/programs/programs.php
INFO - 2018-07-31 03:37:44 --> Final output sent to browser
DEBUG - 2018-07-31 03:37:44 --> Total execution time: 0.7081
INFO - 2018-07-31 03:37:45 --> Config Class Initialized
INFO - 2018-07-31 03:37:45 --> Hooks Class Initialized
DEBUG - 2018-07-31 03:37:45 --> UTF-8 Support Enabled
INFO - 2018-07-31 03:37:45 --> Utf8 Class Initialized
INFO - 2018-07-31 03:37:45 --> URI Class Initialized
INFO - 2018-07-31 03:37:45 --> Router Class Initialized
INFO - 2018-07-31 03:37:45 --> Output Class Initialized
INFO - 2018-07-31 03:37:45 --> Security Class Initialized
DEBUG - 2018-07-31 03:37:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 03:37:45 --> Input Class Initialized
INFO - 2018-07-31 03:37:45 --> Language Class Initialized
INFO - 2018-07-31 03:37:45 --> Language Class Initialized
INFO - 2018-07-31 03:37:45 --> Config Class Initialized
INFO - 2018-07-31 03:37:45 --> Loader Class Initialized
DEBUG - 2018-07-31 03:37:45 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-31 03:37:45 --> Helper loaded: url_helper
INFO - 2018-07-31 03:37:45 --> Helper loaded: form_helper
INFO - 2018-07-31 03:37:45 --> Helper loaded: date_helper
INFO - 2018-07-31 03:37:45 --> Helper loaded: util_helper
INFO - 2018-07-31 03:37:46 --> Helper loaded: text_helper
INFO - 2018-07-31 03:37:46 --> Helper loaded: string_helper
INFO - 2018-07-31 03:37:46 --> Database Driver Class Initialized
DEBUG - 2018-07-31 03:37:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 03:37:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 03:37:46 --> Email Class Initialized
INFO - 2018-07-31 03:37:46 --> Controller Class Initialized
DEBUG - 2018-07-31 03:37:46 --> Programs MX_Controller Initialized
INFO - 2018-07-31 03:37:46 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-31 03:37:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-07-31 03:37:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-31 03:37:46 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-31 03:37:46 --> Login MX_Controller Initialized
DEBUG - 2018-07-31 03:37:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-31 03:37:46 --> Final output sent to browser
DEBUG - 2018-07-31 03:37:46 --> Total execution time: 0.8117
INFO - 2018-07-31 03:37:46 --> Config Class Initialized
INFO - 2018-07-31 03:37:46 --> Hooks Class Initialized
DEBUG - 2018-07-31 03:37:46 --> UTF-8 Support Enabled
INFO - 2018-07-31 03:37:46 --> Utf8 Class Initialized
INFO - 2018-07-31 03:37:46 --> URI Class Initialized
INFO - 2018-07-31 03:37:46 --> Router Class Initialized
INFO - 2018-07-31 03:37:46 --> Output Class Initialized
INFO - 2018-07-31 03:37:46 --> Security Class Initialized
DEBUG - 2018-07-31 03:37:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 03:37:46 --> Input Class Initialized
INFO - 2018-07-31 03:37:46 --> Language Class Initialized
INFO - 2018-07-31 03:37:46 --> Language Class Initialized
INFO - 2018-07-31 03:37:46 --> Config Class Initialized
INFO - 2018-07-31 03:37:46 --> Loader Class Initialized
DEBUG - 2018-07-31 03:37:46 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-31 03:37:46 --> Helper loaded: url_helper
INFO - 2018-07-31 03:37:46 --> Helper loaded: form_helper
INFO - 2018-07-31 03:37:46 --> Helper loaded: date_helper
INFO - 2018-07-31 03:37:46 --> Helper loaded: util_helper
INFO - 2018-07-31 03:37:46 --> Helper loaded: text_helper
INFO - 2018-07-31 03:37:46 --> Helper loaded: string_helper
INFO - 2018-07-31 03:37:46 --> Database Driver Class Initialized
DEBUG - 2018-07-31 03:37:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 03:37:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 03:37:46 --> Email Class Initialized
INFO - 2018-07-31 03:37:46 --> Controller Class Initialized
DEBUG - 2018-07-31 03:37:46 --> Programs MX_Controller Initialized
INFO - 2018-07-31 03:37:46 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-31 03:37:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-07-31 03:37:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-31 03:37:46 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-31 03:37:46 --> Login MX_Controller Initialized
DEBUG - 2018-07-31 03:37:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-31 03:37:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-31 03:37:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-31 03:37:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-31 03:37:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-31 03:37:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-31 03:37:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/programs/create_program.php
INFO - 2018-07-31 03:37:46 --> Final output sent to browser
DEBUG - 2018-07-31 03:37:47 --> Total execution time: 0.6718
INFO - 2018-07-31 03:37:48 --> Config Class Initialized
INFO - 2018-07-31 03:37:48 --> Hooks Class Initialized
DEBUG - 2018-07-31 03:37:48 --> UTF-8 Support Enabled
INFO - 2018-07-31 03:37:48 --> Utf8 Class Initialized
INFO - 2018-07-31 03:37:48 --> URI Class Initialized
INFO - 2018-07-31 03:37:48 --> Router Class Initialized
INFO - 2018-07-31 03:37:48 --> Output Class Initialized
INFO - 2018-07-31 03:37:48 --> Security Class Initialized
DEBUG - 2018-07-31 03:37:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 03:37:48 --> Input Class Initialized
INFO - 2018-07-31 03:37:48 --> Language Class Initialized
INFO - 2018-07-31 03:37:48 --> Language Class Initialized
INFO - 2018-07-31 03:37:48 --> Config Class Initialized
INFO - 2018-07-31 03:37:48 --> Loader Class Initialized
DEBUG - 2018-07-31 03:37:48 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-31 03:37:48 --> Helper loaded: url_helper
INFO - 2018-07-31 03:37:48 --> Helper loaded: form_helper
INFO - 2018-07-31 03:37:48 --> Helper loaded: date_helper
INFO - 2018-07-31 03:37:48 --> Helper loaded: util_helper
INFO - 2018-07-31 03:37:48 --> Helper loaded: text_helper
INFO - 2018-07-31 03:37:48 --> Helper loaded: string_helper
INFO - 2018-07-31 03:37:48 --> Database Driver Class Initialized
DEBUG - 2018-07-31 03:37:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 03:37:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 03:37:48 --> Email Class Initialized
INFO - 2018-07-31 03:37:48 --> Controller Class Initialized
DEBUG - 2018-07-31 03:37:48 --> Programs MX_Controller Initialized
INFO - 2018-07-31 03:37:48 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-31 03:37:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-07-31 03:37:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-31 03:37:48 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-31 03:37:48 --> Login MX_Controller Initialized
DEBUG - 2018-07-31 03:37:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-31 03:37:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-31 03:37:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-31 03:37:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-31 03:37:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-31 03:37:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-31 03:37:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/programs/create_program.php
INFO - 2018-07-31 03:37:48 --> Final output sent to browser
DEBUG - 2018-07-31 03:37:48 --> Total execution time: 0.7905
INFO - 2018-07-31 03:37:59 --> Config Class Initialized
INFO - 2018-07-31 03:37:59 --> Hooks Class Initialized
DEBUG - 2018-07-31 03:37:59 --> UTF-8 Support Enabled
INFO - 2018-07-31 03:37:59 --> Utf8 Class Initialized
INFO - 2018-07-31 03:37:59 --> URI Class Initialized
INFO - 2018-07-31 03:37:59 --> Router Class Initialized
INFO - 2018-07-31 03:37:59 --> Output Class Initialized
INFO - 2018-07-31 03:37:59 --> Security Class Initialized
DEBUG - 2018-07-31 03:37:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 03:37:59 --> Input Class Initialized
INFO - 2018-07-31 03:37:59 --> Language Class Initialized
INFO - 2018-07-31 03:37:59 --> Language Class Initialized
INFO - 2018-07-31 03:37:59 --> Config Class Initialized
INFO - 2018-07-31 03:37:59 --> Loader Class Initialized
DEBUG - 2018-07-31 03:37:59 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-31 03:37:59 --> Helper loaded: url_helper
INFO - 2018-07-31 03:37:59 --> Helper loaded: form_helper
INFO - 2018-07-31 03:37:59 --> Helper loaded: date_helper
INFO - 2018-07-31 03:37:59 --> Helper loaded: util_helper
INFO - 2018-07-31 03:37:59 --> Helper loaded: text_helper
INFO - 2018-07-31 03:37:59 --> Helper loaded: string_helper
INFO - 2018-07-31 03:37:59 --> Database Driver Class Initialized
DEBUG - 2018-07-31 03:38:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 03:38:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 03:38:00 --> Email Class Initialized
INFO - 2018-07-31 03:38:00 --> Controller Class Initialized
DEBUG - 2018-07-31 03:38:00 --> Programs MX_Controller Initialized
INFO - 2018-07-31 03:38:00 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-31 03:38:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-07-31 03:38:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-31 03:38:00 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-31 03:38:00 --> Login MX_Controller Initialized
DEBUG - 2018-07-31 03:38:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-31 03:38:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
INFO - 2018-07-31 03:38:00 --> Upload Class Initialized
INFO - 2018-07-31 03:38:00 --> Config Class Initialized
INFO - 2018-07-31 03:38:00 --> Hooks Class Initialized
DEBUG - 2018-07-31 03:38:00 --> UTF-8 Support Enabled
INFO - 2018-07-31 03:38:00 --> Utf8 Class Initialized
INFO - 2018-07-31 03:38:00 --> URI Class Initialized
INFO - 2018-07-31 03:38:00 --> Router Class Initialized
INFO - 2018-07-31 03:38:00 --> Output Class Initialized
INFO - 2018-07-31 03:38:00 --> Security Class Initialized
DEBUG - 2018-07-31 03:38:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 03:38:00 --> Input Class Initialized
INFO - 2018-07-31 03:38:00 --> Language Class Initialized
INFO - 2018-07-31 03:38:00 --> Language Class Initialized
INFO - 2018-07-31 03:38:00 --> Config Class Initialized
INFO - 2018-07-31 03:38:00 --> Loader Class Initialized
DEBUG - 2018-07-31 03:38:00 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-31 03:38:00 --> Helper loaded: url_helper
INFO - 2018-07-31 03:38:00 --> Helper loaded: form_helper
INFO - 2018-07-31 03:38:00 --> Helper loaded: date_helper
INFO - 2018-07-31 03:38:00 --> Helper loaded: util_helper
INFO - 2018-07-31 03:38:00 --> Helper loaded: text_helper
INFO - 2018-07-31 03:38:00 --> Helper loaded: string_helper
INFO - 2018-07-31 03:38:00 --> Database Driver Class Initialized
DEBUG - 2018-07-31 03:38:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 03:38:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 03:38:00 --> Email Class Initialized
INFO - 2018-07-31 03:38:00 --> Controller Class Initialized
DEBUG - 2018-07-31 03:38:00 --> Programs MX_Controller Initialized
INFO - 2018-07-31 03:38:00 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-31 03:38:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-07-31 03:38:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-31 03:38:00 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-31 03:38:00 --> Login MX_Controller Initialized
DEBUG - 2018-07-31 03:38:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-31 03:38:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-31 03:38:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-31 03:38:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-31 03:38:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-31 03:38:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-31 03:38:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/programs/programs.php
INFO - 2018-07-31 03:38:01 --> Final output sent to browser
DEBUG - 2018-07-31 03:38:01 --> Total execution time: 0.7030
INFO - 2018-07-31 03:38:01 --> Config Class Initialized
INFO - 2018-07-31 03:38:01 --> Hooks Class Initialized
DEBUG - 2018-07-31 03:38:01 --> UTF-8 Support Enabled
INFO - 2018-07-31 03:38:01 --> Utf8 Class Initialized
INFO - 2018-07-31 03:38:01 --> URI Class Initialized
INFO - 2018-07-31 03:38:01 --> Router Class Initialized
INFO - 2018-07-31 03:38:01 --> Output Class Initialized
INFO - 2018-07-31 03:38:01 --> Security Class Initialized
DEBUG - 2018-07-31 03:38:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 03:38:01 --> Input Class Initialized
INFO - 2018-07-31 03:38:01 --> Language Class Initialized
INFO - 2018-07-31 03:38:01 --> Language Class Initialized
INFO - 2018-07-31 03:38:01 --> Config Class Initialized
INFO - 2018-07-31 03:38:01 --> Loader Class Initialized
DEBUG - 2018-07-31 03:38:01 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-31 03:38:01 --> Helper loaded: url_helper
INFO - 2018-07-31 03:38:01 --> Helper loaded: form_helper
INFO - 2018-07-31 03:38:01 --> Helper loaded: date_helper
INFO - 2018-07-31 03:38:01 --> Helper loaded: util_helper
INFO - 2018-07-31 03:38:01 --> Helper loaded: text_helper
INFO - 2018-07-31 03:38:01 --> Helper loaded: string_helper
INFO - 2018-07-31 03:38:01 --> Database Driver Class Initialized
DEBUG - 2018-07-31 03:38:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 03:38:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 03:38:01 --> Email Class Initialized
INFO - 2018-07-31 03:38:01 --> Controller Class Initialized
DEBUG - 2018-07-31 03:38:01 --> Programs MX_Controller Initialized
INFO - 2018-07-31 03:38:02 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-31 03:38:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-07-31 03:38:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-31 03:38:02 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-31 03:38:02 --> Login MX_Controller Initialized
DEBUG - 2018-07-31 03:38:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-31 03:38:02 --> Final output sent to browser
DEBUG - 2018-07-31 03:38:02 --> Total execution time: 0.7310
INFO - 2018-07-31 03:38:02 --> Config Class Initialized
INFO - 2018-07-31 03:38:02 --> Hooks Class Initialized
DEBUG - 2018-07-31 03:38:02 --> UTF-8 Support Enabled
INFO - 2018-07-31 03:38:02 --> Utf8 Class Initialized
INFO - 2018-07-31 03:38:02 --> URI Class Initialized
INFO - 2018-07-31 03:38:02 --> Router Class Initialized
INFO - 2018-07-31 03:38:02 --> Output Class Initialized
INFO - 2018-07-31 03:38:02 --> Security Class Initialized
DEBUG - 2018-07-31 03:38:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 03:38:02 --> Input Class Initialized
INFO - 2018-07-31 03:38:02 --> Language Class Initialized
INFO - 2018-07-31 03:38:02 --> Language Class Initialized
INFO - 2018-07-31 03:38:02 --> Config Class Initialized
INFO - 2018-07-31 03:38:02 --> Loader Class Initialized
DEBUG - 2018-07-31 03:38:02 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-31 03:38:02 --> Helper loaded: url_helper
INFO - 2018-07-31 03:38:02 --> Helper loaded: form_helper
INFO - 2018-07-31 03:38:02 --> Helper loaded: date_helper
INFO - 2018-07-31 03:38:02 --> Helper loaded: util_helper
INFO - 2018-07-31 03:38:02 --> Helper loaded: text_helper
INFO - 2018-07-31 03:38:02 --> Helper loaded: string_helper
INFO - 2018-07-31 03:38:02 --> Database Driver Class Initialized
DEBUG - 2018-07-31 03:38:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 03:38:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 03:38:03 --> Email Class Initialized
INFO - 2018-07-31 03:38:03 --> Controller Class Initialized
DEBUG - 2018-07-31 03:38:03 --> Programs MX_Controller Initialized
INFO - 2018-07-31 03:38:03 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-31 03:38:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-07-31 03:38:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-31 03:38:03 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-31 03:38:03 --> Login MX_Controller Initialized
DEBUG - 2018-07-31 03:38:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-31 03:38:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-31 03:38:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-31 03:38:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-31 03:38:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-31 03:38:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-31 03:38:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/programs/create_program.php
INFO - 2018-07-31 03:38:03 --> Final output sent to browser
DEBUG - 2018-07-31 03:38:03 --> Total execution time: 0.6731
INFO - 2018-07-31 03:38:13 --> Config Class Initialized
INFO - 2018-07-31 03:38:13 --> Hooks Class Initialized
DEBUG - 2018-07-31 03:38:13 --> UTF-8 Support Enabled
INFO - 2018-07-31 03:38:13 --> Utf8 Class Initialized
INFO - 2018-07-31 03:38:13 --> URI Class Initialized
INFO - 2018-07-31 03:38:13 --> Router Class Initialized
INFO - 2018-07-31 03:38:13 --> Output Class Initialized
INFO - 2018-07-31 03:38:13 --> Security Class Initialized
DEBUG - 2018-07-31 03:38:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 03:38:13 --> Input Class Initialized
INFO - 2018-07-31 03:38:13 --> Language Class Initialized
INFO - 2018-07-31 03:38:13 --> Language Class Initialized
INFO - 2018-07-31 03:38:13 --> Config Class Initialized
INFO - 2018-07-31 03:38:13 --> Loader Class Initialized
DEBUG - 2018-07-31 03:38:13 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-31 03:38:13 --> Helper loaded: url_helper
INFO - 2018-07-31 03:38:13 --> Helper loaded: form_helper
INFO - 2018-07-31 03:38:13 --> Helper loaded: date_helper
INFO - 2018-07-31 03:38:13 --> Helper loaded: util_helper
INFO - 2018-07-31 03:38:13 --> Helper loaded: text_helper
INFO - 2018-07-31 03:38:13 --> Helper loaded: string_helper
INFO - 2018-07-31 03:38:13 --> Database Driver Class Initialized
DEBUG - 2018-07-31 03:38:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 03:38:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 03:38:13 --> Email Class Initialized
INFO - 2018-07-31 03:38:13 --> Controller Class Initialized
DEBUG - 2018-07-31 03:38:13 --> Programs MX_Controller Initialized
INFO - 2018-07-31 03:38:13 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-31 03:38:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-07-31 03:38:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-31 03:38:13 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-31 03:38:13 --> Login MX_Controller Initialized
DEBUG - 2018-07-31 03:38:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-31 03:38:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
INFO - 2018-07-31 03:38:13 --> Upload Class Initialized
INFO - 2018-07-31 03:38:13 --> Config Class Initialized
INFO - 2018-07-31 03:38:13 --> Hooks Class Initialized
DEBUG - 2018-07-31 03:38:13 --> UTF-8 Support Enabled
INFO - 2018-07-31 03:38:13 --> Utf8 Class Initialized
INFO - 2018-07-31 03:38:13 --> URI Class Initialized
INFO - 2018-07-31 03:38:13 --> Router Class Initialized
INFO - 2018-07-31 03:38:13 --> Output Class Initialized
INFO - 2018-07-31 03:38:14 --> Security Class Initialized
DEBUG - 2018-07-31 03:38:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 03:38:14 --> Input Class Initialized
INFO - 2018-07-31 03:38:14 --> Language Class Initialized
INFO - 2018-07-31 03:38:14 --> Language Class Initialized
INFO - 2018-07-31 03:38:14 --> Config Class Initialized
INFO - 2018-07-31 03:38:14 --> Loader Class Initialized
DEBUG - 2018-07-31 03:38:14 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-31 03:38:14 --> Helper loaded: url_helper
INFO - 2018-07-31 03:38:14 --> Helper loaded: form_helper
INFO - 2018-07-31 03:38:14 --> Helper loaded: date_helper
INFO - 2018-07-31 03:38:14 --> Helper loaded: util_helper
INFO - 2018-07-31 03:38:14 --> Helper loaded: text_helper
INFO - 2018-07-31 03:38:14 --> Helper loaded: string_helper
INFO - 2018-07-31 03:38:14 --> Database Driver Class Initialized
DEBUG - 2018-07-31 03:38:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 03:38:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 03:38:14 --> Email Class Initialized
INFO - 2018-07-31 03:38:14 --> Controller Class Initialized
DEBUG - 2018-07-31 03:38:14 --> Programs MX_Controller Initialized
INFO - 2018-07-31 03:38:14 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-31 03:38:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-07-31 03:38:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-31 03:38:14 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-31 03:38:14 --> Login MX_Controller Initialized
DEBUG - 2018-07-31 03:38:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-31 03:38:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-31 03:38:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-31 03:38:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-31 03:38:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-31 03:38:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-31 03:38:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/programs/programs.php
INFO - 2018-07-31 03:38:14 --> Final output sent to browser
DEBUG - 2018-07-31 03:38:14 --> Total execution time: 0.7617
INFO - 2018-07-31 03:38:14 --> Config Class Initialized
INFO - 2018-07-31 03:38:15 --> Hooks Class Initialized
DEBUG - 2018-07-31 03:38:15 --> UTF-8 Support Enabled
INFO - 2018-07-31 03:38:15 --> Utf8 Class Initialized
INFO - 2018-07-31 03:38:15 --> URI Class Initialized
INFO - 2018-07-31 03:38:15 --> Router Class Initialized
INFO - 2018-07-31 03:38:15 --> Output Class Initialized
INFO - 2018-07-31 03:38:15 --> Security Class Initialized
DEBUG - 2018-07-31 03:38:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 03:38:15 --> Input Class Initialized
INFO - 2018-07-31 03:38:15 --> Language Class Initialized
INFO - 2018-07-31 03:38:15 --> Language Class Initialized
INFO - 2018-07-31 03:38:15 --> Config Class Initialized
INFO - 2018-07-31 03:38:15 --> Loader Class Initialized
DEBUG - 2018-07-31 03:38:15 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-31 03:38:15 --> Helper loaded: url_helper
INFO - 2018-07-31 03:38:15 --> Helper loaded: form_helper
INFO - 2018-07-31 03:38:15 --> Helper loaded: date_helper
INFO - 2018-07-31 03:38:15 --> Helper loaded: util_helper
INFO - 2018-07-31 03:38:15 --> Helper loaded: text_helper
INFO - 2018-07-31 03:38:15 --> Helper loaded: string_helper
INFO - 2018-07-31 03:38:15 --> Database Driver Class Initialized
DEBUG - 2018-07-31 03:38:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 03:38:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 03:38:15 --> Email Class Initialized
INFO - 2018-07-31 03:38:15 --> Controller Class Initialized
DEBUG - 2018-07-31 03:38:15 --> Programs MX_Controller Initialized
INFO - 2018-07-31 03:38:15 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-31 03:38:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-07-31 03:38:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-31 03:38:15 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-31 03:38:15 --> Login MX_Controller Initialized
DEBUG - 2018-07-31 03:38:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-31 03:38:15 --> Final output sent to browser
DEBUG - 2018-07-31 03:38:15 --> Total execution time: 0.7132
INFO - 2018-07-31 03:38:19 --> Config Class Initialized
INFO - 2018-07-31 03:38:19 --> Hooks Class Initialized
DEBUG - 2018-07-31 03:38:19 --> UTF-8 Support Enabled
INFO - 2018-07-31 03:38:19 --> Utf8 Class Initialized
INFO - 2018-07-31 03:38:19 --> URI Class Initialized
INFO - 2018-07-31 03:38:19 --> Router Class Initialized
INFO - 2018-07-31 03:38:19 --> Output Class Initialized
INFO - 2018-07-31 03:38:19 --> Security Class Initialized
DEBUG - 2018-07-31 03:38:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 03:38:20 --> Input Class Initialized
INFO - 2018-07-31 03:38:20 --> Language Class Initialized
INFO - 2018-07-31 03:38:20 --> Language Class Initialized
INFO - 2018-07-31 03:38:20 --> Config Class Initialized
INFO - 2018-07-31 03:38:20 --> Loader Class Initialized
DEBUG - 2018-07-31 03:38:20 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-31 03:38:20 --> Helper loaded: url_helper
INFO - 2018-07-31 03:38:20 --> Helper loaded: form_helper
INFO - 2018-07-31 03:38:20 --> Helper loaded: date_helper
INFO - 2018-07-31 03:38:20 --> Helper loaded: util_helper
INFO - 2018-07-31 03:38:20 --> Helper loaded: text_helper
INFO - 2018-07-31 03:38:20 --> Helper loaded: string_helper
INFO - 2018-07-31 03:38:20 --> Database Driver Class Initialized
DEBUG - 2018-07-31 03:38:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 03:38:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 03:38:20 --> Email Class Initialized
INFO - 2018-07-31 03:38:20 --> Controller Class Initialized
DEBUG - 2018-07-31 03:38:20 --> Programs MX_Controller Initialized
INFO - 2018-07-31 03:38:20 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-31 03:38:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-07-31 03:38:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-31 03:38:20 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-31 03:38:20 --> Login MX_Controller Initialized
DEBUG - 2018-07-31 03:38:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-31 03:38:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-31 03:38:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-31 03:38:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-31 03:38:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-31 03:38:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-31 03:38:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/programs/create_program.php
INFO - 2018-07-31 03:38:20 --> Final output sent to browser
DEBUG - 2018-07-31 03:38:20 --> Total execution time: 0.6473
INFO - 2018-07-31 03:38:23 --> Config Class Initialized
INFO - 2018-07-31 03:38:23 --> Hooks Class Initialized
DEBUG - 2018-07-31 03:38:23 --> UTF-8 Support Enabled
INFO - 2018-07-31 03:38:23 --> Utf8 Class Initialized
INFO - 2018-07-31 03:38:23 --> URI Class Initialized
INFO - 2018-07-31 03:38:23 --> Router Class Initialized
INFO - 2018-07-31 03:38:23 --> Output Class Initialized
INFO - 2018-07-31 03:38:23 --> Security Class Initialized
DEBUG - 2018-07-31 03:38:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 03:38:23 --> Input Class Initialized
INFO - 2018-07-31 03:38:23 --> Language Class Initialized
INFO - 2018-07-31 03:38:23 --> Language Class Initialized
INFO - 2018-07-31 03:38:23 --> Config Class Initialized
INFO - 2018-07-31 03:38:23 --> Loader Class Initialized
DEBUG - 2018-07-31 03:38:23 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-31 03:38:23 --> Helper loaded: url_helper
INFO - 2018-07-31 03:38:23 --> Helper loaded: form_helper
INFO - 2018-07-31 03:38:23 --> Helper loaded: date_helper
INFO - 2018-07-31 03:38:23 --> Helper loaded: util_helper
INFO - 2018-07-31 03:38:23 --> Helper loaded: text_helper
INFO - 2018-07-31 03:38:23 --> Helper loaded: string_helper
INFO - 2018-07-31 03:38:23 --> Database Driver Class Initialized
DEBUG - 2018-07-31 03:38:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 03:38:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 03:38:23 --> Email Class Initialized
INFO - 2018-07-31 03:38:23 --> Controller Class Initialized
DEBUG - 2018-07-31 03:38:23 --> Programs MX_Controller Initialized
INFO - 2018-07-31 03:38:23 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-31 03:38:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-07-31 03:38:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-31 03:38:23 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-31 03:38:23 --> Login MX_Controller Initialized
DEBUG - 2018-07-31 03:38:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-31 03:38:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-31 03:38:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-31 03:38:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-31 03:38:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-31 03:38:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-31 03:38:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/programs/programs.php
INFO - 2018-07-31 03:38:24 --> Final output sent to browser
DEBUG - 2018-07-31 03:38:24 --> Total execution time: 0.6671
INFO - 2018-07-31 03:38:24 --> Config Class Initialized
INFO - 2018-07-31 03:38:24 --> Hooks Class Initialized
DEBUG - 2018-07-31 03:38:24 --> UTF-8 Support Enabled
INFO - 2018-07-31 03:38:24 --> Utf8 Class Initialized
INFO - 2018-07-31 03:38:24 --> URI Class Initialized
INFO - 2018-07-31 03:38:24 --> Router Class Initialized
INFO - 2018-07-31 03:38:24 --> Output Class Initialized
INFO - 2018-07-31 03:38:24 --> Security Class Initialized
DEBUG - 2018-07-31 03:38:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 03:38:24 --> Input Class Initialized
INFO - 2018-07-31 03:38:24 --> Language Class Initialized
INFO - 2018-07-31 03:38:24 --> Language Class Initialized
INFO - 2018-07-31 03:38:24 --> Config Class Initialized
INFO - 2018-07-31 03:38:24 --> Loader Class Initialized
DEBUG - 2018-07-31 03:38:24 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-31 03:38:24 --> Helper loaded: url_helper
INFO - 2018-07-31 03:38:24 --> Helper loaded: form_helper
INFO - 2018-07-31 03:38:24 --> Helper loaded: date_helper
INFO - 2018-07-31 03:38:24 --> Helper loaded: util_helper
INFO - 2018-07-31 03:38:24 --> Helper loaded: text_helper
INFO - 2018-07-31 03:38:24 --> Helper loaded: string_helper
INFO - 2018-07-31 03:38:24 --> Database Driver Class Initialized
DEBUG - 2018-07-31 03:38:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 03:38:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 03:38:24 --> Email Class Initialized
INFO - 2018-07-31 03:38:24 --> Controller Class Initialized
DEBUG - 2018-07-31 03:38:24 --> Programs MX_Controller Initialized
INFO - 2018-07-31 03:38:24 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-31 03:38:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-07-31 03:38:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-31 03:38:25 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-31 03:38:25 --> Login MX_Controller Initialized
DEBUG - 2018-07-31 03:38:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-31 03:38:25 --> Final output sent to browser
DEBUG - 2018-07-31 03:38:25 --> Total execution time: 0.8560
INFO - 2018-07-31 03:38:26 --> Config Class Initialized
INFO - 2018-07-31 03:38:26 --> Hooks Class Initialized
DEBUG - 2018-07-31 03:38:26 --> UTF-8 Support Enabled
INFO - 2018-07-31 03:38:26 --> Utf8 Class Initialized
INFO - 2018-07-31 03:38:26 --> URI Class Initialized
INFO - 2018-07-31 03:38:26 --> Router Class Initialized
INFO - 2018-07-31 03:38:26 --> Output Class Initialized
INFO - 2018-07-31 03:38:26 --> Security Class Initialized
DEBUG - 2018-07-31 03:38:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 03:38:26 --> Input Class Initialized
INFO - 2018-07-31 03:38:26 --> Language Class Initialized
INFO - 2018-07-31 03:38:26 --> Language Class Initialized
INFO - 2018-07-31 03:38:26 --> Config Class Initialized
INFO - 2018-07-31 03:38:26 --> Loader Class Initialized
DEBUG - 2018-07-31 03:38:26 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-31 03:38:26 --> Helper loaded: url_helper
INFO - 2018-07-31 03:38:26 --> Helper loaded: form_helper
INFO - 2018-07-31 03:38:26 --> Helper loaded: date_helper
INFO - 2018-07-31 03:38:26 --> Helper loaded: util_helper
INFO - 2018-07-31 03:38:26 --> Helper loaded: text_helper
INFO - 2018-07-31 03:38:26 --> Helper loaded: string_helper
INFO - 2018-07-31 03:38:26 --> Config Class Initialized
INFO - 2018-07-31 03:38:26 --> Hooks Class Initialized
INFO - 2018-07-31 03:38:26 --> Database Driver Class Initialized
DEBUG - 2018-07-31 03:38:26 --> UTF-8 Support Enabled
INFO - 2018-07-31 03:38:26 --> Utf8 Class Initialized
INFO - 2018-07-31 03:38:26 --> URI Class Initialized
INFO - 2018-07-31 03:38:26 --> Router Class Initialized
DEBUG - 2018-07-31 03:38:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 03:38:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 03:38:26 --> Output Class Initialized
INFO - 2018-07-31 03:38:26 --> Security Class Initialized
INFO - 2018-07-31 03:38:26 --> Email Class Initialized
INFO - 2018-07-31 03:38:26 --> Controller Class Initialized
DEBUG - 2018-07-31 03:38:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-07-31 03:38:26 --> Admin MX_Controller Initialized
INFO - 2018-07-31 03:38:26 --> Input Class Initialized
INFO - 2018-07-31 03:38:26 --> Language file loaded: language/english/data_lang.php
INFO - 2018-07-31 03:38:26 --> Language Class Initialized
DEBUG - 2018-07-31 03:38:26 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
INFO - 2018-07-31 03:38:26 --> Language Class Initialized
DEBUG - 2018-07-31 03:38:26 --> Login MX_Controller Initialized
DEBUG - 2018-07-31 03:38:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-31 03:38:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-31 03:38:26 --> Config Class Initialized
INFO - 2018-07-31 03:38:26 --> Loader Class Initialized
DEBUG - 2018-07-31 03:38:26 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-31 03:38:26 --> Helper loaded: url_helper
INFO - 2018-07-31 03:38:26 --> Final output sent to browser
DEBUG - 2018-07-31 03:38:26 --> Total execution time: 0.7587
INFO - 2018-07-31 03:38:26 --> Helper loaded: form_helper
INFO - 2018-07-31 03:38:26 --> Helper loaded: date_helper
INFO - 2018-07-31 03:38:27 --> Helper loaded: util_helper
INFO - 2018-07-31 03:38:27 --> Helper loaded: text_helper
INFO - 2018-07-31 03:38:27 --> Helper loaded: string_helper
INFO - 2018-07-31 03:38:27 --> Database Driver Class Initialized
INFO - 2018-07-31 03:38:27 --> Config Class Initialized
DEBUG - 2018-07-31 03:38:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 03:38:27 --> Hooks Class Initialized
INFO - 2018-07-31 03:38:27 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-07-31 03:38:27 --> UTF-8 Support Enabled
INFO - 2018-07-31 03:38:27 --> Email Class Initialized
INFO - 2018-07-31 03:38:27 --> Controller Class Initialized
INFO - 2018-07-31 03:38:27 --> Utf8 Class Initialized
DEBUG - 2018-07-31 03:38:27 --> Admin MX_Controller Initialized
INFO - 2018-07-31 03:38:27 --> URI Class Initialized
INFO - 2018-07-31 03:38:27 --> Language file loaded: language/english/data_lang.php
INFO - 2018-07-31 03:38:27 --> Router Class Initialized
DEBUG - 2018-07-31 03:38:27 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
INFO - 2018-07-31 03:38:27 --> Output Class Initialized
DEBUG - 2018-07-31 03:38:27 --> Login MX_Controller Initialized
DEBUG - 2018-07-31 03:38:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-31 03:38:27 --> Security Class Initialized
DEBUG - 2018-07-31 03:38:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-31 03:38:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 03:38:27 --> Input Class Initialized
INFO - 2018-07-31 03:38:27 --> Language Class Initialized
INFO - 2018-07-31 03:38:27 --> Language Class Initialized
INFO - 2018-07-31 03:38:27 --> Final output sent to browser
DEBUG - 2018-07-31 03:38:27 --> Total execution time: 0.7179
INFO - 2018-07-31 03:38:27 --> Config Class Initialized
INFO - 2018-07-31 03:38:27 --> Loader Class Initialized
DEBUG - 2018-07-31 03:38:27 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-31 03:38:27 --> Helper loaded: url_helper
INFO - 2018-07-31 03:38:27 --> Helper loaded: form_helper
INFO - 2018-07-31 03:38:27 --> Helper loaded: date_helper
INFO - 2018-07-31 03:38:27 --> Helper loaded: util_helper
INFO - 2018-07-31 03:38:27 --> Helper loaded: text_helper
INFO - 2018-07-31 03:38:27 --> Helper loaded: string_helper
INFO - 2018-07-31 03:38:27 --> Database Driver Class Initialized
DEBUG - 2018-07-31 03:38:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 03:38:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 03:38:27 --> Email Class Initialized
INFO - 2018-07-31 03:38:27 --> Controller Class Initialized
DEBUG - 2018-07-31 03:38:27 --> Admin MX_Controller Initialized
INFO - 2018-07-31 03:38:27 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-31 03:38:27 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-31 03:38:27 --> Login MX_Controller Initialized
DEBUG - 2018-07-31 03:38:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-31 03:38:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-31 03:38:27 --> Final output sent to browser
DEBUG - 2018-07-31 03:38:27 --> Total execution time: 0.6514
INFO - 2018-07-31 03:38:33 --> Config Class Initialized
INFO - 2018-07-31 03:38:33 --> Hooks Class Initialized
DEBUG - 2018-07-31 03:38:33 --> UTF-8 Support Enabled
INFO - 2018-07-31 03:38:33 --> Utf8 Class Initialized
INFO - 2018-07-31 03:38:33 --> URI Class Initialized
INFO - 2018-07-31 03:38:33 --> Router Class Initialized
INFO - 2018-07-31 03:38:33 --> Output Class Initialized
INFO - 2018-07-31 03:38:33 --> Security Class Initialized
DEBUG - 2018-07-31 03:38:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 03:38:33 --> Input Class Initialized
INFO - 2018-07-31 03:38:33 --> Language Class Initialized
INFO - 2018-07-31 03:38:33 --> Language Class Initialized
INFO - 2018-07-31 03:38:33 --> Config Class Initialized
INFO - 2018-07-31 03:38:33 --> Loader Class Initialized
DEBUG - 2018-07-31 03:38:33 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-31 03:38:33 --> Helper loaded: url_helper
INFO - 2018-07-31 03:38:33 --> Helper loaded: form_helper
INFO - 2018-07-31 03:38:33 --> Helper loaded: date_helper
INFO - 2018-07-31 03:38:33 --> Helper loaded: util_helper
INFO - 2018-07-31 03:38:33 --> Helper loaded: text_helper
INFO - 2018-07-31 03:38:33 --> Helper loaded: string_helper
INFO - 2018-07-31 03:38:33 --> Database Driver Class Initialized
DEBUG - 2018-07-31 03:38:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 03:38:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 03:38:33 --> Email Class Initialized
INFO - 2018-07-31 03:38:33 --> Controller Class Initialized
DEBUG - 2018-07-31 03:38:33 --> Admin MX_Controller Initialized
INFO - 2018-07-31 03:38:33 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-31 03:38:33 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-31 03:38:33 --> Login MX_Controller Initialized
DEBUG - 2018-07-31 03:38:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-31 03:38:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-31 03:38:33 --> Final output sent to browser
DEBUG - 2018-07-31 03:38:33 --> Total execution time: 0.6378
INFO - 2018-07-31 03:39:35 --> Config Class Initialized
INFO - 2018-07-31 03:39:35 --> Hooks Class Initialized
DEBUG - 2018-07-31 03:39:35 --> UTF-8 Support Enabled
INFO - 2018-07-31 03:39:35 --> Utf8 Class Initialized
INFO - 2018-07-31 03:39:35 --> URI Class Initialized
INFO - 2018-07-31 03:39:35 --> Router Class Initialized
INFO - 2018-07-31 03:39:35 --> Output Class Initialized
INFO - 2018-07-31 03:39:35 --> Security Class Initialized
DEBUG - 2018-07-31 03:39:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 03:39:35 --> Input Class Initialized
INFO - 2018-07-31 03:39:35 --> Language Class Initialized
INFO - 2018-07-31 03:39:35 --> Language Class Initialized
INFO - 2018-07-31 03:39:35 --> Config Class Initialized
INFO - 2018-07-31 03:39:35 --> Loader Class Initialized
DEBUG - 2018-07-31 03:39:35 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-31 03:39:35 --> Helper loaded: url_helper
INFO - 2018-07-31 03:39:35 --> Helper loaded: form_helper
INFO - 2018-07-31 03:39:35 --> Helper loaded: date_helper
INFO - 2018-07-31 03:39:35 --> Helper loaded: util_helper
INFO - 2018-07-31 03:39:35 --> Helper loaded: text_helper
INFO - 2018-07-31 03:39:35 --> Helper loaded: string_helper
INFO - 2018-07-31 03:39:35 --> Database Driver Class Initialized
DEBUG - 2018-07-31 03:39:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 03:39:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 03:39:36 --> Email Class Initialized
INFO - 2018-07-31 03:39:36 --> Controller Class Initialized
DEBUG - 2018-07-31 03:39:36 --> Programs MX_Controller Initialized
INFO - 2018-07-31 03:39:36 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-31 03:39:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-07-31 03:39:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-31 03:39:36 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-31 03:39:36 --> Login MX_Controller Initialized
DEBUG - 2018-07-31 03:39:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-31 03:39:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-31 03:39:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-31 03:39:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-31 03:39:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-31 03:39:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-31 03:39:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/programs/create_program.php
INFO - 2018-07-31 03:39:36 --> Final output sent to browser
DEBUG - 2018-07-31 03:39:36 --> Total execution time: 0.6662
INFO - 2018-07-31 03:39:42 --> Config Class Initialized
INFO - 2018-07-31 03:39:42 --> Hooks Class Initialized
DEBUG - 2018-07-31 03:39:42 --> UTF-8 Support Enabled
INFO - 2018-07-31 03:39:42 --> Utf8 Class Initialized
INFO - 2018-07-31 03:39:42 --> URI Class Initialized
INFO - 2018-07-31 03:39:42 --> Router Class Initialized
INFO - 2018-07-31 03:39:42 --> Output Class Initialized
INFO - 2018-07-31 03:39:42 --> Security Class Initialized
DEBUG - 2018-07-31 03:39:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 03:39:43 --> Input Class Initialized
INFO - 2018-07-31 03:39:43 --> Language Class Initialized
INFO - 2018-07-31 03:39:43 --> Language Class Initialized
INFO - 2018-07-31 03:39:43 --> Config Class Initialized
INFO - 2018-07-31 03:39:43 --> Loader Class Initialized
DEBUG - 2018-07-31 03:39:43 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-31 03:39:43 --> Helper loaded: url_helper
INFO - 2018-07-31 03:39:43 --> Helper loaded: form_helper
INFO - 2018-07-31 03:39:43 --> Helper loaded: date_helper
INFO - 2018-07-31 03:39:43 --> Helper loaded: util_helper
INFO - 2018-07-31 03:39:43 --> Helper loaded: text_helper
INFO - 2018-07-31 03:39:43 --> Helper loaded: string_helper
INFO - 2018-07-31 03:39:43 --> Database Driver Class Initialized
DEBUG - 2018-07-31 03:39:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 03:39:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 03:39:43 --> Email Class Initialized
INFO - 2018-07-31 03:39:43 --> Controller Class Initialized
DEBUG - 2018-07-31 03:39:43 --> Programs MX_Controller Initialized
INFO - 2018-07-31 03:39:43 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-31 03:39:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-07-31 03:39:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-31 03:39:43 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-31 03:39:43 --> Login MX_Controller Initialized
DEBUG - 2018-07-31 03:39:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-31 03:39:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
INFO - 2018-07-31 03:39:43 --> Upload Class Initialized
INFO - 2018-07-31 03:39:43 --> Language file loaded: language/english/upload_lang.php
INFO - 2018-07-31 03:39:43 --> The uploaded file exceeds the maximum allowed size in your PHP configuration file.
INFO - 2018-07-31 03:39:43 --> Config Class Initialized
INFO - 2018-07-31 03:39:43 --> Hooks Class Initialized
DEBUG - 2018-07-31 03:39:43 --> UTF-8 Support Enabled
INFO - 2018-07-31 03:39:43 --> Utf8 Class Initialized
INFO - 2018-07-31 03:39:43 --> URI Class Initialized
INFO - 2018-07-31 03:39:43 --> Router Class Initialized
INFO - 2018-07-31 03:39:43 --> Output Class Initialized
INFO - 2018-07-31 03:39:43 --> Security Class Initialized
DEBUG - 2018-07-31 03:39:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 03:39:43 --> Input Class Initialized
INFO - 2018-07-31 03:39:43 --> Language Class Initialized
INFO - 2018-07-31 03:39:43 --> Language Class Initialized
INFO - 2018-07-31 03:39:43 --> Config Class Initialized
INFO - 2018-07-31 03:39:43 --> Loader Class Initialized
DEBUG - 2018-07-31 03:39:43 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-31 03:39:43 --> Helper loaded: url_helper
INFO - 2018-07-31 03:39:43 --> Helper loaded: form_helper
INFO - 2018-07-31 03:39:43 --> Helper loaded: date_helper
INFO - 2018-07-31 03:39:43 --> Helper loaded: util_helper
INFO - 2018-07-31 03:39:43 --> Helper loaded: text_helper
INFO - 2018-07-31 03:39:43 --> Helper loaded: string_helper
INFO - 2018-07-31 03:39:43 --> Database Driver Class Initialized
DEBUG - 2018-07-31 03:39:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 03:39:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 03:39:43 --> Email Class Initialized
INFO - 2018-07-31 03:39:43 --> Controller Class Initialized
DEBUG - 2018-07-31 03:39:43 --> Users MX_Controller Initialized
DEBUG - 2018-07-31 03:39:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-31 03:39:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-07-31 03:39:43 --> Helper loaded: file_helper
DEBUG - 2018-07-31 03:39:44 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-31 03:39:44 --> Login MX_Controller Initialized
INFO - 2018-07-31 03:39:44 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-31 03:39:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-31 03:39:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-31 03:39:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-31 03:39:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-31 03:39:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-31 03:39:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-31 03:39:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-31 03:39:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/create_user.php
INFO - 2018-07-31 03:39:44 --> Final output sent to browser
DEBUG - 2018-07-31 03:39:44 --> Total execution time: 0.6890
INFO - 2018-07-31 03:39:47 --> Config Class Initialized
INFO - 2018-07-31 03:39:47 --> Hooks Class Initialized
DEBUG - 2018-07-31 03:39:47 --> UTF-8 Support Enabled
INFO - 2018-07-31 03:39:47 --> Utf8 Class Initialized
INFO - 2018-07-31 03:39:47 --> URI Class Initialized
INFO - 2018-07-31 03:39:47 --> Router Class Initialized
INFO - 2018-07-31 03:39:47 --> Output Class Initialized
INFO - 2018-07-31 03:39:47 --> Security Class Initialized
DEBUG - 2018-07-31 03:39:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 03:39:47 --> Input Class Initialized
INFO - 2018-07-31 03:39:47 --> Language Class Initialized
ERROR - 2018-07-31 03:39:47 --> 404 Page Not Found: /index
INFO - 2018-07-31 03:39:51 --> Config Class Initialized
INFO - 2018-07-31 03:39:51 --> Hooks Class Initialized
DEBUG - 2018-07-31 03:39:51 --> UTF-8 Support Enabled
INFO - 2018-07-31 03:39:51 --> Utf8 Class Initialized
INFO - 2018-07-31 03:39:51 --> URI Class Initialized
INFO - 2018-07-31 03:39:51 --> Router Class Initialized
INFO - 2018-07-31 03:39:52 --> Output Class Initialized
INFO - 2018-07-31 03:39:52 --> Security Class Initialized
DEBUG - 2018-07-31 03:39:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 03:39:52 --> Input Class Initialized
INFO - 2018-07-31 03:39:52 --> Language Class Initialized
INFO - 2018-07-31 03:39:52 --> Language Class Initialized
INFO - 2018-07-31 03:39:52 --> Config Class Initialized
INFO - 2018-07-31 03:39:52 --> Loader Class Initialized
DEBUG - 2018-07-31 03:39:52 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-31 03:39:52 --> Helper loaded: url_helper
INFO - 2018-07-31 03:39:52 --> Helper loaded: form_helper
INFO - 2018-07-31 03:39:52 --> Helper loaded: date_helper
INFO - 2018-07-31 03:39:52 --> Helper loaded: util_helper
INFO - 2018-07-31 03:39:52 --> Helper loaded: text_helper
INFO - 2018-07-31 03:39:52 --> Helper loaded: string_helper
INFO - 2018-07-31 03:39:52 --> Database Driver Class Initialized
DEBUG - 2018-07-31 03:39:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 03:39:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 03:39:52 --> Email Class Initialized
INFO - 2018-07-31 03:39:52 --> Controller Class Initialized
DEBUG - 2018-07-31 03:39:52 --> Programs MX_Controller Initialized
INFO - 2018-07-31 03:39:52 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-31 03:39:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-07-31 03:39:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-31 03:39:52 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-31 03:39:52 --> Login MX_Controller Initialized
DEBUG - 2018-07-31 03:39:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-31 03:39:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
INFO - 2018-07-31 03:39:52 --> Upload Class Initialized
INFO - 2018-07-31 03:39:52 --> Language file loaded: language/english/upload_lang.php
INFO - 2018-07-31 03:39:52 --> The uploaded file exceeds the maximum allowed size in your PHP configuration file.
INFO - 2018-07-31 03:39:52 --> Config Class Initialized
INFO - 2018-07-31 03:39:52 --> Hooks Class Initialized
DEBUG - 2018-07-31 03:39:52 --> UTF-8 Support Enabled
INFO - 2018-07-31 03:39:52 --> Utf8 Class Initialized
INFO - 2018-07-31 03:39:52 --> URI Class Initialized
INFO - 2018-07-31 03:39:52 --> Router Class Initialized
INFO - 2018-07-31 03:39:52 --> Output Class Initialized
INFO - 2018-07-31 03:39:52 --> Security Class Initialized
DEBUG - 2018-07-31 03:39:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 03:39:52 --> Input Class Initialized
INFO - 2018-07-31 03:39:52 --> Language Class Initialized
INFO - 2018-07-31 03:39:52 --> Language Class Initialized
INFO - 2018-07-31 03:39:52 --> Config Class Initialized
INFO - 2018-07-31 03:39:52 --> Loader Class Initialized
DEBUG - 2018-07-31 03:39:52 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-31 03:39:52 --> Helper loaded: url_helper
INFO - 2018-07-31 03:39:52 --> Helper loaded: form_helper
INFO - 2018-07-31 03:39:52 --> Helper loaded: date_helper
INFO - 2018-07-31 03:39:52 --> Helper loaded: util_helper
INFO - 2018-07-31 03:39:52 --> Helper loaded: text_helper
INFO - 2018-07-31 03:39:52 --> Helper loaded: string_helper
INFO - 2018-07-31 03:39:52 --> Database Driver Class Initialized
DEBUG - 2018-07-31 03:39:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 03:39:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 03:39:53 --> Email Class Initialized
INFO - 2018-07-31 03:39:53 --> Controller Class Initialized
DEBUG - 2018-07-31 03:39:53 --> Users MX_Controller Initialized
DEBUG - 2018-07-31 03:39:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-31 03:39:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-07-31 03:39:53 --> Helper loaded: file_helper
DEBUG - 2018-07-31 03:39:53 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-31 03:39:53 --> Login MX_Controller Initialized
INFO - 2018-07-31 03:39:53 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-31 03:39:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-31 03:39:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-31 03:39:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-31 03:39:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-31 03:39:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-31 03:39:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-31 03:39:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-31 03:39:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/create_user.php
INFO - 2018-07-31 03:39:53 --> Final output sent to browser
DEBUG - 2018-07-31 03:39:53 --> Total execution time: 0.7015
INFO - 2018-07-31 03:39:57 --> Config Class Initialized
INFO - 2018-07-31 03:39:57 --> Hooks Class Initialized
DEBUG - 2018-07-31 03:39:57 --> UTF-8 Support Enabled
INFO - 2018-07-31 03:39:57 --> Utf8 Class Initialized
INFO - 2018-07-31 03:39:57 --> URI Class Initialized
INFO - 2018-07-31 03:39:57 --> Router Class Initialized
INFO - 2018-07-31 03:39:57 --> Output Class Initialized
INFO - 2018-07-31 03:39:57 --> Security Class Initialized
DEBUG - 2018-07-31 03:39:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 03:39:57 --> Input Class Initialized
INFO - 2018-07-31 03:39:57 --> Language Class Initialized
INFO - 2018-07-31 03:39:57 --> Language Class Initialized
INFO - 2018-07-31 03:39:57 --> Config Class Initialized
INFO - 2018-07-31 03:39:57 --> Loader Class Initialized
DEBUG - 2018-07-31 03:39:57 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-31 03:39:57 --> Helper loaded: url_helper
INFO - 2018-07-31 03:39:57 --> Helper loaded: form_helper
INFO - 2018-07-31 03:39:57 --> Helper loaded: date_helper
INFO - 2018-07-31 03:39:57 --> Helper loaded: util_helper
INFO - 2018-07-31 03:39:57 --> Helper loaded: text_helper
INFO - 2018-07-31 03:39:57 --> Helper loaded: string_helper
INFO - 2018-07-31 03:39:57 --> Database Driver Class Initialized
DEBUG - 2018-07-31 03:39:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 03:39:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 03:39:57 --> Email Class Initialized
INFO - 2018-07-31 03:39:57 --> Controller Class Initialized
DEBUG - 2018-07-31 03:39:57 --> Programs MX_Controller Initialized
INFO - 2018-07-31 03:39:57 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-31 03:39:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-07-31 03:39:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-31 03:39:57 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-31 03:39:57 --> Login MX_Controller Initialized
DEBUG - 2018-07-31 03:39:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-31 03:39:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-31 03:39:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-31 03:39:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-31 03:39:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-31 03:39:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-31 03:39:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/programs/create_program.php
INFO - 2018-07-31 03:39:57 --> Final output sent to browser
DEBUG - 2018-07-31 03:39:57 --> Total execution time: 0.8149
INFO - 2018-07-31 03:39:58 --> Config Class Initialized
INFO - 2018-07-31 03:39:58 --> Hooks Class Initialized
DEBUG - 2018-07-31 03:39:58 --> UTF-8 Support Enabled
INFO - 2018-07-31 03:39:58 --> Utf8 Class Initialized
INFO - 2018-07-31 03:39:58 --> URI Class Initialized
INFO - 2018-07-31 03:39:58 --> Router Class Initialized
INFO - 2018-07-31 03:39:58 --> Output Class Initialized
INFO - 2018-07-31 03:39:58 --> Security Class Initialized
DEBUG - 2018-07-31 03:39:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 03:39:58 --> Input Class Initialized
INFO - 2018-07-31 03:39:58 --> Language Class Initialized
ERROR - 2018-07-31 03:39:58 --> 404 Page Not Found: /index
INFO - 2018-07-31 03:40:09 --> Config Class Initialized
INFO - 2018-07-31 03:40:09 --> Hooks Class Initialized
DEBUG - 2018-07-31 03:40:09 --> UTF-8 Support Enabled
INFO - 2018-07-31 03:40:09 --> Utf8 Class Initialized
INFO - 2018-07-31 03:40:09 --> URI Class Initialized
INFO - 2018-07-31 03:40:09 --> Router Class Initialized
INFO - 2018-07-31 03:40:09 --> Output Class Initialized
INFO - 2018-07-31 03:40:09 --> Security Class Initialized
DEBUG - 2018-07-31 03:40:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 03:40:09 --> Input Class Initialized
INFO - 2018-07-31 03:40:09 --> Language Class Initialized
INFO - 2018-07-31 03:40:09 --> Language Class Initialized
INFO - 2018-07-31 03:40:09 --> Config Class Initialized
INFO - 2018-07-31 03:40:09 --> Loader Class Initialized
DEBUG - 2018-07-31 03:40:09 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-31 03:40:09 --> Helper loaded: url_helper
INFO - 2018-07-31 03:40:09 --> Helper loaded: form_helper
INFO - 2018-07-31 03:40:09 --> Helper loaded: date_helper
INFO - 2018-07-31 03:40:09 --> Helper loaded: util_helper
INFO - 2018-07-31 03:40:09 --> Helper loaded: text_helper
INFO - 2018-07-31 03:40:09 --> Helper loaded: string_helper
INFO - 2018-07-31 03:40:09 --> Database Driver Class Initialized
DEBUG - 2018-07-31 03:40:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 03:40:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 03:40:09 --> Email Class Initialized
INFO - 2018-07-31 03:40:09 --> Controller Class Initialized
DEBUG - 2018-07-31 03:40:09 --> Programs MX_Controller Initialized
INFO - 2018-07-31 03:40:09 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-31 03:40:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-07-31 03:40:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-31 03:40:09 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-31 03:40:09 --> Login MX_Controller Initialized
DEBUG - 2018-07-31 03:40:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-31 03:40:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
INFO - 2018-07-31 03:40:09 --> Upload Class Initialized
INFO - 2018-07-31 03:40:09 --> Language file loaded: language/english/upload_lang.php
INFO - 2018-07-31 03:40:09 --> The uploaded file exceeds the maximum allowed size in your PHP configuration file.
INFO - 2018-07-31 03:40:09 --> Config Class Initialized
INFO - 2018-07-31 03:40:09 --> Hooks Class Initialized
DEBUG - 2018-07-31 03:40:09 --> UTF-8 Support Enabled
INFO - 2018-07-31 03:40:09 --> Utf8 Class Initialized
INFO - 2018-07-31 03:40:09 --> URI Class Initialized
INFO - 2018-07-31 03:40:09 --> Router Class Initialized
INFO - 2018-07-31 03:40:09 --> Output Class Initialized
INFO - 2018-07-31 03:40:10 --> Security Class Initialized
DEBUG - 2018-07-31 03:40:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 03:40:10 --> Input Class Initialized
INFO - 2018-07-31 03:40:10 --> Language Class Initialized
INFO - 2018-07-31 03:40:10 --> Language Class Initialized
INFO - 2018-07-31 03:40:10 --> Config Class Initialized
INFO - 2018-07-31 03:40:10 --> Loader Class Initialized
DEBUG - 2018-07-31 03:40:10 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-31 03:40:10 --> Helper loaded: url_helper
INFO - 2018-07-31 03:40:10 --> Helper loaded: form_helper
INFO - 2018-07-31 03:40:10 --> Helper loaded: date_helper
INFO - 2018-07-31 03:40:10 --> Helper loaded: util_helper
INFO - 2018-07-31 03:40:10 --> Helper loaded: text_helper
INFO - 2018-07-31 03:40:10 --> Helper loaded: string_helper
INFO - 2018-07-31 03:40:10 --> Database Driver Class Initialized
DEBUG - 2018-07-31 03:40:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 03:40:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 03:40:10 --> Email Class Initialized
INFO - 2018-07-31 03:40:10 --> Controller Class Initialized
DEBUG - 2018-07-31 03:40:10 --> Users MX_Controller Initialized
DEBUG - 2018-07-31 03:40:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-31 03:40:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-07-31 03:40:10 --> Helper loaded: file_helper
DEBUG - 2018-07-31 03:40:10 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-31 03:40:10 --> Login MX_Controller Initialized
INFO - 2018-07-31 03:40:10 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-31 03:40:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-31 03:40:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-31 03:40:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-31 03:40:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-31 03:40:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-31 03:40:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-31 03:40:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-31 03:40:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/create_user.php
INFO - 2018-07-31 03:40:10 --> Final output sent to browser
DEBUG - 2018-07-31 03:40:10 --> Total execution time: 0.7017
INFO - 2018-07-31 03:42:43 --> Config Class Initialized
INFO - 2018-07-31 03:42:43 --> Hooks Class Initialized
DEBUG - 2018-07-31 03:42:43 --> UTF-8 Support Enabled
INFO - 2018-07-31 03:42:43 --> Utf8 Class Initialized
INFO - 2018-07-31 03:42:43 --> URI Class Initialized
INFO - 2018-07-31 03:42:43 --> Router Class Initialized
INFO - 2018-07-31 03:42:43 --> Output Class Initialized
INFO - 2018-07-31 03:42:43 --> Security Class Initialized
DEBUG - 2018-07-31 03:42:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 03:42:44 --> Input Class Initialized
INFO - 2018-07-31 03:42:44 --> Language Class Initialized
INFO - 2018-07-31 03:42:44 --> Language Class Initialized
INFO - 2018-07-31 03:42:44 --> Config Class Initialized
INFO - 2018-07-31 03:42:44 --> Loader Class Initialized
DEBUG - 2018-07-31 03:42:44 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-31 03:42:44 --> Helper loaded: url_helper
INFO - 2018-07-31 03:42:44 --> Helper loaded: form_helper
INFO - 2018-07-31 03:42:44 --> Helper loaded: date_helper
INFO - 2018-07-31 03:42:44 --> Helper loaded: util_helper
INFO - 2018-07-31 03:42:44 --> Helper loaded: text_helper
INFO - 2018-07-31 03:42:44 --> Helper loaded: string_helper
INFO - 2018-07-31 03:42:44 --> Database Driver Class Initialized
DEBUG - 2018-07-31 03:42:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 03:42:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 03:42:44 --> Email Class Initialized
INFO - 2018-07-31 03:42:44 --> Controller Class Initialized
DEBUG - 2018-07-31 03:42:44 --> Programs MX_Controller Initialized
INFO - 2018-07-31 03:42:44 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-31 03:42:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-07-31 03:42:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-31 03:42:44 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-31 03:42:44 --> Login MX_Controller Initialized
DEBUG - 2018-07-31 03:42:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-31 03:42:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
INFO - 2018-07-31 03:42:44 --> Upload Class Initialized
INFO - 2018-07-31 03:42:44 --> Language file loaded: language/english/upload_lang.php
INFO - 2018-07-31 03:42:44 --> The uploaded file exceeds the maximum allowed size in your PHP configuration file.
INFO - 2018-07-31 03:42:53 --> Config Class Initialized
INFO - 2018-07-31 03:42:53 --> Hooks Class Initialized
DEBUG - 2018-07-31 03:42:53 --> UTF-8 Support Enabled
INFO - 2018-07-31 03:42:53 --> Utf8 Class Initialized
INFO - 2018-07-31 03:42:53 --> URI Class Initialized
INFO - 2018-07-31 03:42:53 --> Router Class Initialized
INFO - 2018-07-31 03:42:53 --> Output Class Initialized
INFO - 2018-07-31 03:42:53 --> Security Class Initialized
DEBUG - 2018-07-31 03:42:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 03:42:53 --> Input Class Initialized
INFO - 2018-07-31 03:42:53 --> Language Class Initialized
INFO - 2018-07-31 03:42:53 --> Language Class Initialized
INFO - 2018-07-31 03:42:53 --> Config Class Initialized
INFO - 2018-07-31 03:42:53 --> Loader Class Initialized
DEBUG - 2018-07-31 03:42:53 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-31 03:42:53 --> Helper loaded: url_helper
INFO - 2018-07-31 03:42:53 --> Helper loaded: form_helper
INFO - 2018-07-31 03:42:53 --> Helper loaded: date_helper
INFO - 2018-07-31 03:42:53 --> Helper loaded: util_helper
INFO - 2018-07-31 03:42:53 --> Helper loaded: text_helper
INFO - 2018-07-31 03:42:53 --> Helper loaded: string_helper
INFO - 2018-07-31 03:42:53 --> Database Driver Class Initialized
DEBUG - 2018-07-31 03:42:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 03:42:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 03:42:53 --> Email Class Initialized
INFO - 2018-07-31 03:42:53 --> Controller Class Initialized
DEBUG - 2018-07-31 03:42:53 --> Programs MX_Controller Initialized
INFO - 2018-07-31 03:42:53 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-31 03:42:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-07-31 03:42:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-31 03:42:53 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-31 03:42:53 --> Login MX_Controller Initialized
DEBUG - 2018-07-31 03:42:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-31 03:42:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
INFO - 2018-07-31 03:42:53 --> Upload Class Initialized
INFO - 2018-07-31 03:42:53 --> Language file loaded: language/english/upload_lang.php
INFO - 2018-07-31 03:42:53 --> The uploaded file exceeds the maximum allowed size in your PHP configuration file.
INFO - 2018-07-31 03:42:57 --> Config Class Initialized
INFO - 2018-07-31 03:42:57 --> Hooks Class Initialized
DEBUG - 2018-07-31 03:42:57 --> UTF-8 Support Enabled
INFO - 2018-07-31 03:42:57 --> Utf8 Class Initialized
INFO - 2018-07-31 03:42:57 --> URI Class Initialized
INFO - 2018-07-31 03:42:57 --> Router Class Initialized
INFO - 2018-07-31 03:42:57 --> Output Class Initialized
INFO - 2018-07-31 03:42:57 --> Security Class Initialized
DEBUG - 2018-07-31 03:42:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 03:42:57 --> Input Class Initialized
INFO - 2018-07-31 03:42:57 --> Language Class Initialized
INFO - 2018-07-31 03:42:57 --> Language Class Initialized
INFO - 2018-07-31 03:42:57 --> Config Class Initialized
INFO - 2018-07-31 03:42:57 --> Loader Class Initialized
DEBUG - 2018-07-31 03:42:57 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-31 03:42:57 --> Helper loaded: url_helper
INFO - 2018-07-31 03:42:57 --> Helper loaded: form_helper
INFO - 2018-07-31 03:42:57 --> Helper loaded: date_helper
INFO - 2018-07-31 03:42:57 --> Helper loaded: util_helper
INFO - 2018-07-31 03:42:57 --> Helper loaded: text_helper
INFO - 2018-07-31 03:42:57 --> Helper loaded: string_helper
INFO - 2018-07-31 03:42:57 --> Database Driver Class Initialized
DEBUG - 2018-07-31 03:42:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 03:42:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 03:42:57 --> Email Class Initialized
INFO - 2018-07-31 03:42:57 --> Controller Class Initialized
DEBUG - 2018-07-31 03:42:57 --> Programs MX_Controller Initialized
INFO - 2018-07-31 03:42:57 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-31 03:42:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-07-31 03:42:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-31 03:42:57 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-31 03:42:57 --> Login MX_Controller Initialized
DEBUG - 2018-07-31 03:42:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-31 03:42:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
INFO - 2018-07-31 03:42:57 --> Upload Class Initialized
INFO - 2018-07-31 03:42:57 --> Language file loaded: language/english/upload_lang.php
INFO - 2018-07-31 03:42:57 --> The uploaded file exceeds the maximum allowed size in your PHP configuration file.
INFO - 2018-07-31 03:43:12 --> Config Class Initialized
INFO - 2018-07-31 03:43:12 --> Hooks Class Initialized
DEBUG - 2018-07-31 03:43:12 --> UTF-8 Support Enabled
INFO - 2018-07-31 03:43:12 --> Utf8 Class Initialized
INFO - 2018-07-31 03:43:12 --> URI Class Initialized
INFO - 2018-07-31 03:43:12 --> Router Class Initialized
INFO - 2018-07-31 03:43:12 --> Output Class Initialized
INFO - 2018-07-31 03:43:12 --> Security Class Initialized
DEBUG - 2018-07-31 03:43:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 03:43:12 --> Input Class Initialized
INFO - 2018-07-31 03:43:12 --> Language Class Initialized
INFO - 2018-07-31 03:43:12 --> Language Class Initialized
INFO - 2018-07-31 03:43:12 --> Config Class Initialized
INFO - 2018-07-31 03:43:12 --> Loader Class Initialized
DEBUG - 2018-07-31 03:43:12 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-31 03:43:12 --> Helper loaded: url_helper
INFO - 2018-07-31 03:43:12 --> Helper loaded: form_helper
INFO - 2018-07-31 03:43:12 --> Helper loaded: date_helper
INFO - 2018-07-31 03:43:12 --> Helper loaded: util_helper
INFO - 2018-07-31 03:43:12 --> Helper loaded: text_helper
INFO - 2018-07-31 03:43:12 --> Helper loaded: string_helper
INFO - 2018-07-31 03:43:12 --> Database Driver Class Initialized
DEBUG - 2018-07-31 03:43:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 03:43:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 03:43:12 --> Email Class Initialized
INFO - 2018-07-31 03:43:12 --> Controller Class Initialized
DEBUG - 2018-07-31 03:43:12 --> Programs MX_Controller Initialized
INFO - 2018-07-31 03:43:12 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-31 03:43:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-07-31 03:43:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-31 03:43:12 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-31 03:43:12 --> Login MX_Controller Initialized
DEBUG - 2018-07-31 03:43:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-31 03:43:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
INFO - 2018-07-31 03:43:12 --> Upload Class Initialized
INFO - 2018-07-31 03:43:12 --> Language file loaded: language/english/upload_lang.php
INFO - 2018-07-31 03:43:12 --> The uploaded file exceeds the maximum allowed size in your PHP configuration file.
INFO - 2018-07-31 03:44:31 --> Config Class Initialized
INFO - 2018-07-31 03:44:31 --> Hooks Class Initialized
DEBUG - 2018-07-31 03:44:31 --> UTF-8 Support Enabled
INFO - 2018-07-31 03:44:31 --> Utf8 Class Initialized
INFO - 2018-07-31 03:44:31 --> URI Class Initialized
INFO - 2018-07-31 03:44:31 --> Router Class Initialized
INFO - 2018-07-31 03:44:31 --> Output Class Initialized
INFO - 2018-07-31 03:44:31 --> Security Class Initialized
DEBUG - 2018-07-31 03:44:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 03:44:31 --> Input Class Initialized
INFO - 2018-07-31 03:44:31 --> Language Class Initialized
INFO - 2018-07-31 03:44:31 --> Language Class Initialized
INFO - 2018-07-31 03:44:31 --> Config Class Initialized
INFO - 2018-07-31 03:44:31 --> Loader Class Initialized
DEBUG - 2018-07-31 03:44:31 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-31 03:44:31 --> Helper loaded: url_helper
INFO - 2018-07-31 03:44:31 --> Helper loaded: form_helper
INFO - 2018-07-31 03:44:31 --> Helper loaded: date_helper
INFO - 2018-07-31 03:44:31 --> Helper loaded: util_helper
INFO - 2018-07-31 03:44:31 --> Helper loaded: text_helper
INFO - 2018-07-31 03:44:31 --> Helper loaded: string_helper
INFO - 2018-07-31 03:44:31 --> Database Driver Class Initialized
DEBUG - 2018-07-31 03:44:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 03:44:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 03:44:31 --> Email Class Initialized
INFO - 2018-07-31 03:44:31 --> Controller Class Initialized
DEBUG - 2018-07-31 03:44:31 --> Programs MX_Controller Initialized
INFO - 2018-07-31 03:44:31 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-31 03:44:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-07-31 03:44:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-31 03:44:31 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-31 03:44:31 --> Login MX_Controller Initialized
DEBUG - 2018-07-31 03:44:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-31 03:44:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
INFO - 2018-07-31 03:44:32 --> Upload Class Initialized
ERROR - 2018-07-31 03:44:32 --> Severity: Warning --> unlink(E:\xampp\htdocs\consulting\assets/images/programs/): Permission denied E:\xampp\htdocs\consulting\application\modules\admin\controllers\Programs.php 187
INFO - 2018-07-31 03:44:36 --> Config Class Initialized
INFO - 2018-07-31 03:44:36 --> Hooks Class Initialized
DEBUG - 2018-07-31 03:44:36 --> UTF-8 Support Enabled
INFO - 2018-07-31 03:44:36 --> Utf8 Class Initialized
INFO - 2018-07-31 03:44:36 --> URI Class Initialized
INFO - 2018-07-31 03:44:37 --> Router Class Initialized
INFO - 2018-07-31 03:44:37 --> Output Class Initialized
INFO - 2018-07-31 03:44:37 --> Security Class Initialized
DEBUG - 2018-07-31 03:44:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 03:44:37 --> Input Class Initialized
INFO - 2018-07-31 03:44:37 --> Language Class Initialized
ERROR - 2018-07-31 03:44:37 --> 404 Page Not Found: /index
INFO - 2018-07-31 03:44:55 --> Config Class Initialized
INFO - 2018-07-31 03:44:55 --> Hooks Class Initialized
DEBUG - 2018-07-31 03:44:55 --> UTF-8 Support Enabled
INFO - 2018-07-31 03:44:55 --> Utf8 Class Initialized
INFO - 2018-07-31 03:44:55 --> URI Class Initialized
INFO - 2018-07-31 03:44:55 --> Router Class Initialized
INFO - 2018-07-31 03:44:55 --> Output Class Initialized
INFO - 2018-07-31 03:44:55 --> Security Class Initialized
DEBUG - 2018-07-31 03:44:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 03:44:55 --> Input Class Initialized
INFO - 2018-07-31 03:44:55 --> Language Class Initialized
INFO - 2018-07-31 03:44:55 --> Language Class Initialized
INFO - 2018-07-31 03:44:55 --> Config Class Initialized
INFO - 2018-07-31 03:44:55 --> Loader Class Initialized
DEBUG - 2018-07-31 03:44:55 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-31 03:44:55 --> Helper loaded: url_helper
INFO - 2018-07-31 03:44:55 --> Helper loaded: form_helper
INFO - 2018-07-31 03:44:56 --> Helper loaded: date_helper
INFO - 2018-07-31 03:44:56 --> Helper loaded: util_helper
INFO - 2018-07-31 03:44:56 --> Helper loaded: text_helper
INFO - 2018-07-31 03:44:56 --> Helper loaded: string_helper
INFO - 2018-07-31 03:44:56 --> Database Driver Class Initialized
DEBUG - 2018-07-31 03:44:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 03:44:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 03:44:56 --> Email Class Initialized
INFO - 2018-07-31 03:44:56 --> Controller Class Initialized
DEBUG - 2018-07-31 03:44:56 --> Programs MX_Controller Initialized
INFO - 2018-07-31 03:44:56 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-31 03:44:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-07-31 03:44:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-31 03:44:56 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-31 03:44:56 --> Login MX_Controller Initialized
DEBUG - 2018-07-31 03:44:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-31 03:44:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
INFO - 2018-07-31 03:44:56 --> Upload Class Initialized
ERROR - 2018-07-31 03:44:56 --> Severity: Warning --> unlink(E:\xampp\htdocs\consulting\assets/images/programs/): Permission denied E:\xampp\htdocs\consulting\application\modules\admin\controllers\Programs.php 187
INFO - 2018-07-31 03:45:54 --> Config Class Initialized
INFO - 2018-07-31 03:45:54 --> Hooks Class Initialized
DEBUG - 2018-07-31 03:45:54 --> UTF-8 Support Enabled
INFO - 2018-07-31 03:45:54 --> Utf8 Class Initialized
INFO - 2018-07-31 03:45:54 --> URI Class Initialized
INFO - 2018-07-31 03:45:54 --> Router Class Initialized
INFO - 2018-07-31 03:45:54 --> Output Class Initialized
INFO - 2018-07-31 03:45:54 --> Security Class Initialized
DEBUG - 2018-07-31 03:45:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 03:45:54 --> Input Class Initialized
INFO - 2018-07-31 03:45:54 --> Language Class Initialized
INFO - 2018-07-31 03:45:54 --> Language Class Initialized
INFO - 2018-07-31 03:45:54 --> Config Class Initialized
INFO - 2018-07-31 03:45:54 --> Loader Class Initialized
DEBUG - 2018-07-31 03:45:54 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-31 03:45:54 --> Helper loaded: url_helper
INFO - 2018-07-31 03:45:54 --> Helper loaded: form_helper
INFO - 2018-07-31 03:45:54 --> Helper loaded: date_helper
INFO - 2018-07-31 03:45:54 --> Helper loaded: util_helper
INFO - 2018-07-31 03:45:54 --> Helper loaded: text_helper
INFO - 2018-07-31 03:45:54 --> Helper loaded: string_helper
INFO - 2018-07-31 03:45:54 --> Database Driver Class Initialized
DEBUG - 2018-07-31 03:45:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 03:45:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 03:45:54 --> Email Class Initialized
INFO - 2018-07-31 03:45:54 --> Controller Class Initialized
DEBUG - 2018-07-31 03:45:55 --> Programs MX_Controller Initialized
INFO - 2018-07-31 03:45:55 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-31 03:45:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-07-31 03:45:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-31 03:45:55 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-31 03:45:55 --> Login MX_Controller Initialized
DEBUG - 2018-07-31 03:45:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-31 03:45:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
INFO - 2018-07-31 03:45:55 --> Upload Class Initialized
ERROR - 2018-07-31 03:45:55 --> Severity: Warning --> unlink(E:\xampp\htdocs\consulting\assets/images/programs/): Permission denied E:\xampp\htdocs\consulting\application\modules\admin\controllers\Programs.php 187
INFO - 2018-07-31 03:46:56 --> Config Class Initialized
INFO - 2018-07-31 03:46:56 --> Hooks Class Initialized
DEBUG - 2018-07-31 03:46:56 --> UTF-8 Support Enabled
INFO - 2018-07-31 03:46:57 --> Utf8 Class Initialized
INFO - 2018-07-31 03:46:57 --> URI Class Initialized
INFO - 2018-07-31 03:46:57 --> Router Class Initialized
INFO - 2018-07-31 03:46:57 --> Output Class Initialized
INFO - 2018-07-31 03:46:57 --> Security Class Initialized
DEBUG - 2018-07-31 03:46:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 03:46:57 --> Input Class Initialized
INFO - 2018-07-31 03:46:57 --> Language Class Initialized
INFO - 2018-07-31 03:46:57 --> Language Class Initialized
INFO - 2018-07-31 03:46:57 --> Config Class Initialized
INFO - 2018-07-31 03:46:57 --> Loader Class Initialized
DEBUG - 2018-07-31 03:46:57 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-31 03:46:57 --> Helper loaded: url_helper
INFO - 2018-07-31 03:46:57 --> Helper loaded: form_helper
INFO - 2018-07-31 03:46:57 --> Helper loaded: date_helper
INFO - 2018-07-31 03:46:57 --> Helper loaded: util_helper
INFO - 2018-07-31 03:46:57 --> Helper loaded: text_helper
INFO - 2018-07-31 03:46:57 --> Helper loaded: string_helper
INFO - 2018-07-31 03:46:57 --> Database Driver Class Initialized
DEBUG - 2018-07-31 03:46:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 03:46:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 03:46:57 --> Email Class Initialized
INFO - 2018-07-31 03:46:57 --> Controller Class Initialized
DEBUG - 2018-07-31 03:46:57 --> Programs MX_Controller Initialized
INFO - 2018-07-31 03:46:57 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-31 03:46:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-07-31 03:46:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-31 03:46:57 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-31 03:46:57 --> Login MX_Controller Initialized
DEBUG - 2018-07-31 03:46:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-31 03:46:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
INFO - 2018-07-31 03:46:57 --> Upload Class Initialized
ERROR - 2018-07-31 03:46:57 --> Severity: Warning --> unlink(E:\xampp\htdocs\consulting\assets/images/programs/): Permission denied E:\xampp\htdocs\consulting\application\modules\admin\controllers\Programs.php 187
INFO - 2018-07-31 05:00:19 --> Config Class Initialized
INFO - 2018-07-31 05:00:19 --> Hooks Class Initialized
DEBUG - 2018-07-31 05:00:19 --> UTF-8 Support Enabled
INFO - 2018-07-31 05:00:19 --> Utf8 Class Initialized
INFO - 2018-07-31 05:00:19 --> URI Class Initialized
INFO - 2018-07-31 05:00:19 --> Router Class Initialized
INFO - 2018-07-31 05:00:19 --> Output Class Initialized
INFO - 2018-07-31 05:00:19 --> Security Class Initialized
DEBUG - 2018-07-31 05:00:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 05:00:19 --> Input Class Initialized
INFO - 2018-07-31 05:00:19 --> Language Class Initialized
INFO - 2018-07-31 05:00:19 --> Language Class Initialized
INFO - 2018-07-31 05:00:19 --> Config Class Initialized
INFO - 2018-07-31 05:00:19 --> Loader Class Initialized
DEBUG - 2018-07-31 05:00:19 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-31 05:00:19 --> Helper loaded: url_helper
INFO - 2018-07-31 05:00:19 --> Helper loaded: form_helper
INFO - 2018-07-31 05:00:19 --> Helper loaded: date_helper
INFO - 2018-07-31 05:00:19 --> Helper loaded: util_helper
INFO - 2018-07-31 05:00:19 --> Helper loaded: text_helper
INFO - 2018-07-31 05:00:20 --> Helper loaded: string_helper
INFO - 2018-07-31 05:00:20 --> Database Driver Class Initialized
DEBUG - 2018-07-31 05:00:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 05:00:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 05:00:20 --> Email Class Initialized
INFO - 2018-07-31 05:00:20 --> Controller Class Initialized
DEBUG - 2018-07-31 05:00:20 --> Programs MX_Controller Initialized
INFO - 2018-07-31 05:00:20 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-31 05:00:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-07-31 05:00:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-31 05:00:20 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-31 05:00:20 --> Login MX_Controller Initialized
DEBUG - 2018-07-31 05:00:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-31 05:00:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
INFO - 2018-07-31 05:00:20 --> Upload Class Initialized
INFO - 2018-07-31 05:00:20 --> Config Class Initialized
INFO - 2018-07-31 05:00:20 --> Hooks Class Initialized
DEBUG - 2018-07-31 05:00:20 --> UTF-8 Support Enabled
INFO - 2018-07-31 05:00:20 --> Utf8 Class Initialized
INFO - 2018-07-31 05:00:20 --> URI Class Initialized
INFO - 2018-07-31 05:00:20 --> Router Class Initialized
INFO - 2018-07-31 05:00:20 --> Output Class Initialized
INFO - 2018-07-31 05:00:20 --> Security Class Initialized
DEBUG - 2018-07-31 05:00:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 05:00:20 --> Input Class Initialized
INFO - 2018-07-31 05:00:20 --> Language Class Initialized
INFO - 2018-07-31 05:00:20 --> Language Class Initialized
INFO - 2018-07-31 05:00:20 --> Config Class Initialized
INFO - 2018-07-31 05:00:20 --> Loader Class Initialized
DEBUG - 2018-07-31 05:00:20 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-31 05:00:20 --> Helper loaded: url_helper
INFO - 2018-07-31 05:00:20 --> Helper loaded: form_helper
INFO - 2018-07-31 05:00:20 --> Helper loaded: date_helper
INFO - 2018-07-31 05:00:20 --> Helper loaded: util_helper
INFO - 2018-07-31 05:00:20 --> Helper loaded: text_helper
INFO - 2018-07-31 05:00:20 --> Helper loaded: string_helper
INFO - 2018-07-31 05:00:20 --> Database Driver Class Initialized
DEBUG - 2018-07-31 05:00:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 05:00:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 05:00:20 --> Email Class Initialized
INFO - 2018-07-31 05:00:20 --> Controller Class Initialized
DEBUG - 2018-07-31 05:00:20 --> Programs MX_Controller Initialized
INFO - 2018-07-31 05:00:20 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-31 05:00:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-07-31 05:00:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-31 05:00:20 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-31 05:00:20 --> Login MX_Controller Initialized
DEBUG - 2018-07-31 05:00:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-31 05:00:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-31 05:00:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-31 05:00:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-31 05:00:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-31 05:00:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-31 05:00:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/programs/programs.php
INFO - 2018-07-31 05:00:21 --> Final output sent to browser
DEBUG - 2018-07-31 05:00:21 --> Total execution time: 0.7233
INFO - 2018-07-31 05:00:21 --> Config Class Initialized
INFO - 2018-07-31 05:00:21 --> Hooks Class Initialized
DEBUG - 2018-07-31 05:00:21 --> UTF-8 Support Enabled
INFO - 2018-07-31 05:00:21 --> Utf8 Class Initialized
INFO - 2018-07-31 05:00:21 --> URI Class Initialized
INFO - 2018-07-31 05:00:21 --> Router Class Initialized
INFO - 2018-07-31 05:00:21 --> Output Class Initialized
INFO - 2018-07-31 05:00:21 --> Security Class Initialized
DEBUG - 2018-07-31 05:00:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 05:00:21 --> Input Class Initialized
INFO - 2018-07-31 05:00:21 --> Language Class Initialized
INFO - 2018-07-31 05:00:21 --> Language Class Initialized
INFO - 2018-07-31 05:00:21 --> Config Class Initialized
INFO - 2018-07-31 05:00:21 --> Loader Class Initialized
DEBUG - 2018-07-31 05:00:22 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-31 05:00:22 --> Helper loaded: url_helper
INFO - 2018-07-31 05:00:22 --> Helper loaded: form_helper
INFO - 2018-07-31 05:00:22 --> Helper loaded: date_helper
INFO - 2018-07-31 05:00:22 --> Helper loaded: util_helper
INFO - 2018-07-31 05:00:22 --> Helper loaded: text_helper
INFO - 2018-07-31 05:00:22 --> Helper loaded: string_helper
INFO - 2018-07-31 05:00:22 --> Database Driver Class Initialized
DEBUG - 2018-07-31 05:00:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 05:00:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 05:00:22 --> Email Class Initialized
INFO - 2018-07-31 05:00:22 --> Controller Class Initialized
DEBUG - 2018-07-31 05:00:22 --> Programs MX_Controller Initialized
INFO - 2018-07-31 05:00:22 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-31 05:00:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-07-31 05:00:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-31 05:00:22 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-31 05:00:22 --> Login MX_Controller Initialized
DEBUG - 2018-07-31 05:00:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-31 05:00:22 --> Final output sent to browser
DEBUG - 2018-07-31 05:00:22 --> Total execution time: 0.8069
INFO - 2018-07-31 05:00:24 --> Config Class Initialized
INFO - 2018-07-31 05:00:24 --> Hooks Class Initialized
DEBUG - 2018-07-31 05:00:24 --> UTF-8 Support Enabled
INFO - 2018-07-31 05:00:24 --> Utf8 Class Initialized
INFO - 2018-07-31 05:00:24 --> URI Class Initialized
INFO - 2018-07-31 05:00:24 --> Router Class Initialized
INFO - 2018-07-31 05:00:24 --> Output Class Initialized
INFO - 2018-07-31 05:00:24 --> Security Class Initialized
DEBUG - 2018-07-31 05:00:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 05:00:24 --> Input Class Initialized
INFO - 2018-07-31 05:00:24 --> Language Class Initialized
INFO - 2018-07-31 05:00:24 --> Language Class Initialized
INFO - 2018-07-31 05:00:24 --> Config Class Initialized
INFO - 2018-07-31 05:00:24 --> Loader Class Initialized
DEBUG - 2018-07-31 05:00:24 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-31 05:00:24 --> Helper loaded: url_helper
INFO - 2018-07-31 05:00:24 --> Helper loaded: form_helper
INFO - 2018-07-31 05:00:24 --> Helper loaded: date_helper
INFO - 2018-07-31 05:00:24 --> Helper loaded: util_helper
INFO - 2018-07-31 05:00:24 --> Helper loaded: text_helper
INFO - 2018-07-31 05:00:24 --> Helper loaded: string_helper
INFO - 2018-07-31 05:00:24 --> Database Driver Class Initialized
DEBUG - 2018-07-31 05:00:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 05:00:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 05:00:24 --> Email Class Initialized
INFO - 2018-07-31 05:00:24 --> Controller Class Initialized
DEBUG - 2018-07-31 05:00:24 --> Programs MX_Controller Initialized
INFO - 2018-07-31 05:00:24 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-31 05:00:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-07-31 05:00:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-31 05:00:24 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-31 05:00:24 --> Login MX_Controller Initialized
DEBUG - 2018-07-31 05:00:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-31 05:00:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-31 05:00:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-31 05:00:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-31 05:00:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-31 05:00:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-31 05:00:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/programs/create_program.php
INFO - 2018-07-31 05:00:24 --> Final output sent to browser
DEBUG - 2018-07-31 05:00:24 --> Total execution time: 0.6905
INFO - 2018-07-31 05:00:46 --> Config Class Initialized
INFO - 2018-07-31 05:00:46 --> Hooks Class Initialized
DEBUG - 2018-07-31 05:00:46 --> UTF-8 Support Enabled
INFO - 2018-07-31 05:00:46 --> Utf8 Class Initialized
INFO - 2018-07-31 05:00:46 --> URI Class Initialized
INFO - 2018-07-31 05:00:46 --> Router Class Initialized
INFO - 2018-07-31 05:00:46 --> Output Class Initialized
INFO - 2018-07-31 05:00:46 --> Security Class Initialized
DEBUG - 2018-07-31 05:00:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 05:00:46 --> Input Class Initialized
INFO - 2018-07-31 05:00:46 --> Language Class Initialized
INFO - 2018-07-31 05:00:46 --> Language Class Initialized
INFO - 2018-07-31 05:00:46 --> Config Class Initialized
INFO - 2018-07-31 05:00:46 --> Loader Class Initialized
DEBUG - 2018-07-31 05:00:46 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-31 05:00:46 --> Helper loaded: url_helper
INFO - 2018-07-31 05:00:46 --> Helper loaded: form_helper
INFO - 2018-07-31 05:00:46 --> Helper loaded: date_helper
INFO - 2018-07-31 05:00:46 --> Helper loaded: util_helper
INFO - 2018-07-31 05:00:46 --> Helper loaded: text_helper
INFO - 2018-07-31 05:00:46 --> Helper loaded: string_helper
INFO - 2018-07-31 05:00:46 --> Database Driver Class Initialized
DEBUG - 2018-07-31 05:00:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 05:00:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 05:00:46 --> Email Class Initialized
INFO - 2018-07-31 05:00:46 --> Controller Class Initialized
DEBUG - 2018-07-31 05:00:46 --> Programs MX_Controller Initialized
INFO - 2018-07-31 05:00:46 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-31 05:00:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-07-31 05:00:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-31 05:00:46 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-31 05:00:46 --> Login MX_Controller Initialized
DEBUG - 2018-07-31 05:00:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-31 05:00:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
INFO - 2018-07-31 05:00:46 --> Upload Class Initialized
INFO - 2018-07-31 05:00:47 --> Config Class Initialized
INFO - 2018-07-31 05:00:47 --> Hooks Class Initialized
DEBUG - 2018-07-31 05:00:47 --> UTF-8 Support Enabled
INFO - 2018-07-31 05:00:47 --> Utf8 Class Initialized
INFO - 2018-07-31 05:00:47 --> URI Class Initialized
INFO - 2018-07-31 05:00:47 --> Router Class Initialized
INFO - 2018-07-31 05:00:47 --> Output Class Initialized
INFO - 2018-07-31 05:00:47 --> Security Class Initialized
DEBUG - 2018-07-31 05:00:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 05:00:47 --> Input Class Initialized
INFO - 2018-07-31 05:00:47 --> Language Class Initialized
INFO - 2018-07-31 05:00:47 --> Language Class Initialized
INFO - 2018-07-31 05:00:47 --> Config Class Initialized
INFO - 2018-07-31 05:00:47 --> Loader Class Initialized
DEBUG - 2018-07-31 05:00:47 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-31 05:00:47 --> Helper loaded: url_helper
INFO - 2018-07-31 05:00:47 --> Helper loaded: form_helper
INFO - 2018-07-31 05:00:47 --> Helper loaded: date_helper
INFO - 2018-07-31 05:00:47 --> Helper loaded: util_helper
INFO - 2018-07-31 05:00:47 --> Helper loaded: text_helper
INFO - 2018-07-31 05:00:47 --> Helper loaded: string_helper
INFO - 2018-07-31 05:00:47 --> Database Driver Class Initialized
DEBUG - 2018-07-31 05:00:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 05:00:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 05:00:47 --> Email Class Initialized
INFO - 2018-07-31 05:00:47 --> Controller Class Initialized
DEBUG - 2018-07-31 05:00:47 --> Programs MX_Controller Initialized
INFO - 2018-07-31 05:00:47 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-31 05:00:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-07-31 05:00:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-31 05:00:47 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-31 05:00:47 --> Login MX_Controller Initialized
DEBUG - 2018-07-31 05:00:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-31 05:00:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-31 05:00:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-31 05:00:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-31 05:00:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-31 05:00:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-31 05:00:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/programs/programs.php
INFO - 2018-07-31 05:00:47 --> Final output sent to browser
DEBUG - 2018-07-31 05:00:47 --> Total execution time: 0.8504
INFO - 2018-07-31 05:00:48 --> Config Class Initialized
INFO - 2018-07-31 05:00:48 --> Hooks Class Initialized
DEBUG - 2018-07-31 05:00:48 --> UTF-8 Support Enabled
INFO - 2018-07-31 05:00:48 --> Utf8 Class Initialized
INFO - 2018-07-31 05:00:48 --> URI Class Initialized
INFO - 2018-07-31 05:00:48 --> Router Class Initialized
INFO - 2018-07-31 05:00:48 --> Output Class Initialized
INFO - 2018-07-31 05:00:48 --> Security Class Initialized
DEBUG - 2018-07-31 05:00:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 05:00:48 --> Input Class Initialized
INFO - 2018-07-31 05:00:48 --> Language Class Initialized
INFO - 2018-07-31 05:00:48 --> Language Class Initialized
INFO - 2018-07-31 05:00:48 --> Config Class Initialized
INFO - 2018-07-31 05:00:48 --> Loader Class Initialized
DEBUG - 2018-07-31 05:00:48 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-31 05:00:48 --> Helper loaded: url_helper
INFO - 2018-07-31 05:00:48 --> Helper loaded: form_helper
INFO - 2018-07-31 05:00:48 --> Helper loaded: date_helper
INFO - 2018-07-31 05:00:48 --> Helper loaded: util_helper
INFO - 2018-07-31 05:00:48 --> Helper loaded: text_helper
INFO - 2018-07-31 05:00:48 --> Helper loaded: string_helper
INFO - 2018-07-31 05:00:48 --> Database Driver Class Initialized
DEBUG - 2018-07-31 05:00:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 05:00:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 05:00:48 --> Email Class Initialized
INFO - 2018-07-31 05:00:48 --> Controller Class Initialized
DEBUG - 2018-07-31 05:00:48 --> Programs MX_Controller Initialized
INFO - 2018-07-31 05:00:48 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-31 05:00:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-07-31 05:00:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-31 05:00:48 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-31 05:00:48 --> Login MX_Controller Initialized
DEBUG - 2018-07-31 05:00:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-31 05:00:49 --> Final output sent to browser
DEBUG - 2018-07-31 05:00:49 --> Total execution time: 0.7494
INFO - 2018-07-31 05:00:49 --> Config Class Initialized
INFO - 2018-07-31 05:00:49 --> Hooks Class Initialized
DEBUG - 2018-07-31 05:00:49 --> UTF-8 Support Enabled
INFO - 2018-07-31 05:00:49 --> Utf8 Class Initialized
INFO - 2018-07-31 05:00:49 --> URI Class Initialized
INFO - 2018-07-31 05:00:49 --> Router Class Initialized
INFO - 2018-07-31 05:00:49 --> Output Class Initialized
INFO - 2018-07-31 05:00:49 --> Security Class Initialized
DEBUG - 2018-07-31 05:00:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 05:00:49 --> Input Class Initialized
INFO - 2018-07-31 05:00:49 --> Language Class Initialized
INFO - 2018-07-31 05:00:49 --> Language Class Initialized
INFO - 2018-07-31 05:00:49 --> Config Class Initialized
INFO - 2018-07-31 05:00:49 --> Loader Class Initialized
DEBUG - 2018-07-31 05:00:49 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-31 05:00:49 --> Helper loaded: url_helper
INFO - 2018-07-31 05:00:49 --> Helper loaded: form_helper
INFO - 2018-07-31 05:00:49 --> Helper loaded: date_helper
INFO - 2018-07-31 05:00:49 --> Helper loaded: util_helper
INFO - 2018-07-31 05:00:49 --> Helper loaded: text_helper
INFO - 2018-07-31 05:00:49 --> Helper loaded: string_helper
INFO - 2018-07-31 05:00:49 --> Database Driver Class Initialized
DEBUG - 2018-07-31 05:00:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 05:00:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 05:00:50 --> Email Class Initialized
INFO - 2018-07-31 05:00:50 --> Controller Class Initialized
DEBUG - 2018-07-31 05:00:50 --> Programs MX_Controller Initialized
INFO - 2018-07-31 05:00:50 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-31 05:00:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-07-31 05:00:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-31 05:00:50 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-31 05:00:50 --> Login MX_Controller Initialized
DEBUG - 2018-07-31 05:00:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-31 05:00:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-31 05:00:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-31 05:00:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-31 05:00:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-31 05:00:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-31 05:00:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/programs/create_program.php
INFO - 2018-07-31 05:00:50 --> Final output sent to browser
DEBUG - 2018-07-31 05:00:50 --> Total execution time: 0.6942
INFO - 2018-07-31 05:00:55 --> Config Class Initialized
INFO - 2018-07-31 05:00:55 --> Hooks Class Initialized
DEBUG - 2018-07-31 05:00:55 --> UTF-8 Support Enabled
INFO - 2018-07-31 05:00:55 --> Utf8 Class Initialized
INFO - 2018-07-31 05:00:55 --> URI Class Initialized
INFO - 2018-07-31 05:00:55 --> Router Class Initialized
INFO - 2018-07-31 05:00:55 --> Output Class Initialized
INFO - 2018-07-31 05:00:55 --> Security Class Initialized
DEBUG - 2018-07-31 05:00:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 05:00:55 --> Input Class Initialized
INFO - 2018-07-31 05:00:55 --> Language Class Initialized
INFO - 2018-07-31 05:00:55 --> Language Class Initialized
INFO - 2018-07-31 05:00:55 --> Config Class Initialized
INFO - 2018-07-31 05:00:55 --> Loader Class Initialized
DEBUG - 2018-07-31 05:00:55 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-31 05:00:55 --> Helper loaded: url_helper
INFO - 2018-07-31 05:00:55 --> Helper loaded: form_helper
INFO - 2018-07-31 05:00:55 --> Helper loaded: date_helper
INFO - 2018-07-31 05:00:55 --> Helper loaded: util_helper
INFO - 2018-07-31 05:00:55 --> Helper loaded: text_helper
INFO - 2018-07-31 05:00:55 --> Helper loaded: string_helper
INFO - 2018-07-31 05:00:55 --> Database Driver Class Initialized
DEBUG - 2018-07-31 05:00:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 05:00:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 05:00:55 --> Email Class Initialized
INFO - 2018-07-31 05:00:55 --> Controller Class Initialized
DEBUG - 2018-07-31 05:00:55 --> Programs MX_Controller Initialized
INFO - 2018-07-31 05:00:55 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-31 05:00:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-07-31 05:00:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-31 05:00:55 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-31 05:00:55 --> Login MX_Controller Initialized
DEBUG - 2018-07-31 05:00:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-31 05:00:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-31 05:00:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-31 05:00:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-31 05:00:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-31 05:00:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-31 05:00:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/programs/programs.php
INFO - 2018-07-31 05:00:56 --> Final output sent to browser
DEBUG - 2018-07-31 05:00:56 --> Total execution time: 0.7124
INFO - 2018-07-31 05:00:56 --> Config Class Initialized
INFO - 2018-07-31 05:00:56 --> Hooks Class Initialized
DEBUG - 2018-07-31 05:00:56 --> UTF-8 Support Enabled
INFO - 2018-07-31 05:00:56 --> Utf8 Class Initialized
INFO - 2018-07-31 05:00:56 --> URI Class Initialized
INFO - 2018-07-31 05:00:56 --> Router Class Initialized
INFO - 2018-07-31 05:00:56 --> Output Class Initialized
INFO - 2018-07-31 05:00:56 --> Security Class Initialized
DEBUG - 2018-07-31 05:00:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 05:00:56 --> Input Class Initialized
INFO - 2018-07-31 05:00:56 --> Language Class Initialized
INFO - 2018-07-31 05:00:56 --> Language Class Initialized
INFO - 2018-07-31 05:00:56 --> Config Class Initialized
INFO - 2018-07-31 05:00:56 --> Loader Class Initialized
DEBUG - 2018-07-31 05:00:56 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-31 05:00:56 --> Helper loaded: url_helper
INFO - 2018-07-31 05:00:56 --> Helper loaded: form_helper
INFO - 2018-07-31 05:00:56 --> Helper loaded: date_helper
INFO - 2018-07-31 05:00:56 --> Helper loaded: util_helper
INFO - 2018-07-31 05:00:56 --> Helper loaded: text_helper
INFO - 2018-07-31 05:00:56 --> Helper loaded: string_helper
INFO - 2018-07-31 05:00:56 --> Database Driver Class Initialized
DEBUG - 2018-07-31 05:00:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 05:00:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 05:00:56 --> Email Class Initialized
INFO - 2018-07-31 05:00:56 --> Controller Class Initialized
DEBUG - 2018-07-31 05:00:57 --> Programs MX_Controller Initialized
INFO - 2018-07-31 05:00:57 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-31 05:00:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-07-31 05:00:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-31 05:00:57 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-31 05:00:57 --> Login MX_Controller Initialized
DEBUG - 2018-07-31 05:00:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-31 05:00:57 --> Final output sent to browser
DEBUG - 2018-07-31 05:00:57 --> Total execution time: 0.7674
INFO - 2018-07-31 05:02:41 --> Config Class Initialized
INFO - 2018-07-31 05:02:41 --> Hooks Class Initialized
DEBUG - 2018-07-31 05:02:41 --> UTF-8 Support Enabled
INFO - 2018-07-31 05:02:41 --> Utf8 Class Initialized
INFO - 2018-07-31 05:02:41 --> URI Class Initialized
INFO - 2018-07-31 05:02:41 --> Router Class Initialized
INFO - 2018-07-31 05:02:41 --> Output Class Initialized
INFO - 2018-07-31 05:02:41 --> Security Class Initialized
DEBUG - 2018-07-31 05:02:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 05:02:41 --> Config Class Initialized
INFO - 2018-07-31 05:02:41 --> Input Class Initialized
INFO - 2018-07-31 05:02:41 --> Hooks Class Initialized
INFO - 2018-07-31 05:02:41 --> Language Class Initialized
DEBUG - 2018-07-31 05:02:41 --> UTF-8 Support Enabled
INFO - 2018-07-31 05:02:41 --> Utf8 Class Initialized
INFO - 2018-07-31 05:02:41 --> Language Class Initialized
INFO - 2018-07-31 05:02:41 --> Config Class Initialized
INFO - 2018-07-31 05:02:41 --> URI Class Initialized
INFO - 2018-07-31 05:02:41 --> Router Class Initialized
INFO - 2018-07-31 05:02:41 --> Loader Class Initialized
DEBUG - 2018-07-31 05:02:41 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-31 05:02:41 --> Output Class Initialized
INFO - 2018-07-31 05:02:41 --> Helper loaded: url_helper
INFO - 2018-07-31 05:02:41 --> Security Class Initialized
DEBUG - 2018-07-31 05:02:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 05:02:41 --> Helper loaded: form_helper
INFO - 2018-07-31 05:02:41 --> Input Class Initialized
INFO - 2018-07-31 05:02:41 --> Language Class Initialized
INFO - 2018-07-31 05:02:41 --> Helper loaded: date_helper
INFO - 2018-07-31 05:02:41 --> Language Class Initialized
INFO - 2018-07-31 05:02:41 --> Config Class Initialized
INFO - 2018-07-31 05:02:41 --> Config Class Initialized
INFO - 2018-07-31 05:02:41 --> Hooks Class Initialized
INFO - 2018-07-31 05:02:41 --> Helper loaded: util_helper
INFO - 2018-07-31 05:02:41 --> Loader Class Initialized
INFO - 2018-07-31 05:02:41 --> Helper loaded: text_helper
DEBUG - 2018-07-31 05:02:41 --> UTF-8 Support Enabled
INFO - 2018-07-31 05:02:41 --> Utf8 Class Initialized
INFO - 2018-07-31 05:02:41 --> Helper loaded: string_helper
DEBUG - 2018-07-31 05:02:41 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-31 05:02:41 --> URI Class Initialized
INFO - 2018-07-31 05:02:41 --> Helper loaded: url_helper
INFO - 2018-07-31 05:02:41 --> Router Class Initialized
INFO - 2018-07-31 05:02:41 --> Helper loaded: form_helper
INFO - 2018-07-31 05:02:41 --> Database Driver Class Initialized
INFO - 2018-07-31 05:02:41 --> Output Class Initialized
DEBUG - 2018-07-31 05:02:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 05:02:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 05:02:41 --> Security Class Initialized
DEBUG - 2018-07-31 05:02:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 05:02:41 --> Email Class Initialized
INFO - 2018-07-31 05:02:41 --> Controller Class Initialized
INFO - 2018-07-31 05:02:41 --> Input Class Initialized
INFO - 2018-07-31 05:02:41 --> Helper loaded: date_helper
DEBUG - 2018-07-31 05:02:41 --> Programs MX_Controller Initialized
INFO - 2018-07-31 05:02:41 --> Language file loaded: language/english/data_lang.php
INFO - 2018-07-31 05:02:41 --> Config Class Initialized
INFO - 2018-07-31 05:02:41 --> Hooks Class Initialized
DEBUG - 2018-07-31 05:02:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
INFO - 2018-07-31 05:02:41 --> Language Class Initialized
INFO - 2018-07-31 05:02:41 --> Helper loaded: util_helper
DEBUG - 2018-07-31 05:02:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-31 05:02:41 --> UTF-8 Support Enabled
INFO - 2018-07-31 05:02:41 --> Utf8 Class Initialized
DEBUG - 2018-07-31 05:02:41 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-31 05:02:41 --> Login MX_Controller Initialized
INFO - 2018-07-31 05:02:41 --> URI Class Initialized
DEBUG - 2018-07-31 05:02:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-31 05:02:41 --> Router Class Initialized
INFO - 2018-07-31 05:02:41 --> Output Class Initialized
INFO - 2018-07-31 05:02:41 --> Helper loaded: text_helper
INFO - 2018-07-31 05:02:41 --> Language Class Initialized
INFO - 2018-07-31 05:02:41 --> Final output sent to browser
DEBUG - 2018-07-31 05:02:41 --> Total execution time: 0.7008
INFO - 2018-07-31 05:02:41 --> Security Class Initialized
DEBUG - 2018-07-31 05:02:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 05:02:41 --> Input Class Initialized
INFO - 2018-07-31 05:02:41 --> Language Class Initialized
INFO - 2018-07-31 05:02:41 --> Helper loaded: string_helper
INFO - 2018-07-31 05:02:41 --> Config Class Initialized
INFO - 2018-07-31 05:02:41 --> Hooks Class Initialized
INFO - 2018-07-31 05:02:41 --> Language Class Initialized
INFO - 2018-07-31 05:02:42 --> Config Class Initialized
DEBUG - 2018-07-31 05:02:42 --> UTF-8 Support Enabled
INFO - 2018-07-31 05:02:42 --> Utf8 Class Initialized
INFO - 2018-07-31 05:02:42 --> Loader Class Initialized
INFO - 2018-07-31 05:02:42 --> Config Class Initialized
INFO - 2018-07-31 05:02:42 --> Database Driver Class Initialized
INFO - 2018-07-31 05:02:42 --> Loader Class Initialized
DEBUG - 2018-07-31 05:02:42 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-31 05:02:42 --> URI Class Initialized
DEBUG - 2018-07-31 05:02:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 05:02:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 05:02:42 --> Helper loaded: url_helper
DEBUG - 2018-07-31 05:02:42 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-31 05:02:42 --> Router Class Initialized
INFO - 2018-07-31 05:02:42 --> Helper loaded: form_helper
INFO - 2018-07-31 05:02:42 --> Email Class Initialized
INFO - 2018-07-31 05:02:42 --> Helper loaded: url_helper
INFO - 2018-07-31 05:02:42 --> Output Class Initialized
INFO - 2018-07-31 05:02:42 --> Controller Class Initialized
INFO - 2018-07-31 05:02:42 --> Helper loaded: date_helper
INFO - 2018-07-31 05:02:42 --> Helper loaded: form_helper
INFO - 2018-07-31 05:02:42 --> Security Class Initialized
DEBUG - 2018-07-31 05:02:42 --> Programs MX_Controller Initialized
INFO - 2018-07-31 05:02:42 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-31 05:02:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-07-31 05:02:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 05:02:42 --> Helper loaded: util_helper
DEBUG - 2018-07-31 05:02:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-31 05:02:42 --> Helper loaded: text_helper
INFO - 2018-07-31 05:02:42 --> Helper loaded: date_helper
INFO - 2018-07-31 05:02:42 --> Helper loaded: util_helper
DEBUG - 2018-07-31 05:02:42 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
INFO - 2018-07-31 05:02:42 --> Helper loaded: string_helper
INFO - 2018-07-31 05:02:42 --> Input Class Initialized
DEBUG - 2018-07-31 05:02:42 --> Login MX_Controller Initialized
INFO - 2018-07-31 05:02:42 --> Language Class Initialized
INFO - 2018-07-31 05:02:42 --> Helper loaded: text_helper
INFO - 2018-07-31 05:02:42 --> Database Driver Class Initialized
INFO - 2018-07-31 05:02:42 --> Language Class Initialized
DEBUG - 2018-07-31 05:02:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-31 05:02:42 --> Helper loaded: string_helper
DEBUG - 2018-07-31 05:02:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 05:02:42 --> Config Class Initialized
INFO - 2018-07-31 05:02:42 --> Final output sent to browser
DEBUG - 2018-07-31 05:02:42 --> Total execution time: 0.8719
INFO - 2018-07-31 05:02:42 --> Loader Class Initialized
INFO - 2018-07-31 05:02:42 --> Database Driver Class Initialized
INFO - 2018-07-31 05:02:42 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-07-31 05:02:42 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-31 05:02:42 --> Email Class Initialized
DEBUG - 2018-07-31 05:02:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 05:02:42 --> Controller Class Initialized
INFO - 2018-07-31 05:02:42 --> Helper loaded: url_helper
DEBUG - 2018-07-31 05:02:42 --> Programs MX_Controller Initialized
INFO - 2018-07-31 05:02:42 --> Language file loaded: language/english/data_lang.php
INFO - 2018-07-31 05:02:42 --> Helper loaded: form_helper
DEBUG - 2018-07-31 05:02:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
INFO - 2018-07-31 05:02:42 --> Helper loaded: date_helper
DEBUG - 2018-07-31 05:02:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-31 05:02:42 --> Helper loaded: util_helper
INFO - 2018-07-31 05:02:42 --> Helper loaded: text_helper
DEBUG - 2018-07-31 05:02:42 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-31 05:02:42 --> Login MX_Controller Initialized
INFO - 2018-07-31 05:02:42 --> Helper loaded: string_helper
DEBUG - 2018-07-31 05:02:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-31 05:02:42 --> Database Driver Class Initialized
INFO - 2018-07-31 05:02:42 --> Final output sent to browser
DEBUG - 2018-07-31 05:02:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-07-31 05:02:42 --> Total execution time: 0.6454
INFO - 2018-07-31 05:02:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 05:02:42 --> Email Class Initialized
INFO - 2018-07-31 05:02:42 --> Controller Class Initialized
DEBUG - 2018-07-31 05:02:42 --> Programs MX_Controller Initialized
INFO - 2018-07-31 05:02:42 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-31 05:02:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-07-31 05:02:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-31 05:02:42 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-31 05:02:42 --> Login MX_Controller Initialized
DEBUG - 2018-07-31 05:02:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-31 05:02:42 --> Final output sent to browser
DEBUG - 2018-07-31 05:02:42 --> Total execution time: 1.0516
INFO - 2018-07-31 05:02:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 05:02:42 --> Email Class Initialized
INFO - 2018-07-31 05:02:42 --> Controller Class Initialized
DEBUG - 2018-07-31 05:02:42 --> Programs MX_Controller Initialized
INFO - 2018-07-31 05:02:42 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-31 05:02:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-07-31 05:02:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-31 05:02:42 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
INFO - 2018-07-31 05:02:42 --> Config Class Initialized
INFO - 2018-07-31 05:02:42 --> Hooks Class Initialized
DEBUG - 2018-07-31 05:02:42 --> Login MX_Controller Initialized
DEBUG - 2018-07-31 05:02:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-31 05:02:42 --> UTF-8 Support Enabled
INFO - 2018-07-31 05:02:42 --> Utf8 Class Initialized
INFO - 2018-07-31 05:02:42 --> Final output sent to browser
DEBUG - 2018-07-31 05:02:42 --> Total execution time: 0.8592
INFO - 2018-07-31 05:02:42 --> URI Class Initialized
INFO - 2018-07-31 05:02:42 --> Router Class Initialized
INFO - 2018-07-31 05:02:42 --> Output Class Initialized
INFO - 2018-07-31 05:02:42 --> Security Class Initialized
DEBUG - 2018-07-31 05:02:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 05:02:42 --> Input Class Initialized
INFO - 2018-07-31 05:02:42 --> Language Class Initialized
INFO - 2018-07-31 05:02:42 --> Language Class Initialized
INFO - 2018-07-31 05:02:42 --> Config Class Initialized
INFO - 2018-07-31 05:02:42 --> Loader Class Initialized
DEBUG - 2018-07-31 05:02:43 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-31 05:02:43 --> Helper loaded: url_helper
INFO - 2018-07-31 05:02:43 --> Helper loaded: form_helper
INFO - 2018-07-31 05:02:43 --> Helper loaded: date_helper
INFO - 2018-07-31 05:02:43 --> Helper loaded: util_helper
INFO - 2018-07-31 05:02:43 --> Helper loaded: text_helper
INFO - 2018-07-31 05:02:43 --> Helper loaded: string_helper
INFO - 2018-07-31 05:02:43 --> Database Driver Class Initialized
DEBUG - 2018-07-31 05:02:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 05:02:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 05:02:43 --> Email Class Initialized
INFO - 2018-07-31 05:02:43 --> Controller Class Initialized
DEBUG - 2018-07-31 05:02:43 --> Programs MX_Controller Initialized
INFO - 2018-07-31 05:02:43 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-31 05:02:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-07-31 05:02:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-31 05:02:43 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-31 05:02:43 --> Login MX_Controller Initialized
DEBUG - 2018-07-31 05:02:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-31 05:02:43 --> Final output sent to browser
DEBUG - 2018-07-31 05:02:43 --> Total execution time: 0.5568
INFO - 2018-07-31 05:02:43 --> Config Class Initialized
INFO - 2018-07-31 05:02:43 --> Hooks Class Initialized
DEBUG - 2018-07-31 05:02:43 --> UTF-8 Support Enabled
INFO - 2018-07-31 05:02:43 --> Utf8 Class Initialized
INFO - 2018-07-31 05:02:43 --> URI Class Initialized
INFO - 2018-07-31 05:02:43 --> Router Class Initialized
INFO - 2018-07-31 05:02:43 --> Output Class Initialized
INFO - 2018-07-31 05:02:43 --> Security Class Initialized
DEBUG - 2018-07-31 05:02:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 05:02:43 --> Config Class Initialized
INFO - 2018-07-31 05:02:43 --> Hooks Class Initialized
INFO - 2018-07-31 05:02:43 --> Input Class Initialized
INFO - 2018-07-31 05:02:43 --> Language Class Initialized
DEBUG - 2018-07-31 05:02:43 --> UTF-8 Support Enabled
INFO - 2018-07-31 05:02:43 --> Utf8 Class Initialized
INFO - 2018-07-31 05:02:43 --> Language Class Initialized
INFO - 2018-07-31 05:02:43 --> Config Class Initialized
INFO - 2018-07-31 05:02:43 --> URI Class Initialized
INFO - 2018-07-31 05:02:43 --> Router Class Initialized
INFO - 2018-07-31 05:02:43 --> Loader Class Initialized
INFO - 2018-07-31 05:02:43 --> Output Class Initialized
DEBUG - 2018-07-31 05:02:43 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-31 05:02:43 --> Helper loaded: url_helper
INFO - 2018-07-31 05:02:43 --> Security Class Initialized
DEBUG - 2018-07-31 05:02:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 05:02:44 --> Helper loaded: form_helper
INFO - 2018-07-31 05:02:44 --> Input Class Initialized
INFO - 2018-07-31 05:02:44 --> Helper loaded: date_helper
INFO - 2018-07-31 05:02:44 --> Language Class Initialized
INFO - 2018-07-31 05:02:44 --> Helper loaded: util_helper
INFO - 2018-07-31 05:02:44 --> Language Class Initialized
INFO - 2018-07-31 05:02:44 --> Config Class Initialized
INFO - 2018-07-31 05:02:44 --> Helper loaded: text_helper
INFO - 2018-07-31 05:02:44 --> Helper loaded: string_helper
INFO - 2018-07-31 05:02:44 --> Loader Class Initialized
DEBUG - 2018-07-31 05:02:44 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-31 05:02:44 --> Database Driver Class Initialized
INFO - 2018-07-31 05:02:44 --> Helper loaded: url_helper
DEBUG - 2018-07-31 05:02:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 05:02:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 05:02:44 --> Helper loaded: form_helper
INFO - 2018-07-31 05:02:44 --> Helper loaded: date_helper
INFO - 2018-07-31 05:02:44 --> Email Class Initialized
INFO - 2018-07-31 05:02:44 --> Controller Class Initialized
INFO - 2018-07-31 05:02:44 --> Helper loaded: util_helper
DEBUG - 2018-07-31 05:02:44 --> Programs MX_Controller Initialized
INFO - 2018-07-31 05:02:44 --> Helper loaded: text_helper
INFO - 2018-07-31 05:02:44 --> Language file loaded: language/english/data_lang.php
INFO - 2018-07-31 05:02:44 --> Helper loaded: string_helper
DEBUG - 2018-07-31 05:02:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
INFO - 2018-07-31 05:02:44 --> Database Driver Class Initialized
DEBUG - 2018-07-31 05:02:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-31 05:02:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-07-31 05:02:44 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-31 05:02:44 --> Login MX_Controller Initialized
DEBUG - 2018-07-31 05:02:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-31 05:02:44 --> Final output sent to browser
DEBUG - 2018-07-31 05:02:44 --> Total execution time: 0.6602
INFO - 2018-07-31 05:02:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 05:02:44 --> Email Class Initialized
INFO - 2018-07-31 05:02:44 --> Controller Class Initialized
DEBUG - 2018-07-31 05:02:44 --> Programs MX_Controller Initialized
INFO - 2018-07-31 05:02:44 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-31 05:02:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-07-31 05:02:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-31 05:02:44 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-31 05:02:44 --> Login MX_Controller Initialized
DEBUG - 2018-07-31 05:02:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-31 05:02:44 --> Final output sent to browser
DEBUG - 2018-07-31 05:02:44 --> Total execution time: 0.6997
INFO - 2018-07-31 05:52:49 --> Config Class Initialized
INFO - 2018-07-31 05:52:49 --> Hooks Class Initialized
DEBUG - 2018-07-31 05:52:49 --> UTF-8 Support Enabled
INFO - 2018-07-31 05:52:49 --> Utf8 Class Initialized
INFO - 2018-07-31 05:52:49 --> URI Class Initialized
INFO - 2018-07-31 05:52:49 --> Router Class Initialized
INFO - 2018-07-31 05:52:49 --> Output Class Initialized
INFO - 2018-07-31 05:52:49 --> Security Class Initialized
DEBUG - 2018-07-31 05:52:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 05:52:49 --> Input Class Initialized
INFO - 2018-07-31 05:52:49 --> Language Class Initialized
INFO - 2018-07-31 05:52:49 --> Language Class Initialized
INFO - 2018-07-31 05:52:49 --> Config Class Initialized
INFO - 2018-07-31 05:52:49 --> Loader Class Initialized
DEBUG - 2018-07-31 05:52:49 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-31 05:52:49 --> Helper loaded: url_helper
INFO - 2018-07-31 05:52:49 --> Helper loaded: form_helper
INFO - 2018-07-31 05:52:49 --> Helper loaded: date_helper
INFO - 2018-07-31 05:52:49 --> Helper loaded: util_helper
INFO - 2018-07-31 05:52:49 --> Helper loaded: text_helper
INFO - 2018-07-31 05:52:50 --> Helper loaded: string_helper
INFO - 2018-07-31 05:52:50 --> Database Driver Class Initialized
DEBUG - 2018-07-31 05:52:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 05:52:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 05:52:50 --> Email Class Initialized
INFO - 2018-07-31 05:52:50 --> Controller Class Initialized
DEBUG - 2018-07-31 05:52:50 --> Login MX_Controller Initialized
INFO - 2018-07-31 05:52:50 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-31 05:52:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-31 05:52:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-31 05:52:50 --> 1 Loggedout
INFO - 2018-07-31 05:52:50 --> Config Class Initialized
INFO - 2018-07-31 05:52:50 --> Hooks Class Initialized
DEBUG - 2018-07-31 05:52:50 --> UTF-8 Support Enabled
INFO - 2018-07-31 05:52:50 --> Utf8 Class Initialized
INFO - 2018-07-31 05:52:50 --> URI Class Initialized
INFO - 2018-07-31 05:52:50 --> Router Class Initialized
INFO - 2018-07-31 05:52:50 --> Output Class Initialized
INFO - 2018-07-31 05:52:50 --> Security Class Initialized
DEBUG - 2018-07-31 05:52:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 05:52:50 --> Input Class Initialized
INFO - 2018-07-31 05:52:50 --> Language Class Initialized
INFO - 2018-07-31 05:52:50 --> Language Class Initialized
INFO - 2018-07-31 05:52:50 --> Config Class Initialized
INFO - 2018-07-31 05:52:50 --> Loader Class Initialized
DEBUG - 2018-07-31 05:52:50 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-31 05:52:50 --> Helper loaded: url_helper
INFO - 2018-07-31 05:52:50 --> Helper loaded: form_helper
INFO - 2018-07-31 05:52:50 --> Helper loaded: date_helper
INFO - 2018-07-31 05:52:50 --> Helper loaded: util_helper
INFO - 2018-07-31 05:52:50 --> Helper loaded: text_helper
INFO - 2018-07-31 05:52:50 --> Helper loaded: string_helper
INFO - 2018-07-31 05:52:50 --> Database Driver Class Initialized
DEBUG - 2018-07-31 05:52:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 05:52:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 05:52:50 --> Email Class Initialized
INFO - 2018-07-31 05:52:50 --> Controller Class Initialized
DEBUG - 2018-07-31 05:52:50 --> Admin MX_Controller Initialized
INFO - 2018-07-31 05:52:50 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-31 05:52:50 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-31 05:52:50 --> Login MX_Controller Initialized
DEBUG - 2018-07-31 05:52:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-31 05:52:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-31 05:52:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/logins/login.php
INFO - 2018-07-31 05:52:51 --> Config Class Initialized
INFO - 2018-07-31 05:52:51 --> Hooks Class Initialized
DEBUG - 2018-07-31 05:52:51 --> UTF-8 Support Enabled
INFO - 2018-07-31 05:52:51 --> Utf8 Class Initialized
INFO - 2018-07-31 05:52:51 --> URI Class Initialized
INFO - 2018-07-31 05:52:51 --> Router Class Initialized
INFO - 2018-07-31 05:52:51 --> Output Class Initialized
INFO - 2018-07-31 05:52:51 --> Security Class Initialized
DEBUG - 2018-07-31 05:52:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 05:52:51 --> Input Class Initialized
INFO - 2018-07-31 05:52:51 --> Language Class Initialized
ERROR - 2018-07-31 05:52:51 --> 404 Page Not Found: /index
INFO - 2018-07-31 05:52:57 --> Config Class Initialized
INFO - 2018-07-31 05:52:57 --> Hooks Class Initialized
DEBUG - 2018-07-31 05:52:57 --> UTF-8 Support Enabled
INFO - 2018-07-31 05:52:57 --> Utf8 Class Initialized
INFO - 2018-07-31 05:52:57 --> URI Class Initialized
INFO - 2018-07-31 05:52:57 --> Router Class Initialized
INFO - 2018-07-31 05:52:57 --> Output Class Initialized
INFO - 2018-07-31 05:52:57 --> Security Class Initialized
DEBUG - 2018-07-31 05:52:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 05:52:57 --> Input Class Initialized
INFO - 2018-07-31 05:52:57 --> Language Class Initialized
INFO - 2018-07-31 05:52:57 --> Language Class Initialized
INFO - 2018-07-31 05:52:57 --> Config Class Initialized
INFO - 2018-07-31 05:52:57 --> Loader Class Initialized
DEBUG - 2018-07-31 05:52:57 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-31 05:52:57 --> Helper loaded: url_helper
INFO - 2018-07-31 05:52:57 --> Helper loaded: form_helper
INFO - 2018-07-31 05:52:57 --> Helper loaded: date_helper
INFO - 2018-07-31 05:52:57 --> Helper loaded: util_helper
INFO - 2018-07-31 05:52:57 --> Helper loaded: text_helper
INFO - 2018-07-31 05:52:57 --> Helper loaded: string_helper
INFO - 2018-07-31 05:52:57 --> Database Driver Class Initialized
DEBUG - 2018-07-31 05:52:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 05:52:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 05:52:57 --> Email Class Initialized
INFO - 2018-07-31 05:52:57 --> Controller Class Initialized
DEBUG - 2018-07-31 05:52:57 --> Login MX_Controller Initialized
INFO - 2018-07-31 05:52:57 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-31 05:52:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-31 05:52:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-31 05:52:57 --> 4 Loggedout
INFO - 2018-07-31 05:52:57 --> Config Class Initialized
INFO - 2018-07-31 05:52:57 --> Hooks Class Initialized
DEBUG - 2018-07-31 05:52:57 --> UTF-8 Support Enabled
INFO - 2018-07-31 05:52:57 --> Utf8 Class Initialized
INFO - 2018-07-31 05:52:58 --> URI Class Initialized
INFO - 2018-07-31 05:52:58 --> Router Class Initialized
INFO - 2018-07-31 05:52:58 --> Output Class Initialized
INFO - 2018-07-31 05:52:58 --> Security Class Initialized
DEBUG - 2018-07-31 05:52:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 05:52:58 --> Input Class Initialized
INFO - 2018-07-31 05:52:58 --> Language Class Initialized
INFO - 2018-07-31 05:52:58 --> Language Class Initialized
INFO - 2018-07-31 05:52:58 --> Config Class Initialized
INFO - 2018-07-31 05:52:58 --> Loader Class Initialized
DEBUG - 2018-07-31 05:52:58 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-31 05:52:58 --> Helper loaded: url_helper
INFO - 2018-07-31 05:52:58 --> Helper loaded: form_helper
INFO - 2018-07-31 05:52:58 --> Helper loaded: date_helper
INFO - 2018-07-31 05:52:58 --> Helper loaded: util_helper
INFO - 2018-07-31 05:52:58 --> Helper loaded: text_helper
INFO - 2018-07-31 05:52:58 --> Helper loaded: string_helper
INFO - 2018-07-31 05:52:58 --> Database Driver Class Initialized
DEBUG - 2018-07-31 05:52:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 05:52:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 05:52:58 --> Email Class Initialized
INFO - 2018-07-31 05:52:58 --> Controller Class Initialized
DEBUG - 2018-07-31 05:52:58 --> Home MX_Controller Initialized
DEBUG - 2018-07-31 05:52:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-31 05:52:58 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-31 05:52:58 --> Login MX_Controller Initialized
INFO - 2018-07-31 05:52:58 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-31 05:52:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-31 05:52:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-31 05:52:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/login.php
INFO - 2018-07-31 21:35:19 --> Config Class Initialized
INFO - 2018-07-31 21:35:19 --> Config Class Initialized
INFO - 2018-07-31 21:35:19 --> Hooks Class Initialized
INFO - 2018-07-31 21:35:19 --> Hooks Class Initialized
DEBUG - 2018-07-31 21:35:20 --> UTF-8 Support Enabled
DEBUG - 2018-07-31 21:35:20 --> UTF-8 Support Enabled
INFO - 2018-07-31 21:35:20 --> Utf8 Class Initialized
INFO - 2018-07-31 21:35:20 --> Utf8 Class Initialized
INFO - 2018-07-31 21:35:20 --> URI Class Initialized
INFO - 2018-07-31 21:35:20 --> URI Class Initialized
INFO - 2018-07-31 21:35:20 --> Router Class Initialized
INFO - 2018-07-31 21:35:20 --> Router Class Initialized
INFO - 2018-07-31 21:35:21 --> Output Class Initialized
INFO - 2018-07-31 21:35:21 --> Output Class Initialized
INFO - 2018-07-31 21:35:21 --> Security Class Initialized
INFO - 2018-07-31 21:35:21 --> Security Class Initialized
DEBUG - 2018-07-31 21:35:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-07-31 21:35:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 21:35:21 --> Input Class Initialized
INFO - 2018-07-31 21:35:21 --> Input Class Initialized
INFO - 2018-07-31 21:35:21 --> Language Class Initialized
INFO - 2018-07-31 21:35:21 --> Language Class Initialized
INFO - 2018-07-31 21:35:22 --> Language Class Initialized
INFO - 2018-07-31 21:35:22 --> Language Class Initialized
INFO - 2018-07-31 21:35:22 --> Config Class Initialized
INFO - 2018-07-31 21:35:22 --> Config Class Initialized
INFO - 2018-07-31 21:35:22 --> Loader Class Initialized
INFO - 2018-07-31 21:35:22 --> Loader Class Initialized
DEBUG - 2018-07-31 21:35:22 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
DEBUG - 2018-07-31 21:35:22 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-31 21:35:23 --> Helper loaded: url_helper
INFO - 2018-07-31 21:35:23 --> Helper loaded: url_helper
INFO - 2018-07-31 21:35:23 --> Helper loaded: form_helper
INFO - 2018-07-31 21:35:23 --> Helper loaded: form_helper
INFO - 2018-07-31 21:35:23 --> Helper loaded: date_helper
INFO - 2018-07-31 21:35:23 --> Helper loaded: date_helper
INFO - 2018-07-31 21:35:23 --> Helper loaded: util_helper
INFO - 2018-07-31 21:35:23 --> Helper loaded: util_helper
INFO - 2018-07-31 21:35:24 --> Helper loaded: text_helper
INFO - 2018-07-31 21:35:24 --> Helper loaded: text_helper
INFO - 2018-07-31 21:35:24 --> Helper loaded: string_helper
INFO - 2018-07-31 21:35:24 --> Helper loaded: string_helper
INFO - 2018-07-31 21:35:25 --> Database Driver Class Initialized
INFO - 2018-07-31 21:35:25 --> Database Driver Class Initialized
DEBUG - 2018-07-31 21:35:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-07-31 21:35:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 21:35:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 21:35:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 21:35:27 --> Email Class Initialized
INFO - 2018-07-31 21:35:27 --> Email Class Initialized
INFO - 2018-07-31 21:35:27 --> Controller Class Initialized
INFO - 2018-07-31 21:35:27 --> Controller Class Initialized
DEBUG - 2018-07-31 21:35:27 --> Admin MX_Controller Initialized
DEBUG - 2018-07-31 21:35:27 --> Home MX_Controller Initialized
INFO - 2018-07-31 21:35:27 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-31 21:35:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-31 21:35:27 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-31 21:35:27 --> Login MX_Controller Initialized
DEBUG - 2018-07-31 21:35:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-31 21:35:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-31 21:35:29 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-31 21:35:29 --> Login MX_Controller Initialized
INFO - 2018-07-31 21:35:29 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-31 21:35:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-31 21:35:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-31 21:35:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/logins/login.php
DEBUG - 2018-07-31 21:35:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/login.php
INFO - 2018-07-31 21:35:30 --> Config Class Initialized
INFO - 2018-07-31 21:35:30 --> Hooks Class Initialized
DEBUG - 2018-07-31 21:35:30 --> UTF-8 Support Enabled
INFO - 2018-07-31 21:35:30 --> Utf8 Class Initialized
INFO - 2018-07-31 21:35:30 --> URI Class Initialized
INFO - 2018-07-31 21:35:31 --> Router Class Initialized
INFO - 2018-07-31 21:35:31 --> Output Class Initialized
INFO - 2018-07-31 21:35:31 --> Security Class Initialized
DEBUG - 2018-07-31 21:35:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 21:35:31 --> Input Class Initialized
INFO - 2018-07-31 21:35:31 --> Language Class Initialized
ERROR - 2018-07-31 21:35:31 --> 404 Page Not Found: /index
INFO - 2018-07-31 21:35:33 --> Config Class Initialized
INFO - 2018-07-31 21:35:33 --> Hooks Class Initialized
DEBUG - 2018-07-31 21:35:33 --> UTF-8 Support Enabled
INFO - 2018-07-31 21:35:33 --> Utf8 Class Initialized
INFO - 2018-07-31 21:35:33 --> URI Class Initialized
INFO - 2018-07-31 21:35:33 --> Router Class Initialized
INFO - 2018-07-31 21:35:33 --> Output Class Initialized
INFO - 2018-07-31 21:35:33 --> Security Class Initialized
DEBUG - 2018-07-31 21:35:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 21:35:34 --> Input Class Initialized
INFO - 2018-07-31 21:35:34 --> Language Class Initialized
ERROR - 2018-07-31 21:35:34 --> 404 Page Not Found: /index
INFO - 2018-07-31 21:37:16 --> Config Class Initialized
INFO - 2018-07-31 21:37:16 --> Hooks Class Initialized
DEBUG - 2018-07-31 21:37:16 --> UTF-8 Support Enabled
INFO - 2018-07-31 21:37:16 --> Utf8 Class Initialized
INFO - 2018-07-31 21:37:16 --> URI Class Initialized
INFO - 2018-07-31 21:37:16 --> Router Class Initialized
INFO - 2018-07-31 21:37:16 --> Output Class Initialized
INFO - 2018-07-31 21:37:16 --> Security Class Initialized
DEBUG - 2018-07-31 21:37:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 21:37:16 --> Input Class Initialized
INFO - 2018-07-31 21:37:16 --> Language Class Initialized
INFO - 2018-07-31 21:37:16 --> Language Class Initialized
INFO - 2018-07-31 21:37:16 --> Config Class Initialized
INFO - 2018-07-31 21:37:16 --> Loader Class Initialized
DEBUG - 2018-07-31 21:37:16 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-31 21:37:16 --> Helper loaded: url_helper
INFO - 2018-07-31 21:37:16 --> Helper loaded: form_helper
INFO - 2018-07-31 21:37:16 --> Helper loaded: date_helper
INFO - 2018-07-31 21:37:16 --> Helper loaded: util_helper
INFO - 2018-07-31 21:37:16 --> Helper loaded: text_helper
INFO - 2018-07-31 21:37:16 --> Helper loaded: string_helper
INFO - 2018-07-31 21:37:16 --> Database Driver Class Initialized
DEBUG - 2018-07-31 21:37:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 21:37:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 21:37:16 --> Email Class Initialized
INFO - 2018-07-31 21:37:16 --> Controller Class Initialized
DEBUG - 2018-07-31 21:37:16 --> Login MX_Controller Initialized
INFO - 2018-07-31 21:37:16 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-31 21:37:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-31 21:37:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-31 21:37:16 --> Email starts for colin-admin fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-07-31 21:37:16 --> User session created for 1
INFO - 2018-07-31 21:37:17 --> Login status colin-admin - success
INFO - 2018-07-31 21:37:17 --> Final output sent to browser
DEBUG - 2018-07-31 21:37:17 --> Total execution time: 0.7743
INFO - 2018-07-31 21:37:17 --> Config Class Initialized
INFO - 2018-07-31 21:37:17 --> Hooks Class Initialized
DEBUG - 2018-07-31 21:37:17 --> UTF-8 Support Enabled
INFO - 2018-07-31 21:37:17 --> Utf8 Class Initialized
INFO - 2018-07-31 21:37:17 --> URI Class Initialized
INFO - 2018-07-31 21:37:17 --> Router Class Initialized
INFO - 2018-07-31 21:37:17 --> Output Class Initialized
INFO - 2018-07-31 21:37:17 --> Security Class Initialized
DEBUG - 2018-07-31 21:37:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 21:37:17 --> Input Class Initialized
INFO - 2018-07-31 21:37:17 --> Language Class Initialized
INFO - 2018-07-31 21:37:17 --> Language Class Initialized
INFO - 2018-07-31 21:37:17 --> Config Class Initialized
INFO - 2018-07-31 21:37:17 --> Loader Class Initialized
DEBUG - 2018-07-31 21:37:17 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-31 21:37:17 --> Helper loaded: url_helper
INFO - 2018-07-31 21:37:17 --> Helper loaded: form_helper
INFO - 2018-07-31 21:37:17 --> Helper loaded: date_helper
INFO - 2018-07-31 21:37:17 --> Helper loaded: util_helper
INFO - 2018-07-31 21:37:17 --> Helper loaded: text_helper
INFO - 2018-07-31 21:37:17 --> Helper loaded: string_helper
INFO - 2018-07-31 21:37:17 --> Database Driver Class Initialized
DEBUG - 2018-07-31 21:37:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 21:37:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 21:37:17 --> Email Class Initialized
INFO - 2018-07-31 21:37:17 --> Controller Class Initialized
DEBUG - 2018-07-31 21:37:17 --> Admin MX_Controller Initialized
INFO - 2018-07-31 21:37:17 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-31 21:37:17 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-31 21:37:17 --> Login MX_Controller Initialized
DEBUG - 2018-07-31 21:37:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-31 21:37:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-31 21:37:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-31 21:37:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-31 21:37:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-31 21:37:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-31 21:37:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-31 21:37:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/dashboard.php
INFO - 2018-07-31 21:37:18 --> Final output sent to browser
DEBUG - 2018-07-31 21:37:18 --> Total execution time: 1.3175
INFO - 2018-07-31 21:37:19 --> Config Class Initialized
INFO - 2018-07-31 21:37:19 --> Hooks Class Initialized
DEBUG - 2018-07-31 21:37:19 --> UTF-8 Support Enabled
INFO - 2018-07-31 21:37:19 --> Utf8 Class Initialized
INFO - 2018-07-31 21:37:19 --> URI Class Initialized
INFO - 2018-07-31 21:37:19 --> Router Class Initialized
INFO - 2018-07-31 21:37:19 --> Output Class Initialized
INFO - 2018-07-31 21:37:19 --> Security Class Initialized
DEBUG - 2018-07-31 21:37:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 21:37:19 --> Input Class Initialized
INFO - 2018-07-31 21:37:19 --> Language Class Initialized
ERROR - 2018-07-31 21:37:19 --> 404 Page Not Found: /index
INFO - 2018-07-31 21:37:22 --> Config Class Initialized
INFO - 2018-07-31 21:37:22 --> Hooks Class Initialized
DEBUG - 2018-07-31 21:37:22 --> UTF-8 Support Enabled
INFO - 2018-07-31 21:37:22 --> Utf8 Class Initialized
INFO - 2018-07-31 21:37:22 --> URI Class Initialized
INFO - 2018-07-31 21:37:22 --> Router Class Initialized
INFO - 2018-07-31 21:37:22 --> Output Class Initialized
INFO - 2018-07-31 21:37:22 --> Security Class Initialized
DEBUG - 2018-07-31 21:37:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 21:37:22 --> Input Class Initialized
INFO - 2018-07-31 21:37:22 --> Language Class Initialized
ERROR - 2018-07-31 21:37:22 --> 404 Page Not Found: /index
INFO - 2018-07-31 21:37:22 --> Config Class Initialized
INFO - 2018-07-31 21:37:22 --> Hooks Class Initialized
DEBUG - 2018-07-31 21:37:22 --> UTF-8 Support Enabled
INFO - 2018-07-31 21:37:22 --> Utf8 Class Initialized
INFO - 2018-07-31 21:37:22 --> URI Class Initialized
INFO - 2018-07-31 21:37:22 --> Router Class Initialized
INFO - 2018-07-31 21:37:22 --> Output Class Initialized
INFO - 2018-07-31 21:37:22 --> Security Class Initialized
DEBUG - 2018-07-31 21:37:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 21:37:22 --> Input Class Initialized
INFO - 2018-07-31 21:37:22 --> Language Class Initialized
ERROR - 2018-07-31 21:37:22 --> 404 Page Not Found: /index
INFO - 2018-07-31 21:37:26 --> Config Class Initialized
INFO - 2018-07-31 21:37:26 --> Hooks Class Initialized
DEBUG - 2018-07-31 21:37:26 --> UTF-8 Support Enabled
INFO - 2018-07-31 21:37:26 --> Utf8 Class Initialized
INFO - 2018-07-31 21:37:26 --> URI Class Initialized
INFO - 2018-07-31 21:37:26 --> Router Class Initialized
INFO - 2018-07-31 21:37:26 --> Output Class Initialized
INFO - 2018-07-31 21:37:26 --> Security Class Initialized
DEBUG - 2018-07-31 21:37:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 21:37:26 --> Input Class Initialized
INFO - 2018-07-31 21:37:26 --> Language Class Initialized
INFO - 2018-07-31 21:37:26 --> Language Class Initialized
INFO - 2018-07-31 21:37:26 --> Config Class Initialized
INFO - 2018-07-31 21:37:26 --> Loader Class Initialized
DEBUG - 2018-07-31 21:37:26 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-31 21:37:26 --> Helper loaded: url_helper
INFO - 2018-07-31 21:37:26 --> Helper loaded: form_helper
INFO - 2018-07-31 21:37:26 --> Helper loaded: date_helper
INFO - 2018-07-31 21:37:26 --> Helper loaded: util_helper
INFO - 2018-07-31 21:37:26 --> Helper loaded: text_helper
INFO - 2018-07-31 21:37:26 --> Helper loaded: string_helper
INFO - 2018-07-31 21:37:26 --> Database Driver Class Initialized
DEBUG - 2018-07-31 21:37:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 21:37:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 21:37:27 --> Email Class Initialized
INFO - 2018-07-31 21:37:27 --> Controller Class Initialized
DEBUG - 2018-07-31 21:37:27 --> Login MX_Controller Initialized
INFO - 2018-07-31 21:37:27 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-31 21:37:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-31 21:37:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-31 21:37:27 --> Email starts for colinUser fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-07-31 21:37:27 --> User session created for 4
INFO - 2018-07-31 21:37:27 --> Login status colinUser - success
INFO - 2018-07-31 21:37:27 --> Final output sent to browser
DEBUG - 2018-07-31 21:37:27 --> Total execution time: 0.7218
INFO - 2018-07-31 21:37:27 --> Config Class Initialized
INFO - 2018-07-31 21:37:27 --> Hooks Class Initialized
DEBUG - 2018-07-31 21:37:27 --> UTF-8 Support Enabled
INFO - 2018-07-31 21:37:27 --> Utf8 Class Initialized
INFO - 2018-07-31 21:37:27 --> URI Class Initialized
INFO - 2018-07-31 21:37:27 --> Router Class Initialized
INFO - 2018-07-31 21:37:27 --> Output Class Initialized
INFO - 2018-07-31 21:37:27 --> Security Class Initialized
DEBUG - 2018-07-31 21:37:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 21:37:27 --> Input Class Initialized
INFO - 2018-07-31 21:37:27 --> Language Class Initialized
INFO - 2018-07-31 21:37:27 --> Language Class Initialized
INFO - 2018-07-31 21:37:27 --> Config Class Initialized
INFO - 2018-07-31 21:37:27 --> Loader Class Initialized
DEBUG - 2018-07-31 21:37:27 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-31 21:37:27 --> Helper loaded: url_helper
INFO - 2018-07-31 21:37:27 --> Helper loaded: form_helper
INFO - 2018-07-31 21:37:27 --> Helper loaded: date_helper
INFO - 2018-07-31 21:37:27 --> Helper loaded: util_helper
INFO - 2018-07-31 21:37:27 --> Helper loaded: text_helper
INFO - 2018-07-31 21:37:27 --> Helper loaded: string_helper
INFO - 2018-07-31 21:37:27 --> Database Driver Class Initialized
DEBUG - 2018-07-31 21:37:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 21:37:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 21:37:27 --> Email Class Initialized
INFO - 2018-07-31 21:37:27 --> Controller Class Initialized
DEBUG - 2018-07-31 21:37:27 --> Home MX_Controller Initialized
DEBUG - 2018-07-31 21:37:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-31 21:37:27 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-31 21:37:27 --> Login MX_Controller Initialized
INFO - 2018-07-31 21:37:27 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-31 21:37:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-31 21:37:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-31 21:37:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-07-31 21:37:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-07-31 21:37:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-07-31 21:37:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-07-31 21:37:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-07-31 21:37:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-07-31 21:37:28 --> Final output sent to browser
DEBUG - 2018-07-31 21:37:28 --> Total execution time: 1.3234
INFO - 2018-07-31 21:37:31 --> Config Class Initialized
INFO - 2018-07-31 21:37:31 --> Hooks Class Initialized
DEBUG - 2018-07-31 21:37:31 --> UTF-8 Support Enabled
INFO - 2018-07-31 21:37:31 --> Utf8 Class Initialized
INFO - 2018-07-31 21:37:31 --> URI Class Initialized
INFO - 2018-07-31 21:37:31 --> Router Class Initialized
INFO - 2018-07-31 21:37:31 --> Output Class Initialized
INFO - 2018-07-31 21:37:31 --> Security Class Initialized
DEBUG - 2018-07-31 21:37:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 21:37:31 --> Input Class Initialized
INFO - 2018-07-31 21:37:31 --> Language Class Initialized
ERROR - 2018-07-31 21:37:31 --> 404 Page Not Found: /index
INFO - 2018-07-31 21:37:31 --> Config Class Initialized
INFO - 2018-07-31 21:37:31 --> Hooks Class Initialized
DEBUG - 2018-07-31 21:37:31 --> UTF-8 Support Enabled
INFO - 2018-07-31 21:37:31 --> Utf8 Class Initialized
INFO - 2018-07-31 21:37:31 --> URI Class Initialized
INFO - 2018-07-31 21:37:31 --> Config Class Initialized
INFO - 2018-07-31 21:37:31 --> Hooks Class Initialized
INFO - 2018-07-31 21:37:31 --> Router Class Initialized
INFO - 2018-07-31 21:37:31 --> Output Class Initialized
DEBUG - 2018-07-31 21:37:31 --> UTF-8 Support Enabled
INFO - 2018-07-31 21:37:31 --> Utf8 Class Initialized
INFO - 2018-07-31 21:37:31 --> Security Class Initialized
INFO - 2018-07-31 21:37:31 --> URI Class Initialized
DEBUG - 2018-07-31 21:37:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 21:37:31 --> Input Class Initialized
INFO - 2018-07-31 21:37:31 --> Router Class Initialized
INFO - 2018-07-31 21:37:31 --> Language Class Initialized
INFO - 2018-07-31 21:37:31 --> Output Class Initialized
INFO - 2018-07-31 21:37:31 --> Security Class Initialized
INFO - 2018-07-31 21:37:31 --> Language Class Initialized
INFO - 2018-07-31 21:37:31 --> Config Class Initialized
DEBUG - 2018-07-31 21:37:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 21:37:31 --> Input Class Initialized
INFO - 2018-07-31 21:37:31 --> Loader Class Initialized
INFO - 2018-07-31 21:37:31 --> Language Class Initialized
DEBUG - 2018-07-31 21:37:31 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
ERROR - 2018-07-31 21:37:31 --> 404 Page Not Found: /index
INFO - 2018-07-31 21:37:31 --> Helper loaded: url_helper
INFO - 2018-07-31 21:37:31 --> Helper loaded: form_helper
INFO - 2018-07-31 21:37:31 --> Config Class Initialized
INFO - 2018-07-31 21:37:31 --> Hooks Class Initialized
INFO - 2018-07-31 21:37:31 --> Helper loaded: date_helper
DEBUG - 2018-07-31 21:37:31 --> UTF-8 Support Enabled
INFO - 2018-07-31 21:37:32 --> Utf8 Class Initialized
INFO - 2018-07-31 21:37:32 --> URI Class Initialized
INFO - 2018-07-31 21:37:32 --> Router Class Initialized
INFO - 2018-07-31 21:37:32 --> Output Class Initialized
INFO - 2018-07-31 21:37:32 --> Security Class Initialized
DEBUG - 2018-07-31 21:37:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 21:37:32 --> Input Class Initialized
INFO - 2018-07-31 21:37:32 --> Helper loaded: util_helper
INFO - 2018-07-31 21:37:32 --> Language Class Initialized
INFO - 2018-07-31 21:37:32 --> Config Class Initialized
INFO - 2018-07-31 21:37:32 --> Helper loaded: text_helper
INFO - 2018-07-31 21:37:32 --> Hooks Class Initialized
DEBUG - 2018-07-31 21:37:32 --> UTF-8 Support Enabled
INFO - 2018-07-31 21:37:32 --> Utf8 Class Initialized
INFO - 2018-07-31 21:37:32 --> Language Class Initialized
INFO - 2018-07-31 21:37:32 --> Config Class Initialized
INFO - 2018-07-31 21:37:32 --> URI Class Initialized
INFO - 2018-07-31 21:37:32 --> Helper loaded: string_helper
INFO - 2018-07-31 21:37:32 --> Loader Class Initialized
INFO - 2018-07-31 21:37:32 --> Router Class Initialized
INFO - 2018-07-31 21:37:32 --> Database Driver Class Initialized
DEBUG - 2018-07-31 21:37:32 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-31 21:37:32 --> Output Class Initialized
INFO - 2018-07-31 21:37:32 --> Helper loaded: url_helper
INFO - 2018-07-31 21:37:32 --> Config Class Initialized
INFO - 2018-07-31 21:37:32 --> Hooks Class Initialized
INFO - 2018-07-31 21:37:32 --> Helper loaded: form_helper
INFO - 2018-07-31 21:37:32 --> Security Class Initialized
DEBUG - 2018-07-31 21:37:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 21:37:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 21:37:32 --> Helper loaded: date_helper
DEBUG - 2018-07-31 21:37:32 --> UTF-8 Support Enabled
DEBUG - 2018-07-31 21:37:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 21:37:32 --> Utf8 Class Initialized
INFO - 2018-07-31 21:37:32 --> Email Class Initialized
INFO - 2018-07-31 21:37:32 --> Controller Class Initialized
INFO - 2018-07-31 21:37:32 --> Input Class Initialized
INFO - 2018-07-31 21:37:32 --> Helper loaded: util_helper
INFO - 2018-07-31 21:37:32 --> URI Class Initialized
INFO - 2018-07-31 21:37:32 --> Helper loaded: text_helper
INFO - 2018-07-31 21:37:32 --> Language Class Initialized
DEBUG - 2018-07-31 21:37:32 --> Home MX_Controller Initialized
INFO - 2018-07-31 21:37:32 --> Router Class Initialized
ERROR - 2018-07-31 21:37:32 --> 404 Page Not Found: /index
INFO - 2018-07-31 21:37:32 --> Output Class Initialized
INFO - 2018-07-31 21:37:32 --> Helper loaded: string_helper
DEBUG - 2018-07-31 21:37:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-07-31 21:37:32 --> Security Class Initialized
DEBUG - 2018-07-31 21:37:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 21:37:32 --> Database Driver Class Initialized
DEBUG - 2018-07-31 21:37:32 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
INFO - 2018-07-31 21:37:32 --> Input Class Initialized
DEBUG - 2018-07-31 21:37:32 --> Login MX_Controller Initialized
DEBUG - 2018-07-31 21:37:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 21:37:32 --> Language file loaded: language/english/data_lang.php
INFO - 2018-07-31 21:37:32 --> Language Class Initialized
DEBUG - 2018-07-31 21:37:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
ERROR - 2018-07-31 21:37:32 --> 404 Page Not Found: /index
DEBUG - 2018-07-31 21:37:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-31 21:37:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 21:37:32 --> Email Class Initialized
INFO - 2018-07-31 21:37:32 --> Controller Class Initialized
DEBUG - 2018-07-31 21:37:32 --> Programs MX_Controller Initialized
INFO - 2018-07-31 21:37:32 --> Language file loaded: language/english/data_lang.php
INFO - 2018-07-31 21:37:32 --> Config Class Initialized
INFO - 2018-07-31 21:37:32 --> Hooks Class Initialized
DEBUG - 2018-07-31 21:37:32 --> UTF-8 Support Enabled
INFO - 2018-07-31 21:37:32 --> Utf8 Class Initialized
DEBUG - 2018-07-31 21:37:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
INFO - 2018-07-31 21:37:32 --> URI Class Initialized
DEBUG - 2018-07-31 21:37:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-31 21:37:32 --> Router Class Initialized
INFO - 2018-07-31 21:37:32 --> Output Class Initialized
DEBUG - 2018-07-31 21:37:32 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-31 21:37:32 --> Login MX_Controller Initialized
INFO - 2018-07-31 21:37:32 --> Security Class Initialized
DEBUG - 2018-07-31 21:37:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-31 21:37:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 21:37:32 --> Input Class Initialized
INFO - 2018-07-31 21:37:32 --> Language Class Initialized
ERROR - 2018-07-31 21:37:32 --> 404 Page Not Found: /index
DEBUG - 2018-07-31 21:37:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-31 21:37:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-31 21:37:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-31 21:37:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
INFO - 2018-07-31 21:37:33 --> Config Class Initialized
INFO - 2018-07-31 21:37:33 --> Hooks Class Initialized
DEBUG - 2018-07-31 21:37:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-31 21:37:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/programs/programs.php
DEBUG - 2018-07-31 21:37:33 --> UTF-8 Support Enabled
INFO - 2018-07-31 21:37:33 --> Utf8 Class Initialized
INFO - 2018-07-31 21:37:33 --> Final output sent to browser
INFO - 2018-07-31 21:37:33 --> URI Class Initialized
INFO - 2018-07-31 21:37:33 --> Router Class Initialized
INFO - 2018-07-31 21:37:33 --> Output Class Initialized
INFO - 2018-07-31 21:37:33 --> Security Class Initialized
DEBUG - 2018-07-31 21:37:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 21:37:33 --> Input Class Initialized
INFO - 2018-07-31 21:37:33 --> Language Class Initialized
ERROR - 2018-07-31 21:37:33 --> 404 Page Not Found: /index
DEBUG - 2018-07-31 21:37:33 --> Total execution time: 1.1014
INFO - 2018-07-31 21:37:33 --> Config Class Initialized
INFO - 2018-07-31 21:37:33 --> Config Class Initialized
INFO - 2018-07-31 21:37:33 --> Hooks Class Initialized
INFO - 2018-07-31 21:37:33 --> Hooks Class Initialized
DEBUG - 2018-07-31 21:37:33 --> UTF-8 Support Enabled
DEBUG - 2018-07-31 21:37:33 --> UTF-8 Support Enabled
INFO - 2018-07-31 21:37:33 --> Utf8 Class Initialized
INFO - 2018-07-31 21:37:33 --> Utf8 Class Initialized
INFO - 2018-07-31 21:37:33 --> URI Class Initialized
INFO - 2018-07-31 21:37:33 --> URI Class Initialized
INFO - 2018-07-31 21:37:33 --> Router Class Initialized
INFO - 2018-07-31 21:37:33 --> Router Class Initialized
INFO - 2018-07-31 21:37:33 --> Output Class Initialized
INFO - 2018-07-31 21:37:33 --> Security Class Initialized
INFO - 2018-07-31 21:37:33 --> Output Class Initialized
DEBUG - 2018-07-31 21:37:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 21:37:33 --> Security Class Initialized
INFO - 2018-07-31 21:37:33 --> Input Class Initialized
INFO - 2018-07-31 21:37:33 --> Language Class Initialized
DEBUG - 2018-07-31 21:37:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 21:37:33 --> Language Class Initialized
INFO - 2018-07-31 21:37:33 --> Input Class Initialized
INFO - 2018-07-31 21:37:33 --> Config Class Initialized
INFO - 2018-07-31 21:37:33 --> Loader Class Initialized
DEBUG - 2018-07-31 21:37:33 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-31 21:37:33 --> Helper loaded: url_helper
INFO - 2018-07-31 21:37:33 --> Helper loaded: form_helper
INFO - 2018-07-31 21:37:33 --> Helper loaded: date_helper
INFO - 2018-07-31 21:37:33 --> Helper loaded: util_helper
INFO - 2018-07-31 21:37:33 --> Helper loaded: text_helper
INFO - 2018-07-31 21:37:33 --> Helper loaded: string_helper
INFO - 2018-07-31 21:37:33 --> Language Class Initialized
ERROR - 2018-07-31 21:37:34 --> 404 Page Not Found: /index
INFO - 2018-07-31 21:37:34 --> Database Driver Class Initialized
DEBUG - 2018-07-31 21:37:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 21:37:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 21:37:34 --> Email Class Initialized
INFO - 2018-07-31 21:37:34 --> Controller Class Initialized
DEBUG - 2018-07-31 21:37:34 --> Programs MX_Controller Initialized
INFO - 2018-07-31 21:37:34 --> Config Class Initialized
INFO - 2018-07-31 21:37:34 --> Hooks Class Initialized
INFO - 2018-07-31 21:37:34 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-31 21:37:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-07-31 21:37:34 --> UTF-8 Support Enabled
INFO - 2018-07-31 21:37:34 --> Utf8 Class Initialized
DEBUG - 2018-07-31 21:37:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-31 21:37:34 --> URI Class Initialized
DEBUG - 2018-07-31 21:37:34 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-31 21:37:34 --> Login MX_Controller Initialized
INFO - 2018-07-31 21:37:34 --> Router Class Initialized
DEBUG - 2018-07-31 21:37:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-31 21:37:34 --> Output Class Initialized
INFO - 2018-07-31 21:37:34 --> Security Class Initialized
INFO - 2018-07-31 21:37:34 --> Final output sent to browser
DEBUG - 2018-07-31 21:37:34 --> Total execution time: 0.7851
DEBUG - 2018-07-31 21:37:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 21:37:34 --> Input Class Initialized
INFO - 2018-07-31 21:37:34 --> Language Class Initialized
ERROR - 2018-07-31 21:37:34 --> 404 Page Not Found: /index
INFO - 2018-07-31 21:37:34 --> Config Class Initialized
INFO - 2018-07-31 21:37:34 --> Hooks Class Initialized
DEBUG - 2018-07-31 21:37:34 --> UTF-8 Support Enabled
INFO - 2018-07-31 21:37:34 --> Utf8 Class Initialized
INFO - 2018-07-31 21:37:34 --> URI Class Initialized
INFO - 2018-07-31 21:37:34 --> Router Class Initialized
INFO - 2018-07-31 21:37:34 --> Output Class Initialized
INFO - 2018-07-31 21:37:34 --> Security Class Initialized
DEBUG - 2018-07-31 21:37:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 21:37:34 --> Input Class Initialized
INFO - 2018-07-31 21:37:34 --> Language Class Initialized
ERROR - 2018-07-31 21:37:34 --> 404 Page Not Found: /index
INFO - 2018-07-31 21:37:34 --> Config Class Initialized
INFO - 2018-07-31 21:37:34 --> Hooks Class Initialized
DEBUG - 2018-07-31 21:37:34 --> UTF-8 Support Enabled
INFO - 2018-07-31 21:37:34 --> Utf8 Class Initialized
INFO - 2018-07-31 21:37:34 --> URI Class Initialized
INFO - 2018-07-31 21:37:34 --> Router Class Initialized
INFO - 2018-07-31 21:37:34 --> Output Class Initialized
INFO - 2018-07-31 21:37:34 --> Security Class Initialized
DEBUG - 2018-07-31 21:37:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 21:37:34 --> Input Class Initialized
INFO - 2018-07-31 21:37:34 --> Language Class Initialized
ERROR - 2018-07-31 21:37:34 --> 404 Page Not Found: /index
INFO - 2018-07-31 21:37:37 --> Config Class Initialized
INFO - 2018-07-31 21:37:37 --> Hooks Class Initialized
DEBUG - 2018-07-31 21:37:37 --> UTF-8 Support Enabled
INFO - 2018-07-31 21:37:37 --> Utf8 Class Initialized
INFO - 2018-07-31 21:37:37 --> URI Class Initialized
INFO - 2018-07-31 21:37:37 --> Router Class Initialized
INFO - 2018-07-31 21:37:37 --> Output Class Initialized
INFO - 2018-07-31 21:37:37 --> Security Class Initialized
DEBUG - 2018-07-31 21:37:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 21:37:37 --> Input Class Initialized
INFO - 2018-07-31 21:37:37 --> Language Class Initialized
INFO - 2018-07-31 21:37:37 --> Language Class Initialized
INFO - 2018-07-31 21:37:37 --> Config Class Initialized
INFO - 2018-07-31 21:37:37 --> Loader Class Initialized
DEBUG - 2018-07-31 21:37:37 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-31 21:37:37 --> Helper loaded: url_helper
INFO - 2018-07-31 21:37:37 --> Helper loaded: form_helper
INFO - 2018-07-31 21:37:37 --> Helper loaded: date_helper
INFO - 2018-07-31 21:37:37 --> Helper loaded: util_helper
INFO - 2018-07-31 21:37:38 --> Helper loaded: text_helper
INFO - 2018-07-31 21:37:38 --> Helper loaded: string_helper
INFO - 2018-07-31 21:37:38 --> Database Driver Class Initialized
DEBUG - 2018-07-31 21:37:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 21:37:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 21:37:38 --> Email Class Initialized
INFO - 2018-07-31 21:37:38 --> Controller Class Initialized
DEBUG - 2018-07-31 21:37:38 --> Programs MX_Controller Initialized
INFO - 2018-07-31 21:37:38 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-31 21:37:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-07-31 21:37:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-31 21:37:38 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-31 21:37:38 --> Login MX_Controller Initialized
DEBUG - 2018-07-31 21:37:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-31 21:37:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-31 21:37:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-31 21:37:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-31 21:37:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-31 21:37:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-31 21:37:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/programs/create_program.php
INFO - 2018-07-31 21:37:38 --> Final output sent to browser
DEBUG - 2018-07-31 21:37:38 --> Total execution time: 1.1272
INFO - 2018-07-31 21:37:53 --> Config Class Initialized
INFO - 2018-07-31 21:37:53 --> Hooks Class Initialized
DEBUG - 2018-07-31 21:37:53 --> UTF-8 Support Enabled
INFO - 2018-07-31 21:37:53 --> Utf8 Class Initialized
INFO - 2018-07-31 21:37:53 --> URI Class Initialized
INFO - 2018-07-31 21:37:53 --> Router Class Initialized
INFO - 2018-07-31 21:37:53 --> Output Class Initialized
INFO - 2018-07-31 21:37:53 --> Security Class Initialized
DEBUG - 2018-07-31 21:37:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 21:37:53 --> Input Class Initialized
INFO - 2018-07-31 21:37:53 --> Language Class Initialized
INFO - 2018-07-31 21:37:53 --> Language Class Initialized
INFO - 2018-07-31 21:37:53 --> Config Class Initialized
INFO - 2018-07-31 21:37:53 --> Loader Class Initialized
DEBUG - 2018-07-31 21:37:53 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-31 21:37:53 --> Helper loaded: url_helper
INFO - 2018-07-31 21:37:53 --> Helper loaded: form_helper
INFO - 2018-07-31 21:37:53 --> Helper loaded: date_helper
INFO - 2018-07-31 21:37:53 --> Helper loaded: util_helper
INFO - 2018-07-31 21:37:53 --> Helper loaded: text_helper
INFO - 2018-07-31 21:37:53 --> Helper loaded: string_helper
INFO - 2018-07-31 21:37:53 --> Database Driver Class Initialized
DEBUG - 2018-07-31 21:37:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 21:37:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 21:37:53 --> Email Class Initialized
INFO - 2018-07-31 21:37:53 --> Controller Class Initialized
DEBUG - 2018-07-31 21:37:53 --> Programs MX_Controller Initialized
INFO - 2018-07-31 21:37:53 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-31 21:37:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-07-31 21:37:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-31 21:37:53 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-31 21:37:53 --> Login MX_Controller Initialized
DEBUG - 2018-07-31 21:37:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-31 21:37:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-31 21:37:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-31 21:37:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-31 21:37:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-31 21:37:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-31 21:37:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/programs/programs.php
INFO - 2018-07-31 21:37:53 --> Final output sent to browser
DEBUG - 2018-07-31 21:37:53 --> Total execution time: 0.7644
INFO - 2018-07-31 21:37:54 --> Config Class Initialized
INFO - 2018-07-31 21:37:54 --> Hooks Class Initialized
DEBUG - 2018-07-31 21:37:54 --> UTF-8 Support Enabled
INFO - 2018-07-31 21:37:54 --> Utf8 Class Initialized
INFO - 2018-07-31 21:37:54 --> URI Class Initialized
INFO - 2018-07-31 21:37:54 --> Router Class Initialized
INFO - 2018-07-31 21:37:54 --> Output Class Initialized
INFO - 2018-07-31 21:37:54 --> Security Class Initialized
DEBUG - 2018-07-31 21:37:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 21:37:54 --> Input Class Initialized
INFO - 2018-07-31 21:37:54 --> Language Class Initialized
INFO - 2018-07-31 21:37:54 --> Language Class Initialized
INFO - 2018-07-31 21:37:54 --> Config Class Initialized
INFO - 2018-07-31 21:37:54 --> Loader Class Initialized
DEBUG - 2018-07-31 21:37:54 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-31 21:37:54 --> Helper loaded: url_helper
INFO - 2018-07-31 21:37:54 --> Helper loaded: form_helper
INFO - 2018-07-31 21:37:54 --> Helper loaded: date_helper
INFO - 2018-07-31 21:37:54 --> Helper loaded: util_helper
INFO - 2018-07-31 21:37:54 --> Helper loaded: text_helper
INFO - 2018-07-31 21:37:54 --> Helper loaded: string_helper
INFO - 2018-07-31 21:37:54 --> Database Driver Class Initialized
DEBUG - 2018-07-31 21:37:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 21:37:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 21:37:54 --> Email Class Initialized
INFO - 2018-07-31 21:37:54 --> Controller Class Initialized
DEBUG - 2018-07-31 21:37:54 --> Programs MX_Controller Initialized
INFO - 2018-07-31 21:37:54 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-31 21:37:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-07-31 21:37:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-31 21:37:54 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-31 21:37:54 --> Login MX_Controller Initialized
DEBUG - 2018-07-31 21:37:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-31 21:37:54 --> Final output sent to browser
DEBUG - 2018-07-31 21:37:54 --> Total execution time: 0.7755
INFO - 2018-07-31 21:37:56 --> Config Class Initialized
INFO - 2018-07-31 21:37:56 --> Hooks Class Initialized
DEBUG - 2018-07-31 21:37:56 --> UTF-8 Support Enabled
INFO - 2018-07-31 21:37:56 --> Utf8 Class Initialized
INFO - 2018-07-31 21:37:56 --> URI Class Initialized
INFO - 2018-07-31 21:37:56 --> Router Class Initialized
INFO - 2018-07-31 21:37:56 --> Output Class Initialized
INFO - 2018-07-31 21:37:56 --> Security Class Initialized
DEBUG - 2018-07-31 21:37:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 21:37:56 --> Input Class Initialized
INFO - 2018-07-31 21:37:56 --> Language Class Initialized
INFO - 2018-07-31 21:37:56 --> Language Class Initialized
INFO - 2018-07-31 21:37:56 --> Config Class Initialized
INFO - 2018-07-31 21:37:56 --> Loader Class Initialized
DEBUG - 2018-07-31 21:37:56 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-31 21:37:56 --> Helper loaded: url_helper
INFO - 2018-07-31 21:37:56 --> Helper loaded: form_helper
INFO - 2018-07-31 21:37:56 --> Helper loaded: date_helper
INFO - 2018-07-31 21:37:56 --> Helper loaded: util_helper
INFO - 2018-07-31 21:37:56 --> Helper loaded: text_helper
INFO - 2018-07-31 21:37:56 --> Helper loaded: string_helper
INFO - 2018-07-31 21:37:56 --> Database Driver Class Initialized
DEBUG - 2018-07-31 21:37:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 21:37:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 21:37:56 --> Email Class Initialized
INFO - 2018-07-31 21:37:56 --> Controller Class Initialized
DEBUG - 2018-07-31 21:37:56 --> Programs MX_Controller Initialized
INFO - 2018-07-31 21:37:56 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-31 21:37:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-07-31 21:37:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-31 21:37:56 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-31 21:37:56 --> Login MX_Controller Initialized
DEBUG - 2018-07-31 21:37:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-31 21:37:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-31 21:37:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-31 21:37:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-31 21:37:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-31 21:37:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-31 21:37:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/programs/create_program.php
INFO - 2018-07-31 21:37:56 --> Final output sent to browser
DEBUG - 2018-07-31 21:37:57 --> Total execution time: 0.7045
INFO - 2018-07-31 21:38:13 --> Config Class Initialized
INFO - 2018-07-31 21:38:13 --> Hooks Class Initialized
DEBUG - 2018-07-31 21:38:13 --> UTF-8 Support Enabled
INFO - 2018-07-31 21:38:13 --> Utf8 Class Initialized
INFO - 2018-07-31 21:38:13 --> URI Class Initialized
INFO - 2018-07-31 21:38:13 --> Router Class Initialized
INFO - 2018-07-31 21:38:13 --> Output Class Initialized
INFO - 2018-07-31 21:38:13 --> Security Class Initialized
DEBUG - 2018-07-31 21:38:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 21:38:13 --> Input Class Initialized
INFO - 2018-07-31 21:38:13 --> Language Class Initialized
INFO - 2018-07-31 21:38:13 --> Language Class Initialized
INFO - 2018-07-31 21:38:13 --> Config Class Initialized
INFO - 2018-07-31 21:38:13 --> Loader Class Initialized
DEBUG - 2018-07-31 21:38:13 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-31 21:38:13 --> Helper loaded: url_helper
INFO - 2018-07-31 21:38:13 --> Helper loaded: form_helper
INFO - 2018-07-31 21:38:13 --> Helper loaded: date_helper
INFO - 2018-07-31 21:38:13 --> Helper loaded: util_helper
INFO - 2018-07-31 21:38:13 --> Helper loaded: text_helper
INFO - 2018-07-31 21:38:13 --> Helper loaded: string_helper
INFO - 2018-07-31 21:38:13 --> Database Driver Class Initialized
DEBUG - 2018-07-31 21:38:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 21:38:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 21:38:14 --> Email Class Initialized
INFO - 2018-07-31 21:38:14 --> Controller Class Initialized
DEBUG - 2018-07-31 21:38:14 --> Programs MX_Controller Initialized
INFO - 2018-07-31 21:38:14 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-31 21:38:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-07-31 21:38:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-31 21:38:14 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-31 21:38:14 --> Login MX_Controller Initialized
DEBUG - 2018-07-31 21:38:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-31 21:38:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
INFO - 2018-07-31 21:38:14 --> Upload Class Initialized
INFO - 2018-07-31 21:38:14 --> Config Class Initialized
INFO - 2018-07-31 21:38:14 --> Hooks Class Initialized
DEBUG - 2018-07-31 21:38:14 --> UTF-8 Support Enabled
INFO - 2018-07-31 21:38:14 --> Utf8 Class Initialized
INFO - 2018-07-31 21:38:14 --> URI Class Initialized
INFO - 2018-07-31 21:38:14 --> Router Class Initialized
INFO - 2018-07-31 21:38:14 --> Output Class Initialized
INFO - 2018-07-31 21:38:14 --> Security Class Initialized
DEBUG - 2018-07-31 21:38:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 21:38:14 --> Input Class Initialized
INFO - 2018-07-31 21:38:14 --> Language Class Initialized
INFO - 2018-07-31 21:38:14 --> Language Class Initialized
INFO - 2018-07-31 21:38:14 --> Config Class Initialized
INFO - 2018-07-31 21:38:14 --> Loader Class Initialized
DEBUG - 2018-07-31 21:38:14 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-31 21:38:14 --> Helper loaded: url_helper
INFO - 2018-07-31 21:38:14 --> Helper loaded: form_helper
INFO - 2018-07-31 21:38:14 --> Helper loaded: date_helper
INFO - 2018-07-31 21:38:14 --> Helper loaded: util_helper
INFO - 2018-07-31 21:38:14 --> Helper loaded: text_helper
INFO - 2018-07-31 21:38:14 --> Helper loaded: string_helper
INFO - 2018-07-31 21:38:15 --> Database Driver Class Initialized
DEBUG - 2018-07-31 21:38:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 21:38:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 21:38:15 --> Email Class Initialized
INFO - 2018-07-31 21:38:15 --> Controller Class Initialized
DEBUG - 2018-07-31 21:38:15 --> Programs MX_Controller Initialized
INFO - 2018-07-31 21:38:15 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-31 21:38:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-07-31 21:38:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-31 21:38:15 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-31 21:38:15 --> Login MX_Controller Initialized
DEBUG - 2018-07-31 21:38:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-31 21:38:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-31 21:38:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-31 21:38:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-31 21:38:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-31 21:38:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-31 21:38:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/programs/programs.php
INFO - 2018-07-31 21:38:15 --> Final output sent to browser
DEBUG - 2018-07-31 21:38:15 --> Total execution time: 0.7541
INFO - 2018-07-31 21:38:15 --> Config Class Initialized
INFO - 2018-07-31 21:38:15 --> Hooks Class Initialized
DEBUG - 2018-07-31 21:38:15 --> UTF-8 Support Enabled
INFO - 2018-07-31 21:38:15 --> Utf8 Class Initialized
INFO - 2018-07-31 21:38:15 --> URI Class Initialized
INFO - 2018-07-31 21:38:15 --> Router Class Initialized
INFO - 2018-07-31 21:38:15 --> Output Class Initialized
INFO - 2018-07-31 21:38:15 --> Security Class Initialized
DEBUG - 2018-07-31 21:38:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 21:38:15 --> Input Class Initialized
INFO - 2018-07-31 21:38:15 --> Language Class Initialized
INFO - 2018-07-31 21:38:16 --> Language Class Initialized
INFO - 2018-07-31 21:38:16 --> Config Class Initialized
INFO - 2018-07-31 21:38:16 --> Loader Class Initialized
DEBUG - 2018-07-31 21:38:16 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-31 21:38:16 --> Helper loaded: url_helper
INFO - 2018-07-31 21:38:16 --> Helper loaded: form_helper
INFO - 2018-07-31 21:38:16 --> Helper loaded: date_helper
INFO - 2018-07-31 21:38:16 --> Helper loaded: util_helper
INFO - 2018-07-31 21:38:16 --> Helper loaded: text_helper
INFO - 2018-07-31 21:38:16 --> Helper loaded: string_helper
INFO - 2018-07-31 21:38:16 --> Database Driver Class Initialized
DEBUG - 2018-07-31 21:38:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 21:38:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 21:38:16 --> Email Class Initialized
INFO - 2018-07-31 21:38:16 --> Controller Class Initialized
DEBUG - 2018-07-31 21:38:16 --> Programs MX_Controller Initialized
INFO - 2018-07-31 21:38:16 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-31 21:38:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-07-31 21:38:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-31 21:38:16 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-31 21:38:16 --> Login MX_Controller Initialized
DEBUG - 2018-07-31 21:38:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-31 21:38:16 --> Final output sent to browser
DEBUG - 2018-07-31 21:38:16 --> Total execution time: 0.7406
INFO - 2018-07-31 21:38:18 --> Config Class Initialized
INFO - 2018-07-31 21:38:18 --> Hooks Class Initialized
DEBUG - 2018-07-31 21:38:18 --> UTF-8 Support Enabled
INFO - 2018-07-31 21:38:18 --> Utf8 Class Initialized
INFO - 2018-07-31 21:38:18 --> URI Class Initialized
INFO - 2018-07-31 21:38:18 --> Router Class Initialized
INFO - 2018-07-31 21:38:18 --> Output Class Initialized
INFO - 2018-07-31 21:38:18 --> Security Class Initialized
DEBUG - 2018-07-31 21:38:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 21:38:18 --> Input Class Initialized
INFO - 2018-07-31 21:38:18 --> Language Class Initialized
INFO - 2018-07-31 21:38:18 --> Language Class Initialized
INFO - 2018-07-31 21:38:18 --> Config Class Initialized
INFO - 2018-07-31 21:38:18 --> Loader Class Initialized
DEBUG - 2018-07-31 21:38:18 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-31 21:38:18 --> Helper loaded: url_helper
INFO - 2018-07-31 21:38:18 --> Helper loaded: form_helper
INFO - 2018-07-31 21:38:18 --> Helper loaded: date_helper
INFO - 2018-07-31 21:38:18 --> Helper loaded: util_helper
INFO - 2018-07-31 21:38:18 --> Helper loaded: text_helper
INFO - 2018-07-31 21:38:18 --> Helper loaded: string_helper
INFO - 2018-07-31 21:38:18 --> Database Driver Class Initialized
DEBUG - 2018-07-31 21:38:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 21:38:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 21:38:18 --> Email Class Initialized
INFO - 2018-07-31 21:38:18 --> Controller Class Initialized
DEBUG - 2018-07-31 21:38:18 --> Programs MX_Controller Initialized
INFO - 2018-07-31 21:38:18 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-31 21:38:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-07-31 21:38:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-31 21:38:18 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-31 21:38:18 --> Login MX_Controller Initialized
DEBUG - 2018-07-31 21:38:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-31 21:38:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-31 21:38:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-31 21:38:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-31 21:38:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-31 21:38:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-31 21:38:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/programs/create_program.php
INFO - 2018-07-31 21:38:18 --> Final output sent to browser
DEBUG - 2018-07-31 21:38:18 --> Total execution time: 0.7134
INFO - 2018-07-31 21:38:35 --> Config Class Initialized
INFO - 2018-07-31 21:38:35 --> Hooks Class Initialized
DEBUG - 2018-07-31 21:38:35 --> UTF-8 Support Enabled
INFO - 2018-07-31 21:38:35 --> Utf8 Class Initialized
INFO - 2018-07-31 21:38:35 --> URI Class Initialized
INFO - 2018-07-31 21:38:35 --> Router Class Initialized
INFO - 2018-07-31 21:38:35 --> Output Class Initialized
INFO - 2018-07-31 21:38:35 --> Security Class Initialized
DEBUG - 2018-07-31 21:38:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 21:38:35 --> Input Class Initialized
INFO - 2018-07-31 21:38:35 --> Language Class Initialized
INFO - 2018-07-31 21:38:35 --> Language Class Initialized
INFO - 2018-07-31 21:38:35 --> Config Class Initialized
INFO - 2018-07-31 21:38:35 --> Loader Class Initialized
DEBUG - 2018-07-31 21:38:35 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-31 21:38:35 --> Helper loaded: url_helper
INFO - 2018-07-31 21:38:35 --> Helper loaded: form_helper
INFO - 2018-07-31 21:38:35 --> Helper loaded: date_helper
INFO - 2018-07-31 21:38:35 --> Helper loaded: util_helper
INFO - 2018-07-31 21:38:35 --> Helper loaded: text_helper
INFO - 2018-07-31 21:38:35 --> Helper loaded: string_helper
INFO - 2018-07-31 21:38:35 --> Database Driver Class Initialized
DEBUG - 2018-07-31 21:38:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 21:38:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 21:38:35 --> Email Class Initialized
INFO - 2018-07-31 21:38:35 --> Controller Class Initialized
DEBUG - 2018-07-31 21:38:35 --> Programs MX_Controller Initialized
INFO - 2018-07-31 21:38:35 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-31 21:38:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-07-31 21:38:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-31 21:38:35 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-31 21:38:35 --> Login MX_Controller Initialized
DEBUG - 2018-07-31 21:38:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-31 21:38:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
INFO - 2018-07-31 21:38:35 --> Upload Class Initialized
INFO - 2018-07-31 21:38:36 --> Config Class Initialized
INFO - 2018-07-31 21:38:36 --> Hooks Class Initialized
DEBUG - 2018-07-31 21:38:36 --> UTF-8 Support Enabled
INFO - 2018-07-31 21:38:36 --> Utf8 Class Initialized
INFO - 2018-07-31 21:38:36 --> URI Class Initialized
INFO - 2018-07-31 21:38:36 --> Router Class Initialized
INFO - 2018-07-31 21:38:36 --> Output Class Initialized
INFO - 2018-07-31 21:38:36 --> Security Class Initialized
DEBUG - 2018-07-31 21:38:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 21:38:36 --> Input Class Initialized
INFO - 2018-07-31 21:38:36 --> Language Class Initialized
INFO - 2018-07-31 21:38:36 --> Language Class Initialized
INFO - 2018-07-31 21:38:36 --> Config Class Initialized
INFO - 2018-07-31 21:38:36 --> Loader Class Initialized
DEBUG - 2018-07-31 21:38:36 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-31 21:38:36 --> Helper loaded: url_helper
INFO - 2018-07-31 21:38:36 --> Helper loaded: form_helper
INFO - 2018-07-31 21:38:36 --> Helper loaded: date_helper
INFO - 2018-07-31 21:38:36 --> Helper loaded: util_helper
INFO - 2018-07-31 21:38:36 --> Helper loaded: text_helper
INFO - 2018-07-31 21:38:36 --> Helper loaded: string_helper
INFO - 2018-07-31 21:38:36 --> Database Driver Class Initialized
DEBUG - 2018-07-31 21:38:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 21:38:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 21:38:36 --> Email Class Initialized
INFO - 2018-07-31 21:38:36 --> Controller Class Initialized
DEBUG - 2018-07-31 21:38:36 --> Programs MX_Controller Initialized
INFO - 2018-07-31 21:38:36 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-31 21:38:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-07-31 21:38:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-31 21:38:36 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-31 21:38:36 --> Login MX_Controller Initialized
DEBUG - 2018-07-31 21:38:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-31 21:38:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-31 21:38:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-31 21:38:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-31 21:38:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-31 21:38:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-31 21:38:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/programs/programs.php
INFO - 2018-07-31 21:38:36 --> Final output sent to browser
DEBUG - 2018-07-31 21:38:36 --> Total execution time: 0.7551
INFO - 2018-07-31 21:38:37 --> Config Class Initialized
INFO - 2018-07-31 21:38:37 --> Hooks Class Initialized
DEBUG - 2018-07-31 21:38:37 --> UTF-8 Support Enabled
INFO - 2018-07-31 21:38:37 --> Utf8 Class Initialized
INFO - 2018-07-31 21:38:37 --> URI Class Initialized
INFO - 2018-07-31 21:38:37 --> Router Class Initialized
INFO - 2018-07-31 21:38:37 --> Output Class Initialized
INFO - 2018-07-31 21:38:37 --> Security Class Initialized
DEBUG - 2018-07-31 21:38:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 21:38:37 --> Input Class Initialized
INFO - 2018-07-31 21:38:37 --> Language Class Initialized
INFO - 2018-07-31 21:38:37 --> Language Class Initialized
INFO - 2018-07-31 21:38:37 --> Config Class Initialized
INFO - 2018-07-31 21:38:37 --> Loader Class Initialized
DEBUG - 2018-07-31 21:38:37 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-31 21:38:37 --> Helper loaded: url_helper
INFO - 2018-07-31 21:38:37 --> Helper loaded: form_helper
INFO - 2018-07-31 21:38:37 --> Helper loaded: date_helper
INFO - 2018-07-31 21:38:37 --> Helper loaded: util_helper
INFO - 2018-07-31 21:38:37 --> Helper loaded: text_helper
INFO - 2018-07-31 21:38:37 --> Helper loaded: string_helper
INFO - 2018-07-31 21:38:37 --> Database Driver Class Initialized
DEBUG - 2018-07-31 21:38:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 21:38:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 21:38:37 --> Email Class Initialized
INFO - 2018-07-31 21:38:37 --> Controller Class Initialized
DEBUG - 2018-07-31 21:38:37 --> Programs MX_Controller Initialized
INFO - 2018-07-31 21:38:37 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-31 21:38:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-07-31 21:38:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-31 21:38:37 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-31 21:38:37 --> Login MX_Controller Initialized
DEBUG - 2018-07-31 21:38:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-31 21:38:37 --> Final output sent to browser
DEBUG - 2018-07-31 21:38:37 --> Total execution time: 0.7009
INFO - 2018-07-31 21:38:55 --> Config Class Initialized
INFO - 2018-07-31 21:38:55 --> Hooks Class Initialized
DEBUG - 2018-07-31 21:38:55 --> UTF-8 Support Enabled
INFO - 2018-07-31 21:38:55 --> Utf8 Class Initialized
INFO - 2018-07-31 21:38:55 --> URI Class Initialized
INFO - 2018-07-31 21:38:55 --> Router Class Initialized
INFO - 2018-07-31 21:38:55 --> Output Class Initialized
INFO - 2018-07-31 21:38:55 --> Security Class Initialized
DEBUG - 2018-07-31 21:38:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 21:38:55 --> Input Class Initialized
INFO - 2018-07-31 21:38:55 --> Language Class Initialized
INFO - 2018-07-31 21:38:55 --> Language Class Initialized
INFO - 2018-07-31 21:38:55 --> Config Class Initialized
INFO - 2018-07-31 21:38:55 --> Loader Class Initialized
DEBUG - 2018-07-31 21:38:55 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-31 21:38:55 --> Helper loaded: url_helper
INFO - 2018-07-31 21:38:55 --> Helper loaded: form_helper
INFO - 2018-07-31 21:38:55 --> Helper loaded: date_helper
INFO - 2018-07-31 21:38:55 --> Helper loaded: util_helper
INFO - 2018-07-31 21:38:55 --> Helper loaded: text_helper
INFO - 2018-07-31 21:38:55 --> Helper loaded: string_helper
INFO - 2018-07-31 21:38:55 --> Database Driver Class Initialized
DEBUG - 2018-07-31 21:38:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 21:38:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 21:38:55 --> Email Class Initialized
INFO - 2018-07-31 21:38:55 --> Controller Class Initialized
DEBUG - 2018-07-31 21:38:55 --> Programs MX_Controller Initialized
INFO - 2018-07-31 21:38:55 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-31 21:38:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-07-31 21:38:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-31 21:38:56 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-31 21:38:56 --> Login MX_Controller Initialized
DEBUG - 2018-07-31 21:38:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-31 21:38:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-31 21:38:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-31 21:38:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-31 21:38:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-31 21:38:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-31 21:38:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/programs/create_program.php
INFO - 2018-07-31 21:38:56 --> Final output sent to browser
DEBUG - 2018-07-31 21:38:56 --> Total execution time: 0.7416
INFO - 2018-07-31 21:39:00 --> Config Class Initialized
INFO - 2018-07-31 21:39:01 --> Hooks Class Initialized
DEBUG - 2018-07-31 21:39:01 --> UTF-8 Support Enabled
INFO - 2018-07-31 21:39:01 --> Utf8 Class Initialized
INFO - 2018-07-31 21:39:01 --> URI Class Initialized
INFO - 2018-07-31 21:39:01 --> Router Class Initialized
INFO - 2018-07-31 21:39:01 --> Output Class Initialized
INFO - 2018-07-31 21:39:01 --> Security Class Initialized
DEBUG - 2018-07-31 21:39:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 21:39:01 --> Input Class Initialized
INFO - 2018-07-31 21:39:01 --> Language Class Initialized
ERROR - 2018-07-31 21:39:01 --> 404 Page Not Found: /index
INFO - 2018-07-31 21:39:32 --> Config Class Initialized
INFO - 2018-07-31 21:39:32 --> Hooks Class Initialized
DEBUG - 2018-07-31 21:39:32 --> UTF-8 Support Enabled
INFO - 2018-07-31 21:39:32 --> Utf8 Class Initialized
INFO - 2018-07-31 21:39:32 --> URI Class Initialized
INFO - 2018-07-31 21:39:32 --> Router Class Initialized
INFO - 2018-07-31 21:39:32 --> Output Class Initialized
INFO - 2018-07-31 21:39:32 --> Security Class Initialized
DEBUG - 2018-07-31 21:39:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 21:39:32 --> Input Class Initialized
INFO - 2018-07-31 21:39:32 --> Language Class Initialized
INFO - 2018-07-31 21:39:32 --> Language Class Initialized
INFO - 2018-07-31 21:39:32 --> Config Class Initialized
INFO - 2018-07-31 21:39:32 --> Loader Class Initialized
DEBUG - 2018-07-31 21:39:32 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-31 21:39:32 --> Helper loaded: url_helper
INFO - 2018-07-31 21:39:32 --> Helper loaded: form_helper
INFO - 2018-07-31 21:39:32 --> Helper loaded: date_helper
INFO - 2018-07-31 21:39:32 --> Helper loaded: util_helper
INFO - 2018-07-31 21:39:32 --> Helper loaded: text_helper
INFO - 2018-07-31 21:39:32 --> Helper loaded: string_helper
INFO - 2018-07-31 21:39:32 --> Database Driver Class Initialized
DEBUG - 2018-07-31 21:39:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 21:39:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 21:39:32 --> Email Class Initialized
INFO - 2018-07-31 21:39:33 --> Controller Class Initialized
DEBUG - 2018-07-31 21:39:33 --> Programs MX_Controller Initialized
INFO - 2018-07-31 21:39:33 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-31 21:39:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-07-31 21:39:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-31 21:39:33 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-31 21:39:33 --> Login MX_Controller Initialized
DEBUG - 2018-07-31 21:39:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-31 21:39:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
INFO - 2018-07-31 21:39:33 --> Upload Class Initialized
INFO - 2018-07-31 21:39:33 --> Config Class Initialized
INFO - 2018-07-31 21:39:33 --> Hooks Class Initialized
DEBUG - 2018-07-31 21:39:33 --> UTF-8 Support Enabled
INFO - 2018-07-31 21:39:33 --> Utf8 Class Initialized
INFO - 2018-07-31 21:39:33 --> URI Class Initialized
INFO - 2018-07-31 21:39:33 --> Router Class Initialized
INFO - 2018-07-31 21:39:33 --> Output Class Initialized
INFO - 2018-07-31 21:39:33 --> Security Class Initialized
DEBUG - 2018-07-31 21:39:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 21:39:33 --> Input Class Initialized
INFO - 2018-07-31 21:39:33 --> Language Class Initialized
INFO - 2018-07-31 21:39:33 --> Language Class Initialized
INFO - 2018-07-31 21:39:33 --> Config Class Initialized
INFO - 2018-07-31 21:39:33 --> Loader Class Initialized
DEBUG - 2018-07-31 21:39:33 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-31 21:39:33 --> Helper loaded: url_helper
INFO - 2018-07-31 21:39:33 --> Helper loaded: form_helper
INFO - 2018-07-31 21:39:33 --> Helper loaded: date_helper
INFO - 2018-07-31 21:39:33 --> Helper loaded: util_helper
INFO - 2018-07-31 21:39:33 --> Helper loaded: text_helper
INFO - 2018-07-31 21:39:33 --> Helper loaded: string_helper
INFO - 2018-07-31 21:39:33 --> Database Driver Class Initialized
DEBUG - 2018-07-31 21:39:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 21:39:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 21:39:33 --> Email Class Initialized
INFO - 2018-07-31 21:39:33 --> Controller Class Initialized
DEBUG - 2018-07-31 21:39:33 --> Programs MX_Controller Initialized
INFO - 2018-07-31 21:39:34 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-31 21:39:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-07-31 21:39:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-31 21:39:34 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-31 21:39:34 --> Login MX_Controller Initialized
DEBUG - 2018-07-31 21:39:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-31 21:39:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-31 21:39:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-31 21:39:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-31 21:39:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-31 21:39:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-31 21:39:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/programs/programs.php
INFO - 2018-07-31 21:39:34 --> Final output sent to browser
DEBUG - 2018-07-31 21:39:34 --> Total execution time: 0.8046
INFO - 2018-07-31 21:39:34 --> Config Class Initialized
INFO - 2018-07-31 21:39:34 --> Hooks Class Initialized
DEBUG - 2018-07-31 21:39:34 --> UTF-8 Support Enabled
INFO - 2018-07-31 21:39:34 --> Utf8 Class Initialized
INFO - 2018-07-31 21:39:34 --> URI Class Initialized
INFO - 2018-07-31 21:39:34 --> Router Class Initialized
INFO - 2018-07-31 21:39:34 --> Output Class Initialized
INFO - 2018-07-31 21:39:34 --> Security Class Initialized
DEBUG - 2018-07-31 21:39:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 21:39:34 --> Input Class Initialized
INFO - 2018-07-31 21:39:34 --> Language Class Initialized
INFO - 2018-07-31 21:39:34 --> Language Class Initialized
INFO - 2018-07-31 21:39:35 --> Config Class Initialized
INFO - 2018-07-31 21:39:35 --> Loader Class Initialized
DEBUG - 2018-07-31 21:39:35 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-31 21:39:35 --> Helper loaded: url_helper
INFO - 2018-07-31 21:39:35 --> Helper loaded: form_helper
INFO - 2018-07-31 21:39:35 --> Helper loaded: date_helper
INFO - 2018-07-31 21:39:35 --> Helper loaded: util_helper
INFO - 2018-07-31 21:39:35 --> Helper loaded: text_helper
INFO - 2018-07-31 21:39:35 --> Helper loaded: string_helper
INFO - 2018-07-31 21:39:35 --> Database Driver Class Initialized
DEBUG - 2018-07-31 21:39:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 21:39:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 21:39:35 --> Email Class Initialized
INFO - 2018-07-31 21:39:35 --> Controller Class Initialized
DEBUG - 2018-07-31 21:39:35 --> Programs MX_Controller Initialized
INFO - 2018-07-31 21:39:35 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-31 21:39:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-07-31 21:39:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-31 21:39:35 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-31 21:39:35 --> Login MX_Controller Initialized
DEBUG - 2018-07-31 21:39:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-31 21:39:35 --> Final output sent to browser
DEBUG - 2018-07-31 21:39:35 --> Total execution time: 0.7209
INFO - 2018-07-31 22:20:32 --> Config Class Initialized
INFO - 2018-07-31 22:20:32 --> Hooks Class Initialized
DEBUG - 2018-07-31 22:20:32 --> UTF-8 Support Enabled
INFO - 2018-07-31 22:20:32 --> Utf8 Class Initialized
INFO - 2018-07-31 22:20:32 --> URI Class Initialized
INFO - 2018-07-31 22:20:32 --> Router Class Initialized
INFO - 2018-07-31 22:20:32 --> Output Class Initialized
INFO - 2018-07-31 22:20:32 --> Security Class Initialized
DEBUG - 2018-07-31 22:20:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 22:20:32 --> Input Class Initialized
INFO - 2018-07-31 22:20:32 --> Language Class Initialized
INFO - 2018-07-31 22:20:32 --> Language Class Initialized
INFO - 2018-07-31 22:20:32 --> Config Class Initialized
INFO - 2018-07-31 22:20:32 --> Loader Class Initialized
DEBUG - 2018-07-31 22:20:32 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-31 22:20:32 --> Helper loaded: url_helper
INFO - 2018-07-31 22:20:32 --> Helper loaded: form_helper
INFO - 2018-07-31 22:20:32 --> Helper loaded: date_helper
INFO - 2018-07-31 22:20:32 --> Helper loaded: util_helper
INFO - 2018-07-31 22:20:32 --> Helper loaded: text_helper
INFO - 2018-07-31 22:20:32 --> Helper loaded: string_helper
INFO - 2018-07-31 22:20:32 --> Database Driver Class Initialized
DEBUG - 2018-07-31 22:20:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 22:20:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 22:20:32 --> Email Class Initialized
INFO - 2018-07-31 22:20:32 --> Controller Class Initialized
DEBUG - 2018-07-31 22:20:32 --> Home MX_Controller Initialized
DEBUG - 2018-07-31 22:20:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-31 22:20:32 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-31 22:20:33 --> Login MX_Controller Initialized
INFO - 2018-07-31 22:20:33 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-31 22:20:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-31 22:20:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-31 22:20:54 --> Config Class Initialized
INFO - 2018-07-31 22:20:54 --> Hooks Class Initialized
DEBUG - 2018-07-31 22:20:54 --> UTF-8 Support Enabled
INFO - 2018-07-31 22:20:54 --> Utf8 Class Initialized
INFO - 2018-07-31 22:20:54 --> URI Class Initialized
INFO - 2018-07-31 22:20:54 --> Router Class Initialized
INFO - 2018-07-31 22:20:54 --> Output Class Initialized
INFO - 2018-07-31 22:20:54 --> Security Class Initialized
DEBUG - 2018-07-31 22:20:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 22:20:54 --> Input Class Initialized
INFO - 2018-07-31 22:20:54 --> Language Class Initialized
INFO - 2018-07-31 22:20:54 --> Language Class Initialized
INFO - 2018-07-31 22:20:54 --> Config Class Initialized
INFO - 2018-07-31 22:20:54 --> Loader Class Initialized
DEBUG - 2018-07-31 22:20:54 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-31 22:20:54 --> Helper loaded: url_helper
INFO - 2018-07-31 22:20:54 --> Helper loaded: form_helper
INFO - 2018-07-31 22:20:54 --> Helper loaded: date_helper
INFO - 2018-07-31 22:20:54 --> Helper loaded: util_helper
INFO - 2018-07-31 22:20:54 --> Helper loaded: text_helper
INFO - 2018-07-31 22:20:54 --> Helper loaded: string_helper
INFO - 2018-07-31 22:20:54 --> Database Driver Class Initialized
DEBUG - 2018-07-31 22:20:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 22:20:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 22:20:54 --> Email Class Initialized
INFO - 2018-07-31 22:20:54 --> Controller Class Initialized
DEBUG - 2018-07-31 22:20:54 --> Home MX_Controller Initialized
DEBUG - 2018-07-31 22:20:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-31 22:20:54 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-31 22:20:54 --> Login MX_Controller Initialized
INFO - 2018-07-31 22:20:54 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-31 22:20:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-31 22:20:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-31 22:20:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-07-31 22:20:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-07-31 22:20:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-07-31 22:20:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-07-31 22:20:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-07-31 22:20:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-07-31 22:20:54 --> Final output sent to browser
DEBUG - 2018-07-31 22:20:55 --> Total execution time: 0.7384
INFO - 2018-07-31 22:20:55 --> Config Class Initialized
INFO - 2018-07-31 22:20:55 --> Hooks Class Initialized
DEBUG - 2018-07-31 22:20:55 --> UTF-8 Support Enabled
INFO - 2018-07-31 22:20:55 --> Utf8 Class Initialized
INFO - 2018-07-31 22:20:55 --> URI Class Initialized
INFO - 2018-07-31 22:20:55 --> Router Class Initialized
INFO - 2018-07-31 22:20:55 --> Output Class Initialized
INFO - 2018-07-31 22:20:55 --> Security Class Initialized
INFO - 2018-07-31 22:20:55 --> Config Class Initialized
INFO - 2018-07-31 22:20:55 --> Hooks Class Initialized
DEBUG - 2018-07-31 22:20:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-07-31 22:20:55 --> UTF-8 Support Enabled
INFO - 2018-07-31 22:20:55 --> Input Class Initialized
INFO - 2018-07-31 22:20:55 --> Utf8 Class Initialized
INFO - 2018-07-31 22:20:55 --> URI Class Initialized
INFO - 2018-07-31 22:20:55 --> Language Class Initialized
INFO - 2018-07-31 22:20:55 --> Router Class Initialized
ERROR - 2018-07-31 22:20:55 --> 404 Page Not Found: /index
INFO - 2018-07-31 22:20:55 --> Output Class Initialized
INFO - 2018-07-31 22:20:55 --> Config Class Initialized
INFO - 2018-07-31 22:20:56 --> Hooks Class Initialized
INFO - 2018-07-31 22:20:56 --> Security Class Initialized
DEBUG - 2018-07-31 22:20:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-07-31 22:20:56 --> UTF-8 Support Enabled
INFO - 2018-07-31 22:20:56 --> Utf8 Class Initialized
INFO - 2018-07-31 22:20:56 --> Input Class Initialized
INFO - 2018-07-31 22:20:56 --> Language Class Initialized
INFO - 2018-07-31 22:20:56 --> URI Class Initialized
INFO - 2018-07-31 22:20:56 --> Router Class Initialized
INFO - 2018-07-31 22:20:56 --> Language Class Initialized
INFO - 2018-07-31 22:20:56 --> Config Class Initialized
INFO - 2018-07-31 22:20:56 --> Output Class Initialized
INFO - 2018-07-31 22:20:56 --> Security Class Initialized
INFO - 2018-07-31 22:20:56 --> Loader Class Initialized
DEBUG - 2018-07-31 22:20:56 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
DEBUG - 2018-07-31 22:20:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 22:20:56 --> Helper loaded: url_helper
INFO - 2018-07-31 22:20:56 --> Input Class Initialized
INFO - 2018-07-31 22:20:56 --> Language Class Initialized
INFO - 2018-07-31 22:20:56 --> Helper loaded: form_helper
ERROR - 2018-07-31 22:20:56 --> 404 Page Not Found: /index
INFO - 2018-07-31 22:20:56 --> Helper loaded: date_helper
INFO - 2018-07-31 22:20:56 --> Config Class Initialized
INFO - 2018-07-31 22:20:56 --> Hooks Class Initialized
INFO - 2018-07-31 22:20:56 --> Helper loaded: util_helper
DEBUG - 2018-07-31 22:20:56 --> UTF-8 Support Enabled
INFO - 2018-07-31 22:20:56 --> Helper loaded: text_helper
INFO - 2018-07-31 22:20:56 --> Utf8 Class Initialized
INFO - 2018-07-31 22:20:56 --> URI Class Initialized
INFO - 2018-07-31 22:20:56 --> Helper loaded: string_helper
INFO - 2018-07-31 22:20:56 --> Router Class Initialized
INFO - 2018-07-31 22:20:56 --> Database Driver Class Initialized
INFO - 2018-07-31 22:20:56 --> Output Class Initialized
DEBUG - 2018-07-31 22:20:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 22:20:56 --> Security Class Initialized
INFO - 2018-07-31 22:20:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 22:20:56 --> Email Class Initialized
INFO - 2018-07-31 22:20:56 --> Controller Class Initialized
DEBUG - 2018-07-31 22:20:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-07-31 22:20:56 --> Home MX_Controller Initialized
INFO - 2018-07-31 22:20:56 --> Input Class Initialized
DEBUG - 2018-07-31 22:20:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-07-31 22:20:56 --> Language Class Initialized
ERROR - 2018-07-31 22:20:56 --> 404 Page Not Found: /index
DEBUG - 2018-07-31 22:20:56 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-31 22:20:56 --> Login MX_Controller Initialized
INFO - 2018-07-31 22:20:56 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-31 22:20:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-31 22:20:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-31 22:21:01 --> Config Class Initialized
INFO - 2018-07-31 22:21:01 --> Hooks Class Initialized
DEBUG - 2018-07-31 22:21:01 --> UTF-8 Support Enabled
INFO - 2018-07-31 22:21:01 --> Utf8 Class Initialized
INFO - 2018-07-31 22:21:01 --> URI Class Initialized
INFO - 2018-07-31 22:21:01 --> Router Class Initialized
INFO - 2018-07-31 22:21:01 --> Output Class Initialized
INFO - 2018-07-31 22:21:01 --> Security Class Initialized
DEBUG - 2018-07-31 22:21:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 22:21:01 --> Input Class Initialized
INFO - 2018-07-31 22:21:01 --> Language Class Initialized
INFO - 2018-07-31 22:21:01 --> Language Class Initialized
INFO - 2018-07-31 22:21:01 --> Config Class Initialized
INFO - 2018-07-31 22:21:01 --> Loader Class Initialized
DEBUG - 2018-07-31 22:21:01 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-31 22:21:01 --> Helper loaded: url_helper
INFO - 2018-07-31 22:21:01 --> Helper loaded: form_helper
INFO - 2018-07-31 22:21:01 --> Helper loaded: date_helper
INFO - 2018-07-31 22:21:01 --> Helper loaded: util_helper
INFO - 2018-07-31 22:21:01 --> Helper loaded: text_helper
INFO - 2018-07-31 22:21:01 --> Helper loaded: string_helper
INFO - 2018-07-31 22:21:01 --> Database Driver Class Initialized
DEBUG - 2018-07-31 22:21:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 22:21:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 22:21:01 --> Email Class Initialized
INFO - 2018-07-31 22:21:01 --> Controller Class Initialized
DEBUG - 2018-07-31 22:21:01 --> Home MX_Controller Initialized
DEBUG - 2018-07-31 22:21:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-31 22:21:01 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-31 22:21:01 --> Login MX_Controller Initialized
INFO - 2018-07-31 22:21:01 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-31 22:21:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-31 22:21:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-31 22:26:25 --> Config Class Initialized
INFO - 2018-07-31 22:26:25 --> Hooks Class Initialized
DEBUG - 2018-07-31 22:26:25 --> UTF-8 Support Enabled
INFO - 2018-07-31 22:26:25 --> Utf8 Class Initialized
INFO - 2018-07-31 22:26:25 --> URI Class Initialized
INFO - 2018-07-31 22:26:25 --> Router Class Initialized
INFO - 2018-07-31 22:26:25 --> Output Class Initialized
INFO - 2018-07-31 22:26:25 --> Security Class Initialized
DEBUG - 2018-07-31 22:26:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 22:26:25 --> Input Class Initialized
INFO - 2018-07-31 22:26:25 --> Language Class Initialized
INFO - 2018-07-31 22:26:25 --> Language Class Initialized
INFO - 2018-07-31 22:26:25 --> Config Class Initialized
INFO - 2018-07-31 22:26:25 --> Loader Class Initialized
DEBUG - 2018-07-31 22:26:25 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-31 22:26:25 --> Helper loaded: url_helper
INFO - 2018-07-31 22:26:25 --> Helper loaded: form_helper
INFO - 2018-07-31 22:26:25 --> Helper loaded: date_helper
INFO - 2018-07-31 22:26:25 --> Helper loaded: util_helper
INFO - 2018-07-31 22:26:25 --> Helper loaded: text_helper
INFO - 2018-07-31 22:26:25 --> Helper loaded: string_helper
INFO - 2018-07-31 22:26:25 --> Database Driver Class Initialized
DEBUG - 2018-07-31 22:26:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 22:26:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 22:26:25 --> Email Class Initialized
INFO - 2018-07-31 22:26:25 --> Controller Class Initialized
DEBUG - 2018-07-31 22:26:25 --> Home MX_Controller Initialized
DEBUG - 2018-07-31 22:26:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-31 22:26:25 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-31 22:26:25 --> Login MX_Controller Initialized
INFO - 2018-07-31 22:26:25 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-31 22:26:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-31 22:26:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-31 22:26:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-07-31 22:26:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-07-31 22:26:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-07-31 22:26:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-07-31 22:26:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-07-31 22:26:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-07-31 22:26:26 --> Final output sent to browser
DEBUG - 2018-07-31 22:26:26 --> Total execution time: 0.7277
INFO - 2018-07-31 22:26:26 --> Config Class Initialized
INFO - 2018-07-31 22:26:26 --> Hooks Class Initialized
DEBUG - 2018-07-31 22:26:26 --> UTF-8 Support Enabled
INFO - 2018-07-31 22:26:26 --> Config Class Initialized
INFO - 2018-07-31 22:26:26 --> Hooks Class Initialized
INFO - 2018-07-31 22:26:26 --> Utf8 Class Initialized
DEBUG - 2018-07-31 22:26:26 --> UTF-8 Support Enabled
INFO - 2018-07-31 22:26:26 --> Utf8 Class Initialized
INFO - 2018-07-31 22:26:26 --> URI Class Initialized
INFO - 2018-07-31 22:26:26 --> URI Class Initialized
INFO - 2018-07-31 22:26:26 --> Router Class Initialized
INFO - 2018-07-31 22:26:26 --> Output Class Initialized
INFO - 2018-07-31 22:26:26 --> Security Class Initialized
INFO - 2018-07-31 22:26:26 --> Router Class Initialized
INFO - 2018-07-31 22:26:26 --> Output Class Initialized
DEBUG - 2018-07-31 22:26:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 22:26:26 --> Security Class Initialized
INFO - 2018-07-31 22:26:26 --> Input Class Initialized
DEBUG - 2018-07-31 22:26:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 22:26:26 --> Input Class Initialized
INFO - 2018-07-31 22:26:26 --> Language Class Initialized
INFO - 2018-07-31 22:26:26 --> Language Class Initialized
INFO - 2018-07-31 22:26:26 --> Language Class Initialized
INFO - 2018-07-31 22:26:26 --> Config Class Initialized
ERROR - 2018-07-31 22:26:26 --> 404 Page Not Found: /index
INFO - 2018-07-31 22:26:26 --> Loader Class Initialized
INFO - 2018-07-31 22:26:26 --> Config Class Initialized
INFO - 2018-07-31 22:26:26 --> Hooks Class Initialized
DEBUG - 2018-07-31 22:26:26 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
DEBUG - 2018-07-31 22:26:26 --> UTF-8 Support Enabled
INFO - 2018-07-31 22:26:26 --> Utf8 Class Initialized
INFO - 2018-07-31 22:26:26 --> URI Class Initialized
INFO - 2018-07-31 22:26:27 --> Helper loaded: url_helper
INFO - 2018-07-31 22:26:27 --> Router Class Initialized
INFO - 2018-07-31 22:26:27 --> Output Class Initialized
INFO - 2018-07-31 22:26:27 --> Helper loaded: form_helper
INFO - 2018-07-31 22:26:27 --> Helper loaded: date_helper
INFO - 2018-07-31 22:26:27 --> Security Class Initialized
INFO - 2018-07-31 22:26:27 --> Helper loaded: util_helper
DEBUG - 2018-07-31 22:26:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 22:26:27 --> Helper loaded: text_helper
INFO - 2018-07-31 22:26:27 --> Input Class Initialized
INFO - 2018-07-31 22:26:27 --> Helper loaded: string_helper
INFO - 2018-07-31 22:26:27 --> Language Class Initialized
ERROR - 2018-07-31 22:26:27 --> 404 Page Not Found: /index
INFO - 2018-07-31 22:26:27 --> Database Driver Class Initialized
INFO - 2018-07-31 22:26:27 --> Config Class Initialized
DEBUG - 2018-07-31 22:26:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 22:26:27 --> Hooks Class Initialized
INFO - 2018-07-31 22:26:27 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-07-31 22:26:27 --> UTF-8 Support Enabled
INFO - 2018-07-31 22:26:27 --> Email Class Initialized
INFO - 2018-07-31 22:26:27 --> Utf8 Class Initialized
INFO - 2018-07-31 22:26:27 --> URI Class Initialized
INFO - 2018-07-31 22:26:27 --> Controller Class Initialized
DEBUG - 2018-07-31 22:26:27 --> Home MX_Controller Initialized
INFO - 2018-07-31 22:26:27 --> Router Class Initialized
DEBUG - 2018-07-31 22:26:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-07-31 22:26:27 --> Output Class Initialized
INFO - 2018-07-31 22:26:27 --> Security Class Initialized
DEBUG - 2018-07-31 22:26:27 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-31 22:26:27 --> Login MX_Controller Initialized
DEBUG - 2018-07-31 22:26:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 22:26:27 --> Input Class Initialized
INFO - 2018-07-31 22:26:27 --> Language file loaded: language/english/data_lang.php
INFO - 2018-07-31 22:26:27 --> Language Class Initialized
DEBUG - 2018-07-31 22:26:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-31 22:26:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
ERROR - 2018-07-31 22:26:27 --> 404 Page Not Found: /index
INFO - 2018-07-31 22:26:27 --> Config Class Initialized
INFO - 2018-07-31 22:26:27 --> Hooks Class Initialized
DEBUG - 2018-07-31 22:26:27 --> UTF-8 Support Enabled
INFO - 2018-07-31 22:26:27 --> Utf8 Class Initialized
INFO - 2018-07-31 22:26:27 --> URI Class Initialized
INFO - 2018-07-31 22:26:27 --> Router Class Initialized
INFO - 2018-07-31 22:26:27 --> Output Class Initialized
INFO - 2018-07-31 22:26:27 --> Security Class Initialized
DEBUG - 2018-07-31 22:26:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 22:26:27 --> Input Class Initialized
INFO - 2018-07-31 22:26:27 --> Language Class Initialized
ERROR - 2018-07-31 22:26:27 --> 404 Page Not Found: /index
INFO - 2018-07-31 22:26:27 --> Config Class Initialized
INFO - 2018-07-31 22:26:27 --> Hooks Class Initialized
DEBUG - 2018-07-31 22:26:27 --> UTF-8 Support Enabled
INFO - 2018-07-31 22:26:27 --> Utf8 Class Initialized
INFO - 2018-07-31 22:26:27 --> URI Class Initialized
INFO - 2018-07-31 22:26:27 --> Router Class Initialized
INFO - 2018-07-31 22:26:27 --> Output Class Initialized
INFO - 2018-07-31 22:26:28 --> Security Class Initialized
DEBUG - 2018-07-31 22:26:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 22:26:28 --> Input Class Initialized
INFO - 2018-07-31 22:26:28 --> Language Class Initialized
ERROR - 2018-07-31 22:26:28 --> 404 Page Not Found: /index
INFO - 2018-07-31 22:26:28 --> Config Class Initialized
INFO - 2018-07-31 22:26:28 --> Hooks Class Initialized
DEBUG - 2018-07-31 22:26:28 --> UTF-8 Support Enabled
INFO - 2018-07-31 22:26:28 --> Utf8 Class Initialized
INFO - 2018-07-31 22:26:28 --> URI Class Initialized
INFO - 2018-07-31 22:26:28 --> Router Class Initialized
INFO - 2018-07-31 22:26:28 --> Output Class Initialized
INFO - 2018-07-31 22:26:28 --> Security Class Initialized
DEBUG - 2018-07-31 22:26:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 22:26:28 --> Input Class Initialized
INFO - 2018-07-31 22:26:28 --> Language Class Initialized
ERROR - 2018-07-31 22:26:28 --> 404 Page Not Found: /index
INFO - 2018-07-31 22:27:44 --> Config Class Initialized
INFO - 2018-07-31 22:27:44 --> Hooks Class Initialized
DEBUG - 2018-07-31 22:27:44 --> UTF-8 Support Enabled
INFO - 2018-07-31 22:27:44 --> Utf8 Class Initialized
INFO - 2018-07-31 22:27:44 --> URI Class Initialized
INFO - 2018-07-31 22:27:44 --> Router Class Initialized
INFO - 2018-07-31 22:27:44 --> Output Class Initialized
INFO - 2018-07-31 22:27:44 --> Security Class Initialized
DEBUG - 2018-07-31 22:27:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 22:27:44 --> Input Class Initialized
INFO - 2018-07-31 22:27:44 --> Language Class Initialized
INFO - 2018-07-31 22:27:44 --> Language Class Initialized
INFO - 2018-07-31 22:27:44 --> Config Class Initialized
INFO - 2018-07-31 22:27:44 --> Loader Class Initialized
DEBUG - 2018-07-31 22:27:44 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-31 22:27:44 --> Helper loaded: url_helper
INFO - 2018-07-31 22:27:44 --> Helper loaded: form_helper
INFO - 2018-07-31 22:27:44 --> Helper loaded: date_helper
INFO - 2018-07-31 22:27:44 --> Helper loaded: util_helper
INFO - 2018-07-31 22:27:44 --> Helper loaded: text_helper
INFO - 2018-07-31 22:27:44 --> Helper loaded: string_helper
INFO - 2018-07-31 22:27:44 --> Database Driver Class Initialized
DEBUG - 2018-07-31 22:27:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 22:27:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 22:27:44 --> Email Class Initialized
INFO - 2018-07-31 22:27:44 --> Controller Class Initialized
DEBUG - 2018-07-31 22:27:44 --> Home MX_Controller Initialized
DEBUG - 2018-07-31 22:27:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-31 22:27:44 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-31 22:27:44 --> Login MX_Controller Initialized
INFO - 2018-07-31 22:27:44 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-31 22:27:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-31 22:27:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-31 22:27:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-07-31 22:27:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-07-31 22:27:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-07-31 22:27:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-07-31 22:27:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-07-31 22:27:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-07-31 22:27:45 --> Final output sent to browser
DEBUG - 2018-07-31 22:27:45 --> Total execution time: 0.7122
INFO - 2018-07-31 22:27:45 --> Config Class Initialized
INFO - 2018-07-31 22:27:45 --> Hooks Class Initialized
DEBUG - 2018-07-31 22:27:45 --> UTF-8 Support Enabled
INFO - 2018-07-31 22:27:45 --> Config Class Initialized
INFO - 2018-07-31 22:27:45 --> Utf8 Class Initialized
INFO - 2018-07-31 22:27:45 --> Hooks Class Initialized
INFO - 2018-07-31 22:27:45 --> URI Class Initialized
DEBUG - 2018-07-31 22:27:45 --> UTF-8 Support Enabled
INFO - 2018-07-31 22:27:45 --> Utf8 Class Initialized
INFO - 2018-07-31 22:27:45 --> Router Class Initialized
INFO - 2018-07-31 22:27:45 --> URI Class Initialized
INFO - 2018-07-31 22:27:45 --> Output Class Initialized
INFO - 2018-07-31 22:27:45 --> Router Class Initialized
INFO - 2018-07-31 22:27:45 --> Security Class Initialized
INFO - 2018-07-31 22:27:45 --> Output Class Initialized
DEBUG - 2018-07-31 22:27:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 22:27:45 --> Security Class Initialized
INFO - 2018-07-31 22:27:45 --> Input Class Initialized
DEBUG - 2018-07-31 22:27:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 22:27:46 --> Input Class Initialized
INFO - 2018-07-31 22:27:46 --> Language Class Initialized
INFO - 2018-07-31 22:27:46 --> Language Class Initialized
INFO - 2018-07-31 22:27:46 --> Language Class Initialized
INFO - 2018-07-31 22:27:46 --> Config Class Initialized
ERROR - 2018-07-31 22:27:46 --> 404 Page Not Found: /index
INFO - 2018-07-31 22:27:46 --> Loader Class Initialized
INFO - 2018-07-31 22:27:46 --> Config Class Initialized
INFO - 2018-07-31 22:27:46 --> Hooks Class Initialized
DEBUG - 2018-07-31 22:27:46 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
DEBUG - 2018-07-31 22:27:46 --> UTF-8 Support Enabled
INFO - 2018-07-31 22:27:46 --> Helper loaded: url_helper
INFO - 2018-07-31 22:27:46 --> Utf8 Class Initialized
INFO - 2018-07-31 22:27:46 --> Helper loaded: form_helper
INFO - 2018-07-31 22:27:46 --> URI Class Initialized
INFO - 2018-07-31 22:27:46 --> Helper loaded: date_helper
INFO - 2018-07-31 22:27:46 --> Helper loaded: util_helper
INFO - 2018-07-31 22:27:46 --> Router Class Initialized
INFO - 2018-07-31 22:27:46 --> Helper loaded: text_helper
INFO - 2018-07-31 22:27:46 --> Output Class Initialized
INFO - 2018-07-31 22:27:46 --> Helper loaded: string_helper
INFO - 2018-07-31 22:27:46 --> Security Class Initialized
DEBUG - 2018-07-31 22:27:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 22:27:46 --> Database Driver Class Initialized
INFO - 2018-07-31 22:27:46 --> Input Class Initialized
DEBUG - 2018-07-31 22:27:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 22:27:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 22:27:46 --> Language Class Initialized
ERROR - 2018-07-31 22:27:46 --> 404 Page Not Found: /index
INFO - 2018-07-31 22:27:46 --> Email Class Initialized
INFO - 2018-07-31 22:27:46 --> Controller Class Initialized
INFO - 2018-07-31 22:27:46 --> Config Class Initialized
INFO - 2018-07-31 22:27:46 --> Hooks Class Initialized
DEBUG - 2018-07-31 22:27:46 --> Home MX_Controller Initialized
DEBUG - 2018-07-31 22:27:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-31 22:27:46 --> UTF-8 Support Enabled
INFO - 2018-07-31 22:27:46 --> Utf8 Class Initialized
DEBUG - 2018-07-31 22:27:46 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-31 22:27:46 --> Login MX_Controller Initialized
INFO - 2018-07-31 22:27:46 --> URI Class Initialized
INFO - 2018-07-31 22:27:46 --> Language file loaded: language/english/data_lang.php
INFO - 2018-07-31 22:27:46 --> Router Class Initialized
DEBUG - 2018-07-31 22:27:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-31 22:27:46 --> Output Class Initialized
DEBUG - 2018-07-31 22:27:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-31 22:27:46 --> Security Class Initialized
DEBUG - 2018-07-31 22:27:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 22:27:46 --> Input Class Initialized
INFO - 2018-07-31 22:27:46 --> Language Class Initialized
ERROR - 2018-07-31 22:27:46 --> 404 Page Not Found: /index
INFO - 2018-07-31 22:27:46 --> Config Class Initialized
INFO - 2018-07-31 22:27:46 --> Hooks Class Initialized
DEBUG - 2018-07-31 22:27:46 --> UTF-8 Support Enabled
INFO - 2018-07-31 22:27:46 --> Utf8 Class Initialized
INFO - 2018-07-31 22:27:46 --> URI Class Initialized
INFO - 2018-07-31 22:27:46 --> Router Class Initialized
INFO - 2018-07-31 22:27:46 --> Output Class Initialized
INFO - 2018-07-31 22:27:46 --> Security Class Initialized
DEBUG - 2018-07-31 22:27:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 22:27:47 --> Input Class Initialized
INFO - 2018-07-31 22:27:47 --> Language Class Initialized
ERROR - 2018-07-31 22:27:47 --> 404 Page Not Found: /index
INFO - 2018-07-31 22:27:47 --> Config Class Initialized
INFO - 2018-07-31 22:27:47 --> Hooks Class Initialized
DEBUG - 2018-07-31 22:27:47 --> UTF-8 Support Enabled
INFO - 2018-07-31 22:27:47 --> Utf8 Class Initialized
INFO - 2018-07-31 22:27:47 --> URI Class Initialized
INFO - 2018-07-31 22:27:47 --> Router Class Initialized
INFO - 2018-07-31 22:27:47 --> Output Class Initialized
INFO - 2018-07-31 22:27:47 --> Security Class Initialized
DEBUG - 2018-07-31 22:27:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 22:27:47 --> Input Class Initialized
INFO - 2018-07-31 22:27:47 --> Language Class Initialized
ERROR - 2018-07-31 22:27:47 --> 404 Page Not Found: /index
INFO - 2018-07-31 22:27:47 --> Config Class Initialized
INFO - 2018-07-31 22:27:47 --> Hooks Class Initialized
DEBUG - 2018-07-31 22:27:47 --> UTF-8 Support Enabled
INFO - 2018-07-31 22:27:47 --> Utf8 Class Initialized
INFO - 2018-07-31 22:27:47 --> URI Class Initialized
INFO - 2018-07-31 22:27:47 --> Router Class Initialized
INFO - 2018-07-31 22:27:47 --> Output Class Initialized
INFO - 2018-07-31 22:27:47 --> Security Class Initialized
DEBUG - 2018-07-31 22:27:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 22:27:47 --> Input Class Initialized
INFO - 2018-07-31 22:27:47 --> Language Class Initialized
ERROR - 2018-07-31 22:27:47 --> 404 Page Not Found: /index
INFO - 2018-07-31 22:28:01 --> Config Class Initialized
INFO - 2018-07-31 22:28:01 --> Hooks Class Initialized
DEBUG - 2018-07-31 22:28:01 --> UTF-8 Support Enabled
INFO - 2018-07-31 22:28:01 --> Utf8 Class Initialized
INFO - 2018-07-31 22:28:01 --> URI Class Initialized
INFO - 2018-07-31 22:28:01 --> Router Class Initialized
INFO - 2018-07-31 22:28:01 --> Output Class Initialized
INFO - 2018-07-31 22:28:01 --> Security Class Initialized
DEBUG - 2018-07-31 22:28:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 22:28:01 --> Input Class Initialized
INFO - 2018-07-31 22:28:01 --> Language Class Initialized
INFO - 2018-07-31 22:28:01 --> Language Class Initialized
INFO - 2018-07-31 22:28:01 --> Config Class Initialized
INFO - 2018-07-31 22:28:01 --> Loader Class Initialized
DEBUG - 2018-07-31 22:28:01 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-31 22:28:01 --> Helper loaded: url_helper
INFO - 2018-07-31 22:28:01 --> Helper loaded: form_helper
INFO - 2018-07-31 22:28:01 --> Helper loaded: date_helper
INFO - 2018-07-31 22:28:01 --> Helper loaded: util_helper
INFO - 2018-07-31 22:28:01 --> Helper loaded: text_helper
INFO - 2018-07-31 22:28:01 --> Helper loaded: string_helper
INFO - 2018-07-31 22:28:02 --> Database Driver Class Initialized
DEBUG - 2018-07-31 22:28:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 22:28:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 22:28:02 --> Email Class Initialized
INFO - 2018-07-31 22:28:02 --> Controller Class Initialized
DEBUG - 2018-07-31 22:28:02 --> Home MX_Controller Initialized
DEBUG - 2018-07-31 22:28:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-31 22:28:02 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-31 22:28:02 --> Login MX_Controller Initialized
INFO - 2018-07-31 22:28:02 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-31 22:28:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-31 22:28:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-31 22:28:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-07-31 22:28:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-07-31 22:28:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-07-31 22:28:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-07-31 22:28:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-07-31 22:28:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-07-31 22:28:02 --> Final output sent to browser
DEBUG - 2018-07-31 22:28:02 --> Total execution time: 0.8028
INFO - 2018-07-31 22:31:52 --> Config Class Initialized
INFO - 2018-07-31 22:31:52 --> Hooks Class Initialized
DEBUG - 2018-07-31 22:31:52 --> UTF-8 Support Enabled
INFO - 2018-07-31 22:31:52 --> Utf8 Class Initialized
INFO - 2018-07-31 22:31:52 --> URI Class Initialized
INFO - 2018-07-31 22:31:52 --> Router Class Initialized
INFO - 2018-07-31 22:31:52 --> Output Class Initialized
INFO - 2018-07-31 22:31:52 --> Security Class Initialized
DEBUG - 2018-07-31 22:31:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 22:31:52 --> Input Class Initialized
INFO - 2018-07-31 22:31:52 --> Language Class Initialized
INFO - 2018-07-31 22:31:52 --> Language Class Initialized
INFO - 2018-07-31 22:31:52 --> Config Class Initialized
INFO - 2018-07-31 22:31:52 --> Loader Class Initialized
DEBUG - 2018-07-31 22:31:52 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-31 22:31:52 --> Helper loaded: url_helper
INFO - 2018-07-31 22:31:52 --> Helper loaded: form_helper
INFO - 2018-07-31 22:31:52 --> Helper loaded: date_helper
INFO - 2018-07-31 22:31:52 --> Helper loaded: util_helper
INFO - 2018-07-31 22:31:52 --> Helper loaded: text_helper
INFO - 2018-07-31 22:31:52 --> Helper loaded: string_helper
INFO - 2018-07-31 22:31:52 --> Database Driver Class Initialized
DEBUG - 2018-07-31 22:31:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 22:31:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 22:31:52 --> Email Class Initialized
INFO - 2018-07-31 22:31:52 --> Controller Class Initialized
DEBUG - 2018-07-31 22:31:52 --> Home MX_Controller Initialized
DEBUG - 2018-07-31 22:31:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-31 22:31:52 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-31 22:31:52 --> Login MX_Controller Initialized
INFO - 2018-07-31 22:31:52 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-31 22:31:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-31 22:31:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-31 22:31:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-07-31 22:31:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-07-31 22:31:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-07-31 22:31:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-07-31 22:31:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-07-31 22:31:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-07-31 22:31:52 --> Final output sent to browser
DEBUG - 2018-07-31 22:31:52 --> Total execution time: 0.7810
INFO - 2018-07-31 22:31:53 --> Config Class Initialized
INFO - 2018-07-31 22:31:53 --> Hooks Class Initialized
INFO - 2018-07-31 22:31:53 --> Config Class Initialized
INFO - 2018-07-31 22:31:53 --> Hooks Class Initialized
DEBUG - 2018-07-31 22:31:53 --> UTF-8 Support Enabled
DEBUG - 2018-07-31 22:31:53 --> UTF-8 Support Enabled
INFO - 2018-07-31 22:31:53 --> Utf8 Class Initialized
INFO - 2018-07-31 22:31:53 --> Utf8 Class Initialized
INFO - 2018-07-31 22:31:53 --> URI Class Initialized
INFO - 2018-07-31 22:31:53 --> URI Class Initialized
INFO - 2018-07-31 22:31:53 --> Router Class Initialized
INFO - 2018-07-31 22:31:53 --> Output Class Initialized
INFO - 2018-07-31 22:31:53 --> Router Class Initialized
INFO - 2018-07-31 22:31:53 --> Security Class Initialized
DEBUG - 2018-07-31 22:31:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 22:31:53 --> Input Class Initialized
INFO - 2018-07-31 22:31:53 --> Output Class Initialized
INFO - 2018-07-31 22:31:53 --> Language Class Initialized
INFO - 2018-07-31 22:31:53 --> Language Class Initialized
INFO - 2018-07-31 22:31:53 --> Config Class Initialized
INFO - 2018-07-31 22:31:53 --> Security Class Initialized
INFO - 2018-07-31 22:31:53 --> Loader Class Initialized
DEBUG - 2018-07-31 22:31:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 22:31:53 --> Input Class Initialized
INFO - 2018-07-31 22:31:53 --> Language Class Initialized
DEBUG - 2018-07-31 22:31:53 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
ERROR - 2018-07-31 22:31:53 --> 404 Page Not Found: /index
INFO - 2018-07-31 22:31:54 --> Helper loaded: url_helper
INFO - 2018-07-31 22:31:54 --> Config Class Initialized
INFO - 2018-07-31 22:31:54 --> Hooks Class Initialized
INFO - 2018-07-31 22:31:54 --> Helper loaded: form_helper
DEBUG - 2018-07-31 22:31:54 --> UTF-8 Support Enabled
INFO - 2018-07-31 22:31:54 --> Utf8 Class Initialized
INFO - 2018-07-31 22:31:54 --> URI Class Initialized
INFO - 2018-07-31 22:31:54 --> Router Class Initialized
INFO - 2018-07-31 22:31:54 --> Helper loaded: date_helper
INFO - 2018-07-31 22:31:54 --> Output Class Initialized
INFO - 2018-07-31 22:31:54 --> Security Class Initialized
INFO - 2018-07-31 22:31:54 --> Helper loaded: util_helper
DEBUG - 2018-07-31 22:31:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 22:31:54 --> Helper loaded: text_helper
INFO - 2018-07-31 22:31:54 --> Input Class Initialized
INFO - 2018-07-31 22:31:54 --> Helper loaded: string_helper
INFO - 2018-07-31 22:31:54 --> Language Class Initialized
ERROR - 2018-07-31 22:31:54 --> 404 Page Not Found: /index
INFO - 2018-07-31 22:31:54 --> Database Driver Class Initialized
INFO - 2018-07-31 22:31:54 --> Config Class Initialized
INFO - 2018-07-31 22:31:54 --> Hooks Class Initialized
DEBUG - 2018-07-31 22:31:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 22:31:54 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-07-31 22:31:54 --> UTF-8 Support Enabled
INFO - 2018-07-31 22:31:54 --> Utf8 Class Initialized
INFO - 2018-07-31 22:31:54 --> Email Class Initialized
INFO - 2018-07-31 22:31:54 --> URI Class Initialized
INFO - 2018-07-31 22:31:54 --> Controller Class Initialized
DEBUG - 2018-07-31 22:31:54 --> Home MX_Controller Initialized
INFO - 2018-07-31 22:31:54 --> Router Class Initialized
INFO - 2018-07-31 22:31:54 --> Output Class Initialized
DEBUG - 2018-07-31 22:31:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-07-31 22:31:54 --> Security Class Initialized
DEBUG - 2018-07-31 22:31:54 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-31 22:31:54 --> Login MX_Controller Initialized
DEBUG - 2018-07-31 22:31:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 22:31:54 --> Language file loaded: language/english/data_lang.php
INFO - 2018-07-31 22:31:54 --> Input Class Initialized
DEBUG - 2018-07-31 22:31:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-31 22:31:54 --> Language Class Initialized
DEBUG - 2018-07-31 22:31:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
ERROR - 2018-07-31 22:31:54 --> 404 Page Not Found: /index
INFO - 2018-07-31 22:31:54 --> Config Class Initialized
INFO - 2018-07-31 22:31:54 --> Hooks Class Initialized
DEBUG - 2018-07-31 22:31:54 --> UTF-8 Support Enabled
INFO - 2018-07-31 22:31:54 --> Utf8 Class Initialized
INFO - 2018-07-31 22:31:54 --> URI Class Initialized
INFO - 2018-07-31 22:31:54 --> Router Class Initialized
INFO - 2018-07-31 22:31:54 --> Output Class Initialized
INFO - 2018-07-31 22:31:54 --> Security Class Initialized
DEBUG - 2018-07-31 22:31:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 22:31:54 --> Input Class Initialized
INFO - 2018-07-31 22:31:54 --> Language Class Initialized
ERROR - 2018-07-31 22:31:54 --> 404 Page Not Found: /index
INFO - 2018-07-31 22:31:55 --> Config Class Initialized
INFO - 2018-07-31 22:31:55 --> Hooks Class Initialized
DEBUG - 2018-07-31 22:31:55 --> UTF-8 Support Enabled
INFO - 2018-07-31 22:31:55 --> Utf8 Class Initialized
INFO - 2018-07-31 22:31:55 --> URI Class Initialized
INFO - 2018-07-31 22:31:55 --> Router Class Initialized
INFO - 2018-07-31 22:31:55 --> Output Class Initialized
INFO - 2018-07-31 22:31:55 --> Security Class Initialized
DEBUG - 2018-07-31 22:31:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 22:31:55 --> Input Class Initialized
INFO - 2018-07-31 22:31:55 --> Language Class Initialized
ERROR - 2018-07-31 22:31:55 --> 404 Page Not Found: /index
INFO - 2018-07-31 22:31:55 --> Config Class Initialized
INFO - 2018-07-31 22:31:55 --> Hooks Class Initialized
DEBUG - 2018-07-31 22:31:55 --> UTF-8 Support Enabled
INFO - 2018-07-31 22:31:55 --> Utf8 Class Initialized
INFO - 2018-07-31 22:31:55 --> URI Class Initialized
INFO - 2018-07-31 22:31:55 --> Router Class Initialized
INFO - 2018-07-31 22:31:55 --> Output Class Initialized
INFO - 2018-07-31 22:31:55 --> Security Class Initialized
DEBUG - 2018-07-31 22:31:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 22:31:55 --> Input Class Initialized
INFO - 2018-07-31 22:31:55 --> Language Class Initialized
ERROR - 2018-07-31 22:31:55 --> 404 Page Not Found: /index
INFO - 2018-07-31 22:31:58 --> Config Class Initialized
INFO - 2018-07-31 22:31:58 --> Hooks Class Initialized
DEBUG - 2018-07-31 22:31:58 --> UTF-8 Support Enabled
INFO - 2018-07-31 22:31:58 --> Utf8 Class Initialized
INFO - 2018-07-31 22:31:58 --> URI Class Initialized
INFO - 2018-07-31 22:31:58 --> Router Class Initialized
INFO - 2018-07-31 22:31:58 --> Output Class Initialized
INFO - 2018-07-31 22:31:58 --> Security Class Initialized
DEBUG - 2018-07-31 22:31:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 22:31:58 --> Input Class Initialized
INFO - 2018-07-31 22:31:58 --> Language Class Initialized
INFO - 2018-07-31 22:31:58 --> Language Class Initialized
INFO - 2018-07-31 22:31:58 --> Config Class Initialized
INFO - 2018-07-31 22:31:58 --> Loader Class Initialized
DEBUG - 2018-07-31 22:31:58 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-31 22:31:58 --> Helper loaded: url_helper
INFO - 2018-07-31 22:31:58 --> Helper loaded: form_helper
INFO - 2018-07-31 22:31:58 --> Helper loaded: date_helper
INFO - 2018-07-31 22:31:58 --> Helper loaded: util_helper
INFO - 2018-07-31 22:31:58 --> Helper loaded: text_helper
INFO - 2018-07-31 22:31:58 --> Helper loaded: string_helper
INFO - 2018-07-31 22:31:58 --> Database Driver Class Initialized
DEBUG - 2018-07-31 22:31:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 22:31:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 22:31:58 --> Email Class Initialized
INFO - 2018-07-31 22:31:58 --> Controller Class Initialized
DEBUG - 2018-07-31 22:31:58 --> Programs MX_Controller Initialized
INFO - 2018-07-31 22:31:58 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-31 22:31:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-07-31 22:31:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-31 22:31:58 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-31 22:31:58 --> Login MX_Controller Initialized
DEBUG - 2018-07-31 22:31:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-31 22:31:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-31 22:31:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-31 22:31:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-31 22:31:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-31 22:31:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-31 22:31:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/programs/create_program.php
INFO - 2018-07-31 22:31:58 --> Final output sent to browser
DEBUG - 2018-07-31 22:31:59 --> Total execution time: 0.7599
INFO - 2018-07-31 22:32:00 --> Config Class Initialized
INFO - 2018-07-31 22:32:00 --> Hooks Class Initialized
DEBUG - 2018-07-31 22:32:00 --> UTF-8 Support Enabled
INFO - 2018-07-31 22:32:00 --> Utf8 Class Initialized
INFO - 2018-07-31 22:32:01 --> URI Class Initialized
INFO - 2018-07-31 22:32:01 --> Router Class Initialized
INFO - 2018-07-31 22:32:01 --> Output Class Initialized
INFO - 2018-07-31 22:32:01 --> Security Class Initialized
DEBUG - 2018-07-31 22:32:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 22:32:01 --> Input Class Initialized
INFO - 2018-07-31 22:32:01 --> Language Class Initialized
INFO - 2018-07-31 22:32:01 --> Language Class Initialized
INFO - 2018-07-31 22:32:01 --> Config Class Initialized
INFO - 2018-07-31 22:32:01 --> Loader Class Initialized
DEBUG - 2018-07-31 22:32:01 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-31 22:32:01 --> Helper loaded: url_helper
INFO - 2018-07-31 22:32:01 --> Helper loaded: form_helper
INFO - 2018-07-31 22:32:01 --> Helper loaded: date_helper
INFO - 2018-07-31 22:32:01 --> Helper loaded: util_helper
INFO - 2018-07-31 22:32:01 --> Helper loaded: text_helper
INFO - 2018-07-31 22:32:01 --> Helper loaded: string_helper
INFO - 2018-07-31 22:32:01 --> Database Driver Class Initialized
DEBUG - 2018-07-31 22:32:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 22:32:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 22:32:01 --> Email Class Initialized
INFO - 2018-07-31 22:32:01 --> Controller Class Initialized
DEBUG - 2018-07-31 22:32:01 --> Programs MX_Controller Initialized
INFO - 2018-07-31 22:32:01 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-31 22:32:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-07-31 22:32:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-31 22:32:01 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-31 22:32:01 --> Login MX_Controller Initialized
DEBUG - 2018-07-31 22:32:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-31 22:32:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-31 22:32:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-31 22:32:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-31 22:32:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-31 22:32:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-31 22:32:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/programs/programs.php
INFO - 2018-07-31 22:32:01 --> Final output sent to browser
DEBUG - 2018-07-31 22:32:01 --> Total execution time: 0.8121
INFO - 2018-07-31 22:32:02 --> Config Class Initialized
INFO - 2018-07-31 22:32:02 --> Hooks Class Initialized
DEBUG - 2018-07-31 22:32:02 --> UTF-8 Support Enabled
INFO - 2018-07-31 22:32:02 --> Utf8 Class Initialized
INFO - 2018-07-31 22:32:02 --> URI Class Initialized
INFO - 2018-07-31 22:32:02 --> Router Class Initialized
INFO - 2018-07-31 22:32:02 --> Output Class Initialized
INFO - 2018-07-31 22:32:02 --> Security Class Initialized
DEBUG - 2018-07-31 22:32:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 22:32:02 --> Input Class Initialized
INFO - 2018-07-31 22:32:02 --> Language Class Initialized
INFO - 2018-07-31 22:32:02 --> Language Class Initialized
INFO - 2018-07-31 22:32:02 --> Config Class Initialized
INFO - 2018-07-31 22:32:02 --> Loader Class Initialized
DEBUG - 2018-07-31 22:32:02 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-31 22:32:02 --> Helper loaded: url_helper
INFO - 2018-07-31 22:32:02 --> Helper loaded: form_helper
INFO - 2018-07-31 22:32:02 --> Helper loaded: date_helper
INFO - 2018-07-31 22:32:02 --> Helper loaded: util_helper
INFO - 2018-07-31 22:32:02 --> Helper loaded: text_helper
INFO - 2018-07-31 22:32:02 --> Helper loaded: string_helper
INFO - 2018-07-31 22:32:02 --> Database Driver Class Initialized
DEBUG - 2018-07-31 22:32:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 22:32:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 22:32:02 --> Email Class Initialized
INFO - 2018-07-31 22:32:02 --> Controller Class Initialized
DEBUG - 2018-07-31 22:32:02 --> Programs MX_Controller Initialized
INFO - 2018-07-31 22:32:02 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-31 22:32:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-07-31 22:32:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-31 22:32:02 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-31 22:32:02 --> Login MX_Controller Initialized
DEBUG - 2018-07-31 22:32:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-31 22:32:02 --> Final output sent to browser
DEBUG - 2018-07-31 22:32:02 --> Total execution time: 0.7760
INFO - 2018-07-31 22:32:04 --> Config Class Initialized
INFO - 2018-07-31 22:32:04 --> Hooks Class Initialized
DEBUG - 2018-07-31 22:32:04 --> UTF-8 Support Enabled
INFO - 2018-07-31 22:32:04 --> Utf8 Class Initialized
INFO - 2018-07-31 22:32:04 --> URI Class Initialized
INFO - 2018-07-31 22:32:04 --> Router Class Initialized
INFO - 2018-07-31 22:32:04 --> Output Class Initialized
INFO - 2018-07-31 22:32:04 --> Security Class Initialized
DEBUG - 2018-07-31 22:32:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 22:32:04 --> Input Class Initialized
INFO - 2018-07-31 22:32:04 --> Language Class Initialized
INFO - 2018-07-31 22:32:04 --> Language Class Initialized
INFO - 2018-07-31 22:32:04 --> Config Class Initialized
INFO - 2018-07-31 22:32:04 --> Loader Class Initialized
DEBUG - 2018-07-31 22:32:04 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-31 22:32:04 --> Helper loaded: url_helper
INFO - 2018-07-31 22:32:04 --> Helper loaded: form_helper
INFO - 2018-07-31 22:32:04 --> Helper loaded: date_helper
INFO - 2018-07-31 22:32:04 --> Helper loaded: util_helper
INFO - 2018-07-31 22:32:04 --> Helper loaded: text_helper
INFO - 2018-07-31 22:32:04 --> Helper loaded: string_helper
INFO - 2018-07-31 22:32:04 --> Database Driver Class Initialized
DEBUG - 2018-07-31 22:32:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 22:32:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 22:32:04 --> Email Class Initialized
INFO - 2018-07-31 22:32:04 --> Controller Class Initialized
DEBUG - 2018-07-31 22:32:04 --> Programs MX_Controller Initialized
INFO - 2018-07-31 22:32:04 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-31 22:32:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-07-31 22:32:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-31 22:32:04 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-31 22:32:04 --> Login MX_Controller Initialized
DEBUG - 2018-07-31 22:32:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-31 22:32:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-31 22:32:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-31 22:32:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-31 22:32:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-31 22:32:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-31 22:32:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/programs/create_program.php
INFO - 2018-07-31 22:32:04 --> Final output sent to browser
DEBUG - 2018-07-31 22:32:04 --> Total execution time: 0.7630
INFO - 2018-07-31 22:32:15 --> Config Class Initialized
INFO - 2018-07-31 22:32:15 --> Hooks Class Initialized
DEBUG - 2018-07-31 22:32:15 --> UTF-8 Support Enabled
INFO - 2018-07-31 22:32:15 --> Utf8 Class Initialized
INFO - 2018-07-31 22:32:15 --> URI Class Initialized
INFO - 2018-07-31 22:32:15 --> Router Class Initialized
INFO - 2018-07-31 22:32:15 --> Output Class Initialized
INFO - 2018-07-31 22:32:15 --> Security Class Initialized
DEBUG - 2018-07-31 22:32:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 22:32:15 --> Input Class Initialized
INFO - 2018-07-31 22:32:15 --> Language Class Initialized
INFO - 2018-07-31 22:32:15 --> Language Class Initialized
INFO - 2018-07-31 22:32:15 --> Config Class Initialized
INFO - 2018-07-31 22:32:15 --> Loader Class Initialized
DEBUG - 2018-07-31 22:32:15 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-31 22:32:15 --> Helper loaded: url_helper
INFO - 2018-07-31 22:32:15 --> Helper loaded: form_helper
INFO - 2018-07-31 22:32:15 --> Helper loaded: date_helper
INFO - 2018-07-31 22:32:15 --> Helper loaded: util_helper
INFO - 2018-07-31 22:32:15 --> Helper loaded: text_helper
INFO - 2018-07-31 22:32:15 --> Helper loaded: string_helper
INFO - 2018-07-31 22:32:15 --> Database Driver Class Initialized
DEBUG - 2018-07-31 22:32:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 22:32:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 22:32:15 --> Email Class Initialized
INFO - 2018-07-31 22:32:15 --> Controller Class Initialized
DEBUG - 2018-07-31 22:32:15 --> Programs MX_Controller Initialized
INFO - 2018-07-31 22:32:15 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-31 22:32:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-07-31 22:32:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-31 22:32:15 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-31 22:32:15 --> Login MX_Controller Initialized
DEBUG - 2018-07-31 22:32:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-31 22:32:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
INFO - 2018-07-31 22:32:15 --> Upload Class Initialized
INFO - 2018-07-31 22:32:15 --> Config Class Initialized
INFO - 2018-07-31 22:32:16 --> Hooks Class Initialized
DEBUG - 2018-07-31 22:32:16 --> UTF-8 Support Enabled
INFO - 2018-07-31 22:32:16 --> Utf8 Class Initialized
INFO - 2018-07-31 22:32:16 --> URI Class Initialized
INFO - 2018-07-31 22:32:16 --> Router Class Initialized
INFO - 2018-07-31 22:32:16 --> Output Class Initialized
INFO - 2018-07-31 22:32:16 --> Security Class Initialized
DEBUG - 2018-07-31 22:32:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 22:32:16 --> Input Class Initialized
INFO - 2018-07-31 22:32:16 --> Language Class Initialized
INFO - 2018-07-31 22:32:16 --> Language Class Initialized
INFO - 2018-07-31 22:32:16 --> Config Class Initialized
INFO - 2018-07-31 22:32:16 --> Loader Class Initialized
DEBUG - 2018-07-31 22:32:16 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-31 22:32:16 --> Helper loaded: url_helper
INFO - 2018-07-31 22:32:16 --> Helper loaded: form_helper
INFO - 2018-07-31 22:32:16 --> Helper loaded: date_helper
INFO - 2018-07-31 22:32:16 --> Helper loaded: util_helper
INFO - 2018-07-31 22:32:16 --> Helper loaded: text_helper
INFO - 2018-07-31 22:32:16 --> Helper loaded: string_helper
INFO - 2018-07-31 22:32:16 --> Database Driver Class Initialized
DEBUG - 2018-07-31 22:32:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 22:32:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 22:32:16 --> Email Class Initialized
INFO - 2018-07-31 22:32:16 --> Controller Class Initialized
DEBUG - 2018-07-31 22:32:16 --> Programs MX_Controller Initialized
INFO - 2018-07-31 22:32:16 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-31 22:32:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-07-31 22:32:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-31 22:32:16 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-31 22:32:16 --> Login MX_Controller Initialized
DEBUG - 2018-07-31 22:32:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-31 22:32:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-31 22:32:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-31 22:32:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-31 22:32:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-31 22:32:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-31 22:32:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/programs/programs.php
INFO - 2018-07-31 22:32:16 --> Final output sent to browser
DEBUG - 2018-07-31 22:32:16 --> Total execution time: 0.8687
INFO - 2018-07-31 22:32:17 --> Config Class Initialized
INFO - 2018-07-31 22:32:17 --> Hooks Class Initialized
DEBUG - 2018-07-31 22:32:17 --> UTF-8 Support Enabled
INFO - 2018-07-31 22:32:17 --> Utf8 Class Initialized
INFO - 2018-07-31 22:32:17 --> URI Class Initialized
INFO - 2018-07-31 22:32:17 --> Router Class Initialized
INFO - 2018-07-31 22:32:17 --> Output Class Initialized
INFO - 2018-07-31 22:32:17 --> Security Class Initialized
DEBUG - 2018-07-31 22:32:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 22:32:17 --> Input Class Initialized
INFO - 2018-07-31 22:32:17 --> Language Class Initialized
INFO - 2018-07-31 22:32:17 --> Language Class Initialized
INFO - 2018-07-31 22:32:17 --> Config Class Initialized
INFO - 2018-07-31 22:32:17 --> Loader Class Initialized
DEBUG - 2018-07-31 22:32:17 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-31 22:32:17 --> Helper loaded: url_helper
INFO - 2018-07-31 22:32:17 --> Helper loaded: form_helper
INFO - 2018-07-31 22:32:17 --> Helper loaded: date_helper
INFO - 2018-07-31 22:32:17 --> Helper loaded: util_helper
INFO - 2018-07-31 22:32:17 --> Helper loaded: text_helper
INFO - 2018-07-31 22:32:17 --> Helper loaded: string_helper
INFO - 2018-07-31 22:32:17 --> Database Driver Class Initialized
DEBUG - 2018-07-31 22:32:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 22:32:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 22:32:18 --> Email Class Initialized
INFO - 2018-07-31 22:32:18 --> Controller Class Initialized
DEBUG - 2018-07-31 22:32:18 --> Programs MX_Controller Initialized
INFO - 2018-07-31 22:32:18 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-31 22:32:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-07-31 22:32:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-31 22:32:18 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-31 22:32:18 --> Login MX_Controller Initialized
DEBUG - 2018-07-31 22:32:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-31 22:32:18 --> Final output sent to browser
DEBUG - 2018-07-31 22:32:18 --> Total execution time: 0.8705
INFO - 2018-07-31 22:32:19 --> Config Class Initialized
INFO - 2018-07-31 22:32:19 --> Hooks Class Initialized
DEBUG - 2018-07-31 22:32:19 --> UTF-8 Support Enabled
INFO - 2018-07-31 22:32:19 --> Utf8 Class Initialized
INFO - 2018-07-31 22:32:19 --> URI Class Initialized
INFO - 2018-07-31 22:32:19 --> Router Class Initialized
INFO - 2018-07-31 22:32:19 --> Output Class Initialized
INFO - 2018-07-31 22:32:19 --> Security Class Initialized
DEBUG - 2018-07-31 22:32:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 22:32:19 --> Input Class Initialized
INFO - 2018-07-31 22:32:19 --> Language Class Initialized
INFO - 2018-07-31 22:32:19 --> Language Class Initialized
INFO - 2018-07-31 22:32:19 --> Config Class Initialized
INFO - 2018-07-31 22:32:19 --> Loader Class Initialized
DEBUG - 2018-07-31 22:32:19 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-31 22:32:19 --> Helper loaded: url_helper
INFO - 2018-07-31 22:32:19 --> Helper loaded: form_helper
INFO - 2018-07-31 22:32:19 --> Helper loaded: date_helper
INFO - 2018-07-31 22:32:19 --> Helper loaded: util_helper
INFO - 2018-07-31 22:32:19 --> Helper loaded: text_helper
INFO - 2018-07-31 22:32:19 --> Helper loaded: string_helper
INFO - 2018-07-31 22:32:19 --> Database Driver Class Initialized
DEBUG - 2018-07-31 22:32:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 22:32:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 22:32:19 --> Email Class Initialized
INFO - 2018-07-31 22:32:19 --> Controller Class Initialized
DEBUG - 2018-07-31 22:32:19 --> Home MX_Controller Initialized
DEBUG - 2018-07-31 22:32:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-31 22:32:19 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-31 22:32:19 --> Login MX_Controller Initialized
INFO - 2018-07-31 22:32:19 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-31 22:32:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-31 22:32:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-31 22:32:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-07-31 22:32:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-07-31 22:32:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-07-31 22:32:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-07-31 22:32:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-07-31 22:32:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-07-31 22:32:19 --> Final output sent to browser
DEBUG - 2018-07-31 22:32:20 --> Total execution time: 0.8012
INFO - 2018-07-31 22:32:20 --> Config Class Initialized
INFO - 2018-07-31 22:32:20 --> Hooks Class Initialized
DEBUG - 2018-07-31 22:32:20 --> UTF-8 Support Enabled
INFO - 2018-07-31 22:32:20 --> Config Class Initialized
INFO - 2018-07-31 22:32:20 --> Hooks Class Initialized
INFO - 2018-07-31 22:32:20 --> Utf8 Class Initialized
DEBUG - 2018-07-31 22:32:20 --> UTF-8 Support Enabled
INFO - 2018-07-31 22:32:20 --> Utf8 Class Initialized
INFO - 2018-07-31 22:32:20 --> URI Class Initialized
INFO - 2018-07-31 22:32:20 --> URI Class Initialized
INFO - 2018-07-31 22:32:20 --> Router Class Initialized
INFO - 2018-07-31 22:32:20 --> Router Class Initialized
INFO - 2018-07-31 22:32:20 --> Output Class Initialized
INFO - 2018-07-31 22:32:20 --> Output Class Initialized
INFO - 2018-07-31 22:32:20 --> Security Class Initialized
INFO - 2018-07-31 22:32:20 --> Security Class Initialized
DEBUG - 2018-07-31 22:32:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-07-31 22:32:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 22:32:20 --> Input Class Initialized
INFO - 2018-07-31 22:32:20 --> Input Class Initialized
INFO - 2018-07-31 22:32:20 --> Language Class Initialized
INFO - 2018-07-31 22:32:20 --> Language Class Initialized
INFO - 2018-07-31 22:32:20 --> Language Class Initialized
ERROR - 2018-07-31 22:32:20 --> 404 Page Not Found: /index
INFO - 2018-07-31 22:32:20 --> Config Class Initialized
INFO - 2018-07-31 22:32:20 --> Config Class Initialized
INFO - 2018-07-31 22:32:20 --> Hooks Class Initialized
INFO - 2018-07-31 22:32:20 --> Loader Class Initialized
DEBUG - 2018-07-31 22:32:20 --> UTF-8 Support Enabled
INFO - 2018-07-31 22:32:20 --> Utf8 Class Initialized
DEBUG - 2018-07-31 22:32:20 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-31 22:32:20 --> URI Class Initialized
INFO - 2018-07-31 22:32:20 --> Helper loaded: url_helper
INFO - 2018-07-31 22:32:21 --> Helper loaded: form_helper
INFO - 2018-07-31 22:32:21 --> Router Class Initialized
INFO - 2018-07-31 22:32:21 --> Output Class Initialized
INFO - 2018-07-31 22:32:21 --> Helper loaded: date_helper
INFO - 2018-07-31 22:32:21 --> Security Class Initialized
DEBUG - 2018-07-31 22:32:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 22:32:21 --> Helper loaded: util_helper
INFO - 2018-07-31 22:32:21 --> Helper loaded: text_helper
INFO - 2018-07-31 22:32:21 --> Input Class Initialized
INFO - 2018-07-31 22:32:21 --> Helper loaded: string_helper
INFO - 2018-07-31 22:32:21 --> Language Class Initialized
ERROR - 2018-07-31 22:32:21 --> 404 Page Not Found: /index
INFO - 2018-07-31 22:32:21 --> Database Driver Class Initialized
DEBUG - 2018-07-31 22:32:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 22:32:21 --> Config Class Initialized
INFO - 2018-07-31 22:32:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 22:32:21 --> Hooks Class Initialized
INFO - 2018-07-31 22:32:21 --> Email Class Initialized
INFO - 2018-07-31 22:32:21 --> Controller Class Initialized
DEBUG - 2018-07-31 22:32:21 --> UTF-8 Support Enabled
DEBUG - 2018-07-31 22:32:21 --> Home MX_Controller Initialized
INFO - 2018-07-31 22:32:21 --> Utf8 Class Initialized
DEBUG - 2018-07-31 22:32:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-07-31 22:32:21 --> URI Class Initialized
DEBUG - 2018-07-31 22:32:21 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-31 22:32:21 --> Login MX_Controller Initialized
INFO - 2018-07-31 22:32:21 --> Language file loaded: language/english/data_lang.php
INFO - 2018-07-31 22:32:21 --> Router Class Initialized
DEBUG - 2018-07-31 22:32:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-31 22:32:21 --> Output Class Initialized
DEBUG - 2018-07-31 22:32:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-31 22:32:21 --> Security Class Initialized
DEBUG - 2018-07-31 22:32:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 22:32:21 --> Input Class Initialized
INFO - 2018-07-31 22:32:21 --> Language Class Initialized
ERROR - 2018-07-31 22:32:21 --> 404 Page Not Found: /index
INFO - 2018-07-31 22:32:42 --> Config Class Initialized
INFO - 2018-07-31 22:32:42 --> Hooks Class Initialized
DEBUG - 2018-07-31 22:32:42 --> UTF-8 Support Enabled
INFO - 2018-07-31 22:32:42 --> Utf8 Class Initialized
INFO - 2018-07-31 22:32:42 --> URI Class Initialized
INFO - 2018-07-31 22:32:42 --> Router Class Initialized
INFO - 2018-07-31 22:32:42 --> Output Class Initialized
INFO - 2018-07-31 22:32:42 --> Security Class Initialized
DEBUG - 2018-07-31 22:32:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 22:32:42 --> Input Class Initialized
INFO - 2018-07-31 22:32:42 --> Language Class Initialized
INFO - 2018-07-31 22:32:42 --> Language Class Initialized
INFO - 2018-07-31 22:32:42 --> Config Class Initialized
INFO - 2018-07-31 22:32:42 --> Loader Class Initialized
DEBUG - 2018-07-31 22:32:42 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-31 22:32:42 --> Helper loaded: url_helper
INFO - 2018-07-31 22:32:42 --> Helper loaded: form_helper
INFO - 2018-07-31 22:32:42 --> Helper loaded: date_helper
INFO - 2018-07-31 22:32:42 --> Helper loaded: util_helper
INFO - 2018-07-31 22:32:42 --> Helper loaded: text_helper
INFO - 2018-07-31 22:32:42 --> Helper loaded: string_helper
INFO - 2018-07-31 22:32:42 --> Database Driver Class Initialized
DEBUG - 2018-07-31 22:32:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 22:32:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 22:32:42 --> Email Class Initialized
INFO - 2018-07-31 22:32:42 --> Controller Class Initialized
DEBUG - 2018-07-31 22:32:42 --> Programs MX_Controller Initialized
INFO - 2018-07-31 22:32:42 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-31 22:32:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-07-31 22:32:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-31 22:32:42 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-31 22:32:42 --> Login MX_Controller Initialized
DEBUG - 2018-07-31 22:32:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-31 22:32:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-31 22:32:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-31 22:32:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-31 22:32:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-31 22:32:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-31 22:32:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/programs/create_program.php
INFO - 2018-07-31 22:32:42 --> Final output sent to browser
DEBUG - 2018-07-31 22:32:43 --> Total execution time: 0.7556
INFO - 2018-07-31 22:32:47 --> Config Class Initialized
INFO - 2018-07-31 22:32:47 --> Hooks Class Initialized
DEBUG - 2018-07-31 22:32:47 --> UTF-8 Support Enabled
INFO - 2018-07-31 22:32:47 --> Utf8 Class Initialized
INFO - 2018-07-31 22:32:47 --> URI Class Initialized
INFO - 2018-07-31 22:32:47 --> Router Class Initialized
INFO - 2018-07-31 22:32:47 --> Output Class Initialized
INFO - 2018-07-31 22:32:47 --> Security Class Initialized
DEBUG - 2018-07-31 22:32:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 22:32:47 --> Input Class Initialized
INFO - 2018-07-31 22:32:47 --> Language Class Initialized
INFO - 2018-07-31 22:32:47 --> Language Class Initialized
INFO - 2018-07-31 22:32:47 --> Config Class Initialized
INFO - 2018-07-31 22:32:47 --> Loader Class Initialized
DEBUG - 2018-07-31 22:32:48 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-31 22:32:48 --> Helper loaded: url_helper
INFO - 2018-07-31 22:32:48 --> Helper loaded: form_helper
INFO - 2018-07-31 22:32:48 --> Helper loaded: date_helper
INFO - 2018-07-31 22:32:48 --> Helper loaded: util_helper
INFO - 2018-07-31 22:32:48 --> Helper loaded: text_helper
INFO - 2018-07-31 22:32:48 --> Helper loaded: string_helper
INFO - 2018-07-31 22:32:48 --> Database Driver Class Initialized
DEBUG - 2018-07-31 22:32:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 22:32:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 22:32:48 --> Email Class Initialized
INFO - 2018-07-31 22:32:48 --> Controller Class Initialized
DEBUG - 2018-07-31 22:32:48 --> Programs MX_Controller Initialized
INFO - 2018-07-31 22:32:48 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-31 22:32:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-07-31 22:32:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-31 22:32:48 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-31 22:32:48 --> Login MX_Controller Initialized
DEBUG - 2018-07-31 22:32:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-31 22:32:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
INFO - 2018-07-31 22:32:48 --> Upload Class Initialized
INFO - 2018-07-31 22:32:48 --> Config Class Initialized
INFO - 2018-07-31 22:32:48 --> Hooks Class Initialized
DEBUG - 2018-07-31 22:32:48 --> UTF-8 Support Enabled
INFO - 2018-07-31 22:32:48 --> Utf8 Class Initialized
INFO - 2018-07-31 22:32:48 --> URI Class Initialized
INFO - 2018-07-31 22:32:48 --> Router Class Initialized
INFO - 2018-07-31 22:32:48 --> Output Class Initialized
INFO - 2018-07-31 22:32:48 --> Security Class Initialized
DEBUG - 2018-07-31 22:32:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 22:32:48 --> Input Class Initialized
INFO - 2018-07-31 22:32:48 --> Language Class Initialized
INFO - 2018-07-31 22:32:48 --> Language Class Initialized
INFO - 2018-07-31 22:32:48 --> Config Class Initialized
INFO - 2018-07-31 22:32:48 --> Loader Class Initialized
DEBUG - 2018-07-31 22:32:48 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-31 22:32:48 --> Helper loaded: url_helper
INFO - 2018-07-31 22:32:48 --> Helper loaded: form_helper
INFO - 2018-07-31 22:32:48 --> Helper loaded: date_helper
INFO - 2018-07-31 22:32:48 --> Helper loaded: util_helper
INFO - 2018-07-31 22:32:48 --> Helper loaded: text_helper
INFO - 2018-07-31 22:32:48 --> Helper loaded: string_helper
INFO - 2018-07-31 22:32:48 --> Database Driver Class Initialized
DEBUG - 2018-07-31 22:32:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 22:32:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 22:32:48 --> Email Class Initialized
INFO - 2018-07-31 22:32:49 --> Controller Class Initialized
DEBUG - 2018-07-31 22:32:49 --> Programs MX_Controller Initialized
INFO - 2018-07-31 22:32:49 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-31 22:32:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-07-31 22:32:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-31 22:32:49 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-31 22:32:49 --> Login MX_Controller Initialized
DEBUG - 2018-07-31 22:32:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-31 22:32:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-31 22:32:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-31 22:32:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-31 22:32:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-31 22:32:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-31 22:32:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/programs/programs.php
INFO - 2018-07-31 22:32:49 --> Final output sent to browser
DEBUG - 2018-07-31 22:32:49 --> Total execution time: 0.8596
INFO - 2018-07-31 22:32:49 --> Config Class Initialized
INFO - 2018-07-31 22:32:49 --> Hooks Class Initialized
DEBUG - 2018-07-31 22:32:49 --> UTF-8 Support Enabled
INFO - 2018-07-31 22:32:49 --> Utf8 Class Initialized
INFO - 2018-07-31 22:32:49 --> URI Class Initialized
INFO - 2018-07-31 22:32:49 --> Router Class Initialized
INFO - 2018-07-31 22:32:49 --> Output Class Initialized
INFO - 2018-07-31 22:32:49 --> Security Class Initialized
DEBUG - 2018-07-31 22:32:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 22:32:49 --> Input Class Initialized
INFO - 2018-07-31 22:32:49 --> Language Class Initialized
INFO - 2018-07-31 22:32:50 --> Language Class Initialized
INFO - 2018-07-31 22:32:50 --> Config Class Initialized
INFO - 2018-07-31 22:32:50 --> Loader Class Initialized
DEBUG - 2018-07-31 22:32:50 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-31 22:32:50 --> Helper loaded: url_helper
INFO - 2018-07-31 22:32:50 --> Helper loaded: form_helper
INFO - 2018-07-31 22:32:50 --> Helper loaded: date_helper
INFO - 2018-07-31 22:32:50 --> Helper loaded: util_helper
INFO - 2018-07-31 22:32:50 --> Helper loaded: text_helper
INFO - 2018-07-31 22:32:50 --> Helper loaded: string_helper
INFO - 2018-07-31 22:32:50 --> Database Driver Class Initialized
DEBUG - 2018-07-31 22:32:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 22:32:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 22:32:50 --> Email Class Initialized
INFO - 2018-07-31 22:32:50 --> Controller Class Initialized
DEBUG - 2018-07-31 22:32:50 --> Programs MX_Controller Initialized
INFO - 2018-07-31 22:32:50 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-31 22:32:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-07-31 22:32:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-31 22:32:50 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
INFO - 2018-07-31 22:32:50 --> Config Class Initialized
INFO - 2018-07-31 22:32:50 --> Hooks Class Initialized
DEBUG - 2018-07-31 22:32:50 --> Login MX_Controller Initialized
DEBUG - 2018-07-31 22:32:50 --> UTF-8 Support Enabled
DEBUG - 2018-07-31 22:32:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-31 22:32:50 --> Utf8 Class Initialized
INFO - 2018-07-31 22:32:50 --> URI Class Initialized
INFO - 2018-07-31 22:32:50 --> Router Class Initialized
INFO - 2018-07-31 22:32:50 --> Output Class Initialized
INFO - 2018-07-31 22:32:50 --> Final output sent to browser
DEBUG - 2018-07-31 22:32:50 --> Total execution time: 0.8098
INFO - 2018-07-31 22:32:50 --> Security Class Initialized
DEBUG - 2018-07-31 22:32:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 22:32:50 --> Input Class Initialized
INFO - 2018-07-31 22:32:50 --> Language Class Initialized
INFO - 2018-07-31 22:32:50 --> Language Class Initialized
INFO - 2018-07-31 22:32:50 --> Config Class Initialized
INFO - 2018-07-31 22:32:50 --> Loader Class Initialized
DEBUG - 2018-07-31 22:32:50 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-31 22:32:50 --> Helper loaded: url_helper
INFO - 2018-07-31 22:32:50 --> Helper loaded: form_helper
INFO - 2018-07-31 22:32:50 --> Helper loaded: date_helper
INFO - 2018-07-31 22:32:50 --> Helper loaded: util_helper
INFO - 2018-07-31 22:32:50 --> Helper loaded: text_helper
INFO - 2018-07-31 22:32:50 --> Helper loaded: string_helper
INFO - 2018-07-31 22:32:50 --> Database Driver Class Initialized
DEBUG - 2018-07-31 22:32:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 22:32:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 22:32:50 --> Email Class Initialized
INFO - 2018-07-31 22:32:50 --> Controller Class Initialized
DEBUG - 2018-07-31 22:32:50 --> Home MX_Controller Initialized
DEBUG - 2018-07-31 22:32:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-31 22:32:51 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-31 22:32:51 --> Login MX_Controller Initialized
INFO - 2018-07-31 22:32:51 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-31 22:32:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-31 22:32:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-31 22:32:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-07-31 22:32:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-07-31 22:32:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-07-31 22:32:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-07-31 22:32:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-07-31 22:32:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-07-31 22:32:51 --> Final output sent to browser
DEBUG - 2018-07-31 22:32:51 --> Total execution time: 0.7879
INFO - 2018-07-31 22:32:51 --> Config Class Initialized
INFO - 2018-07-31 22:32:51 --> Hooks Class Initialized
INFO - 2018-07-31 22:32:51 --> Config Class Initialized
DEBUG - 2018-07-31 22:32:51 --> UTF-8 Support Enabled
INFO - 2018-07-31 22:32:51 --> Hooks Class Initialized
DEBUG - 2018-07-31 22:32:51 --> UTF-8 Support Enabled
INFO - 2018-07-31 22:32:51 --> Utf8 Class Initialized
INFO - 2018-07-31 22:32:51 --> Utf8 Class Initialized
INFO - 2018-07-31 22:32:51 --> URI Class Initialized
INFO - 2018-07-31 22:32:51 --> Router Class Initialized
INFO - 2018-07-31 22:32:51 --> URI Class Initialized
INFO - 2018-07-31 22:32:51 --> Output Class Initialized
INFO - 2018-07-31 22:32:51 --> Router Class Initialized
INFO - 2018-07-31 22:32:51 --> Output Class Initialized
INFO - 2018-07-31 22:32:51 --> Security Class Initialized
INFO - 2018-07-31 22:32:51 --> Security Class Initialized
DEBUG - 2018-07-31 22:32:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-07-31 22:32:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 22:32:51 --> Input Class Initialized
INFO - 2018-07-31 22:32:51 --> Input Class Initialized
INFO - 2018-07-31 22:32:51 --> Language Class Initialized
INFO - 2018-07-31 22:32:51 --> Language Class Initialized
INFO - 2018-07-31 22:32:51 --> Language Class Initialized
INFO - 2018-07-31 22:32:51 --> Config Class Initialized
ERROR - 2018-07-31 22:32:51 --> 404 Page Not Found: /index
INFO - 2018-07-31 22:32:52 --> Loader Class Initialized
INFO - 2018-07-31 22:32:52 --> Config Class Initialized
INFO - 2018-07-31 22:32:52 --> Hooks Class Initialized
DEBUG - 2018-07-31 22:32:52 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
DEBUG - 2018-07-31 22:32:52 --> UTF-8 Support Enabled
INFO - 2018-07-31 22:32:52 --> Helper loaded: url_helper
INFO - 2018-07-31 22:32:52 --> Utf8 Class Initialized
INFO - 2018-07-31 22:32:52 --> Helper loaded: form_helper
INFO - 2018-07-31 22:32:52 --> URI Class Initialized
INFO - 2018-07-31 22:32:52 --> Helper loaded: date_helper
INFO - 2018-07-31 22:32:52 --> Router Class Initialized
INFO - 2018-07-31 22:32:52 --> Helper loaded: util_helper
INFO - 2018-07-31 22:32:52 --> Output Class Initialized
INFO - 2018-07-31 22:32:52 --> Helper loaded: text_helper
INFO - 2018-07-31 22:32:52 --> Security Class Initialized
DEBUG - 2018-07-31 22:32:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 22:32:52 --> Helper loaded: string_helper
INFO - 2018-07-31 22:32:52 --> Input Class Initialized
INFO - 2018-07-31 22:32:52 --> Database Driver Class Initialized
INFO - 2018-07-31 22:32:52 --> Language Class Initialized
DEBUG - 2018-07-31 22:32:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 22:32:52 --> Session: Class initialized using 'files' driver.
ERROR - 2018-07-31 22:32:52 --> 404 Page Not Found: /index
INFO - 2018-07-31 22:32:52 --> Email Class Initialized
INFO - 2018-07-31 22:32:52 --> Config Class Initialized
INFO - 2018-07-31 22:32:52 --> Hooks Class Initialized
INFO - 2018-07-31 22:32:52 --> Controller Class Initialized
DEBUG - 2018-07-31 22:32:52 --> Home MX_Controller Initialized
DEBUG - 2018-07-31 22:32:52 --> UTF-8 Support Enabled
INFO - 2018-07-31 22:32:52 --> Utf8 Class Initialized
DEBUG - 2018-07-31 22:32:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-07-31 22:32:52 --> URI Class Initialized
DEBUG - 2018-07-31 22:32:52 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-31 22:32:52 --> Login MX_Controller Initialized
INFO - 2018-07-31 22:32:52 --> Router Class Initialized
INFO - 2018-07-31 22:32:52 --> Language file loaded: language/english/data_lang.php
INFO - 2018-07-31 22:32:52 --> Output Class Initialized
DEBUG - 2018-07-31 22:32:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-31 22:32:52 --> Security Class Initialized
DEBUG - 2018-07-31 22:32:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-31 22:32:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 22:32:52 --> Input Class Initialized
INFO - 2018-07-31 22:32:52 --> Language Class Initialized
ERROR - 2018-07-31 22:32:52 --> 404 Page Not Found: /index
INFO - 2018-07-31 22:33:01 --> Config Class Initialized
INFO - 2018-07-31 22:33:01 --> Hooks Class Initialized
DEBUG - 2018-07-31 22:33:01 --> UTF-8 Support Enabled
INFO - 2018-07-31 22:33:01 --> Utf8 Class Initialized
INFO - 2018-07-31 22:33:01 --> URI Class Initialized
INFO - 2018-07-31 22:33:01 --> Router Class Initialized
INFO - 2018-07-31 22:33:01 --> Output Class Initialized
INFO - 2018-07-31 22:33:01 --> Security Class Initialized
DEBUG - 2018-07-31 22:33:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 22:33:02 --> Input Class Initialized
INFO - 2018-07-31 22:33:02 --> Language Class Initialized
INFO - 2018-07-31 22:33:02 --> Language Class Initialized
INFO - 2018-07-31 22:33:02 --> Config Class Initialized
INFO - 2018-07-31 22:33:02 --> Loader Class Initialized
DEBUG - 2018-07-31 22:33:02 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-31 22:33:02 --> Helper loaded: url_helper
INFO - 2018-07-31 22:33:02 --> Helper loaded: form_helper
INFO - 2018-07-31 22:33:02 --> Helper loaded: date_helper
INFO - 2018-07-31 22:33:02 --> Helper loaded: util_helper
INFO - 2018-07-31 22:33:02 --> Helper loaded: text_helper
INFO - 2018-07-31 22:33:02 --> Helper loaded: string_helper
INFO - 2018-07-31 22:33:02 --> Database Driver Class Initialized
DEBUG - 2018-07-31 22:33:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 22:33:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 22:33:02 --> Email Class Initialized
INFO - 2018-07-31 22:33:02 --> Controller Class Initialized
DEBUG - 2018-07-31 22:33:02 --> Programs MX_Controller Initialized
INFO - 2018-07-31 22:33:02 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-31 22:33:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-07-31 22:33:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-31 22:33:02 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-31 22:33:02 --> Login MX_Controller Initialized
DEBUG - 2018-07-31 22:33:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-31 22:33:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-31 22:33:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-31 22:33:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-31 22:33:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-31 22:33:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-31 22:33:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/programs/create_program.php
INFO - 2018-07-31 22:33:02 --> Final output sent to browser
DEBUG - 2018-07-31 22:33:02 --> Total execution time: 0.8141
INFO - 2018-07-31 22:33:15 --> Config Class Initialized
INFO - 2018-07-31 22:33:15 --> Hooks Class Initialized
DEBUG - 2018-07-31 22:33:15 --> UTF-8 Support Enabled
INFO - 2018-07-31 22:33:15 --> Utf8 Class Initialized
INFO - 2018-07-31 22:33:15 --> URI Class Initialized
INFO - 2018-07-31 22:33:15 --> Router Class Initialized
INFO - 2018-07-31 22:33:15 --> Output Class Initialized
INFO - 2018-07-31 22:33:15 --> Security Class Initialized
DEBUG - 2018-07-31 22:33:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 22:33:15 --> Input Class Initialized
INFO - 2018-07-31 22:33:15 --> Language Class Initialized
INFO - 2018-07-31 22:33:15 --> Language Class Initialized
INFO - 2018-07-31 22:33:15 --> Config Class Initialized
INFO - 2018-07-31 22:33:15 --> Loader Class Initialized
DEBUG - 2018-07-31 22:33:15 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-31 22:33:15 --> Helper loaded: url_helper
INFO - 2018-07-31 22:33:15 --> Helper loaded: form_helper
INFO - 2018-07-31 22:33:15 --> Helper loaded: date_helper
INFO - 2018-07-31 22:33:15 --> Helper loaded: util_helper
INFO - 2018-07-31 22:33:15 --> Helper loaded: text_helper
INFO - 2018-07-31 22:33:15 --> Helper loaded: string_helper
INFO - 2018-07-31 22:33:15 --> Database Driver Class Initialized
DEBUG - 2018-07-31 22:33:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 22:33:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 22:33:15 --> Email Class Initialized
INFO - 2018-07-31 22:33:15 --> Controller Class Initialized
DEBUG - 2018-07-31 22:33:15 --> Programs MX_Controller Initialized
INFO - 2018-07-31 22:33:15 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-31 22:33:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-07-31 22:33:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-31 22:33:15 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-31 22:33:15 --> Login MX_Controller Initialized
DEBUG - 2018-07-31 22:33:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-31 22:33:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
INFO - 2018-07-31 22:33:15 --> Upload Class Initialized
INFO - 2018-07-31 22:33:16 --> Config Class Initialized
INFO - 2018-07-31 22:33:16 --> Hooks Class Initialized
DEBUG - 2018-07-31 22:33:16 --> UTF-8 Support Enabled
INFO - 2018-07-31 22:33:16 --> Utf8 Class Initialized
INFO - 2018-07-31 22:33:16 --> URI Class Initialized
INFO - 2018-07-31 22:33:16 --> Router Class Initialized
INFO - 2018-07-31 22:33:16 --> Output Class Initialized
INFO - 2018-07-31 22:33:16 --> Security Class Initialized
DEBUG - 2018-07-31 22:33:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 22:33:16 --> Input Class Initialized
INFO - 2018-07-31 22:33:16 --> Language Class Initialized
INFO - 2018-07-31 22:33:16 --> Language Class Initialized
INFO - 2018-07-31 22:33:16 --> Config Class Initialized
INFO - 2018-07-31 22:33:16 --> Loader Class Initialized
DEBUG - 2018-07-31 22:33:16 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-31 22:33:16 --> Helper loaded: url_helper
INFO - 2018-07-31 22:33:16 --> Helper loaded: form_helper
INFO - 2018-07-31 22:33:16 --> Helper loaded: date_helper
INFO - 2018-07-31 22:33:16 --> Helper loaded: util_helper
INFO - 2018-07-31 22:33:16 --> Helper loaded: text_helper
INFO - 2018-07-31 22:33:16 --> Helper loaded: string_helper
INFO - 2018-07-31 22:33:16 --> Database Driver Class Initialized
DEBUG - 2018-07-31 22:33:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 22:33:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 22:33:16 --> Email Class Initialized
INFO - 2018-07-31 22:33:16 --> Controller Class Initialized
DEBUG - 2018-07-31 22:33:16 --> Programs MX_Controller Initialized
INFO - 2018-07-31 22:33:16 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-31 22:33:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-07-31 22:33:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-31 22:33:16 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-31 22:33:16 --> Login MX_Controller Initialized
DEBUG - 2018-07-31 22:33:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-31 22:33:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-31 22:33:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-31 22:33:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-31 22:33:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-31 22:33:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-31 22:33:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/programs/programs.php
INFO - 2018-07-31 22:33:17 --> Final output sent to browser
DEBUG - 2018-07-31 22:33:17 --> Total execution time: 0.9476
INFO - 2018-07-31 22:33:17 --> Config Class Initialized
INFO - 2018-07-31 22:33:17 --> Hooks Class Initialized
DEBUG - 2018-07-31 22:33:17 --> UTF-8 Support Enabled
INFO - 2018-07-31 22:33:17 --> Utf8 Class Initialized
INFO - 2018-07-31 22:33:17 --> URI Class Initialized
INFO - 2018-07-31 22:33:17 --> Router Class Initialized
INFO - 2018-07-31 22:33:17 --> Output Class Initialized
INFO - 2018-07-31 22:33:17 --> Security Class Initialized
DEBUG - 2018-07-31 22:33:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 22:33:17 --> Input Class Initialized
INFO - 2018-07-31 22:33:17 --> Language Class Initialized
INFO - 2018-07-31 22:33:17 --> Language Class Initialized
INFO - 2018-07-31 22:33:17 --> Config Class Initialized
INFO - 2018-07-31 22:33:17 --> Loader Class Initialized
DEBUG - 2018-07-31 22:33:17 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-31 22:33:17 --> Helper loaded: url_helper
INFO - 2018-07-31 22:33:17 --> Helper loaded: form_helper
INFO - 2018-07-31 22:33:17 --> Helper loaded: date_helper
INFO - 2018-07-31 22:33:17 --> Helper loaded: util_helper
INFO - 2018-07-31 22:33:17 --> Helper loaded: text_helper
INFO - 2018-07-31 22:33:17 --> Helper loaded: string_helper
INFO - 2018-07-31 22:33:17 --> Database Driver Class Initialized
DEBUG - 2018-07-31 22:33:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 22:33:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 22:33:18 --> Email Class Initialized
INFO - 2018-07-31 22:33:18 --> Controller Class Initialized
DEBUG - 2018-07-31 22:33:18 --> Programs MX_Controller Initialized
INFO - 2018-07-31 22:33:18 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-31 22:33:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-07-31 22:33:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-31 22:33:18 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-31 22:33:18 --> Login MX_Controller Initialized
DEBUG - 2018-07-31 22:33:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-31 22:33:18 --> Final output sent to browser
DEBUG - 2018-07-31 22:33:18 --> Total execution time: 0.6908
INFO - 2018-07-31 22:34:24 --> Config Class Initialized
INFO - 2018-07-31 22:34:24 --> Hooks Class Initialized
DEBUG - 2018-07-31 22:34:24 --> UTF-8 Support Enabled
INFO - 2018-07-31 22:34:24 --> Utf8 Class Initialized
INFO - 2018-07-31 22:34:24 --> URI Class Initialized
INFO - 2018-07-31 22:34:24 --> Router Class Initialized
INFO - 2018-07-31 22:34:24 --> Output Class Initialized
INFO - 2018-07-31 22:34:24 --> Security Class Initialized
DEBUG - 2018-07-31 22:34:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 22:34:24 --> Input Class Initialized
INFO - 2018-07-31 22:34:24 --> Language Class Initialized
INFO - 2018-07-31 22:34:24 --> Language Class Initialized
INFO - 2018-07-31 22:34:24 --> Config Class Initialized
INFO - 2018-07-31 22:34:24 --> Loader Class Initialized
DEBUG - 2018-07-31 22:34:24 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-31 22:34:24 --> Helper loaded: url_helper
INFO - 2018-07-31 22:34:24 --> Helper loaded: form_helper
INFO - 2018-07-31 22:34:24 --> Helper loaded: date_helper
INFO - 2018-07-31 22:34:24 --> Helper loaded: util_helper
INFO - 2018-07-31 22:34:24 --> Helper loaded: text_helper
INFO - 2018-07-31 22:34:24 --> Helper loaded: string_helper
INFO - 2018-07-31 22:34:24 --> Database Driver Class Initialized
DEBUG - 2018-07-31 22:34:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 22:34:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 22:34:24 --> Email Class Initialized
INFO - 2018-07-31 22:34:25 --> Controller Class Initialized
DEBUG - 2018-07-31 22:34:25 --> Home MX_Controller Initialized
DEBUG - 2018-07-31 22:34:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-31 22:34:25 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-31 22:34:25 --> Login MX_Controller Initialized
INFO - 2018-07-31 22:34:25 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-31 22:34:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-31 22:34:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-31 22:34:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-07-31 22:34:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-07-31 22:34:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-07-31 22:34:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-07-31 22:34:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-07-31 22:34:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-07-31 22:34:25 --> Final output sent to browser
DEBUG - 2018-07-31 22:34:25 --> Total execution time: 0.7844
INFO - 2018-07-31 22:34:25 --> Config Class Initialized
INFO - 2018-07-31 22:34:25 --> Hooks Class Initialized
INFO - 2018-07-31 22:34:25 --> Config Class Initialized
INFO - 2018-07-31 22:34:25 --> Hooks Class Initialized
DEBUG - 2018-07-31 22:34:25 --> UTF-8 Support Enabled
DEBUG - 2018-07-31 22:34:25 --> UTF-8 Support Enabled
INFO - 2018-07-31 22:34:25 --> Utf8 Class Initialized
INFO - 2018-07-31 22:34:25 --> URI Class Initialized
INFO - 2018-07-31 22:34:25 --> Router Class Initialized
INFO - 2018-07-31 22:34:25 --> Output Class Initialized
INFO - 2018-07-31 22:34:25 --> Security Class Initialized
DEBUG - 2018-07-31 22:34:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 22:34:26 --> Utf8 Class Initialized
INFO - 2018-07-31 22:34:26 --> Input Class Initialized
INFO - 2018-07-31 22:34:26 --> Language Class Initialized
INFO - 2018-07-31 22:34:26 --> URI Class Initialized
INFO - 2018-07-31 22:34:26 --> Router Class Initialized
INFO - 2018-07-31 22:34:26 --> Language Class Initialized
INFO - 2018-07-31 22:34:26 --> Config Class Initialized
INFO - 2018-07-31 22:34:26 --> Output Class Initialized
INFO - 2018-07-31 22:34:26 --> Loader Class Initialized
DEBUG - 2018-07-31 22:34:26 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-31 22:34:26 --> Helper loaded: url_helper
INFO - 2018-07-31 22:34:26 --> Security Class Initialized
INFO - 2018-07-31 22:34:26 --> Helper loaded: form_helper
INFO - 2018-07-31 22:34:26 --> Helper loaded: date_helper
DEBUG - 2018-07-31 22:34:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 22:34:26 --> Input Class Initialized
INFO - 2018-07-31 22:34:26 --> Helper loaded: util_helper
INFO - 2018-07-31 22:34:26 --> Language Class Initialized
ERROR - 2018-07-31 22:34:26 --> 404 Page Not Found: /index
INFO - 2018-07-31 22:34:26 --> Helper loaded: text_helper
INFO - 2018-07-31 22:34:26 --> Config Class Initialized
INFO - 2018-07-31 22:34:26 --> Hooks Class Initialized
INFO - 2018-07-31 22:34:26 --> Helper loaded: string_helper
INFO - 2018-07-31 22:34:26 --> Database Driver Class Initialized
DEBUG - 2018-07-31 22:34:26 --> UTF-8 Support Enabled
INFO - 2018-07-31 22:34:26 --> Utf8 Class Initialized
INFO - 2018-07-31 22:34:26 --> URI Class Initialized
DEBUG - 2018-07-31 22:34:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 22:34:26 --> Router Class Initialized
INFO - 2018-07-31 22:34:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 22:34:26 --> Email Class Initialized
INFO - 2018-07-31 22:34:26 --> Controller Class Initialized
INFO - 2018-07-31 22:34:26 --> Output Class Initialized
DEBUG - 2018-07-31 22:34:26 --> Home MX_Controller Initialized
INFO - 2018-07-31 22:34:26 --> Security Class Initialized
DEBUG - 2018-07-31 22:34:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-31 22:34:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 22:34:26 --> Input Class Initialized
DEBUG - 2018-07-31 22:34:26 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-31 22:34:26 --> Login MX_Controller Initialized
INFO - 2018-07-31 22:34:26 --> Language Class Initialized
INFO - 2018-07-31 22:34:26 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-31 22:34:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-31 22:34:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
ERROR - 2018-07-31 22:34:27 --> 404 Page Not Found: /index
INFO - 2018-07-31 22:34:27 --> Config Class Initialized
INFO - 2018-07-31 22:34:27 --> Hooks Class Initialized
DEBUG - 2018-07-31 22:34:27 --> UTF-8 Support Enabled
INFO - 2018-07-31 22:34:27 --> Utf8 Class Initialized
INFO - 2018-07-31 22:34:27 --> URI Class Initialized
INFO - 2018-07-31 22:34:27 --> Router Class Initialized
INFO - 2018-07-31 22:34:27 --> Output Class Initialized
INFO - 2018-07-31 22:34:27 --> Security Class Initialized
DEBUG - 2018-07-31 22:34:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 22:34:27 --> Input Class Initialized
INFO - 2018-07-31 22:34:27 --> Language Class Initialized
ERROR - 2018-07-31 22:34:27 --> 404 Page Not Found: /index
INFO - 2018-07-31 22:40:10 --> Config Class Initialized
INFO - 2018-07-31 22:40:10 --> Hooks Class Initialized
DEBUG - 2018-07-31 22:40:10 --> UTF-8 Support Enabled
INFO - 2018-07-31 22:40:10 --> Utf8 Class Initialized
INFO - 2018-07-31 22:40:10 --> URI Class Initialized
INFO - 2018-07-31 22:40:10 --> Router Class Initialized
INFO - 2018-07-31 22:40:10 --> Output Class Initialized
INFO - 2018-07-31 22:40:10 --> Security Class Initialized
DEBUG - 2018-07-31 22:40:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 22:40:10 --> Input Class Initialized
INFO - 2018-07-31 22:40:10 --> Language Class Initialized
INFO - 2018-07-31 22:40:10 --> Language Class Initialized
INFO - 2018-07-31 22:40:10 --> Config Class Initialized
INFO - 2018-07-31 22:40:10 --> Loader Class Initialized
DEBUG - 2018-07-31 22:40:10 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-31 22:40:10 --> Helper loaded: url_helper
INFO - 2018-07-31 22:40:10 --> Helper loaded: form_helper
INFO - 2018-07-31 22:40:10 --> Helper loaded: date_helper
INFO - 2018-07-31 22:40:10 --> Helper loaded: util_helper
INFO - 2018-07-31 22:40:10 --> Helper loaded: text_helper
INFO - 2018-07-31 22:40:10 --> Helper loaded: string_helper
INFO - 2018-07-31 22:40:10 --> Database Driver Class Initialized
DEBUG - 2018-07-31 22:40:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 22:40:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 22:40:10 --> Email Class Initialized
INFO - 2018-07-31 22:40:10 --> Controller Class Initialized
DEBUG - 2018-07-31 22:40:10 --> Home MX_Controller Initialized
DEBUG - 2018-07-31 22:40:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-31 22:40:10 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-31 22:40:10 --> Login MX_Controller Initialized
INFO - 2018-07-31 22:40:10 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-31 22:40:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-31 22:40:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-31 22:40:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-07-31 22:40:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-07-31 22:40:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-07-31 22:40:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-07-31 22:40:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-07-31 22:40:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-07-31 22:40:11 --> Final output sent to browser
DEBUG - 2018-07-31 22:40:11 --> Total execution time: 0.8088
INFO - 2018-07-31 22:40:11 --> Config Class Initialized
INFO - 2018-07-31 22:40:11 --> Hooks Class Initialized
INFO - 2018-07-31 22:40:11 --> Config Class Initialized
INFO - 2018-07-31 22:40:11 --> Hooks Class Initialized
DEBUG - 2018-07-31 22:40:11 --> UTF-8 Support Enabled
DEBUG - 2018-07-31 22:40:11 --> UTF-8 Support Enabled
INFO - 2018-07-31 22:40:11 --> Utf8 Class Initialized
INFO - 2018-07-31 22:40:11 --> Utf8 Class Initialized
INFO - 2018-07-31 22:40:11 --> URI Class Initialized
INFO - 2018-07-31 22:40:11 --> URI Class Initialized
INFO - 2018-07-31 22:40:11 --> Router Class Initialized
INFO - 2018-07-31 22:40:11 --> Output Class Initialized
INFO - 2018-07-31 22:40:11 --> Router Class Initialized
INFO - 2018-07-31 22:40:11 --> Output Class Initialized
INFO - 2018-07-31 22:40:11 --> Security Class Initialized
DEBUG - 2018-07-31 22:40:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 22:40:11 --> Security Class Initialized
INFO - 2018-07-31 22:40:12 --> Input Class Initialized
DEBUG - 2018-07-31 22:40:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 22:40:12 --> Language Class Initialized
INFO - 2018-07-31 22:40:12 --> Input Class Initialized
ERROR - 2018-07-31 22:40:12 --> 404 Page Not Found: /index
INFO - 2018-07-31 22:40:12 --> Language Class Initialized
INFO - 2018-07-31 22:40:12 --> Config Class Initialized
INFO - 2018-07-31 22:40:12 --> Hooks Class Initialized
INFO - 2018-07-31 22:40:12 --> Language Class Initialized
INFO - 2018-07-31 22:40:12 --> Config Class Initialized
DEBUG - 2018-07-31 22:40:12 --> UTF-8 Support Enabled
INFO - 2018-07-31 22:40:12 --> Utf8 Class Initialized
INFO - 2018-07-31 22:40:12 --> Loader Class Initialized
DEBUG - 2018-07-31 22:40:12 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-31 22:40:12 --> URI Class Initialized
INFO - 2018-07-31 22:40:12 --> Helper loaded: url_helper
INFO - 2018-07-31 22:40:12 --> Router Class Initialized
INFO - 2018-07-31 22:40:12 --> Output Class Initialized
INFO - 2018-07-31 22:40:12 --> Helper loaded: form_helper
INFO - 2018-07-31 22:40:12 --> Helper loaded: date_helper
INFO - 2018-07-31 22:40:12 --> Security Class Initialized
DEBUG - 2018-07-31 22:40:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 22:40:12 --> Helper loaded: util_helper
INFO - 2018-07-31 22:40:12 --> Input Class Initialized
INFO - 2018-07-31 22:40:12 --> Language Class Initialized
INFO - 2018-07-31 22:40:12 --> Helper loaded: text_helper
ERROR - 2018-07-31 22:40:12 --> 404 Page Not Found: /index
INFO - 2018-07-31 22:40:12 --> Helper loaded: string_helper
INFO - 2018-07-31 22:40:12 --> Database Driver Class Initialized
INFO - 2018-07-31 22:40:12 --> Config Class Initialized
INFO - 2018-07-31 22:40:12 --> Hooks Class Initialized
DEBUG - 2018-07-31 22:40:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 22:40:12 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-07-31 22:40:12 --> UTF-8 Support Enabled
INFO - 2018-07-31 22:40:12 --> Utf8 Class Initialized
INFO - 2018-07-31 22:40:12 --> Email Class Initialized
INFO - 2018-07-31 22:40:12 --> URI Class Initialized
INFO - 2018-07-31 22:40:12 --> Controller Class Initialized
DEBUG - 2018-07-31 22:40:12 --> Home MX_Controller Initialized
INFO - 2018-07-31 22:40:12 --> Router Class Initialized
INFO - 2018-07-31 22:40:12 --> Output Class Initialized
DEBUG - 2018-07-31 22:40:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-07-31 22:40:12 --> Security Class Initialized
DEBUG - 2018-07-31 22:40:12 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-31 22:40:12 --> Login MX_Controller Initialized
DEBUG - 2018-07-31 22:40:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 22:40:12 --> Language file loaded: language/english/data_lang.php
INFO - 2018-07-31 22:40:12 --> Input Class Initialized
DEBUG - 2018-07-31 22:40:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-31 22:40:12 --> Language Class Initialized
ERROR - 2018-07-31 22:40:12 --> 404 Page Not Found: /index
DEBUG - 2018-07-31 22:40:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-31 22:40:12 --> Config Class Initialized
INFO - 2018-07-31 22:40:12 --> Hooks Class Initialized
DEBUG - 2018-07-31 22:40:12 --> UTF-8 Support Enabled
INFO - 2018-07-31 22:40:12 --> Utf8 Class Initialized
INFO - 2018-07-31 22:40:12 --> URI Class Initialized
INFO - 2018-07-31 22:40:12 --> Router Class Initialized
INFO - 2018-07-31 22:40:13 --> Output Class Initialized
INFO - 2018-07-31 22:40:13 --> Security Class Initialized
DEBUG - 2018-07-31 22:40:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 22:40:13 --> Input Class Initialized
INFO - 2018-07-31 22:40:13 --> Language Class Initialized
ERROR - 2018-07-31 22:40:13 --> 404 Page Not Found: /index
INFO - 2018-07-31 22:40:13 --> Config Class Initialized
INFO - 2018-07-31 22:40:13 --> Hooks Class Initialized
DEBUG - 2018-07-31 22:40:13 --> UTF-8 Support Enabled
INFO - 2018-07-31 22:40:13 --> Utf8 Class Initialized
INFO - 2018-07-31 22:40:13 --> URI Class Initialized
INFO - 2018-07-31 22:40:13 --> Router Class Initialized
INFO - 2018-07-31 22:40:13 --> Output Class Initialized
INFO - 2018-07-31 22:40:13 --> Security Class Initialized
DEBUG - 2018-07-31 22:40:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 22:40:13 --> Input Class Initialized
INFO - 2018-07-31 22:40:13 --> Language Class Initialized
ERROR - 2018-07-31 22:40:13 --> 404 Page Not Found: /index
INFO - 2018-07-31 22:40:13 --> Config Class Initialized
INFO - 2018-07-31 22:40:13 --> Hooks Class Initialized
DEBUG - 2018-07-31 22:40:13 --> UTF-8 Support Enabled
INFO - 2018-07-31 22:40:13 --> Utf8 Class Initialized
INFO - 2018-07-31 22:40:13 --> URI Class Initialized
INFO - 2018-07-31 22:40:13 --> Router Class Initialized
INFO - 2018-07-31 22:40:13 --> Output Class Initialized
INFO - 2018-07-31 22:40:13 --> Security Class Initialized
DEBUG - 2018-07-31 22:40:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 22:40:13 --> Input Class Initialized
INFO - 2018-07-31 22:40:13 --> Language Class Initialized
ERROR - 2018-07-31 22:40:13 --> 404 Page Not Found: /index
INFO - 2018-07-31 23:55:20 --> Config Class Initialized
INFO - 2018-07-31 23:55:20 --> Config Class Initialized
INFO - 2018-07-31 23:55:20 --> Hooks Class Initialized
INFO - 2018-07-31 23:55:20 --> Hooks Class Initialized
DEBUG - 2018-07-31 23:55:20 --> UTF-8 Support Enabled
DEBUG - 2018-07-31 23:55:20 --> UTF-8 Support Enabled
INFO - 2018-07-31 23:55:20 --> Utf8 Class Initialized
INFO - 2018-07-31 23:55:20 --> Utf8 Class Initialized
INFO - 2018-07-31 23:55:20 --> URI Class Initialized
INFO - 2018-07-31 23:55:20 --> URI Class Initialized
INFO - 2018-07-31 23:55:20 --> Router Class Initialized
INFO - 2018-07-31 23:55:20 --> Router Class Initialized
INFO - 2018-07-31 23:55:20 --> Output Class Initialized
INFO - 2018-07-31 23:55:20 --> Output Class Initialized
INFO - 2018-07-31 23:55:20 --> Security Class Initialized
INFO - 2018-07-31 23:55:20 --> Security Class Initialized
DEBUG - 2018-07-31 23:55:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-07-31 23:55:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 23:55:20 --> Input Class Initialized
INFO - 2018-07-31 23:55:20 --> Input Class Initialized
INFO - 2018-07-31 23:55:20 --> Language Class Initialized
INFO - 2018-07-31 23:55:20 --> Language Class Initialized
ERROR - 2018-07-31 23:55:20 --> 404 Page Not Found: /index
INFO - 2018-07-31 23:55:20 --> Config Class Initialized
INFO - 2018-07-31 23:55:20 --> Language Class Initialized
INFO - 2018-07-31 23:55:20 --> Hooks Class Initialized
DEBUG - 2018-07-31 23:55:20 --> UTF-8 Support Enabled
INFO - 2018-07-31 23:55:20 --> Utf8 Class Initialized
INFO - 2018-07-31 23:55:20 --> URI Class Initialized
INFO - 2018-07-31 23:55:20 --> Config Class Initialized
INFO - 2018-07-31 23:55:20 --> Router Class Initialized
INFO - 2018-07-31 23:55:20 --> Output Class Initialized
INFO - 2018-07-31 23:55:20 --> Security Class Initialized
INFO - 2018-07-31 23:55:20 --> Loader Class Initialized
DEBUG - 2018-07-31 23:55:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 23:55:20 --> Input Class Initialized
DEBUG - 2018-07-31 23:55:20 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-31 23:55:20 --> Language Class Initialized
ERROR - 2018-07-31 23:55:20 --> 404 Page Not Found: /index
INFO - 2018-07-31 23:55:20 --> Helper loaded: url_helper
INFO - 2018-07-31 23:55:20 --> Config Class Initialized
INFO - 2018-07-31 23:55:20 --> Helper loaded: form_helper
INFO - 2018-07-31 23:55:20 --> Hooks Class Initialized
DEBUG - 2018-07-31 23:55:20 --> UTF-8 Support Enabled
INFO - 2018-07-31 23:55:20 --> Helper loaded: date_helper
INFO - 2018-07-31 23:55:20 --> Utf8 Class Initialized
INFO - 2018-07-31 23:55:21 --> URI Class Initialized
INFO - 2018-07-31 23:55:21 --> Helper loaded: util_helper
INFO - 2018-07-31 23:55:21 --> Router Class Initialized
INFO - 2018-07-31 23:55:21 --> Output Class Initialized
INFO - 2018-07-31 23:55:21 --> Helper loaded: text_helper
INFO - 2018-07-31 23:55:21 --> Security Class Initialized
INFO - 2018-07-31 23:55:21 --> Helper loaded: string_helper
DEBUG - 2018-07-31 23:55:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 23:55:21 --> Input Class Initialized
INFO - 2018-07-31 23:55:21 --> Language Class Initialized
ERROR - 2018-07-31 23:55:21 --> 404 Page Not Found: /index
INFO - 2018-07-31 23:55:21 --> Database Driver Class Initialized
DEBUG - 2018-07-31 23:55:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 23:55:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 23:55:21 --> Email Class Initialized
INFO - 2018-07-31 23:55:21 --> Controller Class Initialized
DEBUG - 2018-07-31 23:55:21 --> Home MX_Controller Initialized
DEBUG - 2018-07-31 23:55:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-31 23:55:21 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-31 23:55:21 --> Login MX_Controller Initialized
INFO - 2018-07-31 23:55:21 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-31 23:55:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-31 23:55:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-31 23:55:33 --> Config Class Initialized
INFO - 2018-07-31 23:55:33 --> Hooks Class Initialized
DEBUG - 2018-07-31 23:55:33 --> UTF-8 Support Enabled
INFO - 2018-07-31 23:55:33 --> Utf8 Class Initialized
INFO - 2018-07-31 23:55:33 --> URI Class Initialized
INFO - 2018-07-31 23:55:33 --> Router Class Initialized
INFO - 2018-07-31 23:55:33 --> Output Class Initialized
INFO - 2018-07-31 23:55:33 --> Security Class Initialized
DEBUG - 2018-07-31 23:55:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 23:55:33 --> Input Class Initialized
INFO - 2018-07-31 23:55:33 --> Language Class Initialized
INFO - 2018-07-31 23:55:33 --> Language Class Initialized
INFO - 2018-07-31 23:55:33 --> Config Class Initialized
INFO - 2018-07-31 23:55:33 --> Loader Class Initialized
DEBUG - 2018-07-31 23:55:33 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-31 23:55:33 --> Helper loaded: url_helper
INFO - 2018-07-31 23:55:33 --> Helper loaded: form_helper
INFO - 2018-07-31 23:55:33 --> Helper loaded: date_helper
INFO - 2018-07-31 23:55:33 --> Helper loaded: util_helper
INFO - 2018-07-31 23:55:33 --> Helper loaded: text_helper
INFO - 2018-07-31 23:55:33 --> Helper loaded: string_helper
INFO - 2018-07-31 23:55:33 --> Database Driver Class Initialized
DEBUG - 2018-07-31 23:55:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 23:55:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 23:55:33 --> Email Class Initialized
INFO - 2018-07-31 23:55:33 --> Controller Class Initialized
DEBUG - 2018-07-31 23:55:33 --> Programs MX_Controller Initialized
INFO - 2018-07-31 23:55:33 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-31 23:55:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-07-31 23:55:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-31 23:55:33 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-31 23:55:33 --> Login MX_Controller Initialized
DEBUG - 2018-07-31 23:55:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-31 23:55:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-31 23:55:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-31 23:55:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-31 23:55:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-31 23:55:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-31 23:55:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/programs/create_program.php
INFO - 2018-07-31 23:55:34 --> Final output sent to browser
DEBUG - 2018-07-31 23:55:34 --> Total execution time: 1.0170
INFO - 2018-07-31 23:57:34 --> Config Class Initialized
INFO - 2018-07-31 23:57:34 --> Hooks Class Initialized
DEBUG - 2018-07-31 23:57:34 --> UTF-8 Support Enabled
INFO - 2018-07-31 23:57:34 --> Utf8 Class Initialized
INFO - 2018-07-31 23:57:34 --> URI Class Initialized
INFO - 2018-07-31 23:57:34 --> Router Class Initialized
INFO - 2018-07-31 23:57:34 --> Output Class Initialized
INFO - 2018-07-31 23:57:34 --> Security Class Initialized
DEBUG - 2018-07-31 23:57:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 23:57:34 --> Input Class Initialized
INFO - 2018-07-31 23:57:34 --> Language Class Initialized
INFO - 2018-07-31 23:57:34 --> Language Class Initialized
INFO - 2018-07-31 23:57:34 --> Config Class Initialized
INFO - 2018-07-31 23:57:34 --> Loader Class Initialized
DEBUG - 2018-07-31 23:57:34 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-31 23:57:34 --> Helper loaded: url_helper
INFO - 2018-07-31 23:57:34 --> Helper loaded: form_helper
INFO - 2018-07-31 23:57:34 --> Helper loaded: date_helper
INFO - 2018-07-31 23:57:34 --> Helper loaded: util_helper
INFO - 2018-07-31 23:57:34 --> Helper loaded: text_helper
INFO - 2018-07-31 23:57:34 --> Helper loaded: string_helper
INFO - 2018-07-31 23:57:34 --> Database Driver Class Initialized
DEBUG - 2018-07-31 23:57:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 23:57:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 23:57:35 --> Email Class Initialized
INFO - 2018-07-31 23:57:35 --> Controller Class Initialized
DEBUG - 2018-07-31 23:57:35 --> Chapters MX_Controller Initialized
INFO - 2018-07-31 23:57:35 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-31 23:57:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Chapters_model.php
DEBUG - 2018-07-31 23:57:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-31 23:57:35 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-31 23:57:35 --> Login MX_Controller Initialized
DEBUG - 2018-07-31 23:57:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-31 23:57:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-31 23:57:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-31 23:57:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-31 23:57:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-31 23:57:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-31 23:57:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/chapters/chapters.php
INFO - 2018-07-31 23:57:35 --> Final output sent to browser
DEBUG - 2018-07-31 23:57:35 --> Total execution time: 0.8647
INFO - 2018-07-31 23:57:35 --> Config Class Initialized
INFO - 2018-07-31 23:57:35 --> Hooks Class Initialized
DEBUG - 2018-07-31 23:57:35 --> UTF-8 Support Enabled
INFO - 2018-07-31 23:57:35 --> Utf8 Class Initialized
INFO - 2018-07-31 23:57:35 --> URI Class Initialized
INFO - 2018-07-31 23:57:35 --> Router Class Initialized
INFO - 2018-07-31 23:57:35 --> Output Class Initialized
INFO - 2018-07-31 23:57:36 --> Security Class Initialized
DEBUG - 2018-07-31 23:57:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 23:57:36 --> Input Class Initialized
INFO - 2018-07-31 23:57:36 --> Language Class Initialized
INFO - 2018-07-31 23:57:36 --> Language Class Initialized
INFO - 2018-07-31 23:57:36 --> Config Class Initialized
INFO - 2018-07-31 23:57:36 --> Loader Class Initialized
DEBUG - 2018-07-31 23:57:36 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-31 23:57:36 --> Helper loaded: url_helper
INFO - 2018-07-31 23:57:36 --> Helper loaded: form_helper
INFO - 2018-07-31 23:57:36 --> Helper loaded: date_helper
INFO - 2018-07-31 23:57:36 --> Helper loaded: util_helper
INFO - 2018-07-31 23:57:36 --> Helper loaded: text_helper
INFO - 2018-07-31 23:57:36 --> Helper loaded: string_helper
INFO - 2018-07-31 23:57:36 --> Config Class Initialized
INFO - 2018-07-31 23:57:36 --> Hooks Class Initialized
INFO - 2018-07-31 23:57:36 --> Database Driver Class Initialized
DEBUG - 2018-07-31 23:57:36 --> UTF-8 Support Enabled
DEBUG - 2018-07-31 23:57:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 23:57:36 --> Utf8 Class Initialized
INFO - 2018-07-31 23:57:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 23:57:36 --> URI Class Initialized
INFO - 2018-07-31 23:57:36 --> Email Class Initialized
INFO - 2018-07-31 23:57:36 --> Controller Class Initialized
INFO - 2018-07-31 23:57:36 --> Router Class Initialized
DEBUG - 2018-07-31 23:57:36 --> Chapters MX_Controller Initialized
INFO - 2018-07-31 23:57:36 --> Output Class Initialized
INFO - 2018-07-31 23:57:36 --> Language file loaded: language/english/data_lang.php
INFO - 2018-07-31 23:57:36 --> Security Class Initialized
DEBUG - 2018-07-31 23:57:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Chapters_model.php
DEBUG - 2018-07-31 23:57:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 23:57:36 --> Input Class Initialized
DEBUG - 2018-07-31 23:57:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-31 23:57:36 --> Language Class Initialized
DEBUG - 2018-07-31 23:57:36 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-31 23:57:36 --> Login MX_Controller Initialized
INFO - 2018-07-31 23:57:36 --> Language Class Initialized
INFO - 2018-07-31 23:57:36 --> Config Class Initialized
DEBUG - 2018-07-31 23:57:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-31 23:57:36 --> Loader Class Initialized
DEBUG - 2018-07-31 23:57:36 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-31 23:57:36 --> Helper loaded: url_helper
INFO - 2018-07-31 23:57:36 --> Final output sent to browser
DEBUG - 2018-07-31 23:57:36 --> Total execution time: 0.9056
INFO - 2018-07-31 23:57:36 --> Helper loaded: form_helper
INFO - 2018-07-31 23:57:36 --> Helper loaded: date_helper
INFO - 2018-07-31 23:57:36 --> Helper loaded: util_helper
INFO - 2018-07-31 23:57:36 --> Helper loaded: text_helper
INFO - 2018-07-31 23:57:36 --> Helper loaded: string_helper
INFO - 2018-07-31 23:57:36 --> Database Driver Class Initialized
DEBUG - 2018-07-31 23:57:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 23:57:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 23:57:36 --> Email Class Initialized
INFO - 2018-07-31 23:57:36 --> Controller Class Initialized
DEBUG - 2018-07-31 23:57:36 --> videos MX_Controller Initialized
INFO - 2018-07-31 23:57:36 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-31 23:57:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-07-31 23:57:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-31 23:57:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-07-31 23:57:37 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-31 23:57:37 --> Login MX_Controller Initialized
DEBUG - 2018-07-31 23:57:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-31 23:57:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-31 23:57:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-31 23:57:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-31 23:57:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-31 23:57:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-31 23:57:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/videos/videos.php
INFO - 2018-07-31 23:57:37 --> Final output sent to browser
DEBUG - 2018-07-31 23:57:37 --> Total execution time: 0.9871
INFO - 2018-07-31 23:57:37 --> Config Class Initialized
INFO - 2018-07-31 23:57:37 --> Hooks Class Initialized
DEBUG - 2018-07-31 23:57:37 --> UTF-8 Support Enabled
INFO - 2018-07-31 23:57:37 --> Utf8 Class Initialized
INFO - 2018-07-31 23:57:37 --> URI Class Initialized
INFO - 2018-07-31 23:57:37 --> Config Class Initialized
INFO - 2018-07-31 23:57:37 --> Hooks Class Initialized
INFO - 2018-07-31 23:57:37 --> Router Class Initialized
INFO - 2018-07-31 23:57:37 --> Output Class Initialized
DEBUG - 2018-07-31 23:57:37 --> UTF-8 Support Enabled
INFO - 2018-07-31 23:57:37 --> Utf8 Class Initialized
INFO - 2018-07-31 23:57:37 --> Security Class Initialized
INFO - 2018-07-31 23:57:37 --> URI Class Initialized
DEBUG - 2018-07-31 23:57:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 23:57:37 --> Input Class Initialized
INFO - 2018-07-31 23:57:37 --> Router Class Initialized
INFO - 2018-07-31 23:57:37 --> Language Class Initialized
INFO - 2018-07-31 23:57:37 --> Output Class Initialized
INFO - 2018-07-31 23:57:37 --> Language Class Initialized
INFO - 2018-07-31 23:57:37 --> Config Class Initialized
INFO - 2018-07-31 23:57:37 --> Security Class Initialized
DEBUG - 2018-07-31 23:57:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 23:57:37 --> Loader Class Initialized
INFO - 2018-07-31 23:57:37 --> Input Class Initialized
INFO - 2018-07-31 23:57:37 --> Language Class Initialized
DEBUG - 2018-07-31 23:57:37 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-31 23:57:37 --> Helper loaded: url_helper
INFO - 2018-07-31 23:57:37 --> Language Class Initialized
INFO - 2018-07-31 23:57:38 --> Config Class Initialized
INFO - 2018-07-31 23:57:38 --> Helper loaded: form_helper
INFO - 2018-07-31 23:57:38 --> Helper loaded: date_helper
INFO - 2018-07-31 23:57:38 --> Loader Class Initialized
DEBUG - 2018-07-31 23:57:38 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-31 23:57:38 --> Helper loaded: util_helper
INFO - 2018-07-31 23:57:38 --> Helper loaded: text_helper
INFO - 2018-07-31 23:57:38 --> Helper loaded: url_helper
INFO - 2018-07-31 23:57:38 --> Helper loaded: string_helper
INFO - 2018-07-31 23:57:38 --> Helper loaded: form_helper
INFO - 2018-07-31 23:57:38 --> Helper loaded: date_helper
INFO - 2018-07-31 23:57:38 --> Database Driver Class Initialized
INFO - 2018-07-31 23:57:38 --> Helper loaded: util_helper
DEBUG - 2018-07-31 23:57:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 23:57:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 23:57:38 --> Helper loaded: text_helper
INFO - 2018-07-31 23:57:38 --> Helper loaded: string_helper
INFO - 2018-07-31 23:57:38 --> Email Class Initialized
INFO - 2018-07-31 23:57:38 --> Controller Class Initialized
INFO - 2018-07-31 23:57:38 --> Database Driver Class Initialized
DEBUG - 2018-07-31 23:57:38 --> videos MX_Controller Initialized
INFO - 2018-07-31 23:57:38 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-31 23:57:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-07-31 23:57:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-07-31 23:57:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-31 23:57:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-07-31 23:57:38 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-31 23:57:38 --> Login MX_Controller Initialized
DEBUG - 2018-07-31 23:57:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-31 23:57:38 --> Final output sent to browser
DEBUG - 2018-07-31 23:57:38 --> Total execution time: 0.8418
INFO - 2018-07-31 23:57:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 23:57:38 --> Email Class Initialized
INFO - 2018-07-31 23:57:38 --> Controller Class Initialized
DEBUG - 2018-07-31 23:57:38 --> videos MX_Controller Initialized
INFO - 2018-07-31 23:57:38 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-31 23:57:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-07-31 23:57:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-31 23:57:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-07-31 23:57:38 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-31 23:57:38 --> Login MX_Controller Initialized
DEBUG - 2018-07-31 23:57:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-31 23:57:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-31 23:57:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-31 23:57:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-31 23:57:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-31 23:57:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-31 23:57:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/videos/create_video.php
INFO - 2018-07-31 23:57:38 --> Final output sent to browser
DEBUG - 2018-07-31 23:57:38 --> Total execution time: 1.1273
INFO - 2018-07-31 23:57:39 --> Config Class Initialized
INFO - 2018-07-31 23:57:39 --> Hooks Class Initialized
DEBUG - 2018-07-31 23:57:39 --> UTF-8 Support Enabled
INFO - 2018-07-31 23:57:39 --> Utf8 Class Initialized
INFO - 2018-07-31 23:57:39 --> URI Class Initialized
INFO - 2018-07-31 23:57:39 --> Router Class Initialized
INFO - 2018-07-31 23:57:39 --> Output Class Initialized
INFO - 2018-07-31 23:57:39 --> Security Class Initialized
DEBUG - 2018-07-31 23:57:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 23:57:39 --> Input Class Initialized
INFO - 2018-07-31 23:57:39 --> Language Class Initialized
ERROR - 2018-07-31 23:57:39 --> 404 Page Not Found: /index
INFO - 2018-07-31 23:57:44 --> Config Class Initialized
INFO - 2018-07-31 23:57:44 --> Hooks Class Initialized
DEBUG - 2018-07-31 23:57:44 --> UTF-8 Support Enabled
INFO - 2018-07-31 23:57:44 --> Utf8 Class Initialized
INFO - 2018-07-31 23:57:44 --> URI Class Initialized
INFO - 2018-07-31 23:57:44 --> Router Class Initialized
INFO - 2018-07-31 23:57:44 --> Output Class Initialized
INFO - 2018-07-31 23:57:44 --> Security Class Initialized
DEBUG - 2018-07-31 23:57:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 23:57:44 --> Input Class Initialized
INFO - 2018-07-31 23:57:44 --> Language Class Initialized
INFO - 2018-07-31 23:57:44 --> Language Class Initialized
INFO - 2018-07-31 23:57:45 --> Config Class Initialized
INFO - 2018-07-31 23:57:45 --> Loader Class Initialized
DEBUG - 2018-07-31 23:57:45 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-31 23:57:45 --> Helper loaded: url_helper
INFO - 2018-07-31 23:57:45 --> Helper loaded: form_helper
INFO - 2018-07-31 23:57:45 --> Helper loaded: date_helper
INFO - 2018-07-31 23:57:45 --> Helper loaded: util_helper
INFO - 2018-07-31 23:57:45 --> Helper loaded: text_helper
INFO - 2018-07-31 23:57:45 --> Helper loaded: string_helper
INFO - 2018-07-31 23:57:45 --> Database Driver Class Initialized
DEBUG - 2018-07-31 23:57:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 23:57:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 23:57:45 --> Email Class Initialized
INFO - 2018-07-31 23:57:45 --> Controller Class Initialized
DEBUG - 2018-07-31 23:57:45 --> videos MX_Controller Initialized
INFO - 2018-07-31 23:57:45 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-31 23:57:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-07-31 23:57:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-31 23:57:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-07-31 23:57:45 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-31 23:57:45 --> Login MX_Controller Initialized
DEBUG - 2018-07-31 23:57:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-31 23:57:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-31 23:57:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-31 23:57:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-31 23:57:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-31 23:57:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-31 23:57:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/videos/videos.php
INFO - 2018-07-31 23:57:45 --> Final output sent to browser
DEBUG - 2018-07-31 23:57:45 --> Total execution time: 0.8214
INFO - 2018-07-31 23:57:45 --> Config Class Initialized
INFO - 2018-07-31 23:57:45 --> Hooks Class Initialized
DEBUG - 2018-07-31 23:57:45 --> UTF-8 Support Enabled
INFO - 2018-07-31 23:57:46 --> Utf8 Class Initialized
INFO - 2018-07-31 23:57:46 --> URI Class Initialized
INFO - 2018-07-31 23:57:46 --> Router Class Initialized
INFO - 2018-07-31 23:57:46 --> Output Class Initialized
INFO - 2018-07-31 23:57:46 --> Security Class Initialized
DEBUG - 2018-07-31 23:57:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 23:57:46 --> Input Class Initialized
INFO - 2018-07-31 23:57:46 --> Language Class Initialized
INFO - 2018-07-31 23:57:46 --> Language Class Initialized
INFO - 2018-07-31 23:57:46 --> Config Class Initialized
INFO - 2018-07-31 23:57:46 --> Loader Class Initialized
DEBUG - 2018-07-31 23:57:46 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-31 23:57:46 --> Helper loaded: url_helper
INFO - 2018-07-31 23:57:46 --> Helper loaded: form_helper
INFO - 2018-07-31 23:57:46 --> Helper loaded: date_helper
INFO - 2018-07-31 23:57:46 --> Helper loaded: util_helper
INFO - 2018-07-31 23:57:46 --> Helper loaded: text_helper
INFO - 2018-07-31 23:57:46 --> Helper loaded: string_helper
INFO - 2018-07-31 23:57:46 --> Database Driver Class Initialized
DEBUG - 2018-07-31 23:57:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 23:57:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 23:57:46 --> Email Class Initialized
INFO - 2018-07-31 23:57:46 --> Controller Class Initialized
DEBUG - 2018-07-31 23:57:46 --> videos MX_Controller Initialized
INFO - 2018-07-31 23:57:46 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-31 23:57:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-07-31 23:57:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-31 23:57:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-07-31 23:57:46 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-31 23:57:46 --> Login MX_Controller Initialized
DEBUG - 2018-07-31 23:57:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-31 23:57:46 --> Final output sent to browser
DEBUG - 2018-07-31 23:57:46 --> Total execution time: 0.7992
INFO - 2018-07-31 23:58:19 --> Config Class Initialized
INFO - 2018-07-31 23:58:19 --> Hooks Class Initialized
DEBUG - 2018-07-31 23:58:19 --> UTF-8 Support Enabled
INFO - 2018-07-31 23:58:19 --> Utf8 Class Initialized
INFO - 2018-07-31 23:58:19 --> URI Class Initialized
INFO - 2018-07-31 23:58:19 --> Router Class Initialized
INFO - 2018-07-31 23:58:19 --> Output Class Initialized
INFO - 2018-07-31 23:58:19 --> Security Class Initialized
DEBUG - 2018-07-31 23:58:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 23:58:19 --> Input Class Initialized
INFO - 2018-07-31 23:58:19 --> Language Class Initialized
INFO - 2018-07-31 23:58:19 --> Language Class Initialized
INFO - 2018-07-31 23:58:19 --> Config Class Initialized
INFO - 2018-07-31 23:58:19 --> Loader Class Initialized
DEBUG - 2018-07-31 23:58:19 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-31 23:58:19 --> Helper loaded: url_helper
INFO - 2018-07-31 23:58:19 --> Helper loaded: form_helper
INFO - 2018-07-31 23:58:20 --> Helper loaded: date_helper
INFO - 2018-07-31 23:58:20 --> Helper loaded: util_helper
INFO - 2018-07-31 23:58:20 --> Helper loaded: text_helper
INFO - 2018-07-31 23:58:20 --> Helper loaded: string_helper
INFO - 2018-07-31 23:58:20 --> Database Driver Class Initialized
DEBUG - 2018-07-31 23:58:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 23:58:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 23:58:20 --> Email Class Initialized
INFO - 2018-07-31 23:58:20 --> Controller Class Initialized
DEBUG - 2018-07-31 23:58:20 --> videos MX_Controller Initialized
INFO - 2018-07-31 23:58:20 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-31 23:58:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-07-31 23:58:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-31 23:58:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-07-31 23:58:20 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-31 23:58:20 --> Login MX_Controller Initialized
DEBUG - 2018-07-31 23:58:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-31 23:58:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-31 23:58:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-31 23:58:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-31 23:58:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-31 23:58:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-31 23:58:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/videos/create_video.php
INFO - 2018-07-31 23:58:20 --> Final output sent to browser
DEBUG - 2018-07-31 23:58:20 --> Total execution time: 0.8200
INFO - 2018-07-31 23:58:21 --> Config Class Initialized
INFO - 2018-07-31 23:58:21 --> Hooks Class Initialized
DEBUG - 2018-07-31 23:58:21 --> UTF-8 Support Enabled
INFO - 2018-07-31 23:58:21 --> Utf8 Class Initialized
INFO - 2018-07-31 23:58:21 --> URI Class Initialized
INFO - 2018-07-31 23:58:21 --> Router Class Initialized
INFO - 2018-07-31 23:58:21 --> Output Class Initialized
INFO - 2018-07-31 23:58:21 --> Security Class Initialized
DEBUG - 2018-07-31 23:58:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 23:58:21 --> Input Class Initialized
INFO - 2018-07-31 23:58:21 --> Language Class Initialized
ERROR - 2018-07-31 23:58:21 --> 404 Page Not Found: /index
INFO - 2018-07-31 23:58:32 --> Config Class Initialized
INFO - 2018-07-31 23:58:32 --> Hooks Class Initialized
DEBUG - 2018-07-31 23:58:32 --> UTF-8 Support Enabled
INFO - 2018-07-31 23:58:32 --> Utf8 Class Initialized
INFO - 2018-07-31 23:58:32 --> URI Class Initialized
INFO - 2018-07-31 23:58:32 --> Router Class Initialized
INFO - 2018-07-31 23:58:32 --> Output Class Initialized
INFO - 2018-07-31 23:58:32 --> Security Class Initialized
DEBUG - 2018-07-31 23:58:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 23:58:32 --> Input Class Initialized
INFO - 2018-07-31 23:58:32 --> Language Class Initialized
INFO - 2018-07-31 23:58:33 --> Language Class Initialized
INFO - 2018-07-31 23:58:33 --> Config Class Initialized
INFO - 2018-07-31 23:58:33 --> Loader Class Initialized
DEBUG - 2018-07-31 23:58:33 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-31 23:58:33 --> Helper loaded: url_helper
INFO - 2018-07-31 23:58:33 --> Helper loaded: form_helper
INFO - 2018-07-31 23:58:33 --> Helper loaded: date_helper
INFO - 2018-07-31 23:58:33 --> Helper loaded: util_helper
INFO - 2018-07-31 23:58:33 --> Helper loaded: text_helper
INFO - 2018-07-31 23:58:33 --> Helper loaded: string_helper
INFO - 2018-07-31 23:58:33 --> Database Driver Class Initialized
DEBUG - 2018-07-31 23:58:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-31 23:58:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-31 23:58:33 --> Email Class Initialized
INFO - 2018-07-31 23:58:33 --> Controller Class Initialized
DEBUG - 2018-07-31 23:58:33 --> videos MX_Controller Initialized
INFO - 2018-07-31 23:58:33 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-31 23:58:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-07-31 23:58:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-31 23:58:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-07-31 23:58:33 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-31 23:58:33 --> Login MX_Controller Initialized
DEBUG - 2018-07-31 23:58:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-31 23:58:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-31 23:58:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-31 23:58:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-31 23:58:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-31 23:58:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-31 23:58:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/videos/create_video.php
INFO - 2018-07-31 23:58:33 --> Final output sent to browser
DEBUG - 2018-07-31 23:58:33 --> Total execution time: 0.9373
INFO - 2018-07-31 23:58:34 --> Config Class Initialized
INFO - 2018-07-31 23:58:34 --> Hooks Class Initialized
DEBUG - 2018-07-31 23:58:34 --> UTF-8 Support Enabled
INFO - 2018-07-31 23:58:34 --> Utf8 Class Initialized
INFO - 2018-07-31 23:58:34 --> URI Class Initialized
INFO - 2018-07-31 23:58:34 --> Router Class Initialized
INFO - 2018-07-31 23:58:34 --> Output Class Initialized
INFO - 2018-07-31 23:58:34 --> Security Class Initialized
DEBUG - 2018-07-31 23:58:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 23:58:34 --> Input Class Initialized
INFO - 2018-07-31 23:58:34 --> Language Class Initialized
ERROR - 2018-07-31 23:58:34 --> 404 Page Not Found: /index
INFO - 2018-07-31 23:58:37 --> Config Class Initialized
INFO - 2018-07-31 23:58:37 --> Hooks Class Initialized
INFO - 2018-07-31 23:58:37 --> Config Class Initialized
INFO - 2018-07-31 23:58:37 --> Hooks Class Initialized
DEBUG - 2018-07-31 23:58:37 --> UTF-8 Support Enabled
INFO - 2018-07-31 23:58:37 --> Utf8 Class Initialized
DEBUG - 2018-07-31 23:58:37 --> UTF-8 Support Enabled
INFO - 2018-07-31 23:58:37 --> Utf8 Class Initialized
INFO - 2018-07-31 23:58:37 --> URI Class Initialized
INFO - 2018-07-31 23:58:37 --> URI Class Initialized
INFO - 2018-07-31 23:58:37 --> Router Class Initialized
INFO - 2018-07-31 23:58:37 --> Output Class Initialized
INFO - 2018-07-31 23:58:37 --> Router Class Initialized
INFO - 2018-07-31 23:58:37 --> Security Class Initialized
INFO - 2018-07-31 23:58:37 --> Output Class Initialized
DEBUG - 2018-07-31 23:58:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 23:58:37 --> Input Class Initialized
INFO - 2018-07-31 23:58:37 --> Security Class Initialized
INFO - 2018-07-31 23:58:38 --> Language Class Initialized
ERROR - 2018-07-31 23:58:38 --> 404 Page Not Found: /index
DEBUG - 2018-07-31 23:58:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 23:58:38 --> Input Class Initialized
INFO - 2018-07-31 23:58:38 --> Language Class Initialized
ERROR - 2018-07-31 23:58:38 --> 404 Page Not Found: /index
INFO - 2018-07-31 23:58:38 --> Config Class Initialized
INFO - 2018-07-31 23:58:38 --> Hooks Class Initialized
DEBUG - 2018-07-31 23:58:38 --> UTF-8 Support Enabled
INFO - 2018-07-31 23:58:38 --> Utf8 Class Initialized
INFO - 2018-07-31 23:58:38 --> URI Class Initialized
INFO - 2018-07-31 23:58:38 --> Router Class Initialized
INFO - 2018-07-31 23:58:38 --> Output Class Initialized
INFO - 2018-07-31 23:58:38 --> Security Class Initialized
DEBUG - 2018-07-31 23:58:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 23:58:38 --> Input Class Initialized
INFO - 2018-07-31 23:58:38 --> Language Class Initialized
ERROR - 2018-07-31 23:58:38 --> 404 Page Not Found: /index
INFO - 2018-07-31 23:58:38 --> Config Class Initialized
INFO - 2018-07-31 23:58:38 --> Hooks Class Initialized
DEBUG - 2018-07-31 23:58:38 --> UTF-8 Support Enabled
INFO - 2018-07-31 23:58:38 --> Utf8 Class Initialized
INFO - 2018-07-31 23:58:38 --> URI Class Initialized
INFO - 2018-07-31 23:58:38 --> Router Class Initialized
INFO - 2018-07-31 23:58:38 --> Output Class Initialized
INFO - 2018-07-31 23:58:38 --> Security Class Initialized
DEBUG - 2018-07-31 23:58:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 23:58:38 --> Input Class Initialized
INFO - 2018-07-31 23:58:38 --> Language Class Initialized
ERROR - 2018-07-31 23:58:38 --> 404 Page Not Found: /index
INFO - 2018-07-31 23:58:44 --> Config Class Initialized
INFO - 2018-07-31 23:58:44 --> Hooks Class Initialized
DEBUG - 2018-07-31 23:58:44 --> UTF-8 Support Enabled
INFO - 2018-07-31 23:58:44 --> Utf8 Class Initialized
INFO - 2018-07-31 23:58:44 --> URI Class Initialized
INFO - 2018-07-31 23:58:44 --> Router Class Initialized
INFO - 2018-07-31 23:58:44 --> Output Class Initialized
INFO - 2018-07-31 23:58:44 --> Security Class Initialized
DEBUG - 2018-07-31 23:58:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-31 23:58:44 --> Input Class Initialized
INFO - 2018-07-31 23:58:44 --> Language Class Initialized
ERROR - 2018-07-31 23:58:44 --> 404 Page Not Found: /index
