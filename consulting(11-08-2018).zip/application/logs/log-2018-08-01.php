<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-08-01 00:00:39 --> Config Class Initialized
INFO - 2018-08-01 00:00:39 --> Hooks Class Initialized
DEBUG - 2018-08-01 00:00:39 --> UTF-8 Support Enabled
INFO - 2018-08-01 00:00:39 --> Utf8 Class Initialized
INFO - 2018-08-01 00:00:39 --> URI Class Initialized
INFO - 2018-08-01 00:00:39 --> Router Class Initialized
INFO - 2018-08-01 00:00:39 --> Output Class Initialized
INFO - 2018-08-01 00:00:39 --> Security Class Initialized
DEBUG - 2018-08-01 00:00:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-01 00:00:39 --> Input Class Initialized
INFO - 2018-08-01 00:00:39 --> Language Class Initialized
INFO - 2018-08-01 00:00:39 --> Language Class Initialized
INFO - 2018-08-01 00:00:39 --> Config Class Initialized
INFO - 2018-08-01 00:00:39 --> Loader Class Initialized
DEBUG - 2018-08-01 00:00:39 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-01 00:00:39 --> Helper loaded: url_helper
INFO - 2018-08-01 00:00:39 --> Helper loaded: form_helper
INFO - 2018-08-01 00:00:39 --> Helper loaded: date_helper
INFO - 2018-08-01 00:00:39 --> Helper loaded: util_helper
INFO - 2018-08-01 00:00:39 --> Helper loaded: text_helper
INFO - 2018-08-01 00:00:39 --> Helper loaded: string_helper
INFO - 2018-08-01 00:00:39 --> Database Driver Class Initialized
DEBUG - 2018-08-01 00:00:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-01 00:00:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-01 00:00:39 --> Email Class Initialized
INFO - 2018-08-01 00:00:39 --> Controller Class Initialized
DEBUG - 2018-08-01 00:00:39 --> videos MX_Controller Initialized
INFO - 2018-08-01 00:00:39 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-01 00:00:39 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-08-01 00:00:39 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-01 00:00:39 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-08-01 00:00:39 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-01 00:00:39 --> Login MX_Controller Initialized
DEBUG - 2018-08-01 00:00:39 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-01 00:00:39 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-08-01 00:00:39 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-08-01 00:00:39 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-08-01 00:00:39 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-08-01 00:00:39 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-08-01 00:00:39 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/videos/create_video.php
INFO - 2018-08-01 00:00:39 --> Final output sent to browser
DEBUG - 2018-08-01 00:00:40 --> Total execution time: 0.3528
INFO - 2018-08-01 00:00:40 --> Config Class Initialized
INFO - 2018-08-01 00:00:40 --> Hooks Class Initialized
DEBUG - 2018-08-01 00:00:40 --> UTF-8 Support Enabled
INFO - 2018-08-01 00:00:40 --> Utf8 Class Initialized
INFO - 2018-08-01 00:00:40 --> URI Class Initialized
INFO - 2018-08-01 00:00:40 --> Router Class Initialized
INFO - 2018-08-01 00:00:40 --> Output Class Initialized
INFO - 2018-08-01 00:00:40 --> Security Class Initialized
DEBUG - 2018-08-01 00:00:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-01 00:00:40 --> Input Class Initialized
INFO - 2018-08-01 00:00:40 --> Language Class Initialized
ERROR - 2018-08-01 00:00:40 --> 404 Page Not Found: /index
INFO - 2018-08-01 00:37:44 --> Config Class Initialized
INFO - 2018-08-01 00:37:44 --> Hooks Class Initialized
DEBUG - 2018-08-01 00:37:44 --> UTF-8 Support Enabled
INFO - 2018-08-01 00:37:44 --> Utf8 Class Initialized
INFO - 2018-08-01 00:37:44 --> URI Class Initialized
INFO - 2018-08-01 00:37:44 --> Router Class Initialized
INFO - 2018-08-01 00:37:44 --> Output Class Initialized
INFO - 2018-08-01 00:37:44 --> Security Class Initialized
DEBUG - 2018-08-01 00:37:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-01 00:37:44 --> Input Class Initialized
INFO - 2018-08-01 00:37:44 --> Language Class Initialized
INFO - 2018-08-01 00:37:44 --> Language Class Initialized
INFO - 2018-08-01 00:37:44 --> Config Class Initialized
INFO - 2018-08-01 00:37:44 --> Hooks Class Initialized
INFO - 2018-08-01 00:37:44 --> Config Class Initialized
DEBUG - 2018-08-01 00:37:44 --> UTF-8 Support Enabled
INFO - 2018-08-01 00:37:44 --> Loader Class Initialized
INFO - 2018-08-01 00:37:44 --> Utf8 Class Initialized
INFO - 2018-08-01 00:37:44 --> URI Class Initialized
INFO - 2018-08-01 00:37:44 --> Router Class Initialized
DEBUG - 2018-08-01 00:37:44 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-01 00:37:44 --> Output Class Initialized
INFO - 2018-08-01 00:37:44 --> Security Class Initialized
DEBUG - 2018-08-01 00:37:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-01 00:37:44 --> Input Class Initialized
INFO - 2018-08-01 00:37:44 --> Language Class Initialized
ERROR - 2018-08-01 00:37:44 --> 404 Page Not Found: /index
INFO - 2018-08-01 00:37:44 --> Config Class Initialized
INFO - 2018-08-01 00:37:44 --> Hooks Class Initialized
DEBUG - 2018-08-01 00:37:44 --> UTF-8 Support Enabled
INFO - 2018-08-01 00:37:44 --> Helper loaded: url_helper
INFO - 2018-08-01 00:37:44 --> Utf8 Class Initialized
INFO - 2018-08-01 00:37:44 --> URI Class Initialized
INFO - 2018-08-01 00:37:44 --> Router Class Initialized
INFO - 2018-08-01 00:37:44 --> Helper loaded: form_helper
INFO - 2018-08-01 00:37:44 --> Output Class Initialized
INFO - 2018-08-01 00:37:44 --> Security Class Initialized
DEBUG - 2018-08-01 00:37:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-01 00:37:44 --> Input Class Initialized
INFO - 2018-08-01 00:37:44 --> Language Class Initialized
ERROR - 2018-08-01 00:37:44 --> 404 Page Not Found: /index
INFO - 2018-08-01 00:37:44 --> Config Class Initialized
INFO - 2018-08-01 00:37:44 --> Helper loaded: date_helper
INFO - 2018-08-01 00:37:44 --> Hooks Class Initialized
DEBUG - 2018-08-01 00:37:44 --> UTF-8 Support Enabled
INFO - 2018-08-01 00:37:44 --> Helper loaded: util_helper
INFO - 2018-08-01 00:37:44 --> Utf8 Class Initialized
INFO - 2018-08-01 00:37:44 --> URI Class Initialized
INFO - 2018-08-01 00:37:44 --> Router Class Initialized
INFO - 2018-08-01 00:37:44 --> Helper loaded: text_helper
INFO - 2018-08-01 00:37:44 --> Output Class Initialized
INFO - 2018-08-01 00:37:44 --> Security Class Initialized
DEBUG - 2018-08-01 00:37:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-01 00:37:44 --> Input Class Initialized
INFO - 2018-08-01 00:37:44 --> Language Class Initialized
ERROR - 2018-08-01 00:37:44 --> 404 Page Not Found: /index
INFO - 2018-08-01 00:37:44 --> Helper loaded: string_helper
INFO - 2018-08-01 00:37:44 --> Database Driver Class Initialized
DEBUG - 2018-08-01 00:37:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-01 00:37:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-01 00:37:44 --> Email Class Initialized
INFO - 2018-08-01 00:37:44 --> Controller Class Initialized
DEBUG - 2018-08-01 00:37:44 --> Home MX_Controller Initialized
DEBUG - 2018-08-01 00:37:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-01 00:37:45 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-01 00:37:45 --> Login MX_Controller Initialized
INFO - 2018-08-01 00:37:45 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-01 00:37:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-01 00:37:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-01 02:44:33 --> Config Class Initialized
INFO - 2018-08-01 02:44:33 --> Hooks Class Initialized
DEBUG - 2018-08-01 02:44:33 --> UTF-8 Support Enabled
INFO - 2018-08-01 02:44:33 --> Utf8 Class Initialized
INFO - 2018-08-01 02:44:33 --> URI Class Initialized
INFO - 2018-08-01 02:44:33 --> Router Class Initialized
INFO - 2018-08-01 02:44:33 --> Output Class Initialized
INFO - 2018-08-01 02:44:33 --> Security Class Initialized
DEBUG - 2018-08-01 02:44:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-01 02:44:33 --> Input Class Initialized
INFO - 2018-08-01 02:44:33 --> Language Class Initialized
INFO - 2018-08-01 02:44:33 --> Config Class Initialized
INFO - 2018-08-01 02:44:33 --> Language Class Initialized
INFO - 2018-08-01 02:44:33 --> Hooks Class Initialized
INFO - 2018-08-01 02:44:33 --> Config Class Initialized
DEBUG - 2018-08-01 02:44:33 --> UTF-8 Support Enabled
INFO - 2018-08-01 02:44:33 --> Utf8 Class Initialized
INFO - 2018-08-01 02:44:33 --> Loader Class Initialized
INFO - 2018-08-01 02:44:33 --> URI Class Initialized
INFO - 2018-08-01 02:44:33 --> Router Class Initialized
DEBUG - 2018-08-01 02:44:33 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-01 02:44:33 --> Output Class Initialized
INFO - 2018-08-01 02:44:33 --> Security Class Initialized
DEBUG - 2018-08-01 02:44:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-01 02:44:33 --> Input Class Initialized
INFO - 2018-08-01 02:44:33 --> Language Class Initialized
ERROR - 2018-08-01 02:44:33 --> 404 Page Not Found: /index
INFO - 2018-08-01 02:44:33 --> Config Class Initialized
INFO - 2018-08-01 02:44:33 --> Hooks Class Initialized
DEBUG - 2018-08-01 02:44:33 --> UTF-8 Support Enabled
INFO - 2018-08-01 02:44:33 --> Helper loaded: url_helper
INFO - 2018-08-01 02:44:33 --> Utf8 Class Initialized
INFO - 2018-08-01 02:44:33 --> URI Class Initialized
INFO - 2018-08-01 02:44:33 --> Router Class Initialized
INFO - 2018-08-01 02:44:33 --> Helper loaded: form_helper
INFO - 2018-08-01 02:44:33 --> Output Class Initialized
INFO - 2018-08-01 02:44:33 --> Security Class Initialized
DEBUG - 2018-08-01 02:44:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-01 02:44:33 --> Input Class Initialized
INFO - 2018-08-01 02:44:33 --> Language Class Initialized
ERROR - 2018-08-01 02:44:33 --> 404 Page Not Found: /index
INFO - 2018-08-01 02:44:33 --> Config Class Initialized
INFO - 2018-08-01 02:44:33 --> Hooks Class Initialized
DEBUG - 2018-08-01 02:44:33 --> UTF-8 Support Enabled
INFO - 2018-08-01 02:44:33 --> Helper loaded: date_helper
INFO - 2018-08-01 02:44:33 --> Utf8 Class Initialized
INFO - 2018-08-01 02:44:33 --> URI Class Initialized
INFO - 2018-08-01 02:44:33 --> Router Class Initialized
INFO - 2018-08-01 02:44:33 --> Helper loaded: util_helper
INFO - 2018-08-01 02:44:33 --> Output Class Initialized
INFO - 2018-08-01 02:44:33 --> Security Class Initialized
DEBUG - 2018-08-01 02:44:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-01 02:44:33 --> Input Class Initialized
INFO - 2018-08-01 02:44:33 --> Language Class Initialized
ERROR - 2018-08-01 02:44:33 --> 404 Page Not Found: /index
INFO - 2018-08-01 02:44:33 --> Helper loaded: text_helper
INFO - 2018-08-01 02:44:33 --> Helper loaded: string_helper
INFO - 2018-08-01 02:44:33 --> Database Driver Class Initialized
DEBUG - 2018-08-01 02:44:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-01 02:44:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-01 02:44:33 --> Email Class Initialized
INFO - 2018-08-01 02:44:33 --> Controller Class Initialized
DEBUG - 2018-08-01 02:44:33 --> Home MX_Controller Initialized
DEBUG - 2018-08-01 02:44:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-01 02:44:33 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-01 02:44:33 --> Login MX_Controller Initialized
INFO - 2018-08-01 02:44:33 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-01 02:44:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-01 02:44:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-01 02:44:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/login.php
INFO - 2018-08-01 02:44:36 --> Config Class Initialized
INFO - 2018-08-01 02:44:36 --> Hooks Class Initialized
DEBUG - 2018-08-01 02:44:36 --> UTF-8 Support Enabled
INFO - 2018-08-01 02:44:36 --> Utf8 Class Initialized
INFO - 2018-08-01 02:44:36 --> URI Class Initialized
INFO - 2018-08-01 02:44:36 --> Router Class Initialized
INFO - 2018-08-01 02:44:36 --> Output Class Initialized
INFO - 2018-08-01 02:44:36 --> Security Class Initialized
DEBUG - 2018-08-01 02:44:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-01 02:44:36 --> Input Class Initialized
INFO - 2018-08-01 02:44:36 --> Language Class Initialized
INFO - 2018-08-01 02:44:36 --> Language Class Initialized
INFO - 2018-08-01 02:44:36 --> Config Class Initialized
INFO - 2018-08-01 02:44:36 --> Loader Class Initialized
DEBUG - 2018-08-01 02:44:36 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-01 02:44:36 --> Helper loaded: url_helper
INFO - 2018-08-01 02:44:36 --> Helper loaded: form_helper
INFO - 2018-08-01 02:44:36 --> Helper loaded: date_helper
INFO - 2018-08-01 02:44:36 --> Helper loaded: util_helper
INFO - 2018-08-01 02:44:36 --> Helper loaded: text_helper
INFO - 2018-08-01 02:44:36 --> Helper loaded: string_helper
INFO - 2018-08-01 02:44:36 --> Database Driver Class Initialized
DEBUG - 2018-08-01 02:44:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-01 02:44:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-01 02:44:36 --> Email Class Initialized
INFO - 2018-08-01 02:44:36 --> Controller Class Initialized
DEBUG - 2018-08-01 02:44:36 --> Home MX_Controller Initialized
DEBUG - 2018-08-01 02:44:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-01 02:44:36 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-01 02:44:36 --> Login MX_Controller Initialized
INFO - 2018-08-01 02:44:36 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-01 02:44:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-01 02:44:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-01 02:44:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/login.php
INFO - 2018-08-01 02:44:37 --> Config Class Initialized
INFO - 2018-08-01 02:44:37 --> Hooks Class Initialized
DEBUG - 2018-08-01 02:44:37 --> UTF-8 Support Enabled
INFO - 2018-08-01 02:44:37 --> Utf8 Class Initialized
INFO - 2018-08-01 02:44:37 --> URI Class Initialized
INFO - 2018-08-01 02:44:37 --> Router Class Initialized
INFO - 2018-08-01 02:44:37 --> Output Class Initialized
INFO - 2018-08-01 02:44:38 --> Security Class Initialized
DEBUG - 2018-08-01 02:44:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-01 02:44:38 --> Input Class Initialized
INFO - 2018-08-01 02:44:38 --> Language Class Initialized
INFO - 2018-08-01 02:44:38 --> Language Class Initialized
INFO - 2018-08-01 02:44:38 --> Config Class Initialized
INFO - 2018-08-01 02:44:38 --> Loader Class Initialized
DEBUG - 2018-08-01 02:44:38 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-01 02:44:38 --> Helper loaded: url_helper
INFO - 2018-08-01 02:44:38 --> Helper loaded: form_helper
INFO - 2018-08-01 02:44:38 --> Helper loaded: date_helper
INFO - 2018-08-01 02:44:38 --> Helper loaded: util_helper
INFO - 2018-08-01 02:44:38 --> Helper loaded: text_helper
INFO - 2018-08-01 02:44:38 --> Helper loaded: string_helper
INFO - 2018-08-01 02:44:38 --> Database Driver Class Initialized
DEBUG - 2018-08-01 02:44:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-01 02:44:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-01 02:44:38 --> Email Class Initialized
INFO - 2018-08-01 02:44:38 --> Controller Class Initialized
DEBUG - 2018-08-01 02:44:38 --> Home MX_Controller Initialized
DEBUG - 2018-08-01 02:44:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-01 02:44:38 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-01 02:44:38 --> Login MX_Controller Initialized
INFO - 2018-08-01 02:44:38 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-01 02:44:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-01 02:44:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-01 02:44:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/login.php
INFO - 2018-08-01 02:44:48 --> Config Class Initialized
INFO - 2018-08-01 02:44:48 --> Hooks Class Initialized
DEBUG - 2018-08-01 02:44:48 --> UTF-8 Support Enabled
INFO - 2018-08-01 02:44:48 --> Utf8 Class Initialized
INFO - 2018-08-01 02:44:48 --> URI Class Initialized
INFO - 2018-08-01 02:44:48 --> Config Class Initialized
INFO - 2018-08-01 02:44:48 --> Router Class Initialized
INFO - 2018-08-01 02:44:48 --> Hooks Class Initialized
DEBUG - 2018-08-01 02:44:48 --> UTF-8 Support Enabled
INFO - 2018-08-01 02:44:48 --> Output Class Initialized
INFO - 2018-08-01 02:44:48 --> Utf8 Class Initialized
INFO - 2018-08-01 02:44:48 --> URI Class Initialized
INFO - 2018-08-01 02:44:48 --> Router Class Initialized
INFO - 2018-08-01 02:44:48 --> Security Class Initialized
INFO - 2018-08-01 02:44:48 --> Output Class Initialized
INFO - 2018-08-01 02:44:48 --> Security Class Initialized
DEBUG - 2018-08-01 02:44:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-01 02:44:49 --> Input Class Initialized
INFO - 2018-08-01 02:44:49 --> Language Class Initialized
ERROR - 2018-08-01 02:44:49 --> 404 Page Not Found: /index
INFO - 2018-08-01 02:44:49 --> Config Class Initialized
INFO - 2018-08-01 02:44:49 --> Hooks Class Initialized
DEBUG - 2018-08-01 02:44:49 --> UTF-8 Support Enabled
DEBUG - 2018-08-01 02:44:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-01 02:44:49 --> Utf8 Class Initialized
INFO - 2018-08-01 02:44:49 --> URI Class Initialized
INFO - 2018-08-01 02:44:49 --> Router Class Initialized
INFO - 2018-08-01 02:44:49 --> Input Class Initialized
INFO - 2018-08-01 02:44:49 --> Output Class Initialized
INFO - 2018-08-01 02:44:49 --> Security Class Initialized
DEBUG - 2018-08-01 02:44:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-01 02:44:49 --> Input Class Initialized
INFO - 2018-08-01 02:44:49 --> Language Class Initialized
ERROR - 2018-08-01 02:44:49 --> 404 Page Not Found: /index
INFO - 2018-08-01 02:44:49 --> Config Class Initialized
INFO - 2018-08-01 02:44:49 --> Hooks Class Initialized
DEBUG - 2018-08-01 02:44:49 --> UTF-8 Support Enabled
INFO - 2018-08-01 02:44:49 --> Language Class Initialized
INFO - 2018-08-01 02:44:49 --> Utf8 Class Initialized
INFO - 2018-08-01 02:44:49 --> URI Class Initialized
INFO - 2018-08-01 02:44:49 --> Router Class Initialized
INFO - 2018-08-01 02:44:49 --> Language Class Initialized
INFO - 2018-08-01 02:44:49 --> Output Class Initialized
INFO - 2018-08-01 02:44:49 --> Security Class Initialized
DEBUG - 2018-08-01 02:44:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-01 02:44:49 --> Input Class Initialized
INFO - 2018-08-01 02:44:49 --> Language Class Initialized
ERROR - 2018-08-01 02:44:49 --> 404 Page Not Found: /index
INFO - 2018-08-01 02:44:49 --> Config Class Initialized
INFO - 2018-08-01 02:44:49 --> Loader Class Initialized
DEBUG - 2018-08-01 02:44:49 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-01 02:44:49 --> Helper loaded: url_helper
INFO - 2018-08-01 02:44:49 --> Helper loaded: form_helper
INFO - 2018-08-01 02:44:49 --> Helper loaded: date_helper
INFO - 2018-08-01 02:44:49 --> Helper loaded: util_helper
INFO - 2018-08-01 02:44:49 --> Helper loaded: text_helper
INFO - 2018-08-01 02:44:49 --> Helper loaded: string_helper
INFO - 2018-08-01 02:44:49 --> Database Driver Class Initialized
DEBUG - 2018-08-01 02:44:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-01 02:44:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-01 02:44:49 --> Email Class Initialized
INFO - 2018-08-01 02:44:49 --> Controller Class Initialized
DEBUG - 2018-08-01 02:44:49 --> Home MX_Controller Initialized
DEBUG - 2018-08-01 02:44:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-01 02:44:49 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-01 02:44:49 --> Login MX_Controller Initialized
INFO - 2018-08-01 02:44:49 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-01 02:44:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-01 02:44:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-01 02:44:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/login.php
INFO - 2018-08-01 02:44:51 --> Config Class Initialized
INFO - 2018-08-01 02:44:51 --> Hooks Class Initialized
DEBUG - 2018-08-01 02:44:51 --> UTF-8 Support Enabled
INFO - 2018-08-01 02:44:51 --> Utf8 Class Initialized
INFO - 2018-08-01 02:44:51 --> URI Class Initialized
INFO - 2018-08-01 02:44:51 --> Config Class Initialized
INFO - 2018-08-01 02:44:51 --> Hooks Class Initialized
INFO - 2018-08-01 02:44:51 --> Router Class Initialized
INFO - 2018-08-01 02:44:51 --> Output Class Initialized
DEBUG - 2018-08-01 02:44:51 --> UTF-8 Support Enabled
INFO - 2018-08-01 02:44:51 --> Security Class Initialized
DEBUG - 2018-08-01 02:44:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-01 02:44:51 --> Input Class Initialized
INFO - 2018-08-01 02:44:51 --> Language Class Initialized
INFO - 2018-08-01 02:44:51 --> Utf8 Class Initialized
INFO - 2018-08-01 02:44:51 --> Language Class Initialized
INFO - 2018-08-01 02:44:51 --> Config Class Initialized
INFO - 2018-08-01 02:44:51 --> URI Class Initialized
INFO - 2018-08-01 02:44:51 --> Loader Class Initialized
DEBUG - 2018-08-01 02:44:51 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-01 02:44:51 --> Helper loaded: url_helper
INFO - 2018-08-01 02:44:51 --> Helper loaded: form_helper
INFO - 2018-08-01 02:44:51 --> Helper loaded: date_helper
INFO - 2018-08-01 02:44:51 --> Helper loaded: util_helper
INFO - 2018-08-01 02:44:51 --> Helper loaded: text_helper
INFO - 2018-08-01 02:44:51 --> Helper loaded: string_helper
INFO - 2018-08-01 02:44:51 --> Router Class Initialized
INFO - 2018-08-01 02:44:51 --> Database Driver Class Initialized
INFO - 2018-08-01 02:44:51 --> Output Class Initialized
DEBUG - 2018-08-01 02:44:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-01 02:44:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-01 02:44:51 --> Security Class Initialized
INFO - 2018-08-01 02:44:51 --> Email Class Initialized
DEBUG - 2018-08-01 02:44:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-01 02:44:51 --> Controller Class Initialized
DEBUG - 2018-08-01 02:44:51 --> Home MX_Controller Initialized
DEBUG - 2018-08-01 02:44:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-08-01 02:44:51 --> Input Class Initialized
DEBUG - 2018-08-01 02:44:51 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-01 02:44:51 --> Login MX_Controller Initialized
INFO - 2018-08-01 02:44:51 --> Language Class Initialized
INFO - 2018-08-01 02:44:51 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-01 02:44:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-01 02:44:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-01 02:44:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/login.php
ERROR - 2018-08-01 02:44:51 --> 404 Page Not Found: /index
INFO - 2018-08-01 02:44:51 --> Config Class Initialized
INFO - 2018-08-01 02:44:51 --> Hooks Class Initialized
DEBUG - 2018-08-01 02:44:51 --> UTF-8 Support Enabled
INFO - 2018-08-01 02:44:51 --> Utf8 Class Initialized
INFO - 2018-08-01 02:44:51 --> URI Class Initialized
INFO - 2018-08-01 02:44:51 --> Router Class Initialized
INFO - 2018-08-01 02:44:51 --> Output Class Initialized
INFO - 2018-08-01 02:44:51 --> Security Class Initialized
DEBUG - 2018-08-01 02:44:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-01 02:44:51 --> Input Class Initialized
INFO - 2018-08-01 02:44:51 --> Language Class Initialized
ERROR - 2018-08-01 02:44:51 --> 404 Page Not Found: /index
INFO - 2018-08-01 02:44:51 --> Config Class Initialized
INFO - 2018-08-01 02:44:52 --> Hooks Class Initialized
DEBUG - 2018-08-01 02:44:52 --> UTF-8 Support Enabled
INFO - 2018-08-01 02:44:52 --> Utf8 Class Initialized
INFO - 2018-08-01 02:44:52 --> URI Class Initialized
INFO - 2018-08-01 02:44:52 --> Router Class Initialized
INFO - 2018-08-01 02:44:52 --> Output Class Initialized
INFO - 2018-08-01 02:44:52 --> Security Class Initialized
DEBUG - 2018-08-01 02:44:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-01 02:44:52 --> Input Class Initialized
INFO - 2018-08-01 02:44:52 --> Language Class Initialized
ERROR - 2018-08-01 02:44:52 --> 404 Page Not Found: /index
INFO - 2018-08-01 02:44:58 --> Config Class Initialized
INFO - 2018-08-01 02:44:58 --> Hooks Class Initialized
DEBUG - 2018-08-01 02:44:58 --> UTF-8 Support Enabled
INFO - 2018-08-01 02:44:58 --> Utf8 Class Initialized
INFO - 2018-08-01 02:44:58 --> URI Class Initialized
INFO - 2018-08-01 02:44:58 --> Router Class Initialized
INFO - 2018-08-01 02:44:58 --> Output Class Initialized
INFO - 2018-08-01 02:44:58 --> Security Class Initialized
DEBUG - 2018-08-01 02:44:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-01 02:44:58 --> Input Class Initialized
INFO - 2018-08-01 02:44:58 --> Language Class Initialized
INFO - 2018-08-01 02:44:58 --> Language Class Initialized
INFO - 2018-08-01 02:44:58 --> Config Class Initialized
INFO - 2018-08-01 02:44:58 --> Loader Class Initialized
DEBUG - 2018-08-01 02:44:58 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-01 02:44:58 --> Helper loaded: url_helper
INFO - 2018-08-01 02:44:58 --> Helper loaded: form_helper
INFO - 2018-08-01 02:44:58 --> Helper loaded: date_helper
INFO - 2018-08-01 02:44:58 --> Helper loaded: util_helper
INFO - 2018-08-01 02:44:58 --> Helper loaded: text_helper
INFO - 2018-08-01 02:44:58 --> Helper loaded: string_helper
INFO - 2018-08-01 02:44:58 --> Database Driver Class Initialized
DEBUG - 2018-08-01 02:44:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-01 02:44:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-01 02:44:58 --> Email Class Initialized
INFO - 2018-08-01 02:44:58 --> Controller Class Initialized
DEBUG - 2018-08-01 02:44:58 --> Home MX_Controller Initialized
DEBUG - 2018-08-01 02:44:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-01 02:44:58 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-01 02:44:58 --> Login MX_Controller Initialized
INFO - 2018-08-01 02:44:58 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-01 02:44:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-01 02:44:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-01 02:44:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/login.php
INFO - 2018-08-01 02:45:01 --> Config Class Initialized
INFO - 2018-08-01 02:45:01 --> Hooks Class Initialized
DEBUG - 2018-08-01 02:45:01 --> UTF-8 Support Enabled
INFO - 2018-08-01 02:45:01 --> Utf8 Class Initialized
INFO - 2018-08-01 02:45:01 --> URI Class Initialized
INFO - 2018-08-01 02:45:01 --> Router Class Initialized
INFO - 2018-08-01 02:45:01 --> Output Class Initialized
INFO - 2018-08-01 02:45:01 --> Security Class Initialized
DEBUG - 2018-08-01 02:45:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-01 02:45:01 --> Input Class Initialized
INFO - 2018-08-01 02:45:01 --> Language Class Initialized
INFO - 2018-08-01 02:45:01 --> Language Class Initialized
INFO - 2018-08-01 02:45:01 --> Config Class Initialized
INFO - 2018-08-01 02:45:01 --> Loader Class Initialized
DEBUG - 2018-08-01 02:45:01 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-01 02:45:01 --> Helper loaded: url_helper
INFO - 2018-08-01 02:45:01 --> Helper loaded: form_helper
INFO - 2018-08-01 02:45:01 --> Helper loaded: date_helper
INFO - 2018-08-01 02:45:01 --> Helper loaded: util_helper
INFO - 2018-08-01 02:45:01 --> Helper loaded: text_helper
INFO - 2018-08-01 02:45:01 --> Helper loaded: string_helper
INFO - 2018-08-01 02:45:01 --> Database Driver Class Initialized
DEBUG - 2018-08-01 02:45:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-01 02:45:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-01 02:45:01 --> Email Class Initialized
INFO - 2018-08-01 02:45:01 --> Controller Class Initialized
DEBUG - 2018-08-01 02:45:01 --> Home MX_Controller Initialized
DEBUG - 2018-08-01 02:45:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-01 02:45:01 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-01 02:45:01 --> Login MX_Controller Initialized
INFO - 2018-08-01 02:45:01 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-01 02:45:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-01 02:45:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-01 02:45:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/login.php
INFO - 2018-08-01 02:45:08 --> Config Class Initialized
INFO - 2018-08-01 02:45:08 --> Hooks Class Initialized
DEBUG - 2018-08-01 02:45:08 --> UTF-8 Support Enabled
INFO - 2018-08-01 02:45:08 --> Utf8 Class Initialized
INFO - 2018-08-01 02:45:08 --> URI Class Initialized
INFO - 2018-08-01 02:45:08 --> Router Class Initialized
INFO - 2018-08-01 02:45:08 --> Output Class Initialized
INFO - 2018-08-01 02:45:08 --> Security Class Initialized
DEBUG - 2018-08-01 02:45:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-01 02:45:08 --> Input Class Initialized
INFO - 2018-08-01 02:45:08 --> Language Class Initialized
INFO - 2018-08-01 02:45:08 --> Language Class Initialized
INFO - 2018-08-01 02:45:08 --> Config Class Initialized
INFO - 2018-08-01 02:45:08 --> Loader Class Initialized
DEBUG - 2018-08-01 02:45:08 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-01 02:45:08 --> Helper loaded: url_helper
INFO - 2018-08-01 02:45:08 --> Helper loaded: form_helper
INFO - 2018-08-01 02:45:08 --> Helper loaded: date_helper
INFO - 2018-08-01 02:45:08 --> Helper loaded: util_helper
INFO - 2018-08-01 02:45:08 --> Helper loaded: text_helper
INFO - 2018-08-01 02:45:08 --> Helper loaded: string_helper
INFO - 2018-08-01 02:45:08 --> Database Driver Class Initialized
DEBUG - 2018-08-01 02:45:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-01 02:45:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-01 02:45:08 --> Email Class Initialized
INFO - 2018-08-01 02:45:08 --> Controller Class Initialized
DEBUG - 2018-08-01 02:45:08 --> Login MX_Controller Initialized
INFO - 2018-08-01 02:45:08 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-01 02:45:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-01 02:45:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-01 02:45:08 --> Email starts for colinUser fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-08-01 02:45:08 --> User session created for 4
INFO - 2018-08-01 02:45:09 --> Login status colinUser - success
INFO - 2018-08-01 02:45:09 --> Final output sent to browser
DEBUG - 2018-08-01 02:45:09 --> Total execution time: 0.4757
INFO - 2018-08-01 02:45:09 --> Config Class Initialized
INFO - 2018-08-01 02:45:09 --> Hooks Class Initialized
DEBUG - 2018-08-01 02:45:09 --> UTF-8 Support Enabled
INFO - 2018-08-01 02:45:09 --> Utf8 Class Initialized
INFO - 2018-08-01 02:45:09 --> URI Class Initialized
INFO - 2018-08-01 02:45:09 --> Router Class Initialized
INFO - 2018-08-01 02:45:09 --> Output Class Initialized
INFO - 2018-08-01 02:45:09 --> Security Class Initialized
DEBUG - 2018-08-01 02:45:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-01 02:45:09 --> Input Class Initialized
INFO - 2018-08-01 02:45:09 --> Language Class Initialized
INFO - 2018-08-01 02:45:09 --> Language Class Initialized
INFO - 2018-08-01 02:45:09 --> Config Class Initialized
INFO - 2018-08-01 02:45:09 --> Loader Class Initialized
DEBUG - 2018-08-01 02:45:09 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-01 02:45:09 --> Helper loaded: url_helper
INFO - 2018-08-01 02:45:09 --> Helper loaded: form_helper
INFO - 2018-08-01 02:45:09 --> Helper loaded: date_helper
INFO - 2018-08-01 02:45:09 --> Helper loaded: util_helper
INFO - 2018-08-01 02:45:09 --> Helper loaded: text_helper
INFO - 2018-08-01 02:45:09 --> Helper loaded: string_helper
INFO - 2018-08-01 02:45:09 --> Database Driver Class Initialized
DEBUG - 2018-08-01 02:45:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-01 02:45:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-01 02:45:09 --> Email Class Initialized
INFO - 2018-08-01 02:45:09 --> Controller Class Initialized
DEBUG - 2018-08-01 02:45:09 --> Home MX_Controller Initialized
DEBUG - 2018-08-01 02:45:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-01 02:45:09 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-01 02:45:09 --> Login MX_Controller Initialized
INFO - 2018-08-01 02:45:09 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-01 02:45:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-01 02:45:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-01 02:45:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-08-01 02:45:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-08-01 02:45:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-08-01 02:45:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-08-01 02:45:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-08-01 02:45:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-08-01 02:45:09 --> Final output sent to browser
DEBUG - 2018-08-01 02:45:09 --> Total execution time: 0.6251
INFO - 2018-08-01 02:45:10 --> Config Class Initialized
INFO - 2018-08-01 02:45:10 --> Hooks Class Initialized
DEBUG - 2018-08-01 02:45:10 --> UTF-8 Support Enabled
INFO - 2018-08-01 02:45:10 --> Utf8 Class Initialized
INFO - 2018-08-01 02:45:10 --> Config Class Initialized
INFO - 2018-08-01 02:45:10 --> Hooks Class Initialized
INFO - 2018-08-01 02:45:10 --> URI Class Initialized
DEBUG - 2018-08-01 02:45:10 --> UTF-8 Support Enabled
INFO - 2018-08-01 02:45:10 --> Router Class Initialized
INFO - 2018-08-01 02:45:10 --> Utf8 Class Initialized
INFO - 2018-08-01 02:45:10 --> Output Class Initialized
INFO - 2018-08-01 02:45:10 --> URI Class Initialized
INFO - 2018-08-01 02:45:10 --> Security Class Initialized
INFO - 2018-08-01 02:45:10 --> Router Class Initialized
DEBUG - 2018-08-01 02:45:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-01 02:45:10 --> Output Class Initialized
INFO - 2018-08-01 02:45:10 --> Security Class Initialized
INFO - 2018-08-01 02:45:10 --> Input Class Initialized
DEBUG - 2018-08-01 02:45:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-01 02:45:10 --> Input Class Initialized
INFO - 2018-08-01 02:45:10 --> Language Class Initialized
INFO - 2018-08-01 02:45:10 --> Language Class Initialized
INFO - 2018-08-01 02:45:10 --> Config Class Initialized
INFO - 2018-08-01 02:45:10 --> Loader Class Initialized
DEBUG - 2018-08-01 02:45:10 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-01 02:45:10 --> Helper loaded: url_helper
INFO - 2018-08-01 02:45:10 --> Language Class Initialized
INFO - 2018-08-01 02:45:10 --> Helper loaded: form_helper
ERROR - 2018-08-01 02:45:10 --> 404 Page Not Found: /index
INFO - 2018-08-01 02:45:10 --> Helper loaded: date_helper
INFO - 2018-08-01 02:45:10 --> Config Class Initialized
INFO - 2018-08-01 02:45:10 --> Hooks Class Initialized
INFO - 2018-08-01 02:45:10 --> Helper loaded: util_helper
DEBUG - 2018-08-01 02:45:10 --> UTF-8 Support Enabled
INFO - 2018-08-01 02:45:10 --> Utf8 Class Initialized
INFO - 2018-08-01 02:45:10 --> Helper loaded: text_helper
INFO - 2018-08-01 02:45:10 --> URI Class Initialized
INFO - 2018-08-01 02:45:10 --> Helper loaded: string_helper
INFO - 2018-08-01 02:45:10 --> Router Class Initialized
INFO - 2018-08-01 02:45:10 --> Output Class Initialized
INFO - 2018-08-01 02:45:10 --> Database Driver Class Initialized
INFO - 2018-08-01 02:45:10 --> Security Class Initialized
DEBUG - 2018-08-01 02:45:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-01 02:45:10 --> Input Class Initialized
DEBUG - 2018-08-01 02:45:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-01 02:45:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-01 02:45:10 --> Language Class Initialized
ERROR - 2018-08-01 02:45:10 --> 404 Page Not Found: /index
INFO - 2018-08-01 02:45:10 --> Email Class Initialized
INFO - 2018-08-01 02:45:10 --> Controller Class Initialized
INFO - 2018-08-01 02:45:10 --> Config Class Initialized
INFO - 2018-08-01 02:45:10 --> Hooks Class Initialized
DEBUG - 2018-08-01 02:45:10 --> Home MX_Controller Initialized
DEBUG - 2018-08-01 02:45:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-01 02:45:10 --> UTF-8 Support Enabled
INFO - 2018-08-01 02:45:10 --> Utf8 Class Initialized
INFO - 2018-08-01 02:45:10 --> URI Class Initialized
DEBUG - 2018-08-01 02:45:10 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
INFO - 2018-08-01 02:45:10 --> Router Class Initialized
DEBUG - 2018-08-01 02:45:10 --> Login MX_Controller Initialized
INFO - 2018-08-01 02:45:10 --> Output Class Initialized
INFO - 2018-08-01 02:45:10 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-01 02:45:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-01 02:45:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-01 02:45:11 --> Config Class Initialized
INFO - 2018-08-01 02:45:11 --> Security Class Initialized
INFO - 2018-08-01 02:45:11 --> Hooks Class Initialized
DEBUG - 2018-08-01 02:45:11 --> UTF-8 Support Enabled
INFO - 2018-08-01 02:45:11 --> Utf8 Class Initialized
INFO - 2018-08-01 02:45:11 --> URI Class Initialized
INFO - 2018-08-01 02:45:11 --> Router Class Initialized
INFO - 2018-08-01 02:45:11 --> Output Class Initialized
INFO - 2018-08-01 02:45:11 --> Security Class Initialized
DEBUG - 2018-08-01 02:45:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-08-01 02:45:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-01 02:45:11 --> Input Class Initialized
INFO - 2018-08-01 02:45:11 --> Input Class Initialized
INFO - 2018-08-01 02:45:11 --> Language Class Initialized
INFO - 2018-08-01 02:45:11 --> Language Class Initialized
ERROR - 2018-08-01 02:45:11 --> 404 Page Not Found: /index
ERROR - 2018-08-01 02:45:11 --> 404 Page Not Found: /index
INFO - 2018-08-01 02:45:11 --> Config Class Initialized
INFO - 2018-08-01 02:45:11 --> Hooks Class Initialized
DEBUG - 2018-08-01 02:45:11 --> UTF-8 Support Enabled
INFO - 2018-08-01 02:45:11 --> Utf8 Class Initialized
INFO - 2018-08-01 02:45:11 --> URI Class Initialized
INFO - 2018-08-01 02:45:11 --> Router Class Initialized
INFO - 2018-08-01 02:45:11 --> Output Class Initialized
INFO - 2018-08-01 02:45:11 --> Security Class Initialized
DEBUG - 2018-08-01 02:45:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-01 02:45:11 --> Input Class Initialized
INFO - 2018-08-01 02:45:11 --> Language Class Initialized
ERROR - 2018-08-01 02:45:11 --> 404 Page Not Found: /index
INFO - 2018-08-01 02:45:11 --> Config Class Initialized
INFO - 2018-08-01 02:45:11 --> Hooks Class Initialized
DEBUG - 2018-08-01 02:45:11 --> UTF-8 Support Enabled
INFO - 2018-08-01 02:45:11 --> Utf8 Class Initialized
INFO - 2018-08-01 02:45:11 --> URI Class Initialized
INFO - 2018-08-01 02:45:11 --> Router Class Initialized
INFO - 2018-08-01 02:45:11 --> Output Class Initialized
INFO - 2018-08-01 02:45:11 --> Security Class Initialized
DEBUG - 2018-08-01 02:45:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-01 02:45:11 --> Input Class Initialized
INFO - 2018-08-01 02:45:11 --> Language Class Initialized
ERROR - 2018-08-01 02:45:11 --> 404 Page Not Found: /index
INFO - 2018-08-01 02:45:11 --> Config Class Initialized
INFO - 2018-08-01 02:45:11 --> Hooks Class Initialized
DEBUG - 2018-08-01 02:45:11 --> UTF-8 Support Enabled
INFO - 2018-08-01 02:45:11 --> Utf8 Class Initialized
INFO - 2018-08-01 02:45:11 --> URI Class Initialized
INFO - 2018-08-01 02:45:11 --> Router Class Initialized
INFO - 2018-08-01 02:45:11 --> Output Class Initialized
INFO - 2018-08-01 02:45:11 --> Security Class Initialized
DEBUG - 2018-08-01 02:45:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-01 02:45:11 --> Input Class Initialized
INFO - 2018-08-01 02:45:11 --> Language Class Initialized
ERROR - 2018-08-01 02:45:11 --> 404 Page Not Found: /index
INFO - 2018-08-01 02:45:11 --> Config Class Initialized
INFO - 2018-08-01 02:45:11 --> Hooks Class Initialized
DEBUG - 2018-08-01 02:45:11 --> UTF-8 Support Enabled
INFO - 2018-08-01 02:45:11 --> Utf8 Class Initialized
INFO - 2018-08-01 02:45:11 --> URI Class Initialized
INFO - 2018-08-01 02:45:11 --> Router Class Initialized
INFO - 2018-08-01 02:45:12 --> Output Class Initialized
INFO - 2018-08-01 02:45:12 --> Security Class Initialized
DEBUG - 2018-08-01 02:45:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-01 02:45:12 --> Input Class Initialized
INFO - 2018-08-01 02:45:12 --> Language Class Initialized
ERROR - 2018-08-01 02:45:12 --> 404 Page Not Found: /index
INFO - 2018-08-01 02:45:12 --> Config Class Initialized
INFO - 2018-08-01 02:45:12 --> Hooks Class Initialized
DEBUG - 2018-08-01 02:45:12 --> UTF-8 Support Enabled
INFO - 2018-08-01 02:45:12 --> Utf8 Class Initialized
INFO - 2018-08-01 02:45:12 --> URI Class Initialized
INFO - 2018-08-01 02:45:12 --> Router Class Initialized
INFO - 2018-08-01 02:45:12 --> Output Class Initialized
INFO - 2018-08-01 02:45:12 --> Security Class Initialized
DEBUG - 2018-08-01 02:45:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-01 02:45:12 --> Input Class Initialized
INFO - 2018-08-01 02:45:12 --> Language Class Initialized
ERROR - 2018-08-01 02:45:12 --> 404 Page Not Found: /index
INFO - 2018-08-01 02:45:12 --> Config Class Initialized
INFO - 2018-08-01 02:45:12 --> Hooks Class Initialized
DEBUG - 2018-08-01 02:45:12 --> UTF-8 Support Enabled
INFO - 2018-08-01 02:45:12 --> Utf8 Class Initialized
INFO - 2018-08-01 02:45:12 --> URI Class Initialized
INFO - 2018-08-01 02:45:12 --> Router Class Initialized
INFO - 2018-08-01 02:45:12 --> Output Class Initialized
INFO - 2018-08-01 02:45:12 --> Security Class Initialized
DEBUG - 2018-08-01 02:45:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-01 02:45:12 --> Input Class Initialized
INFO - 2018-08-01 02:45:12 --> Language Class Initialized
ERROR - 2018-08-01 02:45:12 --> 404 Page Not Found: /index
INFO - 2018-08-01 02:45:16 --> Config Class Initialized
INFO - 2018-08-01 02:45:16 --> Hooks Class Initialized
DEBUG - 2018-08-01 02:45:16 --> UTF-8 Support Enabled
INFO - 2018-08-01 02:45:16 --> Config Class Initialized
INFO - 2018-08-01 02:45:16 --> Hooks Class Initialized
INFO - 2018-08-01 02:45:16 --> Utf8 Class Initialized
DEBUG - 2018-08-01 02:45:16 --> UTF-8 Support Enabled
INFO - 2018-08-01 02:45:16 --> URI Class Initialized
INFO - 2018-08-01 02:45:16 --> Utf8 Class Initialized
INFO - 2018-08-01 02:45:16 --> URI Class Initialized
INFO - 2018-08-01 02:45:16 --> Router Class Initialized
INFO - 2018-08-01 02:45:16 --> Router Class Initialized
INFO - 2018-08-01 02:45:16 --> Output Class Initialized
INFO - 2018-08-01 02:45:16 --> Security Class Initialized
DEBUG - 2018-08-01 02:45:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-01 02:45:16 --> Input Class Initialized
INFO - 2018-08-01 02:45:16 --> Language Class Initialized
ERROR - 2018-08-01 02:45:16 --> 404 Page Not Found: /index
INFO - 2018-08-01 02:45:16 --> Config Class Initialized
INFO - 2018-08-01 02:45:16 --> Hooks Class Initialized
DEBUG - 2018-08-01 02:45:16 --> UTF-8 Support Enabled
INFO - 2018-08-01 02:45:16 --> Output Class Initialized
INFO - 2018-08-01 02:45:16 --> Utf8 Class Initialized
INFO - 2018-08-01 02:45:16 --> URI Class Initialized
INFO - 2018-08-01 02:45:16 --> Router Class Initialized
INFO - 2018-08-01 02:45:16 --> Security Class Initialized
INFO - 2018-08-01 02:45:16 --> Output Class Initialized
INFO - 2018-08-01 02:45:16 --> Security Class Initialized
DEBUG - 2018-08-01 02:45:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-01 02:45:16 --> Input Class Initialized
INFO - 2018-08-01 02:45:16 --> Language Class Initialized
ERROR - 2018-08-01 02:45:16 --> 404 Page Not Found: /index
INFO - 2018-08-01 02:45:16 --> Config Class Initialized
INFO - 2018-08-01 02:45:16 --> Hooks Class Initialized
DEBUG - 2018-08-01 02:45:16 --> UTF-8 Support Enabled
DEBUG - 2018-08-01 02:45:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-01 02:45:16 --> Utf8 Class Initialized
INFO - 2018-08-01 02:45:16 --> URI Class Initialized
INFO - 2018-08-01 02:45:16 --> Router Class Initialized
INFO - 2018-08-01 02:45:16 --> Output Class Initialized
INFO - 2018-08-01 02:45:16 --> Security Class Initialized
DEBUG - 2018-08-01 02:45:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-01 02:45:16 --> Input Class Initialized
INFO - 2018-08-01 02:45:16 --> Language Class Initialized
ERROR - 2018-08-01 02:45:16 --> 404 Page Not Found: /index
INFO - 2018-08-01 02:45:16 --> Input Class Initialized
INFO - 2018-08-01 02:45:16 --> Language Class Initialized
INFO - 2018-08-01 02:45:16 --> Language Class Initialized
INFO - 2018-08-01 02:45:16 --> Config Class Initialized
INFO - 2018-08-01 02:45:16 --> Loader Class Initialized
DEBUG - 2018-08-01 02:45:16 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-01 02:45:16 --> Helper loaded: url_helper
INFO - 2018-08-01 02:45:16 --> Helper loaded: form_helper
INFO - 2018-08-01 02:45:16 --> Helper loaded: date_helper
INFO - 2018-08-01 02:45:16 --> Helper loaded: util_helper
INFO - 2018-08-01 02:45:16 --> Helper loaded: text_helper
INFO - 2018-08-01 02:45:16 --> Helper loaded: string_helper
INFO - 2018-08-01 02:45:16 --> Database Driver Class Initialized
DEBUG - 2018-08-01 02:45:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-01 02:45:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-01 02:45:16 --> Email Class Initialized
INFO - 2018-08-01 02:45:16 --> Controller Class Initialized
DEBUG - 2018-08-01 02:45:16 --> Home MX_Controller Initialized
DEBUG - 2018-08-01 02:45:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-01 02:45:16 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-01 02:45:16 --> Login MX_Controller Initialized
INFO - 2018-08-01 02:45:16 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-01 02:45:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-01 02:45:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-01 02:45:17 --> Config Class Initialized
INFO - 2018-08-01 02:45:17 --> Hooks Class Initialized
DEBUG - 2018-08-01 02:45:17 --> UTF-8 Support Enabled
INFO - 2018-08-01 02:45:17 --> Utf8 Class Initialized
INFO - 2018-08-01 02:45:17 --> URI Class Initialized
INFO - 2018-08-01 02:45:17 --> Router Class Initialized
INFO - 2018-08-01 02:45:17 --> Output Class Initialized
INFO - 2018-08-01 02:45:17 --> Security Class Initialized
DEBUG - 2018-08-01 02:45:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-01 02:45:17 --> Input Class Initialized
INFO - 2018-08-01 02:45:17 --> Language Class Initialized
INFO - 2018-08-01 02:45:17 --> Language Class Initialized
INFO - 2018-08-01 02:45:17 --> Config Class Initialized
INFO - 2018-08-01 02:45:17 --> Loader Class Initialized
DEBUG - 2018-08-01 02:45:17 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-01 02:45:17 --> Helper loaded: url_helper
INFO - 2018-08-01 02:45:17 --> Helper loaded: form_helper
INFO - 2018-08-01 02:45:17 --> Helper loaded: date_helper
INFO - 2018-08-01 02:45:17 --> Helper loaded: util_helper
INFO - 2018-08-01 02:45:17 --> Helper loaded: text_helper
INFO - 2018-08-01 02:45:17 --> Helper loaded: string_helper
INFO - 2018-08-01 02:45:17 --> Database Driver Class Initialized
DEBUG - 2018-08-01 02:45:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-01 02:45:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-01 02:45:17 --> Email Class Initialized
INFO - 2018-08-01 02:45:17 --> Controller Class Initialized
DEBUG - 2018-08-01 02:45:17 --> Home MX_Controller Initialized
DEBUG - 2018-08-01 02:45:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-01 02:45:17 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-01 02:45:17 --> Login MX_Controller Initialized
INFO - 2018-08-01 02:45:17 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-01 02:45:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-01 02:45:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-01 02:45:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-08-01 02:45:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-08-01 02:45:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-08-01 02:45:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-08-01 02:45:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-08-01 02:45:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-08-01 02:45:17 --> Final output sent to browser
DEBUG - 2018-08-01 02:45:17 --> Total execution time: 0.4261
INFO - 2018-08-01 02:45:18 --> Config Class Initialized
INFO - 2018-08-01 02:45:18 --> Hooks Class Initialized
DEBUG - 2018-08-01 02:45:18 --> UTF-8 Support Enabled
INFO - 2018-08-01 02:45:18 --> Utf8 Class Initialized
INFO - 2018-08-01 02:45:18 --> URI Class Initialized
INFO - 2018-08-01 02:45:18 --> Config Class Initialized
INFO - 2018-08-01 02:45:18 --> Hooks Class Initialized
INFO - 2018-08-01 02:45:18 --> Router Class Initialized
INFO - 2018-08-01 02:45:18 --> Output Class Initialized
DEBUG - 2018-08-01 02:45:18 --> UTF-8 Support Enabled
INFO - 2018-08-01 02:45:18 --> Utf8 Class Initialized
INFO - 2018-08-01 02:45:18 --> Security Class Initialized
DEBUG - 2018-08-01 02:45:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-01 02:45:18 --> URI Class Initialized
INFO - 2018-08-01 02:45:18 --> Input Class Initialized
INFO - 2018-08-01 02:45:18 --> Language Class Initialized
INFO - 2018-08-01 02:45:18 --> Router Class Initialized
INFO - 2018-08-01 02:45:18 --> Output Class Initialized
ERROR - 2018-08-01 02:45:18 --> 404 Page Not Found: /index
INFO - 2018-08-01 02:45:18 --> Security Class Initialized
DEBUG - 2018-08-01 02:45:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-01 02:45:18 --> Input Class Initialized
INFO - 2018-08-01 02:45:18 --> Language Class Initialized
INFO - 2018-08-01 02:45:18 --> Language Class Initialized
INFO - 2018-08-01 02:45:18 --> Config Class Initialized
INFO - 2018-08-01 02:45:18 --> Config Class Initialized
INFO - 2018-08-01 02:45:18 --> Hooks Class Initialized
INFO - 2018-08-01 02:45:18 --> Loader Class Initialized
DEBUG - 2018-08-01 02:45:18 --> UTF-8 Support Enabled
INFO - 2018-08-01 02:45:18 --> Utf8 Class Initialized
INFO - 2018-08-01 02:45:18 --> URI Class Initialized
INFO - 2018-08-01 02:45:18 --> Router Class Initialized
INFO - 2018-08-01 02:45:18 --> Output Class Initialized
INFO - 2018-08-01 02:45:18 --> Security Class Initialized
DEBUG - 2018-08-01 02:45:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-01 02:45:18 --> Input Class Initialized
INFO - 2018-08-01 02:45:18 --> Language Class Initialized
DEBUG - 2018-08-01 02:45:18 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
ERROR - 2018-08-01 02:45:18 --> 404 Page Not Found: /index
INFO - 2018-08-01 02:45:18 --> Helper loaded: url_helper
INFO - 2018-08-01 02:45:18 --> Config Class Initialized
INFO - 2018-08-01 02:45:18 --> Hooks Class Initialized
INFO - 2018-08-01 02:45:18 --> Helper loaded: form_helper
INFO - 2018-08-01 02:45:18 --> Helper loaded: date_helper
DEBUG - 2018-08-01 02:45:18 --> UTF-8 Support Enabled
INFO - 2018-08-01 02:45:18 --> Utf8 Class Initialized
INFO - 2018-08-01 02:45:18 --> Helper loaded: util_helper
INFO - 2018-08-01 02:45:18 --> Helper loaded: text_helper
INFO - 2018-08-01 02:45:18 --> URI Class Initialized
INFO - 2018-08-01 02:45:18 --> Helper loaded: string_helper
INFO - 2018-08-01 02:45:18 --> Router Class Initialized
INFO - 2018-08-01 02:45:18 --> Output Class Initialized
INFO - 2018-08-01 02:45:18 --> Database Driver Class Initialized
INFO - 2018-08-01 02:45:18 --> Security Class Initialized
DEBUG - 2018-08-01 02:45:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-01 02:45:18 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-08-01 02:45:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-01 02:45:18 --> Email Class Initialized
INFO - 2018-08-01 02:45:18 --> Input Class Initialized
INFO - 2018-08-01 02:45:18 --> Controller Class Initialized
INFO - 2018-08-01 02:45:18 --> Language Class Initialized
DEBUG - 2018-08-01 02:45:18 --> Home MX_Controller Initialized
ERROR - 2018-08-01 02:45:18 --> 404 Page Not Found: /index
DEBUG - 2018-08-01 02:45:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-01 02:45:19 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-01 02:45:19 --> Login MX_Controller Initialized
INFO - 2018-08-01 02:45:19 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-01 02:45:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-01 02:45:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-01 02:45:19 --> Config Class Initialized
INFO - 2018-08-01 02:45:19 --> Hooks Class Initialized
DEBUG - 2018-08-01 02:45:19 --> UTF-8 Support Enabled
INFO - 2018-08-01 02:45:19 --> Utf8 Class Initialized
INFO - 2018-08-01 02:45:19 --> URI Class Initialized
INFO - 2018-08-01 02:45:19 --> Router Class Initialized
INFO - 2018-08-01 02:45:19 --> Output Class Initialized
INFO - 2018-08-01 02:45:19 --> Security Class Initialized
DEBUG - 2018-08-01 02:45:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-01 02:45:19 --> Input Class Initialized
INFO - 2018-08-01 02:45:19 --> Language Class Initialized
INFO - 2018-08-01 02:45:19 --> Language Class Initialized
INFO - 2018-08-01 02:45:19 --> Config Class Initialized
INFO - 2018-08-01 02:45:19 --> Loader Class Initialized
DEBUG - 2018-08-01 02:45:19 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-01 02:45:19 --> Helper loaded: url_helper
INFO - 2018-08-01 02:45:20 --> Helper loaded: form_helper
INFO - 2018-08-01 02:45:20 --> Helper loaded: date_helper
INFO - 2018-08-01 02:45:20 --> Helper loaded: util_helper
INFO - 2018-08-01 02:45:20 --> Helper loaded: text_helper
INFO - 2018-08-01 02:45:20 --> Helper loaded: string_helper
INFO - 2018-08-01 02:45:20 --> Database Driver Class Initialized
DEBUG - 2018-08-01 02:45:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-01 02:45:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-01 02:45:20 --> Email Class Initialized
INFO - 2018-08-01 02:45:20 --> Controller Class Initialized
DEBUG - 2018-08-01 02:45:20 --> Login MX_Controller Initialized
INFO - 2018-08-01 02:45:20 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-01 02:45:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-01 02:45:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-01 02:45:20 --> 4 Loggedout
INFO - 2018-08-01 02:45:20 --> Config Class Initialized
INFO - 2018-08-01 02:45:20 --> Hooks Class Initialized
DEBUG - 2018-08-01 02:45:20 --> UTF-8 Support Enabled
INFO - 2018-08-01 02:45:20 --> Utf8 Class Initialized
INFO - 2018-08-01 02:45:20 --> URI Class Initialized
INFO - 2018-08-01 02:45:20 --> Router Class Initialized
INFO - 2018-08-01 02:45:20 --> Output Class Initialized
INFO - 2018-08-01 02:45:20 --> Security Class Initialized
DEBUG - 2018-08-01 02:45:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-01 02:45:20 --> Input Class Initialized
INFO - 2018-08-01 02:45:20 --> Language Class Initialized
INFO - 2018-08-01 02:45:20 --> Language Class Initialized
INFO - 2018-08-01 02:45:20 --> Config Class Initialized
INFO - 2018-08-01 02:45:20 --> Loader Class Initialized
DEBUG - 2018-08-01 02:45:20 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-01 02:45:20 --> Helper loaded: url_helper
INFO - 2018-08-01 02:45:20 --> Helper loaded: form_helper
INFO - 2018-08-01 02:45:20 --> Helper loaded: date_helper
INFO - 2018-08-01 02:45:20 --> Helper loaded: util_helper
INFO - 2018-08-01 02:45:20 --> Helper loaded: text_helper
INFO - 2018-08-01 02:45:20 --> Helper loaded: string_helper
INFO - 2018-08-01 02:45:20 --> Database Driver Class Initialized
DEBUG - 2018-08-01 02:45:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-01 02:45:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-01 02:45:20 --> Email Class Initialized
INFO - 2018-08-01 02:45:20 --> Controller Class Initialized
DEBUG - 2018-08-01 02:45:20 --> Home MX_Controller Initialized
DEBUG - 2018-08-01 02:45:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-01 02:45:20 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-01 02:45:20 --> Login MX_Controller Initialized
INFO - 2018-08-01 02:45:20 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-01 02:45:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-01 02:45:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-01 02:45:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/login.php
INFO - 2018-08-01 02:45:26 --> Config Class Initialized
INFO - 2018-08-01 02:45:26 --> Hooks Class Initialized
DEBUG - 2018-08-01 02:45:26 --> UTF-8 Support Enabled
INFO - 2018-08-01 02:45:26 --> Utf8 Class Initialized
INFO - 2018-08-01 02:45:26 --> URI Class Initialized
INFO - 2018-08-01 02:45:26 --> Router Class Initialized
INFO - 2018-08-01 02:45:26 --> Output Class Initialized
INFO - 2018-08-01 02:45:26 --> Security Class Initialized
DEBUG - 2018-08-01 02:45:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-01 02:45:26 --> Input Class Initialized
INFO - 2018-08-01 02:45:26 --> Language Class Initialized
INFO - 2018-08-01 02:45:26 --> Language Class Initialized
INFO - 2018-08-01 02:45:26 --> Config Class Initialized
INFO - 2018-08-01 02:45:26 --> Loader Class Initialized
DEBUG - 2018-08-01 02:45:26 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-01 02:45:26 --> Helper loaded: url_helper
INFO - 2018-08-01 02:45:26 --> Helper loaded: form_helper
INFO - 2018-08-01 02:45:26 --> Helper loaded: date_helper
INFO - 2018-08-01 02:45:26 --> Helper loaded: util_helper
INFO - 2018-08-01 02:45:26 --> Helper loaded: text_helper
INFO - 2018-08-01 02:45:26 --> Helper loaded: string_helper
INFO - 2018-08-01 02:45:26 --> Database Driver Class Initialized
DEBUG - 2018-08-01 02:45:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-01 02:45:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-01 02:45:26 --> Email Class Initialized
INFO - 2018-08-01 02:45:26 --> Controller Class Initialized
DEBUG - 2018-08-01 02:45:26 --> Login MX_Controller Initialized
INFO - 2018-08-01 02:45:26 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-01 02:45:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-01 02:45:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-01 02:45:26 --> Email starts for colinUser fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-08-01 02:45:26 --> User session created for 4
INFO - 2018-08-01 02:45:26 --> Login status colinUser - success
INFO - 2018-08-01 02:45:26 --> Final output sent to browser
DEBUG - 2018-08-01 02:45:26 --> Total execution time: 0.3598
INFO - 2018-08-01 02:45:26 --> Config Class Initialized
INFO - 2018-08-01 02:45:26 --> Hooks Class Initialized
DEBUG - 2018-08-01 02:45:26 --> UTF-8 Support Enabled
INFO - 2018-08-01 02:45:26 --> Utf8 Class Initialized
INFO - 2018-08-01 02:45:26 --> URI Class Initialized
INFO - 2018-08-01 02:45:26 --> Router Class Initialized
INFO - 2018-08-01 02:45:26 --> Output Class Initialized
INFO - 2018-08-01 02:45:26 --> Security Class Initialized
DEBUG - 2018-08-01 02:45:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-01 02:45:26 --> Input Class Initialized
INFO - 2018-08-01 02:45:26 --> Language Class Initialized
INFO - 2018-08-01 02:45:26 --> Language Class Initialized
INFO - 2018-08-01 02:45:26 --> Config Class Initialized
INFO - 2018-08-01 02:45:26 --> Loader Class Initialized
DEBUG - 2018-08-01 02:45:26 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-01 02:45:26 --> Helper loaded: url_helper
INFO - 2018-08-01 02:45:26 --> Helper loaded: form_helper
INFO - 2018-08-01 02:45:26 --> Helper loaded: date_helper
INFO - 2018-08-01 02:45:26 --> Helper loaded: util_helper
INFO - 2018-08-01 02:45:26 --> Helper loaded: text_helper
INFO - 2018-08-01 02:45:26 --> Helper loaded: string_helper
INFO - 2018-08-01 02:45:26 --> Database Driver Class Initialized
DEBUG - 2018-08-01 02:45:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-01 02:45:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-01 02:45:27 --> Email Class Initialized
INFO - 2018-08-01 02:45:27 --> Controller Class Initialized
DEBUG - 2018-08-01 02:45:27 --> Home MX_Controller Initialized
DEBUG - 2018-08-01 02:45:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-01 02:45:27 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-01 02:45:27 --> Login MX_Controller Initialized
INFO - 2018-08-01 02:45:27 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-01 02:45:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-01 02:45:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-01 02:45:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-08-01 02:45:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-08-01 02:45:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-08-01 02:45:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-08-01 02:45:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-08-01 02:45:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-08-01 02:45:27 --> Final output sent to browser
DEBUG - 2018-08-01 02:45:27 --> Total execution time: 0.4462
INFO - 2018-08-01 02:45:27 --> Config Class Initialized
INFO - 2018-08-01 02:45:27 --> Hooks Class Initialized
DEBUG - 2018-08-01 02:45:27 --> UTF-8 Support Enabled
INFO - 2018-08-01 02:45:27 --> Utf8 Class Initialized
INFO - 2018-08-01 02:45:27 --> Config Class Initialized
INFO - 2018-08-01 02:45:27 --> Hooks Class Initialized
INFO - 2018-08-01 02:45:27 --> URI Class Initialized
DEBUG - 2018-08-01 02:45:27 --> UTF-8 Support Enabled
INFO - 2018-08-01 02:45:27 --> Utf8 Class Initialized
INFO - 2018-08-01 02:45:27 --> URI Class Initialized
INFO - 2018-08-01 02:45:27 --> Router Class Initialized
INFO - 2018-08-01 02:45:27 --> Output Class Initialized
INFO - 2018-08-01 02:45:27 --> Router Class Initialized
INFO - 2018-08-01 02:45:27 --> Output Class Initialized
INFO - 2018-08-01 02:45:27 --> Security Class Initialized
DEBUG - 2018-08-01 02:45:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-01 02:45:27 --> Security Class Initialized
INFO - 2018-08-01 02:45:27 --> Input Class Initialized
DEBUG - 2018-08-01 02:45:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-01 02:45:27 --> Language Class Initialized
INFO - 2018-08-01 02:45:27 --> Input Class Initialized
INFO - 2018-08-01 02:45:27 --> Language Class Initialized
INFO - 2018-08-01 02:45:27 --> Language Class Initialized
INFO - 2018-08-01 02:45:27 --> Config Class Initialized
INFO - 2018-08-01 02:45:28 --> Loader Class Initialized
DEBUG - 2018-08-01 02:45:28 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-01 02:45:28 --> Helper loaded: url_helper
INFO - 2018-08-01 02:45:28 --> Helper loaded: form_helper
ERROR - 2018-08-01 02:45:28 --> 404 Page Not Found: /index
INFO - 2018-08-01 02:45:28 --> Helper loaded: date_helper
INFO - 2018-08-01 02:45:28 --> Helper loaded: util_helper
INFO - 2018-08-01 02:45:28 --> Config Class Initialized
INFO - 2018-08-01 02:45:28 --> Hooks Class Initialized
INFO - 2018-08-01 02:45:28 --> Helper loaded: text_helper
DEBUG - 2018-08-01 02:45:28 --> UTF-8 Support Enabled
INFO - 2018-08-01 02:45:28 --> Utf8 Class Initialized
INFO - 2018-08-01 02:45:28 --> Config Class Initialized
INFO - 2018-08-01 02:45:28 --> Hooks Class Initialized
INFO - 2018-08-01 02:45:28 --> URI Class Initialized
DEBUG - 2018-08-01 02:45:28 --> UTF-8 Support Enabled
INFO - 2018-08-01 02:45:28 --> Utf8 Class Initialized
INFO - 2018-08-01 02:45:28 --> URI Class Initialized
INFO - 2018-08-01 02:45:28 --> Router Class Initialized
INFO - 2018-08-01 02:45:28 --> Helper loaded: string_helper
INFO - 2018-08-01 02:45:28 --> Router Class Initialized
INFO - 2018-08-01 02:45:28 --> Output Class Initialized
INFO - 2018-08-01 02:45:28 --> Output Class Initialized
INFO - 2018-08-01 02:45:28 --> Database Driver Class Initialized
INFO - 2018-08-01 02:45:28 --> Security Class Initialized
DEBUG - 2018-08-01 02:45:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-01 02:45:28 --> Input Class Initialized
INFO - 2018-08-01 02:45:28 --> Language Class Initialized
ERROR - 2018-08-01 02:45:28 --> 404 Page Not Found: /index
INFO - 2018-08-01 02:45:28 --> Config Class Initialized
INFO - 2018-08-01 02:45:28 --> Security Class Initialized
INFO - 2018-08-01 02:45:28 --> Hooks Class Initialized
DEBUG - 2018-08-01 02:45:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-08-01 02:45:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-01 02:45:28 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-08-01 02:45:28 --> UTF-8 Support Enabled
INFO - 2018-08-01 02:45:28 --> Input Class Initialized
INFO - 2018-08-01 02:45:28 --> Utf8 Class Initialized
INFO - 2018-08-01 02:45:28 --> Email Class Initialized
INFO - 2018-08-01 02:45:28 --> Language Class Initialized
INFO - 2018-08-01 02:45:28 --> Controller Class Initialized
INFO - 2018-08-01 02:45:28 --> URI Class Initialized
ERROR - 2018-08-01 02:45:28 --> 404 Page Not Found: /index
DEBUG - 2018-08-01 02:45:28 --> Home MX_Controller Initialized
INFO - 2018-08-01 02:45:28 --> Router Class Initialized
DEBUG - 2018-08-01 02:45:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-08-01 02:45:28 --> Output Class Initialized
INFO - 2018-08-01 02:45:28 --> Config Class Initialized
INFO - 2018-08-01 02:45:28 --> Security Class Initialized
DEBUG - 2018-08-01 02:45:28 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-01 02:45:28 --> Login MX_Controller Initialized
INFO - 2018-08-01 02:45:28 --> Hooks Class Initialized
DEBUG - 2018-08-01 02:45:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-01 02:45:28 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-01 02:45:28 --> UTF-8 Support Enabled
INFO - 2018-08-01 02:45:28 --> Utf8 Class Initialized
INFO - 2018-08-01 02:45:28 --> Input Class Initialized
DEBUG - 2018-08-01 02:45:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-08-01 02:45:28 --> URI Class Initialized
INFO - 2018-08-01 02:45:28 --> Language Class Initialized
DEBUG - 2018-08-01 02:45:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
ERROR - 2018-08-01 02:45:28 --> 404 Page Not Found: /index
INFO - 2018-08-01 02:45:28 --> Router Class Initialized
INFO - 2018-08-01 02:45:28 --> Config Class Initialized
INFO - 2018-08-01 02:45:28 --> Hooks Class Initialized
INFO - 2018-08-01 02:45:28 --> Output Class Initialized
INFO - 2018-08-01 02:45:28 --> Security Class Initialized
DEBUG - 2018-08-01 02:45:28 --> UTF-8 Support Enabled
INFO - 2018-08-01 02:45:28 --> Utf8 Class Initialized
DEBUG - 2018-08-01 02:45:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-01 02:45:28 --> URI Class Initialized
INFO - 2018-08-01 02:45:28 --> Input Class Initialized
INFO - 2018-08-01 02:45:28 --> Language Class Initialized
INFO - 2018-08-01 02:45:28 --> Router Class Initialized
ERROR - 2018-08-01 02:45:28 --> 404 Page Not Found: /index
INFO - 2018-08-01 02:45:28 --> Output Class Initialized
INFO - 2018-08-01 02:45:28 --> Security Class Initialized
DEBUG - 2018-08-01 02:45:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-01 02:45:28 --> Input Class Initialized
INFO - 2018-08-01 02:45:28 --> Language Class Initialized
ERROR - 2018-08-01 02:45:28 --> 404 Page Not Found: /index
INFO - 2018-08-01 02:45:28 --> Config Class Initialized
INFO - 2018-08-01 02:45:28 --> Hooks Class Initialized
DEBUG - 2018-08-01 02:45:28 --> UTF-8 Support Enabled
INFO - 2018-08-01 02:45:28 --> Utf8 Class Initialized
INFO - 2018-08-01 02:45:28 --> URI Class Initialized
INFO - 2018-08-01 02:45:28 --> Router Class Initialized
INFO - 2018-08-01 02:45:28 --> Output Class Initialized
INFO - 2018-08-01 02:45:28 --> Security Class Initialized
DEBUG - 2018-08-01 02:45:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-01 02:45:28 --> Input Class Initialized
INFO - 2018-08-01 02:45:29 --> Language Class Initialized
ERROR - 2018-08-01 02:45:29 --> 404 Page Not Found: /index
INFO - 2018-08-01 02:47:45 --> Config Class Initialized
INFO - 2018-08-01 02:47:45 --> Hooks Class Initialized
DEBUG - 2018-08-01 02:47:45 --> UTF-8 Support Enabled
INFO - 2018-08-01 02:47:45 --> Utf8 Class Initialized
INFO - 2018-08-01 02:47:45 --> URI Class Initialized
INFO - 2018-08-01 02:47:45 --> Router Class Initialized
INFO - 2018-08-01 02:47:45 --> Output Class Initialized
INFO - 2018-08-01 02:47:45 --> Security Class Initialized
DEBUG - 2018-08-01 02:47:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-01 02:47:45 --> Input Class Initialized
INFO - 2018-08-01 02:47:45 --> Language Class Initialized
INFO - 2018-08-01 02:47:45 --> Language Class Initialized
INFO - 2018-08-01 02:47:45 --> Config Class Initialized
INFO - 2018-08-01 02:47:45 --> Loader Class Initialized
DEBUG - 2018-08-01 02:47:45 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-01 02:47:45 --> Helper loaded: url_helper
INFO - 2018-08-01 02:47:45 --> Helper loaded: form_helper
INFO - 2018-08-01 02:47:45 --> Helper loaded: date_helper
INFO - 2018-08-01 02:47:45 --> Helper loaded: util_helper
INFO - 2018-08-01 02:47:45 --> Helper loaded: text_helper
INFO - 2018-08-01 02:47:45 --> Helper loaded: string_helper
INFO - 2018-08-01 02:47:45 --> Database Driver Class Initialized
DEBUG - 2018-08-01 02:47:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-01 02:47:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-01 02:47:45 --> Email Class Initialized
INFO - 2018-08-01 02:47:45 --> Controller Class Initialized
DEBUG - 2018-08-01 02:47:45 --> Home MX_Controller Initialized
DEBUG - 2018-08-01 02:47:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-08-01 02:47:45 --> Config Class Initialized
DEBUG - 2018-08-01 02:47:45 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
INFO - 2018-08-01 02:47:45 --> Hooks Class Initialized
DEBUG - 2018-08-01 02:47:45 --> Login MX_Controller Initialized
INFO - 2018-08-01 02:47:45 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-01 02:47:45 --> UTF-8 Support Enabled
INFO - 2018-08-01 02:47:45 --> Utf8 Class Initialized
DEBUG - 2018-08-01 02:47:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-08-01 02:47:45 --> URI Class Initialized
DEBUG - 2018-08-01 02:47:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-01 02:47:45 --> Router Class Initialized
INFO - 2018-08-01 02:47:45 --> Output Class Initialized
INFO - 2018-08-01 02:47:46 --> Security Class Initialized
DEBUG - 2018-08-01 02:47:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-01 02:47:46 --> Input Class Initialized
INFO - 2018-08-01 02:47:46 --> Language Class Initialized
ERROR - 2018-08-01 02:47:46 --> 404 Page Not Found: /index
INFO - 2018-08-01 02:47:46 --> Config Class Initialized
INFO - 2018-08-01 02:47:46 --> Hooks Class Initialized
DEBUG - 2018-08-01 02:47:46 --> UTF-8 Support Enabled
INFO - 2018-08-01 02:47:46 --> Utf8 Class Initialized
INFO - 2018-08-01 02:47:46 --> URI Class Initialized
INFO - 2018-08-01 02:47:46 --> Router Class Initialized
INFO - 2018-08-01 02:47:46 --> Output Class Initialized
INFO - 2018-08-01 02:47:46 --> Security Class Initialized
DEBUG - 2018-08-01 02:47:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-01 02:47:46 --> Input Class Initialized
INFO - 2018-08-01 02:47:46 --> Language Class Initialized
ERROR - 2018-08-01 02:47:46 --> 404 Page Not Found: /index
INFO - 2018-08-01 02:47:46 --> Config Class Initialized
INFO - 2018-08-01 02:47:46 --> Hooks Class Initialized
DEBUG - 2018-08-01 02:47:46 --> UTF-8 Support Enabled
INFO - 2018-08-01 02:47:46 --> Utf8 Class Initialized
INFO - 2018-08-01 02:47:46 --> URI Class Initialized
INFO - 2018-08-01 02:47:46 --> Router Class Initialized
INFO - 2018-08-01 02:47:46 --> Output Class Initialized
INFO - 2018-08-01 02:47:46 --> Security Class Initialized
DEBUG - 2018-08-01 02:47:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-01 02:47:46 --> Input Class Initialized
INFO - 2018-08-01 02:47:46 --> Language Class Initialized
ERROR - 2018-08-01 02:47:46 --> 404 Page Not Found: /index
INFO - 2018-08-01 02:47:51 --> Config Class Initialized
INFO - 2018-08-01 02:47:51 --> Hooks Class Initialized
DEBUG - 2018-08-01 02:47:51 --> UTF-8 Support Enabled
INFO - 2018-08-01 02:47:51 --> Utf8 Class Initialized
INFO - 2018-08-01 02:47:51 --> URI Class Initialized
INFO - 2018-08-01 02:47:51 --> Router Class Initialized
INFO - 2018-08-01 02:47:51 --> Config Class Initialized
INFO - 2018-08-01 02:47:51 --> Hooks Class Initialized
INFO - 2018-08-01 02:47:51 --> Output Class Initialized
DEBUG - 2018-08-01 02:47:51 --> UTF-8 Support Enabled
INFO - 2018-08-01 02:47:51 --> Security Class Initialized
INFO - 2018-08-01 02:47:51 --> Utf8 Class Initialized
DEBUG - 2018-08-01 02:47:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-01 02:47:51 --> Input Class Initialized
INFO - 2018-08-01 02:47:51 --> URI Class Initialized
INFO - 2018-08-01 02:47:51 --> Language Class Initialized
INFO - 2018-08-01 02:47:51 --> Router Class Initialized
INFO - 2018-08-01 02:47:51 --> Output Class Initialized
INFO - 2018-08-01 02:47:51 --> Language Class Initialized
INFO - 2018-08-01 02:47:51 --> Config Class Initialized
INFO - 2018-08-01 02:47:51 --> Security Class Initialized
DEBUG - 2018-08-01 02:47:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-01 02:47:51 --> Loader Class Initialized
INFO - 2018-08-01 02:47:51 --> Input Class Initialized
DEBUG - 2018-08-01 02:47:51 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-01 02:47:51 --> Language Class Initialized
INFO - 2018-08-01 02:47:51 --> Helper loaded: url_helper
ERROR - 2018-08-01 02:47:51 --> 404 Page Not Found: /index
INFO - 2018-08-01 02:47:51 --> Helper loaded: form_helper
INFO - 2018-08-01 02:47:51 --> Helper loaded: date_helper
INFO - 2018-08-01 02:47:51 --> Config Class Initialized
INFO - 2018-08-01 02:47:51 --> Hooks Class Initialized
INFO - 2018-08-01 02:47:51 --> Helper loaded: util_helper
DEBUG - 2018-08-01 02:47:51 --> UTF-8 Support Enabled
INFO - 2018-08-01 02:47:51 --> Helper loaded: text_helper
INFO - 2018-08-01 02:47:51 --> Utf8 Class Initialized
INFO - 2018-08-01 02:47:51 --> URI Class Initialized
INFO - 2018-08-01 02:47:51 --> Helper loaded: string_helper
INFO - 2018-08-01 02:47:51 --> Router Class Initialized
INFO - 2018-08-01 02:47:51 --> Output Class Initialized
INFO - 2018-08-01 02:47:51 --> Security Class Initialized
INFO - 2018-08-01 02:47:51 --> Database Driver Class Initialized
DEBUG - 2018-08-01 02:47:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-01 02:47:51 --> Input Class Initialized
INFO - 2018-08-01 02:47:51 --> Language Class Initialized
ERROR - 2018-08-01 02:47:51 --> 404 Page Not Found: /index
INFO - 2018-08-01 02:47:51 --> Config Class Initialized
INFO - 2018-08-01 02:47:51 --> Hooks Class Initialized
DEBUG - 2018-08-01 02:47:51 --> UTF-8 Support Enabled
INFO - 2018-08-01 02:47:51 --> Utf8 Class Initialized
DEBUG - 2018-08-01 02:47:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-01 02:47:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-01 02:47:51 --> URI Class Initialized
INFO - 2018-08-01 02:47:51 --> Email Class Initialized
INFO - 2018-08-01 02:47:51 --> Router Class Initialized
INFO - 2018-08-01 02:47:51 --> Controller Class Initialized
INFO - 2018-08-01 02:47:51 --> Output Class Initialized
DEBUG - 2018-08-01 02:47:51 --> Home MX_Controller Initialized
DEBUG - 2018-08-01 02:47:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-08-01 02:47:51 --> Security Class Initialized
DEBUG - 2018-08-01 02:47:51 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-01 02:47:51 --> Login MX_Controller Initialized
DEBUG - 2018-08-01 02:47:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-01 02:47:51 --> Language file loaded: language/english/data_lang.php
INFO - 2018-08-01 02:47:51 --> Input Class Initialized
DEBUG - 2018-08-01 02:47:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-01 02:47:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-01 02:47:51 --> Language Class Initialized
ERROR - 2018-08-01 02:47:51 --> 404 Page Not Found: /index
INFO - 2018-08-01 23:53:55 --> Config Class Initialized
INFO - 2018-08-01 23:53:55 --> Hooks Class Initialized
DEBUG - 2018-08-01 23:53:55 --> UTF-8 Support Enabled
INFO - 2018-08-01 23:53:55 --> Utf8 Class Initialized
INFO - 2018-08-01 23:53:55 --> URI Class Initialized
INFO - 2018-08-01 23:53:55 --> Router Class Initialized
INFO - 2018-08-01 23:53:55 --> Output Class Initialized
INFO - 2018-08-01 23:53:56 --> Security Class Initialized
DEBUG - 2018-08-01 23:53:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-01 23:53:56 --> Input Class Initialized
INFO - 2018-08-01 23:53:56 --> Language Class Initialized
INFO - 2018-08-01 23:53:56 --> Language Class Initialized
INFO - 2018-08-01 23:53:56 --> Config Class Initialized
INFO - 2018-08-01 23:53:56 --> Loader Class Initialized
DEBUG - 2018-08-01 23:53:56 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-01 23:53:56 --> Helper loaded: url_helper
INFO - 2018-08-01 23:53:56 --> Helper loaded: form_helper
INFO - 2018-08-01 23:53:56 --> Helper loaded: date_helper
INFO - 2018-08-01 23:53:56 --> Helper loaded: util_helper
INFO - 2018-08-01 23:53:56 --> Helper loaded: text_helper
INFO - 2018-08-01 23:53:56 --> Helper loaded: string_helper
INFO - 2018-08-01 23:53:56 --> Database Driver Class Initialized
DEBUG - 2018-08-01 23:53:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-01 23:53:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-01 23:53:58 --> Email Class Initialized
INFO - 2018-08-01 23:53:58 --> Controller Class Initialized
DEBUG - 2018-08-01 23:53:58 --> Home MX_Controller Initialized
DEBUG - 2018-08-01 23:53:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-01 23:53:58 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-01 23:53:58 --> Login MX_Controller Initialized
INFO - 2018-08-01 23:53:58 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-01 23:53:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-01 23:53:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-01 23:53:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/login.php
INFO - 2018-08-01 23:54:07 --> Config Class Initialized
INFO - 2018-08-01 23:54:07 --> Hooks Class Initialized
DEBUG - 2018-08-01 23:54:07 --> UTF-8 Support Enabled
INFO - 2018-08-01 23:54:07 --> Utf8 Class Initialized
INFO - 2018-08-01 23:54:07 --> URI Class Initialized
INFO - 2018-08-01 23:54:07 --> Router Class Initialized
INFO - 2018-08-01 23:54:07 --> Output Class Initialized
INFO - 2018-08-01 23:54:07 --> Security Class Initialized
DEBUG - 2018-08-01 23:54:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-01 23:54:07 --> Input Class Initialized
INFO - 2018-08-01 23:54:07 --> Language Class Initialized
INFO - 2018-08-01 23:54:07 --> Language Class Initialized
INFO - 2018-08-01 23:54:07 --> Config Class Initialized
INFO - 2018-08-01 23:54:07 --> Loader Class Initialized
DEBUG - 2018-08-01 23:54:07 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-01 23:54:07 --> Helper loaded: url_helper
INFO - 2018-08-01 23:54:07 --> Helper loaded: form_helper
INFO - 2018-08-01 23:54:07 --> Helper loaded: date_helper
INFO - 2018-08-01 23:54:07 --> Helper loaded: util_helper
INFO - 2018-08-01 23:54:07 --> Helper loaded: text_helper
INFO - 2018-08-01 23:54:07 --> Helper loaded: string_helper
INFO - 2018-08-01 23:54:07 --> Database Driver Class Initialized
DEBUG - 2018-08-01 23:54:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-01 23:54:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-01 23:54:07 --> Email Class Initialized
INFO - 2018-08-01 23:54:07 --> Controller Class Initialized
DEBUG - 2018-08-01 23:54:07 --> videos MX_Controller Initialized
INFO - 2018-08-01 23:54:07 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-01 23:54:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-08-01 23:54:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-01 23:54:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-08-01 23:54:07 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-01 23:54:07 --> Login MX_Controller Initialized
DEBUG - 2018-08-01 23:54:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-01 23:54:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/logins/login.php
INFO - 2018-08-01 23:54:08 --> Config Class Initialized
INFO - 2018-08-01 23:54:08 --> Hooks Class Initialized
DEBUG - 2018-08-01 23:54:08 --> UTF-8 Support Enabled
INFO - 2018-08-01 23:54:08 --> Utf8 Class Initialized
INFO - 2018-08-01 23:54:08 --> URI Class Initialized
INFO - 2018-08-01 23:54:08 --> Router Class Initialized
INFO - 2018-08-01 23:54:08 --> Output Class Initialized
INFO - 2018-08-01 23:54:08 --> Security Class Initialized
DEBUG - 2018-08-01 23:54:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-01 23:54:08 --> Input Class Initialized
INFO - 2018-08-01 23:54:08 --> Language Class Initialized
ERROR - 2018-08-01 23:54:08 --> 404 Page Not Found: /index
INFO - 2018-08-01 23:54:08 --> Config Class Initialized
INFO - 2018-08-01 23:54:08 --> Hooks Class Initialized
DEBUG - 2018-08-01 23:54:08 --> UTF-8 Support Enabled
INFO - 2018-08-01 23:54:08 --> Utf8 Class Initialized
INFO - 2018-08-01 23:54:08 --> URI Class Initialized
INFO - 2018-08-01 23:54:08 --> Router Class Initialized
INFO - 2018-08-01 23:54:08 --> Output Class Initialized
INFO - 2018-08-01 23:54:08 --> Security Class Initialized
DEBUG - 2018-08-01 23:54:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-01 23:54:08 --> Input Class Initialized
INFO - 2018-08-01 23:54:08 --> Language Class Initialized
ERROR - 2018-08-01 23:54:08 --> 404 Page Not Found: /index
INFO - 2018-08-01 23:57:49 --> Config Class Initialized
INFO - 2018-08-01 23:57:49 --> Hooks Class Initialized
DEBUG - 2018-08-01 23:57:49 --> UTF-8 Support Enabled
INFO - 2018-08-01 23:57:49 --> Utf8 Class Initialized
INFO - 2018-08-01 23:57:49 --> URI Class Initialized
INFO - 2018-08-01 23:57:49 --> Router Class Initialized
INFO - 2018-08-01 23:57:49 --> Output Class Initialized
INFO - 2018-08-01 23:57:49 --> Security Class Initialized
DEBUG - 2018-08-01 23:57:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-01 23:57:49 --> Input Class Initialized
INFO - 2018-08-01 23:57:49 --> Language Class Initialized
INFO - 2018-08-01 23:57:49 --> Language Class Initialized
INFO - 2018-08-01 23:57:49 --> Config Class Initialized
INFO - 2018-08-01 23:57:49 --> Loader Class Initialized
DEBUG - 2018-08-01 23:57:49 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-01 23:57:49 --> Helper loaded: url_helper
INFO - 2018-08-01 23:57:49 --> Helper loaded: form_helper
INFO - 2018-08-01 23:57:49 --> Helper loaded: date_helper
INFO - 2018-08-01 23:57:49 --> Helper loaded: util_helper
INFO - 2018-08-01 23:57:49 --> Helper loaded: text_helper
INFO - 2018-08-01 23:57:49 --> Helper loaded: string_helper
INFO - 2018-08-01 23:57:49 --> Database Driver Class Initialized
DEBUG - 2018-08-01 23:57:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-01 23:57:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-01 23:57:49 --> Email Class Initialized
INFO - 2018-08-01 23:57:49 --> Controller Class Initialized
DEBUG - 2018-08-01 23:57:49 --> Login MX_Controller Initialized
INFO - 2018-08-01 23:57:49 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-01 23:57:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-01 23:57:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-01 23:57:49 --> Email starts for colinUser fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-08-01 23:57:49 --> User session created for 4
INFO - 2018-08-01 23:57:49 --> Login status colinUser - success
INFO - 2018-08-01 23:57:50 --> Final output sent to browser
DEBUG - 2018-08-01 23:57:50 --> Total execution time: 0.4748
INFO - 2018-08-01 23:57:50 --> Config Class Initialized
INFO - 2018-08-01 23:57:50 --> Hooks Class Initialized
DEBUG - 2018-08-01 23:57:50 --> UTF-8 Support Enabled
INFO - 2018-08-01 23:57:50 --> Utf8 Class Initialized
INFO - 2018-08-01 23:57:50 --> URI Class Initialized
INFO - 2018-08-01 23:57:50 --> Router Class Initialized
INFO - 2018-08-01 23:57:50 --> Output Class Initialized
INFO - 2018-08-01 23:57:50 --> Security Class Initialized
DEBUG - 2018-08-01 23:57:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-01 23:57:50 --> Input Class Initialized
INFO - 2018-08-01 23:57:50 --> Language Class Initialized
INFO - 2018-08-01 23:57:50 --> Language Class Initialized
INFO - 2018-08-01 23:57:50 --> Config Class Initialized
INFO - 2018-08-01 23:57:50 --> Loader Class Initialized
DEBUG - 2018-08-01 23:57:50 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-01 23:57:50 --> Helper loaded: url_helper
INFO - 2018-08-01 23:57:50 --> Helper loaded: form_helper
INFO - 2018-08-01 23:57:50 --> Helper loaded: date_helper
INFO - 2018-08-01 23:57:50 --> Helper loaded: util_helper
INFO - 2018-08-01 23:57:50 --> Helper loaded: text_helper
INFO - 2018-08-01 23:57:50 --> Helper loaded: string_helper
INFO - 2018-08-01 23:57:50 --> Database Driver Class Initialized
DEBUG - 2018-08-01 23:57:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-01 23:57:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-01 23:57:50 --> Email Class Initialized
INFO - 2018-08-01 23:57:50 --> Controller Class Initialized
DEBUG - 2018-08-01 23:57:50 --> Home MX_Controller Initialized
DEBUG - 2018-08-01 23:57:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-01 23:57:50 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-01 23:57:50 --> Login MX_Controller Initialized
INFO - 2018-08-01 23:57:50 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-01 23:57:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-01 23:57:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-01 23:57:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-08-01 23:57:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-08-01 23:57:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-08-01 23:57:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-08-01 23:57:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-08-01 23:57:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-08-01 23:57:50 --> Final output sent to browser
DEBUG - 2018-08-01 23:57:50 --> Total execution time: 0.6673
INFO - 2018-08-01 23:57:52 --> Config Class Initialized
INFO - 2018-08-01 23:57:52 --> Hooks Class Initialized
DEBUG - 2018-08-01 23:57:52 --> UTF-8 Support Enabled
INFO - 2018-08-01 23:57:52 --> Utf8 Class Initialized
INFO - 2018-08-01 23:57:52 --> URI Class Initialized
INFO - 2018-08-01 23:57:52 --> Router Class Initialized
INFO - 2018-08-01 23:57:52 --> Output Class Initialized
INFO - 2018-08-01 23:57:52 --> Security Class Initialized
INFO - 2018-08-01 23:57:52 --> Config Class Initialized
INFO - 2018-08-01 23:57:52 --> Hooks Class Initialized
DEBUG - 2018-08-01 23:57:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-01 23:57:52 --> Input Class Initialized
DEBUG - 2018-08-01 23:57:52 --> UTF-8 Support Enabled
INFO - 2018-08-01 23:57:52 --> Utf8 Class Initialized
INFO - 2018-08-01 23:57:52 --> Language Class Initialized
INFO - 2018-08-01 23:57:52 --> URI Class Initialized
ERROR - 2018-08-01 23:57:52 --> 404 Page Not Found: /index
INFO - 2018-08-01 23:57:52 --> Router Class Initialized
INFO - 2018-08-01 23:57:52 --> Output Class Initialized
INFO - 2018-08-01 23:57:52 --> Security Class Initialized
DEBUG - 2018-08-01 23:57:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-01 23:57:52 --> Input Class Initialized
INFO - 2018-08-01 23:57:52 --> Language Class Initialized
INFO - 2018-08-01 23:57:52 --> Language Class Initialized
INFO - 2018-08-01 23:57:52 --> Config Class Initialized
INFO - 2018-08-01 23:57:52 --> Config Class Initialized
INFO - 2018-08-01 23:57:52 --> Loader Class Initialized
INFO - 2018-08-01 23:57:52 --> Hooks Class Initialized
DEBUG - 2018-08-01 23:57:52 --> UTF-8 Support Enabled
INFO - 2018-08-01 23:57:52 --> Utf8 Class Initialized
DEBUG - 2018-08-01 23:57:52 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-01 23:57:52 --> URI Class Initialized
INFO - 2018-08-01 23:57:52 --> Helper loaded: url_helper
INFO - 2018-08-01 23:57:52 --> Helper loaded: form_helper
INFO - 2018-08-01 23:57:52 --> Router Class Initialized
INFO - 2018-08-01 23:57:52 --> Helper loaded: date_helper
INFO - 2018-08-01 23:57:52 --> Output Class Initialized
INFO - 2018-08-01 23:57:52 --> Helper loaded: util_helper
INFO - 2018-08-01 23:57:52 --> Security Class Initialized
INFO - 2018-08-01 23:57:52 --> Helper loaded: text_helper
DEBUG - 2018-08-01 23:57:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-01 23:57:52 --> Input Class Initialized
INFO - 2018-08-01 23:57:52 --> Helper loaded: string_helper
INFO - 2018-08-01 23:57:52 --> Language Class Initialized
ERROR - 2018-08-01 23:57:52 --> 404 Page Not Found: /index
INFO - 2018-08-01 23:57:52 --> Database Driver Class Initialized
DEBUG - 2018-08-01 23:57:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-01 23:57:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-01 23:57:52 --> Email Class Initialized
INFO - 2018-08-01 23:57:52 --> Controller Class Initialized
INFO - 2018-08-01 23:57:52 --> Config Class Initialized
INFO - 2018-08-01 23:57:52 --> Hooks Class Initialized
DEBUG - 2018-08-01 23:57:52 --> Home MX_Controller Initialized
DEBUG - 2018-08-01 23:57:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-01 23:57:52 --> UTF-8 Support Enabled
INFO - 2018-08-01 23:57:53 --> Utf8 Class Initialized
INFO - 2018-08-01 23:57:53 --> Config Class Initialized
DEBUG - 2018-08-01 23:57:53 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-01 23:57:53 --> Login MX_Controller Initialized
INFO - 2018-08-01 23:57:53 --> Hooks Class Initialized
INFO - 2018-08-01 23:57:53 --> URI Class Initialized
INFO - 2018-08-01 23:57:53 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-01 23:57:53 --> UTF-8 Support Enabled
INFO - 2018-08-01 23:57:53 --> Utf8 Class Initialized
DEBUG - 2018-08-01 23:57:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-08-01 23:57:53 --> Router Class Initialized
DEBUG - 2018-08-01 23:57:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-01 23:57:53 --> URI Class Initialized
INFO - 2018-08-01 23:57:53 --> Output Class Initialized
INFO - 2018-08-01 23:57:53 --> Router Class Initialized
INFO - 2018-08-01 23:57:53 --> Security Class Initialized
INFO - 2018-08-01 23:57:53 --> Output Class Initialized
INFO - 2018-08-01 23:57:53 --> Security Class Initialized
DEBUG - 2018-08-01 23:57:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-01 23:57:53 --> Input Class Initialized
INFO - 2018-08-01 23:57:53 --> Language Class Initialized
ERROR - 2018-08-01 23:57:53 --> 404 Page Not Found: /index
DEBUG - 2018-08-01 23:57:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-01 23:57:53 --> Config Class Initialized
INFO - 2018-08-01 23:57:53 --> Hooks Class Initialized
INFO - 2018-08-01 23:57:53 --> Input Class Initialized
INFO - 2018-08-01 23:57:53 --> Language Class Initialized
DEBUG - 2018-08-01 23:57:53 --> UTF-8 Support Enabled
ERROR - 2018-08-01 23:57:53 --> 404 Page Not Found: /index
INFO - 2018-08-01 23:57:53 --> Utf8 Class Initialized
INFO - 2018-08-01 23:57:53 --> URI Class Initialized
INFO - 2018-08-01 23:57:53 --> Router Class Initialized
INFO - 2018-08-01 23:57:53 --> Output Class Initialized
INFO - 2018-08-01 23:57:53 --> Security Class Initialized
DEBUG - 2018-08-01 23:57:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-01 23:57:53 --> Input Class Initialized
INFO - 2018-08-01 23:57:53 --> Language Class Initialized
ERROR - 2018-08-01 23:57:53 --> 404 Page Not Found: /index
INFO - 2018-08-01 23:57:53 --> Config Class Initialized
INFO - 2018-08-01 23:57:53 --> Hooks Class Initialized
DEBUG - 2018-08-01 23:57:53 --> UTF-8 Support Enabled
INFO - 2018-08-01 23:57:53 --> Utf8 Class Initialized
INFO - 2018-08-01 23:57:53 --> URI Class Initialized
INFO - 2018-08-01 23:57:53 --> Router Class Initialized
INFO - 2018-08-01 23:57:53 --> Output Class Initialized
INFO - 2018-08-01 23:57:53 --> Security Class Initialized
DEBUG - 2018-08-01 23:57:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-01 23:57:53 --> Input Class Initialized
INFO - 2018-08-01 23:57:53 --> Language Class Initialized
ERROR - 2018-08-01 23:57:53 --> 404 Page Not Found: /index
INFO - 2018-08-01 23:57:53 --> Config Class Initialized
INFO - 2018-08-01 23:57:53 --> Hooks Class Initialized
DEBUG - 2018-08-01 23:57:53 --> UTF-8 Support Enabled
INFO - 2018-08-01 23:57:53 --> Utf8 Class Initialized
INFO - 2018-08-01 23:57:53 --> URI Class Initialized
INFO - 2018-08-01 23:57:53 --> Router Class Initialized
INFO - 2018-08-01 23:57:53 --> Output Class Initialized
INFO - 2018-08-01 23:57:53 --> Security Class Initialized
DEBUG - 2018-08-01 23:57:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-01 23:57:53 --> Input Class Initialized
INFO - 2018-08-01 23:57:53 --> Language Class Initialized
ERROR - 2018-08-01 23:57:53 --> 404 Page Not Found: /index
INFO - 2018-08-01 23:57:54 --> Config Class Initialized
INFO - 2018-08-01 23:57:54 --> Hooks Class Initialized
DEBUG - 2018-08-01 23:57:54 --> UTF-8 Support Enabled
INFO - 2018-08-01 23:57:54 --> Utf8 Class Initialized
INFO - 2018-08-01 23:57:54 --> URI Class Initialized
INFO - 2018-08-01 23:57:54 --> Router Class Initialized
INFO - 2018-08-01 23:57:54 --> Output Class Initialized
INFO - 2018-08-01 23:57:54 --> Security Class Initialized
DEBUG - 2018-08-01 23:57:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-01 23:57:54 --> Input Class Initialized
INFO - 2018-08-01 23:57:54 --> Language Class Initialized
ERROR - 2018-08-01 23:57:54 --> 404 Page Not Found: /index
INFO - 2018-08-01 23:57:54 --> Config Class Initialized
INFO - 2018-08-01 23:57:54 --> Hooks Class Initialized
DEBUG - 2018-08-01 23:57:54 --> UTF-8 Support Enabled
INFO - 2018-08-01 23:57:54 --> Utf8 Class Initialized
INFO - 2018-08-01 23:57:54 --> URI Class Initialized
INFO - 2018-08-01 23:57:54 --> Router Class Initialized
INFO - 2018-08-01 23:57:54 --> Output Class Initialized
INFO - 2018-08-01 23:57:54 --> Security Class Initialized
DEBUG - 2018-08-01 23:57:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-01 23:57:54 --> Input Class Initialized
INFO - 2018-08-01 23:57:54 --> Language Class Initialized
ERROR - 2018-08-01 23:57:54 --> 404 Page Not Found: /index
INFO - 2018-08-01 23:57:54 --> Config Class Initialized
INFO - 2018-08-01 23:57:54 --> Hooks Class Initialized
DEBUG - 2018-08-01 23:57:54 --> UTF-8 Support Enabled
INFO - 2018-08-01 23:57:54 --> Utf8 Class Initialized
INFO - 2018-08-01 23:57:54 --> URI Class Initialized
INFO - 2018-08-01 23:57:54 --> Router Class Initialized
INFO - 2018-08-01 23:57:54 --> Output Class Initialized
INFO - 2018-08-01 23:57:54 --> Security Class Initialized
DEBUG - 2018-08-01 23:57:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-01 23:57:54 --> Input Class Initialized
INFO - 2018-08-01 23:57:54 --> Language Class Initialized
ERROR - 2018-08-01 23:57:54 --> 404 Page Not Found: /index
INFO - 2018-08-01 23:59:08 --> Config Class Initialized
INFO - 2018-08-01 23:59:08 --> Hooks Class Initialized
DEBUG - 2018-08-01 23:59:08 --> UTF-8 Support Enabled
INFO - 2018-08-01 23:59:08 --> Utf8 Class Initialized
INFO - 2018-08-01 23:59:08 --> URI Class Initialized
INFO - 2018-08-01 23:59:08 --> Router Class Initialized
INFO - 2018-08-01 23:59:08 --> Output Class Initialized
INFO - 2018-08-01 23:59:08 --> Security Class Initialized
DEBUG - 2018-08-01 23:59:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-01 23:59:08 --> Input Class Initialized
INFO - 2018-08-01 23:59:08 --> Language Class Initialized
INFO - 2018-08-01 23:59:08 --> Language Class Initialized
INFO - 2018-08-01 23:59:08 --> Config Class Initialized
INFO - 2018-08-01 23:59:08 --> Loader Class Initialized
DEBUG - 2018-08-01 23:59:08 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-01 23:59:08 --> Helper loaded: url_helper
INFO - 2018-08-01 23:59:08 --> Helper loaded: form_helper
INFO - 2018-08-01 23:59:08 --> Helper loaded: date_helper
INFO - 2018-08-01 23:59:08 --> Helper loaded: util_helper
INFO - 2018-08-01 23:59:08 --> Helper loaded: text_helper
INFO - 2018-08-01 23:59:08 --> Helper loaded: string_helper
INFO - 2018-08-01 23:59:08 --> Database Driver Class Initialized
DEBUG - 2018-08-01 23:59:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-01 23:59:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-01 23:59:08 --> Email Class Initialized
INFO - 2018-08-01 23:59:08 --> Config Class Initialized
INFO - 2018-08-01 23:59:08 --> Hooks Class Initialized
INFO - 2018-08-01 23:59:08 --> Controller Class Initialized
DEBUG - 2018-08-01 23:59:08 --> Home MX_Controller Initialized
DEBUG - 2018-08-01 23:59:08 --> UTF-8 Support Enabled
INFO - 2018-08-01 23:59:08 --> Utf8 Class Initialized
DEBUG - 2018-08-01 23:59:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-08-01 23:59:08 --> URI Class Initialized
DEBUG - 2018-08-01 23:59:08 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-01 23:59:08 --> Login MX_Controller Initialized
INFO - 2018-08-01 23:59:08 --> Router Class Initialized
INFO - 2018-08-01 23:59:08 --> Language file loaded: language/english/data_lang.php
INFO - 2018-08-01 23:59:08 --> Output Class Initialized
DEBUG - 2018-08-01 23:59:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-08-01 23:59:08 --> Security Class Initialized
DEBUG - 2018-08-01 23:59:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-01 23:59:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-01 23:59:08 --> Input Class Initialized
INFO - 2018-08-01 23:59:08 --> Language Class Initialized
ERROR - 2018-08-01 23:59:08 --> 404 Page Not Found: /index
INFO - 2018-08-01 23:59:08 --> Config Class Initialized
INFO - 2018-08-01 23:59:08 --> Hooks Class Initialized
DEBUG - 2018-08-01 23:59:08 --> UTF-8 Support Enabled
INFO - 2018-08-01 23:59:08 --> Utf8 Class Initialized
INFO - 2018-08-01 23:59:08 --> URI Class Initialized
INFO - 2018-08-01 23:59:08 --> Router Class Initialized
INFO - 2018-08-01 23:59:08 --> Output Class Initialized
INFO - 2018-08-01 23:59:08 --> Security Class Initialized
DEBUG - 2018-08-01 23:59:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-01 23:59:08 --> Input Class Initialized
INFO - 2018-08-01 23:59:08 --> Language Class Initialized
ERROR - 2018-08-01 23:59:08 --> 404 Page Not Found: /index
INFO - 2018-08-01 23:59:08 --> Config Class Initialized
INFO - 2018-08-01 23:59:08 --> Hooks Class Initialized
DEBUG - 2018-08-01 23:59:08 --> UTF-8 Support Enabled
INFO - 2018-08-01 23:59:08 --> Utf8 Class Initialized
INFO - 2018-08-01 23:59:08 --> URI Class Initialized
INFO - 2018-08-01 23:59:08 --> Router Class Initialized
INFO - 2018-08-01 23:59:08 --> Output Class Initialized
INFO - 2018-08-01 23:59:08 --> Security Class Initialized
DEBUG - 2018-08-01 23:59:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-01 23:59:08 --> Input Class Initialized
INFO - 2018-08-01 23:59:08 --> Language Class Initialized
ERROR - 2018-08-01 23:59:08 --> 404 Page Not Found: /index
INFO - 2018-08-01 23:59:35 --> Config Class Initialized
INFO - 2018-08-01 23:59:35 --> Hooks Class Initialized
DEBUG - 2018-08-01 23:59:35 --> UTF-8 Support Enabled
INFO - 2018-08-01 23:59:35 --> Utf8 Class Initialized
INFO - 2018-08-01 23:59:35 --> URI Class Initialized
INFO - 2018-08-01 23:59:35 --> Router Class Initialized
INFO - 2018-08-01 23:59:35 --> Output Class Initialized
INFO - 2018-08-01 23:59:35 --> Security Class Initialized
DEBUG - 2018-08-01 23:59:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-01 23:59:35 --> Input Class Initialized
INFO - 2018-08-01 23:59:35 --> Language Class Initialized
INFO - 2018-08-01 23:59:35 --> Language Class Initialized
INFO - 2018-08-01 23:59:35 --> Config Class Initialized
INFO - 2018-08-01 23:59:35 --> Loader Class Initialized
DEBUG - 2018-08-01 23:59:35 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-01 23:59:35 --> Helper loaded: url_helper
INFO - 2018-08-01 23:59:35 --> Helper loaded: form_helper
INFO - 2018-08-01 23:59:35 --> Helper loaded: date_helper
INFO - 2018-08-01 23:59:35 --> Helper loaded: util_helper
INFO - 2018-08-01 23:59:35 --> Helper loaded: text_helper
INFO - 2018-08-01 23:59:35 --> Helper loaded: string_helper
INFO - 2018-08-01 23:59:35 --> Database Driver Class Initialized
DEBUG - 2018-08-01 23:59:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-01 23:59:35 --> Config Class Initialized
INFO - 2018-08-01 23:59:35 --> Hooks Class Initialized
INFO - 2018-08-01 23:59:35 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-08-01 23:59:35 --> UTF-8 Support Enabled
INFO - 2018-08-01 23:59:35 --> Email Class Initialized
INFO - 2018-08-01 23:59:35 --> Utf8 Class Initialized
INFO - 2018-08-01 23:59:35 --> Controller Class Initialized
DEBUG - 2018-08-01 23:59:35 --> Home MX_Controller Initialized
INFO - 2018-08-01 23:59:35 --> URI Class Initialized
DEBUG - 2018-08-01 23:59:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-08-01 23:59:35 --> Router Class Initialized
INFO - 2018-08-01 23:59:35 --> Output Class Initialized
DEBUG - 2018-08-01 23:59:35 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-01 23:59:35 --> Login MX_Controller Initialized
INFO - 2018-08-01 23:59:35 --> Security Class Initialized
INFO - 2018-08-01 23:59:35 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-01 23:59:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-01 23:59:35 --> Input Class Initialized
DEBUG - 2018-08-01 23:59:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-08-01 23:59:35 --> Language Class Initialized
DEBUG - 2018-08-01 23:59:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
ERROR - 2018-08-01 23:59:35 --> 404 Page Not Found: /index
INFO - 2018-08-01 23:59:35 --> Config Class Initialized
INFO - 2018-08-01 23:59:35 --> Hooks Class Initialized
DEBUG - 2018-08-01 23:59:35 --> UTF-8 Support Enabled
INFO - 2018-08-01 23:59:35 --> Utf8 Class Initialized
INFO - 2018-08-01 23:59:35 --> URI Class Initialized
INFO - 2018-08-01 23:59:35 --> Router Class Initialized
INFO - 2018-08-01 23:59:35 --> Output Class Initialized
INFO - 2018-08-01 23:59:35 --> Security Class Initialized
DEBUG - 2018-08-01 23:59:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-01 23:59:35 --> Input Class Initialized
INFO - 2018-08-01 23:59:35 --> Language Class Initialized
ERROR - 2018-08-01 23:59:35 --> 404 Page Not Found: /index
INFO - 2018-08-01 23:59:35 --> Config Class Initialized
INFO - 2018-08-01 23:59:35 --> Hooks Class Initialized
DEBUG - 2018-08-01 23:59:35 --> UTF-8 Support Enabled
INFO - 2018-08-01 23:59:35 --> Utf8 Class Initialized
INFO - 2018-08-01 23:59:35 --> URI Class Initialized
INFO - 2018-08-01 23:59:35 --> Router Class Initialized
INFO - 2018-08-01 23:59:35 --> Output Class Initialized
INFO - 2018-08-01 23:59:35 --> Security Class Initialized
DEBUG - 2018-08-01 23:59:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-01 23:59:35 --> Input Class Initialized
INFO - 2018-08-01 23:59:35 --> Language Class Initialized
ERROR - 2018-08-01 23:59:35 --> 404 Page Not Found: /index
INFO - 2018-08-01 23:59:36 --> Config Class Initialized
INFO - 2018-08-01 23:59:36 --> Hooks Class Initialized
DEBUG - 2018-08-01 23:59:36 --> UTF-8 Support Enabled
INFO - 2018-08-01 23:59:36 --> Utf8 Class Initialized
INFO - 2018-08-01 23:59:36 --> URI Class Initialized
INFO - 2018-08-01 23:59:36 --> Router Class Initialized
INFO - 2018-08-01 23:59:36 --> Output Class Initialized
INFO - 2018-08-01 23:59:36 --> Security Class Initialized
DEBUG - 2018-08-01 23:59:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-01 23:59:36 --> Input Class Initialized
INFO - 2018-08-01 23:59:36 --> Language Class Initialized
ERROR - 2018-08-01 23:59:36 --> 404 Page Not Found: /index
INFO - 2018-08-01 23:59:36 --> Config Class Initialized
INFO - 2018-08-01 23:59:36 --> Hooks Class Initialized
INFO - 2018-08-01 23:59:36 --> Config Class Initialized
INFO - 2018-08-01 23:59:36 --> Hooks Class Initialized
DEBUG - 2018-08-01 23:59:36 --> UTF-8 Support Enabled
INFO - 2018-08-01 23:59:36 --> Utf8 Class Initialized
DEBUG - 2018-08-01 23:59:36 --> UTF-8 Support Enabled
INFO - 2018-08-01 23:59:36 --> Utf8 Class Initialized
INFO - 2018-08-01 23:59:36 --> URI Class Initialized
INFO - 2018-08-01 23:59:36 --> URI Class Initialized
INFO - 2018-08-01 23:59:36 --> Router Class Initialized
INFO - 2018-08-01 23:59:36 --> Router Class Initialized
INFO - 2018-08-01 23:59:36 --> Output Class Initialized
INFO - 2018-08-01 23:59:36 --> Output Class Initialized
INFO - 2018-08-01 23:59:36 --> Security Class Initialized
INFO - 2018-08-01 23:59:36 --> Security Class Initialized
DEBUG - 2018-08-01 23:59:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-08-01 23:59:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-01 23:59:36 --> Input Class Initialized
INFO - 2018-08-01 23:59:36 --> Language Class Initialized
INFO - 2018-08-01 23:59:36 --> Input Class Initialized
ERROR - 2018-08-01 23:59:36 --> 404 Page Not Found: /index
INFO - 2018-08-01 23:59:36 --> Language Class Initialized
INFO - 2018-08-01 23:59:36 --> Config Class Initialized
INFO - 2018-08-01 23:59:36 --> Hooks Class Initialized
INFO - 2018-08-01 23:59:36 --> Language Class Initialized
INFO - 2018-08-01 23:59:36 --> Config Class Initialized
DEBUG - 2018-08-01 23:59:36 --> UTF-8 Support Enabled
INFO - 2018-08-01 23:59:36 --> Utf8 Class Initialized
INFO - 2018-08-01 23:59:36 --> Loader Class Initialized
DEBUG - 2018-08-01 23:59:36 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-01 23:59:36 --> URI Class Initialized
INFO - 2018-08-01 23:59:36 --> Helper loaded: url_helper
INFO - 2018-08-01 23:59:36 --> Router Class Initialized
INFO - 2018-08-01 23:59:36 --> Output Class Initialized
INFO - 2018-08-01 23:59:36 --> Helper loaded: form_helper
INFO - 2018-08-01 23:59:36 --> Helper loaded: date_helper
INFO - 2018-08-01 23:59:36 --> Security Class Initialized
INFO - 2018-08-01 23:59:36 --> Helper loaded: util_helper
DEBUG - 2018-08-01 23:59:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-01 23:59:36 --> Helper loaded: text_helper
INFO - 2018-08-01 23:59:36 --> Input Class Initialized
INFO - 2018-08-01 23:59:36 --> Helper loaded: string_helper
INFO - 2018-08-01 23:59:36 --> Language Class Initialized
ERROR - 2018-08-01 23:59:36 --> 404 Page Not Found: /index
INFO - 2018-08-01 23:59:36 --> Database Driver Class Initialized
DEBUG - 2018-08-01 23:59:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-01 23:59:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-01 23:59:36 --> Email Class Initialized
INFO - 2018-08-01 23:59:36 --> Controller Class Initialized
DEBUG - 2018-08-01 23:59:36 --> Home MX_Controller Initialized
DEBUG - 2018-08-01 23:59:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-01 23:59:36 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-01 23:59:36 --> Login MX_Controller Initialized
INFO - 2018-08-01 23:59:36 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-01 23:59:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-01 23:59:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-01 23:59:37 --> Config Class Initialized
INFO - 2018-08-01 23:59:37 --> Hooks Class Initialized
DEBUG - 2018-08-01 23:59:37 --> UTF-8 Support Enabled
INFO - 2018-08-01 23:59:37 --> Utf8 Class Initialized
INFO - 2018-08-01 23:59:37 --> URI Class Initialized
INFO - 2018-08-01 23:59:37 --> Router Class Initialized
INFO - 2018-08-01 23:59:37 --> Output Class Initialized
INFO - 2018-08-01 23:59:37 --> Security Class Initialized
DEBUG - 2018-08-01 23:59:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-01 23:59:37 --> Input Class Initialized
INFO - 2018-08-01 23:59:37 --> Language Class Initialized
INFO - 2018-08-01 23:59:37 --> Language Class Initialized
INFO - 2018-08-01 23:59:37 --> Config Class Initialized
INFO - 2018-08-01 23:59:37 --> Loader Class Initialized
DEBUG - 2018-08-01 23:59:37 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-01 23:59:37 --> Helper loaded: url_helper
INFO - 2018-08-01 23:59:37 --> Helper loaded: form_helper
INFO - 2018-08-01 23:59:37 --> Helper loaded: date_helper
INFO - 2018-08-01 23:59:37 --> Helper loaded: util_helper
INFO - 2018-08-01 23:59:37 --> Helper loaded: text_helper
INFO - 2018-08-01 23:59:37 --> Helper loaded: string_helper
INFO - 2018-08-01 23:59:37 --> Database Driver Class Initialized
DEBUG - 2018-08-01 23:59:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-01 23:59:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-01 23:59:37 --> Email Class Initialized
INFO - 2018-08-01 23:59:37 --> Controller Class Initialized
DEBUG - 2018-08-01 23:59:37 --> Home MX_Controller Initialized
DEBUG - 2018-08-01 23:59:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-01 23:59:37 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-01 23:59:37 --> Login MX_Controller Initialized
INFO - 2018-08-01 23:59:37 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-01 23:59:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-01 23:59:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-01 23:59:37 --> Config Class Initialized
INFO - 2018-08-01 23:59:37 --> Hooks Class Initialized
DEBUG - 2018-08-01 23:59:37 --> UTF-8 Support Enabled
INFO - 2018-08-01 23:59:37 --> Utf8 Class Initialized
INFO - 2018-08-01 23:59:37 --> URI Class Initialized
INFO - 2018-08-01 23:59:37 --> Router Class Initialized
INFO - 2018-08-01 23:59:37 --> Output Class Initialized
INFO - 2018-08-01 23:59:37 --> Security Class Initialized
DEBUG - 2018-08-01 23:59:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-01 23:59:37 --> Input Class Initialized
INFO - 2018-08-01 23:59:37 --> Language Class Initialized
INFO - 2018-08-01 23:59:37 --> Language Class Initialized
INFO - 2018-08-01 23:59:37 --> Config Class Initialized
INFO - 2018-08-01 23:59:37 --> Loader Class Initialized
DEBUG - 2018-08-01 23:59:37 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-01 23:59:37 --> Helper loaded: url_helper
INFO - 2018-08-01 23:59:37 --> Helper loaded: form_helper
INFO - 2018-08-01 23:59:37 --> Helper loaded: date_helper
INFO - 2018-08-01 23:59:37 --> Helper loaded: util_helper
INFO - 2018-08-01 23:59:37 --> Helper loaded: text_helper
INFO - 2018-08-01 23:59:37 --> Helper loaded: string_helper
INFO - 2018-08-01 23:59:37 --> Database Driver Class Initialized
DEBUG - 2018-08-01 23:59:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-01 23:59:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-01 23:59:38 --> Email Class Initialized
INFO - 2018-08-01 23:59:38 --> Controller Class Initialized
INFO - 2018-08-01 23:59:38 --> Config Class Initialized
INFO - 2018-08-01 23:59:38 --> Hooks Class Initialized
DEBUG - 2018-08-01 23:59:38 --> Home MX_Controller Initialized
DEBUG - 2018-08-01 23:59:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-01 23:59:38 --> UTF-8 Support Enabled
INFO - 2018-08-01 23:59:38 --> Utf8 Class Initialized
DEBUG - 2018-08-01 23:59:38 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-01 23:59:38 --> Login MX_Controller Initialized
INFO - 2018-08-01 23:59:38 --> URI Class Initialized
INFO - 2018-08-01 23:59:38 --> Language file loaded: language/english/data_lang.php
INFO - 2018-08-01 23:59:38 --> Router Class Initialized
DEBUG - 2018-08-01 23:59:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-08-01 23:59:38 --> Output Class Initialized
INFO - 2018-08-01 23:59:38 --> Security Class Initialized
DEBUG - 2018-08-01 23:59:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-01 23:59:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-01 23:59:38 --> Input Class Initialized
INFO - 2018-08-01 23:59:38 --> Language Class Initialized
ERROR - 2018-08-01 23:59:38 --> 404 Page Not Found: /index
INFO - 2018-08-01 23:59:38 --> Config Class Initialized
INFO - 2018-08-01 23:59:38 --> Hooks Class Initialized
DEBUG - 2018-08-01 23:59:38 --> UTF-8 Support Enabled
INFO - 2018-08-01 23:59:38 --> Utf8 Class Initialized
INFO - 2018-08-01 23:59:38 --> URI Class Initialized
INFO - 2018-08-01 23:59:38 --> Router Class Initialized
INFO - 2018-08-01 23:59:38 --> Output Class Initialized
INFO - 2018-08-01 23:59:38 --> Security Class Initialized
DEBUG - 2018-08-01 23:59:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-01 23:59:38 --> Input Class Initialized
INFO - 2018-08-01 23:59:38 --> Language Class Initialized
ERROR - 2018-08-01 23:59:38 --> 404 Page Not Found: /index
INFO - 2018-08-01 23:59:38 --> Config Class Initialized
INFO - 2018-08-01 23:59:38 --> Hooks Class Initialized
DEBUG - 2018-08-01 23:59:38 --> UTF-8 Support Enabled
INFO - 2018-08-01 23:59:38 --> Utf8 Class Initialized
INFO - 2018-08-01 23:59:38 --> URI Class Initialized
INFO - 2018-08-01 23:59:38 --> Router Class Initialized
INFO - 2018-08-01 23:59:38 --> Output Class Initialized
INFO - 2018-08-01 23:59:38 --> Security Class Initialized
DEBUG - 2018-08-01 23:59:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-01 23:59:38 --> Input Class Initialized
INFO - 2018-08-01 23:59:38 --> Language Class Initialized
ERROR - 2018-08-01 23:59:38 --> 404 Page Not Found: /index
INFO - 2018-08-01 23:59:38 --> Config Class Initialized
INFO - 2018-08-01 23:59:38 --> Hooks Class Initialized
DEBUG - 2018-08-01 23:59:38 --> UTF-8 Support Enabled
INFO - 2018-08-01 23:59:38 --> Utf8 Class Initialized
INFO - 2018-08-01 23:59:38 --> URI Class Initialized
INFO - 2018-08-01 23:59:38 --> Router Class Initialized
INFO - 2018-08-01 23:59:38 --> Output Class Initialized
INFO - 2018-08-01 23:59:38 --> Security Class Initialized
DEBUG - 2018-08-01 23:59:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-01 23:59:38 --> Input Class Initialized
INFO - 2018-08-01 23:59:38 --> Language Class Initialized
INFO - 2018-08-01 23:59:38 --> Language Class Initialized
INFO - 2018-08-01 23:59:38 --> Config Class Initialized
INFO - 2018-08-01 23:59:38 --> Loader Class Initialized
DEBUG - 2018-08-01 23:59:38 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-01 23:59:38 --> Helper loaded: url_helper
INFO - 2018-08-01 23:59:38 --> Helper loaded: form_helper
INFO - 2018-08-01 23:59:38 --> Helper loaded: date_helper
INFO - 2018-08-01 23:59:38 --> Helper loaded: util_helper
INFO - 2018-08-01 23:59:38 --> Helper loaded: text_helper
INFO - 2018-08-01 23:59:38 --> Helper loaded: string_helper
INFO - 2018-08-01 23:59:38 --> Database Driver Class Initialized
DEBUG - 2018-08-01 23:59:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-01 23:59:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-01 23:59:38 --> Config Class Initialized
INFO - 2018-08-01 23:59:38 --> Hooks Class Initialized
INFO - 2018-08-01 23:59:38 --> Email Class Initialized
INFO - 2018-08-01 23:59:38 --> Controller Class Initialized
DEBUG - 2018-08-01 23:59:38 --> UTF-8 Support Enabled
INFO - 2018-08-01 23:59:38 --> Utf8 Class Initialized
DEBUG - 2018-08-01 23:59:38 --> Home MX_Controller Initialized
INFO - 2018-08-01 23:59:38 --> URI Class Initialized
DEBUG - 2018-08-01 23:59:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-08-01 23:59:38 --> Router Class Initialized
DEBUG - 2018-08-01 23:59:38 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-01 23:59:38 --> Login MX_Controller Initialized
INFO - 2018-08-01 23:59:38 --> Output Class Initialized
INFO - 2018-08-01 23:59:38 --> Language file loaded: language/english/data_lang.php
INFO - 2018-08-01 23:59:38 --> Security Class Initialized
DEBUG - 2018-08-01 23:59:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-01 23:59:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-01 23:59:38 --> Input Class Initialized
DEBUG - 2018-08-01 23:59:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-01 23:59:38 --> Language Class Initialized
ERROR - 2018-08-01 23:59:38 --> 404 Page Not Found: /index
INFO - 2018-08-01 23:59:38 --> Config Class Initialized
INFO - 2018-08-01 23:59:38 --> Hooks Class Initialized
DEBUG - 2018-08-01 23:59:38 --> UTF-8 Support Enabled
INFO - 2018-08-01 23:59:38 --> Utf8 Class Initialized
INFO - 2018-08-01 23:59:38 --> URI Class Initialized
INFO - 2018-08-01 23:59:38 --> Router Class Initialized
INFO - 2018-08-01 23:59:39 --> Output Class Initialized
INFO - 2018-08-01 23:59:39 --> Security Class Initialized
DEBUG - 2018-08-01 23:59:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-01 23:59:39 --> Input Class Initialized
INFO - 2018-08-01 23:59:39 --> Language Class Initialized
ERROR - 2018-08-01 23:59:39 --> 404 Page Not Found: /index
INFO - 2018-08-01 23:59:39 --> Config Class Initialized
INFO - 2018-08-01 23:59:39 --> Hooks Class Initialized
DEBUG - 2018-08-01 23:59:39 --> UTF-8 Support Enabled
INFO - 2018-08-01 23:59:39 --> Utf8 Class Initialized
INFO - 2018-08-01 23:59:39 --> URI Class Initialized
INFO - 2018-08-01 23:59:39 --> Router Class Initialized
INFO - 2018-08-01 23:59:39 --> Output Class Initialized
INFO - 2018-08-01 23:59:39 --> Security Class Initialized
DEBUG - 2018-08-01 23:59:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-01 23:59:39 --> Input Class Initialized
INFO - 2018-08-01 23:59:39 --> Language Class Initialized
ERROR - 2018-08-01 23:59:39 --> 404 Page Not Found: /index
INFO - 2018-08-01 23:59:39 --> Config Class Initialized
INFO - 2018-08-01 23:59:39 --> Hooks Class Initialized
DEBUG - 2018-08-01 23:59:39 --> UTF-8 Support Enabled
INFO - 2018-08-01 23:59:39 --> Utf8 Class Initialized
INFO - 2018-08-01 23:59:39 --> URI Class Initialized
INFO - 2018-08-01 23:59:39 --> Router Class Initialized
INFO - 2018-08-01 23:59:39 --> Output Class Initialized
INFO - 2018-08-01 23:59:39 --> Security Class Initialized
DEBUG - 2018-08-01 23:59:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-01 23:59:39 --> Input Class Initialized
INFO - 2018-08-01 23:59:39 --> Language Class Initialized
INFO - 2018-08-01 23:59:39 --> Language Class Initialized
INFO - 2018-08-01 23:59:39 --> Config Class Initialized
INFO - 2018-08-01 23:59:39 --> Loader Class Initialized
DEBUG - 2018-08-01 23:59:39 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-01 23:59:39 --> Helper loaded: url_helper
INFO - 2018-08-01 23:59:39 --> Helper loaded: form_helper
INFO - 2018-08-01 23:59:39 --> Helper loaded: date_helper
INFO - 2018-08-01 23:59:39 --> Helper loaded: util_helper
INFO - 2018-08-01 23:59:39 --> Helper loaded: text_helper
INFO - 2018-08-01 23:59:39 --> Helper loaded: string_helper
INFO - 2018-08-01 23:59:39 --> Database Driver Class Initialized
DEBUG - 2018-08-01 23:59:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-01 23:59:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-01 23:59:39 --> Email Class Initialized
INFO - 2018-08-01 23:59:39 --> Controller Class Initialized
DEBUG - 2018-08-01 23:59:39 --> Home MX_Controller Initialized
DEBUG - 2018-08-01 23:59:39 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-01 23:59:39 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-01 23:59:39 --> Login MX_Controller Initialized
INFO - 2018-08-01 23:59:39 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-01 23:59:39 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-01 23:59:39 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-01 23:59:40 --> Config Class Initialized
INFO - 2018-08-01 23:59:40 --> Hooks Class Initialized
DEBUG - 2018-08-01 23:59:40 --> UTF-8 Support Enabled
INFO - 2018-08-01 23:59:40 --> Utf8 Class Initialized
INFO - 2018-08-01 23:59:40 --> URI Class Initialized
INFO - 2018-08-01 23:59:40 --> Router Class Initialized
INFO - 2018-08-01 23:59:40 --> Output Class Initialized
INFO - 2018-08-01 23:59:40 --> Security Class Initialized
DEBUG - 2018-08-01 23:59:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-01 23:59:40 --> Input Class Initialized
INFO - 2018-08-01 23:59:40 --> Language Class Initialized
INFO - 2018-08-01 23:59:40 --> Language Class Initialized
INFO - 2018-08-01 23:59:40 --> Config Class Initialized
INFO - 2018-08-01 23:59:40 --> Loader Class Initialized
DEBUG - 2018-08-01 23:59:40 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-01 23:59:40 --> Helper loaded: url_helper
INFO - 2018-08-01 23:59:40 --> Helper loaded: form_helper
INFO - 2018-08-01 23:59:41 --> Helper loaded: date_helper
INFO - 2018-08-01 23:59:41 --> Helper loaded: util_helper
INFO - 2018-08-01 23:59:41 --> Helper loaded: text_helper
INFO - 2018-08-01 23:59:41 --> Config Class Initialized
INFO - 2018-08-01 23:59:41 --> Helper loaded: string_helper
INFO - 2018-08-01 23:59:41 --> Hooks Class Initialized
DEBUG - 2018-08-01 23:59:41 --> UTF-8 Support Enabled
INFO - 2018-08-01 23:59:41 --> Database Driver Class Initialized
INFO - 2018-08-01 23:59:41 --> Utf8 Class Initialized
INFO - 2018-08-01 23:59:41 --> URI Class Initialized
INFO - 2018-08-01 23:59:41 --> Router Class Initialized
INFO - 2018-08-01 23:59:41 --> Output Class Initialized
DEBUG - 2018-08-01 23:59:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-01 23:59:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-01 23:59:41 --> Security Class Initialized
DEBUG - 2018-08-01 23:59:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-01 23:59:41 --> Email Class Initialized
INFO - 2018-08-01 23:59:41 --> Input Class Initialized
INFO - 2018-08-01 23:59:41 --> Controller Class Initialized
DEBUG - 2018-08-01 23:59:41 --> Home MX_Controller Initialized
INFO - 2018-08-01 23:59:41 --> Language Class Initialized
ERROR - 2018-08-01 23:59:41 --> 404 Page Not Found: /index
DEBUG - 2018-08-01 23:59:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-08-01 23:59:41 --> Config Class Initialized
DEBUG - 2018-08-01 23:59:41 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
INFO - 2018-08-01 23:59:41 --> Hooks Class Initialized
DEBUG - 2018-08-01 23:59:41 --> Login MX_Controller Initialized
INFO - 2018-08-01 23:59:41 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-01 23:59:41 --> UTF-8 Support Enabled
DEBUG - 2018-08-01 23:59:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-01 23:59:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-01 23:59:41 --> Utf8 Class Initialized
INFO - 2018-08-01 23:59:41 --> URI Class Initialized
INFO - 2018-08-01 23:59:41 --> Router Class Initialized
INFO - 2018-08-01 23:59:41 --> Output Class Initialized
INFO - 2018-08-01 23:59:41 --> Security Class Initialized
DEBUG - 2018-08-01 23:59:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-01 23:59:41 --> Input Class Initialized
INFO - 2018-08-01 23:59:41 --> Language Class Initialized
ERROR - 2018-08-01 23:59:41 --> 404 Page Not Found: /index
INFO - 2018-08-01 23:59:41 --> Config Class Initialized
INFO - 2018-08-01 23:59:41 --> Hooks Class Initialized
DEBUG - 2018-08-01 23:59:41 --> UTF-8 Support Enabled
INFO - 2018-08-01 23:59:41 --> Utf8 Class Initialized
INFO - 2018-08-01 23:59:41 --> URI Class Initialized
INFO - 2018-08-01 23:59:41 --> Router Class Initialized
INFO - 2018-08-01 23:59:41 --> Output Class Initialized
INFO - 2018-08-01 23:59:41 --> Security Class Initialized
DEBUG - 2018-08-01 23:59:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-01 23:59:41 --> Input Class Initialized
INFO - 2018-08-01 23:59:41 --> Language Class Initialized
ERROR - 2018-08-01 23:59:41 --> 404 Page Not Found: /index
INFO - 2018-08-01 23:59:45 --> Config Class Initialized
INFO - 2018-08-01 23:59:45 --> Hooks Class Initialized
DEBUG - 2018-08-01 23:59:45 --> UTF-8 Support Enabled
INFO - 2018-08-01 23:59:45 --> Utf8 Class Initialized
INFO - 2018-08-01 23:59:46 --> URI Class Initialized
INFO - 2018-08-01 23:59:46 --> Router Class Initialized
INFO - 2018-08-01 23:59:46 --> Output Class Initialized
INFO - 2018-08-01 23:59:46 --> Security Class Initialized
DEBUG - 2018-08-01 23:59:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-01 23:59:46 --> Input Class Initialized
INFO - 2018-08-01 23:59:46 --> Language Class Initialized
INFO - 2018-08-01 23:59:46 --> Language Class Initialized
INFO - 2018-08-01 23:59:46 --> Config Class Initialized
INFO - 2018-08-01 23:59:46 --> Loader Class Initialized
DEBUG - 2018-08-01 23:59:46 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-01 23:59:46 --> Helper loaded: url_helper
INFO - 2018-08-01 23:59:46 --> Helper loaded: form_helper
INFO - 2018-08-01 23:59:46 --> Helper loaded: date_helper
INFO - 2018-08-01 23:59:46 --> Helper loaded: util_helper
INFO - 2018-08-01 23:59:46 --> Helper loaded: text_helper
INFO - 2018-08-01 23:59:46 --> Helper loaded: string_helper
INFO - 2018-08-01 23:59:46 --> Database Driver Class Initialized
DEBUG - 2018-08-01 23:59:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-01 23:59:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-01 23:59:46 --> Config Class Initialized
INFO - 2018-08-01 23:59:46 --> Hooks Class Initialized
INFO - 2018-08-01 23:59:46 --> Email Class Initialized
INFO - 2018-08-01 23:59:46 --> Controller Class Initialized
DEBUG - 2018-08-01 23:59:46 --> UTF-8 Support Enabled
INFO - 2018-08-01 23:59:46 --> Utf8 Class Initialized
DEBUG - 2018-08-01 23:59:46 --> Home MX_Controller Initialized
INFO - 2018-08-01 23:59:46 --> URI Class Initialized
DEBUG - 2018-08-01 23:59:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-08-01 23:59:46 --> Router Class Initialized
DEBUG - 2018-08-01 23:59:46 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-01 23:59:46 --> Login MX_Controller Initialized
INFO - 2018-08-01 23:59:46 --> Output Class Initialized
INFO - 2018-08-01 23:59:46 --> Language file loaded: language/english/data_lang.php
INFO - 2018-08-01 23:59:46 --> Security Class Initialized
DEBUG - 2018-08-01 23:59:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-01 23:59:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-01 23:59:46 --> Input Class Initialized
DEBUG - 2018-08-01 23:59:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-01 23:59:46 --> Language Class Initialized
ERROR - 2018-08-01 23:59:46 --> 404 Page Not Found: /index
INFO - 2018-08-01 23:59:46 --> Config Class Initialized
INFO - 2018-08-01 23:59:46 --> Hooks Class Initialized
DEBUG - 2018-08-01 23:59:46 --> UTF-8 Support Enabled
INFO - 2018-08-01 23:59:46 --> Utf8 Class Initialized
INFO - 2018-08-01 23:59:46 --> URI Class Initialized
INFO - 2018-08-01 23:59:46 --> Router Class Initialized
INFO - 2018-08-01 23:59:46 --> Output Class Initialized
INFO - 2018-08-01 23:59:46 --> Security Class Initialized
DEBUG - 2018-08-01 23:59:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-01 23:59:46 --> Input Class Initialized
INFO - 2018-08-01 23:59:46 --> Language Class Initialized
ERROR - 2018-08-01 23:59:46 --> 404 Page Not Found: /index
INFO - 2018-08-01 23:59:46 --> Config Class Initialized
INFO - 2018-08-01 23:59:46 --> Hooks Class Initialized
DEBUG - 2018-08-01 23:59:46 --> UTF-8 Support Enabled
INFO - 2018-08-01 23:59:46 --> Utf8 Class Initialized
INFO - 2018-08-01 23:59:46 --> URI Class Initialized
INFO - 2018-08-01 23:59:46 --> Router Class Initialized
INFO - 2018-08-01 23:59:46 --> Output Class Initialized
INFO - 2018-08-01 23:59:46 --> Security Class Initialized
DEBUG - 2018-08-01 23:59:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-01 23:59:46 --> Input Class Initialized
INFO - 2018-08-01 23:59:46 --> Language Class Initialized
ERROR - 2018-08-01 23:59:46 --> 404 Page Not Found: /index
INFO - 2018-08-01 23:59:55 --> Config Class Initialized
INFO - 2018-08-01 23:59:55 --> Hooks Class Initialized
DEBUG - 2018-08-01 23:59:55 --> UTF-8 Support Enabled
INFO - 2018-08-01 23:59:55 --> Utf8 Class Initialized
INFO - 2018-08-01 23:59:55 --> URI Class Initialized
INFO - 2018-08-01 23:59:55 --> Router Class Initialized
INFO - 2018-08-01 23:59:55 --> Output Class Initialized
INFO - 2018-08-01 23:59:55 --> Security Class Initialized
DEBUG - 2018-08-01 23:59:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-01 23:59:55 --> Input Class Initialized
INFO - 2018-08-01 23:59:55 --> Language Class Initialized
INFO - 2018-08-01 23:59:55 --> Language Class Initialized
INFO - 2018-08-01 23:59:55 --> Config Class Initialized
INFO - 2018-08-01 23:59:55 --> Loader Class Initialized
DEBUG - 2018-08-01 23:59:55 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-01 23:59:55 --> Helper loaded: url_helper
INFO - 2018-08-01 23:59:55 --> Helper loaded: form_helper
INFO - 2018-08-01 23:59:55 --> Helper loaded: date_helper
INFO - 2018-08-01 23:59:55 --> Helper loaded: util_helper
INFO - 2018-08-01 23:59:55 --> Helper loaded: text_helper
INFO - 2018-08-01 23:59:55 --> Helper loaded: string_helper
INFO - 2018-08-01 23:59:55 --> Database Driver Class Initialized
DEBUG - 2018-08-01 23:59:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-01 23:59:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-01 23:59:55 --> Email Class Initialized
INFO - 2018-08-01 23:59:55 --> Controller Class Initialized
DEBUG - 2018-08-01 23:59:55 --> Home MX_Controller Initialized
DEBUG - 2018-08-01 23:59:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-01 23:59:55 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-01 23:59:55 --> Login MX_Controller Initialized
INFO - 2018-08-01 23:59:55 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-01 23:59:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-01 23:59:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
