<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-08-02 00:02:23 --> Config Class Initialized
INFO - 2018-08-02 00:02:23 --> Hooks Class Initialized
DEBUG - 2018-08-02 00:02:23 --> UTF-8 Support Enabled
INFO - 2018-08-02 00:02:23 --> Utf8 Class Initialized
INFO - 2018-08-02 00:02:23 --> URI Class Initialized
INFO - 2018-08-02 00:02:23 --> Router Class Initialized
INFO - 2018-08-02 00:02:23 --> Output Class Initialized
INFO - 2018-08-02 00:02:23 --> Security Class Initialized
DEBUG - 2018-08-02 00:02:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 00:02:23 --> Input Class Initialized
INFO - 2018-08-02 00:02:23 --> Language Class Initialized
INFO - 2018-08-02 00:02:23 --> Language Class Initialized
INFO - 2018-08-02 00:02:23 --> Config Class Initialized
INFO - 2018-08-02 00:02:23 --> Loader Class Initialized
DEBUG - 2018-08-02 00:02:23 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-02 00:02:23 --> Helper loaded: url_helper
INFO - 2018-08-02 00:02:23 --> Helper loaded: form_helper
INFO - 2018-08-02 00:02:23 --> Helper loaded: date_helper
INFO - 2018-08-02 00:02:23 --> Helper loaded: util_helper
INFO - 2018-08-02 00:02:23 --> Helper loaded: text_helper
INFO - 2018-08-02 00:02:23 --> Helper loaded: string_helper
INFO - 2018-08-02 00:02:23 --> Database Driver Class Initialized
DEBUG - 2018-08-02 00:02:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-02 00:02:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-02 00:02:23 --> Email Class Initialized
INFO - 2018-08-02 00:02:23 --> Controller Class Initialized
DEBUG - 2018-08-02 00:02:23 --> Home MX_Controller Initialized
DEBUG - 2018-08-02 00:02:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-02 00:02:23 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-02 00:02:23 --> Login MX_Controller Initialized
INFO - 2018-08-02 00:02:23 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-02 00:02:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-02 00:02:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-02 00:02:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-08-02 00:02:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-08-02 00:02:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-08-02 00:02:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-08-02 00:02:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-08-02 00:02:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-08-02 00:02:24 --> Final output sent to browser
DEBUG - 2018-08-02 00:02:24 --> Total execution time: 0.5177
INFO - 2018-08-02 00:02:26 --> Config Class Initialized
INFO - 2018-08-02 00:02:26 --> Hooks Class Initialized
DEBUG - 2018-08-02 00:02:26 --> UTF-8 Support Enabled
INFO - 2018-08-02 00:02:26 --> Config Class Initialized
INFO - 2018-08-02 00:02:26 --> Hooks Class Initialized
INFO - 2018-08-02 00:02:26 --> Utf8 Class Initialized
DEBUG - 2018-08-02 00:02:26 --> UTF-8 Support Enabled
INFO - 2018-08-02 00:02:26 --> URI Class Initialized
INFO - 2018-08-02 00:02:26 --> Utf8 Class Initialized
INFO - 2018-08-02 00:02:26 --> Router Class Initialized
INFO - 2018-08-02 00:02:26 --> URI Class Initialized
INFO - 2018-08-02 00:02:26 --> Output Class Initialized
INFO - 2018-08-02 00:02:26 --> Router Class Initialized
INFO - 2018-08-02 00:02:26 --> Output Class Initialized
INFO - 2018-08-02 00:02:26 --> Security Class Initialized
DEBUG - 2018-08-02 00:02:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 00:02:26 --> Input Class Initialized
INFO - 2018-08-02 00:02:26 --> Language Class Initialized
INFO - 2018-08-02 00:02:26 --> Security Class Initialized
DEBUG - 2018-08-02 00:02:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 00:02:26 --> Language Class Initialized
INFO - 2018-08-02 00:02:26 --> Config Class Initialized
INFO - 2018-08-02 00:02:26 --> Input Class Initialized
INFO - 2018-08-02 00:02:26 --> Language Class Initialized
INFO - 2018-08-02 00:02:26 --> Loader Class Initialized
DEBUG - 2018-08-02 00:02:26 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
ERROR - 2018-08-02 00:02:26 --> 404 Page Not Found: /index
INFO - 2018-08-02 00:02:26 --> Helper loaded: url_helper
INFO - 2018-08-02 00:02:26 --> Helper loaded: form_helper
INFO - 2018-08-02 00:02:26 --> Config Class Initialized
INFO - 2018-08-02 00:02:26 --> Helper loaded: date_helper
INFO - 2018-08-02 00:02:26 --> Hooks Class Initialized
DEBUG - 2018-08-02 00:02:27 --> UTF-8 Support Enabled
INFO - 2018-08-02 00:02:27 --> Utf8 Class Initialized
INFO - 2018-08-02 00:02:27 --> URI Class Initialized
INFO - 2018-08-02 00:02:27 --> Helper loaded: util_helper
INFO - 2018-08-02 00:02:27 --> Helper loaded: text_helper
INFO - 2018-08-02 00:02:27 --> Router Class Initialized
INFO - 2018-08-02 00:02:27 --> Helper loaded: string_helper
INFO - 2018-08-02 00:02:27 --> Output Class Initialized
INFO - 2018-08-02 00:02:27 --> Security Class Initialized
INFO - 2018-08-02 00:02:27 --> Database Driver Class Initialized
DEBUG - 2018-08-02 00:02:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 00:02:27 --> Input Class Initialized
DEBUG - 2018-08-02 00:02:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-02 00:02:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-02 00:02:27 --> Language Class Initialized
ERROR - 2018-08-02 00:02:27 --> 404 Page Not Found: /index
INFO - 2018-08-02 00:02:27 --> Email Class Initialized
INFO - 2018-08-02 00:02:27 --> Controller Class Initialized
INFO - 2018-08-02 00:02:27 --> Config Class Initialized
INFO - 2018-08-02 00:02:27 --> Hooks Class Initialized
DEBUG - 2018-08-02 00:02:27 --> Home MX_Controller Initialized
DEBUG - 2018-08-02 00:02:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-02 00:02:27 --> UTF-8 Support Enabled
INFO - 2018-08-02 00:02:27 --> Utf8 Class Initialized
DEBUG - 2018-08-02 00:02:27 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-02 00:02:27 --> Login MX_Controller Initialized
INFO - 2018-08-02 00:02:27 --> URI Class Initialized
INFO - 2018-08-02 00:02:27 --> Language file loaded: language/english/data_lang.php
INFO - 2018-08-02 00:02:27 --> Router Class Initialized
INFO - 2018-08-02 00:02:27 --> Output Class Initialized
DEBUG - 2018-08-02 00:02:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-02 00:02:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-02 00:02:27 --> Security Class Initialized
DEBUG - 2018-08-02 00:02:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 00:02:27 --> Input Class Initialized
INFO - 2018-08-02 00:02:27 --> Language Class Initialized
ERROR - 2018-08-02 00:02:27 --> 404 Page Not Found: /index
INFO - 2018-08-02 00:02:27 --> Config Class Initialized
INFO - 2018-08-02 00:02:27 --> Hooks Class Initialized
DEBUG - 2018-08-02 00:02:27 --> UTF-8 Support Enabled
INFO - 2018-08-02 00:02:27 --> Utf8 Class Initialized
INFO - 2018-08-02 00:02:27 --> URI Class Initialized
INFO - 2018-08-02 00:02:27 --> Router Class Initialized
INFO - 2018-08-02 00:02:27 --> Output Class Initialized
INFO - 2018-08-02 00:02:27 --> Security Class Initialized
DEBUG - 2018-08-02 00:02:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 00:02:27 --> Input Class Initialized
INFO - 2018-08-02 00:02:27 --> Language Class Initialized
ERROR - 2018-08-02 00:02:27 --> 404 Page Not Found: /index
INFO - 2018-08-02 00:02:27 --> Config Class Initialized
INFO - 2018-08-02 00:02:27 --> Hooks Class Initialized
DEBUG - 2018-08-02 00:02:27 --> UTF-8 Support Enabled
INFO - 2018-08-02 00:02:27 --> Utf8 Class Initialized
INFO - 2018-08-02 00:02:27 --> URI Class Initialized
INFO - 2018-08-02 00:02:27 --> Router Class Initialized
INFO - 2018-08-02 00:02:27 --> Output Class Initialized
INFO - 2018-08-02 00:02:27 --> Security Class Initialized
DEBUG - 2018-08-02 00:02:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 00:02:27 --> Input Class Initialized
INFO - 2018-08-02 00:02:27 --> Language Class Initialized
ERROR - 2018-08-02 00:02:27 --> 404 Page Not Found: /index
INFO - 2018-08-02 00:02:27 --> Config Class Initialized
INFO - 2018-08-02 00:02:27 --> Hooks Class Initialized
DEBUG - 2018-08-02 00:02:27 --> UTF-8 Support Enabled
INFO - 2018-08-02 00:02:27 --> Utf8 Class Initialized
INFO - 2018-08-02 00:02:27 --> URI Class Initialized
INFO - 2018-08-02 00:02:27 --> Router Class Initialized
INFO - 2018-08-02 00:02:27 --> Output Class Initialized
INFO - 2018-08-02 00:02:27 --> Security Class Initialized
DEBUG - 2018-08-02 00:02:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 00:02:27 --> Input Class Initialized
INFO - 2018-08-02 00:02:28 --> Language Class Initialized
ERROR - 2018-08-02 00:02:28 --> 404 Page Not Found: /index
INFO - 2018-08-02 00:11:52 --> Config Class Initialized
INFO - 2018-08-02 00:11:52 --> Hooks Class Initialized
DEBUG - 2018-08-02 00:11:52 --> UTF-8 Support Enabled
INFO - 2018-08-02 00:11:52 --> Utf8 Class Initialized
INFO - 2018-08-02 00:11:52 --> URI Class Initialized
INFO - 2018-08-02 00:11:52 --> Router Class Initialized
INFO - 2018-08-02 00:11:52 --> Output Class Initialized
INFO - 2018-08-02 00:11:52 --> Security Class Initialized
DEBUG - 2018-08-02 00:11:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 00:11:52 --> Input Class Initialized
INFO - 2018-08-02 00:11:52 --> Language Class Initialized
INFO - 2018-08-02 00:11:52 --> Language Class Initialized
INFO - 2018-08-02 00:11:52 --> Config Class Initialized
INFO - 2018-08-02 00:11:52 --> Loader Class Initialized
DEBUG - 2018-08-02 00:11:52 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-02 00:11:52 --> Helper loaded: url_helper
INFO - 2018-08-02 00:11:52 --> Helper loaded: form_helper
INFO - 2018-08-02 00:11:52 --> Helper loaded: date_helper
INFO - 2018-08-02 00:11:52 --> Helper loaded: util_helper
INFO - 2018-08-02 00:11:52 --> Helper loaded: text_helper
INFO - 2018-08-02 00:11:52 --> Helper loaded: string_helper
INFO - 2018-08-02 00:11:52 --> Database Driver Class Initialized
DEBUG - 2018-08-02 00:11:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-02 00:11:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-02 00:11:52 --> Email Class Initialized
INFO - 2018-08-02 00:11:52 --> Controller Class Initialized
DEBUG - 2018-08-02 00:11:52 --> Login MX_Controller Initialized
INFO - 2018-08-02 00:11:52 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-02 00:11:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-02 00:11:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-02 00:11:52 --> Email starts for colin-admin. fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-08-02 00:11:52 --> Login status colin-admin. - failure
INFO - 2018-08-02 00:11:52 --> Final output sent to browser
DEBUG - 2018-08-02 00:11:52 --> Total execution time: 0.2770
INFO - 2018-08-02 00:11:55 --> Config Class Initialized
INFO - 2018-08-02 00:11:55 --> Hooks Class Initialized
DEBUG - 2018-08-02 00:11:55 --> UTF-8 Support Enabled
INFO - 2018-08-02 00:11:55 --> Utf8 Class Initialized
INFO - 2018-08-02 00:11:55 --> URI Class Initialized
INFO - 2018-08-02 00:11:55 --> Router Class Initialized
INFO - 2018-08-02 00:11:55 --> Output Class Initialized
INFO - 2018-08-02 00:11:55 --> Security Class Initialized
DEBUG - 2018-08-02 00:11:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 00:11:55 --> Input Class Initialized
INFO - 2018-08-02 00:11:55 --> Language Class Initialized
INFO - 2018-08-02 00:11:55 --> Language Class Initialized
INFO - 2018-08-02 00:11:55 --> Config Class Initialized
INFO - 2018-08-02 00:11:55 --> Loader Class Initialized
DEBUG - 2018-08-02 00:11:55 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-02 00:11:55 --> Helper loaded: url_helper
INFO - 2018-08-02 00:11:55 --> Helper loaded: form_helper
INFO - 2018-08-02 00:11:55 --> Helper loaded: date_helper
INFO - 2018-08-02 00:11:55 --> Helper loaded: util_helper
INFO - 2018-08-02 00:11:55 --> Helper loaded: text_helper
INFO - 2018-08-02 00:11:55 --> Helper loaded: string_helper
INFO - 2018-08-02 00:11:55 --> Database Driver Class Initialized
DEBUG - 2018-08-02 00:11:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-02 00:11:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-02 00:11:55 --> Email Class Initialized
INFO - 2018-08-02 00:11:55 --> Controller Class Initialized
DEBUG - 2018-08-02 00:11:55 --> Login MX_Controller Initialized
INFO - 2018-08-02 00:11:55 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-02 00:11:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-02 00:11:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-02 00:11:55 --> Email starts for colin-admin fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-08-02 00:11:55 --> User session created for 1
INFO - 2018-08-02 00:11:55 --> Login status colin-admin - success
INFO - 2018-08-02 00:11:55 --> Final output sent to browser
DEBUG - 2018-08-02 00:11:55 --> Total execution time: 0.3343
INFO - 2018-08-02 00:11:55 --> Config Class Initialized
INFO - 2018-08-02 00:11:55 --> Hooks Class Initialized
DEBUG - 2018-08-02 00:11:55 --> UTF-8 Support Enabled
INFO - 2018-08-02 00:11:55 --> Utf8 Class Initialized
INFO - 2018-08-02 00:11:55 --> URI Class Initialized
INFO - 2018-08-02 00:11:55 --> Router Class Initialized
INFO - 2018-08-02 00:11:55 --> Output Class Initialized
INFO - 2018-08-02 00:11:55 --> Security Class Initialized
DEBUG - 2018-08-02 00:11:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 00:11:55 --> Input Class Initialized
INFO - 2018-08-02 00:11:55 --> Language Class Initialized
INFO - 2018-08-02 00:11:55 --> Language Class Initialized
INFO - 2018-08-02 00:11:55 --> Config Class Initialized
INFO - 2018-08-02 00:11:55 --> Loader Class Initialized
DEBUG - 2018-08-02 00:11:55 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-02 00:11:55 --> Helper loaded: url_helper
INFO - 2018-08-02 00:11:55 --> Helper loaded: form_helper
INFO - 2018-08-02 00:11:55 --> Helper loaded: date_helper
INFO - 2018-08-02 00:11:55 --> Helper loaded: util_helper
INFO - 2018-08-02 00:11:55 --> Helper loaded: text_helper
INFO - 2018-08-02 00:11:55 --> Helper loaded: string_helper
INFO - 2018-08-02 00:11:55 --> Database Driver Class Initialized
DEBUG - 2018-08-02 00:11:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-02 00:11:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-02 00:11:55 --> Email Class Initialized
INFO - 2018-08-02 00:11:55 --> Controller Class Initialized
DEBUG - 2018-08-02 00:11:55 --> videos MX_Controller Initialized
INFO - 2018-08-02 00:11:55 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-02 00:11:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-08-02 00:11:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-02 00:11:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-08-02 00:11:55 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-02 00:11:55 --> Login MX_Controller Initialized
DEBUG - 2018-08-02 00:11:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-02 00:11:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-08-02 00:11:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-08-02 00:11:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-08-02 00:11:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-08-02 00:11:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-08-02 00:11:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/videos/create_video.php
INFO - 2018-08-02 00:11:56 --> Final output sent to browser
DEBUG - 2018-08-02 00:11:56 --> Total execution time: 0.6572
INFO - 2018-08-02 00:11:57 --> Config Class Initialized
INFO - 2018-08-02 00:11:57 --> Hooks Class Initialized
DEBUG - 2018-08-02 00:11:57 --> UTF-8 Support Enabled
INFO - 2018-08-02 00:11:57 --> Utf8 Class Initialized
INFO - 2018-08-02 00:11:57 --> URI Class Initialized
INFO - 2018-08-02 00:11:57 --> Router Class Initialized
INFO - 2018-08-02 00:11:57 --> Output Class Initialized
INFO - 2018-08-02 00:11:57 --> Security Class Initialized
DEBUG - 2018-08-02 00:11:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 00:11:57 --> Input Class Initialized
INFO - 2018-08-02 00:11:57 --> Language Class Initialized
ERROR - 2018-08-02 00:11:57 --> 404 Page Not Found: /index
INFO - 2018-08-02 00:12:03 --> Config Class Initialized
INFO - 2018-08-02 00:12:03 --> Hooks Class Initialized
DEBUG - 2018-08-02 00:12:03 --> UTF-8 Support Enabled
INFO - 2018-08-02 00:12:03 --> Utf8 Class Initialized
INFO - 2018-08-02 00:12:03 --> URI Class Initialized
INFO - 2018-08-02 00:12:03 --> Router Class Initialized
INFO - 2018-08-02 00:12:03 --> Output Class Initialized
INFO - 2018-08-02 00:12:03 --> Security Class Initialized
DEBUG - 2018-08-02 00:12:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 00:12:03 --> Input Class Initialized
INFO - 2018-08-02 00:12:03 --> Language Class Initialized
INFO - 2018-08-02 00:12:03 --> Language Class Initialized
INFO - 2018-08-02 00:12:03 --> Config Class Initialized
INFO - 2018-08-02 00:12:03 --> Loader Class Initialized
DEBUG - 2018-08-02 00:12:03 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-02 00:12:03 --> Helper loaded: url_helper
INFO - 2018-08-02 00:12:03 --> Helper loaded: form_helper
INFO - 2018-08-02 00:12:03 --> Helper loaded: date_helper
INFO - 2018-08-02 00:12:03 --> Helper loaded: util_helper
INFO - 2018-08-02 00:12:03 --> Helper loaded: text_helper
INFO - 2018-08-02 00:12:03 --> Helper loaded: string_helper
INFO - 2018-08-02 00:12:03 --> Database Driver Class Initialized
DEBUG - 2018-08-02 00:12:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-02 00:12:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-02 00:12:03 --> Email Class Initialized
INFO - 2018-08-02 00:12:03 --> Controller Class Initialized
DEBUG - 2018-08-02 00:12:03 --> videos MX_Controller Initialized
INFO - 2018-08-02 00:12:03 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-02 00:12:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-08-02 00:12:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-02 00:12:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-08-02 00:12:03 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-02 00:12:03 --> Login MX_Controller Initialized
DEBUG - 2018-08-02 00:12:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-02 00:12:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-08-02 00:12:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-08-02 00:12:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-08-02 00:12:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-08-02 00:12:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-08-02 00:12:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/videos/videos.php
INFO - 2018-08-02 00:12:04 --> Final output sent to browser
DEBUG - 2018-08-02 00:12:04 --> Total execution time: 0.5248
INFO - 2018-08-02 00:12:04 --> Config Class Initialized
INFO - 2018-08-02 00:12:04 --> Hooks Class Initialized
DEBUG - 2018-08-02 00:12:04 --> UTF-8 Support Enabled
INFO - 2018-08-02 00:12:04 --> Utf8 Class Initialized
INFO - 2018-08-02 00:12:04 --> URI Class Initialized
INFO - 2018-08-02 00:12:04 --> Router Class Initialized
INFO - 2018-08-02 00:12:04 --> Output Class Initialized
INFO - 2018-08-02 00:12:04 --> Security Class Initialized
DEBUG - 2018-08-02 00:12:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 00:12:04 --> Input Class Initialized
INFO - 2018-08-02 00:12:04 --> Language Class Initialized
INFO - 2018-08-02 00:12:04 --> Language Class Initialized
INFO - 2018-08-02 00:12:04 --> Config Class Initialized
INFO - 2018-08-02 00:12:04 --> Loader Class Initialized
DEBUG - 2018-08-02 00:12:04 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-02 00:12:04 --> Helper loaded: url_helper
INFO - 2018-08-02 00:12:04 --> Helper loaded: form_helper
INFO - 2018-08-02 00:12:04 --> Helper loaded: date_helper
INFO - 2018-08-02 00:12:04 --> Helper loaded: util_helper
INFO - 2018-08-02 00:12:04 --> Helper loaded: text_helper
INFO - 2018-08-02 00:12:04 --> Helper loaded: string_helper
INFO - 2018-08-02 00:12:04 --> Database Driver Class Initialized
DEBUG - 2018-08-02 00:12:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-02 00:12:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-02 00:12:04 --> Email Class Initialized
INFO - 2018-08-02 00:12:04 --> Controller Class Initialized
DEBUG - 2018-08-02 00:12:04 --> videos MX_Controller Initialized
INFO - 2018-08-02 00:12:04 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-02 00:12:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-08-02 00:12:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-02 00:12:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-08-02 00:12:04 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-02 00:12:04 --> Login MX_Controller Initialized
DEBUG - 2018-08-02 00:12:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-02 00:12:04 --> Final output sent to browser
DEBUG - 2018-08-02 00:12:04 --> Total execution time: 0.4809
INFO - 2018-08-02 00:19:22 --> Config Class Initialized
INFO - 2018-08-02 00:19:22 --> Hooks Class Initialized
DEBUG - 2018-08-02 00:19:22 --> UTF-8 Support Enabled
INFO - 2018-08-02 00:19:22 --> Utf8 Class Initialized
INFO - 2018-08-02 00:19:22 --> URI Class Initialized
INFO - 2018-08-02 00:19:22 --> Router Class Initialized
INFO - 2018-08-02 00:19:22 --> Output Class Initialized
INFO - 2018-08-02 00:19:22 --> Security Class Initialized
DEBUG - 2018-08-02 00:19:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 00:19:22 --> Input Class Initialized
INFO - 2018-08-02 00:19:22 --> Language Class Initialized
INFO - 2018-08-02 00:19:22 --> Language Class Initialized
INFO - 2018-08-02 00:19:22 --> Config Class Initialized
INFO - 2018-08-02 00:19:22 --> Loader Class Initialized
DEBUG - 2018-08-02 00:19:22 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-02 00:19:22 --> Helper loaded: url_helper
INFO - 2018-08-02 00:19:22 --> Helper loaded: form_helper
INFO - 2018-08-02 00:19:22 --> Helper loaded: date_helper
INFO - 2018-08-02 00:19:22 --> Helper loaded: util_helper
INFO - 2018-08-02 00:19:22 --> Helper loaded: text_helper
INFO - 2018-08-02 00:19:22 --> Helper loaded: string_helper
INFO - 2018-08-02 00:19:22 --> Database Driver Class Initialized
DEBUG - 2018-08-02 00:19:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-02 00:19:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-02 00:19:22 --> Email Class Initialized
INFO - 2018-08-02 00:19:23 --> Controller Class Initialized
DEBUG - 2018-08-02 00:19:23 --> Home MX_Controller Initialized
DEBUG - 2018-08-02 00:19:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-02 00:19:23 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-02 00:19:23 --> Login MX_Controller Initialized
INFO - 2018-08-02 00:19:23 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-02 00:19:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-02 00:19:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-02 00:19:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-08-02 00:19:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-08-02 00:19:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-08-02 00:19:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-08-02 00:19:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-08-02 00:19:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-08-02 00:19:23 --> Final output sent to browser
DEBUG - 2018-08-02 00:19:23 --> Total execution time: 0.4426
INFO - 2018-08-02 00:19:25 --> Config Class Initialized
INFO - 2018-08-02 00:19:25 --> Hooks Class Initialized
DEBUG - 2018-08-02 00:19:25 --> UTF-8 Support Enabled
INFO - 2018-08-02 00:19:25 --> Utf8 Class Initialized
INFO - 2018-08-02 00:19:25 --> URI Class Initialized
INFO - 2018-08-02 00:19:25 --> Router Class Initialized
INFO - 2018-08-02 00:19:25 --> Config Class Initialized
INFO - 2018-08-02 00:19:25 --> Hooks Class Initialized
INFO - 2018-08-02 00:19:25 --> Output Class Initialized
INFO - 2018-08-02 00:19:25 --> Security Class Initialized
DEBUG - 2018-08-02 00:19:25 --> UTF-8 Support Enabled
DEBUG - 2018-08-02 00:19:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 00:19:25 --> Utf8 Class Initialized
INFO - 2018-08-02 00:19:25 --> Input Class Initialized
INFO - 2018-08-02 00:19:25 --> URI Class Initialized
INFO - 2018-08-02 00:19:25 --> Router Class Initialized
INFO - 2018-08-02 00:19:25 --> Language Class Initialized
INFO - 2018-08-02 00:19:25 --> Output Class Initialized
ERROR - 2018-08-02 00:19:25 --> 404 Page Not Found: /index
INFO - 2018-08-02 00:19:25 --> Security Class Initialized
DEBUG - 2018-08-02 00:19:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 00:19:25 --> Input Class Initialized
INFO - 2018-08-02 00:19:25 --> Language Class Initialized
INFO - 2018-08-02 00:19:25 --> Language Class Initialized
INFO - 2018-08-02 00:19:25 --> Config Class Initialized
INFO - 2018-08-02 00:19:25 --> Config Class Initialized
INFO - 2018-08-02 00:19:25 --> Hooks Class Initialized
INFO - 2018-08-02 00:19:25 --> Loader Class Initialized
DEBUG - 2018-08-02 00:19:25 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
DEBUG - 2018-08-02 00:19:25 --> UTF-8 Support Enabled
INFO - 2018-08-02 00:19:25 --> Utf8 Class Initialized
INFO - 2018-08-02 00:19:25 --> Helper loaded: url_helper
INFO - 2018-08-02 00:19:25 --> URI Class Initialized
INFO - 2018-08-02 00:19:25 --> Router Class Initialized
INFO - 2018-08-02 00:19:25 --> Output Class Initialized
INFO - 2018-08-02 00:19:25 --> Helper loaded: form_helper
INFO - 2018-08-02 00:19:25 --> Security Class Initialized
INFO - 2018-08-02 00:19:25 --> Helper loaded: date_helper
DEBUG - 2018-08-02 00:19:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 00:19:25 --> Input Class Initialized
INFO - 2018-08-02 00:19:25 --> Helper loaded: util_helper
INFO - 2018-08-02 00:19:25 --> Language Class Initialized
INFO - 2018-08-02 00:19:25 --> Helper loaded: text_helper
INFO - 2018-08-02 00:19:25 --> Helper loaded: string_helper
ERROR - 2018-08-02 00:19:25 --> 404 Page Not Found: /index
INFO - 2018-08-02 00:19:25 --> Database Driver Class Initialized
INFO - 2018-08-02 00:19:25 --> Config Class Initialized
INFO - 2018-08-02 00:19:26 --> Hooks Class Initialized
DEBUG - 2018-08-02 00:19:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-08-02 00:19:26 --> UTF-8 Support Enabled
INFO - 2018-08-02 00:19:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-02 00:19:26 --> Utf8 Class Initialized
INFO - 2018-08-02 00:19:26 --> Email Class Initialized
INFO - 2018-08-02 00:19:26 --> Controller Class Initialized
INFO - 2018-08-02 00:19:26 --> URI Class Initialized
DEBUG - 2018-08-02 00:19:26 --> Home MX_Controller Initialized
INFO - 2018-08-02 00:19:26 --> Router Class Initialized
DEBUG - 2018-08-02 00:19:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-08-02 00:19:26 --> Output Class Initialized
INFO - 2018-08-02 00:19:26 --> Security Class Initialized
DEBUG - 2018-08-02 00:19:26 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-02 00:19:26 --> Login MX_Controller Initialized
DEBUG - 2018-08-02 00:19:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 00:19:26 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-02 00:19:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-08-02 00:19:26 --> Input Class Initialized
INFO - 2018-08-02 00:19:26 --> Language Class Initialized
DEBUG - 2018-08-02 00:19:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
ERROR - 2018-08-02 00:19:26 --> 404 Page Not Found: /index
INFO - 2018-08-02 00:19:26 --> Config Class Initialized
INFO - 2018-08-02 00:19:26 --> Hooks Class Initialized
DEBUG - 2018-08-02 00:19:26 --> UTF-8 Support Enabled
INFO - 2018-08-02 00:19:26 --> Utf8 Class Initialized
INFO - 2018-08-02 00:19:26 --> URI Class Initialized
INFO - 2018-08-02 00:19:26 --> Router Class Initialized
INFO - 2018-08-02 00:19:26 --> Output Class Initialized
INFO - 2018-08-02 00:19:26 --> Security Class Initialized
DEBUG - 2018-08-02 00:19:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 00:19:26 --> Input Class Initialized
INFO - 2018-08-02 00:19:26 --> Language Class Initialized
ERROR - 2018-08-02 00:19:26 --> 404 Page Not Found: /index
INFO - 2018-08-02 00:19:26 --> Config Class Initialized
INFO - 2018-08-02 00:19:26 --> Hooks Class Initialized
DEBUG - 2018-08-02 00:19:26 --> UTF-8 Support Enabled
INFO - 2018-08-02 00:19:26 --> Utf8 Class Initialized
INFO - 2018-08-02 00:19:26 --> URI Class Initialized
INFO - 2018-08-02 00:19:26 --> Router Class Initialized
INFO - 2018-08-02 00:19:26 --> Output Class Initialized
INFO - 2018-08-02 00:19:26 --> Security Class Initialized
DEBUG - 2018-08-02 00:19:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 00:19:26 --> Input Class Initialized
INFO - 2018-08-02 00:19:26 --> Language Class Initialized
ERROR - 2018-08-02 00:19:26 --> 404 Page Not Found: /index
INFO - 2018-08-02 00:19:26 --> Config Class Initialized
INFO - 2018-08-02 00:19:26 --> Hooks Class Initialized
DEBUG - 2018-08-02 00:19:26 --> UTF-8 Support Enabled
INFO - 2018-08-02 00:19:26 --> Utf8 Class Initialized
INFO - 2018-08-02 00:19:26 --> URI Class Initialized
INFO - 2018-08-02 00:19:26 --> Router Class Initialized
INFO - 2018-08-02 00:19:26 --> Output Class Initialized
INFO - 2018-08-02 00:19:26 --> Security Class Initialized
DEBUG - 2018-08-02 00:19:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 00:19:26 --> Input Class Initialized
INFO - 2018-08-02 00:19:26 --> Language Class Initialized
ERROR - 2018-08-02 00:19:26 --> 404 Page Not Found: /index
INFO - 2018-08-02 01:46:34 --> Config Class Initialized
INFO - 2018-08-02 01:46:34 --> Hooks Class Initialized
DEBUG - 2018-08-02 01:46:34 --> UTF-8 Support Enabled
INFO - 2018-08-02 01:46:34 --> Utf8 Class Initialized
INFO - 2018-08-02 01:46:34 --> URI Class Initialized
INFO - 2018-08-02 01:46:34 --> Router Class Initialized
INFO - 2018-08-02 01:46:34 --> Output Class Initialized
INFO - 2018-08-02 01:46:34 --> Security Class Initialized
DEBUG - 2018-08-02 01:46:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 01:46:34 --> Input Class Initialized
INFO - 2018-08-02 01:46:34 --> Language Class Initialized
INFO - 2018-08-02 01:46:34 --> Language Class Initialized
INFO - 2018-08-02 01:46:34 --> Config Class Initialized
INFO - 2018-08-02 01:46:34 --> Loader Class Initialized
DEBUG - 2018-08-02 01:46:34 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-02 01:46:34 --> Helper loaded: url_helper
INFO - 2018-08-02 01:46:34 --> Helper loaded: form_helper
INFO - 2018-08-02 01:46:34 --> Helper loaded: date_helper
INFO - 2018-08-02 01:46:34 --> Helper loaded: util_helper
INFO - 2018-08-02 01:46:34 --> Helper loaded: text_helper
INFO - 2018-08-02 01:46:34 --> Helper loaded: string_helper
INFO - 2018-08-02 01:46:34 --> Database Driver Class Initialized
DEBUG - 2018-08-02 01:46:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-02 01:46:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-02 01:46:35 --> Email Class Initialized
INFO - 2018-08-02 01:46:35 --> Controller Class Initialized
DEBUG - 2018-08-02 01:46:35 --> Home MX_Controller Initialized
DEBUG - 2018-08-02 01:46:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-02 01:46:35 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-02 01:46:35 --> Login MX_Controller Initialized
INFO - 2018-08-02 01:46:35 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-02 01:46:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-02 01:46:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-02 01:46:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-08-02 01:46:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-08-02 01:46:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-08-02 01:46:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-08-02 01:46:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-08-02 01:46:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-08-02 01:46:35 --> Final output sent to browser
DEBUG - 2018-08-02 01:46:35 --> Total execution time: 0.4655
INFO - 2018-08-02 01:46:36 --> Config Class Initialized
INFO - 2018-08-02 01:46:36 --> Hooks Class Initialized
DEBUG - 2018-08-02 01:46:36 --> UTF-8 Support Enabled
INFO - 2018-08-02 01:46:36 --> Utf8 Class Initialized
INFO - 2018-08-02 01:46:36 --> Config Class Initialized
INFO - 2018-08-02 01:46:36 --> URI Class Initialized
INFO - 2018-08-02 01:46:36 --> Hooks Class Initialized
INFO - 2018-08-02 01:46:36 --> Router Class Initialized
DEBUG - 2018-08-02 01:46:36 --> UTF-8 Support Enabled
INFO - 2018-08-02 01:46:36 --> Utf8 Class Initialized
INFO - 2018-08-02 01:46:36 --> Output Class Initialized
INFO - 2018-08-02 01:46:36 --> URI Class Initialized
INFO - 2018-08-02 01:46:36 --> Security Class Initialized
DEBUG - 2018-08-02 01:46:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 01:46:36 --> Router Class Initialized
INFO - 2018-08-02 01:46:36 --> Output Class Initialized
INFO - 2018-08-02 01:46:36 --> Input Class Initialized
INFO - 2018-08-02 01:46:37 --> Security Class Initialized
INFO - 2018-08-02 01:46:37 --> Language Class Initialized
DEBUG - 2018-08-02 01:46:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 01:46:37 --> Input Class Initialized
ERROR - 2018-08-02 01:46:37 --> 404 Page Not Found: /index
INFO - 2018-08-02 01:46:37 --> Language Class Initialized
INFO - 2018-08-02 01:46:37 --> Language Class Initialized
INFO - 2018-08-02 01:46:37 --> Config Class Initialized
INFO - 2018-08-02 01:46:37 --> Config Class Initialized
INFO - 2018-08-02 01:46:37 --> Hooks Class Initialized
INFO - 2018-08-02 01:46:37 --> Loader Class Initialized
DEBUG - 2018-08-02 01:46:37 --> UTF-8 Support Enabled
DEBUG - 2018-08-02 01:46:37 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-02 01:46:37 --> Utf8 Class Initialized
INFO - 2018-08-02 01:46:37 --> URI Class Initialized
INFO - 2018-08-02 01:46:37 --> Router Class Initialized
INFO - 2018-08-02 01:46:37 --> Helper loaded: url_helper
INFO - 2018-08-02 01:46:37 --> Output Class Initialized
INFO - 2018-08-02 01:46:37 --> Helper loaded: form_helper
INFO - 2018-08-02 01:46:37 --> Security Class Initialized
INFO - 2018-08-02 01:46:37 --> Helper loaded: date_helper
DEBUG - 2018-08-02 01:46:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 01:46:37 --> Helper loaded: util_helper
INFO - 2018-08-02 01:46:37 --> Input Class Initialized
INFO - 2018-08-02 01:46:37 --> Helper loaded: text_helper
INFO - 2018-08-02 01:46:37 --> Language Class Initialized
INFO - 2018-08-02 01:46:37 --> Helper loaded: string_helper
ERROR - 2018-08-02 01:46:37 --> 404 Page Not Found: /index
INFO - 2018-08-02 01:46:37 --> Database Driver Class Initialized
INFO - 2018-08-02 01:46:37 --> Config Class Initialized
INFO - 2018-08-02 01:46:37 --> Hooks Class Initialized
DEBUG - 2018-08-02 01:46:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-02 01:46:37 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-08-02 01:46:37 --> UTF-8 Support Enabled
INFO - 2018-08-02 01:46:37 --> Utf8 Class Initialized
INFO - 2018-08-02 01:46:37 --> Email Class Initialized
INFO - 2018-08-02 01:46:37 --> Controller Class Initialized
INFO - 2018-08-02 01:46:37 --> URI Class Initialized
DEBUG - 2018-08-02 01:46:37 --> Home MX_Controller Initialized
INFO - 2018-08-02 01:46:37 --> Router Class Initialized
INFO - 2018-08-02 01:46:37 --> Output Class Initialized
DEBUG - 2018-08-02 01:46:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-08-02 01:46:37 --> Security Class Initialized
DEBUG - 2018-08-02 01:46:37 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-02 01:46:37 --> Login MX_Controller Initialized
DEBUG - 2018-08-02 01:46:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 01:46:37 --> Input Class Initialized
INFO - 2018-08-02 01:46:37 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-02 01:46:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-08-02 01:46:37 --> Language Class Initialized
DEBUG - 2018-08-02 01:46:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
ERROR - 2018-08-02 01:46:37 --> 404 Page Not Found: /index
INFO - 2018-08-02 02:04:10 --> Config Class Initialized
INFO - 2018-08-02 02:04:10 --> Hooks Class Initialized
DEBUG - 2018-08-02 02:04:10 --> UTF-8 Support Enabled
INFO - 2018-08-02 02:04:11 --> Utf8 Class Initialized
INFO - 2018-08-02 02:04:11 --> URI Class Initialized
INFO - 2018-08-02 02:04:11 --> Router Class Initialized
INFO - 2018-08-02 02:04:11 --> Output Class Initialized
INFO - 2018-08-02 02:04:11 --> Security Class Initialized
DEBUG - 2018-08-02 02:04:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 02:04:11 --> Input Class Initialized
INFO - 2018-08-02 02:04:11 --> Language Class Initialized
INFO - 2018-08-02 02:04:11 --> Language Class Initialized
INFO - 2018-08-02 02:04:11 --> Config Class Initialized
INFO - 2018-08-02 02:04:11 --> Loader Class Initialized
DEBUG - 2018-08-02 02:04:11 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-02 02:04:11 --> Helper loaded: url_helper
INFO - 2018-08-02 02:04:11 --> Helper loaded: form_helper
INFO - 2018-08-02 02:04:11 --> Helper loaded: date_helper
INFO - 2018-08-02 02:04:11 --> Helper loaded: util_helper
INFO - 2018-08-02 02:04:11 --> Helper loaded: text_helper
INFO - 2018-08-02 02:04:11 --> Helper loaded: string_helper
INFO - 2018-08-02 02:04:11 --> Database Driver Class Initialized
DEBUG - 2018-08-02 02:04:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-02 02:04:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-02 02:04:11 --> Email Class Initialized
INFO - 2018-08-02 02:04:11 --> Controller Class Initialized
DEBUG - 2018-08-02 02:04:11 --> Home MX_Controller Initialized
DEBUG - 2018-08-02 02:04:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-02 02:04:11 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-02 02:04:11 --> Login MX_Controller Initialized
INFO - 2018-08-02 02:04:11 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-02 02:04:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-02 02:04:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-02 02:04:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-08-02 02:04:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-08-02 02:04:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-08-02 02:04:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-08-02 02:04:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-08-02 02:04:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-08-02 02:04:12 --> Final output sent to browser
DEBUG - 2018-08-02 02:04:12 --> Total execution time: 1.2645
INFO - 2018-08-02 02:04:13 --> Config Class Initialized
INFO - 2018-08-02 02:04:13 --> Hooks Class Initialized
DEBUG - 2018-08-02 02:04:13 --> UTF-8 Support Enabled
INFO - 2018-08-02 02:04:13 --> Utf8 Class Initialized
INFO - 2018-08-02 02:04:13 --> Config Class Initialized
INFO - 2018-08-02 02:04:13 --> Hooks Class Initialized
INFO - 2018-08-02 02:04:13 --> URI Class Initialized
DEBUG - 2018-08-02 02:04:13 --> UTF-8 Support Enabled
INFO - 2018-08-02 02:04:13 --> Utf8 Class Initialized
INFO - 2018-08-02 02:04:13 --> Router Class Initialized
INFO - 2018-08-02 02:04:13 --> URI Class Initialized
INFO - 2018-08-02 02:04:13 --> Output Class Initialized
INFO - 2018-08-02 02:04:13 --> Security Class Initialized
INFO - 2018-08-02 02:04:13 --> Router Class Initialized
INFO - 2018-08-02 02:04:13 --> Output Class Initialized
DEBUG - 2018-08-02 02:04:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 02:04:13 --> Security Class Initialized
DEBUG - 2018-08-02 02:04:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 02:04:14 --> Input Class Initialized
INFO - 2018-08-02 02:04:14 --> Input Class Initialized
INFO - 2018-08-02 02:04:14 --> Language Class Initialized
ERROR - 2018-08-02 02:04:14 --> 404 Page Not Found: /index
INFO - 2018-08-02 02:04:14 --> Language Class Initialized
INFO - 2018-08-02 02:04:14 --> Language Class Initialized
INFO - 2018-08-02 02:04:14 --> Config Class Initialized
INFO - 2018-08-02 02:04:14 --> Hooks Class Initialized
INFO - 2018-08-02 02:04:14 --> Config Class Initialized
DEBUG - 2018-08-02 02:04:14 --> UTF-8 Support Enabled
INFO - 2018-08-02 02:04:14 --> Utf8 Class Initialized
INFO - 2018-08-02 02:04:14 --> URI Class Initialized
INFO - 2018-08-02 02:04:14 --> Router Class Initialized
INFO - 2018-08-02 02:04:14 --> Output Class Initialized
INFO - 2018-08-02 02:04:14 --> Security Class Initialized
DEBUG - 2018-08-02 02:04:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 02:04:14 --> Loader Class Initialized
INFO - 2018-08-02 02:04:14 --> Input Class Initialized
DEBUG - 2018-08-02 02:04:14 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-02 02:04:14 --> Language Class Initialized
ERROR - 2018-08-02 02:04:14 --> 404 Page Not Found: /index
INFO - 2018-08-02 02:04:14 --> Helper loaded: url_helper
INFO - 2018-08-02 02:04:14 --> Config Class Initialized
INFO - 2018-08-02 02:04:14 --> Helper loaded: form_helper
INFO - 2018-08-02 02:04:14 --> Hooks Class Initialized
INFO - 2018-08-02 02:04:14 --> Helper loaded: date_helper
DEBUG - 2018-08-02 02:04:14 --> UTF-8 Support Enabled
INFO - 2018-08-02 02:04:14 --> Utf8 Class Initialized
INFO - 2018-08-02 02:04:14 --> URI Class Initialized
INFO - 2018-08-02 02:04:14 --> Helper loaded: util_helper
INFO - 2018-08-02 02:04:14 --> Router Class Initialized
INFO - 2018-08-02 02:04:14 --> Helper loaded: text_helper
INFO - 2018-08-02 02:04:14 --> Output Class Initialized
INFO - 2018-08-02 02:04:14 --> Helper loaded: string_helper
INFO - 2018-08-02 02:04:14 --> Security Class Initialized
DEBUG - 2018-08-02 02:04:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 02:04:14 --> Database Driver Class Initialized
INFO - 2018-08-02 02:04:14 --> Input Class Initialized
DEBUG - 2018-08-02 02:04:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-02 02:04:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-02 02:04:14 --> Language Class Initialized
INFO - 2018-08-02 02:04:14 --> Email Class Initialized
ERROR - 2018-08-02 02:04:14 --> 404 Page Not Found: /index
INFO - 2018-08-02 02:04:14 --> Controller Class Initialized
DEBUG - 2018-08-02 02:04:14 --> Home MX_Controller Initialized
DEBUG - 2018-08-02 02:04:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-02 02:04:14 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-02 02:04:14 --> Login MX_Controller Initialized
INFO - 2018-08-02 02:04:14 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-02 02:04:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-02 02:04:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-02 02:04:20 --> Config Class Initialized
INFO - 2018-08-02 02:04:20 --> Hooks Class Initialized
DEBUG - 2018-08-02 02:04:20 --> UTF-8 Support Enabled
INFO - 2018-08-02 02:04:20 --> Utf8 Class Initialized
INFO - 2018-08-02 02:04:20 --> URI Class Initialized
INFO - 2018-08-02 02:04:20 --> Router Class Initialized
INFO - 2018-08-02 02:04:20 --> Output Class Initialized
INFO - 2018-08-02 02:04:20 --> Security Class Initialized
DEBUG - 2018-08-02 02:04:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 02:04:20 --> Input Class Initialized
INFO - 2018-08-02 02:04:20 --> Language Class Initialized
INFO - 2018-08-02 02:04:20 --> Language Class Initialized
INFO - 2018-08-02 02:04:20 --> Config Class Initialized
INFO - 2018-08-02 02:04:20 --> Loader Class Initialized
DEBUG - 2018-08-02 02:04:20 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-02 02:04:20 --> Helper loaded: url_helper
INFO - 2018-08-02 02:04:20 --> Helper loaded: form_helper
INFO - 2018-08-02 02:04:20 --> Helper loaded: date_helper
INFO - 2018-08-02 02:04:20 --> Helper loaded: util_helper
INFO - 2018-08-02 02:04:20 --> Helper loaded: text_helper
INFO - 2018-08-02 02:04:20 --> Helper loaded: string_helper
INFO - 2018-08-02 02:04:20 --> Database Driver Class Initialized
DEBUG - 2018-08-02 02:04:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-02 02:04:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-02 02:04:20 --> Email Class Initialized
INFO - 2018-08-02 02:04:20 --> Controller Class Initialized
DEBUG - 2018-08-02 02:04:20 --> Home MX_Controller Initialized
DEBUG - 2018-08-02 02:04:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-02 02:04:20 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
INFO - 2018-08-02 02:04:20 --> Config Class Initialized
INFO - 2018-08-02 02:04:20 --> Hooks Class Initialized
DEBUG - 2018-08-02 02:04:20 --> Login MX_Controller Initialized
INFO - 2018-08-02 02:04:20 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-02 02:04:20 --> UTF-8 Support Enabled
DEBUG - 2018-08-02 02:04:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-08-02 02:04:21 --> Utf8 Class Initialized
DEBUG - 2018-08-02 02:04:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-02 02:04:21 --> URI Class Initialized
INFO - 2018-08-02 02:04:21 --> Router Class Initialized
INFO - 2018-08-02 02:04:21 --> Output Class Initialized
INFO - 2018-08-02 02:04:21 --> Security Class Initialized
DEBUG - 2018-08-02 02:04:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 02:04:21 --> Input Class Initialized
INFO - 2018-08-02 02:04:21 --> Language Class Initialized
ERROR - 2018-08-02 02:04:21 --> 404 Page Not Found: /index
INFO - 2018-08-02 02:04:21 --> Config Class Initialized
INFO - 2018-08-02 02:04:21 --> Hooks Class Initialized
DEBUG - 2018-08-02 02:04:21 --> UTF-8 Support Enabled
INFO - 2018-08-02 02:04:21 --> Utf8 Class Initialized
INFO - 2018-08-02 02:04:21 --> URI Class Initialized
INFO - 2018-08-02 02:04:21 --> Router Class Initialized
INFO - 2018-08-02 02:04:21 --> Output Class Initialized
INFO - 2018-08-02 02:04:21 --> Security Class Initialized
DEBUG - 2018-08-02 02:04:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 02:04:21 --> Input Class Initialized
INFO - 2018-08-02 02:04:21 --> Language Class Initialized
ERROR - 2018-08-02 02:04:21 --> 404 Page Not Found: /index
INFO - 2018-08-02 02:04:21 --> Config Class Initialized
INFO - 2018-08-02 02:04:21 --> Hooks Class Initialized
DEBUG - 2018-08-02 02:04:21 --> UTF-8 Support Enabled
INFO - 2018-08-02 02:04:21 --> Utf8 Class Initialized
INFO - 2018-08-02 02:04:21 --> URI Class Initialized
INFO - 2018-08-02 02:04:21 --> Router Class Initialized
INFO - 2018-08-02 02:04:21 --> Output Class Initialized
INFO - 2018-08-02 02:04:21 --> Security Class Initialized
DEBUG - 2018-08-02 02:04:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 02:04:21 --> Input Class Initialized
INFO - 2018-08-02 02:04:21 --> Language Class Initialized
ERROR - 2018-08-02 02:04:21 --> 404 Page Not Found: /index
INFO - 2018-08-02 02:04:21 --> Config Class Initialized
INFO - 2018-08-02 02:04:21 --> Hooks Class Initialized
DEBUG - 2018-08-02 02:04:21 --> UTF-8 Support Enabled
INFO - 2018-08-02 02:04:21 --> Utf8 Class Initialized
INFO - 2018-08-02 02:04:21 --> URI Class Initialized
INFO - 2018-08-02 02:04:21 --> Router Class Initialized
INFO - 2018-08-02 02:04:21 --> Output Class Initialized
INFO - 2018-08-02 02:04:21 --> Security Class Initialized
DEBUG - 2018-08-02 02:04:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 02:04:21 --> Input Class Initialized
INFO - 2018-08-02 02:04:21 --> Language Class Initialized
ERROR - 2018-08-02 02:04:21 --> 404 Page Not Found: /index
INFO - 2018-08-02 02:04:21 --> Config Class Initialized
INFO - 2018-08-02 02:04:21 --> Hooks Class Initialized
DEBUG - 2018-08-02 02:04:21 --> UTF-8 Support Enabled
INFO - 2018-08-02 02:04:21 --> Utf8 Class Initialized
INFO - 2018-08-02 02:04:21 --> URI Class Initialized
INFO - 2018-08-02 02:04:21 --> Router Class Initialized
INFO - 2018-08-02 02:04:21 --> Output Class Initialized
INFO - 2018-08-02 02:04:21 --> Security Class Initialized
DEBUG - 2018-08-02 02:04:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 02:04:21 --> Input Class Initialized
INFO - 2018-08-02 02:04:21 --> Language Class Initialized
ERROR - 2018-08-02 02:04:21 --> 404 Page Not Found: /index
INFO - 2018-08-02 02:04:21 --> Config Class Initialized
INFO - 2018-08-02 02:04:21 --> Hooks Class Initialized
DEBUG - 2018-08-02 02:04:21 --> UTF-8 Support Enabled
INFO - 2018-08-02 02:04:21 --> Utf8 Class Initialized
INFO - 2018-08-02 02:04:21 --> URI Class Initialized
INFO - 2018-08-02 02:04:21 --> Router Class Initialized
INFO - 2018-08-02 02:04:21 --> Output Class Initialized
INFO - 2018-08-02 02:04:21 --> Security Class Initialized
DEBUG - 2018-08-02 02:04:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 02:04:21 --> Input Class Initialized
INFO - 2018-08-02 02:04:21 --> Language Class Initialized
ERROR - 2018-08-02 02:04:21 --> 404 Page Not Found: /index
INFO - 2018-08-02 02:04:22 --> Config Class Initialized
INFO - 2018-08-02 02:04:22 --> Hooks Class Initialized
DEBUG - 2018-08-02 02:04:22 --> UTF-8 Support Enabled
INFO - 2018-08-02 02:04:22 --> Utf8 Class Initialized
INFO - 2018-08-02 02:04:22 --> URI Class Initialized
INFO - 2018-08-02 02:04:22 --> Router Class Initialized
INFO - 2018-08-02 02:04:22 --> Output Class Initialized
INFO - 2018-08-02 02:04:22 --> Security Class Initialized
DEBUG - 2018-08-02 02:04:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 02:04:23 --> Input Class Initialized
INFO - 2018-08-02 02:04:23 --> Language Class Initialized
INFO - 2018-08-02 02:04:23 --> Language Class Initialized
INFO - 2018-08-02 02:04:23 --> Config Class Initialized
INFO - 2018-08-02 02:04:23 --> Loader Class Initialized
DEBUG - 2018-08-02 02:04:23 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-02 02:04:23 --> Helper loaded: url_helper
INFO - 2018-08-02 02:04:23 --> Helper loaded: form_helper
INFO - 2018-08-02 02:04:23 --> Helper loaded: date_helper
INFO - 2018-08-02 02:04:23 --> Helper loaded: util_helper
INFO - 2018-08-02 02:04:23 --> Helper loaded: text_helper
INFO - 2018-08-02 02:04:23 --> Helper loaded: string_helper
INFO - 2018-08-02 02:04:23 --> Database Driver Class Initialized
DEBUG - 2018-08-02 02:04:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-02 02:04:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-02 02:04:23 --> Email Class Initialized
INFO - 2018-08-02 02:04:23 --> Controller Class Initialized
DEBUG - 2018-08-02 02:04:23 --> Home MX_Controller Initialized
DEBUG - 2018-08-02 02:04:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-02 02:04:23 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-02 02:04:23 --> Login MX_Controller Initialized
INFO - 2018-08-02 02:04:23 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-02 02:04:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-02 02:04:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-02 02:04:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-08-02 02:04:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-08-02 02:04:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-08-02 02:04:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-08-02 02:04:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-08-02 02:04:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-08-02 02:04:23 --> Final output sent to browser
DEBUG - 2018-08-02 02:04:23 --> Total execution time: 0.4146
INFO - 2018-08-02 02:04:25 --> Config Class Initialized
INFO - 2018-08-02 02:04:25 --> Hooks Class Initialized
INFO - 2018-08-02 02:04:25 --> Config Class Initialized
INFO - 2018-08-02 02:04:25 --> Hooks Class Initialized
DEBUG - 2018-08-02 02:04:25 --> UTF-8 Support Enabled
DEBUG - 2018-08-02 02:04:25 --> UTF-8 Support Enabled
INFO - 2018-08-02 02:04:25 --> Utf8 Class Initialized
INFO - 2018-08-02 02:04:25 --> URI Class Initialized
INFO - 2018-08-02 02:04:25 --> Router Class Initialized
INFO - 2018-08-02 02:04:25 --> Output Class Initialized
INFO - 2018-08-02 02:04:26 --> Security Class Initialized
INFO - 2018-08-02 02:04:26 --> Utf8 Class Initialized
DEBUG - 2018-08-02 02:04:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 02:04:26 --> Input Class Initialized
INFO - 2018-08-02 02:04:26 --> URI Class Initialized
INFO - 2018-08-02 02:04:26 --> Language Class Initialized
INFO - 2018-08-02 02:04:26 --> Router Class Initialized
INFO - 2018-08-02 02:04:26 --> Output Class Initialized
INFO - 2018-08-02 02:04:26 --> Language Class Initialized
INFO - 2018-08-02 02:04:26 --> Config Class Initialized
INFO - 2018-08-02 02:04:26 --> Security Class Initialized
INFO - 2018-08-02 02:04:26 --> Loader Class Initialized
DEBUG - 2018-08-02 02:04:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-08-02 02:04:26 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-02 02:04:26 --> Input Class Initialized
INFO - 2018-08-02 02:04:26 --> Language Class Initialized
INFO - 2018-08-02 02:04:26 --> Helper loaded: url_helper
INFO - 2018-08-02 02:04:26 --> Helper loaded: form_helper
ERROR - 2018-08-02 02:04:26 --> 404 Page Not Found: /index
INFO - 2018-08-02 02:04:26 --> Helper loaded: date_helper
INFO - 2018-08-02 02:04:26 --> Config Class Initialized
INFO - 2018-08-02 02:04:26 --> Hooks Class Initialized
INFO - 2018-08-02 02:04:26 --> Helper loaded: util_helper
DEBUG - 2018-08-02 02:04:26 --> UTF-8 Support Enabled
INFO - 2018-08-02 02:04:26 --> Utf8 Class Initialized
INFO - 2018-08-02 02:04:26 --> URI Class Initialized
INFO - 2018-08-02 02:04:26 --> Helper loaded: text_helper
INFO - 2018-08-02 02:04:26 --> Router Class Initialized
INFO - 2018-08-02 02:04:26 --> Helper loaded: string_helper
INFO - 2018-08-02 02:04:26 --> Output Class Initialized
INFO - 2018-08-02 02:04:26 --> Database Driver Class Initialized
INFO - 2018-08-02 02:04:26 --> Security Class Initialized
DEBUG - 2018-08-02 02:04:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-08-02 02:04:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-02 02:04:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-02 02:04:26 --> Input Class Initialized
INFO - 2018-08-02 02:04:26 --> Language Class Initialized
INFO - 2018-08-02 02:04:26 --> Email Class Initialized
INFO - 2018-08-02 02:04:26 --> Controller Class Initialized
ERROR - 2018-08-02 02:04:26 --> 404 Page Not Found: /index
DEBUG - 2018-08-02 02:04:26 --> Home MX_Controller Initialized
INFO - 2018-08-02 02:04:26 --> Config Class Initialized
INFO - 2018-08-02 02:04:26 --> Hooks Class Initialized
DEBUG - 2018-08-02 02:04:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-02 02:04:26 --> UTF-8 Support Enabled
DEBUG - 2018-08-02 02:04:26 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-02 02:04:26 --> Login MX_Controller Initialized
INFO - 2018-08-02 02:04:26 --> Utf8 Class Initialized
INFO - 2018-08-02 02:04:26 --> Language file loaded: language/english/data_lang.php
INFO - 2018-08-02 02:04:26 --> URI Class Initialized
DEBUG - 2018-08-02 02:04:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-08-02 02:04:26 --> Router Class Initialized
DEBUG - 2018-08-02 02:04:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-02 02:04:26 --> Output Class Initialized
INFO - 2018-08-02 02:04:26 --> Security Class Initialized
DEBUG - 2018-08-02 02:04:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 02:04:26 --> Input Class Initialized
INFO - 2018-08-02 02:04:26 --> Language Class Initialized
ERROR - 2018-08-02 02:04:26 --> 404 Page Not Found: /index
INFO - 2018-08-02 02:04:26 --> Config Class Initialized
INFO - 2018-08-02 02:04:26 --> Hooks Class Initialized
DEBUG - 2018-08-02 02:04:26 --> UTF-8 Support Enabled
INFO - 2018-08-02 02:04:26 --> Utf8 Class Initialized
INFO - 2018-08-02 02:04:26 --> URI Class Initialized
INFO - 2018-08-02 02:04:26 --> Router Class Initialized
INFO - 2018-08-02 02:04:26 --> Output Class Initialized
INFO - 2018-08-02 02:04:26 --> Security Class Initialized
DEBUG - 2018-08-02 02:04:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 02:04:26 --> Input Class Initialized
INFO - 2018-08-02 02:04:26 --> Language Class Initialized
ERROR - 2018-08-02 02:04:26 --> 404 Page Not Found: /index
INFO - 2018-08-02 02:04:26 --> Config Class Initialized
INFO - 2018-08-02 02:04:26 --> Hooks Class Initialized
DEBUG - 2018-08-02 02:04:27 --> UTF-8 Support Enabled
INFO - 2018-08-02 02:04:27 --> Utf8 Class Initialized
INFO - 2018-08-02 02:04:27 --> URI Class Initialized
INFO - 2018-08-02 02:04:27 --> Router Class Initialized
INFO - 2018-08-02 02:04:27 --> Output Class Initialized
INFO - 2018-08-02 02:04:27 --> Security Class Initialized
DEBUG - 2018-08-02 02:04:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 02:04:27 --> Input Class Initialized
INFO - 2018-08-02 02:04:27 --> Language Class Initialized
ERROR - 2018-08-02 02:04:27 --> 404 Page Not Found: /index
INFO - 2018-08-02 02:04:27 --> Config Class Initialized
INFO - 2018-08-02 02:04:27 --> Hooks Class Initialized
DEBUG - 2018-08-02 02:04:27 --> UTF-8 Support Enabled
INFO - 2018-08-02 02:04:27 --> Utf8 Class Initialized
INFO - 2018-08-02 02:04:27 --> URI Class Initialized
INFO - 2018-08-02 02:04:27 --> Router Class Initialized
INFO - 2018-08-02 02:04:27 --> Output Class Initialized
INFO - 2018-08-02 02:04:27 --> Security Class Initialized
DEBUG - 2018-08-02 02:04:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 02:04:27 --> Input Class Initialized
INFO - 2018-08-02 02:04:27 --> Language Class Initialized
ERROR - 2018-08-02 02:04:27 --> 404 Page Not Found: /index
INFO - 2018-08-02 02:04:45 --> Config Class Initialized
INFO - 2018-08-02 02:04:45 --> Hooks Class Initialized
DEBUG - 2018-08-02 02:04:45 --> UTF-8 Support Enabled
INFO - 2018-08-02 02:04:45 --> Utf8 Class Initialized
INFO - 2018-08-02 02:04:45 --> URI Class Initialized
INFO - 2018-08-02 02:04:45 --> Router Class Initialized
INFO - 2018-08-02 02:04:45 --> Output Class Initialized
INFO - 2018-08-02 02:04:45 --> Security Class Initialized
DEBUG - 2018-08-02 02:04:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 02:04:45 --> Input Class Initialized
INFO - 2018-08-02 02:04:45 --> Language Class Initialized
INFO - 2018-08-02 02:04:45 --> Language Class Initialized
INFO - 2018-08-02 02:04:45 --> Config Class Initialized
INFO - 2018-08-02 02:04:45 --> Loader Class Initialized
DEBUG - 2018-08-02 02:04:45 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-02 02:04:45 --> Helper loaded: url_helper
INFO - 2018-08-02 02:04:45 --> Helper loaded: form_helper
INFO - 2018-08-02 02:04:45 --> Helper loaded: date_helper
INFO - 2018-08-02 02:04:45 --> Helper loaded: util_helper
INFO - 2018-08-02 02:04:45 --> Helper loaded: text_helper
INFO - 2018-08-02 02:04:45 --> Helper loaded: string_helper
INFO - 2018-08-02 02:04:45 --> Database Driver Class Initialized
DEBUG - 2018-08-02 02:04:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-02 02:04:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-02 02:04:45 --> Email Class Initialized
INFO - 2018-08-02 02:04:45 --> Controller Class Initialized
DEBUG - 2018-08-02 02:04:45 --> Home MX_Controller Initialized
DEBUG - 2018-08-02 02:04:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-02 02:04:45 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-02 02:04:45 --> Login MX_Controller Initialized
INFO - 2018-08-02 02:04:45 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-02 02:04:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-02 02:04:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-02 02:04:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-08-02 02:04:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-08-02 02:04:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-08-02 02:04:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-08-02 02:04:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-08-02 02:04:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-08-02 02:04:45 --> Final output sent to browser
DEBUG - 2018-08-02 02:04:45 --> Total execution time: 0.3987
INFO - 2018-08-02 02:04:46 --> Config Class Initialized
INFO - 2018-08-02 02:04:46 --> Hooks Class Initialized
DEBUG - 2018-08-02 02:04:46 --> UTF-8 Support Enabled
INFO - 2018-08-02 02:04:46 --> Utf8 Class Initialized
INFO - 2018-08-02 02:04:46 --> URI Class Initialized
INFO - 2018-08-02 02:04:46 --> Config Class Initialized
INFO - 2018-08-02 02:04:46 --> Hooks Class Initialized
INFO - 2018-08-02 02:04:46 --> Router Class Initialized
DEBUG - 2018-08-02 02:04:46 --> UTF-8 Support Enabled
INFO - 2018-08-02 02:04:46 --> Utf8 Class Initialized
INFO - 2018-08-02 02:04:46 --> URI Class Initialized
INFO - 2018-08-02 02:04:46 --> Router Class Initialized
INFO - 2018-08-02 02:04:46 --> Output Class Initialized
INFO - 2018-08-02 02:04:46 --> Security Class Initialized
INFO - 2018-08-02 02:04:46 --> Output Class Initialized
DEBUG - 2018-08-02 02:04:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 02:04:46 --> Security Class Initialized
DEBUG - 2018-08-02 02:04:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 02:04:46 --> Input Class Initialized
INFO - 2018-08-02 02:04:46 --> Input Class Initialized
INFO - 2018-08-02 02:04:46 --> Language Class Initialized
INFO - 2018-08-02 02:04:46 --> Language Class Initialized
INFO - 2018-08-02 02:04:46 --> Language Class Initialized
ERROR - 2018-08-02 02:04:46 --> 404 Page Not Found: /index
INFO - 2018-08-02 02:04:46 --> Config Class Initialized
INFO - 2018-08-02 02:04:46 --> Loader Class Initialized
INFO - 2018-08-02 02:04:46 --> Config Class Initialized
INFO - 2018-08-02 02:04:47 --> Hooks Class Initialized
DEBUG - 2018-08-02 02:04:47 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
DEBUG - 2018-08-02 02:04:47 --> UTF-8 Support Enabled
INFO - 2018-08-02 02:04:47 --> Utf8 Class Initialized
INFO - 2018-08-02 02:04:47 --> URI Class Initialized
INFO - 2018-08-02 02:04:47 --> Router Class Initialized
INFO - 2018-08-02 02:04:47 --> Helper loaded: url_helper
INFO - 2018-08-02 02:04:47 --> Helper loaded: form_helper
INFO - 2018-08-02 02:04:47 --> Output Class Initialized
INFO - 2018-08-02 02:04:47 --> Helper loaded: date_helper
INFO - 2018-08-02 02:04:47 --> Helper loaded: util_helper
INFO - 2018-08-02 02:04:47 --> Helper loaded: text_helper
INFO - 2018-08-02 02:04:47 --> Helper loaded: string_helper
INFO - 2018-08-02 02:04:47 --> Security Class Initialized
INFO - 2018-08-02 02:04:47 --> Database Driver Class Initialized
DEBUG - 2018-08-02 02:04:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 02:04:47 --> Input Class Initialized
DEBUG - 2018-08-02 02:04:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-02 02:04:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-02 02:04:47 --> Language Class Initialized
ERROR - 2018-08-02 02:04:47 --> 404 Page Not Found: /index
INFO - 2018-08-02 02:04:47 --> Email Class Initialized
INFO - 2018-08-02 02:04:47 --> Controller Class Initialized
INFO - 2018-08-02 02:04:47 --> Config Class Initialized
INFO - 2018-08-02 02:04:47 --> Hooks Class Initialized
DEBUG - 2018-08-02 02:04:47 --> Home MX_Controller Initialized
DEBUG - 2018-08-02 02:04:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-02 02:04:47 --> UTF-8 Support Enabled
INFO - 2018-08-02 02:04:47 --> Utf8 Class Initialized
DEBUG - 2018-08-02 02:04:47 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-02 02:04:47 --> Login MX_Controller Initialized
INFO - 2018-08-02 02:04:47 --> URI Class Initialized
INFO - 2018-08-02 02:04:47 --> Language file loaded: language/english/data_lang.php
INFO - 2018-08-02 02:04:47 --> Router Class Initialized
INFO - 2018-08-02 02:04:47 --> Output Class Initialized
DEBUG - 2018-08-02 02:04:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-08-02 02:04:47 --> Security Class Initialized
DEBUG - 2018-08-02 02:04:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 02:04:47 --> Input Class Initialized
INFO - 2018-08-02 02:04:47 --> Language Class Initialized
DEBUG - 2018-08-02 02:04:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
ERROR - 2018-08-02 02:04:47 --> 404 Page Not Found: /index
INFO - 2018-08-02 02:13:10 --> Config Class Initialized
INFO - 2018-08-02 02:13:10 --> Hooks Class Initialized
DEBUG - 2018-08-02 02:13:10 --> UTF-8 Support Enabled
INFO - 2018-08-02 02:13:10 --> Utf8 Class Initialized
INFO - 2018-08-02 02:13:10 --> URI Class Initialized
INFO - 2018-08-02 02:13:10 --> Router Class Initialized
INFO - 2018-08-02 02:13:10 --> Output Class Initialized
INFO - 2018-08-02 02:13:10 --> Security Class Initialized
DEBUG - 2018-08-02 02:13:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 02:13:10 --> Input Class Initialized
INFO - 2018-08-02 02:13:10 --> Language Class Initialized
INFO - 2018-08-02 02:13:10 --> Language Class Initialized
INFO - 2018-08-02 02:13:10 --> Config Class Initialized
INFO - 2018-08-02 02:13:10 --> Loader Class Initialized
DEBUG - 2018-08-02 02:13:10 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-02 02:13:10 --> Helper loaded: url_helper
INFO - 2018-08-02 02:13:10 --> Helper loaded: form_helper
INFO - 2018-08-02 02:13:10 --> Helper loaded: date_helper
INFO - 2018-08-02 02:13:10 --> Helper loaded: util_helper
INFO - 2018-08-02 02:13:10 --> Helper loaded: text_helper
INFO - 2018-08-02 02:13:10 --> Helper loaded: string_helper
INFO - 2018-08-02 02:13:10 --> Database Driver Class Initialized
DEBUG - 2018-08-02 02:13:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-02 02:13:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-02 02:13:10 --> Email Class Initialized
INFO - 2018-08-02 02:13:10 --> Controller Class Initialized
DEBUG - 2018-08-02 02:13:10 --> Home MX_Controller Initialized
DEBUG - 2018-08-02 02:13:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-02 02:13:10 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-02 02:13:10 --> Login MX_Controller Initialized
INFO - 2018-08-02 02:13:10 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-02 02:13:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-02 02:13:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-02 02:13:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-08-02 02:13:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-08-02 02:13:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-08-02 02:13:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-08-02 02:13:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-08-02 02:13:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-08-02 02:13:10 --> Final output sent to browser
DEBUG - 2018-08-02 02:13:10 --> Total execution time: 0.4355
INFO - 2018-08-02 02:13:13 --> Config Class Initialized
INFO - 2018-08-02 02:13:13 --> Hooks Class Initialized
DEBUG - 2018-08-02 02:13:13 --> UTF-8 Support Enabled
INFO - 2018-08-02 02:13:13 --> Config Class Initialized
INFO - 2018-08-02 02:13:13 --> Hooks Class Initialized
INFO - 2018-08-02 02:13:13 --> Utf8 Class Initialized
DEBUG - 2018-08-02 02:13:13 --> UTF-8 Support Enabled
INFO - 2018-08-02 02:13:13 --> Utf8 Class Initialized
INFO - 2018-08-02 02:13:13 --> URI Class Initialized
INFO - 2018-08-02 02:13:13 --> Router Class Initialized
INFO - 2018-08-02 02:13:13 --> Output Class Initialized
INFO - 2018-08-02 02:13:13 --> Security Class Initialized
DEBUG - 2018-08-02 02:13:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 02:13:13 --> Input Class Initialized
INFO - 2018-08-02 02:13:13 --> Language Class Initialized
INFO - 2018-08-02 02:13:13 --> Language Class Initialized
INFO - 2018-08-02 02:13:13 --> Config Class Initialized
INFO - 2018-08-02 02:13:13 --> Loader Class Initialized
DEBUG - 2018-08-02 02:13:13 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-02 02:13:13 --> URI Class Initialized
INFO - 2018-08-02 02:13:13 --> Helper loaded: url_helper
INFO - 2018-08-02 02:13:13 --> Helper loaded: form_helper
INFO - 2018-08-02 02:13:13 --> Helper loaded: date_helper
INFO - 2018-08-02 02:13:13 --> Helper loaded: util_helper
INFO - 2018-08-02 02:13:13 --> Helper loaded: text_helper
INFO - 2018-08-02 02:13:13 --> Helper loaded: string_helper
INFO - 2018-08-02 02:13:13 --> Database Driver Class Initialized
INFO - 2018-08-02 02:13:13 --> Router Class Initialized
INFO - 2018-08-02 02:13:13 --> Output Class Initialized
DEBUG - 2018-08-02 02:13:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-02 02:13:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-02 02:13:13 --> Security Class Initialized
INFO - 2018-08-02 02:13:13 --> Email Class Initialized
INFO - 2018-08-02 02:13:13 --> Controller Class Initialized
DEBUG - 2018-08-02 02:13:13 --> Home MX_Controller Initialized
DEBUG - 2018-08-02 02:13:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-02 02:13:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-08-02 02:13:13 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
INFO - 2018-08-02 02:13:13 --> Input Class Initialized
DEBUG - 2018-08-02 02:13:13 --> Login MX_Controller Initialized
INFO - 2018-08-02 02:13:13 --> Language file loaded: language/english/data_lang.php
INFO - 2018-08-02 02:13:13 --> Language Class Initialized
DEBUG - 2018-08-02 02:13:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-02 02:13:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
ERROR - 2018-08-02 02:13:13 --> 404 Page Not Found: /index
INFO - 2018-08-02 02:13:14 --> Config Class Initialized
INFO - 2018-08-02 02:13:14 --> Hooks Class Initialized
DEBUG - 2018-08-02 02:13:14 --> UTF-8 Support Enabled
INFO - 2018-08-02 02:13:14 --> Utf8 Class Initialized
INFO - 2018-08-02 02:13:14 --> URI Class Initialized
INFO - 2018-08-02 02:13:14 --> Router Class Initialized
INFO - 2018-08-02 02:13:14 --> Output Class Initialized
INFO - 2018-08-02 02:13:14 --> Security Class Initialized
DEBUG - 2018-08-02 02:13:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 02:13:14 --> Input Class Initialized
INFO - 2018-08-02 02:13:14 --> Language Class Initialized
ERROR - 2018-08-02 02:13:14 --> 404 Page Not Found: /index
INFO - 2018-08-02 02:13:14 --> Config Class Initialized
INFO - 2018-08-02 02:13:14 --> Hooks Class Initialized
DEBUG - 2018-08-02 02:13:14 --> UTF-8 Support Enabled
INFO - 2018-08-02 02:13:14 --> Utf8 Class Initialized
INFO - 2018-08-02 02:13:14 --> URI Class Initialized
INFO - 2018-08-02 02:13:14 --> Router Class Initialized
INFO - 2018-08-02 02:13:14 --> Output Class Initialized
INFO - 2018-08-02 02:13:14 --> Security Class Initialized
DEBUG - 2018-08-02 02:13:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 02:13:14 --> Input Class Initialized
INFO - 2018-08-02 02:13:14 --> Language Class Initialized
ERROR - 2018-08-02 02:13:14 --> 404 Page Not Found: /index
INFO - 2018-08-02 02:14:31 --> Config Class Initialized
INFO - 2018-08-02 02:14:31 --> Hooks Class Initialized
DEBUG - 2018-08-02 02:14:31 --> UTF-8 Support Enabled
INFO - 2018-08-02 02:14:31 --> Utf8 Class Initialized
INFO - 2018-08-02 02:14:31 --> URI Class Initialized
INFO - 2018-08-02 02:14:31 --> Router Class Initialized
INFO - 2018-08-02 02:14:31 --> Output Class Initialized
INFO - 2018-08-02 02:14:31 --> Security Class Initialized
DEBUG - 2018-08-02 02:14:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 02:14:31 --> Input Class Initialized
INFO - 2018-08-02 02:14:31 --> Language Class Initialized
INFO - 2018-08-02 02:14:31 --> Language Class Initialized
INFO - 2018-08-02 02:14:31 --> Config Class Initialized
INFO - 2018-08-02 02:14:31 --> Loader Class Initialized
DEBUG - 2018-08-02 02:14:31 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-02 02:14:31 --> Helper loaded: url_helper
INFO - 2018-08-02 02:14:31 --> Helper loaded: form_helper
INFO - 2018-08-02 02:14:31 --> Helper loaded: date_helper
INFO - 2018-08-02 02:14:31 --> Helper loaded: util_helper
INFO - 2018-08-02 02:14:31 --> Helper loaded: text_helper
INFO - 2018-08-02 02:14:31 --> Helper loaded: string_helper
INFO - 2018-08-02 02:14:31 --> Database Driver Class Initialized
DEBUG - 2018-08-02 02:14:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-02 02:14:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-02 02:14:31 --> Email Class Initialized
INFO - 2018-08-02 02:14:31 --> Controller Class Initialized
DEBUG - 2018-08-02 02:14:31 --> Home MX_Controller Initialized
DEBUG - 2018-08-02 02:14:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-02 02:14:31 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-02 02:14:31 --> Login MX_Controller Initialized
INFO - 2018-08-02 02:14:31 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-02 02:14:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-02 02:14:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-02 02:14:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-08-02 02:14:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-08-02 02:14:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-08-02 02:14:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-08-02 02:14:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-08-02 02:14:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-08-02 02:14:31 --> Final output sent to browser
DEBUG - 2018-08-02 02:14:31 --> Total execution time: 0.4906
INFO - 2018-08-02 02:14:32 --> Config Class Initialized
INFO - 2018-08-02 02:14:32 --> Hooks Class Initialized
DEBUG - 2018-08-02 02:14:32 --> UTF-8 Support Enabled
INFO - 2018-08-02 02:14:32 --> Utf8 Class Initialized
INFO - 2018-08-02 02:14:32 --> URI Class Initialized
INFO - 2018-08-02 02:14:32 --> Config Class Initialized
INFO - 2018-08-02 02:14:32 --> Hooks Class Initialized
INFO - 2018-08-02 02:14:32 --> Router Class Initialized
DEBUG - 2018-08-02 02:14:32 --> UTF-8 Support Enabled
INFO - 2018-08-02 02:14:32 --> Utf8 Class Initialized
INFO - 2018-08-02 02:14:32 --> URI Class Initialized
INFO - 2018-08-02 02:14:32 --> Router Class Initialized
INFO - 2018-08-02 02:14:32 --> Output Class Initialized
INFO - 2018-08-02 02:14:32 --> Security Class Initialized
DEBUG - 2018-08-02 02:14:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 02:14:32 --> Input Class Initialized
INFO - 2018-08-02 02:14:32 --> Output Class Initialized
INFO - 2018-08-02 02:14:32 --> Security Class Initialized
INFO - 2018-08-02 02:14:32 --> Language Class Initialized
DEBUG - 2018-08-02 02:14:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 02:14:33 --> Input Class Initialized
INFO - 2018-08-02 02:14:33 --> Language Class Initialized
INFO - 2018-08-02 02:14:33 --> Config Class Initialized
INFO - 2018-08-02 02:14:33 --> Language Class Initialized
ERROR - 2018-08-02 02:14:33 --> 404 Page Not Found: /index
INFO - 2018-08-02 02:14:33 --> Loader Class Initialized
INFO - 2018-08-02 02:14:33 --> Config Class Initialized
INFO - 2018-08-02 02:14:33 --> Hooks Class Initialized
DEBUG - 2018-08-02 02:14:33 --> UTF-8 Support Enabled
INFO - 2018-08-02 02:14:33 --> Utf8 Class Initialized
INFO - 2018-08-02 02:14:33 --> URI Class Initialized
INFO - 2018-08-02 02:14:33 --> Router Class Initialized
INFO - 2018-08-02 02:14:33 --> Output Class Initialized
INFO - 2018-08-02 02:14:33 --> Security Class Initialized
DEBUG - 2018-08-02 02:14:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 02:14:33 --> Input Class Initialized
DEBUG - 2018-08-02 02:14:33 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-02 02:14:33 --> Helper loaded: url_helper
INFO - 2018-08-02 02:14:33 --> Language Class Initialized
ERROR - 2018-08-02 02:14:33 --> 404 Page Not Found: /index
INFO - 2018-08-02 02:14:33 --> Helper loaded: form_helper
INFO - 2018-08-02 02:14:33 --> Helper loaded: date_helper
INFO - 2018-08-02 02:14:33 --> Config Class Initialized
INFO - 2018-08-02 02:14:33 --> Hooks Class Initialized
INFO - 2018-08-02 02:14:33 --> Helper loaded: util_helper
DEBUG - 2018-08-02 02:14:33 --> UTF-8 Support Enabled
INFO - 2018-08-02 02:14:33 --> Utf8 Class Initialized
INFO - 2018-08-02 02:14:33 --> URI Class Initialized
INFO - 2018-08-02 02:14:33 --> Helper loaded: text_helper
INFO - 2018-08-02 02:14:33 --> Router Class Initialized
INFO - 2018-08-02 02:14:33 --> Helper loaded: string_helper
INFO - 2018-08-02 02:14:33 --> Output Class Initialized
INFO - 2018-08-02 02:14:33 --> Security Class Initialized
INFO - 2018-08-02 02:14:33 --> Database Driver Class Initialized
DEBUG - 2018-08-02 02:14:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-08-02 02:14:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-02 02:14:33 --> Input Class Initialized
INFO - 2018-08-02 02:14:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-02 02:14:33 --> Email Class Initialized
INFO - 2018-08-02 02:14:33 --> Controller Class Initialized
DEBUG - 2018-08-02 02:14:33 --> Home MX_Controller Initialized
DEBUG - 2018-08-02 02:14:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-08-02 02:14:33 --> Language Class Initialized
DEBUG - 2018-08-02 02:14:33 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-02 02:14:33 --> Login MX_Controller Initialized
ERROR - 2018-08-02 02:14:33 --> 404 Page Not Found: /index
INFO - 2018-08-02 02:14:33 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-02 02:14:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-02 02:14:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-02 02:15:14 --> Config Class Initialized
INFO - 2018-08-02 02:15:14 --> Hooks Class Initialized
DEBUG - 2018-08-02 02:15:14 --> UTF-8 Support Enabled
INFO - 2018-08-02 02:15:14 --> Utf8 Class Initialized
INFO - 2018-08-02 02:15:14 --> URI Class Initialized
INFO - 2018-08-02 02:15:14 --> Router Class Initialized
INFO - 2018-08-02 02:15:14 --> Output Class Initialized
INFO - 2018-08-02 02:15:14 --> Security Class Initialized
DEBUG - 2018-08-02 02:15:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 02:15:14 --> Input Class Initialized
INFO - 2018-08-02 02:15:14 --> Language Class Initialized
INFO - 2018-08-02 02:15:14 --> Language Class Initialized
INFO - 2018-08-02 02:15:14 --> Config Class Initialized
INFO - 2018-08-02 02:15:14 --> Loader Class Initialized
DEBUG - 2018-08-02 02:15:14 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-02 02:15:14 --> Helper loaded: url_helper
INFO - 2018-08-02 02:15:14 --> Helper loaded: form_helper
INFO - 2018-08-02 02:15:14 --> Helper loaded: date_helper
INFO - 2018-08-02 02:15:14 --> Helper loaded: util_helper
INFO - 2018-08-02 02:15:14 --> Helper loaded: text_helper
INFO - 2018-08-02 02:15:14 --> Helper loaded: string_helper
INFO - 2018-08-02 02:15:14 --> Database Driver Class Initialized
DEBUG - 2018-08-02 02:15:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-02 02:15:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-02 02:15:14 --> Email Class Initialized
INFO - 2018-08-02 02:15:14 --> Controller Class Initialized
DEBUG - 2018-08-02 02:15:14 --> Home MX_Controller Initialized
DEBUG - 2018-08-02 02:15:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-02 02:15:14 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-02 02:15:14 --> Login MX_Controller Initialized
INFO - 2018-08-02 02:15:14 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-02 02:15:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-02 02:15:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-02 02:15:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-08-02 02:15:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-08-02 02:15:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-08-02 02:15:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-08-02 02:15:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-08-02 02:15:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-08-02 02:15:14 --> Final output sent to browser
DEBUG - 2018-08-02 02:15:14 --> Total execution time: 0.4468
INFO - 2018-08-02 02:15:15 --> Config Class Initialized
INFO - 2018-08-02 02:15:15 --> Hooks Class Initialized
DEBUG - 2018-08-02 02:15:15 --> UTF-8 Support Enabled
INFO - 2018-08-02 02:15:15 --> Utf8 Class Initialized
INFO - 2018-08-02 02:15:15 --> Config Class Initialized
INFO - 2018-08-02 02:15:15 --> URI Class Initialized
INFO - 2018-08-02 02:15:15 --> Hooks Class Initialized
DEBUG - 2018-08-02 02:15:15 --> UTF-8 Support Enabled
INFO - 2018-08-02 02:15:15 --> Utf8 Class Initialized
INFO - 2018-08-02 02:15:15 --> Router Class Initialized
INFO - 2018-08-02 02:15:15 --> URI Class Initialized
INFO - 2018-08-02 02:15:15 --> Output Class Initialized
INFO - 2018-08-02 02:15:15 --> Router Class Initialized
INFO - 2018-08-02 02:15:15 --> Security Class Initialized
DEBUG - 2018-08-02 02:15:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 02:15:15 --> Output Class Initialized
INFO - 2018-08-02 02:15:15 --> Input Class Initialized
INFO - 2018-08-02 02:15:15 --> Language Class Initialized
INFO - 2018-08-02 02:15:15 --> Security Class Initialized
DEBUG - 2018-08-02 02:15:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-08-02 02:15:15 --> 404 Page Not Found: /index
INFO - 2018-08-02 02:15:15 --> Input Class Initialized
INFO - 2018-08-02 02:15:15 --> Language Class Initialized
INFO - 2018-08-02 02:15:15 --> Config Class Initialized
INFO - 2018-08-02 02:15:15 --> Language Class Initialized
INFO - 2018-08-02 02:15:15 --> Hooks Class Initialized
INFO - 2018-08-02 02:15:15 --> Config Class Initialized
DEBUG - 2018-08-02 02:15:15 --> UTF-8 Support Enabled
INFO - 2018-08-02 02:15:16 --> Utf8 Class Initialized
INFO - 2018-08-02 02:15:16 --> URI Class Initialized
INFO - 2018-08-02 02:15:16 --> Loader Class Initialized
DEBUG - 2018-08-02 02:15:16 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-02 02:15:16 --> Router Class Initialized
INFO - 2018-08-02 02:15:16 --> Helper loaded: url_helper
INFO - 2018-08-02 02:15:16 --> Output Class Initialized
INFO - 2018-08-02 02:15:16 --> Security Class Initialized
INFO - 2018-08-02 02:15:16 --> Helper loaded: form_helper
DEBUG - 2018-08-02 02:15:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 02:15:16 --> Helper loaded: date_helper
INFO - 2018-08-02 02:15:16 --> Input Class Initialized
INFO - 2018-08-02 02:15:16 --> Helper loaded: util_helper
INFO - 2018-08-02 02:15:16 --> Language Class Initialized
INFO - 2018-08-02 02:15:16 --> Helper loaded: text_helper
INFO - 2018-08-02 02:15:16 --> Helper loaded: string_helper
ERROR - 2018-08-02 02:15:16 --> 404 Page Not Found: /index
INFO - 2018-08-02 02:15:16 --> Database Driver Class Initialized
INFO - 2018-08-02 02:15:16 --> Config Class Initialized
INFO - 2018-08-02 02:15:16 --> Hooks Class Initialized
DEBUG - 2018-08-02 02:15:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-02 02:15:16 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-08-02 02:15:16 --> UTF-8 Support Enabled
INFO - 2018-08-02 02:15:16 --> Email Class Initialized
INFO - 2018-08-02 02:15:16 --> Controller Class Initialized
DEBUG - 2018-08-02 02:15:16 --> Home MX_Controller Initialized
DEBUG - 2018-08-02 02:15:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-08-02 02:15:16 --> Utf8 Class Initialized
DEBUG - 2018-08-02 02:15:16 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-02 02:15:16 --> Login MX_Controller Initialized
INFO - 2018-08-02 02:15:16 --> URI Class Initialized
INFO - 2018-08-02 02:15:16 --> Router Class Initialized
INFO - 2018-08-02 02:15:16 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-02 02:15:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-08-02 02:15:16 --> Output Class Initialized
DEBUG - 2018-08-02 02:15:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-02 02:15:16 --> Security Class Initialized
DEBUG - 2018-08-02 02:15:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 02:15:16 --> Input Class Initialized
INFO - 2018-08-02 02:15:16 --> Language Class Initialized
ERROR - 2018-08-02 02:15:16 --> 404 Page Not Found: /index
INFO - 2018-08-02 02:15:25 --> Config Class Initialized
INFO - 2018-08-02 02:15:25 --> Hooks Class Initialized
DEBUG - 2018-08-02 02:15:25 --> UTF-8 Support Enabled
INFO - 2018-08-02 02:15:25 --> Utf8 Class Initialized
INFO - 2018-08-02 02:15:25 --> URI Class Initialized
INFO - 2018-08-02 02:15:25 --> Router Class Initialized
INFO - 2018-08-02 02:15:25 --> Output Class Initialized
INFO - 2018-08-02 02:15:25 --> Security Class Initialized
DEBUG - 2018-08-02 02:15:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 02:15:25 --> Input Class Initialized
INFO - 2018-08-02 02:15:25 --> Language Class Initialized
INFO - 2018-08-02 02:15:25 --> Language Class Initialized
INFO - 2018-08-02 02:15:25 --> Config Class Initialized
INFO - 2018-08-02 02:15:25 --> Loader Class Initialized
DEBUG - 2018-08-02 02:15:25 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-02 02:15:25 --> Helper loaded: url_helper
INFO - 2018-08-02 02:15:25 --> Helper loaded: form_helper
INFO - 2018-08-02 02:15:25 --> Helper loaded: date_helper
INFO - 2018-08-02 02:15:25 --> Helper loaded: util_helper
INFO - 2018-08-02 02:15:25 --> Helper loaded: text_helper
INFO - 2018-08-02 02:15:25 --> Helper loaded: string_helper
INFO - 2018-08-02 02:15:25 --> Database Driver Class Initialized
DEBUG - 2018-08-02 02:15:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-02 02:15:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-02 02:15:25 --> Email Class Initialized
INFO - 2018-08-02 02:15:25 --> Controller Class Initialized
DEBUG - 2018-08-02 02:15:25 --> Home MX_Controller Initialized
DEBUG - 2018-08-02 02:15:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-02 02:15:25 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-02 02:15:25 --> Login MX_Controller Initialized
INFO - 2018-08-02 02:15:25 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-02 02:15:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-02 02:15:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-02 02:15:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-08-02 02:15:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-08-02 02:15:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-08-02 02:15:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-08-02 02:15:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-08-02 02:15:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-08-02 02:15:25 --> Final output sent to browser
DEBUG - 2018-08-02 02:15:25 --> Total execution time: 0.4791
INFO - 2018-08-02 02:15:26 --> Config Class Initialized
INFO - 2018-08-02 02:15:26 --> Hooks Class Initialized
INFO - 2018-08-02 02:15:26 --> Config Class Initialized
INFO - 2018-08-02 02:15:26 --> Hooks Class Initialized
DEBUG - 2018-08-02 02:15:26 --> UTF-8 Support Enabled
DEBUG - 2018-08-02 02:15:26 --> UTF-8 Support Enabled
INFO - 2018-08-02 02:15:26 --> Utf8 Class Initialized
INFO - 2018-08-02 02:15:26 --> Utf8 Class Initialized
INFO - 2018-08-02 02:15:27 --> URI Class Initialized
INFO - 2018-08-02 02:15:27 --> URI Class Initialized
INFO - 2018-08-02 02:15:27 --> Router Class Initialized
INFO - 2018-08-02 02:15:27 --> Output Class Initialized
INFO - 2018-08-02 02:15:27 --> Security Class Initialized
DEBUG - 2018-08-02 02:15:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 02:15:27 --> Input Class Initialized
INFO - 2018-08-02 02:15:27 --> Language Class Initialized
INFO - 2018-08-02 02:15:27 --> Language Class Initialized
INFO - 2018-08-02 02:15:27 --> Config Class Initialized
INFO - 2018-08-02 02:15:27 --> Loader Class Initialized
DEBUG - 2018-08-02 02:15:27 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-02 02:15:27 --> Helper loaded: url_helper
INFO - 2018-08-02 02:15:27 --> Helper loaded: form_helper
INFO - 2018-08-02 02:15:27 --> Router Class Initialized
INFO - 2018-08-02 02:15:27 --> Helper loaded: date_helper
INFO - 2018-08-02 02:15:27 --> Output Class Initialized
INFO - 2018-08-02 02:15:27 --> Security Class Initialized
DEBUG - 2018-08-02 02:15:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 02:15:27 --> Input Class Initialized
INFO - 2018-08-02 02:15:27 --> Language Class Initialized
ERROR - 2018-08-02 02:15:27 --> 404 Page Not Found: /index
INFO - 2018-08-02 02:15:27 --> Helper loaded: util_helper
INFO - 2018-08-02 02:15:27 --> Helper loaded: text_helper
INFO - 2018-08-02 02:15:27 --> Helper loaded: string_helper
INFO - 2018-08-02 02:15:27 --> Database Driver Class Initialized
INFO - 2018-08-02 02:15:27 --> Config Class Initialized
INFO - 2018-08-02 02:15:27 --> Hooks Class Initialized
DEBUG - 2018-08-02 02:15:27 --> UTF-8 Support Enabled
INFO - 2018-08-02 02:15:27 --> Utf8 Class Initialized
DEBUG - 2018-08-02 02:15:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-02 02:15:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-02 02:15:27 --> URI Class Initialized
INFO - 2018-08-02 02:15:27 --> Email Class Initialized
INFO - 2018-08-02 02:15:27 --> Controller Class Initialized
DEBUG - 2018-08-02 02:15:27 --> Home MX_Controller Initialized
DEBUG - 2018-08-02 02:15:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-08-02 02:15:27 --> Router Class Initialized
DEBUG - 2018-08-02 02:15:27 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-02 02:15:27 --> Login MX_Controller Initialized
INFO - 2018-08-02 02:15:27 --> Output Class Initialized
INFO - 2018-08-02 02:15:27 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-02 02:15:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-08-02 02:15:27 --> Security Class Initialized
DEBUG - 2018-08-02 02:15:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-02 02:15:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 02:15:27 --> Input Class Initialized
INFO - 2018-08-02 02:15:28 --> Language Class Initialized
ERROR - 2018-08-02 02:15:28 --> 404 Page Not Found: /index
INFO - 2018-08-02 02:15:28 --> Config Class Initialized
INFO - 2018-08-02 02:15:28 --> Hooks Class Initialized
DEBUG - 2018-08-02 02:15:28 --> UTF-8 Support Enabled
INFO - 2018-08-02 02:15:28 --> Utf8 Class Initialized
INFO - 2018-08-02 02:15:28 --> URI Class Initialized
INFO - 2018-08-02 02:15:28 --> Router Class Initialized
INFO - 2018-08-02 02:15:28 --> Output Class Initialized
INFO - 2018-08-02 02:15:28 --> Security Class Initialized
DEBUG - 2018-08-02 02:15:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 02:15:28 --> Input Class Initialized
INFO - 2018-08-02 02:15:28 --> Language Class Initialized
ERROR - 2018-08-02 02:15:28 --> 404 Page Not Found: /index
INFO - 2018-08-02 02:16:52 --> Config Class Initialized
INFO - 2018-08-02 02:16:52 --> Hooks Class Initialized
DEBUG - 2018-08-02 02:16:52 --> UTF-8 Support Enabled
INFO - 2018-08-02 02:16:52 --> Utf8 Class Initialized
INFO - 2018-08-02 02:16:53 --> URI Class Initialized
INFO - 2018-08-02 02:16:53 --> Router Class Initialized
INFO - 2018-08-02 02:16:53 --> Output Class Initialized
INFO - 2018-08-02 02:16:53 --> Security Class Initialized
DEBUG - 2018-08-02 02:16:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 02:16:53 --> Input Class Initialized
INFO - 2018-08-02 02:16:53 --> Language Class Initialized
INFO - 2018-08-02 02:16:53 --> Language Class Initialized
INFO - 2018-08-02 02:16:53 --> Config Class Initialized
INFO - 2018-08-02 02:16:53 --> Loader Class Initialized
DEBUG - 2018-08-02 02:16:53 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-02 02:16:53 --> Helper loaded: url_helper
INFO - 2018-08-02 02:16:53 --> Helper loaded: form_helper
INFO - 2018-08-02 02:16:53 --> Helper loaded: date_helper
INFO - 2018-08-02 02:16:53 --> Helper loaded: util_helper
INFO - 2018-08-02 02:16:53 --> Helper loaded: text_helper
INFO - 2018-08-02 02:16:53 --> Helper loaded: string_helper
INFO - 2018-08-02 02:16:53 --> Database Driver Class Initialized
DEBUG - 2018-08-02 02:16:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-02 02:16:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-02 02:16:53 --> Email Class Initialized
INFO - 2018-08-02 02:16:53 --> Controller Class Initialized
DEBUG - 2018-08-02 02:16:53 --> Home MX_Controller Initialized
DEBUG - 2018-08-02 02:16:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-02 02:16:53 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-02 02:16:53 --> Login MX_Controller Initialized
INFO - 2018-08-02 02:16:53 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-02 02:16:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-02 02:16:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-02 02:16:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-08-02 02:16:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-08-02 02:16:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-08-02 02:16:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-08-02 02:16:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-08-02 02:16:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-08-02 02:16:53 --> Final output sent to browser
DEBUG - 2018-08-02 02:16:53 --> Total execution time: 0.4673
INFO - 2018-08-02 02:16:54 --> Config Class Initialized
INFO - 2018-08-02 02:16:54 --> Hooks Class Initialized
DEBUG - 2018-08-02 02:16:54 --> UTF-8 Support Enabled
INFO - 2018-08-02 02:16:54 --> Utf8 Class Initialized
INFO - 2018-08-02 02:16:54 --> Config Class Initialized
INFO - 2018-08-02 02:16:54 --> Hooks Class Initialized
INFO - 2018-08-02 02:16:54 --> URI Class Initialized
DEBUG - 2018-08-02 02:16:54 --> UTF-8 Support Enabled
INFO - 2018-08-02 02:16:54 --> Router Class Initialized
INFO - 2018-08-02 02:16:54 --> Utf8 Class Initialized
INFO - 2018-08-02 02:16:54 --> URI Class Initialized
INFO - 2018-08-02 02:16:54 --> Router Class Initialized
INFO - 2018-08-02 02:16:54 --> Output Class Initialized
INFO - 2018-08-02 02:16:54 --> Security Class Initialized
DEBUG - 2018-08-02 02:16:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 02:16:54 --> Input Class Initialized
INFO - 2018-08-02 02:16:54 --> Language Class Initialized
INFO - 2018-08-02 02:16:54 --> Language Class Initialized
INFO - 2018-08-02 02:16:54 --> Config Class Initialized
INFO - 2018-08-02 02:16:54 --> Output Class Initialized
INFO - 2018-08-02 02:16:54 --> Loader Class Initialized
DEBUG - 2018-08-02 02:16:54 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-02 02:16:54 --> Security Class Initialized
INFO - 2018-08-02 02:16:54 --> Helper loaded: url_helper
DEBUG - 2018-08-02 02:16:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 02:16:54 --> Helper loaded: form_helper
INFO - 2018-08-02 02:16:54 --> Input Class Initialized
INFO - 2018-08-02 02:16:54 --> Helper loaded: date_helper
INFO - 2018-08-02 02:16:54 --> Helper loaded: util_helper
INFO - 2018-08-02 02:16:54 --> Helper loaded: text_helper
INFO - 2018-08-02 02:16:54 --> Language Class Initialized
INFO - 2018-08-02 02:16:54 --> Helper loaded: string_helper
ERROR - 2018-08-02 02:16:54 --> 404 Page Not Found: /index
INFO - 2018-08-02 02:16:54 --> Database Driver Class Initialized
DEBUG - 2018-08-02 02:16:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-02 02:16:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-02 02:16:55 --> Email Class Initialized
INFO - 2018-08-02 02:16:55 --> Controller Class Initialized
DEBUG - 2018-08-02 02:16:55 --> Home MX_Controller Initialized
INFO - 2018-08-02 02:16:55 --> Config Class Initialized
INFO - 2018-08-02 02:16:55 --> Hooks Class Initialized
DEBUG - 2018-08-02 02:16:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-02 02:16:55 --> UTF-8 Support Enabled
DEBUG - 2018-08-02 02:16:55 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-02 02:16:55 --> Login MX_Controller Initialized
INFO - 2018-08-02 02:16:55 --> Utf8 Class Initialized
INFO - 2018-08-02 02:16:55 --> Language file loaded: language/english/data_lang.php
INFO - 2018-08-02 02:16:55 --> URI Class Initialized
DEBUG - 2018-08-02 02:16:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-02 02:16:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-02 02:16:55 --> Router Class Initialized
INFO - 2018-08-02 02:16:55 --> Output Class Initialized
INFO - 2018-08-02 02:16:55 --> Security Class Initialized
DEBUG - 2018-08-02 02:16:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 02:16:55 --> Input Class Initialized
INFO - 2018-08-02 02:16:55 --> Language Class Initialized
ERROR - 2018-08-02 02:16:55 --> 404 Page Not Found: /index
INFO - 2018-08-02 02:16:55 --> Config Class Initialized
INFO - 2018-08-02 02:16:55 --> Hooks Class Initialized
DEBUG - 2018-08-02 02:16:55 --> UTF-8 Support Enabled
INFO - 2018-08-02 02:16:55 --> Utf8 Class Initialized
INFO - 2018-08-02 02:16:55 --> URI Class Initialized
INFO - 2018-08-02 02:16:55 --> Router Class Initialized
INFO - 2018-08-02 02:16:55 --> Output Class Initialized
INFO - 2018-08-02 02:16:55 --> Security Class Initialized
DEBUG - 2018-08-02 02:16:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 02:16:55 --> Input Class Initialized
INFO - 2018-08-02 02:16:55 --> Language Class Initialized
ERROR - 2018-08-02 02:16:55 --> 404 Page Not Found: /index
INFO - 2018-08-02 02:18:49 --> Config Class Initialized
INFO - 2018-08-02 02:18:49 --> Hooks Class Initialized
DEBUG - 2018-08-02 02:18:49 --> UTF-8 Support Enabled
INFO - 2018-08-02 02:18:49 --> Utf8 Class Initialized
INFO - 2018-08-02 02:18:49 --> URI Class Initialized
INFO - 2018-08-02 02:18:49 --> Router Class Initialized
INFO - 2018-08-02 02:18:49 --> Output Class Initialized
INFO - 2018-08-02 02:18:49 --> Security Class Initialized
DEBUG - 2018-08-02 02:18:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 02:18:49 --> Input Class Initialized
INFO - 2018-08-02 02:18:49 --> Language Class Initialized
INFO - 2018-08-02 02:18:49 --> Language Class Initialized
INFO - 2018-08-02 02:18:49 --> Config Class Initialized
INFO - 2018-08-02 02:18:49 --> Loader Class Initialized
DEBUG - 2018-08-02 02:18:49 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-02 02:18:49 --> Helper loaded: url_helper
INFO - 2018-08-02 02:18:49 --> Helper loaded: form_helper
INFO - 2018-08-02 02:18:49 --> Helper loaded: date_helper
INFO - 2018-08-02 02:18:49 --> Helper loaded: util_helper
INFO - 2018-08-02 02:18:49 --> Helper loaded: text_helper
INFO - 2018-08-02 02:18:49 --> Helper loaded: string_helper
INFO - 2018-08-02 02:18:49 --> Database Driver Class Initialized
DEBUG - 2018-08-02 02:18:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-02 02:18:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-02 02:18:49 --> Email Class Initialized
INFO - 2018-08-02 02:18:49 --> Controller Class Initialized
DEBUG - 2018-08-02 02:18:49 --> Home MX_Controller Initialized
DEBUG - 2018-08-02 02:18:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-02 02:18:49 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-02 02:18:49 --> Login MX_Controller Initialized
INFO - 2018-08-02 02:18:49 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-02 02:18:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-02 02:18:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-02 02:18:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-08-02 02:18:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-08-02 02:18:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-08-02 02:18:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-08-02 02:18:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-08-02 02:18:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-08-02 02:18:49 --> Final output sent to browser
DEBUG - 2018-08-02 02:18:50 --> Total execution time: 0.4598
INFO - 2018-08-02 02:18:50 --> Config Class Initialized
INFO - 2018-08-02 02:18:50 --> Hooks Class Initialized
DEBUG - 2018-08-02 02:18:50 --> UTF-8 Support Enabled
INFO - 2018-08-02 02:18:50 --> Utf8 Class Initialized
INFO - 2018-08-02 02:18:50 --> Config Class Initialized
INFO - 2018-08-02 02:18:50 --> Hooks Class Initialized
INFO - 2018-08-02 02:18:50 --> URI Class Initialized
DEBUG - 2018-08-02 02:18:50 --> UTF-8 Support Enabled
INFO - 2018-08-02 02:18:50 --> Router Class Initialized
INFO - 2018-08-02 02:18:50 --> Utf8 Class Initialized
INFO - 2018-08-02 02:18:50 --> Output Class Initialized
INFO - 2018-08-02 02:18:50 --> URI Class Initialized
INFO - 2018-08-02 02:18:50 --> Router Class Initialized
INFO - 2018-08-02 02:18:50 --> Security Class Initialized
INFO - 2018-08-02 02:18:50 --> Output Class Initialized
INFO - 2018-08-02 02:18:50 --> Security Class Initialized
DEBUG - 2018-08-02 02:18:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-08-02 02:18:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 02:18:51 --> Input Class Initialized
INFO - 2018-08-02 02:18:51 --> Language Class Initialized
INFO - 2018-08-02 02:18:51 --> Input Class Initialized
ERROR - 2018-08-02 02:18:51 --> 404 Page Not Found: /index
INFO - 2018-08-02 02:18:51 --> Language Class Initialized
INFO - 2018-08-02 02:18:51 --> Language Class Initialized
INFO - 2018-08-02 02:18:51 --> Config Class Initialized
INFO - 2018-08-02 02:18:51 --> Hooks Class Initialized
INFO - 2018-08-02 02:18:51 --> Config Class Initialized
DEBUG - 2018-08-02 02:18:51 --> UTF-8 Support Enabled
INFO - 2018-08-02 02:18:51 --> Loader Class Initialized
INFO - 2018-08-02 02:18:51 --> Utf8 Class Initialized
INFO - 2018-08-02 02:18:51 --> URI Class Initialized
INFO - 2018-08-02 02:18:51 --> Router Class Initialized
INFO - 2018-08-02 02:18:51 --> Output Class Initialized
DEBUG - 2018-08-02 02:18:51 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-02 02:18:51 --> Security Class Initialized
DEBUG - 2018-08-02 02:18:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 02:18:51 --> Input Class Initialized
INFO - 2018-08-02 02:18:51 --> Helper loaded: url_helper
INFO - 2018-08-02 02:18:51 --> Language Class Initialized
INFO - 2018-08-02 02:18:51 --> Helper loaded: form_helper
ERROR - 2018-08-02 02:18:51 --> 404 Page Not Found: /index
INFO - 2018-08-02 02:18:51 --> Helper loaded: date_helper
INFO - 2018-08-02 02:18:51 --> Helper loaded: util_helper
INFO - 2018-08-02 02:18:51 --> Config Class Initialized
INFO - 2018-08-02 02:18:51 --> Hooks Class Initialized
INFO - 2018-08-02 02:18:51 --> Helper loaded: text_helper
INFO - 2018-08-02 02:18:51 --> Helper loaded: string_helper
DEBUG - 2018-08-02 02:18:51 --> UTF-8 Support Enabled
INFO - 2018-08-02 02:18:51 --> Utf8 Class Initialized
INFO - 2018-08-02 02:18:51 --> Database Driver Class Initialized
INFO - 2018-08-02 02:18:51 --> URI Class Initialized
DEBUG - 2018-08-02 02:18:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-02 02:18:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-02 02:18:51 --> Router Class Initialized
INFO - 2018-08-02 02:18:51 --> Email Class Initialized
INFO - 2018-08-02 02:18:51 --> Controller Class Initialized
DEBUG - 2018-08-02 02:18:51 --> Home MX_Controller Initialized
INFO - 2018-08-02 02:18:51 --> Output Class Initialized
DEBUG - 2018-08-02 02:18:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-08-02 02:18:51 --> Security Class Initialized
DEBUG - 2018-08-02 02:18:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-08-02 02:18:51 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-02 02:18:51 --> Login MX_Controller Initialized
INFO - 2018-08-02 02:18:51 --> Input Class Initialized
INFO - 2018-08-02 02:18:51 --> Language file loaded: language/english/data_lang.php
INFO - 2018-08-02 02:18:51 --> Language Class Initialized
DEBUG - 2018-08-02 02:18:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
ERROR - 2018-08-02 02:18:51 --> 404 Page Not Found: /index
DEBUG - 2018-08-02 02:18:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-02 02:18:51 --> Config Class Initialized
INFO - 2018-08-02 02:18:51 --> Hooks Class Initialized
DEBUG - 2018-08-02 02:18:51 --> UTF-8 Support Enabled
INFO - 2018-08-02 02:18:51 --> Utf8 Class Initialized
INFO - 2018-08-02 02:18:51 --> URI Class Initialized
INFO - 2018-08-02 02:18:51 --> Router Class Initialized
INFO - 2018-08-02 02:18:51 --> Output Class Initialized
INFO - 2018-08-02 02:18:51 --> Security Class Initialized
DEBUG - 2018-08-02 02:18:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 02:18:51 --> Input Class Initialized
INFO - 2018-08-02 02:18:51 --> Language Class Initialized
ERROR - 2018-08-02 02:18:51 --> 404 Page Not Found: /index
INFO - 2018-08-02 02:18:51 --> Config Class Initialized
INFO - 2018-08-02 02:18:52 --> Hooks Class Initialized
DEBUG - 2018-08-02 02:18:52 --> UTF-8 Support Enabled
INFO - 2018-08-02 02:18:52 --> Utf8 Class Initialized
INFO - 2018-08-02 02:18:52 --> URI Class Initialized
INFO - 2018-08-02 02:18:52 --> Router Class Initialized
INFO - 2018-08-02 02:18:52 --> Output Class Initialized
INFO - 2018-08-02 02:18:52 --> Security Class Initialized
DEBUG - 2018-08-02 02:18:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 02:18:52 --> Input Class Initialized
INFO - 2018-08-02 02:18:52 --> Language Class Initialized
ERROR - 2018-08-02 02:18:52 --> 404 Page Not Found: /index
INFO - 2018-08-02 02:18:52 --> Config Class Initialized
INFO - 2018-08-02 02:18:52 --> Hooks Class Initialized
DEBUG - 2018-08-02 02:18:52 --> UTF-8 Support Enabled
INFO - 2018-08-02 02:18:52 --> Utf8 Class Initialized
INFO - 2018-08-02 02:18:52 --> URI Class Initialized
INFO - 2018-08-02 02:18:52 --> Router Class Initialized
INFO - 2018-08-02 02:18:52 --> Output Class Initialized
INFO - 2018-08-02 02:18:52 --> Security Class Initialized
DEBUG - 2018-08-02 02:18:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 02:18:52 --> Input Class Initialized
INFO - 2018-08-02 02:18:52 --> Language Class Initialized
ERROR - 2018-08-02 02:18:52 --> 404 Page Not Found: /index
INFO - 2018-08-02 02:19:36 --> Config Class Initialized
INFO - 2018-08-02 02:19:36 --> Hooks Class Initialized
DEBUG - 2018-08-02 02:19:36 --> UTF-8 Support Enabled
INFO - 2018-08-02 02:19:36 --> Utf8 Class Initialized
INFO - 2018-08-02 02:19:36 --> URI Class Initialized
INFO - 2018-08-02 02:19:36 --> Router Class Initialized
INFO - 2018-08-02 02:19:36 --> Output Class Initialized
INFO - 2018-08-02 02:19:36 --> Security Class Initialized
DEBUG - 2018-08-02 02:19:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 02:19:36 --> Input Class Initialized
INFO - 2018-08-02 02:19:36 --> Language Class Initialized
INFO - 2018-08-02 02:19:36 --> Language Class Initialized
INFO - 2018-08-02 02:19:36 --> Config Class Initialized
INFO - 2018-08-02 02:19:36 --> Loader Class Initialized
DEBUG - 2018-08-02 02:19:36 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-02 02:19:36 --> Helper loaded: url_helper
INFO - 2018-08-02 02:19:36 --> Helper loaded: form_helper
INFO - 2018-08-02 02:19:36 --> Helper loaded: date_helper
INFO - 2018-08-02 02:19:36 --> Helper loaded: util_helper
INFO - 2018-08-02 02:19:36 --> Helper loaded: text_helper
INFO - 2018-08-02 02:19:36 --> Helper loaded: string_helper
INFO - 2018-08-02 02:19:37 --> Database Driver Class Initialized
DEBUG - 2018-08-02 02:19:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-02 02:19:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-02 02:19:37 --> Email Class Initialized
INFO - 2018-08-02 02:19:37 --> Controller Class Initialized
DEBUG - 2018-08-02 02:19:37 --> Home MX_Controller Initialized
DEBUG - 2018-08-02 02:19:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-02 02:19:37 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-02 02:19:37 --> Login MX_Controller Initialized
INFO - 2018-08-02 02:19:37 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-02 02:19:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-02 02:19:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-02 02:19:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-08-02 02:19:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-08-02 02:19:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-08-02 02:19:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-08-02 02:19:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-08-02 02:19:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-08-02 02:19:37 --> Final output sent to browser
DEBUG - 2018-08-02 02:19:37 --> Total execution time: 0.4618
INFO - 2018-08-02 02:19:37 --> Config Class Initialized
INFO - 2018-08-02 02:19:37 --> Hooks Class Initialized
DEBUG - 2018-08-02 02:19:37 --> UTF-8 Support Enabled
INFO - 2018-08-02 02:19:37 --> Utf8 Class Initialized
INFO - 2018-08-02 02:19:38 --> Config Class Initialized
INFO - 2018-08-02 02:19:38 --> Hooks Class Initialized
INFO - 2018-08-02 02:19:38 --> URI Class Initialized
DEBUG - 2018-08-02 02:19:38 --> UTF-8 Support Enabled
INFO - 2018-08-02 02:19:38 --> Utf8 Class Initialized
INFO - 2018-08-02 02:19:38 --> URI Class Initialized
INFO - 2018-08-02 02:19:38 --> Router Class Initialized
INFO - 2018-08-02 02:19:38 --> Router Class Initialized
INFO - 2018-08-02 02:19:38 --> Output Class Initialized
INFO - 2018-08-02 02:19:38 --> Security Class Initialized
DEBUG - 2018-08-02 02:19:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 02:19:38 --> Output Class Initialized
INFO - 2018-08-02 02:19:38 --> Input Class Initialized
INFO - 2018-08-02 02:19:38 --> Security Class Initialized
DEBUG - 2018-08-02 02:19:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 02:19:38 --> Language Class Initialized
INFO - 2018-08-02 02:19:38 --> Input Class Initialized
INFO - 2018-08-02 02:19:38 --> Language Class Initialized
INFO - 2018-08-02 02:19:38 --> Language Class Initialized
ERROR - 2018-08-02 02:19:38 --> 404 Page Not Found: /index
INFO - 2018-08-02 02:19:38 --> Config Class Initialized
INFO - 2018-08-02 02:19:38 --> Loader Class Initialized
DEBUG - 2018-08-02 02:19:38 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-02 02:19:38 --> Helper loaded: url_helper
INFO - 2018-08-02 02:19:38 --> Config Class Initialized
INFO - 2018-08-02 02:19:38 --> Hooks Class Initialized
INFO - 2018-08-02 02:19:38 --> Helper loaded: form_helper
DEBUG - 2018-08-02 02:19:38 --> UTF-8 Support Enabled
INFO - 2018-08-02 02:19:38 --> Helper loaded: date_helper
INFO - 2018-08-02 02:19:38 --> Utf8 Class Initialized
INFO - 2018-08-02 02:19:38 --> Helper loaded: util_helper
INFO - 2018-08-02 02:19:38 --> URI Class Initialized
INFO - 2018-08-02 02:19:38 --> Router Class Initialized
INFO - 2018-08-02 02:19:38 --> Output Class Initialized
INFO - 2018-08-02 02:19:38 --> Security Class Initialized
DEBUG - 2018-08-02 02:19:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 02:19:38 --> Helper loaded: text_helper
INFO - 2018-08-02 02:19:38 --> Input Class Initialized
INFO - 2018-08-02 02:19:38 --> Helper loaded: string_helper
INFO - 2018-08-02 02:19:38 --> Language Class Initialized
ERROR - 2018-08-02 02:19:38 --> 404 Page Not Found: /index
INFO - 2018-08-02 02:19:38 --> Database Driver Class Initialized
INFO - 2018-08-02 02:19:38 --> Config Class Initialized
INFO - 2018-08-02 02:19:38 --> Hooks Class Initialized
DEBUG - 2018-08-02 02:19:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-02 02:19:38 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-08-02 02:19:38 --> UTF-8 Support Enabled
INFO - 2018-08-02 02:19:38 --> Utf8 Class Initialized
INFO - 2018-08-02 02:19:38 --> Email Class Initialized
INFO - 2018-08-02 02:19:38 --> URI Class Initialized
INFO - 2018-08-02 02:19:38 --> Controller Class Initialized
DEBUG - 2018-08-02 02:19:38 --> Home MX_Controller Initialized
INFO - 2018-08-02 02:19:38 --> Router Class Initialized
DEBUG - 2018-08-02 02:19:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-08-02 02:19:38 --> Output Class Initialized
INFO - 2018-08-02 02:19:38 --> Security Class Initialized
DEBUG - 2018-08-02 02:19:38 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-02 02:19:38 --> Login MX_Controller Initialized
DEBUG - 2018-08-02 02:19:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 02:19:39 --> Language file loaded: language/english/data_lang.php
INFO - 2018-08-02 02:19:39 --> Input Class Initialized
DEBUG - 2018-08-02 02:19:39 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-08-02 02:19:39 --> Language Class Initialized
DEBUG - 2018-08-02 02:19:39 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
ERROR - 2018-08-02 02:19:39 --> 404 Page Not Found: /index
INFO - 2018-08-02 02:19:39 --> Config Class Initialized
INFO - 2018-08-02 02:19:39 --> Hooks Class Initialized
DEBUG - 2018-08-02 02:19:39 --> UTF-8 Support Enabled
INFO - 2018-08-02 02:19:39 --> Utf8 Class Initialized
INFO - 2018-08-02 02:19:39 --> URI Class Initialized
INFO - 2018-08-02 02:19:39 --> Router Class Initialized
INFO - 2018-08-02 02:19:39 --> Output Class Initialized
INFO - 2018-08-02 02:19:39 --> Security Class Initialized
DEBUG - 2018-08-02 02:19:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 02:19:39 --> Input Class Initialized
INFO - 2018-08-02 02:19:39 --> Language Class Initialized
ERROR - 2018-08-02 02:19:39 --> 404 Page Not Found: /index
INFO - 2018-08-02 02:19:39 --> Config Class Initialized
INFO - 2018-08-02 02:19:39 --> Hooks Class Initialized
DEBUG - 2018-08-02 02:19:39 --> UTF-8 Support Enabled
INFO - 2018-08-02 02:19:39 --> Utf8 Class Initialized
INFO - 2018-08-02 02:19:39 --> URI Class Initialized
INFO - 2018-08-02 02:19:39 --> Router Class Initialized
INFO - 2018-08-02 02:19:39 --> Output Class Initialized
INFO - 2018-08-02 02:19:39 --> Security Class Initialized
DEBUG - 2018-08-02 02:19:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 02:19:39 --> Input Class Initialized
INFO - 2018-08-02 02:19:39 --> Language Class Initialized
ERROR - 2018-08-02 02:19:39 --> 404 Page Not Found: /index
INFO - 2018-08-02 02:19:39 --> Config Class Initialized
INFO - 2018-08-02 02:19:39 --> Hooks Class Initialized
DEBUG - 2018-08-02 02:19:39 --> UTF-8 Support Enabled
INFO - 2018-08-02 02:19:39 --> Utf8 Class Initialized
INFO - 2018-08-02 02:19:39 --> URI Class Initialized
INFO - 2018-08-02 02:19:39 --> Router Class Initialized
INFO - 2018-08-02 02:19:39 --> Output Class Initialized
INFO - 2018-08-02 02:19:39 --> Security Class Initialized
DEBUG - 2018-08-02 02:19:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 02:19:39 --> Input Class Initialized
INFO - 2018-08-02 02:19:39 --> Language Class Initialized
ERROR - 2018-08-02 02:19:39 --> 404 Page Not Found: /index
INFO - 2018-08-02 02:22:21 --> Config Class Initialized
INFO - 2018-08-02 02:22:21 --> Hooks Class Initialized
DEBUG - 2018-08-02 02:22:21 --> UTF-8 Support Enabled
INFO - 2018-08-02 02:22:21 --> Utf8 Class Initialized
INFO - 2018-08-02 02:22:21 --> URI Class Initialized
INFO - 2018-08-02 02:22:21 --> Router Class Initialized
INFO - 2018-08-02 02:22:21 --> Output Class Initialized
INFO - 2018-08-02 02:22:21 --> Security Class Initialized
DEBUG - 2018-08-02 02:22:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 02:22:21 --> Input Class Initialized
INFO - 2018-08-02 02:22:21 --> Language Class Initialized
INFO - 2018-08-02 02:22:21 --> Language Class Initialized
INFO - 2018-08-02 02:22:21 --> Config Class Initialized
INFO - 2018-08-02 02:22:21 --> Loader Class Initialized
DEBUG - 2018-08-02 02:22:21 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-02 02:22:21 --> Helper loaded: url_helper
INFO - 2018-08-02 02:22:21 --> Helper loaded: form_helper
INFO - 2018-08-02 02:22:21 --> Helper loaded: date_helper
INFO - 2018-08-02 02:22:21 --> Helper loaded: util_helper
INFO - 2018-08-02 02:22:21 --> Helper loaded: text_helper
INFO - 2018-08-02 02:22:21 --> Helper loaded: string_helper
INFO - 2018-08-02 02:22:21 --> Database Driver Class Initialized
DEBUG - 2018-08-02 02:22:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-02 02:22:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-02 02:22:21 --> Email Class Initialized
INFO - 2018-08-02 02:22:21 --> Controller Class Initialized
DEBUG - 2018-08-02 02:22:21 --> Home MX_Controller Initialized
DEBUG - 2018-08-02 02:22:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-02 02:22:21 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-02 02:22:21 --> Login MX_Controller Initialized
INFO - 2018-08-02 02:22:21 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-02 02:22:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-02 02:22:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-02 02:22:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-08-02 02:22:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-08-02 02:22:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-08-02 02:22:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-08-02 02:22:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-08-02 02:22:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-08-02 02:22:21 --> Final output sent to browser
DEBUG - 2018-08-02 02:22:21 --> Total execution time: 0.4544
INFO - 2018-08-02 02:22:23 --> Config Class Initialized
INFO - 2018-08-02 02:22:23 --> Hooks Class Initialized
DEBUG - 2018-08-02 02:22:23 --> UTF-8 Support Enabled
INFO - 2018-08-02 02:22:23 --> Utf8 Class Initialized
INFO - 2018-08-02 02:22:23 --> Config Class Initialized
INFO - 2018-08-02 02:22:23 --> Hooks Class Initialized
INFO - 2018-08-02 02:22:23 --> URI Class Initialized
DEBUG - 2018-08-02 02:22:23 --> UTF-8 Support Enabled
INFO - 2018-08-02 02:22:23 --> Utf8 Class Initialized
INFO - 2018-08-02 02:22:23 --> URI Class Initialized
INFO - 2018-08-02 02:22:23 --> Router Class Initialized
INFO - 2018-08-02 02:22:23 --> Output Class Initialized
INFO - 2018-08-02 02:22:23 --> Security Class Initialized
INFO - 2018-08-02 02:22:23 --> Router Class Initialized
DEBUG - 2018-08-02 02:22:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 02:22:23 --> Input Class Initialized
INFO - 2018-08-02 02:22:23 --> Output Class Initialized
INFO - 2018-08-02 02:22:23 --> Security Class Initialized
INFO - 2018-08-02 02:22:23 --> Language Class Initialized
DEBUG - 2018-08-02 02:22:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 02:22:23 --> Language Class Initialized
INFO - 2018-08-02 02:22:23 --> Input Class Initialized
INFO - 2018-08-02 02:22:23 --> Language Class Initialized
INFO - 2018-08-02 02:22:23 --> Config Class Initialized
ERROR - 2018-08-02 02:22:23 --> 404 Page Not Found: /index
INFO - 2018-08-02 02:22:23 --> Loader Class Initialized
INFO - 2018-08-02 02:22:23 --> Config Class Initialized
INFO - 2018-08-02 02:22:23 --> Hooks Class Initialized
DEBUG - 2018-08-02 02:22:23 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-02 02:22:23 --> Helper loaded: url_helper
DEBUG - 2018-08-02 02:22:23 --> UTF-8 Support Enabled
INFO - 2018-08-02 02:22:23 --> Utf8 Class Initialized
INFO - 2018-08-02 02:22:23 --> Helper loaded: form_helper
INFO - 2018-08-02 02:22:23 --> URI Class Initialized
INFO - 2018-08-02 02:22:23 --> Router Class Initialized
INFO - 2018-08-02 02:22:23 --> Helper loaded: date_helper
INFO - 2018-08-02 02:22:23 --> Output Class Initialized
INFO - 2018-08-02 02:22:23 --> Security Class Initialized
INFO - 2018-08-02 02:22:23 --> Helper loaded: util_helper
INFO - 2018-08-02 02:22:23 --> Helper loaded: text_helper
DEBUG - 2018-08-02 02:22:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 02:22:23 --> Helper loaded: string_helper
INFO - 2018-08-02 02:22:23 --> Input Class Initialized
INFO - 2018-08-02 02:22:23 --> Database Driver Class Initialized
INFO - 2018-08-02 02:22:23 --> Language Class Initialized
DEBUG - 2018-08-02 02:22:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-02 02:22:23 --> Session: Class initialized using 'files' driver.
ERROR - 2018-08-02 02:22:23 --> 404 Page Not Found: /index
INFO - 2018-08-02 02:22:23 --> Email Class Initialized
INFO - 2018-08-02 02:22:23 --> Config Class Initialized
INFO - 2018-08-02 02:22:23 --> Hooks Class Initialized
INFO - 2018-08-02 02:22:23 --> Controller Class Initialized
DEBUG - 2018-08-02 02:22:23 --> Home MX_Controller Initialized
DEBUG - 2018-08-02 02:22:23 --> UTF-8 Support Enabled
DEBUG - 2018-08-02 02:22:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-08-02 02:22:24 --> Utf8 Class Initialized
INFO - 2018-08-02 02:22:24 --> URI Class Initialized
DEBUG - 2018-08-02 02:22:24 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-02 02:22:24 --> Login MX_Controller Initialized
INFO - 2018-08-02 02:22:24 --> Router Class Initialized
INFO - 2018-08-02 02:22:24 --> Language file loaded: language/english/data_lang.php
INFO - 2018-08-02 02:22:24 --> Output Class Initialized
DEBUG - 2018-08-02 02:22:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-08-02 02:22:24 --> Security Class Initialized
DEBUG - 2018-08-02 02:22:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-02 02:22:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 02:22:24 --> Input Class Initialized
INFO - 2018-08-02 02:22:24 --> Language Class Initialized
ERROR - 2018-08-02 02:22:24 --> 404 Page Not Found: /index
INFO - 2018-08-02 02:22:24 --> Config Class Initialized
INFO - 2018-08-02 02:22:24 --> Hooks Class Initialized
DEBUG - 2018-08-02 02:22:24 --> UTF-8 Support Enabled
INFO - 2018-08-02 02:22:24 --> Utf8 Class Initialized
INFO - 2018-08-02 02:22:24 --> URI Class Initialized
INFO - 2018-08-02 02:22:24 --> Router Class Initialized
INFO - 2018-08-02 02:22:24 --> Output Class Initialized
INFO - 2018-08-02 02:22:24 --> Security Class Initialized
DEBUG - 2018-08-02 02:22:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 02:22:24 --> Input Class Initialized
INFO - 2018-08-02 02:22:24 --> Language Class Initialized
ERROR - 2018-08-02 02:22:24 --> 404 Page Not Found: /index
INFO - 2018-08-02 02:22:24 --> Config Class Initialized
INFO - 2018-08-02 02:22:24 --> Hooks Class Initialized
DEBUG - 2018-08-02 02:22:24 --> UTF-8 Support Enabled
INFO - 2018-08-02 02:22:24 --> Utf8 Class Initialized
INFO - 2018-08-02 02:22:24 --> URI Class Initialized
INFO - 2018-08-02 02:22:24 --> Router Class Initialized
INFO - 2018-08-02 02:22:24 --> Output Class Initialized
INFO - 2018-08-02 02:22:24 --> Security Class Initialized
DEBUG - 2018-08-02 02:22:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 02:22:24 --> Input Class Initialized
INFO - 2018-08-02 02:22:24 --> Language Class Initialized
ERROR - 2018-08-02 02:22:24 --> 404 Page Not Found: /index
INFO - 2018-08-02 02:22:24 --> Config Class Initialized
INFO - 2018-08-02 02:22:24 --> Hooks Class Initialized
DEBUG - 2018-08-02 02:22:24 --> UTF-8 Support Enabled
INFO - 2018-08-02 02:22:24 --> Utf8 Class Initialized
INFO - 2018-08-02 02:22:24 --> URI Class Initialized
INFO - 2018-08-02 02:22:24 --> Router Class Initialized
INFO - 2018-08-02 02:22:24 --> Output Class Initialized
INFO - 2018-08-02 02:22:24 --> Security Class Initialized
DEBUG - 2018-08-02 02:22:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 02:22:24 --> Input Class Initialized
INFO - 2018-08-02 02:22:24 --> Language Class Initialized
ERROR - 2018-08-02 02:22:24 --> 404 Page Not Found: /index
INFO - 2018-08-02 02:24:29 --> Config Class Initialized
INFO - 2018-08-02 02:24:29 --> Hooks Class Initialized
DEBUG - 2018-08-02 02:24:29 --> UTF-8 Support Enabled
INFO - 2018-08-02 02:24:29 --> Utf8 Class Initialized
INFO - 2018-08-02 02:24:29 --> URI Class Initialized
INFO - 2018-08-02 02:24:29 --> Router Class Initialized
INFO - 2018-08-02 02:24:29 --> Output Class Initialized
INFO - 2018-08-02 02:24:29 --> Security Class Initialized
DEBUG - 2018-08-02 02:24:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 02:24:29 --> Input Class Initialized
INFO - 2018-08-02 02:24:29 --> Language Class Initialized
INFO - 2018-08-02 02:24:29 --> Language Class Initialized
INFO - 2018-08-02 02:24:29 --> Config Class Initialized
INFO - 2018-08-02 02:24:29 --> Loader Class Initialized
DEBUG - 2018-08-02 02:24:29 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-02 02:24:29 --> Helper loaded: url_helper
INFO - 2018-08-02 02:24:29 --> Helper loaded: form_helper
INFO - 2018-08-02 02:24:29 --> Helper loaded: date_helper
INFO - 2018-08-02 02:24:29 --> Helper loaded: util_helper
INFO - 2018-08-02 02:24:29 --> Helper loaded: text_helper
INFO - 2018-08-02 02:24:29 --> Helper loaded: string_helper
INFO - 2018-08-02 02:24:29 --> Database Driver Class Initialized
DEBUG - 2018-08-02 02:24:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-02 02:24:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-02 02:24:29 --> Email Class Initialized
INFO - 2018-08-02 02:24:29 --> Controller Class Initialized
DEBUG - 2018-08-02 02:24:29 --> Home MX_Controller Initialized
DEBUG - 2018-08-02 02:24:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-02 02:24:29 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-02 02:24:29 --> Login MX_Controller Initialized
INFO - 2018-08-02 02:24:29 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-02 02:24:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-02 02:24:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-02 02:24:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-08-02 02:24:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-08-02 02:24:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-08-02 02:24:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-08-02 02:24:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-08-02 02:24:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-08-02 02:24:29 --> Final output sent to browser
DEBUG - 2018-08-02 02:24:29 --> Total execution time: 0.4988
INFO - 2018-08-02 02:24:30 --> Config Class Initialized
INFO - 2018-08-02 02:24:30 --> Hooks Class Initialized
DEBUG - 2018-08-02 02:24:30 --> UTF-8 Support Enabled
INFO - 2018-08-02 02:24:30 --> Config Class Initialized
INFO - 2018-08-02 02:24:30 --> Utf8 Class Initialized
INFO - 2018-08-02 02:24:30 --> Hooks Class Initialized
INFO - 2018-08-02 02:24:30 --> URI Class Initialized
DEBUG - 2018-08-02 02:24:30 --> UTF-8 Support Enabled
INFO - 2018-08-02 02:24:30 --> Utf8 Class Initialized
INFO - 2018-08-02 02:24:30 --> Router Class Initialized
INFO - 2018-08-02 02:24:30 --> URI Class Initialized
INFO - 2018-08-02 02:24:30 --> Output Class Initialized
INFO - 2018-08-02 02:24:30 --> Router Class Initialized
INFO - 2018-08-02 02:24:30 --> Security Class Initialized
DEBUG - 2018-08-02 02:24:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 02:24:30 --> Output Class Initialized
INFO - 2018-08-02 02:24:30 --> Input Class Initialized
INFO - 2018-08-02 02:24:30 --> Language Class Initialized
ERROR - 2018-08-02 02:24:30 --> 404 Page Not Found: /index
INFO - 2018-08-02 02:24:30 --> Security Class Initialized
INFO - 2018-08-02 02:24:30 --> Config Class Initialized
INFO - 2018-08-02 02:24:30 --> Hooks Class Initialized
DEBUG - 2018-08-02 02:24:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-08-02 02:24:30 --> UTF-8 Support Enabled
INFO - 2018-08-02 02:24:30 --> Utf8 Class Initialized
INFO - 2018-08-02 02:24:30 --> URI Class Initialized
INFO - 2018-08-02 02:24:31 --> Input Class Initialized
INFO - 2018-08-02 02:24:31 --> Router Class Initialized
INFO - 2018-08-02 02:24:31 --> Output Class Initialized
INFO - 2018-08-02 02:24:31 --> Language Class Initialized
INFO - 2018-08-02 02:24:31 --> Security Class Initialized
INFO - 2018-08-02 02:24:31 --> Language Class Initialized
DEBUG - 2018-08-02 02:24:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 02:24:31 --> Config Class Initialized
INFO - 2018-08-02 02:24:31 --> Input Class Initialized
INFO - 2018-08-02 02:24:31 --> Loader Class Initialized
INFO - 2018-08-02 02:24:31 --> Language Class Initialized
DEBUG - 2018-08-02 02:24:31 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
ERROR - 2018-08-02 02:24:31 --> 404 Page Not Found: /index
INFO - 2018-08-02 02:24:31 --> Helper loaded: url_helper
INFO - 2018-08-02 02:24:31 --> Config Class Initialized
INFO - 2018-08-02 02:24:31 --> Hooks Class Initialized
INFO - 2018-08-02 02:24:31 --> Helper loaded: form_helper
DEBUG - 2018-08-02 02:24:31 --> UTF-8 Support Enabled
INFO - 2018-08-02 02:24:31 --> Helper loaded: date_helper
INFO - 2018-08-02 02:24:31 --> Utf8 Class Initialized
INFO - 2018-08-02 02:24:31 --> URI Class Initialized
INFO - 2018-08-02 02:24:31 --> Helper loaded: util_helper
INFO - 2018-08-02 02:24:31 --> Router Class Initialized
INFO - 2018-08-02 02:24:31 --> Output Class Initialized
INFO - 2018-08-02 02:24:31 --> Helper loaded: text_helper
INFO - 2018-08-02 02:24:31 --> Security Class Initialized
DEBUG - 2018-08-02 02:24:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 02:24:31 --> Helper loaded: string_helper
INFO - 2018-08-02 02:24:31 --> Input Class Initialized
INFO - 2018-08-02 02:24:31 --> Language Class Initialized
INFO - 2018-08-02 02:24:31 --> Database Driver Class Initialized
ERROR - 2018-08-02 02:24:31 --> 404 Page Not Found: /index
DEBUG - 2018-08-02 02:24:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-02 02:24:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-02 02:24:31 --> Email Class Initialized
INFO - 2018-08-02 02:24:31 --> Controller Class Initialized
INFO - 2018-08-02 02:24:31 --> Config Class Initialized
DEBUG - 2018-08-02 02:24:31 --> Home MX_Controller Initialized
INFO - 2018-08-02 02:24:31 --> Hooks Class Initialized
DEBUG - 2018-08-02 02:24:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-02 02:24:31 --> UTF-8 Support Enabled
INFO - 2018-08-02 02:24:31 --> Utf8 Class Initialized
DEBUG - 2018-08-02 02:24:31 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-02 02:24:31 --> Login MX_Controller Initialized
INFO - 2018-08-02 02:24:31 --> URI Class Initialized
INFO - 2018-08-02 02:24:31 --> Language file loaded: language/english/data_lang.php
INFO - 2018-08-02 02:24:31 --> Router Class Initialized
DEBUG - 2018-08-02 02:24:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-02 02:24:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-02 02:24:31 --> Output Class Initialized
INFO - 2018-08-02 02:24:31 --> Security Class Initialized
DEBUG - 2018-08-02 02:24:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 02:24:31 --> Input Class Initialized
INFO - 2018-08-02 02:24:31 --> Language Class Initialized
ERROR - 2018-08-02 02:24:31 --> 404 Page Not Found: /index
INFO - 2018-08-02 02:24:31 --> Config Class Initialized
INFO - 2018-08-02 02:24:31 --> Hooks Class Initialized
DEBUG - 2018-08-02 02:24:31 --> UTF-8 Support Enabled
INFO - 2018-08-02 02:24:31 --> Utf8 Class Initialized
INFO - 2018-08-02 02:24:31 --> URI Class Initialized
INFO - 2018-08-02 02:24:31 --> Router Class Initialized
INFO - 2018-08-02 02:24:31 --> Output Class Initialized
INFO - 2018-08-02 02:24:31 --> Security Class Initialized
DEBUG - 2018-08-02 02:24:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 02:24:31 --> Input Class Initialized
INFO - 2018-08-02 02:24:31 --> Language Class Initialized
ERROR - 2018-08-02 02:24:31 --> 404 Page Not Found: /index
INFO - 2018-08-02 02:24:32 --> Config Class Initialized
INFO - 2018-08-02 02:24:32 --> Hooks Class Initialized
DEBUG - 2018-08-02 02:24:32 --> UTF-8 Support Enabled
INFO - 2018-08-02 02:24:32 --> Utf8 Class Initialized
INFO - 2018-08-02 02:24:32 --> URI Class Initialized
INFO - 2018-08-02 02:24:32 --> Router Class Initialized
INFO - 2018-08-02 02:24:32 --> Output Class Initialized
INFO - 2018-08-02 02:24:32 --> Security Class Initialized
DEBUG - 2018-08-02 02:24:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 02:24:32 --> Input Class Initialized
INFO - 2018-08-02 02:24:32 --> Language Class Initialized
ERROR - 2018-08-02 02:24:32 --> 404 Page Not Found: /index
INFO - 2018-08-02 02:26:10 --> Config Class Initialized
INFO - 2018-08-02 02:26:10 --> Hooks Class Initialized
DEBUG - 2018-08-02 02:26:10 --> UTF-8 Support Enabled
INFO - 2018-08-02 02:26:10 --> Utf8 Class Initialized
INFO - 2018-08-02 02:26:10 --> URI Class Initialized
INFO - 2018-08-02 02:26:10 --> Router Class Initialized
INFO - 2018-08-02 02:26:10 --> Output Class Initialized
INFO - 2018-08-02 02:26:10 --> Security Class Initialized
DEBUG - 2018-08-02 02:26:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 02:26:10 --> Input Class Initialized
INFO - 2018-08-02 02:26:10 --> Language Class Initialized
INFO - 2018-08-02 02:26:10 --> Language Class Initialized
INFO - 2018-08-02 02:26:10 --> Config Class Initialized
INFO - 2018-08-02 02:26:10 --> Loader Class Initialized
DEBUG - 2018-08-02 02:26:10 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-02 02:26:10 --> Helper loaded: url_helper
INFO - 2018-08-02 02:26:10 --> Helper loaded: form_helper
INFO - 2018-08-02 02:26:10 --> Helper loaded: date_helper
INFO - 2018-08-02 02:26:10 --> Helper loaded: util_helper
INFO - 2018-08-02 02:26:10 --> Helper loaded: text_helper
INFO - 2018-08-02 02:26:10 --> Helper loaded: string_helper
INFO - 2018-08-02 02:26:10 --> Database Driver Class Initialized
DEBUG - 2018-08-02 02:26:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-02 02:26:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-02 02:26:10 --> Email Class Initialized
INFO - 2018-08-02 02:26:10 --> Controller Class Initialized
DEBUG - 2018-08-02 02:26:10 --> Home MX_Controller Initialized
DEBUG - 2018-08-02 02:26:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-02 02:26:10 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-02 02:26:10 --> Login MX_Controller Initialized
INFO - 2018-08-02 02:26:10 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-02 02:26:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-02 02:26:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-02 02:26:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-08-02 02:26:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-08-02 02:26:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-08-02 02:26:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-08-02 02:26:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-08-02 02:26:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-08-02 02:26:10 --> Final output sent to browser
DEBUG - 2018-08-02 02:26:10 --> Total execution time: 0.4736
INFO - 2018-08-02 02:26:11 --> Config Class Initialized
INFO - 2018-08-02 02:26:11 --> Hooks Class Initialized
DEBUG - 2018-08-02 02:26:11 --> UTF-8 Support Enabled
INFO - 2018-08-02 02:26:11 --> Utf8 Class Initialized
INFO - 2018-08-02 02:26:11 --> Config Class Initialized
INFO - 2018-08-02 02:26:11 --> Hooks Class Initialized
INFO - 2018-08-02 02:26:11 --> URI Class Initialized
DEBUG - 2018-08-02 02:26:11 --> UTF-8 Support Enabled
INFO - 2018-08-02 02:26:11 --> Utf8 Class Initialized
INFO - 2018-08-02 02:26:11 --> URI Class Initialized
INFO - 2018-08-02 02:26:11 --> Router Class Initialized
INFO - 2018-08-02 02:26:11 --> Output Class Initialized
INFO - 2018-08-02 02:26:11 --> Security Class Initialized
DEBUG - 2018-08-02 02:26:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 02:26:11 --> Input Class Initialized
INFO - 2018-08-02 02:26:11 --> Language Class Initialized
INFO - 2018-08-02 02:26:11 --> Language Class Initialized
INFO - 2018-08-02 02:26:11 --> Config Class Initialized
INFO - 2018-08-02 02:26:11 --> Router Class Initialized
INFO - 2018-08-02 02:26:11 --> Output Class Initialized
INFO - 2018-08-02 02:26:11 --> Loader Class Initialized
INFO - 2018-08-02 02:26:11 --> Security Class Initialized
DEBUG - 2018-08-02 02:26:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 02:26:12 --> Input Class Initialized
INFO - 2018-08-02 02:26:12 --> Language Class Initialized
ERROR - 2018-08-02 02:26:12 --> 404 Page Not Found: /index
DEBUG - 2018-08-02 02:26:12 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-02 02:26:12 --> Helper loaded: url_helper
INFO - 2018-08-02 02:26:12 --> Helper loaded: form_helper
INFO - 2018-08-02 02:26:12 --> Helper loaded: date_helper
INFO - 2018-08-02 02:26:12 --> Helper loaded: util_helper
INFO - 2018-08-02 02:26:12 --> Helper loaded: text_helper
INFO - 2018-08-02 02:26:12 --> Helper loaded: string_helper
INFO - 2018-08-02 02:26:12 --> Database Driver Class Initialized
INFO - 2018-08-02 02:26:12 --> Config Class Initialized
INFO - 2018-08-02 02:26:12 --> Hooks Class Initialized
DEBUG - 2018-08-02 02:26:12 --> UTF-8 Support Enabled
DEBUG - 2018-08-02 02:26:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-02 02:26:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-02 02:26:12 --> Utf8 Class Initialized
INFO - 2018-08-02 02:26:12 --> Email Class Initialized
INFO - 2018-08-02 02:26:12 --> Controller Class Initialized
DEBUG - 2018-08-02 02:26:12 --> Home MX_Controller Initialized
DEBUG - 2018-08-02 02:26:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-08-02 02:26:12 --> URI Class Initialized
DEBUG - 2018-08-02 02:26:12 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-02 02:26:12 --> Login MX_Controller Initialized
INFO - 2018-08-02 02:26:12 --> Router Class Initialized
INFO - 2018-08-02 02:26:12 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-02 02:26:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-02 02:26:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-02 02:26:12 --> Output Class Initialized
INFO - 2018-08-02 02:26:12 --> Security Class Initialized
DEBUG - 2018-08-02 02:26:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 02:26:12 --> Input Class Initialized
INFO - 2018-08-02 02:26:12 --> Language Class Initialized
ERROR - 2018-08-02 02:26:12 --> 404 Page Not Found: /index
INFO - 2018-08-02 02:26:12 --> Config Class Initialized
INFO - 2018-08-02 02:26:12 --> Hooks Class Initialized
DEBUG - 2018-08-02 02:26:12 --> UTF-8 Support Enabled
INFO - 2018-08-02 02:26:12 --> Utf8 Class Initialized
INFO - 2018-08-02 02:26:13 --> URI Class Initialized
INFO - 2018-08-02 02:26:13 --> Router Class Initialized
INFO - 2018-08-02 02:26:13 --> Output Class Initialized
INFO - 2018-08-02 02:26:13 --> Security Class Initialized
DEBUG - 2018-08-02 02:26:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 02:26:13 --> Input Class Initialized
INFO - 2018-08-02 02:26:13 --> Language Class Initialized
ERROR - 2018-08-02 02:26:13 --> 404 Page Not Found: /index
INFO - 2018-08-02 02:30:16 --> Config Class Initialized
INFO - 2018-08-02 02:30:16 --> Hooks Class Initialized
DEBUG - 2018-08-02 02:30:16 --> UTF-8 Support Enabled
INFO - 2018-08-02 02:30:16 --> Utf8 Class Initialized
INFO - 2018-08-02 02:30:16 --> URI Class Initialized
INFO - 2018-08-02 02:30:16 --> Router Class Initialized
INFO - 2018-08-02 02:30:16 --> Output Class Initialized
INFO - 2018-08-02 02:30:16 --> Security Class Initialized
DEBUG - 2018-08-02 02:30:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 02:30:16 --> Input Class Initialized
INFO - 2018-08-02 02:30:16 --> Language Class Initialized
INFO - 2018-08-02 02:30:16 --> Language Class Initialized
INFO - 2018-08-02 02:30:16 --> Config Class Initialized
INFO - 2018-08-02 02:30:16 --> Loader Class Initialized
DEBUG - 2018-08-02 02:30:16 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-02 02:30:16 --> Helper loaded: url_helper
INFO - 2018-08-02 02:30:16 --> Helper loaded: form_helper
INFO - 2018-08-02 02:30:17 --> Helper loaded: date_helper
INFO - 2018-08-02 02:30:17 --> Helper loaded: util_helper
INFO - 2018-08-02 02:30:17 --> Helper loaded: text_helper
INFO - 2018-08-02 02:30:17 --> Helper loaded: string_helper
INFO - 2018-08-02 02:30:17 --> Database Driver Class Initialized
DEBUG - 2018-08-02 02:30:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-02 02:30:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-02 02:30:17 --> Email Class Initialized
INFO - 2018-08-02 02:30:17 --> Controller Class Initialized
DEBUG - 2018-08-02 02:30:17 --> Home MX_Controller Initialized
DEBUG - 2018-08-02 02:30:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-02 02:30:17 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-02 02:30:17 --> Login MX_Controller Initialized
INFO - 2018-08-02 02:30:17 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-02 02:30:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-02 02:30:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-02 02:30:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-08-02 02:30:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-08-02 02:30:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-08-02 02:30:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-08-02 02:30:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-08-02 02:30:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-08-02 02:30:17 --> Final output sent to browser
DEBUG - 2018-08-02 02:30:17 --> Total execution time: 0.5092
INFO - 2018-08-02 02:30:18 --> Config Class Initialized
INFO - 2018-08-02 02:30:18 --> Hooks Class Initialized
DEBUG - 2018-08-02 02:30:18 --> UTF-8 Support Enabled
INFO - 2018-08-02 02:30:18 --> Utf8 Class Initialized
INFO - 2018-08-02 02:30:18 --> URI Class Initialized
INFO - 2018-08-02 02:30:18 --> Router Class Initialized
INFO - 2018-08-02 02:30:18 --> Output Class Initialized
INFO - 2018-08-02 02:30:18 --> Config Class Initialized
INFO - 2018-08-02 02:30:18 --> Security Class Initialized
INFO - 2018-08-02 02:30:18 --> Hooks Class Initialized
DEBUG - 2018-08-02 02:30:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 02:30:18 --> Input Class Initialized
DEBUG - 2018-08-02 02:30:18 --> UTF-8 Support Enabled
INFO - 2018-08-02 02:30:18 --> Utf8 Class Initialized
INFO - 2018-08-02 02:30:18 --> Language Class Initialized
INFO - 2018-08-02 02:30:19 --> URI Class Initialized
ERROR - 2018-08-02 02:30:19 --> 404 Page Not Found: /index
INFO - 2018-08-02 02:30:19 --> Router Class Initialized
INFO - 2018-08-02 02:30:19 --> Output Class Initialized
INFO - 2018-08-02 02:30:19 --> Security Class Initialized
DEBUG - 2018-08-02 02:30:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 02:30:19 --> Config Class Initialized
INFO - 2018-08-02 02:30:19 --> Input Class Initialized
INFO - 2018-08-02 02:30:19 --> Hooks Class Initialized
INFO - 2018-08-02 02:30:19 --> Language Class Initialized
DEBUG - 2018-08-02 02:30:19 --> UTF-8 Support Enabled
INFO - 2018-08-02 02:30:19 --> Language Class Initialized
INFO - 2018-08-02 02:30:19 --> Utf8 Class Initialized
INFO - 2018-08-02 02:30:19 --> Config Class Initialized
INFO - 2018-08-02 02:30:19 --> URI Class Initialized
INFO - 2018-08-02 02:30:19 --> Loader Class Initialized
DEBUG - 2018-08-02 02:30:19 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-02 02:30:19 --> Router Class Initialized
INFO - 2018-08-02 02:30:19 --> Helper loaded: url_helper
INFO - 2018-08-02 02:30:19 --> Output Class Initialized
INFO - 2018-08-02 02:30:19 --> Helper loaded: form_helper
INFO - 2018-08-02 02:30:19 --> Security Class Initialized
INFO - 2018-08-02 02:30:19 --> Helper loaded: date_helper
DEBUG - 2018-08-02 02:30:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 02:30:19 --> Helper loaded: util_helper
INFO - 2018-08-02 02:30:19 --> Input Class Initialized
INFO - 2018-08-02 02:30:19 --> Helper loaded: text_helper
INFO - 2018-08-02 02:30:19 --> Language Class Initialized
INFO - 2018-08-02 02:30:19 --> Helper loaded: string_helper
ERROR - 2018-08-02 02:30:19 --> 404 Page Not Found: /index
INFO - 2018-08-02 02:30:19 --> Database Driver Class Initialized
DEBUG - 2018-08-02 02:30:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-02 02:30:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-02 02:30:19 --> Config Class Initialized
INFO - 2018-08-02 02:30:19 --> Hooks Class Initialized
INFO - 2018-08-02 02:30:19 --> Email Class Initialized
INFO - 2018-08-02 02:30:19 --> Controller Class Initialized
DEBUG - 2018-08-02 02:30:19 --> UTF-8 Support Enabled
INFO - 2018-08-02 02:30:19 --> Utf8 Class Initialized
DEBUG - 2018-08-02 02:30:19 --> Home MX_Controller Initialized
INFO - 2018-08-02 02:30:19 --> URI Class Initialized
DEBUG - 2018-08-02 02:30:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-08-02 02:30:19 --> Router Class Initialized
DEBUG - 2018-08-02 02:30:19 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-02 02:30:19 --> Login MX_Controller Initialized
INFO - 2018-08-02 02:30:19 --> Output Class Initialized
INFO - 2018-08-02 02:30:19 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-02 02:30:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-08-02 02:30:19 --> Security Class Initialized
DEBUG - 2018-08-02 02:30:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-02 02:30:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 02:30:19 --> Input Class Initialized
INFO - 2018-08-02 02:30:19 --> Language Class Initialized
ERROR - 2018-08-02 02:30:19 --> 404 Page Not Found: /index
INFO - 2018-08-02 02:30:19 --> Config Class Initialized
INFO - 2018-08-02 02:30:19 --> Hooks Class Initialized
DEBUG - 2018-08-02 02:30:19 --> UTF-8 Support Enabled
INFO - 2018-08-02 02:30:19 --> Utf8 Class Initialized
INFO - 2018-08-02 02:30:19 --> URI Class Initialized
INFO - 2018-08-02 02:30:19 --> Router Class Initialized
INFO - 2018-08-02 02:30:19 --> Output Class Initialized
INFO - 2018-08-02 02:30:19 --> Security Class Initialized
DEBUG - 2018-08-02 02:30:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 02:30:19 --> Input Class Initialized
INFO - 2018-08-02 02:30:19 --> Language Class Initialized
ERROR - 2018-08-02 02:30:19 --> 404 Page Not Found: /index
INFO - 2018-08-02 02:30:19 --> Config Class Initialized
INFO - 2018-08-02 02:30:19 --> Hooks Class Initialized
DEBUG - 2018-08-02 02:30:19 --> UTF-8 Support Enabled
INFO - 2018-08-02 02:30:19 --> Utf8 Class Initialized
INFO - 2018-08-02 02:30:19 --> URI Class Initialized
INFO - 2018-08-02 02:30:19 --> Router Class Initialized
INFO - 2018-08-02 02:30:19 --> Output Class Initialized
INFO - 2018-08-02 02:30:19 --> Security Class Initialized
DEBUG - 2018-08-02 02:30:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 02:30:19 --> Input Class Initialized
INFO - 2018-08-02 02:30:19 --> Language Class Initialized
ERROR - 2018-08-02 02:30:19 --> 404 Page Not Found: /index
INFO - 2018-08-02 02:30:19 --> Config Class Initialized
INFO - 2018-08-02 02:30:19 --> Hooks Class Initialized
DEBUG - 2018-08-02 02:30:19 --> UTF-8 Support Enabled
INFO - 2018-08-02 02:30:19 --> Utf8 Class Initialized
INFO - 2018-08-02 02:30:20 --> URI Class Initialized
INFO - 2018-08-02 02:30:20 --> Router Class Initialized
INFO - 2018-08-02 02:30:20 --> Output Class Initialized
INFO - 2018-08-02 02:30:20 --> Security Class Initialized
DEBUG - 2018-08-02 02:30:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 02:30:20 --> Input Class Initialized
INFO - 2018-08-02 02:30:20 --> Language Class Initialized
ERROR - 2018-08-02 02:30:20 --> 404 Page Not Found: /index
INFO - 2018-08-02 03:27:58 --> Config Class Initialized
INFO - 2018-08-02 03:27:58 --> Hooks Class Initialized
DEBUG - 2018-08-02 03:27:58 --> UTF-8 Support Enabled
INFO - 2018-08-02 03:27:58 --> Utf8 Class Initialized
INFO - 2018-08-02 03:27:58 --> URI Class Initialized
INFO - 2018-08-02 03:27:58 --> Router Class Initialized
INFO - 2018-08-02 03:27:58 --> Output Class Initialized
INFO - 2018-08-02 03:27:58 --> Security Class Initialized
DEBUG - 2018-08-02 03:27:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 03:27:58 --> Input Class Initialized
INFO - 2018-08-02 03:27:58 --> Language Class Initialized
INFO - 2018-08-02 03:27:58 --> Language Class Initialized
INFO - 2018-08-02 03:27:58 --> Config Class Initialized
INFO - 2018-08-02 03:27:58 --> Loader Class Initialized
DEBUG - 2018-08-02 03:27:58 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-02 03:27:58 --> Helper loaded: url_helper
INFO - 2018-08-02 03:27:58 --> Helper loaded: form_helper
INFO - 2018-08-02 03:27:58 --> Helper loaded: date_helper
INFO - 2018-08-02 03:27:58 --> Helper loaded: util_helper
INFO - 2018-08-02 03:27:58 --> Helper loaded: text_helper
INFO - 2018-08-02 03:27:58 --> Helper loaded: string_helper
INFO - 2018-08-02 03:27:58 --> Database Driver Class Initialized
DEBUG - 2018-08-02 03:27:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-02 03:27:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-02 03:27:58 --> Email Class Initialized
INFO - 2018-08-02 03:27:58 --> Controller Class Initialized
DEBUG - 2018-08-02 03:27:58 --> Home MX_Controller Initialized
DEBUG - 2018-08-02 03:27:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-02 03:27:58 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-02 03:27:58 --> Login MX_Controller Initialized
INFO - 2018-08-02 03:27:58 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-02 03:27:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-02 03:27:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-02 03:27:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-08-02 03:27:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-08-02 03:27:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-08-02 03:27:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-08-02 03:27:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-08-02 03:27:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-08-02 03:27:59 --> Final output sent to browser
DEBUG - 2018-08-02 03:27:59 --> Total execution time: 0.6918
INFO - 2018-08-02 03:28:00 --> Config Class Initialized
INFO - 2018-08-02 03:28:00 --> Hooks Class Initialized
DEBUG - 2018-08-02 03:28:00 --> UTF-8 Support Enabled
INFO - 2018-08-02 03:28:01 --> Utf8 Class Initialized
INFO - 2018-08-02 03:28:01 --> Config Class Initialized
INFO - 2018-08-02 03:28:01 --> Hooks Class Initialized
INFO - 2018-08-02 03:28:01 --> URI Class Initialized
DEBUG - 2018-08-02 03:28:01 --> UTF-8 Support Enabled
INFO - 2018-08-02 03:28:01 --> Router Class Initialized
INFO - 2018-08-02 03:28:01 --> Utf8 Class Initialized
INFO - 2018-08-02 03:28:01 --> Output Class Initialized
INFO - 2018-08-02 03:28:01 --> URI Class Initialized
INFO - 2018-08-02 03:28:01 --> Security Class Initialized
DEBUG - 2018-08-02 03:28:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 03:28:01 --> Router Class Initialized
INFO - 2018-08-02 03:28:01 --> Input Class Initialized
INFO - 2018-08-02 03:28:01 --> Output Class Initialized
INFO - 2018-08-02 03:28:01 --> Security Class Initialized
INFO - 2018-08-02 03:28:01 --> Language Class Initialized
ERROR - 2018-08-02 03:28:01 --> 404 Page Not Found: /index
DEBUG - 2018-08-02 03:28:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 03:28:01 --> Input Class Initialized
INFO - 2018-08-02 03:28:01 --> Config Class Initialized
INFO - 2018-08-02 03:28:01 --> Hooks Class Initialized
INFO - 2018-08-02 03:28:01 --> Language Class Initialized
DEBUG - 2018-08-02 03:28:01 --> UTF-8 Support Enabled
INFO - 2018-08-02 03:28:01 --> Utf8 Class Initialized
INFO - 2018-08-02 03:28:01 --> URI Class Initialized
INFO - 2018-08-02 03:28:01 --> Router Class Initialized
INFO - 2018-08-02 03:28:01 --> Output Class Initialized
INFO - 2018-08-02 03:28:01 --> Security Class Initialized
DEBUG - 2018-08-02 03:28:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 03:28:01 --> Language Class Initialized
INFO - 2018-08-02 03:28:01 --> Input Class Initialized
INFO - 2018-08-02 03:28:01 --> Config Class Initialized
INFO - 2018-08-02 03:28:01 --> Language Class Initialized
ERROR - 2018-08-02 03:28:01 --> 404 Page Not Found: /index
INFO - 2018-08-02 03:28:01 --> Loader Class Initialized
DEBUG - 2018-08-02 03:28:01 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-02 03:28:01 --> Config Class Initialized
INFO - 2018-08-02 03:28:01 --> Hooks Class Initialized
INFO - 2018-08-02 03:28:01 --> Helper loaded: url_helper
DEBUG - 2018-08-02 03:28:01 --> UTF-8 Support Enabled
INFO - 2018-08-02 03:28:01 --> Utf8 Class Initialized
INFO - 2018-08-02 03:28:01 --> URI Class Initialized
INFO - 2018-08-02 03:28:01 --> Helper loaded: form_helper
INFO - 2018-08-02 03:28:01 --> Router Class Initialized
INFO - 2018-08-02 03:28:01 --> Helper loaded: date_helper
INFO - 2018-08-02 03:28:01 --> Output Class Initialized
INFO - 2018-08-02 03:28:01 --> Helper loaded: util_helper
INFO - 2018-08-02 03:28:01 --> Security Class Initialized
INFO - 2018-08-02 03:28:01 --> Helper loaded: text_helper
INFO - 2018-08-02 03:28:01 --> Helper loaded: string_helper
DEBUG - 2018-08-02 03:28:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 03:28:01 --> Input Class Initialized
INFO - 2018-08-02 03:28:01 --> Database Driver Class Initialized
INFO - 2018-08-02 03:28:01 --> Language Class Initialized
DEBUG - 2018-08-02 03:28:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-02 03:28:01 --> Session: Class initialized using 'files' driver.
ERROR - 2018-08-02 03:28:01 --> 404 Page Not Found: /index
INFO - 2018-08-02 03:28:01 --> Email Class Initialized
INFO - 2018-08-02 03:28:01 --> Controller Class Initialized
INFO - 2018-08-02 03:28:01 --> Config Class Initialized
DEBUG - 2018-08-02 03:28:01 --> Home MX_Controller Initialized
INFO - 2018-08-02 03:28:02 --> Hooks Class Initialized
DEBUG - 2018-08-02 03:28:02 --> UTF-8 Support Enabled
INFO - 2018-08-02 03:28:02 --> Utf8 Class Initialized
DEBUG - 2018-08-02 03:28:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-08-02 03:28:02 --> URI Class Initialized
INFO - 2018-08-02 03:28:02 --> Router Class Initialized
DEBUG - 2018-08-02 03:28:02 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-02 03:28:02 --> Login MX_Controller Initialized
INFO - 2018-08-02 03:28:02 --> Output Class Initialized
INFO - 2018-08-02 03:28:02 --> Security Class Initialized
INFO - 2018-08-02 03:28:02 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-02 03:28:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 03:28:02 --> Input Class Initialized
INFO - 2018-08-02 03:28:02 --> Language Class Initialized
ERROR - 2018-08-02 03:28:02 --> 404 Page Not Found: /index
DEBUG - 2018-08-02 03:28:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-08-02 03:28:02 --> Config Class Initialized
INFO - 2018-08-02 03:28:02 --> Hooks Class Initialized
DEBUG - 2018-08-02 03:28:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-02 03:28:02 --> UTF-8 Support Enabled
INFO - 2018-08-02 03:28:02 --> Utf8 Class Initialized
INFO - 2018-08-02 03:28:02 --> URI Class Initialized
INFO - 2018-08-02 03:28:02 --> Router Class Initialized
INFO - 2018-08-02 03:28:02 --> Output Class Initialized
INFO - 2018-08-02 03:28:02 --> Security Class Initialized
DEBUG - 2018-08-02 03:28:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 03:28:02 --> Input Class Initialized
INFO - 2018-08-02 03:28:02 --> Language Class Initialized
ERROR - 2018-08-02 03:28:02 --> 404 Page Not Found: /index
INFO - 2018-08-02 03:28:02 --> Config Class Initialized
INFO - 2018-08-02 03:28:02 --> Hooks Class Initialized
DEBUG - 2018-08-02 03:28:02 --> UTF-8 Support Enabled
INFO - 2018-08-02 03:28:02 --> Utf8 Class Initialized
INFO - 2018-08-02 03:28:02 --> URI Class Initialized
INFO - 2018-08-02 03:28:02 --> Router Class Initialized
INFO - 2018-08-02 03:28:02 --> Output Class Initialized
INFO - 2018-08-02 03:28:02 --> Security Class Initialized
DEBUG - 2018-08-02 03:28:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 03:28:02 --> Input Class Initialized
INFO - 2018-08-02 03:28:02 --> Language Class Initialized
ERROR - 2018-08-02 03:28:02 --> 404 Page Not Found: /index
INFO - 2018-08-02 03:28:32 --> Config Class Initialized
INFO - 2018-08-02 03:28:32 --> Hooks Class Initialized
DEBUG - 2018-08-02 03:28:32 --> UTF-8 Support Enabled
INFO - 2018-08-02 03:28:32 --> Utf8 Class Initialized
INFO - 2018-08-02 03:28:32 --> URI Class Initialized
INFO - 2018-08-02 03:28:32 --> Router Class Initialized
INFO - 2018-08-02 03:28:32 --> Output Class Initialized
INFO - 2018-08-02 03:28:32 --> Security Class Initialized
DEBUG - 2018-08-02 03:28:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 03:28:32 --> Input Class Initialized
INFO - 2018-08-02 03:28:32 --> Language Class Initialized
INFO - 2018-08-02 03:28:32 --> Language Class Initialized
INFO - 2018-08-02 03:28:32 --> Config Class Initialized
INFO - 2018-08-02 03:28:32 --> Loader Class Initialized
DEBUG - 2018-08-02 03:28:32 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-02 03:28:32 --> Helper loaded: url_helper
INFO - 2018-08-02 03:28:32 --> Helper loaded: form_helper
INFO - 2018-08-02 03:28:32 --> Helper loaded: date_helper
INFO - 2018-08-02 03:28:32 --> Helper loaded: util_helper
INFO - 2018-08-02 03:28:32 --> Helper loaded: text_helper
INFO - 2018-08-02 03:28:32 --> Helper loaded: string_helper
INFO - 2018-08-02 03:28:32 --> Database Driver Class Initialized
DEBUG - 2018-08-02 03:28:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-02 03:28:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-02 03:28:32 --> Email Class Initialized
INFO - 2018-08-02 03:28:32 --> Controller Class Initialized
DEBUG - 2018-08-02 03:28:32 --> Home MX_Controller Initialized
DEBUG - 2018-08-02 03:28:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-02 03:28:32 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-02 03:28:32 --> Login MX_Controller Initialized
INFO - 2018-08-02 03:28:32 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-02 03:28:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-02 03:28:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-02 03:28:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-08-02 03:28:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-08-02 03:28:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-08-02 03:28:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-08-02 03:28:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-08-02 03:28:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-08-02 03:28:32 --> Final output sent to browser
DEBUG - 2018-08-02 03:28:32 --> Total execution time: 0.5145
INFO - 2018-08-02 03:28:33 --> Config Class Initialized
INFO - 2018-08-02 03:28:33 --> Hooks Class Initialized
INFO - 2018-08-02 03:28:33 --> Config Class Initialized
INFO - 2018-08-02 03:28:33 --> Hooks Class Initialized
DEBUG - 2018-08-02 03:28:33 --> UTF-8 Support Enabled
DEBUG - 2018-08-02 03:28:33 --> UTF-8 Support Enabled
INFO - 2018-08-02 03:28:33 --> Utf8 Class Initialized
INFO - 2018-08-02 03:28:33 --> Utf8 Class Initialized
INFO - 2018-08-02 03:28:33 --> URI Class Initialized
INFO - 2018-08-02 03:28:33 --> URI Class Initialized
INFO - 2018-08-02 03:28:33 --> Router Class Initialized
INFO - 2018-08-02 03:28:33 --> Router Class Initialized
INFO - 2018-08-02 03:28:33 --> Output Class Initialized
INFO - 2018-08-02 03:28:33 --> Output Class Initialized
INFO - 2018-08-02 03:28:33 --> Security Class Initialized
INFO - 2018-08-02 03:28:33 --> Security Class Initialized
DEBUG - 2018-08-02 03:28:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-08-02 03:28:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 03:28:33 --> Input Class Initialized
INFO - 2018-08-02 03:28:33 --> Input Class Initialized
INFO - 2018-08-02 03:28:33 --> Language Class Initialized
INFO - 2018-08-02 03:28:34 --> Language Class Initialized
INFO - 2018-08-02 03:28:34 --> Config Class Initialized
INFO - 2018-08-02 03:28:34 --> Language Class Initialized
INFO - 2018-08-02 03:28:34 --> Loader Class Initialized
ERROR - 2018-08-02 03:28:34 --> 404 Page Not Found: /index
DEBUG - 2018-08-02 03:28:34 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-02 03:28:34 --> Config Class Initialized
INFO - 2018-08-02 03:28:34 --> Hooks Class Initialized
INFO - 2018-08-02 03:28:34 --> Helper loaded: url_helper
DEBUG - 2018-08-02 03:28:34 --> UTF-8 Support Enabled
INFO - 2018-08-02 03:28:34 --> Helper loaded: form_helper
INFO - 2018-08-02 03:28:34 --> Utf8 Class Initialized
INFO - 2018-08-02 03:28:34 --> Helper loaded: date_helper
INFO - 2018-08-02 03:28:34 --> Helper loaded: util_helper
INFO - 2018-08-02 03:28:34 --> URI Class Initialized
INFO - 2018-08-02 03:28:34 --> Helper loaded: text_helper
INFO - 2018-08-02 03:28:34 --> Helper loaded: string_helper
INFO - 2018-08-02 03:28:34 --> Router Class Initialized
INFO - 2018-08-02 03:28:34 --> Database Driver Class Initialized
INFO - 2018-08-02 03:28:34 --> Output Class Initialized
DEBUG - 2018-08-02 03:28:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-02 03:28:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-02 03:28:34 --> Security Class Initialized
INFO - 2018-08-02 03:28:34 --> Email Class Initialized
INFO - 2018-08-02 03:28:34 --> Controller Class Initialized
DEBUG - 2018-08-02 03:28:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-08-02 03:28:34 --> Home MX_Controller Initialized
INFO - 2018-08-02 03:28:34 --> Input Class Initialized
INFO - 2018-08-02 03:28:34 --> Language Class Initialized
DEBUG - 2018-08-02 03:28:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
ERROR - 2018-08-02 03:28:34 --> 404 Page Not Found: /index
DEBUG - 2018-08-02 03:28:34 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-02 03:28:34 --> Login MX_Controller Initialized
INFO - 2018-08-02 03:28:34 --> Config Class Initialized
INFO - 2018-08-02 03:28:34 --> Hooks Class Initialized
INFO - 2018-08-02 03:28:34 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-02 03:28:34 --> UTF-8 Support Enabled
INFO - 2018-08-02 03:28:34 --> Utf8 Class Initialized
INFO - 2018-08-02 03:28:34 --> URI Class Initialized
DEBUG - 2018-08-02 03:28:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-02 03:28:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-02 03:28:34 --> Router Class Initialized
INFO - 2018-08-02 03:28:34 --> Output Class Initialized
INFO - 2018-08-02 03:28:34 --> Security Class Initialized
DEBUG - 2018-08-02 03:28:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 03:28:34 --> Input Class Initialized
INFO - 2018-08-02 03:28:34 --> Language Class Initialized
ERROR - 2018-08-02 03:28:34 --> 404 Page Not Found: /index
INFO - 2018-08-02 03:28:34 --> Config Class Initialized
INFO - 2018-08-02 03:28:34 --> Hooks Class Initialized
DEBUG - 2018-08-02 03:28:34 --> UTF-8 Support Enabled
INFO - 2018-08-02 03:28:34 --> Utf8 Class Initialized
INFO - 2018-08-02 03:28:34 --> URI Class Initialized
INFO - 2018-08-02 03:28:35 --> Router Class Initialized
INFO - 2018-08-02 03:28:35 --> Output Class Initialized
INFO - 2018-08-02 03:28:35 --> Security Class Initialized
DEBUG - 2018-08-02 03:28:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 03:28:35 --> Input Class Initialized
INFO - 2018-08-02 03:28:35 --> Language Class Initialized
ERROR - 2018-08-02 03:28:35 --> 404 Page Not Found: /index
INFO - 2018-08-02 03:28:35 --> Config Class Initialized
INFO - 2018-08-02 03:28:35 --> Hooks Class Initialized
DEBUG - 2018-08-02 03:28:35 --> UTF-8 Support Enabled
INFO - 2018-08-02 03:28:35 --> Utf8 Class Initialized
INFO - 2018-08-02 03:28:35 --> URI Class Initialized
INFO - 2018-08-02 03:28:35 --> Router Class Initialized
INFO - 2018-08-02 03:28:35 --> Output Class Initialized
INFO - 2018-08-02 03:28:35 --> Security Class Initialized
DEBUG - 2018-08-02 03:28:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 03:28:35 --> Input Class Initialized
INFO - 2018-08-02 03:28:35 --> Language Class Initialized
ERROR - 2018-08-02 03:28:35 --> 404 Page Not Found: /index
INFO - 2018-08-02 03:28:35 --> Config Class Initialized
INFO - 2018-08-02 03:28:35 --> Hooks Class Initialized
DEBUG - 2018-08-02 03:28:35 --> UTF-8 Support Enabled
INFO - 2018-08-02 03:28:35 --> Utf8 Class Initialized
INFO - 2018-08-02 03:28:35 --> URI Class Initialized
INFO - 2018-08-02 03:28:35 --> Router Class Initialized
INFO - 2018-08-02 03:28:35 --> Output Class Initialized
INFO - 2018-08-02 03:28:35 --> Security Class Initialized
DEBUG - 2018-08-02 03:28:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 03:28:35 --> Input Class Initialized
INFO - 2018-08-02 03:28:35 --> Language Class Initialized
ERROR - 2018-08-02 03:28:35 --> 404 Page Not Found: /index
INFO - 2018-08-02 03:28:52 --> Config Class Initialized
INFO - 2018-08-02 03:28:52 --> Hooks Class Initialized
DEBUG - 2018-08-02 03:28:53 --> UTF-8 Support Enabled
INFO - 2018-08-02 03:28:53 --> Utf8 Class Initialized
INFO - 2018-08-02 03:28:53 --> URI Class Initialized
INFO - 2018-08-02 03:28:53 --> Router Class Initialized
INFO - 2018-08-02 03:28:53 --> Output Class Initialized
INFO - 2018-08-02 03:28:53 --> Security Class Initialized
DEBUG - 2018-08-02 03:28:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 03:28:53 --> Input Class Initialized
INFO - 2018-08-02 03:28:53 --> Language Class Initialized
INFO - 2018-08-02 03:28:53 --> Language Class Initialized
INFO - 2018-08-02 03:28:53 --> Config Class Initialized
INFO - 2018-08-02 03:28:53 --> Loader Class Initialized
DEBUG - 2018-08-02 03:28:53 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-02 03:28:53 --> Helper loaded: url_helper
INFO - 2018-08-02 03:28:53 --> Helper loaded: form_helper
INFO - 2018-08-02 03:28:53 --> Helper loaded: date_helper
INFO - 2018-08-02 03:28:53 --> Helper loaded: util_helper
INFO - 2018-08-02 03:28:53 --> Helper loaded: text_helper
INFO - 2018-08-02 03:28:53 --> Helper loaded: string_helper
INFO - 2018-08-02 03:28:53 --> Database Driver Class Initialized
DEBUG - 2018-08-02 03:28:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-02 03:28:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-02 03:28:53 --> Email Class Initialized
INFO - 2018-08-02 03:28:53 --> Controller Class Initialized
DEBUG - 2018-08-02 03:28:53 --> Home MX_Controller Initialized
DEBUG - 2018-08-02 03:28:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-02 03:28:53 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-02 03:28:53 --> Login MX_Controller Initialized
INFO - 2018-08-02 03:28:53 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-02 03:28:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-02 03:28:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-02 03:28:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-08-02 03:28:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-08-02 03:28:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-08-02 03:28:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-08-02 03:28:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-08-02 03:28:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-08-02 03:28:53 --> Final output sent to browser
DEBUG - 2018-08-02 03:28:53 --> Total execution time: 0.5090
INFO - 2018-08-02 03:28:54 --> Config Class Initialized
INFO - 2018-08-02 03:28:54 --> Hooks Class Initialized
DEBUG - 2018-08-02 03:28:54 --> UTF-8 Support Enabled
INFO - 2018-08-02 03:28:54 --> Utf8 Class Initialized
INFO - 2018-08-02 03:28:54 --> Config Class Initialized
INFO - 2018-08-02 03:28:54 --> Hooks Class Initialized
INFO - 2018-08-02 03:28:54 --> URI Class Initialized
DEBUG - 2018-08-02 03:28:54 --> UTF-8 Support Enabled
INFO - 2018-08-02 03:28:54 --> Router Class Initialized
INFO - 2018-08-02 03:28:54 --> Utf8 Class Initialized
INFO - 2018-08-02 03:28:54 --> Output Class Initialized
INFO - 2018-08-02 03:28:54 --> URI Class Initialized
INFO - 2018-08-02 03:28:54 --> Router Class Initialized
INFO - 2018-08-02 03:28:54 --> Output Class Initialized
INFO - 2018-08-02 03:28:54 --> Security Class Initialized
DEBUG - 2018-08-02 03:28:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 03:28:54 --> Input Class Initialized
INFO - 2018-08-02 03:28:54 --> Language Class Initialized
INFO - 2018-08-02 03:28:54 --> Language Class Initialized
INFO - 2018-08-02 03:28:54 --> Security Class Initialized
INFO - 2018-08-02 03:28:54 --> Config Class Initialized
DEBUG - 2018-08-02 03:28:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 03:28:54 --> Loader Class Initialized
INFO - 2018-08-02 03:28:54 --> Input Class Initialized
INFO - 2018-08-02 03:28:54 --> Language Class Initialized
ERROR - 2018-08-02 03:28:54 --> 404 Page Not Found: /index
DEBUG - 2018-08-02 03:28:54 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-02 03:28:54 --> Config Class Initialized
INFO - 2018-08-02 03:28:54 --> Hooks Class Initialized
INFO - 2018-08-02 03:28:54 --> Helper loaded: url_helper
DEBUG - 2018-08-02 03:28:54 --> UTF-8 Support Enabled
INFO - 2018-08-02 03:28:54 --> Utf8 Class Initialized
INFO - 2018-08-02 03:28:54 --> URI Class Initialized
INFO - 2018-08-02 03:28:54 --> Helper loaded: form_helper
INFO - 2018-08-02 03:28:54 --> Helper loaded: date_helper
INFO - 2018-08-02 03:28:54 --> Router Class Initialized
INFO - 2018-08-02 03:28:54 --> Helper loaded: util_helper
INFO - 2018-08-02 03:28:54 --> Helper loaded: text_helper
INFO - 2018-08-02 03:28:54 --> Helper loaded: string_helper
INFO - 2018-08-02 03:28:54 --> Output Class Initialized
INFO - 2018-08-02 03:28:54 --> Database Driver Class Initialized
INFO - 2018-08-02 03:28:54 --> Security Class Initialized
DEBUG - 2018-08-02 03:28:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 03:28:54 --> Input Class Initialized
INFO - 2018-08-02 03:28:54 --> Language Class Initialized
ERROR - 2018-08-02 03:28:54 --> 404 Page Not Found: /index
INFO - 2018-08-02 03:28:54 --> Config Class Initialized
INFO - 2018-08-02 03:28:55 --> Hooks Class Initialized
DEBUG - 2018-08-02 03:28:55 --> UTF-8 Support Enabled
INFO - 2018-08-02 03:28:55 --> Utf8 Class Initialized
INFO - 2018-08-02 03:28:55 --> URI Class Initialized
INFO - 2018-08-02 03:28:55 --> Router Class Initialized
INFO - 2018-08-02 03:28:55 --> Output Class Initialized
INFO - 2018-08-02 03:28:55 --> Security Class Initialized
DEBUG - 2018-08-02 03:28:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-08-02 03:28:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-02 03:28:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-02 03:28:55 --> Input Class Initialized
INFO - 2018-08-02 03:28:55 --> Email Class Initialized
INFO - 2018-08-02 03:28:55 --> Controller Class Initialized
DEBUG - 2018-08-02 03:28:55 --> Home MX_Controller Initialized
DEBUG - 2018-08-02 03:28:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-08-02 03:28:55 --> Language Class Initialized
DEBUG - 2018-08-02 03:28:55 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-02 03:28:55 --> Login MX_Controller Initialized
ERROR - 2018-08-02 03:28:55 --> 404 Page Not Found: /index
INFO - 2018-08-02 03:28:55 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-02 03:28:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-02 03:28:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-02 03:28:55 --> Config Class Initialized
INFO - 2018-08-02 03:28:55 --> Hooks Class Initialized
DEBUG - 2018-08-02 03:28:55 --> UTF-8 Support Enabled
INFO - 2018-08-02 03:28:55 --> Utf8 Class Initialized
INFO - 2018-08-02 03:28:55 --> URI Class Initialized
INFO - 2018-08-02 03:28:55 --> Router Class Initialized
INFO - 2018-08-02 03:28:55 --> Output Class Initialized
INFO - 2018-08-02 03:28:55 --> Security Class Initialized
DEBUG - 2018-08-02 03:28:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 03:28:55 --> Input Class Initialized
INFO - 2018-08-02 03:28:55 --> Language Class Initialized
ERROR - 2018-08-02 03:28:55 --> 404 Page Not Found: /index
INFO - 2018-08-02 03:28:55 --> Config Class Initialized
INFO - 2018-08-02 03:28:55 --> Hooks Class Initialized
DEBUG - 2018-08-02 03:28:55 --> UTF-8 Support Enabled
INFO - 2018-08-02 03:28:55 --> Utf8 Class Initialized
INFO - 2018-08-02 03:28:55 --> URI Class Initialized
INFO - 2018-08-02 03:28:55 --> Router Class Initialized
INFO - 2018-08-02 03:28:55 --> Output Class Initialized
INFO - 2018-08-02 03:28:55 --> Security Class Initialized
DEBUG - 2018-08-02 03:28:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 03:28:55 --> Input Class Initialized
INFO - 2018-08-02 03:28:55 --> Language Class Initialized
ERROR - 2018-08-02 03:28:55 --> 404 Page Not Found: /index
INFO - 2018-08-02 03:28:56 --> Config Class Initialized
INFO - 2018-08-02 03:28:56 --> Hooks Class Initialized
DEBUG - 2018-08-02 03:28:56 --> UTF-8 Support Enabled
INFO - 2018-08-02 03:28:56 --> Utf8 Class Initialized
INFO - 2018-08-02 03:28:56 --> URI Class Initialized
INFO - 2018-08-02 03:28:56 --> Router Class Initialized
INFO - 2018-08-02 03:28:56 --> Output Class Initialized
INFO - 2018-08-02 03:28:56 --> Security Class Initialized
DEBUG - 2018-08-02 03:28:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 03:28:56 --> Input Class Initialized
INFO - 2018-08-02 03:28:56 --> Language Class Initialized
ERROR - 2018-08-02 03:28:56 --> 404 Page Not Found: /index
INFO - 2018-08-02 03:29:11 --> Config Class Initialized
INFO - 2018-08-02 03:29:11 --> Hooks Class Initialized
DEBUG - 2018-08-02 03:29:11 --> UTF-8 Support Enabled
INFO - 2018-08-02 03:29:11 --> Utf8 Class Initialized
INFO - 2018-08-02 03:29:11 --> URI Class Initialized
INFO - 2018-08-02 03:29:11 --> Router Class Initialized
INFO - 2018-08-02 03:29:11 --> Output Class Initialized
INFO - 2018-08-02 03:29:11 --> Security Class Initialized
DEBUG - 2018-08-02 03:29:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 03:29:11 --> Input Class Initialized
INFO - 2018-08-02 03:29:11 --> Language Class Initialized
INFO - 2018-08-02 03:29:11 --> Language Class Initialized
INFO - 2018-08-02 03:29:11 --> Config Class Initialized
INFO - 2018-08-02 03:29:11 --> Loader Class Initialized
DEBUG - 2018-08-02 03:29:11 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-02 03:29:11 --> Helper loaded: url_helper
INFO - 2018-08-02 03:29:11 --> Helper loaded: form_helper
INFO - 2018-08-02 03:29:11 --> Helper loaded: date_helper
INFO - 2018-08-02 03:29:11 --> Helper loaded: util_helper
INFO - 2018-08-02 03:29:11 --> Helper loaded: text_helper
INFO - 2018-08-02 03:29:11 --> Helper loaded: string_helper
INFO - 2018-08-02 03:29:11 --> Database Driver Class Initialized
DEBUG - 2018-08-02 03:29:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-02 03:29:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-02 03:29:11 --> Email Class Initialized
INFO - 2018-08-02 03:29:11 --> Controller Class Initialized
DEBUG - 2018-08-02 03:29:11 --> Home MX_Controller Initialized
DEBUG - 2018-08-02 03:29:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-02 03:29:11 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-02 03:29:11 --> Login MX_Controller Initialized
INFO - 2018-08-02 03:29:11 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-02 03:29:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-02 03:29:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-02 03:29:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-08-02 03:29:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-08-02 03:29:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-08-02 03:29:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-08-02 03:29:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-08-02 03:29:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-08-02 03:29:12 --> Final output sent to browser
DEBUG - 2018-08-02 03:29:12 --> Total execution time: 0.5490
INFO - 2018-08-02 03:29:12 --> Config Class Initialized
INFO - 2018-08-02 03:29:12 --> Hooks Class Initialized
DEBUG - 2018-08-02 03:29:12 --> UTF-8 Support Enabled
INFO - 2018-08-02 03:29:12 --> Utf8 Class Initialized
INFO - 2018-08-02 03:29:12 --> Config Class Initialized
INFO - 2018-08-02 03:29:12 --> Hooks Class Initialized
INFO - 2018-08-02 03:29:12 --> URI Class Initialized
DEBUG - 2018-08-02 03:29:12 --> UTF-8 Support Enabled
INFO - 2018-08-02 03:29:12 --> Router Class Initialized
INFO - 2018-08-02 03:29:13 --> Utf8 Class Initialized
INFO - 2018-08-02 03:29:13 --> Output Class Initialized
INFO - 2018-08-02 03:29:13 --> URI Class Initialized
INFO - 2018-08-02 03:29:13 --> Router Class Initialized
INFO - 2018-08-02 03:29:13 --> Output Class Initialized
INFO - 2018-08-02 03:29:13 --> Security Class Initialized
DEBUG - 2018-08-02 03:29:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 03:29:13 --> Input Class Initialized
INFO - 2018-08-02 03:29:13 --> Language Class Initialized
INFO - 2018-08-02 03:29:13 --> Language Class Initialized
INFO - 2018-08-02 03:29:13 --> Config Class Initialized
INFO - 2018-08-02 03:29:13 --> Security Class Initialized
DEBUG - 2018-08-02 03:29:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 03:29:13 --> Loader Class Initialized
DEBUG - 2018-08-02 03:29:13 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-02 03:29:13 --> Input Class Initialized
INFO - 2018-08-02 03:29:13 --> Helper loaded: url_helper
INFO - 2018-08-02 03:29:13 --> Helper loaded: form_helper
INFO - 2018-08-02 03:29:13 --> Helper loaded: date_helper
INFO - 2018-08-02 03:29:13 --> Language Class Initialized
INFO - 2018-08-02 03:29:13 --> Helper loaded: util_helper
ERROR - 2018-08-02 03:29:13 --> 404 Page Not Found: /index
INFO - 2018-08-02 03:29:13 --> Helper loaded: text_helper
INFO - 2018-08-02 03:29:13 --> Helper loaded: string_helper
INFO - 2018-08-02 03:29:13 --> Config Class Initialized
INFO - 2018-08-02 03:29:13 --> Hooks Class Initialized
INFO - 2018-08-02 03:29:13 --> Database Driver Class Initialized
DEBUG - 2018-08-02 03:29:13 --> UTF-8 Support Enabled
DEBUG - 2018-08-02 03:29:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-02 03:29:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-02 03:29:13 --> Utf8 Class Initialized
INFO - 2018-08-02 03:29:13 --> URI Class Initialized
INFO - 2018-08-02 03:29:13 --> Email Class Initialized
INFO - 2018-08-02 03:29:13 --> Controller Class Initialized
INFO - 2018-08-02 03:29:13 --> Router Class Initialized
DEBUG - 2018-08-02 03:29:13 --> Home MX_Controller Initialized
INFO - 2018-08-02 03:29:13 --> Output Class Initialized
DEBUG - 2018-08-02 03:29:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-08-02 03:29:13 --> Security Class Initialized
DEBUG - 2018-08-02 03:29:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-08-02 03:29:13 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-02 03:29:13 --> Login MX_Controller Initialized
INFO - 2018-08-02 03:29:13 --> Input Class Initialized
INFO - 2018-08-02 03:29:13 --> Language file loaded: language/english/data_lang.php
INFO - 2018-08-02 03:29:13 --> Language Class Initialized
DEBUG - 2018-08-02 03:29:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
ERROR - 2018-08-02 03:29:13 --> 404 Page Not Found: /index
DEBUG - 2018-08-02 03:29:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-02 03:29:13 --> Config Class Initialized
INFO - 2018-08-02 03:29:13 --> Hooks Class Initialized
DEBUG - 2018-08-02 03:29:13 --> UTF-8 Support Enabled
INFO - 2018-08-02 03:29:13 --> Utf8 Class Initialized
INFO - 2018-08-02 03:29:13 --> URI Class Initialized
INFO - 2018-08-02 03:29:13 --> Router Class Initialized
INFO - 2018-08-02 03:29:13 --> Output Class Initialized
INFO - 2018-08-02 03:29:13 --> Security Class Initialized
DEBUG - 2018-08-02 03:29:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 03:29:13 --> Input Class Initialized
INFO - 2018-08-02 03:29:14 --> Language Class Initialized
ERROR - 2018-08-02 03:29:14 --> 404 Page Not Found: /index
INFO - 2018-08-02 03:29:14 --> Config Class Initialized
INFO - 2018-08-02 03:29:14 --> Hooks Class Initialized
DEBUG - 2018-08-02 03:29:14 --> UTF-8 Support Enabled
INFO - 2018-08-02 03:29:14 --> Utf8 Class Initialized
INFO - 2018-08-02 03:29:14 --> URI Class Initialized
INFO - 2018-08-02 03:29:14 --> Router Class Initialized
INFO - 2018-08-02 03:29:14 --> Output Class Initialized
INFO - 2018-08-02 03:29:14 --> Security Class Initialized
DEBUG - 2018-08-02 03:29:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 03:29:14 --> Input Class Initialized
INFO - 2018-08-02 03:29:14 --> Language Class Initialized
ERROR - 2018-08-02 03:29:14 --> 404 Page Not Found: /index
INFO - 2018-08-02 03:29:14 --> Config Class Initialized
INFO - 2018-08-02 03:29:14 --> Hooks Class Initialized
DEBUG - 2018-08-02 03:29:14 --> UTF-8 Support Enabled
INFO - 2018-08-02 03:29:14 --> Utf8 Class Initialized
INFO - 2018-08-02 03:29:14 --> URI Class Initialized
INFO - 2018-08-02 03:29:14 --> Router Class Initialized
INFO - 2018-08-02 03:29:14 --> Output Class Initialized
INFO - 2018-08-02 03:29:14 --> Security Class Initialized
DEBUG - 2018-08-02 03:29:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 03:29:14 --> Input Class Initialized
INFO - 2018-08-02 03:29:14 --> Language Class Initialized
ERROR - 2018-08-02 03:29:14 --> 404 Page Not Found: /index
INFO - 2018-08-02 03:29:14 --> Config Class Initialized
INFO - 2018-08-02 03:29:14 --> Hooks Class Initialized
DEBUG - 2018-08-02 03:29:14 --> UTF-8 Support Enabled
INFO - 2018-08-02 03:29:14 --> Utf8 Class Initialized
INFO - 2018-08-02 03:29:14 --> URI Class Initialized
INFO - 2018-08-02 03:29:14 --> Router Class Initialized
INFO - 2018-08-02 03:29:14 --> Output Class Initialized
INFO - 2018-08-02 03:29:14 --> Security Class Initialized
DEBUG - 2018-08-02 03:29:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 03:29:14 --> Input Class Initialized
INFO - 2018-08-02 03:29:14 --> Language Class Initialized
ERROR - 2018-08-02 03:29:14 --> 404 Page Not Found: /index
INFO - 2018-08-02 03:29:25 --> Config Class Initialized
INFO - 2018-08-02 03:29:25 --> Hooks Class Initialized
DEBUG - 2018-08-02 03:29:25 --> UTF-8 Support Enabled
INFO - 2018-08-02 03:29:25 --> Utf8 Class Initialized
INFO - 2018-08-02 03:29:25 --> URI Class Initialized
INFO - 2018-08-02 03:29:25 --> Router Class Initialized
INFO - 2018-08-02 03:29:25 --> Output Class Initialized
INFO - 2018-08-02 03:29:25 --> Security Class Initialized
DEBUG - 2018-08-02 03:29:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 03:29:25 --> Input Class Initialized
INFO - 2018-08-02 03:29:25 --> Language Class Initialized
INFO - 2018-08-02 03:29:25 --> Language Class Initialized
INFO - 2018-08-02 03:29:25 --> Config Class Initialized
INFO - 2018-08-02 03:29:25 --> Loader Class Initialized
DEBUG - 2018-08-02 03:29:25 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-02 03:29:25 --> Helper loaded: url_helper
INFO - 2018-08-02 03:29:25 --> Helper loaded: form_helper
INFO - 2018-08-02 03:29:25 --> Helper loaded: date_helper
INFO - 2018-08-02 03:29:25 --> Helper loaded: util_helper
INFO - 2018-08-02 03:29:25 --> Helper loaded: text_helper
INFO - 2018-08-02 03:29:25 --> Helper loaded: string_helper
INFO - 2018-08-02 03:29:25 --> Database Driver Class Initialized
DEBUG - 2018-08-02 03:29:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-02 03:29:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-02 03:29:25 --> Email Class Initialized
INFO - 2018-08-02 03:29:25 --> Controller Class Initialized
DEBUG - 2018-08-02 03:29:25 --> Home MX_Controller Initialized
DEBUG - 2018-08-02 03:29:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-02 03:29:25 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-02 03:29:25 --> Login MX_Controller Initialized
INFO - 2018-08-02 03:29:25 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-02 03:29:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-02 03:29:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-02 03:29:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-08-02 03:29:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-08-02 03:29:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-08-02 03:29:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-08-02 03:29:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-08-02 03:29:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-08-02 03:29:25 --> Final output sent to browser
DEBUG - 2018-08-02 03:29:26 --> Total execution time: 0.5183
INFO - 2018-08-02 03:29:26 --> Config Class Initialized
INFO - 2018-08-02 03:29:26 --> Hooks Class Initialized
DEBUG - 2018-08-02 03:29:26 --> UTF-8 Support Enabled
INFO - 2018-08-02 03:29:26 --> Utf8 Class Initialized
INFO - 2018-08-02 03:29:26 --> Config Class Initialized
INFO - 2018-08-02 03:29:26 --> Hooks Class Initialized
INFO - 2018-08-02 03:29:26 --> URI Class Initialized
DEBUG - 2018-08-02 03:29:26 --> UTF-8 Support Enabled
INFO - 2018-08-02 03:29:26 --> Utf8 Class Initialized
INFO - 2018-08-02 03:29:26 --> Router Class Initialized
INFO - 2018-08-02 03:29:26 --> URI Class Initialized
INFO - 2018-08-02 03:29:26 --> Output Class Initialized
INFO - 2018-08-02 03:29:26 --> Router Class Initialized
INFO - 2018-08-02 03:29:26 --> Security Class Initialized
DEBUG - 2018-08-02 03:29:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 03:29:26 --> Output Class Initialized
INFO - 2018-08-02 03:29:26 --> Security Class Initialized
INFO - 2018-08-02 03:29:26 --> Input Class Initialized
DEBUG - 2018-08-02 03:29:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 03:29:26 --> Input Class Initialized
INFO - 2018-08-02 03:29:26 --> Language Class Initialized
INFO - 2018-08-02 03:29:26 --> Language Class Initialized
INFO - 2018-08-02 03:29:26 --> Language Class Initialized
INFO - 2018-08-02 03:29:26 --> Config Class Initialized
ERROR - 2018-08-02 03:29:26 --> 404 Page Not Found: /index
INFO - 2018-08-02 03:29:26 --> Loader Class Initialized
INFO - 2018-08-02 03:29:26 --> Config Class Initialized
INFO - 2018-08-02 03:29:26 --> Hooks Class Initialized
DEBUG - 2018-08-02 03:29:26 --> UTF-8 Support Enabled
DEBUG - 2018-08-02 03:29:26 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-02 03:29:27 --> Utf8 Class Initialized
INFO - 2018-08-02 03:29:27 --> URI Class Initialized
INFO - 2018-08-02 03:29:27 --> Helper loaded: url_helper
INFO - 2018-08-02 03:29:27 --> Router Class Initialized
INFO - 2018-08-02 03:29:27 --> Helper loaded: form_helper
INFO - 2018-08-02 03:29:27 --> Output Class Initialized
INFO - 2018-08-02 03:29:27 --> Security Class Initialized
INFO - 2018-08-02 03:29:27 --> Helper loaded: date_helper
INFO - 2018-08-02 03:29:27 --> Helper loaded: util_helper
DEBUG - 2018-08-02 03:29:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 03:29:27 --> Helper loaded: text_helper
INFO - 2018-08-02 03:29:27 --> Input Class Initialized
INFO - 2018-08-02 03:29:27 --> Helper loaded: string_helper
INFO - 2018-08-02 03:29:27 --> Language Class Initialized
INFO - 2018-08-02 03:29:27 --> Database Driver Class Initialized
ERROR - 2018-08-02 03:29:27 --> 404 Page Not Found: /index
DEBUG - 2018-08-02 03:29:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-02 03:29:27 --> Config Class Initialized
INFO - 2018-08-02 03:29:27 --> Hooks Class Initialized
INFO - 2018-08-02 03:29:27 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-08-02 03:29:27 --> UTF-8 Support Enabled
INFO - 2018-08-02 03:29:27 --> Email Class Initialized
INFO - 2018-08-02 03:29:27 --> Utf8 Class Initialized
INFO - 2018-08-02 03:29:27 --> Controller Class Initialized
DEBUG - 2018-08-02 03:29:27 --> Home MX_Controller Initialized
INFO - 2018-08-02 03:29:27 --> URI Class Initialized
DEBUG - 2018-08-02 03:29:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-08-02 03:29:27 --> Router Class Initialized
INFO - 2018-08-02 03:29:27 --> Output Class Initialized
DEBUG - 2018-08-02 03:29:27 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-02 03:29:27 --> Login MX_Controller Initialized
INFO - 2018-08-02 03:29:27 --> Security Class Initialized
INFO - 2018-08-02 03:29:27 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-02 03:29:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-08-02 03:29:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-08-02 03:29:27 --> Input Class Initialized
DEBUG - 2018-08-02 03:29:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-02 03:29:27 --> Language Class Initialized
ERROR - 2018-08-02 03:29:27 --> 404 Page Not Found: /index
INFO - 2018-08-02 03:29:27 --> Config Class Initialized
INFO - 2018-08-02 03:29:27 --> Hooks Class Initialized
DEBUG - 2018-08-02 03:29:27 --> UTF-8 Support Enabled
INFO - 2018-08-02 03:29:27 --> Utf8 Class Initialized
INFO - 2018-08-02 03:29:27 --> URI Class Initialized
INFO - 2018-08-02 03:29:27 --> Router Class Initialized
INFO - 2018-08-02 03:29:27 --> Output Class Initialized
INFO - 2018-08-02 03:29:27 --> Security Class Initialized
DEBUG - 2018-08-02 03:29:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 03:29:27 --> Input Class Initialized
INFO - 2018-08-02 03:29:27 --> Language Class Initialized
ERROR - 2018-08-02 03:29:27 --> 404 Page Not Found: /index
INFO - 2018-08-02 03:29:27 --> Config Class Initialized
INFO - 2018-08-02 03:29:27 --> Hooks Class Initialized
DEBUG - 2018-08-02 03:29:27 --> UTF-8 Support Enabled
INFO - 2018-08-02 03:29:27 --> Utf8 Class Initialized
INFO - 2018-08-02 03:29:27 --> URI Class Initialized
INFO - 2018-08-02 03:29:27 --> Router Class Initialized
INFO - 2018-08-02 03:29:27 --> Output Class Initialized
INFO - 2018-08-02 03:29:27 --> Security Class Initialized
DEBUG - 2018-08-02 03:29:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 03:29:27 --> Input Class Initialized
INFO - 2018-08-02 03:29:27 --> Language Class Initialized
ERROR - 2018-08-02 03:29:27 --> 404 Page Not Found: /index
INFO - 2018-08-02 03:29:27 --> Config Class Initialized
INFO - 2018-08-02 03:29:27 --> Hooks Class Initialized
DEBUG - 2018-08-02 03:29:27 --> UTF-8 Support Enabled
INFO - 2018-08-02 03:29:27 --> Utf8 Class Initialized
INFO - 2018-08-02 03:29:28 --> URI Class Initialized
INFO - 2018-08-02 03:29:28 --> Router Class Initialized
INFO - 2018-08-02 03:29:28 --> Output Class Initialized
INFO - 2018-08-02 03:29:28 --> Security Class Initialized
DEBUG - 2018-08-02 03:29:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 03:29:28 --> Input Class Initialized
INFO - 2018-08-02 03:29:28 --> Language Class Initialized
ERROR - 2018-08-02 03:29:28 --> 404 Page Not Found: /index
INFO - 2018-08-02 03:30:21 --> Config Class Initialized
INFO - 2018-08-02 03:30:21 --> Hooks Class Initialized
DEBUG - 2018-08-02 03:30:21 --> UTF-8 Support Enabled
INFO - 2018-08-02 03:30:21 --> Utf8 Class Initialized
INFO - 2018-08-02 03:30:21 --> URI Class Initialized
INFO - 2018-08-02 03:30:21 --> Router Class Initialized
INFO - 2018-08-02 03:30:21 --> Output Class Initialized
INFO - 2018-08-02 03:30:21 --> Security Class Initialized
DEBUG - 2018-08-02 03:30:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 03:30:21 --> Input Class Initialized
INFO - 2018-08-02 03:30:21 --> Language Class Initialized
INFO - 2018-08-02 03:30:21 --> Language Class Initialized
INFO - 2018-08-02 03:30:21 --> Config Class Initialized
INFO - 2018-08-02 03:30:21 --> Loader Class Initialized
DEBUG - 2018-08-02 03:30:21 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-02 03:30:21 --> Helper loaded: url_helper
INFO - 2018-08-02 03:30:21 --> Helper loaded: form_helper
INFO - 2018-08-02 03:30:21 --> Helper loaded: date_helper
INFO - 2018-08-02 03:30:21 --> Helper loaded: util_helper
INFO - 2018-08-02 03:30:21 --> Helper loaded: text_helper
INFO - 2018-08-02 03:30:21 --> Helper loaded: string_helper
INFO - 2018-08-02 03:30:21 --> Database Driver Class Initialized
DEBUG - 2018-08-02 03:30:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-02 03:30:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-02 03:30:22 --> Email Class Initialized
INFO - 2018-08-02 03:30:22 --> Controller Class Initialized
DEBUG - 2018-08-02 03:30:22 --> Home MX_Controller Initialized
DEBUG - 2018-08-02 03:30:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-02 03:30:22 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-02 03:30:22 --> Login MX_Controller Initialized
INFO - 2018-08-02 03:30:22 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-02 03:30:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-02 03:30:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-02 03:30:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-08-02 03:30:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-08-02 03:30:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-08-02 03:30:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-08-02 03:30:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-08-02 03:30:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-08-02 03:30:22 --> Final output sent to browser
DEBUG - 2018-08-02 03:30:22 --> Total execution time: 0.5329
INFO - 2018-08-02 03:30:22 --> Config Class Initialized
INFO - 2018-08-02 03:30:22 --> Hooks Class Initialized
DEBUG - 2018-08-02 03:30:23 --> UTF-8 Support Enabled
INFO - 2018-08-02 03:30:23 --> Utf8 Class Initialized
INFO - 2018-08-02 03:30:23 --> URI Class Initialized
INFO - 2018-08-02 03:30:23 --> Router Class Initialized
INFO - 2018-08-02 03:30:23 --> Output Class Initialized
INFO - 2018-08-02 03:30:23 --> Security Class Initialized
DEBUG - 2018-08-02 03:30:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 03:30:23 --> Input Class Initialized
INFO - 2018-08-02 03:30:23 --> Language Class Initialized
ERROR - 2018-08-02 03:30:23 --> 404 Page Not Found: /index
INFO - 2018-08-02 03:30:23 --> Config Class Initialized
INFO - 2018-08-02 03:30:23 --> Hooks Class Initialized
DEBUG - 2018-08-02 03:30:23 --> UTF-8 Support Enabled
INFO - 2018-08-02 03:30:23 --> Utf8 Class Initialized
INFO - 2018-08-02 03:30:23 --> URI Class Initialized
INFO - 2018-08-02 03:30:23 --> Router Class Initialized
INFO - 2018-08-02 03:30:23 --> Output Class Initialized
INFO - 2018-08-02 03:30:23 --> Security Class Initialized
DEBUG - 2018-08-02 03:30:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 03:30:23 --> Input Class Initialized
INFO - 2018-08-02 03:30:23 --> Language Class Initialized
ERROR - 2018-08-02 03:30:23 --> 404 Page Not Found: /index
INFO - 2018-08-02 03:30:23 --> Config Class Initialized
INFO - 2018-08-02 03:30:23 --> Hooks Class Initialized
DEBUG - 2018-08-02 03:30:23 --> UTF-8 Support Enabled
INFO - 2018-08-02 03:30:23 --> Utf8 Class Initialized
INFO - 2018-08-02 03:30:23 --> URI Class Initialized
INFO - 2018-08-02 03:30:23 --> Router Class Initialized
INFO - 2018-08-02 03:30:23 --> Output Class Initialized
INFO - 2018-08-02 03:30:23 --> Security Class Initialized
DEBUG - 2018-08-02 03:30:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 03:30:23 --> Input Class Initialized
INFO - 2018-08-02 03:30:23 --> Language Class Initialized
ERROR - 2018-08-02 03:30:23 --> 404 Page Not Found: /index
INFO - 2018-08-02 03:30:23 --> Config Class Initialized
INFO - 2018-08-02 03:30:23 --> Hooks Class Initialized
DEBUG - 2018-08-02 03:30:23 --> UTF-8 Support Enabled
INFO - 2018-08-02 03:30:23 --> Utf8 Class Initialized
INFO - 2018-08-02 03:30:23 --> URI Class Initialized
INFO - 2018-08-02 03:30:23 --> Router Class Initialized
INFO - 2018-08-02 03:30:23 --> Output Class Initialized
INFO - 2018-08-02 03:30:23 --> Security Class Initialized
DEBUG - 2018-08-02 03:30:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 03:30:24 --> Input Class Initialized
INFO - 2018-08-02 03:30:24 --> Language Class Initialized
ERROR - 2018-08-02 03:30:24 --> 404 Page Not Found: /index
INFO - 2018-08-02 03:30:24 --> Config Class Initialized
INFO - 2018-08-02 03:30:24 --> Hooks Class Initialized
DEBUG - 2018-08-02 03:30:24 --> UTF-8 Support Enabled
INFO - 2018-08-02 03:30:24 --> Utf8 Class Initialized
INFO - 2018-08-02 03:30:24 --> URI Class Initialized
INFO - 2018-08-02 03:30:24 --> Router Class Initialized
INFO - 2018-08-02 03:30:24 --> Output Class Initialized
INFO - 2018-08-02 03:30:24 --> Security Class Initialized
DEBUG - 2018-08-02 03:30:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 03:30:24 --> Input Class Initialized
INFO - 2018-08-02 03:30:24 --> Language Class Initialized
ERROR - 2018-08-02 03:30:24 --> 404 Page Not Found: /index
INFO - 2018-08-02 03:30:24 --> Config Class Initialized
INFO - 2018-08-02 03:30:24 --> Hooks Class Initialized
DEBUG - 2018-08-02 03:30:24 --> UTF-8 Support Enabled
INFO - 2018-08-02 03:30:24 --> Utf8 Class Initialized
INFO - 2018-08-02 03:30:24 --> URI Class Initialized
INFO - 2018-08-02 03:30:24 --> Router Class Initialized
INFO - 2018-08-02 03:30:24 --> Output Class Initialized
INFO - 2018-08-02 03:30:24 --> Security Class Initialized
DEBUG - 2018-08-02 03:30:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 03:30:24 --> Input Class Initialized
INFO - 2018-08-02 03:30:24 --> Language Class Initialized
ERROR - 2018-08-02 03:30:24 --> 404 Page Not Found: /index
INFO - 2018-08-02 03:30:29 --> Config Class Initialized
INFO - 2018-08-02 03:30:29 --> Hooks Class Initialized
DEBUG - 2018-08-02 03:30:29 --> UTF-8 Support Enabled
INFO - 2018-08-02 03:30:29 --> Utf8 Class Initialized
INFO - 2018-08-02 03:30:29 --> URI Class Initialized
INFO - 2018-08-02 03:30:29 --> Router Class Initialized
INFO - 2018-08-02 03:30:29 --> Output Class Initialized
INFO - 2018-08-02 03:30:29 --> Security Class Initialized
DEBUG - 2018-08-02 03:30:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 03:30:29 --> Input Class Initialized
INFO - 2018-08-02 03:30:29 --> Language Class Initialized
INFO - 2018-08-02 03:30:29 --> Language Class Initialized
INFO - 2018-08-02 03:30:29 --> Config Class Initialized
INFO - 2018-08-02 03:30:29 --> Loader Class Initialized
DEBUG - 2018-08-02 03:30:29 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-02 03:30:29 --> Helper loaded: url_helper
INFO - 2018-08-02 03:30:29 --> Helper loaded: form_helper
INFO - 2018-08-02 03:30:29 --> Helper loaded: date_helper
INFO - 2018-08-02 03:30:29 --> Helper loaded: util_helper
INFO - 2018-08-02 03:30:29 --> Helper loaded: text_helper
INFO - 2018-08-02 03:30:29 --> Helper loaded: string_helper
INFO - 2018-08-02 03:30:29 --> Database Driver Class Initialized
DEBUG - 2018-08-02 03:30:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-02 03:30:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-02 03:30:29 --> Email Class Initialized
INFO - 2018-08-02 03:30:29 --> Controller Class Initialized
DEBUG - 2018-08-02 03:30:29 --> Home MX_Controller Initialized
DEBUG - 2018-08-02 03:30:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-02 03:30:29 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-02 03:30:29 --> Login MX_Controller Initialized
INFO - 2018-08-02 03:30:29 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-02 03:30:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-02 03:30:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-02 03:30:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-08-02 03:30:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-08-02 03:30:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-08-02 03:30:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-08-02 03:30:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-08-02 03:30:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-08-02 03:30:30 --> Final output sent to browser
DEBUG - 2018-08-02 03:30:30 --> Total execution time: 0.5370
INFO - 2018-08-02 03:30:30 --> Config Class Initialized
INFO - 2018-08-02 03:30:30 --> Config Class Initialized
INFO - 2018-08-02 03:30:30 --> Hooks Class Initialized
INFO - 2018-08-02 03:30:30 --> Hooks Class Initialized
DEBUG - 2018-08-02 03:30:30 --> UTF-8 Support Enabled
DEBUG - 2018-08-02 03:30:30 --> UTF-8 Support Enabled
INFO - 2018-08-02 03:30:30 --> Utf8 Class Initialized
INFO - 2018-08-02 03:30:30 --> Utf8 Class Initialized
INFO - 2018-08-02 03:30:30 --> URI Class Initialized
INFO - 2018-08-02 03:30:30 --> URI Class Initialized
INFO - 2018-08-02 03:30:30 --> Router Class Initialized
INFO - 2018-08-02 03:30:30 --> Router Class Initialized
INFO - 2018-08-02 03:30:30 --> Output Class Initialized
INFO - 2018-08-02 03:30:30 --> Output Class Initialized
INFO - 2018-08-02 03:30:30 --> Security Class Initialized
DEBUG - 2018-08-02 03:30:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 03:30:30 --> Input Class Initialized
INFO - 2018-08-02 03:30:30 --> Security Class Initialized
INFO - 2018-08-02 03:30:30 --> Language Class Initialized
ERROR - 2018-08-02 03:30:30 --> 404 Page Not Found: /index
DEBUG - 2018-08-02 03:30:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 03:30:30 --> Input Class Initialized
INFO - 2018-08-02 03:30:30 --> Language Class Initialized
ERROR - 2018-08-02 03:30:30 --> 404 Page Not Found: /index
INFO - 2018-08-02 03:30:30 --> Config Class Initialized
INFO - 2018-08-02 03:30:30 --> Hooks Class Initialized
DEBUG - 2018-08-02 03:30:30 --> UTF-8 Support Enabled
INFO - 2018-08-02 03:30:30 --> Utf8 Class Initialized
INFO - 2018-08-02 03:30:30 --> URI Class Initialized
INFO - 2018-08-02 03:30:30 --> Router Class Initialized
INFO - 2018-08-02 03:30:30 --> Output Class Initialized
INFO - 2018-08-02 03:30:30 --> Security Class Initialized
DEBUG - 2018-08-02 03:30:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 03:30:31 --> Input Class Initialized
INFO - 2018-08-02 03:30:31 --> Language Class Initialized
ERROR - 2018-08-02 03:30:31 --> 404 Page Not Found: /index
INFO - 2018-08-02 03:30:31 --> Config Class Initialized
INFO - 2018-08-02 03:30:31 --> Hooks Class Initialized
DEBUG - 2018-08-02 03:30:31 --> UTF-8 Support Enabled
INFO - 2018-08-02 03:30:31 --> Utf8 Class Initialized
INFO - 2018-08-02 03:30:31 --> URI Class Initialized
INFO - 2018-08-02 03:30:31 --> Router Class Initialized
INFO - 2018-08-02 03:30:31 --> Output Class Initialized
INFO - 2018-08-02 03:30:31 --> Security Class Initialized
DEBUG - 2018-08-02 03:30:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 03:30:31 --> Input Class Initialized
INFO - 2018-08-02 03:30:31 --> Language Class Initialized
ERROR - 2018-08-02 03:30:31 --> 404 Page Not Found: /index
INFO - 2018-08-02 03:30:35 --> Config Class Initialized
INFO - 2018-08-02 03:30:35 --> Hooks Class Initialized
DEBUG - 2018-08-02 03:30:35 --> UTF-8 Support Enabled
INFO - 2018-08-02 03:30:35 --> Utf8 Class Initialized
INFO - 2018-08-02 03:30:35 --> URI Class Initialized
INFO - 2018-08-02 03:30:35 --> Router Class Initialized
INFO - 2018-08-02 03:30:35 --> Output Class Initialized
INFO - 2018-08-02 03:30:35 --> Security Class Initialized
DEBUG - 2018-08-02 03:30:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 03:30:35 --> Input Class Initialized
INFO - 2018-08-02 03:30:35 --> Language Class Initialized
INFO - 2018-08-02 03:30:35 --> Language Class Initialized
INFO - 2018-08-02 03:30:35 --> Config Class Initialized
INFO - 2018-08-02 03:30:35 --> Loader Class Initialized
DEBUG - 2018-08-02 03:30:35 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-02 03:30:36 --> Helper loaded: url_helper
INFO - 2018-08-02 03:30:36 --> Helper loaded: form_helper
INFO - 2018-08-02 03:30:36 --> Helper loaded: date_helper
INFO - 2018-08-02 03:30:36 --> Helper loaded: util_helper
INFO - 2018-08-02 03:30:36 --> Helper loaded: text_helper
INFO - 2018-08-02 03:30:36 --> Helper loaded: string_helper
INFO - 2018-08-02 03:30:36 --> Database Driver Class Initialized
DEBUG - 2018-08-02 03:30:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-02 03:30:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-02 03:30:36 --> Email Class Initialized
INFO - 2018-08-02 03:30:36 --> Controller Class Initialized
DEBUG - 2018-08-02 03:30:36 --> Home MX_Controller Initialized
DEBUG - 2018-08-02 03:30:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-02 03:30:36 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-02 03:30:36 --> Login MX_Controller Initialized
INFO - 2018-08-02 03:30:36 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-02 03:30:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-02 03:30:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-02 03:30:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-08-02 03:30:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-08-02 03:30:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-08-02 03:30:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-08-02 03:30:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-08-02 03:30:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-08-02 03:30:36 --> Final output sent to browser
DEBUG - 2018-08-02 03:30:36 --> Total execution time: 0.5437
INFO - 2018-08-02 03:30:36 --> Config Class Initialized
INFO - 2018-08-02 03:30:36 --> Hooks Class Initialized
INFO - 2018-08-02 03:30:36 --> Config Class Initialized
INFO - 2018-08-02 03:30:37 --> Config Class Initialized
INFO - 2018-08-02 03:30:37 --> Hooks Class Initialized
INFO - 2018-08-02 03:30:37 --> Hooks Class Initialized
DEBUG - 2018-08-02 03:30:37 --> UTF-8 Support Enabled
DEBUG - 2018-08-02 03:30:37 --> UTF-8 Support Enabled
DEBUG - 2018-08-02 03:30:37 --> UTF-8 Support Enabled
INFO - 2018-08-02 03:30:37 --> Utf8 Class Initialized
INFO - 2018-08-02 03:30:37 --> Utf8 Class Initialized
INFO - 2018-08-02 03:30:37 --> URI Class Initialized
INFO - 2018-08-02 03:30:37 --> Utf8 Class Initialized
INFO - 2018-08-02 03:30:37 --> URI Class Initialized
INFO - 2018-08-02 03:30:37 --> Router Class Initialized
INFO - 2018-08-02 03:30:37 --> Router Class Initialized
INFO - 2018-08-02 03:30:37 --> URI Class Initialized
INFO - 2018-08-02 03:30:37 --> Output Class Initialized
INFO - 2018-08-02 03:30:37 --> Security Class Initialized
INFO - 2018-08-02 03:30:37 --> Output Class Initialized
DEBUG - 2018-08-02 03:30:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 03:30:37 --> Router Class Initialized
INFO - 2018-08-02 03:30:37 --> Input Class Initialized
INFO - 2018-08-02 03:30:37 --> Security Class Initialized
INFO - 2018-08-02 03:30:37 --> Output Class Initialized
INFO - 2018-08-02 03:30:37 --> Security Class Initialized
INFO - 2018-08-02 03:30:37 --> Language Class Initialized
DEBUG - 2018-08-02 03:30:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 03:30:37 --> Input Class Initialized
ERROR - 2018-08-02 03:30:37 --> 404 Page Not Found: /index
DEBUG - 2018-08-02 03:30:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 03:30:37 --> Input Class Initialized
INFO - 2018-08-02 03:30:37 --> Language Class Initialized
INFO - 2018-08-02 03:30:37 --> Language Class Initialized
INFO - 2018-08-02 03:30:37 --> Language Class Initialized
ERROR - 2018-08-02 03:30:37 --> 404 Page Not Found: /index
INFO - 2018-08-02 03:30:37 --> Config Class Initialized
INFO - 2018-08-02 03:30:37 --> Loader Class Initialized
INFO - 2018-08-02 03:30:37 --> Config Class Initialized
INFO - 2018-08-02 03:30:37 --> Hooks Class Initialized
DEBUG - 2018-08-02 03:30:37 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-02 03:30:37 --> Helper loaded: url_helper
DEBUG - 2018-08-02 03:30:37 --> UTF-8 Support Enabled
INFO - 2018-08-02 03:30:37 --> Utf8 Class Initialized
INFO - 2018-08-02 03:30:37 --> Helper loaded: form_helper
INFO - 2018-08-02 03:30:37 --> URI Class Initialized
INFO - 2018-08-02 03:30:37 --> Helper loaded: date_helper
INFO - 2018-08-02 03:30:37 --> Helper loaded: util_helper
INFO - 2018-08-02 03:30:37 --> Router Class Initialized
INFO - 2018-08-02 03:30:37 --> Output Class Initialized
INFO - 2018-08-02 03:30:37 --> Helper loaded: text_helper
INFO - 2018-08-02 03:30:37 --> Security Class Initialized
INFO - 2018-08-02 03:30:37 --> Helper loaded: string_helper
DEBUG - 2018-08-02 03:30:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 03:30:37 --> Database Driver Class Initialized
INFO - 2018-08-02 03:30:37 --> Input Class Initialized
INFO - 2018-08-02 03:30:37 --> Language Class Initialized
DEBUG - 2018-08-02 03:30:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-02 03:30:37 --> Session: Class initialized using 'files' driver.
ERROR - 2018-08-02 03:30:37 --> 404 Page Not Found: /index
INFO - 2018-08-02 03:30:37 --> Email Class Initialized
INFO - 2018-08-02 03:30:37 --> Config Class Initialized
INFO - 2018-08-02 03:30:37 --> Hooks Class Initialized
INFO - 2018-08-02 03:30:37 --> Controller Class Initialized
DEBUG - 2018-08-02 03:30:37 --> Home MX_Controller Initialized
DEBUG - 2018-08-02 03:30:37 --> UTF-8 Support Enabled
INFO - 2018-08-02 03:30:37 --> Utf8 Class Initialized
DEBUG - 2018-08-02 03:30:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-08-02 03:30:37 --> URI Class Initialized
DEBUG - 2018-08-02 03:30:37 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-02 03:30:37 --> Login MX_Controller Initialized
INFO - 2018-08-02 03:30:37 --> Router Class Initialized
INFO - 2018-08-02 03:30:37 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-02 03:30:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-08-02 03:30:37 --> Output Class Initialized
DEBUG - 2018-08-02 03:30:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-02 03:30:37 --> Security Class Initialized
DEBUG - 2018-08-02 03:30:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 03:30:37 --> Input Class Initialized
INFO - 2018-08-02 03:30:37 --> Language Class Initialized
ERROR - 2018-08-02 03:30:37 --> 404 Page Not Found: /index
INFO - 2018-08-02 03:30:37 --> Config Class Initialized
INFO - 2018-08-02 03:30:37 --> Hooks Class Initialized
DEBUG - 2018-08-02 03:30:37 --> UTF-8 Support Enabled
INFO - 2018-08-02 03:30:37 --> Utf8 Class Initialized
INFO - 2018-08-02 03:30:37 --> URI Class Initialized
INFO - 2018-08-02 03:30:37 --> Router Class Initialized
INFO - 2018-08-02 03:30:37 --> Output Class Initialized
INFO - 2018-08-02 03:30:37 --> Security Class Initialized
DEBUG - 2018-08-02 03:30:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 03:30:38 --> Input Class Initialized
INFO - 2018-08-02 03:30:38 --> Language Class Initialized
ERROR - 2018-08-02 03:30:38 --> 404 Page Not Found: /index
INFO - 2018-08-02 03:30:38 --> Config Class Initialized
INFO - 2018-08-02 03:30:38 --> Hooks Class Initialized
DEBUG - 2018-08-02 03:30:38 --> UTF-8 Support Enabled
INFO - 2018-08-02 03:30:38 --> Utf8 Class Initialized
INFO - 2018-08-02 03:30:38 --> URI Class Initialized
INFO - 2018-08-02 03:30:38 --> Router Class Initialized
INFO - 2018-08-02 03:30:38 --> Output Class Initialized
INFO - 2018-08-02 03:30:38 --> Security Class Initialized
DEBUG - 2018-08-02 03:30:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 03:30:38 --> Input Class Initialized
INFO - 2018-08-02 03:30:38 --> Language Class Initialized
ERROR - 2018-08-02 03:30:38 --> 404 Page Not Found: /index
INFO - 2018-08-02 03:30:38 --> Config Class Initialized
INFO - 2018-08-02 03:30:38 --> Hooks Class Initialized
DEBUG - 2018-08-02 03:30:38 --> UTF-8 Support Enabled
INFO - 2018-08-02 03:30:38 --> Utf8 Class Initialized
INFO - 2018-08-02 03:30:38 --> URI Class Initialized
INFO - 2018-08-02 03:30:38 --> Router Class Initialized
INFO - 2018-08-02 03:30:38 --> Output Class Initialized
INFO - 2018-08-02 03:30:38 --> Security Class Initialized
DEBUG - 2018-08-02 03:30:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 03:30:38 --> Input Class Initialized
INFO - 2018-08-02 03:30:38 --> Language Class Initialized
ERROR - 2018-08-02 03:30:38 --> 404 Page Not Found: /index
INFO - 2018-08-02 03:30:46 --> Config Class Initialized
INFO - 2018-08-02 03:30:46 --> Hooks Class Initialized
DEBUG - 2018-08-02 03:30:46 --> UTF-8 Support Enabled
INFO - 2018-08-02 03:30:46 --> Utf8 Class Initialized
INFO - 2018-08-02 03:30:46 --> URI Class Initialized
INFO - 2018-08-02 03:30:46 --> Router Class Initialized
INFO - 2018-08-02 03:30:46 --> Output Class Initialized
INFO - 2018-08-02 03:30:46 --> Security Class Initialized
DEBUG - 2018-08-02 03:30:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 03:30:46 --> Input Class Initialized
INFO - 2018-08-02 03:30:46 --> Language Class Initialized
INFO - 2018-08-02 03:30:46 --> Language Class Initialized
INFO - 2018-08-02 03:30:46 --> Config Class Initialized
INFO - 2018-08-02 03:30:46 --> Loader Class Initialized
DEBUG - 2018-08-02 03:30:46 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-02 03:30:46 --> Helper loaded: url_helper
INFO - 2018-08-02 03:30:46 --> Helper loaded: form_helper
INFO - 2018-08-02 03:30:46 --> Helper loaded: date_helper
INFO - 2018-08-02 03:30:46 --> Helper loaded: util_helper
INFO - 2018-08-02 03:30:46 --> Helper loaded: text_helper
INFO - 2018-08-02 03:30:46 --> Helper loaded: string_helper
INFO - 2018-08-02 03:30:46 --> Database Driver Class Initialized
DEBUG - 2018-08-02 03:30:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-02 03:30:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-02 03:30:46 --> Email Class Initialized
INFO - 2018-08-02 03:30:46 --> Controller Class Initialized
DEBUG - 2018-08-02 03:30:46 --> Home MX_Controller Initialized
DEBUG - 2018-08-02 03:30:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-02 03:30:46 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-02 03:30:46 --> Login MX_Controller Initialized
INFO - 2018-08-02 03:30:46 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-02 03:30:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-02 03:30:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-02 03:30:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-08-02 03:30:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-08-02 03:30:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-08-02 03:30:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-08-02 03:30:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-08-02 03:30:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-08-02 03:30:47 --> Final output sent to browser
DEBUG - 2018-08-02 03:30:47 --> Total execution time: 0.6638
INFO - 2018-08-02 03:30:47 --> Config Class Initialized
INFO - 2018-08-02 03:30:47 --> Config Class Initialized
INFO - 2018-08-02 03:30:47 --> Hooks Class Initialized
INFO - 2018-08-02 03:30:47 --> Hooks Class Initialized
DEBUG - 2018-08-02 03:30:47 --> UTF-8 Support Enabled
DEBUG - 2018-08-02 03:30:47 --> UTF-8 Support Enabled
INFO - 2018-08-02 03:30:47 --> Config Class Initialized
INFO - 2018-08-02 03:30:47 --> Hooks Class Initialized
INFO - 2018-08-02 03:30:47 --> Utf8 Class Initialized
INFO - 2018-08-02 03:30:47 --> Utf8 Class Initialized
DEBUG - 2018-08-02 03:30:47 --> UTF-8 Support Enabled
INFO - 2018-08-02 03:30:47 --> URI Class Initialized
INFO - 2018-08-02 03:30:47 --> URI Class Initialized
INFO - 2018-08-02 03:30:47 --> Utf8 Class Initialized
INFO - 2018-08-02 03:30:47 --> URI Class Initialized
INFO - 2018-08-02 03:30:47 --> Router Class Initialized
INFO - 2018-08-02 03:30:47 --> Output Class Initialized
INFO - 2018-08-02 03:30:48 --> Router Class Initialized
INFO - 2018-08-02 03:30:48 --> Router Class Initialized
INFO - 2018-08-02 03:30:48 --> Security Class Initialized
INFO - 2018-08-02 03:30:48 --> Output Class Initialized
INFO - 2018-08-02 03:30:48 --> Output Class Initialized
DEBUG - 2018-08-02 03:30:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 03:30:48 --> Input Class Initialized
INFO - 2018-08-02 03:30:48 --> Security Class Initialized
INFO - 2018-08-02 03:30:48 --> Security Class Initialized
INFO - 2018-08-02 03:30:48 --> Language Class Initialized
DEBUG - 2018-08-02 03:30:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-08-02 03:30:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 03:30:48 --> Language Class Initialized
INFO - 2018-08-02 03:30:48 --> Input Class Initialized
INFO - 2018-08-02 03:30:48 --> Language Class Initialized
INFO - 2018-08-02 03:30:48 --> Input Class Initialized
ERROR - 2018-08-02 03:30:48 --> 404 Page Not Found: /index
INFO - 2018-08-02 03:30:48 --> Config Class Initialized
INFO - 2018-08-02 03:30:48 --> Language Class Initialized
ERROR - 2018-08-02 03:30:48 --> 404 Page Not Found: /index
INFO - 2018-08-02 03:30:48 --> Loader Class Initialized
DEBUG - 2018-08-02 03:30:48 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-02 03:30:48 --> Config Class Initialized
INFO - 2018-08-02 03:30:48 --> Hooks Class Initialized
INFO - 2018-08-02 03:30:48 --> Helper loaded: url_helper
INFO - 2018-08-02 03:30:48 --> Helper loaded: form_helper
DEBUG - 2018-08-02 03:30:48 --> UTF-8 Support Enabled
INFO - 2018-08-02 03:30:48 --> Utf8 Class Initialized
INFO - 2018-08-02 03:30:48 --> Helper loaded: date_helper
INFO - 2018-08-02 03:30:48 --> Helper loaded: util_helper
INFO - 2018-08-02 03:30:48 --> URI Class Initialized
INFO - 2018-08-02 03:30:48 --> Router Class Initialized
INFO - 2018-08-02 03:30:48 --> Helper loaded: text_helper
INFO - 2018-08-02 03:30:48 --> Helper loaded: string_helper
INFO - 2018-08-02 03:30:48 --> Output Class Initialized
INFO - 2018-08-02 03:30:48 --> Security Class Initialized
INFO - 2018-08-02 03:30:48 --> Database Driver Class Initialized
DEBUG - 2018-08-02 03:30:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-08-02 03:30:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-02 03:30:48 --> Input Class Initialized
INFO - 2018-08-02 03:30:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-02 03:30:48 --> Language Class Initialized
INFO - 2018-08-02 03:30:48 --> Email Class Initialized
INFO - 2018-08-02 03:30:48 --> Controller Class Initialized
ERROR - 2018-08-02 03:30:48 --> 404 Page Not Found: /index
DEBUG - 2018-08-02 03:30:48 --> Home MX_Controller Initialized
INFO - 2018-08-02 03:30:48 --> Config Class Initialized
DEBUG - 2018-08-02 03:30:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-08-02 03:30:48 --> Hooks Class Initialized
DEBUG - 2018-08-02 03:30:48 --> UTF-8 Support Enabled
DEBUG - 2018-08-02 03:30:48 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-02 03:30:48 --> Login MX_Controller Initialized
INFO - 2018-08-02 03:30:48 --> Utf8 Class Initialized
INFO - 2018-08-02 03:30:48 --> Language file loaded: language/english/data_lang.php
INFO - 2018-08-02 03:30:48 --> URI Class Initialized
DEBUG - 2018-08-02 03:30:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-08-02 03:30:48 --> Router Class Initialized
DEBUG - 2018-08-02 03:30:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-02 03:30:48 --> Output Class Initialized
INFO - 2018-08-02 03:30:48 --> Security Class Initialized
DEBUG - 2018-08-02 03:30:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 03:30:48 --> Input Class Initialized
INFO - 2018-08-02 03:30:48 --> Language Class Initialized
ERROR - 2018-08-02 03:30:48 --> 404 Page Not Found: /index
INFO - 2018-08-02 03:30:48 --> Config Class Initialized
INFO - 2018-08-02 03:30:48 --> Hooks Class Initialized
DEBUG - 2018-08-02 03:30:48 --> UTF-8 Support Enabled
INFO - 2018-08-02 03:30:48 --> Utf8 Class Initialized
INFO - 2018-08-02 03:30:48 --> URI Class Initialized
INFO - 2018-08-02 03:30:48 --> Router Class Initialized
INFO - 2018-08-02 03:30:48 --> Output Class Initialized
INFO - 2018-08-02 03:30:48 --> Security Class Initialized
DEBUG - 2018-08-02 03:30:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 03:30:48 --> Input Class Initialized
INFO - 2018-08-02 03:30:48 --> Language Class Initialized
ERROR - 2018-08-02 03:30:48 --> 404 Page Not Found: /index
INFO - 2018-08-02 03:30:48 --> Config Class Initialized
INFO - 2018-08-02 03:30:48 --> Hooks Class Initialized
DEBUG - 2018-08-02 03:30:48 --> UTF-8 Support Enabled
INFO - 2018-08-02 03:30:48 --> Utf8 Class Initialized
INFO - 2018-08-02 03:30:48 --> URI Class Initialized
INFO - 2018-08-02 03:30:48 --> Router Class Initialized
INFO - 2018-08-02 03:30:48 --> Output Class Initialized
INFO - 2018-08-02 03:30:48 --> Security Class Initialized
DEBUG - 2018-08-02 03:30:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 03:30:49 --> Input Class Initialized
INFO - 2018-08-02 03:30:49 --> Language Class Initialized
ERROR - 2018-08-02 03:30:49 --> 404 Page Not Found: /index
INFO - 2018-08-02 03:30:49 --> Config Class Initialized
INFO - 2018-08-02 03:30:49 --> Hooks Class Initialized
DEBUG - 2018-08-02 03:30:49 --> UTF-8 Support Enabled
INFO - 2018-08-02 03:30:49 --> Utf8 Class Initialized
INFO - 2018-08-02 03:30:49 --> URI Class Initialized
INFO - 2018-08-02 03:30:49 --> Router Class Initialized
INFO - 2018-08-02 03:30:49 --> Output Class Initialized
INFO - 2018-08-02 03:30:49 --> Security Class Initialized
DEBUG - 2018-08-02 03:30:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 03:30:49 --> Input Class Initialized
INFO - 2018-08-02 03:30:49 --> Language Class Initialized
ERROR - 2018-08-02 03:30:49 --> 404 Page Not Found: /index
INFO - 2018-08-02 03:30:51 --> Config Class Initialized
INFO - 2018-08-02 03:30:51 --> Hooks Class Initialized
DEBUG - 2018-08-02 03:30:51 --> UTF-8 Support Enabled
INFO - 2018-08-02 03:30:51 --> Utf8 Class Initialized
INFO - 2018-08-02 03:30:51 --> URI Class Initialized
INFO - 2018-08-02 03:30:51 --> Router Class Initialized
INFO - 2018-08-02 03:30:51 --> Output Class Initialized
INFO - 2018-08-02 03:30:51 --> Security Class Initialized
DEBUG - 2018-08-02 03:30:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 03:30:51 --> Input Class Initialized
INFO - 2018-08-02 03:30:51 --> Language Class Initialized
INFO - 2018-08-02 03:30:51 --> Language Class Initialized
INFO - 2018-08-02 03:30:51 --> Config Class Initialized
INFO - 2018-08-02 03:30:51 --> Loader Class Initialized
DEBUG - 2018-08-02 03:30:51 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-02 03:30:51 --> Helper loaded: url_helper
INFO - 2018-08-02 03:30:51 --> Helper loaded: form_helper
INFO - 2018-08-02 03:30:51 --> Helper loaded: date_helper
INFO - 2018-08-02 03:30:51 --> Helper loaded: util_helper
INFO - 2018-08-02 03:30:51 --> Helper loaded: text_helper
INFO - 2018-08-02 03:30:51 --> Helper loaded: string_helper
INFO - 2018-08-02 03:30:51 --> Database Driver Class Initialized
DEBUG - 2018-08-02 03:30:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-02 03:30:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-02 03:30:51 --> Email Class Initialized
INFO - 2018-08-02 03:30:51 --> Controller Class Initialized
DEBUG - 2018-08-02 03:30:51 --> Login MX_Controller Initialized
INFO - 2018-08-02 03:30:51 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-02 03:30:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-02 03:30:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-02 03:30:51 --> 4 Loggedout
INFO - 2018-08-02 03:30:51 --> Config Class Initialized
INFO - 2018-08-02 03:30:51 --> Hooks Class Initialized
DEBUG - 2018-08-02 03:30:51 --> UTF-8 Support Enabled
INFO - 2018-08-02 03:30:51 --> Utf8 Class Initialized
INFO - 2018-08-02 03:30:51 --> URI Class Initialized
INFO - 2018-08-02 03:30:51 --> Router Class Initialized
INFO - 2018-08-02 03:30:51 --> Output Class Initialized
INFO - 2018-08-02 03:30:51 --> Security Class Initialized
DEBUG - 2018-08-02 03:30:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 03:30:51 --> Input Class Initialized
INFO - 2018-08-02 03:30:51 --> Language Class Initialized
INFO - 2018-08-02 03:30:51 --> Language Class Initialized
INFO - 2018-08-02 03:30:51 --> Config Class Initialized
INFO - 2018-08-02 03:30:51 --> Loader Class Initialized
DEBUG - 2018-08-02 03:30:51 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-02 03:30:51 --> Helper loaded: url_helper
INFO - 2018-08-02 03:30:51 --> Helper loaded: form_helper
INFO - 2018-08-02 03:30:51 --> Helper loaded: date_helper
INFO - 2018-08-02 03:30:51 --> Helper loaded: util_helper
INFO - 2018-08-02 03:30:51 --> Helper loaded: text_helper
INFO - 2018-08-02 03:30:51 --> Helper loaded: string_helper
INFO - 2018-08-02 03:30:51 --> Database Driver Class Initialized
DEBUG - 2018-08-02 03:30:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-02 03:30:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-02 03:30:51 --> Email Class Initialized
INFO - 2018-08-02 03:30:51 --> Controller Class Initialized
DEBUG - 2018-08-02 03:30:51 --> Home MX_Controller Initialized
DEBUG - 2018-08-02 03:30:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-02 03:30:51 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-02 03:30:51 --> Login MX_Controller Initialized
INFO - 2018-08-02 03:30:51 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-02 03:30:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-02 03:30:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-02 03:30:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/login.php
INFO - 2018-08-02 03:30:55 --> Config Class Initialized
INFO - 2018-08-02 03:30:55 --> Hooks Class Initialized
DEBUG - 2018-08-02 03:30:55 --> UTF-8 Support Enabled
INFO - 2018-08-02 03:30:55 --> Utf8 Class Initialized
INFO - 2018-08-02 03:30:55 --> URI Class Initialized
INFO - 2018-08-02 03:30:55 --> Router Class Initialized
INFO - 2018-08-02 03:30:55 --> Output Class Initialized
INFO - 2018-08-02 03:30:55 --> Security Class Initialized
DEBUG - 2018-08-02 03:30:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 03:30:55 --> Input Class Initialized
INFO - 2018-08-02 03:30:55 --> Language Class Initialized
INFO - 2018-08-02 03:30:55 --> Language Class Initialized
INFO - 2018-08-02 03:30:55 --> Config Class Initialized
INFO - 2018-08-02 03:30:55 --> Loader Class Initialized
DEBUG - 2018-08-02 03:30:55 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-02 03:30:55 --> Helper loaded: url_helper
INFO - 2018-08-02 03:30:55 --> Helper loaded: form_helper
INFO - 2018-08-02 03:30:55 --> Helper loaded: date_helper
INFO - 2018-08-02 03:30:55 --> Helper loaded: util_helper
INFO - 2018-08-02 03:30:55 --> Helper loaded: text_helper
INFO - 2018-08-02 03:30:55 --> Helper loaded: string_helper
INFO - 2018-08-02 03:30:55 --> Database Driver Class Initialized
DEBUG - 2018-08-02 03:30:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-02 03:30:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-02 03:30:56 --> Email Class Initialized
INFO - 2018-08-02 03:30:56 --> Controller Class Initialized
DEBUG - 2018-08-02 03:30:56 --> Login MX_Controller Initialized
INFO - 2018-08-02 03:30:56 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-02 03:30:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-02 03:30:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-02 03:30:56 --> Email starts for colinUser fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-08-02 03:30:56 --> User session created for 4
INFO - 2018-08-02 03:30:56 --> Login status colinUser - success
INFO - 2018-08-02 03:30:56 --> Final output sent to browser
DEBUG - 2018-08-02 03:30:56 --> Total execution time: 0.6669
INFO - 2018-08-02 03:30:56 --> Config Class Initialized
INFO - 2018-08-02 03:30:56 --> Hooks Class Initialized
DEBUG - 2018-08-02 03:30:56 --> UTF-8 Support Enabled
INFO - 2018-08-02 03:30:56 --> Utf8 Class Initialized
INFO - 2018-08-02 03:30:56 --> URI Class Initialized
INFO - 2018-08-02 03:30:56 --> Router Class Initialized
INFO - 2018-08-02 03:30:56 --> Output Class Initialized
INFO - 2018-08-02 03:30:56 --> Security Class Initialized
DEBUG - 2018-08-02 03:30:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 03:30:56 --> Input Class Initialized
INFO - 2018-08-02 03:30:56 --> Language Class Initialized
INFO - 2018-08-02 03:30:56 --> Language Class Initialized
INFO - 2018-08-02 03:30:56 --> Config Class Initialized
INFO - 2018-08-02 03:30:56 --> Loader Class Initialized
DEBUG - 2018-08-02 03:30:56 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-02 03:30:56 --> Helper loaded: url_helper
INFO - 2018-08-02 03:30:56 --> Helper loaded: form_helper
INFO - 2018-08-02 03:30:56 --> Helper loaded: date_helper
INFO - 2018-08-02 03:30:56 --> Helper loaded: util_helper
INFO - 2018-08-02 03:30:56 --> Helper loaded: text_helper
INFO - 2018-08-02 03:30:56 --> Helper loaded: string_helper
INFO - 2018-08-02 03:30:56 --> Database Driver Class Initialized
DEBUG - 2018-08-02 03:30:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-02 03:30:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-02 03:30:56 --> Email Class Initialized
INFO - 2018-08-02 03:30:56 --> Controller Class Initialized
DEBUG - 2018-08-02 03:30:56 --> Home MX_Controller Initialized
DEBUG - 2018-08-02 03:30:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-02 03:30:57 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-02 03:30:57 --> Login MX_Controller Initialized
INFO - 2018-08-02 03:30:57 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-02 03:30:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-02 03:30:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-02 03:30:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-08-02 03:30:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-08-02 03:30:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-08-02 03:30:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-08-02 03:30:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-08-02 03:30:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-08-02 03:30:57 --> Final output sent to browser
DEBUG - 2018-08-02 03:30:57 --> Total execution time: 0.7924
INFO - 2018-08-02 03:30:57 --> Config Class Initialized
INFO - 2018-08-02 03:30:57 --> Hooks Class Initialized
DEBUG - 2018-08-02 03:30:57 --> UTF-8 Support Enabled
INFO - 2018-08-02 03:30:57 --> Utf8 Class Initialized
INFO - 2018-08-02 03:30:57 --> Config Class Initialized
INFO - 2018-08-02 03:30:57 --> Hooks Class Initialized
INFO - 2018-08-02 03:30:57 --> URI Class Initialized
DEBUG - 2018-08-02 03:30:57 --> UTF-8 Support Enabled
INFO - 2018-08-02 03:30:57 --> Utf8 Class Initialized
INFO - 2018-08-02 03:30:57 --> URI Class Initialized
INFO - 2018-08-02 03:30:57 --> Router Class Initialized
INFO - 2018-08-02 03:30:58 --> Output Class Initialized
INFO - 2018-08-02 03:30:58 --> Security Class Initialized
INFO - 2018-08-02 03:30:58 --> Router Class Initialized
INFO - 2018-08-02 03:30:58 --> Output Class Initialized
DEBUG - 2018-08-02 03:30:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 03:30:58 --> Input Class Initialized
INFO - 2018-08-02 03:30:58 --> Security Class Initialized
INFO - 2018-08-02 03:30:58 --> Language Class Initialized
DEBUG - 2018-08-02 03:30:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 03:30:58 --> Input Class Initialized
INFO - 2018-08-02 03:30:58 --> Language Class Initialized
INFO - 2018-08-02 03:30:58 --> Language Class Initialized
ERROR - 2018-08-02 03:30:58 --> 404 Page Not Found: /index
INFO - 2018-08-02 03:30:58 --> Config Class Initialized
INFO - 2018-08-02 03:30:58 --> Config Class Initialized
INFO - 2018-08-02 03:30:58 --> Hooks Class Initialized
INFO - 2018-08-02 03:30:58 --> Loader Class Initialized
DEBUG - 2018-08-02 03:30:58 --> UTF-8 Support Enabled
DEBUG - 2018-08-02 03:30:58 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-02 03:30:58 --> Utf8 Class Initialized
INFO - 2018-08-02 03:30:58 --> URI Class Initialized
INFO - 2018-08-02 03:30:58 --> Helper loaded: url_helper
INFO - 2018-08-02 03:30:58 --> Router Class Initialized
INFO - 2018-08-02 03:30:58 --> Helper loaded: form_helper
INFO - 2018-08-02 03:30:58 --> Output Class Initialized
INFO - 2018-08-02 03:30:58 --> Helper loaded: date_helper
INFO - 2018-08-02 03:30:58 --> Security Class Initialized
DEBUG - 2018-08-02 03:30:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 03:30:58 --> Helper loaded: util_helper
INFO - 2018-08-02 03:30:58 --> Input Class Initialized
INFO - 2018-08-02 03:30:58 --> Helper loaded: text_helper
INFO - 2018-08-02 03:30:58 --> Helper loaded: string_helper
INFO - 2018-08-02 03:30:58 --> Language Class Initialized
INFO - 2018-08-02 03:30:58 --> Database Driver Class Initialized
ERROR - 2018-08-02 03:30:58 --> 404 Page Not Found: /index
DEBUG - 2018-08-02 03:30:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-02 03:30:58 --> Config Class Initialized
INFO - 2018-08-02 03:30:58 --> Hooks Class Initialized
INFO - 2018-08-02 03:30:58 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-08-02 03:30:58 --> UTF-8 Support Enabled
INFO - 2018-08-02 03:30:58 --> Email Class Initialized
INFO - 2018-08-02 03:30:58 --> Utf8 Class Initialized
INFO - 2018-08-02 03:30:58 --> URI Class Initialized
INFO - 2018-08-02 03:30:58 --> Controller Class Initialized
INFO - 2018-08-02 03:30:58 --> Router Class Initialized
DEBUG - 2018-08-02 03:30:58 --> Home MX_Controller Initialized
INFO - 2018-08-02 03:30:58 --> Output Class Initialized
INFO - 2018-08-02 03:30:58 --> Security Class Initialized
DEBUG - 2018-08-02 03:30:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-02 03:30:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 03:30:58 --> Input Class Initialized
DEBUG - 2018-08-02 03:30:58 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-02 03:30:58 --> Login MX_Controller Initialized
INFO - 2018-08-02 03:30:58 --> Language Class Initialized
INFO - 2018-08-02 03:30:58 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-02 03:30:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-02 03:30:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
ERROR - 2018-08-02 03:30:59 --> 404 Page Not Found: /index
INFO - 2018-08-02 03:30:59 --> Config Class Initialized
INFO - 2018-08-02 03:30:59 --> Hooks Class Initialized
DEBUG - 2018-08-02 03:30:59 --> UTF-8 Support Enabled
INFO - 2018-08-02 03:30:59 --> Utf8 Class Initialized
INFO - 2018-08-02 03:30:59 --> URI Class Initialized
INFO - 2018-08-02 03:30:59 --> Router Class Initialized
INFO - 2018-08-02 03:30:59 --> Output Class Initialized
INFO - 2018-08-02 03:30:59 --> Security Class Initialized
DEBUG - 2018-08-02 03:30:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 03:30:59 --> Input Class Initialized
INFO - 2018-08-02 03:30:59 --> Language Class Initialized
ERROR - 2018-08-02 03:30:59 --> 404 Page Not Found: /index
INFO - 2018-08-02 03:30:59 --> Config Class Initialized
INFO - 2018-08-02 03:30:59 --> Hooks Class Initialized
DEBUG - 2018-08-02 03:30:59 --> UTF-8 Support Enabled
INFO - 2018-08-02 03:30:59 --> Utf8 Class Initialized
INFO - 2018-08-02 03:30:59 --> URI Class Initialized
INFO - 2018-08-02 03:30:59 --> Router Class Initialized
INFO - 2018-08-02 03:30:59 --> Output Class Initialized
INFO - 2018-08-02 03:30:59 --> Security Class Initialized
DEBUG - 2018-08-02 03:30:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 03:30:59 --> Input Class Initialized
INFO - 2018-08-02 03:30:59 --> Language Class Initialized
ERROR - 2018-08-02 03:30:59 --> 404 Page Not Found: /index
INFO - 2018-08-02 03:30:59 --> Config Class Initialized
INFO - 2018-08-02 03:30:59 --> Hooks Class Initialized
DEBUG - 2018-08-02 03:30:59 --> UTF-8 Support Enabled
INFO - 2018-08-02 03:30:59 --> Utf8 Class Initialized
INFO - 2018-08-02 03:30:59 --> URI Class Initialized
INFO - 2018-08-02 03:30:59 --> Router Class Initialized
INFO - 2018-08-02 03:30:59 --> Output Class Initialized
INFO - 2018-08-02 03:30:59 --> Security Class Initialized
DEBUG - 2018-08-02 03:30:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 03:30:59 --> Input Class Initialized
INFO - 2018-08-02 03:30:59 --> Language Class Initialized
ERROR - 2018-08-02 03:30:59 --> 404 Page Not Found: /index
INFO - 2018-08-02 03:30:59 --> Config Class Initialized
INFO - 2018-08-02 03:30:59 --> Hooks Class Initialized
DEBUG - 2018-08-02 03:30:59 --> UTF-8 Support Enabled
INFO - 2018-08-02 03:30:59 --> Utf8 Class Initialized
INFO - 2018-08-02 03:30:59 --> URI Class Initialized
INFO - 2018-08-02 03:30:59 --> Router Class Initialized
INFO - 2018-08-02 03:30:59 --> Output Class Initialized
INFO - 2018-08-02 03:30:59 --> Security Class Initialized
DEBUG - 2018-08-02 03:30:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 03:30:59 --> Input Class Initialized
INFO - 2018-08-02 03:30:59 --> Language Class Initialized
ERROR - 2018-08-02 03:30:59 --> 404 Page Not Found: /index
INFO - 2018-08-02 03:31:34 --> Config Class Initialized
INFO - 2018-08-02 03:31:34 --> Hooks Class Initialized
DEBUG - 2018-08-02 03:31:34 --> UTF-8 Support Enabled
INFO - 2018-08-02 03:31:34 --> Utf8 Class Initialized
INFO - 2018-08-02 03:31:34 --> URI Class Initialized
INFO - 2018-08-02 03:31:34 --> Router Class Initialized
INFO - 2018-08-02 03:31:34 --> Output Class Initialized
INFO - 2018-08-02 03:31:34 --> Security Class Initialized
DEBUG - 2018-08-02 03:31:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 03:31:34 --> Input Class Initialized
INFO - 2018-08-02 03:31:34 --> Language Class Initialized
INFO - 2018-08-02 03:31:34 --> Language Class Initialized
INFO - 2018-08-02 03:31:34 --> Config Class Initialized
INFO - 2018-08-02 03:31:35 --> Loader Class Initialized
DEBUG - 2018-08-02 03:31:35 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-02 03:31:35 --> Helper loaded: url_helper
INFO - 2018-08-02 03:31:35 --> Helper loaded: form_helper
INFO - 2018-08-02 03:31:35 --> Helper loaded: date_helper
INFO - 2018-08-02 03:31:35 --> Helper loaded: util_helper
INFO - 2018-08-02 03:31:35 --> Helper loaded: text_helper
INFO - 2018-08-02 03:31:35 --> Helper loaded: string_helper
INFO - 2018-08-02 03:31:35 --> Database Driver Class Initialized
DEBUG - 2018-08-02 03:31:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-02 03:31:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-02 03:31:35 --> Email Class Initialized
INFO - 2018-08-02 03:31:35 --> Controller Class Initialized
DEBUG - 2018-08-02 03:31:35 --> Home MX_Controller Initialized
DEBUG - 2018-08-02 03:31:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-02 03:31:35 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-02 03:31:35 --> Login MX_Controller Initialized
INFO - 2018-08-02 03:31:35 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-02 03:31:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-02 03:31:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-02 03:31:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-08-02 03:31:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-08-02 03:31:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-08-02 03:31:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-08-02 03:31:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-08-02 03:31:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-08-02 03:31:35 --> Final output sent to browser
DEBUG - 2018-08-02 03:31:35 --> Total execution time: 0.5443
INFO - 2018-08-02 03:31:36 --> Config Class Initialized
INFO - 2018-08-02 03:31:36 --> Hooks Class Initialized
DEBUG - 2018-08-02 03:31:36 --> UTF-8 Support Enabled
INFO - 2018-08-02 03:31:36 --> Config Class Initialized
INFO - 2018-08-02 03:31:36 --> Hooks Class Initialized
INFO - 2018-08-02 03:31:36 --> Utf8 Class Initialized
DEBUG - 2018-08-02 03:31:36 --> UTF-8 Support Enabled
INFO - 2018-08-02 03:31:36 --> Utf8 Class Initialized
INFO - 2018-08-02 03:31:36 --> URI Class Initialized
INFO - 2018-08-02 03:31:36 --> URI Class Initialized
INFO - 2018-08-02 03:31:36 --> Router Class Initialized
INFO - 2018-08-02 03:31:36 --> Output Class Initialized
INFO - 2018-08-02 03:31:36 --> Security Class Initialized
DEBUG - 2018-08-02 03:31:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 03:31:36 --> Input Class Initialized
INFO - 2018-08-02 03:31:36 --> Language Class Initialized
INFO - 2018-08-02 03:31:36 --> Router Class Initialized
INFO - 2018-08-02 03:31:36 --> Output Class Initialized
INFO - 2018-08-02 03:31:36 --> Language Class Initialized
INFO - 2018-08-02 03:31:36 --> Config Class Initialized
INFO - 2018-08-02 03:31:36 --> Security Class Initialized
DEBUG - 2018-08-02 03:31:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 03:31:36 --> Loader Class Initialized
INFO - 2018-08-02 03:31:36 --> Input Class Initialized
DEBUG - 2018-08-02 03:31:36 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-02 03:31:36 --> Helper loaded: url_helper
INFO - 2018-08-02 03:31:36 --> Language Class Initialized
INFO - 2018-08-02 03:31:36 --> Helper loaded: form_helper
ERROR - 2018-08-02 03:31:36 --> 404 Page Not Found: /index
INFO - 2018-08-02 03:31:36 --> Helper loaded: date_helper
INFO - 2018-08-02 03:31:36 --> Config Class Initialized
INFO - 2018-08-02 03:31:36 --> Helper loaded: util_helper
INFO - 2018-08-02 03:31:36 --> Hooks Class Initialized
INFO - 2018-08-02 03:31:36 --> Helper loaded: text_helper
DEBUG - 2018-08-02 03:31:36 --> UTF-8 Support Enabled
INFO - 2018-08-02 03:31:36 --> Utf8 Class Initialized
INFO - 2018-08-02 03:31:36 --> Helper loaded: string_helper
INFO - 2018-08-02 03:31:36 --> URI Class Initialized
INFO - 2018-08-02 03:31:36 --> Database Driver Class Initialized
INFO - 2018-08-02 03:31:36 --> Router Class Initialized
DEBUG - 2018-08-02 03:31:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-02 03:31:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-02 03:31:36 --> Output Class Initialized
INFO - 2018-08-02 03:31:36 --> Email Class Initialized
INFO - 2018-08-02 03:31:36 --> Security Class Initialized
INFO - 2018-08-02 03:31:36 --> Controller Class Initialized
DEBUG - 2018-08-02 03:31:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-08-02 03:31:36 --> Home MX_Controller Initialized
INFO - 2018-08-02 03:31:36 --> Input Class Initialized
DEBUG - 2018-08-02 03:31:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-08-02 03:31:36 --> Language Class Initialized
ERROR - 2018-08-02 03:31:36 --> 404 Page Not Found: /index
DEBUG - 2018-08-02 03:31:36 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-02 03:31:36 --> Login MX_Controller Initialized
INFO - 2018-08-02 03:31:36 --> Config Class Initialized
INFO - 2018-08-02 03:31:36 --> Language file loaded: language/english/data_lang.php
INFO - 2018-08-02 03:31:36 --> Hooks Class Initialized
DEBUG - 2018-08-02 03:31:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-02 03:31:36 --> UTF-8 Support Enabled
DEBUG - 2018-08-02 03:31:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-02 03:31:36 --> Utf8 Class Initialized
INFO - 2018-08-02 03:31:36 --> URI Class Initialized
INFO - 2018-08-02 03:31:36 --> Router Class Initialized
INFO - 2018-08-02 03:31:36 --> Output Class Initialized
INFO - 2018-08-02 03:31:37 --> Security Class Initialized
DEBUG - 2018-08-02 03:31:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 03:31:37 --> Input Class Initialized
INFO - 2018-08-02 03:31:37 --> Language Class Initialized
ERROR - 2018-08-02 03:31:37 --> 404 Page Not Found: /index
INFO - 2018-08-02 03:31:37 --> Config Class Initialized
INFO - 2018-08-02 03:31:37 --> Hooks Class Initialized
DEBUG - 2018-08-02 03:31:37 --> UTF-8 Support Enabled
INFO - 2018-08-02 03:31:37 --> Utf8 Class Initialized
INFO - 2018-08-02 03:31:37 --> URI Class Initialized
INFO - 2018-08-02 03:31:37 --> Router Class Initialized
INFO - 2018-08-02 03:31:37 --> Output Class Initialized
INFO - 2018-08-02 03:31:37 --> Security Class Initialized
DEBUG - 2018-08-02 03:31:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 03:31:37 --> Input Class Initialized
INFO - 2018-08-02 03:31:37 --> Language Class Initialized
ERROR - 2018-08-02 03:31:37 --> 404 Page Not Found: /index
INFO - 2018-08-02 03:31:37 --> Config Class Initialized
INFO - 2018-08-02 03:31:37 --> Hooks Class Initialized
DEBUG - 2018-08-02 03:31:37 --> UTF-8 Support Enabled
INFO - 2018-08-02 03:31:37 --> Utf8 Class Initialized
INFO - 2018-08-02 03:31:37 --> URI Class Initialized
INFO - 2018-08-02 03:31:37 --> Router Class Initialized
INFO - 2018-08-02 03:31:37 --> Output Class Initialized
INFO - 2018-08-02 03:31:37 --> Security Class Initialized
DEBUG - 2018-08-02 03:31:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 03:31:37 --> Input Class Initialized
INFO - 2018-08-02 03:31:37 --> Language Class Initialized
ERROR - 2018-08-02 03:31:37 --> 404 Page Not Found: /index
INFO - 2018-08-02 03:31:37 --> Config Class Initialized
INFO - 2018-08-02 03:31:37 --> Hooks Class Initialized
DEBUG - 2018-08-02 03:31:37 --> UTF-8 Support Enabled
INFO - 2018-08-02 03:31:37 --> Utf8 Class Initialized
INFO - 2018-08-02 03:31:37 --> URI Class Initialized
INFO - 2018-08-02 03:31:37 --> Router Class Initialized
INFO - 2018-08-02 03:31:37 --> Output Class Initialized
INFO - 2018-08-02 03:31:37 --> Security Class Initialized
DEBUG - 2018-08-02 03:31:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 03:31:37 --> Input Class Initialized
INFO - 2018-08-02 03:31:37 --> Language Class Initialized
ERROR - 2018-08-02 03:31:37 --> 404 Page Not Found: /index
INFO - 2018-08-02 03:31:51 --> Config Class Initialized
INFO - 2018-08-02 03:31:51 --> Hooks Class Initialized
DEBUG - 2018-08-02 03:31:51 --> UTF-8 Support Enabled
INFO - 2018-08-02 03:31:51 --> Utf8 Class Initialized
INFO - 2018-08-02 03:31:51 --> URI Class Initialized
INFO - 2018-08-02 03:31:51 --> Router Class Initialized
INFO - 2018-08-02 03:31:51 --> Output Class Initialized
INFO - 2018-08-02 03:31:51 --> Security Class Initialized
DEBUG - 2018-08-02 03:31:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 03:31:51 --> Input Class Initialized
INFO - 2018-08-02 03:31:51 --> Language Class Initialized
INFO - 2018-08-02 03:31:51 --> Language Class Initialized
INFO - 2018-08-02 03:31:51 --> Config Class Initialized
INFO - 2018-08-02 03:31:51 --> Loader Class Initialized
DEBUG - 2018-08-02 03:31:51 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-02 03:31:51 --> Helper loaded: url_helper
INFO - 2018-08-02 03:31:51 --> Helper loaded: form_helper
INFO - 2018-08-02 03:31:51 --> Helper loaded: date_helper
INFO - 2018-08-02 03:31:52 --> Helper loaded: util_helper
INFO - 2018-08-02 03:31:52 --> Helper loaded: text_helper
INFO - 2018-08-02 03:31:52 --> Helper loaded: string_helper
INFO - 2018-08-02 03:31:52 --> Database Driver Class Initialized
DEBUG - 2018-08-02 03:31:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-02 03:31:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-02 03:31:52 --> Email Class Initialized
INFO - 2018-08-02 03:31:52 --> Controller Class Initialized
DEBUG - 2018-08-02 03:31:52 --> Home MX_Controller Initialized
DEBUG - 2018-08-02 03:31:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-02 03:31:52 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-02 03:31:52 --> Login MX_Controller Initialized
INFO - 2018-08-02 03:31:52 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-02 03:31:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-02 03:31:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-02 03:31:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-08-02 03:31:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-08-02 03:31:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-08-02 03:31:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-08-02 03:31:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-08-02 03:31:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-08-02 03:31:52 --> Final output sent to browser
DEBUG - 2018-08-02 03:31:52 --> Total execution time: 0.8172
INFO - 2018-08-02 03:31:53 --> Config Class Initialized
INFO - 2018-08-02 03:31:53 --> Hooks Class Initialized
DEBUG - 2018-08-02 03:31:53 --> UTF-8 Support Enabled
INFO - 2018-08-02 03:31:53 --> Config Class Initialized
INFO - 2018-08-02 03:31:53 --> Hooks Class Initialized
INFO - 2018-08-02 03:31:53 --> Utf8 Class Initialized
INFO - 2018-08-02 03:31:53 --> URI Class Initialized
DEBUG - 2018-08-02 03:31:53 --> UTF-8 Support Enabled
INFO - 2018-08-02 03:31:53 --> Utf8 Class Initialized
INFO - 2018-08-02 03:31:53 --> Router Class Initialized
INFO - 2018-08-02 03:31:53 --> URI Class Initialized
INFO - 2018-08-02 03:31:53 --> Output Class Initialized
INFO - 2018-08-02 03:31:53 --> Security Class Initialized
DEBUG - 2018-08-02 03:31:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 03:31:53 --> Input Class Initialized
INFO - 2018-08-02 03:31:53 --> Language Class Initialized
ERROR - 2018-08-02 03:31:53 --> 404 Page Not Found: /index
INFO - 2018-08-02 03:31:53 --> Router Class Initialized
INFO - 2018-08-02 03:31:53 --> Config Class Initialized
INFO - 2018-08-02 03:31:53 --> Hooks Class Initialized
INFO - 2018-08-02 03:31:53 --> Output Class Initialized
DEBUG - 2018-08-02 03:31:53 --> UTF-8 Support Enabled
INFO - 2018-08-02 03:31:53 --> Utf8 Class Initialized
INFO - 2018-08-02 03:31:53 --> Security Class Initialized
INFO - 2018-08-02 03:31:53 --> URI Class Initialized
DEBUG - 2018-08-02 03:31:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 03:31:53 --> Router Class Initialized
INFO - 2018-08-02 03:31:53 --> Output Class Initialized
INFO - 2018-08-02 03:31:53 --> Input Class Initialized
INFO - 2018-08-02 03:31:53 --> Security Class Initialized
INFO - 2018-08-02 03:31:53 --> Language Class Initialized
INFO - 2018-08-02 03:31:53 --> Language Class Initialized
DEBUG - 2018-08-02 03:31:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 03:31:53 --> Config Class Initialized
INFO - 2018-08-02 03:31:53 --> Input Class Initialized
INFO - 2018-08-02 03:31:53 --> Language Class Initialized
INFO - 2018-08-02 03:31:53 --> Loader Class Initialized
ERROR - 2018-08-02 03:31:53 --> 404 Page Not Found: /index
DEBUG - 2018-08-02 03:31:53 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-02 03:31:53 --> Helper loaded: url_helper
INFO - 2018-08-02 03:31:53 --> Config Class Initialized
INFO - 2018-08-02 03:31:53 --> Hooks Class Initialized
INFO - 2018-08-02 03:31:53 --> Helper loaded: form_helper
DEBUG - 2018-08-02 03:31:53 --> UTF-8 Support Enabled
INFO - 2018-08-02 03:31:53 --> Utf8 Class Initialized
INFO - 2018-08-02 03:31:53 --> URI Class Initialized
INFO - 2018-08-02 03:31:53 --> Helper loaded: date_helper
INFO - 2018-08-02 03:31:53 --> Router Class Initialized
INFO - 2018-08-02 03:31:54 --> Helper loaded: util_helper
INFO - 2018-08-02 03:31:54 --> Output Class Initialized
INFO - 2018-08-02 03:31:54 --> Helper loaded: text_helper
INFO - 2018-08-02 03:31:54 --> Security Class Initialized
DEBUG - 2018-08-02 03:31:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 03:31:54 --> Helper loaded: string_helper
INFO - 2018-08-02 03:31:54 --> Input Class Initialized
INFO - 2018-08-02 03:31:54 --> Database Driver Class Initialized
INFO - 2018-08-02 03:31:54 --> Language Class Initialized
DEBUG - 2018-08-02 03:31:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-02 03:31:54 --> Session: Class initialized using 'files' driver.
ERROR - 2018-08-02 03:31:54 --> 404 Page Not Found: /index
INFO - 2018-08-02 03:31:54 --> Email Class Initialized
INFO - 2018-08-02 03:31:54 --> Config Class Initialized
INFO - 2018-08-02 03:31:54 --> Hooks Class Initialized
INFO - 2018-08-02 03:31:54 --> Controller Class Initialized
DEBUG - 2018-08-02 03:31:54 --> Home MX_Controller Initialized
DEBUG - 2018-08-02 03:31:54 --> UTF-8 Support Enabled
INFO - 2018-08-02 03:31:54 --> Utf8 Class Initialized
DEBUG - 2018-08-02 03:31:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-08-02 03:31:54 --> URI Class Initialized
DEBUG - 2018-08-02 03:31:54 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-02 03:31:54 --> Login MX_Controller Initialized
INFO - 2018-08-02 03:31:54 --> Router Class Initialized
INFO - 2018-08-02 03:31:54 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-02 03:31:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-08-02 03:31:54 --> Output Class Initialized
INFO - 2018-08-02 03:31:54 --> Security Class Initialized
DEBUG - 2018-08-02 03:31:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-02 03:31:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 03:31:54 --> Input Class Initialized
INFO - 2018-08-02 03:31:54 --> Language Class Initialized
ERROR - 2018-08-02 03:31:54 --> 404 Page Not Found: /index
INFO - 2018-08-02 03:31:54 --> Config Class Initialized
INFO - 2018-08-02 03:31:54 --> Hooks Class Initialized
DEBUG - 2018-08-02 03:31:54 --> UTF-8 Support Enabled
INFO - 2018-08-02 03:31:54 --> Utf8 Class Initialized
INFO - 2018-08-02 03:31:54 --> URI Class Initialized
INFO - 2018-08-02 03:31:54 --> Router Class Initialized
INFO - 2018-08-02 03:31:54 --> Output Class Initialized
INFO - 2018-08-02 03:31:54 --> Security Class Initialized
DEBUG - 2018-08-02 03:31:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 03:31:54 --> Input Class Initialized
INFO - 2018-08-02 03:31:54 --> Language Class Initialized
ERROR - 2018-08-02 03:31:54 --> 404 Page Not Found: /index
INFO - 2018-08-02 03:31:54 --> Config Class Initialized
INFO - 2018-08-02 03:31:54 --> Hooks Class Initialized
DEBUG - 2018-08-02 03:31:54 --> UTF-8 Support Enabled
INFO - 2018-08-02 03:31:54 --> Utf8 Class Initialized
INFO - 2018-08-02 03:31:54 --> URI Class Initialized
INFO - 2018-08-02 03:31:54 --> Router Class Initialized
INFO - 2018-08-02 03:31:54 --> Output Class Initialized
INFO - 2018-08-02 03:31:54 --> Security Class Initialized
DEBUG - 2018-08-02 03:31:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 03:31:54 --> Input Class Initialized
INFO - 2018-08-02 03:31:54 --> Language Class Initialized
ERROR - 2018-08-02 03:31:54 --> 404 Page Not Found: /index
INFO - 2018-08-02 03:32:48 --> Config Class Initialized
INFO - 2018-08-02 03:32:48 --> Hooks Class Initialized
DEBUG - 2018-08-02 03:32:48 --> UTF-8 Support Enabled
INFO - 2018-08-02 03:32:48 --> Utf8 Class Initialized
INFO - 2018-08-02 03:32:48 --> URI Class Initialized
INFO - 2018-08-02 03:32:48 --> Router Class Initialized
INFO - 2018-08-02 03:32:48 --> Output Class Initialized
INFO - 2018-08-02 03:32:48 --> Security Class Initialized
DEBUG - 2018-08-02 03:32:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 03:32:48 --> Input Class Initialized
INFO - 2018-08-02 03:32:48 --> Language Class Initialized
INFO - 2018-08-02 03:32:48 --> Language Class Initialized
INFO - 2018-08-02 03:32:48 --> Config Class Initialized
INFO - 2018-08-02 03:32:48 --> Loader Class Initialized
DEBUG - 2018-08-02 03:32:48 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-02 03:32:48 --> Helper loaded: url_helper
INFO - 2018-08-02 03:32:48 --> Helper loaded: form_helper
INFO - 2018-08-02 03:32:48 --> Helper loaded: date_helper
INFO - 2018-08-02 03:32:48 --> Helper loaded: util_helper
INFO - 2018-08-02 03:32:48 --> Helper loaded: text_helper
INFO - 2018-08-02 03:32:48 --> Helper loaded: string_helper
INFO - 2018-08-02 03:32:48 --> Database Driver Class Initialized
DEBUG - 2018-08-02 03:32:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-02 03:32:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-02 03:32:48 --> Email Class Initialized
INFO - 2018-08-02 03:32:48 --> Controller Class Initialized
DEBUG - 2018-08-02 03:32:48 --> Home MX_Controller Initialized
DEBUG - 2018-08-02 03:32:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-02 03:32:48 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-02 03:32:48 --> Login MX_Controller Initialized
INFO - 2018-08-02 03:32:48 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-02 03:32:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-02 03:32:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-02 03:32:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-08-02 03:32:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-08-02 03:32:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-08-02 03:32:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-08-02 03:32:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-08-02 03:32:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-08-02 03:32:49 --> Final output sent to browser
DEBUG - 2018-08-02 03:32:49 --> Total execution time: 0.5684
INFO - 2018-08-02 03:32:49 --> Config Class Initialized
INFO - 2018-08-02 03:32:49 --> Hooks Class Initialized
INFO - 2018-08-02 03:32:49 --> Config Class Initialized
INFO - 2018-08-02 03:32:49 --> Hooks Class Initialized
DEBUG - 2018-08-02 03:32:49 --> UTF-8 Support Enabled
DEBUG - 2018-08-02 03:32:49 --> UTF-8 Support Enabled
INFO - 2018-08-02 03:32:49 --> Utf8 Class Initialized
INFO - 2018-08-02 03:32:49 --> Utf8 Class Initialized
INFO - 2018-08-02 03:32:49 --> URI Class Initialized
INFO - 2018-08-02 03:32:49 --> URI Class Initialized
INFO - 2018-08-02 03:32:50 --> Router Class Initialized
INFO - 2018-08-02 03:32:50 --> Output Class Initialized
INFO - 2018-08-02 03:32:50 --> Security Class Initialized
DEBUG - 2018-08-02 03:32:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 03:32:50 --> Input Class Initialized
INFO - 2018-08-02 03:32:50 --> Language Class Initialized
INFO - 2018-08-02 03:32:50 --> Router Class Initialized
INFO - 2018-08-02 03:32:50 --> Language Class Initialized
INFO - 2018-08-02 03:32:50 --> Output Class Initialized
INFO - 2018-08-02 03:32:50 --> Config Class Initialized
INFO - 2018-08-02 03:32:50 --> Security Class Initialized
INFO - 2018-08-02 03:32:50 --> Loader Class Initialized
DEBUG - 2018-08-02 03:32:50 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
DEBUG - 2018-08-02 03:32:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 03:32:50 --> Helper loaded: url_helper
INFO - 2018-08-02 03:32:50 --> Input Class Initialized
INFO - 2018-08-02 03:32:50 --> Helper loaded: form_helper
INFO - 2018-08-02 03:32:50 --> Language Class Initialized
INFO - 2018-08-02 03:32:50 --> Helper loaded: date_helper
ERROR - 2018-08-02 03:32:50 --> 404 Page Not Found: /index
INFO - 2018-08-02 03:32:50 --> Helper loaded: util_helper
INFO - 2018-08-02 03:32:50 --> Config Class Initialized
INFO - 2018-08-02 03:32:50 --> Hooks Class Initialized
INFO - 2018-08-02 03:32:50 --> Helper loaded: text_helper
INFO - 2018-08-02 03:32:50 --> Helper loaded: string_helper
DEBUG - 2018-08-02 03:32:50 --> UTF-8 Support Enabled
INFO - 2018-08-02 03:32:50 --> Utf8 Class Initialized
INFO - 2018-08-02 03:32:50 --> Database Driver Class Initialized
INFO - 2018-08-02 03:32:50 --> URI Class Initialized
DEBUG - 2018-08-02 03:32:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-02 03:32:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-02 03:32:50 --> Router Class Initialized
INFO - 2018-08-02 03:32:50 --> Email Class Initialized
INFO - 2018-08-02 03:32:50 --> Output Class Initialized
INFO - 2018-08-02 03:32:50 --> Controller Class Initialized
DEBUG - 2018-08-02 03:32:50 --> Home MX_Controller Initialized
INFO - 2018-08-02 03:32:50 --> Security Class Initialized
DEBUG - 2018-08-02 03:32:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-08-02 03:32:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-08-02 03:32:50 --> Input Class Initialized
INFO - 2018-08-02 03:32:50 --> Language Class Initialized
DEBUG - 2018-08-02 03:32:50 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-02 03:32:50 --> Login MX_Controller Initialized
ERROR - 2018-08-02 03:32:50 --> 404 Page Not Found: /index
INFO - 2018-08-02 03:32:50 --> Language file loaded: language/english/data_lang.php
INFO - 2018-08-02 03:32:50 --> Config Class Initialized
INFO - 2018-08-02 03:32:50 --> Hooks Class Initialized
DEBUG - 2018-08-02 03:32:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-02 03:32:50 --> UTF-8 Support Enabled
INFO - 2018-08-02 03:32:50 --> Utf8 Class Initialized
DEBUG - 2018-08-02 03:32:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-02 03:32:50 --> URI Class Initialized
INFO - 2018-08-02 03:32:50 --> Router Class Initialized
INFO - 2018-08-02 03:32:50 --> Output Class Initialized
INFO - 2018-08-02 03:32:50 --> Security Class Initialized
DEBUG - 2018-08-02 03:32:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 03:32:50 --> Input Class Initialized
INFO - 2018-08-02 03:32:50 --> Language Class Initialized
ERROR - 2018-08-02 03:32:51 --> 404 Page Not Found: /index
INFO - 2018-08-02 03:32:51 --> Config Class Initialized
INFO - 2018-08-02 03:32:51 --> Hooks Class Initialized
DEBUG - 2018-08-02 03:32:51 --> UTF-8 Support Enabled
INFO - 2018-08-02 03:32:51 --> Utf8 Class Initialized
INFO - 2018-08-02 03:32:51 --> URI Class Initialized
INFO - 2018-08-02 03:32:51 --> Router Class Initialized
INFO - 2018-08-02 03:32:51 --> Output Class Initialized
INFO - 2018-08-02 03:32:51 --> Security Class Initialized
DEBUG - 2018-08-02 03:32:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 03:32:51 --> Input Class Initialized
INFO - 2018-08-02 03:32:51 --> Language Class Initialized
ERROR - 2018-08-02 03:32:51 --> 404 Page Not Found: /index
INFO - 2018-08-02 03:32:51 --> Config Class Initialized
INFO - 2018-08-02 03:32:51 --> Hooks Class Initialized
DEBUG - 2018-08-02 03:32:51 --> UTF-8 Support Enabled
INFO - 2018-08-02 03:32:51 --> Utf8 Class Initialized
INFO - 2018-08-02 03:32:51 --> URI Class Initialized
INFO - 2018-08-02 03:32:51 --> Router Class Initialized
INFO - 2018-08-02 03:32:51 --> Output Class Initialized
INFO - 2018-08-02 03:32:51 --> Security Class Initialized
DEBUG - 2018-08-02 03:32:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 03:32:51 --> Input Class Initialized
INFO - 2018-08-02 03:32:51 --> Language Class Initialized
ERROR - 2018-08-02 03:32:51 --> 404 Page Not Found: /index
INFO - 2018-08-02 03:32:51 --> Config Class Initialized
INFO - 2018-08-02 03:32:51 --> Hooks Class Initialized
DEBUG - 2018-08-02 03:32:51 --> UTF-8 Support Enabled
INFO - 2018-08-02 03:32:51 --> Utf8 Class Initialized
INFO - 2018-08-02 03:32:51 --> URI Class Initialized
INFO - 2018-08-02 03:32:51 --> Router Class Initialized
INFO - 2018-08-02 03:32:51 --> Output Class Initialized
INFO - 2018-08-02 03:32:51 --> Security Class Initialized
DEBUG - 2018-08-02 03:32:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 03:32:51 --> Input Class Initialized
INFO - 2018-08-02 03:32:51 --> Language Class Initialized
ERROR - 2018-08-02 03:32:51 --> 404 Page Not Found: /index
INFO - 2018-08-02 03:33:08 --> Config Class Initialized
INFO - 2018-08-02 03:33:08 --> Hooks Class Initialized
DEBUG - 2018-08-02 03:33:08 --> UTF-8 Support Enabled
INFO - 2018-08-02 03:33:08 --> Utf8 Class Initialized
INFO - 2018-08-02 03:33:08 --> URI Class Initialized
DEBUG - 2018-08-02 03:33:08 --> No URI present. Default controller set.
INFO - 2018-08-02 03:33:08 --> Router Class Initialized
INFO - 2018-08-02 03:33:08 --> Output Class Initialized
INFO - 2018-08-02 03:33:08 --> Security Class Initialized
DEBUG - 2018-08-02 03:33:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 03:33:08 --> Input Class Initialized
INFO - 2018-08-02 03:33:08 --> Language Class Initialized
INFO - 2018-08-02 03:33:08 --> Language Class Initialized
INFO - 2018-08-02 03:33:09 --> Config Class Initialized
INFO - 2018-08-02 03:33:09 --> Loader Class Initialized
DEBUG - 2018-08-02 03:33:09 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-02 03:33:09 --> Helper loaded: url_helper
INFO - 2018-08-02 03:33:09 --> Helper loaded: form_helper
INFO - 2018-08-02 03:33:09 --> Helper loaded: date_helper
INFO - 2018-08-02 03:33:09 --> Helper loaded: util_helper
INFO - 2018-08-02 03:33:09 --> Helper loaded: text_helper
INFO - 2018-08-02 03:33:09 --> Helper loaded: string_helper
INFO - 2018-08-02 03:33:09 --> Database Driver Class Initialized
DEBUG - 2018-08-02 03:33:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-02 03:33:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-02 03:33:09 --> Email Class Initialized
INFO - 2018-08-02 03:33:09 --> Controller Class Initialized
DEBUG - 2018-08-02 03:33:09 --> Home MX_Controller Initialized
DEBUG - 2018-08-02 03:33:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-02 03:33:09 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-02 03:33:09 --> Login MX_Controller Initialized
INFO - 2018-08-02 03:33:09 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-02 03:33:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-02 03:33:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-02 03:33:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-08-02 03:33:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-08-02 03:33:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-08-02 03:33:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-08-02 03:33:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-08-02 03:33:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-08-02 03:33:09 --> Final output sent to browser
DEBUG - 2018-08-02 03:33:09 --> Total execution time: 0.5879
INFO - 2018-08-02 03:33:10 --> Config Class Initialized
INFO - 2018-08-02 03:33:10 --> Hooks Class Initialized
DEBUG - 2018-08-02 03:33:10 --> UTF-8 Support Enabled
INFO - 2018-08-02 03:33:10 --> Utf8 Class Initialized
INFO - 2018-08-02 03:33:10 --> Config Class Initialized
INFO - 2018-08-02 03:33:10 --> Hooks Class Initialized
INFO - 2018-08-02 03:33:10 --> URI Class Initialized
DEBUG - 2018-08-02 03:33:10 --> UTF-8 Support Enabled
INFO - 2018-08-02 03:33:10 --> Utf8 Class Initialized
INFO - 2018-08-02 03:33:10 --> URI Class Initialized
INFO - 2018-08-02 03:33:10 --> Router Class Initialized
INFO - 2018-08-02 03:33:10 --> Router Class Initialized
INFO - 2018-08-02 03:33:10 --> Output Class Initialized
INFO - 2018-08-02 03:33:10 --> Output Class Initialized
INFO - 2018-08-02 03:33:10 --> Security Class Initialized
INFO - 2018-08-02 03:33:10 --> Security Class Initialized
DEBUG - 2018-08-02 03:33:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-08-02 03:33:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 03:33:10 --> Input Class Initialized
INFO - 2018-08-02 03:33:10 --> Language Class Initialized
INFO - 2018-08-02 03:33:10 --> Input Class Initialized
INFO - 2018-08-02 03:33:10 --> Language Class Initialized
INFO - 2018-08-02 03:33:10 --> Language Class Initialized
ERROR - 2018-08-02 03:33:10 --> 404 Page Not Found: /index
INFO - 2018-08-02 03:33:10 --> Config Class Initialized
INFO - 2018-08-02 03:33:10 --> Loader Class Initialized
DEBUG - 2018-08-02 03:33:10 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-02 03:33:10 --> Helper loaded: url_helper
INFO - 2018-08-02 03:33:10 --> Helper loaded: form_helper
INFO - 2018-08-02 03:33:10 --> Helper loaded: date_helper
INFO - 2018-08-02 03:33:11 --> Config Class Initialized
INFO - 2018-08-02 03:33:11 --> Hooks Class Initialized
INFO - 2018-08-02 03:33:11 --> Helper loaded: util_helper
DEBUG - 2018-08-02 03:33:11 --> UTF-8 Support Enabled
INFO - 2018-08-02 03:33:11 --> Utf8 Class Initialized
INFO - 2018-08-02 03:33:11 --> URI Class Initialized
INFO - 2018-08-02 03:33:11 --> Router Class Initialized
INFO - 2018-08-02 03:33:11 --> Output Class Initialized
INFO - 2018-08-02 03:33:11 --> Security Class Initialized
INFO - 2018-08-02 03:33:11 --> Helper loaded: text_helper
DEBUG - 2018-08-02 03:33:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 03:33:11 --> Helper loaded: string_helper
INFO - 2018-08-02 03:33:11 --> Database Driver Class Initialized
INFO - 2018-08-02 03:33:11 --> Input Class Initialized
INFO - 2018-08-02 03:33:11 --> Language Class Initialized
DEBUG - 2018-08-02 03:33:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-02 03:33:11 --> Session: Class initialized using 'files' driver.
ERROR - 2018-08-02 03:33:11 --> 404 Page Not Found: /index
INFO - 2018-08-02 03:33:11 --> Email Class Initialized
INFO - 2018-08-02 03:33:11 --> Controller Class Initialized
DEBUG - 2018-08-02 03:33:11 --> Home MX_Controller Initialized
DEBUG - 2018-08-02 03:33:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-02 03:33:11 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
INFO - 2018-08-02 03:33:11 --> Config Class Initialized
DEBUG - 2018-08-02 03:33:11 --> Login MX_Controller Initialized
INFO - 2018-08-02 03:33:11 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-02 03:33:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-02 03:33:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-02 03:33:11 --> Hooks Class Initialized
DEBUG - 2018-08-02 03:33:11 --> UTF-8 Support Enabled
INFO - 2018-08-02 03:33:11 --> Utf8 Class Initialized
INFO - 2018-08-02 03:33:11 --> URI Class Initialized
INFO - 2018-08-02 03:33:11 --> Router Class Initialized
INFO - 2018-08-02 03:33:11 --> Output Class Initialized
INFO - 2018-08-02 03:33:11 --> Security Class Initialized
DEBUG - 2018-08-02 03:33:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 03:33:11 --> Input Class Initialized
INFO - 2018-08-02 03:33:12 --> Language Class Initialized
ERROR - 2018-08-02 03:33:12 --> 404 Page Not Found: /index
INFO - 2018-08-02 03:35:42 --> Config Class Initialized
INFO - 2018-08-02 03:35:42 --> Hooks Class Initialized
DEBUG - 2018-08-02 03:35:42 --> UTF-8 Support Enabled
INFO - 2018-08-02 03:35:42 --> Utf8 Class Initialized
INFO - 2018-08-02 03:35:42 --> URI Class Initialized
DEBUG - 2018-08-02 03:35:42 --> No URI present. Default controller set.
INFO - 2018-08-02 03:35:42 --> Router Class Initialized
INFO - 2018-08-02 03:35:42 --> Output Class Initialized
INFO - 2018-08-02 03:35:42 --> Security Class Initialized
DEBUG - 2018-08-02 03:35:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 03:35:42 --> Input Class Initialized
INFO - 2018-08-02 03:35:42 --> Language Class Initialized
INFO - 2018-08-02 03:35:42 --> Language Class Initialized
INFO - 2018-08-02 03:35:42 --> Config Class Initialized
INFO - 2018-08-02 03:35:42 --> Loader Class Initialized
DEBUG - 2018-08-02 03:35:42 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-02 03:35:42 --> Helper loaded: url_helper
INFO - 2018-08-02 03:35:42 --> Helper loaded: form_helper
INFO - 2018-08-02 03:35:42 --> Helper loaded: date_helper
INFO - 2018-08-02 03:35:42 --> Helper loaded: util_helper
INFO - 2018-08-02 03:35:43 --> Helper loaded: text_helper
INFO - 2018-08-02 03:35:43 --> Helper loaded: string_helper
INFO - 2018-08-02 03:35:43 --> Database Driver Class Initialized
DEBUG - 2018-08-02 03:35:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-02 03:35:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-02 03:35:43 --> Email Class Initialized
INFO - 2018-08-02 03:35:43 --> Controller Class Initialized
DEBUG - 2018-08-02 03:35:43 --> Home MX_Controller Initialized
DEBUG - 2018-08-02 03:35:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-02 03:35:43 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-02 03:35:43 --> Login MX_Controller Initialized
INFO - 2018-08-02 03:35:43 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-02 03:35:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-02 03:35:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-02 03:35:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-08-02 03:35:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-08-02 03:35:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-08-02 03:35:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-08-02 03:35:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-08-02 03:35:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-08-02 03:35:43 --> Final output sent to browser
DEBUG - 2018-08-02 03:35:43 --> Total execution time: 0.6206
INFO - 2018-08-02 03:35:45 --> Config Class Initialized
INFO - 2018-08-02 03:35:45 --> Hooks Class Initialized
DEBUG - 2018-08-02 03:35:45 --> UTF-8 Support Enabled
INFO - 2018-08-02 03:35:45 --> Config Class Initialized
INFO - 2018-08-02 03:35:45 --> Hooks Class Initialized
INFO - 2018-08-02 03:35:45 --> Utf8 Class Initialized
DEBUG - 2018-08-02 03:35:45 --> UTF-8 Support Enabled
INFO - 2018-08-02 03:35:45 --> Utf8 Class Initialized
INFO - 2018-08-02 03:35:45 --> URI Class Initialized
INFO - 2018-08-02 03:35:45 --> URI Class Initialized
INFO - 2018-08-02 03:35:45 --> Router Class Initialized
INFO - 2018-08-02 03:35:45 --> Router Class Initialized
INFO - 2018-08-02 03:35:45 --> Output Class Initialized
INFO - 2018-08-02 03:35:45 --> Output Class Initialized
INFO - 2018-08-02 03:35:45 --> Security Class Initialized
DEBUG - 2018-08-02 03:35:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 03:35:45 --> Security Class Initialized
INFO - 2018-08-02 03:35:45 --> Input Class Initialized
INFO - 2018-08-02 03:35:45 --> Language Class Initialized
ERROR - 2018-08-02 03:35:45 --> 404 Page Not Found: /index
DEBUG - 2018-08-02 03:35:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 03:35:45 --> Input Class Initialized
INFO - 2018-08-02 03:35:45 --> Config Class Initialized
INFO - 2018-08-02 03:35:45 --> Hooks Class Initialized
INFO - 2018-08-02 03:35:45 --> Language Class Initialized
DEBUG - 2018-08-02 03:35:45 --> UTF-8 Support Enabled
INFO - 2018-08-02 03:35:45 --> Language Class Initialized
INFO - 2018-08-02 03:35:45 --> Utf8 Class Initialized
INFO - 2018-08-02 03:35:45 --> URI Class Initialized
INFO - 2018-08-02 03:35:45 --> Router Class Initialized
INFO - 2018-08-02 03:35:45 --> Output Class Initialized
INFO - 2018-08-02 03:35:45 --> Security Class Initialized
DEBUG - 2018-08-02 03:35:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 03:35:45 --> Config Class Initialized
INFO - 2018-08-02 03:35:45 --> Input Class Initialized
INFO - 2018-08-02 03:35:45 --> Loader Class Initialized
INFO - 2018-08-02 03:35:45 --> Language Class Initialized
DEBUG - 2018-08-02 03:35:45 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
ERROR - 2018-08-02 03:35:45 --> 404 Page Not Found: /index
INFO - 2018-08-02 03:35:45 --> Config Class Initialized
INFO - 2018-08-02 03:35:45 --> Hooks Class Initialized
DEBUG - 2018-08-02 03:35:46 --> UTF-8 Support Enabled
INFO - 2018-08-02 03:35:46 --> Utf8 Class Initialized
INFO - 2018-08-02 03:35:46 --> URI Class Initialized
INFO - 2018-08-02 03:35:46 --> Router Class Initialized
INFO - 2018-08-02 03:35:46 --> Output Class Initialized
INFO - 2018-08-02 03:35:46 --> Security Class Initialized
DEBUG - 2018-08-02 03:35:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 03:35:46 --> Helper loaded: url_helper
INFO - 2018-08-02 03:35:46 --> Input Class Initialized
INFO - 2018-08-02 03:35:46 --> Language Class Initialized
ERROR - 2018-08-02 03:35:46 --> 404 Page Not Found: /index
INFO - 2018-08-02 03:35:46 --> Helper loaded: form_helper
INFO - 2018-08-02 03:35:46 --> Helper loaded: date_helper
INFO - 2018-08-02 03:35:46 --> Helper loaded: util_helper
INFO - 2018-08-02 03:35:46 --> Helper loaded: text_helper
INFO - 2018-08-02 03:35:46 --> Helper loaded: string_helper
INFO - 2018-08-02 03:35:46 --> Database Driver Class Initialized
DEBUG - 2018-08-02 03:35:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-02 03:35:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-02 03:35:46 --> Email Class Initialized
INFO - 2018-08-02 03:35:46 --> Controller Class Initialized
DEBUG - 2018-08-02 03:35:46 --> Home MX_Controller Initialized
DEBUG - 2018-08-02 03:35:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-02 03:35:46 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-02 03:35:46 --> Login MX_Controller Initialized
INFO - 2018-08-02 03:35:46 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-02 03:35:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-02 03:35:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-02 21:38:07 --> Config Class Initialized
INFO - 2018-08-02 21:38:07 --> Config Class Initialized
INFO - 2018-08-02 21:38:07 --> Hooks Class Initialized
INFO - 2018-08-02 21:38:07 --> Hooks Class Initialized
DEBUG - 2018-08-02 21:38:07 --> UTF-8 Support Enabled
DEBUG - 2018-08-02 21:38:07 --> UTF-8 Support Enabled
INFO - 2018-08-02 21:38:07 --> Utf8 Class Initialized
INFO - 2018-08-02 21:38:07 --> Utf8 Class Initialized
INFO - 2018-08-02 21:38:07 --> URI Class Initialized
INFO - 2018-08-02 21:38:07 --> URI Class Initialized
INFO - 2018-08-02 21:38:07 --> Router Class Initialized
DEBUG - 2018-08-02 21:38:07 --> No URI present. Default controller set.
INFO - 2018-08-02 21:38:07 --> Router Class Initialized
INFO - 2018-08-02 21:38:07 --> Output Class Initialized
INFO - 2018-08-02 21:38:07 --> Output Class Initialized
INFO - 2018-08-02 21:38:07 --> Security Class Initialized
INFO - 2018-08-02 21:38:07 --> Security Class Initialized
DEBUG - 2018-08-02 21:38:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-08-02 21:38:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 21:38:07 --> Input Class Initialized
INFO - 2018-08-02 21:38:07 --> Input Class Initialized
INFO - 2018-08-02 21:38:07 --> Language Class Initialized
INFO - 2018-08-02 21:38:07 --> Language Class Initialized
INFO - 2018-08-02 21:38:07 --> Language Class Initialized
INFO - 2018-08-02 21:38:07 --> Language Class Initialized
INFO - 2018-08-02 21:38:07 --> Config Class Initialized
INFO - 2018-08-02 21:38:07 --> Config Class Initialized
INFO - 2018-08-02 21:38:08 --> Loader Class Initialized
INFO - 2018-08-02 21:38:08 --> Loader Class Initialized
DEBUG - 2018-08-02 21:38:08 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
DEBUG - 2018-08-02 21:38:08 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-02 21:38:08 --> Helper loaded: url_helper
INFO - 2018-08-02 21:38:08 --> Helper loaded: url_helper
INFO - 2018-08-02 21:38:08 --> Helper loaded: form_helper
INFO - 2018-08-02 21:38:08 --> Helper loaded: form_helper
INFO - 2018-08-02 21:38:08 --> Helper loaded: date_helper
INFO - 2018-08-02 21:38:08 --> Helper loaded: date_helper
INFO - 2018-08-02 21:38:08 --> Helper loaded: util_helper
INFO - 2018-08-02 21:38:08 --> Helper loaded: util_helper
INFO - 2018-08-02 21:38:08 --> Helper loaded: text_helper
INFO - 2018-08-02 21:38:08 --> Helper loaded: text_helper
INFO - 2018-08-02 21:38:08 --> Helper loaded: string_helper
INFO - 2018-08-02 21:38:08 --> Helper loaded: string_helper
INFO - 2018-08-02 21:38:08 --> Database Driver Class Initialized
INFO - 2018-08-02 21:38:08 --> Database Driver Class Initialized
DEBUG - 2018-08-02 21:38:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-08-02 21:38:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-02 21:38:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-02 21:38:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-02 21:38:08 --> Email Class Initialized
INFO - 2018-08-02 21:38:08 --> Email Class Initialized
INFO - 2018-08-02 21:38:08 --> Controller Class Initialized
INFO - 2018-08-02 21:38:08 --> Controller Class Initialized
DEBUG - 2018-08-02 21:38:08 --> Home MX_Controller Initialized
DEBUG - 2018-08-02 21:38:08 --> videos MX_Controller Initialized
INFO - 2018-08-02 21:38:08 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-02 21:38:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-02 21:38:08 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-02 21:38:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-08-02 21:38:08 --> Login MX_Controller Initialized
DEBUG - 2018-08-02 21:38:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-08-02 21:38:08 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-02 21:38:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-02 21:38:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-08-02 21:38:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-02 21:38:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/login.php
DEBUG - 2018-08-02 21:38:08 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-02 21:38:08 --> Login MX_Controller Initialized
DEBUG - 2018-08-02 21:38:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-02 21:38:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/logins/login.php
INFO - 2018-08-02 21:38:09 --> Config Class Initialized
INFO - 2018-08-02 21:38:09 --> Hooks Class Initialized
DEBUG - 2018-08-02 21:38:09 --> UTF-8 Support Enabled
INFO - 2018-08-02 21:38:09 --> Utf8 Class Initialized
INFO - 2018-08-02 21:38:09 --> URI Class Initialized
INFO - 2018-08-02 21:38:09 --> Router Class Initialized
INFO - 2018-08-02 21:38:09 --> Output Class Initialized
INFO - 2018-08-02 21:38:09 --> Security Class Initialized
DEBUG - 2018-08-02 21:38:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 21:38:09 --> Input Class Initialized
INFO - 2018-08-02 21:38:09 --> Language Class Initialized
ERROR - 2018-08-02 21:38:09 --> 404 Page Not Found: /index
INFO - 2018-08-02 21:38:09 --> Config Class Initialized
INFO - 2018-08-02 21:38:09 --> Hooks Class Initialized
DEBUG - 2018-08-02 21:38:09 --> UTF-8 Support Enabled
INFO - 2018-08-02 21:38:09 --> Utf8 Class Initialized
INFO - 2018-08-02 21:38:09 --> URI Class Initialized
INFO - 2018-08-02 21:38:09 --> Router Class Initialized
INFO - 2018-08-02 21:38:09 --> Output Class Initialized
INFO - 2018-08-02 21:38:09 --> Security Class Initialized
DEBUG - 2018-08-02 21:38:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 21:38:10 --> Input Class Initialized
INFO - 2018-08-02 21:38:10 --> Language Class Initialized
ERROR - 2018-08-02 21:38:10 --> 404 Page Not Found: /index
INFO - 2018-08-02 21:38:28 --> Config Class Initialized
INFO - 2018-08-02 21:38:28 --> Hooks Class Initialized
DEBUG - 2018-08-02 21:38:28 --> UTF-8 Support Enabled
INFO - 2018-08-02 21:38:28 --> Utf8 Class Initialized
INFO - 2018-08-02 21:38:28 --> URI Class Initialized
INFO - 2018-08-02 21:38:28 --> Router Class Initialized
INFO - 2018-08-02 21:38:28 --> Output Class Initialized
INFO - 2018-08-02 21:38:28 --> Security Class Initialized
DEBUG - 2018-08-02 21:38:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 21:38:28 --> Input Class Initialized
INFO - 2018-08-02 21:38:28 --> Language Class Initialized
INFO - 2018-08-02 21:38:28 --> Language Class Initialized
INFO - 2018-08-02 21:38:28 --> Config Class Initialized
INFO - 2018-08-02 21:38:28 --> Loader Class Initialized
DEBUG - 2018-08-02 21:38:28 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-02 21:38:28 --> Helper loaded: url_helper
INFO - 2018-08-02 21:38:28 --> Helper loaded: form_helper
INFO - 2018-08-02 21:38:28 --> Helper loaded: date_helper
INFO - 2018-08-02 21:38:28 --> Helper loaded: util_helper
INFO - 2018-08-02 21:38:28 --> Helper loaded: text_helper
INFO - 2018-08-02 21:38:28 --> Helper loaded: string_helper
INFO - 2018-08-02 21:38:28 --> Database Driver Class Initialized
DEBUG - 2018-08-02 21:38:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-02 21:38:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-02 21:38:28 --> Email Class Initialized
INFO - 2018-08-02 21:38:28 --> Controller Class Initialized
DEBUG - 2018-08-02 21:38:28 --> Login MX_Controller Initialized
INFO - 2018-08-02 21:38:28 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-02 21:38:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-02 21:38:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-02 21:38:28 --> Email starts for colinUser fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-08-02 21:38:28 --> User session created for 4
INFO - 2018-08-02 21:38:28 --> Login status colinUser - success
INFO - 2018-08-02 21:38:28 --> Final output sent to browser
DEBUG - 2018-08-02 21:38:28 --> Total execution time: 0.5732
INFO - 2018-08-02 21:38:28 --> Config Class Initialized
INFO - 2018-08-02 21:38:28 --> Hooks Class Initialized
DEBUG - 2018-08-02 21:38:28 --> UTF-8 Support Enabled
INFO - 2018-08-02 21:38:28 --> Utf8 Class Initialized
INFO - 2018-08-02 21:38:28 --> URI Class Initialized
DEBUG - 2018-08-02 21:38:28 --> No URI present. Default controller set.
INFO - 2018-08-02 21:38:28 --> Router Class Initialized
INFO - 2018-08-02 21:38:28 --> Output Class Initialized
INFO - 2018-08-02 21:38:28 --> Security Class Initialized
DEBUG - 2018-08-02 21:38:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 21:38:29 --> Input Class Initialized
INFO - 2018-08-02 21:38:29 --> Language Class Initialized
INFO - 2018-08-02 21:38:29 --> Language Class Initialized
INFO - 2018-08-02 21:38:29 --> Config Class Initialized
INFO - 2018-08-02 21:38:29 --> Loader Class Initialized
DEBUG - 2018-08-02 21:38:29 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-02 21:38:29 --> Helper loaded: url_helper
INFO - 2018-08-02 21:38:29 --> Helper loaded: form_helper
INFO - 2018-08-02 21:38:29 --> Helper loaded: date_helper
INFO - 2018-08-02 21:38:29 --> Helper loaded: util_helper
INFO - 2018-08-02 21:38:29 --> Helper loaded: text_helper
INFO - 2018-08-02 21:38:29 --> Helper loaded: string_helper
INFO - 2018-08-02 21:38:29 --> Database Driver Class Initialized
DEBUG - 2018-08-02 21:38:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-02 21:38:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-02 21:38:29 --> Email Class Initialized
INFO - 2018-08-02 21:38:29 --> Controller Class Initialized
DEBUG - 2018-08-02 21:38:29 --> Home MX_Controller Initialized
DEBUG - 2018-08-02 21:38:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-02 21:38:29 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-02 21:38:29 --> Login MX_Controller Initialized
INFO - 2018-08-02 21:38:29 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-02 21:38:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-02 21:38:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-02 21:38:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-08-02 21:38:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-08-02 21:38:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-08-02 21:38:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-08-02 21:38:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-08-02 21:38:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-08-02 21:38:29 --> Final output sent to browser
DEBUG - 2018-08-02 21:38:29 --> Total execution time: 0.8796
INFO - 2018-08-02 21:38:31 --> Config Class Initialized
INFO - 2018-08-02 21:38:31 --> Hooks Class Initialized
DEBUG - 2018-08-02 21:38:31 --> UTF-8 Support Enabled
INFO - 2018-08-02 21:38:31 --> Utf8 Class Initialized
INFO - 2018-08-02 21:38:31 --> URI Class Initialized
INFO - 2018-08-02 21:38:31 --> Router Class Initialized
INFO - 2018-08-02 21:38:31 --> Output Class Initialized
INFO - 2018-08-02 21:38:31 --> Security Class Initialized
DEBUG - 2018-08-02 21:38:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 21:38:31 --> Input Class Initialized
INFO - 2018-08-02 21:38:31 --> Language Class Initialized
INFO - 2018-08-02 21:38:31 --> Config Class Initialized
INFO - 2018-08-02 21:38:31 --> Hooks Class Initialized
INFO - 2018-08-02 21:38:31 --> Language Class Initialized
INFO - 2018-08-02 21:38:31 --> Config Class Initialized
DEBUG - 2018-08-02 21:38:31 --> UTF-8 Support Enabled
INFO - 2018-08-02 21:38:31 --> Utf8 Class Initialized
INFO - 2018-08-02 21:38:31 --> Loader Class Initialized
DEBUG - 2018-08-02 21:38:31 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-02 21:38:31 --> URI Class Initialized
INFO - 2018-08-02 21:38:31 --> Helper loaded: url_helper
INFO - 2018-08-02 21:38:31 --> Router Class Initialized
INFO - 2018-08-02 21:38:31 --> Helper loaded: form_helper
INFO - 2018-08-02 21:38:31 --> Output Class Initialized
INFO - 2018-08-02 21:38:31 --> Helper loaded: date_helper
INFO - 2018-08-02 21:38:31 --> Security Class Initialized
INFO - 2018-08-02 21:38:31 --> Helper loaded: util_helper
INFO - 2018-08-02 21:38:31 --> Helper loaded: text_helper
DEBUG - 2018-08-02 21:38:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 21:38:32 --> Input Class Initialized
INFO - 2018-08-02 21:38:32 --> Helper loaded: string_helper
INFO - 2018-08-02 21:38:32 --> Language Class Initialized
INFO - 2018-08-02 21:38:32 --> Database Driver Class Initialized
ERROR - 2018-08-02 21:38:32 --> 404 Page Not Found: /index
DEBUG - 2018-08-02 21:38:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-02 21:38:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-02 21:38:32 --> Email Class Initialized
INFO - 2018-08-02 21:38:32 --> Controller Class Initialized
DEBUG - 2018-08-02 21:38:32 --> Login MX_Controller Initialized
INFO - 2018-08-02 21:38:32 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-02 21:38:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-02 21:38:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-02 21:38:32 --> Email starts for colin-admin fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-08-02 21:38:32 --> User session created for 1
INFO - 2018-08-02 21:38:32 --> Config Class Initialized
INFO - 2018-08-02 21:38:32 --> Hooks Class Initialized
DEBUG - 2018-08-02 21:38:32 --> UTF-8 Support Enabled
INFO - 2018-08-02 21:38:32 --> Utf8 Class Initialized
INFO - 2018-08-02 21:38:32 --> URI Class Initialized
INFO - 2018-08-02 21:38:32 --> Router Class Initialized
INFO - 2018-08-02 21:38:32 --> Output Class Initialized
INFO - 2018-08-02 21:38:32 --> Security Class Initialized
INFO - 2018-08-02 21:38:32 --> Login status colin-admin - success
INFO - 2018-08-02 21:38:32 --> Config Class Initialized
INFO - 2018-08-02 21:38:32 --> Final output sent to browser
DEBUG - 2018-08-02 21:38:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 21:38:32 --> Hooks Class Initialized
DEBUG - 2018-08-02 21:38:32 --> Total execution time: 0.7146
INFO - 2018-08-02 21:38:32 --> Input Class Initialized
INFO - 2018-08-02 21:38:32 --> Language Class Initialized
INFO - 2018-08-02 21:38:32 --> Language Class Initialized
INFO - 2018-08-02 21:38:32 --> Config Class Initialized
INFO - 2018-08-02 21:38:32 --> Loader Class Initialized
DEBUG - 2018-08-02 21:38:32 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-02 21:38:32 --> Helper loaded: url_helper
INFO - 2018-08-02 21:38:32 --> Helper loaded: form_helper
INFO - 2018-08-02 21:38:32 --> Helper loaded: date_helper
INFO - 2018-08-02 21:38:32 --> Helper loaded: util_helper
DEBUG - 2018-08-02 21:38:32 --> UTF-8 Support Enabled
INFO - 2018-08-02 21:38:32 --> Helper loaded: text_helper
INFO - 2018-08-02 21:38:32 --> Helper loaded: string_helper
INFO - 2018-08-02 21:38:32 --> Database Driver Class Initialized
INFO - 2018-08-02 21:38:32 --> Config Class Initialized
INFO - 2018-08-02 21:38:32 --> Utf8 Class Initialized
INFO - 2018-08-02 21:38:32 --> Hooks Class Initialized
DEBUG - 2018-08-02 21:38:32 --> UTF-8 Support Enabled
DEBUG - 2018-08-02 21:38:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-02 21:38:32 --> URI Class Initialized
INFO - 2018-08-02 21:38:32 --> Utf8 Class Initialized
INFO - 2018-08-02 21:38:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-02 21:38:32 --> Config Class Initialized
INFO - 2018-08-02 21:38:32 --> Router Class Initialized
INFO - 2018-08-02 21:38:32 --> Hooks Class Initialized
INFO - 2018-08-02 21:38:32 --> URI Class Initialized
DEBUG - 2018-08-02 21:38:32 --> UTF-8 Support Enabled
INFO - 2018-08-02 21:38:32 --> Router Class Initialized
INFO - 2018-08-02 21:38:32 --> Output Class Initialized
INFO - 2018-08-02 21:38:32 --> Email Class Initialized
INFO - 2018-08-02 21:38:32 --> Utf8 Class Initialized
INFO - 2018-08-02 21:38:33 --> Security Class Initialized
INFO - 2018-08-02 21:38:33 --> Output Class Initialized
INFO - 2018-08-02 21:38:33 --> URI Class Initialized
INFO - 2018-08-02 21:38:33 --> Controller Class Initialized
INFO - 2018-08-02 21:38:33 --> Security Class Initialized
DEBUG - 2018-08-02 21:38:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-08-02 21:38:33 --> Home MX_Controller Initialized
INFO - 2018-08-02 21:38:33 --> Router Class Initialized
DEBUG - 2018-08-02 21:38:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 21:38:33 --> Output Class Initialized
DEBUG - 2018-08-02 21:38:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-08-02 21:38:33 --> Input Class Initialized
INFO - 2018-08-02 21:38:33 --> Input Class Initialized
INFO - 2018-08-02 21:38:33 --> Language Class Initialized
INFO - 2018-08-02 21:38:33 --> Security Class Initialized
DEBUG - 2018-08-02 21:38:33 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-02 21:38:33 --> Login MX_Controller Initialized
INFO - 2018-08-02 21:38:33 --> Language Class Initialized
DEBUG - 2018-08-02 21:38:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-08-02 21:38:33 --> 404 Page Not Found: /index
INFO - 2018-08-02 21:38:33 --> Language file loaded: language/english/data_lang.php
INFO - 2018-08-02 21:38:33 --> Input Class Initialized
ERROR - 2018-08-02 21:38:33 --> 404 Page Not Found: /index
DEBUG - 2018-08-02 21:38:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-08-02 21:38:33 --> Language Class Initialized
DEBUG - 2018-08-02 21:38:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-02 21:38:33 --> Language Class Initialized
INFO - 2018-08-02 21:38:33 --> Config Class Initialized
INFO - 2018-08-02 21:38:33 --> Hooks Class Initialized
INFO - 2018-08-02 21:38:33 --> Config Class Initialized
INFO - 2018-08-02 21:38:33 --> Loader Class Initialized
DEBUG - 2018-08-02 21:38:33 --> UTF-8 Support Enabled
INFO - 2018-08-02 21:38:33 --> Utf8 Class Initialized
DEBUG - 2018-08-02 21:38:33 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-02 21:38:33 --> URI Class Initialized
INFO - 2018-08-02 21:38:33 --> Helper loaded: url_helper
INFO - 2018-08-02 21:38:33 --> Config Class Initialized
INFO - 2018-08-02 21:38:33 --> Hooks Class Initialized
INFO - 2018-08-02 21:38:33 --> Helper loaded: form_helper
INFO - 2018-08-02 21:38:33 --> Router Class Initialized
INFO - 2018-08-02 21:38:33 --> Helper loaded: date_helper
DEBUG - 2018-08-02 21:38:33 --> UTF-8 Support Enabled
INFO - 2018-08-02 21:38:33 --> Output Class Initialized
INFO - 2018-08-02 21:38:33 --> Utf8 Class Initialized
INFO - 2018-08-02 21:38:33 --> Helper loaded: util_helper
INFO - 2018-08-02 21:38:33 --> Security Class Initialized
INFO - 2018-08-02 21:38:33 --> URI Class Initialized
INFO - 2018-08-02 21:38:33 --> Helper loaded: text_helper
DEBUG - 2018-08-02 21:38:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 21:38:33 --> Helper loaded: string_helper
INFO - 2018-08-02 21:38:33 --> Input Class Initialized
INFO - 2018-08-02 21:38:33 --> Router Class Initialized
INFO - 2018-08-02 21:38:33 --> Output Class Initialized
INFO - 2018-08-02 21:38:33 --> Language Class Initialized
INFO - 2018-08-02 21:38:33 --> Database Driver Class Initialized
INFO - 2018-08-02 21:38:33 --> Security Class Initialized
ERROR - 2018-08-02 21:38:33 --> 404 Page Not Found: /index
DEBUG - 2018-08-02 21:38:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-02 21:38:33 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-08-02 21:38:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 21:38:33 --> Input Class Initialized
INFO - 2018-08-02 21:38:33 --> Email Class Initialized
INFO - 2018-08-02 21:38:33 --> Controller Class Initialized
INFO - 2018-08-02 21:38:33 --> Language Class Initialized
DEBUG - 2018-08-02 21:38:33 --> videos MX_Controller Initialized
ERROR - 2018-08-02 21:38:33 --> 404 Page Not Found: /index
INFO - 2018-08-02 21:38:33 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-02 21:38:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-08-02 21:38:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-02 21:38:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-08-02 21:38:33 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-02 21:38:33 --> Login MX_Controller Initialized
DEBUG - 2018-08-02 21:38:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-02 21:38:33 --> Config Class Initialized
INFO - 2018-08-02 21:38:33 --> Hooks Class Initialized
DEBUG - 2018-08-02 21:38:33 --> UTF-8 Support Enabled
INFO - 2018-08-02 21:38:33 --> Utf8 Class Initialized
INFO - 2018-08-02 21:38:33 --> URI Class Initialized
INFO - 2018-08-02 21:38:33 --> Router Class Initialized
INFO - 2018-08-02 21:38:33 --> Output Class Initialized
INFO - 2018-08-02 21:38:33 --> Security Class Initialized
DEBUG - 2018-08-02 21:38:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 21:38:33 --> Input Class Initialized
INFO - 2018-08-02 21:38:33 --> Language Class Initialized
ERROR - 2018-08-02 21:38:33 --> 404 Page Not Found: /index
INFO - 2018-08-02 21:38:33 --> Config Class Initialized
INFO - 2018-08-02 21:38:33 --> Hooks Class Initialized
DEBUG - 2018-08-02 21:38:33 --> UTF-8 Support Enabled
INFO - 2018-08-02 21:38:33 --> Utf8 Class Initialized
INFO - 2018-08-02 21:38:33 --> URI Class Initialized
INFO - 2018-08-02 21:38:33 --> Router Class Initialized
INFO - 2018-08-02 21:38:33 --> Output Class Initialized
INFO - 2018-08-02 21:38:33 --> Security Class Initialized
DEBUG - 2018-08-02 21:38:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 21:38:33 --> Input Class Initialized
INFO - 2018-08-02 21:38:33 --> Language Class Initialized
DEBUG - 2018-08-02 21:38:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
ERROR - 2018-08-02 21:38:33 --> 404 Page Not Found: /index
DEBUG - 2018-08-02 21:38:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-08-02 21:38:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-08-02 21:38:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-08-02 21:38:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-08-02 21:38:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/videos/videos.php
INFO - 2018-08-02 21:38:34 --> Final output sent to browser
DEBUG - 2018-08-02 21:38:34 --> Total execution time: 1.2973
INFO - 2018-08-02 21:38:34 --> Config Class Initialized
INFO - 2018-08-02 21:38:34 --> Hooks Class Initialized
DEBUG - 2018-08-02 21:38:34 --> UTF-8 Support Enabled
INFO - 2018-08-02 21:38:34 --> Utf8 Class Initialized
INFO - 2018-08-02 21:38:34 --> URI Class Initialized
INFO - 2018-08-02 21:38:34 --> Router Class Initialized
INFO - 2018-08-02 21:38:34 --> Output Class Initialized
INFO - 2018-08-02 21:38:34 --> Security Class Initialized
DEBUG - 2018-08-02 21:38:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 21:38:34 --> Input Class Initialized
INFO - 2018-08-02 21:38:34 --> Language Class Initialized
ERROR - 2018-08-02 21:38:34 --> 404 Page Not Found: /index
INFO - 2018-08-02 21:38:34 --> Config Class Initialized
INFO - 2018-08-02 21:38:34 --> Hooks Class Initialized
DEBUG - 2018-08-02 21:38:34 --> UTF-8 Support Enabled
INFO - 2018-08-02 21:38:34 --> Utf8 Class Initialized
INFO - 2018-08-02 21:38:34 --> URI Class Initialized
INFO - 2018-08-02 21:38:35 --> Router Class Initialized
INFO - 2018-08-02 21:38:35 --> Output Class Initialized
INFO - 2018-08-02 21:38:35 --> Security Class Initialized
DEBUG - 2018-08-02 21:38:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 21:38:35 --> Input Class Initialized
INFO - 2018-08-02 21:38:35 --> Language Class Initialized
ERROR - 2018-08-02 21:38:35 --> 404 Page Not Found: /index
INFO - 2018-08-02 21:38:35 --> Config Class Initialized
INFO - 2018-08-02 21:38:35 --> Hooks Class Initialized
DEBUG - 2018-08-02 21:38:35 --> UTF-8 Support Enabled
INFO - 2018-08-02 21:38:35 --> Utf8 Class Initialized
INFO - 2018-08-02 21:38:35 --> URI Class Initialized
INFO - 2018-08-02 21:38:35 --> Router Class Initialized
INFO - 2018-08-02 21:38:35 --> Output Class Initialized
INFO - 2018-08-02 21:38:35 --> Security Class Initialized
DEBUG - 2018-08-02 21:38:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 21:38:35 --> Input Class Initialized
INFO - 2018-08-02 21:38:35 --> Language Class Initialized
ERROR - 2018-08-02 21:38:35 --> 404 Page Not Found: /index
INFO - 2018-08-02 21:38:36 --> Config Class Initialized
INFO - 2018-08-02 21:38:36 --> Hooks Class Initialized
DEBUG - 2018-08-02 21:38:36 --> UTF-8 Support Enabled
INFO - 2018-08-02 21:38:36 --> Utf8 Class Initialized
INFO - 2018-08-02 21:38:36 --> URI Class Initialized
INFO - 2018-08-02 21:38:36 --> Router Class Initialized
INFO - 2018-08-02 21:38:36 --> Output Class Initialized
INFO - 2018-08-02 21:38:36 --> Security Class Initialized
DEBUG - 2018-08-02 21:38:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 21:38:36 --> Input Class Initialized
INFO - 2018-08-02 21:38:36 --> Language Class Initialized
INFO - 2018-08-02 21:38:36 --> Language Class Initialized
INFO - 2018-08-02 21:38:36 --> Config Class Initialized
INFO - 2018-08-02 21:38:36 --> Loader Class Initialized
DEBUG - 2018-08-02 21:38:36 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-02 21:38:36 --> Helper loaded: url_helper
INFO - 2018-08-02 21:38:36 --> Helper loaded: form_helper
INFO - 2018-08-02 21:38:36 --> Helper loaded: date_helper
INFO - 2018-08-02 21:38:36 --> Helper loaded: util_helper
INFO - 2018-08-02 21:38:36 --> Helper loaded: text_helper
INFO - 2018-08-02 21:38:36 --> Helper loaded: string_helper
INFO - 2018-08-02 21:38:36 --> Database Driver Class Initialized
DEBUG - 2018-08-02 21:38:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-02 21:38:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-02 21:38:36 --> Email Class Initialized
INFO - 2018-08-02 21:38:36 --> Controller Class Initialized
DEBUG - 2018-08-02 21:38:36 --> videos MX_Controller Initialized
INFO - 2018-08-02 21:38:36 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-02 21:38:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-08-02 21:38:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-02 21:38:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-08-02 21:38:37 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-02 21:38:37 --> Login MX_Controller Initialized
DEBUG - 2018-08-02 21:38:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-02 21:38:37 --> Final output sent to browser
DEBUG - 2018-08-02 21:38:37 --> Total execution time: 0.9936
INFO - 2018-08-02 21:38:52 --> Config Class Initialized
INFO - 2018-08-02 21:38:52 --> Hooks Class Initialized
DEBUG - 2018-08-02 21:38:52 --> UTF-8 Support Enabled
INFO - 2018-08-02 21:38:52 --> Utf8 Class Initialized
INFO - 2018-08-02 21:38:52 --> URI Class Initialized
INFO - 2018-08-02 21:38:52 --> Router Class Initialized
INFO - 2018-08-02 21:38:52 --> Output Class Initialized
INFO - 2018-08-02 21:38:52 --> Security Class Initialized
DEBUG - 2018-08-02 21:38:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 21:38:52 --> Input Class Initialized
INFO - 2018-08-02 21:38:52 --> Language Class Initialized
INFO - 2018-08-02 21:38:53 --> Language Class Initialized
INFO - 2018-08-02 21:38:53 --> Config Class Initialized
INFO - 2018-08-02 21:38:53 --> Loader Class Initialized
DEBUG - 2018-08-02 21:38:53 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-02 21:38:53 --> Helper loaded: url_helper
INFO - 2018-08-02 21:38:53 --> Helper loaded: form_helper
INFO - 2018-08-02 21:38:53 --> Helper loaded: date_helper
INFO - 2018-08-02 21:38:53 --> Helper loaded: util_helper
INFO - 2018-08-02 21:38:53 --> Helper loaded: text_helper
INFO - 2018-08-02 21:38:53 --> Helper loaded: string_helper
INFO - 2018-08-02 21:38:53 --> Database Driver Class Initialized
DEBUG - 2018-08-02 21:38:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-02 21:38:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-02 21:38:53 --> Email Class Initialized
INFO - 2018-08-02 21:38:53 --> Controller Class Initialized
DEBUG - 2018-08-02 21:38:53 --> Home MX_Controller Initialized
DEBUG - 2018-08-02 21:38:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-02 21:38:53 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-02 21:38:53 --> Login MX_Controller Initialized
INFO - 2018-08-02 21:38:53 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-02 21:38:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-02 21:38:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-02 21:38:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-08-02 21:38:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-08-02 21:38:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-08-02 21:38:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-08-02 21:38:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-08-02 21:38:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-08-02 21:38:53 --> Final output sent to browser
DEBUG - 2018-08-02 21:38:53 --> Total execution time: 0.7186
INFO - 2018-08-02 21:38:54 --> Config Class Initialized
INFO - 2018-08-02 21:38:54 --> Config Class Initialized
INFO - 2018-08-02 21:38:54 --> Hooks Class Initialized
INFO - 2018-08-02 21:38:54 --> Hooks Class Initialized
DEBUG - 2018-08-02 21:38:54 --> UTF-8 Support Enabled
DEBUG - 2018-08-02 21:38:54 --> UTF-8 Support Enabled
INFO - 2018-08-02 21:38:54 --> Utf8 Class Initialized
INFO - 2018-08-02 21:38:54 --> Config Class Initialized
INFO - 2018-08-02 21:38:54 --> Hooks Class Initialized
INFO - 2018-08-02 21:38:54 --> Utf8 Class Initialized
INFO - 2018-08-02 21:38:54 --> URI Class Initialized
INFO - 2018-08-02 21:38:54 --> URI Class Initialized
DEBUG - 2018-08-02 21:38:54 --> UTF-8 Support Enabled
INFO - 2018-08-02 21:38:54 --> Router Class Initialized
INFO - 2018-08-02 21:38:54 --> Utf8 Class Initialized
INFO - 2018-08-02 21:38:54 --> Router Class Initialized
INFO - 2018-08-02 21:38:54 --> Output Class Initialized
INFO - 2018-08-02 21:38:54 --> URI Class Initialized
INFO - 2018-08-02 21:38:54 --> Output Class Initialized
INFO - 2018-08-02 21:38:54 --> Security Class Initialized
INFO - 2018-08-02 21:38:54 --> Router Class Initialized
INFO - 2018-08-02 21:38:54 --> Output Class Initialized
INFO - 2018-08-02 21:38:54 --> Security Class Initialized
DEBUG - 2018-08-02 21:38:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 21:38:54 --> Input Class Initialized
INFO - 2018-08-02 21:38:54 --> Security Class Initialized
DEBUG - 2018-08-02 21:38:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 21:38:54 --> Language Class Initialized
DEBUG - 2018-08-02 21:38:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 21:38:54 --> Input Class Initialized
INFO - 2018-08-02 21:38:54 --> Input Class Initialized
INFO - 2018-08-02 21:38:54 --> Language Class Initialized
INFO - 2018-08-02 21:38:54 --> Language Class Initialized
INFO - 2018-08-02 21:38:54 --> Config Class Initialized
INFO - 2018-08-02 21:38:54 --> Language Class Initialized
ERROR - 2018-08-02 21:38:54 --> 404 Page Not Found: /index
ERROR - 2018-08-02 21:38:54 --> 404 Page Not Found: /index
INFO - 2018-08-02 21:38:54 --> Loader Class Initialized
INFO - 2018-08-02 21:38:54 --> Config Class Initialized
INFO - 2018-08-02 21:38:54 --> Hooks Class Initialized
DEBUG - 2018-08-02 21:38:54 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
DEBUG - 2018-08-02 21:38:54 --> UTF-8 Support Enabled
INFO - 2018-08-02 21:38:54 --> Utf8 Class Initialized
INFO - 2018-08-02 21:38:54 --> URI Class Initialized
INFO - 2018-08-02 21:38:54 --> Helper loaded: url_helper
INFO - 2018-08-02 21:38:54 --> Helper loaded: form_helper
INFO - 2018-08-02 21:38:54 --> Router Class Initialized
INFO - 2018-08-02 21:38:54 --> Helper loaded: date_helper
INFO - 2018-08-02 21:38:54 --> Output Class Initialized
INFO - 2018-08-02 21:38:54 --> Helper loaded: util_helper
INFO - 2018-08-02 21:38:54 --> Security Class Initialized
DEBUG - 2018-08-02 21:38:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 21:38:54 --> Helper loaded: text_helper
INFO - 2018-08-02 21:38:54 --> Input Class Initialized
INFO - 2018-08-02 21:38:54 --> Helper loaded: string_helper
INFO - 2018-08-02 21:38:54 --> Language Class Initialized
INFO - 2018-08-02 21:38:54 --> Database Driver Class Initialized
ERROR - 2018-08-02 21:38:54 --> 404 Page Not Found: /index
DEBUG - 2018-08-02 21:38:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-02 21:38:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-02 21:38:54 --> Config Class Initialized
INFO - 2018-08-02 21:38:54 --> Hooks Class Initialized
INFO - 2018-08-02 21:38:54 --> Email Class Initialized
INFO - 2018-08-02 21:38:54 --> Controller Class Initialized
DEBUG - 2018-08-02 21:38:54 --> UTF-8 Support Enabled
INFO - 2018-08-02 21:38:54 --> Utf8 Class Initialized
DEBUG - 2018-08-02 21:38:54 --> Home MX_Controller Initialized
INFO - 2018-08-02 21:38:54 --> URI Class Initialized
DEBUG - 2018-08-02 21:38:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-08-02 21:38:54 --> Router Class Initialized
DEBUG - 2018-08-02 21:38:54 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-02 21:38:54 --> Login MX_Controller Initialized
INFO - 2018-08-02 21:38:54 --> Output Class Initialized
INFO - 2018-08-02 21:38:54 --> Language file loaded: language/english/data_lang.php
INFO - 2018-08-02 21:38:54 --> Security Class Initialized
DEBUG - 2018-08-02 21:38:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-02 21:38:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 21:38:54 --> Input Class Initialized
DEBUG - 2018-08-02 21:38:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-02 21:38:54 --> Language Class Initialized
ERROR - 2018-08-02 21:38:54 --> 404 Page Not Found: /index
INFO - 2018-08-02 21:39:02 --> Config Class Initialized
INFO - 2018-08-02 21:39:02 --> Hooks Class Initialized
DEBUG - 2018-08-02 21:39:02 --> UTF-8 Support Enabled
INFO - 2018-08-02 21:39:02 --> Utf8 Class Initialized
INFO - 2018-08-02 21:39:02 --> URI Class Initialized
INFO - 2018-08-02 21:39:02 --> Router Class Initialized
INFO - 2018-08-02 21:39:02 --> Output Class Initialized
INFO - 2018-08-02 21:39:02 --> Security Class Initialized
DEBUG - 2018-08-02 21:39:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 21:39:02 --> Input Class Initialized
INFO - 2018-08-02 21:39:02 --> Language Class Initialized
INFO - 2018-08-02 21:39:02 --> Language Class Initialized
INFO - 2018-08-02 21:39:02 --> Config Class Initialized
INFO - 2018-08-02 21:39:02 --> Loader Class Initialized
DEBUG - 2018-08-02 21:39:02 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-02 21:39:02 --> Helper loaded: url_helper
INFO - 2018-08-02 21:39:02 --> Helper loaded: form_helper
INFO - 2018-08-02 21:39:02 --> Helper loaded: date_helper
INFO - 2018-08-02 21:39:02 --> Helper loaded: util_helper
INFO - 2018-08-02 21:39:02 --> Helper loaded: text_helper
INFO - 2018-08-02 21:39:02 --> Helper loaded: string_helper
INFO - 2018-08-02 21:39:02 --> Database Driver Class Initialized
DEBUG - 2018-08-02 21:39:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-02 21:39:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-02 21:39:02 --> Email Class Initialized
INFO - 2018-08-02 21:39:02 --> Controller Class Initialized
DEBUG - 2018-08-02 21:39:02 --> Home MX_Controller Initialized
DEBUG - 2018-08-02 21:39:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-02 21:39:02 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-02 21:39:02 --> Login MX_Controller Initialized
INFO - 2018-08-02 21:39:02 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-02 21:39:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-02 21:39:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-02 21:39:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-08-02 21:39:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-08-02 21:39:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-08-02 21:39:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-08-02 21:39:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-08-02 21:39:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-08-02 21:39:02 --> Final output sent to browser
DEBUG - 2018-08-02 21:39:02 --> Total execution time: 0.6004
INFO - 2018-08-02 21:39:03 --> Config Class Initialized
INFO - 2018-08-02 21:39:03 --> Config Class Initialized
INFO - 2018-08-02 21:39:03 --> Hooks Class Initialized
INFO - 2018-08-02 21:39:03 --> Hooks Class Initialized
DEBUG - 2018-08-02 21:39:03 --> UTF-8 Support Enabled
DEBUG - 2018-08-02 21:39:03 --> UTF-8 Support Enabled
INFO - 2018-08-02 21:39:03 --> Config Class Initialized
INFO - 2018-08-02 21:39:03 --> Hooks Class Initialized
INFO - 2018-08-02 21:39:03 --> Utf8 Class Initialized
INFO - 2018-08-02 21:39:03 --> Utf8 Class Initialized
INFO - 2018-08-02 21:39:03 --> URI Class Initialized
DEBUG - 2018-08-02 21:39:03 --> UTF-8 Support Enabled
INFO - 2018-08-02 21:39:03 --> Router Class Initialized
INFO - 2018-08-02 21:39:03 --> Output Class Initialized
INFO - 2018-08-02 21:39:03 --> URI Class Initialized
INFO - 2018-08-02 21:39:03 --> Utf8 Class Initialized
INFO - 2018-08-02 21:39:03 --> Security Class Initialized
INFO - 2018-08-02 21:39:03 --> Router Class Initialized
INFO - 2018-08-02 21:39:03 --> URI Class Initialized
INFO - 2018-08-02 21:39:03 --> Output Class Initialized
INFO - 2018-08-02 21:39:03 --> Security Class Initialized
DEBUG - 2018-08-02 21:39:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-08-02 21:39:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 21:39:03 --> Input Class Initialized
INFO - 2018-08-02 21:39:03 --> Router Class Initialized
INFO - 2018-08-02 21:39:03 --> Input Class Initialized
INFO - 2018-08-02 21:39:03 --> Language Class Initialized
INFO - 2018-08-02 21:39:03 --> Output Class Initialized
INFO - 2018-08-02 21:39:03 --> Language Class Initialized
INFO - 2018-08-02 21:39:03 --> Security Class Initialized
ERROR - 2018-08-02 21:39:03 --> 404 Page Not Found: /index
DEBUG - 2018-08-02 21:39:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-08-02 21:39:03 --> 404 Page Not Found: /index
INFO - 2018-08-02 21:39:03 --> Input Class Initialized
INFO - 2018-08-02 21:39:03 --> Config Class Initialized
INFO - 2018-08-02 21:39:03 --> Hooks Class Initialized
INFO - 2018-08-02 21:39:03 --> Language Class Initialized
DEBUG - 2018-08-02 21:39:03 --> UTF-8 Support Enabled
INFO - 2018-08-02 21:39:03 --> Language Class Initialized
INFO - 2018-08-02 21:39:03 --> Config Class Initialized
INFO - 2018-08-02 21:39:03 --> Utf8 Class Initialized
INFO - 2018-08-02 21:39:03 --> URI Class Initialized
INFO - 2018-08-02 21:39:03 --> Loader Class Initialized
DEBUG - 2018-08-02 21:39:03 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-02 21:39:03 --> Router Class Initialized
INFO - 2018-08-02 21:39:03 --> Helper loaded: url_helper
INFO - 2018-08-02 21:39:03 --> Output Class Initialized
INFO - 2018-08-02 21:39:03 --> Security Class Initialized
INFO - 2018-08-02 21:39:03 --> Helper loaded: form_helper
DEBUG - 2018-08-02 21:39:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 21:39:03 --> Helper loaded: date_helper
INFO - 2018-08-02 21:39:03 --> Input Class Initialized
INFO - 2018-08-02 21:39:03 --> Language Class Initialized
INFO - 2018-08-02 21:39:03 --> Helper loaded: util_helper
ERROR - 2018-08-02 21:39:03 --> 404 Page Not Found: /index
INFO - 2018-08-02 21:39:03 --> Helper loaded: text_helper
INFO - 2018-08-02 21:39:03 --> Helper loaded: string_helper
INFO - 2018-08-02 21:39:03 --> Config Class Initialized
INFO - 2018-08-02 21:39:03 --> Hooks Class Initialized
INFO - 2018-08-02 21:39:03 --> Database Driver Class Initialized
DEBUG - 2018-08-02 21:39:03 --> UTF-8 Support Enabled
DEBUG - 2018-08-02 21:39:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-02 21:39:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-02 21:39:03 --> Utf8 Class Initialized
INFO - 2018-08-02 21:39:03 --> URI Class Initialized
INFO - 2018-08-02 21:39:03 --> Email Class Initialized
INFO - 2018-08-02 21:39:03 --> Controller Class Initialized
INFO - 2018-08-02 21:39:04 --> Router Class Initialized
DEBUG - 2018-08-02 21:39:04 --> Home MX_Controller Initialized
INFO - 2018-08-02 21:39:04 --> Output Class Initialized
DEBUG - 2018-08-02 21:39:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-08-02 21:39:04 --> Security Class Initialized
DEBUG - 2018-08-02 21:39:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-08-02 21:39:04 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-02 21:39:04 --> Login MX_Controller Initialized
INFO - 2018-08-02 21:39:04 --> Input Class Initialized
INFO - 2018-08-02 21:39:04 --> Language file loaded: language/english/data_lang.php
INFO - 2018-08-02 21:39:04 --> Language Class Initialized
DEBUG - 2018-08-02 21:39:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
ERROR - 2018-08-02 21:39:04 --> 404 Page Not Found: /index
DEBUG - 2018-08-02 21:39:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-02 21:39:06 --> Config Class Initialized
INFO - 2018-08-02 21:39:06 --> Hooks Class Initialized
DEBUG - 2018-08-02 21:39:06 --> UTF-8 Support Enabled
INFO - 2018-08-02 21:39:06 --> Utf8 Class Initialized
INFO - 2018-08-02 21:39:06 --> URI Class Initialized
INFO - 2018-08-02 21:39:06 --> Router Class Initialized
INFO - 2018-08-02 21:39:06 --> Output Class Initialized
INFO - 2018-08-02 21:39:06 --> Security Class Initialized
DEBUG - 2018-08-02 21:39:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 21:39:06 --> Input Class Initialized
INFO - 2018-08-02 21:39:06 --> Language Class Initialized
INFO - 2018-08-02 21:39:06 --> Language Class Initialized
INFO - 2018-08-02 21:39:06 --> Config Class Initialized
INFO - 2018-08-02 21:39:06 --> Loader Class Initialized
DEBUG - 2018-08-02 21:39:06 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-02 21:39:06 --> Helper loaded: url_helper
INFO - 2018-08-02 21:39:06 --> Helper loaded: form_helper
INFO - 2018-08-02 21:39:06 --> Helper loaded: date_helper
INFO - 2018-08-02 21:39:06 --> Helper loaded: util_helper
INFO - 2018-08-02 21:39:06 --> Helper loaded: text_helper
INFO - 2018-08-02 21:39:06 --> Helper loaded: string_helper
INFO - 2018-08-02 21:39:06 --> Database Driver Class Initialized
DEBUG - 2018-08-02 21:39:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-02 21:39:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-02 21:39:06 --> Email Class Initialized
INFO - 2018-08-02 21:39:06 --> Controller Class Initialized
DEBUG - 2018-08-02 21:39:06 --> Home MX_Controller Initialized
DEBUG - 2018-08-02 21:39:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-02 21:39:06 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-02 21:39:06 --> Login MX_Controller Initialized
INFO - 2018-08-02 21:39:06 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-02 21:39:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-02 21:39:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-02 21:39:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-08-02 21:39:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-08-02 21:39:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-08-02 21:39:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-08-02 21:39:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-08-02 21:39:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-08-02 21:39:06 --> Final output sent to browser
DEBUG - 2018-08-02 21:39:06 --> Total execution time: 0.5784
INFO - 2018-08-02 21:39:07 --> Config Class Initialized
INFO - 2018-08-02 21:39:07 --> Config Class Initialized
INFO - 2018-08-02 21:39:07 --> Hooks Class Initialized
INFO - 2018-08-02 21:39:07 --> Hooks Class Initialized
DEBUG - 2018-08-02 21:39:07 --> UTF-8 Support Enabled
DEBUG - 2018-08-02 21:39:07 --> UTF-8 Support Enabled
INFO - 2018-08-02 21:39:07 --> Config Class Initialized
INFO - 2018-08-02 21:39:07 --> Utf8 Class Initialized
INFO - 2018-08-02 21:39:07 --> Hooks Class Initialized
INFO - 2018-08-02 21:39:07 --> URI Class Initialized
DEBUG - 2018-08-02 21:39:07 --> UTF-8 Support Enabled
INFO - 2018-08-02 21:39:07 --> Utf8 Class Initialized
INFO - 2018-08-02 21:39:07 --> Utf8 Class Initialized
INFO - 2018-08-02 21:39:07 --> Router Class Initialized
INFO - 2018-08-02 21:39:07 --> URI Class Initialized
INFO - 2018-08-02 21:39:07 --> URI Class Initialized
INFO - 2018-08-02 21:39:07 --> Router Class Initialized
INFO - 2018-08-02 21:39:07 --> Output Class Initialized
INFO - 2018-08-02 21:39:07 --> Output Class Initialized
INFO - 2018-08-02 21:39:07 --> Security Class Initialized
INFO - 2018-08-02 21:39:07 --> Security Class Initialized
DEBUG - 2018-08-02 21:39:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-08-02 21:39:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 21:39:07 --> Input Class Initialized
INFO - 2018-08-02 21:39:07 --> Language Class Initialized
INFO - 2018-08-02 21:39:07 --> Router Class Initialized
INFO - 2018-08-02 21:39:07 --> Output Class Initialized
INFO - 2018-08-02 21:39:07 --> Language Class Initialized
INFO - 2018-08-02 21:39:07 --> Input Class Initialized
INFO - 2018-08-02 21:39:07 --> Config Class Initialized
INFO - 2018-08-02 21:39:07 --> Language Class Initialized
INFO - 2018-08-02 21:39:07 --> Security Class Initialized
INFO - 2018-08-02 21:39:07 --> Loader Class Initialized
DEBUG - 2018-08-02 21:39:07 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
ERROR - 2018-08-02 21:39:07 --> 404 Page Not Found: /index
DEBUG - 2018-08-02 21:39:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 21:39:07 --> Helper loaded: url_helper
INFO - 2018-08-02 21:39:07 --> Config Class Initialized
INFO - 2018-08-02 21:39:07 --> Input Class Initialized
INFO - 2018-08-02 21:39:07 --> Hooks Class Initialized
INFO - 2018-08-02 21:39:07 --> Helper loaded: form_helper
INFO - 2018-08-02 21:39:07 --> Helper loaded: date_helper
DEBUG - 2018-08-02 21:39:07 --> UTF-8 Support Enabled
INFO - 2018-08-02 21:39:07 --> Utf8 Class Initialized
INFO - 2018-08-02 21:39:07 --> Helper loaded: util_helper
INFO - 2018-08-02 21:39:07 --> Language Class Initialized
INFO - 2018-08-02 21:39:07 --> URI Class Initialized
INFO - 2018-08-02 21:39:07 --> Helper loaded: text_helper
INFO - 2018-08-02 21:39:07 --> Helper loaded: string_helper
INFO - 2018-08-02 21:39:07 --> Router Class Initialized
INFO - 2018-08-02 21:39:07 --> Output Class Initialized
INFO - 2018-08-02 21:39:07 --> Database Driver Class Initialized
ERROR - 2018-08-02 21:39:07 --> 404 Page Not Found: /index
INFO - 2018-08-02 21:39:07 --> Security Class Initialized
DEBUG - 2018-08-02 21:39:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-02 21:39:07 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-08-02 21:39:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 21:39:07 --> Input Class Initialized
INFO - 2018-08-02 21:39:07 --> Email Class Initialized
INFO - 2018-08-02 21:39:07 --> Controller Class Initialized
INFO - 2018-08-02 21:39:07 --> Language Class Initialized
DEBUG - 2018-08-02 21:39:07 --> Home MX_Controller Initialized
ERROR - 2018-08-02 21:39:07 --> 404 Page Not Found: /index
DEBUG - 2018-08-02 21:39:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-08-02 21:39:07 --> Config Class Initialized
INFO - 2018-08-02 21:39:07 --> Hooks Class Initialized
DEBUG - 2018-08-02 21:39:07 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-02 21:39:07 --> Login MX_Controller Initialized
DEBUG - 2018-08-02 21:39:07 --> UTF-8 Support Enabled
INFO - 2018-08-02 21:39:07 --> Utf8 Class Initialized
INFO - 2018-08-02 21:39:07 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-02 21:39:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-08-02 21:39:07 --> URI Class Initialized
DEBUG - 2018-08-02 21:39:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-02 21:39:07 --> Router Class Initialized
INFO - 2018-08-02 21:39:07 --> Output Class Initialized
INFO - 2018-08-02 21:39:07 --> Security Class Initialized
DEBUG - 2018-08-02 21:39:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 21:39:07 --> Input Class Initialized
INFO - 2018-08-02 21:39:07 --> Language Class Initialized
ERROR - 2018-08-02 21:39:07 --> 404 Page Not Found: /index
INFO - 2018-08-02 21:39:27 --> Config Class Initialized
INFO - 2018-08-02 21:39:27 --> Hooks Class Initialized
DEBUG - 2018-08-02 21:39:27 --> UTF-8 Support Enabled
INFO - 2018-08-02 21:39:27 --> Utf8 Class Initialized
INFO - 2018-08-02 21:39:27 --> URI Class Initialized
INFO - 2018-08-02 21:39:27 --> Router Class Initialized
INFO - 2018-08-02 21:39:27 --> Output Class Initialized
INFO - 2018-08-02 21:39:27 --> Security Class Initialized
DEBUG - 2018-08-02 21:39:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 21:39:27 --> Input Class Initialized
INFO - 2018-08-02 21:39:27 --> Language Class Initialized
INFO - 2018-08-02 21:39:27 --> Language Class Initialized
INFO - 2018-08-02 21:39:27 --> Config Class Initialized
INFO - 2018-08-02 21:39:27 --> Loader Class Initialized
DEBUG - 2018-08-02 21:39:27 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-02 21:39:27 --> Helper loaded: url_helper
INFO - 2018-08-02 21:39:27 --> Helper loaded: form_helper
INFO - 2018-08-02 21:39:27 --> Helper loaded: date_helper
INFO - 2018-08-02 21:39:27 --> Helper loaded: util_helper
INFO - 2018-08-02 21:39:27 --> Helper loaded: text_helper
INFO - 2018-08-02 21:39:27 --> Helper loaded: string_helper
INFO - 2018-08-02 21:39:27 --> Database Driver Class Initialized
DEBUG - 2018-08-02 21:39:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-02 21:39:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-02 21:39:27 --> Email Class Initialized
INFO - 2018-08-02 21:39:27 --> Controller Class Initialized
DEBUG - 2018-08-02 21:39:27 --> videos MX_Controller Initialized
INFO - 2018-08-02 21:39:27 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-02 21:39:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-08-02 21:39:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-02 21:39:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-08-02 21:39:27 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-02 21:39:27 --> Login MX_Controller Initialized
DEBUG - 2018-08-02 21:39:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-02 21:39:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-08-02 21:39:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-08-02 21:39:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-08-02 21:39:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-08-02 21:39:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-08-02 21:39:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/videos/create_video.php
INFO - 2018-08-02 21:39:27 --> Final output sent to browser
DEBUG - 2018-08-02 21:39:28 --> Total execution time: 0.7267
INFO - 2018-08-02 21:39:28 --> Config Class Initialized
INFO - 2018-08-02 21:39:28 --> Hooks Class Initialized
DEBUG - 2018-08-02 21:39:28 --> UTF-8 Support Enabled
INFO - 2018-08-02 21:39:28 --> Utf8 Class Initialized
INFO - 2018-08-02 21:39:28 --> URI Class Initialized
INFO - 2018-08-02 21:39:28 --> Router Class Initialized
INFO - 2018-08-02 21:39:28 --> Output Class Initialized
INFO - 2018-08-02 21:39:28 --> Security Class Initialized
DEBUG - 2018-08-02 21:39:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 21:39:29 --> Input Class Initialized
INFO - 2018-08-02 21:39:29 --> Language Class Initialized
ERROR - 2018-08-02 21:39:29 --> 404 Page Not Found: /index
INFO - 2018-08-02 21:39:32 --> Config Class Initialized
INFO - 2018-08-02 21:39:32 --> Hooks Class Initialized
DEBUG - 2018-08-02 21:39:32 --> UTF-8 Support Enabled
INFO - 2018-08-02 21:39:32 --> Utf8 Class Initialized
INFO - 2018-08-02 21:39:32 --> URI Class Initialized
INFO - 2018-08-02 21:39:32 --> Router Class Initialized
INFO - 2018-08-02 21:39:32 --> Output Class Initialized
INFO - 2018-08-02 21:39:32 --> Security Class Initialized
DEBUG - 2018-08-02 21:39:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 21:39:32 --> Input Class Initialized
INFO - 2018-08-02 21:39:32 --> Language Class Initialized
INFO - 2018-08-02 21:39:32 --> Language Class Initialized
INFO - 2018-08-02 21:39:32 --> Config Class Initialized
INFO - 2018-08-02 21:39:32 --> Loader Class Initialized
DEBUG - 2018-08-02 21:39:32 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-02 21:39:32 --> Helper loaded: url_helper
INFO - 2018-08-02 21:39:32 --> Helper loaded: form_helper
INFO - 2018-08-02 21:39:32 --> Helper loaded: date_helper
INFO - 2018-08-02 21:39:32 --> Helper loaded: util_helper
INFO - 2018-08-02 21:39:32 --> Helper loaded: text_helper
INFO - 2018-08-02 21:39:32 --> Helper loaded: string_helper
INFO - 2018-08-02 21:39:32 --> Database Driver Class Initialized
DEBUG - 2018-08-02 21:39:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-02 21:39:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-02 21:39:32 --> Email Class Initialized
INFO - 2018-08-02 21:39:32 --> Controller Class Initialized
DEBUG - 2018-08-02 21:39:32 --> videos MX_Controller Initialized
INFO - 2018-08-02 21:39:32 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-02 21:39:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-08-02 21:39:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-02 21:39:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-08-02 21:39:32 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-02 21:39:32 --> Login MX_Controller Initialized
DEBUG - 2018-08-02 21:39:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-02 21:39:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-08-02 21:39:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-08-02 21:39:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-08-02 21:39:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-08-02 21:39:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-08-02 21:39:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/videos/videos.php
INFO - 2018-08-02 21:39:32 --> Final output sent to browser
DEBUG - 2018-08-02 21:39:32 --> Total execution time: 0.6693
INFO - 2018-08-02 21:39:33 --> Config Class Initialized
INFO - 2018-08-02 21:39:33 --> Hooks Class Initialized
DEBUG - 2018-08-02 21:39:33 --> UTF-8 Support Enabled
INFO - 2018-08-02 21:39:33 --> Utf8 Class Initialized
INFO - 2018-08-02 21:39:33 --> URI Class Initialized
INFO - 2018-08-02 21:39:33 --> Router Class Initialized
INFO - 2018-08-02 21:39:33 --> Output Class Initialized
INFO - 2018-08-02 21:39:33 --> Security Class Initialized
DEBUG - 2018-08-02 21:39:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 21:39:33 --> Input Class Initialized
INFO - 2018-08-02 21:39:33 --> Language Class Initialized
INFO - 2018-08-02 21:39:33 --> Language Class Initialized
INFO - 2018-08-02 21:39:33 --> Config Class Initialized
INFO - 2018-08-02 21:39:33 --> Loader Class Initialized
DEBUG - 2018-08-02 21:39:33 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-02 21:39:33 --> Helper loaded: url_helper
INFO - 2018-08-02 21:39:33 --> Helper loaded: form_helper
INFO - 2018-08-02 21:39:33 --> Helper loaded: date_helper
INFO - 2018-08-02 21:39:33 --> Helper loaded: util_helper
INFO - 2018-08-02 21:39:33 --> Helper loaded: text_helper
INFO - 2018-08-02 21:39:33 --> Helper loaded: string_helper
INFO - 2018-08-02 21:39:33 --> Database Driver Class Initialized
DEBUG - 2018-08-02 21:39:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-02 21:39:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-02 21:39:33 --> Email Class Initialized
INFO - 2018-08-02 21:39:33 --> Controller Class Initialized
DEBUG - 2018-08-02 21:39:33 --> videos MX_Controller Initialized
INFO - 2018-08-02 21:39:33 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-02 21:39:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-08-02 21:39:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-02 21:39:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-08-02 21:39:33 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-02 21:39:33 --> Login MX_Controller Initialized
DEBUG - 2018-08-02 21:39:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-02 21:39:33 --> Final output sent to browser
DEBUG - 2018-08-02 21:39:33 --> Total execution time: 0.6691
INFO - 2018-08-02 21:39:36 --> Config Class Initialized
INFO - 2018-08-02 21:39:36 --> Hooks Class Initialized
DEBUG - 2018-08-02 21:39:36 --> UTF-8 Support Enabled
INFO - 2018-08-02 21:39:36 --> Utf8 Class Initialized
INFO - 2018-08-02 21:39:36 --> URI Class Initialized
INFO - 2018-08-02 21:39:36 --> Router Class Initialized
INFO - 2018-08-02 21:39:36 --> Output Class Initialized
INFO - 2018-08-02 21:39:36 --> Security Class Initialized
DEBUG - 2018-08-02 21:39:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 21:39:36 --> Input Class Initialized
INFO - 2018-08-02 21:39:36 --> Language Class Initialized
INFO - 2018-08-02 21:39:36 --> Language Class Initialized
INFO - 2018-08-02 21:39:36 --> Config Class Initialized
INFO - 2018-08-02 21:39:36 --> Loader Class Initialized
DEBUG - 2018-08-02 21:39:36 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-02 21:39:36 --> Helper loaded: url_helper
INFO - 2018-08-02 21:39:37 --> Helper loaded: form_helper
INFO - 2018-08-02 21:39:37 --> Helper loaded: date_helper
INFO - 2018-08-02 21:39:37 --> Helper loaded: util_helper
INFO - 2018-08-02 21:39:37 --> Helper loaded: text_helper
INFO - 2018-08-02 21:39:37 --> Helper loaded: string_helper
INFO - 2018-08-02 21:39:37 --> Database Driver Class Initialized
DEBUG - 2018-08-02 21:39:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-02 21:39:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-02 21:39:37 --> Email Class Initialized
INFO - 2018-08-02 21:39:37 --> Controller Class Initialized
DEBUG - 2018-08-02 21:39:37 --> videos MX_Controller Initialized
INFO - 2018-08-02 21:39:37 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-02 21:39:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-08-02 21:39:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-02 21:39:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-08-02 21:39:37 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-02 21:39:37 --> Login MX_Controller Initialized
DEBUG - 2018-08-02 21:39:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-02 21:39:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-08-02 21:39:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-08-02 21:39:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-08-02 21:39:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-08-02 21:39:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-08-02 21:39:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/videos/create_video.php
INFO - 2018-08-02 21:39:37 --> Final output sent to browser
DEBUG - 2018-08-02 21:39:37 --> Total execution time: 0.6227
INFO - 2018-08-02 21:39:37 --> Config Class Initialized
INFO - 2018-08-02 21:39:37 --> Hooks Class Initialized
DEBUG - 2018-08-02 21:39:37 --> UTF-8 Support Enabled
INFO - 2018-08-02 21:39:37 --> Utf8 Class Initialized
INFO - 2018-08-02 21:39:37 --> URI Class Initialized
INFO - 2018-08-02 21:39:37 --> Router Class Initialized
INFO - 2018-08-02 21:39:37 --> Output Class Initialized
INFO - 2018-08-02 21:39:37 --> Security Class Initialized
DEBUG - 2018-08-02 21:39:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 21:39:37 --> Input Class Initialized
INFO - 2018-08-02 21:39:37 --> Language Class Initialized
ERROR - 2018-08-02 21:39:37 --> 404 Page Not Found: /index
INFO - 2018-08-02 21:39:47 --> Config Class Initialized
INFO - 2018-08-02 21:39:47 --> Hooks Class Initialized
DEBUG - 2018-08-02 21:39:47 --> UTF-8 Support Enabled
INFO - 2018-08-02 21:39:47 --> Utf8 Class Initialized
INFO - 2018-08-02 21:39:47 --> URI Class Initialized
INFO - 2018-08-02 21:39:47 --> Router Class Initialized
INFO - 2018-08-02 21:39:47 --> Output Class Initialized
INFO - 2018-08-02 21:39:47 --> Security Class Initialized
DEBUG - 2018-08-02 21:39:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 21:39:47 --> Input Class Initialized
INFO - 2018-08-02 21:39:47 --> Language Class Initialized
INFO - 2018-08-02 21:39:47 --> Language Class Initialized
INFO - 2018-08-02 21:39:47 --> Config Class Initialized
INFO - 2018-08-02 21:39:47 --> Loader Class Initialized
DEBUG - 2018-08-02 21:39:47 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-02 21:39:47 --> Helper loaded: url_helper
INFO - 2018-08-02 21:39:47 --> Helper loaded: form_helper
INFO - 2018-08-02 21:39:47 --> Helper loaded: date_helper
INFO - 2018-08-02 21:39:47 --> Helper loaded: util_helper
INFO - 2018-08-02 21:39:47 --> Helper loaded: text_helper
INFO - 2018-08-02 21:39:47 --> Helper loaded: string_helper
INFO - 2018-08-02 21:39:47 --> Database Driver Class Initialized
DEBUG - 2018-08-02 21:39:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-02 21:39:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-02 21:39:48 --> Email Class Initialized
INFO - 2018-08-02 21:39:48 --> Controller Class Initialized
DEBUG - 2018-08-02 21:39:48 --> videos MX_Controller Initialized
INFO - 2018-08-02 21:39:48 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-02 21:39:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-08-02 21:39:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-02 21:39:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-08-02 21:39:48 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-02 21:39:48 --> Login MX_Controller Initialized
DEBUG - 2018-08-02 21:39:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-02 21:39:48 --> Config Class Initialized
INFO - 2018-08-02 21:39:48 --> Hooks Class Initialized
DEBUG - 2018-08-02 21:39:48 --> UTF-8 Support Enabled
INFO - 2018-08-02 21:39:48 --> Utf8 Class Initialized
INFO - 2018-08-02 21:39:48 --> URI Class Initialized
INFO - 2018-08-02 21:39:48 --> Router Class Initialized
INFO - 2018-08-02 21:39:48 --> Output Class Initialized
INFO - 2018-08-02 21:39:48 --> Security Class Initialized
DEBUG - 2018-08-02 21:39:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 21:39:48 --> Input Class Initialized
INFO - 2018-08-02 21:39:48 --> Language Class Initialized
INFO - 2018-08-02 21:39:48 --> Language Class Initialized
INFO - 2018-08-02 21:39:48 --> Config Class Initialized
INFO - 2018-08-02 21:39:48 --> Loader Class Initialized
DEBUG - 2018-08-02 21:39:48 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-02 21:39:48 --> Helper loaded: url_helper
INFO - 2018-08-02 21:39:48 --> Helper loaded: form_helper
INFO - 2018-08-02 21:39:48 --> Helper loaded: date_helper
INFO - 2018-08-02 21:39:48 --> Helper loaded: util_helper
INFO - 2018-08-02 21:39:48 --> Helper loaded: text_helper
INFO - 2018-08-02 21:39:48 --> Helper loaded: string_helper
INFO - 2018-08-02 21:39:48 --> Database Driver Class Initialized
DEBUG - 2018-08-02 21:39:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-02 21:39:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-02 21:39:48 --> Email Class Initialized
INFO - 2018-08-02 21:39:48 --> Controller Class Initialized
DEBUG - 2018-08-02 21:39:48 --> videos MX_Controller Initialized
INFO - 2018-08-02 21:39:48 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-02 21:39:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-08-02 21:39:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-02 21:39:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-08-02 21:39:48 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-02 21:39:48 --> Login MX_Controller Initialized
DEBUG - 2018-08-02 21:39:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-02 21:39:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-08-02 21:39:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-08-02 21:39:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-08-02 21:39:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-08-02 21:39:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-08-02 21:39:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/videos/videos.php
INFO - 2018-08-02 21:39:49 --> Final output sent to browser
DEBUG - 2018-08-02 21:39:49 --> Total execution time: 0.6683
INFO - 2018-08-02 21:39:49 --> Config Class Initialized
INFO - 2018-08-02 21:39:49 --> Hooks Class Initialized
DEBUG - 2018-08-02 21:39:49 --> UTF-8 Support Enabled
INFO - 2018-08-02 21:39:49 --> Utf8 Class Initialized
INFO - 2018-08-02 21:39:49 --> URI Class Initialized
INFO - 2018-08-02 21:39:49 --> Router Class Initialized
INFO - 2018-08-02 21:39:49 --> Output Class Initialized
INFO - 2018-08-02 21:39:49 --> Security Class Initialized
DEBUG - 2018-08-02 21:39:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 21:39:49 --> Input Class Initialized
INFO - 2018-08-02 21:39:49 --> Language Class Initialized
INFO - 2018-08-02 21:39:49 --> Language Class Initialized
INFO - 2018-08-02 21:39:49 --> Config Class Initialized
INFO - 2018-08-02 21:39:49 --> Loader Class Initialized
DEBUG - 2018-08-02 21:39:49 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-02 21:39:49 --> Helper loaded: url_helper
INFO - 2018-08-02 21:39:49 --> Helper loaded: form_helper
INFO - 2018-08-02 21:39:49 --> Helper loaded: date_helper
INFO - 2018-08-02 21:39:49 --> Helper loaded: util_helper
INFO - 2018-08-02 21:39:49 --> Helper loaded: text_helper
INFO - 2018-08-02 21:39:50 --> Helper loaded: string_helper
INFO - 2018-08-02 21:39:50 --> Database Driver Class Initialized
DEBUG - 2018-08-02 21:39:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-02 21:39:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-02 21:39:50 --> Email Class Initialized
INFO - 2018-08-02 21:39:50 --> Controller Class Initialized
DEBUG - 2018-08-02 21:39:50 --> videos MX_Controller Initialized
INFO - 2018-08-02 21:39:50 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-02 21:39:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-08-02 21:39:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-02 21:39:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-08-02 21:39:50 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-02 21:39:50 --> Login MX_Controller Initialized
DEBUG - 2018-08-02 21:39:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-02 21:39:50 --> Final output sent to browser
DEBUG - 2018-08-02 21:39:50 --> Total execution time: 0.8687
INFO - 2018-08-02 21:39:58 --> Config Class Initialized
INFO - 2018-08-02 21:39:58 --> Hooks Class Initialized
DEBUG - 2018-08-02 21:39:59 --> UTF-8 Support Enabled
INFO - 2018-08-02 21:39:59 --> Utf8 Class Initialized
INFO - 2018-08-02 21:39:59 --> URI Class Initialized
INFO - 2018-08-02 21:39:59 --> Router Class Initialized
INFO - 2018-08-02 21:39:59 --> Output Class Initialized
INFO - 2018-08-02 21:39:59 --> Security Class Initialized
DEBUG - 2018-08-02 21:39:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 21:39:59 --> Input Class Initialized
INFO - 2018-08-02 21:39:59 --> Language Class Initialized
INFO - 2018-08-02 21:39:59 --> Language Class Initialized
INFO - 2018-08-02 21:39:59 --> Config Class Initialized
INFO - 2018-08-02 21:39:59 --> Loader Class Initialized
DEBUG - 2018-08-02 21:39:59 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-02 21:39:59 --> Helper loaded: url_helper
INFO - 2018-08-02 21:39:59 --> Helper loaded: form_helper
INFO - 2018-08-02 21:39:59 --> Helper loaded: date_helper
INFO - 2018-08-02 21:39:59 --> Helper loaded: util_helper
INFO - 2018-08-02 21:39:59 --> Helper loaded: text_helper
INFO - 2018-08-02 21:39:59 --> Helper loaded: string_helper
INFO - 2018-08-02 21:39:59 --> Database Driver Class Initialized
DEBUG - 2018-08-02 21:39:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-02 21:39:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-02 21:39:59 --> Email Class Initialized
INFO - 2018-08-02 21:39:59 --> Controller Class Initialized
DEBUG - 2018-08-02 21:39:59 --> Home MX_Controller Initialized
DEBUG - 2018-08-02 21:39:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-02 21:39:59 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-02 21:39:59 --> Login MX_Controller Initialized
INFO - 2018-08-02 21:39:59 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-02 21:39:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-02 21:39:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-02 21:39:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-08-02 21:39:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-08-02 21:39:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-08-02 21:39:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-08-02 21:39:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-08-02 21:39:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-08-02 21:39:59 --> Final output sent to browser
DEBUG - 2018-08-02 21:39:59 --> Total execution time: 0.5756
INFO - 2018-08-02 21:40:00 --> Config Class Initialized
INFO - 2018-08-02 21:40:00 --> Config Class Initialized
INFO - 2018-08-02 21:40:00 --> Hooks Class Initialized
INFO - 2018-08-02 21:40:00 --> Config Class Initialized
INFO - 2018-08-02 21:40:00 --> Hooks Class Initialized
DEBUG - 2018-08-02 21:40:00 --> UTF-8 Support Enabled
INFO - 2018-08-02 21:40:00 --> Hooks Class Initialized
DEBUG - 2018-08-02 21:40:00 --> UTF-8 Support Enabled
INFO - 2018-08-02 21:40:00 --> Utf8 Class Initialized
INFO - 2018-08-02 21:40:00 --> Utf8 Class Initialized
DEBUG - 2018-08-02 21:40:00 --> UTF-8 Support Enabled
INFO - 2018-08-02 21:40:00 --> URI Class Initialized
INFO - 2018-08-02 21:40:00 --> Router Class Initialized
INFO - 2018-08-02 21:40:00 --> Output Class Initialized
INFO - 2018-08-02 21:40:00 --> Security Class Initialized
DEBUG - 2018-08-02 21:40:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 21:40:00 --> Input Class Initialized
INFO - 2018-08-02 21:40:00 --> Language Class Initialized
INFO - 2018-08-02 21:40:00 --> Language Class Initialized
INFO - 2018-08-02 21:40:00 --> Config Class Initialized
INFO - 2018-08-02 21:40:00 --> Loader Class Initialized
DEBUG - 2018-08-02 21:40:00 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-02 21:40:00 --> URI Class Initialized
INFO - 2018-08-02 21:40:00 --> Utf8 Class Initialized
INFO - 2018-08-02 21:40:00 --> URI Class Initialized
INFO - 2018-08-02 21:40:00 --> Helper loaded: url_helper
INFO - 2018-08-02 21:40:00 --> Router Class Initialized
INFO - 2018-08-02 21:40:00 --> Output Class Initialized
INFO - 2018-08-02 21:40:00 --> Router Class Initialized
INFO - 2018-08-02 21:40:00 --> Helper loaded: form_helper
INFO - 2018-08-02 21:40:00 --> Helper loaded: date_helper
INFO - 2018-08-02 21:40:00 --> Output Class Initialized
INFO - 2018-08-02 21:40:00 --> Security Class Initialized
INFO - 2018-08-02 21:40:00 --> Helper loaded: util_helper
DEBUG - 2018-08-02 21:40:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 21:40:00 --> Security Class Initialized
INFO - 2018-08-02 21:40:00 --> Input Class Initialized
INFO - 2018-08-02 21:40:00 --> Helper loaded: text_helper
DEBUG - 2018-08-02 21:40:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 21:40:00 --> Language Class Initialized
INFO - 2018-08-02 21:40:00 --> Input Class Initialized
INFO - 2018-08-02 21:40:00 --> Helper loaded: string_helper
ERROR - 2018-08-02 21:40:00 --> 404 Page Not Found: /index
INFO - 2018-08-02 21:40:00 --> Language Class Initialized
INFO - 2018-08-02 21:40:00 --> Database Driver Class Initialized
ERROR - 2018-08-02 21:40:00 --> 404 Page Not Found: /index
DEBUG - 2018-08-02 21:40:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-02 21:40:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-02 21:40:00 --> Email Class Initialized
INFO - 2018-08-02 21:40:00 --> Config Class Initialized
INFO - 2018-08-02 21:40:00 --> Hooks Class Initialized
INFO - 2018-08-02 21:40:00 --> Controller Class Initialized
DEBUG - 2018-08-02 21:40:00 --> Home MX_Controller Initialized
DEBUG - 2018-08-02 21:40:00 --> UTF-8 Support Enabled
INFO - 2018-08-02 21:40:00 --> Utf8 Class Initialized
DEBUG - 2018-08-02 21:40:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-08-02 21:40:00 --> URI Class Initialized
DEBUG - 2018-08-02 21:40:00 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-02 21:40:00 --> Login MX_Controller Initialized
INFO - 2018-08-02 21:40:00 --> Router Class Initialized
INFO - 2018-08-02 21:40:00 --> Language file loaded: language/english/data_lang.php
INFO - 2018-08-02 21:40:00 --> Output Class Initialized
DEBUG - 2018-08-02 21:40:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-08-02 21:40:00 --> Security Class Initialized
DEBUG - 2018-08-02 21:40:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-02 21:40:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 21:40:00 --> Input Class Initialized
INFO - 2018-08-02 21:40:01 --> Language Class Initialized
ERROR - 2018-08-02 21:40:01 --> 404 Page Not Found: /index
INFO - 2018-08-02 21:40:01 --> Config Class Initialized
INFO - 2018-08-02 21:40:01 --> Hooks Class Initialized
DEBUG - 2018-08-02 21:40:01 --> UTF-8 Support Enabled
INFO - 2018-08-02 21:40:01 --> Utf8 Class Initialized
INFO - 2018-08-02 21:40:01 --> URI Class Initialized
INFO - 2018-08-02 21:40:01 --> Router Class Initialized
INFO - 2018-08-02 21:40:01 --> Output Class Initialized
INFO - 2018-08-02 21:40:01 --> Security Class Initialized
DEBUG - 2018-08-02 21:40:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 21:40:01 --> Input Class Initialized
INFO - 2018-08-02 21:40:01 --> Language Class Initialized
ERROR - 2018-08-02 21:40:01 --> 404 Page Not Found: /index
INFO - 2018-08-02 22:08:19 --> Config Class Initialized
INFO - 2018-08-02 22:08:19 --> Hooks Class Initialized
DEBUG - 2018-08-02 22:08:19 --> UTF-8 Support Enabled
INFO - 2018-08-02 22:08:19 --> Utf8 Class Initialized
INFO - 2018-08-02 22:08:19 --> URI Class Initialized
INFO - 2018-08-02 22:08:19 --> Router Class Initialized
INFO - 2018-08-02 22:08:19 --> Output Class Initialized
INFO - 2018-08-02 22:08:19 --> Security Class Initialized
DEBUG - 2018-08-02 22:08:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 22:08:19 --> Input Class Initialized
INFO - 2018-08-02 22:08:19 --> Language Class Initialized
INFO - 2018-08-02 22:08:19 --> Language Class Initialized
INFO - 2018-08-02 22:08:19 --> Config Class Initialized
INFO - 2018-08-02 22:08:19 --> Loader Class Initialized
DEBUG - 2018-08-02 22:08:19 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-02 22:08:19 --> Helper loaded: url_helper
INFO - 2018-08-02 22:08:19 --> Helper loaded: form_helper
INFO - 2018-08-02 22:08:19 --> Helper loaded: date_helper
INFO - 2018-08-02 22:08:20 --> Helper loaded: util_helper
INFO - 2018-08-02 22:08:20 --> Helper loaded: text_helper
INFO - 2018-08-02 22:08:20 --> Helper loaded: string_helper
INFO - 2018-08-02 22:08:20 --> Database Driver Class Initialized
DEBUG - 2018-08-02 22:08:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-02 22:08:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-02 22:08:20 --> Email Class Initialized
INFO - 2018-08-02 22:08:20 --> Controller Class Initialized
DEBUG - 2018-08-02 22:08:20 --> Home MX_Controller Initialized
DEBUG - 2018-08-02 22:08:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-02 22:08:20 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-02 22:08:20 --> Login MX_Controller Initialized
INFO - 2018-08-02 22:08:20 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-02 22:08:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-02 22:08:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-02 22:08:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-08-02 22:08:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-08-02 22:08:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-08-02 22:08:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-08-02 22:08:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-08-02 22:08:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-08-02 22:08:20 --> Final output sent to browser
DEBUG - 2018-08-02 22:08:20 --> Total execution time: 1.5862
INFO - 2018-08-02 22:08:23 --> Config Class Initialized
INFO - 2018-08-02 22:08:23 --> Config Class Initialized
INFO - 2018-08-02 22:08:23 --> Hooks Class Initialized
INFO - 2018-08-02 22:08:23 --> Hooks Class Initialized
INFO - 2018-08-02 22:08:23 --> Config Class Initialized
INFO - 2018-08-02 22:08:23 --> Hooks Class Initialized
DEBUG - 2018-08-02 22:08:23 --> UTF-8 Support Enabled
INFO - 2018-08-02 22:08:23 --> Utf8 Class Initialized
INFO - 2018-08-02 22:08:23 --> URI Class Initialized
DEBUG - 2018-08-02 22:08:23 --> UTF-8 Support Enabled
DEBUG - 2018-08-02 22:08:23 --> UTF-8 Support Enabled
INFO - 2018-08-02 22:08:23 --> Router Class Initialized
INFO - 2018-08-02 22:08:23 --> Output Class Initialized
INFO - 2018-08-02 22:08:23 --> Security Class Initialized
DEBUG - 2018-08-02 22:08:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 22:08:23 --> Input Class Initialized
INFO - 2018-08-02 22:08:23 --> Language Class Initialized
INFO - 2018-08-02 22:08:23 --> Utf8 Class Initialized
INFO - 2018-08-02 22:08:23 --> Utf8 Class Initialized
ERROR - 2018-08-02 22:08:23 --> 404 Page Not Found: /index
INFO - 2018-08-02 22:08:23 --> URI Class Initialized
INFO - 2018-08-02 22:08:23 --> Config Class Initialized
INFO - 2018-08-02 22:08:23 --> URI Class Initialized
INFO - 2018-08-02 22:08:23 --> Hooks Class Initialized
DEBUG - 2018-08-02 22:08:23 --> UTF-8 Support Enabled
INFO - 2018-08-02 22:08:23 --> Router Class Initialized
INFO - 2018-08-02 22:08:23 --> Router Class Initialized
INFO - 2018-08-02 22:08:23 --> Utf8 Class Initialized
INFO - 2018-08-02 22:08:23 --> URI Class Initialized
INFO - 2018-08-02 22:08:23 --> Output Class Initialized
INFO - 2018-08-02 22:08:23 --> Security Class Initialized
INFO - 2018-08-02 22:08:23 --> Router Class Initialized
INFO - 2018-08-02 22:08:23 --> Output Class Initialized
DEBUG - 2018-08-02 22:08:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 22:08:23 --> Output Class Initialized
INFO - 2018-08-02 22:08:23 --> Input Class Initialized
INFO - 2018-08-02 22:08:23 --> Security Class Initialized
INFO - 2018-08-02 22:08:23 --> Language Class Initialized
DEBUG - 2018-08-02 22:08:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 22:08:23 --> Input Class Initialized
ERROR - 2018-08-02 22:08:23 --> 404 Page Not Found: /index
INFO - 2018-08-02 22:08:23 --> Language Class Initialized
ERROR - 2018-08-02 22:08:23 --> 404 Page Not Found: /index
INFO - 2018-08-02 22:08:23 --> Security Class Initialized
DEBUG - 2018-08-02 22:08:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 22:08:23 --> Input Class Initialized
INFO - 2018-08-02 22:08:23 --> Config Class Initialized
INFO - 2018-08-02 22:08:23 --> Language Class Initialized
INFO - 2018-08-02 22:08:23 --> Hooks Class Initialized
DEBUG - 2018-08-02 22:08:23 --> UTF-8 Support Enabled
INFO - 2018-08-02 22:08:23 --> Language Class Initialized
INFO - 2018-08-02 22:08:23 --> Utf8 Class Initialized
INFO - 2018-08-02 22:08:23 --> Config Class Initialized
INFO - 2018-08-02 22:08:23 --> URI Class Initialized
INFO - 2018-08-02 22:08:23 --> Loader Class Initialized
INFO - 2018-08-02 22:08:23 --> Router Class Initialized
DEBUG - 2018-08-02 22:08:23 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-02 22:08:23 --> Output Class Initialized
INFO - 2018-08-02 22:08:23 --> Helper loaded: url_helper
INFO - 2018-08-02 22:08:23 --> Security Class Initialized
INFO - 2018-08-02 22:08:23 --> Helper loaded: form_helper
DEBUG - 2018-08-02 22:08:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 22:08:23 --> Input Class Initialized
INFO - 2018-08-02 22:08:23 --> Helper loaded: date_helper
INFO - 2018-08-02 22:08:23 --> Language Class Initialized
INFO - 2018-08-02 22:08:23 --> Helper loaded: util_helper
ERROR - 2018-08-02 22:08:23 --> 404 Page Not Found: /index
INFO - 2018-08-02 22:08:23 --> Helper loaded: text_helper
INFO - 2018-08-02 22:08:23 --> Helper loaded: string_helper
INFO - 2018-08-02 22:08:23 --> Database Driver Class Initialized
DEBUG - 2018-08-02 22:08:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-02 22:08:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-02 22:08:23 --> Email Class Initialized
INFO - 2018-08-02 22:08:23 --> Controller Class Initialized
DEBUG - 2018-08-02 22:08:23 --> Home MX_Controller Initialized
DEBUG - 2018-08-02 22:08:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-02 22:08:24 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-02 22:08:24 --> Login MX_Controller Initialized
INFO - 2018-08-02 22:08:24 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-02 22:08:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-02 22:08:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-02 22:08:28 --> Config Class Initialized
INFO - 2018-08-02 22:08:28 --> Hooks Class Initialized
DEBUG - 2018-08-02 22:08:28 --> UTF-8 Support Enabled
INFO - 2018-08-02 22:08:28 --> Utf8 Class Initialized
INFO - 2018-08-02 22:08:28 --> URI Class Initialized
INFO - 2018-08-02 22:08:28 --> Router Class Initialized
INFO - 2018-08-02 22:08:28 --> Output Class Initialized
INFO - 2018-08-02 22:08:28 --> Security Class Initialized
DEBUG - 2018-08-02 22:08:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 22:08:28 --> Input Class Initialized
INFO - 2018-08-02 22:08:28 --> Language Class Initialized
INFO - 2018-08-02 22:08:28 --> Language Class Initialized
INFO - 2018-08-02 22:08:28 --> Config Class Initialized
INFO - 2018-08-02 22:08:28 --> Loader Class Initialized
DEBUG - 2018-08-02 22:08:28 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-02 22:08:28 --> Helper loaded: url_helper
INFO - 2018-08-02 22:08:28 --> Helper loaded: form_helper
INFO - 2018-08-02 22:08:28 --> Helper loaded: date_helper
INFO - 2018-08-02 22:08:28 --> Helper loaded: util_helper
INFO - 2018-08-02 22:08:28 --> Helper loaded: text_helper
INFO - 2018-08-02 22:08:28 --> Helper loaded: string_helper
INFO - 2018-08-02 22:08:28 --> Database Driver Class Initialized
DEBUG - 2018-08-02 22:08:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-02 22:08:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-02 22:08:28 --> Email Class Initialized
INFO - 2018-08-02 22:08:28 --> Controller Class Initialized
DEBUG - 2018-08-02 22:08:28 --> Home MX_Controller Initialized
DEBUG - 2018-08-02 22:08:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-02 22:08:28 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-02 22:08:28 --> Login MX_Controller Initialized
INFO - 2018-08-02 22:08:28 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-02 22:08:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-02 22:08:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-02 22:08:28 --> Config Class Initialized
INFO - 2018-08-02 22:08:28 --> Hooks Class Initialized
DEBUG - 2018-08-02 22:08:28 --> UTF-8 Support Enabled
INFO - 2018-08-02 22:08:28 --> Utf8 Class Initialized
INFO - 2018-08-02 22:08:29 --> URI Class Initialized
INFO - 2018-08-02 22:08:29 --> Router Class Initialized
INFO - 2018-08-02 22:08:29 --> Output Class Initialized
INFO - 2018-08-02 22:08:29 --> Security Class Initialized
DEBUG - 2018-08-02 22:08:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 22:08:29 --> Input Class Initialized
INFO - 2018-08-02 22:08:29 --> Language Class Initialized
INFO - 2018-08-02 22:08:29 --> Language Class Initialized
INFO - 2018-08-02 22:08:29 --> Config Class Initialized
INFO - 2018-08-02 22:08:29 --> Loader Class Initialized
DEBUG - 2018-08-02 22:08:29 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-02 22:08:29 --> Helper loaded: url_helper
INFO - 2018-08-02 22:08:29 --> Helper loaded: form_helper
INFO - 2018-08-02 22:08:29 --> Helper loaded: date_helper
INFO - 2018-08-02 22:08:29 --> Helper loaded: util_helper
INFO - 2018-08-02 22:08:29 --> Helper loaded: text_helper
INFO - 2018-08-02 22:08:29 --> Helper loaded: string_helper
INFO - 2018-08-02 22:08:29 --> Database Driver Class Initialized
DEBUG - 2018-08-02 22:08:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-02 22:08:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-02 22:08:29 --> Email Class Initialized
INFO - 2018-08-02 22:08:29 --> Controller Class Initialized
DEBUG - 2018-08-02 22:08:29 --> Home MX_Controller Initialized
DEBUG - 2018-08-02 22:08:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-02 22:08:29 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-02 22:08:29 --> Login MX_Controller Initialized
INFO - 2018-08-02 22:08:29 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-02 22:08:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-02 22:08:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-02 22:08:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-08-02 22:08:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-08-02 22:08:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-08-02 22:08:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-08-02 22:08:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-08-02 22:08:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-08-02 22:08:29 --> Final output sent to browser
DEBUG - 2018-08-02 22:08:29 --> Total execution time: 0.6504
INFO - 2018-08-02 22:08:31 --> Config Class Initialized
INFO - 2018-08-02 22:08:31 --> Hooks Class Initialized
DEBUG - 2018-08-02 22:08:31 --> UTF-8 Support Enabled
INFO - 2018-08-02 22:08:31 --> Config Class Initialized
INFO - 2018-08-02 22:08:31 --> Hooks Class Initialized
INFO - 2018-08-02 22:08:31 --> Utf8 Class Initialized
DEBUG - 2018-08-02 22:08:31 --> UTF-8 Support Enabled
INFO - 2018-08-02 22:08:31 --> Utf8 Class Initialized
INFO - 2018-08-02 22:08:31 --> URI Class Initialized
INFO - 2018-08-02 22:08:31 --> Router Class Initialized
INFO - 2018-08-02 22:08:31 --> Output Class Initialized
INFO - 2018-08-02 22:08:31 --> URI Class Initialized
INFO - 2018-08-02 22:08:31 --> Security Class Initialized
INFO - 2018-08-02 22:08:31 --> Router Class Initialized
DEBUG - 2018-08-02 22:08:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 22:08:31 --> Output Class Initialized
INFO - 2018-08-02 22:08:31 --> Input Class Initialized
INFO - 2018-08-02 22:08:31 --> Language Class Initialized
INFO - 2018-08-02 22:08:31 --> Security Class Initialized
DEBUG - 2018-08-02 22:08:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 22:08:31 --> Language Class Initialized
INFO - 2018-08-02 22:08:31 --> Config Class Initialized
INFO - 2018-08-02 22:08:31 --> Input Class Initialized
INFO - 2018-08-02 22:08:31 --> Language Class Initialized
INFO - 2018-08-02 22:08:31 --> Loader Class Initialized
DEBUG - 2018-08-02 22:08:31 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
ERROR - 2018-08-02 22:08:31 --> 404 Page Not Found: /index
INFO - 2018-08-02 22:08:31 --> Helper loaded: url_helper
INFO - 2018-08-02 22:08:31 --> Config Class Initialized
INFO - 2018-08-02 22:08:31 --> Helper loaded: form_helper
INFO - 2018-08-02 22:08:31 --> Helper loaded: date_helper
INFO - 2018-08-02 22:08:31 --> Hooks Class Initialized
INFO - 2018-08-02 22:08:31 --> Helper loaded: util_helper
INFO - 2018-08-02 22:08:31 --> Helper loaded: text_helper
DEBUG - 2018-08-02 22:08:31 --> UTF-8 Support Enabled
INFO - 2018-08-02 22:08:31 --> Utf8 Class Initialized
INFO - 2018-08-02 22:08:31 --> Helper loaded: string_helper
INFO - 2018-08-02 22:08:31 --> URI Class Initialized
INFO - 2018-08-02 22:08:31 --> Database Driver Class Initialized
INFO - 2018-08-02 22:08:31 --> Router Class Initialized
DEBUG - 2018-08-02 22:08:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-02 22:08:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-02 22:08:31 --> Output Class Initialized
INFO - 2018-08-02 22:08:31 --> Security Class Initialized
INFO - 2018-08-02 22:08:31 --> Email Class Initialized
INFO - 2018-08-02 22:08:31 --> Controller Class Initialized
DEBUG - 2018-08-02 22:08:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 22:08:31 --> Input Class Initialized
DEBUG - 2018-08-02 22:08:31 --> Home MX_Controller Initialized
INFO - 2018-08-02 22:08:31 --> Language Class Initialized
DEBUG - 2018-08-02 22:08:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
ERROR - 2018-08-02 22:08:31 --> 404 Page Not Found: /index
DEBUG - 2018-08-02 22:08:31 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-02 22:08:31 --> Login MX_Controller Initialized
INFO - 2018-08-02 22:08:31 --> Config Class Initialized
INFO - 2018-08-02 22:08:31 --> Language file loaded: language/english/data_lang.php
INFO - 2018-08-02 22:08:31 --> Hooks Class Initialized
DEBUG - 2018-08-02 22:08:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-02 22:08:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-02 22:08:31 --> UTF-8 Support Enabled
INFO - 2018-08-02 22:08:31 --> Utf8 Class Initialized
INFO - 2018-08-02 22:08:31 --> URI Class Initialized
INFO - 2018-08-02 22:08:31 --> Router Class Initialized
INFO - 2018-08-02 22:08:31 --> Output Class Initialized
INFO - 2018-08-02 22:08:31 --> Security Class Initialized
DEBUG - 2018-08-02 22:08:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 22:08:31 --> Input Class Initialized
INFO - 2018-08-02 22:08:31 --> Language Class Initialized
ERROR - 2018-08-02 22:08:31 --> 404 Page Not Found: /index
INFO - 2018-08-02 22:08:33 --> Config Class Initialized
INFO - 2018-08-02 22:08:33 --> Hooks Class Initialized
DEBUG - 2018-08-02 22:08:33 --> UTF-8 Support Enabled
INFO - 2018-08-02 22:08:33 --> Utf8 Class Initialized
INFO - 2018-08-02 22:08:33 --> URI Class Initialized
INFO - 2018-08-02 22:08:33 --> Router Class Initialized
INFO - 2018-08-02 22:08:33 --> Output Class Initialized
INFO - 2018-08-02 22:08:33 --> Security Class Initialized
DEBUG - 2018-08-02 22:08:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 22:08:34 --> Input Class Initialized
INFO - 2018-08-02 22:08:34 --> Language Class Initialized
INFO - 2018-08-02 22:08:34 --> Language Class Initialized
INFO - 2018-08-02 22:08:34 --> Config Class Initialized
INFO - 2018-08-02 22:08:34 --> Loader Class Initialized
DEBUG - 2018-08-02 22:08:34 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-02 22:08:34 --> Helper loaded: url_helper
INFO - 2018-08-02 22:08:34 --> Helper loaded: form_helper
INFO - 2018-08-02 22:08:34 --> Helper loaded: date_helper
INFO - 2018-08-02 22:08:34 --> Helper loaded: util_helper
INFO - 2018-08-02 22:08:34 --> Helper loaded: text_helper
INFO - 2018-08-02 22:08:34 --> Helper loaded: string_helper
INFO - 2018-08-02 22:08:34 --> Database Driver Class Initialized
DEBUG - 2018-08-02 22:08:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-02 22:08:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-02 22:08:34 --> Email Class Initialized
INFO - 2018-08-02 22:08:34 --> Controller Class Initialized
DEBUG - 2018-08-02 22:08:34 --> Home MX_Controller Initialized
DEBUG - 2018-08-02 22:08:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-02 22:08:34 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-02 22:08:34 --> Login MX_Controller Initialized
INFO - 2018-08-02 22:08:34 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-02 22:08:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-02 22:08:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-02 22:08:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-08-02 22:08:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-08-02 22:08:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-08-02 22:08:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-08-02 22:08:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-08-02 22:08:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-08-02 22:08:34 --> Final output sent to browser
DEBUG - 2018-08-02 22:08:34 --> Total execution time: 0.6497
INFO - 2018-08-02 22:08:37 --> Config Class Initialized
INFO - 2018-08-02 22:08:37 --> Config Class Initialized
INFO - 2018-08-02 22:08:37 --> Hooks Class Initialized
INFO - 2018-08-02 22:08:37 --> Hooks Class Initialized
INFO - 2018-08-02 22:08:37 --> Config Class Initialized
INFO - 2018-08-02 22:08:37 --> Hooks Class Initialized
DEBUG - 2018-08-02 22:08:37 --> UTF-8 Support Enabled
DEBUG - 2018-08-02 22:08:37 --> UTF-8 Support Enabled
DEBUG - 2018-08-02 22:08:37 --> UTF-8 Support Enabled
INFO - 2018-08-02 22:08:37 --> Utf8 Class Initialized
INFO - 2018-08-02 22:08:37 --> URI Class Initialized
INFO - 2018-08-02 22:08:37 --> Router Class Initialized
INFO - 2018-08-02 22:08:37 --> Utf8 Class Initialized
INFO - 2018-08-02 22:08:37 --> Output Class Initialized
INFO - 2018-08-02 22:08:37 --> Utf8 Class Initialized
INFO - 2018-08-02 22:08:37 --> Security Class Initialized
INFO - 2018-08-02 22:08:37 --> URI Class Initialized
INFO - 2018-08-02 22:08:38 --> URI Class Initialized
INFO - 2018-08-02 22:08:38 --> Router Class Initialized
INFO - 2018-08-02 22:08:38 --> Output Class Initialized
INFO - 2018-08-02 22:08:38 --> Router Class Initialized
INFO - 2018-08-02 22:08:38 --> Security Class Initialized
DEBUG - 2018-08-02 22:08:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 22:08:38 --> Output Class Initialized
DEBUG - 2018-08-02 22:08:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 22:08:38 --> Security Class Initialized
INFO - 2018-08-02 22:08:38 --> Input Class Initialized
INFO - 2018-08-02 22:08:38 --> Input Class Initialized
INFO - 2018-08-02 22:08:38 --> Language Class Initialized
DEBUG - 2018-08-02 22:08:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 22:08:38 --> Language Class Initialized
ERROR - 2018-08-02 22:08:38 --> 404 Page Not Found: /index
INFO - 2018-08-02 22:08:38 --> Input Class Initialized
INFO - 2018-08-02 22:08:38 --> Language Class Initialized
INFO - 2018-08-02 22:08:38 --> Language Class Initialized
INFO - 2018-08-02 22:08:38 --> Config Class Initialized
ERROR - 2018-08-02 22:08:38 --> 404 Page Not Found: /index
INFO - 2018-08-02 22:08:38 --> Loader Class Initialized
DEBUG - 2018-08-02 22:08:38 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-02 22:08:38 --> Config Class Initialized
INFO - 2018-08-02 22:08:38 --> Hooks Class Initialized
INFO - 2018-08-02 22:08:38 --> Helper loaded: url_helper
INFO - 2018-08-02 22:08:38 --> Helper loaded: form_helper
DEBUG - 2018-08-02 22:08:38 --> UTF-8 Support Enabled
INFO - 2018-08-02 22:08:38 --> Utf8 Class Initialized
INFO - 2018-08-02 22:08:38 --> Helper loaded: date_helper
INFO - 2018-08-02 22:08:38 --> Helper loaded: util_helper
INFO - 2018-08-02 22:08:38 --> URI Class Initialized
INFO - 2018-08-02 22:08:38 --> Helper loaded: text_helper
INFO - 2018-08-02 22:08:38 --> Router Class Initialized
INFO - 2018-08-02 22:08:38 --> Helper loaded: string_helper
INFO - 2018-08-02 22:08:38 --> Output Class Initialized
INFO - 2018-08-02 22:08:38 --> Security Class Initialized
INFO - 2018-08-02 22:08:38 --> Database Driver Class Initialized
DEBUG - 2018-08-02 22:08:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-08-02 22:08:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-02 22:08:38 --> Input Class Initialized
INFO - 2018-08-02 22:08:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-02 22:08:38 --> Language Class Initialized
INFO - 2018-08-02 22:08:38 --> Email Class Initialized
INFO - 2018-08-02 22:08:38 --> Controller Class Initialized
ERROR - 2018-08-02 22:08:38 --> 404 Page Not Found: /index
DEBUG - 2018-08-02 22:08:38 --> Home MX_Controller Initialized
DEBUG - 2018-08-02 22:08:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-08-02 22:08:38 --> Config Class Initialized
INFO - 2018-08-02 22:08:38 --> Hooks Class Initialized
DEBUG - 2018-08-02 22:08:38 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-02 22:08:38 --> Login MX_Controller Initialized
DEBUG - 2018-08-02 22:08:38 --> UTF-8 Support Enabled
INFO - 2018-08-02 22:08:38 --> Utf8 Class Initialized
INFO - 2018-08-02 22:08:38 --> Language file loaded: language/english/data_lang.php
INFO - 2018-08-02 22:08:38 --> URI Class Initialized
DEBUG - 2018-08-02 22:08:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-02 22:08:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-02 22:08:38 --> Router Class Initialized
INFO - 2018-08-02 22:08:38 --> Output Class Initialized
INFO - 2018-08-02 22:08:38 --> Security Class Initialized
DEBUG - 2018-08-02 22:08:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 22:08:38 --> Input Class Initialized
INFO - 2018-08-02 22:08:38 --> Language Class Initialized
ERROR - 2018-08-02 22:08:38 --> 404 Page Not Found: /index
INFO - 2018-08-02 22:08:42 --> Config Class Initialized
INFO - 2018-08-02 22:08:42 --> Hooks Class Initialized
DEBUG - 2018-08-02 22:08:42 --> UTF-8 Support Enabled
INFO - 2018-08-02 22:08:42 --> Utf8 Class Initialized
INFO - 2018-08-02 22:08:42 --> URI Class Initialized
INFO - 2018-08-02 22:08:42 --> Router Class Initialized
INFO - 2018-08-02 22:08:42 --> Output Class Initialized
INFO - 2018-08-02 22:08:42 --> Security Class Initialized
DEBUG - 2018-08-02 22:08:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 22:08:42 --> Input Class Initialized
INFO - 2018-08-02 22:08:42 --> Language Class Initialized
INFO - 2018-08-02 22:08:42 --> Language Class Initialized
INFO - 2018-08-02 22:08:42 --> Config Class Initialized
INFO - 2018-08-02 22:08:42 --> Loader Class Initialized
DEBUG - 2018-08-02 22:08:42 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-02 22:08:42 --> Helper loaded: url_helper
INFO - 2018-08-02 22:08:42 --> Helper loaded: form_helper
INFO - 2018-08-02 22:08:42 --> Helper loaded: date_helper
INFO - 2018-08-02 22:08:42 --> Helper loaded: util_helper
INFO - 2018-08-02 22:08:42 --> Helper loaded: text_helper
INFO - 2018-08-02 22:08:42 --> Helper loaded: string_helper
INFO - 2018-08-02 22:08:42 --> Database Driver Class Initialized
DEBUG - 2018-08-02 22:08:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-02 22:08:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-02 22:08:42 --> Email Class Initialized
INFO - 2018-08-02 22:08:42 --> Controller Class Initialized
DEBUG - 2018-08-02 22:08:42 --> Home MX_Controller Initialized
DEBUG - 2018-08-02 22:08:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-02 22:08:42 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-02 22:08:42 --> Login MX_Controller Initialized
INFO - 2018-08-02 22:08:42 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-02 22:08:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-02 22:08:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-02 22:08:43 --> Config Class Initialized
INFO - 2018-08-02 22:08:43 --> Hooks Class Initialized
DEBUG - 2018-08-02 22:08:43 --> UTF-8 Support Enabled
INFO - 2018-08-02 22:08:43 --> Utf8 Class Initialized
INFO - 2018-08-02 22:08:43 --> URI Class Initialized
INFO - 2018-08-02 22:08:43 --> Router Class Initialized
INFO - 2018-08-02 22:08:43 --> Output Class Initialized
INFO - 2018-08-02 22:08:43 --> Security Class Initialized
DEBUG - 2018-08-02 22:08:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 22:08:43 --> Input Class Initialized
INFO - 2018-08-02 22:08:43 --> Language Class Initialized
INFO - 2018-08-02 22:08:43 --> Language Class Initialized
INFO - 2018-08-02 22:08:43 --> Config Class Initialized
INFO - 2018-08-02 22:08:43 --> Loader Class Initialized
DEBUG - 2018-08-02 22:08:43 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-02 22:08:43 --> Helper loaded: url_helper
INFO - 2018-08-02 22:08:43 --> Helper loaded: form_helper
INFO - 2018-08-02 22:08:43 --> Helper loaded: date_helper
INFO - 2018-08-02 22:08:43 --> Helper loaded: util_helper
INFO - 2018-08-02 22:08:43 --> Helper loaded: text_helper
INFO - 2018-08-02 22:08:43 --> Helper loaded: string_helper
INFO - 2018-08-02 22:08:43 --> Database Driver Class Initialized
DEBUG - 2018-08-02 22:08:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-02 22:08:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-02 22:08:43 --> Email Class Initialized
INFO - 2018-08-02 22:08:43 --> Controller Class Initialized
DEBUG - 2018-08-02 22:08:43 --> Home MX_Controller Initialized
DEBUG - 2018-08-02 22:08:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-02 22:08:43 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-02 22:08:43 --> Login MX_Controller Initialized
INFO - 2018-08-02 22:08:43 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-02 22:08:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-02 22:08:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-02 22:08:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-08-02 22:08:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-08-02 22:08:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-08-02 22:08:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-08-02 22:08:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-08-02 22:08:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-08-02 22:08:43 --> Final output sent to browser
DEBUG - 2018-08-02 22:08:43 --> Total execution time: 0.6130
INFO - 2018-08-02 22:08:49 --> Config Class Initialized
INFO - 2018-08-02 22:08:49 --> Hooks Class Initialized
DEBUG - 2018-08-02 22:08:49 --> UTF-8 Support Enabled
INFO - 2018-08-02 22:08:49 --> Config Class Initialized
INFO - 2018-08-02 22:08:49 --> Utf8 Class Initialized
INFO - 2018-08-02 22:08:49 --> URI Class Initialized
INFO - 2018-08-02 22:08:49 --> Router Class Initialized
INFO - 2018-08-02 22:08:49 --> Hooks Class Initialized
INFO - 2018-08-02 22:08:49 --> Output Class Initialized
INFO - 2018-08-02 22:08:49 --> Security Class Initialized
DEBUG - 2018-08-02 22:08:49 --> UTF-8 Support Enabled
INFO - 2018-08-02 22:08:49 --> Utf8 Class Initialized
DEBUG - 2018-08-02 22:08:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 22:08:49 --> Input Class Initialized
INFO - 2018-08-02 22:08:49 --> URI Class Initialized
INFO - 2018-08-02 22:08:49 --> Language Class Initialized
INFO - 2018-08-02 22:08:49 --> Router Class Initialized
ERROR - 2018-08-02 22:08:49 --> 404 Page Not Found: /index
INFO - 2018-08-02 22:08:49 --> Output Class Initialized
INFO - 2018-08-02 22:08:49 --> Security Class Initialized
INFO - 2018-08-02 22:08:49 --> Config Class Initialized
INFO - 2018-08-02 22:08:49 --> Hooks Class Initialized
DEBUG - 2018-08-02 22:08:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 22:08:49 --> Input Class Initialized
DEBUG - 2018-08-02 22:08:49 --> UTF-8 Support Enabled
INFO - 2018-08-02 22:08:49 --> Utf8 Class Initialized
INFO - 2018-08-02 22:08:49 --> Language Class Initialized
INFO - 2018-08-02 22:08:49 --> URI Class Initialized
INFO - 2018-08-02 22:08:49 --> Language Class Initialized
INFO - 2018-08-02 22:08:49 --> Config Class Initialized
INFO - 2018-08-02 22:08:49 --> Router Class Initialized
INFO - 2018-08-02 22:08:49 --> Output Class Initialized
INFO - 2018-08-02 22:08:49 --> Loader Class Initialized
DEBUG - 2018-08-02 22:08:49 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-02 22:08:49 --> Security Class Initialized
INFO - 2018-08-02 22:08:49 --> Helper loaded: url_helper
DEBUG - 2018-08-02 22:08:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 22:08:49 --> Input Class Initialized
INFO - 2018-08-02 22:08:49 --> Helper loaded: form_helper
INFO - 2018-08-02 22:08:49 --> Language Class Initialized
INFO - 2018-08-02 22:08:49 --> Helper loaded: date_helper
ERROR - 2018-08-02 22:08:49 --> 404 Page Not Found: /index
INFO - 2018-08-02 22:08:49 --> Helper loaded: util_helper
INFO - 2018-08-02 22:08:49 --> Helper loaded: text_helper
INFO - 2018-08-02 22:08:49 --> Config Class Initialized
INFO - 2018-08-02 22:08:49 --> Helper loaded: string_helper
INFO - 2018-08-02 22:08:49 --> Hooks Class Initialized
INFO - 2018-08-02 22:08:49 --> Database Driver Class Initialized
DEBUG - 2018-08-02 22:08:49 --> UTF-8 Support Enabled
DEBUG - 2018-08-02 22:08:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-02 22:08:49 --> Utf8 Class Initialized
INFO - 2018-08-02 22:08:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-02 22:08:49 --> Email Class Initialized
INFO - 2018-08-02 22:08:49 --> URI Class Initialized
INFO - 2018-08-02 22:08:49 --> Controller Class Initialized
DEBUG - 2018-08-02 22:08:49 --> Home MX_Controller Initialized
DEBUG - 2018-08-02 22:08:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-08-02 22:08:49 --> Router Class Initialized
INFO - 2018-08-02 22:08:49 --> Output Class Initialized
DEBUG - 2018-08-02 22:08:49 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-02 22:08:49 --> Login MX_Controller Initialized
INFO - 2018-08-02 22:08:49 --> Security Class Initialized
INFO - 2018-08-02 22:08:49 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-02 22:08:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 22:08:50 --> Input Class Initialized
DEBUG - 2018-08-02 22:08:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-08-02 22:08:50 --> Language Class Initialized
DEBUG - 2018-08-02 22:08:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
ERROR - 2018-08-02 22:08:50 --> 404 Page Not Found: /index
INFO - 2018-08-02 22:08:51 --> Config Class Initialized
INFO - 2018-08-02 22:08:51 --> Hooks Class Initialized
DEBUG - 2018-08-02 22:08:51 --> UTF-8 Support Enabled
INFO - 2018-08-02 22:08:52 --> Utf8 Class Initialized
INFO - 2018-08-02 22:08:52 --> URI Class Initialized
INFO - 2018-08-02 22:08:52 --> Router Class Initialized
INFO - 2018-08-02 22:08:52 --> Output Class Initialized
INFO - 2018-08-02 22:08:52 --> Security Class Initialized
DEBUG - 2018-08-02 22:08:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 22:08:52 --> Input Class Initialized
INFO - 2018-08-02 22:08:52 --> Language Class Initialized
INFO - 2018-08-02 22:08:52 --> Language Class Initialized
INFO - 2018-08-02 22:08:52 --> Config Class Initialized
INFO - 2018-08-02 22:08:52 --> Loader Class Initialized
DEBUG - 2018-08-02 22:08:52 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-02 22:08:52 --> Helper loaded: url_helper
INFO - 2018-08-02 22:08:52 --> Helper loaded: form_helper
INFO - 2018-08-02 22:08:52 --> Helper loaded: date_helper
INFO - 2018-08-02 22:08:52 --> Helper loaded: util_helper
INFO - 2018-08-02 22:08:52 --> Helper loaded: text_helper
INFO - 2018-08-02 22:08:52 --> Helper loaded: string_helper
INFO - 2018-08-02 22:08:52 --> Database Driver Class Initialized
DEBUG - 2018-08-02 22:08:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-02 22:08:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-02 22:08:52 --> Email Class Initialized
INFO - 2018-08-02 22:08:52 --> Controller Class Initialized
DEBUG - 2018-08-02 22:08:52 --> Home MX_Controller Initialized
DEBUG - 2018-08-02 22:08:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-02 22:08:52 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-02 22:08:52 --> Login MX_Controller Initialized
INFO - 2018-08-02 22:08:52 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-02 22:08:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-02 22:08:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-02 22:08:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-08-02 22:08:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-08-02 22:08:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-08-02 22:08:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-08-02 22:08:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-08-02 22:08:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-08-02 22:08:52 --> Final output sent to browser
DEBUG - 2018-08-02 22:08:52 --> Total execution time: 0.6215
INFO - 2018-08-02 22:08:53 --> Config Class Initialized
INFO - 2018-08-02 22:08:53 --> Config Class Initialized
INFO - 2018-08-02 22:08:53 --> Hooks Class Initialized
INFO - 2018-08-02 22:08:53 --> Hooks Class Initialized
INFO - 2018-08-02 22:08:53 --> Config Class Initialized
INFO - 2018-08-02 22:08:53 --> Hooks Class Initialized
DEBUG - 2018-08-02 22:08:53 --> UTF-8 Support Enabled
DEBUG - 2018-08-02 22:08:53 --> UTF-8 Support Enabled
DEBUG - 2018-08-02 22:08:53 --> UTF-8 Support Enabled
INFO - 2018-08-02 22:08:53 --> Utf8 Class Initialized
INFO - 2018-08-02 22:08:53 --> Utf8 Class Initialized
INFO - 2018-08-02 22:08:53 --> Utf8 Class Initialized
INFO - 2018-08-02 22:08:53 --> URI Class Initialized
INFO - 2018-08-02 22:08:53 --> URI Class Initialized
INFO - 2018-08-02 22:08:53 --> URI Class Initialized
INFO - 2018-08-02 22:08:53 --> Router Class Initialized
INFO - 2018-08-02 22:08:53 --> Output Class Initialized
INFO - 2018-08-02 22:08:53 --> Security Class Initialized
DEBUG - 2018-08-02 22:08:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 22:08:53 --> Input Class Initialized
INFO - 2018-08-02 22:08:53 --> Language Class Initialized
INFO - 2018-08-02 22:08:53 --> Router Class Initialized
INFO - 2018-08-02 22:08:53 --> Router Class Initialized
INFO - 2018-08-02 22:08:53 --> Output Class Initialized
INFO - 2018-08-02 22:08:53 --> Language Class Initialized
INFO - 2018-08-02 22:08:53 --> Output Class Initialized
INFO - 2018-08-02 22:08:53 --> Config Class Initialized
INFO - 2018-08-02 22:08:53 --> Security Class Initialized
DEBUG - 2018-08-02 22:08:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 22:08:53 --> Loader Class Initialized
INFO - 2018-08-02 22:08:53 --> Input Class Initialized
DEBUG - 2018-08-02 22:08:53 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-02 22:08:53 --> Security Class Initialized
INFO - 2018-08-02 22:08:53 --> Language Class Initialized
INFO - 2018-08-02 22:08:53 --> Helper loaded: url_helper
DEBUG - 2018-08-02 22:08:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-08-02 22:08:53 --> 404 Page Not Found: /index
INFO - 2018-08-02 22:08:53 --> Helper loaded: form_helper
INFO - 2018-08-02 22:08:53 --> Input Class Initialized
INFO - 2018-08-02 22:08:53 --> Helper loaded: date_helper
INFO - 2018-08-02 22:08:53 --> Helper loaded: util_helper
INFO - 2018-08-02 22:08:53 --> Language Class Initialized
INFO - 2018-08-02 22:08:53 --> Helper loaded: text_helper
ERROR - 2018-08-02 22:08:53 --> 404 Page Not Found: /index
INFO - 2018-08-02 22:08:53 --> Helper loaded: string_helper
INFO - 2018-08-02 22:08:53 --> Database Driver Class Initialized
INFO - 2018-08-02 22:08:53 --> Config Class Initialized
DEBUG - 2018-08-02 22:08:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-02 22:08:53 --> Hooks Class Initialized
INFO - 2018-08-02 22:08:53 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-08-02 22:08:53 --> UTF-8 Support Enabled
INFO - 2018-08-02 22:08:53 --> Email Class Initialized
INFO - 2018-08-02 22:08:53 --> Controller Class Initialized
DEBUG - 2018-08-02 22:08:53 --> Home MX_Controller Initialized
INFO - 2018-08-02 22:08:53 --> Utf8 Class Initialized
DEBUG - 2018-08-02 22:08:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-08-02 22:08:53 --> URI Class Initialized
DEBUG - 2018-08-02 22:08:53 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-02 22:08:53 --> Login MX_Controller Initialized
INFO - 2018-08-02 22:08:53 --> Router Class Initialized
INFO - 2018-08-02 22:08:53 --> Language file loaded: language/english/data_lang.php
INFO - 2018-08-02 22:08:53 --> Output Class Initialized
DEBUG - 2018-08-02 22:08:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-08-02 22:08:53 --> Security Class Initialized
DEBUG - 2018-08-02 22:08:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-02 22:08:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 22:08:53 --> Input Class Initialized
INFO - 2018-08-02 22:08:53 --> Language Class Initialized
ERROR - 2018-08-02 22:08:53 --> 404 Page Not Found: /index
INFO - 2018-08-02 22:08:53 --> Config Class Initialized
INFO - 2018-08-02 22:08:53 --> Hooks Class Initialized
DEBUG - 2018-08-02 22:08:53 --> UTF-8 Support Enabled
INFO - 2018-08-02 22:08:54 --> Utf8 Class Initialized
INFO - 2018-08-02 22:08:54 --> URI Class Initialized
INFO - 2018-08-02 22:08:54 --> Router Class Initialized
INFO - 2018-08-02 22:08:54 --> Output Class Initialized
INFO - 2018-08-02 22:08:54 --> Security Class Initialized
DEBUG - 2018-08-02 22:08:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 22:08:54 --> Input Class Initialized
INFO - 2018-08-02 22:08:54 --> Language Class Initialized
ERROR - 2018-08-02 22:08:54 --> 404 Page Not Found: /index
INFO - 2018-08-02 22:09:54 --> Config Class Initialized
INFO - 2018-08-02 22:09:54 --> Hooks Class Initialized
DEBUG - 2018-08-02 22:09:54 --> UTF-8 Support Enabled
INFO - 2018-08-02 22:09:54 --> Utf8 Class Initialized
INFO - 2018-08-02 22:09:54 --> URI Class Initialized
INFO - 2018-08-02 22:09:54 --> Router Class Initialized
INFO - 2018-08-02 22:09:54 --> Output Class Initialized
INFO - 2018-08-02 22:09:54 --> Security Class Initialized
DEBUG - 2018-08-02 22:09:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 22:09:54 --> Input Class Initialized
INFO - 2018-08-02 22:09:54 --> Language Class Initialized
INFO - 2018-08-02 22:09:54 --> Language Class Initialized
INFO - 2018-08-02 22:09:54 --> Config Class Initialized
INFO - 2018-08-02 22:09:54 --> Loader Class Initialized
DEBUG - 2018-08-02 22:09:54 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-02 22:09:54 --> Helper loaded: url_helper
INFO - 2018-08-02 22:09:54 --> Helper loaded: form_helper
INFO - 2018-08-02 22:09:54 --> Helper loaded: date_helper
INFO - 2018-08-02 22:09:54 --> Helper loaded: util_helper
INFO - 2018-08-02 22:09:54 --> Helper loaded: text_helper
INFO - 2018-08-02 22:09:54 --> Helper loaded: string_helper
INFO - 2018-08-02 22:09:55 --> Database Driver Class Initialized
DEBUG - 2018-08-02 22:09:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-02 22:09:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-02 22:09:55 --> Email Class Initialized
INFO - 2018-08-02 22:09:55 --> Controller Class Initialized
DEBUG - 2018-08-02 22:09:55 --> Home MX_Controller Initialized
DEBUG - 2018-08-02 22:09:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-02 22:09:55 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-02 22:09:55 --> Login MX_Controller Initialized
INFO - 2018-08-02 22:09:55 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-02 22:09:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-02 22:09:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-02 22:09:55 --> Config Class Initialized
INFO - 2018-08-02 22:09:55 --> Hooks Class Initialized
DEBUG - 2018-08-02 22:09:55 --> UTF-8 Support Enabled
INFO - 2018-08-02 22:09:55 --> Utf8 Class Initialized
INFO - 2018-08-02 22:09:55 --> URI Class Initialized
INFO - 2018-08-02 22:09:55 --> Router Class Initialized
INFO - 2018-08-02 22:09:55 --> Output Class Initialized
INFO - 2018-08-02 22:09:55 --> Security Class Initialized
DEBUG - 2018-08-02 22:09:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 22:09:55 --> Input Class Initialized
INFO - 2018-08-02 22:09:55 --> Language Class Initialized
INFO - 2018-08-02 22:09:55 --> Language Class Initialized
INFO - 2018-08-02 22:09:55 --> Config Class Initialized
INFO - 2018-08-02 22:09:55 --> Loader Class Initialized
DEBUG - 2018-08-02 22:09:55 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-02 22:09:55 --> Helper loaded: url_helper
INFO - 2018-08-02 22:09:55 --> Helper loaded: form_helper
INFO - 2018-08-02 22:09:55 --> Helper loaded: date_helper
INFO - 2018-08-02 22:09:55 --> Helper loaded: util_helper
INFO - 2018-08-02 22:09:55 --> Helper loaded: text_helper
INFO - 2018-08-02 22:09:55 --> Helper loaded: string_helper
INFO - 2018-08-02 22:09:55 --> Database Driver Class Initialized
DEBUG - 2018-08-02 22:09:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-02 22:09:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-02 22:09:55 --> Email Class Initialized
INFO - 2018-08-02 22:09:55 --> Controller Class Initialized
DEBUG - 2018-08-02 22:09:55 --> Home MX_Controller Initialized
DEBUG - 2018-08-02 22:09:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-02 22:09:55 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-02 22:09:55 --> Login MX_Controller Initialized
INFO - 2018-08-02 22:09:55 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-02 22:09:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-02 22:09:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-02 22:09:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-08-02 22:09:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-08-02 22:09:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-08-02 22:09:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-08-02 22:09:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-08-02 22:09:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-08-02 22:09:55 --> Final output sent to browser
DEBUG - 2018-08-02 22:09:55 --> Total execution time: 0.6472
INFO - 2018-08-02 22:09:56 --> Config Class Initialized
INFO - 2018-08-02 22:09:56 --> Hooks Class Initialized
INFO - 2018-08-02 22:09:56 --> Config Class Initialized
INFO - 2018-08-02 22:09:56 --> Hooks Class Initialized
DEBUG - 2018-08-02 22:09:56 --> UTF-8 Support Enabled
INFO - 2018-08-02 22:09:56 --> Utf8 Class Initialized
DEBUG - 2018-08-02 22:09:56 --> UTF-8 Support Enabled
INFO - 2018-08-02 22:09:56 --> Utf8 Class Initialized
INFO - 2018-08-02 22:09:56 --> URI Class Initialized
INFO - 2018-08-02 22:09:56 --> URI Class Initialized
INFO - 2018-08-02 22:09:56 --> Router Class Initialized
INFO - 2018-08-02 22:09:56 --> Router Class Initialized
INFO - 2018-08-02 22:09:56 --> Output Class Initialized
INFO - 2018-08-02 22:09:56 --> Output Class Initialized
INFO - 2018-08-02 22:09:56 --> Security Class Initialized
INFO - 2018-08-02 22:09:56 --> Security Class Initialized
DEBUG - 2018-08-02 22:09:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 22:09:56 --> Input Class Initialized
DEBUG - 2018-08-02 22:09:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 22:09:56 --> Input Class Initialized
INFO - 2018-08-02 22:09:56 --> Language Class Initialized
INFO - 2018-08-02 22:09:56 --> Language Class Initialized
ERROR - 2018-08-02 22:09:56 --> 404 Page Not Found: /index
INFO - 2018-08-02 22:09:56 --> Language Class Initialized
INFO - 2018-08-02 22:09:56 --> Config Class Initialized
INFO - 2018-08-02 22:09:56 --> Hooks Class Initialized
INFO - 2018-08-02 22:09:56 --> Config Class Initialized
DEBUG - 2018-08-02 22:09:56 --> UTF-8 Support Enabled
INFO - 2018-08-02 22:09:56 --> Loader Class Initialized
INFO - 2018-08-02 22:09:56 --> Utf8 Class Initialized
DEBUG - 2018-08-02 22:09:56 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-02 22:09:56 --> URI Class Initialized
INFO - 2018-08-02 22:09:56 --> Helper loaded: url_helper
INFO - 2018-08-02 22:09:56 --> Router Class Initialized
INFO - 2018-08-02 22:09:56 --> Helper loaded: form_helper
INFO - 2018-08-02 22:09:56 --> Output Class Initialized
INFO - 2018-08-02 22:09:57 --> Helper loaded: date_helper
INFO - 2018-08-02 22:09:57 --> Security Class Initialized
INFO - 2018-08-02 22:09:57 --> Helper loaded: util_helper
DEBUG - 2018-08-02 22:09:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 22:09:57 --> Input Class Initialized
INFO - 2018-08-02 22:09:57 --> Helper loaded: text_helper
INFO - 2018-08-02 22:09:57 --> Language Class Initialized
INFO - 2018-08-02 22:09:57 --> Helper loaded: string_helper
ERROR - 2018-08-02 22:09:57 --> 404 Page Not Found: /index
INFO - 2018-08-02 22:09:57 --> Database Driver Class Initialized
INFO - 2018-08-02 22:09:57 --> Config Class Initialized
INFO - 2018-08-02 22:09:57 --> Hooks Class Initialized
DEBUG - 2018-08-02 22:09:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-02 22:09:57 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-08-02 22:09:57 --> UTF-8 Support Enabled
INFO - 2018-08-02 22:09:57 --> Utf8 Class Initialized
INFO - 2018-08-02 22:09:57 --> Email Class Initialized
INFO - 2018-08-02 22:09:57 --> URI Class Initialized
INFO - 2018-08-02 22:09:57 --> Controller Class Initialized
INFO - 2018-08-02 22:09:57 --> Router Class Initialized
DEBUG - 2018-08-02 22:09:57 --> Home MX_Controller Initialized
INFO - 2018-08-02 22:09:57 --> Output Class Initialized
DEBUG - 2018-08-02 22:09:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-08-02 22:09:57 --> Security Class Initialized
DEBUG - 2018-08-02 22:09:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-08-02 22:09:57 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
INFO - 2018-08-02 22:09:57 --> Input Class Initialized
DEBUG - 2018-08-02 22:09:57 --> Login MX_Controller Initialized
INFO - 2018-08-02 22:09:57 --> Language file loaded: language/english/data_lang.php
INFO - 2018-08-02 22:09:57 --> Language Class Initialized
DEBUG - 2018-08-02 22:09:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
ERROR - 2018-08-02 22:09:57 --> 404 Page Not Found: /index
DEBUG - 2018-08-02 22:09:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-02 22:10:02 --> Config Class Initialized
INFO - 2018-08-02 22:10:02 --> Hooks Class Initialized
DEBUG - 2018-08-02 22:10:02 --> UTF-8 Support Enabled
INFO - 2018-08-02 22:10:02 --> Utf8 Class Initialized
INFO - 2018-08-02 22:10:02 --> URI Class Initialized
INFO - 2018-08-02 22:10:02 --> Router Class Initialized
INFO - 2018-08-02 22:10:02 --> Output Class Initialized
INFO - 2018-08-02 22:10:02 --> Security Class Initialized
DEBUG - 2018-08-02 22:10:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 22:10:02 --> Input Class Initialized
INFO - 2018-08-02 22:10:02 --> Language Class Initialized
INFO - 2018-08-02 22:10:02 --> Language Class Initialized
INFO - 2018-08-02 22:10:02 --> Config Class Initialized
INFO - 2018-08-02 22:10:02 --> Loader Class Initialized
DEBUG - 2018-08-02 22:10:02 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-02 22:10:02 --> Helper loaded: url_helper
INFO - 2018-08-02 22:10:02 --> Helper loaded: form_helper
INFO - 2018-08-02 22:10:02 --> Helper loaded: date_helper
INFO - 2018-08-02 22:10:02 --> Helper loaded: util_helper
INFO - 2018-08-02 22:10:02 --> Helper loaded: text_helper
INFO - 2018-08-02 22:10:02 --> Helper loaded: string_helper
INFO - 2018-08-02 22:10:02 --> Database Driver Class Initialized
DEBUG - 2018-08-02 22:10:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-02 22:10:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-02 22:10:02 --> Email Class Initialized
INFO - 2018-08-02 22:10:02 --> Controller Class Initialized
DEBUG - 2018-08-02 22:10:02 --> Home MX_Controller Initialized
DEBUG - 2018-08-02 22:10:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-02 22:10:02 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-02 22:10:02 --> Login MX_Controller Initialized
INFO - 2018-08-02 22:10:02 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-02 22:10:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-02 22:10:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-02 22:10:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-08-02 22:10:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-08-02 22:10:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-08-02 22:10:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-08-02 22:10:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-08-02 22:10:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/search_page.php
INFO - 2018-08-02 22:10:03 --> Final output sent to browser
DEBUG - 2018-08-02 22:10:03 --> Total execution time: 0.6956
INFO - 2018-08-02 22:10:03 --> Config Class Initialized
INFO - 2018-08-02 22:10:03 --> Hooks Class Initialized
INFO - 2018-08-02 22:10:03 --> Config Class Initialized
INFO - 2018-08-02 22:10:03 --> Hooks Class Initialized
DEBUG - 2018-08-02 22:10:03 --> UTF-8 Support Enabled
DEBUG - 2018-08-02 22:10:03 --> UTF-8 Support Enabled
INFO - 2018-08-02 22:10:03 --> Utf8 Class Initialized
INFO - 2018-08-02 22:10:03 --> URI Class Initialized
INFO - 2018-08-02 22:10:03 --> Utf8 Class Initialized
INFO - 2018-08-02 22:10:03 --> Router Class Initialized
INFO - 2018-08-02 22:10:03 --> URI Class Initialized
INFO - 2018-08-02 22:10:03 --> Output Class Initialized
INFO - 2018-08-02 22:10:03 --> Security Class Initialized
INFO - 2018-08-02 22:10:03 --> Router Class Initialized
DEBUG - 2018-08-02 22:10:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 22:10:03 --> Output Class Initialized
INFO - 2018-08-02 22:10:03 --> Input Class Initialized
INFO - 2018-08-02 22:10:03 --> Language Class Initialized
INFO - 2018-08-02 22:10:03 --> Security Class Initialized
DEBUG - 2018-08-02 22:10:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 22:10:03 --> Language Class Initialized
INFO - 2018-08-02 22:10:03 --> Input Class Initialized
INFO - 2018-08-02 22:10:03 --> Config Class Initialized
INFO - 2018-08-02 22:10:03 --> Language Class Initialized
ERROR - 2018-08-02 22:10:03 --> 404 Page Not Found: /index
INFO - 2018-08-02 22:10:03 --> Loader Class Initialized
DEBUG - 2018-08-02 22:10:03 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-02 22:10:03 --> Config Class Initialized
INFO - 2018-08-02 22:10:03 --> Hooks Class Initialized
INFO - 2018-08-02 22:10:03 --> Helper loaded: url_helper
INFO - 2018-08-02 22:10:03 --> Helper loaded: form_helper
DEBUG - 2018-08-02 22:10:03 --> UTF-8 Support Enabled
INFO - 2018-08-02 22:10:03 --> Utf8 Class Initialized
INFO - 2018-08-02 22:10:03 --> Helper loaded: date_helper
INFO - 2018-08-02 22:10:03 --> Helper loaded: util_helper
INFO - 2018-08-02 22:10:03 --> URI Class Initialized
INFO - 2018-08-02 22:10:03 --> Helper loaded: text_helper
INFO - 2018-08-02 22:10:03 --> Router Class Initialized
INFO - 2018-08-02 22:10:03 --> Helper loaded: string_helper
INFO - 2018-08-02 22:10:03 --> Output Class Initialized
INFO - 2018-08-02 22:10:03 --> Security Class Initialized
INFO - 2018-08-02 22:10:03 --> Database Driver Class Initialized
DEBUG - 2018-08-02 22:10:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-08-02 22:10:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-02 22:10:03 --> Input Class Initialized
INFO - 2018-08-02 22:10:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-02 22:10:03 --> Language Class Initialized
INFO - 2018-08-02 22:10:03 --> Email Class Initialized
INFO - 2018-08-02 22:10:03 --> Controller Class Initialized
ERROR - 2018-08-02 22:10:03 --> 404 Page Not Found: /index
DEBUG - 2018-08-02 22:10:04 --> Home MX_Controller Initialized
INFO - 2018-08-02 22:10:04 --> Config Class Initialized
INFO - 2018-08-02 22:10:04 --> Hooks Class Initialized
DEBUG - 2018-08-02 22:10:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-02 22:10:04 --> UTF-8 Support Enabled
DEBUG - 2018-08-02 22:10:04 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-02 22:10:04 --> Login MX_Controller Initialized
INFO - 2018-08-02 22:10:04 --> Utf8 Class Initialized
INFO - 2018-08-02 22:10:04 --> Language file loaded: language/english/data_lang.php
INFO - 2018-08-02 22:10:04 --> URI Class Initialized
DEBUG - 2018-08-02 22:10:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-08-02 22:10:04 --> Router Class Initialized
DEBUG - 2018-08-02 22:10:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-02 22:10:04 --> Output Class Initialized
INFO - 2018-08-02 22:10:04 --> Security Class Initialized
DEBUG - 2018-08-02 22:10:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 22:10:04 --> Input Class Initialized
INFO - 2018-08-02 22:10:04 --> Language Class Initialized
ERROR - 2018-08-02 22:10:04 --> 404 Page Not Found: /index
INFO - 2018-08-02 22:29:18 --> Config Class Initialized
INFO - 2018-08-02 22:29:18 --> Hooks Class Initialized
DEBUG - 2018-08-02 22:29:18 --> UTF-8 Support Enabled
INFO - 2018-08-02 22:29:18 --> Utf8 Class Initialized
INFO - 2018-08-02 22:29:18 --> URI Class Initialized
INFO - 2018-08-02 22:29:18 --> Router Class Initialized
INFO - 2018-08-02 22:29:18 --> Output Class Initialized
INFO - 2018-08-02 22:29:18 --> Security Class Initialized
DEBUG - 2018-08-02 22:29:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 22:29:18 --> Input Class Initialized
INFO - 2018-08-02 22:29:18 --> Language Class Initialized
INFO - 2018-08-02 22:29:18 --> Language Class Initialized
INFO - 2018-08-02 22:29:18 --> Config Class Initialized
INFO - 2018-08-02 22:29:18 --> Loader Class Initialized
DEBUG - 2018-08-02 22:29:18 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-02 22:29:18 --> Helper loaded: url_helper
INFO - 2018-08-02 22:29:18 --> Helper loaded: form_helper
INFO - 2018-08-02 22:29:18 --> Helper loaded: date_helper
INFO - 2018-08-02 22:29:18 --> Helper loaded: util_helper
INFO - 2018-08-02 22:29:18 --> Helper loaded: text_helper
INFO - 2018-08-02 22:29:18 --> Helper loaded: string_helper
INFO - 2018-08-02 22:29:18 --> Database Driver Class Initialized
DEBUG - 2018-08-02 22:29:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-02 22:29:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-02 22:29:18 --> Email Class Initialized
INFO - 2018-08-02 22:29:18 --> Controller Class Initialized
DEBUG - 2018-08-02 22:29:18 --> Profile MX_Controller Initialized
INFO - 2018-08-02 22:29:18 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-02 22:29:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-02 22:29:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Profile_model.php
DEBUG - 2018-08-02 22:29:18 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-02 22:29:18 --> Login MX_Controller Initialized
DEBUG - 2018-08-02 22:29:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-02 22:29:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-08-02 22:29:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-08-02 22:29:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-08-02 22:29:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-08-02 22:29:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-08-02 22:29:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/profile.php
INFO - 2018-08-02 22:29:18 --> Final output sent to browser
DEBUG - 2018-08-02 22:29:18 --> Total execution time: 0.6922
INFO - 2018-08-02 22:29:21 --> Config Class Initialized
INFO - 2018-08-02 22:29:21 --> Hooks Class Initialized
DEBUG - 2018-08-02 22:29:21 --> UTF-8 Support Enabled
INFO - 2018-08-02 22:29:21 --> Utf8 Class Initialized
INFO - 2018-08-02 22:29:21 --> URI Class Initialized
INFO - 2018-08-02 22:29:21 --> Router Class Initialized
INFO - 2018-08-02 22:29:21 --> Output Class Initialized
INFO - 2018-08-02 22:29:21 --> Security Class Initialized
DEBUG - 2018-08-02 22:29:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 22:29:21 --> Input Class Initialized
INFO - 2018-08-02 22:29:21 --> Language Class Initialized
INFO - 2018-08-02 22:29:21 --> Language Class Initialized
INFO - 2018-08-02 22:29:21 --> Config Class Initialized
INFO - 2018-08-02 22:29:21 --> Loader Class Initialized
DEBUG - 2018-08-02 22:29:21 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-02 22:29:22 --> Helper loaded: url_helper
INFO - 2018-08-02 22:29:22 --> Helper loaded: form_helper
INFO - 2018-08-02 22:29:22 --> Helper loaded: date_helper
INFO - 2018-08-02 22:29:22 --> Helper loaded: util_helper
INFO - 2018-08-02 22:29:22 --> Helper loaded: text_helper
INFO - 2018-08-02 22:29:22 --> Helper loaded: string_helper
INFO - 2018-08-02 22:29:22 --> Database Driver Class Initialized
DEBUG - 2018-08-02 22:29:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-02 22:29:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-02 22:29:22 --> Email Class Initialized
INFO - 2018-08-02 22:29:22 --> Controller Class Initialized
DEBUG - 2018-08-02 22:29:22 --> Profile MX_Controller Initialized
INFO - 2018-08-02 22:29:22 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-02 22:29:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-02 22:29:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Profile_model.php
DEBUG - 2018-08-02 22:29:22 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-02 22:29:22 --> Login MX_Controller Initialized
DEBUG - 2018-08-02 22:29:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-02 22:29:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-08-02 22:29:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-08-02 22:29:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-08-02 22:29:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-08-02 22:29:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-08-02 22:29:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/profile.php
INFO - 2018-08-02 22:29:22 --> Final output sent to browser
DEBUG - 2018-08-02 22:29:22 --> Total execution time: 0.6599
INFO - 2018-08-02 22:29:36 --> Config Class Initialized
INFO - 2018-08-02 22:29:36 --> Hooks Class Initialized
DEBUG - 2018-08-02 22:29:36 --> UTF-8 Support Enabled
INFO - 2018-08-02 22:29:36 --> Utf8 Class Initialized
INFO - 2018-08-02 22:29:36 --> URI Class Initialized
INFO - 2018-08-02 22:29:36 --> Router Class Initialized
INFO - 2018-08-02 22:29:36 --> Output Class Initialized
INFO - 2018-08-02 22:29:36 --> Security Class Initialized
DEBUG - 2018-08-02 22:29:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 22:29:36 --> Input Class Initialized
INFO - 2018-08-02 22:29:36 --> Language Class Initialized
INFO - 2018-08-02 22:29:36 --> Language Class Initialized
INFO - 2018-08-02 22:29:36 --> Config Class Initialized
INFO - 2018-08-02 22:29:36 --> Loader Class Initialized
DEBUG - 2018-08-02 22:29:36 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-02 22:29:36 --> Helper loaded: url_helper
INFO - 2018-08-02 22:29:36 --> Helper loaded: form_helper
INFO - 2018-08-02 22:29:36 --> Helper loaded: date_helper
INFO - 2018-08-02 22:29:36 --> Helper loaded: util_helper
INFO - 2018-08-02 22:29:36 --> Helper loaded: text_helper
INFO - 2018-08-02 22:29:36 --> Helper loaded: string_helper
INFO - 2018-08-02 22:29:36 --> Database Driver Class Initialized
DEBUG - 2018-08-02 22:29:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-02 22:29:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-02 22:29:36 --> Email Class Initialized
INFO - 2018-08-02 22:29:36 --> Controller Class Initialized
DEBUG - 2018-08-02 22:29:37 --> Profile MX_Controller Initialized
INFO - 2018-08-02 22:29:37 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-02 22:29:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-02 22:29:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Profile_model.php
DEBUG - 2018-08-02 22:29:37 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-02 22:29:37 --> Login MX_Controller Initialized
DEBUG - 2018-08-02 22:29:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-02 22:29:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-08-02 22:29:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-08-02 22:29:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-08-02 22:29:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-08-02 22:29:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-08-02 22:29:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/profile.php
INFO - 2018-08-02 22:29:37 --> Final output sent to browser
DEBUG - 2018-08-02 22:29:37 --> Total execution time: 0.6670
INFO - 2018-08-02 23:04:54 --> Config Class Initialized
INFO - 2018-08-02 23:04:54 --> Hooks Class Initialized
DEBUG - 2018-08-02 23:04:54 --> UTF-8 Support Enabled
INFO - 2018-08-02 23:04:54 --> Utf8 Class Initialized
INFO - 2018-08-02 23:04:54 --> URI Class Initialized
INFO - 2018-08-02 23:04:54 --> Router Class Initialized
INFO - 2018-08-02 23:04:54 --> Output Class Initialized
INFO - 2018-08-02 23:04:54 --> Security Class Initialized
DEBUG - 2018-08-02 23:04:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 23:04:55 --> Input Class Initialized
INFO - 2018-08-02 23:04:55 --> Language Class Initialized
INFO - 2018-08-02 23:04:55 --> Language Class Initialized
INFO - 2018-08-02 23:04:55 --> Config Class Initialized
INFO - 2018-08-02 23:04:55 --> Loader Class Initialized
DEBUG - 2018-08-02 23:04:55 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-02 23:04:55 --> Helper loaded: url_helper
INFO - 2018-08-02 23:04:55 --> Helper loaded: form_helper
INFO - 2018-08-02 23:04:55 --> Helper loaded: date_helper
INFO - 2018-08-02 23:04:55 --> Helper loaded: util_helper
INFO - 2018-08-02 23:04:55 --> Helper loaded: text_helper
INFO - 2018-08-02 23:04:55 --> Helper loaded: string_helper
INFO - 2018-08-02 23:04:55 --> Database Driver Class Initialized
DEBUG - 2018-08-02 23:04:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-02 23:04:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-02 23:04:55 --> Email Class Initialized
INFO - 2018-08-02 23:04:55 --> Controller Class Initialized
DEBUG - 2018-08-02 23:04:55 --> Profile MX_Controller Initialized
INFO - 2018-08-02 23:04:55 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-02 23:04:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-02 23:04:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Profile_model.php
DEBUG - 2018-08-02 23:04:55 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-02 23:04:55 --> Login MX_Controller Initialized
DEBUG - 2018-08-02 23:04:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-02 23:04:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-08-02 23:04:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-08-02 23:04:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-08-02 23:04:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-08-02 23:04:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-08-02 23:04:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/profile.php
INFO - 2018-08-02 23:04:55 --> Final output sent to browser
DEBUG - 2018-08-02 23:04:55 --> Total execution time: 0.6961
INFO - 2018-08-02 23:05:07 --> Config Class Initialized
INFO - 2018-08-02 23:05:07 --> Hooks Class Initialized
DEBUG - 2018-08-02 23:05:07 --> UTF-8 Support Enabled
INFO - 2018-08-02 23:05:07 --> Utf8 Class Initialized
INFO - 2018-08-02 23:05:08 --> URI Class Initialized
INFO - 2018-08-02 23:05:08 --> Router Class Initialized
INFO - 2018-08-02 23:05:08 --> Output Class Initialized
INFO - 2018-08-02 23:05:08 --> Security Class Initialized
DEBUG - 2018-08-02 23:05:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 23:05:08 --> Input Class Initialized
INFO - 2018-08-02 23:05:08 --> Language Class Initialized
INFO - 2018-08-02 23:05:08 --> Language Class Initialized
INFO - 2018-08-02 23:05:08 --> Config Class Initialized
INFO - 2018-08-02 23:05:08 --> Loader Class Initialized
DEBUG - 2018-08-02 23:05:08 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-02 23:05:08 --> Helper loaded: url_helper
INFO - 2018-08-02 23:05:08 --> Helper loaded: form_helper
INFO - 2018-08-02 23:05:08 --> Helper loaded: date_helper
INFO - 2018-08-02 23:05:08 --> Helper loaded: util_helper
INFO - 2018-08-02 23:05:08 --> Helper loaded: text_helper
INFO - 2018-08-02 23:05:08 --> Helper loaded: string_helper
INFO - 2018-08-02 23:05:08 --> Database Driver Class Initialized
DEBUG - 2018-08-02 23:05:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-02 23:05:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-02 23:05:08 --> Email Class Initialized
INFO - 2018-08-02 23:05:08 --> Controller Class Initialized
DEBUG - 2018-08-02 23:05:08 --> Profile MX_Controller Initialized
INFO - 2018-08-02 23:05:08 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-02 23:05:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-02 23:05:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Profile_model.php
DEBUG - 2018-08-02 23:05:08 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-02 23:05:08 --> Login MX_Controller Initialized
DEBUG - 2018-08-02 23:05:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-02 23:05:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-08-02 23:05:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-08-02 23:05:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-08-02 23:05:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-08-02 23:05:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-08-02 23:05:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/profile.php
INFO - 2018-08-02 23:05:08 --> Final output sent to browser
DEBUG - 2018-08-02 23:05:08 --> Total execution time: 0.6677
INFO - 2018-08-02 23:08:12 --> Config Class Initialized
INFO - 2018-08-02 23:08:12 --> Hooks Class Initialized
DEBUG - 2018-08-02 23:08:12 --> UTF-8 Support Enabled
INFO - 2018-08-02 23:08:12 --> Utf8 Class Initialized
INFO - 2018-08-02 23:08:12 --> URI Class Initialized
INFO - 2018-08-02 23:08:12 --> Router Class Initialized
INFO - 2018-08-02 23:08:12 --> Output Class Initialized
INFO - 2018-08-02 23:08:12 --> Security Class Initialized
DEBUG - 2018-08-02 23:08:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 23:08:12 --> Input Class Initialized
INFO - 2018-08-02 23:08:12 --> Language Class Initialized
INFO - 2018-08-02 23:08:12 --> Language Class Initialized
INFO - 2018-08-02 23:08:12 --> Config Class Initialized
INFO - 2018-08-02 23:08:12 --> Loader Class Initialized
DEBUG - 2018-08-02 23:08:12 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-02 23:08:12 --> Helper loaded: url_helper
INFO - 2018-08-02 23:08:12 --> Helper loaded: form_helper
INFO - 2018-08-02 23:08:12 --> Helper loaded: date_helper
INFO - 2018-08-02 23:08:12 --> Helper loaded: util_helper
INFO - 2018-08-02 23:08:12 --> Helper loaded: text_helper
INFO - 2018-08-02 23:08:12 --> Helper loaded: string_helper
INFO - 2018-08-02 23:08:12 --> Database Driver Class Initialized
DEBUG - 2018-08-02 23:08:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-02 23:08:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-02 23:08:12 --> Email Class Initialized
INFO - 2018-08-02 23:08:12 --> Controller Class Initialized
DEBUG - 2018-08-02 23:08:12 --> Profile MX_Controller Initialized
INFO - 2018-08-02 23:08:12 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-02 23:08:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-02 23:08:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Profile_model.php
DEBUG - 2018-08-02 23:08:12 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-02 23:08:12 --> Login MX_Controller Initialized
DEBUG - 2018-08-02 23:08:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-02 23:08:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-08-02 23:08:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-08-02 23:08:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-08-02 23:08:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-08-02 23:08:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-08-02 23:08:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/profile.php
INFO - 2018-08-02 23:08:12 --> Final output sent to browser
DEBUG - 2018-08-02 23:08:12 --> Total execution time: 0.6921
INFO - 2018-08-02 23:09:08 --> Config Class Initialized
INFO - 2018-08-02 23:09:08 --> Hooks Class Initialized
DEBUG - 2018-08-02 23:09:08 --> UTF-8 Support Enabled
INFO - 2018-08-02 23:09:08 --> Utf8 Class Initialized
INFO - 2018-08-02 23:09:08 --> URI Class Initialized
INFO - 2018-08-02 23:09:08 --> Router Class Initialized
INFO - 2018-08-02 23:09:08 --> Output Class Initialized
INFO - 2018-08-02 23:09:08 --> Security Class Initialized
DEBUG - 2018-08-02 23:09:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 23:09:08 --> Input Class Initialized
INFO - 2018-08-02 23:09:08 --> Language Class Initialized
INFO - 2018-08-02 23:09:08 --> Language Class Initialized
INFO - 2018-08-02 23:09:08 --> Config Class Initialized
INFO - 2018-08-02 23:09:09 --> Loader Class Initialized
DEBUG - 2018-08-02 23:09:09 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-02 23:09:09 --> Helper loaded: url_helper
INFO - 2018-08-02 23:09:09 --> Helper loaded: form_helper
INFO - 2018-08-02 23:09:09 --> Helper loaded: date_helper
INFO - 2018-08-02 23:09:09 --> Helper loaded: util_helper
INFO - 2018-08-02 23:09:09 --> Helper loaded: text_helper
INFO - 2018-08-02 23:09:09 --> Helper loaded: string_helper
INFO - 2018-08-02 23:09:09 --> Database Driver Class Initialized
DEBUG - 2018-08-02 23:09:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-02 23:09:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-02 23:09:09 --> Email Class Initialized
INFO - 2018-08-02 23:09:09 --> Controller Class Initialized
DEBUG - 2018-08-02 23:09:09 --> Profile MX_Controller Initialized
INFO - 2018-08-02 23:09:09 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-02 23:09:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-02 23:09:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Profile_model.php
DEBUG - 2018-08-02 23:09:09 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-02 23:09:09 --> Login MX_Controller Initialized
DEBUG - 2018-08-02 23:09:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-02 23:09:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-08-02 23:09:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-08-02 23:09:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-08-02 23:09:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-08-02 23:09:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-08-02 23:09:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/profile.php
INFO - 2018-08-02 23:09:09 --> Final output sent to browser
DEBUG - 2018-08-02 23:09:09 --> Total execution time: 0.6879
INFO - 2018-08-02 23:09:32 --> Config Class Initialized
INFO - 2018-08-02 23:09:32 --> Hooks Class Initialized
DEBUG - 2018-08-02 23:09:32 --> UTF-8 Support Enabled
INFO - 2018-08-02 23:09:32 --> Utf8 Class Initialized
INFO - 2018-08-02 23:09:32 --> URI Class Initialized
INFO - 2018-08-02 23:09:32 --> Router Class Initialized
INFO - 2018-08-02 23:09:32 --> Output Class Initialized
INFO - 2018-08-02 23:09:32 --> Security Class Initialized
DEBUG - 2018-08-02 23:09:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 23:09:32 --> Input Class Initialized
INFO - 2018-08-02 23:09:32 --> Language Class Initialized
INFO - 2018-08-02 23:09:32 --> Language Class Initialized
INFO - 2018-08-02 23:09:32 --> Config Class Initialized
INFO - 2018-08-02 23:09:32 --> Loader Class Initialized
DEBUG - 2018-08-02 23:09:32 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-02 23:09:32 --> Helper loaded: url_helper
INFO - 2018-08-02 23:09:32 --> Helper loaded: form_helper
INFO - 2018-08-02 23:09:32 --> Helper loaded: date_helper
INFO - 2018-08-02 23:09:32 --> Helper loaded: util_helper
INFO - 2018-08-02 23:09:32 --> Helper loaded: text_helper
INFO - 2018-08-02 23:09:32 --> Helper loaded: string_helper
INFO - 2018-08-02 23:09:32 --> Database Driver Class Initialized
DEBUG - 2018-08-02 23:09:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-02 23:09:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-02 23:09:32 --> Email Class Initialized
INFO - 2018-08-02 23:09:32 --> Controller Class Initialized
DEBUG - 2018-08-02 23:09:32 --> Profile MX_Controller Initialized
INFO - 2018-08-02 23:09:32 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-02 23:09:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-02 23:09:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Profile_model.php
DEBUG - 2018-08-02 23:09:32 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-02 23:09:32 --> Login MX_Controller Initialized
DEBUG - 2018-08-02 23:09:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-02 23:09:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-08-02 23:09:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-08-02 23:09:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-08-02 23:09:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-08-02 23:09:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-08-02 23:09:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/profile.php
INFO - 2018-08-02 23:09:32 --> Final output sent to browser
DEBUG - 2018-08-02 23:09:32 --> Total execution time: 0.6954
INFO - 2018-08-02 23:10:58 --> Config Class Initialized
INFO - 2018-08-02 23:10:58 --> Hooks Class Initialized
DEBUG - 2018-08-02 23:10:58 --> UTF-8 Support Enabled
INFO - 2018-08-02 23:10:58 --> Utf8 Class Initialized
INFO - 2018-08-02 23:10:58 --> URI Class Initialized
INFO - 2018-08-02 23:10:58 --> Router Class Initialized
INFO - 2018-08-02 23:10:58 --> Output Class Initialized
INFO - 2018-08-02 23:10:58 --> Security Class Initialized
DEBUG - 2018-08-02 23:10:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 23:10:58 --> Input Class Initialized
INFO - 2018-08-02 23:10:58 --> Language Class Initialized
INFO - 2018-08-02 23:10:58 --> Language Class Initialized
INFO - 2018-08-02 23:10:58 --> Config Class Initialized
INFO - 2018-08-02 23:10:58 --> Loader Class Initialized
DEBUG - 2018-08-02 23:10:58 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-02 23:10:58 --> Helper loaded: url_helper
INFO - 2018-08-02 23:10:58 --> Helper loaded: form_helper
INFO - 2018-08-02 23:10:58 --> Helper loaded: date_helper
INFO - 2018-08-02 23:10:58 --> Helper loaded: util_helper
INFO - 2018-08-02 23:10:58 --> Helper loaded: text_helper
INFO - 2018-08-02 23:10:58 --> Helper loaded: string_helper
INFO - 2018-08-02 23:10:58 --> Database Driver Class Initialized
DEBUG - 2018-08-02 23:10:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-02 23:10:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-02 23:10:58 --> Email Class Initialized
INFO - 2018-08-02 23:10:58 --> Controller Class Initialized
DEBUG - 2018-08-02 23:10:58 --> Admin MX_Controller Initialized
INFO - 2018-08-02 23:10:58 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-02 23:10:58 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-02 23:10:58 --> Login MX_Controller Initialized
DEBUG - 2018-08-02 23:10:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-02 23:10:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-02 23:10:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-08-02 23:10:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-08-02 23:10:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-08-02 23:10:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-08-02 23:10:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-08-02 23:10:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/dashboard.php
INFO - 2018-08-02 23:10:58 --> Final output sent to browser
DEBUG - 2018-08-02 23:10:58 --> Total execution time: 0.6525
INFO - 2018-08-02 23:10:58 --> Config Class Initialized
INFO - 2018-08-02 23:10:58 --> Hooks Class Initialized
DEBUG - 2018-08-02 23:10:58 --> UTF-8 Support Enabled
INFO - 2018-08-02 23:10:58 --> Config Class Initialized
INFO - 2018-08-02 23:10:58 --> Hooks Class Initialized
INFO - 2018-08-02 23:10:58 --> Utf8 Class Initialized
DEBUG - 2018-08-02 23:10:58 --> UTF-8 Support Enabled
INFO - 2018-08-02 23:10:59 --> Utf8 Class Initialized
INFO - 2018-08-02 23:10:59 --> URI Class Initialized
INFO - 2018-08-02 23:10:59 --> URI Class Initialized
INFO - 2018-08-02 23:10:59 --> Router Class Initialized
INFO - 2018-08-02 23:10:59 --> Output Class Initialized
INFO - 2018-08-02 23:10:59 --> Router Class Initialized
INFO - 2018-08-02 23:10:59 --> Security Class Initialized
INFO - 2018-08-02 23:10:59 --> Output Class Initialized
DEBUG - 2018-08-02 23:10:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 23:10:59 --> Security Class Initialized
INFO - 2018-08-02 23:10:59 --> Input Class Initialized
INFO - 2018-08-02 23:10:59 --> Language Class Initialized
ERROR - 2018-08-02 23:10:59 --> 404 Page Not Found: /index
DEBUG - 2018-08-02 23:10:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 23:10:59 --> Input Class Initialized
INFO - 2018-08-02 23:10:59 --> Language Class Initialized
ERROR - 2018-08-02 23:10:59 --> 404 Page Not Found: /index
INFO - 2018-08-02 23:12:20 --> Config Class Initialized
INFO - 2018-08-02 23:12:20 --> Hooks Class Initialized
DEBUG - 2018-08-02 23:12:20 --> UTF-8 Support Enabled
INFO - 2018-08-02 23:12:20 --> Utf8 Class Initialized
INFO - 2018-08-02 23:12:20 --> URI Class Initialized
INFO - 2018-08-02 23:12:20 --> Router Class Initialized
INFO - 2018-08-02 23:12:20 --> Output Class Initialized
INFO - 2018-08-02 23:12:20 --> Security Class Initialized
DEBUG - 2018-08-02 23:12:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 23:12:20 --> Input Class Initialized
INFO - 2018-08-02 23:12:20 --> Language Class Initialized
INFO - 2018-08-02 23:12:20 --> Language Class Initialized
INFO - 2018-08-02 23:12:20 --> Config Class Initialized
INFO - 2018-08-02 23:12:20 --> Loader Class Initialized
DEBUG - 2018-08-02 23:12:20 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-02 23:12:20 --> Helper loaded: url_helper
INFO - 2018-08-02 23:12:20 --> Helper loaded: form_helper
INFO - 2018-08-02 23:12:20 --> Helper loaded: date_helper
INFO - 2018-08-02 23:12:20 --> Helper loaded: util_helper
INFO - 2018-08-02 23:12:20 --> Helper loaded: text_helper
INFO - 2018-08-02 23:12:20 --> Helper loaded: string_helper
INFO - 2018-08-02 23:12:20 --> Database Driver Class Initialized
DEBUG - 2018-08-02 23:12:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-02 23:12:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-02 23:12:20 --> Email Class Initialized
INFO - 2018-08-02 23:12:20 --> Controller Class Initialized
DEBUG - 2018-08-02 23:12:20 --> Admin MX_Controller Initialized
INFO - 2018-08-02 23:12:20 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-02 23:12:20 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-02 23:12:20 --> Login MX_Controller Initialized
DEBUG - 2018-08-02 23:12:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-02 23:12:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-02 23:12:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-08-02 23:12:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-08-02 23:12:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-08-02 23:12:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-08-02 23:12:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-08-02 23:12:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/dashboard.php
INFO - 2018-08-02 23:12:20 --> Final output sent to browser
DEBUG - 2018-08-02 23:12:20 --> Total execution time: 0.6571
INFO - 2018-08-02 23:12:20 --> Config Class Initialized
INFO - 2018-08-02 23:12:20 --> Config Class Initialized
INFO - 2018-08-02 23:12:20 --> Hooks Class Initialized
INFO - 2018-08-02 23:12:20 --> Hooks Class Initialized
DEBUG - 2018-08-02 23:12:21 --> UTF-8 Support Enabled
INFO - 2018-08-02 23:12:21 --> Utf8 Class Initialized
DEBUG - 2018-08-02 23:12:21 --> UTF-8 Support Enabled
INFO - 2018-08-02 23:12:21 --> URI Class Initialized
INFO - 2018-08-02 23:12:21 --> Utf8 Class Initialized
INFO - 2018-08-02 23:12:21 --> URI Class Initialized
INFO - 2018-08-02 23:12:21 --> Router Class Initialized
INFO - 2018-08-02 23:12:21 --> Router Class Initialized
INFO - 2018-08-02 23:12:21 --> Output Class Initialized
INFO - 2018-08-02 23:12:21 --> Output Class Initialized
INFO - 2018-08-02 23:12:21 --> Security Class Initialized
INFO - 2018-08-02 23:12:21 --> Security Class Initialized
DEBUG - 2018-08-02 23:12:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 23:12:21 --> Input Class Initialized
INFO - 2018-08-02 23:12:21 --> Language Class Initialized
ERROR - 2018-08-02 23:12:21 --> 404 Page Not Found: /index
DEBUG - 2018-08-02 23:12:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 23:12:21 --> Input Class Initialized
INFO - 2018-08-02 23:12:21 --> Language Class Initialized
ERROR - 2018-08-02 23:12:21 --> 404 Page Not Found: /index
INFO - 2018-08-02 23:13:06 --> Config Class Initialized
INFO - 2018-08-02 23:13:06 --> Hooks Class Initialized
DEBUG - 2018-08-02 23:13:06 --> UTF-8 Support Enabled
INFO - 2018-08-02 23:13:06 --> Utf8 Class Initialized
INFO - 2018-08-02 23:13:06 --> URI Class Initialized
INFO - 2018-08-02 23:13:06 --> Router Class Initialized
INFO - 2018-08-02 23:13:06 --> Output Class Initialized
INFO - 2018-08-02 23:13:06 --> Security Class Initialized
DEBUG - 2018-08-02 23:13:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 23:13:06 --> Input Class Initialized
INFO - 2018-08-02 23:13:06 --> Language Class Initialized
INFO - 2018-08-02 23:13:06 --> Language Class Initialized
INFO - 2018-08-02 23:13:06 --> Config Class Initialized
INFO - 2018-08-02 23:13:06 --> Loader Class Initialized
DEBUG - 2018-08-02 23:13:06 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-02 23:13:06 --> Helper loaded: url_helper
INFO - 2018-08-02 23:13:06 --> Helper loaded: form_helper
INFO - 2018-08-02 23:13:06 --> Helper loaded: date_helper
INFO - 2018-08-02 23:13:07 --> Helper loaded: util_helper
INFO - 2018-08-02 23:13:07 --> Helper loaded: text_helper
INFO - 2018-08-02 23:13:07 --> Helper loaded: string_helper
INFO - 2018-08-02 23:13:07 --> Database Driver Class Initialized
DEBUG - 2018-08-02 23:13:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-02 23:13:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-02 23:13:07 --> Email Class Initialized
INFO - 2018-08-02 23:13:07 --> Controller Class Initialized
DEBUG - 2018-08-02 23:13:07 --> Admin MX_Controller Initialized
INFO - 2018-08-02 23:13:07 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-02 23:13:07 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-02 23:13:07 --> Login MX_Controller Initialized
DEBUG - 2018-08-02 23:13:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-02 23:13:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-02 23:13:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-08-02 23:13:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-08-02 23:13:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-08-02 23:13:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-08-02 23:13:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-08-02 23:13:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/dashboard.php
INFO - 2018-08-02 23:13:07 --> Final output sent to browser
DEBUG - 2018-08-02 23:13:07 --> Total execution time: 0.6750
INFO - 2018-08-02 23:13:07 --> Config Class Initialized
INFO - 2018-08-02 23:13:07 --> Config Class Initialized
INFO - 2018-08-02 23:13:07 --> Hooks Class Initialized
INFO - 2018-08-02 23:13:07 --> Hooks Class Initialized
DEBUG - 2018-08-02 23:13:07 --> UTF-8 Support Enabled
DEBUG - 2018-08-02 23:13:07 --> UTF-8 Support Enabled
INFO - 2018-08-02 23:13:07 --> Utf8 Class Initialized
INFO - 2018-08-02 23:13:07 --> Utf8 Class Initialized
INFO - 2018-08-02 23:13:07 --> URI Class Initialized
INFO - 2018-08-02 23:13:07 --> URI Class Initialized
INFO - 2018-08-02 23:13:07 --> Router Class Initialized
INFO - 2018-08-02 23:13:07 --> Output Class Initialized
INFO - 2018-08-02 23:13:07 --> Router Class Initialized
INFO - 2018-08-02 23:13:07 --> Security Class Initialized
INFO - 2018-08-02 23:13:07 --> Output Class Initialized
DEBUG - 2018-08-02 23:13:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 23:13:07 --> Security Class Initialized
DEBUG - 2018-08-02 23:13:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 23:13:07 --> Input Class Initialized
INFO - 2018-08-02 23:13:07 --> Input Class Initialized
INFO - 2018-08-02 23:13:07 --> Language Class Initialized
ERROR - 2018-08-02 23:13:07 --> 404 Page Not Found: /index
INFO - 2018-08-02 23:13:07 --> Language Class Initialized
ERROR - 2018-08-02 23:13:07 --> 404 Page Not Found: /index
INFO - 2018-08-02 23:13:21 --> Config Class Initialized
INFO - 2018-08-02 23:13:21 --> Hooks Class Initialized
DEBUG - 2018-08-02 23:13:21 --> UTF-8 Support Enabled
INFO - 2018-08-02 23:13:22 --> Utf8 Class Initialized
INFO - 2018-08-02 23:13:22 --> URI Class Initialized
INFO - 2018-08-02 23:13:22 --> Router Class Initialized
INFO - 2018-08-02 23:13:22 --> Output Class Initialized
INFO - 2018-08-02 23:13:22 --> Security Class Initialized
DEBUG - 2018-08-02 23:13:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 23:13:22 --> Input Class Initialized
INFO - 2018-08-02 23:13:22 --> Language Class Initialized
INFO - 2018-08-02 23:13:22 --> Language Class Initialized
INFO - 2018-08-02 23:13:22 --> Config Class Initialized
INFO - 2018-08-02 23:13:22 --> Loader Class Initialized
DEBUG - 2018-08-02 23:13:22 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-02 23:13:22 --> Helper loaded: url_helper
INFO - 2018-08-02 23:13:22 --> Helper loaded: form_helper
INFO - 2018-08-02 23:13:22 --> Helper loaded: date_helper
INFO - 2018-08-02 23:13:22 --> Helper loaded: util_helper
INFO - 2018-08-02 23:13:22 --> Helper loaded: text_helper
INFO - 2018-08-02 23:13:22 --> Helper loaded: string_helper
INFO - 2018-08-02 23:13:22 --> Database Driver Class Initialized
DEBUG - 2018-08-02 23:13:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-02 23:13:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-02 23:13:22 --> Email Class Initialized
INFO - 2018-08-02 23:13:22 --> Controller Class Initialized
DEBUG - 2018-08-02 23:13:22 --> Admin MX_Controller Initialized
INFO - 2018-08-02 23:13:22 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-02 23:13:22 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-02 23:13:22 --> Login MX_Controller Initialized
DEBUG - 2018-08-02 23:13:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-02 23:13:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-02 23:13:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-08-02 23:13:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-08-02 23:13:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-08-02 23:13:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-08-02 23:13:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-08-02 23:13:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/dashboard.php
INFO - 2018-08-02 23:13:22 --> Final output sent to browser
DEBUG - 2018-08-02 23:13:22 --> Total execution time: 0.6865
INFO - 2018-08-02 23:13:22 --> Config Class Initialized
INFO - 2018-08-02 23:13:22 --> Config Class Initialized
INFO - 2018-08-02 23:13:22 --> Hooks Class Initialized
INFO - 2018-08-02 23:13:22 --> Hooks Class Initialized
DEBUG - 2018-08-02 23:13:22 --> UTF-8 Support Enabled
DEBUG - 2018-08-02 23:13:22 --> UTF-8 Support Enabled
INFO - 2018-08-02 23:13:22 --> Utf8 Class Initialized
INFO - 2018-08-02 23:13:22 --> URI Class Initialized
INFO - 2018-08-02 23:13:22 --> Utf8 Class Initialized
INFO - 2018-08-02 23:13:22 --> Router Class Initialized
INFO - 2018-08-02 23:13:22 --> Output Class Initialized
INFO - 2018-08-02 23:13:22 --> URI Class Initialized
INFO - 2018-08-02 23:13:22 --> Security Class Initialized
DEBUG - 2018-08-02 23:13:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 23:13:22 --> Input Class Initialized
INFO - 2018-08-02 23:13:22 --> Language Class Initialized
ERROR - 2018-08-02 23:13:22 --> 404 Page Not Found: /index
INFO - 2018-08-02 23:13:23 --> Router Class Initialized
INFO - 2018-08-02 23:13:23 --> Output Class Initialized
INFO - 2018-08-02 23:13:23 --> Security Class Initialized
DEBUG - 2018-08-02 23:13:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 23:13:23 --> Input Class Initialized
INFO - 2018-08-02 23:13:23 --> Language Class Initialized
ERROR - 2018-08-02 23:13:23 --> 404 Page Not Found: /index
INFO - 2018-08-02 23:13:23 --> Config Class Initialized
INFO - 2018-08-02 23:13:23 --> Hooks Class Initialized
DEBUG - 2018-08-02 23:13:23 --> UTF-8 Support Enabled
INFO - 2018-08-02 23:13:23 --> Utf8 Class Initialized
INFO - 2018-08-02 23:13:23 --> URI Class Initialized
INFO - 2018-08-02 23:13:23 --> Router Class Initialized
INFO - 2018-08-02 23:13:23 --> Output Class Initialized
INFO - 2018-08-02 23:13:23 --> Security Class Initialized
DEBUG - 2018-08-02 23:13:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 23:13:23 --> Input Class Initialized
INFO - 2018-08-02 23:13:23 --> Language Class Initialized
ERROR - 2018-08-02 23:13:23 --> 404 Page Not Found: /index
INFO - 2018-08-02 23:13:24 --> Config Class Initialized
INFO - 2018-08-02 23:13:24 --> Hooks Class Initialized
DEBUG - 2018-08-02 23:13:24 --> UTF-8 Support Enabled
INFO - 2018-08-02 23:13:24 --> Utf8 Class Initialized
INFO - 2018-08-02 23:13:24 --> URI Class Initialized
INFO - 2018-08-02 23:13:24 --> Router Class Initialized
INFO - 2018-08-02 23:13:24 --> Output Class Initialized
INFO - 2018-08-02 23:13:24 --> Security Class Initialized
DEBUG - 2018-08-02 23:13:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 23:13:24 --> Input Class Initialized
INFO - 2018-08-02 23:13:24 --> Language Class Initialized
INFO - 2018-08-02 23:13:24 --> Language Class Initialized
INFO - 2018-08-02 23:13:24 --> Config Class Initialized
INFO - 2018-08-02 23:13:24 --> Loader Class Initialized
DEBUG - 2018-08-02 23:13:24 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-02 23:13:24 --> Helper loaded: url_helper
INFO - 2018-08-02 23:13:24 --> Helper loaded: form_helper
INFO - 2018-08-02 23:13:24 --> Helper loaded: date_helper
INFO - 2018-08-02 23:13:25 --> Helper loaded: util_helper
INFO - 2018-08-02 23:13:25 --> Helper loaded: text_helper
INFO - 2018-08-02 23:13:25 --> Helper loaded: string_helper
INFO - 2018-08-02 23:13:25 --> Database Driver Class Initialized
DEBUG - 2018-08-02 23:13:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-02 23:13:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-02 23:13:25 --> Email Class Initialized
INFO - 2018-08-02 23:13:25 --> Controller Class Initialized
DEBUG - 2018-08-02 23:13:25 --> Profile MX_Controller Initialized
INFO - 2018-08-02 23:13:25 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-02 23:13:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-02 23:13:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Profile_model.php
DEBUG - 2018-08-02 23:13:25 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-02 23:13:25 --> Login MX_Controller Initialized
DEBUG - 2018-08-02 23:13:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-02 23:13:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-08-02 23:13:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-08-02 23:13:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-08-02 23:13:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-08-02 23:13:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-08-02 23:13:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/profile.php
INFO - 2018-08-02 23:13:25 --> Final output sent to browser
DEBUG - 2018-08-02 23:13:25 --> Total execution time: 0.7353
INFO - 2018-08-02 23:13:27 --> Config Class Initialized
INFO - 2018-08-02 23:13:27 --> Hooks Class Initialized
DEBUG - 2018-08-02 23:13:27 --> UTF-8 Support Enabled
INFO - 2018-08-02 23:13:27 --> Utf8 Class Initialized
INFO - 2018-08-02 23:13:27 --> URI Class Initialized
INFO - 2018-08-02 23:13:27 --> Router Class Initialized
INFO - 2018-08-02 23:13:27 --> Output Class Initialized
INFO - 2018-08-02 23:13:27 --> Security Class Initialized
DEBUG - 2018-08-02 23:13:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 23:13:28 --> Input Class Initialized
INFO - 2018-08-02 23:13:28 --> Language Class Initialized
INFO - 2018-08-02 23:13:28 --> Language Class Initialized
INFO - 2018-08-02 23:13:28 --> Config Class Initialized
INFO - 2018-08-02 23:13:28 --> Loader Class Initialized
DEBUG - 2018-08-02 23:13:28 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-02 23:13:28 --> Helper loaded: url_helper
INFO - 2018-08-02 23:13:28 --> Helper loaded: form_helper
INFO - 2018-08-02 23:13:28 --> Helper loaded: date_helper
INFO - 2018-08-02 23:13:28 --> Helper loaded: util_helper
INFO - 2018-08-02 23:13:28 --> Helper loaded: text_helper
INFO - 2018-08-02 23:13:28 --> Helper loaded: string_helper
INFO - 2018-08-02 23:13:28 --> Database Driver Class Initialized
DEBUG - 2018-08-02 23:13:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-02 23:13:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-02 23:13:28 --> Email Class Initialized
INFO - 2018-08-02 23:13:28 --> Controller Class Initialized
DEBUG - 2018-08-02 23:13:28 --> Admin MX_Controller Initialized
INFO - 2018-08-02 23:13:28 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-02 23:13:28 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-02 23:13:28 --> Login MX_Controller Initialized
DEBUG - 2018-08-02 23:13:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-02 23:13:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-02 23:13:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-08-02 23:13:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-08-02 23:13:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-08-02 23:13:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-08-02 23:13:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-08-02 23:13:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/dashboard.php
INFO - 2018-08-02 23:13:28 --> Final output sent to browser
DEBUG - 2018-08-02 23:13:28 --> Total execution time: 0.6841
INFO - 2018-08-02 23:13:28 --> Config Class Initialized
INFO - 2018-08-02 23:13:28 --> Hooks Class Initialized
INFO - 2018-08-02 23:13:28 --> Config Class Initialized
INFO - 2018-08-02 23:13:28 --> Hooks Class Initialized
DEBUG - 2018-08-02 23:13:28 --> UTF-8 Support Enabled
INFO - 2018-08-02 23:13:28 --> Utf8 Class Initialized
DEBUG - 2018-08-02 23:13:28 --> UTF-8 Support Enabled
INFO - 2018-08-02 23:13:28 --> Utf8 Class Initialized
INFO - 2018-08-02 23:13:28 --> URI Class Initialized
INFO - 2018-08-02 23:13:28 --> URI Class Initialized
INFO - 2018-08-02 23:13:28 --> Router Class Initialized
INFO - 2018-08-02 23:13:28 --> Output Class Initialized
INFO - 2018-08-02 23:13:28 --> Security Class Initialized
DEBUG - 2018-08-02 23:13:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 23:13:28 --> Input Class Initialized
INFO - 2018-08-02 23:13:28 --> Language Class Initialized
ERROR - 2018-08-02 23:13:28 --> 404 Page Not Found: /index
INFO - 2018-08-02 23:13:28 --> Router Class Initialized
INFO - 2018-08-02 23:13:28 --> Output Class Initialized
INFO - 2018-08-02 23:13:28 --> Security Class Initialized
DEBUG - 2018-08-02 23:13:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 23:13:29 --> Input Class Initialized
INFO - 2018-08-02 23:13:29 --> Language Class Initialized
ERROR - 2018-08-02 23:13:29 --> 404 Page Not Found: /index
INFO - 2018-08-02 23:13:29 --> Config Class Initialized
INFO - 2018-08-02 23:13:29 --> Hooks Class Initialized
DEBUG - 2018-08-02 23:13:29 --> UTF-8 Support Enabled
INFO - 2018-08-02 23:13:29 --> Utf8 Class Initialized
INFO - 2018-08-02 23:13:29 --> URI Class Initialized
INFO - 2018-08-02 23:13:29 --> Router Class Initialized
INFO - 2018-08-02 23:13:29 --> Output Class Initialized
INFO - 2018-08-02 23:13:29 --> Security Class Initialized
DEBUG - 2018-08-02 23:13:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-02 23:13:29 --> Input Class Initialized
INFO - 2018-08-02 23:13:29 --> Language Class Initialized
ERROR - 2018-08-02 23:13:29 --> 404 Page Not Found: /index
