<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-08-03 00:55:06 --> Config Class Initialized
INFO - 2018-08-03 00:55:06 --> Hooks Class Initialized
DEBUG - 2018-08-03 00:55:06 --> UTF-8 Support Enabled
INFO - 2018-08-03 00:55:06 --> Utf8 Class Initialized
INFO - 2018-08-03 00:55:06 --> URI Class Initialized
INFO - 2018-08-03 00:55:06 --> Router Class Initialized
INFO - 2018-08-03 00:55:06 --> Output Class Initialized
INFO - 2018-08-03 00:55:06 --> Security Class Initialized
DEBUG - 2018-08-03 00:55:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 00:55:06 --> Input Class Initialized
INFO - 2018-08-03 00:55:06 --> Language Class Initialized
INFO - 2018-08-03 00:55:06 --> Language Class Initialized
INFO - 2018-08-03 00:55:06 --> Config Class Initialized
INFO - 2018-08-03 00:55:06 --> Loader Class Initialized
DEBUG - 2018-08-03 00:55:06 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-03 00:55:06 --> Helper loaded: url_helper
INFO - 2018-08-03 00:55:06 --> Helper loaded: form_helper
INFO - 2018-08-03 00:55:06 --> Helper loaded: date_helper
INFO - 2018-08-03 00:55:06 --> Helper loaded: util_helper
INFO - 2018-08-03 00:55:06 --> Helper loaded: text_helper
INFO - 2018-08-03 00:55:06 --> Helper loaded: string_helper
INFO - 2018-08-03 00:55:06 --> Database Driver Class Initialized
DEBUG - 2018-08-03 00:55:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 00:55:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-03 00:55:06 --> Email Class Initialized
INFO - 2018-08-03 00:55:06 --> Controller Class Initialized
DEBUG - 2018-08-03 00:55:06 --> Admin MX_Controller Initialized
INFO - 2018-08-03 00:55:06 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-03 00:55:06 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-03 00:55:06 --> Login MX_Controller Initialized
DEBUG - 2018-08-03 00:55:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-03 00:55:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-03 00:55:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-08-03 00:55:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-08-03 00:55:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-08-03 00:55:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-08-03 00:55:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-08-03 00:55:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/dashboard.php
INFO - 2018-08-03 00:55:06 --> Final output sent to browser
DEBUG - 2018-08-03 00:55:06 --> Total execution time: 0.3676
INFO - 2018-08-03 00:55:06 --> Config Class Initialized
INFO - 2018-08-03 00:55:06 --> Config Class Initialized
INFO - 2018-08-03 00:55:06 --> Hooks Class Initialized
INFO - 2018-08-03 00:55:06 --> Hooks Class Initialized
DEBUG - 2018-08-03 00:55:06 --> UTF-8 Support Enabled
DEBUG - 2018-08-03 00:55:06 --> UTF-8 Support Enabled
INFO - 2018-08-03 00:55:06 --> Utf8 Class Initialized
INFO - 2018-08-03 00:55:06 --> Utf8 Class Initialized
INFO - 2018-08-03 00:55:06 --> URI Class Initialized
INFO - 2018-08-03 00:55:06 --> URI Class Initialized
INFO - 2018-08-03 00:55:06 --> Router Class Initialized
INFO - 2018-08-03 00:55:06 --> Output Class Initialized
INFO - 2018-08-03 00:55:06 --> Router Class Initialized
INFO - 2018-08-03 00:55:06 --> Security Class Initialized
INFO - 2018-08-03 00:55:06 --> Output Class Initialized
DEBUG - 2018-08-03 00:55:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 00:55:06 --> Security Class Initialized
INFO - 2018-08-03 00:55:06 --> Input Class Initialized
DEBUG - 2018-08-03 00:55:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 00:55:06 --> Language Class Initialized
INFO - 2018-08-03 00:55:06 --> Input Class Initialized
INFO - 2018-08-03 00:55:06 --> Language Class Initialized
ERROR - 2018-08-03 00:55:06 --> 404 Page Not Found: /index
ERROR - 2018-08-03 00:55:06 --> 404 Page Not Found: /index
INFO - 2018-08-03 00:55:06 --> Config Class Initialized
INFO - 2018-08-03 00:55:06 --> Hooks Class Initialized
DEBUG - 2018-08-03 00:55:07 --> UTF-8 Support Enabled
INFO - 2018-08-03 00:55:07 --> Utf8 Class Initialized
INFO - 2018-08-03 00:55:07 --> URI Class Initialized
INFO - 2018-08-03 00:55:07 --> Router Class Initialized
INFO - 2018-08-03 00:55:07 --> Output Class Initialized
INFO - 2018-08-03 00:55:07 --> Security Class Initialized
DEBUG - 2018-08-03 00:55:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 00:55:07 --> Input Class Initialized
INFO - 2018-08-03 00:55:07 --> Language Class Initialized
ERROR - 2018-08-03 00:55:07 --> 404 Page Not Found: /index
INFO - 2018-08-03 00:55:17 --> Config Class Initialized
INFO - 2018-08-03 00:55:18 --> Hooks Class Initialized
DEBUG - 2018-08-03 00:55:18 --> UTF-8 Support Enabled
INFO - 2018-08-03 00:55:18 --> Utf8 Class Initialized
INFO - 2018-08-03 00:55:18 --> URI Class Initialized
INFO - 2018-08-03 00:55:18 --> Router Class Initialized
INFO - 2018-08-03 00:55:18 --> Output Class Initialized
INFO - 2018-08-03 00:55:18 --> Security Class Initialized
DEBUG - 2018-08-03 00:55:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 00:55:18 --> Input Class Initialized
INFO - 2018-08-03 00:55:18 --> Language Class Initialized
INFO - 2018-08-03 00:55:18 --> Language Class Initialized
INFO - 2018-08-03 00:55:18 --> Config Class Initialized
INFO - 2018-08-03 00:55:18 --> Loader Class Initialized
DEBUG - 2018-08-03 00:55:18 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-03 00:55:18 --> Helper loaded: url_helper
INFO - 2018-08-03 00:55:18 --> Helper loaded: form_helper
INFO - 2018-08-03 00:55:18 --> Helper loaded: date_helper
INFO - 2018-08-03 00:55:18 --> Helper loaded: util_helper
INFO - 2018-08-03 00:55:18 --> Helper loaded: text_helper
INFO - 2018-08-03 00:55:18 --> Helper loaded: string_helper
INFO - 2018-08-03 00:55:18 --> Database Driver Class Initialized
DEBUG - 2018-08-03 00:55:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 00:55:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-03 00:55:18 --> Email Class Initialized
INFO - 2018-08-03 00:55:18 --> Controller Class Initialized
DEBUG - 2018-08-03 00:55:18 --> Admin MX_Controller Initialized
INFO - 2018-08-03 00:55:18 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-03 00:55:18 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-03 00:55:18 --> Login MX_Controller Initialized
DEBUG - 2018-08-03 00:55:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-03 00:55:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-03 00:55:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-08-03 00:55:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-08-03 00:55:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-08-03 00:55:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-08-03 00:55:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-08-03 00:55:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/dashboard.php
INFO - 2018-08-03 00:55:18 --> Final output sent to browser
DEBUG - 2018-08-03 00:55:18 --> Total execution time: 0.3787
INFO - 2018-08-03 00:55:18 --> Config Class Initialized
INFO - 2018-08-03 00:55:18 --> Config Class Initialized
INFO - 2018-08-03 00:55:18 --> Hooks Class Initialized
INFO - 2018-08-03 00:55:18 --> Hooks Class Initialized
DEBUG - 2018-08-03 00:55:18 --> UTF-8 Support Enabled
DEBUG - 2018-08-03 00:55:18 --> UTF-8 Support Enabled
INFO - 2018-08-03 00:55:18 --> Utf8 Class Initialized
INFO - 2018-08-03 00:55:18 --> Utf8 Class Initialized
INFO - 2018-08-03 00:55:18 --> URI Class Initialized
INFO - 2018-08-03 00:55:18 --> URI Class Initialized
INFO - 2018-08-03 00:55:18 --> Router Class Initialized
INFO - 2018-08-03 00:55:18 --> Router Class Initialized
INFO - 2018-08-03 00:55:18 --> Output Class Initialized
INFO - 2018-08-03 00:55:18 --> Output Class Initialized
INFO - 2018-08-03 00:55:18 --> Security Class Initialized
INFO - 2018-08-03 00:55:18 --> Security Class Initialized
DEBUG - 2018-08-03 00:55:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-08-03 00:55:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 00:55:18 --> Input Class Initialized
INFO - 2018-08-03 00:55:18 --> Language Class Initialized
ERROR - 2018-08-03 00:55:18 --> 404 Page Not Found: /index
INFO - 2018-08-03 00:55:18 --> Input Class Initialized
INFO - 2018-08-03 00:55:18 --> Language Class Initialized
ERROR - 2018-08-03 00:55:18 --> 404 Page Not Found: /index
INFO - 2018-08-03 00:55:18 --> Config Class Initialized
INFO - 2018-08-03 00:55:18 --> Hooks Class Initialized
DEBUG - 2018-08-03 00:55:18 --> UTF-8 Support Enabled
INFO - 2018-08-03 00:55:18 --> Utf8 Class Initialized
INFO - 2018-08-03 00:55:18 --> URI Class Initialized
INFO - 2018-08-03 00:55:18 --> Router Class Initialized
INFO - 2018-08-03 00:55:18 --> Output Class Initialized
INFO - 2018-08-03 00:55:18 --> Security Class Initialized
DEBUG - 2018-08-03 00:55:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 00:55:18 --> Input Class Initialized
INFO - 2018-08-03 00:55:18 --> Language Class Initialized
ERROR - 2018-08-03 00:55:18 --> 404 Page Not Found: /index
INFO - 2018-08-03 00:55:48 --> Config Class Initialized
INFO - 2018-08-03 00:55:48 --> Hooks Class Initialized
DEBUG - 2018-08-03 00:55:48 --> UTF-8 Support Enabled
INFO - 2018-08-03 00:55:49 --> Utf8 Class Initialized
INFO - 2018-08-03 00:55:49 --> URI Class Initialized
INFO - 2018-08-03 00:55:49 --> Router Class Initialized
INFO - 2018-08-03 00:55:49 --> Output Class Initialized
INFO - 2018-08-03 00:55:49 --> Security Class Initialized
DEBUG - 2018-08-03 00:55:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 00:55:49 --> Input Class Initialized
INFO - 2018-08-03 00:55:49 --> Language Class Initialized
INFO - 2018-08-03 00:55:49 --> Language Class Initialized
INFO - 2018-08-03 00:55:49 --> Config Class Initialized
INFO - 2018-08-03 00:55:49 --> Loader Class Initialized
DEBUG - 2018-08-03 00:55:49 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-03 00:55:49 --> Helper loaded: url_helper
INFO - 2018-08-03 00:55:49 --> Helper loaded: form_helper
INFO - 2018-08-03 00:55:49 --> Helper loaded: date_helper
INFO - 2018-08-03 00:55:49 --> Helper loaded: util_helper
INFO - 2018-08-03 00:55:49 --> Helper loaded: text_helper
INFO - 2018-08-03 00:55:49 --> Helper loaded: string_helper
INFO - 2018-08-03 00:55:49 --> Database Driver Class Initialized
DEBUG - 2018-08-03 00:55:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 00:55:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-03 00:55:49 --> Email Class Initialized
INFO - 2018-08-03 00:55:49 --> Controller Class Initialized
DEBUG - 2018-08-03 00:55:49 --> Admin MX_Controller Initialized
INFO - 2018-08-03 00:55:49 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-03 00:55:49 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-03 00:55:49 --> Login MX_Controller Initialized
DEBUG - 2018-08-03 00:55:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-03 00:55:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-03 00:55:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-08-03 00:55:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-08-03 00:55:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-08-03 00:55:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-08-03 00:55:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-08-03 00:55:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/dashboard.php
INFO - 2018-08-03 00:55:49 --> Final output sent to browser
DEBUG - 2018-08-03 00:55:49 --> Total execution time: 0.3722
INFO - 2018-08-03 00:55:49 --> Config Class Initialized
INFO - 2018-08-03 00:55:49 --> Config Class Initialized
INFO - 2018-08-03 00:55:49 --> Hooks Class Initialized
INFO - 2018-08-03 00:55:49 --> Hooks Class Initialized
DEBUG - 2018-08-03 00:55:49 --> UTF-8 Support Enabled
DEBUG - 2018-08-03 00:55:49 --> UTF-8 Support Enabled
INFO - 2018-08-03 00:55:49 --> Utf8 Class Initialized
INFO - 2018-08-03 00:55:49 --> URI Class Initialized
INFO - 2018-08-03 00:55:49 --> Router Class Initialized
INFO - 2018-08-03 00:55:49 --> Output Class Initialized
INFO - 2018-08-03 00:55:49 --> Security Class Initialized
DEBUG - 2018-08-03 00:55:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 00:55:49 --> Input Class Initialized
INFO - 2018-08-03 00:55:49 --> Language Class Initialized
ERROR - 2018-08-03 00:55:49 --> 404 Page Not Found: /index
INFO - 2018-08-03 00:55:49 --> Utf8 Class Initialized
INFO - 2018-08-03 00:55:49 --> URI Class Initialized
INFO - 2018-08-03 00:55:49 --> Router Class Initialized
INFO - 2018-08-03 00:55:49 --> Output Class Initialized
INFO - 2018-08-03 00:55:49 --> Security Class Initialized
DEBUG - 2018-08-03 00:55:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 00:55:49 --> Input Class Initialized
INFO - 2018-08-03 00:55:49 --> Language Class Initialized
ERROR - 2018-08-03 00:55:49 --> 404 Page Not Found: /index
INFO - 2018-08-03 00:55:49 --> Config Class Initialized
INFO - 2018-08-03 00:55:49 --> Hooks Class Initialized
DEBUG - 2018-08-03 00:55:49 --> UTF-8 Support Enabled
INFO - 2018-08-03 00:55:49 --> Utf8 Class Initialized
INFO - 2018-08-03 00:55:49 --> URI Class Initialized
INFO - 2018-08-03 00:55:49 --> Router Class Initialized
INFO - 2018-08-03 00:55:49 --> Output Class Initialized
INFO - 2018-08-03 00:55:49 --> Security Class Initialized
DEBUG - 2018-08-03 00:55:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 00:55:49 --> Input Class Initialized
INFO - 2018-08-03 00:55:49 --> Language Class Initialized
ERROR - 2018-08-03 00:55:49 --> 404 Page Not Found: /index
INFO - 2018-08-03 00:56:07 --> Config Class Initialized
INFO - 2018-08-03 00:56:07 --> Hooks Class Initialized
DEBUG - 2018-08-03 00:56:07 --> UTF-8 Support Enabled
INFO - 2018-08-03 00:56:07 --> Utf8 Class Initialized
INFO - 2018-08-03 00:56:07 --> URI Class Initialized
INFO - 2018-08-03 00:56:07 --> Router Class Initialized
INFO - 2018-08-03 00:56:07 --> Output Class Initialized
INFO - 2018-08-03 00:56:07 --> Security Class Initialized
DEBUG - 2018-08-03 00:56:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 00:56:07 --> Input Class Initialized
INFO - 2018-08-03 00:56:07 --> Language Class Initialized
INFO - 2018-08-03 00:56:07 --> Language Class Initialized
INFO - 2018-08-03 00:56:07 --> Config Class Initialized
INFO - 2018-08-03 00:56:07 --> Loader Class Initialized
DEBUG - 2018-08-03 00:56:07 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-03 00:56:07 --> Helper loaded: url_helper
INFO - 2018-08-03 00:56:07 --> Helper loaded: form_helper
INFO - 2018-08-03 00:56:07 --> Helper loaded: date_helper
INFO - 2018-08-03 00:56:07 --> Helper loaded: util_helper
INFO - 2018-08-03 00:56:07 --> Helper loaded: text_helper
INFO - 2018-08-03 00:56:07 --> Helper loaded: string_helper
INFO - 2018-08-03 00:56:07 --> Database Driver Class Initialized
DEBUG - 2018-08-03 00:56:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 00:56:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-03 00:56:07 --> Email Class Initialized
INFO - 2018-08-03 00:56:07 --> Controller Class Initialized
DEBUG - 2018-08-03 00:56:07 --> Admin MX_Controller Initialized
INFO - 2018-08-03 00:56:07 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-03 00:56:07 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-03 00:56:07 --> Login MX_Controller Initialized
DEBUG - 2018-08-03 00:56:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-03 00:56:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-03 00:56:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-08-03 00:56:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-08-03 00:56:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-08-03 00:56:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-08-03 00:56:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-08-03 00:56:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/dashboard.php
INFO - 2018-08-03 00:56:07 --> Final output sent to browser
DEBUG - 2018-08-03 00:56:07 --> Total execution time: 0.3615
INFO - 2018-08-03 00:56:08 --> Config Class Initialized
INFO - 2018-08-03 00:56:08 --> Config Class Initialized
INFO - 2018-08-03 00:56:08 --> Hooks Class Initialized
INFO - 2018-08-03 00:56:08 --> Hooks Class Initialized
DEBUG - 2018-08-03 00:56:08 --> UTF-8 Support Enabled
DEBUG - 2018-08-03 00:56:08 --> UTF-8 Support Enabled
INFO - 2018-08-03 00:56:08 --> Utf8 Class Initialized
INFO - 2018-08-03 00:56:08 --> Utf8 Class Initialized
INFO - 2018-08-03 00:56:08 --> URI Class Initialized
INFO - 2018-08-03 00:56:08 --> URI Class Initialized
INFO - 2018-08-03 00:56:08 --> Router Class Initialized
INFO - 2018-08-03 00:56:08 --> Router Class Initialized
INFO - 2018-08-03 00:56:08 --> Output Class Initialized
INFO - 2018-08-03 00:56:08 --> Output Class Initialized
INFO - 2018-08-03 00:56:08 --> Security Class Initialized
INFO - 2018-08-03 00:56:08 --> Security Class Initialized
DEBUG - 2018-08-03 00:56:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-08-03 00:56:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 00:56:08 --> Input Class Initialized
INFO - 2018-08-03 00:56:08 --> Input Class Initialized
INFO - 2018-08-03 00:56:08 --> Language Class Initialized
INFO - 2018-08-03 00:56:08 --> Language Class Initialized
ERROR - 2018-08-03 00:56:08 --> 404 Page Not Found: /index
ERROR - 2018-08-03 00:56:08 --> 404 Page Not Found: /index
INFO - 2018-08-03 00:56:08 --> Config Class Initialized
INFO - 2018-08-03 00:56:08 --> Hooks Class Initialized
DEBUG - 2018-08-03 00:56:08 --> UTF-8 Support Enabled
INFO - 2018-08-03 00:56:08 --> Utf8 Class Initialized
INFO - 2018-08-03 00:56:08 --> URI Class Initialized
INFO - 2018-08-03 00:56:08 --> Router Class Initialized
INFO - 2018-08-03 00:56:08 --> Output Class Initialized
INFO - 2018-08-03 00:56:08 --> Security Class Initialized
DEBUG - 2018-08-03 00:56:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 00:56:08 --> Input Class Initialized
INFO - 2018-08-03 00:56:08 --> Language Class Initialized
ERROR - 2018-08-03 00:56:08 --> 404 Page Not Found: /index
INFO - 2018-08-03 00:57:33 --> Config Class Initialized
INFO - 2018-08-03 00:57:33 --> Hooks Class Initialized
DEBUG - 2018-08-03 00:57:33 --> UTF-8 Support Enabled
INFO - 2018-08-03 00:57:33 --> Utf8 Class Initialized
INFO - 2018-08-03 00:57:33 --> URI Class Initialized
DEBUG - 2018-08-03 00:57:33 --> No URI present. Default controller set.
INFO - 2018-08-03 00:57:33 --> Router Class Initialized
INFO - 2018-08-03 00:57:33 --> Output Class Initialized
INFO - 2018-08-03 00:57:33 --> Security Class Initialized
DEBUG - 2018-08-03 00:57:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 00:57:33 --> Input Class Initialized
INFO - 2018-08-03 00:57:33 --> Language Class Initialized
INFO - 2018-08-03 00:57:33 --> Language Class Initialized
INFO - 2018-08-03 00:57:33 --> Config Class Initialized
INFO - 2018-08-03 00:57:33 --> Loader Class Initialized
DEBUG - 2018-08-03 00:57:33 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-03 00:57:33 --> Helper loaded: url_helper
INFO - 2018-08-03 00:57:33 --> Helper loaded: form_helper
INFO - 2018-08-03 00:57:33 --> Helper loaded: date_helper
INFO - 2018-08-03 00:57:33 --> Helper loaded: util_helper
INFO - 2018-08-03 00:57:33 --> Helper loaded: text_helper
INFO - 2018-08-03 00:57:33 --> Helper loaded: string_helper
INFO - 2018-08-03 00:57:33 --> Database Driver Class Initialized
DEBUG - 2018-08-03 00:57:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 00:57:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-03 00:57:33 --> Email Class Initialized
INFO - 2018-08-03 00:57:33 --> Controller Class Initialized
DEBUG - 2018-08-03 00:57:33 --> Home MX_Controller Initialized
DEBUG - 2018-08-03 00:57:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-03 00:57:33 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-03 00:57:33 --> Login MX_Controller Initialized
INFO - 2018-08-03 00:57:33 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-03 00:57:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-03 00:57:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-03 00:57:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-08-03 00:57:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-08-03 00:57:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-08-03 00:57:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-08-03 00:57:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-08-03 00:57:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-08-03 00:57:33 --> Final output sent to browser
DEBUG - 2018-08-03 00:57:33 --> Total execution time: 0.4421
INFO - 2018-08-03 00:57:34 --> Config Class Initialized
INFO - 2018-08-03 00:57:34 --> Hooks Class Initialized
DEBUG - 2018-08-03 00:57:34 --> UTF-8 Support Enabled
INFO - 2018-08-03 00:57:34 --> Utf8 Class Initialized
INFO - 2018-08-03 00:57:34 --> URI Class Initialized
INFO - 2018-08-03 00:57:34 --> Router Class Initialized
INFO - 2018-08-03 00:57:34 --> Output Class Initialized
INFO - 2018-08-03 00:57:34 --> Security Class Initialized
DEBUG - 2018-08-03 00:57:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 00:57:34 --> Input Class Initialized
INFO - 2018-08-03 00:57:34 --> Language Class Initialized
ERROR - 2018-08-03 00:57:34 --> 404 Page Not Found: /index
INFO - 2018-08-03 00:59:23 --> Config Class Initialized
INFO - 2018-08-03 00:59:23 --> Hooks Class Initialized
DEBUG - 2018-08-03 00:59:23 --> UTF-8 Support Enabled
INFO - 2018-08-03 00:59:23 --> Utf8 Class Initialized
INFO - 2018-08-03 00:59:23 --> URI Class Initialized
INFO - 2018-08-03 00:59:23 --> Router Class Initialized
INFO - 2018-08-03 00:59:23 --> Output Class Initialized
INFO - 2018-08-03 00:59:23 --> Security Class Initialized
DEBUG - 2018-08-03 00:59:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 00:59:23 --> Input Class Initialized
INFO - 2018-08-03 00:59:23 --> Language Class Initialized
INFO - 2018-08-03 00:59:23 --> Language Class Initialized
INFO - 2018-08-03 00:59:23 --> Config Class Initialized
INFO - 2018-08-03 00:59:23 --> Loader Class Initialized
DEBUG - 2018-08-03 00:59:23 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-03 00:59:23 --> Helper loaded: url_helper
INFO - 2018-08-03 00:59:23 --> Helper loaded: form_helper
INFO - 2018-08-03 00:59:23 --> Helper loaded: date_helper
INFO - 2018-08-03 00:59:23 --> Helper loaded: util_helper
INFO - 2018-08-03 00:59:23 --> Helper loaded: text_helper
INFO - 2018-08-03 00:59:23 --> Helper loaded: string_helper
INFO - 2018-08-03 00:59:23 --> Database Driver Class Initialized
DEBUG - 2018-08-03 00:59:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 00:59:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-03 00:59:23 --> Email Class Initialized
INFO - 2018-08-03 00:59:23 --> Controller Class Initialized
DEBUG - 2018-08-03 00:59:23 --> Admin MX_Controller Initialized
INFO - 2018-08-03 00:59:23 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-03 00:59:23 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-03 00:59:23 --> Login MX_Controller Initialized
DEBUG - 2018-08-03 00:59:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-03 00:59:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-03 00:59:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-08-03 00:59:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-08-03 00:59:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-08-03 00:59:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-08-03 00:59:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-08-03 00:59:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/dashboard.php
INFO - 2018-08-03 00:59:23 --> Final output sent to browser
DEBUG - 2018-08-03 00:59:23 --> Total execution time: 0.3784
INFO - 2018-08-03 00:59:23 --> Config Class Initialized
INFO - 2018-08-03 00:59:23 --> Hooks Class Initialized
DEBUG - 2018-08-03 00:59:23 --> UTF-8 Support Enabled
INFO - 2018-08-03 00:59:23 --> Utf8 Class Initialized
INFO - 2018-08-03 00:59:23 --> URI Class Initialized
INFO - 2018-08-03 00:59:23 --> Router Class Initialized
INFO - 2018-08-03 00:59:23 --> Output Class Initialized
INFO - 2018-08-03 00:59:23 --> Security Class Initialized
DEBUG - 2018-08-03 00:59:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 00:59:23 --> Input Class Initialized
INFO - 2018-08-03 00:59:23 --> Language Class Initialized
ERROR - 2018-08-03 00:59:23 --> 404 Page Not Found: /index
INFO - 2018-08-03 00:59:23 --> Config Class Initialized
INFO - 2018-08-03 00:59:23 --> Hooks Class Initialized
DEBUG - 2018-08-03 00:59:23 --> UTF-8 Support Enabled
INFO - 2018-08-03 00:59:23 --> Utf8 Class Initialized
INFO - 2018-08-03 00:59:23 --> URI Class Initialized
INFO - 2018-08-03 00:59:23 --> Router Class Initialized
INFO - 2018-08-03 00:59:23 --> Output Class Initialized
INFO - 2018-08-03 00:59:23 --> Security Class Initialized
DEBUG - 2018-08-03 00:59:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 00:59:24 --> Input Class Initialized
INFO - 2018-08-03 00:59:24 --> Language Class Initialized
ERROR - 2018-08-03 00:59:24 --> 404 Page Not Found: /index
INFO - 2018-08-03 00:59:42 --> Config Class Initialized
INFO - 2018-08-03 00:59:42 --> Hooks Class Initialized
DEBUG - 2018-08-03 00:59:42 --> UTF-8 Support Enabled
INFO - 2018-08-03 00:59:42 --> Utf8 Class Initialized
INFO - 2018-08-03 00:59:42 --> URI Class Initialized
INFO - 2018-08-03 00:59:42 --> Router Class Initialized
INFO - 2018-08-03 00:59:42 --> Output Class Initialized
INFO - 2018-08-03 00:59:42 --> Security Class Initialized
DEBUG - 2018-08-03 00:59:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 00:59:42 --> Input Class Initialized
INFO - 2018-08-03 00:59:42 --> Language Class Initialized
INFO - 2018-08-03 00:59:42 --> Language Class Initialized
INFO - 2018-08-03 00:59:42 --> Config Class Initialized
INFO - 2018-08-03 00:59:42 --> Loader Class Initialized
DEBUG - 2018-08-03 00:59:42 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-03 00:59:42 --> Helper loaded: url_helper
INFO - 2018-08-03 00:59:42 --> Helper loaded: form_helper
INFO - 2018-08-03 00:59:42 --> Helper loaded: date_helper
INFO - 2018-08-03 00:59:42 --> Helper loaded: util_helper
INFO - 2018-08-03 00:59:42 --> Helper loaded: text_helper
INFO - 2018-08-03 00:59:42 --> Helper loaded: string_helper
INFO - 2018-08-03 00:59:42 --> Database Driver Class Initialized
DEBUG - 2018-08-03 00:59:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 00:59:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-03 00:59:42 --> Email Class Initialized
INFO - 2018-08-03 00:59:42 --> Controller Class Initialized
DEBUG - 2018-08-03 00:59:42 --> Admin MX_Controller Initialized
INFO - 2018-08-03 00:59:42 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-03 00:59:42 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-03 00:59:42 --> Login MX_Controller Initialized
DEBUG - 2018-08-03 00:59:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-03 00:59:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-03 00:59:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-08-03 00:59:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-08-03 00:59:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-08-03 00:59:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-08-03 00:59:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-08-03 00:59:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/dashboard.php
INFO - 2018-08-03 00:59:42 --> Final output sent to browser
DEBUG - 2018-08-03 00:59:42 --> Total execution time: 0.3873
INFO - 2018-08-03 00:59:42 --> Config Class Initialized
INFO - 2018-08-03 00:59:42 --> Hooks Class Initialized
DEBUG - 2018-08-03 00:59:42 --> UTF-8 Support Enabled
INFO - 2018-08-03 00:59:42 --> Utf8 Class Initialized
INFO - 2018-08-03 00:59:42 --> URI Class Initialized
INFO - 2018-08-03 00:59:42 --> Router Class Initialized
INFO - 2018-08-03 00:59:42 --> Output Class Initialized
INFO - 2018-08-03 00:59:42 --> Security Class Initialized
DEBUG - 2018-08-03 00:59:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 00:59:43 --> Input Class Initialized
INFO - 2018-08-03 00:59:43 --> Config Class Initialized
INFO - 2018-08-03 00:59:43 --> Hooks Class Initialized
INFO - 2018-08-03 00:59:43 --> Language Class Initialized
ERROR - 2018-08-03 00:59:43 --> 404 Page Not Found: /index
DEBUG - 2018-08-03 00:59:43 --> UTF-8 Support Enabled
INFO - 2018-08-03 00:59:43 --> Utf8 Class Initialized
INFO - 2018-08-03 00:59:43 --> URI Class Initialized
INFO - 2018-08-03 00:59:43 --> Router Class Initialized
INFO - 2018-08-03 00:59:43 --> Output Class Initialized
INFO - 2018-08-03 00:59:43 --> Security Class Initialized
DEBUG - 2018-08-03 00:59:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 00:59:43 --> Input Class Initialized
INFO - 2018-08-03 00:59:43 --> Language Class Initialized
ERROR - 2018-08-03 00:59:43 --> 404 Page Not Found: /index
INFO - 2018-08-03 00:59:57 --> Config Class Initialized
INFO - 2018-08-03 00:59:57 --> Hooks Class Initialized
DEBUG - 2018-08-03 00:59:57 --> UTF-8 Support Enabled
INFO - 2018-08-03 00:59:57 --> Utf8 Class Initialized
INFO - 2018-08-03 00:59:57 --> URI Class Initialized
INFO - 2018-08-03 00:59:57 --> Router Class Initialized
INFO - 2018-08-03 00:59:57 --> Output Class Initialized
INFO - 2018-08-03 00:59:57 --> Security Class Initialized
DEBUG - 2018-08-03 00:59:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 00:59:57 --> Input Class Initialized
INFO - 2018-08-03 00:59:57 --> Language Class Initialized
INFO - 2018-08-03 00:59:57 --> Language Class Initialized
INFO - 2018-08-03 00:59:57 --> Config Class Initialized
INFO - 2018-08-03 00:59:57 --> Loader Class Initialized
DEBUG - 2018-08-03 00:59:57 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-03 00:59:57 --> Helper loaded: url_helper
INFO - 2018-08-03 00:59:57 --> Helper loaded: form_helper
INFO - 2018-08-03 00:59:57 --> Helper loaded: date_helper
INFO - 2018-08-03 00:59:57 --> Helper loaded: util_helper
INFO - 2018-08-03 00:59:57 --> Helper loaded: text_helper
INFO - 2018-08-03 00:59:57 --> Helper loaded: string_helper
INFO - 2018-08-03 00:59:57 --> Database Driver Class Initialized
DEBUG - 2018-08-03 00:59:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 00:59:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-03 00:59:57 --> Email Class Initialized
INFO - 2018-08-03 00:59:57 --> Controller Class Initialized
DEBUG - 2018-08-03 00:59:57 --> Admin MX_Controller Initialized
INFO - 2018-08-03 00:59:57 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-03 00:59:57 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-03 00:59:57 --> Login MX_Controller Initialized
DEBUG - 2018-08-03 00:59:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-03 00:59:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-03 00:59:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-08-03 00:59:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-08-03 00:59:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-08-03 00:59:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-08-03 00:59:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-08-03 00:59:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/dashboard.php
INFO - 2018-08-03 00:59:57 --> Final output sent to browser
DEBUG - 2018-08-03 00:59:57 --> Total execution time: 0.3705
INFO - 2018-08-03 00:59:57 --> Config Class Initialized
INFO - 2018-08-03 00:59:57 --> Hooks Class Initialized
DEBUG - 2018-08-03 00:59:57 --> UTF-8 Support Enabled
INFO - 2018-08-03 00:59:57 --> Utf8 Class Initialized
INFO - 2018-08-03 00:59:57 --> URI Class Initialized
INFO - 2018-08-03 00:59:57 --> Router Class Initialized
INFO - 2018-08-03 00:59:57 --> Output Class Initialized
INFO - 2018-08-03 00:59:58 --> Security Class Initialized
DEBUG - 2018-08-03 00:59:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 00:59:58 --> Input Class Initialized
INFO - 2018-08-03 00:59:58 --> Language Class Initialized
ERROR - 2018-08-03 00:59:58 --> 404 Page Not Found: /index
INFO - 2018-08-03 00:59:58 --> Config Class Initialized
INFO - 2018-08-03 00:59:58 --> Hooks Class Initialized
DEBUG - 2018-08-03 00:59:58 --> UTF-8 Support Enabled
INFO - 2018-08-03 00:59:58 --> Utf8 Class Initialized
INFO - 2018-08-03 00:59:58 --> URI Class Initialized
INFO - 2018-08-03 00:59:58 --> Router Class Initialized
INFO - 2018-08-03 00:59:58 --> Output Class Initialized
INFO - 2018-08-03 00:59:58 --> Security Class Initialized
DEBUG - 2018-08-03 00:59:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 00:59:58 --> Input Class Initialized
INFO - 2018-08-03 00:59:58 --> Language Class Initialized
ERROR - 2018-08-03 00:59:58 --> 404 Page Not Found: /index
INFO - 2018-08-03 01:02:30 --> Config Class Initialized
INFO - 2018-08-03 01:02:30 --> Hooks Class Initialized
DEBUG - 2018-08-03 01:02:30 --> UTF-8 Support Enabled
INFO - 2018-08-03 01:02:30 --> Utf8 Class Initialized
INFO - 2018-08-03 01:02:30 --> URI Class Initialized
INFO - 2018-08-03 01:02:30 --> Router Class Initialized
INFO - 2018-08-03 01:02:30 --> Output Class Initialized
INFO - 2018-08-03 01:02:30 --> Security Class Initialized
DEBUG - 2018-08-03 01:02:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 01:02:30 --> Input Class Initialized
INFO - 2018-08-03 01:02:30 --> Language Class Initialized
INFO - 2018-08-03 01:02:30 --> Language Class Initialized
INFO - 2018-08-03 01:02:30 --> Config Class Initialized
INFO - 2018-08-03 01:02:30 --> Loader Class Initialized
DEBUG - 2018-08-03 01:02:30 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-03 01:02:30 --> Helper loaded: url_helper
INFO - 2018-08-03 01:02:30 --> Helper loaded: form_helper
INFO - 2018-08-03 01:02:30 --> Helper loaded: date_helper
INFO - 2018-08-03 01:02:30 --> Helper loaded: util_helper
INFO - 2018-08-03 01:02:30 --> Helper loaded: text_helper
INFO - 2018-08-03 01:02:30 --> Helper loaded: string_helper
INFO - 2018-08-03 01:02:30 --> Database Driver Class Initialized
DEBUG - 2018-08-03 01:02:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 01:02:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-03 01:02:30 --> Email Class Initialized
INFO - 2018-08-03 01:02:30 --> Controller Class Initialized
DEBUG - 2018-08-03 01:02:30 --> Home MX_Controller Initialized
DEBUG - 2018-08-03 01:02:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-03 01:02:30 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-03 01:02:30 --> Login MX_Controller Initialized
INFO - 2018-08-03 01:02:30 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-03 01:02:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-03 01:02:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-03 01:02:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-08-03 01:02:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-08-03 01:02:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-08-03 01:02:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-08-03 01:02:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-08-03 01:02:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/search_page.php
INFO - 2018-08-03 01:02:30 --> Final output sent to browser
DEBUG - 2018-08-03 01:02:30 --> Total execution time: 0.4554
INFO - 2018-08-03 01:02:32 --> Config Class Initialized
INFO - 2018-08-03 01:02:32 --> Config Class Initialized
INFO - 2018-08-03 01:02:32 --> Hooks Class Initialized
INFO - 2018-08-03 01:02:32 --> Hooks Class Initialized
DEBUG - 2018-08-03 01:02:32 --> UTF-8 Support Enabled
DEBUG - 2018-08-03 01:02:32 --> UTF-8 Support Enabled
INFO - 2018-08-03 01:02:32 --> Utf8 Class Initialized
INFO - 2018-08-03 01:02:32 --> Utf8 Class Initialized
INFO - 2018-08-03 01:02:32 --> URI Class Initialized
INFO - 2018-08-03 01:02:32 --> URI Class Initialized
INFO - 2018-08-03 01:02:32 --> Router Class Initialized
INFO - 2018-08-03 01:02:32 --> Output Class Initialized
INFO - 2018-08-03 01:02:32 --> Router Class Initialized
INFO - 2018-08-03 01:02:32 --> Security Class Initialized
INFO - 2018-08-03 01:02:32 --> Output Class Initialized
DEBUG - 2018-08-03 01:02:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 01:02:32 --> Security Class Initialized
INFO - 2018-08-03 01:02:32 --> Input Class Initialized
INFO - 2018-08-03 01:02:32 --> Language Class Initialized
INFO - 2018-08-03 01:02:32 --> Language Class Initialized
DEBUG - 2018-08-03 01:02:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 01:02:32 --> Config Class Initialized
INFO - 2018-08-03 01:02:32 --> Loader Class Initialized
DEBUG - 2018-08-03 01:02:32 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-03 01:02:32 --> Helper loaded: url_helper
INFO - 2018-08-03 01:02:32 --> Helper loaded: form_helper
INFO - 2018-08-03 01:02:32 --> Helper loaded: date_helper
INFO - 2018-08-03 01:02:32 --> Helper loaded: util_helper
INFO - 2018-08-03 01:02:32 --> Helper loaded: text_helper
INFO - 2018-08-03 01:02:32 --> Helper loaded: string_helper
INFO - 2018-08-03 01:02:32 --> Input Class Initialized
INFO - 2018-08-03 01:02:32 --> Database Driver Class Initialized
INFO - 2018-08-03 01:02:32 --> Language Class Initialized
DEBUG - 2018-08-03 01:02:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 01:02:32 --> Session: Class initialized using 'files' driver.
ERROR - 2018-08-03 01:02:32 --> 404 Page Not Found: /index
INFO - 2018-08-03 01:02:32 --> Email Class Initialized
INFO - 2018-08-03 01:02:32 --> Config Class Initialized
INFO - 2018-08-03 01:02:32 --> Hooks Class Initialized
INFO - 2018-08-03 01:02:32 --> Controller Class Initialized
DEBUG - 2018-08-03 01:02:32 --> Home MX_Controller Initialized
DEBUG - 2018-08-03 01:02:32 --> UTF-8 Support Enabled
INFO - 2018-08-03 01:02:32 --> Utf8 Class Initialized
DEBUG - 2018-08-03 01:02:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-08-03 01:02:32 --> URI Class Initialized
DEBUG - 2018-08-03 01:02:32 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-03 01:02:32 --> Login MX_Controller Initialized
INFO - 2018-08-03 01:02:32 --> Router Class Initialized
INFO - 2018-08-03 01:02:32 --> Language file loaded: language/english/data_lang.php
INFO - 2018-08-03 01:02:32 --> Output Class Initialized
DEBUG - 2018-08-03 01:02:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-08-03 01:02:32 --> Security Class Initialized
DEBUG - 2018-08-03 01:02:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-03 01:02:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 01:02:32 --> Input Class Initialized
INFO - 2018-08-03 01:02:32 --> Language Class Initialized
ERROR - 2018-08-03 01:02:32 --> 404 Page Not Found: /index
INFO - 2018-08-03 01:02:32 --> Config Class Initialized
INFO - 2018-08-03 01:02:32 --> Hooks Class Initialized
DEBUG - 2018-08-03 01:02:32 --> UTF-8 Support Enabled
INFO - 2018-08-03 01:02:32 --> Utf8 Class Initialized
INFO - 2018-08-03 01:02:32 --> URI Class Initialized
INFO - 2018-08-03 01:02:32 --> Router Class Initialized
INFO - 2018-08-03 01:02:32 --> Output Class Initialized
INFO - 2018-08-03 01:02:32 --> Security Class Initialized
DEBUG - 2018-08-03 01:02:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 01:02:32 --> Input Class Initialized
INFO - 2018-08-03 01:02:32 --> Language Class Initialized
ERROR - 2018-08-03 01:02:32 --> 404 Page Not Found: /index
INFO - 2018-08-03 01:02:32 --> Config Class Initialized
INFO - 2018-08-03 01:02:32 --> Hooks Class Initialized
DEBUG - 2018-08-03 01:02:32 --> UTF-8 Support Enabled
INFO - 2018-08-03 01:02:32 --> Utf8 Class Initialized
INFO - 2018-08-03 01:02:32 --> URI Class Initialized
INFO - 2018-08-03 01:02:32 --> Router Class Initialized
INFO - 2018-08-03 01:02:32 --> Output Class Initialized
INFO - 2018-08-03 01:02:32 --> Security Class Initialized
DEBUG - 2018-08-03 01:02:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 01:02:32 --> Input Class Initialized
INFO - 2018-08-03 01:02:32 --> Language Class Initialized
ERROR - 2018-08-03 01:02:32 --> 404 Page Not Found: /index
INFO - 2018-08-03 01:02:32 --> Config Class Initialized
INFO - 2018-08-03 01:02:32 --> Hooks Class Initialized
DEBUG - 2018-08-03 01:02:32 --> UTF-8 Support Enabled
INFO - 2018-08-03 01:02:32 --> Utf8 Class Initialized
INFO - 2018-08-03 01:02:32 --> URI Class Initialized
INFO - 2018-08-03 01:02:32 --> Router Class Initialized
INFO - 2018-08-03 01:02:32 --> Output Class Initialized
INFO - 2018-08-03 01:02:32 --> Security Class Initialized
DEBUG - 2018-08-03 01:02:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 01:02:33 --> Input Class Initialized
INFO - 2018-08-03 01:02:33 --> Language Class Initialized
ERROR - 2018-08-03 01:02:33 --> 404 Page Not Found: /index
INFO - 2018-08-03 01:02:33 --> Config Class Initialized
INFO - 2018-08-03 01:02:33 --> Hooks Class Initialized
DEBUG - 2018-08-03 01:02:33 --> UTF-8 Support Enabled
INFO - 2018-08-03 01:02:33 --> Utf8 Class Initialized
INFO - 2018-08-03 01:02:33 --> URI Class Initialized
INFO - 2018-08-03 01:02:33 --> Router Class Initialized
INFO - 2018-08-03 01:02:33 --> Output Class Initialized
INFO - 2018-08-03 01:02:33 --> Security Class Initialized
DEBUG - 2018-08-03 01:02:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 01:02:33 --> Input Class Initialized
INFO - 2018-08-03 01:02:33 --> Language Class Initialized
ERROR - 2018-08-03 01:02:33 --> 404 Page Not Found: /index
INFO - 2018-08-03 01:03:21 --> Config Class Initialized
INFO - 2018-08-03 01:03:21 --> Hooks Class Initialized
DEBUG - 2018-08-03 01:03:21 --> UTF-8 Support Enabled
INFO - 2018-08-03 01:03:21 --> Utf8 Class Initialized
INFO - 2018-08-03 01:03:21 --> URI Class Initialized
INFO - 2018-08-03 01:03:21 --> Router Class Initialized
INFO - 2018-08-03 01:03:21 --> Output Class Initialized
INFO - 2018-08-03 01:03:21 --> Security Class Initialized
DEBUG - 2018-08-03 01:03:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 01:03:21 --> Input Class Initialized
INFO - 2018-08-03 01:03:21 --> Language Class Initialized
INFO - 2018-08-03 01:03:21 --> Language Class Initialized
INFO - 2018-08-03 01:03:21 --> Config Class Initialized
INFO - 2018-08-03 01:03:21 --> Loader Class Initialized
DEBUG - 2018-08-03 01:03:21 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-03 01:03:21 --> Helper loaded: url_helper
INFO - 2018-08-03 01:03:21 --> Helper loaded: form_helper
INFO - 2018-08-03 01:03:21 --> Helper loaded: date_helper
INFO - 2018-08-03 01:03:21 --> Helper loaded: util_helper
INFO - 2018-08-03 01:03:21 --> Helper loaded: text_helper
INFO - 2018-08-03 01:03:21 --> Helper loaded: string_helper
INFO - 2018-08-03 01:03:21 --> Database Driver Class Initialized
DEBUG - 2018-08-03 01:03:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 01:03:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-03 01:03:21 --> Email Class Initialized
INFO - 2018-08-03 01:03:21 --> Controller Class Initialized
DEBUG - 2018-08-03 01:03:21 --> Admin MX_Controller Initialized
INFO - 2018-08-03 01:03:21 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-03 01:03:21 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-03 01:03:21 --> Login MX_Controller Initialized
DEBUG - 2018-08-03 01:03:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-03 01:03:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-03 01:03:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-08-03 01:03:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-08-03 01:03:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-08-03 01:03:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-08-03 01:03:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-08-03 01:03:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/dashboard.php
INFO - 2018-08-03 01:03:21 --> Final output sent to browser
DEBUG - 2018-08-03 01:03:21 --> Total execution time: 0.3865
INFO - 2018-08-03 01:03:21 --> Config Class Initialized
INFO - 2018-08-03 01:03:21 --> Config Class Initialized
INFO - 2018-08-03 01:03:21 --> Hooks Class Initialized
INFO - 2018-08-03 01:03:21 --> Hooks Class Initialized
DEBUG - 2018-08-03 01:03:21 --> UTF-8 Support Enabled
DEBUG - 2018-08-03 01:03:21 --> UTF-8 Support Enabled
INFO - 2018-08-03 01:03:21 --> Utf8 Class Initialized
INFO - 2018-08-03 01:03:21 --> Utf8 Class Initialized
INFO - 2018-08-03 01:03:21 --> URI Class Initialized
INFO - 2018-08-03 01:03:21 --> URI Class Initialized
INFO - 2018-08-03 01:03:21 --> Router Class Initialized
INFO - 2018-08-03 01:03:21 --> Router Class Initialized
INFO - 2018-08-03 01:03:21 --> Output Class Initialized
INFO - 2018-08-03 01:03:21 --> Output Class Initialized
INFO - 2018-08-03 01:03:21 --> Security Class Initialized
INFO - 2018-08-03 01:03:21 --> Security Class Initialized
DEBUG - 2018-08-03 01:03:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-08-03 01:03:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 01:03:21 --> Input Class Initialized
INFO - 2018-08-03 01:03:21 --> Input Class Initialized
INFO - 2018-08-03 01:03:21 --> Language Class Initialized
INFO - 2018-08-03 01:03:21 --> Language Class Initialized
ERROR - 2018-08-03 01:03:21 --> 404 Page Not Found: /index
ERROR - 2018-08-03 01:03:21 --> 404 Page Not Found: /index
INFO - 2018-08-03 01:03:22 --> Config Class Initialized
INFO - 2018-08-03 01:03:22 --> Hooks Class Initialized
INFO - 2018-08-03 01:03:22 --> Config Class Initialized
INFO - 2018-08-03 01:03:22 --> Hooks Class Initialized
DEBUG - 2018-08-03 01:03:22 --> UTF-8 Support Enabled
INFO - 2018-08-03 01:03:22 --> Utf8 Class Initialized
DEBUG - 2018-08-03 01:03:22 --> UTF-8 Support Enabled
INFO - 2018-08-03 01:03:22 --> Utf8 Class Initialized
INFO - 2018-08-03 01:03:22 --> URI Class Initialized
INFO - 2018-08-03 01:03:22 --> URI Class Initialized
INFO - 2018-08-03 01:03:22 --> Router Class Initialized
INFO - 2018-08-03 01:03:22 --> Output Class Initialized
INFO - 2018-08-03 01:03:22 --> Router Class Initialized
INFO - 2018-08-03 01:03:22 --> Output Class Initialized
INFO - 2018-08-03 01:03:22 --> Security Class Initialized
DEBUG - 2018-08-03 01:03:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 01:03:22 --> Security Class Initialized
INFO - 2018-08-03 01:03:22 --> Input Class Initialized
DEBUG - 2018-08-03 01:03:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 01:03:22 --> Language Class Initialized
INFO - 2018-08-03 01:03:22 --> Input Class Initialized
INFO - 2018-08-03 01:03:22 --> Language Class Initialized
INFO - 2018-08-03 01:03:22 --> Language Class Initialized
INFO - 2018-08-03 01:03:22 --> Config Class Initialized
ERROR - 2018-08-03 01:03:22 --> 404 Page Not Found: /index
INFO - 2018-08-03 01:03:22 --> Loader Class Initialized
DEBUG - 2018-08-03 01:03:22 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-03 01:03:22 --> Helper loaded: url_helper
INFO - 2018-08-03 01:03:22 --> Helper loaded: form_helper
INFO - 2018-08-03 01:03:22 --> Helper loaded: date_helper
INFO - 2018-08-03 01:03:22 --> Helper loaded: util_helper
INFO - 2018-08-03 01:03:22 --> Helper loaded: text_helper
INFO - 2018-08-03 01:03:22 --> Helper loaded: string_helper
INFO - 2018-08-03 01:03:22 --> Database Driver Class Initialized
DEBUG - 2018-08-03 01:03:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 01:03:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-03 01:03:22 --> Email Class Initialized
INFO - 2018-08-03 01:03:22 --> Controller Class Initialized
DEBUG - 2018-08-03 01:03:22 --> Home MX_Controller Initialized
DEBUG - 2018-08-03 01:03:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-03 01:03:22 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-03 01:03:22 --> Login MX_Controller Initialized
INFO - 2018-08-03 01:03:22 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-03 01:03:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-03 01:03:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-03 01:03:24 --> Config Class Initialized
INFO - 2018-08-03 01:03:24 --> Hooks Class Initialized
DEBUG - 2018-08-03 01:03:24 --> UTF-8 Support Enabled
INFO - 2018-08-03 01:03:24 --> Utf8 Class Initialized
INFO - 2018-08-03 01:03:24 --> URI Class Initialized
INFO - 2018-08-03 01:03:24 --> Router Class Initialized
INFO - 2018-08-03 01:03:24 --> Output Class Initialized
INFO - 2018-08-03 01:03:24 --> Security Class Initialized
DEBUG - 2018-08-03 01:03:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 01:03:24 --> Input Class Initialized
INFO - 2018-08-03 01:03:24 --> Language Class Initialized
INFO - 2018-08-03 01:03:24 --> Language Class Initialized
INFO - 2018-08-03 01:03:24 --> Config Class Initialized
INFO - 2018-08-03 01:03:24 --> Loader Class Initialized
DEBUG - 2018-08-03 01:03:24 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-03 01:03:24 --> Helper loaded: url_helper
INFO - 2018-08-03 01:03:24 --> Helper loaded: form_helper
INFO - 2018-08-03 01:03:24 --> Helper loaded: date_helper
INFO - 2018-08-03 01:03:24 --> Helper loaded: util_helper
INFO - 2018-08-03 01:03:24 --> Helper loaded: text_helper
INFO - 2018-08-03 01:03:24 --> Helper loaded: string_helper
INFO - 2018-08-03 01:03:24 --> Database Driver Class Initialized
DEBUG - 2018-08-03 01:03:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 01:03:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-03 01:03:24 --> Email Class Initialized
INFO - 2018-08-03 01:03:24 --> Controller Class Initialized
DEBUG - 2018-08-03 01:03:24 --> Home MX_Controller Initialized
DEBUG - 2018-08-03 01:03:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-03 01:03:24 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-03 01:03:24 --> Login MX_Controller Initialized
INFO - 2018-08-03 01:03:24 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-03 01:03:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-03 01:03:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-03 01:03:26 --> Config Class Initialized
INFO - 2018-08-03 01:03:26 --> Hooks Class Initialized
DEBUG - 2018-08-03 01:03:26 --> UTF-8 Support Enabled
INFO - 2018-08-03 01:03:26 --> Utf8 Class Initialized
INFO - 2018-08-03 01:03:26 --> URI Class Initialized
INFO - 2018-08-03 01:03:26 --> Router Class Initialized
INFO - 2018-08-03 01:03:26 --> Output Class Initialized
INFO - 2018-08-03 01:03:26 --> Security Class Initialized
DEBUG - 2018-08-03 01:03:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 01:03:26 --> Input Class Initialized
INFO - 2018-08-03 01:03:26 --> Language Class Initialized
INFO - 2018-08-03 01:03:26 --> Language Class Initialized
INFO - 2018-08-03 01:03:26 --> Config Class Initialized
INFO - 2018-08-03 01:03:26 --> Loader Class Initialized
DEBUG - 2018-08-03 01:03:26 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-03 01:03:26 --> Helper loaded: url_helper
INFO - 2018-08-03 01:03:26 --> Helper loaded: form_helper
INFO - 2018-08-03 01:03:26 --> Helper loaded: date_helper
INFO - 2018-08-03 01:03:26 --> Helper loaded: util_helper
INFO - 2018-08-03 01:03:26 --> Helper loaded: text_helper
INFO - 2018-08-03 01:03:26 --> Helper loaded: string_helper
INFO - 2018-08-03 01:03:26 --> Database Driver Class Initialized
DEBUG - 2018-08-03 01:03:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 01:03:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-03 01:03:26 --> Email Class Initialized
INFO - 2018-08-03 01:03:27 --> Controller Class Initialized
DEBUG - 2018-08-03 01:03:27 --> Home MX_Controller Initialized
DEBUG - 2018-08-03 01:03:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-03 01:03:27 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-03 01:03:27 --> Login MX_Controller Initialized
INFO - 2018-08-03 01:03:27 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-03 01:03:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-03 01:03:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-03 01:03:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-08-03 01:03:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-08-03 01:03:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-08-03 01:03:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-08-03 01:03:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-08-03 01:03:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/search_page.php
INFO - 2018-08-03 01:03:27 --> Final output sent to browser
DEBUG - 2018-08-03 01:03:27 --> Total execution time: 0.4085
INFO - 2018-08-03 01:03:27 --> Config Class Initialized
INFO - 2018-08-03 01:03:27 --> Hooks Class Initialized
DEBUG - 2018-08-03 01:03:27 --> UTF-8 Support Enabled
INFO - 2018-08-03 01:03:27 --> Utf8 Class Initialized
INFO - 2018-08-03 01:03:27 --> Config Class Initialized
INFO - 2018-08-03 01:03:27 --> Hooks Class Initialized
INFO - 2018-08-03 01:03:27 --> URI Class Initialized
DEBUG - 2018-08-03 01:03:27 --> UTF-8 Support Enabled
INFO - 2018-08-03 01:03:27 --> Router Class Initialized
INFO - 2018-08-03 01:03:27 --> Utf8 Class Initialized
INFO - 2018-08-03 01:03:27 --> URI Class Initialized
INFO - 2018-08-03 01:03:27 --> Output Class Initialized
INFO - 2018-08-03 01:03:27 --> Security Class Initialized
INFO - 2018-08-03 01:03:27 --> Router Class Initialized
INFO - 2018-08-03 01:03:27 --> Output Class Initialized
INFO - 2018-08-03 01:03:27 --> Security Class Initialized
DEBUG - 2018-08-03 01:03:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-08-03 01:03:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 01:03:28 --> Input Class Initialized
INFO - 2018-08-03 01:03:28 --> Input Class Initialized
INFO - 2018-08-03 01:03:28 --> Language Class Initialized
INFO - 2018-08-03 01:03:28 --> Language Class Initialized
INFO - 2018-08-03 01:03:28 --> Language Class Initialized
ERROR - 2018-08-03 01:03:28 --> 404 Page Not Found: /index
INFO - 2018-08-03 01:03:28 --> Config Class Initialized
INFO - 2018-08-03 01:03:28 --> Config Class Initialized
INFO - 2018-08-03 01:03:28 --> Hooks Class Initialized
INFO - 2018-08-03 01:03:28 --> Loader Class Initialized
DEBUG - 2018-08-03 01:03:28 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
DEBUG - 2018-08-03 01:03:28 --> UTF-8 Support Enabled
INFO - 2018-08-03 01:03:28 --> Utf8 Class Initialized
INFO - 2018-08-03 01:03:28 --> Helper loaded: url_helper
INFO - 2018-08-03 01:03:28 --> URI Class Initialized
INFO - 2018-08-03 01:03:28 --> Helper loaded: form_helper
INFO - 2018-08-03 01:03:28 --> Helper loaded: date_helper
INFO - 2018-08-03 01:03:28 --> Router Class Initialized
INFO - 2018-08-03 01:03:28 --> Output Class Initialized
INFO - 2018-08-03 01:03:28 --> Helper loaded: util_helper
INFO - 2018-08-03 01:03:28 --> Helper loaded: text_helper
INFO - 2018-08-03 01:03:28 --> Security Class Initialized
DEBUG - 2018-08-03 01:03:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 01:03:28 --> Helper loaded: string_helper
INFO - 2018-08-03 01:03:28 --> Input Class Initialized
INFO - 2018-08-03 01:03:28 --> Database Driver Class Initialized
INFO - 2018-08-03 01:03:28 --> Language Class Initialized
DEBUG - 2018-08-03 01:03:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2018-08-03 01:03:28 --> 404 Page Not Found: /index
INFO - 2018-08-03 01:03:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-03 01:03:28 --> Config Class Initialized
INFO - 2018-08-03 01:03:28 --> Hooks Class Initialized
INFO - 2018-08-03 01:03:28 --> Email Class Initialized
INFO - 2018-08-03 01:03:28 --> Controller Class Initialized
DEBUG - 2018-08-03 01:03:28 --> UTF-8 Support Enabled
DEBUG - 2018-08-03 01:03:28 --> Home MX_Controller Initialized
INFO - 2018-08-03 01:03:28 --> Utf8 Class Initialized
DEBUG - 2018-08-03 01:03:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-08-03 01:03:28 --> URI Class Initialized
INFO - 2018-08-03 01:03:28 --> Router Class Initialized
DEBUG - 2018-08-03 01:03:28 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-03 01:03:28 --> Login MX_Controller Initialized
INFO - 2018-08-03 01:03:28 --> Output Class Initialized
INFO - 2018-08-03 01:03:28 --> Language file loaded: language/english/data_lang.php
INFO - 2018-08-03 01:03:28 --> Security Class Initialized
DEBUG - 2018-08-03 01:03:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-03 01:03:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 01:03:28 --> Input Class Initialized
DEBUG - 2018-08-03 01:03:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-03 01:03:28 --> Language Class Initialized
ERROR - 2018-08-03 01:03:28 --> 404 Page Not Found: /index
INFO - 2018-08-03 01:03:28 --> Config Class Initialized
INFO - 2018-08-03 01:03:28 --> Hooks Class Initialized
DEBUG - 2018-08-03 01:03:28 --> UTF-8 Support Enabled
INFO - 2018-08-03 01:03:28 --> Utf8 Class Initialized
INFO - 2018-08-03 01:03:28 --> URI Class Initialized
INFO - 2018-08-03 01:03:28 --> Router Class Initialized
INFO - 2018-08-03 01:03:28 --> Output Class Initialized
INFO - 2018-08-03 01:03:28 --> Security Class Initialized
DEBUG - 2018-08-03 01:03:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 01:03:28 --> Input Class Initialized
INFO - 2018-08-03 01:03:28 --> Language Class Initialized
ERROR - 2018-08-03 01:03:28 --> 404 Page Not Found: /index
INFO - 2018-08-03 01:03:28 --> Config Class Initialized
INFO - 2018-08-03 01:03:28 --> Hooks Class Initialized
DEBUG - 2018-08-03 01:03:28 --> UTF-8 Support Enabled
INFO - 2018-08-03 01:03:28 --> Utf8 Class Initialized
INFO - 2018-08-03 01:03:28 --> URI Class Initialized
INFO - 2018-08-03 01:03:28 --> Router Class Initialized
INFO - 2018-08-03 01:03:28 --> Output Class Initialized
INFO - 2018-08-03 01:03:28 --> Security Class Initialized
DEBUG - 2018-08-03 01:03:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 01:03:28 --> Input Class Initialized
INFO - 2018-08-03 01:03:28 --> Language Class Initialized
ERROR - 2018-08-03 01:03:28 --> 404 Page Not Found: /index
INFO - 2018-08-03 01:03:28 --> Config Class Initialized
INFO - 2018-08-03 01:03:28 --> Hooks Class Initialized
DEBUG - 2018-08-03 01:03:28 --> UTF-8 Support Enabled
INFO - 2018-08-03 01:03:28 --> Utf8 Class Initialized
INFO - 2018-08-03 01:03:28 --> URI Class Initialized
INFO - 2018-08-03 01:03:28 --> Router Class Initialized
INFO - 2018-08-03 01:03:28 --> Output Class Initialized
INFO - 2018-08-03 01:03:28 --> Security Class Initialized
DEBUG - 2018-08-03 01:03:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 01:03:28 --> Input Class Initialized
INFO - 2018-08-03 01:03:28 --> Language Class Initialized
ERROR - 2018-08-03 01:03:28 --> 404 Page Not Found: /index
INFO - 2018-08-03 01:03:32 --> Config Class Initialized
INFO - 2018-08-03 01:03:32 --> Hooks Class Initialized
DEBUG - 2018-08-03 01:03:32 --> UTF-8 Support Enabled
INFO - 2018-08-03 01:03:32 --> Utf8 Class Initialized
INFO - 2018-08-03 01:03:32 --> URI Class Initialized
INFO - 2018-08-03 01:03:32 --> Router Class Initialized
INFO - 2018-08-03 01:03:32 --> Output Class Initialized
INFO - 2018-08-03 01:03:32 --> Security Class Initialized
DEBUG - 2018-08-03 01:03:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 01:03:32 --> Input Class Initialized
INFO - 2018-08-03 01:03:32 --> Language Class Initialized
INFO - 2018-08-03 01:03:32 --> Language Class Initialized
INFO - 2018-08-03 01:03:32 --> Config Class Initialized
INFO - 2018-08-03 01:03:32 --> Loader Class Initialized
DEBUG - 2018-08-03 01:03:32 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-03 01:03:32 --> Helper loaded: url_helper
INFO - 2018-08-03 01:03:32 --> Helper loaded: form_helper
INFO - 2018-08-03 01:03:32 --> Helper loaded: date_helper
INFO - 2018-08-03 01:03:32 --> Helper loaded: util_helper
INFO - 2018-08-03 01:03:32 --> Helper loaded: text_helper
INFO - 2018-08-03 01:03:32 --> Helper loaded: string_helper
INFO - 2018-08-03 01:03:32 --> Database Driver Class Initialized
DEBUG - 2018-08-03 01:03:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 01:03:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-03 01:03:32 --> Email Class Initialized
INFO - 2018-08-03 01:03:32 --> Controller Class Initialized
DEBUG - 2018-08-03 01:03:32 --> Home MX_Controller Initialized
DEBUG - 2018-08-03 01:03:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-03 01:03:32 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-03 01:03:32 --> Login MX_Controller Initialized
INFO - 2018-08-03 01:03:32 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-03 01:03:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-03 01:03:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-03 01:03:35 --> Config Class Initialized
INFO - 2018-08-03 01:03:35 --> Hooks Class Initialized
DEBUG - 2018-08-03 01:03:35 --> UTF-8 Support Enabled
INFO - 2018-08-03 01:03:35 --> Utf8 Class Initialized
INFO - 2018-08-03 01:03:35 --> URI Class Initialized
INFO - 2018-08-03 01:03:35 --> Router Class Initialized
INFO - 2018-08-03 01:03:35 --> Output Class Initialized
INFO - 2018-08-03 01:03:35 --> Security Class Initialized
DEBUG - 2018-08-03 01:03:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 01:03:35 --> Input Class Initialized
INFO - 2018-08-03 01:03:35 --> Language Class Initialized
INFO - 2018-08-03 01:03:35 --> Language Class Initialized
INFO - 2018-08-03 01:03:35 --> Config Class Initialized
INFO - 2018-08-03 01:03:35 --> Loader Class Initialized
DEBUG - 2018-08-03 01:03:35 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-03 01:03:35 --> Helper loaded: url_helper
INFO - 2018-08-03 01:03:35 --> Helper loaded: form_helper
INFO - 2018-08-03 01:03:35 --> Helper loaded: date_helper
INFO - 2018-08-03 01:03:35 --> Helper loaded: util_helper
INFO - 2018-08-03 01:03:35 --> Helper loaded: text_helper
INFO - 2018-08-03 01:03:35 --> Helper loaded: string_helper
INFO - 2018-08-03 01:03:35 --> Database Driver Class Initialized
DEBUG - 2018-08-03 01:03:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 01:03:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-03 01:03:35 --> Email Class Initialized
INFO - 2018-08-03 01:03:35 --> Controller Class Initialized
DEBUG - 2018-08-03 01:03:35 --> Home MX_Controller Initialized
DEBUG - 2018-08-03 01:03:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-03 01:03:35 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-03 01:03:35 --> Login MX_Controller Initialized
INFO - 2018-08-03 01:03:35 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-03 01:03:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-03 01:03:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-03 01:03:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-08-03 01:03:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-08-03 01:03:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-08-03 01:03:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-08-03 01:03:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-08-03 01:03:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/search_page.php
INFO - 2018-08-03 01:03:35 --> Final output sent to browser
DEBUG - 2018-08-03 01:03:35 --> Total execution time: 0.4203
INFO - 2018-08-03 01:03:36 --> Config Class Initialized
INFO - 2018-08-03 01:03:36 --> Hooks Class Initialized
DEBUG - 2018-08-03 01:03:36 --> UTF-8 Support Enabled
INFO - 2018-08-03 01:03:36 --> Utf8 Class Initialized
INFO - 2018-08-03 01:03:36 --> Config Class Initialized
INFO - 2018-08-03 01:03:36 --> Hooks Class Initialized
INFO - 2018-08-03 01:03:36 --> URI Class Initialized
DEBUG - 2018-08-03 01:03:36 --> UTF-8 Support Enabled
INFO - 2018-08-03 01:03:36 --> Utf8 Class Initialized
INFO - 2018-08-03 01:03:36 --> URI Class Initialized
INFO - 2018-08-03 01:03:36 --> Router Class Initialized
INFO - 2018-08-03 01:03:36 --> Output Class Initialized
INFO - 2018-08-03 01:03:36 --> Security Class Initialized
DEBUG - 2018-08-03 01:03:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 01:03:36 --> Router Class Initialized
INFO - 2018-08-03 01:03:36 --> Input Class Initialized
INFO - 2018-08-03 01:03:36 --> Output Class Initialized
INFO - 2018-08-03 01:03:36 --> Language Class Initialized
INFO - 2018-08-03 01:03:36 --> Security Class Initialized
DEBUG - 2018-08-03 01:03:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 01:03:36 --> Language Class Initialized
INFO - 2018-08-03 01:03:36 --> Input Class Initialized
INFO - 2018-08-03 01:03:36 --> Config Class Initialized
INFO - 2018-08-03 01:03:36 --> Language Class Initialized
INFO - 2018-08-03 01:03:36 --> Loader Class Initialized
ERROR - 2018-08-03 01:03:36 --> 404 Page Not Found: /index
DEBUG - 2018-08-03 01:03:36 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-03 01:03:36 --> Helper loaded: url_helper
INFO - 2018-08-03 01:03:36 --> Config Class Initialized
INFO - 2018-08-03 01:03:36 --> Helper loaded: form_helper
INFO - 2018-08-03 01:03:36 --> Hooks Class Initialized
INFO - 2018-08-03 01:03:36 --> Helper loaded: date_helper
INFO - 2018-08-03 01:03:36 --> Helper loaded: util_helper
DEBUG - 2018-08-03 01:03:36 --> UTF-8 Support Enabled
INFO - 2018-08-03 01:03:36 --> Utf8 Class Initialized
INFO - 2018-08-03 01:03:36 --> Helper loaded: text_helper
INFO - 2018-08-03 01:03:36 --> URI Class Initialized
INFO - 2018-08-03 01:03:36 --> Helper loaded: string_helper
INFO - 2018-08-03 01:03:36 --> Router Class Initialized
INFO - 2018-08-03 01:03:36 --> Database Driver Class Initialized
INFO - 2018-08-03 01:03:36 --> Output Class Initialized
DEBUG - 2018-08-03 01:03:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 01:03:36 --> Security Class Initialized
INFO - 2018-08-03 01:03:36 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-08-03 01:03:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 01:03:36 --> Input Class Initialized
INFO - 2018-08-03 01:03:36 --> Email Class Initialized
INFO - 2018-08-03 01:03:36 --> Controller Class Initialized
INFO - 2018-08-03 01:03:36 --> Language Class Initialized
DEBUG - 2018-08-03 01:03:36 --> Home MX_Controller Initialized
ERROR - 2018-08-03 01:03:36 --> 404 Page Not Found: /index
DEBUG - 2018-08-03 01:03:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-08-03 01:03:36 --> Config Class Initialized
INFO - 2018-08-03 01:03:36 --> Hooks Class Initialized
DEBUG - 2018-08-03 01:03:36 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-03 01:03:36 --> Login MX_Controller Initialized
DEBUG - 2018-08-03 01:03:36 --> UTF-8 Support Enabled
INFO - 2018-08-03 01:03:36 --> Utf8 Class Initialized
INFO - 2018-08-03 01:03:36 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-03 01:03:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-08-03 01:03:36 --> URI Class Initialized
DEBUG - 2018-08-03 01:03:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-03 01:03:36 --> Router Class Initialized
INFO - 2018-08-03 01:03:36 --> Output Class Initialized
INFO - 2018-08-03 01:03:36 --> Security Class Initialized
DEBUG - 2018-08-03 01:03:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 01:03:36 --> Input Class Initialized
INFO - 2018-08-03 01:03:36 --> Language Class Initialized
ERROR - 2018-08-03 01:03:36 --> 404 Page Not Found: /index
INFO - 2018-08-03 01:03:45 --> Config Class Initialized
INFO - 2018-08-03 01:03:45 --> Hooks Class Initialized
DEBUG - 2018-08-03 01:03:45 --> UTF-8 Support Enabled
INFO - 2018-08-03 01:03:45 --> Utf8 Class Initialized
INFO - 2018-08-03 01:03:45 --> URI Class Initialized
INFO - 2018-08-03 01:03:45 --> Router Class Initialized
INFO - 2018-08-03 01:03:45 --> Output Class Initialized
INFO - 2018-08-03 01:03:45 --> Security Class Initialized
DEBUG - 2018-08-03 01:03:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 01:03:45 --> Input Class Initialized
INFO - 2018-08-03 01:03:45 --> Language Class Initialized
INFO - 2018-08-03 01:03:45 --> Language Class Initialized
INFO - 2018-08-03 01:03:45 --> Config Class Initialized
INFO - 2018-08-03 01:03:45 --> Loader Class Initialized
DEBUG - 2018-08-03 01:03:45 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-03 01:03:45 --> Helper loaded: url_helper
INFO - 2018-08-03 01:03:45 --> Helper loaded: form_helper
INFO - 2018-08-03 01:03:45 --> Helper loaded: date_helper
INFO - 2018-08-03 01:03:45 --> Helper loaded: util_helper
INFO - 2018-08-03 01:03:45 --> Helper loaded: text_helper
INFO - 2018-08-03 01:03:45 --> Helper loaded: string_helper
INFO - 2018-08-03 01:03:45 --> Database Driver Class Initialized
DEBUG - 2018-08-03 01:03:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 01:03:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-03 01:03:45 --> Email Class Initialized
INFO - 2018-08-03 01:03:45 --> Controller Class Initialized
DEBUG - 2018-08-03 01:03:45 --> Home MX_Controller Initialized
DEBUG - 2018-08-03 01:03:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-03 01:03:45 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-03 01:03:45 --> Login MX_Controller Initialized
INFO - 2018-08-03 01:03:45 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-03 01:03:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-03 01:03:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-03 01:03:59 --> Config Class Initialized
INFO - 2018-08-03 01:03:59 --> Hooks Class Initialized
DEBUG - 2018-08-03 01:03:59 --> UTF-8 Support Enabled
INFO - 2018-08-03 01:03:59 --> Utf8 Class Initialized
INFO - 2018-08-03 01:03:59 --> URI Class Initialized
INFO - 2018-08-03 01:03:59 --> Router Class Initialized
INFO - 2018-08-03 01:03:59 --> Output Class Initialized
INFO - 2018-08-03 01:03:59 --> Security Class Initialized
DEBUG - 2018-08-03 01:03:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 01:03:59 --> Input Class Initialized
INFO - 2018-08-03 01:03:59 --> Language Class Initialized
INFO - 2018-08-03 01:03:59 --> Language Class Initialized
INFO - 2018-08-03 01:03:59 --> Config Class Initialized
INFO - 2018-08-03 01:04:00 --> Loader Class Initialized
DEBUG - 2018-08-03 01:04:00 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-03 01:04:00 --> Helper loaded: url_helper
INFO - 2018-08-03 01:04:00 --> Helper loaded: form_helper
INFO - 2018-08-03 01:04:00 --> Helper loaded: date_helper
INFO - 2018-08-03 01:04:00 --> Helper loaded: util_helper
INFO - 2018-08-03 01:04:00 --> Helper loaded: text_helper
INFO - 2018-08-03 01:04:00 --> Helper loaded: string_helper
INFO - 2018-08-03 01:04:00 --> Database Driver Class Initialized
DEBUG - 2018-08-03 01:04:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 01:04:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-03 01:04:00 --> Email Class Initialized
INFO - 2018-08-03 01:04:00 --> Controller Class Initialized
DEBUG - 2018-08-03 01:04:00 --> Home MX_Controller Initialized
DEBUG - 2018-08-03 01:04:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-03 01:04:00 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-03 01:04:00 --> Login MX_Controller Initialized
INFO - 2018-08-03 01:04:00 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-03 01:04:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-03 01:04:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-03 01:04:01 --> Config Class Initialized
INFO - 2018-08-03 01:04:01 --> Hooks Class Initialized
DEBUG - 2018-08-03 01:04:01 --> UTF-8 Support Enabled
INFO - 2018-08-03 01:04:01 --> Utf8 Class Initialized
INFO - 2018-08-03 01:04:01 --> URI Class Initialized
INFO - 2018-08-03 01:04:01 --> Router Class Initialized
INFO - 2018-08-03 01:04:01 --> Output Class Initialized
INFO - 2018-08-03 01:04:01 --> Security Class Initialized
DEBUG - 2018-08-03 01:04:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 01:04:01 --> Input Class Initialized
INFO - 2018-08-03 01:04:01 --> Language Class Initialized
INFO - 2018-08-03 01:04:01 --> Language Class Initialized
INFO - 2018-08-03 01:04:01 --> Config Class Initialized
INFO - 2018-08-03 01:04:01 --> Loader Class Initialized
DEBUG - 2018-08-03 01:04:01 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-03 01:04:01 --> Helper loaded: url_helper
INFO - 2018-08-03 01:04:01 --> Helper loaded: form_helper
INFO - 2018-08-03 01:04:01 --> Helper loaded: date_helper
INFO - 2018-08-03 01:04:01 --> Helper loaded: util_helper
INFO - 2018-08-03 01:04:01 --> Helper loaded: text_helper
INFO - 2018-08-03 01:04:01 --> Helper loaded: string_helper
INFO - 2018-08-03 01:04:01 --> Database Driver Class Initialized
DEBUG - 2018-08-03 01:04:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 01:04:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-03 01:04:01 --> Email Class Initialized
INFO - 2018-08-03 01:04:01 --> Controller Class Initialized
DEBUG - 2018-08-03 01:04:01 --> Home MX_Controller Initialized
DEBUG - 2018-08-03 01:04:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-03 01:04:01 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-03 01:04:01 --> Login MX_Controller Initialized
INFO - 2018-08-03 01:04:01 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-03 01:04:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-03 01:04:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-03 01:04:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-08-03 01:04:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-08-03 01:04:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-08-03 01:04:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-08-03 01:04:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-08-03 01:04:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/search_page.php
INFO - 2018-08-03 01:04:01 --> Final output sent to browser
DEBUG - 2018-08-03 01:04:01 --> Total execution time: 0.4365
INFO - 2018-08-03 01:04:02 --> Config Class Initialized
INFO - 2018-08-03 01:04:02 --> Hooks Class Initialized
INFO - 2018-08-03 01:04:02 --> Config Class Initialized
INFO - 2018-08-03 01:04:02 --> Hooks Class Initialized
DEBUG - 2018-08-03 01:04:02 --> UTF-8 Support Enabled
INFO - 2018-08-03 01:04:02 --> Utf8 Class Initialized
DEBUG - 2018-08-03 01:04:02 --> UTF-8 Support Enabled
INFO - 2018-08-03 01:04:02 --> Utf8 Class Initialized
INFO - 2018-08-03 01:04:02 --> URI Class Initialized
INFO - 2018-08-03 01:04:02 --> URI Class Initialized
INFO - 2018-08-03 01:04:02 --> Router Class Initialized
INFO - 2018-08-03 01:04:02 --> Output Class Initialized
INFO - 2018-08-03 01:04:02 --> Security Class Initialized
INFO - 2018-08-03 01:04:02 --> Router Class Initialized
DEBUG - 2018-08-03 01:04:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 01:04:02 --> Output Class Initialized
INFO - 2018-08-03 01:04:02 --> Security Class Initialized
INFO - 2018-08-03 01:04:02 --> Input Class Initialized
INFO - 2018-08-03 01:04:02 --> Language Class Initialized
DEBUG - 2018-08-03 01:04:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 01:04:02 --> Input Class Initialized
INFO - 2018-08-03 01:04:02 --> Language Class Initialized
INFO - 2018-08-03 01:04:02 --> Language Class Initialized
INFO - 2018-08-03 01:04:02 --> Config Class Initialized
ERROR - 2018-08-03 01:04:02 --> 404 Page Not Found: /index
INFO - 2018-08-03 01:04:02 --> Loader Class Initialized
DEBUG - 2018-08-03 01:04:02 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-03 01:04:02 --> Helper loaded: url_helper
INFO - 2018-08-03 01:04:02 --> Config Class Initialized
INFO - 2018-08-03 01:04:02 --> Hooks Class Initialized
INFO - 2018-08-03 01:04:02 --> Helper loaded: form_helper
INFO - 2018-08-03 01:04:02 --> Helper loaded: date_helper
DEBUG - 2018-08-03 01:04:02 --> UTF-8 Support Enabled
INFO - 2018-08-03 01:04:02 --> Utf8 Class Initialized
INFO - 2018-08-03 01:04:02 --> Helper loaded: util_helper
INFO - 2018-08-03 01:04:02 --> URI Class Initialized
INFO - 2018-08-03 01:04:02 --> Helper loaded: text_helper
INFO - 2018-08-03 01:04:02 --> Helper loaded: string_helper
INFO - 2018-08-03 01:04:02 --> Router Class Initialized
INFO - 2018-08-03 01:04:02 --> Output Class Initialized
INFO - 2018-08-03 01:04:02 --> Database Driver Class Initialized
INFO - 2018-08-03 01:04:02 --> Security Class Initialized
DEBUG - 2018-08-03 01:04:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 01:04:02 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-08-03 01:04:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 01:04:02 --> Input Class Initialized
INFO - 2018-08-03 01:04:02 --> Email Class Initialized
INFO - 2018-08-03 01:04:02 --> Language Class Initialized
ERROR - 2018-08-03 01:04:02 --> 404 Page Not Found: /index
INFO - 2018-08-03 01:04:02 --> Controller Class Initialized
DEBUG - 2018-08-03 01:04:02 --> Home MX_Controller Initialized
INFO - 2018-08-03 01:04:02 --> Config Class Initialized
INFO - 2018-08-03 01:04:02 --> Hooks Class Initialized
DEBUG - 2018-08-03 01:04:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-03 01:04:02 --> UTF-8 Support Enabled
DEBUG - 2018-08-03 01:04:02 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-03 01:04:03 --> Login MX_Controller Initialized
INFO - 2018-08-03 01:04:03 --> Utf8 Class Initialized
INFO - 2018-08-03 01:04:03 --> Language file loaded: language/english/data_lang.php
INFO - 2018-08-03 01:04:03 --> URI Class Initialized
DEBUG - 2018-08-03 01:04:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-08-03 01:04:03 --> Router Class Initialized
DEBUG - 2018-08-03 01:04:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-03 01:04:03 --> Output Class Initialized
INFO - 2018-08-03 01:04:03 --> Security Class Initialized
DEBUG - 2018-08-03 01:04:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 01:04:03 --> Input Class Initialized
INFO - 2018-08-03 01:04:03 --> Language Class Initialized
ERROR - 2018-08-03 01:04:03 --> 404 Page Not Found: /index
INFO - 2018-08-03 01:18:30 --> Config Class Initialized
INFO - 2018-08-03 01:18:30 --> Hooks Class Initialized
DEBUG - 2018-08-03 01:18:30 --> UTF-8 Support Enabled
INFO - 2018-08-03 01:18:30 --> Utf8 Class Initialized
INFO - 2018-08-03 01:18:30 --> URI Class Initialized
INFO - 2018-08-03 01:18:30 --> Router Class Initialized
INFO - 2018-08-03 01:18:30 --> Output Class Initialized
INFO - 2018-08-03 01:18:30 --> Security Class Initialized
DEBUG - 2018-08-03 01:18:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 01:18:30 --> Input Class Initialized
INFO - 2018-08-03 01:18:30 --> Language Class Initialized
INFO - 2018-08-03 01:18:30 --> Language Class Initialized
INFO - 2018-08-03 01:18:30 --> Config Class Initialized
INFO - 2018-08-03 01:18:30 --> Loader Class Initialized
DEBUG - 2018-08-03 01:18:30 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-03 01:18:30 --> Helper loaded: url_helper
INFO - 2018-08-03 01:18:30 --> Helper loaded: form_helper
INFO - 2018-08-03 01:18:30 --> Helper loaded: date_helper
INFO - 2018-08-03 01:18:30 --> Helper loaded: util_helper
INFO - 2018-08-03 01:18:30 --> Helper loaded: text_helper
INFO - 2018-08-03 01:18:30 --> Helper loaded: string_helper
INFO - 2018-08-03 01:18:30 --> Database Driver Class Initialized
DEBUG - 2018-08-03 01:18:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 01:18:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-03 01:18:30 --> Email Class Initialized
INFO - 2018-08-03 01:18:30 --> Controller Class Initialized
DEBUG - 2018-08-03 01:18:30 --> Home MX_Controller Initialized
DEBUG - 2018-08-03 01:18:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-03 01:18:30 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-03 01:18:30 --> Login MX_Controller Initialized
INFO - 2018-08-03 01:18:30 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-03 01:18:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-03 01:18:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-03 01:18:32 --> Config Class Initialized
INFO - 2018-08-03 01:18:32 --> Hooks Class Initialized
DEBUG - 2018-08-03 01:18:32 --> UTF-8 Support Enabled
INFO - 2018-08-03 01:18:32 --> Utf8 Class Initialized
INFO - 2018-08-03 01:18:32 --> URI Class Initialized
INFO - 2018-08-03 01:18:32 --> Router Class Initialized
INFO - 2018-08-03 01:18:32 --> Output Class Initialized
INFO - 2018-08-03 01:18:32 --> Security Class Initialized
DEBUG - 2018-08-03 01:18:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 01:18:32 --> Input Class Initialized
INFO - 2018-08-03 01:18:32 --> Language Class Initialized
INFO - 2018-08-03 01:18:32 --> Language Class Initialized
INFO - 2018-08-03 01:18:32 --> Config Class Initialized
INFO - 2018-08-03 01:18:32 --> Loader Class Initialized
DEBUG - 2018-08-03 01:18:32 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-03 01:18:32 --> Helper loaded: url_helper
INFO - 2018-08-03 01:18:32 --> Helper loaded: form_helper
INFO - 2018-08-03 01:18:32 --> Helper loaded: date_helper
INFO - 2018-08-03 01:18:32 --> Helper loaded: util_helper
INFO - 2018-08-03 01:18:32 --> Helper loaded: text_helper
INFO - 2018-08-03 01:18:32 --> Helper loaded: string_helper
INFO - 2018-08-03 01:18:32 --> Database Driver Class Initialized
DEBUG - 2018-08-03 01:18:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 01:18:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-03 01:18:32 --> Email Class Initialized
INFO - 2018-08-03 01:18:32 --> Controller Class Initialized
DEBUG - 2018-08-03 01:18:32 --> Home MX_Controller Initialized
DEBUG - 2018-08-03 01:18:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-03 01:18:32 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-03 01:18:33 --> Login MX_Controller Initialized
INFO - 2018-08-03 01:18:33 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-03 01:18:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-03 01:18:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-03 01:18:43 --> Config Class Initialized
INFO - 2018-08-03 01:18:43 --> Hooks Class Initialized
DEBUG - 2018-08-03 01:18:43 --> UTF-8 Support Enabled
INFO - 2018-08-03 01:18:43 --> Utf8 Class Initialized
INFO - 2018-08-03 01:18:43 --> URI Class Initialized
INFO - 2018-08-03 01:18:43 --> Router Class Initialized
INFO - 2018-08-03 01:18:43 --> Output Class Initialized
INFO - 2018-08-03 01:18:43 --> Security Class Initialized
DEBUG - 2018-08-03 01:18:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 01:18:43 --> Input Class Initialized
INFO - 2018-08-03 01:18:43 --> Language Class Initialized
INFO - 2018-08-03 01:18:43 --> Language Class Initialized
INFO - 2018-08-03 01:18:43 --> Config Class Initialized
INFO - 2018-08-03 01:18:43 --> Loader Class Initialized
DEBUG - 2018-08-03 01:18:43 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-03 01:18:43 --> Helper loaded: url_helper
INFO - 2018-08-03 01:18:43 --> Helper loaded: form_helper
INFO - 2018-08-03 01:18:43 --> Helper loaded: date_helper
INFO - 2018-08-03 01:18:43 --> Helper loaded: util_helper
INFO - 2018-08-03 01:18:43 --> Helper loaded: text_helper
INFO - 2018-08-03 01:18:43 --> Helper loaded: string_helper
INFO - 2018-08-03 01:18:43 --> Database Driver Class Initialized
DEBUG - 2018-08-03 01:18:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 01:18:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-03 01:18:43 --> Email Class Initialized
INFO - 2018-08-03 01:18:43 --> Controller Class Initialized
DEBUG - 2018-08-03 01:18:43 --> Home MX_Controller Initialized
DEBUG - 2018-08-03 01:18:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-03 01:18:43 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-03 01:18:43 --> Login MX_Controller Initialized
INFO - 2018-08-03 01:18:43 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-03 01:18:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-03 01:18:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-03 01:18:45 --> Config Class Initialized
INFO - 2018-08-03 01:18:45 --> Hooks Class Initialized
DEBUG - 2018-08-03 01:18:45 --> UTF-8 Support Enabled
INFO - 2018-08-03 01:18:45 --> Utf8 Class Initialized
INFO - 2018-08-03 01:18:45 --> URI Class Initialized
INFO - 2018-08-03 01:18:45 --> Router Class Initialized
INFO - 2018-08-03 01:18:45 --> Output Class Initialized
INFO - 2018-08-03 01:18:45 --> Security Class Initialized
DEBUG - 2018-08-03 01:18:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 01:18:45 --> Input Class Initialized
INFO - 2018-08-03 01:18:45 --> Language Class Initialized
INFO - 2018-08-03 01:18:45 --> Language Class Initialized
INFO - 2018-08-03 01:18:45 --> Config Class Initialized
INFO - 2018-08-03 01:18:45 --> Loader Class Initialized
DEBUG - 2018-08-03 01:18:45 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-03 01:18:45 --> Helper loaded: url_helper
INFO - 2018-08-03 01:18:45 --> Helper loaded: form_helper
INFO - 2018-08-03 01:18:45 --> Helper loaded: date_helper
INFO - 2018-08-03 01:18:45 --> Helper loaded: util_helper
INFO - 2018-08-03 01:18:45 --> Helper loaded: text_helper
INFO - 2018-08-03 01:18:45 --> Helper loaded: string_helper
INFO - 2018-08-03 01:18:45 --> Database Driver Class Initialized
DEBUG - 2018-08-03 01:18:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 01:18:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-03 01:18:45 --> Email Class Initialized
INFO - 2018-08-03 01:18:45 --> Controller Class Initialized
DEBUG - 2018-08-03 01:18:45 --> Home MX_Controller Initialized
DEBUG - 2018-08-03 01:18:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-03 01:18:45 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-03 01:18:45 --> Login MX_Controller Initialized
INFO - 2018-08-03 01:18:45 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-03 01:18:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-03 01:18:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-03 01:18:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-08-03 01:18:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-08-03 01:18:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-08-03 01:18:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-08-03 01:18:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-08-03 01:18:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/search_page.php
INFO - 2018-08-03 01:18:45 --> Final output sent to browser
DEBUG - 2018-08-03 01:18:45 --> Total execution time: 0.4482
INFO - 2018-08-03 01:18:46 --> Config Class Initialized
INFO - 2018-08-03 01:18:46 --> Hooks Class Initialized
INFO - 2018-08-03 01:18:46 --> Config Class Initialized
INFO - 2018-08-03 01:18:46 --> Hooks Class Initialized
DEBUG - 2018-08-03 01:18:46 --> UTF-8 Support Enabled
INFO - 2018-08-03 01:18:46 --> Utf8 Class Initialized
DEBUG - 2018-08-03 01:18:46 --> UTF-8 Support Enabled
INFO - 2018-08-03 01:18:46 --> URI Class Initialized
INFO - 2018-08-03 01:18:46 --> Utf8 Class Initialized
INFO - 2018-08-03 01:18:46 --> URI Class Initialized
INFO - 2018-08-03 01:18:46 --> Router Class Initialized
INFO - 2018-08-03 01:18:46 --> Output Class Initialized
INFO - 2018-08-03 01:18:46 --> Router Class Initialized
INFO - 2018-08-03 01:18:46 --> Security Class Initialized
INFO - 2018-08-03 01:18:46 --> Output Class Initialized
DEBUG - 2018-08-03 01:18:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 01:18:46 --> Security Class Initialized
DEBUG - 2018-08-03 01:18:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 01:18:46 --> Input Class Initialized
INFO - 2018-08-03 01:18:46 --> Language Class Initialized
INFO - 2018-08-03 01:18:46 --> Input Class Initialized
ERROR - 2018-08-03 01:18:46 --> 404 Page Not Found: /index
INFO - 2018-08-03 01:18:46 --> Language Class Initialized
INFO - 2018-08-03 01:18:46 --> Language Class Initialized
INFO - 2018-08-03 01:18:47 --> Config Class Initialized
INFO - 2018-08-03 01:18:47 --> Hooks Class Initialized
INFO - 2018-08-03 01:18:47 --> Config Class Initialized
DEBUG - 2018-08-03 01:18:47 --> UTF-8 Support Enabled
INFO - 2018-08-03 01:18:47 --> Loader Class Initialized
INFO - 2018-08-03 01:18:47 --> Utf8 Class Initialized
INFO - 2018-08-03 01:18:47 --> URI Class Initialized
INFO - 2018-08-03 01:18:47 --> Router Class Initialized
DEBUG - 2018-08-03 01:18:47 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-03 01:18:47 --> Output Class Initialized
INFO - 2018-08-03 01:18:47 --> Helper loaded: url_helper
INFO - 2018-08-03 01:18:47 --> Security Class Initialized
DEBUG - 2018-08-03 01:18:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 01:18:47 --> Input Class Initialized
INFO - 2018-08-03 01:18:47 --> Language Class Initialized
ERROR - 2018-08-03 01:18:47 --> 404 Page Not Found: /index
INFO - 2018-08-03 01:18:47 --> Helper loaded: form_helper
INFO - 2018-08-03 01:18:47 --> Config Class Initialized
INFO - 2018-08-03 01:18:47 --> Hooks Class Initialized
INFO - 2018-08-03 01:18:47 --> Helper loaded: date_helper
DEBUG - 2018-08-03 01:18:47 --> UTF-8 Support Enabled
INFO - 2018-08-03 01:18:47 --> Utf8 Class Initialized
INFO - 2018-08-03 01:18:47 --> URI Class Initialized
INFO - 2018-08-03 01:18:47 --> Router Class Initialized
INFO - 2018-08-03 01:18:47 --> Helper loaded: util_helper
INFO - 2018-08-03 01:18:47 --> Output Class Initialized
INFO - 2018-08-03 01:18:47 --> Helper loaded: text_helper
INFO - 2018-08-03 01:18:47 --> Helper loaded: string_helper
INFO - 2018-08-03 01:18:47 --> Security Class Initialized
DEBUG - 2018-08-03 01:18:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 01:18:47 --> Database Driver Class Initialized
INFO - 2018-08-03 01:18:47 --> Input Class Initialized
DEBUG - 2018-08-03 01:18:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 01:18:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-03 01:18:47 --> Language Class Initialized
INFO - 2018-08-03 01:18:47 --> Email Class Initialized
INFO - 2018-08-03 01:18:47 --> Controller Class Initialized
ERROR - 2018-08-03 01:18:47 --> 404 Page Not Found: /index
DEBUG - 2018-08-03 01:18:47 --> Home MX_Controller Initialized
DEBUG - 2018-08-03 01:18:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-03 01:18:47 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-03 01:18:47 --> Login MX_Controller Initialized
INFO - 2018-08-03 01:18:47 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-03 01:18:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-03 01:18:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-03 01:19:49 --> Config Class Initialized
INFO - 2018-08-03 01:19:49 --> Hooks Class Initialized
DEBUG - 2018-08-03 01:19:49 --> UTF-8 Support Enabled
INFO - 2018-08-03 01:19:49 --> Utf8 Class Initialized
INFO - 2018-08-03 01:19:49 --> URI Class Initialized
INFO - 2018-08-03 01:19:49 --> Router Class Initialized
INFO - 2018-08-03 01:19:49 --> Output Class Initialized
INFO - 2018-08-03 01:19:49 --> Security Class Initialized
DEBUG - 2018-08-03 01:19:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 01:19:49 --> Input Class Initialized
INFO - 2018-08-03 01:19:49 --> Language Class Initialized
INFO - 2018-08-03 01:19:49 --> Language Class Initialized
INFO - 2018-08-03 01:19:49 --> Config Class Initialized
INFO - 2018-08-03 01:19:49 --> Loader Class Initialized
DEBUG - 2018-08-03 01:19:49 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-03 01:19:49 --> Helper loaded: url_helper
INFO - 2018-08-03 01:19:49 --> Helper loaded: form_helper
INFO - 2018-08-03 01:19:49 --> Helper loaded: date_helper
INFO - 2018-08-03 01:19:49 --> Helper loaded: util_helper
INFO - 2018-08-03 01:19:49 --> Helper loaded: text_helper
INFO - 2018-08-03 01:19:49 --> Helper loaded: string_helper
INFO - 2018-08-03 01:19:49 --> Database Driver Class Initialized
DEBUG - 2018-08-03 01:19:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 01:19:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-03 01:19:49 --> Email Class Initialized
INFO - 2018-08-03 01:19:49 --> Controller Class Initialized
DEBUG - 2018-08-03 01:19:49 --> Home MX_Controller Initialized
DEBUG - 2018-08-03 01:19:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-03 01:19:49 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-03 01:19:49 --> Login MX_Controller Initialized
INFO - 2018-08-03 01:19:49 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-03 01:19:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-03 01:19:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-03 01:19:53 --> Config Class Initialized
INFO - 2018-08-03 01:19:53 --> Hooks Class Initialized
DEBUG - 2018-08-03 01:19:53 --> UTF-8 Support Enabled
INFO - 2018-08-03 01:19:53 --> Utf8 Class Initialized
INFO - 2018-08-03 01:19:53 --> URI Class Initialized
INFO - 2018-08-03 01:19:53 --> Router Class Initialized
INFO - 2018-08-03 01:19:53 --> Output Class Initialized
INFO - 2018-08-03 01:19:53 --> Security Class Initialized
DEBUG - 2018-08-03 01:19:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 01:19:53 --> Input Class Initialized
INFO - 2018-08-03 01:19:53 --> Language Class Initialized
ERROR - 2018-08-03 01:19:53 --> 404 Page Not Found: /index
INFO - 2018-08-03 01:21:12 --> Config Class Initialized
INFO - 2018-08-03 01:21:12 --> Hooks Class Initialized
DEBUG - 2018-08-03 01:21:12 --> UTF-8 Support Enabled
INFO - 2018-08-03 01:21:12 --> Utf8 Class Initialized
INFO - 2018-08-03 01:21:12 --> URI Class Initialized
INFO - 2018-08-03 01:21:12 --> Router Class Initialized
INFO - 2018-08-03 01:21:12 --> Output Class Initialized
INFO - 2018-08-03 01:21:12 --> Security Class Initialized
DEBUG - 2018-08-03 01:21:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 01:21:12 --> Input Class Initialized
INFO - 2018-08-03 01:21:12 --> Language Class Initialized
INFO - 2018-08-03 01:21:12 --> Language Class Initialized
INFO - 2018-08-03 01:21:12 --> Config Class Initialized
INFO - 2018-08-03 01:21:12 --> Loader Class Initialized
DEBUG - 2018-08-03 01:21:12 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-03 01:21:12 --> Helper loaded: url_helper
INFO - 2018-08-03 01:21:12 --> Helper loaded: form_helper
INFO - 2018-08-03 01:21:12 --> Helper loaded: date_helper
INFO - 2018-08-03 01:21:12 --> Helper loaded: util_helper
INFO - 2018-08-03 01:21:12 --> Helper loaded: text_helper
INFO - 2018-08-03 01:21:12 --> Helper loaded: string_helper
INFO - 2018-08-03 01:21:13 --> Database Driver Class Initialized
DEBUG - 2018-08-03 01:21:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 01:21:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-03 01:21:13 --> Email Class Initialized
INFO - 2018-08-03 01:21:13 --> Controller Class Initialized
DEBUG - 2018-08-03 01:21:13 --> Admin MX_Controller Initialized
INFO - 2018-08-03 01:21:13 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-03 01:21:13 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-03 01:21:13 --> Login MX_Controller Initialized
DEBUG - 2018-08-03 01:21:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-03 01:21:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-03 01:21:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-08-03 01:21:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-08-03 01:21:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-08-03 01:21:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-08-03 01:21:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-08-03 01:21:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/dashboard.php
INFO - 2018-08-03 01:21:13 --> Final output sent to browser
DEBUG - 2018-08-03 01:21:13 --> Total execution time: 0.4617
INFO - 2018-08-03 01:21:13 --> Config Class Initialized
INFO - 2018-08-03 01:21:13 --> Hooks Class Initialized
DEBUG - 2018-08-03 01:21:13 --> UTF-8 Support Enabled
INFO - 2018-08-03 01:21:13 --> Utf8 Class Initialized
INFO - 2018-08-03 01:21:13 --> URI Class Initialized
INFO - 2018-08-03 01:21:13 --> Router Class Initialized
INFO - 2018-08-03 01:21:13 --> Output Class Initialized
INFO - 2018-08-03 01:21:13 --> Security Class Initialized
DEBUG - 2018-08-03 01:21:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 01:21:13 --> Input Class Initialized
INFO - 2018-08-03 01:21:13 --> Language Class Initialized
ERROR - 2018-08-03 01:21:13 --> 404 Page Not Found: /index
INFO - 2018-08-03 01:21:14 --> Config Class Initialized
INFO - 2018-08-03 01:21:14 --> Hooks Class Initialized
DEBUG - 2018-08-03 01:21:14 --> UTF-8 Support Enabled
INFO - 2018-08-03 01:21:14 --> Utf8 Class Initialized
INFO - 2018-08-03 01:21:14 --> URI Class Initialized
INFO - 2018-08-03 01:21:14 --> Router Class Initialized
INFO - 2018-08-03 01:21:14 --> Output Class Initialized
INFO - 2018-08-03 01:21:14 --> Security Class Initialized
DEBUG - 2018-08-03 01:21:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 01:21:14 --> Input Class Initialized
INFO - 2018-08-03 01:21:14 --> Config Class Initialized
INFO - 2018-08-03 01:21:14 --> Hooks Class Initialized
DEBUG - 2018-08-03 01:21:14 --> UTF-8 Support Enabled
INFO - 2018-08-03 01:21:14 --> Language Class Initialized
INFO - 2018-08-03 01:21:14 --> Utf8 Class Initialized
ERROR - 2018-08-03 01:21:14 --> 404 Page Not Found: /index
INFO - 2018-08-03 01:21:14 --> URI Class Initialized
INFO - 2018-08-03 01:21:14 --> Router Class Initialized
INFO - 2018-08-03 01:21:14 --> Output Class Initialized
INFO - 2018-08-03 01:21:14 --> Security Class Initialized
DEBUG - 2018-08-03 01:21:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 01:21:14 --> Input Class Initialized
INFO - 2018-08-03 01:21:14 --> Language Class Initialized
INFO - 2018-08-03 01:21:14 --> Language Class Initialized
INFO - 2018-08-03 01:21:14 --> Config Class Initialized
INFO - 2018-08-03 01:21:14 --> Loader Class Initialized
DEBUG - 2018-08-03 01:21:14 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-03 01:21:14 --> Helper loaded: url_helper
INFO - 2018-08-03 01:21:14 --> Helper loaded: form_helper
INFO - 2018-08-03 01:21:14 --> Helper loaded: date_helper
INFO - 2018-08-03 01:21:14 --> Helper loaded: util_helper
INFO - 2018-08-03 01:21:14 --> Helper loaded: text_helper
INFO - 2018-08-03 01:21:14 --> Helper loaded: string_helper
INFO - 2018-08-03 01:21:14 --> Database Driver Class Initialized
DEBUG - 2018-08-03 01:21:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 01:21:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-03 01:21:15 --> Email Class Initialized
INFO - 2018-08-03 01:21:15 --> Controller Class Initialized
DEBUG - 2018-08-03 01:21:15 --> Home MX_Controller Initialized
DEBUG - 2018-08-03 01:21:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-03 01:21:15 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-03 01:21:15 --> Login MX_Controller Initialized
INFO - 2018-08-03 01:21:15 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-03 01:21:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-03 01:21:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-03 01:21:28 --> Config Class Initialized
INFO - 2018-08-03 01:21:28 --> Hooks Class Initialized
DEBUG - 2018-08-03 01:21:28 --> UTF-8 Support Enabled
INFO - 2018-08-03 01:21:28 --> Utf8 Class Initialized
INFO - 2018-08-03 01:21:28 --> URI Class Initialized
INFO - 2018-08-03 01:21:28 --> Router Class Initialized
INFO - 2018-08-03 01:21:28 --> Output Class Initialized
INFO - 2018-08-03 01:21:28 --> Security Class Initialized
DEBUG - 2018-08-03 01:21:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 01:21:28 --> Input Class Initialized
INFO - 2018-08-03 01:21:28 --> Language Class Initialized
INFO - 2018-08-03 01:21:28 --> Language Class Initialized
INFO - 2018-08-03 01:21:28 --> Config Class Initialized
INFO - 2018-08-03 01:21:28 --> Loader Class Initialized
DEBUG - 2018-08-03 01:21:28 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-03 01:21:28 --> Helper loaded: url_helper
INFO - 2018-08-03 01:21:28 --> Helper loaded: form_helper
INFO - 2018-08-03 01:21:28 --> Helper loaded: date_helper
INFO - 2018-08-03 01:21:28 --> Helper loaded: util_helper
INFO - 2018-08-03 01:21:28 --> Helper loaded: text_helper
INFO - 2018-08-03 01:21:28 --> Helper loaded: string_helper
INFO - 2018-08-03 01:21:28 --> Database Driver Class Initialized
DEBUG - 2018-08-03 01:21:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 01:21:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-03 01:21:28 --> Email Class Initialized
INFO - 2018-08-03 01:21:28 --> Controller Class Initialized
DEBUG - 2018-08-03 01:21:28 --> Home MX_Controller Initialized
DEBUG - 2018-08-03 01:21:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-03 01:21:28 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-03 01:21:28 --> Login MX_Controller Initialized
INFO - 2018-08-03 01:21:28 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-03 01:21:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-03 01:21:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-03 01:21:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-08-03 01:21:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-08-03 01:21:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-08-03 01:21:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-08-03 01:21:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-08-03 01:21:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/search_page.php
INFO - 2018-08-03 01:21:28 --> Final output sent to browser
DEBUG - 2018-08-03 01:21:28 --> Total execution time: 0.4969
INFO - 2018-08-03 01:21:29 --> Config Class Initialized
INFO - 2018-08-03 01:21:29 --> Hooks Class Initialized
DEBUG - 2018-08-03 01:21:29 --> UTF-8 Support Enabled
INFO - 2018-08-03 01:21:29 --> Utf8 Class Initialized
INFO - 2018-08-03 01:21:29 --> Config Class Initialized
INFO - 2018-08-03 01:21:29 --> URI Class Initialized
INFO - 2018-08-03 01:21:29 --> Hooks Class Initialized
INFO - 2018-08-03 01:21:29 --> Router Class Initialized
DEBUG - 2018-08-03 01:21:29 --> UTF-8 Support Enabled
INFO - 2018-08-03 01:21:29 --> Output Class Initialized
INFO - 2018-08-03 01:21:29 --> Utf8 Class Initialized
INFO - 2018-08-03 01:21:29 --> Security Class Initialized
INFO - 2018-08-03 01:21:29 --> URI Class Initialized
DEBUG - 2018-08-03 01:21:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 01:21:29 --> Input Class Initialized
INFO - 2018-08-03 01:21:29 --> Router Class Initialized
INFO - 2018-08-03 01:21:29 --> Language Class Initialized
INFO - 2018-08-03 01:21:29 --> Output Class Initialized
ERROR - 2018-08-03 01:21:29 --> 404 Page Not Found: /index
INFO - 2018-08-03 01:21:29 --> Security Class Initialized
DEBUG - 2018-08-03 01:21:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 01:21:29 --> Input Class Initialized
INFO - 2018-08-03 01:21:29 --> Language Class Initialized
INFO - 2018-08-03 01:21:29 --> Language Class Initialized
INFO - 2018-08-03 01:21:29 --> Config Class Initialized
INFO - 2018-08-03 01:21:29 --> Loader Class Initialized
DEBUG - 2018-08-03 01:21:29 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-03 01:21:29 --> Helper loaded: url_helper
INFO - 2018-08-03 01:21:29 --> Helper loaded: form_helper
INFO - 2018-08-03 01:21:29 --> Helper loaded: date_helper
INFO - 2018-08-03 01:21:29 --> Helper loaded: util_helper
INFO - 2018-08-03 01:21:29 --> Helper loaded: text_helper
INFO - 2018-08-03 01:21:29 --> Helper loaded: string_helper
INFO - 2018-08-03 01:21:29 --> Database Driver Class Initialized
DEBUG - 2018-08-03 01:21:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 01:21:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-03 01:21:29 --> Email Class Initialized
INFO - 2018-08-03 01:21:29 --> Controller Class Initialized
DEBUG - 2018-08-03 01:21:29 --> Home MX_Controller Initialized
INFO - 2018-08-03 01:21:29 --> Config Class Initialized
INFO - 2018-08-03 01:21:29 --> Hooks Class Initialized
DEBUG - 2018-08-03 01:21:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-03 01:21:29 --> UTF-8 Support Enabled
DEBUG - 2018-08-03 01:21:29 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
INFO - 2018-08-03 01:21:29 --> Utf8 Class Initialized
DEBUG - 2018-08-03 01:21:29 --> Login MX_Controller Initialized
INFO - 2018-08-03 01:21:29 --> Language file loaded: language/english/data_lang.php
INFO - 2018-08-03 01:21:29 --> URI Class Initialized
DEBUG - 2018-08-03 01:21:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-08-03 01:21:29 --> Router Class Initialized
DEBUG - 2018-08-03 01:21:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-03 01:21:29 --> Output Class Initialized
INFO - 2018-08-03 01:21:29 --> Security Class Initialized
DEBUG - 2018-08-03 01:21:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 01:21:29 --> Input Class Initialized
INFO - 2018-08-03 01:21:29 --> Language Class Initialized
ERROR - 2018-08-03 01:21:29 --> 404 Page Not Found: /index
INFO - 2018-08-03 01:21:30 --> Config Class Initialized
INFO - 2018-08-03 01:21:30 --> Hooks Class Initialized
DEBUG - 2018-08-03 01:21:30 --> UTF-8 Support Enabled
INFO - 2018-08-03 01:21:30 --> Utf8 Class Initialized
INFO - 2018-08-03 01:21:30 --> URI Class Initialized
INFO - 2018-08-03 01:21:30 --> Router Class Initialized
INFO - 2018-08-03 01:21:30 --> Output Class Initialized
INFO - 2018-08-03 01:21:30 --> Security Class Initialized
DEBUG - 2018-08-03 01:21:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 01:21:30 --> Input Class Initialized
INFO - 2018-08-03 01:21:30 --> Language Class Initialized
ERROR - 2018-08-03 01:21:30 --> 404 Page Not Found: /index
INFO - 2018-08-03 01:21:33 --> Config Class Initialized
INFO - 2018-08-03 01:21:33 --> Hooks Class Initialized
DEBUG - 2018-08-03 01:21:33 --> UTF-8 Support Enabled
INFO - 2018-08-03 01:21:33 --> Utf8 Class Initialized
INFO - 2018-08-03 01:21:33 --> URI Class Initialized
INFO - 2018-08-03 01:21:33 --> Router Class Initialized
INFO - 2018-08-03 01:21:33 --> Output Class Initialized
INFO - 2018-08-03 01:21:33 --> Security Class Initialized
DEBUG - 2018-08-03 01:21:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 01:21:33 --> Input Class Initialized
INFO - 2018-08-03 01:21:33 --> Language Class Initialized
INFO - 2018-08-03 01:21:33 --> Language Class Initialized
INFO - 2018-08-03 01:21:33 --> Config Class Initialized
INFO - 2018-08-03 01:21:33 --> Loader Class Initialized
DEBUG - 2018-08-03 01:21:33 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-03 01:21:33 --> Helper loaded: url_helper
INFO - 2018-08-03 01:21:33 --> Helper loaded: form_helper
INFO - 2018-08-03 01:21:33 --> Helper loaded: date_helper
INFO - 2018-08-03 01:21:33 --> Helper loaded: util_helper
INFO - 2018-08-03 01:21:33 --> Helper loaded: text_helper
INFO - 2018-08-03 01:21:33 --> Helper loaded: string_helper
INFO - 2018-08-03 01:21:33 --> Database Driver Class Initialized
DEBUG - 2018-08-03 01:21:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 01:21:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-03 01:21:33 --> Email Class Initialized
INFO - 2018-08-03 01:21:33 --> Controller Class Initialized
DEBUG - 2018-08-03 01:21:33 --> Home MX_Controller Initialized
DEBUG - 2018-08-03 01:21:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-03 01:21:33 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-03 01:21:33 --> Login MX_Controller Initialized
INFO - 2018-08-03 01:21:33 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-03 01:21:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-03 01:21:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-03 01:21:36 --> Config Class Initialized
INFO - 2018-08-03 01:21:36 --> Hooks Class Initialized
DEBUG - 2018-08-03 01:21:36 --> UTF-8 Support Enabled
INFO - 2018-08-03 01:21:37 --> Utf8 Class Initialized
INFO - 2018-08-03 01:21:37 --> URI Class Initialized
INFO - 2018-08-03 01:21:37 --> Router Class Initialized
INFO - 2018-08-03 01:21:37 --> Output Class Initialized
INFO - 2018-08-03 01:21:37 --> Security Class Initialized
DEBUG - 2018-08-03 01:21:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 01:21:37 --> Input Class Initialized
INFO - 2018-08-03 01:21:37 --> Language Class Initialized
INFO - 2018-08-03 01:21:37 --> Language Class Initialized
INFO - 2018-08-03 01:21:37 --> Config Class Initialized
INFO - 2018-08-03 01:21:37 --> Loader Class Initialized
DEBUG - 2018-08-03 01:21:37 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-03 01:21:37 --> Helper loaded: url_helper
INFO - 2018-08-03 01:21:37 --> Helper loaded: form_helper
INFO - 2018-08-03 01:21:37 --> Helper loaded: date_helper
INFO - 2018-08-03 01:21:37 --> Helper loaded: util_helper
INFO - 2018-08-03 01:21:37 --> Helper loaded: text_helper
INFO - 2018-08-03 01:21:37 --> Helper loaded: string_helper
INFO - 2018-08-03 01:21:37 --> Database Driver Class Initialized
DEBUG - 2018-08-03 01:21:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 01:21:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-03 01:21:37 --> Email Class Initialized
INFO - 2018-08-03 01:21:37 --> Controller Class Initialized
DEBUG - 2018-08-03 01:21:37 --> Home MX_Controller Initialized
DEBUG - 2018-08-03 01:21:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-03 01:21:37 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-03 01:21:37 --> Login MX_Controller Initialized
INFO - 2018-08-03 01:21:37 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-03 01:21:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-03 01:21:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-03 01:21:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-08-03 01:21:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-08-03 01:21:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-08-03 01:21:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-08-03 01:21:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-08-03 01:21:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/search_page.php
INFO - 2018-08-03 01:21:37 --> Final output sent to browser
DEBUG - 2018-08-03 01:21:37 --> Total execution time: 0.4787
INFO - 2018-08-03 01:21:37 --> Config Class Initialized
INFO - 2018-08-03 01:21:37 --> Hooks Class Initialized
INFO - 2018-08-03 01:21:37 --> Config Class Initialized
INFO - 2018-08-03 01:21:37 --> Hooks Class Initialized
DEBUG - 2018-08-03 01:21:37 --> UTF-8 Support Enabled
INFO - 2018-08-03 01:21:37 --> Utf8 Class Initialized
DEBUG - 2018-08-03 01:21:37 --> UTF-8 Support Enabled
INFO - 2018-08-03 01:21:37 --> Utf8 Class Initialized
INFO - 2018-08-03 01:21:38 --> URI Class Initialized
INFO - 2018-08-03 01:21:38 --> URI Class Initialized
INFO - 2018-08-03 01:21:38 --> Router Class Initialized
INFO - 2018-08-03 01:21:38 --> Output Class Initialized
INFO - 2018-08-03 01:21:38 --> Router Class Initialized
INFO - 2018-08-03 01:21:38 --> Security Class Initialized
DEBUG - 2018-08-03 01:21:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 01:21:38 --> Output Class Initialized
INFO - 2018-08-03 01:21:38 --> Input Class Initialized
INFO - 2018-08-03 01:21:38 --> Security Class Initialized
DEBUG - 2018-08-03 01:21:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 01:21:38 --> Language Class Initialized
INFO - 2018-08-03 01:21:38 --> Input Class Initialized
ERROR - 2018-08-03 01:21:38 --> 404 Page Not Found: /index
INFO - 2018-08-03 01:21:38 --> Language Class Initialized
INFO - 2018-08-03 01:21:38 --> Config Class Initialized
INFO - 2018-08-03 01:21:38 --> Hooks Class Initialized
INFO - 2018-08-03 01:21:38 --> Language Class Initialized
INFO - 2018-08-03 01:21:38 --> Config Class Initialized
DEBUG - 2018-08-03 01:21:38 --> UTF-8 Support Enabled
INFO - 2018-08-03 01:21:38 --> Utf8 Class Initialized
INFO - 2018-08-03 01:21:38 --> Loader Class Initialized
INFO - 2018-08-03 01:21:38 --> URI Class Initialized
DEBUG - 2018-08-03 01:21:38 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-03 01:21:38 --> Helper loaded: url_helper
INFO - 2018-08-03 01:21:38 --> Router Class Initialized
INFO - 2018-08-03 01:21:38 --> Helper loaded: form_helper
INFO - 2018-08-03 01:21:38 --> Output Class Initialized
INFO - 2018-08-03 01:21:38 --> Security Class Initialized
INFO - 2018-08-03 01:21:38 --> Helper loaded: date_helper
DEBUG - 2018-08-03 01:21:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 01:21:38 --> Helper loaded: util_helper
INFO - 2018-08-03 01:21:38 --> Input Class Initialized
INFO - 2018-08-03 01:21:38 --> Helper loaded: text_helper
INFO - 2018-08-03 01:21:38 --> Language Class Initialized
INFO - 2018-08-03 01:21:38 --> Helper loaded: string_helper
ERROR - 2018-08-03 01:21:38 --> 404 Page Not Found: /index
INFO - 2018-08-03 01:21:38 --> Database Driver Class Initialized
INFO - 2018-08-03 01:21:38 --> Config Class Initialized
DEBUG - 2018-08-03 01:21:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 01:21:38 --> Hooks Class Initialized
INFO - 2018-08-03 01:21:38 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-08-03 01:21:38 --> UTF-8 Support Enabled
INFO - 2018-08-03 01:21:38 --> Email Class Initialized
INFO - 2018-08-03 01:21:38 --> Utf8 Class Initialized
INFO - 2018-08-03 01:21:38 --> Controller Class Initialized
DEBUG - 2018-08-03 01:21:38 --> Home MX_Controller Initialized
INFO - 2018-08-03 01:21:38 --> URI Class Initialized
INFO - 2018-08-03 01:21:38 --> Router Class Initialized
DEBUG - 2018-08-03 01:21:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-08-03 01:21:38 --> Output Class Initialized
DEBUG - 2018-08-03 01:21:38 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-03 01:21:38 --> Login MX_Controller Initialized
INFO - 2018-08-03 01:21:38 --> Security Class Initialized
INFO - 2018-08-03 01:21:38 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-03 01:21:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-08-03 01:21:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-03 01:21:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-03 01:21:38 --> Input Class Initialized
INFO - 2018-08-03 01:21:38 --> Language Class Initialized
ERROR - 2018-08-03 01:21:38 --> 404 Page Not Found: /index
INFO - 2018-08-03 01:21:41 --> Config Class Initialized
INFO - 2018-08-03 01:21:41 --> Hooks Class Initialized
DEBUG - 2018-08-03 01:21:41 --> UTF-8 Support Enabled
INFO - 2018-08-03 01:21:41 --> Utf8 Class Initialized
INFO - 2018-08-03 01:21:41 --> URI Class Initialized
INFO - 2018-08-03 01:21:41 --> Router Class Initialized
INFO - 2018-08-03 01:21:41 --> Output Class Initialized
INFO - 2018-08-03 01:21:41 --> Security Class Initialized
DEBUG - 2018-08-03 01:21:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 01:21:41 --> Input Class Initialized
INFO - 2018-08-03 01:21:41 --> Language Class Initialized
INFO - 2018-08-03 01:21:41 --> Language Class Initialized
INFO - 2018-08-03 01:21:41 --> Config Class Initialized
INFO - 2018-08-03 01:21:41 --> Loader Class Initialized
DEBUG - 2018-08-03 01:21:41 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-03 01:21:41 --> Helper loaded: url_helper
INFO - 2018-08-03 01:21:41 --> Helper loaded: form_helper
INFO - 2018-08-03 01:21:41 --> Helper loaded: date_helper
INFO - 2018-08-03 01:21:41 --> Helper loaded: util_helper
INFO - 2018-08-03 01:21:41 --> Helper loaded: text_helper
INFO - 2018-08-03 01:21:41 --> Helper loaded: string_helper
INFO - 2018-08-03 01:21:41 --> Database Driver Class Initialized
DEBUG - 2018-08-03 01:21:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 01:21:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-03 01:21:41 --> Email Class Initialized
INFO - 2018-08-03 01:21:41 --> Controller Class Initialized
DEBUG - 2018-08-03 01:21:41 --> Home MX_Controller Initialized
DEBUG - 2018-08-03 01:21:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-03 01:21:41 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-03 01:21:41 --> Login MX_Controller Initialized
INFO - 2018-08-03 01:21:41 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-03 01:21:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-03 01:21:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-03 01:21:43 --> Config Class Initialized
INFO - 2018-08-03 01:21:43 --> Hooks Class Initialized
DEBUG - 2018-08-03 01:21:43 --> UTF-8 Support Enabled
INFO - 2018-08-03 01:21:43 --> Utf8 Class Initialized
INFO - 2018-08-03 01:21:43 --> URI Class Initialized
INFO - 2018-08-03 01:21:43 --> Router Class Initialized
INFO - 2018-08-03 01:21:43 --> Output Class Initialized
INFO - 2018-08-03 01:21:43 --> Security Class Initialized
DEBUG - 2018-08-03 01:21:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 01:21:43 --> Input Class Initialized
INFO - 2018-08-03 01:21:43 --> Language Class Initialized
INFO - 2018-08-03 01:21:43 --> Language Class Initialized
INFO - 2018-08-03 01:21:43 --> Config Class Initialized
INFO - 2018-08-03 01:21:43 --> Loader Class Initialized
DEBUG - 2018-08-03 01:21:43 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-03 01:21:43 --> Helper loaded: url_helper
INFO - 2018-08-03 01:21:43 --> Helper loaded: form_helper
INFO - 2018-08-03 01:21:43 --> Helper loaded: date_helper
INFO - 2018-08-03 01:21:43 --> Helper loaded: util_helper
INFO - 2018-08-03 01:21:43 --> Helper loaded: text_helper
INFO - 2018-08-03 01:21:43 --> Helper loaded: string_helper
INFO - 2018-08-03 01:21:43 --> Database Driver Class Initialized
DEBUG - 2018-08-03 01:21:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 01:21:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-03 01:21:43 --> Email Class Initialized
INFO - 2018-08-03 01:21:43 --> Controller Class Initialized
DEBUG - 2018-08-03 01:21:43 --> Home MX_Controller Initialized
DEBUG - 2018-08-03 01:21:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-03 01:21:43 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-03 01:21:43 --> Login MX_Controller Initialized
INFO - 2018-08-03 01:21:43 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-03 01:21:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-03 01:21:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-03 01:21:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-08-03 01:21:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-08-03 01:21:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-08-03 01:21:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-08-03 01:21:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-08-03 01:21:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/search_page.php
INFO - 2018-08-03 01:21:44 --> Final output sent to browser
DEBUG - 2018-08-03 01:21:44 --> Total execution time: 0.5777
INFO - 2018-08-03 01:21:44 --> Config Class Initialized
INFO - 2018-08-03 01:21:44 --> Hooks Class Initialized
DEBUG - 2018-08-03 01:21:44 --> UTF-8 Support Enabled
INFO - 2018-08-03 01:21:44 --> Config Class Initialized
INFO - 2018-08-03 01:21:44 --> Utf8 Class Initialized
INFO - 2018-08-03 01:21:44 --> Hooks Class Initialized
INFO - 2018-08-03 01:21:44 --> URI Class Initialized
DEBUG - 2018-08-03 01:21:44 --> UTF-8 Support Enabled
INFO - 2018-08-03 01:21:44 --> Utf8 Class Initialized
INFO - 2018-08-03 01:21:44 --> Router Class Initialized
INFO - 2018-08-03 01:21:44 --> URI Class Initialized
INFO - 2018-08-03 01:21:44 --> Router Class Initialized
INFO - 2018-08-03 01:21:44 --> Output Class Initialized
INFO - 2018-08-03 01:21:44 --> Output Class Initialized
INFO - 2018-08-03 01:21:44 --> Security Class Initialized
DEBUG - 2018-08-03 01:21:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 01:21:44 --> Input Class Initialized
INFO - 2018-08-03 01:21:44 --> Language Class Initialized
ERROR - 2018-08-03 01:21:44 --> 404 Page Not Found: /index
INFO - 2018-08-03 01:21:44 --> Config Class Initialized
INFO - 2018-08-03 01:21:44 --> Hooks Class Initialized
DEBUG - 2018-08-03 01:21:44 --> UTF-8 Support Enabled
INFO - 2018-08-03 01:21:44 --> Utf8 Class Initialized
INFO - 2018-08-03 01:21:44 --> URI Class Initialized
INFO - 2018-08-03 01:21:44 --> Security Class Initialized
INFO - 2018-08-03 01:21:44 --> Router Class Initialized
DEBUG - 2018-08-03 01:21:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 01:21:44 --> Output Class Initialized
INFO - 2018-08-03 01:21:44 --> Security Class Initialized
DEBUG - 2018-08-03 01:21:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 01:21:44 --> Input Class Initialized
INFO - 2018-08-03 01:21:44 --> Language Class Initialized
ERROR - 2018-08-03 01:21:44 --> 404 Page Not Found: /index
INFO - 2018-08-03 01:21:44 --> Config Class Initialized
INFO - 2018-08-03 01:21:45 --> Hooks Class Initialized
DEBUG - 2018-08-03 01:21:45 --> UTF-8 Support Enabled
INFO - 2018-08-03 01:21:45 --> Utf8 Class Initialized
INFO - 2018-08-03 01:21:45 --> Input Class Initialized
INFO - 2018-08-03 01:21:45 --> URI Class Initialized
INFO - 2018-08-03 01:21:45 --> Language Class Initialized
INFO - 2018-08-03 01:21:45 --> Router Class Initialized
INFO - 2018-08-03 01:21:45 --> Output Class Initialized
INFO - 2018-08-03 01:21:45 --> Language Class Initialized
INFO - 2018-08-03 01:21:45 --> Security Class Initialized
INFO - 2018-08-03 01:21:45 --> Config Class Initialized
INFO - 2018-08-03 01:21:45 --> Loader Class Initialized
DEBUG - 2018-08-03 01:21:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 01:21:45 --> Input Class Initialized
DEBUG - 2018-08-03 01:21:45 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-03 01:21:45 --> Language Class Initialized
INFO - 2018-08-03 01:21:45 --> Helper loaded: url_helper
ERROR - 2018-08-03 01:21:45 --> 404 Page Not Found: /index
INFO - 2018-08-03 01:21:45 --> Helper loaded: form_helper
INFO - 2018-08-03 01:21:45 --> Helper loaded: date_helper
INFO - 2018-08-03 01:21:45 --> Helper loaded: util_helper
INFO - 2018-08-03 01:21:45 --> Helper loaded: text_helper
INFO - 2018-08-03 01:21:45 --> Helper loaded: string_helper
INFO - 2018-08-03 01:21:45 --> Database Driver Class Initialized
DEBUG - 2018-08-03 01:21:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 01:21:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-03 01:21:45 --> Email Class Initialized
INFO - 2018-08-03 01:21:45 --> Controller Class Initialized
DEBUG - 2018-08-03 01:21:45 --> Home MX_Controller Initialized
DEBUG - 2018-08-03 01:21:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-03 01:21:45 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-03 01:21:45 --> Login MX_Controller Initialized
INFO - 2018-08-03 01:21:45 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-03 01:21:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-03 01:21:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-03 01:21:46 --> Config Class Initialized
INFO - 2018-08-03 01:21:46 --> Hooks Class Initialized
DEBUG - 2018-08-03 01:21:46 --> UTF-8 Support Enabled
INFO - 2018-08-03 01:21:46 --> Utf8 Class Initialized
INFO - 2018-08-03 01:21:46 --> URI Class Initialized
INFO - 2018-08-03 01:21:46 --> Router Class Initialized
INFO - 2018-08-03 01:21:46 --> Output Class Initialized
INFO - 2018-08-03 01:21:46 --> Security Class Initialized
DEBUG - 2018-08-03 01:21:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 01:21:46 --> Input Class Initialized
INFO - 2018-08-03 01:21:46 --> Language Class Initialized
INFO - 2018-08-03 01:21:46 --> Language Class Initialized
INFO - 2018-08-03 01:21:46 --> Config Class Initialized
INFO - 2018-08-03 01:21:46 --> Loader Class Initialized
DEBUG - 2018-08-03 01:21:46 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-03 01:21:46 --> Helper loaded: url_helper
INFO - 2018-08-03 01:21:46 --> Helper loaded: form_helper
INFO - 2018-08-03 01:21:46 --> Helper loaded: date_helper
INFO - 2018-08-03 01:21:46 --> Helper loaded: util_helper
INFO - 2018-08-03 01:21:46 --> Helper loaded: text_helper
INFO - 2018-08-03 01:21:47 --> Helper loaded: string_helper
INFO - 2018-08-03 01:21:47 --> Database Driver Class Initialized
DEBUG - 2018-08-03 01:21:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 01:21:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-03 01:21:47 --> Email Class Initialized
INFO - 2018-08-03 01:21:47 --> Controller Class Initialized
DEBUG - 2018-08-03 01:21:47 --> Home MX_Controller Initialized
DEBUG - 2018-08-03 01:21:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-03 01:21:47 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-03 01:21:47 --> Login MX_Controller Initialized
INFO - 2018-08-03 01:21:47 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-03 01:21:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-03 01:21:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-03 01:21:49 --> Config Class Initialized
INFO - 2018-08-03 01:21:49 --> Hooks Class Initialized
DEBUG - 2018-08-03 01:21:49 --> UTF-8 Support Enabled
INFO - 2018-08-03 01:21:49 --> Utf8 Class Initialized
INFO - 2018-08-03 01:21:49 --> URI Class Initialized
INFO - 2018-08-03 01:21:49 --> Router Class Initialized
INFO - 2018-08-03 01:21:49 --> Output Class Initialized
INFO - 2018-08-03 01:21:49 --> Security Class Initialized
DEBUG - 2018-08-03 01:21:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 01:21:49 --> Input Class Initialized
INFO - 2018-08-03 01:21:49 --> Language Class Initialized
INFO - 2018-08-03 01:21:49 --> Language Class Initialized
INFO - 2018-08-03 01:21:49 --> Config Class Initialized
INFO - 2018-08-03 01:21:49 --> Loader Class Initialized
DEBUG - 2018-08-03 01:21:49 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-03 01:21:49 --> Helper loaded: url_helper
INFO - 2018-08-03 01:21:49 --> Helper loaded: form_helper
INFO - 2018-08-03 01:21:49 --> Helper loaded: date_helper
INFO - 2018-08-03 01:21:49 --> Helper loaded: util_helper
INFO - 2018-08-03 01:21:49 --> Helper loaded: text_helper
INFO - 2018-08-03 01:21:49 --> Helper loaded: string_helper
INFO - 2018-08-03 01:21:49 --> Database Driver Class Initialized
DEBUG - 2018-08-03 01:21:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 01:21:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-03 01:21:49 --> Email Class Initialized
INFO - 2018-08-03 01:21:49 --> Controller Class Initialized
DEBUG - 2018-08-03 01:21:49 --> Home MX_Controller Initialized
DEBUG - 2018-08-03 01:21:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-03 01:21:49 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-03 01:21:50 --> Login MX_Controller Initialized
INFO - 2018-08-03 01:21:50 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-03 01:21:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-03 01:21:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-03 01:21:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-08-03 01:21:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-08-03 01:21:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-08-03 01:21:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-08-03 01:21:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-08-03 01:21:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/search_page.php
INFO - 2018-08-03 01:21:50 --> Final output sent to browser
DEBUG - 2018-08-03 01:21:50 --> Total execution time: 0.4871
INFO - 2018-08-03 01:21:50 --> Config Class Initialized
INFO - 2018-08-03 01:21:50 --> Hooks Class Initialized
INFO - 2018-08-03 01:21:50 --> Config Class Initialized
INFO - 2018-08-03 01:21:50 --> Hooks Class Initialized
DEBUG - 2018-08-03 01:21:50 --> UTF-8 Support Enabled
DEBUG - 2018-08-03 01:21:50 --> UTF-8 Support Enabled
INFO - 2018-08-03 01:21:50 --> Utf8 Class Initialized
INFO - 2018-08-03 01:21:50 --> URI Class Initialized
INFO - 2018-08-03 01:21:50 --> Utf8 Class Initialized
INFO - 2018-08-03 01:21:50 --> Router Class Initialized
INFO - 2018-08-03 01:21:50 --> Output Class Initialized
INFO - 2018-08-03 01:21:50 --> URI Class Initialized
INFO - 2018-08-03 01:21:50 --> Router Class Initialized
INFO - 2018-08-03 01:21:50 --> Security Class Initialized
INFO - 2018-08-03 01:21:50 --> Output Class Initialized
DEBUG - 2018-08-03 01:21:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 01:21:50 --> Input Class Initialized
INFO - 2018-08-03 01:21:50 --> Security Class Initialized
INFO - 2018-08-03 01:21:50 --> Language Class Initialized
DEBUG - 2018-08-03 01:21:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 01:21:50 --> Input Class Initialized
INFO - 2018-08-03 01:21:50 --> Language Class Initialized
INFO - 2018-08-03 01:21:50 --> Config Class Initialized
INFO - 2018-08-03 01:21:50 --> Language Class Initialized
ERROR - 2018-08-03 01:21:50 --> 404 Page Not Found: /index
INFO - 2018-08-03 01:21:50 --> Loader Class Initialized
DEBUG - 2018-08-03 01:21:50 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-03 01:21:50 --> Config Class Initialized
INFO - 2018-08-03 01:21:50 --> Hooks Class Initialized
INFO - 2018-08-03 01:21:50 --> Helper loaded: url_helper
INFO - 2018-08-03 01:21:50 --> Helper loaded: form_helper
DEBUG - 2018-08-03 01:21:50 --> UTF-8 Support Enabled
INFO - 2018-08-03 01:21:50 --> Utf8 Class Initialized
INFO - 2018-08-03 01:21:50 --> Helper loaded: date_helper
INFO - 2018-08-03 01:21:50 --> Helper loaded: util_helper
INFO - 2018-08-03 01:21:50 --> URI Class Initialized
INFO - 2018-08-03 01:21:50 --> Router Class Initialized
INFO - 2018-08-03 01:21:50 --> Helper loaded: text_helper
INFO - 2018-08-03 01:21:50 --> Helper loaded: string_helper
INFO - 2018-08-03 01:21:50 --> Output Class Initialized
INFO - 2018-08-03 01:21:50 --> Security Class Initialized
INFO - 2018-08-03 01:21:50 --> Database Driver Class Initialized
DEBUG - 2018-08-03 01:21:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-08-03 01:21:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 01:21:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-03 01:21:50 --> Input Class Initialized
INFO - 2018-08-03 01:21:50 --> Language Class Initialized
INFO - 2018-08-03 01:21:50 --> Email Class Initialized
INFO - 2018-08-03 01:21:50 --> Controller Class Initialized
ERROR - 2018-08-03 01:21:50 --> 404 Page Not Found: /index
DEBUG - 2018-08-03 01:21:50 --> Home MX_Controller Initialized
INFO - 2018-08-03 01:21:51 --> Config Class Initialized
INFO - 2018-08-03 01:21:51 --> Hooks Class Initialized
DEBUG - 2018-08-03 01:21:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-03 01:21:51 --> UTF-8 Support Enabled
DEBUG - 2018-08-03 01:21:51 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
INFO - 2018-08-03 01:21:51 --> Utf8 Class Initialized
DEBUG - 2018-08-03 01:21:51 --> Login MX_Controller Initialized
INFO - 2018-08-03 01:21:51 --> URI Class Initialized
INFO - 2018-08-03 01:21:51 --> Language file loaded: language/english/data_lang.php
INFO - 2018-08-03 01:21:51 --> Router Class Initialized
DEBUG - 2018-08-03 01:21:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-08-03 01:21:51 --> Output Class Initialized
DEBUG - 2018-08-03 01:21:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-03 01:21:51 --> Security Class Initialized
DEBUG - 2018-08-03 01:21:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 01:21:51 --> Input Class Initialized
INFO - 2018-08-03 01:21:51 --> Language Class Initialized
ERROR - 2018-08-03 01:21:51 --> 404 Page Not Found: /index
INFO - 2018-08-03 01:34:53 --> Config Class Initialized
INFO - 2018-08-03 01:34:53 --> Hooks Class Initialized
DEBUG - 2018-08-03 01:34:53 --> UTF-8 Support Enabled
INFO - 2018-08-03 01:34:53 --> Utf8 Class Initialized
INFO - 2018-08-03 01:34:53 --> URI Class Initialized
INFO - 2018-08-03 01:34:53 --> Router Class Initialized
INFO - 2018-08-03 01:34:53 --> Output Class Initialized
INFO - 2018-08-03 01:34:53 --> Security Class Initialized
DEBUG - 2018-08-03 01:34:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 01:34:53 --> Input Class Initialized
INFO - 2018-08-03 01:34:53 --> Language Class Initialized
INFO - 2018-08-03 01:34:53 --> Language Class Initialized
INFO - 2018-08-03 01:34:53 --> Config Class Initialized
INFO - 2018-08-03 01:34:53 --> Loader Class Initialized
DEBUG - 2018-08-03 01:34:53 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-03 01:34:53 --> Helper loaded: url_helper
INFO - 2018-08-03 01:34:53 --> Helper loaded: form_helper
INFO - 2018-08-03 01:34:53 --> Helper loaded: date_helper
INFO - 2018-08-03 01:34:53 --> Helper loaded: util_helper
INFO - 2018-08-03 01:34:53 --> Helper loaded: text_helper
INFO - 2018-08-03 01:34:53 --> Helper loaded: string_helper
INFO - 2018-08-03 01:34:53 --> Database Driver Class Initialized
DEBUG - 2018-08-03 01:34:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 01:34:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-03 01:34:53 --> Email Class Initialized
INFO - 2018-08-03 01:34:53 --> Controller Class Initialized
DEBUG - 2018-08-03 01:34:53 --> Home MX_Controller Initialized
DEBUG - 2018-08-03 01:34:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-03 01:34:53 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-03 01:34:53 --> Login MX_Controller Initialized
INFO - 2018-08-03 01:34:53 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-03 01:34:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-03 01:34:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-03 01:34:55 --> Config Class Initialized
INFO - 2018-08-03 01:34:55 --> Hooks Class Initialized
DEBUG - 2018-08-03 01:34:55 --> UTF-8 Support Enabled
INFO - 2018-08-03 01:34:55 --> Utf8 Class Initialized
INFO - 2018-08-03 01:34:55 --> URI Class Initialized
INFO - 2018-08-03 01:34:55 --> Router Class Initialized
INFO - 2018-08-03 01:34:55 --> Output Class Initialized
INFO - 2018-08-03 01:34:55 --> Security Class Initialized
DEBUG - 2018-08-03 01:34:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 01:34:55 --> Input Class Initialized
INFO - 2018-08-03 01:34:55 --> Language Class Initialized
INFO - 2018-08-03 01:34:55 --> Language Class Initialized
INFO - 2018-08-03 01:34:55 --> Config Class Initialized
INFO - 2018-08-03 01:34:55 --> Loader Class Initialized
DEBUG - 2018-08-03 01:34:55 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-03 01:34:55 --> Helper loaded: url_helper
INFO - 2018-08-03 01:34:55 --> Helper loaded: form_helper
INFO - 2018-08-03 01:34:55 --> Helper loaded: date_helper
INFO - 2018-08-03 01:34:55 --> Helper loaded: util_helper
INFO - 2018-08-03 01:34:55 --> Helper loaded: text_helper
INFO - 2018-08-03 01:34:55 --> Helper loaded: string_helper
INFO - 2018-08-03 01:34:55 --> Database Driver Class Initialized
DEBUG - 2018-08-03 01:34:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 01:34:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-03 01:34:55 --> Email Class Initialized
INFO - 2018-08-03 01:34:55 --> Controller Class Initialized
DEBUG - 2018-08-03 01:34:55 --> Home MX_Controller Initialized
DEBUG - 2018-08-03 01:34:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-03 01:34:55 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-03 01:34:55 --> Login MX_Controller Initialized
INFO - 2018-08-03 01:34:55 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-03 01:34:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-03 01:34:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-03 01:34:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-08-03 01:34:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-08-03 01:34:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-08-03 01:34:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-08-03 01:34:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-08-03 01:34:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/search_page.php
INFO - 2018-08-03 01:34:56 --> Final output sent to browser
DEBUG - 2018-08-03 01:34:56 --> Total execution time: 0.5071
INFO - 2018-08-03 01:34:56 --> Config Class Initialized
INFO - 2018-08-03 01:34:56 --> Config Class Initialized
INFO - 2018-08-03 01:34:56 --> Hooks Class Initialized
INFO - 2018-08-03 01:34:56 --> Hooks Class Initialized
DEBUG - 2018-08-03 01:34:56 --> UTF-8 Support Enabled
DEBUG - 2018-08-03 01:34:56 --> UTF-8 Support Enabled
INFO - 2018-08-03 01:34:57 --> Utf8 Class Initialized
INFO - 2018-08-03 01:34:57 --> Utf8 Class Initialized
INFO - 2018-08-03 01:34:57 --> URI Class Initialized
INFO - 2018-08-03 01:34:57 --> URI Class Initialized
INFO - 2018-08-03 01:34:57 --> Router Class Initialized
INFO - 2018-08-03 01:34:57 --> Router Class Initialized
INFO - 2018-08-03 01:34:57 --> Output Class Initialized
INFO - 2018-08-03 01:34:57 --> Output Class Initialized
INFO - 2018-08-03 01:34:57 --> Security Class Initialized
INFO - 2018-08-03 01:34:57 --> Security Class Initialized
DEBUG - 2018-08-03 01:34:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-08-03 01:34:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 01:34:57 --> Input Class Initialized
INFO - 2018-08-03 01:34:57 --> Input Class Initialized
INFO - 2018-08-03 01:34:57 --> Language Class Initialized
INFO - 2018-08-03 01:34:57 --> Language Class Initialized
INFO - 2018-08-03 01:34:57 --> Config Class Initialized
INFO - 2018-08-03 01:34:57 --> Language Class Initialized
INFO - 2018-08-03 01:34:57 --> Loader Class Initialized
ERROR - 2018-08-03 01:34:57 --> 404 Page Not Found: /index
DEBUG - 2018-08-03 01:34:57 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-03 01:34:57 --> Config Class Initialized
INFO - 2018-08-03 01:34:57 --> Hooks Class Initialized
INFO - 2018-08-03 01:34:57 --> Helper loaded: url_helper
DEBUG - 2018-08-03 01:34:57 --> UTF-8 Support Enabled
INFO - 2018-08-03 01:34:57 --> Helper loaded: form_helper
INFO - 2018-08-03 01:34:57 --> Utf8 Class Initialized
INFO - 2018-08-03 01:34:57 --> Helper loaded: date_helper
INFO - 2018-08-03 01:34:57 --> Helper loaded: util_helper
INFO - 2018-08-03 01:34:57 --> URI Class Initialized
INFO - 2018-08-03 01:34:57 --> Router Class Initialized
INFO - 2018-08-03 01:34:57 --> Helper loaded: text_helper
INFO - 2018-08-03 01:34:57 --> Output Class Initialized
INFO - 2018-08-03 01:34:57 --> Helper loaded: string_helper
INFO - 2018-08-03 01:34:57 --> Security Class Initialized
INFO - 2018-08-03 01:34:57 --> Database Driver Class Initialized
DEBUG - 2018-08-03 01:34:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-08-03 01:34:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 01:34:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-03 01:34:57 --> Input Class Initialized
INFO - 2018-08-03 01:34:57 --> Language Class Initialized
INFO - 2018-08-03 01:34:57 --> Email Class Initialized
INFO - 2018-08-03 01:34:57 --> Controller Class Initialized
ERROR - 2018-08-03 01:34:57 --> 404 Page Not Found: /index
DEBUG - 2018-08-03 01:34:57 --> Home MX_Controller Initialized
INFO - 2018-08-03 01:34:57 --> Config Class Initialized
INFO - 2018-08-03 01:34:57 --> Hooks Class Initialized
DEBUG - 2018-08-03 01:34:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-03 01:34:57 --> UTF-8 Support Enabled
DEBUG - 2018-08-03 01:34:57 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
INFO - 2018-08-03 01:34:57 --> Utf8 Class Initialized
DEBUG - 2018-08-03 01:34:57 --> Login MX_Controller Initialized
INFO - 2018-08-03 01:34:57 --> URI Class Initialized
INFO - 2018-08-03 01:34:57 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-03 01:34:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-08-03 01:34:57 --> Router Class Initialized
DEBUG - 2018-08-03 01:34:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-03 01:34:57 --> Output Class Initialized
INFO - 2018-08-03 01:34:57 --> Security Class Initialized
DEBUG - 2018-08-03 01:34:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 01:34:57 --> Input Class Initialized
INFO - 2018-08-03 01:34:57 --> Language Class Initialized
ERROR - 2018-08-03 01:34:57 --> 404 Page Not Found: /index
INFO - 2018-08-03 01:38:33 --> Config Class Initialized
INFO - 2018-08-03 01:38:33 --> Hooks Class Initialized
DEBUG - 2018-08-03 01:38:33 --> UTF-8 Support Enabled
INFO - 2018-08-03 01:38:33 --> Utf8 Class Initialized
INFO - 2018-08-03 01:38:33 --> URI Class Initialized
INFO - 2018-08-03 01:38:33 --> Router Class Initialized
INFO - 2018-08-03 01:38:33 --> Output Class Initialized
INFO - 2018-08-03 01:38:33 --> Security Class Initialized
DEBUG - 2018-08-03 01:38:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 01:38:33 --> Input Class Initialized
INFO - 2018-08-03 01:38:33 --> Language Class Initialized
INFO - 2018-08-03 01:38:33 --> Language Class Initialized
INFO - 2018-08-03 01:38:33 --> Config Class Initialized
INFO - 2018-08-03 01:38:33 --> Loader Class Initialized
DEBUG - 2018-08-03 01:38:33 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-03 01:38:33 --> Helper loaded: url_helper
INFO - 2018-08-03 01:38:33 --> Helper loaded: form_helper
INFO - 2018-08-03 01:38:33 --> Helper loaded: date_helper
INFO - 2018-08-03 01:38:33 --> Helper loaded: util_helper
INFO - 2018-08-03 01:38:33 --> Helper loaded: text_helper
INFO - 2018-08-03 01:38:33 --> Helper loaded: string_helper
INFO - 2018-08-03 01:38:33 --> Database Driver Class Initialized
DEBUG - 2018-08-03 01:38:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 01:38:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-03 01:38:33 --> Email Class Initialized
INFO - 2018-08-03 01:38:33 --> Controller Class Initialized
DEBUG - 2018-08-03 01:38:33 --> Home MX_Controller Initialized
DEBUG - 2018-08-03 01:38:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-03 01:38:33 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-03 01:38:33 --> Login MX_Controller Initialized
INFO - 2018-08-03 01:38:33 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-03 01:38:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-03 01:38:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-03 01:38:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-08-03 01:38:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-08-03 01:38:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-08-03 01:38:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-08-03 01:38:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-08-03 01:38:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/search_page.php
INFO - 2018-08-03 01:38:33 --> Final output sent to browser
DEBUG - 2018-08-03 01:38:33 --> Total execution time: 0.4917
INFO - 2018-08-03 01:38:34 --> Config Class Initialized
INFO - 2018-08-03 01:38:34 --> Hooks Class Initialized
DEBUG - 2018-08-03 01:38:34 --> UTF-8 Support Enabled
INFO - 2018-08-03 01:38:34 --> Utf8 Class Initialized
INFO - 2018-08-03 01:38:34 --> Config Class Initialized
INFO - 2018-08-03 01:38:34 --> Hooks Class Initialized
INFO - 2018-08-03 01:38:34 --> URI Class Initialized
DEBUG - 2018-08-03 01:38:34 --> UTF-8 Support Enabled
INFO - 2018-08-03 01:38:34 --> Router Class Initialized
INFO - 2018-08-03 01:38:34 --> Utf8 Class Initialized
INFO - 2018-08-03 01:38:34 --> Output Class Initialized
INFO - 2018-08-03 01:38:34 --> URI Class Initialized
INFO - 2018-08-03 01:38:34 --> Router Class Initialized
INFO - 2018-08-03 01:38:34 --> Output Class Initialized
INFO - 2018-08-03 01:38:34 --> Security Class Initialized
DEBUG - 2018-08-03 01:38:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 01:38:34 --> Input Class Initialized
INFO - 2018-08-03 01:38:34 --> Security Class Initialized
INFO - 2018-08-03 01:38:34 --> Language Class Initialized
INFO - 2018-08-03 01:38:34 --> Language Class Initialized
DEBUG - 2018-08-03 01:38:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 01:38:34 --> Config Class Initialized
INFO - 2018-08-03 01:38:34 --> Loader Class Initialized
DEBUG - 2018-08-03 01:38:34 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-03 01:38:34 --> Input Class Initialized
INFO - 2018-08-03 01:38:34 --> Helper loaded: url_helper
INFO - 2018-08-03 01:38:34 --> Language Class Initialized
INFO - 2018-08-03 01:38:34 --> Helper loaded: form_helper
ERROR - 2018-08-03 01:38:34 --> 404 Page Not Found: /index
INFO - 2018-08-03 01:38:34 --> Helper loaded: date_helper
INFO - 2018-08-03 01:38:34 --> Helper loaded: util_helper
INFO - 2018-08-03 01:38:34 --> Config Class Initialized
INFO - 2018-08-03 01:38:34 --> Hooks Class Initialized
INFO - 2018-08-03 01:38:34 --> Helper loaded: text_helper
INFO - 2018-08-03 01:38:34 --> Helper loaded: string_helper
DEBUG - 2018-08-03 01:38:34 --> UTF-8 Support Enabled
INFO - 2018-08-03 01:38:34 --> Utf8 Class Initialized
INFO - 2018-08-03 01:38:34 --> Database Driver Class Initialized
INFO - 2018-08-03 01:38:34 --> URI Class Initialized
DEBUG - 2018-08-03 01:38:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 01:38:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-03 01:38:34 --> Router Class Initialized
INFO - 2018-08-03 01:38:34 --> Output Class Initialized
INFO - 2018-08-03 01:38:34 --> Email Class Initialized
INFO - 2018-08-03 01:38:34 --> Controller Class Initialized
INFO - 2018-08-03 01:38:34 --> Security Class Initialized
DEBUG - 2018-08-03 01:38:34 --> Home MX_Controller Initialized
DEBUG - 2018-08-03 01:38:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 01:38:34 --> Input Class Initialized
DEBUG - 2018-08-03 01:38:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-08-03 01:38:34 --> Language Class Initialized
DEBUG - 2018-08-03 01:38:34 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-03 01:38:34 --> Login MX_Controller Initialized
ERROR - 2018-08-03 01:38:34 --> 404 Page Not Found: /index
INFO - 2018-08-03 01:38:34 --> Language file loaded: language/english/data_lang.php
INFO - 2018-08-03 01:38:34 --> Config Class Initialized
DEBUG - 2018-08-03 01:38:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-08-03 01:38:34 --> Hooks Class Initialized
DEBUG - 2018-08-03 01:38:34 --> UTF-8 Support Enabled
DEBUG - 2018-08-03 01:38:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-03 01:38:34 --> Utf8 Class Initialized
INFO - 2018-08-03 01:38:34 --> URI Class Initialized
INFO - 2018-08-03 01:38:34 --> Router Class Initialized
INFO - 2018-08-03 01:38:34 --> Output Class Initialized
INFO - 2018-08-03 01:38:34 --> Security Class Initialized
DEBUG - 2018-08-03 01:38:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 01:38:34 --> Input Class Initialized
INFO - 2018-08-03 01:38:34 --> Language Class Initialized
ERROR - 2018-08-03 01:38:34 --> 404 Page Not Found: /index
INFO - 2018-08-03 01:40:49 --> Config Class Initialized
INFO - 2018-08-03 01:40:49 --> Hooks Class Initialized
DEBUG - 2018-08-03 01:40:49 --> UTF-8 Support Enabled
INFO - 2018-08-03 01:40:49 --> Utf8 Class Initialized
INFO - 2018-08-03 01:40:49 --> URI Class Initialized
INFO - 2018-08-03 01:40:49 --> Router Class Initialized
INFO - 2018-08-03 01:40:49 --> Output Class Initialized
INFO - 2018-08-03 01:40:49 --> Security Class Initialized
DEBUG - 2018-08-03 01:40:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 01:40:50 --> Input Class Initialized
INFO - 2018-08-03 01:40:50 --> Language Class Initialized
INFO - 2018-08-03 01:40:50 --> Language Class Initialized
INFO - 2018-08-03 01:40:50 --> Config Class Initialized
INFO - 2018-08-03 01:40:50 --> Loader Class Initialized
DEBUG - 2018-08-03 01:40:50 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-03 01:40:50 --> Helper loaded: url_helper
INFO - 2018-08-03 01:40:50 --> Helper loaded: form_helper
INFO - 2018-08-03 01:40:50 --> Helper loaded: date_helper
INFO - 2018-08-03 01:40:50 --> Helper loaded: util_helper
INFO - 2018-08-03 01:40:50 --> Helper loaded: text_helper
INFO - 2018-08-03 01:40:50 --> Helper loaded: string_helper
INFO - 2018-08-03 01:40:50 --> Database Driver Class Initialized
DEBUG - 2018-08-03 01:40:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 01:40:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-03 01:40:50 --> Email Class Initialized
INFO - 2018-08-03 01:40:50 --> Controller Class Initialized
DEBUG - 2018-08-03 01:40:50 --> Home MX_Controller Initialized
DEBUG - 2018-08-03 01:40:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-03 01:40:50 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-03 01:40:50 --> Login MX_Controller Initialized
INFO - 2018-08-03 01:40:50 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-03 01:40:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-03 01:40:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-03 01:40:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-08-03 01:40:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-08-03 01:40:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-08-03 01:40:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-08-03 01:40:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-08-03 01:40:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/search_page.php
INFO - 2018-08-03 01:40:50 --> Final output sent to browser
DEBUG - 2018-08-03 01:40:50 --> Total execution time: 0.4974
INFO - 2018-08-03 01:40:51 --> Config Class Initialized
INFO - 2018-08-03 01:40:51 --> Hooks Class Initialized
INFO - 2018-08-03 01:40:51 --> Config Class Initialized
INFO - 2018-08-03 01:40:51 --> Hooks Class Initialized
DEBUG - 2018-08-03 01:40:51 --> UTF-8 Support Enabled
INFO - 2018-08-03 01:40:51 --> Utf8 Class Initialized
DEBUG - 2018-08-03 01:40:51 --> UTF-8 Support Enabled
INFO - 2018-08-03 01:40:51 --> Utf8 Class Initialized
INFO - 2018-08-03 01:40:51 --> URI Class Initialized
INFO - 2018-08-03 01:40:51 --> URI Class Initialized
INFO - 2018-08-03 01:40:51 --> Router Class Initialized
INFO - 2018-08-03 01:40:51 --> Router Class Initialized
INFO - 2018-08-03 01:40:51 --> Output Class Initialized
INFO - 2018-08-03 01:40:51 --> Output Class Initialized
INFO - 2018-08-03 01:40:51 --> Security Class Initialized
INFO - 2018-08-03 01:40:51 --> Security Class Initialized
DEBUG - 2018-08-03 01:40:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-08-03 01:40:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 01:40:51 --> Input Class Initialized
INFO - 2018-08-03 01:40:51 --> Input Class Initialized
INFO - 2018-08-03 01:40:51 --> Language Class Initialized
ERROR - 2018-08-03 01:40:51 --> 404 Page Not Found: /index
INFO - 2018-08-03 01:40:51 --> Config Class Initialized
INFO - 2018-08-03 01:40:52 --> Hooks Class Initialized
DEBUG - 2018-08-03 01:40:52 --> UTF-8 Support Enabled
INFO - 2018-08-03 01:40:52 --> Language Class Initialized
INFO - 2018-08-03 01:40:52 --> Utf8 Class Initialized
INFO - 2018-08-03 01:40:52 --> URI Class Initialized
INFO - 2018-08-03 01:40:52 --> Router Class Initialized
INFO - 2018-08-03 01:40:52 --> Language Class Initialized
INFO - 2018-08-03 01:40:52 --> Output Class Initialized
INFO - 2018-08-03 01:40:52 --> Security Class Initialized
DEBUG - 2018-08-03 01:40:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 01:40:52 --> Input Class Initialized
INFO - 2018-08-03 01:40:52 --> Language Class Initialized
ERROR - 2018-08-03 01:40:52 --> 404 Page Not Found: /index
INFO - 2018-08-03 01:40:52 --> Config Class Initialized
INFO - 2018-08-03 01:40:52 --> Config Class Initialized
INFO - 2018-08-03 01:40:52 --> Hooks Class Initialized
INFO - 2018-08-03 01:40:52 --> Loader Class Initialized
DEBUG - 2018-08-03 01:40:52 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
DEBUG - 2018-08-03 01:40:52 --> UTF-8 Support Enabled
INFO - 2018-08-03 01:40:52 --> Utf8 Class Initialized
INFO - 2018-08-03 01:40:52 --> Helper loaded: url_helper
INFO - 2018-08-03 01:40:52 --> URI Class Initialized
INFO - 2018-08-03 01:40:52 --> Helper loaded: form_helper
INFO - 2018-08-03 01:40:52 --> Router Class Initialized
INFO - 2018-08-03 01:40:52 --> Helper loaded: date_helper
INFO - 2018-08-03 01:40:52 --> Helper loaded: util_helper
INFO - 2018-08-03 01:40:52 --> Output Class Initialized
INFO - 2018-08-03 01:40:52 --> Security Class Initialized
INFO - 2018-08-03 01:40:52 --> Helper loaded: text_helper
INFO - 2018-08-03 01:40:52 --> Helper loaded: string_helper
DEBUG - 2018-08-03 01:40:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 01:40:52 --> Input Class Initialized
INFO - 2018-08-03 01:40:52 --> Database Driver Class Initialized
INFO - 2018-08-03 01:40:52 --> Language Class Initialized
DEBUG - 2018-08-03 01:40:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 01:40:52 --> Session: Class initialized using 'files' driver.
ERROR - 2018-08-03 01:40:52 --> 404 Page Not Found: /index
INFO - 2018-08-03 01:40:52 --> Email Class Initialized
INFO - 2018-08-03 01:40:52 --> Controller Class Initialized
DEBUG - 2018-08-03 01:40:52 --> Home MX_Controller Initialized
DEBUG - 2018-08-03 01:40:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-03 01:40:52 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-03 01:40:52 --> Login MX_Controller Initialized
INFO - 2018-08-03 01:40:52 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-03 01:40:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-03 01:40:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-03 01:40:54 --> Config Class Initialized
INFO - 2018-08-03 01:40:54 --> Hooks Class Initialized
DEBUG - 2018-08-03 01:40:54 --> UTF-8 Support Enabled
INFO - 2018-08-03 01:40:54 --> Utf8 Class Initialized
INFO - 2018-08-03 01:40:54 --> URI Class Initialized
INFO - 2018-08-03 01:40:54 --> Router Class Initialized
INFO - 2018-08-03 01:40:54 --> Output Class Initialized
INFO - 2018-08-03 01:40:54 --> Security Class Initialized
DEBUG - 2018-08-03 01:40:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 01:40:54 --> Input Class Initialized
INFO - 2018-08-03 01:40:54 --> Language Class Initialized
INFO - 2018-08-03 01:40:54 --> Language Class Initialized
INFO - 2018-08-03 01:40:54 --> Config Class Initialized
INFO - 2018-08-03 01:40:54 --> Loader Class Initialized
DEBUG - 2018-08-03 01:40:54 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-03 01:40:54 --> Helper loaded: url_helper
INFO - 2018-08-03 01:40:54 --> Helper loaded: form_helper
INFO - 2018-08-03 01:40:54 --> Helper loaded: date_helper
INFO - 2018-08-03 01:40:54 --> Helper loaded: util_helper
INFO - 2018-08-03 01:40:54 --> Helper loaded: text_helper
INFO - 2018-08-03 01:40:54 --> Helper loaded: string_helper
INFO - 2018-08-03 01:40:54 --> Database Driver Class Initialized
DEBUG - 2018-08-03 01:40:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 01:40:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-03 01:40:54 --> Email Class Initialized
INFO - 2018-08-03 01:40:54 --> Controller Class Initialized
DEBUG - 2018-08-03 01:40:54 --> Home MX_Controller Initialized
DEBUG - 2018-08-03 01:40:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-03 01:40:54 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-03 01:40:54 --> Login MX_Controller Initialized
INFO - 2018-08-03 01:40:54 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-03 01:40:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-03 01:40:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-03 01:40:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-08-03 01:40:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-08-03 01:40:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-08-03 01:40:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-08-03 01:40:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-08-03 01:40:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/search_page.php
INFO - 2018-08-03 01:40:55 --> Final output sent to browser
DEBUG - 2018-08-03 01:40:55 --> Total execution time: 0.5636
INFO - 2018-08-03 01:40:55 --> Config Class Initialized
INFO - 2018-08-03 01:40:55 --> Hooks Class Initialized
INFO - 2018-08-03 01:40:55 --> Config Class Initialized
INFO - 2018-08-03 01:40:55 --> Hooks Class Initialized
DEBUG - 2018-08-03 01:40:55 --> UTF-8 Support Enabled
INFO - 2018-08-03 01:40:55 --> Utf8 Class Initialized
DEBUG - 2018-08-03 01:40:55 --> UTF-8 Support Enabled
INFO - 2018-08-03 01:40:55 --> Utf8 Class Initialized
INFO - 2018-08-03 01:40:55 --> URI Class Initialized
INFO - 2018-08-03 01:40:55 --> URI Class Initialized
INFO - 2018-08-03 01:40:55 --> Router Class Initialized
INFO - 2018-08-03 01:40:55 --> Router Class Initialized
INFO - 2018-08-03 01:40:55 --> Output Class Initialized
INFO - 2018-08-03 01:40:55 --> Security Class Initialized
DEBUG - 2018-08-03 01:40:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 01:40:55 --> Input Class Initialized
INFO - 2018-08-03 01:40:55 --> Language Class Initialized
ERROR - 2018-08-03 01:40:55 --> 404 Page Not Found: /index
INFO - 2018-08-03 01:40:55 --> Config Class Initialized
INFO - 2018-08-03 01:40:55 --> Hooks Class Initialized
DEBUG - 2018-08-03 01:40:55 --> UTF-8 Support Enabled
INFO - 2018-08-03 01:40:55 --> Output Class Initialized
INFO - 2018-08-03 01:40:55 --> Utf8 Class Initialized
INFO - 2018-08-03 01:40:55 --> Security Class Initialized
INFO - 2018-08-03 01:40:55 --> URI Class Initialized
DEBUG - 2018-08-03 01:40:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 01:40:55 --> Input Class Initialized
INFO - 2018-08-03 01:40:55 --> Router Class Initialized
INFO - 2018-08-03 01:40:55 --> Output Class Initialized
INFO - 2018-08-03 01:40:55 --> Language Class Initialized
INFO - 2018-08-03 01:40:55 --> Language Class Initialized
INFO - 2018-08-03 01:40:55 --> Security Class Initialized
INFO - 2018-08-03 01:40:55 --> Config Class Initialized
DEBUG - 2018-08-03 01:40:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 01:40:55 --> Input Class Initialized
INFO - 2018-08-03 01:40:55 --> Loader Class Initialized
INFO - 2018-08-03 01:40:55 --> Language Class Initialized
DEBUG - 2018-08-03 01:40:55 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-03 01:40:55 --> Helper loaded: url_helper
ERROR - 2018-08-03 01:40:55 --> 404 Page Not Found: /index
INFO - 2018-08-03 01:40:56 --> Helper loaded: form_helper
INFO - 2018-08-03 01:40:56 --> Config Class Initialized
INFO - 2018-08-03 01:40:56 --> Hooks Class Initialized
INFO - 2018-08-03 01:40:56 --> Helper loaded: date_helper
DEBUG - 2018-08-03 01:40:56 --> UTF-8 Support Enabled
INFO - 2018-08-03 01:40:56 --> Utf8 Class Initialized
INFO - 2018-08-03 01:40:56 --> URI Class Initialized
INFO - 2018-08-03 01:40:56 --> Router Class Initialized
INFO - 2018-08-03 01:40:56 --> Helper loaded: util_helper
INFO - 2018-08-03 01:40:56 --> Output Class Initialized
INFO - 2018-08-03 01:40:56 --> Security Class Initialized
DEBUG - 2018-08-03 01:40:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 01:40:56 --> Input Class Initialized
INFO - 2018-08-03 01:40:56 --> Language Class Initialized
ERROR - 2018-08-03 01:40:56 --> 404 Page Not Found: /index
INFO - 2018-08-03 01:40:56 --> Helper loaded: text_helper
INFO - 2018-08-03 01:40:56 --> Helper loaded: string_helper
INFO - 2018-08-03 01:40:56 --> Database Driver Class Initialized
DEBUG - 2018-08-03 01:40:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 01:40:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-03 01:40:56 --> Email Class Initialized
INFO - 2018-08-03 01:40:56 --> Controller Class Initialized
DEBUG - 2018-08-03 01:40:56 --> Home MX_Controller Initialized
DEBUG - 2018-08-03 01:40:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-03 01:40:56 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-03 01:40:56 --> Login MX_Controller Initialized
INFO - 2018-08-03 01:40:56 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-03 01:40:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-03 01:40:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-03 01:41:25 --> Config Class Initialized
INFO - 2018-08-03 01:41:25 --> Hooks Class Initialized
DEBUG - 2018-08-03 01:41:25 --> UTF-8 Support Enabled
INFO - 2018-08-03 01:41:25 --> Utf8 Class Initialized
INFO - 2018-08-03 01:41:25 --> URI Class Initialized
DEBUG - 2018-08-03 01:41:25 --> No URI present. Default controller set.
INFO - 2018-08-03 01:41:25 --> Router Class Initialized
INFO - 2018-08-03 01:41:25 --> Output Class Initialized
INFO - 2018-08-03 01:41:25 --> Security Class Initialized
DEBUG - 2018-08-03 01:41:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 01:41:25 --> Input Class Initialized
INFO - 2018-08-03 01:41:25 --> Language Class Initialized
INFO - 2018-08-03 01:41:25 --> Language Class Initialized
INFO - 2018-08-03 01:41:25 --> Config Class Initialized
INFO - 2018-08-03 01:41:25 --> Loader Class Initialized
DEBUG - 2018-08-03 01:41:25 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-03 01:41:25 --> Helper loaded: url_helper
INFO - 2018-08-03 01:41:25 --> Helper loaded: form_helper
INFO - 2018-08-03 01:41:25 --> Helper loaded: date_helper
INFO - 2018-08-03 01:41:25 --> Helper loaded: util_helper
INFO - 2018-08-03 01:41:25 --> Helper loaded: text_helper
INFO - 2018-08-03 01:41:25 --> Helper loaded: string_helper
INFO - 2018-08-03 01:41:25 --> Database Driver Class Initialized
DEBUG - 2018-08-03 01:41:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 01:41:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-03 01:41:25 --> Email Class Initialized
INFO - 2018-08-03 01:41:25 --> Controller Class Initialized
DEBUG - 2018-08-03 01:41:25 --> Home MX_Controller Initialized
DEBUG - 2018-08-03 01:41:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-03 01:41:25 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-03 01:41:25 --> Login MX_Controller Initialized
INFO - 2018-08-03 01:41:25 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-03 01:41:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-03 01:41:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-03 01:41:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-08-03 01:41:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-08-03 01:41:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-08-03 01:41:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-08-03 01:41:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-08-03 01:41:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-08-03 01:41:25 --> Final output sent to browser
DEBUG - 2018-08-03 01:41:25 --> Total execution time: 0.4978
INFO - 2018-08-03 01:41:26 --> Config Class Initialized
INFO - 2018-08-03 01:41:26 --> Hooks Class Initialized
DEBUG - 2018-08-03 01:41:26 --> UTF-8 Support Enabled
INFO - 2018-08-03 01:41:26 --> Utf8 Class Initialized
INFO - 2018-08-03 01:41:26 --> URI Class Initialized
INFO - 2018-08-03 01:41:26 --> Config Class Initialized
INFO - 2018-08-03 01:41:26 --> Hooks Class Initialized
INFO - 2018-08-03 01:41:26 --> Router Class Initialized
INFO - 2018-08-03 01:41:26 --> Output Class Initialized
DEBUG - 2018-08-03 01:41:26 --> UTF-8 Support Enabled
INFO - 2018-08-03 01:41:26 --> Utf8 Class Initialized
INFO - 2018-08-03 01:41:26 --> Security Class Initialized
INFO - 2018-08-03 01:41:26 --> URI Class Initialized
DEBUG - 2018-08-03 01:41:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 01:41:26 --> Input Class Initialized
INFO - 2018-08-03 01:41:26 --> Router Class Initialized
INFO - 2018-08-03 01:41:26 --> Output Class Initialized
INFO - 2018-08-03 01:41:26 --> Language Class Initialized
INFO - 2018-08-03 01:41:26 --> Security Class Initialized
DEBUG - 2018-08-03 01:41:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 01:41:26 --> Input Class Initialized
ERROR - 2018-08-03 01:41:26 --> 404 Page Not Found: /index
INFO - 2018-08-03 01:41:26 --> Language Class Initialized
INFO - 2018-08-03 01:41:26 --> Config Class Initialized
INFO - 2018-08-03 01:41:26 --> Hooks Class Initialized
INFO - 2018-08-03 01:41:26 --> Language Class Initialized
DEBUG - 2018-08-03 01:41:26 --> UTF-8 Support Enabled
INFO - 2018-08-03 01:41:26 --> Utf8 Class Initialized
INFO - 2018-08-03 01:41:26 --> URI Class Initialized
INFO - 2018-08-03 01:41:26 --> Router Class Initialized
INFO - 2018-08-03 01:41:26 --> Config Class Initialized
INFO - 2018-08-03 01:41:26 --> Output Class Initialized
INFO - 2018-08-03 01:41:26 --> Security Class Initialized
INFO - 2018-08-03 01:41:26 --> Loader Class Initialized
DEBUG - 2018-08-03 01:41:26 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
DEBUG - 2018-08-03 01:41:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 01:41:26 --> Input Class Initialized
INFO - 2018-08-03 01:41:26 --> Helper loaded: url_helper
INFO - 2018-08-03 01:41:26 --> Language Class Initialized
INFO - 2018-08-03 01:41:26 --> Helper loaded: form_helper
INFO - 2018-08-03 01:41:26 --> Helper loaded: date_helper
ERROR - 2018-08-03 01:41:26 --> 404 Page Not Found: /index
INFO - 2018-08-03 01:41:26 --> Helper loaded: util_helper
INFO - 2018-08-03 01:41:26 --> Config Class Initialized
INFO - 2018-08-03 01:41:26 --> Hooks Class Initialized
INFO - 2018-08-03 01:41:26 --> Helper loaded: text_helper
DEBUG - 2018-08-03 01:41:26 --> UTF-8 Support Enabled
INFO - 2018-08-03 01:41:26 --> Utf8 Class Initialized
INFO - 2018-08-03 01:41:26 --> Helper loaded: string_helper
INFO - 2018-08-03 01:41:27 --> URI Class Initialized
INFO - 2018-08-03 01:41:27 --> Database Driver Class Initialized
INFO - 2018-08-03 01:41:27 --> Router Class Initialized
DEBUG - 2018-08-03 01:41:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 01:41:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-03 01:41:27 --> Email Class Initialized
INFO - 2018-08-03 01:41:27 --> Output Class Initialized
INFO - 2018-08-03 01:41:27 --> Controller Class Initialized
INFO - 2018-08-03 01:41:27 --> Security Class Initialized
DEBUG - 2018-08-03 01:41:27 --> Home MX_Controller Initialized
DEBUG - 2018-08-03 01:41:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 01:41:27 --> Input Class Initialized
DEBUG - 2018-08-03 01:41:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-08-03 01:41:27 --> Language Class Initialized
DEBUG - 2018-08-03 01:41:27 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-03 01:41:27 --> Login MX_Controller Initialized
ERROR - 2018-08-03 01:41:27 --> 404 Page Not Found: /index
INFO - 2018-08-03 01:41:27 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-03 01:41:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-03 01:41:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-03 01:41:29 --> Config Class Initialized
INFO - 2018-08-03 01:41:29 --> Hooks Class Initialized
DEBUG - 2018-08-03 01:41:29 --> UTF-8 Support Enabled
INFO - 2018-08-03 01:41:29 --> Utf8 Class Initialized
INFO - 2018-08-03 01:41:29 --> URI Class Initialized
INFO - 2018-08-03 01:41:29 --> Router Class Initialized
INFO - 2018-08-03 01:41:29 --> Output Class Initialized
INFO - 2018-08-03 01:41:29 --> Security Class Initialized
DEBUG - 2018-08-03 01:41:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 01:41:29 --> Input Class Initialized
INFO - 2018-08-03 01:41:29 --> Language Class Initialized
INFO - 2018-08-03 01:41:29 --> Language Class Initialized
INFO - 2018-08-03 01:41:29 --> Config Class Initialized
INFO - 2018-08-03 01:41:29 --> Loader Class Initialized
DEBUG - 2018-08-03 01:41:29 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-03 01:41:29 --> Helper loaded: url_helper
INFO - 2018-08-03 01:41:29 --> Helper loaded: form_helper
INFO - 2018-08-03 01:41:29 --> Helper loaded: date_helper
INFO - 2018-08-03 01:41:29 --> Helper loaded: util_helper
INFO - 2018-08-03 01:41:29 --> Helper loaded: text_helper
INFO - 2018-08-03 01:41:29 --> Helper loaded: string_helper
INFO - 2018-08-03 01:41:30 --> Database Driver Class Initialized
DEBUG - 2018-08-03 01:41:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 01:41:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-03 01:41:30 --> Email Class Initialized
INFO - 2018-08-03 01:41:30 --> Controller Class Initialized
DEBUG - 2018-08-03 01:41:30 --> Home MX_Controller Initialized
DEBUG - 2018-08-03 01:41:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-03 01:41:30 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-03 01:41:30 --> Login MX_Controller Initialized
INFO - 2018-08-03 01:41:30 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-03 01:41:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-03 01:41:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-03 01:41:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-08-03 01:41:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-08-03 01:41:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-08-03 01:41:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-08-03 01:41:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-08-03 01:41:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-08-03 01:41:30 --> Final output sent to browser
DEBUG - 2018-08-03 01:41:30 --> Total execution time: 0.5255
INFO - 2018-08-03 01:41:30 --> Config Class Initialized
INFO - 2018-08-03 01:41:30 --> Config Class Initialized
INFO - 2018-08-03 01:41:30 --> Hooks Class Initialized
INFO - 2018-08-03 01:41:30 --> Hooks Class Initialized
DEBUG - 2018-08-03 01:41:30 --> UTF-8 Support Enabled
DEBUG - 2018-08-03 01:41:30 --> UTF-8 Support Enabled
INFO - 2018-08-03 01:41:30 --> Config Class Initialized
INFO - 2018-08-03 01:41:30 --> Hooks Class Initialized
INFO - 2018-08-03 01:41:30 --> Utf8 Class Initialized
INFO - 2018-08-03 01:41:30 --> Utf8 Class Initialized
INFO - 2018-08-03 01:41:30 --> URI Class Initialized
INFO - 2018-08-03 01:41:30 --> URI Class Initialized
DEBUG - 2018-08-03 01:41:30 --> UTF-8 Support Enabled
INFO - 2018-08-03 01:41:30 --> Utf8 Class Initialized
INFO - 2018-08-03 01:41:30 --> Router Class Initialized
INFO - 2018-08-03 01:41:30 --> URI Class Initialized
INFO - 2018-08-03 01:41:30 --> Router Class Initialized
INFO - 2018-08-03 01:41:30 --> Output Class Initialized
INFO - 2018-08-03 01:41:31 --> Router Class Initialized
INFO - 2018-08-03 01:41:31 --> Output Class Initialized
INFO - 2018-08-03 01:41:31 --> Security Class Initialized
INFO - 2018-08-03 01:41:31 --> Output Class Initialized
INFO - 2018-08-03 01:41:31 --> Security Class Initialized
DEBUG - 2018-08-03 01:41:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 01:41:31 --> Security Class Initialized
DEBUG - 2018-08-03 01:41:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 01:41:31 --> Input Class Initialized
DEBUG - 2018-08-03 01:41:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 01:41:31 --> Input Class Initialized
INFO - 2018-08-03 01:41:31 --> Language Class Initialized
INFO - 2018-08-03 01:41:31 --> Language Class Initialized
ERROR - 2018-08-03 01:41:31 --> 404 Page Not Found: /index
INFO - 2018-08-03 01:41:31 --> Input Class Initialized
INFO - 2018-08-03 01:41:31 --> Language Class Initialized
ERROR - 2018-08-03 01:41:31 --> 404 Page Not Found: /index
INFO - 2018-08-03 01:41:31 --> Language Class Initialized
INFO - 2018-08-03 01:41:31 --> Config Class Initialized
INFO - 2018-08-03 01:41:31 --> Hooks Class Initialized
INFO - 2018-08-03 01:41:31 --> Config Class Initialized
DEBUG - 2018-08-03 01:41:31 --> UTF-8 Support Enabled
INFO - 2018-08-03 01:41:31 --> Loader Class Initialized
INFO - 2018-08-03 01:41:31 --> Utf8 Class Initialized
DEBUG - 2018-08-03 01:41:31 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-03 01:41:31 --> URI Class Initialized
INFO - 2018-08-03 01:41:31 --> Helper loaded: url_helper
INFO - 2018-08-03 01:41:31 --> Router Class Initialized
INFO - 2018-08-03 01:41:31 --> Helper loaded: form_helper
INFO - 2018-08-03 01:41:31 --> Output Class Initialized
INFO - 2018-08-03 01:41:31 --> Helper loaded: date_helper
INFO - 2018-08-03 01:41:31 --> Security Class Initialized
INFO - 2018-08-03 01:41:31 --> Helper loaded: util_helper
DEBUG - 2018-08-03 01:41:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 01:41:31 --> Input Class Initialized
INFO - 2018-08-03 01:41:31 --> Helper loaded: text_helper
INFO - 2018-08-03 01:41:31 --> Language Class Initialized
INFO - 2018-08-03 01:41:31 --> Helper loaded: string_helper
ERROR - 2018-08-03 01:41:31 --> 404 Page Not Found: /index
INFO - 2018-08-03 01:41:31 --> Database Driver Class Initialized
INFO - 2018-08-03 01:41:31 --> Config Class Initialized
INFO - 2018-08-03 01:41:31 --> Hooks Class Initialized
DEBUG - 2018-08-03 01:41:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 01:41:31 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-08-03 01:41:31 --> UTF-8 Support Enabled
INFO - 2018-08-03 01:41:31 --> Utf8 Class Initialized
INFO - 2018-08-03 01:41:31 --> Email Class Initialized
INFO - 2018-08-03 01:41:31 --> Controller Class Initialized
INFO - 2018-08-03 01:41:31 --> URI Class Initialized
DEBUG - 2018-08-03 01:41:31 --> Home MX_Controller Initialized
INFO - 2018-08-03 01:41:31 --> Router Class Initialized
DEBUG - 2018-08-03 01:41:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-08-03 01:41:31 --> Output Class Initialized
INFO - 2018-08-03 01:41:31 --> Security Class Initialized
DEBUG - 2018-08-03 01:41:31 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-03 01:41:31 --> Login MX_Controller Initialized
DEBUG - 2018-08-03 01:41:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 01:41:31 --> Language file loaded: language/english/data_lang.php
INFO - 2018-08-03 01:41:31 --> Input Class Initialized
DEBUG - 2018-08-03 01:41:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-03 01:41:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-03 01:41:31 --> Language Class Initialized
ERROR - 2018-08-03 01:41:31 --> 404 Page Not Found: /index
INFO - 2018-08-03 01:41:35 --> Config Class Initialized
INFO - 2018-08-03 01:41:35 --> Hooks Class Initialized
DEBUG - 2018-08-03 01:41:35 --> UTF-8 Support Enabled
INFO - 2018-08-03 01:41:35 --> Utf8 Class Initialized
INFO - 2018-08-03 01:41:35 --> URI Class Initialized
INFO - 2018-08-03 01:41:35 --> Router Class Initialized
INFO - 2018-08-03 01:41:35 --> Output Class Initialized
INFO - 2018-08-03 01:41:35 --> Security Class Initialized
DEBUG - 2018-08-03 01:41:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 01:41:35 --> Input Class Initialized
INFO - 2018-08-03 01:41:35 --> Language Class Initialized
INFO - 2018-08-03 01:41:35 --> Language Class Initialized
INFO - 2018-08-03 01:41:35 --> Config Class Initialized
INFO - 2018-08-03 01:41:35 --> Loader Class Initialized
DEBUG - 2018-08-03 01:41:35 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-03 01:41:35 --> Helper loaded: url_helper
INFO - 2018-08-03 01:41:35 --> Helper loaded: form_helper
INFO - 2018-08-03 01:41:35 --> Helper loaded: date_helper
INFO - 2018-08-03 01:41:35 --> Helper loaded: util_helper
INFO - 2018-08-03 01:41:35 --> Helper loaded: text_helper
INFO - 2018-08-03 01:41:35 --> Helper loaded: string_helper
INFO - 2018-08-03 01:41:35 --> Database Driver Class Initialized
DEBUG - 2018-08-03 01:41:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 01:41:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-03 01:41:35 --> Email Class Initialized
INFO - 2018-08-03 01:41:35 --> Controller Class Initialized
DEBUG - 2018-08-03 01:41:35 --> Home MX_Controller Initialized
DEBUG - 2018-08-03 01:41:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-03 01:41:35 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-03 01:41:35 --> Login MX_Controller Initialized
INFO - 2018-08-03 01:41:35 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-03 01:41:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-03 01:41:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-03 01:41:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-08-03 01:41:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-08-03 01:41:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-08-03 01:41:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-08-03 01:41:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-08-03 01:41:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-08-03 01:41:35 --> Final output sent to browser
DEBUG - 2018-08-03 01:41:35 --> Total execution time: 0.5174
INFO - 2018-08-03 01:41:36 --> Config Class Initialized
INFO - 2018-08-03 01:41:36 --> Config Class Initialized
INFO - 2018-08-03 01:41:36 --> Hooks Class Initialized
INFO - 2018-08-03 01:41:36 --> Hooks Class Initialized
DEBUG - 2018-08-03 01:41:36 --> UTF-8 Support Enabled
DEBUG - 2018-08-03 01:41:36 --> UTF-8 Support Enabled
INFO - 2018-08-03 01:41:36 --> Config Class Initialized
INFO - 2018-08-03 01:41:36 --> Hooks Class Initialized
INFO - 2018-08-03 01:41:36 --> Utf8 Class Initialized
INFO - 2018-08-03 01:41:36 --> Utf8 Class Initialized
INFO - 2018-08-03 01:41:36 --> URI Class Initialized
DEBUG - 2018-08-03 01:41:36 --> UTF-8 Support Enabled
INFO - 2018-08-03 01:41:36 --> URI Class Initialized
INFO - 2018-08-03 01:41:36 --> Utf8 Class Initialized
INFO - 2018-08-03 01:41:36 --> Router Class Initialized
INFO - 2018-08-03 01:41:36 --> URI Class Initialized
INFO - 2018-08-03 01:41:36 --> Output Class Initialized
INFO - 2018-08-03 01:41:36 --> Router Class Initialized
INFO - 2018-08-03 01:41:36 --> Security Class Initialized
INFO - 2018-08-03 01:41:36 --> Router Class Initialized
INFO - 2018-08-03 01:41:36 --> Output Class Initialized
DEBUG - 2018-08-03 01:41:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 01:41:36 --> Output Class Initialized
INFO - 2018-08-03 01:41:36 --> Security Class Initialized
INFO - 2018-08-03 01:41:36 --> Input Class Initialized
INFO - 2018-08-03 01:41:36 --> Security Class Initialized
DEBUG - 2018-08-03 01:41:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 01:41:36 --> Language Class Initialized
INFO - 2018-08-03 01:41:36 --> Input Class Initialized
DEBUG - 2018-08-03 01:41:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 01:41:36 --> Input Class Initialized
INFO - 2018-08-03 01:41:36 --> Language Class Initialized
ERROR - 2018-08-03 01:41:36 --> 404 Page Not Found: /index
INFO - 2018-08-03 01:41:36 --> Language Class Initialized
ERROR - 2018-08-03 01:41:36 --> 404 Page Not Found: /index
INFO - 2018-08-03 01:41:36 --> Language Class Initialized
INFO - 2018-08-03 01:41:36 --> Config Class Initialized
INFO - 2018-08-03 01:41:36 --> Hooks Class Initialized
INFO - 2018-08-03 01:41:36 --> Config Class Initialized
DEBUG - 2018-08-03 01:41:36 --> UTF-8 Support Enabled
INFO - 2018-08-03 01:41:36 --> Utf8 Class Initialized
INFO - 2018-08-03 01:41:36 --> URI Class Initialized
INFO - 2018-08-03 01:41:36 --> Router Class Initialized
INFO - 2018-08-03 01:41:36 --> Loader Class Initialized
DEBUG - 2018-08-03 01:41:36 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-03 01:41:36 --> Output Class Initialized
INFO - 2018-08-03 01:41:36 --> Helper loaded: url_helper
INFO - 2018-08-03 01:41:36 --> Security Class Initialized
DEBUG - 2018-08-03 01:41:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 01:41:36 --> Helper loaded: form_helper
INFO - 2018-08-03 01:41:36 --> Input Class Initialized
INFO - 2018-08-03 01:41:36 --> Helper loaded: date_helper
INFO - 2018-08-03 01:41:36 --> Language Class Initialized
INFO - 2018-08-03 01:41:36 --> Helper loaded: util_helper
INFO - 2018-08-03 01:41:36 --> Helper loaded: text_helper
ERROR - 2018-08-03 01:41:36 --> 404 Page Not Found: /index
INFO - 2018-08-03 01:41:36 --> Helper loaded: string_helper
INFO - 2018-08-03 01:41:36 --> Database Driver Class Initialized
INFO - 2018-08-03 01:41:36 --> Config Class Initialized
INFO - 2018-08-03 01:41:36 --> Hooks Class Initialized
DEBUG - 2018-08-03 01:41:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 01:41:36 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-08-03 01:41:36 --> UTF-8 Support Enabled
INFO - 2018-08-03 01:41:36 --> Utf8 Class Initialized
INFO - 2018-08-03 01:41:36 --> Email Class Initialized
INFO - 2018-08-03 01:41:36 --> Controller Class Initialized
INFO - 2018-08-03 01:41:36 --> URI Class Initialized
DEBUG - 2018-08-03 01:41:36 --> Home MX_Controller Initialized
INFO - 2018-08-03 01:41:36 --> Router Class Initialized
DEBUG - 2018-08-03 01:41:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-08-03 01:41:36 --> Output Class Initialized
INFO - 2018-08-03 01:41:37 --> Security Class Initialized
DEBUG - 2018-08-03 01:41:37 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-03 01:41:37 --> Login MX_Controller Initialized
DEBUG - 2018-08-03 01:41:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 01:41:37 --> Input Class Initialized
INFO - 2018-08-03 01:41:37 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-03 01:41:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-08-03 01:41:37 --> Language Class Initialized
DEBUG - 2018-08-03 01:41:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
ERROR - 2018-08-03 01:41:37 --> 404 Page Not Found: /index
INFO - 2018-08-03 01:41:48 --> Config Class Initialized
INFO - 2018-08-03 01:41:48 --> Hooks Class Initialized
DEBUG - 2018-08-03 01:41:48 --> UTF-8 Support Enabled
INFO - 2018-08-03 01:41:48 --> Utf8 Class Initialized
INFO - 2018-08-03 01:41:48 --> URI Class Initialized
INFO - 2018-08-03 01:41:48 --> Router Class Initialized
INFO - 2018-08-03 01:41:48 --> Output Class Initialized
INFO - 2018-08-03 01:41:48 --> Security Class Initialized
DEBUG - 2018-08-03 01:41:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 01:41:48 --> Input Class Initialized
INFO - 2018-08-03 01:41:48 --> Language Class Initialized
INFO - 2018-08-03 01:41:48 --> Language Class Initialized
INFO - 2018-08-03 01:41:48 --> Config Class Initialized
INFO - 2018-08-03 01:41:48 --> Loader Class Initialized
DEBUG - 2018-08-03 01:41:48 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-03 01:41:48 --> Helper loaded: url_helper
INFO - 2018-08-03 01:41:48 --> Helper loaded: form_helper
INFO - 2018-08-03 01:41:48 --> Helper loaded: date_helper
INFO - 2018-08-03 01:41:48 --> Helper loaded: util_helper
INFO - 2018-08-03 01:41:48 --> Helper loaded: text_helper
INFO - 2018-08-03 01:41:48 --> Helper loaded: string_helper
INFO - 2018-08-03 01:41:48 --> Database Driver Class Initialized
DEBUG - 2018-08-03 01:41:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 01:41:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-03 01:41:48 --> Email Class Initialized
INFO - 2018-08-03 01:41:48 --> Controller Class Initialized
DEBUG - 2018-08-03 01:41:48 --> Home MX_Controller Initialized
DEBUG - 2018-08-03 01:41:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-03 01:41:48 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-03 01:41:48 --> Login MX_Controller Initialized
INFO - 2018-08-03 01:41:48 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-03 01:41:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-03 01:41:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-03 01:41:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-08-03 01:41:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-08-03 01:41:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-08-03 01:41:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-08-03 01:41:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-08-03 01:41:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-08-03 01:41:48 --> Final output sent to browser
DEBUG - 2018-08-03 01:41:48 --> Total execution time: 0.4992
INFO - 2018-08-03 01:41:49 --> Config Class Initialized
INFO - 2018-08-03 01:41:49 --> Config Class Initialized
INFO - 2018-08-03 01:41:49 --> Hooks Class Initialized
INFO - 2018-08-03 01:41:49 --> Hooks Class Initialized
INFO - 2018-08-03 01:41:49 --> Config Class Initialized
INFO - 2018-08-03 01:41:49 --> Hooks Class Initialized
DEBUG - 2018-08-03 01:41:49 --> UTF-8 Support Enabled
DEBUG - 2018-08-03 01:41:49 --> UTF-8 Support Enabled
INFO - 2018-08-03 01:41:49 --> Utf8 Class Initialized
DEBUG - 2018-08-03 01:41:49 --> UTF-8 Support Enabled
INFO - 2018-08-03 01:41:49 --> Utf8 Class Initialized
INFO - 2018-08-03 01:41:49 --> Utf8 Class Initialized
INFO - 2018-08-03 01:41:49 --> URI Class Initialized
INFO - 2018-08-03 01:41:49 --> URI Class Initialized
INFO - 2018-08-03 01:41:49 --> URI Class Initialized
INFO - 2018-08-03 01:41:49 --> Router Class Initialized
INFO - 2018-08-03 01:41:49 --> Router Class Initialized
INFO - 2018-08-03 01:41:49 --> Output Class Initialized
INFO - 2018-08-03 01:41:49 --> Router Class Initialized
INFO - 2018-08-03 01:41:49 --> Output Class Initialized
INFO - 2018-08-03 01:41:49 --> Security Class Initialized
INFO - 2018-08-03 01:41:49 --> Output Class Initialized
INFO - 2018-08-03 01:41:49 --> Security Class Initialized
DEBUG - 2018-08-03 01:41:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 01:41:49 --> Input Class Initialized
INFO - 2018-08-03 01:41:49 --> Language Class Initialized
DEBUG - 2018-08-03 01:41:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 01:41:49 --> Security Class Initialized
INFO - 2018-08-03 01:41:49 --> Input Class Initialized
ERROR - 2018-08-03 01:41:49 --> 404 Page Not Found: /index
DEBUG - 2018-08-03 01:41:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 01:41:49 --> Language Class Initialized
ERROR - 2018-08-03 01:41:49 --> 404 Page Not Found: /index
INFO - 2018-08-03 01:41:49 --> Config Class Initialized
INFO - 2018-08-03 01:41:49 --> Hooks Class Initialized
DEBUG - 2018-08-03 01:41:49 --> UTF-8 Support Enabled
INFO - 2018-08-03 01:41:49 --> Utf8 Class Initialized
INFO - 2018-08-03 01:41:49 --> Input Class Initialized
INFO - 2018-08-03 01:41:49 --> URI Class Initialized
INFO - 2018-08-03 01:41:49 --> Language Class Initialized
INFO - 2018-08-03 01:41:49 --> Router Class Initialized
INFO - 2018-08-03 01:41:49 --> Output Class Initialized
INFO - 2018-08-03 01:41:49 --> Language Class Initialized
INFO - 2018-08-03 01:41:49 --> Config Class Initialized
INFO - 2018-08-03 01:41:49 --> Security Class Initialized
DEBUG - 2018-08-03 01:41:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 01:41:50 --> Loader Class Initialized
INFO - 2018-08-03 01:41:50 --> Input Class Initialized
DEBUG - 2018-08-03 01:41:50 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-03 01:41:50 --> Language Class Initialized
INFO - 2018-08-03 01:41:50 --> Helper loaded: url_helper
ERROR - 2018-08-03 01:41:50 --> 404 Page Not Found: /index
INFO - 2018-08-03 01:41:50 --> Helper loaded: form_helper
INFO - 2018-08-03 01:41:50 --> Helper loaded: date_helper
INFO - 2018-08-03 01:41:50 --> Config Class Initialized
INFO - 2018-08-03 01:41:50 --> Hooks Class Initialized
INFO - 2018-08-03 01:41:50 --> Helper loaded: util_helper
INFO - 2018-08-03 01:41:50 --> Helper loaded: text_helper
DEBUG - 2018-08-03 01:41:50 --> UTF-8 Support Enabled
INFO - 2018-08-03 01:41:50 --> Utf8 Class Initialized
INFO - 2018-08-03 01:41:50 --> Helper loaded: string_helper
INFO - 2018-08-03 01:41:50 --> URI Class Initialized
INFO - 2018-08-03 01:41:50 --> Database Driver Class Initialized
INFO - 2018-08-03 01:41:50 --> Router Class Initialized
DEBUG - 2018-08-03 01:41:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 01:41:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-03 01:41:50 --> Output Class Initialized
INFO - 2018-08-03 01:41:50 --> Security Class Initialized
INFO - 2018-08-03 01:41:50 --> Email Class Initialized
INFO - 2018-08-03 01:41:50 --> Controller Class Initialized
DEBUG - 2018-08-03 01:41:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-08-03 01:41:50 --> Home MX_Controller Initialized
INFO - 2018-08-03 01:41:50 --> Input Class Initialized
INFO - 2018-08-03 01:41:50 --> Language Class Initialized
DEBUG - 2018-08-03 01:41:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
ERROR - 2018-08-03 01:41:50 --> 404 Page Not Found: /index
DEBUG - 2018-08-03 01:41:50 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-03 01:41:50 --> Login MX_Controller Initialized
INFO - 2018-08-03 01:41:50 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-03 01:41:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-03 01:41:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-03 01:51:05 --> Config Class Initialized
INFO - 2018-08-03 01:51:05 --> Hooks Class Initialized
DEBUG - 2018-08-03 01:51:05 --> UTF-8 Support Enabled
INFO - 2018-08-03 01:51:05 --> Utf8 Class Initialized
INFO - 2018-08-03 01:51:05 --> URI Class Initialized
INFO - 2018-08-03 01:51:05 --> Router Class Initialized
INFO - 2018-08-03 01:51:05 --> Output Class Initialized
INFO - 2018-08-03 01:51:05 --> Security Class Initialized
DEBUG - 2018-08-03 01:51:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 01:51:05 --> Input Class Initialized
INFO - 2018-08-03 01:51:05 --> Language Class Initialized
INFO - 2018-08-03 01:51:05 --> Language Class Initialized
INFO - 2018-08-03 01:51:05 --> Config Class Initialized
INFO - 2018-08-03 01:51:05 --> Loader Class Initialized
DEBUG - 2018-08-03 01:51:05 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-03 01:51:05 --> Helper loaded: url_helper
INFO - 2018-08-03 01:51:05 --> Helper loaded: form_helper
INFO - 2018-08-03 01:51:05 --> Helper loaded: date_helper
INFO - 2018-08-03 01:51:05 --> Helper loaded: util_helper
INFO - 2018-08-03 01:51:05 --> Helper loaded: text_helper
INFO - 2018-08-03 01:51:05 --> Helper loaded: string_helper
INFO - 2018-08-03 01:51:05 --> Database Driver Class Initialized
DEBUG - 2018-08-03 01:51:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 01:51:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-03 01:51:05 --> Email Class Initialized
INFO - 2018-08-03 01:51:05 --> Controller Class Initialized
DEBUG - 2018-08-03 01:51:05 --> Home MX_Controller Initialized
DEBUG - 2018-08-03 01:51:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-03 01:51:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-08-03 01:51:05 --> Final output sent to browser
DEBUG - 2018-08-03 01:51:05 --> Total execution time: 0.3918
INFO - 2018-08-03 01:51:05 --> Config Class Initialized
INFO - 2018-08-03 01:51:05 --> Hooks Class Initialized
DEBUG - 2018-08-03 01:51:05 --> UTF-8 Support Enabled
INFO - 2018-08-03 01:51:05 --> Utf8 Class Initialized
INFO - 2018-08-03 01:51:06 --> URI Class Initialized
INFO - 2018-08-03 01:51:06 --> Router Class Initialized
INFO - 2018-08-03 01:51:06 --> Output Class Initialized
INFO - 2018-08-03 01:51:06 --> Security Class Initialized
DEBUG - 2018-08-03 01:51:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 01:51:06 --> Input Class Initialized
INFO - 2018-08-03 01:51:06 --> Language Class Initialized
INFO - 2018-08-03 01:51:06 --> Language Class Initialized
INFO - 2018-08-03 01:51:06 --> Config Class Initialized
INFO - 2018-08-03 01:51:06 --> Loader Class Initialized
DEBUG - 2018-08-03 01:51:06 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-03 01:51:06 --> Helper loaded: url_helper
INFO - 2018-08-03 01:51:06 --> Helper loaded: form_helper
INFO - 2018-08-03 01:51:06 --> Helper loaded: date_helper
INFO - 2018-08-03 01:51:06 --> Helper loaded: util_helper
INFO - 2018-08-03 01:51:06 --> Helper loaded: text_helper
INFO - 2018-08-03 01:51:06 --> Helper loaded: string_helper
INFO - 2018-08-03 01:51:06 --> Database Driver Class Initialized
DEBUG - 2018-08-03 01:51:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 01:51:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-03 01:51:06 --> Email Class Initialized
INFO - 2018-08-03 01:51:06 --> Controller Class Initialized
DEBUG - 2018-08-03 01:51:06 --> Home MX_Controller Initialized
DEBUG - 2018-08-03 01:51:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-08-03 01:51:06 --> Config Class Initialized
INFO - 2018-08-03 01:51:06 --> Hooks Class Initialized
DEBUG - 2018-08-03 01:51:06 --> UTF-8 Support Enabled
INFO - 2018-08-03 01:51:06 --> Utf8 Class Initialized
INFO - 2018-08-03 01:51:06 --> URI Class Initialized
INFO - 2018-08-03 01:51:06 --> Router Class Initialized
INFO - 2018-08-03 01:51:06 --> Output Class Initialized
INFO - 2018-08-03 01:51:06 --> Security Class Initialized
DEBUG - 2018-08-03 01:51:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 01:51:06 --> Input Class Initialized
INFO - 2018-08-03 01:51:06 --> Language Class Initialized
INFO - 2018-08-03 01:51:06 --> Language Class Initialized
INFO - 2018-08-03 01:51:06 --> Config Class Initialized
INFO - 2018-08-03 01:51:06 --> Loader Class Initialized
DEBUG - 2018-08-03 01:51:06 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-03 01:51:06 --> Helper loaded: url_helper
INFO - 2018-08-03 01:51:06 --> Helper loaded: form_helper
INFO - 2018-08-03 01:51:06 --> Helper loaded: date_helper
INFO - 2018-08-03 01:51:06 --> Helper loaded: util_helper
INFO - 2018-08-03 01:51:06 --> Helper loaded: text_helper
INFO - 2018-08-03 01:51:06 --> Helper loaded: string_helper
INFO - 2018-08-03 01:51:06 --> Database Driver Class Initialized
DEBUG - 2018-08-03 01:51:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 01:51:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-03 01:51:06 --> Email Class Initialized
INFO - 2018-08-03 01:51:06 --> Controller Class Initialized
DEBUG - 2018-08-03 01:51:06 --> Home MX_Controller Initialized
DEBUG - 2018-08-03 01:51:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-03 01:51:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-08-03 01:51:07 --> Final output sent to browser
DEBUG - 2018-08-03 01:51:07 --> Total execution time: 0.4440
INFO - 2018-08-03 01:51:07 --> Config Class Initialized
INFO - 2018-08-03 01:51:07 --> Hooks Class Initialized
DEBUG - 2018-08-03 01:51:07 --> UTF-8 Support Enabled
INFO - 2018-08-03 01:51:07 --> Utf8 Class Initialized
INFO - 2018-08-03 01:51:07 --> URI Class Initialized
INFO - 2018-08-03 01:51:07 --> Router Class Initialized
INFO - 2018-08-03 01:51:07 --> Output Class Initialized
INFO - 2018-08-03 01:51:07 --> Security Class Initialized
DEBUG - 2018-08-03 01:51:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 01:51:07 --> Input Class Initialized
INFO - 2018-08-03 01:51:07 --> Language Class Initialized
INFO - 2018-08-03 01:51:07 --> Language Class Initialized
INFO - 2018-08-03 01:51:07 --> Config Class Initialized
INFO - 2018-08-03 01:51:07 --> Loader Class Initialized
DEBUG - 2018-08-03 01:51:07 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-03 01:51:07 --> Helper loaded: url_helper
INFO - 2018-08-03 01:51:07 --> Helper loaded: form_helper
INFO - 2018-08-03 01:51:07 --> Helper loaded: date_helper
INFO - 2018-08-03 01:51:07 --> Helper loaded: util_helper
INFO - 2018-08-03 01:51:07 --> Helper loaded: text_helper
INFO - 2018-08-03 01:51:07 --> Helper loaded: string_helper
INFO - 2018-08-03 01:51:07 --> Database Driver Class Initialized
DEBUG - 2018-08-03 01:51:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 01:51:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-03 01:51:07 --> Email Class Initialized
INFO - 2018-08-03 01:51:07 --> Controller Class Initialized
DEBUG - 2018-08-03 01:51:07 --> Home MX_Controller Initialized
DEBUG - 2018-08-03 01:51:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-08-03 01:52:46 --> Config Class Initialized
INFO - 2018-08-03 01:52:46 --> Hooks Class Initialized
DEBUG - 2018-08-03 01:52:46 --> UTF-8 Support Enabled
INFO - 2018-08-03 01:52:46 --> Utf8 Class Initialized
INFO - 2018-08-03 01:52:46 --> URI Class Initialized
INFO - 2018-08-03 01:52:46 --> Router Class Initialized
INFO - 2018-08-03 01:52:46 --> Output Class Initialized
INFO - 2018-08-03 01:52:46 --> Security Class Initialized
DEBUG - 2018-08-03 01:52:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 01:52:46 --> Input Class Initialized
INFO - 2018-08-03 01:52:46 --> Language Class Initialized
INFO - 2018-08-03 01:52:46 --> Language Class Initialized
INFO - 2018-08-03 01:52:46 --> Config Class Initialized
INFO - 2018-08-03 01:52:46 --> Loader Class Initialized
DEBUG - 2018-08-03 01:52:46 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-03 01:52:46 --> Helper loaded: url_helper
INFO - 2018-08-03 01:52:46 --> Helper loaded: form_helper
INFO - 2018-08-03 01:52:46 --> Helper loaded: date_helper
INFO - 2018-08-03 01:52:46 --> Helper loaded: util_helper
INFO - 2018-08-03 01:52:46 --> Helper loaded: text_helper
INFO - 2018-08-03 01:52:46 --> Helper loaded: string_helper
INFO - 2018-08-03 01:52:46 --> Database Driver Class Initialized
DEBUG - 2018-08-03 01:52:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 01:52:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-03 01:52:46 --> Email Class Initialized
INFO - 2018-08-03 01:52:46 --> Controller Class Initialized
DEBUG - 2018-08-03 01:52:46 --> Home MX_Controller Initialized
DEBUG - 2018-08-03 01:52:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-03 01:52:46 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-03 01:52:46 --> Login MX_Controller Initialized
INFO - 2018-08-03 01:52:46 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-03 01:52:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-03 01:52:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-03 01:52:46 --> Config Class Initialized
INFO - 2018-08-03 01:52:46 --> Hooks Class Initialized
DEBUG - 2018-08-03 01:52:46 --> UTF-8 Support Enabled
INFO - 2018-08-03 01:52:46 --> Utf8 Class Initialized
INFO - 2018-08-03 01:52:46 --> URI Class Initialized
INFO - 2018-08-03 01:52:46 --> Router Class Initialized
INFO - 2018-08-03 01:52:46 --> Output Class Initialized
INFO - 2018-08-03 01:52:46 --> Security Class Initialized
DEBUG - 2018-08-03 01:52:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 01:52:46 --> Input Class Initialized
INFO - 2018-08-03 01:52:46 --> Language Class Initialized
INFO - 2018-08-03 01:52:46 --> Language Class Initialized
INFO - 2018-08-03 01:52:46 --> Config Class Initialized
INFO - 2018-08-03 01:52:46 --> Loader Class Initialized
DEBUG - 2018-08-03 01:52:46 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-03 01:52:46 --> Helper loaded: url_helper
INFO - 2018-08-03 01:52:46 --> Helper loaded: form_helper
INFO - 2018-08-03 01:52:46 --> Helper loaded: date_helper
INFO - 2018-08-03 01:52:46 --> Helper loaded: util_helper
INFO - 2018-08-03 01:52:46 --> Helper loaded: text_helper
INFO - 2018-08-03 01:52:47 --> Helper loaded: string_helper
INFO - 2018-08-03 01:52:47 --> Database Driver Class Initialized
DEBUG - 2018-08-03 01:52:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 01:52:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-03 01:52:47 --> Email Class Initialized
INFO - 2018-08-03 01:52:47 --> Controller Class Initialized
DEBUG - 2018-08-03 01:52:47 --> Home MX_Controller Initialized
DEBUG - 2018-08-03 01:52:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-03 01:52:47 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-03 01:52:47 --> Login MX_Controller Initialized
INFO - 2018-08-03 01:52:47 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-03 01:52:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-03 01:52:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-03 01:52:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-08-03 01:52:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-08-03 01:52:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-08-03 01:52:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-08-03 01:52:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-08-03 01:52:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-08-03 01:52:47 --> Final output sent to browser
DEBUG - 2018-08-03 01:52:47 --> Total execution time: 0.5449
INFO - 2018-08-03 01:52:48 --> Config Class Initialized
INFO - 2018-08-03 01:52:48 --> Hooks Class Initialized
DEBUG - 2018-08-03 01:52:48 --> UTF-8 Support Enabled
INFO - 2018-08-03 01:52:48 --> Utf8 Class Initialized
INFO - 2018-08-03 01:52:48 --> Config Class Initialized
INFO - 2018-08-03 01:52:48 --> Hooks Class Initialized
INFO - 2018-08-03 01:52:48 --> URI Class Initialized
DEBUG - 2018-08-03 01:52:48 --> UTF-8 Support Enabled
INFO - 2018-08-03 01:52:48 --> Router Class Initialized
INFO - 2018-08-03 01:52:48 --> Utf8 Class Initialized
INFO - 2018-08-03 01:52:48 --> URI Class Initialized
INFO - 2018-08-03 01:52:48 --> Output Class Initialized
INFO - 2018-08-03 01:52:48 --> Router Class Initialized
INFO - 2018-08-03 01:52:48 --> Security Class Initialized
INFO - 2018-08-03 01:52:48 --> Output Class Initialized
INFO - 2018-08-03 01:52:48 --> Security Class Initialized
DEBUG - 2018-08-03 01:52:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-08-03 01:52:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 01:52:48 --> Input Class Initialized
INFO - 2018-08-03 01:52:48 --> Input Class Initialized
INFO - 2018-08-03 01:52:48 --> Language Class Initialized
INFO - 2018-08-03 01:52:48 --> Language Class Initialized
ERROR - 2018-08-03 01:52:48 --> 404 Page Not Found: /index
INFO - 2018-08-03 01:52:48 --> Language Class Initialized
INFO - 2018-08-03 01:52:48 --> Config Class Initialized
INFO - 2018-08-03 01:52:48 --> Config Class Initialized
INFO - 2018-08-03 01:52:49 --> Hooks Class Initialized
INFO - 2018-08-03 01:52:49 --> Loader Class Initialized
DEBUG - 2018-08-03 01:52:49 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
DEBUG - 2018-08-03 01:52:49 --> UTF-8 Support Enabled
INFO - 2018-08-03 01:52:49 --> Utf8 Class Initialized
INFO - 2018-08-03 01:52:49 --> Helper loaded: url_helper
INFO - 2018-08-03 01:52:49 --> Helper loaded: form_helper
INFO - 2018-08-03 01:52:49 --> URI Class Initialized
INFO - 2018-08-03 01:52:49 --> Helper loaded: date_helper
INFO - 2018-08-03 01:52:49 --> Router Class Initialized
INFO - 2018-08-03 01:52:49 --> Helper loaded: util_helper
INFO - 2018-08-03 01:52:49 --> Helper loaded: text_helper
INFO - 2018-08-03 01:52:49 --> Output Class Initialized
INFO - 2018-08-03 01:52:49 --> Helper loaded: string_helper
INFO - 2018-08-03 01:52:49 --> Security Class Initialized
INFO - 2018-08-03 01:52:49 --> Database Driver Class Initialized
DEBUG - 2018-08-03 01:52:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-08-03 01:52:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 01:52:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-03 01:52:49 --> Input Class Initialized
INFO - 2018-08-03 01:52:49 --> Language Class Initialized
INFO - 2018-08-03 01:52:49 --> Email Class Initialized
INFO - 2018-08-03 01:52:49 --> Controller Class Initialized
ERROR - 2018-08-03 01:52:49 --> 404 Page Not Found: /index
DEBUG - 2018-08-03 01:52:49 --> Home MX_Controller Initialized
DEBUG - 2018-08-03 01:52:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-08-03 01:52:49 --> Config Class Initialized
INFO - 2018-08-03 01:52:49 --> Hooks Class Initialized
DEBUG - 2018-08-03 01:52:49 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-03 01:52:49 --> Login MX_Controller Initialized
DEBUG - 2018-08-03 01:52:49 --> UTF-8 Support Enabled
INFO - 2018-08-03 01:52:49 --> Utf8 Class Initialized
INFO - 2018-08-03 01:52:49 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-03 01:52:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-08-03 01:52:49 --> URI Class Initialized
DEBUG - 2018-08-03 01:52:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-03 01:52:49 --> Router Class Initialized
INFO - 2018-08-03 01:52:49 --> Output Class Initialized
INFO - 2018-08-03 01:52:49 --> Security Class Initialized
DEBUG - 2018-08-03 01:52:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 01:52:49 --> Input Class Initialized
INFO - 2018-08-03 01:52:49 --> Language Class Initialized
ERROR - 2018-08-03 01:52:49 --> 404 Page Not Found: /index
INFO - 2018-08-03 01:53:38 --> Config Class Initialized
INFO - 2018-08-03 01:53:38 --> Hooks Class Initialized
DEBUG - 2018-08-03 01:53:38 --> UTF-8 Support Enabled
INFO - 2018-08-03 01:53:38 --> Utf8 Class Initialized
INFO - 2018-08-03 01:53:38 --> URI Class Initialized
INFO - 2018-08-03 01:53:38 --> Router Class Initialized
INFO - 2018-08-03 01:53:38 --> Output Class Initialized
INFO - 2018-08-03 01:53:38 --> Security Class Initialized
DEBUG - 2018-08-03 01:53:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 01:53:38 --> Input Class Initialized
INFO - 2018-08-03 01:53:38 --> Language Class Initialized
INFO - 2018-08-03 01:53:38 --> Language Class Initialized
INFO - 2018-08-03 01:53:38 --> Config Class Initialized
INFO - 2018-08-03 01:53:38 --> Loader Class Initialized
DEBUG - 2018-08-03 01:53:38 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-03 01:53:38 --> Helper loaded: url_helper
INFO - 2018-08-03 01:53:38 --> Helper loaded: form_helper
INFO - 2018-08-03 01:53:38 --> Helper loaded: date_helper
INFO - 2018-08-03 01:53:38 --> Helper loaded: util_helper
INFO - 2018-08-03 01:53:38 --> Helper loaded: text_helper
INFO - 2018-08-03 01:53:38 --> Helper loaded: string_helper
INFO - 2018-08-03 01:53:38 --> Database Driver Class Initialized
DEBUG - 2018-08-03 01:53:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 01:53:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-03 01:53:39 --> Email Class Initialized
INFO - 2018-08-03 01:53:39 --> Controller Class Initialized
DEBUG - 2018-08-03 01:53:39 --> Home MX_Controller Initialized
DEBUG - 2018-08-03 01:53:39 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-03 01:53:39 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-03 01:53:39 --> Login MX_Controller Initialized
INFO - 2018-08-03 01:53:39 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-03 01:53:39 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-03 01:53:39 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-03 01:53:40 --> Config Class Initialized
INFO - 2018-08-03 01:53:40 --> Hooks Class Initialized
DEBUG - 2018-08-03 01:53:40 --> UTF-8 Support Enabled
INFO - 2018-08-03 01:53:40 --> Utf8 Class Initialized
INFO - 2018-08-03 01:53:40 --> URI Class Initialized
INFO - 2018-08-03 01:53:40 --> Router Class Initialized
INFO - 2018-08-03 01:53:40 --> Output Class Initialized
INFO - 2018-08-03 01:53:40 --> Security Class Initialized
DEBUG - 2018-08-03 01:53:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 01:53:40 --> Input Class Initialized
INFO - 2018-08-03 01:53:40 --> Language Class Initialized
INFO - 2018-08-03 01:53:40 --> Language Class Initialized
INFO - 2018-08-03 01:53:40 --> Config Class Initialized
INFO - 2018-08-03 01:53:40 --> Loader Class Initialized
DEBUG - 2018-08-03 01:53:40 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-03 01:53:40 --> Helper loaded: url_helper
INFO - 2018-08-03 01:53:40 --> Helper loaded: form_helper
INFO - 2018-08-03 01:53:40 --> Helper loaded: date_helper
INFO - 2018-08-03 01:53:40 --> Helper loaded: util_helper
INFO - 2018-08-03 01:53:40 --> Helper loaded: text_helper
INFO - 2018-08-03 01:53:40 --> Helper loaded: string_helper
INFO - 2018-08-03 01:53:40 --> Database Driver Class Initialized
DEBUG - 2018-08-03 01:53:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 01:53:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-03 01:53:40 --> Email Class Initialized
INFO - 2018-08-03 01:53:40 --> Controller Class Initialized
DEBUG - 2018-08-03 01:53:40 --> Home MX_Controller Initialized
DEBUG - 2018-08-03 01:53:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-03 01:53:40 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-03 01:53:41 --> Login MX_Controller Initialized
INFO - 2018-08-03 01:53:41 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-03 01:53:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-03 01:53:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-03 01:53:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-08-03 01:53:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-08-03 01:53:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-08-03 01:53:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-08-03 01:53:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-08-03 01:53:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-08-03 01:53:41 --> Final output sent to browser
DEBUG - 2018-08-03 01:53:41 --> Total execution time: 0.5436
INFO - 2018-08-03 01:53:41 --> Config Class Initialized
INFO - 2018-08-03 01:53:41 --> Hooks Class Initialized
DEBUG - 2018-08-03 01:53:41 --> UTF-8 Support Enabled
INFO - 2018-08-03 01:53:41 --> Config Class Initialized
INFO - 2018-08-03 01:53:41 --> Hooks Class Initialized
INFO - 2018-08-03 01:53:41 --> Utf8 Class Initialized
DEBUG - 2018-08-03 01:53:41 --> UTF-8 Support Enabled
INFO - 2018-08-03 01:53:41 --> Utf8 Class Initialized
INFO - 2018-08-03 01:53:41 --> URI Class Initialized
INFO - 2018-08-03 01:53:41 --> URI Class Initialized
INFO - 2018-08-03 01:53:41 --> Router Class Initialized
INFO - 2018-08-03 01:53:41 --> Output Class Initialized
INFO - 2018-08-03 01:53:41 --> Router Class Initialized
INFO - 2018-08-03 01:53:41 --> Security Class Initialized
INFO - 2018-08-03 01:53:41 --> Output Class Initialized
DEBUG - 2018-08-03 01:53:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 01:53:41 --> Security Class Initialized
INFO - 2018-08-03 01:53:41 --> Input Class Initialized
DEBUG - 2018-08-03 01:53:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 01:53:42 --> Input Class Initialized
INFO - 2018-08-03 01:53:42 --> Language Class Initialized
INFO - 2018-08-03 01:53:42 --> Language Class Initialized
INFO - 2018-08-03 01:53:42 --> Language Class Initialized
INFO - 2018-08-03 01:53:42 --> Config Class Initialized
ERROR - 2018-08-03 01:53:42 --> 404 Page Not Found: /index
INFO - 2018-08-03 01:53:42 --> Loader Class Initialized
INFO - 2018-08-03 01:53:42 --> Config Class Initialized
INFO - 2018-08-03 01:53:42 --> Hooks Class Initialized
DEBUG - 2018-08-03 01:53:42 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
DEBUG - 2018-08-03 01:53:42 --> UTF-8 Support Enabled
INFO - 2018-08-03 01:53:42 --> Helper loaded: url_helper
INFO - 2018-08-03 01:53:42 --> Utf8 Class Initialized
INFO - 2018-08-03 01:53:42 --> URI Class Initialized
INFO - 2018-08-03 01:53:42 --> Helper loaded: form_helper
INFO - 2018-08-03 01:53:42 --> Helper loaded: date_helper
INFO - 2018-08-03 01:53:42 --> Router Class Initialized
INFO - 2018-08-03 01:53:42 --> Helper loaded: util_helper
INFO - 2018-08-03 01:53:42 --> Output Class Initialized
INFO - 2018-08-03 01:53:42 --> Helper loaded: text_helper
INFO - 2018-08-03 01:53:42 --> Security Class Initialized
INFO - 2018-08-03 01:53:42 --> Helper loaded: string_helper
DEBUG - 2018-08-03 01:53:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 01:53:42 --> Input Class Initialized
INFO - 2018-08-03 01:53:42 --> Database Driver Class Initialized
INFO - 2018-08-03 01:53:42 --> Language Class Initialized
DEBUG - 2018-08-03 01:53:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 01:53:42 --> Session: Class initialized using 'files' driver.
ERROR - 2018-08-03 01:53:42 --> 404 Page Not Found: /index
INFO - 2018-08-03 01:53:42 --> Email Class Initialized
INFO - 2018-08-03 01:53:42 --> Config Class Initialized
INFO - 2018-08-03 01:53:42 --> Hooks Class Initialized
INFO - 2018-08-03 01:53:42 --> Controller Class Initialized
DEBUG - 2018-08-03 01:53:42 --> UTF-8 Support Enabled
INFO - 2018-08-03 01:53:42 --> Utf8 Class Initialized
DEBUG - 2018-08-03 01:53:42 --> Home MX_Controller Initialized
INFO - 2018-08-03 01:53:42 --> URI Class Initialized
DEBUG - 2018-08-03 01:53:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-08-03 01:53:42 --> Router Class Initialized
INFO - 2018-08-03 01:53:42 --> Output Class Initialized
DEBUG - 2018-08-03 01:53:42 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
INFO - 2018-08-03 01:53:42 --> Security Class Initialized
DEBUG - 2018-08-03 01:53:42 --> Login MX_Controller Initialized
DEBUG - 2018-08-03 01:53:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 01:53:42 --> Language file loaded: language/english/data_lang.php
INFO - 2018-08-03 01:53:42 --> Input Class Initialized
DEBUG - 2018-08-03 01:53:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-08-03 01:53:42 --> Language Class Initialized
DEBUG - 2018-08-03 01:53:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
ERROR - 2018-08-03 01:53:42 --> 404 Page Not Found: /index
INFO - 2018-08-03 01:54:09 --> Config Class Initialized
INFO - 2018-08-03 01:54:09 --> Hooks Class Initialized
DEBUG - 2018-08-03 01:54:09 --> UTF-8 Support Enabled
INFO - 2018-08-03 01:54:09 --> Utf8 Class Initialized
INFO - 2018-08-03 01:54:09 --> URI Class Initialized
INFO - 2018-08-03 01:54:09 --> Router Class Initialized
INFO - 2018-08-03 01:54:09 --> Output Class Initialized
INFO - 2018-08-03 01:54:09 --> Security Class Initialized
DEBUG - 2018-08-03 01:54:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 01:54:09 --> Input Class Initialized
INFO - 2018-08-03 01:54:09 --> Language Class Initialized
INFO - 2018-08-03 01:54:09 --> Language Class Initialized
INFO - 2018-08-03 01:54:09 --> Config Class Initialized
INFO - 2018-08-03 01:54:09 --> Loader Class Initialized
DEBUG - 2018-08-03 01:54:09 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-03 01:54:09 --> Helper loaded: url_helper
INFO - 2018-08-03 01:54:09 --> Helper loaded: form_helper
INFO - 2018-08-03 01:54:09 --> Helper loaded: date_helper
INFO - 2018-08-03 01:54:09 --> Helper loaded: util_helper
INFO - 2018-08-03 01:54:09 --> Helper loaded: text_helper
INFO - 2018-08-03 01:54:09 --> Helper loaded: string_helper
INFO - 2018-08-03 01:54:09 --> Database Driver Class Initialized
DEBUG - 2018-08-03 01:54:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 01:54:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-03 01:54:09 --> Email Class Initialized
INFO - 2018-08-03 01:54:09 --> Controller Class Initialized
DEBUG - 2018-08-03 01:54:09 --> Home MX_Controller Initialized
DEBUG - 2018-08-03 01:54:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-03 01:54:09 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-03 01:54:09 --> Login MX_Controller Initialized
INFO - 2018-08-03 01:54:09 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-03 01:54:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-03 01:54:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-03 01:54:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-08-03 01:54:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-08-03 01:54:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-08-03 01:54:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-08-03 01:54:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-08-03 01:54:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-08-03 01:54:09 --> Final output sent to browser
DEBUG - 2018-08-03 01:54:09 --> Total execution time: 0.5676
INFO - 2018-08-03 01:54:11 --> Config Class Initialized
INFO - 2018-08-03 01:54:11 --> Hooks Class Initialized
DEBUG - 2018-08-03 01:54:11 --> UTF-8 Support Enabled
INFO - 2018-08-03 01:54:11 --> Utf8 Class Initialized
INFO - 2018-08-03 01:54:11 --> Config Class Initialized
INFO - 2018-08-03 01:54:11 --> Hooks Class Initialized
INFO - 2018-08-03 01:54:11 --> URI Class Initialized
DEBUG - 2018-08-03 01:54:11 --> UTF-8 Support Enabled
INFO - 2018-08-03 01:54:11 --> Utf8 Class Initialized
INFO - 2018-08-03 01:54:11 --> URI Class Initialized
INFO - 2018-08-03 01:54:11 --> Router Class Initialized
INFO - 2018-08-03 01:54:11 --> Output Class Initialized
INFO - 2018-08-03 01:54:11 --> Security Class Initialized
INFO - 2018-08-03 01:54:11 --> Router Class Initialized
DEBUG - 2018-08-03 01:54:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 01:54:11 --> Output Class Initialized
INFO - 2018-08-03 01:54:11 --> Input Class Initialized
INFO - 2018-08-03 01:54:11 --> Security Class Initialized
DEBUG - 2018-08-03 01:54:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 01:54:12 --> Language Class Initialized
INFO - 2018-08-03 01:54:12 --> Input Class Initialized
INFO - 2018-08-03 01:54:12 --> Language Class Initialized
INFO - 2018-08-03 01:54:12 --> Language Class Initialized
INFO - 2018-08-03 01:54:12 --> Config Class Initialized
ERROR - 2018-08-03 01:54:12 --> 404 Page Not Found: /index
INFO - 2018-08-03 01:54:12 --> Loader Class Initialized
INFO - 2018-08-03 01:54:12 --> Config Class Initialized
INFO - 2018-08-03 01:54:12 --> Hooks Class Initialized
DEBUG - 2018-08-03 01:54:12 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
DEBUG - 2018-08-03 01:54:12 --> UTF-8 Support Enabled
INFO - 2018-08-03 01:54:12 --> Utf8 Class Initialized
INFO - 2018-08-03 01:54:12 --> Helper loaded: url_helper
INFO - 2018-08-03 01:54:12 --> URI Class Initialized
INFO - 2018-08-03 01:54:12 --> Helper loaded: form_helper
INFO - 2018-08-03 01:54:12 --> Helper loaded: date_helper
INFO - 2018-08-03 01:54:12 --> Router Class Initialized
INFO - 2018-08-03 01:54:12 --> Helper loaded: util_helper
INFO - 2018-08-03 01:54:12 --> Output Class Initialized
INFO - 2018-08-03 01:54:12 --> Helper loaded: text_helper
INFO - 2018-08-03 01:54:12 --> Security Class Initialized
INFO - 2018-08-03 01:54:12 --> Helper loaded: string_helper
DEBUG - 2018-08-03 01:54:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 01:54:12 --> Input Class Initialized
INFO - 2018-08-03 01:54:12 --> Database Driver Class Initialized
INFO - 2018-08-03 01:54:12 --> Language Class Initialized
DEBUG - 2018-08-03 01:54:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 01:54:12 --> Session: Class initialized using 'files' driver.
ERROR - 2018-08-03 01:54:12 --> 404 Page Not Found: /index
INFO - 2018-08-03 01:54:12 --> Email Class Initialized
INFO - 2018-08-03 01:54:12 --> Config Class Initialized
INFO - 2018-08-03 01:54:12 --> Hooks Class Initialized
INFO - 2018-08-03 01:54:12 --> Controller Class Initialized
DEBUG - 2018-08-03 01:54:12 --> Home MX_Controller Initialized
DEBUG - 2018-08-03 01:54:12 --> UTF-8 Support Enabled
INFO - 2018-08-03 01:54:12 --> Utf8 Class Initialized
DEBUG - 2018-08-03 01:54:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-08-03 01:54:12 --> URI Class Initialized
DEBUG - 2018-08-03 01:54:12 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-03 01:54:12 --> Login MX_Controller Initialized
INFO - 2018-08-03 01:54:12 --> Router Class Initialized
INFO - 2018-08-03 01:54:12 --> Language file loaded: language/english/data_lang.php
INFO - 2018-08-03 01:54:12 --> Output Class Initialized
DEBUG - 2018-08-03 01:54:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-08-03 01:54:12 --> Security Class Initialized
DEBUG - 2018-08-03 01:54:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-03 01:54:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 01:54:12 --> Input Class Initialized
INFO - 2018-08-03 01:54:12 --> Language Class Initialized
ERROR - 2018-08-03 01:54:12 --> 404 Page Not Found: /index
INFO - 2018-08-03 01:54:12 --> Config Class Initialized
INFO - 2018-08-03 01:54:12 --> Hooks Class Initialized
DEBUG - 2018-08-03 01:54:12 --> UTF-8 Support Enabled
INFO - 2018-08-03 01:54:12 --> Utf8 Class Initialized
INFO - 2018-08-03 01:54:12 --> URI Class Initialized
INFO - 2018-08-03 01:54:12 --> Router Class Initialized
INFO - 2018-08-03 01:54:12 --> Output Class Initialized
INFO - 2018-08-03 01:54:12 --> Security Class Initialized
DEBUG - 2018-08-03 01:54:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 01:54:12 --> Input Class Initialized
INFO - 2018-08-03 01:54:12 --> Language Class Initialized
ERROR - 2018-08-03 01:54:12 --> 404 Page Not Found: /index
INFO - 2018-08-03 01:54:12 --> Config Class Initialized
INFO - 2018-08-03 01:54:12 --> Hooks Class Initialized
DEBUG - 2018-08-03 01:54:12 --> UTF-8 Support Enabled
INFO - 2018-08-03 01:54:12 --> Utf8 Class Initialized
INFO - 2018-08-03 01:54:12 --> URI Class Initialized
INFO - 2018-08-03 01:54:12 --> Router Class Initialized
INFO - 2018-08-03 01:54:12 --> Output Class Initialized
INFO - 2018-08-03 01:54:12 --> Security Class Initialized
DEBUG - 2018-08-03 01:54:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 01:54:12 --> Input Class Initialized
INFO - 2018-08-03 01:54:12 --> Language Class Initialized
ERROR - 2018-08-03 01:54:12 --> 404 Page Not Found: /index
INFO - 2018-08-03 01:54:13 --> Config Class Initialized
INFO - 2018-08-03 01:54:13 --> Hooks Class Initialized
DEBUG - 2018-08-03 01:54:13 --> UTF-8 Support Enabled
INFO - 2018-08-03 01:54:13 --> Utf8 Class Initialized
INFO - 2018-08-03 01:54:13 --> URI Class Initialized
INFO - 2018-08-03 01:54:13 --> Router Class Initialized
INFO - 2018-08-03 01:54:13 --> Output Class Initialized
INFO - 2018-08-03 01:54:13 --> Security Class Initialized
DEBUG - 2018-08-03 01:54:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 01:54:13 --> Input Class Initialized
INFO - 2018-08-03 01:54:13 --> Language Class Initialized
ERROR - 2018-08-03 01:54:13 --> 404 Page Not Found: /index
INFO - 2018-08-03 01:59:42 --> Config Class Initialized
INFO - 2018-08-03 01:59:42 --> Hooks Class Initialized
DEBUG - 2018-08-03 01:59:42 --> UTF-8 Support Enabled
INFO - 2018-08-03 01:59:42 --> Utf8 Class Initialized
INFO - 2018-08-03 01:59:42 --> URI Class Initialized
INFO - 2018-08-03 01:59:42 --> Router Class Initialized
INFO - 2018-08-03 01:59:42 --> Output Class Initialized
INFO - 2018-08-03 01:59:43 --> Security Class Initialized
DEBUG - 2018-08-03 01:59:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 01:59:43 --> Input Class Initialized
INFO - 2018-08-03 01:59:43 --> Language Class Initialized
INFO - 2018-08-03 01:59:43 --> Language Class Initialized
INFO - 2018-08-03 01:59:43 --> Config Class Initialized
INFO - 2018-08-03 01:59:43 --> Loader Class Initialized
DEBUG - 2018-08-03 01:59:43 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-03 01:59:43 --> Helper loaded: url_helper
INFO - 2018-08-03 01:59:43 --> Helper loaded: form_helper
INFO - 2018-08-03 01:59:43 --> Helper loaded: date_helper
INFO - 2018-08-03 01:59:43 --> Helper loaded: util_helper
INFO - 2018-08-03 01:59:43 --> Helper loaded: text_helper
INFO - 2018-08-03 01:59:43 --> Helper loaded: string_helper
INFO - 2018-08-03 01:59:43 --> Database Driver Class Initialized
DEBUG - 2018-08-03 01:59:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 01:59:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-03 01:59:43 --> Email Class Initialized
INFO - 2018-08-03 01:59:43 --> Controller Class Initialized
DEBUG - 2018-08-03 01:59:43 --> Home MX_Controller Initialized
DEBUG - 2018-08-03 01:59:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-03 01:59:43 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-03 01:59:43 --> Login MX_Controller Initialized
INFO - 2018-08-03 01:59:43 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-03 01:59:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-03 01:59:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-03 01:59:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-08-03 01:59:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-08-03 01:59:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-08-03 01:59:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-08-03 01:59:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-08-03 01:59:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-08-03 01:59:43 --> Final output sent to browser
DEBUG - 2018-08-03 01:59:43 --> Total execution time: 0.5354
INFO - 2018-08-03 01:59:44 --> Config Class Initialized
INFO - 2018-08-03 01:59:44 --> Hooks Class Initialized
DEBUG - 2018-08-03 01:59:44 --> UTF-8 Support Enabled
INFO - 2018-08-03 01:59:44 --> Utf8 Class Initialized
INFO - 2018-08-03 01:59:44 --> URI Class Initialized
INFO - 2018-08-03 01:59:44 --> Config Class Initialized
INFO - 2018-08-03 01:59:44 --> Hooks Class Initialized
INFO - 2018-08-03 01:59:44 --> Router Class Initialized
INFO - 2018-08-03 01:59:44 --> Output Class Initialized
DEBUG - 2018-08-03 01:59:44 --> UTF-8 Support Enabled
INFO - 2018-08-03 01:59:44 --> Utf8 Class Initialized
INFO - 2018-08-03 01:59:44 --> Security Class Initialized
INFO - 2018-08-03 01:59:44 --> URI Class Initialized
DEBUG - 2018-08-03 01:59:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 01:59:44 --> Router Class Initialized
INFO - 2018-08-03 01:59:44 --> Input Class Initialized
INFO - 2018-08-03 01:59:44 --> Output Class Initialized
INFO - 2018-08-03 01:59:44 --> Security Class Initialized
INFO - 2018-08-03 01:59:44 --> Language Class Initialized
DEBUG - 2018-08-03 01:59:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-08-03 01:59:44 --> 404 Page Not Found: /index
INFO - 2018-08-03 01:59:44 --> Input Class Initialized
INFO - 2018-08-03 01:59:44 --> Config Class Initialized
INFO - 2018-08-03 01:59:44 --> Hooks Class Initialized
INFO - 2018-08-03 01:59:44 --> Language Class Initialized
DEBUG - 2018-08-03 01:59:44 --> UTF-8 Support Enabled
INFO - 2018-08-03 01:59:44 --> Language Class Initialized
INFO - 2018-08-03 01:59:44 --> Utf8 Class Initialized
INFO - 2018-08-03 01:59:44 --> Config Class Initialized
INFO - 2018-08-03 01:59:44 --> URI Class Initialized
INFO - 2018-08-03 01:59:44 --> Loader Class Initialized
DEBUG - 2018-08-03 01:59:44 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-03 01:59:44 --> Router Class Initialized
INFO - 2018-08-03 01:59:44 --> Helper loaded: url_helper
INFO - 2018-08-03 01:59:44 --> Output Class Initialized
INFO - 2018-08-03 01:59:44 --> Security Class Initialized
INFO - 2018-08-03 01:59:44 --> Helper loaded: form_helper
INFO - 2018-08-03 01:59:44 --> Helper loaded: date_helper
DEBUG - 2018-08-03 01:59:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 01:59:44 --> Helper loaded: util_helper
INFO - 2018-08-03 01:59:44 --> Input Class Initialized
INFO - 2018-08-03 01:59:44 --> Helper loaded: text_helper
INFO - 2018-08-03 01:59:44 --> Language Class Initialized
INFO - 2018-08-03 01:59:44 --> Helper loaded: string_helper
ERROR - 2018-08-03 01:59:44 --> 404 Page Not Found: /index
INFO - 2018-08-03 01:59:44 --> Database Driver Class Initialized
INFO - 2018-08-03 01:59:44 --> Config Class Initialized
INFO - 2018-08-03 01:59:44 --> Hooks Class Initialized
DEBUG - 2018-08-03 01:59:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 01:59:44 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-08-03 01:59:44 --> UTF-8 Support Enabled
INFO - 2018-08-03 01:59:44 --> Utf8 Class Initialized
INFO - 2018-08-03 01:59:44 --> Email Class Initialized
INFO - 2018-08-03 01:59:44 --> Controller Class Initialized
INFO - 2018-08-03 01:59:44 --> URI Class Initialized
INFO - 2018-08-03 01:59:44 --> Router Class Initialized
DEBUG - 2018-08-03 01:59:44 --> Home MX_Controller Initialized
DEBUG - 2018-08-03 01:59:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-08-03 01:59:44 --> Output Class Initialized
INFO - 2018-08-03 01:59:44 --> Security Class Initialized
DEBUG - 2018-08-03 01:59:44 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-03 01:59:44 --> Login MX_Controller Initialized
DEBUG - 2018-08-03 01:59:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 01:59:44 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-03 01:59:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-08-03 01:59:44 --> Input Class Initialized
DEBUG - 2018-08-03 01:59:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-03 01:59:44 --> Language Class Initialized
ERROR - 2018-08-03 01:59:45 --> 404 Page Not Found: /index
INFO - 2018-08-03 02:00:34 --> Config Class Initialized
INFO - 2018-08-03 02:00:34 --> Hooks Class Initialized
DEBUG - 2018-08-03 02:00:34 --> UTF-8 Support Enabled
INFO - 2018-08-03 02:00:34 --> Utf8 Class Initialized
INFO - 2018-08-03 02:00:34 --> URI Class Initialized
INFO - 2018-08-03 02:00:34 --> Router Class Initialized
INFO - 2018-08-03 02:00:34 --> Output Class Initialized
INFO - 2018-08-03 02:00:34 --> Security Class Initialized
DEBUG - 2018-08-03 02:00:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 02:00:34 --> Input Class Initialized
INFO - 2018-08-03 02:00:34 --> Language Class Initialized
INFO - 2018-08-03 02:00:34 --> Language Class Initialized
INFO - 2018-08-03 02:00:34 --> Config Class Initialized
INFO - 2018-08-03 02:00:34 --> Loader Class Initialized
DEBUG - 2018-08-03 02:00:34 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-03 02:00:34 --> Helper loaded: url_helper
INFO - 2018-08-03 02:00:34 --> Helper loaded: form_helper
INFO - 2018-08-03 02:00:34 --> Helper loaded: date_helper
INFO - 2018-08-03 02:00:34 --> Helper loaded: util_helper
INFO - 2018-08-03 02:00:34 --> Helper loaded: text_helper
INFO - 2018-08-03 02:00:34 --> Helper loaded: string_helper
INFO - 2018-08-03 02:00:34 --> Database Driver Class Initialized
DEBUG - 2018-08-03 02:00:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 02:00:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-03 02:00:34 --> Email Class Initialized
INFO - 2018-08-03 02:00:34 --> Controller Class Initialized
DEBUG - 2018-08-03 02:00:34 --> Home MX_Controller Initialized
DEBUG - 2018-08-03 02:00:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-03 02:00:34 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-03 02:00:34 --> Login MX_Controller Initialized
INFO - 2018-08-03 02:00:34 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-03 02:00:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-03 02:00:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-03 02:00:49 --> Config Class Initialized
INFO - 2018-08-03 02:00:49 --> Hooks Class Initialized
DEBUG - 2018-08-03 02:00:49 --> UTF-8 Support Enabled
INFO - 2018-08-03 02:00:49 --> Utf8 Class Initialized
INFO - 2018-08-03 02:00:49 --> URI Class Initialized
INFO - 2018-08-03 02:00:49 --> Router Class Initialized
INFO - 2018-08-03 02:00:49 --> Output Class Initialized
INFO - 2018-08-03 02:00:49 --> Security Class Initialized
DEBUG - 2018-08-03 02:00:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 02:00:49 --> Input Class Initialized
INFO - 2018-08-03 02:00:49 --> Language Class Initialized
INFO - 2018-08-03 02:00:49 --> Language Class Initialized
INFO - 2018-08-03 02:00:49 --> Config Class Initialized
INFO - 2018-08-03 02:00:49 --> Loader Class Initialized
DEBUG - 2018-08-03 02:00:49 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-03 02:00:49 --> Helper loaded: url_helper
INFO - 2018-08-03 02:00:49 --> Helper loaded: form_helper
INFO - 2018-08-03 02:00:49 --> Helper loaded: date_helper
INFO - 2018-08-03 02:00:49 --> Helper loaded: util_helper
INFO - 2018-08-03 02:00:49 --> Helper loaded: text_helper
INFO - 2018-08-03 02:00:49 --> Helper loaded: string_helper
INFO - 2018-08-03 02:00:49 --> Database Driver Class Initialized
DEBUG - 2018-08-03 02:00:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 02:00:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-03 02:00:49 --> Email Class Initialized
INFO - 2018-08-03 02:00:49 --> Controller Class Initialized
DEBUG - 2018-08-03 02:00:49 --> Home MX_Controller Initialized
DEBUG - 2018-08-03 02:00:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-03 02:00:49 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-03 02:00:49 --> Login MX_Controller Initialized
INFO - 2018-08-03 02:00:49 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-03 02:00:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-03 02:00:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-03 02:00:52 --> Config Class Initialized
INFO - 2018-08-03 02:00:52 --> Hooks Class Initialized
DEBUG - 2018-08-03 02:00:52 --> UTF-8 Support Enabled
INFO - 2018-08-03 02:00:52 --> Utf8 Class Initialized
INFO - 2018-08-03 02:00:52 --> URI Class Initialized
INFO - 2018-08-03 02:00:52 --> Router Class Initialized
INFO - 2018-08-03 02:00:52 --> Output Class Initialized
INFO - 2018-08-03 02:00:52 --> Security Class Initialized
DEBUG - 2018-08-03 02:00:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 02:00:52 --> Input Class Initialized
INFO - 2018-08-03 02:00:52 --> Language Class Initialized
INFO - 2018-08-03 02:00:52 --> Language Class Initialized
INFO - 2018-08-03 02:00:52 --> Config Class Initialized
INFO - 2018-08-03 02:00:52 --> Loader Class Initialized
DEBUG - 2018-08-03 02:00:52 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-03 02:00:52 --> Helper loaded: url_helper
INFO - 2018-08-03 02:00:52 --> Helper loaded: form_helper
INFO - 2018-08-03 02:00:52 --> Helper loaded: date_helper
INFO - 2018-08-03 02:00:52 --> Helper loaded: util_helper
INFO - 2018-08-03 02:00:52 --> Helper loaded: text_helper
INFO - 2018-08-03 02:00:52 --> Helper loaded: string_helper
INFO - 2018-08-03 02:00:52 --> Database Driver Class Initialized
DEBUG - 2018-08-03 02:00:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 02:00:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-03 02:00:52 --> Email Class Initialized
INFO - 2018-08-03 02:00:52 --> Controller Class Initialized
DEBUG - 2018-08-03 02:00:52 --> Home MX_Controller Initialized
DEBUG - 2018-08-03 02:00:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-03 02:00:52 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-03 02:00:52 --> Login MX_Controller Initialized
INFO - 2018-08-03 02:00:52 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-03 02:00:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-03 02:00:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-03 02:00:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-08-03 02:00:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-08-03 02:00:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-08-03 02:00:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-08-03 02:00:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-08-03 02:00:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-08-03 02:00:52 --> Final output sent to browser
DEBUG - 2018-08-03 02:00:52 --> Total execution time: 0.5550
INFO - 2018-08-03 02:00:53 --> Config Class Initialized
INFO - 2018-08-03 02:00:53 --> Hooks Class Initialized
DEBUG - 2018-08-03 02:00:53 --> UTF-8 Support Enabled
INFO - 2018-08-03 02:00:53 --> Config Class Initialized
INFO - 2018-08-03 02:00:53 --> Hooks Class Initialized
INFO - 2018-08-03 02:00:53 --> Utf8 Class Initialized
DEBUG - 2018-08-03 02:00:53 --> UTF-8 Support Enabled
INFO - 2018-08-03 02:00:53 --> Utf8 Class Initialized
INFO - 2018-08-03 02:00:53 --> URI Class Initialized
INFO - 2018-08-03 02:00:53 --> Router Class Initialized
INFO - 2018-08-03 02:00:53 --> URI Class Initialized
INFO - 2018-08-03 02:00:53 --> Output Class Initialized
INFO - 2018-08-03 02:00:53 --> Router Class Initialized
INFO - 2018-08-03 02:00:53 --> Security Class Initialized
INFO - 2018-08-03 02:00:53 --> Output Class Initialized
DEBUG - 2018-08-03 02:00:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 02:00:53 --> Input Class Initialized
INFO - 2018-08-03 02:00:53 --> Security Class Initialized
INFO - 2018-08-03 02:00:53 --> Language Class Initialized
DEBUG - 2018-08-03 02:00:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 02:00:53 --> Input Class Initialized
INFO - 2018-08-03 02:00:53 --> Language Class Initialized
INFO - 2018-08-03 02:00:53 --> Config Class Initialized
INFO - 2018-08-03 02:00:53 --> Language Class Initialized
ERROR - 2018-08-03 02:00:53 --> 404 Page Not Found: /index
INFO - 2018-08-03 02:00:53 --> Loader Class Initialized
DEBUG - 2018-08-03 02:00:53 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-03 02:00:53 --> Config Class Initialized
INFO - 2018-08-03 02:00:53 --> Hooks Class Initialized
INFO - 2018-08-03 02:00:53 --> Helper loaded: url_helper
INFO - 2018-08-03 02:00:53 --> Helper loaded: form_helper
DEBUG - 2018-08-03 02:00:53 --> UTF-8 Support Enabled
INFO - 2018-08-03 02:00:53 --> Utf8 Class Initialized
INFO - 2018-08-03 02:00:53 --> Helper loaded: date_helper
INFO - 2018-08-03 02:00:53 --> Helper loaded: util_helper
INFO - 2018-08-03 02:00:53 --> URI Class Initialized
INFO - 2018-08-03 02:00:53 --> Helper loaded: text_helper
INFO - 2018-08-03 02:00:53 --> Router Class Initialized
INFO - 2018-08-03 02:00:53 --> Helper loaded: string_helper
INFO - 2018-08-03 02:00:53 --> Output Class Initialized
INFO - 2018-08-03 02:00:54 --> Security Class Initialized
INFO - 2018-08-03 02:00:54 --> Database Driver Class Initialized
DEBUG - 2018-08-03 02:00:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-08-03 02:00:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 02:00:54 --> Input Class Initialized
INFO - 2018-08-03 02:00:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-03 02:00:54 --> Language Class Initialized
INFO - 2018-08-03 02:00:54 --> Email Class Initialized
INFO - 2018-08-03 02:00:54 --> Controller Class Initialized
ERROR - 2018-08-03 02:00:54 --> 404 Page Not Found: /index
DEBUG - 2018-08-03 02:00:54 --> Home MX_Controller Initialized
INFO - 2018-08-03 02:00:54 --> Config Class Initialized
INFO - 2018-08-03 02:00:54 --> Hooks Class Initialized
DEBUG - 2018-08-03 02:00:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-03 02:00:54 --> UTF-8 Support Enabled
DEBUG - 2018-08-03 02:00:54 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-03 02:00:54 --> Login MX_Controller Initialized
INFO - 2018-08-03 02:00:54 --> Utf8 Class Initialized
INFO - 2018-08-03 02:00:54 --> Language file loaded: language/english/data_lang.php
INFO - 2018-08-03 02:00:54 --> URI Class Initialized
DEBUG - 2018-08-03 02:00:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-08-03 02:00:54 --> Router Class Initialized
DEBUG - 2018-08-03 02:00:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-03 02:00:54 --> Output Class Initialized
INFO - 2018-08-03 02:00:54 --> Security Class Initialized
DEBUG - 2018-08-03 02:00:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 02:00:54 --> Input Class Initialized
INFO - 2018-08-03 02:00:54 --> Language Class Initialized
ERROR - 2018-08-03 02:00:54 --> 404 Page Not Found: /index
INFO - 2018-08-03 02:00:59 --> Config Class Initialized
INFO - 2018-08-03 02:00:59 --> Hooks Class Initialized
DEBUG - 2018-08-03 02:00:59 --> UTF-8 Support Enabled
INFO - 2018-08-03 02:01:00 --> Utf8 Class Initialized
INFO - 2018-08-03 02:01:00 --> URI Class Initialized
INFO - 2018-08-03 02:01:00 --> Router Class Initialized
INFO - 2018-08-03 02:01:00 --> Output Class Initialized
INFO - 2018-08-03 02:01:00 --> Security Class Initialized
DEBUG - 2018-08-03 02:01:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 02:01:00 --> Input Class Initialized
INFO - 2018-08-03 02:01:00 --> Language Class Initialized
INFO - 2018-08-03 02:01:00 --> Language Class Initialized
INFO - 2018-08-03 02:01:00 --> Config Class Initialized
INFO - 2018-08-03 02:01:00 --> Loader Class Initialized
DEBUG - 2018-08-03 02:01:00 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-03 02:01:00 --> Helper loaded: url_helper
INFO - 2018-08-03 02:01:00 --> Helper loaded: form_helper
INFO - 2018-08-03 02:01:00 --> Helper loaded: date_helper
INFO - 2018-08-03 02:01:00 --> Helper loaded: util_helper
INFO - 2018-08-03 02:01:00 --> Helper loaded: text_helper
INFO - 2018-08-03 02:01:00 --> Helper loaded: string_helper
INFO - 2018-08-03 02:01:00 --> Database Driver Class Initialized
DEBUG - 2018-08-03 02:01:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 02:01:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-03 02:01:00 --> Email Class Initialized
INFO - 2018-08-03 02:01:00 --> Controller Class Initialized
DEBUG - 2018-08-03 02:01:00 --> Home MX_Controller Initialized
DEBUG - 2018-08-03 02:01:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-03 02:01:00 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-03 02:01:00 --> Login MX_Controller Initialized
INFO - 2018-08-03 02:01:00 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-03 02:01:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-03 02:01:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-03 02:01:02 --> Config Class Initialized
INFO - 2018-08-03 02:01:02 --> Hooks Class Initialized
DEBUG - 2018-08-03 02:01:02 --> UTF-8 Support Enabled
INFO - 2018-08-03 02:01:02 --> Utf8 Class Initialized
INFO - 2018-08-03 02:01:02 --> URI Class Initialized
INFO - 2018-08-03 02:01:02 --> Router Class Initialized
INFO - 2018-08-03 02:01:02 --> Output Class Initialized
INFO - 2018-08-03 02:01:02 --> Security Class Initialized
DEBUG - 2018-08-03 02:01:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 02:01:02 --> Input Class Initialized
INFO - 2018-08-03 02:01:02 --> Language Class Initialized
INFO - 2018-08-03 02:01:02 --> Language Class Initialized
INFO - 2018-08-03 02:01:02 --> Config Class Initialized
INFO - 2018-08-03 02:01:02 --> Loader Class Initialized
DEBUG - 2018-08-03 02:01:02 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-03 02:01:02 --> Helper loaded: url_helper
INFO - 2018-08-03 02:01:02 --> Helper loaded: form_helper
INFO - 2018-08-03 02:01:02 --> Helper loaded: date_helper
INFO - 2018-08-03 02:01:02 --> Helper loaded: util_helper
INFO - 2018-08-03 02:01:02 --> Helper loaded: text_helper
INFO - 2018-08-03 02:01:02 --> Helper loaded: string_helper
INFO - 2018-08-03 02:01:02 --> Database Driver Class Initialized
DEBUG - 2018-08-03 02:01:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 02:01:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-03 02:01:02 --> Email Class Initialized
INFO - 2018-08-03 02:01:02 --> Controller Class Initialized
DEBUG - 2018-08-03 02:01:02 --> Home MX_Controller Initialized
DEBUG - 2018-08-03 02:01:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-03 02:01:02 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-03 02:01:02 --> Login MX_Controller Initialized
INFO - 2018-08-03 02:01:02 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-03 02:01:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-03 02:01:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-03 02:01:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-08-03 02:01:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-08-03 02:01:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-08-03 02:01:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-08-03 02:01:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-08-03 02:01:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-08-03 02:01:02 --> Final output sent to browser
DEBUG - 2018-08-03 02:01:02 --> Total execution time: 0.5362
INFO - 2018-08-03 02:01:03 --> Config Class Initialized
INFO - 2018-08-03 02:01:03 --> Hooks Class Initialized
DEBUG - 2018-08-03 02:01:03 --> UTF-8 Support Enabled
INFO - 2018-08-03 02:01:03 --> Config Class Initialized
INFO - 2018-08-03 02:01:03 --> Hooks Class Initialized
INFO - 2018-08-03 02:01:03 --> Utf8 Class Initialized
DEBUG - 2018-08-03 02:01:03 --> UTF-8 Support Enabled
INFO - 2018-08-03 02:01:03 --> Utf8 Class Initialized
INFO - 2018-08-03 02:01:03 --> URI Class Initialized
INFO - 2018-08-03 02:01:03 --> Router Class Initialized
INFO - 2018-08-03 02:01:03 --> Output Class Initialized
INFO - 2018-08-03 02:01:03 --> URI Class Initialized
INFO - 2018-08-03 02:01:03 --> Security Class Initialized
INFO - 2018-08-03 02:01:03 --> Router Class Initialized
DEBUG - 2018-08-03 02:01:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 02:01:03 --> Input Class Initialized
INFO - 2018-08-03 02:01:03 --> Language Class Initialized
INFO - 2018-08-03 02:01:03 --> Output Class Initialized
INFO - 2018-08-03 02:01:03 --> Language Class Initialized
INFO - 2018-08-03 02:01:03 --> Config Class Initialized
INFO - 2018-08-03 02:01:03 --> Security Class Initialized
DEBUG - 2018-08-03 02:01:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 02:01:03 --> Loader Class Initialized
INFO - 2018-08-03 02:01:03 --> Input Class Initialized
DEBUG - 2018-08-03 02:01:03 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-03 02:01:03 --> Language Class Initialized
INFO - 2018-08-03 02:01:03 --> Helper loaded: url_helper
ERROR - 2018-08-03 02:01:03 --> 404 Page Not Found: /index
INFO - 2018-08-03 02:01:03 --> Helper loaded: form_helper
INFO - 2018-08-03 02:01:03 --> Helper loaded: date_helper
INFO - 2018-08-03 02:01:03 --> Config Class Initialized
INFO - 2018-08-03 02:01:03 --> Hooks Class Initialized
INFO - 2018-08-03 02:01:03 --> Helper loaded: util_helper
INFO - 2018-08-03 02:01:03 --> Helper loaded: text_helper
DEBUG - 2018-08-03 02:01:03 --> UTF-8 Support Enabled
INFO - 2018-08-03 02:01:03 --> Utf8 Class Initialized
INFO - 2018-08-03 02:01:03 --> Helper loaded: string_helper
INFO - 2018-08-03 02:01:03 --> URI Class Initialized
INFO - 2018-08-03 02:01:03 --> Database Driver Class Initialized
INFO - 2018-08-03 02:01:03 --> Router Class Initialized
DEBUG - 2018-08-03 02:01:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 02:01:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-03 02:01:03 --> Output Class Initialized
INFO - 2018-08-03 02:01:03 --> Security Class Initialized
INFO - 2018-08-03 02:01:03 --> Email Class Initialized
INFO - 2018-08-03 02:01:03 --> Controller Class Initialized
DEBUG - 2018-08-03 02:01:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-08-03 02:01:03 --> Home MX_Controller Initialized
INFO - 2018-08-03 02:01:03 --> Input Class Initialized
INFO - 2018-08-03 02:01:03 --> Language Class Initialized
DEBUG - 2018-08-03 02:01:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
ERROR - 2018-08-03 02:01:03 --> 404 Page Not Found: /index
DEBUG - 2018-08-03 02:01:03 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-03 02:01:03 --> Login MX_Controller Initialized
INFO - 2018-08-03 02:01:03 --> Config Class Initialized
INFO - 2018-08-03 02:01:03 --> Hooks Class Initialized
INFO - 2018-08-03 02:01:03 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-03 02:01:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-03 02:01:03 --> UTF-8 Support Enabled
INFO - 2018-08-03 02:01:03 --> Utf8 Class Initialized
DEBUG - 2018-08-03 02:01:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-03 02:01:03 --> URI Class Initialized
INFO - 2018-08-03 02:01:03 --> Router Class Initialized
INFO - 2018-08-03 02:01:03 --> Output Class Initialized
INFO - 2018-08-03 02:01:03 --> Security Class Initialized
DEBUG - 2018-08-03 02:01:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 02:01:03 --> Input Class Initialized
INFO - 2018-08-03 02:01:03 --> Language Class Initialized
ERROR - 2018-08-03 02:01:03 --> 404 Page Not Found: /index
INFO - 2018-08-03 02:01:06 --> Config Class Initialized
INFO - 2018-08-03 02:01:06 --> Hooks Class Initialized
DEBUG - 2018-08-03 02:01:06 --> UTF-8 Support Enabled
INFO - 2018-08-03 02:01:06 --> Utf8 Class Initialized
INFO - 2018-08-03 02:01:06 --> URI Class Initialized
INFO - 2018-08-03 02:01:06 --> Router Class Initialized
INFO - 2018-08-03 02:01:06 --> Output Class Initialized
INFO - 2018-08-03 02:01:06 --> Security Class Initialized
DEBUG - 2018-08-03 02:01:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 02:01:06 --> Input Class Initialized
INFO - 2018-08-03 02:01:06 --> Language Class Initialized
INFO - 2018-08-03 02:01:06 --> Language Class Initialized
INFO - 2018-08-03 02:01:06 --> Config Class Initialized
INFO - 2018-08-03 02:01:06 --> Loader Class Initialized
DEBUG - 2018-08-03 02:01:06 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-03 02:01:06 --> Helper loaded: url_helper
INFO - 2018-08-03 02:01:06 --> Helper loaded: form_helper
INFO - 2018-08-03 02:01:06 --> Helper loaded: date_helper
INFO - 2018-08-03 02:01:07 --> Helper loaded: util_helper
INFO - 2018-08-03 02:01:07 --> Helper loaded: text_helper
INFO - 2018-08-03 02:01:07 --> Helper loaded: string_helper
INFO - 2018-08-03 02:01:07 --> Database Driver Class Initialized
DEBUG - 2018-08-03 02:01:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 02:01:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-03 02:01:07 --> Email Class Initialized
INFO - 2018-08-03 02:01:07 --> Controller Class Initialized
DEBUG - 2018-08-03 02:01:07 --> Home MX_Controller Initialized
DEBUG - 2018-08-03 02:01:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-03 02:01:07 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-03 02:01:07 --> Login MX_Controller Initialized
INFO - 2018-08-03 02:01:07 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-03 02:01:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-03 02:01:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-03 02:01:09 --> Config Class Initialized
INFO - 2018-08-03 02:01:09 --> Hooks Class Initialized
DEBUG - 2018-08-03 02:01:09 --> UTF-8 Support Enabled
INFO - 2018-08-03 02:01:09 --> Utf8 Class Initialized
INFO - 2018-08-03 02:01:09 --> URI Class Initialized
INFO - 2018-08-03 02:01:09 --> Router Class Initialized
INFO - 2018-08-03 02:01:09 --> Output Class Initialized
INFO - 2018-08-03 02:01:09 --> Security Class Initialized
DEBUG - 2018-08-03 02:01:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 02:01:09 --> Input Class Initialized
INFO - 2018-08-03 02:01:09 --> Language Class Initialized
INFO - 2018-08-03 02:01:09 --> Language Class Initialized
INFO - 2018-08-03 02:01:09 --> Config Class Initialized
INFO - 2018-08-03 02:01:09 --> Loader Class Initialized
DEBUG - 2018-08-03 02:01:09 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-03 02:01:09 --> Helper loaded: url_helper
INFO - 2018-08-03 02:01:09 --> Helper loaded: form_helper
INFO - 2018-08-03 02:01:09 --> Helper loaded: date_helper
INFO - 2018-08-03 02:01:09 --> Helper loaded: util_helper
INFO - 2018-08-03 02:01:09 --> Helper loaded: text_helper
INFO - 2018-08-03 02:01:09 --> Helper loaded: string_helper
INFO - 2018-08-03 02:01:09 --> Database Driver Class Initialized
DEBUG - 2018-08-03 02:01:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 02:01:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-03 02:01:09 --> Email Class Initialized
INFO - 2018-08-03 02:01:09 --> Controller Class Initialized
DEBUG - 2018-08-03 02:01:09 --> Home MX_Controller Initialized
DEBUG - 2018-08-03 02:01:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-03 02:01:09 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-03 02:01:09 --> Login MX_Controller Initialized
INFO - 2018-08-03 02:01:09 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-03 02:01:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-03 02:01:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-03 02:01:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-08-03 02:01:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-08-03 02:01:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-08-03 02:01:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-08-03 02:01:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-08-03 02:01:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-08-03 02:01:09 --> Final output sent to browser
DEBUG - 2018-08-03 02:01:09 --> Total execution time: 0.5534
INFO - 2018-08-03 02:01:10 --> Config Class Initialized
INFO - 2018-08-03 02:01:10 --> Hooks Class Initialized
DEBUG - 2018-08-03 02:01:10 --> UTF-8 Support Enabled
INFO - 2018-08-03 02:01:10 --> Config Class Initialized
INFO - 2018-08-03 02:01:10 --> Hooks Class Initialized
INFO - 2018-08-03 02:01:10 --> Utf8 Class Initialized
INFO - 2018-08-03 02:01:10 --> URI Class Initialized
DEBUG - 2018-08-03 02:01:10 --> UTF-8 Support Enabled
INFO - 2018-08-03 02:01:10 --> Utf8 Class Initialized
INFO - 2018-08-03 02:01:10 --> Router Class Initialized
INFO - 2018-08-03 02:01:10 --> URI Class Initialized
INFO - 2018-08-03 02:01:10 --> Output Class Initialized
INFO - 2018-08-03 02:01:10 --> Router Class Initialized
INFO - 2018-08-03 02:01:10 --> Security Class Initialized
INFO - 2018-08-03 02:01:10 --> Output Class Initialized
DEBUG - 2018-08-03 02:01:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 02:01:10 --> Security Class Initialized
INFO - 2018-08-03 02:01:10 --> Input Class Initialized
INFO - 2018-08-03 02:01:10 --> Language Class Initialized
DEBUG - 2018-08-03 02:01:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 02:01:10 --> Input Class Initialized
ERROR - 2018-08-03 02:01:10 --> 404 Page Not Found: /index
INFO - 2018-08-03 02:01:10 --> Language Class Initialized
INFO - 2018-08-03 02:01:10 --> Config Class Initialized
INFO - 2018-08-03 02:01:10 --> Hooks Class Initialized
INFO - 2018-08-03 02:01:10 --> Language Class Initialized
INFO - 2018-08-03 02:01:10 --> Config Class Initialized
DEBUG - 2018-08-03 02:01:10 --> UTF-8 Support Enabled
INFO - 2018-08-03 02:01:10 --> Utf8 Class Initialized
INFO - 2018-08-03 02:01:10 --> Loader Class Initialized
DEBUG - 2018-08-03 02:01:10 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-03 02:01:10 --> URI Class Initialized
INFO - 2018-08-03 02:01:10 --> Helper loaded: url_helper
INFO - 2018-08-03 02:01:10 --> Router Class Initialized
INFO - 2018-08-03 02:01:10 --> Helper loaded: form_helper
INFO - 2018-08-03 02:01:10 --> Output Class Initialized
INFO - 2018-08-03 02:01:10 --> Helper loaded: date_helper
INFO - 2018-08-03 02:01:10 --> Security Class Initialized
INFO - 2018-08-03 02:01:10 --> Helper loaded: util_helper
DEBUG - 2018-08-03 02:01:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 02:01:10 --> Input Class Initialized
INFO - 2018-08-03 02:01:10 --> Helper loaded: text_helper
INFO - 2018-08-03 02:01:10 --> Language Class Initialized
INFO - 2018-08-03 02:01:10 --> Helper loaded: string_helper
ERROR - 2018-08-03 02:01:10 --> 404 Page Not Found: /index
INFO - 2018-08-03 02:01:10 --> Database Driver Class Initialized
DEBUG - 2018-08-03 02:01:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 02:01:10 --> Config Class Initialized
INFO - 2018-08-03 02:01:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-03 02:01:10 --> Hooks Class Initialized
INFO - 2018-08-03 02:01:10 --> Email Class Initialized
DEBUG - 2018-08-03 02:01:10 --> UTF-8 Support Enabled
INFO - 2018-08-03 02:01:10 --> Controller Class Initialized
INFO - 2018-08-03 02:01:11 --> Utf8 Class Initialized
DEBUG - 2018-08-03 02:01:11 --> Home MX_Controller Initialized
INFO - 2018-08-03 02:01:11 --> URI Class Initialized
DEBUG - 2018-08-03 02:01:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-08-03 02:01:11 --> Router Class Initialized
INFO - 2018-08-03 02:01:11 --> Output Class Initialized
DEBUG - 2018-08-03 02:01:11 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-03 02:01:11 --> Login MX_Controller Initialized
INFO - 2018-08-03 02:01:11 --> Security Class Initialized
INFO - 2018-08-03 02:01:11 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-03 02:01:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 02:01:11 --> Input Class Initialized
DEBUG - 2018-08-03 02:01:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-08-03 02:01:11 --> Language Class Initialized
DEBUG - 2018-08-03 02:01:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
ERROR - 2018-08-03 02:01:11 --> 404 Page Not Found: /index
INFO - 2018-08-03 02:16:32 --> Config Class Initialized
INFO - 2018-08-03 02:16:32 --> Hooks Class Initialized
DEBUG - 2018-08-03 02:16:32 --> UTF-8 Support Enabled
INFO - 2018-08-03 02:16:32 --> Utf8 Class Initialized
INFO - 2018-08-03 02:16:32 --> URI Class Initialized
INFO - 2018-08-03 02:16:32 --> Router Class Initialized
INFO - 2018-08-03 02:16:32 --> Output Class Initialized
INFO - 2018-08-03 02:16:32 --> Security Class Initialized
DEBUG - 2018-08-03 02:16:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 02:16:32 --> Input Class Initialized
INFO - 2018-08-03 02:16:32 --> Language Class Initialized
INFO - 2018-08-03 02:16:32 --> Language Class Initialized
INFO - 2018-08-03 02:16:32 --> Config Class Initialized
INFO - 2018-08-03 02:16:32 --> Loader Class Initialized
DEBUG - 2018-08-03 02:16:32 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-03 02:16:32 --> Helper loaded: url_helper
INFO - 2018-08-03 02:16:32 --> Helper loaded: form_helper
INFO - 2018-08-03 02:16:32 --> Helper loaded: date_helper
INFO - 2018-08-03 02:16:32 --> Helper loaded: util_helper
INFO - 2018-08-03 02:16:32 --> Helper loaded: text_helper
INFO - 2018-08-03 02:16:32 --> Helper loaded: string_helper
INFO - 2018-08-03 02:16:32 --> Database Driver Class Initialized
DEBUG - 2018-08-03 02:16:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 02:16:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-03 02:16:32 --> Email Class Initialized
INFO - 2018-08-03 02:16:32 --> Controller Class Initialized
DEBUG - 2018-08-03 02:16:32 --> Home MX_Controller Initialized
DEBUG - 2018-08-03 02:16:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-03 02:16:32 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-03 02:16:32 --> Login MX_Controller Initialized
INFO - 2018-08-03 02:16:32 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-03 02:16:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-03 02:16:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-03 02:16:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-08-03 02:16:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-08-03 02:16:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-08-03 02:16:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-08-03 02:16:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-08-03 02:16:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-08-03 02:16:32 --> Final output sent to browser
DEBUG - 2018-08-03 02:16:32 --> Total execution time: 0.5779
INFO - 2018-08-03 02:16:34 --> Config Class Initialized
INFO - 2018-08-03 02:16:34 --> Hooks Class Initialized
DEBUG - 2018-08-03 02:16:34 --> UTF-8 Support Enabled
INFO - 2018-08-03 02:16:34 --> Utf8 Class Initialized
INFO - 2018-08-03 02:16:34 --> URI Class Initialized
INFO - 2018-08-03 02:16:34 --> Config Class Initialized
INFO - 2018-08-03 02:16:34 --> Router Class Initialized
INFO - 2018-08-03 02:16:34 --> Hooks Class Initialized
INFO - 2018-08-03 02:16:34 --> Output Class Initialized
DEBUG - 2018-08-03 02:16:34 --> UTF-8 Support Enabled
INFO - 2018-08-03 02:16:34 --> Utf8 Class Initialized
INFO - 2018-08-03 02:16:34 --> Security Class Initialized
INFO - 2018-08-03 02:16:34 --> URI Class Initialized
INFO - 2018-08-03 02:16:34 --> Router Class Initialized
DEBUG - 2018-08-03 02:16:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 02:16:34 --> Output Class Initialized
INFO - 2018-08-03 02:16:34 --> Input Class Initialized
INFO - 2018-08-03 02:16:34 --> Security Class Initialized
INFO - 2018-08-03 02:16:34 --> Language Class Initialized
ERROR - 2018-08-03 02:16:34 --> 404 Page Not Found: /index
DEBUG - 2018-08-03 02:16:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 02:16:34 --> Input Class Initialized
INFO - 2018-08-03 02:16:34 --> Language Class Initialized
INFO - 2018-08-03 02:16:34 --> Language Class Initialized
INFO - 2018-08-03 02:16:34 --> Config Class Initialized
INFO - 2018-08-03 02:16:34 --> Loader Class Initialized
DEBUG - 2018-08-03 02:16:34 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-03 02:16:34 --> Helper loaded: url_helper
INFO - 2018-08-03 02:16:34 --> Helper loaded: form_helper
INFO - 2018-08-03 02:16:35 --> Helper loaded: date_helper
INFO - 2018-08-03 02:16:35 --> Helper loaded: util_helper
INFO - 2018-08-03 02:16:35 --> Config Class Initialized
INFO - 2018-08-03 02:16:35 --> Hooks Class Initialized
INFO - 2018-08-03 02:16:35 --> Helper loaded: text_helper
DEBUG - 2018-08-03 02:16:35 --> UTF-8 Support Enabled
INFO - 2018-08-03 02:16:35 --> Utf8 Class Initialized
INFO - 2018-08-03 02:16:35 --> URI Class Initialized
INFO - 2018-08-03 02:16:35 --> Router Class Initialized
INFO - 2018-08-03 02:16:35 --> Output Class Initialized
INFO - 2018-08-03 02:16:35 --> Security Class Initialized
DEBUG - 2018-08-03 02:16:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 02:16:35 --> Input Class Initialized
INFO - 2018-08-03 02:16:35 --> Language Class Initialized
INFO - 2018-08-03 02:16:35 --> Helper loaded: string_helper
ERROR - 2018-08-03 02:16:35 --> 404 Page Not Found: /index
INFO - 2018-08-03 02:16:35 --> Config Class Initialized
INFO - 2018-08-03 02:16:35 --> Database Driver Class Initialized
INFO - 2018-08-03 02:16:35 --> Hooks Class Initialized
DEBUG - 2018-08-03 02:16:35 --> UTF-8 Support Enabled
INFO - 2018-08-03 02:16:35 --> Utf8 Class Initialized
INFO - 2018-08-03 02:16:35 --> URI Class Initialized
INFO - 2018-08-03 02:16:35 --> Router Class Initialized
INFO - 2018-08-03 02:16:35 --> Output Class Initialized
DEBUG - 2018-08-03 02:16:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 02:16:35 --> Security Class Initialized
INFO - 2018-08-03 02:16:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-03 02:16:35 --> Email Class Initialized
INFO - 2018-08-03 02:16:35 --> Controller Class Initialized
DEBUG - 2018-08-03 02:16:35 --> Home MX_Controller Initialized
DEBUG - 2018-08-03 02:16:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 02:16:35 --> Input Class Initialized
DEBUG - 2018-08-03 02:16:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-08-03 02:16:35 --> Language Class Initialized
ERROR - 2018-08-03 02:16:35 --> 404 Page Not Found: /index
DEBUG - 2018-08-03 02:16:35 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-03 02:16:35 --> Login MX_Controller Initialized
INFO - 2018-08-03 02:16:36 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-03 02:16:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-03 02:16:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-03 02:16:44 --> Config Class Initialized
INFO - 2018-08-03 02:16:44 --> Hooks Class Initialized
DEBUG - 2018-08-03 02:16:44 --> UTF-8 Support Enabled
INFO - 2018-08-03 02:16:44 --> Utf8 Class Initialized
INFO - 2018-08-03 02:16:44 --> URI Class Initialized
INFO - 2018-08-03 02:16:44 --> Router Class Initialized
INFO - 2018-08-03 02:16:44 --> Output Class Initialized
INFO - 2018-08-03 02:16:44 --> Security Class Initialized
DEBUG - 2018-08-03 02:16:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 02:16:44 --> Input Class Initialized
INFO - 2018-08-03 02:16:44 --> Language Class Initialized
INFO - 2018-08-03 02:16:44 --> Language Class Initialized
INFO - 2018-08-03 02:16:44 --> Config Class Initialized
INFO - 2018-08-03 02:16:44 --> Loader Class Initialized
DEBUG - 2018-08-03 02:16:44 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-03 02:16:44 --> Helper loaded: url_helper
INFO - 2018-08-03 02:16:44 --> Helper loaded: form_helper
INFO - 2018-08-03 02:16:44 --> Helper loaded: date_helper
INFO - 2018-08-03 02:16:44 --> Helper loaded: util_helper
INFO - 2018-08-03 02:16:44 --> Helper loaded: text_helper
INFO - 2018-08-03 02:16:44 --> Helper loaded: string_helper
INFO - 2018-08-03 02:16:44 --> Database Driver Class Initialized
DEBUG - 2018-08-03 02:16:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 02:16:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-03 02:16:44 --> Email Class Initialized
INFO - 2018-08-03 02:16:44 --> Controller Class Initialized
DEBUG - 2018-08-03 02:16:44 --> Home MX_Controller Initialized
DEBUG - 2018-08-03 02:16:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-03 02:16:44 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-03 02:16:44 --> Login MX_Controller Initialized
INFO - 2018-08-03 02:16:44 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-03 02:16:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-03 02:16:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-03 02:16:47 --> Config Class Initialized
INFO - 2018-08-03 02:16:47 --> Hooks Class Initialized
DEBUG - 2018-08-03 02:16:47 --> UTF-8 Support Enabled
INFO - 2018-08-03 02:16:47 --> Utf8 Class Initialized
INFO - 2018-08-03 02:16:47 --> URI Class Initialized
INFO - 2018-08-03 02:16:47 --> Router Class Initialized
INFO - 2018-08-03 02:16:47 --> Output Class Initialized
INFO - 2018-08-03 02:16:47 --> Security Class Initialized
DEBUG - 2018-08-03 02:16:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 02:16:47 --> Input Class Initialized
INFO - 2018-08-03 02:16:47 --> Language Class Initialized
INFO - 2018-08-03 02:16:47 --> Language Class Initialized
INFO - 2018-08-03 02:16:47 --> Config Class Initialized
INFO - 2018-08-03 02:16:47 --> Loader Class Initialized
DEBUG - 2018-08-03 02:16:47 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-03 02:16:47 --> Helper loaded: url_helper
INFO - 2018-08-03 02:16:47 --> Helper loaded: form_helper
INFO - 2018-08-03 02:16:47 --> Helper loaded: date_helper
INFO - 2018-08-03 02:16:47 --> Helper loaded: util_helper
INFO - 2018-08-03 02:16:47 --> Helper loaded: text_helper
INFO - 2018-08-03 02:16:47 --> Helper loaded: string_helper
INFO - 2018-08-03 02:16:47 --> Database Driver Class Initialized
DEBUG - 2018-08-03 02:16:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 02:16:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-03 02:16:48 --> Email Class Initialized
INFO - 2018-08-03 02:16:48 --> Controller Class Initialized
DEBUG - 2018-08-03 02:16:48 --> Home MX_Controller Initialized
DEBUG - 2018-08-03 02:16:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-03 02:16:48 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-03 02:16:48 --> Login MX_Controller Initialized
INFO - 2018-08-03 02:16:48 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-03 02:16:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-03 02:16:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-03 02:16:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-08-03 02:16:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-08-03 02:16:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-08-03 02:16:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-08-03 02:16:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-08-03 02:16:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-08-03 02:16:48 --> Final output sent to browser
DEBUG - 2018-08-03 02:16:48 --> Total execution time: 0.6695
INFO - 2018-08-03 02:16:48 --> Config Class Initialized
INFO - 2018-08-03 02:16:49 --> Hooks Class Initialized
DEBUG - 2018-08-03 02:16:49 --> UTF-8 Support Enabled
INFO - 2018-08-03 02:16:49 --> Utf8 Class Initialized
INFO - 2018-08-03 02:16:49 --> URI Class Initialized
INFO - 2018-08-03 02:16:49 --> Config Class Initialized
INFO - 2018-08-03 02:16:49 --> Hooks Class Initialized
INFO - 2018-08-03 02:16:49 --> Router Class Initialized
INFO - 2018-08-03 02:16:49 --> Output Class Initialized
DEBUG - 2018-08-03 02:16:49 --> UTF-8 Support Enabled
INFO - 2018-08-03 02:16:49 --> Utf8 Class Initialized
INFO - 2018-08-03 02:16:49 --> Security Class Initialized
INFO - 2018-08-03 02:16:49 --> URI Class Initialized
DEBUG - 2018-08-03 02:16:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 02:16:49 --> Router Class Initialized
INFO - 2018-08-03 02:16:49 --> Input Class Initialized
INFO - 2018-08-03 02:16:49 --> Output Class Initialized
INFO - 2018-08-03 02:16:49 --> Language Class Initialized
INFO - 2018-08-03 02:16:49 --> Security Class Initialized
ERROR - 2018-08-03 02:16:49 --> 404 Page Not Found: /index
DEBUG - 2018-08-03 02:16:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 02:16:49 --> Config Class Initialized
INFO - 2018-08-03 02:16:49 --> Hooks Class Initialized
INFO - 2018-08-03 02:16:49 --> Input Class Initialized
DEBUG - 2018-08-03 02:16:49 --> UTF-8 Support Enabled
INFO - 2018-08-03 02:16:49 --> Utf8 Class Initialized
INFO - 2018-08-03 02:16:49 --> URI Class Initialized
INFO - 2018-08-03 02:16:49 --> Router Class Initialized
INFO - 2018-08-03 02:16:49 --> Output Class Initialized
INFO - 2018-08-03 02:16:49 --> Security Class Initialized
DEBUG - 2018-08-03 02:16:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 02:16:49 --> Input Class Initialized
INFO - 2018-08-03 02:16:49 --> Language Class Initialized
INFO - 2018-08-03 02:16:49 --> Language Class Initialized
ERROR - 2018-08-03 02:16:49 --> 404 Page Not Found: /index
INFO - 2018-08-03 02:16:49 --> Language Class Initialized
INFO - 2018-08-03 02:16:49 --> Config Class Initialized
INFO - 2018-08-03 02:16:49 --> Config Class Initialized
INFO - 2018-08-03 02:16:49 --> Hooks Class Initialized
INFO - 2018-08-03 02:16:49 --> Loader Class Initialized
DEBUG - 2018-08-03 02:16:49 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
DEBUG - 2018-08-03 02:16:49 --> UTF-8 Support Enabled
INFO - 2018-08-03 02:16:49 --> Helper loaded: url_helper
INFO - 2018-08-03 02:16:49 --> Helper loaded: form_helper
INFO - 2018-08-03 02:16:49 --> Helper loaded: date_helper
INFO - 2018-08-03 02:16:50 --> Utf8 Class Initialized
INFO - 2018-08-03 02:16:50 --> Helper loaded: util_helper
INFO - 2018-08-03 02:16:50 --> URI Class Initialized
INFO - 2018-08-03 02:16:50 --> Helper loaded: text_helper
INFO - 2018-08-03 02:16:50 --> Router Class Initialized
INFO - 2018-08-03 02:16:50 --> Helper loaded: string_helper
INFO - 2018-08-03 02:16:50 --> Database Driver Class Initialized
INFO - 2018-08-03 02:16:50 --> Output Class Initialized
INFO - 2018-08-03 02:16:50 --> Security Class Initialized
DEBUG - 2018-08-03 02:16:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 02:16:50 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-08-03 02:16:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 02:16:50 --> Email Class Initialized
INFO - 2018-08-03 02:16:50 --> Controller Class Initialized
INFO - 2018-08-03 02:16:50 --> Input Class Initialized
DEBUG - 2018-08-03 02:16:50 --> Home MX_Controller Initialized
INFO - 2018-08-03 02:16:50 --> Language Class Initialized
ERROR - 2018-08-03 02:16:50 --> 404 Page Not Found: /index
DEBUG - 2018-08-03 02:16:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-03 02:16:50 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-03 02:16:50 --> Login MX_Controller Initialized
INFO - 2018-08-03 02:16:50 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-03 02:16:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-03 02:16:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-03 02:21:25 --> Config Class Initialized
INFO - 2018-08-03 02:21:25 --> Hooks Class Initialized
DEBUG - 2018-08-03 02:21:25 --> UTF-8 Support Enabled
INFO - 2018-08-03 02:21:25 --> Utf8 Class Initialized
INFO - 2018-08-03 02:21:25 --> URI Class Initialized
INFO - 2018-08-03 02:21:25 --> Router Class Initialized
INFO - 2018-08-03 02:21:25 --> Output Class Initialized
INFO - 2018-08-03 02:21:25 --> Security Class Initialized
DEBUG - 2018-08-03 02:21:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 02:21:25 --> Input Class Initialized
INFO - 2018-08-03 02:21:25 --> Language Class Initialized
INFO - 2018-08-03 02:21:25 --> Language Class Initialized
INFO - 2018-08-03 02:21:25 --> Config Class Initialized
INFO - 2018-08-03 02:21:25 --> Loader Class Initialized
DEBUG - 2018-08-03 02:21:25 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-03 02:21:25 --> Helper loaded: url_helper
INFO - 2018-08-03 02:21:25 --> Helper loaded: form_helper
INFO - 2018-08-03 02:21:25 --> Helper loaded: date_helper
INFO - 2018-08-03 02:21:25 --> Helper loaded: util_helper
INFO - 2018-08-03 02:21:25 --> Helper loaded: text_helper
INFO - 2018-08-03 02:21:25 --> Helper loaded: string_helper
INFO - 2018-08-03 02:21:25 --> Database Driver Class Initialized
DEBUG - 2018-08-03 02:21:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 02:21:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-03 02:21:26 --> Email Class Initialized
INFO - 2018-08-03 02:21:26 --> Controller Class Initialized
DEBUG - 2018-08-03 02:21:26 --> Home MX_Controller Initialized
DEBUG - 2018-08-03 02:21:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-03 02:21:26 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-03 02:21:26 --> Login MX_Controller Initialized
INFO - 2018-08-03 02:21:26 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-03 02:21:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-03 02:21:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-03 02:21:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-08-03 02:21:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-08-03 02:21:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-08-03 02:21:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-08-03 02:21:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-08-03 02:21:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-08-03 02:21:26 --> Final output sent to browser
DEBUG - 2018-08-03 02:21:26 --> Total execution time: 0.5946
INFO - 2018-08-03 02:21:27 --> Config Class Initialized
INFO - 2018-08-03 02:21:27 --> Hooks Class Initialized
DEBUG - 2018-08-03 02:21:27 --> UTF-8 Support Enabled
INFO - 2018-08-03 02:21:27 --> Utf8 Class Initialized
INFO - 2018-08-03 02:21:27 --> URI Class Initialized
INFO - 2018-08-03 02:21:27 --> Router Class Initialized
INFO - 2018-08-03 02:21:27 --> Config Class Initialized
INFO - 2018-08-03 02:21:27 --> Hooks Class Initialized
INFO - 2018-08-03 02:21:27 --> Output Class Initialized
DEBUG - 2018-08-03 02:21:27 --> UTF-8 Support Enabled
INFO - 2018-08-03 02:21:27 --> Utf8 Class Initialized
INFO - 2018-08-03 02:21:27 --> URI Class Initialized
INFO - 2018-08-03 02:21:27 --> Security Class Initialized
INFO - 2018-08-03 02:21:27 --> Router Class Initialized
DEBUG - 2018-08-03 02:21:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 02:21:27 --> Input Class Initialized
INFO - 2018-08-03 02:21:27 --> Language Class Initialized
ERROR - 2018-08-03 02:21:27 --> 404 Page Not Found: /index
INFO - 2018-08-03 02:21:27 --> Output Class Initialized
INFO - 2018-08-03 02:21:27 --> Security Class Initialized
INFO - 2018-08-03 02:21:27 --> Config Class Initialized
INFO - 2018-08-03 02:21:27 --> Hooks Class Initialized
DEBUG - 2018-08-03 02:21:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-08-03 02:21:27 --> UTF-8 Support Enabled
INFO - 2018-08-03 02:21:27 --> Utf8 Class Initialized
INFO - 2018-08-03 02:21:27 --> URI Class Initialized
INFO - 2018-08-03 02:21:27 --> Router Class Initialized
INFO - 2018-08-03 02:21:27 --> Output Class Initialized
INFO - 2018-08-03 02:21:27 --> Security Class Initialized
DEBUG - 2018-08-03 02:21:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 02:21:27 --> Input Class Initialized
INFO - 2018-08-03 02:21:27 --> Input Class Initialized
INFO - 2018-08-03 02:21:27 --> Language Class Initialized
INFO - 2018-08-03 02:21:27 --> Language Class Initialized
ERROR - 2018-08-03 02:21:27 --> 404 Page Not Found: /index
INFO - 2018-08-03 02:21:27 --> Language Class Initialized
INFO - 2018-08-03 02:21:27 --> Config Class Initialized
INFO - 2018-08-03 02:21:27 --> Config Class Initialized
INFO - 2018-08-03 02:21:27 --> Hooks Class Initialized
INFO - 2018-08-03 02:21:27 --> Loader Class Initialized
DEBUG - 2018-08-03 02:21:27 --> UTF-8 Support Enabled
INFO - 2018-08-03 02:21:27 --> Utf8 Class Initialized
INFO - 2018-08-03 02:21:27 --> URI Class Initialized
DEBUG - 2018-08-03 02:21:28 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-03 02:21:28 --> Router Class Initialized
INFO - 2018-08-03 02:21:28 --> Helper loaded: url_helper
INFO - 2018-08-03 02:21:28 --> Helper loaded: form_helper
INFO - 2018-08-03 02:21:28 --> Output Class Initialized
INFO - 2018-08-03 02:21:28 --> Helper loaded: date_helper
INFO - 2018-08-03 02:21:28 --> Security Class Initialized
DEBUG - 2018-08-03 02:21:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 02:21:28 --> Input Class Initialized
INFO - 2018-08-03 02:21:28 --> Helper loaded: util_helper
INFO - 2018-08-03 02:21:28 --> Helper loaded: text_helper
INFO - 2018-08-03 02:21:28 --> Language Class Initialized
INFO - 2018-08-03 02:21:28 --> Helper loaded: string_helper
ERROR - 2018-08-03 02:21:28 --> 404 Page Not Found: /index
INFO - 2018-08-03 02:21:28 --> Database Driver Class Initialized
DEBUG - 2018-08-03 02:21:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 02:21:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-03 02:21:28 --> Email Class Initialized
INFO - 2018-08-03 02:21:28 --> Controller Class Initialized
DEBUG - 2018-08-03 02:21:28 --> Home MX_Controller Initialized
DEBUG - 2018-08-03 02:21:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-03 02:21:28 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-03 02:21:28 --> Login MX_Controller Initialized
INFO - 2018-08-03 02:21:28 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-03 02:21:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-03 02:21:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-03 02:21:36 --> Config Class Initialized
INFO - 2018-08-03 02:21:36 --> Hooks Class Initialized
DEBUG - 2018-08-03 02:21:36 --> UTF-8 Support Enabled
INFO - 2018-08-03 02:21:36 --> Utf8 Class Initialized
INFO - 2018-08-03 02:21:36 --> URI Class Initialized
INFO - 2018-08-03 02:21:36 --> Router Class Initialized
INFO - 2018-08-03 02:21:36 --> Output Class Initialized
INFO - 2018-08-03 02:21:36 --> Security Class Initialized
DEBUG - 2018-08-03 02:21:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 02:21:36 --> Input Class Initialized
INFO - 2018-08-03 02:21:36 --> Language Class Initialized
INFO - 2018-08-03 02:21:36 --> Language Class Initialized
INFO - 2018-08-03 02:21:36 --> Config Class Initialized
INFO - 2018-08-03 02:21:36 --> Loader Class Initialized
DEBUG - 2018-08-03 02:21:36 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-03 02:21:36 --> Helper loaded: url_helper
INFO - 2018-08-03 02:21:36 --> Helper loaded: form_helper
INFO - 2018-08-03 02:21:36 --> Helper loaded: date_helper
INFO - 2018-08-03 02:21:36 --> Helper loaded: util_helper
INFO - 2018-08-03 02:21:36 --> Helper loaded: text_helper
INFO - 2018-08-03 02:21:36 --> Helper loaded: string_helper
INFO - 2018-08-03 02:21:36 --> Database Driver Class Initialized
DEBUG - 2018-08-03 02:21:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 02:21:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-03 02:21:36 --> Email Class Initialized
INFO - 2018-08-03 02:21:36 --> Controller Class Initialized
DEBUG - 2018-08-03 02:21:36 --> Home MX_Controller Initialized
DEBUG - 2018-08-03 02:21:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-03 02:21:36 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-03 02:21:36 --> Login MX_Controller Initialized
INFO - 2018-08-03 02:21:36 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-03 02:21:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-03 02:21:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-03 02:21:38 --> Config Class Initialized
INFO - 2018-08-03 02:21:38 --> Hooks Class Initialized
DEBUG - 2018-08-03 02:21:38 --> UTF-8 Support Enabled
INFO - 2018-08-03 02:21:38 --> Utf8 Class Initialized
INFO - 2018-08-03 02:21:38 --> URI Class Initialized
INFO - 2018-08-03 02:21:38 --> Router Class Initialized
INFO - 2018-08-03 02:21:38 --> Output Class Initialized
INFO - 2018-08-03 02:21:38 --> Security Class Initialized
DEBUG - 2018-08-03 02:21:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 02:21:38 --> Input Class Initialized
INFO - 2018-08-03 02:21:38 --> Language Class Initialized
INFO - 2018-08-03 02:21:38 --> Language Class Initialized
INFO - 2018-08-03 02:21:38 --> Config Class Initialized
INFO - 2018-08-03 02:21:38 --> Loader Class Initialized
DEBUG - 2018-08-03 02:21:38 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-03 02:21:38 --> Helper loaded: url_helper
INFO - 2018-08-03 02:21:38 --> Helper loaded: form_helper
INFO - 2018-08-03 02:21:38 --> Helper loaded: date_helper
INFO - 2018-08-03 02:21:38 --> Helper loaded: util_helper
INFO - 2018-08-03 02:21:38 --> Helper loaded: text_helper
INFO - 2018-08-03 02:21:38 --> Helper loaded: string_helper
INFO - 2018-08-03 02:21:38 --> Database Driver Class Initialized
DEBUG - 2018-08-03 02:21:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 02:21:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-03 02:21:38 --> Email Class Initialized
INFO - 2018-08-03 02:21:38 --> Controller Class Initialized
DEBUG - 2018-08-03 02:21:38 --> Home MX_Controller Initialized
DEBUG - 2018-08-03 02:21:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-03 02:21:38 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-03 02:21:38 --> Login MX_Controller Initialized
INFO - 2018-08-03 02:21:38 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-03 02:21:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-03 02:21:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-03 02:21:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-08-03 02:21:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-08-03 02:21:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-08-03 02:21:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-08-03 02:21:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-08-03 02:21:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-08-03 02:21:38 --> Final output sent to browser
DEBUG - 2018-08-03 02:21:38 --> Total execution time: 0.6759
INFO - 2018-08-03 02:21:39 --> Config Class Initialized
INFO - 2018-08-03 02:21:39 --> Hooks Class Initialized
DEBUG - 2018-08-03 02:21:39 --> UTF-8 Support Enabled
INFO - 2018-08-03 02:21:39 --> Utf8 Class Initialized
INFO - 2018-08-03 02:21:39 --> Config Class Initialized
INFO - 2018-08-03 02:21:39 --> Hooks Class Initialized
INFO - 2018-08-03 02:21:39 --> URI Class Initialized
DEBUG - 2018-08-03 02:21:39 --> UTF-8 Support Enabled
INFO - 2018-08-03 02:21:39 --> Utf8 Class Initialized
INFO - 2018-08-03 02:21:39 --> Router Class Initialized
INFO - 2018-08-03 02:21:39 --> URI Class Initialized
INFO - 2018-08-03 02:21:39 --> Output Class Initialized
INFO - 2018-08-03 02:21:39 --> Security Class Initialized
INFO - 2018-08-03 02:21:39 --> Router Class Initialized
DEBUG - 2018-08-03 02:21:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 02:21:39 --> Input Class Initialized
INFO - 2018-08-03 02:21:39 --> Output Class Initialized
INFO - 2018-08-03 02:21:39 --> Language Class Initialized
INFO - 2018-08-03 02:21:39 --> Security Class Initialized
ERROR - 2018-08-03 02:21:39 --> 404 Page Not Found: /index
DEBUG - 2018-08-03 02:21:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 02:21:39 --> Input Class Initialized
INFO - 2018-08-03 02:21:39 --> Config Class Initialized
INFO - 2018-08-03 02:21:39 --> Hooks Class Initialized
INFO - 2018-08-03 02:21:39 --> Language Class Initialized
DEBUG - 2018-08-03 02:21:39 --> UTF-8 Support Enabled
INFO - 2018-08-03 02:21:39 --> Language Class Initialized
INFO - 2018-08-03 02:21:39 --> Utf8 Class Initialized
INFO - 2018-08-03 02:21:39 --> Config Class Initialized
INFO - 2018-08-03 02:21:39 --> URI Class Initialized
INFO - 2018-08-03 02:21:39 --> Router Class Initialized
INFO - 2018-08-03 02:21:39 --> Loader Class Initialized
INFO - 2018-08-03 02:21:39 --> Output Class Initialized
DEBUG - 2018-08-03 02:21:39 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-03 02:21:39 --> Security Class Initialized
INFO - 2018-08-03 02:21:39 --> Helper loaded: url_helper
INFO - 2018-08-03 02:21:39 --> Helper loaded: form_helper
DEBUG - 2018-08-03 02:21:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 02:21:39 --> Helper loaded: date_helper
INFO - 2018-08-03 02:21:39 --> Input Class Initialized
INFO - 2018-08-03 02:21:39 --> Helper loaded: util_helper
INFO - 2018-08-03 02:21:39 --> Language Class Initialized
ERROR - 2018-08-03 02:21:39 --> 404 Page Not Found: /index
INFO - 2018-08-03 02:21:39 --> Helper loaded: text_helper
INFO - 2018-08-03 02:21:39 --> Helper loaded: string_helper
INFO - 2018-08-03 02:21:40 --> Config Class Initialized
INFO - 2018-08-03 02:21:40 --> Hooks Class Initialized
INFO - 2018-08-03 02:21:40 --> Database Driver Class Initialized
DEBUG - 2018-08-03 02:21:40 --> UTF-8 Support Enabled
DEBUG - 2018-08-03 02:21:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 02:21:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-03 02:21:40 --> Utf8 Class Initialized
INFO - 2018-08-03 02:21:40 --> URI Class Initialized
INFO - 2018-08-03 02:21:40 --> Email Class Initialized
INFO - 2018-08-03 02:21:40 --> Controller Class Initialized
INFO - 2018-08-03 02:21:40 --> Router Class Initialized
DEBUG - 2018-08-03 02:21:40 --> Home MX_Controller Initialized
INFO - 2018-08-03 02:21:40 --> Output Class Initialized
INFO - 2018-08-03 02:21:40 --> Security Class Initialized
DEBUG - 2018-08-03 02:21:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-03 02:21:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-08-03 02:21:40 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-03 02:21:40 --> Login MX_Controller Initialized
INFO - 2018-08-03 02:21:40 --> Input Class Initialized
INFO - 2018-08-03 02:21:40 --> Language file loaded: language/english/data_lang.php
INFO - 2018-08-03 02:21:40 --> Language Class Initialized
DEBUG - 2018-08-03 02:21:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
ERROR - 2018-08-03 02:21:40 --> 404 Page Not Found: /index
DEBUG - 2018-08-03 02:21:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-03 02:21:46 --> Config Class Initialized
INFO - 2018-08-03 02:21:46 --> Hooks Class Initialized
DEBUG - 2018-08-03 02:21:46 --> UTF-8 Support Enabled
INFO - 2018-08-03 02:21:46 --> Utf8 Class Initialized
INFO - 2018-08-03 02:21:46 --> URI Class Initialized
INFO - 2018-08-03 02:21:46 --> Router Class Initialized
INFO - 2018-08-03 02:21:46 --> Output Class Initialized
INFO - 2018-08-03 02:21:46 --> Security Class Initialized
DEBUG - 2018-08-03 02:21:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 02:21:46 --> Input Class Initialized
INFO - 2018-08-03 02:21:46 --> Language Class Initialized
INFO - 2018-08-03 02:21:46 --> Language Class Initialized
INFO - 2018-08-03 02:21:46 --> Config Class Initialized
INFO - 2018-08-03 02:21:46 --> Loader Class Initialized
DEBUG - 2018-08-03 02:21:46 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-03 02:21:46 --> Helper loaded: url_helper
INFO - 2018-08-03 02:21:46 --> Helper loaded: form_helper
INFO - 2018-08-03 02:21:46 --> Helper loaded: date_helper
INFO - 2018-08-03 02:21:46 --> Helper loaded: util_helper
INFO - 2018-08-03 02:21:46 --> Helper loaded: text_helper
INFO - 2018-08-03 02:21:46 --> Helper loaded: string_helper
INFO - 2018-08-03 02:21:46 --> Database Driver Class Initialized
DEBUG - 2018-08-03 02:21:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 02:21:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-03 02:21:46 --> Email Class Initialized
INFO - 2018-08-03 02:21:46 --> Controller Class Initialized
DEBUG - 2018-08-03 02:21:46 --> Home MX_Controller Initialized
DEBUG - 2018-08-03 02:21:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-03 02:21:46 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-03 02:21:46 --> Login MX_Controller Initialized
INFO - 2018-08-03 02:21:46 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-03 02:21:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-03 02:21:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-03 02:21:51 --> Config Class Initialized
INFO - 2018-08-03 02:21:51 --> Hooks Class Initialized
DEBUG - 2018-08-03 02:21:51 --> UTF-8 Support Enabled
INFO - 2018-08-03 02:21:51 --> Utf8 Class Initialized
INFO - 2018-08-03 02:21:51 --> URI Class Initialized
INFO - 2018-08-03 02:21:51 --> Router Class Initialized
INFO - 2018-08-03 02:21:51 --> Output Class Initialized
INFO - 2018-08-03 02:21:51 --> Security Class Initialized
DEBUG - 2018-08-03 02:21:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 02:21:51 --> Input Class Initialized
INFO - 2018-08-03 02:21:51 --> Language Class Initialized
INFO - 2018-08-03 02:21:51 --> Language Class Initialized
INFO - 2018-08-03 02:21:51 --> Config Class Initialized
INFO - 2018-08-03 02:21:51 --> Loader Class Initialized
DEBUG - 2018-08-03 02:21:51 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-03 02:21:51 --> Helper loaded: url_helper
INFO - 2018-08-03 02:21:51 --> Helper loaded: form_helper
INFO - 2018-08-03 02:21:51 --> Helper loaded: date_helper
INFO - 2018-08-03 02:21:51 --> Helper loaded: util_helper
INFO - 2018-08-03 02:21:51 --> Helper loaded: text_helper
INFO - 2018-08-03 02:21:51 --> Helper loaded: string_helper
INFO - 2018-08-03 02:21:52 --> Database Driver Class Initialized
DEBUG - 2018-08-03 02:21:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 02:21:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-03 02:21:52 --> Email Class Initialized
INFO - 2018-08-03 02:21:52 --> Controller Class Initialized
DEBUG - 2018-08-03 02:21:52 --> Home MX_Controller Initialized
DEBUG - 2018-08-03 02:21:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-03 02:21:52 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-03 02:21:52 --> Login MX_Controller Initialized
INFO - 2018-08-03 02:21:52 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-03 02:21:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-03 02:21:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-03 02:21:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-08-03 02:21:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-08-03 02:21:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-08-03 02:21:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-08-03 02:21:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-08-03 02:21:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-08-03 02:21:52 --> Final output sent to browser
DEBUG - 2018-08-03 02:21:52 --> Total execution time: 0.5708
INFO - 2018-08-03 02:21:52 --> Config Class Initialized
INFO - 2018-08-03 02:21:52 --> Hooks Class Initialized
DEBUG - 2018-08-03 02:21:52 --> UTF-8 Support Enabled
INFO - 2018-08-03 02:21:52 --> Config Class Initialized
INFO - 2018-08-03 02:21:52 --> Hooks Class Initialized
INFO - 2018-08-03 02:21:52 --> Utf8 Class Initialized
DEBUG - 2018-08-03 02:21:52 --> UTF-8 Support Enabled
INFO - 2018-08-03 02:21:52 --> Utf8 Class Initialized
INFO - 2018-08-03 02:21:53 --> URI Class Initialized
INFO - 2018-08-03 02:21:53 --> Router Class Initialized
INFO - 2018-08-03 02:21:53 --> Output Class Initialized
INFO - 2018-08-03 02:21:53 --> Security Class Initialized
DEBUG - 2018-08-03 02:21:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 02:21:53 --> Input Class Initialized
INFO - 2018-08-03 02:21:53 --> Language Class Initialized
INFO - 2018-08-03 02:21:53 --> Language Class Initialized
INFO - 2018-08-03 02:21:53 --> URI Class Initialized
INFO - 2018-08-03 02:21:53 --> Config Class Initialized
INFO - 2018-08-03 02:21:53 --> Loader Class Initialized
DEBUG - 2018-08-03 02:21:53 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-03 02:21:53 --> Helper loaded: url_helper
INFO - 2018-08-03 02:21:53 --> Router Class Initialized
INFO - 2018-08-03 02:21:53 --> Helper loaded: form_helper
INFO - 2018-08-03 02:21:53 --> Helper loaded: date_helper
INFO - 2018-08-03 02:21:53 --> Output Class Initialized
INFO - 2018-08-03 02:21:53 --> Security Class Initialized
INFO - 2018-08-03 02:21:53 --> Helper loaded: util_helper
INFO - 2018-08-03 02:21:53 --> Helper loaded: text_helper
DEBUG - 2018-08-03 02:21:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 02:21:53 --> Helper loaded: string_helper
INFO - 2018-08-03 02:21:53 --> Input Class Initialized
INFO - 2018-08-03 02:21:53 --> Language Class Initialized
INFO - 2018-08-03 02:21:53 --> Database Driver Class Initialized
ERROR - 2018-08-03 02:21:53 --> 404 Page Not Found: /index
DEBUG - 2018-08-03 02:21:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 02:21:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-03 02:21:53 --> Config Class Initialized
INFO - 2018-08-03 02:21:53 --> Hooks Class Initialized
INFO - 2018-08-03 02:21:53 --> Email Class Initialized
DEBUG - 2018-08-03 02:21:53 --> UTF-8 Support Enabled
INFO - 2018-08-03 02:21:53 --> Utf8 Class Initialized
INFO - 2018-08-03 02:21:53 --> Controller Class Initialized
INFO - 2018-08-03 02:21:53 --> URI Class Initialized
DEBUG - 2018-08-03 02:21:53 --> Home MX_Controller Initialized
DEBUG - 2018-08-03 02:21:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-08-03 02:21:53 --> Router Class Initialized
INFO - 2018-08-03 02:21:53 --> Output Class Initialized
DEBUG - 2018-08-03 02:21:53 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-03 02:21:53 --> Login MX_Controller Initialized
INFO - 2018-08-03 02:21:53 --> Security Class Initialized
INFO - 2018-08-03 02:21:53 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-03 02:21:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-03 02:21:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-08-03 02:21:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-03 02:21:53 --> Input Class Initialized
INFO - 2018-08-03 02:21:53 --> Language Class Initialized
ERROR - 2018-08-03 02:21:53 --> 404 Page Not Found: /index
INFO - 2018-08-03 02:21:53 --> Config Class Initialized
INFO - 2018-08-03 02:21:53 --> Hooks Class Initialized
DEBUG - 2018-08-03 02:21:53 --> UTF-8 Support Enabled
INFO - 2018-08-03 02:21:53 --> Utf8 Class Initialized
INFO - 2018-08-03 02:21:53 --> URI Class Initialized
INFO - 2018-08-03 02:21:53 --> Router Class Initialized
INFO - 2018-08-03 02:21:53 --> Output Class Initialized
INFO - 2018-08-03 02:21:53 --> Security Class Initialized
DEBUG - 2018-08-03 02:21:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 02:21:53 --> Input Class Initialized
INFO - 2018-08-03 02:21:54 --> Language Class Initialized
ERROR - 2018-08-03 02:21:54 --> 404 Page Not Found: /index
INFO - 2018-08-03 02:21:54 --> Config Class Initialized
INFO - 2018-08-03 02:21:54 --> Hooks Class Initialized
DEBUG - 2018-08-03 02:21:54 --> UTF-8 Support Enabled
INFO - 2018-08-03 02:21:54 --> Utf8 Class Initialized
INFO - 2018-08-03 02:21:54 --> URI Class Initialized
INFO - 2018-08-03 02:21:54 --> Router Class Initialized
INFO - 2018-08-03 02:21:54 --> Output Class Initialized
INFO - 2018-08-03 02:21:54 --> Security Class Initialized
DEBUG - 2018-08-03 02:21:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 02:21:54 --> Input Class Initialized
INFO - 2018-08-03 02:21:54 --> Language Class Initialized
ERROR - 2018-08-03 02:21:54 --> 404 Page Not Found: /index
INFO - 2018-08-03 02:21:54 --> Config Class Initialized
INFO - 2018-08-03 02:21:54 --> Hooks Class Initialized
DEBUG - 2018-08-03 02:21:54 --> UTF-8 Support Enabled
INFO - 2018-08-03 02:21:54 --> Utf8 Class Initialized
INFO - 2018-08-03 02:21:54 --> URI Class Initialized
INFO - 2018-08-03 02:21:54 --> Router Class Initialized
INFO - 2018-08-03 02:21:54 --> Output Class Initialized
INFO - 2018-08-03 02:21:54 --> Security Class Initialized
DEBUG - 2018-08-03 02:21:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 02:21:54 --> Input Class Initialized
INFO - 2018-08-03 02:21:54 --> Language Class Initialized
ERROR - 2018-08-03 02:21:54 --> 404 Page Not Found: /index
INFO - 2018-08-03 02:21:54 --> Config Class Initialized
INFO - 2018-08-03 02:21:54 --> Hooks Class Initialized
DEBUG - 2018-08-03 02:21:54 --> UTF-8 Support Enabled
INFO - 2018-08-03 02:21:54 --> Utf8 Class Initialized
INFO - 2018-08-03 02:21:54 --> URI Class Initialized
INFO - 2018-08-03 02:21:54 --> Router Class Initialized
INFO - 2018-08-03 02:21:54 --> Output Class Initialized
INFO - 2018-08-03 02:21:54 --> Security Class Initialized
DEBUG - 2018-08-03 02:21:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 02:21:54 --> Input Class Initialized
INFO - 2018-08-03 02:21:54 --> Language Class Initialized
ERROR - 2018-08-03 02:21:54 --> 404 Page Not Found: /index
INFO - 2018-08-03 02:22:22 --> Config Class Initialized
INFO - 2018-08-03 02:22:22 --> Hooks Class Initialized
DEBUG - 2018-08-03 02:22:22 --> UTF-8 Support Enabled
INFO - 2018-08-03 02:22:22 --> Utf8 Class Initialized
INFO - 2018-08-03 02:22:22 --> URI Class Initialized
INFO - 2018-08-03 02:22:22 --> Router Class Initialized
INFO - 2018-08-03 02:22:22 --> Output Class Initialized
INFO - 2018-08-03 02:22:22 --> Security Class Initialized
DEBUG - 2018-08-03 02:22:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 02:22:22 --> Input Class Initialized
INFO - 2018-08-03 02:22:22 --> Language Class Initialized
INFO - 2018-08-03 02:22:22 --> Language Class Initialized
INFO - 2018-08-03 02:22:22 --> Config Class Initialized
INFO - 2018-08-03 02:22:22 --> Loader Class Initialized
DEBUG - 2018-08-03 02:22:22 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-03 02:22:22 --> Helper loaded: url_helper
INFO - 2018-08-03 02:22:22 --> Helper loaded: form_helper
INFO - 2018-08-03 02:22:22 --> Helper loaded: date_helper
INFO - 2018-08-03 02:22:22 --> Helper loaded: util_helper
INFO - 2018-08-03 02:22:22 --> Helper loaded: text_helper
INFO - 2018-08-03 02:22:22 --> Helper loaded: string_helper
INFO - 2018-08-03 02:22:22 --> Database Driver Class Initialized
DEBUG - 2018-08-03 02:22:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 02:22:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-03 02:22:22 --> Email Class Initialized
INFO - 2018-08-03 02:22:22 --> Controller Class Initialized
DEBUG - 2018-08-03 02:22:22 --> Home MX_Controller Initialized
DEBUG - 2018-08-03 02:22:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-03 02:22:22 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-03 02:22:23 --> Login MX_Controller Initialized
INFO - 2018-08-03 02:22:23 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-03 02:22:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-03 02:22:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-03 02:22:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-08-03 02:22:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-08-03 02:22:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-08-03 02:22:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-08-03 02:22:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-08-03 02:22:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-08-03 02:22:23 --> Final output sent to browser
DEBUG - 2018-08-03 02:22:23 --> Total execution time: 0.5950
INFO - 2018-08-03 02:22:23 --> Config Class Initialized
INFO - 2018-08-03 02:22:23 --> Hooks Class Initialized
DEBUG - 2018-08-03 02:22:23 --> UTF-8 Support Enabled
INFO - 2018-08-03 02:22:23 --> Utf8 Class Initialized
INFO - 2018-08-03 02:22:23 --> URI Class Initialized
INFO - 2018-08-03 02:22:23 --> Config Class Initialized
INFO - 2018-08-03 02:22:23 --> Hooks Class Initialized
INFO - 2018-08-03 02:22:23 --> Router Class Initialized
DEBUG - 2018-08-03 02:22:23 --> UTF-8 Support Enabled
INFO - 2018-08-03 02:22:23 --> Utf8 Class Initialized
INFO - 2018-08-03 02:22:24 --> URI Class Initialized
INFO - 2018-08-03 02:22:24 --> Router Class Initialized
INFO - 2018-08-03 02:22:24 --> Output Class Initialized
INFO - 2018-08-03 02:22:24 --> Output Class Initialized
INFO - 2018-08-03 02:22:24 --> Security Class Initialized
INFO - 2018-08-03 02:22:24 --> Security Class Initialized
DEBUG - 2018-08-03 02:22:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-08-03 02:22:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 02:22:24 --> Input Class Initialized
INFO - 2018-08-03 02:22:24 --> Language Class Initialized
ERROR - 2018-08-03 02:22:24 --> 404 Page Not Found: /index
INFO - 2018-08-03 02:22:24 --> Input Class Initialized
INFO - 2018-08-03 02:22:24 --> Config Class Initialized
INFO - 2018-08-03 02:22:24 --> Hooks Class Initialized
INFO - 2018-08-03 02:22:24 --> Language Class Initialized
DEBUG - 2018-08-03 02:22:24 --> UTF-8 Support Enabled
INFO - 2018-08-03 02:22:24 --> Utf8 Class Initialized
INFO - 2018-08-03 02:22:24 --> URI Class Initialized
INFO - 2018-08-03 02:22:24 --> Router Class Initialized
INFO - 2018-08-03 02:22:24 --> Output Class Initialized
INFO - 2018-08-03 02:22:24 --> Security Class Initialized
DEBUG - 2018-08-03 02:22:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 02:22:24 --> Input Class Initialized
INFO - 2018-08-03 02:22:24 --> Language Class Initialized
INFO - 2018-08-03 02:22:24 --> Language Class Initialized
INFO - 2018-08-03 02:22:24 --> Config Class Initialized
ERROR - 2018-08-03 02:22:24 --> 404 Page Not Found: /index
INFO - 2018-08-03 02:22:24 --> Loader Class Initialized
DEBUG - 2018-08-03 02:22:24 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-03 02:22:24 --> Helper loaded: url_helper
INFO - 2018-08-03 02:22:24 --> Helper loaded: form_helper
INFO - 2018-08-03 02:22:24 --> Helper loaded: date_helper
INFO - 2018-08-03 02:22:24 --> Helper loaded: util_helper
INFO - 2018-08-03 02:22:24 --> Helper loaded: text_helper
INFO - 2018-08-03 02:22:24 --> Config Class Initialized
INFO - 2018-08-03 02:22:24 --> Hooks Class Initialized
INFO - 2018-08-03 02:22:24 --> Helper loaded: string_helper
DEBUG - 2018-08-03 02:22:24 --> UTF-8 Support Enabled
INFO - 2018-08-03 02:22:24 --> Utf8 Class Initialized
INFO - 2018-08-03 02:22:24 --> URI Class Initialized
INFO - 2018-08-03 02:22:25 --> Router Class Initialized
INFO - 2018-08-03 02:22:25 --> Output Class Initialized
INFO - 2018-08-03 02:22:25 --> Database Driver Class Initialized
INFO - 2018-08-03 02:22:25 --> Security Class Initialized
DEBUG - 2018-08-03 02:22:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 02:22:25 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-08-03 02:22:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 02:22:25 --> Input Class Initialized
INFO - 2018-08-03 02:22:25 --> Email Class Initialized
INFO - 2018-08-03 02:22:25 --> Controller Class Initialized
INFO - 2018-08-03 02:22:25 --> Language Class Initialized
DEBUG - 2018-08-03 02:22:25 --> Home MX_Controller Initialized
ERROR - 2018-08-03 02:22:25 --> 404 Page Not Found: /index
DEBUG - 2018-08-03 02:22:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-03 02:22:25 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-03 02:22:25 --> Login MX_Controller Initialized
INFO - 2018-08-03 02:22:25 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-03 02:22:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-03 02:22:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-03 02:22:26 --> Config Class Initialized
INFO - 2018-08-03 02:22:26 --> Hooks Class Initialized
DEBUG - 2018-08-03 02:22:26 --> UTF-8 Support Enabled
INFO - 2018-08-03 02:22:26 --> Utf8 Class Initialized
INFO - 2018-08-03 02:22:26 --> URI Class Initialized
INFO - 2018-08-03 02:22:26 --> Router Class Initialized
INFO - 2018-08-03 02:22:26 --> Output Class Initialized
INFO - 2018-08-03 02:22:26 --> Security Class Initialized
DEBUG - 2018-08-03 02:22:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 02:22:26 --> Input Class Initialized
INFO - 2018-08-03 02:22:26 --> Language Class Initialized
INFO - 2018-08-03 02:22:26 --> Language Class Initialized
INFO - 2018-08-03 02:22:26 --> Config Class Initialized
INFO - 2018-08-03 02:22:26 --> Loader Class Initialized
DEBUG - 2018-08-03 02:22:26 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-03 02:22:26 --> Helper loaded: url_helper
INFO - 2018-08-03 02:22:26 --> Helper loaded: form_helper
INFO - 2018-08-03 02:22:26 --> Helper loaded: date_helper
INFO - 2018-08-03 02:22:26 --> Helper loaded: util_helper
INFO - 2018-08-03 02:22:26 --> Helper loaded: text_helper
INFO - 2018-08-03 02:22:26 --> Helper loaded: string_helper
INFO - 2018-08-03 02:22:26 --> Database Driver Class Initialized
DEBUG - 2018-08-03 02:22:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 02:22:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-03 02:22:26 --> Email Class Initialized
INFO - 2018-08-03 02:22:26 --> Controller Class Initialized
DEBUG - 2018-08-03 02:22:26 --> Admin MX_Controller Initialized
INFO - 2018-08-03 02:22:26 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-03 02:22:26 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-03 02:22:26 --> Login MX_Controller Initialized
DEBUG - 2018-08-03 02:22:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-03 02:22:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-03 02:22:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-08-03 02:22:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-08-03 02:22:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-08-03 02:22:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-08-03 02:22:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-08-03 02:22:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/dashboard.php
INFO - 2018-08-03 02:22:26 --> Final output sent to browser
DEBUG - 2018-08-03 02:22:26 --> Total execution time: 0.5910
INFO - 2018-08-03 02:22:27 --> Config Class Initialized
INFO - 2018-08-03 02:22:27 --> Hooks Class Initialized
DEBUG - 2018-08-03 02:22:27 --> UTF-8 Support Enabled
INFO - 2018-08-03 02:22:27 --> Utf8 Class Initialized
INFO - 2018-08-03 02:22:27 --> URI Class Initialized
INFO - 2018-08-03 02:22:27 --> Router Class Initialized
INFO - 2018-08-03 02:22:27 --> Output Class Initialized
INFO - 2018-08-03 02:22:27 --> Security Class Initialized
INFO - 2018-08-03 02:22:27 --> Config Class Initialized
DEBUG - 2018-08-03 02:22:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 02:22:27 --> Hooks Class Initialized
DEBUG - 2018-08-03 02:22:27 --> UTF-8 Support Enabled
INFO - 2018-08-03 02:22:27 --> Input Class Initialized
INFO - 2018-08-03 02:22:27 --> Utf8 Class Initialized
INFO - 2018-08-03 02:22:27 --> URI Class Initialized
INFO - 2018-08-03 02:22:27 --> Language Class Initialized
INFO - 2018-08-03 02:22:27 --> Router Class Initialized
INFO - 2018-08-03 02:22:27 --> Output Class Initialized
ERROR - 2018-08-03 02:22:27 --> 404 Page Not Found: /index
INFO - 2018-08-03 02:22:27 --> Security Class Initialized
DEBUG - 2018-08-03 02:22:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 02:22:27 --> Input Class Initialized
INFO - 2018-08-03 02:22:27 --> Language Class Initialized
ERROR - 2018-08-03 02:22:27 --> 404 Page Not Found: /index
INFO - 2018-08-03 02:22:27 --> Config Class Initialized
INFO - 2018-08-03 02:22:27 --> Config Class Initialized
INFO - 2018-08-03 02:22:27 --> Hooks Class Initialized
DEBUG - 2018-08-03 02:22:27 --> UTF-8 Support Enabled
INFO - 2018-08-03 02:22:27 --> Utf8 Class Initialized
INFO - 2018-08-03 02:22:27 --> URI Class Initialized
INFO - 2018-08-03 02:22:27 --> Hooks Class Initialized
INFO - 2018-08-03 02:22:27 --> Router Class Initialized
INFO - 2018-08-03 02:22:27 --> Output Class Initialized
DEBUG - 2018-08-03 02:22:27 --> UTF-8 Support Enabled
INFO - 2018-08-03 02:22:27 --> Utf8 Class Initialized
INFO - 2018-08-03 02:22:27 --> Security Class Initialized
INFO - 2018-08-03 02:22:27 --> URI Class Initialized
INFO - 2018-08-03 02:22:27 --> Router Class Initialized
DEBUG - 2018-08-03 02:22:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 02:22:27 --> Output Class Initialized
INFO - 2018-08-03 02:22:27 --> Security Class Initialized
DEBUG - 2018-08-03 02:22:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 02:22:27 --> Input Class Initialized
INFO - 2018-08-03 02:22:27 --> Language Class Initialized
INFO - 2018-08-03 02:22:28 --> Input Class Initialized
ERROR - 2018-08-03 02:22:28 --> 404 Page Not Found: /index
INFO - 2018-08-03 02:22:28 --> Language Class Initialized
INFO - 2018-08-03 02:22:28 --> Language Class Initialized
INFO - 2018-08-03 02:22:28 --> Config Class Initialized
INFO - 2018-08-03 02:22:28 --> Loader Class Initialized
DEBUG - 2018-08-03 02:22:28 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-03 02:22:28 --> Helper loaded: url_helper
INFO - 2018-08-03 02:22:28 --> Helper loaded: form_helper
INFO - 2018-08-03 02:22:28 --> Helper loaded: date_helper
INFO - 2018-08-03 02:22:28 --> Helper loaded: util_helper
INFO - 2018-08-03 02:22:28 --> Helper loaded: text_helper
INFO - 2018-08-03 02:22:28 --> Helper loaded: string_helper
INFO - 2018-08-03 02:22:28 --> Database Driver Class Initialized
DEBUG - 2018-08-03 02:22:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 02:22:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-03 02:22:28 --> Email Class Initialized
INFO - 2018-08-03 02:22:28 --> Controller Class Initialized
DEBUG - 2018-08-03 02:22:28 --> Home MX_Controller Initialized
DEBUG - 2018-08-03 02:22:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-03 02:22:28 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-03 02:22:28 --> Login MX_Controller Initialized
INFO - 2018-08-03 02:22:28 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-03 02:22:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-03 02:22:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-03 02:22:50 --> Config Class Initialized
INFO - 2018-08-03 02:22:50 --> Hooks Class Initialized
DEBUG - 2018-08-03 02:22:50 --> UTF-8 Support Enabled
INFO - 2018-08-03 02:22:50 --> Utf8 Class Initialized
INFO - 2018-08-03 02:22:50 --> URI Class Initialized
INFO - 2018-08-03 02:22:50 --> Router Class Initialized
INFO - 2018-08-03 02:22:50 --> Output Class Initialized
INFO - 2018-08-03 02:22:50 --> Security Class Initialized
DEBUG - 2018-08-03 02:22:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 02:22:50 --> Input Class Initialized
INFO - 2018-08-03 02:22:50 --> Language Class Initialized
INFO - 2018-08-03 02:22:50 --> Language Class Initialized
INFO - 2018-08-03 02:22:50 --> Config Class Initialized
INFO - 2018-08-03 02:22:50 --> Loader Class Initialized
DEBUG - 2018-08-03 02:22:50 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-03 02:22:50 --> Helper loaded: url_helper
INFO - 2018-08-03 02:22:50 --> Helper loaded: form_helper
INFO - 2018-08-03 02:22:50 --> Helper loaded: date_helper
INFO - 2018-08-03 02:22:50 --> Helper loaded: util_helper
INFO - 2018-08-03 02:22:50 --> Helper loaded: text_helper
INFO - 2018-08-03 02:22:50 --> Helper loaded: string_helper
INFO - 2018-08-03 02:22:51 --> Database Driver Class Initialized
DEBUG - 2018-08-03 02:22:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 02:22:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-03 02:22:51 --> Email Class Initialized
INFO - 2018-08-03 02:22:51 --> Controller Class Initialized
DEBUG - 2018-08-03 02:22:51 --> Home MX_Controller Initialized
DEBUG - 2018-08-03 02:22:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-03 02:22:51 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-03 02:22:51 --> Login MX_Controller Initialized
INFO - 2018-08-03 02:22:51 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-03 02:22:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-03 02:22:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-03 02:22:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-08-03 02:22:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-08-03 02:22:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-08-03 02:22:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-08-03 02:22:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-08-03 02:22:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-08-03 02:22:51 --> Final output sent to browser
DEBUG - 2018-08-03 02:22:51 --> Total execution time: 0.6231
INFO - 2018-08-03 02:22:51 --> Config Class Initialized
INFO - 2018-08-03 02:22:51 --> Hooks Class Initialized
DEBUG - 2018-08-03 02:22:51 --> UTF-8 Support Enabled
INFO - 2018-08-03 02:22:51 --> Utf8 Class Initialized
INFO - 2018-08-03 02:22:52 --> URI Class Initialized
INFO - 2018-08-03 02:22:52 --> Config Class Initialized
INFO - 2018-08-03 02:22:52 --> Hooks Class Initialized
INFO - 2018-08-03 02:22:52 --> Router Class Initialized
DEBUG - 2018-08-03 02:22:52 --> UTF-8 Support Enabled
INFO - 2018-08-03 02:22:52 --> Utf8 Class Initialized
INFO - 2018-08-03 02:22:52 --> URI Class Initialized
INFO - 2018-08-03 02:22:52 --> Router Class Initialized
INFO - 2018-08-03 02:22:52 --> Output Class Initialized
INFO - 2018-08-03 02:22:52 --> Security Class Initialized
INFO - 2018-08-03 02:22:52 --> Output Class Initialized
INFO - 2018-08-03 02:22:52 --> Security Class Initialized
DEBUG - 2018-08-03 02:22:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-08-03 02:22:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 02:22:52 --> Input Class Initialized
INFO - 2018-08-03 02:22:52 --> Input Class Initialized
INFO - 2018-08-03 02:22:52 --> Language Class Initialized
ERROR - 2018-08-03 02:22:52 --> 404 Page Not Found: /index
INFO - 2018-08-03 02:22:52 --> Language Class Initialized
INFO - 2018-08-03 02:22:52 --> Config Class Initialized
INFO - 2018-08-03 02:22:52 --> Language Class Initialized
INFO - 2018-08-03 02:22:52 --> Config Class Initialized
INFO - 2018-08-03 02:22:52 --> Hooks Class Initialized
INFO - 2018-08-03 02:22:52 --> Loader Class Initialized
DEBUG - 2018-08-03 02:22:52 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
DEBUG - 2018-08-03 02:22:52 --> UTF-8 Support Enabled
INFO - 2018-08-03 02:22:52 --> Helper loaded: url_helper
INFO - 2018-08-03 02:22:52 --> Utf8 Class Initialized
INFO - 2018-08-03 02:22:52 --> Helper loaded: form_helper
INFO - 2018-08-03 02:22:52 --> URI Class Initialized
INFO - 2018-08-03 02:22:52 --> Router Class Initialized
INFO - 2018-08-03 02:22:52 --> Helper loaded: date_helper
INFO - 2018-08-03 02:22:52 --> Helper loaded: util_helper
INFO - 2018-08-03 02:22:52 --> Output Class Initialized
INFO - 2018-08-03 02:22:52 --> Helper loaded: text_helper
INFO - 2018-08-03 02:22:52 --> Security Class Initialized
INFO - 2018-08-03 02:22:52 --> Helper loaded: string_helper
DEBUG - 2018-08-03 02:22:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 02:22:52 --> Database Driver Class Initialized
INFO - 2018-08-03 02:22:52 --> Input Class Initialized
INFO - 2018-08-03 02:22:52 --> Language Class Initialized
ERROR - 2018-08-03 02:22:52 --> 404 Page Not Found: /index
DEBUG - 2018-08-03 02:22:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 02:22:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-03 02:22:52 --> Email Class Initialized
INFO - 2018-08-03 02:22:52 --> Config Class Initialized
INFO - 2018-08-03 02:22:52 --> Controller Class Initialized
INFO - 2018-08-03 02:22:52 --> Hooks Class Initialized
DEBUG - 2018-08-03 02:22:52 --> Home MX_Controller Initialized
DEBUG - 2018-08-03 02:22:52 --> UTF-8 Support Enabled
DEBUG - 2018-08-03 02:22:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-08-03 02:22:53 --> Utf8 Class Initialized
DEBUG - 2018-08-03 02:22:53 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-03 02:22:53 --> Login MX_Controller Initialized
INFO - 2018-08-03 02:22:53 --> URI Class Initialized
INFO - 2018-08-03 02:22:53 --> Language file loaded: language/english/data_lang.php
INFO - 2018-08-03 02:22:53 --> Router Class Initialized
DEBUG - 2018-08-03 02:22:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-03 02:22:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-03 02:22:53 --> Output Class Initialized
INFO - 2018-08-03 02:22:53 --> Security Class Initialized
DEBUG - 2018-08-03 02:22:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 02:22:53 --> Input Class Initialized
INFO - 2018-08-03 02:22:53 --> Language Class Initialized
ERROR - 2018-08-03 02:22:53 --> 404 Page Not Found: /index
INFO - 2018-08-03 02:23:28 --> Config Class Initialized
INFO - 2018-08-03 02:23:28 --> Hooks Class Initialized
DEBUG - 2018-08-03 02:23:28 --> UTF-8 Support Enabled
INFO - 2018-08-03 02:23:28 --> Utf8 Class Initialized
INFO - 2018-08-03 02:23:28 --> URI Class Initialized
INFO - 2018-08-03 02:23:28 --> Router Class Initialized
INFO - 2018-08-03 02:23:28 --> Output Class Initialized
INFO - 2018-08-03 02:23:28 --> Security Class Initialized
DEBUG - 2018-08-03 02:23:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 02:23:28 --> Input Class Initialized
INFO - 2018-08-03 02:23:28 --> Language Class Initialized
INFO - 2018-08-03 02:23:28 --> Language Class Initialized
INFO - 2018-08-03 02:23:28 --> Config Class Initialized
INFO - 2018-08-03 02:23:28 --> Loader Class Initialized
DEBUG - 2018-08-03 02:23:28 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-03 02:23:28 --> Helper loaded: url_helper
INFO - 2018-08-03 02:23:28 --> Helper loaded: form_helper
INFO - 2018-08-03 02:23:28 --> Helper loaded: date_helper
INFO - 2018-08-03 02:23:28 --> Helper loaded: util_helper
INFO - 2018-08-03 02:23:28 --> Helper loaded: text_helper
INFO - 2018-08-03 02:23:28 --> Helper loaded: string_helper
INFO - 2018-08-03 02:23:28 --> Database Driver Class Initialized
DEBUG - 2018-08-03 02:23:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 02:23:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-03 02:23:28 --> Email Class Initialized
INFO - 2018-08-03 02:23:28 --> Controller Class Initialized
DEBUG - 2018-08-03 02:23:28 --> Home MX_Controller Initialized
DEBUG - 2018-08-03 02:23:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-03 02:23:28 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-03 02:23:28 --> Login MX_Controller Initialized
INFO - 2018-08-03 02:23:28 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-03 02:23:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-03 02:23:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-03 02:23:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-08-03 02:23:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-08-03 02:23:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-08-03 02:23:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-08-03 02:23:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-08-03 02:23:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-08-03 02:23:28 --> Final output sent to browser
DEBUG - 2018-08-03 02:23:28 --> Total execution time: 0.6802
INFO - 2018-08-03 02:23:29 --> Config Class Initialized
INFO - 2018-08-03 02:23:29 --> Hooks Class Initialized
DEBUG - 2018-08-03 02:23:29 --> UTF-8 Support Enabled
INFO - 2018-08-03 02:23:29 --> Config Class Initialized
INFO - 2018-08-03 02:23:29 --> Hooks Class Initialized
INFO - 2018-08-03 02:23:29 --> Utf8 Class Initialized
DEBUG - 2018-08-03 02:23:29 --> UTF-8 Support Enabled
INFO - 2018-08-03 02:23:29 --> Utf8 Class Initialized
INFO - 2018-08-03 02:23:29 --> URI Class Initialized
INFO - 2018-08-03 02:23:29 --> URI Class Initialized
INFO - 2018-08-03 02:23:29 --> Router Class Initialized
INFO - 2018-08-03 02:23:29 --> Output Class Initialized
INFO - 2018-08-03 02:23:29 --> Router Class Initialized
INFO - 2018-08-03 02:23:29 --> Security Class Initialized
INFO - 2018-08-03 02:23:29 --> Output Class Initialized
DEBUG - 2018-08-03 02:23:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 02:23:29 --> Security Class Initialized
INFO - 2018-08-03 02:23:29 --> Input Class Initialized
DEBUG - 2018-08-03 02:23:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 02:23:29 --> Language Class Initialized
INFO - 2018-08-03 02:23:29 --> Language Class Initialized
INFO - 2018-08-03 02:23:30 --> Input Class Initialized
INFO - 2018-08-03 02:23:30 --> Config Class Initialized
INFO - 2018-08-03 02:23:30 --> Language Class Initialized
INFO - 2018-08-03 02:23:30 --> Loader Class Initialized
DEBUG - 2018-08-03 02:23:30 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
ERROR - 2018-08-03 02:23:30 --> 404 Page Not Found: /index
INFO - 2018-08-03 02:23:30 --> Helper loaded: url_helper
INFO - 2018-08-03 02:23:30 --> Helper loaded: form_helper
INFO - 2018-08-03 02:23:30 --> Helper loaded: date_helper
INFO - 2018-08-03 02:23:30 --> Helper loaded: util_helper
INFO - 2018-08-03 02:23:30 --> Helper loaded: text_helper
INFO - 2018-08-03 02:23:30 --> Helper loaded: string_helper
INFO - 2018-08-03 02:23:30 --> Database Driver Class Initialized
DEBUG - 2018-08-03 02:23:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 02:23:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-03 02:23:30 --> Email Class Initialized
INFO - 2018-08-03 02:23:30 --> Controller Class Initialized
INFO - 2018-08-03 02:23:30 --> Config Class Initialized
DEBUG - 2018-08-03 02:23:30 --> Home MX_Controller Initialized
INFO - 2018-08-03 02:23:30 --> Hooks Class Initialized
DEBUG - 2018-08-03 02:23:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-03 02:23:30 --> UTF-8 Support Enabled
DEBUG - 2018-08-03 02:23:30 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-03 02:23:30 --> Login MX_Controller Initialized
INFO - 2018-08-03 02:23:30 --> Utf8 Class Initialized
INFO - 2018-08-03 02:23:30 --> Language file loaded: language/english/data_lang.php
INFO - 2018-08-03 02:23:30 --> URI Class Initialized
DEBUG - 2018-08-03 02:23:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-03 02:23:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-03 02:23:30 --> Router Class Initialized
INFO - 2018-08-03 02:23:30 --> Output Class Initialized
INFO - 2018-08-03 02:23:30 --> Security Class Initialized
DEBUG - 2018-08-03 02:23:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 02:23:30 --> Input Class Initialized
INFO - 2018-08-03 02:23:30 --> Language Class Initialized
ERROR - 2018-08-03 02:23:31 --> 404 Page Not Found: /index
INFO - 2018-08-03 02:23:31 --> Config Class Initialized
INFO - 2018-08-03 02:23:31 --> Hooks Class Initialized
DEBUG - 2018-08-03 02:23:31 --> UTF-8 Support Enabled
INFO - 2018-08-03 02:23:31 --> Utf8 Class Initialized
INFO - 2018-08-03 02:23:31 --> URI Class Initialized
INFO - 2018-08-03 02:23:31 --> Router Class Initialized
INFO - 2018-08-03 02:23:31 --> Output Class Initialized
INFO - 2018-08-03 02:23:31 --> Security Class Initialized
DEBUG - 2018-08-03 02:23:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 02:23:31 --> Input Class Initialized
INFO - 2018-08-03 02:23:31 --> Language Class Initialized
ERROR - 2018-08-03 02:23:31 --> 404 Page Not Found: /index
INFO - 2018-08-03 02:24:02 --> Config Class Initialized
INFO - 2018-08-03 02:24:02 --> Hooks Class Initialized
DEBUG - 2018-08-03 02:24:02 --> UTF-8 Support Enabled
INFO - 2018-08-03 02:24:02 --> Utf8 Class Initialized
INFO - 2018-08-03 02:24:02 --> URI Class Initialized
INFO - 2018-08-03 02:24:02 --> Router Class Initialized
INFO - 2018-08-03 02:24:02 --> Output Class Initialized
INFO - 2018-08-03 02:24:02 --> Security Class Initialized
DEBUG - 2018-08-03 02:24:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 02:24:02 --> Input Class Initialized
INFO - 2018-08-03 02:24:02 --> Language Class Initialized
INFO - 2018-08-03 02:24:02 --> Language Class Initialized
INFO - 2018-08-03 02:24:02 --> Config Class Initialized
INFO - 2018-08-03 02:24:02 --> Loader Class Initialized
DEBUG - 2018-08-03 02:24:02 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-03 02:24:03 --> Helper loaded: url_helper
INFO - 2018-08-03 02:24:03 --> Helper loaded: form_helper
INFO - 2018-08-03 02:24:03 --> Helper loaded: date_helper
INFO - 2018-08-03 02:24:03 --> Helper loaded: util_helper
INFO - 2018-08-03 02:24:03 --> Helper loaded: text_helper
INFO - 2018-08-03 02:24:03 --> Helper loaded: string_helper
INFO - 2018-08-03 02:24:03 --> Database Driver Class Initialized
DEBUG - 2018-08-03 02:24:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 02:24:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-03 02:24:03 --> Email Class Initialized
INFO - 2018-08-03 02:24:03 --> Controller Class Initialized
DEBUG - 2018-08-03 02:24:03 --> Home MX_Controller Initialized
DEBUG - 2018-08-03 02:24:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-03 02:24:03 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-03 02:24:03 --> Login MX_Controller Initialized
INFO - 2018-08-03 02:24:03 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-03 02:24:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-03 02:24:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-03 02:24:04 --> Config Class Initialized
INFO - 2018-08-03 02:24:04 --> Hooks Class Initialized
DEBUG - 2018-08-03 02:24:04 --> UTF-8 Support Enabled
INFO - 2018-08-03 02:24:04 --> Utf8 Class Initialized
INFO - 2018-08-03 02:24:04 --> URI Class Initialized
INFO - 2018-08-03 02:24:04 --> Router Class Initialized
INFO - 2018-08-03 02:24:04 --> Output Class Initialized
INFO - 2018-08-03 02:24:04 --> Security Class Initialized
DEBUG - 2018-08-03 02:24:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 02:24:04 --> Input Class Initialized
INFO - 2018-08-03 02:24:04 --> Language Class Initialized
INFO - 2018-08-03 02:24:04 --> Language Class Initialized
INFO - 2018-08-03 02:24:04 --> Config Class Initialized
INFO - 2018-08-03 02:24:04 --> Loader Class Initialized
DEBUG - 2018-08-03 02:24:04 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-03 02:24:04 --> Helper loaded: url_helper
INFO - 2018-08-03 02:24:04 --> Helper loaded: form_helper
INFO - 2018-08-03 02:24:04 --> Helper loaded: date_helper
INFO - 2018-08-03 02:24:04 --> Helper loaded: util_helper
INFO - 2018-08-03 02:24:04 --> Helper loaded: text_helper
INFO - 2018-08-03 02:24:04 --> Helper loaded: string_helper
INFO - 2018-08-03 02:24:04 --> Database Driver Class Initialized
DEBUG - 2018-08-03 02:24:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 02:24:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-03 02:24:04 --> Email Class Initialized
INFO - 2018-08-03 02:24:04 --> Controller Class Initialized
DEBUG - 2018-08-03 02:24:04 --> Home MX_Controller Initialized
DEBUG - 2018-08-03 02:24:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-03 02:24:04 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-03 02:24:04 --> Login MX_Controller Initialized
INFO - 2018-08-03 02:24:04 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-03 02:24:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-03 02:24:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-03 02:24:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-08-03 02:24:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-08-03 02:24:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-08-03 02:24:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-08-03 02:24:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-08-03 02:24:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-08-03 02:24:04 --> Final output sent to browser
DEBUG - 2018-08-03 02:24:04 --> Total execution time: 0.7274
INFO - 2018-08-03 02:24:05 --> Config Class Initialized
INFO - 2018-08-03 02:24:05 --> Hooks Class Initialized
DEBUG - 2018-08-03 02:24:05 --> UTF-8 Support Enabled
INFO - 2018-08-03 02:24:05 --> Utf8 Class Initialized
INFO - 2018-08-03 02:24:05 --> Config Class Initialized
INFO - 2018-08-03 02:24:05 --> Hooks Class Initialized
INFO - 2018-08-03 02:24:05 --> URI Class Initialized
DEBUG - 2018-08-03 02:24:05 --> UTF-8 Support Enabled
INFO - 2018-08-03 02:24:05 --> Utf8 Class Initialized
INFO - 2018-08-03 02:24:05 --> URI Class Initialized
INFO - 2018-08-03 02:24:05 --> Router Class Initialized
INFO - 2018-08-03 02:24:05 --> Output Class Initialized
INFO - 2018-08-03 02:24:05 --> Router Class Initialized
INFO - 2018-08-03 02:24:05 --> Output Class Initialized
INFO - 2018-08-03 02:24:05 --> Security Class Initialized
INFO - 2018-08-03 02:24:05 --> Security Class Initialized
DEBUG - 2018-08-03 02:24:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 02:24:05 --> Input Class Initialized
DEBUG - 2018-08-03 02:24:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 02:24:05 --> Language Class Initialized
INFO - 2018-08-03 02:24:05 --> Input Class Initialized
INFO - 2018-08-03 02:24:05 --> Language Class Initialized
INFO - 2018-08-03 02:24:05 --> Language Class Initialized
INFO - 2018-08-03 02:24:05 --> Config Class Initialized
ERROR - 2018-08-03 02:24:05 --> 404 Page Not Found: /index
INFO - 2018-08-03 02:24:05 --> Loader Class Initialized
DEBUG - 2018-08-03 02:24:06 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-03 02:24:06 --> Helper loaded: url_helper
INFO - 2018-08-03 02:24:06 --> Helper loaded: form_helper
INFO - 2018-08-03 02:24:06 --> Config Class Initialized
INFO - 2018-08-03 02:24:06 --> Hooks Class Initialized
INFO - 2018-08-03 02:24:06 --> Helper loaded: date_helper
DEBUG - 2018-08-03 02:24:06 --> UTF-8 Support Enabled
INFO - 2018-08-03 02:24:06 --> Utf8 Class Initialized
INFO - 2018-08-03 02:24:06 --> URI Class Initialized
INFO - 2018-08-03 02:24:06 --> Helper loaded: util_helper
INFO - 2018-08-03 02:24:06 --> Router Class Initialized
INFO - 2018-08-03 02:24:06 --> Output Class Initialized
INFO - 2018-08-03 02:24:06 --> Helper loaded: text_helper
INFO - 2018-08-03 02:24:06 --> Security Class Initialized
DEBUG - 2018-08-03 02:24:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 02:24:06 --> Input Class Initialized
INFO - 2018-08-03 02:24:06 --> Language Class Initialized
INFO - 2018-08-03 02:24:06 --> Helper loaded: string_helper
ERROR - 2018-08-03 02:24:06 --> 404 Page Not Found: /index
INFO - 2018-08-03 02:24:06 --> Database Driver Class Initialized
INFO - 2018-08-03 02:24:06 --> Config Class Initialized
INFO - 2018-08-03 02:24:06 --> Hooks Class Initialized
DEBUG - 2018-08-03 02:24:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 02:24:06 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-08-03 02:24:06 --> UTF-8 Support Enabled
INFO - 2018-08-03 02:24:06 --> Email Class Initialized
INFO - 2018-08-03 02:24:06 --> Utf8 Class Initialized
INFO - 2018-08-03 02:24:06 --> Controller Class Initialized
INFO - 2018-08-03 02:24:06 --> URI Class Initialized
DEBUG - 2018-08-03 02:24:06 --> Home MX_Controller Initialized
INFO - 2018-08-03 02:24:06 --> Router Class Initialized
INFO - 2018-08-03 02:24:06 --> Output Class Initialized
DEBUG - 2018-08-03 02:24:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-08-03 02:24:06 --> Security Class Initialized
DEBUG - 2018-08-03 02:24:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 02:24:06 --> Input Class Initialized
INFO - 2018-08-03 02:24:06 --> Language Class Initialized
ERROR - 2018-08-03 02:24:06 --> 404 Page Not Found: /index
DEBUG - 2018-08-03 02:24:06 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-03 02:24:06 --> Login MX_Controller Initialized
INFO - 2018-08-03 02:24:06 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-03 02:24:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-03 02:24:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-03 02:24:12 --> Config Class Initialized
INFO - 2018-08-03 02:24:12 --> Hooks Class Initialized
DEBUG - 2018-08-03 02:24:12 --> UTF-8 Support Enabled
INFO - 2018-08-03 02:24:12 --> Utf8 Class Initialized
INFO - 2018-08-03 02:24:12 --> URI Class Initialized
INFO - 2018-08-03 02:24:12 --> Router Class Initialized
INFO - 2018-08-03 02:24:12 --> Output Class Initialized
INFO - 2018-08-03 02:24:12 --> Security Class Initialized
DEBUG - 2018-08-03 02:24:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 02:24:12 --> Input Class Initialized
INFO - 2018-08-03 02:24:12 --> Language Class Initialized
INFO - 2018-08-03 02:24:12 --> Language Class Initialized
INFO - 2018-08-03 02:24:12 --> Config Class Initialized
INFO - 2018-08-03 02:24:12 --> Loader Class Initialized
DEBUG - 2018-08-03 02:24:12 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-03 02:24:12 --> Helper loaded: url_helper
INFO - 2018-08-03 02:24:12 --> Helper loaded: form_helper
INFO - 2018-08-03 02:24:12 --> Helper loaded: date_helper
INFO - 2018-08-03 02:24:12 --> Helper loaded: util_helper
INFO - 2018-08-03 02:24:12 --> Helper loaded: text_helper
INFO - 2018-08-03 02:24:12 --> Helper loaded: string_helper
INFO - 2018-08-03 02:24:12 --> Database Driver Class Initialized
DEBUG - 2018-08-03 02:24:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 02:24:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-03 02:24:12 --> Email Class Initialized
INFO - 2018-08-03 02:24:12 --> Controller Class Initialized
DEBUG - 2018-08-03 02:24:12 --> Home MX_Controller Initialized
DEBUG - 2018-08-03 02:24:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-03 02:24:12 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-03 02:24:12 --> Login MX_Controller Initialized
INFO - 2018-08-03 02:24:12 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-03 02:24:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-03 02:24:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-03 02:24:14 --> Config Class Initialized
INFO - 2018-08-03 02:24:14 --> Hooks Class Initialized
DEBUG - 2018-08-03 02:24:14 --> UTF-8 Support Enabled
INFO - 2018-08-03 02:24:14 --> Utf8 Class Initialized
INFO - 2018-08-03 02:24:14 --> URI Class Initialized
INFO - 2018-08-03 02:24:14 --> Router Class Initialized
INFO - 2018-08-03 02:24:14 --> Output Class Initialized
INFO - 2018-08-03 02:24:14 --> Security Class Initialized
DEBUG - 2018-08-03 02:24:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 02:24:14 --> Input Class Initialized
INFO - 2018-08-03 02:24:14 --> Language Class Initialized
INFO - 2018-08-03 02:24:14 --> Language Class Initialized
INFO - 2018-08-03 02:24:14 --> Config Class Initialized
INFO - 2018-08-03 02:24:14 --> Loader Class Initialized
DEBUG - 2018-08-03 02:24:14 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-03 02:24:14 --> Helper loaded: url_helper
INFO - 2018-08-03 02:24:14 --> Helper loaded: form_helper
INFO - 2018-08-03 02:24:14 --> Helper loaded: date_helper
INFO - 2018-08-03 02:24:14 --> Helper loaded: util_helper
INFO - 2018-08-03 02:24:14 --> Helper loaded: text_helper
INFO - 2018-08-03 02:24:14 --> Helper loaded: string_helper
INFO - 2018-08-03 02:24:14 --> Database Driver Class Initialized
DEBUG - 2018-08-03 02:24:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 02:24:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-03 02:24:14 --> Email Class Initialized
INFO - 2018-08-03 02:24:14 --> Controller Class Initialized
DEBUG - 2018-08-03 02:24:14 --> Home MX_Controller Initialized
DEBUG - 2018-08-03 02:24:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-03 02:24:14 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-03 02:24:14 --> Login MX_Controller Initialized
INFO - 2018-08-03 02:24:14 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-03 02:24:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-03 02:24:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-03 02:24:15 --> Config Class Initialized
INFO - 2018-08-03 02:24:15 --> Hooks Class Initialized
DEBUG - 2018-08-03 02:24:15 --> UTF-8 Support Enabled
INFO - 2018-08-03 02:24:15 --> Utf8 Class Initialized
INFO - 2018-08-03 02:24:15 --> URI Class Initialized
INFO - 2018-08-03 02:24:15 --> Router Class Initialized
INFO - 2018-08-03 02:24:15 --> Output Class Initialized
INFO - 2018-08-03 02:24:15 --> Security Class Initialized
DEBUG - 2018-08-03 02:24:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 02:24:15 --> Input Class Initialized
INFO - 2018-08-03 02:24:15 --> Language Class Initialized
INFO - 2018-08-03 02:24:15 --> Language Class Initialized
INFO - 2018-08-03 02:24:15 --> Config Class Initialized
INFO - 2018-08-03 02:24:16 --> Loader Class Initialized
DEBUG - 2018-08-03 02:24:16 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-03 02:24:16 --> Helper loaded: url_helper
INFO - 2018-08-03 02:24:16 --> Helper loaded: form_helper
INFO - 2018-08-03 02:24:16 --> Helper loaded: date_helper
INFO - 2018-08-03 02:24:16 --> Helper loaded: util_helper
INFO - 2018-08-03 02:24:16 --> Helper loaded: text_helper
INFO - 2018-08-03 02:24:16 --> Helper loaded: string_helper
INFO - 2018-08-03 02:24:16 --> Database Driver Class Initialized
DEBUG - 2018-08-03 02:24:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 02:24:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-03 02:24:16 --> Email Class Initialized
INFO - 2018-08-03 02:24:16 --> Controller Class Initialized
DEBUG - 2018-08-03 02:24:16 --> Home MX_Controller Initialized
DEBUG - 2018-08-03 02:24:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-03 02:24:16 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-03 02:24:16 --> Login MX_Controller Initialized
INFO - 2018-08-03 02:24:16 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-03 02:24:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-03 02:24:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-03 02:24:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-08-03 02:24:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-08-03 02:24:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-08-03 02:24:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-08-03 02:24:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-08-03 02:24:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-08-03 02:24:16 --> Final output sent to browser
DEBUG - 2018-08-03 02:24:16 --> Total execution time: 0.7830
INFO - 2018-08-03 02:24:17 --> Config Class Initialized
INFO - 2018-08-03 02:24:17 --> Hooks Class Initialized
DEBUG - 2018-08-03 02:24:17 --> UTF-8 Support Enabled
INFO - 2018-08-03 02:24:17 --> Utf8 Class Initialized
INFO - 2018-08-03 02:24:17 --> URI Class Initialized
INFO - 2018-08-03 02:24:17 --> Config Class Initialized
INFO - 2018-08-03 02:24:17 --> Hooks Class Initialized
INFO - 2018-08-03 02:24:17 --> Router Class Initialized
DEBUG - 2018-08-03 02:24:17 --> UTF-8 Support Enabled
INFO - 2018-08-03 02:24:17 --> Utf8 Class Initialized
INFO - 2018-08-03 02:24:17 --> URI Class Initialized
INFO - 2018-08-03 02:24:17 --> Output Class Initialized
INFO - 2018-08-03 02:24:17 --> Router Class Initialized
INFO - 2018-08-03 02:24:17 --> Output Class Initialized
INFO - 2018-08-03 02:24:17 --> Security Class Initialized
DEBUG - 2018-08-03 02:24:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 02:24:17 --> Input Class Initialized
INFO - 2018-08-03 02:24:17 --> Language Class Initialized
INFO - 2018-08-03 02:24:17 --> Language Class Initialized
INFO - 2018-08-03 02:24:17 --> Config Class Initialized
INFO - 2018-08-03 02:24:17 --> Security Class Initialized
DEBUG - 2018-08-03 02:24:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 02:24:17 --> Loader Class Initialized
INFO - 2018-08-03 02:24:17 --> Input Class Initialized
DEBUG - 2018-08-03 02:24:17 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-03 02:24:17 --> Helper loaded: url_helper
INFO - 2018-08-03 02:24:17 --> Language Class Initialized
ERROR - 2018-08-03 02:24:17 --> 404 Page Not Found: /index
INFO - 2018-08-03 02:24:17 --> Helper loaded: form_helper
INFO - 2018-08-03 02:24:17 --> Helper loaded: date_helper
INFO - 2018-08-03 02:24:17 --> Helper loaded: util_helper
INFO - 2018-08-03 02:24:17 --> Config Class Initialized
INFO - 2018-08-03 02:24:17 --> Hooks Class Initialized
INFO - 2018-08-03 02:24:17 --> Helper loaded: text_helper
DEBUG - 2018-08-03 02:24:18 --> UTF-8 Support Enabled
INFO - 2018-08-03 02:24:18 --> Utf8 Class Initialized
INFO - 2018-08-03 02:24:18 --> Helper loaded: string_helper
INFO - 2018-08-03 02:24:18 --> URI Class Initialized
INFO - 2018-08-03 02:24:18 --> Router Class Initialized
INFO - 2018-08-03 02:24:18 --> Database Driver Class Initialized
INFO - 2018-08-03 02:24:18 --> Output Class Initialized
INFO - 2018-08-03 02:24:18 --> Security Class Initialized
DEBUG - 2018-08-03 02:24:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-08-03 02:24:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 02:24:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-03 02:24:18 --> Input Class Initialized
INFO - 2018-08-03 02:24:18 --> Language Class Initialized
INFO - 2018-08-03 02:24:18 --> Email Class Initialized
INFO - 2018-08-03 02:24:18 --> Controller Class Initialized
ERROR - 2018-08-03 02:24:18 --> 404 Page Not Found: /index
DEBUG - 2018-08-03 02:24:18 --> Home MX_Controller Initialized
INFO - 2018-08-03 02:24:18 --> Config Class Initialized
DEBUG - 2018-08-03 02:24:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-08-03 02:24:18 --> Hooks Class Initialized
DEBUG - 2018-08-03 02:24:18 --> UTF-8 Support Enabled
DEBUG - 2018-08-03 02:24:18 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-03 02:24:18 --> Login MX_Controller Initialized
INFO - 2018-08-03 02:24:18 --> Utf8 Class Initialized
INFO - 2018-08-03 02:24:18 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-03 02:24:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-03 02:24:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-03 02:24:18 --> URI Class Initialized
INFO - 2018-08-03 02:24:18 --> Router Class Initialized
INFO - 2018-08-03 02:24:18 --> Output Class Initialized
INFO - 2018-08-03 02:24:18 --> Security Class Initialized
DEBUG - 2018-08-03 02:24:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 02:24:18 --> Input Class Initialized
INFO - 2018-08-03 02:24:18 --> Language Class Initialized
ERROR - 2018-08-03 02:24:18 --> 404 Page Not Found: /index
INFO - 2018-08-03 02:24:21 --> Config Class Initialized
INFO - 2018-08-03 02:24:21 --> Hooks Class Initialized
DEBUG - 2018-08-03 02:24:21 --> UTF-8 Support Enabled
INFO - 2018-08-03 02:24:21 --> Utf8 Class Initialized
INFO - 2018-08-03 02:24:21 --> URI Class Initialized
INFO - 2018-08-03 02:24:21 --> Router Class Initialized
INFO - 2018-08-03 02:24:21 --> Output Class Initialized
INFO - 2018-08-03 02:24:21 --> Security Class Initialized
DEBUG - 2018-08-03 02:24:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 02:24:21 --> Input Class Initialized
INFO - 2018-08-03 02:24:21 --> Language Class Initialized
INFO - 2018-08-03 02:24:21 --> Language Class Initialized
INFO - 2018-08-03 02:24:21 --> Config Class Initialized
INFO - 2018-08-03 02:24:21 --> Loader Class Initialized
DEBUG - 2018-08-03 02:24:21 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-03 02:24:21 --> Helper loaded: url_helper
INFO - 2018-08-03 02:24:21 --> Helper loaded: form_helper
INFO - 2018-08-03 02:24:21 --> Helper loaded: date_helper
INFO - 2018-08-03 02:24:21 --> Helper loaded: util_helper
INFO - 2018-08-03 02:24:21 --> Helper loaded: text_helper
INFO - 2018-08-03 02:24:21 --> Helper loaded: string_helper
INFO - 2018-08-03 02:24:21 --> Database Driver Class Initialized
DEBUG - 2018-08-03 02:24:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 02:24:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-03 02:24:21 --> Email Class Initialized
INFO - 2018-08-03 02:24:21 --> Controller Class Initialized
DEBUG - 2018-08-03 02:24:21 --> Home MX_Controller Initialized
DEBUG - 2018-08-03 02:24:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-03 02:24:21 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-03 02:24:21 --> Login MX_Controller Initialized
INFO - 2018-08-03 02:24:21 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-03 02:24:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-03 02:24:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-03 02:24:22 --> Config Class Initialized
INFO - 2018-08-03 02:24:23 --> Hooks Class Initialized
DEBUG - 2018-08-03 02:24:23 --> UTF-8 Support Enabled
INFO - 2018-08-03 02:24:23 --> Utf8 Class Initialized
INFO - 2018-08-03 02:24:23 --> URI Class Initialized
INFO - 2018-08-03 02:24:23 --> Router Class Initialized
INFO - 2018-08-03 02:24:23 --> Output Class Initialized
INFO - 2018-08-03 02:24:23 --> Security Class Initialized
DEBUG - 2018-08-03 02:24:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 02:24:23 --> Input Class Initialized
INFO - 2018-08-03 02:24:23 --> Language Class Initialized
INFO - 2018-08-03 02:24:23 --> Language Class Initialized
INFO - 2018-08-03 02:24:23 --> Config Class Initialized
INFO - 2018-08-03 02:24:23 --> Loader Class Initialized
DEBUG - 2018-08-03 02:24:23 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-03 02:24:23 --> Helper loaded: url_helper
INFO - 2018-08-03 02:24:23 --> Helper loaded: form_helper
INFO - 2018-08-03 02:24:23 --> Helper loaded: date_helper
INFO - 2018-08-03 02:24:23 --> Helper loaded: util_helper
INFO - 2018-08-03 02:24:23 --> Helper loaded: text_helper
INFO - 2018-08-03 02:24:23 --> Helper loaded: string_helper
INFO - 2018-08-03 02:24:23 --> Database Driver Class Initialized
DEBUG - 2018-08-03 02:24:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 02:24:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-03 02:24:23 --> Email Class Initialized
INFO - 2018-08-03 02:24:23 --> Controller Class Initialized
DEBUG - 2018-08-03 02:24:23 --> Home MX_Controller Initialized
DEBUG - 2018-08-03 02:24:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-03 02:24:23 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-03 02:24:23 --> Login MX_Controller Initialized
INFO - 2018-08-03 02:24:23 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-03 02:24:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-03 02:24:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-03 02:24:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-08-03 02:24:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-08-03 02:24:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-08-03 02:24:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-08-03 02:24:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-08-03 02:24:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-08-03 02:24:23 --> Final output sent to browser
DEBUG - 2018-08-03 02:24:23 --> Total execution time: 0.7168
INFO - 2018-08-03 02:24:24 --> Config Class Initialized
INFO - 2018-08-03 02:24:24 --> Hooks Class Initialized
DEBUG - 2018-08-03 02:24:24 --> UTF-8 Support Enabled
INFO - 2018-08-03 02:24:24 --> Utf8 Class Initialized
INFO - 2018-08-03 02:24:24 --> Config Class Initialized
INFO - 2018-08-03 02:24:24 --> Hooks Class Initialized
INFO - 2018-08-03 02:24:24 --> URI Class Initialized
DEBUG - 2018-08-03 02:24:24 --> UTF-8 Support Enabled
INFO - 2018-08-03 02:24:24 --> Utf8 Class Initialized
INFO - 2018-08-03 02:24:24 --> URI Class Initialized
INFO - 2018-08-03 02:24:24 --> Router Class Initialized
INFO - 2018-08-03 02:24:24 --> Router Class Initialized
INFO - 2018-08-03 02:24:24 --> Output Class Initialized
INFO - 2018-08-03 02:24:24 --> Output Class Initialized
INFO - 2018-08-03 02:24:24 --> Security Class Initialized
DEBUG - 2018-08-03 02:24:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 02:24:24 --> Input Class Initialized
INFO - 2018-08-03 02:24:24 --> Language Class Initialized
ERROR - 2018-08-03 02:24:24 --> 404 Page Not Found: /index
INFO - 2018-08-03 02:24:24 --> Security Class Initialized
DEBUG - 2018-08-03 02:24:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 02:24:24 --> Input Class Initialized
INFO - 2018-08-03 02:24:24 --> Language Class Initialized
INFO - 2018-08-03 02:24:24 --> Language Class Initialized
INFO - 2018-08-03 02:24:24 --> Config Class Initialized
INFO - 2018-08-03 02:24:24 --> Loader Class Initialized
DEBUG - 2018-08-03 02:24:24 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-03 02:24:24 --> Helper loaded: url_helper
INFO - 2018-08-03 02:24:24 --> Helper loaded: form_helper
INFO - 2018-08-03 02:24:24 --> Helper loaded: date_helper
INFO - 2018-08-03 02:24:24 --> Helper loaded: util_helper
INFO - 2018-08-03 02:24:24 --> Helper loaded: text_helper
INFO - 2018-08-03 02:24:24 --> Config Class Initialized
INFO - 2018-08-03 02:24:24 --> Hooks Class Initialized
INFO - 2018-08-03 02:24:24 --> Helper loaded: string_helper
DEBUG - 2018-08-03 02:24:24 --> UTF-8 Support Enabled
INFO - 2018-08-03 02:24:24 --> Utf8 Class Initialized
INFO - 2018-08-03 02:24:25 --> URI Class Initialized
INFO - 2018-08-03 02:24:25 --> Router Class Initialized
INFO - 2018-08-03 02:24:25 --> Database Driver Class Initialized
INFO - 2018-08-03 02:24:25 --> Output Class Initialized
DEBUG - 2018-08-03 02:24:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 02:24:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-03 02:24:25 --> Security Class Initialized
INFO - 2018-08-03 02:24:25 --> Email Class Initialized
DEBUG - 2018-08-03 02:24:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 02:24:25 --> Controller Class Initialized
DEBUG - 2018-08-03 02:24:25 --> Home MX_Controller Initialized
DEBUG - 2018-08-03 02:24:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-08-03 02:24:25 --> Input Class Initialized
DEBUG - 2018-08-03 02:24:25 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-03 02:24:25 --> Login MX_Controller Initialized
INFO - 2018-08-03 02:24:25 --> Language Class Initialized
INFO - 2018-08-03 02:24:25 --> Language file loaded: language/english/data_lang.php
ERROR - 2018-08-03 02:24:25 --> 404 Page Not Found: /index
DEBUG - 2018-08-03 02:24:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-08-03 02:24:25 --> Config Class Initialized
INFO - 2018-08-03 02:24:25 --> Hooks Class Initialized
DEBUG - 2018-08-03 02:24:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-03 02:24:25 --> UTF-8 Support Enabled
INFO - 2018-08-03 02:24:25 --> Utf8 Class Initialized
INFO - 2018-08-03 02:24:25 --> URI Class Initialized
INFO - 2018-08-03 02:24:25 --> Router Class Initialized
INFO - 2018-08-03 02:24:25 --> Output Class Initialized
INFO - 2018-08-03 02:24:25 --> Security Class Initialized
DEBUG - 2018-08-03 02:24:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 02:24:25 --> Input Class Initialized
INFO - 2018-08-03 02:24:25 --> Language Class Initialized
ERROR - 2018-08-03 02:24:25 --> 404 Page Not Found: /index
INFO - 2018-08-03 02:24:27 --> Config Class Initialized
INFO - 2018-08-03 02:24:27 --> Hooks Class Initialized
DEBUG - 2018-08-03 02:24:27 --> UTF-8 Support Enabled
INFO - 2018-08-03 02:24:27 --> Utf8 Class Initialized
INFO - 2018-08-03 02:24:27 --> URI Class Initialized
INFO - 2018-08-03 02:24:27 --> Router Class Initialized
INFO - 2018-08-03 02:24:27 --> Output Class Initialized
INFO - 2018-08-03 02:24:27 --> Security Class Initialized
DEBUG - 2018-08-03 02:24:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 02:24:27 --> Input Class Initialized
INFO - 2018-08-03 02:24:27 --> Language Class Initialized
INFO - 2018-08-03 02:24:27 --> Language Class Initialized
INFO - 2018-08-03 02:24:27 --> Config Class Initialized
INFO - 2018-08-03 02:24:27 --> Loader Class Initialized
DEBUG - 2018-08-03 02:24:27 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-03 02:24:27 --> Helper loaded: url_helper
INFO - 2018-08-03 02:24:27 --> Helper loaded: form_helper
INFO - 2018-08-03 02:24:27 --> Helper loaded: date_helper
INFO - 2018-08-03 02:24:27 --> Helper loaded: util_helper
INFO - 2018-08-03 02:24:27 --> Helper loaded: text_helper
INFO - 2018-08-03 02:24:27 --> Helper loaded: string_helper
INFO - 2018-08-03 02:24:27 --> Database Driver Class Initialized
DEBUG - 2018-08-03 02:24:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 02:24:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-03 02:24:27 --> Email Class Initialized
INFO - 2018-08-03 02:24:27 --> Controller Class Initialized
DEBUG - 2018-08-03 02:24:27 --> Home MX_Controller Initialized
DEBUG - 2018-08-03 02:24:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-03 02:24:27 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-03 02:24:27 --> Login MX_Controller Initialized
INFO - 2018-08-03 02:24:27 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-03 02:24:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-03 02:24:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-03 02:24:28 --> Config Class Initialized
INFO - 2018-08-03 02:24:28 --> Hooks Class Initialized
DEBUG - 2018-08-03 02:24:28 --> UTF-8 Support Enabled
INFO - 2018-08-03 02:24:28 --> Utf8 Class Initialized
INFO - 2018-08-03 02:24:28 --> URI Class Initialized
INFO - 2018-08-03 02:24:28 --> Router Class Initialized
INFO - 2018-08-03 02:24:29 --> Output Class Initialized
INFO - 2018-08-03 02:24:29 --> Security Class Initialized
DEBUG - 2018-08-03 02:24:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 02:24:29 --> Input Class Initialized
INFO - 2018-08-03 02:24:29 --> Language Class Initialized
INFO - 2018-08-03 02:24:29 --> Language Class Initialized
INFO - 2018-08-03 02:24:29 --> Config Class Initialized
INFO - 2018-08-03 02:24:29 --> Loader Class Initialized
DEBUG - 2018-08-03 02:24:29 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-03 02:24:29 --> Helper loaded: url_helper
INFO - 2018-08-03 02:24:29 --> Helper loaded: form_helper
INFO - 2018-08-03 02:24:29 --> Helper loaded: date_helper
INFO - 2018-08-03 02:24:29 --> Helper loaded: util_helper
INFO - 2018-08-03 02:24:29 --> Helper loaded: text_helper
INFO - 2018-08-03 02:24:29 --> Helper loaded: string_helper
INFO - 2018-08-03 02:24:29 --> Database Driver Class Initialized
DEBUG - 2018-08-03 02:24:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 02:24:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-03 02:24:29 --> Email Class Initialized
INFO - 2018-08-03 02:24:29 --> Controller Class Initialized
DEBUG - 2018-08-03 02:24:29 --> Home MX_Controller Initialized
DEBUG - 2018-08-03 02:24:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-03 02:24:29 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-03 02:24:29 --> Login MX_Controller Initialized
INFO - 2018-08-03 02:24:29 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-03 02:24:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-03 02:24:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-03 02:24:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-08-03 02:24:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-08-03 02:24:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-08-03 02:24:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-08-03 02:24:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-08-03 02:24:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-08-03 02:24:29 --> Final output sent to browser
DEBUG - 2018-08-03 02:24:29 --> Total execution time: 0.8209
INFO - 2018-08-03 02:24:30 --> Config Class Initialized
INFO - 2018-08-03 02:24:30 --> Hooks Class Initialized
DEBUG - 2018-08-03 02:24:30 --> UTF-8 Support Enabled
INFO - 2018-08-03 02:24:30 --> Utf8 Class Initialized
INFO - 2018-08-03 02:24:30 --> Config Class Initialized
INFO - 2018-08-03 02:24:30 --> Hooks Class Initialized
INFO - 2018-08-03 02:24:30 --> URI Class Initialized
DEBUG - 2018-08-03 02:24:30 --> UTF-8 Support Enabled
INFO - 2018-08-03 02:24:30 --> Utf8 Class Initialized
INFO - 2018-08-03 02:24:30 --> Router Class Initialized
INFO - 2018-08-03 02:24:30 --> Output Class Initialized
INFO - 2018-08-03 02:24:30 --> URI Class Initialized
INFO - 2018-08-03 02:24:30 --> Security Class Initialized
INFO - 2018-08-03 02:24:30 --> Router Class Initialized
INFO - 2018-08-03 02:24:30 --> Output Class Initialized
DEBUG - 2018-08-03 02:24:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 02:24:30 --> Input Class Initialized
INFO - 2018-08-03 02:24:30 --> Security Class Initialized
INFO - 2018-08-03 02:24:30 --> Language Class Initialized
DEBUG - 2018-08-03 02:24:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-08-03 02:24:30 --> 404 Page Not Found: /index
INFO - 2018-08-03 02:24:30 --> Input Class Initialized
INFO - 2018-08-03 02:24:30 --> Language Class Initialized
INFO - 2018-08-03 02:24:30 --> Language Class Initialized
INFO - 2018-08-03 02:24:30 --> Config Class Initialized
INFO - 2018-08-03 02:24:30 --> Loader Class Initialized
DEBUG - 2018-08-03 02:24:30 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-03 02:24:30 --> Helper loaded: url_helper
INFO - 2018-08-03 02:24:30 --> Config Class Initialized
INFO - 2018-08-03 02:24:30 --> Hooks Class Initialized
INFO - 2018-08-03 02:24:30 --> Helper loaded: form_helper
DEBUG - 2018-08-03 02:24:30 --> UTF-8 Support Enabled
INFO - 2018-08-03 02:24:30 --> Helper loaded: date_helper
INFO - 2018-08-03 02:24:30 --> Utf8 Class Initialized
INFO - 2018-08-03 02:24:30 --> URI Class Initialized
INFO - 2018-08-03 02:24:30 --> Router Class Initialized
INFO - 2018-08-03 02:24:30 --> Helper loaded: util_helper
INFO - 2018-08-03 02:24:30 --> Output Class Initialized
INFO - 2018-08-03 02:24:30 --> Security Class Initialized
INFO - 2018-08-03 02:24:31 --> Helper loaded: text_helper
DEBUG - 2018-08-03 02:24:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 02:24:31 --> Helper loaded: string_helper
INFO - 2018-08-03 02:24:31 --> Input Class Initialized
INFO - 2018-08-03 02:24:31 --> Database Driver Class Initialized
INFO - 2018-08-03 02:24:31 --> Language Class Initialized
DEBUG - 2018-08-03 02:24:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 02:24:31 --> Session: Class initialized using 'files' driver.
ERROR - 2018-08-03 02:24:31 --> 404 Page Not Found: /index
INFO - 2018-08-03 02:24:31 --> Email Class Initialized
INFO - 2018-08-03 02:24:31 --> Controller Class Initialized
INFO - 2018-08-03 02:24:31 --> Config Class Initialized
INFO - 2018-08-03 02:24:31 --> Hooks Class Initialized
DEBUG - 2018-08-03 02:24:31 --> Home MX_Controller Initialized
DEBUG - 2018-08-03 02:24:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-03 02:24:31 --> UTF-8 Support Enabled
INFO - 2018-08-03 02:24:31 --> Utf8 Class Initialized
DEBUG - 2018-08-03 02:24:31 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-03 02:24:31 --> Login MX_Controller Initialized
INFO - 2018-08-03 02:24:31 --> URI Class Initialized
INFO - 2018-08-03 02:24:31 --> Language file loaded: language/english/data_lang.php
INFO - 2018-08-03 02:24:31 --> Router Class Initialized
DEBUG - 2018-08-03 02:24:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-08-03 02:24:31 --> Output Class Initialized
INFO - 2018-08-03 02:24:31 --> Security Class Initialized
DEBUG - 2018-08-03 02:24:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-03 02:24:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 02:24:31 --> Input Class Initialized
INFO - 2018-08-03 02:24:31 --> Language Class Initialized
ERROR - 2018-08-03 02:24:31 --> 404 Page Not Found: /index
INFO - 2018-08-03 02:24:32 --> Config Class Initialized
INFO - 2018-08-03 02:24:32 --> Hooks Class Initialized
DEBUG - 2018-08-03 02:24:32 --> UTF-8 Support Enabled
INFO - 2018-08-03 02:24:32 --> Utf8 Class Initialized
INFO - 2018-08-03 02:24:32 --> URI Class Initialized
INFO - 2018-08-03 02:24:32 --> Router Class Initialized
INFO - 2018-08-03 02:24:32 --> Output Class Initialized
INFO - 2018-08-03 02:24:32 --> Security Class Initialized
DEBUG - 2018-08-03 02:24:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 02:24:32 --> Input Class Initialized
INFO - 2018-08-03 02:24:32 --> Language Class Initialized
INFO - 2018-08-03 02:24:32 --> Language Class Initialized
INFO - 2018-08-03 02:24:32 --> Config Class Initialized
INFO - 2018-08-03 02:24:32 --> Loader Class Initialized
DEBUG - 2018-08-03 02:24:32 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-03 02:24:32 --> Helper loaded: url_helper
INFO - 2018-08-03 02:24:32 --> Helper loaded: form_helper
INFO - 2018-08-03 02:24:32 --> Helper loaded: date_helper
INFO - 2018-08-03 02:24:32 --> Helper loaded: util_helper
INFO - 2018-08-03 02:24:32 --> Helper loaded: text_helper
INFO - 2018-08-03 02:24:32 --> Helper loaded: string_helper
INFO - 2018-08-03 02:24:32 --> Database Driver Class Initialized
DEBUG - 2018-08-03 02:24:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 02:24:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-03 02:24:32 --> Email Class Initialized
INFO - 2018-08-03 02:24:32 --> Controller Class Initialized
DEBUG - 2018-08-03 02:24:32 --> Home MX_Controller Initialized
DEBUG - 2018-08-03 02:24:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-03 02:24:32 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-03 02:24:32 --> Login MX_Controller Initialized
INFO - 2018-08-03 02:24:33 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-03 02:24:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-03 02:24:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-03 02:24:34 --> Config Class Initialized
INFO - 2018-08-03 02:24:34 --> Hooks Class Initialized
DEBUG - 2018-08-03 02:24:34 --> UTF-8 Support Enabled
INFO - 2018-08-03 02:24:34 --> Utf8 Class Initialized
INFO - 2018-08-03 02:24:34 --> URI Class Initialized
INFO - 2018-08-03 02:24:34 --> Router Class Initialized
INFO - 2018-08-03 02:24:34 --> Output Class Initialized
INFO - 2018-08-03 02:24:34 --> Security Class Initialized
DEBUG - 2018-08-03 02:24:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 02:24:34 --> Input Class Initialized
INFO - 2018-08-03 02:24:34 --> Language Class Initialized
INFO - 2018-08-03 02:24:34 --> Language Class Initialized
INFO - 2018-08-03 02:24:34 --> Config Class Initialized
INFO - 2018-08-03 02:24:34 --> Loader Class Initialized
DEBUG - 2018-08-03 02:24:34 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-03 02:24:34 --> Helper loaded: url_helper
INFO - 2018-08-03 02:24:34 --> Helper loaded: form_helper
INFO - 2018-08-03 02:24:34 --> Helper loaded: date_helper
INFO - 2018-08-03 02:24:34 --> Helper loaded: util_helper
INFO - 2018-08-03 02:24:34 --> Helper loaded: text_helper
INFO - 2018-08-03 02:24:34 --> Helper loaded: string_helper
INFO - 2018-08-03 02:24:34 --> Database Driver Class Initialized
DEBUG - 2018-08-03 02:24:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 02:24:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-03 02:24:34 --> Email Class Initialized
INFO - 2018-08-03 02:24:34 --> Controller Class Initialized
DEBUG - 2018-08-03 02:24:34 --> Home MX_Controller Initialized
DEBUG - 2018-08-03 02:24:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-03 02:24:35 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-03 02:24:35 --> Login MX_Controller Initialized
INFO - 2018-08-03 02:24:35 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-03 02:24:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-03 02:24:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-03 02:24:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-08-03 02:24:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-08-03 02:24:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-08-03 02:24:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-08-03 02:24:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-08-03 02:24:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-08-03 02:24:35 --> Final output sent to browser
DEBUG - 2018-08-03 02:24:35 --> Total execution time: 0.7493
INFO - 2018-08-03 02:24:35 --> Config Class Initialized
INFO - 2018-08-03 02:24:35 --> Hooks Class Initialized
DEBUG - 2018-08-03 02:24:35 --> UTF-8 Support Enabled
INFO - 2018-08-03 02:24:35 --> Utf8 Class Initialized
INFO - 2018-08-03 02:24:35 --> Config Class Initialized
INFO - 2018-08-03 02:24:35 --> Hooks Class Initialized
INFO - 2018-08-03 02:24:35 --> URI Class Initialized
DEBUG - 2018-08-03 02:24:35 --> UTF-8 Support Enabled
INFO - 2018-08-03 02:24:36 --> Utf8 Class Initialized
INFO - 2018-08-03 02:24:36 --> URI Class Initialized
INFO - 2018-08-03 02:24:36 --> Router Class Initialized
INFO - 2018-08-03 02:24:36 --> Router Class Initialized
INFO - 2018-08-03 02:24:36 --> Output Class Initialized
INFO - 2018-08-03 02:24:36 --> Output Class Initialized
INFO - 2018-08-03 02:24:36 --> Security Class Initialized
DEBUG - 2018-08-03 02:24:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 02:24:36 --> Security Class Initialized
INFO - 2018-08-03 02:24:36 --> Input Class Initialized
INFO - 2018-08-03 02:24:36 --> Language Class Initialized
ERROR - 2018-08-03 02:24:36 --> 404 Page Not Found: /index
DEBUG - 2018-08-03 02:24:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 02:24:36 --> Config Class Initialized
INFO - 2018-08-03 02:24:36 --> Input Class Initialized
INFO - 2018-08-03 02:24:36 --> Hooks Class Initialized
INFO - 2018-08-03 02:24:36 --> Language Class Initialized
DEBUG - 2018-08-03 02:24:36 --> UTF-8 Support Enabled
INFO - 2018-08-03 02:24:36 --> Utf8 Class Initialized
INFO - 2018-08-03 02:24:36 --> Language Class Initialized
INFO - 2018-08-03 02:24:36 --> URI Class Initialized
INFO - 2018-08-03 02:24:36 --> Config Class Initialized
INFO - 2018-08-03 02:24:36 --> Loader Class Initialized
INFO - 2018-08-03 02:24:36 --> Router Class Initialized
DEBUG - 2018-08-03 02:24:36 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-03 02:24:36 --> Output Class Initialized
INFO - 2018-08-03 02:24:36 --> Helper loaded: url_helper
INFO - 2018-08-03 02:24:36 --> Helper loaded: form_helper
INFO - 2018-08-03 02:24:36 --> Helper loaded: date_helper
INFO - 2018-08-03 02:24:36 --> Helper loaded: util_helper
INFO - 2018-08-03 02:24:36 --> Helper loaded: text_helper
INFO - 2018-08-03 02:24:36 --> Security Class Initialized
DEBUG - 2018-08-03 02:24:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 02:24:36 --> Helper loaded: string_helper
INFO - 2018-08-03 02:24:36 --> Input Class Initialized
INFO - 2018-08-03 02:24:36 --> Language Class Initialized
ERROR - 2018-08-03 02:24:36 --> 404 Page Not Found: /index
INFO - 2018-08-03 02:24:36 --> Config Class Initialized
INFO - 2018-08-03 02:24:36 --> Hooks Class Initialized
DEBUG - 2018-08-03 02:24:36 --> UTF-8 Support Enabled
INFO - 2018-08-03 02:24:36 --> Database Driver Class Initialized
INFO - 2018-08-03 02:24:36 --> Utf8 Class Initialized
DEBUG - 2018-08-03 02:24:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 02:24:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-03 02:24:36 --> URI Class Initialized
INFO - 2018-08-03 02:24:36 --> Email Class Initialized
INFO - 2018-08-03 02:24:36 --> Router Class Initialized
INFO - 2018-08-03 02:24:36 --> Controller Class Initialized
DEBUG - 2018-08-03 02:24:36 --> Home MX_Controller Initialized
DEBUG - 2018-08-03 02:24:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-08-03 02:24:36 --> Output Class Initialized
DEBUG - 2018-08-03 02:24:36 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-03 02:24:36 --> Login MX_Controller Initialized
INFO - 2018-08-03 02:24:36 --> Security Class Initialized
DEBUG - 2018-08-03 02:24:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 02:24:37 --> Language file loaded: language/english/data_lang.php
INFO - 2018-08-03 02:24:37 --> Input Class Initialized
INFO - 2018-08-03 02:24:37 --> Language Class Initialized
DEBUG - 2018-08-03 02:24:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-03 02:24:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
ERROR - 2018-08-03 02:24:37 --> 404 Page Not Found: /index
INFO - 2018-08-03 02:25:07 --> Config Class Initialized
INFO - 2018-08-03 02:25:07 --> Hooks Class Initialized
DEBUG - 2018-08-03 02:25:07 --> UTF-8 Support Enabled
INFO - 2018-08-03 02:25:07 --> Utf8 Class Initialized
INFO - 2018-08-03 02:25:07 --> URI Class Initialized
INFO - 2018-08-03 02:25:07 --> Router Class Initialized
INFO - 2018-08-03 02:25:07 --> Output Class Initialized
INFO - 2018-08-03 02:25:07 --> Security Class Initialized
DEBUG - 2018-08-03 02:25:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 02:25:08 --> Input Class Initialized
INFO - 2018-08-03 02:25:08 --> Language Class Initialized
INFO - 2018-08-03 02:25:08 --> Language Class Initialized
INFO - 2018-08-03 02:25:08 --> Config Class Initialized
INFO - 2018-08-03 02:25:08 --> Loader Class Initialized
DEBUG - 2018-08-03 02:25:08 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-03 02:25:08 --> Helper loaded: url_helper
INFO - 2018-08-03 02:25:08 --> Helper loaded: form_helper
INFO - 2018-08-03 02:25:08 --> Helper loaded: date_helper
INFO - 2018-08-03 02:25:08 --> Helper loaded: util_helper
INFO - 2018-08-03 02:25:08 --> Helper loaded: text_helper
INFO - 2018-08-03 02:25:08 --> Helper loaded: string_helper
INFO - 2018-08-03 02:25:08 --> Database Driver Class Initialized
DEBUG - 2018-08-03 02:25:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 02:25:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-03 02:25:08 --> Email Class Initialized
INFO - 2018-08-03 02:25:08 --> Controller Class Initialized
DEBUG - 2018-08-03 02:25:08 --> Home MX_Controller Initialized
DEBUG - 2018-08-03 02:25:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-03 02:25:08 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-03 02:25:08 --> Login MX_Controller Initialized
INFO - 2018-08-03 02:25:08 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-03 02:25:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-03 02:25:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-03 02:25:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-08-03 02:25:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-08-03 02:25:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-08-03 02:25:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-08-03 02:25:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-08-03 02:25:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-08-03 02:25:08 --> Final output sent to browser
DEBUG - 2018-08-03 02:25:08 --> Total execution time: 0.6781
INFO - 2018-08-03 02:25:09 --> Config Class Initialized
INFO - 2018-08-03 02:25:09 --> Hooks Class Initialized
DEBUG - 2018-08-03 02:25:09 --> UTF-8 Support Enabled
INFO - 2018-08-03 02:25:09 --> Utf8 Class Initialized
INFO - 2018-08-03 02:25:09 --> URI Class Initialized
INFO - 2018-08-03 02:25:09 --> Config Class Initialized
INFO - 2018-08-03 02:25:09 --> Hooks Class Initialized
INFO - 2018-08-03 02:25:09 --> Router Class Initialized
DEBUG - 2018-08-03 02:25:09 --> UTF-8 Support Enabled
INFO - 2018-08-03 02:25:09 --> Utf8 Class Initialized
INFO - 2018-08-03 02:25:09 --> URI Class Initialized
INFO - 2018-08-03 02:25:09 --> Output Class Initialized
INFO - 2018-08-03 02:25:09 --> Router Class Initialized
INFO - 2018-08-03 02:25:09 --> Security Class Initialized
INFO - 2018-08-03 02:25:09 --> Output Class Initialized
DEBUG - 2018-08-03 02:25:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 02:25:09 --> Security Class Initialized
INFO - 2018-08-03 02:25:09 --> Input Class Initialized
DEBUG - 2018-08-03 02:25:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 02:25:09 --> Language Class Initialized
INFO - 2018-08-03 02:25:09 --> Input Class Initialized
ERROR - 2018-08-03 02:25:09 --> 404 Page Not Found: /index
INFO - 2018-08-03 02:25:09 --> Language Class Initialized
INFO - 2018-08-03 02:25:09 --> Config Class Initialized
INFO - 2018-08-03 02:25:09 --> Hooks Class Initialized
INFO - 2018-08-03 02:25:09 --> Language Class Initialized
DEBUG - 2018-08-03 02:25:09 --> UTF-8 Support Enabled
INFO - 2018-08-03 02:25:09 --> Config Class Initialized
INFO - 2018-08-03 02:25:09 --> Utf8 Class Initialized
INFO - 2018-08-03 02:25:09 --> URI Class Initialized
INFO - 2018-08-03 02:25:09 --> Router Class Initialized
INFO - 2018-08-03 02:25:09 --> Loader Class Initialized
DEBUG - 2018-08-03 02:25:09 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-03 02:25:09 --> Output Class Initialized
INFO - 2018-08-03 02:25:09 --> Security Class Initialized
INFO - 2018-08-03 02:25:09 --> Helper loaded: url_helper
DEBUG - 2018-08-03 02:25:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 02:25:09 --> Input Class Initialized
INFO - 2018-08-03 02:25:09 --> Language Class Initialized
INFO - 2018-08-03 02:25:09 --> Helper loaded: form_helper
INFO - 2018-08-03 02:25:09 --> Helper loaded: date_helper
ERROR - 2018-08-03 02:25:09 --> 404 Page Not Found: /index
INFO - 2018-08-03 02:25:10 --> Helper loaded: util_helper
INFO - 2018-08-03 02:25:10 --> Helper loaded: text_helper
INFO - 2018-08-03 02:25:10 --> Config Class Initialized
INFO - 2018-08-03 02:25:10 --> Hooks Class Initialized
INFO - 2018-08-03 02:25:10 --> Helper loaded: string_helper
DEBUG - 2018-08-03 02:25:10 --> UTF-8 Support Enabled
INFO - 2018-08-03 02:25:10 --> Utf8 Class Initialized
INFO - 2018-08-03 02:25:10 --> URI Class Initialized
INFO - 2018-08-03 02:25:10 --> Router Class Initialized
INFO - 2018-08-03 02:25:10 --> Database Driver Class Initialized
INFO - 2018-08-03 02:25:10 --> Output Class Initialized
INFO - 2018-08-03 02:25:10 --> Security Class Initialized
DEBUG - 2018-08-03 02:25:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-08-03 02:25:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 02:25:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-03 02:25:10 --> Input Class Initialized
INFO - 2018-08-03 02:25:10 --> Language Class Initialized
INFO - 2018-08-03 02:25:10 --> Email Class Initialized
ERROR - 2018-08-03 02:25:10 --> 404 Page Not Found: /index
INFO - 2018-08-03 02:25:10 --> Controller Class Initialized
DEBUG - 2018-08-03 02:25:10 --> Home MX_Controller Initialized
DEBUG - 2018-08-03 02:25:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-03 02:25:10 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-03 02:25:10 --> Login MX_Controller Initialized
INFO - 2018-08-03 02:25:10 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-03 02:25:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-03 02:25:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-03 02:29:28 --> Config Class Initialized
INFO - 2018-08-03 02:29:28 --> Hooks Class Initialized
DEBUG - 2018-08-03 02:29:28 --> UTF-8 Support Enabled
INFO - 2018-08-03 02:29:28 --> Utf8 Class Initialized
INFO - 2018-08-03 02:29:28 --> URI Class Initialized
INFO - 2018-08-03 02:29:28 --> Router Class Initialized
INFO - 2018-08-03 02:29:28 --> Output Class Initialized
INFO - 2018-08-03 02:29:28 --> Security Class Initialized
DEBUG - 2018-08-03 02:29:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 02:29:28 --> Input Class Initialized
INFO - 2018-08-03 02:29:28 --> Language Class Initialized
ERROR - 2018-08-03 02:29:28 --> 404 Page Not Found: /index
INFO - 2018-08-03 02:30:13 --> Config Class Initialized
INFO - 2018-08-03 02:30:13 --> Hooks Class Initialized
DEBUG - 2018-08-03 02:30:13 --> UTF-8 Support Enabled
INFO - 2018-08-03 02:30:13 --> Utf8 Class Initialized
INFO - 2018-08-03 02:30:13 --> URI Class Initialized
INFO - 2018-08-03 02:30:13 --> Router Class Initialized
INFO - 2018-08-03 02:30:13 --> Output Class Initialized
INFO - 2018-08-03 02:30:13 --> Security Class Initialized
DEBUG - 2018-08-03 02:30:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 02:30:14 --> Input Class Initialized
INFO - 2018-08-03 02:30:14 --> Language Class Initialized
INFO - 2018-08-03 02:30:14 --> Language Class Initialized
INFO - 2018-08-03 02:30:14 --> Config Class Initialized
INFO - 2018-08-03 02:30:14 --> Loader Class Initialized
DEBUG - 2018-08-03 02:30:14 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-03 02:30:14 --> Helper loaded: url_helper
INFO - 2018-08-03 02:30:14 --> Helper loaded: form_helper
INFO - 2018-08-03 02:30:14 --> Helper loaded: date_helper
INFO - 2018-08-03 02:30:14 --> Helper loaded: util_helper
INFO - 2018-08-03 02:30:14 --> Helper loaded: text_helper
INFO - 2018-08-03 02:30:14 --> Helper loaded: string_helper
INFO - 2018-08-03 02:30:14 --> Database Driver Class Initialized
DEBUG - 2018-08-03 02:30:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 02:30:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-03 02:30:14 --> Email Class Initialized
INFO - 2018-08-03 02:30:14 --> Controller Class Initialized
DEBUG - 2018-08-03 02:30:14 --> Home MX_Controller Initialized
DEBUG - 2018-08-03 02:30:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-03 02:30:14 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-03 02:30:14 --> Login MX_Controller Initialized
INFO - 2018-08-03 02:30:14 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-03 02:30:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-03 02:30:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-03 02:31:29 --> Config Class Initialized
INFO - 2018-08-03 02:31:29 --> Hooks Class Initialized
DEBUG - 2018-08-03 02:31:29 --> UTF-8 Support Enabled
INFO - 2018-08-03 02:31:30 --> Utf8 Class Initialized
INFO - 2018-08-03 02:31:30 --> URI Class Initialized
INFO - 2018-08-03 02:31:30 --> Router Class Initialized
INFO - 2018-08-03 02:31:30 --> Output Class Initialized
INFO - 2018-08-03 02:31:30 --> Security Class Initialized
DEBUG - 2018-08-03 02:31:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 02:31:30 --> Input Class Initialized
INFO - 2018-08-03 02:31:30 --> Language Class Initialized
INFO - 2018-08-03 02:31:30 --> Language Class Initialized
INFO - 2018-08-03 02:31:30 --> Config Class Initialized
INFO - 2018-08-03 02:31:30 --> Loader Class Initialized
DEBUG - 2018-08-03 02:31:30 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-03 02:31:30 --> Helper loaded: url_helper
INFO - 2018-08-03 02:31:30 --> Helper loaded: form_helper
INFO - 2018-08-03 02:31:30 --> Helper loaded: date_helper
INFO - 2018-08-03 02:31:30 --> Helper loaded: util_helper
INFO - 2018-08-03 02:31:30 --> Helper loaded: text_helper
INFO - 2018-08-03 02:31:30 --> Helper loaded: string_helper
INFO - 2018-08-03 02:31:30 --> Database Driver Class Initialized
DEBUG - 2018-08-03 02:31:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 02:31:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-03 02:31:30 --> Email Class Initialized
INFO - 2018-08-03 02:31:30 --> Controller Class Initialized
DEBUG - 2018-08-03 02:31:30 --> Home MX_Controller Initialized
DEBUG - 2018-08-03 02:31:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-03 02:31:30 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-03 02:31:30 --> Login MX_Controller Initialized
INFO - 2018-08-03 02:31:30 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-03 02:31:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-03 02:31:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-03 02:31:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-08-03 02:31:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-08-03 02:31:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-08-03 02:31:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-08-03 02:31:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-08-03 02:31:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-08-03 02:31:30 --> Final output sent to browser
DEBUG - 2018-08-03 02:31:30 --> Total execution time: 0.6818
INFO - 2018-08-03 02:31:31 --> Config Class Initialized
INFO - 2018-08-03 02:31:31 --> Hooks Class Initialized
INFO - 2018-08-03 02:31:31 --> Config Class Initialized
INFO - 2018-08-03 02:31:31 --> Hooks Class Initialized
DEBUG - 2018-08-03 02:31:31 --> UTF-8 Support Enabled
INFO - 2018-08-03 02:31:31 --> Utf8 Class Initialized
DEBUG - 2018-08-03 02:31:31 --> UTF-8 Support Enabled
INFO - 2018-08-03 02:31:31 --> Utf8 Class Initialized
INFO - 2018-08-03 02:31:31 --> URI Class Initialized
INFO - 2018-08-03 02:31:31 --> URI Class Initialized
INFO - 2018-08-03 02:31:31 --> Router Class Initialized
INFO - 2018-08-03 02:31:31 --> Output Class Initialized
INFO - 2018-08-03 02:31:31 --> Router Class Initialized
INFO - 2018-08-03 02:31:31 --> Security Class Initialized
INFO - 2018-08-03 02:31:31 --> Output Class Initialized
DEBUG - 2018-08-03 02:31:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 02:31:31 --> Input Class Initialized
INFO - 2018-08-03 02:31:31 --> Security Class Initialized
INFO - 2018-08-03 02:31:31 --> Language Class Initialized
DEBUG - 2018-08-03 02:31:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 02:31:31 --> Input Class Initialized
INFO - 2018-08-03 02:31:31 --> Language Class Initialized
INFO - 2018-08-03 02:31:31 --> Config Class Initialized
INFO - 2018-08-03 02:31:31 --> Language Class Initialized
INFO - 2018-08-03 02:31:31 --> Loader Class Initialized
ERROR - 2018-08-03 02:31:31 --> 404 Page Not Found: /index
DEBUG - 2018-08-03 02:31:31 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-03 02:31:31 --> Helper loaded: url_helper
INFO - 2018-08-03 02:31:31 --> Config Class Initialized
INFO - 2018-08-03 02:31:31 --> Hooks Class Initialized
INFO - 2018-08-03 02:31:31 --> Helper loaded: form_helper
DEBUG - 2018-08-03 02:31:31 --> UTF-8 Support Enabled
INFO - 2018-08-03 02:31:31 --> Helper loaded: date_helper
INFO - 2018-08-03 02:31:31 --> Utf8 Class Initialized
INFO - 2018-08-03 02:31:31 --> Helper loaded: util_helper
INFO - 2018-08-03 02:31:31 --> URI Class Initialized
INFO - 2018-08-03 02:31:31 --> Helper loaded: text_helper
INFO - 2018-08-03 02:31:31 --> Helper loaded: string_helper
INFO - 2018-08-03 02:31:31 --> Router Class Initialized
INFO - 2018-08-03 02:31:31 --> Output Class Initialized
INFO - 2018-08-03 02:31:31 --> Database Driver Class Initialized
INFO - 2018-08-03 02:31:31 --> Security Class Initialized
DEBUG - 2018-08-03 02:31:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 02:31:31 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-08-03 02:31:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 02:31:31 --> Input Class Initialized
INFO - 2018-08-03 02:31:31 --> Email Class Initialized
INFO - 2018-08-03 02:31:31 --> Controller Class Initialized
INFO - 2018-08-03 02:31:31 --> Language Class Initialized
DEBUG - 2018-08-03 02:31:31 --> Home MX_Controller Initialized
ERROR - 2018-08-03 02:31:31 --> 404 Page Not Found: /index
DEBUG - 2018-08-03 02:31:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-08-03 02:31:32 --> Config Class Initialized
DEBUG - 2018-08-03 02:31:32 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-03 02:31:32 --> Login MX_Controller Initialized
INFO - 2018-08-03 02:31:32 --> Hooks Class Initialized
INFO - 2018-08-03 02:31:32 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-03 02:31:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-03 02:31:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-03 02:31:32 --> UTF-8 Support Enabled
INFO - 2018-08-03 02:31:32 --> Utf8 Class Initialized
INFO - 2018-08-03 02:31:32 --> URI Class Initialized
INFO - 2018-08-03 02:31:32 --> Router Class Initialized
INFO - 2018-08-03 02:31:32 --> Output Class Initialized
INFO - 2018-08-03 02:31:32 --> Security Class Initialized
DEBUG - 2018-08-03 02:31:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 02:31:32 --> Input Class Initialized
INFO - 2018-08-03 02:31:32 --> Language Class Initialized
ERROR - 2018-08-03 02:31:32 --> 404 Page Not Found: /index
INFO - 2018-08-03 02:32:29 --> Config Class Initialized
INFO - 2018-08-03 02:32:29 --> Hooks Class Initialized
DEBUG - 2018-08-03 02:32:29 --> UTF-8 Support Enabled
INFO - 2018-08-03 02:32:29 --> Utf8 Class Initialized
INFO - 2018-08-03 02:32:29 --> URI Class Initialized
INFO - 2018-08-03 02:32:30 --> Router Class Initialized
INFO - 2018-08-03 02:32:30 --> Output Class Initialized
INFO - 2018-08-03 02:32:30 --> Security Class Initialized
DEBUG - 2018-08-03 02:32:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 02:32:30 --> Input Class Initialized
INFO - 2018-08-03 02:32:30 --> Language Class Initialized
INFO - 2018-08-03 02:32:30 --> Language Class Initialized
INFO - 2018-08-03 02:32:30 --> Config Class Initialized
INFO - 2018-08-03 02:32:30 --> Loader Class Initialized
DEBUG - 2018-08-03 02:32:30 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-03 02:32:30 --> Helper loaded: url_helper
INFO - 2018-08-03 02:32:30 --> Helper loaded: form_helper
INFO - 2018-08-03 02:32:30 --> Helper loaded: date_helper
INFO - 2018-08-03 02:32:30 --> Helper loaded: util_helper
INFO - 2018-08-03 02:32:30 --> Helper loaded: text_helper
INFO - 2018-08-03 02:32:30 --> Helper loaded: string_helper
INFO - 2018-08-03 02:32:30 --> Database Driver Class Initialized
DEBUG - 2018-08-03 02:32:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 02:32:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-03 02:32:30 --> Email Class Initialized
INFO - 2018-08-03 02:32:30 --> Controller Class Initialized
DEBUG - 2018-08-03 02:32:30 --> Admin MX_Controller Initialized
INFO - 2018-08-03 02:32:30 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-03 02:32:30 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-03 02:32:30 --> Login MX_Controller Initialized
DEBUG - 2018-08-03 02:32:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-03 02:32:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-03 02:32:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-08-03 02:32:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-08-03 02:32:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-08-03 02:32:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-08-03 02:32:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-08-03 02:32:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/dashboard.php
INFO - 2018-08-03 02:32:30 --> Final output sent to browser
INFO - 2018-08-03 02:32:30 --> Config Class Initialized
INFO - 2018-08-03 02:32:30 --> Config Class Initialized
DEBUG - 2018-08-03 02:32:30 --> Total execution time: 0.6533
INFO - 2018-08-03 02:32:30 --> Hooks Class Initialized
INFO - 2018-08-03 02:32:30 --> Hooks Class Initialized
DEBUG - 2018-08-03 02:32:30 --> UTF-8 Support Enabled
INFO - 2018-08-03 02:32:30 --> Utf8 Class Initialized
INFO - 2018-08-03 02:32:30 --> URI Class Initialized
INFO - 2018-08-03 02:32:30 --> Router Class Initialized
INFO - 2018-08-03 02:32:30 --> Output Class Initialized
DEBUG - 2018-08-03 02:32:30 --> UTF-8 Support Enabled
INFO - 2018-08-03 02:32:30 --> Security Class Initialized
INFO - 2018-08-03 02:32:30 --> Utf8 Class Initialized
DEBUG - 2018-08-03 02:32:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 02:32:30 --> Input Class Initialized
INFO - 2018-08-03 02:32:30 --> URI Class Initialized
INFO - 2018-08-03 02:32:30 --> Language Class Initialized
INFO - 2018-08-03 02:32:30 --> Router Class Initialized
ERROR - 2018-08-03 02:32:30 --> 404 Page Not Found: /index
INFO - 2018-08-03 02:32:31 --> Output Class Initialized
INFO - 2018-08-03 02:32:31 --> Security Class Initialized
DEBUG - 2018-08-03 02:32:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 02:32:31 --> Input Class Initialized
INFO - 2018-08-03 02:32:31 --> Language Class Initialized
ERROR - 2018-08-03 02:32:31 --> 404 Page Not Found: /index
INFO - 2018-08-03 02:32:31 --> Config Class Initialized
INFO - 2018-08-03 02:32:31 --> Hooks Class Initialized
DEBUG - 2018-08-03 02:32:31 --> UTF-8 Support Enabled
INFO - 2018-08-03 02:32:31 --> Utf8 Class Initialized
INFO - 2018-08-03 02:32:31 --> URI Class Initialized
INFO - 2018-08-03 02:32:31 --> Router Class Initialized
INFO - 2018-08-03 02:32:31 --> Output Class Initialized
INFO - 2018-08-03 02:32:31 --> Security Class Initialized
DEBUG - 2018-08-03 02:32:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 02:32:31 --> Input Class Initialized
INFO - 2018-08-03 02:32:31 --> Language Class Initialized
INFO - 2018-08-03 02:32:31 --> Language Class Initialized
INFO - 2018-08-03 02:32:31 --> Config Class Initialized
INFO - 2018-08-03 02:32:31 --> Loader Class Initialized
DEBUG - 2018-08-03 02:32:31 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-03 02:32:31 --> Helper loaded: url_helper
INFO - 2018-08-03 02:32:31 --> Helper loaded: form_helper
INFO - 2018-08-03 02:32:31 --> Helper loaded: date_helper
INFO - 2018-08-03 02:32:31 --> Helper loaded: util_helper
INFO - 2018-08-03 02:32:31 --> Helper loaded: text_helper
INFO - 2018-08-03 02:32:31 --> Helper loaded: string_helper
INFO - 2018-08-03 02:32:31 --> Database Driver Class Initialized
DEBUG - 2018-08-03 02:32:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 02:32:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-03 02:32:31 --> Email Class Initialized
INFO - 2018-08-03 02:32:31 --> Controller Class Initialized
DEBUG - 2018-08-03 02:32:31 --> Home MX_Controller Initialized
DEBUG - 2018-08-03 02:32:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-03 02:32:32 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-03 02:32:32 --> Login MX_Controller Initialized
INFO - 2018-08-03 02:32:32 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-03 02:32:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-03 02:32:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-03 02:33:23 --> Config Class Initialized
INFO - 2018-08-03 02:33:23 --> Hooks Class Initialized
DEBUG - 2018-08-03 02:33:23 --> UTF-8 Support Enabled
INFO - 2018-08-03 02:33:23 --> Utf8 Class Initialized
INFO - 2018-08-03 02:33:23 --> URI Class Initialized
INFO - 2018-08-03 02:33:23 --> Router Class Initialized
INFO - 2018-08-03 02:33:23 --> Output Class Initialized
INFO - 2018-08-03 02:33:23 --> Security Class Initialized
DEBUG - 2018-08-03 02:33:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 02:33:23 --> Input Class Initialized
INFO - 2018-08-03 02:33:23 --> Language Class Initialized
INFO - 2018-08-03 02:33:23 --> Language Class Initialized
INFO - 2018-08-03 02:33:23 --> Config Class Initialized
INFO - 2018-08-03 02:33:23 --> Loader Class Initialized
DEBUG - 2018-08-03 02:33:23 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-03 02:33:23 --> Helper loaded: url_helper
INFO - 2018-08-03 02:33:23 --> Helper loaded: form_helper
INFO - 2018-08-03 02:33:23 --> Helper loaded: date_helper
INFO - 2018-08-03 02:33:23 --> Helper loaded: util_helper
INFO - 2018-08-03 02:33:23 --> Helper loaded: text_helper
INFO - 2018-08-03 02:33:23 --> Helper loaded: string_helper
INFO - 2018-08-03 02:33:23 --> Database Driver Class Initialized
DEBUG - 2018-08-03 02:33:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 02:33:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-03 02:33:23 --> Email Class Initialized
INFO - 2018-08-03 02:33:23 --> Controller Class Initialized
DEBUG - 2018-08-03 02:33:23 --> Admin MX_Controller Initialized
INFO - 2018-08-03 02:33:23 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-03 02:33:23 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-03 02:33:23 --> Login MX_Controller Initialized
DEBUG - 2018-08-03 02:33:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-03 02:33:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-03 02:33:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-08-03 02:33:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-08-03 02:33:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-08-03 02:33:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-08-03 02:33:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-08-03 02:33:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/dashboard.php
INFO - 2018-08-03 02:33:24 --> Final output sent to browser
DEBUG - 2018-08-03 02:33:24 --> Total execution time: 0.6493
INFO - 2018-08-03 02:33:24 --> Config Class Initialized
INFO - 2018-08-03 02:33:24 --> Hooks Class Initialized
DEBUG - 2018-08-03 02:33:25 --> UTF-8 Support Enabled
INFO - 2018-08-03 02:33:25 --> Utf8 Class Initialized
INFO - 2018-08-03 02:33:25 --> URI Class Initialized
INFO - 2018-08-03 02:33:25 --> Router Class Initialized
INFO - 2018-08-03 02:33:25 --> Config Class Initialized
INFO - 2018-08-03 02:33:25 --> Hooks Class Initialized
INFO - 2018-08-03 02:33:25 --> Output Class Initialized
DEBUG - 2018-08-03 02:33:25 --> UTF-8 Support Enabled
INFO - 2018-08-03 02:33:25 --> Utf8 Class Initialized
INFO - 2018-08-03 02:33:25 --> Security Class Initialized
INFO - 2018-08-03 02:33:25 --> URI Class Initialized
DEBUG - 2018-08-03 02:33:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 02:33:25 --> Input Class Initialized
INFO - 2018-08-03 02:33:25 --> Router Class Initialized
INFO - 2018-08-03 02:33:25 --> Output Class Initialized
INFO - 2018-08-03 02:33:25 --> Language Class Initialized
INFO - 2018-08-03 02:33:25 --> Security Class Initialized
ERROR - 2018-08-03 02:33:25 --> 404 Page Not Found: /index
DEBUG - 2018-08-03 02:33:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 02:33:25 --> Input Class Initialized
INFO - 2018-08-03 02:33:25 --> Language Class Initialized
INFO - 2018-08-03 02:33:25 --> Language Class Initialized
INFO - 2018-08-03 02:33:25 --> Config Class Initialized
INFO - 2018-08-03 02:33:25 --> Loader Class Initialized
DEBUG - 2018-08-03 02:33:25 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-03 02:33:25 --> Helper loaded: url_helper
INFO - 2018-08-03 02:33:25 --> Helper loaded: form_helper
INFO - 2018-08-03 02:33:25 --> Helper loaded: date_helper
INFO - 2018-08-03 02:33:25 --> Helper loaded: util_helper
INFO - 2018-08-03 02:33:25 --> Helper loaded: text_helper
INFO - 2018-08-03 02:33:25 --> Helper loaded: string_helper
INFO - 2018-08-03 02:33:25 --> Database Driver Class Initialized
DEBUG - 2018-08-03 02:33:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 02:33:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-03 02:33:25 --> Email Class Initialized
INFO - 2018-08-03 02:33:25 --> Controller Class Initialized
DEBUG - 2018-08-03 02:33:25 --> Home MX_Controller Initialized
DEBUG - 2018-08-03 02:33:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-03 02:33:26 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-03 02:33:26 --> Login MX_Controller Initialized
INFO - 2018-08-03 02:33:26 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-03 02:33:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-03 02:33:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-03 02:36:26 --> Config Class Initialized
INFO - 2018-08-03 02:36:26 --> Hooks Class Initialized
DEBUG - 2018-08-03 02:36:26 --> UTF-8 Support Enabled
INFO - 2018-08-03 02:36:26 --> Utf8 Class Initialized
INFO - 2018-08-03 02:36:26 --> URI Class Initialized
INFO - 2018-08-03 02:36:27 --> Router Class Initialized
INFO - 2018-08-03 02:36:27 --> Output Class Initialized
INFO - 2018-08-03 02:36:27 --> Security Class Initialized
DEBUG - 2018-08-03 02:36:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 02:36:27 --> Input Class Initialized
INFO - 2018-08-03 02:36:27 --> Language Class Initialized
INFO - 2018-08-03 02:36:27 --> Language Class Initialized
INFO - 2018-08-03 02:36:27 --> Config Class Initialized
INFO - 2018-08-03 02:36:27 --> Loader Class Initialized
DEBUG - 2018-08-03 02:36:27 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-03 02:36:27 --> Helper loaded: url_helper
INFO - 2018-08-03 02:36:27 --> Helper loaded: form_helper
INFO - 2018-08-03 02:36:27 --> Helper loaded: date_helper
INFO - 2018-08-03 02:36:27 --> Helper loaded: util_helper
INFO - 2018-08-03 02:36:27 --> Helper loaded: text_helper
INFO - 2018-08-03 02:36:27 --> Helper loaded: string_helper
INFO - 2018-08-03 02:36:27 --> Database Driver Class Initialized
DEBUG - 2018-08-03 02:36:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 02:36:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-03 02:36:27 --> Email Class Initialized
INFO - 2018-08-03 02:36:27 --> Controller Class Initialized
DEBUG - 2018-08-03 02:36:27 --> Admin MX_Controller Initialized
INFO - 2018-08-03 02:36:27 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-03 02:36:27 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-03 02:36:27 --> Login MX_Controller Initialized
DEBUG - 2018-08-03 02:36:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-03 02:36:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-03 02:36:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-08-03 02:36:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-08-03 02:36:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-08-03 02:36:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-08-03 02:36:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-08-03 02:36:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/dashboard.php
INFO - 2018-08-03 02:36:27 --> Final output sent to browser
DEBUG - 2018-08-03 02:36:27 --> Total execution time: 0.6764
INFO - 2018-08-03 02:36:27 --> Config Class Initialized
INFO - 2018-08-03 02:36:27 --> Hooks Class Initialized
DEBUG - 2018-08-03 02:36:27 --> UTF-8 Support Enabled
INFO - 2018-08-03 02:36:27 --> Utf8 Class Initialized
INFO - 2018-08-03 02:36:27 --> URI Class Initialized
INFO - 2018-08-03 02:36:27 --> Router Class Initialized
INFO - 2018-08-03 02:36:27 --> Output Class Initialized
INFO - 2018-08-03 02:36:27 --> Security Class Initialized
DEBUG - 2018-08-03 02:36:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 02:36:27 --> Input Class Initialized
INFO - 2018-08-03 02:36:28 --> Language Class Initialized
ERROR - 2018-08-03 02:36:28 --> 404 Page Not Found: /index
INFO - 2018-08-03 02:36:28 --> Config Class Initialized
INFO - 2018-08-03 02:36:28 --> Hooks Class Initialized
DEBUG - 2018-08-03 02:36:28 --> UTF-8 Support Enabled
INFO - 2018-08-03 02:36:28 --> Utf8 Class Initialized
INFO - 2018-08-03 02:36:28 --> URI Class Initialized
INFO - 2018-08-03 02:36:28 --> Router Class Initialized
INFO - 2018-08-03 02:36:28 --> Output Class Initialized
INFO - 2018-08-03 02:36:28 --> Security Class Initialized
DEBUG - 2018-08-03 02:36:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 02:36:28 --> Input Class Initialized
INFO - 2018-08-03 02:36:28 --> Language Class Initialized
INFO - 2018-08-03 02:36:28 --> Language Class Initialized
INFO - 2018-08-03 02:36:28 --> Config Class Initialized
INFO - 2018-08-03 02:36:28 --> Loader Class Initialized
DEBUG - 2018-08-03 02:36:28 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-03 02:36:28 --> Helper loaded: url_helper
INFO - 2018-08-03 02:36:28 --> Helper loaded: form_helper
INFO - 2018-08-03 02:36:28 --> Helper loaded: date_helper
INFO - 2018-08-03 02:36:28 --> Helper loaded: util_helper
INFO - 2018-08-03 02:36:28 --> Helper loaded: text_helper
INFO - 2018-08-03 02:36:28 --> Helper loaded: string_helper
INFO - 2018-08-03 02:36:28 --> Database Driver Class Initialized
DEBUG - 2018-08-03 02:36:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 02:36:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-03 02:36:28 --> Email Class Initialized
INFO - 2018-08-03 02:36:28 --> Controller Class Initialized
DEBUG - 2018-08-03 02:36:28 --> Home MX_Controller Initialized
DEBUG - 2018-08-03 02:36:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-03 02:36:28 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-03 02:36:28 --> Login MX_Controller Initialized
INFO - 2018-08-03 02:36:28 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-03 02:36:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-03 02:36:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-03 02:36:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-08-03 02:36:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-08-03 02:36:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-08-03 02:36:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-08-03 02:36:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-08-03 02:36:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-08-03 02:36:29 --> Final output sent to browser
DEBUG - 2018-08-03 02:36:29 --> Total execution time: 0.7836
INFO - 2018-08-03 02:36:29 --> Config Class Initialized
INFO - 2018-08-03 02:36:29 --> Hooks Class Initialized
DEBUG - 2018-08-03 02:36:29 --> UTF-8 Support Enabled
INFO - 2018-08-03 02:36:29 --> Utf8 Class Initialized
INFO - 2018-08-03 02:36:29 --> URI Class Initialized
INFO - 2018-08-03 02:36:29 --> Router Class Initialized
INFO - 2018-08-03 02:36:29 --> Output Class Initialized
INFO - 2018-08-03 02:36:29 --> Security Class Initialized
DEBUG - 2018-08-03 02:36:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 02:36:29 --> Input Class Initialized
INFO - 2018-08-03 02:36:29 --> Config Class Initialized
INFO - 2018-08-03 02:36:29 --> Language Class Initialized
INFO - 2018-08-03 02:36:29 --> Hooks Class Initialized
DEBUG - 2018-08-03 02:36:29 --> UTF-8 Support Enabled
INFO - 2018-08-03 02:36:29 --> Language Class Initialized
INFO - 2018-08-03 02:36:29 --> Utf8 Class Initialized
INFO - 2018-08-03 02:36:29 --> Config Class Initialized
INFO - 2018-08-03 02:36:29 --> URI Class Initialized
INFO - 2018-08-03 02:36:29 --> Router Class Initialized
INFO - 2018-08-03 02:36:29 --> Loader Class Initialized
INFO - 2018-08-03 02:36:29 --> Output Class Initialized
DEBUG - 2018-08-03 02:36:29 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-03 02:36:29 --> Helper loaded: url_helper
INFO - 2018-08-03 02:36:29 --> Security Class Initialized
DEBUG - 2018-08-03 02:36:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 02:36:29 --> Helper loaded: form_helper
INFO - 2018-08-03 02:36:29 --> Input Class Initialized
INFO - 2018-08-03 02:36:29 --> Helper loaded: date_helper
INFO - 2018-08-03 02:36:29 --> Language Class Initialized
INFO - 2018-08-03 02:36:29 --> Helper loaded: util_helper
ERROR - 2018-08-03 02:36:29 --> 404 Page Not Found: /index
INFO - 2018-08-03 02:36:29 --> Helper loaded: text_helper
INFO - 2018-08-03 02:36:29 --> Helper loaded: string_helper
INFO - 2018-08-03 02:36:29 --> Database Driver Class Initialized
DEBUG - 2018-08-03 02:36:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 02:36:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-03 02:36:29 --> Email Class Initialized
INFO - 2018-08-03 02:36:29 --> Controller Class Initialized
INFO - 2018-08-03 02:36:29 --> Config Class Initialized
INFO - 2018-08-03 02:36:30 --> Hooks Class Initialized
DEBUG - 2018-08-03 02:36:30 --> Home MX_Controller Initialized
DEBUG - 2018-08-03 02:36:30 --> UTF-8 Support Enabled
INFO - 2018-08-03 02:36:30 --> Config Class Initialized
INFO - 2018-08-03 02:36:30 --> Hooks Class Initialized
INFO - 2018-08-03 02:36:30 --> Utf8 Class Initialized
DEBUG - 2018-08-03 02:36:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-03 02:36:30 --> UTF-8 Support Enabled
INFO - 2018-08-03 02:36:30 --> Utf8 Class Initialized
INFO - 2018-08-03 02:36:30 --> URI Class Initialized
INFO - 2018-08-03 02:36:30 --> Router Class Initialized
INFO - 2018-08-03 02:36:30 --> URI Class Initialized
DEBUG - 2018-08-03 02:36:30 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
INFO - 2018-08-03 02:36:30 --> Output Class Initialized
INFO - 2018-08-03 02:36:30 --> Router Class Initialized
INFO - 2018-08-03 02:36:30 --> Security Class Initialized
INFO - 2018-08-03 02:36:30 --> Output Class Initialized
DEBUG - 2018-08-03 02:36:30 --> Login MX_Controller Initialized
INFO - 2018-08-03 02:36:30 --> Security Class Initialized
DEBUG - 2018-08-03 02:36:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-08-03 02:36:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 02:36:30 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-03 02:36:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-08-03 02:36:30 --> Input Class Initialized
INFO - 2018-08-03 02:36:30 --> Input Class Initialized
INFO - 2018-08-03 02:36:30 --> Language Class Initialized
DEBUG - 2018-08-03 02:36:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-03 02:36:30 --> Language Class Initialized
ERROR - 2018-08-03 02:36:30 --> 404 Page Not Found: /index
INFO - 2018-08-03 02:36:30 --> Language Class Initialized
INFO - 2018-08-03 02:36:30 --> Config Class Initialized
INFO - 2018-08-03 02:36:30 --> Config Class Initialized
INFO - 2018-08-03 02:36:30 --> Hooks Class Initialized
INFO - 2018-08-03 02:36:30 --> Loader Class Initialized
DEBUG - 2018-08-03 02:36:30 --> UTF-8 Support Enabled
INFO - 2018-08-03 02:36:30 --> Utf8 Class Initialized
DEBUG - 2018-08-03 02:36:30 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-03 02:36:30 --> URI Class Initialized
INFO - 2018-08-03 02:36:30 --> Helper loaded: url_helper
INFO - 2018-08-03 02:36:30 --> Helper loaded: form_helper
INFO - 2018-08-03 02:36:30 --> Router Class Initialized
INFO - 2018-08-03 02:36:30 --> Helper loaded: date_helper
INFO - 2018-08-03 02:36:30 --> Output Class Initialized
INFO - 2018-08-03 02:36:30 --> Helper loaded: util_helper
INFO - 2018-08-03 02:36:30 --> Security Class Initialized
INFO - 2018-08-03 02:36:30 --> Helper loaded: text_helper
DEBUG - 2018-08-03 02:36:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 02:36:30 --> Input Class Initialized
INFO - 2018-08-03 02:36:30 --> Language Class Initialized
ERROR - 2018-08-03 02:36:30 --> 404 Page Not Found: /index
INFO - 2018-08-03 02:36:30 --> Config Class Initialized
INFO - 2018-08-03 02:36:30 --> Helper loaded: string_helper
INFO - 2018-08-03 02:36:30 --> Hooks Class Initialized
DEBUG - 2018-08-03 02:36:30 --> UTF-8 Support Enabled
INFO - 2018-08-03 02:36:30 --> Database Driver Class Initialized
INFO - 2018-08-03 02:36:30 --> Utf8 Class Initialized
INFO - 2018-08-03 02:36:30 --> URI Class Initialized
INFO - 2018-08-03 02:36:30 --> Router Class Initialized
DEBUG - 2018-08-03 02:36:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 02:36:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-03 02:36:30 --> Output Class Initialized
INFO - 2018-08-03 02:36:30 --> Email Class Initialized
INFO - 2018-08-03 02:36:30 --> Security Class Initialized
INFO - 2018-08-03 02:36:30 --> Controller Class Initialized
DEBUG - 2018-08-03 02:36:30 --> Home MX_Controller Initialized
DEBUG - 2018-08-03 02:36:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-03 02:36:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-08-03 02:36:31 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-03 02:36:31 --> Login MX_Controller Initialized
INFO - 2018-08-03 02:36:31 --> Input Class Initialized
INFO - 2018-08-03 02:36:31 --> Language file loaded: language/english/data_lang.php
INFO - 2018-08-03 02:36:31 --> Language Class Initialized
ERROR - 2018-08-03 02:36:31 --> 404 Page Not Found: /index
DEBUG - 2018-08-03 02:36:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-03 02:36:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-03 02:36:38 --> Config Class Initialized
INFO - 2018-08-03 02:36:38 --> Hooks Class Initialized
DEBUG - 2018-08-03 02:36:38 --> UTF-8 Support Enabled
INFO - 2018-08-03 02:36:38 --> Utf8 Class Initialized
INFO - 2018-08-03 02:36:38 --> URI Class Initialized
INFO - 2018-08-03 02:36:38 --> Router Class Initialized
INFO - 2018-08-03 02:36:38 --> Output Class Initialized
INFO - 2018-08-03 02:36:38 --> Security Class Initialized
DEBUG - 2018-08-03 02:36:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 02:36:38 --> Input Class Initialized
INFO - 2018-08-03 02:36:38 --> Language Class Initialized
INFO - 2018-08-03 02:36:38 --> Language Class Initialized
INFO - 2018-08-03 02:36:38 --> Config Class Initialized
INFO - 2018-08-03 02:36:38 --> Loader Class Initialized
DEBUG - 2018-08-03 02:36:38 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-03 02:36:38 --> Helper loaded: url_helper
INFO - 2018-08-03 02:36:38 --> Helper loaded: form_helper
INFO - 2018-08-03 02:36:38 --> Helper loaded: date_helper
INFO - 2018-08-03 02:36:38 --> Helper loaded: util_helper
INFO - 2018-08-03 02:36:38 --> Helper loaded: text_helper
INFO - 2018-08-03 02:36:38 --> Helper loaded: string_helper
INFO - 2018-08-03 02:36:38 --> Database Driver Class Initialized
DEBUG - 2018-08-03 02:36:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 02:36:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-03 02:36:38 --> Email Class Initialized
INFO - 2018-08-03 02:36:38 --> Controller Class Initialized
DEBUG - 2018-08-03 02:36:38 --> Home MX_Controller Initialized
DEBUG - 2018-08-03 02:36:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-03 02:36:38 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-03 02:36:38 --> Login MX_Controller Initialized
INFO - 2018-08-03 02:36:38 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-03 02:36:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-03 02:36:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-03 02:37:06 --> Config Class Initialized
INFO - 2018-08-03 02:37:06 --> Hooks Class Initialized
DEBUG - 2018-08-03 02:37:06 --> UTF-8 Support Enabled
INFO - 2018-08-03 02:37:06 --> Utf8 Class Initialized
INFO - 2018-08-03 02:37:06 --> URI Class Initialized
INFO - 2018-08-03 02:37:06 --> Router Class Initialized
INFO - 2018-08-03 02:37:06 --> Output Class Initialized
INFO - 2018-08-03 02:37:06 --> Security Class Initialized
DEBUG - 2018-08-03 02:37:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 02:37:06 --> Input Class Initialized
INFO - 2018-08-03 02:37:06 --> Language Class Initialized
INFO - 2018-08-03 02:37:06 --> Language Class Initialized
INFO - 2018-08-03 02:37:06 --> Config Class Initialized
INFO - 2018-08-03 02:37:06 --> Loader Class Initialized
DEBUG - 2018-08-03 02:37:06 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-03 02:37:06 --> Helper loaded: url_helper
INFO - 2018-08-03 02:37:06 --> Helper loaded: form_helper
INFO - 2018-08-03 02:37:06 --> Helper loaded: date_helper
INFO - 2018-08-03 02:37:06 --> Helper loaded: util_helper
INFO - 2018-08-03 02:37:06 --> Helper loaded: text_helper
INFO - 2018-08-03 02:37:06 --> Helper loaded: string_helper
INFO - 2018-08-03 02:37:06 --> Database Driver Class Initialized
DEBUG - 2018-08-03 02:37:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 02:37:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-03 02:37:06 --> Email Class Initialized
INFO - 2018-08-03 02:37:06 --> Controller Class Initialized
DEBUG - 2018-08-03 02:37:06 --> Home MX_Controller Initialized
DEBUG - 2018-08-03 02:37:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-03 02:37:06 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-03 02:37:06 --> Login MX_Controller Initialized
INFO - 2018-08-03 02:37:06 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-03 02:37:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-03 02:37:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-03 02:37:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-08-03 02:37:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-08-03 02:37:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-08-03 02:37:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-08-03 02:37:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-08-03 02:37:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-08-03 02:37:06 --> Final output sent to browser
DEBUG - 2018-08-03 02:37:06 --> Total execution time: 0.7026
INFO - 2018-08-03 02:37:07 --> Config Class Initialized
INFO - 2018-08-03 02:37:07 --> Hooks Class Initialized
DEBUG - 2018-08-03 02:37:07 --> UTF-8 Support Enabled
INFO - 2018-08-03 02:37:07 --> Config Class Initialized
INFO - 2018-08-03 02:37:07 --> Hooks Class Initialized
INFO - 2018-08-03 02:37:07 --> Utf8 Class Initialized
DEBUG - 2018-08-03 02:37:07 --> UTF-8 Support Enabled
INFO - 2018-08-03 02:37:07 --> Utf8 Class Initialized
INFO - 2018-08-03 02:37:07 --> URI Class Initialized
INFO - 2018-08-03 02:37:07 --> URI Class Initialized
INFO - 2018-08-03 02:37:07 --> Router Class Initialized
INFO - 2018-08-03 02:37:07 --> Router Class Initialized
INFO - 2018-08-03 02:37:07 --> Output Class Initialized
INFO - 2018-08-03 02:37:07 --> Security Class Initialized
INFO - 2018-08-03 02:37:07 --> Output Class Initialized
DEBUG - 2018-08-03 02:37:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 02:37:07 --> Security Class Initialized
DEBUG - 2018-08-03 02:37:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 02:37:07 --> Input Class Initialized
INFO - 2018-08-03 02:37:07 --> Input Class Initialized
INFO - 2018-08-03 02:37:07 --> Language Class Initialized
INFO - 2018-08-03 02:37:07 --> Language Class Initialized
INFO - 2018-08-03 02:37:07 --> Language Class Initialized
ERROR - 2018-08-03 02:37:07 --> 404 Page Not Found: /index
INFO - 2018-08-03 02:37:07 --> Config Class Initialized
INFO - 2018-08-03 02:37:07 --> Config Class Initialized
INFO - 2018-08-03 02:37:07 --> Hooks Class Initialized
INFO - 2018-08-03 02:37:07 --> Loader Class Initialized
DEBUG - 2018-08-03 02:37:07 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
DEBUG - 2018-08-03 02:37:07 --> UTF-8 Support Enabled
INFO - 2018-08-03 02:37:07 --> Helper loaded: url_helper
INFO - 2018-08-03 02:37:07 --> Utf8 Class Initialized
INFO - 2018-08-03 02:37:07 --> URI Class Initialized
INFO - 2018-08-03 02:37:07 --> Helper loaded: form_helper
INFO - 2018-08-03 02:37:08 --> Router Class Initialized
INFO - 2018-08-03 02:37:08 --> Helper loaded: date_helper
INFO - 2018-08-03 02:37:08 --> Helper loaded: util_helper
INFO - 2018-08-03 02:37:08 --> Output Class Initialized
INFO - 2018-08-03 02:37:08 --> Helper loaded: text_helper
INFO - 2018-08-03 02:37:08 --> Security Class Initialized
INFO - 2018-08-03 02:37:08 --> Helper loaded: string_helper
DEBUG - 2018-08-03 02:37:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 02:37:08 --> Input Class Initialized
INFO - 2018-08-03 02:37:08 --> Database Driver Class Initialized
INFO - 2018-08-03 02:37:08 --> Language Class Initialized
DEBUG - 2018-08-03 02:37:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 02:37:08 --> Session: Class initialized using 'files' driver.
ERROR - 2018-08-03 02:37:08 --> 404 Page Not Found: /index
INFO - 2018-08-03 02:37:08 --> Email Class Initialized
INFO - 2018-08-03 02:37:08 --> Config Class Initialized
INFO - 2018-08-03 02:37:08 --> Hooks Class Initialized
INFO - 2018-08-03 02:37:08 --> Controller Class Initialized
DEBUG - 2018-08-03 02:37:08 --> Home MX_Controller Initialized
DEBUG - 2018-08-03 02:37:08 --> UTF-8 Support Enabled
INFO - 2018-08-03 02:37:08 --> Utf8 Class Initialized
DEBUG - 2018-08-03 02:37:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-08-03 02:37:08 --> URI Class Initialized
INFO - 2018-08-03 02:37:08 --> Router Class Initialized
INFO - 2018-08-03 02:37:08 --> Output Class Initialized
DEBUG - 2018-08-03 02:37:08 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-03 02:37:08 --> Login MX_Controller Initialized
INFO - 2018-08-03 02:37:08 --> Security Class Initialized
INFO - 2018-08-03 02:37:08 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-03 02:37:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 02:37:08 --> Input Class Initialized
DEBUG - 2018-08-03 02:37:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-08-03 02:37:08 --> Language Class Initialized
DEBUG - 2018-08-03 02:37:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
ERROR - 2018-08-03 02:37:08 --> 404 Page Not Found: /index
INFO - 2018-08-03 02:38:09 --> Config Class Initialized
INFO - 2018-08-03 02:38:09 --> Hooks Class Initialized
DEBUG - 2018-08-03 02:38:09 --> UTF-8 Support Enabled
INFO - 2018-08-03 02:38:09 --> Utf8 Class Initialized
INFO - 2018-08-03 02:38:09 --> URI Class Initialized
INFO - 2018-08-03 02:38:09 --> Router Class Initialized
INFO - 2018-08-03 02:38:09 --> Output Class Initialized
INFO - 2018-08-03 02:38:09 --> Security Class Initialized
DEBUG - 2018-08-03 02:38:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 02:38:09 --> Input Class Initialized
INFO - 2018-08-03 02:38:09 --> Language Class Initialized
INFO - 2018-08-03 02:38:09 --> Language Class Initialized
INFO - 2018-08-03 02:38:09 --> Config Class Initialized
INFO - 2018-08-03 02:38:09 --> Loader Class Initialized
DEBUG - 2018-08-03 02:38:09 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-03 02:38:09 --> Helper loaded: url_helper
INFO - 2018-08-03 02:38:09 --> Helper loaded: form_helper
INFO - 2018-08-03 02:38:09 --> Helper loaded: date_helper
INFO - 2018-08-03 02:38:09 --> Helper loaded: util_helper
INFO - 2018-08-03 02:38:09 --> Helper loaded: text_helper
INFO - 2018-08-03 02:38:09 --> Helper loaded: string_helper
INFO - 2018-08-03 02:38:09 --> Database Driver Class Initialized
DEBUG - 2018-08-03 02:38:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 02:38:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-03 02:38:10 --> Email Class Initialized
INFO - 2018-08-03 02:38:10 --> Controller Class Initialized
DEBUG - 2018-08-03 02:38:10 --> Home MX_Controller Initialized
DEBUG - 2018-08-03 02:38:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-03 02:38:10 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-03 02:38:10 --> Login MX_Controller Initialized
INFO - 2018-08-03 02:38:10 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-03 02:38:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-03 02:38:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-03 02:38:19 --> Config Class Initialized
INFO - 2018-08-03 02:38:19 --> Hooks Class Initialized
DEBUG - 2018-08-03 02:38:19 --> UTF-8 Support Enabled
INFO - 2018-08-03 02:38:19 --> Utf8 Class Initialized
INFO - 2018-08-03 02:38:19 --> URI Class Initialized
INFO - 2018-08-03 02:38:19 --> Router Class Initialized
INFO - 2018-08-03 02:38:19 --> Output Class Initialized
INFO - 2018-08-03 02:38:19 --> Security Class Initialized
DEBUG - 2018-08-03 02:38:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 02:38:19 --> Input Class Initialized
INFO - 2018-08-03 02:38:19 --> Language Class Initialized
INFO - 2018-08-03 02:38:19 --> Language Class Initialized
INFO - 2018-08-03 02:38:19 --> Config Class Initialized
INFO - 2018-08-03 02:38:19 --> Loader Class Initialized
DEBUG - 2018-08-03 02:38:19 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-03 02:38:19 --> Helper loaded: url_helper
INFO - 2018-08-03 02:38:19 --> Helper loaded: form_helper
INFO - 2018-08-03 02:38:19 --> Helper loaded: date_helper
INFO - 2018-08-03 02:38:19 --> Helper loaded: util_helper
INFO - 2018-08-03 02:38:19 --> Helper loaded: text_helper
INFO - 2018-08-03 02:38:19 --> Helper loaded: string_helper
INFO - 2018-08-03 02:38:19 --> Database Driver Class Initialized
DEBUG - 2018-08-03 02:38:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 02:38:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-03 02:38:19 --> Email Class Initialized
INFO - 2018-08-03 02:38:19 --> Controller Class Initialized
DEBUG - 2018-08-03 02:38:19 --> Admin MX_Controller Initialized
INFO - 2018-08-03 02:38:19 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-03 02:38:19 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-03 02:38:19 --> Login MX_Controller Initialized
DEBUG - 2018-08-03 02:38:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-03 02:38:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-03 02:38:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-08-03 02:38:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-08-03 02:38:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-08-03 02:38:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-08-03 02:38:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-08-03 02:38:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/dashboard.php
INFO - 2018-08-03 02:38:19 --> Final output sent to browser
DEBUG - 2018-08-03 02:38:20 --> Total execution time: 0.7241
INFO - 2018-08-03 02:38:20 --> Config Class Initialized
INFO - 2018-08-03 02:38:20 --> Hooks Class Initialized
DEBUG - 2018-08-03 02:38:20 --> UTF-8 Support Enabled
INFO - 2018-08-03 02:38:20 --> Utf8 Class Initialized
INFO - 2018-08-03 02:38:20 --> URI Class Initialized
INFO - 2018-08-03 02:38:20 --> Router Class Initialized
INFO - 2018-08-03 02:38:20 --> Output Class Initialized
INFO - 2018-08-03 02:38:20 --> Security Class Initialized
DEBUG - 2018-08-03 02:38:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 02:38:20 --> Input Class Initialized
INFO - 2018-08-03 02:38:20 --> Language Class Initialized
ERROR - 2018-08-03 02:38:20 --> 404 Page Not Found: /index
INFO - 2018-08-03 02:38:20 --> Config Class Initialized
INFO - 2018-08-03 02:38:20 --> Hooks Class Initialized
DEBUG - 2018-08-03 02:38:21 --> UTF-8 Support Enabled
INFO - 2018-08-03 02:38:21 --> Utf8 Class Initialized
INFO - 2018-08-03 02:38:21 --> URI Class Initialized
INFO - 2018-08-03 02:38:21 --> Router Class Initialized
INFO - 2018-08-03 02:38:21 --> Output Class Initialized
INFO - 2018-08-03 02:38:21 --> Security Class Initialized
DEBUG - 2018-08-03 02:38:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 02:38:21 --> Input Class Initialized
INFO - 2018-08-03 02:38:21 --> Language Class Initialized
INFO - 2018-08-03 02:38:21 --> Language Class Initialized
INFO - 2018-08-03 02:38:21 --> Config Class Initialized
INFO - 2018-08-03 02:38:21 --> Loader Class Initialized
DEBUG - 2018-08-03 02:38:21 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-03 02:38:21 --> Helper loaded: url_helper
INFO - 2018-08-03 02:38:21 --> Helper loaded: form_helper
INFO - 2018-08-03 02:38:21 --> Helper loaded: date_helper
INFO - 2018-08-03 02:38:21 --> Helper loaded: util_helper
INFO - 2018-08-03 02:38:21 --> Helper loaded: text_helper
INFO - 2018-08-03 02:38:21 --> Helper loaded: string_helper
INFO - 2018-08-03 02:38:21 --> Database Driver Class Initialized
DEBUG - 2018-08-03 02:38:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 02:38:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-03 02:38:21 --> Email Class Initialized
INFO - 2018-08-03 02:38:21 --> Controller Class Initialized
DEBUG - 2018-08-03 02:38:21 --> Home MX_Controller Initialized
DEBUG - 2018-08-03 02:38:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-03 02:38:21 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-03 02:38:21 --> Login MX_Controller Initialized
INFO - 2018-08-03 02:38:21 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-03 02:38:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-03 02:38:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-03 02:38:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
INFO - 2018-08-03 02:38:21 --> Config Class Initialized
INFO - 2018-08-03 02:38:21 --> Config Class Initialized
INFO - 2018-08-03 02:38:21 --> Hooks Class Initialized
DEBUG - 2018-08-03 02:38:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
INFO - 2018-08-03 02:38:21 --> Hooks Class Initialized
DEBUG - 2018-08-03 02:38:22 --> UTF-8 Support Enabled
INFO - 2018-08-03 02:38:22 --> Utf8 Class Initialized
INFO - 2018-08-03 02:38:22 --> URI Class Initialized
INFO - 2018-08-03 02:38:22 --> Router Class Initialized
DEBUG - 2018-08-03 02:38:22 --> UTF-8 Support Enabled
DEBUG - 2018-08-03 02:38:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
INFO - 2018-08-03 02:38:22 --> Output Class Initialized
INFO - 2018-08-03 02:38:22 --> Utf8 Class Initialized
INFO - 2018-08-03 02:38:22 --> Security Class Initialized
DEBUG - 2018-08-03 02:38:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
INFO - 2018-08-03 02:38:22 --> URI Class Initialized
DEBUG - 2018-08-03 02:38:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
INFO - 2018-08-03 02:38:22 --> Router Class Initialized
DEBUG - 2018-08-03 02:38:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 02:38:22 --> Input Class Initialized
DEBUG - 2018-08-03 02:38:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-08-03 02:38:22 --> Output Class Initialized
INFO - 2018-08-03 02:38:22 --> Final output sent to browser
INFO - 2018-08-03 02:38:22 --> Language Class Initialized
INFO - 2018-08-03 02:38:22 --> Security Class Initialized
DEBUG - 2018-08-03 02:38:22 --> Total execution time: 1.3879
DEBUG - 2018-08-03 02:38:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-08-03 02:38:22 --> 404 Page Not Found: /index
INFO - 2018-08-03 02:38:22 --> Input Class Initialized
INFO - 2018-08-03 02:38:22 --> Language Class Initialized
INFO - 2018-08-03 02:38:22 --> Language Class Initialized
INFO - 2018-08-03 02:38:22 --> Config Class Initialized
INFO - 2018-08-03 02:38:22 --> Loader Class Initialized
DEBUG - 2018-08-03 02:38:22 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-03 02:38:22 --> Helper loaded: url_helper
INFO - 2018-08-03 02:38:22 --> Helper loaded: form_helper
INFO - 2018-08-03 02:38:22 --> Helper loaded: date_helper
INFO - 2018-08-03 02:38:22 --> Helper loaded: util_helper
INFO - 2018-08-03 02:38:22 --> Helper loaded: text_helper
INFO - 2018-08-03 02:38:22 --> Helper loaded: string_helper
INFO - 2018-08-03 02:38:22 --> Database Driver Class Initialized
DEBUG - 2018-08-03 02:38:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 02:38:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-03 02:38:23 --> Email Class Initialized
INFO - 2018-08-03 02:38:23 --> Controller Class Initialized
DEBUG - 2018-08-03 02:38:23 --> Home MX_Controller Initialized
DEBUG - 2018-08-03 02:38:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-03 02:38:23 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-03 02:38:23 --> Login MX_Controller Initialized
INFO - 2018-08-03 02:38:23 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-03 02:38:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-03 02:38:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-03 02:38:23 --> Config Class Initialized
INFO - 2018-08-03 02:38:23 --> Hooks Class Initialized
DEBUG - 2018-08-03 02:38:23 --> UTF-8 Support Enabled
INFO - 2018-08-03 02:38:23 --> Utf8 Class Initialized
INFO - 2018-08-03 02:38:23 --> Config Class Initialized
INFO - 2018-08-03 02:38:23 --> Hooks Class Initialized
INFO - 2018-08-03 02:38:23 --> URI Class Initialized
DEBUG - 2018-08-03 02:38:24 --> UTF-8 Support Enabled
INFO - 2018-08-03 02:38:24 --> Router Class Initialized
INFO - 2018-08-03 02:38:24 --> Utf8 Class Initialized
INFO - 2018-08-03 02:38:24 --> URI Class Initialized
INFO - 2018-08-03 02:38:24 --> Output Class Initialized
INFO - 2018-08-03 02:38:24 --> Security Class Initialized
INFO - 2018-08-03 02:38:24 --> Router Class Initialized
DEBUG - 2018-08-03 02:38:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 02:38:24 --> Input Class Initialized
INFO - 2018-08-03 02:38:24 --> Output Class Initialized
INFO - 2018-08-03 02:38:24 --> Security Class Initialized
INFO - 2018-08-03 02:38:24 --> Language Class Initialized
ERROR - 2018-08-03 02:38:24 --> 404 Page Not Found: /index
DEBUG - 2018-08-03 02:38:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 02:38:24 --> Input Class Initialized
INFO - 2018-08-03 02:38:24 --> Config Class Initialized
INFO - 2018-08-03 02:38:24 --> Hooks Class Initialized
INFO - 2018-08-03 02:38:24 --> Language Class Initialized
DEBUG - 2018-08-03 02:38:24 --> UTF-8 Support Enabled
INFO - 2018-08-03 02:38:24 --> Language Class Initialized
INFO - 2018-08-03 02:38:24 --> Utf8 Class Initialized
INFO - 2018-08-03 02:38:24 --> Config Class Initialized
INFO - 2018-08-03 02:38:24 --> URI Class Initialized
INFO - 2018-08-03 02:38:24 --> Loader Class Initialized
DEBUG - 2018-08-03 02:38:24 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-03 02:38:24 --> Router Class Initialized
INFO - 2018-08-03 02:38:24 --> Output Class Initialized
INFO - 2018-08-03 02:38:24 --> Helper loaded: url_helper
INFO - 2018-08-03 02:38:24 --> Security Class Initialized
INFO - 2018-08-03 02:38:24 --> Helper loaded: form_helper
DEBUG - 2018-08-03 02:38:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 02:38:24 --> Helper loaded: date_helper
INFO - 2018-08-03 02:38:24 --> Input Class Initialized
INFO - 2018-08-03 02:38:24 --> Helper loaded: util_helper
INFO - 2018-08-03 02:38:24 --> Language Class Initialized
INFO - 2018-08-03 02:38:24 --> Helper loaded: text_helper
INFO - 2018-08-03 02:38:24 --> Helper loaded: string_helper
ERROR - 2018-08-03 02:38:24 --> 404 Page Not Found: /index
INFO - 2018-08-03 02:38:24 --> Database Driver Class Initialized
INFO - 2018-08-03 02:38:24 --> Config Class Initialized
INFO - 2018-08-03 02:38:24 --> Hooks Class Initialized
DEBUG - 2018-08-03 02:38:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 02:38:24 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-08-03 02:38:24 --> UTF-8 Support Enabled
INFO - 2018-08-03 02:38:24 --> Utf8 Class Initialized
INFO - 2018-08-03 02:38:24 --> Email Class Initialized
INFO - 2018-08-03 02:38:24 --> Controller Class Initialized
INFO - 2018-08-03 02:38:24 --> URI Class Initialized
DEBUG - 2018-08-03 02:38:24 --> Home MX_Controller Initialized
INFO - 2018-08-03 02:38:24 --> Router Class Initialized
DEBUG - 2018-08-03 02:38:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-08-03 02:38:24 --> Output Class Initialized
INFO - 2018-08-03 02:38:24 --> Security Class Initialized
DEBUG - 2018-08-03 02:38:24 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-03 02:38:24 --> Login MX_Controller Initialized
DEBUG - 2018-08-03 02:38:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 02:38:24 --> Language file loaded: language/english/data_lang.php
INFO - 2018-08-03 02:38:24 --> Input Class Initialized
DEBUG - 2018-08-03 02:38:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-08-03 02:38:24 --> Language Class Initialized
DEBUG - 2018-08-03 02:38:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
ERROR - 2018-08-03 02:38:24 --> 404 Page Not Found: /index
INFO - 2018-08-03 02:38:24 --> Config Class Initialized
INFO - 2018-08-03 02:38:24 --> Hooks Class Initialized
DEBUG - 2018-08-03 02:38:24 --> UTF-8 Support Enabled
INFO - 2018-08-03 02:38:24 --> Utf8 Class Initialized
INFO - 2018-08-03 02:38:24 --> URI Class Initialized
INFO - 2018-08-03 02:38:24 --> Router Class Initialized
INFO - 2018-08-03 02:38:24 --> Output Class Initialized
INFO - 2018-08-03 02:38:24 --> Security Class Initialized
DEBUG - 2018-08-03 02:38:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 02:38:25 --> Input Class Initialized
INFO - 2018-08-03 02:38:25 --> Language Class Initialized
ERROR - 2018-08-03 02:38:25 --> 404 Page Not Found: /index
INFO - 2018-08-03 02:38:25 --> Config Class Initialized
INFO - 2018-08-03 02:38:25 --> Hooks Class Initialized
DEBUG - 2018-08-03 02:38:25 --> UTF-8 Support Enabled
INFO - 2018-08-03 02:38:25 --> Utf8 Class Initialized
INFO - 2018-08-03 02:38:25 --> URI Class Initialized
INFO - 2018-08-03 02:38:25 --> Router Class Initialized
INFO - 2018-08-03 02:38:25 --> Output Class Initialized
INFO - 2018-08-03 02:38:25 --> Security Class Initialized
DEBUG - 2018-08-03 02:38:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 02:38:25 --> Input Class Initialized
INFO - 2018-08-03 02:38:25 --> Language Class Initialized
ERROR - 2018-08-03 02:38:25 --> 404 Page Not Found: /index
INFO - 2018-08-03 02:38:25 --> Config Class Initialized
INFO - 2018-08-03 02:38:25 --> Hooks Class Initialized
DEBUG - 2018-08-03 02:38:25 --> UTF-8 Support Enabled
INFO - 2018-08-03 02:38:25 --> Utf8 Class Initialized
INFO - 2018-08-03 02:38:25 --> URI Class Initialized
INFO - 2018-08-03 02:38:25 --> Router Class Initialized
INFO - 2018-08-03 02:38:25 --> Output Class Initialized
INFO - 2018-08-03 02:38:25 --> Security Class Initialized
DEBUG - 2018-08-03 02:38:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 02:38:25 --> Input Class Initialized
INFO - 2018-08-03 02:38:25 --> Language Class Initialized
ERROR - 2018-08-03 02:38:25 --> 404 Page Not Found: /index
INFO - 2018-08-03 02:38:26 --> Config Class Initialized
INFO - 2018-08-03 02:38:26 --> Hooks Class Initialized
DEBUG - 2018-08-03 02:38:26 --> UTF-8 Support Enabled
INFO - 2018-08-03 02:38:26 --> Utf8 Class Initialized
INFO - 2018-08-03 02:38:26 --> URI Class Initialized
INFO - 2018-08-03 02:38:26 --> Router Class Initialized
INFO - 2018-08-03 02:38:26 --> Output Class Initialized
INFO - 2018-08-03 02:38:26 --> Security Class Initialized
DEBUG - 2018-08-03 02:38:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 02:38:26 --> Input Class Initialized
INFO - 2018-08-03 02:38:26 --> Language Class Initialized
INFO - 2018-08-03 02:38:26 --> Language Class Initialized
INFO - 2018-08-03 02:38:26 --> Config Class Initialized
INFO - 2018-08-03 02:38:26 --> Loader Class Initialized
DEBUG - 2018-08-03 02:38:26 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-03 02:38:26 --> Helper loaded: url_helper
INFO - 2018-08-03 02:38:26 --> Helper loaded: form_helper
INFO - 2018-08-03 02:38:26 --> Helper loaded: date_helper
INFO - 2018-08-03 02:38:26 --> Helper loaded: util_helper
INFO - 2018-08-03 02:38:26 --> Helper loaded: text_helper
INFO - 2018-08-03 02:38:26 --> Helper loaded: string_helper
INFO - 2018-08-03 02:38:26 --> Database Driver Class Initialized
DEBUG - 2018-08-03 02:38:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 02:38:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-03 02:38:26 --> Email Class Initialized
INFO - 2018-08-03 02:38:26 --> Controller Class Initialized
DEBUG - 2018-08-03 02:38:26 --> Home MX_Controller Initialized
DEBUG - 2018-08-03 02:38:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-03 02:38:26 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-03 02:38:26 --> Login MX_Controller Initialized
INFO - 2018-08-03 02:38:26 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-03 02:38:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-03 02:38:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-03 02:38:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-08-03 02:38:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-08-03 02:38:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-08-03 02:38:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-08-03 02:38:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-08-03 02:38:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-08-03 02:38:27 --> Final output sent to browser
DEBUG - 2018-08-03 02:38:27 --> Total execution time: 0.7878
INFO - 2018-08-03 02:38:27 --> Config Class Initialized
INFO - 2018-08-03 02:38:27 --> Hooks Class Initialized
INFO - 2018-08-03 02:38:27 --> Config Class Initialized
INFO - 2018-08-03 02:38:27 --> Hooks Class Initialized
DEBUG - 2018-08-03 02:38:27 --> UTF-8 Support Enabled
DEBUG - 2018-08-03 02:38:27 --> UTF-8 Support Enabled
INFO - 2018-08-03 02:38:27 --> Utf8 Class Initialized
INFO - 2018-08-03 02:38:27 --> URI Class Initialized
INFO - 2018-08-03 02:38:27 --> Utf8 Class Initialized
INFO - 2018-08-03 02:38:27 --> Router Class Initialized
INFO - 2018-08-03 02:38:27 --> URI Class Initialized
INFO - 2018-08-03 02:38:27 --> Output Class Initialized
INFO - 2018-08-03 02:38:27 --> Router Class Initialized
INFO - 2018-08-03 02:38:27 --> Output Class Initialized
INFO - 2018-08-03 02:38:27 --> Security Class Initialized
INFO - 2018-08-03 02:38:27 --> Security Class Initialized
DEBUG - 2018-08-03 02:38:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-08-03 02:38:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 02:38:27 --> Input Class Initialized
INFO - 2018-08-03 02:38:27 --> Input Class Initialized
INFO - 2018-08-03 02:38:28 --> Language Class Initialized
INFO - 2018-08-03 02:38:28 --> Language Class Initialized
ERROR - 2018-08-03 02:38:28 --> 404 Page Not Found: /index
INFO - 2018-08-03 02:38:28 --> Language Class Initialized
INFO - 2018-08-03 02:38:28 --> Config Class Initialized
INFO - 2018-08-03 02:38:28 --> Config Class Initialized
INFO - 2018-08-03 02:38:28 --> Hooks Class Initialized
INFO - 2018-08-03 02:38:28 --> Loader Class Initialized
DEBUG - 2018-08-03 02:38:28 --> UTF-8 Support Enabled
INFO - 2018-08-03 02:38:28 --> Utf8 Class Initialized
DEBUG - 2018-08-03 02:38:28 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-03 02:38:28 --> Helper loaded: url_helper
INFO - 2018-08-03 02:38:28 --> URI Class Initialized
INFO - 2018-08-03 02:38:28 --> Router Class Initialized
INFO - 2018-08-03 02:38:28 --> Helper loaded: form_helper
INFO - 2018-08-03 02:38:28 --> Output Class Initialized
INFO - 2018-08-03 02:38:28 --> Helper loaded: date_helper
INFO - 2018-08-03 02:38:28 --> Security Class Initialized
INFO - 2018-08-03 02:38:28 --> Helper loaded: util_helper
DEBUG - 2018-08-03 02:38:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 02:38:28 --> Input Class Initialized
INFO - 2018-08-03 02:38:28 --> Helper loaded: text_helper
INFO - 2018-08-03 02:38:28 --> Language Class Initialized
INFO - 2018-08-03 02:38:28 --> Helper loaded: string_helper
ERROR - 2018-08-03 02:38:28 --> 404 Page Not Found: /index
INFO - 2018-08-03 02:38:28 --> Database Driver Class Initialized
INFO - 2018-08-03 02:38:28 --> Config Class Initialized
DEBUG - 2018-08-03 02:38:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 02:38:28 --> Hooks Class Initialized
INFO - 2018-08-03 02:38:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-03 02:38:28 --> Email Class Initialized
DEBUG - 2018-08-03 02:38:28 --> UTF-8 Support Enabled
INFO - 2018-08-03 02:38:28 --> Controller Class Initialized
INFO - 2018-08-03 02:38:28 --> Utf8 Class Initialized
DEBUG - 2018-08-03 02:38:28 --> Home MX_Controller Initialized
INFO - 2018-08-03 02:38:28 --> URI Class Initialized
INFO - 2018-08-03 02:38:28 --> Router Class Initialized
DEBUG - 2018-08-03 02:38:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-08-03 02:38:28 --> Output Class Initialized
DEBUG - 2018-08-03 02:38:28 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-03 02:38:28 --> Login MX_Controller Initialized
INFO - 2018-08-03 02:38:28 --> Security Class Initialized
INFO - 2018-08-03 02:38:28 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-03 02:38:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-08-03 02:38:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-03 02:38:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-03 02:38:28 --> Input Class Initialized
INFO - 2018-08-03 02:38:28 --> Language Class Initialized
ERROR - 2018-08-03 02:38:28 --> 404 Page Not Found: /index
INFO - 2018-08-03 02:38:47 --> Config Class Initialized
INFO - 2018-08-03 02:38:47 --> Hooks Class Initialized
DEBUG - 2018-08-03 02:38:47 --> UTF-8 Support Enabled
INFO - 2018-08-03 02:38:47 --> Utf8 Class Initialized
INFO - 2018-08-03 02:38:47 --> URI Class Initialized
INFO - 2018-08-03 02:38:47 --> Router Class Initialized
INFO - 2018-08-03 02:38:47 --> Output Class Initialized
INFO - 2018-08-03 02:38:47 --> Security Class Initialized
DEBUG - 2018-08-03 02:38:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 02:38:48 --> Input Class Initialized
INFO - 2018-08-03 02:38:48 --> Language Class Initialized
INFO - 2018-08-03 02:38:48 --> Language Class Initialized
INFO - 2018-08-03 02:38:48 --> Config Class Initialized
INFO - 2018-08-03 02:38:48 --> Loader Class Initialized
DEBUG - 2018-08-03 02:38:48 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-03 02:38:48 --> Helper loaded: url_helper
INFO - 2018-08-03 02:38:48 --> Helper loaded: form_helper
INFO - 2018-08-03 02:38:48 --> Helper loaded: date_helper
INFO - 2018-08-03 02:38:48 --> Helper loaded: util_helper
INFO - 2018-08-03 02:38:48 --> Helper loaded: text_helper
INFO - 2018-08-03 02:38:48 --> Helper loaded: string_helper
INFO - 2018-08-03 02:38:48 --> Database Driver Class Initialized
DEBUG - 2018-08-03 02:38:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 02:38:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-03 02:38:48 --> Email Class Initialized
INFO - 2018-08-03 02:38:48 --> Controller Class Initialized
DEBUG - 2018-08-03 02:38:48 --> Home MX_Controller Initialized
DEBUG - 2018-08-03 02:38:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-03 02:38:48 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-03 02:38:48 --> Login MX_Controller Initialized
INFO - 2018-08-03 02:38:48 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-03 02:38:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-03 02:38:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-03 02:38:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-08-03 02:38:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-08-03 02:38:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-08-03 02:38:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-08-03 02:38:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-08-03 02:38:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-08-03 02:38:48 --> Final output sent to browser
DEBUG - 2018-08-03 02:38:48 --> Total execution time: 0.7190
INFO - 2018-08-03 02:38:49 --> Config Class Initialized
INFO - 2018-08-03 02:38:49 --> Hooks Class Initialized
INFO - 2018-08-03 02:38:49 --> Config Class Initialized
INFO - 2018-08-03 02:38:49 --> Hooks Class Initialized
DEBUG - 2018-08-03 02:38:49 --> UTF-8 Support Enabled
DEBUG - 2018-08-03 02:38:49 --> UTF-8 Support Enabled
INFO - 2018-08-03 02:38:49 --> Utf8 Class Initialized
INFO - 2018-08-03 02:38:49 --> URI Class Initialized
INFO - 2018-08-03 02:38:49 --> Router Class Initialized
INFO - 2018-08-03 02:38:49 --> Output Class Initialized
INFO - 2018-08-03 02:38:49 --> Security Class Initialized
DEBUG - 2018-08-03 02:38:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 02:38:49 --> Input Class Initialized
INFO - 2018-08-03 02:38:49 --> Utf8 Class Initialized
INFO - 2018-08-03 02:38:49 --> Language Class Initialized
INFO - 2018-08-03 02:38:49 --> URI Class Initialized
INFO - 2018-08-03 02:38:49 --> Router Class Initialized
INFO - 2018-08-03 02:38:49 --> Language Class Initialized
INFO - 2018-08-03 02:38:49 --> Output Class Initialized
INFO - 2018-08-03 02:38:49 --> Config Class Initialized
INFO - 2018-08-03 02:38:49 --> Security Class Initialized
INFO - 2018-08-03 02:38:49 --> Loader Class Initialized
DEBUG - 2018-08-03 02:38:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 02:38:49 --> Input Class Initialized
DEBUG - 2018-08-03 02:38:49 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-03 02:38:49 --> Language Class Initialized
INFO - 2018-08-03 02:38:49 --> Helper loaded: url_helper
ERROR - 2018-08-03 02:38:49 --> 404 Page Not Found: /index
INFO - 2018-08-03 02:38:49 --> Helper loaded: form_helper
INFO - 2018-08-03 02:38:49 --> Helper loaded: date_helper
INFO - 2018-08-03 02:38:49 --> Config Class Initialized
INFO - 2018-08-03 02:38:49 --> Hooks Class Initialized
INFO - 2018-08-03 02:38:49 --> Helper loaded: util_helper
DEBUG - 2018-08-03 02:38:49 --> UTF-8 Support Enabled
INFO - 2018-08-03 02:38:49 --> Helper loaded: text_helper
INFO - 2018-08-03 02:38:49 --> Utf8 Class Initialized
INFO - 2018-08-03 02:38:49 --> Helper loaded: string_helper
INFO - 2018-08-03 02:38:49 --> URI Class Initialized
INFO - 2018-08-03 02:38:49 --> Database Driver Class Initialized
INFO - 2018-08-03 02:38:49 --> Router Class Initialized
DEBUG - 2018-08-03 02:38:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 02:38:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-03 02:38:49 --> Output Class Initialized
INFO - 2018-08-03 02:38:49 --> Security Class Initialized
INFO - 2018-08-03 02:38:49 --> Email Class Initialized
DEBUG - 2018-08-03 02:38:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 02:38:49 --> Controller Class Initialized
INFO - 2018-08-03 02:38:49 --> Input Class Initialized
DEBUG - 2018-08-03 02:38:49 --> Home MX_Controller Initialized
INFO - 2018-08-03 02:38:50 --> Language Class Initialized
DEBUG - 2018-08-03 02:38:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
ERROR - 2018-08-03 02:38:50 --> 404 Page Not Found: /index
DEBUG - 2018-08-03 02:38:50 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-03 02:38:50 --> Login MX_Controller Initialized
INFO - 2018-08-03 02:38:50 --> Config Class Initialized
INFO - 2018-08-03 02:38:50 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-03 02:38:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-08-03 02:38:50 --> Hooks Class Initialized
DEBUG - 2018-08-03 02:38:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-03 02:38:50 --> UTF-8 Support Enabled
INFO - 2018-08-03 02:38:50 --> Utf8 Class Initialized
INFO - 2018-08-03 02:38:50 --> URI Class Initialized
INFO - 2018-08-03 02:38:50 --> Router Class Initialized
INFO - 2018-08-03 02:38:50 --> Output Class Initialized
INFO - 2018-08-03 02:38:50 --> Security Class Initialized
DEBUG - 2018-08-03 02:38:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 02:38:50 --> Input Class Initialized
INFO - 2018-08-03 02:38:50 --> Language Class Initialized
ERROR - 2018-08-03 02:38:50 --> 404 Page Not Found: /index
INFO - 2018-08-03 02:38:50 --> Config Class Initialized
INFO - 2018-08-03 02:38:50 --> Hooks Class Initialized
DEBUG - 2018-08-03 02:38:50 --> UTF-8 Support Enabled
INFO - 2018-08-03 02:38:50 --> Utf8 Class Initialized
INFO - 2018-08-03 02:38:50 --> URI Class Initialized
INFO - 2018-08-03 02:38:50 --> Router Class Initialized
INFO - 2018-08-03 02:38:50 --> Output Class Initialized
INFO - 2018-08-03 02:38:50 --> Security Class Initialized
DEBUG - 2018-08-03 02:38:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 02:38:50 --> Input Class Initialized
INFO - 2018-08-03 02:38:50 --> Language Class Initialized
ERROR - 2018-08-03 02:38:50 --> 404 Page Not Found: /index
INFO - 2018-08-03 02:38:50 --> Config Class Initialized
INFO - 2018-08-03 02:38:50 --> Hooks Class Initialized
DEBUG - 2018-08-03 02:38:50 --> UTF-8 Support Enabled
INFO - 2018-08-03 02:38:50 --> Utf8 Class Initialized
INFO - 2018-08-03 02:38:50 --> URI Class Initialized
INFO - 2018-08-03 02:38:50 --> Router Class Initialized
INFO - 2018-08-03 02:38:50 --> Output Class Initialized
INFO - 2018-08-03 02:38:50 --> Security Class Initialized
DEBUG - 2018-08-03 02:38:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 02:38:50 --> Input Class Initialized
INFO - 2018-08-03 02:38:50 --> Language Class Initialized
ERROR - 2018-08-03 02:38:50 --> 404 Page Not Found: /index
INFO - 2018-08-03 02:38:50 --> Config Class Initialized
INFO - 2018-08-03 02:38:50 --> Hooks Class Initialized
DEBUG - 2018-08-03 02:38:50 --> UTF-8 Support Enabled
INFO - 2018-08-03 02:38:50 --> Utf8 Class Initialized
INFO - 2018-08-03 02:38:50 --> URI Class Initialized
INFO - 2018-08-03 02:38:51 --> Router Class Initialized
INFO - 2018-08-03 02:38:51 --> Output Class Initialized
INFO - 2018-08-03 02:38:51 --> Security Class Initialized
DEBUG - 2018-08-03 02:38:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 02:38:51 --> Input Class Initialized
INFO - 2018-08-03 02:38:51 --> Language Class Initialized
ERROR - 2018-08-03 02:38:51 --> 404 Page Not Found: /index
INFO - 2018-08-03 02:38:59 --> Config Class Initialized
INFO - 2018-08-03 02:38:59 --> Hooks Class Initialized
DEBUG - 2018-08-03 02:38:59 --> UTF-8 Support Enabled
INFO - 2018-08-03 02:38:59 --> Utf8 Class Initialized
INFO - 2018-08-03 02:38:59 --> URI Class Initialized
INFO - 2018-08-03 02:38:59 --> Router Class Initialized
INFO - 2018-08-03 02:38:59 --> Output Class Initialized
INFO - 2018-08-03 02:38:59 --> Security Class Initialized
DEBUG - 2018-08-03 02:38:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 02:38:59 --> Input Class Initialized
INFO - 2018-08-03 02:38:59 --> Language Class Initialized
ERROR - 2018-08-03 02:38:59 --> 404 Page Not Found: /index
INFO - 2018-08-03 02:39:39 --> Config Class Initialized
INFO - 2018-08-03 02:39:39 --> Hooks Class Initialized
DEBUG - 2018-08-03 02:39:39 --> UTF-8 Support Enabled
INFO - 2018-08-03 02:39:39 --> Utf8 Class Initialized
INFO - 2018-08-03 02:39:39 --> URI Class Initialized
INFO - 2018-08-03 02:39:39 --> Router Class Initialized
INFO - 2018-08-03 02:39:39 --> Output Class Initialized
INFO - 2018-08-03 02:39:39 --> Security Class Initialized
DEBUG - 2018-08-03 02:39:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 02:39:39 --> Input Class Initialized
INFO - 2018-08-03 02:39:39 --> Language Class Initialized
INFO - 2018-08-03 02:39:39 --> Language Class Initialized
INFO - 2018-08-03 02:39:39 --> Config Class Initialized
INFO - 2018-08-03 02:39:39 --> Loader Class Initialized
DEBUG - 2018-08-03 02:39:39 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-03 02:39:39 --> Helper loaded: url_helper
INFO - 2018-08-03 02:39:39 --> Helper loaded: form_helper
INFO - 2018-08-03 02:39:39 --> Helper loaded: date_helper
INFO - 2018-08-03 02:39:39 --> Helper loaded: util_helper
INFO - 2018-08-03 02:39:39 --> Helper loaded: text_helper
INFO - 2018-08-03 02:39:39 --> Helper loaded: string_helper
INFO - 2018-08-03 02:39:39 --> Database Driver Class Initialized
DEBUG - 2018-08-03 02:39:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 02:39:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-03 02:39:40 --> Email Class Initialized
INFO - 2018-08-03 02:39:40 --> Controller Class Initialized
DEBUG - 2018-08-03 02:39:40 --> Admin MX_Controller Initialized
INFO - 2018-08-03 02:39:40 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-03 02:39:40 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-03 02:39:40 --> Login MX_Controller Initialized
DEBUG - 2018-08-03 02:39:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-03 02:39:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-03 02:39:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-08-03 02:39:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-08-03 02:39:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-08-03 02:39:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-08-03 02:39:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-08-03 02:39:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/dashboard.php
INFO - 2018-08-03 02:39:40 --> Final output sent to browser
DEBUG - 2018-08-03 02:39:40 --> Total execution time: 0.6990
INFO - 2018-08-03 02:39:40 --> Config Class Initialized
INFO - 2018-08-03 02:39:40 --> Hooks Class Initialized
DEBUG - 2018-08-03 02:39:40 --> UTF-8 Support Enabled
INFO - 2018-08-03 02:39:41 --> Utf8 Class Initialized
INFO - 2018-08-03 02:39:41 --> URI Class Initialized
INFO - 2018-08-03 02:39:41 --> Router Class Initialized
INFO - 2018-08-03 02:39:41 --> Output Class Initialized
INFO - 2018-08-03 02:39:41 --> Security Class Initialized
DEBUG - 2018-08-03 02:39:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 02:39:41 --> Input Class Initialized
INFO - 2018-08-03 02:39:41 --> Language Class Initialized
INFO - 2018-08-03 02:39:41 --> Language Class Initialized
INFO - 2018-08-03 02:39:41 --> Config Class Initialized
INFO - 2018-08-03 02:39:41 --> Loader Class Initialized
DEBUG - 2018-08-03 02:39:41 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-03 02:39:41 --> Helper loaded: url_helper
INFO - 2018-08-03 02:39:41 --> Helper loaded: form_helper
INFO - 2018-08-03 02:39:41 --> Helper loaded: date_helper
INFO - 2018-08-03 02:39:41 --> Helper loaded: util_helper
INFO - 2018-08-03 02:39:41 --> Helper loaded: text_helper
INFO - 2018-08-03 02:39:41 --> Helper loaded: string_helper
INFO - 2018-08-03 02:39:41 --> Database Driver Class Initialized
DEBUG - 2018-08-03 02:39:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 02:39:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-03 02:39:41 --> Email Class Initialized
INFO - 2018-08-03 02:39:41 --> Controller Class Initialized
DEBUG - 2018-08-03 02:39:41 --> Home MX_Controller Initialized
DEBUG - 2018-08-03 02:39:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-03 02:39:41 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-03 02:39:41 --> Login MX_Controller Initialized
INFO - 2018-08-03 02:39:41 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-03 02:39:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-03 02:39:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-03 02:40:14 --> Config Class Initialized
INFO - 2018-08-03 02:40:14 --> Hooks Class Initialized
DEBUG - 2018-08-03 02:40:14 --> UTF-8 Support Enabled
INFO - 2018-08-03 02:40:14 --> Utf8 Class Initialized
INFO - 2018-08-03 02:40:14 --> URI Class Initialized
INFO - 2018-08-03 02:40:14 --> Router Class Initialized
INFO - 2018-08-03 02:40:14 --> Output Class Initialized
INFO - 2018-08-03 02:40:14 --> Security Class Initialized
DEBUG - 2018-08-03 02:40:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 02:40:14 --> Input Class Initialized
INFO - 2018-08-03 02:40:14 --> Language Class Initialized
INFO - 2018-08-03 02:40:14 --> Language Class Initialized
INFO - 2018-08-03 02:40:14 --> Config Class Initialized
INFO - 2018-08-03 02:40:14 --> Loader Class Initialized
DEBUG - 2018-08-03 02:40:14 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-03 02:40:14 --> Helper loaded: url_helper
INFO - 2018-08-03 02:40:14 --> Helper loaded: form_helper
INFO - 2018-08-03 02:40:14 --> Helper loaded: date_helper
INFO - 2018-08-03 02:40:14 --> Helper loaded: util_helper
INFO - 2018-08-03 02:40:14 --> Helper loaded: text_helper
INFO - 2018-08-03 02:40:14 --> Helper loaded: string_helper
INFO - 2018-08-03 02:40:14 --> Database Driver Class Initialized
DEBUG - 2018-08-03 02:40:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 02:40:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-03 02:40:14 --> Email Class Initialized
INFO - 2018-08-03 02:40:14 --> Controller Class Initialized
DEBUG - 2018-08-03 02:40:14 --> Admin MX_Controller Initialized
INFO - 2018-08-03 02:40:14 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-03 02:40:14 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-03 02:40:14 --> Login MX_Controller Initialized
DEBUG - 2018-08-03 02:40:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-03 02:40:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-03 02:40:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-08-03 02:40:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-08-03 02:40:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-08-03 02:40:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-08-03 02:40:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-08-03 02:40:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/dashboard.php
INFO - 2018-08-03 02:40:14 --> Final output sent to browser
DEBUG - 2018-08-03 02:40:14 --> Total execution time: 0.6770
INFO - 2018-08-03 02:40:15 --> Config Class Initialized
INFO - 2018-08-03 02:40:15 --> Hooks Class Initialized
DEBUG - 2018-08-03 02:40:15 --> UTF-8 Support Enabled
INFO - 2018-08-03 02:40:15 --> Utf8 Class Initialized
INFO - 2018-08-03 02:40:15 --> URI Class Initialized
INFO - 2018-08-03 02:40:15 --> Router Class Initialized
INFO - 2018-08-03 02:40:15 --> Output Class Initialized
INFO - 2018-08-03 02:40:15 --> Security Class Initialized
DEBUG - 2018-08-03 02:40:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 02:40:15 --> Input Class Initialized
INFO - 2018-08-03 02:40:15 --> Language Class Initialized
INFO - 2018-08-03 02:40:15 --> Language Class Initialized
INFO - 2018-08-03 02:40:15 --> Config Class Initialized
INFO - 2018-08-03 02:40:15 --> Loader Class Initialized
DEBUG - 2018-08-03 02:40:16 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-03 02:40:16 --> Helper loaded: url_helper
INFO - 2018-08-03 02:40:16 --> Helper loaded: form_helper
INFO - 2018-08-03 02:40:16 --> Helper loaded: date_helper
INFO - 2018-08-03 02:40:16 --> Helper loaded: util_helper
INFO - 2018-08-03 02:40:16 --> Helper loaded: text_helper
INFO - 2018-08-03 02:40:16 --> Helper loaded: string_helper
INFO - 2018-08-03 02:40:16 --> Database Driver Class Initialized
DEBUG - 2018-08-03 02:40:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 02:40:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-03 02:40:16 --> Email Class Initialized
INFO - 2018-08-03 02:40:16 --> Controller Class Initialized
DEBUG - 2018-08-03 02:40:16 --> Home MX_Controller Initialized
DEBUG - 2018-08-03 02:40:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-03 02:40:16 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-03 02:40:16 --> Login MX_Controller Initialized
INFO - 2018-08-03 02:40:16 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-03 02:40:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-03 02:40:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-03 02:40:36 --> Config Class Initialized
INFO - 2018-08-03 02:40:36 --> Hooks Class Initialized
DEBUG - 2018-08-03 02:40:36 --> UTF-8 Support Enabled
INFO - 2018-08-03 02:40:36 --> Utf8 Class Initialized
INFO - 2018-08-03 02:40:36 --> URI Class Initialized
INFO - 2018-08-03 02:40:36 --> Router Class Initialized
INFO - 2018-08-03 02:40:36 --> Output Class Initialized
INFO - 2018-08-03 02:40:36 --> Security Class Initialized
DEBUG - 2018-08-03 02:40:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 02:40:36 --> Input Class Initialized
INFO - 2018-08-03 02:40:36 --> Language Class Initialized
INFO - 2018-08-03 02:40:36 --> Language Class Initialized
INFO - 2018-08-03 02:40:36 --> Config Class Initialized
INFO - 2018-08-03 02:40:36 --> Loader Class Initialized
DEBUG - 2018-08-03 02:40:36 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-03 02:40:36 --> Helper loaded: url_helper
INFO - 2018-08-03 02:40:36 --> Helper loaded: form_helper
INFO - 2018-08-03 02:40:36 --> Helper loaded: date_helper
INFO - 2018-08-03 02:40:36 --> Helper loaded: util_helper
INFO - 2018-08-03 02:40:36 --> Helper loaded: text_helper
INFO - 2018-08-03 02:40:36 --> Helper loaded: string_helper
INFO - 2018-08-03 02:40:36 --> Database Driver Class Initialized
DEBUG - 2018-08-03 02:40:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 02:40:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-03 02:40:36 --> Email Class Initialized
INFO - 2018-08-03 02:40:36 --> Controller Class Initialized
DEBUG - 2018-08-03 02:40:36 --> Admin MX_Controller Initialized
INFO - 2018-08-03 02:40:36 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-03 02:40:36 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-03 02:40:36 --> Login MX_Controller Initialized
DEBUG - 2018-08-03 02:40:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-03 02:40:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-03 02:40:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-08-03 02:40:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-08-03 02:40:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-08-03 02:40:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-08-03 02:40:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-08-03 02:40:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/dashboard.php
INFO - 2018-08-03 02:40:37 --> Final output sent to browser
DEBUG - 2018-08-03 02:40:37 --> Total execution time: 0.7120
INFO - 2018-08-03 02:40:37 --> Config Class Initialized
INFO - 2018-08-03 02:40:37 --> Hooks Class Initialized
DEBUG - 2018-08-03 02:40:37 --> UTF-8 Support Enabled
INFO - 2018-08-03 02:40:37 --> Utf8 Class Initialized
INFO - 2018-08-03 02:40:37 --> URI Class Initialized
INFO - 2018-08-03 02:40:38 --> Router Class Initialized
INFO - 2018-08-03 02:40:38 --> Output Class Initialized
INFO - 2018-08-03 02:40:38 --> Security Class Initialized
DEBUG - 2018-08-03 02:40:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 02:40:38 --> Input Class Initialized
INFO - 2018-08-03 02:40:38 --> Language Class Initialized
INFO - 2018-08-03 02:40:38 --> Language Class Initialized
INFO - 2018-08-03 02:40:38 --> Config Class Initialized
INFO - 2018-08-03 02:40:38 --> Loader Class Initialized
DEBUG - 2018-08-03 02:40:38 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-03 02:40:38 --> Helper loaded: url_helper
INFO - 2018-08-03 02:40:38 --> Helper loaded: form_helper
INFO - 2018-08-03 02:40:38 --> Helper loaded: date_helper
INFO - 2018-08-03 02:40:38 --> Helper loaded: util_helper
INFO - 2018-08-03 02:40:38 --> Helper loaded: text_helper
INFO - 2018-08-03 02:40:38 --> Helper loaded: string_helper
INFO - 2018-08-03 02:40:38 --> Database Driver Class Initialized
DEBUG - 2018-08-03 02:40:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 02:40:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-03 02:40:38 --> Email Class Initialized
INFO - 2018-08-03 02:40:38 --> Controller Class Initialized
DEBUG - 2018-08-03 02:40:38 --> Home MX_Controller Initialized
DEBUG - 2018-08-03 02:40:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-03 02:40:38 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-03 02:40:38 --> Login MX_Controller Initialized
INFO - 2018-08-03 02:40:38 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-03 02:40:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-03 02:40:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-03 02:42:29 --> Config Class Initialized
INFO - 2018-08-03 02:42:29 --> Hooks Class Initialized
DEBUG - 2018-08-03 02:42:29 --> UTF-8 Support Enabled
INFO - 2018-08-03 02:42:29 --> Utf8 Class Initialized
INFO - 2018-08-03 02:42:29 --> URI Class Initialized
INFO - 2018-08-03 02:42:29 --> Router Class Initialized
INFO - 2018-08-03 02:42:29 --> Output Class Initialized
INFO - 2018-08-03 02:42:29 --> Security Class Initialized
DEBUG - 2018-08-03 02:42:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 02:42:29 --> Input Class Initialized
INFO - 2018-08-03 02:42:29 --> Language Class Initialized
INFO - 2018-08-03 02:42:29 --> Language Class Initialized
INFO - 2018-08-03 02:42:29 --> Config Class Initialized
INFO - 2018-08-03 02:42:29 --> Loader Class Initialized
DEBUG - 2018-08-03 02:42:29 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-03 02:42:29 --> Helper loaded: url_helper
INFO - 2018-08-03 02:42:29 --> Helper loaded: form_helper
INFO - 2018-08-03 02:42:29 --> Helper loaded: date_helper
INFO - 2018-08-03 02:42:29 --> Helper loaded: util_helper
INFO - 2018-08-03 02:42:29 --> Helper loaded: text_helper
INFO - 2018-08-03 02:42:29 --> Helper loaded: string_helper
INFO - 2018-08-03 02:42:29 --> Database Driver Class Initialized
DEBUG - 2018-08-03 02:42:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 02:42:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-03 02:42:29 --> Email Class Initialized
INFO - 2018-08-03 02:42:29 --> Controller Class Initialized
DEBUG - 2018-08-03 02:42:29 --> Admin MX_Controller Initialized
INFO - 2018-08-03 02:42:29 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-03 02:42:29 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-03 02:42:29 --> Login MX_Controller Initialized
DEBUG - 2018-08-03 02:42:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-03 02:42:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-03 02:42:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-08-03 02:42:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-08-03 02:42:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-08-03 02:42:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-08-03 02:42:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-08-03 02:42:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/dashboard.php
INFO - 2018-08-03 02:42:29 --> Final output sent to browser
DEBUG - 2018-08-03 02:42:29 --> Total execution time: 0.6997
INFO - 2018-08-03 02:42:30 --> Config Class Initialized
INFO - 2018-08-03 02:42:30 --> Hooks Class Initialized
DEBUG - 2018-08-03 02:42:30 --> UTF-8 Support Enabled
INFO - 2018-08-03 02:42:30 --> Utf8 Class Initialized
INFO - 2018-08-03 02:42:30 --> URI Class Initialized
INFO - 2018-08-03 02:42:30 --> Router Class Initialized
INFO - 2018-08-03 02:42:30 --> Output Class Initialized
INFO - 2018-08-03 02:42:31 --> Security Class Initialized
DEBUG - 2018-08-03 02:42:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 02:42:31 --> Input Class Initialized
INFO - 2018-08-03 02:42:31 --> Language Class Initialized
INFO - 2018-08-03 02:42:31 --> Language Class Initialized
INFO - 2018-08-03 02:42:31 --> Config Class Initialized
INFO - 2018-08-03 02:42:31 --> Loader Class Initialized
DEBUG - 2018-08-03 02:42:31 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-03 02:42:31 --> Helper loaded: url_helper
INFO - 2018-08-03 02:42:31 --> Helper loaded: form_helper
INFO - 2018-08-03 02:42:31 --> Helper loaded: date_helper
INFO - 2018-08-03 02:42:31 --> Helper loaded: util_helper
INFO - 2018-08-03 02:42:31 --> Helper loaded: text_helper
INFO - 2018-08-03 02:42:31 --> Helper loaded: string_helper
INFO - 2018-08-03 02:42:31 --> Database Driver Class Initialized
DEBUG - 2018-08-03 02:42:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 02:42:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-03 02:42:31 --> Email Class Initialized
INFO - 2018-08-03 02:42:31 --> Controller Class Initialized
DEBUG - 2018-08-03 02:42:31 --> Home MX_Controller Initialized
DEBUG - 2018-08-03 02:42:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-03 02:42:31 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-03 02:42:31 --> Login MX_Controller Initialized
INFO - 2018-08-03 02:42:31 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-03 02:42:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-03 02:42:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-03 02:42:47 --> Config Class Initialized
INFO - 2018-08-03 02:42:47 --> Hooks Class Initialized
DEBUG - 2018-08-03 02:42:47 --> UTF-8 Support Enabled
INFO - 2018-08-03 02:42:47 --> Utf8 Class Initialized
INFO - 2018-08-03 02:42:47 --> URI Class Initialized
INFO - 2018-08-03 02:42:47 --> Router Class Initialized
INFO - 2018-08-03 02:42:47 --> Output Class Initialized
INFO - 2018-08-03 02:42:47 --> Security Class Initialized
DEBUG - 2018-08-03 02:42:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 02:42:47 --> Input Class Initialized
INFO - 2018-08-03 02:42:47 --> Language Class Initialized
INFO - 2018-08-03 02:42:47 --> Language Class Initialized
INFO - 2018-08-03 02:42:47 --> Config Class Initialized
INFO - 2018-08-03 02:42:47 --> Loader Class Initialized
DEBUG - 2018-08-03 02:42:47 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-03 02:42:47 --> Helper loaded: url_helper
INFO - 2018-08-03 02:42:47 --> Helper loaded: form_helper
INFO - 2018-08-03 02:42:47 --> Helper loaded: date_helper
INFO - 2018-08-03 02:42:47 --> Helper loaded: util_helper
INFO - 2018-08-03 02:42:47 --> Helper loaded: text_helper
INFO - 2018-08-03 02:42:47 --> Helper loaded: string_helper
INFO - 2018-08-03 02:42:47 --> Database Driver Class Initialized
DEBUG - 2018-08-03 02:42:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 02:42:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-03 02:42:47 --> Email Class Initialized
INFO - 2018-08-03 02:42:47 --> Controller Class Initialized
DEBUG - 2018-08-03 02:42:48 --> Home MX_Controller Initialized
DEBUG - 2018-08-03 02:42:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-03 02:42:48 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-03 02:42:48 --> Login MX_Controller Initialized
INFO - 2018-08-03 02:42:48 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-03 02:42:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-03 02:42:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-03 02:42:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-08-03 02:42:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-08-03 02:42:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-08-03 02:42:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-08-03 02:42:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-08-03 02:42:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-08-03 02:42:48 --> Final output sent to browser
DEBUG - 2018-08-03 02:42:48 --> Total execution time: 0.7358
INFO - 2018-08-03 02:42:49 --> Config Class Initialized
INFO - 2018-08-03 02:42:49 --> Hooks Class Initialized
DEBUG - 2018-08-03 02:42:49 --> UTF-8 Support Enabled
INFO - 2018-08-03 02:42:49 --> Config Class Initialized
INFO - 2018-08-03 02:42:49 --> Hooks Class Initialized
INFO - 2018-08-03 02:42:49 --> Utf8 Class Initialized
DEBUG - 2018-08-03 02:42:49 --> UTF-8 Support Enabled
INFO - 2018-08-03 02:42:49 --> URI Class Initialized
INFO - 2018-08-03 02:42:49 --> Utf8 Class Initialized
INFO - 2018-08-03 02:42:49 --> URI Class Initialized
INFO - 2018-08-03 02:42:49 --> Router Class Initialized
INFO - 2018-08-03 02:42:49 --> Router Class Initialized
INFO - 2018-08-03 02:42:49 --> Output Class Initialized
INFO - 2018-08-03 02:42:49 --> Output Class Initialized
INFO - 2018-08-03 02:42:49 --> Security Class Initialized
DEBUG - 2018-08-03 02:42:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 02:42:49 --> Security Class Initialized
INFO - 2018-08-03 02:42:49 --> Input Class Initialized
INFO - 2018-08-03 02:42:49 --> Language Class Initialized
INFO - 2018-08-03 02:42:49 --> Language Class Initialized
DEBUG - 2018-08-03 02:42:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 02:42:49 --> Config Class Initialized
INFO - 2018-08-03 02:42:49 --> Input Class Initialized
INFO - 2018-08-03 02:42:49 --> Loader Class Initialized
DEBUG - 2018-08-03 02:42:49 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-03 02:42:49 --> Language Class Initialized
INFO - 2018-08-03 02:42:49 --> Helper loaded: url_helper
INFO - 2018-08-03 02:42:49 --> Helper loaded: form_helper
ERROR - 2018-08-03 02:42:49 --> 404 Page Not Found: /index
INFO - 2018-08-03 02:42:49 --> Helper loaded: date_helper
INFO - 2018-08-03 02:42:49 --> Config Class Initialized
INFO - 2018-08-03 02:42:49 --> Hooks Class Initialized
INFO - 2018-08-03 02:42:49 --> Helper loaded: util_helper
DEBUG - 2018-08-03 02:42:49 --> UTF-8 Support Enabled
INFO - 2018-08-03 02:42:49 --> Helper loaded: text_helper
INFO - 2018-08-03 02:42:49 --> Utf8 Class Initialized
INFO - 2018-08-03 02:42:49 --> Helper loaded: string_helper
INFO - 2018-08-03 02:42:49 --> URI Class Initialized
INFO - 2018-08-03 02:42:49 --> Router Class Initialized
INFO - 2018-08-03 02:42:49 --> Database Driver Class Initialized
INFO - 2018-08-03 02:42:49 --> Output Class Initialized
DEBUG - 2018-08-03 02:42:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 02:42:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-03 02:42:49 --> Security Class Initialized
INFO - 2018-08-03 02:42:49 --> Email Class Initialized
DEBUG - 2018-08-03 02:42:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 02:42:49 --> Controller Class Initialized
INFO - 2018-08-03 02:42:50 --> Input Class Initialized
DEBUG - 2018-08-03 02:42:50 --> Home MX_Controller Initialized
INFO - 2018-08-03 02:42:50 --> Language Class Initialized
ERROR - 2018-08-03 02:42:50 --> 404 Page Not Found: /index
DEBUG - 2018-08-03 02:42:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-08-03 02:42:50 --> Config Class Initialized
INFO - 2018-08-03 02:42:50 --> Hooks Class Initialized
DEBUG - 2018-08-03 02:42:50 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-03 02:42:50 --> Login MX_Controller Initialized
DEBUG - 2018-08-03 02:42:50 --> UTF-8 Support Enabled
INFO - 2018-08-03 02:42:50 --> Utf8 Class Initialized
INFO - 2018-08-03 02:42:50 --> Language file loaded: language/english/data_lang.php
INFO - 2018-08-03 02:42:50 --> URI Class Initialized
DEBUG - 2018-08-03 02:42:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-08-03 02:42:50 --> Router Class Initialized
DEBUG - 2018-08-03 02:42:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-03 02:42:50 --> Output Class Initialized
INFO - 2018-08-03 02:42:50 --> Security Class Initialized
DEBUG - 2018-08-03 02:42:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 02:42:50 --> Input Class Initialized
INFO - 2018-08-03 02:42:50 --> Language Class Initialized
ERROR - 2018-08-03 02:42:50 --> 404 Page Not Found: /index
INFO - 2018-08-03 02:43:04 --> Config Class Initialized
INFO - 2018-08-03 02:43:04 --> Hooks Class Initialized
DEBUG - 2018-08-03 02:43:04 --> UTF-8 Support Enabled
INFO - 2018-08-03 02:43:04 --> Utf8 Class Initialized
INFO - 2018-08-03 02:43:04 --> URI Class Initialized
INFO - 2018-08-03 02:43:04 --> Router Class Initialized
INFO - 2018-08-03 02:43:04 --> Output Class Initialized
INFO - 2018-08-03 02:43:04 --> Security Class Initialized
DEBUG - 2018-08-03 02:43:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 02:43:05 --> Input Class Initialized
INFO - 2018-08-03 02:43:05 --> Language Class Initialized
INFO - 2018-08-03 02:43:05 --> Language Class Initialized
INFO - 2018-08-03 02:43:05 --> Config Class Initialized
INFO - 2018-08-03 02:43:05 --> Loader Class Initialized
DEBUG - 2018-08-03 02:43:05 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-03 02:43:05 --> Helper loaded: url_helper
INFO - 2018-08-03 02:43:05 --> Helper loaded: form_helper
INFO - 2018-08-03 02:43:05 --> Helper loaded: date_helper
INFO - 2018-08-03 02:43:05 --> Helper loaded: util_helper
INFO - 2018-08-03 02:43:05 --> Helper loaded: text_helper
INFO - 2018-08-03 02:43:05 --> Helper loaded: string_helper
INFO - 2018-08-03 02:43:05 --> Database Driver Class Initialized
DEBUG - 2018-08-03 02:43:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 02:43:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-03 02:43:05 --> Email Class Initialized
INFO - 2018-08-03 02:43:05 --> Controller Class Initialized
DEBUG - 2018-08-03 02:43:05 --> Profile MX_Controller Initialized
INFO - 2018-08-03 02:43:05 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-03 02:43:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-03 02:43:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Profile_model.php
DEBUG - 2018-08-03 02:43:05 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-03 02:43:05 --> Login MX_Controller Initialized
DEBUG - 2018-08-03 02:43:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-03 02:43:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-08-03 02:43:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-08-03 02:43:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-08-03 02:43:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-08-03 02:43:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-08-03 02:43:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/profile.php
INFO - 2018-08-03 02:43:05 --> Final output sent to browser
DEBUG - 2018-08-03 02:43:05 --> Total execution time: 0.7686
INFO - 2018-08-03 02:43:06 --> Config Class Initialized
INFO - 2018-08-03 02:43:06 --> Hooks Class Initialized
DEBUG - 2018-08-03 02:43:06 --> UTF-8 Support Enabled
INFO - 2018-08-03 02:43:06 --> Utf8 Class Initialized
INFO - 2018-08-03 02:43:06 --> URI Class Initialized
INFO - 2018-08-03 02:43:06 --> Router Class Initialized
INFO - 2018-08-03 02:43:06 --> Output Class Initialized
INFO - 2018-08-03 02:43:06 --> Security Class Initialized
DEBUG - 2018-08-03 02:43:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 02:43:06 --> Input Class Initialized
INFO - 2018-08-03 02:43:06 --> Language Class Initialized
INFO - 2018-08-03 02:43:06 --> Language Class Initialized
INFO - 2018-08-03 02:43:06 --> Config Class Initialized
INFO - 2018-08-03 02:43:06 --> Loader Class Initialized
DEBUG - 2018-08-03 02:43:06 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-03 02:43:06 --> Helper loaded: url_helper
INFO - 2018-08-03 02:43:06 --> Helper loaded: form_helper
INFO - 2018-08-03 02:43:06 --> Helper loaded: date_helper
INFO - 2018-08-03 02:43:06 --> Helper loaded: util_helper
INFO - 2018-08-03 02:43:06 --> Helper loaded: text_helper
INFO - 2018-08-03 02:43:06 --> Helper loaded: string_helper
INFO - 2018-08-03 02:43:06 --> Config Class Initialized
INFO - 2018-08-03 02:43:06 --> Hooks Class Initialized
INFO - 2018-08-03 02:43:06 --> Database Driver Class Initialized
DEBUG - 2018-08-03 02:43:06 --> UTF-8 Support Enabled
DEBUG - 2018-08-03 02:43:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 02:43:06 --> Utf8 Class Initialized
INFO - 2018-08-03 02:43:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-03 02:43:06 --> URI Class Initialized
INFO - 2018-08-03 02:43:06 --> Email Class Initialized
INFO - 2018-08-03 02:43:06 --> Controller Class Initialized
INFO - 2018-08-03 02:43:06 --> Router Class Initialized
DEBUG - 2018-08-03 02:43:06 --> Home MX_Controller Initialized
INFO - 2018-08-03 02:43:06 --> Output Class Initialized
DEBUG - 2018-08-03 02:43:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-08-03 02:43:07 --> Security Class Initialized
DEBUG - 2018-08-03 02:43:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-08-03 02:43:07 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-03 02:43:07 --> Login MX_Controller Initialized
INFO - 2018-08-03 02:43:07 --> Input Class Initialized
INFO - 2018-08-03 02:43:07 --> Language file loaded: language/english/data_lang.php
INFO - 2018-08-03 02:43:07 --> Language Class Initialized
DEBUG - 2018-08-03 02:43:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-08-03 02:43:07 --> Language Class Initialized
INFO - 2018-08-03 02:43:07 --> Config Class Initialized
DEBUG - 2018-08-03 02:43:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-03 02:43:07 --> Loader Class Initialized
DEBUG - 2018-08-03 02:43:07 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-03 02:43:07 --> Helper loaded: url_helper
INFO - 2018-08-03 02:43:07 --> Helper loaded: form_helper
INFO - 2018-08-03 02:43:07 --> Helper loaded: date_helper
INFO - 2018-08-03 02:43:07 --> Helper loaded: util_helper
INFO - 2018-08-03 02:43:07 --> Helper loaded: text_helper
INFO - 2018-08-03 02:43:07 --> Helper loaded: string_helper
INFO - 2018-08-03 02:43:07 --> Database Driver Class Initialized
DEBUG - 2018-08-03 02:43:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 02:43:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-03 02:43:07 --> Email Class Initialized
INFO - 2018-08-03 02:43:07 --> Controller Class Initialized
DEBUG - 2018-08-03 02:43:07 --> Profile MX_Controller Initialized
INFO - 2018-08-03 02:43:07 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-03 02:43:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-03 02:43:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Profile_model.php
DEBUG - 2018-08-03 02:43:07 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-03 02:43:07 --> Login MX_Controller Initialized
DEBUG - 2018-08-03 02:43:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-03 02:43:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-08-03 02:43:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-08-03 02:43:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-08-03 02:43:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-08-03 02:43:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-08-03 02:43:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/profile.php
INFO - 2018-08-03 02:43:07 --> Final output sent to browser
DEBUG - 2018-08-03 02:43:07 --> Total execution time: 0.7520
INFO - 2018-08-03 02:43:08 --> Config Class Initialized
INFO - 2018-08-03 02:43:08 --> Hooks Class Initialized
DEBUG - 2018-08-03 02:43:08 --> UTF-8 Support Enabled
INFO - 2018-08-03 02:43:08 --> Utf8 Class Initialized
INFO - 2018-08-03 02:43:08 --> URI Class Initialized
INFO - 2018-08-03 02:43:08 --> Router Class Initialized
INFO - 2018-08-03 02:43:08 --> Output Class Initialized
INFO - 2018-08-03 02:43:08 --> Security Class Initialized
DEBUG - 2018-08-03 02:43:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 02:43:08 --> Input Class Initialized
INFO - 2018-08-03 02:43:08 --> Language Class Initialized
INFO - 2018-08-03 02:43:08 --> Language Class Initialized
INFO - 2018-08-03 02:43:08 --> Config Class Initialized
INFO - 2018-08-03 02:43:08 --> Loader Class Initialized
DEBUG - 2018-08-03 02:43:08 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-03 02:43:08 --> Helper loaded: url_helper
INFO - 2018-08-03 02:43:08 --> Helper loaded: form_helper
INFO - 2018-08-03 02:43:08 --> Helper loaded: date_helper
INFO - 2018-08-03 02:43:08 --> Helper loaded: util_helper
INFO - 2018-08-03 02:43:08 --> Helper loaded: text_helper
INFO - 2018-08-03 02:43:08 --> Helper loaded: string_helper
INFO - 2018-08-03 02:43:08 --> Database Driver Class Initialized
DEBUG - 2018-08-03 02:43:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 02:43:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-03 02:43:08 --> Email Class Initialized
INFO - 2018-08-03 02:43:08 --> Controller Class Initialized
DEBUG - 2018-08-03 02:43:08 --> Home MX_Controller Initialized
DEBUG - 2018-08-03 02:43:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-03 02:43:08 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-03 02:43:08 --> Login MX_Controller Initialized
INFO - 2018-08-03 02:43:08 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-03 02:43:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-03 02:43:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-03 02:43:09 --> Config Class Initialized
INFO - 2018-08-03 02:43:09 --> Hooks Class Initialized
DEBUG - 2018-08-03 02:43:09 --> UTF-8 Support Enabled
INFO - 2018-08-03 02:43:10 --> Utf8 Class Initialized
INFO - 2018-08-03 02:43:10 --> URI Class Initialized
INFO - 2018-08-03 02:43:10 --> Router Class Initialized
INFO - 2018-08-03 02:43:10 --> Output Class Initialized
INFO - 2018-08-03 02:43:10 --> Security Class Initialized
DEBUG - 2018-08-03 02:43:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 02:43:10 --> Input Class Initialized
INFO - 2018-08-03 02:43:10 --> Language Class Initialized
INFO - 2018-08-03 02:43:10 --> Language Class Initialized
INFO - 2018-08-03 02:43:10 --> Config Class Initialized
INFO - 2018-08-03 02:43:10 --> Loader Class Initialized
DEBUG - 2018-08-03 02:43:10 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-03 02:43:10 --> Helper loaded: url_helper
INFO - 2018-08-03 02:43:10 --> Helper loaded: form_helper
INFO - 2018-08-03 02:43:10 --> Helper loaded: date_helper
INFO - 2018-08-03 02:43:10 --> Helper loaded: util_helper
INFO - 2018-08-03 02:43:10 --> Helper loaded: text_helper
INFO - 2018-08-03 02:43:10 --> Helper loaded: string_helper
INFO - 2018-08-03 02:43:10 --> Database Driver Class Initialized
DEBUG - 2018-08-03 02:43:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 02:43:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-03 02:43:10 --> Email Class Initialized
INFO - 2018-08-03 02:43:10 --> Controller Class Initialized
DEBUG - 2018-08-03 02:43:10 --> Admin MX_Controller Initialized
INFO - 2018-08-03 02:43:10 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-03 02:43:10 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-03 02:43:10 --> Login MX_Controller Initialized
DEBUG - 2018-08-03 02:43:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-03 02:43:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-03 02:43:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-08-03 02:43:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-08-03 02:43:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-08-03 02:43:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-08-03 02:43:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-08-03 02:43:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/dashboard.php
INFO - 2018-08-03 02:43:10 --> Final output sent to browser
DEBUG - 2018-08-03 02:43:10 --> Total execution time: 0.7899
INFO - 2018-08-03 02:43:11 --> Config Class Initialized
INFO - 2018-08-03 02:43:11 --> Hooks Class Initialized
DEBUG - 2018-08-03 02:43:11 --> UTF-8 Support Enabled
INFO - 2018-08-03 02:43:11 --> Utf8 Class Initialized
INFO - 2018-08-03 02:43:11 --> URI Class Initialized
INFO - 2018-08-03 02:43:11 --> Router Class Initialized
INFO - 2018-08-03 02:43:11 --> Output Class Initialized
INFO - 2018-08-03 02:43:11 --> Security Class Initialized
DEBUG - 2018-08-03 02:43:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 02:43:11 --> Input Class Initialized
INFO - 2018-08-03 02:43:11 --> Language Class Initialized
INFO - 2018-08-03 02:43:11 --> Language Class Initialized
INFO - 2018-08-03 02:43:11 --> Config Class Initialized
INFO - 2018-08-03 02:43:11 --> Loader Class Initialized
DEBUG - 2018-08-03 02:43:11 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-03 02:43:11 --> Helper loaded: url_helper
INFO - 2018-08-03 02:43:11 --> Helper loaded: form_helper
INFO - 2018-08-03 02:43:11 --> Helper loaded: date_helper
INFO - 2018-08-03 02:43:11 --> Helper loaded: util_helper
INFO - 2018-08-03 02:43:11 --> Helper loaded: text_helper
INFO - 2018-08-03 02:43:11 --> Helper loaded: string_helper
INFO - 2018-08-03 02:43:11 --> Database Driver Class Initialized
DEBUG - 2018-08-03 02:43:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 02:43:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-03 02:43:11 --> Email Class Initialized
INFO - 2018-08-03 02:43:12 --> Controller Class Initialized
DEBUG - 2018-08-03 02:43:12 --> Home MX_Controller Initialized
DEBUG - 2018-08-03 02:43:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-03 02:43:12 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-03 02:43:12 --> Login MX_Controller Initialized
INFO - 2018-08-03 02:43:12 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-03 02:43:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-03 02:43:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-03 02:43:34 --> Config Class Initialized
INFO - 2018-08-03 02:43:34 --> Hooks Class Initialized
DEBUG - 2018-08-03 02:43:34 --> UTF-8 Support Enabled
INFO - 2018-08-03 02:43:34 --> Utf8 Class Initialized
INFO - 2018-08-03 02:43:34 --> URI Class Initialized
INFO - 2018-08-03 02:43:34 --> Router Class Initialized
INFO - 2018-08-03 02:43:34 --> Output Class Initialized
INFO - 2018-08-03 02:43:34 --> Security Class Initialized
DEBUG - 2018-08-03 02:43:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 02:43:34 --> Input Class Initialized
INFO - 2018-08-03 02:43:34 --> Language Class Initialized
INFO - 2018-08-03 02:43:34 --> Language Class Initialized
INFO - 2018-08-03 02:43:34 --> Config Class Initialized
INFO - 2018-08-03 02:43:34 --> Loader Class Initialized
DEBUG - 2018-08-03 02:43:34 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-03 02:43:34 --> Helper loaded: url_helper
INFO - 2018-08-03 02:43:34 --> Helper loaded: form_helper
INFO - 2018-08-03 02:43:34 --> Helper loaded: date_helper
INFO - 2018-08-03 02:43:34 --> Helper loaded: util_helper
INFO - 2018-08-03 02:43:34 --> Helper loaded: text_helper
INFO - 2018-08-03 02:43:34 --> Helper loaded: string_helper
INFO - 2018-08-03 02:43:34 --> Database Driver Class Initialized
DEBUG - 2018-08-03 02:43:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 02:43:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-03 02:43:34 --> Email Class Initialized
INFO - 2018-08-03 02:43:34 --> Controller Class Initialized
DEBUG - 2018-08-03 02:43:34 --> Home MX_Controller Initialized
DEBUG - 2018-08-03 02:43:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-03 02:43:34 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-03 02:43:34 --> Login MX_Controller Initialized
INFO - 2018-08-03 02:43:34 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-03 02:43:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-03 02:43:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-03 02:43:37 --> Config Class Initialized
INFO - 2018-08-03 02:43:37 --> Hooks Class Initialized
DEBUG - 2018-08-03 02:43:37 --> UTF-8 Support Enabled
INFO - 2018-08-03 02:43:37 --> Utf8 Class Initialized
INFO - 2018-08-03 02:43:37 --> URI Class Initialized
INFO - 2018-08-03 02:43:37 --> Router Class Initialized
INFO - 2018-08-03 02:43:37 --> Output Class Initialized
INFO - 2018-08-03 02:43:37 --> Security Class Initialized
DEBUG - 2018-08-03 02:43:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 02:43:37 --> Input Class Initialized
INFO - 2018-08-03 02:43:37 --> Language Class Initialized
INFO - 2018-08-03 02:43:37 --> Language Class Initialized
INFO - 2018-08-03 02:43:37 --> Config Class Initialized
INFO - 2018-08-03 02:43:37 --> Loader Class Initialized
DEBUG - 2018-08-03 02:43:37 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-03 02:43:37 --> Helper loaded: url_helper
INFO - 2018-08-03 02:43:37 --> Helper loaded: form_helper
INFO - 2018-08-03 02:43:37 --> Helper loaded: date_helper
INFO - 2018-08-03 02:43:37 --> Helper loaded: util_helper
INFO - 2018-08-03 02:43:37 --> Helper loaded: text_helper
INFO - 2018-08-03 02:43:37 --> Helper loaded: string_helper
INFO - 2018-08-03 02:43:37 --> Database Driver Class Initialized
DEBUG - 2018-08-03 02:43:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 02:43:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-03 02:43:37 --> Email Class Initialized
INFO - 2018-08-03 02:43:37 --> Controller Class Initialized
DEBUG - 2018-08-03 02:43:38 --> Home MX_Controller Initialized
DEBUG - 2018-08-03 02:43:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-03 02:43:38 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-03 02:43:38 --> Login MX_Controller Initialized
INFO - 2018-08-03 02:43:38 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-03 02:43:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-03 02:43:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-03 02:43:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-08-03 02:43:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-08-03 02:43:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-08-03 02:43:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-08-03 02:43:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-08-03 02:43:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-08-03 02:43:38 --> Final output sent to browser
DEBUG - 2018-08-03 02:43:38 --> Total execution time: 0.7462
INFO - 2018-08-03 02:43:38 --> Config Class Initialized
INFO - 2018-08-03 02:43:38 --> Hooks Class Initialized
DEBUG - 2018-08-03 02:43:38 --> UTF-8 Support Enabled
INFO - 2018-08-03 02:43:38 --> Config Class Initialized
INFO - 2018-08-03 02:43:38 --> Hooks Class Initialized
INFO - 2018-08-03 02:43:38 --> Utf8 Class Initialized
DEBUG - 2018-08-03 02:43:38 --> UTF-8 Support Enabled
INFO - 2018-08-03 02:43:38 --> Utf8 Class Initialized
INFO - 2018-08-03 02:43:39 --> URI Class Initialized
INFO - 2018-08-03 02:43:39 --> URI Class Initialized
INFO - 2018-08-03 02:43:39 --> Router Class Initialized
INFO - 2018-08-03 02:43:39 --> Router Class Initialized
INFO - 2018-08-03 02:43:39 --> Output Class Initialized
INFO - 2018-08-03 02:43:39 --> Security Class Initialized
DEBUG - 2018-08-03 02:43:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 02:43:39 --> Input Class Initialized
INFO - 2018-08-03 02:43:39 --> Output Class Initialized
INFO - 2018-08-03 02:43:39 --> Security Class Initialized
INFO - 2018-08-03 02:43:39 --> Language Class Initialized
DEBUG - 2018-08-03 02:43:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-08-03 02:43:39 --> 404 Page Not Found: /index
INFO - 2018-08-03 02:43:39 --> Input Class Initialized
INFO - 2018-08-03 02:43:39 --> Config Class Initialized
INFO - 2018-08-03 02:43:39 --> Hooks Class Initialized
INFO - 2018-08-03 02:43:39 --> Language Class Initialized
DEBUG - 2018-08-03 02:43:39 --> UTF-8 Support Enabled
INFO - 2018-08-03 02:43:39 --> Language Class Initialized
INFO - 2018-08-03 02:43:39 --> Utf8 Class Initialized
INFO - 2018-08-03 02:43:39 --> URI Class Initialized
INFO - 2018-08-03 02:43:39 --> Config Class Initialized
INFO - 2018-08-03 02:43:39 --> Router Class Initialized
INFO - 2018-08-03 02:43:39 --> Loader Class Initialized
DEBUG - 2018-08-03 02:43:39 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-03 02:43:39 --> Helper loaded: url_helper
INFO - 2018-08-03 02:43:39 --> Helper loaded: form_helper
INFO - 2018-08-03 02:43:39 --> Output Class Initialized
INFO - 2018-08-03 02:43:39 --> Helper loaded: date_helper
INFO - 2018-08-03 02:43:39 --> Helper loaded: util_helper
INFO - 2018-08-03 02:43:39 --> Helper loaded: text_helper
INFO - 2018-08-03 02:43:39 --> Helper loaded: string_helper
INFO - 2018-08-03 02:43:39 --> Security Class Initialized
INFO - 2018-08-03 02:43:39 --> Database Driver Class Initialized
DEBUG - 2018-08-03 02:43:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-08-03 02:43:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 02:43:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-03 02:43:39 --> Input Class Initialized
INFO - 2018-08-03 02:43:39 --> Language Class Initialized
INFO - 2018-08-03 02:43:39 --> Email Class Initialized
ERROR - 2018-08-03 02:43:39 --> 404 Page Not Found: /index
INFO - 2018-08-03 02:43:39 --> Controller Class Initialized
DEBUG - 2018-08-03 02:43:39 --> Home MX_Controller Initialized
INFO - 2018-08-03 02:43:39 --> Config Class Initialized
INFO - 2018-08-03 02:43:39 --> Hooks Class Initialized
DEBUG - 2018-08-03 02:43:39 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-03 02:43:39 --> UTF-8 Support Enabled
INFO - 2018-08-03 02:43:39 --> Utf8 Class Initialized
INFO - 2018-08-03 02:43:40 --> URI Class Initialized
INFO - 2018-08-03 02:43:40 --> Router Class Initialized
DEBUG - 2018-08-03 02:43:40 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
INFO - 2018-08-03 02:43:40 --> Output Class Initialized
INFO - 2018-08-03 02:43:40 --> Security Class Initialized
DEBUG - 2018-08-03 02:43:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 02:43:40 --> Input Class Initialized
INFO - 2018-08-03 02:43:40 --> Language Class Initialized
ERROR - 2018-08-03 02:43:40 --> 404 Page Not Found: /index
DEBUG - 2018-08-03 02:43:40 --> Login MX_Controller Initialized
INFO - 2018-08-03 02:43:40 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-03 02:43:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-03 02:43:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-03 02:43:40 --> Config Class Initialized
INFO - 2018-08-03 02:43:40 --> Hooks Class Initialized
DEBUG - 2018-08-03 02:43:40 --> UTF-8 Support Enabled
INFO - 2018-08-03 02:43:40 --> Utf8 Class Initialized
INFO - 2018-08-03 02:43:40 --> URI Class Initialized
INFO - 2018-08-03 02:43:40 --> Router Class Initialized
INFO - 2018-08-03 02:43:40 --> Output Class Initialized
INFO - 2018-08-03 02:43:40 --> Security Class Initialized
DEBUG - 2018-08-03 02:43:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 02:43:40 --> Input Class Initialized
INFO - 2018-08-03 02:43:41 --> Language Class Initialized
INFO - 2018-08-03 02:43:41 --> Language Class Initialized
INFO - 2018-08-03 02:43:41 --> Config Class Initialized
INFO - 2018-08-03 02:43:41 --> Loader Class Initialized
DEBUG - 2018-08-03 02:43:41 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-03 02:43:41 --> Helper loaded: url_helper
INFO - 2018-08-03 02:43:41 --> Helper loaded: form_helper
INFO - 2018-08-03 02:43:41 --> Helper loaded: date_helper
INFO - 2018-08-03 02:43:41 --> Helper loaded: util_helper
INFO - 2018-08-03 02:43:41 --> Helper loaded: text_helper
INFO - 2018-08-03 02:43:41 --> Helper loaded: string_helper
INFO - 2018-08-03 02:43:41 --> Database Driver Class Initialized
DEBUG - 2018-08-03 02:43:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 02:43:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-03 02:43:41 --> Email Class Initialized
INFO - 2018-08-03 02:43:41 --> Controller Class Initialized
DEBUG - 2018-08-03 02:43:41 --> Admin MX_Controller Initialized
INFO - 2018-08-03 02:43:41 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-03 02:43:41 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-03 02:43:41 --> Login MX_Controller Initialized
DEBUG - 2018-08-03 02:43:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-03 02:43:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-03 02:43:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-08-03 02:43:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-08-03 02:43:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-08-03 02:43:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-08-03 02:43:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-08-03 02:43:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/dashboard.php
INFO - 2018-08-03 02:43:41 --> Final output sent to browser
DEBUG - 2018-08-03 02:43:41 --> Total execution time: 0.7877
INFO - 2018-08-03 02:43:42 --> Config Class Initialized
INFO - 2018-08-03 02:43:42 --> Hooks Class Initialized
DEBUG - 2018-08-03 02:43:42 --> UTF-8 Support Enabled
INFO - 2018-08-03 02:43:42 --> Utf8 Class Initialized
INFO - 2018-08-03 02:43:42 --> URI Class Initialized
INFO - 2018-08-03 02:43:42 --> Router Class Initialized
INFO - 2018-08-03 02:43:42 --> Output Class Initialized
INFO - 2018-08-03 02:43:42 --> Security Class Initialized
DEBUG - 2018-08-03 02:43:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 02:43:42 --> Input Class Initialized
INFO - 2018-08-03 02:43:42 --> Language Class Initialized
INFO - 2018-08-03 02:43:42 --> Language Class Initialized
INFO - 2018-08-03 02:43:42 --> Config Class Initialized
INFO - 2018-08-03 02:43:42 --> Loader Class Initialized
DEBUG - 2018-08-03 02:43:42 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-03 02:43:42 --> Helper loaded: url_helper
INFO - 2018-08-03 02:43:42 --> Helper loaded: form_helper
INFO - 2018-08-03 02:43:42 --> Helper loaded: date_helper
INFO - 2018-08-03 02:43:42 --> Helper loaded: util_helper
INFO - 2018-08-03 02:43:42 --> Helper loaded: text_helper
INFO - 2018-08-03 02:43:42 --> Helper loaded: string_helper
INFO - 2018-08-03 02:43:42 --> Database Driver Class Initialized
DEBUG - 2018-08-03 02:43:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 02:43:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-03 02:43:42 --> Email Class Initialized
INFO - 2018-08-03 02:43:42 --> Controller Class Initialized
DEBUG - 2018-08-03 02:43:42 --> Home MX_Controller Initialized
DEBUG - 2018-08-03 02:43:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-03 02:43:43 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-03 02:43:43 --> Login MX_Controller Initialized
INFO - 2018-08-03 02:43:43 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-03 02:43:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-03 02:43:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-03 02:43:58 --> Config Class Initialized
INFO - 2018-08-03 02:43:58 --> Hooks Class Initialized
DEBUG - 2018-08-03 02:43:58 --> UTF-8 Support Enabled
INFO - 2018-08-03 02:43:58 --> Utf8 Class Initialized
INFO - 2018-08-03 02:43:58 --> URI Class Initialized
INFO - 2018-08-03 02:43:58 --> Router Class Initialized
INFO - 2018-08-03 02:43:58 --> Output Class Initialized
INFO - 2018-08-03 02:43:58 --> Security Class Initialized
DEBUG - 2018-08-03 02:43:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 02:43:58 --> Input Class Initialized
INFO - 2018-08-03 02:43:58 --> Language Class Initialized
INFO - 2018-08-03 02:43:58 --> Language Class Initialized
INFO - 2018-08-03 02:43:58 --> Config Class Initialized
INFO - 2018-08-03 02:43:58 --> Loader Class Initialized
DEBUG - 2018-08-03 02:43:58 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-03 02:43:58 --> Helper loaded: url_helper
INFO - 2018-08-03 02:43:58 --> Helper loaded: form_helper
INFO - 2018-08-03 02:43:58 --> Helper loaded: date_helper
INFO - 2018-08-03 02:43:58 --> Helper loaded: util_helper
INFO - 2018-08-03 02:43:58 --> Helper loaded: text_helper
INFO - 2018-08-03 02:43:58 --> Helper loaded: string_helper
INFO - 2018-08-03 02:43:58 --> Database Driver Class Initialized
DEBUG - 2018-08-03 02:43:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 02:43:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-03 02:43:58 --> Email Class Initialized
INFO - 2018-08-03 02:43:58 --> Controller Class Initialized
DEBUG - 2018-08-03 02:43:58 --> Home MX_Controller Initialized
DEBUG - 2018-08-03 02:43:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-03 02:43:58 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-03 02:43:58 --> Login MX_Controller Initialized
INFO - 2018-08-03 02:43:59 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-03 02:43:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-03 02:43:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-03 02:43:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-08-03 02:43:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-08-03 02:43:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-08-03 02:43:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-08-03 02:43:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-08-03 02:43:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-08-03 02:43:59 --> Final output sent to browser
DEBUG - 2018-08-03 02:43:59 --> Total execution time: 0.8029
INFO - 2018-08-03 02:43:59 --> Config Class Initialized
INFO - 2018-08-03 02:43:59 --> Hooks Class Initialized
DEBUG - 2018-08-03 02:43:59 --> UTF-8 Support Enabled
INFO - 2018-08-03 02:43:59 --> Utf8 Class Initialized
INFO - 2018-08-03 02:43:59 --> URI Class Initialized
INFO - 2018-08-03 02:43:59 --> Config Class Initialized
INFO - 2018-08-03 02:43:59 --> Hooks Class Initialized
INFO - 2018-08-03 02:43:59 --> Router Class Initialized
INFO - 2018-08-03 02:43:59 --> Output Class Initialized
DEBUG - 2018-08-03 02:43:59 --> UTF-8 Support Enabled
INFO - 2018-08-03 02:43:59 --> Security Class Initialized
INFO - 2018-08-03 02:43:59 --> Utf8 Class Initialized
DEBUG - 2018-08-03 02:43:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 02:43:59 --> Input Class Initialized
INFO - 2018-08-03 02:43:59 --> URI Class Initialized
INFO - 2018-08-03 02:43:59 --> Language Class Initialized
ERROR - 2018-08-03 02:43:59 --> 404 Page Not Found: /index
INFO - 2018-08-03 02:43:59 --> Router Class Initialized
INFO - 2018-08-03 02:44:00 --> Output Class Initialized
INFO - 2018-08-03 02:44:00 --> Security Class Initialized
DEBUG - 2018-08-03 02:44:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 02:44:00 --> Config Class Initialized
INFO - 2018-08-03 02:44:00 --> Hooks Class Initialized
INFO - 2018-08-03 02:44:00 --> Input Class Initialized
DEBUG - 2018-08-03 02:44:00 --> UTF-8 Support Enabled
INFO - 2018-08-03 02:44:00 --> Language Class Initialized
INFO - 2018-08-03 02:44:00 --> Utf8 Class Initialized
INFO - 2018-08-03 02:44:00 --> Language Class Initialized
INFO - 2018-08-03 02:44:00 --> URI Class Initialized
INFO - 2018-08-03 02:44:00 --> Config Class Initialized
INFO - 2018-08-03 02:44:00 --> Loader Class Initialized
INFO - 2018-08-03 02:44:00 --> Router Class Initialized
DEBUG - 2018-08-03 02:44:00 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-03 02:44:00 --> Output Class Initialized
INFO - 2018-08-03 02:44:00 --> Helper loaded: url_helper
INFO - 2018-08-03 02:44:00 --> Security Class Initialized
INFO - 2018-08-03 02:44:00 --> Helper loaded: form_helper
DEBUG - 2018-08-03 02:44:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 02:44:00 --> Helper loaded: date_helper
INFO - 2018-08-03 02:44:00 --> Helper loaded: util_helper
INFO - 2018-08-03 02:44:00 --> Helper loaded: text_helper
INFO - 2018-08-03 02:44:00 --> Helper loaded: string_helper
INFO - 2018-08-03 02:44:00 --> Input Class Initialized
INFO - 2018-08-03 02:44:00 --> Database Driver Class Initialized
INFO - 2018-08-03 02:44:00 --> Language Class Initialized
DEBUG - 2018-08-03 02:44:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 02:44:00 --> Session: Class initialized using 'files' driver.
ERROR - 2018-08-03 02:44:00 --> 404 Page Not Found: /index
INFO - 2018-08-03 02:44:00 --> Email Class Initialized
INFO - 2018-08-03 02:44:00 --> Config Class Initialized
INFO - 2018-08-03 02:44:00 --> Hooks Class Initialized
INFO - 2018-08-03 02:44:00 --> Controller Class Initialized
DEBUG - 2018-08-03 02:44:00 --> Home MX_Controller Initialized
DEBUG - 2018-08-03 02:44:00 --> UTF-8 Support Enabled
DEBUG - 2018-08-03 02:44:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-08-03 02:44:00 --> Utf8 Class Initialized
INFO - 2018-08-03 02:44:00 --> URI Class Initialized
DEBUG - 2018-08-03 02:44:00 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-03 02:44:00 --> Login MX_Controller Initialized
INFO - 2018-08-03 02:44:00 --> Router Class Initialized
INFO - 2018-08-03 02:44:00 --> Language file loaded: language/english/data_lang.php
INFO - 2018-08-03 02:44:00 --> Output Class Initialized
DEBUG - 2018-08-03 02:44:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-03 02:44:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-03 02:44:00 --> Security Class Initialized
DEBUG - 2018-08-03 02:44:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 02:44:00 --> Input Class Initialized
INFO - 2018-08-03 02:44:00 --> Language Class Initialized
ERROR - 2018-08-03 02:44:00 --> 404 Page Not Found: /index
INFO - 2018-08-03 02:44:18 --> Config Class Initialized
INFO - 2018-08-03 02:44:18 --> Hooks Class Initialized
DEBUG - 2018-08-03 02:44:18 --> UTF-8 Support Enabled
INFO - 2018-08-03 02:44:18 --> Utf8 Class Initialized
INFO - 2018-08-03 02:44:18 --> URI Class Initialized
INFO - 2018-08-03 02:44:18 --> Router Class Initialized
INFO - 2018-08-03 02:44:18 --> Output Class Initialized
INFO - 2018-08-03 02:44:18 --> Security Class Initialized
DEBUG - 2018-08-03 02:44:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 02:44:18 --> Input Class Initialized
INFO - 2018-08-03 02:44:18 --> Language Class Initialized
INFO - 2018-08-03 02:44:18 --> Language Class Initialized
INFO - 2018-08-03 02:44:18 --> Config Class Initialized
INFO - 2018-08-03 02:44:18 --> Loader Class Initialized
DEBUG - 2018-08-03 02:44:18 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-03 02:44:18 --> Helper loaded: url_helper
INFO - 2018-08-03 02:44:18 --> Helper loaded: form_helper
INFO - 2018-08-03 02:44:18 --> Helper loaded: date_helper
INFO - 2018-08-03 02:44:18 --> Helper loaded: util_helper
INFO - 2018-08-03 02:44:18 --> Helper loaded: text_helper
INFO - 2018-08-03 02:44:18 --> Helper loaded: string_helper
INFO - 2018-08-03 02:44:18 --> Database Driver Class Initialized
DEBUG - 2018-08-03 02:44:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 02:44:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-03 02:44:19 --> Email Class Initialized
INFO - 2018-08-03 02:44:19 --> Controller Class Initialized
DEBUG - 2018-08-03 02:44:19 --> Admin MX_Controller Initialized
INFO - 2018-08-03 02:44:19 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-03 02:44:19 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-03 02:44:19 --> Login MX_Controller Initialized
DEBUG - 2018-08-03 02:44:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-03 02:44:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-03 02:44:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-08-03 02:44:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-08-03 02:44:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-08-03 02:44:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-08-03 02:44:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-08-03 02:44:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/dashboard.php
INFO - 2018-08-03 02:44:19 --> Final output sent to browser
DEBUG - 2018-08-03 02:44:19 --> Total execution time: 0.8026
INFO - 2018-08-03 02:44:20 --> Config Class Initialized
INFO - 2018-08-03 02:44:20 --> Hooks Class Initialized
DEBUG - 2018-08-03 02:44:20 --> UTF-8 Support Enabled
INFO - 2018-08-03 02:44:20 --> Utf8 Class Initialized
INFO - 2018-08-03 02:44:20 --> URI Class Initialized
INFO - 2018-08-03 02:44:20 --> Router Class Initialized
INFO - 2018-08-03 02:44:20 --> Output Class Initialized
INFO - 2018-08-03 02:44:20 --> Security Class Initialized
DEBUG - 2018-08-03 02:44:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 02:44:20 --> Input Class Initialized
INFO - 2018-08-03 02:44:20 --> Language Class Initialized
INFO - 2018-08-03 02:44:20 --> Language Class Initialized
INFO - 2018-08-03 02:44:20 --> Config Class Initialized
INFO - 2018-08-03 02:44:20 --> Loader Class Initialized
DEBUG - 2018-08-03 02:44:20 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-03 02:44:20 --> Helper loaded: url_helper
INFO - 2018-08-03 02:44:20 --> Helper loaded: form_helper
INFO - 2018-08-03 02:44:20 --> Helper loaded: date_helper
INFO - 2018-08-03 02:44:20 --> Helper loaded: util_helper
INFO - 2018-08-03 02:44:20 --> Helper loaded: text_helper
INFO - 2018-08-03 02:44:20 --> Helper loaded: string_helper
INFO - 2018-08-03 02:44:20 --> Database Driver Class Initialized
DEBUG - 2018-08-03 02:44:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 02:44:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-03 02:44:20 --> Email Class Initialized
INFO - 2018-08-03 02:44:20 --> Controller Class Initialized
DEBUG - 2018-08-03 02:44:21 --> Home MX_Controller Initialized
DEBUG - 2018-08-03 02:44:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-03 02:44:21 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-03 02:44:21 --> Login MX_Controller Initialized
INFO - 2018-08-03 02:44:21 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-03 02:44:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-03 02:44:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-03 02:46:02 --> Config Class Initialized
INFO - 2018-08-03 02:46:02 --> Hooks Class Initialized
DEBUG - 2018-08-03 02:46:02 --> UTF-8 Support Enabled
INFO - 2018-08-03 02:46:02 --> Utf8 Class Initialized
INFO - 2018-08-03 02:46:02 --> URI Class Initialized
INFO - 2018-08-03 02:46:02 --> Router Class Initialized
INFO - 2018-08-03 02:46:02 --> Output Class Initialized
INFO - 2018-08-03 02:46:02 --> Security Class Initialized
DEBUG - 2018-08-03 02:46:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 02:46:02 --> Input Class Initialized
INFO - 2018-08-03 02:46:02 --> Language Class Initialized
INFO - 2018-08-03 02:46:02 --> Language Class Initialized
INFO - 2018-08-03 02:46:02 --> Config Class Initialized
INFO - 2018-08-03 02:46:02 --> Loader Class Initialized
DEBUG - 2018-08-03 02:46:02 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-03 02:46:02 --> Helper loaded: url_helper
INFO - 2018-08-03 02:46:02 --> Helper loaded: form_helper
INFO - 2018-08-03 02:46:03 --> Helper loaded: date_helper
INFO - 2018-08-03 02:46:03 --> Helper loaded: util_helper
INFO - 2018-08-03 02:46:03 --> Helper loaded: text_helper
INFO - 2018-08-03 02:46:03 --> Helper loaded: string_helper
INFO - 2018-08-03 02:46:03 --> Database Driver Class Initialized
DEBUG - 2018-08-03 02:46:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 02:46:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-03 02:46:03 --> Email Class Initialized
INFO - 2018-08-03 02:46:03 --> Controller Class Initialized
DEBUG - 2018-08-03 02:46:03 --> Admin MX_Controller Initialized
INFO - 2018-08-03 02:46:03 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-03 02:46:03 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-03 02:46:03 --> Login MX_Controller Initialized
DEBUG - 2018-08-03 02:46:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-03 02:46:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-03 02:46:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-08-03 02:46:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-08-03 02:46:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-08-03 02:46:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-08-03 02:46:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-08-03 02:46:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/dashboard.php
INFO - 2018-08-03 02:46:03 --> Final output sent to browser
DEBUG - 2018-08-03 02:46:03 --> Total execution time: 0.7471
INFO - 2018-08-03 02:46:04 --> Config Class Initialized
INFO - 2018-08-03 02:46:04 --> Hooks Class Initialized
DEBUG - 2018-08-03 02:46:04 --> UTF-8 Support Enabled
INFO - 2018-08-03 02:46:04 --> Utf8 Class Initialized
INFO - 2018-08-03 02:46:04 --> URI Class Initialized
INFO - 2018-08-03 02:46:04 --> Router Class Initialized
INFO - 2018-08-03 02:46:04 --> Output Class Initialized
INFO - 2018-08-03 02:46:04 --> Security Class Initialized
DEBUG - 2018-08-03 02:46:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 02:46:04 --> Input Class Initialized
INFO - 2018-08-03 02:46:05 --> Language Class Initialized
INFO - 2018-08-03 02:46:05 --> Language Class Initialized
INFO - 2018-08-03 02:46:05 --> Config Class Initialized
INFO - 2018-08-03 02:46:05 --> Loader Class Initialized
DEBUG - 2018-08-03 02:46:05 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-03 02:46:05 --> Helper loaded: url_helper
INFO - 2018-08-03 02:46:05 --> Helper loaded: form_helper
INFO - 2018-08-03 02:46:05 --> Helper loaded: date_helper
INFO - 2018-08-03 02:46:05 --> Helper loaded: util_helper
INFO - 2018-08-03 02:46:05 --> Helper loaded: text_helper
INFO - 2018-08-03 02:46:05 --> Helper loaded: string_helper
INFO - 2018-08-03 02:46:05 --> Database Driver Class Initialized
DEBUG - 2018-08-03 02:46:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 02:46:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-03 02:46:05 --> Email Class Initialized
INFO - 2018-08-03 02:46:05 --> Controller Class Initialized
DEBUG - 2018-08-03 02:46:05 --> Home MX_Controller Initialized
DEBUG - 2018-08-03 02:46:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-03 02:46:05 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-03 02:46:05 --> Login MX_Controller Initialized
INFO - 2018-08-03 02:46:05 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-03 02:46:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-03 02:46:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-03 02:46:45 --> Config Class Initialized
INFO - 2018-08-03 02:46:45 --> Hooks Class Initialized
DEBUG - 2018-08-03 02:46:45 --> UTF-8 Support Enabled
INFO - 2018-08-03 02:46:45 --> Utf8 Class Initialized
INFO - 2018-08-03 02:46:46 --> URI Class Initialized
INFO - 2018-08-03 02:46:46 --> Router Class Initialized
INFO - 2018-08-03 02:46:46 --> Output Class Initialized
INFO - 2018-08-03 02:46:46 --> Security Class Initialized
DEBUG - 2018-08-03 02:46:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 02:46:46 --> Input Class Initialized
INFO - 2018-08-03 02:46:46 --> Language Class Initialized
INFO - 2018-08-03 02:46:46 --> Language Class Initialized
INFO - 2018-08-03 02:46:46 --> Config Class Initialized
INFO - 2018-08-03 02:46:46 --> Loader Class Initialized
DEBUG - 2018-08-03 02:46:46 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-03 02:46:46 --> Helper loaded: url_helper
INFO - 2018-08-03 02:46:46 --> Helper loaded: form_helper
INFO - 2018-08-03 02:46:46 --> Helper loaded: date_helper
INFO - 2018-08-03 02:46:46 --> Helper loaded: util_helper
INFO - 2018-08-03 02:46:46 --> Helper loaded: text_helper
INFO - 2018-08-03 02:46:46 --> Helper loaded: string_helper
INFO - 2018-08-03 02:46:46 --> Database Driver Class Initialized
DEBUG - 2018-08-03 02:46:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 02:46:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-03 02:46:46 --> Email Class Initialized
INFO - 2018-08-03 02:46:46 --> Controller Class Initialized
DEBUG - 2018-08-03 02:46:46 --> Admin MX_Controller Initialized
INFO - 2018-08-03 02:46:46 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-03 02:46:46 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-03 02:46:46 --> Login MX_Controller Initialized
DEBUG - 2018-08-03 02:46:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-03 02:46:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-03 02:46:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-08-03 02:46:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-08-03 02:46:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-08-03 02:46:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-08-03 02:46:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-08-03 02:46:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/dashboard.php
INFO - 2018-08-03 02:46:46 --> Final output sent to browser
DEBUG - 2018-08-03 02:46:46 --> Total execution time: 0.7225
INFO - 2018-08-03 02:46:47 --> Config Class Initialized
INFO - 2018-08-03 02:46:47 --> Hooks Class Initialized
DEBUG - 2018-08-03 02:46:47 --> UTF-8 Support Enabled
INFO - 2018-08-03 02:46:47 --> Utf8 Class Initialized
INFO - 2018-08-03 02:46:47 --> URI Class Initialized
INFO - 2018-08-03 02:46:47 --> Router Class Initialized
INFO - 2018-08-03 02:46:47 --> Output Class Initialized
INFO - 2018-08-03 02:46:47 --> Security Class Initialized
DEBUG - 2018-08-03 02:46:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 02:46:47 --> Input Class Initialized
INFO - 2018-08-03 02:46:47 --> Language Class Initialized
INFO - 2018-08-03 02:46:47 --> Language Class Initialized
INFO - 2018-08-03 02:46:47 --> Config Class Initialized
INFO - 2018-08-03 02:46:47 --> Loader Class Initialized
DEBUG - 2018-08-03 02:46:47 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-03 02:46:47 --> Helper loaded: url_helper
INFO - 2018-08-03 02:46:47 --> Helper loaded: form_helper
INFO - 2018-08-03 02:46:48 --> Helper loaded: date_helper
INFO - 2018-08-03 02:46:48 --> Helper loaded: util_helper
INFO - 2018-08-03 02:46:48 --> Helper loaded: text_helper
INFO - 2018-08-03 02:46:48 --> Helper loaded: string_helper
INFO - 2018-08-03 02:46:48 --> Database Driver Class Initialized
DEBUG - 2018-08-03 02:46:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 02:46:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-03 02:46:48 --> Email Class Initialized
INFO - 2018-08-03 02:46:48 --> Controller Class Initialized
DEBUG - 2018-08-03 02:46:48 --> Home MX_Controller Initialized
DEBUG - 2018-08-03 02:46:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-03 02:46:48 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-03 02:46:48 --> Login MX_Controller Initialized
INFO - 2018-08-03 02:46:48 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-03 02:46:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-03 02:46:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-03 02:47:08 --> Config Class Initialized
INFO - 2018-08-03 02:47:08 --> Hooks Class Initialized
DEBUG - 2018-08-03 02:47:08 --> UTF-8 Support Enabled
INFO - 2018-08-03 02:47:08 --> Utf8 Class Initialized
INFO - 2018-08-03 02:47:08 --> URI Class Initialized
INFO - 2018-08-03 02:47:08 --> Router Class Initialized
INFO - 2018-08-03 02:47:08 --> Output Class Initialized
INFO - 2018-08-03 02:47:08 --> Security Class Initialized
DEBUG - 2018-08-03 02:47:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 02:47:08 --> Input Class Initialized
INFO - 2018-08-03 02:47:08 --> Language Class Initialized
INFO - 2018-08-03 02:47:08 --> Language Class Initialized
INFO - 2018-08-03 02:47:08 --> Config Class Initialized
INFO - 2018-08-03 02:47:08 --> Loader Class Initialized
DEBUG - 2018-08-03 02:47:08 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-03 02:47:08 --> Helper loaded: url_helper
INFO - 2018-08-03 02:47:08 --> Helper loaded: form_helper
INFO - 2018-08-03 02:47:08 --> Helper loaded: date_helper
INFO - 2018-08-03 02:47:08 --> Helper loaded: util_helper
INFO - 2018-08-03 02:47:08 --> Helper loaded: text_helper
INFO - 2018-08-03 02:47:08 --> Helper loaded: string_helper
INFO - 2018-08-03 02:47:08 --> Database Driver Class Initialized
DEBUG - 2018-08-03 02:47:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 02:47:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-03 02:47:08 --> Email Class Initialized
INFO - 2018-08-03 02:47:08 --> Controller Class Initialized
DEBUG - 2018-08-03 02:47:08 --> Home MX_Controller Initialized
DEBUG - 2018-08-03 02:47:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-03 02:47:08 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-03 02:47:08 --> Login MX_Controller Initialized
INFO - 2018-08-03 02:47:08 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-03 02:47:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-03 02:47:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-03 02:47:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-08-03 02:47:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-08-03 02:47:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-08-03 02:47:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-08-03 02:47:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-08-03 02:47:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-08-03 02:47:09 --> Final output sent to browser
DEBUG - 2018-08-03 02:47:09 --> Total execution time: 0.8413
INFO - 2018-08-03 02:47:09 --> Config Class Initialized
INFO - 2018-08-03 02:47:09 --> Hooks Class Initialized
DEBUG - 2018-08-03 02:47:09 --> UTF-8 Support Enabled
INFO - 2018-08-03 02:47:09 --> Utf8 Class Initialized
INFO - 2018-08-03 02:47:09 --> Config Class Initialized
INFO - 2018-08-03 02:47:09 --> Hooks Class Initialized
INFO - 2018-08-03 02:47:09 --> URI Class Initialized
DEBUG - 2018-08-03 02:47:09 --> UTF-8 Support Enabled
INFO - 2018-08-03 02:47:09 --> Router Class Initialized
INFO - 2018-08-03 02:47:09 --> Utf8 Class Initialized
INFO - 2018-08-03 02:47:09 --> URI Class Initialized
INFO - 2018-08-03 02:47:09 --> Router Class Initialized
INFO - 2018-08-03 02:47:09 --> Output Class Initialized
INFO - 2018-08-03 02:47:09 --> Security Class Initialized
DEBUG - 2018-08-03 02:47:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 02:47:09 --> Input Class Initialized
INFO - 2018-08-03 02:47:09 --> Output Class Initialized
INFO - 2018-08-03 02:47:09 --> Security Class Initialized
INFO - 2018-08-03 02:47:09 --> Language Class Initialized
INFO - 2018-08-03 02:47:10 --> Language Class Initialized
DEBUG - 2018-08-03 02:47:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 02:47:10 --> Input Class Initialized
INFO - 2018-08-03 02:47:10 --> Config Class Initialized
INFO - 2018-08-03 02:47:10 --> Language Class Initialized
INFO - 2018-08-03 02:47:10 --> Loader Class Initialized
ERROR - 2018-08-03 02:47:10 --> 404 Page Not Found: /index
DEBUG - 2018-08-03 02:47:10 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-03 02:47:10 --> Helper loaded: url_helper
INFO - 2018-08-03 02:47:10 --> Helper loaded: form_helper
INFO - 2018-08-03 02:47:10 --> Config Class Initialized
INFO - 2018-08-03 02:47:10 --> Helper loaded: date_helper
INFO - 2018-08-03 02:47:10 --> Hooks Class Initialized
INFO - 2018-08-03 02:47:10 --> Helper loaded: util_helper
DEBUG - 2018-08-03 02:47:10 --> UTF-8 Support Enabled
INFO - 2018-08-03 02:47:10 --> Helper loaded: text_helper
INFO - 2018-08-03 02:47:10 --> Utf8 Class Initialized
INFO - 2018-08-03 02:47:10 --> URI Class Initialized
INFO - 2018-08-03 02:47:10 --> Helper loaded: string_helper
INFO - 2018-08-03 02:47:10 --> Router Class Initialized
INFO - 2018-08-03 02:47:10 --> Database Driver Class Initialized
INFO - 2018-08-03 02:47:10 --> Output Class Initialized
DEBUG - 2018-08-03 02:47:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 02:47:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-03 02:47:10 --> Security Class Initialized
DEBUG - 2018-08-03 02:47:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 02:47:10 --> Email Class Initialized
INFO - 2018-08-03 02:47:10 --> Controller Class Initialized
INFO - 2018-08-03 02:47:10 --> Input Class Initialized
DEBUG - 2018-08-03 02:47:10 --> Home MX_Controller Initialized
INFO - 2018-08-03 02:47:10 --> Language Class Initialized
ERROR - 2018-08-03 02:47:10 --> 404 Page Not Found: /index
DEBUG - 2018-08-03 02:47:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-03 02:47:10 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
INFO - 2018-08-03 02:47:10 --> Config Class Initialized
DEBUG - 2018-08-03 02:47:10 --> Login MX_Controller Initialized
INFO - 2018-08-03 02:47:10 --> Hooks Class Initialized
INFO - 2018-08-03 02:47:10 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-03 02:47:10 --> UTF-8 Support Enabled
INFO - 2018-08-03 02:47:10 --> Utf8 Class Initialized
DEBUG - 2018-08-03 02:47:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-08-03 02:47:10 --> URI Class Initialized
DEBUG - 2018-08-03 02:47:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-03 02:47:10 --> Router Class Initialized
INFO - 2018-08-03 02:47:10 --> Output Class Initialized
INFO - 2018-08-03 02:47:10 --> Security Class Initialized
DEBUG - 2018-08-03 02:47:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 02:47:10 --> Input Class Initialized
INFO - 2018-08-03 02:47:10 --> Language Class Initialized
ERROR - 2018-08-03 02:47:10 --> 404 Page Not Found: /index
INFO - 2018-08-03 02:47:30 --> Config Class Initialized
INFO - 2018-08-03 02:47:30 --> Hooks Class Initialized
DEBUG - 2018-08-03 02:47:30 --> UTF-8 Support Enabled
INFO - 2018-08-03 02:47:30 --> Utf8 Class Initialized
INFO - 2018-08-03 02:47:30 --> URI Class Initialized
INFO - 2018-08-03 02:47:30 --> Router Class Initialized
INFO - 2018-08-03 02:47:30 --> Output Class Initialized
INFO - 2018-08-03 02:47:30 --> Security Class Initialized
DEBUG - 2018-08-03 02:47:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 02:47:31 --> Input Class Initialized
INFO - 2018-08-03 02:47:31 --> Language Class Initialized
INFO - 2018-08-03 02:47:31 --> Language Class Initialized
INFO - 2018-08-03 02:47:31 --> Config Class Initialized
INFO - 2018-08-03 02:47:31 --> Loader Class Initialized
DEBUG - 2018-08-03 02:47:31 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-03 02:47:31 --> Helper loaded: url_helper
INFO - 2018-08-03 02:47:31 --> Helper loaded: form_helper
INFO - 2018-08-03 02:47:31 --> Helper loaded: date_helper
INFO - 2018-08-03 02:47:31 --> Helper loaded: util_helper
INFO - 2018-08-03 02:47:31 --> Helper loaded: text_helper
INFO - 2018-08-03 02:47:31 --> Helper loaded: string_helper
INFO - 2018-08-03 02:47:31 --> Database Driver Class Initialized
DEBUG - 2018-08-03 02:47:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 02:47:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-03 02:47:31 --> Email Class Initialized
INFO - 2018-08-03 02:47:31 --> Controller Class Initialized
DEBUG - 2018-08-03 02:47:31 --> Admin MX_Controller Initialized
INFO - 2018-08-03 02:47:31 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-03 02:47:31 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-03 02:47:31 --> Login MX_Controller Initialized
DEBUG - 2018-08-03 02:47:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-03 02:47:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-03 02:47:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-08-03 02:47:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-08-03 02:47:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-08-03 02:47:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-08-03 02:47:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-08-03 02:47:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/dashboard.php
INFO - 2018-08-03 02:47:31 --> Final output sent to browser
DEBUG - 2018-08-03 02:47:31 --> Total execution time: 0.7331
INFO - 2018-08-03 02:47:31 --> Config Class Initialized
INFO - 2018-08-03 02:47:31 --> Hooks Class Initialized
DEBUG - 2018-08-03 02:47:31 --> UTF-8 Support Enabled
INFO - 2018-08-03 02:47:31 --> Utf8 Class Initialized
INFO - 2018-08-03 02:47:31 --> URI Class Initialized
INFO - 2018-08-03 02:47:31 --> Router Class Initialized
INFO - 2018-08-03 02:47:31 --> Output Class Initialized
INFO - 2018-08-03 02:47:31 --> Security Class Initialized
DEBUG - 2018-08-03 02:47:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 02:47:31 --> Input Class Initialized
INFO - 2018-08-03 02:47:31 --> Language Class Initialized
INFO - 2018-08-03 02:47:31 --> Language Class Initialized
INFO - 2018-08-03 02:47:31 --> Config Class Initialized
INFO - 2018-08-03 02:47:31 --> Loader Class Initialized
DEBUG - 2018-08-03 02:47:31 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-03 02:47:31 --> Helper loaded: url_helper
INFO - 2018-08-03 02:47:32 --> Helper loaded: form_helper
INFO - 2018-08-03 02:47:32 --> Helper loaded: date_helper
INFO - 2018-08-03 02:47:32 --> Helper loaded: util_helper
INFO - 2018-08-03 02:47:32 --> Helper loaded: text_helper
INFO - 2018-08-03 02:47:32 --> Helper loaded: string_helper
INFO - 2018-08-03 02:47:32 --> Database Driver Class Initialized
DEBUG - 2018-08-03 02:47:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 02:47:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-03 02:47:32 --> Email Class Initialized
INFO - 2018-08-03 02:47:32 --> Controller Class Initialized
DEBUG - 2018-08-03 02:47:32 --> Admin MX_Controller Initialized
INFO - 2018-08-03 02:47:32 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-03 02:47:32 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-03 02:47:32 --> Login MX_Controller Initialized
DEBUG - 2018-08-03 02:47:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-03 02:47:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-03 02:47:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-08-03 02:47:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-08-03 02:47:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-08-03 02:47:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-08-03 02:47:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-08-03 02:47:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/dashboard.php
INFO - 2018-08-03 02:47:32 --> Final output sent to browser
DEBUG - 2018-08-03 02:47:32 --> Total execution time: 0.8026
INFO - 2018-08-03 02:47:32 --> Config Class Initialized
INFO - 2018-08-03 02:47:32 --> Hooks Class Initialized
DEBUG - 2018-08-03 02:47:33 --> UTF-8 Support Enabled
INFO - 2018-08-03 02:47:33 --> Utf8 Class Initialized
INFO - 2018-08-03 02:47:33 --> URI Class Initialized
INFO - 2018-08-03 02:47:33 --> Router Class Initialized
INFO - 2018-08-03 02:47:33 --> Output Class Initialized
INFO - 2018-08-03 02:47:33 --> Security Class Initialized
DEBUG - 2018-08-03 02:47:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 02:47:33 --> Input Class Initialized
INFO - 2018-08-03 02:47:33 --> Language Class Initialized
INFO - 2018-08-03 02:47:33 --> Language Class Initialized
INFO - 2018-08-03 02:47:33 --> Config Class Initialized
INFO - 2018-08-03 02:47:33 --> Loader Class Initialized
DEBUG - 2018-08-03 02:47:33 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-03 02:47:33 --> Helper loaded: url_helper
INFO - 2018-08-03 02:47:33 --> Helper loaded: form_helper
INFO - 2018-08-03 02:47:33 --> Helper loaded: date_helper
INFO - 2018-08-03 02:47:33 --> Helper loaded: util_helper
INFO - 2018-08-03 02:47:33 --> Helper loaded: text_helper
INFO - 2018-08-03 02:47:33 --> Helper loaded: string_helper
INFO - 2018-08-03 02:47:33 --> Database Driver Class Initialized
DEBUG - 2018-08-03 02:47:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 02:47:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-03 02:47:33 --> Email Class Initialized
INFO - 2018-08-03 02:47:33 --> Controller Class Initialized
DEBUG - 2018-08-03 02:47:33 --> Admin MX_Controller Initialized
INFO - 2018-08-03 02:47:33 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-03 02:47:33 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-03 02:47:33 --> Login MX_Controller Initialized
DEBUG - 2018-08-03 02:47:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-03 02:47:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-03 02:47:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-08-03 02:47:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-08-03 02:47:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-08-03 02:47:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-08-03 02:47:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-08-03 02:47:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/dashboard.php
INFO - 2018-08-03 02:47:33 --> Final output sent to browser
DEBUG - 2018-08-03 02:47:34 --> Total execution time: 1.0825
INFO - 2018-08-03 02:47:34 --> Config Class Initialized
INFO - 2018-08-03 02:47:34 --> Hooks Class Initialized
DEBUG - 2018-08-03 02:47:34 --> UTF-8 Support Enabled
INFO - 2018-08-03 02:47:35 --> Utf8 Class Initialized
INFO - 2018-08-03 02:47:35 --> URI Class Initialized
INFO - 2018-08-03 02:47:35 --> Router Class Initialized
INFO - 2018-08-03 02:47:35 --> Output Class Initialized
INFO - 2018-08-03 02:47:35 --> Security Class Initialized
DEBUG - 2018-08-03 02:47:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 02:47:35 --> Input Class Initialized
INFO - 2018-08-03 02:47:35 --> Language Class Initialized
INFO - 2018-08-03 02:47:35 --> Language Class Initialized
INFO - 2018-08-03 02:47:35 --> Config Class Initialized
INFO - 2018-08-03 02:47:35 --> Loader Class Initialized
DEBUG - 2018-08-03 02:47:35 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-03 02:47:35 --> Helper loaded: url_helper
INFO - 2018-08-03 02:47:35 --> Helper loaded: form_helper
INFO - 2018-08-03 02:47:35 --> Helper loaded: date_helper
INFO - 2018-08-03 02:47:35 --> Helper loaded: util_helper
INFO - 2018-08-03 02:47:35 --> Helper loaded: text_helper
INFO - 2018-08-03 02:47:35 --> Helper loaded: string_helper
INFO - 2018-08-03 02:47:35 --> Database Driver Class Initialized
DEBUG - 2018-08-03 02:47:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 02:47:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-03 02:47:35 --> Email Class Initialized
INFO - 2018-08-03 02:47:35 --> Controller Class Initialized
DEBUG - 2018-08-03 02:47:35 --> Home MX_Controller Initialized
DEBUG - 2018-08-03 02:47:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-03 02:47:35 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-03 02:47:35 --> Login MX_Controller Initialized
INFO - 2018-08-03 02:47:35 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-03 02:47:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-03 02:47:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-03 02:51:58 --> Config Class Initialized
INFO - 2018-08-03 02:51:58 --> Hooks Class Initialized
DEBUG - 2018-08-03 02:51:58 --> UTF-8 Support Enabled
INFO - 2018-08-03 02:51:58 --> Utf8 Class Initialized
INFO - 2018-08-03 02:51:58 --> URI Class Initialized
INFO - 2018-08-03 02:51:58 --> Router Class Initialized
INFO - 2018-08-03 02:51:58 --> Output Class Initialized
INFO - 2018-08-03 02:51:58 --> Security Class Initialized
DEBUG - 2018-08-03 02:51:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 02:51:58 --> Input Class Initialized
INFO - 2018-08-03 02:51:58 --> Language Class Initialized
INFO - 2018-08-03 02:51:58 --> Language Class Initialized
INFO - 2018-08-03 02:51:59 --> Config Class Initialized
INFO - 2018-08-03 02:51:59 --> Loader Class Initialized
DEBUG - 2018-08-03 02:51:59 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-03 02:51:59 --> Helper loaded: url_helper
INFO - 2018-08-03 02:51:59 --> Helper loaded: form_helper
INFO - 2018-08-03 02:51:59 --> Helper loaded: date_helper
INFO - 2018-08-03 02:51:59 --> Helper loaded: util_helper
INFO - 2018-08-03 02:51:59 --> Helper loaded: text_helper
INFO - 2018-08-03 02:51:59 --> Helper loaded: string_helper
INFO - 2018-08-03 02:51:59 --> Database Driver Class Initialized
DEBUG - 2018-08-03 02:51:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 02:51:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-03 02:51:59 --> Email Class Initialized
INFO - 2018-08-03 02:51:59 --> Controller Class Initialized
DEBUG - 2018-08-03 02:51:59 --> Admin MX_Controller Initialized
INFO - 2018-08-03 02:51:59 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-03 02:51:59 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-03 02:51:59 --> Login MX_Controller Initialized
DEBUG - 2018-08-03 02:51:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-03 02:51:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-03 02:51:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-08-03 02:51:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-08-03 02:51:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-08-03 02:51:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-08-03 02:51:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-08-03 02:51:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/dashboard.php
INFO - 2018-08-03 02:51:59 --> Final output sent to browser
DEBUG - 2018-08-03 02:51:59 --> Total execution time: 0.7178
INFO - 2018-08-03 02:52:00 --> Config Class Initialized
INFO - 2018-08-03 02:52:00 --> Hooks Class Initialized
DEBUG - 2018-08-03 02:52:00 --> UTF-8 Support Enabled
INFO - 2018-08-03 02:52:00 --> Utf8 Class Initialized
INFO - 2018-08-03 02:52:00 --> URI Class Initialized
INFO - 2018-08-03 02:52:00 --> Router Class Initialized
INFO - 2018-08-03 02:52:00 --> Output Class Initialized
INFO - 2018-08-03 02:52:00 --> Security Class Initialized
DEBUG - 2018-08-03 02:52:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 02:52:00 --> Input Class Initialized
INFO - 2018-08-03 02:52:00 --> Language Class Initialized
INFO - 2018-08-03 02:52:00 --> Language Class Initialized
INFO - 2018-08-03 02:52:00 --> Config Class Initialized
INFO - 2018-08-03 02:52:00 --> Loader Class Initialized
DEBUG - 2018-08-03 02:52:01 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-03 02:52:01 --> Helper loaded: url_helper
INFO - 2018-08-03 02:52:01 --> Helper loaded: form_helper
INFO - 2018-08-03 02:52:01 --> Helper loaded: date_helper
INFO - 2018-08-03 02:52:01 --> Helper loaded: util_helper
INFO - 2018-08-03 02:52:01 --> Helper loaded: text_helper
INFO - 2018-08-03 02:52:01 --> Helper loaded: string_helper
INFO - 2018-08-03 02:52:01 --> Database Driver Class Initialized
DEBUG - 2018-08-03 02:52:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 02:52:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-03 02:52:01 --> Email Class Initialized
INFO - 2018-08-03 02:52:01 --> Controller Class Initialized
DEBUG - 2018-08-03 02:52:01 --> Home MX_Controller Initialized
DEBUG - 2018-08-03 02:52:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-03 02:52:01 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-03 02:52:01 --> Login MX_Controller Initialized
INFO - 2018-08-03 02:52:01 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-03 02:52:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-03 02:52:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-03 02:52:20 --> Config Class Initialized
INFO - 2018-08-03 02:52:20 --> Hooks Class Initialized
DEBUG - 2018-08-03 02:52:20 --> UTF-8 Support Enabled
INFO - 2018-08-03 02:52:20 --> Utf8 Class Initialized
INFO - 2018-08-03 02:52:20 --> URI Class Initialized
INFO - 2018-08-03 02:52:20 --> Router Class Initialized
INFO - 2018-08-03 02:52:20 --> Output Class Initialized
INFO - 2018-08-03 02:52:20 --> Security Class Initialized
DEBUG - 2018-08-03 02:52:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 02:52:20 --> Input Class Initialized
INFO - 2018-08-03 02:52:20 --> Language Class Initialized
INFO - 2018-08-03 02:52:20 --> Language Class Initialized
INFO - 2018-08-03 02:52:20 --> Config Class Initialized
INFO - 2018-08-03 02:52:20 --> Loader Class Initialized
DEBUG - 2018-08-03 02:52:20 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-03 02:52:20 --> Helper loaded: url_helper
INFO - 2018-08-03 02:52:20 --> Helper loaded: form_helper
INFO - 2018-08-03 02:52:20 --> Helper loaded: date_helper
INFO - 2018-08-03 02:52:20 --> Helper loaded: util_helper
INFO - 2018-08-03 02:52:20 --> Helper loaded: text_helper
INFO - 2018-08-03 02:52:20 --> Helper loaded: string_helper
INFO - 2018-08-03 02:52:20 --> Database Driver Class Initialized
DEBUG - 2018-08-03 02:52:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 02:52:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-03 02:52:20 --> Email Class Initialized
INFO - 2018-08-03 02:52:20 --> Controller Class Initialized
DEBUG - 2018-08-03 02:52:20 --> Admin MX_Controller Initialized
INFO - 2018-08-03 02:52:20 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-03 02:52:20 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-03 02:52:20 --> Login MX_Controller Initialized
DEBUG - 2018-08-03 02:52:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-03 02:52:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-03 02:52:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-08-03 02:52:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-08-03 02:52:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-08-03 02:52:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-08-03 02:52:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-08-03 02:52:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/dashboard.php
INFO - 2018-08-03 02:52:20 --> Final output sent to browser
DEBUG - 2018-08-03 02:52:20 --> Total execution time: 0.8244
INFO - 2018-08-03 02:52:21 --> Config Class Initialized
INFO - 2018-08-03 02:52:21 --> Hooks Class Initialized
DEBUG - 2018-08-03 02:52:21 --> UTF-8 Support Enabled
INFO - 2018-08-03 02:52:21 --> Utf8 Class Initialized
INFO - 2018-08-03 02:52:21 --> URI Class Initialized
INFO - 2018-08-03 02:52:21 --> Router Class Initialized
INFO - 2018-08-03 02:52:21 --> Output Class Initialized
INFO - 2018-08-03 02:52:21 --> Security Class Initialized
DEBUG - 2018-08-03 02:52:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 02:52:21 --> Input Class Initialized
INFO - 2018-08-03 02:52:21 --> Language Class Initialized
INFO - 2018-08-03 02:52:22 --> Language Class Initialized
INFO - 2018-08-03 02:52:22 --> Config Class Initialized
INFO - 2018-08-03 02:52:22 --> Loader Class Initialized
DEBUG - 2018-08-03 02:52:22 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-03 02:52:22 --> Helper loaded: url_helper
INFO - 2018-08-03 02:52:22 --> Helper loaded: form_helper
INFO - 2018-08-03 02:52:22 --> Helper loaded: date_helper
INFO - 2018-08-03 02:52:22 --> Helper loaded: util_helper
INFO - 2018-08-03 02:52:22 --> Helper loaded: text_helper
INFO - 2018-08-03 02:52:22 --> Helper loaded: string_helper
INFO - 2018-08-03 02:52:22 --> Database Driver Class Initialized
DEBUG - 2018-08-03 02:52:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 02:52:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-03 02:52:22 --> Email Class Initialized
INFO - 2018-08-03 02:52:22 --> Controller Class Initialized
DEBUG - 2018-08-03 02:52:22 --> Home MX_Controller Initialized
DEBUG - 2018-08-03 02:52:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-03 02:52:22 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-03 02:52:22 --> Login MX_Controller Initialized
INFO - 2018-08-03 02:52:22 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-03 02:52:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-03 02:52:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-03 02:52:46 --> Config Class Initialized
INFO - 2018-08-03 02:52:46 --> Hooks Class Initialized
DEBUG - 2018-08-03 02:52:46 --> UTF-8 Support Enabled
INFO - 2018-08-03 02:52:46 --> Utf8 Class Initialized
INFO - 2018-08-03 02:52:46 --> URI Class Initialized
INFO - 2018-08-03 02:52:46 --> Router Class Initialized
INFO - 2018-08-03 02:52:46 --> Output Class Initialized
INFO - 2018-08-03 02:52:46 --> Security Class Initialized
DEBUG - 2018-08-03 02:52:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 02:52:46 --> Input Class Initialized
INFO - 2018-08-03 02:52:47 --> Language Class Initialized
INFO - 2018-08-03 02:52:47 --> Language Class Initialized
INFO - 2018-08-03 02:52:47 --> Config Class Initialized
INFO - 2018-08-03 02:52:47 --> Loader Class Initialized
DEBUG - 2018-08-03 02:52:47 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-03 02:52:47 --> Helper loaded: url_helper
INFO - 2018-08-03 02:52:47 --> Helper loaded: form_helper
INFO - 2018-08-03 02:52:47 --> Helper loaded: date_helper
INFO - 2018-08-03 02:52:47 --> Helper loaded: util_helper
INFO - 2018-08-03 02:52:47 --> Helper loaded: text_helper
INFO - 2018-08-03 02:52:47 --> Helper loaded: string_helper
INFO - 2018-08-03 02:52:47 --> Database Driver Class Initialized
DEBUG - 2018-08-03 02:52:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 02:52:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-03 02:52:47 --> Email Class Initialized
INFO - 2018-08-03 02:52:47 --> Controller Class Initialized
DEBUG - 2018-08-03 02:52:47 --> Admin MX_Controller Initialized
INFO - 2018-08-03 02:52:47 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-03 02:52:47 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-03 02:52:47 --> Login MX_Controller Initialized
DEBUG - 2018-08-03 02:52:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-03 02:52:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-03 02:52:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-08-03 02:52:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-08-03 02:52:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-08-03 02:52:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-08-03 02:52:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-08-03 02:52:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/dashboard.php
INFO - 2018-08-03 02:52:47 --> Final output sent to browser
DEBUG - 2018-08-03 02:52:47 --> Total execution time: 0.7953
INFO - 2018-08-03 02:52:48 --> Config Class Initialized
INFO - 2018-08-03 02:52:48 --> Hooks Class Initialized
DEBUG - 2018-08-03 02:52:48 --> UTF-8 Support Enabled
INFO - 2018-08-03 02:52:48 --> Utf8 Class Initialized
INFO - 2018-08-03 02:52:48 --> URI Class Initialized
INFO - 2018-08-03 02:52:48 --> Router Class Initialized
INFO - 2018-08-03 02:52:48 --> Output Class Initialized
INFO - 2018-08-03 02:52:48 --> Security Class Initialized
DEBUG - 2018-08-03 02:52:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 02:52:48 --> Input Class Initialized
INFO - 2018-08-03 02:52:48 --> Language Class Initialized
INFO - 2018-08-03 02:52:48 --> Language Class Initialized
INFO - 2018-08-03 02:52:49 --> Config Class Initialized
INFO - 2018-08-03 02:52:49 --> Loader Class Initialized
DEBUG - 2018-08-03 02:52:49 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-03 02:52:49 --> Helper loaded: url_helper
INFO - 2018-08-03 02:52:49 --> Helper loaded: form_helper
INFO - 2018-08-03 02:52:49 --> Helper loaded: date_helper
INFO - 2018-08-03 02:52:49 --> Helper loaded: util_helper
INFO - 2018-08-03 02:52:49 --> Helper loaded: text_helper
INFO - 2018-08-03 02:52:49 --> Helper loaded: string_helper
INFO - 2018-08-03 02:52:49 --> Database Driver Class Initialized
DEBUG - 2018-08-03 02:52:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 02:52:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-03 02:52:49 --> Email Class Initialized
INFO - 2018-08-03 02:52:49 --> Controller Class Initialized
DEBUG - 2018-08-03 02:52:49 --> Home MX_Controller Initialized
DEBUG - 2018-08-03 02:52:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-03 02:52:49 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-03 02:52:49 --> Login MX_Controller Initialized
INFO - 2018-08-03 02:52:49 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-03 02:52:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-03 02:52:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-03 02:53:01 --> Config Class Initialized
INFO - 2018-08-03 02:53:01 --> Hooks Class Initialized
DEBUG - 2018-08-03 02:53:01 --> UTF-8 Support Enabled
INFO - 2018-08-03 02:53:01 --> Utf8 Class Initialized
INFO - 2018-08-03 02:53:01 --> URI Class Initialized
INFO - 2018-08-03 02:53:01 --> Router Class Initialized
INFO - 2018-08-03 02:53:01 --> Output Class Initialized
INFO - 2018-08-03 02:53:01 --> Security Class Initialized
DEBUG - 2018-08-03 02:53:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 02:53:01 --> Input Class Initialized
INFO - 2018-08-03 02:53:01 --> Language Class Initialized
INFO - 2018-08-03 02:53:01 --> Language Class Initialized
INFO - 2018-08-03 02:53:01 --> Config Class Initialized
INFO - 2018-08-03 02:53:01 --> Loader Class Initialized
DEBUG - 2018-08-03 02:53:01 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-03 02:53:01 --> Helper loaded: url_helper
INFO - 2018-08-03 02:53:01 --> Helper loaded: form_helper
INFO - 2018-08-03 02:53:02 --> Helper loaded: date_helper
INFO - 2018-08-03 02:53:02 --> Helper loaded: util_helper
INFO - 2018-08-03 02:53:02 --> Helper loaded: text_helper
INFO - 2018-08-03 02:53:02 --> Helper loaded: string_helper
INFO - 2018-08-03 02:53:02 --> Database Driver Class Initialized
DEBUG - 2018-08-03 02:53:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 02:53:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-03 02:53:02 --> Email Class Initialized
INFO - 2018-08-03 02:53:02 --> Controller Class Initialized
DEBUG - 2018-08-03 02:53:02 --> Home MX_Controller Initialized
DEBUG - 2018-08-03 02:53:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-03 02:53:02 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-03 02:53:02 --> Login MX_Controller Initialized
INFO - 2018-08-03 02:53:02 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-03 02:53:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-03 02:53:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-03 02:53:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-08-03 02:53:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-08-03 02:53:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-08-03 02:53:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-08-03 02:53:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-08-03 02:53:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-08-03 02:53:02 --> Final output sent to browser
DEBUG - 2018-08-03 02:53:02 --> Total execution time: 0.8676
INFO - 2018-08-03 02:53:03 --> Config Class Initialized
INFO - 2018-08-03 02:53:03 --> Hooks Class Initialized
DEBUG - 2018-08-03 02:53:03 --> UTF-8 Support Enabled
INFO - 2018-08-03 02:53:03 --> Config Class Initialized
INFO - 2018-08-03 02:53:03 --> Hooks Class Initialized
INFO - 2018-08-03 02:53:03 --> Utf8 Class Initialized
DEBUG - 2018-08-03 02:53:03 --> UTF-8 Support Enabled
INFO - 2018-08-03 02:53:03 --> Utf8 Class Initialized
INFO - 2018-08-03 02:53:03 --> URI Class Initialized
INFO - 2018-08-03 02:53:03 --> Router Class Initialized
INFO - 2018-08-03 02:53:03 --> Output Class Initialized
INFO - 2018-08-03 02:53:03 --> Security Class Initialized
DEBUG - 2018-08-03 02:53:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 02:53:03 --> Input Class Initialized
INFO - 2018-08-03 02:53:03 --> Language Class Initialized
INFO - 2018-08-03 02:53:03 --> URI Class Initialized
INFO - 2018-08-03 02:53:03 --> Language Class Initialized
INFO - 2018-08-03 02:53:04 --> Config Class Initialized
INFO - 2018-08-03 02:53:04 --> Router Class Initialized
INFO - 2018-08-03 02:53:04 --> Output Class Initialized
INFO - 2018-08-03 02:53:04 --> Loader Class Initialized
DEBUG - 2018-08-03 02:53:04 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-03 02:53:04 --> Security Class Initialized
DEBUG - 2018-08-03 02:53:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 02:53:04 --> Helper loaded: url_helper
INFO - 2018-08-03 02:53:04 --> Input Class Initialized
INFO - 2018-08-03 02:53:04 --> Language Class Initialized
ERROR - 2018-08-03 02:53:04 --> 404 Page Not Found: /index
INFO - 2018-08-03 02:53:04 --> Config Class Initialized
INFO - 2018-08-03 02:53:04 --> Hooks Class Initialized
INFO - 2018-08-03 02:53:04 --> Helper loaded: form_helper
DEBUG - 2018-08-03 02:53:04 --> UTF-8 Support Enabled
INFO - 2018-08-03 02:53:04 --> Helper loaded: date_helper
INFO - 2018-08-03 02:53:04 --> Helper loaded: util_helper
INFO - 2018-08-03 02:53:04 --> Utf8 Class Initialized
INFO - 2018-08-03 02:53:04 --> Helper loaded: text_helper
INFO - 2018-08-03 02:53:04 --> URI Class Initialized
INFO - 2018-08-03 02:53:04 --> Router Class Initialized
INFO - 2018-08-03 02:53:04 --> Helper loaded: string_helper
INFO - 2018-08-03 02:53:04 --> Output Class Initialized
INFO - 2018-08-03 02:53:04 --> Security Class Initialized
INFO - 2018-08-03 02:53:04 --> Database Driver Class Initialized
DEBUG - 2018-08-03 02:53:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 02:53:04 --> Input Class Initialized
INFO - 2018-08-03 02:53:04 --> Language Class Initialized
ERROR - 2018-08-03 02:53:04 --> 404 Page Not Found: /index
INFO - 2018-08-03 02:53:04 --> Config Class Initialized
DEBUG - 2018-08-03 02:53:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 02:53:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-03 02:53:04 --> Hooks Class Initialized
INFO - 2018-08-03 02:53:04 --> Email Class Initialized
INFO - 2018-08-03 02:53:04 --> Controller Class Initialized
DEBUG - 2018-08-03 02:53:04 --> Home MX_Controller Initialized
DEBUG - 2018-08-03 02:53:04 --> UTF-8 Support Enabled
INFO - 2018-08-03 02:53:04 --> Utf8 Class Initialized
DEBUG - 2018-08-03 02:53:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-08-03 02:53:04 --> URI Class Initialized
INFO - 2018-08-03 02:53:04 --> Router Class Initialized
DEBUG - 2018-08-03 02:53:04 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-03 02:53:04 --> Login MX_Controller Initialized
INFO - 2018-08-03 02:53:04 --> Output Class Initialized
INFO - 2018-08-03 02:53:04 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-03 02:53:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-03 02:53:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-03 02:53:04 --> Security Class Initialized
DEBUG - 2018-08-03 02:53:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 02:53:05 --> Input Class Initialized
INFO - 2018-08-03 02:53:05 --> Language Class Initialized
ERROR - 2018-08-03 02:53:05 --> 404 Page Not Found: /index
INFO - 2018-08-03 02:53:22 --> Config Class Initialized
INFO - 2018-08-03 02:53:22 --> Hooks Class Initialized
DEBUG - 2018-08-03 02:53:22 --> UTF-8 Support Enabled
INFO - 2018-08-03 02:53:22 --> Utf8 Class Initialized
INFO - 2018-08-03 02:53:22 --> URI Class Initialized
INFO - 2018-08-03 02:53:22 --> Router Class Initialized
INFO - 2018-08-03 02:53:22 --> Output Class Initialized
INFO - 2018-08-03 02:53:23 --> Security Class Initialized
DEBUG - 2018-08-03 02:53:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 02:53:23 --> Input Class Initialized
INFO - 2018-08-03 02:53:23 --> Language Class Initialized
INFO - 2018-08-03 02:53:23 --> Language Class Initialized
INFO - 2018-08-03 02:53:23 --> Config Class Initialized
INFO - 2018-08-03 02:53:23 --> Loader Class Initialized
DEBUG - 2018-08-03 02:53:23 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-03 02:53:23 --> Helper loaded: url_helper
INFO - 2018-08-03 02:53:23 --> Helper loaded: form_helper
INFO - 2018-08-03 02:53:23 --> Helper loaded: date_helper
INFO - 2018-08-03 02:53:23 --> Helper loaded: util_helper
INFO - 2018-08-03 02:53:23 --> Helper loaded: text_helper
INFO - 2018-08-03 02:53:23 --> Helper loaded: string_helper
INFO - 2018-08-03 02:53:23 --> Database Driver Class Initialized
DEBUG - 2018-08-03 02:53:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 02:53:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-03 02:53:23 --> Email Class Initialized
INFO - 2018-08-03 02:53:23 --> Controller Class Initialized
DEBUG - 2018-08-03 02:53:23 --> Admin MX_Controller Initialized
INFO - 2018-08-03 02:53:23 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-03 02:53:23 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-03 02:53:23 --> Login MX_Controller Initialized
DEBUG - 2018-08-03 02:53:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-03 02:53:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-03 02:53:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-08-03 02:53:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-08-03 02:53:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-08-03 02:53:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-08-03 02:53:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-08-03 02:53:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/dashboard.php
INFO - 2018-08-03 02:53:23 --> Final output sent to browser
DEBUG - 2018-08-03 02:53:23 --> Total execution time: 0.7557
INFO - 2018-08-03 02:53:24 --> Config Class Initialized
INFO - 2018-08-03 02:53:24 --> Hooks Class Initialized
DEBUG - 2018-08-03 02:53:24 --> UTF-8 Support Enabled
INFO - 2018-08-03 02:53:24 --> Utf8 Class Initialized
INFO - 2018-08-03 02:53:25 --> URI Class Initialized
INFO - 2018-08-03 02:53:25 --> Router Class Initialized
INFO - 2018-08-03 02:53:25 --> Output Class Initialized
INFO - 2018-08-03 02:53:25 --> Security Class Initialized
DEBUG - 2018-08-03 02:53:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 02:53:25 --> Input Class Initialized
INFO - 2018-08-03 02:53:25 --> Language Class Initialized
INFO - 2018-08-03 02:53:25 --> Language Class Initialized
INFO - 2018-08-03 02:53:25 --> Config Class Initialized
INFO - 2018-08-03 02:53:25 --> Loader Class Initialized
DEBUG - 2018-08-03 02:53:25 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-03 02:53:25 --> Helper loaded: url_helper
INFO - 2018-08-03 02:53:25 --> Helper loaded: form_helper
INFO - 2018-08-03 02:53:25 --> Helper loaded: date_helper
INFO - 2018-08-03 02:53:25 --> Helper loaded: util_helper
INFO - 2018-08-03 02:53:25 --> Helper loaded: text_helper
INFO - 2018-08-03 02:53:25 --> Helper loaded: string_helper
INFO - 2018-08-03 02:53:25 --> Database Driver Class Initialized
DEBUG - 2018-08-03 02:53:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 02:53:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-03 02:53:25 --> Email Class Initialized
INFO - 2018-08-03 02:53:25 --> Controller Class Initialized
DEBUG - 2018-08-03 02:53:25 --> Home MX_Controller Initialized
DEBUG - 2018-08-03 02:53:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-03 02:53:25 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-03 02:53:25 --> Login MX_Controller Initialized
INFO - 2018-08-03 02:53:25 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-03 02:53:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-03 02:53:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-03 03:00:01 --> Config Class Initialized
INFO - 2018-08-03 03:00:01 --> Hooks Class Initialized
DEBUG - 2018-08-03 03:00:01 --> UTF-8 Support Enabled
INFO - 2018-08-03 03:00:01 --> Utf8 Class Initialized
INFO - 2018-08-03 03:00:01 --> URI Class Initialized
INFO - 2018-08-03 03:00:01 --> Router Class Initialized
INFO - 2018-08-03 03:00:01 --> Output Class Initialized
INFO - 2018-08-03 03:00:01 --> Security Class Initialized
DEBUG - 2018-08-03 03:00:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 03:00:01 --> Input Class Initialized
INFO - 2018-08-03 03:00:01 --> Language Class Initialized
INFO - 2018-08-03 03:00:01 --> Language Class Initialized
INFO - 2018-08-03 03:00:01 --> Config Class Initialized
INFO - 2018-08-03 03:00:01 --> Loader Class Initialized
DEBUG - 2018-08-03 03:00:01 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-03 03:00:01 --> Helper loaded: url_helper
INFO - 2018-08-03 03:00:01 --> Helper loaded: form_helper
INFO - 2018-08-03 03:00:01 --> Helper loaded: date_helper
INFO - 2018-08-03 03:00:01 --> Helper loaded: util_helper
INFO - 2018-08-03 03:00:01 --> Helper loaded: text_helper
INFO - 2018-08-03 03:00:01 --> Helper loaded: string_helper
INFO - 2018-08-03 03:00:01 --> Database Driver Class Initialized
DEBUG - 2018-08-03 03:00:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 03:00:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-03 03:00:02 --> Email Class Initialized
INFO - 2018-08-03 03:00:02 --> Controller Class Initialized
DEBUG - 2018-08-03 03:00:02 --> Admin MX_Controller Initialized
INFO - 2018-08-03 03:00:02 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-03 03:00:02 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-03 03:00:02 --> Login MX_Controller Initialized
DEBUG - 2018-08-03 03:00:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-03 03:00:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-03 03:00:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-08-03 03:00:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-08-03 03:00:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-08-03 03:00:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-08-03 03:00:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-08-03 03:00:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/dashboard.php
INFO - 2018-08-03 03:00:02 --> Final output sent to browser
DEBUG - 2018-08-03 03:00:02 --> Total execution time: 0.7866
INFO - 2018-08-03 03:00:03 --> Config Class Initialized
INFO - 2018-08-03 03:00:03 --> Hooks Class Initialized
DEBUG - 2018-08-03 03:00:03 --> UTF-8 Support Enabled
INFO - 2018-08-03 03:00:03 --> Utf8 Class Initialized
INFO - 2018-08-03 03:00:03 --> URI Class Initialized
INFO - 2018-08-03 03:00:03 --> Router Class Initialized
INFO - 2018-08-03 03:00:03 --> Output Class Initialized
INFO - 2018-08-03 03:00:03 --> Security Class Initialized
DEBUG - 2018-08-03 03:00:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 03:00:03 --> Input Class Initialized
INFO - 2018-08-03 03:00:03 --> Language Class Initialized
INFO - 2018-08-03 03:00:03 --> Language Class Initialized
INFO - 2018-08-03 03:00:03 --> Config Class Initialized
INFO - 2018-08-03 03:00:03 --> Loader Class Initialized
DEBUG - 2018-08-03 03:00:03 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-03 03:00:03 --> Helper loaded: url_helper
INFO - 2018-08-03 03:00:03 --> Helper loaded: form_helper
INFO - 2018-08-03 03:00:03 --> Helper loaded: date_helper
INFO - 2018-08-03 03:00:03 --> Helper loaded: util_helper
INFO - 2018-08-03 03:00:03 --> Helper loaded: text_helper
INFO - 2018-08-03 03:00:03 --> Helper loaded: string_helper
INFO - 2018-08-03 03:00:03 --> Database Driver Class Initialized
DEBUG - 2018-08-03 03:00:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 03:00:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-03 03:00:04 --> Email Class Initialized
INFO - 2018-08-03 03:00:04 --> Controller Class Initialized
DEBUG - 2018-08-03 03:00:04 --> Home MX_Controller Initialized
DEBUG - 2018-08-03 03:00:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-03 03:00:04 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-03 03:00:04 --> Login MX_Controller Initialized
INFO - 2018-08-03 03:00:04 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-03 03:00:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-03 03:00:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-03 03:00:07 --> Config Class Initialized
INFO - 2018-08-03 03:00:07 --> Hooks Class Initialized
DEBUG - 2018-08-03 03:00:07 --> UTF-8 Support Enabled
INFO - 2018-08-03 03:00:07 --> Utf8 Class Initialized
INFO - 2018-08-03 03:00:07 --> URI Class Initialized
INFO - 2018-08-03 03:00:07 --> Router Class Initialized
INFO - 2018-08-03 03:00:07 --> Output Class Initialized
INFO - 2018-08-03 03:00:07 --> Security Class Initialized
DEBUG - 2018-08-03 03:00:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 03:00:07 --> Input Class Initialized
INFO - 2018-08-03 03:00:07 --> Language Class Initialized
INFO - 2018-08-03 03:00:07 --> Language Class Initialized
INFO - 2018-08-03 03:00:07 --> Config Class Initialized
INFO - 2018-08-03 03:00:07 --> Loader Class Initialized
DEBUG - 2018-08-03 03:00:07 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-03 03:00:07 --> Helper loaded: url_helper
INFO - 2018-08-03 03:00:07 --> Helper loaded: form_helper
INFO - 2018-08-03 03:00:07 --> Helper loaded: date_helper
INFO - 2018-08-03 03:00:07 --> Helper loaded: util_helper
INFO - 2018-08-03 03:00:07 --> Helper loaded: text_helper
INFO - 2018-08-03 03:00:07 --> Helper loaded: string_helper
INFO - 2018-08-03 03:00:07 --> Database Driver Class Initialized
DEBUG - 2018-08-03 03:00:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 03:00:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-03 03:00:07 --> Email Class Initialized
INFO - 2018-08-03 03:00:07 --> Controller Class Initialized
DEBUG - 2018-08-03 03:00:07 --> Home MX_Controller Initialized
DEBUG - 2018-08-03 03:00:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-03 03:00:07 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-03 03:00:07 --> Login MX_Controller Initialized
INFO - 2018-08-03 03:00:07 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-03 03:00:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-03 03:00:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-03 03:00:10 --> Config Class Initialized
INFO - 2018-08-03 03:00:10 --> Hooks Class Initialized
DEBUG - 2018-08-03 03:00:10 --> UTF-8 Support Enabled
INFO - 2018-08-03 03:00:10 --> Utf8 Class Initialized
INFO - 2018-08-03 03:00:10 --> URI Class Initialized
INFO - 2018-08-03 03:00:10 --> Router Class Initialized
INFO - 2018-08-03 03:00:10 --> Output Class Initialized
INFO - 2018-08-03 03:00:10 --> Security Class Initialized
DEBUG - 2018-08-03 03:00:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 03:00:10 --> Input Class Initialized
INFO - 2018-08-03 03:00:10 --> Language Class Initialized
INFO - 2018-08-03 03:00:10 --> Language Class Initialized
INFO - 2018-08-03 03:00:10 --> Config Class Initialized
INFO - 2018-08-03 03:00:10 --> Loader Class Initialized
DEBUG - 2018-08-03 03:00:10 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-03 03:00:11 --> Helper loaded: url_helper
INFO - 2018-08-03 03:00:11 --> Helper loaded: form_helper
INFO - 2018-08-03 03:00:11 --> Helper loaded: date_helper
INFO - 2018-08-03 03:00:11 --> Helper loaded: util_helper
INFO - 2018-08-03 03:00:11 --> Helper loaded: text_helper
INFO - 2018-08-03 03:00:11 --> Helper loaded: string_helper
INFO - 2018-08-03 03:00:11 --> Database Driver Class Initialized
DEBUG - 2018-08-03 03:00:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 03:00:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-03 03:00:11 --> Email Class Initialized
INFO - 2018-08-03 03:00:11 --> Controller Class Initialized
DEBUG - 2018-08-03 03:00:11 --> Home MX_Controller Initialized
DEBUG - 2018-08-03 03:00:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-03 03:00:11 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-03 03:00:11 --> Login MX_Controller Initialized
INFO - 2018-08-03 03:00:11 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-03 03:00:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-03 03:00:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-03 03:00:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-08-03 03:00:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-08-03 03:00:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-08-03 03:00:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-08-03 03:00:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-08-03 03:00:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-08-03 03:00:11 --> Final output sent to browser
DEBUG - 2018-08-03 03:00:11 --> Total execution time: 0.8202
INFO - 2018-08-03 03:00:12 --> Config Class Initialized
INFO - 2018-08-03 03:00:12 --> Hooks Class Initialized
DEBUG - 2018-08-03 03:00:12 --> UTF-8 Support Enabled
INFO - 2018-08-03 03:00:12 --> Config Class Initialized
INFO - 2018-08-03 03:00:12 --> Hooks Class Initialized
INFO - 2018-08-03 03:00:12 --> Utf8 Class Initialized
DEBUG - 2018-08-03 03:00:12 --> UTF-8 Support Enabled
INFO - 2018-08-03 03:00:12 --> Utf8 Class Initialized
INFO - 2018-08-03 03:00:12 --> URI Class Initialized
INFO - 2018-08-03 03:00:12 --> Router Class Initialized
INFO - 2018-08-03 03:00:12 --> Output Class Initialized
INFO - 2018-08-03 03:00:12 --> Security Class Initialized
DEBUG - 2018-08-03 03:00:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 03:00:12 --> Input Class Initialized
INFO - 2018-08-03 03:00:13 --> Language Class Initialized
INFO - 2018-08-03 03:00:13 --> URI Class Initialized
INFO - 2018-08-03 03:00:13 --> Language Class Initialized
INFO - 2018-08-03 03:00:13 --> Config Class Initialized
INFO - 2018-08-03 03:00:13 --> Router Class Initialized
INFO - 2018-08-03 03:00:13 --> Loader Class Initialized
INFO - 2018-08-03 03:00:13 --> Output Class Initialized
INFO - 2018-08-03 03:00:13 --> Security Class Initialized
DEBUG - 2018-08-03 03:00:13 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-03 03:00:13 --> Helper loaded: url_helper
DEBUG - 2018-08-03 03:00:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 03:00:13 --> Helper loaded: form_helper
INFO - 2018-08-03 03:00:13 --> Input Class Initialized
INFO - 2018-08-03 03:00:13 --> Helper loaded: date_helper
INFO - 2018-08-03 03:00:13 --> Language Class Initialized
ERROR - 2018-08-03 03:00:13 --> 404 Page Not Found: /index
INFO - 2018-08-03 03:00:13 --> Config Class Initialized
INFO - 2018-08-03 03:00:13 --> Hooks Class Initialized
DEBUG - 2018-08-03 03:00:13 --> UTF-8 Support Enabled
INFO - 2018-08-03 03:00:13 --> Utf8 Class Initialized
INFO - 2018-08-03 03:00:13 --> URI Class Initialized
INFO - 2018-08-03 03:00:13 --> Helper loaded: util_helper
INFO - 2018-08-03 03:00:13 --> Router Class Initialized
INFO - 2018-08-03 03:00:13 --> Helper loaded: text_helper
INFO - 2018-08-03 03:00:13 --> Helper loaded: string_helper
INFO - 2018-08-03 03:00:13 --> Output Class Initialized
INFO - 2018-08-03 03:00:13 --> Database Driver Class Initialized
INFO - 2018-08-03 03:00:13 --> Security Class Initialized
DEBUG - 2018-08-03 03:00:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 03:00:13 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-08-03 03:00:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 03:00:13 --> Input Class Initialized
INFO - 2018-08-03 03:00:13 --> Email Class Initialized
INFO - 2018-08-03 03:00:13 --> Controller Class Initialized
INFO - 2018-08-03 03:00:13 --> Language Class Initialized
DEBUG - 2018-08-03 03:00:13 --> Home MX_Controller Initialized
ERROR - 2018-08-03 03:00:13 --> 404 Page Not Found: /index
DEBUG - 2018-08-03 03:00:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-08-03 03:00:13 --> Config Class Initialized
DEBUG - 2018-08-03 03:00:13 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-03 03:00:13 --> Login MX_Controller Initialized
INFO - 2018-08-03 03:00:13 --> Hooks Class Initialized
INFO - 2018-08-03 03:00:14 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-03 03:00:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-03 03:00:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-03 03:00:14 --> UTF-8 Support Enabled
INFO - 2018-08-03 03:00:14 --> Utf8 Class Initialized
INFO - 2018-08-03 03:00:14 --> URI Class Initialized
INFO - 2018-08-03 03:00:14 --> Router Class Initialized
INFO - 2018-08-03 03:00:14 --> Output Class Initialized
INFO - 2018-08-03 03:00:14 --> Security Class Initialized
DEBUG - 2018-08-03 03:00:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 03:00:14 --> Input Class Initialized
INFO - 2018-08-03 03:00:14 --> Language Class Initialized
ERROR - 2018-08-03 03:00:14 --> 404 Page Not Found: /index
INFO - 2018-08-03 03:00:56 --> Config Class Initialized
INFO - 2018-08-03 03:00:56 --> Hooks Class Initialized
DEBUG - 2018-08-03 03:00:56 --> UTF-8 Support Enabled
INFO - 2018-08-03 03:00:56 --> Utf8 Class Initialized
INFO - 2018-08-03 03:00:56 --> URI Class Initialized
INFO - 2018-08-03 03:00:56 --> Router Class Initialized
INFO - 2018-08-03 03:00:56 --> Output Class Initialized
INFO - 2018-08-03 03:00:56 --> Security Class Initialized
DEBUG - 2018-08-03 03:00:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 03:00:56 --> Input Class Initialized
INFO - 2018-08-03 03:00:56 --> Language Class Initialized
INFO - 2018-08-03 03:00:56 --> Language Class Initialized
INFO - 2018-08-03 03:00:56 --> Config Class Initialized
INFO - 2018-08-03 03:00:56 --> Loader Class Initialized
DEBUG - 2018-08-03 03:00:56 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-03 03:00:56 --> Helper loaded: url_helper
INFO - 2018-08-03 03:00:56 --> Helper loaded: form_helper
INFO - 2018-08-03 03:00:56 --> Helper loaded: date_helper
INFO - 2018-08-03 03:00:56 --> Helper loaded: util_helper
INFO - 2018-08-03 03:00:56 --> Helper loaded: text_helper
INFO - 2018-08-03 03:00:56 --> Helper loaded: string_helper
INFO - 2018-08-03 03:00:56 --> Database Driver Class Initialized
DEBUG - 2018-08-03 03:00:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 03:00:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-03 03:00:56 --> Email Class Initialized
INFO - 2018-08-03 03:00:56 --> Controller Class Initialized
DEBUG - 2018-08-03 03:00:56 --> Admin MX_Controller Initialized
INFO - 2018-08-03 03:00:56 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-03 03:00:56 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-03 03:00:56 --> Login MX_Controller Initialized
DEBUG - 2018-08-03 03:00:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-03 03:00:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-03 03:00:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-08-03 03:00:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-08-03 03:00:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-08-03 03:00:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-08-03 03:00:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-08-03 03:00:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/dashboard.php
INFO - 2018-08-03 03:00:56 --> Final output sent to browser
DEBUG - 2018-08-03 03:00:56 --> Total execution time: 0.7628
INFO - 2018-08-03 03:00:57 --> Config Class Initialized
INFO - 2018-08-03 03:00:57 --> Hooks Class Initialized
DEBUG - 2018-08-03 03:00:57 --> UTF-8 Support Enabled
INFO - 2018-08-03 03:00:57 --> Utf8 Class Initialized
INFO - 2018-08-03 03:00:57 --> URI Class Initialized
INFO - 2018-08-03 03:00:57 --> Router Class Initialized
INFO - 2018-08-03 03:00:57 --> Output Class Initialized
INFO - 2018-08-03 03:00:57 --> Security Class Initialized
DEBUG - 2018-08-03 03:00:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 03:00:57 --> Input Class Initialized
INFO - 2018-08-03 03:00:57 --> Language Class Initialized
INFO - 2018-08-03 03:00:58 --> Language Class Initialized
INFO - 2018-08-03 03:00:58 --> Config Class Initialized
INFO - 2018-08-03 03:00:58 --> Loader Class Initialized
DEBUG - 2018-08-03 03:00:58 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-03 03:00:58 --> Helper loaded: url_helper
INFO - 2018-08-03 03:00:58 --> Helper loaded: form_helper
INFO - 2018-08-03 03:00:58 --> Helper loaded: date_helper
INFO - 2018-08-03 03:00:58 --> Helper loaded: util_helper
INFO - 2018-08-03 03:00:58 --> Helper loaded: text_helper
INFO - 2018-08-03 03:00:58 --> Helper loaded: string_helper
INFO - 2018-08-03 03:00:58 --> Database Driver Class Initialized
DEBUG - 2018-08-03 03:00:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 03:00:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-03 03:00:58 --> Email Class Initialized
INFO - 2018-08-03 03:00:58 --> Controller Class Initialized
DEBUG - 2018-08-03 03:00:58 --> Home MX_Controller Initialized
DEBUG - 2018-08-03 03:00:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-03 03:00:58 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-03 03:00:58 --> Login MX_Controller Initialized
INFO - 2018-08-03 03:00:58 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-03 03:00:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-03 03:00:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-03 03:01:02 --> Config Class Initialized
INFO - 2018-08-03 03:01:02 --> Hooks Class Initialized
DEBUG - 2018-08-03 03:01:02 --> UTF-8 Support Enabled
INFO - 2018-08-03 03:01:02 --> Utf8 Class Initialized
INFO - 2018-08-03 03:01:02 --> URI Class Initialized
INFO - 2018-08-03 03:01:02 --> Router Class Initialized
INFO - 2018-08-03 03:01:02 --> Output Class Initialized
INFO - 2018-08-03 03:01:02 --> Security Class Initialized
DEBUG - 2018-08-03 03:01:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 03:01:02 --> Input Class Initialized
INFO - 2018-08-03 03:01:02 --> Language Class Initialized
INFO - 2018-08-03 03:01:02 --> Language Class Initialized
INFO - 2018-08-03 03:01:02 --> Config Class Initialized
INFO - 2018-08-03 03:01:02 --> Loader Class Initialized
DEBUG - 2018-08-03 03:01:02 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-03 03:01:02 --> Helper loaded: url_helper
INFO - 2018-08-03 03:01:02 --> Helper loaded: form_helper
INFO - 2018-08-03 03:01:02 --> Helper loaded: date_helper
INFO - 2018-08-03 03:01:02 --> Helper loaded: util_helper
INFO - 2018-08-03 03:01:02 --> Helper loaded: text_helper
INFO - 2018-08-03 03:01:02 --> Helper loaded: string_helper
INFO - 2018-08-03 03:01:02 --> Database Driver Class Initialized
DEBUG - 2018-08-03 03:01:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 03:01:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-03 03:01:02 --> Email Class Initialized
INFO - 2018-08-03 03:01:02 --> Controller Class Initialized
DEBUG - 2018-08-03 03:01:02 --> Home MX_Controller Initialized
DEBUG - 2018-08-03 03:01:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-03 03:01:02 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-03 03:01:02 --> Login MX_Controller Initialized
INFO - 2018-08-03 03:01:02 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-03 03:01:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-03 03:01:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-03 03:01:07 --> Config Class Initialized
INFO - 2018-08-03 03:01:07 --> Hooks Class Initialized
DEBUG - 2018-08-03 03:01:07 --> UTF-8 Support Enabled
INFO - 2018-08-03 03:01:07 --> Utf8 Class Initialized
INFO - 2018-08-03 03:01:07 --> URI Class Initialized
INFO - 2018-08-03 03:01:07 --> Router Class Initialized
INFO - 2018-08-03 03:01:07 --> Output Class Initialized
INFO - 2018-08-03 03:01:07 --> Security Class Initialized
DEBUG - 2018-08-03 03:01:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 03:01:07 --> Input Class Initialized
INFO - 2018-08-03 03:01:07 --> Language Class Initialized
INFO - 2018-08-03 03:01:07 --> Language Class Initialized
INFO - 2018-08-03 03:01:07 --> Config Class Initialized
INFO - 2018-08-03 03:01:07 --> Loader Class Initialized
DEBUG - 2018-08-03 03:01:08 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-03 03:01:08 --> Helper loaded: url_helper
INFO - 2018-08-03 03:01:08 --> Helper loaded: form_helper
INFO - 2018-08-03 03:01:08 --> Helper loaded: date_helper
INFO - 2018-08-03 03:01:08 --> Helper loaded: util_helper
INFO - 2018-08-03 03:01:08 --> Helper loaded: text_helper
INFO - 2018-08-03 03:01:08 --> Helper loaded: string_helper
INFO - 2018-08-03 03:01:08 --> Database Driver Class Initialized
DEBUG - 2018-08-03 03:01:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 03:01:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-03 03:01:08 --> Email Class Initialized
INFO - 2018-08-03 03:01:08 --> Controller Class Initialized
DEBUG - 2018-08-03 03:01:08 --> Home MX_Controller Initialized
DEBUG - 2018-08-03 03:01:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-03 03:01:08 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-03 03:01:08 --> Login MX_Controller Initialized
INFO - 2018-08-03 03:01:08 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-03 03:01:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-03 03:01:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-03 03:01:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-08-03 03:01:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-08-03 03:01:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-08-03 03:01:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-08-03 03:01:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-08-03 03:01:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-08-03 03:01:08 --> Final output sent to browser
DEBUG - 2018-08-03 03:01:08 --> Total execution time: 0.8057
INFO - 2018-08-03 03:01:09 --> Config Class Initialized
INFO - 2018-08-03 03:01:09 --> Hooks Class Initialized
INFO - 2018-08-03 03:01:09 --> Config Class Initialized
INFO - 2018-08-03 03:01:09 --> Hooks Class Initialized
DEBUG - 2018-08-03 03:01:09 --> UTF-8 Support Enabled
DEBUG - 2018-08-03 03:01:09 --> UTF-8 Support Enabled
INFO - 2018-08-03 03:01:09 --> Utf8 Class Initialized
INFO - 2018-08-03 03:01:09 --> Utf8 Class Initialized
INFO - 2018-08-03 03:01:09 --> URI Class Initialized
INFO - 2018-08-03 03:01:09 --> URI Class Initialized
INFO - 2018-08-03 03:01:09 --> Router Class Initialized
INFO - 2018-08-03 03:01:09 --> Router Class Initialized
INFO - 2018-08-03 03:01:09 --> Output Class Initialized
INFO - 2018-08-03 03:01:09 --> Security Class Initialized
INFO - 2018-08-03 03:01:09 --> Output Class Initialized
DEBUG - 2018-08-03 03:01:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 03:01:09 --> Input Class Initialized
INFO - 2018-08-03 03:01:09 --> Security Class Initialized
INFO - 2018-08-03 03:01:09 --> Language Class Initialized
INFO - 2018-08-03 03:01:09 --> Language Class Initialized
INFO - 2018-08-03 03:01:09 --> Config Class Initialized
DEBUG - 2018-08-03 03:01:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 03:01:09 --> Loader Class Initialized
DEBUG - 2018-08-03 03:01:09 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-03 03:01:09 --> Helper loaded: url_helper
INFO - 2018-08-03 03:01:09 --> Helper loaded: form_helper
INFO - 2018-08-03 03:01:09 --> Input Class Initialized
INFO - 2018-08-03 03:01:09 --> Helper loaded: date_helper
INFO - 2018-08-03 03:01:10 --> Language Class Initialized
INFO - 2018-08-03 03:01:10 --> Helper loaded: util_helper
ERROR - 2018-08-03 03:01:10 --> 404 Page Not Found: /index
INFO - 2018-08-03 03:01:10 --> Helper loaded: text_helper
INFO - 2018-08-03 03:01:10 --> Helper loaded: string_helper
INFO - 2018-08-03 03:01:10 --> Config Class Initialized
INFO - 2018-08-03 03:01:10 --> Database Driver Class Initialized
INFO - 2018-08-03 03:01:10 --> Hooks Class Initialized
DEBUG - 2018-08-03 03:01:10 --> UTF-8 Support Enabled
INFO - 2018-08-03 03:01:10 --> Utf8 Class Initialized
INFO - 2018-08-03 03:01:10 --> URI Class Initialized
DEBUG - 2018-08-03 03:01:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 03:01:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-03 03:01:10 --> Router Class Initialized
INFO - 2018-08-03 03:01:10 --> Output Class Initialized
INFO - 2018-08-03 03:01:10 --> Email Class Initialized
INFO - 2018-08-03 03:01:10 --> Controller Class Initialized
INFO - 2018-08-03 03:01:10 --> Security Class Initialized
DEBUG - 2018-08-03 03:01:10 --> Home MX_Controller Initialized
DEBUG - 2018-08-03 03:01:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-03 03:01:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 03:01:10 --> Input Class Initialized
DEBUG - 2018-08-03 03:01:10 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
INFO - 2018-08-03 03:01:10 --> Language Class Initialized
DEBUG - 2018-08-03 03:01:10 --> Login MX_Controller Initialized
INFO - 2018-08-03 03:01:10 --> Language file loaded: language/english/data_lang.php
ERROR - 2018-08-03 03:01:10 --> 404 Page Not Found: /index
DEBUG - 2018-08-03 03:01:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-03 03:01:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-03 03:01:10 --> Config Class Initialized
INFO - 2018-08-03 03:01:10 --> Hooks Class Initialized
DEBUG - 2018-08-03 03:01:10 --> UTF-8 Support Enabled
INFO - 2018-08-03 03:01:10 --> Utf8 Class Initialized
INFO - 2018-08-03 03:01:10 --> URI Class Initialized
INFO - 2018-08-03 03:01:10 --> Router Class Initialized
INFO - 2018-08-03 03:01:10 --> Output Class Initialized
INFO - 2018-08-03 03:01:10 --> Security Class Initialized
DEBUG - 2018-08-03 03:01:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 03:01:10 --> Input Class Initialized
INFO - 2018-08-03 03:01:10 --> Language Class Initialized
ERROR - 2018-08-03 03:01:11 --> 404 Page Not Found: /index
INFO - 2018-08-03 03:01:11 --> Config Class Initialized
INFO - 2018-08-03 03:01:11 --> Hooks Class Initialized
DEBUG - 2018-08-03 03:01:11 --> UTF-8 Support Enabled
INFO - 2018-08-03 03:01:11 --> Utf8 Class Initialized
INFO - 2018-08-03 03:01:11 --> URI Class Initialized
INFO - 2018-08-03 03:01:11 --> Router Class Initialized
INFO - 2018-08-03 03:01:11 --> Output Class Initialized
INFO - 2018-08-03 03:01:11 --> Security Class Initialized
DEBUG - 2018-08-03 03:01:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 03:01:11 --> Input Class Initialized
INFO - 2018-08-03 03:01:11 --> Language Class Initialized
INFO - 2018-08-03 03:01:11 --> Language Class Initialized
INFO - 2018-08-03 03:01:11 --> Config Class Initialized
INFO - 2018-08-03 03:01:11 --> Loader Class Initialized
DEBUG - 2018-08-03 03:01:11 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-03 03:01:11 --> Helper loaded: url_helper
INFO - 2018-08-03 03:01:11 --> Helper loaded: form_helper
INFO - 2018-08-03 03:01:12 --> Helper loaded: date_helper
INFO - 2018-08-03 03:01:12 --> Helper loaded: util_helper
INFO - 2018-08-03 03:01:12 --> Helper loaded: text_helper
INFO - 2018-08-03 03:01:12 --> Helper loaded: string_helper
INFO - 2018-08-03 03:01:12 --> Database Driver Class Initialized
DEBUG - 2018-08-03 03:01:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 03:01:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-03 03:01:12 --> Email Class Initialized
INFO - 2018-08-03 03:01:12 --> Controller Class Initialized
DEBUG - 2018-08-03 03:01:12 --> Home MX_Controller Initialized
DEBUG - 2018-08-03 03:01:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-03 03:01:12 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-03 03:01:12 --> Login MX_Controller Initialized
INFO - 2018-08-03 03:01:12 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-03 03:01:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-03 03:01:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-03 03:01:15 --> Config Class Initialized
INFO - 2018-08-03 03:01:15 --> Hooks Class Initialized
DEBUG - 2018-08-03 03:01:15 --> UTF-8 Support Enabled
INFO - 2018-08-03 03:01:15 --> Utf8 Class Initialized
INFO - 2018-08-03 03:01:15 --> URI Class Initialized
INFO - 2018-08-03 03:01:15 --> Router Class Initialized
INFO - 2018-08-03 03:01:15 --> Output Class Initialized
INFO - 2018-08-03 03:01:15 --> Security Class Initialized
DEBUG - 2018-08-03 03:01:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 03:01:15 --> Input Class Initialized
INFO - 2018-08-03 03:01:15 --> Language Class Initialized
INFO - 2018-08-03 03:01:15 --> Language Class Initialized
INFO - 2018-08-03 03:01:15 --> Config Class Initialized
INFO - 2018-08-03 03:01:15 --> Loader Class Initialized
DEBUG - 2018-08-03 03:01:15 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-03 03:01:15 --> Helper loaded: url_helper
INFO - 2018-08-03 03:01:15 --> Helper loaded: form_helper
INFO - 2018-08-03 03:01:15 --> Helper loaded: date_helper
INFO - 2018-08-03 03:01:15 --> Helper loaded: util_helper
INFO - 2018-08-03 03:01:15 --> Helper loaded: text_helper
INFO - 2018-08-03 03:01:15 --> Helper loaded: string_helper
INFO - 2018-08-03 03:01:15 --> Database Driver Class Initialized
DEBUG - 2018-08-03 03:01:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 03:01:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-03 03:01:15 --> Email Class Initialized
INFO - 2018-08-03 03:01:15 --> Controller Class Initialized
DEBUG - 2018-08-03 03:01:15 --> Home MX_Controller Initialized
DEBUG - 2018-08-03 03:01:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-03 03:01:16 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-03 03:01:16 --> Login MX_Controller Initialized
INFO - 2018-08-03 03:01:16 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-03 03:01:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-03 03:01:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-03 03:01:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-08-03 03:01:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-08-03 03:01:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-08-03 03:01:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-08-03 03:01:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-08-03 03:01:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-08-03 03:01:16 --> Final output sent to browser
DEBUG - 2018-08-03 03:01:16 --> Total execution time: 0.8310
INFO - 2018-08-03 03:01:16 --> Config Class Initialized
INFO - 2018-08-03 03:01:16 --> Hooks Class Initialized
DEBUG - 2018-08-03 03:01:16 --> UTF-8 Support Enabled
INFO - 2018-08-03 03:01:17 --> Config Class Initialized
INFO - 2018-08-03 03:01:17 --> Utf8 Class Initialized
INFO - 2018-08-03 03:01:17 --> Hooks Class Initialized
INFO - 2018-08-03 03:01:17 --> URI Class Initialized
DEBUG - 2018-08-03 03:01:17 --> UTF-8 Support Enabled
INFO - 2018-08-03 03:01:17 --> Router Class Initialized
INFO - 2018-08-03 03:01:17 --> Utf8 Class Initialized
INFO - 2018-08-03 03:01:17 --> Output Class Initialized
INFO - 2018-08-03 03:01:17 --> URI Class Initialized
INFO - 2018-08-03 03:01:17 --> Router Class Initialized
INFO - 2018-08-03 03:01:17 --> Security Class Initialized
INFO - 2018-08-03 03:01:17 --> Output Class Initialized
DEBUG - 2018-08-03 03:01:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 03:01:17 --> Input Class Initialized
INFO - 2018-08-03 03:01:17 --> Language Class Initialized
INFO - 2018-08-03 03:01:17 --> Security Class Initialized
ERROR - 2018-08-03 03:01:17 --> 404 Page Not Found: /index
DEBUG - 2018-08-03 03:01:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 03:01:17 --> Input Class Initialized
INFO - 2018-08-03 03:01:17 --> Language Class Initialized
INFO - 2018-08-03 03:01:17 --> Language Class Initialized
INFO - 2018-08-03 03:01:17 --> Config Class Initialized
INFO - 2018-08-03 03:01:17 --> Loader Class Initialized
INFO - 2018-08-03 03:01:17 --> Config Class Initialized
INFO - 2018-08-03 03:01:17 --> Hooks Class Initialized
DEBUG - 2018-08-03 03:01:17 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
DEBUG - 2018-08-03 03:01:17 --> UTF-8 Support Enabled
INFO - 2018-08-03 03:01:17 --> Utf8 Class Initialized
INFO - 2018-08-03 03:01:17 --> URI Class Initialized
INFO - 2018-08-03 03:01:17 --> Helper loaded: url_helper
INFO - 2018-08-03 03:01:17 --> Helper loaded: form_helper
INFO - 2018-08-03 03:01:17 --> Router Class Initialized
INFO - 2018-08-03 03:01:17 --> Helper loaded: date_helper
INFO - 2018-08-03 03:01:17 --> Output Class Initialized
INFO - 2018-08-03 03:01:17 --> Security Class Initialized
INFO - 2018-08-03 03:01:17 --> Helper loaded: util_helper
DEBUG - 2018-08-03 03:01:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 03:01:17 --> Input Class Initialized
INFO - 2018-08-03 03:01:18 --> Language Class Initialized
ERROR - 2018-08-03 03:01:18 --> 404 Page Not Found: /index
INFO - 2018-08-03 03:01:18 --> Helper loaded: text_helper
INFO - 2018-08-03 03:01:18 --> Config Class Initialized
INFO - 2018-08-03 03:01:18 --> Hooks Class Initialized
DEBUG - 2018-08-03 03:01:18 --> UTF-8 Support Enabled
INFO - 2018-08-03 03:01:18 --> Helper loaded: string_helper
INFO - 2018-08-03 03:01:18 --> Utf8 Class Initialized
INFO - 2018-08-03 03:01:18 --> Database Driver Class Initialized
INFO - 2018-08-03 03:01:18 --> URI Class Initialized
INFO - 2018-08-03 03:01:18 --> Router Class Initialized
DEBUG - 2018-08-03 03:01:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 03:01:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-03 03:01:18 --> Output Class Initialized
INFO - 2018-08-03 03:01:18 --> Email Class Initialized
INFO - 2018-08-03 03:01:18 --> Controller Class Initialized
INFO - 2018-08-03 03:01:18 --> Security Class Initialized
DEBUG - 2018-08-03 03:01:18 --> Home MX_Controller Initialized
DEBUG - 2018-08-03 03:01:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 03:01:18 --> Input Class Initialized
DEBUG - 2018-08-03 03:01:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-08-03 03:01:18 --> Language Class Initialized
DEBUG - 2018-08-03 03:01:18 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-03 03:01:18 --> Login MX_Controller Initialized
ERROR - 2018-08-03 03:01:18 --> 404 Page Not Found: /index
INFO - 2018-08-03 03:01:18 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-03 03:01:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-03 03:01:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-03 03:01:19 --> Config Class Initialized
INFO - 2018-08-03 03:01:19 --> Hooks Class Initialized
DEBUG - 2018-08-03 03:01:19 --> UTF-8 Support Enabled
INFO - 2018-08-03 03:01:19 --> Utf8 Class Initialized
INFO - 2018-08-03 03:01:19 --> URI Class Initialized
INFO - 2018-08-03 03:01:19 --> Router Class Initialized
INFO - 2018-08-03 03:01:19 --> Output Class Initialized
INFO - 2018-08-03 03:01:19 --> Security Class Initialized
DEBUG - 2018-08-03 03:01:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 03:01:19 --> Input Class Initialized
INFO - 2018-08-03 03:01:20 --> Language Class Initialized
INFO - 2018-08-03 03:01:20 --> Language Class Initialized
INFO - 2018-08-03 03:01:20 --> Config Class Initialized
INFO - 2018-08-03 03:01:20 --> Loader Class Initialized
DEBUG - 2018-08-03 03:01:20 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-03 03:01:20 --> Helper loaded: url_helper
INFO - 2018-08-03 03:01:20 --> Helper loaded: form_helper
INFO - 2018-08-03 03:01:20 --> Helper loaded: date_helper
INFO - 2018-08-03 03:01:20 --> Helper loaded: util_helper
INFO - 2018-08-03 03:01:20 --> Helper loaded: text_helper
INFO - 2018-08-03 03:01:20 --> Helper loaded: string_helper
INFO - 2018-08-03 03:01:20 --> Database Driver Class Initialized
DEBUG - 2018-08-03 03:01:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 03:01:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-03 03:01:20 --> Email Class Initialized
INFO - 2018-08-03 03:01:20 --> Controller Class Initialized
DEBUG - 2018-08-03 03:01:20 --> Home MX_Controller Initialized
DEBUG - 2018-08-03 03:01:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-03 03:01:20 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-03 03:01:20 --> Login MX_Controller Initialized
INFO - 2018-08-03 03:01:20 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-03 03:01:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-03 03:01:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-03 03:01:21 --> Config Class Initialized
INFO - 2018-08-03 03:01:21 --> Hooks Class Initialized
DEBUG - 2018-08-03 03:01:21 --> UTF-8 Support Enabled
INFO - 2018-08-03 03:01:21 --> Utf8 Class Initialized
INFO - 2018-08-03 03:01:21 --> URI Class Initialized
INFO - 2018-08-03 03:01:21 --> Router Class Initialized
INFO - 2018-08-03 03:01:22 --> Output Class Initialized
INFO - 2018-08-03 03:01:22 --> Security Class Initialized
DEBUG - 2018-08-03 03:01:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 03:01:22 --> Input Class Initialized
INFO - 2018-08-03 03:01:22 --> Language Class Initialized
INFO - 2018-08-03 03:01:22 --> Language Class Initialized
INFO - 2018-08-03 03:01:22 --> Config Class Initialized
INFO - 2018-08-03 03:01:22 --> Loader Class Initialized
DEBUG - 2018-08-03 03:01:22 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-03 03:01:22 --> Helper loaded: url_helper
INFO - 2018-08-03 03:01:22 --> Helper loaded: form_helper
INFO - 2018-08-03 03:01:22 --> Helper loaded: date_helper
INFO - 2018-08-03 03:01:22 --> Helper loaded: util_helper
INFO - 2018-08-03 03:01:22 --> Helper loaded: text_helper
INFO - 2018-08-03 03:01:22 --> Helper loaded: string_helper
INFO - 2018-08-03 03:01:22 --> Database Driver Class Initialized
DEBUG - 2018-08-03 03:01:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 03:01:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-03 03:01:22 --> Email Class Initialized
INFO - 2018-08-03 03:01:22 --> Controller Class Initialized
DEBUG - 2018-08-03 03:01:22 --> Home MX_Controller Initialized
DEBUG - 2018-08-03 03:01:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-03 03:01:22 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-03 03:01:22 --> Login MX_Controller Initialized
INFO - 2018-08-03 03:01:22 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-03 03:01:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-03 03:01:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-03 03:01:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-08-03 03:01:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-08-03 03:01:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-08-03 03:01:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-08-03 03:01:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-08-03 03:01:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-08-03 03:01:22 --> Final output sent to browser
DEBUG - 2018-08-03 03:01:22 --> Total execution time: 0.9362
INFO - 2018-08-03 03:01:23 --> Config Class Initialized
INFO - 2018-08-03 03:01:23 --> Hooks Class Initialized
DEBUG - 2018-08-03 03:01:23 --> UTF-8 Support Enabled
INFO - 2018-08-03 03:01:23 --> Config Class Initialized
INFO - 2018-08-03 03:01:23 --> Hooks Class Initialized
INFO - 2018-08-03 03:01:23 --> Utf8 Class Initialized
DEBUG - 2018-08-03 03:01:23 --> UTF-8 Support Enabled
INFO - 2018-08-03 03:01:23 --> Utf8 Class Initialized
INFO - 2018-08-03 03:01:23 --> URI Class Initialized
INFO - 2018-08-03 03:01:23 --> URI Class Initialized
INFO - 2018-08-03 03:01:23 --> Router Class Initialized
INFO - 2018-08-03 03:01:23 --> Router Class Initialized
INFO - 2018-08-03 03:01:23 --> Output Class Initialized
INFO - 2018-08-03 03:01:23 --> Security Class Initialized
INFO - 2018-08-03 03:01:23 --> Output Class Initialized
DEBUG - 2018-08-03 03:01:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 03:01:23 --> Input Class Initialized
INFO - 2018-08-03 03:01:23 --> Language Class Initialized
INFO - 2018-08-03 03:01:24 --> Security Class Initialized
INFO - 2018-08-03 03:01:24 --> Language Class Initialized
DEBUG - 2018-08-03 03:01:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 03:01:24 --> Input Class Initialized
INFO - 2018-08-03 03:01:24 --> Config Class Initialized
INFO - 2018-08-03 03:01:24 --> Language Class Initialized
INFO - 2018-08-03 03:01:24 --> Loader Class Initialized
DEBUG - 2018-08-03 03:01:24 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
ERROR - 2018-08-03 03:01:24 --> 404 Page Not Found: /index
INFO - 2018-08-03 03:01:24 --> Helper loaded: url_helper
INFO - 2018-08-03 03:01:24 --> Helper loaded: form_helper
INFO - 2018-08-03 03:01:24 --> Helper loaded: date_helper
INFO - 2018-08-03 03:01:24 --> Config Class Initialized
INFO - 2018-08-03 03:01:24 --> Hooks Class Initialized
INFO - 2018-08-03 03:01:24 --> Helper loaded: util_helper
DEBUG - 2018-08-03 03:01:24 --> UTF-8 Support Enabled
INFO - 2018-08-03 03:01:24 --> Utf8 Class Initialized
INFO - 2018-08-03 03:01:24 --> Helper loaded: text_helper
INFO - 2018-08-03 03:01:24 --> URI Class Initialized
INFO - 2018-08-03 03:01:24 --> Router Class Initialized
INFO - 2018-08-03 03:01:24 --> Output Class Initialized
INFO - 2018-08-03 03:01:24 --> Helper loaded: string_helper
INFO - 2018-08-03 03:01:24 --> Database Driver Class Initialized
INFO - 2018-08-03 03:01:24 --> Security Class Initialized
DEBUG - 2018-08-03 03:01:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-08-03 03:01:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 03:01:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-03 03:01:24 --> Input Class Initialized
INFO - 2018-08-03 03:01:24 --> Email Class Initialized
INFO - 2018-08-03 03:01:24 --> Controller Class Initialized
INFO - 2018-08-03 03:01:24 --> Language Class Initialized
ERROR - 2018-08-03 03:01:24 --> 404 Page Not Found: /index
DEBUG - 2018-08-03 03:01:24 --> Home MX_Controller Initialized
INFO - 2018-08-03 03:01:24 --> Config Class Initialized
DEBUG - 2018-08-03 03:01:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-08-03 03:01:24 --> Hooks Class Initialized
DEBUG - 2018-08-03 03:01:25 --> UTF-8 Support Enabled
INFO - 2018-08-03 03:01:25 --> Utf8 Class Initialized
INFO - 2018-08-03 03:01:25 --> URI Class Initialized
INFO - 2018-08-03 03:01:25 --> Router Class Initialized
INFO - 2018-08-03 03:01:25 --> Output Class Initialized
DEBUG - 2018-08-03 03:01:25 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-03 03:01:25 --> Login MX_Controller Initialized
INFO - 2018-08-03 03:01:25 --> Security Class Initialized
DEBUG - 2018-08-03 03:01:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 03:01:25 --> Language file loaded: language/english/data_lang.php
INFO - 2018-08-03 03:01:25 --> Input Class Initialized
DEBUG - 2018-08-03 03:01:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-08-03 03:01:25 --> Language Class Initialized
DEBUG - 2018-08-03 03:01:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
ERROR - 2018-08-03 03:01:25 --> 404 Page Not Found: /index
INFO - 2018-08-03 03:02:03 --> Config Class Initialized
INFO - 2018-08-03 03:02:03 --> Hooks Class Initialized
DEBUG - 2018-08-03 03:02:03 --> UTF-8 Support Enabled
INFO - 2018-08-03 03:02:03 --> Utf8 Class Initialized
INFO - 2018-08-03 03:02:03 --> URI Class Initialized
INFO - 2018-08-03 03:02:03 --> Router Class Initialized
INFO - 2018-08-03 03:02:03 --> Output Class Initialized
INFO - 2018-08-03 03:02:03 --> Security Class Initialized
DEBUG - 2018-08-03 03:02:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 03:02:03 --> Input Class Initialized
INFO - 2018-08-03 03:02:03 --> Language Class Initialized
INFO - 2018-08-03 03:02:03 --> Language Class Initialized
INFO - 2018-08-03 03:02:03 --> Config Class Initialized
INFO - 2018-08-03 03:02:03 --> Loader Class Initialized
DEBUG - 2018-08-03 03:02:03 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-03 03:02:03 --> Helper loaded: url_helper
INFO - 2018-08-03 03:02:03 --> Helper loaded: form_helper
INFO - 2018-08-03 03:02:03 --> Helper loaded: date_helper
INFO - 2018-08-03 03:02:03 --> Helper loaded: util_helper
INFO - 2018-08-03 03:02:03 --> Helper loaded: text_helper
INFO - 2018-08-03 03:02:03 --> Helper loaded: string_helper
INFO - 2018-08-03 03:02:03 --> Database Driver Class Initialized
DEBUG - 2018-08-03 03:02:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 03:02:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-03 03:02:03 --> Email Class Initialized
INFO - 2018-08-03 03:02:03 --> Controller Class Initialized
DEBUG - 2018-08-03 03:02:03 --> Admin MX_Controller Initialized
INFO - 2018-08-03 03:02:03 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-03 03:02:03 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-03 03:02:03 --> Login MX_Controller Initialized
DEBUG - 2018-08-03 03:02:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-03 03:02:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-03 03:02:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-08-03 03:02:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-08-03 03:02:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-08-03 03:02:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-08-03 03:02:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-08-03 03:02:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/dashboard.php
INFO - 2018-08-03 03:02:04 --> Final output sent to browser
DEBUG - 2018-08-03 03:02:04 --> Total execution time: 0.8039
INFO - 2018-08-03 03:02:04 --> Config Class Initialized
INFO - 2018-08-03 03:02:04 --> Hooks Class Initialized
DEBUG - 2018-08-03 03:02:04 --> UTF-8 Support Enabled
INFO - 2018-08-03 03:02:04 --> Utf8 Class Initialized
INFO - 2018-08-03 03:02:05 --> URI Class Initialized
INFO - 2018-08-03 03:02:05 --> Router Class Initialized
INFO - 2018-08-03 03:02:05 --> Output Class Initialized
INFO - 2018-08-03 03:02:05 --> Security Class Initialized
DEBUG - 2018-08-03 03:02:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 03:02:05 --> Input Class Initialized
INFO - 2018-08-03 03:02:05 --> Language Class Initialized
INFO - 2018-08-03 03:02:05 --> Language Class Initialized
INFO - 2018-08-03 03:02:05 --> Config Class Initialized
INFO - 2018-08-03 03:02:05 --> Loader Class Initialized
DEBUG - 2018-08-03 03:02:05 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-03 03:02:05 --> Helper loaded: url_helper
INFO - 2018-08-03 03:02:05 --> Helper loaded: form_helper
INFO - 2018-08-03 03:02:05 --> Helper loaded: date_helper
INFO - 2018-08-03 03:02:05 --> Helper loaded: util_helper
INFO - 2018-08-03 03:02:05 --> Helper loaded: text_helper
INFO - 2018-08-03 03:02:05 --> Helper loaded: string_helper
INFO - 2018-08-03 03:02:05 --> Database Driver Class Initialized
DEBUG - 2018-08-03 03:02:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 03:02:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-03 03:02:05 --> Email Class Initialized
INFO - 2018-08-03 03:02:05 --> Controller Class Initialized
DEBUG - 2018-08-03 03:02:05 --> Home MX_Controller Initialized
DEBUG - 2018-08-03 03:02:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-03 03:02:05 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-03 03:02:05 --> Login MX_Controller Initialized
INFO - 2018-08-03 03:02:05 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-03 03:02:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-03 03:02:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-03 03:02:07 --> Config Class Initialized
INFO - 2018-08-03 03:02:07 --> Hooks Class Initialized
DEBUG - 2018-08-03 03:02:07 --> UTF-8 Support Enabled
INFO - 2018-08-03 03:02:07 --> Utf8 Class Initialized
INFO - 2018-08-03 03:02:07 --> URI Class Initialized
INFO - 2018-08-03 03:02:07 --> Router Class Initialized
INFO - 2018-08-03 03:02:07 --> Output Class Initialized
INFO - 2018-08-03 03:02:07 --> Security Class Initialized
DEBUG - 2018-08-03 03:02:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 03:02:08 --> Input Class Initialized
INFO - 2018-08-03 03:02:08 --> Language Class Initialized
INFO - 2018-08-03 03:02:08 --> Language Class Initialized
INFO - 2018-08-03 03:02:08 --> Config Class Initialized
INFO - 2018-08-03 03:02:08 --> Loader Class Initialized
DEBUG - 2018-08-03 03:02:08 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-03 03:02:08 --> Helper loaded: url_helper
INFO - 2018-08-03 03:02:08 --> Helper loaded: form_helper
INFO - 2018-08-03 03:02:08 --> Helper loaded: date_helper
INFO - 2018-08-03 03:02:08 --> Helper loaded: util_helper
INFO - 2018-08-03 03:02:08 --> Helper loaded: text_helper
INFO - 2018-08-03 03:02:08 --> Helper loaded: string_helper
INFO - 2018-08-03 03:02:08 --> Database Driver Class Initialized
DEBUG - 2018-08-03 03:02:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 03:02:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-03 03:02:08 --> Email Class Initialized
INFO - 2018-08-03 03:02:08 --> Controller Class Initialized
DEBUG - 2018-08-03 03:02:08 --> Home MX_Controller Initialized
DEBUG - 2018-08-03 03:02:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-03 03:02:08 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-03 03:02:08 --> Login MX_Controller Initialized
INFO - 2018-08-03 03:02:08 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-03 03:02:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-03 03:02:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-03 03:02:10 --> Config Class Initialized
INFO - 2018-08-03 03:02:10 --> Hooks Class Initialized
DEBUG - 2018-08-03 03:02:10 --> UTF-8 Support Enabled
INFO - 2018-08-03 03:02:10 --> Utf8 Class Initialized
INFO - 2018-08-03 03:02:10 --> URI Class Initialized
INFO - 2018-08-03 03:02:10 --> Router Class Initialized
INFO - 2018-08-03 03:02:10 --> Output Class Initialized
INFO - 2018-08-03 03:02:10 --> Security Class Initialized
DEBUG - 2018-08-03 03:02:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 03:02:10 --> Input Class Initialized
INFO - 2018-08-03 03:02:10 --> Language Class Initialized
INFO - 2018-08-03 03:02:10 --> Language Class Initialized
INFO - 2018-08-03 03:02:10 --> Config Class Initialized
INFO - 2018-08-03 03:02:10 --> Loader Class Initialized
DEBUG - 2018-08-03 03:02:10 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-03 03:02:10 --> Helper loaded: url_helper
INFO - 2018-08-03 03:02:10 --> Helper loaded: form_helper
INFO - 2018-08-03 03:02:10 --> Helper loaded: date_helper
INFO - 2018-08-03 03:02:10 --> Helper loaded: util_helper
INFO - 2018-08-03 03:02:10 --> Helper loaded: text_helper
INFO - 2018-08-03 03:02:10 --> Helper loaded: string_helper
INFO - 2018-08-03 03:02:10 --> Database Driver Class Initialized
DEBUG - 2018-08-03 03:02:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 03:02:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-03 03:02:10 --> Email Class Initialized
INFO - 2018-08-03 03:02:10 --> Controller Class Initialized
DEBUG - 2018-08-03 03:02:10 --> Home MX_Controller Initialized
DEBUG - 2018-08-03 03:02:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-03 03:02:10 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-03 03:02:10 --> Login MX_Controller Initialized
INFO - 2018-08-03 03:02:10 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-03 03:02:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-03 03:02:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-03 03:02:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-08-03 03:02:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-08-03 03:02:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-08-03 03:02:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-08-03 03:02:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-08-03 03:02:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-08-03 03:02:10 --> Final output sent to browser
DEBUG - 2018-08-03 03:02:11 --> Total execution time: 0.8414
INFO - 2018-08-03 03:02:11 --> Config Class Initialized
INFO - 2018-08-03 03:02:11 --> Hooks Class Initialized
DEBUG - 2018-08-03 03:02:11 --> UTF-8 Support Enabled
INFO - 2018-08-03 03:02:11 --> Config Class Initialized
INFO - 2018-08-03 03:02:11 --> Hooks Class Initialized
INFO - 2018-08-03 03:02:11 --> Utf8 Class Initialized
DEBUG - 2018-08-03 03:02:11 --> UTF-8 Support Enabled
INFO - 2018-08-03 03:02:11 --> Utf8 Class Initialized
INFO - 2018-08-03 03:02:11 --> URI Class Initialized
INFO - 2018-08-03 03:02:11 --> Router Class Initialized
INFO - 2018-08-03 03:02:11 --> URI Class Initialized
INFO - 2018-08-03 03:02:11 --> Output Class Initialized
INFO - 2018-08-03 03:02:12 --> Router Class Initialized
INFO - 2018-08-03 03:02:12 --> Output Class Initialized
INFO - 2018-08-03 03:02:12 --> Security Class Initialized
DEBUG - 2018-08-03 03:02:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 03:02:12 --> Input Class Initialized
INFO - 2018-08-03 03:02:12 --> Security Class Initialized
INFO - 2018-08-03 03:02:12 --> Language Class Initialized
ERROR - 2018-08-03 03:02:12 --> 404 Page Not Found: /index
DEBUG - 2018-08-03 03:02:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 03:02:12 --> Input Class Initialized
INFO - 2018-08-03 03:02:12 --> Language Class Initialized
INFO - 2018-08-03 03:02:12 --> Config Class Initialized
INFO - 2018-08-03 03:02:12 --> Hooks Class Initialized
INFO - 2018-08-03 03:02:12 --> Language Class Initialized
DEBUG - 2018-08-03 03:02:12 --> UTF-8 Support Enabled
INFO - 2018-08-03 03:02:12 --> Utf8 Class Initialized
INFO - 2018-08-03 03:02:12 --> Config Class Initialized
INFO - 2018-08-03 03:02:12 --> URI Class Initialized
INFO - 2018-08-03 03:02:12 --> Loader Class Initialized
DEBUG - 2018-08-03 03:02:12 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-03 03:02:12 --> Helper loaded: url_helper
INFO - 2018-08-03 03:02:12 --> Router Class Initialized
INFO - 2018-08-03 03:02:12 --> Helper loaded: form_helper
INFO - 2018-08-03 03:02:12 --> Helper loaded: date_helper
INFO - 2018-08-03 03:02:12 --> Helper loaded: util_helper
INFO - 2018-08-03 03:02:12 --> Output Class Initialized
INFO - 2018-08-03 03:02:12 --> Helper loaded: text_helper
INFO - 2018-08-03 03:02:12 --> Helper loaded: string_helper
INFO - 2018-08-03 03:02:12 --> Database Driver Class Initialized
INFO - 2018-08-03 03:02:12 --> Security Class Initialized
DEBUG - 2018-08-03 03:02:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 03:02:12 --> Input Class Initialized
DEBUG - 2018-08-03 03:02:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 03:02:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-03 03:02:13 --> Language Class Initialized
INFO - 2018-08-03 03:02:13 --> Email Class Initialized
INFO - 2018-08-03 03:02:13 --> Controller Class Initialized
DEBUG - 2018-08-03 03:02:13 --> Home MX_Controller Initialized
DEBUG - 2018-08-03 03:02:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
ERROR - 2018-08-03 03:02:13 --> 404 Page Not Found: /index
DEBUG - 2018-08-03 03:02:13 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-03 03:02:13 --> Login MX_Controller Initialized
INFO - 2018-08-03 03:02:13 --> Config Class Initialized
INFO - 2018-08-03 03:02:13 --> Hooks Class Initialized
INFO - 2018-08-03 03:02:13 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-03 03:02:13 --> UTF-8 Support Enabled
INFO - 2018-08-03 03:02:13 --> Utf8 Class Initialized
INFO - 2018-08-03 03:02:13 --> URI Class Initialized
DEBUG - 2018-08-03 03:02:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-08-03 03:02:13 --> Router Class Initialized
DEBUG - 2018-08-03 03:02:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-03 03:02:13 --> Output Class Initialized
INFO - 2018-08-03 03:02:13 --> Security Class Initialized
DEBUG - 2018-08-03 03:02:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 03:02:13 --> Input Class Initialized
INFO - 2018-08-03 03:02:13 --> Language Class Initialized
ERROR - 2018-08-03 03:02:13 --> 404 Page Not Found: /index
INFO - 2018-08-03 03:02:34 --> Config Class Initialized
INFO - 2018-08-03 03:02:34 --> Hooks Class Initialized
DEBUG - 2018-08-03 03:02:34 --> UTF-8 Support Enabled
INFO - 2018-08-03 03:02:34 --> Utf8 Class Initialized
INFO - 2018-08-03 03:02:34 --> URI Class Initialized
INFO - 2018-08-03 03:02:34 --> Router Class Initialized
INFO - 2018-08-03 03:02:34 --> Output Class Initialized
INFO - 2018-08-03 03:02:34 --> Security Class Initialized
DEBUG - 2018-08-03 03:02:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 03:02:34 --> Input Class Initialized
INFO - 2018-08-03 03:02:34 --> Language Class Initialized
INFO - 2018-08-03 03:02:34 --> Language Class Initialized
INFO - 2018-08-03 03:02:34 --> Config Class Initialized
INFO - 2018-08-03 03:02:34 --> Loader Class Initialized
DEBUG - 2018-08-03 03:02:34 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-03 03:02:34 --> Helper loaded: url_helper
INFO - 2018-08-03 03:02:34 --> Helper loaded: form_helper
INFO - 2018-08-03 03:02:34 --> Helper loaded: date_helper
INFO - 2018-08-03 03:02:34 --> Helper loaded: util_helper
INFO - 2018-08-03 03:02:34 --> Helper loaded: text_helper
INFO - 2018-08-03 03:02:34 --> Helper loaded: string_helper
INFO - 2018-08-03 03:02:34 --> Database Driver Class Initialized
DEBUG - 2018-08-03 03:02:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 03:02:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-03 03:02:34 --> Email Class Initialized
INFO - 2018-08-03 03:02:34 --> Controller Class Initialized
DEBUG - 2018-08-03 03:02:34 --> Admin MX_Controller Initialized
INFO - 2018-08-03 03:02:34 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-03 03:02:34 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-03 03:02:34 --> Login MX_Controller Initialized
DEBUG - 2018-08-03 03:02:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-03 03:02:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-03 03:02:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-08-03 03:02:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-08-03 03:02:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-08-03 03:02:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-08-03 03:02:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-08-03 03:02:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/dashboard.php
INFO - 2018-08-03 03:02:34 --> Final output sent to browser
DEBUG - 2018-08-03 03:02:34 --> Total execution time: 0.8110
INFO - 2018-08-03 03:02:35 --> Config Class Initialized
INFO - 2018-08-03 03:02:35 --> Hooks Class Initialized
DEBUG - 2018-08-03 03:02:35 --> UTF-8 Support Enabled
INFO - 2018-08-03 03:02:35 --> Utf8 Class Initialized
INFO - 2018-08-03 03:02:35 --> URI Class Initialized
INFO - 2018-08-03 03:02:35 --> Router Class Initialized
INFO - 2018-08-03 03:02:35 --> Output Class Initialized
INFO - 2018-08-03 03:02:35 --> Security Class Initialized
DEBUG - 2018-08-03 03:02:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 03:02:35 --> Input Class Initialized
INFO - 2018-08-03 03:02:35 --> Language Class Initialized
INFO - 2018-08-03 03:02:35 --> Language Class Initialized
INFO - 2018-08-03 03:02:35 --> Config Class Initialized
INFO - 2018-08-03 03:02:36 --> Loader Class Initialized
DEBUG - 2018-08-03 03:02:36 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-03 03:02:36 --> Helper loaded: url_helper
INFO - 2018-08-03 03:02:36 --> Helper loaded: form_helper
INFO - 2018-08-03 03:02:36 --> Helper loaded: date_helper
INFO - 2018-08-03 03:02:36 --> Helper loaded: util_helper
INFO - 2018-08-03 03:02:36 --> Helper loaded: text_helper
INFO - 2018-08-03 03:02:36 --> Helper loaded: string_helper
INFO - 2018-08-03 03:02:36 --> Database Driver Class Initialized
DEBUG - 2018-08-03 03:02:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 03:02:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-03 03:02:36 --> Email Class Initialized
INFO - 2018-08-03 03:02:36 --> Controller Class Initialized
DEBUG - 2018-08-03 03:02:36 --> Home MX_Controller Initialized
DEBUG - 2018-08-03 03:02:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-03 03:02:36 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-03 03:02:36 --> Login MX_Controller Initialized
INFO - 2018-08-03 03:02:36 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-03 03:02:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-03 03:02:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-03 03:02:45 --> Config Class Initialized
INFO - 2018-08-03 03:02:45 --> Hooks Class Initialized
DEBUG - 2018-08-03 03:02:45 --> UTF-8 Support Enabled
INFO - 2018-08-03 03:02:45 --> Utf8 Class Initialized
INFO - 2018-08-03 03:02:45 --> URI Class Initialized
INFO - 2018-08-03 03:02:45 --> Router Class Initialized
INFO - 2018-08-03 03:02:45 --> Output Class Initialized
INFO - 2018-08-03 03:02:45 --> Security Class Initialized
DEBUG - 2018-08-03 03:02:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 03:02:45 --> Input Class Initialized
INFO - 2018-08-03 03:02:45 --> Language Class Initialized
INFO - 2018-08-03 03:02:45 --> Language Class Initialized
INFO - 2018-08-03 03:02:45 --> Config Class Initialized
INFO - 2018-08-03 03:02:45 --> Loader Class Initialized
DEBUG - 2018-08-03 03:02:45 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-03 03:02:45 --> Helper loaded: url_helper
INFO - 2018-08-03 03:02:45 --> Helper loaded: form_helper
INFO - 2018-08-03 03:02:45 --> Helper loaded: date_helper
INFO - 2018-08-03 03:02:45 --> Helper loaded: util_helper
INFO - 2018-08-03 03:02:45 --> Helper loaded: text_helper
INFO - 2018-08-03 03:02:45 --> Helper loaded: string_helper
INFO - 2018-08-03 03:02:45 --> Database Driver Class Initialized
DEBUG - 2018-08-03 03:02:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 03:02:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-03 03:02:45 --> Email Class Initialized
INFO - 2018-08-03 03:02:45 --> Controller Class Initialized
DEBUG - 2018-08-03 03:02:45 --> Home MX_Controller Initialized
DEBUG - 2018-08-03 03:02:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-03 03:02:45 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-03 03:02:45 --> Login MX_Controller Initialized
INFO - 2018-08-03 03:02:45 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-03 03:02:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-03 03:02:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-03 03:02:46 --> Config Class Initialized
INFO - 2018-08-03 03:02:46 --> Hooks Class Initialized
DEBUG - 2018-08-03 03:02:46 --> UTF-8 Support Enabled
INFO - 2018-08-03 03:02:46 --> Utf8 Class Initialized
INFO - 2018-08-03 03:02:47 --> URI Class Initialized
INFO - 2018-08-03 03:02:47 --> Router Class Initialized
INFO - 2018-08-03 03:02:47 --> Output Class Initialized
INFO - 2018-08-03 03:02:47 --> Security Class Initialized
DEBUG - 2018-08-03 03:02:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 03:02:47 --> Input Class Initialized
INFO - 2018-08-03 03:02:47 --> Language Class Initialized
INFO - 2018-08-03 03:02:47 --> Language Class Initialized
INFO - 2018-08-03 03:02:47 --> Config Class Initialized
INFO - 2018-08-03 03:02:47 --> Loader Class Initialized
DEBUG - 2018-08-03 03:02:47 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-03 03:02:47 --> Helper loaded: url_helper
INFO - 2018-08-03 03:02:47 --> Helper loaded: form_helper
INFO - 2018-08-03 03:02:47 --> Helper loaded: date_helper
INFO - 2018-08-03 03:02:47 --> Helper loaded: util_helper
INFO - 2018-08-03 03:02:47 --> Helper loaded: text_helper
INFO - 2018-08-03 03:02:47 --> Helper loaded: string_helper
INFO - 2018-08-03 03:02:47 --> Database Driver Class Initialized
DEBUG - 2018-08-03 03:02:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 03:02:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-03 03:02:47 --> Email Class Initialized
INFO - 2018-08-03 03:02:47 --> Controller Class Initialized
DEBUG - 2018-08-03 03:02:47 --> Home MX_Controller Initialized
DEBUG - 2018-08-03 03:02:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-03 03:02:47 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-03 03:02:47 --> Login MX_Controller Initialized
INFO - 2018-08-03 03:02:47 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-03 03:02:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-03 03:02:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-03 03:02:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-08-03 03:02:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-08-03 03:02:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-08-03 03:02:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-08-03 03:02:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-08-03 03:02:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-08-03 03:02:47 --> Final output sent to browser
DEBUG - 2018-08-03 03:02:47 --> Total execution time: 0.8389
INFO - 2018-08-03 03:02:48 --> Config Class Initialized
INFO - 2018-08-03 03:02:48 --> Hooks Class Initialized
DEBUG - 2018-08-03 03:02:48 --> UTF-8 Support Enabled
INFO - 2018-08-03 03:02:48 --> Utf8 Class Initialized
INFO - 2018-08-03 03:02:48 --> Config Class Initialized
INFO - 2018-08-03 03:02:48 --> Hooks Class Initialized
INFO - 2018-08-03 03:02:48 --> URI Class Initialized
INFO - 2018-08-03 03:02:48 --> Router Class Initialized
DEBUG - 2018-08-03 03:02:48 --> UTF-8 Support Enabled
INFO - 2018-08-03 03:02:48 --> Output Class Initialized
INFO - 2018-08-03 03:02:48 --> Utf8 Class Initialized
INFO - 2018-08-03 03:02:48 --> Security Class Initialized
INFO - 2018-08-03 03:02:48 --> URI Class Initialized
DEBUG - 2018-08-03 03:02:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 03:02:48 --> Router Class Initialized
INFO - 2018-08-03 03:02:48 --> Input Class Initialized
INFO - 2018-08-03 03:02:48 --> Output Class Initialized
INFO - 2018-08-03 03:02:48 --> Language Class Initialized
ERROR - 2018-08-03 03:02:48 --> 404 Page Not Found: /index
INFO - 2018-08-03 03:02:48 --> Security Class Initialized
DEBUG - 2018-08-03 03:02:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 03:02:49 --> Input Class Initialized
INFO - 2018-08-03 03:02:49 --> Language Class Initialized
INFO - 2018-08-03 03:02:49 --> Config Class Initialized
INFO - 2018-08-03 03:02:49 --> Hooks Class Initialized
INFO - 2018-08-03 03:02:49 --> Language Class Initialized
INFO - 2018-08-03 03:02:49 --> Config Class Initialized
DEBUG - 2018-08-03 03:02:49 --> UTF-8 Support Enabled
INFO - 2018-08-03 03:02:49 --> Loader Class Initialized
INFO - 2018-08-03 03:02:49 --> Utf8 Class Initialized
DEBUG - 2018-08-03 03:02:49 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-03 03:02:49 --> Helper loaded: url_helper
INFO - 2018-08-03 03:02:49 --> URI Class Initialized
INFO - 2018-08-03 03:02:49 --> Router Class Initialized
INFO - 2018-08-03 03:02:49 --> Helper loaded: form_helper
INFO - 2018-08-03 03:02:49 --> Output Class Initialized
INFO - 2018-08-03 03:02:49 --> Helper loaded: date_helper
INFO - 2018-08-03 03:02:49 --> Security Class Initialized
INFO - 2018-08-03 03:02:49 --> Helper loaded: util_helper
INFO - 2018-08-03 03:02:49 --> Helper loaded: text_helper
DEBUG - 2018-08-03 03:02:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 03:02:49 --> Helper loaded: string_helper
INFO - 2018-08-03 03:02:49 --> Input Class Initialized
INFO - 2018-08-03 03:02:49 --> Database Driver Class Initialized
INFO - 2018-08-03 03:02:49 --> Language Class Initialized
DEBUG - 2018-08-03 03:02:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 03:02:49 --> Session: Class initialized using 'files' driver.
ERROR - 2018-08-03 03:02:49 --> 404 Page Not Found: /index
INFO - 2018-08-03 03:02:49 --> Email Class Initialized
INFO - 2018-08-03 03:02:49 --> Config Class Initialized
INFO - 2018-08-03 03:02:49 --> Hooks Class Initialized
INFO - 2018-08-03 03:02:49 --> Controller Class Initialized
DEBUG - 2018-08-03 03:02:49 --> Home MX_Controller Initialized
DEBUG - 2018-08-03 03:02:49 --> UTF-8 Support Enabled
DEBUG - 2018-08-03 03:02:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-08-03 03:02:49 --> Utf8 Class Initialized
DEBUG - 2018-08-03 03:02:49 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-03 03:02:49 --> Login MX_Controller Initialized
INFO - 2018-08-03 03:02:49 --> URI Class Initialized
INFO - 2018-08-03 03:02:49 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-03 03:02:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-03 03:02:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-03 03:02:49 --> Router Class Initialized
INFO - 2018-08-03 03:02:49 --> Output Class Initialized
INFO - 2018-08-03 03:02:49 --> Security Class Initialized
DEBUG - 2018-08-03 03:02:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 03:02:49 --> Input Class Initialized
INFO - 2018-08-03 03:02:49 --> Language Class Initialized
ERROR - 2018-08-03 03:02:49 --> 404 Page Not Found: /index
INFO - 2018-08-03 03:04:03 --> Config Class Initialized
INFO - 2018-08-03 03:04:03 --> Hooks Class Initialized
DEBUG - 2018-08-03 03:04:03 --> UTF-8 Support Enabled
INFO - 2018-08-03 03:04:03 --> Utf8 Class Initialized
INFO - 2018-08-03 03:04:03 --> URI Class Initialized
INFO - 2018-08-03 03:04:03 --> Router Class Initialized
INFO - 2018-08-03 03:04:03 --> Output Class Initialized
INFO - 2018-08-03 03:04:03 --> Security Class Initialized
DEBUG - 2018-08-03 03:04:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 03:04:03 --> Input Class Initialized
INFO - 2018-08-03 03:04:03 --> Language Class Initialized
INFO - 2018-08-03 03:04:03 --> Language Class Initialized
INFO - 2018-08-03 03:04:03 --> Config Class Initialized
INFO - 2018-08-03 03:04:03 --> Loader Class Initialized
DEBUG - 2018-08-03 03:04:03 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-03 03:04:03 --> Helper loaded: url_helper
INFO - 2018-08-03 03:04:03 --> Helper loaded: form_helper
INFO - 2018-08-03 03:04:03 --> Helper loaded: date_helper
INFO - 2018-08-03 03:04:03 --> Helper loaded: util_helper
INFO - 2018-08-03 03:04:03 --> Helper loaded: text_helper
INFO - 2018-08-03 03:04:03 --> Helper loaded: string_helper
INFO - 2018-08-03 03:04:03 --> Database Driver Class Initialized
DEBUG - 2018-08-03 03:04:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 03:04:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-03 03:04:04 --> Email Class Initialized
INFO - 2018-08-03 03:04:04 --> Controller Class Initialized
DEBUG - 2018-08-03 03:04:04 --> Admin MX_Controller Initialized
INFO - 2018-08-03 03:04:04 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-03 03:04:04 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-03 03:04:04 --> Login MX_Controller Initialized
DEBUG - 2018-08-03 03:04:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-03 03:04:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-03 03:04:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-08-03 03:04:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-08-03 03:04:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-08-03 03:04:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-08-03 03:04:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-08-03 03:04:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/dashboard.php
INFO - 2018-08-03 03:04:04 --> Final output sent to browser
DEBUG - 2018-08-03 03:04:04 --> Total execution time: 0.8020
INFO - 2018-08-03 03:04:04 --> Config Class Initialized
INFO - 2018-08-03 03:04:04 --> Hooks Class Initialized
DEBUG - 2018-08-03 03:04:04 --> UTF-8 Support Enabled
INFO - 2018-08-03 03:04:04 --> Utf8 Class Initialized
INFO - 2018-08-03 03:04:04 --> URI Class Initialized
INFO - 2018-08-03 03:04:05 --> Router Class Initialized
INFO - 2018-08-03 03:04:05 --> Output Class Initialized
INFO - 2018-08-03 03:04:05 --> Security Class Initialized
DEBUG - 2018-08-03 03:04:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 03:04:05 --> Input Class Initialized
INFO - 2018-08-03 03:04:05 --> Language Class Initialized
INFO - 2018-08-03 03:04:05 --> Language Class Initialized
INFO - 2018-08-03 03:04:05 --> Config Class Initialized
INFO - 2018-08-03 03:04:05 --> Loader Class Initialized
DEBUG - 2018-08-03 03:04:05 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-03 03:04:05 --> Helper loaded: url_helper
INFO - 2018-08-03 03:04:05 --> Helper loaded: form_helper
INFO - 2018-08-03 03:04:05 --> Helper loaded: date_helper
INFO - 2018-08-03 03:04:05 --> Helper loaded: util_helper
INFO - 2018-08-03 03:04:05 --> Helper loaded: text_helper
INFO - 2018-08-03 03:04:05 --> Helper loaded: string_helper
INFO - 2018-08-03 03:04:05 --> Database Driver Class Initialized
DEBUG - 2018-08-03 03:04:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 03:04:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-03 03:04:05 --> Email Class Initialized
INFO - 2018-08-03 03:04:05 --> Controller Class Initialized
DEBUG - 2018-08-03 03:04:05 --> Home MX_Controller Initialized
DEBUG - 2018-08-03 03:04:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-03 03:04:05 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-03 03:04:05 --> Login MX_Controller Initialized
INFO - 2018-08-03 03:04:05 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-03 03:04:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-03 03:04:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-03 03:04:06 --> Config Class Initialized
INFO - 2018-08-03 03:04:06 --> Hooks Class Initialized
DEBUG - 2018-08-03 03:04:06 --> UTF-8 Support Enabled
INFO - 2018-08-03 03:04:06 --> Utf8 Class Initialized
INFO - 2018-08-03 03:04:06 --> URI Class Initialized
INFO - 2018-08-03 03:04:07 --> Router Class Initialized
INFO - 2018-08-03 03:04:07 --> Output Class Initialized
INFO - 2018-08-03 03:04:07 --> Security Class Initialized
DEBUG - 2018-08-03 03:04:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 03:04:07 --> Input Class Initialized
INFO - 2018-08-03 03:04:07 --> Language Class Initialized
INFO - 2018-08-03 03:04:07 --> Language Class Initialized
INFO - 2018-08-03 03:04:07 --> Config Class Initialized
INFO - 2018-08-03 03:04:07 --> Loader Class Initialized
DEBUG - 2018-08-03 03:04:07 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-03 03:04:07 --> Helper loaded: url_helper
INFO - 2018-08-03 03:04:07 --> Helper loaded: form_helper
INFO - 2018-08-03 03:04:07 --> Helper loaded: date_helper
INFO - 2018-08-03 03:04:07 --> Helper loaded: util_helper
INFO - 2018-08-03 03:04:07 --> Helper loaded: text_helper
INFO - 2018-08-03 03:04:07 --> Helper loaded: string_helper
INFO - 2018-08-03 03:04:07 --> Database Driver Class Initialized
DEBUG - 2018-08-03 03:04:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 03:04:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-03 03:04:07 --> Email Class Initialized
INFO - 2018-08-03 03:04:07 --> Controller Class Initialized
DEBUG - 2018-08-03 03:04:07 --> Home MX_Controller Initialized
DEBUG - 2018-08-03 03:04:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-03 03:04:07 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-03 03:04:07 --> Login MX_Controller Initialized
INFO - 2018-08-03 03:04:07 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-03 03:04:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-03 03:04:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-03 03:04:10 --> Config Class Initialized
INFO - 2018-08-03 03:04:10 --> Hooks Class Initialized
DEBUG - 2018-08-03 03:04:10 --> UTF-8 Support Enabled
INFO - 2018-08-03 03:04:10 --> Utf8 Class Initialized
INFO - 2018-08-03 03:04:10 --> URI Class Initialized
INFO - 2018-08-03 03:04:10 --> Router Class Initialized
INFO - 2018-08-03 03:04:10 --> Output Class Initialized
INFO - 2018-08-03 03:04:10 --> Security Class Initialized
DEBUG - 2018-08-03 03:04:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 03:04:10 --> Input Class Initialized
INFO - 2018-08-03 03:04:10 --> Language Class Initialized
INFO - 2018-08-03 03:04:10 --> Language Class Initialized
INFO - 2018-08-03 03:04:10 --> Config Class Initialized
INFO - 2018-08-03 03:04:10 --> Loader Class Initialized
DEBUG - 2018-08-03 03:04:10 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-03 03:04:10 --> Helper loaded: url_helper
INFO - 2018-08-03 03:04:10 --> Helper loaded: form_helper
INFO - 2018-08-03 03:04:10 --> Helper loaded: date_helper
INFO - 2018-08-03 03:04:10 --> Helper loaded: util_helper
INFO - 2018-08-03 03:04:10 --> Helper loaded: text_helper
INFO - 2018-08-03 03:04:10 --> Helper loaded: string_helper
INFO - 2018-08-03 03:04:10 --> Database Driver Class Initialized
DEBUG - 2018-08-03 03:04:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 03:04:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-03 03:04:10 --> Email Class Initialized
INFO - 2018-08-03 03:04:10 --> Controller Class Initialized
DEBUG - 2018-08-03 03:04:10 --> Home MX_Controller Initialized
DEBUG - 2018-08-03 03:04:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-03 03:04:10 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-03 03:04:10 --> Login MX_Controller Initialized
INFO - 2018-08-03 03:04:10 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-03 03:04:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-03 03:04:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-03 03:04:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-08-03 03:04:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-08-03 03:04:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-08-03 03:04:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-08-03 03:04:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-08-03 03:04:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-08-03 03:04:10 --> Final output sent to browser
DEBUG - 2018-08-03 03:04:11 --> Total execution time: 0.8374
INFO - 2018-08-03 03:04:11 --> Config Class Initialized
INFO - 2018-08-03 03:04:11 --> Hooks Class Initialized
DEBUG - 2018-08-03 03:04:11 --> UTF-8 Support Enabled
INFO - 2018-08-03 03:04:11 --> Config Class Initialized
INFO - 2018-08-03 03:04:11 --> Hooks Class Initialized
INFO - 2018-08-03 03:04:11 --> Utf8 Class Initialized
DEBUG - 2018-08-03 03:04:11 --> UTF-8 Support Enabled
INFO - 2018-08-03 03:04:11 --> Utf8 Class Initialized
INFO - 2018-08-03 03:04:11 --> URI Class Initialized
INFO - 2018-08-03 03:04:11 --> URI Class Initialized
INFO - 2018-08-03 03:04:11 --> Router Class Initialized
INFO - 2018-08-03 03:04:12 --> Output Class Initialized
INFO - 2018-08-03 03:04:12 --> Router Class Initialized
INFO - 2018-08-03 03:04:12 --> Security Class Initialized
INFO - 2018-08-03 03:04:12 --> Output Class Initialized
INFO - 2018-08-03 03:04:12 --> Security Class Initialized
DEBUG - 2018-08-03 03:04:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-08-03 03:04:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 03:04:12 --> Input Class Initialized
INFO - 2018-08-03 03:04:12 --> Input Class Initialized
INFO - 2018-08-03 03:04:12 --> Language Class Initialized
INFO - 2018-08-03 03:04:12 --> Language Class Initialized
ERROR - 2018-08-03 03:04:12 --> 404 Page Not Found: /index
INFO - 2018-08-03 03:04:12 --> Language Class Initialized
INFO - 2018-08-03 03:04:12 --> Config Class Initialized
INFO - 2018-08-03 03:04:12 --> Config Class Initialized
INFO - 2018-08-03 03:04:12 --> Hooks Class Initialized
INFO - 2018-08-03 03:04:12 --> Loader Class Initialized
DEBUG - 2018-08-03 03:04:12 --> UTF-8 Support Enabled
INFO - 2018-08-03 03:04:12 --> Utf8 Class Initialized
INFO - 2018-08-03 03:04:12 --> URI Class Initialized
DEBUG - 2018-08-03 03:04:12 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-03 03:04:12 --> Router Class Initialized
INFO - 2018-08-03 03:04:12 --> Helper loaded: url_helper
INFO - 2018-08-03 03:04:12 --> Output Class Initialized
INFO - 2018-08-03 03:04:12 --> Helper loaded: form_helper
INFO - 2018-08-03 03:04:12 --> Security Class Initialized
INFO - 2018-08-03 03:04:12 --> Helper loaded: date_helper
INFO - 2018-08-03 03:04:12 --> Helper loaded: util_helper
DEBUG - 2018-08-03 03:04:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 03:04:12 --> Helper loaded: text_helper
INFO - 2018-08-03 03:04:12 --> Helper loaded: string_helper
INFO - 2018-08-03 03:04:12 --> Input Class Initialized
INFO - 2018-08-03 03:04:12 --> Database Driver Class Initialized
INFO - 2018-08-03 03:04:12 --> Language Class Initialized
DEBUG - 2018-08-03 03:04:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 03:04:12 --> Session: Class initialized using 'files' driver.
ERROR - 2018-08-03 03:04:12 --> 404 Page Not Found: /index
INFO - 2018-08-03 03:04:12 --> Email Class Initialized
INFO - 2018-08-03 03:04:12 --> Config Class Initialized
INFO - 2018-08-03 03:04:12 --> Controller Class Initialized
DEBUG - 2018-08-03 03:04:12 --> Home MX_Controller Initialized
DEBUG - 2018-08-03 03:04:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-08-03 03:04:12 --> Hooks Class Initialized
DEBUG - 2018-08-03 03:04:12 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-03 03:04:13 --> Login MX_Controller Initialized
DEBUG - 2018-08-03 03:04:13 --> UTF-8 Support Enabled
INFO - 2018-08-03 03:04:13 --> Language file loaded: language/english/data_lang.php
INFO - 2018-08-03 03:04:13 --> Utf8 Class Initialized
DEBUG - 2018-08-03 03:04:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-03 03:04:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-03 03:04:13 --> URI Class Initialized
INFO - 2018-08-03 03:04:13 --> Router Class Initialized
INFO - 2018-08-03 03:04:13 --> Output Class Initialized
INFO - 2018-08-03 03:04:13 --> Security Class Initialized
DEBUG - 2018-08-03 03:04:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 03:04:13 --> Input Class Initialized
INFO - 2018-08-03 03:04:13 --> Language Class Initialized
ERROR - 2018-08-03 03:04:13 --> 404 Page Not Found: /index
INFO - 2018-08-03 03:04:29 --> Config Class Initialized
INFO - 2018-08-03 03:04:29 --> Hooks Class Initialized
DEBUG - 2018-08-03 03:04:29 --> UTF-8 Support Enabled
INFO - 2018-08-03 03:04:29 --> Utf8 Class Initialized
INFO - 2018-08-03 03:04:29 --> URI Class Initialized
INFO - 2018-08-03 03:04:29 --> Router Class Initialized
INFO - 2018-08-03 03:04:29 --> Output Class Initialized
INFO - 2018-08-03 03:04:29 --> Security Class Initialized
DEBUG - 2018-08-03 03:04:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 03:04:29 --> Input Class Initialized
INFO - 2018-08-03 03:04:29 --> Language Class Initialized
INFO - 2018-08-03 03:04:29 --> Language Class Initialized
INFO - 2018-08-03 03:04:29 --> Config Class Initialized
INFO - 2018-08-03 03:04:29 --> Loader Class Initialized
DEBUG - 2018-08-03 03:04:29 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-03 03:04:29 --> Helper loaded: url_helper
INFO - 2018-08-03 03:04:29 --> Helper loaded: form_helper
INFO - 2018-08-03 03:04:29 --> Helper loaded: date_helper
INFO - 2018-08-03 03:04:29 --> Helper loaded: util_helper
INFO - 2018-08-03 03:04:29 --> Helper loaded: text_helper
INFO - 2018-08-03 03:04:29 --> Helper loaded: string_helper
INFO - 2018-08-03 03:04:29 --> Database Driver Class Initialized
DEBUG - 2018-08-03 03:04:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 03:04:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-03 03:04:29 --> Email Class Initialized
INFO - 2018-08-03 03:04:29 --> Controller Class Initialized
DEBUG - 2018-08-03 03:04:29 --> Home MX_Controller Initialized
DEBUG - 2018-08-03 03:04:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-03 03:04:29 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-03 03:04:29 --> Login MX_Controller Initialized
INFO - 2018-08-03 03:04:29 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-03 03:04:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-03 03:04:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-03 03:04:31 --> Config Class Initialized
INFO - 2018-08-03 03:04:31 --> Hooks Class Initialized
DEBUG - 2018-08-03 03:04:31 --> UTF-8 Support Enabled
INFO - 2018-08-03 03:04:31 --> Utf8 Class Initialized
INFO - 2018-08-03 03:04:31 --> URI Class Initialized
INFO - 2018-08-03 03:04:31 --> Router Class Initialized
INFO - 2018-08-03 03:04:31 --> Output Class Initialized
INFO - 2018-08-03 03:04:31 --> Security Class Initialized
DEBUG - 2018-08-03 03:04:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 03:04:31 --> Input Class Initialized
INFO - 2018-08-03 03:04:31 --> Language Class Initialized
INFO - 2018-08-03 03:04:31 --> Language Class Initialized
INFO - 2018-08-03 03:04:31 --> Config Class Initialized
INFO - 2018-08-03 03:04:31 --> Loader Class Initialized
DEBUG - 2018-08-03 03:04:31 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-03 03:04:31 --> Helper loaded: url_helper
INFO - 2018-08-03 03:04:31 --> Helper loaded: form_helper
INFO - 2018-08-03 03:04:31 --> Helper loaded: date_helper
INFO - 2018-08-03 03:04:32 --> Helper loaded: util_helper
INFO - 2018-08-03 03:04:32 --> Helper loaded: text_helper
INFO - 2018-08-03 03:04:32 --> Helper loaded: string_helper
INFO - 2018-08-03 03:04:32 --> Database Driver Class Initialized
DEBUG - 2018-08-03 03:04:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 03:04:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-03 03:04:32 --> Email Class Initialized
INFO - 2018-08-03 03:04:32 --> Controller Class Initialized
DEBUG - 2018-08-03 03:04:32 --> Home MX_Controller Initialized
DEBUG - 2018-08-03 03:04:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-03 03:04:32 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-03 03:04:32 --> Login MX_Controller Initialized
INFO - 2018-08-03 03:04:32 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-03 03:04:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-03 03:04:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-03 03:04:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-08-03 03:04:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-08-03 03:04:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-08-03 03:04:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-08-03 03:04:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-08-03 03:04:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-08-03 03:04:32 --> Final output sent to browser
DEBUG - 2018-08-03 03:04:32 --> Total execution time: 0.8408
INFO - 2018-08-03 03:04:33 --> Config Class Initialized
INFO - 2018-08-03 03:04:33 --> Hooks Class Initialized
DEBUG - 2018-08-03 03:04:33 --> UTF-8 Support Enabled
INFO - 2018-08-03 03:04:33 --> Utf8 Class Initialized
INFO - 2018-08-03 03:04:33 --> Config Class Initialized
INFO - 2018-08-03 03:04:33 --> Hooks Class Initialized
INFO - 2018-08-03 03:04:33 --> URI Class Initialized
DEBUG - 2018-08-03 03:04:33 --> UTF-8 Support Enabled
INFO - 2018-08-03 03:04:33 --> Utf8 Class Initialized
INFO - 2018-08-03 03:04:33 --> URI Class Initialized
INFO - 2018-08-03 03:04:33 --> Router Class Initialized
INFO - 2018-08-03 03:04:33 --> Router Class Initialized
INFO - 2018-08-03 03:04:33 --> Output Class Initialized
INFO - 2018-08-03 03:04:33 --> Output Class Initialized
INFO - 2018-08-03 03:04:33 --> Security Class Initialized
DEBUG - 2018-08-03 03:04:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 03:04:33 --> Input Class Initialized
INFO - 2018-08-03 03:04:33 --> Language Class Initialized
INFO - 2018-08-03 03:04:33 --> Security Class Initialized
ERROR - 2018-08-03 03:04:33 --> 404 Page Not Found: /index
DEBUG - 2018-08-03 03:04:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 03:04:33 --> Config Class Initialized
INFO - 2018-08-03 03:04:33 --> Hooks Class Initialized
INFO - 2018-08-03 03:04:33 --> Input Class Initialized
DEBUG - 2018-08-03 03:04:33 --> UTF-8 Support Enabled
INFO - 2018-08-03 03:04:33 --> Utf8 Class Initialized
INFO - 2018-08-03 03:04:33 --> URI Class Initialized
INFO - 2018-08-03 03:04:33 --> Language Class Initialized
INFO - 2018-08-03 03:04:33 --> Router Class Initialized
INFO - 2018-08-03 03:04:33 --> Output Class Initialized
INFO - 2018-08-03 03:04:33 --> Language Class Initialized
INFO - 2018-08-03 03:04:33 --> Config Class Initialized
INFO - 2018-08-03 03:04:33 --> Security Class Initialized
INFO - 2018-08-03 03:04:34 --> Loader Class Initialized
DEBUG - 2018-08-03 03:04:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 03:04:34 --> Input Class Initialized
DEBUG - 2018-08-03 03:04:34 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-03 03:04:34 --> Language Class Initialized
INFO - 2018-08-03 03:04:34 --> Helper loaded: url_helper
ERROR - 2018-08-03 03:04:34 --> 404 Page Not Found: /index
INFO - 2018-08-03 03:04:34 --> Helper loaded: form_helper
INFO - 2018-08-03 03:04:34 --> Config Class Initialized
INFO - 2018-08-03 03:04:34 --> Hooks Class Initialized
DEBUG - 2018-08-03 03:04:34 --> UTF-8 Support Enabled
INFO - 2018-08-03 03:04:34 --> Utf8 Class Initialized
INFO - 2018-08-03 03:04:34 --> URI Class Initialized
INFO - 2018-08-03 03:04:34 --> Router Class Initialized
INFO - 2018-08-03 03:04:34 --> Output Class Initialized
INFO - 2018-08-03 03:04:34 --> Security Class Initialized
DEBUG - 2018-08-03 03:04:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 03:04:34 --> Input Class Initialized
INFO - 2018-08-03 03:04:34 --> Language Class Initialized
ERROR - 2018-08-03 03:04:34 --> 404 Page Not Found: /index
INFO - 2018-08-03 03:04:34 --> Helper loaded: date_helper
INFO - 2018-08-03 03:04:34 --> Helper loaded: util_helper
INFO - 2018-08-03 03:04:34 --> Helper loaded: text_helper
INFO - 2018-08-03 03:04:34 --> Helper loaded: string_helper
INFO - 2018-08-03 03:04:35 --> Database Driver Class Initialized
DEBUG - 2018-08-03 03:04:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 03:04:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-03 03:04:35 --> Email Class Initialized
INFO - 2018-08-03 03:04:35 --> Controller Class Initialized
DEBUG - 2018-08-03 03:04:35 --> Home MX_Controller Initialized
DEBUG - 2018-08-03 03:04:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-03 03:04:35 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-03 03:04:35 --> Login MX_Controller Initialized
INFO - 2018-08-03 03:04:35 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-03 03:04:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-03 03:04:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-03 03:04:39 --> Config Class Initialized
INFO - 2018-08-03 03:04:39 --> Hooks Class Initialized
DEBUG - 2018-08-03 03:04:39 --> UTF-8 Support Enabled
INFO - 2018-08-03 03:04:39 --> Utf8 Class Initialized
INFO - 2018-08-03 03:04:39 --> URI Class Initialized
INFO - 2018-08-03 03:04:39 --> Router Class Initialized
INFO - 2018-08-03 03:04:39 --> Output Class Initialized
INFO - 2018-08-03 03:04:39 --> Security Class Initialized
DEBUG - 2018-08-03 03:04:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 03:04:39 --> Input Class Initialized
INFO - 2018-08-03 03:04:39 --> Language Class Initialized
INFO - 2018-08-03 03:04:39 --> Language Class Initialized
INFO - 2018-08-03 03:04:39 --> Config Class Initialized
INFO - 2018-08-03 03:04:39 --> Loader Class Initialized
DEBUG - 2018-08-03 03:04:39 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-03 03:04:39 --> Helper loaded: url_helper
INFO - 2018-08-03 03:04:39 --> Helper loaded: form_helper
INFO - 2018-08-03 03:04:39 --> Helper loaded: date_helper
INFO - 2018-08-03 03:04:39 --> Helper loaded: util_helper
INFO - 2018-08-03 03:04:39 --> Helper loaded: text_helper
INFO - 2018-08-03 03:04:39 --> Helper loaded: string_helper
INFO - 2018-08-03 03:04:39 --> Database Driver Class Initialized
DEBUG - 2018-08-03 03:04:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 03:04:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-03 03:04:40 --> Email Class Initialized
INFO - 2018-08-03 03:04:40 --> Controller Class Initialized
DEBUG - 2018-08-03 03:04:40 --> Home MX_Controller Initialized
DEBUG - 2018-08-03 03:04:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-03 03:04:40 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-03 03:04:40 --> Login MX_Controller Initialized
INFO - 2018-08-03 03:04:40 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-03 03:04:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-03 03:04:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-03 03:04:40 --> Config Class Initialized
INFO - 2018-08-03 03:04:40 --> Hooks Class Initialized
DEBUG - 2018-08-03 03:04:40 --> UTF-8 Support Enabled
INFO - 2018-08-03 03:04:41 --> Utf8 Class Initialized
INFO - 2018-08-03 03:04:41 --> URI Class Initialized
INFO - 2018-08-03 03:04:41 --> Router Class Initialized
INFO - 2018-08-03 03:04:41 --> Output Class Initialized
INFO - 2018-08-03 03:04:41 --> Security Class Initialized
DEBUG - 2018-08-03 03:04:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 03:04:41 --> Input Class Initialized
INFO - 2018-08-03 03:04:41 --> Language Class Initialized
INFO - 2018-08-03 03:04:41 --> Language Class Initialized
INFO - 2018-08-03 03:04:41 --> Config Class Initialized
INFO - 2018-08-03 03:04:41 --> Loader Class Initialized
DEBUG - 2018-08-03 03:04:41 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-03 03:04:41 --> Helper loaded: url_helper
INFO - 2018-08-03 03:04:41 --> Helper loaded: form_helper
INFO - 2018-08-03 03:04:41 --> Helper loaded: date_helper
INFO - 2018-08-03 03:04:41 --> Helper loaded: util_helper
INFO - 2018-08-03 03:04:41 --> Helper loaded: text_helper
INFO - 2018-08-03 03:04:41 --> Helper loaded: string_helper
INFO - 2018-08-03 03:04:41 --> Database Driver Class Initialized
DEBUG - 2018-08-03 03:04:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 03:04:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-03 03:04:41 --> Email Class Initialized
INFO - 2018-08-03 03:04:41 --> Controller Class Initialized
DEBUG - 2018-08-03 03:04:41 --> Home MX_Controller Initialized
DEBUG - 2018-08-03 03:04:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-03 03:04:41 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-03 03:04:41 --> Login MX_Controller Initialized
INFO - 2018-08-03 03:04:41 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-03 03:04:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-03 03:04:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-03 03:04:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-08-03 03:04:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-08-03 03:04:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-08-03 03:04:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-08-03 03:04:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-08-03 03:04:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-08-03 03:04:41 --> Final output sent to browser
DEBUG - 2018-08-03 03:04:41 --> Total execution time: 0.8746
INFO - 2018-08-03 03:04:42 --> Config Class Initialized
INFO - 2018-08-03 03:04:42 --> Hooks Class Initialized
DEBUG - 2018-08-03 03:04:42 --> UTF-8 Support Enabled
INFO - 2018-08-03 03:04:42 --> Config Class Initialized
INFO - 2018-08-03 03:04:42 --> Utf8 Class Initialized
INFO - 2018-08-03 03:04:42 --> Hooks Class Initialized
DEBUG - 2018-08-03 03:04:42 --> UTF-8 Support Enabled
INFO - 2018-08-03 03:04:42 --> Utf8 Class Initialized
INFO - 2018-08-03 03:04:42 --> URI Class Initialized
INFO - 2018-08-03 03:04:42 --> Router Class Initialized
INFO - 2018-08-03 03:04:42 --> URI Class Initialized
INFO - 2018-08-03 03:04:42 --> Output Class Initialized
INFO - 2018-08-03 03:04:42 --> Router Class Initialized
INFO - 2018-08-03 03:04:42 --> Security Class Initialized
INFO - 2018-08-03 03:04:42 --> Output Class Initialized
DEBUG - 2018-08-03 03:04:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 03:04:42 --> Security Class Initialized
DEBUG - 2018-08-03 03:04:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 03:04:43 --> Input Class Initialized
INFO - 2018-08-03 03:04:43 --> Input Class Initialized
INFO - 2018-08-03 03:04:43 --> Language Class Initialized
INFO - 2018-08-03 03:04:43 --> Language Class Initialized
ERROR - 2018-08-03 03:04:43 --> 404 Page Not Found: /index
INFO - 2018-08-03 03:04:43 --> Language Class Initialized
INFO - 2018-08-03 03:04:43 --> Config Class Initialized
INFO - 2018-08-03 03:04:43 --> Loader Class Initialized
DEBUG - 2018-08-03 03:04:43 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-03 03:04:43 --> Config Class Initialized
INFO - 2018-08-03 03:04:43 --> Helper loaded: url_helper
INFO - 2018-08-03 03:04:43 --> Hooks Class Initialized
DEBUG - 2018-08-03 03:04:43 --> UTF-8 Support Enabled
INFO - 2018-08-03 03:04:43 --> Utf8 Class Initialized
INFO - 2018-08-03 03:04:43 --> URI Class Initialized
INFO - 2018-08-03 03:04:43 --> Helper loaded: form_helper
INFO - 2018-08-03 03:04:43 --> Router Class Initialized
INFO - 2018-08-03 03:04:43 --> Helper loaded: date_helper
INFO - 2018-08-03 03:04:43 --> Output Class Initialized
INFO - 2018-08-03 03:04:43 --> Helper loaded: util_helper
INFO - 2018-08-03 03:04:43 --> Security Class Initialized
INFO - 2018-08-03 03:04:43 --> Helper loaded: text_helper
DEBUG - 2018-08-03 03:04:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 03:04:43 --> Helper loaded: string_helper
INFO - 2018-08-03 03:04:43 --> Input Class Initialized
INFO - 2018-08-03 03:04:43 --> Language Class Initialized
INFO - 2018-08-03 03:04:43 --> Database Driver Class Initialized
ERROR - 2018-08-03 03:04:43 --> 404 Page Not Found: /index
DEBUG - 2018-08-03 03:04:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 03:04:43 --> Config Class Initialized
INFO - 2018-08-03 03:04:43 --> Hooks Class Initialized
INFO - 2018-08-03 03:04:43 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-08-03 03:04:43 --> UTF-8 Support Enabled
INFO - 2018-08-03 03:04:43 --> Utf8 Class Initialized
INFO - 2018-08-03 03:04:43 --> URI Class Initialized
INFO - 2018-08-03 03:04:43 --> Router Class Initialized
INFO - 2018-08-03 03:04:44 --> Output Class Initialized
INFO - 2018-08-03 03:04:44 --> Email Class Initialized
INFO - 2018-08-03 03:04:44 --> Controller Class Initialized
INFO - 2018-08-03 03:04:44 --> Security Class Initialized
DEBUG - 2018-08-03 03:04:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-08-03 03:04:44 --> Home MX_Controller Initialized
INFO - 2018-08-03 03:04:44 --> Input Class Initialized
INFO - 2018-08-03 03:04:44 --> Language Class Initialized
DEBUG - 2018-08-03 03:04:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
ERROR - 2018-08-03 03:04:44 --> 404 Page Not Found: /index
DEBUG - 2018-08-03 03:04:44 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-03 03:04:44 --> Login MX_Controller Initialized
INFO - 2018-08-03 03:04:44 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-03 03:04:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-03 03:04:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-03 03:06:04 --> Config Class Initialized
INFO - 2018-08-03 03:06:04 --> Hooks Class Initialized
DEBUG - 2018-08-03 03:06:04 --> UTF-8 Support Enabled
INFO - 2018-08-03 03:06:04 --> Utf8 Class Initialized
INFO - 2018-08-03 03:06:04 --> URI Class Initialized
INFO - 2018-08-03 03:06:04 --> Router Class Initialized
INFO - 2018-08-03 03:06:04 --> Output Class Initialized
INFO - 2018-08-03 03:06:04 --> Security Class Initialized
DEBUG - 2018-08-03 03:06:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 03:06:04 --> Input Class Initialized
INFO - 2018-08-03 03:06:04 --> Language Class Initialized
INFO - 2018-08-03 03:06:04 --> Language Class Initialized
INFO - 2018-08-03 03:06:04 --> Config Class Initialized
INFO - 2018-08-03 03:06:04 --> Loader Class Initialized
DEBUG - 2018-08-03 03:06:04 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-03 03:06:04 --> Helper loaded: url_helper
INFO - 2018-08-03 03:06:04 --> Helper loaded: form_helper
INFO - 2018-08-03 03:06:04 --> Helper loaded: date_helper
INFO - 2018-08-03 03:06:05 --> Helper loaded: util_helper
INFO - 2018-08-03 03:06:05 --> Helper loaded: text_helper
INFO - 2018-08-03 03:06:05 --> Helper loaded: string_helper
INFO - 2018-08-03 03:06:05 --> Database Driver Class Initialized
DEBUG - 2018-08-03 03:06:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 03:06:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-03 03:06:05 --> Email Class Initialized
INFO - 2018-08-03 03:06:05 --> Controller Class Initialized
DEBUG - 2018-08-03 03:06:05 --> Home MX_Controller Initialized
DEBUG - 2018-08-03 03:06:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-03 03:06:05 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-03 03:06:05 --> Login MX_Controller Initialized
INFO - 2018-08-03 03:06:05 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-03 03:06:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-03 03:06:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-03 03:07:02 --> Config Class Initialized
INFO - 2018-08-03 03:07:02 --> Hooks Class Initialized
DEBUG - 2018-08-03 03:07:02 --> UTF-8 Support Enabled
INFO - 2018-08-03 03:07:02 --> Utf8 Class Initialized
INFO - 2018-08-03 03:07:02 --> URI Class Initialized
INFO - 2018-08-03 03:07:02 --> Router Class Initialized
INFO - 2018-08-03 03:07:02 --> Output Class Initialized
INFO - 2018-08-03 03:07:02 --> Security Class Initialized
DEBUG - 2018-08-03 03:07:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 03:07:02 --> Input Class Initialized
INFO - 2018-08-03 03:07:02 --> Language Class Initialized
INFO - 2018-08-03 03:07:02 --> Language Class Initialized
INFO - 2018-08-03 03:07:02 --> Config Class Initialized
INFO - 2018-08-03 03:07:02 --> Loader Class Initialized
DEBUG - 2018-08-03 03:07:02 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-03 03:07:02 --> Helper loaded: url_helper
INFO - 2018-08-03 03:07:02 --> Helper loaded: form_helper
INFO - 2018-08-03 03:07:02 --> Helper loaded: date_helper
INFO - 2018-08-03 03:07:02 --> Helper loaded: util_helper
INFO - 2018-08-03 03:07:02 --> Helper loaded: text_helper
INFO - 2018-08-03 03:07:02 --> Helper loaded: string_helper
INFO - 2018-08-03 03:07:02 --> Database Driver Class Initialized
DEBUG - 2018-08-03 03:07:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 03:07:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-03 03:07:02 --> Email Class Initialized
INFO - 2018-08-03 03:07:02 --> Controller Class Initialized
DEBUG - 2018-08-03 03:07:02 --> Home MX_Controller Initialized
DEBUG - 2018-08-03 03:07:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-03 03:07:03 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-03 03:07:03 --> Login MX_Controller Initialized
INFO - 2018-08-03 03:07:03 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-03 03:07:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-03 03:07:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-03 03:07:10 --> Config Class Initialized
INFO - 2018-08-03 03:07:10 --> Hooks Class Initialized
DEBUG - 2018-08-03 03:07:11 --> UTF-8 Support Enabled
INFO - 2018-08-03 03:07:11 --> Utf8 Class Initialized
INFO - 2018-08-03 03:07:11 --> URI Class Initialized
INFO - 2018-08-03 03:07:11 --> Router Class Initialized
INFO - 2018-08-03 03:07:11 --> Output Class Initialized
INFO - 2018-08-03 03:07:11 --> Security Class Initialized
DEBUG - 2018-08-03 03:07:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 03:07:11 --> Input Class Initialized
INFO - 2018-08-03 03:07:11 --> Language Class Initialized
INFO - 2018-08-03 03:07:11 --> Language Class Initialized
INFO - 2018-08-03 03:07:11 --> Config Class Initialized
INFO - 2018-08-03 03:07:11 --> Loader Class Initialized
DEBUG - 2018-08-03 03:07:11 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-03 03:07:11 --> Helper loaded: url_helper
INFO - 2018-08-03 03:07:11 --> Helper loaded: form_helper
INFO - 2018-08-03 03:07:11 --> Helper loaded: date_helper
INFO - 2018-08-03 03:07:11 --> Helper loaded: util_helper
INFO - 2018-08-03 03:07:11 --> Helper loaded: text_helper
INFO - 2018-08-03 03:07:11 --> Helper loaded: string_helper
INFO - 2018-08-03 03:07:11 --> Database Driver Class Initialized
DEBUG - 2018-08-03 03:07:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 03:07:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-03 03:07:11 --> Email Class Initialized
INFO - 2018-08-03 03:07:11 --> Controller Class Initialized
DEBUG - 2018-08-03 03:07:11 --> Home MX_Controller Initialized
DEBUG - 2018-08-03 03:07:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-03 03:07:11 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-03 03:07:11 --> Login MX_Controller Initialized
INFO - 2018-08-03 03:07:11 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-03 03:07:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-03 03:07:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-03 03:07:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-08-03 03:07:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-08-03 03:07:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-08-03 03:07:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-08-03 03:07:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-08-03 03:07:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-08-03 03:07:11 --> Final output sent to browser
DEBUG - 2018-08-03 03:07:11 --> Total execution time: 0.8965
INFO - 2018-08-03 03:07:12 --> Config Class Initialized
INFO - 2018-08-03 03:07:12 --> Hooks Class Initialized
DEBUG - 2018-08-03 03:07:12 --> UTF-8 Support Enabled
INFO - 2018-08-03 03:07:12 --> Config Class Initialized
INFO - 2018-08-03 03:07:12 --> Utf8 Class Initialized
INFO - 2018-08-03 03:07:12 --> Hooks Class Initialized
INFO - 2018-08-03 03:07:12 --> URI Class Initialized
DEBUG - 2018-08-03 03:07:12 --> UTF-8 Support Enabled
INFO - 2018-08-03 03:07:12 --> Router Class Initialized
INFO - 2018-08-03 03:07:12 --> Output Class Initialized
INFO - 2018-08-03 03:07:13 --> Utf8 Class Initialized
INFO - 2018-08-03 03:07:13 --> Security Class Initialized
DEBUG - 2018-08-03 03:07:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 03:07:13 --> URI Class Initialized
INFO - 2018-08-03 03:07:13 --> Input Class Initialized
INFO - 2018-08-03 03:07:13 --> Router Class Initialized
INFO - 2018-08-03 03:07:13 --> Output Class Initialized
INFO - 2018-08-03 03:07:13 --> Language Class Initialized
INFO - 2018-08-03 03:07:13 --> Security Class Initialized
DEBUG - 2018-08-03 03:07:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 03:07:13 --> Input Class Initialized
ERROR - 2018-08-03 03:07:13 --> 404 Page Not Found: /index
INFO - 2018-08-03 03:07:13 --> Language Class Initialized
INFO - 2018-08-03 03:07:13 --> Language Class Initialized
INFO - 2018-08-03 03:07:13 --> Config Class Initialized
INFO - 2018-08-03 03:07:13 --> Config Class Initialized
INFO - 2018-08-03 03:07:13 --> Hooks Class Initialized
INFO - 2018-08-03 03:07:13 --> Loader Class Initialized
DEBUG - 2018-08-03 03:07:13 --> UTF-8 Support Enabled
INFO - 2018-08-03 03:07:13 --> Utf8 Class Initialized
DEBUG - 2018-08-03 03:07:13 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-03 03:07:13 --> URI Class Initialized
INFO - 2018-08-03 03:07:13 --> Helper loaded: url_helper
INFO - 2018-08-03 03:07:13 --> Router Class Initialized
INFO - 2018-08-03 03:07:13 --> Helper loaded: form_helper
INFO - 2018-08-03 03:07:13 --> Output Class Initialized
INFO - 2018-08-03 03:07:13 --> Helper loaded: date_helper
INFO - 2018-08-03 03:07:13 --> Security Class Initialized
INFO - 2018-08-03 03:07:13 --> Helper loaded: util_helper
DEBUG - 2018-08-03 03:07:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 03:07:13 --> Input Class Initialized
INFO - 2018-08-03 03:07:13 --> Helper loaded: text_helper
INFO - 2018-08-03 03:07:13 --> Language Class Initialized
INFO - 2018-08-03 03:07:13 --> Helper loaded: string_helper
ERROR - 2018-08-03 03:07:13 --> 404 Page Not Found: /index
INFO - 2018-08-03 03:07:13 --> Database Driver Class Initialized
INFO - 2018-08-03 03:07:14 --> Config Class Initialized
INFO - 2018-08-03 03:07:14 --> Hooks Class Initialized
DEBUG - 2018-08-03 03:07:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 03:07:14 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-08-03 03:07:14 --> UTF-8 Support Enabled
INFO - 2018-08-03 03:07:14 --> Email Class Initialized
INFO - 2018-08-03 03:07:14 --> Controller Class Initialized
DEBUG - 2018-08-03 03:07:14 --> Home MX_Controller Initialized
INFO - 2018-08-03 03:07:14 --> Utf8 Class Initialized
DEBUG - 2018-08-03 03:07:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-08-03 03:07:14 --> URI Class Initialized
DEBUG - 2018-08-03 03:07:14 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-03 03:07:14 --> Login MX_Controller Initialized
INFO - 2018-08-03 03:07:14 --> Router Class Initialized
INFO - 2018-08-03 03:07:14 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-03 03:07:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-08-03 03:07:14 --> Output Class Initialized
DEBUG - 2018-08-03 03:07:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-03 03:07:14 --> Security Class Initialized
DEBUG - 2018-08-03 03:07:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 03:07:14 --> Input Class Initialized
INFO - 2018-08-03 03:07:14 --> Language Class Initialized
ERROR - 2018-08-03 03:07:14 --> 404 Page Not Found: /index
INFO - 2018-08-03 03:08:29 --> Config Class Initialized
INFO - 2018-08-03 03:08:29 --> Hooks Class Initialized
DEBUG - 2018-08-03 03:08:29 --> UTF-8 Support Enabled
INFO - 2018-08-03 03:08:29 --> Utf8 Class Initialized
INFO - 2018-08-03 03:08:29 --> URI Class Initialized
INFO - 2018-08-03 03:08:29 --> Router Class Initialized
INFO - 2018-08-03 03:08:29 --> Output Class Initialized
INFO - 2018-08-03 03:08:29 --> Security Class Initialized
DEBUG - 2018-08-03 03:08:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 03:08:29 --> Input Class Initialized
INFO - 2018-08-03 03:08:29 --> Language Class Initialized
INFO - 2018-08-03 03:08:29 --> Language Class Initialized
INFO - 2018-08-03 03:08:29 --> Config Class Initialized
INFO - 2018-08-03 03:08:30 --> Loader Class Initialized
DEBUG - 2018-08-03 03:08:30 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-03 03:08:30 --> Helper loaded: url_helper
INFO - 2018-08-03 03:08:30 --> Helper loaded: form_helper
INFO - 2018-08-03 03:08:30 --> Helper loaded: date_helper
INFO - 2018-08-03 03:08:30 --> Helper loaded: util_helper
INFO - 2018-08-03 03:08:30 --> Helper loaded: text_helper
INFO - 2018-08-03 03:08:30 --> Helper loaded: string_helper
INFO - 2018-08-03 03:08:30 --> Database Driver Class Initialized
DEBUG - 2018-08-03 03:08:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 03:08:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-03 03:08:30 --> Email Class Initialized
INFO - 2018-08-03 03:08:30 --> Controller Class Initialized
DEBUG - 2018-08-03 03:08:30 --> Home MX_Controller Initialized
DEBUG - 2018-08-03 03:08:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-03 03:08:30 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-03 03:08:30 --> Login MX_Controller Initialized
INFO - 2018-08-03 03:08:30 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-03 03:08:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-03 03:08:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-03 03:08:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-08-03 03:08:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-08-03 03:08:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-08-03 03:08:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-08-03 03:08:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-08-03 03:08:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-08-03 03:08:30 --> Final output sent to browser
DEBUG - 2018-08-03 03:08:30 --> Total execution time: 0.9222
INFO - 2018-08-03 03:08:31 --> Config Class Initialized
INFO - 2018-08-03 03:08:31 --> Hooks Class Initialized
INFO - 2018-08-03 03:08:31 --> Config Class Initialized
DEBUG - 2018-08-03 03:08:31 --> UTF-8 Support Enabled
INFO - 2018-08-03 03:08:31 --> Hooks Class Initialized
INFO - 2018-08-03 03:08:31 --> Utf8 Class Initialized
DEBUG - 2018-08-03 03:08:31 --> UTF-8 Support Enabled
INFO - 2018-08-03 03:08:31 --> Utf8 Class Initialized
INFO - 2018-08-03 03:08:31 --> URI Class Initialized
INFO - 2018-08-03 03:08:31 --> URI Class Initialized
INFO - 2018-08-03 03:08:31 --> Router Class Initialized
INFO - 2018-08-03 03:08:31 --> Router Class Initialized
INFO - 2018-08-03 03:08:31 --> Output Class Initialized
INFO - 2018-08-03 03:08:31 --> Output Class Initialized
INFO - 2018-08-03 03:08:31 --> Security Class Initialized
INFO - 2018-08-03 03:08:31 --> Security Class Initialized
DEBUG - 2018-08-03 03:08:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 03:08:31 --> Input Class Initialized
DEBUG - 2018-08-03 03:08:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 03:08:31 --> Language Class Initialized
INFO - 2018-08-03 03:08:31 --> Input Class Initialized
INFO - 2018-08-03 03:08:32 --> Language Class Initialized
ERROR - 2018-08-03 03:08:32 --> 404 Page Not Found: /index
INFO - 2018-08-03 03:08:32 --> Language Class Initialized
INFO - 2018-08-03 03:08:32 --> Config Class Initialized
INFO - 2018-08-03 03:08:32 --> Loader Class Initialized
INFO - 2018-08-03 03:08:32 --> Config Class Initialized
INFO - 2018-08-03 03:08:32 --> Hooks Class Initialized
DEBUG - 2018-08-03 03:08:32 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-03 03:08:32 --> Helper loaded: url_helper
DEBUG - 2018-08-03 03:08:32 --> UTF-8 Support Enabled
INFO - 2018-08-03 03:08:32 --> Utf8 Class Initialized
INFO - 2018-08-03 03:08:32 --> Helper loaded: form_helper
INFO - 2018-08-03 03:08:32 --> URI Class Initialized
INFO - 2018-08-03 03:08:32 --> Router Class Initialized
INFO - 2018-08-03 03:08:32 --> Helper loaded: date_helper
INFO - 2018-08-03 03:08:32 --> Output Class Initialized
INFO - 2018-08-03 03:08:32 --> Helper loaded: util_helper
INFO - 2018-08-03 03:08:32 --> Security Class Initialized
DEBUG - 2018-08-03 03:08:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 03:08:32 --> Helper loaded: text_helper
INFO - 2018-08-03 03:08:32 --> Input Class Initialized
INFO - 2018-08-03 03:08:32 --> Language Class Initialized
INFO - 2018-08-03 03:08:32 --> Helper loaded: string_helper
ERROR - 2018-08-03 03:08:32 --> 404 Page Not Found: /index
INFO - 2018-08-03 03:08:32 --> Database Driver Class Initialized
INFO - 2018-08-03 03:08:32 --> Config Class Initialized
INFO - 2018-08-03 03:08:32 --> Hooks Class Initialized
DEBUG - 2018-08-03 03:08:32 --> UTF-8 Support Enabled
INFO - 2018-08-03 03:08:32 --> Utf8 Class Initialized
INFO - 2018-08-03 03:08:32 --> URI Class Initialized
DEBUG - 2018-08-03 03:08:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 03:08:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-03 03:08:32 --> Router Class Initialized
INFO - 2018-08-03 03:08:32 --> Email Class Initialized
INFO - 2018-08-03 03:08:32 --> Controller Class Initialized
DEBUG - 2018-08-03 03:08:32 --> Home MX_Controller Initialized
DEBUG - 2018-08-03 03:08:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-08-03 03:08:32 --> Output Class Initialized
DEBUG - 2018-08-03 03:08:32 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-03 03:08:32 --> Login MX_Controller Initialized
INFO - 2018-08-03 03:08:32 --> Security Class Initialized
DEBUG - 2018-08-03 03:08:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 03:08:32 --> Language file loaded: language/english/data_lang.php
INFO - 2018-08-03 03:08:33 --> Input Class Initialized
INFO - 2018-08-03 03:08:33 --> Language Class Initialized
DEBUG - 2018-08-03 03:08:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-03 03:08:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
ERROR - 2018-08-03 03:08:33 --> 404 Page Not Found: /index
INFO - 2018-08-03 03:11:13 --> Config Class Initialized
INFO - 2018-08-03 03:11:13 --> Hooks Class Initialized
DEBUG - 2018-08-03 03:11:13 --> UTF-8 Support Enabled
INFO - 2018-08-03 03:11:13 --> Utf8 Class Initialized
INFO - 2018-08-03 03:11:13 --> URI Class Initialized
INFO - 2018-08-03 03:11:13 --> Router Class Initialized
INFO - 2018-08-03 03:11:13 --> Output Class Initialized
INFO - 2018-08-03 03:11:13 --> Security Class Initialized
DEBUG - 2018-08-03 03:11:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 03:11:13 --> Input Class Initialized
INFO - 2018-08-03 03:11:13 --> Language Class Initialized
INFO - 2018-08-03 03:11:13 --> Language Class Initialized
INFO - 2018-08-03 03:11:13 --> Config Class Initialized
INFO - 2018-08-03 03:11:14 --> Loader Class Initialized
DEBUG - 2018-08-03 03:11:14 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-03 03:11:14 --> Helper loaded: url_helper
INFO - 2018-08-03 03:11:14 --> Helper loaded: form_helper
INFO - 2018-08-03 03:11:14 --> Helper loaded: date_helper
INFO - 2018-08-03 03:11:14 --> Helper loaded: util_helper
INFO - 2018-08-03 03:11:14 --> Helper loaded: text_helper
INFO - 2018-08-03 03:11:14 --> Helper loaded: string_helper
INFO - 2018-08-03 03:11:14 --> Database Driver Class Initialized
DEBUG - 2018-08-03 03:11:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 03:11:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-03 03:11:14 --> Email Class Initialized
INFO - 2018-08-03 03:11:14 --> Controller Class Initialized
DEBUG - 2018-08-03 03:11:14 --> Admin MX_Controller Initialized
INFO - 2018-08-03 03:11:14 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-03 03:11:14 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-03 03:11:14 --> Login MX_Controller Initialized
DEBUG - 2018-08-03 03:11:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-03 03:11:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-03 03:11:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-08-03 03:11:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-08-03 03:11:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-08-03 03:11:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-08-03 03:11:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-08-03 03:11:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/dashboard.php
INFO - 2018-08-03 03:11:14 --> Final output sent to browser
DEBUG - 2018-08-03 03:11:14 --> Total execution time: 0.8783
INFO - 2018-08-03 03:11:15 --> Config Class Initialized
INFO - 2018-08-03 03:11:15 --> Hooks Class Initialized
DEBUG - 2018-08-03 03:11:15 --> UTF-8 Support Enabled
INFO - 2018-08-03 03:11:15 --> Utf8 Class Initialized
INFO - 2018-08-03 03:11:15 --> URI Class Initialized
INFO - 2018-08-03 03:11:15 --> Router Class Initialized
INFO - 2018-08-03 03:11:15 --> Output Class Initialized
INFO - 2018-08-03 03:11:15 --> Security Class Initialized
DEBUG - 2018-08-03 03:11:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 03:11:15 --> Input Class Initialized
INFO - 2018-08-03 03:11:15 --> Language Class Initialized
INFO - 2018-08-03 03:11:15 --> Language Class Initialized
INFO - 2018-08-03 03:11:15 --> Config Class Initialized
INFO - 2018-08-03 03:11:15 --> Loader Class Initialized
DEBUG - 2018-08-03 03:11:15 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-03 03:11:15 --> Helper loaded: url_helper
INFO - 2018-08-03 03:11:15 --> Helper loaded: form_helper
INFO - 2018-08-03 03:11:15 --> Helper loaded: date_helper
INFO - 2018-08-03 03:11:15 --> Helper loaded: util_helper
INFO - 2018-08-03 03:11:15 --> Helper loaded: text_helper
INFO - 2018-08-03 03:11:15 --> Helper loaded: string_helper
INFO - 2018-08-03 03:11:15 --> Database Driver Class Initialized
DEBUG - 2018-08-03 03:11:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 03:11:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-03 03:11:15 --> Email Class Initialized
INFO - 2018-08-03 03:11:16 --> Controller Class Initialized
DEBUG - 2018-08-03 03:11:16 --> Home MX_Controller Initialized
DEBUG - 2018-08-03 03:11:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-03 03:11:16 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-03 03:11:16 --> Login MX_Controller Initialized
INFO - 2018-08-03 03:11:16 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-03 03:11:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-03 03:11:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-03 03:11:19 --> Config Class Initialized
INFO - 2018-08-03 03:11:19 --> Hooks Class Initialized
DEBUG - 2018-08-03 03:11:19 --> UTF-8 Support Enabled
INFO - 2018-08-03 03:11:19 --> Utf8 Class Initialized
INFO - 2018-08-03 03:11:19 --> URI Class Initialized
INFO - 2018-08-03 03:11:19 --> Router Class Initialized
INFO - 2018-08-03 03:11:19 --> Output Class Initialized
INFO - 2018-08-03 03:11:19 --> Security Class Initialized
DEBUG - 2018-08-03 03:11:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 03:11:19 --> Input Class Initialized
INFO - 2018-08-03 03:11:19 --> Language Class Initialized
INFO - 2018-08-03 03:11:19 --> Language Class Initialized
INFO - 2018-08-03 03:11:19 --> Config Class Initialized
INFO - 2018-08-03 03:11:19 --> Loader Class Initialized
DEBUG - 2018-08-03 03:11:19 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-03 03:11:19 --> Helper loaded: url_helper
INFO - 2018-08-03 03:11:19 --> Helper loaded: form_helper
INFO - 2018-08-03 03:11:19 --> Helper loaded: date_helper
INFO - 2018-08-03 03:11:19 --> Helper loaded: util_helper
INFO - 2018-08-03 03:11:19 --> Helper loaded: text_helper
INFO - 2018-08-03 03:11:19 --> Helper loaded: string_helper
INFO - 2018-08-03 03:11:19 --> Database Driver Class Initialized
DEBUG - 2018-08-03 03:11:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 03:11:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-03 03:11:19 --> Email Class Initialized
INFO - 2018-08-03 03:11:19 --> Controller Class Initialized
DEBUG - 2018-08-03 03:11:19 --> Home MX_Controller Initialized
DEBUG - 2018-08-03 03:11:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-03 03:11:19 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-03 03:11:19 --> Login MX_Controller Initialized
INFO - 2018-08-03 03:11:19 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-03 03:11:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-03 03:11:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-03 03:11:21 --> Config Class Initialized
INFO - 2018-08-03 03:11:21 --> Hooks Class Initialized
DEBUG - 2018-08-03 03:11:21 --> UTF-8 Support Enabled
INFO - 2018-08-03 03:11:21 --> Utf8 Class Initialized
INFO - 2018-08-03 03:11:21 --> URI Class Initialized
INFO - 2018-08-03 03:11:21 --> Router Class Initialized
INFO - 2018-08-03 03:11:21 --> Output Class Initialized
INFO - 2018-08-03 03:11:21 --> Security Class Initialized
DEBUG - 2018-08-03 03:11:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 03:11:21 --> Input Class Initialized
INFO - 2018-08-03 03:11:21 --> Language Class Initialized
INFO - 2018-08-03 03:11:21 --> Language Class Initialized
INFO - 2018-08-03 03:11:21 --> Config Class Initialized
INFO - 2018-08-03 03:11:21 --> Loader Class Initialized
DEBUG - 2018-08-03 03:11:21 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-03 03:11:22 --> Helper loaded: url_helper
INFO - 2018-08-03 03:11:22 --> Helper loaded: form_helper
INFO - 2018-08-03 03:11:22 --> Helper loaded: date_helper
INFO - 2018-08-03 03:11:22 --> Helper loaded: util_helper
INFO - 2018-08-03 03:11:22 --> Helper loaded: text_helper
INFO - 2018-08-03 03:11:22 --> Helper loaded: string_helper
INFO - 2018-08-03 03:11:22 --> Database Driver Class Initialized
DEBUG - 2018-08-03 03:11:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 03:11:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-03 03:11:22 --> Email Class Initialized
INFO - 2018-08-03 03:11:22 --> Controller Class Initialized
DEBUG - 2018-08-03 03:11:22 --> Home MX_Controller Initialized
DEBUG - 2018-08-03 03:11:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-03 03:11:22 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-03 03:11:22 --> Login MX_Controller Initialized
INFO - 2018-08-03 03:11:22 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-03 03:11:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-03 03:11:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-03 03:11:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-08-03 03:11:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-08-03 03:11:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-08-03 03:11:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-08-03 03:11:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-08-03 03:11:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-08-03 03:11:22 --> Final output sent to browser
DEBUG - 2018-08-03 03:11:22 --> Total execution time: 0.8851
INFO - 2018-08-03 03:11:23 --> Config Class Initialized
INFO - 2018-08-03 03:11:23 --> Hooks Class Initialized
INFO - 2018-08-03 03:11:23 --> Config Class Initialized
INFO - 2018-08-03 03:11:23 --> Hooks Class Initialized
DEBUG - 2018-08-03 03:11:23 --> UTF-8 Support Enabled
DEBUG - 2018-08-03 03:11:23 --> UTF-8 Support Enabled
INFO - 2018-08-03 03:11:23 --> Utf8 Class Initialized
INFO - 2018-08-03 03:11:23 --> Utf8 Class Initialized
INFO - 2018-08-03 03:11:23 --> URI Class Initialized
INFO - 2018-08-03 03:11:23 --> URI Class Initialized
INFO - 2018-08-03 03:11:23 --> Router Class Initialized
INFO - 2018-08-03 03:11:23 --> Router Class Initialized
INFO - 2018-08-03 03:11:23 --> Output Class Initialized
INFO - 2018-08-03 03:11:23 --> Security Class Initialized
DEBUG - 2018-08-03 03:11:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 03:11:23 --> Input Class Initialized
INFO - 2018-08-03 03:11:23 --> Language Class Initialized
INFO - 2018-08-03 03:11:23 --> Language Class Initialized
INFO - 2018-08-03 03:11:23 --> Config Class Initialized
INFO - 2018-08-03 03:11:23 --> Output Class Initialized
INFO - 2018-08-03 03:11:23 --> Security Class Initialized
INFO - 2018-08-03 03:11:23 --> Loader Class Initialized
DEBUG - 2018-08-03 03:11:23 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
DEBUG - 2018-08-03 03:11:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 03:11:23 --> Input Class Initialized
INFO - 2018-08-03 03:11:23 --> Helper loaded: url_helper
INFO - 2018-08-03 03:11:23 --> Language Class Initialized
INFO - 2018-08-03 03:11:23 --> Helper loaded: form_helper
ERROR - 2018-08-03 03:11:24 --> 404 Page Not Found: /index
INFO - 2018-08-03 03:11:24 --> Config Class Initialized
INFO - 2018-08-03 03:11:24 --> Hooks Class Initialized
DEBUG - 2018-08-03 03:11:24 --> UTF-8 Support Enabled
INFO - 2018-08-03 03:11:24 --> Utf8 Class Initialized
INFO - 2018-08-03 03:11:24 --> Helper loaded: date_helper
INFO - 2018-08-03 03:11:24 --> URI Class Initialized
INFO - 2018-08-03 03:11:24 --> Helper loaded: util_helper
INFO - 2018-08-03 03:11:24 --> Router Class Initialized
INFO - 2018-08-03 03:11:24 --> Output Class Initialized
INFO - 2018-08-03 03:11:24 --> Helper loaded: text_helper
INFO - 2018-08-03 03:11:24 --> Helper loaded: string_helper
INFO - 2018-08-03 03:11:24 --> Security Class Initialized
DEBUG - 2018-08-03 03:11:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 03:11:24 --> Database Driver Class Initialized
INFO - 2018-08-03 03:11:24 --> Input Class Initialized
DEBUG - 2018-08-03 03:11:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 03:11:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-03 03:11:24 --> Language Class Initialized
ERROR - 2018-08-03 03:11:24 --> 404 Page Not Found: /index
INFO - 2018-08-03 03:11:24 --> Email Class Initialized
INFO - 2018-08-03 03:11:24 --> Controller Class Initialized
INFO - 2018-08-03 03:11:24 --> Config Class Initialized
INFO - 2018-08-03 03:11:24 --> Hooks Class Initialized
DEBUG - 2018-08-03 03:11:24 --> Home MX_Controller Initialized
DEBUG - 2018-08-03 03:11:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-03 03:11:24 --> UTF-8 Support Enabled
INFO - 2018-08-03 03:11:24 --> Utf8 Class Initialized
DEBUG - 2018-08-03 03:11:24 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-03 03:11:24 --> Login MX_Controller Initialized
INFO - 2018-08-03 03:11:24 --> URI Class Initialized
INFO - 2018-08-03 03:11:24 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-03 03:11:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-03 03:11:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-03 03:11:25 --> Router Class Initialized
INFO - 2018-08-03 03:11:25 --> Output Class Initialized
INFO - 2018-08-03 03:11:25 --> Security Class Initialized
DEBUG - 2018-08-03 03:11:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 03:11:25 --> Input Class Initialized
INFO - 2018-08-03 03:11:25 --> Language Class Initialized
ERROR - 2018-08-03 03:11:25 --> 404 Page Not Found: /index
INFO - 2018-08-03 03:11:48 --> Config Class Initialized
INFO - 2018-08-03 03:11:48 --> Hooks Class Initialized
DEBUG - 2018-08-03 03:11:48 --> UTF-8 Support Enabled
INFO - 2018-08-03 03:11:48 --> Utf8 Class Initialized
INFO - 2018-08-03 03:11:48 --> URI Class Initialized
INFO - 2018-08-03 03:11:48 --> Router Class Initialized
INFO - 2018-08-03 03:11:48 --> Output Class Initialized
INFO - 2018-08-03 03:11:48 --> Security Class Initialized
DEBUG - 2018-08-03 03:11:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 03:11:48 --> Input Class Initialized
INFO - 2018-08-03 03:11:48 --> Language Class Initialized
INFO - 2018-08-03 03:11:48 --> Language Class Initialized
INFO - 2018-08-03 03:11:48 --> Config Class Initialized
INFO - 2018-08-03 03:11:48 --> Loader Class Initialized
DEBUG - 2018-08-03 03:11:48 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-03 03:11:48 --> Helper loaded: url_helper
INFO - 2018-08-03 03:11:48 --> Helper loaded: form_helper
INFO - 2018-08-03 03:11:48 --> Helper loaded: date_helper
INFO - 2018-08-03 03:11:48 --> Helper loaded: util_helper
INFO - 2018-08-03 03:11:48 --> Helper loaded: text_helper
INFO - 2018-08-03 03:11:48 --> Helper loaded: string_helper
INFO - 2018-08-03 03:11:48 --> Database Driver Class Initialized
DEBUG - 2018-08-03 03:11:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 03:11:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-03 03:11:48 --> Email Class Initialized
INFO - 2018-08-03 03:11:48 --> Controller Class Initialized
DEBUG - 2018-08-03 03:11:48 --> Home MX_Controller Initialized
DEBUG - 2018-08-03 03:11:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-03 03:11:48 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-03 03:11:49 --> Login MX_Controller Initialized
INFO - 2018-08-03 03:11:49 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-03 03:11:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-03 03:11:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-03 03:11:51 --> Config Class Initialized
INFO - 2018-08-03 03:11:51 --> Hooks Class Initialized
DEBUG - 2018-08-03 03:11:51 --> UTF-8 Support Enabled
INFO - 2018-08-03 03:11:51 --> Utf8 Class Initialized
INFO - 2018-08-03 03:11:51 --> URI Class Initialized
INFO - 2018-08-03 03:11:51 --> Router Class Initialized
INFO - 2018-08-03 03:11:51 --> Output Class Initialized
INFO - 2018-08-03 03:11:51 --> Security Class Initialized
DEBUG - 2018-08-03 03:11:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 03:11:51 --> Input Class Initialized
INFO - 2018-08-03 03:11:51 --> Language Class Initialized
INFO - 2018-08-03 03:11:51 --> Language Class Initialized
INFO - 2018-08-03 03:11:51 --> Config Class Initialized
INFO - 2018-08-03 03:11:51 --> Loader Class Initialized
DEBUG - 2018-08-03 03:11:51 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-03 03:11:51 --> Helper loaded: url_helper
INFO - 2018-08-03 03:11:51 --> Helper loaded: form_helper
INFO - 2018-08-03 03:11:51 --> Helper loaded: date_helper
INFO - 2018-08-03 03:11:51 --> Helper loaded: util_helper
INFO - 2018-08-03 03:11:51 --> Helper loaded: text_helper
INFO - 2018-08-03 03:11:51 --> Helper loaded: string_helper
INFO - 2018-08-03 03:11:51 --> Database Driver Class Initialized
DEBUG - 2018-08-03 03:11:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 03:11:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-03 03:11:51 --> Email Class Initialized
INFO - 2018-08-03 03:11:51 --> Controller Class Initialized
DEBUG - 2018-08-03 03:11:51 --> Home MX_Controller Initialized
DEBUG - 2018-08-03 03:11:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-03 03:11:51 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-03 03:11:51 --> Login MX_Controller Initialized
INFO - 2018-08-03 03:11:51 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-03 03:11:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-03 03:11:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-03 03:11:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-08-03 03:11:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-08-03 03:11:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-08-03 03:11:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-08-03 03:11:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-08-03 03:11:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-08-03 03:11:52 --> Final output sent to browser
DEBUG - 2018-08-03 03:11:52 --> Total execution time: 0.8930
INFO - 2018-08-03 03:11:52 --> Config Class Initialized
INFO - 2018-08-03 03:11:52 --> Hooks Class Initialized
INFO - 2018-08-03 03:11:52 --> Config Class Initialized
INFO - 2018-08-03 03:11:52 --> Hooks Class Initialized
DEBUG - 2018-08-03 03:11:52 --> UTF-8 Support Enabled
INFO - 2018-08-03 03:11:52 --> Utf8 Class Initialized
DEBUG - 2018-08-03 03:11:52 --> UTF-8 Support Enabled
INFO - 2018-08-03 03:11:53 --> URI Class Initialized
INFO - 2018-08-03 03:11:53 --> Utf8 Class Initialized
INFO - 2018-08-03 03:11:53 --> Router Class Initialized
INFO - 2018-08-03 03:11:53 --> URI Class Initialized
INFO - 2018-08-03 03:11:53 --> Router Class Initialized
INFO - 2018-08-03 03:11:53 --> Output Class Initialized
INFO - 2018-08-03 03:11:53 --> Security Class Initialized
DEBUG - 2018-08-03 03:11:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 03:11:53 --> Input Class Initialized
INFO - 2018-08-03 03:11:53 --> Language Class Initialized
INFO - 2018-08-03 03:11:53 --> Language Class Initialized
INFO - 2018-08-03 03:11:53 --> Config Class Initialized
INFO - 2018-08-03 03:11:53 --> Loader Class Initialized
DEBUG - 2018-08-03 03:11:53 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-03 03:11:53 --> Output Class Initialized
INFO - 2018-08-03 03:11:53 --> Helper loaded: url_helper
INFO - 2018-08-03 03:11:53 --> Helper loaded: form_helper
INFO - 2018-08-03 03:11:53 --> Security Class Initialized
INFO - 2018-08-03 03:11:53 --> Helper loaded: date_helper
DEBUG - 2018-08-03 03:11:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 03:11:53 --> Helper loaded: util_helper
INFO - 2018-08-03 03:11:53 --> Input Class Initialized
INFO - 2018-08-03 03:11:53 --> Helper loaded: text_helper
INFO - 2018-08-03 03:11:53 --> Helper loaded: string_helper
INFO - 2018-08-03 03:11:53 --> Language Class Initialized
INFO - 2018-08-03 03:11:53 --> Database Driver Class Initialized
ERROR - 2018-08-03 03:11:53 --> 404 Page Not Found: /index
DEBUG - 2018-08-03 03:11:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 03:11:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-03 03:11:53 --> Config Class Initialized
INFO - 2018-08-03 03:11:53 --> Hooks Class Initialized
INFO - 2018-08-03 03:11:53 --> Email Class Initialized
INFO - 2018-08-03 03:11:53 --> Controller Class Initialized
DEBUG - 2018-08-03 03:11:53 --> UTF-8 Support Enabled
INFO - 2018-08-03 03:11:53 --> Utf8 Class Initialized
DEBUG - 2018-08-03 03:11:53 --> Home MX_Controller Initialized
INFO - 2018-08-03 03:11:54 --> URI Class Initialized
DEBUG - 2018-08-03 03:11:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-08-03 03:11:54 --> Router Class Initialized
INFO - 2018-08-03 03:11:54 --> Output Class Initialized
DEBUG - 2018-08-03 03:11:54 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
INFO - 2018-08-03 03:11:54 --> Security Class Initialized
DEBUG - 2018-08-03 03:11:54 --> Login MX_Controller Initialized
DEBUG - 2018-08-03 03:11:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 03:11:54 --> Input Class Initialized
INFO - 2018-08-03 03:11:54 --> Language file loaded: language/english/data_lang.php
INFO - 2018-08-03 03:11:54 --> Language Class Initialized
ERROR - 2018-08-03 03:11:54 --> 404 Page Not Found: /index
DEBUG - 2018-08-03 03:11:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-08-03 03:11:54 --> Config Class Initialized
INFO - 2018-08-03 03:11:54 --> Hooks Class Initialized
DEBUG - 2018-08-03 03:11:54 --> UTF-8 Support Enabled
INFO - 2018-08-03 03:11:54 --> Utf8 Class Initialized
DEBUG - 2018-08-03 03:11:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-03 03:11:54 --> URI Class Initialized
INFO - 2018-08-03 03:11:54 --> Router Class Initialized
INFO - 2018-08-03 03:11:54 --> Output Class Initialized
INFO - 2018-08-03 03:11:54 --> Security Class Initialized
DEBUG - 2018-08-03 03:11:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 03:11:54 --> Input Class Initialized
INFO - 2018-08-03 03:11:54 --> Language Class Initialized
ERROR - 2018-08-03 03:11:54 --> 404 Page Not Found: /index
INFO - 2018-08-03 03:11:57 --> Config Class Initialized
INFO - 2018-08-03 03:11:57 --> Hooks Class Initialized
DEBUG - 2018-08-03 03:11:57 --> UTF-8 Support Enabled
INFO - 2018-08-03 03:11:57 --> Utf8 Class Initialized
INFO - 2018-08-03 03:11:57 --> URI Class Initialized
INFO - 2018-08-03 03:11:57 --> Router Class Initialized
INFO - 2018-08-03 03:11:57 --> Output Class Initialized
INFO - 2018-08-03 03:11:57 --> Security Class Initialized
DEBUG - 2018-08-03 03:11:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 03:11:57 --> Input Class Initialized
INFO - 2018-08-03 03:11:57 --> Language Class Initialized
INFO - 2018-08-03 03:11:57 --> Language Class Initialized
INFO - 2018-08-03 03:11:57 --> Config Class Initialized
INFO - 2018-08-03 03:11:57 --> Loader Class Initialized
DEBUG - 2018-08-03 03:11:57 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-03 03:11:58 --> Helper loaded: url_helper
INFO - 2018-08-03 03:11:58 --> Helper loaded: form_helper
INFO - 2018-08-03 03:11:58 --> Helper loaded: date_helper
INFO - 2018-08-03 03:11:58 --> Helper loaded: util_helper
INFO - 2018-08-03 03:11:58 --> Helper loaded: text_helper
INFO - 2018-08-03 03:11:58 --> Helper loaded: string_helper
INFO - 2018-08-03 03:11:58 --> Database Driver Class Initialized
DEBUG - 2018-08-03 03:11:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 03:11:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-03 03:11:58 --> Email Class Initialized
INFO - 2018-08-03 03:11:58 --> Controller Class Initialized
DEBUG - 2018-08-03 03:11:58 --> Home MX_Controller Initialized
DEBUG - 2018-08-03 03:11:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-03 03:11:58 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-03 03:11:58 --> Login MX_Controller Initialized
INFO - 2018-08-03 03:11:58 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-03 03:11:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-03 03:11:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-03 03:12:00 --> Config Class Initialized
INFO - 2018-08-03 03:12:00 --> Hooks Class Initialized
DEBUG - 2018-08-03 03:12:00 --> UTF-8 Support Enabled
INFO - 2018-08-03 03:12:00 --> Utf8 Class Initialized
INFO - 2018-08-03 03:12:00 --> URI Class Initialized
INFO - 2018-08-03 03:12:00 --> Router Class Initialized
INFO - 2018-08-03 03:12:00 --> Output Class Initialized
INFO - 2018-08-03 03:12:00 --> Security Class Initialized
DEBUG - 2018-08-03 03:12:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 03:12:00 --> Input Class Initialized
INFO - 2018-08-03 03:12:00 --> Language Class Initialized
INFO - 2018-08-03 03:12:00 --> Language Class Initialized
INFO - 2018-08-03 03:12:00 --> Config Class Initialized
INFO - 2018-08-03 03:12:00 --> Loader Class Initialized
DEBUG - 2018-08-03 03:12:00 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-03 03:12:00 --> Helper loaded: url_helper
INFO - 2018-08-03 03:12:00 --> Helper loaded: form_helper
INFO - 2018-08-03 03:12:00 --> Helper loaded: date_helper
INFO - 2018-08-03 03:12:00 --> Helper loaded: util_helper
INFO - 2018-08-03 03:12:00 --> Helper loaded: text_helper
INFO - 2018-08-03 03:12:00 --> Helper loaded: string_helper
INFO - 2018-08-03 03:12:00 --> Database Driver Class Initialized
DEBUG - 2018-08-03 03:12:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 03:12:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-03 03:12:00 --> Email Class Initialized
INFO - 2018-08-03 03:12:00 --> Controller Class Initialized
DEBUG - 2018-08-03 03:12:00 --> Home MX_Controller Initialized
DEBUG - 2018-08-03 03:12:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-03 03:12:00 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-03 03:12:00 --> Login MX_Controller Initialized
INFO - 2018-08-03 03:12:00 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-03 03:12:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-03 03:12:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-03 03:12:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-08-03 03:12:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-08-03 03:12:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-08-03 03:12:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-08-03 03:12:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-08-03 03:12:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-08-03 03:12:01 --> Final output sent to browser
DEBUG - 2018-08-03 03:12:01 --> Total execution time: 0.9033
INFO - 2018-08-03 03:12:01 --> Config Class Initialized
INFO - 2018-08-03 03:12:01 --> Hooks Class Initialized
INFO - 2018-08-03 03:12:01 --> Config Class Initialized
INFO - 2018-08-03 03:12:01 --> Hooks Class Initialized
DEBUG - 2018-08-03 03:12:01 --> UTF-8 Support Enabled
DEBUG - 2018-08-03 03:12:01 --> UTF-8 Support Enabled
INFO - 2018-08-03 03:12:01 --> Utf8 Class Initialized
INFO - 2018-08-03 03:12:02 --> Utf8 Class Initialized
INFO - 2018-08-03 03:12:02 --> URI Class Initialized
INFO - 2018-08-03 03:12:02 --> URI Class Initialized
INFO - 2018-08-03 03:12:02 --> Router Class Initialized
INFO - 2018-08-03 03:12:02 --> Router Class Initialized
INFO - 2018-08-03 03:12:02 --> Output Class Initialized
INFO - 2018-08-03 03:12:02 --> Output Class Initialized
INFO - 2018-08-03 03:12:02 --> Security Class Initialized
INFO - 2018-08-03 03:12:02 --> Security Class Initialized
DEBUG - 2018-08-03 03:12:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-08-03 03:12:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 03:12:02 --> Input Class Initialized
INFO - 2018-08-03 03:12:02 --> Input Class Initialized
INFO - 2018-08-03 03:12:02 --> Language Class Initialized
INFO - 2018-08-03 03:12:02 --> Language Class Initialized
ERROR - 2018-08-03 03:12:02 --> 404 Page Not Found: /index
INFO - 2018-08-03 03:12:02 --> Language Class Initialized
INFO - 2018-08-03 03:12:02 --> Config Class Initialized
INFO - 2018-08-03 03:12:02 --> Config Class Initialized
INFO - 2018-08-03 03:12:02 --> Hooks Class Initialized
INFO - 2018-08-03 03:12:02 --> Loader Class Initialized
DEBUG - 2018-08-03 03:12:02 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
DEBUG - 2018-08-03 03:12:02 --> UTF-8 Support Enabled
INFO - 2018-08-03 03:12:02 --> Utf8 Class Initialized
INFO - 2018-08-03 03:12:02 --> Helper loaded: url_helper
INFO - 2018-08-03 03:12:02 --> URI Class Initialized
INFO - 2018-08-03 03:12:02 --> Helper loaded: form_helper
INFO - 2018-08-03 03:12:02 --> Router Class Initialized
INFO - 2018-08-03 03:12:02 --> Output Class Initialized
INFO - 2018-08-03 03:12:02 --> Helper loaded: date_helper
INFO - 2018-08-03 03:12:02 --> Helper loaded: util_helper
INFO - 2018-08-03 03:12:02 --> Security Class Initialized
INFO - 2018-08-03 03:12:02 --> Helper loaded: text_helper
INFO - 2018-08-03 03:12:02 --> Helper loaded: string_helper
DEBUG - 2018-08-03 03:12:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 03:12:02 --> Database Driver Class Initialized
INFO - 2018-08-03 03:12:02 --> Input Class Initialized
INFO - 2018-08-03 03:12:02 --> Language Class Initialized
ERROR - 2018-08-03 03:12:02 --> 404 Page Not Found: /index
DEBUG - 2018-08-03 03:12:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 03:12:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-03 03:12:02 --> Config Class Initialized
INFO - 2018-08-03 03:12:02 --> Hooks Class Initialized
INFO - 2018-08-03 03:12:02 --> Email Class Initialized
INFO - 2018-08-03 03:12:02 --> Controller Class Initialized
DEBUG - 2018-08-03 03:12:02 --> UTF-8 Support Enabled
DEBUG - 2018-08-03 03:12:02 --> Home MX_Controller Initialized
DEBUG - 2018-08-03 03:12:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-08-03 03:12:02 --> Utf8 Class Initialized
DEBUG - 2018-08-03 03:12:02 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-03 03:12:02 --> Login MX_Controller Initialized
INFO - 2018-08-03 03:12:02 --> URI Class Initialized
INFO - 2018-08-03 03:12:03 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-03 03:12:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-03 03:12:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-03 03:12:03 --> Router Class Initialized
INFO - 2018-08-03 03:12:03 --> Output Class Initialized
INFO - 2018-08-03 03:12:03 --> Security Class Initialized
DEBUG - 2018-08-03 03:12:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 03:12:03 --> Input Class Initialized
INFO - 2018-08-03 03:12:03 --> Language Class Initialized
ERROR - 2018-08-03 03:12:03 --> 404 Page Not Found: /index
INFO - 2018-08-03 03:12:06 --> Config Class Initialized
INFO - 2018-08-03 03:12:06 --> Hooks Class Initialized
DEBUG - 2018-08-03 03:12:06 --> UTF-8 Support Enabled
INFO - 2018-08-03 03:12:06 --> Utf8 Class Initialized
INFO - 2018-08-03 03:12:06 --> URI Class Initialized
INFO - 2018-08-03 03:12:06 --> Router Class Initialized
INFO - 2018-08-03 03:12:06 --> Output Class Initialized
INFO - 2018-08-03 03:12:06 --> Security Class Initialized
DEBUG - 2018-08-03 03:12:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 03:12:06 --> Input Class Initialized
INFO - 2018-08-03 03:12:06 --> Language Class Initialized
INFO - 2018-08-03 03:12:06 --> Language Class Initialized
INFO - 2018-08-03 03:12:06 --> Config Class Initialized
INFO - 2018-08-03 03:12:06 --> Loader Class Initialized
DEBUG - 2018-08-03 03:12:06 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-03 03:12:06 --> Helper loaded: url_helper
INFO - 2018-08-03 03:12:06 --> Helper loaded: form_helper
INFO - 2018-08-03 03:12:06 --> Helper loaded: date_helper
INFO - 2018-08-03 03:12:06 --> Helper loaded: util_helper
INFO - 2018-08-03 03:12:06 --> Helper loaded: text_helper
INFO - 2018-08-03 03:12:06 --> Helper loaded: string_helper
INFO - 2018-08-03 03:12:06 --> Database Driver Class Initialized
DEBUG - 2018-08-03 03:12:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 03:12:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-03 03:12:06 --> Email Class Initialized
INFO - 2018-08-03 03:12:06 --> Controller Class Initialized
DEBUG - 2018-08-03 03:12:06 --> Home MX_Controller Initialized
DEBUG - 2018-08-03 03:12:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-03 03:12:06 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-03 03:12:06 --> Login MX_Controller Initialized
INFO - 2018-08-03 03:12:07 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-03 03:12:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-03 03:12:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-03 03:12:08 --> Config Class Initialized
INFO - 2018-08-03 03:12:08 --> Hooks Class Initialized
DEBUG - 2018-08-03 03:12:08 --> UTF-8 Support Enabled
INFO - 2018-08-03 03:12:08 --> Utf8 Class Initialized
INFO - 2018-08-03 03:12:08 --> URI Class Initialized
INFO - 2018-08-03 03:12:08 --> Router Class Initialized
INFO - 2018-08-03 03:12:08 --> Output Class Initialized
INFO - 2018-08-03 03:12:08 --> Security Class Initialized
DEBUG - 2018-08-03 03:12:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 03:12:08 --> Input Class Initialized
INFO - 2018-08-03 03:12:08 --> Language Class Initialized
INFO - 2018-08-03 03:12:08 --> Language Class Initialized
INFO - 2018-08-03 03:12:08 --> Config Class Initialized
INFO - 2018-08-03 03:12:08 --> Loader Class Initialized
DEBUG - 2018-08-03 03:12:08 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-03 03:12:08 --> Helper loaded: url_helper
INFO - 2018-08-03 03:12:08 --> Helper loaded: form_helper
INFO - 2018-08-03 03:12:08 --> Helper loaded: date_helper
INFO - 2018-08-03 03:12:08 --> Helper loaded: util_helper
INFO - 2018-08-03 03:12:08 --> Helper loaded: text_helper
INFO - 2018-08-03 03:12:09 --> Helper loaded: string_helper
INFO - 2018-08-03 03:12:09 --> Database Driver Class Initialized
DEBUG - 2018-08-03 03:12:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 03:12:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-03 03:12:09 --> Email Class Initialized
INFO - 2018-08-03 03:12:09 --> Controller Class Initialized
DEBUG - 2018-08-03 03:12:09 --> Home MX_Controller Initialized
DEBUG - 2018-08-03 03:12:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-03 03:12:09 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-03 03:12:09 --> Login MX_Controller Initialized
INFO - 2018-08-03 03:12:09 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-03 03:12:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-03 03:12:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-03 03:12:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-08-03 03:12:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-08-03 03:12:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-08-03 03:12:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-08-03 03:12:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-08-03 03:12:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-08-03 03:12:09 --> Final output sent to browser
DEBUG - 2018-08-03 03:12:09 --> Total execution time: 0.9467
INFO - 2018-08-03 03:12:10 --> Config Class Initialized
INFO - 2018-08-03 03:12:10 --> Hooks Class Initialized
INFO - 2018-08-03 03:12:10 --> Config Class Initialized
DEBUG - 2018-08-03 03:12:10 --> UTF-8 Support Enabled
INFO - 2018-08-03 03:12:10 --> Hooks Class Initialized
DEBUG - 2018-08-03 03:12:10 --> UTF-8 Support Enabled
INFO - 2018-08-03 03:12:10 --> Utf8 Class Initialized
INFO - 2018-08-03 03:12:10 --> Utf8 Class Initialized
INFO - 2018-08-03 03:12:10 --> URI Class Initialized
INFO - 2018-08-03 03:12:10 --> URI Class Initialized
INFO - 2018-08-03 03:12:10 --> Router Class Initialized
INFO - 2018-08-03 03:12:10 --> Output Class Initialized
INFO - 2018-08-03 03:12:10 --> Router Class Initialized
INFO - 2018-08-03 03:12:10 --> Security Class Initialized
DEBUG - 2018-08-03 03:12:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 03:12:10 --> Output Class Initialized
INFO - 2018-08-03 03:12:10 --> Input Class Initialized
INFO - 2018-08-03 03:12:10 --> Security Class Initialized
DEBUG - 2018-08-03 03:12:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 03:12:10 --> Language Class Initialized
ERROR - 2018-08-03 03:12:10 --> 404 Page Not Found: /index
INFO - 2018-08-03 03:12:10 --> Input Class Initialized
INFO - 2018-08-03 03:12:10 --> Language Class Initialized
INFO - 2018-08-03 03:12:10 --> Config Class Initialized
INFO - 2018-08-03 03:12:10 --> Hooks Class Initialized
INFO - 2018-08-03 03:12:10 --> Language Class Initialized
INFO - 2018-08-03 03:12:10 --> Config Class Initialized
DEBUG - 2018-08-03 03:12:10 --> UTF-8 Support Enabled
INFO - 2018-08-03 03:12:10 --> Utf8 Class Initialized
INFO - 2018-08-03 03:12:10 --> Loader Class Initialized
INFO - 2018-08-03 03:12:10 --> URI Class Initialized
DEBUG - 2018-08-03 03:12:10 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-03 03:12:10 --> Router Class Initialized
INFO - 2018-08-03 03:12:10 --> Helper loaded: url_helper
INFO - 2018-08-03 03:12:10 --> Output Class Initialized
INFO - 2018-08-03 03:12:10 --> Helper loaded: form_helper
INFO - 2018-08-03 03:12:10 --> Helper loaded: date_helper
INFO - 2018-08-03 03:12:10 --> Security Class Initialized
DEBUG - 2018-08-03 03:12:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 03:12:10 --> Helper loaded: util_helper
INFO - 2018-08-03 03:12:11 --> Input Class Initialized
INFO - 2018-08-03 03:12:11 --> Helper loaded: text_helper
INFO - 2018-08-03 03:12:11 --> Language Class Initialized
INFO - 2018-08-03 03:12:11 --> Helper loaded: string_helper
ERROR - 2018-08-03 03:12:11 --> 404 Page Not Found: /index
INFO - 2018-08-03 03:12:11 --> Database Driver Class Initialized
INFO - 2018-08-03 03:12:11 --> Config Class Initialized
INFO - 2018-08-03 03:12:11 --> Hooks Class Initialized
DEBUG - 2018-08-03 03:12:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 03:12:11 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-08-03 03:12:11 --> UTF-8 Support Enabled
INFO - 2018-08-03 03:12:11 --> Email Class Initialized
INFO - 2018-08-03 03:12:11 --> Controller Class Initialized
DEBUG - 2018-08-03 03:12:11 --> Home MX_Controller Initialized
DEBUG - 2018-08-03 03:12:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-08-03 03:12:11 --> Utf8 Class Initialized
DEBUG - 2018-08-03 03:12:11 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-03 03:12:11 --> Login MX_Controller Initialized
INFO - 2018-08-03 03:12:11 --> URI Class Initialized
INFO - 2018-08-03 03:12:11 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-03 03:12:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-08-03 03:12:11 --> Router Class Initialized
INFO - 2018-08-03 03:12:11 --> Output Class Initialized
DEBUG - 2018-08-03 03:12:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-03 03:12:11 --> Security Class Initialized
DEBUG - 2018-08-03 03:12:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 03:12:11 --> Input Class Initialized
INFO - 2018-08-03 03:12:11 --> Language Class Initialized
ERROR - 2018-08-03 03:12:11 --> 404 Page Not Found: /index
INFO - 2018-08-03 03:12:13 --> Config Class Initialized
INFO - 2018-08-03 03:12:13 --> Hooks Class Initialized
DEBUG - 2018-08-03 03:12:13 --> UTF-8 Support Enabled
INFO - 2018-08-03 03:12:13 --> Utf8 Class Initialized
INFO - 2018-08-03 03:12:13 --> URI Class Initialized
INFO - 2018-08-03 03:12:13 --> Router Class Initialized
INFO - 2018-08-03 03:12:13 --> Output Class Initialized
INFO - 2018-08-03 03:12:13 --> Security Class Initialized
DEBUG - 2018-08-03 03:12:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 03:12:13 --> Input Class Initialized
INFO - 2018-08-03 03:12:13 --> Language Class Initialized
INFO - 2018-08-03 03:12:13 --> Language Class Initialized
INFO - 2018-08-03 03:12:13 --> Config Class Initialized
INFO - 2018-08-03 03:12:13 --> Loader Class Initialized
DEBUG - 2018-08-03 03:12:13 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-03 03:12:13 --> Helper loaded: url_helper
INFO - 2018-08-03 03:12:13 --> Helper loaded: form_helper
INFO - 2018-08-03 03:12:13 --> Helper loaded: date_helper
INFO - 2018-08-03 03:12:13 --> Helper loaded: util_helper
INFO - 2018-08-03 03:12:13 --> Helper loaded: text_helper
INFO - 2018-08-03 03:12:13 --> Helper loaded: string_helper
INFO - 2018-08-03 03:12:14 --> Database Driver Class Initialized
DEBUG - 2018-08-03 03:12:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 03:12:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-03 03:12:14 --> Email Class Initialized
INFO - 2018-08-03 03:12:14 --> Controller Class Initialized
DEBUG - 2018-08-03 03:12:14 --> Home MX_Controller Initialized
DEBUG - 2018-08-03 03:12:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-03 03:12:14 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-03 03:12:14 --> Login MX_Controller Initialized
INFO - 2018-08-03 03:12:14 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-03 03:12:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-03 03:12:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-03 03:12:15 --> Config Class Initialized
INFO - 2018-08-03 03:12:15 --> Hooks Class Initialized
DEBUG - 2018-08-03 03:12:15 --> UTF-8 Support Enabled
INFO - 2018-08-03 03:12:15 --> Utf8 Class Initialized
INFO - 2018-08-03 03:12:15 --> URI Class Initialized
INFO - 2018-08-03 03:12:15 --> Router Class Initialized
INFO - 2018-08-03 03:12:15 --> Output Class Initialized
INFO - 2018-08-03 03:12:15 --> Security Class Initialized
DEBUG - 2018-08-03 03:12:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 03:12:15 --> Input Class Initialized
INFO - 2018-08-03 03:12:15 --> Language Class Initialized
INFO - 2018-08-03 03:12:15 --> Language Class Initialized
INFO - 2018-08-03 03:12:15 --> Config Class Initialized
INFO - 2018-08-03 03:12:15 --> Loader Class Initialized
DEBUG - 2018-08-03 03:12:15 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-03 03:12:15 --> Helper loaded: url_helper
INFO - 2018-08-03 03:12:15 --> Helper loaded: form_helper
INFO - 2018-08-03 03:12:15 --> Helper loaded: date_helper
INFO - 2018-08-03 03:12:15 --> Helper loaded: util_helper
INFO - 2018-08-03 03:12:15 --> Helper loaded: text_helper
INFO - 2018-08-03 03:12:15 --> Helper loaded: string_helper
INFO - 2018-08-03 03:12:15 --> Database Driver Class Initialized
DEBUG - 2018-08-03 03:12:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 03:12:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-03 03:12:15 --> Email Class Initialized
INFO - 2018-08-03 03:12:15 --> Controller Class Initialized
DEBUG - 2018-08-03 03:12:15 --> Home MX_Controller Initialized
DEBUG - 2018-08-03 03:12:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-03 03:12:15 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-03 03:12:15 --> Login MX_Controller Initialized
INFO - 2018-08-03 03:12:15 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-03 03:12:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-03 03:12:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-03 03:12:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-08-03 03:12:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-08-03 03:12:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-08-03 03:12:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-08-03 03:12:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-08-03 03:12:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-08-03 03:12:16 --> Final output sent to browser
DEBUG - 2018-08-03 03:12:16 --> Total execution time: 0.9847
INFO - 2018-08-03 03:12:16 --> Config Class Initialized
INFO - 2018-08-03 03:12:16 --> Hooks Class Initialized
INFO - 2018-08-03 03:12:16 --> Config Class Initialized
INFO - 2018-08-03 03:12:17 --> Hooks Class Initialized
DEBUG - 2018-08-03 03:12:17 --> UTF-8 Support Enabled
DEBUG - 2018-08-03 03:12:17 --> UTF-8 Support Enabled
INFO - 2018-08-03 03:12:17 --> Utf8 Class Initialized
INFO - 2018-08-03 03:12:17 --> Utf8 Class Initialized
INFO - 2018-08-03 03:12:17 --> URI Class Initialized
INFO - 2018-08-03 03:12:17 --> Router Class Initialized
INFO - 2018-08-03 03:12:17 --> Output Class Initialized
INFO - 2018-08-03 03:12:17 --> Security Class Initialized
DEBUG - 2018-08-03 03:12:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 03:12:17 --> Input Class Initialized
INFO - 2018-08-03 03:12:17 --> Language Class Initialized
INFO - 2018-08-03 03:12:17 --> Language Class Initialized
INFO - 2018-08-03 03:12:17 --> URI Class Initialized
INFO - 2018-08-03 03:12:17 --> Config Class Initialized
INFO - 2018-08-03 03:12:17 --> Router Class Initialized
INFO - 2018-08-03 03:12:17 --> Output Class Initialized
INFO - 2018-08-03 03:12:17 --> Loader Class Initialized
DEBUG - 2018-08-03 03:12:17 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-03 03:12:17 --> Security Class Initialized
INFO - 2018-08-03 03:12:17 --> Helper loaded: url_helper
INFO - 2018-08-03 03:12:17 --> Helper loaded: form_helper
INFO - 2018-08-03 03:12:17 --> Helper loaded: date_helper
INFO - 2018-08-03 03:12:17 --> Helper loaded: util_helper
INFO - 2018-08-03 03:12:17 --> Helper loaded: text_helper
DEBUG - 2018-08-03 03:12:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 03:12:17 --> Helper loaded: string_helper
INFO - 2018-08-03 03:12:17 --> Input Class Initialized
INFO - 2018-08-03 03:12:17 --> Language Class Initialized
ERROR - 2018-08-03 03:12:17 --> 404 Page Not Found: /index
INFO - 2018-08-03 03:12:17 --> Database Driver Class Initialized
INFO - 2018-08-03 03:12:17 --> Config Class Initialized
INFO - 2018-08-03 03:12:17 --> Hooks Class Initialized
DEBUG - 2018-08-03 03:12:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 03:12:17 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-08-03 03:12:17 --> UTF-8 Support Enabled
INFO - 2018-08-03 03:12:17 --> Email Class Initialized
INFO - 2018-08-03 03:12:17 --> Utf8 Class Initialized
INFO - 2018-08-03 03:12:17 --> Controller Class Initialized
INFO - 2018-08-03 03:12:17 --> URI Class Initialized
DEBUG - 2018-08-03 03:12:18 --> Home MX_Controller Initialized
INFO - 2018-08-03 03:12:18 --> Router Class Initialized
DEBUG - 2018-08-03 03:12:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-08-03 03:12:18 --> Output Class Initialized
DEBUG - 2018-08-03 03:12:18 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
INFO - 2018-08-03 03:12:18 --> Security Class Initialized
DEBUG - 2018-08-03 03:12:18 --> Login MX_Controller Initialized
DEBUG - 2018-08-03 03:12:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 03:12:18 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-03 03:12:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-08-03 03:12:18 --> Input Class Initialized
DEBUG - 2018-08-03 03:12:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-03 03:12:18 --> Language Class Initialized
ERROR - 2018-08-03 03:12:18 --> 404 Page Not Found: /index
INFO - 2018-08-03 03:12:18 --> Config Class Initialized
INFO - 2018-08-03 03:12:18 --> Hooks Class Initialized
DEBUG - 2018-08-03 03:12:18 --> UTF-8 Support Enabled
INFO - 2018-08-03 03:12:18 --> Utf8 Class Initialized
INFO - 2018-08-03 03:12:18 --> URI Class Initialized
INFO - 2018-08-03 03:12:18 --> Router Class Initialized
INFO - 2018-08-03 03:12:18 --> Output Class Initialized
INFO - 2018-08-03 03:12:18 --> Security Class Initialized
DEBUG - 2018-08-03 03:12:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 03:12:18 --> Input Class Initialized
INFO - 2018-08-03 03:12:18 --> Language Class Initialized
ERROR - 2018-08-03 03:12:18 --> 404 Page Not Found: /index
INFO - 2018-08-03 03:12:22 --> Config Class Initialized
INFO - 2018-08-03 03:12:22 --> Hooks Class Initialized
DEBUG - 2018-08-03 03:12:22 --> UTF-8 Support Enabled
INFO - 2018-08-03 03:12:22 --> Utf8 Class Initialized
INFO - 2018-08-03 03:12:22 --> URI Class Initialized
INFO - 2018-08-03 03:12:22 --> Router Class Initialized
INFO - 2018-08-03 03:12:22 --> Output Class Initialized
INFO - 2018-08-03 03:12:22 --> Security Class Initialized
DEBUG - 2018-08-03 03:12:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 03:12:22 --> Input Class Initialized
INFO - 2018-08-03 03:12:22 --> Language Class Initialized
INFO - 2018-08-03 03:12:22 --> Language Class Initialized
INFO - 2018-08-03 03:12:22 --> Config Class Initialized
INFO - 2018-08-03 03:12:22 --> Loader Class Initialized
DEBUG - 2018-08-03 03:12:22 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-03 03:12:22 --> Helper loaded: url_helper
INFO - 2018-08-03 03:12:22 --> Helper loaded: form_helper
INFO - 2018-08-03 03:12:22 --> Helper loaded: date_helper
INFO - 2018-08-03 03:12:22 --> Helper loaded: util_helper
INFO - 2018-08-03 03:12:22 --> Helper loaded: text_helper
INFO - 2018-08-03 03:12:22 --> Helper loaded: string_helper
INFO - 2018-08-03 03:12:22 --> Database Driver Class Initialized
DEBUG - 2018-08-03 03:12:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 03:12:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-03 03:12:22 --> Email Class Initialized
INFO - 2018-08-03 03:12:22 --> Controller Class Initialized
DEBUG - 2018-08-03 03:12:22 --> Home MX_Controller Initialized
DEBUG - 2018-08-03 03:12:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-03 03:12:22 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-03 03:12:22 --> Login MX_Controller Initialized
INFO - 2018-08-03 03:12:22 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-03 03:12:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-03 03:12:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-03 03:12:24 --> Config Class Initialized
INFO - 2018-08-03 03:12:24 --> Hooks Class Initialized
DEBUG - 2018-08-03 03:12:24 --> UTF-8 Support Enabled
INFO - 2018-08-03 03:12:24 --> Utf8 Class Initialized
INFO - 2018-08-03 03:12:24 --> URI Class Initialized
INFO - 2018-08-03 03:12:24 --> Router Class Initialized
INFO - 2018-08-03 03:12:24 --> Output Class Initialized
INFO - 2018-08-03 03:12:24 --> Security Class Initialized
DEBUG - 2018-08-03 03:12:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 03:12:24 --> Input Class Initialized
INFO - 2018-08-03 03:12:24 --> Language Class Initialized
INFO - 2018-08-03 03:12:24 --> Language Class Initialized
INFO - 2018-08-03 03:12:24 --> Config Class Initialized
INFO - 2018-08-03 03:12:24 --> Loader Class Initialized
DEBUG - 2018-08-03 03:12:24 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-03 03:12:24 --> Helper loaded: url_helper
INFO - 2018-08-03 03:12:24 --> Helper loaded: form_helper
INFO - 2018-08-03 03:12:24 --> Helper loaded: date_helper
INFO - 2018-08-03 03:12:24 --> Helper loaded: util_helper
INFO - 2018-08-03 03:12:24 --> Helper loaded: text_helper
INFO - 2018-08-03 03:12:24 --> Helper loaded: string_helper
INFO - 2018-08-03 03:12:24 --> Database Driver Class Initialized
DEBUG - 2018-08-03 03:12:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 03:12:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-03 03:12:24 --> Email Class Initialized
INFO - 2018-08-03 03:12:24 --> Controller Class Initialized
DEBUG - 2018-08-03 03:12:24 --> Home MX_Controller Initialized
DEBUG - 2018-08-03 03:12:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-03 03:12:25 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-03 03:12:25 --> Login MX_Controller Initialized
INFO - 2018-08-03 03:12:25 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-03 03:12:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-03 03:12:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-03 03:12:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-08-03 03:12:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-08-03 03:12:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-08-03 03:12:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-08-03 03:12:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-08-03 03:12:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-08-03 03:12:25 --> Final output sent to browser
DEBUG - 2018-08-03 03:12:25 --> Total execution time: 0.9533
INFO - 2018-08-03 03:12:25 --> Config Class Initialized
INFO - 2018-08-03 03:12:26 --> Hooks Class Initialized
DEBUG - 2018-08-03 03:12:26 --> UTF-8 Support Enabled
INFO - 2018-08-03 03:12:26 --> Config Class Initialized
INFO - 2018-08-03 03:12:26 --> Hooks Class Initialized
INFO - 2018-08-03 03:12:26 --> Utf8 Class Initialized
DEBUG - 2018-08-03 03:12:26 --> UTF-8 Support Enabled
INFO - 2018-08-03 03:12:26 --> Utf8 Class Initialized
INFO - 2018-08-03 03:12:26 --> URI Class Initialized
INFO - 2018-08-03 03:12:26 --> URI Class Initialized
INFO - 2018-08-03 03:12:26 --> Router Class Initialized
INFO - 2018-08-03 03:12:26 --> Output Class Initialized
INFO - 2018-08-03 03:12:26 --> Security Class Initialized
INFO - 2018-08-03 03:12:26 --> Router Class Initialized
DEBUG - 2018-08-03 03:12:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 03:12:26 --> Output Class Initialized
INFO - 2018-08-03 03:12:26 --> Security Class Initialized
INFO - 2018-08-03 03:12:26 --> Input Class Initialized
DEBUG - 2018-08-03 03:12:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 03:12:26 --> Language Class Initialized
INFO - 2018-08-03 03:12:26 --> Input Class Initialized
INFO - 2018-08-03 03:12:26 --> Language Class Initialized
INFO - 2018-08-03 03:12:26 --> Config Class Initialized
INFO - 2018-08-03 03:12:26 --> Language Class Initialized
ERROR - 2018-08-03 03:12:26 --> 404 Page Not Found: /index
INFO - 2018-08-03 03:12:26 --> Loader Class Initialized
INFO - 2018-08-03 03:12:26 --> Config Class Initialized
INFO - 2018-08-03 03:12:26 --> Hooks Class Initialized
DEBUG - 2018-08-03 03:12:26 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
DEBUG - 2018-08-03 03:12:26 --> UTF-8 Support Enabled
INFO - 2018-08-03 03:12:26 --> Helper loaded: url_helper
INFO - 2018-08-03 03:12:26 --> Utf8 Class Initialized
INFO - 2018-08-03 03:12:26 --> Helper loaded: form_helper
INFO - 2018-08-03 03:12:26 --> URI Class Initialized
INFO - 2018-08-03 03:12:26 --> Router Class Initialized
INFO - 2018-08-03 03:12:26 --> Helper loaded: date_helper
INFO - 2018-08-03 03:12:26 --> Output Class Initialized
INFO - 2018-08-03 03:12:26 --> Helper loaded: util_helper
INFO - 2018-08-03 03:12:26 --> Security Class Initialized
DEBUG - 2018-08-03 03:12:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 03:12:26 --> Helper loaded: text_helper
INFO - 2018-08-03 03:12:26 --> Input Class Initialized
INFO - 2018-08-03 03:12:26 --> Helper loaded: string_helper
INFO - 2018-08-03 03:12:27 --> Language Class Initialized
INFO - 2018-08-03 03:12:27 --> Database Driver Class Initialized
ERROR - 2018-08-03 03:12:27 --> 404 Page Not Found: /index
DEBUG - 2018-08-03 03:12:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 03:12:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-03 03:12:27 --> Config Class Initialized
INFO - 2018-08-03 03:12:27 --> Email Class Initialized
INFO - 2018-08-03 03:12:27 --> Controller Class Initialized
DEBUG - 2018-08-03 03:12:27 --> Home MX_Controller Initialized
DEBUG - 2018-08-03 03:12:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-08-03 03:12:27 --> Hooks Class Initialized
DEBUG - 2018-08-03 03:12:27 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-03 03:12:27 --> Login MX_Controller Initialized
DEBUG - 2018-08-03 03:12:27 --> UTF-8 Support Enabled
INFO - 2018-08-03 03:12:27 --> Language file loaded: language/english/data_lang.php
INFO - 2018-08-03 03:12:27 --> Utf8 Class Initialized
DEBUG - 2018-08-03 03:12:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-08-03 03:12:27 --> URI Class Initialized
DEBUG - 2018-08-03 03:12:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-03 03:12:27 --> Router Class Initialized
INFO - 2018-08-03 03:12:27 --> Output Class Initialized
INFO - 2018-08-03 03:12:27 --> Security Class Initialized
DEBUG - 2018-08-03 03:12:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 03:12:27 --> Input Class Initialized
INFO - 2018-08-03 03:12:27 --> Language Class Initialized
ERROR - 2018-08-03 03:12:27 --> 404 Page Not Found: /index
INFO - 2018-08-03 03:12:40 --> Config Class Initialized
INFO - 2018-08-03 03:12:40 --> Hooks Class Initialized
DEBUG - 2018-08-03 03:12:40 --> UTF-8 Support Enabled
INFO - 2018-08-03 03:12:40 --> Utf8 Class Initialized
INFO - 2018-08-03 03:12:40 --> URI Class Initialized
INFO - 2018-08-03 03:12:40 --> Router Class Initialized
INFO - 2018-08-03 03:12:40 --> Output Class Initialized
INFO - 2018-08-03 03:12:41 --> Security Class Initialized
DEBUG - 2018-08-03 03:12:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 03:12:41 --> Input Class Initialized
INFO - 2018-08-03 03:12:41 --> Language Class Initialized
INFO - 2018-08-03 03:12:41 --> Language Class Initialized
INFO - 2018-08-03 03:12:41 --> Config Class Initialized
INFO - 2018-08-03 03:12:41 --> Loader Class Initialized
DEBUG - 2018-08-03 03:12:41 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-03 03:12:41 --> Helper loaded: url_helper
INFO - 2018-08-03 03:12:41 --> Helper loaded: form_helper
INFO - 2018-08-03 03:12:41 --> Helper loaded: date_helper
INFO - 2018-08-03 03:12:41 --> Helper loaded: util_helper
INFO - 2018-08-03 03:12:41 --> Helper loaded: text_helper
INFO - 2018-08-03 03:12:41 --> Helper loaded: string_helper
INFO - 2018-08-03 03:12:41 --> Database Driver Class Initialized
DEBUG - 2018-08-03 03:12:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 03:12:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-03 03:12:41 --> Email Class Initialized
INFO - 2018-08-03 03:12:41 --> Controller Class Initialized
DEBUG - 2018-08-03 03:12:41 --> Home MX_Controller Initialized
DEBUG - 2018-08-03 03:12:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-03 03:12:41 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-03 03:12:41 --> Login MX_Controller Initialized
INFO - 2018-08-03 03:12:41 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-03 03:12:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-03 03:12:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-03 03:12:42 --> Config Class Initialized
INFO - 2018-08-03 03:12:42 --> Hooks Class Initialized
DEBUG - 2018-08-03 03:12:42 --> UTF-8 Support Enabled
INFO - 2018-08-03 03:12:42 --> Utf8 Class Initialized
INFO - 2018-08-03 03:12:42 --> URI Class Initialized
INFO - 2018-08-03 03:12:43 --> Router Class Initialized
INFO - 2018-08-03 03:12:43 --> Output Class Initialized
INFO - 2018-08-03 03:12:43 --> Security Class Initialized
DEBUG - 2018-08-03 03:12:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 03:12:43 --> Input Class Initialized
INFO - 2018-08-03 03:12:43 --> Language Class Initialized
INFO - 2018-08-03 03:12:43 --> Language Class Initialized
INFO - 2018-08-03 03:12:43 --> Config Class Initialized
INFO - 2018-08-03 03:12:43 --> Loader Class Initialized
DEBUG - 2018-08-03 03:12:43 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-03 03:12:43 --> Helper loaded: url_helper
INFO - 2018-08-03 03:12:43 --> Helper loaded: form_helper
INFO - 2018-08-03 03:12:43 --> Helper loaded: date_helper
INFO - 2018-08-03 03:12:43 --> Helper loaded: util_helper
INFO - 2018-08-03 03:12:43 --> Helper loaded: text_helper
INFO - 2018-08-03 03:12:43 --> Helper loaded: string_helper
INFO - 2018-08-03 03:12:43 --> Database Driver Class Initialized
DEBUG - 2018-08-03 03:12:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 03:12:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-03 03:12:43 --> Email Class Initialized
INFO - 2018-08-03 03:12:43 --> Controller Class Initialized
DEBUG - 2018-08-03 03:12:43 --> Home MX_Controller Initialized
DEBUG - 2018-08-03 03:12:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-03 03:12:43 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-03 03:12:43 --> Login MX_Controller Initialized
INFO - 2018-08-03 03:12:43 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-03 03:12:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-03 03:12:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-03 03:12:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-08-03 03:12:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-08-03 03:12:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-08-03 03:12:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-08-03 03:12:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-08-03 03:12:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-08-03 03:12:43 --> Final output sent to browser
DEBUG - 2018-08-03 03:12:43 --> Total execution time: 0.9277
INFO - 2018-08-03 03:12:44 --> Config Class Initialized
INFO - 2018-08-03 03:12:44 --> Hooks Class Initialized
DEBUG - 2018-08-03 03:12:44 --> UTF-8 Support Enabled
INFO - 2018-08-03 03:12:44 --> Config Class Initialized
INFO - 2018-08-03 03:12:44 --> Hooks Class Initialized
INFO - 2018-08-03 03:12:44 --> Utf8 Class Initialized
DEBUG - 2018-08-03 03:12:44 --> UTF-8 Support Enabled
INFO - 2018-08-03 03:12:44 --> Utf8 Class Initialized
INFO - 2018-08-03 03:12:44 --> URI Class Initialized
INFO - 2018-08-03 03:12:44 --> URI Class Initialized
INFO - 2018-08-03 03:12:44 --> Router Class Initialized
INFO - 2018-08-03 03:12:44 --> Router Class Initialized
INFO - 2018-08-03 03:12:44 --> Output Class Initialized
INFO - 2018-08-03 03:12:44 --> Security Class Initialized
DEBUG - 2018-08-03 03:12:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 03:12:44 --> Input Class Initialized
INFO - 2018-08-03 03:12:44 --> Output Class Initialized
INFO - 2018-08-03 03:12:45 --> Security Class Initialized
INFO - 2018-08-03 03:12:45 --> Language Class Initialized
ERROR - 2018-08-03 03:12:45 --> 404 Page Not Found: /index
DEBUG - 2018-08-03 03:12:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 03:12:45 --> Input Class Initialized
INFO - 2018-08-03 03:12:45 --> Config Class Initialized
INFO - 2018-08-03 03:12:45 --> Language Class Initialized
INFO - 2018-08-03 03:12:45 --> Hooks Class Initialized
INFO - 2018-08-03 03:12:45 --> Language Class Initialized
INFO - 2018-08-03 03:12:45 --> Config Class Initialized
DEBUG - 2018-08-03 03:12:45 --> UTF-8 Support Enabled
INFO - 2018-08-03 03:12:45 --> Utf8 Class Initialized
INFO - 2018-08-03 03:12:45 --> Loader Class Initialized
DEBUG - 2018-08-03 03:12:45 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-03 03:12:45 --> URI Class Initialized
INFO - 2018-08-03 03:12:45 --> Helper loaded: url_helper
INFO - 2018-08-03 03:12:45 --> Helper loaded: form_helper
INFO - 2018-08-03 03:12:45 --> Router Class Initialized
INFO - 2018-08-03 03:12:45 --> Helper loaded: date_helper
INFO - 2018-08-03 03:12:45 --> Output Class Initialized
INFO - 2018-08-03 03:12:45 --> Helper loaded: util_helper
INFO - 2018-08-03 03:12:45 --> Helper loaded: text_helper
INFO - 2018-08-03 03:12:45 --> Security Class Initialized
INFO - 2018-08-03 03:12:45 --> Helper loaded: string_helper
DEBUG - 2018-08-03 03:12:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 03:12:45 --> Database Driver Class Initialized
INFO - 2018-08-03 03:12:45 --> Input Class Initialized
INFO - 2018-08-03 03:12:45 --> Language Class Initialized
DEBUG - 2018-08-03 03:12:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 03:12:45 --> Session: Class initialized using 'files' driver.
ERROR - 2018-08-03 03:12:45 --> 404 Page Not Found: /index
INFO - 2018-08-03 03:12:45 --> Email Class Initialized
INFO - 2018-08-03 03:12:45 --> Controller Class Initialized
DEBUG - 2018-08-03 03:12:45 --> Home MX_Controller Initialized
INFO - 2018-08-03 03:12:45 --> Config Class Initialized
DEBUG - 2018-08-03 03:12:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-08-03 03:12:45 --> Hooks Class Initialized
DEBUG - 2018-08-03 03:12:45 --> UTF-8 Support Enabled
DEBUG - 2018-08-03 03:12:45 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-03 03:12:45 --> Login MX_Controller Initialized
INFO - 2018-08-03 03:12:45 --> Utf8 Class Initialized
INFO - 2018-08-03 03:12:45 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-03 03:12:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-03 03:12:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-03 03:12:46 --> URI Class Initialized
INFO - 2018-08-03 03:12:46 --> Router Class Initialized
INFO - 2018-08-03 03:12:46 --> Output Class Initialized
INFO - 2018-08-03 03:12:46 --> Security Class Initialized
DEBUG - 2018-08-03 03:12:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 03:12:46 --> Input Class Initialized
INFO - 2018-08-03 03:12:46 --> Language Class Initialized
ERROR - 2018-08-03 03:12:46 --> 404 Page Not Found: /index
INFO - 2018-08-03 22:15:28 --> Config Class Initialized
INFO - 2018-08-03 22:15:28 --> Hooks Class Initialized
DEBUG - 2018-08-03 22:15:28 --> UTF-8 Support Enabled
INFO - 2018-08-03 22:15:28 --> Utf8 Class Initialized
INFO - 2018-08-03 22:15:28 --> URI Class Initialized
INFO - 2018-08-03 22:15:29 --> Router Class Initialized
INFO - 2018-08-03 22:15:29 --> Output Class Initialized
INFO - 2018-08-03 22:15:29 --> Security Class Initialized
DEBUG - 2018-08-03 22:15:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 22:15:29 --> Input Class Initialized
INFO - 2018-08-03 22:15:29 --> Language Class Initialized
INFO - 2018-08-03 22:15:29 --> Config Class Initialized
INFO - 2018-08-03 22:15:29 --> Hooks Class Initialized
DEBUG - 2018-08-03 22:15:29 --> UTF-8 Support Enabled
INFO - 2018-08-03 22:15:29 --> Utf8 Class Initialized
INFO - 2018-08-03 22:15:29 --> Language Class Initialized
INFO - 2018-08-03 22:15:29 --> URI Class Initialized
INFO - 2018-08-03 22:15:29 --> Router Class Initialized
INFO - 2018-08-03 22:15:29 --> Output Class Initialized
INFO - 2018-08-03 22:15:29 --> Security Class Initialized
DEBUG - 2018-08-03 22:15:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 22:15:29 --> Input Class Initialized
INFO - 2018-08-03 22:15:29 --> Language Class Initialized
INFO - 2018-08-03 22:15:29 --> Language Class Initialized
INFO - 2018-08-03 22:15:29 --> Config Class Initialized
INFO - 2018-08-03 22:15:29 --> Config Class Initialized
INFO - 2018-08-03 22:15:29 --> Loader Class Initialized
INFO - 2018-08-03 22:15:29 --> Loader Class Initialized
DEBUG - 2018-08-03 22:15:29 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
DEBUG - 2018-08-03 22:15:29 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-03 22:15:29 --> Helper loaded: url_helper
INFO - 2018-08-03 22:15:29 --> Helper loaded: url_helper
INFO - 2018-08-03 22:15:29 --> Helper loaded: form_helper
INFO - 2018-08-03 22:15:29 --> Helper loaded: form_helper
INFO - 2018-08-03 22:15:29 --> Helper loaded: date_helper
INFO - 2018-08-03 22:15:29 --> Helper loaded: date_helper
INFO - 2018-08-03 22:15:29 --> Helper loaded: util_helper
INFO - 2018-08-03 22:15:29 --> Helper loaded: util_helper
INFO - 2018-08-03 22:15:29 --> Helper loaded: text_helper
INFO - 2018-08-03 22:15:29 --> Helper loaded: text_helper
INFO - 2018-08-03 22:15:29 --> Helper loaded: string_helper
INFO - 2018-08-03 22:15:29 --> Helper loaded: string_helper
INFO - 2018-08-03 22:15:30 --> Database Driver Class Initialized
INFO - 2018-08-03 22:15:30 --> Database Driver Class Initialized
DEBUG - 2018-08-03 22:15:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-08-03 22:15:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 22:15:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-03 22:15:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-03 22:15:30 --> Email Class Initialized
INFO - 2018-08-03 22:15:30 --> Email Class Initialized
INFO - 2018-08-03 22:15:30 --> Controller Class Initialized
INFO - 2018-08-03 22:15:30 --> Controller Class Initialized
DEBUG - 2018-08-03 22:15:30 --> Home MX_Controller Initialized
DEBUG - 2018-08-03 22:15:30 --> Admin MX_Controller Initialized
DEBUG - 2018-08-03 22:15:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-08-03 22:15:30 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-03 22:15:30 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-03 22:15:30 --> Login MX_Controller Initialized
DEBUG - 2018-08-03 22:15:30 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-03 22:15:30 --> Login MX_Controller Initialized
DEBUG - 2018-08-03 22:15:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-08-03 22:15:30 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-03 22:15:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-03 22:15:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-03 22:15:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-03 22:15:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/login.php
DEBUG - 2018-08-03 22:15:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/logins/login.php
INFO - 2018-08-03 22:15:31 --> Config Class Initialized
INFO - 2018-08-03 22:15:31 --> Hooks Class Initialized
DEBUG - 2018-08-03 22:15:31 --> UTF-8 Support Enabled
INFO - 2018-08-03 22:15:31 --> Utf8 Class Initialized
INFO - 2018-08-03 22:15:31 --> URI Class Initialized
INFO - 2018-08-03 22:15:31 --> Router Class Initialized
INFO - 2018-08-03 22:15:31 --> Output Class Initialized
INFO - 2018-08-03 22:15:31 --> Security Class Initialized
DEBUG - 2018-08-03 22:15:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 22:15:31 --> Input Class Initialized
INFO - 2018-08-03 22:15:31 --> Language Class Initialized
ERROR - 2018-08-03 22:15:31 --> 404 Page Not Found: /index
INFO - 2018-08-03 22:15:38 --> Config Class Initialized
INFO - 2018-08-03 22:15:38 --> Hooks Class Initialized
DEBUG - 2018-08-03 22:15:38 --> UTF-8 Support Enabled
INFO - 2018-08-03 22:15:38 --> Utf8 Class Initialized
INFO - 2018-08-03 22:15:38 --> URI Class Initialized
INFO - 2018-08-03 22:15:38 --> Router Class Initialized
INFO - 2018-08-03 22:15:38 --> Output Class Initialized
INFO - 2018-08-03 22:15:38 --> Security Class Initialized
DEBUG - 2018-08-03 22:15:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 22:15:38 --> Input Class Initialized
INFO - 2018-08-03 22:15:38 --> Language Class Initialized
INFO - 2018-08-03 22:15:38 --> Language Class Initialized
INFO - 2018-08-03 22:15:39 --> Config Class Initialized
INFO - 2018-08-03 22:15:39 --> Loader Class Initialized
DEBUG - 2018-08-03 22:15:39 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-03 22:15:39 --> Helper loaded: url_helper
INFO - 2018-08-03 22:15:39 --> Helper loaded: form_helper
INFO - 2018-08-03 22:15:39 --> Helper loaded: date_helper
INFO - 2018-08-03 22:15:39 --> Helper loaded: util_helper
INFO - 2018-08-03 22:15:39 --> Helper loaded: text_helper
INFO - 2018-08-03 22:15:39 --> Helper loaded: string_helper
INFO - 2018-08-03 22:15:39 --> Database Driver Class Initialized
DEBUG - 2018-08-03 22:15:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 22:15:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-03 22:15:39 --> Email Class Initialized
INFO - 2018-08-03 22:15:39 --> Controller Class Initialized
DEBUG - 2018-08-03 22:15:39 --> Login MX_Controller Initialized
INFO - 2018-08-03 22:15:39 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-03 22:15:39 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-03 22:15:39 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-03 22:15:39 --> Email starts for colinUser fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-08-03 22:15:39 --> User session created for 4
INFO - 2018-08-03 22:15:39 --> Login status colinUser - success
INFO - 2018-08-03 22:15:39 --> Final output sent to browser
DEBUG - 2018-08-03 22:15:39 --> Total execution time: 0.8462
INFO - 2018-08-03 22:15:39 --> Config Class Initialized
INFO - 2018-08-03 22:15:39 --> Hooks Class Initialized
DEBUG - 2018-08-03 22:15:39 --> UTF-8 Support Enabled
INFO - 2018-08-03 22:15:39 --> Utf8 Class Initialized
INFO - 2018-08-03 22:15:39 --> URI Class Initialized
INFO - 2018-08-03 22:15:39 --> Router Class Initialized
INFO - 2018-08-03 22:15:39 --> Output Class Initialized
INFO - 2018-08-03 22:15:39 --> Security Class Initialized
DEBUG - 2018-08-03 22:15:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 22:15:39 --> Input Class Initialized
INFO - 2018-08-03 22:15:39 --> Language Class Initialized
INFO - 2018-08-03 22:15:39 --> Language Class Initialized
INFO - 2018-08-03 22:15:39 --> Config Class Initialized
INFO - 2018-08-03 22:15:39 --> Loader Class Initialized
DEBUG - 2018-08-03 22:15:39 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-03 22:15:39 --> Helper loaded: url_helper
INFO - 2018-08-03 22:15:40 --> Helper loaded: form_helper
INFO - 2018-08-03 22:15:40 --> Helper loaded: date_helper
INFO - 2018-08-03 22:15:40 --> Helper loaded: util_helper
INFO - 2018-08-03 22:15:40 --> Helper loaded: text_helper
INFO - 2018-08-03 22:15:40 --> Helper loaded: string_helper
INFO - 2018-08-03 22:15:40 --> Database Driver Class Initialized
DEBUG - 2018-08-03 22:15:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 22:15:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-03 22:15:40 --> Email Class Initialized
INFO - 2018-08-03 22:15:40 --> Controller Class Initialized
DEBUG - 2018-08-03 22:15:40 --> Home MX_Controller Initialized
DEBUG - 2018-08-03 22:15:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-03 22:15:40 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-03 22:15:40 --> Login MX_Controller Initialized
INFO - 2018-08-03 22:15:40 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-03 22:15:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-03 22:15:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-03 22:15:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-08-03 22:15:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-08-03 22:15:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-08-03 22:15:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-08-03 22:15:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-08-03 22:15:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-08-03 22:15:40 --> Final output sent to browser
DEBUG - 2018-08-03 22:15:40 --> Total execution time: 1.1647
INFO - 2018-08-03 22:15:41 --> Config Class Initialized
INFO - 2018-08-03 22:15:41 --> Hooks Class Initialized
DEBUG - 2018-08-03 22:15:41 --> UTF-8 Support Enabled
INFO - 2018-08-03 22:15:41 --> Utf8 Class Initialized
INFO - 2018-08-03 22:15:41 --> URI Class Initialized
INFO - 2018-08-03 22:15:41 --> Router Class Initialized
INFO - 2018-08-03 22:15:41 --> Output Class Initialized
INFO - 2018-08-03 22:15:41 --> Security Class Initialized
DEBUG - 2018-08-03 22:15:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 22:15:42 --> Input Class Initialized
INFO - 2018-08-03 22:15:42 --> Language Class Initialized
ERROR - 2018-08-03 22:15:42 --> 404 Page Not Found: /index
INFO - 2018-08-03 22:15:42 --> Config Class Initialized
INFO - 2018-08-03 22:15:42 --> Hooks Class Initialized
INFO - 2018-08-03 22:15:42 --> Config Class Initialized
INFO - 2018-08-03 22:15:42 --> Hooks Class Initialized
DEBUG - 2018-08-03 22:15:42 --> UTF-8 Support Enabled
INFO - 2018-08-03 22:15:42 --> Utf8 Class Initialized
DEBUG - 2018-08-03 22:15:42 --> UTF-8 Support Enabled
INFO - 2018-08-03 22:15:42 --> Config Class Initialized
INFO - 2018-08-03 22:15:42 --> Hooks Class Initialized
INFO - 2018-08-03 22:15:42 --> Utf8 Class Initialized
INFO - 2018-08-03 22:15:42 --> URI Class Initialized
INFO - 2018-08-03 22:15:42 --> URI Class Initialized
INFO - 2018-08-03 22:15:42 --> Router Class Initialized
INFO - 2018-08-03 22:15:42 --> Router Class Initialized
DEBUG - 2018-08-03 22:15:42 --> UTF-8 Support Enabled
INFO - 2018-08-03 22:15:42 --> Utf8 Class Initialized
INFO - 2018-08-03 22:15:42 --> Output Class Initialized
INFO - 2018-08-03 22:15:42 --> Output Class Initialized
INFO - 2018-08-03 22:15:42 --> URI Class Initialized
INFO - 2018-08-03 22:15:42 --> Security Class Initialized
INFO - 2018-08-03 22:15:42 --> Security Class Initialized
INFO - 2018-08-03 22:15:42 --> Router Class Initialized
INFO - 2018-08-03 22:15:42 --> Output Class Initialized
INFO - 2018-08-03 22:15:42 --> Security Class Initialized
DEBUG - 2018-08-03 22:15:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 22:15:42 --> Input Class Initialized
INFO - 2018-08-03 22:15:42 --> Language Class Initialized
ERROR - 2018-08-03 22:15:42 --> 404 Page Not Found: /index
DEBUG - 2018-08-03 22:15:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 22:15:42 --> Input Class Initialized
DEBUG - 2018-08-03 22:15:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 22:15:42 --> Language Class Initialized
INFO - 2018-08-03 22:15:42 --> Language Class Initialized
INFO - 2018-08-03 22:15:42 --> Config Class Initialized
INFO - 2018-08-03 22:15:42 --> Input Class Initialized
INFO - 2018-08-03 22:15:42 --> Hooks Class Initialized
INFO - 2018-08-03 22:15:42 --> Config Class Initialized
INFO - 2018-08-03 22:15:42 --> Language Class Initialized
DEBUG - 2018-08-03 22:15:42 --> UTF-8 Support Enabled
INFO - 2018-08-03 22:15:42 --> Loader Class Initialized
INFO - 2018-08-03 22:15:42 --> Utf8 Class Initialized
DEBUG - 2018-08-03 22:15:42 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
ERROR - 2018-08-03 22:15:42 --> 404 Page Not Found: /index
INFO - 2018-08-03 22:15:42 --> URI Class Initialized
INFO - 2018-08-03 22:15:42 --> Helper loaded: url_helper
INFO - 2018-08-03 22:15:42 --> Config Class Initialized
INFO - 2018-08-03 22:15:42 --> Hooks Class Initialized
INFO - 2018-08-03 22:15:42 --> Helper loaded: form_helper
INFO - 2018-08-03 22:15:42 --> Router Class Initialized
INFO - 2018-08-03 22:15:42 --> Helper loaded: date_helper
DEBUG - 2018-08-03 22:15:42 --> UTF-8 Support Enabled
INFO - 2018-08-03 22:15:42 --> Output Class Initialized
INFO - 2018-08-03 22:15:42 --> Utf8 Class Initialized
INFO - 2018-08-03 22:15:42 --> Helper loaded: util_helper
INFO - 2018-08-03 22:15:42 --> URI Class Initialized
INFO - 2018-08-03 22:15:42 --> Helper loaded: text_helper
INFO - 2018-08-03 22:15:42 --> Security Class Initialized
INFO - 2018-08-03 22:15:42 --> Helper loaded: string_helper
DEBUG - 2018-08-03 22:15:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 22:15:42 --> Router Class Initialized
INFO - 2018-08-03 22:15:42 --> Input Class Initialized
INFO - 2018-08-03 22:15:42 --> Output Class Initialized
INFO - 2018-08-03 22:15:42 --> Database Driver Class Initialized
INFO - 2018-08-03 22:15:42 --> Security Class Initialized
INFO - 2018-08-03 22:15:42 --> Language Class Initialized
DEBUG - 2018-08-03 22:15:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 22:15:42 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-08-03 22:15:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-08-03 22:15:42 --> 404 Page Not Found: /index
INFO - 2018-08-03 22:15:42 --> Input Class Initialized
INFO - 2018-08-03 22:15:42 --> Email Class Initialized
INFO - 2018-08-03 22:15:42 --> Controller Class Initialized
INFO - 2018-08-03 22:15:42 --> Language Class Initialized
INFO - 2018-08-03 22:15:42 --> Config Class Initialized
INFO - 2018-08-03 22:15:43 --> Hooks Class Initialized
DEBUG - 2018-08-03 22:15:43 --> Home MX_Controller Initialized
ERROR - 2018-08-03 22:15:43 --> 404 Page Not Found: /index
DEBUG - 2018-08-03 22:15:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-03 22:15:43 --> UTF-8 Support Enabled
INFO - 2018-08-03 22:15:43 --> Utf8 Class Initialized
DEBUG - 2018-08-03 22:15:43 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-03 22:15:43 --> Login MX_Controller Initialized
INFO - 2018-08-03 22:15:43 --> URI Class Initialized
INFO - 2018-08-03 22:15:43 --> Language file loaded: language/english/data_lang.php
INFO - 2018-08-03 22:15:43 --> Router Class Initialized
DEBUG - 2018-08-03 22:15:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-08-03 22:15:43 --> Output Class Initialized
DEBUG - 2018-08-03 22:15:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-03 22:15:43 --> Security Class Initialized
DEBUG - 2018-08-03 22:15:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 22:15:43 --> Input Class Initialized
INFO - 2018-08-03 22:15:43 --> Language Class Initialized
ERROR - 2018-08-03 22:15:43 --> 404 Page Not Found: /index
INFO - 2018-08-03 22:15:43 --> Config Class Initialized
INFO - 2018-08-03 22:15:43 --> Hooks Class Initialized
DEBUG - 2018-08-03 22:15:43 --> UTF-8 Support Enabled
INFO - 2018-08-03 22:15:43 --> Utf8 Class Initialized
INFO - 2018-08-03 22:15:43 --> URI Class Initialized
INFO - 2018-08-03 22:15:43 --> Router Class Initialized
INFO - 2018-08-03 22:15:43 --> Output Class Initialized
INFO - 2018-08-03 22:15:43 --> Security Class Initialized
DEBUG - 2018-08-03 22:15:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 22:15:43 --> Input Class Initialized
INFO - 2018-08-03 22:15:43 --> Language Class Initialized
ERROR - 2018-08-03 22:15:43 --> 404 Page Not Found: /index
INFO - 2018-08-03 22:15:43 --> Config Class Initialized
INFO - 2018-08-03 22:15:43 --> Hooks Class Initialized
DEBUG - 2018-08-03 22:15:43 --> UTF-8 Support Enabled
INFO - 2018-08-03 22:15:43 --> Utf8 Class Initialized
INFO - 2018-08-03 22:15:43 --> URI Class Initialized
INFO - 2018-08-03 22:15:43 --> Router Class Initialized
INFO - 2018-08-03 22:15:43 --> Output Class Initialized
INFO - 2018-08-03 22:15:43 --> Security Class Initialized
DEBUG - 2018-08-03 22:15:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 22:15:43 --> Input Class Initialized
INFO - 2018-08-03 22:15:43 --> Language Class Initialized
ERROR - 2018-08-03 22:15:43 --> 404 Page Not Found: /index
INFO - 2018-08-03 22:15:44 --> Config Class Initialized
INFO - 2018-08-03 22:15:44 --> Hooks Class Initialized
DEBUG - 2018-08-03 22:15:44 --> UTF-8 Support Enabled
INFO - 2018-08-03 22:15:44 --> Utf8 Class Initialized
INFO - 2018-08-03 22:15:44 --> URI Class Initialized
INFO - 2018-08-03 22:15:44 --> Router Class Initialized
INFO - 2018-08-03 22:15:44 --> Output Class Initialized
INFO - 2018-08-03 22:15:44 --> Security Class Initialized
DEBUG - 2018-08-03 22:15:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 22:15:44 --> Input Class Initialized
INFO - 2018-08-03 22:15:44 --> Language Class Initialized
ERROR - 2018-08-03 22:15:44 --> 404 Page Not Found: /index
INFO - 2018-08-03 22:15:44 --> Config Class Initialized
INFO - 2018-08-03 22:15:44 --> Hooks Class Initialized
DEBUG - 2018-08-03 22:15:44 --> UTF-8 Support Enabled
INFO - 2018-08-03 22:15:44 --> Utf8 Class Initialized
INFO - 2018-08-03 22:15:44 --> URI Class Initialized
INFO - 2018-08-03 22:15:44 --> Router Class Initialized
INFO - 2018-08-03 22:15:44 --> Output Class Initialized
INFO - 2018-08-03 22:15:44 --> Security Class Initialized
DEBUG - 2018-08-03 22:15:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 22:15:44 --> Input Class Initialized
INFO - 2018-08-03 22:15:44 --> Language Class Initialized
ERROR - 2018-08-03 22:15:44 --> 404 Page Not Found: /index
INFO - 2018-08-03 22:15:44 --> Config Class Initialized
INFO - 2018-08-03 22:15:44 --> Hooks Class Initialized
DEBUG - 2018-08-03 22:15:44 --> UTF-8 Support Enabled
INFO - 2018-08-03 22:15:44 --> Utf8 Class Initialized
INFO - 2018-08-03 22:15:44 --> URI Class Initialized
INFO - 2018-08-03 22:15:44 --> Router Class Initialized
INFO - 2018-08-03 22:15:44 --> Output Class Initialized
INFO - 2018-08-03 22:15:44 --> Security Class Initialized
DEBUG - 2018-08-03 22:15:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 22:15:44 --> Input Class Initialized
INFO - 2018-08-03 22:15:44 --> Language Class Initialized
ERROR - 2018-08-03 22:15:44 --> 404 Page Not Found: /index
INFO - 2018-08-03 22:15:45 --> Config Class Initialized
INFO - 2018-08-03 22:15:45 --> Hooks Class Initialized
DEBUG - 2018-08-03 22:15:45 --> UTF-8 Support Enabled
INFO - 2018-08-03 22:15:45 --> Utf8 Class Initialized
INFO - 2018-08-03 22:15:45 --> URI Class Initialized
INFO - 2018-08-03 22:15:45 --> Router Class Initialized
INFO - 2018-08-03 22:15:45 --> Output Class Initialized
INFO - 2018-08-03 22:15:45 --> Security Class Initialized
DEBUG - 2018-08-03 22:15:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 22:15:45 --> Input Class Initialized
INFO - 2018-08-03 22:15:45 --> Language Class Initialized
INFO - 2018-08-03 22:15:45 --> Language Class Initialized
INFO - 2018-08-03 22:15:45 --> Config Class Initialized
INFO - 2018-08-03 22:15:45 --> Loader Class Initialized
DEBUG - 2018-08-03 22:15:45 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-03 22:15:45 --> Helper loaded: url_helper
INFO - 2018-08-03 22:15:45 --> Helper loaded: form_helper
INFO - 2018-08-03 22:15:45 --> Helper loaded: date_helper
INFO - 2018-08-03 22:15:45 --> Helper loaded: util_helper
INFO - 2018-08-03 22:15:45 --> Helper loaded: text_helper
INFO - 2018-08-03 22:15:45 --> Helper loaded: string_helper
INFO - 2018-08-03 22:15:45 --> Database Driver Class Initialized
DEBUG - 2018-08-03 22:15:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 22:15:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-03 22:15:45 --> Email Class Initialized
INFO - 2018-08-03 22:15:45 --> Controller Class Initialized
DEBUG - 2018-08-03 22:15:45 --> Login MX_Controller Initialized
INFO - 2018-08-03 22:15:46 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-03 22:15:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-03 22:15:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-03 22:15:46 --> Email starts for colin-admin fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-08-03 22:15:46 --> User session created for 1
INFO - 2018-08-03 22:15:46 --> Login status colin-admin - success
INFO - 2018-08-03 22:15:46 --> Final output sent to browser
DEBUG - 2018-08-03 22:15:46 --> Total execution time: 0.7770
INFO - 2018-08-03 22:15:46 --> Config Class Initialized
INFO - 2018-08-03 22:15:46 --> Hooks Class Initialized
DEBUG - 2018-08-03 22:15:46 --> UTF-8 Support Enabled
INFO - 2018-08-03 22:15:46 --> Utf8 Class Initialized
INFO - 2018-08-03 22:15:46 --> URI Class Initialized
INFO - 2018-08-03 22:15:46 --> Router Class Initialized
INFO - 2018-08-03 22:15:46 --> Output Class Initialized
INFO - 2018-08-03 22:15:46 --> Security Class Initialized
DEBUG - 2018-08-03 22:15:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 22:15:46 --> Input Class Initialized
INFO - 2018-08-03 22:15:46 --> Language Class Initialized
INFO - 2018-08-03 22:15:46 --> Language Class Initialized
INFO - 2018-08-03 22:15:46 --> Config Class Initialized
INFO - 2018-08-03 22:15:46 --> Loader Class Initialized
DEBUG - 2018-08-03 22:15:46 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-03 22:15:46 --> Helper loaded: url_helper
INFO - 2018-08-03 22:15:46 --> Helper loaded: form_helper
INFO - 2018-08-03 22:15:46 --> Helper loaded: date_helper
INFO - 2018-08-03 22:15:46 --> Helper loaded: util_helper
INFO - 2018-08-03 22:15:46 --> Helper loaded: text_helper
INFO - 2018-08-03 22:15:46 --> Helper loaded: string_helper
INFO - 2018-08-03 22:15:46 --> Database Driver Class Initialized
DEBUG - 2018-08-03 22:15:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 22:15:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-03 22:15:46 --> Email Class Initialized
INFO - 2018-08-03 22:15:46 --> Controller Class Initialized
DEBUG - 2018-08-03 22:15:46 --> Admin MX_Controller Initialized
INFO - 2018-08-03 22:15:46 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-03 22:15:46 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-03 22:15:46 --> Login MX_Controller Initialized
DEBUG - 2018-08-03 22:15:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-03 22:15:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-03 22:15:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-08-03 22:15:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-08-03 22:15:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-08-03 22:15:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-08-03 22:15:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-08-03 22:15:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/dashboard.php
INFO - 2018-08-03 22:15:47 --> Final output sent to browser
DEBUG - 2018-08-03 22:15:47 --> Total execution time: 1.2661
INFO - 2018-08-03 22:15:49 --> Config Class Initialized
INFO - 2018-08-03 22:15:49 --> Hooks Class Initialized
DEBUG - 2018-08-03 22:15:49 --> UTF-8 Support Enabled
INFO - 2018-08-03 22:15:49 --> Utf8 Class Initialized
INFO - 2018-08-03 22:15:50 --> URI Class Initialized
INFO - 2018-08-03 22:15:50 --> Router Class Initialized
INFO - 2018-08-03 22:15:50 --> Output Class Initialized
INFO - 2018-08-03 22:15:50 --> Security Class Initialized
DEBUG - 2018-08-03 22:15:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 22:15:50 --> Input Class Initialized
INFO - 2018-08-03 22:15:50 --> Language Class Initialized
INFO - 2018-08-03 22:15:50 --> Language Class Initialized
INFO - 2018-08-03 22:15:50 --> Config Class Initialized
INFO - 2018-08-03 22:15:50 --> Loader Class Initialized
DEBUG - 2018-08-03 22:15:50 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-03 22:15:50 --> Helper loaded: url_helper
INFO - 2018-08-03 22:15:50 --> Helper loaded: form_helper
INFO - 2018-08-03 22:15:50 --> Helper loaded: date_helper
INFO - 2018-08-03 22:15:50 --> Helper loaded: util_helper
INFO - 2018-08-03 22:15:50 --> Helper loaded: text_helper
INFO - 2018-08-03 22:15:50 --> Helper loaded: string_helper
INFO - 2018-08-03 22:15:50 --> Database Driver Class Initialized
DEBUG - 2018-08-03 22:15:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 22:15:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-03 22:15:50 --> Email Class Initialized
INFO - 2018-08-03 22:15:51 --> Controller Class Initialized
DEBUG - 2018-08-03 22:15:51 --> Home MX_Controller Initialized
DEBUG - 2018-08-03 22:15:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-03 22:15:51 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-03 22:15:51 --> Login MX_Controller Initialized
INFO - 2018-08-03 22:15:51 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-03 22:15:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-03 22:15:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-03 22:16:14 --> Config Class Initialized
INFO - 2018-08-03 22:16:14 --> Hooks Class Initialized
DEBUG - 2018-08-03 22:16:14 --> UTF-8 Support Enabled
INFO - 2018-08-03 22:16:14 --> Utf8 Class Initialized
INFO - 2018-08-03 22:16:14 --> URI Class Initialized
INFO - 2018-08-03 22:16:14 --> Router Class Initialized
INFO - 2018-08-03 22:16:14 --> Output Class Initialized
INFO - 2018-08-03 22:16:14 --> Security Class Initialized
DEBUG - 2018-08-03 22:16:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 22:16:14 --> Input Class Initialized
INFO - 2018-08-03 22:16:14 --> Language Class Initialized
INFO - 2018-08-03 22:16:14 --> Language Class Initialized
INFO - 2018-08-03 22:16:14 --> Config Class Initialized
INFO - 2018-08-03 22:16:14 --> Loader Class Initialized
DEBUG - 2018-08-03 22:16:14 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-03 22:16:14 --> Helper loaded: url_helper
INFO - 2018-08-03 22:16:14 --> Helper loaded: form_helper
INFO - 2018-08-03 22:16:14 --> Helper loaded: date_helper
INFO - 2018-08-03 22:16:14 --> Helper loaded: util_helper
INFO - 2018-08-03 22:16:14 --> Helper loaded: text_helper
INFO - 2018-08-03 22:16:14 --> Helper loaded: string_helper
INFO - 2018-08-03 22:16:14 --> Database Driver Class Initialized
DEBUG - 2018-08-03 22:16:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 22:16:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-03 22:16:14 --> Email Class Initialized
INFO - 2018-08-03 22:16:14 --> Controller Class Initialized
DEBUG - 2018-08-03 22:16:14 --> Home MX_Controller Initialized
DEBUG - 2018-08-03 22:16:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-03 22:16:15 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-03 22:16:15 --> Login MX_Controller Initialized
INFO - 2018-08-03 22:16:15 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-03 22:16:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-03 22:16:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-03 22:16:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-08-03 22:16:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-08-03 22:16:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-08-03 22:16:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-08-03 22:16:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-08-03 22:16:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-08-03 22:16:15 --> Final output sent to browser
DEBUG - 2018-08-03 22:16:15 --> Total execution time: 0.9990
INFO - 2018-08-03 22:16:15 --> Config Class Initialized
INFO - 2018-08-03 22:16:15 --> Config Class Initialized
INFO - 2018-08-03 22:16:15 --> Hooks Class Initialized
INFO - 2018-08-03 22:16:15 --> Hooks Class Initialized
INFO - 2018-08-03 22:16:15 --> Config Class Initialized
INFO - 2018-08-03 22:16:15 --> Hooks Class Initialized
DEBUG - 2018-08-03 22:16:15 --> UTF-8 Support Enabled
DEBUG - 2018-08-03 22:16:15 --> UTF-8 Support Enabled
DEBUG - 2018-08-03 22:16:15 --> UTF-8 Support Enabled
INFO - 2018-08-03 22:16:15 --> Utf8 Class Initialized
INFO - 2018-08-03 22:16:15 --> Utf8 Class Initialized
INFO - 2018-08-03 22:16:15 --> Utf8 Class Initialized
INFO - 2018-08-03 22:16:15 --> URI Class Initialized
INFO - 2018-08-03 22:16:15 --> URI Class Initialized
INFO - 2018-08-03 22:16:15 --> Router Class Initialized
INFO - 2018-08-03 22:16:15 --> URI Class Initialized
INFO - 2018-08-03 22:16:16 --> Router Class Initialized
INFO - 2018-08-03 22:16:16 --> Router Class Initialized
INFO - 2018-08-03 22:16:16 --> Output Class Initialized
INFO - 2018-08-03 22:16:16 --> Output Class Initialized
INFO - 2018-08-03 22:16:16 --> Output Class Initialized
INFO - 2018-08-03 22:16:16 --> Security Class Initialized
INFO - 2018-08-03 22:16:16 --> Security Class Initialized
DEBUG - 2018-08-03 22:16:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 22:16:16 --> Security Class Initialized
INFO - 2018-08-03 22:16:16 --> Input Class Initialized
DEBUG - 2018-08-03 22:16:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 22:16:16 --> Input Class Initialized
INFO - 2018-08-03 22:16:16 --> Language Class Initialized
INFO - 2018-08-03 22:16:16 --> Language Class Initialized
ERROR - 2018-08-03 22:16:16 --> 404 Page Not Found: /index
DEBUG - 2018-08-03 22:16:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 22:16:16 --> Input Class Initialized
INFO - 2018-08-03 22:16:16 --> Language Class Initialized
INFO - 2018-08-03 22:16:16 --> Config Class Initialized
INFO - 2018-08-03 22:16:16 --> Language Class Initialized
INFO - 2018-08-03 22:16:16 --> Config Class Initialized
INFO - 2018-08-03 22:16:16 --> Hooks Class Initialized
INFO - 2018-08-03 22:16:16 --> Loader Class Initialized
DEBUG - 2018-08-03 22:16:16 --> UTF-8 Support Enabled
INFO - 2018-08-03 22:16:16 --> Utf8 Class Initialized
INFO - 2018-08-03 22:16:16 --> URI Class Initialized
ERROR - 2018-08-03 22:16:16 --> 404 Page Not Found: /index
DEBUG - 2018-08-03 22:16:16 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-03 22:16:16 --> Router Class Initialized
INFO - 2018-08-03 22:16:16 --> Output Class Initialized
INFO - 2018-08-03 22:16:16 --> Security Class Initialized
DEBUG - 2018-08-03 22:16:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-03 22:16:16 --> Input Class Initialized
INFO - 2018-08-03 22:16:16 --> Language Class Initialized
ERROR - 2018-08-03 22:16:16 --> 404 Page Not Found: /index
INFO - 2018-08-03 22:16:16 --> Config Class Initialized
INFO - 2018-08-03 22:16:16 --> Helper loaded: url_helper
INFO - 2018-08-03 22:16:16 --> Hooks Class Initialized
DEBUG - 2018-08-03 22:16:16 --> UTF-8 Support Enabled
INFO - 2018-08-03 22:16:16 --> Utf8 Class Initialized
INFO - 2018-08-03 22:16:16 --> URI Class Initialized
INFO - 2018-08-03 22:16:16 --> Helper loaded: form_helper
INFO - 2018-08-03 22:16:16 --> Router Class Initialized
INFO - 2018-08-03 22:16:16 --> Helper loaded: date_helper
INFO - 2018-08-03 22:16:16 --> Output Class Initialized
INFO - 2018-08-03 22:16:16 --> Helper loaded: util_helper
INFO - 2018-08-03 22:16:16 --> Helper loaded: text_helper
INFO - 2018-08-03 22:16:16 --> Helper loaded: string_helper
INFO - 2018-08-03 22:16:16 --> Security Class Initialized
INFO - 2018-08-03 22:16:16 --> Database Driver Class Initialized
DEBUG - 2018-08-03 22:16:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-08-03 22:16:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-03 22:16:16 --> Input Class Initialized
INFO - 2018-08-03 22:16:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-03 22:16:16 --> Language Class Initialized
INFO - 2018-08-03 22:16:16 --> Email Class Initialized
INFO - 2018-08-03 22:16:17 --> Controller Class Initialized
ERROR - 2018-08-03 22:16:17 --> 404 Page Not Found: /index
DEBUG - 2018-08-03 22:16:17 --> Home MX_Controller Initialized
DEBUG - 2018-08-03 22:16:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-03 22:16:17 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-03 22:16:17 --> Login MX_Controller Initialized
INFO - 2018-08-03 22:16:17 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-03 22:16:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-03 22:16:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
