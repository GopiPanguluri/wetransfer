<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-08-06 22:37:55 --> Config Class Initialized
INFO - 2018-08-06 22:37:55 --> Hooks Class Initialized
DEBUG - 2018-08-06 22:37:55 --> UTF-8 Support Enabled
INFO - 2018-08-06 22:37:55 --> Utf8 Class Initialized
INFO - 2018-08-06 22:37:55 --> URI Class Initialized
INFO - 2018-08-06 22:37:55 --> Router Class Initialized
INFO - 2018-08-06 22:37:55 --> Output Class Initialized
INFO - 2018-08-06 22:37:55 --> Config Class Initialized
INFO - 2018-08-06 22:37:55 --> Hooks Class Initialized
DEBUG - 2018-08-06 22:37:55 --> UTF-8 Support Enabled
INFO - 2018-08-06 22:37:55 --> Utf8 Class Initialized
INFO - 2018-08-06 22:37:55 --> URI Class Initialized
INFO - 2018-08-06 22:37:55 --> Security Class Initialized
INFO - 2018-08-06 22:37:55 --> Router Class Initialized
INFO - 2018-08-06 22:37:55 --> Output Class Initialized
INFO - 2018-08-06 22:37:55 --> Security Class Initialized
DEBUG - 2018-08-06 22:37:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-08-06 22:37:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-06 22:37:55 --> Input Class Initialized
INFO - 2018-08-06 22:37:55 --> Input Class Initialized
INFO - 2018-08-06 22:37:55 --> Language Class Initialized
INFO - 2018-08-06 22:37:55 --> Language Class Initialized
INFO - 2018-08-06 22:37:56 --> Language Class Initialized
INFO - 2018-08-06 22:37:56 --> Language Class Initialized
INFO - 2018-08-06 22:37:56 --> Config Class Initialized
INFO - 2018-08-06 22:37:56 --> Config Class Initialized
INFO - 2018-08-06 22:37:56 --> Loader Class Initialized
INFO - 2018-08-06 22:37:56 --> Loader Class Initialized
DEBUG - 2018-08-06 22:37:56 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
DEBUG - 2018-08-06 22:37:56 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-06 22:37:56 --> Helper loaded: url_helper
INFO - 2018-08-06 22:37:56 --> Helper loaded: form_helper
INFO - 2018-08-06 22:37:56 --> Helper loaded: date_helper
INFO - 2018-08-06 22:37:56 --> Helper loaded: url_helper
INFO - 2018-08-06 22:37:56 --> Helper loaded: util_helper
INFO - 2018-08-06 22:37:56 --> Helper loaded: form_helper
INFO - 2018-08-06 22:37:56 --> Helper loaded: text_helper
INFO - 2018-08-06 22:37:56 --> Helper loaded: date_helper
INFO - 2018-08-06 22:37:56 --> Helper loaded: string_helper
INFO - 2018-08-06 22:37:56 --> Helper loaded: util_helper
INFO - 2018-08-06 22:37:56 --> Helper loaded: text_helper
INFO - 2018-08-06 22:37:56 --> Helper loaded: string_helper
INFO - 2018-08-06 22:37:56 --> Database Driver Class Initialized
INFO - 2018-08-06 22:37:56 --> Database Driver Class Initialized
DEBUG - 2018-08-06 22:37:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-08-06 22:37:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-06 22:37:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-06 22:37:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-06 22:37:56 --> Email Class Initialized
INFO - 2018-08-06 22:37:56 --> Controller Class Initialized
DEBUG - 2018-08-06 22:37:56 --> Home MX_Controller Initialized
DEBUG - 2018-08-06 22:37:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-08-06 22:37:56 --> Email Class Initialized
INFO - 2018-08-06 22:37:56 --> Controller Class Initialized
DEBUG - 2018-08-06 22:37:56 --> Admin MX_Controller Initialized
INFO - 2018-08-06 22:37:56 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-06 22:37:56 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-06 22:37:56 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-06 22:37:56 --> Login MX_Controller Initialized
INFO - 2018-08-06 22:37:56 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-06 22:37:56 --> Login MX_Controller Initialized
DEBUG - 2018-08-06 22:37:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-06 22:37:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-06 22:37:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-06 22:37:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-06 22:37:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/login.php
DEBUG - 2018-08-06 22:37:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/logins/login.php
INFO - 2018-08-06 22:37:57 --> Config Class Initialized
INFO - 2018-08-06 22:37:57 --> Hooks Class Initialized
DEBUG - 2018-08-06 22:37:57 --> UTF-8 Support Enabled
INFO - 2018-08-06 22:37:57 --> Utf8 Class Initialized
INFO - 2018-08-06 22:37:57 --> URI Class Initialized
INFO - 2018-08-06 22:37:57 --> Router Class Initialized
INFO - 2018-08-06 22:37:57 --> Output Class Initialized
INFO - 2018-08-06 22:37:57 --> Security Class Initialized
DEBUG - 2018-08-06 22:37:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-06 22:37:57 --> Input Class Initialized
INFO - 2018-08-06 22:37:57 --> Language Class Initialized
ERROR - 2018-08-06 22:37:57 --> 404 Page Not Found: /index
INFO - 2018-08-06 22:37:57 --> Config Class Initialized
INFO - 2018-08-06 22:37:57 --> Hooks Class Initialized
DEBUG - 2018-08-06 22:37:57 --> UTF-8 Support Enabled
INFO - 2018-08-06 22:37:57 --> Utf8 Class Initialized
INFO - 2018-08-06 22:37:57 --> URI Class Initialized
INFO - 2018-08-06 22:37:57 --> Router Class Initialized
INFO - 2018-08-06 22:37:57 --> Output Class Initialized
INFO - 2018-08-06 22:37:57 --> Security Class Initialized
DEBUG - 2018-08-06 22:37:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-06 22:37:57 --> Input Class Initialized
INFO - 2018-08-06 22:37:57 --> Language Class Initialized
ERROR - 2018-08-06 22:37:57 --> 404 Page Not Found: /index
INFO - 2018-08-06 22:38:07 --> Config Class Initialized
INFO - 2018-08-06 22:38:07 --> Hooks Class Initialized
DEBUG - 2018-08-06 22:38:07 --> UTF-8 Support Enabled
INFO - 2018-08-06 22:38:07 --> Utf8 Class Initialized
INFO - 2018-08-06 22:38:07 --> URI Class Initialized
INFO - 2018-08-06 22:38:07 --> Router Class Initialized
INFO - 2018-08-06 22:38:07 --> Output Class Initialized
INFO - 2018-08-06 22:38:07 --> Security Class Initialized
DEBUG - 2018-08-06 22:38:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-06 22:38:07 --> Input Class Initialized
INFO - 2018-08-06 22:38:07 --> Language Class Initialized
INFO - 2018-08-06 22:38:07 --> Language Class Initialized
INFO - 2018-08-06 22:38:07 --> Config Class Initialized
INFO - 2018-08-06 22:38:07 --> Loader Class Initialized
DEBUG - 2018-08-06 22:38:07 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-06 22:38:07 --> Helper loaded: url_helper
INFO - 2018-08-06 22:38:07 --> Helper loaded: form_helper
INFO - 2018-08-06 22:38:07 --> Helper loaded: date_helper
INFO - 2018-08-06 22:38:07 --> Helper loaded: util_helper
INFO - 2018-08-06 22:38:07 --> Helper loaded: text_helper
INFO - 2018-08-06 22:38:07 --> Helper loaded: string_helper
INFO - 2018-08-06 22:38:07 --> Database Driver Class Initialized
DEBUG - 2018-08-06 22:38:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-06 22:38:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-06 22:38:07 --> Email Class Initialized
INFO - 2018-08-06 22:38:07 --> Controller Class Initialized
DEBUG - 2018-08-06 22:38:07 --> Login MX_Controller Initialized
INFO - 2018-08-06 22:38:07 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-06 22:38:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-06 22:38:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-06 22:38:07 --> Email starts for colinUser fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-08-06 22:38:07 --> User session created for 4
INFO - 2018-08-06 22:38:08 --> Login status colinUser - success
INFO - 2018-08-06 22:38:08 --> Final output sent to browser
DEBUG - 2018-08-06 22:38:08 --> Total execution time: 0.3214
INFO - 2018-08-06 22:38:08 --> Config Class Initialized
INFO - 2018-08-06 22:38:08 --> Hooks Class Initialized
DEBUG - 2018-08-06 22:38:08 --> UTF-8 Support Enabled
INFO - 2018-08-06 22:38:08 --> Utf8 Class Initialized
INFO - 2018-08-06 22:38:08 --> URI Class Initialized
INFO - 2018-08-06 22:38:08 --> Router Class Initialized
INFO - 2018-08-06 22:38:08 --> Output Class Initialized
INFO - 2018-08-06 22:38:08 --> Security Class Initialized
DEBUG - 2018-08-06 22:38:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-06 22:38:08 --> Input Class Initialized
INFO - 2018-08-06 22:38:08 --> Language Class Initialized
INFO - 2018-08-06 22:38:08 --> Language Class Initialized
INFO - 2018-08-06 22:38:08 --> Config Class Initialized
INFO - 2018-08-06 22:38:08 --> Loader Class Initialized
DEBUG - 2018-08-06 22:38:08 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-06 22:38:08 --> Helper loaded: url_helper
INFO - 2018-08-06 22:38:08 --> Helper loaded: form_helper
INFO - 2018-08-06 22:38:08 --> Helper loaded: date_helper
INFO - 2018-08-06 22:38:08 --> Helper loaded: util_helper
INFO - 2018-08-06 22:38:08 --> Helper loaded: text_helper
INFO - 2018-08-06 22:38:08 --> Helper loaded: string_helper
INFO - 2018-08-06 22:38:08 --> Database Driver Class Initialized
DEBUG - 2018-08-06 22:38:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-06 22:38:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-06 22:38:08 --> Email Class Initialized
INFO - 2018-08-06 22:38:08 --> Controller Class Initialized
DEBUG - 2018-08-06 22:38:08 --> Home MX_Controller Initialized
DEBUG - 2018-08-06 22:38:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-06 22:38:08 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-06 22:38:08 --> Login MX_Controller Initialized
INFO - 2018-08-06 22:38:08 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-06 22:38:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-06 22:38:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-06 22:38:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-08-06 22:38:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-08-06 22:38:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-08-06 22:38:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-08-06 22:38:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-08-06 22:38:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-08-06 22:38:08 --> Final output sent to browser
DEBUG - 2018-08-06 22:38:08 --> Total execution time: 0.6193
INFO - 2018-08-06 22:38:09 --> Config Class Initialized
INFO - 2018-08-06 22:38:09 --> Hooks Class Initialized
INFO - 2018-08-06 22:38:09 --> Config Class Initialized
INFO - 2018-08-06 22:38:09 --> Hooks Class Initialized
DEBUG - 2018-08-06 22:38:09 --> UTF-8 Support Enabled
INFO - 2018-08-06 22:38:09 --> Utf8 Class Initialized
DEBUG - 2018-08-06 22:38:09 --> UTF-8 Support Enabled
INFO - 2018-08-06 22:38:09 --> Utf8 Class Initialized
INFO - 2018-08-06 22:38:09 --> URI Class Initialized
INFO - 2018-08-06 22:38:09 --> URI Class Initialized
INFO - 2018-08-06 22:38:09 --> Router Class Initialized
INFO - 2018-08-06 22:38:09 --> Output Class Initialized
INFO - 2018-08-06 22:38:09 --> Router Class Initialized
INFO - 2018-08-06 22:38:09 --> Security Class Initialized
INFO - 2018-08-06 22:38:09 --> Output Class Initialized
INFO - 2018-08-06 22:38:09 --> Security Class Initialized
DEBUG - 2018-08-06 22:38:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-06 22:38:09 --> Input Class Initialized
DEBUG - 2018-08-06 22:38:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-06 22:38:09 --> Input Class Initialized
INFO - 2018-08-06 22:38:09 --> Language Class Initialized
INFO - 2018-08-06 22:38:09 --> Language Class Initialized
ERROR - 2018-08-06 22:38:09 --> 404 Page Not Found: /index
ERROR - 2018-08-06 22:38:09 --> 404 Page Not Found: /index
INFO - 2018-08-06 22:38:09 --> Config Class Initialized
INFO - 2018-08-06 22:38:09 --> Hooks Class Initialized
DEBUG - 2018-08-06 22:38:09 --> UTF-8 Support Enabled
INFO - 2018-08-06 22:38:09 --> Utf8 Class Initialized
INFO - 2018-08-06 22:38:09 --> URI Class Initialized
INFO - 2018-08-06 22:38:09 --> Router Class Initialized
INFO - 2018-08-06 22:38:09 --> Output Class Initialized
INFO - 2018-08-06 22:38:09 --> Security Class Initialized
DEBUG - 2018-08-06 22:38:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-06 22:38:09 --> Input Class Initialized
INFO - 2018-08-06 22:38:10 --> Language Class Initialized
INFO - 2018-08-06 22:38:10 --> Language Class Initialized
INFO - 2018-08-06 22:38:10 --> Config Class Initialized
INFO - 2018-08-06 22:38:10 --> Loader Class Initialized
DEBUG - 2018-08-06 22:38:10 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-06 22:38:10 --> Helper loaded: url_helper
INFO - 2018-08-06 22:38:10 --> Helper loaded: form_helper
INFO - 2018-08-06 22:38:10 --> Helper loaded: date_helper
INFO - 2018-08-06 22:38:10 --> Helper loaded: util_helper
INFO - 2018-08-06 22:38:10 --> Helper loaded: text_helper
INFO - 2018-08-06 22:38:10 --> Helper loaded: string_helper
INFO - 2018-08-06 22:38:10 --> Database Driver Class Initialized
DEBUG - 2018-08-06 22:38:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-06 22:38:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-06 22:38:10 --> Email Class Initialized
INFO - 2018-08-06 22:38:10 --> Controller Class Initialized
DEBUG - 2018-08-06 22:38:10 --> Home MX_Controller Initialized
DEBUG - 2018-08-06 22:38:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-06 22:38:10 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-06 22:38:10 --> Login MX_Controller Initialized
INFO - 2018-08-06 22:38:10 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-06 22:38:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-06 22:38:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-06 22:38:10 --> Config Class Initialized
INFO - 2018-08-06 22:38:10 --> Hooks Class Initialized
DEBUG - 2018-08-06 22:38:10 --> UTF-8 Support Enabled
INFO - 2018-08-06 22:38:10 --> Utf8 Class Initialized
INFO - 2018-08-06 22:38:10 --> URI Class Initialized
INFO - 2018-08-06 22:38:10 --> Router Class Initialized
INFO - 2018-08-06 22:38:10 --> Output Class Initialized
INFO - 2018-08-06 22:38:10 --> Security Class Initialized
DEBUG - 2018-08-06 22:38:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-06 22:38:10 --> Input Class Initialized
INFO - 2018-08-06 22:38:10 --> Language Class Initialized
ERROR - 2018-08-06 22:38:10 --> 404 Page Not Found: /index
INFO - 2018-08-06 22:38:10 --> Config Class Initialized
INFO - 2018-08-06 22:38:10 --> Hooks Class Initialized
DEBUG - 2018-08-06 22:38:10 --> UTF-8 Support Enabled
INFO - 2018-08-06 22:38:10 --> Utf8 Class Initialized
INFO - 2018-08-06 22:38:10 --> URI Class Initialized
INFO - 2018-08-06 22:38:10 --> Router Class Initialized
INFO - 2018-08-06 22:38:10 --> Output Class Initialized
INFO - 2018-08-06 22:38:10 --> Security Class Initialized
DEBUG - 2018-08-06 22:38:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-06 22:38:10 --> Input Class Initialized
INFO - 2018-08-06 22:38:10 --> Language Class Initialized
ERROR - 2018-08-06 22:38:10 --> 404 Page Not Found: /index
INFO - 2018-08-06 22:38:10 --> Config Class Initialized
INFO - 2018-08-06 22:38:10 --> Hooks Class Initialized
DEBUG - 2018-08-06 22:38:10 --> UTF-8 Support Enabled
INFO - 2018-08-06 22:38:10 --> Utf8 Class Initialized
INFO - 2018-08-06 22:38:10 --> URI Class Initialized
INFO - 2018-08-06 22:38:11 --> Router Class Initialized
INFO - 2018-08-06 22:38:11 --> Output Class Initialized
INFO - 2018-08-06 22:38:11 --> Security Class Initialized
DEBUG - 2018-08-06 22:38:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-06 22:38:11 --> Input Class Initialized
INFO - 2018-08-06 22:38:11 --> Language Class Initialized
ERROR - 2018-08-06 22:38:11 --> 404 Page Not Found: /index
INFO - 2018-08-06 22:38:11 --> Config Class Initialized
INFO - 2018-08-06 22:38:11 --> Hooks Class Initialized
DEBUG - 2018-08-06 22:38:11 --> UTF-8 Support Enabled
INFO - 2018-08-06 22:38:11 --> Utf8 Class Initialized
INFO - 2018-08-06 22:38:11 --> URI Class Initialized
INFO - 2018-08-06 22:38:11 --> Router Class Initialized
INFO - 2018-08-06 22:38:11 --> Output Class Initialized
INFO - 2018-08-06 22:38:11 --> Security Class Initialized
DEBUG - 2018-08-06 22:38:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-06 22:38:11 --> Input Class Initialized
INFO - 2018-08-06 22:38:11 --> Language Class Initialized
ERROR - 2018-08-06 22:38:11 --> 404 Page Not Found: /index
INFO - 2018-08-06 22:38:11 --> Config Class Initialized
INFO - 2018-08-06 22:38:11 --> Hooks Class Initialized
DEBUG - 2018-08-06 22:38:11 --> UTF-8 Support Enabled
INFO - 2018-08-06 22:38:11 --> Utf8 Class Initialized
INFO - 2018-08-06 22:38:11 --> URI Class Initialized
INFO - 2018-08-06 22:38:11 --> Router Class Initialized
INFO - 2018-08-06 22:38:11 --> Output Class Initialized
INFO - 2018-08-06 22:38:11 --> Security Class Initialized
DEBUG - 2018-08-06 22:38:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-06 22:38:11 --> Input Class Initialized
INFO - 2018-08-06 22:38:11 --> Language Class Initialized
ERROR - 2018-08-06 22:38:11 --> 404 Page Not Found: /index
INFO - 2018-08-06 22:38:11 --> Config Class Initialized
INFO - 2018-08-06 22:38:11 --> Hooks Class Initialized
DEBUG - 2018-08-06 22:38:11 --> UTF-8 Support Enabled
INFO - 2018-08-06 22:38:11 --> Utf8 Class Initialized
INFO - 2018-08-06 22:38:11 --> URI Class Initialized
INFO - 2018-08-06 22:38:11 --> Router Class Initialized
INFO - 2018-08-06 22:38:11 --> Output Class Initialized
INFO - 2018-08-06 22:38:11 --> Security Class Initialized
DEBUG - 2018-08-06 22:38:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-06 22:38:11 --> Input Class Initialized
INFO - 2018-08-06 22:38:11 --> Language Class Initialized
ERROR - 2018-08-06 22:38:11 --> 404 Page Not Found: /index
INFO - 2018-08-06 22:38:11 --> Config Class Initialized
INFO - 2018-08-06 22:38:11 --> Hooks Class Initialized
DEBUG - 2018-08-06 22:38:11 --> UTF-8 Support Enabled
INFO - 2018-08-06 22:38:11 --> Utf8 Class Initialized
INFO - 2018-08-06 22:38:11 --> URI Class Initialized
INFO - 2018-08-06 22:38:11 --> Router Class Initialized
INFO - 2018-08-06 22:38:11 --> Output Class Initialized
INFO - 2018-08-06 22:38:11 --> Security Class Initialized
DEBUG - 2018-08-06 22:38:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-06 22:38:11 --> Input Class Initialized
INFO - 2018-08-06 22:38:11 --> Language Class Initialized
INFO - 2018-08-06 22:38:11 --> Language Class Initialized
INFO - 2018-08-06 22:38:11 --> Config Class Initialized
INFO - 2018-08-06 22:38:11 --> Loader Class Initialized
DEBUG - 2018-08-06 22:38:11 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-06 22:38:11 --> Helper loaded: url_helper
INFO - 2018-08-06 22:38:11 --> Helper loaded: form_helper
INFO - 2018-08-06 22:38:11 --> Helper loaded: date_helper
INFO - 2018-08-06 22:38:11 --> Helper loaded: util_helper
INFO - 2018-08-06 22:38:11 --> Helper loaded: text_helper
INFO - 2018-08-06 22:38:11 --> Helper loaded: string_helper
INFO - 2018-08-06 22:38:11 --> Database Driver Class Initialized
DEBUG - 2018-08-06 22:38:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-06 22:38:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-06 22:38:11 --> Email Class Initialized
INFO - 2018-08-06 22:38:11 --> Controller Class Initialized
DEBUG - 2018-08-06 22:38:11 --> Login MX_Controller Initialized
INFO - 2018-08-06 22:38:11 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-06 22:38:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-06 22:38:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-06 22:38:11 --> Email starts for colin-admin fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-08-06 22:38:11 --> User session created for 1
INFO - 2018-08-06 22:38:11 --> Login status colin-admin - success
INFO - 2018-08-06 22:38:11 --> Final output sent to browser
DEBUG - 2018-08-06 22:38:11 --> Total execution time: 0.3839
INFO - 2018-08-06 22:38:12 --> Config Class Initialized
INFO - 2018-08-06 22:38:12 --> Hooks Class Initialized
DEBUG - 2018-08-06 22:38:12 --> UTF-8 Support Enabled
INFO - 2018-08-06 22:38:12 --> Utf8 Class Initialized
INFO - 2018-08-06 22:38:12 --> URI Class Initialized
INFO - 2018-08-06 22:38:12 --> Router Class Initialized
INFO - 2018-08-06 22:38:12 --> Output Class Initialized
INFO - 2018-08-06 22:38:12 --> Security Class Initialized
DEBUG - 2018-08-06 22:38:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-06 22:38:12 --> Input Class Initialized
INFO - 2018-08-06 22:38:12 --> Language Class Initialized
INFO - 2018-08-06 22:38:12 --> Language Class Initialized
INFO - 2018-08-06 22:38:12 --> Config Class Initialized
INFO - 2018-08-06 22:38:12 --> Loader Class Initialized
DEBUG - 2018-08-06 22:38:12 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-06 22:38:12 --> Helper loaded: url_helper
INFO - 2018-08-06 22:38:12 --> Helper loaded: form_helper
INFO - 2018-08-06 22:38:12 --> Helper loaded: date_helper
INFO - 2018-08-06 22:38:12 --> Helper loaded: util_helper
INFO - 2018-08-06 22:38:12 --> Helper loaded: text_helper
INFO - 2018-08-06 22:38:12 --> Helper loaded: string_helper
INFO - 2018-08-06 22:38:12 --> Database Driver Class Initialized
INFO - 2018-08-06 22:38:12 --> Config Class Initialized
INFO - 2018-08-06 22:38:12 --> Hooks Class Initialized
DEBUG - 2018-08-06 22:38:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-06 22:38:12 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-08-06 22:38:12 --> UTF-8 Support Enabled
INFO - 2018-08-06 22:38:12 --> Utf8 Class Initialized
INFO - 2018-08-06 22:38:12 --> Email Class Initialized
INFO - 2018-08-06 22:38:12 --> Controller Class Initialized
INFO - 2018-08-06 22:38:12 --> URI Class Initialized
DEBUG - 2018-08-06 22:38:12 --> Admin MX_Controller Initialized
INFO - 2018-08-06 22:38:12 --> Router Class Initialized
INFO - 2018-08-06 22:38:12 --> Language file loaded: language/english/data_lang.php
INFO - 2018-08-06 22:38:12 --> Output Class Initialized
INFO - 2018-08-06 22:38:12 --> Security Class Initialized
DEBUG - 2018-08-06 22:38:12 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-06 22:38:12 --> Login MX_Controller Initialized
DEBUG - 2018-08-06 22:38:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-06 22:38:12 --> Input Class Initialized
DEBUG - 2018-08-06 22:38:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-08-06 22:38:12 --> Language Class Initialized
DEBUG - 2018-08-06 22:38:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
ERROR - 2018-08-06 22:38:12 --> 404 Page Not Found: /index
INFO - 2018-08-06 22:38:12 --> Config Class Initialized
INFO - 2018-08-06 22:38:12 --> Hooks Class Initialized
DEBUG - 2018-08-06 22:38:12 --> UTF-8 Support Enabled
INFO - 2018-08-06 22:38:12 --> Utf8 Class Initialized
INFO - 2018-08-06 22:38:12 --> URI Class Initialized
INFO - 2018-08-06 22:38:12 --> Router Class Initialized
INFO - 2018-08-06 22:38:12 --> Output Class Initialized
INFO - 2018-08-06 22:38:12 --> Security Class Initialized
DEBUG - 2018-08-06 22:38:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-08-06 22:38:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-06 22:38:12 --> Input Class Initialized
INFO - 2018-08-06 22:38:12 --> Language Class Initialized
ERROR - 2018-08-06 22:38:12 --> 404 Page Not Found: /index
DEBUG - 2018-08-06 22:38:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
INFO - 2018-08-06 22:38:12 --> Config Class Initialized
INFO - 2018-08-06 22:38:12 --> Hooks Class Initialized
DEBUG - 2018-08-06 22:38:12 --> UTF-8 Support Enabled
DEBUG - 2018-08-06 22:38:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
INFO - 2018-08-06 22:38:12 --> Utf8 Class Initialized
INFO - 2018-08-06 22:38:12 --> URI Class Initialized
INFO - 2018-08-06 22:38:12 --> Router Class Initialized
DEBUG - 2018-08-06 22:38:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
INFO - 2018-08-06 22:38:12 --> Output Class Initialized
INFO - 2018-08-06 22:38:12 --> Security Class Initialized
DEBUG - 2018-08-06 22:38:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-08-06 22:38:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
INFO - 2018-08-06 22:38:12 --> Input Class Initialized
DEBUG - 2018-08-06 22:38:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/dashboard.php
INFO - 2018-08-06 22:38:12 --> Language Class Initialized
ERROR - 2018-08-06 22:38:12 --> 404 Page Not Found: /index
INFO - 2018-08-06 22:38:12 --> Final output sent to browser
DEBUG - 2018-08-06 22:38:12 --> Total execution time: 0.5632
INFO - 2018-08-06 22:38:13 --> Config Class Initialized
INFO - 2018-08-06 22:38:13 --> Hooks Class Initialized
DEBUG - 2018-08-06 22:38:13 --> UTF-8 Support Enabled
INFO - 2018-08-06 22:38:13 --> Utf8 Class Initialized
INFO - 2018-08-06 22:38:13 --> URI Class Initialized
INFO - 2018-08-06 22:38:13 --> Router Class Initialized
INFO - 2018-08-06 22:38:13 --> Output Class Initialized
INFO - 2018-08-06 22:38:13 --> Security Class Initialized
DEBUG - 2018-08-06 22:38:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-06 22:38:14 --> Input Class Initialized
INFO - 2018-08-06 22:38:14 --> Language Class Initialized
INFO - 2018-08-06 22:38:14 --> Language Class Initialized
INFO - 2018-08-06 22:38:14 --> Config Class Initialized
INFO - 2018-08-06 22:38:14 --> Loader Class Initialized
DEBUG - 2018-08-06 22:38:14 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-06 22:38:14 --> Helper loaded: url_helper
INFO - 2018-08-06 22:38:14 --> Helper loaded: form_helper
INFO - 2018-08-06 22:38:14 --> Helper loaded: date_helper
INFO - 2018-08-06 22:38:14 --> Helper loaded: util_helper
INFO - 2018-08-06 22:38:14 --> Helper loaded: text_helper
INFO - 2018-08-06 22:38:14 --> Helper loaded: string_helper
INFO - 2018-08-06 22:38:14 --> Database Driver Class Initialized
DEBUG - 2018-08-06 22:38:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-06 22:38:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-06 22:38:14 --> Email Class Initialized
INFO - 2018-08-06 22:38:14 --> Controller Class Initialized
DEBUG - 2018-08-06 22:38:14 --> Home MX_Controller Initialized
DEBUG - 2018-08-06 22:38:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-06 22:38:14 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-06 22:38:14 --> Login MX_Controller Initialized
INFO - 2018-08-06 22:38:14 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-06 22:38:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-06 22:38:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-06 22:38:26 --> Config Class Initialized
INFO - 2018-08-06 22:38:26 --> Hooks Class Initialized
DEBUG - 2018-08-06 22:38:26 --> UTF-8 Support Enabled
INFO - 2018-08-06 22:38:26 --> Utf8 Class Initialized
INFO - 2018-08-06 22:38:26 --> URI Class Initialized
INFO - 2018-08-06 22:38:26 --> Router Class Initialized
INFO - 2018-08-06 22:38:26 --> Output Class Initialized
INFO - 2018-08-06 22:38:26 --> Security Class Initialized
DEBUG - 2018-08-06 22:38:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-06 22:38:26 --> Input Class Initialized
INFO - 2018-08-06 22:38:26 --> Language Class Initialized
INFO - 2018-08-06 22:38:26 --> Language Class Initialized
INFO - 2018-08-06 22:38:26 --> Config Class Initialized
INFO - 2018-08-06 22:38:26 --> Loader Class Initialized
DEBUG - 2018-08-06 22:38:26 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-06 22:38:26 --> Helper loaded: url_helper
INFO - 2018-08-06 22:38:26 --> Helper loaded: form_helper
INFO - 2018-08-06 22:38:26 --> Helper loaded: date_helper
INFO - 2018-08-06 22:38:26 --> Helper loaded: util_helper
INFO - 2018-08-06 22:38:26 --> Helper loaded: text_helper
INFO - 2018-08-06 22:38:26 --> Helper loaded: string_helper
INFO - 2018-08-06 22:38:26 --> Database Driver Class Initialized
DEBUG - 2018-08-06 22:38:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-06 22:38:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-06 22:38:26 --> Email Class Initialized
INFO - 2018-08-06 22:38:26 --> Controller Class Initialized
DEBUG - 2018-08-06 22:38:26 --> Home MX_Controller Initialized
DEBUG - 2018-08-06 22:38:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-06 22:38:26 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-06 22:38:26 --> Login MX_Controller Initialized
INFO - 2018-08-06 22:38:26 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-06 22:38:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-06 22:38:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-06 22:38:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-08-06 22:38:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-08-06 22:38:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-08-06 22:38:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-08-06 22:38:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-08-06 22:38:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/search_page.php
INFO - 2018-08-06 22:38:26 --> Final output sent to browser
DEBUG - 2018-08-06 22:38:26 --> Total execution time: 0.3833
INFO - 2018-08-06 22:38:27 --> Config Class Initialized
INFO - 2018-08-06 22:38:27 --> Hooks Class Initialized
DEBUG - 2018-08-06 22:38:27 --> UTF-8 Support Enabled
INFO - 2018-08-06 22:38:27 --> Config Class Initialized
INFO - 2018-08-06 22:38:27 --> Hooks Class Initialized
INFO - 2018-08-06 22:38:27 --> Utf8 Class Initialized
INFO - 2018-08-06 22:38:27 --> URI Class Initialized
DEBUG - 2018-08-06 22:38:27 --> UTF-8 Support Enabled
INFO - 2018-08-06 22:38:27 --> Utf8 Class Initialized
INFO - 2018-08-06 22:38:27 --> Router Class Initialized
INFO - 2018-08-06 22:38:27 --> URI Class Initialized
INFO - 2018-08-06 22:38:27 --> Router Class Initialized
INFO - 2018-08-06 22:38:27 --> Output Class Initialized
INFO - 2018-08-06 22:38:27 --> Security Class Initialized
DEBUG - 2018-08-06 22:38:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-06 22:38:27 --> Input Class Initialized
INFO - 2018-08-06 22:38:27 --> Language Class Initialized
INFO - 2018-08-06 22:38:27 --> Language Class Initialized
INFO - 2018-08-06 22:38:27 --> Config Class Initialized
INFO - 2018-08-06 22:38:27 --> Output Class Initialized
INFO - 2018-08-06 22:38:27 --> Loader Class Initialized
DEBUG - 2018-08-06 22:38:27 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-06 22:38:27 --> Security Class Initialized
DEBUG - 2018-08-06 22:38:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-06 22:38:27 --> Helper loaded: url_helper
INFO - 2018-08-06 22:38:27 --> Input Class Initialized
INFO - 2018-08-06 22:38:27 --> Language Class Initialized
ERROR - 2018-08-06 22:38:27 --> 404 Page Not Found: /index
INFO - 2018-08-06 22:38:27 --> Helper loaded: form_helper
INFO - 2018-08-06 22:38:27 --> Config Class Initialized
INFO - 2018-08-06 22:38:27 --> Helper loaded: date_helper
INFO - 2018-08-06 22:38:27 --> Hooks Class Initialized
INFO - 2018-08-06 22:38:27 --> Helper loaded: util_helper
DEBUG - 2018-08-06 22:38:27 --> UTF-8 Support Enabled
INFO - 2018-08-06 22:38:27 --> Utf8 Class Initialized
INFO - 2018-08-06 22:38:27 --> Helper loaded: text_helper
INFO - 2018-08-06 22:38:27 --> Helper loaded: string_helper
INFO - 2018-08-06 22:38:27 --> URI Class Initialized
INFO - 2018-08-06 22:38:27 --> Router Class Initialized
INFO - 2018-08-06 22:38:27 --> Database Driver Class Initialized
INFO - 2018-08-06 22:38:27 --> Output Class Initialized
INFO - 2018-08-06 22:38:27 --> Security Class Initialized
DEBUG - 2018-08-06 22:38:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-06 22:38:27 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-08-06 22:38:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-06 22:38:27 --> Input Class Initialized
INFO - 2018-08-06 22:38:27 --> Email Class Initialized
INFO - 2018-08-06 22:38:27 --> Controller Class Initialized
INFO - 2018-08-06 22:38:27 --> Language Class Initialized
DEBUG - 2018-08-06 22:38:27 --> Home MX_Controller Initialized
ERROR - 2018-08-06 22:38:27 --> 404 Page Not Found: /index
DEBUG - 2018-08-06 22:38:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-08-06 22:38:27 --> Config Class Initialized
INFO - 2018-08-06 22:38:27 --> Hooks Class Initialized
DEBUG - 2018-08-06 22:38:27 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-06 22:38:27 --> Login MX_Controller Initialized
DEBUG - 2018-08-06 22:38:27 --> UTF-8 Support Enabled
INFO - 2018-08-06 22:38:27 --> Utf8 Class Initialized
INFO - 2018-08-06 22:38:27 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-06 22:38:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-08-06 22:38:27 --> URI Class Initialized
DEBUG - 2018-08-06 22:38:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-06 22:38:27 --> Router Class Initialized
INFO - 2018-08-06 22:38:27 --> Output Class Initialized
INFO - 2018-08-06 22:38:27 --> Security Class Initialized
DEBUG - 2018-08-06 22:38:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-06 22:38:27 --> Input Class Initialized
INFO - 2018-08-06 22:38:27 --> Language Class Initialized
ERROR - 2018-08-06 22:38:27 --> 404 Page Not Found: /index
INFO - 2018-08-06 22:38:30 --> Config Class Initialized
INFO - 2018-08-06 22:38:30 --> Hooks Class Initialized
DEBUG - 2018-08-06 22:38:30 --> UTF-8 Support Enabled
INFO - 2018-08-06 22:38:30 --> Utf8 Class Initialized
INFO - 2018-08-06 22:38:30 --> URI Class Initialized
DEBUG - 2018-08-06 22:38:30 --> No URI present. Default controller set.
INFO - 2018-08-06 22:38:30 --> Router Class Initialized
INFO - 2018-08-06 22:38:30 --> Output Class Initialized
INFO - 2018-08-06 22:38:30 --> Security Class Initialized
DEBUG - 2018-08-06 22:38:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-06 22:38:30 --> Input Class Initialized
INFO - 2018-08-06 22:38:30 --> Language Class Initialized
INFO - 2018-08-06 22:38:30 --> Language Class Initialized
INFO - 2018-08-06 22:38:30 --> Config Class Initialized
INFO - 2018-08-06 22:38:30 --> Loader Class Initialized
DEBUG - 2018-08-06 22:38:30 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-06 22:38:30 --> Helper loaded: url_helper
INFO - 2018-08-06 22:38:30 --> Helper loaded: form_helper
INFO - 2018-08-06 22:38:30 --> Helper loaded: date_helper
INFO - 2018-08-06 22:38:30 --> Helper loaded: util_helper
INFO - 2018-08-06 22:38:30 --> Helper loaded: text_helper
INFO - 2018-08-06 22:38:30 --> Helper loaded: string_helper
INFO - 2018-08-06 22:38:30 --> Database Driver Class Initialized
DEBUG - 2018-08-06 22:38:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-06 22:38:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-06 22:38:30 --> Email Class Initialized
INFO - 2018-08-06 22:38:30 --> Controller Class Initialized
DEBUG - 2018-08-06 22:38:30 --> Home MX_Controller Initialized
DEBUG - 2018-08-06 22:38:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-06 22:38:30 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-06 22:38:30 --> Login MX_Controller Initialized
INFO - 2018-08-06 22:38:30 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-06 22:38:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-06 22:38:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-06 22:38:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-08-06 22:38:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-08-06 22:38:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-08-06 22:38:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-08-06 22:38:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-08-06 22:38:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-08-06 22:38:30 --> Final output sent to browser
DEBUG - 2018-08-06 22:38:30 --> Total execution time: 0.4351
INFO - 2018-08-06 22:38:31 --> Config Class Initialized
INFO - 2018-08-06 22:38:31 --> Hooks Class Initialized
DEBUG - 2018-08-06 22:38:31 --> UTF-8 Support Enabled
INFO - 2018-08-06 22:38:31 --> Utf8 Class Initialized
INFO - 2018-08-06 22:38:31 --> URI Class Initialized
INFO - 2018-08-06 22:38:31 --> Router Class Initialized
INFO - 2018-08-06 22:38:31 --> Config Class Initialized
INFO - 2018-08-06 22:38:31 --> Hooks Class Initialized
INFO - 2018-08-06 22:38:31 --> Output Class Initialized
INFO - 2018-08-06 22:38:31 --> Security Class Initialized
DEBUG - 2018-08-06 22:38:31 --> UTF-8 Support Enabled
INFO - 2018-08-06 22:38:31 --> Utf8 Class Initialized
DEBUG - 2018-08-06 22:38:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-06 22:38:31 --> Input Class Initialized
INFO - 2018-08-06 22:38:31 --> URI Class Initialized
INFO - 2018-08-06 22:38:31 --> Language Class Initialized
INFO - 2018-08-06 22:38:31 --> Router Class Initialized
ERROR - 2018-08-06 22:38:31 --> 404 Page Not Found: /index
INFO - 2018-08-06 22:38:31 --> Output Class Initialized
INFO - 2018-08-06 22:38:31 --> Security Class Initialized
INFO - 2018-08-06 22:38:31 --> Config Class Initialized
INFO - 2018-08-06 22:38:31 --> Hooks Class Initialized
DEBUG - 2018-08-06 22:38:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-08-06 22:38:31 --> UTF-8 Support Enabled
INFO - 2018-08-06 22:38:31 --> Input Class Initialized
INFO - 2018-08-06 22:38:31 --> Utf8 Class Initialized
INFO - 2018-08-06 22:38:31 --> URI Class Initialized
INFO - 2018-08-06 22:38:31 --> Language Class Initialized
INFO - 2018-08-06 22:38:31 --> Router Class Initialized
INFO - 2018-08-06 22:38:31 --> Language Class Initialized
INFO - 2018-08-06 22:38:31 --> Config Class Initialized
INFO - 2018-08-06 22:38:31 --> Output Class Initialized
INFO - 2018-08-06 22:38:31 --> Security Class Initialized
INFO - 2018-08-06 22:38:31 --> Loader Class Initialized
DEBUG - 2018-08-06 22:38:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-06 22:38:31 --> Input Class Initialized
INFO - 2018-08-06 22:38:31 --> Language Class Initialized
DEBUG - 2018-08-06 22:38:31 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
ERROR - 2018-08-06 22:38:31 --> 404 Page Not Found: /index
INFO - 2018-08-06 22:38:31 --> Helper loaded: url_helper
INFO - 2018-08-06 22:38:31 --> Config Class Initialized
INFO - 2018-08-06 22:38:31 --> Hooks Class Initialized
INFO - 2018-08-06 22:38:31 --> Helper loaded: form_helper
DEBUG - 2018-08-06 22:38:31 --> UTF-8 Support Enabled
INFO - 2018-08-06 22:38:31 --> Utf8 Class Initialized
INFO - 2018-08-06 22:38:31 --> URI Class Initialized
INFO - 2018-08-06 22:38:31 --> Helper loaded: date_helper
INFO - 2018-08-06 22:38:31 --> Helper loaded: util_helper
INFO - 2018-08-06 22:38:31 --> Router Class Initialized
INFO - 2018-08-06 22:38:31 --> Helper loaded: text_helper
INFO - 2018-08-06 22:38:31 --> Output Class Initialized
INFO - 2018-08-06 22:38:31 --> Security Class Initialized
INFO - 2018-08-06 22:38:31 --> Helper loaded: string_helper
DEBUG - 2018-08-06 22:38:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-06 22:38:31 --> Database Driver Class Initialized
INFO - 2018-08-06 22:38:31 --> Input Class Initialized
DEBUG - 2018-08-06 22:38:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-06 22:38:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-06 22:38:31 --> Language Class Initialized
ERROR - 2018-08-06 22:38:31 --> 404 Page Not Found: /index
INFO - 2018-08-06 22:38:31 --> Email Class Initialized
INFO - 2018-08-06 22:38:31 --> Controller Class Initialized
DEBUG - 2018-08-06 22:38:31 --> Home MX_Controller Initialized
DEBUG - 2018-08-06 22:38:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-06 22:38:31 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-06 22:38:31 --> Login MX_Controller Initialized
INFO - 2018-08-06 22:38:31 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-06 22:38:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-06 22:38:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-06 22:38:33 --> Config Class Initialized
INFO - 2018-08-06 22:38:33 --> Hooks Class Initialized
DEBUG - 2018-08-06 22:38:33 --> UTF-8 Support Enabled
INFO - 2018-08-06 22:38:33 --> Utf8 Class Initialized
INFO - 2018-08-06 22:38:33 --> URI Class Initialized
INFO - 2018-08-06 22:38:33 --> Router Class Initialized
INFO - 2018-08-06 22:38:33 --> Output Class Initialized
INFO - 2018-08-06 22:38:33 --> Security Class Initialized
DEBUG - 2018-08-06 22:38:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-06 22:38:33 --> Input Class Initialized
INFO - 2018-08-06 22:38:33 --> Language Class Initialized
INFO - 2018-08-06 22:38:33 --> Language Class Initialized
INFO - 2018-08-06 22:38:33 --> Config Class Initialized
INFO - 2018-08-06 22:38:33 --> Loader Class Initialized
DEBUG - 2018-08-06 22:38:33 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-06 22:38:33 --> Helper loaded: url_helper
INFO - 2018-08-06 22:38:33 --> Helper loaded: form_helper
INFO - 2018-08-06 22:38:33 --> Helper loaded: date_helper
INFO - 2018-08-06 22:38:33 --> Helper loaded: util_helper
INFO - 2018-08-06 22:38:33 --> Helper loaded: text_helper
INFO - 2018-08-06 22:38:33 --> Helper loaded: string_helper
INFO - 2018-08-06 22:38:33 --> Database Driver Class Initialized
DEBUG - 2018-08-06 22:38:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-06 22:38:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-06 22:38:33 --> Email Class Initialized
INFO - 2018-08-06 22:38:33 --> Controller Class Initialized
DEBUG - 2018-08-06 22:38:33 --> Home MX_Controller Initialized
DEBUG - 2018-08-06 22:38:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-06 22:38:33 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-06 22:38:33 --> Login MX_Controller Initialized
INFO - 2018-08-06 22:38:33 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-06 22:38:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-06 22:38:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-06 22:38:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-08-06 22:38:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-08-06 22:38:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-08-06 22:38:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-08-06 22:38:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-08-06 22:38:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-08-06 22:38:33 --> Final output sent to browser
DEBUG - 2018-08-06 22:38:33 --> Total execution time: 0.3906
INFO - 2018-08-06 22:38:33 --> Config Class Initialized
INFO - 2018-08-06 22:38:33 --> Config Class Initialized
INFO - 2018-08-06 22:38:33 --> Hooks Class Initialized
INFO - 2018-08-06 22:38:33 --> Hooks Class Initialized
DEBUG - 2018-08-06 22:38:33 --> UTF-8 Support Enabled
DEBUG - 2018-08-06 22:38:33 --> UTF-8 Support Enabled
INFO - 2018-08-06 22:38:33 --> Utf8 Class Initialized
INFO - 2018-08-06 22:38:33 --> Config Class Initialized
INFO - 2018-08-06 22:38:33 --> Utf8 Class Initialized
INFO - 2018-08-06 22:38:33 --> Hooks Class Initialized
INFO - 2018-08-06 22:38:33 --> URI Class Initialized
INFO - 2018-08-06 22:38:33 --> URI Class Initialized
DEBUG - 2018-08-06 22:38:33 --> UTF-8 Support Enabled
INFO - 2018-08-06 22:38:33 --> Router Class Initialized
INFO - 2018-08-06 22:38:33 --> Utf8 Class Initialized
INFO - 2018-08-06 22:38:33 --> Router Class Initialized
INFO - 2018-08-06 22:38:33 --> Output Class Initialized
INFO - 2018-08-06 22:38:33 --> URI Class Initialized
INFO - 2018-08-06 22:38:34 --> Output Class Initialized
INFO - 2018-08-06 22:38:34 --> Security Class Initialized
INFO - 2018-08-06 22:38:34 --> Security Class Initialized
INFO - 2018-08-06 22:38:34 --> Router Class Initialized
DEBUG - 2018-08-06 22:38:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-08-06 22:38:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-06 22:38:34 --> Input Class Initialized
INFO - 2018-08-06 22:38:34 --> Language Class Initialized
ERROR - 2018-08-06 22:38:34 --> 404 Page Not Found: /index
INFO - 2018-08-06 22:38:34 --> Input Class Initialized
INFO - 2018-08-06 22:38:34 --> Output Class Initialized
INFO - 2018-08-06 22:38:34 --> Language Class Initialized
INFO - 2018-08-06 22:38:34 --> Security Class Initialized
ERROR - 2018-08-06 22:38:34 --> 404 Page Not Found: /index
DEBUG - 2018-08-06 22:38:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-06 22:38:34 --> Config Class Initialized
INFO - 2018-08-06 22:38:34 --> Hooks Class Initialized
INFO - 2018-08-06 22:38:34 --> Input Class Initialized
INFO - 2018-08-06 22:38:34 --> Language Class Initialized
DEBUG - 2018-08-06 22:38:34 --> UTF-8 Support Enabled
INFO - 2018-08-06 22:38:34 --> Utf8 Class Initialized
INFO - 2018-08-06 22:38:34 --> Language Class Initialized
INFO - 2018-08-06 22:38:34 --> Config Class Initialized
INFO - 2018-08-06 22:38:34 --> URI Class Initialized
INFO - 2018-08-06 22:38:34 --> Loader Class Initialized
INFO - 2018-08-06 22:38:34 --> Router Class Initialized
DEBUG - 2018-08-06 22:38:34 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-06 22:38:34 --> Helper loaded: url_helper
INFO - 2018-08-06 22:38:34 --> Helper loaded: form_helper
INFO - 2018-08-06 22:38:34 --> Helper loaded: date_helper
INFO - 2018-08-06 22:38:34 --> Helper loaded: util_helper
INFO - 2018-08-06 22:38:34 --> Helper loaded: text_helper
INFO - 2018-08-06 22:38:34 --> Helper loaded: string_helper
INFO - 2018-08-06 22:38:34 --> Database Driver Class Initialized
INFO - 2018-08-06 22:38:34 --> Output Class Initialized
INFO - 2018-08-06 22:38:34 --> Security Class Initialized
DEBUG - 2018-08-06 22:38:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-06 22:38:34 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-08-06 22:38:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-06 22:38:34 --> Email Class Initialized
INFO - 2018-08-06 22:38:34 --> Controller Class Initialized
DEBUG - 2018-08-06 22:38:34 --> Home MX_Controller Initialized
INFO - 2018-08-06 22:38:34 --> Input Class Initialized
DEBUG - 2018-08-06 22:38:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-08-06 22:38:34 --> Language Class Initialized
DEBUG - 2018-08-06 22:38:34 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-06 22:38:34 --> Login MX_Controller Initialized
ERROR - 2018-08-06 22:38:34 --> 404 Page Not Found: /index
INFO - 2018-08-06 22:38:34 --> Language file loaded: language/english/data_lang.php
INFO - 2018-08-06 22:38:34 --> Config Class Initialized
INFO - 2018-08-06 22:38:34 --> Hooks Class Initialized
DEBUG - 2018-08-06 22:38:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-06 22:38:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-06 22:38:34 --> UTF-8 Support Enabled
INFO - 2018-08-06 22:38:34 --> Utf8 Class Initialized
INFO - 2018-08-06 22:38:34 --> URI Class Initialized
INFO - 2018-08-06 22:38:34 --> Router Class Initialized
INFO - 2018-08-06 22:38:34 --> Output Class Initialized
INFO - 2018-08-06 22:38:34 --> Security Class Initialized
DEBUG - 2018-08-06 22:38:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-06 22:38:34 --> Input Class Initialized
INFO - 2018-08-06 22:38:34 --> Language Class Initialized
ERROR - 2018-08-06 22:38:34 --> 404 Page Not Found: /index
INFO - 2018-08-06 22:38:47 --> Config Class Initialized
INFO - 2018-08-06 22:38:47 --> Hooks Class Initialized
DEBUG - 2018-08-06 22:38:47 --> UTF-8 Support Enabled
INFO - 2018-08-06 22:38:47 --> Utf8 Class Initialized
INFO - 2018-08-06 22:38:47 --> URI Class Initialized
INFO - 2018-08-06 22:38:47 --> Router Class Initialized
INFO - 2018-08-06 22:38:47 --> Output Class Initialized
INFO - 2018-08-06 22:38:47 --> Security Class Initialized
DEBUG - 2018-08-06 22:38:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-06 22:38:47 --> Input Class Initialized
INFO - 2018-08-06 22:38:47 --> Language Class Initialized
INFO - 2018-08-06 22:38:47 --> Language Class Initialized
INFO - 2018-08-06 22:38:47 --> Config Class Initialized
INFO - 2018-08-06 22:38:47 --> Loader Class Initialized
DEBUG - 2018-08-06 22:38:47 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-06 22:38:47 --> Helper loaded: url_helper
INFO - 2018-08-06 22:38:47 --> Helper loaded: form_helper
INFO - 2018-08-06 22:38:47 --> Helper loaded: date_helper
INFO - 2018-08-06 22:38:47 --> Helper loaded: util_helper
INFO - 2018-08-06 22:38:47 --> Helper loaded: text_helper
INFO - 2018-08-06 22:38:47 --> Helper loaded: string_helper
INFO - 2018-08-06 22:38:47 --> Database Driver Class Initialized
DEBUG - 2018-08-06 22:38:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-06 22:38:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-06 22:38:47 --> Email Class Initialized
INFO - 2018-08-06 22:38:47 --> Controller Class Initialized
DEBUG - 2018-08-06 22:38:47 --> Home MX_Controller Initialized
DEBUG - 2018-08-06 22:38:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-06 22:38:47 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-06 22:38:47 --> Login MX_Controller Initialized
INFO - 2018-08-06 22:38:47 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-06 22:38:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-06 22:38:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-06 22:38:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-08-06 22:38:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-08-06 22:38:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-08-06 22:38:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-08-06 22:38:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-08-06 22:38:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-08-06 22:38:47 --> Final output sent to browser
DEBUG - 2018-08-06 22:38:47 --> Total execution time: 0.3716
INFO - 2018-08-06 22:38:48 --> Config Class Initialized
INFO - 2018-08-06 22:38:48 --> Config Class Initialized
INFO - 2018-08-06 22:38:48 --> Hooks Class Initialized
INFO - 2018-08-06 22:38:48 --> Hooks Class Initialized
DEBUG - 2018-08-06 22:38:48 --> UTF-8 Support Enabled
DEBUG - 2018-08-06 22:38:48 --> UTF-8 Support Enabled
INFO - 2018-08-06 22:38:48 --> Utf8 Class Initialized
INFO - 2018-08-06 22:38:48 --> Utf8 Class Initialized
INFO - 2018-08-06 22:38:48 --> Config Class Initialized
INFO - 2018-08-06 22:38:48 --> Hooks Class Initialized
INFO - 2018-08-06 22:38:48 --> URI Class Initialized
INFO - 2018-08-06 22:38:48 --> URI Class Initialized
DEBUG - 2018-08-06 22:38:48 --> UTF-8 Support Enabled
INFO - 2018-08-06 22:38:48 --> Router Class Initialized
INFO - 2018-08-06 22:38:48 --> Router Class Initialized
INFO - 2018-08-06 22:38:48 --> Utf8 Class Initialized
INFO - 2018-08-06 22:38:48 --> Output Class Initialized
INFO - 2018-08-06 22:38:48 --> URI Class Initialized
INFO - 2018-08-06 22:38:48 --> Router Class Initialized
INFO - 2018-08-06 22:38:48 --> Output Class Initialized
INFO - 2018-08-06 22:38:48 --> Security Class Initialized
DEBUG - 2018-08-06 22:38:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-06 22:38:48 --> Input Class Initialized
INFO - 2018-08-06 22:38:48 --> Language Class Initialized
INFO - 2018-08-06 22:38:48 --> Security Class Initialized
INFO - 2018-08-06 22:38:48 --> Output Class Initialized
INFO - 2018-08-06 22:38:48 --> Language Class Initialized
INFO - 2018-08-06 22:38:48 --> Security Class Initialized
DEBUG - 2018-08-06 22:38:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-06 22:38:48 --> Config Class Initialized
DEBUG - 2018-08-06 22:38:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-06 22:38:48 --> Loader Class Initialized
INFO - 2018-08-06 22:38:48 --> Input Class Initialized
INFO - 2018-08-06 22:38:48 --> Input Class Initialized
DEBUG - 2018-08-06 22:38:48 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-06 22:38:48 --> Language Class Initialized
INFO - 2018-08-06 22:38:48 --> Helper loaded: url_helper
INFO - 2018-08-06 22:38:48 --> Helper loaded: form_helper
ERROR - 2018-08-06 22:38:48 --> 404 Page Not Found: /index
INFO - 2018-08-06 22:38:48 --> Language Class Initialized
INFO - 2018-08-06 22:38:48 --> Helper loaded: date_helper
INFO - 2018-08-06 22:38:48 --> Helper loaded: util_helper
ERROR - 2018-08-06 22:38:48 --> 404 Page Not Found: /index
INFO - 2018-08-06 22:38:48 --> Helper loaded: text_helper
INFO - 2018-08-06 22:38:48 --> Config Class Initialized
INFO - 2018-08-06 22:38:48 --> Hooks Class Initialized
INFO - 2018-08-06 22:38:48 --> Helper loaded: string_helper
DEBUG - 2018-08-06 22:38:48 --> UTF-8 Support Enabled
INFO - 2018-08-06 22:38:48 --> Database Driver Class Initialized
INFO - 2018-08-06 22:38:48 --> Utf8 Class Initialized
INFO - 2018-08-06 22:38:48 --> URI Class Initialized
DEBUG - 2018-08-06 22:38:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-06 22:38:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-06 22:38:48 --> Router Class Initialized
INFO - 2018-08-06 22:38:48 --> Output Class Initialized
INFO - 2018-08-06 22:38:48 --> Email Class Initialized
INFO - 2018-08-06 22:38:48 --> Controller Class Initialized
INFO - 2018-08-06 22:38:48 --> Security Class Initialized
DEBUG - 2018-08-06 22:38:48 --> Home MX_Controller Initialized
DEBUG - 2018-08-06 22:38:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-06 22:38:48 --> Input Class Initialized
DEBUG - 2018-08-06 22:38:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-08-06 22:38:48 --> Language Class Initialized
DEBUG - 2018-08-06 22:38:48 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-06 22:38:48 --> Login MX_Controller Initialized
ERROR - 2018-08-06 22:38:48 --> 404 Page Not Found: /index
INFO - 2018-08-06 22:38:48 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-06 22:38:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-06 22:38:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-06 22:38:48 --> Config Class Initialized
INFO - 2018-08-06 22:38:48 --> Hooks Class Initialized
DEBUG - 2018-08-06 22:38:48 --> UTF-8 Support Enabled
INFO - 2018-08-06 22:38:48 --> Utf8 Class Initialized
INFO - 2018-08-06 22:38:48 --> URI Class Initialized
INFO - 2018-08-06 22:38:48 --> Router Class Initialized
INFO - 2018-08-06 22:38:48 --> Output Class Initialized
INFO - 2018-08-06 22:38:48 --> Security Class Initialized
DEBUG - 2018-08-06 22:38:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-06 22:38:48 --> Input Class Initialized
INFO - 2018-08-06 22:38:48 --> Language Class Initialized
ERROR - 2018-08-06 22:38:48 --> 404 Page Not Found: /index
INFO - 2018-08-06 22:39:00 --> Config Class Initialized
INFO - 2018-08-06 22:39:00 --> Hooks Class Initialized
DEBUG - 2018-08-06 22:39:00 --> UTF-8 Support Enabled
INFO - 2018-08-06 22:39:00 --> Utf8 Class Initialized
INFO - 2018-08-06 22:39:00 --> URI Class Initialized
INFO - 2018-08-06 22:39:00 --> Router Class Initialized
INFO - 2018-08-06 22:39:00 --> Output Class Initialized
INFO - 2018-08-06 22:39:00 --> Security Class Initialized
DEBUG - 2018-08-06 22:39:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-06 22:39:00 --> Input Class Initialized
INFO - 2018-08-06 22:39:00 --> Language Class Initialized
INFO - 2018-08-06 22:39:01 --> Language Class Initialized
INFO - 2018-08-06 22:39:01 --> Config Class Initialized
INFO - 2018-08-06 22:39:01 --> Loader Class Initialized
DEBUG - 2018-08-06 22:39:01 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-06 22:39:01 --> Helper loaded: url_helper
INFO - 2018-08-06 22:39:01 --> Helper loaded: form_helper
INFO - 2018-08-06 22:39:01 --> Helper loaded: date_helper
INFO - 2018-08-06 22:39:01 --> Helper loaded: util_helper
INFO - 2018-08-06 22:39:01 --> Helper loaded: text_helper
INFO - 2018-08-06 22:39:01 --> Helper loaded: string_helper
INFO - 2018-08-06 22:39:01 --> Database Driver Class Initialized
DEBUG - 2018-08-06 22:39:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-06 22:39:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-06 22:39:01 --> Email Class Initialized
INFO - 2018-08-06 22:39:01 --> Controller Class Initialized
DEBUG - 2018-08-06 22:39:01 --> Home MX_Controller Initialized
DEBUG - 2018-08-06 22:39:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-06 22:39:01 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-06 22:39:01 --> Login MX_Controller Initialized
INFO - 2018-08-06 22:39:01 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-06 22:39:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-06 22:39:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-06 22:39:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-08-06 22:39:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-08-06 22:39:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-08-06 22:39:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-08-06 22:39:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-08-06 22:39:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-08-06 22:39:01 --> Final output sent to browser
DEBUG - 2018-08-06 22:39:01 --> Total execution time: 0.3795
INFO - 2018-08-06 22:39:01 --> Config Class Initialized
INFO - 2018-08-06 22:39:01 --> Config Class Initialized
INFO - 2018-08-06 22:39:01 --> Hooks Class Initialized
INFO - 2018-08-06 22:39:01 --> Hooks Class Initialized
DEBUG - 2018-08-06 22:39:01 --> UTF-8 Support Enabled
DEBUG - 2018-08-06 22:39:01 --> UTF-8 Support Enabled
INFO - 2018-08-06 22:39:01 --> Config Class Initialized
INFO - 2018-08-06 22:39:01 --> Hooks Class Initialized
INFO - 2018-08-06 22:39:01 --> Utf8 Class Initialized
INFO - 2018-08-06 22:39:01 --> Utf8 Class Initialized
INFO - 2018-08-06 22:39:01 --> URI Class Initialized
DEBUG - 2018-08-06 22:39:01 --> UTF-8 Support Enabled
INFO - 2018-08-06 22:39:01 --> Utf8 Class Initialized
INFO - 2018-08-06 22:39:01 --> URI Class Initialized
INFO - 2018-08-06 22:39:01 --> Router Class Initialized
INFO - 2018-08-06 22:39:01 --> URI Class Initialized
INFO - 2018-08-06 22:39:01 --> Output Class Initialized
INFO - 2018-08-06 22:39:01 --> Router Class Initialized
INFO - 2018-08-06 22:39:01 --> Router Class Initialized
INFO - 2018-08-06 22:39:01 --> Output Class Initialized
INFO - 2018-08-06 22:39:01 --> Output Class Initialized
INFO - 2018-08-06 22:39:01 --> Security Class Initialized
DEBUG - 2018-08-06 22:39:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-06 22:39:01 --> Input Class Initialized
INFO - 2018-08-06 22:39:01 --> Language Class Initialized
INFO - 2018-08-06 22:39:01 --> Security Class Initialized
INFO - 2018-08-06 22:39:01 --> Security Class Initialized
DEBUG - 2018-08-06 22:39:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-06 22:39:01 --> Language Class Initialized
DEBUG - 2018-08-06 22:39:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-06 22:39:01 --> Input Class Initialized
INFO - 2018-08-06 22:39:01 --> Config Class Initialized
INFO - 2018-08-06 22:39:01 --> Language Class Initialized
INFO - 2018-08-06 22:39:01 --> Loader Class Initialized
DEBUG - 2018-08-06 22:39:01 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
ERROR - 2018-08-06 22:39:01 --> 404 Page Not Found: /index
INFO - 2018-08-06 22:39:01 --> Input Class Initialized
INFO - 2018-08-06 22:39:01 --> Helper loaded: url_helper
INFO - 2018-08-06 22:39:01 --> Helper loaded: form_helper
INFO - 2018-08-06 22:39:01 --> Language Class Initialized
INFO - 2018-08-06 22:39:01 --> Helper loaded: date_helper
INFO - 2018-08-06 22:39:01 --> Helper loaded: util_helper
ERROR - 2018-08-06 22:39:01 --> 404 Page Not Found: /index
INFO - 2018-08-06 22:39:01 --> Helper loaded: text_helper
INFO - 2018-08-06 22:39:01 --> Config Class Initialized
INFO - 2018-08-06 22:39:01 --> Helper loaded: string_helper
INFO - 2018-08-06 22:39:01 --> Hooks Class Initialized
DEBUG - 2018-08-06 22:39:01 --> UTF-8 Support Enabled
INFO - 2018-08-06 22:39:01 --> Database Driver Class Initialized
INFO - 2018-08-06 22:39:01 --> Utf8 Class Initialized
DEBUG - 2018-08-06 22:39:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-06 22:39:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-06 22:39:01 --> URI Class Initialized
INFO - 2018-08-06 22:39:01 --> Email Class Initialized
INFO - 2018-08-06 22:39:01 --> Router Class Initialized
INFO - 2018-08-06 22:39:01 --> Controller Class Initialized
INFO - 2018-08-06 22:39:01 --> Output Class Initialized
DEBUG - 2018-08-06 22:39:02 --> Home MX_Controller Initialized
INFO - 2018-08-06 22:39:02 --> Security Class Initialized
DEBUG - 2018-08-06 22:39:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-06 22:39:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-06 22:39:02 --> Input Class Initialized
DEBUG - 2018-08-06 22:39:02 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-06 22:39:02 --> Login MX_Controller Initialized
INFO - 2018-08-06 22:39:02 --> Language Class Initialized
INFO - 2018-08-06 22:39:02 --> Language file loaded: language/english/data_lang.php
ERROR - 2018-08-06 22:39:02 --> 404 Page Not Found: /index
DEBUG - 2018-08-06 22:39:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-08-06 22:39:02 --> Config Class Initialized
INFO - 2018-08-06 22:39:02 --> Hooks Class Initialized
DEBUG - 2018-08-06 22:39:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-06 22:39:02 --> UTF-8 Support Enabled
INFO - 2018-08-06 22:39:02 --> Utf8 Class Initialized
INFO - 2018-08-06 22:39:02 --> URI Class Initialized
INFO - 2018-08-06 22:39:02 --> Router Class Initialized
INFO - 2018-08-06 22:39:02 --> Output Class Initialized
INFO - 2018-08-06 22:39:02 --> Security Class Initialized
DEBUG - 2018-08-06 22:39:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-06 22:39:02 --> Input Class Initialized
INFO - 2018-08-06 22:39:02 --> Language Class Initialized
ERROR - 2018-08-06 22:39:02 --> 404 Page Not Found: /index
INFO - 2018-08-06 22:39:05 --> Config Class Initialized
INFO - 2018-08-06 22:39:05 --> Hooks Class Initialized
DEBUG - 2018-08-06 22:39:05 --> UTF-8 Support Enabled
INFO - 2018-08-06 22:39:05 --> Utf8 Class Initialized
INFO - 2018-08-06 22:39:06 --> URI Class Initialized
INFO - 2018-08-06 22:39:06 --> Router Class Initialized
INFO - 2018-08-06 22:39:06 --> Output Class Initialized
INFO - 2018-08-06 22:39:06 --> Security Class Initialized
DEBUG - 2018-08-06 22:39:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-06 22:39:06 --> Input Class Initialized
INFO - 2018-08-06 22:39:06 --> Language Class Initialized
INFO - 2018-08-06 22:39:06 --> Language Class Initialized
INFO - 2018-08-06 22:39:06 --> Config Class Initialized
INFO - 2018-08-06 22:39:06 --> Loader Class Initialized
DEBUG - 2018-08-06 22:39:06 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-06 22:39:06 --> Helper loaded: url_helper
INFO - 2018-08-06 22:39:06 --> Helper loaded: form_helper
INFO - 2018-08-06 22:39:06 --> Helper loaded: date_helper
INFO - 2018-08-06 22:39:06 --> Helper loaded: util_helper
INFO - 2018-08-06 22:39:06 --> Helper loaded: text_helper
INFO - 2018-08-06 22:39:06 --> Helper loaded: string_helper
INFO - 2018-08-06 22:39:06 --> Database Driver Class Initialized
DEBUG - 2018-08-06 22:39:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-06 22:39:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-06 22:39:06 --> Email Class Initialized
INFO - 2018-08-06 22:39:06 --> Controller Class Initialized
DEBUG - 2018-08-06 22:39:06 --> Home MX_Controller Initialized
DEBUG - 2018-08-06 22:39:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-06 22:39:06 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-06 22:39:06 --> Login MX_Controller Initialized
INFO - 2018-08-06 22:39:06 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-06 22:39:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-06 22:39:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-06 22:39:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-08-06 22:39:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-08-06 22:39:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-08-06 22:39:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-08-06 22:39:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-08-06 22:39:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-08-06 22:39:06 --> Final output sent to browser
DEBUG - 2018-08-06 22:39:06 --> Total execution time: 0.3939
INFO - 2018-08-06 22:39:06 --> Config Class Initialized
INFO - 2018-08-06 22:39:06 --> Config Class Initialized
INFO - 2018-08-06 22:39:06 --> Hooks Class Initialized
INFO - 2018-08-06 22:39:06 --> Hooks Class Initialized
DEBUG - 2018-08-06 22:39:06 --> UTF-8 Support Enabled
DEBUG - 2018-08-06 22:39:06 --> UTF-8 Support Enabled
INFO - 2018-08-06 22:39:06 --> Config Class Initialized
INFO - 2018-08-06 22:39:06 --> Utf8 Class Initialized
INFO - 2018-08-06 22:39:06 --> Hooks Class Initialized
INFO - 2018-08-06 22:39:06 --> Utf8 Class Initialized
INFO - 2018-08-06 22:39:06 --> URI Class Initialized
INFO - 2018-08-06 22:39:06 --> URI Class Initialized
DEBUG - 2018-08-06 22:39:06 --> UTF-8 Support Enabled
INFO - 2018-08-06 22:39:06 --> Router Class Initialized
INFO - 2018-08-06 22:39:06 --> Router Class Initialized
INFO - 2018-08-06 22:39:06 --> Utf8 Class Initialized
INFO - 2018-08-06 22:39:06 --> Output Class Initialized
INFO - 2018-08-06 22:39:06 --> Security Class Initialized
DEBUG - 2018-08-06 22:39:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-06 22:39:06 --> URI Class Initialized
INFO - 2018-08-06 22:39:06 --> Output Class Initialized
INFO - 2018-08-06 22:39:06 --> Input Class Initialized
INFO - 2018-08-06 22:39:06 --> Language Class Initialized
INFO - 2018-08-06 22:39:06 --> Router Class Initialized
ERROR - 2018-08-06 22:39:06 --> 404 Page Not Found: /index
INFO - 2018-08-06 22:39:06 --> Output Class Initialized
INFO - 2018-08-06 22:39:06 --> Security Class Initialized
INFO - 2018-08-06 22:39:06 --> Security Class Initialized
DEBUG - 2018-08-06 22:39:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-08-06 22:39:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-06 22:39:06 --> Input Class Initialized
INFO - 2018-08-06 22:39:06 --> Input Class Initialized
INFO - 2018-08-06 22:39:06 --> Language Class Initialized
INFO - 2018-08-06 22:39:06 --> Language Class Initialized
INFO - 2018-08-06 22:39:06 --> Language Class Initialized
INFO - 2018-08-06 22:39:06 --> Config Class Initialized
ERROR - 2018-08-06 22:39:06 --> 404 Page Not Found: /index
INFO - 2018-08-06 22:39:06 --> Loader Class Initialized
INFO - 2018-08-06 22:39:06 --> Config Class Initialized
DEBUG - 2018-08-06 22:39:06 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-06 22:39:06 --> Hooks Class Initialized
INFO - 2018-08-06 22:39:06 --> Helper loaded: url_helper
DEBUG - 2018-08-06 22:39:06 --> UTF-8 Support Enabled
INFO - 2018-08-06 22:39:06 --> Utf8 Class Initialized
INFO - 2018-08-06 22:39:06 --> Helper loaded: form_helper
INFO - 2018-08-06 22:39:06 --> URI Class Initialized
INFO - 2018-08-06 22:39:06 --> Helper loaded: date_helper
INFO - 2018-08-06 22:39:06 --> Helper loaded: util_helper
INFO - 2018-08-06 22:39:06 --> Router Class Initialized
INFO - 2018-08-06 22:39:07 --> Helper loaded: text_helper
INFO - 2018-08-06 22:39:07 --> Output Class Initialized
INFO - 2018-08-06 22:39:07 --> Helper loaded: string_helper
INFO - 2018-08-06 22:39:07 --> Security Class Initialized
DEBUG - 2018-08-06 22:39:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-06 22:39:07 --> Database Driver Class Initialized
INFO - 2018-08-06 22:39:07 --> Input Class Initialized
INFO - 2018-08-06 22:39:07 --> Language Class Initialized
DEBUG - 2018-08-06 22:39:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-06 22:39:07 --> Session: Class initialized using 'files' driver.
ERROR - 2018-08-06 22:39:07 --> 404 Page Not Found: /index
INFO - 2018-08-06 22:39:07 --> Email Class Initialized
INFO - 2018-08-06 22:39:07 --> Config Class Initialized
INFO - 2018-08-06 22:39:07 --> Hooks Class Initialized
INFO - 2018-08-06 22:39:07 --> Controller Class Initialized
DEBUG - 2018-08-06 22:39:07 --> Home MX_Controller Initialized
DEBUG - 2018-08-06 22:39:07 --> UTF-8 Support Enabled
INFO - 2018-08-06 22:39:07 --> Utf8 Class Initialized
DEBUG - 2018-08-06 22:39:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-08-06 22:39:07 --> URI Class Initialized
DEBUG - 2018-08-06 22:39:07 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-06 22:39:07 --> Login MX_Controller Initialized
INFO - 2018-08-06 22:39:07 --> Router Class Initialized
INFO - 2018-08-06 22:39:07 --> Language file loaded: language/english/data_lang.php
INFO - 2018-08-06 22:39:07 --> Output Class Initialized
DEBUG - 2018-08-06 22:39:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-08-06 22:39:07 --> Security Class Initialized
DEBUG - 2018-08-06 22:39:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-06 22:39:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-06 22:39:07 --> Input Class Initialized
INFO - 2018-08-06 22:39:07 --> Language Class Initialized
ERROR - 2018-08-06 22:39:07 --> 404 Page Not Found: /index
INFO - 2018-08-06 22:39:20 --> Config Class Initialized
INFO - 2018-08-06 22:39:20 --> Hooks Class Initialized
DEBUG - 2018-08-06 22:39:20 --> UTF-8 Support Enabled
INFO - 2018-08-06 22:39:20 --> Utf8 Class Initialized
INFO - 2018-08-06 22:39:20 --> URI Class Initialized
INFO - 2018-08-06 22:39:20 --> Router Class Initialized
INFO - 2018-08-06 22:39:20 --> Output Class Initialized
INFO - 2018-08-06 22:39:20 --> Security Class Initialized
DEBUG - 2018-08-06 22:39:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-06 22:39:20 --> Input Class Initialized
INFO - 2018-08-06 22:39:20 --> Language Class Initialized
INFO - 2018-08-06 22:39:20 --> Language Class Initialized
INFO - 2018-08-06 22:39:20 --> Config Class Initialized
INFO - 2018-08-06 22:39:20 --> Loader Class Initialized
DEBUG - 2018-08-06 22:39:20 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-06 22:39:20 --> Helper loaded: url_helper
INFO - 2018-08-06 22:39:20 --> Helper loaded: form_helper
INFO - 2018-08-06 22:39:20 --> Helper loaded: date_helper
INFO - 2018-08-06 22:39:20 --> Helper loaded: util_helper
INFO - 2018-08-06 22:39:20 --> Helper loaded: text_helper
INFO - 2018-08-06 22:39:20 --> Helper loaded: string_helper
INFO - 2018-08-06 22:39:20 --> Database Driver Class Initialized
DEBUG - 2018-08-06 22:39:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-06 22:39:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-06 22:39:20 --> Email Class Initialized
INFO - 2018-08-06 22:39:20 --> Controller Class Initialized
DEBUG - 2018-08-06 22:39:20 --> Home MX_Controller Initialized
DEBUG - 2018-08-06 22:39:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-06 22:39:20 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-06 22:39:20 --> Login MX_Controller Initialized
INFO - 2018-08-06 22:39:20 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-06 22:39:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-06 22:39:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-06 22:39:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-08-06 22:39:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-08-06 22:39:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-08-06 22:39:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-08-06 22:39:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-08-06 22:39:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/search_page.php
INFO - 2018-08-06 22:39:20 --> Final output sent to browser
DEBUG - 2018-08-06 22:39:20 --> Total execution time: 0.3921
INFO - 2018-08-06 22:39:21 --> Config Class Initialized
INFO - 2018-08-06 22:39:21 --> Hooks Class Initialized
INFO - 2018-08-06 22:39:21 --> Config Class Initialized
INFO - 2018-08-06 22:39:21 --> Hooks Class Initialized
DEBUG - 2018-08-06 22:39:21 --> UTF-8 Support Enabled
INFO - 2018-08-06 22:39:21 --> Utf8 Class Initialized
DEBUG - 2018-08-06 22:39:21 --> UTF-8 Support Enabled
INFO - 2018-08-06 22:39:21 --> Utf8 Class Initialized
INFO - 2018-08-06 22:39:21 --> URI Class Initialized
INFO - 2018-08-06 22:39:21 --> URI Class Initialized
INFO - 2018-08-06 22:39:21 --> Router Class Initialized
INFO - 2018-08-06 22:39:21 --> Output Class Initialized
INFO - 2018-08-06 22:39:21 --> Router Class Initialized
INFO - 2018-08-06 22:39:21 --> Security Class Initialized
DEBUG - 2018-08-06 22:39:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-06 22:39:21 --> Input Class Initialized
INFO - 2018-08-06 22:39:21 --> Language Class Initialized
INFO - 2018-08-06 22:39:21 --> Output Class Initialized
ERROR - 2018-08-06 22:39:21 --> 404 Page Not Found: /index
INFO - 2018-08-06 22:39:21 --> Security Class Initialized
DEBUG - 2018-08-06 22:39:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-06 22:39:21 --> Config Class Initialized
INFO - 2018-08-06 22:39:21 --> Hooks Class Initialized
INFO - 2018-08-06 22:39:21 --> Input Class Initialized
INFO - 2018-08-06 22:39:21 --> Language Class Initialized
DEBUG - 2018-08-06 22:39:21 --> UTF-8 Support Enabled
INFO - 2018-08-06 22:39:21 --> Utf8 Class Initialized
INFO - 2018-08-06 22:39:21 --> Language Class Initialized
INFO - 2018-08-06 22:39:21 --> Config Class Initialized
INFO - 2018-08-06 22:39:21 --> URI Class Initialized
INFO - 2018-08-06 22:39:21 --> Router Class Initialized
INFO - 2018-08-06 22:39:21 --> Loader Class Initialized
DEBUG - 2018-08-06 22:39:21 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-06 22:39:21 --> Output Class Initialized
INFO - 2018-08-06 22:39:21 --> Security Class Initialized
INFO - 2018-08-06 22:39:21 --> Helper loaded: url_helper
DEBUG - 2018-08-06 22:39:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-06 22:39:21 --> Helper loaded: form_helper
INFO - 2018-08-06 22:39:21 --> Input Class Initialized
INFO - 2018-08-06 22:39:21 --> Language Class Initialized
ERROR - 2018-08-06 22:39:21 --> 404 Page Not Found: /index
INFO - 2018-08-06 22:39:21 --> Helper loaded: date_helper
INFO - 2018-08-06 22:39:21 --> Helper loaded: util_helper
INFO - 2018-08-06 22:39:21 --> Config Class Initialized
INFO - 2018-08-06 22:39:21 --> Hooks Class Initialized
INFO - 2018-08-06 22:39:21 --> Helper loaded: text_helper
INFO - 2018-08-06 22:39:21 --> Helper loaded: string_helper
DEBUG - 2018-08-06 22:39:21 --> UTF-8 Support Enabled
INFO - 2018-08-06 22:39:21 --> Utf8 Class Initialized
INFO - 2018-08-06 22:39:21 --> Database Driver Class Initialized
INFO - 2018-08-06 22:39:21 --> URI Class Initialized
INFO - 2018-08-06 22:39:21 --> Router Class Initialized
DEBUG - 2018-08-06 22:39:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-06 22:39:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-06 22:39:21 --> Output Class Initialized
INFO - 2018-08-06 22:39:21 --> Security Class Initialized
INFO - 2018-08-06 22:39:21 --> Email Class Initialized
INFO - 2018-08-06 22:39:21 --> Controller Class Initialized
DEBUG - 2018-08-06 22:39:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-08-06 22:39:21 --> Home MX_Controller Initialized
DEBUG - 2018-08-06 22:39:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-08-06 22:39:21 --> Input Class Initialized
INFO - 2018-08-06 22:39:21 --> Language Class Initialized
DEBUG - 2018-08-06 22:39:21 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-06 22:39:21 --> Login MX_Controller Initialized
ERROR - 2018-08-06 22:39:21 --> 404 Page Not Found: /index
INFO - 2018-08-06 22:39:21 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-06 22:39:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-06 22:39:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-06 22:48:24 --> Config Class Initialized
INFO - 2018-08-06 22:48:24 --> Hooks Class Initialized
DEBUG - 2018-08-06 22:48:24 --> UTF-8 Support Enabled
INFO - 2018-08-06 22:48:24 --> Utf8 Class Initialized
INFO - 2018-08-06 22:48:24 --> URI Class Initialized
INFO - 2018-08-06 22:48:24 --> Router Class Initialized
INFO - 2018-08-06 22:48:24 --> Output Class Initialized
INFO - 2018-08-06 22:48:24 --> Security Class Initialized
DEBUG - 2018-08-06 22:48:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-06 22:48:24 --> Input Class Initialized
INFO - 2018-08-06 22:48:24 --> Language Class Initialized
INFO - 2018-08-06 22:48:24 --> Language Class Initialized
INFO - 2018-08-06 22:48:24 --> Config Class Initialized
INFO - 2018-08-06 22:48:24 --> Loader Class Initialized
DEBUG - 2018-08-06 22:48:24 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-06 22:48:24 --> Helper loaded: url_helper
INFO - 2018-08-06 22:48:24 --> Helper loaded: form_helper
INFO - 2018-08-06 22:48:24 --> Helper loaded: date_helper
INFO - 2018-08-06 22:48:24 --> Helper loaded: util_helper
INFO - 2018-08-06 22:48:24 --> Helper loaded: text_helper
INFO - 2018-08-06 22:48:24 --> Helper loaded: string_helper
INFO - 2018-08-06 22:48:24 --> Database Driver Class Initialized
DEBUG - 2018-08-06 22:48:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-06 22:48:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-06 22:48:24 --> Email Class Initialized
INFO - 2018-08-06 22:48:24 --> Controller Class Initialized
DEBUG - 2018-08-06 22:48:24 --> Home MX_Controller Initialized
DEBUG - 2018-08-06 22:48:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-06 22:48:24 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-06 22:48:24 --> Login MX_Controller Initialized
INFO - 2018-08-06 22:48:24 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-06 22:48:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-06 22:48:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-06 22:48:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-08-06 22:48:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-08-06 22:48:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-08-06 22:48:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-08-06 22:48:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-08-06 22:48:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/search_page.php
INFO - 2018-08-06 22:48:24 --> Final output sent to browser
DEBUG - 2018-08-06 22:48:24 --> Total execution time: 0.4230
INFO - 2018-08-06 22:48:24 --> Config Class Initialized
INFO - 2018-08-06 22:48:24 --> Config Class Initialized
INFO - 2018-08-06 22:48:24 --> Hooks Class Initialized
INFO - 2018-08-06 22:48:24 --> Hooks Class Initialized
DEBUG - 2018-08-06 22:48:25 --> UTF-8 Support Enabled
DEBUG - 2018-08-06 22:48:25 --> UTF-8 Support Enabled
INFO - 2018-08-06 22:48:25 --> Utf8 Class Initialized
INFO - 2018-08-06 22:48:25 --> Utf8 Class Initialized
INFO - 2018-08-06 22:48:25 --> URI Class Initialized
INFO - 2018-08-06 22:48:25 --> URI Class Initialized
INFO - 2018-08-06 22:48:25 --> Router Class Initialized
INFO - 2018-08-06 22:48:25 --> Router Class Initialized
INFO - 2018-08-06 22:48:25 --> Output Class Initialized
INFO - 2018-08-06 22:48:25 --> Security Class Initialized
DEBUG - 2018-08-06 22:48:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-06 22:48:25 --> Input Class Initialized
INFO - 2018-08-06 22:48:25 --> Language Class Initialized
INFO - 2018-08-06 22:48:25 --> Language Class Initialized
INFO - 2018-08-06 22:48:25 --> Config Class Initialized
INFO - 2018-08-06 22:48:25 --> Output Class Initialized
INFO - 2018-08-06 22:48:25 --> Loader Class Initialized
INFO - 2018-08-06 22:48:25 --> Security Class Initialized
DEBUG - 2018-08-06 22:48:25 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-06 22:48:25 --> Helper loaded: url_helper
INFO - 2018-08-06 22:48:25 --> Helper loaded: form_helper
INFO - 2018-08-06 22:48:25 --> Helper loaded: date_helper
INFO - 2018-08-06 22:48:25 --> Helper loaded: util_helper
INFO - 2018-08-06 22:48:25 --> Helper loaded: text_helper
INFO - 2018-08-06 22:48:25 --> Helper loaded: string_helper
DEBUG - 2018-08-06 22:48:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-06 22:48:25 --> Database Driver Class Initialized
INFO - 2018-08-06 22:48:25 --> Input Class Initialized
DEBUG - 2018-08-06 22:48:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-06 22:48:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-06 22:48:25 --> Language Class Initialized
ERROR - 2018-08-06 22:48:25 --> 404 Page Not Found: /index
INFO - 2018-08-06 22:48:25 --> Email Class Initialized
INFO - 2018-08-06 22:48:25 --> Controller Class Initialized
INFO - 2018-08-06 22:48:25 --> Config Class Initialized
DEBUG - 2018-08-06 22:48:25 --> Home MX_Controller Initialized
INFO - 2018-08-06 22:48:25 --> Hooks Class Initialized
DEBUG - 2018-08-06 22:48:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-06 22:48:25 --> UTF-8 Support Enabled
INFO - 2018-08-06 22:48:25 --> Utf8 Class Initialized
DEBUG - 2018-08-06 22:48:25 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-06 22:48:25 --> Login MX_Controller Initialized
INFO - 2018-08-06 22:48:25 --> URI Class Initialized
INFO - 2018-08-06 22:48:25 --> Language file loaded: language/english/data_lang.php
INFO - 2018-08-06 22:48:25 --> Router Class Initialized
DEBUG - 2018-08-06 22:48:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-06 22:48:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-06 22:48:25 --> Output Class Initialized
INFO - 2018-08-06 22:48:25 --> Security Class Initialized
DEBUG - 2018-08-06 22:48:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-06 22:48:25 --> Input Class Initialized
INFO - 2018-08-06 22:48:25 --> Language Class Initialized
ERROR - 2018-08-06 22:48:25 --> 404 Page Not Found: /index
INFO - 2018-08-06 22:48:25 --> Config Class Initialized
INFO - 2018-08-06 22:48:25 --> Hooks Class Initialized
DEBUG - 2018-08-06 22:48:25 --> UTF-8 Support Enabled
INFO - 2018-08-06 22:48:25 --> Utf8 Class Initialized
INFO - 2018-08-06 22:48:25 --> URI Class Initialized
INFO - 2018-08-06 22:48:25 --> Router Class Initialized
INFO - 2018-08-06 22:48:25 --> Output Class Initialized
INFO - 2018-08-06 22:48:25 --> Security Class Initialized
DEBUG - 2018-08-06 22:48:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-06 22:48:25 --> Input Class Initialized
INFO - 2018-08-06 22:48:25 --> Language Class Initialized
ERROR - 2018-08-06 22:48:25 --> 404 Page Not Found: /index
INFO - 2018-08-06 23:02:24 --> Config Class Initialized
INFO - 2018-08-06 23:02:24 --> Hooks Class Initialized
DEBUG - 2018-08-06 23:02:24 --> UTF-8 Support Enabled
INFO - 2018-08-06 23:02:24 --> Utf8 Class Initialized
INFO - 2018-08-06 23:02:24 --> URI Class Initialized
INFO - 2018-08-06 23:02:24 --> Router Class Initialized
INFO - 2018-08-06 23:02:24 --> Output Class Initialized
INFO - 2018-08-06 23:02:24 --> Security Class Initialized
DEBUG - 2018-08-06 23:02:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-06 23:02:24 --> Input Class Initialized
INFO - 2018-08-06 23:02:24 --> Language Class Initialized
INFO - 2018-08-06 23:02:24 --> Language Class Initialized
INFO - 2018-08-06 23:02:24 --> Config Class Initialized
INFO - 2018-08-06 23:02:24 --> Loader Class Initialized
DEBUG - 2018-08-06 23:02:24 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-06 23:02:24 --> Helper loaded: url_helper
INFO - 2018-08-06 23:02:24 --> Helper loaded: form_helper
INFO - 2018-08-06 23:02:24 --> Helper loaded: date_helper
INFO - 2018-08-06 23:02:24 --> Helper loaded: util_helper
INFO - 2018-08-06 23:02:24 --> Helper loaded: text_helper
INFO - 2018-08-06 23:02:24 --> Helper loaded: string_helper
INFO - 2018-08-06 23:02:24 --> Database Driver Class Initialized
DEBUG - 2018-08-06 23:02:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-06 23:02:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-06 23:02:24 --> Email Class Initialized
INFO - 2018-08-06 23:02:24 --> Controller Class Initialized
DEBUG - 2018-08-06 23:02:24 --> Home MX_Controller Initialized
DEBUG - 2018-08-06 23:02:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-06 23:02:24 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-06 23:02:24 --> Login MX_Controller Initialized
INFO - 2018-08-06 23:02:24 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-06 23:02:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-06 23:02:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-06 23:02:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-08-06 23:02:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-08-06 23:02:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-08-06 23:02:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-08-06 23:02:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-08-06 23:02:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/search_page.php
INFO - 2018-08-06 23:02:25 --> Final output sent to browser
DEBUG - 2018-08-06 23:02:25 --> Total execution time: 0.4168
INFO - 2018-08-06 23:02:25 --> Config Class Initialized
INFO - 2018-08-06 23:02:25 --> Hooks Class Initialized
DEBUG - 2018-08-06 23:02:25 --> UTF-8 Support Enabled
INFO - 2018-08-06 23:02:25 --> Config Class Initialized
INFO - 2018-08-06 23:02:25 --> Hooks Class Initialized
INFO - 2018-08-06 23:02:25 --> Utf8 Class Initialized
INFO - 2018-08-06 23:02:25 --> URI Class Initialized
DEBUG - 2018-08-06 23:02:25 --> UTF-8 Support Enabled
INFO - 2018-08-06 23:02:25 --> Router Class Initialized
INFO - 2018-08-06 23:02:25 --> Utf8 Class Initialized
INFO - 2018-08-06 23:02:25 --> URI Class Initialized
INFO - 2018-08-06 23:02:25 --> Router Class Initialized
INFO - 2018-08-06 23:02:25 --> Output Class Initialized
INFO - 2018-08-06 23:02:25 --> Output Class Initialized
INFO - 2018-08-06 23:02:25 --> Security Class Initialized
INFO - 2018-08-06 23:02:25 --> Security Class Initialized
DEBUG - 2018-08-06 23:02:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-06 23:02:25 --> Input Class Initialized
INFO - 2018-08-06 23:02:25 --> Language Class Initialized
ERROR - 2018-08-06 23:02:25 --> 404 Page Not Found: /index
DEBUG - 2018-08-06 23:02:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-06 23:02:25 --> Config Class Initialized
INFO - 2018-08-06 23:02:25 --> Hooks Class Initialized
INFO - 2018-08-06 23:02:25 --> Input Class Initialized
INFO - 2018-08-06 23:02:25 --> Language Class Initialized
DEBUG - 2018-08-06 23:02:25 --> UTF-8 Support Enabled
INFO - 2018-08-06 23:02:25 --> Utf8 Class Initialized
INFO - 2018-08-06 23:02:25 --> Language Class Initialized
INFO - 2018-08-06 23:02:25 --> URI Class Initialized
INFO - 2018-08-06 23:02:25 --> Config Class Initialized
INFO - 2018-08-06 23:02:25 --> Loader Class Initialized
INFO - 2018-08-06 23:02:25 --> Router Class Initialized
INFO - 2018-08-06 23:02:25 --> Output Class Initialized
DEBUG - 2018-08-06 23:02:25 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-06 23:02:25 --> Security Class Initialized
INFO - 2018-08-06 23:02:25 --> Helper loaded: url_helper
DEBUG - 2018-08-06 23:02:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-06 23:02:25 --> Input Class Initialized
INFO - 2018-08-06 23:02:25 --> Helper loaded: form_helper
INFO - 2018-08-06 23:02:25 --> Language Class Initialized
ERROR - 2018-08-06 23:02:25 --> 404 Page Not Found: /index
INFO - 2018-08-06 23:02:25 --> Helper loaded: date_helper
INFO - 2018-08-06 23:02:25 --> Helper loaded: util_helper
INFO - 2018-08-06 23:02:25 --> Config Class Initialized
INFO - 2018-08-06 23:02:25 --> Hooks Class Initialized
INFO - 2018-08-06 23:02:25 --> Helper loaded: text_helper
INFO - 2018-08-06 23:02:25 --> Helper loaded: string_helper
DEBUG - 2018-08-06 23:02:25 --> UTF-8 Support Enabled
INFO - 2018-08-06 23:02:25 --> Utf8 Class Initialized
INFO - 2018-08-06 23:02:25 --> Database Driver Class Initialized
INFO - 2018-08-06 23:02:25 --> URI Class Initialized
DEBUG - 2018-08-06 23:02:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-06 23:02:25 --> Router Class Initialized
INFO - 2018-08-06 23:02:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-06 23:02:25 --> Output Class Initialized
INFO - 2018-08-06 23:02:25 --> Security Class Initialized
INFO - 2018-08-06 23:02:25 --> Email Class Initialized
INFO - 2018-08-06 23:02:25 --> Controller Class Initialized
DEBUG - 2018-08-06 23:02:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-06 23:02:25 --> Input Class Initialized
DEBUG - 2018-08-06 23:02:25 --> Home MX_Controller Initialized
INFO - 2018-08-06 23:02:26 --> Language Class Initialized
DEBUG - 2018-08-06 23:02:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
ERROR - 2018-08-06 23:02:26 --> 404 Page Not Found: /index
DEBUG - 2018-08-06 23:02:26 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-06 23:02:26 --> Login MX_Controller Initialized
INFO - 2018-08-06 23:02:26 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-06 23:02:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-06 23:02:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-06 23:04:55 --> Config Class Initialized
INFO - 2018-08-06 23:04:55 --> Hooks Class Initialized
DEBUG - 2018-08-06 23:04:55 --> UTF-8 Support Enabled
INFO - 2018-08-06 23:04:55 --> Utf8 Class Initialized
INFO - 2018-08-06 23:04:55 --> URI Class Initialized
INFO - 2018-08-06 23:04:55 --> Router Class Initialized
INFO - 2018-08-06 23:04:55 --> Output Class Initialized
INFO - 2018-08-06 23:04:55 --> Security Class Initialized
DEBUG - 2018-08-06 23:04:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-06 23:04:55 --> Input Class Initialized
INFO - 2018-08-06 23:04:55 --> Language Class Initialized
INFO - 2018-08-06 23:04:55 --> Language Class Initialized
INFO - 2018-08-06 23:04:55 --> Config Class Initialized
INFO - 2018-08-06 23:04:55 --> Loader Class Initialized
DEBUG - 2018-08-06 23:04:55 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-06 23:04:55 --> Helper loaded: url_helper
INFO - 2018-08-06 23:04:55 --> Helper loaded: form_helper
INFO - 2018-08-06 23:04:55 --> Helper loaded: date_helper
INFO - 2018-08-06 23:04:55 --> Helper loaded: util_helper
INFO - 2018-08-06 23:04:55 --> Helper loaded: text_helper
INFO - 2018-08-06 23:04:55 --> Helper loaded: string_helper
INFO - 2018-08-06 23:04:55 --> Database Driver Class Initialized
DEBUG - 2018-08-06 23:04:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-06 23:04:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-06 23:04:55 --> Email Class Initialized
INFO - 2018-08-06 23:04:55 --> Controller Class Initialized
DEBUG - 2018-08-06 23:04:55 --> Home MX_Controller Initialized
DEBUG - 2018-08-06 23:04:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-06 23:04:55 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-06 23:04:55 --> Login MX_Controller Initialized
INFO - 2018-08-06 23:04:55 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-06 23:04:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-06 23:04:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-06 23:04:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-08-06 23:04:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-08-06 23:04:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-08-06 23:04:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-08-06 23:04:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-08-06 23:04:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/search_page.php
INFO - 2018-08-06 23:04:55 --> Final output sent to browser
DEBUG - 2018-08-06 23:04:55 --> Total execution time: 0.4430
INFO - 2018-08-06 23:04:56 --> Config Class Initialized
INFO - 2018-08-06 23:04:56 --> Hooks Class Initialized
DEBUG - 2018-08-06 23:04:56 --> UTF-8 Support Enabled
INFO - 2018-08-06 23:04:56 --> Utf8 Class Initialized
INFO - 2018-08-06 23:04:56 --> Config Class Initialized
INFO - 2018-08-06 23:04:56 --> Hooks Class Initialized
INFO - 2018-08-06 23:04:56 --> URI Class Initialized
DEBUG - 2018-08-06 23:04:56 --> UTF-8 Support Enabled
INFO - 2018-08-06 23:04:56 --> Router Class Initialized
INFO - 2018-08-06 23:04:56 --> Utf8 Class Initialized
INFO - 2018-08-06 23:04:56 --> Output Class Initialized
INFO - 2018-08-06 23:04:56 --> URI Class Initialized
INFO - 2018-08-06 23:04:56 --> Router Class Initialized
INFO - 2018-08-06 23:04:56 --> Security Class Initialized
INFO - 2018-08-06 23:04:56 --> Output Class Initialized
DEBUG - 2018-08-06 23:04:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-06 23:04:56 --> Input Class Initialized
INFO - 2018-08-06 23:04:56 --> Language Class Initialized
ERROR - 2018-08-06 23:04:56 --> 404 Page Not Found: /index
INFO - 2018-08-06 23:04:56 --> Config Class Initialized
INFO - 2018-08-06 23:04:56 --> Hooks Class Initialized
DEBUG - 2018-08-06 23:04:56 --> UTF-8 Support Enabled
INFO - 2018-08-06 23:04:56 --> Security Class Initialized
INFO - 2018-08-06 23:04:56 --> Utf8 Class Initialized
INFO - 2018-08-06 23:04:56 --> URI Class Initialized
INFO - 2018-08-06 23:04:56 --> Router Class Initialized
DEBUG - 2018-08-06 23:04:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-06 23:04:56 --> Output Class Initialized
INFO - 2018-08-06 23:04:56 --> Security Class Initialized
DEBUG - 2018-08-06 23:04:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-06 23:04:56 --> Input Class Initialized
INFO - 2018-08-06 23:04:56 --> Language Class Initialized
ERROR - 2018-08-06 23:04:56 --> 404 Page Not Found: /index
INFO - 2018-08-06 23:04:56 --> Config Class Initialized
INFO - 2018-08-06 23:04:56 --> Hooks Class Initialized
INFO - 2018-08-06 23:04:56 --> Input Class Initialized
DEBUG - 2018-08-06 23:04:56 --> UTF-8 Support Enabled
INFO - 2018-08-06 23:04:56 --> Utf8 Class Initialized
INFO - 2018-08-06 23:04:56 --> Language Class Initialized
INFO - 2018-08-06 23:04:56 --> URI Class Initialized
INFO - 2018-08-06 23:04:56 --> Router Class Initialized
INFO - 2018-08-06 23:04:56 --> Language Class Initialized
INFO - 2018-08-06 23:04:56 --> Output Class Initialized
INFO - 2018-08-06 23:04:56 --> Config Class Initialized
INFO - 2018-08-06 23:04:56 --> Security Class Initialized
DEBUG - 2018-08-06 23:04:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-06 23:04:56 --> Loader Class Initialized
INFO - 2018-08-06 23:04:56 --> Input Class Initialized
INFO - 2018-08-06 23:04:56 --> Language Class Initialized
ERROR - 2018-08-06 23:04:56 --> 404 Page Not Found: /index
DEBUG - 2018-08-06 23:04:56 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-06 23:04:56 --> Helper loaded: url_helper
INFO - 2018-08-06 23:04:56 --> Helper loaded: form_helper
INFO - 2018-08-06 23:04:56 --> Helper loaded: date_helper
INFO - 2018-08-06 23:04:56 --> Helper loaded: util_helper
INFO - 2018-08-06 23:04:56 --> Helper loaded: text_helper
INFO - 2018-08-06 23:04:56 --> Helper loaded: string_helper
INFO - 2018-08-06 23:04:56 --> Database Driver Class Initialized
DEBUG - 2018-08-06 23:04:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-06 23:04:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-06 23:04:56 --> Email Class Initialized
INFO - 2018-08-06 23:04:56 --> Controller Class Initialized
DEBUG - 2018-08-06 23:04:56 --> Home MX_Controller Initialized
DEBUG - 2018-08-06 23:04:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-06 23:04:56 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-06 23:04:56 --> Login MX_Controller Initialized
INFO - 2018-08-06 23:04:56 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-06 23:04:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-06 23:04:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-06 23:05:34 --> Config Class Initialized
INFO - 2018-08-06 23:05:34 --> Hooks Class Initialized
DEBUG - 2018-08-06 23:05:34 --> UTF-8 Support Enabled
INFO - 2018-08-06 23:05:34 --> Utf8 Class Initialized
INFO - 2018-08-06 23:05:34 --> URI Class Initialized
INFO - 2018-08-06 23:05:34 --> Router Class Initialized
INFO - 2018-08-06 23:05:34 --> Output Class Initialized
INFO - 2018-08-06 23:05:34 --> Security Class Initialized
DEBUG - 2018-08-06 23:05:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-06 23:05:34 --> Input Class Initialized
INFO - 2018-08-06 23:05:34 --> Language Class Initialized
INFO - 2018-08-06 23:05:34 --> Language Class Initialized
INFO - 2018-08-06 23:05:34 --> Config Class Initialized
INFO - 2018-08-06 23:05:34 --> Loader Class Initialized
DEBUG - 2018-08-06 23:05:34 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-06 23:05:34 --> Helper loaded: url_helper
INFO - 2018-08-06 23:05:34 --> Helper loaded: form_helper
INFO - 2018-08-06 23:05:34 --> Helper loaded: date_helper
INFO - 2018-08-06 23:05:34 --> Helper loaded: util_helper
INFO - 2018-08-06 23:05:34 --> Helper loaded: text_helper
INFO - 2018-08-06 23:05:34 --> Helper loaded: string_helper
INFO - 2018-08-06 23:05:34 --> Database Driver Class Initialized
DEBUG - 2018-08-06 23:05:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-06 23:05:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-06 23:05:34 --> Email Class Initialized
INFO - 2018-08-06 23:05:34 --> Controller Class Initialized
DEBUG - 2018-08-06 23:05:34 --> Home MX_Controller Initialized
DEBUG - 2018-08-06 23:05:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-06 23:05:34 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-06 23:05:34 --> Login MX_Controller Initialized
INFO - 2018-08-06 23:05:34 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-06 23:05:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-06 23:05:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-06 23:05:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-08-06 23:05:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-08-06 23:05:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-08-06 23:05:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-08-06 23:05:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-08-06 23:05:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/search_page.php
INFO - 2018-08-06 23:05:34 --> Final output sent to browser
DEBUG - 2018-08-06 23:05:34 --> Total execution time: 0.4453
INFO - 2018-08-06 23:05:35 --> Config Class Initialized
INFO - 2018-08-06 23:05:35 --> Hooks Class Initialized
INFO - 2018-08-06 23:05:35 --> Config Class Initialized
INFO - 2018-08-06 23:05:35 --> Hooks Class Initialized
DEBUG - 2018-08-06 23:05:35 --> UTF-8 Support Enabled
INFO - 2018-08-06 23:05:35 --> Utf8 Class Initialized
DEBUG - 2018-08-06 23:05:35 --> UTF-8 Support Enabled
INFO - 2018-08-06 23:05:35 --> URI Class Initialized
INFO - 2018-08-06 23:05:35 --> Utf8 Class Initialized
INFO - 2018-08-06 23:05:35 --> Router Class Initialized
INFO - 2018-08-06 23:05:35 --> Output Class Initialized
INFO - 2018-08-06 23:05:35 --> URI Class Initialized
INFO - 2018-08-06 23:05:35 --> Security Class Initialized
INFO - 2018-08-06 23:05:35 --> Router Class Initialized
INFO - 2018-08-06 23:05:35 --> Output Class Initialized
INFO - 2018-08-06 23:05:35 --> Security Class Initialized
DEBUG - 2018-08-06 23:05:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-06 23:05:35 --> Input Class Initialized
INFO - 2018-08-06 23:05:35 --> Language Class Initialized
INFO - 2018-08-06 23:05:35 --> Language Class Initialized
DEBUG - 2018-08-06 23:05:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-06 23:05:35 --> Config Class Initialized
INFO - 2018-08-06 23:05:35 --> Input Class Initialized
INFO - 2018-08-06 23:05:35 --> Loader Class Initialized
INFO - 2018-08-06 23:05:35 --> Language Class Initialized
DEBUG - 2018-08-06 23:05:35 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
ERROR - 2018-08-06 23:05:35 --> 404 Page Not Found: /index
INFO - 2018-08-06 23:05:35 --> Helper loaded: url_helper
INFO - 2018-08-06 23:05:35 --> Helper loaded: form_helper
INFO - 2018-08-06 23:05:35 --> Config Class Initialized
INFO - 2018-08-06 23:05:35 --> Hooks Class Initialized
INFO - 2018-08-06 23:05:35 --> Helper loaded: date_helper
DEBUG - 2018-08-06 23:05:35 --> UTF-8 Support Enabled
INFO - 2018-08-06 23:05:35 --> Utf8 Class Initialized
INFO - 2018-08-06 23:05:35 --> URI Class Initialized
INFO - 2018-08-06 23:05:35 --> Router Class Initialized
INFO - 2018-08-06 23:05:35 --> Helper loaded: util_helper
INFO - 2018-08-06 23:05:35 --> Output Class Initialized
INFO - 2018-08-06 23:05:35 --> Helper loaded: text_helper
INFO - 2018-08-06 23:05:35 --> Security Class Initialized
DEBUG - 2018-08-06 23:05:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-06 23:05:35 --> Helper loaded: string_helper
INFO - 2018-08-06 23:05:35 --> Input Class Initialized
INFO - 2018-08-06 23:05:35 --> Database Driver Class Initialized
INFO - 2018-08-06 23:05:35 --> Language Class Initialized
DEBUG - 2018-08-06 23:05:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-06 23:05:35 --> Session: Class initialized using 'files' driver.
ERROR - 2018-08-06 23:05:35 --> 404 Page Not Found: /index
INFO - 2018-08-06 23:05:35 --> Email Class Initialized
INFO - 2018-08-06 23:05:35 --> Config Class Initialized
INFO - 2018-08-06 23:05:35 --> Hooks Class Initialized
INFO - 2018-08-06 23:05:35 --> Controller Class Initialized
DEBUG - 2018-08-06 23:05:35 --> Home MX_Controller Initialized
DEBUG - 2018-08-06 23:05:35 --> UTF-8 Support Enabled
INFO - 2018-08-06 23:05:35 --> Utf8 Class Initialized
DEBUG - 2018-08-06 23:05:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-08-06 23:05:35 --> URI Class Initialized
DEBUG - 2018-08-06 23:05:35 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-06 23:05:35 --> Login MX_Controller Initialized
INFO - 2018-08-06 23:05:35 --> Router Class Initialized
INFO - 2018-08-06 23:05:35 --> Output Class Initialized
INFO - 2018-08-06 23:05:35 --> Language file loaded: language/english/data_lang.php
INFO - 2018-08-06 23:05:35 --> Security Class Initialized
DEBUG - 2018-08-06 23:05:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-06 23:05:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-08-06 23:05:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-06 23:05:35 --> Input Class Initialized
INFO - 2018-08-06 23:05:35 --> Language Class Initialized
ERROR - 2018-08-06 23:05:35 --> 404 Page Not Found: /index
INFO - 2018-08-06 23:05:40 --> Config Class Initialized
INFO - 2018-08-06 23:05:40 --> Hooks Class Initialized
DEBUG - 2018-08-06 23:05:40 --> UTF-8 Support Enabled
INFO - 2018-08-06 23:05:40 --> Utf8 Class Initialized
INFO - 2018-08-06 23:05:40 --> URI Class Initialized
INFO - 2018-08-06 23:05:40 --> Router Class Initialized
INFO - 2018-08-06 23:05:40 --> Output Class Initialized
INFO - 2018-08-06 23:05:40 --> Security Class Initialized
DEBUG - 2018-08-06 23:05:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-06 23:05:40 --> Input Class Initialized
INFO - 2018-08-06 23:05:40 --> Language Class Initialized
INFO - 2018-08-06 23:05:40 --> Language Class Initialized
INFO - 2018-08-06 23:05:40 --> Config Class Initialized
INFO - 2018-08-06 23:05:40 --> Loader Class Initialized
DEBUG - 2018-08-06 23:05:40 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-06 23:05:40 --> Helper loaded: url_helper
INFO - 2018-08-06 23:05:40 --> Helper loaded: form_helper
INFO - 2018-08-06 23:05:40 --> Helper loaded: date_helper
INFO - 2018-08-06 23:05:40 --> Helper loaded: util_helper
INFO - 2018-08-06 23:05:40 --> Helper loaded: text_helper
INFO - 2018-08-06 23:05:40 --> Helper loaded: string_helper
INFO - 2018-08-06 23:05:40 --> Database Driver Class Initialized
DEBUG - 2018-08-06 23:05:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-06 23:05:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-06 23:05:40 --> Email Class Initialized
INFO - 2018-08-06 23:05:40 --> Controller Class Initialized
DEBUG - 2018-08-06 23:05:41 --> Home MX_Controller Initialized
DEBUG - 2018-08-06 23:05:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-06 23:05:41 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-06 23:05:41 --> Login MX_Controller Initialized
INFO - 2018-08-06 23:05:41 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-06 23:05:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-06 23:05:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-06 23:05:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-08-06 23:05:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-08-06 23:05:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-08-06 23:05:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-08-06 23:05:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-08-06 23:05:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/search_page.php
INFO - 2018-08-06 23:05:41 --> Final output sent to browser
DEBUG - 2018-08-06 23:05:41 --> Total execution time: 0.4462
INFO - 2018-08-06 23:05:41 --> Config Class Initialized
INFO - 2018-08-06 23:05:41 --> Hooks Class Initialized
INFO - 2018-08-06 23:05:41 --> Config Class Initialized
INFO - 2018-08-06 23:05:41 --> Hooks Class Initialized
DEBUG - 2018-08-06 23:05:41 --> UTF-8 Support Enabled
INFO - 2018-08-06 23:05:41 --> Utf8 Class Initialized
DEBUG - 2018-08-06 23:05:41 --> UTF-8 Support Enabled
INFO - 2018-08-06 23:05:41 --> Utf8 Class Initialized
INFO - 2018-08-06 23:05:41 --> URI Class Initialized
INFO - 2018-08-06 23:05:41 --> URI Class Initialized
INFO - 2018-08-06 23:05:41 --> Router Class Initialized
INFO - 2018-08-06 23:05:41 --> Output Class Initialized
INFO - 2018-08-06 23:05:41 --> Router Class Initialized
INFO - 2018-08-06 23:05:41 --> Output Class Initialized
INFO - 2018-08-06 23:05:41 --> Security Class Initialized
INFO - 2018-08-06 23:05:41 --> Security Class Initialized
DEBUG - 2018-08-06 23:05:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-08-06 23:05:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-06 23:05:41 --> Input Class Initialized
INFO - 2018-08-06 23:05:41 --> Input Class Initialized
INFO - 2018-08-06 23:05:41 --> Language Class Initialized
INFO - 2018-08-06 23:05:41 --> Language Class Initialized
ERROR - 2018-08-06 23:05:41 --> 404 Page Not Found: /index
INFO - 2018-08-06 23:05:41 --> Language Class Initialized
INFO - 2018-08-06 23:05:41 --> Config Class Initialized
INFO - 2018-08-06 23:05:41 --> Hooks Class Initialized
INFO - 2018-08-06 23:05:41 --> Config Class Initialized
DEBUG - 2018-08-06 23:05:41 --> UTF-8 Support Enabled
INFO - 2018-08-06 23:05:41 --> Loader Class Initialized
INFO - 2018-08-06 23:05:41 --> Utf8 Class Initialized
INFO - 2018-08-06 23:05:41 --> URI Class Initialized
INFO - 2018-08-06 23:05:41 --> Router Class Initialized
DEBUG - 2018-08-06 23:05:41 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-06 23:05:41 --> Output Class Initialized
INFO - 2018-08-06 23:05:41 --> Security Class Initialized
DEBUG - 2018-08-06 23:05:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-06 23:05:41 --> Input Class Initialized
INFO - 2018-08-06 23:05:41 --> Language Class Initialized
ERROR - 2018-08-06 23:05:41 --> 404 Page Not Found: /index
INFO - 2018-08-06 23:05:41 --> Helper loaded: url_helper
INFO - 2018-08-06 23:05:41 --> Config Class Initialized
INFO - 2018-08-06 23:05:41 --> Hooks Class Initialized
INFO - 2018-08-06 23:05:41 --> Helper loaded: form_helper
DEBUG - 2018-08-06 23:05:41 --> UTF-8 Support Enabled
INFO - 2018-08-06 23:05:41 --> Utf8 Class Initialized
INFO - 2018-08-06 23:05:41 --> URI Class Initialized
INFO - 2018-08-06 23:05:41 --> Router Class Initialized
INFO - 2018-08-06 23:05:41 --> Helper loaded: date_helper
INFO - 2018-08-06 23:05:41 --> Output Class Initialized
INFO - 2018-08-06 23:05:41 --> Security Class Initialized
DEBUG - 2018-08-06 23:05:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-06 23:05:41 --> Input Class Initialized
INFO - 2018-08-06 23:05:41 --> Language Class Initialized
ERROR - 2018-08-06 23:05:41 --> 404 Page Not Found: /index
INFO - 2018-08-06 23:05:41 --> Helper loaded: util_helper
INFO - 2018-08-06 23:05:41 --> Helper loaded: text_helper
INFO - 2018-08-06 23:05:41 --> Helper loaded: string_helper
INFO - 2018-08-06 23:05:41 --> Database Driver Class Initialized
DEBUG - 2018-08-06 23:05:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-06 23:05:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-06 23:05:41 --> Email Class Initialized
INFO - 2018-08-06 23:05:41 --> Controller Class Initialized
DEBUG - 2018-08-06 23:05:41 --> Home MX_Controller Initialized
DEBUG - 2018-08-06 23:05:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-06 23:05:41 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-06 23:05:42 --> Login MX_Controller Initialized
INFO - 2018-08-06 23:05:42 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-06 23:05:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-06 23:05:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-06 23:06:33 --> Config Class Initialized
INFO - 2018-08-06 23:06:33 --> Hooks Class Initialized
DEBUG - 2018-08-06 23:06:33 --> UTF-8 Support Enabled
INFO - 2018-08-06 23:06:33 --> Utf8 Class Initialized
INFO - 2018-08-06 23:06:33 --> URI Class Initialized
DEBUG - 2018-08-06 23:06:33 --> No URI present. Default controller set.
INFO - 2018-08-06 23:06:33 --> Router Class Initialized
INFO - 2018-08-06 23:06:33 --> Output Class Initialized
INFO - 2018-08-06 23:06:33 --> Security Class Initialized
DEBUG - 2018-08-06 23:06:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-06 23:06:33 --> Input Class Initialized
INFO - 2018-08-06 23:06:33 --> Language Class Initialized
INFO - 2018-08-06 23:06:33 --> Language Class Initialized
INFO - 2018-08-06 23:06:33 --> Config Class Initialized
INFO - 2018-08-06 23:06:33 --> Loader Class Initialized
DEBUG - 2018-08-06 23:06:33 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-06 23:06:33 --> Helper loaded: url_helper
INFO - 2018-08-06 23:06:33 --> Helper loaded: form_helper
INFO - 2018-08-06 23:06:33 --> Helper loaded: date_helper
INFO - 2018-08-06 23:06:33 --> Helper loaded: util_helper
INFO - 2018-08-06 23:06:33 --> Helper loaded: text_helper
INFO - 2018-08-06 23:06:33 --> Helper loaded: string_helper
INFO - 2018-08-06 23:06:33 --> Database Driver Class Initialized
DEBUG - 2018-08-06 23:06:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-06 23:06:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-06 23:06:34 --> Email Class Initialized
INFO - 2018-08-06 23:06:34 --> Controller Class Initialized
DEBUG - 2018-08-06 23:06:34 --> Home MX_Controller Initialized
DEBUG - 2018-08-06 23:06:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-06 23:06:34 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-06 23:06:34 --> Login MX_Controller Initialized
INFO - 2018-08-06 23:06:34 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-06 23:06:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-06 23:06:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-06 23:06:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-08-06 23:06:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-08-06 23:06:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-08-06 23:06:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-08-06 23:06:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-08-06 23:06:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-08-06 23:06:34 --> Final output sent to browser
DEBUG - 2018-08-06 23:06:34 --> Total execution time: 0.5797
INFO - 2018-08-06 23:06:34 --> Config Class Initialized
INFO - 2018-08-06 23:06:34 --> Hooks Class Initialized
DEBUG - 2018-08-06 23:06:34 --> UTF-8 Support Enabled
INFO - 2018-08-06 23:06:34 --> Utf8 Class Initialized
INFO - 2018-08-06 23:06:34 --> URI Class Initialized
INFO - 2018-08-06 23:06:34 --> Router Class Initialized
INFO - 2018-08-06 23:06:34 --> Config Class Initialized
INFO - 2018-08-06 23:06:34 --> Hooks Class Initialized
INFO - 2018-08-06 23:06:34 --> Output Class Initialized
DEBUG - 2018-08-06 23:06:34 --> UTF-8 Support Enabled
INFO - 2018-08-06 23:06:34 --> Utf8 Class Initialized
INFO - 2018-08-06 23:06:34 --> URI Class Initialized
INFO - 2018-08-06 23:06:34 --> Router Class Initialized
INFO - 2018-08-06 23:06:34 --> Output Class Initialized
INFO - 2018-08-06 23:06:34 --> Security Class Initialized
DEBUG - 2018-08-06 23:06:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-06 23:06:34 --> Input Class Initialized
INFO - 2018-08-06 23:06:34 --> Language Class Initialized
INFO - 2018-08-06 23:06:34 --> Security Class Initialized
INFO - 2018-08-06 23:06:34 --> Language Class Initialized
DEBUG - 2018-08-06 23:06:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-06 23:06:34 --> Config Class Initialized
INFO - 2018-08-06 23:06:34 --> Input Class Initialized
INFO - 2018-08-06 23:06:34 --> Loader Class Initialized
INFO - 2018-08-06 23:06:34 --> Language Class Initialized
ERROR - 2018-08-06 23:06:35 --> 404 Page Not Found: /index
DEBUG - 2018-08-06 23:06:35 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-06 23:06:35 --> Helper loaded: url_helper
INFO - 2018-08-06 23:06:35 --> Config Class Initialized
INFO - 2018-08-06 23:06:35 --> Hooks Class Initialized
INFO - 2018-08-06 23:06:35 --> Helper loaded: form_helper
INFO - 2018-08-06 23:06:35 --> Helper loaded: date_helper
DEBUG - 2018-08-06 23:06:35 --> UTF-8 Support Enabled
INFO - 2018-08-06 23:06:35 --> Utf8 Class Initialized
INFO - 2018-08-06 23:06:35 --> Helper loaded: util_helper
INFO - 2018-08-06 23:06:35 --> URI Class Initialized
INFO - 2018-08-06 23:06:35 --> Helper loaded: text_helper
INFO - 2018-08-06 23:06:35 --> Router Class Initialized
INFO - 2018-08-06 23:06:35 --> Helper loaded: string_helper
INFO - 2018-08-06 23:06:35 --> Output Class Initialized
INFO - 2018-08-06 23:06:35 --> Security Class Initialized
INFO - 2018-08-06 23:06:35 --> Database Driver Class Initialized
DEBUG - 2018-08-06 23:06:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-08-06 23:06:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-06 23:06:35 --> Input Class Initialized
INFO - 2018-08-06 23:06:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-06 23:06:35 --> Language Class Initialized
INFO - 2018-08-06 23:06:35 --> Email Class Initialized
ERROR - 2018-08-06 23:06:35 --> 404 Page Not Found: /index
INFO - 2018-08-06 23:06:35 --> Controller Class Initialized
INFO - 2018-08-06 23:06:35 --> Config Class Initialized
INFO - 2018-08-06 23:06:35 --> Hooks Class Initialized
DEBUG - 2018-08-06 23:06:35 --> Home MX_Controller Initialized
DEBUG - 2018-08-06 23:06:35 --> UTF-8 Support Enabled
INFO - 2018-08-06 23:06:35 --> Utf8 Class Initialized
INFO - 2018-08-06 23:06:35 --> URI Class Initialized
INFO - 2018-08-06 23:06:35 --> Router Class Initialized
DEBUG - 2018-08-06 23:06:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-08-06 23:06:35 --> Output Class Initialized
DEBUG - 2018-08-06 23:06:35 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-06 23:06:35 --> Login MX_Controller Initialized
INFO - 2018-08-06 23:06:35 --> Security Class Initialized
INFO - 2018-08-06 23:06:35 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-06 23:06:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-06 23:06:35 --> Input Class Initialized
DEBUG - 2018-08-06 23:06:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-08-06 23:06:35 --> Language Class Initialized
DEBUG - 2018-08-06 23:06:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
ERROR - 2018-08-06 23:06:35 --> 404 Page Not Found: /index
INFO - 2018-08-06 23:06:36 --> Config Class Initialized
INFO - 2018-08-06 23:06:36 --> Hooks Class Initialized
DEBUG - 2018-08-06 23:06:36 --> UTF-8 Support Enabled
INFO - 2018-08-06 23:06:36 --> Utf8 Class Initialized
INFO - 2018-08-06 23:06:36 --> URI Class Initialized
INFO - 2018-08-06 23:06:36 --> Router Class Initialized
INFO - 2018-08-06 23:06:36 --> Output Class Initialized
INFO - 2018-08-06 23:06:36 --> Security Class Initialized
DEBUG - 2018-08-06 23:06:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-06 23:06:36 --> Input Class Initialized
INFO - 2018-08-06 23:06:36 --> Language Class Initialized
INFO - 2018-08-06 23:06:36 --> Language Class Initialized
INFO - 2018-08-06 23:06:36 --> Config Class Initialized
INFO - 2018-08-06 23:06:36 --> Loader Class Initialized
DEBUG - 2018-08-06 23:06:36 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-06 23:06:36 --> Helper loaded: url_helper
INFO - 2018-08-06 23:06:36 --> Helper loaded: form_helper
INFO - 2018-08-06 23:06:36 --> Helper loaded: date_helper
INFO - 2018-08-06 23:06:36 --> Helper loaded: util_helper
INFO - 2018-08-06 23:06:36 --> Helper loaded: text_helper
INFO - 2018-08-06 23:06:36 --> Helper loaded: string_helper
INFO - 2018-08-06 23:06:36 --> Database Driver Class Initialized
DEBUG - 2018-08-06 23:06:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-06 23:06:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-06 23:06:36 --> Email Class Initialized
INFO - 2018-08-06 23:06:36 --> Controller Class Initialized
DEBUG - 2018-08-06 23:06:36 --> Home MX_Controller Initialized
DEBUG - 2018-08-06 23:06:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-06 23:06:36 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-06 23:06:36 --> Login MX_Controller Initialized
INFO - 2018-08-06 23:06:36 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-06 23:06:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-06 23:06:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-06 23:06:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-08-06 23:06:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-08-06 23:06:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-08-06 23:06:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-08-06 23:06:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-08-06 23:06:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-08-06 23:06:36 --> Final output sent to browser
DEBUG - 2018-08-06 23:06:36 --> Total execution time: 0.6130
INFO - 2018-08-06 23:06:36 --> Config Class Initialized
INFO - 2018-08-06 23:06:36 --> Config Class Initialized
INFO - 2018-08-06 23:06:36 --> Hooks Class Initialized
INFO - 2018-08-06 23:06:36 --> Hooks Class Initialized
DEBUG - 2018-08-06 23:06:36 --> UTF-8 Support Enabled
DEBUG - 2018-08-06 23:06:36 --> UTF-8 Support Enabled
INFO - 2018-08-06 23:06:36 --> Utf8 Class Initialized
INFO - 2018-08-06 23:06:36 --> Config Class Initialized
INFO - 2018-08-06 23:06:36 --> Hooks Class Initialized
INFO - 2018-08-06 23:06:36 --> URI Class Initialized
INFO - 2018-08-06 23:06:36 --> Utf8 Class Initialized
INFO - 2018-08-06 23:06:37 --> URI Class Initialized
INFO - 2018-08-06 23:06:37 --> Router Class Initialized
DEBUG - 2018-08-06 23:06:37 --> UTF-8 Support Enabled
INFO - 2018-08-06 23:06:37 --> Router Class Initialized
INFO - 2018-08-06 23:06:37 --> Output Class Initialized
INFO - 2018-08-06 23:06:37 --> Security Class Initialized
DEBUG - 2018-08-06 23:06:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-06 23:06:37 --> Utf8 Class Initialized
INFO - 2018-08-06 23:06:37 --> Input Class Initialized
INFO - 2018-08-06 23:06:37 --> Output Class Initialized
INFO - 2018-08-06 23:06:37 --> URI Class Initialized
INFO - 2018-08-06 23:06:37 --> Router Class Initialized
INFO - 2018-08-06 23:06:37 --> Output Class Initialized
INFO - 2018-08-06 23:06:37 --> Security Class Initialized
DEBUG - 2018-08-06 23:06:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-06 23:06:37 --> Input Class Initialized
INFO - 2018-08-06 23:06:37 --> Language Class Initialized
INFO - 2018-08-06 23:06:37 --> Language Class Initialized
INFO - 2018-08-06 23:06:37 --> Language Class Initialized
INFO - 2018-08-06 23:06:37 --> Security Class Initialized
INFO - 2018-08-06 23:06:37 --> Config Class Initialized
INFO - 2018-08-06 23:06:37 --> Loader Class Initialized
ERROR - 2018-08-06 23:06:37 --> 404 Page Not Found: /index
DEBUG - 2018-08-06 23:06:37 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-06 23:06:37 --> Helper loaded: url_helper
INFO - 2018-08-06 23:06:37 --> Helper loaded: form_helper
INFO - 2018-08-06 23:06:37 --> Helper loaded: date_helper
INFO - 2018-08-06 23:06:37 --> Helper loaded: util_helper
INFO - 2018-08-06 23:06:37 --> Helper loaded: text_helper
INFO - 2018-08-06 23:06:37 --> Helper loaded: string_helper
INFO - 2018-08-06 23:06:37 --> Database Driver Class Initialized
DEBUG - 2018-08-06 23:06:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-06 23:06:37 --> Input Class Initialized
INFO - 2018-08-06 23:06:37 --> Language Class Initialized
ERROR - 2018-08-06 23:06:37 --> 404 Page Not Found: /index
DEBUG - 2018-08-06 23:06:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-06 23:06:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-06 23:06:37 --> Config Class Initialized
INFO - 2018-08-06 23:06:37 --> Hooks Class Initialized
INFO - 2018-08-06 23:06:37 --> Email Class Initialized
INFO - 2018-08-06 23:06:37 --> Controller Class Initialized
DEBUG - 2018-08-06 23:06:37 --> UTF-8 Support Enabled
INFO - 2018-08-06 23:06:37 --> Utf8 Class Initialized
DEBUG - 2018-08-06 23:06:37 --> Home MX_Controller Initialized
INFO - 2018-08-06 23:06:37 --> URI Class Initialized
DEBUG - 2018-08-06 23:06:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-08-06 23:06:37 --> Router Class Initialized
INFO - 2018-08-06 23:06:37 --> Output Class Initialized
DEBUG - 2018-08-06 23:06:37 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-06 23:06:37 --> Login MX_Controller Initialized
INFO - 2018-08-06 23:06:37 --> Security Class Initialized
INFO - 2018-08-06 23:06:37 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-06 23:06:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-06 23:06:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-06 23:06:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-06 23:06:37 --> Input Class Initialized
INFO - 2018-08-06 23:06:37 --> Language Class Initialized
ERROR - 2018-08-06 23:06:37 --> 404 Page Not Found: /index
INFO - 2018-08-06 23:06:37 --> Config Class Initialized
INFO - 2018-08-06 23:06:37 --> Hooks Class Initialized
DEBUG - 2018-08-06 23:06:37 --> UTF-8 Support Enabled
INFO - 2018-08-06 23:06:37 --> Utf8 Class Initialized
INFO - 2018-08-06 23:06:37 --> URI Class Initialized
INFO - 2018-08-06 23:06:37 --> Router Class Initialized
INFO - 2018-08-06 23:06:37 --> Output Class Initialized
INFO - 2018-08-06 23:06:37 --> Security Class Initialized
DEBUG - 2018-08-06 23:06:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-06 23:06:38 --> Input Class Initialized
INFO - 2018-08-06 23:06:38 --> Language Class Initialized
ERROR - 2018-08-06 23:06:38 --> 404 Page Not Found: /index
INFO - 2018-08-06 23:16:29 --> Config Class Initialized
INFO - 2018-08-06 23:16:29 --> Hooks Class Initialized
DEBUG - 2018-08-06 23:16:29 --> UTF-8 Support Enabled
INFO - 2018-08-06 23:16:29 --> Utf8 Class Initialized
INFO - 2018-08-06 23:16:29 --> URI Class Initialized
INFO - 2018-08-06 23:16:29 --> Router Class Initialized
INFO - 2018-08-06 23:16:29 --> Output Class Initialized
INFO - 2018-08-06 23:16:29 --> Security Class Initialized
DEBUG - 2018-08-06 23:16:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-06 23:16:29 --> Input Class Initialized
INFO - 2018-08-06 23:16:29 --> Language Class Initialized
INFO - 2018-08-06 23:16:29 --> Language Class Initialized
INFO - 2018-08-06 23:16:29 --> Config Class Initialized
INFO - 2018-08-06 23:16:29 --> Loader Class Initialized
DEBUG - 2018-08-06 23:16:29 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-06 23:16:29 --> Helper loaded: url_helper
INFO - 2018-08-06 23:16:29 --> Helper loaded: form_helper
INFO - 2018-08-06 23:16:29 --> Helper loaded: date_helper
INFO - 2018-08-06 23:16:29 --> Helper loaded: util_helper
INFO - 2018-08-06 23:16:29 --> Helper loaded: text_helper
INFO - 2018-08-06 23:16:29 --> Helper loaded: string_helper
INFO - 2018-08-06 23:16:29 --> Database Driver Class Initialized
DEBUG - 2018-08-06 23:16:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-06 23:16:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-06 23:16:29 --> Email Class Initialized
INFO - 2018-08-06 23:16:29 --> Controller Class Initialized
DEBUG - 2018-08-06 23:16:29 --> Home MX_Controller Initialized
DEBUG - 2018-08-06 23:16:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-06 23:16:29 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-06 23:16:29 --> Login MX_Controller Initialized
INFO - 2018-08-06 23:16:29 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-06 23:16:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-06 23:16:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-06 23:16:43 --> Config Class Initialized
INFO - 2018-08-06 23:16:43 --> Hooks Class Initialized
DEBUG - 2018-08-06 23:16:43 --> UTF-8 Support Enabled
INFO - 2018-08-06 23:16:43 --> Utf8 Class Initialized
INFO - 2018-08-06 23:16:43 --> URI Class Initialized
INFO - 2018-08-06 23:16:43 --> Router Class Initialized
INFO - 2018-08-06 23:16:43 --> Output Class Initialized
INFO - 2018-08-06 23:16:43 --> Security Class Initialized
DEBUG - 2018-08-06 23:16:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-06 23:16:43 --> Input Class Initialized
INFO - 2018-08-06 23:16:43 --> Language Class Initialized
INFO - 2018-08-06 23:16:43 --> Language Class Initialized
INFO - 2018-08-06 23:16:43 --> Config Class Initialized
INFO - 2018-08-06 23:16:43 --> Loader Class Initialized
DEBUG - 2018-08-06 23:16:43 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-06 23:16:43 --> Helper loaded: url_helper
INFO - 2018-08-06 23:16:43 --> Helper loaded: form_helper
INFO - 2018-08-06 23:16:43 --> Helper loaded: date_helper
INFO - 2018-08-06 23:16:43 --> Helper loaded: util_helper
INFO - 2018-08-06 23:16:43 --> Helper loaded: text_helper
INFO - 2018-08-06 23:16:43 --> Helper loaded: string_helper
INFO - 2018-08-06 23:16:43 --> Database Driver Class Initialized
DEBUG - 2018-08-06 23:16:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-06 23:16:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-06 23:16:43 --> Email Class Initialized
INFO - 2018-08-06 23:16:43 --> Controller Class Initialized
DEBUG - 2018-08-06 23:16:43 --> Home MX_Controller Initialized
DEBUG - 2018-08-06 23:16:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-06 23:16:43 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-06 23:16:43 --> Login MX_Controller Initialized
INFO - 2018-08-06 23:16:43 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-06 23:16:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-06 23:16:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-06 23:18:28 --> Config Class Initialized
INFO - 2018-08-06 23:18:28 --> Hooks Class Initialized
DEBUG - 2018-08-06 23:18:28 --> UTF-8 Support Enabled
INFO - 2018-08-06 23:18:28 --> Utf8 Class Initialized
INFO - 2018-08-06 23:18:28 --> URI Class Initialized
INFO - 2018-08-06 23:18:29 --> Router Class Initialized
INFO - 2018-08-06 23:18:29 --> Output Class Initialized
INFO - 2018-08-06 23:18:29 --> Security Class Initialized
DEBUG - 2018-08-06 23:18:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-06 23:18:29 --> Input Class Initialized
INFO - 2018-08-06 23:18:29 --> Language Class Initialized
INFO - 2018-08-06 23:18:29 --> Language Class Initialized
INFO - 2018-08-06 23:18:29 --> Config Class Initialized
INFO - 2018-08-06 23:18:29 --> Loader Class Initialized
DEBUG - 2018-08-06 23:18:29 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-06 23:18:29 --> Helper loaded: url_helper
INFO - 2018-08-06 23:18:29 --> Helper loaded: form_helper
INFO - 2018-08-06 23:18:29 --> Helper loaded: date_helper
INFO - 2018-08-06 23:18:29 --> Helper loaded: util_helper
INFO - 2018-08-06 23:18:29 --> Helper loaded: text_helper
INFO - 2018-08-06 23:18:29 --> Helper loaded: string_helper
INFO - 2018-08-06 23:18:29 --> Database Driver Class Initialized
DEBUG - 2018-08-06 23:18:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-06 23:18:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-06 23:18:29 --> Email Class Initialized
INFO - 2018-08-06 23:18:29 --> Controller Class Initialized
DEBUG - 2018-08-06 23:18:29 --> Home MX_Controller Initialized
DEBUG - 2018-08-06 23:18:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-06 23:18:29 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-06 23:18:29 --> Login MX_Controller Initialized
INFO - 2018-08-06 23:18:29 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-06 23:18:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-06 23:18:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-06 23:19:07 --> Config Class Initialized
INFO - 2018-08-06 23:19:07 --> Hooks Class Initialized
DEBUG - 2018-08-06 23:19:07 --> UTF-8 Support Enabled
INFO - 2018-08-06 23:19:07 --> Utf8 Class Initialized
INFO - 2018-08-06 23:19:07 --> URI Class Initialized
INFO - 2018-08-06 23:19:07 --> Router Class Initialized
INFO - 2018-08-06 23:19:07 --> Output Class Initialized
INFO - 2018-08-06 23:19:07 --> Security Class Initialized
DEBUG - 2018-08-06 23:19:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-06 23:19:07 --> Input Class Initialized
INFO - 2018-08-06 23:19:07 --> Language Class Initialized
INFO - 2018-08-06 23:19:07 --> Language Class Initialized
INFO - 2018-08-06 23:19:07 --> Config Class Initialized
INFO - 2018-08-06 23:19:07 --> Loader Class Initialized
DEBUG - 2018-08-06 23:19:07 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-06 23:19:07 --> Helper loaded: url_helper
INFO - 2018-08-06 23:19:07 --> Helper loaded: form_helper
INFO - 2018-08-06 23:19:07 --> Helper loaded: date_helper
INFO - 2018-08-06 23:19:07 --> Helper loaded: util_helper
INFO - 2018-08-06 23:19:07 --> Helper loaded: text_helper
INFO - 2018-08-06 23:19:07 --> Helper loaded: string_helper
INFO - 2018-08-06 23:19:07 --> Database Driver Class Initialized
DEBUG - 2018-08-06 23:19:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-06 23:19:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-06 23:19:07 --> Email Class Initialized
INFO - 2018-08-06 23:19:07 --> Controller Class Initialized
DEBUG - 2018-08-06 23:19:07 --> Home MX_Controller Initialized
DEBUG - 2018-08-06 23:19:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-06 23:19:08 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-06 23:19:08 --> Login MX_Controller Initialized
INFO - 2018-08-06 23:19:08 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-06 23:19:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-06 23:19:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
ERROR - 2018-08-06 23:19:08 --> Severity: error --> Exception: Cannot use object of type mysqli as array E:\xampp\htdocs\consulting\application\modules\home\controllers\Home.php 228
INFO - 2018-08-06 23:19:22 --> Config Class Initialized
INFO - 2018-08-06 23:19:22 --> Hooks Class Initialized
DEBUG - 2018-08-06 23:19:22 --> UTF-8 Support Enabled
INFO - 2018-08-06 23:19:22 --> Utf8 Class Initialized
INFO - 2018-08-06 23:19:22 --> URI Class Initialized
INFO - 2018-08-06 23:19:22 --> Router Class Initialized
INFO - 2018-08-06 23:19:22 --> Output Class Initialized
INFO - 2018-08-06 23:19:22 --> Security Class Initialized
DEBUG - 2018-08-06 23:19:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-06 23:19:22 --> Input Class Initialized
INFO - 2018-08-06 23:19:22 --> Language Class Initialized
INFO - 2018-08-06 23:19:22 --> Language Class Initialized
INFO - 2018-08-06 23:19:22 --> Config Class Initialized
INFO - 2018-08-06 23:19:22 --> Loader Class Initialized
DEBUG - 2018-08-06 23:19:22 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-06 23:19:22 --> Helper loaded: url_helper
INFO - 2018-08-06 23:19:22 --> Helper loaded: form_helper
INFO - 2018-08-06 23:19:22 --> Helper loaded: date_helper
INFO - 2018-08-06 23:19:22 --> Helper loaded: util_helper
INFO - 2018-08-06 23:19:22 --> Helper loaded: text_helper
INFO - 2018-08-06 23:19:22 --> Helper loaded: string_helper
INFO - 2018-08-06 23:19:22 --> Database Driver Class Initialized
DEBUG - 2018-08-06 23:19:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-06 23:19:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-06 23:19:22 --> Email Class Initialized
INFO - 2018-08-06 23:19:22 --> Controller Class Initialized
DEBUG - 2018-08-06 23:19:22 --> Home MX_Controller Initialized
DEBUG - 2018-08-06 23:19:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-06 23:19:22 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-06 23:19:22 --> Login MX_Controller Initialized
INFO - 2018-08-06 23:19:22 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-06 23:19:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-06 23:19:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-06 23:23:03 --> Config Class Initialized
INFO - 2018-08-06 23:23:03 --> Hooks Class Initialized
DEBUG - 2018-08-06 23:23:03 --> UTF-8 Support Enabled
INFO - 2018-08-06 23:23:03 --> Utf8 Class Initialized
INFO - 2018-08-06 23:23:03 --> URI Class Initialized
INFO - 2018-08-06 23:23:03 --> Router Class Initialized
INFO - 2018-08-06 23:23:03 --> Output Class Initialized
INFO - 2018-08-06 23:23:03 --> Security Class Initialized
DEBUG - 2018-08-06 23:23:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-06 23:23:03 --> Input Class Initialized
INFO - 2018-08-06 23:23:03 --> Language Class Initialized
INFO - 2018-08-06 23:23:03 --> Language Class Initialized
INFO - 2018-08-06 23:23:03 --> Config Class Initialized
INFO - 2018-08-06 23:23:03 --> Loader Class Initialized
DEBUG - 2018-08-06 23:23:03 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-06 23:23:03 --> Helper loaded: url_helper
INFO - 2018-08-06 23:23:03 --> Helper loaded: form_helper
INFO - 2018-08-06 23:23:03 --> Helper loaded: date_helper
INFO - 2018-08-06 23:23:03 --> Helper loaded: util_helper
INFO - 2018-08-06 23:23:03 --> Helper loaded: text_helper
INFO - 2018-08-06 23:23:03 --> Helper loaded: string_helper
INFO - 2018-08-06 23:23:03 --> Database Driver Class Initialized
DEBUG - 2018-08-06 23:23:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-06 23:23:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-06 23:23:03 --> Email Class Initialized
INFO - 2018-08-06 23:23:03 --> Controller Class Initialized
DEBUG - 2018-08-06 23:23:03 --> Home MX_Controller Initialized
DEBUG - 2018-08-06 23:23:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-06 23:23:03 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-06 23:23:03 --> Login MX_Controller Initialized
INFO - 2018-08-06 23:23:03 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-06 23:23:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-06 23:23:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-06 23:23:26 --> Config Class Initialized
INFO - 2018-08-06 23:23:26 --> Hooks Class Initialized
DEBUG - 2018-08-06 23:23:27 --> UTF-8 Support Enabled
INFO - 2018-08-06 23:23:27 --> Utf8 Class Initialized
INFO - 2018-08-06 23:23:27 --> URI Class Initialized
INFO - 2018-08-06 23:23:27 --> Router Class Initialized
INFO - 2018-08-06 23:23:27 --> Output Class Initialized
INFO - 2018-08-06 23:23:27 --> Security Class Initialized
DEBUG - 2018-08-06 23:23:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-06 23:23:27 --> Input Class Initialized
INFO - 2018-08-06 23:23:27 --> Language Class Initialized
INFO - 2018-08-06 23:23:27 --> Language Class Initialized
INFO - 2018-08-06 23:23:27 --> Config Class Initialized
INFO - 2018-08-06 23:23:27 --> Loader Class Initialized
DEBUG - 2018-08-06 23:23:27 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-06 23:23:27 --> Helper loaded: url_helper
INFO - 2018-08-06 23:23:27 --> Helper loaded: form_helper
INFO - 2018-08-06 23:23:27 --> Helper loaded: date_helper
INFO - 2018-08-06 23:23:27 --> Helper loaded: util_helper
INFO - 2018-08-06 23:23:27 --> Helper loaded: text_helper
INFO - 2018-08-06 23:23:27 --> Helper loaded: string_helper
INFO - 2018-08-06 23:23:27 --> Database Driver Class Initialized
DEBUG - 2018-08-06 23:23:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-06 23:23:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-06 23:23:27 --> Email Class Initialized
INFO - 2018-08-06 23:23:27 --> Controller Class Initialized
DEBUG - 2018-08-06 23:23:27 --> Home MX_Controller Initialized
DEBUG - 2018-08-06 23:23:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-06 23:23:27 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-06 23:23:27 --> Login MX_Controller Initialized
INFO - 2018-08-06 23:23:27 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-06 23:23:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-06 23:23:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-06 23:25:01 --> Config Class Initialized
INFO - 2018-08-06 23:25:01 --> Hooks Class Initialized
DEBUG - 2018-08-06 23:25:01 --> UTF-8 Support Enabled
INFO - 2018-08-06 23:25:01 --> Utf8 Class Initialized
INFO - 2018-08-06 23:25:01 --> URI Class Initialized
INFO - 2018-08-06 23:25:01 --> Router Class Initialized
INFO - 2018-08-06 23:25:01 --> Output Class Initialized
INFO - 2018-08-06 23:25:01 --> Security Class Initialized
DEBUG - 2018-08-06 23:25:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-06 23:25:01 --> Input Class Initialized
INFO - 2018-08-06 23:25:01 --> Language Class Initialized
INFO - 2018-08-06 23:25:01 --> Language Class Initialized
INFO - 2018-08-06 23:25:01 --> Config Class Initialized
INFO - 2018-08-06 23:25:01 --> Loader Class Initialized
DEBUG - 2018-08-06 23:25:01 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-06 23:25:01 --> Helper loaded: url_helper
INFO - 2018-08-06 23:25:01 --> Helper loaded: form_helper
INFO - 2018-08-06 23:25:02 --> Helper loaded: date_helper
INFO - 2018-08-06 23:25:02 --> Helper loaded: util_helper
INFO - 2018-08-06 23:25:02 --> Helper loaded: text_helper
INFO - 2018-08-06 23:25:02 --> Helper loaded: string_helper
INFO - 2018-08-06 23:25:02 --> Database Driver Class Initialized
DEBUG - 2018-08-06 23:25:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-06 23:25:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-06 23:25:02 --> Email Class Initialized
INFO - 2018-08-06 23:25:02 --> Controller Class Initialized
DEBUG - 2018-08-06 23:25:02 --> Home MX_Controller Initialized
DEBUG - 2018-08-06 23:25:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-06 23:25:02 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-06 23:25:02 --> Login MX_Controller Initialized
INFO - 2018-08-06 23:25:02 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-06 23:25:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-06 23:25:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-06 23:25:23 --> Config Class Initialized
INFO - 2018-08-06 23:25:23 --> Hooks Class Initialized
DEBUG - 2018-08-06 23:25:23 --> UTF-8 Support Enabled
INFO - 2018-08-06 23:25:23 --> Utf8 Class Initialized
INFO - 2018-08-06 23:25:23 --> URI Class Initialized
INFO - 2018-08-06 23:25:23 --> Router Class Initialized
INFO - 2018-08-06 23:25:23 --> Output Class Initialized
INFO - 2018-08-06 23:25:23 --> Security Class Initialized
DEBUG - 2018-08-06 23:25:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-06 23:25:23 --> Input Class Initialized
INFO - 2018-08-06 23:25:23 --> Language Class Initialized
INFO - 2018-08-06 23:25:23 --> Language Class Initialized
INFO - 2018-08-06 23:25:23 --> Config Class Initialized
INFO - 2018-08-06 23:25:23 --> Loader Class Initialized
DEBUG - 2018-08-06 23:25:23 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-06 23:25:23 --> Helper loaded: url_helper
INFO - 2018-08-06 23:25:23 --> Helper loaded: form_helper
INFO - 2018-08-06 23:25:23 --> Helper loaded: date_helper
INFO - 2018-08-06 23:25:23 --> Helper loaded: util_helper
INFO - 2018-08-06 23:25:24 --> Helper loaded: text_helper
INFO - 2018-08-06 23:25:24 --> Helper loaded: string_helper
INFO - 2018-08-06 23:25:24 --> Database Driver Class Initialized
DEBUG - 2018-08-06 23:25:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-06 23:25:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-06 23:25:24 --> Email Class Initialized
INFO - 2018-08-06 23:25:24 --> Controller Class Initialized
DEBUG - 2018-08-06 23:25:24 --> Home MX_Controller Initialized
DEBUG - 2018-08-06 23:25:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-06 23:25:24 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-06 23:25:24 --> Login MX_Controller Initialized
INFO - 2018-08-06 23:25:24 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-06 23:25:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-06 23:25:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-06 23:28:16 --> Config Class Initialized
INFO - 2018-08-06 23:28:16 --> Hooks Class Initialized
DEBUG - 2018-08-06 23:28:16 --> UTF-8 Support Enabled
INFO - 2018-08-06 23:28:16 --> Utf8 Class Initialized
INFO - 2018-08-06 23:28:16 --> URI Class Initialized
INFO - 2018-08-06 23:28:16 --> Router Class Initialized
INFO - 2018-08-06 23:28:16 --> Output Class Initialized
INFO - 2018-08-06 23:28:16 --> Security Class Initialized
DEBUG - 2018-08-06 23:28:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-06 23:28:16 --> Input Class Initialized
INFO - 2018-08-06 23:28:16 --> Language Class Initialized
INFO - 2018-08-06 23:28:16 --> Language Class Initialized
INFO - 2018-08-06 23:28:16 --> Config Class Initialized
INFO - 2018-08-06 23:28:16 --> Loader Class Initialized
DEBUG - 2018-08-06 23:28:16 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-06 23:28:16 --> Helper loaded: url_helper
INFO - 2018-08-06 23:28:16 --> Helper loaded: form_helper
INFO - 2018-08-06 23:28:16 --> Helper loaded: date_helper
INFO - 2018-08-06 23:28:16 --> Helper loaded: util_helper
INFO - 2018-08-06 23:28:16 --> Helper loaded: text_helper
INFO - 2018-08-06 23:28:16 --> Helper loaded: string_helper
INFO - 2018-08-06 23:28:16 --> Database Driver Class Initialized
DEBUG - 2018-08-06 23:28:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-06 23:28:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-06 23:28:17 --> Email Class Initialized
INFO - 2018-08-06 23:28:17 --> Controller Class Initialized
DEBUG - 2018-08-06 23:28:17 --> Home MX_Controller Initialized
DEBUG - 2018-08-06 23:28:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-06 23:28:17 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-06 23:28:17 --> Login MX_Controller Initialized
INFO - 2018-08-06 23:28:17 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-06 23:28:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-06 23:28:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-06 23:28:26 --> Config Class Initialized
INFO - 2018-08-06 23:28:26 --> Hooks Class Initialized
DEBUG - 2018-08-06 23:28:26 --> UTF-8 Support Enabled
INFO - 2018-08-06 23:28:26 --> Utf8 Class Initialized
INFO - 2018-08-06 23:28:26 --> URI Class Initialized
INFO - 2018-08-06 23:28:26 --> Router Class Initialized
INFO - 2018-08-06 23:28:26 --> Output Class Initialized
INFO - 2018-08-06 23:28:26 --> Security Class Initialized
DEBUG - 2018-08-06 23:28:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-06 23:28:26 --> Input Class Initialized
INFO - 2018-08-06 23:28:26 --> Language Class Initialized
INFO - 2018-08-06 23:28:26 --> Language Class Initialized
INFO - 2018-08-06 23:28:26 --> Config Class Initialized
INFO - 2018-08-06 23:28:26 --> Loader Class Initialized
DEBUG - 2018-08-06 23:28:26 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-06 23:28:26 --> Helper loaded: url_helper
INFO - 2018-08-06 23:28:26 --> Helper loaded: form_helper
INFO - 2018-08-06 23:28:26 --> Helper loaded: date_helper
INFO - 2018-08-06 23:28:26 --> Helper loaded: util_helper
INFO - 2018-08-06 23:28:26 --> Helper loaded: text_helper
INFO - 2018-08-06 23:28:26 --> Helper loaded: string_helper
INFO - 2018-08-06 23:28:26 --> Database Driver Class Initialized
DEBUG - 2018-08-06 23:28:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-06 23:28:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-06 23:28:26 --> Email Class Initialized
INFO - 2018-08-06 23:28:26 --> Controller Class Initialized
DEBUG - 2018-08-06 23:28:26 --> Home MX_Controller Initialized
DEBUG - 2018-08-06 23:28:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-06 23:28:26 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-06 23:28:26 --> Login MX_Controller Initialized
INFO - 2018-08-06 23:28:26 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-06 23:28:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-06 23:28:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-06 23:28:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-08-06 23:28:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-08-06 23:28:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-08-06 23:28:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-08-06 23:28:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-08-06 23:28:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/search_page.php
INFO - 2018-08-06 23:28:26 --> Final output sent to browser
DEBUG - 2018-08-06 23:28:26 --> Total execution time: 0.4807
INFO - 2018-08-06 23:28:27 --> Config Class Initialized
INFO - 2018-08-06 23:28:27 --> Hooks Class Initialized
INFO - 2018-08-06 23:28:27 --> Config Class Initialized
INFO - 2018-08-06 23:28:27 --> Hooks Class Initialized
DEBUG - 2018-08-06 23:28:27 --> UTF-8 Support Enabled
INFO - 2018-08-06 23:28:27 --> Utf8 Class Initialized
DEBUG - 2018-08-06 23:28:27 --> UTF-8 Support Enabled
INFO - 2018-08-06 23:28:27 --> Utf8 Class Initialized
INFO - 2018-08-06 23:28:27 --> URI Class Initialized
INFO - 2018-08-06 23:28:27 --> URI Class Initialized
INFO - 2018-08-06 23:28:27 --> Router Class Initialized
INFO - 2018-08-06 23:28:27 --> Output Class Initialized
INFO - 2018-08-06 23:28:27 --> Security Class Initialized
DEBUG - 2018-08-06 23:28:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-06 23:28:27 --> Input Class Initialized
INFO - 2018-08-06 23:28:27 --> Language Class Initialized
INFO - 2018-08-06 23:28:27 --> Router Class Initialized
INFO - 2018-08-06 23:28:27 --> Language Class Initialized
INFO - 2018-08-06 23:28:27 --> Config Class Initialized
INFO - 2018-08-06 23:28:27 --> Output Class Initialized
INFO - 2018-08-06 23:28:27 --> Loader Class Initialized
INFO - 2018-08-06 23:28:27 --> Security Class Initialized
DEBUG - 2018-08-06 23:28:27 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
DEBUG - 2018-08-06 23:28:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-06 23:28:27 --> Helper loaded: url_helper
INFO - 2018-08-06 23:28:27 --> Input Class Initialized
INFO - 2018-08-06 23:28:27 --> Helper loaded: form_helper
INFO - 2018-08-06 23:28:27 --> Language Class Initialized
ERROR - 2018-08-06 23:28:27 --> 404 Page Not Found: /index
INFO - 2018-08-06 23:28:27 --> Helper loaded: date_helper
INFO - 2018-08-06 23:28:27 --> Helper loaded: util_helper
INFO - 2018-08-06 23:28:27 --> Config Class Initialized
INFO - 2018-08-06 23:28:27 --> Hooks Class Initialized
INFO - 2018-08-06 23:28:27 --> Helper loaded: text_helper
DEBUG - 2018-08-06 23:28:27 --> UTF-8 Support Enabled
INFO - 2018-08-06 23:28:27 --> Utf8 Class Initialized
INFO - 2018-08-06 23:28:27 --> Helper loaded: string_helper
INFO - 2018-08-06 23:28:27 --> URI Class Initialized
INFO - 2018-08-06 23:28:27 --> Database Driver Class Initialized
INFO - 2018-08-06 23:28:27 --> Router Class Initialized
DEBUG - 2018-08-06 23:28:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-06 23:28:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-06 23:28:27 --> Output Class Initialized
INFO - 2018-08-06 23:28:27 --> Security Class Initialized
INFO - 2018-08-06 23:28:27 --> Email Class Initialized
INFO - 2018-08-06 23:28:27 --> Controller Class Initialized
DEBUG - 2018-08-06 23:28:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-08-06 23:28:27 --> Home MX_Controller Initialized
INFO - 2018-08-06 23:28:27 --> Input Class Initialized
INFO - 2018-08-06 23:28:27 --> Language Class Initialized
DEBUG - 2018-08-06 23:28:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
ERROR - 2018-08-06 23:28:27 --> 404 Page Not Found: /index
DEBUG - 2018-08-06 23:28:27 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-06 23:28:27 --> Login MX_Controller Initialized
INFO - 2018-08-06 23:28:27 --> Config Class Initialized
INFO - 2018-08-06 23:28:27 --> Hooks Class Initialized
INFO - 2018-08-06 23:28:27 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-06 23:28:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-06 23:28:27 --> UTF-8 Support Enabled
INFO - 2018-08-06 23:28:27 --> Utf8 Class Initialized
DEBUG - 2018-08-06 23:28:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-06 23:28:27 --> URI Class Initialized
INFO - 2018-08-06 23:28:27 --> Router Class Initialized
INFO - 2018-08-06 23:28:27 --> Output Class Initialized
INFO - 2018-08-06 23:28:27 --> Security Class Initialized
DEBUG - 2018-08-06 23:28:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-06 23:28:27 --> Input Class Initialized
INFO - 2018-08-06 23:28:27 --> Language Class Initialized
ERROR - 2018-08-06 23:28:27 --> 404 Page Not Found: /index
INFO - 2018-08-06 23:28:27 --> Config Class Initialized
INFO - 2018-08-06 23:28:27 --> Hooks Class Initialized
DEBUG - 2018-08-06 23:28:27 --> UTF-8 Support Enabled
INFO - 2018-08-06 23:28:27 --> Utf8 Class Initialized
INFO - 2018-08-06 23:28:27 --> URI Class Initialized
INFO - 2018-08-06 23:28:27 --> Router Class Initialized
INFO - 2018-08-06 23:28:27 --> Output Class Initialized
INFO - 2018-08-06 23:28:27 --> Security Class Initialized
DEBUG - 2018-08-06 23:28:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-06 23:28:27 --> Input Class Initialized
INFO - 2018-08-06 23:28:27 --> Language Class Initialized
ERROR - 2018-08-06 23:28:27 --> 404 Page Not Found: /index
INFO - 2018-08-06 23:28:27 --> Config Class Initialized
INFO - 2018-08-06 23:28:27 --> Hooks Class Initialized
DEBUG - 2018-08-06 23:28:27 --> UTF-8 Support Enabled
INFO - 2018-08-06 23:28:27 --> Utf8 Class Initialized
INFO - 2018-08-06 23:28:27 --> URI Class Initialized
INFO - 2018-08-06 23:28:27 --> Router Class Initialized
INFO - 2018-08-06 23:28:27 --> Output Class Initialized
INFO - 2018-08-06 23:28:27 --> Security Class Initialized
DEBUG - 2018-08-06 23:28:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-06 23:28:27 --> Input Class Initialized
INFO - 2018-08-06 23:28:27 --> Language Class Initialized
ERROR - 2018-08-06 23:28:28 --> 404 Page Not Found: /index
INFO - 2018-08-06 23:28:28 --> Config Class Initialized
INFO - 2018-08-06 23:28:28 --> Hooks Class Initialized
DEBUG - 2018-08-06 23:28:28 --> UTF-8 Support Enabled
INFO - 2018-08-06 23:28:28 --> Utf8 Class Initialized
INFO - 2018-08-06 23:28:28 --> URI Class Initialized
INFO - 2018-08-06 23:28:28 --> Router Class Initialized
INFO - 2018-08-06 23:28:28 --> Output Class Initialized
INFO - 2018-08-06 23:28:28 --> Security Class Initialized
DEBUG - 2018-08-06 23:28:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-06 23:28:28 --> Input Class Initialized
INFO - 2018-08-06 23:28:28 --> Language Class Initialized
ERROR - 2018-08-06 23:28:28 --> 404 Page Not Found: /index
INFO - 2018-08-06 23:30:21 --> Config Class Initialized
INFO - 2018-08-06 23:30:21 --> Hooks Class Initialized
DEBUG - 2018-08-06 23:30:21 --> UTF-8 Support Enabled
INFO - 2018-08-06 23:30:21 --> Utf8 Class Initialized
INFO - 2018-08-06 23:30:21 --> URI Class Initialized
INFO - 2018-08-06 23:30:21 --> Router Class Initialized
INFO - 2018-08-06 23:30:21 --> Output Class Initialized
INFO - 2018-08-06 23:30:21 --> Security Class Initialized
DEBUG - 2018-08-06 23:30:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-06 23:30:21 --> Input Class Initialized
INFO - 2018-08-06 23:30:21 --> Language Class Initialized
INFO - 2018-08-06 23:30:21 --> Language Class Initialized
INFO - 2018-08-06 23:30:21 --> Config Class Initialized
INFO - 2018-08-06 23:30:21 --> Loader Class Initialized
DEBUG - 2018-08-06 23:30:21 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-06 23:30:21 --> Helper loaded: url_helper
INFO - 2018-08-06 23:30:22 --> Helper loaded: form_helper
INFO - 2018-08-06 23:30:22 --> Helper loaded: date_helper
INFO - 2018-08-06 23:30:22 --> Helper loaded: util_helper
INFO - 2018-08-06 23:30:22 --> Helper loaded: text_helper
INFO - 2018-08-06 23:30:22 --> Helper loaded: string_helper
INFO - 2018-08-06 23:30:22 --> Database Driver Class Initialized
DEBUG - 2018-08-06 23:30:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-06 23:30:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-06 23:30:22 --> Email Class Initialized
INFO - 2018-08-06 23:30:22 --> Controller Class Initialized
DEBUG - 2018-08-06 23:30:22 --> Home MX_Controller Initialized
DEBUG - 2018-08-06 23:30:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-06 23:30:22 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-06 23:30:22 --> Login MX_Controller Initialized
INFO - 2018-08-06 23:30:22 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-06 23:30:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-06 23:30:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-06 23:30:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-08-06 23:30:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-08-06 23:30:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
ERROR - 2018-08-06 23:30:22 --> Severity: Notice --> Undefined index: chapter_name E:\xampp\htdocs\consulting\application\modules\home\views\search_page.php 109
ERROR - 2018-08-06 23:30:22 --> Severity: Notice --> Undefined index: chapter_name E:\xampp\htdocs\consulting\application\modules\home\views\search_page.php 109
ERROR - 2018-08-06 23:30:22 --> Severity: Notice --> Undefined index: chapter_name E:\xampp\htdocs\consulting\application\modules\home\views\search_page.php 109
DEBUG - 2018-08-06 23:30:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-08-06 23:30:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-08-06 23:30:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/search_page.php
INFO - 2018-08-06 23:30:22 --> Final output sent to browser
DEBUG - 2018-08-06 23:30:22 --> Total execution time: 0.5306
INFO - 2018-08-06 23:30:22 --> Config Class Initialized
INFO - 2018-08-06 23:30:22 --> Hooks Class Initialized
DEBUG - 2018-08-06 23:30:22 --> UTF-8 Support Enabled
INFO - 2018-08-06 23:30:22 --> Config Class Initialized
INFO - 2018-08-06 23:30:22 --> Utf8 Class Initialized
INFO - 2018-08-06 23:30:22 --> Hooks Class Initialized
DEBUG - 2018-08-06 23:30:22 --> UTF-8 Support Enabled
INFO - 2018-08-06 23:30:22 --> URI Class Initialized
INFO - 2018-08-06 23:30:22 --> Utf8 Class Initialized
INFO - 2018-08-06 23:30:22 --> Router Class Initialized
INFO - 2018-08-06 23:30:22 --> URI Class Initialized
INFO - 2018-08-06 23:30:22 --> Output Class Initialized
INFO - 2018-08-06 23:30:22 --> Router Class Initialized
INFO - 2018-08-06 23:30:22 --> Security Class Initialized
DEBUG - 2018-08-06 23:30:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-06 23:30:22 --> Output Class Initialized
INFO - 2018-08-06 23:30:22 --> Input Class Initialized
INFO - 2018-08-06 23:30:22 --> Language Class Initialized
ERROR - 2018-08-06 23:30:22 --> 404 Page Not Found: /index
INFO - 2018-08-06 23:30:22 --> Security Class Initialized
DEBUG - 2018-08-06 23:30:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-06 23:30:22 --> Config Class Initialized
INFO - 2018-08-06 23:30:22 --> Hooks Class Initialized
INFO - 2018-08-06 23:30:22 --> Input Class Initialized
INFO - 2018-08-06 23:30:22 --> Language Class Initialized
DEBUG - 2018-08-06 23:30:22 --> UTF-8 Support Enabled
INFO - 2018-08-06 23:30:22 --> Utf8 Class Initialized
INFO - 2018-08-06 23:30:22 --> Language Class Initialized
INFO - 2018-08-06 23:30:22 --> Config Class Initialized
INFO - 2018-08-06 23:30:22 --> URI Class Initialized
INFO - 2018-08-06 23:30:22 --> Router Class Initialized
INFO - 2018-08-06 23:30:22 --> Loader Class Initialized
DEBUG - 2018-08-06 23:30:22 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-06 23:30:22 --> Output Class Initialized
INFO - 2018-08-06 23:30:22 --> Security Class Initialized
INFO - 2018-08-06 23:30:22 --> Helper loaded: url_helper
DEBUG - 2018-08-06 23:30:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-06 23:30:22 --> Helper loaded: form_helper
INFO - 2018-08-06 23:30:22 --> Input Class Initialized
INFO - 2018-08-06 23:30:23 --> Language Class Initialized
INFO - 2018-08-06 23:30:23 --> Helper loaded: date_helper
INFO - 2018-08-06 23:30:23 --> Helper loaded: util_helper
ERROR - 2018-08-06 23:30:23 --> 404 Page Not Found: /index
INFO - 2018-08-06 23:30:23 --> Helper loaded: text_helper
INFO - 2018-08-06 23:30:23 --> Config Class Initialized
INFO - 2018-08-06 23:30:23 --> Hooks Class Initialized
INFO - 2018-08-06 23:30:23 --> Helper loaded: string_helper
DEBUG - 2018-08-06 23:30:23 --> UTF-8 Support Enabled
INFO - 2018-08-06 23:30:23 --> Database Driver Class Initialized
INFO - 2018-08-06 23:30:23 --> Utf8 Class Initialized
INFO - 2018-08-06 23:30:23 --> URI Class Initialized
INFO - 2018-08-06 23:30:23 --> Router Class Initialized
INFO - 2018-08-06 23:30:23 --> Output Class Initialized
INFO - 2018-08-06 23:30:23 --> Security Class Initialized
DEBUG - 2018-08-06 23:30:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-06 23:30:23 --> Input Class Initialized
INFO - 2018-08-06 23:30:23 --> Language Class Initialized
ERROR - 2018-08-06 23:30:23 --> 404 Page Not Found: /index
DEBUG - 2018-08-06 23:30:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-06 23:30:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-06 23:30:23 --> Email Class Initialized
INFO - 2018-08-06 23:30:23 --> Controller Class Initialized
DEBUG - 2018-08-06 23:30:23 --> Home MX_Controller Initialized
DEBUG - 2018-08-06 23:30:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-06 23:30:23 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-06 23:30:23 --> Login MX_Controller Initialized
INFO - 2018-08-06 23:30:23 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-06 23:30:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-06 23:30:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-06 23:31:08 --> Config Class Initialized
INFO - 2018-08-06 23:31:08 --> Hooks Class Initialized
DEBUG - 2018-08-06 23:31:08 --> UTF-8 Support Enabled
INFO - 2018-08-06 23:31:08 --> Utf8 Class Initialized
INFO - 2018-08-06 23:31:08 --> URI Class Initialized
INFO - 2018-08-06 23:31:08 --> Router Class Initialized
INFO - 2018-08-06 23:31:08 --> Output Class Initialized
INFO - 2018-08-06 23:31:08 --> Security Class Initialized
DEBUG - 2018-08-06 23:31:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-06 23:31:08 --> Input Class Initialized
INFO - 2018-08-06 23:31:08 --> Language Class Initialized
INFO - 2018-08-06 23:31:08 --> Language Class Initialized
INFO - 2018-08-06 23:31:08 --> Config Class Initialized
INFO - 2018-08-06 23:31:08 --> Loader Class Initialized
DEBUG - 2018-08-06 23:31:08 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-06 23:31:08 --> Helper loaded: url_helper
INFO - 2018-08-06 23:31:08 --> Helper loaded: form_helper
INFO - 2018-08-06 23:31:08 --> Helper loaded: date_helper
INFO - 2018-08-06 23:31:08 --> Helper loaded: util_helper
INFO - 2018-08-06 23:31:08 --> Helper loaded: text_helper
INFO - 2018-08-06 23:31:08 --> Helper loaded: string_helper
INFO - 2018-08-06 23:31:08 --> Database Driver Class Initialized
DEBUG - 2018-08-06 23:31:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-06 23:31:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-06 23:31:08 --> Email Class Initialized
INFO - 2018-08-06 23:31:08 --> Controller Class Initialized
DEBUG - 2018-08-06 23:31:08 --> Home MX_Controller Initialized
DEBUG - 2018-08-06 23:31:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-06 23:31:08 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-06 23:31:08 --> Login MX_Controller Initialized
INFO - 2018-08-06 23:31:08 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-06 23:31:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-06 23:31:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-06 23:33:29 --> Config Class Initialized
INFO - 2018-08-06 23:33:29 --> Hooks Class Initialized
DEBUG - 2018-08-06 23:33:29 --> UTF-8 Support Enabled
INFO - 2018-08-06 23:33:29 --> Utf8 Class Initialized
INFO - 2018-08-06 23:33:29 --> URI Class Initialized
INFO - 2018-08-06 23:33:29 --> Router Class Initialized
INFO - 2018-08-06 23:33:29 --> Output Class Initialized
INFO - 2018-08-06 23:33:29 --> Security Class Initialized
DEBUG - 2018-08-06 23:33:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-06 23:33:29 --> Input Class Initialized
INFO - 2018-08-06 23:33:29 --> Language Class Initialized
INFO - 2018-08-06 23:33:29 --> Language Class Initialized
INFO - 2018-08-06 23:33:29 --> Config Class Initialized
INFO - 2018-08-06 23:33:29 --> Loader Class Initialized
DEBUG - 2018-08-06 23:33:29 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-06 23:33:29 --> Helper loaded: url_helper
INFO - 2018-08-06 23:33:29 --> Helper loaded: form_helper
INFO - 2018-08-06 23:33:29 --> Helper loaded: date_helper
INFO - 2018-08-06 23:33:29 --> Helper loaded: util_helper
INFO - 2018-08-06 23:33:29 --> Helper loaded: text_helper
INFO - 2018-08-06 23:33:29 --> Helper loaded: string_helper
INFO - 2018-08-06 23:33:29 --> Database Driver Class Initialized
DEBUG - 2018-08-06 23:33:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-06 23:33:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-06 23:33:29 --> Email Class Initialized
INFO - 2018-08-06 23:33:29 --> Controller Class Initialized
DEBUG - 2018-08-06 23:33:29 --> Home MX_Controller Initialized
DEBUG - 2018-08-06 23:33:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-06 23:33:29 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-06 23:33:29 --> Login MX_Controller Initialized
INFO - 2018-08-06 23:33:29 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-06 23:33:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-06 23:33:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-06 23:33:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-08-06 23:33:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-08-06 23:33:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-08-06 23:33:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-08-06 23:33:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-08-06 23:33:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/search_page.php
INFO - 2018-08-06 23:33:30 --> Final output sent to browser
DEBUG - 2018-08-06 23:33:30 --> Total execution time: 0.4973
INFO - 2018-08-06 23:33:30 --> Config Class Initialized
INFO - 2018-08-06 23:33:30 --> Hooks Class Initialized
DEBUG - 2018-08-06 23:33:30 --> UTF-8 Support Enabled
INFO - 2018-08-06 23:33:30 --> Config Class Initialized
INFO - 2018-08-06 23:33:30 --> Utf8 Class Initialized
INFO - 2018-08-06 23:33:30 --> Hooks Class Initialized
INFO - 2018-08-06 23:33:30 --> URI Class Initialized
DEBUG - 2018-08-06 23:33:30 --> UTF-8 Support Enabled
INFO - 2018-08-06 23:33:30 --> Router Class Initialized
INFO - 2018-08-06 23:33:30 --> Utf8 Class Initialized
INFO - 2018-08-06 23:33:30 --> Output Class Initialized
INFO - 2018-08-06 23:33:30 --> URI Class Initialized
INFO - 2018-08-06 23:33:30 --> Router Class Initialized
INFO - 2018-08-06 23:33:30 --> Output Class Initialized
INFO - 2018-08-06 23:33:30 --> Security Class Initialized
DEBUG - 2018-08-06 23:33:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-06 23:33:30 --> Input Class Initialized
INFO - 2018-08-06 23:33:30 --> Language Class Initialized
INFO - 2018-08-06 23:33:30 --> Security Class Initialized
INFO - 2018-08-06 23:33:30 --> Language Class Initialized
DEBUG - 2018-08-06 23:33:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-06 23:33:30 --> Input Class Initialized
INFO - 2018-08-06 23:33:30 --> Language Class Initialized
ERROR - 2018-08-06 23:33:30 --> 404 Page Not Found: /index
INFO - 2018-08-06 23:33:30 --> Config Class Initialized
INFO - 2018-08-06 23:33:30 --> Hooks Class Initialized
DEBUG - 2018-08-06 23:33:30 --> UTF-8 Support Enabled
INFO - 2018-08-06 23:33:30 --> Utf8 Class Initialized
INFO - 2018-08-06 23:33:30 --> URI Class Initialized
INFO - 2018-08-06 23:33:30 --> Config Class Initialized
INFO - 2018-08-06 23:33:30 --> Router Class Initialized
INFO - 2018-08-06 23:33:30 --> Output Class Initialized
INFO - 2018-08-06 23:33:30 --> Loader Class Initialized
INFO - 2018-08-06 23:33:30 --> Security Class Initialized
DEBUG - 2018-08-06 23:33:30 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
DEBUG - 2018-08-06 23:33:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-06 23:33:30 --> Input Class Initialized
INFO - 2018-08-06 23:33:30 --> Helper loaded: url_helper
INFO - 2018-08-06 23:33:30 --> Language Class Initialized
INFO - 2018-08-06 23:33:30 --> Helper loaded: form_helper
ERROR - 2018-08-06 23:33:30 --> 404 Page Not Found: /index
INFO - 2018-08-06 23:33:30 --> Helper loaded: date_helper
INFO - 2018-08-06 23:33:30 --> Helper loaded: util_helper
INFO - 2018-08-06 23:33:30 --> Config Class Initialized
INFO - 2018-08-06 23:33:30 --> Hooks Class Initialized
INFO - 2018-08-06 23:33:30 --> Helper loaded: text_helper
DEBUG - 2018-08-06 23:33:30 --> UTF-8 Support Enabled
INFO - 2018-08-06 23:33:30 --> Helper loaded: string_helper
INFO - 2018-08-06 23:33:30 --> Utf8 Class Initialized
INFO - 2018-08-06 23:33:31 --> URI Class Initialized
INFO - 2018-08-06 23:33:31 --> Router Class Initialized
INFO - 2018-08-06 23:33:31 --> Database Driver Class Initialized
INFO - 2018-08-06 23:33:31 --> Output Class Initialized
INFO - 2018-08-06 23:33:31 --> Security Class Initialized
DEBUG - 2018-08-06 23:33:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-06 23:33:31 --> Input Class Initialized
INFO - 2018-08-06 23:33:31 --> Language Class Initialized
ERROR - 2018-08-06 23:33:31 --> 404 Page Not Found: /index
DEBUG - 2018-08-06 23:33:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-06 23:33:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-06 23:33:31 --> Email Class Initialized
INFO - 2018-08-06 23:33:31 --> Controller Class Initialized
DEBUG - 2018-08-06 23:33:31 --> Home MX_Controller Initialized
DEBUG - 2018-08-06 23:33:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-06 23:33:31 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-06 23:33:31 --> Login MX_Controller Initialized
INFO - 2018-08-06 23:33:31 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-06 23:33:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-06 23:33:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-06 23:33:37 --> Config Class Initialized
INFO - 2018-08-06 23:33:37 --> Hooks Class Initialized
DEBUG - 2018-08-06 23:33:37 --> UTF-8 Support Enabled
INFO - 2018-08-06 23:33:37 --> Utf8 Class Initialized
INFO - 2018-08-06 23:33:37 --> URI Class Initialized
INFO - 2018-08-06 23:33:37 --> Router Class Initialized
INFO - 2018-08-06 23:33:37 --> Output Class Initialized
INFO - 2018-08-06 23:33:37 --> Security Class Initialized
DEBUG - 2018-08-06 23:33:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-06 23:33:37 --> Input Class Initialized
INFO - 2018-08-06 23:33:37 --> Language Class Initialized
INFO - 2018-08-06 23:33:37 --> Language Class Initialized
INFO - 2018-08-06 23:33:37 --> Config Class Initialized
INFO - 2018-08-06 23:33:37 --> Loader Class Initialized
DEBUG - 2018-08-06 23:33:37 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-06 23:33:37 --> Helper loaded: url_helper
INFO - 2018-08-06 23:33:37 --> Helper loaded: form_helper
INFO - 2018-08-06 23:33:37 --> Helper loaded: date_helper
INFO - 2018-08-06 23:33:37 --> Helper loaded: util_helper
INFO - 2018-08-06 23:33:37 --> Helper loaded: text_helper
INFO - 2018-08-06 23:33:37 --> Helper loaded: string_helper
INFO - 2018-08-06 23:33:37 --> Database Driver Class Initialized
DEBUG - 2018-08-06 23:33:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-06 23:33:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-06 23:33:37 --> Email Class Initialized
INFO - 2018-08-06 23:33:37 --> Controller Class Initialized
DEBUG - 2018-08-06 23:33:37 --> Home MX_Controller Initialized
DEBUG - 2018-08-06 23:33:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-06 23:33:37 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-06 23:33:37 --> Login MX_Controller Initialized
INFO - 2018-08-06 23:33:37 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-06 23:33:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-06 23:33:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-06 23:33:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-08-06 23:33:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-08-06 23:33:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-08-06 23:33:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-08-06 23:33:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-08-06 23:33:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-08-06 23:33:37 --> Final output sent to browser
DEBUG - 2018-08-06 23:33:37 --> Total execution time: 0.6063
INFO - 2018-08-06 23:33:37 --> Config Class Initialized
INFO - 2018-08-06 23:33:37 --> Config Class Initialized
INFO - 2018-08-06 23:33:37 --> Hooks Class Initialized
INFO - 2018-08-06 23:33:37 --> Hooks Class Initialized
DEBUG - 2018-08-06 23:33:37 --> UTF-8 Support Enabled
DEBUG - 2018-08-06 23:33:37 --> UTF-8 Support Enabled
INFO - 2018-08-06 23:33:37 --> Utf8 Class Initialized
INFO - 2018-08-06 23:33:37 --> Utf8 Class Initialized
INFO - 2018-08-06 23:33:37 --> Config Class Initialized
INFO - 2018-08-06 23:33:38 --> Hooks Class Initialized
INFO - 2018-08-06 23:33:38 --> URI Class Initialized
INFO - 2018-08-06 23:33:38 --> URI Class Initialized
DEBUG - 2018-08-06 23:33:38 --> UTF-8 Support Enabled
INFO - 2018-08-06 23:33:38 --> Router Class Initialized
INFO - 2018-08-06 23:33:38 --> Router Class Initialized
INFO - 2018-08-06 23:33:38 --> Utf8 Class Initialized
INFO - 2018-08-06 23:33:38 --> Output Class Initialized
INFO - 2018-08-06 23:33:38 --> Output Class Initialized
INFO - 2018-08-06 23:33:38 --> Security Class Initialized
INFO - 2018-08-06 23:33:38 --> URI Class Initialized
INFO - 2018-08-06 23:33:38 --> Security Class Initialized
DEBUG - 2018-08-06 23:33:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-06 23:33:38 --> Router Class Initialized
INFO - 2018-08-06 23:33:38 --> Input Class Initialized
INFO - 2018-08-06 23:33:38 --> Output Class Initialized
DEBUG - 2018-08-06 23:33:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-06 23:33:38 --> Input Class Initialized
INFO - 2018-08-06 23:33:38 --> Security Class Initialized
INFO - 2018-08-06 23:33:38 --> Language Class Initialized
ERROR - 2018-08-06 23:33:38 --> 404 Page Not Found: /index
DEBUG - 2018-08-06 23:33:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-06 23:33:38 --> Language Class Initialized
ERROR - 2018-08-06 23:33:38 --> 404 Page Not Found: /index
INFO - 2018-08-06 23:33:38 --> Input Class Initialized
INFO - 2018-08-06 23:33:38 --> Language Class Initialized
INFO - 2018-08-06 23:33:38 --> Config Class Initialized
INFO - 2018-08-06 23:33:38 --> Language Class Initialized
INFO - 2018-08-06 23:33:38 --> Hooks Class Initialized
INFO - 2018-08-06 23:33:38 --> Config Class Initialized
DEBUG - 2018-08-06 23:33:38 --> UTF-8 Support Enabled
INFO - 2018-08-06 23:33:38 --> Utf8 Class Initialized
INFO - 2018-08-06 23:33:38 --> URI Class Initialized
INFO - 2018-08-06 23:33:38 --> Router Class Initialized
INFO - 2018-08-06 23:33:38 --> Loader Class Initialized
INFO - 2018-08-06 23:33:38 --> Output Class Initialized
DEBUG - 2018-08-06 23:33:38 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-06 23:33:38 --> Security Class Initialized
DEBUG - 2018-08-06 23:33:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-06 23:33:38 --> Input Class Initialized
INFO - 2018-08-06 23:33:38 --> Language Class Initialized
ERROR - 2018-08-06 23:33:38 --> 404 Page Not Found: /index
INFO - 2018-08-06 23:33:38 --> Config Class Initialized
INFO - 2018-08-06 23:33:38 --> Hooks Class Initialized
DEBUG - 2018-08-06 23:33:38 --> UTF-8 Support Enabled
INFO - 2018-08-06 23:33:38 --> Helper loaded: url_helper
INFO - 2018-08-06 23:33:38 --> Utf8 Class Initialized
INFO - 2018-08-06 23:33:38 --> Helper loaded: form_helper
INFO - 2018-08-06 23:33:38 --> Helper loaded: date_helper
INFO - 2018-08-06 23:33:38 --> URI Class Initialized
INFO - 2018-08-06 23:33:38 --> Helper loaded: util_helper
INFO - 2018-08-06 23:33:38 --> Router Class Initialized
INFO - 2018-08-06 23:33:38 --> Helper loaded: text_helper
INFO - 2018-08-06 23:33:38 --> Output Class Initialized
INFO - 2018-08-06 23:33:38 --> Security Class Initialized
INFO - 2018-08-06 23:33:38 --> Helper loaded: string_helper
DEBUG - 2018-08-06 23:33:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-06 23:33:38 --> Database Driver Class Initialized
INFO - 2018-08-06 23:33:38 --> Input Class Initialized
DEBUG - 2018-08-06 23:33:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-06 23:33:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-06 23:33:38 --> Language Class Initialized
INFO - 2018-08-06 23:33:38 --> Email Class Initialized
ERROR - 2018-08-06 23:33:38 --> 404 Page Not Found: /index
INFO - 2018-08-06 23:33:38 --> Controller Class Initialized
DEBUG - 2018-08-06 23:33:38 --> Home MX_Controller Initialized
DEBUG - 2018-08-06 23:33:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-06 23:33:38 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-06 23:33:38 --> Login MX_Controller Initialized
INFO - 2018-08-06 23:33:38 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-06 23:33:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-06 23:33:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-06 23:33:54 --> Config Class Initialized
INFO - 2018-08-06 23:33:54 --> Hooks Class Initialized
DEBUG - 2018-08-06 23:33:54 --> UTF-8 Support Enabled
INFO - 2018-08-06 23:33:54 --> Utf8 Class Initialized
INFO - 2018-08-06 23:33:54 --> URI Class Initialized
INFO - 2018-08-06 23:33:54 --> Router Class Initialized
INFO - 2018-08-06 23:33:54 --> Output Class Initialized
INFO - 2018-08-06 23:33:54 --> Security Class Initialized
DEBUG - 2018-08-06 23:33:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-06 23:33:54 --> Input Class Initialized
INFO - 2018-08-06 23:33:54 --> Language Class Initialized
INFO - 2018-08-06 23:33:54 --> Language Class Initialized
INFO - 2018-08-06 23:33:54 --> Config Class Initialized
INFO - 2018-08-06 23:33:54 --> Loader Class Initialized
DEBUG - 2018-08-06 23:33:54 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-06 23:33:54 --> Helper loaded: url_helper
INFO - 2018-08-06 23:33:54 --> Helper loaded: form_helper
INFO - 2018-08-06 23:33:54 --> Helper loaded: date_helper
INFO - 2018-08-06 23:33:54 --> Helper loaded: util_helper
INFO - 2018-08-06 23:33:54 --> Helper loaded: text_helper
INFO - 2018-08-06 23:33:54 --> Helper loaded: string_helper
INFO - 2018-08-06 23:33:54 --> Database Driver Class Initialized
DEBUG - 2018-08-06 23:33:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-06 23:33:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-06 23:33:55 --> Email Class Initialized
INFO - 2018-08-06 23:33:55 --> Controller Class Initialized
DEBUG - 2018-08-06 23:33:55 --> Home MX_Controller Initialized
DEBUG - 2018-08-06 23:33:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-06 23:33:55 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-06 23:33:55 --> Login MX_Controller Initialized
INFO - 2018-08-06 23:33:55 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-06 23:33:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-06 23:33:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-06 23:33:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-08-06 23:33:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-08-06 23:33:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-08-06 23:33:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-08-06 23:33:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-08-06 23:33:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-08-06 23:33:55 --> Final output sent to browser
DEBUG - 2018-08-06 23:33:55 --> Total execution time: 0.5417
INFO - 2018-08-06 23:33:55 --> Config Class Initialized
INFO - 2018-08-06 23:33:55 --> Config Class Initialized
INFO - 2018-08-06 23:33:55 --> Hooks Class Initialized
INFO - 2018-08-06 23:33:55 --> Hooks Class Initialized
INFO - 2018-08-06 23:33:55 --> Config Class Initialized
INFO - 2018-08-06 23:33:55 --> Hooks Class Initialized
DEBUG - 2018-08-06 23:33:55 --> UTF-8 Support Enabled
DEBUG - 2018-08-06 23:33:55 --> UTF-8 Support Enabled
INFO - 2018-08-06 23:33:55 --> Utf8 Class Initialized
DEBUG - 2018-08-06 23:33:55 --> UTF-8 Support Enabled
INFO - 2018-08-06 23:33:55 --> Utf8 Class Initialized
INFO - 2018-08-06 23:33:55 --> Utf8 Class Initialized
INFO - 2018-08-06 23:33:55 --> URI Class Initialized
INFO - 2018-08-06 23:33:55 --> URI Class Initialized
INFO - 2018-08-06 23:33:55 --> URI Class Initialized
INFO - 2018-08-06 23:33:55 --> Router Class Initialized
INFO - 2018-08-06 23:33:55 --> Router Class Initialized
INFO - 2018-08-06 23:33:55 --> Output Class Initialized
INFO - 2018-08-06 23:33:55 --> Router Class Initialized
INFO - 2018-08-06 23:33:55 --> Output Class Initialized
INFO - 2018-08-06 23:33:55 --> Security Class Initialized
INFO - 2018-08-06 23:33:55 --> Output Class Initialized
INFO - 2018-08-06 23:33:55 --> Security Class Initialized
DEBUG - 2018-08-06 23:33:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-08-06 23:33:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-06 23:33:55 --> Security Class Initialized
INFO - 2018-08-06 23:33:55 --> Input Class Initialized
INFO - 2018-08-06 23:33:55 --> Input Class Initialized
DEBUG - 2018-08-06 23:33:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-06 23:33:55 --> Language Class Initialized
INFO - 2018-08-06 23:33:55 --> Language Class Initialized
INFO - 2018-08-06 23:33:55 --> Input Class Initialized
INFO - 2018-08-06 23:33:55 --> Language Class Initialized
INFO - 2018-08-06 23:33:55 --> Config Class Initialized
INFO - 2018-08-06 23:33:55 --> Language Class Initialized
ERROR - 2018-08-06 23:33:55 --> 404 Page Not Found: /index
ERROR - 2018-08-06 23:33:55 --> 404 Page Not Found: /index
INFO - 2018-08-06 23:33:55 --> Loader Class Initialized
INFO - 2018-08-06 23:33:55 --> Config Class Initialized
INFO - 2018-08-06 23:33:55 --> Hooks Class Initialized
DEBUG - 2018-08-06 23:33:55 --> UTF-8 Support Enabled
DEBUG - 2018-08-06 23:33:55 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-06 23:33:55 --> Utf8 Class Initialized
INFO - 2018-08-06 23:33:55 --> URI Class Initialized
INFO - 2018-08-06 23:33:56 --> Router Class Initialized
INFO - 2018-08-06 23:33:56 --> Helper loaded: url_helper
INFO - 2018-08-06 23:33:56 --> Output Class Initialized
INFO - 2018-08-06 23:33:56 --> Helper loaded: form_helper
INFO - 2018-08-06 23:33:56 --> Helper loaded: date_helper
INFO - 2018-08-06 23:33:56 --> Helper loaded: util_helper
INFO - 2018-08-06 23:33:56 --> Helper loaded: text_helper
INFO - 2018-08-06 23:33:56 --> Helper loaded: string_helper
INFO - 2018-08-06 23:33:56 --> Security Class Initialized
INFO - 2018-08-06 23:33:56 --> Database Driver Class Initialized
DEBUG - 2018-08-06 23:33:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-06 23:33:56 --> Input Class Initialized
INFO - 2018-08-06 23:33:56 --> Language Class Initialized
ERROR - 2018-08-06 23:33:56 --> 404 Page Not Found: /index
INFO - 2018-08-06 23:33:56 --> Config Class Initialized
DEBUG - 2018-08-06 23:33:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-06 23:33:56 --> Hooks Class Initialized
INFO - 2018-08-06 23:33:56 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-08-06 23:33:56 --> UTF-8 Support Enabled
INFO - 2018-08-06 23:33:56 --> Email Class Initialized
INFO - 2018-08-06 23:33:56 --> Utf8 Class Initialized
INFO - 2018-08-06 23:33:56 --> Controller Class Initialized
DEBUG - 2018-08-06 23:33:56 --> Home MX_Controller Initialized
INFO - 2018-08-06 23:33:56 --> URI Class Initialized
DEBUG - 2018-08-06 23:33:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-08-06 23:33:56 --> Router Class Initialized
INFO - 2018-08-06 23:33:56 --> Output Class Initialized
DEBUG - 2018-08-06 23:33:56 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-06 23:33:56 --> Login MX_Controller Initialized
INFO - 2018-08-06 23:33:56 --> Security Class Initialized
INFO - 2018-08-06 23:33:56 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-06 23:33:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-06 23:33:56 --> Input Class Initialized
DEBUG - 2018-08-06 23:33:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-08-06 23:33:56 --> Language Class Initialized
DEBUG - 2018-08-06 23:33:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
ERROR - 2018-08-06 23:33:56 --> 404 Page Not Found: /index
INFO - 2018-08-06 23:34:00 --> Config Class Initialized
INFO - 2018-08-06 23:34:00 --> Hooks Class Initialized
DEBUG - 2018-08-06 23:34:00 --> UTF-8 Support Enabled
INFO - 2018-08-06 23:34:00 --> Utf8 Class Initialized
INFO - 2018-08-06 23:34:00 --> URI Class Initialized
INFO - 2018-08-06 23:34:00 --> Router Class Initialized
INFO - 2018-08-06 23:34:00 --> Output Class Initialized
INFO - 2018-08-06 23:34:00 --> Security Class Initialized
DEBUG - 2018-08-06 23:34:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-06 23:34:00 --> Input Class Initialized
INFO - 2018-08-06 23:34:00 --> Language Class Initialized
INFO - 2018-08-06 23:34:00 --> Language Class Initialized
INFO - 2018-08-06 23:34:00 --> Config Class Initialized
INFO - 2018-08-06 23:34:00 --> Loader Class Initialized
DEBUG - 2018-08-06 23:34:00 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-06 23:34:00 --> Helper loaded: url_helper
INFO - 2018-08-06 23:34:00 --> Helper loaded: form_helper
INFO - 2018-08-06 23:34:00 --> Helper loaded: date_helper
INFO - 2018-08-06 23:34:00 --> Helper loaded: util_helper
INFO - 2018-08-06 23:34:00 --> Helper loaded: text_helper
INFO - 2018-08-06 23:34:00 --> Helper loaded: string_helper
INFO - 2018-08-06 23:34:00 --> Database Driver Class Initialized
DEBUG - 2018-08-06 23:34:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-06 23:34:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-06 23:34:00 --> Email Class Initialized
INFO - 2018-08-06 23:34:00 --> Controller Class Initialized
DEBUG - 2018-08-06 23:34:00 --> Home MX_Controller Initialized
DEBUG - 2018-08-06 23:34:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-06 23:34:00 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-06 23:34:00 --> Login MX_Controller Initialized
INFO - 2018-08-06 23:34:00 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-06 23:34:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-06 23:34:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-06 23:34:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-08-06 23:34:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-08-06 23:34:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-08-06 23:34:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-08-06 23:34:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-08-06 23:34:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-08-06 23:34:00 --> Final output sent to browser
DEBUG - 2018-08-06 23:34:00 --> Total execution time: 0.5545
INFO - 2018-08-06 23:34:01 --> Config Class Initialized
INFO - 2018-08-06 23:34:01 --> Config Class Initialized
INFO - 2018-08-06 23:34:01 --> Hooks Class Initialized
INFO - 2018-08-06 23:34:01 --> Hooks Class Initialized
INFO - 2018-08-06 23:34:01 --> Config Class Initialized
INFO - 2018-08-06 23:34:01 --> Hooks Class Initialized
DEBUG - 2018-08-06 23:34:01 --> UTF-8 Support Enabled
DEBUG - 2018-08-06 23:34:01 --> UTF-8 Support Enabled
DEBUG - 2018-08-06 23:34:01 --> UTF-8 Support Enabled
INFO - 2018-08-06 23:34:01 --> Utf8 Class Initialized
INFO - 2018-08-06 23:34:01 --> Utf8 Class Initialized
INFO - 2018-08-06 23:34:01 --> Utf8 Class Initialized
INFO - 2018-08-06 23:34:01 --> URI Class Initialized
INFO - 2018-08-06 23:34:01 --> URI Class Initialized
INFO - 2018-08-06 23:34:01 --> URI Class Initialized
INFO - 2018-08-06 23:34:01 --> Router Class Initialized
INFO - 2018-08-06 23:34:01 --> Router Class Initialized
INFO - 2018-08-06 23:34:01 --> Router Class Initialized
INFO - 2018-08-06 23:34:01 --> Output Class Initialized
INFO - 2018-08-06 23:34:01 --> Output Class Initialized
INFO - 2018-08-06 23:34:01 --> Output Class Initialized
INFO - 2018-08-06 23:34:01 --> Security Class Initialized
INFO - 2018-08-06 23:34:01 --> Security Class Initialized
INFO - 2018-08-06 23:34:01 --> Security Class Initialized
DEBUG - 2018-08-06 23:34:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-08-06 23:34:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-08-06 23:34:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-06 23:34:01 --> Input Class Initialized
INFO - 2018-08-06 23:34:01 --> Input Class Initialized
INFO - 2018-08-06 23:34:01 --> Language Class Initialized
INFO - 2018-08-06 23:34:01 --> Input Class Initialized
ERROR - 2018-08-06 23:34:01 --> 404 Page Not Found: /index
INFO - 2018-08-06 23:34:01 --> Language Class Initialized
ERROR - 2018-08-06 23:34:01 --> 404 Page Not Found: /index
INFO - 2018-08-06 23:34:01 --> Language Class Initialized
INFO - 2018-08-06 23:34:01 --> Language Class Initialized
INFO - 2018-08-06 23:34:01 --> Config Class Initialized
INFO - 2018-08-06 23:34:01 --> Hooks Class Initialized
INFO - 2018-08-06 23:34:01 --> Config Class Initialized
DEBUG - 2018-08-06 23:34:01 --> UTF-8 Support Enabled
INFO - 2018-08-06 23:34:01 --> Loader Class Initialized
INFO - 2018-08-06 23:34:01 --> Utf8 Class Initialized
DEBUG - 2018-08-06 23:34:01 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-06 23:34:01 --> URI Class Initialized
INFO - 2018-08-06 23:34:01 --> Helper loaded: url_helper
INFO - 2018-08-06 23:34:01 --> Helper loaded: form_helper
INFO - 2018-08-06 23:34:01 --> Router Class Initialized
INFO - 2018-08-06 23:34:01 --> Output Class Initialized
INFO - 2018-08-06 23:34:01 --> Helper loaded: date_helper
INFO - 2018-08-06 23:34:01 --> Helper loaded: util_helper
INFO - 2018-08-06 23:34:01 --> Security Class Initialized
DEBUG - 2018-08-06 23:34:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-06 23:34:01 --> Helper loaded: text_helper
INFO - 2018-08-06 23:34:01 --> Input Class Initialized
INFO - 2018-08-06 23:34:01 --> Helper loaded: string_helper
INFO - 2018-08-06 23:34:01 --> Language Class Initialized
INFO - 2018-08-06 23:34:01 --> Database Driver Class Initialized
ERROR - 2018-08-06 23:34:01 --> 404 Page Not Found: /index
INFO - 2018-08-06 23:34:01 --> Config Class Initialized
DEBUG - 2018-08-06 23:34:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-06 23:34:01 --> Hooks Class Initialized
INFO - 2018-08-06 23:34:01 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-08-06 23:34:01 --> UTF-8 Support Enabled
INFO - 2018-08-06 23:34:01 --> Email Class Initialized
INFO - 2018-08-06 23:34:01 --> Utf8 Class Initialized
INFO - 2018-08-06 23:34:01 --> Controller Class Initialized
INFO - 2018-08-06 23:34:01 --> URI Class Initialized
DEBUG - 2018-08-06 23:34:01 --> Home MX_Controller Initialized
INFO - 2018-08-06 23:34:01 --> Router Class Initialized
INFO - 2018-08-06 23:34:01 --> Output Class Initialized
DEBUG - 2018-08-06 23:34:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-08-06 23:34:01 --> Security Class Initialized
DEBUG - 2018-08-06 23:34:01 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-06 23:34:01 --> Login MX_Controller Initialized
DEBUG - 2018-08-06 23:34:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-06 23:34:01 --> Input Class Initialized
INFO - 2018-08-06 23:34:01 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-06 23:34:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-08-06 23:34:01 --> Language Class Initialized
DEBUG - 2018-08-06 23:34:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
ERROR - 2018-08-06 23:34:01 --> 404 Page Not Found: /index
INFO - 2018-08-06 23:34:09 --> Config Class Initialized
INFO - 2018-08-06 23:34:09 --> Hooks Class Initialized
DEBUG - 2018-08-06 23:34:09 --> UTF-8 Support Enabled
INFO - 2018-08-06 23:34:09 --> Utf8 Class Initialized
INFO - 2018-08-06 23:34:09 --> URI Class Initialized
INFO - 2018-08-06 23:34:09 --> Router Class Initialized
INFO - 2018-08-06 23:34:09 --> Output Class Initialized
INFO - 2018-08-06 23:34:09 --> Security Class Initialized
DEBUG - 2018-08-06 23:34:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-06 23:34:09 --> Input Class Initialized
INFO - 2018-08-06 23:34:09 --> Language Class Initialized
INFO - 2018-08-06 23:34:09 --> Language Class Initialized
INFO - 2018-08-06 23:34:09 --> Config Class Initialized
INFO - 2018-08-06 23:34:09 --> Loader Class Initialized
DEBUG - 2018-08-06 23:34:09 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-06 23:34:09 --> Helper loaded: url_helper
INFO - 2018-08-06 23:34:09 --> Helper loaded: form_helper
INFO - 2018-08-06 23:34:09 --> Helper loaded: date_helper
INFO - 2018-08-06 23:34:09 --> Helper loaded: util_helper
INFO - 2018-08-06 23:34:09 --> Helper loaded: text_helper
INFO - 2018-08-06 23:34:09 --> Helper loaded: string_helper
INFO - 2018-08-06 23:34:09 --> Database Driver Class Initialized
DEBUG - 2018-08-06 23:34:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-06 23:34:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-06 23:34:09 --> Email Class Initialized
INFO - 2018-08-06 23:34:09 --> Controller Class Initialized
DEBUG - 2018-08-06 23:34:09 --> Home MX_Controller Initialized
DEBUG - 2018-08-06 23:34:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-06 23:34:09 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-06 23:34:09 --> Login MX_Controller Initialized
INFO - 2018-08-06 23:34:09 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-06 23:34:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-06 23:34:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-06 23:34:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-08-06 23:34:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-08-06 23:34:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-08-06 23:34:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-08-06 23:34:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-08-06 23:34:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-08-06 23:34:09 --> Final output sent to browser
DEBUG - 2018-08-06 23:34:09 --> Total execution time: 0.5055
INFO - 2018-08-06 23:34:10 --> Config Class Initialized
INFO - 2018-08-06 23:34:10 --> Config Class Initialized
INFO - 2018-08-06 23:34:10 --> Hooks Class Initialized
INFO - 2018-08-06 23:34:10 --> Hooks Class Initialized
DEBUG - 2018-08-06 23:34:10 --> UTF-8 Support Enabled
INFO - 2018-08-06 23:34:10 --> Utf8 Class Initialized
DEBUG - 2018-08-06 23:34:10 --> UTF-8 Support Enabled
INFO - 2018-08-06 23:34:10 --> URI Class Initialized
INFO - 2018-08-06 23:34:10 --> Config Class Initialized
INFO - 2018-08-06 23:34:10 --> Utf8 Class Initialized
INFO - 2018-08-06 23:34:10 --> Hooks Class Initialized
INFO - 2018-08-06 23:34:10 --> Router Class Initialized
INFO - 2018-08-06 23:34:10 --> URI Class Initialized
DEBUG - 2018-08-06 23:34:10 --> UTF-8 Support Enabled
INFO - 2018-08-06 23:34:10 --> Utf8 Class Initialized
INFO - 2018-08-06 23:34:10 --> Output Class Initialized
INFO - 2018-08-06 23:34:10 --> Router Class Initialized
INFO - 2018-08-06 23:34:10 --> URI Class Initialized
INFO - 2018-08-06 23:34:10 --> Security Class Initialized
INFO - 2018-08-06 23:34:10 --> Output Class Initialized
INFO - 2018-08-06 23:34:10 --> Router Class Initialized
INFO - 2018-08-06 23:34:10 --> Security Class Initialized
DEBUG - 2018-08-06 23:34:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-06 23:34:10 --> Output Class Initialized
DEBUG - 2018-08-06 23:34:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-06 23:34:10 --> Input Class Initialized
INFO - 2018-08-06 23:34:10 --> Language Class Initialized
ERROR - 2018-08-06 23:34:10 --> 404 Page Not Found: /index
INFO - 2018-08-06 23:34:10 --> Config Class Initialized
INFO - 2018-08-06 23:34:10 --> Hooks Class Initialized
DEBUG - 2018-08-06 23:34:10 --> UTF-8 Support Enabled
INFO - 2018-08-06 23:34:10 --> Utf8 Class Initialized
INFO - 2018-08-06 23:34:10 --> URI Class Initialized
INFO - 2018-08-06 23:34:10 --> Router Class Initialized
INFO - 2018-08-06 23:34:10 --> Input Class Initialized
INFO - 2018-08-06 23:34:10 --> Output Class Initialized
INFO - 2018-08-06 23:34:10 --> Security Class Initialized
INFO - 2018-08-06 23:34:10 --> Language Class Initialized
INFO - 2018-08-06 23:34:10 --> Security Class Initialized
DEBUG - 2018-08-06 23:34:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-06 23:34:10 --> Input Class Initialized
INFO - 2018-08-06 23:34:10 --> Language Class Initialized
DEBUG - 2018-08-06 23:34:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-08-06 23:34:10 --> 404 Page Not Found: /index
ERROR - 2018-08-06 23:34:10 --> 404 Page Not Found: /index
INFO - 2018-08-06 23:34:10 --> Input Class Initialized
INFO - 2018-08-06 23:34:10 --> Language Class Initialized
INFO - 2018-08-06 23:34:10 --> Language Class Initialized
INFO - 2018-08-06 23:34:10 --> Config Class Initialized
INFO - 2018-08-06 23:34:10 --> Config Class Initialized
INFO - 2018-08-06 23:34:10 --> Hooks Class Initialized
INFO - 2018-08-06 23:34:11 --> Loader Class Initialized
DEBUG - 2018-08-06 23:34:11 --> UTF-8 Support Enabled
INFO - 2018-08-06 23:34:11 --> Utf8 Class Initialized
DEBUG - 2018-08-06 23:34:11 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-06 23:34:11 --> URI Class Initialized
INFO - 2018-08-06 23:34:11 --> Helper loaded: url_helper
INFO - 2018-08-06 23:34:11 --> Router Class Initialized
INFO - 2018-08-06 23:34:11 --> Helper loaded: form_helper
INFO - 2018-08-06 23:34:11 --> Output Class Initialized
INFO - 2018-08-06 23:34:11 --> Helper loaded: date_helper
INFO - 2018-08-06 23:34:11 --> Security Class Initialized
INFO - 2018-08-06 23:34:11 --> Helper loaded: util_helper
DEBUG - 2018-08-06 23:34:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-06 23:34:11 --> Helper loaded: text_helper
INFO - 2018-08-06 23:34:11 --> Input Class Initialized
INFO - 2018-08-06 23:34:11 --> Helper loaded: string_helper
INFO - 2018-08-06 23:34:11 --> Language Class Initialized
INFO - 2018-08-06 23:34:11 --> Database Driver Class Initialized
ERROR - 2018-08-06 23:34:11 --> 404 Page Not Found: /index
DEBUG - 2018-08-06 23:34:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-06 23:34:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-06 23:34:11 --> Email Class Initialized
INFO - 2018-08-06 23:34:11 --> Controller Class Initialized
DEBUG - 2018-08-06 23:34:11 --> Home MX_Controller Initialized
DEBUG - 2018-08-06 23:34:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-06 23:34:11 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-06 23:34:11 --> Login MX_Controller Initialized
INFO - 2018-08-06 23:34:11 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-06 23:34:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-06 23:34:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-06 23:34:31 --> Config Class Initialized
INFO - 2018-08-06 23:34:32 --> Hooks Class Initialized
DEBUG - 2018-08-06 23:34:32 --> UTF-8 Support Enabled
INFO - 2018-08-06 23:34:32 --> Utf8 Class Initialized
INFO - 2018-08-06 23:34:32 --> URI Class Initialized
INFO - 2018-08-06 23:34:32 --> Router Class Initialized
INFO - 2018-08-06 23:34:32 --> Output Class Initialized
INFO - 2018-08-06 23:34:32 --> Security Class Initialized
DEBUG - 2018-08-06 23:34:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-06 23:34:32 --> Input Class Initialized
INFO - 2018-08-06 23:34:32 --> Language Class Initialized
INFO - 2018-08-06 23:34:32 --> Language Class Initialized
INFO - 2018-08-06 23:34:32 --> Config Class Initialized
INFO - 2018-08-06 23:34:32 --> Loader Class Initialized
DEBUG - 2018-08-06 23:34:32 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-06 23:34:32 --> Helper loaded: url_helper
INFO - 2018-08-06 23:34:32 --> Helper loaded: form_helper
INFO - 2018-08-06 23:34:32 --> Helper loaded: date_helper
INFO - 2018-08-06 23:34:32 --> Helper loaded: util_helper
INFO - 2018-08-06 23:34:32 --> Helper loaded: text_helper
INFO - 2018-08-06 23:34:32 --> Helper loaded: string_helper
INFO - 2018-08-06 23:34:32 --> Database Driver Class Initialized
DEBUG - 2018-08-06 23:34:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-06 23:34:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-06 23:34:32 --> Email Class Initialized
INFO - 2018-08-06 23:34:32 --> Controller Class Initialized
DEBUG - 2018-08-06 23:34:32 --> Home MX_Controller Initialized
DEBUG - 2018-08-06 23:34:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-06 23:34:32 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-06 23:34:32 --> Login MX_Controller Initialized
INFO - 2018-08-06 23:34:32 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-06 23:34:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-06 23:34:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-06 23:34:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-08-06 23:34:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-08-06 23:34:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-08-06 23:34:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-08-06 23:34:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-08-06 23:34:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-08-06 23:34:32 --> Final output sent to browser
DEBUG - 2018-08-06 23:34:32 --> Total execution time: 0.5089
INFO - 2018-08-06 23:34:32 --> Config Class Initialized
INFO - 2018-08-06 23:34:32 --> Config Class Initialized
INFO - 2018-08-06 23:34:32 --> Hooks Class Initialized
INFO - 2018-08-06 23:34:32 --> Hooks Class Initialized
DEBUG - 2018-08-06 23:34:32 --> UTF-8 Support Enabled
DEBUG - 2018-08-06 23:34:32 --> UTF-8 Support Enabled
INFO - 2018-08-06 23:34:32 --> Config Class Initialized
INFO - 2018-08-06 23:34:32 --> Hooks Class Initialized
INFO - 2018-08-06 23:34:32 --> Utf8 Class Initialized
INFO - 2018-08-06 23:34:32 --> Utf8 Class Initialized
DEBUG - 2018-08-06 23:34:32 --> UTF-8 Support Enabled
INFO - 2018-08-06 23:34:32 --> URI Class Initialized
INFO - 2018-08-06 23:34:32 --> Utf8 Class Initialized
INFO - 2018-08-06 23:34:32 --> URI Class Initialized
INFO - 2018-08-06 23:34:32 --> Router Class Initialized
INFO - 2018-08-06 23:34:32 --> URI Class Initialized
INFO - 2018-08-06 23:34:32 --> Router Class Initialized
INFO - 2018-08-06 23:34:32 --> Output Class Initialized
INFO - 2018-08-06 23:34:33 --> Security Class Initialized
DEBUG - 2018-08-06 23:34:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-06 23:34:33 --> Input Class Initialized
INFO - 2018-08-06 23:34:33 --> Output Class Initialized
INFO - 2018-08-06 23:34:33 --> Router Class Initialized
INFO - 2018-08-06 23:34:33 --> Security Class Initialized
INFO - 2018-08-06 23:34:33 --> Language Class Initialized
INFO - 2018-08-06 23:34:33 --> Output Class Initialized
DEBUG - 2018-08-06 23:34:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-06 23:34:33 --> Input Class Initialized
INFO - 2018-08-06 23:34:33 --> Language Class Initialized
INFO - 2018-08-06 23:34:33 --> Security Class Initialized
INFO - 2018-08-06 23:34:33 --> Language Class Initialized
ERROR - 2018-08-06 23:34:33 --> 404 Page Not Found: /index
DEBUG - 2018-08-06 23:34:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-06 23:34:33 --> Config Class Initialized
INFO - 2018-08-06 23:34:33 --> Input Class Initialized
INFO - 2018-08-06 23:34:33 --> Loader Class Initialized
INFO - 2018-08-06 23:34:33 --> Language Class Initialized
INFO - 2018-08-06 23:34:33 --> Config Class Initialized
DEBUG - 2018-08-06 23:34:33 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-06 23:34:33 --> Hooks Class Initialized
ERROR - 2018-08-06 23:34:33 --> 404 Page Not Found: /index
INFO - 2018-08-06 23:34:33 --> Helper loaded: url_helper
DEBUG - 2018-08-06 23:34:33 --> UTF-8 Support Enabled
INFO - 2018-08-06 23:34:33 --> Helper loaded: form_helper
INFO - 2018-08-06 23:34:33 --> Utf8 Class Initialized
INFO - 2018-08-06 23:34:33 --> URI Class Initialized
INFO - 2018-08-06 23:34:33 --> Helper loaded: date_helper
INFO - 2018-08-06 23:34:33 --> Router Class Initialized
INFO - 2018-08-06 23:34:33 --> Helper loaded: util_helper
INFO - 2018-08-06 23:34:33 --> Helper loaded: text_helper
INFO - 2018-08-06 23:34:33 --> Helper loaded: string_helper
INFO - 2018-08-06 23:34:33 --> Output Class Initialized
INFO - 2018-08-06 23:34:33 --> Database Driver Class Initialized
INFO - 2018-08-06 23:34:33 --> Security Class Initialized
DEBUG - 2018-08-06 23:34:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-06 23:34:33 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-08-06 23:34:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-06 23:34:33 --> Input Class Initialized
INFO - 2018-08-06 23:34:33 --> Email Class Initialized
INFO - 2018-08-06 23:34:33 --> Controller Class Initialized
INFO - 2018-08-06 23:34:33 --> Language Class Initialized
DEBUG - 2018-08-06 23:34:33 --> Home MX_Controller Initialized
ERROR - 2018-08-06 23:34:33 --> 404 Page Not Found: /index
DEBUG - 2018-08-06 23:34:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-08-06 23:34:33 --> Config Class Initialized
INFO - 2018-08-06 23:34:33 --> Hooks Class Initialized
DEBUG - 2018-08-06 23:34:33 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-06 23:34:33 --> Login MX_Controller Initialized
DEBUG - 2018-08-06 23:34:33 --> UTF-8 Support Enabled
INFO - 2018-08-06 23:34:33 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-06 23:34:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-06 23:34:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-06 23:34:33 --> Utf8 Class Initialized
INFO - 2018-08-06 23:34:33 --> URI Class Initialized
INFO - 2018-08-06 23:34:33 --> Router Class Initialized
INFO - 2018-08-06 23:34:33 --> Output Class Initialized
INFO - 2018-08-06 23:34:33 --> Security Class Initialized
DEBUG - 2018-08-06 23:34:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-06 23:34:33 --> Input Class Initialized
INFO - 2018-08-06 23:34:33 --> Language Class Initialized
ERROR - 2018-08-06 23:34:33 --> 404 Page Not Found: /index
INFO - 2018-08-06 23:34:39 --> Config Class Initialized
INFO - 2018-08-06 23:34:39 --> Hooks Class Initialized
DEBUG - 2018-08-06 23:34:39 --> UTF-8 Support Enabled
INFO - 2018-08-06 23:34:39 --> Utf8 Class Initialized
INFO - 2018-08-06 23:34:39 --> URI Class Initialized
INFO - 2018-08-06 23:34:39 --> Router Class Initialized
INFO - 2018-08-06 23:34:39 --> Output Class Initialized
INFO - 2018-08-06 23:34:39 --> Security Class Initialized
DEBUG - 2018-08-06 23:34:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-06 23:34:39 --> Input Class Initialized
INFO - 2018-08-06 23:34:39 --> Language Class Initialized
INFO - 2018-08-06 23:34:39 --> Language Class Initialized
INFO - 2018-08-06 23:34:39 --> Config Class Initialized
INFO - 2018-08-06 23:34:39 --> Loader Class Initialized
DEBUG - 2018-08-06 23:34:39 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-06 23:34:39 --> Helper loaded: url_helper
INFO - 2018-08-06 23:34:40 --> Helper loaded: form_helper
INFO - 2018-08-06 23:34:40 --> Helper loaded: date_helper
INFO - 2018-08-06 23:34:40 --> Helper loaded: util_helper
INFO - 2018-08-06 23:34:40 --> Helper loaded: text_helper
INFO - 2018-08-06 23:34:40 --> Helper loaded: string_helper
INFO - 2018-08-06 23:34:40 --> Database Driver Class Initialized
DEBUG - 2018-08-06 23:34:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-06 23:34:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-06 23:34:40 --> Email Class Initialized
INFO - 2018-08-06 23:34:40 --> Controller Class Initialized
DEBUG - 2018-08-06 23:34:40 --> Home MX_Controller Initialized
DEBUG - 2018-08-06 23:34:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-06 23:34:40 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-06 23:34:40 --> Login MX_Controller Initialized
INFO - 2018-08-06 23:34:40 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-06 23:34:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-06 23:34:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-06 23:34:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-08-06 23:34:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-08-06 23:34:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-08-06 23:34:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-08-06 23:34:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-08-06 23:34:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/search_page.php
INFO - 2018-08-06 23:34:40 --> Final output sent to browser
DEBUG - 2018-08-06 23:34:40 --> Total execution time: 0.5102
INFO - 2018-08-06 23:34:40 --> Config Class Initialized
INFO - 2018-08-06 23:34:40 --> Config Class Initialized
INFO - 2018-08-06 23:34:40 --> Hooks Class Initialized
INFO - 2018-08-06 23:34:40 --> Hooks Class Initialized
DEBUG - 2018-08-06 23:34:40 --> UTF-8 Support Enabled
INFO - 2018-08-06 23:34:40 --> Utf8 Class Initialized
DEBUG - 2018-08-06 23:34:40 --> UTF-8 Support Enabled
INFO - 2018-08-06 23:34:40 --> Utf8 Class Initialized
INFO - 2018-08-06 23:34:40 --> URI Class Initialized
INFO - 2018-08-06 23:34:40 --> URI Class Initialized
INFO - 2018-08-06 23:34:40 --> Router Class Initialized
INFO - 2018-08-06 23:34:40 --> Router Class Initialized
INFO - 2018-08-06 23:34:40 --> Output Class Initialized
INFO - 2018-08-06 23:34:40 --> Output Class Initialized
INFO - 2018-08-06 23:34:40 --> Security Class Initialized
DEBUG - 2018-08-06 23:34:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-06 23:34:40 --> Input Class Initialized
INFO - 2018-08-06 23:34:40 --> Language Class Initialized
ERROR - 2018-08-06 23:34:40 --> 404 Page Not Found: /index
INFO - 2018-08-06 23:34:40 --> Config Class Initialized
INFO - 2018-08-06 23:34:40 --> Hooks Class Initialized
DEBUG - 2018-08-06 23:34:40 --> UTF-8 Support Enabled
INFO - 2018-08-06 23:34:40 --> Security Class Initialized
INFO - 2018-08-06 23:34:40 --> Utf8 Class Initialized
INFO - 2018-08-06 23:34:40 --> URI Class Initialized
INFO - 2018-08-06 23:34:40 --> Router Class Initialized
DEBUG - 2018-08-06 23:34:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-06 23:34:40 --> Output Class Initialized
INFO - 2018-08-06 23:34:40 --> Security Class Initialized
DEBUG - 2018-08-06 23:34:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-06 23:34:40 --> Input Class Initialized
INFO - 2018-08-06 23:34:40 --> Language Class Initialized
ERROR - 2018-08-06 23:34:40 --> 404 Page Not Found: /index
INFO - 2018-08-06 23:34:40 --> Input Class Initialized
INFO - 2018-08-06 23:34:40 --> Config Class Initialized
INFO - 2018-08-06 23:34:40 --> Hooks Class Initialized
INFO - 2018-08-06 23:34:40 --> Language Class Initialized
DEBUG - 2018-08-06 23:34:41 --> UTF-8 Support Enabled
INFO - 2018-08-06 23:34:41 --> Language Class Initialized
INFO - 2018-08-06 23:34:41 --> Utf8 Class Initialized
INFO - 2018-08-06 23:34:41 --> URI Class Initialized
INFO - 2018-08-06 23:34:41 --> Config Class Initialized
INFO - 2018-08-06 23:34:41 --> Router Class Initialized
INFO - 2018-08-06 23:34:41 --> Output Class Initialized
INFO - 2018-08-06 23:34:41 --> Loader Class Initialized
INFO - 2018-08-06 23:34:41 --> Security Class Initialized
DEBUG - 2018-08-06 23:34:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-06 23:34:41 --> Input Class Initialized
INFO - 2018-08-06 23:34:41 --> Language Class Initialized
ERROR - 2018-08-06 23:34:41 --> 404 Page Not Found: /index
DEBUG - 2018-08-06 23:34:41 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-06 23:34:41 --> Helper loaded: url_helper
INFO - 2018-08-06 23:34:41 --> Helper loaded: form_helper
INFO - 2018-08-06 23:34:41 --> Helper loaded: date_helper
INFO - 2018-08-06 23:34:41 --> Helper loaded: util_helper
INFO - 2018-08-06 23:34:41 --> Helper loaded: text_helper
INFO - 2018-08-06 23:34:41 --> Helper loaded: string_helper
INFO - 2018-08-06 23:34:41 --> Database Driver Class Initialized
DEBUG - 2018-08-06 23:34:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-06 23:34:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-06 23:34:41 --> Email Class Initialized
INFO - 2018-08-06 23:34:41 --> Controller Class Initialized
DEBUG - 2018-08-06 23:34:41 --> Home MX_Controller Initialized
DEBUG - 2018-08-06 23:34:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-06 23:34:41 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-06 23:34:41 --> Login MX_Controller Initialized
INFO - 2018-08-06 23:34:41 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-06 23:34:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-06 23:34:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-06 23:37:06 --> Config Class Initialized
INFO - 2018-08-06 23:37:06 --> Hooks Class Initialized
DEBUG - 2018-08-06 23:37:06 --> UTF-8 Support Enabled
INFO - 2018-08-06 23:37:06 --> Utf8 Class Initialized
INFO - 2018-08-06 23:37:06 --> URI Class Initialized
INFO - 2018-08-06 23:37:06 --> Router Class Initialized
INFO - 2018-08-06 23:37:06 --> Output Class Initialized
INFO - 2018-08-06 23:37:06 --> Security Class Initialized
DEBUG - 2018-08-06 23:37:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-06 23:37:06 --> Input Class Initialized
INFO - 2018-08-06 23:37:06 --> Language Class Initialized
INFO - 2018-08-06 23:37:06 --> Language Class Initialized
INFO - 2018-08-06 23:37:06 --> Config Class Initialized
INFO - 2018-08-06 23:37:06 --> Loader Class Initialized
DEBUG - 2018-08-06 23:37:06 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-06 23:37:06 --> Helper loaded: url_helper
INFO - 2018-08-06 23:37:06 --> Helper loaded: form_helper
INFO - 2018-08-06 23:37:06 --> Helper loaded: date_helper
INFO - 2018-08-06 23:37:06 --> Helper loaded: util_helper
INFO - 2018-08-06 23:37:06 --> Helper loaded: text_helper
INFO - 2018-08-06 23:37:06 --> Helper loaded: string_helper
INFO - 2018-08-06 23:37:06 --> Database Driver Class Initialized
DEBUG - 2018-08-06 23:37:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-06 23:37:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-06 23:37:06 --> Email Class Initialized
INFO - 2018-08-06 23:37:06 --> Controller Class Initialized
DEBUG - 2018-08-06 23:37:06 --> Home MX_Controller Initialized
DEBUG - 2018-08-06 23:37:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-06 23:37:06 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-06 23:37:06 --> Login MX_Controller Initialized
INFO - 2018-08-06 23:37:06 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-06 23:37:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-06 23:37:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-06 23:37:10 --> Config Class Initialized
INFO - 2018-08-06 23:37:10 --> Hooks Class Initialized
DEBUG - 2018-08-06 23:37:10 --> UTF-8 Support Enabled
INFO - 2018-08-06 23:37:10 --> Utf8 Class Initialized
INFO - 2018-08-06 23:37:10 --> URI Class Initialized
INFO - 2018-08-06 23:37:10 --> Router Class Initialized
INFO - 2018-08-06 23:37:10 --> Output Class Initialized
INFO - 2018-08-06 23:37:10 --> Security Class Initialized
DEBUG - 2018-08-06 23:37:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-06 23:37:10 --> Input Class Initialized
INFO - 2018-08-06 23:37:10 --> Language Class Initialized
INFO - 2018-08-06 23:37:10 --> Language Class Initialized
INFO - 2018-08-06 23:37:10 --> Config Class Initialized
INFO - 2018-08-06 23:37:10 --> Loader Class Initialized
DEBUG - 2018-08-06 23:37:10 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-06 23:37:10 --> Helper loaded: url_helper
INFO - 2018-08-06 23:37:10 --> Helper loaded: form_helper
INFO - 2018-08-06 23:37:10 --> Helper loaded: date_helper
INFO - 2018-08-06 23:37:10 --> Helper loaded: util_helper
INFO - 2018-08-06 23:37:10 --> Helper loaded: text_helper
INFO - 2018-08-06 23:37:10 --> Helper loaded: string_helper
INFO - 2018-08-06 23:37:10 --> Database Driver Class Initialized
DEBUG - 2018-08-06 23:37:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-06 23:37:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-06 23:37:10 --> Email Class Initialized
INFO - 2018-08-06 23:37:10 --> Controller Class Initialized
DEBUG - 2018-08-06 23:37:10 --> Home MX_Controller Initialized
DEBUG - 2018-08-06 23:37:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-06 23:37:10 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-06 23:37:10 --> Login MX_Controller Initialized
INFO - 2018-08-06 23:37:10 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-06 23:37:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-06 23:37:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-06 23:37:20 --> Config Class Initialized
INFO - 2018-08-06 23:37:20 --> Hooks Class Initialized
DEBUG - 2018-08-06 23:37:20 --> UTF-8 Support Enabled
INFO - 2018-08-06 23:37:20 --> Utf8 Class Initialized
INFO - 2018-08-06 23:37:20 --> URI Class Initialized
INFO - 2018-08-06 23:37:20 --> Router Class Initialized
INFO - 2018-08-06 23:37:20 --> Output Class Initialized
INFO - 2018-08-06 23:37:20 --> Security Class Initialized
DEBUG - 2018-08-06 23:37:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-06 23:37:20 --> Input Class Initialized
INFO - 2018-08-06 23:37:20 --> Language Class Initialized
INFO - 2018-08-06 23:37:20 --> Language Class Initialized
INFO - 2018-08-06 23:37:20 --> Config Class Initialized
INFO - 2018-08-06 23:37:20 --> Loader Class Initialized
DEBUG - 2018-08-06 23:37:20 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-06 23:37:20 --> Helper loaded: url_helper
INFO - 2018-08-06 23:37:20 --> Helper loaded: form_helper
INFO - 2018-08-06 23:37:20 --> Helper loaded: date_helper
INFO - 2018-08-06 23:37:20 --> Helper loaded: util_helper
INFO - 2018-08-06 23:37:20 --> Helper loaded: text_helper
INFO - 2018-08-06 23:37:20 --> Helper loaded: string_helper
INFO - 2018-08-06 23:37:20 --> Database Driver Class Initialized
DEBUG - 2018-08-06 23:37:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-06 23:37:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-06 23:37:21 --> Email Class Initialized
INFO - 2018-08-06 23:37:21 --> Controller Class Initialized
DEBUG - 2018-08-06 23:37:21 --> Home MX_Controller Initialized
DEBUG - 2018-08-06 23:37:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-06 23:37:21 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-06 23:37:21 --> Login MX_Controller Initialized
INFO - 2018-08-06 23:37:21 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-06 23:37:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-06 23:37:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-06 23:37:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-08-06 23:37:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-08-06 23:37:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-08-06 23:37:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-08-06 23:37:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-08-06 23:37:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/search_page.php
INFO - 2018-08-06 23:37:21 --> Final output sent to browser
DEBUG - 2018-08-06 23:37:21 --> Total execution time: 0.5303
INFO - 2018-08-06 23:37:21 --> Config Class Initialized
INFO - 2018-08-06 23:37:21 --> Hooks Class Initialized
INFO - 2018-08-06 23:37:21 --> Config Class Initialized
INFO - 2018-08-06 23:37:21 --> Hooks Class Initialized
DEBUG - 2018-08-06 23:37:21 --> UTF-8 Support Enabled
INFO - 2018-08-06 23:37:21 --> Utf8 Class Initialized
DEBUG - 2018-08-06 23:37:21 --> UTF-8 Support Enabled
INFO - 2018-08-06 23:37:21 --> Utf8 Class Initialized
INFO - 2018-08-06 23:37:21 --> URI Class Initialized
INFO - 2018-08-06 23:37:21 --> URI Class Initialized
INFO - 2018-08-06 23:37:21 --> Router Class Initialized
INFO - 2018-08-06 23:37:21 --> Output Class Initialized
INFO - 2018-08-06 23:37:21 --> Security Class Initialized
DEBUG - 2018-08-06 23:37:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-06 23:37:21 --> Router Class Initialized
INFO - 2018-08-06 23:37:21 --> Input Class Initialized
INFO - 2018-08-06 23:37:21 --> Language Class Initialized
INFO - 2018-08-06 23:37:21 --> Language Class Initialized
INFO - 2018-08-06 23:37:21 --> Output Class Initialized
INFO - 2018-08-06 23:37:21 --> Config Class Initialized
INFO - 2018-08-06 23:37:21 --> Loader Class Initialized
INFO - 2018-08-06 23:37:21 --> Security Class Initialized
DEBUG - 2018-08-06 23:37:21 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-06 23:37:21 --> Helper loaded: url_helper
INFO - 2018-08-06 23:37:21 --> Helper loaded: form_helper
INFO - 2018-08-06 23:37:21 --> Helper loaded: date_helper
INFO - 2018-08-06 23:37:21 --> Helper loaded: util_helper
INFO - 2018-08-06 23:37:21 --> Helper loaded: text_helper
INFO - 2018-08-06 23:37:21 --> Helper loaded: string_helper
DEBUG - 2018-08-06 23:37:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-06 23:37:21 --> Database Driver Class Initialized
INFO - 2018-08-06 23:37:21 --> Input Class Initialized
DEBUG - 2018-08-06 23:37:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-06 23:37:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-06 23:37:21 --> Language Class Initialized
ERROR - 2018-08-06 23:37:22 --> 404 Page Not Found: /index
INFO - 2018-08-06 23:37:22 --> Email Class Initialized
INFO - 2018-08-06 23:37:22 --> Controller Class Initialized
INFO - 2018-08-06 23:37:22 --> Config Class Initialized
INFO - 2018-08-06 23:37:22 --> Hooks Class Initialized
DEBUG - 2018-08-06 23:37:22 --> Home MX_Controller Initialized
DEBUG - 2018-08-06 23:37:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-06 23:37:22 --> UTF-8 Support Enabled
INFO - 2018-08-06 23:37:22 --> Utf8 Class Initialized
DEBUG - 2018-08-06 23:37:22 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-06 23:37:22 --> Login MX_Controller Initialized
INFO - 2018-08-06 23:37:22 --> URI Class Initialized
INFO - 2018-08-06 23:37:22 --> Language file loaded: language/english/data_lang.php
INFO - 2018-08-06 23:37:22 --> Router Class Initialized
DEBUG - 2018-08-06 23:37:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-08-06 23:37:22 --> Output Class Initialized
DEBUG - 2018-08-06 23:37:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-06 23:37:22 --> Security Class Initialized
DEBUG - 2018-08-06 23:37:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-06 23:37:22 --> Input Class Initialized
INFO - 2018-08-06 23:37:22 --> Language Class Initialized
ERROR - 2018-08-06 23:37:22 --> 404 Page Not Found: /index
INFO - 2018-08-06 23:37:22 --> Config Class Initialized
INFO - 2018-08-06 23:37:22 --> Hooks Class Initialized
DEBUG - 2018-08-06 23:37:22 --> UTF-8 Support Enabled
INFO - 2018-08-06 23:37:22 --> Utf8 Class Initialized
INFO - 2018-08-06 23:37:22 --> URI Class Initialized
INFO - 2018-08-06 23:37:22 --> Router Class Initialized
INFO - 2018-08-06 23:37:22 --> Output Class Initialized
INFO - 2018-08-06 23:37:22 --> Security Class Initialized
DEBUG - 2018-08-06 23:37:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-06 23:37:22 --> Input Class Initialized
INFO - 2018-08-06 23:37:22 --> Language Class Initialized
ERROR - 2018-08-06 23:37:22 --> 404 Page Not Found: /index
INFO - 2018-08-06 23:37:36 --> Config Class Initialized
INFO - 2018-08-06 23:37:36 --> Hooks Class Initialized
DEBUG - 2018-08-06 23:37:36 --> UTF-8 Support Enabled
INFO - 2018-08-06 23:37:36 --> Utf8 Class Initialized
INFO - 2018-08-06 23:37:36 --> URI Class Initialized
INFO - 2018-08-06 23:37:36 --> Router Class Initialized
INFO - 2018-08-06 23:37:36 --> Output Class Initialized
INFO - 2018-08-06 23:37:36 --> Security Class Initialized
DEBUG - 2018-08-06 23:37:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-06 23:37:36 --> Input Class Initialized
INFO - 2018-08-06 23:37:36 --> Language Class Initialized
INFO - 2018-08-06 23:37:36 --> Language Class Initialized
INFO - 2018-08-06 23:37:36 --> Config Class Initialized
INFO - 2018-08-06 23:37:36 --> Loader Class Initialized
DEBUG - 2018-08-06 23:37:36 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-06 23:37:36 --> Helper loaded: url_helper
INFO - 2018-08-06 23:37:36 --> Helper loaded: form_helper
INFO - 2018-08-06 23:37:36 --> Helper loaded: date_helper
INFO - 2018-08-06 23:37:36 --> Helper loaded: util_helper
INFO - 2018-08-06 23:37:36 --> Helper loaded: text_helper
INFO - 2018-08-06 23:37:36 --> Helper loaded: string_helper
INFO - 2018-08-06 23:37:36 --> Database Driver Class Initialized
DEBUG - 2018-08-06 23:37:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-06 23:37:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-06 23:37:36 --> Email Class Initialized
INFO - 2018-08-06 23:37:36 --> Controller Class Initialized
DEBUG - 2018-08-06 23:37:36 --> Home MX_Controller Initialized
DEBUG - 2018-08-06 23:37:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-06 23:37:36 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-06 23:37:36 --> Login MX_Controller Initialized
INFO - 2018-08-06 23:37:36 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-06 23:37:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-06 23:37:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-06 23:38:04 --> Config Class Initialized
INFO - 2018-08-06 23:38:04 --> Hooks Class Initialized
DEBUG - 2018-08-06 23:38:04 --> UTF-8 Support Enabled
INFO - 2018-08-06 23:38:04 --> Utf8 Class Initialized
INFO - 2018-08-06 23:38:04 --> URI Class Initialized
INFO - 2018-08-06 23:38:04 --> Router Class Initialized
INFO - 2018-08-06 23:38:04 --> Output Class Initialized
INFO - 2018-08-06 23:38:04 --> Security Class Initialized
DEBUG - 2018-08-06 23:38:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-06 23:38:04 --> Input Class Initialized
INFO - 2018-08-06 23:38:04 --> Language Class Initialized
INFO - 2018-08-06 23:38:04 --> Language Class Initialized
INFO - 2018-08-06 23:38:04 --> Config Class Initialized
INFO - 2018-08-06 23:38:04 --> Loader Class Initialized
DEBUG - 2018-08-06 23:38:04 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-06 23:38:04 --> Helper loaded: url_helper
INFO - 2018-08-06 23:38:04 --> Helper loaded: form_helper
INFO - 2018-08-06 23:38:04 --> Helper loaded: date_helper
INFO - 2018-08-06 23:38:04 --> Helper loaded: util_helper
INFO - 2018-08-06 23:38:04 --> Helper loaded: text_helper
INFO - 2018-08-06 23:38:04 --> Helper loaded: string_helper
INFO - 2018-08-06 23:38:04 --> Database Driver Class Initialized
DEBUG - 2018-08-06 23:38:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-06 23:38:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-06 23:38:05 --> Email Class Initialized
INFO - 2018-08-06 23:38:05 --> Controller Class Initialized
DEBUG - 2018-08-06 23:38:05 --> Home MX_Controller Initialized
DEBUG - 2018-08-06 23:38:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-06 23:38:05 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-06 23:38:05 --> Login MX_Controller Initialized
INFO - 2018-08-06 23:38:05 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-06 23:38:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-06 23:38:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-06 23:38:22 --> Config Class Initialized
INFO - 2018-08-06 23:38:22 --> Hooks Class Initialized
DEBUG - 2018-08-06 23:38:22 --> UTF-8 Support Enabled
INFO - 2018-08-06 23:38:22 --> Utf8 Class Initialized
INFO - 2018-08-06 23:38:22 --> URI Class Initialized
INFO - 2018-08-06 23:38:22 --> Router Class Initialized
INFO - 2018-08-06 23:38:22 --> Output Class Initialized
INFO - 2018-08-06 23:38:22 --> Security Class Initialized
DEBUG - 2018-08-06 23:38:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-06 23:38:22 --> Input Class Initialized
INFO - 2018-08-06 23:38:22 --> Language Class Initialized
INFO - 2018-08-06 23:38:22 --> Language Class Initialized
INFO - 2018-08-06 23:38:22 --> Config Class Initialized
INFO - 2018-08-06 23:38:22 --> Loader Class Initialized
DEBUG - 2018-08-06 23:38:22 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-06 23:38:22 --> Helper loaded: url_helper
INFO - 2018-08-06 23:38:22 --> Helper loaded: form_helper
INFO - 2018-08-06 23:38:22 --> Helper loaded: date_helper
INFO - 2018-08-06 23:38:22 --> Helper loaded: util_helper
INFO - 2018-08-06 23:38:22 --> Helper loaded: text_helper
INFO - 2018-08-06 23:38:22 --> Helper loaded: string_helper
INFO - 2018-08-06 23:38:22 --> Database Driver Class Initialized
DEBUG - 2018-08-06 23:38:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-06 23:38:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-06 23:38:22 --> Email Class Initialized
INFO - 2018-08-06 23:38:22 --> Controller Class Initialized
DEBUG - 2018-08-06 23:38:22 --> Home MX_Controller Initialized
DEBUG - 2018-08-06 23:38:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-06 23:38:22 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-06 23:38:22 --> Login MX_Controller Initialized
INFO - 2018-08-06 23:38:22 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-06 23:38:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-06 23:38:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-06 23:40:35 --> Config Class Initialized
INFO - 2018-08-06 23:40:35 --> Hooks Class Initialized
DEBUG - 2018-08-06 23:40:35 --> UTF-8 Support Enabled
INFO - 2018-08-06 23:40:35 --> Utf8 Class Initialized
INFO - 2018-08-06 23:40:35 --> URI Class Initialized
INFO - 2018-08-06 23:40:35 --> Router Class Initialized
INFO - 2018-08-06 23:40:35 --> Output Class Initialized
INFO - 2018-08-06 23:40:35 --> Security Class Initialized
DEBUG - 2018-08-06 23:40:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-06 23:40:35 --> Input Class Initialized
INFO - 2018-08-06 23:40:35 --> Language Class Initialized
INFO - 2018-08-06 23:40:35 --> Language Class Initialized
INFO - 2018-08-06 23:40:35 --> Config Class Initialized
INFO - 2018-08-06 23:40:35 --> Loader Class Initialized
DEBUG - 2018-08-06 23:40:35 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-06 23:40:35 --> Helper loaded: url_helper
INFO - 2018-08-06 23:40:35 --> Helper loaded: form_helper
INFO - 2018-08-06 23:40:35 --> Helper loaded: date_helper
INFO - 2018-08-06 23:40:35 --> Helper loaded: util_helper
INFO - 2018-08-06 23:40:35 --> Helper loaded: text_helper
INFO - 2018-08-06 23:40:35 --> Helper loaded: string_helper
INFO - 2018-08-06 23:40:35 --> Database Driver Class Initialized
DEBUG - 2018-08-06 23:40:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-06 23:40:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-06 23:40:35 --> Email Class Initialized
INFO - 2018-08-06 23:40:35 --> Controller Class Initialized
DEBUG - 2018-08-06 23:40:35 --> Home MX_Controller Initialized
DEBUG - 2018-08-06 23:40:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-06 23:40:36 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-06 23:40:36 --> Login MX_Controller Initialized
INFO - 2018-08-06 23:40:36 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-06 23:40:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-06 23:40:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
ERROR - 2018-08-06 23:40:36 --> Severity: Notice --> Undefined variable: get_pro_chapt1 E:\xampp\htdocs\consulting\application\modules\home\controllers\Home.php 239
ERROR - 2018-08-06 23:40:36 --> Severity: error --> Exception: Call to a member function num_rows() on null E:\xampp\htdocs\consulting\application\modules\home\controllers\Home.php 239
INFO - 2018-08-06 23:40:53 --> Config Class Initialized
INFO - 2018-08-06 23:40:53 --> Hooks Class Initialized
DEBUG - 2018-08-06 23:40:53 --> UTF-8 Support Enabled
INFO - 2018-08-06 23:40:53 --> Utf8 Class Initialized
INFO - 2018-08-06 23:40:53 --> URI Class Initialized
INFO - 2018-08-06 23:40:53 --> Router Class Initialized
INFO - 2018-08-06 23:40:53 --> Output Class Initialized
INFO - 2018-08-06 23:40:53 --> Security Class Initialized
DEBUG - 2018-08-06 23:40:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-06 23:40:53 --> Input Class Initialized
INFO - 2018-08-06 23:40:53 --> Language Class Initialized
INFO - 2018-08-06 23:40:53 --> Language Class Initialized
INFO - 2018-08-06 23:40:53 --> Config Class Initialized
INFO - 2018-08-06 23:40:53 --> Loader Class Initialized
DEBUG - 2018-08-06 23:40:53 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-06 23:40:53 --> Helper loaded: url_helper
INFO - 2018-08-06 23:40:53 --> Helper loaded: form_helper
INFO - 2018-08-06 23:40:53 --> Helper loaded: date_helper
INFO - 2018-08-06 23:40:53 --> Helper loaded: util_helper
INFO - 2018-08-06 23:40:53 --> Helper loaded: text_helper
INFO - 2018-08-06 23:40:53 --> Helper loaded: string_helper
INFO - 2018-08-06 23:40:53 --> Database Driver Class Initialized
DEBUG - 2018-08-06 23:40:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-06 23:40:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-06 23:40:53 --> Email Class Initialized
INFO - 2018-08-06 23:40:53 --> Controller Class Initialized
DEBUG - 2018-08-06 23:40:53 --> Home MX_Controller Initialized
DEBUG - 2018-08-06 23:40:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-06 23:40:53 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-06 23:40:53 --> Login MX_Controller Initialized
INFO - 2018-08-06 23:40:53 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-06 23:40:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-06 23:40:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-06 23:41:11 --> Config Class Initialized
INFO - 2018-08-06 23:41:11 --> Hooks Class Initialized
DEBUG - 2018-08-06 23:41:11 --> UTF-8 Support Enabled
INFO - 2018-08-06 23:41:11 --> Utf8 Class Initialized
INFO - 2018-08-06 23:41:11 --> URI Class Initialized
INFO - 2018-08-06 23:41:11 --> Router Class Initialized
INFO - 2018-08-06 23:41:11 --> Output Class Initialized
INFO - 2018-08-06 23:41:11 --> Security Class Initialized
DEBUG - 2018-08-06 23:41:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-06 23:41:11 --> Input Class Initialized
INFO - 2018-08-06 23:41:11 --> Language Class Initialized
INFO - 2018-08-06 23:41:11 --> Language Class Initialized
INFO - 2018-08-06 23:41:11 --> Config Class Initialized
INFO - 2018-08-06 23:41:11 --> Loader Class Initialized
DEBUG - 2018-08-06 23:41:11 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-06 23:41:11 --> Helper loaded: url_helper
INFO - 2018-08-06 23:41:11 --> Helper loaded: form_helper
INFO - 2018-08-06 23:41:11 --> Helper loaded: date_helper
INFO - 2018-08-06 23:41:11 --> Helper loaded: util_helper
INFO - 2018-08-06 23:41:11 --> Helper loaded: text_helper
INFO - 2018-08-06 23:41:11 --> Helper loaded: string_helper
INFO - 2018-08-06 23:41:11 --> Database Driver Class Initialized
DEBUG - 2018-08-06 23:41:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-06 23:41:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-06 23:41:11 --> Email Class Initialized
INFO - 2018-08-06 23:41:11 --> Controller Class Initialized
DEBUG - 2018-08-06 23:41:11 --> Home MX_Controller Initialized
DEBUG - 2018-08-06 23:41:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-06 23:41:11 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-06 23:41:11 --> Login MX_Controller Initialized
INFO - 2018-08-06 23:41:11 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-06 23:41:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-06 23:41:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-06 23:44:01 --> Config Class Initialized
INFO - 2018-08-06 23:44:01 --> Hooks Class Initialized
DEBUG - 2018-08-06 23:44:01 --> UTF-8 Support Enabled
INFO - 2018-08-06 23:44:01 --> Utf8 Class Initialized
INFO - 2018-08-06 23:44:01 --> URI Class Initialized
INFO - 2018-08-06 23:44:01 --> Router Class Initialized
INFO - 2018-08-06 23:44:01 --> Output Class Initialized
INFO - 2018-08-06 23:44:01 --> Security Class Initialized
DEBUG - 2018-08-06 23:44:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-06 23:44:01 --> Input Class Initialized
INFO - 2018-08-06 23:44:01 --> Language Class Initialized
INFO - 2018-08-06 23:44:01 --> Language Class Initialized
INFO - 2018-08-06 23:44:01 --> Config Class Initialized
INFO - 2018-08-06 23:44:01 --> Loader Class Initialized
DEBUG - 2018-08-06 23:44:01 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-06 23:44:01 --> Helper loaded: url_helper
INFO - 2018-08-06 23:44:01 --> Helper loaded: form_helper
INFO - 2018-08-06 23:44:01 --> Helper loaded: date_helper
INFO - 2018-08-06 23:44:01 --> Helper loaded: util_helper
INFO - 2018-08-06 23:44:01 --> Helper loaded: text_helper
INFO - 2018-08-06 23:44:01 --> Helper loaded: string_helper
INFO - 2018-08-06 23:44:01 --> Database Driver Class Initialized
DEBUG - 2018-08-06 23:44:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-06 23:44:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-06 23:44:01 --> Email Class Initialized
INFO - 2018-08-06 23:44:01 --> Controller Class Initialized
DEBUG - 2018-08-06 23:44:02 --> Home MX_Controller Initialized
DEBUG - 2018-08-06 23:44:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-06 23:44:02 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-06 23:44:02 --> Login MX_Controller Initialized
INFO - 2018-08-06 23:44:02 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-06 23:44:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-06 23:44:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-06 23:44:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-08-06 23:44:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-08-06 23:44:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-08-06 23:44:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-08-06 23:44:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-08-06 23:44:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/search_page.php
INFO - 2018-08-06 23:44:02 --> Final output sent to browser
DEBUG - 2018-08-06 23:44:02 --> Total execution time: 0.5349
INFO - 2018-08-06 23:44:02 --> Config Class Initialized
INFO - 2018-08-06 23:44:02 --> Hooks Class Initialized
DEBUG - 2018-08-06 23:44:02 --> UTF-8 Support Enabled
INFO - 2018-08-06 23:44:02 --> Config Class Initialized
INFO - 2018-08-06 23:44:02 --> Hooks Class Initialized
INFO - 2018-08-06 23:44:02 --> Utf8 Class Initialized
DEBUG - 2018-08-06 23:44:02 --> UTF-8 Support Enabled
INFO - 2018-08-06 23:44:02 --> URI Class Initialized
INFO - 2018-08-06 23:44:02 --> Utf8 Class Initialized
INFO - 2018-08-06 23:44:02 --> URI Class Initialized
INFO - 2018-08-06 23:44:02 --> Router Class Initialized
INFO - 2018-08-06 23:44:02 --> Output Class Initialized
INFO - 2018-08-06 23:44:02 --> Router Class Initialized
INFO - 2018-08-06 23:44:02 --> Security Class Initialized
INFO - 2018-08-06 23:44:02 --> Output Class Initialized
DEBUG - 2018-08-06 23:44:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-06 23:44:02 --> Input Class Initialized
INFO - 2018-08-06 23:44:02 --> Language Class Initialized
INFO - 2018-08-06 23:44:02 --> Security Class Initialized
DEBUG - 2018-08-06 23:44:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-06 23:44:02 --> Language Class Initialized
INFO - 2018-08-06 23:44:02 --> Input Class Initialized
INFO - 2018-08-06 23:44:02 --> Language Class Initialized
ERROR - 2018-08-06 23:44:02 --> 404 Page Not Found: /index
INFO - 2018-08-06 23:44:02 --> Config Class Initialized
INFO - 2018-08-06 23:44:02 --> Config Class Initialized
INFO - 2018-08-06 23:44:02 --> Hooks Class Initialized
INFO - 2018-08-06 23:44:02 --> Loader Class Initialized
DEBUG - 2018-08-06 23:44:02 --> UTF-8 Support Enabled
DEBUG - 2018-08-06 23:44:02 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-06 23:44:02 --> Utf8 Class Initialized
INFO - 2018-08-06 23:44:02 --> URI Class Initialized
INFO - 2018-08-06 23:44:02 --> Router Class Initialized
INFO - 2018-08-06 23:44:02 --> Helper loaded: url_helper
INFO - 2018-08-06 23:44:02 --> Output Class Initialized
INFO - 2018-08-06 23:44:02 --> Security Class Initialized
DEBUG - 2018-08-06 23:44:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-06 23:44:03 --> Input Class Initialized
INFO - 2018-08-06 23:44:03 --> Language Class Initialized
ERROR - 2018-08-06 23:44:03 --> 404 Page Not Found: /index
INFO - 2018-08-06 23:44:03 --> Helper loaded: form_helper
INFO - 2018-08-06 23:44:03 --> Config Class Initialized
INFO - 2018-08-06 23:44:03 --> Hooks Class Initialized
INFO - 2018-08-06 23:44:03 --> Helper loaded: date_helper
DEBUG - 2018-08-06 23:44:03 --> UTF-8 Support Enabled
INFO - 2018-08-06 23:44:03 --> Helper loaded: util_helper
INFO - 2018-08-06 23:44:03 --> Utf8 Class Initialized
INFO - 2018-08-06 23:44:03 --> Helper loaded: text_helper
INFO - 2018-08-06 23:44:03 --> URI Class Initialized
INFO - 2018-08-06 23:44:03 --> Helper loaded: string_helper
INFO - 2018-08-06 23:44:03 --> Router Class Initialized
INFO - 2018-08-06 23:44:03 --> Output Class Initialized
INFO - 2018-08-06 23:44:03 --> Database Driver Class Initialized
INFO - 2018-08-06 23:44:03 --> Security Class Initialized
DEBUG - 2018-08-06 23:44:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-06 23:44:03 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-08-06 23:44:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-06 23:44:03 --> Input Class Initialized
INFO - 2018-08-06 23:44:03 --> Email Class Initialized
INFO - 2018-08-06 23:44:03 --> Controller Class Initialized
INFO - 2018-08-06 23:44:03 --> Language Class Initialized
DEBUG - 2018-08-06 23:44:03 --> Home MX_Controller Initialized
ERROR - 2018-08-06 23:44:03 --> 404 Page Not Found: /index
DEBUG - 2018-08-06 23:44:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-06 23:44:03 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-06 23:44:03 --> Login MX_Controller Initialized
INFO - 2018-08-06 23:44:03 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-06 23:44:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-06 23:44:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-06 23:44:21 --> Config Class Initialized
INFO - 2018-08-06 23:44:21 --> Hooks Class Initialized
DEBUG - 2018-08-06 23:44:21 --> UTF-8 Support Enabled
INFO - 2018-08-06 23:44:21 --> Utf8 Class Initialized
INFO - 2018-08-06 23:44:21 --> URI Class Initialized
INFO - 2018-08-06 23:44:21 --> Router Class Initialized
INFO - 2018-08-06 23:44:21 --> Output Class Initialized
INFO - 2018-08-06 23:44:21 --> Security Class Initialized
DEBUG - 2018-08-06 23:44:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-06 23:44:21 --> Input Class Initialized
INFO - 2018-08-06 23:44:21 --> Language Class Initialized
INFO - 2018-08-06 23:44:21 --> Language Class Initialized
INFO - 2018-08-06 23:44:21 --> Config Class Initialized
INFO - 2018-08-06 23:44:21 --> Loader Class Initialized
DEBUG - 2018-08-06 23:44:21 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-06 23:44:21 --> Helper loaded: url_helper
INFO - 2018-08-06 23:44:21 --> Helper loaded: form_helper
INFO - 2018-08-06 23:44:21 --> Helper loaded: date_helper
INFO - 2018-08-06 23:44:21 --> Helper loaded: util_helper
INFO - 2018-08-06 23:44:21 --> Helper loaded: text_helper
INFO - 2018-08-06 23:44:21 --> Helper loaded: string_helper
INFO - 2018-08-06 23:44:21 --> Database Driver Class Initialized
DEBUG - 2018-08-06 23:44:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-06 23:44:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-06 23:44:22 --> Email Class Initialized
INFO - 2018-08-06 23:44:22 --> Controller Class Initialized
DEBUG - 2018-08-06 23:44:22 --> Home MX_Controller Initialized
DEBUG - 2018-08-06 23:44:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-06 23:44:22 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-06 23:44:22 --> Login MX_Controller Initialized
INFO - 2018-08-06 23:44:22 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-06 23:44:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-06 23:44:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-06 23:44:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-08-06 23:44:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-08-06 23:44:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-08-06 23:44:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-08-06 23:44:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-08-06 23:44:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/search_page.php
INFO - 2018-08-06 23:44:22 --> Final output sent to browser
DEBUG - 2018-08-06 23:44:22 --> Total execution time: 0.5199
INFO - 2018-08-06 23:44:22 --> Config Class Initialized
INFO - 2018-08-06 23:44:22 --> Hooks Class Initialized
DEBUG - 2018-08-06 23:44:22 --> UTF-8 Support Enabled
INFO - 2018-08-06 23:44:22 --> Config Class Initialized
INFO - 2018-08-06 23:44:22 --> Hooks Class Initialized
INFO - 2018-08-06 23:44:22 --> Utf8 Class Initialized
DEBUG - 2018-08-06 23:44:22 --> UTF-8 Support Enabled
INFO - 2018-08-06 23:44:22 --> URI Class Initialized
INFO - 2018-08-06 23:44:22 --> Utf8 Class Initialized
INFO - 2018-08-06 23:44:22 --> URI Class Initialized
INFO - 2018-08-06 23:44:22 --> Router Class Initialized
INFO - 2018-08-06 23:44:22 --> Output Class Initialized
INFO - 2018-08-06 23:44:22 --> Security Class Initialized
DEBUG - 2018-08-06 23:44:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-06 23:44:22 --> Router Class Initialized
INFO - 2018-08-06 23:44:22 --> Input Class Initialized
INFO - 2018-08-06 23:44:22 --> Output Class Initialized
INFO - 2018-08-06 23:44:22 --> Security Class Initialized
INFO - 2018-08-06 23:44:22 --> Language Class Initialized
DEBUG - 2018-08-06 23:44:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-06 23:44:22 --> Language Class Initialized
INFO - 2018-08-06 23:44:22 --> Input Class Initialized
INFO - 2018-08-06 23:44:22 --> Config Class Initialized
INFO - 2018-08-06 23:44:22 --> Language Class Initialized
INFO - 2018-08-06 23:44:22 --> Loader Class Initialized
ERROR - 2018-08-06 23:44:22 --> 404 Page Not Found: /index
DEBUG - 2018-08-06 23:44:22 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-06 23:44:22 --> Config Class Initialized
INFO - 2018-08-06 23:44:22 --> Hooks Class Initialized
INFO - 2018-08-06 23:44:22 --> Helper loaded: url_helper
INFO - 2018-08-06 23:44:22 --> Helper loaded: form_helper
DEBUG - 2018-08-06 23:44:22 --> UTF-8 Support Enabled
INFO - 2018-08-06 23:44:22 --> Utf8 Class Initialized
INFO - 2018-08-06 23:44:22 --> Helper loaded: date_helper
INFO - 2018-08-06 23:44:22 --> Helper loaded: util_helper
INFO - 2018-08-06 23:44:22 --> URI Class Initialized
INFO - 2018-08-06 23:44:22 --> Router Class Initialized
INFO - 2018-08-06 23:44:22 --> Helper loaded: text_helper
INFO - 2018-08-06 23:44:22 --> Output Class Initialized
INFO - 2018-08-06 23:44:22 --> Helper loaded: string_helper
INFO - 2018-08-06 23:44:22 --> Security Class Initialized
INFO - 2018-08-06 23:44:22 --> Database Driver Class Initialized
DEBUG - 2018-08-06 23:44:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-06 23:44:22 --> Input Class Initialized
DEBUG - 2018-08-06 23:44:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-06 23:44:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-06 23:44:23 --> Language Class Initialized
ERROR - 2018-08-06 23:44:23 --> 404 Page Not Found: /index
INFO - 2018-08-06 23:44:23 --> Email Class Initialized
INFO - 2018-08-06 23:44:23 --> Controller Class Initialized
INFO - 2018-08-06 23:44:23 --> Config Class Initialized
DEBUG - 2018-08-06 23:44:23 --> Home MX_Controller Initialized
INFO - 2018-08-06 23:44:23 --> Hooks Class Initialized
DEBUG - 2018-08-06 23:44:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-06 23:44:23 --> UTF-8 Support Enabled
INFO - 2018-08-06 23:44:23 --> Utf8 Class Initialized
DEBUG - 2018-08-06 23:44:23 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-06 23:44:23 --> Login MX_Controller Initialized
INFO - 2018-08-06 23:44:23 --> URI Class Initialized
INFO - 2018-08-06 23:44:23 --> Language file loaded: language/english/data_lang.php
INFO - 2018-08-06 23:44:23 --> Router Class Initialized
DEBUG - 2018-08-06 23:44:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-08-06 23:44:23 --> Output Class Initialized
DEBUG - 2018-08-06 23:44:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-06 23:44:23 --> Security Class Initialized
DEBUG - 2018-08-06 23:44:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-06 23:44:23 --> Input Class Initialized
INFO - 2018-08-06 23:44:23 --> Language Class Initialized
ERROR - 2018-08-06 23:44:23 --> 404 Page Not Found: /index
INFO - 2018-08-06 23:47:03 --> Config Class Initialized
INFO - 2018-08-06 23:47:03 --> Hooks Class Initialized
DEBUG - 2018-08-06 23:47:03 --> UTF-8 Support Enabled
INFO - 2018-08-06 23:47:03 --> Utf8 Class Initialized
INFO - 2018-08-06 23:47:03 --> URI Class Initialized
INFO - 2018-08-06 23:47:03 --> Router Class Initialized
INFO - 2018-08-06 23:47:03 --> Output Class Initialized
INFO - 2018-08-06 23:47:03 --> Security Class Initialized
DEBUG - 2018-08-06 23:47:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-06 23:47:03 --> Input Class Initialized
INFO - 2018-08-06 23:47:03 --> Language Class Initialized
INFO - 2018-08-06 23:47:03 --> Language Class Initialized
INFO - 2018-08-06 23:47:03 --> Config Class Initialized
INFO - 2018-08-06 23:47:03 --> Loader Class Initialized
DEBUG - 2018-08-06 23:47:03 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-06 23:47:03 --> Helper loaded: url_helper
INFO - 2018-08-06 23:47:03 --> Helper loaded: form_helper
INFO - 2018-08-06 23:47:03 --> Helper loaded: date_helper
INFO - 2018-08-06 23:47:03 --> Helper loaded: util_helper
INFO - 2018-08-06 23:47:03 --> Helper loaded: text_helper
INFO - 2018-08-06 23:47:03 --> Helper loaded: string_helper
INFO - 2018-08-06 23:47:03 --> Database Driver Class Initialized
DEBUG - 2018-08-06 23:47:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-06 23:47:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-06 23:47:03 --> Email Class Initialized
INFO - 2018-08-06 23:47:03 --> Controller Class Initialized
DEBUG - 2018-08-06 23:47:03 --> Home MX_Controller Initialized
DEBUG - 2018-08-06 23:47:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-06 23:47:03 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-06 23:47:03 --> Login MX_Controller Initialized
INFO - 2018-08-06 23:47:03 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-06 23:47:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-06 23:47:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-06 23:47:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-08-06 23:47:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-08-06 23:47:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-08-06 23:47:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-08-06 23:47:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-08-06 23:47:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/search_page.php
INFO - 2018-08-06 23:47:04 --> Final output sent to browser
DEBUG - 2018-08-06 23:47:04 --> Total execution time: 0.6225
INFO - 2018-08-06 23:47:04 --> Config Class Initialized
INFO - 2018-08-06 23:47:04 --> Hooks Class Initialized
INFO - 2018-08-06 23:47:04 --> Config Class Initialized
DEBUG - 2018-08-06 23:47:04 --> UTF-8 Support Enabled
INFO - 2018-08-06 23:47:04 --> Hooks Class Initialized
INFO - 2018-08-06 23:47:04 --> Utf8 Class Initialized
DEBUG - 2018-08-06 23:47:04 --> UTF-8 Support Enabled
INFO - 2018-08-06 23:47:04 --> Utf8 Class Initialized
INFO - 2018-08-06 23:47:04 --> URI Class Initialized
INFO - 2018-08-06 23:47:04 --> URI Class Initialized
INFO - 2018-08-06 23:47:04 --> Router Class Initialized
INFO - 2018-08-06 23:47:04 --> Output Class Initialized
INFO - 2018-08-06 23:47:04 --> Security Class Initialized
INFO - 2018-08-06 23:47:04 --> Router Class Initialized
DEBUG - 2018-08-06 23:47:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-06 23:47:04 --> Output Class Initialized
INFO - 2018-08-06 23:47:04 --> Input Class Initialized
INFO - 2018-08-06 23:47:04 --> Language Class Initialized
INFO - 2018-08-06 23:47:04 --> Security Class Initialized
DEBUG - 2018-08-06 23:47:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-06 23:47:04 --> Language Class Initialized
INFO - 2018-08-06 23:47:04 --> Input Class Initialized
INFO - 2018-08-06 23:47:04 --> Config Class Initialized
INFO - 2018-08-06 23:47:04 --> Language Class Initialized
INFO - 2018-08-06 23:47:04 --> Loader Class Initialized
ERROR - 2018-08-06 23:47:04 --> 404 Page Not Found: /index
DEBUG - 2018-08-06 23:47:04 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-06 23:47:04 --> Helper loaded: url_helper
INFO - 2018-08-06 23:47:04 --> Config Class Initialized
INFO - 2018-08-06 23:47:04 --> Hooks Class Initialized
INFO - 2018-08-06 23:47:04 --> Helper loaded: form_helper
DEBUG - 2018-08-06 23:47:04 --> UTF-8 Support Enabled
INFO - 2018-08-06 23:47:04 --> Helper loaded: date_helper
INFO - 2018-08-06 23:47:04 --> Utf8 Class Initialized
INFO - 2018-08-06 23:47:04 --> URI Class Initialized
INFO - 2018-08-06 23:47:04 --> Router Class Initialized
INFO - 2018-08-06 23:47:04 --> Helper loaded: util_helper
INFO - 2018-08-06 23:47:04 --> Output Class Initialized
INFO - 2018-08-06 23:47:04 --> Security Class Initialized
DEBUG - 2018-08-06 23:47:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-06 23:47:04 --> Input Class Initialized
INFO - 2018-08-06 23:47:04 --> Language Class Initialized
ERROR - 2018-08-06 23:47:04 --> 404 Page Not Found: /index
INFO - 2018-08-06 23:47:04 --> Config Class Initialized
INFO - 2018-08-06 23:47:04 --> Helper loaded: text_helper
INFO - 2018-08-06 23:47:04 --> Hooks Class Initialized
INFO - 2018-08-06 23:47:04 --> Helper loaded: string_helper
DEBUG - 2018-08-06 23:47:04 --> UTF-8 Support Enabled
INFO - 2018-08-06 23:47:04 --> Utf8 Class Initialized
INFO - 2018-08-06 23:47:04 --> Database Driver Class Initialized
INFO - 2018-08-06 23:47:04 --> URI Class Initialized
DEBUG - 2018-08-06 23:47:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-06 23:47:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-06 23:47:04 --> Router Class Initialized
INFO - 2018-08-06 23:47:04 --> Output Class Initialized
INFO - 2018-08-06 23:47:04 --> Email Class Initialized
INFO - 2018-08-06 23:47:04 --> Controller Class Initialized
INFO - 2018-08-06 23:47:04 --> Security Class Initialized
DEBUG - 2018-08-06 23:47:04 --> Home MX_Controller Initialized
DEBUG - 2018-08-06 23:47:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-06 23:47:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-06 23:47:04 --> Input Class Initialized
DEBUG - 2018-08-06 23:47:04 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-06 23:47:04 --> Login MX_Controller Initialized
INFO - 2018-08-06 23:47:04 --> Language Class Initialized
ERROR - 2018-08-06 23:47:04 --> 404 Page Not Found: /index
INFO - 2018-08-06 23:47:04 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-06 23:47:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-06 23:47:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-06 23:47:46 --> Config Class Initialized
INFO - 2018-08-06 23:47:46 --> Hooks Class Initialized
DEBUG - 2018-08-06 23:47:46 --> UTF-8 Support Enabled
INFO - 2018-08-06 23:47:46 --> Utf8 Class Initialized
INFO - 2018-08-06 23:47:46 --> URI Class Initialized
INFO - 2018-08-06 23:47:46 --> Router Class Initialized
INFO - 2018-08-06 23:47:46 --> Output Class Initialized
INFO - 2018-08-06 23:47:46 --> Security Class Initialized
DEBUG - 2018-08-06 23:47:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-06 23:47:46 --> Input Class Initialized
INFO - 2018-08-06 23:47:46 --> Language Class Initialized
INFO - 2018-08-06 23:47:46 --> Language Class Initialized
INFO - 2018-08-06 23:47:46 --> Config Class Initialized
INFO - 2018-08-06 23:47:46 --> Loader Class Initialized
DEBUG - 2018-08-06 23:47:46 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-06 23:47:46 --> Helper loaded: url_helper
INFO - 2018-08-06 23:47:46 --> Helper loaded: form_helper
INFO - 2018-08-06 23:47:46 --> Helper loaded: date_helper
INFO - 2018-08-06 23:47:46 --> Helper loaded: util_helper
INFO - 2018-08-06 23:47:46 --> Helper loaded: text_helper
INFO - 2018-08-06 23:47:46 --> Helper loaded: string_helper
INFO - 2018-08-06 23:47:46 --> Database Driver Class Initialized
DEBUG - 2018-08-06 23:47:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-06 23:47:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-06 23:47:46 --> Email Class Initialized
INFO - 2018-08-06 23:47:46 --> Controller Class Initialized
DEBUG - 2018-08-06 23:47:46 --> Home MX_Controller Initialized
DEBUG - 2018-08-06 23:47:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-06 23:47:47 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-06 23:47:47 --> Login MX_Controller Initialized
INFO - 2018-08-06 23:47:47 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-06 23:47:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-06 23:47:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-06 23:47:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-08-06 23:47:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-08-06 23:47:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-08-06 23:47:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-08-06 23:47:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-08-06 23:47:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/search_page.php
INFO - 2018-08-06 23:47:47 --> Final output sent to browser
DEBUG - 2018-08-06 23:47:47 --> Total execution time: 0.5699
INFO - 2018-08-06 23:47:47 --> Config Class Initialized
INFO - 2018-08-06 23:47:47 --> Hooks Class Initialized
DEBUG - 2018-08-06 23:47:47 --> UTF-8 Support Enabled
INFO - 2018-08-06 23:47:47 --> Config Class Initialized
INFO - 2018-08-06 23:47:47 --> Utf8 Class Initialized
INFO - 2018-08-06 23:47:47 --> Hooks Class Initialized
DEBUG - 2018-08-06 23:47:47 --> UTF-8 Support Enabled
INFO - 2018-08-06 23:47:47 --> URI Class Initialized
INFO - 2018-08-06 23:47:47 --> Utf8 Class Initialized
INFO - 2018-08-06 23:47:47 --> URI Class Initialized
INFO - 2018-08-06 23:47:47 --> Router Class Initialized
INFO - 2018-08-06 23:47:47 --> Output Class Initialized
INFO - 2018-08-06 23:47:47 --> Security Class Initialized
DEBUG - 2018-08-06 23:47:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-06 23:47:47 --> Input Class Initialized
INFO - 2018-08-06 23:47:47 --> Language Class Initialized
INFO - 2018-08-06 23:47:47 --> Router Class Initialized
INFO - 2018-08-06 23:47:47 --> Output Class Initialized
INFO - 2018-08-06 23:47:47 --> Language Class Initialized
INFO - 2018-08-06 23:47:47 --> Config Class Initialized
INFO - 2018-08-06 23:47:47 --> Security Class Initialized
INFO - 2018-08-06 23:47:47 --> Loader Class Initialized
DEBUG - 2018-08-06 23:47:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-08-06 23:47:47 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-06 23:47:47 --> Input Class Initialized
INFO - 2018-08-06 23:47:47 --> Language Class Initialized
INFO - 2018-08-06 23:47:47 --> Helper loaded: url_helper
INFO - 2018-08-06 23:47:47 --> Helper loaded: form_helper
ERROR - 2018-08-06 23:47:47 --> 404 Page Not Found: /index
INFO - 2018-08-06 23:47:47 --> Helper loaded: date_helper
INFO - 2018-08-06 23:47:47 --> Config Class Initialized
INFO - 2018-08-06 23:47:47 --> Hooks Class Initialized
INFO - 2018-08-06 23:47:47 --> Helper loaded: util_helper
DEBUG - 2018-08-06 23:47:47 --> UTF-8 Support Enabled
INFO - 2018-08-06 23:47:47 --> Helper loaded: text_helper
INFO - 2018-08-06 23:47:47 --> Utf8 Class Initialized
INFO - 2018-08-06 23:47:47 --> Helper loaded: string_helper
INFO - 2018-08-06 23:47:47 --> URI Class Initialized
INFO - 2018-08-06 23:47:47 --> Database Driver Class Initialized
INFO - 2018-08-06 23:47:47 --> Router Class Initialized
DEBUG - 2018-08-06 23:47:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-06 23:47:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-06 23:47:47 --> Output Class Initialized
INFO - 2018-08-06 23:47:47 --> Email Class Initialized
INFO - 2018-08-06 23:47:47 --> Security Class Initialized
INFO - 2018-08-06 23:47:47 --> Controller Class Initialized
DEBUG - 2018-08-06 23:47:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-08-06 23:47:47 --> Home MX_Controller Initialized
INFO - 2018-08-06 23:47:47 --> Input Class Initialized
DEBUG - 2018-08-06 23:47:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-08-06 23:47:47 --> Language Class Initialized
ERROR - 2018-08-06 23:47:47 --> 404 Page Not Found: /index
DEBUG - 2018-08-06 23:47:47 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-06 23:47:47 --> Login MX_Controller Initialized
INFO - 2018-08-06 23:47:48 --> Config Class Initialized
INFO - 2018-08-06 23:47:48 --> Hooks Class Initialized
INFO - 2018-08-06 23:47:48 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-06 23:47:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-06 23:47:48 --> UTF-8 Support Enabled
INFO - 2018-08-06 23:47:48 --> Utf8 Class Initialized
DEBUG - 2018-08-06 23:47:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-06 23:47:48 --> URI Class Initialized
INFO - 2018-08-06 23:47:48 --> Router Class Initialized
INFO - 2018-08-06 23:47:48 --> Output Class Initialized
INFO - 2018-08-06 23:47:48 --> Security Class Initialized
DEBUG - 2018-08-06 23:47:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-06 23:47:48 --> Input Class Initialized
INFO - 2018-08-06 23:47:48 --> Language Class Initialized
ERROR - 2018-08-06 23:47:48 --> 404 Page Not Found: /index
INFO - 2018-08-06 23:48:15 --> Config Class Initialized
INFO - 2018-08-06 23:48:15 --> Hooks Class Initialized
DEBUG - 2018-08-06 23:48:15 --> UTF-8 Support Enabled
INFO - 2018-08-06 23:48:15 --> Utf8 Class Initialized
INFO - 2018-08-06 23:48:15 --> URI Class Initialized
INFO - 2018-08-06 23:48:15 --> Router Class Initialized
INFO - 2018-08-06 23:48:15 --> Output Class Initialized
INFO - 2018-08-06 23:48:15 --> Security Class Initialized
DEBUG - 2018-08-06 23:48:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-06 23:48:15 --> Input Class Initialized
INFO - 2018-08-06 23:48:15 --> Language Class Initialized
INFO - 2018-08-06 23:48:15 --> Language Class Initialized
INFO - 2018-08-06 23:48:15 --> Config Class Initialized
INFO - 2018-08-06 23:48:15 --> Loader Class Initialized
DEBUG - 2018-08-06 23:48:15 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-06 23:48:15 --> Helper loaded: url_helper
INFO - 2018-08-06 23:48:15 --> Helper loaded: form_helper
INFO - 2018-08-06 23:48:15 --> Helper loaded: date_helper
INFO - 2018-08-06 23:48:15 --> Helper loaded: util_helper
INFO - 2018-08-06 23:48:15 --> Helper loaded: text_helper
INFO - 2018-08-06 23:48:15 --> Helper loaded: string_helper
INFO - 2018-08-06 23:48:15 --> Database Driver Class Initialized
DEBUG - 2018-08-06 23:48:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-06 23:48:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-06 23:48:15 --> Email Class Initialized
INFO - 2018-08-06 23:48:15 --> Controller Class Initialized
DEBUG - 2018-08-06 23:48:15 --> Home MX_Controller Initialized
DEBUG - 2018-08-06 23:48:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-06 23:48:15 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-06 23:48:15 --> Login MX_Controller Initialized
INFO - 2018-08-06 23:48:15 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-06 23:48:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-06 23:48:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-06 23:48:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-08-06 23:48:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-08-06 23:48:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-08-06 23:48:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-08-06 23:48:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-08-06 23:48:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/search_page.php
INFO - 2018-08-06 23:48:15 --> Final output sent to browser
DEBUG - 2018-08-06 23:48:15 --> Total execution time: 0.6137
INFO - 2018-08-06 23:48:15 --> Config Class Initialized
INFO - 2018-08-06 23:48:15 --> Hooks Class Initialized
INFO - 2018-08-06 23:48:15 --> Config Class Initialized
INFO - 2018-08-06 23:48:15 --> Hooks Class Initialized
DEBUG - 2018-08-06 23:48:15 --> UTF-8 Support Enabled
DEBUG - 2018-08-06 23:48:15 --> UTF-8 Support Enabled
INFO - 2018-08-06 23:48:15 --> Utf8 Class Initialized
INFO - 2018-08-06 23:48:15 --> URI Class Initialized
INFO - 2018-08-06 23:48:16 --> Utf8 Class Initialized
INFO - 2018-08-06 23:48:16 --> Router Class Initialized
INFO - 2018-08-06 23:48:16 --> URI Class Initialized
INFO - 2018-08-06 23:48:16 --> Output Class Initialized
INFO - 2018-08-06 23:48:16 --> Router Class Initialized
INFO - 2018-08-06 23:48:16 --> Security Class Initialized
DEBUG - 2018-08-06 23:48:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-06 23:48:16 --> Input Class Initialized
INFO - 2018-08-06 23:48:16 --> Language Class Initialized
INFO - 2018-08-06 23:48:16 --> Language Class Initialized
INFO - 2018-08-06 23:48:16 --> Config Class Initialized
INFO - 2018-08-06 23:48:16 --> Loader Class Initialized
INFO - 2018-08-06 23:48:16 --> Output Class Initialized
DEBUG - 2018-08-06 23:48:16 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-06 23:48:16 --> Helper loaded: url_helper
INFO - 2018-08-06 23:48:16 --> Security Class Initialized
INFO - 2018-08-06 23:48:16 --> Helper loaded: form_helper
INFO - 2018-08-06 23:48:16 --> Helper loaded: date_helper
INFO - 2018-08-06 23:48:16 --> Helper loaded: util_helper
INFO - 2018-08-06 23:48:16 --> Helper loaded: text_helper
INFO - 2018-08-06 23:48:16 --> Helper loaded: string_helper
DEBUG - 2018-08-06 23:48:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-06 23:48:16 --> Database Driver Class Initialized
INFO - 2018-08-06 23:48:16 --> Input Class Initialized
DEBUG - 2018-08-06 23:48:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-06 23:48:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-06 23:48:16 --> Language Class Initialized
ERROR - 2018-08-06 23:48:16 --> 404 Page Not Found: /index
INFO - 2018-08-06 23:48:16 --> Email Class Initialized
INFO - 2018-08-06 23:48:16 --> Controller Class Initialized
INFO - 2018-08-06 23:48:16 --> Config Class Initialized
INFO - 2018-08-06 23:48:16 --> Hooks Class Initialized
DEBUG - 2018-08-06 23:48:16 --> Home MX_Controller Initialized
DEBUG - 2018-08-06 23:48:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-06 23:48:16 --> UTF-8 Support Enabled
INFO - 2018-08-06 23:48:16 --> Utf8 Class Initialized
DEBUG - 2018-08-06 23:48:16 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-06 23:48:16 --> Login MX_Controller Initialized
INFO - 2018-08-06 23:48:16 --> URI Class Initialized
INFO - 2018-08-06 23:48:16 --> Language file loaded: language/english/data_lang.php
INFO - 2018-08-06 23:48:16 --> Router Class Initialized
DEBUG - 2018-08-06 23:48:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-08-06 23:48:16 --> Output Class Initialized
DEBUG - 2018-08-06 23:48:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-06 23:48:16 --> Security Class Initialized
DEBUG - 2018-08-06 23:48:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-06 23:48:16 --> Input Class Initialized
INFO - 2018-08-06 23:48:16 --> Language Class Initialized
ERROR - 2018-08-06 23:48:16 --> 404 Page Not Found: /index
INFO - 2018-08-06 23:48:16 --> Config Class Initialized
INFO - 2018-08-06 23:48:16 --> Hooks Class Initialized
DEBUG - 2018-08-06 23:48:16 --> UTF-8 Support Enabled
INFO - 2018-08-06 23:48:16 --> Utf8 Class Initialized
INFO - 2018-08-06 23:48:16 --> URI Class Initialized
INFO - 2018-08-06 23:48:16 --> Router Class Initialized
INFO - 2018-08-06 23:48:16 --> Output Class Initialized
INFO - 2018-08-06 23:48:16 --> Security Class Initialized
DEBUG - 2018-08-06 23:48:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-06 23:48:16 --> Input Class Initialized
INFO - 2018-08-06 23:48:16 --> Language Class Initialized
ERROR - 2018-08-06 23:48:16 --> 404 Page Not Found: /index
INFO - 2018-08-06 23:48:20 --> Config Class Initialized
INFO - 2018-08-06 23:48:20 --> Hooks Class Initialized
DEBUG - 2018-08-06 23:48:20 --> UTF-8 Support Enabled
INFO - 2018-08-06 23:48:20 --> Utf8 Class Initialized
INFO - 2018-08-06 23:48:20 --> URI Class Initialized
INFO - 2018-08-06 23:48:20 --> Router Class Initialized
INFO - 2018-08-06 23:48:20 --> Output Class Initialized
INFO - 2018-08-06 23:48:20 --> Security Class Initialized
DEBUG - 2018-08-06 23:48:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-06 23:48:20 --> Input Class Initialized
INFO - 2018-08-06 23:48:20 --> Language Class Initialized
INFO - 2018-08-06 23:48:20 --> Language Class Initialized
INFO - 2018-08-06 23:48:20 --> Config Class Initialized
INFO - 2018-08-06 23:48:20 --> Loader Class Initialized
DEBUG - 2018-08-06 23:48:20 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-06 23:48:20 --> Helper loaded: url_helper
INFO - 2018-08-06 23:48:20 --> Helper loaded: form_helper
INFO - 2018-08-06 23:48:20 --> Helper loaded: date_helper
INFO - 2018-08-06 23:48:20 --> Helper loaded: util_helper
INFO - 2018-08-06 23:48:20 --> Helper loaded: text_helper
INFO - 2018-08-06 23:48:20 --> Helper loaded: string_helper
INFO - 2018-08-06 23:48:20 --> Database Driver Class Initialized
DEBUG - 2018-08-06 23:48:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-06 23:48:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-06 23:48:20 --> Email Class Initialized
INFO - 2018-08-06 23:48:20 --> Controller Class Initialized
DEBUG - 2018-08-06 23:48:20 --> Home MX_Controller Initialized
DEBUG - 2018-08-06 23:48:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-06 23:48:20 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-06 23:48:20 --> Login MX_Controller Initialized
INFO - 2018-08-06 23:48:20 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-06 23:48:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-06 23:48:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-06 23:48:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-08-06 23:48:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-08-06 23:48:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-08-06 23:48:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-08-06 23:48:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-08-06 23:48:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-08-06 23:48:20 --> Final output sent to browser
DEBUG - 2018-08-06 23:48:21 --> Total execution time: 0.6035
INFO - 2018-08-06 23:48:21 --> Config Class Initialized
INFO - 2018-08-06 23:48:21 --> Hooks Class Initialized
DEBUG - 2018-08-06 23:48:21 --> UTF-8 Support Enabled
INFO - 2018-08-06 23:48:21 --> Utf8 Class Initialized
INFO - 2018-08-06 23:48:21 --> URI Class Initialized
INFO - 2018-08-06 23:48:21 --> Router Class Initialized
INFO - 2018-08-06 23:48:21 --> Output Class Initialized
INFO - 2018-08-06 23:48:21 --> Security Class Initialized
DEBUG - 2018-08-06 23:48:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-06 23:48:21 --> Input Class Initialized
INFO - 2018-08-06 23:48:21 --> Language Class Initialized
INFO - 2018-08-06 23:48:21 --> Language Class Initialized
INFO - 2018-08-06 23:48:21 --> Config Class Initialized
INFO - 2018-08-06 23:48:21 --> Loader Class Initialized
DEBUG - 2018-08-06 23:48:21 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-06 23:48:21 --> Helper loaded: url_helper
INFO - 2018-08-06 23:48:21 --> Helper loaded: form_helper
INFO - 2018-08-06 23:48:21 --> Helper loaded: date_helper
INFO - 2018-08-06 23:48:21 --> Helper loaded: util_helper
INFO - 2018-08-06 23:48:21 --> Helper loaded: text_helper
INFO - 2018-08-06 23:48:21 --> Helper loaded: string_helper
INFO - 2018-08-06 23:48:21 --> Database Driver Class Initialized
DEBUG - 2018-08-06 23:48:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-06 23:48:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-06 23:48:21 --> Email Class Initialized
INFO - 2018-08-06 23:48:21 --> Controller Class Initialized
DEBUG - 2018-08-06 23:48:21 --> Home MX_Controller Initialized
DEBUG - 2018-08-06 23:48:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-06 23:48:21 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-06 23:48:21 --> Login MX_Controller Initialized
INFO - 2018-08-06 23:48:21 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-06 23:48:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-06 23:48:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-06 23:48:30 --> Config Class Initialized
INFO - 2018-08-06 23:48:30 --> Hooks Class Initialized
DEBUG - 2018-08-06 23:48:30 --> UTF-8 Support Enabled
INFO - 2018-08-06 23:48:30 --> Utf8 Class Initialized
INFO - 2018-08-06 23:48:30 --> URI Class Initialized
INFO - 2018-08-06 23:48:30 --> Router Class Initialized
INFO - 2018-08-06 23:48:30 --> Output Class Initialized
INFO - 2018-08-06 23:48:30 --> Security Class Initialized
DEBUG - 2018-08-06 23:48:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-06 23:48:30 --> Input Class Initialized
INFO - 2018-08-06 23:48:30 --> Language Class Initialized
INFO - 2018-08-06 23:48:30 --> Language Class Initialized
INFO - 2018-08-06 23:48:30 --> Config Class Initialized
INFO - 2018-08-06 23:48:30 --> Loader Class Initialized
DEBUG - 2018-08-06 23:48:30 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-06 23:48:30 --> Helper loaded: url_helper
INFO - 2018-08-06 23:48:30 --> Helper loaded: form_helper
INFO - 2018-08-06 23:48:30 --> Helper loaded: date_helper
INFO - 2018-08-06 23:48:30 --> Helper loaded: util_helper
INFO - 2018-08-06 23:48:30 --> Helper loaded: text_helper
INFO - 2018-08-06 23:48:30 --> Helper loaded: string_helper
INFO - 2018-08-06 23:48:30 --> Database Driver Class Initialized
DEBUG - 2018-08-06 23:48:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-06 23:48:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-06 23:48:30 --> Email Class Initialized
INFO - 2018-08-06 23:48:30 --> Controller Class Initialized
DEBUG - 2018-08-06 23:48:30 --> Home MX_Controller Initialized
DEBUG - 2018-08-06 23:48:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-06 23:48:30 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-06 23:48:30 --> Login MX_Controller Initialized
INFO - 2018-08-06 23:48:30 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-06 23:48:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-06 23:48:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-06 23:48:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-08-06 23:48:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-08-06 23:48:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-08-06 23:48:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-08-06 23:48:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-08-06 23:48:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/search_page.php
INFO - 2018-08-06 23:48:30 --> Final output sent to browser
DEBUG - 2018-08-06 23:48:30 --> Total execution time: 0.5791
INFO - 2018-08-06 23:48:30 --> Config Class Initialized
INFO - 2018-08-06 23:48:30 --> Hooks Class Initialized
INFO - 2018-08-06 23:48:30 --> Config Class Initialized
INFO - 2018-08-06 23:48:30 --> Hooks Class Initialized
DEBUG - 2018-08-06 23:48:30 --> UTF-8 Support Enabled
INFO - 2018-08-06 23:48:30 --> Utf8 Class Initialized
DEBUG - 2018-08-06 23:48:30 --> UTF-8 Support Enabled
INFO - 2018-08-06 23:48:30 --> Utf8 Class Initialized
INFO - 2018-08-06 23:48:30 --> URI Class Initialized
INFO - 2018-08-06 23:48:31 --> URI Class Initialized
INFO - 2018-08-06 23:48:31 --> Router Class Initialized
INFO - 2018-08-06 23:48:31 --> Output Class Initialized
INFO - 2018-08-06 23:48:31 --> Security Class Initialized
INFO - 2018-08-06 23:48:31 --> Router Class Initialized
INFO - 2018-08-06 23:48:31 --> Output Class Initialized
DEBUG - 2018-08-06 23:48:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-06 23:48:31 --> Security Class Initialized
DEBUG - 2018-08-06 23:48:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-06 23:48:31 --> Input Class Initialized
INFO - 2018-08-06 23:48:31 --> Language Class Initialized
ERROR - 2018-08-06 23:48:31 --> 404 Page Not Found: /index
INFO - 2018-08-06 23:48:31 --> Input Class Initialized
INFO - 2018-08-06 23:48:31 --> Config Class Initialized
INFO - 2018-08-06 23:48:31 --> Hooks Class Initialized
INFO - 2018-08-06 23:48:31 --> Language Class Initialized
DEBUG - 2018-08-06 23:48:31 --> UTF-8 Support Enabled
INFO - 2018-08-06 23:48:31 --> Utf8 Class Initialized
INFO - 2018-08-06 23:48:31 --> Language Class Initialized
INFO - 2018-08-06 23:48:31 --> URI Class Initialized
INFO - 2018-08-06 23:48:31 --> Config Class Initialized
INFO - 2018-08-06 23:48:31 --> Router Class Initialized
INFO - 2018-08-06 23:48:31 --> Output Class Initialized
INFO - 2018-08-06 23:48:31 --> Loader Class Initialized
INFO - 2018-08-06 23:48:31 --> Security Class Initialized
DEBUG - 2018-08-06 23:48:31 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
DEBUG - 2018-08-06 23:48:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-06 23:48:31 --> Helper loaded: url_helper
INFO - 2018-08-06 23:48:31 --> Input Class Initialized
INFO - 2018-08-06 23:48:31 --> Language Class Initialized
INFO - 2018-08-06 23:48:31 --> Helper loaded: form_helper
INFO - 2018-08-06 23:48:31 --> Helper loaded: date_helper
ERROR - 2018-08-06 23:48:31 --> 404 Page Not Found: /index
INFO - 2018-08-06 23:48:31 --> Helper loaded: util_helper
INFO - 2018-08-06 23:48:31 --> Config Class Initialized
INFO - 2018-08-06 23:48:31 --> Hooks Class Initialized
INFO - 2018-08-06 23:48:31 --> Helper loaded: text_helper
DEBUG - 2018-08-06 23:48:31 --> UTF-8 Support Enabled
INFO - 2018-08-06 23:48:31 --> Helper loaded: string_helper
INFO - 2018-08-06 23:48:31 --> Utf8 Class Initialized
INFO - 2018-08-06 23:48:31 --> URI Class Initialized
INFO - 2018-08-06 23:48:31 --> Router Class Initialized
INFO - 2018-08-06 23:48:31 --> Database Driver Class Initialized
INFO - 2018-08-06 23:48:31 --> Output Class Initialized
INFO - 2018-08-06 23:48:31 --> Security Class Initialized
DEBUG - 2018-08-06 23:48:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-06 23:48:31 --> Input Class Initialized
INFO - 2018-08-06 23:48:31 --> Language Class Initialized
ERROR - 2018-08-06 23:48:31 --> 404 Page Not Found: /index
DEBUG - 2018-08-06 23:48:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-06 23:48:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-06 23:48:31 --> Email Class Initialized
INFO - 2018-08-06 23:48:31 --> Controller Class Initialized
DEBUG - 2018-08-06 23:48:31 --> Home MX_Controller Initialized
DEBUG - 2018-08-06 23:48:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-06 23:48:31 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-06 23:48:31 --> Login MX_Controller Initialized
INFO - 2018-08-06 23:48:31 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-06 23:48:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-06 23:48:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-06 23:48:36 --> Config Class Initialized
INFO - 2018-08-06 23:48:36 --> Hooks Class Initialized
DEBUG - 2018-08-06 23:48:36 --> UTF-8 Support Enabled
INFO - 2018-08-06 23:48:37 --> Utf8 Class Initialized
INFO - 2018-08-06 23:48:37 --> URI Class Initialized
INFO - 2018-08-06 23:48:37 --> Router Class Initialized
INFO - 2018-08-06 23:48:37 --> Output Class Initialized
INFO - 2018-08-06 23:48:37 --> Security Class Initialized
DEBUG - 2018-08-06 23:48:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-06 23:48:37 --> Input Class Initialized
INFO - 2018-08-06 23:48:37 --> Language Class Initialized
INFO - 2018-08-06 23:48:37 --> Language Class Initialized
INFO - 2018-08-06 23:48:37 --> Config Class Initialized
INFO - 2018-08-06 23:48:37 --> Loader Class Initialized
DEBUG - 2018-08-06 23:48:37 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-06 23:48:37 --> Helper loaded: url_helper
INFO - 2018-08-06 23:48:37 --> Helper loaded: form_helper
INFO - 2018-08-06 23:48:37 --> Helper loaded: date_helper
INFO - 2018-08-06 23:48:37 --> Helper loaded: util_helper
INFO - 2018-08-06 23:48:37 --> Helper loaded: text_helper
INFO - 2018-08-06 23:48:37 --> Helper loaded: string_helper
INFO - 2018-08-06 23:48:37 --> Database Driver Class Initialized
DEBUG - 2018-08-06 23:48:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-06 23:48:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-06 23:48:37 --> Email Class Initialized
INFO - 2018-08-06 23:48:37 --> Controller Class Initialized
DEBUG - 2018-08-06 23:48:37 --> Home MX_Controller Initialized
DEBUG - 2018-08-06 23:48:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-06 23:48:37 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-06 23:48:37 --> Login MX_Controller Initialized
INFO - 2018-08-06 23:48:37 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-06 23:48:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-06 23:48:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-06 23:48:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-08-06 23:48:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-08-06 23:48:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
ERROR - 2018-08-06 23:48:37 --> Severity: Notice --> Undefined variable: rw_items_less E:\xampp\htdocs\consulting\application\modules\home\views\search_page.php 109
ERROR - 2018-08-06 23:48:37 --> Severity: Notice --> Undefined variable: rw_items_less E:\xampp\htdocs\consulting\application\modules\home\views\search_page.php 109
ERROR - 2018-08-06 23:48:37 --> Severity: Notice --> Undefined variable: rw_items_less E:\xampp\htdocs\consulting\application\modules\home\views\search_page.php 109
DEBUG - 2018-08-06 23:48:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-08-06 23:48:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-08-06 23:48:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/search_page.php
INFO - 2018-08-06 23:48:37 --> Final output sent to browser
DEBUG - 2018-08-06 23:48:37 --> Total execution time: 0.6018
INFO - 2018-08-06 23:48:37 --> Config Class Initialized
INFO - 2018-08-06 23:48:37 --> Hooks Class Initialized
INFO - 2018-08-06 23:48:37 --> Config Class Initialized
INFO - 2018-08-06 23:48:37 --> Hooks Class Initialized
DEBUG - 2018-08-06 23:48:37 --> UTF-8 Support Enabled
DEBUG - 2018-08-06 23:48:37 --> UTF-8 Support Enabled
INFO - 2018-08-06 23:48:37 --> Utf8 Class Initialized
INFO - 2018-08-06 23:48:37 --> Utf8 Class Initialized
INFO - 2018-08-06 23:48:37 --> URI Class Initialized
INFO - 2018-08-06 23:48:37 --> Router Class Initialized
INFO - 2018-08-06 23:48:37 --> URI Class Initialized
INFO - 2018-08-06 23:48:37 --> Output Class Initialized
INFO - 2018-08-06 23:48:37 --> Router Class Initialized
INFO - 2018-08-06 23:48:37 --> Security Class Initialized
DEBUG - 2018-08-06 23:48:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-06 23:48:37 --> Input Class Initialized
INFO - 2018-08-06 23:48:38 --> Language Class Initialized
INFO - 2018-08-06 23:48:38 --> Language Class Initialized
INFO - 2018-08-06 23:48:38 --> Output Class Initialized
INFO - 2018-08-06 23:48:38 --> Config Class Initialized
INFO - 2018-08-06 23:48:38 --> Loader Class Initialized
INFO - 2018-08-06 23:48:38 --> Security Class Initialized
DEBUG - 2018-08-06 23:48:38 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-06 23:48:38 --> Helper loaded: url_helper
INFO - 2018-08-06 23:48:38 --> Helper loaded: form_helper
INFO - 2018-08-06 23:48:38 --> Helper loaded: date_helper
INFO - 2018-08-06 23:48:38 --> Helper loaded: util_helper
INFO - 2018-08-06 23:48:38 --> Helper loaded: text_helper
INFO - 2018-08-06 23:48:38 --> Helper loaded: string_helper
DEBUG - 2018-08-06 23:48:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-06 23:48:38 --> Database Driver Class Initialized
INFO - 2018-08-06 23:48:38 --> Input Class Initialized
DEBUG - 2018-08-06 23:48:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-06 23:48:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-06 23:48:38 --> Language Class Initialized
INFO - 2018-08-06 23:48:38 --> Email Class Initialized
ERROR - 2018-08-06 23:48:38 --> 404 Page Not Found: /index
INFO - 2018-08-06 23:48:38 --> Controller Class Initialized
INFO - 2018-08-06 23:48:38 --> Config Class Initialized
INFO - 2018-08-06 23:48:38 --> Hooks Class Initialized
DEBUG - 2018-08-06 23:48:38 --> Home MX_Controller Initialized
DEBUG - 2018-08-06 23:48:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-06 23:48:38 --> UTF-8 Support Enabled
INFO - 2018-08-06 23:48:38 --> Utf8 Class Initialized
DEBUG - 2018-08-06 23:48:38 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-06 23:48:38 --> Login MX_Controller Initialized
INFO - 2018-08-06 23:48:38 --> URI Class Initialized
INFO - 2018-08-06 23:48:38 --> Language file loaded: language/english/data_lang.php
INFO - 2018-08-06 23:48:38 --> Router Class Initialized
DEBUG - 2018-08-06 23:48:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-08-06 23:48:38 --> Output Class Initialized
DEBUG - 2018-08-06 23:48:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-06 23:48:38 --> Security Class Initialized
DEBUG - 2018-08-06 23:48:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-06 23:48:38 --> Input Class Initialized
INFO - 2018-08-06 23:48:38 --> Language Class Initialized
ERROR - 2018-08-06 23:48:38 --> 404 Page Not Found: /index
INFO - 2018-08-06 23:48:38 --> Config Class Initialized
INFO - 2018-08-06 23:48:38 --> Hooks Class Initialized
DEBUG - 2018-08-06 23:48:38 --> UTF-8 Support Enabled
INFO - 2018-08-06 23:48:38 --> Utf8 Class Initialized
INFO - 2018-08-06 23:48:38 --> URI Class Initialized
INFO - 2018-08-06 23:48:38 --> Router Class Initialized
INFO - 2018-08-06 23:48:38 --> Output Class Initialized
INFO - 2018-08-06 23:48:38 --> Security Class Initialized
DEBUG - 2018-08-06 23:48:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-06 23:48:38 --> Input Class Initialized
INFO - 2018-08-06 23:48:38 --> Language Class Initialized
ERROR - 2018-08-06 23:48:38 --> 404 Page Not Found: /index
INFO - 2018-08-06 23:48:46 --> Config Class Initialized
INFO - 2018-08-06 23:48:46 --> Hooks Class Initialized
DEBUG - 2018-08-06 23:48:46 --> UTF-8 Support Enabled
INFO - 2018-08-06 23:48:46 --> Utf8 Class Initialized
INFO - 2018-08-06 23:48:46 --> URI Class Initialized
INFO - 2018-08-06 23:48:46 --> Router Class Initialized
INFO - 2018-08-06 23:48:46 --> Output Class Initialized
INFO - 2018-08-06 23:48:46 --> Security Class Initialized
DEBUG - 2018-08-06 23:48:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-06 23:48:46 --> Input Class Initialized
INFO - 2018-08-06 23:48:46 --> Language Class Initialized
INFO - 2018-08-06 23:48:46 --> Language Class Initialized
INFO - 2018-08-06 23:48:46 --> Config Class Initialized
INFO - 2018-08-06 23:48:46 --> Loader Class Initialized
DEBUG - 2018-08-06 23:48:46 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-06 23:48:46 --> Helper loaded: url_helper
INFO - 2018-08-06 23:48:46 --> Helper loaded: form_helper
INFO - 2018-08-06 23:48:46 --> Helper loaded: date_helper
INFO - 2018-08-06 23:48:46 --> Helper loaded: util_helper
INFO - 2018-08-06 23:48:46 --> Helper loaded: text_helper
INFO - 2018-08-06 23:48:46 --> Helper loaded: string_helper
INFO - 2018-08-06 23:48:46 --> Database Driver Class Initialized
DEBUG - 2018-08-06 23:48:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-06 23:48:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-06 23:48:46 --> Email Class Initialized
INFO - 2018-08-06 23:48:46 --> Controller Class Initialized
DEBUG - 2018-08-06 23:48:46 --> Home MX_Controller Initialized
DEBUG - 2018-08-06 23:48:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-06 23:48:46 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-06 23:48:46 --> Login MX_Controller Initialized
INFO - 2018-08-06 23:48:46 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-06 23:48:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-06 23:48:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-06 23:48:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-08-06 23:48:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-08-06 23:48:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-08-06 23:48:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-08-06 23:48:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-08-06 23:48:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/search_page.php
INFO - 2018-08-06 23:48:46 --> Final output sent to browser
DEBUG - 2018-08-06 23:48:46 --> Total execution time: 0.5730
INFO - 2018-08-06 23:48:46 --> Config Class Initialized
INFO - 2018-08-06 23:48:46 --> Hooks Class Initialized
INFO - 2018-08-06 23:48:46 --> Config Class Initialized
INFO - 2018-08-06 23:48:46 --> Hooks Class Initialized
DEBUG - 2018-08-06 23:48:46 --> UTF-8 Support Enabled
INFO - 2018-08-06 23:48:46 --> Utf8 Class Initialized
DEBUG - 2018-08-06 23:48:46 --> UTF-8 Support Enabled
INFO - 2018-08-06 23:48:46 --> URI Class Initialized
INFO - 2018-08-06 23:48:46 --> Utf8 Class Initialized
INFO - 2018-08-06 23:48:46 --> Router Class Initialized
INFO - 2018-08-06 23:48:47 --> URI Class Initialized
INFO - 2018-08-06 23:48:47 --> Router Class Initialized
INFO - 2018-08-06 23:48:47 --> Output Class Initialized
INFO - 2018-08-06 23:48:47 --> Security Class Initialized
INFO - 2018-08-06 23:48:47 --> Output Class Initialized
INFO - 2018-08-06 23:48:47 --> Security Class Initialized
DEBUG - 2018-08-06 23:48:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-08-06 23:48:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-06 23:48:47 --> Input Class Initialized
INFO - 2018-08-06 23:48:47 --> Language Class Initialized
INFO - 2018-08-06 23:48:47 --> Input Class Initialized
INFO - 2018-08-06 23:48:47 --> Language Class Initialized
INFO - 2018-08-06 23:48:47 --> Language Class Initialized
INFO - 2018-08-06 23:48:47 --> Config Class Initialized
ERROR - 2018-08-06 23:48:47 --> 404 Page Not Found: /index
INFO - 2018-08-06 23:48:47 --> Loader Class Initialized
INFO - 2018-08-06 23:48:47 --> Config Class Initialized
INFO - 2018-08-06 23:48:47 --> Hooks Class Initialized
DEBUG - 2018-08-06 23:48:47 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
DEBUG - 2018-08-06 23:48:47 --> UTF-8 Support Enabled
INFO - 2018-08-06 23:48:47 --> Helper loaded: url_helper
INFO - 2018-08-06 23:48:47 --> Utf8 Class Initialized
INFO - 2018-08-06 23:48:47 --> URI Class Initialized
INFO - 2018-08-06 23:48:47 --> Router Class Initialized
INFO - 2018-08-06 23:48:47 --> Output Class Initialized
INFO - 2018-08-06 23:48:47 --> Security Class Initialized
INFO - 2018-08-06 23:48:47 --> Helper loaded: form_helper
DEBUG - 2018-08-06 23:48:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-06 23:48:47 --> Input Class Initialized
INFO - 2018-08-06 23:48:47 --> Language Class Initialized
ERROR - 2018-08-06 23:48:47 --> 404 Page Not Found: /index
INFO - 2018-08-06 23:48:47 --> Config Class Initialized
INFO - 2018-08-06 23:48:47 --> Hooks Class Initialized
INFO - 2018-08-06 23:48:47 --> Helper loaded: date_helper
INFO - 2018-08-06 23:48:47 --> Helper loaded: util_helper
DEBUG - 2018-08-06 23:48:47 --> UTF-8 Support Enabled
INFO - 2018-08-06 23:48:47 --> Utf8 Class Initialized
INFO - 2018-08-06 23:48:47 --> Helper loaded: text_helper
INFO - 2018-08-06 23:48:47 --> Helper loaded: string_helper
INFO - 2018-08-06 23:48:47 --> URI Class Initialized
INFO - 2018-08-06 23:48:47 --> Router Class Initialized
INFO - 2018-08-06 23:48:47 --> Database Driver Class Initialized
INFO - 2018-08-06 23:48:47 --> Output Class Initialized
DEBUG - 2018-08-06 23:48:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-06 23:48:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-06 23:48:47 --> Security Class Initialized
DEBUG - 2018-08-06 23:48:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-06 23:48:47 --> Email Class Initialized
INFO - 2018-08-06 23:48:47 --> Controller Class Initialized
INFO - 2018-08-06 23:48:47 --> Input Class Initialized
DEBUG - 2018-08-06 23:48:47 --> Home MX_Controller Initialized
INFO - 2018-08-06 23:48:47 --> Language Class Initialized
DEBUG - 2018-08-06 23:48:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
ERROR - 2018-08-06 23:48:47 --> 404 Page Not Found: /index
DEBUG - 2018-08-06 23:48:47 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-06 23:48:47 --> Login MX_Controller Initialized
INFO - 2018-08-06 23:48:47 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-06 23:48:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-06 23:48:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-06 23:49:55 --> Config Class Initialized
INFO - 2018-08-06 23:49:55 --> Hooks Class Initialized
DEBUG - 2018-08-06 23:49:55 --> UTF-8 Support Enabled
INFO - 2018-08-06 23:49:55 --> Utf8 Class Initialized
INFO - 2018-08-06 23:49:55 --> URI Class Initialized
INFO - 2018-08-06 23:49:55 --> Router Class Initialized
INFO - 2018-08-06 23:49:55 --> Output Class Initialized
INFO - 2018-08-06 23:49:56 --> Security Class Initialized
DEBUG - 2018-08-06 23:49:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-06 23:49:56 --> Input Class Initialized
INFO - 2018-08-06 23:49:56 --> Language Class Initialized
INFO - 2018-08-06 23:49:56 --> Language Class Initialized
INFO - 2018-08-06 23:49:56 --> Config Class Initialized
INFO - 2018-08-06 23:49:56 --> Loader Class Initialized
DEBUG - 2018-08-06 23:49:56 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-06 23:49:56 --> Helper loaded: url_helper
INFO - 2018-08-06 23:49:56 --> Helper loaded: form_helper
INFO - 2018-08-06 23:49:56 --> Helper loaded: date_helper
INFO - 2018-08-06 23:49:56 --> Helper loaded: util_helper
INFO - 2018-08-06 23:49:56 --> Helper loaded: text_helper
INFO - 2018-08-06 23:49:56 --> Helper loaded: string_helper
INFO - 2018-08-06 23:49:56 --> Database Driver Class Initialized
DEBUG - 2018-08-06 23:49:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-06 23:49:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-06 23:49:56 --> Email Class Initialized
INFO - 2018-08-06 23:49:56 --> Controller Class Initialized
DEBUG - 2018-08-06 23:49:56 --> Home MX_Controller Initialized
DEBUG - 2018-08-06 23:49:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-06 23:49:56 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-06 23:49:56 --> Login MX_Controller Initialized
INFO - 2018-08-06 23:49:56 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-06 23:49:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-06 23:49:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-06 23:49:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-08-06 23:49:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-08-06 23:49:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-08-06 23:49:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-08-06 23:49:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-08-06 23:49:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/search_page.php
INFO - 2018-08-06 23:49:56 --> Final output sent to browser
DEBUG - 2018-08-06 23:49:56 --> Total execution time: 0.5724
INFO - 2018-08-06 23:49:56 --> Config Class Initialized
INFO - 2018-08-06 23:49:56 --> Hooks Class Initialized
INFO - 2018-08-06 23:49:56 --> Config Class Initialized
INFO - 2018-08-06 23:49:56 --> Hooks Class Initialized
DEBUG - 2018-08-06 23:49:56 --> UTF-8 Support Enabled
DEBUG - 2018-08-06 23:49:56 --> UTF-8 Support Enabled
INFO - 2018-08-06 23:49:56 --> Utf8 Class Initialized
INFO - 2018-08-06 23:49:56 --> URI Class Initialized
INFO - 2018-08-06 23:49:56 --> Router Class Initialized
INFO - 2018-08-06 23:49:56 --> Output Class Initialized
INFO - 2018-08-06 23:49:56 --> Security Class Initialized
DEBUG - 2018-08-06 23:49:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-06 23:49:56 --> Input Class Initialized
INFO - 2018-08-06 23:49:56 --> Language Class Initialized
INFO - 2018-08-06 23:49:56 --> Utf8 Class Initialized
INFO - 2018-08-06 23:49:56 --> Language Class Initialized
INFO - 2018-08-06 23:49:56 --> URI Class Initialized
INFO - 2018-08-06 23:49:56 --> Config Class Initialized
INFO - 2018-08-06 23:49:56 --> Router Class Initialized
INFO - 2018-08-06 23:49:56 --> Loader Class Initialized
INFO - 2018-08-06 23:49:56 --> Output Class Initialized
DEBUG - 2018-08-06 23:49:56 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-06 23:49:56 --> Helper loaded: url_helper
INFO - 2018-08-06 23:49:56 --> Helper loaded: form_helper
INFO - 2018-08-06 23:49:57 --> Helper loaded: date_helper
INFO - 2018-08-06 23:49:57 --> Helper loaded: util_helper
INFO - 2018-08-06 23:49:57 --> Helper loaded: text_helper
INFO - 2018-08-06 23:49:57 --> Helper loaded: string_helper
INFO - 2018-08-06 23:49:57 --> Security Class Initialized
INFO - 2018-08-06 23:49:57 --> Database Driver Class Initialized
DEBUG - 2018-08-06 23:49:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-08-06 23:49:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-06 23:49:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-06 23:49:57 --> Input Class Initialized
INFO - 2018-08-06 23:49:57 --> Language Class Initialized
INFO - 2018-08-06 23:49:57 --> Email Class Initialized
INFO - 2018-08-06 23:49:57 --> Controller Class Initialized
ERROR - 2018-08-06 23:49:57 --> 404 Page Not Found: /index
DEBUG - 2018-08-06 23:49:57 --> Home MX_Controller Initialized
INFO - 2018-08-06 23:49:57 --> Config Class Initialized
INFO - 2018-08-06 23:49:57 --> Hooks Class Initialized
DEBUG - 2018-08-06 23:49:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-06 23:49:57 --> UTF-8 Support Enabled
DEBUG - 2018-08-06 23:49:57 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
INFO - 2018-08-06 23:49:57 --> Utf8 Class Initialized
DEBUG - 2018-08-06 23:49:57 --> Login MX_Controller Initialized
INFO - 2018-08-06 23:49:57 --> Language file loaded: language/english/data_lang.php
INFO - 2018-08-06 23:49:57 --> URI Class Initialized
DEBUG - 2018-08-06 23:49:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-08-06 23:49:57 --> Router Class Initialized
DEBUG - 2018-08-06 23:49:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-06 23:49:57 --> Output Class Initialized
INFO - 2018-08-06 23:49:57 --> Security Class Initialized
DEBUG - 2018-08-06 23:49:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-06 23:49:57 --> Input Class Initialized
INFO - 2018-08-06 23:49:57 --> Language Class Initialized
ERROR - 2018-08-06 23:49:57 --> 404 Page Not Found: /index
INFO - 2018-08-06 23:49:57 --> Config Class Initialized
INFO - 2018-08-06 23:49:57 --> Hooks Class Initialized
DEBUG - 2018-08-06 23:49:57 --> UTF-8 Support Enabled
INFO - 2018-08-06 23:49:57 --> Utf8 Class Initialized
INFO - 2018-08-06 23:49:57 --> URI Class Initialized
INFO - 2018-08-06 23:49:57 --> Router Class Initialized
INFO - 2018-08-06 23:49:57 --> Output Class Initialized
INFO - 2018-08-06 23:49:57 --> Security Class Initialized
DEBUG - 2018-08-06 23:49:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-06 23:49:57 --> Input Class Initialized
INFO - 2018-08-06 23:49:57 --> Language Class Initialized
ERROR - 2018-08-06 23:49:57 --> 404 Page Not Found: /index
INFO - 2018-08-06 23:50:20 --> Config Class Initialized
INFO - 2018-08-06 23:50:20 --> Hooks Class Initialized
DEBUG - 2018-08-06 23:50:20 --> UTF-8 Support Enabled
INFO - 2018-08-06 23:50:20 --> Utf8 Class Initialized
INFO - 2018-08-06 23:50:20 --> URI Class Initialized
INFO - 2018-08-06 23:50:20 --> Router Class Initialized
INFO - 2018-08-06 23:50:20 --> Output Class Initialized
INFO - 2018-08-06 23:50:20 --> Security Class Initialized
DEBUG - 2018-08-06 23:50:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-06 23:50:20 --> Input Class Initialized
INFO - 2018-08-06 23:50:20 --> Language Class Initialized
INFO - 2018-08-06 23:50:20 --> Language Class Initialized
INFO - 2018-08-06 23:50:20 --> Config Class Initialized
INFO - 2018-08-06 23:50:20 --> Loader Class Initialized
DEBUG - 2018-08-06 23:50:20 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-06 23:50:21 --> Helper loaded: url_helper
INFO - 2018-08-06 23:50:21 --> Helper loaded: form_helper
INFO - 2018-08-06 23:50:21 --> Helper loaded: date_helper
INFO - 2018-08-06 23:50:21 --> Helper loaded: util_helper
INFO - 2018-08-06 23:50:21 --> Helper loaded: text_helper
INFO - 2018-08-06 23:50:21 --> Helper loaded: string_helper
INFO - 2018-08-06 23:50:21 --> Database Driver Class Initialized
DEBUG - 2018-08-06 23:50:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-06 23:50:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-06 23:50:21 --> Email Class Initialized
INFO - 2018-08-06 23:50:21 --> Controller Class Initialized
DEBUG - 2018-08-06 23:50:21 --> Home MX_Controller Initialized
DEBUG - 2018-08-06 23:50:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-06 23:50:21 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-06 23:50:21 --> Login MX_Controller Initialized
INFO - 2018-08-06 23:50:21 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-06 23:50:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-06 23:50:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-06 23:50:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-08-06 23:50:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-08-06 23:50:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-08-06 23:50:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-08-06 23:50:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-08-06 23:50:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/search_page.php
INFO - 2018-08-06 23:50:21 --> Final output sent to browser
DEBUG - 2018-08-06 23:50:21 --> Total execution time: 0.5680
INFO - 2018-08-06 23:50:21 --> Config Class Initialized
INFO - 2018-08-06 23:50:21 --> Hooks Class Initialized
INFO - 2018-08-06 23:50:21 --> Config Class Initialized
INFO - 2018-08-06 23:50:21 --> Hooks Class Initialized
DEBUG - 2018-08-06 23:50:21 --> UTF-8 Support Enabled
INFO - 2018-08-06 23:50:21 --> Utf8 Class Initialized
DEBUG - 2018-08-06 23:50:21 --> UTF-8 Support Enabled
INFO - 2018-08-06 23:50:21 --> Utf8 Class Initialized
INFO - 2018-08-06 23:50:21 --> URI Class Initialized
INFO - 2018-08-06 23:50:21 --> URI Class Initialized
INFO - 2018-08-06 23:50:21 --> Router Class Initialized
INFO - 2018-08-06 23:50:21 --> Router Class Initialized
INFO - 2018-08-06 23:50:21 --> Output Class Initialized
INFO - 2018-08-06 23:50:21 --> Output Class Initialized
INFO - 2018-08-06 23:50:21 --> Security Class Initialized
INFO - 2018-08-06 23:50:21 --> Security Class Initialized
DEBUG - 2018-08-06 23:50:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-08-06 23:50:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-06 23:50:22 --> Input Class Initialized
INFO - 2018-08-06 23:50:22 --> Input Class Initialized
INFO - 2018-08-06 23:50:22 --> Language Class Initialized
INFO - 2018-08-06 23:50:22 --> Language Class Initialized
INFO - 2018-08-06 23:50:22 --> Language Class Initialized
ERROR - 2018-08-06 23:50:22 --> 404 Page Not Found: /index
INFO - 2018-08-06 23:50:22 --> Config Class Initialized
INFO - 2018-08-06 23:50:22 --> Config Class Initialized
INFO - 2018-08-06 23:50:22 --> Hooks Class Initialized
INFO - 2018-08-06 23:50:22 --> Loader Class Initialized
DEBUG - 2018-08-06 23:50:22 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
DEBUG - 2018-08-06 23:50:22 --> UTF-8 Support Enabled
INFO - 2018-08-06 23:50:22 --> Helper loaded: url_helper
INFO - 2018-08-06 23:50:22 --> Utf8 Class Initialized
INFO - 2018-08-06 23:50:22 --> URI Class Initialized
INFO - 2018-08-06 23:50:22 --> Helper loaded: form_helper
INFO - 2018-08-06 23:50:22 --> Router Class Initialized
INFO - 2018-08-06 23:50:22 --> Helper loaded: date_helper
INFO - 2018-08-06 23:50:22 --> Output Class Initialized
INFO - 2018-08-06 23:50:22 --> Helper loaded: util_helper
INFO - 2018-08-06 23:50:22 --> Security Class Initialized
INFO - 2018-08-06 23:50:22 --> Helper loaded: text_helper
INFO - 2018-08-06 23:50:22 --> Helper loaded: string_helper
DEBUG - 2018-08-06 23:50:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-06 23:50:22 --> Input Class Initialized
INFO - 2018-08-06 23:50:22 --> Database Driver Class Initialized
INFO - 2018-08-06 23:50:22 --> Language Class Initialized
DEBUG - 2018-08-06 23:50:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-06 23:50:22 --> Session: Class initialized using 'files' driver.
ERROR - 2018-08-06 23:50:22 --> 404 Page Not Found: /index
INFO - 2018-08-06 23:50:22 --> Email Class Initialized
INFO - 2018-08-06 23:50:22 --> Config Class Initialized
INFO - 2018-08-06 23:50:22 --> Hooks Class Initialized
INFO - 2018-08-06 23:50:22 --> Controller Class Initialized
DEBUG - 2018-08-06 23:50:22 --> Home MX_Controller Initialized
DEBUG - 2018-08-06 23:50:22 --> UTF-8 Support Enabled
INFO - 2018-08-06 23:50:22 --> Utf8 Class Initialized
DEBUG - 2018-08-06 23:50:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-08-06 23:50:22 --> URI Class Initialized
INFO - 2018-08-06 23:50:22 --> Router Class Initialized
DEBUG - 2018-08-06 23:50:22 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
INFO - 2018-08-06 23:50:22 --> Output Class Initialized
DEBUG - 2018-08-06 23:50:22 --> Login MX_Controller Initialized
INFO - 2018-08-06 23:50:22 --> Security Class Initialized
INFO - 2018-08-06 23:50:22 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-06 23:50:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-08-06 23:50:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-08-06 23:50:22 --> Input Class Initialized
DEBUG - 2018-08-06 23:50:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-06 23:50:22 --> Language Class Initialized
ERROR - 2018-08-06 23:50:22 --> 404 Page Not Found: /index
INFO - 2018-08-06 23:51:11 --> Config Class Initialized
INFO - 2018-08-06 23:51:11 --> Hooks Class Initialized
DEBUG - 2018-08-06 23:51:11 --> UTF-8 Support Enabled
INFO - 2018-08-06 23:51:11 --> Utf8 Class Initialized
INFO - 2018-08-06 23:51:11 --> URI Class Initialized
INFO - 2018-08-06 23:51:11 --> Router Class Initialized
INFO - 2018-08-06 23:51:11 --> Output Class Initialized
INFO - 2018-08-06 23:51:11 --> Security Class Initialized
DEBUG - 2018-08-06 23:51:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-06 23:51:11 --> Input Class Initialized
INFO - 2018-08-06 23:51:11 --> Language Class Initialized
INFO - 2018-08-06 23:51:12 --> Language Class Initialized
INFO - 2018-08-06 23:51:12 --> Config Class Initialized
INFO - 2018-08-06 23:51:12 --> Loader Class Initialized
DEBUG - 2018-08-06 23:51:12 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-06 23:51:12 --> Helper loaded: url_helper
INFO - 2018-08-06 23:51:12 --> Helper loaded: form_helper
INFO - 2018-08-06 23:51:12 --> Helper loaded: date_helper
INFO - 2018-08-06 23:51:12 --> Helper loaded: util_helper
INFO - 2018-08-06 23:51:12 --> Helper loaded: text_helper
INFO - 2018-08-06 23:51:12 --> Helper loaded: string_helper
INFO - 2018-08-06 23:51:12 --> Database Driver Class Initialized
DEBUG - 2018-08-06 23:51:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-06 23:51:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-06 23:51:12 --> Email Class Initialized
INFO - 2018-08-06 23:51:12 --> Controller Class Initialized
DEBUG - 2018-08-06 23:51:12 --> Home MX_Controller Initialized
DEBUG - 2018-08-06 23:51:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-06 23:51:12 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-06 23:51:12 --> Login MX_Controller Initialized
INFO - 2018-08-06 23:51:12 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-06 23:51:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-06 23:51:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-06 23:51:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-08-06 23:51:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-08-06 23:51:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-08-06 23:51:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-08-06 23:51:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-08-06 23:51:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/search_page.php
INFO - 2018-08-06 23:51:12 --> Final output sent to browser
DEBUG - 2018-08-06 23:51:12 --> Total execution time: 0.6249
INFO - 2018-08-06 23:51:12 --> Config Class Initialized
INFO - 2018-08-06 23:51:12 --> Hooks Class Initialized
INFO - 2018-08-06 23:51:12 --> Config Class Initialized
INFO - 2018-08-06 23:51:12 --> Hooks Class Initialized
DEBUG - 2018-08-06 23:51:12 --> UTF-8 Support Enabled
INFO - 2018-08-06 23:51:12 --> Utf8 Class Initialized
DEBUG - 2018-08-06 23:51:12 --> UTF-8 Support Enabled
INFO - 2018-08-06 23:51:12 --> URI Class Initialized
INFO - 2018-08-06 23:51:12 --> Utf8 Class Initialized
INFO - 2018-08-06 23:51:12 --> URI Class Initialized
INFO - 2018-08-06 23:51:12 --> Router Class Initialized
INFO - 2018-08-06 23:51:12 --> Output Class Initialized
INFO - 2018-08-06 23:51:12 --> Router Class Initialized
INFO - 2018-08-06 23:51:12 --> Output Class Initialized
INFO - 2018-08-06 23:51:12 --> Security Class Initialized
DEBUG - 2018-08-06 23:51:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-06 23:51:12 --> Security Class Initialized
INFO - 2018-08-06 23:51:12 --> Input Class Initialized
INFO - 2018-08-06 23:51:12 --> Language Class Initialized
ERROR - 2018-08-06 23:51:12 --> 404 Page Not Found: /index
INFO - 2018-08-06 23:51:12 --> Config Class Initialized
INFO - 2018-08-06 23:51:12 --> Hooks Class Initialized
DEBUG - 2018-08-06 23:51:13 --> UTF-8 Support Enabled
DEBUG - 2018-08-06 23:51:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-06 23:51:13 --> Utf8 Class Initialized
INFO - 2018-08-06 23:51:13 --> URI Class Initialized
INFO - 2018-08-06 23:51:13 --> Input Class Initialized
INFO - 2018-08-06 23:51:13 --> Router Class Initialized
INFO - 2018-08-06 23:51:13 --> Output Class Initialized
INFO - 2018-08-06 23:51:13 --> Language Class Initialized
INFO - 2018-08-06 23:51:13 --> Language Class Initialized
INFO - 2018-08-06 23:51:13 --> Security Class Initialized
INFO - 2018-08-06 23:51:13 --> Config Class Initialized
DEBUG - 2018-08-06 23:51:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-06 23:51:13 --> Input Class Initialized
INFO - 2018-08-06 23:51:13 --> Loader Class Initialized
INFO - 2018-08-06 23:51:13 --> Language Class Initialized
DEBUG - 2018-08-06 23:51:13 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-06 23:51:13 --> Helper loaded: url_helper
ERROR - 2018-08-06 23:51:13 --> 404 Page Not Found: /index
INFO - 2018-08-06 23:51:13 --> Helper loaded: form_helper
INFO - 2018-08-06 23:51:13 --> Config Class Initialized
INFO - 2018-08-06 23:51:13 --> Hooks Class Initialized
INFO - 2018-08-06 23:51:13 --> Helper loaded: date_helper
INFO - 2018-08-06 23:51:13 --> Helper loaded: util_helper
DEBUG - 2018-08-06 23:51:13 --> UTF-8 Support Enabled
INFO - 2018-08-06 23:51:13 --> Utf8 Class Initialized
INFO - 2018-08-06 23:51:13 --> Helper loaded: text_helper
INFO - 2018-08-06 23:51:13 --> Helper loaded: string_helper
INFO - 2018-08-06 23:51:13 --> URI Class Initialized
INFO - 2018-08-06 23:51:13 --> Router Class Initialized
INFO - 2018-08-06 23:51:13 --> Database Driver Class Initialized
INFO - 2018-08-06 23:51:13 --> Output Class Initialized
DEBUG - 2018-08-06 23:51:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-06 23:51:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-06 23:51:13 --> Security Class Initialized
DEBUG - 2018-08-06 23:51:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-06 23:51:13 --> Email Class Initialized
INFO - 2018-08-06 23:51:13 --> Input Class Initialized
INFO - 2018-08-06 23:51:13 --> Language Class Initialized
INFO - 2018-08-06 23:51:13 --> Controller Class Initialized
DEBUG - 2018-08-06 23:51:13 --> Home MX_Controller Initialized
ERROR - 2018-08-06 23:51:13 --> 404 Page Not Found: /index
DEBUG - 2018-08-06 23:51:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-06 23:51:13 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-06 23:51:13 --> Login MX_Controller Initialized
INFO - 2018-08-06 23:51:13 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-06 23:51:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-06 23:51:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-06 23:51:18 --> Config Class Initialized
INFO - 2018-08-06 23:51:18 --> Hooks Class Initialized
DEBUG - 2018-08-06 23:51:18 --> UTF-8 Support Enabled
INFO - 2018-08-06 23:51:18 --> Utf8 Class Initialized
INFO - 2018-08-06 23:51:18 --> URI Class Initialized
INFO - 2018-08-06 23:51:18 --> Router Class Initialized
INFO - 2018-08-06 23:51:18 --> Output Class Initialized
INFO - 2018-08-06 23:51:18 --> Security Class Initialized
DEBUG - 2018-08-06 23:51:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-06 23:51:18 --> Input Class Initialized
INFO - 2018-08-06 23:51:18 --> Language Class Initialized
INFO - 2018-08-06 23:51:18 --> Language Class Initialized
INFO - 2018-08-06 23:51:18 --> Config Class Initialized
INFO - 2018-08-06 23:51:18 --> Loader Class Initialized
DEBUG - 2018-08-06 23:51:18 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-06 23:51:18 --> Helper loaded: url_helper
INFO - 2018-08-06 23:51:18 --> Helper loaded: form_helper
INFO - 2018-08-06 23:51:18 --> Helper loaded: date_helper
INFO - 2018-08-06 23:51:18 --> Helper loaded: util_helper
INFO - 2018-08-06 23:51:18 --> Helper loaded: text_helper
INFO - 2018-08-06 23:51:18 --> Helper loaded: string_helper
INFO - 2018-08-06 23:51:18 --> Database Driver Class Initialized
DEBUG - 2018-08-06 23:51:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-06 23:51:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-06 23:51:19 --> Email Class Initialized
INFO - 2018-08-06 23:51:19 --> Controller Class Initialized
DEBUG - 2018-08-06 23:51:19 --> Home MX_Controller Initialized
DEBUG - 2018-08-06 23:51:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-06 23:51:19 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-06 23:51:19 --> Login MX_Controller Initialized
INFO - 2018-08-06 23:51:19 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-06 23:51:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-06 23:51:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-06 23:51:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-08-06 23:51:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-08-06 23:51:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-08-06 23:51:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-08-06 23:51:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-08-06 23:51:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/search_page.php
INFO - 2018-08-06 23:51:19 --> Final output sent to browser
DEBUG - 2018-08-06 23:51:19 --> Total execution time: 0.5759
INFO - 2018-08-06 23:51:19 --> Config Class Initialized
INFO - 2018-08-06 23:51:19 --> Hooks Class Initialized
DEBUG - 2018-08-06 23:51:19 --> UTF-8 Support Enabled
INFO - 2018-08-06 23:51:19 --> Utf8 Class Initialized
INFO - 2018-08-06 23:51:19 --> URI Class Initialized
INFO - 2018-08-06 23:51:19 --> Router Class Initialized
INFO - 2018-08-06 23:51:19 --> Output Class Initialized
INFO - 2018-08-06 23:51:19 --> Security Class Initialized
DEBUG - 2018-08-06 23:51:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-06 23:51:19 --> Input Class Initialized
INFO - 2018-08-06 23:51:19 --> Language Class Initialized
INFO - 2018-08-06 23:51:19 --> Language Class Initialized
INFO - 2018-08-06 23:51:19 --> Config Class Initialized
INFO - 2018-08-06 23:51:19 --> Loader Class Initialized
DEBUG - 2018-08-06 23:51:19 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-06 23:51:19 --> Helper loaded: url_helper
INFO - 2018-08-06 23:51:19 --> Helper loaded: form_helper
INFO - 2018-08-06 23:51:19 --> Helper loaded: date_helper
INFO - 2018-08-06 23:51:19 --> Helper loaded: util_helper
INFO - 2018-08-06 23:51:19 --> Helper loaded: text_helper
INFO - 2018-08-06 23:51:19 --> Helper loaded: string_helper
INFO - 2018-08-06 23:51:19 --> Database Driver Class Initialized
DEBUG - 2018-08-06 23:51:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-06 23:51:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-06 23:51:19 --> Email Class Initialized
INFO - 2018-08-06 23:51:19 --> Controller Class Initialized
DEBUG - 2018-08-06 23:51:19 --> Home MX_Controller Initialized
DEBUG - 2018-08-06 23:51:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-06 23:51:19 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-06 23:51:19 --> Login MX_Controller Initialized
INFO - 2018-08-06 23:51:19 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-06 23:51:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-06 23:51:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-06 23:51:22 --> Config Class Initialized
INFO - 2018-08-06 23:51:22 --> Hooks Class Initialized
DEBUG - 2018-08-06 23:51:22 --> UTF-8 Support Enabled
INFO - 2018-08-06 23:51:22 --> Utf8 Class Initialized
INFO - 2018-08-06 23:51:22 --> URI Class Initialized
INFO - 2018-08-06 23:51:22 --> Router Class Initialized
INFO - 2018-08-06 23:51:22 --> Output Class Initialized
INFO - 2018-08-06 23:51:22 --> Security Class Initialized
DEBUG - 2018-08-06 23:51:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-06 23:51:22 --> Input Class Initialized
INFO - 2018-08-06 23:51:22 --> Language Class Initialized
INFO - 2018-08-06 23:51:22 --> Language Class Initialized
INFO - 2018-08-06 23:51:22 --> Config Class Initialized
INFO - 2018-08-06 23:51:23 --> Loader Class Initialized
DEBUG - 2018-08-06 23:51:23 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-06 23:51:23 --> Helper loaded: url_helper
INFO - 2018-08-06 23:51:23 --> Helper loaded: form_helper
INFO - 2018-08-06 23:51:23 --> Helper loaded: date_helper
INFO - 2018-08-06 23:51:23 --> Helper loaded: util_helper
INFO - 2018-08-06 23:51:23 --> Helper loaded: text_helper
INFO - 2018-08-06 23:51:23 --> Helper loaded: string_helper
INFO - 2018-08-06 23:51:23 --> Database Driver Class Initialized
DEBUG - 2018-08-06 23:51:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-06 23:51:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-06 23:51:23 --> Email Class Initialized
INFO - 2018-08-06 23:51:23 --> Controller Class Initialized
DEBUG - 2018-08-06 23:51:23 --> Home MX_Controller Initialized
DEBUG - 2018-08-06 23:51:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-06 23:51:23 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-06 23:51:23 --> Login MX_Controller Initialized
INFO - 2018-08-06 23:51:23 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-06 23:51:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-06 23:51:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-06 23:51:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-08-06 23:51:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-08-06 23:51:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-08-06 23:51:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-08-06 23:51:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-08-06 23:51:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/search_page.php
INFO - 2018-08-06 23:51:23 --> Final output sent to browser
DEBUG - 2018-08-06 23:51:23 --> Total execution time: 0.5868
INFO - 2018-08-06 23:51:23 --> Config Class Initialized
INFO - 2018-08-06 23:51:23 --> Hooks Class Initialized
DEBUG - 2018-08-06 23:51:23 --> UTF-8 Support Enabled
INFO - 2018-08-06 23:51:23 --> Utf8 Class Initialized
INFO - 2018-08-06 23:51:23 --> URI Class Initialized
INFO - 2018-08-06 23:51:23 --> Router Class Initialized
INFO - 2018-08-06 23:51:23 --> Output Class Initialized
INFO - 2018-08-06 23:51:23 --> Security Class Initialized
DEBUG - 2018-08-06 23:51:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-06 23:51:23 --> Input Class Initialized
INFO - 2018-08-06 23:51:23 --> Language Class Initialized
INFO - 2018-08-06 23:51:23 --> Language Class Initialized
INFO - 2018-08-06 23:51:23 --> Config Class Initialized
INFO - 2018-08-06 23:51:24 --> Loader Class Initialized
DEBUG - 2018-08-06 23:51:24 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-06 23:51:24 --> Helper loaded: url_helper
INFO - 2018-08-06 23:51:24 --> Helper loaded: form_helper
INFO - 2018-08-06 23:51:24 --> Helper loaded: date_helper
INFO - 2018-08-06 23:51:24 --> Helper loaded: util_helper
INFO - 2018-08-06 23:51:24 --> Helper loaded: text_helper
INFO - 2018-08-06 23:51:24 --> Helper loaded: string_helper
INFO - 2018-08-06 23:51:24 --> Database Driver Class Initialized
DEBUG - 2018-08-06 23:51:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-06 23:51:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-06 23:51:24 --> Email Class Initialized
INFO - 2018-08-06 23:51:24 --> Controller Class Initialized
DEBUG - 2018-08-06 23:51:24 --> Home MX_Controller Initialized
DEBUG - 2018-08-06 23:51:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-06 23:51:24 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-06 23:51:24 --> Login MX_Controller Initialized
INFO - 2018-08-06 23:51:24 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-06 23:51:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-06 23:51:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-06 23:51:47 --> Config Class Initialized
INFO - 2018-08-06 23:51:47 --> Hooks Class Initialized
DEBUG - 2018-08-06 23:51:47 --> UTF-8 Support Enabled
INFO - 2018-08-06 23:51:47 --> Utf8 Class Initialized
INFO - 2018-08-06 23:51:47 --> URI Class Initialized
INFO - 2018-08-06 23:51:47 --> Router Class Initialized
INFO - 2018-08-06 23:51:47 --> Output Class Initialized
INFO - 2018-08-06 23:51:47 --> Security Class Initialized
DEBUG - 2018-08-06 23:51:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-06 23:51:47 --> Input Class Initialized
INFO - 2018-08-06 23:51:47 --> Language Class Initialized
INFO - 2018-08-06 23:51:47 --> Language Class Initialized
INFO - 2018-08-06 23:51:47 --> Config Class Initialized
INFO - 2018-08-06 23:51:47 --> Loader Class Initialized
DEBUG - 2018-08-06 23:51:47 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-06 23:51:47 --> Helper loaded: url_helper
INFO - 2018-08-06 23:51:47 --> Helper loaded: form_helper
INFO - 2018-08-06 23:51:47 --> Helper loaded: date_helper
INFO - 2018-08-06 23:51:47 --> Helper loaded: util_helper
INFO - 2018-08-06 23:51:47 --> Helper loaded: text_helper
INFO - 2018-08-06 23:51:47 --> Helper loaded: string_helper
INFO - 2018-08-06 23:51:47 --> Database Driver Class Initialized
DEBUG - 2018-08-06 23:51:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-06 23:51:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-06 23:51:47 --> Email Class Initialized
INFO - 2018-08-06 23:51:47 --> Controller Class Initialized
DEBUG - 2018-08-06 23:51:47 --> Home MX_Controller Initialized
DEBUG - 2018-08-06 23:51:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-06 23:51:47 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-06 23:51:47 --> Login MX_Controller Initialized
INFO - 2018-08-06 23:51:47 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-06 23:51:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-06 23:51:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-06 23:51:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-08-06 23:51:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-08-06 23:51:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-08-06 23:51:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-08-06 23:51:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-08-06 23:51:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/search_page.php
INFO - 2018-08-06 23:51:47 --> Final output sent to browser
DEBUG - 2018-08-06 23:51:47 --> Total execution time: 0.5901
INFO - 2018-08-06 23:51:47 --> Config Class Initialized
INFO - 2018-08-06 23:51:47 --> Hooks Class Initialized
DEBUG - 2018-08-06 23:51:48 --> UTF-8 Support Enabled
INFO - 2018-08-06 23:51:48 --> Utf8 Class Initialized
INFO - 2018-08-06 23:51:48 --> URI Class Initialized
INFO - 2018-08-06 23:51:48 --> Router Class Initialized
INFO - 2018-08-06 23:51:48 --> Output Class Initialized
INFO - 2018-08-06 23:51:48 --> Security Class Initialized
DEBUG - 2018-08-06 23:51:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-06 23:51:48 --> Input Class Initialized
INFO - 2018-08-06 23:51:48 --> Language Class Initialized
INFO - 2018-08-06 23:51:48 --> Language Class Initialized
INFO - 2018-08-06 23:51:48 --> Config Class Initialized
INFO - 2018-08-06 23:51:48 --> Loader Class Initialized
DEBUG - 2018-08-06 23:51:48 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-06 23:51:48 --> Helper loaded: url_helper
INFO - 2018-08-06 23:51:48 --> Helper loaded: form_helper
INFO - 2018-08-06 23:51:48 --> Helper loaded: date_helper
INFO - 2018-08-06 23:51:48 --> Helper loaded: util_helper
INFO - 2018-08-06 23:51:48 --> Helper loaded: text_helper
INFO - 2018-08-06 23:51:48 --> Helper loaded: string_helper
INFO - 2018-08-06 23:51:48 --> Database Driver Class Initialized
DEBUG - 2018-08-06 23:51:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-06 23:51:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-06 23:51:48 --> Email Class Initialized
INFO - 2018-08-06 23:51:48 --> Controller Class Initialized
DEBUG - 2018-08-06 23:51:48 --> Home MX_Controller Initialized
DEBUG - 2018-08-06 23:51:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-06 23:51:48 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-06 23:51:48 --> Login MX_Controller Initialized
INFO - 2018-08-06 23:51:48 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-06 23:51:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-06 23:51:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-06 23:51:49 --> Config Class Initialized
INFO - 2018-08-06 23:51:49 --> Hooks Class Initialized
DEBUG - 2018-08-06 23:51:49 --> UTF-8 Support Enabled
INFO - 2018-08-06 23:51:49 --> Utf8 Class Initialized
INFO - 2018-08-06 23:51:49 --> URI Class Initialized
INFO - 2018-08-06 23:51:49 --> Router Class Initialized
INFO - 2018-08-06 23:51:49 --> Output Class Initialized
INFO - 2018-08-06 23:51:49 --> Security Class Initialized
DEBUG - 2018-08-06 23:51:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-06 23:51:49 --> Input Class Initialized
INFO - 2018-08-06 23:51:49 --> Language Class Initialized
INFO - 2018-08-06 23:51:49 --> Language Class Initialized
INFO - 2018-08-06 23:51:49 --> Config Class Initialized
INFO - 2018-08-06 23:51:49 --> Loader Class Initialized
DEBUG - 2018-08-06 23:51:49 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-06 23:51:49 --> Helper loaded: url_helper
INFO - 2018-08-06 23:51:49 --> Helper loaded: form_helper
INFO - 2018-08-06 23:51:49 --> Helper loaded: date_helper
INFO - 2018-08-06 23:51:49 --> Helper loaded: util_helper
INFO - 2018-08-06 23:51:49 --> Helper loaded: text_helper
INFO - 2018-08-06 23:51:49 --> Helper loaded: string_helper
INFO - 2018-08-06 23:51:49 --> Database Driver Class Initialized
DEBUG - 2018-08-06 23:51:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-06 23:51:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-06 23:51:49 --> Email Class Initialized
INFO - 2018-08-06 23:51:49 --> Controller Class Initialized
DEBUG - 2018-08-06 23:51:49 --> Home MX_Controller Initialized
DEBUG - 2018-08-06 23:51:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-06 23:51:49 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-06 23:51:49 --> Login MX_Controller Initialized
INFO - 2018-08-06 23:51:49 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-06 23:51:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-06 23:51:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-06 23:51:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-08-06 23:51:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-08-06 23:51:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-08-06 23:51:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-08-06 23:51:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-08-06 23:51:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/search_page.php
INFO - 2018-08-06 23:51:49 --> Final output sent to browser
DEBUG - 2018-08-06 23:51:49 --> Total execution time: 0.6029
INFO - 2018-08-06 23:51:50 --> Config Class Initialized
INFO - 2018-08-06 23:51:50 --> Hooks Class Initialized
DEBUG - 2018-08-06 23:51:50 --> UTF-8 Support Enabled
INFO - 2018-08-06 23:51:50 --> Utf8 Class Initialized
INFO - 2018-08-06 23:51:50 --> URI Class Initialized
INFO - 2018-08-06 23:51:50 --> Router Class Initialized
INFO - 2018-08-06 23:51:50 --> Output Class Initialized
INFO - 2018-08-06 23:51:50 --> Security Class Initialized
DEBUG - 2018-08-06 23:51:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-06 23:51:50 --> Input Class Initialized
INFO - 2018-08-06 23:51:50 --> Language Class Initialized
INFO - 2018-08-06 23:51:50 --> Language Class Initialized
INFO - 2018-08-06 23:51:50 --> Config Class Initialized
INFO - 2018-08-06 23:51:50 --> Loader Class Initialized
DEBUG - 2018-08-06 23:51:50 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-06 23:51:50 --> Helper loaded: url_helper
INFO - 2018-08-06 23:51:50 --> Helper loaded: form_helper
INFO - 2018-08-06 23:51:50 --> Helper loaded: date_helper
INFO - 2018-08-06 23:51:50 --> Helper loaded: util_helper
INFO - 2018-08-06 23:51:50 --> Helper loaded: text_helper
INFO - 2018-08-06 23:51:50 --> Helper loaded: string_helper
INFO - 2018-08-06 23:51:50 --> Database Driver Class Initialized
DEBUG - 2018-08-06 23:51:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-06 23:51:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-06 23:51:50 --> Email Class Initialized
INFO - 2018-08-06 23:51:50 --> Controller Class Initialized
DEBUG - 2018-08-06 23:51:50 --> Home MX_Controller Initialized
DEBUG - 2018-08-06 23:51:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-06 23:51:50 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-06 23:51:50 --> Login MX_Controller Initialized
INFO - 2018-08-06 23:51:50 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-06 23:51:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-06 23:51:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
