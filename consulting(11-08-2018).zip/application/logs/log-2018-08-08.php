<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-08-08 00:19:38 --> Config Class Initialized
INFO - 2018-08-08 00:19:38 --> Hooks Class Initialized
DEBUG - 2018-08-08 00:19:38 --> UTF-8 Support Enabled
INFO - 2018-08-08 00:19:38 --> Utf8 Class Initialized
INFO - 2018-08-08 00:19:38 --> URI Class Initialized
INFO - 2018-08-08 00:19:38 --> Router Class Initialized
INFO - 2018-08-08 00:19:38 --> Output Class Initialized
INFO - 2018-08-08 00:19:38 --> Security Class Initialized
DEBUG - 2018-08-08 00:19:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-08 00:19:38 --> Input Class Initialized
INFO - 2018-08-08 00:19:38 --> Language Class Initialized
INFO - 2018-08-08 00:19:38 --> Language Class Initialized
INFO - 2018-08-08 00:19:38 --> Config Class Initialized
INFO - 2018-08-08 00:19:38 --> Loader Class Initialized
DEBUG - 2018-08-08 00:19:38 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-08 00:19:38 --> Helper loaded: url_helper
INFO - 2018-08-08 00:19:38 --> Helper loaded: form_helper
INFO - 2018-08-08 00:19:38 --> Helper loaded: date_helper
INFO - 2018-08-08 00:19:38 --> Helper loaded: util_helper
INFO - 2018-08-08 00:19:38 --> Helper loaded: text_helper
INFO - 2018-08-08 00:19:38 --> Helper loaded: string_helper
INFO - 2018-08-08 00:19:38 --> Database Driver Class Initialized
DEBUG - 2018-08-08 00:19:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-08 00:19:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-08 00:19:38 --> Email Class Initialized
INFO - 2018-08-08 00:19:38 --> Controller Class Initialized
DEBUG - 2018-08-08 00:19:38 --> Settings MX_Controller Initialized
INFO - 2018-08-08 00:19:38 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-08 00:19:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-08 00:19:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Settings_model.php
DEBUG - 2018-08-08 00:19:38 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-08 00:19:38 --> Login MX_Controller Initialized
DEBUG - 2018-08-08 00:19:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-08 00:19:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
INFO - 2018-08-08 00:19:38 --> Upload Class Initialized
INFO - 2018-08-08 00:20:19 --> Config Class Initialized
INFO - 2018-08-08 00:20:19 --> Hooks Class Initialized
DEBUG - 2018-08-08 00:20:19 --> UTF-8 Support Enabled
INFO - 2018-08-08 00:20:19 --> Utf8 Class Initialized
INFO - 2018-08-08 00:20:19 --> URI Class Initialized
INFO - 2018-08-08 00:20:19 --> Router Class Initialized
INFO - 2018-08-08 00:20:19 --> Output Class Initialized
INFO - 2018-08-08 00:20:19 --> Security Class Initialized
DEBUG - 2018-08-08 00:20:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-08 00:20:19 --> Input Class Initialized
INFO - 2018-08-08 00:20:19 --> Language Class Initialized
INFO - 2018-08-08 00:20:19 --> Language Class Initialized
INFO - 2018-08-08 00:20:19 --> Config Class Initialized
INFO - 2018-08-08 00:20:19 --> Loader Class Initialized
DEBUG - 2018-08-08 00:20:19 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-08 00:20:19 --> Helper loaded: url_helper
INFO - 2018-08-08 00:20:19 --> Helper loaded: form_helper
INFO - 2018-08-08 00:20:19 --> Helper loaded: date_helper
INFO - 2018-08-08 00:20:19 --> Helper loaded: util_helper
INFO - 2018-08-08 00:20:19 --> Helper loaded: text_helper
INFO - 2018-08-08 00:20:19 --> Helper loaded: string_helper
INFO - 2018-08-08 00:20:19 --> Database Driver Class Initialized
DEBUG - 2018-08-08 00:20:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-08 00:20:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-08 00:20:19 --> Email Class Initialized
INFO - 2018-08-08 00:20:19 --> Controller Class Initialized
DEBUG - 2018-08-08 00:20:19 --> Settings MX_Controller Initialized
INFO - 2018-08-08 00:20:19 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-08 00:20:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-08 00:20:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Settings_model.php
DEBUG - 2018-08-08 00:20:19 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-08 00:20:19 --> Login MX_Controller Initialized
DEBUG - 2018-08-08 00:20:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-08 00:21:11 --> Config Class Initialized
INFO - 2018-08-08 00:21:11 --> Hooks Class Initialized
DEBUG - 2018-08-08 00:21:11 --> UTF-8 Support Enabled
INFO - 2018-08-08 00:21:11 --> Utf8 Class Initialized
INFO - 2018-08-08 00:21:11 --> URI Class Initialized
INFO - 2018-08-08 00:21:11 --> Router Class Initialized
INFO - 2018-08-08 00:21:11 --> Output Class Initialized
INFO - 2018-08-08 00:21:11 --> Security Class Initialized
DEBUG - 2018-08-08 00:21:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-08 00:21:11 --> Input Class Initialized
INFO - 2018-08-08 00:21:11 --> Language Class Initialized
INFO - 2018-08-08 00:21:11 --> Language Class Initialized
INFO - 2018-08-08 00:21:11 --> Config Class Initialized
INFO - 2018-08-08 00:21:11 --> Loader Class Initialized
DEBUG - 2018-08-08 00:21:11 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-08 00:21:11 --> Helper loaded: url_helper
INFO - 2018-08-08 00:21:11 --> Helper loaded: form_helper
INFO - 2018-08-08 00:21:11 --> Helper loaded: date_helper
INFO - 2018-08-08 00:21:11 --> Helper loaded: util_helper
INFO - 2018-08-08 00:21:11 --> Helper loaded: text_helper
INFO - 2018-08-08 00:21:11 --> Helper loaded: string_helper
INFO - 2018-08-08 00:21:11 --> Database Driver Class Initialized
DEBUG - 2018-08-08 00:21:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-08 00:21:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-08 00:21:11 --> Email Class Initialized
INFO - 2018-08-08 00:21:11 --> Controller Class Initialized
DEBUG - 2018-08-08 00:21:11 --> Settings MX_Controller Initialized
INFO - 2018-08-08 00:21:11 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-08 00:21:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-08 00:21:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Settings_model.php
DEBUG - 2018-08-08 00:21:11 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-08 00:21:11 --> Login MX_Controller Initialized
DEBUG - 2018-08-08 00:21:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-08 00:21:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
INFO - 2018-08-08 00:21:11 --> Upload Class Initialized
ERROR - 2018-08-08 00:21:11 --> Severity: Notice --> Undefined variable: row E:\xampp\htdocs\consulting\application\modules\admin\controllers\settings.php 105
INFO - 2018-08-08 00:21:11 --> Config Class Initialized
INFO - 2018-08-08 00:21:11 --> Hooks Class Initialized
DEBUG - 2018-08-08 00:21:11 --> UTF-8 Support Enabled
INFO - 2018-08-08 00:21:11 --> Utf8 Class Initialized
INFO - 2018-08-08 00:21:11 --> URI Class Initialized
INFO - 2018-08-08 00:21:11 --> Router Class Initialized
INFO - 2018-08-08 00:21:11 --> Output Class Initialized
INFO - 2018-08-08 00:21:11 --> Security Class Initialized
DEBUG - 2018-08-08 00:21:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-08 00:21:11 --> Input Class Initialized
INFO - 2018-08-08 00:21:11 --> Language Class Initialized
INFO - 2018-08-08 00:21:11 --> Language Class Initialized
INFO - 2018-08-08 00:21:11 --> Config Class Initialized
INFO - 2018-08-08 00:21:11 --> Loader Class Initialized
DEBUG - 2018-08-08 00:21:11 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-08 00:21:11 --> Helper loaded: url_helper
INFO - 2018-08-08 00:21:11 --> Helper loaded: form_helper
INFO - 2018-08-08 00:21:11 --> Helper loaded: date_helper
INFO - 2018-08-08 00:21:11 --> Helper loaded: util_helper
INFO - 2018-08-08 00:21:11 --> Helper loaded: text_helper
INFO - 2018-08-08 00:21:11 --> Helper loaded: string_helper
INFO - 2018-08-08 00:21:11 --> Database Driver Class Initialized
DEBUG - 2018-08-08 00:21:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-08 00:21:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-08 00:21:11 --> Email Class Initialized
INFO - 2018-08-08 00:21:11 --> Controller Class Initialized
DEBUG - 2018-08-08 00:21:11 --> Settings MX_Controller Initialized
INFO - 2018-08-08 00:21:11 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-08 00:21:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-08 00:21:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Settings_model.php
DEBUG - 2018-08-08 00:21:12 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-08 00:21:12 --> Login MX_Controller Initialized
DEBUG - 2018-08-08 00:21:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-08 00:21:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-08-08 00:21:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-08-08 00:21:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-08-08 00:21:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-08-08 00:21:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-08-08 00:21:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/settings.php
INFO - 2018-08-08 00:21:12 --> Final output sent to browser
DEBUG - 2018-08-08 00:21:12 --> Total execution time: 0.3709
INFO - 2018-08-08 00:21:29 --> Config Class Initialized
INFO - 2018-08-08 00:21:29 --> Hooks Class Initialized
DEBUG - 2018-08-08 00:21:29 --> UTF-8 Support Enabled
INFO - 2018-08-08 00:21:29 --> Utf8 Class Initialized
INFO - 2018-08-08 00:21:29 --> URI Class Initialized
INFO - 2018-08-08 00:21:29 --> Router Class Initialized
INFO - 2018-08-08 00:21:29 --> Output Class Initialized
INFO - 2018-08-08 00:21:29 --> Security Class Initialized
DEBUG - 2018-08-08 00:21:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-08 00:21:29 --> Input Class Initialized
INFO - 2018-08-08 00:21:29 --> Language Class Initialized
INFO - 2018-08-08 00:21:29 --> Language Class Initialized
INFO - 2018-08-08 00:21:29 --> Config Class Initialized
INFO - 2018-08-08 00:21:29 --> Loader Class Initialized
DEBUG - 2018-08-08 00:21:29 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-08 00:21:29 --> Helper loaded: url_helper
INFO - 2018-08-08 00:21:29 --> Helper loaded: form_helper
INFO - 2018-08-08 00:21:29 --> Helper loaded: date_helper
INFO - 2018-08-08 00:21:29 --> Helper loaded: util_helper
INFO - 2018-08-08 00:21:29 --> Helper loaded: text_helper
INFO - 2018-08-08 00:21:29 --> Helper loaded: string_helper
INFO - 2018-08-08 00:21:29 --> Database Driver Class Initialized
DEBUG - 2018-08-08 00:21:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-08 00:21:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-08 00:21:29 --> Email Class Initialized
INFO - 2018-08-08 00:21:29 --> Controller Class Initialized
DEBUG - 2018-08-08 00:21:29 --> Settings MX_Controller Initialized
INFO - 2018-08-08 00:21:29 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-08 00:21:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-08 00:21:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Settings_model.php
DEBUG - 2018-08-08 00:21:29 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-08 00:21:29 --> Login MX_Controller Initialized
DEBUG - 2018-08-08 00:21:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-08 00:21:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
INFO - 2018-08-08 00:21:29 --> Upload Class Initialized
ERROR - 2018-08-08 00:21:29 --> Severity: Notice --> Undefined variable: row E:\xampp\htdocs\consulting\application\modules\admin\controllers\settings.php 105
INFO - 2018-08-08 00:21:30 --> Config Class Initialized
INFO - 2018-08-08 00:21:30 --> Hooks Class Initialized
DEBUG - 2018-08-08 00:21:30 --> UTF-8 Support Enabled
INFO - 2018-08-08 00:21:30 --> Utf8 Class Initialized
INFO - 2018-08-08 00:21:30 --> URI Class Initialized
INFO - 2018-08-08 00:21:30 --> Router Class Initialized
INFO - 2018-08-08 00:21:30 --> Output Class Initialized
INFO - 2018-08-08 00:21:30 --> Security Class Initialized
DEBUG - 2018-08-08 00:21:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-08 00:21:30 --> Input Class Initialized
INFO - 2018-08-08 00:21:30 --> Language Class Initialized
INFO - 2018-08-08 00:21:30 --> Language Class Initialized
INFO - 2018-08-08 00:21:30 --> Config Class Initialized
INFO - 2018-08-08 00:21:30 --> Loader Class Initialized
DEBUG - 2018-08-08 00:21:30 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-08 00:21:30 --> Helper loaded: url_helper
INFO - 2018-08-08 00:21:30 --> Helper loaded: form_helper
INFO - 2018-08-08 00:21:30 --> Helper loaded: date_helper
INFO - 2018-08-08 00:21:30 --> Helper loaded: util_helper
INFO - 2018-08-08 00:21:30 --> Helper loaded: text_helper
INFO - 2018-08-08 00:21:30 --> Helper loaded: string_helper
INFO - 2018-08-08 00:21:30 --> Database Driver Class Initialized
DEBUG - 2018-08-08 00:21:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-08 00:21:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-08 00:21:30 --> Email Class Initialized
INFO - 2018-08-08 00:21:30 --> Controller Class Initialized
DEBUG - 2018-08-08 00:21:30 --> Settings MX_Controller Initialized
INFO - 2018-08-08 00:21:30 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-08 00:21:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-08 00:21:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Settings_model.php
DEBUG - 2018-08-08 00:21:30 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-08 00:21:30 --> Login MX_Controller Initialized
DEBUG - 2018-08-08 00:21:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-08 00:21:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-08-08 00:21:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-08-08 00:21:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-08-08 00:21:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-08-08 00:21:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-08-08 00:21:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/settings.php
INFO - 2018-08-08 00:21:30 --> Final output sent to browser
DEBUG - 2018-08-08 00:21:30 --> Total execution time: 0.4649
INFO - 2018-08-08 00:21:40 --> Config Class Initialized
INFO - 2018-08-08 00:21:40 --> Hooks Class Initialized
DEBUG - 2018-08-08 00:21:40 --> UTF-8 Support Enabled
INFO - 2018-08-08 00:21:40 --> Utf8 Class Initialized
INFO - 2018-08-08 00:21:40 --> URI Class Initialized
INFO - 2018-08-08 00:21:40 --> Router Class Initialized
INFO - 2018-08-08 00:21:40 --> Output Class Initialized
INFO - 2018-08-08 00:21:40 --> Security Class Initialized
DEBUG - 2018-08-08 00:21:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-08 00:21:40 --> Input Class Initialized
INFO - 2018-08-08 00:21:40 --> Language Class Initialized
INFO - 2018-08-08 00:21:40 --> Language Class Initialized
INFO - 2018-08-08 00:21:40 --> Config Class Initialized
INFO - 2018-08-08 00:21:40 --> Loader Class Initialized
DEBUG - 2018-08-08 00:21:40 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-08 00:21:40 --> Helper loaded: url_helper
INFO - 2018-08-08 00:21:40 --> Helper loaded: form_helper
INFO - 2018-08-08 00:21:40 --> Helper loaded: date_helper
INFO - 2018-08-08 00:21:40 --> Helper loaded: util_helper
INFO - 2018-08-08 00:21:40 --> Helper loaded: text_helper
INFO - 2018-08-08 00:21:40 --> Helper loaded: string_helper
INFO - 2018-08-08 00:21:40 --> Database Driver Class Initialized
DEBUG - 2018-08-08 00:21:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-08 00:21:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-08 00:21:40 --> Email Class Initialized
INFO - 2018-08-08 00:21:40 --> Controller Class Initialized
DEBUG - 2018-08-08 00:21:40 --> Settings MX_Controller Initialized
INFO - 2018-08-08 00:21:40 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-08 00:21:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-08 00:21:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Settings_model.php
DEBUG - 2018-08-08 00:21:40 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-08 00:21:40 --> Login MX_Controller Initialized
DEBUG - 2018-08-08 00:21:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-08 00:21:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-08-08 00:21:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-08-08 00:21:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-08-08 00:21:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-08-08 00:21:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-08-08 00:21:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/settings.php
INFO - 2018-08-08 00:21:40 --> Final output sent to browser
DEBUG - 2018-08-08 00:21:40 --> Total execution time: 0.4094
INFO - 2018-08-08 00:21:49 --> Config Class Initialized
INFO - 2018-08-08 00:21:49 --> Hooks Class Initialized
DEBUG - 2018-08-08 00:21:49 --> UTF-8 Support Enabled
INFO - 2018-08-08 00:21:49 --> Utf8 Class Initialized
INFO - 2018-08-08 00:21:49 --> URI Class Initialized
INFO - 2018-08-08 00:21:49 --> Router Class Initialized
INFO - 2018-08-08 00:21:49 --> Output Class Initialized
INFO - 2018-08-08 00:21:49 --> Security Class Initialized
DEBUG - 2018-08-08 00:21:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-08 00:21:49 --> Input Class Initialized
INFO - 2018-08-08 00:21:49 --> Language Class Initialized
INFO - 2018-08-08 00:21:49 --> Language Class Initialized
INFO - 2018-08-08 00:21:49 --> Config Class Initialized
INFO - 2018-08-08 00:21:49 --> Loader Class Initialized
DEBUG - 2018-08-08 00:21:49 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-08 00:21:49 --> Helper loaded: url_helper
INFO - 2018-08-08 00:21:49 --> Helper loaded: form_helper
INFO - 2018-08-08 00:21:49 --> Helper loaded: date_helper
INFO - 2018-08-08 00:21:49 --> Helper loaded: util_helper
INFO - 2018-08-08 00:21:49 --> Helper loaded: text_helper
INFO - 2018-08-08 00:21:49 --> Helper loaded: string_helper
INFO - 2018-08-08 00:21:49 --> Database Driver Class Initialized
DEBUG - 2018-08-08 00:21:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-08 00:21:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-08 00:21:49 --> Email Class Initialized
INFO - 2018-08-08 00:21:49 --> Controller Class Initialized
DEBUG - 2018-08-08 00:21:49 --> Settings MX_Controller Initialized
INFO - 2018-08-08 00:21:50 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-08 00:21:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-08 00:21:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Settings_model.php
DEBUG - 2018-08-08 00:21:50 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-08 00:21:50 --> Login MX_Controller Initialized
DEBUG - 2018-08-08 00:21:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-08 00:21:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-08-08 00:21:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-08-08 00:21:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-08-08 00:21:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-08-08 00:21:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-08-08 00:21:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/settings.php
INFO - 2018-08-08 00:21:50 --> Final output sent to browser
DEBUG - 2018-08-08 00:21:50 --> Total execution time: 0.4218
INFO - 2018-08-08 00:30:20 --> Config Class Initialized
INFO - 2018-08-08 00:30:20 --> Hooks Class Initialized
DEBUG - 2018-08-08 00:30:20 --> UTF-8 Support Enabled
INFO - 2018-08-08 00:30:20 --> Utf8 Class Initialized
INFO - 2018-08-08 00:30:20 --> URI Class Initialized
INFO - 2018-08-08 00:30:20 --> Router Class Initialized
INFO - 2018-08-08 00:30:20 --> Output Class Initialized
INFO - 2018-08-08 00:30:20 --> Security Class Initialized
DEBUG - 2018-08-08 00:30:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-08 00:30:20 --> Input Class Initialized
INFO - 2018-08-08 00:30:20 --> Language Class Initialized
INFO - 2018-08-08 00:30:20 --> Language Class Initialized
INFO - 2018-08-08 00:30:20 --> Config Class Initialized
INFO - 2018-08-08 00:30:20 --> Loader Class Initialized
DEBUG - 2018-08-08 00:30:20 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-08 00:30:20 --> Helper loaded: url_helper
INFO - 2018-08-08 00:30:20 --> Helper loaded: form_helper
INFO - 2018-08-08 00:30:20 --> Helper loaded: date_helper
INFO - 2018-08-08 00:30:20 --> Helper loaded: util_helper
INFO - 2018-08-08 00:30:20 --> Helper loaded: text_helper
INFO - 2018-08-08 00:30:20 --> Helper loaded: string_helper
INFO - 2018-08-08 00:30:20 --> Database Driver Class Initialized
DEBUG - 2018-08-08 00:30:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-08 00:30:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-08 00:30:20 --> Email Class Initialized
INFO - 2018-08-08 00:30:20 --> Controller Class Initialized
DEBUG - 2018-08-08 00:30:20 --> Home MX_Controller Initialized
DEBUG - 2018-08-08 00:30:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-08 00:30:20 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-08 00:30:20 --> Login MX_Controller Initialized
INFO - 2018-08-08 00:30:20 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-08 00:30:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-08 00:30:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-08 00:30:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Settings_model.php
DEBUG - 2018-08-08 00:30:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/login.php
INFO - 2018-08-08 00:30:40 --> Config Class Initialized
INFO - 2018-08-08 00:30:40 --> Hooks Class Initialized
DEBUG - 2018-08-08 00:30:40 --> UTF-8 Support Enabled
INFO - 2018-08-08 00:30:40 --> Utf8 Class Initialized
INFO - 2018-08-08 00:30:40 --> URI Class Initialized
INFO - 2018-08-08 00:30:40 --> Router Class Initialized
INFO - 2018-08-08 00:30:40 --> Output Class Initialized
INFO - 2018-08-08 00:30:40 --> Security Class Initialized
DEBUG - 2018-08-08 00:30:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-08 00:30:40 --> Input Class Initialized
INFO - 2018-08-08 00:30:40 --> Language Class Initialized
INFO - 2018-08-08 00:30:40 --> Language Class Initialized
INFO - 2018-08-08 00:30:40 --> Config Class Initialized
INFO - 2018-08-08 00:30:40 --> Loader Class Initialized
DEBUG - 2018-08-08 00:30:40 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-08 00:30:40 --> Helper loaded: url_helper
INFO - 2018-08-08 00:30:40 --> Helper loaded: form_helper
INFO - 2018-08-08 00:30:40 --> Helper loaded: date_helper
INFO - 2018-08-08 00:30:40 --> Helper loaded: util_helper
INFO - 2018-08-08 00:30:40 --> Helper loaded: text_helper
INFO - 2018-08-08 00:30:40 --> Helper loaded: string_helper
INFO - 2018-08-08 00:30:40 --> Database Driver Class Initialized
DEBUG - 2018-08-08 00:30:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-08 00:30:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-08 00:30:40 --> Email Class Initialized
INFO - 2018-08-08 00:30:40 --> Controller Class Initialized
DEBUG - 2018-08-08 00:30:40 --> Home MX_Controller Initialized
DEBUG - 2018-08-08 00:30:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-08 00:30:40 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-08 00:30:40 --> Login MX_Controller Initialized
INFO - 2018-08-08 00:30:40 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-08 00:30:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-08 00:30:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-08 00:30:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Settings_model.php
DEBUG - 2018-08-08 00:30:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/login.php
INFO - 2018-08-08 00:31:06 --> Config Class Initialized
INFO - 2018-08-08 00:31:06 --> Hooks Class Initialized
DEBUG - 2018-08-08 00:31:06 --> UTF-8 Support Enabled
INFO - 2018-08-08 00:31:06 --> Utf8 Class Initialized
INFO - 2018-08-08 00:31:06 --> URI Class Initialized
INFO - 2018-08-08 00:31:07 --> Router Class Initialized
INFO - 2018-08-08 00:31:07 --> Output Class Initialized
INFO - 2018-08-08 00:31:07 --> Security Class Initialized
DEBUG - 2018-08-08 00:31:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-08 00:31:07 --> Input Class Initialized
INFO - 2018-08-08 00:31:07 --> Language Class Initialized
INFO - 2018-08-08 00:31:07 --> Language Class Initialized
INFO - 2018-08-08 00:31:07 --> Config Class Initialized
INFO - 2018-08-08 00:31:07 --> Loader Class Initialized
DEBUG - 2018-08-08 00:31:07 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-08 00:31:07 --> Helper loaded: url_helper
INFO - 2018-08-08 00:31:07 --> Helper loaded: form_helper
INFO - 2018-08-08 00:31:07 --> Helper loaded: date_helper
INFO - 2018-08-08 00:31:07 --> Helper loaded: util_helper
INFO - 2018-08-08 00:31:07 --> Helper loaded: text_helper
INFO - 2018-08-08 00:31:07 --> Helper loaded: string_helper
INFO - 2018-08-08 00:31:07 --> Database Driver Class Initialized
DEBUG - 2018-08-08 00:31:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-08 00:31:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-08 00:31:07 --> Email Class Initialized
INFO - 2018-08-08 00:31:07 --> Controller Class Initialized
DEBUG - 2018-08-08 00:31:07 --> Settings MX_Controller Initialized
INFO - 2018-08-08 00:31:07 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-08 00:31:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-08 00:31:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Settings_model.php
DEBUG - 2018-08-08 00:31:07 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-08 00:31:07 --> Login MX_Controller Initialized
DEBUG - 2018-08-08 00:31:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-08 00:31:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
INFO - 2018-08-08 00:31:07 --> Upload Class Initialized
ERROR - 2018-08-08 00:31:07 --> Severity: Notice --> Undefined variable: row E:\xampp\htdocs\consulting\application\modules\admin\controllers\settings.php 105
INFO - 2018-08-08 00:31:07 --> Config Class Initialized
INFO - 2018-08-08 00:31:07 --> Hooks Class Initialized
DEBUG - 2018-08-08 00:31:07 --> UTF-8 Support Enabled
INFO - 2018-08-08 00:31:07 --> Utf8 Class Initialized
INFO - 2018-08-08 00:31:07 --> URI Class Initialized
INFO - 2018-08-08 00:31:07 --> Router Class Initialized
INFO - 2018-08-08 00:31:07 --> Output Class Initialized
INFO - 2018-08-08 00:31:07 --> Security Class Initialized
DEBUG - 2018-08-08 00:31:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-08 00:31:07 --> Input Class Initialized
INFO - 2018-08-08 00:31:07 --> Language Class Initialized
INFO - 2018-08-08 00:31:07 --> Language Class Initialized
INFO - 2018-08-08 00:31:07 --> Config Class Initialized
INFO - 2018-08-08 00:31:07 --> Loader Class Initialized
DEBUG - 2018-08-08 00:31:07 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-08 00:31:07 --> Helper loaded: url_helper
INFO - 2018-08-08 00:31:07 --> Helper loaded: form_helper
INFO - 2018-08-08 00:31:07 --> Helper loaded: date_helper
INFO - 2018-08-08 00:31:07 --> Helper loaded: util_helper
INFO - 2018-08-08 00:31:07 --> Helper loaded: text_helper
INFO - 2018-08-08 00:31:07 --> Helper loaded: string_helper
INFO - 2018-08-08 00:31:07 --> Database Driver Class Initialized
DEBUG - 2018-08-08 00:31:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-08 00:31:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-08 00:31:07 --> Email Class Initialized
INFO - 2018-08-08 00:31:07 --> Controller Class Initialized
DEBUG - 2018-08-08 00:31:07 --> Settings MX_Controller Initialized
INFO - 2018-08-08 00:31:07 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-08 00:31:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-08 00:31:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Settings_model.php
DEBUG - 2018-08-08 00:31:07 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-08 00:31:07 --> Login MX_Controller Initialized
DEBUG - 2018-08-08 00:31:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-08 00:31:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-08-08 00:31:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-08-08 00:31:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-08-08 00:31:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-08-08 00:31:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-08-08 00:31:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/settings.php
INFO - 2018-08-08 00:31:07 --> Final output sent to browser
DEBUG - 2018-08-08 00:31:08 --> Total execution time: 0.4674
INFO - 2018-08-08 00:31:11 --> Config Class Initialized
INFO - 2018-08-08 00:31:11 --> Hooks Class Initialized
DEBUG - 2018-08-08 00:31:11 --> UTF-8 Support Enabled
INFO - 2018-08-08 00:31:11 --> Utf8 Class Initialized
INFO - 2018-08-08 00:31:11 --> URI Class Initialized
INFO - 2018-08-08 00:31:11 --> Router Class Initialized
INFO - 2018-08-08 00:31:11 --> Output Class Initialized
INFO - 2018-08-08 00:31:11 --> Security Class Initialized
DEBUG - 2018-08-08 00:31:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-08 00:31:11 --> Input Class Initialized
INFO - 2018-08-08 00:31:11 --> Language Class Initialized
INFO - 2018-08-08 00:31:11 --> Language Class Initialized
INFO - 2018-08-08 00:31:11 --> Config Class Initialized
INFO - 2018-08-08 00:31:11 --> Loader Class Initialized
DEBUG - 2018-08-08 00:31:11 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-08 00:31:11 --> Helper loaded: url_helper
INFO - 2018-08-08 00:31:11 --> Helper loaded: form_helper
INFO - 2018-08-08 00:31:11 --> Helper loaded: date_helper
INFO - 2018-08-08 00:31:11 --> Helper loaded: util_helper
INFO - 2018-08-08 00:31:11 --> Helper loaded: text_helper
INFO - 2018-08-08 00:31:11 --> Helper loaded: string_helper
INFO - 2018-08-08 00:31:11 --> Database Driver Class Initialized
DEBUG - 2018-08-08 00:31:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-08 00:31:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-08 00:31:11 --> Email Class Initialized
INFO - 2018-08-08 00:31:11 --> Controller Class Initialized
DEBUG - 2018-08-08 00:31:11 --> Home MX_Controller Initialized
DEBUG - 2018-08-08 00:31:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-08 00:31:11 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-08 00:31:11 --> Login MX_Controller Initialized
INFO - 2018-08-08 00:31:11 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-08 00:31:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-08 00:31:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-08 00:31:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Settings_model.php
DEBUG - 2018-08-08 00:31:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/login.php
INFO - 2018-08-08 00:32:13 --> Config Class Initialized
INFO - 2018-08-08 00:32:13 --> Hooks Class Initialized
DEBUG - 2018-08-08 00:32:13 --> UTF-8 Support Enabled
INFO - 2018-08-08 00:32:13 --> Utf8 Class Initialized
INFO - 2018-08-08 00:32:13 --> URI Class Initialized
INFO - 2018-08-08 00:32:13 --> Router Class Initialized
INFO - 2018-08-08 00:32:13 --> Output Class Initialized
INFO - 2018-08-08 00:32:13 --> Security Class Initialized
DEBUG - 2018-08-08 00:32:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-08 00:32:13 --> Input Class Initialized
INFO - 2018-08-08 00:32:13 --> Language Class Initialized
INFO - 2018-08-08 00:32:13 --> Language Class Initialized
INFO - 2018-08-08 00:32:13 --> Config Class Initialized
INFO - 2018-08-08 00:32:13 --> Loader Class Initialized
DEBUG - 2018-08-08 00:32:13 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-08 00:32:13 --> Helper loaded: url_helper
INFO - 2018-08-08 00:32:13 --> Helper loaded: form_helper
INFO - 2018-08-08 00:32:13 --> Helper loaded: date_helper
INFO - 2018-08-08 00:32:13 --> Helper loaded: util_helper
INFO - 2018-08-08 00:32:13 --> Helper loaded: text_helper
INFO - 2018-08-08 00:32:13 --> Helper loaded: string_helper
INFO - 2018-08-08 00:32:13 --> Database Driver Class Initialized
DEBUG - 2018-08-08 00:32:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-08 00:32:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-08 00:32:13 --> Email Class Initialized
INFO - 2018-08-08 00:32:13 --> Controller Class Initialized
DEBUG - 2018-08-08 00:32:13 --> Home MX_Controller Initialized
DEBUG - 2018-08-08 00:32:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-08 00:32:14 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-08 00:32:14 --> Login MX_Controller Initialized
INFO - 2018-08-08 00:32:14 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-08 00:32:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-08 00:32:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-08 00:32:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Settings_model.php
DEBUG - 2018-08-08 00:32:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/login.php
INFO - 2018-08-08 00:33:06 --> Config Class Initialized
INFO - 2018-08-08 00:33:06 --> Hooks Class Initialized
DEBUG - 2018-08-08 00:33:06 --> UTF-8 Support Enabled
INFO - 2018-08-08 00:33:06 --> Utf8 Class Initialized
INFO - 2018-08-08 00:33:06 --> URI Class Initialized
INFO - 2018-08-08 00:33:06 --> Router Class Initialized
INFO - 2018-08-08 00:33:06 --> Output Class Initialized
INFO - 2018-08-08 00:33:06 --> Security Class Initialized
DEBUG - 2018-08-08 00:33:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-08 00:33:06 --> Input Class Initialized
INFO - 2018-08-08 00:33:06 --> Language Class Initialized
INFO - 2018-08-08 00:33:06 --> Language Class Initialized
INFO - 2018-08-08 00:33:06 --> Config Class Initialized
INFO - 2018-08-08 00:33:06 --> Loader Class Initialized
DEBUG - 2018-08-08 00:33:06 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-08 00:33:06 --> Helper loaded: url_helper
INFO - 2018-08-08 00:33:06 --> Helper loaded: form_helper
INFO - 2018-08-08 00:33:06 --> Helper loaded: date_helper
INFO - 2018-08-08 00:33:06 --> Helper loaded: util_helper
INFO - 2018-08-08 00:33:06 --> Helper loaded: text_helper
INFO - 2018-08-08 00:33:06 --> Helper loaded: string_helper
INFO - 2018-08-08 00:33:06 --> Database Driver Class Initialized
DEBUG - 2018-08-08 00:33:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-08 00:33:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-08 00:33:06 --> Email Class Initialized
INFO - 2018-08-08 00:33:07 --> Controller Class Initialized
DEBUG - 2018-08-08 00:33:07 --> Home MX_Controller Initialized
DEBUG - 2018-08-08 00:33:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-08 00:33:07 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-08 00:33:07 --> Login MX_Controller Initialized
INFO - 2018-08-08 00:33:07 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-08 00:33:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-08 00:33:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-08 00:33:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Settings_model.php
DEBUG - 2018-08-08 00:33:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/login.php
INFO - 2018-08-08 00:38:47 --> Config Class Initialized
INFO - 2018-08-08 00:38:47 --> Hooks Class Initialized
DEBUG - 2018-08-08 00:38:47 --> UTF-8 Support Enabled
INFO - 2018-08-08 00:38:47 --> Utf8 Class Initialized
INFO - 2018-08-08 00:38:47 --> URI Class Initialized
INFO - 2018-08-08 00:38:47 --> Router Class Initialized
INFO - 2018-08-08 00:38:47 --> Output Class Initialized
INFO - 2018-08-08 00:38:47 --> Security Class Initialized
DEBUG - 2018-08-08 00:38:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-08 00:38:47 --> Input Class Initialized
INFO - 2018-08-08 00:38:47 --> Language Class Initialized
INFO - 2018-08-08 00:38:47 --> Language Class Initialized
INFO - 2018-08-08 00:38:47 --> Config Class Initialized
INFO - 2018-08-08 00:38:47 --> Loader Class Initialized
DEBUG - 2018-08-08 00:38:47 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-08 00:38:47 --> Helper loaded: url_helper
INFO - 2018-08-08 00:38:47 --> Helper loaded: form_helper
INFO - 2018-08-08 00:38:47 --> Helper loaded: date_helper
INFO - 2018-08-08 00:38:47 --> Helper loaded: util_helper
INFO - 2018-08-08 00:38:47 --> Helper loaded: text_helper
INFO - 2018-08-08 00:38:47 --> Helper loaded: string_helper
INFO - 2018-08-08 00:38:47 --> Database Driver Class Initialized
DEBUG - 2018-08-08 00:38:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-08 00:38:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-08 00:38:47 --> Email Class Initialized
INFO - 2018-08-08 00:38:47 --> Controller Class Initialized
DEBUG - 2018-08-08 00:38:47 --> Home MX_Controller Initialized
DEBUG - 2018-08-08 00:38:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-08 00:38:47 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-08 00:38:47 --> Login MX_Controller Initialized
INFO - 2018-08-08 00:38:47 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-08 00:38:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-08 00:38:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-08 00:38:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Settings_model.php
DEBUG - 2018-08-08 00:38:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/login.php
INFO - 2018-08-08 00:38:54 --> Config Class Initialized
INFO - 2018-08-08 00:38:54 --> Hooks Class Initialized
DEBUG - 2018-08-08 00:38:54 --> UTF-8 Support Enabled
INFO - 2018-08-08 00:38:54 --> Utf8 Class Initialized
INFO - 2018-08-08 00:38:54 --> URI Class Initialized
INFO - 2018-08-08 00:38:54 --> Router Class Initialized
INFO - 2018-08-08 00:38:54 --> Output Class Initialized
INFO - 2018-08-08 00:38:54 --> Security Class Initialized
DEBUG - 2018-08-08 00:38:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-08 00:38:54 --> Input Class Initialized
INFO - 2018-08-08 00:38:54 --> Language Class Initialized
INFO - 2018-08-08 00:38:54 --> Language Class Initialized
INFO - 2018-08-08 00:38:54 --> Config Class Initialized
INFO - 2018-08-08 00:38:54 --> Loader Class Initialized
DEBUG - 2018-08-08 00:38:54 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-08 00:38:54 --> Helper loaded: url_helper
INFO - 2018-08-08 00:38:54 --> Helper loaded: form_helper
INFO - 2018-08-08 00:38:54 --> Helper loaded: date_helper
INFO - 2018-08-08 00:38:55 --> Helper loaded: util_helper
INFO - 2018-08-08 00:38:55 --> Helper loaded: text_helper
INFO - 2018-08-08 00:38:55 --> Helper loaded: string_helper
INFO - 2018-08-08 00:38:55 --> Database Driver Class Initialized
DEBUG - 2018-08-08 00:38:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-08 00:38:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-08 00:38:55 --> Email Class Initialized
INFO - 2018-08-08 00:38:55 --> Controller Class Initialized
DEBUG - 2018-08-08 00:38:55 --> Settings MX_Controller Initialized
INFO - 2018-08-08 00:38:55 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-08 00:38:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-08 00:38:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Settings_model.php
DEBUG - 2018-08-08 00:38:55 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-08 00:38:55 --> Login MX_Controller Initialized
DEBUG - 2018-08-08 00:38:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-08 00:38:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
INFO - 2018-08-08 00:38:55 --> Upload Class Initialized
ERROR - 2018-08-08 00:38:55 --> Severity: Notice --> Undefined variable: row E:\xampp\htdocs\consulting\application\modules\admin\controllers\settings.php 105
INFO - 2018-08-08 00:38:55 --> Config Class Initialized
INFO - 2018-08-08 00:38:55 --> Hooks Class Initialized
DEBUG - 2018-08-08 00:38:55 --> UTF-8 Support Enabled
INFO - 2018-08-08 00:38:55 --> Utf8 Class Initialized
INFO - 2018-08-08 00:38:55 --> URI Class Initialized
INFO - 2018-08-08 00:38:55 --> Router Class Initialized
INFO - 2018-08-08 00:38:55 --> Output Class Initialized
INFO - 2018-08-08 00:38:55 --> Security Class Initialized
DEBUG - 2018-08-08 00:38:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-08 00:38:55 --> Input Class Initialized
INFO - 2018-08-08 00:38:55 --> Language Class Initialized
INFO - 2018-08-08 00:38:55 --> Language Class Initialized
INFO - 2018-08-08 00:38:55 --> Config Class Initialized
INFO - 2018-08-08 00:38:55 --> Loader Class Initialized
DEBUG - 2018-08-08 00:38:55 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-08 00:38:55 --> Helper loaded: url_helper
INFO - 2018-08-08 00:38:55 --> Helper loaded: form_helper
INFO - 2018-08-08 00:38:55 --> Helper loaded: date_helper
INFO - 2018-08-08 00:38:55 --> Helper loaded: util_helper
INFO - 2018-08-08 00:38:55 --> Helper loaded: text_helper
INFO - 2018-08-08 00:38:55 --> Helper loaded: string_helper
INFO - 2018-08-08 00:38:55 --> Database Driver Class Initialized
DEBUG - 2018-08-08 00:38:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-08 00:38:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-08 00:38:55 --> Email Class Initialized
INFO - 2018-08-08 00:38:55 --> Controller Class Initialized
DEBUG - 2018-08-08 00:38:55 --> Settings MX_Controller Initialized
INFO - 2018-08-08 00:38:55 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-08 00:38:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-08 00:38:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Settings_model.php
DEBUG - 2018-08-08 00:38:55 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-08 00:38:55 --> Login MX_Controller Initialized
DEBUG - 2018-08-08 00:38:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-08 00:38:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-08-08 00:38:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-08-08 00:38:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-08-08 00:38:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-08-08 00:38:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-08-08 00:38:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/settings.php
INFO - 2018-08-08 00:38:55 --> Final output sent to browser
DEBUG - 2018-08-08 00:38:55 --> Total execution time: 0.4432
INFO - 2018-08-08 00:38:59 --> Config Class Initialized
INFO - 2018-08-08 00:38:59 --> Hooks Class Initialized
DEBUG - 2018-08-08 00:38:59 --> UTF-8 Support Enabled
INFO - 2018-08-08 00:38:59 --> Utf8 Class Initialized
INFO - 2018-08-08 00:38:59 --> URI Class Initialized
INFO - 2018-08-08 00:38:59 --> Router Class Initialized
INFO - 2018-08-08 00:38:59 --> Output Class Initialized
INFO - 2018-08-08 00:38:59 --> Security Class Initialized
DEBUG - 2018-08-08 00:38:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-08 00:38:59 --> Input Class Initialized
INFO - 2018-08-08 00:38:59 --> Language Class Initialized
INFO - 2018-08-08 00:38:59 --> Language Class Initialized
INFO - 2018-08-08 00:38:59 --> Config Class Initialized
INFO - 2018-08-08 00:38:59 --> Loader Class Initialized
DEBUG - 2018-08-08 00:38:59 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-08 00:38:59 --> Helper loaded: url_helper
INFO - 2018-08-08 00:38:59 --> Helper loaded: form_helper
INFO - 2018-08-08 00:38:59 --> Helper loaded: date_helper
INFO - 2018-08-08 00:38:59 --> Helper loaded: util_helper
INFO - 2018-08-08 00:38:59 --> Helper loaded: text_helper
INFO - 2018-08-08 00:38:59 --> Helper loaded: string_helper
INFO - 2018-08-08 00:38:59 --> Database Driver Class Initialized
DEBUG - 2018-08-08 00:38:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-08 00:38:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-08 00:38:59 --> Email Class Initialized
INFO - 2018-08-08 00:38:59 --> Controller Class Initialized
DEBUG - 2018-08-08 00:38:59 --> Home MX_Controller Initialized
DEBUG - 2018-08-08 00:38:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-08 00:38:59 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-08 00:38:59 --> Login MX_Controller Initialized
INFO - 2018-08-08 00:38:59 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-08 00:38:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-08 00:38:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-08 00:38:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Settings_model.php
DEBUG - 2018-08-08 00:38:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/login.php
INFO - 2018-08-08 00:39:11 --> Config Class Initialized
INFO - 2018-08-08 00:39:11 --> Hooks Class Initialized
DEBUG - 2018-08-08 00:39:11 --> UTF-8 Support Enabled
INFO - 2018-08-08 00:39:11 --> Utf8 Class Initialized
INFO - 2018-08-08 00:39:11 --> URI Class Initialized
INFO - 2018-08-08 00:39:11 --> Router Class Initialized
INFO - 2018-08-08 00:39:11 --> Output Class Initialized
INFO - 2018-08-08 00:39:11 --> Security Class Initialized
DEBUG - 2018-08-08 00:39:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-08 00:39:11 --> Input Class Initialized
INFO - 2018-08-08 00:39:11 --> Language Class Initialized
INFO - 2018-08-08 00:39:11 --> Language Class Initialized
INFO - 2018-08-08 00:39:11 --> Config Class Initialized
INFO - 2018-08-08 00:39:11 --> Loader Class Initialized
DEBUG - 2018-08-08 00:39:11 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-08 00:39:11 --> Helper loaded: url_helper
INFO - 2018-08-08 00:39:11 --> Helper loaded: form_helper
INFO - 2018-08-08 00:39:11 --> Helper loaded: date_helper
INFO - 2018-08-08 00:39:11 --> Helper loaded: util_helper
INFO - 2018-08-08 00:39:11 --> Helper loaded: text_helper
INFO - 2018-08-08 00:39:11 --> Helper loaded: string_helper
INFO - 2018-08-08 00:39:11 --> Database Driver Class Initialized
DEBUG - 2018-08-08 00:39:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-08 00:39:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-08 00:39:11 --> Email Class Initialized
INFO - 2018-08-08 00:39:11 --> Controller Class Initialized
DEBUG - 2018-08-08 00:39:11 --> Settings MX_Controller Initialized
INFO - 2018-08-08 00:39:11 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-08 00:39:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-08 00:39:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Settings_model.php
DEBUG - 2018-08-08 00:39:11 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-08 00:39:11 --> Login MX_Controller Initialized
DEBUG - 2018-08-08 00:39:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-08 00:39:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
INFO - 2018-08-08 00:39:11 --> Upload Class Initialized
ERROR - 2018-08-08 00:39:11 --> Severity: Notice --> Undefined variable: row E:\xampp\htdocs\consulting\application\modules\admin\controllers\settings.php 105
INFO - 2018-08-08 00:39:11 --> Config Class Initialized
INFO - 2018-08-08 00:39:11 --> Hooks Class Initialized
DEBUG - 2018-08-08 00:39:11 --> UTF-8 Support Enabled
INFO - 2018-08-08 00:39:11 --> Utf8 Class Initialized
INFO - 2018-08-08 00:39:11 --> URI Class Initialized
INFO - 2018-08-08 00:39:11 --> Router Class Initialized
INFO - 2018-08-08 00:39:11 --> Output Class Initialized
INFO - 2018-08-08 00:39:11 --> Security Class Initialized
DEBUG - 2018-08-08 00:39:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-08 00:39:11 --> Input Class Initialized
INFO - 2018-08-08 00:39:11 --> Language Class Initialized
INFO - 2018-08-08 00:39:11 --> Language Class Initialized
INFO - 2018-08-08 00:39:11 --> Config Class Initialized
INFO - 2018-08-08 00:39:11 --> Loader Class Initialized
DEBUG - 2018-08-08 00:39:11 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-08 00:39:11 --> Helper loaded: url_helper
INFO - 2018-08-08 00:39:11 --> Helper loaded: form_helper
INFO - 2018-08-08 00:39:11 --> Helper loaded: date_helper
INFO - 2018-08-08 00:39:11 --> Helper loaded: util_helper
INFO - 2018-08-08 00:39:11 --> Helper loaded: text_helper
INFO - 2018-08-08 00:39:11 --> Helper loaded: string_helper
INFO - 2018-08-08 00:39:11 --> Database Driver Class Initialized
DEBUG - 2018-08-08 00:39:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-08 00:39:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-08 00:39:11 --> Email Class Initialized
INFO - 2018-08-08 00:39:11 --> Controller Class Initialized
DEBUG - 2018-08-08 00:39:11 --> Settings MX_Controller Initialized
INFO - 2018-08-08 00:39:11 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-08 00:39:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-08 00:39:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Settings_model.php
DEBUG - 2018-08-08 00:39:11 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-08 00:39:11 --> Login MX_Controller Initialized
DEBUG - 2018-08-08 00:39:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-08 00:39:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-08-08 00:39:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-08-08 00:39:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-08-08 00:39:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-08-08 00:39:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-08-08 00:39:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/settings.php
INFO - 2018-08-08 00:39:12 --> Final output sent to browser
DEBUG - 2018-08-08 00:39:12 --> Total execution time: 0.4051
INFO - 2018-08-08 00:39:16 --> Config Class Initialized
INFO - 2018-08-08 00:39:16 --> Hooks Class Initialized
DEBUG - 2018-08-08 00:39:16 --> UTF-8 Support Enabled
INFO - 2018-08-08 00:39:16 --> Utf8 Class Initialized
INFO - 2018-08-08 00:39:16 --> URI Class Initialized
INFO - 2018-08-08 00:39:16 --> Router Class Initialized
INFO - 2018-08-08 00:39:16 --> Output Class Initialized
INFO - 2018-08-08 00:39:16 --> Security Class Initialized
DEBUG - 2018-08-08 00:39:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-08 00:39:16 --> Input Class Initialized
INFO - 2018-08-08 00:39:16 --> Language Class Initialized
INFO - 2018-08-08 00:39:16 --> Language Class Initialized
INFO - 2018-08-08 00:39:16 --> Config Class Initialized
INFO - 2018-08-08 00:39:16 --> Loader Class Initialized
DEBUG - 2018-08-08 00:39:16 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-08 00:39:16 --> Helper loaded: url_helper
INFO - 2018-08-08 00:39:16 --> Helper loaded: form_helper
INFO - 2018-08-08 00:39:16 --> Helper loaded: date_helper
INFO - 2018-08-08 00:39:16 --> Helper loaded: util_helper
INFO - 2018-08-08 00:39:16 --> Helper loaded: text_helper
INFO - 2018-08-08 00:39:16 --> Helper loaded: string_helper
INFO - 2018-08-08 00:39:16 --> Database Driver Class Initialized
DEBUG - 2018-08-08 00:39:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-08 00:39:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-08 00:39:16 --> Email Class Initialized
INFO - 2018-08-08 00:39:16 --> Controller Class Initialized
DEBUG - 2018-08-08 00:39:16 --> Home MX_Controller Initialized
DEBUG - 2018-08-08 00:39:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-08 00:39:16 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-08 00:39:16 --> Login MX_Controller Initialized
INFO - 2018-08-08 00:39:16 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-08 00:39:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-08 00:39:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-08 00:39:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Settings_model.php
DEBUG - 2018-08-08 00:39:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/login.php
INFO - 2018-08-08 00:39:37 --> Config Class Initialized
INFO - 2018-08-08 00:39:37 --> Hooks Class Initialized
DEBUG - 2018-08-08 00:39:37 --> UTF-8 Support Enabled
INFO - 2018-08-08 00:39:37 --> Utf8 Class Initialized
INFO - 2018-08-08 00:39:37 --> URI Class Initialized
INFO - 2018-08-08 00:39:37 --> Router Class Initialized
INFO - 2018-08-08 00:39:37 --> Output Class Initialized
INFO - 2018-08-08 00:39:37 --> Security Class Initialized
DEBUG - 2018-08-08 00:39:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-08 00:39:37 --> Input Class Initialized
INFO - 2018-08-08 00:39:37 --> Language Class Initialized
INFO - 2018-08-08 00:39:37 --> Language Class Initialized
INFO - 2018-08-08 00:39:37 --> Config Class Initialized
INFO - 2018-08-08 00:39:37 --> Loader Class Initialized
DEBUG - 2018-08-08 00:39:37 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-08 00:39:37 --> Helper loaded: url_helper
INFO - 2018-08-08 00:39:37 --> Helper loaded: form_helper
INFO - 2018-08-08 00:39:37 --> Helper loaded: date_helper
INFO - 2018-08-08 00:39:37 --> Helper loaded: util_helper
INFO - 2018-08-08 00:39:37 --> Helper loaded: text_helper
INFO - 2018-08-08 00:39:37 --> Helper loaded: string_helper
INFO - 2018-08-08 00:39:37 --> Database Driver Class Initialized
DEBUG - 2018-08-08 00:39:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-08 00:39:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-08 00:39:37 --> Email Class Initialized
INFO - 2018-08-08 00:39:37 --> Controller Class Initialized
DEBUG - 2018-08-08 00:39:37 --> Settings MX_Controller Initialized
INFO - 2018-08-08 00:39:37 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-08 00:39:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-08 00:39:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Settings_model.php
DEBUG - 2018-08-08 00:39:37 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-08 00:39:37 --> Login MX_Controller Initialized
DEBUG - 2018-08-08 00:39:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-08 00:39:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
INFO - 2018-08-08 00:39:37 --> Upload Class Initialized
ERROR - 2018-08-08 00:39:37 --> Severity: Notice --> Undefined variable: row E:\xampp\htdocs\consulting\application\modules\admin\controllers\settings.php 105
INFO - 2018-08-08 00:39:37 --> Config Class Initialized
INFO - 2018-08-08 00:39:37 --> Hooks Class Initialized
DEBUG - 2018-08-08 00:39:37 --> UTF-8 Support Enabled
INFO - 2018-08-08 00:39:37 --> Utf8 Class Initialized
INFO - 2018-08-08 00:39:37 --> URI Class Initialized
INFO - 2018-08-08 00:39:37 --> Router Class Initialized
INFO - 2018-08-08 00:39:37 --> Output Class Initialized
INFO - 2018-08-08 00:39:37 --> Security Class Initialized
DEBUG - 2018-08-08 00:39:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-08 00:39:37 --> Input Class Initialized
INFO - 2018-08-08 00:39:37 --> Language Class Initialized
INFO - 2018-08-08 00:39:37 --> Language Class Initialized
INFO - 2018-08-08 00:39:37 --> Config Class Initialized
INFO - 2018-08-08 00:39:37 --> Loader Class Initialized
DEBUG - 2018-08-08 00:39:37 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-08 00:39:37 --> Helper loaded: url_helper
INFO - 2018-08-08 00:39:37 --> Helper loaded: form_helper
INFO - 2018-08-08 00:39:37 --> Helper loaded: date_helper
INFO - 2018-08-08 00:39:37 --> Helper loaded: util_helper
INFO - 2018-08-08 00:39:37 --> Helper loaded: text_helper
INFO - 2018-08-08 00:39:38 --> Helper loaded: string_helper
INFO - 2018-08-08 00:39:38 --> Database Driver Class Initialized
DEBUG - 2018-08-08 00:39:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-08 00:39:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-08 00:39:38 --> Email Class Initialized
INFO - 2018-08-08 00:39:38 --> Controller Class Initialized
DEBUG - 2018-08-08 00:39:38 --> Settings MX_Controller Initialized
INFO - 2018-08-08 00:39:38 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-08 00:39:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-08 00:39:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Settings_model.php
DEBUG - 2018-08-08 00:39:38 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-08 00:39:38 --> Login MX_Controller Initialized
DEBUG - 2018-08-08 00:39:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-08 00:39:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-08-08 00:39:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-08-08 00:39:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-08-08 00:39:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-08-08 00:39:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-08-08 00:39:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/settings.php
INFO - 2018-08-08 00:39:38 --> Final output sent to browser
DEBUG - 2018-08-08 00:39:38 --> Total execution time: 0.4950
INFO - 2018-08-08 00:39:41 --> Config Class Initialized
INFO - 2018-08-08 00:39:42 --> Hooks Class Initialized
DEBUG - 2018-08-08 00:39:42 --> UTF-8 Support Enabled
INFO - 2018-08-08 00:39:42 --> Utf8 Class Initialized
INFO - 2018-08-08 00:39:42 --> URI Class Initialized
INFO - 2018-08-08 00:39:42 --> Router Class Initialized
INFO - 2018-08-08 00:39:42 --> Output Class Initialized
INFO - 2018-08-08 00:39:42 --> Security Class Initialized
DEBUG - 2018-08-08 00:39:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-08 00:39:42 --> Input Class Initialized
INFO - 2018-08-08 00:39:42 --> Language Class Initialized
INFO - 2018-08-08 00:39:42 --> Language Class Initialized
INFO - 2018-08-08 00:39:42 --> Config Class Initialized
INFO - 2018-08-08 00:39:42 --> Loader Class Initialized
DEBUG - 2018-08-08 00:39:42 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-08 00:39:42 --> Helper loaded: url_helper
INFO - 2018-08-08 00:39:42 --> Helper loaded: form_helper
INFO - 2018-08-08 00:39:42 --> Helper loaded: date_helper
INFO - 2018-08-08 00:39:42 --> Helper loaded: util_helper
INFO - 2018-08-08 00:39:42 --> Helper loaded: text_helper
INFO - 2018-08-08 00:39:42 --> Helper loaded: string_helper
INFO - 2018-08-08 00:39:42 --> Database Driver Class Initialized
DEBUG - 2018-08-08 00:39:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-08 00:39:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-08 00:39:42 --> Email Class Initialized
INFO - 2018-08-08 00:39:42 --> Controller Class Initialized
DEBUG - 2018-08-08 00:39:42 --> Home MX_Controller Initialized
DEBUG - 2018-08-08 00:39:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-08 00:39:42 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-08 00:39:42 --> Login MX_Controller Initialized
INFO - 2018-08-08 00:39:42 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-08 00:39:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-08 00:39:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-08 00:39:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Settings_model.php
DEBUG - 2018-08-08 00:39:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/login.php
INFO - 2018-08-08 00:43:57 --> Config Class Initialized
INFO - 2018-08-08 00:43:57 --> Hooks Class Initialized
DEBUG - 2018-08-08 00:43:57 --> UTF-8 Support Enabled
INFO - 2018-08-08 00:43:57 --> Utf8 Class Initialized
INFO - 2018-08-08 00:43:57 --> URI Class Initialized
INFO - 2018-08-08 00:43:57 --> Router Class Initialized
INFO - 2018-08-08 00:43:57 --> Output Class Initialized
INFO - 2018-08-08 00:43:57 --> Security Class Initialized
DEBUG - 2018-08-08 00:43:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-08 00:43:57 --> Input Class Initialized
INFO - 2018-08-08 00:43:57 --> Language Class Initialized
INFO - 2018-08-08 00:43:57 --> Language Class Initialized
INFO - 2018-08-08 00:43:57 --> Config Class Initialized
INFO - 2018-08-08 00:43:57 --> Loader Class Initialized
DEBUG - 2018-08-08 00:43:57 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-08 00:43:57 --> Helper loaded: url_helper
INFO - 2018-08-08 00:43:57 --> Helper loaded: form_helper
INFO - 2018-08-08 00:43:57 --> Helper loaded: date_helper
INFO - 2018-08-08 00:43:57 --> Helper loaded: util_helper
INFO - 2018-08-08 00:43:57 --> Helper loaded: text_helper
INFO - 2018-08-08 00:43:57 --> Helper loaded: string_helper
INFO - 2018-08-08 00:43:57 --> Database Driver Class Initialized
DEBUG - 2018-08-08 00:43:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-08 00:43:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-08 00:43:57 --> Email Class Initialized
INFO - 2018-08-08 00:43:57 --> Controller Class Initialized
DEBUG - 2018-08-08 00:43:57 --> Login MX_Controller Initialized
INFO - 2018-08-08 00:43:57 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-08 00:43:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-08 00:43:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-08 00:43:57 --> Email starts for colinUser fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-08-08 00:43:57 --> User session created for 4
INFO - 2018-08-08 00:43:57 --> Login status colinUser - success
INFO - 2018-08-08 00:43:57 --> Final output sent to browser
DEBUG - 2018-08-08 00:43:57 --> Total execution time: 0.4406
INFO - 2018-08-08 00:43:57 --> Config Class Initialized
INFO - 2018-08-08 00:43:57 --> Hooks Class Initialized
DEBUG - 2018-08-08 00:43:57 --> UTF-8 Support Enabled
INFO - 2018-08-08 00:43:57 --> Utf8 Class Initialized
INFO - 2018-08-08 00:43:57 --> URI Class Initialized
INFO - 2018-08-08 00:43:57 --> Router Class Initialized
INFO - 2018-08-08 00:43:57 --> Output Class Initialized
INFO - 2018-08-08 00:43:57 --> Security Class Initialized
DEBUG - 2018-08-08 00:43:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-08 00:43:57 --> Input Class Initialized
INFO - 2018-08-08 00:43:57 --> Language Class Initialized
INFO - 2018-08-08 00:43:57 --> Language Class Initialized
INFO - 2018-08-08 00:43:57 --> Config Class Initialized
INFO - 2018-08-08 00:43:57 --> Loader Class Initialized
DEBUG - 2018-08-08 00:43:57 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-08 00:43:57 --> Helper loaded: url_helper
INFO - 2018-08-08 00:43:57 --> Helper loaded: form_helper
INFO - 2018-08-08 00:43:57 --> Helper loaded: date_helper
INFO - 2018-08-08 00:43:57 --> Helper loaded: util_helper
INFO - 2018-08-08 00:43:57 --> Helper loaded: text_helper
INFO - 2018-08-08 00:43:57 --> Helper loaded: string_helper
INFO - 2018-08-08 00:43:57 --> Database Driver Class Initialized
DEBUG - 2018-08-08 00:43:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-08 00:43:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-08 00:43:57 --> Email Class Initialized
INFO - 2018-08-08 00:43:57 --> Controller Class Initialized
DEBUG - 2018-08-08 00:43:57 --> Home MX_Controller Initialized
DEBUG - 2018-08-08 00:43:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-08 00:43:57 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-08 00:43:57 --> Login MX_Controller Initialized
INFO - 2018-08-08 00:43:57 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-08 00:43:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-08 00:43:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-08 00:43:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-08-08 00:43:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-08-08 00:43:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-08-08 00:43:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-08-08 00:43:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-08-08 00:43:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-08-08 00:43:58 --> Final output sent to browser
DEBUG - 2018-08-08 00:43:58 --> Total execution time: 0.4909
INFO - 2018-08-08 00:43:58 --> Config Class Initialized
INFO - 2018-08-08 00:43:58 --> Hooks Class Initialized
DEBUG - 2018-08-08 00:43:58 --> UTF-8 Support Enabled
INFO - 2018-08-08 00:43:58 --> Utf8 Class Initialized
INFO - 2018-08-08 00:43:58 --> URI Class Initialized
INFO - 2018-08-08 00:43:58 --> Config Class Initialized
INFO - 2018-08-08 00:43:58 --> Router Class Initialized
INFO - 2018-08-08 00:43:58 --> Hooks Class Initialized
INFO - 2018-08-08 00:43:58 --> Output Class Initialized
INFO - 2018-08-08 00:43:58 --> Security Class Initialized
DEBUG - 2018-08-08 00:43:58 --> UTF-8 Support Enabled
DEBUG - 2018-08-08 00:43:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-08 00:43:58 --> Input Class Initialized
INFO - 2018-08-08 00:43:58 --> Language Class Initialized
INFO - 2018-08-08 00:43:58 --> Utf8 Class Initialized
ERROR - 2018-08-08 00:43:58 --> 404 Page Not Found: /index
INFO - 2018-08-08 00:43:58 --> URI Class Initialized
INFO - 2018-08-08 00:43:58 --> Router Class Initialized
INFO - 2018-08-08 00:43:58 --> Config Class Initialized
INFO - 2018-08-08 00:43:58 --> Hooks Class Initialized
INFO - 2018-08-08 00:43:58 --> Output Class Initialized
DEBUG - 2018-08-08 00:43:58 --> UTF-8 Support Enabled
INFO - 2018-08-08 00:43:58 --> Utf8 Class Initialized
INFO - 2018-08-08 00:43:58 --> Security Class Initialized
INFO - 2018-08-08 00:43:58 --> URI Class Initialized
DEBUG - 2018-08-08 00:43:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-08 00:43:58 --> Router Class Initialized
INFO - 2018-08-08 00:43:58 --> Input Class Initialized
INFO - 2018-08-08 00:43:58 --> Output Class Initialized
INFO - 2018-08-08 00:43:58 --> Security Class Initialized
INFO - 2018-08-08 00:43:58 --> Language Class Initialized
INFO - 2018-08-08 00:43:59 --> Language Class Initialized
DEBUG - 2018-08-08 00:43:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-08 00:43:59 --> Config Class Initialized
INFO - 2018-08-08 00:43:59 --> Input Class Initialized
INFO - 2018-08-08 00:43:59 --> Loader Class Initialized
INFO - 2018-08-08 00:43:59 --> Language Class Initialized
DEBUG - 2018-08-08 00:43:59 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
ERROR - 2018-08-08 00:43:59 --> 404 Page Not Found: /index
INFO - 2018-08-08 00:43:59 --> Helper loaded: url_helper
INFO - 2018-08-08 00:43:59 --> Helper loaded: form_helper
INFO - 2018-08-08 00:43:59 --> Config Class Initialized
INFO - 2018-08-08 00:43:59 --> Hooks Class Initialized
INFO - 2018-08-08 00:43:59 --> Helper loaded: date_helper
DEBUG - 2018-08-08 00:43:59 --> UTF-8 Support Enabled
INFO - 2018-08-08 00:43:59 --> Utf8 Class Initialized
INFO - 2018-08-08 00:43:59 --> URI Class Initialized
INFO - 2018-08-08 00:43:59 --> Router Class Initialized
INFO - 2018-08-08 00:43:59 --> Output Class Initialized
INFO - 2018-08-08 00:43:59 --> Helper loaded: util_helper
INFO - 2018-08-08 00:43:59 --> Security Class Initialized
INFO - 2018-08-08 00:43:59 --> Helper loaded: text_helper
DEBUG - 2018-08-08 00:43:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-08 00:43:59 --> Helper loaded: string_helper
INFO - 2018-08-08 00:43:59 --> Input Class Initialized
INFO - 2018-08-08 00:43:59 --> Language Class Initialized
INFO - 2018-08-08 00:43:59 --> Database Driver Class Initialized
ERROR - 2018-08-08 00:43:59 --> 404 Page Not Found: /index
DEBUG - 2018-08-08 00:43:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-08 00:43:59 --> Config Class Initialized
INFO - 2018-08-08 00:43:59 --> Hooks Class Initialized
INFO - 2018-08-08 00:43:59 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-08-08 00:43:59 --> UTF-8 Support Enabled
INFO - 2018-08-08 00:43:59 --> Email Class Initialized
INFO - 2018-08-08 00:43:59 --> Utf8 Class Initialized
INFO - 2018-08-08 00:43:59 --> Controller Class Initialized
INFO - 2018-08-08 00:43:59 --> Config Class Initialized
INFO - 2018-08-08 00:43:59 --> URI Class Initialized
INFO - 2018-08-08 00:43:59 --> Hooks Class Initialized
DEBUG - 2018-08-08 00:43:59 --> Home MX_Controller Initialized
DEBUG - 2018-08-08 00:43:59 --> UTF-8 Support Enabled
INFO - 2018-08-08 00:43:59 --> Utf8 Class Initialized
INFO - 2018-08-08 00:43:59 --> URI Class Initialized
DEBUG - 2018-08-08 00:43:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-08-08 00:43:59 --> Router Class Initialized
INFO - 2018-08-08 00:43:59 --> Router Class Initialized
INFO - 2018-08-08 00:43:59 --> Output Class Initialized
INFO - 2018-08-08 00:43:59 --> Output Class Initialized
INFO - 2018-08-08 00:43:59 --> Security Class Initialized
INFO - 2018-08-08 00:43:59 --> Security Class Initialized
DEBUG - 2018-08-08 00:43:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-08-08 00:43:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-08 00:43:59 --> Input Class Initialized
INFO - 2018-08-08 00:43:59 --> Input Class Initialized
INFO - 2018-08-08 00:43:59 --> Language Class Initialized
INFO - 2018-08-08 00:43:59 --> Language Class Initialized
ERROR - 2018-08-08 00:43:59 --> 404 Page Not Found: /index
ERROR - 2018-08-08 00:43:59 --> 404 Page Not Found: /index
INFO - 2018-08-08 00:43:59 --> Config Class Initialized
INFO - 2018-08-08 00:43:59 --> Config Class Initialized
INFO - 2018-08-08 00:43:59 --> Hooks Class Initialized
INFO - 2018-08-08 00:43:59 --> Hooks Class Initialized
DEBUG - 2018-08-08 00:43:59 --> UTF-8 Support Enabled
DEBUG - 2018-08-08 00:43:59 --> UTF-8 Support Enabled
INFO - 2018-08-08 00:43:59 --> Utf8 Class Initialized
INFO - 2018-08-08 00:43:59 --> Utf8 Class Initialized
INFO - 2018-08-08 00:43:59 --> URI Class Initialized
INFO - 2018-08-08 00:43:59 --> URI Class Initialized
INFO - 2018-08-08 00:44:00 --> Router Class Initialized
INFO - 2018-08-08 00:44:00 --> Router Class Initialized
INFO - 2018-08-08 00:44:00 --> Output Class Initialized
INFO - 2018-08-08 00:44:00 --> Output Class Initialized
INFO - 2018-08-08 00:44:00 --> Security Class Initialized
INFO - 2018-08-08 00:44:00 --> Security Class Initialized
DEBUG - 2018-08-08 00:44:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-08-08 00:44:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-08 00:44:00 --> Input Class Initialized
INFO - 2018-08-08 00:44:00 --> Input Class Initialized
INFO - 2018-08-08 00:44:00 --> Language Class Initialized
INFO - 2018-08-08 00:44:00 --> Language Class Initialized
ERROR - 2018-08-08 00:44:00 --> 404 Page Not Found: /index
ERROR - 2018-08-08 00:44:00 --> 404 Page Not Found: /index
INFO - 2018-08-08 00:44:00 --> Config Class Initialized
INFO - 2018-08-08 00:44:00 --> Config Class Initialized
INFO - 2018-08-08 00:44:00 --> Hooks Class Initialized
INFO - 2018-08-08 00:44:00 --> Hooks Class Initialized
DEBUG - 2018-08-08 00:44:00 --> UTF-8 Support Enabled
DEBUG - 2018-08-08 00:44:00 --> UTF-8 Support Enabled
INFO - 2018-08-08 00:44:00 --> Utf8 Class Initialized
INFO - 2018-08-08 00:44:00 --> Utf8 Class Initialized
INFO - 2018-08-08 00:44:00 --> URI Class Initialized
INFO - 2018-08-08 00:44:00 --> URI Class Initialized
INFO - 2018-08-08 00:44:00 --> Router Class Initialized
INFO - 2018-08-08 00:44:00 --> Router Class Initialized
INFO - 2018-08-08 00:44:00 --> Output Class Initialized
INFO - 2018-08-08 00:44:00 --> Output Class Initialized
INFO - 2018-08-08 00:44:00 --> Security Class Initialized
INFO - 2018-08-08 00:44:00 --> Security Class Initialized
DEBUG - 2018-08-08 00:44:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-08-08 00:44:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-08 00:44:00 --> Input Class Initialized
INFO - 2018-08-08 00:44:00 --> Input Class Initialized
INFO - 2018-08-08 00:44:00 --> Language Class Initialized
INFO - 2018-08-08 00:44:00 --> Language Class Initialized
ERROR - 2018-08-08 00:44:00 --> 404 Page Not Found: /index
ERROR - 2018-08-08 00:44:00 --> 404 Page Not Found: /index
INFO - 2018-08-08 00:44:00 --> Config Class Initialized
INFO - 2018-08-08 00:44:00 --> Hooks Class Initialized
DEBUG - 2018-08-08 00:44:00 --> UTF-8 Support Enabled
INFO - 2018-08-08 00:44:00 --> Utf8 Class Initialized
INFO - 2018-08-08 00:44:00 --> URI Class Initialized
INFO - 2018-08-08 00:44:00 --> Router Class Initialized
INFO - 2018-08-08 00:44:00 --> Output Class Initialized
INFO - 2018-08-08 00:44:00 --> Security Class Initialized
DEBUG - 2018-08-08 00:44:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-08 00:44:00 --> Input Class Initialized
INFO - 2018-08-08 00:44:00 --> Language Class Initialized
ERROR - 2018-08-08 00:44:00 --> 404 Page Not Found: /index
INFO - 2018-08-08 00:44:58 --> Config Class Initialized
INFO - 2018-08-08 00:44:58 --> Hooks Class Initialized
DEBUG - 2018-08-08 00:44:58 --> UTF-8 Support Enabled
INFO - 2018-08-08 00:44:58 --> Utf8 Class Initialized
INFO - 2018-08-08 00:44:58 --> URI Class Initialized
INFO - 2018-08-08 00:44:58 --> Router Class Initialized
INFO - 2018-08-08 00:44:58 --> Output Class Initialized
INFO - 2018-08-08 00:44:58 --> Security Class Initialized
DEBUG - 2018-08-08 00:44:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-08 00:44:58 --> Input Class Initialized
INFO - 2018-08-08 00:44:58 --> Language Class Initialized
INFO - 2018-08-08 00:44:58 --> Language Class Initialized
INFO - 2018-08-08 00:44:58 --> Config Class Initialized
INFO - 2018-08-08 00:44:58 --> Loader Class Initialized
DEBUG - 2018-08-08 00:44:58 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-08 00:44:58 --> Helper loaded: url_helper
INFO - 2018-08-08 00:44:58 --> Helper loaded: form_helper
INFO - 2018-08-08 00:44:58 --> Helper loaded: date_helper
INFO - 2018-08-08 00:44:58 --> Helper loaded: util_helper
INFO - 2018-08-08 00:44:58 --> Helper loaded: text_helper
INFO - 2018-08-08 00:44:58 --> Helper loaded: string_helper
INFO - 2018-08-08 00:44:58 --> Database Driver Class Initialized
DEBUG - 2018-08-08 00:44:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-08 00:44:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-08 00:44:58 --> Email Class Initialized
INFO - 2018-08-08 00:44:58 --> Controller Class Initialized
DEBUG - 2018-08-08 00:44:58 --> Home MX_Controller Initialized
DEBUG - 2018-08-08 00:44:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-08 00:44:58 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-08 00:44:58 --> Login MX_Controller Initialized
INFO - 2018-08-08 00:44:58 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-08 00:44:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-08 00:44:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-08 00:44:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-08-08 00:44:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-08-08 00:44:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-08-08 00:44:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-08-08 00:44:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-08-08 00:44:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-08-08 00:44:58 --> Final output sent to browser
DEBUG - 2018-08-08 00:44:58 --> Total execution time: 0.4222
INFO - 2018-08-08 00:44:59 --> Config Class Initialized
INFO - 2018-08-08 00:44:59 --> Hooks Class Initialized
DEBUG - 2018-08-08 00:44:59 --> UTF-8 Support Enabled
INFO - 2018-08-08 00:44:59 --> Utf8 Class Initialized
INFO - 2018-08-08 00:44:59 --> URI Class Initialized
INFO - 2018-08-08 00:44:59 --> Router Class Initialized
INFO - 2018-08-08 00:44:59 --> Config Class Initialized
INFO - 2018-08-08 00:44:59 --> Hooks Class Initialized
INFO - 2018-08-08 00:44:59 --> Output Class Initialized
INFO - 2018-08-08 00:44:59 --> Security Class Initialized
DEBUG - 2018-08-08 00:44:59 --> UTF-8 Support Enabled
INFO - 2018-08-08 00:44:59 --> Utf8 Class Initialized
DEBUG - 2018-08-08 00:44:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-08 00:44:59 --> URI Class Initialized
INFO - 2018-08-08 00:44:59 --> Router Class Initialized
INFO - 2018-08-08 00:44:59 --> Input Class Initialized
INFO - 2018-08-08 00:44:59 --> Output Class Initialized
INFO - 2018-08-08 00:44:59 --> Language Class Initialized
ERROR - 2018-08-08 00:44:59 --> 404 Page Not Found: /index
INFO - 2018-08-08 00:44:59 --> Security Class Initialized
INFO - 2018-08-08 00:44:59 --> Config Class Initialized
INFO - 2018-08-08 00:44:59 --> Hooks Class Initialized
DEBUG - 2018-08-08 00:44:59 --> UTF-8 Support Enabled
DEBUG - 2018-08-08 00:44:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-08 00:44:59 --> Utf8 Class Initialized
INFO - 2018-08-08 00:44:59 --> URI Class Initialized
INFO - 2018-08-08 00:44:59 --> Input Class Initialized
INFO - 2018-08-08 00:44:59 --> Router Class Initialized
INFO - 2018-08-08 00:44:59 --> Language Class Initialized
INFO - 2018-08-08 00:44:59 --> Output Class Initialized
INFO - 2018-08-08 00:44:59 --> Security Class Initialized
INFO - 2018-08-08 00:44:59 --> Language Class Initialized
INFO - 2018-08-08 00:44:59 --> Config Class Initialized
DEBUG - 2018-08-08 00:44:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-08 00:44:59 --> Input Class Initialized
INFO - 2018-08-08 00:44:59 --> Loader Class Initialized
INFO - 2018-08-08 00:44:59 --> Language Class Initialized
DEBUG - 2018-08-08 00:44:59 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
ERROR - 2018-08-08 00:44:59 --> 404 Page Not Found: /index
INFO - 2018-08-08 00:44:59 --> Helper loaded: url_helper
INFO - 2018-08-08 00:44:59 --> Helper loaded: form_helper
INFO - 2018-08-08 00:44:59 --> Config Class Initialized
INFO - 2018-08-08 00:44:59 --> Hooks Class Initialized
INFO - 2018-08-08 00:44:59 --> Helper loaded: date_helper
INFO - 2018-08-08 00:44:59 --> Helper loaded: util_helper
DEBUG - 2018-08-08 00:44:59 --> UTF-8 Support Enabled
INFO - 2018-08-08 00:44:59 --> Utf8 Class Initialized
INFO - 2018-08-08 00:44:59 --> Helper loaded: text_helper
INFO - 2018-08-08 00:44:59 --> URI Class Initialized
INFO - 2018-08-08 00:45:00 --> Helper loaded: string_helper
INFO - 2018-08-08 00:45:00 --> Router Class Initialized
INFO - 2018-08-08 00:45:00 --> Output Class Initialized
INFO - 2018-08-08 00:45:00 --> Database Driver Class Initialized
INFO - 2018-08-08 00:45:00 --> Security Class Initialized
DEBUG - 2018-08-08 00:45:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-08 00:45:00 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-08-08 00:45:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-08 00:45:00 --> Input Class Initialized
INFO - 2018-08-08 00:45:00 --> Email Class Initialized
INFO - 2018-08-08 00:45:00 --> Controller Class Initialized
INFO - 2018-08-08 00:45:00 --> Language Class Initialized
DEBUG - 2018-08-08 00:45:00 --> Home MX_Controller Initialized
ERROR - 2018-08-08 00:45:00 --> 404 Page Not Found: /index
DEBUG - 2018-08-08 00:45:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-08-08 00:48:22 --> Config Class Initialized
INFO - 2018-08-08 00:48:22 --> Hooks Class Initialized
DEBUG - 2018-08-08 00:48:22 --> UTF-8 Support Enabled
INFO - 2018-08-08 00:48:22 --> Utf8 Class Initialized
INFO - 2018-08-08 00:48:22 --> URI Class Initialized
DEBUG - 2018-08-08 00:48:22 --> No URI present. Default controller set.
INFO - 2018-08-08 00:48:22 --> Router Class Initialized
INFO - 2018-08-08 00:48:22 --> Output Class Initialized
INFO - 2018-08-08 00:48:22 --> Security Class Initialized
DEBUG - 2018-08-08 00:48:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-08 00:48:22 --> Input Class Initialized
INFO - 2018-08-08 00:48:22 --> Language Class Initialized
INFO - 2018-08-08 00:48:22 --> Language Class Initialized
INFO - 2018-08-08 00:48:22 --> Config Class Initialized
INFO - 2018-08-08 00:48:22 --> Loader Class Initialized
DEBUG - 2018-08-08 00:48:22 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-08 00:48:22 --> Helper loaded: url_helper
INFO - 2018-08-08 00:48:22 --> Helper loaded: form_helper
INFO - 2018-08-08 00:48:22 --> Helper loaded: date_helper
INFO - 2018-08-08 00:48:22 --> Helper loaded: util_helper
INFO - 2018-08-08 00:48:22 --> Helper loaded: text_helper
INFO - 2018-08-08 00:48:22 --> Helper loaded: string_helper
INFO - 2018-08-08 00:48:22 --> Database Driver Class Initialized
DEBUG - 2018-08-08 00:48:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-08 00:48:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-08 00:48:22 --> Email Class Initialized
INFO - 2018-08-08 00:48:22 --> Controller Class Initialized
DEBUG - 2018-08-08 00:48:22 --> Home MX_Controller Initialized
DEBUG - 2018-08-08 00:48:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-08 00:48:22 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-08 00:48:22 --> Login MX_Controller Initialized
INFO - 2018-08-08 00:48:22 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-08 00:48:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-08 00:48:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-08 00:48:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Settings_model.php
DEBUG - 2018-08-08 00:48:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/login.php
INFO - 2018-08-08 00:56:40 --> Config Class Initialized
INFO - 2018-08-08 00:56:40 --> Hooks Class Initialized
DEBUG - 2018-08-08 00:56:40 --> UTF-8 Support Enabled
INFO - 2018-08-08 00:56:40 --> Utf8 Class Initialized
INFO - 2018-08-08 00:56:40 --> URI Class Initialized
INFO - 2018-08-08 00:56:40 --> Router Class Initialized
INFO - 2018-08-08 00:56:40 --> Output Class Initialized
INFO - 2018-08-08 00:56:40 --> Security Class Initialized
DEBUG - 2018-08-08 00:56:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-08 00:56:40 --> Input Class Initialized
INFO - 2018-08-08 00:56:40 --> Language Class Initialized
INFO - 2018-08-08 00:56:40 --> Language Class Initialized
INFO - 2018-08-08 00:56:40 --> Config Class Initialized
INFO - 2018-08-08 00:56:40 --> Loader Class Initialized
DEBUG - 2018-08-08 00:56:40 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-08 00:56:40 --> Helper loaded: url_helper
INFO - 2018-08-08 00:56:40 --> Helper loaded: form_helper
INFO - 2018-08-08 00:56:40 --> Helper loaded: date_helper
INFO - 2018-08-08 00:56:40 --> Helper loaded: util_helper
INFO - 2018-08-08 00:56:40 --> Helper loaded: text_helper
INFO - 2018-08-08 00:56:40 --> Helper loaded: string_helper
INFO - 2018-08-08 00:56:40 --> Database Driver Class Initialized
DEBUG - 2018-08-08 00:56:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-08 00:56:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-08 00:56:40 --> Email Class Initialized
INFO - 2018-08-08 00:56:40 --> Controller Class Initialized
DEBUG - 2018-08-08 00:56:40 --> Settings MX_Controller Initialized
INFO - 2018-08-08 00:56:40 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-08 00:56:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-08 00:56:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Settings_model.php
DEBUG - 2018-08-08 00:56:40 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-08 00:56:40 --> Login MX_Controller Initialized
DEBUG - 2018-08-08 00:56:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-08 00:56:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
INFO - 2018-08-08 00:56:40 --> Upload Class Initialized
INFO - 2018-08-08 00:56:40 --> Language file loaded: language/english/upload_lang.php
DEBUG - 2018-08-08 00:56:40 --> The filetype you are attempting to upload is not allowed.
INFO - 2018-08-08 00:56:40 --> Config Class Initialized
INFO - 2018-08-08 00:56:40 --> Hooks Class Initialized
DEBUG - 2018-08-08 00:56:40 --> UTF-8 Support Enabled
INFO - 2018-08-08 00:56:40 --> Utf8 Class Initialized
INFO - 2018-08-08 00:56:40 --> URI Class Initialized
INFO - 2018-08-08 00:56:41 --> Router Class Initialized
INFO - 2018-08-08 00:56:41 --> Output Class Initialized
INFO - 2018-08-08 00:56:41 --> Security Class Initialized
DEBUG - 2018-08-08 00:56:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-08 00:56:41 --> Input Class Initialized
INFO - 2018-08-08 00:56:41 --> Language Class Initialized
INFO - 2018-08-08 00:56:41 --> Language Class Initialized
INFO - 2018-08-08 00:56:41 --> Config Class Initialized
INFO - 2018-08-08 00:56:41 --> Loader Class Initialized
DEBUG - 2018-08-08 00:56:41 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-08 00:56:41 --> Helper loaded: url_helper
INFO - 2018-08-08 00:56:41 --> Helper loaded: form_helper
INFO - 2018-08-08 00:56:41 --> Helper loaded: date_helper
INFO - 2018-08-08 00:56:41 --> Helper loaded: util_helper
INFO - 2018-08-08 00:56:41 --> Helper loaded: text_helper
INFO - 2018-08-08 00:56:41 --> Helper loaded: string_helper
INFO - 2018-08-08 00:56:41 --> Database Driver Class Initialized
DEBUG - 2018-08-08 00:56:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-08 00:56:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-08 00:56:41 --> Email Class Initialized
INFO - 2018-08-08 00:56:41 --> Controller Class Initialized
DEBUG - 2018-08-08 00:56:41 --> Settings MX_Controller Initialized
INFO - 2018-08-08 00:56:41 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-08 00:56:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-08 00:56:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Settings_model.php
DEBUG - 2018-08-08 00:56:41 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-08 00:56:41 --> Login MX_Controller Initialized
DEBUG - 2018-08-08 00:56:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-08 00:56:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-08-08 00:56:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-08-08 00:56:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-08-08 00:56:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-08-08 00:56:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-08-08 00:56:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/settings.php
INFO - 2018-08-08 00:56:41 --> Final output sent to browser
DEBUG - 2018-08-08 00:56:41 --> Total execution time: 0.4404
INFO - 2018-08-08 00:58:19 --> Config Class Initialized
INFO - 2018-08-08 00:58:19 --> Hooks Class Initialized
DEBUG - 2018-08-08 00:58:20 --> UTF-8 Support Enabled
INFO - 2018-08-08 00:58:20 --> Utf8 Class Initialized
INFO - 2018-08-08 00:58:20 --> URI Class Initialized
INFO - 2018-08-08 00:58:20 --> Router Class Initialized
INFO - 2018-08-08 00:58:20 --> Output Class Initialized
INFO - 2018-08-08 00:58:20 --> Security Class Initialized
DEBUG - 2018-08-08 00:58:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-08 00:58:20 --> Input Class Initialized
INFO - 2018-08-08 00:58:20 --> Language Class Initialized
INFO - 2018-08-08 00:58:20 --> Language Class Initialized
INFO - 2018-08-08 00:58:20 --> Config Class Initialized
INFO - 2018-08-08 00:58:20 --> Loader Class Initialized
DEBUG - 2018-08-08 00:58:20 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-08 00:58:20 --> Helper loaded: url_helper
INFO - 2018-08-08 00:58:20 --> Helper loaded: form_helper
INFO - 2018-08-08 00:58:20 --> Helper loaded: date_helper
INFO - 2018-08-08 00:58:20 --> Helper loaded: util_helper
INFO - 2018-08-08 00:58:20 --> Helper loaded: text_helper
INFO - 2018-08-08 00:58:20 --> Helper loaded: string_helper
INFO - 2018-08-08 00:58:20 --> Database Driver Class Initialized
DEBUG - 2018-08-08 00:58:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-08 00:58:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-08 00:58:20 --> Email Class Initialized
INFO - 2018-08-08 00:58:20 --> Controller Class Initialized
DEBUG - 2018-08-08 00:58:20 --> Settings MX_Controller Initialized
INFO - 2018-08-08 00:58:20 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-08 00:58:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-08 00:58:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Settings_model.php
DEBUG - 2018-08-08 00:58:20 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-08 00:58:20 --> Login MX_Controller Initialized
DEBUG - 2018-08-08 00:58:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-08 00:58:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-08-08 00:58:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-08-08 00:58:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-08-08 00:58:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-08-08 00:58:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-08-08 00:58:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/settings.php
INFO - 2018-08-08 00:58:20 --> Final output sent to browser
DEBUG - 2018-08-08 00:58:20 --> Total execution time: 0.4493
INFO - 2018-08-08 00:58:25 --> Config Class Initialized
INFO - 2018-08-08 00:58:25 --> Hooks Class Initialized
DEBUG - 2018-08-08 00:58:25 --> UTF-8 Support Enabled
INFO - 2018-08-08 00:58:25 --> Utf8 Class Initialized
INFO - 2018-08-08 00:58:25 --> URI Class Initialized
INFO - 2018-08-08 00:58:25 --> Router Class Initialized
INFO - 2018-08-08 00:58:25 --> Output Class Initialized
INFO - 2018-08-08 00:58:25 --> Security Class Initialized
DEBUG - 2018-08-08 00:58:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-08 00:58:25 --> Input Class Initialized
INFO - 2018-08-08 00:58:25 --> Language Class Initialized
INFO - 2018-08-08 00:58:25 --> Language Class Initialized
INFO - 2018-08-08 00:58:25 --> Config Class Initialized
INFO - 2018-08-08 00:58:25 --> Loader Class Initialized
DEBUG - 2018-08-08 00:58:25 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-08 00:58:25 --> Helper loaded: url_helper
INFO - 2018-08-08 00:58:25 --> Helper loaded: form_helper
INFO - 2018-08-08 00:58:25 --> Helper loaded: date_helper
INFO - 2018-08-08 00:58:25 --> Helper loaded: util_helper
INFO - 2018-08-08 00:58:25 --> Helper loaded: text_helper
INFO - 2018-08-08 00:58:25 --> Helper loaded: string_helper
INFO - 2018-08-08 00:58:25 --> Database Driver Class Initialized
DEBUG - 2018-08-08 00:58:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-08 00:58:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-08 00:58:25 --> Email Class Initialized
INFO - 2018-08-08 00:58:25 --> Controller Class Initialized
DEBUG - 2018-08-08 00:58:25 --> Settings MX_Controller Initialized
INFO - 2018-08-08 00:58:25 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-08 00:58:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-08 00:58:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Settings_model.php
DEBUG - 2018-08-08 00:58:25 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-08 00:58:25 --> Login MX_Controller Initialized
DEBUG - 2018-08-08 00:58:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-08 00:58:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
INFO - 2018-08-08 00:58:25 --> Upload Class Initialized
INFO - 2018-08-08 00:58:25 --> Language file loaded: language/english/upload_lang.php
DEBUG - 2018-08-08 00:58:25 --> The filetype you are attempting to upload is not allowed.
INFO - 2018-08-08 00:58:25 --> Config Class Initialized
INFO - 2018-08-08 00:58:25 --> Hooks Class Initialized
DEBUG - 2018-08-08 00:58:25 --> UTF-8 Support Enabled
INFO - 2018-08-08 00:58:25 --> Utf8 Class Initialized
INFO - 2018-08-08 00:58:25 --> URI Class Initialized
INFO - 2018-08-08 00:58:25 --> Router Class Initialized
INFO - 2018-08-08 00:58:25 --> Output Class Initialized
INFO - 2018-08-08 00:58:25 --> Security Class Initialized
DEBUG - 2018-08-08 00:58:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-08 00:58:25 --> Input Class Initialized
INFO - 2018-08-08 00:58:25 --> Language Class Initialized
INFO - 2018-08-08 00:58:25 --> Language Class Initialized
INFO - 2018-08-08 00:58:25 --> Config Class Initialized
INFO - 2018-08-08 00:58:25 --> Loader Class Initialized
DEBUG - 2018-08-08 00:58:25 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-08 00:58:25 --> Helper loaded: url_helper
INFO - 2018-08-08 00:58:25 --> Helper loaded: form_helper
INFO - 2018-08-08 00:58:25 --> Helper loaded: date_helper
INFO - 2018-08-08 00:58:25 --> Helper loaded: util_helper
INFO - 2018-08-08 00:58:25 --> Helper loaded: text_helper
INFO - 2018-08-08 00:58:25 --> Helper loaded: string_helper
INFO - 2018-08-08 00:58:25 --> Database Driver Class Initialized
DEBUG - 2018-08-08 00:58:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-08 00:58:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-08 00:58:25 --> Email Class Initialized
INFO - 2018-08-08 00:58:25 --> Controller Class Initialized
DEBUG - 2018-08-08 00:58:25 --> Settings MX_Controller Initialized
INFO - 2018-08-08 00:58:25 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-08 00:58:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-08 00:58:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Settings_model.php
DEBUG - 2018-08-08 00:58:25 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-08 00:58:25 --> Login MX_Controller Initialized
DEBUG - 2018-08-08 00:58:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-08 00:58:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-08-08 00:58:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-08-08 00:58:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-08-08 00:58:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-08-08 00:58:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-08-08 00:58:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/settings.php
INFO - 2018-08-08 00:58:26 --> Final output sent to browser
DEBUG - 2018-08-08 00:58:26 --> Total execution time: 0.4489
INFO - 2018-08-08 01:03:48 --> Config Class Initialized
INFO - 2018-08-08 01:03:48 --> Hooks Class Initialized
DEBUG - 2018-08-08 01:03:48 --> UTF-8 Support Enabled
INFO - 2018-08-08 01:03:48 --> Utf8 Class Initialized
INFO - 2018-08-08 01:03:48 --> URI Class Initialized
INFO - 2018-08-08 01:03:48 --> Router Class Initialized
INFO - 2018-08-08 01:03:48 --> Output Class Initialized
INFO - 2018-08-08 01:03:48 --> Security Class Initialized
DEBUG - 2018-08-08 01:03:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-08 01:03:48 --> Input Class Initialized
INFO - 2018-08-08 01:03:48 --> Language Class Initialized
INFO - 2018-08-08 01:03:48 --> Language Class Initialized
INFO - 2018-08-08 01:03:48 --> Config Class Initialized
INFO - 2018-08-08 01:03:48 --> Loader Class Initialized
DEBUG - 2018-08-08 01:03:48 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-08 01:03:48 --> Helper loaded: url_helper
INFO - 2018-08-08 01:03:48 --> Helper loaded: form_helper
INFO - 2018-08-08 01:03:48 --> Helper loaded: date_helper
INFO - 2018-08-08 01:03:48 --> Helper loaded: util_helper
INFO - 2018-08-08 01:03:48 --> Helper loaded: text_helper
INFO - 2018-08-08 01:03:48 --> Helper loaded: string_helper
INFO - 2018-08-08 01:03:48 --> Database Driver Class Initialized
DEBUG - 2018-08-08 01:03:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-08 01:03:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-08 01:03:48 --> Email Class Initialized
INFO - 2018-08-08 01:03:48 --> Controller Class Initialized
DEBUG - 2018-08-08 01:03:48 --> Programs MX_Controller Initialized
INFO - 2018-08-08 01:03:48 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-08 01:03:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-08-08 01:03:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-08 01:03:48 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-08 01:03:48 --> Login MX_Controller Initialized
DEBUG - 2018-08-08 01:03:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-08 01:03:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-08-08 01:03:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-08-08 01:03:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-08-08 01:03:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-08-08 01:03:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-08-08 01:03:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/programs/programs.php
INFO - 2018-08-08 01:03:48 --> Final output sent to browser
DEBUG - 2018-08-08 01:03:48 --> Total execution time: 0.5273
INFO - 2018-08-08 01:03:50 --> Config Class Initialized
INFO - 2018-08-08 01:03:50 --> Hooks Class Initialized
DEBUG - 2018-08-08 01:03:50 --> UTF-8 Support Enabled
INFO - 2018-08-08 01:03:50 --> Utf8 Class Initialized
INFO - 2018-08-08 01:03:50 --> URI Class Initialized
INFO - 2018-08-08 01:03:50 --> Router Class Initialized
INFO - 2018-08-08 01:03:50 --> Output Class Initialized
INFO - 2018-08-08 01:03:50 --> Security Class Initialized
DEBUG - 2018-08-08 01:03:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-08 01:03:50 --> Input Class Initialized
INFO - 2018-08-08 01:03:50 --> Language Class Initialized
INFO - 2018-08-08 01:03:50 --> Language Class Initialized
INFO - 2018-08-08 01:03:50 --> Config Class Initialized
INFO - 2018-08-08 01:03:50 --> Loader Class Initialized
DEBUG - 2018-08-08 01:03:50 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-08 01:03:50 --> Helper loaded: url_helper
INFO - 2018-08-08 01:03:50 --> Helper loaded: form_helper
INFO - 2018-08-08 01:03:50 --> Helper loaded: date_helper
INFO - 2018-08-08 01:03:50 --> Helper loaded: util_helper
INFO - 2018-08-08 01:03:50 --> Helper loaded: text_helper
INFO - 2018-08-08 01:03:50 --> Helper loaded: string_helper
INFO - 2018-08-08 01:03:50 --> Database Driver Class Initialized
DEBUG - 2018-08-08 01:03:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-08 01:03:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-08 01:03:50 --> Email Class Initialized
INFO - 2018-08-08 01:03:50 --> Controller Class Initialized
DEBUG - 2018-08-08 01:03:50 --> Programs MX_Controller Initialized
INFO - 2018-08-08 01:03:50 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-08 01:03:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-08-08 01:03:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-08 01:03:50 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-08 01:03:50 --> Login MX_Controller Initialized
DEBUG - 2018-08-08 01:03:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-08 01:03:50 --> Final output sent to browser
DEBUG - 2018-08-08 01:03:50 --> Total execution time: 0.7921
INFO - 2018-08-08 01:03:52 --> Config Class Initialized
INFO - 2018-08-08 01:03:52 --> Hooks Class Initialized
DEBUG - 2018-08-08 01:03:52 --> UTF-8 Support Enabled
INFO - 2018-08-08 01:03:52 --> Utf8 Class Initialized
INFO - 2018-08-08 01:03:52 --> URI Class Initialized
DEBUG - 2018-08-08 01:03:52 --> No URI present. Default controller set.
INFO - 2018-08-08 01:03:52 --> Router Class Initialized
INFO - 2018-08-08 01:03:52 --> Output Class Initialized
INFO - 2018-08-08 01:03:52 --> Security Class Initialized
DEBUG - 2018-08-08 01:03:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-08 01:03:52 --> Input Class Initialized
INFO - 2018-08-08 01:03:52 --> Language Class Initialized
INFO - 2018-08-08 01:03:52 --> Language Class Initialized
INFO - 2018-08-08 01:03:52 --> Config Class Initialized
INFO - 2018-08-08 01:03:52 --> Loader Class Initialized
DEBUG - 2018-08-08 01:03:52 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-08 01:03:52 --> Helper loaded: url_helper
INFO - 2018-08-08 01:03:52 --> Helper loaded: form_helper
INFO - 2018-08-08 01:03:52 --> Helper loaded: date_helper
INFO - 2018-08-08 01:03:52 --> Helper loaded: util_helper
INFO - 2018-08-08 01:03:52 --> Helper loaded: text_helper
INFO - 2018-08-08 01:03:52 --> Helper loaded: string_helper
INFO - 2018-08-08 01:03:52 --> Database Driver Class Initialized
DEBUG - 2018-08-08 01:03:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-08 01:03:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-08 01:03:52 --> Email Class Initialized
INFO - 2018-08-08 01:03:52 --> Controller Class Initialized
DEBUG - 2018-08-08 01:03:52 --> Home MX_Controller Initialized
DEBUG - 2018-08-08 01:03:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-08 01:03:53 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-08 01:03:53 --> Login MX_Controller Initialized
INFO - 2018-08-08 01:03:53 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-08 01:03:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-08 01:03:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-08 01:03:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Settings_model.php
DEBUG - 2018-08-08 01:03:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/login.php
INFO - 2018-08-08 01:03:56 --> Config Class Initialized
INFO - 2018-08-08 01:03:56 --> Hooks Class Initialized
DEBUG - 2018-08-08 01:03:56 --> UTF-8 Support Enabled
INFO - 2018-08-08 01:03:56 --> Utf8 Class Initialized
INFO - 2018-08-08 01:03:56 --> URI Class Initialized
INFO - 2018-08-08 01:03:56 --> Router Class Initialized
INFO - 2018-08-08 01:03:56 --> Output Class Initialized
INFO - 2018-08-08 01:03:56 --> Security Class Initialized
DEBUG - 2018-08-08 01:03:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-08 01:03:56 --> Input Class Initialized
INFO - 2018-08-08 01:03:56 --> Language Class Initialized
INFO - 2018-08-08 01:03:56 --> Language Class Initialized
INFO - 2018-08-08 01:03:56 --> Config Class Initialized
INFO - 2018-08-08 01:03:57 --> Loader Class Initialized
DEBUG - 2018-08-08 01:03:57 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-08 01:03:57 --> Helper loaded: url_helper
INFO - 2018-08-08 01:03:57 --> Helper loaded: form_helper
INFO - 2018-08-08 01:03:57 --> Helper loaded: date_helper
INFO - 2018-08-08 01:03:57 --> Helper loaded: util_helper
INFO - 2018-08-08 01:03:57 --> Helper loaded: text_helper
INFO - 2018-08-08 01:03:57 --> Helper loaded: string_helper
INFO - 2018-08-08 01:03:57 --> Database Driver Class Initialized
DEBUG - 2018-08-08 01:03:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-08 01:03:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-08 01:03:57 --> Email Class Initialized
INFO - 2018-08-08 01:03:57 --> Controller Class Initialized
DEBUG - 2018-08-08 01:03:57 --> Login MX_Controller Initialized
INFO - 2018-08-08 01:03:57 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-08 01:03:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-08 01:03:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-08 01:03:57 --> Email starts for colinUser fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-08-08 01:03:57 --> User session created for 4
INFO - 2018-08-08 01:03:57 --> Login status colinUser - success
INFO - 2018-08-08 01:03:57 --> Final output sent to browser
DEBUG - 2018-08-08 01:03:57 --> Total execution time: 0.5205
INFO - 2018-08-08 01:03:57 --> Config Class Initialized
INFO - 2018-08-08 01:03:57 --> Hooks Class Initialized
DEBUG - 2018-08-08 01:03:57 --> UTF-8 Support Enabled
INFO - 2018-08-08 01:03:57 --> Utf8 Class Initialized
INFO - 2018-08-08 01:03:57 --> URI Class Initialized
DEBUG - 2018-08-08 01:03:57 --> No URI present. Default controller set.
INFO - 2018-08-08 01:03:57 --> Router Class Initialized
INFO - 2018-08-08 01:03:57 --> Output Class Initialized
INFO - 2018-08-08 01:03:57 --> Security Class Initialized
DEBUG - 2018-08-08 01:03:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-08 01:03:57 --> Input Class Initialized
INFO - 2018-08-08 01:03:57 --> Language Class Initialized
INFO - 2018-08-08 01:03:57 --> Language Class Initialized
INFO - 2018-08-08 01:03:57 --> Config Class Initialized
INFO - 2018-08-08 01:03:57 --> Loader Class Initialized
DEBUG - 2018-08-08 01:03:57 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-08 01:03:57 --> Helper loaded: url_helper
INFO - 2018-08-08 01:03:57 --> Helper loaded: form_helper
INFO - 2018-08-08 01:03:57 --> Helper loaded: date_helper
INFO - 2018-08-08 01:03:57 --> Helper loaded: util_helper
INFO - 2018-08-08 01:03:57 --> Helper loaded: text_helper
INFO - 2018-08-08 01:03:57 --> Helper loaded: string_helper
INFO - 2018-08-08 01:03:57 --> Database Driver Class Initialized
DEBUG - 2018-08-08 01:03:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-08 01:03:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-08 01:03:57 --> Email Class Initialized
INFO - 2018-08-08 01:03:57 --> Controller Class Initialized
DEBUG - 2018-08-08 01:03:57 --> Home MX_Controller Initialized
DEBUG - 2018-08-08 01:03:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-08 01:03:57 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-08 01:03:57 --> Login MX_Controller Initialized
INFO - 2018-08-08 01:03:57 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-08 01:03:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-08 01:03:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-08 01:03:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-08-08 01:03:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-08-08 01:03:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-08-08 01:03:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-08-08 01:03:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-08-08 01:03:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-08-08 01:03:58 --> Final output sent to browser
DEBUG - 2018-08-08 01:03:58 --> Total execution time: 0.6496
INFO - 2018-08-08 01:03:58 --> Config Class Initialized
INFO - 2018-08-08 01:03:58 --> Hooks Class Initialized
DEBUG - 2018-08-08 01:03:58 --> UTF-8 Support Enabled
INFO - 2018-08-08 01:03:58 --> Utf8 Class Initialized
INFO - 2018-08-08 01:03:58 --> URI Class Initialized
INFO - 2018-08-08 01:03:58 --> Router Class Initialized
INFO - 2018-08-08 01:03:58 --> Config Class Initialized
INFO - 2018-08-08 01:03:58 --> Hooks Class Initialized
INFO - 2018-08-08 01:03:58 --> Output Class Initialized
INFO - 2018-08-08 01:03:58 --> Security Class Initialized
DEBUG - 2018-08-08 01:03:58 --> UTF-8 Support Enabled
INFO - 2018-08-08 01:03:58 --> Utf8 Class Initialized
DEBUG - 2018-08-08 01:03:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-08 01:03:58 --> Input Class Initialized
INFO - 2018-08-08 01:03:58 --> URI Class Initialized
INFO - 2018-08-08 01:03:58 --> Language Class Initialized
ERROR - 2018-08-08 01:03:58 --> 404 Page Not Found: /index
INFO - 2018-08-08 01:03:58 --> Router Class Initialized
INFO - 2018-08-08 01:03:58 --> Output Class Initialized
INFO - 2018-08-08 01:03:58 --> Config Class Initialized
INFO - 2018-08-08 01:03:59 --> Hooks Class Initialized
INFO - 2018-08-08 01:03:59 --> Security Class Initialized
DEBUG - 2018-08-08 01:03:59 --> UTF-8 Support Enabled
INFO - 2018-08-08 01:03:59 --> Utf8 Class Initialized
DEBUG - 2018-08-08 01:03:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-08 01:03:59 --> URI Class Initialized
INFO - 2018-08-08 01:03:59 --> Input Class Initialized
INFO - 2018-08-08 01:03:59 --> Language Class Initialized
INFO - 2018-08-08 01:03:59 --> Router Class Initialized
INFO - 2018-08-08 01:03:59 --> Output Class Initialized
INFO - 2018-08-08 01:03:59 --> Language Class Initialized
INFO - 2018-08-08 01:03:59 --> Security Class Initialized
DEBUG - 2018-08-08 01:03:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-08 01:03:59 --> Input Class Initialized
INFO - 2018-08-08 01:03:59 --> Config Class Initialized
INFO - 2018-08-08 01:03:59 --> Language Class Initialized
INFO - 2018-08-08 01:03:59 --> Loader Class Initialized
DEBUG - 2018-08-08 01:03:59 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
ERROR - 2018-08-08 01:03:59 --> 404 Page Not Found: /index
INFO - 2018-08-08 01:03:59 --> Helper loaded: url_helper
INFO - 2018-08-08 01:03:59 --> Helper loaded: form_helper
INFO - 2018-08-08 01:03:59 --> Config Class Initialized
INFO - 2018-08-08 01:03:59 --> Hooks Class Initialized
INFO - 2018-08-08 01:03:59 --> Helper loaded: date_helper
INFO - 2018-08-08 01:03:59 --> Helper loaded: util_helper
DEBUG - 2018-08-08 01:03:59 --> UTF-8 Support Enabled
INFO - 2018-08-08 01:03:59 --> Utf8 Class Initialized
INFO - 2018-08-08 01:03:59 --> Helper loaded: text_helper
INFO - 2018-08-08 01:03:59 --> Helper loaded: string_helper
INFO - 2018-08-08 01:03:59 --> URI Class Initialized
INFO - 2018-08-08 01:03:59 --> Router Class Initialized
INFO - 2018-08-08 01:03:59 --> Database Driver Class Initialized
INFO - 2018-08-08 01:03:59 --> Output Class Initialized
INFO - 2018-08-08 01:03:59 --> Security Class Initialized
DEBUG - 2018-08-08 01:03:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-08-08 01:03:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-08 01:03:59 --> Config Class Initialized
INFO - 2018-08-08 01:03:59 --> Hooks Class Initialized
INFO - 2018-08-08 01:03:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-08 01:03:59 --> Input Class Initialized
DEBUG - 2018-08-08 01:03:59 --> UTF-8 Support Enabled
INFO - 2018-08-08 01:03:59 --> Email Class Initialized
INFO - 2018-08-08 01:03:59 --> Language Class Initialized
INFO - 2018-08-08 01:03:59 --> Utf8 Class Initialized
INFO - 2018-08-08 01:03:59 --> Controller Class Initialized
ERROR - 2018-08-08 01:03:59 --> 404 Page Not Found: /index
DEBUG - 2018-08-08 01:03:59 --> Home MX_Controller Initialized
INFO - 2018-08-08 01:03:59 --> URI Class Initialized
DEBUG - 2018-08-08 01:03:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-08-08 01:03:59 --> Router Class Initialized
INFO - 2018-08-08 01:03:59 --> Output Class Initialized
INFO - 2018-08-08 01:03:59 --> Security Class Initialized
DEBUG - 2018-08-08 01:03:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-08 01:03:59 --> Input Class Initialized
INFO - 2018-08-08 01:03:59 --> Language Class Initialized
ERROR - 2018-08-08 01:03:59 --> 404 Page Not Found: /index
INFO - 2018-08-08 01:03:59 --> Config Class Initialized
INFO - 2018-08-08 01:03:59 --> Hooks Class Initialized
DEBUG - 2018-08-08 01:03:59 --> UTF-8 Support Enabled
INFO - 2018-08-08 01:03:59 --> Utf8 Class Initialized
INFO - 2018-08-08 01:04:00 --> URI Class Initialized
INFO - 2018-08-08 01:04:00 --> Router Class Initialized
INFO - 2018-08-08 01:04:00 --> Output Class Initialized
INFO - 2018-08-08 01:04:00 --> Security Class Initialized
DEBUG - 2018-08-08 01:04:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-08 01:04:00 --> Input Class Initialized
INFO - 2018-08-08 01:04:00 --> Language Class Initialized
ERROR - 2018-08-08 01:04:00 --> 404 Page Not Found: /index
INFO - 2018-08-08 01:04:00 --> Config Class Initialized
INFO - 2018-08-08 01:04:00 --> Hooks Class Initialized
DEBUG - 2018-08-08 01:04:00 --> UTF-8 Support Enabled
INFO - 2018-08-08 01:04:00 --> Utf8 Class Initialized
INFO - 2018-08-08 01:04:00 --> URI Class Initialized
INFO - 2018-08-08 01:04:00 --> Router Class Initialized
INFO - 2018-08-08 01:04:00 --> Output Class Initialized
INFO - 2018-08-08 01:04:00 --> Security Class Initialized
DEBUG - 2018-08-08 01:04:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-08 01:04:00 --> Input Class Initialized
INFO - 2018-08-08 01:04:00 --> Language Class Initialized
ERROR - 2018-08-08 01:04:00 --> 404 Page Not Found: /index
INFO - 2018-08-08 01:04:00 --> Config Class Initialized
INFO - 2018-08-08 01:04:00 --> Hooks Class Initialized
DEBUG - 2018-08-08 01:04:00 --> UTF-8 Support Enabled
INFO - 2018-08-08 01:04:00 --> Utf8 Class Initialized
INFO - 2018-08-08 01:04:00 --> URI Class Initialized
INFO - 2018-08-08 01:04:00 --> Router Class Initialized
INFO - 2018-08-08 01:04:00 --> Output Class Initialized
INFO - 2018-08-08 01:04:00 --> Security Class Initialized
DEBUG - 2018-08-08 01:04:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-08 01:04:00 --> Input Class Initialized
INFO - 2018-08-08 01:04:00 --> Language Class Initialized
ERROR - 2018-08-08 01:04:00 --> 404 Page Not Found: /index
INFO - 2018-08-08 01:04:03 --> Config Class Initialized
INFO - 2018-08-08 01:04:03 --> Hooks Class Initialized
DEBUG - 2018-08-08 01:04:03 --> UTF-8 Support Enabled
INFO - 2018-08-08 01:04:03 --> Utf8 Class Initialized
INFO - 2018-08-08 01:04:03 --> URI Class Initialized
INFO - 2018-08-08 01:04:03 --> Router Class Initialized
INFO - 2018-08-08 01:04:03 --> Output Class Initialized
INFO - 2018-08-08 01:04:03 --> Security Class Initialized
DEBUG - 2018-08-08 01:04:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-08 01:04:03 --> Input Class Initialized
INFO - 2018-08-08 01:04:03 --> Language Class Initialized
INFO - 2018-08-08 01:04:03 --> Language Class Initialized
INFO - 2018-08-08 01:04:03 --> Config Class Initialized
INFO - 2018-08-08 01:04:03 --> Loader Class Initialized
DEBUG - 2018-08-08 01:04:03 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-08 01:04:03 --> Helper loaded: url_helper
INFO - 2018-08-08 01:04:03 --> Helper loaded: form_helper
INFO - 2018-08-08 01:04:03 --> Helper loaded: date_helper
INFO - 2018-08-08 01:04:03 --> Helper loaded: util_helper
INFO - 2018-08-08 01:04:03 --> Helper loaded: text_helper
INFO - 2018-08-08 01:04:03 --> Helper loaded: string_helper
INFO - 2018-08-08 01:04:03 --> Database Driver Class Initialized
DEBUG - 2018-08-08 01:04:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-08 01:04:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-08 01:04:03 --> Email Class Initialized
INFO - 2018-08-08 01:04:03 --> Controller Class Initialized
DEBUG - 2018-08-08 01:04:03 --> Programs MX_Controller Initialized
INFO - 2018-08-08 01:04:03 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-08 01:04:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-08-08 01:04:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-08 01:04:03 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-08 01:04:03 --> Login MX_Controller Initialized
DEBUG - 2018-08-08 01:04:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-08 01:04:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-08-08 01:04:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-08-08 01:04:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-08-08 01:04:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-08-08 01:04:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-08-08 01:04:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/programs/create_program.php
INFO - 2018-08-08 01:04:03 --> Final output sent to browser
DEBUG - 2018-08-08 01:04:03 --> Total execution time: 0.6746
INFO - 2018-08-08 01:04:04 --> Config Class Initialized
INFO - 2018-08-08 01:04:04 --> Hooks Class Initialized
DEBUG - 2018-08-08 01:04:04 --> UTF-8 Support Enabled
INFO - 2018-08-08 01:04:04 --> Utf8 Class Initialized
INFO - 2018-08-08 01:04:05 --> URI Class Initialized
INFO - 2018-08-08 01:04:05 --> Router Class Initialized
INFO - 2018-08-08 01:04:05 --> Output Class Initialized
INFO - 2018-08-08 01:04:05 --> Security Class Initialized
DEBUG - 2018-08-08 01:04:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-08 01:04:05 --> Input Class Initialized
INFO - 2018-08-08 01:04:05 --> Language Class Initialized
ERROR - 2018-08-08 01:04:05 --> 404 Page Not Found: /index
INFO - 2018-08-08 01:04:09 --> Config Class Initialized
INFO - 2018-08-08 01:04:09 --> Hooks Class Initialized
DEBUG - 2018-08-08 01:04:09 --> UTF-8 Support Enabled
INFO - 2018-08-08 01:04:09 --> Utf8 Class Initialized
INFO - 2018-08-08 01:04:09 --> URI Class Initialized
INFO - 2018-08-08 01:04:09 --> Router Class Initialized
INFO - 2018-08-08 01:04:09 --> Output Class Initialized
INFO - 2018-08-08 01:04:09 --> Security Class Initialized
DEBUG - 2018-08-08 01:04:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-08 01:04:09 --> Input Class Initialized
INFO - 2018-08-08 01:04:09 --> Language Class Initialized
INFO - 2018-08-08 01:04:09 --> Language Class Initialized
INFO - 2018-08-08 01:04:09 --> Config Class Initialized
INFO - 2018-08-08 01:04:10 --> Loader Class Initialized
DEBUG - 2018-08-08 01:04:10 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-08 01:04:10 --> Helper loaded: url_helper
INFO - 2018-08-08 01:04:10 --> Helper loaded: form_helper
INFO - 2018-08-08 01:04:10 --> Helper loaded: date_helper
INFO - 2018-08-08 01:04:10 --> Helper loaded: util_helper
INFO - 2018-08-08 01:04:10 --> Helper loaded: text_helper
INFO - 2018-08-08 01:04:10 --> Helper loaded: string_helper
INFO - 2018-08-08 01:04:10 --> Database Driver Class Initialized
DEBUG - 2018-08-08 01:04:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-08 01:04:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-08 01:04:10 --> Email Class Initialized
INFO - 2018-08-08 01:04:10 --> Controller Class Initialized
DEBUG - 2018-08-08 01:04:10 --> Programs MX_Controller Initialized
INFO - 2018-08-08 01:04:10 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-08 01:04:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-08-08 01:04:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-08 01:04:10 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-08 01:04:10 --> Login MX_Controller Initialized
DEBUG - 2018-08-08 01:04:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-08 01:04:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
INFO - 2018-08-08 01:04:10 --> Upload Class Initialized
INFO - 2018-08-08 01:04:10 --> Language file loaded: language/english/upload_lang.php
DEBUG - 2018-08-08 01:04:10 --> The filetype you are attempting to upload is not allowed.
INFO - 2018-08-08 01:09:52 --> Config Class Initialized
INFO - 2018-08-08 01:09:52 --> Hooks Class Initialized
DEBUG - 2018-08-08 01:09:52 --> UTF-8 Support Enabled
INFO - 2018-08-08 01:09:52 --> Utf8 Class Initialized
INFO - 2018-08-08 01:09:52 --> URI Class Initialized
INFO - 2018-08-08 01:09:52 --> Router Class Initialized
INFO - 2018-08-08 01:09:52 --> Output Class Initialized
INFO - 2018-08-08 01:09:52 --> Security Class Initialized
DEBUG - 2018-08-08 01:09:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-08 01:09:52 --> Input Class Initialized
INFO - 2018-08-08 01:09:52 --> Language Class Initialized
INFO - 2018-08-08 01:09:52 --> Language Class Initialized
INFO - 2018-08-08 01:09:52 --> Config Class Initialized
INFO - 2018-08-08 01:09:52 --> Loader Class Initialized
DEBUG - 2018-08-08 01:09:52 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-08 01:09:53 --> Helper loaded: url_helper
INFO - 2018-08-08 01:09:53 --> Helper loaded: form_helper
INFO - 2018-08-08 01:09:53 --> Helper loaded: date_helper
INFO - 2018-08-08 01:09:53 --> Helper loaded: util_helper
INFO - 2018-08-08 01:09:53 --> Helper loaded: text_helper
INFO - 2018-08-08 01:09:53 --> Helper loaded: string_helper
INFO - 2018-08-08 01:09:53 --> Database Driver Class Initialized
DEBUG - 2018-08-08 01:09:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-08 01:09:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-08 01:09:53 --> Email Class Initialized
INFO - 2018-08-08 01:09:53 --> Controller Class Initialized
DEBUG - 2018-08-08 01:09:53 --> Programs MX_Controller Initialized
INFO - 2018-08-08 01:09:53 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-08 01:09:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-08-08 01:09:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-08 01:09:53 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-08 01:09:53 --> Login MX_Controller Initialized
DEBUG - 2018-08-08 01:09:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-08 01:09:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
INFO - 2018-08-08 01:09:53 --> Upload Class Initialized
INFO - 2018-08-08 01:09:53 --> Language file loaded: language/english/upload_lang.php
DEBUG - 2018-08-08 01:09:53 --> The filetype you are attempting to upload is not allowed.
INFO - 2018-08-08 01:09:58 --> Config Class Initialized
INFO - 2018-08-08 01:09:58 --> Hooks Class Initialized
DEBUG - 2018-08-08 01:09:58 --> UTF-8 Support Enabled
INFO - 2018-08-08 01:09:58 --> Utf8 Class Initialized
INFO - 2018-08-08 01:09:58 --> URI Class Initialized
INFO - 2018-08-08 01:09:58 --> Router Class Initialized
INFO - 2018-08-08 01:09:58 --> Output Class Initialized
INFO - 2018-08-08 01:09:58 --> Security Class Initialized
DEBUG - 2018-08-08 01:09:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-08 01:09:58 --> Input Class Initialized
INFO - 2018-08-08 01:09:58 --> Language Class Initialized
INFO - 2018-08-08 01:09:58 --> Language Class Initialized
INFO - 2018-08-08 01:09:58 --> Config Class Initialized
INFO - 2018-08-08 01:09:58 --> Loader Class Initialized
DEBUG - 2018-08-08 01:09:58 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-08 01:09:59 --> Helper loaded: url_helper
INFO - 2018-08-08 01:09:59 --> Helper loaded: form_helper
INFO - 2018-08-08 01:09:59 --> Helper loaded: date_helper
INFO - 2018-08-08 01:09:59 --> Helper loaded: util_helper
INFO - 2018-08-08 01:09:59 --> Helper loaded: text_helper
INFO - 2018-08-08 01:09:59 --> Helper loaded: string_helper
INFO - 2018-08-08 01:09:59 --> Database Driver Class Initialized
DEBUG - 2018-08-08 01:09:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-08 01:09:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-08 01:09:59 --> Email Class Initialized
INFO - 2018-08-08 01:09:59 --> Controller Class Initialized
DEBUG - 2018-08-08 01:09:59 --> Programs MX_Controller Initialized
INFO - 2018-08-08 01:09:59 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-08 01:09:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-08-08 01:09:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-08 01:09:59 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-08 01:09:59 --> Login MX_Controller Initialized
DEBUG - 2018-08-08 01:09:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-08 01:09:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
INFO - 2018-08-08 01:09:59 --> Upload Class Initialized
INFO - 2018-08-08 01:09:59 --> Language file loaded: language/english/upload_lang.php
DEBUG - 2018-08-08 01:09:59 --> The filetype you are attempting to upload is not allowed.
INFO - 2018-08-08 01:13:02 --> Config Class Initialized
INFO - 2018-08-08 01:13:02 --> Hooks Class Initialized
DEBUG - 2018-08-08 01:13:02 --> UTF-8 Support Enabled
INFO - 2018-08-08 01:13:02 --> Utf8 Class Initialized
INFO - 2018-08-08 01:13:02 --> URI Class Initialized
INFO - 2018-08-08 01:13:02 --> Router Class Initialized
INFO - 2018-08-08 01:13:02 --> Output Class Initialized
INFO - 2018-08-08 01:13:02 --> Security Class Initialized
DEBUG - 2018-08-08 01:13:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-08 01:13:02 --> Input Class Initialized
INFO - 2018-08-08 01:13:02 --> Language Class Initialized
INFO - 2018-08-08 01:13:02 --> Language Class Initialized
INFO - 2018-08-08 01:13:02 --> Config Class Initialized
INFO - 2018-08-08 01:13:03 --> Loader Class Initialized
DEBUG - 2018-08-08 01:13:03 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-08 01:13:03 --> Helper loaded: url_helper
INFO - 2018-08-08 01:13:03 --> Helper loaded: form_helper
INFO - 2018-08-08 01:13:03 --> Helper loaded: date_helper
INFO - 2018-08-08 01:13:03 --> Helper loaded: util_helper
INFO - 2018-08-08 01:13:03 --> Helper loaded: text_helper
INFO - 2018-08-08 01:13:03 --> Helper loaded: string_helper
INFO - 2018-08-08 01:13:03 --> Database Driver Class Initialized
DEBUG - 2018-08-08 01:13:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-08 01:13:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-08 01:13:03 --> Email Class Initialized
INFO - 2018-08-08 01:13:03 --> Controller Class Initialized
DEBUG - 2018-08-08 01:13:03 --> Programs MX_Controller Initialized
INFO - 2018-08-08 01:13:03 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-08 01:13:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-08-08 01:13:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-08 01:13:03 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-08 01:13:03 --> Login MX_Controller Initialized
DEBUG - 2018-08-08 01:13:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-08 01:13:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
INFO - 2018-08-08 01:13:03 --> Upload Class Initialized
INFO - 2018-08-08 01:13:03 --> Config Class Initialized
INFO - 2018-08-08 01:13:03 --> Hooks Class Initialized
DEBUG - 2018-08-08 01:13:03 --> UTF-8 Support Enabled
INFO - 2018-08-08 01:13:03 --> Utf8 Class Initialized
INFO - 2018-08-08 01:13:03 --> URI Class Initialized
INFO - 2018-08-08 01:13:03 --> Router Class Initialized
INFO - 2018-08-08 01:13:03 --> Output Class Initialized
INFO - 2018-08-08 01:13:03 --> Security Class Initialized
DEBUG - 2018-08-08 01:13:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-08 01:13:03 --> Input Class Initialized
INFO - 2018-08-08 01:13:03 --> Language Class Initialized
INFO - 2018-08-08 01:13:03 --> Language Class Initialized
INFO - 2018-08-08 01:13:03 --> Config Class Initialized
INFO - 2018-08-08 01:13:03 --> Loader Class Initialized
DEBUG - 2018-08-08 01:13:03 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-08 01:13:03 --> Helper loaded: url_helper
INFO - 2018-08-08 01:13:03 --> Helper loaded: form_helper
INFO - 2018-08-08 01:13:03 --> Helper loaded: date_helper
INFO - 2018-08-08 01:13:03 --> Helper loaded: util_helper
INFO - 2018-08-08 01:13:03 --> Helper loaded: text_helper
INFO - 2018-08-08 01:13:03 --> Helper loaded: string_helper
INFO - 2018-08-08 01:13:03 --> Database Driver Class Initialized
DEBUG - 2018-08-08 01:13:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-08 01:13:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-08 01:13:03 --> Email Class Initialized
INFO - 2018-08-08 01:13:03 --> Controller Class Initialized
DEBUG - 2018-08-08 01:13:03 --> Programs MX_Controller Initialized
INFO - 2018-08-08 01:13:03 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-08 01:13:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-08-08 01:13:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-08 01:13:03 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-08 01:13:04 --> Login MX_Controller Initialized
DEBUG - 2018-08-08 01:13:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-08 01:13:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-08-08 01:13:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-08-08 01:13:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-08-08 01:13:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-08-08 01:13:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-08-08 01:13:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/programs/programs.php
INFO - 2018-08-08 01:13:04 --> Final output sent to browser
DEBUG - 2018-08-08 01:13:04 --> Total execution time: 0.6926
INFO - 2018-08-08 01:13:05 --> Config Class Initialized
INFO - 2018-08-08 01:13:05 --> Hooks Class Initialized
DEBUG - 2018-08-08 01:13:05 --> UTF-8 Support Enabled
INFO - 2018-08-08 01:13:05 --> Utf8 Class Initialized
INFO - 2018-08-08 01:13:05 --> URI Class Initialized
INFO - 2018-08-08 01:13:05 --> Router Class Initialized
INFO - 2018-08-08 01:13:05 --> Output Class Initialized
INFO - 2018-08-08 01:13:05 --> Security Class Initialized
DEBUG - 2018-08-08 01:13:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-08 01:13:05 --> Input Class Initialized
INFO - 2018-08-08 01:13:05 --> Language Class Initialized
INFO - 2018-08-08 01:13:05 --> Language Class Initialized
INFO - 2018-08-08 01:13:05 --> Config Class Initialized
INFO - 2018-08-08 01:13:05 --> Loader Class Initialized
DEBUG - 2018-08-08 01:13:05 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-08 01:13:05 --> Helper loaded: url_helper
INFO - 2018-08-08 01:13:05 --> Helper loaded: form_helper
INFO - 2018-08-08 01:13:05 --> Helper loaded: date_helper
INFO - 2018-08-08 01:13:05 --> Helper loaded: util_helper
INFO - 2018-08-08 01:13:05 --> Helper loaded: text_helper
INFO - 2018-08-08 01:13:05 --> Helper loaded: string_helper
INFO - 2018-08-08 01:13:05 --> Database Driver Class Initialized
DEBUG - 2018-08-08 01:13:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-08 01:13:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-08 01:13:06 --> Email Class Initialized
INFO - 2018-08-08 01:13:06 --> Controller Class Initialized
DEBUG - 2018-08-08 01:13:06 --> Programs MX_Controller Initialized
INFO - 2018-08-08 01:13:06 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-08 01:13:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-08-08 01:13:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-08 01:13:06 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-08 01:13:06 --> Login MX_Controller Initialized
DEBUG - 2018-08-08 01:13:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-08 01:13:06 --> Final output sent to browser
DEBUG - 2018-08-08 01:13:06 --> Total execution time: 0.7338
INFO - 2018-08-08 01:13:08 --> Config Class Initialized
INFO - 2018-08-08 01:13:08 --> Hooks Class Initialized
DEBUG - 2018-08-08 01:13:08 --> UTF-8 Support Enabled
INFO - 2018-08-08 01:13:08 --> Utf8 Class Initialized
INFO - 2018-08-08 01:13:08 --> URI Class Initialized
DEBUG - 2018-08-08 01:13:08 --> No URI present. Default controller set.
INFO - 2018-08-08 01:13:08 --> Router Class Initialized
INFO - 2018-08-08 01:13:08 --> Output Class Initialized
INFO - 2018-08-08 01:13:08 --> Security Class Initialized
DEBUG - 2018-08-08 01:13:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-08 01:13:09 --> Input Class Initialized
INFO - 2018-08-08 01:13:09 --> Language Class Initialized
INFO - 2018-08-08 01:13:09 --> Language Class Initialized
INFO - 2018-08-08 01:13:09 --> Config Class Initialized
INFO - 2018-08-08 01:13:09 --> Loader Class Initialized
DEBUG - 2018-08-08 01:13:09 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-08 01:13:09 --> Helper loaded: url_helper
INFO - 2018-08-08 01:13:09 --> Helper loaded: form_helper
INFO - 2018-08-08 01:13:09 --> Helper loaded: date_helper
INFO - 2018-08-08 01:13:09 --> Helper loaded: util_helper
INFO - 2018-08-08 01:13:09 --> Helper loaded: text_helper
INFO - 2018-08-08 01:13:09 --> Helper loaded: string_helper
INFO - 2018-08-08 01:13:09 --> Database Driver Class Initialized
DEBUG - 2018-08-08 01:13:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-08 01:13:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-08 01:13:09 --> Email Class Initialized
INFO - 2018-08-08 01:13:09 --> Controller Class Initialized
DEBUG - 2018-08-08 01:13:09 --> Home MX_Controller Initialized
DEBUG - 2018-08-08 01:13:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-08 01:13:09 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-08 01:13:09 --> Login MX_Controller Initialized
INFO - 2018-08-08 01:13:09 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-08 01:13:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-08 01:13:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-08 01:13:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-08-08 01:13:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-08-08 01:13:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-08-08 01:13:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-08-08 01:13:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-08-08 01:13:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-08-08 01:13:09 --> Final output sent to browser
DEBUG - 2018-08-08 01:13:09 --> Total execution time: 0.5210
INFO - 2018-08-08 01:13:09 --> Config Class Initialized
INFO - 2018-08-08 01:13:09 --> Hooks Class Initialized
DEBUG - 2018-08-08 01:13:09 --> UTF-8 Support Enabled
INFO - 2018-08-08 01:13:10 --> Utf8 Class Initialized
INFO - 2018-08-08 01:13:10 --> URI Class Initialized
INFO - 2018-08-08 01:13:10 --> Config Class Initialized
INFO - 2018-08-08 01:13:10 --> Hooks Class Initialized
INFO - 2018-08-08 01:13:10 --> Router Class Initialized
DEBUG - 2018-08-08 01:13:10 --> UTF-8 Support Enabled
INFO - 2018-08-08 01:13:10 --> Output Class Initialized
INFO - 2018-08-08 01:13:10 --> Utf8 Class Initialized
INFO - 2018-08-08 01:13:10 --> URI Class Initialized
INFO - 2018-08-08 01:13:10 --> Router Class Initialized
INFO - 2018-08-08 01:13:10 --> Output Class Initialized
INFO - 2018-08-08 01:13:10 --> Security Class Initialized
DEBUG - 2018-08-08 01:13:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-08 01:13:10 --> Input Class Initialized
INFO - 2018-08-08 01:13:10 --> Language Class Initialized
INFO - 2018-08-08 01:13:10 --> Language Class Initialized
INFO - 2018-08-08 01:13:10 --> Security Class Initialized
INFO - 2018-08-08 01:13:10 --> Config Class Initialized
DEBUG - 2018-08-08 01:13:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-08 01:13:10 --> Input Class Initialized
INFO - 2018-08-08 01:13:10 --> Loader Class Initialized
DEBUG - 2018-08-08 01:13:10 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-08 01:13:10 --> Language Class Initialized
INFO - 2018-08-08 01:13:10 --> Helper loaded: url_helper
INFO - 2018-08-08 01:13:10 --> Helper loaded: form_helper
ERROR - 2018-08-08 01:13:10 --> 404 Page Not Found: /index
INFO - 2018-08-08 01:13:10 --> Helper loaded: date_helper
INFO - 2018-08-08 01:13:10 --> Helper loaded: util_helper
INFO - 2018-08-08 01:13:10 --> Config Class Initialized
INFO - 2018-08-08 01:13:10 --> Hooks Class Initialized
INFO - 2018-08-08 01:13:10 --> Helper loaded: text_helper
INFO - 2018-08-08 01:13:10 --> Helper loaded: string_helper
DEBUG - 2018-08-08 01:13:10 --> UTF-8 Support Enabled
INFO - 2018-08-08 01:13:10 --> Utf8 Class Initialized
INFO - 2018-08-08 01:13:10 --> Database Driver Class Initialized
INFO - 2018-08-08 01:13:10 --> URI Class Initialized
DEBUG - 2018-08-08 01:13:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-08 01:13:10 --> Router Class Initialized
INFO - 2018-08-08 01:13:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-08 01:13:10 --> Output Class Initialized
INFO - 2018-08-08 01:13:10 --> Security Class Initialized
DEBUG - 2018-08-08 01:13:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-08 01:13:10 --> Email Class Initialized
INFO - 2018-08-08 01:13:10 --> Input Class Initialized
INFO - 2018-08-08 01:13:10 --> Controller Class Initialized
INFO - 2018-08-08 01:13:10 --> Language Class Initialized
DEBUG - 2018-08-08 01:13:10 --> Home MX_Controller Initialized
ERROR - 2018-08-08 01:13:10 --> 404 Page Not Found: /index
DEBUG - 2018-08-08 01:13:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-08-08 01:13:10 --> Config Class Initialized
INFO - 2018-08-08 01:13:10 --> Hooks Class Initialized
DEBUG - 2018-08-08 01:13:10 --> UTF-8 Support Enabled
INFO - 2018-08-08 01:13:10 --> Utf8 Class Initialized
INFO - 2018-08-08 01:13:10 --> URI Class Initialized
INFO - 2018-08-08 01:13:10 --> Router Class Initialized
INFO - 2018-08-08 01:13:10 --> Output Class Initialized
INFO - 2018-08-08 01:13:10 --> Security Class Initialized
DEBUG - 2018-08-08 01:13:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-08 01:13:10 --> Input Class Initialized
INFO - 2018-08-08 01:13:10 --> Language Class Initialized
ERROR - 2018-08-08 01:13:10 --> 404 Page Not Found: /index
INFO - 2018-08-08 05:56:45 --> Config Class Initialized
INFO - 2018-08-08 05:56:45 --> Hooks Class Initialized
DEBUG - 2018-08-08 05:56:45 --> UTF-8 Support Enabled
INFO - 2018-08-08 05:56:45 --> Utf8 Class Initialized
INFO - 2018-08-08 05:56:45 --> URI Class Initialized
INFO - 2018-08-08 05:56:45 --> Router Class Initialized
INFO - 2018-08-08 05:56:45 --> Output Class Initialized
INFO - 2018-08-08 05:56:45 --> Security Class Initialized
DEBUG - 2018-08-08 05:56:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-08 05:56:45 --> Input Class Initialized
INFO - 2018-08-08 05:56:45 --> Language Class Initialized
INFO - 2018-08-08 05:56:45 --> Language Class Initialized
INFO - 2018-08-08 05:56:45 --> Config Class Initialized
INFO - 2018-08-08 05:56:46 --> Loader Class Initialized
DEBUG - 2018-08-08 05:56:46 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-08 05:56:46 --> Helper loaded: url_helper
INFO - 2018-08-08 05:56:46 --> Helper loaded: form_helper
INFO - 2018-08-08 05:56:46 --> Helper loaded: date_helper
INFO - 2018-08-08 05:56:46 --> Helper loaded: util_helper
INFO - 2018-08-08 05:56:46 --> Helper loaded: text_helper
INFO - 2018-08-08 05:56:46 --> Helper loaded: string_helper
INFO - 2018-08-08 05:56:46 --> Database Driver Class Initialized
DEBUG - 2018-08-08 05:56:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-08 05:56:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-08 05:56:46 --> Email Class Initialized
INFO - 2018-08-08 05:56:46 --> Controller Class Initialized
DEBUG - 2018-08-08 05:56:46 --> Home MX_Controller Initialized
DEBUG - 2018-08-08 05:56:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-08 05:56:46 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-08 05:56:46 --> Login MX_Controller Initialized
INFO - 2018-08-08 05:56:46 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-08 05:56:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-08 05:56:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-08 05:56:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Settings_model.php
DEBUG - 2018-08-08 05:56:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/login.php
INFO - 2018-08-08 05:56:55 --> Config Class Initialized
INFO - 2018-08-08 05:56:56 --> Hooks Class Initialized
DEBUG - 2018-08-08 05:56:56 --> UTF-8 Support Enabled
INFO - 2018-08-08 05:56:56 --> Utf8 Class Initialized
INFO - 2018-08-08 05:56:56 --> URI Class Initialized
INFO - 2018-08-08 05:56:56 --> Router Class Initialized
INFO - 2018-08-08 05:56:56 --> Output Class Initialized
INFO - 2018-08-08 05:56:56 --> Security Class Initialized
DEBUG - 2018-08-08 05:56:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-08 05:56:56 --> Input Class Initialized
INFO - 2018-08-08 05:56:56 --> Language Class Initialized
INFO - 2018-08-08 05:56:56 --> Language Class Initialized
INFO - 2018-08-08 05:56:56 --> Config Class Initialized
INFO - 2018-08-08 05:56:56 --> Loader Class Initialized
DEBUG - 2018-08-08 05:56:56 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-08 05:56:56 --> Helper loaded: url_helper
INFO - 2018-08-08 05:56:56 --> Helper loaded: form_helper
INFO - 2018-08-08 05:56:56 --> Helper loaded: date_helper
INFO - 2018-08-08 05:56:56 --> Helper loaded: util_helper
INFO - 2018-08-08 05:56:56 --> Helper loaded: text_helper
INFO - 2018-08-08 05:56:56 --> Helper loaded: string_helper
INFO - 2018-08-08 05:56:56 --> Database Driver Class Initialized
DEBUG - 2018-08-08 05:56:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-08 05:56:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-08 05:56:56 --> Email Class Initialized
INFO - 2018-08-08 05:56:56 --> Controller Class Initialized
DEBUG - 2018-08-08 05:56:56 --> Login MX_Controller Initialized
INFO - 2018-08-08 05:56:56 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-08 05:56:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-08 05:56:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-08 05:56:56 --> Email starts for gopipanguluri123@gmail.com fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-08-08 05:56:56 --> Login status gopipanguluri123@gmail.com - failure
INFO - 2018-08-08 05:56:56 --> Final output sent to browser
DEBUG - 2018-08-08 05:56:56 --> Total execution time: 0.5165
INFO - 2018-08-08 05:57:12 --> Config Class Initialized
INFO - 2018-08-08 05:57:12 --> Hooks Class Initialized
DEBUG - 2018-08-08 05:57:12 --> UTF-8 Support Enabled
INFO - 2018-08-08 05:57:12 --> Utf8 Class Initialized
INFO - 2018-08-08 05:57:12 --> URI Class Initialized
INFO - 2018-08-08 05:57:12 --> Router Class Initialized
INFO - 2018-08-08 05:57:12 --> Output Class Initialized
INFO - 2018-08-08 05:57:12 --> Security Class Initialized
DEBUG - 2018-08-08 05:57:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-08 05:57:12 --> Input Class Initialized
INFO - 2018-08-08 05:57:12 --> Language Class Initialized
INFO - 2018-08-08 05:57:12 --> Language Class Initialized
INFO - 2018-08-08 05:57:12 --> Config Class Initialized
INFO - 2018-08-08 05:57:12 --> Loader Class Initialized
DEBUG - 2018-08-08 05:57:12 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-08 05:57:12 --> Helper loaded: url_helper
INFO - 2018-08-08 05:57:12 --> Helper loaded: form_helper
INFO - 2018-08-08 05:57:12 --> Helper loaded: date_helper
INFO - 2018-08-08 05:57:12 --> Helper loaded: util_helper
INFO - 2018-08-08 05:57:12 --> Helper loaded: text_helper
INFO - 2018-08-08 05:57:12 --> Helper loaded: string_helper
INFO - 2018-08-08 05:57:12 --> Database Driver Class Initialized
DEBUG - 2018-08-08 05:57:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-08 05:57:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-08 05:57:12 --> Email Class Initialized
INFO - 2018-08-08 05:57:12 --> Controller Class Initialized
DEBUG - 2018-08-08 05:57:13 --> Login MX_Controller Initialized
INFO - 2018-08-08 05:57:13 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-08 05:57:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-08 05:57:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-08 05:57:13 --> Email starts for gopipanguluri123@gmail.com fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-08-08 05:57:13 --> Login status gopipanguluri123@gmail.com - failure
INFO - 2018-08-08 05:57:13 --> Final output sent to browser
DEBUG - 2018-08-08 05:57:13 --> Total execution time: 0.4461
INFO - 2018-08-08 06:01:46 --> Config Class Initialized
INFO - 2018-08-08 06:01:46 --> Hooks Class Initialized
DEBUG - 2018-08-08 06:01:46 --> UTF-8 Support Enabled
INFO - 2018-08-08 06:01:46 --> Utf8 Class Initialized
INFO - 2018-08-08 06:01:46 --> URI Class Initialized
INFO - 2018-08-08 06:01:46 --> Router Class Initialized
INFO - 2018-08-08 06:01:46 --> Output Class Initialized
INFO - 2018-08-08 06:01:46 --> Security Class Initialized
DEBUG - 2018-08-08 06:01:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-08 06:01:46 --> Input Class Initialized
INFO - 2018-08-08 06:01:46 --> Language Class Initialized
INFO - 2018-08-08 06:01:46 --> Language Class Initialized
INFO - 2018-08-08 06:01:46 --> Config Class Initialized
INFO - 2018-08-08 06:01:46 --> Loader Class Initialized
DEBUG - 2018-08-08 06:01:46 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-08 06:01:46 --> Helper loaded: url_helper
INFO - 2018-08-08 06:01:46 --> Helper loaded: form_helper
INFO - 2018-08-08 06:01:46 --> Helper loaded: date_helper
INFO - 2018-08-08 06:01:46 --> Helper loaded: util_helper
INFO - 2018-08-08 06:01:46 --> Helper loaded: text_helper
INFO - 2018-08-08 06:01:46 --> Helper loaded: string_helper
INFO - 2018-08-08 06:01:46 --> Database Driver Class Initialized
DEBUG - 2018-08-08 06:01:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-08 06:01:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-08 06:01:46 --> Email Class Initialized
INFO - 2018-08-08 06:01:46 --> Controller Class Initialized
DEBUG - 2018-08-08 06:01:46 --> Login MX_Controller Initialized
INFO - 2018-08-08 06:01:46 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-08 06:01:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-08 06:01:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-08 06:01:46 --> Email starts for colinUser fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-08-08 06:01:46 --> User session created for 4
INFO - 2018-08-08 06:01:46 --> Login status colinUser - success
INFO - 2018-08-08 06:01:46 --> Final output sent to browser
DEBUG - 2018-08-08 06:01:46 --> Total execution time: 0.4982
INFO - 2018-08-08 06:01:46 --> Config Class Initialized
INFO - 2018-08-08 06:01:46 --> Hooks Class Initialized
DEBUG - 2018-08-08 06:01:46 --> UTF-8 Support Enabled
INFO - 2018-08-08 06:01:46 --> Utf8 Class Initialized
INFO - 2018-08-08 06:01:47 --> URI Class Initialized
INFO - 2018-08-08 06:01:47 --> Router Class Initialized
INFO - 2018-08-08 06:01:47 --> Output Class Initialized
INFO - 2018-08-08 06:01:47 --> Security Class Initialized
DEBUG - 2018-08-08 06:01:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-08 06:01:47 --> Input Class Initialized
INFO - 2018-08-08 06:01:47 --> Language Class Initialized
INFO - 2018-08-08 06:01:47 --> Language Class Initialized
INFO - 2018-08-08 06:01:47 --> Config Class Initialized
INFO - 2018-08-08 06:01:47 --> Loader Class Initialized
DEBUG - 2018-08-08 06:01:47 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-08 06:01:47 --> Helper loaded: url_helper
INFO - 2018-08-08 06:01:47 --> Helper loaded: form_helper
INFO - 2018-08-08 06:01:47 --> Helper loaded: date_helper
INFO - 2018-08-08 06:01:47 --> Helper loaded: util_helper
INFO - 2018-08-08 06:01:47 --> Helper loaded: text_helper
INFO - 2018-08-08 06:01:47 --> Helper loaded: string_helper
INFO - 2018-08-08 06:01:47 --> Database Driver Class Initialized
DEBUG - 2018-08-08 06:01:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-08 06:01:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-08 06:01:47 --> Email Class Initialized
INFO - 2018-08-08 06:01:47 --> Controller Class Initialized
DEBUG - 2018-08-08 06:01:47 --> Home MX_Controller Initialized
DEBUG - 2018-08-08 06:01:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-08 06:01:47 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-08 06:01:47 --> Login MX_Controller Initialized
INFO - 2018-08-08 06:01:47 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-08 06:01:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-08 06:01:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-08 06:01:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-08-08 06:01:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-08-08 06:01:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-08-08 06:01:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-08-08 06:01:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-08-08 06:01:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-08-08 06:01:47 --> Final output sent to browser
DEBUG - 2018-08-08 06:01:48 --> Total execution time: 1.0367
INFO - 2018-08-08 06:01:48 --> Config Class Initialized
INFO - 2018-08-08 06:01:48 --> Hooks Class Initialized
DEBUG - 2018-08-08 06:01:48 --> UTF-8 Support Enabled
INFO - 2018-08-08 06:01:48 --> Utf8 Class Initialized
INFO - 2018-08-08 06:01:48 --> Config Class Initialized
INFO - 2018-08-08 06:01:48 --> Hooks Class Initialized
INFO - 2018-08-08 06:01:48 --> URI Class Initialized
DEBUG - 2018-08-08 06:01:48 --> UTF-8 Support Enabled
INFO - 2018-08-08 06:01:48 --> Utf8 Class Initialized
INFO - 2018-08-08 06:01:48 --> URI Class Initialized
INFO - 2018-08-08 06:01:48 --> Router Class Initialized
INFO - 2018-08-08 06:01:48 --> Output Class Initialized
INFO - 2018-08-08 06:01:48 --> Router Class Initialized
INFO - 2018-08-08 06:01:48 --> Security Class Initialized
INFO - 2018-08-08 06:01:48 --> Output Class Initialized
INFO - 2018-08-08 06:01:48 --> Security Class Initialized
DEBUG - 2018-08-08 06:01:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-08 06:01:48 --> Input Class Initialized
DEBUG - 2018-08-08 06:01:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-08 06:01:48 --> Language Class Initialized
INFO - 2018-08-08 06:01:48 --> Language Class Initialized
INFO - 2018-08-08 06:01:49 --> Config Class Initialized
INFO - 2018-08-08 06:01:49 --> Input Class Initialized
INFO - 2018-08-08 06:01:49 --> Loader Class Initialized
DEBUG - 2018-08-08 06:01:49 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-08 06:01:49 --> Language Class Initialized
INFO - 2018-08-08 06:01:49 --> Helper loaded: url_helper
INFO - 2018-08-08 06:01:49 --> Helper loaded: form_helper
ERROR - 2018-08-08 06:01:49 --> 404 Page Not Found: /index
INFO - 2018-08-08 06:01:49 --> Helper loaded: date_helper
INFO - 2018-08-08 06:01:49 --> Helper loaded: util_helper
INFO - 2018-08-08 06:01:49 --> Config Class Initialized
INFO - 2018-08-08 06:01:49 --> Hooks Class Initialized
INFO - 2018-08-08 06:01:49 --> Helper loaded: text_helper
DEBUG - 2018-08-08 06:01:49 --> UTF-8 Support Enabled
INFO - 2018-08-08 06:01:49 --> Utf8 Class Initialized
INFO - 2018-08-08 06:01:49 --> URI Class Initialized
INFO - 2018-08-08 06:01:49 --> Router Class Initialized
INFO - 2018-08-08 06:01:49 --> Output Class Initialized
INFO - 2018-08-08 06:01:49 --> Helper loaded: string_helper
INFO - 2018-08-08 06:01:49 --> Security Class Initialized
DEBUG - 2018-08-08 06:01:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-08 06:01:49 --> Database Driver Class Initialized
INFO - 2018-08-08 06:01:49 --> Input Class Initialized
INFO - 2018-08-08 06:01:49 --> Language Class Initialized
ERROR - 2018-08-08 06:01:49 --> 404 Page Not Found: /index
INFO - 2018-08-08 06:01:49 --> Config Class Initialized
DEBUG - 2018-08-08 06:01:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-08 06:01:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-08 06:01:49 --> Hooks Class Initialized
DEBUG - 2018-08-08 06:01:49 --> UTF-8 Support Enabled
INFO - 2018-08-08 06:01:49 --> Email Class Initialized
INFO - 2018-08-08 06:01:49 --> Config Class Initialized
INFO - 2018-08-08 06:01:49 --> Utf8 Class Initialized
INFO - 2018-08-08 06:01:49 --> Controller Class Initialized
INFO - 2018-08-08 06:01:49 --> Hooks Class Initialized
DEBUG - 2018-08-08 06:01:49 --> Home MX_Controller Initialized
INFO - 2018-08-08 06:01:49 --> URI Class Initialized
DEBUG - 2018-08-08 06:01:49 --> UTF-8 Support Enabled
DEBUG - 2018-08-08 06:01:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-08-08 06:01:49 --> Router Class Initialized
INFO - 2018-08-08 06:01:49 --> Utf8 Class Initialized
INFO - 2018-08-08 06:01:49 --> Output Class Initialized
INFO - 2018-08-08 06:01:49 --> URI Class Initialized
INFO - 2018-08-08 06:01:49 --> Security Class Initialized
DEBUG - 2018-08-08 06:01:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-08 06:01:49 --> Router Class Initialized
INFO - 2018-08-08 06:01:49 --> Input Class Initialized
INFO - 2018-08-08 06:01:49 --> Language Class Initialized
INFO - 2018-08-08 06:01:49 --> Output Class Initialized
ERROR - 2018-08-08 06:01:49 --> 404 Page Not Found: /index
INFO - 2018-08-08 06:01:49 --> Security Class Initialized
DEBUG - 2018-08-08 06:01:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-08 06:01:49 --> Config Class Initialized
INFO - 2018-08-08 06:01:49 --> Hooks Class Initialized
INFO - 2018-08-08 06:01:49 --> Input Class Initialized
INFO - 2018-08-08 06:01:49 --> Language Class Initialized
DEBUG - 2018-08-08 06:01:49 --> UTF-8 Support Enabled
INFO - 2018-08-08 06:01:49 --> Utf8 Class Initialized
ERROR - 2018-08-08 06:01:49 --> 404 Page Not Found: /index
INFO - 2018-08-08 06:01:49 --> URI Class Initialized
INFO - 2018-08-08 06:01:49 --> Router Class Initialized
INFO - 2018-08-08 06:01:50 --> Output Class Initialized
INFO - 2018-08-08 06:01:50 --> Security Class Initialized
DEBUG - 2018-08-08 06:01:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-08 06:01:50 --> Input Class Initialized
INFO - 2018-08-08 06:01:50 --> Language Class Initialized
ERROR - 2018-08-08 06:01:50 --> 404 Page Not Found: /index
INFO - 2018-08-08 06:01:50 --> Config Class Initialized
INFO - 2018-08-08 06:01:50 --> Hooks Class Initialized
DEBUG - 2018-08-08 06:01:50 --> UTF-8 Support Enabled
INFO - 2018-08-08 06:01:50 --> Utf8 Class Initialized
INFO - 2018-08-08 06:01:50 --> URI Class Initialized
INFO - 2018-08-08 06:01:50 --> Router Class Initialized
INFO - 2018-08-08 06:01:50 --> Output Class Initialized
INFO - 2018-08-08 06:01:50 --> Security Class Initialized
DEBUG - 2018-08-08 06:01:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-08 06:01:50 --> Input Class Initialized
INFO - 2018-08-08 06:01:50 --> Language Class Initialized
ERROR - 2018-08-08 06:01:50 --> 404 Page Not Found: /index
INFO - 2018-08-08 06:01:50 --> Config Class Initialized
INFO - 2018-08-08 06:01:50 --> Hooks Class Initialized
DEBUG - 2018-08-08 06:01:50 --> UTF-8 Support Enabled
INFO - 2018-08-08 06:01:50 --> Utf8 Class Initialized
INFO - 2018-08-08 06:01:50 --> URI Class Initialized
INFO - 2018-08-08 06:01:50 --> Router Class Initialized
INFO - 2018-08-08 06:01:50 --> Output Class Initialized
INFO - 2018-08-08 06:01:50 --> Security Class Initialized
DEBUG - 2018-08-08 06:01:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-08 06:01:50 --> Input Class Initialized
INFO - 2018-08-08 06:01:50 --> Language Class Initialized
ERROR - 2018-08-08 06:01:50 --> 404 Page Not Found: /index
INFO - 2018-08-08 06:02:03 --> Config Class Initialized
INFO - 2018-08-08 06:02:03 --> Hooks Class Initialized
DEBUG - 2018-08-08 06:02:03 --> UTF-8 Support Enabled
INFO - 2018-08-08 06:02:03 --> Utf8 Class Initialized
INFO - 2018-08-08 06:02:03 --> URI Class Initialized
INFO - 2018-08-08 06:02:03 --> Router Class Initialized
INFO - 2018-08-08 06:02:03 --> Output Class Initialized
INFO - 2018-08-08 06:02:03 --> Security Class Initialized
DEBUG - 2018-08-08 06:02:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-08 06:02:03 --> Input Class Initialized
INFO - 2018-08-08 06:02:03 --> Language Class Initialized
INFO - 2018-08-08 06:02:03 --> Language Class Initialized
INFO - 2018-08-08 06:02:03 --> Config Class Initialized
INFO - 2018-08-08 06:02:03 --> Loader Class Initialized
DEBUG - 2018-08-08 06:02:03 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-08 06:02:03 --> Helper loaded: url_helper
INFO - 2018-08-08 06:02:03 --> Helper loaded: form_helper
INFO - 2018-08-08 06:02:03 --> Helper loaded: date_helper
INFO - 2018-08-08 06:02:03 --> Helper loaded: util_helper
INFO - 2018-08-08 06:02:03 --> Helper loaded: text_helper
INFO - 2018-08-08 06:02:03 --> Helper loaded: string_helper
INFO - 2018-08-08 06:02:04 --> Database Driver Class Initialized
DEBUG - 2018-08-08 06:02:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-08 06:02:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-08 06:02:04 --> Email Class Initialized
INFO - 2018-08-08 06:02:04 --> Controller Class Initialized
DEBUG - 2018-08-08 06:02:04 --> Login MX_Controller Initialized
INFO - 2018-08-08 06:02:04 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-08 06:02:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-08 06:02:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-08 06:02:04 --> 4 Loggedout
INFO - 2018-08-08 06:02:04 --> Config Class Initialized
INFO - 2018-08-08 06:02:04 --> Hooks Class Initialized
DEBUG - 2018-08-08 06:02:04 --> UTF-8 Support Enabled
INFO - 2018-08-08 06:02:04 --> Utf8 Class Initialized
INFO - 2018-08-08 06:02:04 --> URI Class Initialized
INFO - 2018-08-08 06:02:04 --> Router Class Initialized
INFO - 2018-08-08 06:02:04 --> Output Class Initialized
INFO - 2018-08-08 06:02:04 --> Security Class Initialized
DEBUG - 2018-08-08 06:02:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-08 06:02:04 --> Input Class Initialized
INFO - 2018-08-08 06:02:04 --> Language Class Initialized
INFO - 2018-08-08 06:02:04 --> Language Class Initialized
INFO - 2018-08-08 06:02:04 --> Config Class Initialized
INFO - 2018-08-08 06:02:04 --> Loader Class Initialized
DEBUG - 2018-08-08 06:02:04 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-08 06:02:04 --> Helper loaded: url_helper
INFO - 2018-08-08 06:02:04 --> Helper loaded: form_helper
INFO - 2018-08-08 06:02:04 --> Helper loaded: date_helper
INFO - 2018-08-08 06:02:04 --> Helper loaded: util_helper
INFO - 2018-08-08 06:02:04 --> Helper loaded: text_helper
INFO - 2018-08-08 06:02:04 --> Helper loaded: string_helper
INFO - 2018-08-08 06:02:04 --> Database Driver Class Initialized
DEBUG - 2018-08-08 06:02:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-08 06:02:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-08 06:02:04 --> Email Class Initialized
INFO - 2018-08-08 06:02:04 --> Controller Class Initialized
DEBUG - 2018-08-08 06:02:04 --> Home MX_Controller Initialized
DEBUG - 2018-08-08 06:02:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-08 06:02:04 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-08 06:02:04 --> Login MX_Controller Initialized
INFO - 2018-08-08 06:02:04 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-08 06:02:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-08 06:02:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-08 06:02:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Settings_model.php
DEBUG - 2018-08-08 06:02:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/login.php
INFO - 2018-08-08 20:17:31 --> Config Class Initialized
INFO - 2018-08-08 20:17:31 --> Hooks Class Initialized
DEBUG - 2018-08-08 20:17:31 --> UTF-8 Support Enabled
INFO - 2018-08-08 20:17:31 --> Utf8 Class Initialized
INFO - 2018-08-08 20:17:32 --> URI Class Initialized
INFO - 2018-08-08 20:17:32 --> Router Class Initialized
INFO - 2018-08-08 20:17:32 --> Output Class Initialized
INFO - 2018-08-08 20:17:32 --> Security Class Initialized
DEBUG - 2018-08-08 20:17:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-08 20:17:32 --> Input Class Initialized
INFO - 2018-08-08 20:17:32 --> Language Class Initialized
INFO - 2018-08-08 20:17:32 --> Language Class Initialized
INFO - 2018-08-08 20:17:32 --> Config Class Initialized
INFO - 2018-08-08 20:17:32 --> Config Class Initialized
INFO - 2018-08-08 20:17:32 --> Hooks Class Initialized
DEBUG - 2018-08-08 20:17:32 --> UTF-8 Support Enabled
INFO - 2018-08-08 20:17:32 --> Utf8 Class Initialized
INFO - 2018-08-08 20:17:32 --> URI Class Initialized
INFO - 2018-08-08 20:17:32 --> Loader Class Initialized
INFO - 2018-08-08 20:17:32 --> Router Class Initialized
INFO - 2018-08-08 20:17:32 --> Output Class Initialized
INFO - 2018-08-08 20:17:32 --> Security Class Initialized
DEBUG - 2018-08-08 20:17:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-08 20:17:33 --> Input Class Initialized
INFO - 2018-08-08 20:17:33 --> Language Class Initialized
DEBUG - 2018-08-08 20:17:33 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-08 20:17:33 --> Language Class Initialized
INFO - 2018-08-08 20:17:33 --> Config Class Initialized
INFO - 2018-08-08 20:17:33 --> Loader Class Initialized
DEBUG - 2018-08-08 20:17:33 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-08 20:17:33 --> Helper loaded: url_helper
INFO - 2018-08-08 20:17:33 --> Helper loaded: url_helper
INFO - 2018-08-08 20:17:33 --> Helper loaded: form_helper
INFO - 2018-08-08 20:17:33 --> Helper loaded: form_helper
INFO - 2018-08-08 20:17:33 --> Helper loaded: date_helper
INFO - 2018-08-08 20:17:33 --> Helper loaded: date_helper
INFO - 2018-08-08 20:17:33 --> Helper loaded: util_helper
INFO - 2018-08-08 20:17:33 --> Helper loaded: util_helper
INFO - 2018-08-08 20:17:33 --> Helper loaded: text_helper
INFO - 2018-08-08 20:17:33 --> Helper loaded: text_helper
INFO - 2018-08-08 20:17:33 --> Helper loaded: string_helper
INFO - 2018-08-08 20:17:33 --> Helper loaded: string_helper
INFO - 2018-08-08 20:17:33 --> Database Driver Class Initialized
INFO - 2018-08-08 20:17:33 --> Database Driver Class Initialized
DEBUG - 2018-08-08 20:17:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-08-08 20:17:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-08 20:17:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-08 20:17:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-08 20:17:34 --> Email Class Initialized
INFO - 2018-08-08 20:17:34 --> Email Class Initialized
INFO - 2018-08-08 20:17:34 --> Controller Class Initialized
INFO - 2018-08-08 20:17:34 --> Controller Class Initialized
DEBUG - 2018-08-08 20:17:34 --> Home MX_Controller Initialized
DEBUG - 2018-08-08 20:17:34 --> Programs MX_Controller Initialized
INFO - 2018-08-08 20:17:34 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-08 20:17:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-08 20:17:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-08-08 20:17:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-08 20:17:34 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-08 20:17:34 --> Login MX_Controller Initialized
DEBUG - 2018-08-08 20:17:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-08 20:17:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/logins/login.php
DEBUG - 2018-08-08 20:17:34 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-08 20:17:34 --> Login MX_Controller Initialized
INFO - 2018-08-08 20:17:34 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-08 20:17:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-08 20:17:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-08 20:17:34 --> Config Class Initialized
INFO - 2018-08-08 20:17:34 --> Hooks Class Initialized
DEBUG - 2018-08-08 20:17:35 --> UTF-8 Support Enabled
INFO - 2018-08-08 20:17:35 --> Utf8 Class Initialized
INFO - 2018-08-08 20:17:35 --> URI Class Initialized
INFO - 2018-08-08 20:17:35 --> Router Class Initialized
INFO - 2018-08-08 20:17:35 --> Output Class Initialized
INFO - 2018-08-08 20:17:35 --> Security Class Initialized
DEBUG - 2018-08-08 20:17:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-08 20:17:35 --> Input Class Initialized
INFO - 2018-08-08 20:17:35 --> Language Class Initialized
DEBUG - 2018-08-08 20:17:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Settings_model.php
ERROR - 2018-08-08 20:17:35 --> 404 Page Not Found: /index
DEBUG - 2018-08-08 20:17:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/login.php
INFO - 2018-08-08 20:17:37 --> Config Class Initialized
INFO - 2018-08-08 20:17:37 --> Hooks Class Initialized
DEBUG - 2018-08-08 20:17:37 --> UTF-8 Support Enabled
INFO - 2018-08-08 20:17:37 --> Utf8 Class Initialized
INFO - 2018-08-08 20:17:37 --> URI Class Initialized
INFO - 2018-08-08 20:17:37 --> Router Class Initialized
INFO - 2018-08-08 20:17:37 --> Output Class Initialized
INFO - 2018-08-08 20:17:37 --> Security Class Initialized
DEBUG - 2018-08-08 20:17:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-08 20:17:37 --> Input Class Initialized
INFO - 2018-08-08 20:17:37 --> Language Class Initialized
ERROR - 2018-08-08 20:17:37 --> 404 Page Not Found: /index
INFO - 2018-08-08 20:25:13 --> Config Class Initialized
INFO - 2018-08-08 20:25:13 --> Hooks Class Initialized
DEBUG - 2018-08-08 20:25:13 --> UTF-8 Support Enabled
INFO - 2018-08-08 20:25:13 --> Utf8 Class Initialized
INFO - 2018-08-08 20:25:13 --> URI Class Initialized
INFO - 2018-08-08 20:25:13 --> Router Class Initialized
INFO - 2018-08-08 20:25:13 --> Output Class Initialized
INFO - 2018-08-08 20:25:13 --> Security Class Initialized
DEBUG - 2018-08-08 20:25:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-08 20:25:13 --> Input Class Initialized
INFO - 2018-08-08 20:25:13 --> Language Class Initialized
INFO - 2018-08-08 20:25:13 --> Language Class Initialized
INFO - 2018-08-08 20:25:13 --> Config Class Initialized
INFO - 2018-08-08 20:25:13 --> Loader Class Initialized
DEBUG - 2018-08-08 20:25:13 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-08 20:25:13 --> Helper loaded: url_helper
INFO - 2018-08-08 20:25:13 --> Helper loaded: form_helper
INFO - 2018-08-08 20:25:13 --> Helper loaded: date_helper
INFO - 2018-08-08 20:25:13 --> Helper loaded: util_helper
INFO - 2018-08-08 20:25:13 --> Helper loaded: text_helper
INFO - 2018-08-08 20:25:13 --> Helper loaded: string_helper
INFO - 2018-08-08 20:25:14 --> Database Driver Class Initialized
DEBUG - 2018-08-08 20:25:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-08 20:25:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-08 20:25:14 --> Email Class Initialized
INFO - 2018-08-08 20:25:14 --> Controller Class Initialized
DEBUG - 2018-08-08 20:25:14 --> Login MX_Controller Initialized
INFO - 2018-08-08 20:25:14 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-08 20:25:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-08 20:25:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-08 20:25:14 --> Email starts for colinUser fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-08-08 20:25:14 --> User session created for 4
INFO - 2018-08-08 20:25:14 --> Login status colinUser - success
INFO - 2018-08-08 20:25:14 --> Final output sent to browser
DEBUG - 2018-08-08 20:25:14 --> Total execution time: 1.2377
INFO - 2018-08-08 20:25:14 --> Config Class Initialized
INFO - 2018-08-08 20:25:14 --> Hooks Class Initialized
DEBUG - 2018-08-08 20:25:14 --> UTF-8 Support Enabled
INFO - 2018-08-08 20:25:14 --> Utf8 Class Initialized
INFO - 2018-08-08 20:25:14 --> URI Class Initialized
INFO - 2018-08-08 20:25:14 --> Router Class Initialized
INFO - 2018-08-08 20:25:14 --> Output Class Initialized
INFO - 2018-08-08 20:25:14 --> Security Class Initialized
DEBUG - 2018-08-08 20:25:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-08 20:25:14 --> Input Class Initialized
INFO - 2018-08-08 20:25:14 --> Language Class Initialized
INFO - 2018-08-08 20:25:14 --> Language Class Initialized
INFO - 2018-08-08 20:25:14 --> Config Class Initialized
INFO - 2018-08-08 20:25:14 --> Loader Class Initialized
DEBUG - 2018-08-08 20:25:14 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-08 20:25:14 --> Helper loaded: url_helper
INFO - 2018-08-08 20:25:14 --> Helper loaded: form_helper
INFO - 2018-08-08 20:25:14 --> Helper loaded: date_helper
INFO - 2018-08-08 20:25:14 --> Helper loaded: util_helper
INFO - 2018-08-08 20:25:14 --> Helper loaded: text_helper
INFO - 2018-08-08 20:25:14 --> Helper loaded: string_helper
INFO - 2018-08-08 20:25:14 --> Database Driver Class Initialized
DEBUG - 2018-08-08 20:25:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-08 20:25:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-08 20:25:14 --> Email Class Initialized
INFO - 2018-08-08 20:25:14 --> Controller Class Initialized
DEBUG - 2018-08-08 20:25:14 --> Home MX_Controller Initialized
DEBUG - 2018-08-08 20:25:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-08 20:25:14 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-08 20:25:14 --> Login MX_Controller Initialized
INFO - 2018-08-08 20:25:14 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-08 20:25:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-08 20:25:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-08 20:25:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-08-08 20:25:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-08-08 20:25:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-08-08 20:25:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-08-08 20:25:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-08-08 20:25:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-08-08 20:25:15 --> Final output sent to browser
DEBUG - 2018-08-08 20:25:15 --> Total execution time: 0.9132
INFO - 2018-08-08 20:25:17 --> Config Class Initialized
INFO - 2018-08-08 20:25:17 --> Hooks Class Initialized
DEBUG - 2018-08-08 20:25:17 --> UTF-8 Support Enabled
INFO - 2018-08-08 20:25:17 --> Utf8 Class Initialized
INFO - 2018-08-08 20:25:17 --> URI Class Initialized
INFO - 2018-08-08 20:25:17 --> Router Class Initialized
INFO - 2018-08-08 20:25:17 --> Output Class Initialized
INFO - 2018-08-08 20:25:17 --> Security Class Initialized
DEBUG - 2018-08-08 20:25:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-08 20:25:17 --> Input Class Initialized
INFO - 2018-08-08 20:25:17 --> Language Class Initialized
ERROR - 2018-08-08 20:25:17 --> 404 Page Not Found: /index
INFO - 2018-08-08 20:25:17 --> Config Class Initialized
INFO - 2018-08-08 20:25:17 --> Hooks Class Initialized
DEBUG - 2018-08-08 20:25:17 --> UTF-8 Support Enabled
INFO - 2018-08-08 20:25:17 --> Utf8 Class Initialized
INFO - 2018-08-08 20:25:17 --> URI Class Initialized
INFO - 2018-08-08 20:25:17 --> Router Class Initialized
INFO - 2018-08-08 20:25:17 --> Config Class Initialized
INFO - 2018-08-08 20:25:17 --> Hooks Class Initialized
INFO - 2018-08-08 20:25:17 --> Output Class Initialized
INFO - 2018-08-08 20:25:17 --> Security Class Initialized
DEBUG - 2018-08-08 20:25:17 --> UTF-8 Support Enabled
INFO - 2018-08-08 20:25:17 --> Utf8 Class Initialized
DEBUG - 2018-08-08 20:25:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-08 20:25:17 --> URI Class Initialized
INFO - 2018-08-08 20:25:17 --> Input Class Initialized
INFO - 2018-08-08 20:25:17 --> Router Class Initialized
INFO - 2018-08-08 20:25:18 --> Language Class Initialized
INFO - 2018-08-08 20:25:18 --> Output Class Initialized
INFO - 2018-08-08 20:25:18 --> Security Class Initialized
INFO - 2018-08-08 20:25:18 --> Language Class Initialized
DEBUG - 2018-08-08 20:25:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-08 20:25:18 --> Input Class Initialized
INFO - 2018-08-08 20:25:18 --> Config Class Initialized
INFO - 2018-08-08 20:25:18 --> Language Class Initialized
INFO - 2018-08-08 20:25:18 --> Loader Class Initialized
DEBUG - 2018-08-08 20:25:18 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-08 20:25:18 --> Helper loaded: url_helper
INFO - 2018-08-08 20:25:18 --> Helper loaded: form_helper
INFO - 2018-08-08 20:25:18 --> Helper loaded: date_helper
INFO - 2018-08-08 20:25:18 --> Helper loaded: util_helper
INFO - 2018-08-08 20:25:18 --> Helper loaded: text_helper
INFO - 2018-08-08 20:25:18 --> Helper loaded: string_helper
INFO - 2018-08-08 20:25:18 --> Database Driver Class Initialized
ERROR - 2018-08-08 20:25:18 --> 404 Page Not Found: /index
DEBUG - 2018-08-08 20:25:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-08 20:25:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-08 20:25:18 --> Email Class Initialized
INFO - 2018-08-08 20:25:18 --> Controller Class Initialized
DEBUG - 2018-08-08 20:25:18 --> Home MX_Controller Initialized
DEBUG - 2018-08-08 20:25:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-08-08 20:25:18 --> Config Class Initialized
INFO - 2018-08-08 20:25:18 --> Hooks Class Initialized
DEBUG - 2018-08-08 20:25:18 --> UTF-8 Support Enabled
INFO - 2018-08-08 20:25:18 --> Utf8 Class Initialized
INFO - 2018-08-08 20:25:18 --> URI Class Initialized
INFO - 2018-08-08 20:25:18 --> Router Class Initialized
INFO - 2018-08-08 20:25:18 --> Config Class Initialized
INFO - 2018-08-08 20:25:18 --> Hooks Class Initialized
INFO - 2018-08-08 20:25:18 --> Output Class Initialized
INFO - 2018-08-08 20:25:18 --> Security Class Initialized
DEBUG - 2018-08-08 20:25:18 --> UTF-8 Support Enabled
INFO - 2018-08-08 20:25:18 --> Utf8 Class Initialized
DEBUG - 2018-08-08 20:25:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-08 20:25:18 --> Input Class Initialized
INFO - 2018-08-08 20:25:18 --> URI Class Initialized
INFO - 2018-08-08 20:25:18 --> Language Class Initialized
INFO - 2018-08-08 20:25:18 --> Router Class Initialized
ERROR - 2018-08-08 20:25:18 --> 404 Page Not Found: /index
INFO - 2018-08-08 20:25:18 --> Output Class Initialized
INFO - 2018-08-08 20:25:18 --> Security Class Initialized
DEBUG - 2018-08-08 20:25:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-08 20:25:18 --> Input Class Initialized
INFO - 2018-08-08 20:25:18 --> Language Class Initialized
ERROR - 2018-08-08 20:25:18 --> 404 Page Not Found: /index
INFO - 2018-08-08 20:25:18 --> Config Class Initialized
INFO - 2018-08-08 20:25:18 --> Hooks Class Initialized
DEBUG - 2018-08-08 20:25:18 --> UTF-8 Support Enabled
INFO - 2018-08-08 20:25:18 --> Utf8 Class Initialized
INFO - 2018-08-08 20:25:18 --> URI Class Initialized
INFO - 2018-08-08 20:25:18 --> Router Class Initialized
INFO - 2018-08-08 20:25:18 --> Output Class Initialized
INFO - 2018-08-08 20:25:18 --> Security Class Initialized
DEBUG - 2018-08-08 20:25:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-08 20:25:18 --> Input Class Initialized
INFO - 2018-08-08 20:25:18 --> Language Class Initialized
ERROR - 2018-08-08 20:25:18 --> 404 Page Not Found: /index
INFO - 2018-08-08 20:25:18 --> Config Class Initialized
INFO - 2018-08-08 20:25:18 --> Hooks Class Initialized
DEBUG - 2018-08-08 20:25:19 --> UTF-8 Support Enabled
INFO - 2018-08-08 20:25:19 --> Utf8 Class Initialized
INFO - 2018-08-08 20:25:19 --> URI Class Initialized
INFO - 2018-08-08 20:25:19 --> Router Class Initialized
INFO - 2018-08-08 20:25:19 --> Output Class Initialized
INFO - 2018-08-08 20:25:19 --> Security Class Initialized
DEBUG - 2018-08-08 20:25:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-08 20:25:19 --> Input Class Initialized
INFO - 2018-08-08 20:25:19 --> Language Class Initialized
ERROR - 2018-08-08 20:25:19 --> 404 Page Not Found: /index
INFO - 2018-08-08 20:25:19 --> Config Class Initialized
INFO - 2018-08-08 20:25:19 --> Hooks Class Initialized
DEBUG - 2018-08-08 20:25:19 --> UTF-8 Support Enabled
INFO - 2018-08-08 20:25:19 --> Utf8 Class Initialized
INFO - 2018-08-08 20:25:19 --> URI Class Initialized
INFO - 2018-08-08 20:25:19 --> Router Class Initialized
INFO - 2018-08-08 20:25:19 --> Output Class Initialized
INFO - 2018-08-08 20:25:19 --> Security Class Initialized
DEBUG - 2018-08-08 20:25:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-08 20:25:19 --> Input Class Initialized
INFO - 2018-08-08 20:25:19 --> Language Class Initialized
ERROR - 2018-08-08 20:25:19 --> 404 Page Not Found: /index
INFO - 2018-08-08 20:25:19 --> Config Class Initialized
INFO - 2018-08-08 20:25:19 --> Hooks Class Initialized
DEBUG - 2018-08-08 20:25:19 --> UTF-8 Support Enabled
INFO - 2018-08-08 20:25:19 --> Utf8 Class Initialized
INFO - 2018-08-08 20:25:19 --> URI Class Initialized
INFO - 2018-08-08 20:25:19 --> Router Class Initialized
INFO - 2018-08-08 20:25:19 --> Output Class Initialized
INFO - 2018-08-08 20:25:19 --> Security Class Initialized
DEBUG - 2018-08-08 20:25:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-08 20:25:19 --> Input Class Initialized
INFO - 2018-08-08 20:25:19 --> Language Class Initialized
ERROR - 2018-08-08 20:25:19 --> 404 Page Not Found: /index
INFO - 2018-08-08 20:25:19 --> Config Class Initialized
INFO - 2018-08-08 20:25:19 --> Hooks Class Initialized
DEBUG - 2018-08-08 20:25:19 --> UTF-8 Support Enabled
INFO - 2018-08-08 20:25:19 --> Utf8 Class Initialized
INFO - 2018-08-08 20:25:19 --> URI Class Initialized
INFO - 2018-08-08 20:25:19 --> Router Class Initialized
INFO - 2018-08-08 20:25:19 --> Output Class Initialized
INFO - 2018-08-08 20:25:19 --> Security Class Initialized
DEBUG - 2018-08-08 20:25:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-08 20:25:19 --> Input Class Initialized
INFO - 2018-08-08 20:25:19 --> Language Class Initialized
ERROR - 2018-08-08 20:25:19 --> 404 Page Not Found: /index
INFO - 2018-08-08 20:25:19 --> Config Class Initialized
INFO - 2018-08-08 20:25:19 --> Hooks Class Initialized
DEBUG - 2018-08-08 20:25:19 --> UTF-8 Support Enabled
INFO - 2018-08-08 20:25:19 --> Utf8 Class Initialized
INFO - 2018-08-08 20:25:19 --> URI Class Initialized
INFO - 2018-08-08 20:25:19 --> Router Class Initialized
INFO - 2018-08-08 20:25:19 --> Output Class Initialized
INFO - 2018-08-08 20:25:19 --> Security Class Initialized
DEBUG - 2018-08-08 20:25:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-08 20:25:19 --> Input Class Initialized
INFO - 2018-08-08 20:25:19 --> Language Class Initialized
ERROR - 2018-08-08 20:25:19 --> 404 Page Not Found: /index
INFO - 2018-08-08 20:25:20 --> Config Class Initialized
INFO - 2018-08-08 20:25:20 --> Hooks Class Initialized
DEBUG - 2018-08-08 20:25:20 --> UTF-8 Support Enabled
INFO - 2018-08-08 20:25:20 --> Utf8 Class Initialized
INFO - 2018-08-08 20:25:20 --> URI Class Initialized
INFO - 2018-08-08 20:25:20 --> Router Class Initialized
INFO - 2018-08-08 20:25:20 --> Output Class Initialized
INFO - 2018-08-08 20:25:20 --> Security Class Initialized
DEBUG - 2018-08-08 20:25:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-08 20:25:20 --> Input Class Initialized
INFO - 2018-08-08 20:25:20 --> Language Class Initialized
INFO - 2018-08-08 20:25:20 --> Language Class Initialized
INFO - 2018-08-08 20:25:20 --> Config Class Initialized
INFO - 2018-08-08 20:25:20 --> Loader Class Initialized
DEBUG - 2018-08-08 20:25:20 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-08 20:25:20 --> Helper loaded: url_helper
INFO - 2018-08-08 20:25:20 --> Helper loaded: form_helper
INFO - 2018-08-08 20:25:20 --> Helper loaded: date_helper
INFO - 2018-08-08 20:25:20 --> Helper loaded: util_helper
INFO - 2018-08-08 20:25:20 --> Helper loaded: text_helper
INFO - 2018-08-08 20:25:20 --> Helper loaded: string_helper
INFO - 2018-08-08 20:25:20 --> Database Driver Class Initialized
DEBUG - 2018-08-08 20:25:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-08 20:25:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-08 20:25:20 --> Email Class Initialized
INFO - 2018-08-08 20:25:20 --> Controller Class Initialized
DEBUG - 2018-08-08 20:25:20 --> Login MX_Controller Initialized
INFO - 2018-08-08 20:25:20 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-08 20:25:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-08 20:25:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-08 20:25:20 --> Email starts for colin-admin fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-08-08 20:25:20 --> User session created for 1
INFO - 2018-08-08 20:25:20 --> Login status colin-admin - success
INFO - 2018-08-08 20:25:20 --> Final output sent to browser
DEBUG - 2018-08-08 20:25:20 --> Total execution time: 0.4406
INFO - 2018-08-08 20:25:20 --> Config Class Initialized
INFO - 2018-08-08 20:25:20 --> Hooks Class Initialized
DEBUG - 2018-08-08 20:25:20 --> UTF-8 Support Enabled
INFO - 2018-08-08 20:25:20 --> Utf8 Class Initialized
INFO - 2018-08-08 20:25:20 --> URI Class Initialized
INFO - 2018-08-08 20:25:20 --> Router Class Initialized
INFO - 2018-08-08 20:25:20 --> Output Class Initialized
INFO - 2018-08-08 20:25:20 --> Security Class Initialized
DEBUG - 2018-08-08 20:25:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-08 20:25:20 --> Input Class Initialized
INFO - 2018-08-08 20:25:20 --> Language Class Initialized
INFO - 2018-08-08 20:25:20 --> Language Class Initialized
INFO - 2018-08-08 20:25:20 --> Config Class Initialized
INFO - 2018-08-08 20:25:20 --> Loader Class Initialized
DEBUG - 2018-08-08 20:25:21 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-08 20:25:21 --> Helper loaded: url_helper
INFO - 2018-08-08 20:25:21 --> Helper loaded: form_helper
INFO - 2018-08-08 20:25:21 --> Helper loaded: date_helper
INFO - 2018-08-08 20:25:21 --> Helper loaded: util_helper
INFO - 2018-08-08 20:25:21 --> Helper loaded: text_helper
INFO - 2018-08-08 20:25:21 --> Helper loaded: string_helper
INFO - 2018-08-08 20:25:21 --> Database Driver Class Initialized
DEBUG - 2018-08-08 20:25:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-08 20:25:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-08 20:25:21 --> Email Class Initialized
INFO - 2018-08-08 20:25:21 --> Controller Class Initialized
DEBUG - 2018-08-08 20:25:21 --> Programs MX_Controller Initialized
INFO - 2018-08-08 20:25:21 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-08 20:25:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-08-08 20:25:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-08 20:25:21 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-08 20:25:21 --> Login MX_Controller Initialized
DEBUG - 2018-08-08 20:25:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-08 20:25:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-08-08 20:25:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-08-08 20:25:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-08-08 20:25:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-08-08 20:25:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-08-08 20:25:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/programs/programs.php
INFO - 2018-08-08 20:25:21 --> Final output sent to browser
DEBUG - 2018-08-08 20:25:21 --> Total execution time: 0.7016
INFO - 2018-08-08 20:25:22 --> Config Class Initialized
INFO - 2018-08-08 20:25:22 --> Hooks Class Initialized
DEBUG - 2018-08-08 20:25:22 --> UTF-8 Support Enabled
INFO - 2018-08-08 20:25:22 --> Utf8 Class Initialized
INFO - 2018-08-08 20:25:22 --> URI Class Initialized
INFO - 2018-08-08 20:25:22 --> Router Class Initialized
INFO - 2018-08-08 20:25:22 --> Output Class Initialized
INFO - 2018-08-08 20:25:22 --> Security Class Initialized
DEBUG - 2018-08-08 20:25:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-08 20:25:22 --> Input Class Initialized
INFO - 2018-08-08 20:25:22 --> Language Class Initialized
INFO - 2018-08-08 20:25:22 --> Language Class Initialized
INFO - 2018-08-08 20:25:22 --> Config Class Initialized
INFO - 2018-08-08 20:25:22 --> Loader Class Initialized
DEBUG - 2018-08-08 20:25:22 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-08 20:25:22 --> Helper loaded: url_helper
INFO - 2018-08-08 20:25:22 --> Helper loaded: form_helper
INFO - 2018-08-08 20:25:22 --> Helper loaded: date_helper
INFO - 2018-08-08 20:25:23 --> Helper loaded: util_helper
INFO - 2018-08-08 20:25:23 --> Helper loaded: text_helper
INFO - 2018-08-08 20:25:23 --> Helper loaded: string_helper
INFO - 2018-08-08 20:25:23 --> Database Driver Class Initialized
DEBUG - 2018-08-08 20:25:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-08 20:25:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-08 20:25:23 --> Email Class Initialized
INFO - 2018-08-08 20:25:23 --> Controller Class Initialized
DEBUG - 2018-08-08 20:25:23 --> Programs MX_Controller Initialized
INFO - 2018-08-08 20:25:23 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-08 20:25:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-08-08 20:25:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-08 20:25:23 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-08 20:25:23 --> Login MX_Controller Initialized
DEBUG - 2018-08-08 20:25:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-08 20:25:23 --> Final output sent to browser
DEBUG - 2018-08-08 20:25:23 --> Total execution time: 0.8550
INFO - 2018-08-08 21:01:35 --> Config Class Initialized
INFO - 2018-08-08 21:01:35 --> Hooks Class Initialized
DEBUG - 2018-08-08 21:01:35 --> UTF-8 Support Enabled
INFO - 2018-08-08 21:01:35 --> Utf8 Class Initialized
INFO - 2018-08-08 21:01:35 --> URI Class Initialized
INFO - 2018-08-08 21:01:35 --> Router Class Initialized
INFO - 2018-08-08 21:01:35 --> Output Class Initialized
INFO - 2018-08-08 21:01:35 --> Security Class Initialized
DEBUG - 2018-08-08 21:01:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-08 21:01:35 --> Input Class Initialized
INFO - 2018-08-08 21:01:35 --> Language Class Initialized
INFO - 2018-08-08 21:01:35 --> Language Class Initialized
INFO - 2018-08-08 21:01:35 --> Config Class Initialized
INFO - 2018-08-08 21:01:35 --> Loader Class Initialized
DEBUG - 2018-08-08 21:01:35 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-08 21:01:35 --> Helper loaded: url_helper
INFO - 2018-08-08 21:01:35 --> Helper loaded: form_helper
INFO - 2018-08-08 21:01:35 --> Helper loaded: date_helper
INFO - 2018-08-08 21:01:35 --> Helper loaded: util_helper
INFO - 2018-08-08 21:01:35 --> Helper loaded: text_helper
INFO - 2018-08-08 21:01:35 --> Helper loaded: string_helper
INFO - 2018-08-08 21:01:35 --> Database Driver Class Initialized
DEBUG - 2018-08-08 21:01:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-08 21:01:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-08 21:01:35 --> Email Class Initialized
INFO - 2018-08-08 21:01:35 --> Controller Class Initialized
DEBUG - 2018-08-08 21:01:35 --> Settings MX_Controller Initialized
INFO - 2018-08-08 21:01:35 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-08 21:01:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-08 21:01:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Settings_model.php
DEBUG - 2018-08-08 21:01:35 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-08 21:01:35 --> Login MX_Controller Initialized
DEBUG - 2018-08-08 21:01:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-08 21:01:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-08-08 21:01:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-08-08 21:01:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-08-08 21:01:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-08-08 21:01:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-08-08 21:01:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/settings.php
INFO - 2018-08-08 21:01:35 --> Final output sent to browser
DEBUG - 2018-08-08 21:01:35 --> Total execution time: 0.5335
INFO - 2018-08-08 21:01:49 --> Config Class Initialized
INFO - 2018-08-08 21:01:49 --> Hooks Class Initialized
DEBUG - 2018-08-08 21:01:49 --> UTF-8 Support Enabled
INFO - 2018-08-08 21:01:49 --> Utf8 Class Initialized
INFO - 2018-08-08 21:01:49 --> URI Class Initialized
INFO - 2018-08-08 21:01:49 --> Router Class Initialized
INFO - 2018-08-08 21:01:49 --> Output Class Initialized
INFO - 2018-08-08 21:01:49 --> Security Class Initialized
DEBUG - 2018-08-08 21:01:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-08 21:01:49 --> Input Class Initialized
INFO - 2018-08-08 21:01:49 --> Language Class Initialized
INFO - 2018-08-08 21:01:49 --> Language Class Initialized
INFO - 2018-08-08 21:01:49 --> Config Class Initialized
INFO - 2018-08-08 21:01:49 --> Loader Class Initialized
DEBUG - 2018-08-08 21:01:49 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-08 21:01:49 --> Helper loaded: url_helper
INFO - 2018-08-08 21:01:49 --> Helper loaded: form_helper
INFO - 2018-08-08 21:01:49 --> Helper loaded: date_helper
INFO - 2018-08-08 21:01:49 --> Helper loaded: util_helper
INFO - 2018-08-08 21:01:49 --> Helper loaded: text_helper
INFO - 2018-08-08 21:01:49 --> Helper loaded: string_helper
INFO - 2018-08-08 21:01:49 --> Database Driver Class Initialized
DEBUG - 2018-08-08 21:01:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-08 21:01:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-08 21:01:49 --> Email Class Initialized
INFO - 2018-08-08 21:01:49 --> Controller Class Initialized
DEBUG - 2018-08-08 21:01:49 --> Settings MX_Controller Initialized
INFO - 2018-08-08 21:01:49 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-08 21:01:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-08 21:01:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Settings_model.php
DEBUG - 2018-08-08 21:01:49 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-08 21:01:50 --> Login MX_Controller Initialized
DEBUG - 2018-08-08 21:01:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-08 21:01:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
INFO - 2018-08-08 21:01:50 --> Upload Class Initialized
ERROR - 2018-08-08 21:01:50 --> Severity: Notice --> Undefined variable: row E:\xampp\htdocs\consulting\application\modules\admin\controllers\Settings.php 105
INFO - 2018-08-08 21:01:50 --> Config Class Initialized
INFO - 2018-08-08 21:01:50 --> Hooks Class Initialized
DEBUG - 2018-08-08 21:01:50 --> UTF-8 Support Enabled
INFO - 2018-08-08 21:01:50 --> Utf8 Class Initialized
INFO - 2018-08-08 21:01:50 --> URI Class Initialized
INFO - 2018-08-08 21:01:50 --> Router Class Initialized
INFO - 2018-08-08 21:01:50 --> Output Class Initialized
INFO - 2018-08-08 21:01:50 --> Security Class Initialized
DEBUG - 2018-08-08 21:01:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-08 21:01:50 --> Input Class Initialized
INFO - 2018-08-08 21:01:50 --> Language Class Initialized
INFO - 2018-08-08 21:01:50 --> Language Class Initialized
INFO - 2018-08-08 21:01:50 --> Config Class Initialized
INFO - 2018-08-08 21:01:50 --> Loader Class Initialized
DEBUG - 2018-08-08 21:01:50 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-08 21:01:50 --> Helper loaded: url_helper
INFO - 2018-08-08 21:01:50 --> Helper loaded: form_helper
INFO - 2018-08-08 21:01:50 --> Helper loaded: date_helper
INFO - 2018-08-08 21:01:50 --> Helper loaded: util_helper
INFO - 2018-08-08 21:01:50 --> Helper loaded: text_helper
INFO - 2018-08-08 21:01:50 --> Helper loaded: string_helper
INFO - 2018-08-08 21:01:50 --> Database Driver Class Initialized
DEBUG - 2018-08-08 21:01:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-08 21:01:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-08 21:01:50 --> Email Class Initialized
INFO - 2018-08-08 21:01:50 --> Controller Class Initialized
DEBUG - 2018-08-08 21:01:50 --> Settings MX_Controller Initialized
INFO - 2018-08-08 21:01:50 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-08 21:01:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-08 21:01:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Settings_model.php
DEBUG - 2018-08-08 21:01:50 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-08 21:01:50 --> Login MX_Controller Initialized
DEBUG - 2018-08-08 21:01:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-08 21:01:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-08-08 21:01:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-08-08 21:01:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-08-08 21:01:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-08-08 21:01:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-08-08 21:01:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/settings.php
INFO - 2018-08-08 21:01:50 --> Final output sent to browser
DEBUG - 2018-08-08 21:01:50 --> Total execution time: 0.4974
INFO - 2018-08-08 21:02:08 --> Config Class Initialized
INFO - 2018-08-08 21:02:08 --> Hooks Class Initialized
DEBUG - 2018-08-08 21:02:08 --> UTF-8 Support Enabled
INFO - 2018-08-08 21:02:08 --> Utf8 Class Initialized
INFO - 2018-08-08 21:02:08 --> URI Class Initialized
INFO - 2018-08-08 21:02:08 --> Router Class Initialized
INFO - 2018-08-08 21:02:08 --> Output Class Initialized
INFO - 2018-08-08 21:02:08 --> Security Class Initialized
DEBUG - 2018-08-08 21:02:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-08 21:02:08 --> Input Class Initialized
INFO - 2018-08-08 21:02:08 --> Language Class Initialized
INFO - 2018-08-08 21:02:08 --> Language Class Initialized
INFO - 2018-08-08 21:02:08 --> Config Class Initialized
INFO - 2018-08-08 21:02:08 --> Loader Class Initialized
DEBUG - 2018-08-08 21:02:08 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-08 21:02:08 --> Helper loaded: url_helper
INFO - 2018-08-08 21:02:08 --> Helper loaded: form_helper
INFO - 2018-08-08 21:02:08 --> Helper loaded: date_helper
INFO - 2018-08-08 21:02:08 --> Helper loaded: util_helper
INFO - 2018-08-08 21:02:08 --> Helper loaded: text_helper
INFO - 2018-08-08 21:02:08 --> Helper loaded: string_helper
INFO - 2018-08-08 21:02:08 --> Database Driver Class Initialized
DEBUG - 2018-08-08 21:02:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-08 21:02:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-08 21:02:08 --> Email Class Initialized
INFO - 2018-08-08 21:02:08 --> Controller Class Initialized
DEBUG - 2018-08-08 21:02:08 --> Settings MX_Controller Initialized
INFO - 2018-08-08 21:02:08 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-08 21:02:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-08 21:02:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Settings_model.php
DEBUG - 2018-08-08 21:02:08 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-08 21:02:08 --> Login MX_Controller Initialized
DEBUG - 2018-08-08 21:02:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-08 21:02:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
INFO - 2018-08-08 21:02:08 --> Upload Class Initialized
INFO - 2018-08-08 21:02:08 --> Language file loaded: language/english/upload_lang.php
DEBUG - 2018-08-08 21:02:08 --> The filetype you are attempting to upload is not allowed.
INFO - 2018-08-08 21:02:08 --> Config Class Initialized
INFO - 2018-08-08 21:02:08 --> Hooks Class Initialized
DEBUG - 2018-08-08 21:02:08 --> UTF-8 Support Enabled
INFO - 2018-08-08 21:02:08 --> Utf8 Class Initialized
INFO - 2018-08-08 21:02:08 --> URI Class Initialized
INFO - 2018-08-08 21:02:08 --> Router Class Initialized
INFO - 2018-08-08 21:02:08 --> Output Class Initialized
INFO - 2018-08-08 21:02:08 --> Security Class Initialized
DEBUG - 2018-08-08 21:02:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-08 21:02:08 --> Input Class Initialized
INFO - 2018-08-08 21:02:08 --> Language Class Initialized
INFO - 2018-08-08 21:02:08 --> Language Class Initialized
INFO - 2018-08-08 21:02:08 --> Config Class Initialized
INFO - 2018-08-08 21:02:08 --> Loader Class Initialized
DEBUG - 2018-08-08 21:02:08 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-08 21:02:08 --> Helper loaded: url_helper
INFO - 2018-08-08 21:02:08 --> Helper loaded: form_helper
INFO - 2018-08-08 21:02:08 --> Helper loaded: date_helper
INFO - 2018-08-08 21:02:08 --> Helper loaded: util_helper
INFO - 2018-08-08 21:02:08 --> Helper loaded: text_helper
INFO - 2018-08-08 21:02:08 --> Helper loaded: string_helper
INFO - 2018-08-08 21:02:08 --> Database Driver Class Initialized
DEBUG - 2018-08-08 21:02:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-08 21:02:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-08 21:02:08 --> Email Class Initialized
INFO - 2018-08-08 21:02:08 --> Controller Class Initialized
DEBUG - 2018-08-08 21:02:08 --> Settings MX_Controller Initialized
INFO - 2018-08-08 21:02:08 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-08 21:02:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-08 21:02:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Settings_model.php
DEBUG - 2018-08-08 21:02:08 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-08 21:02:08 --> Login MX_Controller Initialized
DEBUG - 2018-08-08 21:02:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-08 21:02:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-08-08 21:02:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-08-08 21:02:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-08-08 21:02:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-08-08 21:02:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-08-08 21:02:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/settings.php
INFO - 2018-08-08 21:02:09 --> Final output sent to browser
DEBUG - 2018-08-08 21:02:09 --> Total execution time: 0.5062
INFO - 2018-08-08 21:02:58 --> Config Class Initialized
INFO - 2018-08-08 21:02:58 --> Hooks Class Initialized
DEBUG - 2018-08-08 21:02:58 --> UTF-8 Support Enabled
INFO - 2018-08-08 21:02:58 --> Utf8 Class Initialized
INFO - 2018-08-08 21:02:58 --> URI Class Initialized
INFO - 2018-08-08 21:02:58 --> Router Class Initialized
INFO - 2018-08-08 21:02:58 --> Output Class Initialized
INFO - 2018-08-08 21:02:58 --> Security Class Initialized
DEBUG - 2018-08-08 21:02:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-08 21:02:58 --> Input Class Initialized
INFO - 2018-08-08 21:02:58 --> Language Class Initialized
INFO - 2018-08-08 21:02:58 --> Language Class Initialized
INFO - 2018-08-08 21:02:58 --> Config Class Initialized
INFO - 2018-08-08 21:02:58 --> Loader Class Initialized
DEBUG - 2018-08-08 21:02:58 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-08 21:02:58 --> Helper loaded: url_helper
INFO - 2018-08-08 21:02:58 --> Helper loaded: form_helper
INFO - 2018-08-08 21:02:58 --> Helper loaded: date_helper
INFO - 2018-08-08 21:02:58 --> Helper loaded: util_helper
INFO - 2018-08-08 21:02:58 --> Helper loaded: text_helper
INFO - 2018-08-08 21:02:58 --> Helper loaded: string_helper
INFO - 2018-08-08 21:02:58 --> Database Driver Class Initialized
DEBUG - 2018-08-08 21:02:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-08 21:02:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-08 21:02:58 --> Email Class Initialized
INFO - 2018-08-08 21:02:58 --> Controller Class Initialized
DEBUG - 2018-08-08 21:02:58 --> Settings MX_Controller Initialized
INFO - 2018-08-08 21:02:59 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-08 21:02:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-08 21:02:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Settings_model.php
DEBUG - 2018-08-08 21:02:59 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-08 21:02:59 --> Login MX_Controller Initialized
DEBUG - 2018-08-08 21:02:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-08 21:02:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
INFO - 2018-08-08 21:02:59 --> Upload Class Initialized
ERROR - 2018-08-08 21:02:59 --> Severity: Notice --> Undefined variable: row E:\xampp\htdocs\consulting\application\modules\admin\controllers\Settings.php 105
INFO - 2018-08-08 21:02:59 --> Config Class Initialized
INFO - 2018-08-08 21:02:59 --> Hooks Class Initialized
DEBUG - 2018-08-08 21:02:59 --> UTF-8 Support Enabled
INFO - 2018-08-08 21:02:59 --> Utf8 Class Initialized
INFO - 2018-08-08 21:02:59 --> URI Class Initialized
INFO - 2018-08-08 21:02:59 --> Router Class Initialized
INFO - 2018-08-08 21:02:59 --> Output Class Initialized
INFO - 2018-08-08 21:02:59 --> Security Class Initialized
DEBUG - 2018-08-08 21:02:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-08 21:02:59 --> Input Class Initialized
INFO - 2018-08-08 21:02:59 --> Language Class Initialized
INFO - 2018-08-08 21:02:59 --> Language Class Initialized
INFO - 2018-08-08 21:02:59 --> Config Class Initialized
INFO - 2018-08-08 21:02:59 --> Loader Class Initialized
DEBUG - 2018-08-08 21:02:59 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-08 21:02:59 --> Helper loaded: url_helper
INFO - 2018-08-08 21:02:59 --> Helper loaded: form_helper
INFO - 2018-08-08 21:02:59 --> Helper loaded: date_helper
INFO - 2018-08-08 21:02:59 --> Helper loaded: util_helper
INFO - 2018-08-08 21:02:59 --> Helper loaded: text_helper
INFO - 2018-08-08 21:02:59 --> Helper loaded: string_helper
INFO - 2018-08-08 21:02:59 --> Database Driver Class Initialized
DEBUG - 2018-08-08 21:02:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-08 21:02:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-08 21:02:59 --> Email Class Initialized
INFO - 2018-08-08 21:02:59 --> Controller Class Initialized
DEBUG - 2018-08-08 21:02:59 --> Settings MX_Controller Initialized
INFO - 2018-08-08 21:02:59 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-08 21:02:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-08 21:02:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Settings_model.php
DEBUG - 2018-08-08 21:02:59 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-08 21:02:59 --> Login MX_Controller Initialized
DEBUG - 2018-08-08 21:02:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-08 21:02:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-08-08 21:02:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-08-08 21:02:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-08-08 21:02:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-08-08 21:02:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-08-08 21:02:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/settings.php
INFO - 2018-08-08 21:02:59 --> Final output sent to browser
DEBUG - 2018-08-08 21:02:59 --> Total execution time: 0.5422
INFO - 2018-08-08 21:03:57 --> Config Class Initialized
INFO - 2018-08-08 21:03:57 --> Hooks Class Initialized
DEBUG - 2018-08-08 21:03:57 --> UTF-8 Support Enabled
INFO - 2018-08-08 21:03:57 --> Utf8 Class Initialized
INFO - 2018-08-08 21:03:57 --> URI Class Initialized
INFO - 2018-08-08 21:03:57 --> Router Class Initialized
INFO - 2018-08-08 21:03:57 --> Output Class Initialized
INFO - 2018-08-08 21:03:57 --> Security Class Initialized
DEBUG - 2018-08-08 21:03:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-08 21:03:57 --> Input Class Initialized
INFO - 2018-08-08 21:03:57 --> Language Class Initialized
INFO - 2018-08-08 21:03:57 --> Language Class Initialized
INFO - 2018-08-08 21:03:57 --> Config Class Initialized
INFO - 2018-08-08 21:03:57 --> Loader Class Initialized
DEBUG - 2018-08-08 21:03:57 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-08 21:03:57 --> Helper loaded: url_helper
INFO - 2018-08-08 21:03:57 --> Helper loaded: form_helper
INFO - 2018-08-08 21:03:57 --> Helper loaded: date_helper
INFO - 2018-08-08 21:03:57 --> Helper loaded: util_helper
INFO - 2018-08-08 21:03:57 --> Helper loaded: text_helper
INFO - 2018-08-08 21:03:57 --> Helper loaded: string_helper
INFO - 2018-08-08 21:03:57 --> Database Driver Class Initialized
DEBUG - 2018-08-08 21:03:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-08 21:03:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-08 21:03:57 --> Email Class Initialized
INFO - 2018-08-08 21:03:57 --> Controller Class Initialized
DEBUG - 2018-08-08 21:03:57 --> Settings MX_Controller Initialized
INFO - 2018-08-08 21:03:57 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-08 21:03:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-08 21:03:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Settings_model.php
DEBUG - 2018-08-08 21:03:57 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-08 21:03:57 --> Login MX_Controller Initialized
DEBUG - 2018-08-08 21:03:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-08 21:03:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
INFO - 2018-08-08 21:03:57 --> Upload Class Initialized
INFO - 2018-08-08 21:03:57 --> Language file loaded: language/english/upload_lang.php
DEBUG - 2018-08-08 21:03:57 --> The filetype you are attempting to upload is not allowed.
INFO - 2018-08-08 21:03:57 --> Config Class Initialized
INFO - 2018-08-08 21:03:57 --> Hooks Class Initialized
DEBUG - 2018-08-08 21:03:57 --> UTF-8 Support Enabled
INFO - 2018-08-08 21:03:57 --> Utf8 Class Initialized
INFO - 2018-08-08 21:03:57 --> URI Class Initialized
INFO - 2018-08-08 21:03:57 --> Router Class Initialized
INFO - 2018-08-08 21:03:57 --> Output Class Initialized
INFO - 2018-08-08 21:03:57 --> Security Class Initialized
DEBUG - 2018-08-08 21:03:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-08 21:03:57 --> Input Class Initialized
INFO - 2018-08-08 21:03:57 --> Language Class Initialized
INFO - 2018-08-08 21:03:57 --> Language Class Initialized
INFO - 2018-08-08 21:03:57 --> Config Class Initialized
INFO - 2018-08-08 21:03:57 --> Loader Class Initialized
DEBUG - 2018-08-08 21:03:57 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-08 21:03:57 --> Helper loaded: url_helper
INFO - 2018-08-08 21:03:57 --> Helper loaded: form_helper
INFO - 2018-08-08 21:03:57 --> Helper loaded: date_helper
INFO - 2018-08-08 21:03:57 --> Helper loaded: util_helper
INFO - 2018-08-08 21:03:57 --> Helper loaded: text_helper
INFO - 2018-08-08 21:03:57 --> Helper loaded: string_helper
INFO - 2018-08-08 21:03:57 --> Database Driver Class Initialized
DEBUG - 2018-08-08 21:03:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-08 21:03:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-08 21:03:57 --> Email Class Initialized
INFO - 2018-08-08 21:03:57 --> Controller Class Initialized
DEBUG - 2018-08-08 21:03:57 --> Settings MX_Controller Initialized
INFO - 2018-08-08 21:03:57 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-08 21:03:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-08 21:03:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Settings_model.php
DEBUG - 2018-08-08 21:03:57 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-08 21:03:57 --> Login MX_Controller Initialized
DEBUG - 2018-08-08 21:03:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-08 21:03:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-08-08 21:03:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-08-08 21:03:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-08-08 21:03:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-08-08 21:03:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-08-08 21:03:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/settings.php
INFO - 2018-08-08 21:03:58 --> Final output sent to browser
DEBUG - 2018-08-08 21:03:58 --> Total execution time: 0.5189
INFO - 2018-08-08 21:04:28 --> Config Class Initialized
INFO - 2018-08-08 21:04:28 --> Hooks Class Initialized
DEBUG - 2018-08-08 21:04:28 --> UTF-8 Support Enabled
INFO - 2018-08-08 21:04:28 --> Utf8 Class Initialized
INFO - 2018-08-08 21:04:28 --> URI Class Initialized
INFO - 2018-08-08 21:04:28 --> Router Class Initialized
INFO - 2018-08-08 21:04:28 --> Output Class Initialized
INFO - 2018-08-08 21:04:28 --> Security Class Initialized
DEBUG - 2018-08-08 21:04:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-08 21:04:28 --> Input Class Initialized
INFO - 2018-08-08 21:04:28 --> Language Class Initialized
INFO - 2018-08-08 21:04:28 --> Language Class Initialized
INFO - 2018-08-08 21:04:28 --> Config Class Initialized
INFO - 2018-08-08 21:04:28 --> Loader Class Initialized
DEBUG - 2018-08-08 21:04:28 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-08 21:04:28 --> Helper loaded: url_helper
INFO - 2018-08-08 21:04:28 --> Helper loaded: form_helper
INFO - 2018-08-08 21:04:28 --> Helper loaded: date_helper
INFO - 2018-08-08 21:04:28 --> Helper loaded: util_helper
INFO - 2018-08-08 21:04:28 --> Helper loaded: text_helper
INFO - 2018-08-08 21:04:28 --> Helper loaded: string_helper
INFO - 2018-08-08 21:04:28 --> Database Driver Class Initialized
DEBUG - 2018-08-08 21:04:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-08 21:04:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-08 21:04:28 --> Email Class Initialized
INFO - 2018-08-08 21:04:28 --> Controller Class Initialized
DEBUG - 2018-08-08 21:04:28 --> Settings MX_Controller Initialized
INFO - 2018-08-08 21:04:28 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-08 21:04:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-08 21:04:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Settings_model.php
DEBUG - 2018-08-08 21:04:28 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-08 21:04:28 --> Login MX_Controller Initialized
DEBUG - 2018-08-08 21:04:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-08 21:04:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
INFO - 2018-08-08 21:04:28 --> Upload Class Initialized
INFO - 2018-08-08 21:04:28 --> Language file loaded: language/english/upload_lang.php
DEBUG - 2018-08-08 21:04:28 --> The filetype you are attempting to upload is not allowed.
INFO - 2018-08-08 21:04:28 --> Config Class Initialized
INFO - 2018-08-08 21:04:28 --> Hooks Class Initialized
DEBUG - 2018-08-08 21:04:28 --> UTF-8 Support Enabled
INFO - 2018-08-08 21:04:28 --> Utf8 Class Initialized
INFO - 2018-08-08 21:04:28 --> URI Class Initialized
INFO - 2018-08-08 21:04:28 --> Router Class Initialized
INFO - 2018-08-08 21:04:29 --> Output Class Initialized
INFO - 2018-08-08 21:04:29 --> Security Class Initialized
DEBUG - 2018-08-08 21:04:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-08 21:04:29 --> Input Class Initialized
INFO - 2018-08-08 21:04:29 --> Language Class Initialized
INFO - 2018-08-08 21:04:29 --> Language Class Initialized
INFO - 2018-08-08 21:04:29 --> Config Class Initialized
INFO - 2018-08-08 21:04:29 --> Loader Class Initialized
DEBUG - 2018-08-08 21:04:29 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-08 21:04:29 --> Helper loaded: url_helper
INFO - 2018-08-08 21:04:29 --> Helper loaded: form_helper
INFO - 2018-08-08 21:04:29 --> Helper loaded: date_helper
INFO - 2018-08-08 21:04:29 --> Helper loaded: util_helper
INFO - 2018-08-08 21:04:29 --> Helper loaded: text_helper
INFO - 2018-08-08 21:04:29 --> Helper loaded: string_helper
INFO - 2018-08-08 21:04:29 --> Database Driver Class Initialized
DEBUG - 2018-08-08 21:04:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-08 21:04:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-08 21:04:29 --> Email Class Initialized
INFO - 2018-08-08 21:04:29 --> Controller Class Initialized
DEBUG - 2018-08-08 21:04:29 --> Settings MX_Controller Initialized
INFO - 2018-08-08 21:04:29 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-08 21:04:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-08 21:04:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Settings_model.php
DEBUG - 2018-08-08 21:04:29 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-08 21:04:29 --> Login MX_Controller Initialized
DEBUG - 2018-08-08 21:04:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-08 21:04:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-08-08 21:04:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-08-08 21:04:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-08-08 21:04:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-08-08 21:04:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-08-08 21:04:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/settings.php
INFO - 2018-08-08 21:04:29 --> Final output sent to browser
DEBUG - 2018-08-08 21:04:29 --> Total execution time: 0.5395
INFO - 2018-08-08 21:06:29 --> Config Class Initialized
INFO - 2018-08-08 21:06:29 --> Hooks Class Initialized
DEBUG - 2018-08-08 21:06:29 --> UTF-8 Support Enabled
INFO - 2018-08-08 21:06:29 --> Utf8 Class Initialized
INFO - 2018-08-08 21:06:29 --> URI Class Initialized
INFO - 2018-08-08 21:06:29 --> Router Class Initialized
INFO - 2018-08-08 21:06:29 --> Output Class Initialized
INFO - 2018-08-08 21:06:29 --> Security Class Initialized
DEBUG - 2018-08-08 21:06:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-08 21:06:29 --> Input Class Initialized
INFO - 2018-08-08 21:06:29 --> Language Class Initialized
INFO - 2018-08-08 21:06:29 --> Language Class Initialized
INFO - 2018-08-08 21:06:29 --> Config Class Initialized
INFO - 2018-08-08 21:06:29 --> Loader Class Initialized
DEBUG - 2018-08-08 21:06:29 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-08 21:06:29 --> Helper loaded: url_helper
INFO - 2018-08-08 21:06:29 --> Helper loaded: form_helper
INFO - 2018-08-08 21:06:29 --> Helper loaded: date_helper
INFO - 2018-08-08 21:06:29 --> Helper loaded: util_helper
INFO - 2018-08-08 21:06:29 --> Helper loaded: text_helper
INFO - 2018-08-08 21:06:29 --> Helper loaded: string_helper
INFO - 2018-08-08 21:06:29 --> Database Driver Class Initialized
DEBUG - 2018-08-08 21:06:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-08 21:06:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-08 21:06:29 --> Email Class Initialized
INFO - 2018-08-08 21:06:29 --> Controller Class Initialized
DEBUG - 2018-08-08 21:06:29 --> Settings MX_Controller Initialized
INFO - 2018-08-08 21:06:29 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-08 21:06:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-08 21:06:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Settings_model.php
DEBUG - 2018-08-08 21:06:29 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-08 21:06:29 --> Login MX_Controller Initialized
DEBUG - 2018-08-08 21:06:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-08 21:06:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
INFO - 2018-08-08 21:06:30 --> Upload Class Initialized
INFO - 2018-08-08 21:06:30 --> Language file loaded: language/english/upload_lang.php
DEBUG - 2018-08-08 21:06:30 --> The filetype you are attempting to upload is not allowed.
INFO - 2018-08-08 21:06:38 --> Config Class Initialized
INFO - 2018-08-08 21:06:38 --> Hooks Class Initialized
DEBUG - 2018-08-08 21:06:38 --> UTF-8 Support Enabled
INFO - 2018-08-08 21:06:38 --> Utf8 Class Initialized
INFO - 2018-08-08 21:06:38 --> URI Class Initialized
INFO - 2018-08-08 21:06:38 --> Router Class Initialized
INFO - 2018-08-08 21:06:38 --> Output Class Initialized
INFO - 2018-08-08 21:06:38 --> Security Class Initialized
DEBUG - 2018-08-08 21:06:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-08 21:06:39 --> Input Class Initialized
INFO - 2018-08-08 21:06:39 --> Language Class Initialized
INFO - 2018-08-08 21:06:39 --> Language Class Initialized
INFO - 2018-08-08 21:06:39 --> Config Class Initialized
INFO - 2018-08-08 21:06:39 --> Loader Class Initialized
DEBUG - 2018-08-08 21:06:39 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-08 21:06:39 --> Helper loaded: url_helper
INFO - 2018-08-08 21:06:39 --> Helper loaded: form_helper
INFO - 2018-08-08 21:06:39 --> Helper loaded: date_helper
INFO - 2018-08-08 21:06:39 --> Helper loaded: util_helper
INFO - 2018-08-08 21:06:39 --> Helper loaded: text_helper
INFO - 2018-08-08 21:06:39 --> Helper loaded: string_helper
INFO - 2018-08-08 21:06:39 --> Database Driver Class Initialized
DEBUG - 2018-08-08 21:06:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-08 21:06:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-08 21:06:39 --> Email Class Initialized
INFO - 2018-08-08 21:06:39 --> Controller Class Initialized
DEBUG - 2018-08-08 21:06:39 --> Settings MX_Controller Initialized
INFO - 2018-08-08 21:06:39 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-08 21:06:39 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-08 21:06:39 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Settings_model.php
DEBUG - 2018-08-08 21:06:39 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-08 21:06:39 --> Login MX_Controller Initialized
DEBUG - 2018-08-08 21:06:39 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-08 22:15:57 --> Config Class Initialized
INFO - 2018-08-08 22:15:57 --> Hooks Class Initialized
DEBUG - 2018-08-08 22:15:57 --> UTF-8 Support Enabled
INFO - 2018-08-08 22:15:57 --> Utf8 Class Initialized
INFO - 2018-08-08 22:15:57 --> URI Class Initialized
INFO - 2018-08-08 22:15:57 --> Router Class Initialized
INFO - 2018-08-08 22:15:57 --> Output Class Initialized
INFO - 2018-08-08 22:15:57 --> Security Class Initialized
DEBUG - 2018-08-08 22:15:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-08 22:15:57 --> Input Class Initialized
INFO - 2018-08-08 22:15:57 --> Language Class Initialized
INFO - 2018-08-08 22:15:57 --> Language Class Initialized
INFO - 2018-08-08 22:15:57 --> Config Class Initialized
INFO - 2018-08-08 22:15:57 --> Loader Class Initialized
DEBUG - 2018-08-08 22:15:57 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-08 22:15:57 --> Helper loaded: url_helper
INFO - 2018-08-08 22:15:57 --> Helper loaded: form_helper
INFO - 2018-08-08 22:15:57 --> Helper loaded: date_helper
INFO - 2018-08-08 22:15:57 --> Helper loaded: util_helper
INFO - 2018-08-08 22:15:57 --> Helper loaded: text_helper
INFO - 2018-08-08 22:15:57 --> Helper loaded: string_helper
INFO - 2018-08-08 22:15:57 --> Database Driver Class Initialized
DEBUG - 2018-08-08 22:15:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-08 22:15:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-08 22:15:57 --> Email Class Initialized
INFO - 2018-08-08 22:15:57 --> Controller Class Initialized
DEBUG - 2018-08-08 22:15:57 --> Settings MX_Controller Initialized
INFO - 2018-08-08 22:15:57 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-08 22:15:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-08 22:15:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Settings_model.php
DEBUG - 2018-08-08 22:15:57 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-08 22:15:58 --> Login MX_Controller Initialized
DEBUG - 2018-08-08 22:15:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-08 22:15:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-08-08 22:15:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-08-08 22:15:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-08-08 22:15:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-08-08 22:15:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-08-08 22:15:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/settings.php
INFO - 2018-08-08 22:15:58 --> Final output sent to browser
DEBUG - 2018-08-08 22:15:58 --> Total execution time: 0.5642
INFO - 2018-08-08 22:16:00 --> Config Class Initialized
INFO - 2018-08-08 22:16:00 --> Hooks Class Initialized
DEBUG - 2018-08-08 22:16:00 --> UTF-8 Support Enabled
INFO - 2018-08-08 22:16:00 --> Utf8 Class Initialized
INFO - 2018-08-08 22:16:00 --> URI Class Initialized
INFO - 2018-08-08 22:16:00 --> Router Class Initialized
INFO - 2018-08-08 22:16:00 --> Output Class Initialized
INFO - 2018-08-08 22:16:00 --> Security Class Initialized
DEBUG - 2018-08-08 22:16:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-08 22:16:00 --> Input Class Initialized
INFO - 2018-08-08 22:16:00 --> Language Class Initialized
INFO - 2018-08-08 22:16:00 --> Language Class Initialized
INFO - 2018-08-08 22:16:00 --> Config Class Initialized
INFO - 2018-08-08 22:16:00 --> Loader Class Initialized
DEBUG - 2018-08-08 22:16:00 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-08 22:16:00 --> Helper loaded: url_helper
INFO - 2018-08-08 22:16:00 --> Helper loaded: form_helper
INFO - 2018-08-08 22:16:00 --> Helper loaded: date_helper
INFO - 2018-08-08 22:16:00 --> Helper loaded: util_helper
INFO - 2018-08-08 22:16:00 --> Helper loaded: text_helper
INFO - 2018-08-08 22:16:00 --> Helper loaded: string_helper
INFO - 2018-08-08 22:16:01 --> Database Driver Class Initialized
DEBUG - 2018-08-08 22:16:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-08 22:16:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-08 22:16:01 --> Email Class Initialized
INFO - 2018-08-08 22:16:01 --> Controller Class Initialized
DEBUG - 2018-08-08 22:16:01 --> Settings MX_Controller Initialized
INFO - 2018-08-08 22:16:01 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-08 22:16:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-08 22:16:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Settings_model.php
DEBUG - 2018-08-08 22:16:01 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-08 22:16:01 --> Login MX_Controller Initialized
DEBUG - 2018-08-08 22:16:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-08 22:16:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-08-08 22:16:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-08-08 22:16:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-08-08 22:16:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-08-08 22:16:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-08-08 22:16:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/settings.php
INFO - 2018-08-08 22:16:01 --> Final output sent to browser
DEBUG - 2018-08-08 22:16:01 --> Total execution time: 0.5607
INFO - 2018-08-08 22:16:14 --> Config Class Initialized
INFO - 2018-08-08 22:16:14 --> Hooks Class Initialized
DEBUG - 2018-08-08 22:16:14 --> UTF-8 Support Enabled
INFO - 2018-08-08 22:16:14 --> Utf8 Class Initialized
INFO - 2018-08-08 22:16:14 --> URI Class Initialized
INFO - 2018-08-08 22:16:14 --> Router Class Initialized
INFO - 2018-08-08 22:16:14 --> Output Class Initialized
INFO - 2018-08-08 22:16:14 --> Security Class Initialized
DEBUG - 2018-08-08 22:16:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-08 22:16:14 --> Input Class Initialized
INFO - 2018-08-08 22:16:14 --> Language Class Initialized
INFO - 2018-08-08 22:16:14 --> Language Class Initialized
INFO - 2018-08-08 22:16:14 --> Config Class Initialized
INFO - 2018-08-08 22:16:14 --> Loader Class Initialized
DEBUG - 2018-08-08 22:16:14 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-08 22:16:14 --> Helper loaded: url_helper
INFO - 2018-08-08 22:16:14 --> Helper loaded: form_helper
INFO - 2018-08-08 22:16:14 --> Helper loaded: date_helper
INFO - 2018-08-08 22:16:14 --> Helper loaded: util_helper
INFO - 2018-08-08 22:16:14 --> Helper loaded: text_helper
INFO - 2018-08-08 22:16:14 --> Helper loaded: string_helper
INFO - 2018-08-08 22:16:14 --> Database Driver Class Initialized
DEBUG - 2018-08-08 22:16:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-08 22:16:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-08 22:16:14 --> Email Class Initialized
INFO - 2018-08-08 22:16:14 --> Controller Class Initialized
DEBUG - 2018-08-08 22:16:14 --> Settings MX_Controller Initialized
INFO - 2018-08-08 22:16:14 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-08 22:16:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-08 22:16:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Settings_model.php
DEBUG - 2018-08-08 22:16:14 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-08 22:16:14 --> Login MX_Controller Initialized
DEBUG - 2018-08-08 22:16:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-08 22:16:23 --> Config Class Initialized
INFO - 2018-08-08 22:16:23 --> Hooks Class Initialized
DEBUG - 2018-08-08 22:16:23 --> UTF-8 Support Enabled
INFO - 2018-08-08 22:16:23 --> Utf8 Class Initialized
INFO - 2018-08-08 22:16:23 --> URI Class Initialized
INFO - 2018-08-08 22:16:23 --> Router Class Initialized
INFO - 2018-08-08 22:16:23 --> Output Class Initialized
INFO - 2018-08-08 22:16:23 --> Security Class Initialized
DEBUG - 2018-08-08 22:16:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-08 22:16:23 --> Input Class Initialized
INFO - 2018-08-08 22:16:23 --> Language Class Initialized
INFO - 2018-08-08 22:16:23 --> Language Class Initialized
INFO - 2018-08-08 22:16:23 --> Config Class Initialized
INFO - 2018-08-08 22:16:23 --> Loader Class Initialized
DEBUG - 2018-08-08 22:16:23 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-08 22:16:23 --> Helper loaded: url_helper
INFO - 2018-08-08 22:16:23 --> Helper loaded: form_helper
INFO - 2018-08-08 22:16:23 --> Helper loaded: date_helper
INFO - 2018-08-08 22:16:23 --> Helper loaded: util_helper
INFO - 2018-08-08 22:16:23 --> Helper loaded: text_helper
INFO - 2018-08-08 22:16:23 --> Helper loaded: string_helper
INFO - 2018-08-08 22:16:23 --> Database Driver Class Initialized
DEBUG - 2018-08-08 22:16:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-08 22:16:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-08 22:16:23 --> Email Class Initialized
INFO - 2018-08-08 22:16:23 --> Controller Class Initialized
DEBUG - 2018-08-08 22:16:23 --> Settings MX_Controller Initialized
INFO - 2018-08-08 22:16:23 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-08 22:16:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-08 22:16:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Settings_model.php
DEBUG - 2018-08-08 22:16:23 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-08 22:16:23 --> Login MX_Controller Initialized
DEBUG - 2018-08-08 22:16:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-08 22:16:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
INFO - 2018-08-08 22:16:24 --> Upload Class Initialized
INFO - 2018-08-08 22:16:24 --> Language file loaded: language/english/upload_lang.php
DEBUG - 2018-08-08 22:16:24 --> The filetype you are attempting to upload is not allowed.
INFO - 2018-08-08 22:16:24 --> Config Class Initialized
INFO - 2018-08-08 22:16:24 --> Hooks Class Initialized
DEBUG - 2018-08-08 22:16:24 --> UTF-8 Support Enabled
INFO - 2018-08-08 22:16:24 --> Utf8 Class Initialized
INFO - 2018-08-08 22:16:24 --> URI Class Initialized
INFO - 2018-08-08 22:16:24 --> Router Class Initialized
INFO - 2018-08-08 22:16:24 --> Output Class Initialized
INFO - 2018-08-08 22:16:24 --> Security Class Initialized
DEBUG - 2018-08-08 22:16:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-08 22:16:24 --> Input Class Initialized
INFO - 2018-08-08 22:16:24 --> Language Class Initialized
INFO - 2018-08-08 22:16:24 --> Language Class Initialized
INFO - 2018-08-08 22:16:24 --> Config Class Initialized
INFO - 2018-08-08 22:16:24 --> Loader Class Initialized
DEBUG - 2018-08-08 22:16:24 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-08 22:16:24 --> Helper loaded: url_helper
INFO - 2018-08-08 22:16:24 --> Helper loaded: form_helper
INFO - 2018-08-08 22:16:24 --> Helper loaded: date_helper
INFO - 2018-08-08 22:16:24 --> Helper loaded: util_helper
INFO - 2018-08-08 22:16:24 --> Helper loaded: text_helper
INFO - 2018-08-08 22:16:24 --> Helper loaded: string_helper
INFO - 2018-08-08 22:16:24 --> Database Driver Class Initialized
DEBUG - 2018-08-08 22:16:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-08 22:16:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-08 22:16:24 --> Email Class Initialized
INFO - 2018-08-08 22:16:24 --> Controller Class Initialized
DEBUG - 2018-08-08 22:16:24 --> Settings MX_Controller Initialized
INFO - 2018-08-08 22:16:24 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-08 22:16:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-08 22:16:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Settings_model.php
DEBUG - 2018-08-08 22:16:24 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-08 22:16:24 --> Login MX_Controller Initialized
DEBUG - 2018-08-08 22:16:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-08 22:16:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-08-08 22:16:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-08-08 22:16:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-08-08 22:16:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-08-08 22:16:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-08-08 22:16:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/settings.php
INFO - 2018-08-08 22:16:24 --> Final output sent to browser
DEBUG - 2018-08-08 22:16:24 --> Total execution time: 0.5334
INFO - 2018-08-08 22:16:50 --> Config Class Initialized
INFO - 2018-08-08 22:16:50 --> Hooks Class Initialized
DEBUG - 2018-08-08 22:16:50 --> UTF-8 Support Enabled
INFO - 2018-08-08 22:16:50 --> Utf8 Class Initialized
INFO - 2018-08-08 22:16:50 --> URI Class Initialized
INFO - 2018-08-08 22:16:50 --> Router Class Initialized
INFO - 2018-08-08 22:16:50 --> Output Class Initialized
INFO - 2018-08-08 22:16:50 --> Security Class Initialized
DEBUG - 2018-08-08 22:16:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-08 22:16:50 --> Input Class Initialized
INFO - 2018-08-08 22:16:50 --> Language Class Initialized
INFO - 2018-08-08 22:16:50 --> Language Class Initialized
INFO - 2018-08-08 22:16:50 --> Config Class Initialized
INFO - 2018-08-08 22:16:50 --> Loader Class Initialized
DEBUG - 2018-08-08 22:16:50 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-08 22:16:50 --> Helper loaded: url_helper
INFO - 2018-08-08 22:16:50 --> Helper loaded: form_helper
INFO - 2018-08-08 22:16:50 --> Helper loaded: date_helper
INFO - 2018-08-08 22:16:50 --> Helper loaded: util_helper
INFO - 2018-08-08 22:16:51 --> Helper loaded: text_helper
INFO - 2018-08-08 22:16:51 --> Helper loaded: string_helper
INFO - 2018-08-08 22:16:51 --> Database Driver Class Initialized
DEBUG - 2018-08-08 22:16:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-08 22:16:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-08 22:16:51 --> Email Class Initialized
INFO - 2018-08-08 22:16:51 --> Controller Class Initialized
DEBUG - 2018-08-08 22:16:51 --> Settings MX_Controller Initialized
INFO - 2018-08-08 22:16:51 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-08 22:16:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-08 22:16:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Settings_model.php
DEBUG - 2018-08-08 22:16:51 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-08 22:16:51 --> Login MX_Controller Initialized
DEBUG - 2018-08-08 22:16:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-08 22:16:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
INFO - 2018-08-08 22:16:51 --> Upload Class Initialized
INFO - 2018-08-08 22:16:51 --> Language file loaded: language/english/upload_lang.php
DEBUG - 2018-08-08 22:16:51 --> The filetype you are attempting to upload is not allowed.
INFO - 2018-08-08 22:16:51 --> Config Class Initialized
INFO - 2018-08-08 22:16:51 --> Hooks Class Initialized
DEBUG - 2018-08-08 22:16:51 --> UTF-8 Support Enabled
INFO - 2018-08-08 22:16:51 --> Utf8 Class Initialized
INFO - 2018-08-08 22:16:51 --> URI Class Initialized
INFO - 2018-08-08 22:16:51 --> Router Class Initialized
INFO - 2018-08-08 22:16:51 --> Output Class Initialized
INFO - 2018-08-08 22:16:51 --> Security Class Initialized
DEBUG - 2018-08-08 22:16:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-08 22:16:51 --> Input Class Initialized
INFO - 2018-08-08 22:16:51 --> Language Class Initialized
INFO - 2018-08-08 22:16:51 --> Language Class Initialized
INFO - 2018-08-08 22:16:51 --> Config Class Initialized
INFO - 2018-08-08 22:16:51 --> Loader Class Initialized
DEBUG - 2018-08-08 22:16:51 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-08 22:16:51 --> Helper loaded: url_helper
INFO - 2018-08-08 22:16:51 --> Helper loaded: form_helper
INFO - 2018-08-08 22:16:51 --> Helper loaded: date_helper
INFO - 2018-08-08 22:16:51 --> Helper loaded: util_helper
INFO - 2018-08-08 22:16:51 --> Helper loaded: text_helper
INFO - 2018-08-08 22:16:51 --> Helper loaded: string_helper
INFO - 2018-08-08 22:16:51 --> Database Driver Class Initialized
DEBUG - 2018-08-08 22:16:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-08 22:16:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-08 22:16:51 --> Email Class Initialized
INFO - 2018-08-08 22:16:51 --> Controller Class Initialized
DEBUG - 2018-08-08 22:16:51 --> Settings MX_Controller Initialized
INFO - 2018-08-08 22:16:51 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-08 22:16:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-08 22:16:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Settings_model.php
DEBUG - 2018-08-08 22:16:51 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-08 22:16:51 --> Login MX_Controller Initialized
DEBUG - 2018-08-08 22:16:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-08 22:16:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-08-08 22:16:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-08-08 22:16:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-08-08 22:16:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-08-08 22:16:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-08-08 22:16:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/settings.php
INFO - 2018-08-08 22:16:51 --> Final output sent to browser
DEBUG - 2018-08-08 22:16:51 --> Total execution time: 0.5518
INFO - 2018-08-08 22:17:46 --> Config Class Initialized
INFO - 2018-08-08 22:17:46 --> Hooks Class Initialized
DEBUG - 2018-08-08 22:17:46 --> UTF-8 Support Enabled
INFO - 2018-08-08 22:17:46 --> Utf8 Class Initialized
INFO - 2018-08-08 22:17:46 --> URI Class Initialized
INFO - 2018-08-08 22:17:46 --> Router Class Initialized
INFO - 2018-08-08 22:17:46 --> Output Class Initialized
INFO - 2018-08-08 22:17:46 --> Security Class Initialized
DEBUG - 2018-08-08 22:17:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-08 22:17:46 --> Input Class Initialized
INFO - 2018-08-08 22:17:46 --> Language Class Initialized
INFO - 2018-08-08 22:17:46 --> Language Class Initialized
INFO - 2018-08-08 22:17:46 --> Config Class Initialized
INFO - 2018-08-08 22:17:46 --> Loader Class Initialized
DEBUG - 2018-08-08 22:17:46 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-08 22:17:46 --> Helper loaded: url_helper
INFO - 2018-08-08 22:17:46 --> Helper loaded: form_helper
INFO - 2018-08-08 22:17:46 --> Helper loaded: date_helper
INFO - 2018-08-08 22:17:46 --> Helper loaded: util_helper
INFO - 2018-08-08 22:17:46 --> Helper loaded: text_helper
INFO - 2018-08-08 22:17:46 --> Helper loaded: string_helper
INFO - 2018-08-08 22:17:46 --> Database Driver Class Initialized
DEBUG - 2018-08-08 22:17:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-08 22:17:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-08 22:17:46 --> Email Class Initialized
INFO - 2018-08-08 22:17:46 --> Controller Class Initialized
DEBUG - 2018-08-08 22:17:46 --> Settings MX_Controller Initialized
INFO - 2018-08-08 22:17:46 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-08 22:17:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-08 22:17:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Settings_model.php
DEBUG - 2018-08-08 22:17:46 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-08 22:17:46 --> Login MX_Controller Initialized
DEBUG - 2018-08-08 22:17:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-08 22:17:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
INFO - 2018-08-08 22:17:46 --> Upload Class Initialized
INFO - 2018-08-08 22:17:46 --> Language file loaded: language/english/upload_lang.php
DEBUG - 2018-08-08 22:17:46 --> The filetype you are attempting to upload is not allowed.
INFO - 2018-08-08 22:17:46 --> Config Class Initialized
INFO - 2018-08-08 22:17:46 --> Hooks Class Initialized
DEBUG - 2018-08-08 22:17:46 --> UTF-8 Support Enabled
INFO - 2018-08-08 22:17:46 --> Utf8 Class Initialized
INFO - 2018-08-08 22:17:46 --> URI Class Initialized
INFO - 2018-08-08 22:17:47 --> Router Class Initialized
INFO - 2018-08-08 22:17:47 --> Output Class Initialized
INFO - 2018-08-08 22:17:47 --> Security Class Initialized
DEBUG - 2018-08-08 22:17:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-08 22:17:47 --> Input Class Initialized
INFO - 2018-08-08 22:17:47 --> Language Class Initialized
INFO - 2018-08-08 22:17:47 --> Language Class Initialized
INFO - 2018-08-08 22:17:47 --> Config Class Initialized
INFO - 2018-08-08 22:17:47 --> Loader Class Initialized
DEBUG - 2018-08-08 22:17:47 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-08 22:17:47 --> Helper loaded: url_helper
INFO - 2018-08-08 22:17:47 --> Helper loaded: form_helper
INFO - 2018-08-08 22:17:47 --> Helper loaded: date_helper
INFO - 2018-08-08 22:17:47 --> Helper loaded: util_helper
INFO - 2018-08-08 22:17:47 --> Helper loaded: text_helper
INFO - 2018-08-08 22:17:47 --> Helper loaded: string_helper
INFO - 2018-08-08 22:17:47 --> Database Driver Class Initialized
DEBUG - 2018-08-08 22:17:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-08 22:17:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-08 22:17:47 --> Email Class Initialized
INFO - 2018-08-08 22:17:47 --> Controller Class Initialized
DEBUG - 2018-08-08 22:17:47 --> Settings MX_Controller Initialized
INFO - 2018-08-08 22:17:47 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-08 22:17:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-08 22:17:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Settings_model.php
DEBUG - 2018-08-08 22:17:47 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-08 22:17:47 --> Login MX_Controller Initialized
DEBUG - 2018-08-08 22:17:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-08 22:17:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-08-08 22:17:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-08-08 22:17:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-08-08 22:17:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-08-08 22:17:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-08-08 22:17:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/settings.php
INFO - 2018-08-08 22:17:47 --> Final output sent to browser
DEBUG - 2018-08-08 22:17:47 --> Total execution time: 0.7567
INFO - 2018-08-08 22:18:45 --> Config Class Initialized
INFO - 2018-08-08 22:18:45 --> Hooks Class Initialized
DEBUG - 2018-08-08 22:18:45 --> UTF-8 Support Enabled
INFO - 2018-08-08 22:18:45 --> Utf8 Class Initialized
INFO - 2018-08-08 22:18:45 --> URI Class Initialized
INFO - 2018-08-08 22:18:45 --> Router Class Initialized
INFO - 2018-08-08 22:18:45 --> Output Class Initialized
INFO - 2018-08-08 22:18:45 --> Security Class Initialized
DEBUG - 2018-08-08 22:18:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-08 22:18:45 --> Input Class Initialized
INFO - 2018-08-08 22:18:45 --> Language Class Initialized
INFO - 2018-08-08 22:18:45 --> Language Class Initialized
INFO - 2018-08-08 22:18:45 --> Config Class Initialized
INFO - 2018-08-08 22:18:45 --> Loader Class Initialized
DEBUG - 2018-08-08 22:18:45 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-08 22:18:45 --> Helper loaded: url_helper
INFO - 2018-08-08 22:18:45 --> Helper loaded: form_helper
INFO - 2018-08-08 22:18:45 --> Helper loaded: date_helper
INFO - 2018-08-08 22:18:45 --> Helper loaded: util_helper
INFO - 2018-08-08 22:18:45 --> Helper loaded: text_helper
INFO - 2018-08-08 22:18:45 --> Helper loaded: string_helper
INFO - 2018-08-08 22:18:45 --> Database Driver Class Initialized
DEBUG - 2018-08-08 22:18:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-08 22:18:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-08 22:18:45 --> Email Class Initialized
INFO - 2018-08-08 22:18:45 --> Controller Class Initialized
DEBUG - 2018-08-08 22:18:45 --> Settings MX_Controller Initialized
INFO - 2018-08-08 22:18:46 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-08 22:18:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-08 22:18:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Settings_model.php
DEBUG - 2018-08-08 22:18:46 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-08 22:18:46 --> Login MX_Controller Initialized
DEBUG - 2018-08-08 22:18:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-08 22:18:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
INFO - 2018-08-08 22:18:46 --> Upload Class Initialized
ERROR - 2018-08-08 22:18:46 --> Severity: Notice --> Undefined variable: row E:\xampp\htdocs\consulting\application\modules\admin\controllers\Settings.php 105
INFO - 2018-08-08 22:18:46 --> Config Class Initialized
INFO - 2018-08-08 22:18:46 --> Hooks Class Initialized
DEBUG - 2018-08-08 22:18:46 --> UTF-8 Support Enabled
INFO - 2018-08-08 22:18:46 --> Utf8 Class Initialized
INFO - 2018-08-08 22:18:46 --> URI Class Initialized
INFO - 2018-08-08 22:18:46 --> Router Class Initialized
INFO - 2018-08-08 22:18:46 --> Output Class Initialized
INFO - 2018-08-08 22:18:46 --> Security Class Initialized
DEBUG - 2018-08-08 22:18:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-08 22:18:46 --> Input Class Initialized
INFO - 2018-08-08 22:18:46 --> Language Class Initialized
INFO - 2018-08-08 22:18:46 --> Language Class Initialized
INFO - 2018-08-08 22:18:46 --> Config Class Initialized
INFO - 2018-08-08 22:18:46 --> Loader Class Initialized
DEBUG - 2018-08-08 22:18:46 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-08 22:18:46 --> Helper loaded: url_helper
INFO - 2018-08-08 22:18:46 --> Helper loaded: form_helper
INFO - 2018-08-08 22:18:46 --> Helper loaded: date_helper
INFO - 2018-08-08 22:18:46 --> Helper loaded: util_helper
INFO - 2018-08-08 22:18:46 --> Helper loaded: text_helper
INFO - 2018-08-08 22:18:46 --> Helper loaded: string_helper
INFO - 2018-08-08 22:18:46 --> Database Driver Class Initialized
DEBUG - 2018-08-08 22:18:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-08 22:18:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-08 22:18:46 --> Email Class Initialized
INFO - 2018-08-08 22:18:46 --> Controller Class Initialized
DEBUG - 2018-08-08 22:18:46 --> Settings MX_Controller Initialized
INFO - 2018-08-08 22:18:46 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-08 22:18:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-08 22:18:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Settings_model.php
DEBUG - 2018-08-08 22:18:46 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-08 22:18:46 --> Login MX_Controller Initialized
DEBUG - 2018-08-08 22:18:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-08 22:18:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-08-08 22:18:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-08-08 22:18:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-08-08 22:18:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-08-08 22:18:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-08-08 22:18:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/settings.php
INFO - 2018-08-08 22:18:46 --> Final output sent to browser
DEBUG - 2018-08-08 22:18:46 --> Total execution time: 0.5654
INFO - 2018-08-08 22:18:52 --> Config Class Initialized
INFO - 2018-08-08 22:18:52 --> Hooks Class Initialized
DEBUG - 2018-08-08 22:18:52 --> UTF-8 Support Enabled
INFO - 2018-08-08 22:18:52 --> Utf8 Class Initialized
INFO - 2018-08-08 22:18:52 --> URI Class Initialized
INFO - 2018-08-08 22:18:52 --> Router Class Initialized
INFO - 2018-08-08 22:18:52 --> Output Class Initialized
INFO - 2018-08-08 22:18:52 --> Security Class Initialized
DEBUG - 2018-08-08 22:18:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-08 22:18:52 --> Input Class Initialized
INFO - 2018-08-08 22:18:52 --> Language Class Initialized
INFO - 2018-08-08 22:18:52 --> Language Class Initialized
INFO - 2018-08-08 22:18:52 --> Config Class Initialized
INFO - 2018-08-08 22:18:52 --> Loader Class Initialized
DEBUG - 2018-08-08 22:18:52 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-08 22:18:52 --> Helper loaded: url_helper
INFO - 2018-08-08 22:18:53 --> Helper loaded: form_helper
INFO - 2018-08-08 22:18:53 --> Helper loaded: date_helper
INFO - 2018-08-08 22:18:53 --> Helper loaded: util_helper
INFO - 2018-08-08 22:18:53 --> Helper loaded: text_helper
INFO - 2018-08-08 22:18:53 --> Helper loaded: string_helper
INFO - 2018-08-08 22:18:53 --> Database Driver Class Initialized
DEBUG - 2018-08-08 22:18:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-08 22:18:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-08 22:18:53 --> Email Class Initialized
INFO - 2018-08-08 22:18:53 --> Controller Class Initialized
DEBUG - 2018-08-08 22:18:53 --> Settings MX_Controller Initialized
INFO - 2018-08-08 22:18:53 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-08 22:18:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-08 22:18:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Settings_model.php
DEBUG - 2018-08-08 22:18:53 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-08 22:18:53 --> Login MX_Controller Initialized
DEBUG - 2018-08-08 22:18:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-08 22:18:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
INFO - 2018-08-08 22:18:53 --> Upload Class Initialized
INFO - 2018-08-08 22:18:53 --> Language file loaded: language/english/upload_lang.php
DEBUG - 2018-08-08 22:18:53 --> The filetype you are attempting to upload is not allowed.
INFO - 2018-08-08 22:18:53 --> Config Class Initialized
INFO - 2018-08-08 22:18:53 --> Hooks Class Initialized
DEBUG - 2018-08-08 22:18:53 --> UTF-8 Support Enabled
INFO - 2018-08-08 22:18:53 --> Utf8 Class Initialized
INFO - 2018-08-08 22:18:53 --> URI Class Initialized
INFO - 2018-08-08 22:18:53 --> Router Class Initialized
INFO - 2018-08-08 22:18:53 --> Output Class Initialized
INFO - 2018-08-08 22:18:53 --> Security Class Initialized
DEBUG - 2018-08-08 22:18:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-08 22:18:53 --> Input Class Initialized
INFO - 2018-08-08 22:18:53 --> Language Class Initialized
INFO - 2018-08-08 22:18:53 --> Language Class Initialized
INFO - 2018-08-08 22:18:53 --> Config Class Initialized
INFO - 2018-08-08 22:18:53 --> Loader Class Initialized
DEBUG - 2018-08-08 22:18:53 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-08 22:18:53 --> Helper loaded: url_helper
INFO - 2018-08-08 22:18:53 --> Helper loaded: form_helper
INFO - 2018-08-08 22:18:53 --> Helper loaded: date_helper
INFO - 2018-08-08 22:18:53 --> Helper loaded: util_helper
INFO - 2018-08-08 22:18:53 --> Helper loaded: text_helper
INFO - 2018-08-08 22:18:53 --> Helper loaded: string_helper
INFO - 2018-08-08 22:18:53 --> Database Driver Class Initialized
DEBUG - 2018-08-08 22:18:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-08 22:18:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-08 22:18:53 --> Email Class Initialized
INFO - 2018-08-08 22:18:53 --> Controller Class Initialized
DEBUG - 2018-08-08 22:18:53 --> Settings MX_Controller Initialized
INFO - 2018-08-08 22:18:53 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-08 22:18:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-08 22:18:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Settings_model.php
DEBUG - 2018-08-08 22:18:53 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-08 22:18:53 --> Login MX_Controller Initialized
DEBUG - 2018-08-08 22:18:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-08 22:18:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-08-08 22:18:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-08-08 22:18:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-08-08 22:18:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-08-08 22:18:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-08-08 22:18:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/settings.php
INFO - 2018-08-08 22:18:53 --> Final output sent to browser
DEBUG - 2018-08-08 22:18:53 --> Total execution time: 0.5694
INFO - 2018-08-08 22:20:11 --> Config Class Initialized
INFO - 2018-08-08 22:20:11 --> Hooks Class Initialized
DEBUG - 2018-08-08 22:20:11 --> UTF-8 Support Enabled
INFO - 2018-08-08 22:20:11 --> Utf8 Class Initialized
INFO - 2018-08-08 22:20:11 --> URI Class Initialized
INFO - 2018-08-08 22:20:11 --> Router Class Initialized
INFO - 2018-08-08 22:20:11 --> Output Class Initialized
INFO - 2018-08-08 22:20:11 --> Security Class Initialized
DEBUG - 2018-08-08 22:20:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-08 22:20:11 --> Input Class Initialized
INFO - 2018-08-08 22:20:11 --> Language Class Initialized
INFO - 2018-08-08 22:20:11 --> Language Class Initialized
INFO - 2018-08-08 22:20:11 --> Config Class Initialized
INFO - 2018-08-08 22:20:11 --> Loader Class Initialized
DEBUG - 2018-08-08 22:20:11 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-08 22:20:11 --> Helper loaded: url_helper
INFO - 2018-08-08 22:20:11 --> Helper loaded: form_helper
INFO - 2018-08-08 22:20:11 --> Helper loaded: date_helper
INFO - 2018-08-08 22:20:11 --> Helper loaded: util_helper
INFO - 2018-08-08 22:20:11 --> Helper loaded: text_helper
INFO - 2018-08-08 22:20:11 --> Helper loaded: string_helper
INFO - 2018-08-08 22:20:11 --> Database Driver Class Initialized
DEBUG - 2018-08-08 22:20:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-08 22:20:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-08 22:20:11 --> Email Class Initialized
INFO - 2018-08-08 22:20:11 --> Controller Class Initialized
DEBUG - 2018-08-08 22:20:11 --> Settings MX_Controller Initialized
INFO - 2018-08-08 22:20:11 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-08 22:20:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-08 22:20:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Settings_model.php
DEBUG - 2018-08-08 22:20:12 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-08 22:20:12 --> Login MX_Controller Initialized
DEBUG - 2018-08-08 22:20:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-08 22:20:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
INFO - 2018-08-08 22:20:12 --> Upload Class Initialized
ERROR - 2018-08-08 22:20:12 --> Severity: Notice --> Undefined variable: row E:\xampp\htdocs\consulting\application\modules\admin\controllers\Settings.php 105
INFO - 2018-08-08 22:20:12 --> Config Class Initialized
INFO - 2018-08-08 22:20:12 --> Hooks Class Initialized
DEBUG - 2018-08-08 22:20:12 --> UTF-8 Support Enabled
INFO - 2018-08-08 22:20:12 --> Utf8 Class Initialized
INFO - 2018-08-08 22:20:12 --> URI Class Initialized
INFO - 2018-08-08 22:20:12 --> Router Class Initialized
INFO - 2018-08-08 22:20:12 --> Output Class Initialized
INFO - 2018-08-08 22:20:12 --> Security Class Initialized
DEBUG - 2018-08-08 22:20:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-08 22:20:12 --> Input Class Initialized
INFO - 2018-08-08 22:20:12 --> Language Class Initialized
INFO - 2018-08-08 22:20:12 --> Language Class Initialized
INFO - 2018-08-08 22:20:12 --> Config Class Initialized
INFO - 2018-08-08 22:20:12 --> Loader Class Initialized
DEBUG - 2018-08-08 22:20:12 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-08 22:20:12 --> Helper loaded: url_helper
INFO - 2018-08-08 22:20:12 --> Helper loaded: form_helper
INFO - 2018-08-08 22:20:12 --> Helper loaded: date_helper
INFO - 2018-08-08 22:20:12 --> Helper loaded: util_helper
INFO - 2018-08-08 22:20:12 --> Helper loaded: text_helper
INFO - 2018-08-08 22:20:12 --> Helper loaded: string_helper
INFO - 2018-08-08 22:20:12 --> Database Driver Class Initialized
DEBUG - 2018-08-08 22:20:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-08 22:20:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-08 22:20:12 --> Email Class Initialized
INFO - 2018-08-08 22:20:12 --> Controller Class Initialized
DEBUG - 2018-08-08 22:20:12 --> Settings MX_Controller Initialized
INFO - 2018-08-08 22:20:12 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-08 22:20:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-08 22:20:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Settings_model.php
DEBUG - 2018-08-08 22:20:12 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-08 22:20:12 --> Login MX_Controller Initialized
DEBUG - 2018-08-08 22:20:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-08 22:20:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-08-08 22:20:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-08-08 22:20:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-08-08 22:20:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-08-08 22:20:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-08-08 22:20:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/settings.php
INFO - 2018-08-08 22:20:12 --> Final output sent to browser
DEBUG - 2018-08-08 22:20:12 --> Total execution time: 0.5567
INFO - 2018-08-08 22:20:19 --> Config Class Initialized
INFO - 2018-08-08 22:20:19 --> Hooks Class Initialized
DEBUG - 2018-08-08 22:20:19 --> UTF-8 Support Enabled
INFO - 2018-08-08 22:20:19 --> Utf8 Class Initialized
INFO - 2018-08-08 22:20:19 --> URI Class Initialized
INFO - 2018-08-08 22:20:19 --> Router Class Initialized
INFO - 2018-08-08 22:20:19 --> Output Class Initialized
INFO - 2018-08-08 22:20:19 --> Security Class Initialized
DEBUG - 2018-08-08 22:20:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-08 22:20:19 --> Input Class Initialized
INFO - 2018-08-08 22:20:19 --> Language Class Initialized
INFO - 2018-08-08 22:20:19 --> Language Class Initialized
INFO - 2018-08-08 22:20:19 --> Config Class Initialized
INFO - 2018-08-08 22:20:19 --> Loader Class Initialized
DEBUG - 2018-08-08 22:20:19 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-08 22:20:19 --> Helper loaded: url_helper
INFO - 2018-08-08 22:20:19 --> Helper loaded: form_helper
INFO - 2018-08-08 22:20:19 --> Helper loaded: date_helper
INFO - 2018-08-08 22:20:19 --> Helper loaded: util_helper
INFO - 2018-08-08 22:20:19 --> Helper loaded: text_helper
INFO - 2018-08-08 22:20:19 --> Helper loaded: string_helper
INFO - 2018-08-08 22:20:19 --> Database Driver Class Initialized
DEBUG - 2018-08-08 22:20:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-08 22:20:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-08 22:20:19 --> Email Class Initialized
INFO - 2018-08-08 22:20:19 --> Controller Class Initialized
DEBUG - 2018-08-08 22:20:19 --> Login MX_Controller Initialized
INFO - 2018-08-08 22:20:19 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-08 22:20:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-08 22:20:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-08 22:20:19 --> 4 Loggedout
INFO - 2018-08-08 22:20:19 --> Config Class Initialized
INFO - 2018-08-08 22:20:19 --> Hooks Class Initialized
DEBUG - 2018-08-08 22:20:19 --> UTF-8 Support Enabled
INFO - 2018-08-08 22:20:19 --> Utf8 Class Initialized
INFO - 2018-08-08 22:20:19 --> URI Class Initialized
INFO - 2018-08-08 22:20:19 --> Router Class Initialized
INFO - 2018-08-08 22:20:19 --> Output Class Initialized
INFO - 2018-08-08 22:20:19 --> Security Class Initialized
DEBUG - 2018-08-08 22:20:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-08 22:20:19 --> Input Class Initialized
INFO - 2018-08-08 22:20:19 --> Language Class Initialized
INFO - 2018-08-08 22:20:19 --> Language Class Initialized
INFO - 2018-08-08 22:20:19 --> Config Class Initialized
INFO - 2018-08-08 22:20:19 --> Loader Class Initialized
DEBUG - 2018-08-08 22:20:19 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-08 22:20:19 --> Helper loaded: url_helper
INFO - 2018-08-08 22:20:19 --> Helper loaded: form_helper
INFO - 2018-08-08 22:20:19 --> Helper loaded: date_helper
INFO - 2018-08-08 22:20:19 --> Helper loaded: util_helper
INFO - 2018-08-08 22:20:19 --> Helper loaded: text_helper
INFO - 2018-08-08 22:20:19 --> Helper loaded: string_helper
INFO - 2018-08-08 22:20:19 --> Database Driver Class Initialized
DEBUG - 2018-08-08 22:20:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-08 22:20:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-08 22:20:20 --> Email Class Initialized
INFO - 2018-08-08 22:20:20 --> Controller Class Initialized
DEBUG - 2018-08-08 22:20:20 --> Home MX_Controller Initialized
DEBUG - 2018-08-08 22:20:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-08 22:20:20 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-08 22:20:20 --> Login MX_Controller Initialized
INFO - 2018-08-08 22:20:20 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-08 22:20:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-08 22:20:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-08 22:20:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Settings_model.php
DEBUG - 2018-08-08 22:20:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/login.php
