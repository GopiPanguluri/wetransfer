<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-08-09 00:33:44 --> Config Class Initialized
INFO - 2018-08-09 00:33:44 --> Hooks Class Initialized
DEBUG - 2018-08-09 00:33:44 --> UTF-8 Support Enabled
INFO - 2018-08-09 00:33:44 --> Utf8 Class Initialized
INFO - 2018-08-09 00:33:44 --> URI Class Initialized
INFO - 2018-08-09 00:33:44 --> Router Class Initialized
INFO - 2018-08-09 00:33:44 --> Output Class Initialized
INFO - 2018-08-09 00:33:44 --> Security Class Initialized
DEBUG - 2018-08-09 00:33:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-09 00:33:44 --> Input Class Initialized
INFO - 2018-08-09 00:33:44 --> Language Class Initialized
INFO - 2018-08-09 00:33:44 --> Language Class Initialized
INFO - 2018-08-09 00:33:44 --> Config Class Initialized
INFO - 2018-08-09 00:33:44 --> Loader Class Initialized
DEBUG - 2018-08-09 00:33:44 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-09 00:33:44 --> Helper loaded: url_helper
INFO - 2018-08-09 00:33:44 --> Helper loaded: form_helper
INFO - 2018-08-09 00:33:44 --> Helper loaded: date_helper
INFO - 2018-08-09 00:33:44 --> Helper loaded: util_helper
INFO - 2018-08-09 00:33:44 --> Helper loaded: text_helper
INFO - 2018-08-09 00:33:44 --> Helper loaded: string_helper
INFO - 2018-08-09 00:33:44 --> Database Driver Class Initialized
DEBUG - 2018-08-09 00:33:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-09 00:33:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-09 00:33:44 --> Email Class Initialized
INFO - 2018-08-09 00:33:44 --> Controller Class Initialized
DEBUG - 2018-08-09 00:33:44 --> Settings MX_Controller Initialized
INFO - 2018-08-09 00:33:44 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-09 00:33:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-09 00:33:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Settings_model.php
DEBUG - 2018-08-09 00:33:45 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-09 00:33:45 --> Login MX_Controller Initialized
DEBUG - 2018-08-09 00:33:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-09 00:33:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/logins/login.php
INFO - 2018-08-09 00:33:45 --> Config Class Initialized
INFO - 2018-08-09 00:33:45 --> Hooks Class Initialized
DEBUG - 2018-08-09 00:33:45 --> UTF-8 Support Enabled
INFO - 2018-08-09 00:33:45 --> Utf8 Class Initialized
INFO - 2018-08-09 00:33:45 --> URI Class Initialized
INFO - 2018-08-09 00:33:45 --> Router Class Initialized
INFO - 2018-08-09 00:33:45 --> Output Class Initialized
INFO - 2018-08-09 00:33:45 --> Security Class Initialized
DEBUG - 2018-08-09 00:33:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-09 00:33:45 --> Input Class Initialized
INFO - 2018-08-09 00:33:45 --> Language Class Initialized
ERROR - 2018-08-09 00:33:45 --> 404 Page Not Found: /index
INFO - 2018-08-09 00:33:48 --> Config Class Initialized
INFO - 2018-08-09 00:33:48 --> Hooks Class Initialized
DEBUG - 2018-08-09 00:33:48 --> UTF-8 Support Enabled
INFO - 2018-08-09 00:33:48 --> Utf8 Class Initialized
INFO - 2018-08-09 00:33:48 --> URI Class Initialized
INFO - 2018-08-09 00:33:48 --> Router Class Initialized
INFO - 2018-08-09 00:33:48 --> Output Class Initialized
INFO - 2018-08-09 00:33:48 --> Security Class Initialized
DEBUG - 2018-08-09 00:33:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-09 00:33:48 --> Input Class Initialized
INFO - 2018-08-09 00:33:48 --> Language Class Initialized
INFO - 2018-08-09 00:33:48 --> Language Class Initialized
INFO - 2018-08-09 00:33:48 --> Config Class Initialized
INFO - 2018-08-09 00:33:48 --> Loader Class Initialized
DEBUG - 2018-08-09 00:33:48 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-09 00:33:48 --> Helper loaded: url_helper
INFO - 2018-08-09 00:33:48 --> Helper loaded: form_helper
INFO - 2018-08-09 00:33:48 --> Helper loaded: date_helper
INFO - 2018-08-09 00:33:48 --> Helper loaded: util_helper
INFO - 2018-08-09 00:33:48 --> Helper loaded: text_helper
INFO - 2018-08-09 00:33:48 --> Helper loaded: string_helper
INFO - 2018-08-09 00:33:48 --> Database Driver Class Initialized
DEBUG - 2018-08-09 00:33:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-09 00:33:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-09 00:33:48 --> Email Class Initialized
INFO - 2018-08-09 00:33:48 --> Controller Class Initialized
DEBUG - 2018-08-09 00:33:48 --> Login MX_Controller Initialized
INFO - 2018-08-09 00:33:48 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-09 00:33:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-09 00:33:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-09 00:33:48 --> Email starts for colin-admin fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-08-09 00:33:48 --> User session created for 1
INFO - 2018-08-09 00:33:48 --> Login status colin-admin - success
INFO - 2018-08-09 00:33:48 --> Final output sent to browser
DEBUG - 2018-08-09 00:33:48 --> Total execution time: 0.3674
INFO - 2018-08-09 00:33:48 --> Config Class Initialized
INFO - 2018-08-09 00:33:48 --> Hooks Class Initialized
DEBUG - 2018-08-09 00:33:48 --> UTF-8 Support Enabled
INFO - 2018-08-09 00:33:48 --> Utf8 Class Initialized
INFO - 2018-08-09 00:33:48 --> URI Class Initialized
INFO - 2018-08-09 00:33:48 --> Router Class Initialized
INFO - 2018-08-09 00:33:48 --> Output Class Initialized
INFO - 2018-08-09 00:33:48 --> Security Class Initialized
DEBUG - 2018-08-09 00:33:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-09 00:33:48 --> Input Class Initialized
INFO - 2018-08-09 00:33:48 --> Language Class Initialized
INFO - 2018-08-09 00:33:48 --> Language Class Initialized
INFO - 2018-08-09 00:33:48 --> Config Class Initialized
INFO - 2018-08-09 00:33:48 --> Loader Class Initialized
DEBUG - 2018-08-09 00:33:48 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-09 00:33:48 --> Helper loaded: url_helper
INFO - 2018-08-09 00:33:48 --> Helper loaded: form_helper
INFO - 2018-08-09 00:33:48 --> Helper loaded: date_helper
INFO - 2018-08-09 00:33:48 --> Helper loaded: util_helper
INFO - 2018-08-09 00:33:48 --> Helper loaded: text_helper
INFO - 2018-08-09 00:33:48 --> Helper loaded: string_helper
INFO - 2018-08-09 00:33:48 --> Database Driver Class Initialized
DEBUG - 2018-08-09 00:33:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-09 00:33:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-09 00:33:48 --> Email Class Initialized
INFO - 2018-08-09 00:33:48 --> Controller Class Initialized
DEBUG - 2018-08-09 00:33:48 --> Settings MX_Controller Initialized
INFO - 2018-08-09 00:33:49 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-09 00:33:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-09 00:33:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Settings_model.php
DEBUG - 2018-08-09 00:33:49 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-09 00:33:49 --> Login MX_Controller Initialized
DEBUG - 2018-08-09 00:33:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-09 00:33:49 --> Config Class Initialized
INFO - 2018-08-09 00:33:49 --> Hooks Class Initialized
DEBUG - 2018-08-09 00:33:49 --> UTF-8 Support Enabled
INFO - 2018-08-09 00:33:49 --> Utf8 Class Initialized
INFO - 2018-08-09 00:33:49 --> URI Class Initialized
INFO - 2018-08-09 00:33:49 --> Router Class Initialized
INFO - 2018-08-09 00:33:49 --> Output Class Initialized
INFO - 2018-08-09 00:33:49 --> Security Class Initialized
DEBUG - 2018-08-09 00:33:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-09 00:33:49 --> Input Class Initialized
INFO - 2018-08-09 00:33:49 --> Language Class Initialized
INFO - 2018-08-09 00:33:49 --> Language Class Initialized
INFO - 2018-08-09 00:33:49 --> Config Class Initialized
INFO - 2018-08-09 00:33:49 --> Loader Class Initialized
DEBUG - 2018-08-09 00:33:49 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-09 00:33:49 --> Helper loaded: url_helper
INFO - 2018-08-09 00:33:49 --> Helper loaded: form_helper
INFO - 2018-08-09 00:33:49 --> Helper loaded: date_helper
INFO - 2018-08-09 00:33:49 --> Helper loaded: util_helper
INFO - 2018-08-09 00:33:49 --> Helper loaded: text_helper
INFO - 2018-08-09 00:33:49 --> Helper loaded: string_helper
INFO - 2018-08-09 00:33:49 --> Database Driver Class Initialized
DEBUG - 2018-08-09 00:33:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-09 00:33:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-09 00:33:49 --> Email Class Initialized
INFO - 2018-08-09 00:33:49 --> Controller Class Initialized
DEBUG - 2018-08-09 00:33:49 --> Settings MX_Controller Initialized
INFO - 2018-08-09 00:33:49 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-09 00:33:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-09 00:33:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Settings_model.php
DEBUG - 2018-08-09 00:33:49 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-09 00:33:49 --> Login MX_Controller Initialized
DEBUG - 2018-08-09 00:33:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-09 00:33:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-08-09 00:33:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-08-09 00:33:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-08-09 00:33:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
ERROR - 2018-08-09 00:33:49 --> Severity: Notice --> Undefined index: home_user_theme E:\xampp\htdocs\consulting\application\modules\common\views\common\js.php 77
DEBUG - 2018-08-09 00:33:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-08-09 00:33:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/settings.php
INFO - 2018-08-09 00:33:49 --> Final output sent to browser
DEBUG - 2018-08-09 00:33:49 --> Total execution time: 0.4061
INFO - 2018-08-09 00:33:56 --> Config Class Initialized
INFO - 2018-08-09 00:33:56 --> Hooks Class Initialized
DEBUG - 2018-08-09 00:33:56 --> UTF-8 Support Enabled
INFO - 2018-08-09 00:33:57 --> Utf8 Class Initialized
INFO - 2018-08-09 00:33:57 --> URI Class Initialized
INFO - 2018-08-09 00:33:57 --> Router Class Initialized
INFO - 2018-08-09 00:33:57 --> Output Class Initialized
INFO - 2018-08-09 00:33:57 --> Security Class Initialized
DEBUG - 2018-08-09 00:33:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-09 00:33:57 --> Input Class Initialized
INFO - 2018-08-09 00:33:57 --> Language Class Initialized
INFO - 2018-08-09 00:33:57 --> Language Class Initialized
INFO - 2018-08-09 00:33:57 --> Config Class Initialized
INFO - 2018-08-09 00:33:57 --> Loader Class Initialized
DEBUG - 2018-08-09 00:33:57 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-09 00:33:57 --> Helper loaded: url_helper
INFO - 2018-08-09 00:33:57 --> Helper loaded: form_helper
INFO - 2018-08-09 00:33:57 --> Helper loaded: date_helper
INFO - 2018-08-09 00:33:57 --> Helper loaded: util_helper
INFO - 2018-08-09 00:33:57 --> Helper loaded: text_helper
INFO - 2018-08-09 00:33:57 --> Helper loaded: string_helper
INFO - 2018-08-09 00:33:57 --> Database Driver Class Initialized
DEBUG - 2018-08-09 00:33:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-09 00:33:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-09 00:33:57 --> Email Class Initialized
INFO - 2018-08-09 00:33:57 --> Controller Class Initialized
DEBUG - 2018-08-09 00:33:57 --> Settings MX_Controller Initialized
INFO - 2018-08-09 00:33:57 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-09 00:33:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-09 00:33:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Settings_model.php
DEBUG - 2018-08-09 00:33:57 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-09 00:33:57 --> Login MX_Controller Initialized
DEBUG - 2018-08-09 00:33:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-09 00:33:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
INFO - 2018-08-09 00:33:57 --> Upload Class Initialized
INFO - 2018-08-09 00:33:57 --> Language file loaded: language/english/upload_lang.php
DEBUG - 2018-08-09 00:33:57 --> The filetype you are attempting to upload is not allowed.
INFO - 2018-08-09 00:33:57 --> Config Class Initialized
INFO - 2018-08-09 00:33:57 --> Hooks Class Initialized
DEBUG - 2018-08-09 00:33:57 --> UTF-8 Support Enabled
INFO - 2018-08-09 00:33:57 --> Utf8 Class Initialized
INFO - 2018-08-09 00:33:57 --> URI Class Initialized
INFO - 2018-08-09 00:33:57 --> Router Class Initialized
INFO - 2018-08-09 00:33:57 --> Output Class Initialized
INFO - 2018-08-09 00:33:57 --> Security Class Initialized
DEBUG - 2018-08-09 00:33:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-09 00:33:57 --> Input Class Initialized
INFO - 2018-08-09 00:33:57 --> Language Class Initialized
INFO - 2018-08-09 00:33:57 --> Language Class Initialized
INFO - 2018-08-09 00:33:57 --> Config Class Initialized
INFO - 2018-08-09 00:33:57 --> Loader Class Initialized
DEBUG - 2018-08-09 00:33:57 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-09 00:33:57 --> Helper loaded: url_helper
INFO - 2018-08-09 00:33:57 --> Helper loaded: form_helper
INFO - 2018-08-09 00:33:57 --> Helper loaded: date_helper
INFO - 2018-08-09 00:33:57 --> Helper loaded: util_helper
INFO - 2018-08-09 00:33:57 --> Helper loaded: text_helper
INFO - 2018-08-09 00:33:57 --> Helper loaded: string_helper
INFO - 2018-08-09 00:33:57 --> Database Driver Class Initialized
DEBUG - 2018-08-09 00:33:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-09 00:33:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-09 00:33:57 --> Email Class Initialized
INFO - 2018-08-09 00:33:57 --> Controller Class Initialized
DEBUG - 2018-08-09 00:33:57 --> Settings MX_Controller Initialized
INFO - 2018-08-09 00:33:57 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-09 00:33:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-09 00:33:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Settings_model.php
DEBUG - 2018-08-09 00:33:57 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-09 00:33:57 --> Login MX_Controller Initialized
DEBUG - 2018-08-09 00:33:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-09 00:33:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-08-09 00:33:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-08-09 00:33:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-08-09 00:33:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
ERROR - 2018-08-09 00:33:57 --> Severity: Notice --> Undefined index: home_user_theme E:\xampp\htdocs\consulting\application\modules\common\views\common\js.php 77
DEBUG - 2018-08-09 00:33:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-08-09 00:33:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/settings.php
INFO - 2018-08-09 00:33:57 --> Final output sent to browser
DEBUG - 2018-08-09 00:33:57 --> Total execution time: 0.3857
INFO - 2018-08-09 00:44:53 --> Config Class Initialized
INFO - 2018-08-09 00:44:53 --> Hooks Class Initialized
DEBUG - 2018-08-09 00:44:53 --> UTF-8 Support Enabled
INFO - 2018-08-09 00:44:53 --> Utf8 Class Initialized
INFO - 2018-08-09 00:44:53 --> URI Class Initialized
INFO - 2018-08-09 00:44:53 --> Router Class Initialized
INFO - 2018-08-09 00:44:53 --> Output Class Initialized
INFO - 2018-08-09 00:44:53 --> Security Class Initialized
DEBUG - 2018-08-09 00:44:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-09 00:44:53 --> Input Class Initialized
INFO - 2018-08-09 00:44:53 --> Language Class Initialized
INFO - 2018-08-09 00:44:53 --> Language Class Initialized
INFO - 2018-08-09 00:44:53 --> Config Class Initialized
INFO - 2018-08-09 00:44:53 --> Loader Class Initialized
DEBUG - 2018-08-09 00:44:53 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-09 00:44:53 --> Helper loaded: url_helper
INFO - 2018-08-09 00:44:53 --> Helper loaded: form_helper
INFO - 2018-08-09 00:44:53 --> Helper loaded: date_helper
INFO - 2018-08-09 00:44:53 --> Helper loaded: util_helper
INFO - 2018-08-09 00:44:53 --> Helper loaded: text_helper
INFO - 2018-08-09 00:44:53 --> Helper loaded: string_helper
INFO - 2018-08-09 00:44:53 --> Database Driver Class Initialized
DEBUG - 2018-08-09 00:44:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-09 00:44:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-09 00:44:53 --> Email Class Initialized
INFO - 2018-08-09 00:44:53 --> Controller Class Initialized
DEBUG - 2018-08-09 00:44:53 --> Settings MX_Controller Initialized
INFO - 2018-08-09 00:44:53 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-09 00:44:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-09 00:44:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Settings_model.php
DEBUG - 2018-08-09 00:44:53 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-09 00:44:53 --> Login MX_Controller Initialized
DEBUG - 2018-08-09 00:44:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-09 00:44:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
INFO - 2018-08-09 00:44:53 --> Upload Class Initialized
INFO - 2018-08-09 00:44:53 --> Language file loaded: language/english/upload_lang.php
DEBUG - 2018-08-09 00:44:53 --> The filetype you are attempting to upload is not allowed.
INFO - 2018-08-09 00:44:53 --> Config Class Initialized
INFO - 2018-08-09 00:44:53 --> Hooks Class Initialized
DEBUG - 2018-08-09 00:44:53 --> UTF-8 Support Enabled
INFO - 2018-08-09 00:44:53 --> Utf8 Class Initialized
INFO - 2018-08-09 00:44:53 --> URI Class Initialized
INFO - 2018-08-09 00:44:53 --> Router Class Initialized
INFO - 2018-08-09 00:44:53 --> Output Class Initialized
INFO - 2018-08-09 00:44:53 --> Security Class Initialized
DEBUG - 2018-08-09 00:44:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-09 00:44:53 --> Input Class Initialized
INFO - 2018-08-09 00:44:53 --> Language Class Initialized
INFO - 2018-08-09 00:44:53 --> Language Class Initialized
INFO - 2018-08-09 00:44:53 --> Config Class Initialized
INFO - 2018-08-09 00:44:53 --> Loader Class Initialized
DEBUG - 2018-08-09 00:44:54 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-09 00:44:54 --> Helper loaded: url_helper
INFO - 2018-08-09 00:44:54 --> Helper loaded: form_helper
INFO - 2018-08-09 00:44:54 --> Helper loaded: date_helper
INFO - 2018-08-09 00:44:54 --> Helper loaded: util_helper
INFO - 2018-08-09 00:44:54 --> Helper loaded: text_helper
INFO - 2018-08-09 00:44:54 --> Helper loaded: string_helper
INFO - 2018-08-09 00:44:54 --> Database Driver Class Initialized
DEBUG - 2018-08-09 00:44:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-09 00:44:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-09 00:44:54 --> Email Class Initialized
INFO - 2018-08-09 00:44:54 --> Controller Class Initialized
DEBUG - 2018-08-09 00:44:54 --> Settings MX_Controller Initialized
INFO - 2018-08-09 00:44:54 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-09 00:44:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-09 00:44:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Settings_model.php
DEBUG - 2018-08-09 00:44:54 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-09 00:44:54 --> Login MX_Controller Initialized
DEBUG - 2018-08-09 00:44:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-09 00:44:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-08-09 00:44:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-08-09 00:44:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-08-09 00:44:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
ERROR - 2018-08-09 00:44:54 --> Severity: Notice --> Undefined index: home_user_theme E:\xampp\htdocs\consulting\application\modules\common\views\common\js.php 77
DEBUG - 2018-08-09 00:44:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-08-09 00:44:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/settings.php
INFO - 2018-08-09 00:44:54 --> Final output sent to browser
DEBUG - 2018-08-09 00:44:54 --> Total execution time: 0.3917
INFO - 2018-08-09 00:44:58 --> Config Class Initialized
INFO - 2018-08-09 00:44:58 --> Hooks Class Initialized
DEBUG - 2018-08-09 00:44:58 --> UTF-8 Support Enabled
INFO - 2018-08-09 00:44:58 --> Utf8 Class Initialized
INFO - 2018-08-09 00:44:58 --> URI Class Initialized
INFO - 2018-08-09 00:44:58 --> Router Class Initialized
INFO - 2018-08-09 00:44:58 --> Output Class Initialized
INFO - 2018-08-09 00:44:58 --> Security Class Initialized
DEBUG - 2018-08-09 00:44:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-09 00:44:58 --> Input Class Initialized
INFO - 2018-08-09 00:44:58 --> Language Class Initialized
INFO - 2018-08-09 00:44:58 --> Language Class Initialized
INFO - 2018-08-09 00:44:58 --> Config Class Initialized
INFO - 2018-08-09 00:44:58 --> Loader Class Initialized
DEBUG - 2018-08-09 00:44:58 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-09 00:44:58 --> Helper loaded: url_helper
INFO - 2018-08-09 00:44:58 --> Helper loaded: form_helper
INFO - 2018-08-09 00:44:58 --> Helper loaded: date_helper
INFO - 2018-08-09 00:44:58 --> Helper loaded: util_helper
INFO - 2018-08-09 00:44:58 --> Helper loaded: text_helper
INFO - 2018-08-09 00:44:58 --> Helper loaded: string_helper
INFO - 2018-08-09 00:44:58 --> Database Driver Class Initialized
DEBUG - 2018-08-09 00:44:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-09 00:44:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-09 00:44:58 --> Email Class Initialized
INFO - 2018-08-09 00:44:58 --> Controller Class Initialized
DEBUG - 2018-08-09 00:44:58 --> Settings MX_Controller Initialized
INFO - 2018-08-09 00:44:58 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-09 00:44:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-09 00:44:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Settings_model.php
DEBUG - 2018-08-09 00:44:58 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-09 00:44:58 --> Login MX_Controller Initialized
DEBUG - 2018-08-09 00:44:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-09 00:44:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-08-09 00:44:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-08-09 00:44:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-08-09 00:44:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
ERROR - 2018-08-09 00:44:58 --> Severity: Notice --> Undefined index: home_user_theme E:\xampp\htdocs\consulting\application\modules\common\views\common\js.php 77
DEBUG - 2018-08-09 00:44:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-08-09 00:44:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/settings.php
INFO - 2018-08-09 00:44:58 --> Final output sent to browser
DEBUG - 2018-08-09 00:44:58 --> Total execution time: 0.4726
INFO - 2018-08-09 00:45:06 --> Config Class Initialized
INFO - 2018-08-09 00:45:06 --> Hooks Class Initialized
DEBUG - 2018-08-09 00:45:06 --> UTF-8 Support Enabled
INFO - 2018-08-09 00:45:06 --> Utf8 Class Initialized
INFO - 2018-08-09 00:45:06 --> URI Class Initialized
INFO - 2018-08-09 00:45:06 --> Router Class Initialized
INFO - 2018-08-09 00:45:06 --> Output Class Initialized
INFO - 2018-08-09 00:45:06 --> Security Class Initialized
DEBUG - 2018-08-09 00:45:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-09 00:45:06 --> Input Class Initialized
INFO - 2018-08-09 00:45:06 --> Language Class Initialized
INFO - 2018-08-09 00:45:06 --> Language Class Initialized
INFO - 2018-08-09 00:45:06 --> Config Class Initialized
INFO - 2018-08-09 00:45:06 --> Loader Class Initialized
DEBUG - 2018-08-09 00:45:06 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-09 00:45:06 --> Helper loaded: url_helper
INFO - 2018-08-09 00:45:06 --> Helper loaded: form_helper
INFO - 2018-08-09 00:45:06 --> Helper loaded: date_helper
INFO - 2018-08-09 00:45:06 --> Helper loaded: util_helper
INFO - 2018-08-09 00:45:06 --> Helper loaded: text_helper
INFO - 2018-08-09 00:45:06 --> Helper loaded: string_helper
INFO - 2018-08-09 00:45:06 --> Database Driver Class Initialized
DEBUG - 2018-08-09 00:45:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-09 00:45:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-09 00:45:06 --> Email Class Initialized
INFO - 2018-08-09 00:45:06 --> Controller Class Initialized
DEBUG - 2018-08-09 00:45:06 --> Settings MX_Controller Initialized
INFO - 2018-08-09 00:45:06 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-09 00:45:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-09 00:45:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Settings_model.php
DEBUG - 2018-08-09 00:45:06 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-09 00:45:06 --> Login MX_Controller Initialized
DEBUG - 2018-08-09 00:45:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-09 00:45:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
INFO - 2018-08-09 00:45:06 --> Upload Class Initialized
INFO - 2018-08-09 00:45:06 --> Language file loaded: language/english/upload_lang.php
DEBUG - 2018-08-09 00:45:06 --> The filetype you are attempting to upload is not allowed.
INFO - 2018-08-09 00:45:06 --> Config Class Initialized
INFO - 2018-08-09 00:45:06 --> Hooks Class Initialized
DEBUG - 2018-08-09 00:45:06 --> UTF-8 Support Enabled
INFO - 2018-08-09 00:45:06 --> Utf8 Class Initialized
INFO - 2018-08-09 00:45:06 --> URI Class Initialized
INFO - 2018-08-09 00:45:06 --> Router Class Initialized
INFO - 2018-08-09 00:45:06 --> Output Class Initialized
INFO - 2018-08-09 00:45:06 --> Security Class Initialized
DEBUG - 2018-08-09 00:45:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-09 00:45:06 --> Input Class Initialized
INFO - 2018-08-09 00:45:06 --> Language Class Initialized
INFO - 2018-08-09 00:45:06 --> Language Class Initialized
INFO - 2018-08-09 00:45:06 --> Config Class Initialized
INFO - 2018-08-09 00:45:06 --> Loader Class Initialized
DEBUG - 2018-08-09 00:45:06 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-09 00:45:06 --> Helper loaded: url_helper
INFO - 2018-08-09 00:45:06 --> Helper loaded: form_helper
INFO - 2018-08-09 00:45:06 --> Helper loaded: date_helper
INFO - 2018-08-09 00:45:06 --> Helper loaded: util_helper
INFO - 2018-08-09 00:45:06 --> Helper loaded: text_helper
INFO - 2018-08-09 00:45:06 --> Helper loaded: string_helper
INFO - 2018-08-09 00:45:06 --> Database Driver Class Initialized
DEBUG - 2018-08-09 00:45:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-09 00:45:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-09 00:45:06 --> Email Class Initialized
INFO - 2018-08-09 00:45:06 --> Controller Class Initialized
DEBUG - 2018-08-09 00:45:06 --> Settings MX_Controller Initialized
INFO - 2018-08-09 00:45:06 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-09 00:45:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-09 00:45:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Settings_model.php
DEBUG - 2018-08-09 00:45:07 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-09 00:45:07 --> Login MX_Controller Initialized
DEBUG - 2018-08-09 00:45:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-09 00:45:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-08-09 00:45:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-08-09 00:45:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-08-09 00:45:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
ERROR - 2018-08-09 00:45:07 --> Severity: Notice --> Undefined index: home_user_theme E:\xampp\htdocs\consulting\application\modules\common\views\common\js.php 77
DEBUG - 2018-08-09 00:45:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-08-09 00:45:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/settings.php
INFO - 2018-08-09 00:45:07 --> Final output sent to browser
DEBUG - 2018-08-09 00:45:07 --> Total execution time: 0.4004
INFO - 2018-08-09 22:40:25 --> Config Class Initialized
INFO - 2018-08-09 22:40:25 --> Hooks Class Initialized
DEBUG - 2018-08-09 22:40:25 --> UTF-8 Support Enabled
INFO - 2018-08-09 22:40:25 --> Utf8 Class Initialized
INFO - 2018-08-09 22:40:25 --> URI Class Initialized
INFO - 2018-08-09 22:40:25 --> Router Class Initialized
INFO - 2018-08-09 22:40:25 --> Output Class Initialized
INFO - 2018-08-09 22:40:25 --> Security Class Initialized
DEBUG - 2018-08-09 22:40:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-09 22:40:25 --> Input Class Initialized
INFO - 2018-08-09 22:40:26 --> Language Class Initialized
INFO - 2018-08-09 22:40:26 --> Language Class Initialized
INFO - 2018-08-09 22:40:26 --> Config Class Initialized
INFO - 2018-08-09 22:40:26 --> Loader Class Initialized
DEBUG - 2018-08-09 22:40:26 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-09 22:40:26 --> Helper loaded: url_helper
INFO - 2018-08-09 22:40:26 --> Helper loaded: form_helper
INFO - 2018-08-09 22:40:26 --> Helper loaded: date_helper
INFO - 2018-08-09 22:40:26 --> Helper loaded: util_helper
INFO - 2018-08-09 22:40:26 --> Helper loaded: text_helper
INFO - 2018-08-09 22:40:26 --> Helper loaded: string_helper
INFO - 2018-08-09 22:40:26 --> Database Driver Class Initialized
DEBUG - 2018-08-09 22:40:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-09 22:40:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-09 22:40:26 --> Email Class Initialized
INFO - 2018-08-09 22:40:26 --> Controller Class Initialized
DEBUG - 2018-08-09 22:40:26 --> Settings MX_Controller Initialized
INFO - 2018-08-09 22:40:26 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-09 22:40:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-09 22:40:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Settings_model.php
DEBUG - 2018-08-09 22:40:26 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-09 22:40:26 --> Login MX_Controller Initialized
DEBUG - 2018-08-09 22:40:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-09 22:40:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/logins/login.php
INFO - 2018-08-09 22:40:26 --> Config Class Initialized
INFO - 2018-08-09 22:40:26 --> Hooks Class Initialized
DEBUG - 2018-08-09 22:40:26 --> UTF-8 Support Enabled
INFO - 2018-08-09 22:40:26 --> Utf8 Class Initialized
INFO - 2018-08-09 22:40:26 --> URI Class Initialized
INFO - 2018-08-09 22:40:26 --> Router Class Initialized
INFO - 2018-08-09 22:40:26 --> Output Class Initialized
INFO - 2018-08-09 22:40:26 --> Security Class Initialized
DEBUG - 2018-08-09 22:40:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-09 22:40:26 --> Input Class Initialized
INFO - 2018-08-09 22:40:26 --> Language Class Initialized
ERROR - 2018-08-09 22:40:26 --> 404 Page Not Found: /index
INFO - 2018-08-09 22:40:26 --> Config Class Initialized
INFO - 2018-08-09 22:40:26 --> Hooks Class Initialized
DEBUG - 2018-08-09 22:40:26 --> UTF-8 Support Enabled
INFO - 2018-08-09 22:40:26 --> Utf8 Class Initialized
INFO - 2018-08-09 22:40:26 --> URI Class Initialized
INFO - 2018-08-09 22:40:26 --> Router Class Initialized
INFO - 2018-08-09 22:40:26 --> Output Class Initialized
INFO - 2018-08-09 22:40:26 --> Security Class Initialized
DEBUG - 2018-08-09 22:40:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-09 22:40:26 --> Input Class Initialized
INFO - 2018-08-09 22:40:26 --> Language Class Initialized
ERROR - 2018-08-09 22:40:26 --> 404 Page Not Found: /index
INFO - 2018-08-09 22:40:27 --> Config Class Initialized
INFO - 2018-08-09 22:40:27 --> Hooks Class Initialized
DEBUG - 2018-08-09 22:40:27 --> UTF-8 Support Enabled
INFO - 2018-08-09 22:40:27 --> Utf8 Class Initialized
INFO - 2018-08-09 22:40:27 --> URI Class Initialized
INFO - 2018-08-09 22:40:27 --> Router Class Initialized
INFO - 2018-08-09 22:40:27 --> Output Class Initialized
INFO - 2018-08-09 22:40:27 --> Security Class Initialized
DEBUG - 2018-08-09 22:40:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-09 22:40:27 --> Input Class Initialized
INFO - 2018-08-09 22:40:27 --> Language Class Initialized
INFO - 2018-08-09 22:40:27 --> Language Class Initialized
INFO - 2018-08-09 22:40:27 --> Config Class Initialized
INFO - 2018-08-09 22:40:27 --> Loader Class Initialized
DEBUG - 2018-08-09 22:40:27 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-09 22:40:27 --> Helper loaded: url_helper
INFO - 2018-08-09 22:40:27 --> Helper loaded: form_helper
INFO - 2018-08-09 22:40:27 --> Helper loaded: date_helper
INFO - 2018-08-09 22:40:27 --> Helper loaded: util_helper
INFO - 2018-08-09 22:40:27 --> Helper loaded: text_helper
INFO - 2018-08-09 22:40:27 --> Helper loaded: string_helper
INFO - 2018-08-09 22:40:27 --> Database Driver Class Initialized
DEBUG - 2018-08-09 22:40:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-09 22:40:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-09 22:40:27 --> Email Class Initialized
INFO - 2018-08-09 22:40:27 --> Controller Class Initialized
DEBUG - 2018-08-09 22:40:27 --> Home MX_Controller Initialized
DEBUG - 2018-08-09 22:40:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-09 22:40:27 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-09 22:40:27 --> Login MX_Controller Initialized
INFO - 2018-08-09 22:40:27 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-09 22:40:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-09 22:40:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-09 22:40:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Settings_model.php
DEBUG - 2018-08-09 22:40:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/login.php
INFO - 2018-08-09 22:50:47 --> Config Class Initialized
INFO - 2018-08-09 22:50:47 --> Hooks Class Initialized
DEBUG - 2018-08-09 22:50:47 --> UTF-8 Support Enabled
INFO - 2018-08-09 22:50:47 --> Utf8 Class Initialized
INFO - 2018-08-09 22:50:47 --> URI Class Initialized
INFO - 2018-08-09 22:50:47 --> Router Class Initialized
INFO - 2018-08-09 22:50:47 --> Output Class Initialized
INFO - 2018-08-09 22:50:47 --> Security Class Initialized
DEBUG - 2018-08-09 22:50:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-09 22:50:47 --> Input Class Initialized
INFO - 2018-08-09 22:50:47 --> Language Class Initialized
INFO - 2018-08-09 22:50:47 --> Language Class Initialized
INFO - 2018-08-09 22:50:47 --> Config Class Initialized
INFO - 2018-08-09 22:50:47 --> Loader Class Initialized
DEBUG - 2018-08-09 22:50:47 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-09 22:50:47 --> Helper loaded: url_helper
INFO - 2018-08-09 22:50:47 --> Helper loaded: form_helper
INFO - 2018-08-09 22:50:47 --> Helper loaded: date_helper
INFO - 2018-08-09 22:50:47 --> Helper loaded: util_helper
INFO - 2018-08-09 22:50:47 --> Helper loaded: text_helper
INFO - 2018-08-09 22:50:47 --> Helper loaded: string_helper
INFO - 2018-08-09 22:50:47 --> Database Driver Class Initialized
DEBUG - 2018-08-09 22:50:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-09 22:50:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-09 22:50:47 --> Email Class Initialized
INFO - 2018-08-09 22:50:47 --> Controller Class Initialized
DEBUG - 2018-08-09 22:50:47 --> Home MX_Controller Initialized
DEBUG - 2018-08-09 22:50:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-09 22:50:47 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-09 22:50:47 --> Login MX_Controller Initialized
INFO - 2018-08-09 22:50:47 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-09 22:50:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-09 22:50:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-09 22:50:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Settings_model.php
DEBUG - 2018-08-09 22:50:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/login.php
INFO - 2018-08-09 22:50:48 --> Config Class Initialized
INFO - 2018-08-09 22:50:48 --> Hooks Class Initialized
DEBUG - 2018-08-09 22:50:48 --> UTF-8 Support Enabled
INFO - 2018-08-09 22:50:48 --> Utf8 Class Initialized
INFO - 2018-08-09 22:50:48 --> URI Class Initialized
INFO - 2018-08-09 22:50:48 --> Router Class Initialized
INFO - 2018-08-09 22:50:48 --> Output Class Initialized
INFO - 2018-08-09 22:50:48 --> Security Class Initialized
DEBUG - 2018-08-09 22:50:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-09 22:50:48 --> Input Class Initialized
INFO - 2018-08-09 22:50:48 --> Language Class Initialized
INFO - 2018-08-09 22:50:48 --> Language Class Initialized
INFO - 2018-08-09 22:50:48 --> Config Class Initialized
INFO - 2018-08-09 22:50:48 --> Loader Class Initialized
DEBUG - 2018-08-09 22:50:48 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-09 22:50:48 --> Helper loaded: url_helper
INFO - 2018-08-09 22:50:48 --> Helper loaded: form_helper
INFO - 2018-08-09 22:50:48 --> Helper loaded: date_helper
INFO - 2018-08-09 22:50:48 --> Helper loaded: util_helper
INFO - 2018-08-09 22:50:48 --> Helper loaded: text_helper
INFO - 2018-08-09 22:50:48 --> Helper loaded: string_helper
INFO - 2018-08-09 22:50:48 --> Database Driver Class Initialized
DEBUG - 2018-08-09 22:50:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-09 22:50:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-09 22:50:48 --> Email Class Initialized
INFO - 2018-08-09 22:50:48 --> Controller Class Initialized
DEBUG - 2018-08-09 22:50:48 --> Settings MX_Controller Initialized
INFO - 2018-08-09 22:50:48 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-09 22:50:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-09 22:50:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Settings_model.php
DEBUG - 2018-08-09 22:50:48 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-09 22:50:48 --> Login MX_Controller Initialized
DEBUG - 2018-08-09 22:50:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-09 22:50:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/logins/login.php
INFO - 2018-08-09 22:50:57 --> Config Class Initialized
INFO - 2018-08-09 22:50:57 --> Hooks Class Initialized
DEBUG - 2018-08-09 22:50:57 --> UTF-8 Support Enabled
INFO - 2018-08-09 22:50:57 --> Utf8 Class Initialized
INFO - 2018-08-09 22:50:57 --> URI Class Initialized
INFO - 2018-08-09 22:50:57 --> Router Class Initialized
INFO - 2018-08-09 22:50:57 --> Output Class Initialized
INFO - 2018-08-09 22:50:57 --> Security Class Initialized
DEBUG - 2018-08-09 22:50:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-09 22:50:57 --> Input Class Initialized
INFO - 2018-08-09 22:50:57 --> Language Class Initialized
INFO - 2018-08-09 22:50:57 --> Language Class Initialized
INFO - 2018-08-09 22:50:57 --> Config Class Initialized
INFO - 2018-08-09 22:50:57 --> Loader Class Initialized
DEBUG - 2018-08-09 22:50:57 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-09 22:50:57 --> Helper loaded: url_helper
INFO - 2018-08-09 22:50:57 --> Helper loaded: form_helper
INFO - 2018-08-09 22:50:57 --> Helper loaded: date_helper
INFO - 2018-08-09 22:50:57 --> Helper loaded: util_helper
INFO - 2018-08-09 22:50:57 --> Helper loaded: text_helper
INFO - 2018-08-09 22:50:57 --> Helper loaded: string_helper
INFO - 2018-08-09 22:50:57 --> Database Driver Class Initialized
DEBUG - 2018-08-09 22:50:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-09 22:50:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-09 22:50:57 --> Email Class Initialized
INFO - 2018-08-09 22:50:57 --> Controller Class Initialized
DEBUG - 2018-08-09 22:50:57 --> Login MX_Controller Initialized
INFO - 2018-08-09 22:50:57 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-09 22:50:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-09 22:50:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-09 22:50:57 --> Email starts for colinUser fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-08-09 22:50:57 --> User session created for 4
INFO - 2018-08-09 22:50:57 --> Login status colinUser - success
INFO - 2018-08-09 22:50:57 --> Final output sent to browser
DEBUG - 2018-08-09 22:50:57 --> Total execution time: 0.3797
INFO - 2018-08-09 22:50:57 --> Config Class Initialized
INFO - 2018-08-09 22:50:57 --> Hooks Class Initialized
DEBUG - 2018-08-09 22:50:57 --> UTF-8 Support Enabled
INFO - 2018-08-09 22:50:57 --> Utf8 Class Initialized
INFO - 2018-08-09 22:50:57 --> URI Class Initialized
INFO - 2018-08-09 22:50:57 --> Router Class Initialized
INFO - 2018-08-09 22:50:57 --> Output Class Initialized
INFO - 2018-08-09 22:50:57 --> Security Class Initialized
DEBUG - 2018-08-09 22:50:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-09 22:50:57 --> Input Class Initialized
INFO - 2018-08-09 22:50:57 --> Language Class Initialized
INFO - 2018-08-09 22:50:57 --> Language Class Initialized
INFO - 2018-08-09 22:50:58 --> Config Class Initialized
INFO - 2018-08-09 22:50:58 --> Loader Class Initialized
DEBUG - 2018-08-09 22:50:58 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-09 22:50:58 --> Helper loaded: url_helper
INFO - 2018-08-09 22:50:58 --> Helper loaded: form_helper
INFO - 2018-08-09 22:50:58 --> Helper loaded: date_helper
INFO - 2018-08-09 22:50:58 --> Helper loaded: util_helper
INFO - 2018-08-09 22:50:58 --> Helper loaded: text_helper
INFO - 2018-08-09 22:50:58 --> Helper loaded: string_helper
INFO - 2018-08-09 22:50:58 --> Database Driver Class Initialized
DEBUG - 2018-08-09 22:50:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-09 22:50:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-09 22:50:58 --> Email Class Initialized
INFO - 2018-08-09 22:50:58 --> Controller Class Initialized
DEBUG - 2018-08-09 22:50:58 --> Home MX_Controller Initialized
DEBUG - 2018-08-09 22:50:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-09 22:50:58 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-09 22:50:58 --> Login MX_Controller Initialized
INFO - 2018-08-09 22:50:58 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-09 22:50:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-09 22:50:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-09 22:50:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-08-09 22:50:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-08-09 22:50:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-08-09 22:50:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-08-09 22:50:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-08-09 22:50:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-08-09 22:50:58 --> Final output sent to browser
DEBUG - 2018-08-09 22:50:58 --> Total execution time: 0.5308
INFO - 2018-08-09 22:50:59 --> Config Class Initialized
INFO - 2018-08-09 22:50:59 --> Hooks Class Initialized
DEBUG - 2018-08-09 22:50:59 --> UTF-8 Support Enabled
INFO - 2018-08-09 22:50:59 --> Utf8 Class Initialized
INFO - 2018-08-09 22:50:59 --> URI Class Initialized
INFO - 2018-08-09 22:50:59 --> Router Class Initialized
INFO - 2018-08-09 22:50:59 --> Output Class Initialized
INFO - 2018-08-09 22:50:59 --> Config Class Initialized
INFO - 2018-08-09 22:50:59 --> Hooks Class Initialized
INFO - 2018-08-09 22:50:59 --> Security Class Initialized
DEBUG - 2018-08-09 22:50:59 --> UTF-8 Support Enabled
INFO - 2018-08-09 22:50:59 --> Utf8 Class Initialized
INFO - 2018-08-09 22:50:59 --> URI Class Initialized
INFO - 2018-08-09 22:50:59 --> Router Class Initialized
DEBUG - 2018-08-09 22:50:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-09 22:50:59 --> Output Class Initialized
INFO - 2018-08-09 22:50:59 --> Input Class Initialized
INFO - 2018-08-09 22:50:59 --> Security Class Initialized
DEBUG - 2018-08-09 22:50:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-09 22:50:59 --> Language Class Initialized
INFO - 2018-08-09 22:50:59 --> Input Class Initialized
INFO - 2018-08-09 22:50:59 --> Language Class Initialized
INFO - 2018-08-09 22:50:59 --> Language Class Initialized
ERROR - 2018-08-09 22:50:59 --> 404 Page Not Found: /index
INFO - 2018-08-09 22:50:59 --> Config Class Initialized
INFO - 2018-08-09 22:50:59 --> Loader Class Initialized
DEBUG - 2018-08-09 22:50:59 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-09 22:50:59 --> Helper loaded: url_helper
INFO - 2018-08-09 22:50:59 --> Helper loaded: form_helper
INFO - 2018-08-09 22:50:59 --> Helper loaded: date_helper
INFO - 2018-08-09 22:50:59 --> Helper loaded: util_helper
INFO - 2018-08-09 22:50:59 --> Helper loaded: text_helper
INFO - 2018-08-09 22:50:59 --> Helper loaded: string_helper
INFO - 2018-08-09 22:50:59 --> Database Driver Class Initialized
INFO - 2018-08-09 22:50:59 --> Config Class Initialized
INFO - 2018-08-09 22:50:59 --> Hooks Class Initialized
DEBUG - 2018-08-09 22:51:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-08-09 22:51:00 --> UTF-8 Support Enabled
INFO - 2018-08-09 22:51:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-09 22:51:00 --> Utf8 Class Initialized
INFO - 2018-08-09 22:51:00 --> Email Class Initialized
INFO - 2018-08-09 22:51:00 --> Controller Class Initialized
INFO - 2018-08-09 22:51:00 --> URI Class Initialized
DEBUG - 2018-08-09 22:51:00 --> Home MX_Controller Initialized
INFO - 2018-08-09 22:51:00 --> Router Class Initialized
DEBUG - 2018-08-09 22:51:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-08-09 22:51:00 --> Output Class Initialized
INFO - 2018-08-09 22:51:00 --> Security Class Initialized
DEBUG - 2018-08-09 22:51:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-09 22:51:00 --> Input Class Initialized
INFO - 2018-08-09 22:51:00 --> Language Class Initialized
ERROR - 2018-08-09 22:51:00 --> 404 Page Not Found: /index
INFO - 2018-08-09 22:51:00 --> Config Class Initialized
INFO - 2018-08-09 22:51:00 --> Hooks Class Initialized
DEBUG - 2018-08-09 22:51:00 --> UTF-8 Support Enabled
INFO - 2018-08-09 22:51:00 --> Utf8 Class Initialized
INFO - 2018-08-09 22:51:00 --> URI Class Initialized
INFO - 2018-08-09 22:51:00 --> Router Class Initialized
INFO - 2018-08-09 22:51:00 --> Config Class Initialized
INFO - 2018-08-09 22:51:00 --> Output Class Initialized
INFO - 2018-08-09 22:51:00 --> Hooks Class Initialized
DEBUG - 2018-08-09 22:51:00 --> UTF-8 Support Enabled
INFO - 2018-08-09 22:51:00 --> Security Class Initialized
INFO - 2018-08-09 22:51:00 --> Utf8 Class Initialized
INFO - 2018-08-09 22:51:00 --> URI Class Initialized
INFO - 2018-08-09 22:51:00 --> Router Class Initialized
DEBUG - 2018-08-09 22:51:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-09 22:51:00 --> Input Class Initialized
INFO - 2018-08-09 22:51:00 --> Output Class Initialized
INFO - 2018-08-09 22:51:00 --> Language Class Initialized
INFO - 2018-08-09 22:51:00 --> Security Class Initialized
DEBUG - 2018-08-09 22:51:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-08-09 22:51:00 --> 404 Page Not Found: /index
INFO - 2018-08-09 22:51:00 --> Input Class Initialized
INFO - 2018-08-09 22:51:00 --> Language Class Initialized
ERROR - 2018-08-09 22:51:00 --> 404 Page Not Found: /index
INFO - 2018-08-09 22:51:00 --> Config Class Initialized
INFO - 2018-08-09 22:51:00 --> Hooks Class Initialized
DEBUG - 2018-08-09 22:51:00 --> UTF-8 Support Enabled
INFO - 2018-08-09 22:51:00 --> Utf8 Class Initialized
INFO - 2018-08-09 22:51:00 --> URI Class Initialized
INFO - 2018-08-09 22:51:00 --> Router Class Initialized
INFO - 2018-08-09 22:51:00 --> Output Class Initialized
INFO - 2018-08-09 22:51:00 --> Security Class Initialized
DEBUG - 2018-08-09 22:51:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-09 22:51:00 --> Input Class Initialized
INFO - 2018-08-09 22:51:00 --> Language Class Initialized
ERROR - 2018-08-09 22:51:00 --> 404 Page Not Found: /index
INFO - 2018-08-09 22:51:01 --> Config Class Initialized
INFO - 2018-08-09 22:51:01 --> Hooks Class Initialized
DEBUG - 2018-08-09 22:51:01 --> UTF-8 Support Enabled
INFO - 2018-08-09 22:51:01 --> Utf8 Class Initialized
INFO - 2018-08-09 22:51:01 --> URI Class Initialized
INFO - 2018-08-09 22:51:01 --> Router Class Initialized
INFO - 2018-08-09 22:51:01 --> Output Class Initialized
INFO - 2018-08-09 22:51:01 --> Security Class Initialized
DEBUG - 2018-08-09 22:51:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-09 22:51:01 --> Input Class Initialized
INFO - 2018-08-09 22:51:01 --> Language Class Initialized
ERROR - 2018-08-09 22:51:01 --> 404 Page Not Found: /index
INFO - 2018-08-09 22:51:01 --> Config Class Initialized
INFO - 2018-08-09 22:51:01 --> Hooks Class Initialized
DEBUG - 2018-08-09 22:51:01 --> UTF-8 Support Enabled
INFO - 2018-08-09 22:51:01 --> Utf8 Class Initialized
INFO - 2018-08-09 22:51:01 --> URI Class Initialized
INFO - 2018-08-09 22:51:01 --> Router Class Initialized
INFO - 2018-08-09 22:51:01 --> Output Class Initialized
INFO - 2018-08-09 22:51:01 --> Security Class Initialized
DEBUG - 2018-08-09 22:51:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-09 22:51:01 --> Input Class Initialized
INFO - 2018-08-09 22:51:01 --> Language Class Initialized
ERROR - 2018-08-09 22:51:01 --> 404 Page Not Found: /index
INFO - 2018-08-09 22:51:01 --> Config Class Initialized
INFO - 2018-08-09 22:51:01 --> Hooks Class Initialized
DEBUG - 2018-08-09 22:51:01 --> UTF-8 Support Enabled
INFO - 2018-08-09 22:51:01 --> Utf8 Class Initialized
INFO - 2018-08-09 22:51:01 --> URI Class Initialized
INFO - 2018-08-09 22:51:01 --> Router Class Initialized
INFO - 2018-08-09 22:51:01 --> Output Class Initialized
INFO - 2018-08-09 22:51:01 --> Security Class Initialized
DEBUG - 2018-08-09 22:51:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-09 22:51:01 --> Input Class Initialized
INFO - 2018-08-09 22:51:01 --> Language Class Initialized
ERROR - 2018-08-09 22:51:01 --> 404 Page Not Found: /index
INFO - 2018-08-09 22:51:01 --> Config Class Initialized
INFO - 2018-08-09 22:51:01 --> Hooks Class Initialized
DEBUG - 2018-08-09 22:51:01 --> UTF-8 Support Enabled
INFO - 2018-08-09 22:51:01 --> Utf8 Class Initialized
INFO - 2018-08-09 22:51:01 --> URI Class Initialized
INFO - 2018-08-09 22:51:01 --> Router Class Initialized
INFO - 2018-08-09 22:51:01 --> Output Class Initialized
INFO - 2018-08-09 22:51:02 --> Security Class Initialized
DEBUG - 2018-08-09 22:51:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-09 22:51:02 --> Input Class Initialized
INFO - 2018-08-09 22:51:02 --> Language Class Initialized
ERROR - 2018-08-09 22:51:02 --> 404 Page Not Found: /index
INFO - 2018-08-09 22:51:02 --> Config Class Initialized
INFO - 2018-08-09 22:51:02 --> Hooks Class Initialized
DEBUG - 2018-08-09 22:51:02 --> UTF-8 Support Enabled
INFO - 2018-08-09 22:51:02 --> Utf8 Class Initialized
INFO - 2018-08-09 22:51:02 --> URI Class Initialized
INFO - 2018-08-09 22:51:02 --> Router Class Initialized
INFO - 2018-08-09 22:51:02 --> Output Class Initialized
INFO - 2018-08-09 22:51:02 --> Security Class Initialized
DEBUG - 2018-08-09 22:51:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-09 22:51:02 --> Input Class Initialized
INFO - 2018-08-09 22:51:02 --> Language Class Initialized
ERROR - 2018-08-09 22:51:02 --> 404 Page Not Found: /index
INFO - 2018-08-09 22:51:24 --> Config Class Initialized
INFO - 2018-08-09 22:51:24 --> Hooks Class Initialized
DEBUG - 2018-08-09 22:51:24 --> UTF-8 Support Enabled
INFO - 2018-08-09 22:51:24 --> Utf8 Class Initialized
INFO - 2018-08-09 22:51:24 --> URI Class Initialized
INFO - 2018-08-09 22:51:24 --> Router Class Initialized
INFO - 2018-08-09 22:51:24 --> Output Class Initialized
INFO - 2018-08-09 22:51:24 --> Security Class Initialized
DEBUG - 2018-08-09 22:51:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-09 22:51:24 --> Input Class Initialized
INFO - 2018-08-09 22:51:24 --> Language Class Initialized
INFO - 2018-08-09 22:51:24 --> Language Class Initialized
INFO - 2018-08-09 22:51:24 --> Config Class Initialized
INFO - 2018-08-09 22:51:24 --> Loader Class Initialized
DEBUG - 2018-08-09 22:51:24 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-09 22:51:24 --> Helper loaded: url_helper
INFO - 2018-08-09 22:51:24 --> Helper loaded: form_helper
INFO - 2018-08-09 22:51:24 --> Helper loaded: date_helper
INFO - 2018-08-09 22:51:24 --> Helper loaded: util_helper
INFO - 2018-08-09 22:51:24 --> Helper loaded: text_helper
INFO - 2018-08-09 22:51:24 --> Helper loaded: string_helper
INFO - 2018-08-09 22:51:24 --> Database Driver Class Initialized
DEBUG - 2018-08-09 22:51:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-09 22:51:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-09 22:51:24 --> Email Class Initialized
INFO - 2018-08-09 22:51:24 --> Controller Class Initialized
DEBUG - 2018-08-09 22:51:24 --> Login MX_Controller Initialized
INFO - 2018-08-09 22:51:24 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-09 22:51:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-09 22:51:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-09 22:51:24 --> Email starts for colin-admin fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-08-09 22:51:24 --> User session created for 1
INFO - 2018-08-09 22:51:24 --> Login status colin-admin - success
INFO - 2018-08-09 22:51:25 --> Final output sent to browser
DEBUG - 2018-08-09 22:51:25 --> Total execution time: 0.3879
INFO - 2018-08-09 22:51:25 --> Config Class Initialized
INFO - 2018-08-09 22:51:25 --> Hooks Class Initialized
DEBUG - 2018-08-09 22:51:25 --> UTF-8 Support Enabled
INFO - 2018-08-09 22:51:25 --> Utf8 Class Initialized
INFO - 2018-08-09 22:51:25 --> URI Class Initialized
INFO - 2018-08-09 22:51:25 --> Router Class Initialized
INFO - 2018-08-09 22:51:25 --> Output Class Initialized
INFO - 2018-08-09 22:51:25 --> Security Class Initialized
DEBUG - 2018-08-09 22:51:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-09 22:51:25 --> Input Class Initialized
INFO - 2018-08-09 22:51:25 --> Language Class Initialized
INFO - 2018-08-09 22:51:25 --> Language Class Initialized
INFO - 2018-08-09 22:51:25 --> Config Class Initialized
INFO - 2018-08-09 22:51:25 --> Loader Class Initialized
DEBUG - 2018-08-09 22:51:25 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-09 22:51:25 --> Helper loaded: url_helper
INFO - 2018-08-09 22:51:25 --> Helper loaded: form_helper
INFO - 2018-08-09 22:51:25 --> Helper loaded: date_helper
INFO - 2018-08-09 22:51:25 --> Helper loaded: util_helper
INFO - 2018-08-09 22:51:25 --> Helper loaded: text_helper
INFO - 2018-08-09 22:51:25 --> Helper loaded: string_helper
INFO - 2018-08-09 22:51:25 --> Database Driver Class Initialized
DEBUG - 2018-08-09 22:51:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-09 22:51:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-09 22:51:25 --> Email Class Initialized
INFO - 2018-08-09 22:51:25 --> Controller Class Initialized
DEBUG - 2018-08-09 22:51:25 --> Settings MX_Controller Initialized
INFO - 2018-08-09 22:51:25 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-09 22:51:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-09 22:51:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Settings_model.php
DEBUG - 2018-08-09 22:51:25 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-09 22:51:25 --> Login MX_Controller Initialized
DEBUG - 2018-08-09 22:51:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-09 22:51:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-08-09 22:51:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-08-09 22:51:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-08-09 22:51:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-08-09 22:51:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-08-09 22:51:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/settings.php
INFO - 2018-08-09 22:51:25 --> Final output sent to browser
DEBUG - 2018-08-09 22:51:25 --> Total execution time: 0.4027
INFO - 2018-08-09 23:28:56 --> Config Class Initialized
INFO - 2018-08-09 23:28:56 --> Hooks Class Initialized
DEBUG - 2018-08-09 23:28:56 --> UTF-8 Support Enabled
INFO - 2018-08-09 23:28:56 --> Utf8 Class Initialized
INFO - 2018-08-09 23:28:56 --> URI Class Initialized
INFO - 2018-08-09 23:28:56 --> Router Class Initialized
INFO - 2018-08-09 23:28:56 --> Output Class Initialized
INFO - 2018-08-09 23:28:56 --> Security Class Initialized
DEBUG - 2018-08-09 23:28:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-09 23:28:56 --> Input Class Initialized
INFO - 2018-08-09 23:28:56 --> Language Class Initialized
INFO - 2018-08-09 23:28:56 --> Language Class Initialized
INFO - 2018-08-09 23:28:56 --> Config Class Initialized
INFO - 2018-08-09 23:28:56 --> Loader Class Initialized
DEBUG - 2018-08-09 23:28:57 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-09 23:28:57 --> Helper loaded: url_helper
INFO - 2018-08-09 23:28:57 --> Helper loaded: form_helper
INFO - 2018-08-09 23:28:57 --> Helper loaded: date_helper
INFO - 2018-08-09 23:28:57 --> Helper loaded: util_helper
INFO - 2018-08-09 23:28:57 --> Helper loaded: text_helper
INFO - 2018-08-09 23:28:57 --> Helper loaded: string_helper
INFO - 2018-08-09 23:28:57 --> Database Driver Class Initialized
DEBUG - 2018-08-09 23:28:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-09 23:28:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-09 23:28:57 --> Email Class Initialized
INFO - 2018-08-09 23:28:57 --> Controller Class Initialized
DEBUG - 2018-08-09 23:28:57 --> Settings MX_Controller Initialized
INFO - 2018-08-09 23:28:57 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-09 23:28:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-09 23:28:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Settings_model.php
DEBUG - 2018-08-09 23:28:57 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-09 23:28:57 --> Login MX_Controller Initialized
DEBUG - 2018-08-09 23:28:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-09 23:28:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-08-09 23:28:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-08-09 23:28:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-08-09 23:28:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-08-09 23:28:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-08-09 23:28:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/settings.php
INFO - 2018-08-09 23:28:57 --> Final output sent to browser
DEBUG - 2018-08-09 23:28:57 --> Total execution time: 1.2511
INFO - 2018-08-09 23:28:58 --> Config Class Initialized
INFO - 2018-08-09 23:28:58 --> Hooks Class Initialized
DEBUG - 2018-08-09 23:28:58 --> UTF-8 Support Enabled
INFO - 2018-08-09 23:28:58 --> Utf8 Class Initialized
INFO - 2018-08-09 23:28:58 --> URI Class Initialized
INFO - 2018-08-09 23:28:58 --> Router Class Initialized
INFO - 2018-08-09 23:28:58 --> Output Class Initialized
INFO - 2018-08-09 23:28:58 --> Security Class Initialized
DEBUG - 2018-08-09 23:28:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-09 23:28:58 --> Input Class Initialized
INFO - 2018-08-09 23:28:58 --> Language Class Initialized
INFO - 2018-08-09 23:28:58 --> Language Class Initialized
INFO - 2018-08-09 23:28:58 --> Config Class Initialized
INFO - 2018-08-09 23:28:58 --> Loader Class Initialized
DEBUG - 2018-08-09 23:28:58 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-09 23:28:58 --> Helper loaded: url_helper
INFO - 2018-08-09 23:28:58 --> Helper loaded: form_helper
INFO - 2018-08-09 23:28:58 --> Helper loaded: date_helper
INFO - 2018-08-09 23:28:58 --> Helper loaded: util_helper
INFO - 2018-08-09 23:28:58 --> Helper loaded: text_helper
INFO - 2018-08-09 23:28:58 --> Helper loaded: string_helper
INFO - 2018-08-09 23:28:58 --> Database Driver Class Initialized
DEBUG - 2018-08-09 23:28:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-09 23:28:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-09 23:28:59 --> Email Class Initialized
INFO - 2018-08-09 23:28:59 --> Controller Class Initialized
DEBUG - 2018-08-09 23:28:59 --> Home MX_Controller Initialized
DEBUG - 2018-08-09 23:28:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-09 23:28:59 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-09 23:28:59 --> Login MX_Controller Initialized
INFO - 2018-08-09 23:28:59 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-09 23:28:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-09 23:28:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-09 23:28:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-08-09 23:28:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-08-09 23:28:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-08-09 23:28:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-08-09 23:28:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-08-09 23:28:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-08-09 23:28:59 --> Final output sent to browser
DEBUG - 2018-08-09 23:28:59 --> Total execution time: 0.4720
INFO - 2018-08-09 23:28:59 --> Config Class Initialized
INFO - 2018-08-09 23:28:59 --> Hooks Class Initialized
DEBUG - 2018-08-09 23:28:59 --> UTF-8 Support Enabled
INFO - 2018-08-09 23:28:59 --> Utf8 Class Initialized
INFO - 2018-08-09 23:28:59 --> URI Class Initialized
INFO - 2018-08-09 23:28:59 --> Router Class Initialized
INFO - 2018-08-09 23:28:59 --> Output Class Initialized
INFO - 2018-08-09 23:28:59 --> Security Class Initialized
DEBUG - 2018-08-09 23:28:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-09 23:28:59 --> Input Class Initialized
INFO - 2018-08-09 23:28:59 --> Language Class Initialized
INFO - 2018-08-09 23:28:59 --> Language Class Initialized
INFO - 2018-08-09 23:28:59 --> Config Class Initialized
INFO - 2018-08-09 23:28:59 --> Loader Class Initialized
DEBUG - 2018-08-09 23:28:59 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-09 23:28:59 --> Helper loaded: url_helper
INFO - 2018-08-09 23:28:59 --> Helper loaded: form_helper
INFO - 2018-08-09 23:28:59 --> Helper loaded: date_helper
INFO - 2018-08-09 23:28:59 --> Helper loaded: util_helper
INFO - 2018-08-09 23:29:00 --> Helper loaded: text_helper
INFO - 2018-08-09 23:29:00 --> Helper loaded: string_helper
INFO - 2018-08-09 23:29:00 --> Database Driver Class Initialized
DEBUG - 2018-08-09 23:29:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-09 23:29:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-09 23:29:00 --> Email Class Initialized
INFO - 2018-08-09 23:29:00 --> Controller Class Initialized
DEBUG - 2018-08-09 23:29:00 --> Home MX_Controller Initialized
DEBUG - 2018-08-09 23:29:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-08-09 23:29:02 --> Config Class Initialized
INFO - 2018-08-09 23:29:02 --> Hooks Class Initialized
DEBUG - 2018-08-09 23:29:02 --> UTF-8 Support Enabled
INFO - 2018-08-09 23:29:02 --> Utf8 Class Initialized
INFO - 2018-08-09 23:29:02 --> URI Class Initialized
INFO - 2018-08-09 23:29:02 --> Router Class Initialized
INFO - 2018-08-09 23:29:02 --> Output Class Initialized
INFO - 2018-08-09 23:29:02 --> Security Class Initialized
DEBUG - 2018-08-09 23:29:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-09 23:29:02 --> Input Class Initialized
INFO - 2018-08-09 23:29:02 --> Language Class Initialized
ERROR - 2018-08-09 23:29:02 --> 404 Page Not Found: /index
INFO - 2018-08-09 23:29:02 --> Config Class Initialized
INFO - 2018-08-09 23:29:02 --> Hooks Class Initialized
DEBUG - 2018-08-09 23:29:02 --> UTF-8 Support Enabled
INFO - 2018-08-09 23:29:02 --> Utf8 Class Initialized
INFO - 2018-08-09 23:29:03 --> URI Class Initialized
INFO - 2018-08-09 23:29:03 --> Router Class Initialized
INFO - 2018-08-09 23:29:03 --> Output Class Initialized
INFO - 2018-08-09 23:29:03 --> Security Class Initialized
DEBUG - 2018-08-09 23:29:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-09 23:29:03 --> Input Class Initialized
INFO - 2018-08-09 23:29:03 --> Language Class Initialized
ERROR - 2018-08-09 23:29:03 --> 404 Page Not Found: /index
INFO - 2018-08-09 23:29:03 --> Config Class Initialized
INFO - 2018-08-09 23:29:03 --> Hooks Class Initialized
DEBUG - 2018-08-09 23:29:03 --> UTF-8 Support Enabled
INFO - 2018-08-09 23:29:03 --> Utf8 Class Initialized
INFO - 2018-08-09 23:29:03 --> URI Class Initialized
INFO - 2018-08-09 23:29:03 --> Router Class Initialized
INFO - 2018-08-09 23:29:03 --> Output Class Initialized
INFO - 2018-08-09 23:29:03 --> Security Class Initialized
DEBUG - 2018-08-09 23:29:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-09 23:29:03 --> Input Class Initialized
INFO - 2018-08-09 23:29:03 --> Language Class Initialized
ERROR - 2018-08-09 23:29:03 --> 404 Page Not Found: /index
