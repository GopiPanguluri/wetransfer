<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-08-10 21:38:52 --> Config Class Initialized
INFO - 2018-08-10 21:38:52 --> Hooks Class Initialized
DEBUG - 2018-08-10 21:38:52 --> UTF-8 Support Enabled
INFO - 2018-08-10 21:38:52 --> Utf8 Class Initialized
INFO - 2018-08-10 21:38:52 --> URI Class Initialized
INFO - 2018-08-10 21:38:52 --> Config Class Initialized
INFO - 2018-08-10 21:38:52 --> Hooks Class Initialized
DEBUG - 2018-08-10 21:38:52 --> UTF-8 Support Enabled
INFO - 2018-08-10 21:38:52 --> Utf8 Class Initialized
INFO - 2018-08-10 21:38:52 --> URI Class Initialized
INFO - 2018-08-10 21:38:52 --> Router Class Initialized
INFO - 2018-08-10 21:38:52 --> Router Class Initialized
INFO - 2018-08-10 21:38:52 --> Output Class Initialized
INFO - 2018-08-10 21:38:52 --> Output Class Initialized
INFO - 2018-08-10 21:38:52 --> Security Class Initialized
INFO - 2018-08-10 21:38:52 --> Security Class Initialized
DEBUG - 2018-08-10 21:38:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-08-10 21:38:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-10 21:38:52 --> Input Class Initialized
INFO - 2018-08-10 21:38:52 --> Input Class Initialized
INFO - 2018-08-10 21:38:52 --> Language Class Initialized
INFO - 2018-08-10 21:38:52 --> Language Class Initialized
INFO - 2018-08-10 21:38:52 --> Language Class Initialized
INFO - 2018-08-10 21:38:52 --> Language Class Initialized
INFO - 2018-08-10 21:38:52 --> Config Class Initialized
INFO - 2018-08-10 21:38:52 --> Config Class Initialized
INFO - 2018-08-10 21:38:53 --> Loader Class Initialized
INFO - 2018-08-10 21:38:53 --> Loader Class Initialized
DEBUG - 2018-08-10 21:38:53 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
DEBUG - 2018-08-10 21:38:53 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-10 21:38:53 --> Helper loaded: url_helper
INFO - 2018-08-10 21:38:53 --> Helper loaded: url_helper
INFO - 2018-08-10 21:38:53 --> Helper loaded: form_helper
INFO - 2018-08-10 21:38:53 --> Helper loaded: form_helper
INFO - 2018-08-10 21:38:53 --> Helper loaded: date_helper
INFO - 2018-08-10 21:38:53 --> Helper loaded: date_helper
INFO - 2018-08-10 21:38:53 --> Helper loaded: util_helper
INFO - 2018-08-10 21:38:53 --> Helper loaded: util_helper
INFO - 2018-08-10 21:38:53 --> Helper loaded: text_helper
INFO - 2018-08-10 21:38:53 --> Helper loaded: text_helper
INFO - 2018-08-10 21:38:53 --> Helper loaded: string_helper
INFO - 2018-08-10 21:38:53 --> Helper loaded: string_helper
INFO - 2018-08-10 21:38:53 --> Database Driver Class Initialized
INFO - 2018-08-10 21:38:53 --> Database Driver Class Initialized
DEBUG - 2018-08-10 21:38:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-08-10 21:38:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-10 21:38:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-10 21:38:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-10 21:38:53 --> Email Class Initialized
INFO - 2018-08-10 21:38:53 --> Email Class Initialized
INFO - 2018-08-10 21:38:53 --> Controller Class Initialized
INFO - 2018-08-10 21:38:53 --> Controller Class Initialized
DEBUG - 2018-08-10 21:38:53 --> Home MX_Controller Initialized
DEBUG - 2018-08-10 21:38:53 --> Settings MX_Controller Initialized
INFO - 2018-08-10 21:38:53 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-10 21:38:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-10 21:38:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-10 21:38:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Settings_model.php
DEBUG - 2018-08-10 21:38:53 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-10 21:38:53 --> Login MX_Controller Initialized
DEBUG - 2018-08-10 21:38:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-10 21:38:53 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-10 21:38:53 --> Login MX_Controller Initialized
INFO - 2018-08-10 21:38:53 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-10 21:38:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-10 21:38:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-10 21:38:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Settings_model.php
DEBUG - 2018-08-10 21:38:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/logins/login.php
DEBUG - 2018-08-10 21:38:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/login.php
INFO - 2018-08-10 21:38:54 --> Config Class Initialized
INFO - 2018-08-10 21:38:54 --> Hooks Class Initialized
DEBUG - 2018-08-10 21:38:54 --> UTF-8 Support Enabled
INFO - 2018-08-10 21:38:54 --> Utf8 Class Initialized
INFO - 2018-08-10 21:38:54 --> URI Class Initialized
INFO - 2018-08-10 21:38:54 --> Router Class Initialized
INFO - 2018-08-10 21:38:54 --> Output Class Initialized
INFO - 2018-08-10 21:38:54 --> Security Class Initialized
DEBUG - 2018-08-10 21:38:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-10 21:38:54 --> Input Class Initialized
INFO - 2018-08-10 21:38:54 --> Language Class Initialized
ERROR - 2018-08-10 21:38:54 --> 404 Page Not Found: /index
INFO - 2018-08-10 21:38:55 --> Config Class Initialized
INFO - 2018-08-10 21:38:55 --> Hooks Class Initialized
DEBUG - 2018-08-10 21:38:55 --> UTF-8 Support Enabled
INFO - 2018-08-10 21:38:55 --> Utf8 Class Initialized
INFO - 2018-08-10 21:38:55 --> URI Class Initialized
INFO - 2018-08-10 21:38:55 --> Router Class Initialized
INFO - 2018-08-10 21:38:55 --> Output Class Initialized
INFO - 2018-08-10 21:38:55 --> Security Class Initialized
DEBUG - 2018-08-10 21:38:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-10 21:38:55 --> Input Class Initialized
INFO - 2018-08-10 21:38:55 --> Language Class Initialized
ERROR - 2018-08-10 21:38:55 --> 404 Page Not Found: /index
INFO - 2018-08-10 21:39:50 --> Config Class Initialized
INFO - 2018-08-10 21:39:50 --> Hooks Class Initialized
DEBUG - 2018-08-10 21:39:50 --> UTF-8 Support Enabled
INFO - 2018-08-10 21:39:50 --> Utf8 Class Initialized
INFO - 2018-08-10 21:39:50 --> URI Class Initialized
INFO - 2018-08-10 21:39:50 --> Router Class Initialized
INFO - 2018-08-10 21:39:50 --> Output Class Initialized
INFO - 2018-08-10 21:39:50 --> Security Class Initialized
DEBUG - 2018-08-10 21:39:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-10 21:39:50 --> Input Class Initialized
INFO - 2018-08-10 21:39:50 --> Language Class Initialized
INFO - 2018-08-10 21:39:50 --> Language Class Initialized
INFO - 2018-08-10 21:39:50 --> Config Class Initialized
INFO - 2018-08-10 21:39:50 --> Loader Class Initialized
DEBUG - 2018-08-10 21:39:50 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-10 21:39:50 --> Helper loaded: url_helper
INFO - 2018-08-10 21:39:50 --> Helper loaded: form_helper
INFO - 2018-08-10 21:39:50 --> Helper loaded: date_helper
INFO - 2018-08-10 21:39:50 --> Helper loaded: util_helper
INFO - 2018-08-10 21:39:50 --> Helper loaded: text_helper
INFO - 2018-08-10 21:39:50 --> Helper loaded: string_helper
INFO - 2018-08-10 21:39:50 --> Database Driver Class Initialized
DEBUG - 2018-08-10 21:39:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-10 21:39:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-10 21:39:50 --> Email Class Initialized
INFO - 2018-08-10 21:39:50 --> Controller Class Initialized
DEBUG - 2018-08-10 21:39:50 --> Login MX_Controller Initialized
INFO - 2018-08-10 21:39:50 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-10 21:39:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-10 21:39:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-10 21:39:50 --> Email starts for colinUser fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-08-10 21:39:50 --> User session created for 4
INFO - 2018-08-10 21:39:51 --> Login status colinUser - success
INFO - 2018-08-10 21:39:51 --> Final output sent to browser
DEBUG - 2018-08-10 21:39:51 --> Total execution time: 0.3773
INFO - 2018-08-10 21:39:51 --> Config Class Initialized
INFO - 2018-08-10 21:39:51 --> Hooks Class Initialized
DEBUG - 2018-08-10 21:39:51 --> UTF-8 Support Enabled
INFO - 2018-08-10 21:39:51 --> Utf8 Class Initialized
INFO - 2018-08-10 21:39:51 --> URI Class Initialized
INFO - 2018-08-10 21:39:51 --> Router Class Initialized
INFO - 2018-08-10 21:39:51 --> Output Class Initialized
INFO - 2018-08-10 21:39:51 --> Security Class Initialized
DEBUG - 2018-08-10 21:39:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-10 21:39:51 --> Input Class Initialized
INFO - 2018-08-10 21:39:51 --> Language Class Initialized
INFO - 2018-08-10 21:39:51 --> Language Class Initialized
INFO - 2018-08-10 21:39:51 --> Config Class Initialized
INFO - 2018-08-10 21:39:51 --> Loader Class Initialized
DEBUG - 2018-08-10 21:39:51 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-10 21:39:51 --> Helper loaded: url_helper
INFO - 2018-08-10 21:39:51 --> Helper loaded: form_helper
INFO - 2018-08-10 21:39:51 --> Helper loaded: date_helper
INFO - 2018-08-10 21:39:51 --> Helper loaded: util_helper
INFO - 2018-08-10 21:39:51 --> Helper loaded: text_helper
INFO - 2018-08-10 21:39:51 --> Helper loaded: string_helper
INFO - 2018-08-10 21:39:51 --> Database Driver Class Initialized
DEBUG - 2018-08-10 21:39:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-10 21:39:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-10 21:39:51 --> Email Class Initialized
INFO - 2018-08-10 21:39:51 --> Controller Class Initialized
DEBUG - 2018-08-10 21:39:51 --> Home MX_Controller Initialized
DEBUG - 2018-08-10 21:39:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-08-10 21:39:51 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-10 21:39:51 --> Login MX_Controller Initialized
INFO - 2018-08-10 21:39:51 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-10 21:39:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-10 21:39:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-10 21:39:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-08-10 21:39:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-08-10 21:39:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-08-10 21:39:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-08-10 21:39:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-08-10 21:39:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-08-10 21:39:51 --> Final output sent to browser
DEBUG - 2018-08-10 21:39:51 --> Total execution time: 0.7321
INFO - 2018-08-10 21:39:53 --> Config Class Initialized
INFO - 2018-08-10 21:39:53 --> Hooks Class Initialized
DEBUG - 2018-08-10 21:39:53 --> UTF-8 Support Enabled
INFO - 2018-08-10 21:39:53 --> Utf8 Class Initialized
INFO - 2018-08-10 21:39:53 --> URI Class Initialized
INFO - 2018-08-10 21:39:53 --> Router Class Initialized
INFO - 2018-08-10 21:39:53 --> Output Class Initialized
INFO - 2018-08-10 21:39:53 --> Security Class Initialized
DEBUG - 2018-08-10 21:39:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-10 21:39:53 --> Input Class Initialized
INFO - 2018-08-10 21:39:53 --> Language Class Initialized
ERROR - 2018-08-10 21:39:53 --> 404 Page Not Found: /index
INFO - 2018-08-10 21:39:53 --> Config Class Initialized
INFO - 2018-08-10 21:39:53 --> Hooks Class Initialized
DEBUG - 2018-08-10 21:39:53 --> UTF-8 Support Enabled
INFO - 2018-08-10 21:39:53 --> Utf8 Class Initialized
INFO - 2018-08-10 21:39:53 --> URI Class Initialized
INFO - 2018-08-10 21:39:53 --> Router Class Initialized
INFO - 2018-08-10 21:39:53 --> Output Class Initialized
INFO - 2018-08-10 21:39:53 --> Security Class Initialized
INFO - 2018-08-10 21:39:53 --> Config Class Initialized
INFO - 2018-08-10 21:39:53 --> Hooks Class Initialized
DEBUG - 2018-08-10 21:39:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-10 21:39:53 --> Input Class Initialized
DEBUG - 2018-08-10 21:39:53 --> UTF-8 Support Enabled
INFO - 2018-08-10 21:39:53 --> Utf8 Class Initialized
INFO - 2018-08-10 21:39:53 --> Language Class Initialized
INFO - 2018-08-10 21:39:53 --> URI Class Initialized
INFO - 2018-08-10 21:39:53 --> Language Class Initialized
INFO - 2018-08-10 21:39:53 --> Config Class Initialized
INFO - 2018-08-10 21:39:53 --> Router Class Initialized
INFO - 2018-08-10 21:39:53 --> Output Class Initialized
INFO - 2018-08-10 21:39:53 --> Loader Class Initialized
DEBUG - 2018-08-10 21:39:53 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-10 21:39:53 --> Security Class Initialized
INFO - 2018-08-10 21:39:54 --> Helper loaded: url_helper
DEBUG - 2018-08-10 21:39:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-10 21:39:54 --> Input Class Initialized
INFO - 2018-08-10 21:39:54 --> Helper loaded: form_helper
INFO - 2018-08-10 21:39:54 --> Language Class Initialized
ERROR - 2018-08-10 21:39:54 --> 404 Page Not Found: /index
INFO - 2018-08-10 21:39:54 --> Helper loaded: date_helper
INFO - 2018-08-10 21:39:54 --> Helper loaded: util_helper
INFO - 2018-08-10 21:39:54 --> Helper loaded: text_helper
INFO - 2018-08-10 21:39:54 --> Helper loaded: string_helper
INFO - 2018-08-10 21:39:54 --> Database Driver Class Initialized
DEBUG - 2018-08-10 21:39:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-10 21:39:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-10 21:39:54 --> Config Class Initialized
INFO - 2018-08-10 21:39:54 --> Hooks Class Initialized
INFO - 2018-08-10 21:39:54 --> Email Class Initialized
DEBUG - 2018-08-10 21:39:54 --> UTF-8 Support Enabled
INFO - 2018-08-10 21:39:54 --> Utf8 Class Initialized
INFO - 2018-08-10 21:39:54 --> Controller Class Initialized
INFO - 2018-08-10 21:39:54 --> URI Class Initialized
INFO - 2018-08-10 21:39:54 --> Config Class Initialized
INFO - 2018-08-10 21:39:54 --> Hooks Class Initialized
INFO - 2018-08-10 21:39:54 --> Router Class Initialized
DEBUG - 2018-08-10 21:39:54 --> UTF-8 Support Enabled
DEBUG - 2018-08-10 21:39:54 --> Home MX_Controller Initialized
INFO - 2018-08-10 21:39:54 --> Utf8 Class Initialized
INFO - 2018-08-10 21:39:54 --> Output Class Initialized
DEBUG - 2018-08-10 21:39:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-08-10 21:39:54 --> URI Class Initialized
INFO - 2018-08-10 21:39:54 --> Router Class Initialized
INFO - 2018-08-10 21:39:54 --> Security Class Initialized
INFO - 2018-08-10 21:39:54 --> Output Class Initialized
INFO - 2018-08-10 21:39:54 --> Security Class Initialized
DEBUG - 2018-08-10 21:39:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-10 21:39:54 --> Input Class Initialized
INFO - 2018-08-10 21:39:54 --> Language Class Initialized
INFO - 2018-08-10 21:39:54 --> Language Class Initialized
INFO - 2018-08-10 21:39:54 --> Config Class Initialized
INFO - 2018-08-10 21:39:54 --> Loader Class Initialized
DEBUG - 2018-08-10 21:39:54 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-10 21:39:54 --> Helper loaded: url_helper
DEBUG - 2018-08-10 21:39:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-10 21:39:54 --> Helper loaded: form_helper
INFO - 2018-08-10 21:39:54 --> Input Class Initialized
INFO - 2018-08-10 21:39:54 --> Helper loaded: date_helper
INFO - 2018-08-10 21:39:54 --> Helper loaded: util_helper
INFO - 2018-08-10 21:39:54 --> Language Class Initialized
ERROR - 2018-08-10 21:39:54 --> 404 Page Not Found: /index
INFO - 2018-08-10 21:39:54 --> Helper loaded: text_helper
INFO - 2018-08-10 21:39:54 --> Helper loaded: string_helper
INFO - 2018-08-10 21:39:54 --> Database Driver Class Initialized
DEBUG - 2018-08-10 21:39:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-10 21:39:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-10 21:39:54 --> Email Class Initialized
INFO - 2018-08-10 21:39:54 --> Controller Class Initialized
DEBUG - 2018-08-10 21:39:54 --> Login MX_Controller Initialized
INFO - 2018-08-10 21:39:54 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-10 21:39:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-10 21:39:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-10 21:39:54 --> Email starts for colin-admin fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-08-10 21:39:54 --> User session created for 1
INFO - 2018-08-10 21:39:54 --> Config Class Initialized
INFO - 2018-08-10 21:39:54 --> Hooks Class Initialized
DEBUG - 2018-08-10 21:39:54 --> UTF-8 Support Enabled
INFO - 2018-08-10 21:39:54 --> Utf8 Class Initialized
INFO - 2018-08-10 21:39:54 --> URI Class Initialized
INFO - 2018-08-10 21:39:54 --> Router Class Initialized
INFO - 2018-08-10 21:39:54 --> Output Class Initialized
INFO - 2018-08-10 21:39:54 --> Security Class Initialized
DEBUG - 2018-08-10 21:39:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-10 21:39:54 --> Input Class Initialized
INFO - 2018-08-10 21:39:54 --> Language Class Initialized
ERROR - 2018-08-10 21:39:54 --> 404 Page Not Found: /index
INFO - 2018-08-10 21:39:54 --> Config Class Initialized
INFO - 2018-08-10 21:39:54 --> Hooks Class Initialized
DEBUG - 2018-08-10 21:39:54 --> UTF-8 Support Enabled
INFO - 2018-08-10 21:39:54 --> Utf8 Class Initialized
INFO - 2018-08-10 21:39:54 --> URI Class Initialized
INFO - 2018-08-10 21:39:54 --> Router Class Initialized
INFO - 2018-08-10 21:39:54 --> Output Class Initialized
INFO - 2018-08-10 21:39:54 --> Security Class Initialized
DEBUG - 2018-08-10 21:39:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-10 21:39:54 --> Input Class Initialized
INFO - 2018-08-10 21:39:54 --> Language Class Initialized
ERROR - 2018-08-10 21:39:54 --> 404 Page Not Found: /index
INFO - 2018-08-10 21:39:54 --> Login status colin-admin - success
INFO - 2018-08-10 21:39:54 --> Final output sent to browser
DEBUG - 2018-08-10 21:39:54 --> Total execution time: 0.7493
INFO - 2018-08-10 21:39:55 --> Config Class Initialized
INFO - 2018-08-10 21:39:55 --> Hooks Class Initialized
INFO - 2018-08-10 21:39:55 --> Config Class Initialized
INFO - 2018-08-10 21:39:55 --> Hooks Class Initialized
DEBUG - 2018-08-10 21:39:55 --> UTF-8 Support Enabled
INFO - 2018-08-10 21:39:55 --> Utf8 Class Initialized
DEBUG - 2018-08-10 21:39:55 --> UTF-8 Support Enabled
INFO - 2018-08-10 21:39:55 --> URI Class Initialized
INFO - 2018-08-10 21:39:55 --> Router Class Initialized
INFO - 2018-08-10 21:39:55 --> Output Class Initialized
INFO - 2018-08-10 21:39:55 --> Utf8 Class Initialized
INFO - 2018-08-10 21:39:55 --> Security Class Initialized
INFO - 2018-08-10 21:39:55 --> URI Class Initialized
DEBUG - 2018-08-10 21:39:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-10 21:39:55 --> Input Class Initialized
INFO - 2018-08-10 21:39:55 --> Router Class Initialized
INFO - 2018-08-10 21:39:55 --> Language Class Initialized
INFO - 2018-08-10 21:39:55 --> Output Class Initialized
INFO - 2018-08-10 21:39:55 --> Security Class Initialized
INFO - 2018-08-10 21:39:55 --> Language Class Initialized
INFO - 2018-08-10 21:39:55 --> Config Class Initialized
DEBUG - 2018-08-10 21:39:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-10 21:39:55 --> Input Class Initialized
INFO - 2018-08-10 21:39:55 --> Loader Class Initialized
INFO - 2018-08-10 21:39:55 --> Language Class Initialized
DEBUG - 2018-08-10 21:39:55 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
ERROR - 2018-08-10 21:39:55 --> 404 Page Not Found: /index
INFO - 2018-08-10 21:39:55 --> Helper loaded: url_helper
INFO - 2018-08-10 21:39:55 --> Helper loaded: form_helper
INFO - 2018-08-10 21:39:55 --> Helper loaded: date_helper
INFO - 2018-08-10 21:39:55 --> Helper loaded: util_helper
INFO - 2018-08-10 21:39:55 --> Helper loaded: text_helper
INFO - 2018-08-10 21:39:55 --> Helper loaded: string_helper
INFO - 2018-08-10 21:39:55 --> Database Driver Class Initialized
DEBUG - 2018-08-10 21:39:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-10 21:39:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-10 21:39:55 --> Email Class Initialized
INFO - 2018-08-10 21:39:55 --> Controller Class Initialized
DEBUG - 2018-08-10 21:39:55 --> Settings MX_Controller Initialized
INFO - 2018-08-10 21:39:55 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-10 21:39:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-10 21:39:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Settings_model.php
DEBUG - 2018-08-10 21:39:55 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-10 21:39:55 --> Login MX_Controller Initialized
DEBUG - 2018-08-10 21:39:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-08-10 21:39:55 --> Config Class Initialized
INFO - 2018-08-10 21:39:55 --> Hooks Class Initialized
DEBUG - 2018-08-10 21:39:55 --> UTF-8 Support Enabled
INFO - 2018-08-10 21:39:55 --> Utf8 Class Initialized
INFO - 2018-08-10 21:39:55 --> URI Class Initialized
INFO - 2018-08-10 21:39:55 --> Router Class Initialized
INFO - 2018-08-10 21:39:55 --> Output Class Initialized
INFO - 2018-08-10 21:39:55 --> Security Class Initialized
DEBUG - 2018-08-10 21:39:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-10 21:39:55 --> Input Class Initialized
INFO - 2018-08-10 21:39:55 --> Language Class Initialized
ERROR - 2018-08-10 21:39:55 --> 404 Page Not Found: /index
DEBUG - 2018-08-10 21:39:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-08-10 21:39:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-08-10 21:39:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-08-10 21:39:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-08-10 21:39:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-08-10 21:39:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/settings.php
INFO - 2018-08-10 21:39:55 --> Config Class Initialized
INFO - 2018-08-10 21:39:55 --> Hooks Class Initialized
INFO - 2018-08-10 21:39:55 --> Final output sent to browser
DEBUG - 2018-08-10 21:39:55 --> UTF-8 Support Enabled
INFO - 2018-08-10 21:39:55 --> Utf8 Class Initialized
DEBUG - 2018-08-10 21:39:55 --> Total execution time: 0.8253
INFO - 2018-08-10 21:39:55 --> URI Class Initialized
INFO - 2018-08-10 21:39:55 --> Router Class Initialized
INFO - 2018-08-10 21:39:55 --> Output Class Initialized
INFO - 2018-08-10 21:39:55 --> Security Class Initialized
DEBUG - 2018-08-10 21:39:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-10 21:39:56 --> Input Class Initialized
INFO - 2018-08-10 21:39:56 --> Language Class Initialized
ERROR - 2018-08-10 21:39:56 --> 404 Page Not Found: /index
INFO - 2018-08-10 21:39:56 --> Config Class Initialized
INFO - 2018-08-10 21:39:56 --> Hooks Class Initialized
DEBUG - 2018-08-10 21:39:56 --> UTF-8 Support Enabled
INFO - 2018-08-10 21:39:56 --> Utf8 Class Initialized
INFO - 2018-08-10 21:39:56 --> URI Class Initialized
INFO - 2018-08-10 21:39:56 --> Router Class Initialized
INFO - 2018-08-10 21:39:56 --> Output Class Initialized
INFO - 2018-08-10 21:39:56 --> Security Class Initialized
DEBUG - 2018-08-10 21:39:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-10 21:39:56 --> Input Class Initialized
INFO - 2018-08-10 21:39:56 --> Language Class Initialized
ERROR - 2018-08-10 21:39:56 --> 404 Page Not Found: /index
INFO - 2018-08-10 21:39:56 --> Config Class Initialized
INFO - 2018-08-10 21:39:56 --> Hooks Class Initialized
DEBUG - 2018-08-10 21:39:56 --> UTF-8 Support Enabled
INFO - 2018-08-10 21:39:56 --> Utf8 Class Initialized
INFO - 2018-08-10 21:39:56 --> URI Class Initialized
INFO - 2018-08-10 21:39:56 --> Router Class Initialized
INFO - 2018-08-10 21:39:56 --> Output Class Initialized
INFO - 2018-08-10 21:39:56 --> Security Class Initialized
DEBUG - 2018-08-10 21:39:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-10 21:39:56 --> Input Class Initialized
INFO - 2018-08-10 21:39:56 --> Language Class Initialized
ERROR - 2018-08-10 21:39:56 --> 404 Page Not Found: /index
