<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-08-11 06:08:03 --> Config Class Initialized
INFO - 2018-08-11 06:08:03 --> Hooks Class Initialized
DEBUG - 2018-08-11 06:08:03 --> UTF-8 Support Enabled
INFO - 2018-08-11 06:08:03 --> Utf8 Class Initialized
INFO - 2018-08-11 06:08:03 --> URI Class Initialized
INFO - 2018-08-11 06:08:03 --> Router Class Initialized
INFO - 2018-08-11 06:08:04 --> Output Class Initialized
INFO - 2018-08-11 06:08:04 --> Security Class Initialized
DEBUG - 2018-08-11 06:08:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-11 06:08:04 --> Input Class Initialized
INFO - 2018-08-11 06:08:04 --> Language Class Initialized
INFO - 2018-08-11 06:08:04 --> Language Class Initialized
INFO - 2018-08-11 06:08:04 --> Config Class Initialized
INFO - 2018-08-11 06:08:04 --> Loader Class Initialized
DEBUG - 2018-08-11 06:08:04 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-08-11 06:08:04 --> Helper loaded: url_helper
INFO - 2018-08-11 06:08:04 --> Helper loaded: form_helper
INFO - 2018-08-11 06:08:04 --> Helper loaded: date_helper
INFO - 2018-08-11 06:08:04 --> Helper loaded: util_helper
INFO - 2018-08-11 06:08:04 --> Helper loaded: text_helper
INFO - 2018-08-11 06:08:04 --> Helper loaded: string_helper
INFO - 2018-08-11 06:08:04 --> Database Driver Class Initialized
DEBUG - 2018-08-11 06:08:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-11 06:08:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-11 06:08:04 --> Email Class Initialized
INFO - 2018-08-11 06:08:04 --> Controller Class Initialized
DEBUG - 2018-08-11 06:08:04 --> Settings MX_Controller Initialized
INFO - 2018-08-11 06:08:04 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-08-11 06:08:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-08-11 06:08:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Settings_model.php
DEBUG - 2018-08-11 06:08:04 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-08-11 06:08:04 --> Login MX_Controller Initialized
DEBUG - 2018-08-11 06:08:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-08-11 06:08:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/logins/login.php
INFO - 2018-08-11 06:08:04 --> Config Class Initialized
INFO - 2018-08-11 06:08:04 --> Hooks Class Initialized
DEBUG - 2018-08-11 06:08:04 --> UTF-8 Support Enabled
INFO - 2018-08-11 06:08:04 --> Utf8 Class Initialized
INFO - 2018-08-11 06:08:04 --> URI Class Initialized
INFO - 2018-08-11 06:08:04 --> Router Class Initialized
INFO - 2018-08-11 06:08:04 --> Output Class Initialized
INFO - 2018-08-11 06:08:04 --> Security Class Initialized
DEBUG - 2018-08-11 06:08:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-11 06:08:04 --> Input Class Initialized
INFO - 2018-08-11 06:08:04 --> Language Class Initialized
ERROR - 2018-08-11 06:08:04 --> 404 Page Not Found: /index
INFO - 2018-08-11 06:08:05 --> Config Class Initialized
INFO - 2018-08-11 06:08:05 --> Hooks Class Initialized
DEBUG - 2018-08-11 06:08:05 --> UTF-8 Support Enabled
INFO - 2018-08-11 06:08:05 --> Utf8 Class Initialized
INFO - 2018-08-11 06:08:05 --> URI Class Initialized
INFO - 2018-08-11 06:08:05 --> Router Class Initialized
INFO - 2018-08-11 06:08:05 --> Output Class Initialized
INFO - 2018-08-11 06:08:05 --> Security Class Initialized
DEBUG - 2018-08-11 06:08:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-11 06:08:05 --> Input Class Initialized
INFO - 2018-08-11 06:08:05 --> Language Class Initialized
ERROR - 2018-08-11 06:08:05 --> 404 Page Not Found: /index
