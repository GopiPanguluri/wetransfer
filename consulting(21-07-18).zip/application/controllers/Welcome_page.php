<?php class Welcome_page extends CI_Controller{

	public function __construct(){
		parent::__construct();
	}

	public function index(){
		$this->load->view('common/header');
		$this->load->view('welcome_page');
		
		$this->load->view('common/footer');
	}
}