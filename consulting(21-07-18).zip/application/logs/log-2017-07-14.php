<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2017-07-14 13:36:19 --> Config Class Initialized
INFO - 2017-07-14 13:36:19 --> Hooks Class Initialized
DEBUG - 2017-07-14 13:36:19 --> UTF-8 Support Enabled
INFO - 2017-07-14 13:36:19 --> Utf8 Class Initialized
INFO - 2017-07-14 13:36:19 --> URI Class Initialized
INFO - 2017-07-14 13:36:19 --> Router Class Initialized
INFO - 2017-07-14 13:36:19 --> Output Class Initialized
INFO - 2017-07-14 13:36:19 --> Security Class Initialized
DEBUG - 2017-07-14 13:36:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-14 13:36:19 --> Input Class Initialized
INFO - 2017-07-14 13:36:19 --> Language Class Initialized
INFO - 2017-07-14 13:36:19 --> Language Class Initialized
INFO - 2017-07-14 13:36:19 --> Config Class Initialized
INFO - 2017-07-14 13:36:19 --> Loader Class Initialized
INFO - 2017-07-14 13:36:19 --> Helper loaded: url_helper
INFO - 2017-07-14 13:36:19 --> Helper loaded: form_helper
INFO - 2017-07-14 13:36:19 --> Helper loaded: date_helper
INFO - 2017-07-14 13:36:19 --> Helper loaded: util_helper
INFO - 2017-07-14 13:36:19 --> Helper loaded: text_helper
INFO - 2017-07-14 13:36:19 --> Helper loaded: string_helper
INFO - 2017-07-14 13:36:19 --> Database Driver Class Initialized
DEBUG - 2017-07-14 13:36:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-07-14 13:36:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-14 13:36:19 --> Email Class Initialized
INFO - 2017-07-14 13:36:19 --> Controller Class Initialized
DEBUG - 2017-07-14 13:36:19 --> Login MX_Controller Initialized
INFO - 2017-07-14 13:36:19 --> Model Class Initialized
DEBUG - 2017-07-14 13:36:19 --> File loaded: D:\xampp\htdocs\cb\application\modules/common/models/Common_model.php
INFO - 2017-07-14 13:36:19 --> Model Class Initialized
INFO - 2017-07-14 13:36:19 --> SEND ACTIVATION LINK <a href="http://localhost/cb/register/confirmuser?confcode=RQiY0OCV9ule4Gyv&email=joydeep.rakshit01@gmail.com&user_id=">http://localhost/cb/register/confirmuser?confcode=RQiY0OCV9ule4Gyv&email=joydeep.rakshit01@gmail.com&user_id=</a>
