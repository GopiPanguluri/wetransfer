<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2017-09-01 22:39:35 --> Config Class Initialized
INFO - 2017-09-01 22:39:35 --> Hooks Class Initialized
DEBUG - 2017-09-01 22:39:35 --> UTF-8 Support Enabled
INFO - 2017-09-01 22:39:35 --> Utf8 Class Initialized
INFO - 2017-09-01 22:39:35 --> URI Class Initialized
INFO - 2017-09-01 22:39:35 --> Router Class Initialized
INFO - 2017-09-01 22:39:35 --> Output Class Initialized
INFO - 2017-09-01 22:39:35 --> Security Class Initialized
DEBUG - 2017-09-01 22:39:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-01 22:39:35 --> Input Class Initialized
INFO - 2017-09-01 22:39:35 --> Language Class Initialized
INFO - 2017-09-01 22:39:35 --> Language Class Initialized
INFO - 2017-09-01 22:39:35 --> Config Class Initialized
INFO - 2017-09-01 22:39:35 --> Loader Class Initialized
DEBUG - 2017-09-01 22:39:35 --> Config file loaded: C:\xampp\htdocs\construction_bay\application\config/construct-data.php
INFO - 2017-09-01 22:39:35 --> Helper loaded: url_helper
INFO - 2017-09-01 22:39:35 --> Helper loaded: form_helper
INFO - 2017-09-01 22:39:35 --> Helper loaded: date_helper
INFO - 2017-09-01 22:39:35 --> Helper loaded: util_helper
INFO - 2017-09-01 22:39:35 --> Helper loaded: text_helper
INFO - 2017-09-01 22:39:35 --> Helper loaded: string_helper
INFO - 2017-09-01 22:39:35 --> Database Driver Class Initialized
ERROR - 2017-09-01 22:39:35 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'root'@'localhost' (using password: YES) C:\xampp\htdocs\construction_bay\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2017-09-01 22:39:35 --> Unable to connect to the database
INFO - 2017-09-01 22:39:36 --> Language file loaded: language/english/db_lang.php
INFO - 2017-09-01 22:39:37 --> Config Class Initialized
INFO - 2017-09-01 22:39:37 --> Hooks Class Initialized
DEBUG - 2017-09-01 22:39:37 --> UTF-8 Support Enabled
INFO - 2017-09-01 22:39:37 --> Utf8 Class Initialized
INFO - 2017-09-01 22:39:37 --> URI Class Initialized
INFO - 2017-09-01 22:39:37 --> Router Class Initialized
INFO - 2017-09-01 22:39:37 --> Output Class Initialized
INFO - 2017-09-01 22:39:37 --> Security Class Initialized
DEBUG - 2017-09-01 22:39:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-01 22:39:37 --> Input Class Initialized
INFO - 2017-09-01 22:39:37 --> Language Class Initialized
INFO - 2017-09-01 22:39:37 --> Language Class Initialized
INFO - 2017-09-01 22:39:37 --> Config Class Initialized
INFO - 2017-09-01 22:39:37 --> Loader Class Initialized
DEBUG - 2017-09-01 22:39:37 --> Config file loaded: C:\xampp\htdocs\construction_bay\application\config/construct-data.php
INFO - 2017-09-01 22:39:37 --> Helper loaded: url_helper
INFO - 2017-09-01 22:39:37 --> Helper loaded: form_helper
INFO - 2017-09-01 22:39:37 --> Helper loaded: date_helper
INFO - 2017-09-01 22:39:37 --> Helper loaded: util_helper
INFO - 2017-09-01 22:39:37 --> Helper loaded: text_helper
INFO - 2017-09-01 22:39:37 --> Helper loaded: string_helper
INFO - 2017-09-01 22:39:37 --> Database Driver Class Initialized
ERROR - 2017-09-01 22:39:37 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'root'@'localhost' (using password: YES) C:\xampp\htdocs\construction_bay\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2017-09-01 22:39:37 --> Unable to connect to the database
INFO - 2017-09-01 22:39:37 --> Language file loaded: language/english/db_lang.php
INFO - 2017-09-01 22:39:37 --> Config Class Initialized
INFO - 2017-09-01 22:39:37 --> Hooks Class Initialized
DEBUG - 2017-09-01 22:39:37 --> UTF-8 Support Enabled
INFO - 2017-09-01 22:39:37 --> Utf8 Class Initialized
INFO - 2017-09-01 22:39:37 --> URI Class Initialized
INFO - 2017-09-01 22:39:37 --> Router Class Initialized
INFO - 2017-09-01 22:39:37 --> Output Class Initialized
INFO - 2017-09-01 22:39:37 --> Security Class Initialized
DEBUG - 2017-09-01 22:39:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-01 22:39:37 --> Input Class Initialized
INFO - 2017-09-01 22:39:37 --> Language Class Initialized
INFO - 2017-09-01 22:39:37 --> Language Class Initialized
INFO - 2017-09-01 22:39:37 --> Config Class Initialized
INFO - 2017-09-01 22:39:37 --> Loader Class Initialized
DEBUG - 2017-09-01 22:39:37 --> Config file loaded: C:\xampp\htdocs\construction_bay\application\config/construct-data.php
INFO - 2017-09-01 22:39:37 --> Helper loaded: url_helper
INFO - 2017-09-01 22:39:37 --> Helper loaded: form_helper
INFO - 2017-09-01 22:39:37 --> Helper loaded: date_helper
INFO - 2017-09-01 22:39:37 --> Helper loaded: util_helper
INFO - 2017-09-01 22:39:37 --> Helper loaded: text_helper
INFO - 2017-09-01 22:39:37 --> Helper loaded: string_helper
INFO - 2017-09-01 22:39:37 --> Database Driver Class Initialized
ERROR - 2017-09-01 22:39:37 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'root'@'localhost' (using password: YES) C:\xampp\htdocs\construction_bay\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2017-09-01 22:39:37 --> Unable to connect to the database
INFO - 2017-09-01 22:39:37 --> Language file loaded: language/english/db_lang.php
INFO - 2017-09-01 22:42:48 --> Config Class Initialized
INFO - 2017-09-01 22:42:48 --> Hooks Class Initialized
DEBUG - 2017-09-01 22:42:48 --> UTF-8 Support Enabled
INFO - 2017-09-01 22:42:48 --> Utf8 Class Initialized
INFO - 2017-09-01 22:42:48 --> URI Class Initialized
DEBUG - 2017-09-01 22:42:48 --> No URI present. Default controller set.
INFO - 2017-09-01 22:42:48 --> Router Class Initialized
INFO - 2017-09-01 22:42:48 --> Output Class Initialized
INFO - 2017-09-01 22:42:48 --> Security Class Initialized
DEBUG - 2017-09-01 22:42:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-01 22:42:48 --> Input Class Initialized
INFO - 2017-09-01 22:42:48 --> Language Class Initialized
INFO - 2017-09-01 22:42:48 --> Language Class Initialized
INFO - 2017-09-01 22:42:48 --> Config Class Initialized
INFO - 2017-09-01 22:42:48 --> Loader Class Initialized
DEBUG - 2017-09-01 22:42:48 --> Config file loaded: C:\xampp\htdocs\construction_bay\application\config/construct-data.php
INFO - 2017-09-01 22:42:48 --> Helper loaded: url_helper
INFO - 2017-09-01 22:42:48 --> Helper loaded: form_helper
INFO - 2017-09-01 22:42:48 --> Helper loaded: date_helper
INFO - 2017-09-01 22:42:48 --> Helper loaded: util_helper
INFO - 2017-09-01 22:42:48 --> Helper loaded: text_helper
INFO - 2017-09-01 22:42:48 --> Helper loaded: string_helper
INFO - 2017-09-01 22:42:48 --> Database Driver Class Initialized
ERROR - 2017-09-01 22:42:48 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'root'@'localhost' (using password: YES) C:\xampp\htdocs\construction_bay\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2017-09-01 22:42:48 --> Unable to connect to the database
INFO - 2017-09-01 22:42:48 --> Language file loaded: language/english/db_lang.php
INFO - 2017-09-01 22:43:43 --> Config Class Initialized
INFO - 2017-09-01 22:43:43 --> Hooks Class Initialized
DEBUG - 2017-09-01 22:43:43 --> UTF-8 Support Enabled
INFO - 2017-09-01 22:43:43 --> Utf8 Class Initialized
INFO - 2017-09-01 22:43:43 --> URI Class Initialized
DEBUG - 2017-09-01 22:43:43 --> No URI present. Default controller set.
INFO - 2017-09-01 22:43:43 --> Router Class Initialized
INFO - 2017-09-01 22:43:43 --> Output Class Initialized
INFO - 2017-09-01 22:43:43 --> Security Class Initialized
DEBUG - 2017-09-01 22:43:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-01 22:43:43 --> Input Class Initialized
INFO - 2017-09-01 22:43:43 --> Language Class Initialized
INFO - 2017-09-01 22:43:43 --> Language Class Initialized
INFO - 2017-09-01 22:43:43 --> Config Class Initialized
INFO - 2017-09-01 22:43:43 --> Loader Class Initialized
DEBUG - 2017-09-01 22:43:43 --> Config file loaded: C:\xampp\htdocs\construction_bay\application\config/construct-data.php
INFO - 2017-09-01 22:43:43 --> Helper loaded: url_helper
INFO - 2017-09-01 22:43:43 --> Helper loaded: form_helper
INFO - 2017-09-01 22:43:43 --> Helper loaded: date_helper
INFO - 2017-09-01 22:43:43 --> Helper loaded: util_helper
INFO - 2017-09-01 22:43:43 --> Helper loaded: text_helper
INFO - 2017-09-01 22:43:43 --> Helper loaded: string_helper
INFO - 2017-09-01 22:43:43 --> Database Driver Class Initialized
ERROR - 2017-09-01 22:43:43 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'root'@'localhost' (using password: YES) C:\xampp\htdocs\construction_bay\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2017-09-01 22:43:43 --> Unable to connect to the database
INFO - 2017-09-01 22:43:43 --> Language file loaded: language/english/db_lang.php
