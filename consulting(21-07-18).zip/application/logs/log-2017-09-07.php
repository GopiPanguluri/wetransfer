<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2017-09-07 07:54:09 --> Config Class Initialized
INFO - 2017-09-07 07:54:09 --> Hooks Class Initialized
DEBUG - 2017-09-07 07:54:09 --> UTF-8 Support Enabled
INFO - 2017-09-07 07:54:09 --> Utf8 Class Initialized
INFO - 2017-09-07 07:54:09 --> URI Class Initialized
DEBUG - 2017-09-07 07:54:09 --> No URI present. Default controller set.
INFO - 2017-09-07 07:54:09 --> Router Class Initialized
INFO - 2017-09-07 07:54:09 --> Output Class Initialized
INFO - 2017-09-07 07:54:09 --> Security Class Initialized
DEBUG - 2017-09-07 07:54:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-07 07:54:09 --> Input Class Initialized
INFO - 2017-09-07 07:54:09 --> Language Class Initialized
INFO - 2017-09-07 07:54:09 --> Language Class Initialized
INFO - 2017-09-07 07:54:09 --> Config Class Initialized
INFO - 2017-09-07 07:54:09 --> Loader Class Initialized
DEBUG - 2017-09-07 07:54:10 --> Config file loaded: C:\xampp\htdocs\construction_bay\application\config/construct-data.php
INFO - 2017-09-07 07:54:10 --> Helper loaded: url_helper
INFO - 2017-09-07 07:54:10 --> Helper loaded: form_helper
INFO - 2017-09-07 07:54:10 --> Helper loaded: date_helper
INFO - 2017-09-07 07:54:10 --> Helper loaded: util_helper
INFO - 2017-09-07 07:54:10 --> Helper loaded: text_helper
INFO - 2017-09-07 07:54:10 --> Helper loaded: string_helper
INFO - 2017-09-07 07:54:10 --> Database Driver Class Initialized
ERROR - 2017-09-07 07:54:10 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'root'@'localhost' (using password: YES) C:\xampp\htdocs\construction_bay\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2017-09-07 07:54:10 --> Unable to connect to the database
INFO - 2017-09-07 07:54:10 --> Language file loaded: language/english/db_lang.php
