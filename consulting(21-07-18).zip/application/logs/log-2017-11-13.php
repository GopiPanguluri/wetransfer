<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2017-11-13 21:21:25 --> Config Class Initialized
INFO - 2017-11-13 21:21:25 --> Hooks Class Initialized
DEBUG - 2017-11-13 21:21:26 --> UTF-8 Support Enabled
INFO - 2017-11-13 21:21:26 --> Utf8 Class Initialized
INFO - 2017-11-13 21:21:26 --> URI Class Initialized
DEBUG - 2017-11-13 21:21:27 --> No URI present. Default controller set.
INFO - 2017-11-13 21:21:27 --> Router Class Initialized
INFO - 2017-11-13 21:21:27 --> Output Class Initialized
INFO - 2017-11-13 21:21:27 --> Security Class Initialized
DEBUG - 2017-11-13 21:21:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-13 21:21:27 --> Input Class Initialized
INFO - 2017-11-13 21:21:27 --> Language Class Initialized
INFO - 2017-11-13 21:21:27 --> Language Class Initialized
INFO - 2017-11-13 21:21:27 --> Config Class Initialized
INFO - 2017-11-13 21:21:28 --> Loader Class Initialized
DEBUG - 2017-11-13 21:21:28 --> Config file loaded: C:\xampp\htdocs\construction_bay\application\config/construct-data.php
INFO - 2017-11-13 21:21:28 --> Helper loaded: url_helper
INFO - 2017-11-13 21:21:28 --> Helper loaded: form_helper
INFO - 2017-11-13 21:21:28 --> Helper loaded: date_helper
INFO - 2017-11-13 21:21:28 --> Helper loaded: util_helper
INFO - 2017-11-13 21:21:28 --> Helper loaded: text_helper
INFO - 2017-11-13 21:21:28 --> Helper loaded: string_helper
INFO - 2017-11-13 21:21:29 --> Database Driver Class Initialized
DEBUG - 2017-11-13 21:21:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-13 21:21:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-13 21:21:29 --> Email Class Initialized
INFO - 2017-11-13 21:21:29 --> Controller Class Initialized
DEBUG - 2017-11-13 21:21:29 --> Home MX_Controller Initialized
INFO - 2017-11-13 21:21:29 --> Model Class Initialized
DEBUG - 2017-11-13 21:21:30 --> File loaded: C:\xampp\htdocs\construction_bay\application\modules/common/models/Common_model.php
INFO - 2017-11-13 21:21:30 --> Model Class Initialized
DEBUG - 2017-11-13 21:21:31 --> File loaded: C:\xampp\htdocs\construction_bay\application\views\common/header.php
DEBUG - 2017-11-13 21:21:31 --> File loaded: C:\xampp\htdocs\construction_bay\application\views\common/slider.php
DEBUG - 2017-11-13 21:21:31 --> File loaded: C:\xampp\htdocs\construction_bay\application\views\common/index_body.php
DEBUG - 2017-11-13 21:21:31 --> File loaded: C:\xampp\htdocs\construction_bay\application\views\common/index_footer.php
INFO - 2017-11-13 21:21:32 --> Final output sent to browser
DEBUG - 2017-11-13 21:21:32 --> Total execution time: 6.8267
INFO - 2017-11-13 21:21:44 --> Config Class Initialized
INFO - 2017-11-13 21:21:44 --> Hooks Class Initialized
DEBUG - 2017-11-13 21:21:44 --> UTF-8 Support Enabled
INFO - 2017-11-13 21:21:44 --> Utf8 Class Initialized
INFO - 2017-11-13 21:21:44 --> URI Class Initialized
INFO - 2017-11-13 21:21:44 --> Router Class Initialized
INFO - 2017-11-13 21:21:44 --> Output Class Initialized
INFO - 2017-11-13 21:21:44 --> Security Class Initialized
DEBUG - 2017-11-13 21:21:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-13 21:21:45 --> Input Class Initialized
INFO - 2017-11-13 21:21:45 --> Language Class Initialized
ERROR - 2017-11-13 21:21:45 --> 404 Page Not Found: /index
INFO - 2017-11-13 21:21:46 --> Config Class Initialized
INFO - 2017-11-13 21:21:46 --> Hooks Class Initialized
DEBUG - 2017-11-13 21:21:46 --> UTF-8 Support Enabled
INFO - 2017-11-13 21:21:46 --> Utf8 Class Initialized
INFO - 2017-11-13 21:21:46 --> URI Class Initialized
INFO - 2017-11-13 21:21:47 --> Router Class Initialized
INFO - 2017-11-13 21:21:47 --> Output Class Initialized
INFO - 2017-11-13 21:21:47 --> Security Class Initialized
DEBUG - 2017-11-13 21:21:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-13 21:21:47 --> Input Class Initialized
INFO - 2017-11-13 21:21:47 --> Language Class Initialized
INFO - 2017-11-13 21:21:47 --> Language Class Initialized
INFO - 2017-11-13 21:21:47 --> Config Class Initialized
INFO - 2017-11-13 21:21:47 --> Loader Class Initialized
DEBUG - 2017-11-13 21:21:47 --> Config file loaded: C:\xampp\htdocs\construction_bay\application\config/construct-data.php
INFO - 2017-11-13 21:21:47 --> Helper loaded: url_helper
INFO - 2017-11-13 21:21:47 --> Helper loaded: form_helper
INFO - 2017-11-13 21:21:47 --> Helper loaded: date_helper
INFO - 2017-11-13 21:21:47 --> Helper loaded: util_helper
INFO - 2017-11-13 21:21:47 --> Helper loaded: text_helper
INFO - 2017-11-13 21:21:47 --> Helper loaded: string_helper
INFO - 2017-11-13 21:21:47 --> Database Driver Class Initialized
DEBUG - 2017-11-13 21:21:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-13 21:21:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-13 21:21:47 --> Email Class Initialized
INFO - 2017-11-13 21:21:47 --> Controller Class Initialized
INFO - 2017-11-13 21:21:47 --> Model Class Initialized
DEBUG - 2017-11-13 21:21:47 --> File loaded: C:\xampp\htdocs\construction_bay\application\modules/common/models/Common_model.php
INFO - 2017-11-13 21:21:47 --> Model Class Initialized
DEBUG - 2017-11-13 21:21:47 --> File loaded: C:\xampp\htdocs\construction_bay\application\modules/common/models/Common_functions_model.php
INFO - 2017-11-13 21:21:48 --> Model Class Initialized
ERROR - 2017-11-13 21:21:48 --> Severity: Notice --> Undefined variable: category C:\xampp\htdocs\construction_bay\application\views\common\header.php 305
DEBUG - 2017-11-13 21:21:48 --> File loaded: C:\xampp\htdocs\construction_bay\application\views\common/header.php
DEBUG - 2017-11-13 21:21:48 --> File loaded: C:\xampp\htdocs\construction_bay\application\views\projects/projects.php
DEBUG - 2017-11-13 21:21:48 --> File loaded: C:\xampp\htdocs\construction_bay\application\views\common/footer.php
INFO - 2017-11-13 21:21:48 --> Final output sent to browser
DEBUG - 2017-11-13 21:21:48 --> Total execution time: 2.1089
INFO - 2017-11-13 21:46:29 --> Config Class Initialized
INFO - 2017-11-13 21:46:29 --> Hooks Class Initialized
DEBUG - 2017-11-13 21:46:29 --> UTF-8 Support Enabled
INFO - 2017-11-13 21:46:30 --> Utf8 Class Initialized
INFO - 2017-11-13 21:46:30 --> URI Class Initialized
INFO - 2017-11-13 21:46:30 --> Router Class Initialized
INFO - 2017-11-13 21:46:30 --> Output Class Initialized
INFO - 2017-11-13 21:46:30 --> Security Class Initialized
DEBUG - 2017-11-13 21:46:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-13 21:46:30 --> Input Class Initialized
INFO - 2017-11-13 21:46:30 --> Language Class Initialized
INFO - 2017-11-13 21:46:30 --> Language Class Initialized
INFO - 2017-11-13 21:46:30 --> Config Class Initialized
INFO - 2017-11-13 21:46:30 --> Loader Class Initialized
DEBUG - 2017-11-13 21:46:30 --> Config file loaded: C:\xampp\htdocs\construction_bay\application\config/construct-data.php
INFO - 2017-11-13 21:46:30 --> Helper loaded: url_helper
INFO - 2017-11-13 21:46:30 --> Helper loaded: form_helper
INFO - 2017-11-13 21:46:30 --> Helper loaded: date_helper
INFO - 2017-11-13 21:46:30 --> Helper loaded: util_helper
INFO - 2017-11-13 21:46:30 --> Helper loaded: text_helper
INFO - 2017-11-13 21:46:30 --> Helper loaded: string_helper
INFO - 2017-11-13 21:46:30 --> Database Driver Class Initialized
DEBUG - 2017-11-13 21:46:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-13 21:46:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-13 21:46:30 --> Email Class Initialized
INFO - 2017-11-13 21:46:30 --> Controller Class Initialized
INFO - 2017-11-13 21:46:30 --> Model Class Initialized
DEBUG - 2017-11-13 21:46:31 --> File loaded: C:\xampp\htdocs\construction_bay\application\modules/common/models/Common_model.php
INFO - 2017-11-13 21:46:31 --> Model Class Initialized
DEBUG - 2017-11-13 21:46:31 --> File loaded: C:\xampp\htdocs\construction_bay\application\modules/common/models/Common_functions_model.php
INFO - 2017-11-13 21:46:31 --> Model Class Initialized
ERROR - 2017-11-13 21:46:31 --> Severity: Notice --> Undefined variable: category C:\xampp\htdocs\construction_bay\application\views\common\header.php 305
DEBUG - 2017-11-13 21:46:31 --> File loaded: C:\xampp\htdocs\construction_bay\application\views\common/header.php
DEBUG - 2017-11-13 21:46:31 --> File loaded: C:\xampp\htdocs\construction_bay\application\views\projects/projects.php
DEBUG - 2017-11-13 21:46:31 --> File loaded: C:\xampp\htdocs\construction_bay\application\views\common/footer.php
INFO - 2017-11-13 21:46:31 --> Final output sent to browser
DEBUG - 2017-11-13 21:46:31 --> Total execution time: 1.4873
INFO - 2017-11-13 21:46:35 --> Config Class Initialized
INFO - 2017-11-13 21:46:35 --> Hooks Class Initialized
DEBUG - 2017-11-13 21:46:36 --> UTF-8 Support Enabled
INFO - 2017-11-13 21:46:36 --> Utf8 Class Initialized
INFO - 2017-11-13 21:46:36 --> URI Class Initialized
INFO - 2017-11-13 21:46:36 --> Router Class Initialized
INFO - 2017-11-13 21:46:36 --> Output Class Initialized
INFO - 2017-11-13 21:46:36 --> Security Class Initialized
DEBUG - 2017-11-13 21:46:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-13 21:46:36 --> Input Class Initialized
INFO - 2017-11-13 21:46:36 --> Language Class Initialized
ERROR - 2017-11-13 21:46:36 --> 404 Page Not Found: /index
INFO - 2017-11-13 21:46:37 --> Config Class Initialized
INFO - 2017-11-13 21:46:37 --> Hooks Class Initialized
DEBUG - 2017-11-13 21:46:37 --> UTF-8 Support Enabled
INFO - 2017-11-13 21:46:37 --> Utf8 Class Initialized
INFO - 2017-11-13 21:46:37 --> URI Class Initialized
INFO - 2017-11-13 21:46:38 --> Router Class Initialized
INFO - 2017-11-13 21:46:38 --> Output Class Initialized
INFO - 2017-11-13 21:46:38 --> Security Class Initialized
DEBUG - 2017-11-13 21:46:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-13 21:46:38 --> Input Class Initialized
INFO - 2017-11-13 21:46:38 --> Language Class Initialized
ERROR - 2017-11-13 21:46:38 --> 404 Page Not Found: /index
