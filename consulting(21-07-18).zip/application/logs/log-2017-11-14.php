<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2017-11-14 10:39:36 --> Config Class Initialized
INFO - 2017-11-14 10:39:36 --> Hooks Class Initialized
DEBUG - 2017-11-14 10:39:36 --> UTF-8 Support Enabled
INFO - 2017-11-14 10:39:36 --> Utf8 Class Initialized
INFO - 2017-11-14 10:39:36 --> URI Class Initialized
DEBUG - 2017-11-14 10:39:36 --> No URI present. Default controller set.
INFO - 2017-11-14 10:39:36 --> Router Class Initialized
INFO - 2017-11-14 10:39:36 --> Output Class Initialized
INFO - 2017-11-14 10:39:36 --> Security Class Initialized
DEBUG - 2017-11-14 10:39:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 10:39:36 --> Input Class Initialized
INFO - 2017-11-14 10:39:36 --> Language Class Initialized
INFO - 2017-11-14 10:39:36 --> Language Class Initialized
INFO - 2017-11-14 10:39:36 --> Config Class Initialized
INFO - 2017-11-14 10:39:36 --> Loader Class Initialized
DEBUG - 2017-11-14 10:39:36 --> Config file loaded: D:\xampp\htdocs\construction_bay\application\config/construct-data.php
INFO - 2017-11-14 10:39:36 --> Helper loaded: url_helper
INFO - 2017-11-14 10:39:36 --> Helper loaded: form_helper
INFO - 2017-11-14 10:39:36 --> Helper loaded: date_helper
INFO - 2017-11-14 10:39:36 --> Helper loaded: util_helper
INFO - 2017-11-14 10:39:36 --> Helper loaded: text_helper
INFO - 2017-11-14 10:39:36 --> Helper loaded: string_helper
INFO - 2017-11-14 10:39:36 --> Database Driver Class Initialized
DEBUG - 2017-11-14 10:39:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-14 10:39:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-14 10:39:36 --> Email Class Initialized
INFO - 2017-11-14 10:39:36 --> Controller Class Initialized
DEBUG - 2017-11-14 10:39:36 --> Home MX_Controller Initialized
INFO - 2017-11-14 10:39:36 --> Model Class Initialized
DEBUG - 2017-11-14 10:39:36 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_model.php
INFO - 2017-11-14 10:39:36 --> Model Class Initialized
DEBUG - 2017-11-14 10:39:36 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header.php
DEBUG - 2017-11-14 10:39:36 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/slider.php
DEBUG - 2017-11-14 10:39:36 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/index_body.php
DEBUG - 2017-11-14 10:39:36 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/index_footer.php
INFO - 2017-11-14 10:39:36 --> Final output sent to browser
DEBUG - 2017-11-14 10:39:36 --> Total execution time: 0.3350
INFO - 2017-11-14 10:39:36 --> Config Class Initialized
INFO - 2017-11-14 10:39:36 --> Hooks Class Initialized
DEBUG - 2017-11-14 10:39:36 --> UTF-8 Support Enabled
INFO - 2017-11-14 10:39:36 --> Utf8 Class Initialized
INFO - 2017-11-14 10:39:36 --> URI Class Initialized
INFO - 2017-11-14 10:39:36 --> Router Class Initialized
INFO - 2017-11-14 10:39:36 --> Output Class Initialized
INFO - 2017-11-14 10:39:36 --> Security Class Initialized
DEBUG - 2017-11-14 10:39:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 10:39:36 --> Input Class Initialized
INFO - 2017-11-14 10:39:36 --> Language Class Initialized
ERROR - 2017-11-14 10:39:36 --> 404 Page Not Found: /index
INFO - 2017-11-14 10:39:37 --> Config Class Initialized
INFO - 2017-11-14 10:39:37 --> Hooks Class Initialized
DEBUG - 2017-11-14 10:39:37 --> UTF-8 Support Enabled
INFO - 2017-11-14 10:39:37 --> Utf8 Class Initialized
INFO - 2017-11-14 10:39:37 --> URI Class Initialized
INFO - 2017-11-14 10:39:37 --> Router Class Initialized
INFO - 2017-11-14 10:39:37 --> Output Class Initialized
INFO - 2017-11-14 10:39:37 --> Security Class Initialized
DEBUG - 2017-11-14 10:39:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 10:39:37 --> Input Class Initialized
INFO - 2017-11-14 10:39:37 --> Language Class Initialized
ERROR - 2017-11-14 10:39:37 --> 404 Page Not Found: /index
INFO - 2017-11-14 10:43:35 --> Config Class Initialized
INFO - 2017-11-14 10:43:35 --> Hooks Class Initialized
DEBUG - 2017-11-14 10:43:35 --> UTF-8 Support Enabled
INFO - 2017-11-14 10:43:35 --> Utf8 Class Initialized
INFO - 2017-11-14 10:43:35 --> URI Class Initialized
INFO - 2017-11-14 10:43:35 --> Router Class Initialized
INFO - 2017-11-14 10:43:35 --> Output Class Initialized
INFO - 2017-11-14 10:43:35 --> Security Class Initialized
DEBUG - 2017-11-14 10:43:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 10:43:35 --> Input Class Initialized
INFO - 2017-11-14 10:43:35 --> Language Class Initialized
INFO - 2017-11-14 10:43:35 --> Language Class Initialized
INFO - 2017-11-14 10:43:35 --> Config Class Initialized
INFO - 2017-11-14 10:43:35 --> Loader Class Initialized
DEBUG - 2017-11-14 10:43:35 --> Config file loaded: D:\xampp\htdocs\construction_bay\application\config/construct-data.php
INFO - 2017-11-14 10:43:35 --> Helper loaded: url_helper
INFO - 2017-11-14 10:43:35 --> Helper loaded: form_helper
INFO - 2017-11-14 10:43:35 --> Helper loaded: date_helper
INFO - 2017-11-14 10:43:35 --> Helper loaded: util_helper
INFO - 2017-11-14 10:43:35 --> Helper loaded: text_helper
INFO - 2017-11-14 10:43:35 --> Helper loaded: string_helper
INFO - 2017-11-14 10:43:35 --> Database Driver Class Initialized
DEBUG - 2017-11-14 10:43:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-14 10:43:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-14 10:43:35 --> Email Class Initialized
INFO - 2017-11-14 10:43:35 --> Controller Class Initialized
INFO - 2017-11-14 10:43:35 --> Model Class Initialized
DEBUG - 2017-11-14 10:43:35 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_model.php
INFO - 2017-11-14 10:43:35 --> Model Class Initialized
DEBUG - 2017-11-14 10:43:35 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_functions_model.php
INFO - 2017-11-14 10:43:35 --> Model Class Initialized
ERROR - 2017-11-14 10:43:36 --> Severity: Notice --> Undefined variable: category D:\xampp\htdocs\construction_bay\application\views\common\header.php 305
DEBUG - 2017-11-14 10:43:36 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header.php
DEBUG - 2017-11-14 10:43:36 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\interior-design.php
DEBUG - 2017-11-14 10:43:36 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/footer.php
INFO - 2017-11-14 10:43:36 --> Final output sent to browser
DEBUG - 2017-11-14 10:43:36 --> Total execution time: 0.0900
INFO - 2017-11-14 10:43:37 --> Config Class Initialized
INFO - 2017-11-14 10:43:37 --> Hooks Class Initialized
DEBUG - 2017-11-14 10:43:37 --> UTF-8 Support Enabled
INFO - 2017-11-14 10:43:37 --> Utf8 Class Initialized
INFO - 2017-11-14 10:43:37 --> URI Class Initialized
INFO - 2017-11-14 10:43:37 --> Router Class Initialized
INFO - 2017-11-14 10:43:37 --> Output Class Initialized
INFO - 2017-11-14 10:43:37 --> Security Class Initialized
DEBUG - 2017-11-14 10:43:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 10:43:37 --> Input Class Initialized
INFO - 2017-11-14 10:43:37 --> Language Class Initialized
ERROR - 2017-11-14 10:43:37 --> 404 Page Not Found: Companies/favicon.ico
INFO - 2017-11-14 10:43:38 --> Config Class Initialized
INFO - 2017-11-14 10:43:38 --> Hooks Class Initialized
DEBUG - 2017-11-14 10:43:38 --> UTF-8 Support Enabled
INFO - 2017-11-14 10:43:38 --> Utf8 Class Initialized
INFO - 2017-11-14 10:43:38 --> URI Class Initialized
DEBUG - 2017-11-14 10:43:38 --> No URI present. Default controller set.
INFO - 2017-11-14 10:43:38 --> Router Class Initialized
INFO - 2017-11-14 10:43:38 --> Output Class Initialized
INFO - 2017-11-14 10:43:38 --> Security Class Initialized
DEBUG - 2017-11-14 10:43:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 10:43:38 --> Input Class Initialized
INFO - 2017-11-14 10:43:38 --> Language Class Initialized
INFO - 2017-11-14 10:43:38 --> Language Class Initialized
INFO - 2017-11-14 10:43:38 --> Config Class Initialized
INFO - 2017-11-14 10:43:38 --> Loader Class Initialized
DEBUG - 2017-11-14 10:43:38 --> Config file loaded: D:\xampp\htdocs\construction_bay\application\config/construct-data.php
INFO - 2017-11-14 10:43:38 --> Helper loaded: url_helper
INFO - 2017-11-14 10:43:38 --> Helper loaded: form_helper
INFO - 2017-11-14 10:43:38 --> Helper loaded: date_helper
INFO - 2017-11-14 10:43:38 --> Helper loaded: util_helper
INFO - 2017-11-14 10:43:38 --> Helper loaded: text_helper
INFO - 2017-11-14 10:43:38 --> Helper loaded: string_helper
INFO - 2017-11-14 10:43:38 --> Database Driver Class Initialized
DEBUG - 2017-11-14 10:43:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-14 10:43:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-14 10:43:38 --> Email Class Initialized
INFO - 2017-11-14 10:43:38 --> Controller Class Initialized
DEBUG - 2017-11-14 10:43:38 --> Home MX_Controller Initialized
INFO - 2017-11-14 10:43:38 --> Model Class Initialized
DEBUG - 2017-11-14 10:43:38 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_model.php
INFO - 2017-11-14 10:43:38 --> Model Class Initialized
DEBUG - 2017-11-14 10:43:38 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header.php
DEBUG - 2017-11-14 10:43:38 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/slider.php
DEBUG - 2017-11-14 10:43:38 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/index_body.php
DEBUG - 2017-11-14 10:43:38 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/index_footer.php
INFO - 2017-11-14 10:43:38 --> Final output sent to browser
DEBUG - 2017-11-14 10:43:38 --> Total execution time: 0.0810
INFO - 2017-11-14 10:46:26 --> Config Class Initialized
INFO - 2017-11-14 10:46:26 --> Hooks Class Initialized
DEBUG - 2017-11-14 10:46:26 --> UTF-8 Support Enabled
INFO - 2017-11-14 10:46:26 --> Utf8 Class Initialized
INFO - 2017-11-14 10:46:26 --> URI Class Initialized
DEBUG - 2017-11-14 10:46:26 --> No URI present. Default controller set.
INFO - 2017-11-14 10:46:26 --> Router Class Initialized
INFO - 2017-11-14 10:46:26 --> Output Class Initialized
INFO - 2017-11-14 10:46:26 --> Security Class Initialized
DEBUG - 2017-11-14 10:46:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 10:46:26 --> Input Class Initialized
INFO - 2017-11-14 10:46:26 --> Language Class Initialized
INFO - 2017-11-14 10:46:26 --> Language Class Initialized
INFO - 2017-11-14 10:46:26 --> Config Class Initialized
INFO - 2017-11-14 10:46:26 --> Loader Class Initialized
DEBUG - 2017-11-14 10:46:26 --> Config file loaded: D:\xampp\htdocs\construction_bay\application\config/construct-data.php
INFO - 2017-11-14 10:46:26 --> Helper loaded: url_helper
INFO - 2017-11-14 10:46:26 --> Helper loaded: form_helper
INFO - 2017-11-14 10:46:26 --> Helper loaded: date_helper
INFO - 2017-11-14 10:46:26 --> Helper loaded: util_helper
INFO - 2017-11-14 10:46:26 --> Helper loaded: text_helper
INFO - 2017-11-14 10:46:26 --> Helper loaded: string_helper
INFO - 2017-11-14 10:46:26 --> Database Driver Class Initialized
DEBUG - 2017-11-14 10:46:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-14 10:46:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-14 10:46:26 --> Email Class Initialized
INFO - 2017-11-14 10:46:26 --> Controller Class Initialized
DEBUG - 2017-11-14 10:46:26 --> Home MX_Controller Initialized
INFO - 2017-11-14 10:46:26 --> Model Class Initialized
DEBUG - 2017-11-14 10:46:26 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_model.php
INFO - 2017-11-14 10:46:26 --> Model Class Initialized
DEBUG - 2017-11-14 10:46:26 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header.php
DEBUG - 2017-11-14 10:46:26 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/slider.php
DEBUG - 2017-11-14 10:46:26 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/index_body.php
DEBUG - 2017-11-14 10:46:26 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/index_footer.php
INFO - 2017-11-14 10:46:26 --> Final output sent to browser
DEBUG - 2017-11-14 10:46:26 --> Total execution time: 0.0610
INFO - 2017-11-14 11:00:49 --> Config Class Initialized
INFO - 2017-11-14 11:00:49 --> Hooks Class Initialized
DEBUG - 2017-11-14 11:00:49 --> UTF-8 Support Enabled
INFO - 2017-11-14 11:00:49 --> Utf8 Class Initialized
INFO - 2017-11-14 11:00:49 --> URI Class Initialized
INFO - 2017-11-14 11:00:49 --> Router Class Initialized
INFO - 2017-11-14 11:00:49 --> Output Class Initialized
INFO - 2017-11-14 11:00:49 --> Security Class Initialized
DEBUG - 2017-11-14 11:00:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 11:00:49 --> Input Class Initialized
INFO - 2017-11-14 11:00:49 --> Language Class Initialized
INFO - 2017-11-14 11:00:49 --> Language Class Initialized
INFO - 2017-11-14 11:00:49 --> Config Class Initialized
INFO - 2017-11-14 11:00:49 --> Loader Class Initialized
DEBUG - 2017-11-14 11:00:49 --> Config file loaded: D:\xampp\htdocs\construction_bay\application\config/construct-data.php
INFO - 2017-11-14 11:00:49 --> Helper loaded: url_helper
INFO - 2017-11-14 11:00:49 --> Helper loaded: form_helper
INFO - 2017-11-14 11:00:49 --> Helper loaded: date_helper
INFO - 2017-11-14 11:00:49 --> Helper loaded: util_helper
INFO - 2017-11-14 11:00:49 --> Helper loaded: text_helper
INFO - 2017-11-14 11:00:49 --> Helper loaded: string_helper
INFO - 2017-11-14 11:00:49 --> Database Driver Class Initialized
DEBUG - 2017-11-14 11:00:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-14 11:00:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-14 11:00:49 --> Email Class Initialized
INFO - 2017-11-14 11:00:49 --> Controller Class Initialized
INFO - 2017-11-14 11:00:49 --> Model Class Initialized
DEBUG - 2017-11-14 11:00:49 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_model.php
INFO - 2017-11-14 11:00:49 --> Model Class Initialized
DEBUG - 2017-11-14 11:00:49 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_functions_model.php
INFO - 2017-11-14 11:00:49 --> Model Class Initialized
ERROR - 2017-11-14 11:00:49 --> Severity: Notice --> Undefined variable: category D:\xampp\htdocs\construction_bay\application\views\common\header.php 305
DEBUG - 2017-11-14 11:00:49 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header.php
DEBUG - 2017-11-14 11:00:49 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\projects/projects.php
DEBUG - 2017-11-14 11:00:49 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/footer.php
INFO - 2017-11-14 11:00:49 --> Final output sent to browser
DEBUG - 2017-11-14 11:00:49 --> Total execution time: 0.0600
INFO - 2017-11-14 11:00:53 --> Config Class Initialized
INFO - 2017-11-14 11:00:53 --> Hooks Class Initialized
DEBUG - 2017-11-14 11:00:53 --> UTF-8 Support Enabled
INFO - 2017-11-14 11:00:53 --> Utf8 Class Initialized
INFO - 2017-11-14 11:00:53 --> URI Class Initialized
INFO - 2017-11-14 11:00:53 --> Router Class Initialized
INFO - 2017-11-14 11:00:53 --> Output Class Initialized
INFO - 2017-11-14 11:00:53 --> Security Class Initialized
DEBUG - 2017-11-14 11:00:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 11:00:53 --> Input Class Initialized
INFO - 2017-11-14 11:00:53 --> Language Class Initialized
ERROR - 2017-11-14 11:00:53 --> 404 Page Not Found: /index
INFO - 2017-11-14 11:01:24 --> Config Class Initialized
INFO - 2017-11-14 11:01:24 --> Hooks Class Initialized
DEBUG - 2017-11-14 11:01:24 --> UTF-8 Support Enabled
INFO - 2017-11-14 11:01:24 --> Utf8 Class Initialized
INFO - 2017-11-14 11:01:24 --> URI Class Initialized
INFO - 2017-11-14 11:01:24 --> Router Class Initialized
INFO - 2017-11-14 11:01:24 --> Output Class Initialized
INFO - 2017-11-14 11:01:24 --> Security Class Initialized
DEBUG - 2017-11-14 11:01:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 11:01:24 --> Input Class Initialized
INFO - 2017-11-14 11:01:24 --> Language Class Initialized
INFO - 2017-11-14 11:01:24 --> Language Class Initialized
INFO - 2017-11-14 11:01:24 --> Config Class Initialized
INFO - 2017-11-14 11:01:24 --> Loader Class Initialized
DEBUG - 2017-11-14 11:01:24 --> Config file loaded: D:\xampp\htdocs\construction_bay\application\config/construct-data.php
INFO - 2017-11-14 11:01:24 --> Helper loaded: url_helper
INFO - 2017-11-14 11:01:24 --> Helper loaded: form_helper
INFO - 2017-11-14 11:01:24 --> Helper loaded: date_helper
INFO - 2017-11-14 11:01:24 --> Helper loaded: util_helper
INFO - 2017-11-14 11:01:24 --> Helper loaded: text_helper
INFO - 2017-11-14 11:01:24 --> Helper loaded: string_helper
INFO - 2017-11-14 11:01:24 --> Database Driver Class Initialized
DEBUG - 2017-11-14 11:01:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-14 11:01:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-14 11:01:25 --> Email Class Initialized
INFO - 2017-11-14 11:01:25 --> Controller Class Initialized
INFO - 2017-11-14 11:01:25 --> Model Class Initialized
DEBUG - 2017-11-14 11:01:25 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_model.php
INFO - 2017-11-14 11:01:25 --> Model Class Initialized
DEBUG - 2017-11-14 11:01:25 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_functions_model.php
INFO - 2017-11-14 11:01:25 --> Model Class Initialized
ERROR - 2017-11-14 11:01:25 --> Severity: Notice --> Undefined variable: category D:\xampp\htdocs\construction_bay\application\views\common\header.php 305
DEBUG - 2017-11-14 11:01:25 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header.php
DEBUG - 2017-11-14 11:01:25 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\projects/projects.php
DEBUG - 2017-11-14 11:01:25 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/footer.php
INFO - 2017-11-14 11:01:25 --> Final output sent to browser
DEBUG - 2017-11-14 11:01:25 --> Total execution time: 0.0670
INFO - 2017-11-14 11:01:27 --> Config Class Initialized
INFO - 2017-11-14 11:01:27 --> Hooks Class Initialized
DEBUG - 2017-11-14 11:01:27 --> UTF-8 Support Enabled
INFO - 2017-11-14 11:01:27 --> Utf8 Class Initialized
INFO - 2017-11-14 11:01:27 --> URI Class Initialized
INFO - 2017-11-14 11:01:27 --> Router Class Initialized
INFO - 2017-11-14 11:01:27 --> Output Class Initialized
INFO - 2017-11-14 11:01:27 --> Security Class Initialized
DEBUG - 2017-11-14 11:01:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 11:01:27 --> Input Class Initialized
INFO - 2017-11-14 11:01:27 --> Language Class Initialized
ERROR - 2017-11-14 11:01:27 --> 404 Page Not Found: /index
INFO - 2017-11-14 11:01:31 --> Config Class Initialized
INFO - 2017-11-14 11:01:31 --> Hooks Class Initialized
DEBUG - 2017-11-14 11:01:31 --> UTF-8 Support Enabled
INFO - 2017-11-14 11:01:31 --> Utf8 Class Initialized
INFO - 2017-11-14 11:01:31 --> URI Class Initialized
INFO - 2017-11-14 11:01:31 --> Router Class Initialized
INFO - 2017-11-14 11:01:31 --> Output Class Initialized
INFO - 2017-11-14 11:01:31 --> Security Class Initialized
DEBUG - 2017-11-14 11:01:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 11:01:31 --> Input Class Initialized
INFO - 2017-11-14 11:01:31 --> Language Class Initialized
INFO - 2017-11-14 11:01:31 --> Language Class Initialized
INFO - 2017-11-14 11:01:31 --> Config Class Initialized
INFO - 2017-11-14 11:01:31 --> Loader Class Initialized
DEBUG - 2017-11-14 11:01:31 --> Config file loaded: D:\xampp\htdocs\construction_bay\application\config/construct-data.php
INFO - 2017-11-14 11:01:31 --> Helper loaded: url_helper
INFO - 2017-11-14 11:01:31 --> Helper loaded: form_helper
INFO - 2017-11-14 11:01:31 --> Helper loaded: date_helper
INFO - 2017-11-14 11:01:31 --> Helper loaded: util_helper
INFO - 2017-11-14 11:01:31 --> Helper loaded: text_helper
INFO - 2017-11-14 11:01:31 --> Helper loaded: string_helper
INFO - 2017-11-14 11:01:31 --> Database Driver Class Initialized
DEBUG - 2017-11-14 11:01:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-14 11:01:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-14 11:01:31 --> Email Class Initialized
INFO - 2017-11-14 11:01:31 --> Controller Class Initialized
INFO - 2017-11-14 11:01:31 --> Model Class Initialized
DEBUG - 2017-11-14 11:01:31 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_model.php
INFO - 2017-11-14 11:01:31 --> Model Class Initialized
DEBUG - 2017-11-14 11:01:31 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_functions_model.php
INFO - 2017-11-14 11:01:31 --> Model Class Initialized
ERROR - 2017-11-14 11:01:31 --> Severity: Notice --> Undefined variable: category D:\xampp\htdocs\construction_bay\application\views\common\header.php 305
DEBUG - 2017-11-14 11:01:31 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header.php
DEBUG - 2017-11-14 11:01:31 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\projects/projects.php
DEBUG - 2017-11-14 11:01:31 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/footer.php
INFO - 2017-11-14 11:01:31 --> Final output sent to browser
DEBUG - 2017-11-14 11:01:31 --> Total execution time: 0.0620
INFO - 2017-11-14 11:01:33 --> Config Class Initialized
INFO - 2017-11-14 11:01:33 --> Hooks Class Initialized
DEBUG - 2017-11-14 11:01:33 --> UTF-8 Support Enabled
INFO - 2017-11-14 11:01:33 --> Utf8 Class Initialized
INFO - 2017-11-14 11:01:33 --> URI Class Initialized
DEBUG - 2017-11-14 11:01:33 --> No URI present. Default controller set.
INFO - 2017-11-14 11:01:33 --> Router Class Initialized
INFO - 2017-11-14 11:01:33 --> Output Class Initialized
INFO - 2017-11-14 11:01:33 --> Security Class Initialized
DEBUG - 2017-11-14 11:01:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 11:01:33 --> Input Class Initialized
INFO - 2017-11-14 11:01:33 --> Language Class Initialized
INFO - 2017-11-14 11:01:33 --> Language Class Initialized
INFO - 2017-11-14 11:01:33 --> Config Class Initialized
INFO - 2017-11-14 11:01:33 --> Loader Class Initialized
DEBUG - 2017-11-14 11:01:33 --> Config file loaded: D:\xampp\htdocs\construction_bay\application\config/construct-data.php
INFO - 2017-11-14 11:01:33 --> Helper loaded: url_helper
INFO - 2017-11-14 11:01:33 --> Helper loaded: form_helper
INFO - 2017-11-14 11:01:33 --> Helper loaded: date_helper
INFO - 2017-11-14 11:01:33 --> Helper loaded: util_helper
INFO - 2017-11-14 11:01:33 --> Helper loaded: text_helper
INFO - 2017-11-14 11:01:33 --> Helper loaded: string_helper
INFO - 2017-11-14 11:01:33 --> Database Driver Class Initialized
DEBUG - 2017-11-14 11:01:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-14 11:01:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-14 11:01:33 --> Email Class Initialized
INFO - 2017-11-14 11:01:33 --> Controller Class Initialized
DEBUG - 2017-11-14 11:01:33 --> Home MX_Controller Initialized
INFO - 2017-11-14 11:01:33 --> Model Class Initialized
DEBUG - 2017-11-14 11:01:33 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_model.php
INFO - 2017-11-14 11:01:33 --> Model Class Initialized
DEBUG - 2017-11-14 11:01:33 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header.php
DEBUG - 2017-11-14 11:01:33 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/slider.php
DEBUG - 2017-11-14 11:01:33 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/index_body.php
DEBUG - 2017-11-14 11:01:33 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/index_footer.php
INFO - 2017-11-14 11:01:33 --> Final output sent to browser
DEBUG - 2017-11-14 11:01:33 --> Total execution time: 0.0540
INFO - 2017-11-14 11:27:00 --> Config Class Initialized
INFO - 2017-11-14 11:27:00 --> Hooks Class Initialized
DEBUG - 2017-11-14 11:27:00 --> UTF-8 Support Enabled
INFO - 2017-11-14 11:27:00 --> Utf8 Class Initialized
INFO - 2017-11-14 11:27:00 --> URI Class Initialized
DEBUG - 2017-11-14 11:27:00 --> No URI present. Default controller set.
INFO - 2017-11-14 11:27:00 --> Router Class Initialized
INFO - 2017-11-14 11:27:00 --> Output Class Initialized
INFO - 2017-11-14 11:27:00 --> Security Class Initialized
DEBUG - 2017-11-14 11:27:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 11:27:00 --> Input Class Initialized
INFO - 2017-11-14 11:27:00 --> Language Class Initialized
INFO - 2017-11-14 11:27:00 --> Language Class Initialized
INFO - 2017-11-14 11:27:00 --> Config Class Initialized
INFO - 2017-11-14 11:27:00 --> Loader Class Initialized
DEBUG - 2017-11-14 11:27:00 --> Config file loaded: D:\xampp\htdocs\construction_bay\application\config/construct-data.php
INFO - 2017-11-14 11:27:00 --> Helper loaded: url_helper
INFO - 2017-11-14 11:27:00 --> Helper loaded: form_helper
INFO - 2017-11-14 11:27:00 --> Helper loaded: date_helper
INFO - 2017-11-14 11:27:00 --> Helper loaded: util_helper
INFO - 2017-11-14 11:27:00 --> Helper loaded: text_helper
INFO - 2017-11-14 11:27:00 --> Helper loaded: string_helper
INFO - 2017-11-14 11:27:00 --> Database Driver Class Initialized
DEBUG - 2017-11-14 11:27:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-14 11:27:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-14 11:27:00 --> Email Class Initialized
INFO - 2017-11-14 11:27:00 --> Controller Class Initialized
DEBUG - 2017-11-14 11:27:00 --> Home MX_Controller Initialized
INFO - 2017-11-14 11:27:00 --> Model Class Initialized
DEBUG - 2017-11-14 11:27:00 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_model.php
INFO - 2017-11-14 11:27:00 --> Model Class Initialized
DEBUG - 2017-11-14 11:27:00 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header.php
DEBUG - 2017-11-14 11:27:00 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/slider.php
DEBUG - 2017-11-14 11:27:00 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/index_body.php
DEBUG - 2017-11-14 11:27:00 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/index_footer.php
INFO - 2017-11-14 11:27:00 --> Final output sent to browser
DEBUG - 2017-11-14 11:27:00 --> Total execution time: 0.0560
INFO - 2017-11-14 11:33:05 --> Config Class Initialized
INFO - 2017-11-14 11:33:05 --> Hooks Class Initialized
DEBUG - 2017-11-14 11:33:05 --> UTF-8 Support Enabled
INFO - 2017-11-14 11:33:05 --> Utf8 Class Initialized
INFO - 2017-11-14 11:33:05 --> URI Class Initialized
DEBUG - 2017-11-14 11:33:05 --> No URI present. Default controller set.
INFO - 2017-11-14 11:33:05 --> Router Class Initialized
INFO - 2017-11-14 11:33:05 --> Output Class Initialized
INFO - 2017-11-14 11:33:05 --> Security Class Initialized
DEBUG - 2017-11-14 11:33:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 11:33:05 --> Input Class Initialized
INFO - 2017-11-14 11:33:05 --> Language Class Initialized
INFO - 2017-11-14 11:33:05 --> Language Class Initialized
INFO - 2017-11-14 11:33:05 --> Config Class Initialized
INFO - 2017-11-14 11:33:05 --> Loader Class Initialized
DEBUG - 2017-11-14 11:33:05 --> Config file loaded: D:\xampp\htdocs\construction_bay\application\config/construct-data.php
INFO - 2017-11-14 11:33:05 --> Helper loaded: url_helper
INFO - 2017-11-14 11:33:05 --> Helper loaded: form_helper
INFO - 2017-11-14 11:33:05 --> Helper loaded: date_helper
INFO - 2017-11-14 11:33:05 --> Helper loaded: util_helper
INFO - 2017-11-14 11:33:05 --> Helper loaded: text_helper
INFO - 2017-11-14 11:33:05 --> Helper loaded: string_helper
INFO - 2017-11-14 11:33:05 --> Database Driver Class Initialized
DEBUG - 2017-11-14 11:33:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-14 11:33:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-14 11:33:05 --> Email Class Initialized
INFO - 2017-11-14 11:33:05 --> Controller Class Initialized
DEBUG - 2017-11-14 11:33:05 --> Home MX_Controller Initialized
INFO - 2017-11-14 11:33:05 --> Model Class Initialized
DEBUG - 2017-11-14 11:33:05 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_model.php
INFO - 2017-11-14 11:33:05 --> Model Class Initialized
DEBUG - 2017-11-14 11:33:05 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header.php
DEBUG - 2017-11-14 11:33:05 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/slider.php
DEBUG - 2017-11-14 11:33:05 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/index_body.php
DEBUG - 2017-11-14 11:33:05 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/index_footer.php
INFO - 2017-11-14 11:33:05 --> Final output sent to browser
DEBUG - 2017-11-14 11:33:05 --> Total execution time: 0.0780
INFO - 2017-11-14 11:38:49 --> Config Class Initialized
INFO - 2017-11-14 11:38:49 --> Hooks Class Initialized
DEBUG - 2017-11-14 11:38:49 --> UTF-8 Support Enabled
INFO - 2017-11-14 11:38:49 --> Utf8 Class Initialized
INFO - 2017-11-14 11:38:49 --> URI Class Initialized
DEBUG - 2017-11-14 11:38:49 --> No URI present. Default controller set.
INFO - 2017-11-14 11:38:49 --> Router Class Initialized
INFO - 2017-11-14 11:38:49 --> Output Class Initialized
INFO - 2017-11-14 11:38:49 --> Security Class Initialized
DEBUG - 2017-11-14 11:38:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 11:38:49 --> Input Class Initialized
INFO - 2017-11-14 11:38:49 --> Language Class Initialized
INFO - 2017-11-14 11:38:49 --> Language Class Initialized
INFO - 2017-11-14 11:38:49 --> Config Class Initialized
INFO - 2017-11-14 11:38:49 --> Loader Class Initialized
DEBUG - 2017-11-14 11:38:49 --> Config file loaded: D:\xampp\htdocs\construction_bay\application\config/construct-data.php
INFO - 2017-11-14 11:38:49 --> Helper loaded: url_helper
INFO - 2017-11-14 11:38:49 --> Helper loaded: form_helper
INFO - 2017-11-14 11:38:49 --> Helper loaded: date_helper
INFO - 2017-11-14 11:38:49 --> Helper loaded: util_helper
INFO - 2017-11-14 11:38:49 --> Helper loaded: text_helper
INFO - 2017-11-14 11:38:49 --> Helper loaded: string_helper
INFO - 2017-11-14 11:38:49 --> Database Driver Class Initialized
DEBUG - 2017-11-14 11:38:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-14 11:38:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-14 11:38:49 --> Email Class Initialized
INFO - 2017-11-14 11:38:49 --> Controller Class Initialized
DEBUG - 2017-11-14 11:38:49 --> Home MX_Controller Initialized
INFO - 2017-11-14 11:38:49 --> Model Class Initialized
DEBUG - 2017-11-14 11:38:49 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_model.php
INFO - 2017-11-14 11:38:49 --> Model Class Initialized
DEBUG - 2017-11-14 11:38:49 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header.php
DEBUG - 2017-11-14 11:38:49 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/slider.php
DEBUG - 2017-11-14 11:38:49 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/index_body.php
DEBUG - 2017-11-14 11:38:49 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/index_footer.php
INFO - 2017-11-14 11:38:49 --> Final output sent to browser
DEBUG - 2017-11-14 11:38:49 --> Total execution time: 0.0930
INFO - 2017-11-14 11:50:13 --> Config Class Initialized
INFO - 2017-11-14 11:50:13 --> Hooks Class Initialized
DEBUG - 2017-11-14 11:50:13 --> UTF-8 Support Enabled
INFO - 2017-11-14 11:50:13 --> Utf8 Class Initialized
INFO - 2017-11-14 11:50:13 --> URI Class Initialized
INFO - 2017-11-14 11:50:13 --> Router Class Initialized
INFO - 2017-11-14 11:50:13 --> Output Class Initialized
INFO - 2017-11-14 11:50:13 --> Security Class Initialized
DEBUG - 2017-11-14 11:50:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 11:50:13 --> Input Class Initialized
INFO - 2017-11-14 11:50:13 --> Language Class Initialized
INFO - 2017-11-14 11:50:13 --> Language Class Initialized
INFO - 2017-11-14 11:50:13 --> Config Class Initialized
INFO - 2017-11-14 11:50:13 --> Loader Class Initialized
DEBUG - 2017-11-14 11:50:13 --> Config file loaded: D:\xampp\htdocs\construction_bay\application\config/construct-data.php
INFO - 2017-11-14 11:50:13 --> Helper loaded: url_helper
INFO - 2017-11-14 11:50:13 --> Helper loaded: form_helper
INFO - 2017-11-14 11:50:13 --> Helper loaded: date_helper
INFO - 2017-11-14 11:50:13 --> Helper loaded: util_helper
INFO - 2017-11-14 11:50:13 --> Helper loaded: text_helper
INFO - 2017-11-14 11:50:13 --> Helper loaded: string_helper
INFO - 2017-11-14 11:50:13 --> Database Driver Class Initialized
DEBUG - 2017-11-14 11:50:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-14 11:50:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-14 11:50:13 --> Email Class Initialized
INFO - 2017-11-14 11:50:13 --> Controller Class Initialized
INFO - 2017-11-14 11:50:13 --> Model Class Initialized
DEBUG - 2017-11-14 11:50:13 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_model.php
INFO - 2017-11-14 11:50:13 --> Model Class Initialized
DEBUG - 2017-11-14 11:50:13 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_functions_model.php
INFO - 2017-11-14 11:50:13 --> Model Class Initialized
DEBUG - 2017-11-14 11:50:13 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\companies/companies_header.php
DEBUG - 2017-11-14 11:50:13 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\companies/companies_page.php
DEBUG - 2017-11-14 11:50:13 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\companies/companies_footer.php
INFO - 2017-11-14 11:50:13 --> Final output sent to browser
DEBUG - 2017-11-14 11:50:13 --> Total execution time: 0.1010
INFO - 2017-11-14 11:50:15 --> Config Class Initialized
INFO - 2017-11-14 11:50:15 --> Hooks Class Initialized
DEBUG - 2017-11-14 11:50:15 --> UTF-8 Support Enabled
INFO - 2017-11-14 11:50:15 --> Utf8 Class Initialized
INFO - 2017-11-14 11:50:15 --> URI Class Initialized
INFO - 2017-11-14 11:50:15 --> Router Class Initialized
INFO - 2017-11-14 11:50:15 --> Output Class Initialized
INFO - 2017-11-14 11:50:15 --> Security Class Initialized
DEBUG - 2017-11-14 11:50:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 11:50:15 --> Input Class Initialized
INFO - 2017-11-14 11:50:15 --> Language Class Initialized
INFO - 2017-11-14 11:50:15 --> Language Class Initialized
INFO - 2017-11-14 11:50:15 --> Config Class Initialized
INFO - 2017-11-14 11:50:15 --> Loader Class Initialized
DEBUG - 2017-11-14 11:50:15 --> Config file loaded: D:\xampp\htdocs\construction_bay\application\config/construct-data.php
INFO - 2017-11-14 11:50:15 --> Helper loaded: url_helper
INFO - 2017-11-14 11:50:15 --> Helper loaded: form_helper
INFO - 2017-11-14 11:50:15 --> Helper loaded: date_helper
INFO - 2017-11-14 11:50:15 --> Helper loaded: util_helper
INFO - 2017-11-14 11:50:15 --> Helper loaded: text_helper
INFO - 2017-11-14 11:50:15 --> Helper loaded: string_helper
INFO - 2017-11-14 11:50:15 --> Database Driver Class Initialized
DEBUG - 2017-11-14 11:50:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-14 11:50:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-14 11:50:15 --> Email Class Initialized
INFO - 2017-11-14 11:50:15 --> Controller Class Initialized
INFO - 2017-11-14 11:50:15 --> Model Class Initialized
DEBUG - 2017-11-14 11:50:15 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_model.php
INFO - 2017-11-14 11:50:15 --> Model Class Initialized
DEBUG - 2017-11-14 11:50:15 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_functions_model.php
INFO - 2017-11-14 11:50:15 --> Model Class Initialized
DEBUG - 2017-11-14 11:50:15 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/template.php
INFO - 2017-11-14 11:50:15 --> Config Class Initialized
INFO - 2017-11-14 11:50:15 --> Hooks Class Initialized
DEBUG - 2017-11-14 11:50:15 --> UTF-8 Support Enabled
INFO - 2017-11-14 11:50:15 --> Utf8 Class Initialized
INFO - 2017-11-14 11:50:15 --> URI Class Initialized
INFO - 2017-11-14 11:50:15 --> Router Class Initialized
INFO - 2017-11-14 11:50:15 --> Output Class Initialized
INFO - 2017-11-14 11:50:15 --> Security Class Initialized
DEBUG - 2017-11-14 11:50:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 11:50:15 --> Input Class Initialized
INFO - 2017-11-14 11:50:15 --> Language Class Initialized
ERROR - 2017-11-14 11:50:15 --> 404 Page Not Found: /index
INFO - 2017-11-14 11:50:20 --> Config Class Initialized
INFO - 2017-11-14 11:50:20 --> Hooks Class Initialized
DEBUG - 2017-11-14 11:50:20 --> UTF-8 Support Enabled
INFO - 2017-11-14 11:50:20 --> Utf8 Class Initialized
INFO - 2017-11-14 11:50:20 --> URI Class Initialized
INFO - 2017-11-14 11:50:20 --> Router Class Initialized
INFO - 2017-11-14 11:50:20 --> Output Class Initialized
INFO - 2017-11-14 11:50:20 --> Security Class Initialized
DEBUG - 2017-11-14 11:50:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 11:50:20 --> Input Class Initialized
INFO - 2017-11-14 11:50:20 --> Language Class Initialized
INFO - 2017-11-14 11:50:20 --> Language Class Initialized
INFO - 2017-11-14 11:50:20 --> Config Class Initialized
INFO - 2017-11-14 11:50:20 --> Loader Class Initialized
DEBUG - 2017-11-14 11:50:20 --> Config file loaded: D:\xampp\htdocs\construction_bay\application\config/construct-data.php
INFO - 2017-11-14 11:50:20 --> Helper loaded: url_helper
INFO - 2017-11-14 11:50:20 --> Helper loaded: form_helper
INFO - 2017-11-14 11:50:20 --> Helper loaded: date_helper
INFO - 2017-11-14 11:50:20 --> Helper loaded: util_helper
INFO - 2017-11-14 11:50:20 --> Helper loaded: text_helper
INFO - 2017-11-14 11:50:20 --> Helper loaded: string_helper
INFO - 2017-11-14 11:50:20 --> Database Driver Class Initialized
DEBUG - 2017-11-14 11:50:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-14 11:50:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-14 11:50:20 --> Email Class Initialized
INFO - 2017-11-14 11:50:20 --> Controller Class Initialized
INFO - 2017-11-14 11:50:20 --> Model Class Initialized
DEBUG - 2017-11-14 11:50:20 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_model.php
INFO - 2017-11-14 11:50:20 --> Model Class Initialized
DEBUG - 2017-11-14 11:50:20 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_functions_model.php
INFO - 2017-11-14 11:50:20 --> Model Class Initialized
ERROR - 2017-11-14 11:50:20 --> Severity: Notice --> Undefined variable: category D:\xampp\htdocs\construction_bay\application\views\common\header.php 309
DEBUG - 2017-11-14 11:50:20 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header.php
DEBUG - 2017-11-14 11:50:20 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\art-work.php
DEBUG - 2017-11-14 11:50:20 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/footer.php
INFO - 2017-11-14 11:50:20 --> Final output sent to browser
DEBUG - 2017-11-14 11:50:20 --> Total execution time: 0.0530
INFO - 2017-11-14 11:50:35 --> Config Class Initialized
INFO - 2017-11-14 11:50:35 --> Hooks Class Initialized
DEBUG - 2017-11-14 11:50:35 --> UTF-8 Support Enabled
INFO - 2017-11-14 11:50:35 --> Utf8 Class Initialized
INFO - 2017-11-14 11:50:35 --> URI Class Initialized
INFO - 2017-11-14 11:50:35 --> Router Class Initialized
INFO - 2017-11-14 11:50:35 --> Output Class Initialized
INFO - 2017-11-14 11:50:35 --> Security Class Initialized
DEBUG - 2017-11-14 11:50:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 11:50:35 --> Input Class Initialized
INFO - 2017-11-14 11:50:35 --> Language Class Initialized
INFO - 2017-11-14 11:50:35 --> Language Class Initialized
INFO - 2017-11-14 11:50:35 --> Config Class Initialized
INFO - 2017-11-14 11:50:35 --> Loader Class Initialized
DEBUG - 2017-11-14 11:50:35 --> Config file loaded: D:\xampp\htdocs\construction_bay\application\config/construct-data.php
INFO - 2017-11-14 11:50:35 --> Helper loaded: url_helper
INFO - 2017-11-14 11:50:35 --> Helper loaded: form_helper
INFO - 2017-11-14 11:50:35 --> Helper loaded: date_helper
INFO - 2017-11-14 11:50:35 --> Helper loaded: util_helper
INFO - 2017-11-14 11:50:35 --> Helper loaded: text_helper
INFO - 2017-11-14 11:50:35 --> Helper loaded: string_helper
INFO - 2017-11-14 11:50:35 --> Database Driver Class Initialized
DEBUG - 2017-11-14 11:50:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-14 11:50:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-14 11:50:35 --> Email Class Initialized
INFO - 2017-11-14 11:50:35 --> Controller Class Initialized
INFO - 2017-11-14 11:50:35 --> Model Class Initialized
DEBUG - 2017-11-14 11:50:35 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_model.php
INFO - 2017-11-14 11:50:35 --> Model Class Initialized
DEBUG - 2017-11-14 11:50:35 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_functions_model.php
INFO - 2017-11-14 11:50:35 --> Model Class Initialized
ERROR - 2017-11-14 11:50:35 --> Severity: Notice --> Undefined variable: category D:\xampp\htdocs\construction_bay\application\views\common\header.php 309
DEBUG - 2017-11-14 11:50:35 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header.php
DEBUG - 2017-11-14 11:50:35 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\art-work.php
DEBUG - 2017-11-14 11:50:35 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/footer.php
INFO - 2017-11-14 11:50:35 --> Final output sent to browser
DEBUG - 2017-11-14 11:50:35 --> Total execution time: 0.0710
INFO - 2017-11-14 11:51:47 --> Config Class Initialized
INFO - 2017-11-14 11:51:47 --> Hooks Class Initialized
DEBUG - 2017-11-14 11:51:47 --> UTF-8 Support Enabled
INFO - 2017-11-14 11:51:47 --> Utf8 Class Initialized
INFO - 2017-11-14 11:51:47 --> URI Class Initialized
INFO - 2017-11-14 11:51:47 --> Router Class Initialized
INFO - 2017-11-14 11:51:47 --> Output Class Initialized
INFO - 2017-11-14 11:51:47 --> Security Class Initialized
DEBUG - 2017-11-14 11:51:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 11:51:47 --> Input Class Initialized
INFO - 2017-11-14 11:51:47 --> Language Class Initialized
INFO - 2017-11-14 11:51:47 --> Language Class Initialized
INFO - 2017-11-14 11:51:47 --> Config Class Initialized
INFO - 2017-11-14 11:51:47 --> Loader Class Initialized
DEBUG - 2017-11-14 11:51:47 --> Config file loaded: D:\xampp\htdocs\construction_bay\application\config/construct-data.php
INFO - 2017-11-14 11:51:47 --> Helper loaded: url_helper
INFO - 2017-11-14 11:51:47 --> Helper loaded: form_helper
INFO - 2017-11-14 11:51:47 --> Helper loaded: date_helper
INFO - 2017-11-14 11:51:47 --> Helper loaded: util_helper
INFO - 2017-11-14 11:51:47 --> Helper loaded: text_helper
INFO - 2017-11-14 11:51:47 --> Helper loaded: string_helper
INFO - 2017-11-14 11:51:47 --> Database Driver Class Initialized
DEBUG - 2017-11-14 11:51:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-14 11:51:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-14 11:51:47 --> Email Class Initialized
INFO - 2017-11-14 11:51:47 --> Controller Class Initialized
INFO - 2017-11-14 11:51:47 --> Model Class Initialized
DEBUG - 2017-11-14 11:51:47 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_model.php
INFO - 2017-11-14 11:51:47 --> Model Class Initialized
DEBUG - 2017-11-14 11:51:47 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_functions_model.php
INFO - 2017-11-14 11:51:47 --> Model Class Initialized
ERROR - 2017-11-14 11:51:47 --> Severity: Notice --> Undefined variable: category D:\xampp\htdocs\construction_bay\application\views\common\header.php 309
DEBUG - 2017-11-14 11:51:47 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header.php
DEBUG - 2017-11-14 11:51:47 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\art-work.php
DEBUG - 2017-11-14 11:51:47 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/footer.php
INFO - 2017-11-14 11:51:47 --> Final output sent to browser
DEBUG - 2017-11-14 11:51:47 --> Total execution time: 0.0640
INFO - 2017-11-14 11:51:48 --> Config Class Initialized
INFO - 2017-11-14 11:51:48 --> Hooks Class Initialized
DEBUG - 2017-11-14 11:51:48 --> UTF-8 Support Enabled
INFO - 2017-11-14 11:51:48 --> Utf8 Class Initialized
INFO - 2017-11-14 11:51:48 --> URI Class Initialized
INFO - 2017-11-14 11:51:48 --> Router Class Initialized
INFO - 2017-11-14 11:51:48 --> Output Class Initialized
INFO - 2017-11-14 11:51:48 --> Security Class Initialized
DEBUG - 2017-11-14 11:51:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 11:51:48 --> Input Class Initialized
INFO - 2017-11-14 11:51:48 --> Language Class Initialized
INFO - 2017-11-14 11:51:48 --> Language Class Initialized
INFO - 2017-11-14 11:51:48 --> Config Class Initialized
INFO - 2017-11-14 11:51:48 --> Loader Class Initialized
DEBUG - 2017-11-14 11:51:48 --> Config file loaded: D:\xampp\htdocs\construction_bay\application\config/construct-data.php
INFO - 2017-11-14 11:51:48 --> Helper loaded: url_helper
INFO - 2017-11-14 11:51:48 --> Helper loaded: form_helper
INFO - 2017-11-14 11:51:48 --> Helper loaded: date_helper
INFO - 2017-11-14 11:51:48 --> Helper loaded: util_helper
INFO - 2017-11-14 11:51:48 --> Helper loaded: text_helper
INFO - 2017-11-14 11:51:48 --> Helper loaded: string_helper
INFO - 2017-11-14 11:51:48 --> Database Driver Class Initialized
DEBUG - 2017-11-14 11:51:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-14 11:51:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-14 11:51:48 --> Email Class Initialized
INFO - 2017-11-14 11:51:48 --> Controller Class Initialized
INFO - 2017-11-14 11:51:48 --> Model Class Initialized
DEBUG - 2017-11-14 11:51:48 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_model.php
INFO - 2017-11-14 11:51:48 --> Model Class Initialized
DEBUG - 2017-11-14 11:51:48 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_functions_model.php
INFO - 2017-11-14 11:51:48 --> Model Class Initialized
DEBUG - 2017-11-14 11:51:48 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\companies/companies_header.php
DEBUG - 2017-11-14 11:51:48 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\companies/companies_page.php
DEBUG - 2017-11-14 11:51:48 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\companies/companies_footer.php
INFO - 2017-11-14 11:51:48 --> Final output sent to browser
DEBUG - 2017-11-14 11:51:48 --> Total execution time: 0.0780
INFO - 2017-11-14 11:51:49 --> Config Class Initialized
INFO - 2017-11-14 11:51:49 --> Hooks Class Initialized
DEBUG - 2017-11-14 11:51:49 --> UTF-8 Support Enabled
INFO - 2017-11-14 11:51:49 --> Utf8 Class Initialized
INFO - 2017-11-14 11:51:49 --> URI Class Initialized
INFO - 2017-11-14 11:51:49 --> Router Class Initialized
INFO - 2017-11-14 11:51:49 --> Output Class Initialized
INFO - 2017-11-14 11:51:49 --> Security Class Initialized
DEBUG - 2017-11-14 11:51:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 11:51:49 --> Input Class Initialized
INFO - 2017-11-14 11:51:49 --> Language Class Initialized
INFO - 2017-11-14 11:51:49 --> Language Class Initialized
INFO - 2017-11-14 11:51:49 --> Config Class Initialized
INFO - 2017-11-14 11:51:49 --> Loader Class Initialized
DEBUG - 2017-11-14 11:51:49 --> Config file loaded: D:\xampp\htdocs\construction_bay\application\config/construct-data.php
INFO - 2017-11-14 11:51:49 --> Helper loaded: url_helper
INFO - 2017-11-14 11:51:49 --> Helper loaded: form_helper
INFO - 2017-11-14 11:51:49 --> Helper loaded: date_helper
INFO - 2017-11-14 11:51:49 --> Helper loaded: util_helper
INFO - 2017-11-14 11:51:49 --> Helper loaded: text_helper
INFO - 2017-11-14 11:51:49 --> Helper loaded: string_helper
INFO - 2017-11-14 11:51:49 --> Database Driver Class Initialized
DEBUG - 2017-11-14 11:51:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-14 11:51:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-14 11:51:49 --> Email Class Initialized
INFO - 2017-11-14 11:51:49 --> Controller Class Initialized
INFO - 2017-11-14 11:51:49 --> Model Class Initialized
DEBUG - 2017-11-14 11:51:49 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_model.php
INFO - 2017-11-14 11:51:49 --> Model Class Initialized
DEBUG - 2017-11-14 11:51:49 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_functions_model.php
INFO - 2017-11-14 11:51:49 --> Model Class Initialized
DEBUG - 2017-11-14 11:51:49 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/template.php
INFO - 2017-11-14 11:51:50 --> Config Class Initialized
INFO - 2017-11-14 11:51:50 --> Hooks Class Initialized
DEBUG - 2017-11-14 11:51:50 --> UTF-8 Support Enabled
INFO - 2017-11-14 11:51:50 --> Utf8 Class Initialized
INFO - 2017-11-14 11:51:50 --> URI Class Initialized
DEBUG - 2017-11-14 11:51:50 --> No URI present. Default controller set.
INFO - 2017-11-14 11:51:50 --> Router Class Initialized
INFO - 2017-11-14 11:51:50 --> Output Class Initialized
INFO - 2017-11-14 11:51:50 --> Security Class Initialized
DEBUG - 2017-11-14 11:51:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 11:51:50 --> Input Class Initialized
INFO - 2017-11-14 11:51:50 --> Language Class Initialized
INFO - 2017-11-14 11:51:50 --> Language Class Initialized
INFO - 2017-11-14 11:51:50 --> Config Class Initialized
INFO - 2017-11-14 11:51:50 --> Loader Class Initialized
DEBUG - 2017-11-14 11:51:50 --> Config file loaded: D:\xampp\htdocs\construction_bay\application\config/construct-data.php
INFO - 2017-11-14 11:51:50 --> Helper loaded: url_helper
INFO - 2017-11-14 11:51:50 --> Helper loaded: form_helper
INFO - 2017-11-14 11:51:50 --> Helper loaded: date_helper
INFO - 2017-11-14 11:51:50 --> Helper loaded: util_helper
INFO - 2017-11-14 11:51:50 --> Helper loaded: text_helper
INFO - 2017-11-14 11:51:50 --> Helper loaded: string_helper
INFO - 2017-11-14 11:51:50 --> Database Driver Class Initialized
DEBUG - 2017-11-14 11:51:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-14 11:51:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-14 11:51:50 --> Email Class Initialized
INFO - 2017-11-14 11:51:50 --> Controller Class Initialized
DEBUG - 2017-11-14 11:51:50 --> Home MX_Controller Initialized
INFO - 2017-11-14 11:51:50 --> Model Class Initialized
DEBUG - 2017-11-14 11:51:50 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_model.php
INFO - 2017-11-14 11:51:50 --> Model Class Initialized
DEBUG - 2017-11-14 11:51:50 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header.php
DEBUG - 2017-11-14 11:51:50 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/slider.php
DEBUG - 2017-11-14 11:51:50 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/index_body.php
DEBUG - 2017-11-14 11:51:50 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/index_footer.php
INFO - 2017-11-14 11:51:50 --> Final output sent to browser
DEBUG - 2017-11-14 11:51:50 --> Total execution time: 0.0660
INFO - 2017-11-14 11:51:53 --> Config Class Initialized
INFO - 2017-11-14 11:51:53 --> Hooks Class Initialized
DEBUG - 2017-11-14 11:51:53 --> UTF-8 Support Enabled
INFO - 2017-11-14 11:51:53 --> Utf8 Class Initialized
INFO - 2017-11-14 11:51:53 --> URI Class Initialized
INFO - 2017-11-14 11:51:53 --> Router Class Initialized
INFO - 2017-11-14 11:51:53 --> Output Class Initialized
INFO - 2017-11-14 11:51:53 --> Security Class Initialized
DEBUG - 2017-11-14 11:51:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 11:51:53 --> Input Class Initialized
INFO - 2017-11-14 11:51:53 --> Language Class Initialized
INFO - 2017-11-14 11:51:53 --> Language Class Initialized
INFO - 2017-11-14 11:51:53 --> Config Class Initialized
INFO - 2017-11-14 11:51:53 --> Loader Class Initialized
DEBUG - 2017-11-14 11:51:53 --> Config file loaded: D:\xampp\htdocs\construction_bay\application\config/construct-data.php
INFO - 2017-11-14 11:51:53 --> Helper loaded: url_helper
INFO - 2017-11-14 11:51:53 --> Helper loaded: form_helper
INFO - 2017-11-14 11:51:53 --> Helper loaded: date_helper
INFO - 2017-11-14 11:51:53 --> Helper loaded: util_helper
INFO - 2017-11-14 11:51:53 --> Helper loaded: text_helper
INFO - 2017-11-14 11:51:53 --> Helper loaded: string_helper
INFO - 2017-11-14 11:51:53 --> Database Driver Class Initialized
DEBUG - 2017-11-14 11:51:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-14 11:51:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-14 11:51:53 --> Email Class Initialized
INFO - 2017-11-14 11:51:53 --> Controller Class Initialized
INFO - 2017-11-14 11:51:53 --> Model Class Initialized
DEBUG - 2017-11-14 11:51:53 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_model.php
INFO - 2017-11-14 11:51:53 --> Model Class Initialized
DEBUG - 2017-11-14 11:51:53 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_functions_model.php
INFO - 2017-11-14 11:51:53 --> Model Class Initialized
ERROR - 2017-11-14 11:51:53 --> Severity: Notice --> Undefined variable: category D:\xampp\htdocs\construction_bay\application\views\common\header.php 309
DEBUG - 2017-11-14 11:51:53 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header.php
DEBUG - 2017-11-14 11:51:53 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\art-work.php
DEBUG - 2017-11-14 11:51:53 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/footer.php
INFO - 2017-11-14 11:51:53 --> Final output sent to browser
DEBUG - 2017-11-14 11:51:53 --> Total execution time: 0.0530
INFO - 2017-11-14 11:51:56 --> Config Class Initialized
INFO - 2017-11-14 11:51:56 --> Hooks Class Initialized
DEBUG - 2017-11-14 11:51:56 --> UTF-8 Support Enabled
INFO - 2017-11-14 11:51:56 --> Utf8 Class Initialized
INFO - 2017-11-14 11:51:56 --> URI Class Initialized
INFO - 2017-11-14 11:51:56 --> Router Class Initialized
INFO - 2017-11-14 11:51:56 --> Output Class Initialized
INFO - 2017-11-14 11:51:56 --> Security Class Initialized
DEBUG - 2017-11-14 11:51:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 11:51:56 --> Input Class Initialized
INFO - 2017-11-14 11:51:56 --> Language Class Initialized
INFO - 2017-11-14 11:51:56 --> Language Class Initialized
INFO - 2017-11-14 11:51:56 --> Config Class Initialized
INFO - 2017-11-14 11:51:56 --> Loader Class Initialized
DEBUG - 2017-11-14 11:51:56 --> Config file loaded: D:\xampp\htdocs\construction_bay\application\config/construct-data.php
INFO - 2017-11-14 11:51:56 --> Helper loaded: url_helper
INFO - 2017-11-14 11:51:56 --> Helper loaded: form_helper
INFO - 2017-11-14 11:51:56 --> Helper loaded: date_helper
INFO - 2017-11-14 11:51:56 --> Helper loaded: util_helper
INFO - 2017-11-14 11:51:56 --> Helper loaded: text_helper
INFO - 2017-11-14 11:51:56 --> Helper loaded: string_helper
INFO - 2017-11-14 11:51:56 --> Database Driver Class Initialized
DEBUG - 2017-11-14 11:51:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-14 11:51:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-14 11:51:56 --> Email Class Initialized
INFO - 2017-11-14 11:51:56 --> Controller Class Initialized
INFO - 2017-11-14 11:51:56 --> Model Class Initialized
DEBUG - 2017-11-14 11:51:56 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_model.php
INFO - 2017-11-14 11:51:56 --> Model Class Initialized
DEBUG - 2017-11-14 11:51:56 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_functions_model.php
INFO - 2017-11-14 11:51:56 --> Model Class Initialized
DEBUG - 2017-11-14 11:51:56 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\companies/companies_header.php
DEBUG - 2017-11-14 11:51:56 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\companies/companies_page.php
DEBUG - 2017-11-14 11:51:56 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\companies/companies_footer.php
INFO - 2017-11-14 11:51:56 --> Final output sent to browser
DEBUG - 2017-11-14 11:51:56 --> Total execution time: 0.0630
INFO - 2017-11-14 11:51:57 --> Config Class Initialized
INFO - 2017-11-14 11:51:57 --> Hooks Class Initialized
DEBUG - 2017-11-14 11:51:57 --> UTF-8 Support Enabled
INFO - 2017-11-14 11:51:57 --> Utf8 Class Initialized
INFO - 2017-11-14 11:51:57 --> URI Class Initialized
INFO - 2017-11-14 11:51:57 --> Router Class Initialized
INFO - 2017-11-14 11:51:57 --> Output Class Initialized
INFO - 2017-11-14 11:51:57 --> Security Class Initialized
DEBUG - 2017-11-14 11:51:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 11:51:57 --> Input Class Initialized
INFO - 2017-11-14 11:51:57 --> Language Class Initialized
INFO - 2017-11-14 11:51:57 --> Language Class Initialized
INFO - 2017-11-14 11:51:57 --> Config Class Initialized
INFO - 2017-11-14 11:51:57 --> Loader Class Initialized
DEBUG - 2017-11-14 11:51:57 --> Config file loaded: D:\xampp\htdocs\construction_bay\application\config/construct-data.php
INFO - 2017-11-14 11:51:57 --> Helper loaded: url_helper
INFO - 2017-11-14 11:51:57 --> Helper loaded: form_helper
INFO - 2017-11-14 11:51:57 --> Helper loaded: date_helper
INFO - 2017-11-14 11:51:57 --> Helper loaded: util_helper
INFO - 2017-11-14 11:51:57 --> Helper loaded: text_helper
INFO - 2017-11-14 11:51:57 --> Helper loaded: string_helper
INFO - 2017-11-14 11:51:57 --> Database Driver Class Initialized
DEBUG - 2017-11-14 11:51:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-14 11:51:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-14 11:51:57 --> Email Class Initialized
INFO - 2017-11-14 11:51:57 --> Controller Class Initialized
INFO - 2017-11-14 11:51:57 --> Model Class Initialized
DEBUG - 2017-11-14 11:51:57 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_model.php
INFO - 2017-11-14 11:51:57 --> Model Class Initialized
DEBUG - 2017-11-14 11:51:57 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_functions_model.php
INFO - 2017-11-14 11:51:57 --> Model Class Initialized
DEBUG - 2017-11-14 11:51:57 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/template.php
INFO - 2017-11-14 11:52:01 --> Config Class Initialized
INFO - 2017-11-14 11:52:01 --> Hooks Class Initialized
DEBUG - 2017-11-14 11:52:01 --> UTF-8 Support Enabled
INFO - 2017-11-14 11:52:01 --> Utf8 Class Initialized
INFO - 2017-11-14 11:52:01 --> URI Class Initialized
DEBUG - 2017-11-14 11:52:01 --> No URI present. Default controller set.
INFO - 2017-11-14 11:52:01 --> Router Class Initialized
INFO - 2017-11-14 11:52:01 --> Output Class Initialized
INFO - 2017-11-14 11:52:01 --> Security Class Initialized
DEBUG - 2017-11-14 11:52:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 11:52:01 --> Input Class Initialized
INFO - 2017-11-14 11:52:01 --> Language Class Initialized
INFO - 2017-11-14 11:52:01 --> Language Class Initialized
INFO - 2017-11-14 11:52:01 --> Config Class Initialized
INFO - 2017-11-14 11:52:01 --> Loader Class Initialized
DEBUG - 2017-11-14 11:52:01 --> Config file loaded: D:\xampp\htdocs\construction_bay\application\config/construct-data.php
INFO - 2017-11-14 11:52:01 --> Helper loaded: url_helper
INFO - 2017-11-14 11:52:01 --> Helper loaded: form_helper
INFO - 2017-11-14 11:52:01 --> Helper loaded: date_helper
INFO - 2017-11-14 11:52:01 --> Helper loaded: util_helper
INFO - 2017-11-14 11:52:01 --> Helper loaded: text_helper
INFO - 2017-11-14 11:52:01 --> Helper loaded: string_helper
INFO - 2017-11-14 11:52:01 --> Database Driver Class Initialized
DEBUG - 2017-11-14 11:52:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-14 11:52:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-14 11:52:01 --> Email Class Initialized
INFO - 2017-11-14 11:52:01 --> Controller Class Initialized
DEBUG - 2017-11-14 11:52:01 --> Home MX_Controller Initialized
INFO - 2017-11-14 11:52:01 --> Model Class Initialized
DEBUG - 2017-11-14 11:52:01 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_model.php
INFO - 2017-11-14 11:52:01 --> Model Class Initialized
DEBUG - 2017-11-14 11:52:01 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header.php
DEBUG - 2017-11-14 11:52:01 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/slider.php
DEBUG - 2017-11-14 11:52:01 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/index_body.php
DEBUG - 2017-11-14 11:52:01 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/index_footer.php
INFO - 2017-11-14 11:52:01 --> Final output sent to browser
DEBUG - 2017-11-14 11:52:01 --> Total execution time: 0.0640
INFO - 2017-11-14 12:13:23 --> Config Class Initialized
INFO - 2017-11-14 12:13:23 --> Hooks Class Initialized
DEBUG - 2017-11-14 12:13:23 --> UTF-8 Support Enabled
INFO - 2017-11-14 12:13:23 --> Utf8 Class Initialized
INFO - 2017-11-14 12:13:23 --> URI Class Initialized
DEBUG - 2017-11-14 12:13:23 --> No URI present. Default controller set.
INFO - 2017-11-14 12:13:23 --> Router Class Initialized
INFO - 2017-11-14 12:13:23 --> Output Class Initialized
INFO - 2017-11-14 12:13:23 --> Security Class Initialized
DEBUG - 2017-11-14 12:13:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 12:13:23 --> Input Class Initialized
INFO - 2017-11-14 12:13:23 --> Language Class Initialized
INFO - 2017-11-14 12:13:23 --> Language Class Initialized
INFO - 2017-11-14 12:13:23 --> Config Class Initialized
INFO - 2017-11-14 12:13:23 --> Loader Class Initialized
DEBUG - 2017-11-14 12:13:23 --> Config file loaded: D:\xampp\htdocs\construction_bay\application\config/construct-data.php
INFO - 2017-11-14 12:13:23 --> Helper loaded: url_helper
INFO - 2017-11-14 12:13:23 --> Helper loaded: form_helper
INFO - 2017-11-14 12:13:23 --> Helper loaded: date_helper
INFO - 2017-11-14 12:13:23 --> Helper loaded: util_helper
INFO - 2017-11-14 12:13:23 --> Helper loaded: text_helper
INFO - 2017-11-14 12:13:23 --> Helper loaded: string_helper
INFO - 2017-11-14 12:13:23 --> Database Driver Class Initialized
DEBUG - 2017-11-14 12:13:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-14 12:13:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-14 12:13:23 --> Email Class Initialized
INFO - 2017-11-14 12:13:23 --> Controller Class Initialized
DEBUG - 2017-11-14 12:13:23 --> Home MX_Controller Initialized
INFO - 2017-11-14 12:13:23 --> Model Class Initialized
DEBUG - 2017-11-14 12:13:23 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_model.php
INFO - 2017-11-14 12:13:23 --> Model Class Initialized
DEBUG - 2017-11-14 12:13:23 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header.php
DEBUG - 2017-11-14 12:13:23 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/slider.php
DEBUG - 2017-11-14 12:13:23 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/index_body.php
DEBUG - 2017-11-14 12:13:23 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/index_footer.php
INFO - 2017-11-14 12:13:23 --> Final output sent to browser
DEBUG - 2017-11-14 12:13:23 --> Total execution time: 0.0590
INFO - 2017-11-14 12:13:28 --> Config Class Initialized
INFO - 2017-11-14 12:13:28 --> Hooks Class Initialized
DEBUG - 2017-11-14 12:13:28 --> UTF-8 Support Enabled
INFO - 2017-11-14 12:13:28 --> Utf8 Class Initialized
INFO - 2017-11-14 12:13:28 --> URI Class Initialized
INFO - 2017-11-14 12:13:28 --> Router Class Initialized
INFO - 2017-11-14 12:13:28 --> Output Class Initialized
INFO - 2017-11-14 12:13:28 --> Security Class Initialized
DEBUG - 2017-11-14 12:13:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 12:13:28 --> Input Class Initialized
INFO - 2017-11-14 12:13:28 --> Language Class Initialized
INFO - 2017-11-14 12:13:28 --> Language Class Initialized
INFO - 2017-11-14 12:13:28 --> Config Class Initialized
INFO - 2017-11-14 12:13:28 --> Loader Class Initialized
DEBUG - 2017-11-14 12:13:28 --> Config file loaded: D:\xampp\htdocs\construction_bay\application\config/construct-data.php
INFO - 2017-11-14 12:13:28 --> Helper loaded: url_helper
INFO - 2017-11-14 12:13:28 --> Helper loaded: form_helper
INFO - 2017-11-14 12:13:28 --> Helper loaded: date_helper
INFO - 2017-11-14 12:13:28 --> Helper loaded: util_helper
INFO - 2017-11-14 12:13:28 --> Helper loaded: text_helper
INFO - 2017-11-14 12:13:28 --> Helper loaded: string_helper
INFO - 2017-11-14 12:13:28 --> Database Driver Class Initialized
DEBUG - 2017-11-14 12:13:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-14 12:13:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-14 12:13:28 --> Email Class Initialized
INFO - 2017-11-14 12:13:28 --> Controller Class Initialized
INFO - 2017-11-14 12:13:28 --> Model Class Initialized
DEBUG - 2017-11-14 12:13:28 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_model.php
INFO - 2017-11-14 12:13:28 --> Model Class Initialized
DEBUG - 2017-11-14 12:13:28 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_functions_model.php
INFO - 2017-11-14 12:13:28 --> Model Class Initialized
ERROR - 2017-11-14 12:13:28 --> Severity: Notice --> Undefined variable: category D:\xampp\htdocs\construction_bay\application\views\common\header.php 309
DEBUG - 2017-11-14 12:13:28 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header.php
DEBUG - 2017-11-14 12:13:28 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\products-services.php
DEBUG - 2017-11-14 12:13:28 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/footer.php
INFO - 2017-11-14 12:13:28 --> Final output sent to browser
DEBUG - 2017-11-14 12:13:28 --> Total execution time: 0.0620
INFO - 2017-11-14 12:13:35 --> Config Class Initialized
INFO - 2017-11-14 12:13:35 --> Hooks Class Initialized
DEBUG - 2017-11-14 12:13:35 --> UTF-8 Support Enabled
INFO - 2017-11-14 12:13:35 --> Utf8 Class Initialized
INFO - 2017-11-14 12:13:35 --> URI Class Initialized
INFO - 2017-11-14 12:13:35 --> Router Class Initialized
INFO - 2017-11-14 12:13:35 --> Output Class Initialized
INFO - 2017-11-14 12:13:35 --> Security Class Initialized
DEBUG - 2017-11-14 12:13:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 12:13:35 --> Input Class Initialized
INFO - 2017-11-14 12:13:35 --> Language Class Initialized
ERROR - 2017-11-14 12:13:35 --> 404 Page Not Found: /index
INFO - 2017-11-14 12:14:36 --> Config Class Initialized
INFO - 2017-11-14 12:14:36 --> Hooks Class Initialized
DEBUG - 2017-11-14 12:14:36 --> UTF-8 Support Enabled
INFO - 2017-11-14 12:14:36 --> Utf8 Class Initialized
INFO - 2017-11-14 12:14:36 --> URI Class Initialized
INFO - 2017-11-14 12:14:36 --> Router Class Initialized
INFO - 2017-11-14 12:14:36 --> Output Class Initialized
INFO - 2017-11-14 12:14:36 --> Security Class Initialized
DEBUG - 2017-11-14 12:14:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 12:14:36 --> Input Class Initialized
INFO - 2017-11-14 12:14:36 --> Language Class Initialized
INFO - 2017-11-14 12:14:36 --> Language Class Initialized
INFO - 2017-11-14 12:14:36 --> Config Class Initialized
INFO - 2017-11-14 12:14:36 --> Loader Class Initialized
DEBUG - 2017-11-14 12:14:36 --> Config file loaded: D:\xampp\htdocs\construction_bay\application\config/construct-data.php
INFO - 2017-11-14 12:14:36 --> Helper loaded: url_helper
INFO - 2017-11-14 12:14:36 --> Helper loaded: form_helper
INFO - 2017-11-14 12:14:36 --> Helper loaded: date_helper
INFO - 2017-11-14 12:14:36 --> Helper loaded: util_helper
INFO - 2017-11-14 12:14:36 --> Helper loaded: text_helper
INFO - 2017-11-14 12:14:36 --> Helper loaded: string_helper
INFO - 2017-11-14 12:14:36 --> Database Driver Class Initialized
DEBUG - 2017-11-14 12:14:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-14 12:14:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-14 12:14:36 --> Email Class Initialized
INFO - 2017-11-14 12:14:36 --> Controller Class Initialized
INFO - 2017-11-14 12:14:36 --> Model Class Initialized
DEBUG - 2017-11-14 12:14:36 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_model.php
INFO - 2017-11-14 12:14:36 --> Model Class Initialized
DEBUG - 2017-11-14 12:14:36 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_functions_model.php
INFO - 2017-11-14 12:14:36 --> Model Class Initialized
ERROR - 2017-11-14 12:14:36 --> Severity: Notice --> Undefined variable: category D:\xampp\htdocs\construction_bay\application\views\common\header.php 309
DEBUG - 2017-11-14 12:14:36 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header.php
DEBUG - 2017-11-14 12:14:36 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\products-services.php
DEBUG - 2017-11-14 12:14:36 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/footer.php
INFO - 2017-11-14 12:14:36 --> Final output sent to browser
DEBUG - 2017-11-14 12:14:36 --> Total execution time: 0.0610
INFO - 2017-11-14 12:14:37 --> Config Class Initialized
INFO - 2017-11-14 12:14:37 --> Hooks Class Initialized
DEBUG - 2017-11-14 12:14:37 --> UTF-8 Support Enabled
INFO - 2017-11-14 12:14:37 --> Utf8 Class Initialized
INFO - 2017-11-14 12:14:37 --> URI Class Initialized
INFO - 2017-11-14 12:14:37 --> Router Class Initialized
INFO - 2017-11-14 12:14:37 --> Output Class Initialized
INFO - 2017-11-14 12:14:37 --> Security Class Initialized
DEBUG - 2017-11-14 12:14:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 12:14:37 --> Input Class Initialized
INFO - 2017-11-14 12:14:37 --> Language Class Initialized
ERROR - 2017-11-14 12:14:37 --> 404 Page Not Found: /index
INFO - 2017-11-14 12:14:50 --> Config Class Initialized
INFO - 2017-11-14 12:14:50 --> Hooks Class Initialized
DEBUG - 2017-11-14 12:14:50 --> UTF-8 Support Enabled
INFO - 2017-11-14 12:14:50 --> Utf8 Class Initialized
INFO - 2017-11-14 12:14:50 --> URI Class Initialized
INFO - 2017-11-14 12:14:50 --> Router Class Initialized
INFO - 2017-11-14 12:14:50 --> Output Class Initialized
INFO - 2017-11-14 12:14:50 --> Security Class Initialized
DEBUG - 2017-11-14 12:14:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 12:14:50 --> Input Class Initialized
INFO - 2017-11-14 12:14:50 --> Language Class Initialized
INFO - 2017-11-14 12:14:50 --> Language Class Initialized
INFO - 2017-11-14 12:14:50 --> Config Class Initialized
INFO - 2017-11-14 12:14:50 --> Loader Class Initialized
DEBUG - 2017-11-14 12:14:50 --> Config file loaded: D:\xampp\htdocs\construction_bay\application\config/construct-data.php
INFO - 2017-11-14 12:14:50 --> Helper loaded: url_helper
INFO - 2017-11-14 12:14:50 --> Helper loaded: form_helper
INFO - 2017-11-14 12:14:50 --> Helper loaded: date_helper
INFO - 2017-11-14 12:14:50 --> Helper loaded: util_helper
INFO - 2017-11-14 12:14:50 --> Helper loaded: text_helper
INFO - 2017-11-14 12:14:50 --> Helper loaded: string_helper
INFO - 2017-11-14 12:14:50 --> Database Driver Class Initialized
DEBUG - 2017-11-14 12:14:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-14 12:14:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-14 12:14:50 --> Email Class Initialized
INFO - 2017-11-14 12:14:50 --> Controller Class Initialized
INFO - 2017-11-14 12:14:50 --> Model Class Initialized
DEBUG - 2017-11-14 12:14:50 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_model.php
INFO - 2017-11-14 12:14:50 --> Model Class Initialized
DEBUG - 2017-11-14 12:14:50 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_functions_model.php
INFO - 2017-11-14 12:14:50 --> Model Class Initialized
ERROR - 2017-11-14 12:14:50 --> Severity: Notice --> Undefined variable: category D:\xampp\htdocs\construction_bay\application\views\common\header.php 309
DEBUG - 2017-11-14 12:14:50 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header.php
DEBUG - 2017-11-14 12:14:50 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\products-services.php
DEBUG - 2017-11-14 12:14:50 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/footer.php
INFO - 2017-11-14 12:14:50 --> Final output sent to browser
DEBUG - 2017-11-14 12:14:50 --> Total execution time: 0.0640
INFO - 2017-11-14 12:14:51 --> Config Class Initialized
INFO - 2017-11-14 12:14:51 --> Hooks Class Initialized
DEBUG - 2017-11-14 12:14:51 --> UTF-8 Support Enabled
INFO - 2017-11-14 12:14:51 --> Utf8 Class Initialized
INFO - 2017-11-14 12:14:51 --> URI Class Initialized
INFO - 2017-11-14 12:14:51 --> Router Class Initialized
INFO - 2017-11-14 12:14:51 --> Output Class Initialized
INFO - 2017-11-14 12:14:51 --> Security Class Initialized
DEBUG - 2017-11-14 12:14:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 12:14:51 --> Input Class Initialized
INFO - 2017-11-14 12:14:51 --> Language Class Initialized
ERROR - 2017-11-14 12:14:51 --> 404 Page Not Found: /index
INFO - 2017-11-14 12:14:56 --> Config Class Initialized
INFO - 2017-11-14 12:14:56 --> Hooks Class Initialized
DEBUG - 2017-11-14 12:14:56 --> UTF-8 Support Enabled
INFO - 2017-11-14 12:14:56 --> Utf8 Class Initialized
INFO - 2017-11-14 12:14:56 --> URI Class Initialized
INFO - 2017-11-14 12:14:56 --> Router Class Initialized
INFO - 2017-11-14 12:14:56 --> Output Class Initialized
INFO - 2017-11-14 12:14:56 --> Security Class Initialized
DEBUG - 2017-11-14 12:14:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 12:14:56 --> Input Class Initialized
INFO - 2017-11-14 12:14:56 --> Language Class Initialized
INFO - 2017-11-14 12:14:56 --> Language Class Initialized
INFO - 2017-11-14 12:14:56 --> Config Class Initialized
INFO - 2017-11-14 12:14:56 --> Loader Class Initialized
DEBUG - 2017-11-14 12:14:56 --> Config file loaded: D:\xampp\htdocs\construction_bay\application\config/construct-data.php
INFO - 2017-11-14 12:14:56 --> Helper loaded: url_helper
INFO - 2017-11-14 12:14:56 --> Helper loaded: form_helper
INFO - 2017-11-14 12:14:56 --> Helper loaded: date_helper
INFO - 2017-11-14 12:14:56 --> Helper loaded: util_helper
INFO - 2017-11-14 12:14:56 --> Helper loaded: text_helper
INFO - 2017-11-14 12:14:56 --> Helper loaded: string_helper
INFO - 2017-11-14 12:14:56 --> Database Driver Class Initialized
DEBUG - 2017-11-14 12:14:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-14 12:14:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-14 12:14:56 --> Email Class Initialized
INFO - 2017-11-14 12:14:56 --> Controller Class Initialized
INFO - 2017-11-14 12:14:56 --> Model Class Initialized
DEBUG - 2017-11-14 12:14:56 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_model.php
INFO - 2017-11-14 12:14:56 --> Model Class Initialized
DEBUG - 2017-11-14 12:14:56 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_functions_model.php
INFO - 2017-11-14 12:14:56 --> Model Class Initialized
ERROR - 2017-11-14 12:14:56 --> Severity: Notice --> Undefined variable: category D:\xampp\htdocs\construction_bay\application\views\common\header.php 309
DEBUG - 2017-11-14 12:14:56 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header.php
DEBUG - 2017-11-14 12:14:56 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\products-services.php
DEBUG - 2017-11-14 12:14:56 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/footer.php
INFO - 2017-11-14 12:14:56 --> Final output sent to browser
DEBUG - 2017-11-14 12:14:56 --> Total execution time: 0.0540
INFO - 2017-11-14 12:14:56 --> Config Class Initialized
INFO - 2017-11-14 12:14:56 --> Hooks Class Initialized
DEBUG - 2017-11-14 12:14:56 --> UTF-8 Support Enabled
INFO - 2017-11-14 12:14:56 --> Utf8 Class Initialized
INFO - 2017-11-14 12:14:56 --> URI Class Initialized
INFO - 2017-11-14 12:14:56 --> Router Class Initialized
INFO - 2017-11-14 12:14:56 --> Output Class Initialized
INFO - 2017-11-14 12:14:56 --> Security Class Initialized
DEBUG - 2017-11-14 12:14:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 12:14:56 --> Input Class Initialized
INFO - 2017-11-14 12:14:56 --> Language Class Initialized
ERROR - 2017-11-14 12:14:56 --> 404 Page Not Found: /index
INFO - 2017-11-14 12:14:58 --> Config Class Initialized
INFO - 2017-11-14 12:14:58 --> Hooks Class Initialized
DEBUG - 2017-11-14 12:14:58 --> UTF-8 Support Enabled
INFO - 2017-11-14 12:14:58 --> Utf8 Class Initialized
INFO - 2017-11-14 12:14:58 --> URI Class Initialized
INFO - 2017-11-14 12:14:58 --> Router Class Initialized
INFO - 2017-11-14 12:14:58 --> Output Class Initialized
INFO - 2017-11-14 12:14:58 --> Security Class Initialized
DEBUG - 2017-11-14 12:14:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 12:14:58 --> Input Class Initialized
INFO - 2017-11-14 12:14:58 --> Language Class Initialized
INFO - 2017-11-14 12:14:58 --> Language Class Initialized
INFO - 2017-11-14 12:14:58 --> Config Class Initialized
INFO - 2017-11-14 12:14:58 --> Loader Class Initialized
DEBUG - 2017-11-14 12:14:58 --> Config file loaded: D:\xampp\htdocs\construction_bay\application\config/construct-data.php
INFO - 2017-11-14 12:14:58 --> Helper loaded: url_helper
INFO - 2017-11-14 12:14:58 --> Helper loaded: form_helper
INFO - 2017-11-14 12:14:58 --> Helper loaded: date_helper
INFO - 2017-11-14 12:14:58 --> Helper loaded: util_helper
INFO - 2017-11-14 12:14:58 --> Helper loaded: text_helper
INFO - 2017-11-14 12:14:58 --> Helper loaded: string_helper
INFO - 2017-11-14 12:14:58 --> Database Driver Class Initialized
DEBUG - 2017-11-14 12:14:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-14 12:14:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-14 12:14:58 --> Email Class Initialized
INFO - 2017-11-14 12:14:58 --> Controller Class Initialized
INFO - 2017-11-14 12:14:58 --> Model Class Initialized
DEBUG - 2017-11-14 12:14:58 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_model.php
INFO - 2017-11-14 12:14:58 --> Model Class Initialized
DEBUG - 2017-11-14 12:14:58 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_functions_model.php
INFO - 2017-11-14 12:14:58 --> Model Class Initialized
ERROR - 2017-11-14 12:14:58 --> Severity: Notice --> Undefined variable: category D:\xampp\htdocs\construction_bay\application\views\common\header.php 309
DEBUG - 2017-11-14 12:14:58 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header.php
DEBUG - 2017-11-14 12:14:58 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\products-services.php
DEBUG - 2017-11-14 12:14:58 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/footer.php
INFO - 2017-11-14 12:14:58 --> Final output sent to browser
DEBUG - 2017-11-14 12:14:58 --> Total execution time: 0.0500
INFO - 2017-11-14 12:14:59 --> Config Class Initialized
INFO - 2017-11-14 12:14:59 --> Hooks Class Initialized
DEBUG - 2017-11-14 12:14:59 --> UTF-8 Support Enabled
INFO - 2017-11-14 12:14:59 --> Utf8 Class Initialized
INFO - 2017-11-14 12:14:59 --> URI Class Initialized
INFO - 2017-11-14 12:14:59 --> Router Class Initialized
INFO - 2017-11-14 12:14:59 --> Output Class Initialized
INFO - 2017-11-14 12:14:59 --> Security Class Initialized
DEBUG - 2017-11-14 12:14:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 12:14:59 --> Input Class Initialized
INFO - 2017-11-14 12:14:59 --> Language Class Initialized
ERROR - 2017-11-14 12:14:59 --> 404 Page Not Found: /index
INFO - 2017-11-14 12:15:20 --> Config Class Initialized
INFO - 2017-11-14 12:15:20 --> Hooks Class Initialized
DEBUG - 2017-11-14 12:15:20 --> UTF-8 Support Enabled
INFO - 2017-11-14 12:15:20 --> Utf8 Class Initialized
INFO - 2017-11-14 12:15:20 --> URI Class Initialized
INFO - 2017-11-14 12:15:20 --> Router Class Initialized
INFO - 2017-11-14 12:15:20 --> Output Class Initialized
INFO - 2017-11-14 12:15:20 --> Security Class Initialized
DEBUG - 2017-11-14 12:15:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 12:15:20 --> Input Class Initialized
INFO - 2017-11-14 12:15:20 --> Language Class Initialized
INFO - 2017-11-14 12:15:20 --> Language Class Initialized
INFO - 2017-11-14 12:15:20 --> Config Class Initialized
INFO - 2017-11-14 12:15:20 --> Loader Class Initialized
DEBUG - 2017-11-14 12:15:20 --> Config file loaded: D:\xampp\htdocs\construction_bay\application\config/construct-data.php
INFO - 2017-11-14 12:15:20 --> Helper loaded: url_helper
INFO - 2017-11-14 12:15:20 --> Helper loaded: form_helper
INFO - 2017-11-14 12:15:20 --> Helper loaded: date_helper
INFO - 2017-11-14 12:15:20 --> Helper loaded: util_helper
INFO - 2017-11-14 12:15:20 --> Helper loaded: text_helper
INFO - 2017-11-14 12:15:20 --> Helper loaded: string_helper
INFO - 2017-11-14 12:15:20 --> Database Driver Class Initialized
DEBUG - 2017-11-14 12:15:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-14 12:15:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-14 12:15:20 --> Email Class Initialized
INFO - 2017-11-14 12:15:20 --> Controller Class Initialized
INFO - 2017-11-14 12:15:20 --> Model Class Initialized
DEBUG - 2017-11-14 12:15:20 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_model.php
INFO - 2017-11-14 12:15:20 --> Model Class Initialized
DEBUG - 2017-11-14 12:15:20 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_functions_model.php
INFO - 2017-11-14 12:15:20 --> Model Class Initialized
ERROR - 2017-11-14 12:15:20 --> Severity: Notice --> Undefined variable: category D:\xampp\htdocs\construction_bay\application\views\common\header.php 309
DEBUG - 2017-11-14 12:15:20 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header.php
DEBUG - 2017-11-14 12:15:20 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\products-services.php
DEBUG - 2017-11-14 12:15:20 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/footer.php
INFO - 2017-11-14 12:15:20 --> Final output sent to browser
DEBUG - 2017-11-14 12:15:20 --> Total execution time: 0.0690
INFO - 2017-11-14 12:15:21 --> Config Class Initialized
INFO - 2017-11-14 12:15:21 --> Hooks Class Initialized
DEBUG - 2017-11-14 12:15:21 --> UTF-8 Support Enabled
INFO - 2017-11-14 12:15:21 --> Utf8 Class Initialized
INFO - 2017-11-14 12:15:21 --> URI Class Initialized
INFO - 2017-11-14 12:15:21 --> Router Class Initialized
INFO - 2017-11-14 12:15:21 --> Output Class Initialized
INFO - 2017-11-14 12:15:21 --> Security Class Initialized
DEBUG - 2017-11-14 12:15:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 12:15:21 --> Input Class Initialized
INFO - 2017-11-14 12:15:21 --> Language Class Initialized
ERROR - 2017-11-14 12:15:21 --> 404 Page Not Found: /index
INFO - 2017-11-14 12:15:33 --> Config Class Initialized
INFO - 2017-11-14 12:15:33 --> Hooks Class Initialized
DEBUG - 2017-11-14 12:15:34 --> UTF-8 Support Enabled
INFO - 2017-11-14 12:15:34 --> Utf8 Class Initialized
INFO - 2017-11-14 12:15:34 --> URI Class Initialized
INFO - 2017-11-14 12:15:34 --> Router Class Initialized
INFO - 2017-11-14 12:15:34 --> Output Class Initialized
INFO - 2017-11-14 12:15:34 --> Security Class Initialized
DEBUG - 2017-11-14 12:15:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 12:15:34 --> Input Class Initialized
INFO - 2017-11-14 12:15:34 --> Language Class Initialized
INFO - 2017-11-14 12:15:34 --> Language Class Initialized
INFO - 2017-11-14 12:15:34 --> Config Class Initialized
INFO - 2017-11-14 12:15:34 --> Loader Class Initialized
DEBUG - 2017-11-14 12:15:34 --> Config file loaded: D:\xampp\htdocs\construction_bay\application\config/construct-data.php
INFO - 2017-11-14 12:15:34 --> Helper loaded: url_helper
INFO - 2017-11-14 12:15:34 --> Helper loaded: form_helper
INFO - 2017-11-14 12:15:34 --> Helper loaded: date_helper
INFO - 2017-11-14 12:15:34 --> Helper loaded: util_helper
INFO - 2017-11-14 12:15:34 --> Helper loaded: text_helper
INFO - 2017-11-14 12:15:34 --> Helper loaded: string_helper
INFO - 2017-11-14 12:15:34 --> Database Driver Class Initialized
DEBUG - 2017-11-14 12:15:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-14 12:15:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-14 12:15:34 --> Email Class Initialized
INFO - 2017-11-14 12:15:34 --> Controller Class Initialized
INFO - 2017-11-14 12:15:34 --> Model Class Initialized
DEBUG - 2017-11-14 12:15:34 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_model.php
INFO - 2017-11-14 12:15:34 --> Model Class Initialized
DEBUG - 2017-11-14 12:15:34 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_functions_model.php
INFO - 2017-11-14 12:15:34 --> Model Class Initialized
DEBUG - 2017-11-14 12:15:34 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\companies/companies_header.php
DEBUG - 2017-11-14 12:15:34 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\companies/companies_page.php
DEBUG - 2017-11-14 12:15:34 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\companies/companies_footer.php
INFO - 2017-11-14 12:15:34 --> Final output sent to browser
DEBUG - 2017-11-14 12:15:34 --> Total execution time: 0.0740
INFO - 2017-11-14 12:15:35 --> Config Class Initialized
INFO - 2017-11-14 12:15:35 --> Hooks Class Initialized
DEBUG - 2017-11-14 12:15:35 --> UTF-8 Support Enabled
INFO - 2017-11-14 12:15:35 --> Utf8 Class Initialized
INFO - 2017-11-14 12:15:35 --> URI Class Initialized
INFO - 2017-11-14 12:15:35 --> Router Class Initialized
INFO - 2017-11-14 12:15:35 --> Output Class Initialized
INFO - 2017-11-14 12:15:35 --> Security Class Initialized
DEBUG - 2017-11-14 12:15:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 12:15:35 --> Input Class Initialized
INFO - 2017-11-14 12:15:35 --> Language Class Initialized
INFO - 2017-11-14 12:15:35 --> Language Class Initialized
INFO - 2017-11-14 12:15:35 --> Config Class Initialized
INFO - 2017-11-14 12:15:35 --> Loader Class Initialized
DEBUG - 2017-11-14 12:15:35 --> Config file loaded: D:\xampp\htdocs\construction_bay\application\config/construct-data.php
INFO - 2017-11-14 12:15:35 --> Helper loaded: url_helper
INFO - 2017-11-14 12:15:35 --> Helper loaded: form_helper
INFO - 2017-11-14 12:15:35 --> Helper loaded: date_helper
INFO - 2017-11-14 12:15:35 --> Helper loaded: util_helper
INFO - 2017-11-14 12:15:35 --> Helper loaded: text_helper
INFO - 2017-11-14 12:15:35 --> Helper loaded: string_helper
INFO - 2017-11-14 12:15:35 --> Database Driver Class Initialized
DEBUG - 2017-11-14 12:15:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-14 12:15:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-14 12:15:35 --> Email Class Initialized
INFO - 2017-11-14 12:15:35 --> Controller Class Initialized
INFO - 2017-11-14 12:15:35 --> Model Class Initialized
DEBUG - 2017-11-14 12:15:35 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_model.php
INFO - 2017-11-14 12:15:35 --> Model Class Initialized
DEBUG - 2017-11-14 12:15:35 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_functions_model.php
INFO - 2017-11-14 12:15:35 --> Model Class Initialized
DEBUG - 2017-11-14 12:15:35 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/template.php
INFO - 2017-11-14 12:15:39 --> Config Class Initialized
INFO - 2017-11-14 12:15:39 --> Hooks Class Initialized
DEBUG - 2017-11-14 12:15:39 --> UTF-8 Support Enabled
INFO - 2017-11-14 12:15:39 --> Utf8 Class Initialized
INFO - 2017-11-14 12:15:39 --> URI Class Initialized
INFO - 2017-11-14 12:15:39 --> Router Class Initialized
INFO - 2017-11-14 12:15:39 --> Output Class Initialized
INFO - 2017-11-14 12:15:39 --> Security Class Initialized
DEBUG - 2017-11-14 12:15:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 12:15:39 --> Input Class Initialized
INFO - 2017-11-14 12:15:39 --> Language Class Initialized
INFO - 2017-11-14 12:15:39 --> Language Class Initialized
INFO - 2017-11-14 12:15:39 --> Config Class Initialized
INFO - 2017-11-14 12:15:39 --> Loader Class Initialized
DEBUG - 2017-11-14 12:15:39 --> Config file loaded: D:\xampp\htdocs\construction_bay\application\config/construct-data.php
INFO - 2017-11-14 12:15:39 --> Helper loaded: url_helper
INFO - 2017-11-14 12:15:39 --> Helper loaded: form_helper
INFO - 2017-11-14 12:15:39 --> Helper loaded: date_helper
INFO - 2017-11-14 12:15:39 --> Helper loaded: util_helper
INFO - 2017-11-14 12:15:39 --> Helper loaded: text_helper
INFO - 2017-11-14 12:15:39 --> Helper loaded: string_helper
INFO - 2017-11-14 12:15:39 --> Database Driver Class Initialized
DEBUG - 2017-11-14 12:15:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-14 12:15:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-14 12:15:39 --> Email Class Initialized
INFO - 2017-11-14 12:15:39 --> Controller Class Initialized
INFO - 2017-11-14 12:15:39 --> Model Class Initialized
DEBUG - 2017-11-14 12:15:39 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_model.php
INFO - 2017-11-14 12:15:39 --> Model Class Initialized
DEBUG - 2017-11-14 12:15:39 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_functions_model.php
INFO - 2017-11-14 12:15:39 --> Model Class Initialized
DEBUG - 2017-11-14 12:15:39 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/template.php
INFO - 2017-11-14 12:16:05 --> Config Class Initialized
INFO - 2017-11-14 12:16:05 --> Hooks Class Initialized
DEBUG - 2017-11-14 12:16:05 --> UTF-8 Support Enabled
INFO - 2017-11-14 12:16:05 --> Utf8 Class Initialized
INFO - 2017-11-14 12:16:05 --> URI Class Initialized
INFO - 2017-11-14 12:16:05 --> Router Class Initialized
INFO - 2017-11-14 12:16:05 --> Output Class Initialized
INFO - 2017-11-14 12:16:05 --> Security Class Initialized
DEBUG - 2017-11-14 12:16:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 12:16:05 --> Input Class Initialized
INFO - 2017-11-14 12:16:05 --> Language Class Initialized
INFO - 2017-11-14 12:16:05 --> Language Class Initialized
INFO - 2017-11-14 12:16:05 --> Config Class Initialized
INFO - 2017-11-14 12:16:05 --> Loader Class Initialized
DEBUG - 2017-11-14 12:16:05 --> Config file loaded: D:\xampp\htdocs\construction_bay\application\config/construct-data.php
INFO - 2017-11-14 12:16:05 --> Helper loaded: url_helper
INFO - 2017-11-14 12:16:05 --> Helper loaded: form_helper
INFO - 2017-11-14 12:16:05 --> Helper loaded: date_helper
INFO - 2017-11-14 12:16:05 --> Helper loaded: util_helper
INFO - 2017-11-14 12:16:05 --> Helper loaded: text_helper
INFO - 2017-11-14 12:16:05 --> Helper loaded: string_helper
INFO - 2017-11-14 12:16:05 --> Database Driver Class Initialized
DEBUG - 2017-11-14 12:16:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-14 12:16:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-14 12:16:05 --> Email Class Initialized
INFO - 2017-11-14 12:16:05 --> Controller Class Initialized
INFO - 2017-11-14 12:16:05 --> Model Class Initialized
DEBUG - 2017-11-14 12:16:05 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_model.php
INFO - 2017-11-14 12:16:05 --> Model Class Initialized
DEBUG - 2017-11-14 12:16:05 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_functions_model.php
INFO - 2017-11-14 12:16:05 --> Model Class Initialized
DEBUG - 2017-11-14 12:16:05 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/template.php
INFO - 2017-11-14 12:16:19 --> Config Class Initialized
INFO - 2017-11-14 12:16:19 --> Hooks Class Initialized
DEBUG - 2017-11-14 12:16:19 --> UTF-8 Support Enabled
INFO - 2017-11-14 12:16:19 --> Utf8 Class Initialized
INFO - 2017-11-14 12:16:19 --> URI Class Initialized
INFO - 2017-11-14 12:16:19 --> Router Class Initialized
INFO - 2017-11-14 12:16:19 --> Output Class Initialized
INFO - 2017-11-14 12:16:19 --> Security Class Initialized
DEBUG - 2017-11-14 12:16:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 12:16:19 --> Input Class Initialized
INFO - 2017-11-14 12:16:19 --> Language Class Initialized
INFO - 2017-11-14 12:16:19 --> Language Class Initialized
INFO - 2017-11-14 12:16:19 --> Config Class Initialized
INFO - 2017-11-14 12:16:19 --> Loader Class Initialized
DEBUG - 2017-11-14 12:16:19 --> Config file loaded: D:\xampp\htdocs\construction_bay\application\config/construct-data.php
INFO - 2017-11-14 12:16:19 --> Helper loaded: url_helper
INFO - 2017-11-14 12:16:19 --> Helper loaded: form_helper
INFO - 2017-11-14 12:16:19 --> Helper loaded: date_helper
INFO - 2017-11-14 12:16:19 --> Helper loaded: util_helper
INFO - 2017-11-14 12:16:19 --> Helper loaded: text_helper
INFO - 2017-11-14 12:16:19 --> Helper loaded: string_helper
INFO - 2017-11-14 12:16:19 --> Database Driver Class Initialized
DEBUG - 2017-11-14 12:16:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-14 12:16:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-14 12:16:19 --> Email Class Initialized
INFO - 2017-11-14 12:16:19 --> Controller Class Initialized
INFO - 2017-11-14 12:16:19 --> Model Class Initialized
DEBUG - 2017-11-14 12:16:19 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_model.php
INFO - 2017-11-14 12:16:19 --> Model Class Initialized
DEBUG - 2017-11-14 12:16:19 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_functions_model.php
INFO - 2017-11-14 12:16:19 --> Model Class Initialized
DEBUG - 2017-11-14 12:16:19 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/template.php
INFO - 2017-11-14 12:16:26 --> Config Class Initialized
INFO - 2017-11-14 12:16:26 --> Hooks Class Initialized
DEBUG - 2017-11-14 12:16:26 --> UTF-8 Support Enabled
INFO - 2017-11-14 12:16:26 --> Utf8 Class Initialized
INFO - 2017-11-14 12:16:26 --> URI Class Initialized
INFO - 2017-11-14 12:16:26 --> Router Class Initialized
INFO - 2017-11-14 12:16:26 --> Output Class Initialized
INFO - 2017-11-14 12:16:26 --> Security Class Initialized
DEBUG - 2017-11-14 12:16:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 12:16:26 --> Input Class Initialized
INFO - 2017-11-14 12:16:26 --> Language Class Initialized
ERROR - 2017-11-14 12:16:26 --> 404 Page Not Found: /index
INFO - 2017-11-14 12:17:36 --> Config Class Initialized
INFO - 2017-11-14 12:17:36 --> Hooks Class Initialized
DEBUG - 2017-11-14 12:17:36 --> UTF-8 Support Enabled
INFO - 2017-11-14 12:17:36 --> Utf8 Class Initialized
INFO - 2017-11-14 12:17:36 --> URI Class Initialized
INFO - 2017-11-14 12:17:36 --> Router Class Initialized
INFO - 2017-11-14 12:17:36 --> Output Class Initialized
INFO - 2017-11-14 12:17:36 --> Security Class Initialized
DEBUG - 2017-11-14 12:17:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 12:17:36 --> Input Class Initialized
INFO - 2017-11-14 12:17:36 --> Language Class Initialized
INFO - 2017-11-14 12:17:36 --> Language Class Initialized
INFO - 2017-11-14 12:17:36 --> Config Class Initialized
INFO - 2017-11-14 12:17:36 --> Loader Class Initialized
DEBUG - 2017-11-14 12:17:36 --> Config file loaded: D:\xampp\htdocs\construction_bay\application\config/construct-data.php
INFO - 2017-11-14 12:17:36 --> Helper loaded: url_helper
INFO - 2017-11-14 12:17:36 --> Helper loaded: form_helper
INFO - 2017-11-14 12:17:36 --> Helper loaded: date_helper
INFO - 2017-11-14 12:17:36 --> Helper loaded: util_helper
INFO - 2017-11-14 12:17:36 --> Helper loaded: text_helper
INFO - 2017-11-14 12:17:36 --> Helper loaded: string_helper
INFO - 2017-11-14 12:17:36 --> Database Driver Class Initialized
DEBUG - 2017-11-14 12:17:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-14 12:17:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-14 12:17:36 --> Email Class Initialized
INFO - 2017-11-14 12:17:36 --> Controller Class Initialized
INFO - 2017-11-14 12:17:36 --> Model Class Initialized
DEBUG - 2017-11-14 12:17:36 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_model.php
INFO - 2017-11-14 12:17:36 --> Model Class Initialized
DEBUG - 2017-11-14 12:17:36 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_functions_model.php
INFO - 2017-11-14 12:17:36 --> Model Class Initialized
DEBUG - 2017-11-14 12:17:37 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\companies/companies_header.php
DEBUG - 2017-11-14 12:17:37 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\companies/companies_page.php
DEBUG - 2017-11-14 12:17:37 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\companies/companies_footer.php
INFO - 2017-11-14 12:17:37 --> Final output sent to browser
DEBUG - 2017-11-14 12:17:37 --> Total execution time: 0.0820
INFO - 2017-11-14 12:17:37 --> Config Class Initialized
INFO - 2017-11-14 12:17:37 --> Hooks Class Initialized
DEBUG - 2017-11-14 12:17:37 --> UTF-8 Support Enabled
INFO - 2017-11-14 12:17:37 --> Utf8 Class Initialized
INFO - 2017-11-14 12:17:37 --> URI Class Initialized
INFO - 2017-11-14 12:17:37 --> Router Class Initialized
INFO - 2017-11-14 12:17:37 --> Output Class Initialized
INFO - 2017-11-14 12:17:37 --> Security Class Initialized
DEBUG - 2017-11-14 12:17:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 12:17:37 --> Input Class Initialized
INFO - 2017-11-14 12:17:37 --> Language Class Initialized
INFO - 2017-11-14 12:17:37 --> Language Class Initialized
INFO - 2017-11-14 12:17:37 --> Config Class Initialized
INFO - 2017-11-14 12:17:37 --> Loader Class Initialized
DEBUG - 2017-11-14 12:17:37 --> Config file loaded: D:\xampp\htdocs\construction_bay\application\config/construct-data.php
INFO - 2017-11-14 12:17:37 --> Helper loaded: url_helper
INFO - 2017-11-14 12:17:37 --> Helper loaded: form_helper
INFO - 2017-11-14 12:17:37 --> Helper loaded: date_helper
INFO - 2017-11-14 12:17:37 --> Helper loaded: util_helper
INFO - 2017-11-14 12:17:37 --> Helper loaded: text_helper
INFO - 2017-11-14 12:17:37 --> Helper loaded: string_helper
INFO - 2017-11-14 12:17:37 --> Database Driver Class Initialized
DEBUG - 2017-11-14 12:17:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-14 12:17:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-14 12:17:37 --> Email Class Initialized
INFO - 2017-11-14 12:17:37 --> Controller Class Initialized
INFO - 2017-11-14 12:17:37 --> Model Class Initialized
DEBUG - 2017-11-14 12:17:37 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_model.php
INFO - 2017-11-14 12:17:37 --> Model Class Initialized
DEBUG - 2017-11-14 12:17:37 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_functions_model.php
INFO - 2017-11-14 12:17:37 --> Model Class Initialized
ERROR - 2017-11-14 12:17:37 --> Severity: Notice --> Undefined variable: category D:\xampp\htdocs\construction_bay\application\views\common\header.php 309
DEBUG - 2017-11-14 12:17:37 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header.php
DEBUG - 2017-11-14 12:17:37 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\products-services.php
DEBUG - 2017-11-14 12:17:37 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/footer.php
INFO - 2017-11-14 12:17:37 --> Final output sent to browser
DEBUG - 2017-11-14 12:17:37 --> Total execution time: 0.0810
INFO - 2017-11-14 12:17:38 --> Config Class Initialized
INFO - 2017-11-14 12:17:38 --> Hooks Class Initialized
DEBUG - 2017-11-14 12:17:38 --> UTF-8 Support Enabled
INFO - 2017-11-14 12:17:38 --> Utf8 Class Initialized
INFO - 2017-11-14 12:17:38 --> URI Class Initialized
INFO - 2017-11-14 12:17:38 --> Router Class Initialized
INFO - 2017-11-14 12:17:38 --> Output Class Initialized
INFO - 2017-11-14 12:17:38 --> Security Class Initialized
DEBUG - 2017-11-14 12:17:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 12:17:38 --> Input Class Initialized
INFO - 2017-11-14 12:17:38 --> Language Class Initialized
ERROR - 2017-11-14 12:17:38 --> 404 Page Not Found: /index
INFO - 2017-11-14 12:17:39 --> Config Class Initialized
INFO - 2017-11-14 12:17:39 --> Hooks Class Initialized
DEBUG - 2017-11-14 12:17:39 --> UTF-8 Support Enabled
INFO - 2017-11-14 12:17:39 --> Utf8 Class Initialized
INFO - 2017-11-14 12:17:39 --> URI Class Initialized
INFO - 2017-11-14 12:17:39 --> Router Class Initialized
INFO - 2017-11-14 12:17:39 --> Output Class Initialized
INFO - 2017-11-14 12:17:39 --> Security Class Initialized
DEBUG - 2017-11-14 12:17:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 12:17:39 --> Input Class Initialized
INFO - 2017-11-14 12:17:39 --> Language Class Initialized
INFO - 2017-11-14 12:17:39 --> Language Class Initialized
INFO - 2017-11-14 12:17:39 --> Config Class Initialized
INFO - 2017-11-14 12:17:39 --> Loader Class Initialized
DEBUG - 2017-11-14 12:17:39 --> Config file loaded: D:\xampp\htdocs\construction_bay\application\config/construct-data.php
INFO - 2017-11-14 12:17:39 --> Helper loaded: url_helper
INFO - 2017-11-14 12:17:39 --> Helper loaded: form_helper
INFO - 2017-11-14 12:17:39 --> Helper loaded: date_helper
INFO - 2017-11-14 12:17:39 --> Helper loaded: util_helper
INFO - 2017-11-14 12:17:39 --> Helper loaded: text_helper
INFO - 2017-11-14 12:17:39 --> Helper loaded: string_helper
INFO - 2017-11-14 12:17:39 --> Database Driver Class Initialized
DEBUG - 2017-11-14 12:17:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-14 12:17:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-14 12:17:39 --> Email Class Initialized
INFO - 2017-11-14 12:17:39 --> Controller Class Initialized
INFO - 2017-11-14 12:17:39 --> Model Class Initialized
DEBUG - 2017-11-14 12:17:39 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_model.php
INFO - 2017-11-14 12:17:39 --> Model Class Initialized
DEBUG - 2017-11-14 12:17:39 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_functions_model.php
INFO - 2017-11-14 12:17:39 --> Model Class Initialized
ERROR - 2017-11-14 12:17:39 --> Severity: Notice --> Undefined variable: category D:\xampp\htdocs\construction_bay\application\views\common\header.php 309
DEBUG - 2017-11-14 12:17:39 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header.php
DEBUG - 2017-11-14 12:17:39 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\products-services.php
DEBUG - 2017-11-14 12:17:39 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/footer.php
INFO - 2017-11-14 12:17:39 --> Final output sent to browser
DEBUG - 2017-11-14 12:17:39 --> Total execution time: 0.0980
INFO - 2017-11-14 12:17:40 --> Config Class Initialized
INFO - 2017-11-14 12:17:40 --> Hooks Class Initialized
DEBUG - 2017-11-14 12:17:40 --> UTF-8 Support Enabled
INFO - 2017-11-14 12:17:40 --> Utf8 Class Initialized
INFO - 2017-11-14 12:17:40 --> URI Class Initialized
INFO - 2017-11-14 12:17:40 --> Router Class Initialized
INFO - 2017-11-14 12:17:40 --> Output Class Initialized
INFO - 2017-11-14 12:17:40 --> Security Class Initialized
DEBUG - 2017-11-14 12:17:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 12:17:40 --> Input Class Initialized
INFO - 2017-11-14 12:17:40 --> Language Class Initialized
ERROR - 2017-11-14 12:17:40 --> 404 Page Not Found: /index
INFO - 2017-11-14 12:20:41 --> Config Class Initialized
INFO - 2017-11-14 12:20:41 --> Hooks Class Initialized
DEBUG - 2017-11-14 12:20:41 --> UTF-8 Support Enabled
INFO - 2017-11-14 12:20:41 --> Utf8 Class Initialized
INFO - 2017-11-14 12:20:41 --> URI Class Initialized
INFO - 2017-11-14 12:20:41 --> Router Class Initialized
INFO - 2017-11-14 12:20:41 --> Output Class Initialized
INFO - 2017-11-14 12:20:41 --> Security Class Initialized
DEBUG - 2017-11-14 12:20:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 12:20:41 --> Input Class Initialized
INFO - 2017-11-14 12:20:41 --> Language Class Initialized
INFO - 2017-11-14 12:20:41 --> Language Class Initialized
INFO - 2017-11-14 12:20:41 --> Config Class Initialized
INFO - 2017-11-14 12:20:41 --> Loader Class Initialized
DEBUG - 2017-11-14 12:20:41 --> Config file loaded: D:\xampp\htdocs\construction_bay\application\config/construct-data.php
INFO - 2017-11-14 12:20:41 --> Helper loaded: url_helper
INFO - 2017-11-14 12:20:41 --> Helper loaded: form_helper
INFO - 2017-11-14 12:20:41 --> Helper loaded: date_helper
INFO - 2017-11-14 12:20:41 --> Helper loaded: util_helper
INFO - 2017-11-14 12:20:41 --> Helper loaded: text_helper
INFO - 2017-11-14 12:20:41 --> Helper loaded: string_helper
INFO - 2017-11-14 12:20:41 --> Database Driver Class Initialized
DEBUG - 2017-11-14 12:20:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-14 12:20:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-14 12:20:41 --> Email Class Initialized
INFO - 2017-11-14 12:20:41 --> Controller Class Initialized
INFO - 2017-11-14 12:20:41 --> Model Class Initialized
DEBUG - 2017-11-14 12:20:41 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_model.php
INFO - 2017-11-14 12:20:41 --> Model Class Initialized
DEBUG - 2017-11-14 12:20:41 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_functions_model.php
INFO - 2017-11-14 12:20:41 --> Model Class Initialized
DEBUG - 2017-11-14 12:20:41 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\companies/companies_header.php
DEBUG - 2017-11-14 12:20:41 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\companies/companies_page.php
DEBUG - 2017-11-14 12:20:41 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\companies/companies_footer.php
INFO - 2017-11-14 12:20:41 --> Final output sent to browser
DEBUG - 2017-11-14 12:20:41 --> Total execution time: 0.0870
INFO - 2017-11-14 12:20:42 --> Config Class Initialized
INFO - 2017-11-14 12:20:42 --> Hooks Class Initialized
DEBUG - 2017-11-14 12:20:42 --> UTF-8 Support Enabled
INFO - 2017-11-14 12:20:42 --> Utf8 Class Initialized
INFO - 2017-11-14 12:20:42 --> URI Class Initialized
INFO - 2017-11-14 12:20:42 --> Router Class Initialized
INFO - 2017-11-14 12:20:42 --> Output Class Initialized
INFO - 2017-11-14 12:20:42 --> Security Class Initialized
DEBUG - 2017-11-14 12:20:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 12:20:42 --> Input Class Initialized
INFO - 2017-11-14 12:20:42 --> Language Class Initialized
INFO - 2017-11-14 12:20:42 --> Language Class Initialized
INFO - 2017-11-14 12:20:42 --> Config Class Initialized
INFO - 2017-11-14 12:20:42 --> Loader Class Initialized
DEBUG - 2017-11-14 12:20:42 --> Config file loaded: D:\xampp\htdocs\construction_bay\application\config/construct-data.php
INFO - 2017-11-14 12:20:42 --> Helper loaded: url_helper
INFO - 2017-11-14 12:20:42 --> Helper loaded: form_helper
INFO - 2017-11-14 12:20:42 --> Helper loaded: date_helper
INFO - 2017-11-14 12:20:42 --> Helper loaded: util_helper
INFO - 2017-11-14 12:20:42 --> Helper loaded: text_helper
INFO - 2017-11-14 12:20:42 --> Helper loaded: string_helper
INFO - 2017-11-14 12:20:42 --> Database Driver Class Initialized
DEBUG - 2017-11-14 12:20:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-14 12:20:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-14 12:20:42 --> Email Class Initialized
INFO - 2017-11-14 12:20:42 --> Controller Class Initialized
INFO - 2017-11-14 12:20:42 --> Model Class Initialized
DEBUG - 2017-11-14 12:20:42 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_model.php
INFO - 2017-11-14 12:20:42 --> Model Class Initialized
DEBUG - 2017-11-14 12:20:42 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_functions_model.php
INFO - 2017-11-14 12:20:42 --> Model Class Initialized
DEBUG - 2017-11-14 12:20:42 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/template.php
INFO - 2017-11-14 12:20:58 --> Config Class Initialized
INFO - 2017-11-14 12:20:58 --> Hooks Class Initialized
DEBUG - 2017-11-14 12:20:58 --> UTF-8 Support Enabled
INFO - 2017-11-14 12:20:58 --> Utf8 Class Initialized
INFO - 2017-11-14 12:20:58 --> URI Class Initialized
INFO - 2017-11-14 12:20:58 --> Router Class Initialized
INFO - 2017-11-14 12:20:58 --> Output Class Initialized
INFO - 2017-11-14 12:20:58 --> Security Class Initialized
DEBUG - 2017-11-14 12:20:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 12:20:58 --> Input Class Initialized
INFO - 2017-11-14 12:20:58 --> Language Class Initialized
INFO - 2017-11-14 12:20:58 --> Language Class Initialized
INFO - 2017-11-14 12:20:58 --> Config Class Initialized
INFO - 2017-11-14 12:20:58 --> Loader Class Initialized
DEBUG - 2017-11-14 12:20:58 --> Config file loaded: D:\xampp\htdocs\construction_bay\application\config/construct-data.php
INFO - 2017-11-14 12:20:58 --> Helper loaded: url_helper
INFO - 2017-11-14 12:20:58 --> Helper loaded: form_helper
INFO - 2017-11-14 12:20:58 --> Helper loaded: date_helper
INFO - 2017-11-14 12:20:58 --> Helper loaded: util_helper
INFO - 2017-11-14 12:20:58 --> Helper loaded: text_helper
INFO - 2017-11-14 12:20:58 --> Helper loaded: string_helper
INFO - 2017-11-14 12:20:58 --> Database Driver Class Initialized
DEBUG - 2017-11-14 12:20:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-14 12:20:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-14 12:20:58 --> Email Class Initialized
INFO - 2017-11-14 12:20:58 --> Controller Class Initialized
INFO - 2017-11-14 12:20:58 --> Model Class Initialized
DEBUG - 2017-11-14 12:20:58 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_model.php
INFO - 2017-11-14 12:20:58 --> Model Class Initialized
DEBUG - 2017-11-14 12:20:58 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_functions_model.php
INFO - 2017-11-14 12:20:58 --> Model Class Initialized
ERROR - 2017-11-14 12:20:58 --> Severity: Notice --> Undefined variable: category D:\xampp\htdocs\construction_bay\application\views\common\header.php 309
DEBUG - 2017-11-14 12:20:58 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header.php
DEBUG - 2017-11-14 12:20:58 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\products-services.php
DEBUG - 2017-11-14 12:20:58 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/footer.php
INFO - 2017-11-14 12:20:58 --> Final output sent to browser
DEBUG - 2017-11-14 12:20:58 --> Total execution time: 0.0550
INFO - 2017-11-14 12:21:22 --> Config Class Initialized
INFO - 2017-11-14 12:21:22 --> Hooks Class Initialized
DEBUG - 2017-11-14 12:21:22 --> UTF-8 Support Enabled
INFO - 2017-11-14 12:21:22 --> Utf8 Class Initialized
INFO - 2017-11-14 12:21:22 --> URI Class Initialized
DEBUG - 2017-11-14 12:21:22 --> No URI present. Default controller set.
INFO - 2017-11-14 12:21:22 --> Router Class Initialized
INFO - 2017-11-14 12:21:22 --> Output Class Initialized
INFO - 2017-11-14 12:21:22 --> Security Class Initialized
DEBUG - 2017-11-14 12:21:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 12:21:22 --> Input Class Initialized
INFO - 2017-11-14 12:21:22 --> Language Class Initialized
INFO - 2017-11-14 12:21:22 --> Language Class Initialized
INFO - 2017-11-14 12:21:22 --> Config Class Initialized
INFO - 2017-11-14 12:21:22 --> Loader Class Initialized
DEBUG - 2017-11-14 12:21:22 --> Config file loaded: D:\xampp\htdocs\construction_bay\application\config/construct-data.php
INFO - 2017-11-14 12:21:22 --> Helper loaded: url_helper
INFO - 2017-11-14 12:21:22 --> Helper loaded: form_helper
INFO - 2017-11-14 12:21:22 --> Helper loaded: date_helper
INFO - 2017-11-14 12:21:22 --> Helper loaded: util_helper
INFO - 2017-11-14 12:21:22 --> Helper loaded: text_helper
INFO - 2017-11-14 12:21:22 --> Helper loaded: string_helper
INFO - 2017-11-14 12:21:22 --> Database Driver Class Initialized
DEBUG - 2017-11-14 12:21:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-14 12:21:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-14 12:21:22 --> Email Class Initialized
INFO - 2017-11-14 12:21:22 --> Controller Class Initialized
DEBUG - 2017-11-14 12:21:22 --> Home MX_Controller Initialized
INFO - 2017-11-14 12:21:22 --> Model Class Initialized
DEBUG - 2017-11-14 12:21:22 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_model.php
INFO - 2017-11-14 12:21:22 --> Model Class Initialized
DEBUG - 2017-11-14 12:21:22 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header.php
DEBUG - 2017-11-14 12:21:22 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/slider.php
DEBUG - 2017-11-14 12:21:22 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/index_body.php
DEBUG - 2017-11-14 12:21:22 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/index_footer.php
INFO - 2017-11-14 12:21:22 --> Final output sent to browser
DEBUG - 2017-11-14 12:21:22 --> Total execution time: 0.0560
INFO - 2017-11-14 12:21:24 --> Config Class Initialized
INFO - 2017-11-14 12:21:24 --> Hooks Class Initialized
DEBUG - 2017-11-14 12:21:24 --> UTF-8 Support Enabled
INFO - 2017-11-14 12:21:24 --> Utf8 Class Initialized
INFO - 2017-11-14 12:21:24 --> URI Class Initialized
INFO - 2017-11-14 12:21:24 --> Router Class Initialized
INFO - 2017-11-14 12:21:24 --> Output Class Initialized
INFO - 2017-11-14 12:21:24 --> Security Class Initialized
DEBUG - 2017-11-14 12:21:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 12:21:24 --> Input Class Initialized
INFO - 2017-11-14 12:21:24 --> Language Class Initialized
INFO - 2017-11-14 12:21:24 --> Language Class Initialized
INFO - 2017-11-14 12:21:24 --> Config Class Initialized
INFO - 2017-11-14 12:21:24 --> Loader Class Initialized
DEBUG - 2017-11-14 12:21:24 --> Config file loaded: D:\xampp\htdocs\construction_bay\application\config/construct-data.php
INFO - 2017-11-14 12:21:24 --> Helper loaded: url_helper
INFO - 2017-11-14 12:21:24 --> Helper loaded: form_helper
INFO - 2017-11-14 12:21:24 --> Helper loaded: date_helper
INFO - 2017-11-14 12:21:24 --> Helper loaded: util_helper
INFO - 2017-11-14 12:21:24 --> Helper loaded: text_helper
INFO - 2017-11-14 12:21:24 --> Helper loaded: string_helper
INFO - 2017-11-14 12:21:24 --> Database Driver Class Initialized
DEBUG - 2017-11-14 12:21:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-14 12:21:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-14 12:21:24 --> Email Class Initialized
INFO - 2017-11-14 12:21:24 --> Controller Class Initialized
INFO - 2017-11-14 12:21:24 --> Model Class Initialized
DEBUG - 2017-11-14 12:21:24 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_model.php
INFO - 2017-11-14 12:21:24 --> Model Class Initialized
DEBUG - 2017-11-14 12:21:24 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_functions_model.php
INFO - 2017-11-14 12:21:24 --> Model Class Initialized
ERROR - 2017-11-14 12:21:24 --> Severity: Notice --> Undefined variable: category D:\xampp\htdocs\construction_bay\application\views\common\header.php 309
DEBUG - 2017-11-14 12:21:24 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header.php
DEBUG - 2017-11-14 12:21:24 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\products-services.php
DEBUG - 2017-11-14 12:21:24 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/footer.php
INFO - 2017-11-14 12:21:24 --> Final output sent to browser
DEBUG - 2017-11-14 12:21:24 --> Total execution time: 0.0880
INFO - 2017-11-14 12:32:54 --> Config Class Initialized
INFO - 2017-11-14 12:32:54 --> Hooks Class Initialized
DEBUG - 2017-11-14 12:32:54 --> UTF-8 Support Enabled
INFO - 2017-11-14 12:32:54 --> Utf8 Class Initialized
INFO - 2017-11-14 12:32:54 --> URI Class Initialized
DEBUG - 2017-11-14 12:32:54 --> No URI present. Default controller set.
INFO - 2017-11-14 12:32:54 --> Router Class Initialized
INFO - 2017-11-14 12:32:54 --> Output Class Initialized
INFO - 2017-11-14 12:32:54 --> Security Class Initialized
DEBUG - 2017-11-14 12:32:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 12:32:54 --> Input Class Initialized
INFO - 2017-11-14 12:32:54 --> Language Class Initialized
INFO - 2017-11-14 12:32:54 --> Language Class Initialized
INFO - 2017-11-14 12:32:54 --> Config Class Initialized
INFO - 2017-11-14 12:32:54 --> Loader Class Initialized
DEBUG - 2017-11-14 12:32:54 --> Config file loaded: D:\xampp\htdocs\construction_bay\application\config/construct-data.php
INFO - 2017-11-14 12:32:54 --> Helper loaded: url_helper
INFO - 2017-11-14 12:32:54 --> Helper loaded: form_helper
INFO - 2017-11-14 12:32:54 --> Helper loaded: date_helper
INFO - 2017-11-14 12:32:54 --> Helper loaded: util_helper
INFO - 2017-11-14 12:32:54 --> Helper loaded: text_helper
INFO - 2017-11-14 12:32:54 --> Helper loaded: string_helper
INFO - 2017-11-14 12:32:54 --> Database Driver Class Initialized
DEBUG - 2017-11-14 12:32:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-14 12:32:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-14 12:32:54 --> Email Class Initialized
INFO - 2017-11-14 12:32:54 --> Controller Class Initialized
DEBUG - 2017-11-14 12:32:54 --> Home MX_Controller Initialized
INFO - 2017-11-14 12:32:54 --> Model Class Initialized
DEBUG - 2017-11-14 12:32:54 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_model.php
INFO - 2017-11-14 12:32:54 --> Model Class Initialized
DEBUG - 2017-11-14 12:32:54 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header.php
DEBUG - 2017-11-14 12:32:54 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/slider.php
DEBUG - 2017-11-14 12:32:54 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/index_body.php
DEBUG - 2017-11-14 12:32:54 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/index_footer.php
INFO - 2017-11-14 12:32:54 --> Final output sent to browser
DEBUG - 2017-11-14 12:32:54 --> Total execution time: 0.0500
INFO - 2017-11-14 12:32:57 --> Config Class Initialized
INFO - 2017-11-14 12:32:57 --> Hooks Class Initialized
DEBUG - 2017-11-14 12:32:57 --> UTF-8 Support Enabled
INFO - 2017-11-14 12:32:57 --> Utf8 Class Initialized
INFO - 2017-11-14 12:32:57 --> URI Class Initialized
INFO - 2017-11-14 12:32:57 --> Router Class Initialized
INFO - 2017-11-14 12:32:57 --> Output Class Initialized
INFO - 2017-11-14 12:32:57 --> Security Class Initialized
DEBUG - 2017-11-14 12:32:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 12:32:57 --> Input Class Initialized
INFO - 2017-11-14 12:32:57 --> Language Class Initialized
INFO - 2017-11-14 12:32:57 --> Language Class Initialized
INFO - 2017-11-14 12:32:57 --> Config Class Initialized
INFO - 2017-11-14 12:32:57 --> Loader Class Initialized
DEBUG - 2017-11-14 12:32:57 --> Config file loaded: D:\xampp\htdocs\construction_bay\application\config/construct-data.php
INFO - 2017-11-14 12:32:57 --> Helper loaded: url_helper
INFO - 2017-11-14 12:32:57 --> Helper loaded: form_helper
INFO - 2017-11-14 12:32:57 --> Helper loaded: date_helper
INFO - 2017-11-14 12:32:57 --> Helper loaded: util_helper
INFO - 2017-11-14 12:32:57 --> Helper loaded: text_helper
INFO - 2017-11-14 12:32:57 --> Helper loaded: string_helper
INFO - 2017-11-14 12:32:57 --> Database Driver Class Initialized
DEBUG - 2017-11-14 12:32:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-14 12:32:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-14 12:32:57 --> Email Class Initialized
INFO - 2017-11-14 12:32:57 --> Controller Class Initialized
INFO - 2017-11-14 12:32:57 --> Model Class Initialized
DEBUG - 2017-11-14 12:32:57 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_model.php
INFO - 2017-11-14 12:32:57 --> Model Class Initialized
DEBUG - 2017-11-14 12:32:57 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_functions_model.php
INFO - 2017-11-14 12:32:57 --> Model Class Initialized
ERROR - 2017-11-14 12:32:57 --> Severity: Notice --> Undefined variable: category D:\xampp\htdocs\construction_bay\application\views\common\header.php 309
DEBUG - 2017-11-14 12:32:57 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header.php
DEBUG - 2017-11-14 12:32:57 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\products-services.php
DEBUG - 2017-11-14 12:32:57 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/footer.php
INFO - 2017-11-14 12:32:57 --> Final output sent to browser
DEBUG - 2017-11-14 12:32:57 --> Total execution time: 0.0500
INFO - 2017-11-14 12:33:02 --> Config Class Initialized
INFO - 2017-11-14 12:33:02 --> Hooks Class Initialized
DEBUG - 2017-11-14 12:33:02 --> UTF-8 Support Enabled
INFO - 2017-11-14 12:33:02 --> Utf8 Class Initialized
INFO - 2017-11-14 12:33:02 --> URI Class Initialized
DEBUG - 2017-11-14 12:33:02 --> No URI present. Default controller set.
INFO - 2017-11-14 12:33:02 --> Router Class Initialized
INFO - 2017-11-14 12:33:02 --> Output Class Initialized
INFO - 2017-11-14 12:33:02 --> Security Class Initialized
DEBUG - 2017-11-14 12:33:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 12:33:02 --> Input Class Initialized
INFO - 2017-11-14 12:33:02 --> Language Class Initialized
INFO - 2017-11-14 12:33:02 --> Language Class Initialized
INFO - 2017-11-14 12:33:02 --> Config Class Initialized
INFO - 2017-11-14 12:33:02 --> Loader Class Initialized
DEBUG - 2017-11-14 12:33:02 --> Config file loaded: D:\xampp\htdocs\construction_bay\application\config/construct-data.php
INFO - 2017-11-14 12:33:02 --> Helper loaded: url_helper
INFO - 2017-11-14 12:33:02 --> Helper loaded: form_helper
INFO - 2017-11-14 12:33:02 --> Helper loaded: date_helper
INFO - 2017-11-14 12:33:02 --> Helper loaded: util_helper
INFO - 2017-11-14 12:33:02 --> Helper loaded: text_helper
INFO - 2017-11-14 12:33:02 --> Helper loaded: string_helper
INFO - 2017-11-14 12:33:02 --> Database Driver Class Initialized
DEBUG - 2017-11-14 12:33:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-14 12:33:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-14 12:33:02 --> Email Class Initialized
INFO - 2017-11-14 12:33:02 --> Controller Class Initialized
DEBUG - 2017-11-14 12:33:02 --> Home MX_Controller Initialized
INFO - 2017-11-14 12:33:02 --> Model Class Initialized
DEBUG - 2017-11-14 12:33:02 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_model.php
INFO - 2017-11-14 12:33:02 --> Model Class Initialized
DEBUG - 2017-11-14 12:33:02 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header.php
DEBUG - 2017-11-14 12:33:02 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/slider.php
DEBUG - 2017-11-14 12:33:02 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/index_body.php
DEBUG - 2017-11-14 12:33:02 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/index_footer.php
INFO - 2017-11-14 12:33:02 --> Final output sent to browser
DEBUG - 2017-11-14 12:33:02 --> Total execution time: 0.0540
INFO - 2017-11-14 12:33:06 --> Config Class Initialized
INFO - 2017-11-14 12:33:06 --> Hooks Class Initialized
DEBUG - 2017-11-14 12:33:06 --> UTF-8 Support Enabled
INFO - 2017-11-14 12:33:06 --> Utf8 Class Initialized
INFO - 2017-11-14 12:33:06 --> URI Class Initialized
INFO - 2017-11-14 12:33:06 --> Router Class Initialized
INFO - 2017-11-14 12:33:06 --> Output Class Initialized
INFO - 2017-11-14 12:33:06 --> Security Class Initialized
DEBUG - 2017-11-14 12:33:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 12:33:06 --> Input Class Initialized
INFO - 2017-11-14 12:33:06 --> Language Class Initialized
INFO - 2017-11-14 12:33:06 --> Language Class Initialized
INFO - 2017-11-14 12:33:06 --> Config Class Initialized
INFO - 2017-11-14 12:33:06 --> Loader Class Initialized
DEBUG - 2017-11-14 12:33:06 --> Config file loaded: D:\xampp\htdocs\construction_bay\application\config/construct-data.php
INFO - 2017-11-14 12:33:06 --> Helper loaded: url_helper
INFO - 2017-11-14 12:33:06 --> Helper loaded: form_helper
INFO - 2017-11-14 12:33:06 --> Helper loaded: date_helper
INFO - 2017-11-14 12:33:06 --> Helper loaded: util_helper
INFO - 2017-11-14 12:33:06 --> Helper loaded: text_helper
INFO - 2017-11-14 12:33:06 --> Helper loaded: string_helper
INFO - 2017-11-14 12:33:06 --> Database Driver Class Initialized
DEBUG - 2017-11-14 12:33:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-14 12:33:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-14 12:33:06 --> Email Class Initialized
INFO - 2017-11-14 12:33:06 --> Controller Class Initialized
INFO - 2017-11-14 12:33:06 --> Model Class Initialized
DEBUG - 2017-11-14 12:33:06 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_model.php
INFO - 2017-11-14 12:33:06 --> Model Class Initialized
DEBUG - 2017-11-14 12:33:06 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_functions_model.php
INFO - 2017-11-14 12:33:06 --> Model Class Initialized
ERROR - 2017-11-14 12:33:06 --> Severity: Notice --> Undefined variable: category D:\xampp\htdocs\construction_bay\application\views\common\header.php 309
DEBUG - 2017-11-14 12:33:06 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header.php
DEBUG - 2017-11-14 12:33:06 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\projects/projects.php
DEBUG - 2017-11-14 12:33:06 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/footer.php
INFO - 2017-11-14 12:33:06 --> Final output sent to browser
DEBUG - 2017-11-14 12:33:06 --> Total execution time: 0.0710
INFO - 2017-11-14 12:33:11 --> Config Class Initialized
INFO - 2017-11-14 12:33:11 --> Hooks Class Initialized
DEBUG - 2017-11-14 12:33:11 --> UTF-8 Support Enabled
INFO - 2017-11-14 12:33:11 --> Utf8 Class Initialized
INFO - 2017-11-14 12:33:11 --> URI Class Initialized
DEBUG - 2017-11-14 12:33:11 --> No URI present. Default controller set.
INFO - 2017-11-14 12:33:11 --> Router Class Initialized
INFO - 2017-11-14 12:33:11 --> Output Class Initialized
INFO - 2017-11-14 12:33:11 --> Security Class Initialized
DEBUG - 2017-11-14 12:33:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 12:33:11 --> Input Class Initialized
INFO - 2017-11-14 12:33:11 --> Language Class Initialized
INFO - 2017-11-14 12:33:11 --> Language Class Initialized
INFO - 2017-11-14 12:33:11 --> Config Class Initialized
INFO - 2017-11-14 12:33:11 --> Loader Class Initialized
DEBUG - 2017-11-14 12:33:11 --> Config file loaded: D:\xampp\htdocs\construction_bay\application\config/construct-data.php
INFO - 2017-11-14 12:33:11 --> Helper loaded: url_helper
INFO - 2017-11-14 12:33:11 --> Helper loaded: form_helper
INFO - 2017-11-14 12:33:11 --> Helper loaded: date_helper
INFO - 2017-11-14 12:33:11 --> Helper loaded: util_helper
INFO - 2017-11-14 12:33:11 --> Helper loaded: text_helper
INFO - 2017-11-14 12:33:11 --> Helper loaded: string_helper
INFO - 2017-11-14 12:33:11 --> Database Driver Class Initialized
DEBUG - 2017-11-14 12:33:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-14 12:33:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-14 12:33:11 --> Email Class Initialized
INFO - 2017-11-14 12:33:11 --> Controller Class Initialized
DEBUG - 2017-11-14 12:33:11 --> Home MX_Controller Initialized
INFO - 2017-11-14 12:33:11 --> Model Class Initialized
DEBUG - 2017-11-14 12:33:11 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_model.php
INFO - 2017-11-14 12:33:11 --> Model Class Initialized
DEBUG - 2017-11-14 12:33:11 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header.php
DEBUG - 2017-11-14 12:33:11 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/slider.php
DEBUG - 2017-11-14 12:33:11 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/index_body.php
DEBUG - 2017-11-14 12:33:11 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/index_footer.php
INFO - 2017-11-14 12:33:11 --> Final output sent to browser
DEBUG - 2017-11-14 12:33:11 --> Total execution time: 0.0520
INFO - 2017-11-14 12:33:15 --> Config Class Initialized
INFO - 2017-11-14 12:33:15 --> Hooks Class Initialized
DEBUG - 2017-11-14 12:33:15 --> UTF-8 Support Enabled
INFO - 2017-11-14 12:33:15 --> Utf8 Class Initialized
INFO - 2017-11-14 12:33:15 --> URI Class Initialized
INFO - 2017-11-14 12:33:15 --> Router Class Initialized
INFO - 2017-11-14 12:33:15 --> Output Class Initialized
INFO - 2017-11-14 12:33:15 --> Security Class Initialized
DEBUG - 2017-11-14 12:33:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 12:33:15 --> Input Class Initialized
INFO - 2017-11-14 12:33:15 --> Language Class Initialized
INFO - 2017-11-14 12:33:15 --> Language Class Initialized
INFO - 2017-11-14 12:33:15 --> Config Class Initialized
INFO - 2017-11-14 12:33:15 --> Loader Class Initialized
DEBUG - 2017-11-14 12:33:15 --> Config file loaded: D:\xampp\htdocs\construction_bay\application\config/construct-data.php
INFO - 2017-11-14 12:33:15 --> Helper loaded: url_helper
INFO - 2017-11-14 12:33:15 --> Helper loaded: form_helper
INFO - 2017-11-14 12:33:15 --> Helper loaded: date_helper
INFO - 2017-11-14 12:33:15 --> Helper loaded: util_helper
INFO - 2017-11-14 12:33:15 --> Helper loaded: text_helper
INFO - 2017-11-14 12:33:15 --> Helper loaded: string_helper
INFO - 2017-11-14 12:33:15 --> Database Driver Class Initialized
DEBUG - 2017-11-14 12:33:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-14 12:33:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-14 12:33:15 --> Email Class Initialized
INFO - 2017-11-14 12:33:15 --> Controller Class Initialized
INFO - 2017-11-14 12:33:15 --> Model Class Initialized
DEBUG - 2017-11-14 12:33:15 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_model.php
INFO - 2017-11-14 12:33:15 --> Model Class Initialized
DEBUG - 2017-11-14 12:33:15 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_functions_model.php
INFO - 2017-11-14 12:33:15 --> Model Class Initialized
ERROR - 2017-11-14 12:33:15 --> Severity: Notice --> Undefined variable: category D:\xampp\htdocs\construction_bay\application\views\common\header.php 309
DEBUG - 2017-11-14 12:33:15 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header.php
DEBUG - 2017-11-14 12:33:15 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\art-work.php
DEBUG - 2017-11-14 12:33:15 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/footer.php
INFO - 2017-11-14 12:33:15 --> Final output sent to browser
DEBUG - 2017-11-14 12:33:15 --> Total execution time: 0.0780
INFO - 2017-11-14 12:33:21 --> Config Class Initialized
INFO - 2017-11-14 12:33:21 --> Hooks Class Initialized
DEBUG - 2017-11-14 12:33:21 --> UTF-8 Support Enabled
INFO - 2017-11-14 12:33:21 --> Utf8 Class Initialized
INFO - 2017-11-14 12:33:21 --> URI Class Initialized
DEBUG - 2017-11-14 12:33:21 --> No URI present. Default controller set.
INFO - 2017-11-14 12:33:21 --> Router Class Initialized
INFO - 2017-11-14 12:33:21 --> Output Class Initialized
INFO - 2017-11-14 12:33:21 --> Security Class Initialized
DEBUG - 2017-11-14 12:33:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 12:33:21 --> Input Class Initialized
INFO - 2017-11-14 12:33:21 --> Language Class Initialized
INFO - 2017-11-14 12:33:21 --> Language Class Initialized
INFO - 2017-11-14 12:33:21 --> Config Class Initialized
INFO - 2017-11-14 12:33:21 --> Loader Class Initialized
DEBUG - 2017-11-14 12:33:21 --> Config file loaded: D:\xampp\htdocs\construction_bay\application\config/construct-data.php
INFO - 2017-11-14 12:33:21 --> Helper loaded: url_helper
INFO - 2017-11-14 12:33:21 --> Helper loaded: form_helper
INFO - 2017-11-14 12:33:21 --> Helper loaded: date_helper
INFO - 2017-11-14 12:33:21 --> Helper loaded: util_helper
INFO - 2017-11-14 12:33:21 --> Helper loaded: text_helper
INFO - 2017-11-14 12:33:21 --> Helper loaded: string_helper
INFO - 2017-11-14 12:33:21 --> Database Driver Class Initialized
DEBUG - 2017-11-14 12:33:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-14 12:33:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-14 12:33:21 --> Email Class Initialized
INFO - 2017-11-14 12:33:21 --> Controller Class Initialized
DEBUG - 2017-11-14 12:33:21 --> Home MX_Controller Initialized
INFO - 2017-11-14 12:33:21 --> Model Class Initialized
DEBUG - 2017-11-14 12:33:21 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_model.php
INFO - 2017-11-14 12:33:21 --> Model Class Initialized
DEBUG - 2017-11-14 12:33:21 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header.php
DEBUG - 2017-11-14 12:33:21 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/slider.php
DEBUG - 2017-11-14 12:33:21 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/index_body.php
DEBUG - 2017-11-14 12:33:21 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/index_footer.php
INFO - 2017-11-14 12:33:21 --> Final output sent to browser
DEBUG - 2017-11-14 12:33:21 --> Total execution time: 0.0510
INFO - 2017-11-14 12:33:26 --> Config Class Initialized
INFO - 2017-11-14 12:33:26 --> Hooks Class Initialized
DEBUG - 2017-11-14 12:33:26 --> UTF-8 Support Enabled
INFO - 2017-11-14 12:33:26 --> Utf8 Class Initialized
INFO - 2017-11-14 12:33:26 --> URI Class Initialized
INFO - 2017-11-14 12:33:26 --> Router Class Initialized
INFO - 2017-11-14 12:33:26 --> Output Class Initialized
INFO - 2017-11-14 12:33:26 --> Security Class Initialized
DEBUG - 2017-11-14 12:33:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 12:33:26 --> Input Class Initialized
INFO - 2017-11-14 12:33:26 --> Language Class Initialized
INFO - 2017-11-14 12:33:26 --> Language Class Initialized
INFO - 2017-11-14 12:33:26 --> Config Class Initialized
INFO - 2017-11-14 12:33:26 --> Loader Class Initialized
DEBUG - 2017-11-14 12:33:26 --> Config file loaded: D:\xampp\htdocs\construction_bay\application\config/construct-data.php
INFO - 2017-11-14 12:33:26 --> Helper loaded: url_helper
INFO - 2017-11-14 12:33:26 --> Helper loaded: form_helper
INFO - 2017-11-14 12:33:26 --> Helper loaded: date_helper
INFO - 2017-11-14 12:33:26 --> Helper loaded: util_helper
INFO - 2017-11-14 12:33:26 --> Helper loaded: text_helper
INFO - 2017-11-14 12:33:26 --> Helper loaded: string_helper
INFO - 2017-11-14 12:33:26 --> Database Driver Class Initialized
DEBUG - 2017-11-14 12:33:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-14 12:33:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-14 12:33:26 --> Email Class Initialized
INFO - 2017-11-14 12:33:26 --> Controller Class Initialized
INFO - 2017-11-14 12:33:26 --> Model Class Initialized
DEBUG - 2017-11-14 12:33:26 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_model.php
INFO - 2017-11-14 12:33:26 --> Model Class Initialized
DEBUG - 2017-11-14 12:33:26 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_functions_model.php
INFO - 2017-11-14 12:33:26 --> Model Class Initialized
ERROR - 2017-11-14 12:33:26 --> Severity: Notice --> Undefined variable: category D:\xampp\htdocs\construction_bay\application\views\common\header.php 309
DEBUG - 2017-11-14 12:33:26 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header.php
DEBUG - 2017-11-14 12:33:26 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\real-estate-page.php
DEBUG - 2017-11-14 12:33:26 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/footer.php
INFO - 2017-11-14 12:33:26 --> Final output sent to browser
DEBUG - 2017-11-14 12:33:26 --> Total execution time: 0.0660
INFO - 2017-11-14 12:33:31 --> Config Class Initialized
INFO - 2017-11-14 12:33:31 --> Hooks Class Initialized
DEBUG - 2017-11-14 12:33:31 --> UTF-8 Support Enabled
INFO - 2017-11-14 12:33:31 --> Utf8 Class Initialized
INFO - 2017-11-14 12:33:31 --> URI Class Initialized
DEBUG - 2017-11-14 12:33:31 --> No URI present. Default controller set.
INFO - 2017-11-14 12:33:31 --> Router Class Initialized
INFO - 2017-11-14 12:33:31 --> Output Class Initialized
INFO - 2017-11-14 12:33:31 --> Security Class Initialized
DEBUG - 2017-11-14 12:33:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 12:33:31 --> Input Class Initialized
INFO - 2017-11-14 12:33:31 --> Language Class Initialized
INFO - 2017-11-14 12:33:31 --> Language Class Initialized
INFO - 2017-11-14 12:33:31 --> Config Class Initialized
INFO - 2017-11-14 12:33:31 --> Loader Class Initialized
DEBUG - 2017-11-14 12:33:31 --> Config file loaded: D:\xampp\htdocs\construction_bay\application\config/construct-data.php
INFO - 2017-11-14 12:33:31 --> Helper loaded: url_helper
INFO - 2017-11-14 12:33:31 --> Helper loaded: form_helper
INFO - 2017-11-14 12:33:31 --> Helper loaded: date_helper
INFO - 2017-11-14 12:33:31 --> Helper loaded: util_helper
INFO - 2017-11-14 12:33:31 --> Helper loaded: text_helper
INFO - 2017-11-14 12:33:31 --> Helper loaded: string_helper
INFO - 2017-11-14 12:33:31 --> Database Driver Class Initialized
DEBUG - 2017-11-14 12:33:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-14 12:33:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-14 12:33:31 --> Email Class Initialized
INFO - 2017-11-14 12:33:31 --> Controller Class Initialized
DEBUG - 2017-11-14 12:33:31 --> Home MX_Controller Initialized
INFO - 2017-11-14 12:33:31 --> Model Class Initialized
DEBUG - 2017-11-14 12:33:31 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_model.php
INFO - 2017-11-14 12:33:31 --> Model Class Initialized
DEBUG - 2017-11-14 12:33:31 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header.php
DEBUG - 2017-11-14 12:33:31 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/slider.php
DEBUG - 2017-11-14 12:33:31 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/index_body.php
DEBUG - 2017-11-14 12:33:31 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/index_footer.php
INFO - 2017-11-14 12:33:31 --> Final output sent to browser
DEBUG - 2017-11-14 12:33:31 --> Total execution time: 0.0520
INFO - 2017-11-14 12:33:34 --> Config Class Initialized
INFO - 2017-11-14 12:33:34 --> Hooks Class Initialized
DEBUG - 2017-11-14 12:33:34 --> UTF-8 Support Enabled
INFO - 2017-11-14 12:33:34 --> Utf8 Class Initialized
INFO - 2017-11-14 12:33:34 --> URI Class Initialized
INFO - 2017-11-14 12:33:34 --> Router Class Initialized
INFO - 2017-11-14 12:33:34 --> Output Class Initialized
INFO - 2017-11-14 12:33:34 --> Security Class Initialized
DEBUG - 2017-11-14 12:33:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 12:33:34 --> Input Class Initialized
INFO - 2017-11-14 12:33:34 --> Language Class Initialized
INFO - 2017-11-14 12:33:34 --> Language Class Initialized
INFO - 2017-11-14 12:33:34 --> Config Class Initialized
INFO - 2017-11-14 12:33:34 --> Loader Class Initialized
DEBUG - 2017-11-14 12:33:34 --> Config file loaded: D:\xampp\htdocs\construction_bay\application\config/construct-data.php
INFO - 2017-11-14 12:33:34 --> Helper loaded: url_helper
INFO - 2017-11-14 12:33:34 --> Helper loaded: form_helper
INFO - 2017-11-14 12:33:34 --> Helper loaded: date_helper
INFO - 2017-11-14 12:33:34 --> Helper loaded: util_helper
INFO - 2017-11-14 12:33:34 --> Helper loaded: text_helper
INFO - 2017-11-14 12:33:34 --> Helper loaded: string_helper
INFO - 2017-11-14 12:33:34 --> Database Driver Class Initialized
DEBUG - 2017-11-14 12:33:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-14 12:33:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-14 12:33:34 --> Email Class Initialized
INFO - 2017-11-14 12:33:34 --> Controller Class Initialized
INFO - 2017-11-14 12:33:34 --> Model Class Initialized
DEBUG - 2017-11-14 12:33:34 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_model.php
INFO - 2017-11-14 12:33:34 --> Model Class Initialized
DEBUG - 2017-11-14 12:33:34 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_functions_model.php
INFO - 2017-11-14 12:33:34 --> Model Class Initialized
ERROR - 2017-11-14 12:33:34 --> Severity: Notice --> Undefined variable: category D:\xampp\htdocs\construction_bay\application\views\common\header.php 309
DEBUG - 2017-11-14 12:33:34 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header.php
DEBUG - 2017-11-14 12:33:34 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\interior-design.php
DEBUG - 2017-11-14 12:33:34 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/footer.php
INFO - 2017-11-14 12:33:34 --> Final output sent to browser
DEBUG - 2017-11-14 12:33:34 --> Total execution time: 0.0760
INFO - 2017-11-14 12:34:12 --> Config Class Initialized
INFO - 2017-11-14 12:34:12 --> Hooks Class Initialized
DEBUG - 2017-11-14 12:34:12 --> UTF-8 Support Enabled
INFO - 2017-11-14 12:34:12 --> Utf8 Class Initialized
INFO - 2017-11-14 12:34:12 --> URI Class Initialized
DEBUG - 2017-11-14 12:34:12 --> No URI present. Default controller set.
INFO - 2017-11-14 12:34:12 --> Router Class Initialized
INFO - 2017-11-14 12:34:12 --> Output Class Initialized
INFO - 2017-11-14 12:34:12 --> Security Class Initialized
DEBUG - 2017-11-14 12:34:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 12:34:12 --> Input Class Initialized
INFO - 2017-11-14 12:34:12 --> Language Class Initialized
INFO - 2017-11-14 12:34:12 --> Language Class Initialized
INFO - 2017-11-14 12:34:12 --> Config Class Initialized
INFO - 2017-11-14 12:34:12 --> Loader Class Initialized
DEBUG - 2017-11-14 12:34:12 --> Config file loaded: D:\xampp\htdocs\construction_bay\application\config/construct-data.php
INFO - 2017-11-14 12:34:12 --> Helper loaded: url_helper
INFO - 2017-11-14 12:34:12 --> Helper loaded: form_helper
INFO - 2017-11-14 12:34:12 --> Helper loaded: date_helper
INFO - 2017-11-14 12:34:12 --> Helper loaded: util_helper
INFO - 2017-11-14 12:34:12 --> Helper loaded: text_helper
INFO - 2017-11-14 12:34:12 --> Helper loaded: string_helper
INFO - 2017-11-14 12:34:12 --> Database Driver Class Initialized
DEBUG - 2017-11-14 12:34:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-14 12:34:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-14 12:34:12 --> Email Class Initialized
INFO - 2017-11-14 12:34:12 --> Controller Class Initialized
DEBUG - 2017-11-14 12:34:12 --> Home MX_Controller Initialized
INFO - 2017-11-14 12:34:12 --> Model Class Initialized
DEBUG - 2017-11-14 12:34:12 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_model.php
INFO - 2017-11-14 12:34:12 --> Model Class Initialized
DEBUG - 2017-11-14 12:34:12 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header.php
DEBUG - 2017-11-14 12:34:12 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/slider.php
DEBUG - 2017-11-14 12:34:12 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/index_body.php
DEBUG - 2017-11-14 12:34:12 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/index_footer.php
INFO - 2017-11-14 12:34:12 --> Final output sent to browser
DEBUG - 2017-11-14 12:34:12 --> Total execution time: 0.0600
INFO - 2017-11-14 12:38:27 --> Config Class Initialized
INFO - 2017-11-14 12:38:27 --> Hooks Class Initialized
DEBUG - 2017-11-14 12:38:27 --> UTF-8 Support Enabled
INFO - 2017-11-14 12:38:27 --> Utf8 Class Initialized
INFO - 2017-11-14 12:38:27 --> URI Class Initialized
INFO - 2017-11-14 12:38:27 --> Router Class Initialized
INFO - 2017-11-14 12:38:27 --> Output Class Initialized
INFO - 2017-11-14 12:38:27 --> Security Class Initialized
DEBUG - 2017-11-14 12:38:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 12:38:27 --> Input Class Initialized
INFO - 2017-11-14 12:38:27 --> Language Class Initialized
INFO - 2017-11-14 12:38:27 --> Language Class Initialized
INFO - 2017-11-14 12:38:27 --> Config Class Initialized
INFO - 2017-11-14 12:38:27 --> Loader Class Initialized
DEBUG - 2017-11-14 12:38:27 --> Config file loaded: D:\xampp\htdocs\construction_bay\application\config/construct-data.php
INFO - 2017-11-14 12:38:27 --> Helper loaded: url_helper
INFO - 2017-11-14 12:38:27 --> Helper loaded: form_helper
INFO - 2017-11-14 12:38:27 --> Helper loaded: date_helper
INFO - 2017-11-14 12:38:27 --> Helper loaded: util_helper
INFO - 2017-11-14 12:38:27 --> Helper loaded: text_helper
INFO - 2017-11-14 12:38:27 --> Helper loaded: string_helper
INFO - 2017-11-14 12:38:27 --> Database Driver Class Initialized
DEBUG - 2017-11-14 12:38:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-14 12:38:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-14 12:38:27 --> Email Class Initialized
INFO - 2017-11-14 12:38:27 --> Controller Class Initialized
INFO - 2017-11-14 12:38:27 --> Model Class Initialized
DEBUG - 2017-11-14 12:38:27 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_model.php
INFO - 2017-11-14 12:38:27 --> Model Class Initialized
DEBUG - 2017-11-14 12:38:27 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_functions_model.php
INFO - 2017-11-14 12:38:27 --> Model Class Initialized
ERROR - 2017-11-14 12:38:27 --> Severity: Notice --> Undefined variable: category D:\xampp\htdocs\construction_bay\application\views\common\header.php 309
DEBUG - 2017-11-14 12:38:27 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header.php
DEBUG - 2017-11-14 12:38:27 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\products-services.php
DEBUG - 2017-11-14 12:38:27 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/footer.php
INFO - 2017-11-14 12:38:27 --> Final output sent to browser
DEBUG - 2017-11-14 12:38:27 --> Total execution time: 0.0720
INFO - 2017-11-14 12:38:35 --> Config Class Initialized
INFO - 2017-11-14 12:38:35 --> Hooks Class Initialized
DEBUG - 2017-11-14 12:38:35 --> UTF-8 Support Enabled
INFO - 2017-11-14 12:38:35 --> Utf8 Class Initialized
INFO - 2017-11-14 12:38:35 --> URI Class Initialized
DEBUG - 2017-11-14 12:38:35 --> No URI present. Default controller set.
INFO - 2017-11-14 12:38:35 --> Router Class Initialized
INFO - 2017-11-14 12:38:35 --> Output Class Initialized
INFO - 2017-11-14 12:38:35 --> Security Class Initialized
DEBUG - 2017-11-14 12:38:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 12:38:35 --> Input Class Initialized
INFO - 2017-11-14 12:38:35 --> Language Class Initialized
INFO - 2017-11-14 12:38:35 --> Language Class Initialized
INFO - 2017-11-14 12:38:35 --> Config Class Initialized
INFO - 2017-11-14 12:38:35 --> Loader Class Initialized
DEBUG - 2017-11-14 12:38:35 --> Config file loaded: D:\xampp\htdocs\construction_bay\application\config/construct-data.php
INFO - 2017-11-14 12:38:35 --> Helper loaded: url_helper
INFO - 2017-11-14 12:38:35 --> Helper loaded: form_helper
INFO - 2017-11-14 12:38:35 --> Helper loaded: date_helper
INFO - 2017-11-14 12:38:35 --> Helper loaded: util_helper
INFO - 2017-11-14 12:38:35 --> Helper loaded: text_helper
INFO - 2017-11-14 12:38:35 --> Helper loaded: string_helper
INFO - 2017-11-14 12:38:35 --> Database Driver Class Initialized
DEBUG - 2017-11-14 12:38:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-14 12:38:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-14 12:38:35 --> Email Class Initialized
INFO - 2017-11-14 12:38:35 --> Controller Class Initialized
DEBUG - 2017-11-14 12:38:35 --> Home MX_Controller Initialized
INFO - 2017-11-14 12:38:35 --> Model Class Initialized
DEBUG - 2017-11-14 12:38:35 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_model.php
INFO - 2017-11-14 12:38:35 --> Model Class Initialized
DEBUG - 2017-11-14 12:38:35 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header.php
DEBUG - 2017-11-14 12:38:35 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/slider.php
DEBUG - 2017-11-14 12:38:35 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/index_body.php
DEBUG - 2017-11-14 12:38:35 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/index_footer.php
INFO - 2017-11-14 12:38:35 --> Final output sent to browser
DEBUG - 2017-11-14 12:38:35 --> Total execution time: 0.0590
INFO - 2017-11-14 12:38:41 --> Config Class Initialized
INFO - 2017-11-14 12:38:41 --> Hooks Class Initialized
DEBUG - 2017-11-14 12:38:41 --> UTF-8 Support Enabled
INFO - 2017-11-14 12:38:41 --> Utf8 Class Initialized
INFO - 2017-11-14 12:38:41 --> URI Class Initialized
INFO - 2017-11-14 12:38:41 --> Router Class Initialized
INFO - 2017-11-14 12:38:41 --> Output Class Initialized
INFO - 2017-11-14 12:38:41 --> Security Class Initialized
DEBUG - 2017-11-14 12:38:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 12:38:41 --> Input Class Initialized
INFO - 2017-11-14 12:38:41 --> Language Class Initialized
INFO - 2017-11-14 12:38:41 --> Language Class Initialized
INFO - 2017-11-14 12:38:41 --> Config Class Initialized
INFO - 2017-11-14 12:38:41 --> Loader Class Initialized
DEBUG - 2017-11-14 12:38:41 --> Config file loaded: D:\xampp\htdocs\construction_bay\application\config/construct-data.php
INFO - 2017-11-14 12:38:41 --> Helper loaded: url_helper
INFO - 2017-11-14 12:38:41 --> Helper loaded: form_helper
INFO - 2017-11-14 12:38:41 --> Helper loaded: date_helper
INFO - 2017-11-14 12:38:41 --> Helper loaded: util_helper
INFO - 2017-11-14 12:38:41 --> Helper loaded: text_helper
INFO - 2017-11-14 12:38:41 --> Helper loaded: string_helper
INFO - 2017-11-14 12:38:41 --> Database Driver Class Initialized
DEBUG - 2017-11-14 12:38:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-14 12:38:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-14 12:38:41 --> Email Class Initialized
INFO - 2017-11-14 12:38:41 --> Controller Class Initialized
INFO - 2017-11-14 12:38:41 --> Model Class Initialized
DEBUG - 2017-11-14 12:38:41 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_model.php
INFO - 2017-11-14 12:38:41 --> Model Class Initialized
DEBUG - 2017-11-14 12:38:41 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_functions_model.php
INFO - 2017-11-14 12:38:41 --> Model Class Initialized
ERROR - 2017-11-14 12:38:41 --> Severity: Notice --> Undefined variable: category D:\xampp\htdocs\construction_bay\application\views\common\header.php 309
DEBUG - 2017-11-14 12:38:41 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header.php
DEBUG - 2017-11-14 12:38:41 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\projects/projects.php
DEBUG - 2017-11-14 12:38:41 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/footer.php
INFO - 2017-11-14 12:38:41 --> Final output sent to browser
DEBUG - 2017-11-14 12:38:41 --> Total execution time: 0.0630
INFO - 2017-11-14 12:38:46 --> Config Class Initialized
INFO - 2017-11-14 12:38:46 --> Hooks Class Initialized
DEBUG - 2017-11-14 12:38:46 --> UTF-8 Support Enabled
INFO - 2017-11-14 12:38:46 --> Utf8 Class Initialized
INFO - 2017-11-14 12:38:46 --> URI Class Initialized
DEBUG - 2017-11-14 12:38:46 --> No URI present. Default controller set.
INFO - 2017-11-14 12:38:46 --> Router Class Initialized
INFO - 2017-11-14 12:38:46 --> Output Class Initialized
INFO - 2017-11-14 12:38:46 --> Security Class Initialized
DEBUG - 2017-11-14 12:38:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 12:38:46 --> Input Class Initialized
INFO - 2017-11-14 12:38:46 --> Language Class Initialized
INFO - 2017-11-14 12:38:46 --> Language Class Initialized
INFO - 2017-11-14 12:38:46 --> Config Class Initialized
INFO - 2017-11-14 12:38:46 --> Loader Class Initialized
DEBUG - 2017-11-14 12:38:46 --> Config file loaded: D:\xampp\htdocs\construction_bay\application\config/construct-data.php
INFO - 2017-11-14 12:38:46 --> Helper loaded: url_helper
INFO - 2017-11-14 12:38:46 --> Helper loaded: form_helper
INFO - 2017-11-14 12:38:46 --> Helper loaded: date_helper
INFO - 2017-11-14 12:38:46 --> Helper loaded: util_helper
INFO - 2017-11-14 12:38:46 --> Helper loaded: text_helper
INFO - 2017-11-14 12:38:46 --> Helper loaded: string_helper
INFO - 2017-11-14 12:38:46 --> Database Driver Class Initialized
DEBUG - 2017-11-14 12:38:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-14 12:38:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-14 12:38:46 --> Email Class Initialized
INFO - 2017-11-14 12:38:46 --> Controller Class Initialized
DEBUG - 2017-11-14 12:38:46 --> Home MX_Controller Initialized
INFO - 2017-11-14 12:38:46 --> Model Class Initialized
DEBUG - 2017-11-14 12:38:46 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_model.php
INFO - 2017-11-14 12:38:46 --> Model Class Initialized
DEBUG - 2017-11-14 12:38:46 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header.php
DEBUG - 2017-11-14 12:38:46 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/slider.php
DEBUG - 2017-11-14 12:38:46 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/index_body.php
DEBUG - 2017-11-14 12:38:46 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/index_footer.php
INFO - 2017-11-14 12:38:46 --> Final output sent to browser
DEBUG - 2017-11-14 12:38:46 --> Total execution time: 0.0710
INFO - 2017-11-14 12:38:50 --> Config Class Initialized
INFO - 2017-11-14 12:38:50 --> Hooks Class Initialized
DEBUG - 2017-11-14 12:38:50 --> UTF-8 Support Enabled
INFO - 2017-11-14 12:38:50 --> Utf8 Class Initialized
INFO - 2017-11-14 12:38:50 --> URI Class Initialized
INFO - 2017-11-14 12:38:50 --> Router Class Initialized
INFO - 2017-11-14 12:38:50 --> Output Class Initialized
INFO - 2017-11-14 12:38:50 --> Security Class Initialized
DEBUG - 2017-11-14 12:38:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 12:38:50 --> Input Class Initialized
INFO - 2017-11-14 12:38:50 --> Language Class Initialized
INFO - 2017-11-14 12:38:50 --> Language Class Initialized
INFO - 2017-11-14 12:38:50 --> Config Class Initialized
INFO - 2017-11-14 12:38:50 --> Loader Class Initialized
DEBUG - 2017-11-14 12:38:50 --> Config file loaded: D:\xampp\htdocs\construction_bay\application\config/construct-data.php
INFO - 2017-11-14 12:38:50 --> Helper loaded: url_helper
INFO - 2017-11-14 12:38:50 --> Helper loaded: form_helper
INFO - 2017-11-14 12:38:50 --> Helper loaded: date_helper
INFO - 2017-11-14 12:38:50 --> Helper loaded: util_helper
INFO - 2017-11-14 12:38:50 --> Helper loaded: text_helper
INFO - 2017-11-14 12:38:50 --> Helper loaded: string_helper
INFO - 2017-11-14 12:38:50 --> Database Driver Class Initialized
DEBUG - 2017-11-14 12:38:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-14 12:38:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-14 12:38:50 --> Email Class Initialized
INFO - 2017-11-14 12:38:50 --> Controller Class Initialized
INFO - 2017-11-14 12:38:50 --> Model Class Initialized
DEBUG - 2017-11-14 12:38:50 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_model.php
INFO - 2017-11-14 12:38:50 --> Model Class Initialized
DEBUG - 2017-11-14 12:38:50 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_functions_model.php
INFO - 2017-11-14 12:38:50 --> Model Class Initialized
ERROR - 2017-11-14 12:38:50 --> Severity: Notice --> Undefined variable: category D:\xampp\htdocs\construction_bay\application\views\common\header.php 309
DEBUG - 2017-11-14 12:38:50 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header.php
DEBUG - 2017-11-14 12:38:50 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\real-estate-page.php
DEBUG - 2017-11-14 12:38:50 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/footer.php
INFO - 2017-11-14 12:38:50 --> Final output sent to browser
DEBUG - 2017-11-14 12:38:50 --> Total execution time: 0.0770
INFO - 2017-11-14 12:38:55 --> Config Class Initialized
INFO - 2017-11-14 12:38:55 --> Hooks Class Initialized
DEBUG - 2017-11-14 12:38:55 --> UTF-8 Support Enabled
INFO - 2017-11-14 12:38:55 --> Utf8 Class Initialized
INFO - 2017-11-14 12:38:55 --> URI Class Initialized
DEBUG - 2017-11-14 12:38:55 --> No URI present. Default controller set.
INFO - 2017-11-14 12:38:55 --> Router Class Initialized
INFO - 2017-11-14 12:38:55 --> Output Class Initialized
INFO - 2017-11-14 12:38:55 --> Security Class Initialized
DEBUG - 2017-11-14 12:38:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 12:38:55 --> Input Class Initialized
INFO - 2017-11-14 12:38:55 --> Language Class Initialized
INFO - 2017-11-14 12:38:55 --> Language Class Initialized
INFO - 2017-11-14 12:38:55 --> Config Class Initialized
INFO - 2017-11-14 12:38:55 --> Loader Class Initialized
DEBUG - 2017-11-14 12:38:55 --> Config file loaded: D:\xampp\htdocs\construction_bay\application\config/construct-data.php
INFO - 2017-11-14 12:38:55 --> Helper loaded: url_helper
INFO - 2017-11-14 12:38:55 --> Helper loaded: form_helper
INFO - 2017-11-14 12:38:55 --> Helper loaded: date_helper
INFO - 2017-11-14 12:38:55 --> Helper loaded: util_helper
INFO - 2017-11-14 12:38:55 --> Helper loaded: text_helper
INFO - 2017-11-14 12:38:55 --> Helper loaded: string_helper
INFO - 2017-11-14 12:38:55 --> Database Driver Class Initialized
DEBUG - 2017-11-14 12:38:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-14 12:38:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-14 12:38:55 --> Email Class Initialized
INFO - 2017-11-14 12:38:55 --> Controller Class Initialized
DEBUG - 2017-11-14 12:38:55 --> Home MX_Controller Initialized
INFO - 2017-11-14 12:38:55 --> Model Class Initialized
DEBUG - 2017-11-14 12:38:55 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_model.php
INFO - 2017-11-14 12:38:55 --> Model Class Initialized
DEBUG - 2017-11-14 12:38:55 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header.php
DEBUG - 2017-11-14 12:38:55 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/slider.php
DEBUG - 2017-11-14 12:38:55 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/index_body.php
DEBUG - 2017-11-14 12:38:55 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/index_footer.php
INFO - 2017-11-14 12:38:55 --> Final output sent to browser
DEBUG - 2017-11-14 12:38:55 --> Total execution time: 0.0560
INFO - 2017-11-14 12:38:57 --> Config Class Initialized
INFO - 2017-11-14 12:38:57 --> Hooks Class Initialized
DEBUG - 2017-11-14 12:38:57 --> UTF-8 Support Enabled
INFO - 2017-11-14 12:38:57 --> Utf8 Class Initialized
INFO - 2017-11-14 12:38:57 --> URI Class Initialized
INFO - 2017-11-14 12:38:57 --> Router Class Initialized
INFO - 2017-11-14 12:38:57 --> Output Class Initialized
INFO - 2017-11-14 12:38:57 --> Security Class Initialized
DEBUG - 2017-11-14 12:38:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 12:38:57 --> Input Class Initialized
INFO - 2017-11-14 12:38:57 --> Language Class Initialized
INFO - 2017-11-14 12:38:57 --> Language Class Initialized
INFO - 2017-11-14 12:38:57 --> Config Class Initialized
INFO - 2017-11-14 12:38:57 --> Loader Class Initialized
DEBUG - 2017-11-14 12:38:57 --> Config file loaded: D:\xampp\htdocs\construction_bay\application\config/construct-data.php
INFO - 2017-11-14 12:38:57 --> Helper loaded: url_helper
INFO - 2017-11-14 12:38:57 --> Helper loaded: form_helper
INFO - 2017-11-14 12:38:57 --> Helper loaded: date_helper
INFO - 2017-11-14 12:38:57 --> Helper loaded: util_helper
INFO - 2017-11-14 12:38:57 --> Helper loaded: text_helper
INFO - 2017-11-14 12:38:57 --> Helper loaded: string_helper
INFO - 2017-11-14 12:38:57 --> Database Driver Class Initialized
DEBUG - 2017-11-14 12:38:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-14 12:38:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-14 12:38:57 --> Email Class Initialized
INFO - 2017-11-14 12:38:57 --> Controller Class Initialized
INFO - 2017-11-14 12:38:57 --> Model Class Initialized
DEBUG - 2017-11-14 12:38:57 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_model.php
INFO - 2017-11-14 12:38:57 --> Model Class Initialized
DEBUG - 2017-11-14 12:38:57 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_functions_model.php
INFO - 2017-11-14 12:38:57 --> Model Class Initialized
ERROR - 2017-11-14 12:38:57 --> Severity: Notice --> Undefined variable: category D:\xampp\htdocs\construction_bay\application\views\common\header.php 309
DEBUG - 2017-11-14 12:38:57 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header.php
DEBUG - 2017-11-14 12:38:57 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\art-work.php
DEBUG - 2017-11-14 12:38:57 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/footer.php
INFO - 2017-11-14 12:38:57 --> Final output sent to browser
DEBUG - 2017-11-14 12:38:57 --> Total execution time: 0.0600
INFO - 2017-11-14 12:38:58 --> Config Class Initialized
INFO - 2017-11-14 12:38:58 --> Hooks Class Initialized
DEBUG - 2017-11-14 12:38:58 --> UTF-8 Support Enabled
INFO - 2017-11-14 12:38:58 --> Utf8 Class Initialized
INFO - 2017-11-14 12:38:58 --> URI Class Initialized
DEBUG - 2017-11-14 12:38:58 --> No URI present. Default controller set.
INFO - 2017-11-14 12:38:58 --> Router Class Initialized
INFO - 2017-11-14 12:38:58 --> Output Class Initialized
INFO - 2017-11-14 12:38:58 --> Security Class Initialized
DEBUG - 2017-11-14 12:38:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 12:38:58 --> Input Class Initialized
INFO - 2017-11-14 12:38:58 --> Language Class Initialized
INFO - 2017-11-14 12:38:58 --> Language Class Initialized
INFO - 2017-11-14 12:38:58 --> Config Class Initialized
INFO - 2017-11-14 12:38:58 --> Loader Class Initialized
DEBUG - 2017-11-14 12:38:58 --> Config file loaded: D:\xampp\htdocs\construction_bay\application\config/construct-data.php
INFO - 2017-11-14 12:38:58 --> Helper loaded: url_helper
INFO - 2017-11-14 12:38:58 --> Helper loaded: form_helper
INFO - 2017-11-14 12:38:58 --> Helper loaded: date_helper
INFO - 2017-11-14 12:38:58 --> Helper loaded: util_helper
INFO - 2017-11-14 12:38:58 --> Helper loaded: text_helper
INFO - 2017-11-14 12:38:58 --> Helper loaded: string_helper
INFO - 2017-11-14 12:38:58 --> Database Driver Class Initialized
DEBUG - 2017-11-14 12:38:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-14 12:38:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-14 12:38:58 --> Email Class Initialized
INFO - 2017-11-14 12:38:58 --> Controller Class Initialized
DEBUG - 2017-11-14 12:38:58 --> Home MX_Controller Initialized
INFO - 2017-11-14 12:38:58 --> Model Class Initialized
DEBUG - 2017-11-14 12:38:58 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_model.php
INFO - 2017-11-14 12:38:58 --> Model Class Initialized
DEBUG - 2017-11-14 12:38:58 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header.php
DEBUG - 2017-11-14 12:38:58 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/slider.php
DEBUG - 2017-11-14 12:38:58 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/index_body.php
DEBUG - 2017-11-14 12:38:58 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/index_footer.php
INFO - 2017-11-14 12:38:58 --> Final output sent to browser
DEBUG - 2017-11-14 12:38:58 --> Total execution time: 0.0670
INFO - 2017-11-14 12:39:01 --> Config Class Initialized
INFO - 2017-11-14 12:39:01 --> Hooks Class Initialized
DEBUG - 2017-11-14 12:39:01 --> UTF-8 Support Enabled
INFO - 2017-11-14 12:39:01 --> Utf8 Class Initialized
INFO - 2017-11-14 12:39:01 --> URI Class Initialized
INFO - 2017-11-14 12:39:01 --> Router Class Initialized
INFO - 2017-11-14 12:39:01 --> Output Class Initialized
INFO - 2017-11-14 12:39:01 --> Security Class Initialized
DEBUG - 2017-11-14 12:39:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 12:39:01 --> Input Class Initialized
INFO - 2017-11-14 12:39:01 --> Language Class Initialized
INFO - 2017-11-14 12:39:01 --> Language Class Initialized
INFO - 2017-11-14 12:39:01 --> Config Class Initialized
INFO - 2017-11-14 12:39:01 --> Loader Class Initialized
DEBUG - 2017-11-14 12:39:01 --> Config file loaded: D:\xampp\htdocs\construction_bay\application\config/construct-data.php
INFO - 2017-11-14 12:39:01 --> Helper loaded: url_helper
INFO - 2017-11-14 12:39:01 --> Helper loaded: form_helper
INFO - 2017-11-14 12:39:01 --> Helper loaded: date_helper
INFO - 2017-11-14 12:39:01 --> Helper loaded: util_helper
INFO - 2017-11-14 12:39:01 --> Helper loaded: text_helper
INFO - 2017-11-14 12:39:01 --> Helper loaded: string_helper
INFO - 2017-11-14 12:39:01 --> Database Driver Class Initialized
DEBUG - 2017-11-14 12:39:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-14 12:39:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-14 12:39:01 --> Email Class Initialized
INFO - 2017-11-14 12:39:01 --> Controller Class Initialized
INFO - 2017-11-14 12:39:01 --> Model Class Initialized
DEBUG - 2017-11-14 12:39:01 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_model.php
INFO - 2017-11-14 12:39:01 --> Model Class Initialized
DEBUG - 2017-11-14 12:39:01 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_functions_model.php
INFO - 2017-11-14 12:39:01 --> Model Class Initialized
ERROR - 2017-11-14 12:39:01 --> Severity: Notice --> Undefined variable: category D:\xampp\htdocs\construction_bay\application\views\common\header.php 309
DEBUG - 2017-11-14 12:39:01 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header.php
DEBUG - 2017-11-14 12:39:01 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\interior-design.php
DEBUG - 2017-11-14 12:39:01 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/footer.php
INFO - 2017-11-14 12:39:01 --> Final output sent to browser
DEBUG - 2017-11-14 12:39:01 --> Total execution time: 0.0580
INFO - 2017-11-14 12:39:07 --> Config Class Initialized
INFO - 2017-11-14 12:39:07 --> Hooks Class Initialized
DEBUG - 2017-11-14 12:39:07 --> UTF-8 Support Enabled
INFO - 2017-11-14 12:39:07 --> Utf8 Class Initialized
INFO - 2017-11-14 12:39:07 --> URI Class Initialized
DEBUG - 2017-11-14 12:39:07 --> No URI present. Default controller set.
INFO - 2017-11-14 12:39:07 --> Router Class Initialized
INFO - 2017-11-14 12:39:07 --> Output Class Initialized
INFO - 2017-11-14 12:39:07 --> Security Class Initialized
DEBUG - 2017-11-14 12:39:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 12:39:07 --> Input Class Initialized
INFO - 2017-11-14 12:39:07 --> Language Class Initialized
INFO - 2017-11-14 12:39:07 --> Language Class Initialized
INFO - 2017-11-14 12:39:07 --> Config Class Initialized
INFO - 2017-11-14 12:39:07 --> Loader Class Initialized
DEBUG - 2017-11-14 12:39:07 --> Config file loaded: D:\xampp\htdocs\construction_bay\application\config/construct-data.php
INFO - 2017-11-14 12:39:07 --> Helper loaded: url_helper
INFO - 2017-11-14 12:39:07 --> Helper loaded: form_helper
INFO - 2017-11-14 12:39:07 --> Helper loaded: date_helper
INFO - 2017-11-14 12:39:07 --> Helper loaded: util_helper
INFO - 2017-11-14 12:39:07 --> Helper loaded: text_helper
INFO - 2017-11-14 12:39:07 --> Helper loaded: string_helper
INFO - 2017-11-14 12:39:07 --> Database Driver Class Initialized
DEBUG - 2017-11-14 12:39:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-14 12:39:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-14 12:39:07 --> Email Class Initialized
INFO - 2017-11-14 12:39:07 --> Controller Class Initialized
DEBUG - 2017-11-14 12:39:07 --> Home MX_Controller Initialized
INFO - 2017-11-14 12:39:07 --> Model Class Initialized
DEBUG - 2017-11-14 12:39:07 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_model.php
INFO - 2017-11-14 12:39:07 --> Model Class Initialized
DEBUG - 2017-11-14 12:39:07 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header.php
DEBUG - 2017-11-14 12:39:07 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/slider.php
DEBUG - 2017-11-14 12:39:07 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/index_body.php
DEBUG - 2017-11-14 12:39:07 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/index_footer.php
INFO - 2017-11-14 12:39:07 --> Final output sent to browser
DEBUG - 2017-11-14 12:39:07 --> Total execution time: 0.0500
INFO - 2017-11-14 12:39:16 --> Config Class Initialized
INFO - 2017-11-14 12:39:16 --> Hooks Class Initialized
DEBUG - 2017-11-14 12:39:16 --> UTF-8 Support Enabled
INFO - 2017-11-14 12:39:16 --> Utf8 Class Initialized
INFO - 2017-11-14 12:39:16 --> URI Class Initialized
INFO - 2017-11-14 12:39:16 --> Router Class Initialized
INFO - 2017-11-14 12:39:16 --> Output Class Initialized
INFO - 2017-11-14 12:39:16 --> Security Class Initialized
DEBUG - 2017-11-14 12:39:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 12:39:16 --> Input Class Initialized
INFO - 2017-11-14 12:39:16 --> Language Class Initialized
INFO - 2017-11-14 12:39:16 --> Language Class Initialized
INFO - 2017-11-14 12:39:16 --> Config Class Initialized
INFO - 2017-11-14 12:39:16 --> Loader Class Initialized
DEBUG - 2017-11-14 12:39:16 --> Config file loaded: D:\xampp\htdocs\construction_bay\application\config/construct-data.php
INFO - 2017-11-14 12:39:16 --> Helper loaded: url_helper
INFO - 2017-11-14 12:39:16 --> Helper loaded: form_helper
INFO - 2017-11-14 12:39:16 --> Helper loaded: date_helper
INFO - 2017-11-14 12:39:16 --> Helper loaded: util_helper
INFO - 2017-11-14 12:39:16 --> Helper loaded: text_helper
INFO - 2017-11-14 12:39:16 --> Helper loaded: string_helper
INFO - 2017-11-14 12:39:16 --> Database Driver Class Initialized
DEBUG - 2017-11-14 12:39:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-14 12:39:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-14 12:39:16 --> Email Class Initialized
INFO - 2017-11-14 12:39:16 --> Controller Class Initialized
INFO - 2017-11-14 12:39:16 --> Model Class Initialized
DEBUG - 2017-11-14 12:39:16 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_model.php
INFO - 2017-11-14 12:39:16 --> Model Class Initialized
DEBUG - 2017-11-14 12:39:16 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_functions_model.php
INFO - 2017-11-14 12:39:16 --> Model Class Initialized
ERROR - 2017-11-14 12:39:16 --> Severity: Notice --> Undefined variable: category D:\xampp\htdocs\construction_bay\application\views\common\header.php 309
DEBUG - 2017-11-14 12:39:16 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header.php
DEBUG - 2017-11-14 12:39:16 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\interior-design.php
DEBUG - 2017-11-14 12:39:16 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/footer.php
INFO - 2017-11-14 12:39:16 --> Final output sent to browser
DEBUG - 2017-11-14 12:39:16 --> Total execution time: 0.0640
INFO - 2017-11-14 12:39:25 --> Config Class Initialized
INFO - 2017-11-14 12:39:25 --> Hooks Class Initialized
DEBUG - 2017-11-14 12:39:25 --> UTF-8 Support Enabled
INFO - 2017-11-14 12:39:25 --> Utf8 Class Initialized
INFO - 2017-11-14 12:39:25 --> URI Class Initialized
DEBUG - 2017-11-14 12:39:25 --> No URI present. Default controller set.
INFO - 2017-11-14 12:39:25 --> Router Class Initialized
INFO - 2017-11-14 12:39:25 --> Output Class Initialized
INFO - 2017-11-14 12:39:25 --> Security Class Initialized
DEBUG - 2017-11-14 12:39:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 12:39:25 --> Input Class Initialized
INFO - 2017-11-14 12:39:25 --> Language Class Initialized
INFO - 2017-11-14 12:39:25 --> Language Class Initialized
INFO - 2017-11-14 12:39:25 --> Config Class Initialized
INFO - 2017-11-14 12:39:25 --> Loader Class Initialized
DEBUG - 2017-11-14 12:39:25 --> Config file loaded: D:\xampp\htdocs\construction_bay\application\config/construct-data.php
INFO - 2017-11-14 12:39:25 --> Helper loaded: url_helper
INFO - 2017-11-14 12:39:25 --> Helper loaded: form_helper
INFO - 2017-11-14 12:39:25 --> Helper loaded: date_helper
INFO - 2017-11-14 12:39:25 --> Helper loaded: util_helper
INFO - 2017-11-14 12:39:25 --> Helper loaded: text_helper
INFO - 2017-11-14 12:39:25 --> Helper loaded: string_helper
INFO - 2017-11-14 12:39:25 --> Database Driver Class Initialized
DEBUG - 2017-11-14 12:39:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-14 12:39:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-14 12:39:25 --> Email Class Initialized
INFO - 2017-11-14 12:39:25 --> Controller Class Initialized
DEBUG - 2017-11-14 12:39:25 --> Home MX_Controller Initialized
INFO - 2017-11-14 12:39:25 --> Model Class Initialized
DEBUG - 2017-11-14 12:39:25 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_model.php
INFO - 2017-11-14 12:39:25 --> Model Class Initialized
DEBUG - 2017-11-14 12:39:25 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header.php
DEBUG - 2017-11-14 12:39:25 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/slider.php
DEBUG - 2017-11-14 12:39:25 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/index_body.php
DEBUG - 2017-11-14 12:39:25 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/index_footer.php
INFO - 2017-11-14 12:39:25 --> Final output sent to browser
DEBUG - 2017-11-14 12:39:25 --> Total execution time: 0.0540
INFO - 2017-11-14 12:39:33 --> Config Class Initialized
INFO - 2017-11-14 12:39:33 --> Hooks Class Initialized
DEBUG - 2017-11-14 12:39:33 --> UTF-8 Support Enabled
INFO - 2017-11-14 12:39:33 --> Utf8 Class Initialized
INFO - 2017-11-14 12:39:33 --> URI Class Initialized
INFO - 2017-11-14 12:39:33 --> Router Class Initialized
INFO - 2017-11-14 12:39:33 --> Output Class Initialized
INFO - 2017-11-14 12:39:33 --> Security Class Initialized
DEBUG - 2017-11-14 12:39:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 12:39:33 --> Input Class Initialized
INFO - 2017-11-14 12:39:33 --> Language Class Initialized
INFO - 2017-11-14 12:39:33 --> Language Class Initialized
INFO - 2017-11-14 12:39:33 --> Config Class Initialized
INFO - 2017-11-14 12:39:33 --> Loader Class Initialized
DEBUG - 2017-11-14 12:39:33 --> Config file loaded: D:\xampp\htdocs\construction_bay\application\config/construct-data.php
INFO - 2017-11-14 12:39:33 --> Helper loaded: url_helper
INFO - 2017-11-14 12:39:33 --> Helper loaded: form_helper
INFO - 2017-11-14 12:39:33 --> Helper loaded: date_helper
INFO - 2017-11-14 12:39:33 --> Helper loaded: util_helper
INFO - 2017-11-14 12:39:33 --> Helper loaded: text_helper
INFO - 2017-11-14 12:39:33 --> Helper loaded: string_helper
INFO - 2017-11-14 12:39:33 --> Database Driver Class Initialized
DEBUG - 2017-11-14 12:39:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-14 12:39:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-14 12:39:33 --> Email Class Initialized
INFO - 2017-11-14 12:39:33 --> Controller Class Initialized
INFO - 2017-11-14 12:39:33 --> Model Class Initialized
DEBUG - 2017-11-14 12:39:33 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_model.php
INFO - 2017-11-14 12:39:33 --> Model Class Initialized
DEBUG - 2017-11-14 12:39:33 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_functions_model.php
INFO - 2017-11-14 12:39:33 --> Model Class Initialized
ERROR - 2017-11-14 12:39:33 --> Severity: Notice --> Undefined variable: category D:\xampp\htdocs\construction_bay\application\views\common\header.php 309
DEBUG - 2017-11-14 12:39:33 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header.php
DEBUG - 2017-11-14 12:39:33 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\products-services.php
DEBUG - 2017-11-14 12:39:33 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/footer.php
INFO - 2017-11-14 12:39:33 --> Final output sent to browser
DEBUG - 2017-11-14 12:39:33 --> Total execution time: 0.0650
INFO - 2017-11-14 12:39:38 --> Config Class Initialized
INFO - 2017-11-14 12:39:38 --> Hooks Class Initialized
DEBUG - 2017-11-14 12:39:38 --> UTF-8 Support Enabled
INFO - 2017-11-14 12:39:38 --> Utf8 Class Initialized
INFO - 2017-11-14 12:39:38 --> URI Class Initialized
INFO - 2017-11-14 12:39:38 --> Router Class Initialized
INFO - 2017-11-14 12:39:38 --> Output Class Initialized
INFO - 2017-11-14 12:39:38 --> Security Class Initialized
DEBUG - 2017-11-14 12:39:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 12:39:38 --> Input Class Initialized
INFO - 2017-11-14 12:39:38 --> Language Class Initialized
INFO - 2017-11-14 12:39:38 --> Language Class Initialized
INFO - 2017-11-14 12:39:38 --> Config Class Initialized
INFO - 2017-11-14 12:39:38 --> Loader Class Initialized
DEBUG - 2017-11-14 12:39:38 --> Config file loaded: D:\xampp\htdocs\construction_bay\application\config/construct-data.php
INFO - 2017-11-14 12:39:38 --> Helper loaded: url_helper
INFO - 2017-11-14 12:39:38 --> Helper loaded: form_helper
INFO - 2017-11-14 12:39:38 --> Helper loaded: date_helper
INFO - 2017-11-14 12:39:38 --> Helper loaded: util_helper
INFO - 2017-11-14 12:39:38 --> Helper loaded: text_helper
INFO - 2017-11-14 12:39:38 --> Helper loaded: string_helper
INFO - 2017-11-14 12:39:38 --> Database Driver Class Initialized
DEBUG - 2017-11-14 12:39:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-14 12:39:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-14 12:39:38 --> Email Class Initialized
INFO - 2017-11-14 12:39:38 --> Controller Class Initialized
INFO - 2017-11-14 12:39:38 --> Model Class Initialized
DEBUG - 2017-11-14 12:39:38 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_model.php
INFO - 2017-11-14 12:39:38 --> Model Class Initialized
DEBUG - 2017-11-14 12:39:38 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_functions_model.php
INFO - 2017-11-14 12:39:38 --> Model Class Initialized
DEBUG - 2017-11-14 12:39:38 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\companies/companies_header.php
DEBUG - 2017-11-14 12:39:38 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\companies/companies_page.php
DEBUG - 2017-11-14 12:39:38 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\companies/companies_footer.php
INFO - 2017-11-14 12:39:38 --> Final output sent to browser
DEBUG - 2017-11-14 12:39:38 --> Total execution time: 0.0750
INFO - 2017-11-14 12:39:39 --> Config Class Initialized
INFO - 2017-11-14 12:39:39 --> Hooks Class Initialized
DEBUG - 2017-11-14 12:39:39 --> UTF-8 Support Enabled
INFO - 2017-11-14 12:39:39 --> Utf8 Class Initialized
INFO - 2017-11-14 12:39:39 --> URI Class Initialized
INFO - 2017-11-14 12:39:39 --> Router Class Initialized
INFO - 2017-11-14 12:39:39 --> Output Class Initialized
INFO - 2017-11-14 12:39:39 --> Security Class Initialized
DEBUG - 2017-11-14 12:39:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 12:39:39 --> Input Class Initialized
INFO - 2017-11-14 12:39:39 --> Language Class Initialized
INFO - 2017-11-14 12:39:39 --> Language Class Initialized
INFO - 2017-11-14 12:39:39 --> Config Class Initialized
INFO - 2017-11-14 12:39:39 --> Loader Class Initialized
DEBUG - 2017-11-14 12:39:39 --> Config file loaded: D:\xampp\htdocs\construction_bay\application\config/construct-data.php
INFO - 2017-11-14 12:39:39 --> Helper loaded: url_helper
INFO - 2017-11-14 12:39:39 --> Helper loaded: form_helper
INFO - 2017-11-14 12:39:39 --> Helper loaded: date_helper
INFO - 2017-11-14 12:39:39 --> Helper loaded: util_helper
INFO - 2017-11-14 12:39:39 --> Helper loaded: text_helper
INFO - 2017-11-14 12:39:39 --> Helper loaded: string_helper
INFO - 2017-11-14 12:39:39 --> Database Driver Class Initialized
DEBUG - 2017-11-14 12:39:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-14 12:39:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-14 12:39:39 --> Email Class Initialized
INFO - 2017-11-14 12:39:39 --> Controller Class Initialized
INFO - 2017-11-14 12:39:39 --> Model Class Initialized
DEBUG - 2017-11-14 12:39:39 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_model.php
INFO - 2017-11-14 12:39:39 --> Model Class Initialized
DEBUG - 2017-11-14 12:39:39 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_functions_model.php
INFO - 2017-11-14 12:39:39 --> Model Class Initialized
DEBUG - 2017-11-14 12:39:39 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/template.php
INFO - 2017-11-14 12:39:46 --> Config Class Initialized
INFO - 2017-11-14 12:39:46 --> Hooks Class Initialized
DEBUG - 2017-11-14 12:39:46 --> UTF-8 Support Enabled
INFO - 2017-11-14 12:39:46 --> Utf8 Class Initialized
INFO - 2017-11-14 12:39:46 --> URI Class Initialized
INFO - 2017-11-14 12:39:46 --> Router Class Initialized
INFO - 2017-11-14 12:39:46 --> Output Class Initialized
INFO - 2017-11-14 12:39:46 --> Security Class Initialized
DEBUG - 2017-11-14 12:39:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 12:39:46 --> Input Class Initialized
INFO - 2017-11-14 12:39:46 --> Language Class Initialized
INFO - 2017-11-14 12:39:46 --> Language Class Initialized
INFO - 2017-11-14 12:39:46 --> Config Class Initialized
INFO - 2017-11-14 12:39:46 --> Loader Class Initialized
DEBUG - 2017-11-14 12:39:46 --> Config file loaded: D:\xampp\htdocs\construction_bay\application\config/construct-data.php
INFO - 2017-11-14 12:39:46 --> Helper loaded: url_helper
INFO - 2017-11-14 12:39:46 --> Helper loaded: form_helper
INFO - 2017-11-14 12:39:46 --> Helper loaded: date_helper
INFO - 2017-11-14 12:39:46 --> Helper loaded: util_helper
INFO - 2017-11-14 12:39:46 --> Helper loaded: text_helper
INFO - 2017-11-14 12:39:46 --> Helper loaded: string_helper
INFO - 2017-11-14 12:39:46 --> Database Driver Class Initialized
DEBUG - 2017-11-14 12:39:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-14 12:39:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-14 12:39:46 --> Email Class Initialized
INFO - 2017-11-14 12:39:46 --> Controller Class Initialized
INFO - 2017-11-14 12:39:46 --> Model Class Initialized
DEBUG - 2017-11-14 12:39:46 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_model.php
INFO - 2017-11-14 12:39:46 --> Model Class Initialized
DEBUG - 2017-11-14 12:39:46 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_functions_model.php
INFO - 2017-11-14 12:39:46 --> Model Class Initialized
DEBUG - 2017-11-14 12:39:46 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\companies/companies_header.php
DEBUG - 2017-11-14 12:39:46 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\companies/companies_page.php
DEBUG - 2017-11-14 12:39:46 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\companies/companies_footer.php
INFO - 2017-11-14 12:39:46 --> Final output sent to browser
DEBUG - 2017-11-14 12:39:46 --> Total execution time: 0.0800
INFO - 2017-11-14 12:39:47 --> Config Class Initialized
INFO - 2017-11-14 12:39:47 --> Hooks Class Initialized
DEBUG - 2017-11-14 12:39:47 --> UTF-8 Support Enabled
INFO - 2017-11-14 12:39:47 --> Utf8 Class Initialized
INFO - 2017-11-14 12:39:47 --> URI Class Initialized
INFO - 2017-11-14 12:39:47 --> Router Class Initialized
INFO - 2017-11-14 12:39:47 --> Output Class Initialized
INFO - 2017-11-14 12:39:47 --> Security Class Initialized
DEBUG - 2017-11-14 12:39:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 12:39:47 --> Input Class Initialized
INFO - 2017-11-14 12:39:47 --> Language Class Initialized
INFO - 2017-11-14 12:39:47 --> Language Class Initialized
INFO - 2017-11-14 12:39:47 --> Config Class Initialized
INFO - 2017-11-14 12:39:47 --> Loader Class Initialized
DEBUG - 2017-11-14 12:39:47 --> Config file loaded: D:\xampp\htdocs\construction_bay\application\config/construct-data.php
INFO - 2017-11-14 12:39:47 --> Helper loaded: url_helper
INFO - 2017-11-14 12:39:47 --> Helper loaded: form_helper
INFO - 2017-11-14 12:39:47 --> Helper loaded: date_helper
INFO - 2017-11-14 12:39:47 --> Helper loaded: util_helper
INFO - 2017-11-14 12:39:47 --> Helper loaded: text_helper
INFO - 2017-11-14 12:39:47 --> Helper loaded: string_helper
INFO - 2017-11-14 12:39:47 --> Database Driver Class Initialized
DEBUG - 2017-11-14 12:39:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-14 12:39:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-14 12:39:47 --> Email Class Initialized
INFO - 2017-11-14 12:39:47 --> Controller Class Initialized
INFO - 2017-11-14 12:39:47 --> Model Class Initialized
DEBUG - 2017-11-14 12:39:47 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_model.php
INFO - 2017-11-14 12:39:47 --> Model Class Initialized
DEBUG - 2017-11-14 12:39:47 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_functions_model.php
INFO - 2017-11-14 12:39:47 --> Model Class Initialized
DEBUG - 2017-11-14 12:39:47 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/template.php
INFO - 2017-11-14 12:41:53 --> Config Class Initialized
INFO - 2017-11-14 12:41:53 --> Hooks Class Initialized
DEBUG - 2017-11-14 12:41:53 --> UTF-8 Support Enabled
INFO - 2017-11-14 12:41:53 --> Utf8 Class Initialized
INFO - 2017-11-14 12:41:53 --> URI Class Initialized
INFO - 2017-11-14 12:41:53 --> Router Class Initialized
INFO - 2017-11-14 12:41:53 --> Output Class Initialized
INFO - 2017-11-14 12:41:53 --> Security Class Initialized
DEBUG - 2017-11-14 12:41:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 12:41:53 --> Input Class Initialized
INFO - 2017-11-14 12:41:53 --> Language Class Initialized
INFO - 2017-11-14 12:41:53 --> Language Class Initialized
INFO - 2017-11-14 12:41:53 --> Config Class Initialized
INFO - 2017-11-14 12:41:53 --> Loader Class Initialized
DEBUG - 2017-11-14 12:41:53 --> Config file loaded: D:\xampp\htdocs\construction_bay\application\config/construct-data.php
INFO - 2017-11-14 12:41:53 --> Helper loaded: url_helper
INFO - 2017-11-14 12:41:53 --> Helper loaded: form_helper
INFO - 2017-11-14 12:41:53 --> Helper loaded: date_helper
INFO - 2017-11-14 12:41:53 --> Helper loaded: util_helper
INFO - 2017-11-14 12:41:53 --> Helper loaded: text_helper
INFO - 2017-11-14 12:41:53 --> Helper loaded: string_helper
INFO - 2017-11-14 12:41:53 --> Database Driver Class Initialized
DEBUG - 2017-11-14 12:41:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-14 12:41:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-14 12:41:53 --> Email Class Initialized
INFO - 2017-11-14 12:41:53 --> Controller Class Initialized
INFO - 2017-11-14 12:41:53 --> Model Class Initialized
DEBUG - 2017-11-14 12:41:53 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_model.php
INFO - 2017-11-14 12:41:53 --> Model Class Initialized
DEBUG - 2017-11-14 12:41:53 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_functions_model.php
INFO - 2017-11-14 12:41:53 --> Model Class Initialized
DEBUG - 2017-11-14 12:41:53 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/template.php
INFO - 2017-11-14 12:41:54 --> Config Class Initialized
INFO - 2017-11-14 12:41:54 --> Hooks Class Initialized
DEBUG - 2017-11-14 12:41:54 --> UTF-8 Support Enabled
INFO - 2017-11-14 12:41:54 --> Utf8 Class Initialized
INFO - 2017-11-14 12:41:54 --> URI Class Initialized
INFO - 2017-11-14 12:41:54 --> Router Class Initialized
INFO - 2017-11-14 12:41:54 --> Output Class Initialized
INFO - 2017-11-14 12:41:54 --> Security Class Initialized
DEBUG - 2017-11-14 12:41:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 12:41:54 --> Input Class Initialized
INFO - 2017-11-14 12:41:54 --> Language Class Initialized
INFO - 2017-11-14 12:41:54 --> Language Class Initialized
INFO - 2017-11-14 12:41:54 --> Config Class Initialized
INFO - 2017-11-14 12:41:54 --> Loader Class Initialized
DEBUG - 2017-11-14 12:41:54 --> Config file loaded: D:\xampp\htdocs\construction_bay\application\config/construct-data.php
INFO - 2017-11-14 12:41:54 --> Helper loaded: url_helper
INFO - 2017-11-14 12:41:54 --> Helper loaded: form_helper
INFO - 2017-11-14 12:41:54 --> Helper loaded: date_helper
INFO - 2017-11-14 12:41:54 --> Helper loaded: util_helper
INFO - 2017-11-14 12:41:54 --> Helper loaded: text_helper
INFO - 2017-11-14 12:41:54 --> Helper loaded: string_helper
INFO - 2017-11-14 12:41:54 --> Database Driver Class Initialized
DEBUG - 2017-11-14 12:41:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-14 12:41:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-14 12:41:54 --> Email Class Initialized
INFO - 2017-11-14 12:41:54 --> Controller Class Initialized
INFO - 2017-11-14 12:41:54 --> Model Class Initialized
DEBUG - 2017-11-14 12:41:54 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_model.php
INFO - 2017-11-14 12:41:54 --> Model Class Initialized
DEBUG - 2017-11-14 12:41:54 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_functions_model.php
INFO - 2017-11-14 12:41:54 --> Model Class Initialized
DEBUG - 2017-11-14 12:41:54 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/template.php
INFO - 2017-11-14 12:45:33 --> Config Class Initialized
INFO - 2017-11-14 12:45:33 --> Hooks Class Initialized
DEBUG - 2017-11-14 12:45:33 --> UTF-8 Support Enabled
INFO - 2017-11-14 12:45:33 --> Utf8 Class Initialized
INFO - 2017-11-14 12:45:33 --> URI Class Initialized
INFO - 2017-11-14 12:45:33 --> Router Class Initialized
INFO - 2017-11-14 12:45:33 --> Output Class Initialized
INFO - 2017-11-14 12:45:33 --> Security Class Initialized
DEBUG - 2017-11-14 12:45:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 12:45:33 --> Input Class Initialized
INFO - 2017-11-14 12:45:33 --> Language Class Initialized
INFO - 2017-11-14 12:45:33 --> Language Class Initialized
INFO - 2017-11-14 12:45:33 --> Config Class Initialized
INFO - 2017-11-14 12:45:33 --> Loader Class Initialized
DEBUG - 2017-11-14 12:45:33 --> Config file loaded: D:\xampp\htdocs\construction_bay\application\config/construct-data.php
INFO - 2017-11-14 12:45:33 --> Helper loaded: url_helper
INFO - 2017-11-14 12:45:33 --> Helper loaded: form_helper
INFO - 2017-11-14 12:45:33 --> Helper loaded: date_helper
INFO - 2017-11-14 12:45:33 --> Helper loaded: util_helper
INFO - 2017-11-14 12:45:33 --> Helper loaded: text_helper
INFO - 2017-11-14 12:45:33 --> Helper loaded: string_helper
INFO - 2017-11-14 12:45:33 --> Database Driver Class Initialized
DEBUG - 2017-11-14 12:45:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-14 12:45:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-14 12:45:33 --> Email Class Initialized
INFO - 2017-11-14 12:45:33 --> Controller Class Initialized
INFO - 2017-11-14 12:45:33 --> Model Class Initialized
DEBUG - 2017-11-14 12:45:33 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_model.php
INFO - 2017-11-14 12:45:33 --> Model Class Initialized
DEBUG - 2017-11-14 12:45:33 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_functions_model.php
INFO - 2017-11-14 12:45:33 --> Model Class Initialized
DEBUG - 2017-11-14 12:45:33 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\companies/companies_header.php
DEBUG - 2017-11-14 12:45:33 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\companies/companies_page.php
DEBUG - 2017-11-14 12:45:33 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\companies/companies_footer.php
INFO - 2017-11-14 12:45:33 --> Final output sent to browser
DEBUG - 2017-11-14 12:45:33 --> Total execution time: 0.0840
INFO - 2017-11-14 12:45:34 --> Config Class Initialized
INFO - 2017-11-14 12:45:34 --> Hooks Class Initialized
DEBUG - 2017-11-14 12:45:34 --> UTF-8 Support Enabled
INFO - 2017-11-14 12:45:34 --> Utf8 Class Initialized
INFO - 2017-11-14 12:45:34 --> URI Class Initialized
INFO - 2017-11-14 12:45:34 --> Router Class Initialized
INFO - 2017-11-14 12:45:34 --> Output Class Initialized
INFO - 2017-11-14 12:45:34 --> Security Class Initialized
DEBUG - 2017-11-14 12:45:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 12:45:34 --> Input Class Initialized
INFO - 2017-11-14 12:45:34 --> Language Class Initialized
INFO - 2017-11-14 12:45:34 --> Language Class Initialized
INFO - 2017-11-14 12:45:34 --> Config Class Initialized
INFO - 2017-11-14 12:45:34 --> Loader Class Initialized
DEBUG - 2017-11-14 12:45:34 --> Config file loaded: D:\xampp\htdocs\construction_bay\application\config/construct-data.php
INFO - 2017-11-14 12:45:34 --> Helper loaded: url_helper
INFO - 2017-11-14 12:45:34 --> Helper loaded: form_helper
INFO - 2017-11-14 12:45:34 --> Helper loaded: date_helper
INFO - 2017-11-14 12:45:34 --> Helper loaded: util_helper
INFO - 2017-11-14 12:45:34 --> Helper loaded: text_helper
INFO - 2017-11-14 12:45:34 --> Helper loaded: string_helper
INFO - 2017-11-14 12:45:34 --> Database Driver Class Initialized
DEBUG - 2017-11-14 12:45:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-14 12:45:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-14 12:45:34 --> Email Class Initialized
INFO - 2017-11-14 12:45:34 --> Controller Class Initialized
INFO - 2017-11-14 12:45:34 --> Model Class Initialized
DEBUG - 2017-11-14 12:45:34 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_model.php
INFO - 2017-11-14 12:45:34 --> Model Class Initialized
DEBUG - 2017-11-14 12:45:34 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_functions_model.php
INFO - 2017-11-14 12:45:34 --> Model Class Initialized
DEBUG - 2017-11-14 12:45:34 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/template.php
INFO - 2017-11-14 12:45:38 --> Config Class Initialized
INFO - 2017-11-14 12:45:38 --> Hooks Class Initialized
DEBUG - 2017-11-14 12:45:38 --> UTF-8 Support Enabled
INFO - 2017-11-14 12:45:38 --> Utf8 Class Initialized
INFO - 2017-11-14 12:45:38 --> URI Class Initialized
INFO - 2017-11-14 12:45:38 --> Router Class Initialized
INFO - 2017-11-14 12:45:38 --> Output Class Initialized
INFO - 2017-11-14 12:45:38 --> Security Class Initialized
DEBUG - 2017-11-14 12:45:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 12:45:38 --> Input Class Initialized
INFO - 2017-11-14 12:45:38 --> Language Class Initialized
INFO - 2017-11-14 12:45:38 --> Language Class Initialized
INFO - 2017-11-14 12:45:38 --> Config Class Initialized
INFO - 2017-11-14 12:45:38 --> Loader Class Initialized
DEBUG - 2017-11-14 12:45:38 --> Config file loaded: D:\xampp\htdocs\construction_bay\application\config/construct-data.php
INFO - 2017-11-14 12:45:38 --> Helper loaded: url_helper
INFO - 2017-11-14 12:45:38 --> Helper loaded: form_helper
INFO - 2017-11-14 12:45:38 --> Helper loaded: date_helper
INFO - 2017-11-14 12:45:38 --> Helper loaded: util_helper
INFO - 2017-11-14 12:45:38 --> Helper loaded: text_helper
INFO - 2017-11-14 12:45:38 --> Helper loaded: string_helper
INFO - 2017-11-14 12:45:38 --> Database Driver Class Initialized
DEBUG - 2017-11-14 12:45:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-14 12:45:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-14 12:45:38 --> Email Class Initialized
INFO - 2017-11-14 12:45:38 --> Controller Class Initialized
INFO - 2017-11-14 12:45:38 --> Model Class Initialized
DEBUG - 2017-11-14 12:45:38 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_model.php
INFO - 2017-11-14 12:45:38 --> Model Class Initialized
DEBUG - 2017-11-14 12:45:38 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_functions_model.php
INFO - 2017-11-14 12:45:38 --> Model Class Initialized
ERROR - 2017-11-14 12:45:39 --> Severity: Notice --> Undefined variable: category D:\xampp\htdocs\construction_bay\application\views\common\header.php 309
DEBUG - 2017-11-14 12:45:39 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header.php
ERROR - 2017-11-14 12:45:39 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\construction_bay\application\views\microsite.php 86
ERROR - 2017-11-14 12:45:39 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\construction_bay\application\views\microsite.php 97
ERROR - 2017-11-14 12:45:39 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\construction_bay\application\views\microsite.php 101
DEBUG - 2017-11-14 12:45:39 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\microsite.php
DEBUG - 2017-11-14 12:45:39 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/footer.php
INFO - 2017-11-14 12:45:39 --> Final output sent to browser
DEBUG - 2017-11-14 12:45:39 --> Total execution time: 0.3120
INFO - 2017-11-14 12:45:40 --> Config Class Initialized
INFO - 2017-11-14 12:45:40 --> Hooks Class Initialized
DEBUG - 2017-11-14 12:45:40 --> UTF-8 Support Enabled
INFO - 2017-11-14 12:45:40 --> Utf8 Class Initialized
INFO - 2017-11-14 12:45:40 --> URI Class Initialized
INFO - 2017-11-14 12:45:40 --> Router Class Initialized
INFO - 2017-11-14 12:45:40 --> Output Class Initialized
INFO - 2017-11-14 12:45:40 --> Security Class Initialized
DEBUG - 2017-11-14 12:45:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 12:45:40 --> Input Class Initialized
INFO - 2017-11-14 12:45:40 --> Language Class Initialized
INFO - 2017-11-14 12:45:40 --> Language Class Initialized
INFO - 2017-11-14 12:45:40 --> Config Class Initialized
INFO - 2017-11-14 12:45:40 --> Loader Class Initialized
DEBUG - 2017-11-14 12:45:40 --> Config file loaded: D:\xampp\htdocs\construction_bay\application\config/construct-data.php
INFO - 2017-11-14 12:45:40 --> Helper loaded: url_helper
INFO - 2017-11-14 12:45:40 --> Helper loaded: form_helper
INFO - 2017-11-14 12:45:40 --> Helper loaded: date_helper
INFO - 2017-11-14 12:45:40 --> Helper loaded: util_helper
INFO - 2017-11-14 12:45:40 --> Helper loaded: text_helper
INFO - 2017-11-14 12:45:40 --> Helper loaded: string_helper
INFO - 2017-11-14 12:45:40 --> Database Driver Class Initialized
DEBUG - 2017-11-14 12:45:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-14 12:45:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-14 12:45:40 --> Email Class Initialized
INFO - 2017-11-14 12:45:40 --> Controller Class Initialized
INFO - 2017-11-14 12:45:40 --> Model Class Initialized
DEBUG - 2017-11-14 12:45:40 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_model.php
INFO - 2017-11-14 12:45:40 --> Model Class Initialized
DEBUG - 2017-11-14 12:45:40 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_functions_model.php
INFO - 2017-11-14 12:45:40 --> Model Class Initialized
ERROR - 2017-11-14 12:45:40 --> Severity: Notice --> Undefined variable: category D:\xampp\htdocs\construction_bay\application\views\common\header.php 309
DEBUG - 2017-11-14 12:45:40 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header.php
DEBUG - 2017-11-14 12:45:40 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\microsite.php
DEBUG - 2017-11-14 12:45:40 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/footer.php
INFO - 2017-11-14 12:45:40 --> Final output sent to browser
DEBUG - 2017-11-14 12:45:40 --> Total execution time: 0.0570
INFO - 2017-11-14 12:45:45 --> Config Class Initialized
INFO - 2017-11-14 12:45:45 --> Hooks Class Initialized
DEBUG - 2017-11-14 12:45:45 --> UTF-8 Support Enabled
INFO - 2017-11-14 12:45:45 --> Utf8 Class Initialized
INFO - 2017-11-14 12:45:45 --> URI Class Initialized
INFO - 2017-11-14 12:45:45 --> Router Class Initialized
INFO - 2017-11-14 12:45:45 --> Output Class Initialized
INFO - 2017-11-14 12:45:45 --> Security Class Initialized
DEBUG - 2017-11-14 12:45:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 12:45:45 --> Input Class Initialized
INFO - 2017-11-14 12:45:45 --> Language Class Initialized
INFO - 2017-11-14 12:45:45 --> Language Class Initialized
INFO - 2017-11-14 12:45:45 --> Config Class Initialized
INFO - 2017-11-14 12:45:45 --> Loader Class Initialized
DEBUG - 2017-11-14 12:45:45 --> Config file loaded: D:\xampp\htdocs\construction_bay\application\config/construct-data.php
INFO - 2017-11-14 12:45:45 --> Helper loaded: url_helper
INFO - 2017-11-14 12:45:45 --> Helper loaded: form_helper
INFO - 2017-11-14 12:45:45 --> Helper loaded: date_helper
INFO - 2017-11-14 12:45:45 --> Helper loaded: util_helper
INFO - 2017-11-14 12:45:45 --> Helper loaded: text_helper
INFO - 2017-11-14 12:45:45 --> Helper loaded: string_helper
INFO - 2017-11-14 12:45:45 --> Database Driver Class Initialized
DEBUG - 2017-11-14 12:45:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-14 12:45:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-14 12:45:45 --> Email Class Initialized
INFO - 2017-11-14 12:45:45 --> Controller Class Initialized
INFO - 2017-11-14 12:45:45 --> Model Class Initialized
DEBUG - 2017-11-14 12:45:45 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_model.php
INFO - 2017-11-14 12:45:45 --> Model Class Initialized
DEBUG - 2017-11-14 12:45:45 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_functions_model.php
INFO - 2017-11-14 12:45:45 --> Model Class Initialized
DEBUG - 2017-11-14 12:45:45 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\companies/companies_header.php
DEBUG - 2017-11-14 12:45:45 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\companies/companies_page.php
DEBUG - 2017-11-14 12:45:45 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\companies/companies_footer.php
INFO - 2017-11-14 12:45:45 --> Final output sent to browser
DEBUG - 2017-11-14 12:45:45 --> Total execution time: 0.0700
INFO - 2017-11-14 12:45:46 --> Config Class Initialized
INFO - 2017-11-14 12:45:46 --> Hooks Class Initialized
DEBUG - 2017-11-14 12:45:46 --> UTF-8 Support Enabled
INFO - 2017-11-14 12:45:46 --> Utf8 Class Initialized
INFO - 2017-11-14 12:45:46 --> URI Class Initialized
INFO - 2017-11-14 12:45:46 --> Router Class Initialized
INFO - 2017-11-14 12:45:46 --> Output Class Initialized
INFO - 2017-11-14 12:45:46 --> Security Class Initialized
DEBUG - 2017-11-14 12:45:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 12:45:46 --> Input Class Initialized
INFO - 2017-11-14 12:45:46 --> Language Class Initialized
INFO - 2017-11-14 12:45:46 --> Language Class Initialized
INFO - 2017-11-14 12:45:46 --> Config Class Initialized
INFO - 2017-11-14 12:45:46 --> Loader Class Initialized
DEBUG - 2017-11-14 12:45:46 --> Config file loaded: D:\xampp\htdocs\construction_bay\application\config/construct-data.php
INFO - 2017-11-14 12:45:46 --> Helper loaded: url_helper
INFO - 2017-11-14 12:45:46 --> Helper loaded: form_helper
INFO - 2017-11-14 12:45:46 --> Helper loaded: date_helper
INFO - 2017-11-14 12:45:46 --> Helper loaded: util_helper
INFO - 2017-11-14 12:45:46 --> Helper loaded: text_helper
INFO - 2017-11-14 12:45:46 --> Helper loaded: string_helper
INFO - 2017-11-14 12:45:46 --> Database Driver Class Initialized
DEBUG - 2017-11-14 12:45:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-14 12:45:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-14 12:45:46 --> Email Class Initialized
INFO - 2017-11-14 12:45:46 --> Controller Class Initialized
INFO - 2017-11-14 12:45:46 --> Model Class Initialized
DEBUG - 2017-11-14 12:45:46 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_model.php
INFO - 2017-11-14 12:45:46 --> Model Class Initialized
DEBUG - 2017-11-14 12:45:46 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_functions_model.php
INFO - 2017-11-14 12:45:46 --> Model Class Initialized
DEBUG - 2017-11-14 12:45:46 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/template.php
INFO - 2017-11-14 12:49:07 --> Config Class Initialized
INFO - 2017-11-14 12:49:07 --> Hooks Class Initialized
DEBUG - 2017-11-14 12:49:07 --> UTF-8 Support Enabled
INFO - 2017-11-14 12:49:07 --> Utf8 Class Initialized
INFO - 2017-11-14 12:49:07 --> URI Class Initialized
INFO - 2017-11-14 12:49:07 --> Router Class Initialized
INFO - 2017-11-14 12:49:07 --> Output Class Initialized
INFO - 2017-11-14 12:49:07 --> Security Class Initialized
DEBUG - 2017-11-14 12:49:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 12:49:07 --> Input Class Initialized
INFO - 2017-11-14 12:49:07 --> Language Class Initialized
INFO - 2017-11-14 12:49:07 --> Language Class Initialized
INFO - 2017-11-14 12:49:07 --> Config Class Initialized
INFO - 2017-11-14 12:49:07 --> Loader Class Initialized
DEBUG - 2017-11-14 12:49:07 --> Config file loaded: D:\xampp\htdocs\construction_bay\application\config/construct-data.php
INFO - 2017-11-14 12:49:07 --> Helper loaded: url_helper
INFO - 2017-11-14 12:49:07 --> Helper loaded: form_helper
INFO - 2017-11-14 12:49:07 --> Helper loaded: date_helper
INFO - 2017-11-14 12:49:07 --> Helper loaded: util_helper
INFO - 2017-11-14 12:49:07 --> Helper loaded: text_helper
INFO - 2017-11-14 12:49:07 --> Helper loaded: string_helper
INFO - 2017-11-14 12:49:07 --> Database Driver Class Initialized
DEBUG - 2017-11-14 12:49:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-14 12:49:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-14 12:49:07 --> Email Class Initialized
INFO - 2017-11-14 12:49:07 --> Controller Class Initialized
INFO - 2017-11-14 12:49:07 --> Model Class Initialized
DEBUG - 2017-11-14 12:49:07 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_model.php
INFO - 2017-11-14 12:49:07 --> Model Class Initialized
DEBUG - 2017-11-14 12:49:07 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_functions_model.php
INFO - 2017-11-14 12:49:07 --> Model Class Initialized
DEBUG - 2017-11-14 12:49:07 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\companies/companies_header.php
DEBUG - 2017-11-14 12:49:07 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\companies/companies_page.php
DEBUG - 2017-11-14 12:49:07 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\companies/companies_footer.php
INFO - 2017-11-14 12:49:07 --> Final output sent to browser
DEBUG - 2017-11-14 12:49:07 --> Total execution time: 0.0830
INFO - 2017-11-14 12:49:09 --> Config Class Initialized
INFO - 2017-11-14 12:49:09 --> Hooks Class Initialized
DEBUG - 2017-11-14 12:49:09 --> UTF-8 Support Enabled
INFO - 2017-11-14 12:49:09 --> Utf8 Class Initialized
INFO - 2017-11-14 12:49:09 --> URI Class Initialized
INFO - 2017-11-14 12:49:09 --> Router Class Initialized
INFO - 2017-11-14 12:49:09 --> Output Class Initialized
INFO - 2017-11-14 12:49:09 --> Security Class Initialized
DEBUG - 2017-11-14 12:49:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 12:49:09 --> Input Class Initialized
INFO - 2017-11-14 12:49:09 --> Language Class Initialized
ERROR - 2017-11-14 12:49:09 --> 404 Page Not Found: /index
INFO - 2017-11-14 12:49:09 --> Config Class Initialized
INFO - 2017-11-14 12:49:09 --> Hooks Class Initialized
DEBUG - 2017-11-14 12:49:09 --> UTF-8 Support Enabled
INFO - 2017-11-14 12:49:09 --> Utf8 Class Initialized
INFO - 2017-11-14 12:49:09 --> URI Class Initialized
INFO - 2017-11-14 12:49:09 --> Router Class Initialized
INFO - 2017-11-14 12:49:09 --> Output Class Initialized
INFO - 2017-11-14 12:49:09 --> Security Class Initialized
DEBUG - 2017-11-14 12:49:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 12:49:09 --> Input Class Initialized
INFO - 2017-11-14 12:49:09 --> Language Class Initialized
INFO - 2017-11-14 12:49:09 --> Language Class Initialized
INFO - 2017-11-14 12:49:09 --> Config Class Initialized
INFO - 2017-11-14 12:49:09 --> Loader Class Initialized
DEBUG - 2017-11-14 12:49:09 --> Config file loaded: D:\xampp\htdocs\construction_bay\application\config/construct-data.php
INFO - 2017-11-14 12:49:09 --> Helper loaded: url_helper
INFO - 2017-11-14 12:49:09 --> Helper loaded: form_helper
INFO - 2017-11-14 12:49:09 --> Helper loaded: date_helper
INFO - 2017-11-14 12:49:09 --> Helper loaded: util_helper
INFO - 2017-11-14 12:49:09 --> Helper loaded: text_helper
INFO - 2017-11-14 12:49:09 --> Helper loaded: string_helper
INFO - 2017-11-14 12:49:09 --> Database Driver Class Initialized
DEBUG - 2017-11-14 12:49:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-14 12:49:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-14 12:49:09 --> Email Class Initialized
INFO - 2017-11-14 12:49:09 --> Controller Class Initialized
INFO - 2017-11-14 12:49:09 --> Model Class Initialized
DEBUG - 2017-11-14 12:49:09 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_model.php
INFO - 2017-11-14 12:49:09 --> Model Class Initialized
DEBUG - 2017-11-14 12:49:09 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_functions_model.php
INFO - 2017-11-14 12:49:09 --> Model Class Initialized
DEBUG - 2017-11-14 12:49:09 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/template.php
INFO - 2017-11-14 12:50:53 --> Config Class Initialized
INFO - 2017-11-14 12:50:53 --> Hooks Class Initialized
DEBUG - 2017-11-14 12:50:53 --> UTF-8 Support Enabled
INFO - 2017-11-14 12:50:53 --> Utf8 Class Initialized
INFO - 2017-11-14 12:50:53 --> URI Class Initialized
INFO - 2017-11-14 12:50:53 --> Router Class Initialized
INFO - 2017-11-14 12:50:53 --> Output Class Initialized
INFO - 2017-11-14 12:50:53 --> Security Class Initialized
DEBUG - 2017-11-14 12:50:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 12:50:53 --> Input Class Initialized
INFO - 2017-11-14 12:50:53 --> Language Class Initialized
INFO - 2017-11-14 12:50:53 --> Language Class Initialized
INFO - 2017-11-14 12:50:53 --> Config Class Initialized
INFO - 2017-11-14 12:50:53 --> Loader Class Initialized
DEBUG - 2017-11-14 12:50:53 --> Config file loaded: D:\xampp\htdocs\construction_bay\application\config/construct-data.php
INFO - 2017-11-14 12:50:53 --> Helper loaded: url_helper
INFO - 2017-11-14 12:50:53 --> Helper loaded: form_helper
INFO - 2017-11-14 12:50:53 --> Helper loaded: date_helper
INFO - 2017-11-14 12:50:53 --> Helper loaded: util_helper
INFO - 2017-11-14 12:50:53 --> Helper loaded: text_helper
INFO - 2017-11-14 12:50:53 --> Helper loaded: string_helper
INFO - 2017-11-14 12:50:53 --> Database Driver Class Initialized
DEBUG - 2017-11-14 12:50:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-14 12:50:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-14 12:50:53 --> Email Class Initialized
INFO - 2017-11-14 12:50:53 --> Controller Class Initialized
INFO - 2017-11-14 12:50:53 --> Model Class Initialized
DEBUG - 2017-11-14 12:50:53 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_model.php
INFO - 2017-11-14 12:50:53 --> Model Class Initialized
DEBUG - 2017-11-14 12:50:53 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_functions_model.php
INFO - 2017-11-14 12:50:53 --> Model Class Initialized
DEBUG - 2017-11-14 12:50:53 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\companies/companies_header.php
DEBUG - 2017-11-14 12:50:53 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\companies/companies_page.php
DEBUG - 2017-11-14 12:50:53 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\companies/companies_footer.php
INFO - 2017-11-14 12:50:53 --> Final output sent to browser
DEBUG - 2017-11-14 12:50:53 --> Total execution time: 0.0810
INFO - 2017-11-14 12:50:54 --> Config Class Initialized
INFO - 2017-11-14 12:50:54 --> Hooks Class Initialized
DEBUG - 2017-11-14 12:50:54 --> UTF-8 Support Enabled
INFO - 2017-11-14 12:50:54 --> Utf8 Class Initialized
INFO - 2017-11-14 12:50:54 --> URI Class Initialized
INFO - 2017-11-14 12:50:54 --> Router Class Initialized
INFO - 2017-11-14 12:50:54 --> Output Class Initialized
INFO - 2017-11-14 12:50:54 --> Security Class Initialized
DEBUG - 2017-11-14 12:50:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 12:50:54 --> Input Class Initialized
INFO - 2017-11-14 12:50:54 --> Language Class Initialized
ERROR - 2017-11-14 12:50:54 --> 404 Page Not Found: /index
INFO - 2017-11-14 12:50:55 --> Config Class Initialized
INFO - 2017-11-14 12:50:55 --> Hooks Class Initialized
DEBUG - 2017-11-14 12:50:55 --> UTF-8 Support Enabled
INFO - 2017-11-14 12:50:55 --> Utf8 Class Initialized
INFO - 2017-11-14 12:50:55 --> URI Class Initialized
INFO - 2017-11-14 12:50:55 --> Router Class Initialized
INFO - 2017-11-14 12:50:55 --> Output Class Initialized
INFO - 2017-11-14 12:50:55 --> Security Class Initialized
DEBUG - 2017-11-14 12:50:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 12:50:55 --> Input Class Initialized
INFO - 2017-11-14 12:50:55 --> Language Class Initialized
INFO - 2017-11-14 12:50:55 --> Language Class Initialized
INFO - 2017-11-14 12:50:55 --> Config Class Initialized
INFO - 2017-11-14 12:50:55 --> Loader Class Initialized
DEBUG - 2017-11-14 12:50:55 --> Config file loaded: D:\xampp\htdocs\construction_bay\application\config/construct-data.php
INFO - 2017-11-14 12:50:55 --> Helper loaded: url_helper
INFO - 2017-11-14 12:50:55 --> Helper loaded: form_helper
INFO - 2017-11-14 12:50:55 --> Helper loaded: date_helper
INFO - 2017-11-14 12:50:55 --> Helper loaded: util_helper
INFO - 2017-11-14 12:50:55 --> Helper loaded: text_helper
INFO - 2017-11-14 12:50:55 --> Helper loaded: string_helper
INFO - 2017-11-14 12:50:55 --> Database Driver Class Initialized
DEBUG - 2017-11-14 12:50:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-14 12:50:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-14 12:50:55 --> Email Class Initialized
INFO - 2017-11-14 12:50:55 --> Controller Class Initialized
INFO - 2017-11-14 12:50:55 --> Model Class Initialized
DEBUG - 2017-11-14 12:50:55 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_model.php
INFO - 2017-11-14 12:50:55 --> Model Class Initialized
DEBUG - 2017-11-14 12:50:55 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_functions_model.php
INFO - 2017-11-14 12:50:55 --> Model Class Initialized
DEBUG - 2017-11-14 12:50:55 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/template.php
INFO - 2017-11-14 12:51:30 --> Config Class Initialized
INFO - 2017-11-14 12:51:30 --> Hooks Class Initialized
DEBUG - 2017-11-14 12:51:30 --> UTF-8 Support Enabled
INFO - 2017-11-14 12:51:30 --> Utf8 Class Initialized
INFO - 2017-11-14 12:51:30 --> URI Class Initialized
INFO - 2017-11-14 12:51:30 --> Router Class Initialized
INFO - 2017-11-14 12:51:30 --> Output Class Initialized
INFO - 2017-11-14 12:51:30 --> Security Class Initialized
DEBUG - 2017-11-14 12:51:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 12:51:30 --> Input Class Initialized
INFO - 2017-11-14 12:51:30 --> Language Class Initialized
INFO - 2017-11-14 12:51:30 --> Language Class Initialized
INFO - 2017-11-14 12:51:30 --> Config Class Initialized
INFO - 2017-11-14 12:51:30 --> Loader Class Initialized
DEBUG - 2017-11-14 12:51:30 --> Config file loaded: D:\xampp\htdocs\construction_bay\application\config/construct-data.php
INFO - 2017-11-14 12:51:30 --> Helper loaded: url_helper
INFO - 2017-11-14 12:51:30 --> Helper loaded: form_helper
INFO - 2017-11-14 12:51:30 --> Helper loaded: date_helper
INFO - 2017-11-14 12:51:30 --> Helper loaded: util_helper
INFO - 2017-11-14 12:51:30 --> Helper loaded: text_helper
INFO - 2017-11-14 12:51:30 --> Helper loaded: string_helper
INFO - 2017-11-14 12:51:30 --> Database Driver Class Initialized
DEBUG - 2017-11-14 12:51:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-14 12:51:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-14 12:51:30 --> Email Class Initialized
INFO - 2017-11-14 12:51:30 --> Controller Class Initialized
INFO - 2017-11-14 12:51:30 --> Model Class Initialized
DEBUG - 2017-11-14 12:51:30 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_model.php
INFO - 2017-11-14 12:51:30 --> Model Class Initialized
DEBUG - 2017-11-14 12:51:30 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_functions_model.php
INFO - 2017-11-14 12:51:30 --> Model Class Initialized
DEBUG - 2017-11-14 12:51:30 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\companies/companies_header.php
DEBUG - 2017-11-14 12:51:30 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\companies/companies_page.php
DEBUG - 2017-11-14 12:51:30 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\companies/companies_footer.php
INFO - 2017-11-14 12:51:30 --> Final output sent to browser
DEBUG - 2017-11-14 12:51:30 --> Total execution time: 0.0900
INFO - 2017-11-14 12:51:32 --> Config Class Initialized
INFO - 2017-11-14 12:51:32 --> Hooks Class Initialized
DEBUG - 2017-11-14 12:51:32 --> UTF-8 Support Enabled
INFO - 2017-11-14 12:51:32 --> Utf8 Class Initialized
INFO - 2017-11-14 12:51:32 --> URI Class Initialized
INFO - 2017-11-14 12:51:32 --> Router Class Initialized
INFO - 2017-11-14 12:51:32 --> Output Class Initialized
INFO - 2017-11-14 12:51:32 --> Security Class Initialized
DEBUG - 2017-11-14 12:51:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 12:51:32 --> Input Class Initialized
INFO - 2017-11-14 12:51:32 --> Language Class Initialized
INFO - 2017-11-14 12:51:32 --> Language Class Initialized
INFO - 2017-11-14 12:51:32 --> Config Class Initialized
INFO - 2017-11-14 12:51:32 --> Loader Class Initialized
DEBUG - 2017-11-14 12:51:32 --> Config file loaded: D:\xampp\htdocs\construction_bay\application\config/construct-data.php
INFO - 2017-11-14 12:51:32 --> Helper loaded: url_helper
INFO - 2017-11-14 12:51:32 --> Helper loaded: form_helper
INFO - 2017-11-14 12:51:32 --> Helper loaded: date_helper
INFO - 2017-11-14 12:51:32 --> Helper loaded: util_helper
INFO - 2017-11-14 12:51:32 --> Helper loaded: text_helper
INFO - 2017-11-14 12:51:32 --> Helper loaded: string_helper
INFO - 2017-11-14 12:51:32 --> Database Driver Class Initialized
DEBUG - 2017-11-14 12:51:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-14 12:51:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-14 12:51:32 --> Email Class Initialized
INFO - 2017-11-14 12:51:32 --> Controller Class Initialized
INFO - 2017-11-14 12:51:32 --> Model Class Initialized
DEBUG - 2017-11-14 12:51:32 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_model.php
INFO - 2017-11-14 12:51:32 --> Model Class Initialized
DEBUG - 2017-11-14 12:51:32 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_functions_model.php
INFO - 2017-11-14 12:51:32 --> Model Class Initialized
DEBUG - 2017-11-14 12:51:32 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/template.php
INFO - 2017-11-14 12:51:35 --> Config Class Initialized
INFO - 2017-11-14 12:51:35 --> Hooks Class Initialized
DEBUG - 2017-11-14 12:51:35 --> UTF-8 Support Enabled
INFO - 2017-11-14 12:51:35 --> Utf8 Class Initialized
INFO - 2017-11-14 12:51:35 --> URI Class Initialized
DEBUG - 2017-11-14 12:51:35 --> No URI present. Default controller set.
INFO - 2017-11-14 12:51:35 --> Router Class Initialized
INFO - 2017-11-14 12:51:35 --> Output Class Initialized
INFO - 2017-11-14 12:51:35 --> Security Class Initialized
DEBUG - 2017-11-14 12:51:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 12:51:35 --> Input Class Initialized
INFO - 2017-11-14 12:51:35 --> Language Class Initialized
INFO - 2017-11-14 12:51:35 --> Language Class Initialized
INFO - 2017-11-14 12:51:35 --> Config Class Initialized
INFO - 2017-11-14 12:51:35 --> Loader Class Initialized
DEBUG - 2017-11-14 12:51:35 --> Config file loaded: D:\xampp\htdocs\construction_bay\application\config/construct-data.php
INFO - 2017-11-14 12:51:35 --> Helper loaded: url_helper
INFO - 2017-11-14 12:51:35 --> Helper loaded: form_helper
INFO - 2017-11-14 12:51:35 --> Helper loaded: date_helper
INFO - 2017-11-14 12:51:35 --> Helper loaded: util_helper
INFO - 2017-11-14 12:51:35 --> Helper loaded: text_helper
INFO - 2017-11-14 12:51:35 --> Helper loaded: string_helper
INFO - 2017-11-14 12:51:35 --> Database Driver Class Initialized
DEBUG - 2017-11-14 12:51:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-14 12:51:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-14 12:51:35 --> Email Class Initialized
INFO - 2017-11-14 12:51:35 --> Controller Class Initialized
DEBUG - 2017-11-14 12:51:35 --> Home MX_Controller Initialized
INFO - 2017-11-14 12:51:35 --> Model Class Initialized
DEBUG - 2017-11-14 12:51:35 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_model.php
INFO - 2017-11-14 12:51:35 --> Model Class Initialized
DEBUG - 2017-11-14 12:51:35 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header.php
DEBUG - 2017-11-14 12:51:35 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/slider.php
DEBUG - 2017-11-14 12:51:35 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/index_body.php
DEBUG - 2017-11-14 12:51:35 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/index_footer.php
INFO - 2017-11-14 12:51:35 --> Final output sent to browser
DEBUG - 2017-11-14 12:51:35 --> Total execution time: 0.0580
INFO - 2017-11-14 13:00:29 --> Config Class Initialized
INFO - 2017-11-14 13:00:29 --> Hooks Class Initialized
DEBUG - 2017-11-14 13:00:29 --> UTF-8 Support Enabled
INFO - 2017-11-14 13:00:29 --> Utf8 Class Initialized
INFO - 2017-11-14 13:00:29 --> URI Class Initialized
INFO - 2017-11-14 13:00:29 --> Router Class Initialized
INFO - 2017-11-14 13:00:29 --> Output Class Initialized
INFO - 2017-11-14 13:00:29 --> Security Class Initialized
DEBUG - 2017-11-14 13:00:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 13:00:29 --> Input Class Initialized
INFO - 2017-11-14 13:00:29 --> Language Class Initialized
INFO - 2017-11-14 13:00:29 --> Language Class Initialized
INFO - 2017-11-14 13:00:29 --> Config Class Initialized
INFO - 2017-11-14 13:00:29 --> Loader Class Initialized
DEBUG - 2017-11-14 13:00:29 --> Config file loaded: D:\xampp\htdocs\construction_bay\application\config/construct-data.php
INFO - 2017-11-14 13:00:29 --> Helper loaded: url_helper
INFO - 2017-11-14 13:00:29 --> Helper loaded: form_helper
INFO - 2017-11-14 13:00:29 --> Helper loaded: date_helper
INFO - 2017-11-14 13:00:29 --> Helper loaded: util_helper
INFO - 2017-11-14 13:00:29 --> Helper loaded: text_helper
INFO - 2017-11-14 13:00:29 --> Helper loaded: string_helper
INFO - 2017-11-14 13:00:29 --> Database Driver Class Initialized
DEBUG - 2017-11-14 13:00:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-14 13:00:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-14 13:00:29 --> Email Class Initialized
INFO - 2017-11-14 13:00:29 --> Controller Class Initialized
INFO - 2017-11-14 13:00:29 --> Model Class Initialized
DEBUG - 2017-11-14 13:00:29 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_model.php
INFO - 2017-11-14 13:00:29 --> Model Class Initialized
DEBUG - 2017-11-14 13:00:29 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_functions_model.php
INFO - 2017-11-14 13:00:29 --> Model Class Initialized
DEBUG - 2017-11-14 13:00:29 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\companies/companies_header.php
DEBUG - 2017-11-14 13:00:29 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\companies/companies_page.php
DEBUG - 2017-11-14 13:00:29 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\companies/companies_footer.php
INFO - 2017-11-14 13:00:29 --> Final output sent to browser
DEBUG - 2017-11-14 13:00:29 --> Total execution time: 0.0860
INFO - 2017-11-14 13:00:31 --> Config Class Initialized
INFO - 2017-11-14 13:00:31 --> Hooks Class Initialized
DEBUG - 2017-11-14 13:00:31 --> UTF-8 Support Enabled
INFO - 2017-11-14 13:00:31 --> Utf8 Class Initialized
INFO - 2017-11-14 13:00:31 --> URI Class Initialized
INFO - 2017-11-14 13:00:31 --> Router Class Initialized
INFO - 2017-11-14 13:00:31 --> Output Class Initialized
INFO - 2017-11-14 13:00:31 --> Security Class Initialized
DEBUG - 2017-11-14 13:00:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 13:00:31 --> Input Class Initialized
INFO - 2017-11-14 13:00:31 --> Language Class Initialized
ERROR - 2017-11-14 13:00:31 --> 404 Page Not Found: /index
INFO - 2017-11-14 13:00:31 --> Config Class Initialized
INFO - 2017-11-14 13:00:31 --> Hooks Class Initialized
DEBUG - 2017-11-14 13:00:31 --> UTF-8 Support Enabled
INFO - 2017-11-14 13:00:31 --> Utf8 Class Initialized
INFO - 2017-11-14 13:00:31 --> URI Class Initialized
INFO - 2017-11-14 13:00:31 --> Router Class Initialized
INFO - 2017-11-14 13:00:31 --> Output Class Initialized
INFO - 2017-11-14 13:00:31 --> Security Class Initialized
DEBUG - 2017-11-14 13:00:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 13:00:31 --> Input Class Initialized
INFO - 2017-11-14 13:00:31 --> Language Class Initialized
INFO - 2017-11-14 13:00:31 --> Language Class Initialized
INFO - 2017-11-14 13:00:31 --> Config Class Initialized
INFO - 2017-11-14 13:00:31 --> Loader Class Initialized
DEBUG - 2017-11-14 13:00:31 --> Config file loaded: D:\xampp\htdocs\construction_bay\application\config/construct-data.php
INFO - 2017-11-14 13:00:31 --> Helper loaded: url_helper
INFO - 2017-11-14 13:00:31 --> Helper loaded: form_helper
INFO - 2017-11-14 13:00:31 --> Helper loaded: date_helper
INFO - 2017-11-14 13:00:31 --> Helper loaded: util_helper
INFO - 2017-11-14 13:00:31 --> Helper loaded: text_helper
INFO - 2017-11-14 13:00:31 --> Helper loaded: string_helper
INFO - 2017-11-14 13:00:31 --> Database Driver Class Initialized
DEBUG - 2017-11-14 13:00:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-14 13:00:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-14 13:00:31 --> Email Class Initialized
INFO - 2017-11-14 13:00:31 --> Controller Class Initialized
INFO - 2017-11-14 13:00:31 --> Model Class Initialized
DEBUG - 2017-11-14 13:00:31 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_model.php
INFO - 2017-11-14 13:00:31 --> Model Class Initialized
DEBUG - 2017-11-14 13:00:31 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_functions_model.php
INFO - 2017-11-14 13:00:31 --> Model Class Initialized
DEBUG - 2017-11-14 13:00:31 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/template.php
INFO - 2017-11-14 13:11:56 --> Config Class Initialized
INFO - 2017-11-14 13:11:56 --> Hooks Class Initialized
DEBUG - 2017-11-14 13:11:56 --> UTF-8 Support Enabled
INFO - 2017-11-14 13:11:56 --> Utf8 Class Initialized
INFO - 2017-11-14 13:11:56 --> URI Class Initialized
DEBUG - 2017-11-14 13:11:56 --> No URI present. Default controller set.
INFO - 2017-11-14 13:11:56 --> Router Class Initialized
INFO - 2017-11-14 13:11:56 --> Output Class Initialized
INFO - 2017-11-14 13:11:56 --> Security Class Initialized
DEBUG - 2017-11-14 13:11:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 13:11:56 --> Input Class Initialized
INFO - 2017-11-14 13:11:56 --> Language Class Initialized
INFO - 2017-11-14 13:11:56 --> Language Class Initialized
INFO - 2017-11-14 13:11:56 --> Config Class Initialized
INFO - 2017-11-14 13:11:56 --> Loader Class Initialized
DEBUG - 2017-11-14 13:11:56 --> Config file loaded: D:\xampp\htdocs\construction_bay\application\config/construct-data.php
INFO - 2017-11-14 13:11:56 --> Helper loaded: url_helper
INFO - 2017-11-14 13:11:56 --> Helper loaded: form_helper
INFO - 2017-11-14 13:11:56 --> Helper loaded: date_helper
INFO - 2017-11-14 13:11:56 --> Helper loaded: util_helper
INFO - 2017-11-14 13:11:56 --> Helper loaded: text_helper
INFO - 2017-11-14 13:11:56 --> Helper loaded: string_helper
INFO - 2017-11-14 13:11:56 --> Database Driver Class Initialized
DEBUG - 2017-11-14 13:11:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-14 13:11:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-14 13:11:56 --> Email Class Initialized
INFO - 2017-11-14 13:11:56 --> Controller Class Initialized
DEBUG - 2017-11-14 13:11:56 --> Home MX_Controller Initialized
INFO - 2017-11-14 13:11:56 --> Model Class Initialized
DEBUG - 2017-11-14 13:11:56 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_model.php
INFO - 2017-11-14 13:11:56 --> Model Class Initialized
DEBUG - 2017-11-14 13:11:56 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header_menu.php
DEBUG - 2017-11-14 13:11:56 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header.php
DEBUG - 2017-11-14 13:11:56 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/slider.php
DEBUG - 2017-11-14 13:11:56 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/index_body.php
DEBUG - 2017-11-14 13:11:56 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/index_footer.php
INFO - 2017-11-14 13:11:56 --> Final output sent to browser
DEBUG - 2017-11-14 13:11:56 --> Total execution time: 0.0640
INFO - 2017-11-14 13:54:24 --> Config Class Initialized
INFO - 2017-11-14 13:54:24 --> Hooks Class Initialized
DEBUG - 2017-11-14 13:54:24 --> UTF-8 Support Enabled
INFO - 2017-11-14 13:54:24 --> Utf8 Class Initialized
INFO - 2017-11-14 13:54:24 --> URI Class Initialized
INFO - 2017-11-14 13:54:24 --> Router Class Initialized
INFO - 2017-11-14 13:54:24 --> Output Class Initialized
INFO - 2017-11-14 13:54:24 --> Security Class Initialized
DEBUG - 2017-11-14 13:54:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 13:54:24 --> Input Class Initialized
INFO - 2017-11-14 13:54:24 --> Language Class Initialized
INFO - 2017-11-14 13:54:24 --> Language Class Initialized
INFO - 2017-11-14 13:54:24 --> Config Class Initialized
INFO - 2017-11-14 13:54:24 --> Loader Class Initialized
DEBUG - 2017-11-14 13:54:24 --> Config file loaded: D:\xampp\htdocs\construction_bay\application\config/construct-data.php
INFO - 2017-11-14 13:54:24 --> Helper loaded: url_helper
INFO - 2017-11-14 13:54:24 --> Helper loaded: form_helper
INFO - 2017-11-14 13:54:24 --> Helper loaded: date_helper
INFO - 2017-11-14 13:54:24 --> Helper loaded: util_helper
INFO - 2017-11-14 13:54:24 --> Helper loaded: text_helper
INFO - 2017-11-14 13:54:24 --> Helper loaded: string_helper
INFO - 2017-11-14 13:54:24 --> Database Driver Class Initialized
DEBUG - 2017-11-14 13:54:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-14 13:54:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-14 13:54:24 --> Email Class Initialized
INFO - 2017-11-14 13:54:24 --> Controller Class Initialized
INFO - 2017-11-14 13:54:24 --> Model Class Initialized
DEBUG - 2017-11-14 13:54:24 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_model.php
INFO - 2017-11-14 13:54:24 --> Model Class Initialized
DEBUG - 2017-11-14 13:54:24 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_functions_model.php
INFO - 2017-11-14 13:54:24 --> Model Class Initialized
DEBUG - 2017-11-14 13:54:24 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header_menu.php
DEBUG - 2017-11-14 13:54:24 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\companies/companies_header.php
DEBUG - 2017-11-14 13:54:24 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\companies/companies_page.php
DEBUG - 2017-11-14 13:54:24 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\companies/companies_footer.php
INFO - 2017-11-14 13:54:24 --> Final output sent to browser
DEBUG - 2017-11-14 13:54:24 --> Total execution time: 0.0920
INFO - 2017-11-14 13:54:25 --> Config Class Initialized
INFO - 2017-11-14 13:54:25 --> Hooks Class Initialized
DEBUG - 2017-11-14 13:54:25 --> UTF-8 Support Enabled
INFO - 2017-11-14 13:54:25 --> Utf8 Class Initialized
INFO - 2017-11-14 13:54:25 --> URI Class Initialized
INFO - 2017-11-14 13:54:25 --> Router Class Initialized
INFO - 2017-11-14 13:54:25 --> Output Class Initialized
INFO - 2017-11-14 13:54:25 --> Security Class Initialized
DEBUG - 2017-11-14 13:54:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 13:54:25 --> Input Class Initialized
INFO - 2017-11-14 13:54:25 --> Language Class Initialized
INFO - 2017-11-14 13:54:25 --> Language Class Initialized
INFO - 2017-11-14 13:54:25 --> Config Class Initialized
INFO - 2017-11-14 13:54:25 --> Loader Class Initialized
DEBUG - 2017-11-14 13:54:25 --> Config file loaded: D:\xampp\htdocs\construction_bay\application\config/construct-data.php
INFO - 2017-11-14 13:54:25 --> Helper loaded: url_helper
INFO - 2017-11-14 13:54:25 --> Helper loaded: form_helper
INFO - 2017-11-14 13:54:25 --> Helper loaded: date_helper
INFO - 2017-11-14 13:54:25 --> Helper loaded: util_helper
INFO - 2017-11-14 13:54:25 --> Helper loaded: text_helper
INFO - 2017-11-14 13:54:25 --> Helper loaded: string_helper
INFO - 2017-11-14 13:54:25 --> Database Driver Class Initialized
DEBUG - 2017-11-14 13:54:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-14 13:54:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-14 13:54:25 --> Email Class Initialized
INFO - 2017-11-14 13:54:25 --> Controller Class Initialized
INFO - 2017-11-14 13:54:25 --> Model Class Initialized
DEBUG - 2017-11-14 13:54:25 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_model.php
INFO - 2017-11-14 13:54:25 --> Model Class Initialized
DEBUG - 2017-11-14 13:54:25 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_functions_model.php
INFO - 2017-11-14 13:54:25 --> Model Class Initialized
DEBUG - 2017-11-14 13:54:25 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/template.php
INFO - 2017-11-14 13:55:33 --> Config Class Initialized
INFO - 2017-11-14 13:55:33 --> Hooks Class Initialized
DEBUG - 2017-11-14 13:55:33 --> UTF-8 Support Enabled
INFO - 2017-11-14 13:55:33 --> Utf8 Class Initialized
INFO - 2017-11-14 13:55:33 --> URI Class Initialized
INFO - 2017-11-14 13:55:33 --> Router Class Initialized
INFO - 2017-11-14 13:55:33 --> Output Class Initialized
INFO - 2017-11-14 13:55:33 --> Security Class Initialized
DEBUG - 2017-11-14 13:55:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 13:55:33 --> Input Class Initialized
INFO - 2017-11-14 13:55:33 --> Language Class Initialized
INFO - 2017-11-14 13:55:33 --> Language Class Initialized
INFO - 2017-11-14 13:55:33 --> Config Class Initialized
INFO - 2017-11-14 13:55:33 --> Loader Class Initialized
DEBUG - 2017-11-14 13:55:33 --> Config file loaded: D:\xampp\htdocs\construction_bay\application\config/construct-data.php
INFO - 2017-11-14 13:55:33 --> Helper loaded: url_helper
INFO - 2017-11-14 13:55:33 --> Helper loaded: form_helper
INFO - 2017-11-14 13:55:33 --> Helper loaded: date_helper
INFO - 2017-11-14 13:55:33 --> Helper loaded: util_helper
INFO - 2017-11-14 13:55:33 --> Helper loaded: text_helper
INFO - 2017-11-14 13:55:33 --> Helper loaded: string_helper
INFO - 2017-11-14 13:55:33 --> Database Driver Class Initialized
DEBUG - 2017-11-14 13:55:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-14 13:55:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-14 13:55:33 --> Email Class Initialized
INFO - 2017-11-14 13:55:33 --> Controller Class Initialized
INFO - 2017-11-14 13:55:33 --> Model Class Initialized
DEBUG - 2017-11-14 13:55:33 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_model.php
INFO - 2017-11-14 13:55:33 --> Model Class Initialized
DEBUG - 2017-11-14 13:55:33 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_functions_model.php
INFO - 2017-11-14 13:55:33 --> Model Class Initialized
DEBUG - 2017-11-14 13:55:33 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header_menu.php
DEBUG - 2017-11-14 13:55:33 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\companies/companies_header.php
DEBUG - 2017-11-14 13:55:33 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\companies/companies_page.php
DEBUG - 2017-11-14 13:55:33 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\companies/companies_footer.php
INFO - 2017-11-14 13:55:33 --> Final output sent to browser
DEBUG - 2017-11-14 13:55:33 --> Total execution time: 0.0830
INFO - 2017-11-14 13:55:35 --> Config Class Initialized
INFO - 2017-11-14 13:55:35 --> Hooks Class Initialized
DEBUG - 2017-11-14 13:55:35 --> UTF-8 Support Enabled
INFO - 2017-11-14 13:55:35 --> Utf8 Class Initialized
INFO - 2017-11-14 13:55:35 --> URI Class Initialized
INFO - 2017-11-14 13:55:35 --> Router Class Initialized
INFO - 2017-11-14 13:55:35 --> Output Class Initialized
INFO - 2017-11-14 13:55:35 --> Security Class Initialized
DEBUG - 2017-11-14 13:55:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 13:55:35 --> Input Class Initialized
INFO - 2017-11-14 13:55:35 --> Language Class Initialized
INFO - 2017-11-14 13:55:35 --> Language Class Initialized
INFO - 2017-11-14 13:55:35 --> Config Class Initialized
INFO - 2017-11-14 13:55:35 --> Loader Class Initialized
DEBUG - 2017-11-14 13:55:35 --> Config file loaded: D:\xampp\htdocs\construction_bay\application\config/construct-data.php
INFO - 2017-11-14 13:55:35 --> Helper loaded: url_helper
INFO - 2017-11-14 13:55:35 --> Helper loaded: form_helper
INFO - 2017-11-14 13:55:35 --> Helper loaded: date_helper
INFO - 2017-11-14 13:55:35 --> Helper loaded: util_helper
INFO - 2017-11-14 13:55:35 --> Helper loaded: text_helper
INFO - 2017-11-14 13:55:35 --> Helper loaded: string_helper
INFO - 2017-11-14 13:55:35 --> Database Driver Class Initialized
DEBUG - 2017-11-14 13:55:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-14 13:55:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-14 13:55:35 --> Email Class Initialized
INFO - 2017-11-14 13:55:35 --> Controller Class Initialized
INFO - 2017-11-14 13:55:35 --> Model Class Initialized
DEBUG - 2017-11-14 13:55:35 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_model.php
INFO - 2017-11-14 13:55:35 --> Model Class Initialized
DEBUG - 2017-11-14 13:55:35 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_functions_model.php
INFO - 2017-11-14 13:55:35 --> Model Class Initialized
DEBUG - 2017-11-14 13:55:35 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/template.php
INFO - 2017-11-14 13:55:48 --> Config Class Initialized
INFO - 2017-11-14 13:55:48 --> Hooks Class Initialized
DEBUG - 2017-11-14 13:55:48 --> UTF-8 Support Enabled
INFO - 2017-11-14 13:55:48 --> Utf8 Class Initialized
INFO - 2017-11-14 13:55:48 --> URI Class Initialized
INFO - 2017-11-14 13:55:48 --> Router Class Initialized
INFO - 2017-11-14 13:55:48 --> Output Class Initialized
INFO - 2017-11-14 13:55:48 --> Security Class Initialized
DEBUG - 2017-11-14 13:55:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 13:55:48 --> Input Class Initialized
INFO - 2017-11-14 13:55:48 --> Language Class Initialized
INFO - 2017-11-14 13:55:48 --> Language Class Initialized
INFO - 2017-11-14 13:55:48 --> Config Class Initialized
INFO - 2017-11-14 13:55:48 --> Loader Class Initialized
DEBUG - 2017-11-14 13:55:48 --> Config file loaded: D:\xampp\htdocs\construction_bay\application\config/construct-data.php
INFO - 2017-11-14 13:55:48 --> Helper loaded: url_helper
INFO - 2017-11-14 13:55:48 --> Helper loaded: form_helper
INFO - 2017-11-14 13:55:48 --> Helper loaded: date_helper
INFO - 2017-11-14 13:55:48 --> Helper loaded: util_helper
INFO - 2017-11-14 13:55:48 --> Helper loaded: text_helper
INFO - 2017-11-14 13:55:48 --> Helper loaded: string_helper
INFO - 2017-11-14 13:55:48 --> Database Driver Class Initialized
DEBUG - 2017-11-14 13:55:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-14 13:55:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-14 13:55:48 --> Email Class Initialized
INFO - 2017-11-14 13:55:48 --> Controller Class Initialized
INFO - 2017-11-14 13:55:48 --> Model Class Initialized
DEBUG - 2017-11-14 13:55:48 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_model.php
INFO - 2017-11-14 13:55:48 --> Model Class Initialized
DEBUG - 2017-11-14 13:55:48 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_functions_model.php
INFO - 2017-11-14 13:55:48 --> Model Class Initialized
DEBUG - 2017-11-14 13:55:48 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header_menu.php
DEBUG - 2017-11-14 13:55:48 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\companies/companies_header.php
DEBUG - 2017-11-14 13:55:48 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\companies/companies_page.php
DEBUG - 2017-11-14 13:55:48 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\companies/companies_footer.php
INFO - 2017-11-14 13:55:48 --> Final output sent to browser
DEBUG - 2017-11-14 13:55:48 --> Total execution time: 0.0700
INFO - 2017-11-14 13:55:49 --> Config Class Initialized
INFO - 2017-11-14 13:55:49 --> Hooks Class Initialized
DEBUG - 2017-11-14 13:55:49 --> UTF-8 Support Enabled
INFO - 2017-11-14 13:55:49 --> Utf8 Class Initialized
INFO - 2017-11-14 13:55:49 --> URI Class Initialized
INFO - 2017-11-14 13:55:49 --> Router Class Initialized
INFO - 2017-11-14 13:55:49 --> Output Class Initialized
INFO - 2017-11-14 13:55:49 --> Security Class Initialized
DEBUG - 2017-11-14 13:55:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 13:55:49 --> Input Class Initialized
INFO - 2017-11-14 13:55:49 --> Language Class Initialized
INFO - 2017-11-14 13:55:49 --> Language Class Initialized
INFO - 2017-11-14 13:55:49 --> Config Class Initialized
INFO - 2017-11-14 13:55:49 --> Loader Class Initialized
DEBUG - 2017-11-14 13:55:49 --> Config file loaded: D:\xampp\htdocs\construction_bay\application\config/construct-data.php
INFO - 2017-11-14 13:55:49 --> Helper loaded: url_helper
INFO - 2017-11-14 13:55:49 --> Helper loaded: form_helper
INFO - 2017-11-14 13:55:49 --> Helper loaded: date_helper
INFO - 2017-11-14 13:55:49 --> Helper loaded: util_helper
INFO - 2017-11-14 13:55:49 --> Helper loaded: text_helper
INFO - 2017-11-14 13:55:49 --> Helper loaded: string_helper
INFO - 2017-11-14 13:55:49 --> Database Driver Class Initialized
DEBUG - 2017-11-14 13:55:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-14 13:55:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-14 13:55:49 --> Email Class Initialized
INFO - 2017-11-14 13:55:49 --> Controller Class Initialized
INFO - 2017-11-14 13:55:49 --> Model Class Initialized
DEBUG - 2017-11-14 13:55:49 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_model.php
INFO - 2017-11-14 13:55:49 --> Model Class Initialized
DEBUG - 2017-11-14 13:55:49 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_functions_model.php
INFO - 2017-11-14 13:55:49 --> Model Class Initialized
DEBUG - 2017-11-14 13:55:49 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/template.php
INFO - 2017-11-14 14:12:20 --> Config Class Initialized
INFO - 2017-11-14 14:12:20 --> Hooks Class Initialized
DEBUG - 2017-11-14 14:12:20 --> UTF-8 Support Enabled
INFO - 2017-11-14 14:12:20 --> Utf8 Class Initialized
INFO - 2017-11-14 14:12:20 --> URI Class Initialized
INFO - 2017-11-14 14:12:20 --> Router Class Initialized
INFO - 2017-11-14 14:12:20 --> Output Class Initialized
INFO - 2017-11-14 14:12:20 --> Security Class Initialized
DEBUG - 2017-11-14 14:12:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 14:12:20 --> Input Class Initialized
INFO - 2017-11-14 14:12:20 --> Language Class Initialized
INFO - 2017-11-14 14:12:20 --> Language Class Initialized
INFO - 2017-11-14 14:12:20 --> Config Class Initialized
INFO - 2017-11-14 14:12:20 --> Loader Class Initialized
DEBUG - 2017-11-14 14:12:20 --> Config file loaded: D:\xampp\htdocs\construction_bay\application\config/construct-data.php
INFO - 2017-11-14 14:12:20 --> Helper loaded: url_helper
INFO - 2017-11-14 14:12:20 --> Helper loaded: form_helper
INFO - 2017-11-14 14:12:20 --> Helper loaded: date_helper
INFO - 2017-11-14 14:12:20 --> Helper loaded: util_helper
INFO - 2017-11-14 14:12:20 --> Helper loaded: text_helper
INFO - 2017-11-14 14:12:20 --> Helper loaded: string_helper
INFO - 2017-11-14 14:12:20 --> Database Driver Class Initialized
DEBUG - 2017-11-14 14:12:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-14 14:12:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-14 14:12:20 --> Email Class Initialized
INFO - 2017-11-14 14:12:20 --> Controller Class Initialized
INFO - 2017-11-14 14:12:20 --> Model Class Initialized
DEBUG - 2017-11-14 14:12:20 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_model.php
INFO - 2017-11-14 14:12:20 --> Model Class Initialized
DEBUG - 2017-11-14 14:12:20 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_functions_model.php
INFO - 2017-11-14 14:12:20 --> Model Class Initialized
DEBUG - 2017-11-14 14:12:20 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header_menu.php
DEBUG - 2017-11-14 14:12:20 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\companies/companies_header.php
DEBUG - 2017-11-14 14:12:20 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\companies/companies_page.php
DEBUG - 2017-11-14 14:12:20 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\companies/companies_footer.php
INFO - 2017-11-14 14:12:20 --> Final output sent to browser
DEBUG - 2017-11-14 14:12:20 --> Total execution time: 0.0840
INFO - 2017-11-14 14:12:22 --> Config Class Initialized
INFO - 2017-11-14 14:12:22 --> Hooks Class Initialized
DEBUG - 2017-11-14 14:12:22 --> UTF-8 Support Enabled
INFO - 2017-11-14 14:12:22 --> Utf8 Class Initialized
INFO - 2017-11-14 14:12:22 --> URI Class Initialized
INFO - 2017-11-14 14:12:22 --> Router Class Initialized
INFO - 2017-11-14 14:12:22 --> Output Class Initialized
INFO - 2017-11-14 14:12:22 --> Security Class Initialized
DEBUG - 2017-11-14 14:12:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 14:12:22 --> Input Class Initialized
INFO - 2017-11-14 14:12:22 --> Language Class Initialized
INFO - 2017-11-14 14:12:22 --> Language Class Initialized
INFO - 2017-11-14 14:12:22 --> Config Class Initialized
INFO - 2017-11-14 14:12:22 --> Loader Class Initialized
DEBUG - 2017-11-14 14:12:22 --> Config file loaded: D:\xampp\htdocs\construction_bay\application\config/construct-data.php
INFO - 2017-11-14 14:12:22 --> Helper loaded: url_helper
INFO - 2017-11-14 14:12:22 --> Helper loaded: form_helper
INFO - 2017-11-14 14:12:22 --> Helper loaded: date_helper
INFO - 2017-11-14 14:12:22 --> Helper loaded: util_helper
INFO - 2017-11-14 14:12:22 --> Helper loaded: text_helper
INFO - 2017-11-14 14:12:22 --> Helper loaded: string_helper
INFO - 2017-11-14 14:12:22 --> Database Driver Class Initialized
DEBUG - 2017-11-14 14:12:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-14 14:12:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-14 14:12:22 --> Email Class Initialized
INFO - 2017-11-14 14:12:22 --> Controller Class Initialized
INFO - 2017-11-14 14:12:22 --> Model Class Initialized
DEBUG - 2017-11-14 14:12:22 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_model.php
INFO - 2017-11-14 14:12:22 --> Model Class Initialized
DEBUG - 2017-11-14 14:12:22 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_functions_model.php
INFO - 2017-11-14 14:12:22 --> Model Class Initialized
DEBUG - 2017-11-14 14:12:22 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/template.php
INFO - 2017-11-14 14:19:59 --> Config Class Initialized
INFO - 2017-11-14 14:19:59 --> Hooks Class Initialized
DEBUG - 2017-11-14 14:19:59 --> UTF-8 Support Enabled
INFO - 2017-11-14 14:19:59 --> Utf8 Class Initialized
INFO - 2017-11-14 14:19:59 --> URI Class Initialized
INFO - 2017-11-14 14:19:59 --> Router Class Initialized
INFO - 2017-11-14 14:19:59 --> Output Class Initialized
INFO - 2017-11-14 14:19:59 --> Security Class Initialized
DEBUG - 2017-11-14 14:19:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 14:19:59 --> Input Class Initialized
INFO - 2017-11-14 14:19:59 --> Language Class Initialized
INFO - 2017-11-14 14:19:59 --> Language Class Initialized
INFO - 2017-11-14 14:19:59 --> Config Class Initialized
INFO - 2017-11-14 14:19:59 --> Loader Class Initialized
DEBUG - 2017-11-14 14:19:59 --> Config file loaded: D:\xampp\htdocs\construction_bay\application\config/construct-data.php
INFO - 2017-11-14 14:19:59 --> Helper loaded: url_helper
INFO - 2017-11-14 14:19:59 --> Helper loaded: form_helper
INFO - 2017-11-14 14:19:59 --> Helper loaded: date_helper
INFO - 2017-11-14 14:19:59 --> Helper loaded: util_helper
INFO - 2017-11-14 14:19:59 --> Helper loaded: text_helper
INFO - 2017-11-14 14:19:59 --> Helper loaded: string_helper
INFO - 2017-11-14 14:19:59 --> Database Driver Class Initialized
DEBUG - 2017-11-14 14:19:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-14 14:19:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-14 14:19:59 --> Email Class Initialized
INFO - 2017-11-14 14:19:59 --> Controller Class Initialized
INFO - 2017-11-14 14:19:59 --> Model Class Initialized
DEBUG - 2017-11-14 14:19:59 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_model.php
INFO - 2017-11-14 14:19:59 --> Model Class Initialized
DEBUG - 2017-11-14 14:19:59 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_functions_model.php
INFO - 2017-11-14 14:19:59 --> Model Class Initialized
DEBUG - 2017-11-14 14:19:59 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/template.php
INFO - 2017-11-14 14:24:40 --> Config Class Initialized
INFO - 2017-11-14 14:24:40 --> Hooks Class Initialized
DEBUG - 2017-11-14 14:24:40 --> UTF-8 Support Enabled
INFO - 2017-11-14 14:24:40 --> Utf8 Class Initialized
INFO - 2017-11-14 14:24:40 --> URI Class Initialized
INFO - 2017-11-14 14:24:40 --> Router Class Initialized
INFO - 2017-11-14 14:24:40 --> Output Class Initialized
INFO - 2017-11-14 14:24:40 --> Security Class Initialized
DEBUG - 2017-11-14 14:24:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 14:24:40 --> Input Class Initialized
INFO - 2017-11-14 14:24:40 --> Language Class Initialized
INFO - 2017-11-14 14:24:40 --> Language Class Initialized
INFO - 2017-11-14 14:24:40 --> Config Class Initialized
INFO - 2017-11-14 14:24:40 --> Loader Class Initialized
DEBUG - 2017-11-14 14:24:40 --> Config file loaded: D:\xampp\htdocs\construction_bay\application\config/construct-data.php
INFO - 2017-11-14 14:24:40 --> Helper loaded: url_helper
INFO - 2017-11-14 14:24:40 --> Helper loaded: form_helper
INFO - 2017-11-14 14:24:40 --> Helper loaded: date_helper
INFO - 2017-11-14 14:24:40 --> Helper loaded: util_helper
INFO - 2017-11-14 14:24:40 --> Helper loaded: text_helper
INFO - 2017-11-14 14:24:40 --> Helper loaded: string_helper
INFO - 2017-11-14 14:24:40 --> Database Driver Class Initialized
DEBUG - 2017-11-14 14:24:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-14 14:24:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-14 14:24:40 --> Email Class Initialized
INFO - 2017-11-14 14:24:40 --> Controller Class Initialized
INFO - 2017-11-14 14:24:40 --> Model Class Initialized
DEBUG - 2017-11-14 14:24:40 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_model.php
INFO - 2017-11-14 14:24:40 --> Model Class Initialized
DEBUG - 2017-11-14 14:24:40 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_functions_model.php
INFO - 2017-11-14 14:24:40 --> Model Class Initialized
DEBUG - 2017-11-14 14:24:40 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/template.php
INFO - 2017-11-14 14:24:42 --> Config Class Initialized
INFO - 2017-11-14 14:24:42 --> Hooks Class Initialized
DEBUG - 2017-11-14 14:24:42 --> UTF-8 Support Enabled
INFO - 2017-11-14 14:24:42 --> Utf8 Class Initialized
INFO - 2017-11-14 14:24:42 --> URI Class Initialized
INFO - 2017-11-14 14:24:42 --> Router Class Initialized
INFO - 2017-11-14 14:24:42 --> Output Class Initialized
INFO - 2017-11-14 14:24:42 --> Security Class Initialized
DEBUG - 2017-11-14 14:24:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 14:24:42 --> Input Class Initialized
INFO - 2017-11-14 14:24:42 --> Language Class Initialized
INFO - 2017-11-14 14:24:42 --> Language Class Initialized
INFO - 2017-11-14 14:24:42 --> Config Class Initialized
INFO - 2017-11-14 14:24:42 --> Loader Class Initialized
DEBUG - 2017-11-14 14:24:42 --> Config file loaded: D:\xampp\htdocs\construction_bay\application\config/construct-data.php
INFO - 2017-11-14 14:24:42 --> Helper loaded: url_helper
INFO - 2017-11-14 14:24:42 --> Helper loaded: form_helper
INFO - 2017-11-14 14:24:42 --> Helper loaded: date_helper
INFO - 2017-11-14 14:24:42 --> Helper loaded: util_helper
INFO - 2017-11-14 14:24:42 --> Helper loaded: text_helper
INFO - 2017-11-14 14:24:42 --> Helper loaded: string_helper
INFO - 2017-11-14 14:24:42 --> Database Driver Class Initialized
DEBUG - 2017-11-14 14:24:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-14 14:24:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-14 14:24:42 --> Email Class Initialized
INFO - 2017-11-14 14:24:42 --> Controller Class Initialized
INFO - 2017-11-14 14:24:42 --> Model Class Initialized
DEBUG - 2017-11-14 14:24:42 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_model.php
INFO - 2017-11-14 14:24:42 --> Model Class Initialized
DEBUG - 2017-11-14 14:24:42 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_functions_model.php
INFO - 2017-11-14 14:24:42 --> Model Class Initialized
DEBUG - 2017-11-14 14:24:42 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/template.php
INFO - 2017-11-14 14:24:44 --> Config Class Initialized
INFO - 2017-11-14 14:24:44 --> Hooks Class Initialized
DEBUG - 2017-11-14 14:24:44 --> UTF-8 Support Enabled
INFO - 2017-11-14 14:24:44 --> Utf8 Class Initialized
INFO - 2017-11-14 14:24:44 --> URI Class Initialized
INFO - 2017-11-14 14:24:44 --> Router Class Initialized
INFO - 2017-11-14 14:24:44 --> Output Class Initialized
INFO - 2017-11-14 14:24:44 --> Security Class Initialized
DEBUG - 2017-11-14 14:24:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 14:24:44 --> Input Class Initialized
INFO - 2017-11-14 14:24:44 --> Language Class Initialized
INFO - 2017-11-14 14:24:44 --> Language Class Initialized
INFO - 2017-11-14 14:24:44 --> Config Class Initialized
INFO - 2017-11-14 14:24:44 --> Loader Class Initialized
DEBUG - 2017-11-14 14:24:44 --> Config file loaded: D:\xampp\htdocs\construction_bay\application\config/construct-data.php
INFO - 2017-11-14 14:24:44 --> Helper loaded: url_helper
INFO - 2017-11-14 14:24:44 --> Helper loaded: form_helper
INFO - 2017-11-14 14:24:44 --> Helper loaded: date_helper
INFO - 2017-11-14 14:24:44 --> Helper loaded: util_helper
INFO - 2017-11-14 14:24:44 --> Helper loaded: text_helper
INFO - 2017-11-14 14:24:44 --> Helper loaded: string_helper
INFO - 2017-11-14 14:24:44 --> Database Driver Class Initialized
DEBUG - 2017-11-14 14:24:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-14 14:24:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-14 14:24:44 --> Email Class Initialized
INFO - 2017-11-14 14:24:44 --> Controller Class Initialized
INFO - 2017-11-14 14:24:44 --> Model Class Initialized
DEBUG - 2017-11-14 14:24:44 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_model.php
INFO - 2017-11-14 14:24:44 --> Model Class Initialized
DEBUG - 2017-11-14 14:24:44 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_functions_model.php
INFO - 2017-11-14 14:24:44 --> Model Class Initialized
DEBUG - 2017-11-14 14:24:45 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/template.php
INFO - 2017-11-14 14:29:27 --> Config Class Initialized
INFO - 2017-11-14 14:29:27 --> Hooks Class Initialized
DEBUG - 2017-11-14 14:29:27 --> UTF-8 Support Enabled
INFO - 2017-11-14 14:29:27 --> Utf8 Class Initialized
INFO - 2017-11-14 14:29:27 --> URI Class Initialized
INFO - 2017-11-14 14:29:27 --> Router Class Initialized
INFO - 2017-11-14 14:29:27 --> Output Class Initialized
INFO - 2017-11-14 14:29:27 --> Security Class Initialized
DEBUG - 2017-11-14 14:29:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 14:29:27 --> Input Class Initialized
INFO - 2017-11-14 14:29:27 --> Language Class Initialized
INFO - 2017-11-14 14:29:27 --> Language Class Initialized
INFO - 2017-11-14 14:29:27 --> Config Class Initialized
INFO - 2017-11-14 14:29:27 --> Loader Class Initialized
DEBUG - 2017-11-14 14:29:27 --> Config file loaded: D:\xampp\htdocs\construction_bay\application\config/construct-data.php
INFO - 2017-11-14 14:29:27 --> Helper loaded: url_helper
INFO - 2017-11-14 14:29:27 --> Helper loaded: form_helper
INFO - 2017-11-14 14:29:27 --> Helper loaded: date_helper
INFO - 2017-11-14 14:29:27 --> Helper loaded: util_helper
INFO - 2017-11-14 14:29:27 --> Helper loaded: text_helper
INFO - 2017-11-14 14:29:27 --> Helper loaded: string_helper
INFO - 2017-11-14 14:29:27 --> Database Driver Class Initialized
DEBUG - 2017-11-14 14:29:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-14 14:29:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-14 14:29:27 --> Email Class Initialized
INFO - 2017-11-14 14:29:27 --> Controller Class Initialized
INFO - 2017-11-14 14:29:27 --> Model Class Initialized
DEBUG - 2017-11-14 14:29:27 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_model.php
INFO - 2017-11-14 14:29:27 --> Model Class Initialized
DEBUG - 2017-11-14 14:29:27 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_functions_model.php
INFO - 2017-11-14 14:29:27 --> Model Class Initialized
ERROR - 2017-11-14 14:29:27 --> Severity: Notice --> Undefined variable: category D:\xampp\htdocs\construction_bay\application\views\common\header_menu.php 150
DEBUG - 2017-11-14 14:29:27 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header_menu.php
DEBUG - 2017-11-14 14:29:27 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header.php
DEBUG - 2017-11-14 14:29:27 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\microsite.php
DEBUG - 2017-11-14 14:29:27 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/footer.php
INFO - 2017-11-14 14:29:27 --> Final output sent to browser
DEBUG - 2017-11-14 14:29:27 --> Total execution time: 0.1380
INFO - 2017-11-14 14:29:29 --> Config Class Initialized
INFO - 2017-11-14 14:29:29 --> Hooks Class Initialized
DEBUG - 2017-11-14 14:29:29 --> UTF-8 Support Enabled
INFO - 2017-11-14 14:29:29 --> Utf8 Class Initialized
INFO - 2017-11-14 14:29:29 --> URI Class Initialized
INFO - 2017-11-14 14:29:29 --> Router Class Initialized
INFO - 2017-11-14 14:29:29 --> Output Class Initialized
INFO - 2017-11-14 14:29:29 --> Security Class Initialized
DEBUG - 2017-11-14 14:29:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 14:29:29 --> Input Class Initialized
INFO - 2017-11-14 14:29:29 --> Language Class Initialized
INFO - 2017-11-14 14:29:29 --> Language Class Initialized
INFO - 2017-11-14 14:29:29 --> Config Class Initialized
INFO - 2017-11-14 14:29:29 --> Loader Class Initialized
DEBUG - 2017-11-14 14:29:29 --> Config file loaded: D:\xampp\htdocs\construction_bay\application\config/construct-data.php
INFO - 2017-11-14 14:29:29 --> Helper loaded: url_helper
INFO - 2017-11-14 14:29:29 --> Helper loaded: form_helper
INFO - 2017-11-14 14:29:29 --> Helper loaded: date_helper
INFO - 2017-11-14 14:29:29 --> Helper loaded: util_helper
INFO - 2017-11-14 14:29:29 --> Helper loaded: text_helper
INFO - 2017-11-14 14:29:29 --> Helper loaded: string_helper
INFO - 2017-11-14 14:29:29 --> Database Driver Class Initialized
DEBUG - 2017-11-14 14:29:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-14 14:29:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-14 14:29:29 --> Email Class Initialized
INFO - 2017-11-14 14:29:29 --> Controller Class Initialized
INFO - 2017-11-14 14:29:29 --> Model Class Initialized
DEBUG - 2017-11-14 14:29:29 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_model.php
INFO - 2017-11-14 14:29:29 --> Model Class Initialized
DEBUG - 2017-11-14 14:29:29 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_functions_model.php
INFO - 2017-11-14 14:29:29 --> Model Class Initialized
ERROR - 2017-11-14 14:29:29 --> Severity: Notice --> Undefined variable: category D:\xampp\htdocs\construction_bay\application\views\common\header_menu.php 150
DEBUG - 2017-11-14 14:29:29 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header_menu.php
DEBUG - 2017-11-14 14:29:29 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header.php
DEBUG - 2017-11-14 14:29:29 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\microsite.php
DEBUG - 2017-11-14 14:29:29 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/footer.php
INFO - 2017-11-14 14:29:29 --> Final output sent to browser
DEBUG - 2017-11-14 14:29:29 --> Total execution time: 0.0790
INFO - 2017-11-14 14:29:30 --> Config Class Initialized
INFO - 2017-11-14 14:29:30 --> Hooks Class Initialized
DEBUG - 2017-11-14 14:29:30 --> UTF-8 Support Enabled
INFO - 2017-11-14 14:29:30 --> Utf8 Class Initialized
INFO - 2017-11-14 14:29:30 --> URI Class Initialized
INFO - 2017-11-14 14:29:30 --> Router Class Initialized
INFO - 2017-11-14 14:29:30 --> Output Class Initialized
INFO - 2017-11-14 14:29:30 --> Security Class Initialized
DEBUG - 2017-11-14 14:29:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 14:29:30 --> Input Class Initialized
INFO - 2017-11-14 14:29:30 --> Language Class Initialized
INFO - 2017-11-14 14:29:30 --> Language Class Initialized
INFO - 2017-11-14 14:29:30 --> Config Class Initialized
INFO - 2017-11-14 14:29:30 --> Loader Class Initialized
DEBUG - 2017-11-14 14:29:30 --> Config file loaded: D:\xampp\htdocs\construction_bay\application\config/construct-data.php
INFO - 2017-11-14 14:29:30 --> Helper loaded: url_helper
INFO - 2017-11-14 14:29:30 --> Helper loaded: form_helper
INFO - 2017-11-14 14:29:30 --> Helper loaded: date_helper
INFO - 2017-11-14 14:29:30 --> Helper loaded: util_helper
INFO - 2017-11-14 14:29:30 --> Helper loaded: text_helper
INFO - 2017-11-14 14:29:30 --> Helper loaded: string_helper
INFO - 2017-11-14 14:29:30 --> Database Driver Class Initialized
DEBUG - 2017-11-14 14:29:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-14 14:29:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-14 14:29:30 --> Email Class Initialized
INFO - 2017-11-14 14:29:30 --> Controller Class Initialized
INFO - 2017-11-14 14:29:30 --> Model Class Initialized
DEBUG - 2017-11-14 14:29:30 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_model.php
INFO - 2017-11-14 14:29:30 --> Model Class Initialized
DEBUG - 2017-11-14 14:29:30 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_functions_model.php
INFO - 2017-11-14 14:29:30 --> Model Class Initialized
DEBUG - 2017-11-14 14:29:30 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header_menu.php
DEBUG - 2017-11-14 14:29:30 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\companies/companies_header.php
DEBUG - 2017-11-14 14:29:30 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\companies/companies_page.php
DEBUG - 2017-11-14 14:29:30 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\companies/companies_footer.php
INFO - 2017-11-14 14:29:30 --> Final output sent to browser
DEBUG - 2017-11-14 14:29:30 --> Total execution time: 0.0820
INFO - 2017-11-14 14:29:31 --> Config Class Initialized
INFO - 2017-11-14 14:29:31 --> Hooks Class Initialized
DEBUG - 2017-11-14 14:29:31 --> UTF-8 Support Enabled
INFO - 2017-11-14 14:29:31 --> Utf8 Class Initialized
INFO - 2017-11-14 14:29:31 --> URI Class Initialized
INFO - 2017-11-14 14:29:31 --> Router Class Initialized
INFO - 2017-11-14 14:29:31 --> Output Class Initialized
INFO - 2017-11-14 14:29:31 --> Security Class Initialized
DEBUG - 2017-11-14 14:29:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 14:29:31 --> Input Class Initialized
INFO - 2017-11-14 14:29:31 --> Language Class Initialized
INFO - 2017-11-14 14:29:31 --> Language Class Initialized
INFO - 2017-11-14 14:29:31 --> Config Class Initialized
INFO - 2017-11-14 14:29:31 --> Loader Class Initialized
DEBUG - 2017-11-14 14:29:31 --> Config file loaded: D:\xampp\htdocs\construction_bay\application\config/construct-data.php
INFO - 2017-11-14 14:29:31 --> Helper loaded: url_helper
INFO - 2017-11-14 14:29:31 --> Helper loaded: form_helper
INFO - 2017-11-14 14:29:31 --> Helper loaded: date_helper
INFO - 2017-11-14 14:29:31 --> Helper loaded: util_helper
INFO - 2017-11-14 14:29:31 --> Helper loaded: text_helper
INFO - 2017-11-14 14:29:31 --> Helper loaded: string_helper
INFO - 2017-11-14 14:29:31 --> Database Driver Class Initialized
DEBUG - 2017-11-14 14:29:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-14 14:29:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-14 14:29:31 --> Email Class Initialized
INFO - 2017-11-14 14:29:31 --> Controller Class Initialized
INFO - 2017-11-14 14:29:31 --> Model Class Initialized
DEBUG - 2017-11-14 14:29:31 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_model.php
INFO - 2017-11-14 14:29:31 --> Model Class Initialized
DEBUG - 2017-11-14 14:29:31 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_functions_model.php
INFO - 2017-11-14 14:29:31 --> Model Class Initialized
DEBUG - 2017-11-14 14:29:31 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/template.php
INFO - 2017-11-14 14:47:18 --> Config Class Initialized
INFO - 2017-11-14 14:47:18 --> Hooks Class Initialized
DEBUG - 2017-11-14 14:47:18 --> UTF-8 Support Enabled
INFO - 2017-11-14 14:47:18 --> Utf8 Class Initialized
INFO - 2017-11-14 14:47:18 --> URI Class Initialized
INFO - 2017-11-14 14:47:18 --> Router Class Initialized
INFO - 2017-11-14 14:47:18 --> Output Class Initialized
INFO - 2017-11-14 14:47:18 --> Security Class Initialized
DEBUG - 2017-11-14 14:47:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 14:47:18 --> Input Class Initialized
INFO - 2017-11-14 14:47:18 --> Language Class Initialized
INFO - 2017-11-14 14:47:18 --> Language Class Initialized
INFO - 2017-11-14 14:47:18 --> Config Class Initialized
INFO - 2017-11-14 14:47:18 --> Loader Class Initialized
DEBUG - 2017-11-14 14:47:18 --> Config file loaded: D:\xampp\htdocs\construction_bay\application\config/construct-data.php
INFO - 2017-11-14 14:47:18 --> Helper loaded: url_helper
INFO - 2017-11-14 14:47:18 --> Helper loaded: form_helper
INFO - 2017-11-14 14:47:18 --> Helper loaded: date_helper
INFO - 2017-11-14 14:47:18 --> Helper loaded: util_helper
INFO - 2017-11-14 14:47:18 --> Helper loaded: text_helper
INFO - 2017-11-14 14:47:18 --> Helper loaded: string_helper
INFO - 2017-11-14 14:47:18 --> Database Driver Class Initialized
DEBUG - 2017-11-14 14:47:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-14 14:47:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-14 14:47:18 --> Email Class Initialized
INFO - 2017-11-14 14:47:18 --> Controller Class Initialized
INFO - 2017-11-14 14:47:18 --> Model Class Initialized
DEBUG - 2017-11-14 14:47:18 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_model.php
INFO - 2017-11-14 14:47:18 --> Model Class Initialized
DEBUG - 2017-11-14 14:47:18 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_functions_model.php
INFO - 2017-11-14 14:47:18 --> Model Class Initialized
ERROR - 2017-11-14 14:47:18 --> Severity: Notice --> Undefined variable: category D:\xampp\htdocs\construction_bay\application\views\common\header_menu.php 150
DEBUG - 2017-11-14 14:47:18 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header_menu.php
DEBUG - 2017-11-14 14:47:18 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header.php
DEBUG - 2017-11-14 14:47:18 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\products-services.php
DEBUG - 2017-11-14 14:47:18 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/footer.php
INFO - 2017-11-14 14:47:18 --> Final output sent to browser
DEBUG - 2017-11-14 14:47:18 --> Total execution time: 0.0710
INFO - 2017-11-14 14:49:07 --> Config Class Initialized
INFO - 2017-11-14 14:49:07 --> Hooks Class Initialized
DEBUG - 2017-11-14 14:49:07 --> UTF-8 Support Enabled
INFO - 2017-11-14 14:49:07 --> Utf8 Class Initialized
INFO - 2017-11-14 14:49:07 --> URI Class Initialized
INFO - 2017-11-14 14:49:07 --> Router Class Initialized
INFO - 2017-11-14 14:49:07 --> Output Class Initialized
INFO - 2017-11-14 14:49:07 --> Security Class Initialized
DEBUG - 2017-11-14 14:49:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 14:49:07 --> Input Class Initialized
INFO - 2017-11-14 14:49:07 --> Language Class Initialized
INFO - 2017-11-14 14:49:07 --> Language Class Initialized
INFO - 2017-11-14 14:49:07 --> Config Class Initialized
INFO - 2017-11-14 14:49:07 --> Loader Class Initialized
DEBUG - 2017-11-14 14:49:07 --> Config file loaded: D:\xampp\htdocs\construction_bay\application\config/construct-data.php
INFO - 2017-11-14 14:49:07 --> Helper loaded: url_helper
INFO - 2017-11-14 14:49:07 --> Helper loaded: form_helper
INFO - 2017-11-14 14:49:07 --> Helper loaded: date_helper
INFO - 2017-11-14 14:49:07 --> Helper loaded: util_helper
INFO - 2017-11-14 14:49:07 --> Helper loaded: text_helper
INFO - 2017-11-14 14:49:07 --> Helper loaded: string_helper
INFO - 2017-11-14 14:49:07 --> Database Driver Class Initialized
DEBUG - 2017-11-14 14:49:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-14 14:49:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-14 14:49:07 --> Email Class Initialized
INFO - 2017-11-14 14:49:07 --> Controller Class Initialized
INFO - 2017-11-14 14:49:07 --> Model Class Initialized
DEBUG - 2017-11-14 14:49:07 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_model.php
INFO - 2017-11-14 14:49:07 --> Model Class Initialized
DEBUG - 2017-11-14 14:49:07 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_functions_model.php
INFO - 2017-11-14 14:49:07 --> Model Class Initialized
DEBUG - 2017-11-14 14:49:07 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header_menu.php
DEBUG - 2017-11-14 14:49:07 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\companies/companies_header.php
DEBUG - 2017-11-14 14:49:07 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\companies/companies_page.php
DEBUG - 2017-11-14 14:49:07 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\companies/companies_footer.php
INFO - 2017-11-14 14:49:07 --> Final output sent to browser
DEBUG - 2017-11-14 14:49:07 --> Total execution time: 0.3170
INFO - 2017-11-14 14:49:09 --> Config Class Initialized
INFO - 2017-11-14 14:49:09 --> Hooks Class Initialized
DEBUG - 2017-11-14 14:49:09 --> UTF-8 Support Enabled
INFO - 2017-11-14 14:49:09 --> Utf8 Class Initialized
INFO - 2017-11-14 14:49:09 --> URI Class Initialized
INFO - 2017-11-14 14:49:09 --> Router Class Initialized
INFO - 2017-11-14 14:49:09 --> Output Class Initialized
INFO - 2017-11-14 14:49:09 --> Security Class Initialized
DEBUG - 2017-11-14 14:49:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 14:49:09 --> Input Class Initialized
INFO - 2017-11-14 14:49:09 --> Language Class Initialized
INFO - 2017-11-14 14:49:09 --> Language Class Initialized
INFO - 2017-11-14 14:49:09 --> Config Class Initialized
INFO - 2017-11-14 14:49:09 --> Loader Class Initialized
DEBUG - 2017-11-14 14:49:09 --> Config file loaded: D:\xampp\htdocs\construction_bay\application\config/construct-data.php
INFO - 2017-11-14 14:49:09 --> Helper loaded: url_helper
INFO - 2017-11-14 14:49:09 --> Helper loaded: form_helper
INFO - 2017-11-14 14:49:09 --> Helper loaded: date_helper
INFO - 2017-11-14 14:49:09 --> Helper loaded: util_helper
INFO - 2017-11-14 14:49:09 --> Helper loaded: text_helper
INFO - 2017-11-14 14:49:09 --> Helper loaded: string_helper
INFO - 2017-11-14 14:49:09 --> Database Driver Class Initialized
DEBUG - 2017-11-14 14:49:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-14 14:49:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-14 14:49:09 --> Email Class Initialized
INFO - 2017-11-14 14:49:09 --> Controller Class Initialized
INFO - 2017-11-14 14:49:09 --> Model Class Initialized
DEBUG - 2017-11-14 14:49:09 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_model.php
INFO - 2017-11-14 14:49:09 --> Model Class Initialized
DEBUG - 2017-11-14 14:49:09 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_functions_model.php
INFO - 2017-11-14 14:49:09 --> Model Class Initialized
DEBUG - 2017-11-14 14:49:09 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/template.php
INFO - 2017-11-14 14:49:10 --> Config Class Initialized
INFO - 2017-11-14 14:49:10 --> Hooks Class Initialized
DEBUG - 2017-11-14 14:49:10 --> UTF-8 Support Enabled
INFO - 2017-11-14 14:49:10 --> Utf8 Class Initialized
INFO - 2017-11-14 14:49:10 --> URI Class Initialized
INFO - 2017-11-14 14:49:10 --> Router Class Initialized
INFO - 2017-11-14 14:49:10 --> Output Class Initialized
INFO - 2017-11-14 14:49:10 --> Security Class Initialized
DEBUG - 2017-11-14 14:49:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 14:49:10 --> Input Class Initialized
INFO - 2017-11-14 14:49:10 --> Language Class Initialized
INFO - 2017-11-14 14:49:10 --> Language Class Initialized
INFO - 2017-11-14 14:49:10 --> Config Class Initialized
INFO - 2017-11-14 14:49:10 --> Loader Class Initialized
DEBUG - 2017-11-14 14:49:10 --> Config file loaded: D:\xampp\htdocs\construction_bay\application\config/construct-data.php
INFO - 2017-11-14 14:49:11 --> Helper loaded: url_helper
INFO - 2017-11-14 14:49:11 --> Helper loaded: form_helper
INFO - 2017-11-14 14:49:11 --> Helper loaded: date_helper
INFO - 2017-11-14 14:49:11 --> Helper loaded: util_helper
INFO - 2017-11-14 14:49:11 --> Helper loaded: text_helper
INFO - 2017-11-14 14:49:11 --> Helper loaded: string_helper
INFO - 2017-11-14 14:49:11 --> Database Driver Class Initialized
DEBUG - 2017-11-14 14:49:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-14 14:49:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-14 14:49:11 --> Email Class Initialized
INFO - 2017-11-14 14:49:11 --> Controller Class Initialized
INFO - 2017-11-14 14:49:11 --> Model Class Initialized
DEBUG - 2017-11-14 14:49:11 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_model.php
INFO - 2017-11-14 14:49:11 --> Model Class Initialized
DEBUG - 2017-11-14 14:49:11 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_functions_model.php
INFO - 2017-11-14 14:49:11 --> Model Class Initialized
ERROR - 2017-11-14 14:49:11 --> Severity: Notice --> Undefined variable: category D:\xampp\htdocs\construction_bay\application\views\common\header_menu.php 150
DEBUG - 2017-11-14 14:49:11 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header_menu.php
DEBUG - 2017-11-14 14:49:11 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header.php
DEBUG - 2017-11-14 14:49:11 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\products-services.php
DEBUG - 2017-11-14 14:49:11 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/footer.php
INFO - 2017-11-14 14:49:11 --> Final output sent to browser
DEBUG - 2017-11-14 14:49:11 --> Total execution time: 0.0500
INFO - 2017-11-14 14:51:44 --> Config Class Initialized
INFO - 2017-11-14 14:51:44 --> Hooks Class Initialized
DEBUG - 2017-11-14 14:51:44 --> UTF-8 Support Enabled
INFO - 2017-11-14 14:51:44 --> Utf8 Class Initialized
INFO - 2017-11-14 14:51:44 --> URI Class Initialized
INFO - 2017-11-14 14:51:44 --> Router Class Initialized
INFO - 2017-11-14 14:51:44 --> Output Class Initialized
INFO - 2017-11-14 14:51:44 --> Security Class Initialized
DEBUG - 2017-11-14 14:51:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 14:51:44 --> Input Class Initialized
INFO - 2017-11-14 14:51:44 --> Language Class Initialized
INFO - 2017-11-14 14:51:44 --> Language Class Initialized
INFO - 2017-11-14 14:51:44 --> Config Class Initialized
INFO - 2017-11-14 14:51:44 --> Loader Class Initialized
DEBUG - 2017-11-14 14:51:44 --> Config file loaded: D:\xampp\htdocs\construction_bay\application\config/construct-data.php
INFO - 2017-11-14 14:51:44 --> Helper loaded: url_helper
INFO - 2017-11-14 14:51:44 --> Helper loaded: form_helper
INFO - 2017-11-14 14:51:44 --> Helper loaded: date_helper
INFO - 2017-11-14 14:51:44 --> Helper loaded: util_helper
INFO - 2017-11-14 14:51:44 --> Helper loaded: text_helper
INFO - 2017-11-14 14:51:44 --> Helper loaded: string_helper
INFO - 2017-11-14 14:51:44 --> Database Driver Class Initialized
DEBUG - 2017-11-14 14:51:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-14 14:51:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-14 14:51:44 --> Email Class Initialized
INFO - 2017-11-14 14:51:44 --> Controller Class Initialized
ERROR - 2017-11-14 14:51:44 --> Severity: Notice --> Undefined variable: category D:\xampp\htdocs\construction_bay\application\views\common\header_menu.php 150
DEBUG - 2017-11-14 14:51:44 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header_menu.php
DEBUG - 2017-11-14 14:51:44 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header.php
DEBUG - 2017-11-14 14:51:44 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\contact.php
DEBUG - 2017-11-14 14:51:44 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/footer.php
INFO - 2017-11-14 14:51:44 --> Final output sent to browser
DEBUG - 2017-11-14 14:51:44 --> Total execution time: 0.0760
INFO - 2017-11-14 14:51:46 --> Config Class Initialized
INFO - 2017-11-14 14:51:46 --> Hooks Class Initialized
DEBUG - 2017-11-14 14:51:46 --> UTF-8 Support Enabled
INFO - 2017-11-14 14:51:46 --> Utf8 Class Initialized
INFO - 2017-11-14 14:51:46 --> URI Class Initialized
INFO - 2017-11-14 14:51:46 --> Router Class Initialized
INFO - 2017-11-14 14:51:46 --> Output Class Initialized
INFO - 2017-11-14 14:51:46 --> Security Class Initialized
DEBUG - 2017-11-14 14:51:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 14:51:46 --> Input Class Initialized
INFO - 2017-11-14 14:51:46 --> Language Class Initialized
ERROR - 2017-11-14 14:51:46 --> 404 Page Not Found: /index
INFO - 2017-11-14 14:55:51 --> Config Class Initialized
INFO - 2017-11-14 14:55:51 --> Hooks Class Initialized
DEBUG - 2017-11-14 14:55:51 --> UTF-8 Support Enabled
INFO - 2017-11-14 14:55:51 --> Utf8 Class Initialized
INFO - 2017-11-14 14:55:51 --> URI Class Initialized
INFO - 2017-11-14 14:55:51 --> Router Class Initialized
INFO - 2017-11-14 14:55:51 --> Output Class Initialized
INFO - 2017-11-14 14:55:51 --> Security Class Initialized
DEBUG - 2017-11-14 14:55:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 14:55:51 --> Input Class Initialized
INFO - 2017-11-14 14:55:51 --> Language Class Initialized
INFO - 2017-11-14 14:55:51 --> Language Class Initialized
INFO - 2017-11-14 14:55:51 --> Config Class Initialized
INFO - 2017-11-14 14:55:51 --> Loader Class Initialized
DEBUG - 2017-11-14 14:55:51 --> Config file loaded: D:\xampp\htdocs\construction_bay\application\config/construct-data.php
INFO - 2017-11-14 14:55:51 --> Helper loaded: url_helper
INFO - 2017-11-14 14:55:51 --> Helper loaded: form_helper
INFO - 2017-11-14 14:55:51 --> Helper loaded: date_helper
INFO - 2017-11-14 14:55:51 --> Helper loaded: util_helper
INFO - 2017-11-14 14:55:51 --> Helper loaded: text_helper
INFO - 2017-11-14 14:55:51 --> Helper loaded: string_helper
INFO - 2017-11-14 14:55:51 --> Database Driver Class Initialized
DEBUG - 2017-11-14 14:55:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-14 14:55:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-14 14:55:51 --> Email Class Initialized
INFO - 2017-11-14 14:55:51 --> Controller Class Initialized
ERROR - 2017-11-14 14:55:51 --> Severity: Error --> Call to undefined method MX_Config::get_item() D:\xampp\htdocs\construction_bay\application\views\common\header_menu.php 150
INFO - 2017-11-14 14:55:57 --> Config Class Initialized
INFO - 2017-11-14 14:55:57 --> Hooks Class Initialized
DEBUG - 2017-11-14 14:55:57 --> UTF-8 Support Enabled
INFO - 2017-11-14 14:55:57 --> Utf8 Class Initialized
INFO - 2017-11-14 14:55:57 --> URI Class Initialized
INFO - 2017-11-14 14:55:57 --> Router Class Initialized
INFO - 2017-11-14 14:55:57 --> Output Class Initialized
INFO - 2017-11-14 14:55:57 --> Security Class Initialized
DEBUG - 2017-11-14 14:55:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 14:55:57 --> Input Class Initialized
INFO - 2017-11-14 14:55:57 --> Language Class Initialized
INFO - 2017-11-14 14:55:57 --> Language Class Initialized
INFO - 2017-11-14 14:55:57 --> Config Class Initialized
INFO - 2017-11-14 14:55:57 --> Loader Class Initialized
DEBUG - 2017-11-14 14:55:57 --> Config file loaded: D:\xampp\htdocs\construction_bay\application\config/construct-data.php
INFO - 2017-11-14 14:55:57 --> Helper loaded: url_helper
INFO - 2017-11-14 14:55:57 --> Helper loaded: form_helper
INFO - 2017-11-14 14:55:57 --> Helper loaded: date_helper
INFO - 2017-11-14 14:55:57 --> Helper loaded: util_helper
INFO - 2017-11-14 14:55:57 --> Helper loaded: text_helper
INFO - 2017-11-14 14:55:57 --> Helper loaded: string_helper
INFO - 2017-11-14 14:55:57 --> Database Driver Class Initialized
DEBUG - 2017-11-14 14:55:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-14 14:55:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-14 14:55:57 --> Email Class Initialized
INFO - 2017-11-14 14:55:57 --> Controller Class Initialized
ERROR - 2017-11-14 14:55:57 --> Severity: Error --> Call to undefined method MX_Config::get_item() D:\xampp\htdocs\construction_bay\application\views\common\header_menu.php 150
INFO - 2017-11-14 14:57:59 --> Config Class Initialized
INFO - 2017-11-14 14:57:59 --> Hooks Class Initialized
DEBUG - 2017-11-14 14:57:59 --> UTF-8 Support Enabled
INFO - 2017-11-14 14:57:59 --> Utf8 Class Initialized
INFO - 2017-11-14 14:57:59 --> URI Class Initialized
INFO - 2017-11-14 14:57:59 --> Router Class Initialized
INFO - 2017-11-14 14:57:59 --> Output Class Initialized
INFO - 2017-11-14 14:57:59 --> Security Class Initialized
DEBUG - 2017-11-14 14:57:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 14:57:59 --> Input Class Initialized
INFO - 2017-11-14 14:57:59 --> Language Class Initialized
INFO - 2017-11-14 14:57:59 --> Language Class Initialized
INFO - 2017-11-14 14:57:59 --> Config Class Initialized
INFO - 2017-11-14 14:57:59 --> Loader Class Initialized
DEBUG - 2017-11-14 14:57:59 --> Config file loaded: D:\xampp\htdocs\construction_bay\application\config/construct-data.php
INFO - 2017-11-14 14:57:59 --> Helper loaded: url_helper
INFO - 2017-11-14 14:57:59 --> Helper loaded: form_helper
INFO - 2017-11-14 14:57:59 --> Helper loaded: date_helper
INFO - 2017-11-14 14:57:59 --> Helper loaded: util_helper
INFO - 2017-11-14 14:57:59 --> Helper loaded: text_helper
INFO - 2017-11-14 14:57:59 --> Helper loaded: string_helper
INFO - 2017-11-14 14:57:59 --> Database Driver Class Initialized
DEBUG - 2017-11-14 14:57:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-14 14:57:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-14 14:57:59 --> Email Class Initialized
INFO - 2017-11-14 14:57:59 --> Controller Class Initialized
DEBUG - 2017-11-14 14:57:59 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header_menu.php
DEBUG - 2017-11-14 14:57:59 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header.php
DEBUG - 2017-11-14 14:57:59 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\contact.php
DEBUG - 2017-11-14 14:57:59 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/footer.php
INFO - 2017-11-14 14:57:59 --> Final output sent to browser
DEBUG - 2017-11-14 14:57:59 --> Total execution time: 0.0560
INFO - 2017-11-14 14:58:03 --> Config Class Initialized
INFO - 2017-11-14 14:58:03 --> Hooks Class Initialized
DEBUG - 2017-11-14 14:58:03 --> UTF-8 Support Enabled
INFO - 2017-11-14 14:58:03 --> Utf8 Class Initialized
INFO - 2017-11-14 14:58:03 --> URI Class Initialized
INFO - 2017-11-14 14:58:03 --> Router Class Initialized
INFO - 2017-11-14 14:58:03 --> Output Class Initialized
INFO - 2017-11-14 14:58:03 --> Security Class Initialized
DEBUG - 2017-11-14 14:58:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 14:58:03 --> Input Class Initialized
INFO - 2017-11-14 14:58:03 --> Language Class Initialized
INFO - 2017-11-14 14:58:03 --> Language Class Initialized
INFO - 2017-11-14 14:58:03 --> Config Class Initialized
INFO - 2017-11-14 14:58:03 --> Loader Class Initialized
DEBUG - 2017-11-14 14:58:03 --> Config file loaded: D:\xampp\htdocs\construction_bay\application\config/construct-data.php
INFO - 2017-11-14 14:58:03 --> Helper loaded: url_helper
INFO - 2017-11-14 14:58:03 --> Helper loaded: form_helper
INFO - 2017-11-14 14:58:03 --> Helper loaded: date_helper
INFO - 2017-11-14 14:58:03 --> Helper loaded: util_helper
INFO - 2017-11-14 14:58:03 --> Helper loaded: text_helper
INFO - 2017-11-14 14:58:03 --> Helper loaded: string_helper
INFO - 2017-11-14 14:58:03 --> Database Driver Class Initialized
DEBUG - 2017-11-14 14:58:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-14 14:58:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-14 14:58:03 --> Email Class Initialized
INFO - 2017-11-14 14:58:03 --> Controller Class Initialized
DEBUG - 2017-11-14 14:58:03 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header_menu.php
DEBUG - 2017-11-14 14:58:03 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header.php
DEBUG - 2017-11-14 14:58:03 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\contact.php
DEBUG - 2017-11-14 14:58:03 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/footer.php
INFO - 2017-11-14 14:58:03 --> Final output sent to browser
DEBUG - 2017-11-14 14:58:03 --> Total execution time: 0.0480
INFO - 2017-11-14 15:02:17 --> Config Class Initialized
INFO - 2017-11-14 15:02:17 --> Hooks Class Initialized
DEBUG - 2017-11-14 15:02:17 --> UTF-8 Support Enabled
INFO - 2017-11-14 15:02:17 --> Utf8 Class Initialized
INFO - 2017-11-14 15:02:17 --> URI Class Initialized
INFO - 2017-11-14 15:02:17 --> Router Class Initialized
INFO - 2017-11-14 15:02:17 --> Output Class Initialized
INFO - 2017-11-14 15:02:17 --> Security Class Initialized
DEBUG - 2017-11-14 15:02:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 15:02:17 --> Input Class Initialized
INFO - 2017-11-14 15:02:17 --> Language Class Initialized
INFO - 2017-11-14 15:02:17 --> Language Class Initialized
INFO - 2017-11-14 15:02:17 --> Config Class Initialized
INFO - 2017-11-14 15:02:17 --> Loader Class Initialized
DEBUG - 2017-11-14 15:02:17 --> Config file loaded: D:\xampp\htdocs\construction_bay\application\config/construct-data.php
INFO - 2017-11-14 15:02:17 --> Helper loaded: url_helper
INFO - 2017-11-14 15:02:17 --> Helper loaded: form_helper
INFO - 2017-11-14 15:02:17 --> Helper loaded: date_helper
INFO - 2017-11-14 15:02:17 --> Helper loaded: util_helper
INFO - 2017-11-14 15:02:17 --> Helper loaded: text_helper
INFO - 2017-11-14 15:02:17 --> Helper loaded: string_helper
INFO - 2017-11-14 15:02:17 --> Database Driver Class Initialized
DEBUG - 2017-11-14 15:02:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-14 15:02:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-14 15:02:17 --> Email Class Initialized
INFO - 2017-11-14 15:02:17 --> Controller Class Initialized
DEBUG - 2017-11-14 15:02:17 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header_menu.php
DEBUG - 2017-11-14 15:02:17 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header.php
DEBUG - 2017-11-14 15:02:17 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\contact.php
DEBUG - 2017-11-14 15:02:17 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/footer.php
INFO - 2017-11-14 15:02:17 --> Final output sent to browser
DEBUG - 2017-11-14 15:02:17 --> Total execution time: 0.0710
INFO - 2017-11-14 15:02:20 --> Config Class Initialized
INFO - 2017-11-14 15:02:20 --> Hooks Class Initialized
DEBUG - 2017-11-14 15:02:20 --> UTF-8 Support Enabled
INFO - 2017-11-14 15:02:20 --> Utf8 Class Initialized
INFO - 2017-11-14 15:02:20 --> URI Class Initialized
INFO - 2017-11-14 15:02:20 --> Router Class Initialized
INFO - 2017-11-14 15:02:20 --> Output Class Initialized
INFO - 2017-11-14 15:02:20 --> Security Class Initialized
DEBUG - 2017-11-14 15:02:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 15:02:20 --> Input Class Initialized
INFO - 2017-11-14 15:02:20 --> Language Class Initialized
INFO - 2017-11-14 15:02:20 --> Language Class Initialized
INFO - 2017-11-14 15:02:20 --> Config Class Initialized
INFO - 2017-11-14 15:02:20 --> Loader Class Initialized
DEBUG - 2017-11-14 15:02:20 --> Config file loaded: D:\xampp\htdocs\construction_bay\application\config/construct-data.php
INFO - 2017-11-14 15:02:20 --> Helper loaded: url_helper
INFO - 2017-11-14 15:02:20 --> Helper loaded: form_helper
INFO - 2017-11-14 15:02:20 --> Helper loaded: date_helper
INFO - 2017-11-14 15:02:20 --> Helper loaded: util_helper
INFO - 2017-11-14 15:02:20 --> Helper loaded: text_helper
INFO - 2017-11-14 15:02:20 --> Helper loaded: string_helper
INFO - 2017-11-14 15:02:20 --> Database Driver Class Initialized
DEBUG - 2017-11-14 15:02:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-14 15:02:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-14 15:02:20 --> Email Class Initialized
INFO - 2017-11-14 15:02:20 --> Controller Class Initialized
DEBUG - 2017-11-14 15:02:20 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header_menu.php
DEBUG - 2017-11-14 15:02:20 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header.php
DEBUG - 2017-11-14 15:02:20 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\about_us.php
DEBUG - 2017-11-14 15:02:20 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/footer.php
INFO - 2017-11-14 15:02:20 --> Final output sent to browser
DEBUG - 2017-11-14 15:02:20 --> Total execution time: 0.0690
INFO - 2017-11-14 15:07:51 --> Config Class Initialized
INFO - 2017-11-14 15:07:51 --> Hooks Class Initialized
DEBUG - 2017-11-14 15:07:51 --> UTF-8 Support Enabled
INFO - 2017-11-14 15:07:51 --> Utf8 Class Initialized
INFO - 2017-11-14 15:07:51 --> URI Class Initialized
INFO - 2017-11-14 15:07:51 --> Router Class Initialized
INFO - 2017-11-14 15:07:51 --> Output Class Initialized
INFO - 2017-11-14 15:07:51 --> Security Class Initialized
DEBUG - 2017-11-14 15:07:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 15:07:51 --> Input Class Initialized
INFO - 2017-11-14 15:07:51 --> Language Class Initialized
INFO - 2017-11-14 15:07:51 --> Language Class Initialized
INFO - 2017-11-14 15:07:51 --> Config Class Initialized
INFO - 2017-11-14 15:07:51 --> Loader Class Initialized
DEBUG - 2017-11-14 15:07:51 --> Config file loaded: D:\xampp\htdocs\construction_bay\application\config/construct-data.php
INFO - 2017-11-14 15:07:51 --> Helper loaded: url_helper
INFO - 2017-11-14 15:07:51 --> Helper loaded: form_helper
INFO - 2017-11-14 15:07:51 --> Helper loaded: date_helper
INFO - 2017-11-14 15:07:51 --> Helper loaded: util_helper
INFO - 2017-11-14 15:07:51 --> Helper loaded: text_helper
INFO - 2017-11-14 15:07:51 --> Helper loaded: string_helper
INFO - 2017-11-14 15:07:51 --> Database Driver Class Initialized
DEBUG - 2017-11-14 15:07:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-14 15:07:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-14 15:07:51 --> Email Class Initialized
INFO - 2017-11-14 15:07:51 --> Controller Class Initialized
DEBUG - 2017-11-14 15:07:51 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header_menu.php
DEBUG - 2017-11-14 15:07:51 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header.php
DEBUG - 2017-11-14 15:07:51 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\about_us.php
DEBUG - 2017-11-14 15:07:51 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/footer.php
INFO - 2017-11-14 15:07:51 --> Final output sent to browser
DEBUG - 2017-11-14 15:07:51 --> Total execution time: 0.0600
INFO - 2017-11-14 15:08:04 --> Config Class Initialized
INFO - 2017-11-14 15:08:04 --> Hooks Class Initialized
DEBUG - 2017-11-14 15:08:04 --> UTF-8 Support Enabled
INFO - 2017-11-14 15:08:04 --> Utf8 Class Initialized
INFO - 2017-11-14 15:08:04 --> URI Class Initialized
INFO - 2017-11-14 15:08:04 --> Router Class Initialized
INFO - 2017-11-14 15:08:04 --> Output Class Initialized
INFO - 2017-11-14 15:08:04 --> Security Class Initialized
DEBUG - 2017-11-14 15:08:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 15:08:04 --> Input Class Initialized
INFO - 2017-11-14 15:08:04 --> Language Class Initialized
INFO - 2017-11-14 15:08:04 --> Language Class Initialized
INFO - 2017-11-14 15:08:04 --> Config Class Initialized
INFO - 2017-11-14 15:08:04 --> Loader Class Initialized
DEBUG - 2017-11-14 15:08:04 --> Config file loaded: D:\xampp\htdocs\construction_bay\application\config/construct-data.php
INFO - 2017-11-14 15:08:04 --> Helper loaded: url_helper
INFO - 2017-11-14 15:08:04 --> Helper loaded: form_helper
INFO - 2017-11-14 15:08:04 --> Helper loaded: date_helper
INFO - 2017-11-14 15:08:04 --> Helper loaded: util_helper
INFO - 2017-11-14 15:08:04 --> Helper loaded: text_helper
INFO - 2017-11-14 15:08:04 --> Helper loaded: string_helper
INFO - 2017-11-14 15:08:04 --> Database Driver Class Initialized
DEBUG - 2017-11-14 15:08:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-14 15:08:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-14 15:08:04 --> Email Class Initialized
INFO - 2017-11-14 15:08:04 --> Controller Class Initialized
DEBUG - 2017-11-14 15:08:04 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header_menu.php
DEBUG - 2017-11-14 15:08:04 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header.php
DEBUG - 2017-11-14 15:08:04 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\about_us.php
DEBUG - 2017-11-14 15:08:04 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/footer.php
INFO - 2017-11-14 15:08:04 --> Final output sent to browser
DEBUG - 2017-11-14 15:08:04 --> Total execution time: 0.0520
INFO - 2017-11-14 15:08:23 --> Config Class Initialized
INFO - 2017-11-14 15:08:23 --> Hooks Class Initialized
DEBUG - 2017-11-14 15:08:23 --> UTF-8 Support Enabled
INFO - 2017-11-14 15:08:23 --> Utf8 Class Initialized
INFO - 2017-11-14 15:08:23 --> URI Class Initialized
INFO - 2017-11-14 15:08:23 --> Router Class Initialized
INFO - 2017-11-14 15:08:23 --> Output Class Initialized
INFO - 2017-11-14 15:08:23 --> Security Class Initialized
DEBUG - 2017-11-14 15:08:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 15:08:23 --> Input Class Initialized
INFO - 2017-11-14 15:08:23 --> Language Class Initialized
INFO - 2017-11-14 15:08:23 --> Language Class Initialized
INFO - 2017-11-14 15:08:23 --> Config Class Initialized
INFO - 2017-11-14 15:08:23 --> Loader Class Initialized
DEBUG - 2017-11-14 15:08:23 --> Config file loaded: D:\xampp\htdocs\construction_bay\application\config/construct-data.php
INFO - 2017-11-14 15:08:23 --> Helper loaded: url_helper
INFO - 2017-11-14 15:08:23 --> Helper loaded: form_helper
INFO - 2017-11-14 15:08:23 --> Helper loaded: date_helper
INFO - 2017-11-14 15:08:23 --> Helper loaded: util_helper
INFO - 2017-11-14 15:08:23 --> Helper loaded: text_helper
INFO - 2017-11-14 15:08:23 --> Helper loaded: string_helper
INFO - 2017-11-14 15:08:23 --> Database Driver Class Initialized
DEBUG - 2017-11-14 15:08:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-14 15:08:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-14 15:08:23 --> Email Class Initialized
INFO - 2017-11-14 15:08:23 --> Controller Class Initialized
DEBUG - 2017-11-14 15:08:23 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header_menu.php
DEBUG - 2017-11-14 15:08:23 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header.php
DEBUG - 2017-11-14 15:08:23 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\about_us.php
DEBUG - 2017-11-14 15:08:23 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/footer.php
INFO - 2017-11-14 15:08:23 --> Final output sent to browser
DEBUG - 2017-11-14 15:08:23 --> Total execution time: 0.0860
INFO - 2017-11-14 15:18:27 --> Config Class Initialized
INFO - 2017-11-14 15:18:27 --> Hooks Class Initialized
DEBUG - 2017-11-14 15:18:27 --> UTF-8 Support Enabled
INFO - 2017-11-14 15:18:27 --> Utf8 Class Initialized
INFO - 2017-11-14 15:18:27 --> URI Class Initialized
DEBUG - 2017-11-14 15:18:27 --> No URI present. Default controller set.
INFO - 2017-11-14 15:18:27 --> Router Class Initialized
INFO - 2017-11-14 15:18:27 --> Output Class Initialized
INFO - 2017-11-14 15:18:27 --> Security Class Initialized
DEBUG - 2017-11-14 15:18:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 15:18:27 --> Input Class Initialized
INFO - 2017-11-14 15:18:27 --> Language Class Initialized
INFO - 2017-11-14 15:18:27 --> Language Class Initialized
INFO - 2017-11-14 15:18:27 --> Config Class Initialized
INFO - 2017-11-14 15:18:27 --> Loader Class Initialized
DEBUG - 2017-11-14 15:18:27 --> Config file loaded: D:\xampp\htdocs\construction_bay\application\config/construct-data.php
INFO - 2017-11-14 15:18:27 --> Helper loaded: url_helper
INFO - 2017-11-14 15:18:27 --> Helper loaded: form_helper
INFO - 2017-11-14 15:18:27 --> Helper loaded: date_helper
INFO - 2017-11-14 15:18:27 --> Helper loaded: util_helper
INFO - 2017-11-14 15:18:27 --> Helper loaded: text_helper
INFO - 2017-11-14 15:18:27 --> Helper loaded: string_helper
INFO - 2017-11-14 15:18:27 --> Database Driver Class Initialized
DEBUG - 2017-11-14 15:18:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-14 15:18:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-14 15:18:27 --> Email Class Initialized
INFO - 2017-11-14 15:18:27 --> Controller Class Initialized
DEBUG - 2017-11-14 15:18:27 --> Home MX_Controller Initialized
INFO - 2017-11-14 15:18:27 --> Model Class Initialized
DEBUG - 2017-11-14 15:18:27 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_model.php
INFO - 2017-11-14 15:18:27 --> Model Class Initialized
DEBUG - 2017-11-14 15:18:27 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header_menu.php
DEBUG - 2017-11-14 15:18:27 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header.php
DEBUG - 2017-11-14 15:18:27 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/slider.php
DEBUG - 2017-11-14 15:18:27 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/index_body.php
DEBUG - 2017-11-14 15:18:27 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/index_footer.php
INFO - 2017-11-14 15:18:27 --> Final output sent to browser
DEBUG - 2017-11-14 15:18:27 --> Total execution time: 0.1100
INFO - 2017-11-14 15:18:49 --> Config Class Initialized
INFO - 2017-11-14 15:18:49 --> Hooks Class Initialized
DEBUG - 2017-11-14 15:18:49 --> UTF-8 Support Enabled
INFO - 2017-11-14 15:18:49 --> Utf8 Class Initialized
INFO - 2017-11-14 15:18:49 --> URI Class Initialized
INFO - 2017-11-14 15:18:49 --> Router Class Initialized
INFO - 2017-11-14 15:18:49 --> Output Class Initialized
INFO - 2017-11-14 15:18:49 --> Security Class Initialized
DEBUG - 2017-11-14 15:18:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 15:18:49 --> Input Class Initialized
INFO - 2017-11-14 15:18:49 --> Language Class Initialized
INFO - 2017-11-14 15:18:49 --> Language Class Initialized
INFO - 2017-11-14 15:18:49 --> Config Class Initialized
INFO - 2017-11-14 15:18:49 --> Loader Class Initialized
DEBUG - 2017-11-14 15:18:49 --> Config file loaded: D:\xampp\htdocs\construction_bay\application\config/construct-data.php
INFO - 2017-11-14 15:18:49 --> Helper loaded: url_helper
INFO - 2017-11-14 15:18:49 --> Helper loaded: form_helper
INFO - 2017-11-14 15:18:49 --> Helper loaded: date_helper
INFO - 2017-11-14 15:18:49 --> Helper loaded: util_helper
INFO - 2017-11-14 15:18:49 --> Helper loaded: text_helper
INFO - 2017-11-14 15:18:49 --> Helper loaded: string_helper
INFO - 2017-11-14 15:18:49 --> Database Driver Class Initialized
DEBUG - 2017-11-14 15:18:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-14 15:18:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-14 15:18:49 --> Email Class Initialized
INFO - 2017-11-14 15:18:49 --> Controller Class Initialized
DEBUG - 2017-11-14 15:18:49 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header_menu.php
DEBUG - 2017-11-14 15:18:49 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header.php
DEBUG - 2017-11-14 15:18:49 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\contact.php
DEBUG - 2017-11-14 15:18:49 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/footer.php
INFO - 2017-11-14 15:18:49 --> Final output sent to browser
DEBUG - 2017-11-14 15:18:49 --> Total execution time: 0.1120
INFO - 2017-11-14 15:20:54 --> Config Class Initialized
INFO - 2017-11-14 15:20:54 --> Hooks Class Initialized
DEBUG - 2017-11-14 15:20:54 --> UTF-8 Support Enabled
INFO - 2017-11-14 15:20:54 --> Utf8 Class Initialized
INFO - 2017-11-14 15:20:54 --> URI Class Initialized
INFO - 2017-11-14 15:20:54 --> Router Class Initialized
INFO - 2017-11-14 15:20:54 --> Output Class Initialized
INFO - 2017-11-14 15:20:54 --> Security Class Initialized
DEBUG - 2017-11-14 15:20:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 15:20:54 --> Input Class Initialized
INFO - 2017-11-14 15:20:54 --> Language Class Initialized
INFO - 2017-11-14 15:20:54 --> Language Class Initialized
INFO - 2017-11-14 15:20:54 --> Config Class Initialized
INFO - 2017-11-14 15:20:54 --> Loader Class Initialized
DEBUG - 2017-11-14 15:20:54 --> Config file loaded: D:\xampp\htdocs\construction_bay\application\config/construct-data.php
INFO - 2017-11-14 15:20:54 --> Helper loaded: url_helper
INFO - 2017-11-14 15:20:54 --> Helper loaded: form_helper
INFO - 2017-11-14 15:20:54 --> Helper loaded: date_helper
INFO - 2017-11-14 15:20:54 --> Helper loaded: util_helper
INFO - 2017-11-14 15:20:54 --> Helper loaded: text_helper
INFO - 2017-11-14 15:20:54 --> Helper loaded: string_helper
INFO - 2017-11-14 15:20:54 --> Database Driver Class Initialized
DEBUG - 2017-11-14 15:20:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-14 15:20:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-14 15:20:54 --> Email Class Initialized
INFO - 2017-11-14 15:20:54 --> Controller Class Initialized
DEBUG - 2017-11-14 15:20:54 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header_menu.php
DEBUG - 2017-11-14 15:20:54 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header.php
DEBUG - 2017-11-14 15:20:54 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\contact.php
DEBUG - 2017-11-14 15:20:54 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/footer.php
INFO - 2017-11-14 15:20:54 --> Final output sent to browser
DEBUG - 2017-11-14 15:20:54 --> Total execution time: 0.0580
INFO - 2017-11-14 15:22:15 --> Config Class Initialized
INFO - 2017-11-14 15:22:15 --> Hooks Class Initialized
DEBUG - 2017-11-14 15:22:15 --> UTF-8 Support Enabled
INFO - 2017-11-14 15:22:15 --> Utf8 Class Initialized
INFO - 2017-11-14 15:22:15 --> URI Class Initialized
INFO - 2017-11-14 15:22:15 --> Router Class Initialized
INFO - 2017-11-14 15:22:15 --> Output Class Initialized
INFO - 2017-11-14 15:22:15 --> Security Class Initialized
DEBUG - 2017-11-14 15:22:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 15:22:15 --> Input Class Initialized
INFO - 2017-11-14 15:22:15 --> Language Class Initialized
INFO - 2017-11-14 15:22:15 --> Language Class Initialized
INFO - 2017-11-14 15:22:15 --> Config Class Initialized
INFO - 2017-11-14 15:22:15 --> Loader Class Initialized
DEBUG - 2017-11-14 15:22:15 --> Config file loaded: D:\xampp\htdocs\construction_bay\application\config/construct-data.php
INFO - 2017-11-14 15:22:15 --> Helper loaded: url_helper
INFO - 2017-11-14 15:22:15 --> Helper loaded: form_helper
INFO - 2017-11-14 15:22:15 --> Helper loaded: date_helper
INFO - 2017-11-14 15:22:15 --> Helper loaded: util_helper
INFO - 2017-11-14 15:22:15 --> Helper loaded: text_helper
INFO - 2017-11-14 15:22:15 --> Helper loaded: string_helper
INFO - 2017-11-14 15:22:15 --> Database Driver Class Initialized
DEBUG - 2017-11-14 15:22:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-14 15:22:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-14 15:22:15 --> Email Class Initialized
INFO - 2017-11-14 15:22:15 --> Controller Class Initialized
DEBUG - 2017-11-14 15:22:15 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header_menu.php
DEBUG - 2017-11-14 15:22:15 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header.php
DEBUG - 2017-11-14 15:22:15 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\contact.php
DEBUG - 2017-11-14 15:22:15 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/footer.php
INFO - 2017-11-14 15:22:15 --> Final output sent to browser
DEBUG - 2017-11-14 15:22:15 --> Total execution time: 0.0510
INFO - 2017-11-14 15:23:05 --> Config Class Initialized
INFO - 2017-11-14 15:23:05 --> Hooks Class Initialized
DEBUG - 2017-11-14 15:23:05 --> UTF-8 Support Enabled
INFO - 2017-11-14 15:23:05 --> Utf8 Class Initialized
INFO - 2017-11-14 15:23:05 --> URI Class Initialized
INFO - 2017-11-14 15:23:05 --> Router Class Initialized
INFO - 2017-11-14 15:23:05 --> Output Class Initialized
INFO - 2017-11-14 15:23:05 --> Security Class Initialized
DEBUG - 2017-11-14 15:23:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 15:23:05 --> Input Class Initialized
INFO - 2017-11-14 15:23:05 --> Language Class Initialized
INFO - 2017-11-14 15:23:05 --> Language Class Initialized
INFO - 2017-11-14 15:23:05 --> Config Class Initialized
INFO - 2017-11-14 15:23:05 --> Loader Class Initialized
DEBUG - 2017-11-14 15:23:05 --> Config file loaded: D:\xampp\htdocs\construction_bay\application\config/construct-data.php
INFO - 2017-11-14 15:23:05 --> Helper loaded: url_helper
INFO - 2017-11-14 15:23:05 --> Helper loaded: form_helper
INFO - 2017-11-14 15:23:05 --> Helper loaded: date_helper
INFO - 2017-11-14 15:23:05 --> Helper loaded: util_helper
INFO - 2017-11-14 15:23:05 --> Helper loaded: text_helper
INFO - 2017-11-14 15:23:05 --> Helper loaded: string_helper
INFO - 2017-11-14 15:23:05 --> Database Driver Class Initialized
DEBUG - 2017-11-14 15:23:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-14 15:23:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-14 15:23:05 --> Email Class Initialized
INFO - 2017-11-14 15:23:05 --> Controller Class Initialized
DEBUG - 2017-11-14 15:23:05 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header_menu.php
DEBUG - 2017-11-14 15:23:05 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header.php
DEBUG - 2017-11-14 15:23:05 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\contact.php
DEBUG - 2017-11-14 15:23:05 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/footer.php
INFO - 2017-11-14 15:23:05 --> Final output sent to browser
DEBUG - 2017-11-14 15:23:05 --> Total execution time: 0.0630
INFO - 2017-11-14 15:23:08 --> Config Class Initialized
INFO - 2017-11-14 15:23:08 --> Hooks Class Initialized
DEBUG - 2017-11-14 15:23:08 --> UTF-8 Support Enabled
INFO - 2017-11-14 15:23:08 --> Utf8 Class Initialized
INFO - 2017-11-14 15:23:08 --> URI Class Initialized
INFO - 2017-11-14 15:23:08 --> Router Class Initialized
INFO - 2017-11-14 15:23:08 --> Output Class Initialized
INFO - 2017-11-14 15:23:08 --> Security Class Initialized
DEBUG - 2017-11-14 15:23:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 15:23:08 --> Input Class Initialized
INFO - 2017-11-14 15:23:08 --> Language Class Initialized
INFO - 2017-11-14 15:23:08 --> Language Class Initialized
INFO - 2017-11-14 15:23:08 --> Config Class Initialized
INFO - 2017-11-14 15:23:08 --> Loader Class Initialized
DEBUG - 2017-11-14 15:23:08 --> Config file loaded: D:\xampp\htdocs\construction_bay\application\config/construct-data.php
INFO - 2017-11-14 15:23:08 --> Helper loaded: url_helper
INFO - 2017-11-14 15:23:08 --> Helper loaded: form_helper
INFO - 2017-11-14 15:23:08 --> Helper loaded: date_helper
INFO - 2017-11-14 15:23:08 --> Helper loaded: util_helper
INFO - 2017-11-14 15:23:08 --> Helper loaded: text_helper
INFO - 2017-11-14 15:23:08 --> Helper loaded: string_helper
INFO - 2017-11-14 15:23:08 --> Database Driver Class Initialized
DEBUG - 2017-11-14 15:23:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-14 15:23:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-14 15:23:08 --> Email Class Initialized
INFO - 2017-11-14 15:23:08 --> Controller Class Initialized
DEBUG - 2017-11-14 15:23:08 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header_menu.php
DEBUG - 2017-11-14 15:23:08 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header.php
DEBUG - 2017-11-14 15:23:08 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\contact.php
DEBUG - 2017-11-14 15:23:08 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/footer.php
INFO - 2017-11-14 15:23:08 --> Final output sent to browser
DEBUG - 2017-11-14 15:23:08 --> Total execution time: 0.0510
INFO - 2017-11-14 15:25:07 --> Config Class Initialized
INFO - 2017-11-14 15:25:07 --> Hooks Class Initialized
DEBUG - 2017-11-14 15:25:07 --> UTF-8 Support Enabled
INFO - 2017-11-14 15:25:07 --> Utf8 Class Initialized
INFO - 2017-11-14 15:25:07 --> URI Class Initialized
INFO - 2017-11-14 15:25:07 --> Router Class Initialized
INFO - 2017-11-14 15:25:07 --> Output Class Initialized
INFO - 2017-11-14 15:25:07 --> Security Class Initialized
DEBUG - 2017-11-14 15:25:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 15:25:07 --> Input Class Initialized
INFO - 2017-11-14 15:25:07 --> Language Class Initialized
INFO - 2017-11-14 15:25:07 --> Language Class Initialized
INFO - 2017-11-14 15:25:07 --> Config Class Initialized
INFO - 2017-11-14 15:25:07 --> Loader Class Initialized
DEBUG - 2017-11-14 15:25:07 --> Config file loaded: D:\xampp\htdocs\construction_bay\application\config/construct-data.php
INFO - 2017-11-14 15:25:07 --> Helper loaded: url_helper
INFO - 2017-11-14 15:25:07 --> Helper loaded: form_helper
INFO - 2017-11-14 15:25:07 --> Helper loaded: date_helper
INFO - 2017-11-14 15:25:07 --> Helper loaded: util_helper
INFO - 2017-11-14 15:25:07 --> Helper loaded: text_helper
INFO - 2017-11-14 15:25:07 --> Helper loaded: string_helper
INFO - 2017-11-14 15:25:07 --> Database Driver Class Initialized
DEBUG - 2017-11-14 15:25:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-14 15:25:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-14 15:25:07 --> Email Class Initialized
INFO - 2017-11-14 15:25:07 --> Controller Class Initialized
DEBUG - 2017-11-14 15:25:07 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header_menu.php
DEBUG - 2017-11-14 15:25:07 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header.php
DEBUG - 2017-11-14 15:25:07 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\contact.php
DEBUG - 2017-11-14 15:25:07 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/footer.php
INFO - 2017-11-14 15:25:07 --> Final output sent to browser
DEBUG - 2017-11-14 15:25:07 --> Total execution time: 0.0570
INFO - 2017-11-14 15:26:30 --> Config Class Initialized
INFO - 2017-11-14 15:26:30 --> Hooks Class Initialized
DEBUG - 2017-11-14 15:26:30 --> UTF-8 Support Enabled
INFO - 2017-11-14 15:26:30 --> Utf8 Class Initialized
INFO - 2017-11-14 15:26:30 --> URI Class Initialized
INFO - 2017-11-14 15:26:30 --> Router Class Initialized
INFO - 2017-11-14 15:26:30 --> Output Class Initialized
INFO - 2017-11-14 15:26:30 --> Security Class Initialized
DEBUG - 2017-11-14 15:26:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 15:26:30 --> Input Class Initialized
INFO - 2017-11-14 15:26:30 --> Language Class Initialized
INFO - 2017-11-14 15:26:30 --> Language Class Initialized
INFO - 2017-11-14 15:26:30 --> Config Class Initialized
INFO - 2017-11-14 15:26:30 --> Loader Class Initialized
DEBUG - 2017-11-14 15:26:30 --> Config file loaded: D:\xampp\htdocs\construction_bay\application\config/construct-data.php
INFO - 2017-11-14 15:26:30 --> Helper loaded: url_helper
INFO - 2017-11-14 15:26:30 --> Helper loaded: form_helper
INFO - 2017-11-14 15:26:30 --> Helper loaded: date_helper
INFO - 2017-11-14 15:26:30 --> Helper loaded: util_helper
INFO - 2017-11-14 15:26:30 --> Helper loaded: text_helper
INFO - 2017-11-14 15:26:30 --> Helper loaded: string_helper
INFO - 2017-11-14 15:26:30 --> Database Driver Class Initialized
DEBUG - 2017-11-14 15:26:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-14 15:26:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-14 15:26:30 --> Email Class Initialized
INFO - 2017-11-14 15:26:30 --> Controller Class Initialized
DEBUG - 2017-11-14 15:26:30 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header_menu.php
DEBUG - 2017-11-14 15:26:30 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header.php
DEBUG - 2017-11-14 15:26:30 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\about_us.php
DEBUG - 2017-11-14 15:26:30 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/footer.php
INFO - 2017-11-14 15:26:30 --> Final output sent to browser
DEBUG - 2017-11-14 15:26:30 --> Total execution time: 0.0850
INFO - 2017-11-14 15:30:31 --> Config Class Initialized
INFO - 2017-11-14 15:30:31 --> Hooks Class Initialized
DEBUG - 2017-11-14 15:30:31 --> UTF-8 Support Enabled
INFO - 2017-11-14 15:30:31 --> Utf8 Class Initialized
INFO - 2017-11-14 15:30:31 --> URI Class Initialized
INFO - 2017-11-14 15:30:31 --> Router Class Initialized
INFO - 2017-11-14 15:30:31 --> Output Class Initialized
INFO - 2017-11-14 15:30:31 --> Security Class Initialized
DEBUG - 2017-11-14 15:30:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 15:30:31 --> Input Class Initialized
INFO - 2017-11-14 15:30:31 --> Language Class Initialized
INFO - 2017-11-14 15:30:31 --> Language Class Initialized
INFO - 2017-11-14 15:30:31 --> Config Class Initialized
INFO - 2017-11-14 15:30:31 --> Loader Class Initialized
DEBUG - 2017-11-14 15:30:31 --> Config file loaded: D:\xampp\htdocs\construction_bay\application\config/construct-data.php
INFO - 2017-11-14 15:30:31 --> Helper loaded: url_helper
INFO - 2017-11-14 15:30:31 --> Helper loaded: form_helper
INFO - 2017-11-14 15:30:31 --> Helper loaded: date_helper
INFO - 2017-11-14 15:30:31 --> Helper loaded: util_helper
INFO - 2017-11-14 15:30:31 --> Helper loaded: text_helper
INFO - 2017-11-14 15:30:31 --> Helper loaded: string_helper
INFO - 2017-11-14 15:30:31 --> Database Driver Class Initialized
DEBUG - 2017-11-14 15:30:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-14 15:30:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-14 15:30:31 --> Email Class Initialized
INFO - 2017-11-14 15:30:31 --> Controller Class Initialized
DEBUG - 2017-11-14 15:30:31 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header_menu.php
DEBUG - 2017-11-14 15:30:31 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header.php
DEBUG - 2017-11-14 15:30:31 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\about_us.php
DEBUG - 2017-11-14 15:30:31 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/footer_nav.php
DEBUG - 2017-11-14 15:30:31 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/footer.php
INFO - 2017-11-14 15:30:31 --> Final output sent to browser
DEBUG - 2017-11-14 15:30:31 --> Total execution time: 0.0540
INFO - 2017-11-14 15:31:14 --> Config Class Initialized
INFO - 2017-11-14 15:31:14 --> Hooks Class Initialized
DEBUG - 2017-11-14 15:31:14 --> UTF-8 Support Enabled
INFO - 2017-11-14 15:31:14 --> Utf8 Class Initialized
INFO - 2017-11-14 15:31:14 --> URI Class Initialized
DEBUG - 2017-11-14 15:31:14 --> No URI present. Default controller set.
INFO - 2017-11-14 15:31:14 --> Router Class Initialized
INFO - 2017-11-14 15:31:14 --> Output Class Initialized
INFO - 2017-11-14 15:31:14 --> Security Class Initialized
DEBUG - 2017-11-14 15:31:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 15:31:14 --> Input Class Initialized
INFO - 2017-11-14 15:31:14 --> Language Class Initialized
INFO - 2017-11-14 15:31:14 --> Language Class Initialized
INFO - 2017-11-14 15:31:14 --> Config Class Initialized
INFO - 2017-11-14 15:31:14 --> Loader Class Initialized
DEBUG - 2017-11-14 15:31:14 --> Config file loaded: D:\xampp\htdocs\construction_bay\application\config/construct-data.php
INFO - 2017-11-14 15:31:14 --> Helper loaded: url_helper
INFO - 2017-11-14 15:31:14 --> Helper loaded: form_helper
INFO - 2017-11-14 15:31:14 --> Helper loaded: date_helper
INFO - 2017-11-14 15:31:14 --> Helper loaded: util_helper
INFO - 2017-11-14 15:31:14 --> Helper loaded: text_helper
INFO - 2017-11-14 15:31:14 --> Helper loaded: string_helper
INFO - 2017-11-14 15:31:14 --> Database Driver Class Initialized
DEBUG - 2017-11-14 15:31:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-14 15:31:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-14 15:31:14 --> Email Class Initialized
INFO - 2017-11-14 15:31:14 --> Controller Class Initialized
DEBUG - 2017-11-14 15:31:14 --> Home MX_Controller Initialized
INFO - 2017-11-14 15:31:14 --> Model Class Initialized
DEBUG - 2017-11-14 15:31:14 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_model.php
INFO - 2017-11-14 15:31:14 --> Model Class Initialized
DEBUG - 2017-11-14 15:31:14 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header_menu.php
DEBUG - 2017-11-14 15:31:14 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header.php
DEBUG - 2017-11-14 15:31:14 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/slider.php
DEBUG - 2017-11-14 15:31:14 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/index_body.php
DEBUG - 2017-11-14 15:31:14 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/home_footer_nav.php
DEBUG - 2017-11-14 15:31:14 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/index_footer.php
INFO - 2017-11-14 15:31:14 --> Final output sent to browser
DEBUG - 2017-11-14 15:31:14 --> Total execution time: 0.0990
INFO - 2017-11-14 15:31:37 --> Config Class Initialized
INFO - 2017-11-14 15:31:37 --> Hooks Class Initialized
DEBUG - 2017-11-14 15:31:37 --> UTF-8 Support Enabled
INFO - 2017-11-14 15:31:37 --> Utf8 Class Initialized
INFO - 2017-11-14 15:31:37 --> URI Class Initialized
DEBUG - 2017-11-14 15:31:37 --> No URI present. Default controller set.
INFO - 2017-11-14 15:31:37 --> Router Class Initialized
INFO - 2017-11-14 15:31:37 --> Output Class Initialized
INFO - 2017-11-14 15:31:37 --> Security Class Initialized
DEBUG - 2017-11-14 15:31:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 15:31:37 --> Input Class Initialized
INFO - 2017-11-14 15:31:37 --> Language Class Initialized
INFO - 2017-11-14 15:31:37 --> Language Class Initialized
INFO - 2017-11-14 15:31:37 --> Config Class Initialized
INFO - 2017-11-14 15:31:37 --> Loader Class Initialized
DEBUG - 2017-11-14 15:31:37 --> Config file loaded: D:\xampp\htdocs\construction_bay\application\config/construct-data.php
INFO - 2017-11-14 15:31:37 --> Helper loaded: url_helper
INFO - 2017-11-14 15:31:37 --> Helper loaded: form_helper
INFO - 2017-11-14 15:31:37 --> Helper loaded: date_helper
INFO - 2017-11-14 15:31:37 --> Helper loaded: util_helper
INFO - 2017-11-14 15:31:37 --> Helper loaded: text_helper
INFO - 2017-11-14 15:31:37 --> Helper loaded: string_helper
INFO - 2017-11-14 15:31:37 --> Database Driver Class Initialized
DEBUG - 2017-11-14 15:31:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-14 15:31:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-14 15:31:37 --> Email Class Initialized
INFO - 2017-11-14 15:31:37 --> Controller Class Initialized
DEBUG - 2017-11-14 15:31:37 --> Home MX_Controller Initialized
INFO - 2017-11-14 15:31:37 --> Model Class Initialized
DEBUG - 2017-11-14 15:31:37 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_model.php
INFO - 2017-11-14 15:31:37 --> Model Class Initialized
DEBUG - 2017-11-14 15:31:37 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header_menu.php
DEBUG - 2017-11-14 15:31:37 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header.php
DEBUG - 2017-11-14 15:31:37 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/slider.php
DEBUG - 2017-11-14 15:31:37 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/index_body.php
DEBUG - 2017-11-14 15:31:37 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/home_footer_nav.php
DEBUG - 2017-11-14 15:31:37 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/index_footer.php
INFO - 2017-11-14 15:31:37 --> Final output sent to browser
DEBUG - 2017-11-14 15:31:37 --> Total execution time: 0.0710
INFO - 2017-11-14 15:36:41 --> Config Class Initialized
INFO - 2017-11-14 15:36:41 --> Hooks Class Initialized
DEBUG - 2017-11-14 15:36:41 --> UTF-8 Support Enabled
INFO - 2017-11-14 15:36:41 --> Utf8 Class Initialized
INFO - 2017-11-14 15:36:41 --> URI Class Initialized
DEBUG - 2017-11-14 15:36:41 --> No URI present. Default controller set.
INFO - 2017-11-14 15:36:41 --> Router Class Initialized
INFO - 2017-11-14 15:36:41 --> Output Class Initialized
INFO - 2017-11-14 15:36:41 --> Security Class Initialized
DEBUG - 2017-11-14 15:36:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 15:36:41 --> Input Class Initialized
INFO - 2017-11-14 15:36:41 --> Language Class Initialized
INFO - 2017-11-14 15:36:41 --> Language Class Initialized
INFO - 2017-11-14 15:36:41 --> Config Class Initialized
INFO - 2017-11-14 15:36:41 --> Loader Class Initialized
DEBUG - 2017-11-14 15:36:41 --> Config file loaded: D:\xampp\htdocs\construction_bay\application\config/construct-data.php
INFO - 2017-11-14 15:36:41 --> Helper loaded: url_helper
INFO - 2017-11-14 15:36:41 --> Helper loaded: form_helper
INFO - 2017-11-14 15:36:41 --> Helper loaded: date_helper
INFO - 2017-11-14 15:36:41 --> Helper loaded: util_helper
INFO - 2017-11-14 15:36:41 --> Helper loaded: text_helper
INFO - 2017-11-14 15:36:41 --> Helper loaded: string_helper
INFO - 2017-11-14 15:36:41 --> Database Driver Class Initialized
DEBUG - 2017-11-14 15:36:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-14 15:36:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-14 15:36:41 --> Email Class Initialized
INFO - 2017-11-14 15:36:41 --> Controller Class Initialized
DEBUG - 2017-11-14 15:36:41 --> Home MX_Controller Initialized
INFO - 2017-11-14 15:36:41 --> Model Class Initialized
DEBUG - 2017-11-14 15:36:41 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_model.php
INFO - 2017-11-14 15:36:41 --> Model Class Initialized
DEBUG - 2017-11-14 15:36:41 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header_menu.php
DEBUG - 2017-11-14 15:36:41 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header.php
DEBUG - 2017-11-14 15:36:41 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/slider.php
DEBUG - 2017-11-14 15:36:41 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/index_body.php
DEBUG - 2017-11-14 15:36:41 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/home_footer_nav.php
DEBUG - 2017-11-14 15:36:41 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/index_footer.php
INFO - 2017-11-14 15:36:41 --> Final output sent to browser
DEBUG - 2017-11-14 15:36:41 --> Total execution time: 0.0610
INFO - 2017-11-14 15:36:59 --> Config Class Initialized
INFO - 2017-11-14 15:36:59 --> Hooks Class Initialized
DEBUG - 2017-11-14 15:36:59 --> UTF-8 Support Enabled
INFO - 2017-11-14 15:36:59 --> Utf8 Class Initialized
INFO - 2017-11-14 15:36:59 --> URI Class Initialized
INFO - 2017-11-14 15:36:59 --> Router Class Initialized
INFO - 2017-11-14 15:36:59 --> Output Class Initialized
INFO - 2017-11-14 15:36:59 --> Security Class Initialized
DEBUG - 2017-11-14 15:36:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 15:36:59 --> Input Class Initialized
INFO - 2017-11-14 15:36:59 --> Language Class Initialized
INFO - 2017-11-14 15:36:59 --> Language Class Initialized
INFO - 2017-11-14 15:36:59 --> Config Class Initialized
INFO - 2017-11-14 15:36:59 --> Loader Class Initialized
DEBUG - 2017-11-14 15:36:59 --> Config file loaded: D:\xampp\htdocs\construction_bay\application\config/construct-data.php
INFO - 2017-11-14 15:36:59 --> Helper loaded: url_helper
INFO - 2017-11-14 15:36:59 --> Helper loaded: form_helper
INFO - 2017-11-14 15:36:59 --> Helper loaded: date_helper
INFO - 2017-11-14 15:36:59 --> Helper loaded: util_helper
INFO - 2017-11-14 15:36:59 --> Helper loaded: text_helper
INFO - 2017-11-14 15:36:59 --> Helper loaded: string_helper
INFO - 2017-11-14 15:36:59 --> Database Driver Class Initialized
DEBUG - 2017-11-14 15:37:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-14 15:37:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-14 15:37:00 --> Email Class Initialized
INFO - 2017-11-14 15:37:00 --> Controller Class Initialized
INFO - 2017-11-14 15:37:00 --> Model Class Initialized
DEBUG - 2017-11-14 15:37:00 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_model.php
INFO - 2017-11-14 15:37:00 --> Model Class Initialized
DEBUG - 2017-11-14 15:37:00 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_functions_model.php
INFO - 2017-11-14 15:37:00 --> Model Class Initialized
DEBUG - 2017-11-14 15:37:00 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header_menu.php
DEBUG - 2017-11-14 15:37:00 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header.php
DEBUG - 2017-11-14 15:37:00 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\products-services.php
DEBUG - 2017-11-14 15:37:00 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/footer_nav.php
DEBUG - 2017-11-14 15:37:00 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/footer.php
INFO - 2017-11-14 15:37:00 --> Final output sent to browser
DEBUG - 2017-11-14 15:37:00 --> Total execution time: 0.0520
INFO - 2017-11-14 15:37:18 --> Config Class Initialized
INFO - 2017-11-14 15:37:18 --> Hooks Class Initialized
DEBUG - 2017-11-14 15:37:18 --> UTF-8 Support Enabled
INFO - 2017-11-14 15:37:18 --> Utf8 Class Initialized
INFO - 2017-11-14 15:37:18 --> URI Class Initialized
INFO - 2017-11-14 15:37:18 --> Router Class Initialized
INFO - 2017-11-14 15:37:18 --> Output Class Initialized
INFO - 2017-11-14 15:37:18 --> Security Class Initialized
DEBUG - 2017-11-14 15:37:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 15:37:18 --> Input Class Initialized
INFO - 2017-11-14 15:37:18 --> Language Class Initialized
ERROR - 2017-11-14 15:37:18 --> 404 Page Not Found: /index
INFO - 2017-11-14 15:39:48 --> Config Class Initialized
INFO - 2017-11-14 15:39:48 --> Hooks Class Initialized
DEBUG - 2017-11-14 15:39:48 --> UTF-8 Support Enabled
INFO - 2017-11-14 15:39:48 --> Utf8 Class Initialized
INFO - 2017-11-14 15:39:48 --> URI Class Initialized
INFO - 2017-11-14 15:39:48 --> Router Class Initialized
INFO - 2017-11-14 15:39:48 --> Output Class Initialized
INFO - 2017-11-14 15:39:48 --> Security Class Initialized
DEBUG - 2017-11-14 15:39:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 15:39:48 --> Input Class Initialized
INFO - 2017-11-14 15:39:48 --> Language Class Initialized
INFO - 2017-11-14 15:39:48 --> Language Class Initialized
INFO - 2017-11-14 15:39:48 --> Config Class Initialized
INFO - 2017-11-14 15:39:48 --> Loader Class Initialized
DEBUG - 2017-11-14 15:39:48 --> Config file loaded: D:\xampp\htdocs\construction_bay\application\config/construct-data.php
INFO - 2017-11-14 15:39:48 --> Helper loaded: url_helper
INFO - 2017-11-14 15:39:48 --> Helper loaded: form_helper
INFO - 2017-11-14 15:39:48 --> Helper loaded: date_helper
INFO - 2017-11-14 15:39:48 --> Helper loaded: util_helper
INFO - 2017-11-14 15:39:48 --> Helper loaded: text_helper
INFO - 2017-11-14 15:39:48 --> Helper loaded: string_helper
INFO - 2017-11-14 15:39:48 --> Database Driver Class Initialized
DEBUG - 2017-11-14 15:39:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-14 15:39:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-14 15:39:49 --> Email Class Initialized
INFO - 2017-11-14 15:39:49 --> Controller Class Initialized
INFO - 2017-11-14 15:39:49 --> Model Class Initialized
DEBUG - 2017-11-14 15:39:49 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_model.php
INFO - 2017-11-14 15:39:49 --> Model Class Initialized
DEBUG - 2017-11-14 15:39:49 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_functions_model.php
INFO - 2017-11-14 15:39:49 --> Model Class Initialized
DEBUG - 2017-11-14 15:39:49 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header_menu.php
DEBUG - 2017-11-14 15:39:49 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header.php
DEBUG - 2017-11-14 15:39:49 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\products-services.php
DEBUG - 2017-11-14 15:39:49 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/footer_nav.php
DEBUG - 2017-11-14 15:39:49 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/footer.php
INFO - 2017-11-14 15:39:49 --> Final output sent to browser
DEBUG - 2017-11-14 15:39:49 --> Total execution time: 0.0550
INFO - 2017-11-14 15:39:49 --> Config Class Initialized
INFO - 2017-11-14 15:39:49 --> Hooks Class Initialized
DEBUG - 2017-11-14 15:39:49 --> UTF-8 Support Enabled
INFO - 2017-11-14 15:39:49 --> Utf8 Class Initialized
INFO - 2017-11-14 15:39:49 --> URI Class Initialized
INFO - 2017-11-14 15:39:49 --> Router Class Initialized
INFO - 2017-11-14 15:39:49 --> Output Class Initialized
INFO - 2017-11-14 15:39:49 --> Security Class Initialized
DEBUG - 2017-11-14 15:39:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 15:39:49 --> Input Class Initialized
INFO - 2017-11-14 15:39:49 --> Language Class Initialized
ERROR - 2017-11-14 15:39:49 --> 404 Page Not Found: /index
INFO - 2017-11-14 15:40:05 --> Config Class Initialized
INFO - 2017-11-14 15:40:05 --> Hooks Class Initialized
DEBUG - 2017-11-14 15:40:05 --> UTF-8 Support Enabled
INFO - 2017-11-14 15:40:05 --> Utf8 Class Initialized
INFO - 2017-11-14 15:40:05 --> URI Class Initialized
DEBUG - 2017-11-14 15:40:05 --> No URI present. Default controller set.
INFO - 2017-11-14 15:40:05 --> Router Class Initialized
INFO - 2017-11-14 15:40:05 --> Output Class Initialized
INFO - 2017-11-14 15:40:05 --> Security Class Initialized
DEBUG - 2017-11-14 15:40:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 15:40:05 --> Input Class Initialized
INFO - 2017-11-14 15:40:05 --> Language Class Initialized
INFO - 2017-11-14 15:40:05 --> Language Class Initialized
INFO - 2017-11-14 15:40:05 --> Config Class Initialized
INFO - 2017-11-14 15:40:05 --> Loader Class Initialized
DEBUG - 2017-11-14 15:40:05 --> Config file loaded: D:\xampp\htdocs\construction_bay\application\config/construct-data.php
INFO - 2017-11-14 15:40:05 --> Helper loaded: url_helper
INFO - 2017-11-14 15:40:05 --> Helper loaded: form_helper
INFO - 2017-11-14 15:40:05 --> Helper loaded: date_helper
INFO - 2017-11-14 15:40:05 --> Helper loaded: util_helper
INFO - 2017-11-14 15:40:05 --> Helper loaded: text_helper
INFO - 2017-11-14 15:40:05 --> Helper loaded: string_helper
INFO - 2017-11-14 15:40:05 --> Database Driver Class Initialized
DEBUG - 2017-11-14 15:40:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-14 15:40:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-14 15:40:05 --> Email Class Initialized
INFO - 2017-11-14 15:40:05 --> Controller Class Initialized
DEBUG - 2017-11-14 15:40:05 --> Home MX_Controller Initialized
INFO - 2017-11-14 15:40:05 --> Model Class Initialized
DEBUG - 2017-11-14 15:40:05 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_model.php
INFO - 2017-11-14 15:40:05 --> Model Class Initialized
DEBUG - 2017-11-14 15:40:05 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header_menu.php
DEBUG - 2017-11-14 15:40:05 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header.php
DEBUG - 2017-11-14 15:40:05 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/slider.php
DEBUG - 2017-11-14 15:40:05 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/index_body.php
DEBUG - 2017-11-14 15:40:05 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/home_footer_nav.php
DEBUG - 2017-11-14 15:40:05 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/index_footer.php
INFO - 2017-11-14 15:40:05 --> Final output sent to browser
DEBUG - 2017-11-14 15:40:05 --> Total execution time: 0.0680
INFO - 2017-11-14 15:40:23 --> Config Class Initialized
INFO - 2017-11-14 15:40:23 --> Hooks Class Initialized
DEBUG - 2017-11-14 15:40:23 --> UTF-8 Support Enabled
INFO - 2017-11-14 15:40:23 --> Utf8 Class Initialized
INFO - 2017-11-14 15:40:23 --> URI Class Initialized
INFO - 2017-11-14 15:40:23 --> Router Class Initialized
INFO - 2017-11-14 15:40:23 --> Output Class Initialized
INFO - 2017-11-14 15:40:23 --> Security Class Initialized
DEBUG - 2017-11-14 15:40:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 15:40:23 --> Input Class Initialized
INFO - 2017-11-14 15:40:23 --> Language Class Initialized
INFO - 2017-11-14 15:40:23 --> Language Class Initialized
INFO - 2017-11-14 15:40:23 --> Config Class Initialized
INFO - 2017-11-14 15:40:23 --> Loader Class Initialized
DEBUG - 2017-11-14 15:40:23 --> Config file loaded: D:\xampp\htdocs\construction_bay\application\config/construct-data.php
INFO - 2017-11-14 15:40:23 --> Helper loaded: url_helper
INFO - 2017-11-14 15:40:23 --> Helper loaded: form_helper
INFO - 2017-11-14 15:40:23 --> Helper loaded: date_helper
INFO - 2017-11-14 15:40:23 --> Helper loaded: util_helper
INFO - 2017-11-14 15:40:23 --> Helper loaded: text_helper
INFO - 2017-11-14 15:40:23 --> Helper loaded: string_helper
INFO - 2017-11-14 15:40:23 --> Database Driver Class Initialized
DEBUG - 2017-11-14 15:40:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-14 15:40:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-14 15:40:23 --> Email Class Initialized
INFO - 2017-11-14 15:40:23 --> Controller Class Initialized
INFO - 2017-11-14 15:40:23 --> Model Class Initialized
DEBUG - 2017-11-14 15:40:23 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_model.php
INFO - 2017-11-14 15:40:23 --> Model Class Initialized
DEBUG - 2017-11-14 15:40:23 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_functions_model.php
INFO - 2017-11-14 15:40:23 --> Model Class Initialized
DEBUG - 2017-11-14 15:40:23 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header_menu.php
DEBUG - 2017-11-14 15:40:23 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header.php
DEBUG - 2017-11-14 15:40:23 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\projects/projects.php
DEBUG - 2017-11-14 15:40:23 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/footer_nav.php
DEBUG - 2017-11-14 15:40:23 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/footer.php
INFO - 2017-11-14 15:40:23 --> Final output sent to browser
DEBUG - 2017-11-14 15:40:23 --> Total execution time: 0.1430
INFO - 2017-11-14 15:40:31 --> Config Class Initialized
INFO - 2017-11-14 15:40:31 --> Hooks Class Initialized
DEBUG - 2017-11-14 15:40:31 --> UTF-8 Support Enabled
INFO - 2017-11-14 15:40:31 --> Utf8 Class Initialized
INFO - 2017-11-14 15:40:31 --> URI Class Initialized
DEBUG - 2017-11-14 15:40:31 --> No URI present. Default controller set.
INFO - 2017-11-14 15:40:31 --> Router Class Initialized
INFO - 2017-11-14 15:40:31 --> Output Class Initialized
INFO - 2017-11-14 15:40:31 --> Security Class Initialized
DEBUG - 2017-11-14 15:40:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 15:40:31 --> Input Class Initialized
INFO - 2017-11-14 15:40:31 --> Language Class Initialized
INFO - 2017-11-14 15:40:31 --> Language Class Initialized
INFO - 2017-11-14 15:40:31 --> Config Class Initialized
INFO - 2017-11-14 15:40:31 --> Loader Class Initialized
DEBUG - 2017-11-14 15:40:31 --> Config file loaded: D:\xampp\htdocs\construction_bay\application\config/construct-data.php
INFO - 2017-11-14 15:40:31 --> Helper loaded: url_helper
INFO - 2017-11-14 15:40:31 --> Helper loaded: form_helper
INFO - 2017-11-14 15:40:31 --> Helper loaded: date_helper
INFO - 2017-11-14 15:40:31 --> Helper loaded: util_helper
INFO - 2017-11-14 15:40:31 --> Helper loaded: text_helper
INFO - 2017-11-14 15:40:31 --> Helper loaded: string_helper
INFO - 2017-11-14 15:40:31 --> Database Driver Class Initialized
DEBUG - 2017-11-14 15:40:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-14 15:40:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-14 15:40:31 --> Email Class Initialized
INFO - 2017-11-14 15:40:31 --> Controller Class Initialized
DEBUG - 2017-11-14 15:40:31 --> Home MX_Controller Initialized
INFO - 2017-11-14 15:40:31 --> Model Class Initialized
DEBUG - 2017-11-14 15:40:31 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_model.php
INFO - 2017-11-14 15:40:31 --> Model Class Initialized
DEBUG - 2017-11-14 15:40:31 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header_menu.php
DEBUG - 2017-11-14 15:40:31 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header.php
DEBUG - 2017-11-14 15:40:31 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/slider.php
DEBUG - 2017-11-14 15:40:31 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/index_body.php
DEBUG - 2017-11-14 15:40:31 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/home_footer_nav.php
DEBUG - 2017-11-14 15:40:31 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/index_footer.php
INFO - 2017-11-14 15:40:31 --> Final output sent to browser
DEBUG - 2017-11-14 15:40:31 --> Total execution time: 0.0650
INFO - 2017-11-14 15:40:37 --> Config Class Initialized
INFO - 2017-11-14 15:40:37 --> Hooks Class Initialized
DEBUG - 2017-11-14 15:40:37 --> UTF-8 Support Enabled
INFO - 2017-11-14 15:40:37 --> Utf8 Class Initialized
INFO - 2017-11-14 15:40:37 --> URI Class Initialized
INFO - 2017-11-14 15:40:37 --> Router Class Initialized
INFO - 2017-11-14 15:40:37 --> Output Class Initialized
INFO - 2017-11-14 15:40:37 --> Security Class Initialized
DEBUG - 2017-11-14 15:40:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 15:40:37 --> Input Class Initialized
INFO - 2017-11-14 15:40:37 --> Language Class Initialized
INFO - 2017-11-14 15:40:37 --> Language Class Initialized
INFO - 2017-11-14 15:40:37 --> Config Class Initialized
INFO - 2017-11-14 15:40:37 --> Loader Class Initialized
DEBUG - 2017-11-14 15:40:37 --> Config file loaded: D:\xampp\htdocs\construction_bay\application\config/construct-data.php
INFO - 2017-11-14 15:40:37 --> Helper loaded: url_helper
INFO - 2017-11-14 15:40:37 --> Helper loaded: form_helper
INFO - 2017-11-14 15:40:37 --> Helper loaded: date_helper
INFO - 2017-11-14 15:40:37 --> Helper loaded: util_helper
INFO - 2017-11-14 15:40:37 --> Helper loaded: text_helper
INFO - 2017-11-14 15:40:37 --> Helper loaded: string_helper
INFO - 2017-11-14 15:40:37 --> Database Driver Class Initialized
DEBUG - 2017-11-14 15:40:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-14 15:40:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-14 15:40:37 --> Email Class Initialized
INFO - 2017-11-14 15:40:37 --> Controller Class Initialized
INFO - 2017-11-14 15:40:37 --> Model Class Initialized
DEBUG - 2017-11-14 15:40:37 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_model.php
INFO - 2017-11-14 15:40:37 --> Model Class Initialized
DEBUG - 2017-11-14 15:40:37 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_functions_model.php
INFO - 2017-11-14 15:40:37 --> Model Class Initialized
DEBUG - 2017-11-14 15:40:37 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header_menu.php
DEBUG - 2017-11-14 15:40:37 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header.php
DEBUG - 2017-11-14 15:40:37 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\products-services.php
DEBUG - 2017-11-14 15:40:37 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/footer_nav.php
DEBUG - 2017-11-14 15:40:37 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/footer.php
INFO - 2017-11-14 15:40:37 --> Final output sent to browser
DEBUG - 2017-11-14 15:40:37 --> Total execution time: 0.0550
INFO - 2017-11-14 15:40:38 --> Config Class Initialized
INFO - 2017-11-14 15:40:38 --> Hooks Class Initialized
DEBUG - 2017-11-14 15:40:38 --> UTF-8 Support Enabled
INFO - 2017-11-14 15:40:38 --> Utf8 Class Initialized
INFO - 2017-11-14 15:40:38 --> URI Class Initialized
INFO - 2017-11-14 15:40:38 --> Router Class Initialized
INFO - 2017-11-14 15:40:38 --> Output Class Initialized
INFO - 2017-11-14 15:40:38 --> Security Class Initialized
DEBUG - 2017-11-14 15:40:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 15:40:38 --> Input Class Initialized
INFO - 2017-11-14 15:40:38 --> Language Class Initialized
ERROR - 2017-11-14 15:40:38 --> 404 Page Not Found: /index
INFO - 2017-11-14 16:43:18 --> Config Class Initialized
INFO - 2017-11-14 16:43:18 --> Hooks Class Initialized
DEBUG - 2017-11-14 16:43:18 --> UTF-8 Support Enabled
INFO - 2017-11-14 16:43:18 --> Utf8 Class Initialized
INFO - 2017-11-14 16:43:18 --> URI Class Initialized
DEBUG - 2017-11-14 16:43:18 --> No URI present. Default controller set.
INFO - 2017-11-14 16:43:18 --> Router Class Initialized
INFO - 2017-11-14 16:43:18 --> Output Class Initialized
INFO - 2017-11-14 16:43:18 --> Security Class Initialized
DEBUG - 2017-11-14 16:43:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 16:43:18 --> Input Class Initialized
INFO - 2017-11-14 16:43:18 --> Language Class Initialized
INFO - 2017-11-14 16:43:18 --> Language Class Initialized
INFO - 2017-11-14 16:43:18 --> Config Class Initialized
INFO - 2017-11-14 16:43:18 --> Loader Class Initialized
DEBUG - 2017-11-14 16:43:18 --> Config file loaded: D:\xampp\htdocs\construction_bay\application\config/construct-data.php
INFO - 2017-11-14 16:43:18 --> Helper loaded: url_helper
INFO - 2017-11-14 16:43:18 --> Helper loaded: form_helper
INFO - 2017-11-14 16:43:18 --> Helper loaded: date_helper
INFO - 2017-11-14 16:43:18 --> Helper loaded: util_helper
INFO - 2017-11-14 16:43:18 --> Helper loaded: text_helper
INFO - 2017-11-14 16:43:18 --> Helper loaded: string_helper
INFO - 2017-11-14 16:43:18 --> Database Driver Class Initialized
DEBUG - 2017-11-14 16:43:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-14 16:43:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-14 16:43:18 --> Email Class Initialized
INFO - 2017-11-14 16:43:18 --> Controller Class Initialized
DEBUG - 2017-11-14 16:43:18 --> Home MX_Controller Initialized
INFO - 2017-11-14 16:43:18 --> Model Class Initialized
DEBUG - 2017-11-14 16:43:18 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_model.php
INFO - 2017-11-14 16:43:18 --> Model Class Initialized
DEBUG - 2017-11-14 16:43:18 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header_menu.php
DEBUG - 2017-11-14 16:43:18 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header.php
DEBUG - 2017-11-14 16:43:18 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/slider.php
DEBUG - 2017-11-14 16:43:18 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/index_body.php
DEBUG - 2017-11-14 16:43:18 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/home_footer_nav.php
DEBUG - 2017-11-14 16:43:18 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/index_footer.php
INFO - 2017-11-14 16:43:18 --> Final output sent to browser
DEBUG - 2017-11-14 16:43:18 --> Total execution time: 0.5970
INFO - 2017-11-14 16:43:19 --> Config Class Initialized
INFO - 2017-11-14 16:43:19 --> Hooks Class Initialized
DEBUG - 2017-11-14 16:43:19 --> UTF-8 Support Enabled
INFO - 2017-11-14 16:43:19 --> Utf8 Class Initialized
INFO - 2017-11-14 16:43:19 --> URI Class Initialized
INFO - 2017-11-14 16:43:19 --> Router Class Initialized
INFO - 2017-11-14 16:43:19 --> Output Class Initialized
INFO - 2017-11-14 16:43:19 --> Security Class Initialized
DEBUG - 2017-11-14 16:43:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 16:43:19 --> Input Class Initialized
INFO - 2017-11-14 16:43:19 --> Language Class Initialized
INFO - 2017-11-14 16:43:19 --> Language Class Initialized
INFO - 2017-11-14 16:43:19 --> Config Class Initialized
INFO - 2017-11-14 16:43:19 --> Loader Class Initialized
DEBUG - 2017-11-14 16:43:19 --> Config file loaded: D:\xampp\htdocs\construction_bay\application\config/construct-data.php
INFO - 2017-11-14 16:43:19 --> Helper loaded: url_helper
INFO - 2017-11-14 16:43:19 --> Helper loaded: form_helper
INFO - 2017-11-14 16:43:19 --> Helper loaded: date_helper
INFO - 2017-11-14 16:43:19 --> Helper loaded: util_helper
INFO - 2017-11-14 16:43:19 --> Helper loaded: text_helper
INFO - 2017-11-14 16:43:19 --> Helper loaded: string_helper
INFO - 2017-11-14 16:43:19 --> Database Driver Class Initialized
DEBUG - 2017-11-14 16:43:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-14 16:43:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-14 16:43:19 --> Email Class Initialized
INFO - 2017-11-14 16:43:19 --> Controller Class Initialized
INFO - 2017-11-14 16:43:19 --> Model Class Initialized
DEBUG - 2017-11-14 16:43:19 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_model.php
INFO - 2017-11-14 16:43:19 --> Model Class Initialized
DEBUG - 2017-11-14 16:43:19 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_functions_model.php
INFO - 2017-11-14 16:43:19 --> Model Class Initialized
DEBUG - 2017-11-14 16:43:19 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header_menu.php
DEBUG - 2017-11-14 16:43:19 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\companies/companies_header.php
DEBUG - 2017-11-14 16:43:19 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\companies/companies_page.php
DEBUG - 2017-11-14 16:43:19 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/home_footer_nav.php
DEBUG - 2017-11-14 16:43:19 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\companies/companies_footer.php
INFO - 2017-11-14 16:43:19 --> Final output sent to browser
DEBUG - 2017-11-14 16:43:19 --> Total execution time: 0.1220
INFO - 2017-11-14 16:43:20 --> Config Class Initialized
INFO - 2017-11-14 16:43:20 --> Hooks Class Initialized
DEBUG - 2017-11-14 16:43:20 --> UTF-8 Support Enabled
INFO - 2017-11-14 16:43:20 --> Utf8 Class Initialized
INFO - 2017-11-14 16:43:20 --> URI Class Initialized
INFO - 2017-11-14 16:43:20 --> Router Class Initialized
INFO - 2017-11-14 16:43:20 --> Output Class Initialized
INFO - 2017-11-14 16:43:20 --> Security Class Initialized
DEBUG - 2017-11-14 16:43:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 16:43:20 --> Input Class Initialized
INFO - 2017-11-14 16:43:20 --> Language Class Initialized
INFO - 2017-11-14 16:43:20 --> Language Class Initialized
INFO - 2017-11-14 16:43:20 --> Config Class Initialized
INFO - 2017-11-14 16:43:20 --> Loader Class Initialized
DEBUG - 2017-11-14 16:43:20 --> Config file loaded: D:\xampp\htdocs\construction_bay\application\config/construct-data.php
INFO - 2017-11-14 16:43:20 --> Helper loaded: url_helper
INFO - 2017-11-14 16:43:20 --> Helper loaded: form_helper
INFO - 2017-11-14 16:43:20 --> Helper loaded: date_helper
INFO - 2017-11-14 16:43:20 --> Helper loaded: util_helper
INFO - 2017-11-14 16:43:20 --> Helper loaded: text_helper
INFO - 2017-11-14 16:43:20 --> Helper loaded: string_helper
INFO - 2017-11-14 16:43:20 --> Database Driver Class Initialized
DEBUG - 2017-11-14 16:43:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-14 16:43:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-14 16:43:20 --> Email Class Initialized
INFO - 2017-11-14 16:43:20 --> Controller Class Initialized
DEBUG - 2017-11-14 16:43:20 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header_menu.php
DEBUG - 2017-11-14 16:43:20 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header.php
DEBUG - 2017-11-14 16:43:20 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\contact.php
DEBUG - 2017-11-14 16:43:20 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/footer_nav.php
DEBUG - 2017-11-14 16:43:20 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/footer.php
INFO - 2017-11-14 16:43:20 --> Final output sent to browser
DEBUG - 2017-11-14 16:43:20 --> Total execution time: 0.1730
INFO - 2017-11-14 16:43:21 --> Config Class Initialized
INFO - 2017-11-14 16:43:21 --> Hooks Class Initialized
DEBUG - 2017-11-14 16:43:21 --> UTF-8 Support Enabled
INFO - 2017-11-14 16:43:21 --> Utf8 Class Initialized
INFO - 2017-11-14 16:43:21 --> URI Class Initialized
INFO - 2017-11-14 16:43:21 --> Router Class Initialized
INFO - 2017-11-14 16:43:21 --> Output Class Initialized
INFO - 2017-11-14 16:43:21 --> Security Class Initialized
DEBUG - 2017-11-14 16:43:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 16:43:21 --> Input Class Initialized
INFO - 2017-11-14 16:43:21 --> Language Class Initialized
INFO - 2017-11-14 16:43:21 --> Language Class Initialized
INFO - 2017-11-14 16:43:21 --> Config Class Initialized
INFO - 2017-11-14 16:43:21 --> Loader Class Initialized
DEBUG - 2017-11-14 16:43:21 --> Config file loaded: D:\xampp\htdocs\construction_bay\application\config/construct-data.php
INFO - 2017-11-14 16:43:21 --> Helper loaded: url_helper
INFO - 2017-11-14 16:43:21 --> Helper loaded: form_helper
INFO - 2017-11-14 16:43:21 --> Helper loaded: date_helper
INFO - 2017-11-14 16:43:21 --> Helper loaded: util_helper
INFO - 2017-11-14 16:43:21 --> Helper loaded: text_helper
INFO - 2017-11-14 16:43:21 --> Helper loaded: string_helper
INFO - 2017-11-14 16:43:21 --> Database Driver Class Initialized
DEBUG - 2017-11-14 16:43:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-14 16:43:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-14 16:43:21 --> Email Class Initialized
INFO - 2017-11-14 16:43:21 --> Controller Class Initialized
DEBUG - 2017-11-14 16:43:21 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header_menu.php
DEBUG - 2017-11-14 16:43:21 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header.php
DEBUG - 2017-11-14 16:43:21 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\about_us.php
DEBUG - 2017-11-14 16:43:21 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/footer_nav.php
DEBUG - 2017-11-14 16:43:21 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/footer.php
INFO - 2017-11-14 16:43:21 --> Final output sent to browser
DEBUG - 2017-11-14 16:43:21 --> Total execution time: 0.0920
INFO - 2017-11-14 16:43:21 --> Config Class Initialized
INFO - 2017-11-14 16:43:21 --> Hooks Class Initialized
DEBUG - 2017-11-14 16:43:21 --> UTF-8 Support Enabled
INFO - 2017-11-14 16:43:21 --> Utf8 Class Initialized
INFO - 2017-11-14 16:43:21 --> URI Class Initialized
INFO - 2017-11-14 16:43:21 --> Router Class Initialized
INFO - 2017-11-14 16:43:21 --> Output Class Initialized
INFO - 2017-11-14 16:43:21 --> Security Class Initialized
DEBUG - 2017-11-14 16:43:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 16:43:21 --> Input Class Initialized
INFO - 2017-11-14 16:43:21 --> Language Class Initialized
ERROR - 2017-11-14 16:43:21 --> 404 Page Not Found: Companies/companies
INFO - 2017-11-14 16:48:51 --> Config Class Initialized
INFO - 2017-11-14 16:48:51 --> Hooks Class Initialized
DEBUG - 2017-11-14 16:48:51 --> UTF-8 Support Enabled
INFO - 2017-11-14 16:48:51 --> Utf8 Class Initialized
INFO - 2017-11-14 16:48:51 --> URI Class Initialized
DEBUG - 2017-11-14 16:48:51 --> No URI present. Default controller set.
INFO - 2017-11-14 16:48:51 --> Router Class Initialized
INFO - 2017-11-14 16:48:51 --> Output Class Initialized
INFO - 2017-11-14 16:48:51 --> Security Class Initialized
DEBUG - 2017-11-14 16:48:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 16:48:51 --> Input Class Initialized
INFO - 2017-11-14 16:48:51 --> Language Class Initialized
INFO - 2017-11-14 16:48:51 --> Language Class Initialized
INFO - 2017-11-14 16:48:51 --> Config Class Initialized
INFO - 2017-11-14 16:48:51 --> Loader Class Initialized
DEBUG - 2017-11-14 16:48:51 --> Config file loaded: D:\xampp\htdocs\construction_bay\application\config/construct-data.php
INFO - 2017-11-14 16:48:51 --> Helper loaded: url_helper
INFO - 2017-11-14 16:48:51 --> Helper loaded: form_helper
INFO - 2017-11-14 16:48:51 --> Helper loaded: date_helper
INFO - 2017-11-14 16:48:51 --> Helper loaded: util_helper
INFO - 2017-11-14 16:48:51 --> Helper loaded: text_helper
INFO - 2017-11-14 16:48:51 --> Helper loaded: string_helper
INFO - 2017-11-14 16:48:51 --> Database Driver Class Initialized
DEBUG - 2017-11-14 16:48:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-14 16:48:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-14 16:48:51 --> Email Class Initialized
INFO - 2017-11-14 16:48:51 --> Controller Class Initialized
DEBUG - 2017-11-14 16:48:51 --> Home MX_Controller Initialized
INFO - 2017-11-14 16:48:51 --> Model Class Initialized
DEBUG - 2017-11-14 16:48:51 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_model.php
INFO - 2017-11-14 16:48:51 --> Model Class Initialized
DEBUG - 2017-11-14 16:48:51 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header_menu.php
DEBUG - 2017-11-14 16:48:51 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header.php
DEBUG - 2017-11-14 16:48:51 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/slider.php
DEBUG - 2017-11-14 16:48:51 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/index_body.php
DEBUG - 2017-11-14 16:48:51 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/home_footer_nav.php
DEBUG - 2017-11-14 16:48:51 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/index_footer.php
INFO - 2017-11-14 16:48:51 --> Final output sent to browser
DEBUG - 2017-11-14 16:48:51 --> Total execution time: 0.0860
INFO - 2017-11-14 16:48:57 --> Config Class Initialized
INFO - 2017-11-14 16:48:57 --> Hooks Class Initialized
DEBUG - 2017-11-14 16:48:57 --> UTF-8 Support Enabled
INFO - 2017-11-14 16:48:57 --> Utf8 Class Initialized
INFO - 2017-11-14 16:48:57 --> URI Class Initialized
INFO - 2017-11-14 16:48:57 --> Router Class Initialized
INFO - 2017-11-14 16:48:57 --> Output Class Initialized
INFO - 2017-11-14 16:48:57 --> Security Class Initialized
DEBUG - 2017-11-14 16:48:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 16:48:57 --> Input Class Initialized
INFO - 2017-11-14 16:48:57 --> Language Class Initialized
INFO - 2017-11-14 16:48:57 --> Language Class Initialized
INFO - 2017-11-14 16:48:57 --> Config Class Initialized
INFO - 2017-11-14 16:48:57 --> Loader Class Initialized
DEBUG - 2017-11-14 16:48:57 --> Config file loaded: D:\xampp\htdocs\construction_bay\application\config/construct-data.php
INFO - 2017-11-14 16:48:57 --> Helper loaded: url_helper
INFO - 2017-11-14 16:48:57 --> Helper loaded: form_helper
INFO - 2017-11-14 16:48:58 --> Helper loaded: date_helper
INFO - 2017-11-14 16:48:58 --> Helper loaded: util_helper
INFO - 2017-11-14 16:48:58 --> Helper loaded: text_helper
INFO - 2017-11-14 16:48:58 --> Helper loaded: string_helper
INFO - 2017-11-14 16:48:58 --> Database Driver Class Initialized
DEBUG - 2017-11-14 16:48:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-14 16:48:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-14 16:48:58 --> Email Class Initialized
INFO - 2017-11-14 16:48:58 --> Controller Class Initialized
INFO - 2017-11-14 16:48:58 --> Model Class Initialized
DEBUG - 2017-11-14 16:48:58 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_model.php
INFO - 2017-11-14 16:48:58 --> Model Class Initialized
DEBUG - 2017-11-14 16:48:58 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_functions_model.php
INFO - 2017-11-14 16:48:58 --> Model Class Initialized
DEBUG - 2017-11-14 16:48:58 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header_menu.php
DEBUG - 2017-11-14 16:48:58 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header.php
DEBUG - 2017-11-14 16:48:58 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\products-services.php
DEBUG - 2017-11-14 16:48:58 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/footer_nav.php
DEBUG - 2017-11-14 16:48:58 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/footer.php
INFO - 2017-11-14 16:48:58 --> Final output sent to browser
DEBUG - 2017-11-14 16:48:58 --> Total execution time: 0.0840
INFO - 2017-11-14 16:49:15 --> Config Class Initialized
INFO - 2017-11-14 16:49:15 --> Hooks Class Initialized
DEBUG - 2017-11-14 16:49:15 --> UTF-8 Support Enabled
INFO - 2017-11-14 16:49:15 --> Utf8 Class Initialized
INFO - 2017-11-14 16:49:15 --> URI Class Initialized
DEBUG - 2017-11-14 16:49:15 --> No URI present. Default controller set.
INFO - 2017-11-14 16:49:15 --> Router Class Initialized
INFO - 2017-11-14 16:49:15 --> Output Class Initialized
INFO - 2017-11-14 16:49:15 --> Security Class Initialized
DEBUG - 2017-11-14 16:49:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 16:49:15 --> Input Class Initialized
INFO - 2017-11-14 16:49:15 --> Language Class Initialized
INFO - 2017-11-14 16:49:15 --> Language Class Initialized
INFO - 2017-11-14 16:49:15 --> Config Class Initialized
INFO - 2017-11-14 16:49:15 --> Loader Class Initialized
DEBUG - 2017-11-14 16:49:15 --> Config file loaded: D:\xampp\htdocs\construction_bay\application\config/construct-data.php
INFO - 2017-11-14 16:49:15 --> Helper loaded: url_helper
INFO - 2017-11-14 16:49:15 --> Helper loaded: form_helper
INFO - 2017-11-14 16:49:15 --> Helper loaded: date_helper
INFO - 2017-11-14 16:49:15 --> Helper loaded: util_helper
INFO - 2017-11-14 16:49:15 --> Helper loaded: text_helper
INFO - 2017-11-14 16:49:15 --> Helper loaded: string_helper
INFO - 2017-11-14 16:49:15 --> Database Driver Class Initialized
DEBUG - 2017-11-14 16:49:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-14 16:49:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-14 16:49:15 --> Email Class Initialized
INFO - 2017-11-14 16:49:15 --> Controller Class Initialized
DEBUG - 2017-11-14 16:49:15 --> Home MX_Controller Initialized
INFO - 2017-11-14 16:49:15 --> Model Class Initialized
DEBUG - 2017-11-14 16:49:15 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_model.php
INFO - 2017-11-14 16:49:15 --> Model Class Initialized
DEBUG - 2017-11-14 16:49:15 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header_menu.php
DEBUG - 2017-11-14 16:49:15 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header.php
DEBUG - 2017-11-14 16:49:15 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/slider.php
DEBUG - 2017-11-14 16:49:15 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/index_body.php
DEBUG - 2017-11-14 16:49:15 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/home_footer_nav.php
DEBUG - 2017-11-14 16:49:15 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/index_footer.php
INFO - 2017-11-14 16:49:15 --> Final output sent to browser
DEBUG - 2017-11-14 16:49:15 --> Total execution time: 0.1160
INFO - 2017-11-14 16:49:32 --> Config Class Initialized
INFO - 2017-11-14 16:49:32 --> Hooks Class Initialized
DEBUG - 2017-11-14 16:49:32 --> UTF-8 Support Enabled
INFO - 2017-11-14 16:49:32 --> Utf8 Class Initialized
INFO - 2017-11-14 16:49:32 --> URI Class Initialized
INFO - 2017-11-14 16:49:32 --> Router Class Initialized
INFO - 2017-11-14 16:49:32 --> Output Class Initialized
INFO - 2017-11-14 16:49:32 --> Security Class Initialized
DEBUG - 2017-11-14 16:49:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 16:49:32 --> Input Class Initialized
INFO - 2017-11-14 16:49:32 --> Language Class Initialized
INFO - 2017-11-14 16:49:32 --> Language Class Initialized
INFO - 2017-11-14 16:49:32 --> Config Class Initialized
INFO - 2017-11-14 16:49:32 --> Loader Class Initialized
DEBUG - 2017-11-14 16:49:32 --> Config file loaded: D:\xampp\htdocs\construction_bay\application\config/construct-data.php
INFO - 2017-11-14 16:49:32 --> Helper loaded: url_helper
INFO - 2017-11-14 16:49:32 --> Helper loaded: form_helper
INFO - 2017-11-14 16:49:32 --> Helper loaded: date_helper
INFO - 2017-11-14 16:49:32 --> Helper loaded: util_helper
INFO - 2017-11-14 16:49:32 --> Helper loaded: text_helper
INFO - 2017-11-14 16:49:32 --> Helper loaded: string_helper
INFO - 2017-11-14 16:49:32 --> Database Driver Class Initialized
DEBUG - 2017-11-14 16:49:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-14 16:49:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-14 16:49:32 --> Email Class Initialized
INFO - 2017-11-14 16:49:32 --> Controller Class Initialized
INFO - 2017-11-14 16:49:32 --> Model Class Initialized
DEBUG - 2017-11-14 16:49:32 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_model.php
INFO - 2017-11-14 16:49:32 --> Model Class Initialized
DEBUG - 2017-11-14 16:49:32 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_functions_model.php
INFO - 2017-11-14 16:49:32 --> Model Class Initialized
DEBUG - 2017-11-14 16:49:32 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header_menu.php
DEBUG - 2017-11-14 16:49:32 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header.php
DEBUG - 2017-11-14 16:49:32 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\art-work.php
DEBUG - 2017-11-14 16:49:32 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/footer_nav.php
DEBUG - 2017-11-14 16:49:32 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/footer.php
INFO - 2017-11-14 16:49:32 --> Final output sent to browser
DEBUG - 2017-11-14 16:49:32 --> Total execution time: 0.0900
INFO - 2017-11-14 16:49:38 --> Config Class Initialized
INFO - 2017-11-14 16:49:38 --> Hooks Class Initialized
DEBUG - 2017-11-14 16:49:38 --> UTF-8 Support Enabled
INFO - 2017-11-14 16:49:38 --> Utf8 Class Initialized
INFO - 2017-11-14 16:49:38 --> URI Class Initialized
DEBUG - 2017-11-14 16:49:38 --> No URI present. Default controller set.
INFO - 2017-11-14 16:49:38 --> Router Class Initialized
INFO - 2017-11-14 16:49:38 --> Output Class Initialized
INFO - 2017-11-14 16:49:38 --> Security Class Initialized
DEBUG - 2017-11-14 16:49:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 16:49:38 --> Input Class Initialized
INFO - 2017-11-14 16:49:38 --> Language Class Initialized
INFO - 2017-11-14 16:49:38 --> Language Class Initialized
INFO - 2017-11-14 16:49:38 --> Config Class Initialized
INFO - 2017-11-14 16:49:38 --> Loader Class Initialized
DEBUG - 2017-11-14 16:49:38 --> Config file loaded: D:\xampp\htdocs\construction_bay\application\config/construct-data.php
INFO - 2017-11-14 16:49:38 --> Helper loaded: url_helper
INFO - 2017-11-14 16:49:38 --> Helper loaded: form_helper
INFO - 2017-11-14 16:49:38 --> Helper loaded: date_helper
INFO - 2017-11-14 16:49:38 --> Helper loaded: util_helper
INFO - 2017-11-14 16:49:38 --> Helper loaded: text_helper
INFO - 2017-11-14 16:49:38 --> Helper loaded: string_helper
INFO - 2017-11-14 16:49:38 --> Database Driver Class Initialized
DEBUG - 2017-11-14 16:49:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-14 16:49:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-14 16:49:38 --> Email Class Initialized
INFO - 2017-11-14 16:49:38 --> Controller Class Initialized
DEBUG - 2017-11-14 16:49:38 --> Home MX_Controller Initialized
INFO - 2017-11-14 16:49:38 --> Model Class Initialized
DEBUG - 2017-11-14 16:49:38 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_model.php
INFO - 2017-11-14 16:49:38 --> Model Class Initialized
DEBUG - 2017-11-14 16:49:38 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header_menu.php
DEBUG - 2017-11-14 16:49:38 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header.php
DEBUG - 2017-11-14 16:49:38 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/slider.php
DEBUG - 2017-11-14 16:49:38 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/index_body.php
DEBUG - 2017-11-14 16:49:38 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/home_footer_nav.php
DEBUG - 2017-11-14 16:49:38 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/index_footer.php
INFO - 2017-11-14 16:49:38 --> Final output sent to browser
DEBUG - 2017-11-14 16:49:38 --> Total execution time: 0.0910
INFO - 2017-11-14 16:49:45 --> Config Class Initialized
INFO - 2017-11-14 16:49:45 --> Hooks Class Initialized
DEBUG - 2017-11-14 16:49:45 --> UTF-8 Support Enabled
INFO - 2017-11-14 16:49:45 --> Utf8 Class Initialized
INFO - 2017-11-14 16:49:45 --> URI Class Initialized
INFO - 2017-11-14 16:49:45 --> Router Class Initialized
INFO - 2017-11-14 16:49:45 --> Output Class Initialized
INFO - 2017-11-14 16:49:45 --> Security Class Initialized
DEBUG - 2017-11-14 16:49:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 16:49:45 --> Input Class Initialized
INFO - 2017-11-14 16:49:45 --> Language Class Initialized
INFO - 2017-11-14 16:49:45 --> Language Class Initialized
INFO - 2017-11-14 16:49:45 --> Config Class Initialized
INFO - 2017-11-14 16:49:45 --> Loader Class Initialized
DEBUG - 2017-11-14 16:49:45 --> Config file loaded: D:\xampp\htdocs\construction_bay\application\config/construct-data.php
INFO - 2017-11-14 16:49:45 --> Helper loaded: url_helper
INFO - 2017-11-14 16:49:45 --> Helper loaded: form_helper
INFO - 2017-11-14 16:49:45 --> Helper loaded: date_helper
INFO - 2017-11-14 16:49:45 --> Helper loaded: util_helper
INFO - 2017-11-14 16:49:45 --> Helper loaded: text_helper
INFO - 2017-11-14 16:49:45 --> Helper loaded: string_helper
INFO - 2017-11-14 16:49:45 --> Database Driver Class Initialized
DEBUG - 2017-11-14 16:49:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-14 16:49:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-14 16:49:45 --> Email Class Initialized
INFO - 2017-11-14 16:49:45 --> Controller Class Initialized
INFO - 2017-11-14 16:49:45 --> Model Class Initialized
DEBUG - 2017-11-14 16:49:45 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_model.php
INFO - 2017-11-14 16:49:45 --> Model Class Initialized
DEBUG - 2017-11-14 16:49:45 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_functions_model.php
INFO - 2017-11-14 16:49:45 --> Model Class Initialized
DEBUG - 2017-11-14 16:49:45 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header_menu.php
DEBUG - 2017-11-14 16:49:45 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header.php
DEBUG - 2017-11-14 16:49:45 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\interior-design.php
DEBUG - 2017-11-14 16:49:45 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/footer_nav.php
DEBUG - 2017-11-14 16:49:45 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/footer.php
INFO - 2017-11-14 16:49:45 --> Final output sent to browser
DEBUG - 2017-11-14 16:49:45 --> Total execution time: 0.1090
INFO - 2017-11-14 16:49:55 --> Config Class Initialized
INFO - 2017-11-14 16:49:55 --> Hooks Class Initialized
DEBUG - 2017-11-14 16:49:55 --> UTF-8 Support Enabled
INFO - 2017-11-14 16:49:55 --> Utf8 Class Initialized
INFO - 2017-11-14 16:49:55 --> URI Class Initialized
INFO - 2017-11-14 16:49:55 --> Router Class Initialized
INFO - 2017-11-14 16:49:55 --> Output Class Initialized
INFO - 2017-11-14 16:49:55 --> Security Class Initialized
DEBUG - 2017-11-14 16:49:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 16:49:55 --> Input Class Initialized
INFO - 2017-11-14 16:49:55 --> Language Class Initialized
ERROR - 2017-11-14 16:49:55 --> 404 Page Not Found: /index
INFO - 2017-11-14 16:51:53 --> Config Class Initialized
INFO - 2017-11-14 16:51:53 --> Hooks Class Initialized
DEBUG - 2017-11-14 16:51:53 --> UTF-8 Support Enabled
INFO - 2017-11-14 16:51:53 --> Utf8 Class Initialized
INFO - 2017-11-14 16:51:53 --> URI Class Initialized
INFO - 2017-11-14 16:51:53 --> Router Class Initialized
INFO - 2017-11-14 16:51:53 --> Output Class Initialized
INFO - 2017-11-14 16:51:53 --> Security Class Initialized
DEBUG - 2017-11-14 16:51:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 16:51:53 --> Input Class Initialized
INFO - 2017-11-14 16:51:53 --> Language Class Initialized
INFO - 2017-11-14 16:51:53 --> Language Class Initialized
INFO - 2017-11-14 16:51:53 --> Config Class Initialized
INFO - 2017-11-14 16:51:53 --> Loader Class Initialized
DEBUG - 2017-11-14 16:51:53 --> Config file loaded: D:\xampp\htdocs\construction_bay\application\config/construct-data.php
INFO - 2017-11-14 16:51:53 --> Helper loaded: url_helper
INFO - 2017-11-14 16:51:53 --> Helper loaded: form_helper
INFO - 2017-11-14 16:51:53 --> Helper loaded: date_helper
INFO - 2017-11-14 16:51:53 --> Helper loaded: util_helper
INFO - 2017-11-14 16:51:53 --> Helper loaded: text_helper
INFO - 2017-11-14 16:51:53 --> Helper loaded: string_helper
INFO - 2017-11-14 16:51:53 --> Database Driver Class Initialized
DEBUG - 2017-11-14 16:51:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-14 16:51:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-14 16:51:53 --> Email Class Initialized
INFO - 2017-11-14 16:51:53 --> Controller Class Initialized
INFO - 2017-11-14 16:51:53 --> Model Class Initialized
DEBUG - 2017-11-14 16:51:53 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_model.php
INFO - 2017-11-14 16:51:53 --> Model Class Initialized
DEBUG - 2017-11-14 16:51:53 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_functions_model.php
INFO - 2017-11-14 16:51:53 --> Model Class Initialized
DEBUG - 2017-11-14 16:51:53 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header_menu.php
DEBUG - 2017-11-14 16:51:53 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header.php
DEBUG - 2017-11-14 16:51:53 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\products-services.php
DEBUG - 2017-11-14 16:51:53 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/footer_nav.php
DEBUG - 2017-11-14 16:51:53 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/footer.php
INFO - 2017-11-14 16:51:53 --> Final output sent to browser
DEBUG - 2017-11-14 16:51:53 --> Total execution time: 0.1030
INFO - 2017-11-14 16:51:59 --> Config Class Initialized
INFO - 2017-11-14 16:51:59 --> Hooks Class Initialized
DEBUG - 2017-11-14 16:51:59 --> UTF-8 Support Enabled
INFO - 2017-11-14 16:51:59 --> Utf8 Class Initialized
INFO - 2017-11-14 16:51:59 --> URI Class Initialized
INFO - 2017-11-14 16:51:59 --> Router Class Initialized
INFO - 2017-11-14 16:51:59 --> Output Class Initialized
INFO - 2017-11-14 16:51:59 --> Security Class Initialized
DEBUG - 2017-11-14 16:51:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 16:51:59 --> Input Class Initialized
INFO - 2017-11-14 16:51:59 --> Language Class Initialized
INFO - 2017-11-14 16:51:59 --> Language Class Initialized
INFO - 2017-11-14 16:51:59 --> Config Class Initialized
INFO - 2017-11-14 16:51:59 --> Loader Class Initialized
DEBUG - 2017-11-14 16:51:59 --> Config file loaded: D:\xampp\htdocs\construction_bay\application\config/construct-data.php
INFO - 2017-11-14 16:51:59 --> Helper loaded: url_helper
INFO - 2017-11-14 16:51:59 --> Helper loaded: form_helper
INFO - 2017-11-14 16:51:59 --> Helper loaded: date_helper
INFO - 2017-11-14 16:51:59 --> Helper loaded: util_helper
INFO - 2017-11-14 16:51:59 --> Helper loaded: text_helper
INFO - 2017-11-14 16:51:59 --> Helper loaded: string_helper
INFO - 2017-11-14 16:51:59 --> Database Driver Class Initialized
DEBUG - 2017-11-14 16:51:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-14 16:51:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-14 16:51:59 --> Email Class Initialized
INFO - 2017-11-14 16:51:59 --> Controller Class Initialized
INFO - 2017-11-14 16:51:59 --> Model Class Initialized
DEBUG - 2017-11-14 16:51:59 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_model.php
INFO - 2017-11-14 16:51:59 --> Model Class Initialized
DEBUG - 2017-11-14 16:51:59 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_functions_model.php
INFO - 2017-11-14 16:51:59 --> Model Class Initialized
DEBUG - 2017-11-14 16:51:59 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header_menu.php
DEBUG - 2017-11-14 16:51:59 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\companies/companies_header.php
DEBUG - 2017-11-14 16:51:59 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\companies/companies_page.php
DEBUG - 2017-11-14 16:51:59 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/home_footer_nav.php
DEBUG - 2017-11-14 16:51:59 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\companies/companies_footer.php
INFO - 2017-11-14 16:51:59 --> Final output sent to browser
DEBUG - 2017-11-14 16:51:59 --> Total execution time: 0.1180
INFO - 2017-11-14 16:52:00 --> Config Class Initialized
INFO - 2017-11-14 16:52:00 --> Hooks Class Initialized
DEBUG - 2017-11-14 16:52:00 --> UTF-8 Support Enabled
INFO - 2017-11-14 16:52:00 --> Utf8 Class Initialized
INFO - 2017-11-14 16:52:00 --> URI Class Initialized
INFO - 2017-11-14 16:52:00 --> Router Class Initialized
INFO - 2017-11-14 16:52:00 --> Output Class Initialized
INFO - 2017-11-14 16:52:00 --> Security Class Initialized
DEBUG - 2017-11-14 16:52:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 16:52:00 --> Input Class Initialized
INFO - 2017-11-14 16:52:00 --> Language Class Initialized
ERROR - 2017-11-14 16:52:00 --> 404 Page Not Found: Companies/companies
INFO - 2017-11-14 16:52:04 --> Config Class Initialized
INFO - 2017-11-14 16:52:04 --> Hooks Class Initialized
DEBUG - 2017-11-14 16:52:04 --> UTF-8 Support Enabled
INFO - 2017-11-14 16:52:04 --> Utf8 Class Initialized
INFO - 2017-11-14 16:52:04 --> URI Class Initialized
INFO - 2017-11-14 16:52:04 --> Router Class Initialized
INFO - 2017-11-14 16:52:04 --> Output Class Initialized
INFO - 2017-11-14 16:52:04 --> Security Class Initialized
DEBUG - 2017-11-14 16:52:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 16:52:04 --> Input Class Initialized
INFO - 2017-11-14 16:52:04 --> Language Class Initialized
INFO - 2017-11-14 16:52:04 --> Language Class Initialized
INFO - 2017-11-14 16:52:04 --> Config Class Initialized
INFO - 2017-11-14 16:52:04 --> Loader Class Initialized
DEBUG - 2017-11-14 16:52:04 --> Config file loaded: D:\xampp\htdocs\construction_bay\application\config/construct-data.php
INFO - 2017-11-14 16:52:04 --> Helper loaded: url_helper
INFO - 2017-11-14 16:52:04 --> Helper loaded: form_helper
INFO - 2017-11-14 16:52:04 --> Helper loaded: date_helper
INFO - 2017-11-14 16:52:04 --> Helper loaded: util_helper
INFO - 2017-11-14 16:52:04 --> Helper loaded: text_helper
INFO - 2017-11-14 16:52:04 --> Helper loaded: string_helper
INFO - 2017-11-14 16:52:04 --> Database Driver Class Initialized
DEBUG - 2017-11-14 16:52:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-14 16:52:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-14 16:52:04 --> Email Class Initialized
INFO - 2017-11-14 16:52:04 --> Controller Class Initialized
INFO - 2017-11-14 16:52:04 --> Model Class Initialized
DEBUG - 2017-11-14 16:52:04 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_model.php
INFO - 2017-11-14 16:52:04 --> Model Class Initialized
DEBUG - 2017-11-14 16:52:04 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_functions_model.php
INFO - 2017-11-14 16:52:04 --> Model Class Initialized
DEBUG - 2017-11-14 16:52:04 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header_menu.php
DEBUG - 2017-11-14 16:52:04 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header.php
DEBUG - 2017-11-14 16:52:04 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\products-services.php
DEBUG - 2017-11-14 16:52:04 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/footer_nav.php
DEBUG - 2017-11-14 16:52:04 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/footer.php
INFO - 2017-11-14 16:52:04 --> Final output sent to browser
DEBUG - 2017-11-14 16:52:04 --> Total execution time: 0.0630
INFO - 2017-11-14 16:52:10 --> Config Class Initialized
INFO - 2017-11-14 16:52:10 --> Hooks Class Initialized
DEBUG - 2017-11-14 16:52:10 --> UTF-8 Support Enabled
INFO - 2017-11-14 16:52:10 --> Utf8 Class Initialized
INFO - 2017-11-14 16:52:10 --> URI Class Initialized
INFO - 2017-11-14 16:52:10 --> Router Class Initialized
INFO - 2017-11-14 16:52:10 --> Output Class Initialized
INFO - 2017-11-14 16:52:10 --> Security Class Initialized
DEBUG - 2017-11-14 16:52:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 16:52:10 --> Input Class Initialized
INFO - 2017-11-14 16:52:10 --> Language Class Initialized
INFO - 2017-11-14 16:52:10 --> Language Class Initialized
INFO - 2017-11-14 16:52:10 --> Config Class Initialized
INFO - 2017-11-14 16:52:10 --> Loader Class Initialized
DEBUG - 2017-11-14 16:52:10 --> Config file loaded: D:\xampp\htdocs\construction_bay\application\config/construct-data.php
INFO - 2017-11-14 16:52:10 --> Helper loaded: url_helper
INFO - 2017-11-14 16:52:10 --> Helper loaded: form_helper
INFO - 2017-11-14 16:52:10 --> Helper loaded: date_helper
INFO - 2017-11-14 16:52:10 --> Helper loaded: util_helper
INFO - 2017-11-14 16:52:10 --> Helper loaded: text_helper
INFO - 2017-11-14 16:52:10 --> Helper loaded: string_helper
INFO - 2017-11-14 16:52:10 --> Database Driver Class Initialized
DEBUG - 2017-11-14 16:52:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-14 16:52:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-14 16:52:11 --> Email Class Initialized
INFO - 2017-11-14 16:52:11 --> Controller Class Initialized
INFO - 2017-11-14 16:52:11 --> Model Class Initialized
DEBUG - 2017-11-14 16:52:11 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_model.php
INFO - 2017-11-14 16:52:11 --> Model Class Initialized
DEBUG - 2017-11-14 16:52:11 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_functions_model.php
INFO - 2017-11-14 16:52:11 --> Model Class Initialized
DEBUG - 2017-11-14 16:52:11 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header_menu.php
DEBUG - 2017-11-14 16:52:11 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header.php
DEBUG - 2017-11-14 16:52:11 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\products-services.php
DEBUG - 2017-11-14 16:52:11 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/footer_nav.php
DEBUG - 2017-11-14 16:52:11 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/footer.php
INFO - 2017-11-14 16:52:11 --> Final output sent to browser
DEBUG - 2017-11-14 16:52:11 --> Total execution time: 0.0560
INFO - 2017-11-14 16:52:13 --> Config Class Initialized
INFO - 2017-11-14 16:52:13 --> Hooks Class Initialized
DEBUG - 2017-11-14 16:52:13 --> UTF-8 Support Enabled
INFO - 2017-11-14 16:52:13 --> Utf8 Class Initialized
INFO - 2017-11-14 16:52:13 --> URI Class Initialized
INFO - 2017-11-14 16:52:13 --> Router Class Initialized
INFO - 2017-11-14 16:52:13 --> Output Class Initialized
INFO - 2017-11-14 16:52:13 --> Security Class Initialized
DEBUG - 2017-11-14 16:52:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 16:52:13 --> Input Class Initialized
INFO - 2017-11-14 16:52:13 --> Language Class Initialized
INFO - 2017-11-14 16:52:13 --> Language Class Initialized
INFO - 2017-11-14 16:52:13 --> Config Class Initialized
INFO - 2017-11-14 16:52:13 --> Loader Class Initialized
DEBUG - 2017-11-14 16:52:13 --> Config file loaded: D:\xampp\htdocs\construction_bay\application\config/construct-data.php
INFO - 2017-11-14 16:52:13 --> Helper loaded: url_helper
INFO - 2017-11-14 16:52:14 --> Helper loaded: form_helper
INFO - 2017-11-14 16:52:14 --> Helper loaded: date_helper
INFO - 2017-11-14 16:52:14 --> Helper loaded: util_helper
INFO - 2017-11-14 16:52:14 --> Helper loaded: text_helper
INFO - 2017-11-14 16:52:14 --> Helper loaded: string_helper
INFO - 2017-11-14 16:52:14 --> Database Driver Class Initialized
DEBUG - 2017-11-14 16:52:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-14 16:52:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-14 16:52:14 --> Email Class Initialized
INFO - 2017-11-14 16:52:14 --> Controller Class Initialized
INFO - 2017-11-14 16:52:14 --> Model Class Initialized
DEBUG - 2017-11-14 16:52:14 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_model.php
INFO - 2017-11-14 16:52:14 --> Model Class Initialized
DEBUG - 2017-11-14 16:52:14 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_functions_model.php
INFO - 2017-11-14 16:52:14 --> Model Class Initialized
DEBUG - 2017-11-14 16:52:14 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header_menu.php
DEBUG - 2017-11-14 16:52:14 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header.php
DEBUG - 2017-11-14 16:52:14 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\products-services.php
DEBUG - 2017-11-14 16:52:14 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/footer_nav.php
DEBUG - 2017-11-14 16:52:14 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/footer.php
INFO - 2017-11-14 16:52:14 --> Final output sent to browser
DEBUG - 2017-11-14 16:52:14 --> Total execution time: 0.0970
INFO - 2017-11-14 16:52:14 --> Config Class Initialized
INFO - 2017-11-14 16:52:14 --> Hooks Class Initialized
DEBUG - 2017-11-14 16:52:14 --> UTF-8 Support Enabled
INFO - 2017-11-14 16:52:14 --> Utf8 Class Initialized
INFO - 2017-11-14 16:52:14 --> URI Class Initialized
INFO - 2017-11-14 16:52:14 --> Router Class Initialized
INFO - 2017-11-14 16:52:14 --> Output Class Initialized
INFO - 2017-11-14 16:52:14 --> Security Class Initialized
DEBUG - 2017-11-14 16:52:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 16:52:14 --> Input Class Initialized
INFO - 2017-11-14 16:52:14 --> Language Class Initialized
INFO - 2017-11-14 16:52:14 --> Language Class Initialized
INFO - 2017-11-14 16:52:14 --> Config Class Initialized
INFO - 2017-11-14 16:52:14 --> Loader Class Initialized
DEBUG - 2017-11-14 16:52:14 --> Config file loaded: D:\xampp\htdocs\construction_bay\application\config/construct-data.php
INFO - 2017-11-14 16:52:14 --> Helper loaded: url_helper
INFO - 2017-11-14 16:52:14 --> Helper loaded: form_helper
INFO - 2017-11-14 16:52:14 --> Helper loaded: date_helper
INFO - 2017-11-14 16:52:14 --> Helper loaded: util_helper
INFO - 2017-11-14 16:52:14 --> Helper loaded: text_helper
INFO - 2017-11-14 16:52:14 --> Helper loaded: string_helper
INFO - 2017-11-14 16:52:14 --> Database Driver Class Initialized
DEBUG - 2017-11-14 16:52:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-14 16:52:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-14 16:52:14 --> Email Class Initialized
INFO - 2017-11-14 16:52:14 --> Controller Class Initialized
INFO - 2017-11-14 16:52:14 --> Model Class Initialized
DEBUG - 2017-11-14 16:52:14 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_model.php
INFO - 2017-11-14 16:52:14 --> Model Class Initialized
DEBUG - 2017-11-14 16:52:14 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_functions_model.php
INFO - 2017-11-14 16:52:14 --> Model Class Initialized
DEBUG - 2017-11-14 16:52:14 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header_menu.php
DEBUG - 2017-11-14 16:52:14 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header.php
DEBUG - 2017-11-14 16:52:14 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\interior-design.php
DEBUG - 2017-11-14 16:52:14 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/footer_nav.php
DEBUG - 2017-11-14 16:52:14 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/footer.php
INFO - 2017-11-14 16:52:14 --> Final output sent to browser
DEBUG - 2017-11-14 16:52:14 --> Total execution time: 0.0690
INFO - 2017-11-14 16:53:14 --> Config Class Initialized
INFO - 2017-11-14 16:53:14 --> Hooks Class Initialized
DEBUG - 2017-11-14 16:53:14 --> UTF-8 Support Enabled
INFO - 2017-11-14 16:53:14 --> Utf8 Class Initialized
INFO - 2017-11-14 16:53:14 --> URI Class Initialized
INFO - 2017-11-14 16:53:14 --> Router Class Initialized
INFO - 2017-11-14 16:53:14 --> Output Class Initialized
INFO - 2017-11-14 16:53:14 --> Security Class Initialized
DEBUG - 2017-11-14 16:53:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 16:53:14 --> Input Class Initialized
INFO - 2017-11-14 16:53:14 --> Language Class Initialized
INFO - 2017-11-14 16:53:14 --> Language Class Initialized
INFO - 2017-11-14 16:53:14 --> Config Class Initialized
INFO - 2017-11-14 16:53:14 --> Loader Class Initialized
DEBUG - 2017-11-14 16:53:14 --> Config file loaded: D:\xampp\htdocs\construction_bay\application\config/construct-data.php
INFO - 2017-11-14 16:53:14 --> Helper loaded: url_helper
INFO - 2017-11-14 16:53:14 --> Helper loaded: form_helper
INFO - 2017-11-14 16:53:14 --> Helper loaded: date_helper
INFO - 2017-11-14 16:53:14 --> Helper loaded: util_helper
INFO - 2017-11-14 16:53:14 --> Helper loaded: text_helper
INFO - 2017-11-14 16:53:14 --> Helper loaded: string_helper
INFO - 2017-11-14 16:53:14 --> Database Driver Class Initialized
DEBUG - 2017-11-14 16:53:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-14 16:53:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-14 16:53:14 --> Email Class Initialized
INFO - 2017-11-14 16:53:14 --> Controller Class Initialized
INFO - 2017-11-14 16:53:14 --> Model Class Initialized
DEBUG - 2017-11-14 16:53:14 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_model.php
INFO - 2017-11-14 16:53:14 --> Model Class Initialized
DEBUG - 2017-11-14 16:53:14 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_functions_model.php
INFO - 2017-11-14 16:53:14 --> Model Class Initialized
DEBUG - 2017-11-14 16:53:14 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header_menu.php
DEBUG - 2017-11-14 16:53:14 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header.php
DEBUG - 2017-11-14 16:53:14 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\products-services.php
DEBUG - 2017-11-14 16:53:14 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/footer_nav.php
DEBUG - 2017-11-14 16:53:14 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/footer.php
INFO - 2017-11-14 16:53:14 --> Final output sent to browser
DEBUG - 2017-11-14 16:53:14 --> Total execution time: 0.0670
INFO - 2017-11-14 16:53:17 --> Config Class Initialized
INFO - 2017-11-14 16:53:17 --> Hooks Class Initialized
DEBUG - 2017-11-14 16:53:17 --> UTF-8 Support Enabled
INFO - 2017-11-14 16:53:17 --> Utf8 Class Initialized
INFO - 2017-11-14 16:53:17 --> URI Class Initialized
INFO - 2017-11-14 16:53:17 --> Router Class Initialized
INFO - 2017-11-14 16:53:17 --> Output Class Initialized
INFO - 2017-11-14 16:53:17 --> Security Class Initialized
DEBUG - 2017-11-14 16:53:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 16:53:17 --> Input Class Initialized
INFO - 2017-11-14 16:53:17 --> Language Class Initialized
INFO - 2017-11-14 16:53:17 --> Language Class Initialized
INFO - 2017-11-14 16:53:17 --> Config Class Initialized
INFO - 2017-11-14 16:53:17 --> Loader Class Initialized
DEBUG - 2017-11-14 16:53:17 --> Config file loaded: D:\xampp\htdocs\construction_bay\application\config/construct-data.php
INFO - 2017-11-14 16:53:17 --> Helper loaded: url_helper
INFO - 2017-11-14 16:53:17 --> Helper loaded: form_helper
INFO - 2017-11-14 16:53:17 --> Helper loaded: date_helper
INFO - 2017-11-14 16:53:17 --> Helper loaded: util_helper
INFO - 2017-11-14 16:53:17 --> Helper loaded: text_helper
INFO - 2017-11-14 16:53:17 --> Helper loaded: string_helper
INFO - 2017-11-14 16:53:17 --> Database Driver Class Initialized
DEBUG - 2017-11-14 16:53:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-14 16:53:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-14 16:53:17 --> Email Class Initialized
INFO - 2017-11-14 16:53:17 --> Controller Class Initialized
INFO - 2017-11-14 16:53:17 --> Model Class Initialized
DEBUG - 2017-11-14 16:53:17 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_model.php
INFO - 2017-11-14 16:53:17 --> Model Class Initialized
DEBUG - 2017-11-14 16:53:17 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_functions_model.php
INFO - 2017-11-14 16:53:17 --> Model Class Initialized
DEBUG - 2017-11-14 16:53:17 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header_menu.php
DEBUG - 2017-11-14 16:53:17 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\companies/companies_header.php
DEBUG - 2017-11-14 16:53:17 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\companies/companies_page.php
DEBUG - 2017-11-14 16:53:17 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/home_footer_nav.php
DEBUG - 2017-11-14 16:53:17 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\companies/companies_footer.php
INFO - 2017-11-14 16:53:17 --> Final output sent to browser
DEBUG - 2017-11-14 16:53:17 --> Total execution time: 0.0970
INFO - 2017-11-14 16:53:18 --> Config Class Initialized
INFO - 2017-11-14 16:53:18 --> Hooks Class Initialized
DEBUG - 2017-11-14 16:53:18 --> UTF-8 Support Enabled
INFO - 2017-11-14 16:53:18 --> Utf8 Class Initialized
INFO - 2017-11-14 16:53:18 --> URI Class Initialized
INFO - 2017-11-14 16:53:18 --> Router Class Initialized
INFO - 2017-11-14 16:53:18 --> Output Class Initialized
INFO - 2017-11-14 16:53:18 --> Security Class Initialized
DEBUG - 2017-11-14 16:53:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 16:53:18 --> Input Class Initialized
INFO - 2017-11-14 16:53:18 --> Language Class Initialized
ERROR - 2017-11-14 16:53:18 --> 404 Page Not Found: Companies/companies
INFO - 2017-11-14 16:53:42 --> Config Class Initialized
INFO - 2017-11-14 16:53:42 --> Hooks Class Initialized
DEBUG - 2017-11-14 16:53:42 --> UTF-8 Support Enabled
INFO - 2017-11-14 16:53:42 --> Utf8 Class Initialized
INFO - 2017-11-14 16:53:42 --> URI Class Initialized
INFO - 2017-11-14 16:53:42 --> Router Class Initialized
INFO - 2017-11-14 16:53:42 --> Output Class Initialized
INFO - 2017-11-14 16:53:42 --> Security Class Initialized
DEBUG - 2017-11-14 16:53:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 16:53:42 --> Input Class Initialized
INFO - 2017-11-14 16:53:42 --> Language Class Initialized
INFO - 2017-11-14 16:53:42 --> Language Class Initialized
INFO - 2017-11-14 16:53:42 --> Config Class Initialized
INFO - 2017-11-14 16:53:42 --> Loader Class Initialized
DEBUG - 2017-11-14 16:53:42 --> Config file loaded: D:\xampp\htdocs\construction_bay\application\config/construct-data.php
INFO - 2017-11-14 16:53:42 --> Helper loaded: url_helper
INFO - 2017-11-14 16:53:42 --> Helper loaded: form_helper
INFO - 2017-11-14 16:53:42 --> Helper loaded: date_helper
INFO - 2017-11-14 16:53:42 --> Helper loaded: util_helper
INFO - 2017-11-14 16:53:42 --> Helper loaded: text_helper
INFO - 2017-11-14 16:53:42 --> Helper loaded: string_helper
INFO - 2017-11-14 16:53:42 --> Database Driver Class Initialized
DEBUG - 2017-11-14 16:53:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-14 16:53:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-14 16:53:42 --> Email Class Initialized
INFO - 2017-11-14 16:53:42 --> Controller Class Initialized
INFO - 2017-11-14 16:53:42 --> Model Class Initialized
DEBUG - 2017-11-14 16:53:42 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_model.php
INFO - 2017-11-14 16:53:42 --> Model Class Initialized
DEBUG - 2017-11-14 16:53:42 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_functions_model.php
INFO - 2017-11-14 16:53:42 --> Model Class Initialized
DEBUG - 2017-11-14 16:53:42 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header_menu.php
DEBUG - 2017-11-14 16:53:42 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header.php
DEBUG - 2017-11-14 16:53:42 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\products-services.php
DEBUG - 2017-11-14 16:53:42 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/footer_nav.php
DEBUG - 2017-11-14 16:53:42 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/footer.php
INFO - 2017-11-14 16:53:42 --> Final output sent to browser
DEBUG - 2017-11-14 16:53:42 --> Total execution time: 0.0850
INFO - 2017-11-14 16:53:44 --> Config Class Initialized
INFO - 2017-11-14 16:53:44 --> Hooks Class Initialized
DEBUG - 2017-11-14 16:53:44 --> UTF-8 Support Enabled
INFO - 2017-11-14 16:53:44 --> Utf8 Class Initialized
INFO - 2017-11-14 16:53:44 --> URI Class Initialized
INFO - 2017-11-14 16:53:44 --> Router Class Initialized
INFO - 2017-11-14 16:53:44 --> Output Class Initialized
INFO - 2017-11-14 16:53:44 --> Security Class Initialized
DEBUG - 2017-11-14 16:53:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 16:53:44 --> Input Class Initialized
INFO - 2017-11-14 16:53:44 --> Language Class Initialized
INFO - 2017-11-14 16:53:44 --> Language Class Initialized
INFO - 2017-11-14 16:53:44 --> Config Class Initialized
INFO - 2017-11-14 16:53:44 --> Loader Class Initialized
DEBUG - 2017-11-14 16:53:44 --> Config file loaded: D:\xampp\htdocs\construction_bay\application\config/construct-data.php
INFO - 2017-11-14 16:53:44 --> Helper loaded: url_helper
INFO - 2017-11-14 16:53:44 --> Helper loaded: form_helper
INFO - 2017-11-14 16:53:44 --> Helper loaded: date_helper
INFO - 2017-11-14 16:53:44 --> Helper loaded: util_helper
INFO - 2017-11-14 16:53:44 --> Helper loaded: text_helper
INFO - 2017-11-14 16:53:44 --> Helper loaded: string_helper
INFO - 2017-11-14 16:53:44 --> Database Driver Class Initialized
DEBUG - 2017-11-14 16:53:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-14 16:53:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-14 16:53:44 --> Email Class Initialized
INFO - 2017-11-14 16:53:44 --> Controller Class Initialized
INFO - 2017-11-14 16:53:44 --> Model Class Initialized
DEBUG - 2017-11-14 16:53:44 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_model.php
INFO - 2017-11-14 16:53:44 --> Model Class Initialized
DEBUG - 2017-11-14 16:53:44 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_functions_model.php
INFO - 2017-11-14 16:53:44 --> Model Class Initialized
DEBUG - 2017-11-14 16:53:44 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header_menu.php
DEBUG - 2017-11-14 16:53:44 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header.php
DEBUG - 2017-11-14 16:53:44 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\interior-design.php
DEBUG - 2017-11-14 16:53:44 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/footer_nav.php
DEBUG - 2017-11-14 16:53:44 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/footer.php
INFO - 2017-11-14 16:53:44 --> Final output sent to browser
DEBUG - 2017-11-14 16:53:44 --> Total execution time: 0.0680
INFO - 2017-11-14 16:53:46 --> Config Class Initialized
INFO - 2017-11-14 16:53:46 --> Hooks Class Initialized
DEBUG - 2017-11-14 16:53:46 --> UTF-8 Support Enabled
INFO - 2017-11-14 16:53:46 --> Utf8 Class Initialized
INFO - 2017-11-14 16:53:46 --> URI Class Initialized
DEBUG - 2017-11-14 16:53:46 --> No URI present. Default controller set.
INFO - 2017-11-14 16:53:46 --> Router Class Initialized
INFO - 2017-11-14 16:53:46 --> Output Class Initialized
INFO - 2017-11-14 16:53:46 --> Security Class Initialized
DEBUG - 2017-11-14 16:53:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 16:53:46 --> Input Class Initialized
INFO - 2017-11-14 16:53:46 --> Language Class Initialized
INFO - 2017-11-14 16:53:46 --> Language Class Initialized
INFO - 2017-11-14 16:53:46 --> Config Class Initialized
INFO - 2017-11-14 16:53:46 --> Loader Class Initialized
DEBUG - 2017-11-14 16:53:46 --> Config file loaded: D:\xampp\htdocs\construction_bay\application\config/construct-data.php
INFO - 2017-11-14 16:53:46 --> Helper loaded: url_helper
INFO - 2017-11-14 16:53:46 --> Helper loaded: form_helper
INFO - 2017-11-14 16:53:46 --> Helper loaded: date_helper
INFO - 2017-11-14 16:53:46 --> Helper loaded: util_helper
INFO - 2017-11-14 16:53:46 --> Helper loaded: text_helper
INFO - 2017-11-14 16:53:46 --> Helper loaded: string_helper
INFO - 2017-11-14 16:53:46 --> Database Driver Class Initialized
DEBUG - 2017-11-14 16:53:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-14 16:53:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-14 16:53:46 --> Email Class Initialized
INFO - 2017-11-14 16:53:46 --> Controller Class Initialized
DEBUG - 2017-11-14 16:53:46 --> Home MX_Controller Initialized
INFO - 2017-11-14 16:53:46 --> Model Class Initialized
DEBUG - 2017-11-14 16:53:46 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_model.php
INFO - 2017-11-14 16:53:46 --> Model Class Initialized
DEBUG - 2017-11-14 16:53:46 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header_menu.php
DEBUG - 2017-11-14 16:53:46 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header.php
DEBUG - 2017-11-14 16:53:46 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/slider.php
DEBUG - 2017-11-14 16:53:46 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/index_body.php
DEBUG - 2017-11-14 16:53:46 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/home_footer_nav.php
DEBUG - 2017-11-14 16:53:46 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/index_footer.php
INFO - 2017-11-14 16:53:46 --> Final output sent to browser
DEBUG - 2017-11-14 16:53:46 --> Total execution time: 0.0670
INFO - 2017-11-14 16:55:42 --> Config Class Initialized
INFO - 2017-11-14 16:55:42 --> Hooks Class Initialized
DEBUG - 2017-11-14 16:55:42 --> UTF-8 Support Enabled
INFO - 2017-11-14 16:55:42 --> Utf8 Class Initialized
INFO - 2017-11-14 16:55:42 --> URI Class Initialized
DEBUG - 2017-11-14 16:55:42 --> No URI present. Default controller set.
INFO - 2017-11-14 16:55:42 --> Router Class Initialized
INFO - 2017-11-14 16:55:42 --> Output Class Initialized
INFO - 2017-11-14 16:55:42 --> Security Class Initialized
DEBUG - 2017-11-14 16:55:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 16:55:42 --> Input Class Initialized
INFO - 2017-11-14 16:55:42 --> Language Class Initialized
INFO - 2017-11-14 16:55:42 --> Language Class Initialized
INFO - 2017-11-14 16:55:42 --> Config Class Initialized
INFO - 2017-11-14 16:55:42 --> Loader Class Initialized
DEBUG - 2017-11-14 16:55:42 --> Config file loaded: D:\xampp\htdocs\construction_bay\application\config/construct-data.php
INFO - 2017-11-14 16:55:42 --> Helper loaded: url_helper
INFO - 2017-11-14 16:55:42 --> Helper loaded: form_helper
INFO - 2017-11-14 16:55:42 --> Helper loaded: date_helper
INFO - 2017-11-14 16:55:42 --> Helper loaded: util_helper
INFO - 2017-11-14 16:55:42 --> Helper loaded: text_helper
INFO - 2017-11-14 16:55:42 --> Helper loaded: string_helper
INFO - 2017-11-14 16:55:42 --> Database Driver Class Initialized
DEBUG - 2017-11-14 16:55:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-14 16:55:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-14 16:55:42 --> Email Class Initialized
INFO - 2017-11-14 16:55:42 --> Controller Class Initialized
DEBUG - 2017-11-14 16:55:42 --> Home MX_Controller Initialized
INFO - 2017-11-14 16:55:42 --> Model Class Initialized
DEBUG - 2017-11-14 16:55:42 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_model.php
INFO - 2017-11-14 16:55:42 --> Model Class Initialized
DEBUG - 2017-11-14 16:55:42 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header_menu.php
DEBUG - 2017-11-14 16:55:42 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header.php
DEBUG - 2017-11-14 16:55:42 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/slider.php
DEBUG - 2017-11-14 16:55:42 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/index_body.php
DEBUG - 2017-11-14 16:55:42 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/home_footer_nav.php
DEBUG - 2017-11-14 16:55:42 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/index_footer.php
INFO - 2017-11-14 16:55:42 --> Final output sent to browser
DEBUG - 2017-11-14 16:55:42 --> Total execution time: 0.0590
INFO - 2017-11-14 16:55:46 --> Config Class Initialized
INFO - 2017-11-14 16:55:46 --> Hooks Class Initialized
DEBUG - 2017-11-14 16:55:46 --> UTF-8 Support Enabled
INFO - 2017-11-14 16:55:46 --> Utf8 Class Initialized
INFO - 2017-11-14 16:55:46 --> URI Class Initialized
INFO - 2017-11-14 16:55:46 --> Router Class Initialized
INFO - 2017-11-14 16:55:46 --> Output Class Initialized
INFO - 2017-11-14 16:55:46 --> Security Class Initialized
DEBUG - 2017-11-14 16:55:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 16:55:46 --> Input Class Initialized
INFO - 2017-11-14 16:55:46 --> Language Class Initialized
INFO - 2017-11-14 16:55:46 --> Language Class Initialized
INFO - 2017-11-14 16:55:46 --> Config Class Initialized
INFO - 2017-11-14 16:55:46 --> Loader Class Initialized
DEBUG - 2017-11-14 16:55:46 --> Config file loaded: D:\xampp\htdocs\construction_bay\application\config/construct-data.php
INFO - 2017-11-14 16:55:46 --> Helper loaded: url_helper
INFO - 2017-11-14 16:55:46 --> Helper loaded: form_helper
INFO - 2017-11-14 16:55:46 --> Helper loaded: date_helper
INFO - 2017-11-14 16:55:46 --> Helper loaded: util_helper
INFO - 2017-11-14 16:55:46 --> Helper loaded: text_helper
INFO - 2017-11-14 16:55:46 --> Helper loaded: string_helper
INFO - 2017-11-14 16:55:46 --> Database Driver Class Initialized
DEBUG - 2017-11-14 16:55:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-14 16:55:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-14 16:55:46 --> Email Class Initialized
INFO - 2017-11-14 16:55:46 --> Controller Class Initialized
INFO - 2017-11-14 16:55:46 --> Model Class Initialized
DEBUG - 2017-11-14 16:55:46 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_model.php
INFO - 2017-11-14 16:55:46 --> Model Class Initialized
DEBUG - 2017-11-14 16:55:46 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_functions_model.php
INFO - 2017-11-14 16:55:46 --> Model Class Initialized
DEBUG - 2017-11-14 16:55:46 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header_menu.php
DEBUG - 2017-11-14 16:55:46 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header.php
DEBUG - 2017-11-14 16:55:46 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\products-services.php
DEBUG - 2017-11-14 16:55:46 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/footer_nav.php
DEBUG - 2017-11-14 16:55:46 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/footer.php
INFO - 2017-11-14 16:55:46 --> Final output sent to browser
DEBUG - 2017-11-14 16:55:46 --> Total execution time: 0.0690
INFO - 2017-11-14 16:55:49 --> Config Class Initialized
INFO - 2017-11-14 16:55:49 --> Hooks Class Initialized
DEBUG - 2017-11-14 16:55:49 --> UTF-8 Support Enabled
INFO - 2017-11-14 16:55:49 --> Utf8 Class Initialized
INFO - 2017-11-14 16:55:49 --> URI Class Initialized
INFO - 2017-11-14 16:55:49 --> Router Class Initialized
INFO - 2017-11-14 16:55:49 --> Output Class Initialized
INFO - 2017-11-14 16:55:49 --> Security Class Initialized
DEBUG - 2017-11-14 16:55:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 16:55:49 --> Input Class Initialized
INFO - 2017-11-14 16:55:49 --> Language Class Initialized
INFO - 2017-11-14 16:55:49 --> Language Class Initialized
INFO - 2017-11-14 16:55:49 --> Config Class Initialized
INFO - 2017-11-14 16:55:49 --> Loader Class Initialized
DEBUG - 2017-11-14 16:55:49 --> Config file loaded: D:\xampp\htdocs\construction_bay\application\config/construct-data.php
INFO - 2017-11-14 16:55:49 --> Helper loaded: url_helper
INFO - 2017-11-14 16:55:49 --> Helper loaded: form_helper
INFO - 2017-11-14 16:55:49 --> Helper loaded: date_helper
INFO - 2017-11-14 16:55:49 --> Helper loaded: util_helper
INFO - 2017-11-14 16:55:49 --> Helper loaded: text_helper
INFO - 2017-11-14 16:55:49 --> Helper loaded: string_helper
INFO - 2017-11-14 16:55:49 --> Database Driver Class Initialized
DEBUG - 2017-11-14 16:55:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-14 16:55:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-14 16:55:49 --> Email Class Initialized
INFO - 2017-11-14 16:55:49 --> Controller Class Initialized
INFO - 2017-11-14 16:55:49 --> Model Class Initialized
DEBUG - 2017-11-14 16:55:49 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_model.php
INFO - 2017-11-14 16:55:49 --> Model Class Initialized
DEBUG - 2017-11-14 16:55:49 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_functions_model.php
INFO - 2017-11-14 16:55:49 --> Model Class Initialized
DEBUG - 2017-11-14 16:55:49 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header_menu.php
DEBUG - 2017-11-14 16:55:49 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\companies/companies_header.php
DEBUG - 2017-11-14 16:55:49 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\companies/companies_page.php
DEBUG - 2017-11-14 16:55:49 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/home_footer_nav.php
DEBUG - 2017-11-14 16:55:49 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\companies/companies_footer.php
INFO - 2017-11-14 16:55:49 --> Final output sent to browser
DEBUG - 2017-11-14 16:55:49 --> Total execution time: 0.1050
INFO - 2017-11-14 16:55:50 --> Config Class Initialized
INFO - 2017-11-14 16:55:50 --> Hooks Class Initialized
DEBUG - 2017-11-14 16:55:50 --> UTF-8 Support Enabled
INFO - 2017-11-14 16:55:50 --> Utf8 Class Initialized
INFO - 2017-11-14 16:55:50 --> URI Class Initialized
INFO - 2017-11-14 16:55:50 --> Router Class Initialized
INFO - 2017-11-14 16:55:50 --> Output Class Initialized
INFO - 2017-11-14 16:55:50 --> Security Class Initialized
DEBUG - 2017-11-14 16:55:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 16:55:50 --> Input Class Initialized
INFO - 2017-11-14 16:55:50 --> Language Class Initialized
INFO - 2017-11-14 16:55:50 --> Language Class Initialized
INFO - 2017-11-14 16:55:50 --> Config Class Initialized
INFO - 2017-11-14 16:55:50 --> Loader Class Initialized
DEBUG - 2017-11-14 16:55:50 --> Config file loaded: D:\xampp\htdocs\construction_bay\application\config/construct-data.php
INFO - 2017-11-14 16:55:50 --> Helper loaded: url_helper
INFO - 2017-11-14 16:55:50 --> Helper loaded: form_helper
INFO - 2017-11-14 16:55:50 --> Helper loaded: date_helper
INFO - 2017-11-14 16:55:50 --> Helper loaded: util_helper
INFO - 2017-11-14 16:55:50 --> Helper loaded: text_helper
INFO - 2017-11-14 16:55:50 --> Helper loaded: string_helper
INFO - 2017-11-14 16:55:50 --> Database Driver Class Initialized
DEBUG - 2017-11-14 16:55:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-14 16:55:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-14 16:55:50 --> Email Class Initialized
INFO - 2017-11-14 16:55:50 --> Controller Class Initialized
INFO - 2017-11-14 16:55:50 --> Model Class Initialized
DEBUG - 2017-11-14 16:55:50 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_model.php
INFO - 2017-11-14 16:55:50 --> Model Class Initialized
DEBUG - 2017-11-14 16:55:50 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_functions_model.php
INFO - 2017-11-14 16:55:50 --> Model Class Initialized
DEBUG - 2017-11-14 16:55:50 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/template.php
INFO - 2017-11-14 17:11:13 --> Config Class Initialized
INFO - 2017-11-14 17:11:13 --> Hooks Class Initialized
DEBUG - 2017-11-14 17:11:13 --> UTF-8 Support Enabled
INFO - 2017-11-14 17:11:13 --> Utf8 Class Initialized
INFO - 2017-11-14 17:11:13 --> URI Class Initialized
DEBUG - 2017-11-14 17:11:13 --> No URI present. Default controller set.
INFO - 2017-11-14 17:11:13 --> Router Class Initialized
INFO - 2017-11-14 17:11:13 --> Output Class Initialized
INFO - 2017-11-14 17:11:13 --> Security Class Initialized
DEBUG - 2017-11-14 17:11:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 17:11:13 --> Input Class Initialized
INFO - 2017-11-14 17:11:13 --> Language Class Initialized
INFO - 2017-11-14 17:11:13 --> Language Class Initialized
INFO - 2017-11-14 17:11:13 --> Config Class Initialized
INFO - 2017-11-14 17:11:13 --> Loader Class Initialized
DEBUG - 2017-11-14 17:11:13 --> Config file loaded: D:\xampp\htdocs\construction_bay\application\config/construct-data.php
INFO - 2017-11-14 17:11:13 --> Helper loaded: url_helper
INFO - 2017-11-14 17:11:13 --> Helper loaded: form_helper
INFO - 2017-11-14 17:11:13 --> Helper loaded: date_helper
INFO - 2017-11-14 17:11:13 --> Helper loaded: util_helper
INFO - 2017-11-14 17:11:13 --> Helper loaded: text_helper
INFO - 2017-11-14 17:11:13 --> Helper loaded: string_helper
INFO - 2017-11-14 17:11:13 --> Database Driver Class Initialized
DEBUG - 2017-11-14 17:11:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-14 17:11:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-14 17:11:13 --> Email Class Initialized
INFO - 2017-11-14 17:11:13 --> Controller Class Initialized
DEBUG - 2017-11-14 17:11:13 --> Home MX_Controller Initialized
INFO - 2017-11-14 17:11:13 --> Model Class Initialized
DEBUG - 2017-11-14 17:11:13 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_model.php
INFO - 2017-11-14 17:11:13 --> Model Class Initialized
DEBUG - 2017-11-14 17:11:13 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header_menu.php
DEBUG - 2017-11-14 17:11:13 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header.php
DEBUG - 2017-11-14 17:11:13 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/slider.php
DEBUG - 2017-11-14 17:11:13 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/index_body.php
DEBUG - 2017-11-14 17:11:13 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/home_footer_nav.php
DEBUG - 2017-11-14 17:11:13 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/index_footer.php
INFO - 2017-11-14 17:11:13 --> Final output sent to browser
DEBUG - 2017-11-14 17:11:13 --> Total execution time: 0.0600
INFO - 2017-11-14 17:11:30 --> Config Class Initialized
INFO - 2017-11-14 17:11:30 --> Hooks Class Initialized
DEBUG - 2017-11-14 17:11:30 --> UTF-8 Support Enabled
INFO - 2017-11-14 17:11:30 --> Utf8 Class Initialized
INFO - 2017-11-14 17:11:30 --> URI Class Initialized
INFO - 2017-11-14 17:11:30 --> Router Class Initialized
INFO - 2017-11-14 17:11:30 --> Output Class Initialized
INFO - 2017-11-14 17:11:30 --> Security Class Initialized
DEBUG - 2017-11-14 17:11:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 17:11:30 --> Input Class Initialized
INFO - 2017-11-14 17:11:30 --> Language Class Initialized
INFO - 2017-11-14 17:11:30 --> Language Class Initialized
INFO - 2017-11-14 17:11:30 --> Config Class Initialized
INFO - 2017-11-14 17:11:30 --> Loader Class Initialized
DEBUG - 2017-11-14 17:11:30 --> Config file loaded: D:\xampp\htdocs\construction_bay\application\config/construct-data.php
INFO - 2017-11-14 17:11:30 --> Helper loaded: url_helper
INFO - 2017-11-14 17:11:30 --> Helper loaded: form_helper
INFO - 2017-11-14 17:11:30 --> Helper loaded: date_helper
INFO - 2017-11-14 17:11:30 --> Helper loaded: util_helper
INFO - 2017-11-14 17:11:30 --> Helper loaded: text_helper
INFO - 2017-11-14 17:11:30 --> Helper loaded: string_helper
INFO - 2017-11-14 17:11:30 --> Database Driver Class Initialized
DEBUG - 2017-11-14 17:11:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-14 17:11:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-14 17:11:30 --> Email Class Initialized
INFO - 2017-11-14 17:11:30 --> Controller Class Initialized
DEBUG - 2017-11-14 17:11:30 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header_menu.php
DEBUG - 2017-11-14 17:11:30 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header.php
DEBUG - 2017-11-14 17:11:30 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\welcome_page.php
DEBUG - 2017-11-14 17:11:30 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/footer_nav.php
DEBUG - 2017-11-14 17:11:30 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/footer.php
INFO - 2017-11-14 17:11:30 --> Final output sent to browser
DEBUG - 2017-11-14 17:11:30 --> Total execution time: 0.1170
INFO - 2017-11-14 17:11:31 --> Config Class Initialized
INFO - 2017-11-14 17:11:31 --> Hooks Class Initialized
DEBUG - 2017-11-14 17:11:31 --> UTF-8 Support Enabled
INFO - 2017-11-14 17:11:31 --> Utf8 Class Initialized
INFO - 2017-11-14 17:11:31 --> URI Class Initialized
INFO - 2017-11-14 17:11:31 --> Router Class Initialized
INFO - 2017-11-14 17:11:31 --> Output Class Initialized
INFO - 2017-11-14 17:11:31 --> Security Class Initialized
DEBUG - 2017-11-14 17:11:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 17:11:31 --> Input Class Initialized
INFO - 2017-11-14 17:11:31 --> Language Class Initialized
ERROR - 2017-11-14 17:11:31 --> 404 Page Not Found: /index
INFO - 2017-11-14 17:11:43 --> Config Class Initialized
INFO - 2017-11-14 17:11:43 --> Hooks Class Initialized
DEBUG - 2017-11-14 17:11:43 --> UTF-8 Support Enabled
INFO - 2017-11-14 17:11:43 --> Utf8 Class Initialized
INFO - 2017-11-14 17:11:43 --> URI Class Initialized
INFO - 2017-11-14 17:11:43 --> Router Class Initialized
INFO - 2017-11-14 17:11:43 --> Output Class Initialized
INFO - 2017-11-14 17:11:43 --> Security Class Initialized
DEBUG - 2017-11-14 17:11:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 17:11:43 --> Input Class Initialized
INFO - 2017-11-14 17:11:43 --> Language Class Initialized
ERROR - 2017-11-14 17:11:43 --> 404 Page Not Found: /index
INFO - 2017-11-14 17:14:59 --> Config Class Initialized
INFO - 2017-11-14 17:14:59 --> Hooks Class Initialized
DEBUG - 2017-11-14 17:14:59 --> UTF-8 Support Enabled
INFO - 2017-11-14 17:14:59 --> Utf8 Class Initialized
INFO - 2017-11-14 17:14:59 --> URI Class Initialized
INFO - 2017-11-14 17:14:59 --> Router Class Initialized
INFO - 2017-11-14 17:14:59 --> Output Class Initialized
INFO - 2017-11-14 17:14:59 --> Security Class Initialized
DEBUG - 2017-11-14 17:14:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 17:14:59 --> Input Class Initialized
INFO - 2017-11-14 17:14:59 --> Language Class Initialized
INFO - 2017-11-14 17:14:59 --> Language Class Initialized
INFO - 2017-11-14 17:14:59 --> Config Class Initialized
INFO - 2017-11-14 17:14:59 --> Loader Class Initialized
DEBUG - 2017-11-14 17:14:59 --> Config file loaded: D:\xampp\htdocs\construction_bay\application\config/construct-data.php
INFO - 2017-11-14 17:14:59 --> Helper loaded: url_helper
INFO - 2017-11-14 17:14:59 --> Helper loaded: form_helper
INFO - 2017-11-14 17:14:59 --> Helper loaded: date_helper
INFO - 2017-11-14 17:14:59 --> Helper loaded: util_helper
INFO - 2017-11-14 17:14:59 --> Helper loaded: text_helper
INFO - 2017-11-14 17:14:59 --> Helper loaded: string_helper
INFO - 2017-11-14 17:14:59 --> Database Driver Class Initialized
DEBUG - 2017-11-14 17:14:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-14 17:14:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-14 17:14:59 --> Email Class Initialized
INFO - 2017-11-14 17:14:59 --> Controller Class Initialized
DEBUG - 2017-11-14 17:14:59 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header_menu.php
DEBUG - 2017-11-14 17:14:59 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header.php
DEBUG - 2017-11-14 17:14:59 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\welcome_page.php
DEBUG - 2017-11-14 17:14:59 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/footer_nav.php
DEBUG - 2017-11-14 17:14:59 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/footer.php
INFO - 2017-11-14 17:14:59 --> Final output sent to browser
DEBUG - 2017-11-14 17:14:59 --> Total execution time: 0.0600
INFO - 2017-11-14 17:15:01 --> Config Class Initialized
INFO - 2017-11-14 17:15:01 --> Hooks Class Initialized
DEBUG - 2017-11-14 17:15:01 --> UTF-8 Support Enabled
INFO - 2017-11-14 17:15:01 --> Utf8 Class Initialized
INFO - 2017-11-14 17:15:01 --> URI Class Initialized
INFO - 2017-11-14 17:15:01 --> Router Class Initialized
INFO - 2017-11-14 17:15:01 --> Output Class Initialized
INFO - 2017-11-14 17:15:01 --> Security Class Initialized
DEBUG - 2017-11-14 17:15:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 17:15:01 --> Input Class Initialized
INFO - 2017-11-14 17:15:01 --> Language Class Initialized
ERROR - 2017-11-14 17:15:01 --> 404 Page Not Found: /index
INFO - 2017-11-14 17:16:57 --> Config Class Initialized
INFO - 2017-11-14 17:16:57 --> Hooks Class Initialized
DEBUG - 2017-11-14 17:16:57 --> UTF-8 Support Enabled
INFO - 2017-11-14 17:16:57 --> Utf8 Class Initialized
INFO - 2017-11-14 17:16:57 --> URI Class Initialized
INFO - 2017-11-14 17:16:57 --> Router Class Initialized
INFO - 2017-11-14 17:16:57 --> Output Class Initialized
INFO - 2017-11-14 17:16:57 --> Security Class Initialized
DEBUG - 2017-11-14 17:16:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 17:16:57 --> Input Class Initialized
INFO - 2017-11-14 17:16:57 --> Language Class Initialized
INFO - 2017-11-14 17:16:57 --> Language Class Initialized
INFO - 2017-11-14 17:16:57 --> Config Class Initialized
INFO - 2017-11-14 17:16:57 --> Loader Class Initialized
DEBUG - 2017-11-14 17:16:57 --> Config file loaded: D:\xampp\htdocs\construction_bay\application\config/construct-data.php
INFO - 2017-11-14 17:16:57 --> Helper loaded: url_helper
INFO - 2017-11-14 17:16:57 --> Helper loaded: form_helper
INFO - 2017-11-14 17:16:57 --> Helper loaded: date_helper
INFO - 2017-11-14 17:16:57 --> Helper loaded: util_helper
INFO - 2017-11-14 17:16:57 --> Helper loaded: text_helper
INFO - 2017-11-14 17:16:57 --> Helper loaded: string_helper
INFO - 2017-11-14 17:16:57 --> Database Driver Class Initialized
DEBUG - 2017-11-14 17:16:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-14 17:16:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-14 17:16:57 --> Email Class Initialized
INFO - 2017-11-14 17:16:57 --> Controller Class Initialized
DEBUG - 2017-11-14 17:16:57 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header_menu.php
DEBUG - 2017-11-14 17:16:57 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header.php
DEBUG - 2017-11-14 17:16:57 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\welcome_page.php
DEBUG - 2017-11-14 17:16:57 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/footer_nav.php
DEBUG - 2017-11-14 17:16:57 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/footer.php
INFO - 2017-11-14 17:16:57 --> Final output sent to browser
DEBUG - 2017-11-14 17:16:57 --> Total execution time: 0.0560
INFO - 2017-11-14 17:17:35 --> Config Class Initialized
INFO - 2017-11-14 17:17:35 --> Hooks Class Initialized
DEBUG - 2017-11-14 17:17:35 --> UTF-8 Support Enabled
INFO - 2017-11-14 17:17:35 --> Utf8 Class Initialized
INFO - 2017-11-14 17:17:35 --> URI Class Initialized
DEBUG - 2017-11-14 17:17:35 --> No URI present. Default controller set.
INFO - 2017-11-14 17:17:35 --> Router Class Initialized
INFO - 2017-11-14 17:17:35 --> Output Class Initialized
INFO - 2017-11-14 17:17:35 --> Security Class Initialized
DEBUG - 2017-11-14 17:17:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 17:17:35 --> Input Class Initialized
INFO - 2017-11-14 17:17:35 --> Language Class Initialized
INFO - 2017-11-14 17:17:35 --> Language Class Initialized
INFO - 2017-11-14 17:17:35 --> Config Class Initialized
INFO - 2017-11-14 17:17:35 --> Loader Class Initialized
DEBUG - 2017-11-14 17:17:35 --> Config file loaded: D:\xampp\htdocs\construction_bay\application\config/construct-data.php
INFO - 2017-11-14 17:17:35 --> Helper loaded: url_helper
INFO - 2017-11-14 17:17:35 --> Helper loaded: form_helper
INFO - 2017-11-14 17:17:35 --> Helper loaded: date_helper
INFO - 2017-11-14 17:17:35 --> Helper loaded: util_helper
INFO - 2017-11-14 17:17:35 --> Helper loaded: text_helper
INFO - 2017-11-14 17:17:35 --> Helper loaded: string_helper
INFO - 2017-11-14 17:17:35 --> Database Driver Class Initialized
DEBUG - 2017-11-14 17:17:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-14 17:17:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-14 17:17:35 --> Email Class Initialized
INFO - 2017-11-14 17:17:35 --> Controller Class Initialized
DEBUG - 2017-11-14 17:17:35 --> Home MX_Controller Initialized
INFO - 2017-11-14 17:17:35 --> Model Class Initialized
DEBUG - 2017-11-14 17:17:35 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_model.php
INFO - 2017-11-14 17:17:35 --> Model Class Initialized
DEBUG - 2017-11-14 17:17:35 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header_menu.php
DEBUG - 2017-11-14 17:17:35 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header.php
DEBUG - 2017-11-14 17:17:35 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/slider.php
DEBUG - 2017-11-14 17:17:35 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/index_body.php
DEBUG - 2017-11-14 17:17:35 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/home_footer_nav.php
DEBUG - 2017-11-14 17:17:35 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/index_footer.php
INFO - 2017-11-14 17:17:35 --> Final output sent to browser
DEBUG - 2017-11-14 17:17:35 --> Total execution time: 0.0650
INFO - 2017-11-14 17:19:02 --> Config Class Initialized
INFO - 2017-11-14 17:19:02 --> Hooks Class Initialized
DEBUG - 2017-11-14 17:19:02 --> UTF-8 Support Enabled
INFO - 2017-11-14 17:19:02 --> Utf8 Class Initialized
INFO - 2017-11-14 17:19:02 --> URI Class Initialized
INFO - 2017-11-14 17:19:02 --> Router Class Initialized
INFO - 2017-11-14 17:19:02 --> Output Class Initialized
INFO - 2017-11-14 17:19:02 --> Security Class Initialized
DEBUG - 2017-11-14 17:19:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 17:19:02 --> Input Class Initialized
INFO - 2017-11-14 17:19:02 --> Language Class Initialized
INFO - 2017-11-14 17:19:02 --> Language Class Initialized
INFO - 2017-11-14 17:19:02 --> Config Class Initialized
INFO - 2017-11-14 17:19:02 --> Loader Class Initialized
DEBUG - 2017-11-14 17:19:02 --> Config file loaded: D:\xampp\htdocs\construction_bay\application\config/construct-data.php
INFO - 2017-11-14 17:19:02 --> Helper loaded: url_helper
INFO - 2017-11-14 17:19:02 --> Helper loaded: form_helper
INFO - 2017-11-14 17:19:02 --> Helper loaded: date_helper
INFO - 2017-11-14 17:19:02 --> Helper loaded: util_helper
INFO - 2017-11-14 17:19:02 --> Helper loaded: text_helper
INFO - 2017-11-14 17:19:02 --> Helper loaded: string_helper
INFO - 2017-11-14 17:19:02 --> Database Driver Class Initialized
DEBUG - 2017-11-14 17:19:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-14 17:19:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-14 17:19:02 --> Email Class Initialized
INFO - 2017-11-14 17:19:02 --> Controller Class Initialized
DEBUG - 2017-11-14 17:19:02 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header_menu.php
DEBUG - 2017-11-14 17:19:02 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header.php
DEBUG - 2017-11-14 17:19:02 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\welcome_page.php
DEBUG - 2017-11-14 17:19:02 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/footer_nav.php
DEBUG - 2017-11-14 17:19:02 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/footer.php
INFO - 2017-11-14 17:19:02 --> Final output sent to browser
DEBUG - 2017-11-14 17:19:02 --> Total execution time: 0.0750
INFO - 2017-11-14 17:22:02 --> Config Class Initialized
INFO - 2017-11-14 17:22:02 --> Hooks Class Initialized
DEBUG - 2017-11-14 17:22:02 --> UTF-8 Support Enabled
INFO - 2017-11-14 17:22:02 --> Utf8 Class Initialized
INFO - 2017-11-14 17:22:02 --> URI Class Initialized
INFO - 2017-11-14 17:22:02 --> Router Class Initialized
INFO - 2017-11-14 17:22:02 --> Output Class Initialized
INFO - 2017-11-14 17:22:02 --> Security Class Initialized
DEBUG - 2017-11-14 17:22:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 17:22:02 --> Input Class Initialized
INFO - 2017-11-14 17:22:02 --> Language Class Initialized
INFO - 2017-11-14 17:22:02 --> Language Class Initialized
INFO - 2017-11-14 17:22:02 --> Config Class Initialized
INFO - 2017-11-14 17:22:02 --> Loader Class Initialized
DEBUG - 2017-11-14 17:22:02 --> Config file loaded: D:\xampp\htdocs\construction_bay\application\config/construct-data.php
INFO - 2017-11-14 17:22:02 --> Helper loaded: url_helper
INFO - 2017-11-14 17:22:02 --> Helper loaded: form_helper
INFO - 2017-11-14 17:22:02 --> Helper loaded: date_helper
INFO - 2017-11-14 17:22:02 --> Helper loaded: util_helper
INFO - 2017-11-14 17:22:02 --> Helper loaded: text_helper
INFO - 2017-11-14 17:22:02 --> Helper loaded: string_helper
INFO - 2017-11-14 17:22:02 --> Database Driver Class Initialized
DEBUG - 2017-11-14 17:22:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-14 17:22:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-14 17:22:02 --> Email Class Initialized
INFO - 2017-11-14 17:22:02 --> Controller Class Initialized
DEBUG - 2017-11-14 17:22:02 --> Home MX_Controller Initialized
INFO - 2017-11-14 17:22:02 --> Model Class Initialized
DEBUG - 2017-11-14 17:22:02 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_model.php
INFO - 2017-11-14 17:22:02 --> Model Class Initialized
DEBUG - 2017-11-14 17:22:02 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header_menu.php
DEBUG - 2017-11-14 17:22:02 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header.php
DEBUG - 2017-11-14 17:22:02 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\partner-with-us.php
DEBUG - 2017-11-14 17:22:02 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/home_footer_nav.php
DEBUG - 2017-11-14 17:22:02 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/index_footer.php
INFO - 2017-11-14 17:22:02 --> Final output sent to browser
DEBUG - 2017-11-14 17:22:02 --> Total execution time: 0.0640
INFO - 2017-11-14 17:22:06 --> Config Class Initialized
INFO - 2017-11-14 17:22:06 --> Hooks Class Initialized
DEBUG - 2017-11-14 17:22:06 --> UTF-8 Support Enabled
INFO - 2017-11-14 17:22:06 --> Utf8 Class Initialized
INFO - 2017-11-14 17:22:06 --> URI Class Initialized
INFO - 2017-11-14 17:22:06 --> Router Class Initialized
INFO - 2017-11-14 17:22:06 --> Output Class Initialized
INFO - 2017-11-14 17:22:06 --> Security Class Initialized
DEBUG - 2017-11-14 17:22:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 17:22:06 --> Input Class Initialized
INFO - 2017-11-14 17:22:06 --> Language Class Initialized
INFO - 2017-11-14 17:22:06 --> Language Class Initialized
INFO - 2017-11-14 17:22:06 --> Config Class Initialized
INFO - 2017-11-14 17:22:06 --> Loader Class Initialized
DEBUG - 2017-11-14 17:22:06 --> Config file loaded: D:\xampp\htdocs\construction_bay\application\config/construct-data.php
INFO - 2017-11-14 17:22:06 --> Helper loaded: url_helper
INFO - 2017-11-14 17:22:06 --> Helper loaded: form_helper
INFO - 2017-11-14 17:22:06 --> Helper loaded: date_helper
INFO - 2017-11-14 17:22:06 --> Helper loaded: util_helper
INFO - 2017-11-14 17:22:06 --> Helper loaded: text_helper
INFO - 2017-11-14 17:22:06 --> Helper loaded: string_helper
INFO - 2017-11-14 17:22:06 --> Database Driver Class Initialized
DEBUG - 2017-11-14 17:22:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-14 17:22:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-14 17:22:06 --> Email Class Initialized
INFO - 2017-11-14 17:22:06 --> Controller Class Initialized
ERROR - 2017-11-14 17:22:06 --> 404 Page Not Found: Home/favicon.ico
INFO - 2017-11-14 17:23:56 --> Config Class Initialized
INFO - 2017-11-14 17:23:56 --> Hooks Class Initialized
DEBUG - 2017-11-14 17:23:56 --> UTF-8 Support Enabled
INFO - 2017-11-14 17:23:56 --> Utf8 Class Initialized
INFO - 2017-11-14 17:23:56 --> URI Class Initialized
DEBUG - 2017-11-14 17:23:56 --> No URI present. Default controller set.
INFO - 2017-11-14 17:23:56 --> Router Class Initialized
INFO - 2017-11-14 17:23:56 --> Output Class Initialized
INFO - 2017-11-14 17:23:56 --> Security Class Initialized
DEBUG - 2017-11-14 17:23:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 17:23:56 --> Input Class Initialized
INFO - 2017-11-14 17:23:56 --> Language Class Initialized
INFO - 2017-11-14 17:23:56 --> Language Class Initialized
INFO - 2017-11-14 17:23:56 --> Config Class Initialized
INFO - 2017-11-14 17:23:56 --> Loader Class Initialized
DEBUG - 2017-11-14 17:23:56 --> Config file loaded: D:\xampp\htdocs\construction_bay\application\config/construct-data.php
INFO - 2017-11-14 17:23:56 --> Helper loaded: url_helper
INFO - 2017-11-14 17:23:56 --> Helper loaded: form_helper
INFO - 2017-11-14 17:23:56 --> Helper loaded: date_helper
INFO - 2017-11-14 17:23:56 --> Helper loaded: util_helper
INFO - 2017-11-14 17:23:56 --> Helper loaded: text_helper
INFO - 2017-11-14 17:23:56 --> Helper loaded: string_helper
INFO - 2017-11-14 17:23:56 --> Database Driver Class Initialized
DEBUG - 2017-11-14 17:23:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-14 17:23:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-14 17:23:56 --> Email Class Initialized
INFO - 2017-11-14 17:23:56 --> Controller Class Initialized
DEBUG - 2017-11-14 17:23:56 --> Home MX_Controller Initialized
INFO - 2017-11-14 17:23:56 --> Model Class Initialized
DEBUG - 2017-11-14 17:23:56 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_model.php
INFO - 2017-11-14 17:23:56 --> Model Class Initialized
DEBUG - 2017-11-14 17:23:56 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header_menu.php
DEBUG - 2017-11-14 17:23:56 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header.php
DEBUG - 2017-11-14 17:23:56 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/slider.php
DEBUG - 2017-11-14 17:23:56 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/index_body.php
DEBUG - 2017-11-14 17:23:56 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/home_footer_nav.php
DEBUG - 2017-11-14 17:23:56 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/index_footer.php
INFO - 2017-11-14 17:23:56 --> Final output sent to browser
DEBUG - 2017-11-14 17:23:56 --> Total execution time: 0.0650
INFO - 2017-11-14 17:24:32 --> Config Class Initialized
INFO - 2017-11-14 17:24:32 --> Hooks Class Initialized
DEBUG - 2017-11-14 17:24:32 --> UTF-8 Support Enabled
INFO - 2017-11-14 17:24:32 --> Utf8 Class Initialized
INFO - 2017-11-14 17:24:32 --> URI Class Initialized
DEBUG - 2017-11-14 17:24:32 --> No URI present. Default controller set.
INFO - 2017-11-14 17:24:32 --> Router Class Initialized
INFO - 2017-11-14 17:24:32 --> Output Class Initialized
INFO - 2017-11-14 17:24:32 --> Security Class Initialized
DEBUG - 2017-11-14 17:24:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 17:24:32 --> Input Class Initialized
INFO - 2017-11-14 17:24:32 --> Language Class Initialized
INFO - 2017-11-14 17:24:32 --> Language Class Initialized
INFO - 2017-11-14 17:24:32 --> Config Class Initialized
INFO - 2017-11-14 17:24:32 --> Loader Class Initialized
DEBUG - 2017-11-14 17:24:32 --> Config file loaded: D:\xampp\htdocs\construction_bay\application\config/construct-data.php
INFO - 2017-11-14 17:24:32 --> Helper loaded: url_helper
INFO - 2017-11-14 17:24:32 --> Helper loaded: form_helper
INFO - 2017-11-14 17:24:32 --> Helper loaded: date_helper
INFO - 2017-11-14 17:24:32 --> Helper loaded: util_helper
INFO - 2017-11-14 17:24:32 --> Helper loaded: text_helper
INFO - 2017-11-14 17:24:32 --> Helper loaded: string_helper
INFO - 2017-11-14 17:24:32 --> Database Driver Class Initialized
DEBUG - 2017-11-14 17:24:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-14 17:24:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-14 17:24:32 --> Email Class Initialized
INFO - 2017-11-14 17:24:32 --> Controller Class Initialized
DEBUG - 2017-11-14 17:24:32 --> Home MX_Controller Initialized
INFO - 2017-11-14 17:24:32 --> Model Class Initialized
DEBUG - 2017-11-14 17:24:32 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_model.php
INFO - 2017-11-14 17:24:32 --> Model Class Initialized
DEBUG - 2017-11-14 17:24:32 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header_menu.php
DEBUG - 2017-11-14 17:24:32 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header.php
DEBUG - 2017-11-14 17:24:32 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/slider.php
DEBUG - 2017-11-14 17:24:32 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/index_body.php
DEBUG - 2017-11-14 17:24:32 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/home_footer_nav.php
DEBUG - 2017-11-14 17:24:32 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/index_footer.php
INFO - 2017-11-14 17:24:32 --> Final output sent to browser
DEBUG - 2017-11-14 17:24:32 --> Total execution time: 0.0730
INFO - 2017-11-14 17:24:41 --> Config Class Initialized
INFO - 2017-11-14 17:24:41 --> Hooks Class Initialized
DEBUG - 2017-11-14 17:24:41 --> UTF-8 Support Enabled
INFO - 2017-11-14 17:24:41 --> Utf8 Class Initialized
INFO - 2017-11-14 17:24:41 --> URI Class Initialized
INFO - 2017-11-14 17:24:41 --> Router Class Initialized
INFO - 2017-11-14 17:24:41 --> Output Class Initialized
INFO - 2017-11-14 17:24:41 --> Security Class Initialized
DEBUG - 2017-11-14 17:24:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 17:24:41 --> Input Class Initialized
INFO - 2017-11-14 17:24:41 --> Language Class Initialized
INFO - 2017-11-14 17:24:41 --> Language Class Initialized
INFO - 2017-11-14 17:24:41 --> Config Class Initialized
INFO - 2017-11-14 17:24:41 --> Loader Class Initialized
DEBUG - 2017-11-14 17:24:41 --> Config file loaded: D:\xampp\htdocs\construction_bay\application\config/construct-data.php
INFO - 2017-11-14 17:24:41 --> Helper loaded: url_helper
INFO - 2017-11-14 17:24:41 --> Helper loaded: form_helper
INFO - 2017-11-14 17:24:41 --> Helper loaded: date_helper
INFO - 2017-11-14 17:24:41 --> Helper loaded: util_helper
INFO - 2017-11-14 17:24:41 --> Helper loaded: text_helper
INFO - 2017-11-14 17:24:41 --> Helper loaded: string_helper
INFO - 2017-11-14 17:24:41 --> Database Driver Class Initialized
DEBUG - 2017-11-14 17:24:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-14 17:24:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-14 17:24:41 --> Email Class Initialized
INFO - 2017-11-14 17:24:41 --> Controller Class Initialized
DEBUG - 2017-11-14 17:24:41 --> Home MX_Controller Initialized
INFO - 2017-11-14 17:24:41 --> Model Class Initialized
DEBUG - 2017-11-14 17:24:41 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_model.php
INFO - 2017-11-14 17:24:41 --> Model Class Initialized
DEBUG - 2017-11-14 17:24:41 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header_menu.php
DEBUG - 2017-11-14 17:24:41 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header.php
DEBUG - 2017-11-14 17:24:41 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\partner-with-us.php
DEBUG - 2017-11-14 17:24:41 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/home_footer_nav.php
DEBUG - 2017-11-14 17:24:41 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/index_footer.php
INFO - 2017-11-14 17:24:41 --> Final output sent to browser
DEBUG - 2017-11-14 17:24:41 --> Total execution time: 0.0620
INFO - 2017-11-14 17:25:18 --> Config Class Initialized
INFO - 2017-11-14 17:25:18 --> Hooks Class Initialized
DEBUG - 2017-11-14 17:25:18 --> UTF-8 Support Enabled
INFO - 2017-11-14 17:25:18 --> Utf8 Class Initialized
INFO - 2017-11-14 17:25:18 --> URI Class Initialized
INFO - 2017-11-14 17:25:18 --> Router Class Initialized
INFO - 2017-11-14 17:25:18 --> Output Class Initialized
INFO - 2017-11-14 17:25:18 --> Security Class Initialized
DEBUG - 2017-11-14 17:25:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 17:25:18 --> Input Class Initialized
INFO - 2017-11-14 17:25:18 --> Language Class Initialized
INFO - 2017-11-14 17:25:18 --> Language Class Initialized
INFO - 2017-11-14 17:25:18 --> Config Class Initialized
INFO - 2017-11-14 17:25:18 --> Loader Class Initialized
DEBUG - 2017-11-14 17:25:18 --> Config file loaded: D:\xampp\htdocs\construction_bay\application\config/construct-data.php
INFO - 2017-11-14 17:25:18 --> Helper loaded: url_helper
INFO - 2017-11-14 17:25:18 --> Helper loaded: form_helper
INFO - 2017-11-14 17:25:18 --> Helper loaded: date_helper
INFO - 2017-11-14 17:25:18 --> Helper loaded: util_helper
INFO - 2017-11-14 17:25:18 --> Helper loaded: text_helper
INFO - 2017-11-14 17:25:18 --> Helper loaded: string_helper
INFO - 2017-11-14 17:25:18 --> Database Driver Class Initialized
DEBUG - 2017-11-14 17:25:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-14 17:25:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-14 17:25:18 --> Email Class Initialized
INFO - 2017-11-14 17:25:18 --> Controller Class Initialized
DEBUG - 2017-11-14 17:25:18 --> Home MX_Controller Initialized
INFO - 2017-11-14 17:25:18 --> Model Class Initialized
DEBUG - 2017-11-14 17:25:18 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_model.php
INFO - 2017-11-14 17:25:18 --> Model Class Initialized
DEBUG - 2017-11-14 17:25:18 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header_menu.php
DEBUG - 2017-11-14 17:25:18 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header.php
DEBUG - 2017-11-14 17:25:18 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\partner-with-us.php
DEBUG - 2017-11-14 17:25:18 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/home_footer_nav.php
DEBUG - 2017-11-14 17:25:18 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/index_footer.php
INFO - 2017-11-14 17:25:18 --> Final output sent to browser
DEBUG - 2017-11-14 17:25:18 --> Total execution time: 0.0660
INFO - 2017-11-14 17:35:31 --> Config Class Initialized
INFO - 2017-11-14 17:35:31 --> Hooks Class Initialized
DEBUG - 2017-11-14 17:35:31 --> UTF-8 Support Enabled
INFO - 2017-11-14 17:35:31 --> Utf8 Class Initialized
INFO - 2017-11-14 17:35:31 --> URI Class Initialized
INFO - 2017-11-14 17:35:31 --> Router Class Initialized
INFO - 2017-11-14 17:35:31 --> Output Class Initialized
INFO - 2017-11-14 17:35:31 --> Security Class Initialized
DEBUG - 2017-11-14 17:35:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 17:35:31 --> Input Class Initialized
INFO - 2017-11-14 17:35:31 --> Language Class Initialized
INFO - 2017-11-14 17:35:31 --> Language Class Initialized
INFO - 2017-11-14 17:35:31 --> Config Class Initialized
INFO - 2017-11-14 17:35:31 --> Loader Class Initialized
DEBUG - 2017-11-14 17:35:31 --> Config file loaded: D:\xampp\htdocs\construction_bay\application\config/construct-data.php
INFO - 2017-11-14 17:35:31 --> Helper loaded: url_helper
INFO - 2017-11-14 17:35:31 --> Helper loaded: form_helper
INFO - 2017-11-14 17:35:31 --> Helper loaded: date_helper
INFO - 2017-11-14 17:35:31 --> Helper loaded: util_helper
INFO - 2017-11-14 17:35:31 --> Helper loaded: text_helper
INFO - 2017-11-14 17:35:31 --> Helper loaded: string_helper
INFO - 2017-11-14 17:35:31 --> Database Driver Class Initialized
DEBUG - 2017-11-14 17:35:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-14 17:35:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-14 17:35:31 --> Email Class Initialized
INFO - 2017-11-14 17:35:31 --> Controller Class Initialized
DEBUG - 2017-11-14 17:35:31 --> Home MX_Controller Initialized
INFO - 2017-11-14 17:35:31 --> Model Class Initialized
DEBUG - 2017-11-14 17:35:31 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_model.php
INFO - 2017-11-14 17:35:31 --> Model Class Initialized
DEBUG - 2017-11-14 17:35:31 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header_menu.php
DEBUG - 2017-11-14 17:35:31 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header.php
DEBUG - 2017-11-14 17:35:31 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\partner-with-us.php
DEBUG - 2017-11-14 17:35:31 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/home_footer_nav.php
DEBUG - 2017-11-14 17:35:31 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/index_footer.php
INFO - 2017-11-14 17:35:31 --> Final output sent to browser
DEBUG - 2017-11-14 17:35:31 --> Total execution time: 0.0640
INFO - 2017-11-14 17:38:48 --> Config Class Initialized
INFO - 2017-11-14 17:38:48 --> Hooks Class Initialized
DEBUG - 2017-11-14 17:38:48 --> UTF-8 Support Enabled
INFO - 2017-11-14 17:38:48 --> Utf8 Class Initialized
INFO - 2017-11-14 17:38:48 --> URI Class Initialized
INFO - 2017-11-14 17:38:48 --> Router Class Initialized
INFO - 2017-11-14 17:38:48 --> Output Class Initialized
INFO - 2017-11-14 17:38:48 --> Security Class Initialized
DEBUG - 2017-11-14 17:38:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 17:38:48 --> Input Class Initialized
INFO - 2017-11-14 17:38:48 --> Language Class Initialized
INFO - 2017-11-14 17:38:48 --> Language Class Initialized
INFO - 2017-11-14 17:38:48 --> Config Class Initialized
INFO - 2017-11-14 17:38:48 --> Loader Class Initialized
DEBUG - 2017-11-14 17:38:48 --> Config file loaded: D:\xampp\htdocs\construction_bay\application\config/construct-data.php
INFO - 2017-11-14 17:38:48 --> Helper loaded: url_helper
INFO - 2017-11-14 17:38:48 --> Helper loaded: form_helper
INFO - 2017-11-14 17:38:48 --> Helper loaded: date_helper
INFO - 2017-11-14 17:38:48 --> Helper loaded: util_helper
INFO - 2017-11-14 17:38:48 --> Helper loaded: text_helper
INFO - 2017-11-14 17:38:48 --> Helper loaded: string_helper
INFO - 2017-11-14 17:38:48 --> Database Driver Class Initialized
DEBUG - 2017-11-14 17:38:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-14 17:38:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-14 17:38:48 --> Email Class Initialized
INFO - 2017-11-14 17:38:48 --> Controller Class Initialized
DEBUG - 2017-11-14 17:38:48 --> Home MX_Controller Initialized
INFO - 2017-11-14 17:38:48 --> Model Class Initialized
DEBUG - 2017-11-14 17:38:48 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_model.php
INFO - 2017-11-14 17:38:48 --> Model Class Initialized
DEBUG - 2017-11-14 17:38:48 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header_menu.php
DEBUG - 2017-11-14 17:38:48 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header.php
DEBUG - 2017-11-14 17:38:48 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\partner-with-us.php
DEBUG - 2017-11-14 17:38:48 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/home_footer_nav.php
DEBUG - 2017-11-14 17:38:48 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/index_footer.php
INFO - 2017-11-14 17:38:48 --> Final output sent to browser
DEBUG - 2017-11-14 17:38:48 --> Total execution time: 0.0570
INFO - 2017-11-14 17:42:42 --> Config Class Initialized
INFO - 2017-11-14 17:42:42 --> Hooks Class Initialized
DEBUG - 2017-11-14 17:42:42 --> UTF-8 Support Enabled
INFO - 2017-11-14 17:42:42 --> Utf8 Class Initialized
INFO - 2017-11-14 17:42:42 --> URI Class Initialized
DEBUG - 2017-11-14 17:42:42 --> No URI present. Default controller set.
INFO - 2017-11-14 17:42:42 --> Router Class Initialized
INFO - 2017-11-14 17:42:42 --> Output Class Initialized
INFO - 2017-11-14 17:42:43 --> Security Class Initialized
DEBUG - 2017-11-14 17:42:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 17:42:43 --> Input Class Initialized
INFO - 2017-11-14 17:42:43 --> Language Class Initialized
INFO - 2017-11-14 17:42:43 --> Language Class Initialized
INFO - 2017-11-14 17:42:43 --> Config Class Initialized
INFO - 2017-11-14 17:42:43 --> Loader Class Initialized
DEBUG - 2017-11-14 17:42:43 --> Config file loaded: D:\xampp\htdocs\construction_bay\application\config/construct-data.php
INFO - 2017-11-14 17:42:43 --> Helper loaded: url_helper
INFO - 2017-11-14 17:42:43 --> Helper loaded: form_helper
INFO - 2017-11-14 17:42:43 --> Helper loaded: date_helper
INFO - 2017-11-14 17:42:43 --> Helper loaded: util_helper
INFO - 2017-11-14 17:42:43 --> Helper loaded: text_helper
INFO - 2017-11-14 17:42:43 --> Helper loaded: string_helper
INFO - 2017-11-14 17:42:43 --> Database Driver Class Initialized
DEBUG - 2017-11-14 17:42:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-14 17:42:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-14 17:42:43 --> Email Class Initialized
INFO - 2017-11-14 17:42:43 --> Controller Class Initialized
DEBUG - 2017-11-14 17:42:43 --> Home MX_Controller Initialized
INFO - 2017-11-14 17:42:43 --> Model Class Initialized
DEBUG - 2017-11-14 17:42:43 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_model.php
INFO - 2017-11-14 17:42:43 --> Model Class Initialized
DEBUG - 2017-11-14 17:42:43 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header_menu.php
DEBUG - 2017-11-14 17:42:43 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header.php
DEBUG - 2017-11-14 17:42:43 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/slider.php
DEBUG - 2017-11-14 17:42:43 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/index_body.php
DEBUG - 2017-11-14 17:42:43 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/home_footer_nav.php
DEBUG - 2017-11-14 17:42:43 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/index_footer.php
INFO - 2017-11-14 17:42:43 --> Final output sent to browser
DEBUG - 2017-11-14 17:42:43 --> Total execution time: 0.0660
INFO - 2017-11-14 17:43:07 --> Config Class Initialized
INFO - 2017-11-14 17:43:07 --> Hooks Class Initialized
DEBUG - 2017-11-14 17:43:07 --> UTF-8 Support Enabled
INFO - 2017-11-14 17:43:07 --> Utf8 Class Initialized
INFO - 2017-11-14 17:43:07 --> URI Class Initialized
INFO - 2017-11-14 17:43:07 --> Router Class Initialized
INFO - 2017-11-14 17:43:07 --> Output Class Initialized
INFO - 2017-11-14 17:43:07 --> Security Class Initialized
DEBUG - 2017-11-14 17:43:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 17:43:07 --> Input Class Initialized
INFO - 2017-11-14 17:43:07 --> Language Class Initialized
INFO - 2017-11-14 17:43:07 --> Language Class Initialized
INFO - 2017-11-14 17:43:07 --> Config Class Initialized
INFO - 2017-11-14 17:43:07 --> Loader Class Initialized
DEBUG - 2017-11-14 17:43:07 --> Config file loaded: D:\xampp\htdocs\construction_bay\application\config/construct-data.php
INFO - 2017-11-14 17:43:07 --> Helper loaded: url_helper
INFO - 2017-11-14 17:43:07 --> Helper loaded: form_helper
INFO - 2017-11-14 17:43:07 --> Helper loaded: date_helper
INFO - 2017-11-14 17:43:07 --> Helper loaded: util_helper
INFO - 2017-11-14 17:43:07 --> Helper loaded: text_helper
INFO - 2017-11-14 17:43:07 --> Helper loaded: string_helper
INFO - 2017-11-14 17:43:07 --> Database Driver Class Initialized
DEBUG - 2017-11-14 17:43:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-14 17:43:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-14 17:43:07 --> Email Class Initialized
INFO - 2017-11-14 17:43:07 --> Controller Class Initialized
DEBUG - 2017-11-14 17:43:07 --> Home MX_Controller Initialized
INFO - 2017-11-14 17:43:07 --> Model Class Initialized
DEBUG - 2017-11-14 17:43:07 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_model.php
INFO - 2017-11-14 17:43:07 --> Model Class Initialized
DEBUG - 2017-11-14 17:43:07 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header_menu.php
DEBUG - 2017-11-14 17:43:07 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header.php
DEBUG - 2017-11-14 17:43:07 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\partner-with-us.php
DEBUG - 2017-11-14 17:43:07 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/home_footer_nav.php
DEBUG - 2017-11-14 17:43:07 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/index_footer.php
INFO - 2017-11-14 17:43:07 --> Final output sent to browser
DEBUG - 2017-11-14 17:43:07 --> Total execution time: 0.0760
INFO - 2017-11-14 17:45:28 --> Config Class Initialized
INFO - 2017-11-14 17:45:28 --> Hooks Class Initialized
DEBUG - 2017-11-14 17:45:28 --> UTF-8 Support Enabled
INFO - 2017-11-14 17:45:28 --> Utf8 Class Initialized
INFO - 2017-11-14 17:45:28 --> URI Class Initialized
INFO - 2017-11-14 17:45:28 --> Router Class Initialized
INFO - 2017-11-14 17:45:28 --> Output Class Initialized
INFO - 2017-11-14 17:45:28 --> Security Class Initialized
DEBUG - 2017-11-14 17:45:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 17:45:28 --> Input Class Initialized
INFO - 2017-11-14 17:45:28 --> Language Class Initialized
INFO - 2017-11-14 17:45:28 --> Language Class Initialized
INFO - 2017-11-14 17:45:28 --> Config Class Initialized
INFO - 2017-11-14 17:45:28 --> Loader Class Initialized
DEBUG - 2017-11-14 17:45:28 --> Config file loaded: D:\xampp\htdocs\construction_bay\application\config/construct-data.php
INFO - 2017-11-14 17:45:28 --> Helper loaded: url_helper
INFO - 2017-11-14 17:45:28 --> Helper loaded: form_helper
INFO - 2017-11-14 17:45:28 --> Helper loaded: date_helper
INFO - 2017-11-14 17:45:28 --> Helper loaded: util_helper
INFO - 2017-11-14 17:45:28 --> Helper loaded: text_helper
INFO - 2017-11-14 17:45:28 --> Helper loaded: string_helper
INFO - 2017-11-14 17:45:28 --> Database Driver Class Initialized
DEBUG - 2017-11-14 17:45:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-14 17:45:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-14 17:45:28 --> Email Class Initialized
INFO - 2017-11-14 17:45:28 --> Controller Class Initialized
DEBUG - 2017-11-14 17:45:28 --> Home MX_Controller Initialized
INFO - 2017-11-14 17:45:28 --> Model Class Initialized
DEBUG - 2017-11-14 17:45:28 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_model.php
INFO - 2017-11-14 17:45:28 --> Model Class Initialized
DEBUG - 2017-11-14 17:45:28 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header_menu.php
DEBUG - 2017-11-14 17:45:28 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header.php
DEBUG - 2017-11-14 17:45:28 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\partner-with-us.php
DEBUG - 2017-11-14 17:45:28 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/home_footer_nav.php
DEBUG - 2017-11-14 17:45:28 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/index_footer.php
INFO - 2017-11-14 17:45:28 --> Final output sent to browser
DEBUG - 2017-11-14 17:45:28 --> Total execution time: 0.0490
INFO - 2017-11-14 17:45:29 --> Config Class Initialized
INFO - 2017-11-14 17:45:29 --> Hooks Class Initialized
DEBUG - 2017-11-14 17:45:29 --> UTF-8 Support Enabled
INFO - 2017-11-14 17:45:29 --> Utf8 Class Initialized
INFO - 2017-11-14 17:45:29 --> URI Class Initialized
DEBUG - 2017-11-14 17:45:29 --> No URI present. Default controller set.
INFO - 2017-11-14 17:45:29 --> Router Class Initialized
INFO - 2017-11-14 17:45:29 --> Output Class Initialized
INFO - 2017-11-14 17:45:29 --> Security Class Initialized
DEBUG - 2017-11-14 17:45:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 17:45:29 --> Input Class Initialized
INFO - 2017-11-14 17:45:29 --> Language Class Initialized
INFO - 2017-11-14 17:45:29 --> Language Class Initialized
INFO - 2017-11-14 17:45:29 --> Config Class Initialized
INFO - 2017-11-14 17:45:29 --> Loader Class Initialized
DEBUG - 2017-11-14 17:45:29 --> Config file loaded: D:\xampp\htdocs\construction_bay\application\config/construct-data.php
INFO - 2017-11-14 17:45:29 --> Helper loaded: url_helper
INFO - 2017-11-14 17:45:29 --> Helper loaded: form_helper
INFO - 2017-11-14 17:45:29 --> Helper loaded: date_helper
INFO - 2017-11-14 17:45:29 --> Helper loaded: util_helper
INFO - 2017-11-14 17:45:29 --> Helper loaded: text_helper
INFO - 2017-11-14 17:45:29 --> Helper loaded: string_helper
INFO - 2017-11-14 17:45:29 --> Database Driver Class Initialized
DEBUG - 2017-11-14 17:45:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-14 17:45:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-14 17:45:29 --> Email Class Initialized
INFO - 2017-11-14 17:45:29 --> Controller Class Initialized
DEBUG - 2017-11-14 17:45:29 --> Home MX_Controller Initialized
INFO - 2017-11-14 17:45:29 --> Model Class Initialized
DEBUG - 2017-11-14 17:45:29 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_model.php
INFO - 2017-11-14 17:45:29 --> Model Class Initialized
DEBUG - 2017-11-14 17:45:29 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header_menu.php
DEBUG - 2017-11-14 17:45:29 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header.php
DEBUG - 2017-11-14 17:45:29 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/slider.php
DEBUG - 2017-11-14 17:45:29 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/index_body.php
DEBUG - 2017-11-14 17:45:29 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/home_footer_nav.php
DEBUG - 2017-11-14 17:45:29 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/index_footer.php
INFO - 2017-11-14 17:45:29 --> Final output sent to browser
DEBUG - 2017-11-14 17:45:29 --> Total execution time: 0.0580
INFO - 2017-11-14 17:51:17 --> Config Class Initialized
INFO - 2017-11-14 17:51:17 --> Hooks Class Initialized
DEBUG - 2017-11-14 17:51:17 --> UTF-8 Support Enabled
INFO - 2017-11-14 17:51:17 --> Utf8 Class Initialized
INFO - 2017-11-14 17:51:17 --> URI Class Initialized
INFO - 2017-11-14 17:51:17 --> Router Class Initialized
INFO - 2017-11-14 17:51:17 --> Output Class Initialized
INFO - 2017-11-14 17:51:17 --> Security Class Initialized
DEBUG - 2017-11-14 17:51:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 17:51:17 --> Input Class Initialized
INFO - 2017-11-14 17:51:17 --> Language Class Initialized
INFO - 2017-11-14 17:51:17 --> Language Class Initialized
INFO - 2017-11-14 17:51:17 --> Config Class Initialized
INFO - 2017-11-14 17:51:17 --> Loader Class Initialized
DEBUG - 2017-11-14 17:51:17 --> Config file loaded: D:\xampp\htdocs\construction_bay\application\config/construct-data.php
INFO - 2017-11-14 17:51:17 --> Helper loaded: url_helper
INFO - 2017-11-14 17:51:17 --> Helper loaded: form_helper
INFO - 2017-11-14 17:51:17 --> Helper loaded: date_helper
INFO - 2017-11-14 17:51:17 --> Helper loaded: util_helper
INFO - 2017-11-14 17:51:17 --> Helper loaded: text_helper
INFO - 2017-11-14 17:51:17 --> Helper loaded: string_helper
INFO - 2017-11-14 17:51:17 --> Database Driver Class Initialized
DEBUG - 2017-11-14 17:51:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-14 17:51:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-14 17:51:17 --> Email Class Initialized
INFO - 2017-11-14 17:51:17 --> Controller Class Initialized
DEBUG - 2017-11-14 17:51:17 --> Home MX_Controller Initialized
INFO - 2017-11-14 17:51:17 --> Model Class Initialized
DEBUG - 2017-11-14 17:51:17 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_model.php
INFO - 2017-11-14 17:51:17 --> Model Class Initialized
DEBUG - 2017-11-14 17:51:17 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header_menu.php
DEBUG - 2017-11-14 17:51:17 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header.php
DEBUG - 2017-11-14 17:51:17 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\partner-with-us.php
DEBUG - 2017-11-14 17:51:17 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/home_footer_nav.php
DEBUG - 2017-11-14 17:51:17 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/index_footer.php
INFO - 2017-11-14 17:51:17 --> Final output sent to browser
DEBUG - 2017-11-14 17:51:17 --> Total execution time: 0.0510
INFO - 2017-11-14 17:51:42 --> Config Class Initialized
INFO - 2017-11-14 17:51:42 --> Hooks Class Initialized
DEBUG - 2017-11-14 17:51:42 --> UTF-8 Support Enabled
INFO - 2017-11-14 17:51:42 --> Utf8 Class Initialized
INFO - 2017-11-14 17:51:42 --> URI Class Initialized
DEBUG - 2017-11-14 17:51:42 --> No URI present. Default controller set.
INFO - 2017-11-14 17:51:42 --> Router Class Initialized
INFO - 2017-11-14 17:51:42 --> Output Class Initialized
INFO - 2017-11-14 17:51:42 --> Security Class Initialized
DEBUG - 2017-11-14 17:51:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 17:51:42 --> Input Class Initialized
INFO - 2017-11-14 17:51:42 --> Language Class Initialized
INFO - 2017-11-14 17:51:42 --> Language Class Initialized
INFO - 2017-11-14 17:51:42 --> Config Class Initialized
INFO - 2017-11-14 17:51:42 --> Loader Class Initialized
DEBUG - 2017-11-14 17:51:42 --> Config file loaded: D:\xampp\htdocs\construction_bay\application\config/construct-data.php
INFO - 2017-11-14 17:51:42 --> Helper loaded: url_helper
INFO - 2017-11-14 17:51:42 --> Helper loaded: form_helper
INFO - 2017-11-14 17:51:42 --> Helper loaded: date_helper
INFO - 2017-11-14 17:51:42 --> Helper loaded: util_helper
INFO - 2017-11-14 17:51:42 --> Helper loaded: text_helper
INFO - 2017-11-14 17:51:42 --> Helper loaded: string_helper
INFO - 2017-11-14 17:51:42 --> Database Driver Class Initialized
DEBUG - 2017-11-14 17:51:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-14 17:51:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-14 17:51:42 --> Email Class Initialized
INFO - 2017-11-14 17:51:42 --> Controller Class Initialized
DEBUG - 2017-11-14 17:51:42 --> Home MX_Controller Initialized
INFO - 2017-11-14 17:51:42 --> Model Class Initialized
DEBUG - 2017-11-14 17:51:42 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_model.php
INFO - 2017-11-14 17:51:42 --> Model Class Initialized
DEBUG - 2017-11-14 17:51:42 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header_menu.php
DEBUG - 2017-11-14 17:51:42 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header.php
DEBUG - 2017-11-14 17:51:42 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/slider.php
DEBUG - 2017-11-14 17:51:42 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/index_body.php
DEBUG - 2017-11-14 17:51:42 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/home_footer_nav.php
DEBUG - 2017-11-14 17:51:42 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/index_footer.php
INFO - 2017-11-14 17:51:42 --> Final output sent to browser
DEBUG - 2017-11-14 17:51:42 --> Total execution time: 0.0550
INFO - 2017-11-14 17:51:46 --> Config Class Initialized
INFO - 2017-11-14 17:51:46 --> Hooks Class Initialized
DEBUG - 2017-11-14 17:51:46 --> UTF-8 Support Enabled
INFO - 2017-11-14 17:51:46 --> Utf8 Class Initialized
INFO - 2017-11-14 17:51:46 --> URI Class Initialized
INFO - 2017-11-14 17:51:46 --> Router Class Initialized
INFO - 2017-11-14 17:51:46 --> Output Class Initialized
INFO - 2017-11-14 17:51:46 --> Security Class Initialized
DEBUG - 2017-11-14 17:51:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 17:51:46 --> Input Class Initialized
INFO - 2017-11-14 17:51:46 --> Language Class Initialized
INFO - 2017-11-14 17:51:46 --> Language Class Initialized
INFO - 2017-11-14 17:51:46 --> Config Class Initialized
INFO - 2017-11-14 17:51:46 --> Loader Class Initialized
DEBUG - 2017-11-14 17:51:46 --> Config file loaded: D:\xampp\htdocs\construction_bay\application\config/construct-data.php
INFO - 2017-11-14 17:51:46 --> Helper loaded: url_helper
INFO - 2017-11-14 17:51:46 --> Helper loaded: form_helper
INFO - 2017-11-14 17:51:46 --> Helper loaded: date_helper
INFO - 2017-11-14 17:51:46 --> Helper loaded: util_helper
INFO - 2017-11-14 17:51:46 --> Helper loaded: text_helper
INFO - 2017-11-14 17:51:46 --> Helper loaded: string_helper
INFO - 2017-11-14 17:51:46 --> Database Driver Class Initialized
DEBUG - 2017-11-14 17:51:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-14 17:51:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-14 17:51:46 --> Email Class Initialized
INFO - 2017-11-14 17:51:46 --> Controller Class Initialized
DEBUG - 2017-11-14 17:51:46 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header_menu.php
DEBUG - 2017-11-14 17:51:46 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header.php
DEBUG - 2017-11-14 17:51:46 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\welcome_page.php
DEBUG - 2017-11-14 17:51:46 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/footer_nav.php
DEBUG - 2017-11-14 17:51:46 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/footer.php
INFO - 2017-11-14 17:51:46 --> Final output sent to browser
DEBUG - 2017-11-14 17:51:46 --> Total execution time: 0.0760
INFO - 2017-11-14 17:52:13 --> Config Class Initialized
INFO - 2017-11-14 17:52:13 --> Hooks Class Initialized
DEBUG - 2017-11-14 17:52:13 --> UTF-8 Support Enabled
INFO - 2017-11-14 17:52:13 --> Utf8 Class Initialized
INFO - 2017-11-14 17:52:13 --> URI Class Initialized
DEBUG - 2017-11-14 17:52:13 --> No URI present. Default controller set.
INFO - 2017-11-14 17:52:13 --> Router Class Initialized
INFO - 2017-11-14 17:52:13 --> Output Class Initialized
INFO - 2017-11-14 17:52:13 --> Security Class Initialized
DEBUG - 2017-11-14 17:52:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 17:52:13 --> Input Class Initialized
INFO - 2017-11-14 17:52:13 --> Language Class Initialized
INFO - 2017-11-14 17:52:13 --> Language Class Initialized
INFO - 2017-11-14 17:52:13 --> Config Class Initialized
INFO - 2017-11-14 17:52:13 --> Loader Class Initialized
DEBUG - 2017-11-14 17:52:13 --> Config file loaded: D:\xampp\htdocs\construction_bay\application\config/construct-data.php
INFO - 2017-11-14 17:52:13 --> Helper loaded: url_helper
INFO - 2017-11-14 17:52:13 --> Helper loaded: form_helper
INFO - 2017-11-14 17:52:13 --> Helper loaded: date_helper
INFO - 2017-11-14 17:52:13 --> Helper loaded: util_helper
INFO - 2017-11-14 17:52:13 --> Helper loaded: text_helper
INFO - 2017-11-14 17:52:13 --> Helper loaded: string_helper
INFO - 2017-11-14 17:52:13 --> Database Driver Class Initialized
DEBUG - 2017-11-14 17:52:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-14 17:52:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-14 17:52:13 --> Email Class Initialized
INFO - 2017-11-14 17:52:13 --> Controller Class Initialized
DEBUG - 2017-11-14 17:52:13 --> Home MX_Controller Initialized
INFO - 2017-11-14 17:52:13 --> Model Class Initialized
DEBUG - 2017-11-14 17:52:13 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_model.php
INFO - 2017-11-14 17:52:13 --> Model Class Initialized
DEBUG - 2017-11-14 17:52:13 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header_menu.php
DEBUG - 2017-11-14 17:52:13 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header.php
DEBUG - 2017-11-14 17:52:13 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/slider.php
DEBUG - 2017-11-14 17:52:13 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/index_body.php
DEBUG - 2017-11-14 17:52:13 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/home_footer_nav.php
DEBUG - 2017-11-14 17:52:13 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/index_footer.php
INFO - 2017-11-14 17:52:13 --> Final output sent to browser
DEBUG - 2017-11-14 17:52:13 --> Total execution time: 0.0580
INFO - 2017-11-14 17:52:13 --> Config Class Initialized
INFO - 2017-11-14 17:52:13 --> Hooks Class Initialized
DEBUG - 2017-11-14 17:52:13 --> UTF-8 Support Enabled
INFO - 2017-11-14 17:52:13 --> Utf8 Class Initialized
INFO - 2017-11-14 17:52:13 --> URI Class Initialized
INFO - 2017-11-14 17:52:13 --> Router Class Initialized
INFO - 2017-11-14 17:52:13 --> Output Class Initialized
INFO - 2017-11-14 17:52:13 --> Security Class Initialized
DEBUG - 2017-11-14 17:52:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 17:52:13 --> Input Class Initialized
INFO - 2017-11-14 17:52:13 --> Language Class Initialized
INFO - 2017-11-14 17:52:13 --> Language Class Initialized
INFO - 2017-11-14 17:52:13 --> Config Class Initialized
INFO - 2017-11-14 17:52:13 --> Loader Class Initialized
DEBUG - 2017-11-14 17:52:13 --> Config file loaded: D:\xampp\htdocs\construction_bay\application\config/construct-data.php
INFO - 2017-11-14 17:52:13 --> Helper loaded: url_helper
INFO - 2017-11-14 17:52:13 --> Helper loaded: form_helper
INFO - 2017-11-14 17:52:13 --> Helper loaded: date_helper
INFO - 2017-11-14 17:52:13 --> Helper loaded: util_helper
INFO - 2017-11-14 17:52:13 --> Helper loaded: text_helper
INFO - 2017-11-14 17:52:13 --> Helper loaded: string_helper
INFO - 2017-11-14 17:52:13 --> Database Driver Class Initialized
DEBUG - 2017-11-14 17:52:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-14 17:52:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-14 17:52:13 --> Email Class Initialized
INFO - 2017-11-14 17:52:13 --> Controller Class Initialized
DEBUG - 2017-11-14 17:52:13 --> Home MX_Controller Initialized
INFO - 2017-11-14 17:52:13 --> Model Class Initialized
DEBUG - 2017-11-14 17:52:13 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_model.php
INFO - 2017-11-14 17:52:13 --> Model Class Initialized
DEBUG - 2017-11-14 17:52:13 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header_menu.php
DEBUG - 2017-11-14 17:52:13 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header.php
DEBUG - 2017-11-14 17:52:13 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\partner-with-us.php
DEBUG - 2017-11-14 17:52:13 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/home_footer_nav.php
DEBUG - 2017-11-14 17:52:13 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/index_footer.php
INFO - 2017-11-14 17:52:13 --> Final output sent to browser
DEBUG - 2017-11-14 17:52:13 --> Total execution time: 0.0590
INFO - 2017-11-14 17:58:32 --> Config Class Initialized
INFO - 2017-11-14 17:58:32 --> Hooks Class Initialized
DEBUG - 2017-11-14 17:58:32 --> UTF-8 Support Enabled
INFO - 2017-11-14 17:58:32 --> Utf8 Class Initialized
INFO - 2017-11-14 17:58:32 --> URI Class Initialized
INFO - 2017-11-14 17:58:32 --> Router Class Initialized
INFO - 2017-11-14 17:58:32 --> Output Class Initialized
INFO - 2017-11-14 17:58:32 --> Security Class Initialized
DEBUG - 2017-11-14 17:58:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 17:58:32 --> Input Class Initialized
INFO - 2017-11-14 17:58:32 --> Language Class Initialized
INFO - 2017-11-14 17:58:32 --> Language Class Initialized
INFO - 2017-11-14 17:58:32 --> Config Class Initialized
INFO - 2017-11-14 17:58:32 --> Loader Class Initialized
DEBUG - 2017-11-14 17:58:32 --> Config file loaded: D:\xampp\htdocs\construction_bay\application\config/construct-data.php
INFO - 2017-11-14 17:58:32 --> Helper loaded: url_helper
INFO - 2017-11-14 17:58:32 --> Helper loaded: form_helper
INFO - 2017-11-14 17:58:32 --> Helper loaded: date_helper
INFO - 2017-11-14 17:58:32 --> Helper loaded: util_helper
INFO - 2017-11-14 17:58:32 --> Helper loaded: text_helper
INFO - 2017-11-14 17:58:32 --> Helper loaded: string_helper
INFO - 2017-11-14 17:58:32 --> Database Driver Class Initialized
DEBUG - 2017-11-14 17:58:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-14 17:58:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-14 17:58:32 --> Email Class Initialized
INFO - 2017-11-14 17:58:32 --> Controller Class Initialized
DEBUG - 2017-11-14 17:58:32 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header_menu.php
DEBUG - 2017-11-14 17:58:32 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header.php
DEBUG - 2017-11-14 17:58:32 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\contact.php
DEBUG - 2017-11-14 17:58:32 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/footer_nav.php
DEBUG - 2017-11-14 17:58:32 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/footer.php
INFO - 2017-11-14 17:58:32 --> Final output sent to browser
DEBUG - 2017-11-14 17:58:32 --> Total execution time: 0.0930
INFO - 2017-11-14 17:58:35 --> Config Class Initialized
INFO - 2017-11-14 17:58:35 --> Hooks Class Initialized
DEBUG - 2017-11-14 17:58:35 --> UTF-8 Support Enabled
INFO - 2017-11-14 17:58:35 --> Utf8 Class Initialized
INFO - 2017-11-14 17:58:35 --> URI Class Initialized
INFO - 2017-11-14 17:58:35 --> Router Class Initialized
INFO - 2017-11-14 17:58:35 --> Output Class Initialized
INFO - 2017-11-14 17:58:35 --> Security Class Initialized
DEBUG - 2017-11-14 17:58:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 17:58:35 --> Input Class Initialized
INFO - 2017-11-14 17:58:35 --> Language Class Initialized
INFO - 2017-11-14 17:58:35 --> Language Class Initialized
INFO - 2017-11-14 17:58:35 --> Config Class Initialized
INFO - 2017-11-14 17:58:35 --> Loader Class Initialized
DEBUG - 2017-11-14 17:58:35 --> Config file loaded: D:\xampp\htdocs\construction_bay\application\config/construct-data.php
INFO - 2017-11-14 17:58:35 --> Helper loaded: url_helper
INFO - 2017-11-14 17:58:35 --> Helper loaded: form_helper
INFO - 2017-11-14 17:58:35 --> Helper loaded: date_helper
INFO - 2017-11-14 17:58:35 --> Helper loaded: util_helper
INFO - 2017-11-14 17:58:35 --> Helper loaded: text_helper
INFO - 2017-11-14 17:58:35 --> Helper loaded: string_helper
INFO - 2017-11-14 17:58:35 --> Database Driver Class Initialized
DEBUG - 2017-11-14 17:58:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-14 17:58:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-14 17:58:35 --> Email Class Initialized
INFO - 2017-11-14 17:58:35 --> Controller Class Initialized
INFO - 2017-11-14 17:58:35 --> Config Class Initialized
INFO - 2017-11-14 17:58:35 --> Hooks Class Initialized
DEBUG - 2017-11-14 17:58:35 --> UTF-8 Support Enabled
INFO - 2017-11-14 17:58:35 --> Utf8 Class Initialized
DEBUG - 2017-11-14 17:58:35 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header_menu.php
DEBUG - 2017-11-14 17:58:35 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header.php
INFO - 2017-11-14 17:58:35 --> URI Class Initialized
INFO - 2017-11-14 17:58:35 --> Router Class Initialized
INFO - 2017-11-14 17:58:35 --> Output Class Initialized
DEBUG - 2017-11-14 17:58:35 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\about_us.php
INFO - 2017-11-14 17:58:35 --> Security Class Initialized
DEBUG - 2017-11-14 17:58:35 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/footer_nav.php
DEBUG - 2017-11-14 17:58:35 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/footer.php
DEBUG - 2017-11-14 17:58:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 17:58:35 --> Input Class Initialized
INFO - 2017-11-14 17:58:35 --> Final output sent to browser
DEBUG - 2017-11-14 17:58:35 --> Total execution time: 0.1080
INFO - 2017-11-14 17:58:35 --> Language Class Initialized
ERROR - 2017-11-14 17:58:35 --> 404 Page Not Found: /index
INFO - 2017-11-14 17:59:31 --> Config Class Initialized
INFO - 2017-11-14 17:59:31 --> Hooks Class Initialized
DEBUG - 2017-11-14 17:59:31 --> UTF-8 Support Enabled
INFO - 2017-11-14 17:59:31 --> Utf8 Class Initialized
INFO - 2017-11-14 17:59:31 --> URI Class Initialized
INFO - 2017-11-14 17:59:31 --> Router Class Initialized
INFO - 2017-11-14 17:59:31 --> Output Class Initialized
INFO - 2017-11-14 17:59:31 --> Security Class Initialized
DEBUG - 2017-11-14 17:59:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 17:59:31 --> Input Class Initialized
INFO - 2017-11-14 17:59:31 --> Language Class Initialized
INFO - 2017-11-14 17:59:31 --> Language Class Initialized
INFO - 2017-11-14 17:59:31 --> Config Class Initialized
INFO - 2017-11-14 17:59:31 --> Loader Class Initialized
DEBUG - 2017-11-14 17:59:31 --> Config file loaded: D:\xampp\htdocs\construction_bay\application\config/construct-data.php
INFO - 2017-11-14 17:59:31 --> Helper loaded: url_helper
INFO - 2017-11-14 17:59:31 --> Helper loaded: form_helper
INFO - 2017-11-14 17:59:31 --> Helper loaded: date_helper
INFO - 2017-11-14 17:59:31 --> Helper loaded: util_helper
INFO - 2017-11-14 17:59:31 --> Helper loaded: text_helper
INFO - 2017-11-14 17:59:31 --> Helper loaded: string_helper
INFO - 2017-11-14 17:59:31 --> Database Driver Class Initialized
DEBUG - 2017-11-14 17:59:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-14 17:59:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-14 17:59:31 --> Email Class Initialized
INFO - 2017-11-14 17:59:31 --> Controller Class Initialized
DEBUG - 2017-11-14 17:59:31 --> Home MX_Controller Initialized
INFO - 2017-11-14 17:59:31 --> Model Class Initialized
DEBUG - 2017-11-14 17:59:31 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_model.php
INFO - 2017-11-14 17:59:31 --> Model Class Initialized
DEBUG - 2017-11-14 17:59:31 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header_menu.php
DEBUG - 2017-11-14 17:59:31 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header.php
DEBUG - 2017-11-14 17:59:31 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\partner-with-us.php
DEBUG - 2017-11-14 17:59:31 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/footer_nav.php
INFO - 2017-11-14 17:59:31 --> Final output sent to browser
DEBUG - 2017-11-14 17:59:31 --> Total execution time: 0.0590
INFO - 2017-11-14 18:27:42 --> Config Class Initialized
INFO - 2017-11-14 18:27:42 --> Hooks Class Initialized
DEBUG - 2017-11-14 18:27:42 --> UTF-8 Support Enabled
INFO - 2017-11-14 18:27:42 --> Utf8 Class Initialized
INFO - 2017-11-14 18:27:42 --> URI Class Initialized
INFO - 2017-11-14 18:27:42 --> Router Class Initialized
INFO - 2017-11-14 18:27:42 --> Output Class Initialized
INFO - 2017-11-14 18:27:42 --> Security Class Initialized
DEBUG - 2017-11-14 18:27:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 18:27:42 --> Input Class Initialized
INFO - 2017-11-14 18:27:42 --> Language Class Initialized
INFO - 2017-11-14 18:27:42 --> Language Class Initialized
INFO - 2017-11-14 18:27:42 --> Config Class Initialized
INFO - 2017-11-14 18:27:42 --> Loader Class Initialized
DEBUG - 2017-11-14 18:27:42 --> Config file loaded: D:\xampp\htdocs\construction_bay\application\config/construct-data.php
INFO - 2017-11-14 18:27:42 --> Helper loaded: url_helper
INFO - 2017-11-14 18:27:42 --> Helper loaded: form_helper
INFO - 2017-11-14 18:27:42 --> Helper loaded: date_helper
INFO - 2017-11-14 18:27:42 --> Helper loaded: util_helper
INFO - 2017-11-14 18:27:42 --> Helper loaded: text_helper
INFO - 2017-11-14 18:27:42 --> Helper loaded: string_helper
INFO - 2017-11-14 18:27:42 --> Database Driver Class Initialized
DEBUG - 2017-11-14 18:27:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-14 18:27:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-14 18:27:42 --> Email Class Initialized
INFO - 2017-11-14 18:27:42 --> Controller Class Initialized
DEBUG - 2017-11-14 18:27:42 --> Home MX_Controller Initialized
INFO - 2017-11-14 18:27:42 --> Model Class Initialized
DEBUG - 2017-11-14 18:27:42 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_model.php
INFO - 2017-11-14 18:27:42 --> Model Class Initialized
DEBUG - 2017-11-14 18:27:42 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header_menu.php
DEBUG - 2017-11-14 18:27:42 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header.php
DEBUG - 2017-11-14 18:27:42 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\partner-with-us.php
DEBUG - 2017-11-14 18:27:42 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/footer_nav.php
INFO - 2017-11-14 18:27:42 --> Final output sent to browser
DEBUG - 2017-11-14 18:27:42 --> Total execution time: 0.0590
INFO - 2017-11-14 18:27:49 --> Config Class Initialized
INFO - 2017-11-14 18:27:49 --> Hooks Class Initialized
DEBUG - 2017-11-14 18:27:49 --> UTF-8 Support Enabled
INFO - 2017-11-14 18:27:49 --> Utf8 Class Initialized
INFO - 2017-11-14 18:27:49 --> URI Class Initialized
INFO - 2017-11-14 18:27:49 --> Router Class Initialized
INFO - 2017-11-14 18:27:49 --> Output Class Initialized
INFO - 2017-11-14 18:27:49 --> Security Class Initialized
DEBUG - 2017-11-14 18:27:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 18:27:49 --> Input Class Initialized
INFO - 2017-11-14 18:27:49 --> Language Class Initialized
INFO - 2017-11-14 18:27:49 --> Language Class Initialized
INFO - 2017-11-14 18:27:49 --> Config Class Initialized
INFO - 2017-11-14 18:27:49 --> Loader Class Initialized
DEBUG - 2017-11-14 18:27:49 --> Config file loaded: D:\xampp\htdocs\construction_bay\application\config/construct-data.php
INFO - 2017-11-14 18:27:49 --> Helper loaded: url_helper
INFO - 2017-11-14 18:27:49 --> Helper loaded: form_helper
INFO - 2017-11-14 18:27:49 --> Helper loaded: date_helper
INFO - 2017-11-14 18:27:49 --> Helper loaded: util_helper
INFO - 2017-11-14 18:27:49 --> Helper loaded: text_helper
INFO - 2017-11-14 18:27:49 --> Helper loaded: string_helper
INFO - 2017-11-14 18:27:49 --> Database Driver Class Initialized
DEBUG - 2017-11-14 18:27:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-14 18:27:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-14 18:27:49 --> Email Class Initialized
INFO - 2017-11-14 18:27:49 --> Controller Class Initialized
DEBUG - 2017-11-14 18:27:49 --> Home MX_Controller Initialized
INFO - 2017-11-14 18:27:49 --> Model Class Initialized
DEBUG - 2017-11-14 18:27:49 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_model.php
INFO - 2017-11-14 18:27:49 --> Model Class Initialized
DEBUG - 2017-11-14 18:27:49 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header_menu.php
DEBUG - 2017-11-14 18:27:49 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header.php
DEBUG - 2017-11-14 18:27:49 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\partner-with-us.php
DEBUG - 2017-11-14 18:27:49 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/footer_nav.php
INFO - 2017-11-14 18:27:49 --> Final output sent to browser
DEBUG - 2017-11-14 18:27:49 --> Total execution time: 0.0630
INFO - 2017-11-14 18:27:56 --> Config Class Initialized
INFO - 2017-11-14 18:27:56 --> Hooks Class Initialized
DEBUG - 2017-11-14 18:27:56 --> UTF-8 Support Enabled
INFO - 2017-11-14 18:27:56 --> Utf8 Class Initialized
INFO - 2017-11-14 18:27:56 --> URI Class Initialized
INFO - 2017-11-14 18:27:56 --> Router Class Initialized
INFO - 2017-11-14 18:27:56 --> Output Class Initialized
INFO - 2017-11-14 18:27:56 --> Security Class Initialized
DEBUG - 2017-11-14 18:27:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 18:27:56 --> Input Class Initialized
INFO - 2017-11-14 18:27:56 --> Language Class Initialized
INFO - 2017-11-14 18:27:56 --> Language Class Initialized
INFO - 2017-11-14 18:27:56 --> Config Class Initialized
INFO - 2017-11-14 18:27:56 --> Loader Class Initialized
DEBUG - 2017-11-14 18:27:56 --> Config file loaded: D:\xampp\htdocs\construction_bay\application\config/construct-data.php
INFO - 2017-11-14 18:27:56 --> Helper loaded: url_helper
INFO - 2017-11-14 18:27:56 --> Helper loaded: form_helper
INFO - 2017-11-14 18:27:56 --> Helper loaded: date_helper
INFO - 2017-11-14 18:27:56 --> Helper loaded: util_helper
INFO - 2017-11-14 18:27:56 --> Helper loaded: text_helper
INFO - 2017-11-14 18:27:56 --> Helper loaded: string_helper
INFO - 2017-11-14 18:27:56 --> Database Driver Class Initialized
DEBUG - 2017-11-14 18:27:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-14 18:27:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-14 18:27:56 --> Email Class Initialized
INFO - 2017-11-14 18:27:56 --> Controller Class Initialized
DEBUG - 2017-11-14 18:27:56 --> Home MX_Controller Initialized
INFO - 2017-11-14 18:27:56 --> Model Class Initialized
DEBUG - 2017-11-14 18:27:56 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_model.php
INFO - 2017-11-14 18:27:56 --> Model Class Initialized
DEBUG - 2017-11-14 18:27:56 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header_menu.php
DEBUG - 2017-11-14 18:27:56 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header.php
DEBUG - 2017-11-14 18:27:56 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\partner-with-us.php
DEBUG - 2017-11-14 18:27:56 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/footer_nav.php
INFO - 2017-11-14 18:27:56 --> Final output sent to browser
DEBUG - 2017-11-14 18:27:56 --> Total execution time: 0.0520
INFO - 2017-11-14 18:27:57 --> Config Class Initialized
INFO - 2017-11-14 18:27:57 --> Hooks Class Initialized
DEBUG - 2017-11-14 18:27:57 --> UTF-8 Support Enabled
INFO - 2017-11-14 18:27:57 --> Utf8 Class Initialized
INFO - 2017-11-14 18:27:57 --> URI Class Initialized
INFO - 2017-11-14 18:27:57 --> Router Class Initialized
INFO - 2017-11-14 18:27:57 --> Output Class Initialized
INFO - 2017-11-14 18:27:57 --> Security Class Initialized
DEBUG - 2017-11-14 18:27:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 18:27:57 --> Input Class Initialized
INFO - 2017-11-14 18:27:57 --> Language Class Initialized
INFO - 2017-11-14 18:27:57 --> Language Class Initialized
INFO - 2017-11-14 18:27:57 --> Config Class Initialized
INFO - 2017-11-14 18:27:57 --> Loader Class Initialized
DEBUG - 2017-11-14 18:27:57 --> Config file loaded: D:\xampp\htdocs\construction_bay\application\config/construct-data.php
INFO - 2017-11-14 18:27:57 --> Helper loaded: url_helper
INFO - 2017-11-14 18:27:57 --> Helper loaded: form_helper
INFO - 2017-11-14 18:27:57 --> Helper loaded: date_helper
INFO - 2017-11-14 18:27:57 --> Helper loaded: util_helper
INFO - 2017-11-14 18:27:57 --> Helper loaded: text_helper
INFO - 2017-11-14 18:27:57 --> Helper loaded: string_helper
INFO - 2017-11-14 18:27:57 --> Database Driver Class Initialized
DEBUG - 2017-11-14 18:27:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-14 18:27:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-14 18:27:57 --> Email Class Initialized
INFO - 2017-11-14 18:27:57 --> Controller Class Initialized
ERROR - 2017-11-14 18:27:57 --> 404 Page Not Found: Home/favicon.ico
INFO - 2017-11-14 18:28:21 --> Config Class Initialized
INFO - 2017-11-14 18:28:21 --> Hooks Class Initialized
DEBUG - 2017-11-14 18:28:21 --> UTF-8 Support Enabled
INFO - 2017-11-14 18:28:21 --> Utf8 Class Initialized
INFO - 2017-11-14 18:28:21 --> URI Class Initialized
INFO - 2017-11-14 18:28:21 --> Router Class Initialized
INFO - 2017-11-14 18:28:21 --> Output Class Initialized
INFO - 2017-11-14 18:28:21 --> Security Class Initialized
DEBUG - 2017-11-14 18:28:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 18:28:21 --> Input Class Initialized
INFO - 2017-11-14 18:28:21 --> Language Class Initialized
INFO - 2017-11-14 18:28:21 --> Language Class Initialized
INFO - 2017-11-14 18:28:21 --> Config Class Initialized
INFO - 2017-11-14 18:28:21 --> Loader Class Initialized
DEBUG - 2017-11-14 18:28:21 --> Config file loaded: D:\xampp\htdocs\construction_bay\application\config/construct-data.php
INFO - 2017-11-14 18:28:21 --> Helper loaded: url_helper
INFO - 2017-11-14 18:28:21 --> Helper loaded: form_helper
INFO - 2017-11-14 18:28:21 --> Helper loaded: date_helper
INFO - 2017-11-14 18:28:21 --> Helper loaded: util_helper
INFO - 2017-11-14 18:28:21 --> Helper loaded: text_helper
INFO - 2017-11-14 18:28:21 --> Helper loaded: string_helper
INFO - 2017-11-14 18:28:21 --> Database Driver Class Initialized
DEBUG - 2017-11-14 18:28:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-14 18:28:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-14 18:28:21 --> Email Class Initialized
INFO - 2017-11-14 18:28:21 --> Controller Class Initialized
DEBUG - 2017-11-14 18:28:21 --> Home MX_Controller Initialized
INFO - 2017-11-14 18:28:21 --> Model Class Initialized
DEBUG - 2017-11-14 18:28:21 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_model.php
INFO - 2017-11-14 18:28:21 --> Model Class Initialized
DEBUG - 2017-11-14 18:28:21 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header_menu.php
DEBUG - 2017-11-14 18:28:21 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header.php
DEBUG - 2017-11-14 18:28:21 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\partner-with-us.php
DEBUG - 2017-11-14 18:28:21 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/footer_nav.php
INFO - 2017-11-14 18:28:21 --> Final output sent to browser
DEBUG - 2017-11-14 18:28:21 --> Total execution time: 0.0560
INFO - 2017-11-14 18:28:35 --> Config Class Initialized
INFO - 2017-11-14 18:28:35 --> Hooks Class Initialized
DEBUG - 2017-11-14 18:28:35 --> UTF-8 Support Enabled
INFO - 2017-11-14 18:28:35 --> Utf8 Class Initialized
INFO - 2017-11-14 18:28:35 --> URI Class Initialized
INFO - 2017-11-14 18:28:35 --> Router Class Initialized
INFO - 2017-11-14 18:28:35 --> Output Class Initialized
INFO - 2017-11-14 18:28:35 --> Security Class Initialized
DEBUG - 2017-11-14 18:28:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 18:28:35 --> Input Class Initialized
INFO - 2017-11-14 18:28:35 --> Language Class Initialized
INFO - 2017-11-14 18:28:35 --> Language Class Initialized
INFO - 2017-11-14 18:28:35 --> Config Class Initialized
INFO - 2017-11-14 18:28:36 --> Loader Class Initialized
DEBUG - 2017-11-14 18:28:36 --> Config file loaded: D:\xampp\htdocs\construction_bay\application\config/construct-data.php
INFO - 2017-11-14 18:28:36 --> Helper loaded: url_helper
INFO - 2017-11-14 18:28:36 --> Helper loaded: form_helper
INFO - 2017-11-14 18:28:36 --> Helper loaded: date_helper
INFO - 2017-11-14 18:28:36 --> Helper loaded: util_helper
INFO - 2017-11-14 18:28:36 --> Helper loaded: text_helper
INFO - 2017-11-14 18:28:36 --> Helper loaded: string_helper
INFO - 2017-11-14 18:28:36 --> Database Driver Class Initialized
DEBUG - 2017-11-14 18:28:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-14 18:28:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-14 18:28:36 --> Email Class Initialized
INFO - 2017-11-14 18:28:36 --> Controller Class Initialized
DEBUG - 2017-11-14 18:28:36 --> Home MX_Controller Initialized
INFO - 2017-11-14 18:28:36 --> Model Class Initialized
DEBUG - 2017-11-14 18:28:36 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_model.php
INFO - 2017-11-14 18:28:36 --> Model Class Initialized
DEBUG - 2017-11-14 18:28:36 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header_menu.php
DEBUG - 2017-11-14 18:28:36 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header.php
DEBUG - 2017-11-14 18:28:36 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\partner-with-us.php
DEBUG - 2017-11-14 18:28:36 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/footer_nav.php
INFO - 2017-11-14 18:28:36 --> Final output sent to browser
DEBUG - 2017-11-14 18:28:36 --> Total execution time: 0.0780
INFO - 2017-11-14 18:36:07 --> Config Class Initialized
INFO - 2017-11-14 18:36:07 --> Hooks Class Initialized
DEBUG - 2017-11-14 18:36:07 --> UTF-8 Support Enabled
INFO - 2017-11-14 18:36:07 --> Utf8 Class Initialized
INFO - 2017-11-14 18:36:07 --> URI Class Initialized
INFO - 2017-11-14 18:36:07 --> Router Class Initialized
INFO - 2017-11-14 18:36:07 --> Output Class Initialized
INFO - 2017-11-14 18:36:07 --> Security Class Initialized
DEBUG - 2017-11-14 18:36:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 18:36:07 --> Input Class Initialized
INFO - 2017-11-14 18:36:07 --> Language Class Initialized
INFO - 2017-11-14 18:36:07 --> Language Class Initialized
INFO - 2017-11-14 18:36:07 --> Config Class Initialized
INFO - 2017-11-14 18:36:07 --> Loader Class Initialized
DEBUG - 2017-11-14 18:36:07 --> Config file loaded: D:\xampp\htdocs\construction_bay\application\config/construct-data.php
INFO - 2017-11-14 18:36:07 --> Helper loaded: url_helper
INFO - 2017-11-14 18:36:07 --> Helper loaded: form_helper
INFO - 2017-11-14 18:36:07 --> Helper loaded: date_helper
INFO - 2017-11-14 18:36:07 --> Helper loaded: util_helper
INFO - 2017-11-14 18:36:07 --> Helper loaded: text_helper
INFO - 2017-11-14 18:36:07 --> Helper loaded: string_helper
INFO - 2017-11-14 18:36:07 --> Database Driver Class Initialized
DEBUG - 2017-11-14 18:36:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-14 18:36:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-14 18:36:07 --> Email Class Initialized
INFO - 2017-11-14 18:36:07 --> Controller Class Initialized
DEBUG - 2017-11-14 18:36:07 --> Home MX_Controller Initialized
INFO - 2017-11-14 18:36:07 --> Model Class Initialized
DEBUG - 2017-11-14 18:36:07 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_model.php
INFO - 2017-11-14 18:36:07 --> Model Class Initialized
DEBUG - 2017-11-14 18:36:07 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header_menu.php
DEBUG - 2017-11-14 18:36:07 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header.php
DEBUG - 2017-11-14 18:36:07 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\partner-with-us.php
DEBUG - 2017-11-14 18:36:07 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/footer_nav.php
INFO - 2017-11-14 18:36:07 --> Final output sent to browser
DEBUG - 2017-11-14 18:36:07 --> Total execution time: 0.0580
INFO - 2017-11-14 18:36:17 --> Config Class Initialized
INFO - 2017-11-14 18:36:17 --> Hooks Class Initialized
DEBUG - 2017-11-14 18:36:17 --> UTF-8 Support Enabled
INFO - 2017-11-14 18:36:17 --> Utf8 Class Initialized
INFO - 2017-11-14 18:36:17 --> URI Class Initialized
INFO - 2017-11-14 18:36:17 --> Router Class Initialized
INFO - 2017-11-14 18:36:17 --> Output Class Initialized
INFO - 2017-11-14 18:36:17 --> Security Class Initialized
DEBUG - 2017-11-14 18:36:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 18:36:17 --> Input Class Initialized
INFO - 2017-11-14 18:36:17 --> Language Class Initialized
INFO - 2017-11-14 18:36:17 --> Language Class Initialized
INFO - 2017-11-14 18:36:17 --> Config Class Initialized
INFO - 2017-11-14 18:36:17 --> Loader Class Initialized
DEBUG - 2017-11-14 18:36:17 --> Config file loaded: D:\xampp\htdocs\construction_bay\application\config/construct-data.php
INFO - 2017-11-14 18:36:17 --> Helper loaded: url_helper
INFO - 2017-11-14 18:36:17 --> Helper loaded: form_helper
INFO - 2017-11-14 18:36:17 --> Helper loaded: date_helper
INFO - 2017-11-14 18:36:17 --> Helper loaded: util_helper
INFO - 2017-11-14 18:36:17 --> Helper loaded: text_helper
INFO - 2017-11-14 18:36:17 --> Helper loaded: string_helper
INFO - 2017-11-14 18:36:17 --> Database Driver Class Initialized
DEBUG - 2017-11-14 18:36:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-14 18:36:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-14 18:36:17 --> Email Class Initialized
INFO - 2017-11-14 18:36:17 --> Controller Class Initialized
DEBUG - 2017-11-14 18:36:17 --> Home MX_Controller Initialized
INFO - 2017-11-14 18:36:17 --> Model Class Initialized
DEBUG - 2017-11-14 18:36:17 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_model.php
INFO - 2017-11-14 18:36:17 --> Model Class Initialized
DEBUG - 2017-11-14 18:36:17 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header_menu.php
DEBUG - 2017-11-14 18:36:17 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header.php
DEBUG - 2017-11-14 18:36:17 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\partner-with-us.php
DEBUG - 2017-11-14 18:36:17 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/footer_nav.php
INFO - 2017-11-14 18:36:17 --> Final output sent to browser
DEBUG - 2017-11-14 18:36:17 --> Total execution time: 0.0490
INFO - 2017-11-14 18:36:25 --> Config Class Initialized
INFO - 2017-11-14 18:36:25 --> Hooks Class Initialized
DEBUG - 2017-11-14 18:36:25 --> UTF-8 Support Enabled
INFO - 2017-11-14 18:36:25 --> Utf8 Class Initialized
INFO - 2017-11-14 18:36:25 --> URI Class Initialized
INFO - 2017-11-14 18:36:25 --> Router Class Initialized
INFO - 2017-11-14 18:36:25 --> Output Class Initialized
INFO - 2017-11-14 18:36:25 --> Security Class Initialized
DEBUG - 2017-11-14 18:36:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 18:36:25 --> Input Class Initialized
INFO - 2017-11-14 18:36:25 --> Language Class Initialized
INFO - 2017-11-14 18:36:25 --> Language Class Initialized
INFO - 2017-11-14 18:36:25 --> Config Class Initialized
INFO - 2017-11-14 18:36:25 --> Loader Class Initialized
DEBUG - 2017-11-14 18:36:25 --> Config file loaded: D:\xampp\htdocs\construction_bay\application\config/construct-data.php
INFO - 2017-11-14 18:36:25 --> Helper loaded: url_helper
INFO - 2017-11-14 18:36:25 --> Helper loaded: form_helper
INFO - 2017-11-14 18:36:25 --> Helper loaded: date_helper
INFO - 2017-11-14 18:36:25 --> Helper loaded: util_helper
INFO - 2017-11-14 18:36:25 --> Helper loaded: text_helper
INFO - 2017-11-14 18:36:25 --> Helper loaded: string_helper
INFO - 2017-11-14 18:36:25 --> Database Driver Class Initialized
DEBUG - 2017-11-14 18:36:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-14 18:36:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-14 18:36:25 --> Email Class Initialized
INFO - 2017-11-14 18:36:25 --> Controller Class Initialized
DEBUG - 2017-11-14 18:36:25 --> Home MX_Controller Initialized
INFO - 2017-11-14 18:36:25 --> Model Class Initialized
DEBUG - 2017-11-14 18:36:25 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_model.php
INFO - 2017-11-14 18:36:25 --> Model Class Initialized
DEBUG - 2017-11-14 18:36:25 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header_menu.php
DEBUG - 2017-11-14 18:36:25 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header.php
DEBUG - 2017-11-14 18:36:25 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\partner-with-us.php
DEBUG - 2017-11-14 18:36:25 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/footer_nav.php
INFO - 2017-11-14 18:36:25 --> Final output sent to browser
DEBUG - 2017-11-14 18:36:25 --> Total execution time: 0.0670
INFO - 2017-11-14 18:36:26 --> Config Class Initialized
INFO - 2017-11-14 18:36:26 --> Hooks Class Initialized
DEBUG - 2017-11-14 18:36:26 --> UTF-8 Support Enabled
INFO - 2017-11-14 18:36:26 --> Utf8 Class Initialized
INFO - 2017-11-14 18:36:26 --> URI Class Initialized
INFO - 2017-11-14 18:36:26 --> Router Class Initialized
INFO - 2017-11-14 18:36:26 --> Output Class Initialized
INFO - 2017-11-14 18:36:26 --> Security Class Initialized
DEBUG - 2017-11-14 18:36:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 18:36:26 --> Input Class Initialized
INFO - 2017-11-14 18:36:26 --> Language Class Initialized
INFO - 2017-11-14 18:36:26 --> Language Class Initialized
INFO - 2017-11-14 18:36:26 --> Config Class Initialized
INFO - 2017-11-14 18:36:26 --> Loader Class Initialized
DEBUG - 2017-11-14 18:36:26 --> Config file loaded: D:\xampp\htdocs\construction_bay\application\config/construct-data.php
INFO - 2017-11-14 18:36:26 --> Helper loaded: url_helper
INFO - 2017-11-14 18:36:26 --> Helper loaded: form_helper
INFO - 2017-11-14 18:36:26 --> Helper loaded: date_helper
INFO - 2017-11-14 18:36:26 --> Helper loaded: util_helper
INFO - 2017-11-14 18:36:26 --> Helper loaded: text_helper
INFO - 2017-11-14 18:36:26 --> Helper loaded: string_helper
INFO - 2017-11-14 18:36:26 --> Database Driver Class Initialized
DEBUG - 2017-11-14 18:36:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-14 18:36:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-14 18:36:26 --> Email Class Initialized
INFO - 2017-11-14 18:36:26 --> Controller Class Initialized
DEBUG - 2017-11-14 18:36:26 --> Home MX_Controller Initialized
INFO - 2017-11-14 18:36:26 --> Model Class Initialized
DEBUG - 2017-11-14 18:36:26 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_model.php
INFO - 2017-11-14 18:36:26 --> Model Class Initialized
DEBUG - 2017-11-14 18:36:26 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header_menu.php
DEBUG - 2017-11-14 18:36:26 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header.php
DEBUG - 2017-11-14 18:36:26 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\partner-with-us.php
DEBUG - 2017-11-14 18:36:26 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/footer_nav.php
INFO - 2017-11-14 18:36:26 --> Final output sent to browser
DEBUG - 2017-11-14 18:36:26 --> Total execution time: 0.0560
INFO - 2017-11-14 18:36:27 --> Config Class Initialized
INFO - 2017-11-14 18:36:27 --> Hooks Class Initialized
DEBUG - 2017-11-14 18:36:27 --> UTF-8 Support Enabled
INFO - 2017-11-14 18:36:27 --> Utf8 Class Initialized
INFO - 2017-11-14 18:36:27 --> URI Class Initialized
INFO - 2017-11-14 18:36:27 --> Router Class Initialized
INFO - 2017-11-14 18:36:27 --> Output Class Initialized
INFO - 2017-11-14 18:36:27 --> Security Class Initialized
DEBUG - 2017-11-14 18:36:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 18:36:27 --> Input Class Initialized
INFO - 2017-11-14 18:36:27 --> Language Class Initialized
INFO - 2017-11-14 18:36:27 --> Language Class Initialized
INFO - 2017-11-14 18:36:27 --> Config Class Initialized
INFO - 2017-11-14 18:36:27 --> Loader Class Initialized
DEBUG - 2017-11-14 18:36:27 --> Config file loaded: D:\xampp\htdocs\construction_bay\application\config/construct-data.php
INFO - 2017-11-14 18:36:27 --> Helper loaded: url_helper
INFO - 2017-11-14 18:36:27 --> Helper loaded: form_helper
INFO - 2017-11-14 18:36:27 --> Helper loaded: date_helper
INFO - 2017-11-14 18:36:27 --> Helper loaded: util_helper
INFO - 2017-11-14 18:36:27 --> Helper loaded: text_helper
INFO - 2017-11-14 18:36:27 --> Helper loaded: string_helper
INFO - 2017-11-14 18:36:27 --> Database Driver Class Initialized
DEBUG - 2017-11-14 18:36:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-14 18:36:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-14 18:36:27 --> Email Class Initialized
INFO - 2017-11-14 18:36:27 --> Controller Class Initialized
DEBUG - 2017-11-14 18:36:27 --> Home MX_Controller Initialized
INFO - 2017-11-14 18:36:27 --> Model Class Initialized
DEBUG - 2017-11-14 18:36:27 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_model.php
INFO - 2017-11-14 18:36:27 --> Model Class Initialized
DEBUG - 2017-11-14 18:36:27 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header_menu.php
DEBUG - 2017-11-14 18:36:27 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header.php
DEBUG - 2017-11-14 18:36:27 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\partner-with-us.php
DEBUG - 2017-11-14 18:36:27 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/footer_nav.php
INFO - 2017-11-14 18:36:27 --> Final output sent to browser
DEBUG - 2017-11-14 18:36:27 --> Total execution time: 0.0750
INFO - 2017-11-14 18:36:27 --> Config Class Initialized
INFO - 2017-11-14 18:36:27 --> Hooks Class Initialized
DEBUG - 2017-11-14 18:36:27 --> UTF-8 Support Enabled
INFO - 2017-11-14 18:36:27 --> Utf8 Class Initialized
INFO - 2017-11-14 18:36:27 --> URI Class Initialized
INFO - 2017-11-14 18:36:27 --> Router Class Initialized
INFO - 2017-11-14 18:36:27 --> Output Class Initialized
INFO - 2017-11-14 18:36:27 --> Security Class Initialized
DEBUG - 2017-11-14 18:36:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 18:36:27 --> Input Class Initialized
INFO - 2017-11-14 18:36:27 --> Language Class Initialized
INFO - 2017-11-14 18:36:27 --> Language Class Initialized
INFO - 2017-11-14 18:36:27 --> Config Class Initialized
INFO - 2017-11-14 18:36:27 --> Loader Class Initialized
DEBUG - 2017-11-14 18:36:27 --> Config file loaded: D:\xampp\htdocs\construction_bay\application\config/construct-data.php
INFO - 2017-11-14 18:36:27 --> Helper loaded: url_helper
INFO - 2017-11-14 18:36:27 --> Helper loaded: form_helper
INFO - 2017-11-14 18:36:27 --> Helper loaded: date_helper
INFO - 2017-11-14 18:36:27 --> Helper loaded: util_helper
INFO - 2017-11-14 18:36:27 --> Helper loaded: text_helper
INFO - 2017-11-14 18:36:27 --> Helper loaded: string_helper
INFO - 2017-11-14 18:36:27 --> Database Driver Class Initialized
DEBUG - 2017-11-14 18:36:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-14 18:36:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-14 18:36:27 --> Email Class Initialized
INFO - 2017-11-14 18:36:27 --> Controller Class Initialized
DEBUG - 2017-11-14 18:36:27 --> Home MX_Controller Initialized
INFO - 2017-11-14 18:36:27 --> Model Class Initialized
DEBUG - 2017-11-14 18:36:27 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_model.php
INFO - 2017-11-14 18:36:27 --> Model Class Initialized
DEBUG - 2017-11-14 18:36:27 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header_menu.php
DEBUG - 2017-11-14 18:36:27 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header.php
DEBUG - 2017-11-14 18:36:27 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\partner-with-us.php
DEBUG - 2017-11-14 18:36:27 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/footer_nav.php
INFO - 2017-11-14 18:36:27 --> Final output sent to browser
DEBUG - 2017-11-14 18:36:27 --> Total execution time: 0.1410
INFO - 2017-11-14 18:36:27 --> Config Class Initialized
INFO - 2017-11-14 18:36:27 --> Hooks Class Initialized
DEBUG - 2017-11-14 18:36:27 --> UTF-8 Support Enabled
INFO - 2017-11-14 18:36:27 --> Utf8 Class Initialized
INFO - 2017-11-14 18:36:27 --> URI Class Initialized
INFO - 2017-11-14 18:36:27 --> Router Class Initialized
INFO - 2017-11-14 18:36:27 --> Output Class Initialized
INFO - 2017-11-14 18:36:27 --> Security Class Initialized
DEBUG - 2017-11-14 18:36:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 18:36:27 --> Input Class Initialized
INFO - 2017-11-14 18:36:27 --> Language Class Initialized
INFO - 2017-11-14 18:36:27 --> Language Class Initialized
INFO - 2017-11-14 18:36:27 --> Config Class Initialized
INFO - 2017-11-14 18:36:27 --> Loader Class Initialized
DEBUG - 2017-11-14 18:36:27 --> Config file loaded: D:\xampp\htdocs\construction_bay\application\config/construct-data.php
INFO - 2017-11-14 18:36:27 --> Helper loaded: url_helper
INFO - 2017-11-14 18:36:27 --> Helper loaded: form_helper
INFO - 2017-11-14 18:36:27 --> Helper loaded: date_helper
INFO - 2017-11-14 18:36:27 --> Helper loaded: util_helper
INFO - 2017-11-14 18:36:27 --> Helper loaded: text_helper
INFO - 2017-11-14 18:36:27 --> Helper loaded: string_helper
INFO - 2017-11-14 18:36:27 --> Database Driver Class Initialized
DEBUG - 2017-11-14 18:36:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-14 18:36:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-14 18:36:27 --> Email Class Initialized
INFO - 2017-11-14 18:36:27 --> Controller Class Initialized
DEBUG - 2017-11-14 18:36:27 --> Home MX_Controller Initialized
INFO - 2017-11-14 18:36:27 --> Model Class Initialized
DEBUG - 2017-11-14 18:36:27 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_model.php
INFO - 2017-11-14 18:36:27 --> Model Class Initialized
DEBUG - 2017-11-14 18:36:27 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header_menu.php
DEBUG - 2017-11-14 18:36:27 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header.php
DEBUG - 2017-11-14 18:36:27 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\partner-with-us.php
DEBUG - 2017-11-14 18:36:27 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/footer_nav.php
INFO - 2017-11-14 18:36:27 --> Final output sent to browser
DEBUG - 2017-11-14 18:36:27 --> Total execution time: 0.0530
INFO - 2017-11-14 18:36:39 --> Config Class Initialized
INFO - 2017-11-14 18:36:39 --> Hooks Class Initialized
DEBUG - 2017-11-14 18:36:39 --> UTF-8 Support Enabled
INFO - 2017-11-14 18:36:39 --> Utf8 Class Initialized
INFO - 2017-11-14 18:36:39 --> URI Class Initialized
INFO - 2017-11-14 18:36:39 --> Router Class Initialized
INFO - 2017-11-14 18:36:39 --> Output Class Initialized
INFO - 2017-11-14 18:36:39 --> Security Class Initialized
DEBUG - 2017-11-14 18:36:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 18:36:39 --> Input Class Initialized
INFO - 2017-11-14 18:36:39 --> Language Class Initialized
INFO - 2017-11-14 18:36:39 --> Language Class Initialized
INFO - 2017-11-14 18:36:39 --> Config Class Initialized
INFO - 2017-11-14 18:36:39 --> Loader Class Initialized
DEBUG - 2017-11-14 18:36:39 --> Config file loaded: D:\xampp\htdocs\construction_bay\application\config/construct-data.php
INFO - 2017-11-14 18:36:39 --> Helper loaded: url_helper
INFO - 2017-11-14 18:36:39 --> Helper loaded: form_helper
INFO - 2017-11-14 18:36:39 --> Helper loaded: date_helper
INFO - 2017-11-14 18:36:39 --> Helper loaded: util_helper
INFO - 2017-11-14 18:36:39 --> Helper loaded: text_helper
INFO - 2017-11-14 18:36:39 --> Helper loaded: string_helper
INFO - 2017-11-14 18:36:39 --> Database Driver Class Initialized
DEBUG - 2017-11-14 18:36:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-14 18:36:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-14 18:36:39 --> Email Class Initialized
INFO - 2017-11-14 18:36:39 --> Controller Class Initialized
DEBUG - 2017-11-14 18:36:39 --> Home MX_Controller Initialized
INFO - 2017-11-14 18:36:39 --> Model Class Initialized
DEBUG - 2017-11-14 18:36:39 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_model.php
INFO - 2017-11-14 18:36:39 --> Model Class Initialized
DEBUG - 2017-11-14 18:36:39 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header_menu.php
DEBUG - 2017-11-14 18:36:39 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header.php
DEBUG - 2017-11-14 18:36:39 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\partner-with-us.php
DEBUG - 2017-11-14 18:36:39 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/footer_nav.php
INFO - 2017-11-14 18:36:39 --> Final output sent to browser
DEBUG - 2017-11-14 18:36:39 --> Total execution time: 0.0490
INFO - 2017-11-14 18:36:56 --> Config Class Initialized
INFO - 2017-11-14 18:36:56 --> Hooks Class Initialized
DEBUG - 2017-11-14 18:36:56 --> UTF-8 Support Enabled
INFO - 2017-11-14 18:36:56 --> Utf8 Class Initialized
INFO - 2017-11-14 18:36:56 --> URI Class Initialized
INFO - 2017-11-14 18:36:56 --> Router Class Initialized
INFO - 2017-11-14 18:36:56 --> Output Class Initialized
INFO - 2017-11-14 18:36:56 --> Security Class Initialized
DEBUG - 2017-11-14 18:36:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 18:36:56 --> Input Class Initialized
INFO - 2017-11-14 18:36:56 --> Language Class Initialized
INFO - 2017-11-14 18:36:56 --> Language Class Initialized
INFO - 2017-11-14 18:36:56 --> Config Class Initialized
INFO - 2017-11-14 18:36:56 --> Loader Class Initialized
DEBUG - 2017-11-14 18:36:56 --> Config file loaded: D:\xampp\htdocs\construction_bay\application\config/construct-data.php
INFO - 2017-11-14 18:36:56 --> Helper loaded: url_helper
INFO - 2017-11-14 18:36:56 --> Helper loaded: form_helper
INFO - 2017-11-14 18:36:56 --> Helper loaded: date_helper
INFO - 2017-11-14 18:36:56 --> Helper loaded: util_helper
INFO - 2017-11-14 18:36:56 --> Helper loaded: text_helper
INFO - 2017-11-14 18:36:56 --> Helper loaded: string_helper
INFO - 2017-11-14 18:36:56 --> Database Driver Class Initialized
DEBUG - 2017-11-14 18:36:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-14 18:36:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-14 18:36:56 --> Email Class Initialized
INFO - 2017-11-14 18:36:56 --> Controller Class Initialized
DEBUG - 2017-11-14 18:36:56 --> Home MX_Controller Initialized
INFO - 2017-11-14 18:36:56 --> Model Class Initialized
DEBUG - 2017-11-14 18:36:56 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_model.php
INFO - 2017-11-14 18:36:56 --> Model Class Initialized
DEBUG - 2017-11-14 18:36:56 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header_menu.php
DEBUG - 2017-11-14 18:36:56 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header.php
DEBUG - 2017-11-14 18:36:56 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\partner-with-us.php
DEBUG - 2017-11-14 18:36:56 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/footer_nav.php
INFO - 2017-11-14 18:36:56 --> Final output sent to browser
DEBUG - 2017-11-14 18:36:56 --> Total execution time: 0.0570
INFO - 2017-11-14 18:37:19 --> Config Class Initialized
INFO - 2017-11-14 18:37:19 --> Hooks Class Initialized
DEBUG - 2017-11-14 18:37:19 --> UTF-8 Support Enabled
INFO - 2017-11-14 18:37:19 --> Utf8 Class Initialized
INFO - 2017-11-14 18:37:19 --> URI Class Initialized
INFO - 2017-11-14 18:37:19 --> Router Class Initialized
INFO - 2017-11-14 18:37:19 --> Output Class Initialized
INFO - 2017-11-14 18:37:19 --> Security Class Initialized
DEBUG - 2017-11-14 18:37:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 18:37:20 --> Input Class Initialized
INFO - 2017-11-14 18:37:20 --> Language Class Initialized
INFO - 2017-11-14 18:37:20 --> Language Class Initialized
INFO - 2017-11-14 18:37:20 --> Config Class Initialized
INFO - 2017-11-14 18:37:20 --> Loader Class Initialized
DEBUG - 2017-11-14 18:37:20 --> Config file loaded: D:\xampp\htdocs\construction_bay\application\config/construct-data.php
INFO - 2017-11-14 18:37:20 --> Helper loaded: url_helper
INFO - 2017-11-14 18:37:20 --> Helper loaded: form_helper
INFO - 2017-11-14 18:37:20 --> Helper loaded: date_helper
INFO - 2017-11-14 18:37:20 --> Helper loaded: util_helper
INFO - 2017-11-14 18:37:20 --> Helper loaded: text_helper
INFO - 2017-11-14 18:37:20 --> Helper loaded: string_helper
INFO - 2017-11-14 18:37:20 --> Database Driver Class Initialized
DEBUG - 2017-11-14 18:37:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-14 18:37:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-14 18:37:20 --> Email Class Initialized
INFO - 2017-11-14 18:37:20 --> Controller Class Initialized
DEBUG - 2017-11-14 18:37:20 --> Home MX_Controller Initialized
INFO - 2017-11-14 18:37:20 --> Model Class Initialized
DEBUG - 2017-11-14 18:37:20 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_model.php
INFO - 2017-11-14 18:37:20 --> Model Class Initialized
DEBUG - 2017-11-14 18:37:20 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header_menu.php
DEBUG - 2017-11-14 18:37:20 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header.php
DEBUG - 2017-11-14 18:37:20 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\partner-with-us.php
DEBUG - 2017-11-14 18:37:20 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/footer_nav.php
INFO - 2017-11-14 18:37:20 --> Final output sent to browser
DEBUG - 2017-11-14 18:37:20 --> Total execution time: 0.0610
INFO - 2017-11-14 18:37:44 --> Config Class Initialized
INFO - 2017-11-14 18:37:44 --> Hooks Class Initialized
DEBUG - 2017-11-14 18:37:44 --> UTF-8 Support Enabled
INFO - 2017-11-14 18:37:44 --> Utf8 Class Initialized
INFO - 2017-11-14 18:37:44 --> URI Class Initialized
INFO - 2017-11-14 18:37:44 --> Router Class Initialized
INFO - 2017-11-14 18:37:44 --> Output Class Initialized
INFO - 2017-11-14 18:37:44 --> Security Class Initialized
DEBUG - 2017-11-14 18:37:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 18:37:44 --> Input Class Initialized
INFO - 2017-11-14 18:37:44 --> Language Class Initialized
INFO - 2017-11-14 18:37:44 --> Language Class Initialized
INFO - 2017-11-14 18:37:44 --> Config Class Initialized
INFO - 2017-11-14 18:37:44 --> Loader Class Initialized
DEBUG - 2017-11-14 18:37:44 --> Config file loaded: D:\xampp\htdocs\construction_bay\application\config/construct-data.php
INFO - 2017-11-14 18:37:44 --> Helper loaded: url_helper
INFO - 2017-11-14 18:37:44 --> Helper loaded: form_helper
INFO - 2017-11-14 18:37:44 --> Helper loaded: date_helper
INFO - 2017-11-14 18:37:44 --> Helper loaded: util_helper
INFO - 2017-11-14 18:37:44 --> Helper loaded: text_helper
INFO - 2017-11-14 18:37:44 --> Helper loaded: string_helper
INFO - 2017-11-14 18:37:44 --> Database Driver Class Initialized
DEBUG - 2017-11-14 18:37:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-14 18:37:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-14 18:37:44 --> Email Class Initialized
INFO - 2017-11-14 18:37:44 --> Controller Class Initialized
DEBUG - 2017-11-14 18:37:44 --> Home MX_Controller Initialized
INFO - 2017-11-14 18:37:44 --> Model Class Initialized
DEBUG - 2017-11-14 18:37:44 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_model.php
INFO - 2017-11-14 18:37:44 --> Model Class Initialized
DEBUG - 2017-11-14 18:37:44 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header_menu.php
DEBUG - 2017-11-14 18:37:44 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header.php
DEBUG - 2017-11-14 18:37:44 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\partner-with-us.php
DEBUG - 2017-11-14 18:37:44 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/footer_nav.php
INFO - 2017-11-14 18:37:44 --> Final output sent to browser
DEBUG - 2017-11-14 18:37:44 --> Total execution time: 0.0820
INFO - 2017-11-14 18:38:07 --> Config Class Initialized
INFO - 2017-11-14 18:38:07 --> Hooks Class Initialized
DEBUG - 2017-11-14 18:38:07 --> UTF-8 Support Enabled
INFO - 2017-11-14 18:38:07 --> Utf8 Class Initialized
INFO - 2017-11-14 18:38:07 --> URI Class Initialized
INFO - 2017-11-14 18:38:07 --> Router Class Initialized
INFO - 2017-11-14 18:38:07 --> Output Class Initialized
INFO - 2017-11-14 18:38:07 --> Security Class Initialized
DEBUG - 2017-11-14 18:38:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 18:38:07 --> Input Class Initialized
INFO - 2017-11-14 18:38:07 --> Language Class Initialized
INFO - 2017-11-14 18:38:07 --> Language Class Initialized
INFO - 2017-11-14 18:38:07 --> Config Class Initialized
INFO - 2017-11-14 18:38:07 --> Loader Class Initialized
DEBUG - 2017-11-14 18:38:07 --> Config file loaded: D:\xampp\htdocs\construction_bay\application\config/construct-data.php
INFO - 2017-11-14 18:38:07 --> Helper loaded: url_helper
INFO - 2017-11-14 18:38:07 --> Helper loaded: form_helper
INFO - 2017-11-14 18:38:07 --> Helper loaded: date_helper
INFO - 2017-11-14 18:38:07 --> Helper loaded: util_helper
INFO - 2017-11-14 18:38:07 --> Helper loaded: text_helper
INFO - 2017-11-14 18:38:07 --> Helper loaded: string_helper
INFO - 2017-11-14 18:38:07 --> Database Driver Class Initialized
DEBUG - 2017-11-14 18:38:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-14 18:38:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-14 18:38:07 --> Email Class Initialized
INFO - 2017-11-14 18:38:07 --> Controller Class Initialized
ERROR - 2017-11-14 18:38:07 --> 404 Page Not Found: Home/partner_with_us
INFO - 2017-11-14 18:38:11 --> Config Class Initialized
INFO - 2017-11-14 18:38:11 --> Hooks Class Initialized
DEBUG - 2017-11-14 18:38:11 --> UTF-8 Support Enabled
INFO - 2017-11-14 18:38:11 --> Utf8 Class Initialized
INFO - 2017-11-14 18:38:11 --> URI Class Initialized
INFO - 2017-11-14 18:38:11 --> Router Class Initialized
INFO - 2017-11-14 18:38:11 --> Output Class Initialized
INFO - 2017-11-14 18:38:11 --> Security Class Initialized
DEBUG - 2017-11-14 18:38:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 18:38:11 --> Input Class Initialized
INFO - 2017-11-14 18:38:11 --> Language Class Initialized
INFO - 2017-11-14 18:38:11 --> Language Class Initialized
INFO - 2017-11-14 18:38:11 --> Config Class Initialized
INFO - 2017-11-14 18:38:11 --> Loader Class Initialized
DEBUG - 2017-11-14 18:38:11 --> Config file loaded: D:\xampp\htdocs\construction_bay\application\config/construct-data.php
INFO - 2017-11-14 18:38:11 --> Helper loaded: url_helper
INFO - 2017-11-14 18:38:11 --> Helper loaded: form_helper
INFO - 2017-11-14 18:38:11 --> Helper loaded: date_helper
INFO - 2017-11-14 18:38:11 --> Helper loaded: util_helper
INFO - 2017-11-14 18:38:11 --> Helper loaded: text_helper
INFO - 2017-11-14 18:38:11 --> Helper loaded: string_helper
INFO - 2017-11-14 18:38:11 --> Database Driver Class Initialized
DEBUG - 2017-11-14 18:38:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-14 18:38:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-14 18:38:11 --> Email Class Initialized
INFO - 2017-11-14 18:38:11 --> Controller Class Initialized
DEBUG - 2017-11-14 18:38:11 --> Home MX_Controller Initialized
INFO - 2017-11-14 18:38:11 --> Model Class Initialized
DEBUG - 2017-11-14 18:38:11 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_model.php
INFO - 2017-11-14 18:38:11 --> Model Class Initialized
DEBUG - 2017-11-14 18:38:11 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header_menu.php
DEBUG - 2017-11-14 18:38:11 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header.php
DEBUG - 2017-11-14 18:38:11 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\partner-with-us.php
DEBUG - 2017-11-14 18:38:11 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/footer_nav.php
INFO - 2017-11-14 18:38:11 --> Final output sent to browser
DEBUG - 2017-11-14 18:38:11 --> Total execution time: 0.0650
INFO - 2017-11-14 18:38:21 --> Config Class Initialized
INFO - 2017-11-14 18:38:21 --> Hooks Class Initialized
DEBUG - 2017-11-14 18:38:21 --> UTF-8 Support Enabled
INFO - 2017-11-14 18:38:21 --> Utf8 Class Initialized
INFO - 2017-11-14 18:38:21 --> URI Class Initialized
INFO - 2017-11-14 18:38:21 --> Router Class Initialized
INFO - 2017-11-14 18:38:21 --> Output Class Initialized
INFO - 2017-11-14 18:38:21 --> Security Class Initialized
DEBUG - 2017-11-14 18:38:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 18:38:21 --> Input Class Initialized
INFO - 2017-11-14 18:38:21 --> Language Class Initialized
INFO - 2017-11-14 18:38:21 --> Language Class Initialized
INFO - 2017-11-14 18:38:21 --> Config Class Initialized
INFO - 2017-11-14 18:38:21 --> Loader Class Initialized
DEBUG - 2017-11-14 18:38:21 --> Config file loaded: D:\xampp\htdocs\construction_bay\application\config/construct-data.php
INFO - 2017-11-14 18:38:21 --> Helper loaded: url_helper
INFO - 2017-11-14 18:38:21 --> Helper loaded: form_helper
INFO - 2017-11-14 18:38:21 --> Helper loaded: date_helper
INFO - 2017-11-14 18:38:21 --> Helper loaded: util_helper
INFO - 2017-11-14 18:38:21 --> Helper loaded: text_helper
INFO - 2017-11-14 18:38:21 --> Helper loaded: string_helper
INFO - 2017-11-14 18:38:21 --> Database Driver Class Initialized
DEBUG - 2017-11-14 18:38:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-14 18:38:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-14 18:38:21 --> Email Class Initialized
INFO - 2017-11-14 18:38:21 --> Controller Class Initialized
DEBUG - 2017-11-14 18:38:21 --> Home MX_Controller Initialized
INFO - 2017-11-14 18:38:21 --> Model Class Initialized
DEBUG - 2017-11-14 18:38:21 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_model.php
INFO - 2017-11-14 18:38:21 --> Model Class Initialized
DEBUG - 2017-11-14 18:38:21 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header_menu.php
DEBUG - 2017-11-14 18:38:21 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header.php
DEBUG - 2017-11-14 18:38:21 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\partner-with-us.php
DEBUG - 2017-11-14 18:38:21 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/footer_nav.php
INFO - 2017-11-14 18:38:21 --> Final output sent to browser
DEBUG - 2017-11-14 18:38:21 --> Total execution time: 0.0630
INFO - 2017-11-14 18:38:22 --> Config Class Initialized
INFO - 2017-11-14 18:38:22 --> Hooks Class Initialized
DEBUG - 2017-11-14 18:38:22 --> UTF-8 Support Enabled
INFO - 2017-11-14 18:38:22 --> Utf8 Class Initialized
INFO - 2017-11-14 18:38:22 --> URI Class Initialized
INFO - 2017-11-14 18:38:22 --> Router Class Initialized
INFO - 2017-11-14 18:38:22 --> Output Class Initialized
INFO - 2017-11-14 18:38:22 --> Security Class Initialized
DEBUG - 2017-11-14 18:38:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 18:38:22 --> Input Class Initialized
INFO - 2017-11-14 18:38:22 --> Language Class Initialized
INFO - 2017-11-14 18:38:22 --> Language Class Initialized
INFO - 2017-11-14 18:38:22 --> Config Class Initialized
INFO - 2017-11-14 18:38:22 --> Loader Class Initialized
DEBUG - 2017-11-14 18:38:22 --> Config file loaded: D:\xampp\htdocs\construction_bay\application\config/construct-data.php
INFO - 2017-11-14 18:38:22 --> Helper loaded: url_helper
INFO - 2017-11-14 18:38:22 --> Helper loaded: form_helper
INFO - 2017-11-14 18:38:22 --> Helper loaded: date_helper
INFO - 2017-11-14 18:38:22 --> Helper loaded: util_helper
INFO - 2017-11-14 18:38:22 --> Helper loaded: text_helper
INFO - 2017-11-14 18:38:22 --> Helper loaded: string_helper
INFO - 2017-11-14 18:38:22 --> Database Driver Class Initialized
DEBUG - 2017-11-14 18:38:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-14 18:38:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-14 18:38:22 --> Email Class Initialized
INFO - 2017-11-14 18:38:22 --> Controller Class Initialized
DEBUG - 2017-11-14 18:38:22 --> Home MX_Controller Initialized
INFO - 2017-11-14 18:38:22 --> Model Class Initialized
DEBUG - 2017-11-14 18:38:22 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_model.php
INFO - 2017-11-14 18:38:22 --> Model Class Initialized
DEBUG - 2017-11-14 18:38:22 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header_menu.php
DEBUG - 2017-11-14 18:38:22 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header.php
DEBUG - 2017-11-14 18:38:22 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\partner-with-us.php
DEBUG - 2017-11-14 18:38:22 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/footer_nav.php
INFO - 2017-11-14 18:38:22 --> Final output sent to browser
DEBUG - 2017-11-14 18:38:22 --> Total execution time: 0.0700
INFO - 2017-11-14 18:38:23 --> Config Class Initialized
INFO - 2017-11-14 18:38:23 --> Hooks Class Initialized
DEBUG - 2017-11-14 18:38:23 --> UTF-8 Support Enabled
INFO - 2017-11-14 18:38:23 --> Utf8 Class Initialized
INFO - 2017-11-14 18:38:23 --> URI Class Initialized
INFO - 2017-11-14 18:38:23 --> Router Class Initialized
INFO - 2017-11-14 18:38:23 --> Output Class Initialized
INFO - 2017-11-14 18:38:23 --> Security Class Initialized
DEBUG - 2017-11-14 18:38:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 18:38:23 --> Input Class Initialized
INFO - 2017-11-14 18:38:23 --> Language Class Initialized
INFO - 2017-11-14 18:38:23 --> Language Class Initialized
INFO - 2017-11-14 18:38:23 --> Config Class Initialized
INFO - 2017-11-14 18:38:23 --> Loader Class Initialized
DEBUG - 2017-11-14 18:38:23 --> Config file loaded: D:\xampp\htdocs\construction_bay\application\config/construct-data.php
INFO - 2017-11-14 18:38:23 --> Helper loaded: url_helper
INFO - 2017-11-14 18:38:23 --> Helper loaded: form_helper
INFO - 2017-11-14 18:38:23 --> Helper loaded: date_helper
INFO - 2017-11-14 18:38:23 --> Helper loaded: util_helper
INFO - 2017-11-14 18:38:23 --> Helper loaded: text_helper
INFO - 2017-11-14 18:38:23 --> Helper loaded: string_helper
INFO - 2017-11-14 18:38:23 --> Database Driver Class Initialized
DEBUG - 2017-11-14 18:38:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-14 18:38:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-14 18:38:23 --> Email Class Initialized
INFO - 2017-11-14 18:38:23 --> Controller Class Initialized
DEBUG - 2017-11-14 18:38:23 --> Home MX_Controller Initialized
INFO - 2017-11-14 18:38:23 --> Model Class Initialized
DEBUG - 2017-11-14 18:38:23 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_model.php
INFO - 2017-11-14 18:38:23 --> Model Class Initialized
DEBUG - 2017-11-14 18:38:23 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header_menu.php
DEBUG - 2017-11-14 18:38:23 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header.php
DEBUG - 2017-11-14 18:38:23 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\partner-with-us.php
DEBUG - 2017-11-14 18:38:23 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/footer_nav.php
INFO - 2017-11-14 18:38:23 --> Final output sent to browser
DEBUG - 2017-11-14 18:38:23 --> Total execution time: 0.0680
INFO - 2017-11-14 18:38:24 --> Config Class Initialized
INFO - 2017-11-14 18:38:24 --> Hooks Class Initialized
DEBUG - 2017-11-14 18:38:24 --> UTF-8 Support Enabled
INFO - 2017-11-14 18:38:24 --> Utf8 Class Initialized
INFO - 2017-11-14 18:38:24 --> URI Class Initialized
INFO - 2017-11-14 18:38:24 --> Router Class Initialized
INFO - 2017-11-14 18:38:24 --> Output Class Initialized
INFO - 2017-11-14 18:38:24 --> Security Class Initialized
DEBUG - 2017-11-14 18:38:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 18:38:24 --> Input Class Initialized
INFO - 2017-11-14 18:38:24 --> Language Class Initialized
INFO - 2017-11-14 18:38:24 --> Language Class Initialized
INFO - 2017-11-14 18:38:24 --> Config Class Initialized
INFO - 2017-11-14 18:38:24 --> Loader Class Initialized
DEBUG - 2017-11-14 18:38:24 --> Config file loaded: D:\xampp\htdocs\construction_bay\application\config/construct-data.php
INFO - 2017-11-14 18:38:24 --> Helper loaded: url_helper
INFO - 2017-11-14 18:38:24 --> Helper loaded: form_helper
INFO - 2017-11-14 18:38:24 --> Helper loaded: date_helper
INFO - 2017-11-14 18:38:24 --> Helper loaded: util_helper
INFO - 2017-11-14 18:38:24 --> Helper loaded: text_helper
INFO - 2017-11-14 18:38:24 --> Helper loaded: string_helper
INFO - 2017-11-14 18:38:24 --> Database Driver Class Initialized
DEBUG - 2017-11-14 18:38:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-14 18:38:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-14 18:38:24 --> Email Class Initialized
INFO - 2017-11-14 18:38:24 --> Controller Class Initialized
DEBUG - 2017-11-14 18:38:24 --> Home MX_Controller Initialized
INFO - 2017-11-14 18:38:24 --> Model Class Initialized
DEBUG - 2017-11-14 18:38:24 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_model.php
INFO - 2017-11-14 18:38:24 --> Model Class Initialized
DEBUG - 2017-11-14 18:38:24 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header_menu.php
DEBUG - 2017-11-14 18:38:24 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header.php
DEBUG - 2017-11-14 18:38:24 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\partner-with-us.php
DEBUG - 2017-11-14 18:38:24 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/footer_nav.php
INFO - 2017-11-14 18:38:24 --> Final output sent to browser
DEBUG - 2017-11-14 18:38:24 --> Total execution time: 0.0560
INFO - 2017-11-14 18:38:24 --> Config Class Initialized
INFO - 2017-11-14 18:38:24 --> Hooks Class Initialized
DEBUG - 2017-11-14 18:38:24 --> UTF-8 Support Enabled
INFO - 2017-11-14 18:38:24 --> Utf8 Class Initialized
INFO - 2017-11-14 18:38:24 --> URI Class Initialized
INFO - 2017-11-14 18:38:24 --> Router Class Initialized
INFO - 2017-11-14 18:38:24 --> Output Class Initialized
INFO - 2017-11-14 18:38:24 --> Security Class Initialized
DEBUG - 2017-11-14 18:38:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 18:38:24 --> Input Class Initialized
INFO - 2017-11-14 18:38:24 --> Language Class Initialized
INFO - 2017-11-14 18:38:24 --> Language Class Initialized
INFO - 2017-11-14 18:38:24 --> Config Class Initialized
INFO - 2017-11-14 18:38:24 --> Loader Class Initialized
DEBUG - 2017-11-14 18:38:24 --> Config file loaded: D:\xampp\htdocs\construction_bay\application\config/construct-data.php
INFO - 2017-11-14 18:38:24 --> Helper loaded: url_helper
INFO - 2017-11-14 18:38:24 --> Helper loaded: form_helper
INFO - 2017-11-14 18:38:24 --> Helper loaded: date_helper
INFO - 2017-11-14 18:38:24 --> Helper loaded: util_helper
INFO - 2017-11-14 18:38:24 --> Helper loaded: text_helper
INFO - 2017-11-14 18:38:24 --> Helper loaded: string_helper
INFO - 2017-11-14 18:38:24 --> Database Driver Class Initialized
DEBUG - 2017-11-14 18:38:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-14 18:38:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-14 18:38:24 --> Email Class Initialized
INFO - 2017-11-14 18:38:24 --> Controller Class Initialized
DEBUG - 2017-11-14 18:38:24 --> Home MX_Controller Initialized
INFO - 2017-11-14 18:38:24 --> Model Class Initialized
DEBUG - 2017-11-14 18:38:24 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_model.php
INFO - 2017-11-14 18:38:24 --> Model Class Initialized
DEBUG - 2017-11-14 18:38:24 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header_menu.php
DEBUG - 2017-11-14 18:38:24 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header.php
DEBUG - 2017-11-14 18:38:24 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\partner-with-us.php
DEBUG - 2017-11-14 18:38:24 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/footer_nav.php
INFO - 2017-11-14 18:38:24 --> Final output sent to browser
DEBUG - 2017-11-14 18:38:24 --> Total execution time: 0.0660
INFO - 2017-11-14 18:38:25 --> Config Class Initialized
INFO - 2017-11-14 18:38:25 --> Hooks Class Initialized
DEBUG - 2017-11-14 18:38:25 --> UTF-8 Support Enabled
INFO - 2017-11-14 18:38:25 --> Utf8 Class Initialized
INFO - 2017-11-14 18:38:25 --> URI Class Initialized
INFO - 2017-11-14 18:38:25 --> Router Class Initialized
INFO - 2017-11-14 18:38:25 --> Output Class Initialized
INFO - 2017-11-14 18:38:25 --> Security Class Initialized
DEBUG - 2017-11-14 18:38:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 18:38:25 --> Input Class Initialized
INFO - 2017-11-14 18:38:25 --> Language Class Initialized
INFO - 2017-11-14 18:38:25 --> Language Class Initialized
INFO - 2017-11-14 18:38:25 --> Config Class Initialized
INFO - 2017-11-14 18:38:25 --> Loader Class Initialized
DEBUG - 2017-11-14 18:38:25 --> Config file loaded: D:\xampp\htdocs\construction_bay\application\config/construct-data.php
INFO - 2017-11-14 18:38:25 --> Helper loaded: url_helper
INFO - 2017-11-14 18:38:25 --> Helper loaded: form_helper
INFO - 2017-11-14 18:38:25 --> Helper loaded: date_helper
INFO - 2017-11-14 18:38:25 --> Helper loaded: util_helper
INFO - 2017-11-14 18:38:25 --> Helper loaded: text_helper
INFO - 2017-11-14 18:38:25 --> Helper loaded: string_helper
INFO - 2017-11-14 18:38:25 --> Database Driver Class Initialized
DEBUG - 2017-11-14 18:38:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-14 18:38:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-14 18:38:25 --> Email Class Initialized
INFO - 2017-11-14 18:38:25 --> Controller Class Initialized
DEBUG - 2017-11-14 18:38:25 --> Home MX_Controller Initialized
INFO - 2017-11-14 18:38:25 --> Model Class Initialized
DEBUG - 2017-11-14 18:38:25 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_model.php
INFO - 2017-11-14 18:38:25 --> Model Class Initialized
DEBUG - 2017-11-14 18:38:25 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header_menu.php
DEBUG - 2017-11-14 18:38:25 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header.php
DEBUG - 2017-11-14 18:38:25 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\partner-with-us.php
DEBUG - 2017-11-14 18:38:25 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/footer_nav.php
INFO - 2017-11-14 18:38:25 --> Final output sent to browser
DEBUG - 2017-11-14 18:38:25 --> Total execution time: 0.0730
INFO - 2017-11-14 18:38:25 --> Config Class Initialized
INFO - 2017-11-14 18:38:25 --> Hooks Class Initialized
DEBUG - 2017-11-14 18:38:25 --> UTF-8 Support Enabled
INFO - 2017-11-14 18:38:25 --> Utf8 Class Initialized
INFO - 2017-11-14 18:38:25 --> URI Class Initialized
INFO - 2017-11-14 18:38:25 --> Router Class Initialized
INFO - 2017-11-14 18:38:25 --> Output Class Initialized
INFO - 2017-11-14 18:38:25 --> Security Class Initialized
DEBUG - 2017-11-14 18:38:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 18:38:25 --> Input Class Initialized
INFO - 2017-11-14 18:38:25 --> Language Class Initialized
INFO - 2017-11-14 18:38:25 --> Language Class Initialized
INFO - 2017-11-14 18:38:25 --> Config Class Initialized
INFO - 2017-11-14 18:38:25 --> Loader Class Initialized
DEBUG - 2017-11-14 18:38:25 --> Config file loaded: D:\xampp\htdocs\construction_bay\application\config/construct-data.php
INFO - 2017-11-14 18:38:25 --> Helper loaded: url_helper
INFO - 2017-11-14 18:38:25 --> Helper loaded: form_helper
INFO - 2017-11-14 18:38:25 --> Helper loaded: date_helper
INFO - 2017-11-14 18:38:25 --> Helper loaded: util_helper
INFO - 2017-11-14 18:38:25 --> Helper loaded: text_helper
INFO - 2017-11-14 18:38:25 --> Helper loaded: string_helper
INFO - 2017-11-14 18:38:25 --> Database Driver Class Initialized
DEBUG - 2017-11-14 18:38:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-14 18:38:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-14 18:38:25 --> Email Class Initialized
INFO - 2017-11-14 18:38:25 --> Controller Class Initialized
DEBUG - 2017-11-14 18:38:25 --> Home MX_Controller Initialized
INFO - 2017-11-14 18:38:25 --> Model Class Initialized
DEBUG - 2017-11-14 18:38:25 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_model.php
INFO - 2017-11-14 18:38:25 --> Model Class Initialized
DEBUG - 2017-11-14 18:38:25 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header_menu.php
DEBUG - 2017-11-14 18:38:25 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header.php
DEBUG - 2017-11-14 18:38:25 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\partner-with-us.php
DEBUG - 2017-11-14 18:38:25 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/footer_nav.php
INFO - 2017-11-14 18:38:25 --> Final output sent to browser
DEBUG - 2017-11-14 18:38:25 --> Total execution time: 0.0840
INFO - 2017-11-14 18:38:27 --> Config Class Initialized
INFO - 2017-11-14 18:38:27 --> Hooks Class Initialized
DEBUG - 2017-11-14 18:38:27 --> UTF-8 Support Enabled
INFO - 2017-11-14 18:38:27 --> Utf8 Class Initialized
INFO - 2017-11-14 18:38:27 --> URI Class Initialized
INFO - 2017-11-14 18:38:27 --> Router Class Initialized
INFO - 2017-11-14 18:38:27 --> Output Class Initialized
INFO - 2017-11-14 18:38:27 --> Security Class Initialized
DEBUG - 2017-11-14 18:38:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 18:38:27 --> Input Class Initialized
INFO - 2017-11-14 18:38:27 --> Language Class Initialized
INFO - 2017-11-14 18:38:27 --> Language Class Initialized
INFO - 2017-11-14 18:38:27 --> Config Class Initialized
INFO - 2017-11-14 18:38:27 --> Loader Class Initialized
DEBUG - 2017-11-14 18:38:27 --> Config file loaded: D:\xampp\htdocs\construction_bay\application\config/construct-data.php
INFO - 2017-11-14 18:38:27 --> Helper loaded: url_helper
INFO - 2017-11-14 18:38:27 --> Helper loaded: form_helper
INFO - 2017-11-14 18:38:27 --> Helper loaded: date_helper
INFO - 2017-11-14 18:38:27 --> Helper loaded: util_helper
INFO - 2017-11-14 18:38:27 --> Helper loaded: text_helper
INFO - 2017-11-14 18:38:27 --> Helper loaded: string_helper
INFO - 2017-11-14 18:38:27 --> Database Driver Class Initialized
DEBUG - 2017-11-14 18:38:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-14 18:38:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-14 18:38:27 --> Email Class Initialized
INFO - 2017-11-14 18:38:27 --> Controller Class Initialized
DEBUG - 2017-11-14 18:38:27 --> Home MX_Controller Initialized
INFO - 2017-11-14 18:38:27 --> Model Class Initialized
DEBUG - 2017-11-14 18:38:27 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_model.php
INFO - 2017-11-14 18:38:27 --> Model Class Initialized
DEBUG - 2017-11-14 18:38:27 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header_menu.php
DEBUG - 2017-11-14 18:38:27 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header.php
DEBUG - 2017-11-14 18:38:27 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\partner-with-us.php
DEBUG - 2017-11-14 18:38:27 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/footer_nav.php
INFO - 2017-11-14 18:38:27 --> Final output sent to browser
DEBUG - 2017-11-14 18:38:27 --> Total execution time: 0.0690
INFO - 2017-11-14 18:38:51 --> Config Class Initialized
INFO - 2017-11-14 18:38:51 --> Hooks Class Initialized
DEBUG - 2017-11-14 18:38:51 --> UTF-8 Support Enabled
INFO - 2017-11-14 18:38:51 --> Utf8 Class Initialized
INFO - 2017-11-14 18:38:51 --> URI Class Initialized
INFO - 2017-11-14 18:38:51 --> Router Class Initialized
INFO - 2017-11-14 18:38:51 --> Output Class Initialized
INFO - 2017-11-14 18:38:51 --> Security Class Initialized
DEBUG - 2017-11-14 18:38:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 18:38:51 --> Input Class Initialized
INFO - 2017-11-14 18:38:51 --> Language Class Initialized
INFO - 2017-11-14 18:38:51 --> Language Class Initialized
INFO - 2017-11-14 18:38:51 --> Config Class Initialized
INFO - 2017-11-14 18:38:51 --> Loader Class Initialized
DEBUG - 2017-11-14 18:38:51 --> Config file loaded: D:\xampp\htdocs\construction_bay\application\config/construct-data.php
INFO - 2017-11-14 18:38:51 --> Helper loaded: url_helper
INFO - 2017-11-14 18:38:51 --> Helper loaded: form_helper
INFO - 2017-11-14 18:38:51 --> Helper loaded: date_helper
INFO - 2017-11-14 18:38:51 --> Helper loaded: util_helper
INFO - 2017-11-14 18:38:51 --> Helper loaded: text_helper
INFO - 2017-11-14 18:38:51 --> Helper loaded: string_helper
INFO - 2017-11-14 18:38:51 --> Database Driver Class Initialized
DEBUG - 2017-11-14 18:38:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-14 18:38:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-14 18:38:51 --> Email Class Initialized
INFO - 2017-11-14 18:38:51 --> Controller Class Initialized
ERROR - 2017-11-14 18:38:51 --> 404 Page Not Found: Home/partner_with_us1
INFO - 2017-11-14 18:38:53 --> Config Class Initialized
INFO - 2017-11-14 18:38:53 --> Hooks Class Initialized
DEBUG - 2017-11-14 18:38:53 --> UTF-8 Support Enabled
INFO - 2017-11-14 18:38:53 --> Utf8 Class Initialized
INFO - 2017-11-14 18:38:53 --> URI Class Initialized
INFO - 2017-11-14 18:38:53 --> Router Class Initialized
INFO - 2017-11-14 18:38:53 --> Output Class Initialized
INFO - 2017-11-14 18:38:53 --> Security Class Initialized
DEBUG - 2017-11-14 18:38:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 18:38:53 --> Input Class Initialized
INFO - 2017-11-14 18:38:53 --> Language Class Initialized
INFO - 2017-11-14 18:38:53 --> Language Class Initialized
INFO - 2017-11-14 18:38:53 --> Config Class Initialized
INFO - 2017-11-14 18:38:53 --> Loader Class Initialized
DEBUG - 2017-11-14 18:38:53 --> Config file loaded: D:\xampp\htdocs\construction_bay\application\config/construct-data.php
INFO - 2017-11-14 18:38:53 --> Helper loaded: url_helper
INFO - 2017-11-14 18:38:53 --> Helper loaded: form_helper
INFO - 2017-11-14 18:38:53 --> Helper loaded: date_helper
INFO - 2017-11-14 18:38:53 --> Helper loaded: util_helper
INFO - 2017-11-14 18:38:53 --> Helper loaded: text_helper
INFO - 2017-11-14 18:38:53 --> Helper loaded: string_helper
INFO - 2017-11-14 18:38:53 --> Database Driver Class Initialized
DEBUG - 2017-11-14 18:38:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-14 18:38:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-14 18:38:53 --> Email Class Initialized
INFO - 2017-11-14 18:38:53 --> Controller Class Initialized
DEBUG - 2017-11-14 18:38:53 --> Home MX_Controller Initialized
INFO - 2017-11-14 18:38:53 --> Model Class Initialized
DEBUG - 2017-11-14 18:38:53 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_model.php
INFO - 2017-11-14 18:38:53 --> Model Class Initialized
DEBUG - 2017-11-14 18:38:53 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header_menu.php
DEBUG - 2017-11-14 18:38:53 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header.php
DEBUG - 2017-11-14 18:38:53 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\partner-with-us.php
DEBUG - 2017-11-14 18:38:53 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/footer_nav.php
INFO - 2017-11-14 18:38:53 --> Final output sent to browser
DEBUG - 2017-11-14 18:38:53 --> Total execution time: 0.0480
INFO - 2017-11-14 18:39:00 --> Config Class Initialized
INFO - 2017-11-14 18:39:00 --> Hooks Class Initialized
DEBUG - 2017-11-14 18:39:00 --> UTF-8 Support Enabled
INFO - 2017-11-14 18:39:00 --> Utf8 Class Initialized
INFO - 2017-11-14 18:39:00 --> URI Class Initialized
INFO - 2017-11-14 18:39:00 --> Router Class Initialized
INFO - 2017-11-14 18:39:00 --> Output Class Initialized
INFO - 2017-11-14 18:39:00 --> Security Class Initialized
DEBUG - 2017-11-14 18:39:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 18:39:00 --> Input Class Initialized
INFO - 2017-11-14 18:39:00 --> Language Class Initialized
INFO - 2017-11-14 18:39:00 --> Language Class Initialized
INFO - 2017-11-14 18:39:00 --> Config Class Initialized
INFO - 2017-11-14 18:39:00 --> Loader Class Initialized
DEBUG - 2017-11-14 18:39:00 --> Config file loaded: D:\xampp\htdocs\construction_bay\application\config/construct-data.php
INFO - 2017-11-14 18:39:00 --> Helper loaded: url_helper
INFO - 2017-11-14 18:39:00 --> Helper loaded: form_helper
INFO - 2017-11-14 18:39:00 --> Helper loaded: date_helper
INFO - 2017-11-14 18:39:00 --> Helper loaded: util_helper
INFO - 2017-11-14 18:39:00 --> Helper loaded: text_helper
INFO - 2017-11-14 18:39:00 --> Helper loaded: string_helper
INFO - 2017-11-14 18:39:00 --> Database Driver Class Initialized
DEBUG - 2017-11-14 18:39:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-14 18:39:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-14 18:39:00 --> Email Class Initialized
INFO - 2017-11-14 18:39:00 --> Controller Class Initialized
DEBUG - 2017-11-14 18:39:00 --> Home MX_Controller Initialized
INFO - 2017-11-14 18:39:00 --> Model Class Initialized
DEBUG - 2017-11-14 18:39:00 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_model.php
INFO - 2017-11-14 18:39:00 --> Model Class Initialized
DEBUG - 2017-11-14 18:39:00 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header_menu.php
DEBUG - 2017-11-14 18:39:00 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header.php
DEBUG - 2017-11-14 18:39:00 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\partner-with-us.php
DEBUG - 2017-11-14 18:39:00 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/footer_nav.php
INFO - 2017-11-14 18:39:00 --> Final output sent to browser
DEBUG - 2017-11-14 18:39:00 --> Total execution time: 0.0640
INFO - 2017-11-14 18:39:43 --> Config Class Initialized
INFO - 2017-11-14 18:39:43 --> Hooks Class Initialized
DEBUG - 2017-11-14 18:39:43 --> UTF-8 Support Enabled
INFO - 2017-11-14 18:39:43 --> Utf8 Class Initialized
INFO - 2017-11-14 18:39:43 --> URI Class Initialized
INFO - 2017-11-14 18:39:43 --> Router Class Initialized
INFO - 2017-11-14 18:39:43 --> Output Class Initialized
INFO - 2017-11-14 18:39:43 --> Security Class Initialized
DEBUG - 2017-11-14 18:39:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 18:39:43 --> Input Class Initialized
INFO - 2017-11-14 18:39:43 --> Language Class Initialized
INFO - 2017-11-14 18:39:43 --> Language Class Initialized
INFO - 2017-11-14 18:39:43 --> Config Class Initialized
INFO - 2017-11-14 18:39:43 --> Loader Class Initialized
DEBUG - 2017-11-14 18:39:43 --> Config file loaded: D:\xampp\htdocs\construction_bay\application\config/construct-data.php
INFO - 2017-11-14 18:39:43 --> Helper loaded: url_helper
INFO - 2017-11-14 18:39:43 --> Helper loaded: form_helper
INFO - 2017-11-14 18:39:43 --> Helper loaded: date_helper
INFO - 2017-11-14 18:39:43 --> Helper loaded: util_helper
INFO - 2017-11-14 18:39:43 --> Helper loaded: text_helper
INFO - 2017-11-14 18:39:43 --> Helper loaded: string_helper
INFO - 2017-11-14 18:39:43 --> Database Driver Class Initialized
DEBUG - 2017-11-14 18:39:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-14 18:39:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-14 18:39:43 --> Email Class Initialized
INFO - 2017-11-14 18:39:43 --> Controller Class Initialized
DEBUG - 2017-11-14 18:39:43 --> Home MX_Controller Initialized
INFO - 2017-11-14 18:39:43 --> Model Class Initialized
DEBUG - 2017-11-14 18:39:43 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_model.php
INFO - 2017-11-14 18:39:43 --> Model Class Initialized
DEBUG - 2017-11-14 18:39:43 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header_menu.php
DEBUG - 2017-11-14 18:39:43 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header.php
DEBUG - 2017-11-14 18:39:43 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\partner-with-us.php
DEBUG - 2017-11-14 18:39:43 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/footer_nav.php
INFO - 2017-11-14 18:39:43 --> Final output sent to browser
DEBUG - 2017-11-14 18:39:43 --> Total execution time: 0.0610
INFO - 2017-11-14 18:40:04 --> Config Class Initialized
INFO - 2017-11-14 18:40:04 --> Hooks Class Initialized
DEBUG - 2017-11-14 18:40:05 --> UTF-8 Support Enabled
INFO - 2017-11-14 18:40:05 --> Utf8 Class Initialized
INFO - 2017-11-14 18:40:05 --> URI Class Initialized
INFO - 2017-11-14 18:40:05 --> Router Class Initialized
INFO - 2017-11-14 18:40:05 --> Output Class Initialized
INFO - 2017-11-14 18:40:05 --> Security Class Initialized
DEBUG - 2017-11-14 18:40:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 18:40:05 --> Input Class Initialized
INFO - 2017-11-14 18:40:05 --> Language Class Initialized
INFO - 2017-11-14 18:40:05 --> Language Class Initialized
INFO - 2017-11-14 18:40:05 --> Config Class Initialized
INFO - 2017-11-14 18:40:05 --> Loader Class Initialized
DEBUG - 2017-11-14 18:40:05 --> Config file loaded: D:\xampp\htdocs\construction_bay\application\config/construct-data.php
INFO - 2017-11-14 18:40:05 --> Helper loaded: url_helper
INFO - 2017-11-14 18:40:05 --> Helper loaded: form_helper
INFO - 2017-11-14 18:40:05 --> Helper loaded: date_helper
INFO - 2017-11-14 18:40:05 --> Helper loaded: util_helper
INFO - 2017-11-14 18:40:05 --> Helper loaded: text_helper
INFO - 2017-11-14 18:40:05 --> Helper loaded: string_helper
INFO - 2017-11-14 18:40:05 --> Database Driver Class Initialized
DEBUG - 2017-11-14 18:40:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-14 18:40:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-14 18:40:05 --> Email Class Initialized
INFO - 2017-11-14 18:40:05 --> Controller Class Initialized
DEBUG - 2017-11-14 18:40:05 --> Home MX_Controller Initialized
INFO - 2017-11-14 18:40:05 --> Model Class Initialized
DEBUG - 2017-11-14 18:40:05 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_model.php
INFO - 2017-11-14 18:40:05 --> Model Class Initialized
DEBUG - 2017-11-14 18:40:05 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header_menu.php
DEBUG - 2017-11-14 18:40:05 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header.php
DEBUG - 2017-11-14 18:40:05 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\partner-with-us.php
DEBUG - 2017-11-14 18:40:05 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/home_footer_nav.php
DEBUG - 2017-11-14 18:40:05 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/index_footer.php
INFO - 2017-11-14 18:40:05 --> Final output sent to browser
DEBUG - 2017-11-14 18:40:05 --> Total execution time: 0.0780
INFO - 2017-11-14 18:40:37 --> Config Class Initialized
INFO - 2017-11-14 18:40:37 --> Hooks Class Initialized
DEBUG - 2017-11-14 18:40:37 --> UTF-8 Support Enabled
INFO - 2017-11-14 18:40:37 --> Utf8 Class Initialized
INFO - 2017-11-14 18:40:37 --> URI Class Initialized
INFO - 2017-11-14 18:40:37 --> Router Class Initialized
INFO - 2017-11-14 18:40:37 --> Output Class Initialized
INFO - 2017-11-14 18:40:37 --> Security Class Initialized
DEBUG - 2017-11-14 18:40:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 18:40:37 --> Input Class Initialized
INFO - 2017-11-14 18:40:37 --> Language Class Initialized
INFO - 2017-11-14 18:40:37 --> Language Class Initialized
INFO - 2017-11-14 18:40:37 --> Config Class Initialized
INFO - 2017-11-14 18:40:37 --> Loader Class Initialized
DEBUG - 2017-11-14 18:40:37 --> Config file loaded: D:\xampp\htdocs\construction_bay\application\config/construct-data.php
INFO - 2017-11-14 18:40:37 --> Helper loaded: url_helper
INFO - 2017-11-14 18:40:37 --> Helper loaded: form_helper
INFO - 2017-11-14 18:40:37 --> Helper loaded: date_helper
INFO - 2017-11-14 18:40:37 --> Helper loaded: util_helper
INFO - 2017-11-14 18:40:37 --> Helper loaded: text_helper
INFO - 2017-11-14 18:40:37 --> Helper loaded: string_helper
INFO - 2017-11-14 18:40:37 --> Database Driver Class Initialized
DEBUG - 2017-11-14 18:40:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-14 18:40:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-14 18:40:37 --> Email Class Initialized
INFO - 2017-11-14 18:40:37 --> Controller Class Initialized
DEBUG - 2017-11-14 18:40:37 --> Home MX_Controller Initialized
INFO - 2017-11-14 18:40:37 --> Model Class Initialized
DEBUG - 2017-11-14 18:40:37 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_model.php
INFO - 2017-11-14 18:40:37 --> Model Class Initialized
DEBUG - 2017-11-14 18:40:37 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header_menu.php
DEBUG - 2017-11-14 18:40:37 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header.php
DEBUG - 2017-11-14 18:40:37 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\partner-with-us.php
DEBUG - 2017-11-14 18:40:37 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/footer_nav.php
INFO - 2017-11-14 18:40:37 --> Final output sent to browser
DEBUG - 2017-11-14 18:40:37 --> Total execution time: 0.0500
INFO - 2017-11-14 18:40:44 --> Config Class Initialized
INFO - 2017-11-14 18:40:44 --> Hooks Class Initialized
DEBUG - 2017-11-14 18:40:45 --> UTF-8 Support Enabled
INFO - 2017-11-14 18:40:45 --> Utf8 Class Initialized
INFO - 2017-11-14 18:40:45 --> URI Class Initialized
INFO - 2017-11-14 18:40:45 --> Router Class Initialized
INFO - 2017-11-14 18:40:45 --> Output Class Initialized
INFO - 2017-11-14 18:40:45 --> Security Class Initialized
DEBUG - 2017-11-14 18:40:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 18:40:45 --> Input Class Initialized
INFO - 2017-11-14 18:40:45 --> Language Class Initialized
INFO - 2017-11-14 18:40:45 --> Language Class Initialized
INFO - 2017-11-14 18:40:45 --> Config Class Initialized
INFO - 2017-11-14 18:40:45 --> Loader Class Initialized
DEBUG - 2017-11-14 18:40:45 --> Config file loaded: D:\xampp\htdocs\construction_bay\application\config/construct-data.php
INFO - 2017-11-14 18:40:45 --> Helper loaded: url_helper
INFO - 2017-11-14 18:40:45 --> Helper loaded: form_helper
INFO - 2017-11-14 18:40:45 --> Helper loaded: date_helper
INFO - 2017-11-14 18:40:45 --> Helper loaded: util_helper
INFO - 2017-11-14 18:40:45 --> Helper loaded: text_helper
INFO - 2017-11-14 18:40:45 --> Helper loaded: string_helper
INFO - 2017-11-14 18:40:45 --> Database Driver Class Initialized
DEBUG - 2017-11-14 18:40:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-14 18:40:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-14 18:40:45 --> Email Class Initialized
INFO - 2017-11-14 18:40:45 --> Controller Class Initialized
DEBUG - 2017-11-14 18:40:45 --> Home MX_Controller Initialized
INFO - 2017-11-14 18:40:45 --> Model Class Initialized
DEBUG - 2017-11-14 18:40:45 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_model.php
INFO - 2017-11-14 18:40:45 --> Model Class Initialized
DEBUG - 2017-11-14 18:40:45 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header_menu.php
DEBUG - 2017-11-14 18:40:45 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header.php
DEBUG - 2017-11-14 18:40:45 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\partner-with-us.php
DEBUG - 2017-11-14 18:40:45 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/footer_nav.php
INFO - 2017-11-14 18:40:45 --> Final output sent to browser
DEBUG - 2017-11-14 18:40:45 --> Total execution time: 0.0580
INFO - 2017-11-14 18:42:16 --> Config Class Initialized
INFO - 2017-11-14 18:42:16 --> Hooks Class Initialized
DEBUG - 2017-11-14 18:42:16 --> UTF-8 Support Enabled
INFO - 2017-11-14 18:42:16 --> Utf8 Class Initialized
INFO - 2017-11-14 18:42:16 --> URI Class Initialized
INFO - 2017-11-14 18:42:16 --> Router Class Initialized
INFO - 2017-11-14 18:42:16 --> Output Class Initialized
INFO - 2017-11-14 18:42:16 --> Security Class Initialized
DEBUG - 2017-11-14 18:42:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 18:42:16 --> Input Class Initialized
INFO - 2017-11-14 18:42:16 --> Language Class Initialized
INFO - 2017-11-14 18:42:16 --> Language Class Initialized
INFO - 2017-11-14 18:42:16 --> Config Class Initialized
INFO - 2017-11-14 18:42:16 --> Loader Class Initialized
DEBUG - 2017-11-14 18:42:16 --> Config file loaded: D:\xampp\htdocs\construction_bay\application\config/construct-data.php
INFO - 2017-11-14 18:42:16 --> Helper loaded: url_helper
INFO - 2017-11-14 18:42:16 --> Helper loaded: form_helper
INFO - 2017-11-14 18:42:16 --> Helper loaded: date_helper
INFO - 2017-11-14 18:42:16 --> Helper loaded: util_helper
INFO - 2017-11-14 18:42:16 --> Helper loaded: text_helper
INFO - 2017-11-14 18:42:16 --> Helper loaded: string_helper
INFO - 2017-11-14 18:42:16 --> Database Driver Class Initialized
DEBUG - 2017-11-14 18:42:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-14 18:42:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-14 18:42:16 --> Email Class Initialized
INFO - 2017-11-14 18:42:16 --> Controller Class Initialized
DEBUG - 2017-11-14 18:42:16 --> Home MX_Controller Initialized
INFO - 2017-11-14 18:42:16 --> Model Class Initialized
DEBUG - 2017-11-14 18:42:16 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_model.php
INFO - 2017-11-14 18:42:16 --> Model Class Initialized
DEBUG - 2017-11-14 18:42:16 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header_menu.php
DEBUG - 2017-11-14 18:42:16 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header.php
DEBUG - 2017-11-14 18:42:16 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\partner-with-us.php
DEBUG - 2017-11-14 18:42:16 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/footer_nav.php
INFO - 2017-11-14 18:42:16 --> Final output sent to browser
DEBUG - 2017-11-14 18:42:16 --> Total execution time: 0.0890
INFO - 2017-11-14 18:42:26 --> Config Class Initialized
INFO - 2017-11-14 18:42:26 --> Hooks Class Initialized
DEBUG - 2017-11-14 18:42:26 --> UTF-8 Support Enabled
INFO - 2017-11-14 18:42:26 --> Utf8 Class Initialized
INFO - 2017-11-14 18:42:26 --> URI Class Initialized
INFO - 2017-11-14 18:42:26 --> Router Class Initialized
INFO - 2017-11-14 18:42:26 --> Output Class Initialized
INFO - 2017-11-14 18:42:26 --> Security Class Initialized
DEBUG - 2017-11-14 18:42:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 18:42:26 --> Input Class Initialized
INFO - 2017-11-14 18:42:26 --> Language Class Initialized
INFO - 2017-11-14 18:42:26 --> Language Class Initialized
INFO - 2017-11-14 18:42:26 --> Config Class Initialized
INFO - 2017-11-14 18:42:26 --> Loader Class Initialized
DEBUG - 2017-11-14 18:42:26 --> Config file loaded: D:\xampp\htdocs\construction_bay\application\config/construct-data.php
INFO - 2017-11-14 18:42:26 --> Helper loaded: url_helper
INFO - 2017-11-14 18:42:26 --> Helper loaded: form_helper
INFO - 2017-11-14 18:42:26 --> Helper loaded: date_helper
INFO - 2017-11-14 18:42:26 --> Helper loaded: util_helper
INFO - 2017-11-14 18:42:26 --> Helper loaded: text_helper
INFO - 2017-11-14 18:42:26 --> Helper loaded: string_helper
INFO - 2017-11-14 18:42:26 --> Database Driver Class Initialized
DEBUG - 2017-11-14 18:42:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-14 18:42:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-14 18:42:26 --> Email Class Initialized
INFO - 2017-11-14 18:42:26 --> Controller Class Initialized
DEBUG - 2017-11-14 18:42:26 --> Home MX_Controller Initialized
INFO - 2017-11-14 18:42:26 --> Model Class Initialized
DEBUG - 2017-11-14 18:42:26 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_model.php
INFO - 2017-11-14 18:42:26 --> Model Class Initialized
DEBUG - 2017-11-14 18:42:26 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header_menu.php
DEBUG - 2017-11-14 18:42:26 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header.php
DEBUG - 2017-11-14 18:42:26 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\partner-with-us.php
DEBUG - 2017-11-14 18:42:26 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/home_footer_nav.php
DEBUG - 2017-11-14 18:42:26 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/index_footer.php
INFO - 2017-11-14 18:42:26 --> Final output sent to browser
DEBUG - 2017-11-14 18:42:26 --> Total execution time: 0.0610
INFO - 2017-11-14 18:42:49 --> Config Class Initialized
INFO - 2017-11-14 18:42:49 --> Hooks Class Initialized
DEBUG - 2017-11-14 18:42:49 --> UTF-8 Support Enabled
INFO - 2017-11-14 18:42:49 --> Utf8 Class Initialized
INFO - 2017-11-14 18:42:49 --> URI Class Initialized
INFO - 2017-11-14 18:42:49 --> Router Class Initialized
INFO - 2017-11-14 18:42:49 --> Output Class Initialized
INFO - 2017-11-14 18:42:49 --> Security Class Initialized
DEBUG - 2017-11-14 18:42:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 18:42:49 --> Input Class Initialized
INFO - 2017-11-14 18:42:49 --> Language Class Initialized
INFO - 2017-11-14 18:42:49 --> Language Class Initialized
INFO - 2017-11-14 18:42:49 --> Config Class Initialized
INFO - 2017-11-14 18:42:49 --> Loader Class Initialized
DEBUG - 2017-11-14 18:42:49 --> Config file loaded: D:\xampp\htdocs\construction_bay\application\config/construct-data.php
INFO - 2017-11-14 18:42:49 --> Helper loaded: url_helper
INFO - 2017-11-14 18:42:49 --> Helper loaded: form_helper
INFO - 2017-11-14 18:42:49 --> Helper loaded: date_helper
INFO - 2017-11-14 18:42:49 --> Helper loaded: util_helper
INFO - 2017-11-14 18:42:49 --> Helper loaded: text_helper
INFO - 2017-11-14 18:42:49 --> Helper loaded: string_helper
INFO - 2017-11-14 18:42:49 --> Database Driver Class Initialized
DEBUG - 2017-11-14 18:42:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-14 18:42:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-14 18:42:49 --> Email Class Initialized
INFO - 2017-11-14 18:42:49 --> Controller Class Initialized
DEBUG - 2017-11-14 18:42:49 --> Home MX_Controller Initialized
INFO - 2017-11-14 18:42:49 --> Model Class Initialized
DEBUG - 2017-11-14 18:42:49 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_model.php
INFO - 2017-11-14 18:42:49 --> Model Class Initialized
DEBUG - 2017-11-14 18:42:49 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header_menu.php
DEBUG - 2017-11-14 18:42:49 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header.php
DEBUG - 2017-11-14 18:42:49 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\partner-with-us.php
DEBUG - 2017-11-14 18:42:49 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/footer_nav.php
INFO - 2017-11-14 18:42:49 --> Final output sent to browser
DEBUG - 2017-11-14 18:42:49 --> Total execution time: 0.0590
INFO - 2017-11-14 18:43:47 --> Config Class Initialized
INFO - 2017-11-14 18:43:47 --> Hooks Class Initialized
DEBUG - 2017-11-14 18:43:47 --> UTF-8 Support Enabled
INFO - 2017-11-14 18:43:47 --> Utf8 Class Initialized
INFO - 2017-11-14 18:43:47 --> URI Class Initialized
INFO - 2017-11-14 18:43:47 --> Router Class Initialized
INFO - 2017-11-14 18:43:47 --> Output Class Initialized
INFO - 2017-11-14 18:43:47 --> Security Class Initialized
DEBUG - 2017-11-14 18:43:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 18:43:47 --> Input Class Initialized
INFO - 2017-11-14 18:43:47 --> Language Class Initialized
INFO - 2017-11-14 18:43:47 --> Language Class Initialized
INFO - 2017-11-14 18:43:47 --> Config Class Initialized
INFO - 2017-11-14 18:43:47 --> Loader Class Initialized
DEBUG - 2017-11-14 18:43:47 --> Config file loaded: D:\xampp\htdocs\construction_bay\application\config/construct-data.php
INFO - 2017-11-14 18:43:47 --> Helper loaded: url_helper
INFO - 2017-11-14 18:43:47 --> Helper loaded: form_helper
INFO - 2017-11-14 18:43:47 --> Helper loaded: date_helper
INFO - 2017-11-14 18:43:47 --> Helper loaded: util_helper
INFO - 2017-11-14 18:43:47 --> Helper loaded: text_helper
INFO - 2017-11-14 18:43:47 --> Helper loaded: string_helper
INFO - 2017-11-14 18:43:47 --> Database Driver Class Initialized
DEBUG - 2017-11-14 18:43:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-14 18:43:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-14 18:43:47 --> Email Class Initialized
INFO - 2017-11-14 18:43:47 --> Controller Class Initialized
DEBUG - 2017-11-14 18:43:47 --> Home MX_Controller Initialized
INFO - 2017-11-14 18:43:47 --> Model Class Initialized
DEBUG - 2017-11-14 18:43:47 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_model.php
INFO - 2017-11-14 18:43:47 --> Model Class Initialized
DEBUG - 2017-11-14 18:43:47 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header_menu.php
DEBUG - 2017-11-14 18:43:47 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header.php
DEBUG - 2017-11-14 18:43:47 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\partner-with-us.php
DEBUG - 2017-11-14 18:43:47 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/home_footer_nav.php
DEBUG - 2017-11-14 18:43:47 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/index_footer.php
INFO - 2017-11-14 18:43:47 --> Final output sent to browser
DEBUG - 2017-11-14 18:43:47 --> Total execution time: 0.0670
INFO - 2017-11-14 18:44:07 --> Config Class Initialized
INFO - 2017-11-14 18:44:07 --> Hooks Class Initialized
DEBUG - 2017-11-14 18:44:07 --> UTF-8 Support Enabled
INFO - 2017-11-14 18:44:07 --> Utf8 Class Initialized
INFO - 2017-11-14 18:44:07 --> URI Class Initialized
INFO - 2017-11-14 18:44:07 --> Router Class Initialized
INFO - 2017-11-14 18:44:07 --> Output Class Initialized
INFO - 2017-11-14 18:44:07 --> Security Class Initialized
DEBUG - 2017-11-14 18:44:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 18:44:07 --> Input Class Initialized
INFO - 2017-11-14 18:44:07 --> Language Class Initialized
INFO - 2017-11-14 18:44:07 --> Language Class Initialized
INFO - 2017-11-14 18:44:07 --> Config Class Initialized
INFO - 2017-11-14 18:44:07 --> Loader Class Initialized
DEBUG - 2017-11-14 18:44:07 --> Config file loaded: D:\xampp\htdocs\construction_bay\application\config/construct-data.php
INFO - 2017-11-14 18:44:07 --> Helper loaded: url_helper
INFO - 2017-11-14 18:44:07 --> Helper loaded: form_helper
INFO - 2017-11-14 18:44:07 --> Helper loaded: date_helper
INFO - 2017-11-14 18:44:07 --> Helper loaded: util_helper
INFO - 2017-11-14 18:44:07 --> Helper loaded: text_helper
INFO - 2017-11-14 18:44:07 --> Helper loaded: string_helper
INFO - 2017-11-14 18:44:07 --> Database Driver Class Initialized
DEBUG - 2017-11-14 18:44:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-14 18:44:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-14 18:44:07 --> Email Class Initialized
INFO - 2017-11-14 18:44:07 --> Controller Class Initialized
DEBUG - 2017-11-14 18:44:07 --> Home MX_Controller Initialized
INFO - 2017-11-14 18:44:07 --> Model Class Initialized
DEBUG - 2017-11-14 18:44:07 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_model.php
INFO - 2017-11-14 18:44:07 --> Model Class Initialized
DEBUG - 2017-11-14 18:44:07 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header_menu.php
DEBUG - 2017-11-14 18:44:07 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header.php
DEBUG - 2017-11-14 18:44:07 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\partner-with-us.php
DEBUG - 2017-11-14 18:44:07 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/footer_nav.php
DEBUG - 2017-11-14 18:44:07 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/footer.php
INFO - 2017-11-14 18:44:07 --> Final output sent to browser
DEBUG - 2017-11-14 18:44:07 --> Total execution time: 0.0540
INFO - 2017-11-14 18:44:24 --> Config Class Initialized
INFO - 2017-11-14 18:44:24 --> Hooks Class Initialized
DEBUG - 2017-11-14 18:44:24 --> UTF-8 Support Enabled
INFO - 2017-11-14 18:44:24 --> Utf8 Class Initialized
INFO - 2017-11-14 18:44:24 --> URI Class Initialized
INFO - 2017-11-14 18:44:24 --> Router Class Initialized
INFO - 2017-11-14 18:44:24 --> Output Class Initialized
INFO - 2017-11-14 18:44:24 --> Security Class Initialized
DEBUG - 2017-11-14 18:44:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 18:44:24 --> Input Class Initialized
INFO - 2017-11-14 18:44:24 --> Language Class Initialized
INFO - 2017-11-14 18:44:24 --> Language Class Initialized
INFO - 2017-11-14 18:44:24 --> Config Class Initialized
INFO - 2017-11-14 18:44:24 --> Loader Class Initialized
DEBUG - 2017-11-14 18:44:24 --> Config file loaded: D:\xampp\htdocs\construction_bay\application\config/construct-data.php
INFO - 2017-11-14 18:44:24 --> Helper loaded: url_helper
INFO - 2017-11-14 18:44:24 --> Helper loaded: form_helper
INFO - 2017-11-14 18:44:24 --> Helper loaded: date_helper
INFO - 2017-11-14 18:44:24 --> Helper loaded: util_helper
INFO - 2017-11-14 18:44:24 --> Helper loaded: text_helper
INFO - 2017-11-14 18:44:24 --> Helper loaded: string_helper
INFO - 2017-11-14 18:44:24 --> Config Class Initialized
INFO - 2017-11-14 18:44:24 --> Hooks Class Initialized
DEBUG - 2017-11-14 18:44:24 --> UTF-8 Support Enabled
INFO - 2017-11-14 18:44:24 --> Utf8 Class Initialized
INFO - 2017-11-14 18:44:24 --> URI Class Initialized
INFO - 2017-11-14 18:44:24 --> Database Driver Class Initialized
INFO - 2017-11-14 18:44:24 --> Router Class Initialized
INFO - 2017-11-14 18:44:24 --> Output Class Initialized
INFO - 2017-11-14 18:44:24 --> Security Class Initialized
DEBUG - 2017-11-14 18:44:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 18:44:24 --> Input Class Initialized
INFO - 2017-11-14 18:44:24 --> Language Class Initialized
INFO - 2017-11-14 18:44:24 --> Language Class Initialized
INFO - 2017-11-14 18:44:24 --> Config Class Initialized
DEBUG - 2017-11-14 18:44:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-14 18:44:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-14 18:44:24 --> Loader Class Initialized
DEBUG - 2017-11-14 18:44:24 --> Config file loaded: D:\xampp\htdocs\construction_bay\application\config/construct-data.php
INFO - 2017-11-14 18:44:24 --> Email Class Initialized
INFO - 2017-11-14 18:44:24 --> Controller Class Initialized
DEBUG - 2017-11-14 18:44:24 --> Home MX_Controller Initialized
INFO - 2017-11-14 18:44:24 --> Helper loaded: url_helper
INFO - 2017-11-14 18:44:24 --> Model Class Initialized
DEBUG - 2017-11-14 18:44:24 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_model.php
INFO - 2017-11-14 18:44:24 --> Model Class Initialized
INFO - 2017-11-14 18:44:24 --> Helper loaded: form_helper
INFO - 2017-11-14 18:44:24 --> Helper loaded: date_helper
INFO - 2017-11-14 18:44:24 --> Helper loaded: util_helper
DEBUG - 2017-11-14 18:44:24 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header_menu.php
DEBUG - 2017-11-14 18:44:24 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header.php
DEBUG - 2017-11-14 18:44:24 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\partner-with-us.php
DEBUG - 2017-11-14 18:44:24 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/footer_nav.php
DEBUG - 2017-11-14 18:44:24 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/footer.php
INFO - 2017-11-14 18:44:24 --> Final output sent to browser
DEBUG - 2017-11-14 18:44:24 --> Total execution time: 0.1130
INFO - 2017-11-14 18:44:24 --> Helper loaded: text_helper
INFO - 2017-11-14 18:44:24 --> Helper loaded: string_helper
INFO - 2017-11-14 18:44:24 --> Database Driver Class Initialized
DEBUG - 2017-11-14 18:44:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-14 18:44:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-14 18:44:24 --> Email Class Initialized
INFO - 2017-11-14 18:44:24 --> Controller Class Initialized
DEBUG - 2017-11-14 18:44:24 --> Home MX_Controller Initialized
INFO - 2017-11-14 18:44:24 --> Model Class Initialized
DEBUG - 2017-11-14 18:44:24 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_model.php
INFO - 2017-11-14 18:44:24 --> Model Class Initialized
DEBUG - 2017-11-14 18:44:24 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header_menu.php
DEBUG - 2017-11-14 18:44:24 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header.php
DEBUG - 2017-11-14 18:44:24 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\partner-with-us.php
DEBUG - 2017-11-14 18:44:24 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/footer_nav.php
DEBUG - 2017-11-14 18:44:24 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/footer.php
INFO - 2017-11-14 18:44:24 --> Final output sent to browser
DEBUG - 2017-11-14 18:44:24 --> Total execution time: 0.1010
INFO - 2017-11-14 18:47:48 --> Config Class Initialized
INFO - 2017-11-14 18:47:48 --> Hooks Class Initialized
DEBUG - 2017-11-14 18:47:48 --> UTF-8 Support Enabled
INFO - 2017-11-14 18:47:48 --> Utf8 Class Initialized
INFO - 2017-11-14 18:47:48 --> URI Class Initialized
DEBUG - 2017-11-14 18:47:48 --> No URI present. Default controller set.
INFO - 2017-11-14 18:47:48 --> Router Class Initialized
INFO - 2017-11-14 18:47:48 --> Output Class Initialized
INFO - 2017-11-14 18:47:48 --> Security Class Initialized
DEBUG - 2017-11-14 18:47:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 18:47:48 --> Input Class Initialized
INFO - 2017-11-14 18:47:48 --> Language Class Initialized
INFO - 2017-11-14 18:47:48 --> Language Class Initialized
INFO - 2017-11-14 18:47:48 --> Config Class Initialized
INFO - 2017-11-14 18:47:48 --> Loader Class Initialized
DEBUG - 2017-11-14 18:47:48 --> Config file loaded: D:\xampp\htdocs\construction_bay\application\config/construct-data.php
INFO - 2017-11-14 18:47:48 --> Helper loaded: url_helper
INFO - 2017-11-14 18:47:48 --> Helper loaded: form_helper
INFO - 2017-11-14 18:47:48 --> Helper loaded: date_helper
INFO - 2017-11-14 18:47:48 --> Helper loaded: util_helper
INFO - 2017-11-14 18:47:48 --> Helper loaded: text_helper
INFO - 2017-11-14 18:47:48 --> Helper loaded: string_helper
INFO - 2017-11-14 18:47:48 --> Database Driver Class Initialized
DEBUG - 2017-11-14 18:47:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-14 18:47:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-14 18:47:48 --> Email Class Initialized
INFO - 2017-11-14 18:47:48 --> Controller Class Initialized
DEBUG - 2017-11-14 18:47:48 --> Home MX_Controller Initialized
INFO - 2017-11-14 18:47:48 --> Model Class Initialized
DEBUG - 2017-11-14 18:47:48 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_model.php
INFO - 2017-11-14 18:47:48 --> Model Class Initialized
DEBUG - 2017-11-14 18:47:48 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header_menu.php
DEBUG - 2017-11-14 18:47:48 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header.php
INFO - 2017-11-14 18:47:48 --> Config Class Initialized
INFO - 2017-11-14 18:47:48 --> Hooks Class Initialized
DEBUG - 2017-11-14 18:47:48 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/slider.php
DEBUG - 2017-11-14 18:47:48 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/index_body.php
DEBUG - 2017-11-14 18:47:48 --> UTF-8 Support Enabled
INFO - 2017-11-14 18:47:48 --> Utf8 Class Initialized
DEBUG - 2017-11-14 18:47:48 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/home_footer_nav.php
DEBUG - 2017-11-14 18:47:48 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/index_footer.php
INFO - 2017-11-14 18:47:48 --> Final output sent to browser
DEBUG - 2017-11-14 18:47:48 --> Total execution time: 0.0520
INFO - 2017-11-14 18:47:48 --> URI Class Initialized
DEBUG - 2017-11-14 18:47:48 --> No URI present. Default controller set.
INFO - 2017-11-14 18:47:48 --> Router Class Initialized
INFO - 2017-11-14 18:47:48 --> Output Class Initialized
INFO - 2017-11-14 18:47:48 --> Security Class Initialized
DEBUG - 2017-11-14 18:47:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 18:47:48 --> Input Class Initialized
INFO - 2017-11-14 18:47:48 --> Language Class Initialized
INFO - 2017-11-14 18:47:48 --> Language Class Initialized
INFO - 2017-11-14 18:47:48 --> Config Class Initialized
INFO - 2017-11-14 18:47:48 --> Loader Class Initialized
DEBUG - 2017-11-14 18:47:48 --> Config file loaded: D:\xampp\htdocs\construction_bay\application\config/construct-data.php
INFO - 2017-11-14 18:47:48 --> Helper loaded: url_helper
INFO - 2017-11-14 18:47:48 --> Helper loaded: form_helper
INFO - 2017-11-14 18:47:48 --> Helper loaded: date_helper
INFO - 2017-11-14 18:47:48 --> Helper loaded: util_helper
INFO - 2017-11-14 18:47:48 --> Helper loaded: text_helper
INFO - 2017-11-14 18:47:48 --> Helper loaded: string_helper
INFO - 2017-11-14 18:47:48 --> Database Driver Class Initialized
DEBUG - 2017-11-14 18:47:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-14 18:47:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-14 18:47:49 --> Email Class Initialized
INFO - 2017-11-14 18:47:49 --> Controller Class Initialized
DEBUG - 2017-11-14 18:47:49 --> Home MX_Controller Initialized
INFO - 2017-11-14 18:47:49 --> Model Class Initialized
DEBUG - 2017-11-14 18:47:49 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_model.php
INFO - 2017-11-14 18:47:49 --> Model Class Initialized
DEBUG - 2017-11-14 18:47:49 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header_menu.php
DEBUG - 2017-11-14 18:47:49 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header.php
DEBUG - 2017-11-14 18:47:49 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/slider.php
DEBUG - 2017-11-14 18:47:49 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/index_body.php
DEBUG - 2017-11-14 18:47:49 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/home_footer_nav.php
DEBUG - 2017-11-14 18:47:49 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/index_footer.php
INFO - 2017-11-14 18:47:49 --> Final output sent to browser
DEBUG - 2017-11-14 18:47:49 --> Total execution time: 0.1880
INFO - 2017-11-14 18:47:50 --> Config Class Initialized
INFO - 2017-11-14 18:47:50 --> Hooks Class Initialized
DEBUG - 2017-11-14 18:47:50 --> UTF-8 Support Enabled
INFO - 2017-11-14 18:47:50 --> Utf8 Class Initialized
INFO - 2017-11-14 18:47:50 --> URI Class Initialized
INFO - 2017-11-14 18:47:50 --> Router Class Initialized
INFO - 2017-11-14 18:47:50 --> Output Class Initialized
INFO - 2017-11-14 18:47:50 --> Security Class Initialized
DEBUG - 2017-11-14 18:47:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 18:47:50 --> Input Class Initialized
INFO - 2017-11-14 18:47:50 --> Language Class Initialized
ERROR - 2017-11-14 18:47:50 --> 404 Page Not Found: /index
INFO - 2017-11-14 19:09:00 --> Config Class Initialized
INFO - 2017-11-14 19:09:00 --> Hooks Class Initialized
DEBUG - 2017-11-14 19:09:01 --> UTF-8 Support Enabled
INFO - 2017-11-14 19:09:01 --> Utf8 Class Initialized
INFO - 2017-11-14 19:09:01 --> URI Class Initialized
INFO - 2017-11-14 19:09:01 --> Router Class Initialized
INFO - 2017-11-14 19:09:01 --> Output Class Initialized
INFO - 2017-11-14 19:09:01 --> Security Class Initialized
DEBUG - 2017-11-14 19:09:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 19:09:01 --> Input Class Initialized
INFO - 2017-11-14 19:09:01 --> Language Class Initialized
INFO - 2017-11-14 19:09:01 --> Language Class Initialized
INFO - 2017-11-14 19:09:01 --> Config Class Initialized
INFO - 2017-11-14 19:09:01 --> Loader Class Initialized
DEBUG - 2017-11-14 19:09:01 --> Config file loaded: D:\xampp\htdocs\construction_bay\application\config/construct-data.php
INFO - 2017-11-14 19:09:01 --> Helper loaded: url_helper
INFO - 2017-11-14 19:09:01 --> Helper loaded: form_helper
INFO - 2017-11-14 19:09:01 --> Helper loaded: date_helper
INFO - 2017-11-14 19:09:01 --> Helper loaded: util_helper
INFO - 2017-11-14 19:09:01 --> Helper loaded: text_helper
INFO - 2017-11-14 19:09:01 --> Helper loaded: string_helper
INFO - 2017-11-14 19:09:01 --> Database Driver Class Initialized
DEBUG - 2017-11-14 19:09:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-14 19:09:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-14 19:09:01 --> Email Class Initialized
INFO - 2017-11-14 19:09:01 --> Controller Class Initialized
DEBUG - 2017-11-14 19:09:01 --> Home MX_Controller Initialized
INFO - 2017-11-14 19:09:01 --> Model Class Initialized
DEBUG - 2017-11-14 19:09:01 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_model.php
INFO - 2017-11-14 19:09:01 --> Model Class Initialized
DEBUG - 2017-11-14 19:09:01 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header_menu.php
DEBUG - 2017-11-14 19:09:01 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header.php
DEBUG - 2017-11-14 19:09:01 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\partner-with-us.php
DEBUG - 2017-11-14 19:09:01 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/footer_nav.php
DEBUG - 2017-11-14 19:09:01 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/footer.php
INFO - 2017-11-14 19:09:01 --> Final output sent to browser
DEBUG - 2017-11-14 19:09:01 --> Total execution time: 0.8550
INFO - 2017-11-14 19:31:39 --> Config Class Initialized
INFO - 2017-11-14 19:31:39 --> Hooks Class Initialized
DEBUG - 2017-11-14 19:31:39 --> UTF-8 Support Enabled
INFO - 2017-11-14 19:31:39 --> Utf8 Class Initialized
INFO - 2017-11-14 19:31:39 --> URI Class Initialized
INFO - 2017-11-14 19:31:39 --> Router Class Initialized
INFO - 2017-11-14 19:31:39 --> Output Class Initialized
INFO - 2017-11-14 19:31:39 --> Security Class Initialized
DEBUG - 2017-11-14 19:31:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 19:31:39 --> Input Class Initialized
INFO - 2017-11-14 19:31:39 --> Language Class Initialized
INFO - 2017-11-14 19:31:39 --> Language Class Initialized
INFO - 2017-11-14 19:31:39 --> Config Class Initialized
INFO - 2017-11-14 19:31:39 --> Loader Class Initialized
DEBUG - 2017-11-14 19:31:39 --> Config file loaded: D:\xampp\htdocs\construction_bay\application\config/construct-data.php
INFO - 2017-11-14 19:31:39 --> Helper loaded: url_helper
INFO - 2017-11-14 19:31:39 --> Helper loaded: form_helper
INFO - 2017-11-14 19:31:39 --> Helper loaded: date_helper
INFO - 2017-11-14 19:31:39 --> Helper loaded: util_helper
INFO - 2017-11-14 19:31:39 --> Helper loaded: text_helper
INFO - 2017-11-14 19:31:39 --> Helper loaded: string_helper
INFO - 2017-11-14 19:31:39 --> Database Driver Class Initialized
DEBUG - 2017-11-14 19:31:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-14 19:31:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-14 19:31:39 --> Email Class Initialized
INFO - 2017-11-14 19:31:39 --> Controller Class Initialized
DEBUG - 2017-11-14 19:31:39 --> Home MX_Controller Initialized
INFO - 2017-11-14 19:31:39 --> Model Class Initialized
DEBUG - 2017-11-14 19:31:39 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_model.php
INFO - 2017-11-14 19:31:39 --> Model Class Initialized
DEBUG - 2017-11-14 19:31:39 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header_menu.php
DEBUG - 2017-11-14 19:31:39 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header.php
DEBUG - 2017-11-14 19:31:39 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\partner-with-us.php
DEBUG - 2017-11-14 19:31:39 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/footer_nav.php
DEBUG - 2017-11-14 19:31:39 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/footer.php
INFO - 2017-11-14 19:31:39 --> Final output sent to browser
DEBUG - 2017-11-14 19:31:39 --> Total execution time: 0.0640
INFO - 2017-11-14 20:01:32 --> Config Class Initialized
INFO - 2017-11-14 20:01:32 --> Hooks Class Initialized
DEBUG - 2017-11-14 20:01:32 --> UTF-8 Support Enabled
INFO - 2017-11-14 20:01:32 --> Utf8 Class Initialized
INFO - 2017-11-14 20:01:32 --> URI Class Initialized
INFO - 2017-11-14 20:01:32 --> Router Class Initialized
INFO - 2017-11-14 20:01:32 --> Output Class Initialized
INFO - 2017-11-14 20:01:32 --> Security Class Initialized
DEBUG - 2017-11-14 20:01:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 20:01:32 --> Input Class Initialized
INFO - 2017-11-14 20:01:32 --> Language Class Initialized
INFO - 2017-11-14 20:01:32 --> Language Class Initialized
INFO - 2017-11-14 20:01:32 --> Config Class Initialized
INFO - 2017-11-14 20:01:32 --> Loader Class Initialized
DEBUG - 2017-11-14 20:01:32 --> Config file loaded: D:\xampp\htdocs\construction_bay\application\config/construct-data.php
INFO - 2017-11-14 20:01:32 --> Helper loaded: url_helper
INFO - 2017-11-14 20:01:32 --> Helper loaded: form_helper
INFO - 2017-11-14 20:01:32 --> Helper loaded: date_helper
INFO - 2017-11-14 20:01:32 --> Helper loaded: util_helper
INFO - 2017-11-14 20:01:32 --> Helper loaded: text_helper
INFO - 2017-11-14 20:01:32 --> Helper loaded: string_helper
INFO - 2017-11-14 20:01:32 --> Database Driver Class Initialized
DEBUG - 2017-11-14 20:01:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-14 20:01:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-14 20:01:32 --> Email Class Initialized
INFO - 2017-11-14 20:01:32 --> Controller Class Initialized
DEBUG - 2017-11-14 20:01:32 --> Home MX_Controller Initialized
INFO - 2017-11-14 20:01:32 --> Model Class Initialized
DEBUG - 2017-11-14 20:01:32 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_model.php
INFO - 2017-11-14 20:01:32 --> Model Class Initialized
DEBUG - 2017-11-14 20:01:32 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header_menu.php
DEBUG - 2017-11-14 20:01:32 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header.php
DEBUG - 2017-11-14 20:01:32 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\partner-with-us.php
DEBUG - 2017-11-14 20:01:32 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/footer_nav.php
DEBUG - 2017-11-14 20:01:32 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/footer.php
INFO - 2017-11-14 20:01:32 --> Final output sent to browser
DEBUG - 2017-11-14 20:01:32 --> Total execution time: 0.1290
INFO - 2017-11-14 20:01:32 --> Config Class Initialized
INFO - 2017-11-14 20:01:32 --> Hooks Class Initialized
DEBUG - 2017-11-14 20:01:32 --> UTF-8 Support Enabled
INFO - 2017-11-14 20:01:32 --> Utf8 Class Initialized
INFO - 2017-11-14 20:01:32 --> URI Class Initialized
INFO - 2017-11-14 20:01:32 --> Router Class Initialized
INFO - 2017-11-14 20:01:32 --> Output Class Initialized
INFO - 2017-11-14 20:01:32 --> Security Class Initialized
DEBUG - 2017-11-14 20:01:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 20:01:32 --> Input Class Initialized
INFO - 2017-11-14 20:01:32 --> Language Class Initialized
ERROR - 2017-11-14 20:01:32 --> 404 Page Not Found: /index
INFO - 2017-11-14 20:01:41 --> Config Class Initialized
INFO - 2017-11-14 20:01:41 --> Hooks Class Initialized
DEBUG - 2017-11-14 20:01:41 --> UTF-8 Support Enabled
INFO - 2017-11-14 20:01:41 --> Utf8 Class Initialized
INFO - 2017-11-14 20:01:41 --> URI Class Initialized
INFO - 2017-11-14 20:01:41 --> Router Class Initialized
INFO - 2017-11-14 20:01:41 --> Output Class Initialized
INFO - 2017-11-14 20:01:41 --> Security Class Initialized
DEBUG - 2017-11-14 20:01:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 20:01:41 --> Input Class Initialized
INFO - 2017-11-14 20:01:41 --> Language Class Initialized
ERROR - 2017-11-14 20:01:41 --> 404 Page Not Found: /index
INFO - 2017-11-14 20:01:59 --> Config Class Initialized
INFO - 2017-11-14 20:01:59 --> Hooks Class Initialized
DEBUG - 2017-11-14 20:01:59 --> UTF-8 Support Enabled
INFO - 2017-11-14 20:01:59 --> Utf8 Class Initialized
INFO - 2017-11-14 20:01:59 --> URI Class Initialized
INFO - 2017-11-14 20:01:59 --> Router Class Initialized
INFO - 2017-11-14 20:01:59 --> Output Class Initialized
INFO - 2017-11-14 20:01:59 --> Security Class Initialized
DEBUG - 2017-11-14 20:01:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 20:01:59 --> Input Class Initialized
INFO - 2017-11-14 20:01:59 --> Language Class Initialized
INFO - 2017-11-14 20:01:59 --> Language Class Initialized
INFO - 2017-11-14 20:01:59 --> Config Class Initialized
INFO - 2017-11-14 20:01:59 --> Loader Class Initialized
DEBUG - 2017-11-14 20:01:59 --> Config file loaded: D:\xampp\htdocs\construction_bay\application\config/construct-data.php
INFO - 2017-11-14 20:01:59 --> Helper loaded: url_helper
INFO - 2017-11-14 20:01:59 --> Helper loaded: form_helper
INFO - 2017-11-14 20:01:59 --> Helper loaded: date_helper
INFO - 2017-11-14 20:01:59 --> Helper loaded: util_helper
INFO - 2017-11-14 20:01:59 --> Helper loaded: text_helper
INFO - 2017-11-14 20:01:59 --> Helper loaded: string_helper
INFO - 2017-11-14 20:01:59 --> Database Driver Class Initialized
DEBUG - 2017-11-14 20:01:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-14 20:01:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-14 20:01:59 --> Email Class Initialized
INFO - 2017-11-14 20:01:59 --> Controller Class Initialized
DEBUG - 2017-11-14 20:01:59 --> Home MX_Controller Initialized
INFO - 2017-11-14 20:01:59 --> Model Class Initialized
DEBUG - 2017-11-14 20:01:59 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_model.php
INFO - 2017-11-14 20:01:59 --> Model Class Initialized
DEBUG - 2017-11-14 20:01:59 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header_menu.php
DEBUG - 2017-11-14 20:01:59 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header.php
DEBUG - 2017-11-14 20:01:59 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\partner-with-us.php
DEBUG - 2017-11-14 20:01:59 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/footer_nav.php
DEBUG - 2017-11-14 20:01:59 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/footer.php
INFO - 2017-11-14 20:01:59 --> Final output sent to browser
DEBUG - 2017-11-14 20:01:59 --> Total execution time: 0.0670
INFO - 2017-11-14 20:55:42 --> Config Class Initialized
INFO - 2017-11-14 20:55:42 --> Hooks Class Initialized
DEBUG - 2017-11-14 20:55:42 --> UTF-8 Support Enabled
INFO - 2017-11-14 20:55:42 --> Utf8 Class Initialized
INFO - 2017-11-14 20:55:42 --> URI Class Initialized
INFO - 2017-11-14 20:55:42 --> Router Class Initialized
INFO - 2017-11-14 20:55:42 --> Output Class Initialized
INFO - 2017-11-14 20:55:42 --> Security Class Initialized
DEBUG - 2017-11-14 20:55:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 20:55:42 --> Input Class Initialized
INFO - 2017-11-14 20:55:42 --> Language Class Initialized
INFO - 2017-11-14 20:55:42 --> Language Class Initialized
INFO - 2017-11-14 20:55:42 --> Config Class Initialized
INFO - 2017-11-14 20:55:42 --> Loader Class Initialized
DEBUG - 2017-11-14 20:55:42 --> Config file loaded: D:\xampp\htdocs\construction_bay\application\config/construct-data.php
INFO - 2017-11-14 20:55:42 --> Helper loaded: url_helper
INFO - 2017-11-14 20:55:42 --> Helper loaded: form_helper
INFO - 2017-11-14 20:55:42 --> Helper loaded: date_helper
INFO - 2017-11-14 20:55:42 --> Helper loaded: util_helper
INFO - 2017-11-14 20:55:42 --> Helper loaded: text_helper
INFO - 2017-11-14 20:55:42 --> Helper loaded: string_helper
INFO - 2017-11-14 20:55:42 --> Database Driver Class Initialized
DEBUG - 2017-11-14 20:55:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-14 20:55:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-14 20:55:42 --> Email Class Initialized
INFO - 2017-11-14 20:55:42 --> Controller Class Initialized
INFO - 2017-11-14 20:55:42 --> Model Class Initialized
DEBUG - 2017-11-14 20:55:42 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_model.php
INFO - 2017-11-14 20:55:42 --> Model Class Initialized
DEBUG - 2017-11-14 20:55:42 --> File loaded: D:\xampp\htdocs\construction_bay\application\modules/common/models/Common_functions_model.php
INFO - 2017-11-14 20:55:42 --> Model Class Initialized
DEBUG - 2017-11-14 20:55:42 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header_menu.php
DEBUG - 2017-11-14 20:55:42 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/header.php
DEBUG - 2017-11-14 20:55:42 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\products-services.php
DEBUG - 2017-11-14 20:55:42 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/footer_nav.php
DEBUG - 2017-11-14 20:55:42 --> File loaded: D:\xampp\htdocs\construction_bay\application\views\common/footer.php
INFO - 2017-11-14 20:55:42 --> Final output sent to browser
DEBUG - 2017-11-14 20:55:42 --> Total execution time: 0.1090
INFO - 2017-11-14 20:55:49 --> Config Class Initialized
INFO - 2017-11-14 20:55:49 --> Hooks Class Initialized
DEBUG - 2017-11-14 20:55:49 --> UTF-8 Support Enabled
INFO - 2017-11-14 20:55:49 --> Utf8 Class Initialized
INFO - 2017-11-14 20:55:50 --> URI Class Initialized
INFO - 2017-11-14 20:55:50 --> Router Class Initialized
INFO - 2017-11-14 20:55:50 --> Output Class Initialized
INFO - 2017-11-14 20:55:50 --> Security Class Initialized
DEBUG - 2017-11-14 20:55:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-14 20:55:50 --> Input Class Initialized
INFO - 2017-11-14 20:55:50 --> Language Class Initialized
ERROR - 2017-11-14 20:55:50 --> 404 Page Not Found: Companies/favicon.ico
