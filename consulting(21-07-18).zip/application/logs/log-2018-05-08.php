<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-05-08 17:43:31 --> Config Class Initialized
INFO - 2018-05-08 17:43:31 --> Hooks Class Initialized
INFO - 2018-05-08 17:43:31 --> Utf8 Class Initialized
INFO - 2018-05-08 17:43:31 --> URI Class Initialized
INFO - 2018-05-08 17:43:32 --> Router Class Initialized
INFO - 2018-05-08 17:43:32 --> Output Class Initialized
INFO - 2018-05-08 17:43:32 --> Security Class Initialized
INFO - 2018-05-08 17:43:32 --> Input Class Initialized
INFO - 2018-05-08 17:43:33 --> Language Class Initialized
INFO - 2018-05-08 17:43:33 --> Loader Class Initialized
INFO - 2018-05-08 17:43:33 --> Helper loaded: url_helper
INFO - 2018-05-08 17:43:33 --> Helper loaded: form_helper
INFO - 2018-05-08 17:43:33 --> Helper loaded: date_helper
INFO - 2018-05-08 17:43:35 --> Helper loaded: util_helper
INFO - 2018-05-08 17:43:35 --> Helper loaded: text_helper
INFO - 2018-05-08 17:43:35 --> Helper loaded: string_helper
INFO - 2018-05-08 17:43:35 --> Database Driver Class Initialized
INFO - 2018-05-08 17:43:38 --> Email Class Initialized
INFO - 2018-05-08 17:43:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 17:43:38 --> Form Validation Class Initialized
INFO - 2018-05-08 17:43:38 --> Controller Class Initialized
INFO - 2018-05-08 17:43:38 --> File loaded: E:\xampp\htdocs\consulting\application\views\welcome_message.php
INFO - 2018-05-08 17:43:39 --> Final output sent to browser
INFO - 2018-05-08 17:45:04 --> Config Class Initialized
INFO - 2018-05-08 17:45:04 --> Hooks Class Initialized
INFO - 2018-05-08 17:45:05 --> Utf8 Class Initialized
INFO - 2018-05-08 17:45:05 --> URI Class Initialized
INFO - 2018-05-08 17:45:05 --> Router Class Initialized
INFO - 2018-05-08 17:45:05 --> Output Class Initialized
INFO - 2018-05-08 17:45:05 --> Security Class Initialized
INFO - 2018-05-08 17:45:05 --> Input Class Initialized
INFO - 2018-05-08 17:45:05 --> Language Class Initialized
INFO - 2018-05-08 17:45:05 --> Loader Class Initialized
INFO - 2018-05-08 17:45:05 --> Helper loaded: url_helper
INFO - 2018-05-08 17:45:05 --> Helper loaded: form_helper
INFO - 2018-05-08 17:45:05 --> Helper loaded: date_helper
INFO - 2018-05-08 17:45:05 --> Helper loaded: util_helper
INFO - 2018-05-08 17:45:05 --> Helper loaded: text_helper
INFO - 2018-05-08 17:45:05 --> Helper loaded: string_helper
INFO - 2018-05-08 17:45:05 --> Database Driver Class Initialized
INFO - 2018-05-08 17:45:05 --> Email Class Initialized
INFO - 2018-05-08 17:45:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 17:45:05 --> Form Validation Class Initialized
INFO - 2018-05-08 17:45:05 --> Controller Class Initialized
INFO - 2018-05-08 17:45:05 --> File loaded: E:\xampp\htdocs\consulting\application\views\welcome_message.php
INFO - 2018-05-08 17:45:05 --> Final output sent to browser
INFO - 2018-05-08 17:49:39 --> Config Class Initialized
INFO - 2018-05-08 17:49:39 --> Hooks Class Initialized
INFO - 2018-05-08 17:49:39 --> Utf8 Class Initialized
INFO - 2018-05-08 17:49:39 --> URI Class Initialized
INFO - 2018-05-08 17:49:39 --> Router Class Initialized
INFO - 2018-05-08 17:49:39 --> Output Class Initialized
INFO - 2018-05-08 17:49:39 --> Security Class Initialized
INFO - 2018-05-08 17:49:39 --> Input Class Initialized
INFO - 2018-05-08 17:49:39 --> Language Class Initialized
INFO - 2018-05-08 17:49:39 --> Loader Class Initialized
INFO - 2018-05-08 17:49:39 --> Helper loaded: url_helper
INFO - 2018-05-08 17:49:40 --> Helper loaded: form_helper
INFO - 2018-05-08 17:49:40 --> Helper loaded: date_helper
INFO - 2018-05-08 17:49:40 --> Helper loaded: util_helper
INFO - 2018-05-08 17:49:40 --> Helper loaded: text_helper
INFO - 2018-05-08 17:49:40 --> Helper loaded: string_helper
INFO - 2018-05-08 17:49:40 --> Database Driver Class Initialized
INFO - 2018-05-08 17:49:40 --> Email Class Initialized
INFO - 2018-05-08 17:49:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 17:49:40 --> Form Validation Class Initialized
INFO - 2018-05-08 17:49:40 --> Controller Class Initialized
INFO - 2018-05-08 17:49:40 --> File loaded: E:\xampp\htdocs\consulting\application\views\welcome_message.php
INFO - 2018-05-08 17:49:40 --> Final output sent to browser
INFO - 2018-05-08 18:33:12 --> Config Class Initialized
INFO - 2018-05-08 18:33:12 --> Hooks Class Initialized
INFO - 2018-05-08 18:33:12 --> Utf8 Class Initialized
INFO - 2018-05-08 18:33:12 --> URI Class Initialized
INFO - 2018-05-08 18:33:12 --> Router Class Initialized
INFO - 2018-05-08 18:33:12 --> Output Class Initialized
INFO - 2018-05-08 18:33:12 --> Security Class Initialized
INFO - 2018-05-08 18:33:12 --> Input Class Initialized
INFO - 2018-05-08 18:33:12 --> Language Class Initialized
INFO - 2018-05-08 18:33:12 --> Loader Class Initialized
INFO - 2018-05-08 18:33:12 --> Helper loaded: url_helper
INFO - 2018-05-08 18:33:12 --> Helper loaded: form_helper
INFO - 2018-05-08 18:33:12 --> Helper loaded: date_helper
INFO - 2018-05-08 18:33:12 --> Helper loaded: util_helper
INFO - 2018-05-08 18:33:12 --> Helper loaded: text_helper
INFO - 2018-05-08 18:33:12 --> Helper loaded: string_helper
INFO - 2018-05-08 18:33:12 --> Database Driver Class Initialized
INFO - 2018-05-08 18:33:12 --> Email Class Initialized
INFO - 2018-05-08 18:33:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 18:33:12 --> Form Validation Class Initialized
INFO - 2018-05-08 18:33:12 --> Controller Class Initialized
INFO - 2018-05-08 18:33:12 --> File loaded: E:\xampp\htdocs\consulting\application\views\welcome_message.php
INFO - 2018-05-08 18:33:12 --> Final output sent to browser
INFO - 2018-05-08 19:15:14 --> Config Class Initialized
INFO - 2018-05-08 19:15:14 --> Hooks Class Initialized
INFO - 2018-05-08 19:15:14 --> Utf8 Class Initialized
INFO - 2018-05-08 19:15:14 --> URI Class Initialized
INFO - 2018-05-08 19:15:14 --> Router Class Initialized
INFO - 2018-05-08 19:15:14 --> Output Class Initialized
INFO - 2018-05-08 19:15:14 --> Security Class Initialized
INFO - 2018-05-08 19:15:14 --> Input Class Initialized
INFO - 2018-05-08 19:15:14 --> Language Class Initialized
ERROR - 2018-05-08 19:15:14 --> 404 Page Not Found: Home/index
INFO - 2018-05-08 19:15:19 --> Config Class Initialized
INFO - 2018-05-08 19:15:19 --> Hooks Class Initialized
INFO - 2018-05-08 19:15:19 --> Utf8 Class Initialized
INFO - 2018-05-08 19:15:19 --> URI Class Initialized
INFO - 2018-05-08 19:15:19 --> Router Class Initialized
INFO - 2018-05-08 19:15:19 --> Output Class Initialized
INFO - 2018-05-08 19:15:19 --> Security Class Initialized
INFO - 2018-05-08 19:15:19 --> Input Class Initialized
INFO - 2018-05-08 19:15:19 --> Language Class Initialized
ERROR - 2018-05-08 19:15:19 --> 404 Page Not Found: Home/index
INFO - 2018-05-08 19:16:11 --> Config Class Initialized
INFO - 2018-05-08 19:16:11 --> Hooks Class Initialized
INFO - 2018-05-08 19:16:11 --> Utf8 Class Initialized
INFO - 2018-05-08 19:16:11 --> URI Class Initialized
INFO - 2018-05-08 19:16:11 --> Router Class Initialized
INFO - 2018-05-08 19:16:11 --> Output Class Initialized
INFO - 2018-05-08 19:16:11 --> Security Class Initialized
INFO - 2018-05-08 19:16:11 --> Input Class Initialized
INFO - 2018-05-08 19:16:11 --> Language Class Initialized
ERROR - 2018-05-08 19:16:11 --> 404 Page Not Found: Home/index
INFO - 2018-05-08 19:22:11 --> Config Class Initialized
INFO - 2018-05-08 19:22:11 --> Hooks Class Initialized
INFO - 2018-05-08 19:22:11 --> Utf8 Class Initialized
INFO - 2018-05-08 19:22:11 --> URI Class Initialized
INFO - 2018-05-08 19:22:11 --> Router Class Initialized
INFO - 2018-05-08 19:22:11 --> Output Class Initialized
INFO - 2018-05-08 19:22:11 --> Security Class Initialized
INFO - 2018-05-08 19:22:11 --> Input Class Initialized
INFO - 2018-05-08 19:22:11 --> Language Class Initialized
ERROR - 2018-05-08 19:22:11 --> 404 Page Not Found: Home/index
INFO - 2018-05-08 19:24:07 --> Config Class Initialized
INFO - 2018-05-08 19:24:07 --> Hooks Class Initialized
INFO - 2018-05-08 19:24:07 --> Utf8 Class Initialized
INFO - 2018-05-08 19:24:07 --> URI Class Initialized
INFO - 2018-05-08 19:24:07 --> Router Class Initialized
INFO - 2018-05-08 19:24:07 --> Output Class Initialized
INFO - 2018-05-08 19:24:07 --> Security Class Initialized
INFO - 2018-05-08 19:24:07 --> Input Class Initialized
INFO - 2018-05-08 19:24:07 --> Language Class Initialized
ERROR - 2018-05-08 19:24:07 --> 404 Page Not Found: Home/index
INFO - 2018-05-08 19:24:30 --> Config Class Initialized
INFO - 2018-05-08 19:24:30 --> Hooks Class Initialized
INFO - 2018-05-08 19:24:30 --> Utf8 Class Initialized
INFO - 2018-05-08 19:24:30 --> URI Class Initialized
INFO - 2018-05-08 19:24:30 --> Router Class Initialized
INFO - 2018-05-08 19:24:30 --> Output Class Initialized
INFO - 2018-05-08 19:24:30 --> Security Class Initialized
INFO - 2018-05-08 19:24:30 --> Input Class Initialized
INFO - 2018-05-08 19:24:30 --> Language Class Initialized
ERROR - 2018-05-08 19:24:30 --> 404 Page Not Found: Home/index
INFO - 2018-05-08 19:39:22 --> Config Class Initialized
INFO - 2018-05-08 19:39:22 --> Hooks Class Initialized
INFO - 2018-05-08 19:39:22 --> Utf8 Class Initialized
INFO - 2018-05-08 19:39:22 --> URI Class Initialized
INFO - 2018-05-08 19:39:22 --> Router Class Initialized
INFO - 2018-05-08 19:39:22 --> Output Class Initialized
INFO - 2018-05-08 19:39:22 --> Security Class Initialized
INFO - 2018-05-08 19:39:22 --> Input Class Initialized
INFO - 2018-05-08 19:39:22 --> Language Class Initialized
ERROR - 2018-05-08 19:39:22 --> 404 Page Not Found: Home/index
INFO - 2018-05-08 19:49:51 --> Config Class Initialized
INFO - 2018-05-08 19:49:51 --> Hooks Class Initialized
INFO - 2018-05-08 19:49:51 --> Utf8 Class Initialized
INFO - 2018-05-08 19:49:51 --> URI Class Initialized
INFO - 2018-05-08 19:49:51 --> Router Class Initialized
INFO - 2018-05-08 19:49:51 --> Output Class Initialized
INFO - 2018-05-08 19:49:51 --> Security Class Initialized
INFO - 2018-05-08 19:49:51 --> Input Class Initialized
INFO - 2018-05-08 19:49:51 --> Language Class Initialized
ERROR - 2018-05-08 19:49:51 --> 404 Page Not Found: Home/index
INFO - 2018-05-08 19:51:19 --> Config Class Initialized
INFO - 2018-05-08 19:51:19 --> Hooks Class Initialized
INFO - 2018-05-08 19:51:19 --> Utf8 Class Initialized
INFO - 2018-05-08 19:51:19 --> URI Class Initialized
INFO - 2018-05-08 19:51:19 --> Router Class Initialized
INFO - 2018-05-08 19:51:19 --> Output Class Initialized
INFO - 2018-05-08 19:51:19 --> Security Class Initialized
INFO - 2018-05-08 19:51:19 --> Input Class Initialized
INFO - 2018-05-08 19:51:19 --> Language Class Initialized
ERROR - 2018-05-08 19:51:19 --> 404 Page Not Found: Home/index
INFO - 2018-05-08 19:51:22 --> Config Class Initialized
INFO - 2018-05-08 19:51:22 --> Hooks Class Initialized
INFO - 2018-05-08 19:51:22 --> Utf8 Class Initialized
INFO - 2018-05-08 19:51:22 --> URI Class Initialized
INFO - 2018-05-08 19:51:22 --> Router Class Initialized
INFO - 2018-05-08 19:51:22 --> Output Class Initialized
INFO - 2018-05-08 19:51:22 --> Security Class Initialized
INFO - 2018-05-08 19:51:22 --> Input Class Initialized
INFO - 2018-05-08 19:51:22 --> Language Class Initialized
ERROR - 2018-05-08 19:51:22 --> 404 Page Not Found: Home/index
INFO - 2018-05-08 20:59:06 --> Config Class Initialized
INFO - 2018-05-08 20:59:06 --> Hooks Class Initialized
INFO - 2018-05-08 20:59:06 --> Utf8 Class Initialized
INFO - 2018-05-08 20:59:06 --> URI Class Initialized
INFO - 2018-05-08 20:59:06 --> Router Class Initialized
INFO - 2018-05-08 20:59:06 --> Output Class Initialized
INFO - 2018-05-08 20:59:06 --> Security Class Initialized
INFO - 2018-05-08 20:59:06 --> Input Class Initialized
INFO - 2018-05-08 20:59:06 --> Language Class Initialized
ERROR - 2018-05-08 20:59:06 --> 404 Page Not Found: Home/index
INFO - 2018-05-08 20:59:18 --> Config Class Initialized
INFO - 2018-05-08 20:59:18 --> Hooks Class Initialized
INFO - 2018-05-08 20:59:18 --> Utf8 Class Initialized
INFO - 2018-05-08 20:59:18 --> URI Class Initialized
INFO - 2018-05-08 20:59:18 --> Router Class Initialized
INFO - 2018-05-08 20:59:18 --> Output Class Initialized
INFO - 2018-05-08 20:59:18 --> Security Class Initialized
INFO - 2018-05-08 20:59:18 --> Input Class Initialized
INFO - 2018-05-08 20:59:18 --> Language Class Initialized
INFO - 2018-05-08 20:59:18 --> Loader Class Initialized
INFO - 2018-05-08 20:59:18 --> Helper loaded: url_helper
INFO - 2018-05-08 20:59:19 --> Helper loaded: form_helper
INFO - 2018-05-08 20:59:19 --> Helper loaded: date_helper
INFO - 2018-05-08 20:59:19 --> Helper loaded: util_helper
INFO - 2018-05-08 20:59:19 --> Helper loaded: text_helper
INFO - 2018-05-08 20:59:19 --> Helper loaded: string_helper
INFO - 2018-05-08 20:59:19 --> Database Driver Class Initialized
INFO - 2018-05-08 20:59:19 --> Email Class Initialized
INFO - 2018-05-08 20:59:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 20:59:19 --> Form Validation Class Initialized
INFO - 2018-05-08 20:59:19 --> Controller Class Initialized
INFO - 2018-05-08 20:59:19 --> File loaded: E:\xampp\htdocs\consulting\application\views\welcome_message.php
INFO - 2018-05-08 20:59:19 --> Final output sent to browser
INFO - 2018-05-08 21:03:49 --> Config Class Initialized
INFO - 2018-05-08 21:03:49 --> Hooks Class Initialized
INFO - 2018-05-08 21:03:49 --> Utf8 Class Initialized
INFO - 2018-05-08 21:03:49 --> URI Class Initialized
INFO - 2018-05-08 21:03:49 --> Router Class Initialized
INFO - 2018-05-08 21:03:49 --> Output Class Initialized
INFO - 2018-05-08 21:03:49 --> Security Class Initialized
INFO - 2018-05-08 21:03:49 --> Input Class Initialized
INFO - 2018-05-08 21:03:49 --> Language Class Initialized
INFO - 2018-05-08 21:03:49 --> Loader Class Initialized
INFO - 2018-05-08 21:03:49 --> Helper loaded: url_helper
INFO - 2018-05-08 21:03:49 --> Helper loaded: form_helper
INFO - 2018-05-08 21:03:49 --> Helper loaded: date_helper
INFO - 2018-05-08 21:03:49 --> Helper loaded: util_helper
INFO - 2018-05-08 21:03:49 --> Helper loaded: text_helper
INFO - 2018-05-08 21:03:49 --> Helper loaded: string_helper
INFO - 2018-05-08 21:03:49 --> Database Driver Class Initialized
INFO - 2018-05-08 21:03:49 --> Email Class Initialized
INFO - 2018-05-08 21:03:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-08 21:03:49 --> Form Validation Class Initialized
INFO - 2018-05-08 21:03:49 --> Controller Class Initialized
INFO - 2018-05-08 21:03:49 --> File loaded: E:\xampp\htdocs\consulting\application\views\welcome_message.php
INFO - 2018-05-08 21:03:49 --> Final output sent to browser
INFO - 2018-05-08 21:09:06 --> Config Class Initialized
INFO - 2018-05-08 21:09:06 --> Hooks Class Initialized
INFO - 2018-05-08 21:09:06 --> Utf8 Class Initialized
INFO - 2018-05-08 21:09:06 --> URI Class Initialized
INFO - 2018-05-08 21:09:06 --> Router Class Initialized
INFO - 2018-05-08 21:09:06 --> Output Class Initialized
INFO - 2018-05-08 21:09:06 --> Security Class Initialized
INFO - 2018-05-08 21:09:06 --> Input Class Initialized
INFO - 2018-05-08 21:09:06 --> Language Class Initialized
ERROR - 2018-05-08 21:09:06 --> 404 Page Not Found: /index
INFO - 2018-05-08 21:11:19 --> Config Class Initialized
INFO - 2018-05-08 21:11:19 --> Hooks Class Initialized
INFO - 2018-05-08 21:11:19 --> Utf8 Class Initialized
INFO - 2018-05-08 21:11:19 --> URI Class Initialized
INFO - 2018-05-08 21:11:19 --> Router Class Initialized
INFO - 2018-05-08 21:11:19 --> Output Class Initialized
INFO - 2018-05-08 21:11:19 --> Security Class Initialized
INFO - 2018-05-08 21:11:19 --> Input Class Initialized
INFO - 2018-05-08 21:11:19 --> Language Class Initialized
ERROR - 2018-05-08 21:11:19 --> 404 Page Not Found: /index
INFO - 2018-05-08 21:11:27 --> Config Class Initialized
INFO - 2018-05-08 21:11:27 --> Hooks Class Initialized
INFO - 2018-05-08 21:11:27 --> Utf8 Class Initialized
INFO - 2018-05-08 21:11:27 --> URI Class Initialized
INFO - 2018-05-08 21:11:27 --> Router Class Initialized
INFO - 2018-05-08 21:11:27 --> Output Class Initialized
INFO - 2018-05-08 21:11:27 --> Security Class Initialized
INFO - 2018-05-08 21:11:27 --> Input Class Initialized
INFO - 2018-05-08 21:11:27 --> Language Class Initialized
INFO - 2018-05-08 21:11:27 --> Language Class Initialized
INFO - 2018-05-08 21:11:27 --> Config Class Initialized
INFO - 2018-05-08 21:11:27 --> Loader Class Initialized
INFO - 2018-05-08 21:11:27 --> Helper loaded: url_helper
INFO - 2018-05-08 21:11:27 --> Helper loaded: form_helper
INFO - 2018-05-08 21:11:27 --> Helper loaded: date_helper
INFO - 2018-05-08 21:11:27 --> Helper loaded: util_helper
INFO - 2018-05-08 21:11:27 --> Helper loaded: text_helper
INFO - 2018-05-08 21:11:27 --> Helper loaded: string_helper
INFO - 2018-05-08 21:11:27 --> Database Driver Class Initialized
ERROR - 2018-05-08 21:11:27 --> Severity: error --> Exception: Call to undefined method MY_Loader::_ci_load_class() E:\xampp\htdocs\consulting\application\third_party\MX\Loader.php 158
INFO - 2018-05-08 21:24:29 --> Config Class Initialized
INFO - 2018-05-08 21:24:29 --> Hooks Class Initialized
INFO - 2018-05-08 21:24:29 --> Utf8 Class Initialized
INFO - 2018-05-08 21:24:29 --> URI Class Initialized
INFO - 2018-05-08 21:24:29 --> Router Class Initialized
INFO - 2018-05-08 21:24:29 --> Output Class Initialized
INFO - 2018-05-08 21:24:29 --> Security Class Initialized
INFO - 2018-05-08 21:24:29 --> Input Class Initialized
INFO - 2018-05-08 21:24:29 --> Language Class Initialized
ERROR - 2018-05-08 21:24:29 --> 404 Page Not Found: /index
INFO - 2018-05-08 21:26:02 --> Config Class Initialized
INFO - 2018-05-08 21:26:02 --> Hooks Class Initialized
INFO - 2018-05-08 21:26:02 --> Utf8 Class Initialized
INFO - 2018-05-08 21:26:02 --> URI Class Initialized
INFO - 2018-05-08 21:26:02 --> Router Class Initialized
INFO - 2018-05-08 21:26:02 --> Output Class Initialized
INFO - 2018-05-08 21:26:02 --> Security Class Initialized
INFO - 2018-05-08 21:26:02 --> Input Class Initialized
INFO - 2018-05-08 21:26:02 --> Language Class Initialized
ERROR - 2018-05-08 21:26:02 --> 404 Page Not Found: /index
INFO - 2018-05-08 21:26:05 --> Config Class Initialized
INFO - 2018-05-08 21:26:05 --> Hooks Class Initialized
INFO - 2018-05-08 21:26:05 --> Utf8 Class Initialized
INFO - 2018-05-08 21:26:05 --> URI Class Initialized
INFO - 2018-05-08 21:26:05 --> Router Class Initialized
INFO - 2018-05-08 21:26:05 --> Output Class Initialized
INFO - 2018-05-08 21:26:05 --> Security Class Initialized
INFO - 2018-05-08 21:26:05 --> Input Class Initialized
INFO - 2018-05-08 21:26:05 --> Language Class Initialized
ERROR - 2018-05-08 21:26:05 --> 404 Page Not Found: /index
INFO - 2018-05-08 21:26:14 --> Config Class Initialized
INFO - 2018-05-08 21:26:14 --> Hooks Class Initialized
INFO - 2018-05-08 21:26:14 --> Utf8 Class Initialized
INFO - 2018-05-08 21:26:14 --> URI Class Initialized
INFO - 2018-05-08 21:26:14 --> Router Class Initialized
INFO - 2018-05-08 21:26:14 --> Output Class Initialized
INFO - 2018-05-08 21:26:14 --> Security Class Initialized
INFO - 2018-05-08 21:26:14 --> Input Class Initialized
INFO - 2018-05-08 21:26:14 --> Language Class Initialized
ERROR - 2018-05-08 21:26:14 --> 404 Page Not Found: /index
INFO - 2018-05-08 21:27:02 --> Config Class Initialized
INFO - 2018-05-08 21:27:02 --> Hooks Class Initialized
INFO - 2018-05-08 21:27:02 --> Utf8 Class Initialized
INFO - 2018-05-08 21:27:02 --> URI Class Initialized
INFO - 2018-05-08 21:27:02 --> Router Class Initialized
INFO - 2018-05-08 21:27:02 --> Output Class Initialized
INFO - 2018-05-08 21:27:02 --> Security Class Initialized
INFO - 2018-05-08 21:27:02 --> Input Class Initialized
INFO - 2018-05-08 21:27:02 --> Language Class Initialized
ERROR - 2018-05-08 21:27:02 --> 404 Page Not Found: /index
INFO - 2018-05-08 21:27:03 --> Config Class Initialized
INFO - 2018-05-08 21:27:03 --> Hooks Class Initialized
INFO - 2018-05-08 21:27:03 --> Utf8 Class Initialized
INFO - 2018-05-08 21:27:03 --> URI Class Initialized
INFO - 2018-05-08 21:27:03 --> Router Class Initialized
INFO - 2018-05-08 21:27:03 --> Output Class Initialized
INFO - 2018-05-08 21:27:03 --> Security Class Initialized
INFO - 2018-05-08 21:27:03 --> Input Class Initialized
INFO - 2018-05-08 21:27:03 --> Language Class Initialized
ERROR - 2018-05-08 21:27:03 --> 404 Page Not Found: /index
INFO - 2018-05-08 21:29:12 --> Config Class Initialized
INFO - 2018-05-08 21:29:12 --> Hooks Class Initialized
INFO - 2018-05-08 21:29:12 --> Utf8 Class Initialized
INFO - 2018-05-08 21:29:12 --> URI Class Initialized
INFO - 2018-05-08 21:29:12 --> Router Class Initialized
INFO - 2018-05-08 21:29:12 --> Output Class Initialized
INFO - 2018-05-08 21:29:12 --> Security Class Initialized
INFO - 2018-05-08 21:29:12 --> Input Class Initialized
INFO - 2018-05-08 21:29:12 --> Language Class Initialized
ERROR - 2018-05-08 21:29:12 --> 404 Page Not Found: /index
INFO - 2018-05-08 21:29:35 --> Config Class Initialized
INFO - 2018-05-08 21:29:35 --> Hooks Class Initialized
INFO - 2018-05-08 21:29:35 --> Utf8 Class Initialized
INFO - 2018-05-08 21:29:35 --> URI Class Initialized
INFO - 2018-05-08 21:29:35 --> Router Class Initialized
INFO - 2018-05-08 21:29:35 --> Output Class Initialized
INFO - 2018-05-08 21:29:35 --> Security Class Initialized
INFO - 2018-05-08 21:29:35 --> Input Class Initialized
INFO - 2018-05-08 21:29:35 --> Language Class Initialized
INFO - 2018-05-08 21:29:35 --> Language Class Initialized
INFO - 2018-05-08 21:29:35 --> Config Class Initialized
INFO - 2018-05-08 21:29:35 --> Loader Class Initialized
INFO - 2018-05-08 21:29:35 --> Helper loaded: url_helper
INFO - 2018-05-08 21:29:35 --> Helper loaded: form_helper
INFO - 2018-05-08 21:29:35 --> Helper loaded: date_helper
INFO - 2018-05-08 21:29:35 --> Helper loaded: util_helper
INFO - 2018-05-08 21:29:35 --> Helper loaded: text_helper
INFO - 2018-05-08 21:29:35 --> Helper loaded: string_helper
INFO - 2018-05-08 21:29:35 --> Database Driver Class Initialized
ERROR - 2018-05-08 21:29:35 --> Severity: error --> Exception: Call to undefined method MY_Loader::_ci_load_class() E:\xampp\htdocs\consulting\application\third_party\MX\Loader.php 158
INFO - 2018-05-08 21:30:34 --> Config Class Initialized
INFO - 2018-05-08 21:30:34 --> Hooks Class Initialized
INFO - 2018-05-08 21:30:35 --> Utf8 Class Initialized
INFO - 2018-05-08 21:30:35 --> URI Class Initialized
INFO - 2018-05-08 21:30:35 --> Router Class Initialized
INFO - 2018-05-08 21:30:35 --> Output Class Initialized
INFO - 2018-05-08 21:30:35 --> Security Class Initialized
INFO - 2018-05-08 21:30:35 --> Input Class Initialized
INFO - 2018-05-08 21:30:35 --> Language Class Initialized
INFO - 2018-05-08 21:30:35 --> Language Class Initialized
INFO - 2018-05-08 21:30:35 --> Config Class Initialized
INFO - 2018-05-08 21:30:35 --> Loader Class Initialized
INFO - 2018-05-08 21:30:35 --> Helper loaded: url_helper
INFO - 2018-05-08 21:30:35 --> Helper loaded: form_helper
INFO - 2018-05-08 21:30:35 --> Helper loaded: date_helper
INFO - 2018-05-08 21:30:35 --> Helper loaded: util_helper
INFO - 2018-05-08 21:30:35 --> Helper loaded: text_helper
INFO - 2018-05-08 21:30:35 --> Helper loaded: string_helper
INFO - 2018-05-08 21:30:35 --> Database Driver Class Initialized
ERROR - 2018-05-08 21:30:35 --> Severity: error --> Exception: Call to undefined method MY_Loader::_ci_load_class() E:\xampp\htdocs\consulting\application\third_party\MX\Loader.php 158
INFO - 2018-05-08 21:31:34 --> Config Class Initialized
INFO - 2018-05-08 21:31:34 --> Hooks Class Initialized
INFO - 2018-05-08 21:31:34 --> Utf8 Class Initialized
INFO - 2018-05-08 21:31:34 --> URI Class Initialized
INFO - 2018-05-08 21:31:34 --> Router Class Initialized
INFO - 2018-05-08 21:31:34 --> Output Class Initialized
INFO - 2018-05-08 21:31:34 --> Security Class Initialized
INFO - 2018-05-08 21:31:34 --> Input Class Initialized
INFO - 2018-05-08 21:31:34 --> Language Class Initialized
INFO - 2018-05-08 21:31:34 --> Language Class Initialized
INFO - 2018-05-08 21:31:34 --> Config Class Initialized
INFO - 2018-05-08 21:31:34 --> Loader Class Initialized
INFO - 2018-05-08 21:31:34 --> Helper loaded: url_helper
INFO - 2018-05-08 21:31:34 --> Helper loaded: form_helper
INFO - 2018-05-08 21:31:34 --> Helper loaded: date_helper
INFO - 2018-05-08 21:31:34 --> Helper loaded: util_helper
INFO - 2018-05-08 21:31:34 --> Helper loaded: text_helper
INFO - 2018-05-08 21:31:34 --> Helper loaded: string_helper
INFO - 2018-05-08 21:31:34 --> Database Driver Class Initialized
ERROR - 2018-05-08 21:31:34 --> Severity: error --> Exception: Call to undefined method MY_Loader::_ci_load_class() E:\xampp\htdocs\consulting\application\third_party\MX\Loader.php 158
INFO - 2018-05-08 21:42:05 --> Config Class Initialized
INFO - 2018-05-08 21:42:05 --> Hooks Class Initialized
INFO - 2018-05-08 21:42:05 --> Utf8 Class Initialized
INFO - 2018-05-08 21:42:05 --> URI Class Initialized
INFO - 2018-05-08 21:42:05 --> Router Class Initialized
INFO - 2018-05-08 21:42:05 --> Output Class Initialized
INFO - 2018-05-08 21:42:05 --> Security Class Initialized
INFO - 2018-05-08 21:42:05 --> Input Class Initialized
INFO - 2018-05-08 21:42:05 --> Language Class Initialized
INFO - 2018-05-08 21:42:05 --> Language Class Initialized
INFO - 2018-05-08 21:42:05 --> Config Class Initialized
INFO - 2018-05-08 21:42:05 --> Loader Class Initialized
INFO - 2018-05-08 21:42:05 --> Helper loaded: url_helper
INFO - 2018-05-08 21:42:05 --> Helper loaded: form_helper
INFO - 2018-05-08 21:42:05 --> Helper loaded: date_helper
INFO - 2018-05-08 21:42:05 --> Helper loaded: util_helper
INFO - 2018-05-08 21:42:05 --> Helper loaded: text_helper
INFO - 2018-05-08 21:42:05 --> Helper loaded: string_helper
INFO - 2018-05-08 21:42:05 --> Database Driver Class Initialized
ERROR - 2018-05-08 21:42:05 --> Severity: error --> Exception: Call to undefined method MY_Loader::_ci_load_class() E:\xampp\htdocs\consulting\application\third_party\MX\Loader.php 158
INFO - 2018-05-08 21:42:18 --> Config Class Initialized
INFO - 2018-05-08 21:42:18 --> Hooks Class Initialized
INFO - 2018-05-08 21:42:18 --> Utf8 Class Initialized
INFO - 2018-05-08 21:42:18 --> URI Class Initialized
INFO - 2018-05-08 21:42:18 --> Router Class Initialized
INFO - 2018-05-08 21:42:18 --> Output Class Initialized
INFO - 2018-05-08 21:42:18 --> Security Class Initialized
INFO - 2018-05-08 21:42:18 --> Input Class Initialized
INFO - 2018-05-08 21:42:18 --> Language Class Initialized
INFO - 2018-05-08 21:42:18 --> Language Class Initialized
INFO - 2018-05-08 21:42:18 --> Config Class Initialized
INFO - 2018-05-08 21:42:18 --> Loader Class Initialized
INFO - 2018-05-08 21:42:18 --> Helper loaded: url_helper
INFO - 2018-05-08 21:42:18 --> Helper loaded: form_helper
INFO - 2018-05-08 21:42:18 --> Helper loaded: date_helper
INFO - 2018-05-08 21:42:18 --> Helper loaded: util_helper
INFO - 2018-05-08 21:42:18 --> Helper loaded: text_helper
INFO - 2018-05-08 21:42:18 --> Helper loaded: string_helper
INFO - 2018-05-08 21:42:18 --> Database Driver Class Initialized
ERROR - 2018-05-08 21:42:18 --> Severity: error --> Exception: Call to undefined method MY_Loader::_ci_load_class() E:\xampp\htdocs\consulting\application\third_party\MX\Loader.php 158
INFO - 2018-05-08 21:42:19 --> Config Class Initialized
INFO - 2018-05-08 21:42:19 --> Hooks Class Initialized
INFO - 2018-05-08 21:42:19 --> Utf8 Class Initialized
INFO - 2018-05-08 21:42:19 --> URI Class Initialized
INFO - 2018-05-08 21:42:19 --> Router Class Initialized
INFO - 2018-05-08 21:42:19 --> Output Class Initialized
INFO - 2018-05-08 21:42:19 --> Security Class Initialized
INFO - 2018-05-08 21:42:19 --> Input Class Initialized
INFO - 2018-05-08 21:42:19 --> Language Class Initialized
INFO - 2018-05-08 21:42:19 --> Language Class Initialized
INFO - 2018-05-08 21:42:19 --> Config Class Initialized
INFO - 2018-05-08 21:42:19 --> Loader Class Initialized
INFO - 2018-05-08 21:42:19 --> Helper loaded: url_helper
INFO - 2018-05-08 21:42:19 --> Helper loaded: form_helper
INFO - 2018-05-08 21:42:19 --> Helper loaded: date_helper
INFO - 2018-05-08 21:42:19 --> Helper loaded: util_helper
INFO - 2018-05-08 21:42:19 --> Helper loaded: text_helper
INFO - 2018-05-08 21:42:19 --> Helper loaded: string_helper
INFO - 2018-05-08 21:42:19 --> Database Driver Class Initialized
ERROR - 2018-05-08 21:42:19 --> Severity: error --> Exception: Call to undefined method MY_Loader::_ci_load_class() E:\xampp\htdocs\consulting\application\third_party\MX\Loader.php 158
INFO - 2018-05-08 21:47:33 --> Config Class Initialized
INFO - 2018-05-08 21:47:33 --> Hooks Class Initialized
INFO - 2018-05-08 21:47:33 --> Utf8 Class Initialized
INFO - 2018-05-08 21:47:33 --> URI Class Initialized
INFO - 2018-05-08 21:47:33 --> Router Class Initialized
INFO - 2018-05-08 21:47:33 --> Output Class Initialized
INFO - 2018-05-08 21:47:33 --> Security Class Initialized
INFO - 2018-05-08 21:47:33 --> Input Class Initialized
INFO - 2018-05-08 21:47:33 --> Language Class Initialized
INFO - 2018-05-08 21:47:33 --> Language Class Initialized
INFO - 2018-05-08 21:47:33 --> Config Class Initialized
INFO - 2018-05-08 21:47:33 --> Loader Class Initialized
INFO - 2018-05-08 21:47:33 --> Helper loaded: url_helper
INFO - 2018-05-08 21:47:33 --> Helper loaded: form_helper
INFO - 2018-05-08 21:47:33 --> Helper loaded: date_helper
INFO - 2018-05-08 21:47:33 --> Helper loaded: util_helper
INFO - 2018-05-08 21:47:33 --> Helper loaded: text_helper
INFO - 2018-05-08 21:47:33 --> Helper loaded: string_helper
INFO - 2018-05-08 21:47:33 --> Database Driver Class Initialized
ERROR - 2018-05-08 21:47:33 --> Severity: error --> Exception: Call to undefined method MY_Loader::_ci_load_class() E:\xampp\htdocs\consulting\application\third_party\MX\Loader.php 158
INFO - 2018-05-08 21:47:39 --> Config Class Initialized
INFO - 2018-05-08 21:47:39 --> Hooks Class Initialized
INFO - 2018-05-08 21:47:39 --> Utf8 Class Initialized
INFO - 2018-05-08 21:47:39 --> URI Class Initialized
INFO - 2018-05-08 21:47:39 --> Router Class Initialized
INFO - 2018-05-08 21:47:39 --> Output Class Initialized
INFO - 2018-05-08 21:47:39 --> Security Class Initialized
INFO - 2018-05-08 21:47:39 --> Input Class Initialized
INFO - 2018-05-08 21:47:39 --> Language Class Initialized
INFO - 2018-05-08 21:47:39 --> Language Class Initialized
INFO - 2018-05-08 21:47:39 --> Config Class Initialized
INFO - 2018-05-08 21:47:39 --> Loader Class Initialized
INFO - 2018-05-08 21:47:39 --> Helper loaded: url_helper
INFO - 2018-05-08 21:47:39 --> Helper loaded: form_helper
INFO - 2018-05-08 21:47:39 --> Helper loaded: date_helper
INFO - 2018-05-08 21:47:39 --> Helper loaded: util_helper
INFO - 2018-05-08 21:47:39 --> Helper loaded: text_helper
INFO - 2018-05-08 21:47:39 --> Helper loaded: string_helper
INFO - 2018-05-08 21:47:39 --> Database Driver Class Initialized
ERROR - 2018-05-08 21:47:39 --> Severity: error --> Exception: Call to undefined method MY_Loader::_ci_load_class() E:\xampp\htdocs\consulting\application\third_party\MX\Loader.php 158
INFO - 2018-05-08 21:47:44 --> Config Class Initialized
INFO - 2018-05-08 21:47:44 --> Hooks Class Initialized
INFO - 2018-05-08 21:47:44 --> Utf8 Class Initialized
INFO - 2018-05-08 21:47:44 --> URI Class Initialized
INFO - 2018-05-08 21:47:44 --> Router Class Initialized
INFO - 2018-05-08 21:47:44 --> Output Class Initialized
INFO - 2018-05-08 21:47:44 --> Security Class Initialized
INFO - 2018-05-08 21:47:44 --> Input Class Initialized
INFO - 2018-05-08 21:47:44 --> Language Class Initialized
INFO - 2018-05-08 21:47:44 --> Language Class Initialized
INFO - 2018-05-08 21:47:44 --> Config Class Initialized
INFO - 2018-05-08 21:47:44 --> Loader Class Initialized
INFO - 2018-05-08 21:47:44 --> Helper loaded: url_helper
INFO - 2018-05-08 21:47:44 --> Helper loaded: form_helper
INFO - 2018-05-08 21:47:44 --> Helper loaded: date_helper
INFO - 2018-05-08 21:47:44 --> Helper loaded: util_helper
INFO - 2018-05-08 21:47:44 --> Helper loaded: text_helper
INFO - 2018-05-08 21:47:44 --> Helper loaded: string_helper
INFO - 2018-05-08 21:47:44 --> Database Driver Class Initialized
ERROR - 2018-05-08 21:47:44 --> Severity: error --> Exception: Call to undefined method MY_Loader::_ci_load_class() E:\xampp\htdocs\consulting\application\third_party\MX\Loader.php 158
INFO - 2018-05-08 21:55:47 --> Config Class Initialized
INFO - 2018-05-08 21:55:47 --> Hooks Class Initialized
INFO - 2018-05-08 21:55:47 --> Utf8 Class Initialized
INFO - 2018-05-08 21:55:47 --> URI Class Initialized
INFO - 2018-05-08 21:55:48 --> Router Class Initialized
INFO - 2018-05-08 21:55:48 --> Output Class Initialized
INFO - 2018-05-08 21:55:48 --> Security Class Initialized
INFO - 2018-05-08 21:55:48 --> Input Class Initialized
INFO - 2018-05-08 21:55:48 --> Language Class Initialized
INFO - 2018-05-08 21:55:48 --> Language Class Initialized
INFO - 2018-05-08 21:55:48 --> Config Class Initialized
INFO - 2018-05-08 21:55:48 --> Loader Class Initialized
INFO - 2018-05-08 21:55:48 --> Helper loaded: url_helper
INFO - 2018-05-08 21:55:48 --> Helper loaded: form_helper
INFO - 2018-05-08 21:55:48 --> Helper loaded: date_helper
INFO - 2018-05-08 21:55:48 --> Helper loaded: util_helper
INFO - 2018-05-08 21:55:48 --> Helper loaded: text_helper
INFO - 2018-05-08 21:55:48 --> Helper loaded: string_helper
INFO - 2018-05-08 21:55:48 --> Database Driver Class Initialized
ERROR - 2018-05-08 21:55:48 --> Severity: error --> Exception: Call to undefined method MY_Loader::_ci_load_class() E:\xampp\htdocs\consulting\application\third_party\MX\Loader.php 158
INFO - 2018-05-08 22:26:20 --> Config Class Initialized
INFO - 2018-05-08 22:26:20 --> Hooks Class Initialized
INFO - 2018-05-08 22:26:20 --> Utf8 Class Initialized
INFO - 2018-05-08 22:26:20 --> URI Class Initialized
INFO - 2018-05-08 22:26:20 --> Router Class Initialized
INFO - 2018-05-08 22:26:20 --> Output Class Initialized
INFO - 2018-05-08 22:26:20 --> Security Class Initialized
INFO - 2018-05-08 22:26:20 --> Input Class Initialized
INFO - 2018-05-08 22:26:20 --> Language Class Initialized
INFO - 2018-05-08 22:26:20 --> Language Class Initialized
INFO - 2018-05-08 22:26:20 --> Config Class Initialized
INFO - 2018-05-08 22:26:20 --> Loader Class Initialized
INFO - 2018-05-08 22:26:20 --> Helper loaded: url_helper
INFO - 2018-05-08 22:26:20 --> Helper loaded: form_helper
INFO - 2018-05-08 22:26:20 --> Helper loaded: date_helper
INFO - 2018-05-08 22:26:20 --> Helper loaded: util_helper
INFO - 2018-05-08 22:26:20 --> Helper loaded: text_helper
INFO - 2018-05-08 22:26:21 --> Helper loaded: string_helper
INFO - 2018-05-08 22:26:21 --> Database Driver Class Initialized
ERROR - 2018-05-08 22:26:21 --> Severity: error --> Exception: Call to undefined method MY_Loader::_ci_load_class() E:\xampp\htdocs\consulting\application\third_party\MX\Loader.php 158
INFO - 2018-05-08 22:27:52 --> Config Class Initialized
INFO - 2018-05-08 22:27:52 --> Hooks Class Initialized
INFO - 2018-05-08 22:27:53 --> Utf8 Class Initialized
INFO - 2018-05-08 22:27:53 --> URI Class Initialized
INFO - 2018-05-08 22:27:53 --> Router Class Initialized
INFO - 2018-05-08 22:27:53 --> Output Class Initialized
INFO - 2018-05-08 22:27:53 --> Security Class Initialized
INFO - 2018-05-08 22:27:53 --> Input Class Initialized
INFO - 2018-05-08 22:27:53 --> Language Class Initialized
INFO - 2018-05-08 22:27:53 --> Language Class Initialized
INFO - 2018-05-08 22:27:53 --> Config Class Initialized
INFO - 2018-05-08 22:27:53 --> Loader Class Initialized
INFO - 2018-05-08 22:27:53 --> Helper loaded: url_helper
INFO - 2018-05-08 22:27:53 --> Helper loaded: form_helper
INFO - 2018-05-08 22:27:53 --> Helper loaded: date_helper
INFO - 2018-05-08 22:27:53 --> Helper loaded: util_helper
INFO - 2018-05-08 22:27:53 --> Helper loaded: text_helper
INFO - 2018-05-08 22:27:53 --> Helper loaded: string_helper
INFO - 2018-05-08 22:27:53 --> Database Driver Class Initialized
ERROR - 2018-05-08 22:27:53 --> Severity: error --> Exception: Call to undefined method MY_Loader::_ci_load_class() E:\xampp\htdocs\consulting\application\third_party\MX\Loader.php 158
INFO - 2018-05-08 23:03:50 --> Config Class Initialized
INFO - 2018-05-08 23:03:50 --> Hooks Class Initialized
INFO - 2018-05-08 23:03:50 --> Utf8 Class Initialized
INFO - 2018-05-08 23:03:50 --> URI Class Initialized
INFO - 2018-05-08 23:03:50 --> Router Class Initialized
INFO - 2018-05-08 23:03:50 --> Output Class Initialized
INFO - 2018-05-08 23:03:50 --> Security Class Initialized
INFO - 2018-05-08 23:03:50 --> Input Class Initialized
INFO - 2018-05-08 23:03:50 --> Language Class Initialized
ERROR - 2018-05-08 23:03:50 --> 404 Page Not Found: /index
INFO - 2018-05-08 23:04:21 --> Config Class Initialized
INFO - 2018-05-08 23:04:21 --> Hooks Class Initialized
INFO - 2018-05-08 23:04:21 --> Utf8 Class Initialized
INFO - 2018-05-08 23:04:21 --> URI Class Initialized
INFO - 2018-05-08 23:04:21 --> Router Class Initialized
INFO - 2018-05-08 23:04:21 --> Output Class Initialized
INFO - 2018-05-08 23:04:21 --> Security Class Initialized
INFO - 2018-05-08 23:04:21 --> Input Class Initialized
INFO - 2018-05-08 23:04:21 --> Language Class Initialized
ERROR - 2018-05-08 23:04:21 --> 404 Page Not Found: /index
INFO - 2018-05-08 23:04:30 --> Config Class Initialized
INFO - 2018-05-08 23:04:30 --> Hooks Class Initialized
INFO - 2018-05-08 23:04:30 --> Utf8 Class Initialized
INFO - 2018-05-08 23:04:30 --> URI Class Initialized
INFO - 2018-05-08 23:04:30 --> Router Class Initialized
INFO - 2018-05-08 23:04:30 --> Output Class Initialized
INFO - 2018-05-08 23:04:30 --> Security Class Initialized
INFO - 2018-05-08 23:04:30 --> Input Class Initialized
INFO - 2018-05-08 23:04:30 --> Language Class Initialized
INFO - 2018-05-08 23:04:30 --> Language Class Initialized
INFO - 2018-05-08 23:04:30 --> Config Class Initialized
INFO - 2018-05-08 23:04:30 --> Loader Class Initialized
INFO - 2018-05-08 23:04:30 --> Helper loaded: url_helper
INFO - 2018-05-08 23:04:30 --> Helper loaded: form_helper
INFO - 2018-05-08 23:04:30 --> Helper loaded: date_helper
INFO - 2018-05-08 23:04:30 --> Helper loaded: util_helper
INFO - 2018-05-08 23:04:30 --> Helper loaded: text_helper
INFO - 2018-05-08 23:04:30 --> Helper loaded: string_helper
INFO - 2018-05-08 23:04:30 --> Database Driver Class Initialized
ERROR - 2018-05-08 23:04:30 --> Severity: error --> Exception: Call to undefined method MY_Loader::_ci_load_class() E:\xampp\htdocs\consulting\application\third_party\MX\Loader.php 158
INFO - 2018-05-08 23:05:52 --> Config Class Initialized
INFO - 2018-05-08 23:05:52 --> Hooks Class Initialized
INFO - 2018-05-08 23:05:52 --> Utf8 Class Initialized
INFO - 2018-05-08 23:05:52 --> URI Class Initialized
INFO - 2018-05-08 23:05:52 --> Router Class Initialized
INFO - 2018-05-08 23:05:52 --> Output Class Initialized
INFO - 2018-05-08 23:05:52 --> Security Class Initialized
INFO - 2018-05-08 23:05:52 --> Input Class Initialized
INFO - 2018-05-08 23:05:52 --> Language Class Initialized
INFO - 2018-05-08 23:05:52 --> Language Class Initialized
INFO - 2018-05-08 23:05:52 --> Config Class Initialized
INFO - 2018-05-08 23:05:52 --> Loader Class Initialized
INFO - 2018-05-08 23:05:52 --> Helper loaded: url_helper
INFO - 2018-05-08 23:05:52 --> Helper loaded: form_helper
INFO - 2018-05-08 23:05:52 --> Helper loaded: date_helper
INFO - 2018-05-08 23:05:52 --> Helper loaded: util_helper
INFO - 2018-05-08 23:05:52 --> Helper loaded: text_helper
INFO - 2018-05-08 23:05:52 --> Helper loaded: string_helper
INFO - 2018-05-08 23:05:52 --> Database Driver Class Initialized
ERROR - 2018-05-08 23:05:52 --> Severity: error --> Exception: Call to undefined method MY_Loader::_ci_load_class() E:\xampp\htdocs\consulting\application\third_party\MX\Loader.php 158
INFO - 2018-05-08 23:11:54 --> Config Class Initialized
INFO - 2018-05-08 23:11:54 --> Hooks Class Initialized
INFO - 2018-05-08 23:11:54 --> Utf8 Class Initialized
INFO - 2018-05-08 23:11:54 --> URI Class Initialized
INFO - 2018-05-08 23:11:54 --> Router Class Initialized
INFO - 2018-05-08 23:11:54 --> Output Class Initialized
INFO - 2018-05-08 23:11:54 --> Security Class Initialized
INFO - 2018-05-08 23:11:54 --> Input Class Initialized
INFO - 2018-05-08 23:11:54 --> Language Class Initialized
INFO - 2018-05-08 23:11:54 --> Language Class Initialized
INFO - 2018-05-08 23:11:54 --> Config Class Initialized
INFO - 2018-05-08 23:11:54 --> Loader Class Initialized
INFO - 2018-05-08 23:11:54 --> Helper loaded: url_helper
INFO - 2018-05-08 23:11:54 --> Helper loaded: form_helper
INFO - 2018-05-08 23:11:54 --> Helper loaded: date_helper
INFO - 2018-05-08 23:11:54 --> Helper loaded: util_helper
INFO - 2018-05-08 23:11:54 --> Helper loaded: text_helper
INFO - 2018-05-08 23:11:54 --> Helper loaded: string_helper
ERROR - 2018-05-08 23:11:54 --> Severity: error --> Exception: Call to undefined method MY_Loader::_ci_load_class() E:\xampp\htdocs\consulting\application\third_party\MX\Loader.php 158
INFO - 2018-05-08 23:12:03 --> Config Class Initialized
INFO - 2018-05-08 23:12:03 --> Hooks Class Initialized
INFO - 2018-05-08 23:12:03 --> Utf8 Class Initialized
INFO - 2018-05-08 23:12:03 --> URI Class Initialized
INFO - 2018-05-08 23:12:03 --> Router Class Initialized
INFO - 2018-05-08 23:12:03 --> Output Class Initialized
INFO - 2018-05-08 23:12:03 --> Security Class Initialized
INFO - 2018-05-08 23:12:03 --> Input Class Initialized
INFO - 2018-05-08 23:12:03 --> Language Class Initialized
INFO - 2018-05-08 23:12:03 --> Language Class Initialized
INFO - 2018-05-08 23:12:03 --> Config Class Initialized
INFO - 2018-05-08 23:12:03 --> Loader Class Initialized
INFO - 2018-05-08 23:12:03 --> Helper loaded: url_helper
INFO - 2018-05-08 23:12:03 --> Helper loaded: form_helper
INFO - 2018-05-08 23:12:03 --> Helper loaded: date_helper
INFO - 2018-05-08 23:12:03 --> Helper loaded: util_helper
INFO - 2018-05-08 23:12:03 --> Helper loaded: text_helper
INFO - 2018-05-08 23:12:03 --> Helper loaded: string_helper
INFO - 2018-05-08 23:12:03 --> Controller Class Initialized
INFO - 2018-05-08 23:12:19 --> Config Class Initialized
INFO - 2018-05-08 23:12:19 --> Hooks Class Initialized
INFO - 2018-05-08 23:12:19 --> Utf8 Class Initialized
INFO - 2018-05-08 23:12:20 --> URI Class Initialized
INFO - 2018-05-08 23:12:20 --> Router Class Initialized
INFO - 2018-05-08 23:12:20 --> Output Class Initialized
INFO - 2018-05-08 23:12:20 --> Security Class Initialized
INFO - 2018-05-08 23:12:20 --> Input Class Initialized
INFO - 2018-05-08 23:12:20 --> Language Class Initialized
INFO - 2018-05-08 23:12:20 --> Language Class Initialized
INFO - 2018-05-08 23:12:20 --> Config Class Initialized
INFO - 2018-05-08 23:12:20 --> Loader Class Initialized
INFO - 2018-05-08 23:12:20 --> Helper loaded: url_helper
INFO - 2018-05-08 23:12:20 --> Helper loaded: form_helper
INFO - 2018-05-08 23:12:20 --> Helper loaded: date_helper
INFO - 2018-05-08 23:12:20 --> Helper loaded: util_helper
INFO - 2018-05-08 23:12:20 --> Helper loaded: text_helper
INFO - 2018-05-08 23:12:20 --> Helper loaded: string_helper
INFO - 2018-05-08 23:12:20 --> Database Driver Class Initialized
ERROR - 2018-05-08 23:12:20 --> Severity: error --> Exception: Call to undefined method MY_Loader::_ci_load_class() E:\xampp\htdocs\consulting\application\third_party\MX\Loader.php 158
INFO - 2018-05-08 23:12:30 --> Config Class Initialized
INFO - 2018-05-08 23:12:30 --> Hooks Class Initialized
INFO - 2018-05-08 23:12:30 --> Utf8 Class Initialized
INFO - 2018-05-08 23:12:30 --> URI Class Initialized
INFO - 2018-05-08 23:12:30 --> Router Class Initialized
INFO - 2018-05-08 23:12:30 --> Output Class Initialized
INFO - 2018-05-08 23:12:30 --> Security Class Initialized
INFO - 2018-05-08 23:12:30 --> Input Class Initialized
INFO - 2018-05-08 23:12:30 --> Language Class Initialized
INFO - 2018-05-08 23:12:30 --> Language Class Initialized
INFO - 2018-05-08 23:12:30 --> Config Class Initialized
INFO - 2018-05-08 23:12:31 --> Loader Class Initialized
INFO - 2018-05-08 23:12:31 --> Helper loaded: url_helper
INFO - 2018-05-08 23:12:31 --> Helper loaded: form_helper
INFO - 2018-05-08 23:12:31 --> Helper loaded: date_helper
INFO - 2018-05-08 23:12:31 --> Helper loaded: util_helper
INFO - 2018-05-08 23:12:31 --> Helper loaded: text_helper
INFO - 2018-05-08 23:12:31 --> Helper loaded: string_helper
INFO - 2018-05-08 23:12:31 --> Database Driver Class Initialized
ERROR - 2018-05-08 23:12:31 --> Severity: error --> Exception: Call to undefined method MY_Loader::_ci_load_class() E:\xampp\htdocs\consulting\application\third_party\MX\Loader.php 158
INFO - 2018-05-08 23:12:38 --> Config Class Initialized
INFO - 2018-05-08 23:12:39 --> Hooks Class Initialized
INFO - 2018-05-08 23:12:39 --> Utf8 Class Initialized
INFO - 2018-05-08 23:12:39 --> URI Class Initialized
INFO - 2018-05-08 23:12:39 --> Router Class Initialized
INFO - 2018-05-08 23:12:39 --> Output Class Initialized
INFO - 2018-05-08 23:12:39 --> Security Class Initialized
INFO - 2018-05-08 23:12:39 --> Input Class Initialized
INFO - 2018-05-08 23:12:39 --> Language Class Initialized
INFO - 2018-05-08 23:12:39 --> Language Class Initialized
INFO - 2018-05-08 23:12:39 --> Config Class Initialized
INFO - 2018-05-08 23:12:39 --> Loader Class Initialized
INFO - 2018-05-08 23:12:39 --> Helper loaded: url_helper
INFO - 2018-05-08 23:12:39 --> Helper loaded: form_helper
INFO - 2018-05-08 23:12:39 --> Helper loaded: date_helper
INFO - 2018-05-08 23:12:39 --> Helper loaded: util_helper
INFO - 2018-05-08 23:12:39 --> Helper loaded: text_helper
INFO - 2018-05-08 23:12:39 --> Helper loaded: string_helper
INFO - 2018-05-08 23:12:39 --> Database Driver Class Initialized
ERROR - 2018-05-08 23:12:39 --> Severity: error --> Exception: Call to undefined method MY_Loader::_ci_load_class() E:\xampp\htdocs\consulting\application\third_party\MX\Loader.php 158
INFO - 2018-05-08 23:12:46 --> Config Class Initialized
INFO - 2018-05-08 23:12:46 --> Hooks Class Initialized
INFO - 2018-05-08 23:12:46 --> Utf8 Class Initialized
INFO - 2018-05-08 23:12:46 --> URI Class Initialized
INFO - 2018-05-08 23:12:46 --> Router Class Initialized
INFO - 2018-05-08 23:12:46 --> Output Class Initialized
INFO - 2018-05-08 23:12:46 --> Security Class Initialized
INFO - 2018-05-08 23:12:46 --> Input Class Initialized
INFO - 2018-05-08 23:12:46 --> Language Class Initialized
INFO - 2018-05-08 23:12:46 --> Language Class Initialized
INFO - 2018-05-08 23:12:46 --> Config Class Initialized
INFO - 2018-05-08 23:12:46 --> Loader Class Initialized
INFO - 2018-05-08 23:12:46 --> Helper loaded: url_helper
INFO - 2018-05-08 23:12:46 --> Helper loaded: form_helper
INFO - 2018-05-08 23:12:46 --> Helper loaded: date_helper
INFO - 2018-05-08 23:12:46 --> Helper loaded: util_helper
INFO - 2018-05-08 23:12:46 --> Helper loaded: text_helper
INFO - 2018-05-08 23:12:46 --> Helper loaded: string_helper
ERROR - 2018-05-08 23:12:46 --> Severity: error --> Exception: Call to undefined method MY_Loader::_ci_load_class() E:\xampp\htdocs\consulting\application\third_party\MX\Loader.php 158
INFO - 2018-05-08 23:26:36 --> Config Class Initialized
INFO - 2018-05-08 23:26:36 --> Hooks Class Initialized
INFO - 2018-05-08 23:26:36 --> Utf8 Class Initialized
INFO - 2018-05-08 23:26:36 --> URI Class Initialized
INFO - 2018-05-08 23:26:36 --> Router Class Initialized
INFO - 2018-05-08 23:26:36 --> Output Class Initialized
INFO - 2018-05-08 23:26:36 --> Security Class Initialized
INFO - 2018-05-08 23:26:36 --> Input Class Initialized
INFO - 2018-05-08 23:26:36 --> Language Class Initialized
INFO - 2018-05-08 23:26:36 --> Language Class Initialized
INFO - 2018-05-08 23:26:36 --> Config Class Initialized
INFO - 2018-05-08 23:26:36 --> Loader Class Initialized
INFO - 2018-05-08 23:26:36 --> Helper loaded: url_helper
INFO - 2018-05-08 23:26:36 --> Helper loaded: form_helper
INFO - 2018-05-08 23:26:36 --> Helper loaded: date_helper
INFO - 2018-05-08 23:26:36 --> Helper loaded: util_helper
INFO - 2018-05-08 23:26:36 --> Helper loaded: text_helper
INFO - 2018-05-08 23:26:36 --> Helper loaded: string_helper
INFO - 2018-05-08 23:26:36 --> Database Driver Class Initialized
ERROR - 2018-05-08 23:26:36 --> Severity: error --> Exception: Call to undefined method MY_Loader::_ci_load_class() E:\xampp\htdocs\consulting\application\third_party\MX\Loader.php 158
