<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-05-09 01:47:25 --> Config Class Initialized
INFO - 2018-05-09 01:47:25 --> Hooks Class Initialized
INFO - 2018-05-09 01:47:25 --> Utf8 Class Initialized
INFO - 2018-05-09 01:47:25 --> URI Class Initialized
INFO - 2018-05-09 01:47:25 --> Router Class Initialized
INFO - 2018-05-09 01:47:25 --> Output Class Initialized
INFO - 2018-05-09 01:47:25 --> Security Class Initialized
INFO - 2018-05-09 01:47:25 --> Input Class Initialized
INFO - 2018-05-09 01:47:25 --> Language Class Initialized
INFO - 2018-05-09 01:47:25 --> Language Class Initialized
INFO - 2018-05-09 01:47:25 --> Config Class Initialized
INFO - 2018-05-09 01:47:25 --> Loader Class Initialized
INFO - 2018-05-09 01:47:25 --> Helper loaded: url_helper
INFO - 2018-05-09 01:47:25 --> Helper loaded: form_helper
INFO - 2018-05-09 01:47:25 --> Helper loaded: date_helper
INFO - 2018-05-09 01:47:25 --> Helper loaded: util_helper
INFO - 2018-05-09 01:47:25 --> Helper loaded: text_helper
INFO - 2018-05-09 01:47:25 --> Helper loaded: string_helper
INFO - 2018-05-09 01:47:25 --> Database Driver Class Initialized
ERROR - 2018-05-09 01:47:25 --> Severity: error --> Exception: Call to undefined method MY_Loader::_ci_load_class() E:\xampp\htdocs\consulting\application\third_party\MX\Loader.php 158
INFO - 2018-05-09 02:21:46 --> Config Class Initialized
INFO - 2018-05-09 02:21:46 --> Hooks Class Initialized
INFO - 2018-05-09 02:21:46 --> Utf8 Class Initialized
INFO - 2018-05-09 02:21:46 --> URI Class Initialized
INFO - 2018-05-09 02:21:46 --> Router Class Initialized
INFO - 2018-05-09 02:21:46 --> Output Class Initialized
INFO - 2018-05-09 02:21:46 --> Security Class Initialized
INFO - 2018-05-09 02:21:46 --> Input Class Initialized
INFO - 2018-05-09 02:21:46 --> Language Class Initialized
INFO - 2018-05-09 02:21:46 --> Language Class Initialized
INFO - 2018-05-09 02:21:46 --> Config Class Initialized
INFO - 2018-05-09 02:21:46 --> Loader Class Initialized
INFO - 2018-05-09 02:21:46 --> Helper loaded: url_helper
INFO - 2018-05-09 02:21:46 --> Helper loaded: form_helper
INFO - 2018-05-09 02:21:46 --> Helper loaded: date_helper
INFO - 2018-05-09 02:21:46 --> Helper loaded: util_helper
INFO - 2018-05-09 02:21:46 --> Helper loaded: text_helper
INFO - 2018-05-09 02:21:46 --> Helper loaded: string_helper
INFO - 2018-05-09 02:21:46 --> Database Driver Class Initialized
ERROR - 2018-05-09 02:21:46 --> Severity: error --> Exception: Call to undefined method MY_Loader::_ci_load_class() E:\xampp\htdocs\consulting\application\third_party\MX\Loader.php 158
INFO - 2018-05-09 17:48:47 --> Config Class Initialized
INFO - 2018-05-09 17:48:47 --> Hooks Class Initialized
INFO - 2018-05-09 17:48:47 --> Utf8 Class Initialized
INFO - 2018-05-09 17:48:47 --> URI Class Initialized
INFO - 2018-05-09 17:48:47 --> Router Class Initialized
INFO - 2018-05-09 17:48:47 --> Output Class Initialized
INFO - 2018-05-09 17:48:47 --> Security Class Initialized
INFO - 2018-05-09 17:48:47 --> Input Class Initialized
INFO - 2018-05-09 17:48:47 --> Language Class Initialized
INFO - 2018-05-09 17:48:47 --> Language Class Initialized
INFO - 2018-05-09 17:48:47 --> Config Class Initialized
INFO - 2018-05-09 17:48:47 --> Loader Class Initialized
INFO - 2018-05-09 17:48:47 --> Helper loaded: url_helper
INFO - 2018-05-09 17:48:47 --> Helper loaded: form_helper
INFO - 2018-05-09 17:48:47 --> Helper loaded: date_helper
INFO - 2018-05-09 17:48:47 --> Helper loaded: util_helper
INFO - 2018-05-09 17:48:47 --> Helper loaded: text_helper
INFO - 2018-05-09 17:48:47 --> Helper loaded: string_helper
INFO - 2018-05-09 17:48:47 --> Database Driver Class Initialized
ERROR - 2018-05-09 17:48:49 --> Severity: error --> Exception: Call to undefined method MY_Loader::_ci_load_class() E:\xampp\htdocs\consulting\application\third_party\MX\Loader.php 158
INFO - 2018-05-09 17:49:07 --> Config Class Initialized
INFO - 2018-05-09 17:49:07 --> Hooks Class Initialized
INFO - 2018-05-09 17:49:07 --> Utf8 Class Initialized
INFO - 2018-05-09 17:49:07 --> URI Class Initialized
INFO - 2018-05-09 17:49:07 --> Router Class Initialized
INFO - 2018-05-09 17:49:07 --> Output Class Initialized
INFO - 2018-05-09 17:49:07 --> Security Class Initialized
INFO - 2018-05-09 17:49:07 --> Input Class Initialized
INFO - 2018-05-09 17:49:07 --> Language Class Initialized
INFO - 2018-05-09 17:49:07 --> Language Class Initialized
INFO - 2018-05-09 17:49:07 --> Config Class Initialized
INFO - 2018-05-09 17:49:07 --> Loader Class Initialized
INFO - 2018-05-09 17:49:07 --> Helper loaded: url_helper
INFO - 2018-05-09 17:49:07 --> Helper loaded: form_helper
INFO - 2018-05-09 17:49:07 --> Helper loaded: date_helper
INFO - 2018-05-09 17:49:07 --> Helper loaded: util_helper
INFO - 2018-05-09 17:49:07 --> Helper loaded: text_helper
INFO - 2018-05-09 17:49:07 --> Helper loaded: string_helper
INFO - 2018-05-09 17:49:07 --> Database Driver Class Initialized
ERROR - 2018-05-09 17:49:07 --> Severity: error --> Exception: Call to undefined method MY_Loader::_ci_load_class() E:\xampp\htdocs\consulting\application\third_party\MX\Loader.php 158
INFO - 2018-05-09 17:52:46 --> Config Class Initialized
INFO - 2018-05-09 17:52:46 --> Hooks Class Initialized
INFO - 2018-05-09 17:52:46 --> Utf8 Class Initialized
INFO - 2018-05-09 17:52:46 --> URI Class Initialized
INFO - 2018-05-09 17:52:46 --> Router Class Initialized
INFO - 2018-05-09 17:52:46 --> Output Class Initialized
INFO - 2018-05-09 17:52:46 --> Security Class Initialized
INFO - 2018-05-09 17:52:47 --> Input Class Initialized
INFO - 2018-05-09 17:52:47 --> Language Class Initialized
INFO - 2018-05-09 17:52:47 --> Language Class Initialized
INFO - 2018-05-09 17:52:47 --> Config Class Initialized
INFO - 2018-05-09 17:52:47 --> Loader Class Initialized
INFO - 2018-05-09 17:52:47 --> Helper loaded: url_helper
INFO - 2018-05-09 17:52:47 --> Helper loaded: form_helper
INFO - 2018-05-09 17:52:47 --> Helper loaded: date_helper
INFO - 2018-05-09 17:52:47 --> Helper loaded: util_helper
INFO - 2018-05-09 17:52:47 --> Helper loaded: text_helper
INFO - 2018-05-09 17:52:47 --> Helper loaded: string_helper
INFO - 2018-05-09 17:52:47 --> Database Driver Class Initialized
ERROR - 2018-05-09 17:52:47 --> Severity: error --> Exception: Call to undefined method MY_Loader::_ci_load_class() E:\xampp\htdocs\consulting\application\third_party\MX\Loader.php 158
INFO - 2018-05-09 17:53:32 --> Config Class Initialized
INFO - 2018-05-09 17:53:32 --> Hooks Class Initialized
INFO - 2018-05-09 17:53:32 --> Utf8 Class Initialized
INFO - 2018-05-09 17:53:33 --> URI Class Initialized
INFO - 2018-05-09 17:53:33 --> Router Class Initialized
INFO - 2018-05-09 17:53:33 --> Output Class Initialized
INFO - 2018-05-09 17:53:33 --> Security Class Initialized
INFO - 2018-05-09 17:53:33 --> Input Class Initialized
INFO - 2018-05-09 17:53:33 --> Language Class Initialized
INFO - 2018-05-09 17:53:33 --> Language Class Initialized
INFO - 2018-05-09 17:53:33 --> Config Class Initialized
INFO - 2018-05-09 17:53:33 --> Loader Class Initialized
INFO - 2018-05-09 17:53:33 --> Helper loaded: url_helper
INFO - 2018-05-09 17:53:33 --> Helper loaded: form_helper
INFO - 2018-05-09 17:53:33 --> Helper loaded: date_helper
INFO - 2018-05-09 17:53:33 --> Helper loaded: util_helper
INFO - 2018-05-09 17:53:33 --> Helper loaded: text_helper
INFO - 2018-05-09 17:53:33 --> Helper loaded: string_helper
INFO - 2018-05-09 17:53:33 --> Database Driver Class Initialized
ERROR - 2018-05-09 17:53:33 --> Severity: error --> Exception: Call to undefined method MY_Loader::_ci_load_class() E:\xampp\htdocs\consulting\application\third_party\MX\Loader.php 158
INFO - 2018-05-09 18:07:31 --> Config Class Initialized
INFO - 2018-05-09 18:07:31 --> Hooks Class Initialized
INFO - 2018-05-09 18:07:32 --> Utf8 Class Initialized
INFO - 2018-05-09 18:07:32 --> URI Class Initialized
INFO - 2018-05-09 18:07:32 --> Router Class Initialized
INFO - 2018-05-09 18:07:32 --> Output Class Initialized
INFO - 2018-05-09 18:07:32 --> Security Class Initialized
INFO - 2018-05-09 18:07:32 --> Input Class Initialized
INFO - 2018-05-09 18:07:32 --> Language Class Initialized
INFO - 2018-05-09 18:07:32 --> Language Class Initialized
INFO - 2018-05-09 18:07:32 --> Config Class Initialized
INFO - 2018-05-09 18:07:32 --> Loader Class Initialized
INFO - 2018-05-09 18:07:32 --> Helper loaded: url_helper
INFO - 2018-05-09 18:07:32 --> Helper loaded: form_helper
INFO - 2018-05-09 18:07:32 --> Helper loaded: date_helper
INFO - 2018-05-09 18:07:32 --> Helper loaded: util_helper
INFO - 2018-05-09 18:07:32 --> Helper loaded: text_helper
INFO - 2018-05-09 18:07:32 --> Helper loaded: string_helper
INFO - 2018-05-09 18:07:32 --> Database Driver Class Initialized
ERROR - 2018-05-09 18:07:32 --> Severity: error --> Exception: Call to undefined method MY_Loader::_ci_load_class() E:\xampp\htdocs\consulting\application\third_party\MX\Loader.php 158
INFO - 2018-05-09 19:21:59 --> Config Class Initialized
INFO - 2018-05-09 19:21:59 --> Hooks Class Initialized
INFO - 2018-05-09 19:21:59 --> Utf8 Class Initialized
INFO - 2018-05-09 19:21:59 --> URI Class Initialized
INFO - 2018-05-09 19:21:59 --> Router Class Initialized
INFO - 2018-05-09 19:21:59 --> Output Class Initialized
INFO - 2018-05-09 19:21:59 --> Security Class Initialized
INFO - 2018-05-09 19:21:59 --> Input Class Initialized
INFO - 2018-05-09 19:21:59 --> Language Class Initialized
INFO - 2018-05-09 19:21:59 --> Language Class Initialized
INFO - 2018-05-09 19:21:59 --> Config Class Initialized
INFO - 2018-05-09 19:21:59 --> Loader Class Initialized
INFO - 2018-05-09 19:21:59 --> Helper loaded: url_helper
INFO - 2018-05-09 19:21:59 --> Helper loaded: form_helper
INFO - 2018-05-09 19:21:59 --> Helper loaded: date_helper
INFO - 2018-05-09 19:21:59 --> Helper loaded: util_helper
INFO - 2018-05-09 19:21:59 --> Helper loaded: text_helper
INFO - 2018-05-09 19:21:59 --> Helper loaded: string_helper
INFO - 2018-05-09 19:21:59 --> Database Driver Class Initialized
ERROR - 2018-05-09 19:21:59 --> Severity: error --> Exception: Call to undefined method MY_Loader::_ci_load_class() E:\xampp\htdocs\consulting\application\third_party\MX\Loader.php 158
INFO - 2018-05-09 19:24:47 --> Config Class Initialized
INFO - 2018-05-09 19:24:47 --> Hooks Class Initialized
INFO - 2018-05-09 19:24:47 --> Utf8 Class Initialized
INFO - 2018-05-09 19:24:47 --> URI Class Initialized
INFO - 2018-05-09 19:24:47 --> Router Class Initialized
INFO - 2018-05-09 19:24:47 --> Output Class Initialized
INFO - 2018-05-09 19:24:47 --> Security Class Initialized
INFO - 2018-05-09 19:24:47 --> Input Class Initialized
INFO - 2018-05-09 19:24:47 --> Language Class Initialized
INFO - 2018-05-09 19:24:47 --> Language Class Initialized
INFO - 2018-05-09 19:24:47 --> Config Class Initialized
INFO - 2018-05-09 19:24:47 --> Loader Class Initialized
INFO - 2018-05-09 19:24:47 --> Helper loaded: url_helper
INFO - 2018-05-09 19:24:47 --> Helper loaded: form_helper
INFO - 2018-05-09 19:24:47 --> Helper loaded: date_helper
INFO - 2018-05-09 19:24:47 --> Helper loaded: util_helper
INFO - 2018-05-09 19:24:47 --> Helper loaded: text_helper
INFO - 2018-05-09 19:24:47 --> Helper loaded: string_helper
INFO - 2018-05-09 19:24:47 --> Database Driver Class Initialized
ERROR - 2018-05-09 19:24:47 --> Severity: error --> Exception: Call to undefined method MY_Loader::_ci_load_class() E:\xampp\htdocs\consulting\application\third_party\MX\Loader.php 158
INFO - 2018-05-09 23:11:50 --> Config Class Initialized
INFO - 2018-05-09 23:11:50 --> Hooks Class Initialized
DEBUG - 2018-05-09 23:11:50 --> UTF-8 Support Enabled
INFO - 2018-05-09 23:11:50 --> Utf8 Class Initialized
INFO - 2018-05-09 23:11:50 --> URI Class Initialized
INFO - 2018-05-09 23:11:50 --> Router Class Initialized
INFO - 2018-05-09 23:11:50 --> Output Class Initialized
INFO - 2018-05-09 23:11:50 --> Security Class Initialized
DEBUG - 2018-05-09 23:11:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-09 23:11:50 --> Input Class Initialized
INFO - 2018-05-09 23:11:50 --> Language Class Initialized
INFO - 2018-05-09 23:11:50 --> Language Class Initialized
INFO - 2018-05-09 23:11:50 --> Config Class Initialized
INFO - 2018-05-09 23:11:50 --> Loader Class Initialized
DEBUG - 2018-05-09 23:11:50 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-09 23:11:50 --> Helper loaded: url_helper
INFO - 2018-05-09 23:11:50 --> Helper loaded: form_helper
INFO - 2018-05-09 23:11:50 --> Helper loaded: date_helper
INFO - 2018-05-09 23:11:50 --> Helper loaded: util_helper
INFO - 2018-05-09 23:11:50 --> Helper loaded: text_helper
INFO - 2018-05-09 23:11:50 --> Helper loaded: string_helper
INFO - 2018-05-09 23:11:50 --> Database Driver Class Initialized
ERROR - 2018-05-09 23:11:50 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'construction_bay' E:\xampp\htdocs\consulting\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2018-05-09 23:11:50 --> Unable to connect to the database
INFO - 2018-05-09 23:11:50 --> Language file loaded: language/english/db_lang.php
INFO - 2018-05-09 23:17:12 --> Config Class Initialized
INFO - 2018-05-09 23:17:12 --> Hooks Class Initialized
DEBUG - 2018-05-09 23:17:12 --> UTF-8 Support Enabled
INFO - 2018-05-09 23:17:12 --> Utf8 Class Initialized
INFO - 2018-05-09 23:17:12 --> URI Class Initialized
INFO - 2018-05-09 23:17:12 --> Router Class Initialized
INFO - 2018-05-09 23:17:12 --> Output Class Initialized
INFO - 2018-05-09 23:17:12 --> Security Class Initialized
DEBUG - 2018-05-09 23:17:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-09 23:17:12 --> Input Class Initialized
INFO - 2018-05-09 23:17:12 --> Language Class Initialized
INFO - 2018-05-09 23:17:12 --> Language Class Initialized
INFO - 2018-05-09 23:17:12 --> Config Class Initialized
INFO - 2018-05-09 23:17:12 --> Loader Class Initialized
DEBUG - 2018-05-09 23:17:12 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-09 23:17:12 --> Helper loaded: url_helper
INFO - 2018-05-09 23:17:12 --> Helper loaded: form_helper
INFO - 2018-05-09 23:17:12 --> Helper loaded: date_helper
INFO - 2018-05-09 23:17:12 --> Helper loaded: util_helper
INFO - 2018-05-09 23:17:13 --> Helper loaded: text_helper
INFO - 2018-05-09 23:17:13 --> Helper loaded: string_helper
INFO - 2018-05-09 23:17:13 --> Database Driver Class Initialized
DEBUG - 2018-05-09 23:17:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-09 23:17:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-09 23:17:13 --> Email Class Initialized
INFO - 2018-05-09 23:17:13 --> Controller Class Initialized
DEBUG - 2018-05-09 23:17:13 --> Home MX_Controller Initialized
ERROR - 2018-05-09 23:17:13 --> Query error: Table 'consulting.categories' doesn't exist - Invalid query: SELECT *
FROM `categories`
INFO - 2018-05-09 23:17:13 --> Language file loaded: language/english/db_lang.php
INFO - 2018-05-09 23:17:23 --> Config Class Initialized
INFO - 2018-05-09 23:17:23 --> Hooks Class Initialized
DEBUG - 2018-05-09 23:17:23 --> UTF-8 Support Enabled
INFO - 2018-05-09 23:17:23 --> Utf8 Class Initialized
INFO - 2018-05-09 23:17:23 --> URI Class Initialized
INFO - 2018-05-09 23:17:23 --> Router Class Initialized
INFO - 2018-05-09 23:17:23 --> Output Class Initialized
INFO - 2018-05-09 23:17:23 --> Security Class Initialized
DEBUG - 2018-05-09 23:17:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-09 23:17:23 --> Input Class Initialized
INFO - 2018-05-09 23:17:23 --> Language Class Initialized
INFO - 2018-05-09 23:17:23 --> Language Class Initialized
INFO - 2018-05-09 23:17:23 --> Config Class Initialized
INFO - 2018-05-09 23:17:23 --> Loader Class Initialized
DEBUG - 2018-05-09 23:17:23 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-09 23:17:23 --> Helper loaded: url_helper
INFO - 2018-05-09 23:17:23 --> Helper loaded: form_helper
INFO - 2018-05-09 23:17:23 --> Helper loaded: date_helper
INFO - 2018-05-09 23:17:23 --> Helper loaded: util_helper
INFO - 2018-05-09 23:17:23 --> Helper loaded: text_helper
INFO - 2018-05-09 23:17:23 --> Helper loaded: string_helper
INFO - 2018-05-09 23:17:23 --> Database Driver Class Initialized
DEBUG - 2018-05-09 23:17:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-09 23:17:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-09 23:17:23 --> Email Class Initialized
INFO - 2018-05-09 23:17:23 --> Controller Class Initialized
DEBUG - 2018-05-09 23:17:23 --> Admin MX_Controller Initialized
INFO - 2018-05-09 23:17:23 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-09 23:17:23 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-09 23:17:23 --> Login MX_Controller Initialized
DEBUG - 2018-05-09 23:17:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-09 23:17:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-09 23:17:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/logins/login.php
INFO - 2018-05-09 23:25:57 --> Config Class Initialized
INFO - 2018-05-09 23:25:57 --> Hooks Class Initialized
DEBUG - 2018-05-09 23:25:57 --> UTF-8 Support Enabled
INFO - 2018-05-09 23:25:57 --> Utf8 Class Initialized
INFO - 2018-05-09 23:25:57 --> URI Class Initialized
INFO - 2018-05-09 23:25:57 --> Router Class Initialized
INFO - 2018-05-09 23:25:57 --> Output Class Initialized
INFO - 2018-05-09 23:25:57 --> Security Class Initialized
DEBUG - 2018-05-09 23:25:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-09 23:25:57 --> Input Class Initialized
INFO - 2018-05-09 23:25:57 --> Language Class Initialized
INFO - 2018-05-09 23:25:57 --> Language Class Initialized
INFO - 2018-05-09 23:25:57 --> Config Class Initialized
INFO - 2018-05-09 23:25:57 --> Loader Class Initialized
DEBUG - 2018-05-09 23:25:57 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-09 23:25:57 --> Helper loaded: url_helper
INFO - 2018-05-09 23:25:57 --> Helper loaded: form_helper
INFO - 2018-05-09 23:25:58 --> Helper loaded: date_helper
INFO - 2018-05-09 23:25:58 --> Helper loaded: util_helper
INFO - 2018-05-09 23:25:58 --> Helper loaded: text_helper
INFO - 2018-05-09 23:25:58 --> Helper loaded: string_helper
INFO - 2018-05-09 23:25:58 --> Database Driver Class Initialized
DEBUG - 2018-05-09 23:25:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-09 23:25:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-09 23:25:58 --> Email Class Initialized
INFO - 2018-05-09 23:25:58 --> Controller Class Initialized
DEBUG - 2018-05-09 23:25:58 --> Admin MX_Controller Initialized
INFO - 2018-05-09 23:25:58 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-09 23:25:58 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-09 23:25:58 --> Login MX_Controller Initialized
DEBUG - 2018-05-09 23:25:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-09 23:25:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-09 23:25:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/logins/login.php
INFO - 2018-05-09 23:26:24 --> Config Class Initialized
INFO - 2018-05-09 23:26:24 --> Hooks Class Initialized
DEBUG - 2018-05-09 23:26:24 --> UTF-8 Support Enabled
INFO - 2018-05-09 23:26:24 --> Utf8 Class Initialized
INFO - 2018-05-09 23:26:24 --> URI Class Initialized
INFO - 2018-05-09 23:26:24 --> Router Class Initialized
INFO - 2018-05-09 23:26:24 --> Output Class Initialized
INFO - 2018-05-09 23:26:24 --> Security Class Initialized
DEBUG - 2018-05-09 23:26:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-09 23:26:24 --> Input Class Initialized
INFO - 2018-05-09 23:26:24 --> Language Class Initialized
INFO - 2018-05-09 23:26:24 --> Language Class Initialized
INFO - 2018-05-09 23:26:24 --> Config Class Initialized
INFO - 2018-05-09 23:26:24 --> Loader Class Initialized
DEBUG - 2018-05-09 23:26:24 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-09 23:26:24 --> Helper loaded: url_helper
INFO - 2018-05-09 23:26:24 --> Helper loaded: form_helper
INFO - 2018-05-09 23:26:24 --> Helper loaded: date_helper
INFO - 2018-05-09 23:26:24 --> Helper loaded: util_helper
INFO - 2018-05-09 23:26:24 --> Helper loaded: text_helper
INFO - 2018-05-09 23:26:24 --> Helper loaded: string_helper
INFO - 2018-05-09 23:26:24 --> Database Driver Class Initialized
DEBUG - 2018-05-09 23:26:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-09 23:26:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-09 23:26:24 --> Email Class Initialized
INFO - 2018-05-09 23:26:24 --> Controller Class Initialized
DEBUG - 2018-05-09 23:26:24 --> Admin MX_Controller Initialized
INFO - 2018-05-09 23:26:24 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-09 23:26:24 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-09 23:26:24 --> Login MX_Controller Initialized
DEBUG - 2018-05-09 23:26:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-09 23:26:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-09 23:26:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/logins/login.php
INFO - 2018-05-09 23:26:50 --> Config Class Initialized
INFO - 2018-05-09 23:26:50 --> Hooks Class Initialized
DEBUG - 2018-05-09 23:26:50 --> UTF-8 Support Enabled
INFO - 2018-05-09 23:26:50 --> Utf8 Class Initialized
INFO - 2018-05-09 23:26:50 --> URI Class Initialized
INFO - 2018-05-09 23:26:50 --> Router Class Initialized
INFO - 2018-05-09 23:26:50 --> Output Class Initialized
INFO - 2018-05-09 23:26:50 --> Security Class Initialized
DEBUG - 2018-05-09 23:26:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-09 23:26:50 --> Input Class Initialized
INFO - 2018-05-09 23:26:50 --> Language Class Initialized
INFO - 2018-05-09 23:26:50 --> Language Class Initialized
INFO - 2018-05-09 23:26:50 --> Config Class Initialized
INFO - 2018-05-09 23:26:50 --> Loader Class Initialized
DEBUG - 2018-05-09 23:26:50 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-09 23:26:50 --> Helper loaded: url_helper
INFO - 2018-05-09 23:26:50 --> Helper loaded: form_helper
INFO - 2018-05-09 23:26:50 --> Helper loaded: date_helper
INFO - 2018-05-09 23:26:50 --> Helper loaded: util_helper
INFO - 2018-05-09 23:26:50 --> Helper loaded: text_helper
INFO - 2018-05-09 23:26:50 --> Helper loaded: string_helper
INFO - 2018-05-09 23:26:50 --> Database Driver Class Initialized
DEBUG - 2018-05-09 23:26:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-09 23:26:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-09 23:26:50 --> Email Class Initialized
INFO - 2018-05-09 23:26:50 --> Controller Class Initialized
DEBUG - 2018-05-09 23:26:50 --> Admin MX_Controller Initialized
INFO - 2018-05-09 23:26:50 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-09 23:26:50 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-09 23:26:50 --> Login MX_Controller Initialized
DEBUG - 2018-05-09 23:26:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-09 23:26:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-09 23:26:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/logins/login.php
INFO - 2018-05-09 23:27:03 --> Config Class Initialized
INFO - 2018-05-09 23:27:03 --> Hooks Class Initialized
DEBUG - 2018-05-09 23:27:03 --> UTF-8 Support Enabled
INFO - 2018-05-09 23:27:03 --> Utf8 Class Initialized
INFO - 2018-05-09 23:27:03 --> URI Class Initialized
INFO - 2018-05-09 23:27:03 --> Router Class Initialized
INFO - 2018-05-09 23:27:04 --> Output Class Initialized
INFO - 2018-05-09 23:27:04 --> Security Class Initialized
DEBUG - 2018-05-09 23:27:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-09 23:27:04 --> Input Class Initialized
INFO - 2018-05-09 23:27:04 --> Language Class Initialized
INFO - 2018-05-09 23:27:04 --> Language Class Initialized
INFO - 2018-05-09 23:27:04 --> Config Class Initialized
INFO - 2018-05-09 23:27:04 --> Loader Class Initialized
DEBUG - 2018-05-09 23:27:04 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-09 23:27:04 --> Helper loaded: url_helper
INFO - 2018-05-09 23:27:04 --> Helper loaded: form_helper
INFO - 2018-05-09 23:27:04 --> Helper loaded: date_helper
INFO - 2018-05-09 23:27:04 --> Helper loaded: util_helper
INFO - 2018-05-09 23:27:04 --> Helper loaded: text_helper
INFO - 2018-05-09 23:27:04 --> Helper loaded: string_helper
INFO - 2018-05-09 23:27:04 --> Database Driver Class Initialized
DEBUG - 2018-05-09 23:27:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-09 23:27:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-09 23:27:04 --> Email Class Initialized
INFO - 2018-05-09 23:27:04 --> Controller Class Initialized
DEBUG - 2018-05-09 23:27:04 --> Admin MX_Controller Initialized
INFO - 2018-05-09 23:27:04 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-09 23:27:04 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-09 23:27:04 --> Login MX_Controller Initialized
DEBUG - 2018-05-09 23:27:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-09 23:27:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-09 23:27:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/logins/login.php
INFO - 2018-05-09 23:28:00 --> Config Class Initialized
INFO - 2018-05-09 23:28:00 --> Hooks Class Initialized
DEBUG - 2018-05-09 23:28:00 --> UTF-8 Support Enabled
INFO - 2018-05-09 23:28:00 --> Utf8 Class Initialized
INFO - 2018-05-09 23:28:00 --> URI Class Initialized
INFO - 2018-05-09 23:28:00 --> Router Class Initialized
INFO - 2018-05-09 23:28:00 --> Output Class Initialized
INFO - 2018-05-09 23:28:00 --> Security Class Initialized
DEBUG - 2018-05-09 23:28:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-09 23:28:00 --> Input Class Initialized
INFO - 2018-05-09 23:28:00 --> Language Class Initialized
INFO - 2018-05-09 23:28:00 --> Language Class Initialized
INFO - 2018-05-09 23:28:00 --> Config Class Initialized
INFO - 2018-05-09 23:28:00 --> Loader Class Initialized
DEBUG - 2018-05-09 23:28:00 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-09 23:28:00 --> Helper loaded: url_helper
INFO - 2018-05-09 23:28:00 --> Helper loaded: form_helper
INFO - 2018-05-09 23:28:00 --> Helper loaded: date_helper
INFO - 2018-05-09 23:28:00 --> Helper loaded: util_helper
INFO - 2018-05-09 23:28:00 --> Helper loaded: text_helper
INFO - 2018-05-09 23:28:00 --> Helper loaded: string_helper
INFO - 2018-05-09 23:28:00 --> Database Driver Class Initialized
DEBUG - 2018-05-09 23:28:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-09 23:28:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-09 23:28:00 --> Email Class Initialized
INFO - 2018-05-09 23:28:00 --> Controller Class Initialized
DEBUG - 2018-05-09 23:28:00 --> Login MX_Controller Initialized
INFO - 2018-05-09 23:28:00 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-09 23:28:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-09 23:28:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
ERROR - 2018-05-09 23:28:00 --> Query error: Table 'consulting.categories' doesn't exist - Invalid query: SELECT *
FROM `categories`
INFO - 2018-05-09 23:28:00 --> Language file loaded: language/english/db_lang.php
INFO - 2018-05-09 23:29:41 --> Config Class Initialized
INFO - 2018-05-09 23:29:41 --> Hooks Class Initialized
DEBUG - 2018-05-09 23:29:41 --> UTF-8 Support Enabled
INFO - 2018-05-09 23:29:41 --> Utf8 Class Initialized
INFO - 2018-05-09 23:29:41 --> URI Class Initialized
INFO - 2018-05-09 23:29:41 --> Router Class Initialized
INFO - 2018-05-09 23:29:41 --> Output Class Initialized
INFO - 2018-05-09 23:29:41 --> Security Class Initialized
DEBUG - 2018-05-09 23:29:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-09 23:29:41 --> Input Class Initialized
INFO - 2018-05-09 23:29:41 --> Language Class Initialized
INFO - 2018-05-09 23:29:41 --> Language Class Initialized
INFO - 2018-05-09 23:29:41 --> Config Class Initialized
INFO - 2018-05-09 23:29:41 --> Loader Class Initialized
DEBUG - 2018-05-09 23:29:41 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-09 23:29:41 --> Helper loaded: url_helper
INFO - 2018-05-09 23:29:41 --> Helper loaded: form_helper
INFO - 2018-05-09 23:29:41 --> Helper loaded: date_helper
INFO - 2018-05-09 23:29:41 --> Helper loaded: util_helper
INFO - 2018-05-09 23:29:41 --> Helper loaded: text_helper
INFO - 2018-05-09 23:29:42 --> Helper loaded: string_helper
INFO - 2018-05-09 23:29:42 --> Database Driver Class Initialized
DEBUG - 2018-05-09 23:29:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-09 23:29:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-09 23:29:42 --> Email Class Initialized
INFO - 2018-05-09 23:29:42 --> Controller Class Initialized
DEBUG - 2018-05-09 23:29:42 --> Admin MX_Controller Initialized
INFO - 2018-05-09 23:29:42 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-09 23:29:42 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-09 23:29:42 --> Login MX_Controller Initialized
DEBUG - 2018-05-09 23:29:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-09 23:29:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-09 23:29:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/logins/login.php
INFO - 2018-05-09 23:29:42 --> Config Class Initialized
INFO - 2018-05-09 23:29:42 --> Hooks Class Initialized
DEBUG - 2018-05-09 23:29:42 --> UTF-8 Support Enabled
INFO - 2018-05-09 23:29:42 --> Utf8 Class Initialized
INFO - 2018-05-09 23:29:42 --> URI Class Initialized
INFO - 2018-05-09 23:29:42 --> Router Class Initialized
INFO - 2018-05-09 23:29:42 --> Output Class Initialized
INFO - 2018-05-09 23:29:42 --> Security Class Initialized
DEBUG - 2018-05-09 23:29:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-09 23:29:42 --> Input Class Initialized
INFO - 2018-05-09 23:29:42 --> Language Class Initialized
ERROR - 2018-05-09 23:29:42 --> 404 Page Not Found: /index
INFO - 2018-05-09 23:29:42 --> Config Class Initialized
INFO - 2018-05-09 23:29:42 --> Hooks Class Initialized
DEBUG - 2018-05-09 23:29:42 --> UTF-8 Support Enabled
INFO - 2018-05-09 23:29:42 --> Utf8 Class Initialized
INFO - 2018-05-09 23:29:42 --> URI Class Initialized
INFO - 2018-05-09 23:29:42 --> Router Class Initialized
INFO - 2018-05-09 23:29:42 --> Output Class Initialized
INFO - 2018-05-09 23:29:42 --> Security Class Initialized
DEBUG - 2018-05-09 23:29:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-09 23:29:42 --> Input Class Initialized
INFO - 2018-05-09 23:29:42 --> Language Class Initialized
ERROR - 2018-05-09 23:29:42 --> 404 Page Not Found: /index
INFO - 2018-05-09 23:41:18 --> Config Class Initialized
INFO - 2018-05-09 23:41:18 --> Hooks Class Initialized
DEBUG - 2018-05-09 23:41:19 --> UTF-8 Support Enabled
INFO - 2018-05-09 23:41:19 --> Utf8 Class Initialized
INFO - 2018-05-09 23:41:19 --> URI Class Initialized
INFO - 2018-05-09 23:41:19 --> Router Class Initialized
INFO - 2018-05-09 23:41:19 --> Output Class Initialized
INFO - 2018-05-09 23:41:19 --> Security Class Initialized
DEBUG - 2018-05-09 23:41:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-09 23:41:19 --> Input Class Initialized
INFO - 2018-05-09 23:41:19 --> Language Class Initialized
ERROR - 2018-05-09 23:41:19 --> 404 Page Not Found: /index
INFO - 2018-05-09 23:41:30 --> Config Class Initialized
INFO - 2018-05-09 23:41:30 --> Hooks Class Initialized
DEBUG - 2018-05-09 23:41:30 --> UTF-8 Support Enabled
INFO - 2018-05-09 23:41:30 --> Utf8 Class Initialized
INFO - 2018-05-09 23:41:30 --> URI Class Initialized
INFO - 2018-05-09 23:41:30 --> Router Class Initialized
INFO - 2018-05-09 23:41:30 --> Output Class Initialized
INFO - 2018-05-09 23:41:30 --> Security Class Initialized
DEBUG - 2018-05-09 23:41:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-09 23:41:30 --> Input Class Initialized
INFO - 2018-05-09 23:41:30 --> Language Class Initialized
INFO - 2018-05-09 23:41:30 --> Language Class Initialized
INFO - 2018-05-09 23:41:30 --> Config Class Initialized
INFO - 2018-05-09 23:41:30 --> Loader Class Initialized
DEBUG - 2018-05-09 23:41:30 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-09 23:41:30 --> Helper loaded: url_helper
INFO - 2018-05-09 23:41:30 --> Helper loaded: form_helper
INFO - 2018-05-09 23:41:30 --> Helper loaded: date_helper
INFO - 2018-05-09 23:41:30 --> Helper loaded: util_helper
INFO - 2018-05-09 23:41:30 --> Helper loaded: text_helper
INFO - 2018-05-09 23:41:30 --> Helper loaded: string_helper
INFO - 2018-05-09 23:41:30 --> Database Driver Class Initialized
DEBUG - 2018-05-09 23:41:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-09 23:41:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-09 23:41:30 --> Email Class Initialized
INFO - 2018-05-09 23:41:30 --> Controller Class Initialized
DEBUG - 2018-05-09 23:41:30 --> Admin MX_Controller Initialized
INFO - 2018-05-09 23:41:30 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-09 23:41:31 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-09 23:41:31 --> Login MX_Controller Initialized
DEBUG - 2018-05-09 23:41:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-09 23:41:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-09 23:41:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/logins/login.php
INFO - 2018-05-09 23:41:31 --> Config Class Initialized
INFO - 2018-05-09 23:41:31 --> Hooks Class Initialized
DEBUG - 2018-05-09 23:41:31 --> UTF-8 Support Enabled
INFO - 2018-05-09 23:41:31 --> Utf8 Class Initialized
INFO - 2018-05-09 23:41:31 --> URI Class Initialized
INFO - 2018-05-09 23:41:31 --> Router Class Initialized
INFO - 2018-05-09 23:41:31 --> Output Class Initialized
INFO - 2018-05-09 23:41:31 --> Security Class Initialized
DEBUG - 2018-05-09 23:41:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-09 23:41:31 --> Input Class Initialized
INFO - 2018-05-09 23:41:31 --> Language Class Initialized
ERROR - 2018-05-09 23:41:31 --> 404 Page Not Found: /index
INFO - 2018-05-09 23:44:31 --> Config Class Initialized
INFO - 2018-05-09 23:44:31 --> Hooks Class Initialized
DEBUG - 2018-05-09 23:44:31 --> UTF-8 Support Enabled
INFO - 2018-05-09 23:44:31 --> Utf8 Class Initialized
INFO - 2018-05-09 23:44:31 --> URI Class Initialized
INFO - 2018-05-09 23:44:31 --> Router Class Initialized
INFO - 2018-05-09 23:44:31 --> Output Class Initialized
INFO - 2018-05-09 23:44:31 --> Security Class Initialized
DEBUG - 2018-05-09 23:44:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-09 23:44:31 --> Input Class Initialized
INFO - 2018-05-09 23:44:31 --> Language Class Initialized
INFO - 2018-05-09 23:44:31 --> Language Class Initialized
INFO - 2018-05-09 23:44:31 --> Config Class Initialized
INFO - 2018-05-09 23:44:31 --> Loader Class Initialized
DEBUG - 2018-05-09 23:44:31 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-09 23:44:31 --> Helper loaded: url_helper
INFO - 2018-05-09 23:44:31 --> Helper loaded: form_helper
INFO - 2018-05-09 23:44:31 --> Helper loaded: date_helper
INFO - 2018-05-09 23:44:31 --> Helper loaded: util_helper
INFO - 2018-05-09 23:44:31 --> Helper loaded: text_helper
INFO - 2018-05-09 23:44:31 --> Helper loaded: string_helper
INFO - 2018-05-09 23:44:31 --> Database Driver Class Initialized
DEBUG - 2018-05-09 23:44:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-09 23:44:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-09 23:44:31 --> Email Class Initialized
INFO - 2018-05-09 23:44:31 --> Controller Class Initialized
DEBUG - 2018-05-09 23:44:31 --> Login MX_Controller Initialized
INFO - 2018-05-09 23:44:31 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-09 23:44:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-09 23:44:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-09 23:44:31 --> Email starts for admin@consulting.com fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-05-09 23:44:31 --> User session created for 1
INFO - 2018-05-09 23:44:31 --> Login status admin@consulting.com - success
INFO - 2018-05-09 23:44:31 --> Final output sent to browser
DEBUG - 2018-05-09 23:44:31 --> Total execution time: 0.4462
INFO - 2018-05-09 23:44:31 --> Config Class Initialized
INFO - 2018-05-09 23:44:31 --> Hooks Class Initialized
DEBUG - 2018-05-09 23:44:31 --> UTF-8 Support Enabled
INFO - 2018-05-09 23:44:31 --> Utf8 Class Initialized
INFO - 2018-05-09 23:44:31 --> URI Class Initialized
INFO - 2018-05-09 23:44:31 --> Router Class Initialized
INFO - 2018-05-09 23:44:31 --> Output Class Initialized
INFO - 2018-05-09 23:44:31 --> Security Class Initialized
DEBUG - 2018-05-09 23:44:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-09 23:44:32 --> Input Class Initialized
INFO - 2018-05-09 23:44:32 --> Language Class Initialized
INFO - 2018-05-09 23:44:32 --> Language Class Initialized
INFO - 2018-05-09 23:44:32 --> Config Class Initialized
INFO - 2018-05-09 23:44:32 --> Loader Class Initialized
DEBUG - 2018-05-09 23:44:32 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-09 23:44:32 --> Helper loaded: url_helper
INFO - 2018-05-09 23:44:32 --> Helper loaded: form_helper
INFO - 2018-05-09 23:44:32 --> Helper loaded: date_helper
INFO - 2018-05-09 23:44:32 --> Helper loaded: util_helper
INFO - 2018-05-09 23:44:32 --> Helper loaded: text_helper
INFO - 2018-05-09 23:44:32 --> Helper loaded: string_helper
INFO - 2018-05-09 23:44:32 --> Database Driver Class Initialized
DEBUG - 2018-05-09 23:44:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-09 23:44:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-09 23:44:32 --> Email Class Initialized
INFO - 2018-05-09 23:44:32 --> Controller Class Initialized
DEBUG - 2018-05-09 23:44:32 --> Admin MX_Controller Initialized
INFO - 2018-05-09 23:44:32 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-09 23:44:32 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-09 23:44:32 --> Login MX_Controller Initialized
DEBUG - 2018-05-09 23:44:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-09 23:44:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-09 23:44:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-05-09 23:44:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-05-09 23:44:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-05-09 23:44:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-05-09 23:44:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-05-09 23:44:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/dashboard.php
INFO - 2018-05-09 23:44:32 --> Final output sent to browser
DEBUG - 2018-05-09 23:44:32 --> Total execution time: 0.4070
INFO - 2018-05-09 23:44:32 --> Config Class Initialized
INFO - 2018-05-09 23:44:32 --> Hooks Class Initialized
DEBUG - 2018-05-09 23:44:32 --> UTF-8 Support Enabled
INFO - 2018-05-09 23:44:32 --> Utf8 Class Initialized
INFO - 2018-05-09 23:44:32 --> URI Class Initialized
INFO - 2018-05-09 23:44:32 --> Router Class Initialized
INFO - 2018-05-09 23:44:32 --> Output Class Initialized
INFO - 2018-05-09 23:44:32 --> Security Class Initialized
DEBUG - 2018-05-09 23:44:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-09 23:44:33 --> Input Class Initialized
INFO - 2018-05-09 23:44:33 --> Language Class Initialized
ERROR - 2018-05-09 23:44:33 --> 404 Page Not Found: /index
INFO - 2018-05-09 23:44:33 --> Config Class Initialized
INFO - 2018-05-09 23:44:33 --> Hooks Class Initialized
DEBUG - 2018-05-09 23:44:33 --> UTF-8 Support Enabled
INFO - 2018-05-09 23:44:33 --> Utf8 Class Initialized
INFO - 2018-05-09 23:44:33 --> Config Class Initialized
INFO - 2018-05-09 23:44:33 --> URI Class Initialized
INFO - 2018-05-09 23:44:33 --> Hooks Class Initialized
DEBUG - 2018-05-09 23:44:33 --> UTF-8 Support Enabled
INFO - 2018-05-09 23:44:33 --> Utf8 Class Initialized
INFO - 2018-05-09 23:44:33 --> Config Class Initialized
INFO - 2018-05-09 23:44:33 --> Router Class Initialized
INFO - 2018-05-09 23:44:33 --> Hooks Class Initialized
INFO - 2018-05-09 23:44:33 --> URI Class Initialized
INFO - 2018-05-09 23:44:33 --> Output Class Initialized
INFO - 2018-05-09 23:44:33 --> Security Class Initialized
INFO - 2018-05-09 23:44:33 --> Router Class Initialized
DEBUG - 2018-05-09 23:44:33 --> UTF-8 Support Enabled
DEBUG - 2018-05-09 23:44:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-09 23:44:34 --> Input Class Initialized
INFO - 2018-05-09 23:44:34 --> Language Class Initialized
ERROR - 2018-05-09 23:44:34 --> 404 Page Not Found: /index
INFO - 2018-05-09 23:44:34 --> Utf8 Class Initialized
INFO - 2018-05-09 23:44:34 --> URI Class Initialized
INFO - 2018-05-09 23:44:34 --> Output Class Initialized
INFO - 2018-05-09 23:44:34 --> Router Class Initialized
INFO - 2018-05-09 23:44:34 --> Security Class Initialized
INFO - 2018-05-09 23:44:34 --> Output Class Initialized
DEBUG - 2018-05-09 23:44:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-09 23:44:34 --> Security Class Initialized
INFO - 2018-05-09 23:44:34 --> Input Class Initialized
INFO - 2018-05-09 23:44:34 --> Language Class Initialized
DEBUG - 2018-05-09 23:44:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-09 23:44:34 --> Input Class Initialized
ERROR - 2018-05-09 23:44:34 --> 404 Page Not Found: /index
INFO - 2018-05-09 23:44:34 --> Language Class Initialized
ERROR - 2018-05-09 23:44:34 --> 404 Page Not Found: /index
INFO - 2018-05-09 23:44:47 --> Config Class Initialized
INFO - 2018-05-09 23:44:47 --> Hooks Class Initialized
DEBUG - 2018-05-09 23:44:47 --> UTF-8 Support Enabled
INFO - 2018-05-09 23:44:47 --> Utf8 Class Initialized
INFO - 2018-05-09 23:44:47 --> URI Class Initialized
INFO - 2018-05-09 23:44:47 --> Router Class Initialized
INFO - 2018-05-09 23:44:47 --> Output Class Initialized
INFO - 2018-05-09 23:44:47 --> Security Class Initialized
DEBUG - 2018-05-09 23:44:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-09 23:44:47 --> Input Class Initialized
INFO - 2018-05-09 23:44:47 --> Language Class Initialized
ERROR - 2018-05-09 23:44:48 --> 404 Page Not Found: /index
INFO - 2018-05-09 23:46:08 --> Config Class Initialized
INFO - 2018-05-09 23:46:08 --> Hooks Class Initialized
DEBUG - 2018-05-09 23:46:08 --> UTF-8 Support Enabled
INFO - 2018-05-09 23:46:08 --> Utf8 Class Initialized
INFO - 2018-05-09 23:46:08 --> URI Class Initialized
INFO - 2018-05-09 23:46:08 --> Router Class Initialized
INFO - 2018-05-09 23:46:08 --> Output Class Initialized
INFO - 2018-05-09 23:46:08 --> Security Class Initialized
DEBUG - 2018-05-09 23:46:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-09 23:46:08 --> Input Class Initialized
INFO - 2018-05-09 23:46:08 --> Language Class Initialized
INFO - 2018-05-09 23:46:08 --> Language Class Initialized
INFO - 2018-05-09 23:46:08 --> Config Class Initialized
INFO - 2018-05-09 23:46:08 --> Loader Class Initialized
DEBUG - 2018-05-09 23:46:08 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-09 23:46:08 --> Helper loaded: url_helper
INFO - 2018-05-09 23:46:08 --> Helper loaded: form_helper
INFO - 2018-05-09 23:46:08 --> Helper loaded: date_helper
INFO - 2018-05-09 23:46:08 --> Helper loaded: util_helper
INFO - 2018-05-09 23:46:08 --> Helper loaded: text_helper
INFO - 2018-05-09 23:46:08 --> Helper loaded: string_helper
INFO - 2018-05-09 23:46:08 --> Database Driver Class Initialized
DEBUG - 2018-05-09 23:46:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-09 23:46:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-09 23:46:08 --> Email Class Initialized
INFO - 2018-05-09 23:46:08 --> Controller Class Initialized
DEBUG - 2018-05-09 23:46:08 --> Admin MX_Controller Initialized
INFO - 2018-05-09 23:46:08 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-09 23:46:08 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-09 23:46:08 --> Login MX_Controller Initialized
DEBUG - 2018-05-09 23:46:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-09 23:46:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-09 23:46:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-05-09 23:46:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-05-09 23:46:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-05-09 23:46:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-05-09 23:46:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-05-09 23:46:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/dashboard.php
INFO - 2018-05-09 23:46:08 --> Final output sent to browser
DEBUG - 2018-05-09 23:46:08 --> Total execution time: 0.3920
INFO - 2018-05-09 23:46:08 --> Config Class Initialized
INFO - 2018-05-09 23:46:09 --> Hooks Class Initialized
DEBUG - 2018-05-09 23:46:09 --> UTF-8 Support Enabled
INFO - 2018-05-09 23:46:09 --> Utf8 Class Initialized
INFO - 2018-05-09 23:46:09 --> URI Class Initialized
INFO - 2018-05-09 23:46:09 --> Router Class Initialized
INFO - 2018-05-09 23:46:09 --> Output Class Initialized
INFO - 2018-05-09 23:46:09 --> Security Class Initialized
DEBUG - 2018-05-09 23:46:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-09 23:46:09 --> Input Class Initialized
INFO - 2018-05-09 23:46:09 --> Language Class Initialized
ERROR - 2018-05-09 23:46:09 --> 404 Page Not Found: /index
INFO - 2018-05-09 23:46:09 --> Config Class Initialized
INFO - 2018-05-09 23:46:09 --> Hooks Class Initialized
DEBUG - 2018-05-09 23:46:09 --> UTF-8 Support Enabled
INFO - 2018-05-09 23:46:09 --> Utf8 Class Initialized
INFO - 2018-05-09 23:46:09 --> Config Class Initialized
INFO - 2018-05-09 23:46:09 --> Hooks Class Initialized
INFO - 2018-05-09 23:46:09 --> URI Class Initialized
DEBUG - 2018-05-09 23:46:09 --> UTF-8 Support Enabled
INFO - 2018-05-09 23:46:09 --> Utf8 Class Initialized
INFO - 2018-05-09 23:46:09 --> URI Class Initialized
INFO - 2018-05-09 23:46:09 --> Router Class Initialized
INFO - 2018-05-09 23:46:09 --> Output Class Initialized
INFO - 2018-05-09 23:46:09 --> Security Class Initialized
DEBUG - 2018-05-09 23:46:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-09 23:46:09 --> Input Class Initialized
INFO - 2018-05-09 23:46:09 --> Router Class Initialized
INFO - 2018-05-09 23:46:09 --> Language Class Initialized
ERROR - 2018-05-09 23:46:09 --> 404 Page Not Found: /index
INFO - 2018-05-09 23:46:09 --> Output Class Initialized
INFO - 2018-05-09 23:46:09 --> Security Class Initialized
DEBUG - 2018-05-09 23:46:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-09 23:46:09 --> Input Class Initialized
INFO - 2018-05-09 23:46:09 --> Language Class Initialized
ERROR - 2018-05-09 23:46:09 --> 404 Page Not Found: /index
INFO - 2018-05-09 23:46:10 --> Config Class Initialized
INFO - 2018-05-09 23:46:10 --> Hooks Class Initialized
DEBUG - 2018-05-09 23:46:10 --> UTF-8 Support Enabled
INFO - 2018-05-09 23:46:10 --> Utf8 Class Initialized
INFO - 2018-05-09 23:46:10 --> URI Class Initialized
INFO - 2018-05-09 23:46:10 --> Router Class Initialized
INFO - 2018-05-09 23:46:10 --> Output Class Initialized
INFO - 2018-05-09 23:46:10 --> Security Class Initialized
DEBUG - 2018-05-09 23:46:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-09 23:46:10 --> Input Class Initialized
INFO - 2018-05-09 23:46:10 --> Language Class Initialized
ERROR - 2018-05-09 23:46:10 --> 404 Page Not Found: /index
INFO - 2018-05-09 23:46:26 --> Config Class Initialized
INFO - 2018-05-09 23:46:26 --> Hooks Class Initialized
DEBUG - 2018-05-09 23:46:26 --> UTF-8 Support Enabled
INFO - 2018-05-09 23:46:26 --> Utf8 Class Initialized
INFO - 2018-05-09 23:46:26 --> URI Class Initialized
INFO - 2018-05-09 23:46:26 --> Router Class Initialized
INFO - 2018-05-09 23:46:26 --> Output Class Initialized
INFO - 2018-05-09 23:46:26 --> Security Class Initialized
DEBUG - 2018-05-09 23:46:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-09 23:46:26 --> Input Class Initialized
INFO - 2018-05-09 23:46:26 --> Language Class Initialized
INFO - 2018-05-09 23:46:27 --> Language Class Initialized
INFO - 2018-05-09 23:46:27 --> Config Class Initialized
INFO - 2018-05-09 23:46:27 --> Loader Class Initialized
DEBUG - 2018-05-09 23:46:27 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-09 23:46:27 --> Helper loaded: url_helper
INFO - 2018-05-09 23:46:27 --> Helper loaded: form_helper
INFO - 2018-05-09 23:46:27 --> Helper loaded: date_helper
INFO - 2018-05-09 23:46:27 --> Helper loaded: util_helper
INFO - 2018-05-09 23:46:27 --> Helper loaded: text_helper
INFO - 2018-05-09 23:46:27 --> Helper loaded: string_helper
INFO - 2018-05-09 23:46:27 --> Database Driver Class Initialized
DEBUG - 2018-05-09 23:46:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-09 23:46:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-09 23:46:27 --> Email Class Initialized
INFO - 2018-05-09 23:46:27 --> Controller Class Initialized
DEBUG - 2018-05-09 23:46:27 --> Profile MX_Controller Initialized
INFO - 2018-05-09 23:46:27 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-09 23:46:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-09 23:46:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Profile_model.php
DEBUG - 2018-05-09 23:46:27 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-09 23:46:27 --> Login MX_Controller Initialized
DEBUG - 2018-05-09 23:46:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
ERROR - 2018-05-09 23:46:27 --> Severity: Warning --> Illegal string offset 'c_id' E:\xampp\htdocs\consulting\application\modules\admin\controllers\Profile.php 23
ERROR - 2018-05-09 23:46:27 --> Severity: Warning --> Illegal string offset 'c_name' E:\xampp\htdocs\consulting\application\modules\admin\controllers\Profile.php 23
ERROR - 2018-05-09 23:46:27 --> Severity: Warning --> Illegal string offset 'c_id' E:\xampp\htdocs\consulting\application\modules\admin\controllers\Profile.php 23
ERROR - 2018-05-09 23:46:27 --> Severity: Warning --> Illegal string offset 'c_name' E:\xampp\htdocs\consulting\application\modules\admin\controllers\Profile.php 23
ERROR - 2018-05-09 23:46:27 --> Severity: Warning --> Illegal string offset 'c_id' E:\xampp\htdocs\consulting\application\modules\admin\controllers\Profile.php 23
ERROR - 2018-05-09 23:46:27 --> Severity: Warning --> Illegal string offset 'c_name' E:\xampp\htdocs\consulting\application\modules\admin\controllers\Profile.php 23
ERROR - 2018-05-09 23:46:27 --> Severity: Warning --> Illegal string offset 'c_id' E:\xampp\htdocs\consulting\application\modules\admin\controllers\Profile.php 23
ERROR - 2018-05-09 23:46:27 --> Severity: Warning --> Illegal string offset 'c_name' E:\xampp\htdocs\consulting\application\modules\admin\controllers\Profile.php 23
ERROR - 2018-05-09 23:46:27 --> Severity: Warning --> Illegal string offset 'c_id' E:\xampp\htdocs\consulting\application\modules\admin\controllers\Profile.php 23
ERROR - 2018-05-09 23:46:27 --> Severity: Warning --> Illegal string offset 'c_name' E:\xampp\htdocs\consulting\application\modules\admin\controllers\Profile.php 23
ERROR - 2018-05-09 23:46:27 --> Severity: Warning --> Illegal string offset 'c_id' E:\xampp\htdocs\consulting\application\modules\admin\controllers\Profile.php 23
ERROR - 2018-05-09 23:46:27 --> Severity: Warning --> Illegal string offset 'c_name' E:\xampp\htdocs\consulting\application\modules\admin\controllers\Profile.php 23
ERROR - 2018-05-09 23:46:27 --> Severity: Warning --> Illegal string offset 'c_id' E:\xampp\htdocs\consulting\application\modules\admin\controllers\Profile.php 23
ERROR - 2018-05-09 23:46:27 --> Severity: Warning --> Illegal string offset 'c_name' E:\xampp\htdocs\consulting\application\modules\admin\controllers\Profile.php 23
ERROR - 2018-05-09 23:46:27 --> Severity: Warning --> Illegal string offset 'c_id' E:\xampp\htdocs\consulting\application\modules\admin\controllers\Profile.php 23
ERROR - 2018-05-09 23:46:27 --> Severity: Warning --> Illegal string offset 'c_name' E:\xampp\htdocs\consulting\application\modules\admin\controllers\Profile.php 23
ERROR - 2018-05-09 23:46:27 --> Severity: Warning --> Illegal string offset 'c_id' E:\xampp\htdocs\consulting\application\modules\admin\controllers\Profile.php 23
ERROR - 2018-05-09 23:46:27 --> Severity: Warning --> Illegal string offset 'c_name' E:\xampp\htdocs\consulting\application\modules\admin\controllers\Profile.php 23
ERROR - 2018-05-09 23:46:27 --> Severity: Warning --> Illegal string offset 'c_id' E:\xampp\htdocs\consulting\application\modules\admin\controllers\Profile.php 23
ERROR - 2018-05-09 23:46:27 --> Severity: Warning --> Illegal string offset 'c_name' E:\xampp\htdocs\consulting\application\modules\admin\controllers\Profile.php 23
ERROR - 2018-05-09 23:46:27 --> Severity: Warning --> Illegal string offset 'c_id' E:\xampp\htdocs\consulting\application\modules\admin\controllers\Profile.php 23
ERROR - 2018-05-09 23:46:27 --> Severity: Warning --> Illegal string offset 'c_name' E:\xampp\htdocs\consulting\application\modules\admin\controllers\Profile.php 23
ERROR - 2018-05-09 23:46:27 --> Severity: Warning --> Illegal string offset 'c_id' E:\xampp\htdocs\consulting\application\modules\admin\controllers\Profile.php 23
ERROR - 2018-05-09 23:46:27 --> Severity: Warning --> Illegal string offset 'c_name' E:\xampp\htdocs\consulting\application\modules\admin\controllers\Profile.php 23
ERROR - 2018-05-09 23:46:27 --> Severity: Warning --> Illegal string offset 'c_id' E:\xampp\htdocs\consulting\application\modules\admin\controllers\Profile.php 23
ERROR - 2018-05-09 23:46:27 --> Severity: Warning --> Illegal string offset 'c_name' E:\xampp\htdocs\consulting\application\modules\admin\controllers\Profile.php 23
ERROR - 2018-05-09 23:46:27 --> Severity: Warning --> Illegal string offset 'c_id' E:\xampp\htdocs\consulting\application\modules\admin\controllers\Profile.php 23
ERROR - 2018-05-09 23:46:27 --> Severity: Warning --> Illegal string offset 'c_name' E:\xampp\htdocs\consulting\application\modules\admin\controllers\Profile.php 23
ERROR - 2018-05-09 23:46:27 --> Severity: Warning --> Illegal string offset 'c_id' E:\xampp\htdocs\consulting\application\modules\admin\controllers\Profile.php 23
ERROR - 2018-05-09 23:46:27 --> Severity: Warning --> Illegal string offset 'c_name' E:\xampp\htdocs\consulting\application\modules\admin\controllers\Profile.php 23
ERROR - 2018-05-09 23:46:27 --> Severity: Warning --> Illegal string offset 'c_id' E:\xampp\htdocs\consulting\application\modules\admin\controllers\Profile.php 23
ERROR - 2018-05-09 23:46:27 --> Severity: Warning --> Illegal string offset 'c_name' E:\xampp\htdocs\consulting\application\modules\admin\controllers\Profile.php 23
ERROR - 2018-05-09 23:46:27 --> Severity: error --> Exception: Unable to locate the model you have specified: Seller_model E:\xampp\htdocs\consulting\system\core\Loader.php 348
ERROR - 2018-05-09 23:46:27 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at E:\xampp\htdocs\consulting\system\core\Exceptions.php:271) E:\xampp\htdocs\consulting\system\core\Common.php 570
INFO - 2018-05-09 23:46:32 --> Config Class Initialized
INFO - 2018-05-09 23:46:32 --> Hooks Class Initialized
DEBUG - 2018-05-09 23:46:32 --> UTF-8 Support Enabled
INFO - 2018-05-09 23:46:32 --> Utf8 Class Initialized
INFO - 2018-05-09 23:46:32 --> URI Class Initialized
INFO - 2018-05-09 23:46:32 --> Router Class Initialized
INFO - 2018-05-09 23:46:32 --> Output Class Initialized
INFO - 2018-05-09 23:46:32 --> Security Class Initialized
DEBUG - 2018-05-09 23:46:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-09 23:46:32 --> Input Class Initialized
INFO - 2018-05-09 23:46:32 --> Language Class Initialized
INFO - 2018-05-09 23:46:32 --> Language Class Initialized
INFO - 2018-05-09 23:46:32 --> Config Class Initialized
INFO - 2018-05-09 23:46:33 --> Loader Class Initialized
DEBUG - 2018-05-09 23:46:33 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-09 23:46:33 --> Helper loaded: url_helper
INFO - 2018-05-09 23:46:33 --> Helper loaded: form_helper
INFO - 2018-05-09 23:46:33 --> Helper loaded: date_helper
INFO - 2018-05-09 23:46:33 --> Helper loaded: util_helper
INFO - 2018-05-09 23:46:33 --> Helper loaded: text_helper
INFO - 2018-05-09 23:46:33 --> Helper loaded: string_helper
INFO - 2018-05-09 23:46:33 --> Database Driver Class Initialized
DEBUG - 2018-05-09 23:46:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-09 23:46:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-09 23:46:33 --> Email Class Initialized
INFO - 2018-05-09 23:46:33 --> Controller Class Initialized
DEBUG - 2018-05-09 23:46:33 --> Admin MX_Controller Initialized
INFO - 2018-05-09 23:46:33 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-09 23:46:33 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-09 23:46:33 --> Login MX_Controller Initialized
DEBUG - 2018-05-09 23:46:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-09 23:46:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-09 23:46:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-05-09 23:46:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-05-09 23:46:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-05-09 23:46:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-05-09 23:46:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-05-09 23:46:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/dashboard.php
INFO - 2018-05-09 23:46:33 --> Final output sent to browser
DEBUG - 2018-05-09 23:46:33 --> Total execution time: 0.3909
INFO - 2018-05-09 23:46:42 --> Config Class Initialized
INFO - 2018-05-09 23:46:42 --> Hooks Class Initialized
DEBUG - 2018-05-09 23:46:42 --> UTF-8 Support Enabled
INFO - 2018-05-09 23:46:42 --> Utf8 Class Initialized
INFO - 2018-05-09 23:46:42 --> URI Class Initialized
INFO - 2018-05-09 23:46:42 --> Router Class Initialized
INFO - 2018-05-09 23:46:42 --> Output Class Initialized
INFO - 2018-05-09 23:46:42 --> Security Class Initialized
DEBUG - 2018-05-09 23:46:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-09 23:46:42 --> Input Class Initialized
INFO - 2018-05-09 23:46:42 --> Language Class Initialized
INFO - 2018-05-09 23:46:42 --> Language Class Initialized
INFO - 2018-05-09 23:46:42 --> Config Class Initialized
INFO - 2018-05-09 23:46:42 --> Loader Class Initialized
DEBUG - 2018-05-09 23:46:42 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-09 23:46:42 --> Helper loaded: url_helper
INFO - 2018-05-09 23:46:42 --> Helper loaded: form_helper
INFO - 2018-05-09 23:46:42 --> Helper loaded: date_helper
INFO - 2018-05-09 23:46:42 --> Helper loaded: util_helper
INFO - 2018-05-09 23:46:42 --> Helper loaded: text_helper
INFO - 2018-05-09 23:46:42 --> Helper loaded: string_helper
INFO - 2018-05-09 23:46:42 --> Database Driver Class Initialized
DEBUG - 2018-05-09 23:46:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-09 23:46:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-09 23:46:42 --> Email Class Initialized
INFO - 2018-05-09 23:46:42 --> Controller Class Initialized
DEBUG - 2018-05-09 23:46:42 --> News MX_Controller Initialized
INFO - 2018-05-09 23:46:42 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-09 23:46:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/News_model.php
DEBUG - 2018-05-09 23:46:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-09 23:46:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-05-09 23:46:42 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-09 23:46:42 --> Login MX_Controller Initialized
DEBUG - 2018-05-09 23:46:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-09 23:46:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-05-09 23:46:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-05-09 23:46:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-05-09 23:46:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-05-09 23:46:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-05-09 23:46:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/news/news.php
INFO - 2018-05-09 23:46:42 --> Final output sent to browser
DEBUG - 2018-05-09 23:46:42 --> Total execution time: 0.4301
INFO - 2018-05-09 23:46:43 --> Config Class Initialized
INFO - 2018-05-09 23:46:43 --> Config Class Initialized
INFO - 2018-05-09 23:46:43 --> Hooks Class Initialized
INFO - 2018-05-09 23:46:43 --> Hooks Class Initialized
DEBUG - 2018-05-09 23:46:43 --> UTF-8 Support Enabled
DEBUG - 2018-05-09 23:46:43 --> UTF-8 Support Enabled
INFO - 2018-05-09 23:46:43 --> Utf8 Class Initialized
INFO - 2018-05-09 23:46:43 --> Utf8 Class Initialized
INFO - 2018-05-09 23:46:43 --> URI Class Initialized
INFO - 2018-05-09 23:46:43 --> Router Class Initialized
INFO - 2018-05-09 23:46:43 --> URI Class Initialized
INFO - 2018-05-09 23:46:43 --> Output Class Initialized
INFO - 2018-05-09 23:46:43 --> Router Class Initialized
INFO - 2018-05-09 23:46:43 --> Security Class Initialized
INFO - 2018-05-09 23:46:43 --> Output Class Initialized
DEBUG - 2018-05-09 23:46:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-09 23:46:43 --> Input Class Initialized
INFO - 2018-05-09 23:46:43 --> Language Class Initialized
ERROR - 2018-05-09 23:46:43 --> 404 Page Not Found: /index
INFO - 2018-05-09 23:46:43 --> Security Class Initialized
DEBUG - 2018-05-09 23:46:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-09 23:46:43 --> Input Class Initialized
INFO - 2018-05-09 23:46:43 --> Language Class Initialized
ERROR - 2018-05-09 23:46:43 --> 404 Page Not Found: /index
INFO - 2018-05-09 23:46:43 --> Config Class Initialized
INFO - 2018-05-09 23:46:43 --> Hooks Class Initialized
DEBUG - 2018-05-09 23:46:43 --> UTF-8 Support Enabled
INFO - 2018-05-09 23:46:43 --> Utf8 Class Initialized
INFO - 2018-05-09 23:46:43 --> URI Class Initialized
INFO - 2018-05-09 23:46:43 --> Router Class Initialized
INFO - 2018-05-09 23:46:43 --> Output Class Initialized
INFO - 2018-05-09 23:46:43 --> Security Class Initialized
DEBUG - 2018-05-09 23:46:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-09 23:46:43 --> Input Class Initialized
INFO - 2018-05-09 23:46:43 --> Language Class Initialized
INFO - 2018-05-09 23:46:43 --> Language Class Initialized
INFO - 2018-05-09 23:46:43 --> Config Class Initialized
INFO - 2018-05-09 23:46:43 --> Loader Class Initialized
DEBUG - 2018-05-09 23:46:43 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-09 23:46:43 --> Helper loaded: url_helper
INFO - 2018-05-09 23:46:43 --> Helper loaded: form_helper
INFO - 2018-05-09 23:46:43 --> Helper loaded: date_helper
INFO - 2018-05-09 23:46:43 --> Helper loaded: util_helper
INFO - 2018-05-09 23:46:43 --> Helper loaded: text_helper
INFO - 2018-05-09 23:46:43 --> Helper loaded: string_helper
INFO - 2018-05-09 23:46:43 --> Database Driver Class Initialized
DEBUG - 2018-05-09 23:46:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-09 23:46:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-09 23:46:43 --> Email Class Initialized
INFO - 2018-05-09 23:46:43 --> Controller Class Initialized
DEBUG - 2018-05-09 23:46:43 --> News MX_Controller Initialized
INFO - 2018-05-09 23:46:43 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-09 23:46:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/News_model.php
DEBUG - 2018-05-09 23:46:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-09 23:46:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-05-09 23:46:43 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-09 23:46:43 --> Login MX_Controller Initialized
DEBUG - 2018-05-09 23:46:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
ERROR - 2018-05-09 23:46:43 --> Severity: error --> Exception: Call to undefined method CI_DB_mysqli_driver::drawdatatable() E:\xampp\htdocs\consulting\application\modules\admin\models\News_model.php 25
INFO - 2018-05-09 23:51:25 --> Config Class Initialized
INFO - 2018-05-09 23:51:25 --> Hooks Class Initialized
DEBUG - 2018-05-09 23:51:25 --> UTF-8 Support Enabled
INFO - 2018-05-09 23:51:25 --> Utf8 Class Initialized
INFO - 2018-05-09 23:51:25 --> URI Class Initialized
INFO - 2018-05-09 23:51:25 --> Router Class Initialized
INFO - 2018-05-09 23:51:25 --> Output Class Initialized
INFO - 2018-05-09 23:51:25 --> Security Class Initialized
DEBUG - 2018-05-09 23:51:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-09 23:51:25 --> Input Class Initialized
INFO - 2018-05-09 23:51:25 --> Language Class Initialized
INFO - 2018-05-09 23:51:25 --> Language Class Initialized
INFO - 2018-05-09 23:51:25 --> Config Class Initialized
INFO - 2018-05-09 23:51:25 --> Loader Class Initialized
DEBUG - 2018-05-09 23:51:25 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-09 23:51:25 --> Helper loaded: url_helper
INFO - 2018-05-09 23:51:25 --> Helper loaded: form_helper
INFO - 2018-05-09 23:51:25 --> Helper loaded: date_helper
INFO - 2018-05-09 23:51:25 --> Helper loaded: util_helper
INFO - 2018-05-09 23:51:25 --> Helper loaded: text_helper
INFO - 2018-05-09 23:51:25 --> Helper loaded: string_helper
INFO - 2018-05-09 23:51:25 --> Database Driver Class Initialized
DEBUG - 2018-05-09 23:51:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-09 23:51:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-09 23:51:25 --> Email Class Initialized
INFO - 2018-05-09 23:51:25 --> Controller Class Initialized
DEBUG - 2018-05-09 23:51:25 --> News MX_Controller Initialized
INFO - 2018-05-09 23:51:25 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-09 23:51:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/News_model.php
DEBUG - 2018-05-09 23:51:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-09 23:51:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-05-09 23:51:25 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-09 23:51:25 --> Login MX_Controller Initialized
DEBUG - 2018-05-09 23:51:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-09 23:51:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-05-09 23:51:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-05-09 23:51:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-05-09 23:51:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-05-09 23:51:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-05-09 23:51:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/news/news.php
INFO - 2018-05-09 23:51:25 --> Final output sent to browser
INFO - 2018-05-09 23:51:25 --> Config Class Initialized
DEBUG - 2018-05-09 23:51:25 --> Total execution time: 0.4291
INFO - 2018-05-09 23:51:25 --> Hooks Class Initialized
INFO - 2018-05-09 23:51:25 --> Config Class Initialized
DEBUG - 2018-05-09 23:51:25 --> UTF-8 Support Enabled
INFO - 2018-05-09 23:51:25 --> Hooks Class Initialized
DEBUG - 2018-05-09 23:51:25 --> UTF-8 Support Enabled
INFO - 2018-05-09 23:51:25 --> Utf8 Class Initialized
INFO - 2018-05-09 23:51:25 --> URI Class Initialized
INFO - 2018-05-09 23:51:25 --> Router Class Initialized
INFO - 2018-05-09 23:51:25 --> Output Class Initialized
INFO - 2018-05-09 23:51:25 --> Security Class Initialized
DEBUG - 2018-05-09 23:51:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-09 23:51:25 --> Input Class Initialized
INFO - 2018-05-09 23:51:25 --> Language Class Initialized
ERROR - 2018-05-09 23:51:25 --> 404 Page Not Found: /index
INFO - 2018-05-09 23:51:25 --> Utf8 Class Initialized
INFO - 2018-05-09 23:51:25 --> URI Class Initialized
INFO - 2018-05-09 23:51:25 --> Router Class Initialized
INFO - 2018-05-09 23:51:25 --> Output Class Initialized
INFO - 2018-05-09 23:51:25 --> Security Class Initialized
DEBUG - 2018-05-09 23:51:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-09 23:51:25 --> Input Class Initialized
INFO - 2018-05-09 23:51:25 --> Language Class Initialized
ERROR - 2018-05-09 23:51:25 --> 404 Page Not Found: /index
INFO - 2018-05-09 23:51:26 --> Config Class Initialized
INFO - 2018-05-09 23:51:26 --> Hooks Class Initialized
DEBUG - 2018-05-09 23:51:26 --> UTF-8 Support Enabled
INFO - 2018-05-09 23:51:26 --> Utf8 Class Initialized
INFO - 2018-05-09 23:51:26 --> URI Class Initialized
INFO - 2018-05-09 23:51:26 --> Router Class Initialized
INFO - 2018-05-09 23:51:26 --> Output Class Initialized
INFO - 2018-05-09 23:51:26 --> Security Class Initialized
DEBUG - 2018-05-09 23:51:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-09 23:51:26 --> Input Class Initialized
INFO - 2018-05-09 23:51:26 --> Language Class Initialized
INFO - 2018-05-09 23:51:26 --> Language Class Initialized
INFO - 2018-05-09 23:51:26 --> Config Class Initialized
INFO - 2018-05-09 23:51:26 --> Loader Class Initialized
DEBUG - 2018-05-09 23:51:26 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-09 23:51:26 --> Helper loaded: url_helper
INFO - 2018-05-09 23:51:26 --> Helper loaded: form_helper
INFO - 2018-05-09 23:51:26 --> Helper loaded: date_helper
INFO - 2018-05-09 23:51:26 --> Helper loaded: util_helper
INFO - 2018-05-09 23:51:26 --> Helper loaded: text_helper
INFO - 2018-05-09 23:51:26 --> Helper loaded: string_helper
INFO - 2018-05-09 23:51:26 --> Database Driver Class Initialized
DEBUG - 2018-05-09 23:51:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-09 23:51:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-09 23:51:26 --> Email Class Initialized
INFO - 2018-05-09 23:51:26 --> Controller Class Initialized
DEBUG - 2018-05-09 23:51:26 --> News MX_Controller Initialized
INFO - 2018-05-09 23:51:26 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-09 23:51:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/News_model.php
DEBUG - 2018-05-09 23:51:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-09 23:51:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-05-09 23:51:26 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-09 23:51:26 --> Login MX_Controller Initialized
DEBUG - 2018-05-09 23:51:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
ERROR - 2018-05-09 23:51:26 --> Severity: error --> Exception: Call to undefined method CI_DB_mysqli_driver::drawdatatable() E:\xampp\htdocs\consulting\application\modules\admin\models\News_model.php 25
