<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-05-11 01:01:04 --> Config Class Initialized
INFO - 2018-05-11 01:01:04 --> Hooks Class Initialized
DEBUG - 2018-05-11 01:01:04 --> UTF-8 Support Enabled
INFO - 2018-05-11 01:01:04 --> Utf8 Class Initialized
INFO - 2018-05-11 01:01:04 --> URI Class Initialized
DEBUG - 2018-05-11 01:01:04 --> No URI present. Default controller set.
INFO - 2018-05-11 01:01:04 --> Router Class Initialized
INFO - 2018-05-11 01:01:04 --> Output Class Initialized
INFO - 2018-05-11 01:01:04 --> Security Class Initialized
DEBUG - 2018-05-11 01:01:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 01:01:04 --> Input Class Initialized
INFO - 2018-05-11 01:01:04 --> Language Class Initialized
INFO - 2018-05-11 01:01:04 --> Language Class Initialized
INFO - 2018-05-11 01:01:04 --> Config Class Initialized
INFO - 2018-05-11 01:01:04 --> Loader Class Initialized
DEBUG - 2018-05-11 01:01:04 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-11 01:01:04 --> Helper loaded: url_helper
INFO - 2018-05-11 01:01:04 --> Helper loaded: form_helper
INFO - 2018-05-11 01:01:04 --> Helper loaded: date_helper
INFO - 2018-05-11 01:01:04 --> Helper loaded: util_helper
INFO - 2018-05-11 01:01:04 --> Helper loaded: text_helper
INFO - 2018-05-11 01:01:04 --> Helper loaded: string_helper
INFO - 2018-05-11 01:01:04 --> Database Driver Class Initialized
DEBUG - 2018-05-11 01:01:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-11 01:01:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-11 01:01:04 --> Email Class Initialized
INFO - 2018-05-11 01:01:04 --> Controller Class Initialized
DEBUG - 2018-05-11 01:01:05 --> Home MX_Controller Initialized
DEBUG - 2018-05-11 01:01:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-05-11 01:01:05 --> Final output sent to browser
DEBUG - 2018-05-11 01:01:05 --> Total execution time: 0.4827
INFO - 2018-05-11 01:01:05 --> Config Class Initialized
INFO - 2018-05-11 01:01:05 --> Hooks Class Initialized
DEBUG - 2018-05-11 01:01:05 --> UTF-8 Support Enabled
INFO - 2018-05-11 01:01:05 --> Utf8 Class Initialized
INFO - 2018-05-11 01:01:05 --> URI Class Initialized
INFO - 2018-05-11 01:01:05 --> Router Class Initialized
INFO - 2018-05-11 01:01:05 --> Output Class Initialized
INFO - 2018-05-11 01:01:05 --> Security Class Initialized
DEBUG - 2018-05-11 01:01:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 01:01:05 --> Input Class Initialized
INFO - 2018-05-11 01:01:05 --> Language Class Initialized
ERROR - 2018-05-11 01:01:05 --> 404 Page Not Found: /index
INFO - 2018-05-11 01:01:05 --> Config Class Initialized
INFO - 2018-05-11 01:01:05 --> Config Class Initialized
INFO - 2018-05-11 01:01:05 --> Config Class Initialized
INFO - 2018-05-11 01:01:05 --> Config Class Initialized
INFO - 2018-05-11 01:01:05 --> Config Class Initialized
INFO - 2018-05-11 01:01:05 --> Config Class Initialized
INFO - 2018-05-11 01:01:05 --> Hooks Class Initialized
INFO - 2018-05-11 01:01:05 --> Hooks Class Initialized
INFO - 2018-05-11 01:01:05 --> Hooks Class Initialized
INFO - 2018-05-11 01:01:05 --> Hooks Class Initialized
INFO - 2018-05-11 01:01:05 --> Hooks Class Initialized
INFO - 2018-05-11 01:01:05 --> Hooks Class Initialized
DEBUG - 2018-05-11 01:01:05 --> UTF-8 Support Enabled
DEBUG - 2018-05-11 01:01:05 --> UTF-8 Support Enabled
DEBUG - 2018-05-11 01:01:05 --> UTF-8 Support Enabled
DEBUG - 2018-05-11 01:01:05 --> UTF-8 Support Enabled
DEBUG - 2018-05-11 01:01:05 --> UTF-8 Support Enabled
DEBUG - 2018-05-11 01:01:05 --> UTF-8 Support Enabled
INFO - 2018-05-11 01:01:05 --> Utf8 Class Initialized
INFO - 2018-05-11 01:01:05 --> Utf8 Class Initialized
INFO - 2018-05-11 01:01:05 --> Utf8 Class Initialized
INFO - 2018-05-11 01:01:05 --> Utf8 Class Initialized
INFO - 2018-05-11 01:01:05 --> Utf8 Class Initialized
INFO - 2018-05-11 01:01:05 --> Utf8 Class Initialized
INFO - 2018-05-11 01:01:05 --> URI Class Initialized
INFO - 2018-05-11 01:01:05 --> Router Class Initialized
INFO - 2018-05-11 01:01:05 --> URI Class Initialized
INFO - 2018-05-11 01:01:05 --> URI Class Initialized
INFO - 2018-05-11 01:01:05 --> URI Class Initialized
INFO - 2018-05-11 01:01:05 --> URI Class Initialized
INFO - 2018-05-11 01:01:05 --> URI Class Initialized
INFO - 2018-05-11 01:01:05 --> Output Class Initialized
INFO - 2018-05-11 01:01:06 --> Router Class Initialized
INFO - 2018-05-11 01:01:06 --> Router Class Initialized
INFO - 2018-05-11 01:01:06 --> Router Class Initialized
INFO - 2018-05-11 01:01:06 --> Router Class Initialized
INFO - 2018-05-11 01:01:06 --> Security Class Initialized
INFO - 2018-05-11 01:01:06 --> Router Class Initialized
INFO - 2018-05-11 01:01:06 --> Output Class Initialized
DEBUG - 2018-05-11 01:01:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 01:01:06 --> Output Class Initialized
INFO - 2018-05-11 01:01:06 --> Output Class Initialized
INFO - 2018-05-11 01:01:06 --> Output Class Initialized
INFO - 2018-05-11 01:01:06 --> Input Class Initialized
INFO - 2018-05-11 01:01:06 --> Security Class Initialized
INFO - 2018-05-11 01:01:06 --> Security Class Initialized
INFO - 2018-05-11 01:01:06 --> Output Class Initialized
INFO - 2018-05-11 01:01:06 --> Security Class Initialized
INFO - 2018-05-11 01:01:06 --> Security Class Initialized
INFO - 2018-05-11 01:01:06 --> Language Class Initialized
DEBUG - 2018-05-11 01:01:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-11 01:01:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-11 01:01:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-11 01:01:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 01:01:06 --> Security Class Initialized
INFO - 2018-05-11 01:01:06 --> Input Class Initialized
ERROR - 2018-05-11 01:01:06 --> 404 Page Not Found: /index
DEBUG - 2018-05-11 01:01:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 01:01:06 --> Input Class Initialized
INFO - 2018-05-11 01:01:06 --> Input Class Initialized
INFO - 2018-05-11 01:01:06 --> Input Class Initialized
INFO - 2018-05-11 01:01:06 --> Input Class Initialized
INFO - 2018-05-11 01:01:06 --> Language Class Initialized
INFO - 2018-05-11 01:01:06 --> Language Class Initialized
INFO - 2018-05-11 01:01:06 --> Config Class Initialized
INFO - 2018-05-11 01:01:06 --> Language Class Initialized
INFO - 2018-05-11 01:01:06 --> Hooks Class Initialized
INFO - 2018-05-11 01:01:06 --> Language Class Initialized
ERROR - 2018-05-11 01:01:06 --> 404 Page Not Found: /index
ERROR - 2018-05-11 01:01:06 --> 404 Page Not Found: /index
ERROR - 2018-05-11 01:01:06 --> 404 Page Not Found: /index
INFO - 2018-05-11 01:01:06 --> Language Class Initialized
DEBUG - 2018-05-11 01:01:06 --> UTF-8 Support Enabled
ERROR - 2018-05-11 01:01:06 --> 404 Page Not Found: /index
INFO - 2018-05-11 01:01:06 --> Utf8 Class Initialized
ERROR - 2018-05-11 01:01:06 --> 404 Page Not Found: /index
INFO - 2018-05-11 01:01:06 --> Config Class Initialized
INFO - 2018-05-11 01:01:06 --> Config Class Initialized
INFO - 2018-05-11 01:01:06 --> Hooks Class Initialized
INFO - 2018-05-11 01:01:06 --> Hooks Class Initialized
INFO - 2018-05-11 01:01:06 --> Config Class Initialized
INFO - 2018-05-11 01:01:06 --> Config Class Initialized
INFO - 2018-05-11 01:01:06 --> URI Class Initialized
INFO - 2018-05-11 01:01:06 --> Hooks Class Initialized
INFO - 2018-05-11 01:01:06 --> Hooks Class Initialized
DEBUG - 2018-05-11 01:01:06 --> UTF-8 Support Enabled
INFO - 2018-05-11 01:01:06 --> Router Class Initialized
DEBUG - 2018-05-11 01:01:06 --> UTF-8 Support Enabled
INFO - 2018-05-11 01:01:06 --> Utf8 Class Initialized
INFO - 2018-05-11 01:01:06 --> Output Class Initialized
INFO - 2018-05-11 01:01:06 --> Utf8 Class Initialized
DEBUG - 2018-05-11 01:01:06 --> UTF-8 Support Enabled
DEBUG - 2018-05-11 01:01:06 --> UTF-8 Support Enabled
INFO - 2018-05-11 01:01:06 --> URI Class Initialized
INFO - 2018-05-11 01:01:06 --> Router Class Initialized
INFO - 2018-05-11 01:01:06 --> Output Class Initialized
INFO - 2018-05-11 01:01:07 --> URI Class Initialized
INFO - 2018-05-11 01:01:07 --> Security Class Initialized
INFO - 2018-05-11 01:01:07 --> Utf8 Class Initialized
INFO - 2018-05-11 01:01:07 --> Router Class Initialized
DEBUG - 2018-05-11 01:01:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 01:01:07 --> Utf8 Class Initialized
INFO - 2018-05-11 01:01:07 --> Security Class Initialized
INFO - 2018-05-11 01:01:07 --> URI Class Initialized
INFO - 2018-05-11 01:01:07 --> Input Class Initialized
INFO - 2018-05-11 01:01:07 --> URI Class Initialized
DEBUG - 2018-05-11 01:01:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 01:01:07 --> Output Class Initialized
INFO - 2018-05-11 01:01:07 --> Router Class Initialized
INFO - 2018-05-11 01:01:07 --> Input Class Initialized
INFO - 2018-05-11 01:01:07 --> Security Class Initialized
INFO - 2018-05-11 01:01:07 --> Router Class Initialized
INFO - 2018-05-11 01:01:07 --> Output Class Initialized
INFO - 2018-05-11 01:01:07 --> Language Class Initialized
INFO - 2018-05-11 01:01:07 --> Language Class Initialized
ERROR - 2018-05-11 01:01:07 --> 404 Page Not Found: /index
INFO - 2018-05-11 01:01:07 --> Config Class Initialized
INFO - 2018-05-11 01:01:07 --> Hooks Class Initialized
DEBUG - 2018-05-11 01:01:07 --> UTF-8 Support Enabled
INFO - 2018-05-11 01:01:07 --> Utf8 Class Initialized
INFO - 2018-05-11 01:01:07 --> URI Class Initialized
INFO - 2018-05-11 01:01:07 --> Security Class Initialized
INFO - 2018-05-11 01:01:07 --> Output Class Initialized
INFO - 2018-05-11 01:01:07 --> Router Class Initialized
INFO - 2018-05-11 01:01:07 --> Output Class Initialized
INFO - 2018-05-11 01:01:07 --> Security Class Initialized
DEBUG - 2018-05-11 01:01:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 01:01:07 --> Input Class Initialized
DEBUG - 2018-05-11 01:01:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-11 01:01:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-05-11 01:01:07 --> 404 Page Not Found: /index
INFO - 2018-05-11 01:01:07 --> Security Class Initialized
INFO - 2018-05-11 01:01:07 --> Language Class Initialized
ERROR - 2018-05-11 01:01:07 --> 404 Page Not Found: /index
INFO - 2018-05-11 01:01:07 --> Input Class Initialized
INFO - 2018-05-11 01:01:07 --> Language Class Initialized
ERROR - 2018-05-11 01:01:07 --> 404 Page Not Found: /index
INFO - 2018-05-11 01:01:07 --> Config Class Initialized
INFO - 2018-05-11 01:01:07 --> Hooks Class Initialized
DEBUG - 2018-05-11 01:01:07 --> UTF-8 Support Enabled
INFO - 2018-05-11 01:01:07 --> Utf8 Class Initialized
INFO - 2018-05-11 01:01:07 --> URI Class Initialized
INFO - 2018-05-11 01:01:07 --> Router Class Initialized
INFO - 2018-05-11 01:01:07 --> Input Class Initialized
INFO - 2018-05-11 01:01:07 --> Config Class Initialized
DEBUG - 2018-05-11 01:01:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 01:01:07 --> Output Class Initialized
INFO - 2018-05-11 01:01:07 --> Hooks Class Initialized
INFO - 2018-05-11 01:01:07 --> Language Class Initialized
ERROR - 2018-05-11 01:01:07 --> 404 Page Not Found: /index
DEBUG - 2018-05-11 01:01:07 --> UTF-8 Support Enabled
INFO - 2018-05-11 01:01:07 --> Input Class Initialized
INFO - 2018-05-11 01:01:07 --> Security Class Initialized
INFO - 2018-05-11 01:01:07 --> Utf8 Class Initialized
INFO - 2018-05-11 01:01:07 --> Config Class Initialized
DEBUG - 2018-05-11 01:01:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 01:01:07 --> Language Class Initialized
INFO - 2018-05-11 01:01:07 --> Hooks Class Initialized
INFO - 2018-05-11 01:01:07 --> URI Class Initialized
ERROR - 2018-05-11 01:01:07 --> 404 Page Not Found: /index
INFO - 2018-05-11 01:01:07 --> Input Class Initialized
DEBUG - 2018-05-11 01:01:07 --> UTF-8 Support Enabled
INFO - 2018-05-11 01:01:07 --> Router Class Initialized
INFO - 2018-05-11 01:01:07 --> Language Class Initialized
INFO - 2018-05-11 01:01:07 --> Config Class Initialized
INFO - 2018-05-11 01:01:07 --> Hooks Class Initialized
INFO - 2018-05-11 01:01:07 --> Output Class Initialized
INFO - 2018-05-11 01:01:07 --> Utf8 Class Initialized
ERROR - 2018-05-11 01:01:07 --> 404 Page Not Found: /index
INFO - 2018-05-11 01:01:07 --> URI Class Initialized
DEBUG - 2018-05-11 01:01:07 --> UTF-8 Support Enabled
INFO - 2018-05-11 01:01:07 --> Security Class Initialized
INFO - 2018-05-11 01:01:07 --> Router Class Initialized
INFO - 2018-05-11 01:01:07 --> Utf8 Class Initialized
DEBUG - 2018-05-11 01:01:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 01:01:07 --> Output Class Initialized
INFO - 2018-05-11 01:01:07 --> URI Class Initialized
INFO - 2018-05-11 01:01:07 --> Input Class Initialized
INFO - 2018-05-11 01:01:07 --> Security Class Initialized
INFO - 2018-05-11 01:01:07 --> Router Class Initialized
INFO - 2018-05-11 01:01:08 --> Output Class Initialized
INFO - 2018-05-11 01:01:08 --> Language Class Initialized
INFO - 2018-05-11 01:01:08 --> Security Class Initialized
DEBUG - 2018-05-11 01:01:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-05-11 01:01:08 --> 404 Page Not Found: /index
DEBUG - 2018-05-11 01:01:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 01:01:08 --> Input Class Initialized
INFO - 2018-05-11 01:01:08 --> Input Class Initialized
INFO - 2018-05-11 01:01:08 --> Language Class Initialized
INFO - 2018-05-11 01:01:08 --> Language Class Initialized
ERROR - 2018-05-11 01:01:08 --> 404 Page Not Found: /index
ERROR - 2018-05-11 01:01:08 --> 404 Page Not Found: /index
INFO - 2018-05-11 01:01:10 --> Config Class Initialized
INFO - 2018-05-11 01:01:10 --> Hooks Class Initialized
DEBUG - 2018-05-11 01:01:10 --> UTF-8 Support Enabled
INFO - 2018-05-11 01:01:10 --> Utf8 Class Initialized
INFO - 2018-05-11 01:01:10 --> URI Class Initialized
DEBUG - 2018-05-11 01:01:10 --> No URI present. Default controller set.
INFO - 2018-05-11 01:01:10 --> Router Class Initialized
INFO - 2018-05-11 01:01:10 --> Output Class Initialized
INFO - 2018-05-11 01:01:10 --> Security Class Initialized
DEBUG - 2018-05-11 01:01:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 01:01:10 --> Input Class Initialized
INFO - 2018-05-11 01:01:10 --> Language Class Initialized
INFO - 2018-05-11 01:01:10 --> Language Class Initialized
INFO - 2018-05-11 01:01:10 --> Config Class Initialized
INFO - 2018-05-11 01:01:10 --> Loader Class Initialized
DEBUG - 2018-05-11 01:01:10 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-11 01:01:10 --> Helper loaded: url_helper
INFO - 2018-05-11 01:01:10 --> Helper loaded: form_helper
INFO - 2018-05-11 01:01:10 --> Helper loaded: date_helper
INFO - 2018-05-11 01:01:10 --> Helper loaded: util_helper
INFO - 2018-05-11 01:01:10 --> Helper loaded: text_helper
INFO - 2018-05-11 01:01:10 --> Helper loaded: string_helper
INFO - 2018-05-11 01:01:10 --> Database Driver Class Initialized
DEBUG - 2018-05-11 01:01:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-11 01:01:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-11 01:01:10 --> Email Class Initialized
INFO - 2018-05-11 01:01:10 --> Controller Class Initialized
DEBUG - 2018-05-11 01:01:10 --> Home MX_Controller Initialized
DEBUG - 2018-05-11 01:01:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-05-11 01:01:10 --> Final output sent to browser
DEBUG - 2018-05-11 01:01:10 --> Total execution time: 0.3760
INFO - 2018-05-11 01:01:10 --> Config Class Initialized
INFO - 2018-05-11 01:01:10 --> Hooks Class Initialized
DEBUG - 2018-05-11 01:01:10 --> UTF-8 Support Enabled
INFO - 2018-05-11 01:01:10 --> Utf8 Class Initialized
INFO - 2018-05-11 01:01:10 --> URI Class Initialized
INFO - 2018-05-11 01:01:10 --> Config Class Initialized
INFO - 2018-05-11 01:01:10 --> Config Class Initialized
INFO - 2018-05-11 01:01:10 --> Router Class Initialized
INFO - 2018-05-11 01:01:10 --> Config Class Initialized
INFO - 2018-05-11 01:01:10 --> Hooks Class Initialized
INFO - 2018-05-11 01:01:10 --> Hooks Class Initialized
INFO - 2018-05-11 01:01:10 --> Config Class Initialized
INFO - 2018-05-11 01:01:10 --> Config Class Initialized
INFO - 2018-05-11 01:01:10 --> Output Class Initialized
INFO - 2018-05-11 01:01:10 --> Hooks Class Initialized
DEBUG - 2018-05-11 01:01:11 --> UTF-8 Support Enabled
INFO - 2018-05-11 01:01:11 --> Security Class Initialized
INFO - 2018-05-11 01:01:11 --> Hooks Class Initialized
INFO - 2018-05-11 01:01:11 --> Hooks Class Initialized
DEBUG - 2018-05-11 01:01:11 --> UTF-8 Support Enabled
DEBUG - 2018-05-11 01:01:11 --> UTF-8 Support Enabled
INFO - 2018-05-11 01:01:11 --> Utf8 Class Initialized
DEBUG - 2018-05-11 01:01:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 01:01:11 --> Utf8 Class Initialized
INFO - 2018-05-11 01:01:11 --> URI Class Initialized
INFO - 2018-05-11 01:01:11 --> Utf8 Class Initialized
DEBUG - 2018-05-11 01:01:11 --> UTF-8 Support Enabled
DEBUG - 2018-05-11 01:01:11 --> UTF-8 Support Enabled
INFO - 2018-05-11 01:01:11 --> URI Class Initialized
INFO - 2018-05-11 01:01:11 --> Router Class Initialized
INFO - 2018-05-11 01:01:11 --> Utf8 Class Initialized
INFO - 2018-05-11 01:01:11 --> Utf8 Class Initialized
INFO - 2018-05-11 01:01:11 --> Input Class Initialized
INFO - 2018-05-11 01:01:11 --> URI Class Initialized
INFO - 2018-05-11 01:01:11 --> URI Class Initialized
INFO - 2018-05-11 01:01:11 --> URI Class Initialized
INFO - 2018-05-11 01:01:11 --> Output Class Initialized
INFO - 2018-05-11 01:01:11 --> Language Class Initialized
INFO - 2018-05-11 01:01:11 --> Router Class Initialized
INFO - 2018-05-11 01:01:11 --> Router Class Initialized
INFO - 2018-05-11 01:01:11 --> Security Class Initialized
INFO - 2018-05-11 01:01:11 --> Router Class Initialized
INFO - 2018-05-11 01:01:11 --> Output Class Initialized
INFO - 2018-05-11 01:01:11 --> Output Class Initialized
ERROR - 2018-05-11 01:01:11 --> 404 Page Not Found: /index
INFO - 2018-05-11 01:01:11 --> Router Class Initialized
INFO - 2018-05-11 01:01:11 --> Output Class Initialized
DEBUG - 2018-05-11 01:01:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 01:01:11 --> Security Class Initialized
INFO - 2018-05-11 01:01:11 --> Security Class Initialized
INFO - 2018-05-11 01:01:11 --> Output Class Initialized
INFO - 2018-05-11 01:01:11 --> Input Class Initialized
INFO - 2018-05-11 01:01:11 --> Config Class Initialized
DEBUG - 2018-05-11 01:01:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-11 01:01:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 01:01:11 --> Security Class Initialized
INFO - 2018-05-11 01:01:11 --> Security Class Initialized
INFO - 2018-05-11 01:01:11 --> Language Class Initialized
INFO - 2018-05-11 01:01:11 --> Hooks Class Initialized
DEBUG - 2018-05-11 01:01:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-11 01:01:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 01:01:11 --> Input Class Initialized
INFO - 2018-05-11 01:01:11 --> Input Class Initialized
ERROR - 2018-05-11 01:01:11 --> 404 Page Not Found: /index
DEBUG - 2018-05-11 01:01:11 --> UTF-8 Support Enabled
INFO - 2018-05-11 01:01:11 --> Language Class Initialized
INFO - 2018-05-11 01:01:11 --> Language Class Initialized
INFO - 2018-05-11 01:01:11 --> Input Class Initialized
INFO - 2018-05-11 01:01:11 --> Input Class Initialized
INFO - 2018-05-11 01:01:11 --> Utf8 Class Initialized
INFO - 2018-05-11 01:01:11 --> Config Class Initialized
INFO - 2018-05-11 01:01:11 --> Hooks Class Initialized
INFO - 2018-05-11 01:01:11 --> URI Class Initialized
ERROR - 2018-05-11 01:01:11 --> 404 Page Not Found: /index
ERROR - 2018-05-11 01:01:11 --> 404 Page Not Found: /index
INFO - 2018-05-11 01:01:11 --> Language Class Initialized
INFO - 2018-05-11 01:01:11 --> Language Class Initialized
DEBUG - 2018-05-11 01:01:11 --> UTF-8 Support Enabled
INFO - 2018-05-11 01:01:11 --> Utf8 Class Initialized
INFO - 2018-05-11 01:01:11 --> Router Class Initialized
ERROR - 2018-05-11 01:01:11 --> 404 Page Not Found: /index
INFO - 2018-05-11 01:01:11 --> Output Class Initialized
ERROR - 2018-05-11 01:01:11 --> 404 Page Not Found: /index
INFO - 2018-05-11 01:01:11 --> Security Class Initialized
INFO - 2018-05-11 01:01:11 --> URI Class Initialized
INFO - 2018-05-11 01:01:11 --> Config Class Initialized
INFO - 2018-05-11 01:01:11 --> Config Class Initialized
INFO - 2018-05-11 01:01:11 --> Config Class Initialized
INFO - 2018-05-11 01:01:11 --> Hooks Class Initialized
INFO - 2018-05-11 01:01:11 --> Hooks Class Initialized
INFO - 2018-05-11 01:01:11 --> Hooks Class Initialized
DEBUG - 2018-05-11 01:01:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 01:01:11 --> Router Class Initialized
DEBUG - 2018-05-11 01:01:11 --> UTF-8 Support Enabled
INFO - 2018-05-11 01:01:11 --> Output Class Initialized
INFO - 2018-05-11 01:01:11 --> Input Class Initialized
DEBUG - 2018-05-11 01:01:11 --> UTF-8 Support Enabled
INFO - 2018-05-11 01:01:11 --> Utf8 Class Initialized
DEBUG - 2018-05-11 01:01:11 --> UTF-8 Support Enabled
INFO - 2018-05-11 01:01:11 --> Security Class Initialized
INFO - 2018-05-11 01:01:11 --> Utf8 Class Initialized
INFO - 2018-05-11 01:01:11 --> Language Class Initialized
INFO - 2018-05-11 01:01:11 --> URI Class Initialized
INFO - 2018-05-11 01:01:11 --> Router Class Initialized
DEBUG - 2018-05-11 01:01:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 01:01:11 --> Utf8 Class Initialized
ERROR - 2018-05-11 01:01:11 --> 404 Page Not Found: /index
INFO - 2018-05-11 01:01:11 --> URI Class Initialized
INFO - 2018-05-11 01:01:11 --> Input Class Initialized
INFO - 2018-05-11 01:01:11 --> Output Class Initialized
INFO - 2018-05-11 01:01:11 --> URI Class Initialized
INFO - 2018-05-11 01:01:11 --> Language Class Initialized
INFO - 2018-05-11 01:01:11 --> Router Class Initialized
INFO - 2018-05-11 01:01:11 --> Config Class Initialized
ERROR - 2018-05-11 01:01:11 --> 404 Page Not Found: /index
INFO - 2018-05-11 01:01:11 --> Config Class Initialized
INFO - 2018-05-11 01:01:11 --> Hooks Class Initialized
DEBUG - 2018-05-11 01:01:11 --> UTF-8 Support Enabled
INFO - 2018-05-11 01:01:11 --> Router Class Initialized
INFO - 2018-05-11 01:01:11 --> Security Class Initialized
INFO - 2018-05-11 01:01:11 --> Output Class Initialized
INFO - 2018-05-11 01:01:11 --> Hooks Class Initialized
INFO - 2018-05-11 01:01:11 --> Utf8 Class Initialized
INFO - 2018-05-11 01:01:11 --> Output Class Initialized
INFO - 2018-05-11 01:01:11 --> URI Class Initialized
DEBUG - 2018-05-11 01:01:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 01:01:11 --> Security Class Initialized
DEBUG - 2018-05-11 01:01:11 --> UTF-8 Support Enabled
INFO - 2018-05-11 01:01:11 --> Router Class Initialized
INFO - 2018-05-11 01:01:11 --> Input Class Initialized
DEBUG - 2018-05-11 01:01:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 01:01:12 --> Security Class Initialized
INFO - 2018-05-11 01:01:12 --> Utf8 Class Initialized
INFO - 2018-05-11 01:01:12 --> Language Class Initialized
INFO - 2018-05-11 01:01:12 --> Input Class Initialized
INFO - 2018-05-11 01:01:12 --> Output Class Initialized
INFO - 2018-05-11 01:01:12 --> URI Class Initialized
DEBUG - 2018-05-11 01:01:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-05-11 01:01:12 --> 404 Page Not Found: /index
INFO - 2018-05-11 01:01:12 --> Security Class Initialized
INFO - 2018-05-11 01:01:12 --> Input Class Initialized
INFO - 2018-05-11 01:01:12 --> Router Class Initialized
DEBUG - 2018-05-11 01:01:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 01:01:12 --> Language Class Initialized
INFO - 2018-05-11 01:01:12 --> Config Class Initialized
INFO - 2018-05-11 01:01:12 --> Output Class Initialized
INFO - 2018-05-11 01:01:12 --> Language Class Initialized
INFO - 2018-05-11 01:01:12 --> Hooks Class Initialized
ERROR - 2018-05-11 01:01:12 --> 404 Page Not Found: /index
ERROR - 2018-05-11 01:01:12 --> 404 Page Not Found: /index
INFO - 2018-05-11 01:01:12 --> Security Class Initialized
INFO - 2018-05-11 01:01:12 --> Input Class Initialized
DEBUG - 2018-05-11 01:01:12 --> UTF-8 Support Enabled
INFO - 2018-05-11 01:01:12 --> Config Class Initialized
INFO - 2018-05-11 01:01:12 --> Config Class Initialized
INFO - 2018-05-11 01:01:12 --> Utf8 Class Initialized
INFO - 2018-05-11 01:01:12 --> Hooks Class Initialized
INFO - 2018-05-11 01:01:12 --> Hooks Class Initialized
DEBUG - 2018-05-11 01:01:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 01:01:12 --> Language Class Initialized
DEBUG - 2018-05-11 01:01:12 --> UTF-8 Support Enabled
INFO - 2018-05-11 01:01:12 --> URI Class Initialized
ERROR - 2018-05-11 01:01:12 --> 404 Page Not Found: /index
INFO - 2018-05-11 01:01:12 --> Input Class Initialized
DEBUG - 2018-05-11 01:01:12 --> UTF-8 Support Enabled
INFO - 2018-05-11 01:01:12 --> Utf8 Class Initialized
INFO - 2018-05-11 01:01:12 --> URI Class Initialized
INFO - 2018-05-11 01:01:12 --> Router Class Initialized
INFO - 2018-05-11 01:01:12 --> Output Class Initialized
INFO - 2018-05-11 01:01:12 --> Security Class Initialized
DEBUG - 2018-05-11 01:01:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 01:01:12 --> Input Class Initialized
INFO - 2018-05-11 01:01:12 --> Language Class Initialized
ERROR - 2018-05-11 01:01:12 --> 404 Page Not Found: /index
INFO - 2018-05-11 01:01:12 --> Router Class Initialized
INFO - 2018-05-11 01:01:12 --> Output Class Initialized
INFO - 2018-05-11 01:01:12 --> Security Class Initialized
INFO - 2018-05-11 01:01:12 --> Language Class Initialized
INFO - 2018-05-11 01:01:12 --> Utf8 Class Initialized
DEBUG - 2018-05-11 01:01:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 01:01:12 --> Input Class Initialized
INFO - 2018-05-11 01:01:12 --> Language Class Initialized
ERROR - 2018-05-11 01:01:12 --> 404 Page Not Found: /index
INFO - 2018-05-11 01:01:12 --> URI Class Initialized
INFO - 2018-05-11 01:01:12 --> Router Class Initialized
INFO - 2018-05-11 01:01:12 --> Output Class Initialized
INFO - 2018-05-11 01:01:12 --> Security Class Initialized
ERROR - 2018-05-11 01:01:12 --> 404 Page Not Found: /index
DEBUG - 2018-05-11 01:01:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 01:01:12 --> Input Class Initialized
INFO - 2018-05-11 01:01:12 --> Config Class Initialized
INFO - 2018-05-11 01:01:12 --> Hooks Class Initialized
INFO - 2018-05-11 01:01:12 --> Language Class Initialized
DEBUG - 2018-05-11 01:01:12 --> UTF-8 Support Enabled
ERROR - 2018-05-11 01:01:12 --> 404 Page Not Found: /index
INFO - 2018-05-11 01:01:12 --> Utf8 Class Initialized
INFO - 2018-05-11 01:01:12 --> URI Class Initialized
INFO - 2018-05-11 01:01:12 --> Router Class Initialized
INFO - 2018-05-11 01:01:12 --> Output Class Initialized
INFO - 2018-05-11 01:01:12 --> Security Class Initialized
DEBUG - 2018-05-11 01:01:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 01:01:12 --> Input Class Initialized
INFO - 2018-05-11 01:01:12 --> Language Class Initialized
ERROR - 2018-05-11 01:01:12 --> 404 Page Not Found: /index
INFO - 2018-05-11 01:01:19 --> Config Class Initialized
INFO - 2018-05-11 01:01:19 --> Hooks Class Initialized
DEBUG - 2018-05-11 01:01:19 --> UTF-8 Support Enabled
INFO - 2018-05-11 01:01:19 --> Utf8 Class Initialized
INFO - 2018-05-11 01:01:19 --> URI Class Initialized
DEBUG - 2018-05-11 01:01:19 --> No URI present. Default controller set.
INFO - 2018-05-11 01:01:19 --> Router Class Initialized
INFO - 2018-05-11 01:01:19 --> Output Class Initialized
INFO - 2018-05-11 01:01:19 --> Security Class Initialized
DEBUG - 2018-05-11 01:01:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 01:01:19 --> Input Class Initialized
INFO - 2018-05-11 01:01:19 --> Language Class Initialized
INFO - 2018-05-11 01:01:19 --> Language Class Initialized
INFO - 2018-05-11 01:01:19 --> Config Class Initialized
INFO - 2018-05-11 01:01:19 --> Loader Class Initialized
DEBUG - 2018-05-11 01:01:19 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-11 01:01:19 --> Helper loaded: url_helper
INFO - 2018-05-11 01:01:19 --> Helper loaded: form_helper
INFO - 2018-05-11 01:01:19 --> Helper loaded: date_helper
INFO - 2018-05-11 01:01:19 --> Helper loaded: util_helper
INFO - 2018-05-11 01:01:19 --> Helper loaded: text_helper
INFO - 2018-05-11 01:01:19 --> Helper loaded: string_helper
INFO - 2018-05-11 01:01:19 --> Database Driver Class Initialized
DEBUG - 2018-05-11 01:01:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-11 01:01:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-11 01:01:19 --> Email Class Initialized
INFO - 2018-05-11 01:01:19 --> Controller Class Initialized
DEBUG - 2018-05-11 01:01:19 --> Home MX_Controller Initialized
DEBUG - 2018-05-11 01:01:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/login.php
INFO - 2018-05-11 01:01:19 --> Final output sent to browser
DEBUG - 2018-05-11 01:01:19 --> Total execution time: 0.3633
INFO - 2018-05-11 01:01:19 --> Config Class Initialized
INFO - 2018-05-11 01:01:19 --> Hooks Class Initialized
DEBUG - 2018-05-11 01:01:20 --> UTF-8 Support Enabled
INFO - 2018-05-11 01:01:20 --> Utf8 Class Initialized
INFO - 2018-05-11 01:01:44 --> Config Class Initialized
INFO - 2018-05-11 01:01:44 --> Hooks Class Initialized
DEBUG - 2018-05-11 01:01:44 --> UTF-8 Support Enabled
INFO - 2018-05-11 01:01:44 --> Utf8 Class Initialized
INFO - 2018-05-11 01:01:44 --> URI Class Initialized
DEBUG - 2018-05-11 01:01:44 --> No URI present. Default controller set.
INFO - 2018-05-11 01:01:44 --> Router Class Initialized
INFO - 2018-05-11 01:01:44 --> Output Class Initialized
INFO - 2018-05-11 01:01:44 --> Security Class Initialized
DEBUG - 2018-05-11 01:01:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 01:01:44 --> Input Class Initialized
INFO - 2018-05-11 01:01:44 --> Language Class Initialized
INFO - 2018-05-11 01:01:44 --> Language Class Initialized
INFO - 2018-05-11 01:01:44 --> Config Class Initialized
INFO - 2018-05-11 01:01:44 --> Loader Class Initialized
DEBUG - 2018-05-11 01:01:44 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-11 01:01:44 --> Helper loaded: url_helper
INFO - 2018-05-11 01:01:44 --> Helper loaded: form_helper
INFO - 2018-05-11 01:01:44 --> Helper loaded: date_helper
INFO - 2018-05-11 01:01:44 --> Helper loaded: util_helper
INFO - 2018-05-11 01:01:44 --> Helper loaded: text_helper
INFO - 2018-05-11 01:01:44 --> Helper loaded: string_helper
INFO - 2018-05-11 01:01:45 --> Database Driver Class Initialized
DEBUG - 2018-05-11 01:01:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-11 01:01:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-11 01:01:45 --> Email Class Initialized
INFO - 2018-05-11 01:01:45 --> Controller Class Initialized
DEBUG - 2018-05-11 01:01:45 --> Home MX_Controller Initialized
DEBUG - 2018-05-11 01:01:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/login.php
INFO - 2018-05-11 01:01:45 --> Final output sent to browser
DEBUG - 2018-05-11 01:01:45 --> Total execution time: 0.3560
INFO - 2018-05-11 01:02:42 --> Config Class Initialized
INFO - 2018-05-11 01:02:42 --> Hooks Class Initialized
DEBUG - 2018-05-11 01:02:42 --> UTF-8 Support Enabled
INFO - 2018-05-11 01:02:42 --> Utf8 Class Initialized
INFO - 2018-05-11 01:02:42 --> URI Class Initialized
DEBUG - 2018-05-11 01:02:42 --> No URI present. Default controller set.
INFO - 2018-05-11 01:02:42 --> Router Class Initialized
INFO - 2018-05-11 01:02:42 --> Output Class Initialized
INFO - 2018-05-11 01:02:42 --> Security Class Initialized
DEBUG - 2018-05-11 01:02:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 01:02:42 --> Input Class Initialized
INFO - 2018-05-11 01:02:42 --> Language Class Initialized
INFO - 2018-05-11 01:02:42 --> Language Class Initialized
INFO - 2018-05-11 01:02:42 --> Config Class Initialized
INFO - 2018-05-11 01:02:42 --> Loader Class Initialized
DEBUG - 2018-05-11 01:02:42 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-11 01:02:42 --> Helper loaded: url_helper
INFO - 2018-05-11 01:02:42 --> Helper loaded: form_helper
INFO - 2018-05-11 01:02:42 --> Helper loaded: date_helper
INFO - 2018-05-11 01:02:42 --> Helper loaded: util_helper
INFO - 2018-05-11 01:02:42 --> Helper loaded: text_helper
INFO - 2018-05-11 01:02:42 --> Helper loaded: string_helper
INFO - 2018-05-11 01:02:42 --> Database Driver Class Initialized
DEBUG - 2018-05-11 01:02:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-11 01:02:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-11 01:02:43 --> Email Class Initialized
INFO - 2018-05-11 01:02:43 --> Controller Class Initialized
DEBUG - 2018-05-11 01:02:43 --> Home MX_Controller Initialized
DEBUG - 2018-05-11 01:02:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/login.php
INFO - 2018-05-11 01:02:43 --> Final output sent to browser
DEBUG - 2018-05-11 01:02:43 --> Total execution time: 0.3557
INFO - 2018-05-11 01:10:55 --> Config Class Initialized
INFO - 2018-05-11 01:10:55 --> Hooks Class Initialized
DEBUG - 2018-05-11 01:10:55 --> UTF-8 Support Enabled
INFO - 2018-05-11 01:10:55 --> Utf8 Class Initialized
INFO - 2018-05-11 01:10:55 --> URI Class Initialized
DEBUG - 2018-05-11 01:10:55 --> No URI present. Default controller set.
INFO - 2018-05-11 01:10:55 --> Router Class Initialized
INFO - 2018-05-11 01:10:55 --> Output Class Initialized
INFO - 2018-05-11 01:10:55 --> Security Class Initialized
DEBUG - 2018-05-11 01:10:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 01:10:55 --> Input Class Initialized
INFO - 2018-05-11 01:10:55 --> Language Class Initialized
INFO - 2018-05-11 01:10:55 --> Language Class Initialized
INFO - 2018-05-11 01:10:55 --> Config Class Initialized
INFO - 2018-05-11 01:10:55 --> Loader Class Initialized
DEBUG - 2018-05-11 01:10:55 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-11 01:10:55 --> Helper loaded: url_helper
INFO - 2018-05-11 01:10:55 --> Helper loaded: form_helper
INFO - 2018-05-11 01:10:55 --> Helper loaded: date_helper
INFO - 2018-05-11 01:10:55 --> Helper loaded: util_helper
INFO - 2018-05-11 01:10:55 --> Helper loaded: text_helper
INFO - 2018-05-11 01:10:55 --> Helper loaded: string_helper
INFO - 2018-05-11 01:10:55 --> Database Driver Class Initialized
DEBUG - 2018-05-11 01:10:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-11 01:10:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-11 01:10:55 --> Email Class Initialized
INFO - 2018-05-11 01:10:55 --> Controller Class Initialized
DEBUG - 2018-05-11 01:10:56 --> Home MX_Controller Initialized
DEBUG - 2018-05-11 01:10:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/login.php
INFO - 2018-05-11 01:10:56 --> Final output sent to browser
DEBUG - 2018-05-11 01:10:56 --> Total execution time: 0.4043
INFO - 2018-05-11 01:11:30 --> Config Class Initialized
INFO - 2018-05-11 01:11:30 --> Hooks Class Initialized
DEBUG - 2018-05-11 01:11:30 --> UTF-8 Support Enabled
INFO - 2018-05-11 01:11:30 --> Utf8 Class Initialized
INFO - 2018-05-11 01:11:30 --> URI Class Initialized
DEBUG - 2018-05-11 01:11:30 --> No URI present. Default controller set.
INFO - 2018-05-11 01:11:30 --> Router Class Initialized
INFO - 2018-05-11 01:11:30 --> Output Class Initialized
INFO - 2018-05-11 01:11:30 --> Security Class Initialized
DEBUG - 2018-05-11 01:11:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 01:11:30 --> Input Class Initialized
INFO - 2018-05-11 01:11:30 --> Language Class Initialized
INFO - 2018-05-11 01:11:30 --> Language Class Initialized
INFO - 2018-05-11 01:11:30 --> Config Class Initialized
INFO - 2018-05-11 01:11:30 --> Loader Class Initialized
DEBUG - 2018-05-11 01:11:30 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-11 01:11:30 --> Helper loaded: url_helper
INFO - 2018-05-11 01:11:30 --> Helper loaded: form_helper
INFO - 2018-05-11 01:11:30 --> Helper loaded: date_helper
INFO - 2018-05-11 01:11:30 --> Helper loaded: util_helper
INFO - 2018-05-11 01:11:30 --> Helper loaded: text_helper
INFO - 2018-05-11 01:11:30 --> Helper loaded: string_helper
INFO - 2018-05-11 01:11:30 --> Database Driver Class Initialized
DEBUG - 2018-05-11 01:11:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-11 01:11:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-11 01:11:30 --> Email Class Initialized
INFO - 2018-05-11 01:11:30 --> Controller Class Initialized
DEBUG - 2018-05-11 01:11:30 --> Home MX_Controller Initialized
DEBUG - 2018-05-11 01:11:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/login.php
INFO - 2018-05-11 01:11:30 --> Final output sent to browser
DEBUG - 2018-05-11 01:11:30 --> Total execution time: 0.3484
INFO - 2018-05-11 01:11:46 --> Config Class Initialized
INFO - 2018-05-11 01:11:46 --> Hooks Class Initialized
DEBUG - 2018-05-11 01:11:46 --> UTF-8 Support Enabled
INFO - 2018-05-11 01:11:46 --> Utf8 Class Initialized
INFO - 2018-05-11 01:11:46 --> URI Class Initialized
DEBUG - 2018-05-11 01:11:46 --> No URI present. Default controller set.
INFO - 2018-05-11 01:11:46 --> Router Class Initialized
INFO - 2018-05-11 01:11:46 --> Output Class Initialized
INFO - 2018-05-11 01:11:46 --> Security Class Initialized
DEBUG - 2018-05-11 01:11:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 01:11:46 --> Input Class Initialized
INFO - 2018-05-11 01:11:46 --> Language Class Initialized
INFO - 2018-05-11 01:11:46 --> Language Class Initialized
INFO - 2018-05-11 01:11:46 --> Config Class Initialized
INFO - 2018-05-11 01:11:46 --> Loader Class Initialized
DEBUG - 2018-05-11 01:11:46 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-11 01:11:46 --> Helper loaded: url_helper
INFO - 2018-05-11 01:11:46 --> Helper loaded: form_helper
INFO - 2018-05-11 01:11:46 --> Helper loaded: date_helper
INFO - 2018-05-11 01:11:46 --> Helper loaded: util_helper
INFO - 2018-05-11 01:11:46 --> Helper loaded: text_helper
INFO - 2018-05-11 01:11:46 --> Helper loaded: string_helper
INFO - 2018-05-11 01:11:47 --> Database Driver Class Initialized
DEBUG - 2018-05-11 01:11:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-11 01:11:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-11 01:11:47 --> Email Class Initialized
INFO - 2018-05-11 01:11:47 --> Controller Class Initialized
DEBUG - 2018-05-11 01:11:47 --> Home MX_Controller Initialized
DEBUG - 2018-05-11 01:11:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/login.php
INFO - 2018-05-11 01:11:47 --> Final output sent to browser
DEBUG - 2018-05-11 01:11:47 --> Total execution time: 0.3781
INFO - 2018-05-11 01:12:58 --> Config Class Initialized
INFO - 2018-05-11 01:12:58 --> Hooks Class Initialized
DEBUG - 2018-05-11 01:12:58 --> UTF-8 Support Enabled
INFO - 2018-05-11 01:12:58 --> Utf8 Class Initialized
INFO - 2018-05-11 01:12:58 --> URI Class Initialized
DEBUG - 2018-05-11 01:12:58 --> No URI present. Default controller set.
INFO - 2018-05-11 01:12:58 --> Router Class Initialized
INFO - 2018-05-11 01:12:58 --> Output Class Initialized
INFO - 2018-05-11 01:12:58 --> Security Class Initialized
DEBUG - 2018-05-11 01:12:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 01:12:58 --> Input Class Initialized
INFO - 2018-05-11 01:12:58 --> Language Class Initialized
INFO - 2018-05-11 01:12:58 --> Language Class Initialized
INFO - 2018-05-11 01:12:58 --> Config Class Initialized
INFO - 2018-05-11 01:12:58 --> Loader Class Initialized
DEBUG - 2018-05-11 01:12:58 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-11 01:12:58 --> Helper loaded: url_helper
INFO - 2018-05-11 01:12:58 --> Helper loaded: form_helper
INFO - 2018-05-11 01:12:58 --> Helper loaded: date_helper
INFO - 2018-05-11 01:12:58 --> Helper loaded: util_helper
INFO - 2018-05-11 01:12:58 --> Helper loaded: text_helper
INFO - 2018-05-11 01:12:58 --> Helper loaded: string_helper
INFO - 2018-05-11 01:12:58 --> Database Driver Class Initialized
DEBUG - 2018-05-11 01:12:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-11 01:12:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-11 01:12:58 --> Email Class Initialized
INFO - 2018-05-11 01:12:58 --> Controller Class Initialized
DEBUG - 2018-05-11 01:12:58 --> Home MX_Controller Initialized
DEBUG - 2018-05-11 01:12:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/login.php
INFO - 2018-05-11 01:12:58 --> Final output sent to browser
DEBUG - 2018-05-11 01:12:58 --> Total execution time: 0.6338
INFO - 2018-05-11 01:33:31 --> Config Class Initialized
INFO - 2018-05-11 01:33:31 --> Hooks Class Initialized
DEBUG - 2018-05-11 01:33:31 --> UTF-8 Support Enabled
INFO - 2018-05-11 01:33:31 --> Utf8 Class Initialized
INFO - 2018-05-11 01:33:31 --> URI Class Initialized
DEBUG - 2018-05-11 01:33:31 --> No URI present. Default controller set.
INFO - 2018-05-11 01:33:31 --> Router Class Initialized
INFO - 2018-05-11 01:33:31 --> Output Class Initialized
INFO - 2018-05-11 01:33:31 --> Security Class Initialized
DEBUG - 2018-05-11 01:33:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 01:33:31 --> Input Class Initialized
INFO - 2018-05-11 01:33:31 --> Language Class Initialized
INFO - 2018-05-11 01:33:31 --> Language Class Initialized
INFO - 2018-05-11 01:33:31 --> Config Class Initialized
INFO - 2018-05-11 01:33:31 --> Loader Class Initialized
DEBUG - 2018-05-11 01:33:31 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-11 01:33:31 --> Helper loaded: url_helper
INFO - 2018-05-11 01:33:31 --> Helper loaded: form_helper
INFO - 2018-05-11 01:33:31 --> Helper loaded: date_helper
INFO - 2018-05-11 01:33:31 --> Helper loaded: util_helper
INFO - 2018-05-11 01:33:31 --> Helper loaded: text_helper
INFO - 2018-05-11 01:33:31 --> Helper loaded: string_helper
INFO - 2018-05-11 01:33:31 --> Database Driver Class Initialized
DEBUG - 2018-05-11 01:33:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-11 01:33:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-11 01:33:31 --> Email Class Initialized
INFO - 2018-05-11 01:33:31 --> Controller Class Initialized
DEBUG - 2018-05-11 01:33:31 --> Home MX_Controller Initialized
DEBUG - 2018-05-11 01:33:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/login.php
INFO - 2018-05-11 01:33:31 --> Final output sent to browser
DEBUG - 2018-05-11 01:33:31 --> Total execution time: 0.3093
INFO - 2018-05-11 01:35:30 --> Config Class Initialized
INFO - 2018-05-11 01:35:30 --> Hooks Class Initialized
DEBUG - 2018-05-11 01:35:30 --> UTF-8 Support Enabled
INFO - 2018-05-11 01:35:30 --> Utf8 Class Initialized
INFO - 2018-05-11 01:35:30 --> URI Class Initialized
INFO - 2018-05-11 01:35:30 --> Router Class Initialized
INFO - 2018-05-11 01:35:30 --> Output Class Initialized
INFO - 2018-05-11 01:35:30 --> Security Class Initialized
DEBUG - 2018-05-11 01:35:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 01:35:30 --> Input Class Initialized
INFO - 2018-05-11 01:35:30 --> Language Class Initialized
INFO - 2018-05-11 01:35:30 --> Language Class Initialized
INFO - 2018-05-11 01:35:30 --> Config Class Initialized
INFO - 2018-05-11 01:35:30 --> Loader Class Initialized
DEBUG - 2018-05-11 01:35:30 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-11 01:35:30 --> Helper loaded: url_helper
INFO - 2018-05-11 01:35:30 --> Helper loaded: form_helper
INFO - 2018-05-11 01:35:30 --> Helper loaded: date_helper
INFO - 2018-05-11 01:35:30 --> Helper loaded: util_helper
INFO - 2018-05-11 01:35:30 --> Helper loaded: text_helper
INFO - 2018-05-11 01:35:30 --> Helper loaded: string_helper
INFO - 2018-05-11 01:35:30 --> Database Driver Class Initialized
DEBUG - 2018-05-11 01:35:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-11 01:35:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-11 01:35:30 --> Email Class Initialized
INFO - 2018-05-11 01:35:30 --> Controller Class Initialized
DEBUG - 2018-05-11 01:35:30 --> Login MX_Controller Initialized
INFO - 2018-05-11 01:35:30 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-11 01:35:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-11 01:35:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
ERROR - 2018-05-11 01:35:30 --> Severity: Notice --> Undefined index: admin_user_id E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php 531
INFO - 2018-05-11 01:35:30 --> Config Class Initialized
INFO - 2018-05-11 01:35:30 --> Hooks Class Initialized
DEBUG - 2018-05-11 01:35:30 --> UTF-8 Support Enabled
INFO - 2018-05-11 01:35:30 --> Utf8 Class Initialized
INFO - 2018-05-11 01:35:30 --> URI Class Initialized
INFO - 2018-05-11 01:35:30 --> Router Class Initialized
INFO - 2018-05-11 01:35:30 --> Output Class Initialized
INFO - 2018-05-11 01:35:30 --> Security Class Initialized
DEBUG - 2018-05-11 01:35:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 01:35:30 --> Input Class Initialized
INFO - 2018-05-11 01:35:30 --> Language Class Initialized
INFO - 2018-05-11 01:35:30 --> Language Class Initialized
INFO - 2018-05-11 01:35:30 --> Config Class Initialized
INFO - 2018-05-11 01:35:30 --> Loader Class Initialized
DEBUG - 2018-05-11 01:35:30 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-11 01:35:30 --> Helper loaded: url_helper
INFO - 2018-05-11 01:35:30 --> Helper loaded: form_helper
INFO - 2018-05-11 01:35:30 --> Helper loaded: date_helper
INFO - 2018-05-11 01:35:30 --> Helper loaded: util_helper
INFO - 2018-05-11 01:35:30 --> Helper loaded: text_helper
INFO - 2018-05-11 01:35:30 --> Helper loaded: string_helper
INFO - 2018-05-11 01:35:30 --> Database Driver Class Initialized
DEBUG - 2018-05-11 01:35:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-11 01:35:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-11 01:35:30 --> Email Class Initialized
INFO - 2018-05-11 01:35:30 --> Controller Class Initialized
DEBUG - 2018-05-11 01:35:30 --> Admin MX_Controller Initialized
INFO - 2018-05-11 01:35:30 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-11 01:35:30 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-11 01:35:30 --> Login MX_Controller Initialized
DEBUG - 2018-05-11 01:35:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-11 01:35:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-11 01:35:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/logins/login.php
INFO - 2018-05-11 01:35:31 --> Config Class Initialized
INFO - 2018-05-11 01:35:31 --> Hooks Class Initialized
DEBUG - 2018-05-11 01:35:31 --> UTF-8 Support Enabled
INFO - 2018-05-11 01:35:31 --> Utf8 Class Initialized
INFO - 2018-05-11 01:35:31 --> URI Class Initialized
INFO - 2018-05-11 01:35:31 --> Router Class Initialized
INFO - 2018-05-11 01:35:31 --> Output Class Initialized
INFO - 2018-05-11 01:35:31 --> Security Class Initialized
DEBUG - 2018-05-11 01:35:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 01:35:31 --> Input Class Initialized
INFO - 2018-05-11 01:35:31 --> Language Class Initialized
ERROR - 2018-05-11 01:35:31 --> 404 Page Not Found: /index
INFO - 2018-05-11 01:35:31 --> Config Class Initialized
INFO - 2018-05-11 01:35:31 --> Hooks Class Initialized
DEBUG - 2018-05-11 01:35:31 --> UTF-8 Support Enabled
INFO - 2018-05-11 01:35:31 --> Utf8 Class Initialized
INFO - 2018-05-11 01:35:31 --> URI Class Initialized
INFO - 2018-05-11 01:35:31 --> Router Class Initialized
INFO - 2018-05-11 01:35:31 --> Output Class Initialized
INFO - 2018-05-11 01:35:31 --> Security Class Initialized
DEBUG - 2018-05-11 01:35:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 01:35:31 --> Input Class Initialized
INFO - 2018-05-11 01:35:31 --> Language Class Initialized
ERROR - 2018-05-11 01:35:31 --> 404 Page Not Found: /index
INFO - 2018-05-11 01:35:41 --> Config Class Initialized
INFO - 2018-05-11 01:35:41 --> Hooks Class Initialized
DEBUG - 2018-05-11 01:35:41 --> UTF-8 Support Enabled
INFO - 2018-05-11 01:35:41 --> Utf8 Class Initialized
INFO - 2018-05-11 01:35:41 --> URI Class Initialized
INFO - 2018-05-11 01:35:41 --> Router Class Initialized
INFO - 2018-05-11 01:35:41 --> Output Class Initialized
INFO - 2018-05-11 01:35:41 --> Security Class Initialized
DEBUG - 2018-05-11 01:35:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 01:35:41 --> Input Class Initialized
INFO - 2018-05-11 01:35:41 --> Language Class Initialized
INFO - 2018-05-11 01:35:41 --> Language Class Initialized
INFO - 2018-05-11 01:35:41 --> Config Class Initialized
INFO - 2018-05-11 01:35:41 --> Loader Class Initialized
DEBUG - 2018-05-11 01:35:41 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-11 01:35:41 --> Helper loaded: url_helper
INFO - 2018-05-11 01:35:41 --> Helper loaded: form_helper
INFO - 2018-05-11 01:35:41 --> Helper loaded: date_helper
INFO - 2018-05-11 01:35:41 --> Helper loaded: util_helper
INFO - 2018-05-11 01:35:42 --> Helper loaded: text_helper
INFO - 2018-05-11 01:35:42 --> Helper loaded: string_helper
INFO - 2018-05-11 01:35:42 --> Database Driver Class Initialized
DEBUG - 2018-05-11 01:35:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-11 01:35:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-11 01:35:42 --> Email Class Initialized
INFO - 2018-05-11 01:35:42 --> Controller Class Initialized
DEBUG - 2018-05-11 01:35:42 --> Login MX_Controller Initialized
INFO - 2018-05-11 01:35:42 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-11 01:35:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-11 01:35:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-11 01:45:21 --> Config Class Initialized
INFO - 2018-05-11 01:45:21 --> Hooks Class Initialized
DEBUG - 2018-05-11 01:45:21 --> UTF-8 Support Enabled
INFO - 2018-05-11 01:45:21 --> Utf8 Class Initialized
INFO - 2018-05-11 01:45:21 --> URI Class Initialized
INFO - 2018-05-11 01:45:21 --> Router Class Initialized
INFO - 2018-05-11 01:45:21 --> Output Class Initialized
INFO - 2018-05-11 01:45:21 --> Security Class Initialized
DEBUG - 2018-05-11 01:45:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 01:45:21 --> Input Class Initialized
INFO - 2018-05-11 01:45:21 --> Language Class Initialized
ERROR - 2018-05-11 01:45:21 --> 404 Page Not Found: /index
INFO - 2018-05-11 01:45:21 --> Config Class Initialized
INFO - 2018-05-11 01:45:21 --> Hooks Class Initialized
DEBUG - 2018-05-11 01:45:21 --> UTF-8 Support Enabled
INFO - 2018-05-11 01:45:21 --> Utf8 Class Initialized
INFO - 2018-05-11 01:45:21 --> URI Class Initialized
INFO - 2018-05-11 01:45:21 --> Router Class Initialized
INFO - 2018-05-11 01:45:21 --> Output Class Initialized
INFO - 2018-05-11 01:45:21 --> Security Class Initialized
DEBUG - 2018-05-11 01:45:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 01:45:21 --> Input Class Initialized
INFO - 2018-05-11 01:45:21 --> Language Class Initialized
ERROR - 2018-05-11 01:45:21 --> 404 Page Not Found: /index
INFO - 2018-05-11 01:45:21 --> Config Class Initialized
INFO - 2018-05-11 01:45:21 --> Config Class Initialized
INFO - 2018-05-11 01:45:21 --> Config Class Initialized
INFO - 2018-05-11 01:45:21 --> Config Class Initialized
INFO - 2018-05-11 01:45:21 --> Config Class Initialized
INFO - 2018-05-11 01:45:21 --> Config Class Initialized
INFO - 2018-05-11 01:45:21 --> Hooks Class Initialized
INFO - 2018-05-11 01:45:21 --> Hooks Class Initialized
INFO - 2018-05-11 01:45:21 --> Hooks Class Initialized
INFO - 2018-05-11 01:45:21 --> Hooks Class Initialized
INFO - 2018-05-11 01:45:21 --> Hooks Class Initialized
INFO - 2018-05-11 01:45:21 --> Hooks Class Initialized
DEBUG - 2018-05-11 01:45:21 --> UTF-8 Support Enabled
DEBUG - 2018-05-11 01:45:21 --> UTF-8 Support Enabled
DEBUG - 2018-05-11 01:45:21 --> UTF-8 Support Enabled
DEBUG - 2018-05-11 01:45:21 --> UTF-8 Support Enabled
DEBUG - 2018-05-11 01:45:21 --> UTF-8 Support Enabled
DEBUG - 2018-05-11 01:45:21 --> UTF-8 Support Enabled
INFO - 2018-05-11 01:45:21 --> Utf8 Class Initialized
INFO - 2018-05-11 01:45:21 --> Utf8 Class Initialized
INFO - 2018-05-11 01:45:21 --> Utf8 Class Initialized
INFO - 2018-05-11 01:45:21 --> Utf8 Class Initialized
INFO - 2018-05-11 01:45:21 --> Utf8 Class Initialized
INFO - 2018-05-11 01:45:21 --> Utf8 Class Initialized
INFO - 2018-05-11 01:45:21 --> URI Class Initialized
INFO - 2018-05-11 01:45:21 --> URI Class Initialized
INFO - 2018-05-11 01:45:21 --> URI Class Initialized
INFO - 2018-05-11 01:45:21 --> URI Class Initialized
INFO - 2018-05-11 01:45:21 --> URI Class Initialized
INFO - 2018-05-11 01:45:21 --> URI Class Initialized
INFO - 2018-05-11 01:45:21 --> Router Class Initialized
INFO - 2018-05-11 01:45:21 --> Router Class Initialized
INFO - 2018-05-11 01:45:21 --> Router Class Initialized
INFO - 2018-05-11 01:45:21 --> Router Class Initialized
INFO - 2018-05-11 01:45:21 --> Router Class Initialized
INFO - 2018-05-11 01:45:21 --> Router Class Initialized
INFO - 2018-05-11 01:45:21 --> Output Class Initialized
INFO - 2018-05-11 01:45:21 --> Output Class Initialized
INFO - 2018-05-11 01:45:21 --> Output Class Initialized
INFO - 2018-05-11 01:45:21 --> Output Class Initialized
INFO - 2018-05-11 01:45:21 --> Output Class Initialized
INFO - 2018-05-11 01:45:21 --> Output Class Initialized
INFO - 2018-05-11 01:45:21 --> Security Class Initialized
INFO - 2018-05-11 01:45:21 --> Security Class Initialized
INFO - 2018-05-11 01:45:21 --> Security Class Initialized
INFO - 2018-05-11 01:45:21 --> Security Class Initialized
INFO - 2018-05-11 01:45:21 --> Security Class Initialized
INFO - 2018-05-11 01:45:22 --> Security Class Initialized
DEBUG - 2018-05-11 01:45:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-11 01:45:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-11 01:45:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-11 01:45:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-11 01:45:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-11 01:45:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 01:45:22 --> Input Class Initialized
INFO - 2018-05-11 01:45:22 --> Input Class Initialized
INFO - 2018-05-11 01:45:22 --> Input Class Initialized
INFO - 2018-05-11 01:45:22 --> Input Class Initialized
INFO - 2018-05-11 01:45:22 --> Input Class Initialized
INFO - 2018-05-11 01:45:22 --> Input Class Initialized
INFO - 2018-05-11 01:45:22 --> Language Class Initialized
INFO - 2018-05-11 01:45:22 --> Language Class Initialized
INFO - 2018-05-11 01:45:22 --> Language Class Initialized
INFO - 2018-05-11 01:45:22 --> Language Class Initialized
INFO - 2018-05-11 01:45:22 --> Language Class Initialized
INFO - 2018-05-11 01:45:22 --> Language Class Initialized
ERROR - 2018-05-11 01:45:22 --> 404 Page Not Found: /index
ERROR - 2018-05-11 01:45:22 --> 404 Page Not Found: /index
ERROR - 2018-05-11 01:45:22 --> 404 Page Not Found: /index
ERROR - 2018-05-11 01:45:22 --> 404 Page Not Found: /index
ERROR - 2018-05-11 01:45:22 --> 404 Page Not Found: /index
ERROR - 2018-05-11 01:45:22 --> 404 Page Not Found: /index
INFO - 2018-05-11 01:45:22 --> Config Class Initialized
INFO - 2018-05-11 01:45:22 --> Hooks Class Initialized
INFO - 2018-05-11 01:45:22 --> Config Class Initialized
DEBUG - 2018-05-11 01:45:22 --> UTF-8 Support Enabled
INFO - 2018-05-11 01:45:22 --> Config Class Initialized
INFO - 2018-05-11 01:45:22 --> Utf8 Class Initialized
INFO - 2018-05-11 01:45:22 --> Config Class Initialized
INFO - 2018-05-11 01:45:22 --> Hooks Class Initialized
INFO - 2018-05-11 01:45:22 --> Hooks Class Initialized
INFO - 2018-05-11 01:45:22 --> Hooks Class Initialized
INFO - 2018-05-11 01:45:22 --> URI Class Initialized
INFO - 2018-05-11 01:45:22 --> Router Class Initialized
DEBUG - 2018-05-11 01:45:22 --> UTF-8 Support Enabled
DEBUG - 2018-05-11 01:45:22 --> UTF-8 Support Enabled
DEBUG - 2018-05-11 01:45:22 --> UTF-8 Support Enabled
INFO - 2018-05-11 01:45:22 --> Utf8 Class Initialized
INFO - 2018-05-11 01:45:22 --> Utf8 Class Initialized
INFO - 2018-05-11 01:45:22 --> Output Class Initialized
INFO - 2018-05-11 01:45:22 --> Utf8 Class Initialized
INFO - 2018-05-11 01:45:22 --> URI Class Initialized
INFO - 2018-05-11 01:45:22 --> URI Class Initialized
INFO - 2018-05-11 01:45:22 --> Security Class Initialized
INFO - 2018-05-11 01:45:22 --> Config Class Initialized
INFO - 2018-05-11 01:45:22 --> URI Class Initialized
INFO - 2018-05-11 01:45:22 --> Hooks Class Initialized
DEBUG - 2018-05-11 01:45:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 01:45:22 --> Router Class Initialized
INFO - 2018-05-11 01:45:22 --> Router Class Initialized
INFO - 2018-05-11 01:45:22 --> Router Class Initialized
INFO - 2018-05-11 01:45:22 --> Input Class Initialized
INFO - 2018-05-11 01:45:22 --> Output Class Initialized
INFO - 2018-05-11 01:45:22 --> Output Class Initialized
DEBUG - 2018-05-11 01:45:22 --> UTF-8 Support Enabled
INFO - 2018-05-11 01:45:22 --> Output Class Initialized
INFO - 2018-05-11 01:45:22 --> Utf8 Class Initialized
INFO - 2018-05-11 01:45:22 --> Security Class Initialized
INFO - 2018-05-11 01:45:22 --> Security Class Initialized
INFO - 2018-05-11 01:45:22 --> Language Class Initialized
INFO - 2018-05-11 01:45:22 --> Security Class Initialized
INFO - 2018-05-11 01:45:22 --> URI Class Initialized
DEBUG - 2018-05-11 01:45:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-05-11 01:45:22 --> 404 Page Not Found: /index
DEBUG - 2018-05-11 01:45:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-11 01:45:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 01:45:22 --> Input Class Initialized
INFO - 2018-05-11 01:45:22 --> Router Class Initialized
INFO - 2018-05-11 01:45:22 --> Input Class Initialized
INFO - 2018-05-11 01:45:22 --> Language Class Initialized
INFO - 2018-05-11 01:45:22 --> Language Class Initialized
INFO - 2018-05-11 01:45:22 --> Output Class Initialized
INFO - 2018-05-11 01:45:22 --> Input Class Initialized
ERROR - 2018-05-11 01:45:22 --> 404 Page Not Found: /index
INFO - 2018-05-11 01:45:22 --> Security Class Initialized
INFO - 2018-05-11 01:45:22 --> Language Class Initialized
ERROR - 2018-05-11 01:45:22 --> 404 Page Not Found: /index
DEBUG - 2018-05-11 01:45:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-05-11 01:45:22 --> 404 Page Not Found: /index
INFO - 2018-05-11 01:45:22 --> Input Class Initialized
INFO - 2018-05-11 01:45:22 --> Language Class Initialized
ERROR - 2018-05-11 01:45:22 --> 404 Page Not Found: /index
INFO - 2018-05-11 01:45:22 --> Config Class Initialized
INFO - 2018-05-11 01:45:22 --> Hooks Class Initialized
DEBUG - 2018-05-11 01:45:22 --> UTF-8 Support Enabled
INFO - 2018-05-11 01:45:22 --> Config Class Initialized
INFO - 2018-05-11 01:45:22 --> Utf8 Class Initialized
INFO - 2018-05-11 01:45:22 --> Config Class Initialized
INFO - 2018-05-11 01:45:22 --> URI Class Initialized
INFO - 2018-05-11 01:45:22 --> Router Class Initialized
INFO - 2018-05-11 01:45:22 --> Config Class Initialized
INFO - 2018-05-11 01:45:22 --> Output Class Initialized
INFO - 2018-05-11 01:45:22 --> Config Class Initialized
INFO - 2018-05-11 01:45:22 --> Hooks Class Initialized
INFO - 2018-05-11 01:45:22 --> Hooks Class Initialized
INFO - 2018-05-11 01:45:22 --> Hooks Class Initialized
INFO - 2018-05-11 01:45:22 --> Hooks Class Initialized
INFO - 2018-05-11 01:45:22 --> Security Class Initialized
DEBUG - 2018-05-11 01:45:22 --> UTF-8 Support Enabled
DEBUG - 2018-05-11 01:45:22 --> UTF-8 Support Enabled
DEBUG - 2018-05-11 01:45:22 --> UTF-8 Support Enabled
DEBUG - 2018-05-11 01:45:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-11 01:45:22 --> UTF-8 Support Enabled
INFO - 2018-05-11 01:45:22 --> Utf8 Class Initialized
INFO - 2018-05-11 01:45:22 --> Utf8 Class Initialized
INFO - 2018-05-11 01:45:22 --> Utf8 Class Initialized
INFO - 2018-05-11 01:45:22 --> Utf8 Class Initialized
INFO - 2018-05-11 01:45:22 --> Input Class Initialized
INFO - 2018-05-11 01:45:22 --> URI Class Initialized
INFO - 2018-05-11 01:45:22 --> URI Class Initialized
INFO - 2018-05-11 01:45:22 --> URI Class Initialized
INFO - 2018-05-11 01:45:22 --> Language Class Initialized
INFO - 2018-05-11 01:45:22 --> URI Class Initialized
INFO - 2018-05-11 01:45:22 --> Router Class Initialized
INFO - 2018-05-11 01:45:22 --> Router Class Initialized
INFO - 2018-05-11 01:45:22 --> Router Class Initialized
INFO - 2018-05-11 01:45:22 --> Router Class Initialized
ERROR - 2018-05-11 01:45:22 --> 404 Page Not Found: /index
INFO - 2018-05-11 01:45:22 --> Output Class Initialized
INFO - 2018-05-11 01:45:22 --> Output Class Initialized
INFO - 2018-05-11 01:45:22 --> Output Class Initialized
INFO - 2018-05-11 01:45:22 --> Output Class Initialized
INFO - 2018-05-11 01:45:22 --> Security Class Initialized
INFO - 2018-05-11 01:45:22 --> Security Class Initialized
INFO - 2018-05-11 01:45:22 --> Security Class Initialized
INFO - 2018-05-11 01:45:22 --> Security Class Initialized
DEBUG - 2018-05-11 01:45:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-11 01:45:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-11 01:45:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-11 01:45:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 01:45:22 --> Input Class Initialized
INFO - 2018-05-11 01:45:22 --> Input Class Initialized
INFO - 2018-05-11 01:45:22 --> Input Class Initialized
INFO - 2018-05-11 01:45:22 --> Input Class Initialized
INFO - 2018-05-11 01:45:22 --> Language Class Initialized
INFO - 2018-05-11 01:45:22 --> Language Class Initialized
INFO - 2018-05-11 01:45:22 --> Language Class Initialized
INFO - 2018-05-11 01:45:22 --> Language Class Initialized
ERROR - 2018-05-11 01:45:22 --> 404 Page Not Found: /index
ERROR - 2018-05-11 01:45:22 --> 404 Page Not Found: /index
ERROR - 2018-05-11 01:45:22 --> 404 Page Not Found: /index
ERROR - 2018-05-11 01:45:22 --> 404 Page Not Found: /index
INFO - 2018-05-11 01:45:24 --> Config Class Initialized
INFO - 2018-05-11 01:45:24 --> Hooks Class Initialized
DEBUG - 2018-05-11 01:45:24 --> UTF-8 Support Enabled
INFO - 2018-05-11 01:45:24 --> Utf8 Class Initialized
INFO - 2018-05-11 01:45:24 --> URI Class Initialized
INFO - 2018-05-11 01:45:24 --> Router Class Initialized
INFO - 2018-05-11 01:45:24 --> Output Class Initialized
INFO - 2018-05-11 01:45:24 --> Security Class Initialized
DEBUG - 2018-05-11 01:45:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 01:45:24 --> Input Class Initialized
INFO - 2018-05-11 01:45:24 --> Language Class Initialized
ERROR - 2018-05-11 01:45:24 --> 404 Page Not Found: /index
INFO - 2018-05-11 01:45:24 --> Config Class Initialized
INFO - 2018-05-11 01:45:24 --> Hooks Class Initialized
DEBUG - 2018-05-11 01:45:24 --> UTF-8 Support Enabled
INFO - 2018-05-11 01:45:24 --> Utf8 Class Initialized
INFO - 2018-05-11 01:45:24 --> URI Class Initialized
INFO - 2018-05-11 01:45:24 --> Router Class Initialized
INFO - 2018-05-11 01:45:24 --> Output Class Initialized
INFO - 2018-05-11 01:45:24 --> Security Class Initialized
DEBUG - 2018-05-11 01:45:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 01:45:24 --> Input Class Initialized
INFO - 2018-05-11 01:45:24 --> Language Class Initialized
ERROR - 2018-05-11 01:45:24 --> 404 Page Not Found: /index
INFO - 2018-05-11 01:45:24 --> Config Class Initialized
INFO - 2018-05-11 01:45:24 --> Hooks Class Initialized
DEBUG - 2018-05-11 01:45:24 --> UTF-8 Support Enabled
INFO - 2018-05-11 01:45:24 --> Utf8 Class Initialized
INFO - 2018-05-11 01:45:24 --> URI Class Initialized
INFO - 2018-05-11 01:45:24 --> Router Class Initialized
INFO - 2018-05-11 01:45:24 --> Output Class Initialized
INFO - 2018-05-11 01:45:24 --> Security Class Initialized
DEBUG - 2018-05-11 01:45:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 01:45:24 --> Input Class Initialized
INFO - 2018-05-11 01:45:24 --> Language Class Initialized
ERROR - 2018-05-11 01:45:24 --> 404 Page Not Found: /index
INFO - 2018-05-11 01:46:57 --> Config Class Initialized
INFO - 2018-05-11 01:46:57 --> Hooks Class Initialized
DEBUG - 2018-05-11 01:46:57 --> UTF-8 Support Enabled
INFO - 2018-05-11 01:46:57 --> Utf8 Class Initialized
INFO - 2018-05-11 01:46:57 --> URI Class Initialized
INFO - 2018-05-11 01:46:57 --> Router Class Initialized
INFO - 2018-05-11 01:46:58 --> Output Class Initialized
INFO - 2018-05-11 01:46:58 --> Security Class Initialized
DEBUG - 2018-05-11 01:46:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 01:46:58 --> Input Class Initialized
INFO - 2018-05-11 01:46:58 --> Language Class Initialized
ERROR - 2018-05-11 01:46:58 --> 404 Page Not Found: /index
INFO - 2018-05-11 01:46:58 --> Config Class Initialized
INFO - 2018-05-11 01:46:58 --> Config Class Initialized
INFO - 2018-05-11 01:46:58 --> Hooks Class Initialized
INFO - 2018-05-11 01:46:58 --> Hooks Class Initialized
INFO - 2018-05-11 01:46:58 --> Config Class Initialized
INFO - 2018-05-11 01:46:58 --> Config Class Initialized
INFO - 2018-05-11 01:46:58 --> Hooks Class Initialized
INFO - 2018-05-11 01:46:58 --> Hooks Class Initialized
DEBUG - 2018-05-11 01:46:58 --> UTF-8 Support Enabled
INFO - 2018-05-11 01:46:58 --> Config Class Initialized
DEBUG - 2018-05-11 01:46:58 --> UTF-8 Support Enabled
INFO - 2018-05-11 01:46:58 --> Hooks Class Initialized
DEBUG - 2018-05-11 01:46:58 --> UTF-8 Support Enabled
INFO - 2018-05-11 01:46:58 --> Utf8 Class Initialized
DEBUG - 2018-05-11 01:46:58 --> UTF-8 Support Enabled
INFO - 2018-05-11 01:46:58 --> Utf8 Class Initialized
INFO - 2018-05-11 01:46:58 --> Utf8 Class Initialized
DEBUG - 2018-05-11 01:46:58 --> UTF-8 Support Enabled
INFO - 2018-05-11 01:46:58 --> Utf8 Class Initialized
INFO - 2018-05-11 01:46:58 --> URI Class Initialized
INFO - 2018-05-11 01:46:58 --> URI Class Initialized
INFO - 2018-05-11 01:46:58 --> Utf8 Class Initialized
INFO - 2018-05-11 01:46:58 --> URI Class Initialized
INFO - 2018-05-11 01:46:58 --> Router Class Initialized
INFO - 2018-05-11 01:46:58 --> Router Class Initialized
INFO - 2018-05-11 01:46:58 --> URI Class Initialized
INFO - 2018-05-11 01:46:58 --> URI Class Initialized
INFO - 2018-05-11 01:46:58 --> Router Class Initialized
INFO - 2018-05-11 01:46:58 --> Output Class Initialized
INFO - 2018-05-11 01:46:58 --> Output Class Initialized
INFO - 2018-05-11 01:46:58 --> Router Class Initialized
INFO - 2018-05-11 01:46:58 --> Security Class Initialized
INFO - 2018-05-11 01:46:58 --> Output Class Initialized
INFO - 2018-05-11 01:46:58 --> Security Class Initialized
INFO - 2018-05-11 01:46:58 --> Output Class Initialized
INFO - 2018-05-11 01:46:58 --> Router Class Initialized
INFO - 2018-05-11 01:46:58 --> Security Class Initialized
DEBUG - 2018-05-11 01:46:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 01:46:58 --> Output Class Initialized
INFO - 2018-05-11 01:46:58 --> Security Class Initialized
DEBUG - 2018-05-11 01:46:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-11 01:46:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 01:46:58 --> Input Class Initialized
INFO - 2018-05-11 01:46:58 --> Security Class Initialized
DEBUG - 2018-05-11 01:46:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 01:46:58 --> Input Class Initialized
INFO - 2018-05-11 01:46:58 --> Input Class Initialized
DEBUG - 2018-05-11 01:46:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 01:46:58 --> Language Class Initialized
INFO - 2018-05-11 01:46:58 --> Input Class Initialized
INFO - 2018-05-11 01:46:58 --> Language Class Initialized
ERROR - 2018-05-11 01:46:58 --> 404 Page Not Found: /index
INFO - 2018-05-11 01:46:58 --> Input Class Initialized
INFO - 2018-05-11 01:46:58 --> Language Class Initialized
ERROR - 2018-05-11 01:46:58 --> 404 Page Not Found: /index
INFO - 2018-05-11 01:46:58 --> Language Class Initialized
INFO - 2018-05-11 01:46:58 --> Language Class Initialized
ERROR - 2018-05-11 01:46:58 --> 404 Page Not Found: /index
ERROR - 2018-05-11 01:46:58 --> 404 Page Not Found: /index
INFO - 2018-05-11 01:46:58 --> Config Class Initialized
INFO - 2018-05-11 01:46:58 --> Hooks Class Initialized
ERROR - 2018-05-11 01:46:58 --> 404 Page Not Found: /index
DEBUG - 2018-05-11 01:46:58 --> UTF-8 Support Enabled
INFO - 2018-05-11 01:46:58 --> Utf8 Class Initialized
INFO - 2018-05-11 01:46:58 --> Config Class Initialized
INFO - 2018-05-11 01:46:58 --> Config Class Initialized
INFO - 2018-05-11 01:46:58 --> Config Class Initialized
INFO - 2018-05-11 01:46:58 --> Hooks Class Initialized
INFO - 2018-05-11 01:46:58 --> URI Class Initialized
INFO - 2018-05-11 01:46:58 --> Hooks Class Initialized
INFO - 2018-05-11 01:46:58 --> Hooks Class Initialized
DEBUG - 2018-05-11 01:46:58 --> UTF-8 Support Enabled
DEBUG - 2018-05-11 01:46:58 --> UTF-8 Support Enabled
INFO - 2018-05-11 01:46:58 --> Router Class Initialized
DEBUG - 2018-05-11 01:46:58 --> UTF-8 Support Enabled
INFO - 2018-05-11 01:46:58 --> Utf8 Class Initialized
INFO - 2018-05-11 01:46:58 --> Utf8 Class Initialized
INFO - 2018-05-11 01:46:58 --> Utf8 Class Initialized
INFO - 2018-05-11 01:46:58 --> Output Class Initialized
INFO - 2018-05-11 01:46:58 --> URI Class Initialized
INFO - 2018-05-11 01:46:58 --> Security Class Initialized
INFO - 2018-05-11 01:46:58 --> Router Class Initialized
DEBUG - 2018-05-11 01:46:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 01:46:58 --> Input Class Initialized
INFO - 2018-05-11 01:46:58 --> Output Class Initialized
INFO - 2018-05-11 01:46:58 --> URI Class Initialized
INFO - 2018-05-11 01:46:58 --> URI Class Initialized
INFO - 2018-05-11 01:46:58 --> Security Class Initialized
DEBUG - 2018-05-11 01:46:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 01:46:58 --> Input Class Initialized
INFO - 2018-05-11 01:46:58 --> Language Class Initialized
ERROR - 2018-05-11 01:46:58 --> 404 Page Not Found: /index
INFO - 2018-05-11 01:46:58 --> Language Class Initialized
ERROR - 2018-05-11 01:46:58 --> 404 Page Not Found: /index
INFO - 2018-05-11 01:46:58 --> Config Class Initialized
INFO - 2018-05-11 01:46:58 --> Router Class Initialized
INFO - 2018-05-11 01:46:58 --> Hooks Class Initialized
INFO - 2018-05-11 01:46:58 --> Router Class Initialized
INFO - 2018-05-11 01:46:58 --> Config Class Initialized
INFO - 2018-05-11 01:46:58 --> Output Class Initialized
INFO - 2018-05-11 01:46:59 --> Hooks Class Initialized
INFO - 2018-05-11 01:46:59 --> Output Class Initialized
DEBUG - 2018-05-11 01:46:59 --> UTF-8 Support Enabled
INFO - 2018-05-11 01:46:59 --> Security Class Initialized
INFO - 2018-05-11 01:46:59 --> Utf8 Class Initialized
INFO - 2018-05-11 01:46:59 --> Security Class Initialized
DEBUG - 2018-05-11 01:46:59 --> UTF-8 Support Enabled
DEBUG - 2018-05-11 01:46:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 01:46:59 --> Utf8 Class Initialized
DEBUG - 2018-05-11 01:46:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 01:46:59 --> URI Class Initialized
INFO - 2018-05-11 01:46:59 --> Input Class Initialized
INFO - 2018-05-11 01:46:59 --> URI Class Initialized
INFO - 2018-05-11 01:46:59 --> Router Class Initialized
INFO - 2018-05-11 01:46:59 --> Input Class Initialized
INFO - 2018-05-11 01:46:59 --> Router Class Initialized
INFO - 2018-05-11 01:46:59 --> Language Class Initialized
INFO - 2018-05-11 01:46:59 --> Output Class Initialized
INFO - 2018-05-11 01:46:59 --> Output Class Initialized
ERROR - 2018-05-11 01:46:59 --> 404 Page Not Found: /index
INFO - 2018-05-11 01:46:59 --> Security Class Initialized
INFO - 2018-05-11 01:46:59 --> Language Class Initialized
INFO - 2018-05-11 01:46:59 --> Security Class Initialized
INFO - 2018-05-11 01:46:59 --> Config Class Initialized
ERROR - 2018-05-11 01:46:59 --> 404 Page Not Found: /index
INFO - 2018-05-11 01:46:59 --> Hooks Class Initialized
DEBUG - 2018-05-11 01:46:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-11 01:46:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 01:46:59 --> Input Class Initialized
INFO - 2018-05-11 01:46:59 --> Config Class Initialized
DEBUG - 2018-05-11 01:46:59 --> UTF-8 Support Enabled
INFO - 2018-05-11 01:46:59 --> Hooks Class Initialized
INFO - 2018-05-11 01:46:59 --> Language Class Initialized
INFO - 2018-05-11 01:46:59 --> Utf8 Class Initialized
INFO - 2018-05-11 01:46:59 --> Input Class Initialized
DEBUG - 2018-05-11 01:46:59 --> UTF-8 Support Enabled
ERROR - 2018-05-11 01:46:59 --> 404 Page Not Found: /index
INFO - 2018-05-11 01:46:59 --> Language Class Initialized
INFO - 2018-05-11 01:46:59 --> URI Class Initialized
INFO - 2018-05-11 01:46:59 --> Utf8 Class Initialized
INFO - 2018-05-11 01:46:59 --> URI Class Initialized
INFO - 2018-05-11 01:46:59 --> Router Class Initialized
INFO - 2018-05-11 01:46:59 --> Output Class Initialized
INFO - 2018-05-11 01:46:59 --> Security Class Initialized
DEBUG - 2018-05-11 01:46:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 01:46:59 --> Input Class Initialized
INFO - 2018-05-11 01:46:59 --> Language Class Initialized
ERROR - 2018-05-11 01:46:59 --> 404 Page Not Found: /index
ERROR - 2018-05-11 01:46:59 --> 404 Page Not Found: /index
INFO - 2018-05-11 01:46:59 --> Router Class Initialized
INFO - 2018-05-11 01:46:59 --> Output Class Initialized
INFO - 2018-05-11 01:46:59 --> Security Class Initialized
DEBUG - 2018-05-11 01:46:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 01:46:59 --> Input Class Initialized
INFO - 2018-05-11 01:46:59 --> Language Class Initialized
ERROR - 2018-05-11 01:46:59 --> 404 Page Not Found: /index
INFO - 2018-05-11 01:47:08 --> Config Class Initialized
INFO - 2018-05-11 01:47:08 --> Hooks Class Initialized
DEBUG - 2018-05-11 01:47:08 --> UTF-8 Support Enabled
INFO - 2018-05-11 01:47:08 --> Utf8 Class Initialized
INFO - 2018-05-11 01:47:08 --> URI Class Initialized
INFO - 2018-05-11 01:47:08 --> Router Class Initialized
INFO - 2018-05-11 01:47:08 --> Output Class Initialized
INFO - 2018-05-11 01:47:08 --> Security Class Initialized
DEBUG - 2018-05-11 01:47:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 01:47:08 --> Input Class Initialized
INFO - 2018-05-11 01:47:08 --> Language Class Initialized
ERROR - 2018-05-11 01:47:08 --> 404 Page Not Found: /index
INFO - 2018-05-11 01:47:08 --> Config Class Initialized
INFO - 2018-05-11 01:47:08 --> Hooks Class Initialized
DEBUG - 2018-05-11 01:47:08 --> UTF-8 Support Enabled
INFO - 2018-05-11 01:47:08 --> Utf8 Class Initialized
INFO - 2018-05-11 01:47:08 --> Config Class Initialized
INFO - 2018-05-11 01:47:08 --> Config Class Initialized
INFO - 2018-05-11 01:47:08 --> Config Class Initialized
INFO - 2018-05-11 01:47:08 --> Config Class Initialized
INFO - 2018-05-11 01:47:08 --> Hooks Class Initialized
INFO - 2018-05-11 01:47:08 --> Hooks Class Initialized
INFO - 2018-05-11 01:47:08 --> Hooks Class Initialized
INFO - 2018-05-11 01:47:08 --> URI Class Initialized
INFO - 2018-05-11 01:47:08 --> Hooks Class Initialized
DEBUG - 2018-05-11 01:47:08 --> UTF-8 Support Enabled
INFO - 2018-05-11 01:47:08 --> Router Class Initialized
DEBUG - 2018-05-11 01:47:08 --> UTF-8 Support Enabled
DEBUG - 2018-05-11 01:47:08 --> UTF-8 Support Enabled
DEBUG - 2018-05-11 01:47:08 --> UTF-8 Support Enabled
INFO - 2018-05-11 01:47:08 --> Utf8 Class Initialized
INFO - 2018-05-11 01:47:08 --> Utf8 Class Initialized
INFO - 2018-05-11 01:47:08 --> Utf8 Class Initialized
INFO - 2018-05-11 01:47:08 --> Output Class Initialized
INFO - 2018-05-11 01:47:08 --> Utf8 Class Initialized
INFO - 2018-05-11 01:47:08 --> Config Class Initialized
INFO - 2018-05-11 01:47:08 --> URI Class Initialized
INFO - 2018-05-11 01:47:08 --> Router Class Initialized
INFO - 2018-05-11 01:47:08 --> URI Class Initialized
INFO - 2018-05-11 01:47:08 --> URI Class Initialized
INFO - 2018-05-11 01:47:08 --> URI Class Initialized
INFO - 2018-05-11 01:47:08 --> Hooks Class Initialized
INFO - 2018-05-11 01:47:08 --> Output Class Initialized
INFO - 2018-05-11 01:47:08 --> Router Class Initialized
INFO - 2018-05-11 01:47:08 --> Router Class Initialized
INFO - 2018-05-11 01:47:08 --> Security Class Initialized
DEBUG - 2018-05-11 01:47:08 --> UTF-8 Support Enabled
INFO - 2018-05-11 01:47:08 --> Router Class Initialized
INFO - 2018-05-11 01:47:08 --> Security Class Initialized
DEBUG - 2018-05-11 01:47:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 01:47:08 --> Input Class Initialized
INFO - 2018-05-11 01:47:08 --> Output Class Initialized
INFO - 2018-05-11 01:47:08 --> Output Class Initialized
INFO - 2018-05-11 01:47:08 --> Utf8 Class Initialized
DEBUG - 2018-05-11 01:47:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 01:47:08 --> Output Class Initialized
INFO - 2018-05-11 01:47:08 --> Language Class Initialized
INFO - 2018-05-11 01:47:08 --> Security Class Initialized
DEBUG - 2018-05-11 01:47:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 01:47:09 --> Input Class Initialized
INFO - 2018-05-11 01:47:09 --> Language Class Initialized
ERROR - 2018-05-11 01:47:09 --> 404 Page Not Found: /index
INFO - 2018-05-11 01:47:09 --> Config Class Initialized
ERROR - 2018-05-11 01:47:09 --> 404 Page Not Found: /index
INFO - 2018-05-11 01:47:09 --> Security Class Initialized
INFO - 2018-05-11 01:47:09 --> URI Class Initialized
INFO - 2018-05-11 01:47:09 --> Input Class Initialized
INFO - 2018-05-11 01:47:09 --> Security Class Initialized
INFO - 2018-05-11 01:47:09 --> Hooks Class Initialized
DEBUG - 2018-05-11 01:47:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 01:47:09 --> Input Class Initialized
INFO - 2018-05-11 01:47:09 --> Language Class Initialized
ERROR - 2018-05-11 01:47:09 --> 404 Page Not Found: /index
DEBUG - 2018-05-11 01:47:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-11 01:47:09 --> UTF-8 Support Enabled
INFO - 2018-05-11 01:47:09 --> Language Class Initialized
INFO - 2018-05-11 01:47:09 --> Router Class Initialized
INFO - 2018-05-11 01:47:09 --> Utf8 Class Initialized
ERROR - 2018-05-11 01:47:09 --> 404 Page Not Found: /index
INFO - 2018-05-11 01:47:09 --> Output Class Initialized
INFO - 2018-05-11 01:47:09 --> Input Class Initialized
INFO - 2018-05-11 01:47:09 --> URI Class Initialized
INFO - 2018-05-11 01:47:09 --> Config Class Initialized
INFO - 2018-05-11 01:47:09 --> Language Class Initialized
INFO - 2018-05-11 01:47:09 --> Security Class Initialized
INFO - 2018-05-11 01:47:09 --> Config Class Initialized
INFO - 2018-05-11 01:47:09 --> Hooks Class Initialized
INFO - 2018-05-11 01:47:09 --> Hooks Class Initialized
INFO - 2018-05-11 01:47:09 --> Router Class Initialized
DEBUG - 2018-05-11 01:47:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-05-11 01:47:09 --> 404 Page Not Found: /index
DEBUG - 2018-05-11 01:47:09 --> UTF-8 Support Enabled
INFO - 2018-05-11 01:47:09 --> Utf8 Class Initialized
INFO - 2018-05-11 01:47:09 --> URI Class Initialized
INFO - 2018-05-11 01:47:09 --> Router Class Initialized
INFO - 2018-05-11 01:47:09 --> Output Class Initialized
INFO - 2018-05-11 01:47:09 --> Security Class Initialized
DEBUG - 2018-05-11 01:47:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 01:47:09 --> Input Class Initialized
INFO - 2018-05-11 01:47:09 --> Input Class Initialized
INFO - 2018-05-11 01:47:09 --> Output Class Initialized
INFO - 2018-05-11 01:47:09 --> Language Class Initialized
DEBUG - 2018-05-11 01:47:09 --> UTF-8 Support Enabled
INFO - 2018-05-11 01:47:09 --> Language Class Initialized
ERROR - 2018-05-11 01:47:09 --> 404 Page Not Found: /index
INFO - 2018-05-11 01:47:09 --> Config Class Initialized
ERROR - 2018-05-11 01:47:09 --> 404 Page Not Found: /index
INFO - 2018-05-11 01:47:09 --> Utf8 Class Initialized
INFO - 2018-05-11 01:47:09 --> Hooks Class Initialized
DEBUG - 2018-05-11 01:47:09 --> UTF-8 Support Enabled
INFO - 2018-05-11 01:47:09 --> Config Class Initialized
INFO - 2018-05-11 01:47:09 --> Hooks Class Initialized
INFO - 2018-05-11 01:47:09 --> Utf8 Class Initialized
INFO - 2018-05-11 01:47:09 --> URI Class Initialized
INFO - 2018-05-11 01:47:09 --> Security Class Initialized
INFO - 2018-05-11 01:47:09 --> Config Class Initialized
INFO - 2018-05-11 01:47:09 --> Hooks Class Initialized
DEBUG - 2018-05-11 01:47:09 --> UTF-8 Support Enabled
DEBUG - 2018-05-11 01:47:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 01:47:09 --> Router Class Initialized
INFO - 2018-05-11 01:47:09 --> URI Class Initialized
DEBUG - 2018-05-11 01:47:09 --> UTF-8 Support Enabled
INFO - 2018-05-11 01:47:09 --> Router Class Initialized
INFO - 2018-05-11 01:47:09 --> Utf8 Class Initialized
INFO - 2018-05-11 01:47:09 --> Input Class Initialized
INFO - 2018-05-11 01:47:09 --> Output Class Initialized
INFO - 2018-05-11 01:47:09 --> Utf8 Class Initialized
INFO - 2018-05-11 01:47:09 --> Output Class Initialized
INFO - 2018-05-11 01:47:09 --> URI Class Initialized
INFO - 2018-05-11 01:47:09 --> Language Class Initialized
INFO - 2018-05-11 01:47:09 --> Security Class Initialized
INFO - 2018-05-11 01:47:09 --> Security Class Initialized
INFO - 2018-05-11 01:47:09 --> Router Class Initialized
INFO - 2018-05-11 01:47:09 --> URI Class Initialized
ERROR - 2018-05-11 01:47:09 --> 404 Page Not Found: /index
DEBUG - 2018-05-11 01:47:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-11 01:47:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 01:47:09 --> Router Class Initialized
INFO - 2018-05-11 01:47:09 --> Output Class Initialized
INFO - 2018-05-11 01:47:09 --> Config Class Initialized
INFO - 2018-05-11 01:47:09 --> Hooks Class Initialized
INFO - 2018-05-11 01:47:09 --> Input Class Initialized
INFO - 2018-05-11 01:47:09 --> Security Class Initialized
INFO - 2018-05-11 01:47:09 --> Output Class Initialized
INFO - 2018-05-11 01:47:09 --> Input Class Initialized
DEBUG - 2018-05-11 01:47:09 --> UTF-8 Support Enabled
INFO - 2018-05-11 01:47:09 --> Security Class Initialized
INFO - 2018-05-11 01:47:09 --> Language Class Initialized
DEBUG - 2018-05-11 01:47:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 01:47:09 --> Language Class Initialized
INFO - 2018-05-11 01:47:09 --> Utf8 Class Initialized
ERROR - 2018-05-11 01:47:09 --> 404 Page Not Found: /index
DEBUG - 2018-05-11 01:47:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 01:47:09 --> Input Class Initialized
ERROR - 2018-05-11 01:47:09 --> 404 Page Not Found: /index
INFO - 2018-05-11 01:47:09 --> URI Class Initialized
INFO - 2018-05-11 01:47:09 --> Input Class Initialized
INFO - 2018-05-11 01:47:09 --> Language Class Initialized
INFO - 2018-05-11 01:47:09 --> Config Class Initialized
INFO - 2018-05-11 01:47:09 --> Config Class Initialized
INFO - 2018-05-11 01:47:09 --> Language Class Initialized
INFO - 2018-05-11 01:47:09 --> Hooks Class Initialized
INFO - 2018-05-11 01:47:09 --> Hooks Class Initialized
ERROR - 2018-05-11 01:47:09 --> 404 Page Not Found: /index
INFO - 2018-05-11 01:47:09 --> Router Class Initialized
ERROR - 2018-05-11 01:47:09 --> 404 Page Not Found: /index
INFO - 2018-05-11 01:47:09 --> Output Class Initialized
DEBUG - 2018-05-11 01:47:09 --> UTF-8 Support Enabled
DEBUG - 2018-05-11 01:47:09 --> UTF-8 Support Enabled
INFO - 2018-05-11 01:47:09 --> Config Class Initialized
INFO - 2018-05-11 01:47:09 --> Hooks Class Initialized
INFO - 2018-05-11 01:47:09 --> Utf8 Class Initialized
INFO - 2018-05-11 01:47:09 --> Security Class Initialized
INFO - 2018-05-11 01:47:09 --> Utf8 Class Initialized
DEBUG - 2018-05-11 01:47:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-11 01:47:09 --> UTF-8 Support Enabled
INFO - 2018-05-11 01:47:09 --> URI Class Initialized
INFO - 2018-05-11 01:47:09 --> URI Class Initialized
INFO - 2018-05-11 01:47:09 --> Utf8 Class Initialized
INFO - 2018-05-11 01:47:09 --> Router Class Initialized
INFO - 2018-05-11 01:47:09 --> Input Class Initialized
INFO - 2018-05-11 01:47:09 --> Router Class Initialized
INFO - 2018-05-11 01:47:09 --> URI Class Initialized
INFO - 2018-05-11 01:47:09 --> Language Class Initialized
INFO - 2018-05-11 01:47:09 --> Output Class Initialized
INFO - 2018-05-11 01:47:09 --> Output Class Initialized
ERROR - 2018-05-11 01:47:09 --> 404 Page Not Found: /index
INFO - 2018-05-11 01:47:09 --> Router Class Initialized
INFO - 2018-05-11 01:47:09 --> Security Class Initialized
INFO - 2018-05-11 01:47:09 --> Security Class Initialized
DEBUG - 2018-05-11 01:47:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 01:47:09 --> Output Class Initialized
DEBUG - 2018-05-11 01:47:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 01:47:09 --> Config Class Initialized
INFO - 2018-05-11 01:47:09 --> Hooks Class Initialized
INFO - 2018-05-11 01:47:09 --> Input Class Initialized
INFO - 2018-05-11 01:47:09 --> Input Class Initialized
INFO - 2018-05-11 01:47:09 --> Security Class Initialized
INFO - 2018-05-11 01:47:09 --> Language Class Initialized
DEBUG - 2018-05-11 01:47:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 01:47:09 --> Language Class Initialized
DEBUG - 2018-05-11 01:47:09 --> UTF-8 Support Enabled
INFO - 2018-05-11 01:47:09 --> Input Class Initialized
ERROR - 2018-05-11 01:47:09 --> 404 Page Not Found: /index
ERROR - 2018-05-11 01:47:09 --> 404 Page Not Found: /index
INFO - 2018-05-11 01:47:09 --> Utf8 Class Initialized
INFO - 2018-05-11 01:47:09 --> Language Class Initialized
INFO - 2018-05-11 01:47:09 --> URI Class Initialized
INFO - 2018-05-11 01:47:09 --> Router Class Initialized
ERROR - 2018-05-11 01:47:09 --> 404 Page Not Found: /index
INFO - 2018-05-11 01:47:09 --> Output Class Initialized
INFO - 2018-05-11 01:47:10 --> Security Class Initialized
DEBUG - 2018-05-11 01:47:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 01:47:10 --> Input Class Initialized
INFO - 2018-05-11 01:47:10 --> Language Class Initialized
ERROR - 2018-05-11 01:47:10 --> 404 Page Not Found: /index
INFO - 2018-05-11 01:47:12 --> Config Class Initialized
INFO - 2018-05-11 01:47:12 --> Hooks Class Initialized
DEBUG - 2018-05-11 01:47:12 --> UTF-8 Support Enabled
INFO - 2018-05-11 01:47:12 --> Utf8 Class Initialized
INFO - 2018-05-11 01:47:12 --> URI Class Initialized
INFO - 2018-05-11 01:47:12 --> Router Class Initialized
INFO - 2018-05-11 01:47:12 --> Output Class Initialized
INFO - 2018-05-11 01:47:12 --> Security Class Initialized
DEBUG - 2018-05-11 01:47:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 01:47:12 --> Input Class Initialized
INFO - 2018-05-11 01:47:12 --> Language Class Initialized
ERROR - 2018-05-11 01:47:12 --> 404 Page Not Found: /index
INFO - 2018-05-11 01:47:12 --> Config Class Initialized
INFO - 2018-05-11 01:47:12 --> Config Class Initialized
INFO - 2018-05-11 01:47:12 --> Config Class Initialized
INFO - 2018-05-11 01:47:12 --> Config Class Initialized
INFO - 2018-05-11 01:47:12 --> Config Class Initialized
INFO - 2018-05-11 01:47:12 --> Hooks Class Initialized
INFO - 2018-05-11 01:47:12 --> Hooks Class Initialized
INFO - 2018-05-11 01:47:12 --> Hooks Class Initialized
INFO - 2018-05-11 01:47:12 --> Hooks Class Initialized
INFO - 2018-05-11 01:47:12 --> Hooks Class Initialized
DEBUG - 2018-05-11 01:47:12 --> UTF-8 Support Enabled
DEBUG - 2018-05-11 01:47:12 --> UTF-8 Support Enabled
DEBUG - 2018-05-11 01:47:12 --> UTF-8 Support Enabled
DEBUG - 2018-05-11 01:47:12 --> UTF-8 Support Enabled
DEBUG - 2018-05-11 01:47:12 --> UTF-8 Support Enabled
INFO - 2018-05-11 01:47:12 --> Utf8 Class Initialized
INFO - 2018-05-11 01:47:12 --> Utf8 Class Initialized
INFO - 2018-05-11 01:47:12 --> Utf8 Class Initialized
INFO - 2018-05-11 01:47:12 --> Utf8 Class Initialized
INFO - 2018-05-11 01:47:12 --> Utf8 Class Initialized
INFO - 2018-05-11 01:47:12 --> URI Class Initialized
INFO - 2018-05-11 01:47:12 --> URI Class Initialized
INFO - 2018-05-11 01:47:12 --> URI Class Initialized
INFO - 2018-05-11 01:47:12 --> URI Class Initialized
INFO - 2018-05-11 01:47:12 --> URI Class Initialized
INFO - 2018-05-11 01:47:12 --> Router Class Initialized
INFO - 2018-05-11 01:47:12 --> Router Class Initialized
INFO - 2018-05-11 01:47:12 --> Router Class Initialized
INFO - 2018-05-11 01:47:12 --> Router Class Initialized
INFO - 2018-05-11 01:47:12 --> Output Class Initialized
INFO - 2018-05-11 01:47:12 --> Router Class Initialized
INFO - 2018-05-11 01:47:12 --> Output Class Initialized
INFO - 2018-05-11 01:47:12 --> Output Class Initialized
INFO - 2018-05-11 01:47:12 --> Output Class Initialized
INFO - 2018-05-11 01:47:12 --> Output Class Initialized
INFO - 2018-05-11 01:47:12 --> Security Class Initialized
INFO - 2018-05-11 01:47:12 --> Security Class Initialized
INFO - 2018-05-11 01:47:12 --> Security Class Initialized
INFO - 2018-05-11 01:47:12 --> Security Class Initialized
INFO - 2018-05-11 01:47:12 --> Security Class Initialized
DEBUG - 2018-05-11 01:47:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-11 01:47:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-11 01:47:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-11 01:47:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-11 01:47:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 01:47:12 --> Input Class Initialized
INFO - 2018-05-11 01:47:12 --> Input Class Initialized
INFO - 2018-05-11 01:47:12 --> Input Class Initialized
INFO - 2018-05-11 01:47:12 --> Input Class Initialized
INFO - 2018-05-11 01:47:12 --> Input Class Initialized
INFO - 2018-05-11 01:47:12 --> Language Class Initialized
INFO - 2018-05-11 01:47:12 --> Language Class Initialized
INFO - 2018-05-11 01:47:12 --> Language Class Initialized
INFO - 2018-05-11 01:47:12 --> Language Class Initialized
ERROR - 2018-05-11 01:47:12 --> 404 Page Not Found: /index
INFO - 2018-05-11 01:47:12 --> Language Class Initialized
ERROR - 2018-05-11 01:47:12 --> 404 Page Not Found: /index
ERROR - 2018-05-11 01:47:12 --> 404 Page Not Found: /index
ERROR - 2018-05-11 01:47:12 --> 404 Page Not Found: /index
INFO - 2018-05-11 01:47:12 --> Config Class Initialized
INFO - 2018-05-11 01:47:12 --> Config Class Initialized
INFO - 2018-05-11 01:47:12 --> Config Class Initialized
INFO - 2018-05-11 01:47:12 --> Hooks Class Initialized
INFO - 2018-05-11 01:47:12 --> Hooks Class Initialized
INFO - 2018-05-11 01:47:12 --> Hooks Class Initialized
ERROR - 2018-05-11 01:47:12 --> 404 Page Not Found: /index
INFO - 2018-05-11 01:47:12 --> Config Class Initialized
INFO - 2018-05-11 01:47:12 --> Hooks Class Initialized
DEBUG - 2018-05-11 01:47:12 --> UTF-8 Support Enabled
DEBUG - 2018-05-11 01:47:12 --> UTF-8 Support Enabled
DEBUG - 2018-05-11 01:47:12 --> UTF-8 Support Enabled
INFO - 2018-05-11 01:47:12 --> Utf8 Class Initialized
INFO - 2018-05-11 01:47:12 --> Utf8 Class Initialized
DEBUG - 2018-05-11 01:47:12 --> UTF-8 Support Enabled
INFO - 2018-05-11 01:47:12 --> Utf8 Class Initialized
INFO - 2018-05-11 01:47:12 --> URI Class Initialized
INFO - 2018-05-11 01:47:12 --> Router Class Initialized
INFO - 2018-05-11 01:47:12 --> Utf8 Class Initialized
INFO - 2018-05-11 01:47:12 --> Output Class Initialized
INFO - 2018-05-11 01:47:12 --> URI Class Initialized
INFO - 2018-05-11 01:47:12 --> URI Class Initialized
INFO - 2018-05-11 01:47:12 --> URI Class Initialized
INFO - 2018-05-11 01:47:12 --> Security Class Initialized
INFO - 2018-05-11 01:47:12 --> Router Class Initialized
INFO - 2018-05-11 01:47:12 --> Router Class Initialized
DEBUG - 2018-05-11 01:47:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 01:47:12 --> Router Class Initialized
INFO - 2018-05-11 01:47:12 --> Output Class Initialized
INFO - 2018-05-11 01:47:12 --> Output Class Initialized
INFO - 2018-05-11 01:47:12 --> Input Class Initialized
INFO - 2018-05-11 01:47:12 --> Output Class Initialized
INFO - 2018-05-11 01:47:12 --> Language Class Initialized
INFO - 2018-05-11 01:47:12 --> Security Class Initialized
INFO - 2018-05-11 01:47:12 --> Security Class Initialized
INFO - 2018-05-11 01:47:12 --> Security Class Initialized
DEBUG - 2018-05-11 01:47:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-05-11 01:47:12 --> 404 Page Not Found: /index
DEBUG - 2018-05-11 01:47:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-11 01:47:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 01:47:12 --> Input Class Initialized
INFO - 2018-05-11 01:47:12 --> Language Class Initialized
ERROR - 2018-05-11 01:47:12 --> 404 Page Not Found: /index
INFO - 2018-05-11 01:47:12 --> Input Class Initialized
INFO - 2018-05-11 01:47:12 --> Config Class Initialized
INFO - 2018-05-11 01:47:12 --> Config Class Initialized
INFO - 2018-05-11 01:47:12 --> Input Class Initialized
INFO - 2018-05-11 01:47:12 --> Hooks Class Initialized
INFO - 2018-05-11 01:47:12 --> Hooks Class Initialized
INFO - 2018-05-11 01:47:12 --> Language Class Initialized
INFO - 2018-05-11 01:47:12 --> Language Class Initialized
DEBUG - 2018-05-11 01:47:12 --> UTF-8 Support Enabled
DEBUG - 2018-05-11 01:47:12 --> UTF-8 Support Enabled
ERROR - 2018-05-11 01:47:12 --> 404 Page Not Found: /index
ERROR - 2018-05-11 01:47:12 --> 404 Page Not Found: /index
INFO - 2018-05-11 01:47:12 --> Utf8 Class Initialized
INFO - 2018-05-11 01:47:12 --> Utf8 Class Initialized
INFO - 2018-05-11 01:47:13 --> Config Class Initialized
INFO - 2018-05-11 01:47:13 --> Hooks Class Initialized
INFO - 2018-05-11 01:47:13 --> URI Class Initialized
INFO - 2018-05-11 01:47:13 --> Config Class Initialized
DEBUG - 2018-05-11 01:47:13 --> UTF-8 Support Enabled
INFO - 2018-05-11 01:47:13 --> URI Class Initialized
INFO - 2018-05-11 01:47:13 --> Router Class Initialized
INFO - 2018-05-11 01:47:13 --> Hooks Class Initialized
INFO - 2018-05-11 01:47:13 --> Utf8 Class Initialized
DEBUG - 2018-05-11 01:47:13 --> UTF-8 Support Enabled
INFO - 2018-05-11 01:47:13 --> Output Class Initialized
INFO - 2018-05-11 01:47:13 --> Router Class Initialized
INFO - 2018-05-11 01:47:13 --> Utf8 Class Initialized
INFO - 2018-05-11 01:47:13 --> URI Class Initialized
INFO - 2018-05-11 01:47:13 --> Output Class Initialized
INFO - 2018-05-11 01:47:13 --> Security Class Initialized
INFO - 2018-05-11 01:47:13 --> URI Class Initialized
INFO - 2018-05-11 01:47:13 --> Security Class Initialized
INFO - 2018-05-11 01:47:13 --> Router Class Initialized
DEBUG - 2018-05-11 01:47:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 01:47:13 --> Input Class Initialized
INFO - 2018-05-11 01:47:13 --> Output Class Initialized
DEBUG - 2018-05-11 01:47:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 01:47:13 --> Router Class Initialized
INFO - 2018-05-11 01:47:13 --> Security Class Initialized
INFO - 2018-05-11 01:47:13 --> Language Class Initialized
INFO - 2018-05-11 01:47:13 --> Input Class Initialized
INFO - 2018-05-11 01:47:13 --> Output Class Initialized
DEBUG - 2018-05-11 01:47:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 01:47:13 --> Security Class Initialized
INFO - 2018-05-11 01:47:13 --> Language Class Initialized
ERROR - 2018-05-11 01:47:13 --> 404 Page Not Found: /index
DEBUG - 2018-05-11 01:47:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 01:47:13 --> Input Class Initialized
ERROR - 2018-05-11 01:47:13 --> 404 Page Not Found: /index
INFO - 2018-05-11 01:47:13 --> Input Class Initialized
INFO - 2018-05-11 01:47:13 --> Language Class Initialized
INFO - 2018-05-11 01:47:13 --> Language Class Initialized
ERROR - 2018-05-11 01:47:13 --> 404 Page Not Found: /index
ERROR - 2018-05-11 01:47:13 --> 404 Page Not Found: /index
INFO - 2018-05-11 02:17:29 --> Config Class Initialized
INFO - 2018-05-11 02:17:29 --> Hooks Class Initialized
INFO - 2018-05-11 02:17:29 --> Config Class Initialized
INFO - 2018-05-11 02:17:29 --> Hooks Class Initialized
INFO - 2018-05-11 02:17:29 --> Config Class Initialized
INFO - 2018-05-11 02:17:29 --> Config Class Initialized
INFO - 2018-05-11 02:17:29 --> Config Class Initialized
INFO - 2018-05-11 02:17:29 --> Config Class Initialized
INFO - 2018-05-11 02:17:29 --> Hooks Class Initialized
INFO - 2018-05-11 02:17:29 --> Hooks Class Initialized
INFO - 2018-05-11 02:17:29 --> Hooks Class Initialized
INFO - 2018-05-11 02:17:29 --> Hooks Class Initialized
DEBUG - 2018-05-11 02:17:29 --> UTF-8 Support Enabled
DEBUG - 2018-05-11 02:17:29 --> UTF-8 Support Enabled
DEBUG - 2018-05-11 02:17:29 --> UTF-8 Support Enabled
DEBUG - 2018-05-11 02:17:29 --> UTF-8 Support Enabled
DEBUG - 2018-05-11 02:17:29 --> UTF-8 Support Enabled
DEBUG - 2018-05-11 02:17:29 --> UTF-8 Support Enabled
INFO - 2018-05-11 02:17:29 --> Utf8 Class Initialized
INFO - 2018-05-11 02:17:29 --> Utf8 Class Initialized
INFO - 2018-05-11 02:17:29 --> Utf8 Class Initialized
INFO - 2018-05-11 02:17:29 --> Utf8 Class Initialized
INFO - 2018-05-11 02:17:29 --> Utf8 Class Initialized
INFO - 2018-05-11 02:17:29 --> Utf8 Class Initialized
INFO - 2018-05-11 02:17:29 --> URI Class Initialized
INFO - 2018-05-11 02:17:29 --> URI Class Initialized
INFO - 2018-05-11 02:17:29 --> URI Class Initialized
INFO - 2018-05-11 02:17:29 --> URI Class Initialized
INFO - 2018-05-11 02:17:29 --> URI Class Initialized
INFO - 2018-05-11 02:17:29 --> URI Class Initialized
INFO - 2018-05-11 02:17:29 --> Router Class Initialized
INFO - 2018-05-11 02:17:29 --> Router Class Initialized
INFO - 2018-05-11 02:17:29 --> Router Class Initialized
INFO - 2018-05-11 02:17:29 --> Router Class Initialized
INFO - 2018-05-11 02:17:29 --> Router Class Initialized
INFO - 2018-05-11 02:17:29 --> Router Class Initialized
INFO - 2018-05-11 02:17:29 --> Output Class Initialized
INFO - 2018-05-11 02:17:29 --> Output Class Initialized
INFO - 2018-05-11 02:17:29 --> Output Class Initialized
INFO - 2018-05-11 02:17:29 --> Output Class Initialized
INFO - 2018-05-11 02:17:29 --> Output Class Initialized
INFO - 2018-05-11 02:17:29 --> Output Class Initialized
INFO - 2018-05-11 02:17:29 --> Security Class Initialized
INFO - 2018-05-11 02:17:29 --> Security Class Initialized
INFO - 2018-05-11 02:17:29 --> Security Class Initialized
INFO - 2018-05-11 02:17:29 --> Security Class Initialized
INFO - 2018-05-11 02:17:29 --> Security Class Initialized
INFO - 2018-05-11 02:17:29 --> Security Class Initialized
DEBUG - 2018-05-11 02:17:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-11 02:17:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-11 02:17:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-11 02:17:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-11 02:17:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-11 02:17:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 02:17:29 --> Input Class Initialized
INFO - 2018-05-11 02:17:29 --> Input Class Initialized
INFO - 2018-05-11 02:17:29 --> Input Class Initialized
INFO - 2018-05-11 02:17:29 --> Input Class Initialized
INFO - 2018-05-11 02:17:29 --> Input Class Initialized
INFO - 2018-05-11 02:17:29 --> Input Class Initialized
INFO - 2018-05-11 02:17:29 --> Language Class Initialized
INFO - 2018-05-11 02:17:29 --> Language Class Initialized
INFO - 2018-05-11 02:17:29 --> Language Class Initialized
INFO - 2018-05-11 02:17:29 --> Language Class Initialized
INFO - 2018-05-11 02:17:29 --> Language Class Initialized
INFO - 2018-05-11 02:17:29 --> Language Class Initialized
ERROR - 2018-05-11 02:17:29 --> 404 Page Not Found: /index
ERROR - 2018-05-11 02:17:29 --> 404 Page Not Found: /index
ERROR - 2018-05-11 02:17:29 --> 404 Page Not Found: /index
ERROR - 2018-05-11 02:17:29 --> 404 Page Not Found: /index
ERROR - 2018-05-11 02:17:29 --> 404 Page Not Found: /index
ERROR - 2018-05-11 02:17:29 --> 404 Page Not Found: /index
INFO - 2018-05-11 02:17:29 --> Config Class Initialized
INFO - 2018-05-11 02:17:29 --> Hooks Class Initialized
DEBUG - 2018-05-11 02:17:29 --> UTF-8 Support Enabled
INFO - 2018-05-11 02:17:29 --> Utf8 Class Initialized
INFO - 2018-05-11 02:17:29 --> URI Class Initialized
INFO - 2018-05-11 02:17:29 --> Router Class Initialized
INFO - 2018-05-11 02:17:29 --> Output Class Initialized
INFO - 2018-05-11 02:17:29 --> Security Class Initialized
DEBUG - 2018-05-11 02:17:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 02:17:29 --> Input Class Initialized
INFO - 2018-05-11 02:17:29 --> Language Class Initialized
ERROR - 2018-05-11 02:17:29 --> 404 Page Not Found: /index
INFO - 2018-05-11 02:17:29 --> Config Class Initialized
INFO - 2018-05-11 02:17:29 --> Config Class Initialized
INFO - 2018-05-11 02:17:29 --> Config Class Initialized
INFO - 2018-05-11 02:17:29 --> Config Class Initialized
INFO - 2018-05-11 02:17:29 --> Hooks Class Initialized
INFO - 2018-05-11 02:17:29 --> Hooks Class Initialized
INFO - 2018-05-11 02:17:29 --> Hooks Class Initialized
INFO - 2018-05-11 02:17:29 --> Hooks Class Initialized
INFO - 2018-05-11 02:17:29 --> Config Class Initialized
INFO - 2018-05-11 02:17:29 --> Hooks Class Initialized
DEBUG - 2018-05-11 02:17:29 --> UTF-8 Support Enabled
DEBUG - 2018-05-11 02:17:29 --> UTF-8 Support Enabled
DEBUG - 2018-05-11 02:17:29 --> UTF-8 Support Enabled
INFO - 2018-05-11 02:17:29 --> Utf8 Class Initialized
INFO - 2018-05-11 02:17:29 --> Utf8 Class Initialized
INFO - 2018-05-11 02:17:29 --> Utf8 Class Initialized
DEBUG - 2018-05-11 02:17:29 --> UTF-8 Support Enabled
DEBUG - 2018-05-11 02:17:29 --> UTF-8 Support Enabled
INFO - 2018-05-11 02:17:29 --> Utf8 Class Initialized
INFO - 2018-05-11 02:17:29 --> URI Class Initialized
INFO - 2018-05-11 02:17:29 --> URI Class Initialized
INFO - 2018-05-11 02:17:29 --> URI Class Initialized
INFO - 2018-05-11 02:17:29 --> URI Class Initialized
INFO - 2018-05-11 02:17:29 --> Utf8 Class Initialized
INFO - 2018-05-11 02:17:29 --> Router Class Initialized
INFO - 2018-05-11 02:17:29 --> Router Class Initialized
INFO - 2018-05-11 02:17:29 --> Router Class Initialized
INFO - 2018-05-11 02:17:29 --> URI Class Initialized
INFO - 2018-05-11 02:17:29 --> Router Class Initialized
INFO - 2018-05-11 02:17:29 --> Output Class Initialized
INFO - 2018-05-11 02:17:29 --> Security Class Initialized
INFO - 2018-05-11 02:17:29 --> Output Class Initialized
INFO - 2018-05-11 02:17:29 --> Output Class Initialized
INFO - 2018-05-11 02:17:29 --> Output Class Initialized
INFO - 2018-05-11 02:17:29 --> Router Class Initialized
INFO - 2018-05-11 02:17:29 --> Security Class Initialized
INFO - 2018-05-11 02:17:29 --> Output Class Initialized
INFO - 2018-05-11 02:17:29 --> Security Class Initialized
INFO - 2018-05-11 02:17:29 --> Security Class Initialized
DEBUG - 2018-05-11 02:17:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-11 02:17:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 02:17:29 --> Security Class Initialized
INFO - 2018-05-11 02:17:29 --> Input Class Initialized
DEBUG - 2018-05-11 02:17:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-11 02:17:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 02:17:30 --> Input Class Initialized
INFO - 2018-05-11 02:17:30 --> Language Class Initialized
ERROR - 2018-05-11 02:17:30 --> 404 Page Not Found: /index
INFO - 2018-05-11 02:17:30 --> Language Class Initialized
ERROR - 2018-05-11 02:17:30 --> 404 Page Not Found: /index
INFO - 2018-05-11 02:17:30 --> Input Class Initialized
DEBUG - 2018-05-11 02:17:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 02:17:30 --> Input Class Initialized
INFO - 2018-05-11 02:17:30 --> Input Class Initialized
INFO - 2018-05-11 02:17:30 --> Language Class Initialized
INFO - 2018-05-11 02:17:30 --> Language Class Initialized
INFO - 2018-05-11 02:17:30 --> Language Class Initialized
ERROR - 2018-05-11 02:17:30 --> 404 Page Not Found: /index
ERROR - 2018-05-11 02:17:30 --> 404 Page Not Found: /index
ERROR - 2018-05-11 02:17:30 --> 404 Page Not Found: /index
INFO - 2018-05-11 02:17:30 --> Config Class Initialized
INFO - 2018-05-11 02:17:30 --> Config Class Initialized
INFO - 2018-05-11 02:17:30 --> Config Class Initialized
INFO - 2018-05-11 02:17:30 --> Config Class Initialized
INFO - 2018-05-11 02:17:30 --> Hooks Class Initialized
INFO - 2018-05-11 02:17:30 --> Hooks Class Initialized
INFO - 2018-05-11 02:17:30 --> Hooks Class Initialized
INFO - 2018-05-11 02:17:30 --> Hooks Class Initialized
DEBUG - 2018-05-11 02:17:30 --> UTF-8 Support Enabled
DEBUG - 2018-05-11 02:17:30 --> UTF-8 Support Enabled
DEBUG - 2018-05-11 02:17:30 --> UTF-8 Support Enabled
DEBUG - 2018-05-11 02:17:30 --> UTF-8 Support Enabled
INFO - 2018-05-11 02:17:30 --> Utf8 Class Initialized
INFO - 2018-05-11 02:17:30 --> Utf8 Class Initialized
INFO - 2018-05-11 02:17:30 --> Utf8 Class Initialized
INFO - 2018-05-11 02:17:30 --> Utf8 Class Initialized
INFO - 2018-05-11 02:17:30 --> URI Class Initialized
INFO - 2018-05-11 02:17:30 --> URI Class Initialized
INFO - 2018-05-11 02:17:30 --> URI Class Initialized
INFO - 2018-05-11 02:17:30 --> URI Class Initialized
INFO - 2018-05-11 02:17:30 --> Router Class Initialized
INFO - 2018-05-11 02:17:30 --> Router Class Initialized
INFO - 2018-05-11 02:17:30 --> Router Class Initialized
INFO - 2018-05-11 02:17:30 --> Router Class Initialized
INFO - 2018-05-11 02:17:30 --> Output Class Initialized
INFO - 2018-05-11 02:17:30 --> Output Class Initialized
INFO - 2018-05-11 02:17:30 --> Output Class Initialized
INFO - 2018-05-11 02:17:30 --> Config Class Initialized
INFO - 2018-05-11 02:17:30 --> Output Class Initialized
INFO - 2018-05-11 02:17:30 --> Security Class Initialized
INFO - 2018-05-11 02:17:30 --> Security Class Initialized
INFO - 2018-05-11 02:17:30 --> Hooks Class Initialized
INFO - 2018-05-11 02:17:30 --> Security Class Initialized
INFO - 2018-05-11 02:17:30 --> Security Class Initialized
DEBUG - 2018-05-11 02:17:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-11 02:17:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-11 02:17:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-11 02:17:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-11 02:17:30 --> UTF-8 Support Enabled
INFO - 2018-05-11 02:17:30 --> Input Class Initialized
INFO - 2018-05-11 02:17:30 --> Input Class Initialized
INFO - 2018-05-11 02:17:30 --> Input Class Initialized
INFO - 2018-05-11 02:17:30 --> Utf8 Class Initialized
INFO - 2018-05-11 02:17:30 --> Input Class Initialized
INFO - 2018-05-11 02:17:30 --> Language Class Initialized
INFO - 2018-05-11 02:17:30 --> Language Class Initialized
INFO - 2018-05-11 02:17:30 --> Language Class Initialized
INFO - 2018-05-11 02:17:30 --> Language Class Initialized
INFO - 2018-05-11 02:17:30 --> URI Class Initialized
ERROR - 2018-05-11 02:17:30 --> 404 Page Not Found: /index
ERROR - 2018-05-11 02:17:30 --> 404 Page Not Found: /index
ERROR - 2018-05-11 02:17:30 --> 404 Page Not Found: /index
INFO - 2018-05-11 02:17:30 --> Router Class Initialized
ERROR - 2018-05-11 02:17:30 --> 404 Page Not Found: /index
INFO - 2018-05-11 02:17:30 --> Output Class Initialized
INFO - 2018-05-11 02:17:30 --> Security Class Initialized
DEBUG - 2018-05-11 02:17:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 02:17:30 --> Input Class Initialized
INFO - 2018-05-11 02:17:30 --> Language Class Initialized
ERROR - 2018-05-11 02:17:30 --> 404 Page Not Found: /index
INFO - 2018-05-11 02:17:31 --> Config Class Initialized
INFO - 2018-05-11 02:17:31 --> Hooks Class Initialized
DEBUG - 2018-05-11 02:17:31 --> UTF-8 Support Enabled
INFO - 2018-05-11 02:17:31 --> Utf8 Class Initialized
INFO - 2018-05-11 02:17:31 --> URI Class Initialized
DEBUG - 2018-05-11 02:17:31 --> No URI present. Default controller set.
INFO - 2018-05-11 02:17:31 --> Router Class Initialized
INFO - 2018-05-11 02:17:31 --> Output Class Initialized
INFO - 2018-05-11 02:17:31 --> Security Class Initialized
DEBUG - 2018-05-11 02:17:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 02:17:31 --> Input Class Initialized
INFO - 2018-05-11 02:17:31 --> Language Class Initialized
INFO - 2018-05-11 02:17:31 --> Language Class Initialized
INFO - 2018-05-11 02:17:31 --> Config Class Initialized
INFO - 2018-05-11 02:17:31 --> Loader Class Initialized
DEBUG - 2018-05-11 02:17:31 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-11 02:17:31 --> Helper loaded: url_helper
INFO - 2018-05-11 02:17:31 --> Helper loaded: form_helper
INFO - 2018-05-11 02:17:31 --> Helper loaded: date_helper
INFO - 2018-05-11 02:17:31 --> Helper loaded: util_helper
INFO - 2018-05-11 02:17:31 --> Helper loaded: text_helper
INFO - 2018-05-11 02:17:31 --> Helper loaded: string_helper
INFO - 2018-05-11 02:17:31 --> Database Driver Class Initialized
DEBUG - 2018-05-11 02:17:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-11 02:17:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-11 02:17:32 --> Email Class Initialized
INFO - 2018-05-11 02:17:32 --> Controller Class Initialized
DEBUG - 2018-05-11 02:17:32 --> Home MX_Controller Initialized
INFO - 2018-05-11 02:17:32 --> Config Class Initialized
INFO - 2018-05-11 02:17:32 --> Config Class Initialized
INFO - 2018-05-11 02:17:32 --> Hooks Class Initialized
INFO - 2018-05-11 02:17:32 --> Hooks Class Initialized
DEBUG - 2018-05-11 02:17:32 --> UTF-8 Support Enabled
DEBUG - 2018-05-11 02:17:32 --> UTF-8 Support Enabled
INFO - 2018-05-11 02:17:32 --> Utf8 Class Initialized
INFO - 2018-05-11 02:17:32 --> Utf8 Class Initialized
INFO - 2018-05-11 02:17:32 --> URI Class Initialized
INFO - 2018-05-11 02:17:32 --> URI Class Initialized
INFO - 2018-05-11 02:17:32 --> Router Class Initialized
INFO - 2018-05-11 02:17:32 --> Router Class Initialized
INFO - 2018-05-11 02:17:32 --> Output Class Initialized
INFO - 2018-05-11 02:17:32 --> Output Class Initialized
INFO - 2018-05-11 02:17:32 --> Security Class Initialized
INFO - 2018-05-11 02:17:32 --> Security Class Initialized
DEBUG - 2018-05-11 02:17:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-11 02:17:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 02:17:32 --> Input Class Initialized
INFO - 2018-05-11 02:17:32 --> Input Class Initialized
INFO - 2018-05-11 02:17:32 --> Language Class Initialized
INFO - 2018-05-11 02:17:32 --> Language Class Initialized
ERROR - 2018-05-11 02:17:32 --> 404 Page Not Found: /index
INFO - 2018-05-11 02:17:32 --> Language Class Initialized
INFO - 2018-05-11 02:17:32 --> Config Class Initialized
INFO - 2018-05-11 02:17:32 --> Loader Class Initialized
INFO - 2018-05-11 02:17:32 --> Config Class Initialized
INFO - 2018-05-11 02:17:32 --> Hooks Class Initialized
DEBUG - 2018-05-11 02:17:32 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-11 02:17:32 --> Helper loaded: url_helper
DEBUG - 2018-05-11 02:17:32 --> UTF-8 Support Enabled
INFO - 2018-05-11 02:17:32 --> Utf8 Class Initialized
INFO - 2018-05-11 02:17:32 --> Helper loaded: form_helper
INFO - 2018-05-11 02:17:32 --> URI Class Initialized
INFO - 2018-05-11 02:17:32 --> Helper loaded: date_helper
INFO - 2018-05-11 02:17:32 --> Helper loaded: util_helper
INFO - 2018-05-11 02:17:32 --> Router Class Initialized
ERROR - 2018-05-11 02:17:32 --> Query error: Table 'consulting.categories' doesn't exist - Invalid query: SELECT *
FROM `categories`
INFO - 2018-05-11 02:17:32 --> Helper loaded: text_helper
INFO - 2018-05-11 02:17:32 --> Output Class Initialized
INFO - 2018-05-11 02:17:32 --> Helper loaded: string_helper
INFO - 2018-05-11 02:17:32 --> Security Class Initialized
DEBUG - 2018-05-11 02:17:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 02:17:32 --> Database Driver Class Initialized
INFO - 2018-05-11 02:17:32 --> Input Class Initialized
INFO - 2018-05-11 02:17:32 --> Language file loaded: language/english/db_lang.php
INFO - 2018-05-11 02:17:32 --> Language Class Initialized
DEBUG - 2018-05-11 02:17:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-11 02:17:32 --> Session: Class initialized using 'files' driver.
ERROR - 2018-05-11 02:17:32 --> 404 Page Not Found: /index
INFO - 2018-05-11 02:17:32 --> Email Class Initialized
INFO - 2018-05-11 02:17:32 --> Controller Class Initialized
DEBUG - 2018-05-11 02:17:32 --> Admin MX_Controller Initialized
INFO - 2018-05-11 02:17:32 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-11 02:17:32 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-11 02:17:32 --> Login MX_Controller Initialized
DEBUG - 2018-05-11 02:17:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-05-11 02:17:32 --> Config Class Initialized
INFO - 2018-05-11 02:17:32 --> Hooks Class Initialized
DEBUG - 2018-05-11 02:17:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-11 02:17:32 --> UTF-8 Support Enabled
INFO - 2018-05-11 02:17:32 --> Utf8 Class Initialized
INFO - 2018-05-11 02:17:32 --> URI Class Initialized
INFO - 2018-05-11 02:17:32 --> Router Class Initialized
INFO - 2018-05-11 02:17:32 --> Output Class Initialized
DEBUG - 2018-05-11 02:17:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/logins/login.php
INFO - 2018-05-11 02:17:32 --> Security Class Initialized
DEBUG - 2018-05-11 02:17:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 02:17:32 --> Input Class Initialized
INFO - 2018-05-11 02:17:32 --> Language Class Initialized
INFO - 2018-05-11 02:17:32 --> Config Class Initialized
INFO - 2018-05-11 02:17:32 --> Hooks Class Initialized
ERROR - 2018-05-11 02:17:32 --> 404 Page Not Found: /index
DEBUG - 2018-05-11 02:17:32 --> UTF-8 Support Enabled
INFO - 2018-05-11 02:17:32 --> Utf8 Class Initialized
INFO - 2018-05-11 02:17:32 --> URI Class Initialized
INFO - 2018-05-11 02:17:32 --> Router Class Initialized
INFO - 2018-05-11 02:17:32 --> Output Class Initialized
INFO - 2018-05-11 02:17:33 --> Security Class Initialized
DEBUG - 2018-05-11 02:17:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 02:17:33 --> Input Class Initialized
INFO - 2018-05-11 02:17:33 --> Language Class Initialized
ERROR - 2018-05-11 02:17:33 --> 404 Page Not Found: /index
INFO - 2018-05-11 02:17:34 --> Config Class Initialized
INFO - 2018-05-11 02:17:34 --> Hooks Class Initialized
DEBUG - 2018-05-11 02:17:34 --> UTF-8 Support Enabled
INFO - 2018-05-11 02:17:34 --> Utf8 Class Initialized
INFO - 2018-05-11 02:17:34 --> URI Class Initialized
INFO - 2018-05-11 02:17:34 --> Router Class Initialized
INFO - 2018-05-11 02:17:34 --> Output Class Initialized
INFO - 2018-05-11 02:17:34 --> Security Class Initialized
DEBUG - 2018-05-11 02:17:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 02:17:34 --> Input Class Initialized
INFO - 2018-05-11 02:17:34 --> Language Class Initialized
ERROR - 2018-05-11 02:17:34 --> 404 Page Not Found: /index
INFO - 2018-05-11 02:20:00 --> Config Class Initialized
INFO - 2018-05-11 02:20:00 --> Hooks Class Initialized
DEBUG - 2018-05-11 02:20:00 --> UTF-8 Support Enabled
INFO - 2018-05-11 02:20:00 --> Utf8 Class Initialized
INFO - 2018-05-11 02:20:00 --> URI Class Initialized
DEBUG - 2018-05-11 02:20:00 --> No URI present. Default controller set.
INFO - 2018-05-11 02:20:00 --> Router Class Initialized
INFO - 2018-05-11 02:20:01 --> Output Class Initialized
INFO - 2018-05-11 02:20:01 --> Security Class Initialized
DEBUG - 2018-05-11 02:20:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 02:20:01 --> Input Class Initialized
INFO - 2018-05-11 02:20:01 --> Language Class Initialized
INFO - 2018-05-11 02:20:01 --> Language Class Initialized
INFO - 2018-05-11 02:20:01 --> Config Class Initialized
INFO - 2018-05-11 02:20:01 --> Loader Class Initialized
DEBUG - 2018-05-11 02:20:01 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-11 02:20:01 --> Helper loaded: url_helper
INFO - 2018-05-11 02:20:01 --> Helper loaded: form_helper
INFO - 2018-05-11 02:20:01 --> Helper loaded: date_helper
INFO - 2018-05-11 02:20:01 --> Helper loaded: util_helper
INFO - 2018-05-11 02:20:01 --> Helper loaded: text_helper
INFO - 2018-05-11 02:20:01 --> Helper loaded: string_helper
INFO - 2018-05-11 02:20:01 --> Database Driver Class Initialized
DEBUG - 2018-05-11 02:20:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-11 02:20:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-11 02:20:01 --> Email Class Initialized
INFO - 2018-05-11 02:20:01 --> Controller Class Initialized
DEBUG - 2018-05-11 02:20:01 --> Home MX_Controller Initialized
DEBUG - 2018-05-11 02:20:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/login.php
INFO - 2018-05-11 02:20:01 --> Final output sent to browser
DEBUG - 2018-05-11 02:20:01 --> Total execution time: 0.3177
INFO - 2018-05-11 02:20:40 --> Config Class Initialized
INFO - 2018-05-11 02:20:40 --> Hooks Class Initialized
DEBUG - 2018-05-11 02:20:40 --> UTF-8 Support Enabled
INFO - 2018-05-11 02:20:40 --> Utf8 Class Initialized
INFO - 2018-05-11 02:20:40 --> URI Class Initialized
INFO - 2018-05-11 02:20:40 --> Router Class Initialized
INFO - 2018-05-11 02:20:40 --> Output Class Initialized
INFO - 2018-05-11 02:20:40 --> Security Class Initialized
DEBUG - 2018-05-11 02:20:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 02:20:40 --> Input Class Initialized
INFO - 2018-05-11 02:20:40 --> Language Class Initialized
ERROR - 2018-05-11 02:20:40 --> 404 Page Not Found: /index
INFO - 2018-05-11 02:20:40 --> Config Class Initialized
INFO - 2018-05-11 02:20:40 --> Config Class Initialized
INFO - 2018-05-11 02:20:40 --> Config Class Initialized
INFO - 2018-05-11 02:20:40 --> Config Class Initialized
INFO - 2018-05-11 02:20:40 --> Config Class Initialized
INFO - 2018-05-11 02:20:40 --> Hooks Class Initialized
INFO - 2018-05-11 02:20:40 --> Hooks Class Initialized
INFO - 2018-05-11 02:20:40 --> Hooks Class Initialized
INFO - 2018-05-11 02:20:40 --> Hooks Class Initialized
INFO - 2018-05-11 02:20:40 --> Hooks Class Initialized
DEBUG - 2018-05-11 02:20:40 --> UTF-8 Support Enabled
DEBUG - 2018-05-11 02:20:40 --> UTF-8 Support Enabled
DEBUG - 2018-05-11 02:20:40 --> UTF-8 Support Enabled
DEBUG - 2018-05-11 02:20:40 --> UTF-8 Support Enabled
DEBUG - 2018-05-11 02:20:40 --> UTF-8 Support Enabled
INFO - 2018-05-11 02:20:40 --> Utf8 Class Initialized
INFO - 2018-05-11 02:20:40 --> Utf8 Class Initialized
INFO - 2018-05-11 02:20:40 --> Utf8 Class Initialized
INFO - 2018-05-11 02:20:40 --> Utf8 Class Initialized
INFO - 2018-05-11 02:20:40 --> URI Class Initialized
INFO - 2018-05-11 02:20:40 --> Utf8 Class Initialized
INFO - 2018-05-11 02:20:40 --> URI Class Initialized
INFO - 2018-05-11 02:20:40 --> Router Class Initialized
INFO - 2018-05-11 02:20:40 --> URI Class Initialized
INFO - 2018-05-11 02:20:40 --> Output Class Initialized
INFO - 2018-05-11 02:20:40 --> Router Class Initialized
INFO - 2018-05-11 02:20:40 --> Router Class Initialized
INFO - 2018-05-11 02:20:40 --> URI Class Initialized
INFO - 2018-05-11 02:20:40 --> URI Class Initialized
INFO - 2018-05-11 02:20:40 --> Security Class Initialized
INFO - 2018-05-11 02:20:40 --> Output Class Initialized
INFO - 2018-05-11 02:20:40 --> Output Class Initialized
INFO - 2018-05-11 02:20:40 --> Router Class Initialized
DEBUG - 2018-05-11 02:20:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 02:20:40 --> Security Class Initialized
INFO - 2018-05-11 02:20:40 --> Security Class Initialized
INFO - 2018-05-11 02:20:40 --> Router Class Initialized
INFO - 2018-05-11 02:20:40 --> Input Class Initialized
INFO - 2018-05-11 02:20:40 --> Output Class Initialized
DEBUG - 2018-05-11 02:20:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 02:20:40 --> Output Class Initialized
INFO - 2018-05-11 02:20:40 --> Language Class Initialized
DEBUG - 2018-05-11 02:20:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 02:20:40 --> Security Class Initialized
INFO - 2018-05-11 02:20:40 --> Input Class Initialized
INFO - 2018-05-11 02:20:40 --> Security Class Initialized
INFO - 2018-05-11 02:20:40 --> Input Class Initialized
ERROR - 2018-05-11 02:20:40 --> 404 Page Not Found: /index
DEBUG - 2018-05-11 02:20:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 02:20:40 --> Language Class Initialized
DEBUG - 2018-05-11 02:20:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 02:20:40 --> Language Class Initialized
INFO - 2018-05-11 02:20:40 --> Input Class Initialized
ERROR - 2018-05-11 02:20:40 --> 404 Page Not Found: /index
INFO - 2018-05-11 02:20:40 --> Input Class Initialized
ERROR - 2018-05-11 02:20:40 --> 404 Page Not Found: /index
INFO - 2018-05-11 02:20:40 --> Language Class Initialized
INFO - 2018-05-11 02:20:40 --> Language Class Initialized
ERROR - 2018-05-11 02:20:41 --> 404 Page Not Found: /index
ERROR - 2018-05-11 02:20:41 --> 404 Page Not Found: /index
INFO - 2018-05-11 02:20:41 --> Config Class Initialized
INFO - 2018-05-11 02:20:41 --> Config Class Initialized
INFO - 2018-05-11 02:20:41 --> Config Class Initialized
INFO - 2018-05-11 02:20:41 --> Config Class Initialized
INFO - 2018-05-11 02:20:41 --> Hooks Class Initialized
INFO - 2018-05-11 02:20:41 --> Hooks Class Initialized
INFO - 2018-05-11 02:20:41 --> Hooks Class Initialized
INFO - 2018-05-11 02:20:41 --> Hooks Class Initialized
DEBUG - 2018-05-11 02:20:41 --> UTF-8 Support Enabled
INFO - 2018-05-11 02:20:41 --> Utf8 Class Initialized
DEBUG - 2018-05-11 02:20:41 --> UTF-8 Support Enabled
DEBUG - 2018-05-11 02:20:41 --> UTF-8 Support Enabled
DEBUG - 2018-05-11 02:20:41 --> UTF-8 Support Enabled
INFO - 2018-05-11 02:20:41 --> Utf8 Class Initialized
INFO - 2018-05-11 02:20:41 --> Utf8 Class Initialized
INFO - 2018-05-11 02:20:41 --> URI Class Initialized
INFO - 2018-05-11 02:20:41 --> Utf8 Class Initialized
INFO - 2018-05-11 02:20:41 --> Router Class Initialized
INFO - 2018-05-11 02:20:41 --> URI Class Initialized
INFO - 2018-05-11 02:20:41 --> URI Class Initialized
INFO - 2018-05-11 02:20:41 --> URI Class Initialized
INFO - 2018-05-11 02:20:41 --> Output Class Initialized
INFO - 2018-05-11 02:20:41 --> Router Class Initialized
INFO - 2018-05-11 02:20:41 --> Security Class Initialized
INFO - 2018-05-11 02:20:41 --> Output Class Initialized
DEBUG - 2018-05-11 02:20:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 02:20:41 --> Security Class Initialized
INFO - 2018-05-11 02:20:41 --> Input Class Initialized
DEBUG - 2018-05-11 02:20:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 02:20:41 --> Router Class Initialized
INFO - 2018-05-11 02:20:41 --> Router Class Initialized
INFO - 2018-05-11 02:20:41 --> Language Class Initialized
ERROR - 2018-05-11 02:20:41 --> 404 Page Not Found: /index
INFO - 2018-05-11 02:20:41 --> Input Class Initialized
INFO - 2018-05-11 02:20:41 --> Output Class Initialized
INFO - 2018-05-11 02:20:41 --> Output Class Initialized
INFO - 2018-05-11 02:20:41 --> Language Class Initialized
INFO - 2018-05-11 02:20:41 --> Config Class Initialized
INFO - 2018-05-11 02:20:41 --> Hooks Class Initialized
ERROR - 2018-05-11 02:20:41 --> 404 Page Not Found: /index
DEBUG - 2018-05-11 02:20:41 --> UTF-8 Support Enabled
INFO - 2018-05-11 02:20:41 --> Security Class Initialized
INFO - 2018-05-11 02:20:41 --> Security Class Initialized
INFO - 2018-05-11 02:20:41 --> Utf8 Class Initialized
INFO - 2018-05-11 02:20:41 --> Config Class Initialized
INFO - 2018-05-11 02:20:41 --> Hooks Class Initialized
INFO - 2018-05-11 02:20:41 --> URI Class Initialized
DEBUG - 2018-05-11 02:20:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-11 02:20:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-11 02:20:41 --> UTF-8 Support Enabled
INFO - 2018-05-11 02:20:41 --> Router Class Initialized
INFO - 2018-05-11 02:20:41 --> Input Class Initialized
INFO - 2018-05-11 02:20:41 --> Input Class Initialized
INFO - 2018-05-11 02:20:41 --> Utf8 Class Initialized
INFO - 2018-05-11 02:20:41 --> Language Class Initialized
INFO - 2018-05-11 02:20:41 --> Language Class Initialized
INFO - 2018-05-11 02:20:41 --> Output Class Initialized
INFO - 2018-05-11 02:20:41 --> URI Class Initialized
ERROR - 2018-05-11 02:20:41 --> 404 Page Not Found: /index
ERROR - 2018-05-11 02:20:41 --> 404 Page Not Found: /index
INFO - 2018-05-11 02:20:41 --> Security Class Initialized
INFO - 2018-05-11 02:20:41 --> Router Class Initialized
INFO - 2018-05-11 02:20:41 --> Config Class Initialized
INFO - 2018-05-11 02:20:41 --> Config Class Initialized
DEBUG - 2018-05-11 02:20:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 02:20:41 --> Hooks Class Initialized
INFO - 2018-05-11 02:20:41 --> Hooks Class Initialized
INFO - 2018-05-11 02:20:41 --> Output Class Initialized
INFO - 2018-05-11 02:20:41 --> Input Class Initialized
DEBUG - 2018-05-11 02:20:41 --> UTF-8 Support Enabled
INFO - 2018-05-11 02:20:41 --> Security Class Initialized
DEBUG - 2018-05-11 02:20:41 --> UTF-8 Support Enabled
INFO - 2018-05-11 02:20:41 --> Language Class Initialized
INFO - 2018-05-11 02:20:41 --> Utf8 Class Initialized
INFO - 2018-05-11 02:20:41 --> Utf8 Class Initialized
DEBUG - 2018-05-11 02:20:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-05-11 02:20:41 --> 404 Page Not Found: /index
INFO - 2018-05-11 02:20:41 --> URI Class Initialized
INFO - 2018-05-11 02:20:41 --> Input Class Initialized
INFO - 2018-05-11 02:20:41 --> URI Class Initialized
INFO - 2018-05-11 02:20:41 --> Router Class Initialized
INFO - 2018-05-11 02:20:41 --> Output Class Initialized
INFO - 2018-05-11 02:20:41 --> Language Class Initialized
INFO - 2018-05-11 02:20:41 --> Router Class Initialized
INFO - 2018-05-11 02:20:41 --> Security Class Initialized
ERROR - 2018-05-11 02:20:41 --> 404 Page Not Found: /index
INFO - 2018-05-11 02:20:41 --> Output Class Initialized
DEBUG - 2018-05-11 02:20:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 02:20:41 --> Security Class Initialized
INFO - 2018-05-11 02:20:41 --> Input Class Initialized
INFO - 2018-05-11 02:20:41 --> Language Class Initialized
DEBUG - 2018-05-11 02:20:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 02:20:41 --> Input Class Initialized
ERROR - 2018-05-11 02:20:41 --> 404 Page Not Found: /index
INFO - 2018-05-11 02:20:41 --> Language Class Initialized
ERROR - 2018-05-11 02:20:41 --> 404 Page Not Found: /index
INFO - 2018-05-11 05:11:32 --> Config Class Initialized
INFO - 2018-05-11 05:11:32 --> Config Class Initialized
INFO - 2018-05-11 05:11:32 --> Config Class Initialized
INFO - 2018-05-11 05:11:32 --> Config Class Initialized
INFO - 2018-05-11 05:11:32 --> Config Class Initialized
INFO - 2018-05-11 05:11:32 --> Hooks Class Initialized
INFO - 2018-05-11 05:11:32 --> Hooks Class Initialized
INFO - 2018-05-11 05:11:32 --> Hooks Class Initialized
INFO - 2018-05-11 05:11:32 --> Hooks Class Initialized
INFO - 2018-05-11 05:11:32 --> Hooks Class Initialized
DEBUG - 2018-05-11 05:11:32 --> UTF-8 Support Enabled
DEBUG - 2018-05-11 05:11:32 --> UTF-8 Support Enabled
DEBUG - 2018-05-11 05:11:32 --> UTF-8 Support Enabled
DEBUG - 2018-05-11 05:11:32 --> UTF-8 Support Enabled
DEBUG - 2018-05-11 05:11:32 --> UTF-8 Support Enabled
INFO - 2018-05-11 05:11:32 --> Utf8 Class Initialized
INFO - 2018-05-11 05:11:32 --> Utf8 Class Initialized
INFO - 2018-05-11 05:11:32 --> Utf8 Class Initialized
INFO - 2018-05-11 05:11:32 --> Utf8 Class Initialized
INFO - 2018-05-11 05:11:32 --> Utf8 Class Initialized
INFO - 2018-05-11 05:11:32 --> URI Class Initialized
INFO - 2018-05-11 05:11:32 --> URI Class Initialized
INFO - 2018-05-11 05:11:32 --> URI Class Initialized
INFO - 2018-05-11 05:11:32 --> URI Class Initialized
INFO - 2018-05-11 05:11:32 --> URI Class Initialized
INFO - 2018-05-11 05:11:32 --> Router Class Initialized
INFO - 2018-05-11 05:11:32 --> Router Class Initialized
INFO - 2018-05-11 05:11:32 --> Router Class Initialized
INFO - 2018-05-11 05:11:32 --> Output Class Initialized
INFO - 2018-05-11 05:11:32 --> Router Class Initialized
INFO - 2018-05-11 05:11:32 --> Output Class Initialized
INFO - 2018-05-11 05:11:32 --> Router Class Initialized
INFO - 2018-05-11 05:11:32 --> Output Class Initialized
INFO - 2018-05-11 05:11:32 --> Output Class Initialized
INFO - 2018-05-11 05:11:32 --> Security Class Initialized
INFO - 2018-05-11 05:11:32 --> Security Class Initialized
INFO - 2018-05-11 05:11:32 --> Output Class Initialized
INFO - 2018-05-11 05:11:32 --> Security Class Initialized
DEBUG - 2018-05-11 05:11:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-11 05:11:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-11 05:11:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 05:11:32 --> Input Class Initialized
INFO - 2018-05-11 05:11:32 --> Input Class Initialized
INFO - 2018-05-11 05:11:32 --> Security Class Initialized
INFO - 2018-05-11 05:11:32 --> Security Class Initialized
INFO - 2018-05-11 05:11:32 --> Input Class Initialized
INFO - 2018-05-11 05:11:32 --> Language Class Initialized
ERROR - 2018-05-11 05:11:32 --> 404 Page Not Found: /index
INFO - 2018-05-11 05:11:32 --> Language Class Initialized
INFO - 2018-05-11 05:11:32 --> Language Class Initialized
DEBUG - 2018-05-11 05:11:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-11 05:11:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 05:11:32 --> Config Class Initialized
INFO - 2018-05-11 05:11:32 --> Config Class Initialized
INFO - 2018-05-11 05:11:32 --> Hooks Class Initialized
ERROR - 2018-05-11 05:11:32 --> 404 Page Not Found: /index
INFO - 2018-05-11 05:11:32 --> Hooks Class Initialized
INFO - 2018-05-11 05:11:32 --> Input Class Initialized
ERROR - 2018-05-11 05:11:32 --> 404 Page Not Found: /index
INFO - 2018-05-11 05:11:32 --> Input Class Initialized
DEBUG - 2018-05-11 05:11:32 --> UTF-8 Support Enabled
INFO - 2018-05-11 05:11:32 --> Utf8 Class Initialized
DEBUG - 2018-05-11 05:11:32 --> UTF-8 Support Enabled
INFO - 2018-05-11 05:11:32 --> URI Class Initialized
INFO - 2018-05-11 05:11:32 --> Router Class Initialized
INFO - 2018-05-11 05:11:32 --> Config Class Initialized
INFO - 2018-05-11 05:11:32 --> Language Class Initialized
INFO - 2018-05-11 05:11:32 --> Language Class Initialized
INFO - 2018-05-11 05:11:32 --> Utf8 Class Initialized
INFO - 2018-05-11 05:11:32 --> Hooks Class Initialized
INFO - 2018-05-11 05:11:32 --> Output Class Initialized
ERROR - 2018-05-11 05:11:32 --> 404 Page Not Found: /index
ERROR - 2018-05-11 05:11:32 --> 404 Page Not Found: /index
INFO - 2018-05-11 05:11:32 --> Security Class Initialized
DEBUG - 2018-05-11 05:11:32 --> UTF-8 Support Enabled
INFO - 2018-05-11 05:11:32 --> Config Class Initialized
INFO - 2018-05-11 05:11:32 --> URI Class Initialized
INFO - 2018-05-11 05:11:32 --> Hooks Class Initialized
DEBUG - 2018-05-11 05:11:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 05:11:32 --> Utf8 Class Initialized
INFO - 2018-05-11 05:11:32 --> Router Class Initialized
DEBUG - 2018-05-11 05:11:32 --> UTF-8 Support Enabled
INFO - 2018-05-11 05:11:32 --> Utf8 Class Initialized
INFO - 2018-05-11 05:11:32 --> URI Class Initialized
INFO - 2018-05-11 05:11:32 --> Router Class Initialized
INFO - 2018-05-11 05:11:32 --> Output Class Initialized
INFO - 2018-05-11 05:11:32 --> Security Class Initialized
DEBUG - 2018-05-11 05:11:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 05:11:32 --> Input Class Initialized
INFO - 2018-05-11 05:11:32 --> Config Class Initialized
INFO - 2018-05-11 05:11:32 --> Hooks Class Initialized
INFO - 2018-05-11 05:11:32 --> Language Class Initialized
INFO - 2018-05-11 05:11:32 --> Input Class Initialized
INFO - 2018-05-11 05:11:32 --> URI Class Initialized
INFO - 2018-05-11 05:11:32 --> Output Class Initialized
DEBUG - 2018-05-11 05:11:32 --> UTF-8 Support Enabled
ERROR - 2018-05-11 05:11:32 --> 404 Page Not Found: /index
INFO - 2018-05-11 05:11:32 --> Security Class Initialized
INFO - 2018-05-11 05:11:32 --> Router Class Initialized
INFO - 2018-05-11 05:11:32 --> Language Class Initialized
INFO - 2018-05-11 05:11:32 --> Utf8 Class Initialized
INFO - 2018-05-11 05:11:32 --> URI Class Initialized
ERROR - 2018-05-11 05:11:32 --> 404 Page Not Found: /index
DEBUG - 2018-05-11 05:11:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 05:11:32 --> Output Class Initialized
INFO - 2018-05-11 05:11:32 --> Router Class Initialized
INFO - 2018-05-11 05:11:32 --> Output Class Initialized
INFO - 2018-05-11 05:11:32 --> Config Class Initialized
INFO - 2018-05-11 05:11:32 --> Input Class Initialized
INFO - 2018-05-11 05:11:32 --> Security Class Initialized
INFO - 2018-05-11 05:11:32 --> Hooks Class Initialized
INFO - 2018-05-11 05:11:32 --> Security Class Initialized
DEBUG - 2018-05-11 05:11:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 05:11:32 --> Language Class Initialized
DEBUG - 2018-05-11 05:11:32 --> UTF-8 Support Enabled
INFO - 2018-05-11 05:11:32 --> Utf8 Class Initialized
ERROR - 2018-05-11 05:11:32 --> 404 Page Not Found: /index
INFO - 2018-05-11 05:11:32 --> URI Class Initialized
INFO - 2018-05-11 05:11:32 --> Input Class Initialized
DEBUG - 2018-05-11 05:11:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 05:11:32 --> Language Class Initialized
INFO - 2018-05-11 05:11:32 --> Router Class Initialized
INFO - 2018-05-11 05:11:32 --> Config Class Initialized
INFO - 2018-05-11 05:11:32 --> Input Class Initialized
INFO - 2018-05-11 05:11:32 --> Hooks Class Initialized
ERROR - 2018-05-11 05:11:32 --> 404 Page Not Found: /index
INFO - 2018-05-11 05:11:32 --> Language Class Initialized
INFO - 2018-05-11 05:11:32 --> Output Class Initialized
DEBUG - 2018-05-11 05:11:32 --> UTF-8 Support Enabled
INFO - 2018-05-11 05:11:32 --> Utf8 Class Initialized
INFO - 2018-05-11 05:11:32 --> Security Class Initialized
ERROR - 2018-05-11 05:11:32 --> 404 Page Not Found: /index
INFO - 2018-05-11 05:11:32 --> URI Class Initialized
DEBUG - 2018-05-11 05:11:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 05:11:32 --> Config Class Initialized
INFO - 2018-05-11 05:11:33 --> Input Class Initialized
INFO - 2018-05-11 05:11:33 --> Config Class Initialized
INFO - 2018-05-11 05:11:33 --> Hooks Class Initialized
INFO - 2018-05-11 05:11:33 --> Language Class Initialized
INFO - 2018-05-11 05:11:33 --> Router Class Initialized
INFO - 2018-05-11 05:11:33 --> Hooks Class Initialized
ERROR - 2018-05-11 05:11:33 --> 404 Page Not Found: /index
DEBUG - 2018-05-11 05:11:33 --> UTF-8 Support Enabled
DEBUG - 2018-05-11 05:11:33 --> UTF-8 Support Enabled
INFO - 2018-05-11 05:11:33 --> Output Class Initialized
INFO - 2018-05-11 05:11:33 --> Utf8 Class Initialized
INFO - 2018-05-11 05:11:33 --> Utf8 Class Initialized
INFO - 2018-05-11 05:11:33 --> Security Class Initialized
INFO - 2018-05-11 05:11:33 --> URI Class Initialized
INFO - 2018-05-11 05:11:33 --> Router Class Initialized
INFO - 2018-05-11 05:11:33 --> URI Class Initialized
DEBUG - 2018-05-11 05:11:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 05:11:33 --> Output Class Initialized
INFO - 2018-05-11 05:11:33 --> Router Class Initialized
INFO - 2018-05-11 05:11:33 --> Input Class Initialized
INFO - 2018-05-11 05:11:33 --> Security Class Initialized
INFO - 2018-05-11 05:11:33 --> Output Class Initialized
INFO - 2018-05-11 05:11:33 --> Language Class Initialized
DEBUG - 2018-05-11 05:11:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 05:11:33 --> Security Class Initialized
DEBUG - 2018-05-11 05:11:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 05:11:33 --> Input Class Initialized
ERROR - 2018-05-11 05:11:33 --> 404 Page Not Found: /index
INFO - 2018-05-11 05:11:33 --> Input Class Initialized
INFO - 2018-05-11 05:11:33 --> Language Class Initialized
INFO - 2018-05-11 05:11:33 --> Language Class Initialized
ERROR - 2018-05-11 05:11:33 --> 404 Page Not Found: /index
ERROR - 2018-05-11 05:11:33 --> 404 Page Not Found: /index
INFO - 2018-05-11 05:28:40 --> Config Class Initialized
INFO - 2018-05-11 05:28:40 --> Hooks Class Initialized
DEBUG - 2018-05-11 05:28:40 --> UTF-8 Support Enabled
INFO - 2018-05-11 05:28:40 --> Utf8 Class Initialized
INFO - 2018-05-11 05:28:40 --> URI Class Initialized
INFO - 2018-05-11 05:28:40 --> Router Class Initialized
INFO - 2018-05-11 05:28:40 --> Output Class Initialized
INFO - 2018-05-11 05:28:40 --> Security Class Initialized
DEBUG - 2018-05-11 05:28:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 05:28:40 --> Input Class Initialized
INFO - 2018-05-11 05:28:40 --> Language Class Initialized
INFO - 2018-05-11 05:28:40 --> Language Class Initialized
INFO - 2018-05-11 05:28:40 --> Config Class Initialized
INFO - 2018-05-11 05:28:40 --> Loader Class Initialized
DEBUG - 2018-05-11 05:28:40 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-11 05:28:40 --> Helper loaded: url_helper
INFO - 2018-05-11 05:28:40 --> Helper loaded: form_helper
INFO - 2018-05-11 05:28:40 --> Helper loaded: date_helper
INFO - 2018-05-11 05:28:40 --> Helper loaded: util_helper
INFO - 2018-05-11 05:28:40 --> Helper loaded: text_helper
INFO - 2018-05-11 05:28:40 --> Helper loaded: string_helper
INFO - 2018-05-11 05:28:40 --> Database Driver Class Initialized
DEBUG - 2018-05-11 05:28:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-11 05:28:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-11 05:28:40 --> Email Class Initialized
INFO - 2018-05-11 05:28:40 --> Controller Class Initialized
DEBUG - 2018-05-11 05:28:40 --> Login MX_Controller Initialized
INFO - 2018-05-11 05:28:40 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-11 05:28:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-11 05:28:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-11 05:28:40 --> Email starts for admin@consulting.com fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
ERROR - 2018-05-11 05:28:40 --> Severity: Notice --> Undefined index: c_id E:\xampp\htdocs\consulting\application\modules\admin\models\Loginmdl.php 119
INFO - 2018-05-11 05:28:40 --> User session created for 1
INFO - 2018-05-11 05:28:40 --> Login status admin@consulting.com - success
INFO - 2018-05-11 05:28:40 --> Final output sent to browser
DEBUG - 2018-05-11 05:28:40 --> Total execution time: 0.6305
INFO - 2018-05-11 05:28:43 --> Config Class Initialized
INFO - 2018-05-11 05:28:43 --> Hooks Class Initialized
DEBUG - 2018-05-11 05:28:43 --> UTF-8 Support Enabled
INFO - 2018-05-11 05:28:43 --> Utf8 Class Initialized
INFO - 2018-05-11 05:28:43 --> URI Class Initialized
INFO - 2018-05-11 05:28:43 --> Router Class Initialized
INFO - 2018-05-11 05:28:43 --> Output Class Initialized
INFO - 2018-05-11 05:28:43 --> Security Class Initialized
DEBUG - 2018-05-11 05:28:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 05:28:43 --> Input Class Initialized
INFO - 2018-05-11 05:28:43 --> Language Class Initialized
INFO - 2018-05-11 05:28:43 --> Language Class Initialized
INFO - 2018-05-11 05:28:43 --> Config Class Initialized
INFO - 2018-05-11 05:28:43 --> Loader Class Initialized
DEBUG - 2018-05-11 05:28:43 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-11 05:28:43 --> Helper loaded: url_helper
INFO - 2018-05-11 05:28:43 --> Helper loaded: form_helper
INFO - 2018-05-11 05:28:43 --> Helper loaded: date_helper
INFO - 2018-05-11 05:28:43 --> Helper loaded: util_helper
INFO - 2018-05-11 05:28:43 --> Helper loaded: text_helper
INFO - 2018-05-11 05:28:43 --> Helper loaded: string_helper
INFO - 2018-05-11 05:28:43 --> Database Driver Class Initialized
DEBUG - 2018-05-11 05:28:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-11 05:28:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-11 05:28:43 --> Email Class Initialized
INFO - 2018-05-11 05:28:43 --> Controller Class Initialized
DEBUG - 2018-05-11 05:28:43 --> Admin MX_Controller Initialized
INFO - 2018-05-11 05:28:43 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-11 05:28:43 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-11 05:28:43 --> Login MX_Controller Initialized
DEBUG - 2018-05-11 05:28:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-11 05:28:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-11 05:28:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/logins/login.php
INFO - 2018-05-11 05:28:43 --> Config Class Initialized
INFO - 2018-05-11 05:28:43 --> Hooks Class Initialized
DEBUG - 2018-05-11 05:28:43 --> UTF-8 Support Enabled
INFO - 2018-05-11 05:28:43 --> Utf8 Class Initialized
INFO - 2018-05-11 05:28:43 --> URI Class Initialized
INFO - 2018-05-11 05:28:43 --> Router Class Initialized
INFO - 2018-05-11 05:28:43 --> Output Class Initialized
INFO - 2018-05-11 05:28:43 --> Security Class Initialized
DEBUG - 2018-05-11 05:28:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 05:28:43 --> Input Class Initialized
INFO - 2018-05-11 05:28:43 --> Language Class Initialized
ERROR - 2018-05-11 05:28:43 --> 404 Page Not Found: /index
INFO - 2018-05-11 05:28:59 --> Config Class Initialized
INFO - 2018-05-11 05:28:59 --> Hooks Class Initialized
DEBUG - 2018-05-11 05:28:59 --> UTF-8 Support Enabled
INFO - 2018-05-11 05:28:59 --> Utf8 Class Initialized
INFO - 2018-05-11 05:28:59 --> URI Class Initialized
INFO - 2018-05-11 05:28:59 --> Router Class Initialized
INFO - 2018-05-11 05:28:59 --> Output Class Initialized
INFO - 2018-05-11 05:28:59 --> Security Class Initialized
DEBUG - 2018-05-11 05:28:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 05:28:59 --> Input Class Initialized
INFO - 2018-05-11 05:28:59 --> Language Class Initialized
INFO - 2018-05-11 05:28:59 --> Language Class Initialized
INFO - 2018-05-11 05:28:59 --> Config Class Initialized
INFO - 2018-05-11 05:28:59 --> Loader Class Initialized
DEBUG - 2018-05-11 05:28:59 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-11 05:28:59 --> Helper loaded: url_helper
INFO - 2018-05-11 05:28:59 --> Helper loaded: form_helper
INFO - 2018-05-11 05:28:59 --> Helper loaded: date_helper
INFO - 2018-05-11 05:28:59 --> Helper loaded: util_helper
INFO - 2018-05-11 05:28:59 --> Helper loaded: text_helper
INFO - 2018-05-11 05:28:59 --> Helper loaded: string_helper
INFO - 2018-05-11 05:28:59 --> Database Driver Class Initialized
DEBUG - 2018-05-11 05:28:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-11 05:28:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-11 05:28:59 --> Email Class Initialized
INFO - 2018-05-11 05:28:59 --> Controller Class Initialized
DEBUG - 2018-05-11 05:28:59 --> Admin MX_Controller Initialized
INFO - 2018-05-11 05:28:59 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-11 05:28:59 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-11 05:28:59 --> Login MX_Controller Initialized
DEBUG - 2018-05-11 05:28:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-11 05:28:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-11 05:28:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/logins/login.php
INFO - 2018-05-11 05:28:59 --> Config Class Initialized
INFO - 2018-05-11 05:28:59 --> Hooks Class Initialized
DEBUG - 2018-05-11 05:28:59 --> UTF-8 Support Enabled
INFO - 2018-05-11 05:28:59 --> Utf8 Class Initialized
INFO - 2018-05-11 05:28:59 --> URI Class Initialized
INFO - 2018-05-11 05:28:59 --> Router Class Initialized
INFO - 2018-05-11 05:28:59 --> Output Class Initialized
INFO - 2018-05-11 05:28:59 --> Security Class Initialized
DEBUG - 2018-05-11 05:28:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 05:28:59 --> Input Class Initialized
INFO - 2018-05-11 05:28:59 --> Language Class Initialized
ERROR - 2018-05-11 05:28:59 --> 404 Page Not Found: /index
INFO - 2018-05-11 05:29:00 --> Config Class Initialized
INFO - 2018-05-11 05:29:00 --> Hooks Class Initialized
DEBUG - 2018-05-11 05:29:00 --> UTF-8 Support Enabled
INFO - 2018-05-11 05:29:00 --> Utf8 Class Initialized
INFO - 2018-05-11 05:29:00 --> URI Class Initialized
INFO - 2018-05-11 05:29:01 --> Router Class Initialized
INFO - 2018-05-11 05:29:01 --> Output Class Initialized
INFO - 2018-05-11 05:29:01 --> Security Class Initialized
DEBUG - 2018-05-11 05:29:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 05:29:01 --> Input Class Initialized
INFO - 2018-05-11 05:29:01 --> Language Class Initialized
INFO - 2018-05-11 05:29:01 --> Language Class Initialized
INFO - 2018-05-11 05:29:01 --> Config Class Initialized
INFO - 2018-05-11 05:29:01 --> Loader Class Initialized
DEBUG - 2018-05-11 05:29:01 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-11 05:29:01 --> Helper loaded: url_helper
INFO - 2018-05-11 05:29:01 --> Helper loaded: form_helper
INFO - 2018-05-11 05:29:01 --> Helper loaded: date_helper
INFO - 2018-05-11 05:29:01 --> Helper loaded: util_helper
INFO - 2018-05-11 05:29:01 --> Helper loaded: text_helper
INFO - 2018-05-11 05:29:01 --> Helper loaded: string_helper
INFO - 2018-05-11 05:29:01 --> Database Driver Class Initialized
DEBUG - 2018-05-11 05:29:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-11 05:29:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-11 05:29:01 --> Email Class Initialized
INFO - 2018-05-11 05:29:01 --> Controller Class Initialized
DEBUG - 2018-05-11 05:29:01 --> Login MX_Controller Initialized
INFO - 2018-05-11 05:29:01 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-11 05:29:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-11 05:29:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-11 05:29:01 --> Email starts for admin@consulting.com fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
ERROR - 2018-05-11 05:29:01 --> Severity: Notice --> Undefined index: c_id E:\xampp\htdocs\consulting\application\modules\admin\models\Loginmdl.php 119
INFO - 2018-05-11 05:29:01 --> User session created for 1
INFO - 2018-05-11 05:29:01 --> Login status admin@consulting.com - success
INFO - 2018-05-11 05:29:01 --> Final output sent to browser
DEBUG - 2018-05-11 05:29:01 --> Total execution time: 0.3795
INFO - 2018-05-11 05:29:14 --> Config Class Initialized
INFO - 2018-05-11 05:29:14 --> Hooks Class Initialized
DEBUG - 2018-05-11 05:29:14 --> UTF-8 Support Enabled
INFO - 2018-05-11 05:29:14 --> Utf8 Class Initialized
INFO - 2018-05-11 05:29:14 --> URI Class Initialized
INFO - 2018-05-11 05:29:14 --> Router Class Initialized
INFO - 2018-05-11 05:29:14 --> Output Class Initialized
INFO - 2018-05-11 05:29:14 --> Security Class Initialized
DEBUG - 2018-05-11 05:29:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 05:29:14 --> Input Class Initialized
INFO - 2018-05-11 05:29:14 --> Language Class Initialized
INFO - 2018-05-11 05:29:14 --> Language Class Initialized
INFO - 2018-05-11 05:29:14 --> Config Class Initialized
INFO - 2018-05-11 05:29:14 --> Loader Class Initialized
DEBUG - 2018-05-11 05:29:14 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-11 05:29:14 --> Helper loaded: url_helper
INFO - 2018-05-11 05:29:14 --> Helper loaded: form_helper
INFO - 2018-05-11 05:29:14 --> Helper loaded: date_helper
INFO - 2018-05-11 05:29:14 --> Helper loaded: util_helper
INFO - 2018-05-11 05:29:14 --> Helper loaded: text_helper
INFO - 2018-05-11 05:29:14 --> Helper loaded: string_helper
INFO - 2018-05-11 05:29:14 --> Database Driver Class Initialized
DEBUG - 2018-05-11 05:29:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-11 05:29:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-11 05:29:14 --> Email Class Initialized
INFO - 2018-05-11 05:29:14 --> Controller Class Initialized
DEBUG - 2018-05-11 05:29:14 --> Login MX_Controller Initialized
INFO - 2018-05-11 05:29:14 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-11 05:29:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-11 05:29:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-11 05:29:14 --> Email starts for admin@consulting.com fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
ERROR - 2018-05-11 05:29:14 --> Severity: Notice --> Undefined index: c_id E:\xampp\htdocs\consulting\application\modules\admin\models\Loginmdl.php 119
INFO - 2018-05-11 05:29:14 --> User session created for 1
INFO - 2018-05-11 05:29:14 --> Login status admin@consulting.com - success
INFO - 2018-05-11 05:29:14 --> Final output sent to browser
DEBUG - 2018-05-11 05:29:14 --> Total execution time: 0.5014
INFO - 2018-05-11 05:54:14 --> Config Class Initialized
INFO - 2018-05-11 05:54:14 --> Hooks Class Initialized
DEBUG - 2018-05-11 05:54:14 --> UTF-8 Support Enabled
INFO - 2018-05-11 05:54:14 --> Utf8 Class Initialized
INFO - 2018-05-11 05:54:14 --> URI Class Initialized
INFO - 2018-05-11 05:54:14 --> Router Class Initialized
INFO - 2018-05-11 05:54:14 --> Output Class Initialized
INFO - 2018-05-11 05:54:14 --> Security Class Initialized
DEBUG - 2018-05-11 05:54:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 05:54:14 --> Input Class Initialized
INFO - 2018-05-11 05:54:14 --> Language Class Initialized
INFO - 2018-05-11 05:54:14 --> Language Class Initialized
INFO - 2018-05-11 05:54:14 --> Config Class Initialized
INFO - 2018-05-11 05:54:14 --> Loader Class Initialized
DEBUG - 2018-05-11 05:54:14 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-11 05:54:14 --> Helper loaded: url_helper
INFO - 2018-05-11 05:54:14 --> Helper loaded: form_helper
INFO - 2018-05-11 05:54:14 --> Helper loaded: date_helper
INFO - 2018-05-11 05:54:14 --> Helper loaded: util_helper
INFO - 2018-05-11 05:54:14 --> Helper loaded: text_helper
INFO - 2018-05-11 05:54:14 --> Helper loaded: string_helper
INFO - 2018-05-11 05:54:14 --> Database Driver Class Initialized
DEBUG - 2018-05-11 05:54:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-11 05:54:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-11 05:54:14 --> Email Class Initialized
INFO - 2018-05-11 05:54:14 --> Controller Class Initialized
DEBUG - 2018-05-11 05:54:14 --> Login MX_Controller Initialized
INFO - 2018-05-11 05:54:14 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-11 05:54:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-11 05:54:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-11 05:54:14 --> Email starts for  fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-05-11 05:54:14 --> Login status  - failure
INFO - 2018-05-11 05:54:14 --> Final output sent to browser
DEBUG - 2018-05-11 05:54:14 --> Total execution time: 0.3579
INFO - 2018-05-11 05:54:20 --> Config Class Initialized
INFO - 2018-05-11 05:54:20 --> Hooks Class Initialized
DEBUG - 2018-05-11 05:54:20 --> UTF-8 Support Enabled
INFO - 2018-05-11 05:54:20 --> Utf8 Class Initialized
INFO - 2018-05-11 05:54:20 --> URI Class Initialized
DEBUG - 2018-05-11 05:54:20 --> No URI present. Default controller set.
INFO - 2018-05-11 05:54:20 --> Router Class Initialized
INFO - 2018-05-11 05:54:20 --> Output Class Initialized
INFO - 2018-05-11 05:54:20 --> Security Class Initialized
DEBUG - 2018-05-11 05:54:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 05:54:20 --> Input Class Initialized
INFO - 2018-05-11 05:54:20 --> Language Class Initialized
INFO - 2018-05-11 05:54:20 --> Language Class Initialized
INFO - 2018-05-11 05:54:20 --> Config Class Initialized
INFO - 2018-05-11 05:54:20 --> Loader Class Initialized
DEBUG - 2018-05-11 05:54:20 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-11 05:54:20 --> Helper loaded: url_helper
INFO - 2018-05-11 05:54:20 --> Helper loaded: form_helper
INFO - 2018-05-11 05:54:20 --> Helper loaded: date_helper
INFO - 2018-05-11 05:54:20 --> Helper loaded: util_helper
INFO - 2018-05-11 05:54:20 --> Helper loaded: text_helper
INFO - 2018-05-11 05:54:20 --> Helper loaded: string_helper
INFO - 2018-05-11 05:54:20 --> Database Driver Class Initialized
DEBUG - 2018-05-11 05:54:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-11 05:54:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-11 05:54:20 --> Email Class Initialized
INFO - 2018-05-11 05:54:20 --> Controller Class Initialized
DEBUG - 2018-05-11 05:54:20 --> Home MX_Controller Initialized
DEBUG - 2018-05-11 05:54:20 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-11 05:54:20 --> Login MX_Controller Initialized
INFO - 2018-05-11 05:54:20 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-11 05:54:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-11 05:54:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-11 05:54:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/logins/login.php
INFO - 2018-05-11 05:54:20 --> Config Class Initialized
INFO - 2018-05-11 05:54:20 --> Hooks Class Initialized
DEBUG - 2018-05-11 05:54:20 --> UTF-8 Support Enabled
INFO - 2018-05-11 05:54:20 --> Utf8 Class Initialized
INFO - 2018-05-11 05:54:20 --> URI Class Initialized
INFO - 2018-05-11 05:54:20 --> Router Class Initialized
INFO - 2018-05-11 05:54:20 --> Output Class Initialized
INFO - 2018-05-11 05:54:20 --> Security Class Initialized
DEBUG - 2018-05-11 05:54:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 05:54:20 --> Input Class Initialized
INFO - 2018-05-11 05:54:21 --> Language Class Initialized
ERROR - 2018-05-11 05:54:21 --> 404 Page Not Found: /index
INFO - 2018-05-11 05:54:27 --> Config Class Initialized
INFO - 2018-05-11 05:54:27 --> Hooks Class Initialized
DEBUG - 2018-05-11 05:54:27 --> UTF-8 Support Enabled
INFO - 2018-05-11 05:54:27 --> Utf8 Class Initialized
INFO - 2018-05-11 05:54:27 --> URI Class Initialized
DEBUG - 2018-05-11 05:54:27 --> No URI present. Default controller set.
INFO - 2018-05-11 05:54:27 --> Router Class Initialized
INFO - 2018-05-11 05:54:27 --> Output Class Initialized
INFO - 2018-05-11 05:54:27 --> Security Class Initialized
DEBUG - 2018-05-11 05:54:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 05:54:27 --> Input Class Initialized
INFO - 2018-05-11 05:54:27 --> Language Class Initialized
INFO - 2018-05-11 05:54:27 --> Language Class Initialized
INFO - 2018-05-11 05:54:27 --> Config Class Initialized
INFO - 2018-05-11 05:54:27 --> Loader Class Initialized
DEBUG - 2018-05-11 05:54:28 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-11 05:54:28 --> Helper loaded: url_helper
INFO - 2018-05-11 05:54:28 --> Helper loaded: form_helper
INFO - 2018-05-11 05:54:28 --> Helper loaded: date_helper
INFO - 2018-05-11 05:54:28 --> Helper loaded: util_helper
INFO - 2018-05-11 05:54:28 --> Helper loaded: text_helper
INFO - 2018-05-11 05:54:28 --> Helper loaded: string_helper
INFO - 2018-05-11 05:54:28 --> Database Driver Class Initialized
DEBUG - 2018-05-11 05:54:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-11 05:54:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-11 05:54:28 --> Email Class Initialized
INFO - 2018-05-11 05:54:28 --> Controller Class Initialized
DEBUG - 2018-05-11 05:54:28 --> Home MX_Controller Initialized
DEBUG - 2018-05-11 05:54:28 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-11 05:54:28 --> Login MX_Controller Initialized
INFO - 2018-05-11 05:54:28 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-11 05:54:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-11 05:54:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-11 05:54:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/logins/login.php
INFO - 2018-05-11 05:54:28 --> Config Class Initialized
INFO - 2018-05-11 05:54:28 --> Hooks Class Initialized
DEBUG - 2018-05-11 05:54:28 --> UTF-8 Support Enabled
INFO - 2018-05-11 05:54:28 --> Utf8 Class Initialized
INFO - 2018-05-11 05:54:28 --> URI Class Initialized
INFO - 2018-05-11 05:54:28 --> Router Class Initialized
INFO - 2018-05-11 05:54:28 --> Output Class Initialized
INFO - 2018-05-11 05:54:28 --> Security Class Initialized
DEBUG - 2018-05-11 05:54:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 05:54:28 --> Input Class Initialized
INFO - 2018-05-11 05:54:28 --> Language Class Initialized
ERROR - 2018-05-11 05:54:28 --> 404 Page Not Found: /index
INFO - 2018-05-11 05:54:58 --> Config Class Initialized
INFO - 2018-05-11 05:54:58 --> Hooks Class Initialized
DEBUG - 2018-05-11 05:54:58 --> UTF-8 Support Enabled
INFO - 2018-05-11 05:54:58 --> Utf8 Class Initialized
INFO - 2018-05-11 05:54:58 --> URI Class Initialized
DEBUG - 2018-05-11 05:54:58 --> No URI present. Default controller set.
INFO - 2018-05-11 05:54:58 --> Router Class Initialized
INFO - 2018-05-11 05:54:58 --> Output Class Initialized
INFO - 2018-05-11 05:54:58 --> Security Class Initialized
DEBUG - 2018-05-11 05:54:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 05:54:58 --> Input Class Initialized
INFO - 2018-05-11 05:54:58 --> Language Class Initialized
INFO - 2018-05-11 05:54:58 --> Language Class Initialized
INFO - 2018-05-11 05:54:58 --> Config Class Initialized
INFO - 2018-05-11 05:54:58 --> Loader Class Initialized
DEBUG - 2018-05-11 05:54:58 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-11 05:54:58 --> Helper loaded: url_helper
INFO - 2018-05-11 05:54:58 --> Helper loaded: form_helper
INFO - 2018-05-11 05:54:58 --> Helper loaded: date_helper
INFO - 2018-05-11 05:54:58 --> Helper loaded: util_helper
INFO - 2018-05-11 05:54:58 --> Helper loaded: text_helper
INFO - 2018-05-11 05:54:58 --> Helper loaded: string_helper
INFO - 2018-05-11 05:54:58 --> Database Driver Class Initialized
DEBUG - 2018-05-11 05:54:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-11 05:54:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-11 05:54:58 --> Email Class Initialized
INFO - 2018-05-11 05:54:58 --> Controller Class Initialized
DEBUG - 2018-05-11 05:54:58 --> Home MX_Controller Initialized
DEBUG - 2018-05-11 05:54:58 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-11 05:54:58 --> Login MX_Controller Initialized
INFO - 2018-05-11 05:54:58 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-11 05:54:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-11 05:54:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-11 05:54:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/login.php
INFO - 2018-05-11 05:59:29 --> Config Class Initialized
INFO - 2018-05-11 05:59:29 --> Hooks Class Initialized
DEBUG - 2018-05-11 05:59:29 --> UTF-8 Support Enabled
INFO - 2018-05-11 05:59:29 --> Utf8 Class Initialized
INFO - 2018-05-11 05:59:29 --> URI Class Initialized
DEBUG - 2018-05-11 05:59:29 --> No URI present. Default controller set.
INFO - 2018-05-11 05:59:29 --> Router Class Initialized
INFO - 2018-05-11 05:59:29 --> Output Class Initialized
INFO - 2018-05-11 05:59:29 --> Security Class Initialized
DEBUG - 2018-05-11 05:59:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 05:59:29 --> Input Class Initialized
INFO - 2018-05-11 05:59:29 --> Language Class Initialized
INFO - 2018-05-11 05:59:29 --> Language Class Initialized
INFO - 2018-05-11 05:59:29 --> Config Class Initialized
INFO - 2018-05-11 05:59:29 --> Loader Class Initialized
DEBUG - 2018-05-11 05:59:29 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-11 05:59:29 --> Helper loaded: url_helper
INFO - 2018-05-11 05:59:29 --> Helper loaded: form_helper
INFO - 2018-05-11 05:59:29 --> Helper loaded: date_helper
INFO - 2018-05-11 05:59:29 --> Helper loaded: util_helper
INFO - 2018-05-11 05:59:29 --> Helper loaded: text_helper
INFO - 2018-05-11 05:59:29 --> Helper loaded: string_helper
INFO - 2018-05-11 05:59:29 --> Database Driver Class Initialized
DEBUG - 2018-05-11 05:59:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-11 05:59:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-11 05:59:29 --> Email Class Initialized
INFO - 2018-05-11 05:59:29 --> Controller Class Initialized
DEBUG - 2018-05-11 05:59:29 --> Home MX_Controller Initialized
DEBUG - 2018-05-11 05:59:29 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-11 05:59:29 --> Login MX_Controller Initialized
INFO - 2018-05-11 05:59:29 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-11 05:59:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-11 05:59:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-11 05:59:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/login.php
INFO - 2018-05-11 05:59:37 --> Config Class Initialized
INFO - 2018-05-11 05:59:37 --> Hooks Class Initialized
DEBUG - 2018-05-11 05:59:37 --> UTF-8 Support Enabled
INFO - 2018-05-11 05:59:37 --> Utf8 Class Initialized
INFO - 2018-05-11 05:59:37 --> URI Class Initialized
INFO - 2018-05-11 05:59:37 --> Router Class Initialized
INFO - 2018-05-11 05:59:37 --> Output Class Initialized
INFO - 2018-05-11 05:59:37 --> Security Class Initialized
DEBUG - 2018-05-11 05:59:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 05:59:37 --> Input Class Initialized
INFO - 2018-05-11 05:59:37 --> Language Class Initialized
INFO - 2018-05-11 05:59:37 --> Language Class Initialized
INFO - 2018-05-11 05:59:37 --> Config Class Initialized
INFO - 2018-05-11 05:59:37 --> Loader Class Initialized
DEBUG - 2018-05-11 05:59:37 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-11 05:59:37 --> Helper loaded: url_helper
INFO - 2018-05-11 05:59:37 --> Helper loaded: form_helper
INFO - 2018-05-11 05:59:37 --> Helper loaded: date_helper
INFO - 2018-05-11 05:59:37 --> Helper loaded: util_helper
INFO - 2018-05-11 05:59:37 --> Helper loaded: text_helper
INFO - 2018-05-11 05:59:37 --> Helper loaded: string_helper
INFO - 2018-05-11 05:59:37 --> Database Driver Class Initialized
DEBUG - 2018-05-11 05:59:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-11 05:59:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-11 05:59:37 --> Email Class Initialized
INFO - 2018-05-11 05:59:37 --> Controller Class Initialized
DEBUG - 2018-05-11 05:59:37 --> Login MX_Controller Initialized
INFO - 2018-05-11 05:59:37 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-11 05:59:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-11 05:59:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-11 05:59:37 --> Email starts for  fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-05-11 05:59:37 --> Login status  - failure
INFO - 2018-05-11 05:59:37 --> Final output sent to browser
DEBUG - 2018-05-11 05:59:37 --> Total execution time: 0.4622
INFO - 2018-05-11 06:02:14 --> Config Class Initialized
INFO - 2018-05-11 06:02:14 --> Hooks Class Initialized
DEBUG - 2018-05-11 06:02:14 --> UTF-8 Support Enabled
INFO - 2018-05-11 06:02:14 --> Utf8 Class Initialized
INFO - 2018-05-11 06:02:14 --> URI Class Initialized
DEBUG - 2018-05-11 06:02:14 --> No URI present. Default controller set.
INFO - 2018-05-11 06:02:14 --> Router Class Initialized
INFO - 2018-05-11 06:02:14 --> Output Class Initialized
INFO - 2018-05-11 06:02:14 --> Security Class Initialized
DEBUG - 2018-05-11 06:02:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 06:02:14 --> Input Class Initialized
INFO - 2018-05-11 06:02:14 --> Language Class Initialized
INFO - 2018-05-11 06:02:14 --> Language Class Initialized
INFO - 2018-05-11 06:02:14 --> Config Class Initialized
INFO - 2018-05-11 06:02:14 --> Loader Class Initialized
DEBUG - 2018-05-11 06:02:14 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-11 06:02:14 --> Helper loaded: url_helper
INFO - 2018-05-11 06:02:14 --> Helper loaded: form_helper
INFO - 2018-05-11 06:02:14 --> Helper loaded: date_helper
INFO - 2018-05-11 06:02:14 --> Helper loaded: util_helper
INFO - 2018-05-11 06:02:14 --> Helper loaded: text_helper
INFO - 2018-05-11 06:02:14 --> Helper loaded: string_helper
INFO - 2018-05-11 06:02:14 --> Database Driver Class Initialized
DEBUG - 2018-05-11 06:02:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-11 06:02:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-11 06:02:14 --> Email Class Initialized
INFO - 2018-05-11 06:02:14 --> Controller Class Initialized
DEBUG - 2018-05-11 06:02:14 --> Home MX_Controller Initialized
DEBUG - 2018-05-11 06:02:14 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-11 06:02:14 --> Login MX_Controller Initialized
INFO - 2018-05-11 06:02:14 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-11 06:02:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-11 06:02:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-11 06:02:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/login.php
INFO - 2018-05-11 06:02:19 --> Config Class Initialized
INFO - 2018-05-11 06:02:19 --> Hooks Class Initialized
DEBUG - 2018-05-11 06:02:19 --> UTF-8 Support Enabled
INFO - 2018-05-11 06:02:19 --> Utf8 Class Initialized
INFO - 2018-05-11 06:02:19 --> URI Class Initialized
INFO - 2018-05-11 06:02:19 --> Router Class Initialized
INFO - 2018-05-11 06:02:19 --> Output Class Initialized
INFO - 2018-05-11 06:02:19 --> Security Class Initialized
DEBUG - 2018-05-11 06:02:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 06:02:19 --> Input Class Initialized
INFO - 2018-05-11 06:02:19 --> Language Class Initialized
INFO - 2018-05-11 06:02:19 --> Language Class Initialized
INFO - 2018-05-11 06:02:19 --> Config Class Initialized
INFO - 2018-05-11 06:02:19 --> Loader Class Initialized
DEBUG - 2018-05-11 06:02:19 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-11 06:02:19 --> Helper loaded: url_helper
INFO - 2018-05-11 06:02:19 --> Helper loaded: form_helper
INFO - 2018-05-11 06:02:19 --> Helper loaded: date_helper
INFO - 2018-05-11 06:02:19 --> Helper loaded: util_helper
INFO - 2018-05-11 06:02:19 --> Helper loaded: text_helper
INFO - 2018-05-11 06:02:19 --> Helper loaded: string_helper
INFO - 2018-05-11 06:02:19 --> Database Driver Class Initialized
DEBUG - 2018-05-11 06:02:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-11 06:02:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-11 06:02:19 --> Email Class Initialized
INFO - 2018-05-11 06:02:19 --> Controller Class Initialized
DEBUG - 2018-05-11 06:02:19 --> Login MX_Controller Initialized
INFO - 2018-05-11 06:02:19 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-11 06:02:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-11 06:02:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-11 06:02:19 --> Email starts for gopipanguluri123@gmail.com fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
ERROR - 2018-05-11 06:02:19 --> Severity: Notice --> Undefined variable: loggedin_user E:\xampp\htdocs\consulting\application\modules\admin\models\Loginmdl.php 66
INFO - 2018-05-11 06:02:19 --> User session created for 4
INFO - 2018-05-11 06:02:19 --> Login status gopipanguluri123@gmail.com - success
INFO - 2018-05-11 06:02:19 --> Final output sent to browser
DEBUG - 2018-05-11 06:02:19 --> Total execution time: 0.4778
INFO - 2018-05-11 06:02:49 --> Config Class Initialized
INFO - 2018-05-11 06:02:49 --> Hooks Class Initialized
DEBUG - 2018-05-11 06:02:49 --> UTF-8 Support Enabled
INFO - 2018-05-11 06:02:49 --> Utf8 Class Initialized
INFO - 2018-05-11 06:02:49 --> URI Class Initialized
INFO - 2018-05-11 06:02:49 --> Router Class Initialized
INFO - 2018-05-11 06:02:49 --> Output Class Initialized
INFO - 2018-05-11 06:02:49 --> Security Class Initialized
DEBUG - 2018-05-11 06:02:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 06:02:49 --> Input Class Initialized
INFO - 2018-05-11 06:02:49 --> Language Class Initialized
INFO - 2018-05-11 06:02:49 --> Language Class Initialized
INFO - 2018-05-11 06:02:49 --> Config Class Initialized
INFO - 2018-05-11 06:02:49 --> Loader Class Initialized
DEBUG - 2018-05-11 06:02:49 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-11 06:02:49 --> Helper loaded: url_helper
INFO - 2018-05-11 06:02:49 --> Helper loaded: form_helper
INFO - 2018-05-11 06:02:49 --> Helper loaded: date_helper
INFO - 2018-05-11 06:02:49 --> Helper loaded: util_helper
INFO - 2018-05-11 06:02:49 --> Helper loaded: text_helper
INFO - 2018-05-11 06:02:49 --> Helper loaded: string_helper
INFO - 2018-05-11 06:02:49 --> Database Driver Class Initialized
DEBUG - 2018-05-11 06:02:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-11 06:02:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-11 06:02:49 --> Email Class Initialized
INFO - 2018-05-11 06:02:49 --> Controller Class Initialized
DEBUG - 2018-05-11 06:02:49 --> Login MX_Controller Initialized
INFO - 2018-05-11 06:02:49 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-11 06:02:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-11 06:02:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-11 06:02:49 --> Email starts for gopipanguluri123@gmail.com fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
ERROR - 2018-05-11 06:02:49 --> Severity: Notice --> Undefined variable: loggedin_user E:\xampp\htdocs\consulting\application\modules\admin\models\Loginmdl.php 64
INFO - 2018-05-11 06:03:16 --> Config Class Initialized
INFO - 2018-05-11 06:03:16 --> Hooks Class Initialized
DEBUG - 2018-05-11 06:03:16 --> UTF-8 Support Enabled
INFO - 2018-05-11 06:03:16 --> Utf8 Class Initialized
INFO - 2018-05-11 06:03:16 --> URI Class Initialized
INFO - 2018-05-11 06:03:16 --> Router Class Initialized
INFO - 2018-05-11 06:03:16 --> Output Class Initialized
INFO - 2018-05-11 06:03:16 --> Security Class Initialized
DEBUG - 2018-05-11 06:03:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 06:03:16 --> Input Class Initialized
INFO - 2018-05-11 06:03:16 --> Language Class Initialized
INFO - 2018-05-11 06:03:16 --> Language Class Initialized
INFO - 2018-05-11 06:03:16 --> Config Class Initialized
INFO - 2018-05-11 06:03:16 --> Loader Class Initialized
DEBUG - 2018-05-11 06:03:16 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-11 06:03:17 --> Helper loaded: url_helper
INFO - 2018-05-11 06:03:17 --> Helper loaded: form_helper
INFO - 2018-05-11 06:03:17 --> Helper loaded: date_helper
INFO - 2018-05-11 06:03:17 --> Helper loaded: util_helper
INFO - 2018-05-11 06:03:17 --> Helper loaded: text_helper
INFO - 2018-05-11 06:03:17 --> Helper loaded: string_helper
INFO - 2018-05-11 06:03:17 --> Database Driver Class Initialized
DEBUG - 2018-05-11 06:03:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-11 06:03:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-11 06:03:17 --> Email Class Initialized
INFO - 2018-05-11 06:03:17 --> Controller Class Initialized
DEBUG - 2018-05-11 06:03:17 --> Login MX_Controller Initialized
INFO - 2018-05-11 06:03:17 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-11 06:03:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-11 06:03:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-11 06:03:17 --> Email starts for gopipanguluri123@gmail.com fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-05-11 06:04:23 --> Config Class Initialized
INFO - 2018-05-11 06:04:23 --> Hooks Class Initialized
DEBUG - 2018-05-11 06:04:23 --> UTF-8 Support Enabled
INFO - 2018-05-11 06:04:23 --> Utf8 Class Initialized
INFO - 2018-05-11 06:04:23 --> URI Class Initialized
INFO - 2018-05-11 06:04:23 --> Router Class Initialized
INFO - 2018-05-11 06:04:23 --> Output Class Initialized
INFO - 2018-05-11 06:04:23 --> Security Class Initialized
DEBUG - 2018-05-11 06:04:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 06:04:24 --> Input Class Initialized
INFO - 2018-05-11 06:04:24 --> Language Class Initialized
INFO - 2018-05-11 06:04:24 --> Language Class Initialized
INFO - 2018-05-11 06:04:24 --> Config Class Initialized
INFO - 2018-05-11 06:04:24 --> Loader Class Initialized
DEBUG - 2018-05-11 06:04:24 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-11 06:04:24 --> Helper loaded: url_helper
INFO - 2018-05-11 06:04:24 --> Helper loaded: form_helper
INFO - 2018-05-11 06:04:24 --> Helper loaded: date_helper
INFO - 2018-05-11 06:04:24 --> Helper loaded: util_helper
INFO - 2018-05-11 06:04:24 --> Helper loaded: text_helper
INFO - 2018-05-11 06:04:24 --> Helper loaded: string_helper
INFO - 2018-05-11 06:04:24 --> Database Driver Class Initialized
DEBUG - 2018-05-11 06:04:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-11 06:04:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-11 06:04:24 --> Email Class Initialized
INFO - 2018-05-11 06:04:24 --> Controller Class Initialized
DEBUG - 2018-05-11 06:04:24 --> Login MX_Controller Initialized
INFO - 2018-05-11 06:04:24 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-11 06:04:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-11 06:04:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-11 06:04:24 --> Email starts for gopipanguluri123@gmail.com fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-05-11 06:04:37 --> Config Class Initialized
INFO - 2018-05-11 06:04:37 --> Hooks Class Initialized
DEBUG - 2018-05-11 06:04:37 --> UTF-8 Support Enabled
INFO - 2018-05-11 06:04:37 --> Utf8 Class Initialized
INFO - 2018-05-11 06:04:37 --> URI Class Initialized
INFO - 2018-05-11 06:04:37 --> Router Class Initialized
INFO - 2018-05-11 06:04:37 --> Output Class Initialized
INFO - 2018-05-11 06:04:37 --> Security Class Initialized
DEBUG - 2018-05-11 06:04:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 06:04:37 --> Input Class Initialized
INFO - 2018-05-11 06:04:37 --> Language Class Initialized
INFO - 2018-05-11 06:04:37 --> Language Class Initialized
INFO - 2018-05-11 06:04:37 --> Config Class Initialized
INFO - 2018-05-11 06:04:37 --> Loader Class Initialized
DEBUG - 2018-05-11 06:04:37 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-11 06:04:37 --> Helper loaded: url_helper
INFO - 2018-05-11 06:04:37 --> Helper loaded: form_helper
INFO - 2018-05-11 06:04:37 --> Helper loaded: date_helper
INFO - 2018-05-11 06:04:37 --> Helper loaded: util_helper
INFO - 2018-05-11 06:04:37 --> Helper loaded: text_helper
INFO - 2018-05-11 06:04:37 --> Helper loaded: string_helper
INFO - 2018-05-11 06:04:37 --> Database Driver Class Initialized
DEBUG - 2018-05-11 06:04:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-11 06:04:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-11 06:04:37 --> Email Class Initialized
INFO - 2018-05-11 06:04:37 --> Controller Class Initialized
DEBUG - 2018-05-11 06:04:37 --> Login MX_Controller Initialized
INFO - 2018-05-11 06:04:37 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-11 06:04:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-11 06:04:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-11 06:04:37 --> Email starts for gopipanguluri123@gmail.com fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-05-11 06:04:52 --> Config Class Initialized
INFO - 2018-05-11 06:04:52 --> Hooks Class Initialized
DEBUG - 2018-05-11 06:04:52 --> UTF-8 Support Enabled
INFO - 2018-05-11 06:04:52 --> Utf8 Class Initialized
INFO - 2018-05-11 06:04:52 --> URI Class Initialized
INFO - 2018-05-11 06:04:52 --> Router Class Initialized
INFO - 2018-05-11 06:04:53 --> Output Class Initialized
INFO - 2018-05-11 06:04:53 --> Security Class Initialized
DEBUG - 2018-05-11 06:04:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 06:04:53 --> Input Class Initialized
INFO - 2018-05-11 06:04:53 --> Language Class Initialized
INFO - 2018-05-11 06:04:53 --> Language Class Initialized
INFO - 2018-05-11 06:04:53 --> Config Class Initialized
INFO - 2018-05-11 06:04:53 --> Loader Class Initialized
DEBUG - 2018-05-11 06:04:53 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-11 06:04:53 --> Helper loaded: url_helper
INFO - 2018-05-11 06:04:53 --> Helper loaded: form_helper
INFO - 2018-05-11 06:04:53 --> Helper loaded: date_helper
INFO - 2018-05-11 06:04:53 --> Helper loaded: util_helper
INFO - 2018-05-11 06:04:53 --> Helper loaded: text_helper
INFO - 2018-05-11 06:04:53 --> Helper loaded: string_helper
INFO - 2018-05-11 06:04:53 --> Database Driver Class Initialized
DEBUG - 2018-05-11 06:04:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-11 06:04:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-11 06:04:53 --> Email Class Initialized
INFO - 2018-05-11 06:04:53 --> Controller Class Initialized
DEBUG - 2018-05-11 06:04:53 --> Login MX_Controller Initialized
INFO - 2018-05-11 06:04:53 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-11 06:04:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-11 06:04:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-11 06:04:53 --> Email starts for gopipanguluri123@gmail.com fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-05-11 06:05:03 --> Config Class Initialized
INFO - 2018-05-11 06:05:03 --> Hooks Class Initialized
DEBUG - 2018-05-11 06:05:03 --> UTF-8 Support Enabled
INFO - 2018-05-11 06:05:03 --> Utf8 Class Initialized
INFO - 2018-05-11 06:05:03 --> URI Class Initialized
INFO - 2018-05-11 06:05:03 --> Router Class Initialized
INFO - 2018-05-11 06:05:03 --> Output Class Initialized
INFO - 2018-05-11 06:05:03 --> Security Class Initialized
DEBUG - 2018-05-11 06:05:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 06:05:03 --> Input Class Initialized
INFO - 2018-05-11 06:05:03 --> Language Class Initialized
INFO - 2018-05-11 06:05:03 --> Language Class Initialized
INFO - 2018-05-11 06:05:03 --> Config Class Initialized
INFO - 2018-05-11 06:05:03 --> Loader Class Initialized
DEBUG - 2018-05-11 06:05:03 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-11 06:05:04 --> Helper loaded: url_helper
INFO - 2018-05-11 06:05:04 --> Helper loaded: form_helper
INFO - 2018-05-11 06:05:04 --> Helper loaded: date_helper
INFO - 2018-05-11 06:05:04 --> Helper loaded: util_helper
INFO - 2018-05-11 06:05:04 --> Helper loaded: text_helper
INFO - 2018-05-11 06:05:04 --> Helper loaded: string_helper
INFO - 2018-05-11 06:05:04 --> Database Driver Class Initialized
DEBUG - 2018-05-11 06:05:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-11 06:05:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-11 06:05:04 --> Email Class Initialized
INFO - 2018-05-11 06:05:04 --> Controller Class Initialized
DEBUG - 2018-05-11 06:05:04 --> Login MX_Controller Initialized
INFO - 2018-05-11 06:05:04 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-11 06:05:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-11 06:05:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-11 06:05:04 --> Email starts for gopipanguluri123@gmail.com fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-05-11 06:05:04 --> User session created for 4
INFO - 2018-05-11 06:05:04 --> Login status gopipanguluri123@gmail.com - success
INFO - 2018-05-11 06:05:04 --> Final output sent to browser
DEBUG - 2018-05-11 06:05:04 --> Total execution time: 0.4600
INFO - 2018-05-11 06:05:52 --> Config Class Initialized
INFO - 2018-05-11 06:05:52 --> Hooks Class Initialized
DEBUG - 2018-05-11 06:05:52 --> UTF-8 Support Enabled
INFO - 2018-05-11 06:05:52 --> Utf8 Class Initialized
INFO - 2018-05-11 06:05:52 --> URI Class Initialized
INFO - 2018-05-11 06:05:52 --> Router Class Initialized
INFO - 2018-05-11 06:05:52 --> Output Class Initialized
INFO - 2018-05-11 06:05:52 --> Security Class Initialized
DEBUG - 2018-05-11 06:05:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 06:05:52 --> Input Class Initialized
INFO - 2018-05-11 06:05:52 --> Language Class Initialized
INFO - 2018-05-11 06:05:52 --> Language Class Initialized
INFO - 2018-05-11 06:05:52 --> Config Class Initialized
INFO - 2018-05-11 06:05:52 --> Loader Class Initialized
DEBUG - 2018-05-11 06:05:52 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-11 06:05:52 --> Helper loaded: url_helper
INFO - 2018-05-11 06:05:52 --> Helper loaded: form_helper
INFO - 2018-05-11 06:05:52 --> Helper loaded: date_helper
INFO - 2018-05-11 06:05:52 --> Helper loaded: util_helper
INFO - 2018-05-11 06:05:52 --> Helper loaded: text_helper
INFO - 2018-05-11 06:05:52 --> Helper loaded: string_helper
INFO - 2018-05-11 06:05:52 --> Database Driver Class Initialized
DEBUG - 2018-05-11 06:05:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-11 06:05:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-11 06:05:52 --> Email Class Initialized
INFO - 2018-05-11 06:05:52 --> Controller Class Initialized
DEBUG - 2018-05-11 06:05:52 --> Login MX_Controller Initialized
INFO - 2018-05-11 06:05:52 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-11 06:05:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-11 06:05:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-11 06:05:52 --> Email starts for gopipanguluri123@gmail.com fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-05-11 06:05:52 --> User session created for 4
INFO - 2018-05-11 06:05:52 --> Login status gopipanguluri123@gmail.com - success
INFO - 2018-05-11 06:05:52 --> Final output sent to browser
DEBUG - 2018-05-11 06:05:52 --> Total execution time: 0.4511
INFO - 2018-05-11 06:05:59 --> Config Class Initialized
INFO - 2018-05-11 06:05:59 --> Hooks Class Initialized
DEBUG - 2018-05-11 06:05:59 --> UTF-8 Support Enabled
INFO - 2018-05-11 06:05:59 --> Utf8 Class Initialized
INFO - 2018-05-11 06:05:59 --> URI Class Initialized
DEBUG - 2018-05-11 06:05:59 --> No URI present. Default controller set.
INFO - 2018-05-11 06:05:59 --> Router Class Initialized
INFO - 2018-05-11 06:05:59 --> Output Class Initialized
INFO - 2018-05-11 06:05:59 --> Security Class Initialized
DEBUG - 2018-05-11 06:05:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 06:05:59 --> Input Class Initialized
INFO - 2018-05-11 06:05:59 --> Language Class Initialized
INFO - 2018-05-11 06:05:59 --> Language Class Initialized
INFO - 2018-05-11 06:05:59 --> Config Class Initialized
INFO - 2018-05-11 06:05:59 --> Loader Class Initialized
DEBUG - 2018-05-11 06:05:59 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-11 06:05:59 --> Helper loaded: url_helper
INFO - 2018-05-11 06:05:59 --> Helper loaded: form_helper
INFO - 2018-05-11 06:05:59 --> Helper loaded: date_helper
INFO - 2018-05-11 06:05:59 --> Helper loaded: util_helper
INFO - 2018-05-11 06:05:59 --> Helper loaded: text_helper
INFO - 2018-05-11 06:05:59 --> Helper loaded: string_helper
INFO - 2018-05-11 06:05:59 --> Database Driver Class Initialized
DEBUG - 2018-05-11 06:05:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-11 06:05:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-11 06:05:59 --> Email Class Initialized
INFO - 2018-05-11 06:05:59 --> Controller Class Initialized
DEBUG - 2018-05-11 06:05:59 --> Home MX_Controller Initialized
DEBUG - 2018-05-11 06:05:59 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-11 06:05:59 --> Login MX_Controller Initialized
INFO - 2018-05-11 06:05:59 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-11 06:05:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-11 06:05:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-11 06:05:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-05-11 06:05:59 --> Final output sent to browser
DEBUG - 2018-05-11 06:05:59 --> Total execution time: 0.4352
INFO - 2018-05-11 06:05:59 --> Config Class Initialized
INFO - 2018-05-11 06:05:59 --> Hooks Class Initialized
DEBUG - 2018-05-11 06:05:59 --> UTF-8 Support Enabled
INFO - 2018-05-11 06:05:59 --> Utf8 Class Initialized
INFO - 2018-05-11 06:05:59 --> URI Class Initialized
INFO - 2018-05-11 06:05:59 --> Router Class Initialized
INFO - 2018-05-11 06:05:59 --> Output Class Initialized
INFO - 2018-05-11 06:05:59 --> Security Class Initialized
DEBUG - 2018-05-11 06:05:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 06:05:59 --> Input Class Initialized
INFO - 2018-05-11 06:05:59 --> Language Class Initialized
ERROR - 2018-05-11 06:05:59 --> 404 Page Not Found: /index
INFO - 2018-05-11 06:06:00 --> Config Class Initialized
INFO - 2018-05-11 06:06:00 --> Config Class Initialized
INFO - 2018-05-11 06:06:00 --> Config Class Initialized
INFO - 2018-05-11 06:06:00 --> Config Class Initialized
INFO - 2018-05-11 06:06:00 --> Config Class Initialized
INFO - 2018-05-11 06:06:00 --> Config Class Initialized
INFO - 2018-05-11 06:06:00 --> Hooks Class Initialized
INFO - 2018-05-11 06:06:00 --> Hooks Class Initialized
INFO - 2018-05-11 06:06:00 --> Hooks Class Initialized
INFO - 2018-05-11 06:06:00 --> Hooks Class Initialized
INFO - 2018-05-11 06:06:00 --> Hooks Class Initialized
INFO - 2018-05-11 06:06:00 --> Hooks Class Initialized
DEBUG - 2018-05-11 06:06:00 --> UTF-8 Support Enabled
DEBUG - 2018-05-11 06:06:00 --> UTF-8 Support Enabled
DEBUG - 2018-05-11 06:06:00 --> UTF-8 Support Enabled
DEBUG - 2018-05-11 06:06:00 --> UTF-8 Support Enabled
DEBUG - 2018-05-11 06:06:00 --> UTF-8 Support Enabled
DEBUG - 2018-05-11 06:06:00 --> UTF-8 Support Enabled
INFO - 2018-05-11 06:06:00 --> Utf8 Class Initialized
INFO - 2018-05-11 06:06:00 --> Utf8 Class Initialized
INFO - 2018-05-11 06:06:00 --> Utf8 Class Initialized
INFO - 2018-05-11 06:06:00 --> Utf8 Class Initialized
INFO - 2018-05-11 06:06:00 --> Utf8 Class Initialized
INFO - 2018-05-11 06:06:00 --> URI Class Initialized
INFO - 2018-05-11 06:06:00 --> URI Class Initialized
INFO - 2018-05-11 06:06:00 --> URI Class Initialized
INFO - 2018-05-11 06:06:00 --> Utf8 Class Initialized
INFO - 2018-05-11 06:06:00 --> URI Class Initialized
INFO - 2018-05-11 06:06:00 --> URI Class Initialized
INFO - 2018-05-11 06:06:00 --> Router Class Initialized
INFO - 2018-05-11 06:06:00 --> Router Class Initialized
INFO - 2018-05-11 06:06:00 --> URI Class Initialized
INFO - 2018-05-11 06:06:00 --> Router Class Initialized
INFO - 2018-05-11 06:06:00 --> Router Class Initialized
INFO - 2018-05-11 06:06:00 --> Router Class Initialized
INFO - 2018-05-11 06:06:00 --> Output Class Initialized
INFO - 2018-05-11 06:06:00 --> Router Class Initialized
INFO - 2018-05-11 06:06:00 --> Output Class Initialized
INFO - 2018-05-11 06:06:00 --> Output Class Initialized
INFO - 2018-05-11 06:06:00 --> Output Class Initialized
INFO - 2018-05-11 06:06:00 --> Output Class Initialized
INFO - 2018-05-11 06:06:00 --> Security Class Initialized
INFO - 2018-05-11 06:06:00 --> Security Class Initialized
INFO - 2018-05-11 06:06:00 --> Output Class Initialized
INFO - 2018-05-11 06:06:00 --> Security Class Initialized
INFO - 2018-05-11 06:06:00 --> Security Class Initialized
INFO - 2018-05-11 06:06:00 --> Security Class Initialized
DEBUG - 2018-05-11 06:06:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 06:06:00 --> Input Class Initialized
INFO - 2018-05-11 06:06:00 --> Language Class Initialized
ERROR - 2018-05-11 06:06:00 --> 404 Page Not Found: /index
DEBUG - 2018-05-11 06:06:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 06:06:00 --> Input Class Initialized
DEBUG - 2018-05-11 06:06:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-11 06:06:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-11 06:06:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 06:06:00 --> Security Class Initialized
INFO - 2018-05-11 06:06:00 --> Language Class Initialized
INFO - 2018-05-11 06:06:00 --> Input Class Initialized
INFO - 2018-05-11 06:06:00 --> Input Class Initialized
ERROR - 2018-05-11 06:06:00 --> 404 Page Not Found: /index
DEBUG - 2018-05-11 06:06:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 06:06:00 --> Input Class Initialized
INFO - 2018-05-11 06:06:00 --> Language Class Initialized
INFO - 2018-05-11 06:06:00 --> Language Class Initialized
INFO - 2018-05-11 06:06:00 --> Language Class Initialized
INFO - 2018-05-11 06:06:00 --> Input Class Initialized
ERROR - 2018-05-11 06:06:00 --> 404 Page Not Found: /index
ERROR - 2018-05-11 06:06:00 --> 404 Page Not Found: /index
ERROR - 2018-05-11 06:06:00 --> 404 Page Not Found: /index
INFO - 2018-05-11 06:06:00 --> Language Class Initialized
ERROR - 2018-05-11 06:06:00 --> 404 Page Not Found: /index
INFO - 2018-05-11 06:06:00 --> Config Class Initialized
INFO - 2018-05-11 06:06:00 --> Config Class Initialized
INFO - 2018-05-11 06:06:00 --> Config Class Initialized
INFO - 2018-05-11 06:06:00 --> Config Class Initialized
INFO - 2018-05-11 06:06:00 --> Config Class Initialized
INFO - 2018-05-11 06:06:00 --> Hooks Class Initialized
INFO - 2018-05-11 06:06:00 --> Hooks Class Initialized
INFO - 2018-05-11 06:06:00 --> Hooks Class Initialized
INFO - 2018-05-11 06:06:00 --> Hooks Class Initialized
INFO - 2018-05-11 06:06:00 --> Hooks Class Initialized
DEBUG - 2018-05-11 06:06:00 --> UTF-8 Support Enabled
DEBUG - 2018-05-11 06:06:00 --> UTF-8 Support Enabled
INFO - 2018-05-11 06:06:00 --> Utf8 Class Initialized
INFO - 2018-05-11 06:06:00 --> URI Class Initialized
DEBUG - 2018-05-11 06:06:00 --> UTF-8 Support Enabled
DEBUG - 2018-05-11 06:06:00 --> UTF-8 Support Enabled
INFO - 2018-05-11 06:06:00 --> Utf8 Class Initialized
DEBUG - 2018-05-11 06:06:00 --> UTF-8 Support Enabled
INFO - 2018-05-11 06:06:00 --> Router Class Initialized
INFO - 2018-05-11 06:06:00 --> URI Class Initialized
INFO - 2018-05-11 06:06:00 --> Utf8 Class Initialized
INFO - 2018-05-11 06:06:00 --> Utf8 Class Initialized
INFO - 2018-05-11 06:06:00 --> Utf8 Class Initialized
INFO - 2018-05-11 06:06:00 --> URI Class Initialized
INFO - 2018-05-11 06:06:00 --> Output Class Initialized
INFO - 2018-05-11 06:06:00 --> URI Class Initialized
INFO - 2018-05-11 06:06:00 --> Router Class Initialized
INFO - 2018-05-11 06:06:00 --> URI Class Initialized
INFO - 2018-05-11 06:06:00 --> Security Class Initialized
INFO - 2018-05-11 06:06:00 --> Router Class Initialized
INFO - 2018-05-11 06:06:00 --> Output Class Initialized
INFO - 2018-05-11 06:06:00 --> Router Class Initialized
INFO - 2018-05-11 06:06:00 --> Router Class Initialized
INFO - 2018-05-11 06:06:00 --> Output Class Initialized
DEBUG - 2018-05-11 06:06:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 06:06:00 --> Security Class Initialized
INFO - 2018-05-11 06:06:00 --> Output Class Initialized
INFO - 2018-05-11 06:06:00 --> Output Class Initialized
INFO - 2018-05-11 06:06:00 --> Input Class Initialized
INFO - 2018-05-11 06:06:00 --> Security Class Initialized
INFO - 2018-05-11 06:06:00 --> Security Class Initialized
INFO - 2018-05-11 06:06:00 --> Security Class Initialized
DEBUG - 2018-05-11 06:06:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 06:06:01 --> Input Class Initialized
DEBUG - 2018-05-11 06:06:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-11 06:06:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-11 06:06:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 06:06:01 --> Language Class Initialized
INFO - 2018-05-11 06:06:01 --> Language Class Initialized
ERROR - 2018-05-11 06:06:01 --> 404 Page Not Found: /index
INFO - 2018-05-11 06:06:01 --> Input Class Initialized
INFO - 2018-05-11 06:06:01 --> Input Class Initialized
INFO - 2018-05-11 06:06:01 --> Input Class Initialized
ERROR - 2018-05-11 06:06:01 --> 404 Page Not Found: /index
INFO - 2018-05-11 06:06:01 --> Config Class Initialized
INFO - 2018-05-11 06:06:01 --> Hooks Class Initialized
INFO - 2018-05-11 06:06:01 --> Language Class Initialized
INFO - 2018-05-11 06:06:01 --> Config Class Initialized
DEBUG - 2018-05-11 06:06:01 --> UTF-8 Support Enabled
INFO - 2018-05-11 06:06:01 --> Language Class Initialized
INFO - 2018-05-11 06:06:01 --> Language Class Initialized
ERROR - 2018-05-11 06:06:01 --> 404 Page Not Found: /index
INFO - 2018-05-11 06:06:01 --> Hooks Class Initialized
ERROR - 2018-05-11 06:06:01 --> 404 Page Not Found: /index
ERROR - 2018-05-11 06:06:01 --> 404 Page Not Found: /index
INFO - 2018-05-11 06:06:01 --> Utf8 Class Initialized
INFO - 2018-05-11 06:06:01 --> Config Class Initialized
INFO - 2018-05-11 06:06:01 --> Hooks Class Initialized
INFO - 2018-05-11 06:06:01 --> URI Class Initialized
DEBUG - 2018-05-11 06:06:01 --> UTF-8 Support Enabled
INFO - 2018-05-11 06:06:01 --> Config Class Initialized
INFO - 2018-05-11 06:06:01 --> Config Class Initialized
INFO - 2018-05-11 06:06:01 --> Hooks Class Initialized
INFO - 2018-05-11 06:06:01 --> Hooks Class Initialized
DEBUG - 2018-05-11 06:06:01 --> UTF-8 Support Enabled
INFO - 2018-05-11 06:06:01 --> Utf8 Class Initialized
DEBUG - 2018-05-11 06:06:01 --> UTF-8 Support Enabled
INFO - 2018-05-11 06:06:01 --> Router Class Initialized
DEBUG - 2018-05-11 06:06:01 --> UTF-8 Support Enabled
INFO - 2018-05-11 06:06:01 --> Utf8 Class Initialized
INFO - 2018-05-11 06:06:01 --> URI Class Initialized
INFO - 2018-05-11 06:06:01 --> Utf8 Class Initialized
INFO - 2018-05-11 06:06:01 --> URI Class Initialized
INFO - 2018-05-11 06:06:01 --> Router Class Initialized
INFO - 2018-05-11 06:06:01 --> Router Class Initialized
INFO - 2018-05-11 06:06:01 --> Utf8 Class Initialized
INFO - 2018-05-11 06:06:01 --> URI Class Initialized
INFO - 2018-05-11 06:06:01 --> Output Class Initialized
INFO - 2018-05-11 06:06:01 --> URI Class Initialized
INFO - 2018-05-11 06:06:01 --> Router Class Initialized
INFO - 2018-05-11 06:06:01 --> Output Class Initialized
INFO - 2018-05-11 06:06:01 --> Security Class Initialized
INFO - 2018-05-11 06:06:01 --> Output Class Initialized
INFO - 2018-05-11 06:06:01 --> Security Class Initialized
INFO - 2018-05-11 06:06:01 --> Router Class Initialized
DEBUG - 2018-05-11 06:06:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 06:06:01 --> Security Class Initialized
INFO - 2018-05-11 06:06:01 --> Output Class Initialized
INFO - 2018-05-11 06:06:01 --> Input Class Initialized
DEBUG - 2018-05-11 06:06:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-11 06:06:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 06:06:01 --> Input Class Initialized
INFO - 2018-05-11 06:06:01 --> Security Class Initialized
INFO - 2018-05-11 06:06:01 --> Language Class Initialized
INFO - 2018-05-11 06:06:01 --> Input Class Initialized
INFO - 2018-05-11 06:06:01 --> Output Class Initialized
INFO - 2018-05-11 06:06:01 --> Language Class Initialized
DEBUG - 2018-05-11 06:06:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 06:06:01 --> Language Class Initialized
ERROR - 2018-05-11 06:06:01 --> 404 Page Not Found: /index
INFO - 2018-05-11 06:06:01 --> Security Class Initialized
INFO - 2018-05-11 06:06:01 --> Input Class Initialized
ERROR - 2018-05-11 06:06:01 --> 404 Page Not Found: /index
DEBUG - 2018-05-11 06:06:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-05-11 06:06:01 --> 404 Page Not Found: /index
INFO - 2018-05-11 06:06:01 --> Input Class Initialized
INFO - 2018-05-11 06:06:01 --> Language Class Initialized
INFO - 2018-05-11 06:06:01 --> Language Class Initialized
ERROR - 2018-05-11 06:06:01 --> 404 Page Not Found: /index
ERROR - 2018-05-11 06:06:01 --> 404 Page Not Found: /index
INFO - 2018-05-11 06:06:02 --> Config Class Initialized
INFO - 2018-05-11 06:06:03 --> Hooks Class Initialized
DEBUG - 2018-05-11 06:06:03 --> UTF-8 Support Enabled
INFO - 2018-05-11 06:06:03 --> Utf8 Class Initialized
INFO - 2018-05-11 06:06:03 --> URI Class Initialized
INFO - 2018-05-11 06:06:03 --> Router Class Initialized
INFO - 2018-05-11 06:06:03 --> Output Class Initialized
INFO - 2018-05-11 06:06:03 --> Security Class Initialized
DEBUG - 2018-05-11 06:06:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 06:06:03 --> Input Class Initialized
INFO - 2018-05-11 06:06:03 --> Language Class Initialized
ERROR - 2018-05-11 06:06:03 --> 404 Page Not Found: /index
INFO - 2018-05-11 06:06:03 --> Config Class Initialized
INFO - 2018-05-11 06:06:03 --> Hooks Class Initialized
DEBUG - 2018-05-11 06:06:03 --> UTF-8 Support Enabled
INFO - 2018-05-11 06:06:03 --> Utf8 Class Initialized
INFO - 2018-05-11 06:06:03 --> URI Class Initialized
INFO - 2018-05-11 06:06:03 --> Router Class Initialized
INFO - 2018-05-11 06:06:03 --> Output Class Initialized
INFO - 2018-05-11 06:06:03 --> Security Class Initialized
DEBUG - 2018-05-11 06:06:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 06:06:03 --> Input Class Initialized
INFO - 2018-05-11 06:06:03 --> Language Class Initialized
ERROR - 2018-05-11 06:06:03 --> 404 Page Not Found: /index
INFO - 2018-05-11 06:06:03 --> Config Class Initialized
INFO - 2018-05-11 06:06:03 --> Hooks Class Initialized
DEBUG - 2018-05-11 06:06:03 --> UTF-8 Support Enabled
INFO - 2018-05-11 06:06:03 --> Utf8 Class Initialized
INFO - 2018-05-11 06:06:03 --> URI Class Initialized
INFO - 2018-05-11 06:06:03 --> Router Class Initialized
INFO - 2018-05-11 06:06:03 --> Output Class Initialized
INFO - 2018-05-11 06:06:03 --> Security Class Initialized
DEBUG - 2018-05-11 06:06:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 06:06:03 --> Input Class Initialized
INFO - 2018-05-11 06:06:03 --> Language Class Initialized
ERROR - 2018-05-11 06:06:03 --> 404 Page Not Found: /index
INFO - 2018-05-11 06:08:30 --> Config Class Initialized
INFO - 2018-05-11 06:08:30 --> Hooks Class Initialized
DEBUG - 2018-05-11 06:08:30 --> UTF-8 Support Enabled
INFO - 2018-05-11 06:08:30 --> Utf8 Class Initialized
INFO - 2018-05-11 06:08:30 --> URI Class Initialized
INFO - 2018-05-11 06:08:30 --> Router Class Initialized
INFO - 2018-05-11 06:08:30 --> Output Class Initialized
INFO - 2018-05-11 06:08:30 --> Security Class Initialized
DEBUG - 2018-05-11 06:08:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 06:08:30 --> Input Class Initialized
INFO - 2018-05-11 06:08:30 --> Language Class Initialized
INFO - 2018-05-11 06:08:30 --> Language Class Initialized
INFO - 2018-05-11 06:08:30 --> Config Class Initialized
INFO - 2018-05-11 06:08:30 --> Loader Class Initialized
DEBUG - 2018-05-11 06:08:30 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-11 06:08:30 --> Helper loaded: url_helper
INFO - 2018-05-11 06:08:30 --> Helper loaded: form_helper
INFO - 2018-05-11 06:08:30 --> Helper loaded: date_helper
INFO - 2018-05-11 06:08:30 --> Helper loaded: util_helper
INFO - 2018-05-11 06:08:30 --> Helper loaded: text_helper
INFO - 2018-05-11 06:08:30 --> Helper loaded: string_helper
INFO - 2018-05-11 06:08:30 --> Database Driver Class Initialized
DEBUG - 2018-05-11 06:08:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-11 06:08:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-11 06:08:30 --> Email Class Initialized
INFO - 2018-05-11 06:08:30 --> Controller Class Initialized
DEBUG - 2018-05-11 06:08:30 --> Login MX_Controller Initialized
INFO - 2018-05-11 06:08:31 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-11 06:08:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-11 06:08:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-11 06:08:31 --> 4 Loggedout
INFO - 2018-05-11 06:08:31 --> Config Class Initialized
INFO - 2018-05-11 06:08:31 --> Hooks Class Initialized
DEBUG - 2018-05-11 06:08:31 --> UTF-8 Support Enabled
INFO - 2018-05-11 06:08:31 --> Utf8 Class Initialized
INFO - 2018-05-11 06:08:31 --> URI Class Initialized
INFO - 2018-05-11 06:08:31 --> Router Class Initialized
INFO - 2018-05-11 06:08:31 --> Output Class Initialized
INFO - 2018-05-11 06:08:31 --> Security Class Initialized
DEBUG - 2018-05-11 06:08:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 06:08:31 --> Input Class Initialized
INFO - 2018-05-11 06:08:31 --> Language Class Initialized
INFO - 2018-05-11 06:08:31 --> Language Class Initialized
INFO - 2018-05-11 06:08:31 --> Config Class Initialized
INFO - 2018-05-11 06:08:31 --> Loader Class Initialized
DEBUG - 2018-05-11 06:08:31 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-11 06:08:31 --> Helper loaded: url_helper
INFO - 2018-05-11 06:08:31 --> Helper loaded: form_helper
INFO - 2018-05-11 06:08:31 --> Helper loaded: date_helper
INFO - 2018-05-11 06:08:31 --> Helper loaded: util_helper
INFO - 2018-05-11 06:08:31 --> Helper loaded: text_helper
INFO - 2018-05-11 06:08:31 --> Helper loaded: string_helper
INFO - 2018-05-11 06:08:31 --> Database Driver Class Initialized
DEBUG - 2018-05-11 06:08:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-11 06:08:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-11 06:08:31 --> Email Class Initialized
INFO - 2018-05-11 06:08:31 --> Controller Class Initialized
DEBUG - 2018-05-11 06:08:31 --> Home MX_Controller Initialized
DEBUG - 2018-05-11 06:08:31 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-11 06:08:31 --> Login MX_Controller Initialized
INFO - 2018-05-11 06:08:31 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-11 06:08:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-11 06:08:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-11 06:08:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/login.php
INFO - 2018-05-11 06:09:05 --> Config Class Initialized
INFO - 2018-05-11 06:09:05 --> Hooks Class Initialized
DEBUG - 2018-05-11 06:09:05 --> UTF-8 Support Enabled
INFO - 2018-05-11 06:09:05 --> Utf8 Class Initialized
INFO - 2018-05-11 06:09:05 --> URI Class Initialized
INFO - 2018-05-11 06:09:05 --> Router Class Initialized
INFO - 2018-05-11 06:09:05 --> Output Class Initialized
INFO - 2018-05-11 06:09:05 --> Security Class Initialized
DEBUG - 2018-05-11 06:09:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 06:09:05 --> Input Class Initialized
INFO - 2018-05-11 06:09:05 --> Language Class Initialized
INFO - 2018-05-11 06:09:05 --> Language Class Initialized
INFO - 2018-05-11 06:09:05 --> Config Class Initialized
INFO - 2018-05-11 06:09:05 --> Loader Class Initialized
DEBUG - 2018-05-11 06:09:05 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-11 06:09:05 --> Helper loaded: url_helper
INFO - 2018-05-11 06:09:05 --> Helper loaded: form_helper
INFO - 2018-05-11 06:09:05 --> Helper loaded: date_helper
INFO - 2018-05-11 06:09:05 --> Helper loaded: util_helper
INFO - 2018-05-11 06:09:05 --> Helper loaded: text_helper
INFO - 2018-05-11 06:09:05 --> Helper loaded: string_helper
INFO - 2018-05-11 06:09:05 --> Database Driver Class Initialized
DEBUG - 2018-05-11 06:09:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-11 06:09:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-11 06:09:05 --> Email Class Initialized
INFO - 2018-05-11 06:09:05 --> Controller Class Initialized
DEBUG - 2018-05-11 06:09:05 --> Login MX_Controller Initialized
INFO - 2018-05-11 06:09:05 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-11 06:09:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-11 06:09:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-11 06:09:05 --> Email starts for gopipanguluri123@gmail.com fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-05-11 06:09:05 --> User session created for 4
INFO - 2018-05-11 06:09:05 --> Login status gopipanguluri123@gmail.com - success
INFO - 2018-05-11 06:09:05 --> Final output sent to browser
DEBUG - 2018-05-11 06:09:05 --> Total execution time: 0.4536
INFO - 2018-05-11 06:09:05 --> Config Class Initialized
INFO - 2018-05-11 06:09:05 --> Hooks Class Initialized
DEBUG - 2018-05-11 06:09:05 --> UTF-8 Support Enabled
INFO - 2018-05-11 06:09:05 --> Utf8 Class Initialized
INFO - 2018-05-11 06:09:05 --> URI Class Initialized
INFO - 2018-05-11 06:09:05 --> Router Class Initialized
INFO - 2018-05-11 06:09:05 --> Output Class Initialized
INFO - 2018-05-11 06:09:05 --> Security Class Initialized
DEBUG - 2018-05-11 06:09:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 06:09:05 --> Input Class Initialized
INFO - 2018-05-11 06:09:05 --> Language Class Initialized
INFO - 2018-05-11 06:09:05 --> Language Class Initialized
INFO - 2018-05-11 06:09:05 --> Config Class Initialized
INFO - 2018-05-11 06:09:05 --> Loader Class Initialized
DEBUG - 2018-05-11 06:09:05 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-11 06:09:05 --> Helper loaded: url_helper
INFO - 2018-05-11 06:09:05 --> Helper loaded: form_helper
INFO - 2018-05-11 06:09:05 --> Helper loaded: date_helper
INFO - 2018-05-11 06:09:05 --> Helper loaded: util_helper
INFO - 2018-05-11 06:09:05 --> Helper loaded: text_helper
INFO - 2018-05-11 06:09:05 --> Helper loaded: string_helper
INFO - 2018-05-11 06:09:05 --> Database Driver Class Initialized
DEBUG - 2018-05-11 06:09:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-11 06:09:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-11 06:09:05 --> Email Class Initialized
INFO - 2018-05-11 06:09:05 --> Controller Class Initialized
DEBUG - 2018-05-11 06:09:05 --> Home MX_Controller Initialized
DEBUG - 2018-05-11 06:09:05 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-11 06:09:05 --> Login MX_Controller Initialized
INFO - 2018-05-11 06:09:05 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-11 06:09:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-11 06:09:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-11 06:09:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-05-11 06:09:05 --> Final output sent to browser
DEBUG - 2018-05-11 06:09:06 --> Total execution time: 0.4148
INFO - 2018-05-11 06:09:06 --> Config Class Initialized
INFO - 2018-05-11 06:09:06 --> Hooks Class Initialized
DEBUG - 2018-05-11 06:09:06 --> UTF-8 Support Enabled
INFO - 2018-05-11 06:09:06 --> Utf8 Class Initialized
INFO - 2018-05-11 06:09:06 --> URI Class Initialized
INFO - 2018-05-11 06:09:06 --> Router Class Initialized
INFO - 2018-05-11 06:09:06 --> Output Class Initialized
INFO - 2018-05-11 06:09:06 --> Security Class Initialized
DEBUG - 2018-05-11 06:09:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 06:09:06 --> Input Class Initialized
INFO - 2018-05-11 06:09:06 --> Language Class Initialized
ERROR - 2018-05-11 06:09:06 --> 404 Page Not Found: /index
INFO - 2018-05-11 06:09:06 --> Config Class Initialized
INFO - 2018-05-11 06:09:06 --> Config Class Initialized
INFO - 2018-05-11 06:09:06 --> Config Class Initialized
INFO - 2018-05-11 06:09:06 --> Config Class Initialized
INFO - 2018-05-11 06:09:06 --> Hooks Class Initialized
INFO - 2018-05-11 06:09:06 --> Hooks Class Initialized
INFO - 2018-05-11 06:09:06 --> Config Class Initialized
INFO - 2018-05-11 06:09:06 --> Hooks Class Initialized
INFO - 2018-05-11 06:09:06 --> Config Class Initialized
INFO - 2018-05-11 06:09:06 --> Hooks Class Initialized
INFO - 2018-05-11 06:09:06 --> Hooks Class Initialized
DEBUG - 2018-05-11 06:09:06 --> UTF-8 Support Enabled
DEBUG - 2018-05-11 06:09:06 --> UTF-8 Support Enabled
DEBUG - 2018-05-11 06:09:06 --> UTF-8 Support Enabled
DEBUG - 2018-05-11 06:09:06 --> UTF-8 Support Enabled
DEBUG - 2018-05-11 06:09:06 --> UTF-8 Support Enabled
INFO - 2018-05-11 06:09:06 --> Hooks Class Initialized
INFO - 2018-05-11 06:09:06 --> Utf8 Class Initialized
INFO - 2018-05-11 06:09:06 --> Utf8 Class Initialized
INFO - 2018-05-11 06:09:06 --> Utf8 Class Initialized
INFO - 2018-05-11 06:09:06 --> Utf8 Class Initialized
INFO - 2018-05-11 06:09:06 --> URI Class Initialized
INFO - 2018-05-11 06:09:06 --> URI Class Initialized
INFO - 2018-05-11 06:09:06 --> URI Class Initialized
DEBUG - 2018-05-11 06:09:06 --> UTF-8 Support Enabled
INFO - 2018-05-11 06:09:06 --> Utf8 Class Initialized
INFO - 2018-05-11 06:09:06 --> URI Class Initialized
INFO - 2018-05-11 06:09:06 --> Router Class Initialized
INFO - 2018-05-11 06:09:06 --> Router Class Initialized
INFO - 2018-05-11 06:09:06 --> Router Class Initialized
INFO - 2018-05-11 06:09:06 --> Utf8 Class Initialized
INFO - 2018-05-11 06:09:06 --> Output Class Initialized
INFO - 2018-05-11 06:09:06 --> Output Class Initialized
INFO - 2018-05-11 06:09:06 --> Output Class Initialized
INFO - 2018-05-11 06:09:06 --> URI Class Initialized
INFO - 2018-05-11 06:09:06 --> Router Class Initialized
INFO - 2018-05-11 06:09:06 --> URI Class Initialized
INFO - 2018-05-11 06:09:06 --> Security Class Initialized
INFO - 2018-05-11 06:09:06 --> Security Class Initialized
INFO - 2018-05-11 06:09:06 --> Security Class Initialized
INFO - 2018-05-11 06:09:06 --> Router Class Initialized
INFO - 2018-05-11 06:09:06 --> Output Class Initialized
INFO - 2018-05-11 06:09:06 --> Router Class Initialized
DEBUG - 2018-05-11 06:09:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-11 06:09:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 06:09:06 --> Output Class Initialized
DEBUG - 2018-05-11 06:09:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 06:09:06 --> Input Class Initialized
INFO - 2018-05-11 06:09:06 --> Output Class Initialized
INFO - 2018-05-11 06:09:06 --> Security Class Initialized
INFO - 2018-05-11 06:09:06 --> Input Class Initialized
DEBUG - 2018-05-11 06:09:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 06:09:06 --> Security Class Initialized
INFO - 2018-05-11 06:09:06 --> Language Class Initialized
INFO - 2018-05-11 06:09:06 --> Input Class Initialized
INFO - 2018-05-11 06:09:06 --> Security Class Initialized
INFO - 2018-05-11 06:09:06 --> Language Class Initialized
INFO - 2018-05-11 06:09:06 --> Input Class Initialized
INFO - 2018-05-11 06:09:06 --> Language Class Initialized
DEBUG - 2018-05-11 06:09:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-05-11 06:09:06 --> 404 Page Not Found: /index
INFO - 2018-05-11 06:09:06 --> Language Class Initialized
DEBUG - 2018-05-11 06:09:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-05-11 06:09:06 --> 404 Page Not Found: /index
ERROR - 2018-05-11 06:09:06 --> 404 Page Not Found: /index
INFO - 2018-05-11 06:09:06 --> Input Class Initialized
INFO - 2018-05-11 06:09:07 --> Input Class Initialized
ERROR - 2018-05-11 06:09:07 --> 404 Page Not Found: /index
INFO - 2018-05-11 06:09:07 --> Language Class Initialized
INFO - 2018-05-11 06:09:07 --> Config Class Initialized
INFO - 2018-05-11 06:09:07 --> Config Class Initialized
INFO - 2018-05-11 06:09:07 --> Config Class Initialized
INFO - 2018-05-11 06:09:07 --> Hooks Class Initialized
INFO - 2018-05-11 06:09:07 --> Hooks Class Initialized
INFO - 2018-05-11 06:09:07 --> Hooks Class Initialized
INFO - 2018-05-11 06:09:07 --> Language Class Initialized
DEBUG - 2018-05-11 06:09:07 --> UTF-8 Support Enabled
ERROR - 2018-05-11 06:09:07 --> 404 Page Not Found: /index
INFO - 2018-05-11 06:09:07 --> Utf8 Class Initialized
DEBUG - 2018-05-11 06:09:07 --> UTF-8 Support Enabled
ERROR - 2018-05-11 06:09:07 --> 404 Page Not Found: /index
INFO - 2018-05-11 06:09:07 --> Config Class Initialized
INFO - 2018-05-11 06:09:07 --> Hooks Class Initialized
INFO - 2018-05-11 06:09:07 --> URI Class Initialized
DEBUG - 2018-05-11 06:09:07 --> UTF-8 Support Enabled
INFO - 2018-05-11 06:09:07 --> Utf8 Class Initialized
DEBUG - 2018-05-11 06:09:07 --> UTF-8 Support Enabled
INFO - 2018-05-11 06:09:07 --> Config Class Initialized
INFO - 2018-05-11 06:09:07 --> Utf8 Class Initialized
INFO - 2018-05-11 06:09:07 --> Hooks Class Initialized
INFO - 2018-05-11 06:09:07 --> URI Class Initialized
INFO - 2018-05-11 06:09:07 --> Utf8 Class Initialized
INFO - 2018-05-11 06:09:07 --> Router Class Initialized
INFO - 2018-05-11 06:09:07 --> Router Class Initialized
DEBUG - 2018-05-11 06:09:07 --> UTF-8 Support Enabled
INFO - 2018-05-11 06:09:07 --> URI Class Initialized
INFO - 2018-05-11 06:09:07 --> Output Class Initialized
INFO - 2018-05-11 06:09:07 --> URI Class Initialized
INFO - 2018-05-11 06:09:08 --> Output Class Initialized
INFO - 2018-05-11 06:09:08 --> Utf8 Class Initialized
INFO - 2018-05-11 06:09:08 --> Security Class Initialized
INFO - 2018-05-11 06:09:08 --> Router Class Initialized
INFO - 2018-05-11 06:09:08 --> Security Class Initialized
INFO - 2018-05-11 06:09:08 --> Router Class Initialized
INFO - 2018-05-11 06:09:08 --> URI Class Initialized
INFO - 2018-05-11 06:09:08 --> Router Class Initialized
INFO - 2018-05-11 06:09:08 --> Output Class Initialized
INFO - 2018-05-11 06:09:08 --> Security Class Initialized
DEBUG - 2018-05-11 06:09:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 06:09:08 --> Output Class Initialized
DEBUG - 2018-05-11 06:09:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 06:09:08 --> Output Class Initialized
DEBUG - 2018-05-11 06:09:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 06:09:08 --> Security Class Initialized
INFO - 2018-05-11 06:09:08 --> Input Class Initialized
INFO - 2018-05-11 06:09:08 --> Input Class Initialized
INFO - 2018-05-11 06:09:08 --> Security Class Initialized
INFO - 2018-05-11 06:09:08 --> Input Class Initialized
INFO - 2018-05-11 06:09:08 --> Language Class Initialized
DEBUG - 2018-05-11 06:09:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 06:09:08 --> Language Class Initialized
DEBUG - 2018-05-11 06:09:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 06:09:08 --> Language Class Initialized
ERROR - 2018-05-11 06:09:08 --> 404 Page Not Found: /index
INFO - 2018-05-11 06:09:08 --> Input Class Initialized
ERROR - 2018-05-11 06:09:08 --> 404 Page Not Found: /index
ERROR - 2018-05-11 06:09:08 --> 404 Page Not Found: /index
INFO - 2018-05-11 06:09:08 --> Input Class Initialized
INFO - 2018-05-11 06:09:08 --> Language Class Initialized
ERROR - 2018-05-11 06:09:08 --> 404 Page Not Found: /index
INFO - 2018-05-11 06:09:08 --> Language Class Initialized
ERROR - 2018-05-11 06:09:08 --> 404 Page Not Found: /index
INFO - 2018-05-11 06:09:08 --> Config Class Initialized
INFO - 2018-05-11 06:09:08 --> Config Class Initialized
INFO - 2018-05-11 06:09:08 --> Config Class Initialized
INFO - 2018-05-11 06:09:08 --> Config Class Initialized
INFO - 2018-05-11 06:09:08 --> Config Class Initialized
INFO - 2018-05-11 06:09:08 --> Hooks Class Initialized
INFO - 2018-05-11 06:09:08 --> Hooks Class Initialized
INFO - 2018-05-11 06:09:08 --> Hooks Class Initialized
INFO - 2018-05-11 06:09:08 --> Hooks Class Initialized
INFO - 2018-05-11 06:09:08 --> Hooks Class Initialized
DEBUG - 2018-05-11 06:09:09 --> UTF-8 Support Enabled
DEBUG - 2018-05-11 06:09:09 --> UTF-8 Support Enabled
DEBUG - 2018-05-11 06:09:09 --> UTF-8 Support Enabled
DEBUG - 2018-05-11 06:09:09 --> UTF-8 Support Enabled
DEBUG - 2018-05-11 06:09:09 --> UTF-8 Support Enabled
INFO - 2018-05-11 06:09:09 --> Utf8 Class Initialized
INFO - 2018-05-11 06:09:09 --> Config Class Initialized
INFO - 2018-05-11 06:09:09 --> Utf8 Class Initialized
INFO - 2018-05-11 06:09:09 --> Utf8 Class Initialized
INFO - 2018-05-11 06:09:09 --> Utf8 Class Initialized
INFO - 2018-05-11 06:09:09 --> Utf8 Class Initialized
INFO - 2018-05-11 06:09:09 --> Hooks Class Initialized
INFO - 2018-05-11 06:09:09 --> URI Class Initialized
INFO - 2018-05-11 06:09:09 --> URI Class Initialized
INFO - 2018-05-11 06:09:09 --> URI Class Initialized
INFO - 2018-05-11 06:09:09 --> URI Class Initialized
INFO - 2018-05-11 06:09:09 --> URI Class Initialized
DEBUG - 2018-05-11 06:09:09 --> UTF-8 Support Enabled
INFO - 2018-05-11 06:09:09 --> Utf8 Class Initialized
INFO - 2018-05-11 06:09:09 --> URI Class Initialized
INFO - 2018-05-11 06:09:09 --> Router Class Initialized
INFO - 2018-05-11 06:09:09 --> Router Class Initialized
INFO - 2018-05-11 06:09:09 --> Output Class Initialized
INFO - 2018-05-11 06:09:09 --> Security Class Initialized
DEBUG - 2018-05-11 06:09:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 06:09:09 --> Input Class Initialized
INFO - 2018-05-11 06:09:09 --> Language Class Initialized
ERROR - 2018-05-11 06:09:09 --> 404 Page Not Found: /index
INFO - 2018-05-11 06:09:09 --> Router Class Initialized
INFO - 2018-05-11 06:09:09 --> Router Class Initialized
INFO - 2018-05-11 06:09:09 --> Output Class Initialized
INFO - 2018-05-11 06:09:09 --> Router Class Initialized
INFO - 2018-05-11 06:09:09 --> Router Class Initialized
INFO - 2018-05-11 06:09:09 --> Output Class Initialized
INFO - 2018-05-11 06:09:09 --> Output Class Initialized
INFO - 2018-05-11 06:09:09 --> Config Class Initialized
INFO - 2018-05-11 06:09:09 --> Hooks Class Initialized
INFO - 2018-05-11 06:09:09 --> Security Class Initialized
INFO - 2018-05-11 06:09:09 --> Output Class Initialized
INFO - 2018-05-11 06:09:09 --> Security Class Initialized
INFO - 2018-05-11 06:09:09 --> Output Class Initialized
INFO - 2018-05-11 06:09:09 --> Security Class Initialized
DEBUG - 2018-05-11 06:09:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 06:09:09 --> Security Class Initialized
DEBUG - 2018-05-11 06:09:09 --> UTF-8 Support Enabled
INFO - 2018-05-11 06:09:09 --> Security Class Initialized
DEBUG - 2018-05-11 06:09:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-11 06:09:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 06:09:09 --> Input Class Initialized
DEBUG - 2018-05-11 06:09:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 06:09:09 --> Utf8 Class Initialized
DEBUG - 2018-05-11 06:09:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 06:09:09 --> Input Class Initialized
INFO - 2018-05-11 06:09:09 --> Language Class Initialized
INFO - 2018-05-11 06:09:09 --> Input Class Initialized
INFO - 2018-05-11 06:09:09 --> Language Class Initialized
INFO - 2018-05-11 06:09:09 --> Input Class Initialized
INFO - 2018-05-11 06:09:09 --> URI Class Initialized
INFO - 2018-05-11 06:09:09 --> Input Class Initialized
INFO - 2018-05-11 06:09:09 --> Language Class Initialized
ERROR - 2018-05-11 06:09:09 --> 404 Page Not Found: /index
ERROR - 2018-05-11 06:09:09 --> 404 Page Not Found: /index
INFO - 2018-05-11 06:09:09 --> Language Class Initialized
INFO - 2018-05-11 06:09:09 --> Language Class Initialized
INFO - 2018-05-11 06:09:09 --> Router Class Initialized
ERROR - 2018-05-11 06:09:09 --> 404 Page Not Found: /index
ERROR - 2018-05-11 06:09:09 --> 404 Page Not Found: /index
INFO - 2018-05-11 06:09:09 --> Output Class Initialized
ERROR - 2018-05-11 06:09:09 --> 404 Page Not Found: /index
INFO - 2018-05-11 06:09:09 --> Security Class Initialized
DEBUG - 2018-05-11 06:09:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 06:09:09 --> Input Class Initialized
INFO - 2018-05-11 06:09:09 --> Language Class Initialized
ERROR - 2018-05-11 06:09:09 --> 404 Page Not Found: /index
INFO - 2018-05-11 06:09:09 --> Config Class Initialized
INFO - 2018-05-11 06:09:09 --> Hooks Class Initialized
DEBUG - 2018-05-11 06:09:09 --> UTF-8 Support Enabled
INFO - 2018-05-11 06:09:09 --> Utf8 Class Initialized
INFO - 2018-05-11 06:09:09 --> URI Class Initialized
INFO - 2018-05-11 06:09:09 --> Router Class Initialized
INFO - 2018-05-11 06:09:09 --> Output Class Initialized
INFO - 2018-05-11 06:09:09 --> Security Class Initialized
DEBUG - 2018-05-11 06:09:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 06:09:09 --> Input Class Initialized
INFO - 2018-05-11 06:09:09 --> Language Class Initialized
ERROR - 2018-05-11 06:09:09 --> 404 Page Not Found: /index
INFO - 2018-05-11 06:09:09 --> Config Class Initialized
INFO - 2018-05-11 06:09:09 --> Hooks Class Initialized
DEBUG - 2018-05-11 06:09:09 --> UTF-8 Support Enabled
INFO - 2018-05-11 06:09:09 --> Utf8 Class Initialized
INFO - 2018-05-11 06:09:09 --> URI Class Initialized
INFO - 2018-05-11 06:09:09 --> Router Class Initialized
INFO - 2018-05-11 06:09:09 --> Output Class Initialized
INFO - 2018-05-11 06:09:10 --> Security Class Initialized
DEBUG - 2018-05-11 06:09:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 06:09:10 --> Input Class Initialized
INFO - 2018-05-11 06:09:10 --> Language Class Initialized
ERROR - 2018-05-11 06:09:10 --> 404 Page Not Found: /index
INFO - 2018-05-11 06:10:30 --> Config Class Initialized
INFO - 2018-05-11 06:10:30 --> Hooks Class Initialized
DEBUG - 2018-05-11 06:10:30 --> UTF-8 Support Enabled
INFO - 2018-05-11 06:10:30 --> Utf8 Class Initialized
INFO - 2018-05-11 06:10:31 --> URI Class Initialized
INFO - 2018-05-11 06:10:31 --> Router Class Initialized
INFO - 2018-05-11 06:10:31 --> Output Class Initialized
INFO - 2018-05-11 06:10:31 --> Security Class Initialized
DEBUG - 2018-05-11 06:10:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 06:10:31 --> Input Class Initialized
INFO - 2018-05-11 06:10:31 --> Language Class Initialized
INFO - 2018-05-11 06:10:31 --> Language Class Initialized
INFO - 2018-05-11 06:10:31 --> Config Class Initialized
INFO - 2018-05-11 06:10:31 --> Loader Class Initialized
DEBUG - 2018-05-11 06:10:31 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-11 06:10:31 --> Helper loaded: url_helper
INFO - 2018-05-11 06:10:31 --> Helper loaded: form_helper
INFO - 2018-05-11 06:10:31 --> Helper loaded: date_helper
INFO - 2018-05-11 06:10:31 --> Helper loaded: util_helper
INFO - 2018-05-11 06:10:31 --> Helper loaded: text_helper
INFO - 2018-05-11 06:10:31 --> Helper loaded: string_helper
INFO - 2018-05-11 06:10:31 --> Database Driver Class Initialized
DEBUG - 2018-05-11 06:10:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-11 06:10:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-11 06:10:31 --> Email Class Initialized
INFO - 2018-05-11 06:10:31 --> Controller Class Initialized
DEBUG - 2018-05-11 06:10:31 --> Home MX_Controller Initialized
DEBUG - 2018-05-11 06:10:31 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-11 06:10:31 --> Login MX_Controller Initialized
INFO - 2018-05-11 06:10:31 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-11 06:10:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-11 06:10:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-11 06:10:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-05-11 06:10:31 --> Final output sent to browser
DEBUG - 2018-05-11 06:10:31 --> Total execution time: 0.4364
INFO - 2018-05-11 06:10:31 --> Config Class Initialized
INFO - 2018-05-11 06:10:31 --> Hooks Class Initialized
DEBUG - 2018-05-11 06:10:31 --> UTF-8 Support Enabled
INFO - 2018-05-11 06:10:31 --> Utf8 Class Initialized
INFO - 2018-05-11 06:10:31 --> URI Class Initialized
INFO - 2018-05-11 06:10:31 --> Router Class Initialized
INFO - 2018-05-11 06:10:31 --> Output Class Initialized
INFO - 2018-05-11 06:10:31 --> Security Class Initialized
DEBUG - 2018-05-11 06:10:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 06:10:31 --> Input Class Initialized
INFO - 2018-05-11 06:10:31 --> Language Class Initialized
ERROR - 2018-05-11 06:10:31 --> 404 Page Not Found: /index
INFO - 2018-05-11 06:10:31 --> Config Class Initialized
INFO - 2018-05-11 06:10:31 --> Config Class Initialized
INFO - 2018-05-11 06:10:31 --> Config Class Initialized
INFO - 2018-05-11 06:10:31 --> Hooks Class Initialized
INFO - 2018-05-11 06:10:31 --> Hooks Class Initialized
INFO - 2018-05-11 06:10:31 --> Hooks Class Initialized
INFO - 2018-05-11 06:10:31 --> Config Class Initialized
INFO - 2018-05-11 06:10:31 --> Config Class Initialized
DEBUG - 2018-05-11 06:10:31 --> UTF-8 Support Enabled
INFO - 2018-05-11 06:10:31 --> Utf8 Class Initialized
INFO - 2018-05-11 06:10:31 --> Config Class Initialized
INFO - 2018-05-11 06:10:31 --> Hooks Class Initialized
INFO - 2018-05-11 06:10:31 --> Hooks Class Initialized
DEBUG - 2018-05-11 06:10:31 --> UTF-8 Support Enabled
DEBUG - 2018-05-11 06:10:31 --> UTF-8 Support Enabled
INFO - 2018-05-11 06:10:32 --> URI Class Initialized
INFO - 2018-05-11 06:10:32 --> Utf8 Class Initialized
INFO - 2018-05-11 06:10:32 --> Utf8 Class Initialized
DEBUG - 2018-05-11 06:10:32 --> UTF-8 Support Enabled
DEBUG - 2018-05-11 06:10:32 --> UTF-8 Support Enabled
INFO - 2018-05-11 06:10:32 --> Hooks Class Initialized
INFO - 2018-05-11 06:10:32 --> Router Class Initialized
INFO - 2018-05-11 06:10:32 --> Utf8 Class Initialized
INFO - 2018-05-11 06:10:32 --> URI Class Initialized
INFO - 2018-05-11 06:10:32 --> Utf8 Class Initialized
DEBUG - 2018-05-11 06:10:32 --> UTF-8 Support Enabled
INFO - 2018-05-11 06:10:32 --> Output Class Initialized
INFO - 2018-05-11 06:10:32 --> URI Class Initialized
INFO - 2018-05-11 06:10:32 --> Router Class Initialized
INFO - 2018-05-11 06:10:32 --> URI Class Initialized
INFO - 2018-05-11 06:10:32 --> Router Class Initialized
INFO - 2018-05-11 06:10:32 --> Security Class Initialized
INFO - 2018-05-11 06:10:32 --> Utf8 Class Initialized
INFO - 2018-05-11 06:10:32 --> URI Class Initialized
INFO - 2018-05-11 06:10:32 --> Output Class Initialized
INFO - 2018-05-11 06:10:32 --> Security Class Initialized
DEBUG - 2018-05-11 06:10:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 06:10:32 --> Input Class Initialized
INFO - 2018-05-11 06:10:32 --> Language Class Initialized
INFO - 2018-05-11 06:10:32 --> Router Class Initialized
DEBUG - 2018-05-11 06:10:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 06:10:32 --> Output Class Initialized
INFO - 2018-05-11 06:10:32 --> URI Class Initialized
ERROR - 2018-05-11 06:10:32 --> 404 Page Not Found: /index
INFO - 2018-05-11 06:10:32 --> Router Class Initialized
INFO - 2018-05-11 06:10:32 --> Security Class Initialized
INFO - 2018-05-11 06:10:32 --> Router Class Initialized
INFO - 2018-05-11 06:10:32 --> Output Class Initialized
INFO - 2018-05-11 06:10:32 --> Input Class Initialized
INFO - 2018-05-11 06:10:32 --> Output Class Initialized
INFO - 2018-05-11 06:10:32 --> Language Class Initialized
DEBUG - 2018-05-11 06:10:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 06:10:32 --> Security Class Initialized
INFO - 2018-05-11 06:10:32 --> Security Class Initialized
INFO - 2018-05-11 06:10:32 --> Config Class Initialized
INFO - 2018-05-11 06:10:32 --> Output Class Initialized
INFO - 2018-05-11 06:10:32 --> Hooks Class Initialized
ERROR - 2018-05-11 06:10:32 --> 404 Page Not Found: /index
INFO - 2018-05-11 06:10:32 --> Input Class Initialized
DEBUG - 2018-05-11 06:10:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-11 06:10:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 06:10:32 --> Security Class Initialized
INFO - 2018-05-11 06:10:32 --> Language Class Initialized
INFO - 2018-05-11 06:10:32 --> Input Class Initialized
INFO - 2018-05-11 06:10:32 --> Input Class Initialized
DEBUG - 2018-05-11 06:10:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 06:10:32 --> Config Class Initialized
DEBUG - 2018-05-11 06:10:32 --> UTF-8 Support Enabled
ERROR - 2018-05-11 06:10:32 --> 404 Page Not Found: /index
INFO - 2018-05-11 06:10:32 --> Hooks Class Initialized
INFO - 2018-05-11 06:10:32 --> Utf8 Class Initialized
INFO - 2018-05-11 06:10:32 --> Input Class Initialized
INFO - 2018-05-11 06:10:32 --> Language Class Initialized
INFO - 2018-05-11 06:10:32 --> Language Class Initialized
ERROR - 2018-05-11 06:10:32 --> 404 Page Not Found: /index
DEBUG - 2018-05-11 06:10:32 --> UTF-8 Support Enabled
INFO - 2018-05-11 06:10:32 --> URI Class Initialized
INFO - 2018-05-11 06:10:32 --> Language Class Initialized
ERROR - 2018-05-11 06:10:32 --> 404 Page Not Found: /index
INFO - 2018-05-11 06:10:32 --> Utf8 Class Initialized
ERROR - 2018-05-11 06:10:32 --> 404 Page Not Found: /index
INFO - 2018-05-11 06:10:32 --> URI Class Initialized
INFO - 2018-05-11 06:10:32 --> Router Class Initialized
INFO - 2018-05-11 06:10:32 --> Config Class Initialized
INFO - 2018-05-11 06:10:32 --> Config Class Initialized
INFO - 2018-05-11 06:10:32 --> Config Class Initialized
INFO - 2018-05-11 06:10:32 --> Hooks Class Initialized
INFO - 2018-05-11 06:10:32 --> Hooks Class Initialized
DEBUG - 2018-05-11 06:10:32 --> UTF-8 Support Enabled
INFO - 2018-05-11 06:10:32 --> Hooks Class Initialized
INFO - 2018-05-11 06:10:32 --> Output Class Initialized
INFO - 2018-05-11 06:10:32 --> Utf8 Class Initialized
DEBUG - 2018-05-11 06:10:32 --> UTF-8 Support Enabled
INFO - 2018-05-11 06:10:32 --> Router Class Initialized
INFO - 2018-05-11 06:10:32 --> Security Class Initialized
DEBUG - 2018-05-11 06:10:32 --> UTF-8 Support Enabled
INFO - 2018-05-11 06:10:32 --> Utf8 Class Initialized
INFO - 2018-05-11 06:10:32 --> Utf8 Class Initialized
INFO - 2018-05-11 06:10:32 --> Output Class Initialized
INFO - 2018-05-11 06:10:33 --> URI Class Initialized
DEBUG - 2018-05-11 06:10:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 06:10:33 --> URI Class Initialized
INFO - 2018-05-11 06:10:33 --> Router Class Initialized
INFO - 2018-05-11 06:10:33 --> Security Class Initialized
INFO - 2018-05-11 06:10:33 --> Router Class Initialized
INFO - 2018-05-11 06:10:33 --> Input Class Initialized
INFO - 2018-05-11 06:10:33 --> URI Class Initialized
INFO - 2018-05-11 06:10:33 --> Output Class Initialized
INFO - 2018-05-11 06:10:33 --> Security Class Initialized
DEBUG - 2018-05-11 06:10:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 06:10:33 --> Input Class Initialized
INFO - 2018-05-11 06:10:33 --> Language Class Initialized
DEBUG - 2018-05-11 06:10:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 06:10:33 --> Output Class Initialized
INFO - 2018-05-11 06:10:33 --> Router Class Initialized
INFO - 2018-05-11 06:10:33 --> Language Class Initialized
ERROR - 2018-05-11 06:10:33 --> 404 Page Not Found: /index
INFO - 2018-05-11 06:10:33 --> Input Class Initialized
INFO - 2018-05-11 06:10:33 --> Language Class Initialized
ERROR - 2018-05-11 06:10:33 --> 404 Page Not Found: /index
ERROR - 2018-05-11 06:10:33 --> 404 Page Not Found: /index
INFO - 2018-05-11 06:10:33 --> Output Class Initialized
INFO - 2018-05-11 06:10:33 --> Security Class Initialized
DEBUG - 2018-05-11 06:10:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 06:10:33 --> Input Class Initialized
INFO - 2018-05-11 06:10:33 --> Language Class Initialized
ERROR - 2018-05-11 06:10:33 --> 404 Page Not Found: /index
INFO - 2018-05-11 06:10:33 --> Security Class Initialized
DEBUG - 2018-05-11 06:10:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 06:10:33 --> Input Class Initialized
INFO - 2018-05-11 06:10:33 --> Language Class Initialized
ERROR - 2018-05-11 06:10:33 --> 404 Page Not Found: /index
INFO - 2018-05-11 06:10:33 --> Config Class Initialized
INFO - 2018-05-11 06:10:33 --> Config Class Initialized
INFO - 2018-05-11 06:10:33 --> Config Class Initialized
INFO - 2018-05-11 06:10:33 --> Config Class Initialized
INFO - 2018-05-11 06:10:33 --> Config Class Initialized
INFO - 2018-05-11 06:10:33 --> Hooks Class Initialized
INFO - 2018-05-11 06:10:33 --> Hooks Class Initialized
DEBUG - 2018-05-11 06:10:33 --> UTF-8 Support Enabled
INFO - 2018-05-11 06:10:33 --> Hooks Class Initialized
INFO - 2018-05-11 06:10:33 --> Hooks Class Initialized
INFO - 2018-05-11 06:10:33 --> Hooks Class Initialized
INFO - 2018-05-11 06:10:33 --> Utf8 Class Initialized
DEBUG - 2018-05-11 06:10:33 --> UTF-8 Support Enabled
INFO - 2018-05-11 06:10:33 --> Utf8 Class Initialized
DEBUG - 2018-05-11 06:10:33 --> UTF-8 Support Enabled
INFO - 2018-05-11 06:10:33 --> URI Class Initialized
DEBUG - 2018-05-11 06:10:33 --> UTF-8 Support Enabled
DEBUG - 2018-05-11 06:10:33 --> UTF-8 Support Enabled
INFO - 2018-05-11 06:10:33 --> Utf8 Class Initialized
INFO - 2018-05-11 06:10:33 --> Utf8 Class Initialized
INFO - 2018-05-11 06:10:33 --> URI Class Initialized
INFO - 2018-05-11 06:10:33 --> Router Class Initialized
INFO - 2018-05-11 06:10:33 --> Utf8 Class Initialized
INFO - 2018-05-11 06:10:33 --> URI Class Initialized
INFO - 2018-05-11 06:10:33 --> URI Class Initialized
INFO - 2018-05-11 06:10:33 --> Router Class Initialized
INFO - 2018-05-11 06:10:33 --> Router Class Initialized
INFO - 2018-05-11 06:10:33 --> Output Class Initialized
INFO - 2018-05-11 06:10:33 --> Router Class Initialized
INFO - 2018-05-11 06:10:33 --> Output Class Initialized
INFO - 2018-05-11 06:10:33 --> URI Class Initialized
INFO - 2018-05-11 06:10:33 --> Output Class Initialized
INFO - 2018-05-11 06:10:33 --> Output Class Initialized
INFO - 2018-05-11 06:10:33 --> Security Class Initialized
INFO - 2018-05-11 06:10:33 --> Security Class Initialized
INFO - 2018-05-11 06:10:33 --> Router Class Initialized
DEBUG - 2018-05-11 06:10:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 06:10:33 --> Security Class Initialized
DEBUG - 2018-05-11 06:10:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 06:10:33 --> Security Class Initialized
INFO - 2018-05-11 06:10:33 --> Output Class Initialized
INFO - 2018-05-11 06:10:33 --> Input Class Initialized
DEBUG - 2018-05-11 06:10:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 06:10:33 --> Input Class Initialized
DEBUG - 2018-05-11 06:10:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 06:10:33 --> Security Class Initialized
INFO - 2018-05-11 06:10:33 --> Input Class Initialized
INFO - 2018-05-11 06:10:33 --> Language Class Initialized
INFO - 2018-05-11 06:10:33 --> Input Class Initialized
INFO - 2018-05-11 06:10:33 --> Language Class Initialized
DEBUG - 2018-05-11 06:10:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 06:10:33 --> Input Class Initialized
ERROR - 2018-05-11 06:10:33 --> 404 Page Not Found: /index
INFO - 2018-05-11 06:10:33 --> Language Class Initialized
ERROR - 2018-05-11 06:10:33 --> 404 Page Not Found: /index
INFO - 2018-05-11 06:10:33 --> Language Class Initialized
INFO - 2018-05-11 06:10:33 --> Language Class Initialized
ERROR - 2018-05-11 06:10:33 --> 404 Page Not Found: /index
ERROR - 2018-05-11 06:10:33 --> 404 Page Not Found: /index
ERROR - 2018-05-11 06:10:33 --> 404 Page Not Found: /index
INFO - 2018-05-11 06:10:35 --> Config Class Initialized
INFO - 2018-05-11 06:10:35 --> Hooks Class Initialized
DEBUG - 2018-05-11 06:10:35 --> UTF-8 Support Enabled
INFO - 2018-05-11 06:10:35 --> Utf8 Class Initialized
INFO - 2018-05-11 06:10:35 --> URI Class Initialized
INFO - 2018-05-11 06:10:35 --> Router Class Initialized
INFO - 2018-05-11 06:10:35 --> Output Class Initialized
INFO - 2018-05-11 06:10:35 --> Security Class Initialized
DEBUG - 2018-05-11 06:10:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 06:10:35 --> Input Class Initialized
INFO - 2018-05-11 06:10:35 --> Language Class Initialized
ERROR - 2018-05-11 06:10:35 --> 404 Page Not Found: /index
INFO - 2018-05-11 06:11:30 --> Config Class Initialized
INFO - 2018-05-11 06:11:30 --> Hooks Class Initialized
DEBUG - 2018-05-11 06:11:30 --> UTF-8 Support Enabled
INFO - 2018-05-11 06:11:30 --> Utf8 Class Initialized
INFO - 2018-05-11 06:11:30 --> URI Class Initialized
INFO - 2018-05-11 06:11:30 --> Router Class Initialized
INFO - 2018-05-11 06:11:30 --> Output Class Initialized
INFO - 2018-05-11 06:11:30 --> Security Class Initialized
DEBUG - 2018-05-11 06:11:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 06:11:30 --> Input Class Initialized
INFO - 2018-05-11 06:11:30 --> Language Class Initialized
INFO - 2018-05-11 06:11:31 --> Language Class Initialized
INFO - 2018-05-11 06:11:31 --> Config Class Initialized
INFO - 2018-05-11 06:11:31 --> Loader Class Initialized
DEBUG - 2018-05-11 06:11:31 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-11 06:11:31 --> Helper loaded: url_helper
INFO - 2018-05-11 06:11:31 --> Helper loaded: form_helper
INFO - 2018-05-11 06:11:31 --> Helper loaded: date_helper
INFO - 2018-05-11 06:11:31 --> Helper loaded: util_helper
INFO - 2018-05-11 06:11:31 --> Helper loaded: text_helper
INFO - 2018-05-11 06:11:31 --> Helper loaded: string_helper
INFO - 2018-05-11 06:11:31 --> Database Driver Class Initialized
DEBUG - 2018-05-11 06:11:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-11 06:11:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-11 06:11:31 --> Email Class Initialized
INFO - 2018-05-11 06:11:31 --> Controller Class Initialized
DEBUG - 2018-05-11 06:11:31 --> Login MX_Controller Initialized
INFO - 2018-05-11 06:11:31 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-11 06:11:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-11 06:11:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-11 06:11:31 --> 4 Loggedout
INFO - 2018-05-11 06:11:31 --> Config Class Initialized
INFO - 2018-05-11 06:11:31 --> Hooks Class Initialized
DEBUG - 2018-05-11 06:11:31 --> UTF-8 Support Enabled
INFO - 2018-05-11 06:11:31 --> Utf8 Class Initialized
INFO - 2018-05-11 06:11:31 --> URI Class Initialized
INFO - 2018-05-11 06:11:31 --> Router Class Initialized
INFO - 2018-05-11 06:11:31 --> Output Class Initialized
INFO - 2018-05-11 06:11:31 --> Security Class Initialized
DEBUG - 2018-05-11 06:11:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 06:11:31 --> Input Class Initialized
INFO - 2018-05-11 06:11:31 --> Language Class Initialized
INFO - 2018-05-11 06:11:31 --> Language Class Initialized
INFO - 2018-05-11 06:11:31 --> Config Class Initialized
INFO - 2018-05-11 06:11:31 --> Loader Class Initialized
DEBUG - 2018-05-11 06:11:31 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-11 06:11:31 --> Helper loaded: url_helper
INFO - 2018-05-11 06:11:31 --> Helper loaded: form_helper
INFO - 2018-05-11 06:11:31 --> Helper loaded: date_helper
INFO - 2018-05-11 06:11:31 --> Helper loaded: util_helper
INFO - 2018-05-11 06:11:31 --> Helper loaded: text_helper
INFO - 2018-05-11 06:11:31 --> Helper loaded: string_helper
INFO - 2018-05-11 06:11:31 --> Database Driver Class Initialized
DEBUG - 2018-05-11 06:11:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-11 06:11:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-11 06:11:31 --> Email Class Initialized
INFO - 2018-05-11 06:11:31 --> Controller Class Initialized
DEBUG - 2018-05-11 06:11:31 --> Home MX_Controller Initialized
DEBUG - 2018-05-11 06:11:31 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-11 06:11:31 --> Login MX_Controller Initialized
INFO - 2018-05-11 06:11:31 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-11 06:11:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-11 06:11:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-11 06:11:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/login.php
INFO - 2018-05-11 06:11:33 --> Config Class Initialized
INFO - 2018-05-11 06:11:33 --> Hooks Class Initialized
DEBUG - 2018-05-11 06:11:33 --> UTF-8 Support Enabled
INFO - 2018-05-11 06:11:33 --> Utf8 Class Initialized
INFO - 2018-05-11 06:11:33 --> URI Class Initialized
INFO - 2018-05-11 06:11:33 --> Router Class Initialized
INFO - 2018-05-11 06:11:33 --> Output Class Initialized
INFO - 2018-05-11 06:11:33 --> Security Class Initialized
DEBUG - 2018-05-11 06:11:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 06:11:33 --> Input Class Initialized
INFO - 2018-05-11 06:11:33 --> Language Class Initialized
INFO - 2018-05-11 06:11:33 --> Language Class Initialized
INFO - 2018-05-11 06:11:33 --> Config Class Initialized
INFO - 2018-05-11 06:11:33 --> Loader Class Initialized
DEBUG - 2018-05-11 06:11:33 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-11 06:11:33 --> Helper loaded: url_helper
INFO - 2018-05-11 06:11:33 --> Helper loaded: form_helper
INFO - 2018-05-11 06:11:33 --> Helper loaded: date_helper
INFO - 2018-05-11 06:11:33 --> Helper loaded: util_helper
INFO - 2018-05-11 06:11:33 --> Helper loaded: text_helper
INFO - 2018-05-11 06:11:33 --> Helper loaded: string_helper
INFO - 2018-05-11 06:11:33 --> Database Driver Class Initialized
DEBUG - 2018-05-11 06:11:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-11 06:11:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-11 06:11:33 --> Email Class Initialized
INFO - 2018-05-11 06:11:33 --> Controller Class Initialized
DEBUG - 2018-05-11 06:11:33 --> Login MX_Controller Initialized
INFO - 2018-05-11 06:11:33 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-11 06:11:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-11 06:11:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-11 06:11:33 --> Email starts for gopipanguluri123@gmail.com fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-05-11 06:11:33 --> User session created for 4
INFO - 2018-05-11 06:11:33 --> Login status gopipanguluri123@gmail.com - success
INFO - 2018-05-11 06:11:33 --> Final output sent to browser
DEBUG - 2018-05-11 06:11:33 --> Total execution time: 0.4313
INFO - 2018-05-11 06:11:33 --> Config Class Initialized
INFO - 2018-05-11 06:11:33 --> Hooks Class Initialized
DEBUG - 2018-05-11 06:11:33 --> UTF-8 Support Enabled
INFO - 2018-05-11 06:11:33 --> Utf8 Class Initialized
INFO - 2018-05-11 06:11:33 --> URI Class Initialized
INFO - 2018-05-11 06:11:33 --> Router Class Initialized
INFO - 2018-05-11 06:11:33 --> Output Class Initialized
INFO - 2018-05-11 06:11:33 --> Security Class Initialized
DEBUG - 2018-05-11 06:11:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 06:11:33 --> Input Class Initialized
INFO - 2018-05-11 06:11:33 --> Language Class Initialized
INFO - 2018-05-11 06:11:33 --> Language Class Initialized
INFO - 2018-05-11 06:11:33 --> Config Class Initialized
INFO - 2018-05-11 06:11:33 --> Loader Class Initialized
DEBUG - 2018-05-11 06:11:33 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-11 06:11:33 --> Helper loaded: url_helper
INFO - 2018-05-11 06:11:33 --> Helper loaded: form_helper
INFO - 2018-05-11 06:11:33 --> Helper loaded: date_helper
INFO - 2018-05-11 06:11:34 --> Helper loaded: util_helper
INFO - 2018-05-11 06:11:34 --> Helper loaded: text_helper
INFO - 2018-05-11 06:11:34 --> Helper loaded: string_helper
INFO - 2018-05-11 06:11:34 --> Database Driver Class Initialized
DEBUG - 2018-05-11 06:11:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-11 06:11:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-11 06:11:34 --> Email Class Initialized
INFO - 2018-05-11 06:11:34 --> Controller Class Initialized
DEBUG - 2018-05-11 06:11:34 --> Home MX_Controller Initialized
DEBUG - 2018-05-11 06:11:34 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-11 06:11:34 --> Login MX_Controller Initialized
INFO - 2018-05-11 06:11:34 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-11 06:11:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-11 06:11:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-11 06:11:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-05-11 06:11:34 --> Final output sent to browser
INFO - 2018-05-11 06:11:34 --> Config Class Initialized
INFO - 2018-05-11 06:11:34 --> Hooks Class Initialized
DEBUG - 2018-05-11 06:11:34 --> Total execution time: 0.4334
DEBUG - 2018-05-11 06:11:34 --> UTF-8 Support Enabled
INFO - 2018-05-11 06:11:34 --> Utf8 Class Initialized
INFO - 2018-05-11 06:11:34 --> Config Class Initialized
INFO - 2018-05-11 06:11:34 --> Config Class Initialized
INFO - 2018-05-11 06:11:34 --> Config Class Initialized
INFO - 2018-05-11 06:11:34 --> Hooks Class Initialized
INFO - 2018-05-11 06:11:34 --> Hooks Class Initialized
INFO - 2018-05-11 06:11:34 --> Config Class Initialized
INFO - 2018-05-11 06:11:34 --> URI Class Initialized
DEBUG - 2018-05-11 06:11:34 --> UTF-8 Support Enabled
INFO - 2018-05-11 06:11:34 --> Hooks Class Initialized
DEBUG - 2018-05-11 06:11:34 --> UTF-8 Support Enabled
INFO - 2018-05-11 06:11:34 --> Config Class Initialized
INFO - 2018-05-11 06:11:34 --> Hooks Class Initialized
INFO - 2018-05-11 06:11:34 --> Router Class Initialized
INFO - 2018-05-11 06:11:34 --> Utf8 Class Initialized
INFO - 2018-05-11 06:11:34 --> Utf8 Class Initialized
INFO - 2018-05-11 06:11:34 --> Hooks Class Initialized
DEBUG - 2018-05-11 06:11:34 --> UTF-8 Support Enabled
INFO - 2018-05-11 06:11:34 --> Output Class Initialized
DEBUG - 2018-05-11 06:11:34 --> UTF-8 Support Enabled
INFO - 2018-05-11 06:11:34 --> URI Class Initialized
INFO - 2018-05-11 06:11:34 --> URI Class Initialized
INFO - 2018-05-11 06:11:34 --> Utf8 Class Initialized
INFO - 2018-05-11 06:11:34 --> Utf8 Class Initialized
INFO - 2018-05-11 06:11:34 --> Security Class Initialized
INFO - 2018-05-11 06:11:34 --> Router Class Initialized
DEBUG - 2018-05-11 06:11:34 --> UTF-8 Support Enabled
INFO - 2018-05-11 06:11:34 --> URI Class Initialized
DEBUG - 2018-05-11 06:11:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 06:11:34 --> URI Class Initialized
INFO - 2018-05-11 06:11:34 --> Utf8 Class Initialized
INFO - 2018-05-11 06:11:34 --> Router Class Initialized
INFO - 2018-05-11 06:11:34 --> Output Class Initialized
INFO - 2018-05-11 06:11:34 --> Router Class Initialized
INFO - 2018-05-11 06:11:34 --> Input Class Initialized
INFO - 2018-05-11 06:11:34 --> Router Class Initialized
INFO - 2018-05-11 06:11:34 --> URI Class Initialized
INFO - 2018-05-11 06:11:34 --> Security Class Initialized
INFO - 2018-05-11 06:11:34 --> Output Class Initialized
INFO - 2018-05-11 06:11:34 --> Security Class Initialized
INFO - 2018-05-11 06:11:34 --> Language Class Initialized
INFO - 2018-05-11 06:11:34 --> Output Class Initialized
INFO - 2018-05-11 06:11:34 --> Router Class Initialized
INFO - 2018-05-11 06:11:34 --> Output Class Initialized
DEBUG - 2018-05-11 06:11:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-11 06:11:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 06:11:34 --> Security Class Initialized
INFO - 2018-05-11 06:11:34 --> Output Class Initialized
INFO - 2018-05-11 06:11:34 --> Security Class Initialized
ERROR - 2018-05-11 06:11:34 --> 404 Page Not Found: /index
INFO - 2018-05-11 06:11:34 --> Input Class Initialized
DEBUG - 2018-05-11 06:11:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 06:11:34 --> Input Class Initialized
DEBUG - 2018-05-11 06:11:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 06:11:34 --> Security Class Initialized
INFO - 2018-05-11 06:11:34 --> Config Class Initialized
INFO - 2018-05-11 06:11:34 --> Language Class Initialized
INFO - 2018-05-11 06:11:34 --> Input Class Initialized
INFO - 2018-05-11 06:11:34 --> Input Class Initialized
INFO - 2018-05-11 06:11:34 --> Language Class Initialized
INFO - 2018-05-11 06:11:34 --> Hooks Class Initialized
DEBUG - 2018-05-11 06:11:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 06:11:34 --> Language Class Initialized
ERROR - 2018-05-11 06:11:34 --> 404 Page Not Found: /index
ERROR - 2018-05-11 06:11:34 --> 404 Page Not Found: /index
ERROR - 2018-05-11 06:11:34 --> 404 Page Not Found: /index
INFO - 2018-05-11 06:11:34 --> Input Class Initialized
DEBUG - 2018-05-11 06:11:34 --> UTF-8 Support Enabled
INFO - 2018-05-11 06:11:34 --> Language Class Initialized
ERROR - 2018-05-11 06:11:34 --> 404 Page Not Found: /index
INFO - 2018-05-11 06:11:34 --> Utf8 Class Initialized
INFO - 2018-05-11 06:11:34 --> Language Class Initialized
ERROR - 2018-05-11 06:11:34 --> 404 Page Not Found: /index
INFO - 2018-05-11 06:11:34 --> Config Class Initialized
INFO - 2018-05-11 06:11:34 --> Config Class Initialized
INFO - 2018-05-11 06:11:34 --> Hooks Class Initialized
INFO - 2018-05-11 06:11:34 --> Hooks Class Initialized
INFO - 2018-05-11 06:11:34 --> Config Class Initialized
INFO - 2018-05-11 06:11:34 --> URI Class Initialized
INFO - 2018-05-11 06:11:34 --> Hooks Class Initialized
DEBUG - 2018-05-11 06:11:34 --> UTF-8 Support Enabled
INFO - 2018-05-11 06:11:34 --> Config Class Initialized
INFO - 2018-05-11 06:11:34 --> Router Class Initialized
INFO - 2018-05-11 06:11:34 --> Hooks Class Initialized
DEBUG - 2018-05-11 06:11:34 --> UTF-8 Support Enabled
DEBUG - 2018-05-11 06:11:34 --> UTF-8 Support Enabled
INFO - 2018-05-11 06:11:34 --> Utf8 Class Initialized
INFO - 2018-05-11 06:11:34 --> Utf8 Class Initialized
INFO - 2018-05-11 06:11:34 --> Utf8 Class Initialized
DEBUG - 2018-05-11 06:11:34 --> UTF-8 Support Enabled
INFO - 2018-05-11 06:11:34 --> Output Class Initialized
INFO - 2018-05-11 06:11:34 --> URI Class Initialized
INFO - 2018-05-11 06:11:34 --> URI Class Initialized
INFO - 2018-05-11 06:11:34 --> Utf8 Class Initialized
INFO - 2018-05-11 06:11:34 --> URI Class Initialized
INFO - 2018-05-11 06:11:34 --> Security Class Initialized
INFO - 2018-05-11 06:11:34 --> URI Class Initialized
INFO - 2018-05-11 06:11:34 --> Router Class Initialized
INFO - 2018-05-11 06:11:34 --> Router Class Initialized
INFO - 2018-05-11 06:11:34 --> Router Class Initialized
DEBUG - 2018-05-11 06:11:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 06:11:34 --> Router Class Initialized
INFO - 2018-05-11 06:11:34 --> Output Class Initialized
INFO - 2018-05-11 06:11:34 --> Input Class Initialized
INFO - 2018-05-11 06:11:34 --> Output Class Initialized
INFO - 2018-05-11 06:11:34 --> Output Class Initialized
INFO - 2018-05-11 06:11:34 --> Language Class Initialized
INFO - 2018-05-11 06:11:34 --> Security Class Initialized
INFO - 2018-05-11 06:11:34 --> Security Class Initialized
INFO - 2018-05-11 06:11:34 --> Security Class Initialized
INFO - 2018-05-11 06:11:34 --> Output Class Initialized
ERROR - 2018-05-11 06:11:34 --> 404 Page Not Found: /index
DEBUG - 2018-05-11 06:11:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 06:11:35 --> Security Class Initialized
DEBUG - 2018-05-11 06:11:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-11 06:11:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 06:11:35 --> Input Class Initialized
INFO - 2018-05-11 06:11:35 --> Input Class Initialized
INFO - 2018-05-11 06:11:35 --> Input Class Initialized
INFO - 2018-05-11 06:11:35 --> Config Class Initialized
DEBUG - 2018-05-11 06:11:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 06:11:35 --> Hooks Class Initialized
INFO - 2018-05-11 06:11:35 --> Language Class Initialized
INFO - 2018-05-11 06:11:35 --> Language Class Initialized
INFO - 2018-05-11 06:11:35 --> Language Class Initialized
INFO - 2018-05-11 06:11:35 --> Input Class Initialized
ERROR - 2018-05-11 06:11:35 --> 404 Page Not Found: /index
DEBUG - 2018-05-11 06:11:35 --> UTF-8 Support Enabled
ERROR - 2018-05-11 06:11:35 --> 404 Page Not Found: /index
ERROR - 2018-05-11 06:11:35 --> 404 Page Not Found: /index
INFO - 2018-05-11 06:11:35 --> Language Class Initialized
INFO - 2018-05-11 06:11:35 --> Utf8 Class Initialized
INFO - 2018-05-11 06:11:35 --> Config Class Initialized
INFO - 2018-05-11 06:11:35 --> Hooks Class Initialized
INFO - 2018-05-11 06:11:35 --> URI Class Initialized
ERROR - 2018-05-11 06:11:35 --> 404 Page Not Found: /index
DEBUG - 2018-05-11 06:11:35 --> UTF-8 Support Enabled
INFO - 2018-05-11 06:11:35 --> Utf8 Class Initialized
INFO - 2018-05-11 06:11:35 --> Config Class Initialized
INFO - 2018-05-11 06:11:35 --> Config Class Initialized
INFO - 2018-05-11 06:11:35 --> Router Class Initialized
INFO - 2018-05-11 06:11:35 --> Config Class Initialized
INFO - 2018-05-11 06:11:35 --> Hooks Class Initialized
INFO - 2018-05-11 06:11:35 --> Hooks Class Initialized
INFO - 2018-05-11 06:11:35 --> Hooks Class Initialized
INFO - 2018-05-11 06:11:35 --> URI Class Initialized
INFO - 2018-05-11 06:11:35 --> Output Class Initialized
DEBUG - 2018-05-11 06:11:35 --> UTF-8 Support Enabled
DEBUG - 2018-05-11 06:11:35 --> UTF-8 Support Enabled
DEBUG - 2018-05-11 06:11:35 --> UTF-8 Support Enabled
INFO - 2018-05-11 06:11:35 --> Security Class Initialized
INFO - 2018-05-11 06:11:35 --> Router Class Initialized
INFO - 2018-05-11 06:11:35 --> Utf8 Class Initialized
INFO - 2018-05-11 06:11:35 --> URI Class Initialized
INFO - 2018-05-11 06:11:35 --> Utf8 Class Initialized
INFO - 2018-05-11 06:11:35 --> Utf8 Class Initialized
DEBUG - 2018-05-11 06:11:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 06:11:35 --> URI Class Initialized
INFO - 2018-05-11 06:11:35 --> URI Class Initialized
INFO - 2018-05-11 06:11:35 --> Output Class Initialized
INFO - 2018-05-11 06:11:35 --> Router Class Initialized
INFO - 2018-05-11 06:11:35 --> Input Class Initialized
INFO - 2018-05-11 06:11:35 --> Router Class Initialized
INFO - 2018-05-11 06:11:35 --> Language Class Initialized
INFO - 2018-05-11 06:11:35 --> Output Class Initialized
INFO - 2018-05-11 06:11:35 --> Security Class Initialized
INFO - 2018-05-11 06:11:35 --> Router Class Initialized
INFO - 2018-05-11 06:11:35 --> Output Class Initialized
DEBUG - 2018-05-11 06:11:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 06:11:35 --> Security Class Initialized
INFO - 2018-05-11 06:11:35 --> Output Class Initialized
INFO - 2018-05-11 06:11:35 --> Security Class Initialized
ERROR - 2018-05-11 06:11:35 --> 404 Page Not Found: /index
DEBUG - 2018-05-11 06:11:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 06:11:35 --> Security Class Initialized
DEBUG - 2018-05-11 06:11:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 06:11:35 --> Input Class Initialized
INFO - 2018-05-11 06:11:35 --> Config Class Initialized
INFO - 2018-05-11 06:11:35 --> Hooks Class Initialized
INFO - 2018-05-11 06:11:35 --> Input Class Initialized
DEBUG - 2018-05-11 06:11:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 06:11:35 --> Language Class Initialized
INFO - 2018-05-11 06:11:35 --> Input Class Initialized
DEBUG - 2018-05-11 06:11:35 --> UTF-8 Support Enabled
INFO - 2018-05-11 06:11:35 --> Utf8 Class Initialized
INFO - 2018-05-11 06:11:35 --> URI Class Initialized
INFO - 2018-05-11 06:11:35 --> Input Class Initialized
INFO - 2018-05-11 06:11:35 --> Language Class Initialized
ERROR - 2018-05-11 06:11:35 --> 404 Page Not Found: /index
INFO - 2018-05-11 06:11:35 --> Router Class Initialized
INFO - 2018-05-11 06:11:35 --> Language Class Initialized
ERROR - 2018-05-11 06:11:35 --> 404 Page Not Found: /index
INFO - 2018-05-11 06:11:35 --> Language Class Initialized
INFO - 2018-05-11 06:11:35 --> Output Class Initialized
ERROR - 2018-05-11 06:11:35 --> 404 Page Not Found: /index
ERROR - 2018-05-11 06:11:35 --> 404 Page Not Found: /index
INFO - 2018-05-11 06:11:35 --> Security Class Initialized
DEBUG - 2018-05-11 06:11:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 06:11:35 --> Input Class Initialized
INFO - 2018-05-11 06:11:35 --> Language Class Initialized
ERROR - 2018-05-11 06:11:35 --> 404 Page Not Found: /index
INFO - 2018-05-11 06:11:53 --> Config Class Initialized
INFO - 2018-05-11 06:11:53 --> Hooks Class Initialized
DEBUG - 2018-05-11 06:11:53 --> UTF-8 Support Enabled
INFO - 2018-05-11 06:11:53 --> Utf8 Class Initialized
INFO - 2018-05-11 06:11:53 --> URI Class Initialized
INFO - 2018-05-11 06:11:53 --> Router Class Initialized
INFO - 2018-05-11 06:11:53 --> Output Class Initialized
INFO - 2018-05-11 06:11:53 --> Security Class Initialized
DEBUG - 2018-05-11 06:11:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 06:11:53 --> Input Class Initialized
INFO - 2018-05-11 06:11:53 --> Language Class Initialized
INFO - 2018-05-11 06:11:53 --> Language Class Initialized
INFO - 2018-05-11 06:11:53 --> Config Class Initialized
INFO - 2018-05-11 06:11:53 --> Loader Class Initialized
DEBUG - 2018-05-11 06:11:53 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-11 06:11:53 --> Helper loaded: url_helper
INFO - 2018-05-11 06:11:53 --> Helper loaded: form_helper
INFO - 2018-05-11 06:11:53 --> Helper loaded: date_helper
INFO - 2018-05-11 06:11:53 --> Helper loaded: util_helper
INFO - 2018-05-11 06:11:53 --> Helper loaded: text_helper
INFO - 2018-05-11 06:11:53 --> Helper loaded: string_helper
INFO - 2018-05-11 06:11:53 --> Database Driver Class Initialized
DEBUG - 2018-05-11 06:11:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-11 06:11:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-11 06:11:53 --> Email Class Initialized
INFO - 2018-05-11 06:11:53 --> Controller Class Initialized
DEBUG - 2018-05-11 06:11:53 --> Home MX_Controller Initialized
DEBUG - 2018-05-11 06:11:53 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-11 06:11:53 --> Login MX_Controller Initialized
INFO - 2018-05-11 06:11:53 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-11 06:11:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-11 06:11:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-11 06:11:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-05-11 06:11:53 --> Final output sent to browser
INFO - 2018-05-11 06:11:53 --> Config Class Initialized
DEBUG - 2018-05-11 06:11:53 --> Total execution time: 0.4290
INFO - 2018-05-11 06:11:53 --> Hooks Class Initialized
DEBUG - 2018-05-11 06:11:53 --> UTF-8 Support Enabled
INFO - 2018-05-11 06:11:53 --> Utf8 Class Initialized
INFO - 2018-05-11 06:11:53 --> URI Class Initialized
INFO - 2018-05-11 06:11:53 --> Config Class Initialized
INFO - 2018-05-11 06:11:53 --> Config Class Initialized
INFO - 2018-05-11 06:11:53 --> Config Class Initialized
INFO - 2018-05-11 06:11:53 --> Config Class Initialized
INFO - 2018-05-11 06:11:53 --> Hooks Class Initialized
INFO - 2018-05-11 06:11:53 --> Hooks Class Initialized
INFO - 2018-05-11 06:11:53 --> Hooks Class Initialized
INFO - 2018-05-11 06:11:53 --> Router Class Initialized
INFO - 2018-05-11 06:11:53 --> Config Class Initialized
INFO - 2018-05-11 06:11:53 --> Hooks Class Initialized
DEBUG - 2018-05-11 06:11:53 --> UTF-8 Support Enabled
INFO - 2018-05-11 06:11:53 --> Hooks Class Initialized
DEBUG - 2018-05-11 06:11:53 --> UTF-8 Support Enabled
DEBUG - 2018-05-11 06:11:53 --> UTF-8 Support Enabled
INFO - 2018-05-11 06:11:53 --> Output Class Initialized
INFO - 2018-05-11 06:11:53 --> Utf8 Class Initialized
DEBUG - 2018-05-11 06:11:53 --> UTF-8 Support Enabled
INFO - 2018-05-11 06:11:53 --> Utf8 Class Initialized
INFO - 2018-05-11 06:11:53 --> Utf8 Class Initialized
INFO - 2018-05-11 06:11:53 --> Security Class Initialized
DEBUG - 2018-05-11 06:11:53 --> UTF-8 Support Enabled
INFO - 2018-05-11 06:11:53 --> URI Class Initialized
INFO - 2018-05-11 06:11:53 --> Router Class Initialized
INFO - 2018-05-11 06:11:54 --> Utf8 Class Initialized
INFO - 2018-05-11 06:11:54 --> URI Class Initialized
INFO - 2018-05-11 06:11:54 --> URI Class Initialized
INFO - 2018-05-11 06:11:54 --> Utf8 Class Initialized
DEBUG - 2018-05-11 06:11:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 06:11:54 --> Output Class Initialized
INFO - 2018-05-11 06:11:54 --> URI Class Initialized
INFO - 2018-05-11 06:11:54 --> Router Class Initialized
INFO - 2018-05-11 06:11:54 --> Router Class Initialized
INFO - 2018-05-11 06:11:54 --> Router Class Initialized
INFO - 2018-05-11 06:11:54 --> Input Class Initialized
INFO - 2018-05-11 06:11:54 --> Security Class Initialized
INFO - 2018-05-11 06:11:54 --> URI Class Initialized
DEBUG - 2018-05-11 06:11:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 06:11:54 --> Output Class Initialized
INFO - 2018-05-11 06:11:54 --> Router Class Initialized
INFO - 2018-05-11 06:11:54 --> Input Class Initialized
INFO - 2018-05-11 06:11:54 --> Output Class Initialized
INFO - 2018-05-11 06:11:54 --> Language Class Initialized
INFO - 2018-05-11 06:11:54 --> Security Class Initialized
INFO - 2018-05-11 06:11:54 --> Output Class Initialized
INFO - 2018-05-11 06:11:54 --> Output Class Initialized
INFO - 2018-05-11 06:11:54 --> Security Class Initialized
ERROR - 2018-05-11 06:11:54 --> 404 Page Not Found: /index
DEBUG - 2018-05-11 06:11:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 06:11:54 --> Security Class Initialized
INFO - 2018-05-11 06:11:54 --> Language Class Initialized
DEBUG - 2018-05-11 06:11:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 06:11:54 --> Input Class Initialized
ERROR - 2018-05-11 06:11:54 --> 404 Page Not Found: /index
DEBUG - 2018-05-11 06:11:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 06:11:54 --> Config Class Initialized
INFO - 2018-05-11 06:11:54 --> Security Class Initialized
INFO - 2018-05-11 06:11:54 --> Hooks Class Initialized
INFO - 2018-05-11 06:11:54 --> Input Class Initialized
DEBUG - 2018-05-11 06:11:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 06:11:54 --> Input Class Initialized
INFO - 2018-05-11 06:11:54 --> Language Class Initialized
DEBUG - 2018-05-11 06:11:54 --> UTF-8 Support Enabled
INFO - 2018-05-11 06:11:54 --> Utf8 Class Initialized
INFO - 2018-05-11 06:11:54 --> URI Class Initialized
INFO - 2018-05-11 06:11:54 --> Config Class Initialized
INFO - 2018-05-11 06:11:54 --> Hooks Class Initialized
INFO - 2018-05-11 06:11:54 --> Router Class Initialized
INFO - 2018-05-11 06:11:54 --> Language Class Initialized
INFO - 2018-05-11 06:11:54 --> Input Class Initialized
INFO - 2018-05-11 06:11:54 --> Language Class Initialized
ERROR - 2018-05-11 06:11:54 --> 404 Page Not Found: /index
DEBUG - 2018-05-11 06:11:54 --> UTF-8 Support Enabled
INFO - 2018-05-11 06:11:54 --> Utf8 Class Initialized
ERROR - 2018-05-11 06:11:54 --> 404 Page Not Found: /index
INFO - 2018-05-11 06:11:54 --> Output Class Initialized
ERROR - 2018-05-11 06:11:54 --> 404 Page Not Found: /index
INFO - 2018-05-11 06:11:54 --> Language Class Initialized
INFO - 2018-05-11 06:11:54 --> URI Class Initialized
INFO - 2018-05-11 06:11:54 --> Router Class Initialized
INFO - 2018-05-11 06:11:54 --> Output Class Initialized
INFO - 2018-05-11 06:11:54 --> Security Class Initialized
ERROR - 2018-05-11 06:11:54 --> 404 Page Not Found: /index
INFO - 2018-05-11 06:11:54 --> Security Class Initialized
DEBUG - 2018-05-11 06:11:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 06:11:54 --> Input Class Initialized
DEBUG - 2018-05-11 06:11:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 06:11:54 --> Language Class Initialized
INFO - 2018-05-11 06:11:54 --> Input Class Initialized
ERROR - 2018-05-11 06:11:54 --> 404 Page Not Found: /index
INFO - 2018-05-11 06:11:54 --> Config Class Initialized
INFO - 2018-05-11 06:11:54 --> Hooks Class Initialized
INFO - 2018-05-11 06:11:54 --> Language Class Initialized
INFO - 2018-05-11 06:11:54 --> Config Class Initialized
DEBUG - 2018-05-11 06:11:54 --> UTF-8 Support Enabled
INFO - 2018-05-11 06:11:54 --> Config Class Initialized
INFO - 2018-05-11 06:11:54 --> Hooks Class Initialized
INFO - 2018-05-11 06:11:54 --> Utf8 Class Initialized
INFO - 2018-05-11 06:11:54 --> Hooks Class Initialized
ERROR - 2018-05-11 06:11:54 --> 404 Page Not Found: /index
INFO - 2018-05-11 06:11:54 --> Config Class Initialized
DEBUG - 2018-05-11 06:11:54 --> UTF-8 Support Enabled
INFO - 2018-05-11 06:11:54 --> Hooks Class Initialized
DEBUG - 2018-05-11 06:11:54 --> UTF-8 Support Enabled
INFO - 2018-05-11 06:11:54 --> URI Class Initialized
INFO - 2018-05-11 06:11:54 --> Utf8 Class Initialized
INFO - 2018-05-11 06:11:54 --> Config Class Initialized
INFO - 2018-05-11 06:11:54 --> Hooks Class Initialized
DEBUG - 2018-05-11 06:11:54 --> UTF-8 Support Enabled
INFO - 2018-05-11 06:11:54 --> URI Class Initialized
DEBUG - 2018-05-11 06:11:54 --> UTF-8 Support Enabled
INFO - 2018-05-11 06:11:54 --> Router Class Initialized
INFO - 2018-05-11 06:11:54 --> Utf8 Class Initialized
INFO - 2018-05-11 06:11:54 --> Utf8 Class Initialized
INFO - 2018-05-11 06:11:54 --> Utf8 Class Initialized
INFO - 2018-05-11 06:11:54 --> Router Class Initialized
INFO - 2018-05-11 06:11:54 --> URI Class Initialized
INFO - 2018-05-11 06:11:54 --> URI Class Initialized
INFO - 2018-05-11 06:11:54 --> Output Class Initialized
INFO - 2018-05-11 06:11:54 --> URI Class Initialized
INFO - 2018-05-11 06:11:55 --> Router Class Initialized
INFO - 2018-05-11 06:11:55 --> Output Class Initialized
INFO - 2018-05-11 06:11:55 --> Security Class Initialized
INFO - 2018-05-11 06:11:55 --> Router Class Initialized
INFO - 2018-05-11 06:11:55 --> Output Class Initialized
DEBUG - 2018-05-11 06:11:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 06:11:55 --> Security Class Initialized
INFO - 2018-05-11 06:11:55 --> Router Class Initialized
INFO - 2018-05-11 06:11:55 --> Input Class Initialized
INFO - 2018-05-11 06:11:55 --> Security Class Initialized
INFO - 2018-05-11 06:11:55 --> Output Class Initialized
INFO - 2018-05-11 06:11:55 --> Output Class Initialized
DEBUG - 2018-05-11 06:11:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 06:11:55 --> Language Class Initialized
INFO - 2018-05-11 06:11:55 --> Security Class Initialized
INFO - 2018-05-11 06:11:55 --> Security Class Initialized
INFO - 2018-05-11 06:11:55 --> Input Class Initialized
DEBUG - 2018-05-11 06:11:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 06:11:55 --> Language Class Initialized
INFO - 2018-05-11 06:11:55 --> Input Class Initialized
DEBUG - 2018-05-11 06:11:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-11 06:11:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-05-11 06:11:55 --> 404 Page Not Found: /index
INFO - 2018-05-11 06:11:55 --> Input Class Initialized
INFO - 2018-05-11 06:11:55 --> Input Class Initialized
INFO - 2018-05-11 06:11:55 --> Language Class Initialized
ERROR - 2018-05-11 06:11:55 --> 404 Page Not Found: /index
INFO - 2018-05-11 06:11:55 --> Language Class Initialized
INFO - 2018-05-11 06:11:55 --> Language Class Initialized
ERROR - 2018-05-11 06:11:55 --> 404 Page Not Found: /index
INFO - 2018-05-11 06:11:55 --> Config Class Initialized
INFO - 2018-05-11 06:11:55 --> Config Class Initialized
INFO - 2018-05-11 06:11:55 --> Hooks Class Initialized
INFO - 2018-05-11 06:11:55 --> Hooks Class Initialized
ERROR - 2018-05-11 06:11:55 --> 404 Page Not Found: /index
ERROR - 2018-05-11 06:11:55 --> 404 Page Not Found: /index
DEBUG - 2018-05-11 06:11:55 --> UTF-8 Support Enabled
DEBUG - 2018-05-11 06:11:55 --> UTF-8 Support Enabled
INFO - 2018-05-11 06:11:55 --> Config Class Initialized
INFO - 2018-05-11 06:11:55 --> Utf8 Class Initialized
INFO - 2018-05-11 06:11:55 --> Config Class Initialized
INFO - 2018-05-11 06:11:55 --> Hooks Class Initialized
INFO - 2018-05-11 06:11:55 --> Hooks Class Initialized
INFO - 2018-05-11 06:11:55 --> URI Class Initialized
INFO - 2018-05-11 06:11:55 --> Utf8 Class Initialized
INFO - 2018-05-11 06:11:55 --> Router Class Initialized
INFO - 2018-05-11 06:11:55 --> URI Class Initialized
DEBUG - 2018-05-11 06:11:55 --> UTF-8 Support Enabled
DEBUG - 2018-05-11 06:11:55 --> UTF-8 Support Enabled
INFO - 2018-05-11 06:11:55 --> Utf8 Class Initialized
INFO - 2018-05-11 06:11:55 --> Output Class Initialized
INFO - 2018-05-11 06:11:55 --> Utf8 Class Initialized
INFO - 2018-05-11 06:11:55 --> Router Class Initialized
INFO - 2018-05-11 06:11:55 --> Output Class Initialized
INFO - 2018-05-11 06:11:55 --> URI Class Initialized
INFO - 2018-05-11 06:11:55 --> Security Class Initialized
INFO - 2018-05-11 06:11:55 --> URI Class Initialized
INFO - 2018-05-11 06:11:55 --> Security Class Initialized
INFO - 2018-05-11 06:11:55 --> Router Class Initialized
INFO - 2018-05-11 06:11:55 --> Output Class Initialized
DEBUG - 2018-05-11 06:11:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-11 06:11:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 06:11:55 --> Router Class Initialized
INFO - 2018-05-11 06:11:55 --> Input Class Initialized
INFO - 2018-05-11 06:11:55 --> Security Class Initialized
INFO - 2018-05-11 06:11:55 --> Input Class Initialized
INFO - 2018-05-11 06:11:55 --> Output Class Initialized
INFO - 2018-05-11 06:11:55 --> Security Class Initialized
INFO - 2018-05-11 06:11:55 --> Language Class Initialized
INFO - 2018-05-11 06:11:55 --> Language Class Initialized
DEBUG - 2018-05-11 06:11:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 06:11:55 --> Input Class Initialized
DEBUG - 2018-05-11 06:11:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 06:11:55 --> Language Class Initialized
INFO - 2018-05-11 06:11:55 --> Input Class Initialized
ERROR - 2018-05-11 06:11:55 --> 404 Page Not Found: /index
ERROR - 2018-05-11 06:11:55 --> 404 Page Not Found: /index
ERROR - 2018-05-11 06:11:55 --> 404 Page Not Found: /index
INFO - 2018-05-11 06:11:55 --> Language Class Initialized
ERROR - 2018-05-11 06:11:55 --> 404 Page Not Found: /index
INFO - 2018-05-11 06:11:55 --> Config Class Initialized
INFO - 2018-05-11 06:11:55 --> Hooks Class Initialized
DEBUG - 2018-05-11 06:11:55 --> UTF-8 Support Enabled
INFO - 2018-05-11 06:11:55 --> Utf8 Class Initialized
INFO - 2018-05-11 06:11:55 --> URI Class Initialized
INFO - 2018-05-11 06:11:55 --> Router Class Initialized
INFO - 2018-05-11 06:11:55 --> Output Class Initialized
INFO - 2018-05-11 06:11:55 --> Security Class Initialized
DEBUG - 2018-05-11 06:11:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 06:11:55 --> Input Class Initialized
INFO - 2018-05-11 06:11:55 --> Language Class Initialized
ERROR - 2018-05-11 06:11:55 --> 404 Page Not Found: /index
INFO - 2018-05-11 06:11:55 --> Config Class Initialized
INFO - 2018-05-11 06:11:55 --> Hooks Class Initialized
DEBUG - 2018-05-11 06:11:55 --> UTF-8 Support Enabled
INFO - 2018-05-11 06:11:55 --> Utf8 Class Initialized
INFO - 2018-05-11 06:11:55 --> URI Class Initialized
INFO - 2018-05-11 06:11:55 --> Router Class Initialized
INFO - 2018-05-11 06:11:55 --> Output Class Initialized
INFO - 2018-05-11 06:11:55 --> Security Class Initialized
DEBUG - 2018-05-11 06:11:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 06:11:55 --> Input Class Initialized
INFO - 2018-05-11 06:11:55 --> Language Class Initialized
ERROR - 2018-05-11 06:11:55 --> 404 Page Not Found: /index
INFO - 2018-05-11 06:11:55 --> Config Class Initialized
INFO - 2018-05-11 06:11:55 --> Hooks Class Initialized
DEBUG - 2018-05-11 06:11:55 --> UTF-8 Support Enabled
INFO - 2018-05-11 06:11:55 --> Utf8 Class Initialized
INFO - 2018-05-11 06:11:55 --> URI Class Initialized
INFO - 2018-05-11 06:11:55 --> Router Class Initialized
INFO - 2018-05-11 06:11:56 --> Output Class Initialized
INFO - 2018-05-11 06:11:56 --> Security Class Initialized
DEBUG - 2018-05-11 06:11:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 06:11:56 --> Input Class Initialized
INFO - 2018-05-11 06:11:56 --> Language Class Initialized
ERROR - 2018-05-11 06:11:56 --> 404 Page Not Found: /index
INFO - 2018-05-11 06:12:42 --> Config Class Initialized
INFO - 2018-05-11 06:12:42 --> Hooks Class Initialized
DEBUG - 2018-05-11 06:12:42 --> UTF-8 Support Enabled
INFO - 2018-05-11 06:12:42 --> Utf8 Class Initialized
INFO - 2018-05-11 06:12:42 --> URI Class Initialized
INFO - 2018-05-11 06:12:42 --> Router Class Initialized
INFO - 2018-05-11 06:12:42 --> Output Class Initialized
INFO - 2018-05-11 06:12:42 --> Security Class Initialized
DEBUG - 2018-05-11 06:12:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 06:12:42 --> Input Class Initialized
INFO - 2018-05-11 06:12:42 --> Language Class Initialized
INFO - 2018-05-11 06:12:42 --> Language Class Initialized
INFO - 2018-05-11 06:12:42 --> Config Class Initialized
INFO - 2018-05-11 06:12:42 --> Loader Class Initialized
DEBUG - 2018-05-11 06:12:42 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-11 06:12:42 --> Helper loaded: url_helper
INFO - 2018-05-11 06:12:42 --> Helper loaded: form_helper
INFO - 2018-05-11 06:12:42 --> Helper loaded: date_helper
INFO - 2018-05-11 06:12:42 --> Helper loaded: util_helper
INFO - 2018-05-11 06:12:42 --> Helper loaded: text_helper
INFO - 2018-05-11 06:12:42 --> Helper loaded: string_helper
INFO - 2018-05-11 06:12:42 --> Database Driver Class Initialized
DEBUG - 2018-05-11 06:12:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-11 06:12:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-11 06:12:42 --> Email Class Initialized
INFO - 2018-05-11 06:12:42 --> Controller Class Initialized
DEBUG - 2018-05-11 06:12:42 --> Login MX_Controller Initialized
INFO - 2018-05-11 06:12:42 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-11 06:12:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-11 06:12:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-11 06:12:42 --> Email starts for admin@consulting.com fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-05-11 06:12:42 --> User session created for 1
INFO - 2018-05-11 06:12:42 --> Login status admin@consulting.com - success
INFO - 2018-05-11 06:12:42 --> Final output sent to browser
DEBUG - 2018-05-11 06:12:42 --> Total execution time: 0.4594
INFO - 2018-05-11 06:12:42 --> Config Class Initialized
INFO - 2018-05-11 06:12:42 --> Hooks Class Initialized
DEBUG - 2018-05-11 06:12:42 --> UTF-8 Support Enabled
INFO - 2018-05-11 06:12:42 --> Utf8 Class Initialized
INFO - 2018-05-11 06:12:42 --> URI Class Initialized
INFO - 2018-05-11 06:12:42 --> Router Class Initialized
INFO - 2018-05-11 06:12:42 --> Output Class Initialized
INFO - 2018-05-11 06:12:43 --> Security Class Initialized
DEBUG - 2018-05-11 06:12:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 06:12:43 --> Input Class Initialized
INFO - 2018-05-11 06:12:43 --> Language Class Initialized
INFO - 2018-05-11 06:12:43 --> Language Class Initialized
INFO - 2018-05-11 06:12:43 --> Config Class Initialized
INFO - 2018-05-11 06:12:43 --> Loader Class Initialized
DEBUG - 2018-05-11 06:12:43 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-11 06:12:43 --> Helper loaded: url_helper
INFO - 2018-05-11 06:12:43 --> Helper loaded: form_helper
INFO - 2018-05-11 06:12:43 --> Helper loaded: date_helper
INFO - 2018-05-11 06:12:43 --> Helper loaded: util_helper
INFO - 2018-05-11 06:12:43 --> Helper loaded: text_helper
INFO - 2018-05-11 06:12:43 --> Helper loaded: string_helper
INFO - 2018-05-11 06:12:43 --> Database Driver Class Initialized
DEBUG - 2018-05-11 06:12:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-11 06:12:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-11 06:12:43 --> Email Class Initialized
INFO - 2018-05-11 06:12:43 --> Controller Class Initialized
DEBUG - 2018-05-11 06:12:43 --> Admin MX_Controller Initialized
INFO - 2018-05-11 06:12:43 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-11 06:12:43 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-11 06:12:43 --> Login MX_Controller Initialized
DEBUG - 2018-05-11 06:12:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-11 06:12:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-11 06:12:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-05-11 06:12:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-05-11 06:12:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-05-11 06:12:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-05-11 06:12:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-05-11 06:12:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/dashboard.php
INFO - 2018-05-11 06:12:43 --> Final output sent to browser
DEBUG - 2018-05-11 06:12:43 --> Total execution time: 0.4920
INFO - 2018-05-11 06:12:43 --> Config Class Initialized
INFO - 2018-05-11 06:12:43 --> Hooks Class Initialized
DEBUG - 2018-05-11 06:12:43 --> UTF-8 Support Enabled
INFO - 2018-05-11 06:12:43 --> Utf8 Class Initialized
INFO - 2018-05-11 06:12:43 --> URI Class Initialized
INFO - 2018-05-11 06:12:43 --> Router Class Initialized
INFO - 2018-05-11 06:12:43 --> Output Class Initialized
INFO - 2018-05-11 06:12:43 --> Security Class Initialized
DEBUG - 2018-05-11 06:12:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 06:12:43 --> Input Class Initialized
INFO - 2018-05-11 06:12:43 --> Language Class Initialized
ERROR - 2018-05-11 06:12:43 --> 404 Page Not Found: /index
INFO - 2018-05-11 06:12:44 --> Config Class Initialized
INFO - 2018-05-11 06:12:44 --> Hooks Class Initialized
DEBUG - 2018-05-11 06:12:44 --> UTF-8 Support Enabled
INFO - 2018-05-11 06:12:44 --> Utf8 Class Initialized
INFO - 2018-05-11 06:12:44 --> Config Class Initialized
INFO - 2018-05-11 06:12:44 --> Hooks Class Initialized
INFO - 2018-05-11 06:12:44 --> URI Class Initialized
DEBUG - 2018-05-11 06:12:44 --> UTF-8 Support Enabled
INFO - 2018-05-11 06:12:44 --> Utf8 Class Initialized
INFO - 2018-05-11 06:12:44 --> URI Class Initialized
INFO - 2018-05-11 06:12:44 --> Router Class Initialized
INFO - 2018-05-11 06:12:44 --> Router Class Initialized
INFO - 2018-05-11 06:12:44 --> Output Class Initialized
INFO - 2018-05-11 06:12:44 --> Security Class Initialized
DEBUG - 2018-05-11 06:12:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 06:12:44 --> Input Class Initialized
INFO - 2018-05-11 06:12:44 --> Language Class Initialized
ERROR - 2018-05-11 06:12:44 --> 404 Page Not Found: /index
INFO - 2018-05-11 06:12:44 --> Output Class Initialized
INFO - 2018-05-11 06:12:44 --> Security Class Initialized
DEBUG - 2018-05-11 06:12:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 06:12:44 --> Input Class Initialized
INFO - 2018-05-11 06:12:44 --> Language Class Initialized
ERROR - 2018-05-11 06:12:44 --> 404 Page Not Found: /index
INFO - 2018-05-11 21:28:54 --> Config Class Initialized
INFO - 2018-05-11 21:28:54 --> Hooks Class Initialized
DEBUG - 2018-05-11 21:28:55 --> UTF-8 Support Enabled
INFO - 2018-05-11 21:28:55 --> Utf8 Class Initialized
INFO - 2018-05-11 21:28:55 --> URI Class Initialized
INFO - 2018-05-11 21:28:55 --> Router Class Initialized
INFO - 2018-05-11 21:28:55 --> Output Class Initialized
INFO - 2018-05-11 21:28:55 --> Security Class Initialized
DEBUG - 2018-05-11 21:28:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 21:28:55 --> Input Class Initialized
INFO - 2018-05-11 21:28:55 --> Language Class Initialized
INFO - 2018-05-11 21:28:56 --> Language Class Initialized
INFO - 2018-05-11 21:28:56 --> Config Class Initialized
INFO - 2018-05-11 21:28:56 --> Loader Class Initialized
DEBUG - 2018-05-11 21:28:56 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-11 21:28:56 --> Helper loaded: url_helper
INFO - 2018-05-11 21:28:56 --> Helper loaded: form_helper
INFO - 2018-05-11 21:28:56 --> Helper loaded: date_helper
INFO - 2018-05-11 21:28:56 --> Helper loaded: util_helper
INFO - 2018-05-11 21:28:56 --> Helper loaded: text_helper
INFO - 2018-05-11 21:28:56 --> Helper loaded: string_helper
INFO - 2018-05-11 21:28:57 --> Database Driver Class Initialized
DEBUG - 2018-05-11 21:28:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-11 21:28:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-11 21:28:59 --> Email Class Initialized
INFO - 2018-05-11 21:28:59 --> Controller Class Initialized
DEBUG - 2018-05-11 21:28:59 --> Admin MX_Controller Initialized
INFO - 2018-05-11 21:28:59 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-11 21:28:59 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-11 21:28:59 --> Login MX_Controller Initialized
DEBUG - 2018-05-11 21:28:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-11 21:28:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-11 21:28:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/logins/login.php
INFO - 2018-05-11 21:29:00 --> Config Class Initialized
INFO - 2018-05-11 21:29:00 --> Hooks Class Initialized
DEBUG - 2018-05-11 21:29:00 --> UTF-8 Support Enabled
INFO - 2018-05-11 21:29:00 --> Utf8 Class Initialized
INFO - 2018-05-11 21:29:00 --> URI Class Initialized
INFO - 2018-05-11 21:29:00 --> Router Class Initialized
INFO - 2018-05-11 21:29:00 --> Output Class Initialized
INFO - 2018-05-11 21:29:00 --> Security Class Initialized
DEBUG - 2018-05-11 21:29:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 21:29:00 --> Input Class Initialized
INFO - 2018-05-11 21:29:00 --> Language Class Initialized
ERROR - 2018-05-11 21:29:00 --> 404 Page Not Found: /index
INFO - 2018-05-11 21:29:01 --> Config Class Initialized
INFO - 2018-05-11 21:29:01 --> Hooks Class Initialized
DEBUG - 2018-05-11 21:29:01 --> UTF-8 Support Enabled
INFO - 2018-05-11 21:29:01 --> Utf8 Class Initialized
INFO - 2018-05-11 21:29:01 --> URI Class Initialized
INFO - 2018-05-11 21:29:01 --> Router Class Initialized
INFO - 2018-05-11 21:29:01 --> Output Class Initialized
INFO - 2018-05-11 21:29:01 --> Security Class Initialized
DEBUG - 2018-05-11 21:29:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 21:29:01 --> Input Class Initialized
INFO - 2018-05-11 21:29:01 --> Language Class Initialized
ERROR - 2018-05-11 21:29:01 --> 404 Page Not Found: /index
INFO - 2018-05-11 21:29:05 --> Config Class Initialized
INFO - 2018-05-11 21:29:05 --> Hooks Class Initialized
DEBUG - 2018-05-11 21:29:05 --> UTF-8 Support Enabled
INFO - 2018-05-11 21:29:05 --> Utf8 Class Initialized
INFO - 2018-05-11 21:29:05 --> URI Class Initialized
INFO - 2018-05-11 21:29:05 --> Router Class Initialized
INFO - 2018-05-11 21:29:05 --> Output Class Initialized
INFO - 2018-05-11 21:29:05 --> Security Class Initialized
DEBUG - 2018-05-11 21:29:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 21:29:05 --> Input Class Initialized
INFO - 2018-05-11 21:29:05 --> Language Class Initialized
INFO - 2018-05-11 21:29:05 --> Language Class Initialized
INFO - 2018-05-11 21:29:05 --> Config Class Initialized
INFO - 2018-05-11 21:29:05 --> Loader Class Initialized
DEBUG - 2018-05-11 21:29:05 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-11 21:29:05 --> Helper loaded: url_helper
INFO - 2018-05-11 21:29:05 --> Helper loaded: form_helper
INFO - 2018-05-11 21:29:05 --> Helper loaded: date_helper
INFO - 2018-05-11 21:29:05 --> Helper loaded: util_helper
INFO - 2018-05-11 21:29:05 --> Helper loaded: text_helper
INFO - 2018-05-11 21:29:05 --> Helper loaded: string_helper
INFO - 2018-05-11 21:29:05 --> Database Driver Class Initialized
DEBUG - 2018-05-11 21:29:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-11 21:29:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-11 21:29:05 --> Email Class Initialized
INFO - 2018-05-11 21:29:05 --> Controller Class Initialized
DEBUG - 2018-05-11 21:29:05 --> Home MX_Controller Initialized
DEBUG - 2018-05-11 21:29:05 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-11 21:29:05 --> Login MX_Controller Initialized
INFO - 2018-05-11 21:29:05 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-11 21:29:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-11 21:29:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-11 21:29:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/login.php
INFO - 2018-05-11 21:29:45 --> Config Class Initialized
INFO - 2018-05-11 21:29:45 --> Hooks Class Initialized
DEBUG - 2018-05-11 21:29:45 --> UTF-8 Support Enabled
INFO - 2018-05-11 21:29:45 --> Utf8 Class Initialized
INFO - 2018-05-11 21:29:45 --> URI Class Initialized
INFO - 2018-05-11 21:29:45 --> Router Class Initialized
INFO - 2018-05-11 21:29:45 --> Output Class Initialized
INFO - 2018-05-11 21:29:45 --> Security Class Initialized
DEBUG - 2018-05-11 21:29:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 21:29:45 --> Input Class Initialized
INFO - 2018-05-11 21:29:46 --> Language Class Initialized
INFO - 2018-05-11 21:29:46 --> Language Class Initialized
INFO - 2018-05-11 21:29:46 --> Config Class Initialized
INFO - 2018-05-11 21:29:46 --> Loader Class Initialized
DEBUG - 2018-05-11 21:29:46 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-11 21:29:46 --> Helper loaded: url_helper
INFO - 2018-05-11 21:29:46 --> Helper loaded: form_helper
INFO - 2018-05-11 21:29:46 --> Helper loaded: date_helper
INFO - 2018-05-11 21:29:46 --> Helper loaded: util_helper
INFO - 2018-05-11 21:29:46 --> Helper loaded: text_helper
INFO - 2018-05-11 21:29:46 --> Helper loaded: string_helper
INFO - 2018-05-11 21:29:46 --> Database Driver Class Initialized
DEBUG - 2018-05-11 21:29:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-11 21:29:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-11 21:29:46 --> Email Class Initialized
INFO - 2018-05-11 21:29:46 --> Controller Class Initialized
DEBUG - 2018-05-11 21:29:46 --> Login MX_Controller Initialized
INFO - 2018-05-11 21:29:46 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-11 21:29:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-11 21:29:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-11 21:29:46 --> Email starts for gopipanguluri123@gmail.com fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-05-11 21:29:46 --> User session created for 4
INFO - 2018-05-11 21:29:46 --> Login status gopipanguluri123@gmail.com - success
ERROR - 2018-05-11 21:29:46 --> Severity: Notice --> Undefined variable: data E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php 314
INFO - 2018-05-11 21:29:46 --> Final output sent to browser
DEBUG - 2018-05-11 21:29:46 --> Total execution time: 0.6790
INFO - 2018-05-11 21:29:49 --> Config Class Initialized
INFO - 2018-05-11 21:29:49 --> Hooks Class Initialized
DEBUG - 2018-05-11 21:29:49 --> UTF-8 Support Enabled
INFO - 2018-05-11 21:29:49 --> Utf8 Class Initialized
INFO - 2018-05-11 21:29:49 --> URI Class Initialized
INFO - 2018-05-11 21:29:49 --> Router Class Initialized
INFO - 2018-05-11 21:29:49 --> Output Class Initialized
INFO - 2018-05-11 21:29:49 --> Security Class Initialized
DEBUG - 2018-05-11 21:29:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 21:29:49 --> Input Class Initialized
INFO - 2018-05-11 21:29:49 --> Language Class Initialized
INFO - 2018-05-11 21:29:49 --> Language Class Initialized
INFO - 2018-05-11 21:29:49 --> Config Class Initialized
INFO - 2018-05-11 21:29:49 --> Loader Class Initialized
DEBUG - 2018-05-11 21:29:49 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-11 21:29:49 --> Helper loaded: url_helper
INFO - 2018-05-11 21:29:49 --> Helper loaded: form_helper
INFO - 2018-05-11 21:29:49 --> Helper loaded: date_helper
INFO - 2018-05-11 21:29:49 --> Helper loaded: util_helper
INFO - 2018-05-11 21:29:49 --> Helper loaded: text_helper
INFO - 2018-05-11 21:29:49 --> Helper loaded: string_helper
INFO - 2018-05-11 21:29:49 --> Database Driver Class Initialized
DEBUG - 2018-05-11 21:29:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-11 21:29:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-11 21:29:49 --> Email Class Initialized
INFO - 2018-05-11 21:29:49 --> Controller Class Initialized
DEBUG - 2018-05-11 21:29:49 --> Admin MX_Controller Initialized
INFO - 2018-05-11 21:29:49 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-11 21:29:49 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-11 21:29:49 --> Login MX_Controller Initialized
DEBUG - 2018-05-11 21:29:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-11 21:29:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-11 21:29:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/logins/login.php
INFO - 2018-05-11 21:29:50 --> Config Class Initialized
INFO - 2018-05-11 21:29:50 --> Hooks Class Initialized
DEBUG - 2018-05-11 21:29:50 --> UTF-8 Support Enabled
INFO - 2018-05-11 21:29:50 --> Utf8 Class Initialized
INFO - 2018-05-11 21:29:50 --> URI Class Initialized
INFO - 2018-05-11 21:29:50 --> Router Class Initialized
INFO - 2018-05-11 21:29:50 --> Output Class Initialized
INFO - 2018-05-11 21:29:50 --> Security Class Initialized
DEBUG - 2018-05-11 21:29:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 21:29:50 --> Input Class Initialized
INFO - 2018-05-11 21:29:50 --> Language Class Initialized
ERROR - 2018-05-11 21:29:50 --> 404 Page Not Found: /index
INFO - 2018-05-11 21:29:51 --> Config Class Initialized
INFO - 2018-05-11 21:29:51 --> Hooks Class Initialized
DEBUG - 2018-05-11 21:29:51 --> UTF-8 Support Enabled
INFO - 2018-05-11 21:29:51 --> Utf8 Class Initialized
INFO - 2018-05-11 21:29:51 --> URI Class Initialized
INFO - 2018-05-11 21:29:51 --> Router Class Initialized
INFO - 2018-05-11 21:29:51 --> Output Class Initialized
INFO - 2018-05-11 21:29:51 --> Security Class Initialized
DEBUG - 2018-05-11 21:29:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 21:29:51 --> Input Class Initialized
INFO - 2018-05-11 21:29:51 --> Language Class Initialized
INFO - 2018-05-11 21:29:51 --> Language Class Initialized
INFO - 2018-05-11 21:29:51 --> Config Class Initialized
INFO - 2018-05-11 21:29:51 --> Loader Class Initialized
DEBUG - 2018-05-11 21:29:51 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-11 21:29:51 --> Helper loaded: url_helper
INFO - 2018-05-11 21:29:51 --> Helper loaded: form_helper
INFO - 2018-05-11 21:29:51 --> Helper loaded: date_helper
INFO - 2018-05-11 21:29:51 --> Helper loaded: util_helper
INFO - 2018-05-11 21:29:51 --> Helper loaded: text_helper
INFO - 2018-05-11 21:29:51 --> Helper loaded: string_helper
INFO - 2018-05-11 21:29:51 --> Database Driver Class Initialized
DEBUG - 2018-05-11 21:29:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-11 21:29:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-11 21:29:51 --> Email Class Initialized
INFO - 2018-05-11 21:29:51 --> Controller Class Initialized
DEBUG - 2018-05-11 21:29:51 --> Login MX_Controller Initialized
INFO - 2018-05-11 21:29:51 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-11 21:29:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-11 21:29:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-11 21:29:51 --> Email starts for gopipanguluri123@gmail.com fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-05-11 21:29:51 --> User session created for 4
INFO - 2018-05-11 21:29:52 --> Login status gopipanguluri123@gmail.com - success
ERROR - 2018-05-11 21:29:52 --> Severity: Notice --> Undefined variable: data E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php 314
INFO - 2018-05-11 21:29:52 --> Final output sent to browser
DEBUG - 2018-05-11 21:29:52 --> Total execution time: 0.6421
INFO - 2018-05-11 21:30:01 --> Config Class Initialized
INFO - 2018-05-11 21:30:01 --> Hooks Class Initialized
DEBUG - 2018-05-11 21:30:01 --> UTF-8 Support Enabled
INFO - 2018-05-11 21:30:01 --> Utf8 Class Initialized
INFO - 2018-05-11 21:30:01 --> URI Class Initialized
INFO - 2018-05-11 21:30:01 --> Router Class Initialized
INFO - 2018-05-11 21:30:01 --> Output Class Initialized
INFO - 2018-05-11 21:30:01 --> Security Class Initialized
DEBUG - 2018-05-11 21:30:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 21:30:01 --> Input Class Initialized
INFO - 2018-05-11 21:30:01 --> Language Class Initialized
INFO - 2018-05-11 21:30:01 --> Language Class Initialized
INFO - 2018-05-11 21:30:01 --> Config Class Initialized
INFO - 2018-05-11 21:30:01 --> Loader Class Initialized
DEBUG - 2018-05-11 21:30:01 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-11 21:30:01 --> Helper loaded: url_helper
INFO - 2018-05-11 21:30:01 --> Helper loaded: form_helper
INFO - 2018-05-11 21:30:01 --> Helper loaded: date_helper
INFO - 2018-05-11 21:30:01 --> Helper loaded: util_helper
INFO - 2018-05-11 21:30:01 --> Helper loaded: text_helper
INFO - 2018-05-11 21:30:01 --> Helper loaded: string_helper
INFO - 2018-05-11 21:30:01 --> Database Driver Class Initialized
DEBUG - 2018-05-11 21:30:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-11 21:30:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-11 21:30:01 --> Email Class Initialized
INFO - 2018-05-11 21:30:01 --> Controller Class Initialized
DEBUG - 2018-05-11 21:30:01 --> Login MX_Controller Initialized
INFO - 2018-05-11 21:30:01 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-11 21:30:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-11 21:30:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-11 21:30:01 --> Email starts for gopipanguluri123@gmail.com fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-05-11 21:30:01 --> User session created for 4
INFO - 2018-05-11 21:30:01 --> Login status gopipanguluri123@gmail.com - success
ERROR - 2018-05-11 21:30:01 --> Severity: Notice --> Undefined variable: data E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php 314
INFO - 2018-05-11 21:30:01 --> Final output sent to browser
DEBUG - 2018-05-11 21:30:01 --> Total execution time: 0.6013
INFO - 2018-05-11 21:35:31 --> Config Class Initialized
INFO - 2018-05-11 21:35:31 --> Hooks Class Initialized
DEBUG - 2018-05-11 21:35:31 --> UTF-8 Support Enabled
INFO - 2018-05-11 21:35:31 --> Utf8 Class Initialized
INFO - 2018-05-11 21:35:31 --> URI Class Initialized
INFO - 2018-05-11 21:35:31 --> Router Class Initialized
INFO - 2018-05-11 21:35:31 --> Output Class Initialized
INFO - 2018-05-11 21:35:31 --> Security Class Initialized
DEBUG - 2018-05-11 21:35:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 21:35:31 --> Input Class Initialized
INFO - 2018-05-11 21:35:31 --> Language Class Initialized
INFO - 2018-05-11 21:35:31 --> Language Class Initialized
INFO - 2018-05-11 21:35:31 --> Config Class Initialized
INFO - 2018-05-11 21:35:31 --> Loader Class Initialized
DEBUG - 2018-05-11 21:35:31 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-11 21:35:31 --> Helper loaded: url_helper
INFO - 2018-05-11 21:35:31 --> Helper loaded: form_helper
INFO - 2018-05-11 21:35:31 --> Helper loaded: date_helper
INFO - 2018-05-11 21:35:31 --> Helper loaded: util_helper
INFO - 2018-05-11 21:35:31 --> Helper loaded: text_helper
INFO - 2018-05-11 21:35:31 --> Helper loaded: string_helper
INFO - 2018-05-11 21:35:31 --> Database Driver Class Initialized
DEBUG - 2018-05-11 21:35:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-11 21:35:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-11 21:35:31 --> Email Class Initialized
INFO - 2018-05-11 21:35:31 --> Controller Class Initialized
DEBUG - 2018-05-11 21:35:31 --> Login MX_Controller Initialized
INFO - 2018-05-11 21:35:31 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-11 21:35:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-11 21:35:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-11 21:35:32 --> Email starts for gopipanguluri123@gmail.com fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-05-11 21:35:32 --> User session created for 4
INFO - 2018-05-11 21:35:32 --> Login status gopipanguluri123@gmail.com - success
ERROR - 2018-05-11 21:35:32 --> Severity: Notice --> Undefined variable: data E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php 313
INFO - 2018-05-11 21:36:11 --> Config Class Initialized
INFO - 2018-05-11 21:36:11 --> Hooks Class Initialized
DEBUG - 2018-05-11 21:36:11 --> UTF-8 Support Enabled
INFO - 2018-05-11 21:36:12 --> Utf8 Class Initialized
INFO - 2018-05-11 21:36:12 --> URI Class Initialized
INFO - 2018-05-11 21:36:12 --> Router Class Initialized
INFO - 2018-05-11 21:36:12 --> Output Class Initialized
INFO - 2018-05-11 21:36:12 --> Security Class Initialized
DEBUG - 2018-05-11 21:36:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 21:36:12 --> Input Class Initialized
INFO - 2018-05-11 21:36:12 --> Language Class Initialized
INFO - 2018-05-11 21:36:12 --> Language Class Initialized
INFO - 2018-05-11 21:36:12 --> Config Class Initialized
INFO - 2018-05-11 21:36:12 --> Loader Class Initialized
DEBUG - 2018-05-11 21:36:12 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-11 21:36:12 --> Helper loaded: url_helper
INFO - 2018-05-11 21:36:12 --> Helper loaded: form_helper
INFO - 2018-05-11 21:36:12 --> Helper loaded: date_helper
INFO - 2018-05-11 21:36:12 --> Helper loaded: util_helper
INFO - 2018-05-11 21:36:12 --> Helper loaded: text_helper
INFO - 2018-05-11 21:36:12 --> Helper loaded: string_helper
INFO - 2018-05-11 21:36:12 --> Database Driver Class Initialized
DEBUG - 2018-05-11 21:36:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-11 21:36:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-11 21:36:12 --> Email Class Initialized
INFO - 2018-05-11 21:36:12 --> Controller Class Initialized
DEBUG - 2018-05-11 21:36:12 --> Login MX_Controller Initialized
INFO - 2018-05-11 21:36:12 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-11 21:36:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-11 21:36:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-11 21:36:12 --> Email starts for gopipanguluri123@gmail.com fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-05-11 21:36:12 --> User session created for 4
INFO - 2018-05-11 21:36:12 --> Login status gopipanguluri123@gmail.com - success
INFO - 2018-05-11 21:36:25 --> Config Class Initialized
INFO - 2018-05-11 21:36:25 --> Hooks Class Initialized
DEBUG - 2018-05-11 21:36:25 --> UTF-8 Support Enabled
INFO - 2018-05-11 21:36:25 --> Utf8 Class Initialized
INFO - 2018-05-11 21:36:25 --> URI Class Initialized
INFO - 2018-05-11 21:36:25 --> Router Class Initialized
INFO - 2018-05-11 21:36:25 --> Output Class Initialized
INFO - 2018-05-11 21:36:25 --> Security Class Initialized
DEBUG - 2018-05-11 21:36:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 21:36:25 --> Input Class Initialized
INFO - 2018-05-11 21:36:25 --> Language Class Initialized
INFO - 2018-05-11 21:36:25 --> Language Class Initialized
INFO - 2018-05-11 21:36:25 --> Config Class Initialized
INFO - 2018-05-11 21:36:25 --> Loader Class Initialized
DEBUG - 2018-05-11 21:36:25 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-11 21:36:25 --> Helper loaded: url_helper
INFO - 2018-05-11 21:36:25 --> Helper loaded: form_helper
INFO - 2018-05-11 21:36:25 --> Helper loaded: date_helper
INFO - 2018-05-11 21:36:25 --> Helper loaded: util_helper
INFO - 2018-05-11 21:36:25 --> Helper loaded: text_helper
INFO - 2018-05-11 21:36:25 --> Helper loaded: string_helper
INFO - 2018-05-11 21:36:26 --> Database Driver Class Initialized
DEBUG - 2018-05-11 21:36:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-11 21:36:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-11 21:36:26 --> Email Class Initialized
INFO - 2018-05-11 21:36:26 --> Controller Class Initialized
DEBUG - 2018-05-11 21:36:26 --> Home MX_Controller Initialized
DEBUG - 2018-05-11 21:36:26 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-11 21:36:26 --> Login MX_Controller Initialized
INFO - 2018-05-11 21:36:26 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-11 21:36:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-11 21:36:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-11 21:36:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-05-11 21:36:26 --> Final output sent to browser
DEBUG - 2018-05-11 21:36:26 --> Total execution time: 0.5248
INFO - 2018-05-11 21:36:26 --> Config Class Initialized
INFO - 2018-05-11 21:36:26 --> Hooks Class Initialized
DEBUG - 2018-05-11 21:36:26 --> UTF-8 Support Enabled
INFO - 2018-05-11 21:36:26 --> Utf8 Class Initialized
INFO - 2018-05-11 21:36:26 --> URI Class Initialized
INFO - 2018-05-11 21:36:26 --> Router Class Initialized
INFO - 2018-05-11 21:36:26 --> Output Class Initialized
INFO - 2018-05-11 21:36:26 --> Security Class Initialized
DEBUG - 2018-05-11 21:36:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 21:36:26 --> Input Class Initialized
INFO - 2018-05-11 21:36:26 --> Language Class Initialized
ERROR - 2018-05-11 21:36:26 --> 404 Page Not Found: /index
INFO - 2018-05-11 21:36:27 --> Config Class Initialized
INFO - 2018-05-11 21:36:27 --> Config Class Initialized
INFO - 2018-05-11 21:36:27 --> Config Class Initialized
INFO - 2018-05-11 21:36:27 --> Config Class Initialized
INFO - 2018-05-11 21:36:27 --> Config Class Initialized
INFO - 2018-05-11 21:36:27 --> Config Class Initialized
INFO - 2018-05-11 21:36:27 --> Hooks Class Initialized
INFO - 2018-05-11 21:36:27 --> Hooks Class Initialized
INFO - 2018-05-11 21:36:27 --> Hooks Class Initialized
INFO - 2018-05-11 21:36:27 --> Hooks Class Initialized
INFO - 2018-05-11 21:36:27 --> Hooks Class Initialized
DEBUG - 2018-05-11 21:36:27 --> UTF-8 Support Enabled
INFO - 2018-05-11 21:36:27 --> Hooks Class Initialized
INFO - 2018-05-11 21:36:27 --> Utf8 Class Initialized
DEBUG - 2018-05-11 21:36:27 --> UTF-8 Support Enabled
DEBUG - 2018-05-11 21:36:27 --> UTF-8 Support Enabled
DEBUG - 2018-05-11 21:36:27 --> UTF-8 Support Enabled
DEBUG - 2018-05-11 21:36:27 --> UTF-8 Support Enabled
DEBUG - 2018-05-11 21:36:27 --> UTF-8 Support Enabled
INFO - 2018-05-11 21:36:27 --> Utf8 Class Initialized
INFO - 2018-05-11 21:36:27 --> Utf8 Class Initialized
INFO - 2018-05-11 21:36:27 --> Utf8 Class Initialized
INFO - 2018-05-11 21:36:27 --> URI Class Initialized
INFO - 2018-05-11 21:36:27 --> Utf8 Class Initialized
INFO - 2018-05-11 21:36:27 --> Utf8 Class Initialized
INFO - 2018-05-11 21:36:27 --> URI Class Initialized
INFO - 2018-05-11 21:36:27 --> Router Class Initialized
INFO - 2018-05-11 21:36:27 --> URI Class Initialized
INFO - 2018-05-11 21:36:27 --> URI Class Initialized
INFO - 2018-05-11 21:36:27 --> URI Class Initialized
INFO - 2018-05-11 21:36:27 --> URI Class Initialized
INFO - 2018-05-11 21:36:27 --> Output Class Initialized
INFO - 2018-05-11 21:36:27 --> Router Class Initialized
INFO - 2018-05-11 21:36:27 --> Router Class Initialized
INFO - 2018-05-11 21:36:27 --> Router Class Initialized
INFO - 2018-05-11 21:36:27 --> Router Class Initialized
INFO - 2018-05-11 21:36:27 --> Router Class Initialized
INFO - 2018-05-11 21:36:27 --> Security Class Initialized
DEBUG - 2018-05-11 21:36:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 21:36:27 --> Input Class Initialized
INFO - 2018-05-11 21:36:27 --> Output Class Initialized
INFO - 2018-05-11 21:36:27 --> Output Class Initialized
INFO - 2018-05-11 21:36:27 --> Output Class Initialized
INFO - 2018-05-11 21:36:27 --> Output Class Initialized
INFO - 2018-05-11 21:36:27 --> Language Class Initialized
INFO - 2018-05-11 21:36:27 --> Output Class Initialized
INFO - 2018-05-11 21:36:27 --> Security Class Initialized
DEBUG - 2018-05-11 21:36:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 21:36:27 --> Security Class Initialized
ERROR - 2018-05-11 21:36:27 --> 404 Page Not Found: /index
INFO - 2018-05-11 21:36:27 --> Security Class Initialized
INFO - 2018-05-11 21:36:27 --> Security Class Initialized
INFO - 2018-05-11 21:36:27 --> Security Class Initialized
DEBUG - 2018-05-11 21:36:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-11 21:36:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 21:36:27 --> Input Class Initialized
DEBUG - 2018-05-11 21:36:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 21:36:27 --> Input Class Initialized
INFO - 2018-05-11 21:36:27 --> Language Class Initialized
ERROR - 2018-05-11 21:36:27 --> 404 Page Not Found: /index
DEBUG - 2018-05-11 21:36:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 21:36:27 --> Config Class Initialized
INFO - 2018-05-11 21:36:27 --> Hooks Class Initialized
INFO - 2018-05-11 21:36:27 --> Input Class Initialized
INFO - 2018-05-11 21:36:27 --> Input Class Initialized
INFO - 2018-05-11 21:36:27 --> Language Class Initialized
INFO - 2018-05-11 21:36:27 --> Input Class Initialized
INFO - 2018-05-11 21:36:27 --> Language Class Initialized
DEBUG - 2018-05-11 21:36:27 --> UTF-8 Support Enabled
INFO - 2018-05-11 21:36:27 --> Config Class Initialized
INFO - 2018-05-11 21:36:27 --> Language Class Initialized
ERROR - 2018-05-11 21:36:27 --> 404 Page Not Found: /index
INFO - 2018-05-11 21:36:27 --> Language Class Initialized
INFO - 2018-05-11 21:36:27 --> Hooks Class Initialized
INFO - 2018-05-11 21:36:27 --> Utf8 Class Initialized
ERROR - 2018-05-11 21:36:27 --> 404 Page Not Found: /index
ERROR - 2018-05-11 21:36:27 --> 404 Page Not Found: /index
ERROR - 2018-05-11 21:36:27 --> 404 Page Not Found: /index
INFO - 2018-05-11 21:36:27 --> Config Class Initialized
INFO - 2018-05-11 21:36:27 --> Hooks Class Initialized
INFO - 2018-05-11 21:36:27 --> URI Class Initialized
DEBUG - 2018-05-11 21:36:27 --> UTF-8 Support Enabled
INFO - 2018-05-11 21:36:27 --> Config Class Initialized
INFO - 2018-05-11 21:36:27 --> Config Class Initialized
INFO - 2018-05-11 21:36:27 --> Hooks Class Initialized
INFO - 2018-05-11 21:36:27 --> Hooks Class Initialized
DEBUG - 2018-05-11 21:36:27 --> UTF-8 Support Enabled
INFO - 2018-05-11 21:36:27 --> Utf8 Class Initialized
INFO - 2018-05-11 21:36:27 --> Router Class Initialized
INFO - 2018-05-11 21:36:27 --> Utf8 Class Initialized
DEBUG - 2018-05-11 21:36:27 --> UTF-8 Support Enabled
INFO - 2018-05-11 21:36:27 --> URI Class Initialized
INFO - 2018-05-11 21:36:27 --> Output Class Initialized
DEBUG - 2018-05-11 21:36:27 --> UTF-8 Support Enabled
INFO - 2018-05-11 21:36:27 --> Utf8 Class Initialized
INFO - 2018-05-11 21:36:27 --> Security Class Initialized
INFO - 2018-05-11 21:36:27 --> Router Class Initialized
INFO - 2018-05-11 21:36:27 --> Utf8 Class Initialized
INFO - 2018-05-11 21:36:27 --> URI Class Initialized
INFO - 2018-05-11 21:36:27 --> URI Class Initialized
INFO - 2018-05-11 21:36:27 --> Output Class Initialized
DEBUG - 2018-05-11 21:36:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 21:36:27 --> URI Class Initialized
INFO - 2018-05-11 21:36:27 --> Router Class Initialized
INFO - 2018-05-11 21:36:27 --> Router Class Initialized
INFO - 2018-05-11 21:36:27 --> Input Class Initialized
INFO - 2018-05-11 21:36:27 --> Router Class Initialized
INFO - 2018-05-11 21:36:27 --> Security Class Initialized
INFO - 2018-05-11 21:36:27 --> Output Class Initialized
INFO - 2018-05-11 21:36:27 --> Language Class Initialized
INFO - 2018-05-11 21:36:27 --> Security Class Initialized
DEBUG - 2018-05-11 21:36:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 21:36:27 --> Output Class Initialized
INFO - 2018-05-11 21:36:27 --> Output Class Initialized
INFO - 2018-05-11 21:36:27 --> Input Class Initialized
ERROR - 2018-05-11 21:36:27 --> 404 Page Not Found: /index
DEBUG - 2018-05-11 21:36:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 21:36:27 --> Security Class Initialized
INFO - 2018-05-11 21:36:27 --> Security Class Initialized
INFO - 2018-05-11 21:36:27 --> Input Class Initialized
INFO - 2018-05-11 21:36:27 --> Language Class Initialized
DEBUG - 2018-05-11 21:36:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-11 21:36:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 21:36:27 --> Config Class Initialized
INFO - 2018-05-11 21:36:27 --> Hooks Class Initialized
INFO - 2018-05-11 21:36:27 --> Input Class Initialized
INFO - 2018-05-11 21:36:27 --> Input Class Initialized
INFO - 2018-05-11 21:36:27 --> Language Class Initialized
ERROR - 2018-05-11 21:36:27 --> 404 Page Not Found: /index
DEBUG - 2018-05-11 21:36:27 --> UTF-8 Support Enabled
INFO - 2018-05-11 21:36:27 --> Language Class Initialized
ERROR - 2018-05-11 21:36:27 --> 404 Page Not Found: /index
INFO - 2018-05-11 21:36:27 --> Language Class Initialized
INFO - 2018-05-11 21:36:27 --> Config Class Initialized
INFO - 2018-05-11 21:36:28 --> Utf8 Class Initialized
INFO - 2018-05-11 21:36:28 --> Hooks Class Initialized
ERROR - 2018-05-11 21:36:28 --> 404 Page Not Found: /index
ERROR - 2018-05-11 21:36:28 --> 404 Page Not Found: /index
INFO - 2018-05-11 21:36:28 --> Config Class Initialized
INFO - 2018-05-11 21:36:28 --> Hooks Class Initialized
INFO - 2018-05-11 21:36:28 --> Config Class Initialized
INFO - 2018-05-11 21:36:28 --> URI Class Initialized
DEBUG - 2018-05-11 21:36:28 --> UTF-8 Support Enabled
INFO - 2018-05-11 21:36:28 --> Config Class Initialized
INFO - 2018-05-11 21:36:28 --> Hooks Class Initialized
INFO - 2018-05-11 21:36:28 --> Hooks Class Initialized
DEBUG - 2018-05-11 21:36:28 --> UTF-8 Support Enabled
INFO - 2018-05-11 21:36:28 --> Utf8 Class Initialized
INFO - 2018-05-11 21:36:28 --> Router Class Initialized
DEBUG - 2018-05-11 21:36:28 --> UTF-8 Support Enabled
INFO - 2018-05-11 21:36:28 --> Utf8 Class Initialized
INFO - 2018-05-11 21:36:28 --> Utf8 Class Initialized
DEBUG - 2018-05-11 21:36:28 --> UTF-8 Support Enabled
INFO - 2018-05-11 21:36:28 --> URI Class Initialized
INFO - 2018-05-11 21:36:28 --> Output Class Initialized
INFO - 2018-05-11 21:36:28 --> Utf8 Class Initialized
INFO - 2018-05-11 21:36:28 --> URI Class Initialized
INFO - 2018-05-11 21:36:28 --> URI Class Initialized
INFO - 2018-05-11 21:36:28 --> Security Class Initialized
INFO - 2018-05-11 21:36:28 --> Router Class Initialized
INFO - 2018-05-11 21:36:28 --> Output Class Initialized
INFO - 2018-05-11 21:36:28 --> URI Class Initialized
INFO - 2018-05-11 21:36:28 --> Router Class Initialized
DEBUG - 2018-05-11 21:36:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 21:36:28 --> Router Class Initialized
INFO - 2018-05-11 21:36:28 --> Security Class Initialized
INFO - 2018-05-11 21:36:28 --> Output Class Initialized
DEBUG - 2018-05-11 21:36:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 21:36:28 --> Security Class Initialized
INFO - 2018-05-11 21:36:28 --> Input Class Initialized
INFO - 2018-05-11 21:36:28 --> Input Class Initialized
DEBUG - 2018-05-11 21:36:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 21:36:28 --> Output Class Initialized
INFO - 2018-05-11 21:36:28 --> Router Class Initialized
INFO - 2018-05-11 21:36:28 --> Output Class Initialized
INFO - 2018-05-11 21:36:28 --> Input Class Initialized
INFO - 2018-05-11 21:36:28 --> Security Class Initialized
INFO - 2018-05-11 21:36:28 --> Language Class Initialized
INFO - 2018-05-11 21:36:28 --> Language Class Initialized
DEBUG - 2018-05-11 21:36:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-05-11 21:36:28 --> 404 Page Not Found: /index
ERROR - 2018-05-11 21:36:28 --> 404 Page Not Found: /index
INFO - 2018-05-11 21:36:28 --> Language Class Initialized
INFO - 2018-05-11 21:36:28 --> Security Class Initialized
INFO - 2018-05-11 21:36:28 --> Input Class Initialized
ERROR - 2018-05-11 21:36:28 --> 404 Page Not Found: /index
DEBUG - 2018-05-11 21:36:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 21:36:28 --> Input Class Initialized
INFO - 2018-05-11 21:36:28 --> Language Class Initialized
INFO - 2018-05-11 21:36:28 --> Language Class Initialized
ERROR - 2018-05-11 21:36:28 --> 404 Page Not Found: /index
ERROR - 2018-05-11 21:36:28 --> 404 Page Not Found: /index
INFO - 2018-05-11 21:36:33 --> Config Class Initialized
INFO - 2018-05-11 21:36:33 --> Hooks Class Initialized
DEBUG - 2018-05-11 21:36:33 --> UTF-8 Support Enabled
INFO - 2018-05-11 21:36:33 --> Utf8 Class Initialized
INFO - 2018-05-11 21:36:33 --> URI Class Initialized
INFO - 2018-05-11 21:36:33 --> Router Class Initialized
INFO - 2018-05-11 21:36:33 --> Output Class Initialized
INFO - 2018-05-11 21:36:33 --> Security Class Initialized
DEBUG - 2018-05-11 21:36:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 21:36:33 --> Input Class Initialized
INFO - 2018-05-11 21:36:33 --> Language Class Initialized
ERROR - 2018-05-11 21:36:33 --> 404 Page Not Found: /index
INFO - 2018-05-11 21:36:33 --> Config Class Initialized
INFO - 2018-05-11 21:36:33 --> Hooks Class Initialized
DEBUG - 2018-05-11 21:36:33 --> UTF-8 Support Enabled
INFO - 2018-05-11 21:36:33 --> Utf8 Class Initialized
INFO - 2018-05-11 21:36:33 --> URI Class Initialized
INFO - 2018-05-11 21:36:33 --> Router Class Initialized
INFO - 2018-05-11 21:36:33 --> Output Class Initialized
INFO - 2018-05-11 21:36:33 --> Security Class Initialized
DEBUG - 2018-05-11 21:36:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 21:36:33 --> Input Class Initialized
INFO - 2018-05-11 21:36:33 --> Language Class Initialized
ERROR - 2018-05-11 21:36:33 --> 404 Page Not Found: /index
INFO - 2018-05-11 21:36:33 --> Config Class Initialized
INFO - 2018-05-11 21:36:33 --> Hooks Class Initialized
DEBUG - 2018-05-11 21:36:33 --> UTF-8 Support Enabled
INFO - 2018-05-11 21:36:33 --> Utf8 Class Initialized
INFO - 2018-05-11 21:36:33 --> URI Class Initialized
INFO - 2018-05-11 21:36:33 --> Router Class Initialized
INFO - 2018-05-11 21:36:33 --> Output Class Initialized
INFO - 2018-05-11 21:36:33 --> Security Class Initialized
DEBUG - 2018-05-11 21:36:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 21:36:33 --> Input Class Initialized
INFO - 2018-05-11 21:36:33 --> Language Class Initialized
ERROR - 2018-05-11 21:36:33 --> 404 Page Not Found: /index
INFO - 2018-05-11 21:41:27 --> Config Class Initialized
INFO - 2018-05-11 21:41:27 --> Hooks Class Initialized
DEBUG - 2018-05-11 21:41:27 --> UTF-8 Support Enabled
INFO - 2018-05-11 21:41:27 --> Utf8 Class Initialized
INFO - 2018-05-11 21:41:27 --> URI Class Initialized
INFO - 2018-05-11 21:41:27 --> Router Class Initialized
INFO - 2018-05-11 21:41:27 --> Output Class Initialized
INFO - 2018-05-11 21:41:27 --> Security Class Initialized
DEBUG - 2018-05-11 21:41:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 21:41:27 --> Input Class Initialized
INFO - 2018-05-11 21:41:27 --> Language Class Initialized
INFO - 2018-05-11 21:41:27 --> Language Class Initialized
INFO - 2018-05-11 21:41:27 --> Config Class Initialized
INFO - 2018-05-11 21:41:27 --> Loader Class Initialized
DEBUG - 2018-05-11 21:41:27 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-11 21:41:28 --> Helper loaded: url_helper
INFO - 2018-05-11 21:41:28 --> Helper loaded: form_helper
INFO - 2018-05-11 21:41:28 --> Helper loaded: date_helper
INFO - 2018-05-11 21:41:28 --> Helper loaded: util_helper
INFO - 2018-05-11 21:41:28 --> Helper loaded: text_helper
INFO - 2018-05-11 21:41:28 --> Helper loaded: string_helper
INFO - 2018-05-11 21:41:28 --> Database Driver Class Initialized
DEBUG - 2018-05-11 21:41:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-11 21:41:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-11 21:41:28 --> Email Class Initialized
INFO - 2018-05-11 21:41:28 --> Controller Class Initialized
DEBUG - 2018-05-11 21:41:28 --> Login MX_Controller Initialized
INFO - 2018-05-11 21:41:28 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-11 21:41:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-11 21:41:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-11 21:41:28 --> Email starts for gopipanguluri123@gmail.com fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-05-11 21:41:28 --> User session created for 4
INFO - 2018-05-11 21:41:28 --> Login status gopipanguluri123@gmail.com - success
INFO - 2018-05-11 21:41:30 --> Config Class Initialized
INFO - 2018-05-11 21:41:31 --> Hooks Class Initialized
DEBUG - 2018-05-11 21:41:31 --> UTF-8 Support Enabled
INFO - 2018-05-11 21:41:31 --> Utf8 Class Initialized
INFO - 2018-05-11 21:41:31 --> URI Class Initialized
INFO - 2018-05-11 21:41:31 --> Router Class Initialized
INFO - 2018-05-11 21:41:31 --> Output Class Initialized
INFO - 2018-05-11 21:41:31 --> Security Class Initialized
DEBUG - 2018-05-11 21:41:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 21:41:31 --> Input Class Initialized
INFO - 2018-05-11 21:41:31 --> Language Class Initialized
INFO - 2018-05-11 21:41:31 --> Language Class Initialized
INFO - 2018-05-11 21:41:31 --> Config Class Initialized
INFO - 2018-05-11 21:41:31 --> Loader Class Initialized
DEBUG - 2018-05-11 21:41:31 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-11 21:41:31 --> Helper loaded: url_helper
INFO - 2018-05-11 21:41:31 --> Helper loaded: form_helper
INFO - 2018-05-11 21:41:31 --> Helper loaded: date_helper
INFO - 2018-05-11 21:41:31 --> Helper loaded: util_helper
INFO - 2018-05-11 21:41:31 --> Helper loaded: text_helper
INFO - 2018-05-11 21:41:31 --> Helper loaded: string_helper
INFO - 2018-05-11 21:41:31 --> Database Driver Class Initialized
DEBUG - 2018-05-11 21:41:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-11 21:41:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-11 21:41:31 --> Email Class Initialized
INFO - 2018-05-11 21:41:31 --> Controller Class Initialized
DEBUG - 2018-05-11 21:41:31 --> Admin MX_Controller Initialized
INFO - 2018-05-11 21:41:31 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-11 21:41:31 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-11 21:41:31 --> Login MX_Controller Initialized
DEBUG - 2018-05-11 21:41:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-11 21:41:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-11 21:41:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/logins/login.php
INFO - 2018-05-11 21:41:31 --> Config Class Initialized
INFO - 2018-05-11 21:41:31 --> Hooks Class Initialized
DEBUG - 2018-05-11 21:41:31 --> UTF-8 Support Enabled
INFO - 2018-05-11 21:41:31 --> Utf8 Class Initialized
INFO - 2018-05-11 21:41:31 --> URI Class Initialized
INFO - 2018-05-11 21:41:31 --> Router Class Initialized
INFO - 2018-05-11 21:41:31 --> Output Class Initialized
INFO - 2018-05-11 21:41:31 --> Security Class Initialized
DEBUG - 2018-05-11 21:41:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 21:41:31 --> Input Class Initialized
INFO - 2018-05-11 21:41:31 --> Language Class Initialized
ERROR - 2018-05-11 21:41:32 --> 404 Page Not Found: /index
INFO - 2018-05-11 21:41:33 --> Config Class Initialized
INFO - 2018-05-11 21:41:33 --> Hooks Class Initialized
DEBUG - 2018-05-11 21:41:33 --> UTF-8 Support Enabled
INFO - 2018-05-11 21:41:33 --> Utf8 Class Initialized
INFO - 2018-05-11 21:41:33 --> URI Class Initialized
INFO - 2018-05-11 21:41:33 --> Router Class Initialized
INFO - 2018-05-11 21:41:33 --> Output Class Initialized
INFO - 2018-05-11 21:41:33 --> Security Class Initialized
DEBUG - 2018-05-11 21:41:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 21:41:34 --> Input Class Initialized
INFO - 2018-05-11 21:41:34 --> Language Class Initialized
INFO - 2018-05-11 21:41:34 --> Language Class Initialized
INFO - 2018-05-11 21:41:34 --> Config Class Initialized
INFO - 2018-05-11 21:41:34 --> Loader Class Initialized
DEBUG - 2018-05-11 21:41:34 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-11 21:41:34 --> Helper loaded: url_helper
INFO - 2018-05-11 21:41:34 --> Helper loaded: form_helper
INFO - 2018-05-11 21:41:34 --> Helper loaded: date_helper
INFO - 2018-05-11 21:41:34 --> Helper loaded: util_helper
INFO - 2018-05-11 21:41:34 --> Helper loaded: text_helper
INFO - 2018-05-11 21:41:34 --> Helper loaded: string_helper
INFO - 2018-05-11 21:41:34 --> Database Driver Class Initialized
DEBUG - 2018-05-11 21:41:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-11 21:41:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-11 21:41:34 --> Email Class Initialized
INFO - 2018-05-11 21:41:34 --> Controller Class Initialized
DEBUG - 2018-05-11 21:41:34 --> Login MX_Controller Initialized
INFO - 2018-05-11 21:41:34 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-11 21:41:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-11 21:41:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-11 21:41:34 --> Email starts for gopipanguluri123@gmail.com fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-05-11 21:41:34 --> User session created for 4
INFO - 2018-05-11 21:41:34 --> Login status gopipanguluri123@gmail.com - success
INFO - 2018-05-11 21:41:49 --> Config Class Initialized
INFO - 2018-05-11 21:41:49 --> Hooks Class Initialized
DEBUG - 2018-05-11 21:41:49 --> UTF-8 Support Enabled
INFO - 2018-05-11 21:41:49 --> Utf8 Class Initialized
INFO - 2018-05-11 21:41:49 --> URI Class Initialized
INFO - 2018-05-11 21:41:49 --> Router Class Initialized
INFO - 2018-05-11 21:41:49 --> Output Class Initialized
INFO - 2018-05-11 21:41:49 --> Security Class Initialized
DEBUG - 2018-05-11 21:41:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 21:41:49 --> Input Class Initialized
INFO - 2018-05-11 21:41:49 --> Language Class Initialized
INFO - 2018-05-11 21:41:50 --> Language Class Initialized
INFO - 2018-05-11 21:41:50 --> Config Class Initialized
INFO - 2018-05-11 21:41:50 --> Loader Class Initialized
DEBUG - 2018-05-11 21:41:50 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-11 21:41:50 --> Helper loaded: url_helper
INFO - 2018-05-11 21:41:50 --> Helper loaded: form_helper
INFO - 2018-05-11 21:41:50 --> Helper loaded: date_helper
INFO - 2018-05-11 21:41:50 --> Helper loaded: util_helper
INFO - 2018-05-11 21:41:50 --> Helper loaded: text_helper
INFO - 2018-05-11 21:41:50 --> Helper loaded: string_helper
INFO - 2018-05-11 21:41:50 --> Database Driver Class Initialized
DEBUG - 2018-05-11 21:41:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-11 21:41:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-11 21:41:50 --> Email Class Initialized
INFO - 2018-05-11 21:41:50 --> Controller Class Initialized
DEBUG - 2018-05-11 21:41:50 --> Login MX_Controller Initialized
INFO - 2018-05-11 21:41:50 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-11 21:41:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-11 21:41:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-11 21:41:50 --> Email starts for gopipanguluri123@gmail.com fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-05-11 21:42:30 --> Config Class Initialized
INFO - 2018-05-11 21:42:30 --> Hooks Class Initialized
DEBUG - 2018-05-11 21:42:30 --> UTF-8 Support Enabled
INFO - 2018-05-11 21:42:30 --> Utf8 Class Initialized
INFO - 2018-05-11 21:42:30 --> URI Class Initialized
INFO - 2018-05-11 21:42:30 --> Router Class Initialized
INFO - 2018-05-11 21:42:30 --> Output Class Initialized
INFO - 2018-05-11 21:42:30 --> Security Class Initialized
DEBUG - 2018-05-11 21:42:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 21:42:30 --> Input Class Initialized
INFO - 2018-05-11 21:42:30 --> Language Class Initialized
INFO - 2018-05-11 21:42:30 --> Language Class Initialized
INFO - 2018-05-11 21:42:30 --> Config Class Initialized
INFO - 2018-05-11 21:42:30 --> Loader Class Initialized
DEBUG - 2018-05-11 21:42:30 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-11 21:42:30 --> Helper loaded: url_helper
INFO - 2018-05-11 21:42:30 --> Helper loaded: form_helper
INFO - 2018-05-11 21:42:30 --> Helper loaded: date_helper
INFO - 2018-05-11 21:42:30 --> Helper loaded: util_helper
INFO - 2018-05-11 21:42:30 --> Helper loaded: text_helper
INFO - 2018-05-11 21:42:30 --> Helper loaded: string_helper
INFO - 2018-05-11 21:42:30 --> Database Driver Class Initialized
DEBUG - 2018-05-11 21:42:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-11 21:42:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-11 21:42:30 --> Email Class Initialized
INFO - 2018-05-11 21:42:30 --> Controller Class Initialized
DEBUG - 2018-05-11 21:42:30 --> Login MX_Controller Initialized
INFO - 2018-05-11 21:42:30 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-11 21:42:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-11 21:42:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-11 21:42:30 --> Email starts for gopipanguluri123@gmail.com fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-05-11 21:42:44 --> Config Class Initialized
INFO - 2018-05-11 21:42:44 --> Hooks Class Initialized
DEBUG - 2018-05-11 21:42:44 --> UTF-8 Support Enabled
INFO - 2018-05-11 21:42:44 --> Utf8 Class Initialized
INFO - 2018-05-11 21:42:44 --> URI Class Initialized
INFO - 2018-05-11 21:42:44 --> Router Class Initialized
INFO - 2018-05-11 21:42:44 --> Output Class Initialized
INFO - 2018-05-11 21:42:44 --> Security Class Initialized
DEBUG - 2018-05-11 21:42:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 21:42:44 --> Input Class Initialized
INFO - 2018-05-11 21:42:44 --> Language Class Initialized
INFO - 2018-05-11 21:42:44 --> Language Class Initialized
INFO - 2018-05-11 21:42:44 --> Config Class Initialized
INFO - 2018-05-11 21:42:44 --> Loader Class Initialized
DEBUG - 2018-05-11 21:42:44 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-11 21:42:44 --> Helper loaded: url_helper
INFO - 2018-05-11 21:42:44 --> Helper loaded: form_helper
INFO - 2018-05-11 21:42:44 --> Helper loaded: date_helper
INFO - 2018-05-11 21:42:44 --> Helper loaded: util_helper
INFO - 2018-05-11 21:42:44 --> Helper loaded: text_helper
INFO - 2018-05-11 21:42:44 --> Helper loaded: string_helper
INFO - 2018-05-11 21:42:44 --> Database Driver Class Initialized
DEBUG - 2018-05-11 21:42:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-11 21:42:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-11 21:42:44 --> Email Class Initialized
INFO - 2018-05-11 21:42:44 --> Controller Class Initialized
DEBUG - 2018-05-11 21:42:44 --> Login MX_Controller Initialized
INFO - 2018-05-11 21:42:44 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-11 21:42:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-11 21:42:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-11 21:42:44 --> Email starts for gopipanguluri123@gmail.com fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-05-11 21:42:44 --> Login status gopipanguluri123@gmail.com - failure
INFO - 2018-05-11 21:43:06 --> Config Class Initialized
INFO - 2018-05-11 21:43:06 --> Hooks Class Initialized
DEBUG - 2018-05-11 21:43:06 --> UTF-8 Support Enabled
INFO - 2018-05-11 21:43:06 --> Utf8 Class Initialized
INFO - 2018-05-11 21:43:06 --> URI Class Initialized
INFO - 2018-05-11 21:43:06 --> Router Class Initialized
INFO - 2018-05-11 21:43:06 --> Output Class Initialized
INFO - 2018-05-11 21:43:07 --> Security Class Initialized
DEBUG - 2018-05-11 21:43:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 21:43:07 --> Input Class Initialized
INFO - 2018-05-11 21:43:07 --> Language Class Initialized
INFO - 2018-05-11 21:43:07 --> Language Class Initialized
INFO - 2018-05-11 21:43:07 --> Config Class Initialized
INFO - 2018-05-11 21:43:07 --> Loader Class Initialized
DEBUG - 2018-05-11 21:43:07 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-11 21:43:07 --> Helper loaded: url_helper
INFO - 2018-05-11 21:43:07 --> Helper loaded: form_helper
INFO - 2018-05-11 21:43:07 --> Helper loaded: date_helper
INFO - 2018-05-11 21:43:07 --> Helper loaded: util_helper
INFO - 2018-05-11 21:43:07 --> Helper loaded: text_helper
INFO - 2018-05-11 21:43:07 --> Helper loaded: string_helper
INFO - 2018-05-11 21:43:07 --> Database Driver Class Initialized
DEBUG - 2018-05-11 21:43:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-11 21:43:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-11 21:43:07 --> Email Class Initialized
INFO - 2018-05-11 21:43:07 --> Controller Class Initialized
DEBUG - 2018-05-11 21:43:07 --> Login MX_Controller Initialized
INFO - 2018-05-11 21:43:07 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-11 21:43:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-11 21:43:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-11 21:43:07 --> Email starts for gopipanguluri123@gmail.com fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-05-11 21:43:07 --> Login status gopipanguluri123@gmail.com - failure
INFO - 2018-05-11 21:43:07 --> Final output sent to browser
DEBUG - 2018-05-11 21:43:07 --> Total execution time: 0.4691
INFO - 2018-05-11 21:43:13 --> Config Class Initialized
INFO - 2018-05-11 21:43:13 --> Hooks Class Initialized
DEBUG - 2018-05-11 21:43:13 --> UTF-8 Support Enabled
INFO - 2018-05-11 21:43:13 --> Utf8 Class Initialized
INFO - 2018-05-11 21:43:13 --> URI Class Initialized
INFO - 2018-05-11 21:43:13 --> Router Class Initialized
INFO - 2018-05-11 21:43:13 --> Output Class Initialized
INFO - 2018-05-11 21:43:13 --> Security Class Initialized
DEBUG - 2018-05-11 21:43:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 21:43:13 --> Input Class Initialized
INFO - 2018-05-11 21:43:13 --> Language Class Initialized
INFO - 2018-05-11 21:43:13 --> Language Class Initialized
INFO - 2018-05-11 21:43:13 --> Config Class Initialized
INFO - 2018-05-11 21:43:13 --> Loader Class Initialized
DEBUG - 2018-05-11 21:43:13 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-11 21:43:13 --> Helper loaded: url_helper
INFO - 2018-05-11 21:43:13 --> Helper loaded: form_helper
INFO - 2018-05-11 21:43:13 --> Helper loaded: date_helper
INFO - 2018-05-11 21:43:13 --> Helper loaded: util_helper
INFO - 2018-05-11 21:43:13 --> Helper loaded: text_helper
INFO - 2018-05-11 21:43:13 --> Helper loaded: string_helper
INFO - 2018-05-11 21:43:13 --> Database Driver Class Initialized
DEBUG - 2018-05-11 21:43:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-11 21:43:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-11 21:43:13 --> Email Class Initialized
INFO - 2018-05-11 21:43:13 --> Controller Class Initialized
DEBUG - 2018-05-11 21:43:13 --> Login MX_Controller Initialized
INFO - 2018-05-11 21:43:13 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-11 21:43:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-11 21:43:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-11 21:43:13 --> Email starts for admin@consulting.com fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-05-11 21:43:13 --> User session created for 1
INFO - 2018-05-11 21:43:13 --> Login status admin@consulting.com - success
INFO - 2018-05-11 21:43:13 --> Final output sent to browser
DEBUG - 2018-05-11 21:43:13 --> Total execution time: 0.4980
INFO - 2018-05-11 21:43:13 --> Config Class Initialized
INFO - 2018-05-11 21:43:13 --> Hooks Class Initialized
DEBUG - 2018-05-11 21:43:13 --> UTF-8 Support Enabled
INFO - 2018-05-11 21:43:13 --> Utf8 Class Initialized
INFO - 2018-05-11 21:43:13 --> URI Class Initialized
INFO - 2018-05-11 21:43:13 --> Router Class Initialized
INFO - 2018-05-11 21:43:13 --> Output Class Initialized
INFO - 2018-05-11 21:43:14 --> Security Class Initialized
DEBUG - 2018-05-11 21:43:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 21:43:14 --> Input Class Initialized
INFO - 2018-05-11 21:43:14 --> Language Class Initialized
INFO - 2018-05-11 21:43:14 --> Language Class Initialized
INFO - 2018-05-11 21:43:14 --> Config Class Initialized
INFO - 2018-05-11 21:43:14 --> Loader Class Initialized
DEBUG - 2018-05-11 21:43:14 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-11 21:43:14 --> Helper loaded: url_helper
INFO - 2018-05-11 21:43:14 --> Helper loaded: form_helper
INFO - 2018-05-11 21:43:14 --> Helper loaded: date_helper
INFO - 2018-05-11 21:43:14 --> Helper loaded: util_helper
INFO - 2018-05-11 21:43:14 --> Helper loaded: text_helper
INFO - 2018-05-11 21:43:14 --> Helper loaded: string_helper
INFO - 2018-05-11 21:43:14 --> Database Driver Class Initialized
DEBUG - 2018-05-11 21:43:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-11 21:43:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-11 21:43:14 --> Email Class Initialized
INFO - 2018-05-11 21:43:14 --> Controller Class Initialized
DEBUG - 2018-05-11 21:43:14 --> Admin MX_Controller Initialized
INFO - 2018-05-11 21:43:14 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-11 21:43:14 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-11 21:43:14 --> Login MX_Controller Initialized
DEBUG - 2018-05-11 21:43:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-11 21:43:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-11 21:43:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-05-11 21:43:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-05-11 21:43:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-05-11 21:43:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-05-11 21:43:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-05-11 21:43:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/dashboard.php
INFO - 2018-05-11 21:43:14 --> Final output sent to browser
DEBUG - 2018-05-11 21:43:14 --> Total execution time: 0.7391
INFO - 2018-05-11 21:43:14 --> Config Class Initialized
INFO - 2018-05-11 21:43:14 --> Hooks Class Initialized
DEBUG - 2018-05-11 21:43:14 --> UTF-8 Support Enabled
INFO - 2018-05-11 21:43:14 --> Utf8 Class Initialized
INFO - 2018-05-11 21:43:14 --> URI Class Initialized
INFO - 2018-05-11 21:43:15 --> Router Class Initialized
INFO - 2018-05-11 21:43:15 --> Output Class Initialized
INFO - 2018-05-11 21:43:15 --> Security Class Initialized
DEBUG - 2018-05-11 21:43:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 21:43:15 --> Input Class Initialized
INFO - 2018-05-11 21:43:15 --> Language Class Initialized
ERROR - 2018-05-11 21:43:15 --> 404 Page Not Found: /index
INFO - 2018-05-11 21:43:15 --> Config Class Initialized
INFO - 2018-05-11 21:43:15 --> Hooks Class Initialized
DEBUG - 2018-05-11 21:43:16 --> UTF-8 Support Enabled
INFO - 2018-05-11 21:43:16 --> Utf8 Class Initialized
INFO - 2018-05-11 21:43:16 --> Config Class Initialized
INFO - 2018-05-11 21:43:16 --> Hooks Class Initialized
INFO - 2018-05-11 21:43:16 --> URI Class Initialized
DEBUG - 2018-05-11 21:43:16 --> UTF-8 Support Enabled
INFO - 2018-05-11 21:43:16 --> Router Class Initialized
INFO - 2018-05-11 21:43:16 --> Utf8 Class Initialized
INFO - 2018-05-11 21:43:16 --> Output Class Initialized
INFO - 2018-05-11 21:43:16 --> Security Class Initialized
INFO - 2018-05-11 21:43:16 --> URI Class Initialized
DEBUG - 2018-05-11 21:43:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 21:43:16 --> Router Class Initialized
INFO - 2018-05-11 21:43:16 --> Input Class Initialized
INFO - 2018-05-11 21:43:16 --> Output Class Initialized
INFO - 2018-05-11 21:43:16 --> Language Class Initialized
INFO - 2018-05-11 21:43:16 --> Security Class Initialized
ERROR - 2018-05-11 21:43:16 --> 404 Page Not Found: /index
DEBUG - 2018-05-11 21:43:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 21:43:16 --> Input Class Initialized
INFO - 2018-05-11 21:43:16 --> Language Class Initialized
ERROR - 2018-05-11 21:43:16 --> 404 Page Not Found: /index
INFO - 2018-05-11 21:43:23 --> Config Class Initialized
INFO - 2018-05-11 21:43:23 --> Hooks Class Initialized
DEBUG - 2018-05-11 21:43:23 --> UTF-8 Support Enabled
INFO - 2018-05-11 21:43:24 --> Utf8 Class Initialized
INFO - 2018-05-11 21:43:24 --> URI Class Initialized
INFO - 2018-05-11 21:43:24 --> Router Class Initialized
INFO - 2018-05-11 21:43:24 --> Output Class Initialized
INFO - 2018-05-11 21:43:24 --> Security Class Initialized
DEBUG - 2018-05-11 21:43:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 21:43:24 --> Input Class Initialized
INFO - 2018-05-11 21:43:24 --> Language Class Initialized
ERROR - 2018-05-11 21:43:24 --> 404 Page Not Found: /index
INFO - 2018-05-11 21:44:26 --> Config Class Initialized
INFO - 2018-05-11 21:44:26 --> Hooks Class Initialized
DEBUG - 2018-05-11 21:44:26 --> UTF-8 Support Enabled
INFO - 2018-05-11 21:44:26 --> Utf8 Class Initialized
INFO - 2018-05-11 21:44:26 --> URI Class Initialized
INFO - 2018-05-11 21:44:26 --> Router Class Initialized
INFO - 2018-05-11 21:44:26 --> Output Class Initialized
INFO - 2018-05-11 21:44:26 --> Security Class Initialized
DEBUG - 2018-05-11 21:44:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 21:44:26 --> Input Class Initialized
INFO - 2018-05-11 21:44:26 --> Language Class Initialized
INFO - 2018-05-11 21:44:26 --> Language Class Initialized
INFO - 2018-05-11 21:44:26 --> Config Class Initialized
INFO - 2018-05-11 21:44:26 --> Loader Class Initialized
DEBUG - 2018-05-11 21:44:26 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-11 21:44:26 --> Helper loaded: url_helper
INFO - 2018-05-11 21:44:26 --> Helper loaded: form_helper
INFO - 2018-05-11 21:44:26 --> Helper loaded: date_helper
INFO - 2018-05-11 21:44:26 --> Helper loaded: util_helper
INFO - 2018-05-11 21:44:26 --> Helper loaded: text_helper
INFO - 2018-05-11 21:44:26 --> Helper loaded: string_helper
INFO - 2018-05-11 21:44:26 --> Database Driver Class Initialized
DEBUG - 2018-05-11 21:44:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-11 21:44:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-11 21:44:26 --> Email Class Initialized
INFO - 2018-05-11 21:44:26 --> Controller Class Initialized
DEBUG - 2018-05-11 21:44:26 --> Home MX_Controller Initialized
DEBUG - 2018-05-11 21:44:26 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-11 21:44:26 --> Login MX_Controller Initialized
INFO - 2018-05-11 21:44:26 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-11 21:44:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-11 21:44:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-11 21:44:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-05-11 21:44:26 --> Final output sent to browser
DEBUG - 2018-05-11 21:44:26 --> Total execution time: 0.6439
INFO - 2018-05-11 21:44:26 --> Config Class Initialized
INFO - 2018-05-11 21:44:26 --> Hooks Class Initialized
DEBUG - 2018-05-11 21:44:26 --> UTF-8 Support Enabled
INFO - 2018-05-11 21:44:26 --> Utf8 Class Initialized
INFO - 2018-05-11 21:44:26 --> URI Class Initialized
INFO - 2018-05-11 21:44:27 --> Router Class Initialized
INFO - 2018-05-11 21:44:27 --> Output Class Initialized
INFO - 2018-05-11 21:44:27 --> Security Class Initialized
DEBUG - 2018-05-11 21:44:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 21:44:27 --> Input Class Initialized
INFO - 2018-05-11 21:44:27 --> Language Class Initialized
ERROR - 2018-05-11 21:44:27 --> 404 Page Not Found: /index
INFO - 2018-05-11 21:44:27 --> Config Class Initialized
INFO - 2018-05-11 21:44:27 --> Config Class Initialized
INFO - 2018-05-11 21:44:27 --> Config Class Initialized
INFO - 2018-05-11 21:44:27 --> Config Class Initialized
INFO - 2018-05-11 21:44:27 --> Config Class Initialized
INFO - 2018-05-11 21:44:27 --> Config Class Initialized
INFO - 2018-05-11 21:44:27 --> Hooks Class Initialized
INFO - 2018-05-11 21:44:27 --> Hooks Class Initialized
INFO - 2018-05-11 21:44:27 --> Hooks Class Initialized
INFO - 2018-05-11 21:44:27 --> Hooks Class Initialized
INFO - 2018-05-11 21:44:27 --> Hooks Class Initialized
INFO - 2018-05-11 21:44:27 --> Hooks Class Initialized
DEBUG - 2018-05-11 21:44:27 --> UTF-8 Support Enabled
DEBUG - 2018-05-11 21:44:27 --> UTF-8 Support Enabled
DEBUG - 2018-05-11 21:44:27 --> UTF-8 Support Enabled
DEBUG - 2018-05-11 21:44:27 --> UTF-8 Support Enabled
DEBUG - 2018-05-11 21:44:27 --> UTF-8 Support Enabled
DEBUG - 2018-05-11 21:44:27 --> UTF-8 Support Enabled
INFO - 2018-05-11 21:44:27 --> Utf8 Class Initialized
INFO - 2018-05-11 21:44:27 --> Utf8 Class Initialized
INFO - 2018-05-11 21:44:27 --> Utf8 Class Initialized
INFO - 2018-05-11 21:44:27 --> Utf8 Class Initialized
INFO - 2018-05-11 21:44:27 --> Utf8 Class Initialized
INFO - 2018-05-11 21:44:27 --> Utf8 Class Initialized
INFO - 2018-05-11 21:44:27 --> URI Class Initialized
INFO - 2018-05-11 21:44:27 --> URI Class Initialized
INFO - 2018-05-11 21:44:27 --> URI Class Initialized
INFO - 2018-05-11 21:44:27 --> URI Class Initialized
INFO - 2018-05-11 21:44:27 --> URI Class Initialized
INFO - 2018-05-11 21:44:27 --> URI Class Initialized
INFO - 2018-05-11 21:44:27 --> Router Class Initialized
INFO - 2018-05-11 21:44:27 --> Router Class Initialized
INFO - 2018-05-11 21:44:27 --> Router Class Initialized
INFO - 2018-05-11 21:44:27 --> Router Class Initialized
INFO - 2018-05-11 21:44:27 --> Router Class Initialized
INFO - 2018-05-11 21:44:27 --> Router Class Initialized
INFO - 2018-05-11 21:44:27 --> Output Class Initialized
INFO - 2018-05-11 21:44:27 --> Output Class Initialized
INFO - 2018-05-11 21:44:27 --> Output Class Initialized
INFO - 2018-05-11 21:44:27 --> Output Class Initialized
INFO - 2018-05-11 21:44:27 --> Output Class Initialized
INFO - 2018-05-11 21:44:27 --> Security Class Initialized
INFO - 2018-05-11 21:44:27 --> Security Class Initialized
INFO - 2018-05-11 21:44:27 --> Security Class Initialized
INFO - 2018-05-11 21:44:27 --> Security Class Initialized
INFO - 2018-05-11 21:44:27 --> Output Class Initialized
INFO - 2018-05-11 21:44:27 --> Security Class Initialized
DEBUG - 2018-05-11 21:44:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-11 21:44:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-11 21:44:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 21:44:27 --> Security Class Initialized
DEBUG - 2018-05-11 21:44:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-11 21:44:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 21:44:27 --> Input Class Initialized
INFO - 2018-05-11 21:44:27 --> Input Class Initialized
INFO - 2018-05-11 21:44:27 --> Input Class Initialized
INFO - 2018-05-11 21:44:27 --> Input Class Initialized
INFO - 2018-05-11 21:44:27 --> Input Class Initialized
DEBUG - 2018-05-11 21:44:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 21:44:27 --> Language Class Initialized
INFO - 2018-05-11 21:44:27 --> Language Class Initialized
INFO - 2018-05-11 21:44:27 --> Language Class Initialized
INFO - 2018-05-11 21:44:27 --> Input Class Initialized
INFO - 2018-05-11 21:44:27 --> Language Class Initialized
INFO - 2018-05-11 21:44:27 --> Language Class Initialized
ERROR - 2018-05-11 21:44:27 --> 404 Page Not Found: /index
ERROR - 2018-05-11 21:44:27 --> 404 Page Not Found: /index
ERROR - 2018-05-11 21:44:27 --> 404 Page Not Found: /index
ERROR - 2018-05-11 21:44:27 --> 404 Page Not Found: /index
INFO - 2018-05-11 21:44:27 --> Language Class Initialized
INFO - 2018-05-11 21:44:27 --> Config Class Initialized
INFO - 2018-05-11 21:44:27 --> Hooks Class Initialized
DEBUG - 2018-05-11 21:44:27 --> UTF-8 Support Enabled
INFO - 2018-05-11 21:44:27 --> Utf8 Class Initialized
INFO - 2018-05-11 21:44:27 --> URI Class Initialized
INFO - 2018-05-11 21:44:27 --> Config Class Initialized
INFO - 2018-05-11 21:44:28 --> Hooks Class Initialized
INFO - 2018-05-11 21:44:28 --> Router Class Initialized
ERROR - 2018-05-11 21:44:28 --> 404 Page Not Found: /index
ERROR - 2018-05-11 21:44:28 --> 404 Page Not Found: /index
INFO - 2018-05-11 21:44:28 --> Output Class Initialized
INFO - 2018-05-11 21:44:28 --> Config Class Initialized
INFO - 2018-05-11 21:44:28 --> Config Class Initialized
DEBUG - 2018-05-11 21:44:28 --> UTF-8 Support Enabled
INFO - 2018-05-11 21:44:28 --> Config Class Initialized
INFO - 2018-05-11 21:44:28 --> Hooks Class Initialized
INFO - 2018-05-11 21:44:28 --> Security Class Initialized
INFO - 2018-05-11 21:44:28 --> Hooks Class Initialized
INFO - 2018-05-11 21:44:28 --> Hooks Class Initialized
INFO - 2018-05-11 21:44:28 --> Utf8 Class Initialized
DEBUG - 2018-05-11 21:44:28 --> UTF-8 Support Enabled
INFO - 2018-05-11 21:44:28 --> Utf8 Class Initialized
INFO - 2018-05-11 21:44:28 --> URI Class Initialized
INFO - 2018-05-11 21:44:28 --> Router Class Initialized
INFO - 2018-05-11 21:44:28 --> Output Class Initialized
INFO - 2018-05-11 21:44:28 --> Security Class Initialized
DEBUG - 2018-05-11 21:44:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 21:44:28 --> Input Class Initialized
DEBUG - 2018-05-11 21:44:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-11 21:44:28 --> UTF-8 Support Enabled
DEBUG - 2018-05-11 21:44:28 --> UTF-8 Support Enabled
INFO - 2018-05-11 21:44:28 --> URI Class Initialized
INFO - 2018-05-11 21:44:28 --> Language Class Initialized
INFO - 2018-05-11 21:44:28 --> Input Class Initialized
INFO - 2018-05-11 21:44:28 --> Language Class Initialized
INFO - 2018-05-11 21:44:28 --> Utf8 Class Initialized
INFO - 2018-05-11 21:44:28 --> Utf8 Class Initialized
INFO - 2018-05-11 21:44:28 --> Router Class Initialized
ERROR - 2018-05-11 21:44:28 --> 404 Page Not Found: /index
ERROR - 2018-05-11 21:44:28 --> 404 Page Not Found: /index
INFO - 2018-05-11 21:44:28 --> URI Class Initialized
INFO - 2018-05-11 21:44:28 --> Config Class Initialized
INFO - 2018-05-11 21:44:28 --> Config Class Initialized
INFO - 2018-05-11 21:44:28 --> Output Class Initialized
INFO - 2018-05-11 21:44:28 --> URI Class Initialized
INFO - 2018-05-11 21:44:28 --> Router Class Initialized
INFO - 2018-05-11 21:44:28 --> Hooks Class Initialized
INFO - 2018-05-11 21:44:28 --> Hooks Class Initialized
INFO - 2018-05-11 21:44:28 --> Security Class Initialized
INFO - 2018-05-11 21:44:28 --> Output Class Initialized
INFO - 2018-05-11 21:44:28 --> Router Class Initialized
DEBUG - 2018-05-11 21:44:28 --> UTF-8 Support Enabled
DEBUG - 2018-05-11 21:44:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-11 21:44:28 --> UTF-8 Support Enabled
INFO - 2018-05-11 21:44:28 --> Security Class Initialized
INFO - 2018-05-11 21:44:28 --> Output Class Initialized
INFO - 2018-05-11 21:44:28 --> Utf8 Class Initialized
INFO - 2018-05-11 21:44:29 --> Utf8 Class Initialized
DEBUG - 2018-05-11 21:44:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 21:44:29 --> Input Class Initialized
INFO - 2018-05-11 21:44:29 --> Security Class Initialized
INFO - 2018-05-11 21:44:29 --> URI Class Initialized
INFO - 2018-05-11 21:44:29 --> Router Class Initialized
INFO - 2018-05-11 21:44:29 --> Output Class Initialized
INFO - 2018-05-11 21:44:29 --> URI Class Initialized
DEBUG - 2018-05-11 21:44:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 21:44:29 --> Input Class Initialized
INFO - 2018-05-11 21:44:29 --> Language Class Initialized
INFO - 2018-05-11 21:44:29 --> Input Class Initialized
INFO - 2018-05-11 21:44:29 --> Language Class Initialized
INFO - 2018-05-11 21:44:29 --> Router Class Initialized
ERROR - 2018-05-11 21:44:29 --> 404 Page Not Found: /index
INFO - 2018-05-11 21:44:29 --> Security Class Initialized
INFO - 2018-05-11 21:44:29 --> Output Class Initialized
INFO - 2018-05-11 21:44:29 --> Language Class Initialized
ERROR - 2018-05-11 21:44:29 --> 404 Page Not Found: /index
ERROR - 2018-05-11 21:44:29 --> 404 Page Not Found: /index
INFO - 2018-05-11 21:44:29 --> Security Class Initialized
DEBUG - 2018-05-11 21:44:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 21:44:29 --> Config Class Initialized
INFO - 2018-05-11 21:44:29 --> Config Class Initialized
INFO - 2018-05-11 21:44:29 --> Hooks Class Initialized
INFO - 2018-05-11 21:44:29 --> Config Class Initialized
INFO - 2018-05-11 21:44:29 --> Input Class Initialized
INFO - 2018-05-11 21:44:29 --> Hooks Class Initialized
DEBUG - 2018-05-11 21:44:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 21:44:29 --> Language Class Initialized
INFO - 2018-05-11 21:44:29 --> Input Class Initialized
INFO - 2018-05-11 21:44:29 --> Hooks Class Initialized
DEBUG - 2018-05-11 21:44:29 --> UTF-8 Support Enabled
DEBUG - 2018-05-11 21:44:29 --> UTF-8 Support Enabled
ERROR - 2018-05-11 21:44:29 --> 404 Page Not Found: /index
INFO - 2018-05-11 21:44:29 --> Language Class Initialized
INFO - 2018-05-11 21:44:29 --> Utf8 Class Initialized
INFO - 2018-05-11 21:44:29 --> Utf8 Class Initialized
ERROR - 2018-05-11 21:44:29 --> 404 Page Not Found: /index
DEBUG - 2018-05-11 21:44:29 --> UTF-8 Support Enabled
INFO - 2018-05-11 21:44:29 --> URI Class Initialized
INFO - 2018-05-11 21:44:29 --> Utf8 Class Initialized
INFO - 2018-05-11 21:44:29 --> URI Class Initialized
INFO - 2018-05-11 21:44:29 --> Router Class Initialized
INFO - 2018-05-11 21:44:29 --> URI Class Initialized
INFO - 2018-05-11 21:44:29 --> Router Class Initialized
INFO - 2018-05-11 21:44:29 --> Output Class Initialized
INFO - 2018-05-11 21:44:29 --> Security Class Initialized
DEBUG - 2018-05-11 21:44:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 21:44:29 --> Input Class Initialized
INFO - 2018-05-11 21:44:29 --> Language Class Initialized
ERROR - 2018-05-11 21:44:29 --> 404 Page Not Found: /index
INFO - 2018-05-11 21:44:30 --> Output Class Initialized
INFO - 2018-05-11 21:44:30 --> Router Class Initialized
INFO - 2018-05-11 21:44:30 --> Security Class Initialized
DEBUG - 2018-05-11 21:44:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 21:44:30 --> Input Class Initialized
INFO - 2018-05-11 21:44:30 --> Output Class Initialized
INFO - 2018-05-11 21:44:30 --> Security Class Initialized
INFO - 2018-05-11 21:44:30 --> Language Class Initialized
ERROR - 2018-05-11 21:44:30 --> 404 Page Not Found: /index
DEBUG - 2018-05-11 21:44:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 21:44:30 --> Input Class Initialized
INFO - 2018-05-11 21:44:30 --> Language Class Initialized
ERROR - 2018-05-11 21:44:30 --> 404 Page Not Found: /index
INFO - 2018-05-11 21:44:33 --> Config Class Initialized
INFO - 2018-05-11 21:44:33 --> Hooks Class Initialized
DEBUG - 2018-05-11 21:44:33 --> UTF-8 Support Enabled
INFO - 2018-05-11 21:44:33 --> Utf8 Class Initialized
INFO - 2018-05-11 21:44:33 --> URI Class Initialized
INFO - 2018-05-11 21:44:33 --> Router Class Initialized
INFO - 2018-05-11 21:44:33 --> Output Class Initialized
INFO - 2018-05-11 21:44:34 --> Security Class Initialized
DEBUG - 2018-05-11 21:44:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 21:44:34 --> Input Class Initialized
INFO - 2018-05-11 21:44:34 --> Language Class Initialized
INFO - 2018-05-11 21:44:34 --> Language Class Initialized
INFO - 2018-05-11 21:44:34 --> Config Class Initialized
INFO - 2018-05-11 21:44:34 --> Loader Class Initialized
DEBUG - 2018-05-11 21:44:34 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-11 21:44:34 --> Helper loaded: url_helper
INFO - 2018-05-11 21:44:34 --> Helper loaded: form_helper
INFO - 2018-05-11 21:44:34 --> Helper loaded: date_helper
INFO - 2018-05-11 21:44:34 --> Helper loaded: util_helper
INFO - 2018-05-11 21:44:34 --> Helper loaded: text_helper
INFO - 2018-05-11 21:44:34 --> Helper loaded: string_helper
INFO - 2018-05-11 21:44:34 --> Database Driver Class Initialized
DEBUG - 2018-05-11 21:44:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-11 21:44:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-11 21:44:34 --> Email Class Initialized
INFO - 2018-05-11 21:44:34 --> Controller Class Initialized
DEBUG - 2018-05-11 21:44:34 --> Login MX_Controller Initialized
INFO - 2018-05-11 21:44:34 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-11 21:44:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-11 21:44:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-11 21:44:34 --> 4 Loggedout
INFO - 2018-05-11 21:44:34 --> Config Class Initialized
INFO - 2018-05-11 21:44:34 --> Hooks Class Initialized
DEBUG - 2018-05-11 21:44:34 --> UTF-8 Support Enabled
INFO - 2018-05-11 21:44:34 --> Utf8 Class Initialized
INFO - 2018-05-11 21:44:34 --> URI Class Initialized
INFO - 2018-05-11 21:44:34 --> Router Class Initialized
INFO - 2018-05-11 21:44:34 --> Output Class Initialized
INFO - 2018-05-11 21:44:34 --> Security Class Initialized
DEBUG - 2018-05-11 21:44:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 21:44:34 --> Input Class Initialized
INFO - 2018-05-11 21:44:34 --> Language Class Initialized
INFO - 2018-05-11 21:44:34 --> Language Class Initialized
INFO - 2018-05-11 21:44:34 --> Config Class Initialized
INFO - 2018-05-11 21:44:34 --> Loader Class Initialized
DEBUG - 2018-05-11 21:44:34 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-11 21:44:34 --> Helper loaded: url_helper
INFO - 2018-05-11 21:44:34 --> Helper loaded: form_helper
INFO - 2018-05-11 21:44:34 --> Helper loaded: date_helper
INFO - 2018-05-11 21:44:34 --> Helper loaded: util_helper
INFO - 2018-05-11 21:44:34 --> Helper loaded: text_helper
INFO - 2018-05-11 21:44:34 --> Helper loaded: string_helper
INFO - 2018-05-11 21:44:34 --> Database Driver Class Initialized
DEBUG - 2018-05-11 21:44:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-11 21:44:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-11 21:44:34 --> Email Class Initialized
INFO - 2018-05-11 21:44:35 --> Controller Class Initialized
DEBUG - 2018-05-11 21:44:35 --> Home MX_Controller Initialized
DEBUG - 2018-05-11 21:44:35 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-11 21:44:35 --> Login MX_Controller Initialized
INFO - 2018-05-11 21:44:35 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-11 21:44:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-11 21:44:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-11 21:44:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/login.php
INFO - 2018-05-11 21:44:37 --> Config Class Initialized
INFO - 2018-05-11 21:44:37 --> Hooks Class Initialized
DEBUG - 2018-05-11 21:44:37 --> UTF-8 Support Enabled
INFO - 2018-05-11 21:44:37 --> Utf8 Class Initialized
INFO - 2018-05-11 21:44:37 --> URI Class Initialized
INFO - 2018-05-11 21:44:37 --> Router Class Initialized
INFO - 2018-05-11 21:44:37 --> Output Class Initialized
INFO - 2018-05-11 21:44:37 --> Security Class Initialized
DEBUG - 2018-05-11 21:44:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 21:44:37 --> Input Class Initialized
INFO - 2018-05-11 21:44:37 --> Language Class Initialized
INFO - 2018-05-11 21:44:37 --> Language Class Initialized
INFO - 2018-05-11 21:44:37 --> Config Class Initialized
INFO - 2018-05-11 21:44:37 --> Loader Class Initialized
DEBUG - 2018-05-11 21:44:37 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-11 21:44:37 --> Helper loaded: url_helper
INFO - 2018-05-11 21:44:37 --> Helper loaded: form_helper
INFO - 2018-05-11 21:44:37 --> Helper loaded: date_helper
INFO - 2018-05-11 21:44:37 --> Helper loaded: util_helper
INFO - 2018-05-11 21:44:37 --> Helper loaded: text_helper
INFO - 2018-05-11 21:44:37 --> Helper loaded: string_helper
INFO - 2018-05-11 21:44:37 --> Database Driver Class Initialized
DEBUG - 2018-05-11 21:44:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-11 21:44:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-11 21:44:37 --> Email Class Initialized
INFO - 2018-05-11 21:44:37 --> Controller Class Initialized
DEBUG - 2018-05-11 21:44:37 --> Login MX_Controller Initialized
INFO - 2018-05-11 21:44:37 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-11 21:44:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-11 21:44:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-11 21:44:37 --> Email starts for gopipanguluri123@gmail.com fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-05-11 21:44:37 --> User session created for 4
INFO - 2018-05-11 21:44:37 --> Login status gopipanguluri123@gmail.com - success
INFO - 2018-05-11 21:44:37 --> Final output sent to browser
DEBUG - 2018-05-11 21:44:37 --> Total execution time: 0.5396
INFO - 2018-05-11 21:44:37 --> Config Class Initialized
INFO - 2018-05-11 21:44:37 --> Hooks Class Initialized
DEBUG - 2018-05-11 21:44:37 --> UTF-8 Support Enabled
INFO - 2018-05-11 21:44:37 --> Utf8 Class Initialized
INFO - 2018-05-11 21:44:37 --> URI Class Initialized
INFO - 2018-05-11 21:44:37 --> Router Class Initialized
INFO - 2018-05-11 21:44:37 --> Output Class Initialized
INFO - 2018-05-11 21:44:37 --> Security Class Initialized
DEBUG - 2018-05-11 21:44:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 21:44:37 --> Input Class Initialized
INFO - 2018-05-11 21:44:37 --> Language Class Initialized
INFO - 2018-05-11 21:44:37 --> Language Class Initialized
INFO - 2018-05-11 21:44:37 --> Config Class Initialized
INFO - 2018-05-11 21:44:37 --> Loader Class Initialized
DEBUG - 2018-05-11 21:44:37 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-11 21:44:37 --> Helper loaded: url_helper
INFO - 2018-05-11 21:44:37 --> Helper loaded: form_helper
INFO - 2018-05-11 21:44:37 --> Helper loaded: date_helper
INFO - 2018-05-11 21:44:37 --> Helper loaded: util_helper
INFO - 2018-05-11 21:44:37 --> Helper loaded: text_helper
INFO - 2018-05-11 21:44:37 --> Helper loaded: string_helper
INFO - 2018-05-11 21:44:37 --> Database Driver Class Initialized
DEBUG - 2018-05-11 21:44:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-11 21:44:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-11 21:44:38 --> Email Class Initialized
INFO - 2018-05-11 21:44:38 --> Controller Class Initialized
DEBUG - 2018-05-11 21:44:38 --> Home MX_Controller Initialized
DEBUG - 2018-05-11 21:44:38 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-11 21:44:38 --> Login MX_Controller Initialized
INFO - 2018-05-11 21:44:38 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-11 21:44:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-11 21:44:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-11 21:44:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-05-11 21:44:38 --> Final output sent to browser
INFO - 2018-05-11 21:44:38 --> Config Class Initialized
DEBUG - 2018-05-11 21:44:38 --> Total execution time: 0.5093
INFO - 2018-05-11 21:44:38 --> Hooks Class Initialized
DEBUG - 2018-05-11 21:44:38 --> UTF-8 Support Enabled
INFO - 2018-05-11 21:44:38 --> Utf8 Class Initialized
INFO - 2018-05-11 21:44:38 --> URI Class Initialized
INFO - 2018-05-11 21:44:38 --> Router Class Initialized
INFO - 2018-05-11 21:44:38 --> Output Class Initialized
INFO - 2018-05-11 21:44:38 --> Security Class Initialized
DEBUG - 2018-05-11 21:44:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 21:44:38 --> Input Class Initialized
INFO - 2018-05-11 21:44:38 --> Language Class Initialized
ERROR - 2018-05-11 21:44:38 --> 404 Page Not Found: /index
INFO - 2018-05-11 21:44:38 --> Config Class Initialized
INFO - 2018-05-11 21:44:38 --> Config Class Initialized
INFO - 2018-05-11 21:44:38 --> Config Class Initialized
INFO - 2018-05-11 21:44:38 --> Config Class Initialized
INFO - 2018-05-11 21:44:38 --> Config Class Initialized
INFO - 2018-05-11 21:44:38 --> Config Class Initialized
INFO - 2018-05-11 21:44:38 --> Hooks Class Initialized
INFO - 2018-05-11 21:44:38 --> Hooks Class Initialized
INFO - 2018-05-11 21:44:38 --> Hooks Class Initialized
INFO - 2018-05-11 21:44:38 --> Hooks Class Initialized
INFO - 2018-05-11 21:44:38 --> Hooks Class Initialized
INFO - 2018-05-11 21:44:38 --> Hooks Class Initialized
DEBUG - 2018-05-11 21:44:38 --> UTF-8 Support Enabled
DEBUG - 2018-05-11 21:44:38 --> UTF-8 Support Enabled
DEBUG - 2018-05-11 21:44:38 --> UTF-8 Support Enabled
DEBUG - 2018-05-11 21:44:38 --> UTF-8 Support Enabled
DEBUG - 2018-05-11 21:44:38 --> UTF-8 Support Enabled
DEBUG - 2018-05-11 21:44:38 --> UTF-8 Support Enabled
INFO - 2018-05-11 21:44:38 --> Utf8 Class Initialized
INFO - 2018-05-11 21:44:38 --> URI Class Initialized
INFO - 2018-05-11 21:44:38 --> Router Class Initialized
INFO - 2018-05-11 21:44:38 --> Output Class Initialized
INFO - 2018-05-11 21:44:38 --> Security Class Initialized
DEBUG - 2018-05-11 21:44:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 21:44:39 --> Input Class Initialized
INFO - 2018-05-11 21:44:39 --> Language Class Initialized
ERROR - 2018-05-11 21:44:39 --> 404 Page Not Found: /index
INFO - 2018-05-11 21:44:39 --> Utf8 Class Initialized
INFO - 2018-05-11 21:44:39 --> Utf8 Class Initialized
INFO - 2018-05-11 21:44:39 --> Utf8 Class Initialized
INFO - 2018-05-11 21:44:39 --> Utf8 Class Initialized
INFO - 2018-05-11 21:44:39 --> Utf8 Class Initialized
INFO - 2018-05-11 21:44:39 --> URI Class Initialized
INFO - 2018-05-11 21:44:39 --> URI Class Initialized
INFO - 2018-05-11 21:44:39 --> URI Class Initialized
INFO - 2018-05-11 21:44:39 --> URI Class Initialized
INFO - 2018-05-11 21:44:39 --> Router Class Initialized
INFO - 2018-05-11 21:44:39 --> Router Class Initialized
INFO - 2018-05-11 21:44:39 --> URI Class Initialized
INFO - 2018-05-11 21:44:39 --> Router Class Initialized
INFO - 2018-05-11 21:44:39 --> Output Class Initialized
INFO - 2018-05-11 21:44:39 --> Security Class Initialized
DEBUG - 2018-05-11 21:44:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 21:44:39 --> Config Class Initialized
INFO - 2018-05-11 21:44:39 --> Output Class Initialized
INFO - 2018-05-11 21:44:39 --> Hooks Class Initialized
INFO - 2018-05-11 21:44:39 --> Output Class Initialized
INFO - 2018-05-11 21:44:39 --> Router Class Initialized
INFO - 2018-05-11 21:44:39 --> Input Class Initialized
INFO - 2018-05-11 21:44:39 --> Router Class Initialized
INFO - 2018-05-11 21:44:39 --> Security Class Initialized
DEBUG - 2018-05-11 21:44:39 --> UTF-8 Support Enabled
INFO - 2018-05-11 21:44:39 --> Utf8 Class Initialized
INFO - 2018-05-11 21:44:39 --> URI Class Initialized
INFO - 2018-05-11 21:44:39 --> Router Class Initialized
INFO - 2018-05-11 21:44:39 --> Output Class Initialized
DEBUG - 2018-05-11 21:44:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 21:44:39 --> Output Class Initialized
INFO - 2018-05-11 21:44:39 --> Language Class Initialized
INFO - 2018-05-11 21:44:39 --> Security Class Initialized
INFO - 2018-05-11 21:44:39 --> Output Class Initialized
INFO - 2018-05-11 21:44:39 --> Security Class Initialized
INFO - 2018-05-11 21:44:39 --> Input Class Initialized
DEBUG - 2018-05-11 21:44:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-05-11 21:44:39 --> 404 Page Not Found: /index
INFO - 2018-05-11 21:44:39 --> Security Class Initialized
INFO - 2018-05-11 21:44:39 --> Security Class Initialized
DEBUG - 2018-05-11 21:44:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 21:44:39 --> Input Class Initialized
INFO - 2018-05-11 21:44:39 --> Language Class Initialized
INFO - 2018-05-11 21:44:39 --> Config Class Initialized
DEBUG - 2018-05-11 21:44:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-11 21:44:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 21:44:39 --> Hooks Class Initialized
INFO - 2018-05-11 21:44:39 --> Language Class Initialized
INFO - 2018-05-11 21:44:39 --> Input Class Initialized
INFO - 2018-05-11 21:44:39 --> Input Class Initialized
INFO - 2018-05-11 21:44:39 --> Input Class Initialized
ERROR - 2018-05-11 21:44:39 --> 404 Page Not Found: /index
DEBUG - 2018-05-11 21:44:39 --> UTF-8 Support Enabled
ERROR - 2018-05-11 21:44:39 --> 404 Page Not Found: /index
INFO - 2018-05-11 21:44:39 --> Language Class Initialized
INFO - 2018-05-11 21:44:39 --> Language Class Initialized
INFO - 2018-05-11 21:44:39 --> Language Class Initialized
INFO - 2018-05-11 21:44:39 --> Utf8 Class Initialized
ERROR - 2018-05-11 21:44:39 --> 404 Page Not Found: /index
INFO - 2018-05-11 21:44:39 --> Config Class Initialized
INFO - 2018-05-11 21:44:39 --> Config Class Initialized
ERROR - 2018-05-11 21:44:39 --> 404 Page Not Found: /index
ERROR - 2018-05-11 21:44:39 --> 404 Page Not Found: /index
INFO - 2018-05-11 21:44:39 --> URI Class Initialized
INFO - 2018-05-11 21:44:39 --> Hooks Class Initialized
INFO - 2018-05-11 21:44:39 --> Hooks Class Initialized
INFO - 2018-05-11 21:44:39 --> Config Class Initialized
INFO - 2018-05-11 21:44:39 --> Config Class Initialized
INFO - 2018-05-11 21:44:39 --> Hooks Class Initialized
INFO - 2018-05-11 21:44:39 --> Hooks Class Initialized
DEBUG - 2018-05-11 21:44:39 --> UTF-8 Support Enabled
DEBUG - 2018-05-11 21:44:39 --> UTF-8 Support Enabled
INFO - 2018-05-11 21:44:39 --> Router Class Initialized
DEBUG - 2018-05-11 21:44:39 --> UTF-8 Support Enabled
DEBUG - 2018-05-11 21:44:39 --> UTF-8 Support Enabled
INFO - 2018-05-11 21:44:39 --> Utf8 Class Initialized
INFO - 2018-05-11 21:44:39 --> Utf8 Class Initialized
INFO - 2018-05-11 21:44:39 --> Utf8 Class Initialized
INFO - 2018-05-11 21:44:39 --> Utf8 Class Initialized
INFO - 2018-05-11 21:44:39 --> Output Class Initialized
INFO - 2018-05-11 21:44:39 --> Security Class Initialized
INFO - 2018-05-11 21:44:39 --> URI Class Initialized
INFO - 2018-05-11 21:44:39 --> URI Class Initialized
INFO - 2018-05-11 21:44:39 --> URI Class Initialized
INFO - 2018-05-11 21:44:39 --> URI Class Initialized
INFO - 2018-05-11 21:44:39 --> Router Class Initialized
INFO - 2018-05-11 21:44:39 --> Router Class Initialized
DEBUG - 2018-05-11 21:44:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 21:44:39 --> Router Class Initialized
INFO - 2018-05-11 21:44:39 --> Router Class Initialized
INFO - 2018-05-11 21:44:39 --> Output Class Initialized
INFO - 2018-05-11 21:44:39 --> Output Class Initialized
INFO - 2018-05-11 21:44:39 --> Output Class Initialized
INFO - 2018-05-11 21:44:39 --> Input Class Initialized
INFO - 2018-05-11 21:44:39 --> Output Class Initialized
INFO - 2018-05-11 21:44:39 --> Security Class Initialized
INFO - 2018-05-11 21:44:39 --> Security Class Initialized
INFO - 2018-05-11 21:44:39 --> Security Class Initialized
INFO - 2018-05-11 21:44:39 --> Language Class Initialized
INFO - 2018-05-11 21:44:39 --> Security Class Initialized
DEBUG - 2018-05-11 21:44:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-11 21:44:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-11 21:44:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 21:44:39 --> Input Class Initialized
DEBUG - 2018-05-11 21:44:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-05-11 21:44:39 --> 404 Page Not Found: /index
INFO - 2018-05-11 21:44:39 --> Input Class Initialized
INFO - 2018-05-11 21:44:39 --> Language Class Initialized
INFO - 2018-05-11 21:44:39 --> Config Class Initialized
INFO - 2018-05-11 21:44:39 --> Input Class Initialized
INFO - 2018-05-11 21:44:39 --> Input Class Initialized
INFO - 2018-05-11 21:44:39 --> Language Class Initialized
INFO - 2018-05-11 21:44:39 --> Hooks Class Initialized
ERROR - 2018-05-11 21:44:39 --> 404 Page Not Found: /index
INFO - 2018-05-11 21:44:39 --> Language Class Initialized
ERROR - 2018-05-11 21:44:39 --> 404 Page Not Found: /index
INFO - 2018-05-11 21:44:39 --> Language Class Initialized
ERROR - 2018-05-11 21:44:39 --> 404 Page Not Found: /index
DEBUG - 2018-05-11 21:44:39 --> UTF-8 Support Enabled
ERROR - 2018-05-11 21:44:39 --> 404 Page Not Found: /index
INFO - 2018-05-11 21:44:39 --> Config Class Initialized
INFO - 2018-05-11 21:44:39 --> Utf8 Class Initialized
INFO - 2018-05-11 21:44:39 --> Hooks Class Initialized
INFO - 2018-05-11 21:44:39 --> Config Class Initialized
INFO - 2018-05-11 21:44:39 --> Hooks Class Initialized
DEBUG - 2018-05-11 21:44:39 --> UTF-8 Support Enabled
INFO - 2018-05-11 21:44:39 --> URI Class Initialized
INFO - 2018-05-11 21:44:39 --> Config Class Initialized
INFO - 2018-05-11 21:44:39 --> Hooks Class Initialized
DEBUG - 2018-05-11 21:44:39 --> UTF-8 Support Enabled
INFO - 2018-05-11 21:44:39 --> Utf8 Class Initialized
INFO - 2018-05-11 21:44:39 --> Utf8 Class Initialized
INFO - 2018-05-11 21:44:39 --> Router Class Initialized
INFO - 2018-05-11 21:44:39 --> URI Class Initialized
INFO - 2018-05-11 21:44:39 --> URI Class Initialized
DEBUG - 2018-05-11 21:44:39 --> UTF-8 Support Enabled
INFO - 2018-05-11 21:44:39 --> Output Class Initialized
INFO - 2018-05-11 21:44:39 --> Security Class Initialized
INFO - 2018-05-11 21:44:39 --> Utf8 Class Initialized
INFO - 2018-05-11 21:44:39 --> Router Class Initialized
INFO - 2018-05-11 21:44:39 --> Router Class Initialized
INFO - 2018-05-11 21:44:39 --> Output Class Initialized
INFO - 2018-05-11 21:44:39 --> URI Class Initialized
INFO - 2018-05-11 21:44:39 --> Output Class Initialized
DEBUG - 2018-05-11 21:44:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 21:44:40 --> Security Class Initialized
INFO - 2018-05-11 21:44:40 --> Input Class Initialized
INFO - 2018-05-11 21:44:40 --> Security Class Initialized
INFO - 2018-05-11 21:44:40 --> Router Class Initialized
INFO - 2018-05-11 21:44:40 --> Output Class Initialized
INFO - 2018-05-11 21:44:40 --> Language Class Initialized
DEBUG - 2018-05-11 21:44:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-11 21:44:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 21:44:40 --> Input Class Initialized
INFO - 2018-05-11 21:44:40 --> Input Class Initialized
ERROR - 2018-05-11 21:44:40 --> 404 Page Not Found: /index
INFO - 2018-05-11 21:44:40 --> Security Class Initialized
DEBUG - 2018-05-11 21:44:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 21:44:40 --> Language Class Initialized
INFO - 2018-05-11 21:44:40 --> Language Class Initialized
INFO - 2018-05-11 21:44:40 --> Input Class Initialized
ERROR - 2018-05-11 21:44:40 --> 404 Page Not Found: /index
ERROR - 2018-05-11 21:44:40 --> 404 Page Not Found: /index
INFO - 2018-05-11 21:44:40 --> Language Class Initialized
ERROR - 2018-05-11 21:44:40 --> 404 Page Not Found: /index
INFO - 2018-05-11 21:45:13 --> Config Class Initialized
INFO - 2018-05-11 21:45:13 --> Hooks Class Initialized
DEBUG - 2018-05-11 21:45:13 --> UTF-8 Support Enabled
INFO - 2018-05-11 21:45:13 --> Utf8 Class Initialized
INFO - 2018-05-11 21:45:13 --> URI Class Initialized
INFO - 2018-05-11 21:45:13 --> Router Class Initialized
INFO - 2018-05-11 21:45:13 --> Output Class Initialized
INFO - 2018-05-11 21:45:13 --> Security Class Initialized
DEBUG - 2018-05-11 21:45:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 21:45:13 --> Input Class Initialized
INFO - 2018-05-11 21:45:13 --> Language Class Initialized
ERROR - 2018-05-11 21:45:13 --> 404 Page Not Found: /index
INFO - 2018-05-11 21:45:13 --> Config Class Initialized
INFO - 2018-05-11 21:45:13 --> Hooks Class Initialized
DEBUG - 2018-05-11 21:45:13 --> UTF-8 Support Enabled
INFO - 2018-05-11 21:45:13 --> Utf8 Class Initialized
INFO - 2018-05-11 21:45:13 --> URI Class Initialized
INFO - 2018-05-11 21:45:13 --> Router Class Initialized
INFO - 2018-05-11 21:45:13 --> Output Class Initialized
INFO - 2018-05-11 21:45:13 --> Security Class Initialized
DEBUG - 2018-05-11 21:45:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 21:45:13 --> Input Class Initialized
INFO - 2018-05-11 21:45:13 --> Language Class Initialized
ERROR - 2018-05-11 21:45:13 --> 404 Page Not Found: /index
INFO - 2018-05-11 21:45:13 --> Config Class Initialized
INFO - 2018-05-11 21:45:13 --> Config Class Initialized
INFO - 2018-05-11 21:45:13 --> Config Class Initialized
INFO - 2018-05-11 21:45:13 --> Config Class Initialized
INFO - 2018-05-11 21:45:13 --> Hooks Class Initialized
INFO - 2018-05-11 21:45:13 --> Hooks Class Initialized
INFO - 2018-05-11 21:45:13 --> Hooks Class Initialized
INFO - 2018-05-11 21:45:13 --> Hooks Class Initialized
INFO - 2018-05-11 21:45:14 --> Config Class Initialized
INFO - 2018-05-11 21:45:14 --> Config Class Initialized
DEBUG - 2018-05-11 21:45:14 --> UTF-8 Support Enabled
DEBUG - 2018-05-11 21:45:14 --> UTF-8 Support Enabled
INFO - 2018-05-11 21:45:14 --> Hooks Class Initialized
DEBUG - 2018-05-11 21:45:14 --> UTF-8 Support Enabled
DEBUG - 2018-05-11 21:45:14 --> UTF-8 Support Enabled
INFO - 2018-05-11 21:45:14 --> Hooks Class Initialized
INFO - 2018-05-11 21:45:14 --> Utf8 Class Initialized
INFO - 2018-05-11 21:45:14 --> URI Class Initialized
INFO - 2018-05-11 21:45:14 --> Router Class Initialized
INFO - 2018-05-11 21:45:14 --> Output Class Initialized
INFO - 2018-05-11 21:45:14 --> Utf8 Class Initialized
INFO - 2018-05-11 21:45:14 --> Utf8 Class Initialized
INFO - 2018-05-11 21:45:14 --> Utf8 Class Initialized
INFO - 2018-05-11 21:45:14 --> Security Class Initialized
DEBUG - 2018-05-11 21:45:14 --> UTF-8 Support Enabled
DEBUG - 2018-05-11 21:45:14 --> UTF-8 Support Enabled
INFO - 2018-05-11 21:45:14 --> Utf8 Class Initialized
INFO - 2018-05-11 21:45:14 --> Utf8 Class Initialized
INFO - 2018-05-11 21:45:14 --> URI Class Initialized
INFO - 2018-05-11 21:45:14 --> URI Class Initialized
INFO - 2018-05-11 21:45:14 --> URI Class Initialized
DEBUG - 2018-05-11 21:45:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 21:45:14 --> URI Class Initialized
INFO - 2018-05-11 21:45:14 --> Router Class Initialized
INFO - 2018-05-11 21:45:14 --> Router Class Initialized
INFO - 2018-05-11 21:45:14 --> Input Class Initialized
INFO - 2018-05-11 21:45:14 --> URI Class Initialized
INFO - 2018-05-11 21:45:14 --> Router Class Initialized
INFO - 2018-05-11 21:45:14 --> Router Class Initialized
INFO - 2018-05-11 21:45:14 --> Output Class Initialized
INFO - 2018-05-11 21:45:14 --> Router Class Initialized
INFO - 2018-05-11 21:45:14 --> Output Class Initialized
INFO - 2018-05-11 21:45:14 --> Language Class Initialized
INFO - 2018-05-11 21:45:14 --> Output Class Initialized
INFO - 2018-05-11 21:45:14 --> Output Class Initialized
INFO - 2018-05-11 21:45:14 --> Security Class Initialized
INFO - 2018-05-11 21:45:14 --> Security Class Initialized
INFO - 2018-05-11 21:45:14 --> Output Class Initialized
DEBUG - 2018-05-11 21:45:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 21:45:14 --> Security Class Initialized
ERROR - 2018-05-11 21:45:14 --> 404 Page Not Found: /index
INFO - 2018-05-11 21:45:14 --> Security Class Initialized
DEBUG - 2018-05-11 21:45:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 21:45:14 --> Input Class Initialized
INFO - 2018-05-11 21:45:14 --> Input Class Initialized
DEBUG - 2018-05-11 21:45:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 21:45:14 --> Security Class Initialized
DEBUG - 2018-05-11 21:45:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 21:45:14 --> Language Class Initialized
INFO - 2018-05-11 21:45:14 --> Language Class Initialized
INFO - 2018-05-11 21:45:14 --> Input Class Initialized
DEBUG - 2018-05-11 21:45:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-05-11 21:45:14 --> 404 Page Not Found: /index
INFO - 2018-05-11 21:45:14 --> Input Class Initialized
ERROR - 2018-05-11 21:45:14 --> 404 Page Not Found: /index
INFO - 2018-05-11 21:45:14 --> Language Class Initialized
INFO - 2018-05-11 21:45:14 --> Input Class Initialized
INFO - 2018-05-11 21:45:14 --> Language Class Initialized
ERROR - 2018-05-11 21:45:14 --> 404 Page Not Found: /index
INFO - 2018-05-11 21:45:14 --> Config Class Initialized
INFO - 2018-05-11 21:45:14 --> Config Class Initialized
INFO - 2018-05-11 21:45:14 --> Config Class Initialized
INFO - 2018-05-11 21:45:14 --> Hooks Class Initialized
INFO - 2018-05-11 21:45:14 --> Hooks Class Initialized
INFO - 2018-05-11 21:45:14 --> Hooks Class Initialized
INFO - 2018-05-11 21:45:14 --> Language Class Initialized
ERROR - 2018-05-11 21:45:14 --> 404 Page Not Found: /index
DEBUG - 2018-05-11 21:45:14 --> UTF-8 Support Enabled
DEBUG - 2018-05-11 21:45:14 --> UTF-8 Support Enabled
DEBUG - 2018-05-11 21:45:14 --> UTF-8 Support Enabled
ERROR - 2018-05-11 21:45:14 --> 404 Page Not Found: /index
INFO - 2018-05-11 21:45:14 --> Utf8 Class Initialized
INFO - 2018-05-11 21:45:14 --> Utf8 Class Initialized
INFO - 2018-05-11 21:45:14 --> Utf8 Class Initialized
INFO - 2018-05-11 21:45:14 --> URI Class Initialized
INFO - 2018-05-11 21:45:14 --> Config Class Initialized
INFO - 2018-05-11 21:45:14 --> URI Class Initialized
INFO - 2018-05-11 21:45:14 --> Config Class Initialized
INFO - 2018-05-11 21:45:14 --> URI Class Initialized
INFO - 2018-05-11 21:45:14 --> Hooks Class Initialized
INFO - 2018-05-11 21:45:14 --> Hooks Class Initialized
INFO - 2018-05-11 21:45:14 --> Router Class Initialized
INFO - 2018-05-11 21:45:14 --> Router Class Initialized
INFO - 2018-05-11 21:45:14 --> Router Class Initialized
INFO - 2018-05-11 21:45:14 --> Output Class Initialized
DEBUG - 2018-05-11 21:45:14 --> UTF-8 Support Enabled
DEBUG - 2018-05-11 21:45:14 --> UTF-8 Support Enabled
INFO - 2018-05-11 21:45:14 --> Output Class Initialized
INFO - 2018-05-11 21:45:14 --> Utf8 Class Initialized
INFO - 2018-05-11 21:45:14 --> Security Class Initialized
INFO - 2018-05-11 21:45:14 --> Utf8 Class Initialized
INFO - 2018-05-11 21:45:14 --> Output Class Initialized
INFO - 2018-05-11 21:45:14 --> Security Class Initialized
DEBUG - 2018-05-11 21:45:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 21:45:14 --> Input Class Initialized
INFO - 2018-05-11 21:45:14 --> Language Class Initialized
ERROR - 2018-05-11 21:45:14 --> 404 Page Not Found: /index
INFO - 2018-05-11 21:45:14 --> URI Class Initialized
INFO - 2018-05-11 21:45:14 --> Config Class Initialized
INFO - 2018-05-11 21:45:14 --> URI Class Initialized
DEBUG - 2018-05-11 21:45:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 21:45:14 --> Security Class Initialized
INFO - 2018-05-11 21:45:14 --> Hooks Class Initialized
INFO - 2018-05-11 21:45:14 --> Input Class Initialized
INFO - 2018-05-11 21:45:14 --> Router Class Initialized
DEBUG - 2018-05-11 21:45:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 21:45:14 --> Router Class Initialized
INFO - 2018-05-11 21:45:14 --> Input Class Initialized
INFO - 2018-05-11 21:45:14 --> Output Class Initialized
INFO - 2018-05-11 21:45:14 --> Output Class Initialized
DEBUG - 2018-05-11 21:45:14 --> UTF-8 Support Enabled
INFO - 2018-05-11 21:45:14 --> Language Class Initialized
INFO - 2018-05-11 21:45:14 --> Security Class Initialized
INFO - 2018-05-11 21:45:14 --> Security Class Initialized
INFO - 2018-05-11 21:45:14 --> Language Class Initialized
INFO - 2018-05-11 21:45:14 --> Utf8 Class Initialized
ERROR - 2018-05-11 21:45:14 --> 404 Page Not Found: /index
INFO - 2018-05-11 21:45:14 --> URI Class Initialized
DEBUG - 2018-05-11 21:45:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-05-11 21:45:14 --> 404 Page Not Found: /index
DEBUG - 2018-05-11 21:45:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 21:45:14 --> Config Class Initialized
INFO - 2018-05-11 21:45:14 --> Hooks Class Initialized
INFO - 2018-05-11 21:45:14 --> Router Class Initialized
DEBUG - 2018-05-11 21:45:15 --> UTF-8 Support Enabled
INFO - 2018-05-11 21:45:15 --> Utf8 Class Initialized
INFO - 2018-05-11 21:45:15 --> URI Class Initialized
INFO - 2018-05-11 21:45:15 --> Input Class Initialized
INFO - 2018-05-11 21:45:15 --> Router Class Initialized
INFO - 2018-05-11 21:45:15 --> Input Class Initialized
INFO - 2018-05-11 21:45:15 --> Output Class Initialized
INFO - 2018-05-11 21:45:15 --> Config Class Initialized
INFO - 2018-05-11 21:45:15 --> Security Class Initialized
INFO - 2018-05-11 21:45:15 --> Language Class Initialized
INFO - 2018-05-11 21:45:15 --> Hooks Class Initialized
INFO - 2018-05-11 21:45:15 --> Language Class Initialized
INFO - 2018-05-11 21:45:15 --> Output Class Initialized
DEBUG - 2018-05-11 21:45:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 21:45:15 --> Input Class Initialized
INFO - 2018-05-11 21:45:15 --> Language Class Initialized
ERROR - 2018-05-11 21:45:15 --> 404 Page Not Found: /index
INFO - 2018-05-11 21:45:15 --> Security Class Initialized
DEBUG - 2018-05-11 21:45:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 21:45:15 --> Input Class Initialized
ERROR - 2018-05-11 21:45:15 --> 404 Page Not Found: /index
ERROR - 2018-05-11 21:45:15 --> 404 Page Not Found: /index
INFO - 2018-05-11 21:45:15 --> Language Class Initialized
DEBUG - 2018-05-11 21:45:15 --> UTF-8 Support Enabled
INFO - 2018-05-11 21:45:15 --> Utf8 Class Initialized
INFO - 2018-05-11 21:45:15 --> Config Class Initialized
INFO - 2018-05-11 21:45:15 --> URI Class Initialized
ERROR - 2018-05-11 21:45:15 --> 404 Page Not Found: /index
INFO - 2018-05-11 21:45:15 --> Router Class Initialized
INFO - 2018-05-11 21:45:15 --> Hooks Class Initialized
INFO - 2018-05-11 21:45:15 --> Config Class Initialized
INFO - 2018-05-11 21:45:15 --> Hooks Class Initialized
DEBUG - 2018-05-11 21:45:15 --> UTF-8 Support Enabled
INFO - 2018-05-11 21:45:15 --> Output Class Initialized
DEBUG - 2018-05-11 21:45:15 --> UTF-8 Support Enabled
INFO - 2018-05-11 21:45:15 --> Security Class Initialized
INFO - 2018-05-11 21:45:15 --> Utf8 Class Initialized
INFO - 2018-05-11 21:45:15 --> URI Class Initialized
INFO - 2018-05-11 21:45:15 --> Router Class Initialized
DEBUG - 2018-05-11 21:45:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 21:45:15 --> Output Class Initialized
INFO - 2018-05-11 21:45:15 --> Security Class Initialized
DEBUG - 2018-05-11 21:45:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 21:45:15 --> Input Class Initialized
INFO - 2018-05-11 21:45:15 --> Language Class Initialized
ERROR - 2018-05-11 21:45:15 --> 404 Page Not Found: /index
INFO - 2018-05-11 21:45:15 --> Utf8 Class Initialized
INFO - 2018-05-11 21:45:15 --> Input Class Initialized
INFO - 2018-05-11 21:45:15 --> Language Class Initialized
INFO - 2018-05-11 21:45:15 --> URI Class Initialized
ERROR - 2018-05-11 21:45:15 --> 404 Page Not Found: /index
INFO - 2018-05-11 21:45:15 --> Router Class Initialized
INFO - 2018-05-11 21:45:15 --> Output Class Initialized
INFO - 2018-05-11 21:45:15 --> Security Class Initialized
DEBUG - 2018-05-11 21:45:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 21:45:15 --> Input Class Initialized
INFO - 2018-05-11 21:45:15 --> Language Class Initialized
ERROR - 2018-05-11 21:45:15 --> 404 Page Not Found: /index
INFO - 2018-05-11 21:45:17 --> Config Class Initialized
INFO - 2018-05-11 21:45:17 --> Config Class Initialized
INFO - 2018-05-11 21:45:17 --> Config Class Initialized
INFO - 2018-05-11 21:45:17 --> Config Class Initialized
INFO - 2018-05-11 21:45:17 --> Config Class Initialized
INFO - 2018-05-11 21:45:17 --> Hooks Class Initialized
INFO - 2018-05-11 21:45:17 --> Hooks Class Initialized
INFO - 2018-05-11 21:45:17 --> Hooks Class Initialized
INFO - 2018-05-11 21:45:17 --> Hooks Class Initialized
INFO - 2018-05-11 21:45:17 --> Hooks Class Initialized
DEBUG - 2018-05-11 21:45:17 --> UTF-8 Support Enabled
DEBUG - 2018-05-11 21:45:17 --> UTF-8 Support Enabled
DEBUG - 2018-05-11 21:45:17 --> UTF-8 Support Enabled
DEBUG - 2018-05-11 21:45:17 --> UTF-8 Support Enabled
DEBUG - 2018-05-11 21:45:17 --> UTF-8 Support Enabled
INFO - 2018-05-11 21:45:17 --> Utf8 Class Initialized
INFO - 2018-05-11 21:45:17 --> URI Class Initialized
INFO - 2018-05-11 21:45:17 --> Utf8 Class Initialized
INFO - 2018-05-11 21:45:17 --> Utf8 Class Initialized
INFO - 2018-05-11 21:45:17 --> Router Class Initialized
INFO - 2018-05-11 21:45:17 --> Utf8 Class Initialized
INFO - 2018-05-11 21:45:17 --> Utf8 Class Initialized
INFO - 2018-05-11 21:45:17 --> URI Class Initialized
INFO - 2018-05-11 21:45:17 --> Router Class Initialized
INFO - 2018-05-11 21:45:17 --> URI Class Initialized
INFO - 2018-05-11 21:45:17 --> Output Class Initialized
INFO - 2018-05-11 21:45:17 --> URI Class Initialized
INFO - 2018-05-11 21:45:17 --> URI Class Initialized
INFO - 2018-05-11 21:45:17 --> Output Class Initialized
INFO - 2018-05-11 21:45:17 --> Router Class Initialized
INFO - 2018-05-11 21:45:17 --> Router Class Initialized
INFO - 2018-05-11 21:45:17 --> Security Class Initialized
INFO - 2018-05-11 21:45:17 --> Security Class Initialized
INFO - 2018-05-11 21:45:17 --> Router Class Initialized
INFO - 2018-05-11 21:45:17 --> Output Class Initialized
INFO - 2018-05-11 21:45:17 --> Output Class Initialized
DEBUG - 2018-05-11 21:45:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-11 21:45:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 21:45:17 --> Output Class Initialized
INFO - 2018-05-11 21:45:17 --> Security Class Initialized
INFO - 2018-05-11 21:45:17 --> Security Class Initialized
DEBUG - 2018-05-11 21:45:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 21:45:17 --> Input Class Initialized
INFO - 2018-05-11 21:45:17 --> Language Class Initialized
ERROR - 2018-05-11 21:45:17 --> 404 Page Not Found: /index
DEBUG - 2018-05-11 21:45:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 21:45:18 --> Input Class Initialized
INFO - 2018-05-11 21:45:18 --> Security Class Initialized
INFO - 2018-05-11 21:45:18 --> Input Class Initialized
INFO - 2018-05-11 21:45:18 --> Config Class Initialized
INFO - 2018-05-11 21:45:18 --> Hooks Class Initialized
INFO - 2018-05-11 21:45:18 --> Input Class Initialized
DEBUG - 2018-05-11 21:45:18 --> UTF-8 Support Enabled
INFO - 2018-05-11 21:45:18 --> Utf8 Class Initialized
INFO - 2018-05-11 21:45:18 --> URI Class Initialized
INFO - 2018-05-11 21:45:18 --> Router Class Initialized
INFO - 2018-05-11 21:45:18 --> Output Class Initialized
INFO - 2018-05-11 21:45:18 --> Language Class Initialized
DEBUG - 2018-05-11 21:45:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 21:45:18 --> Language Class Initialized
INFO - 2018-05-11 21:45:18 --> Language Class Initialized
INFO - 2018-05-11 21:45:18 --> Security Class Initialized
ERROR - 2018-05-11 21:45:18 --> 404 Page Not Found: /index
INFO - 2018-05-11 21:45:18 --> Input Class Initialized
ERROR - 2018-05-11 21:45:18 --> 404 Page Not Found: /index
ERROR - 2018-05-11 21:45:18 --> 404 Page Not Found: /index
INFO - 2018-05-11 21:45:18 --> Language Class Initialized
DEBUG - 2018-05-11 21:45:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-05-11 21:45:18 --> 404 Page Not Found: /index
INFO - 2018-05-11 21:45:18 --> Config Class Initialized
INFO - 2018-05-11 21:45:18 --> Input Class Initialized
INFO - 2018-05-11 21:45:18 --> Hooks Class Initialized
DEBUG - 2018-05-11 21:45:18 --> UTF-8 Support Enabled
INFO - 2018-05-11 21:45:18 --> Config Class Initialized
INFO - 2018-05-11 21:45:18 --> Config Class Initialized
INFO - 2018-05-11 21:45:18 --> Hooks Class Initialized
INFO - 2018-05-11 21:45:18 --> Hooks Class Initialized
DEBUG - 2018-05-11 21:45:18 --> UTF-8 Support Enabled
INFO - 2018-05-11 21:45:18 --> Utf8 Class Initialized
INFO - 2018-05-11 21:45:18 --> Language Class Initialized
INFO - 2018-05-11 21:45:18 --> Utf8 Class Initialized
DEBUG - 2018-05-11 21:45:18 --> UTF-8 Support Enabled
ERROR - 2018-05-11 21:45:18 --> 404 Page Not Found: /index
INFO - 2018-05-11 21:45:18 --> URI Class Initialized
INFO - 2018-05-11 21:45:18 --> URI Class Initialized
INFO - 2018-05-11 21:45:18 --> Utf8 Class Initialized
INFO - 2018-05-11 21:45:18 --> Router Class Initialized
INFO - 2018-05-11 21:45:18 --> Router Class Initialized
INFO - 2018-05-11 21:45:18 --> Config Class Initialized
INFO - 2018-05-11 21:45:18 --> Hooks Class Initialized
INFO - 2018-05-11 21:45:18 --> URI Class Initialized
DEBUG - 2018-05-11 21:45:18 --> UTF-8 Support Enabled
INFO - 2018-05-11 21:45:18 --> Output Class Initialized
INFO - 2018-05-11 21:45:18 --> Output Class Initialized
INFO - 2018-05-11 21:45:18 --> Router Class Initialized
INFO - 2018-05-11 21:45:18 --> Utf8 Class Initialized
INFO - 2018-05-11 21:45:18 --> Security Class Initialized
INFO - 2018-05-11 21:45:18 --> Security Class Initialized
INFO - 2018-05-11 21:45:18 --> Output Class Initialized
INFO - 2018-05-11 21:45:18 --> URI Class Initialized
INFO - 2018-05-11 21:45:18 --> Security Class Initialized
INFO - 2018-05-11 21:45:18 --> Router Class Initialized
DEBUG - 2018-05-11 21:45:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-11 21:45:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-11 21:45:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 21:45:18 --> Output Class Initialized
INFO - 2018-05-11 21:45:18 --> Security Class Initialized
DEBUG - 2018-05-11 21:45:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 21:45:18 --> Input Class Initialized
INFO - 2018-05-11 21:45:18 --> Input Class Initialized
INFO - 2018-05-11 21:45:18 --> Input Class Initialized
INFO - 2018-05-11 21:45:18 --> Input Class Initialized
INFO - 2018-05-11 21:45:18 --> Language Class Initialized
INFO - 2018-05-11 21:45:18 --> Language Class Initialized
INFO - 2018-05-11 21:45:18 --> Language Class Initialized
INFO - 2018-05-11 21:45:18 --> Language Class Initialized
ERROR - 2018-05-11 21:45:18 --> 404 Page Not Found: /index
ERROR - 2018-05-11 21:45:18 --> 404 Page Not Found: /index
ERROR - 2018-05-11 21:45:18 --> 404 Page Not Found: /index
ERROR - 2018-05-11 21:45:18 --> 404 Page Not Found: /index
INFO - 2018-05-11 21:45:18 --> Config Class Initialized
INFO - 2018-05-11 21:45:18 --> Config Class Initialized
INFO - 2018-05-11 21:45:18 --> Config Class Initialized
INFO - 2018-05-11 21:45:18 --> Hooks Class Initialized
INFO - 2018-05-11 21:45:18 --> Hooks Class Initialized
INFO - 2018-05-11 21:45:18 --> Hooks Class Initialized
DEBUG - 2018-05-11 21:45:18 --> UTF-8 Support Enabled
DEBUG - 2018-05-11 21:45:18 --> UTF-8 Support Enabled
DEBUG - 2018-05-11 21:45:18 --> UTF-8 Support Enabled
INFO - 2018-05-11 21:45:18 --> Utf8 Class Initialized
INFO - 2018-05-11 21:45:18 --> Utf8 Class Initialized
INFO - 2018-05-11 21:45:18 --> URI Class Initialized
INFO - 2018-05-11 21:45:18 --> Utf8 Class Initialized
INFO - 2018-05-11 21:45:18 --> URI Class Initialized
INFO - 2018-05-11 21:45:18 --> Router Class Initialized
INFO - 2018-05-11 21:45:18 --> URI Class Initialized
INFO - 2018-05-11 21:45:18 --> Router Class Initialized
INFO - 2018-05-11 21:45:18 --> Output Class Initialized
INFO - 2018-05-11 21:45:18 --> Router Class Initialized
INFO - 2018-05-11 21:45:18 --> Output Class Initialized
INFO - 2018-05-11 21:45:18 --> Output Class Initialized
INFO - 2018-05-11 21:45:18 --> Security Class Initialized
INFO - 2018-05-11 21:45:18 --> Security Class Initialized
DEBUG - 2018-05-11 21:45:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-11 21:45:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 21:45:18 --> Security Class Initialized
INFO - 2018-05-11 21:45:18 --> Input Class Initialized
DEBUG - 2018-05-11 21:45:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 21:45:18 --> Input Class Initialized
INFO - 2018-05-11 21:45:19 --> Input Class Initialized
INFO - 2018-05-11 21:45:19 --> Language Class Initialized
INFO - 2018-05-11 21:45:19 --> Language Class Initialized
ERROR - 2018-05-11 21:45:19 --> 404 Page Not Found: /index
INFO - 2018-05-11 21:45:19 --> Language Class Initialized
ERROR - 2018-05-11 21:45:19 --> 404 Page Not Found: /index
ERROR - 2018-05-11 21:45:19 --> 404 Page Not Found: /index
INFO - 2018-05-11 21:45:28 --> Config Class Initialized
INFO - 2018-05-11 21:45:28 --> Hooks Class Initialized
DEBUG - 2018-05-11 21:45:28 --> UTF-8 Support Enabled
INFO - 2018-05-11 21:45:28 --> Utf8 Class Initialized
INFO - 2018-05-11 21:45:28 --> URI Class Initialized
INFO - 2018-05-11 21:45:28 --> Router Class Initialized
INFO - 2018-05-11 21:45:28 --> Output Class Initialized
INFO - 2018-05-11 21:45:28 --> Security Class Initialized
DEBUG - 2018-05-11 21:45:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 21:45:28 --> Input Class Initialized
INFO - 2018-05-11 21:45:28 --> Language Class Initialized
ERROR - 2018-05-11 21:45:28 --> 404 Page Not Found: /index
INFO - 2018-05-11 21:45:29 --> Config Class Initialized
INFO - 2018-05-11 21:45:29 --> Config Class Initialized
INFO - 2018-05-11 21:45:29 --> Config Class Initialized
INFO - 2018-05-11 21:45:29 --> Config Class Initialized
INFO - 2018-05-11 21:45:29 --> Config Class Initialized
INFO - 2018-05-11 21:45:29 --> Config Class Initialized
INFO - 2018-05-11 21:45:29 --> Hooks Class Initialized
INFO - 2018-05-11 21:45:29 --> Hooks Class Initialized
INFO - 2018-05-11 21:45:29 --> Hooks Class Initialized
INFO - 2018-05-11 21:45:29 --> Hooks Class Initialized
INFO - 2018-05-11 21:45:29 --> Hooks Class Initialized
INFO - 2018-05-11 21:45:29 --> Hooks Class Initialized
DEBUG - 2018-05-11 21:45:29 --> UTF-8 Support Enabled
DEBUG - 2018-05-11 21:45:29 --> UTF-8 Support Enabled
DEBUG - 2018-05-11 21:45:29 --> UTF-8 Support Enabled
DEBUG - 2018-05-11 21:45:29 --> UTF-8 Support Enabled
DEBUG - 2018-05-11 21:45:29 --> UTF-8 Support Enabled
DEBUG - 2018-05-11 21:45:29 --> UTF-8 Support Enabled
INFO - 2018-05-11 21:45:29 --> Utf8 Class Initialized
INFO - 2018-05-11 21:45:29 --> Utf8 Class Initialized
INFO - 2018-05-11 21:45:29 --> Utf8 Class Initialized
INFO - 2018-05-11 21:45:29 --> Utf8 Class Initialized
INFO - 2018-05-11 21:45:29 --> Utf8 Class Initialized
INFO - 2018-05-11 21:45:29 --> Utf8 Class Initialized
INFO - 2018-05-11 21:45:29 --> URI Class Initialized
INFO - 2018-05-11 21:45:29 --> Router Class Initialized
INFO - 2018-05-11 21:45:29 --> Output Class Initialized
INFO - 2018-05-11 21:45:29 --> Security Class Initialized
INFO - 2018-05-11 21:45:29 --> URI Class Initialized
INFO - 2018-05-11 21:45:29 --> URI Class Initialized
INFO - 2018-05-11 21:45:29 --> URI Class Initialized
INFO - 2018-05-11 21:45:29 --> URI Class Initialized
INFO - 2018-05-11 21:45:29 --> URI Class Initialized
DEBUG - 2018-05-11 21:45:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 21:45:29 --> Router Class Initialized
INFO - 2018-05-11 21:45:29 --> Output Class Initialized
INFO - 2018-05-11 21:45:29 --> Security Class Initialized
INFO - 2018-05-11 21:45:29 --> Router Class Initialized
INFO - 2018-05-11 21:45:29 --> Router Class Initialized
INFO - 2018-05-11 21:45:29 --> Router Class Initialized
INFO - 2018-05-11 21:45:29 --> Router Class Initialized
INFO - 2018-05-11 21:45:29 --> Input Class Initialized
DEBUG - 2018-05-11 21:45:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 21:45:29 --> Language Class Initialized
INFO - 2018-05-11 21:45:29 --> Output Class Initialized
INFO - 2018-05-11 21:45:29 --> Output Class Initialized
INFO - 2018-05-11 21:45:29 --> Output Class Initialized
INFO - 2018-05-11 21:45:29 --> Input Class Initialized
INFO - 2018-05-11 21:45:29 --> Output Class Initialized
INFO - 2018-05-11 21:45:29 --> Security Class Initialized
ERROR - 2018-05-11 21:45:29 --> 404 Page Not Found: /index
INFO - 2018-05-11 21:45:29 --> Security Class Initialized
INFO - 2018-05-11 21:45:29 --> Language Class Initialized
INFO - 2018-05-11 21:45:29 --> Security Class Initialized
INFO - 2018-05-11 21:45:29 --> Security Class Initialized
DEBUG - 2018-05-11 21:45:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 21:45:29 --> Input Class Initialized
DEBUG - 2018-05-11 21:45:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 21:45:29 --> Language Class Initialized
INFO - 2018-05-11 21:45:29 --> Input Class Initialized
DEBUG - 2018-05-11 21:45:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-05-11 21:45:29 --> 404 Page Not Found: /index
DEBUG - 2018-05-11 21:45:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-05-11 21:45:29 --> 404 Page Not Found: /index
INFO - 2018-05-11 21:45:29 --> Language Class Initialized
INFO - 2018-05-11 21:45:29 --> Input Class Initialized
ERROR - 2018-05-11 21:45:29 --> 404 Page Not Found: /index
INFO - 2018-05-11 21:45:29 --> Input Class Initialized
INFO - 2018-05-11 21:45:29 --> Config Class Initialized
INFO - 2018-05-11 21:45:29 --> Hooks Class Initialized
INFO - 2018-05-11 21:45:29 --> Language Class Initialized
INFO - 2018-05-11 21:45:30 --> Language Class Initialized
INFO - 2018-05-11 21:45:30 --> Config Class Initialized
DEBUG - 2018-05-11 21:45:30 --> UTF-8 Support Enabled
INFO - 2018-05-11 21:45:30 --> Config Class Initialized
ERROR - 2018-05-11 21:45:30 --> 404 Page Not Found: /index
ERROR - 2018-05-11 21:45:30 --> 404 Page Not Found: /index
INFO - 2018-05-11 21:45:30 --> Hooks Class Initialized
INFO - 2018-05-11 21:45:30 --> Utf8 Class Initialized
INFO - 2018-05-11 21:45:30 --> Hooks Class Initialized
INFO - 2018-05-11 21:45:30 --> Config Class Initialized
INFO - 2018-05-11 21:45:30 --> Config Class Initialized
INFO - 2018-05-11 21:45:30 --> Hooks Class Initialized
DEBUG - 2018-05-11 21:45:30 --> UTF-8 Support Enabled
INFO - 2018-05-11 21:45:30 --> Hooks Class Initialized
INFO - 2018-05-11 21:45:30 --> URI Class Initialized
INFO - 2018-05-11 21:45:30 --> Utf8 Class Initialized
DEBUG - 2018-05-11 21:45:30 --> UTF-8 Support Enabled
DEBUG - 2018-05-11 21:45:30 --> UTF-8 Support Enabled
INFO - 2018-05-11 21:45:30 --> Utf8 Class Initialized
DEBUG - 2018-05-11 21:45:30 --> UTF-8 Support Enabled
INFO - 2018-05-11 21:45:30 --> Utf8 Class Initialized
INFO - 2018-05-11 21:45:30 --> URI Class Initialized
INFO - 2018-05-11 21:45:30 --> Router Class Initialized
INFO - 2018-05-11 21:45:30 --> Utf8 Class Initialized
INFO - 2018-05-11 21:45:30 --> Output Class Initialized
INFO - 2018-05-11 21:45:30 --> Router Class Initialized
INFO - 2018-05-11 21:45:30 --> URI Class Initialized
INFO - 2018-05-11 21:45:30 --> URI Class Initialized
INFO - 2018-05-11 21:45:30 --> Output Class Initialized
INFO - 2018-05-11 21:45:30 --> Router Class Initialized
INFO - 2018-05-11 21:45:30 --> Security Class Initialized
INFO - 2018-05-11 21:45:30 --> URI Class Initialized
INFO - 2018-05-11 21:45:30 --> Router Class Initialized
DEBUG - 2018-05-11 21:45:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 21:45:30 --> Output Class Initialized
INFO - 2018-05-11 21:45:30 --> Security Class Initialized
INFO - 2018-05-11 21:45:30 --> Router Class Initialized
INFO - 2018-05-11 21:45:30 --> Output Class Initialized
INFO - 2018-05-11 21:45:30 --> Input Class Initialized
DEBUG - 2018-05-11 21:45:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 21:45:30 --> Security Class Initialized
INFO - 2018-05-11 21:45:30 --> Output Class Initialized
INFO - 2018-05-11 21:45:30 --> Security Class Initialized
INFO - 2018-05-11 21:45:30 --> Language Class Initialized
DEBUG - 2018-05-11 21:45:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-11 21:45:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 21:45:30 --> Security Class Initialized
INFO - 2018-05-11 21:45:30 --> Input Class Initialized
ERROR - 2018-05-11 21:45:30 --> 404 Page Not Found: /index
INFO - 2018-05-11 21:45:30 --> Input Class Initialized
INFO - 2018-05-11 21:45:30 --> Language Class Initialized
ERROR - 2018-05-11 21:45:30 --> 404 Page Not Found: /index
INFO - 2018-05-11 21:45:30 --> Input Class Initialized
INFO - 2018-05-11 21:45:30 --> Config Class Initialized
INFO - 2018-05-11 21:45:30 --> Language Class Initialized
DEBUG - 2018-05-11 21:45:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 21:45:30 --> Language Class Initialized
INFO - 2018-05-11 21:45:30 --> Hooks Class Initialized
INFO - 2018-05-11 21:45:30 --> Input Class Initialized
ERROR - 2018-05-11 21:45:30 --> 404 Page Not Found: /index
INFO - 2018-05-11 21:45:30 --> Language Class Initialized
DEBUG - 2018-05-11 21:45:30 --> UTF-8 Support Enabled
ERROR - 2018-05-11 21:45:30 --> 404 Page Not Found: /index
INFO - 2018-05-11 21:45:30 --> Utf8 Class Initialized
ERROR - 2018-05-11 21:45:30 --> 404 Page Not Found: /index
INFO - 2018-05-11 21:45:30 --> Config Class Initialized
INFO - 2018-05-11 21:45:30 --> Hooks Class Initialized
INFO - 2018-05-11 21:45:30 --> URI Class Initialized
DEBUG - 2018-05-11 21:45:30 --> UTF-8 Support Enabled
INFO - 2018-05-11 21:45:30 --> Config Class Initialized
INFO - 2018-05-11 21:45:30 --> Config Class Initialized
INFO - 2018-05-11 21:45:30 --> Config Class Initialized
INFO - 2018-05-11 21:45:30 --> Hooks Class Initialized
INFO - 2018-05-11 21:45:30 --> Hooks Class Initialized
INFO - 2018-05-11 21:45:30 --> Hooks Class Initialized
INFO - 2018-05-11 21:45:30 --> Utf8 Class Initialized
INFO - 2018-05-11 21:45:30 --> Router Class Initialized
DEBUG - 2018-05-11 21:45:30 --> UTF-8 Support Enabled
DEBUG - 2018-05-11 21:45:30 --> UTF-8 Support Enabled
DEBUG - 2018-05-11 21:45:30 --> UTF-8 Support Enabled
INFO - 2018-05-11 21:45:30 --> URI Class Initialized
INFO - 2018-05-11 21:45:30 --> Output Class Initialized
INFO - 2018-05-11 21:45:30 --> Utf8 Class Initialized
INFO - 2018-05-11 21:45:30 --> Utf8 Class Initialized
INFO - 2018-05-11 21:45:30 --> Security Class Initialized
INFO - 2018-05-11 21:45:30 --> Router Class Initialized
INFO - 2018-05-11 21:45:30 --> Utf8 Class Initialized
INFO - 2018-05-11 21:45:30 --> URI Class Initialized
INFO - 2018-05-11 21:45:30 --> URI Class Initialized
INFO - 2018-05-11 21:45:30 --> URI Class Initialized
INFO - 2018-05-11 21:45:30 --> Output Class Initialized
DEBUG - 2018-05-11 21:45:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 21:45:30 --> Router Class Initialized
INFO - 2018-05-11 21:45:30 --> Router Class Initialized
INFO - 2018-05-11 21:45:30 --> Input Class Initialized
INFO - 2018-05-11 21:45:30 --> Security Class Initialized
INFO - 2018-05-11 21:45:30 --> Router Class Initialized
INFO - 2018-05-11 21:45:30 --> Language Class Initialized
INFO - 2018-05-11 21:45:30 --> Output Class Initialized
DEBUG - 2018-05-11 21:45:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 21:45:30 --> Output Class Initialized
INFO - 2018-05-11 21:45:30 --> Output Class Initialized
INFO - 2018-05-11 21:45:30 --> Input Class Initialized
INFO - 2018-05-11 21:45:30 --> Security Class Initialized
INFO - 2018-05-11 21:45:30 --> Security Class Initialized
INFO - 2018-05-11 21:45:30 --> Security Class Initialized
ERROR - 2018-05-11 21:45:30 --> 404 Page Not Found: /index
DEBUG - 2018-05-11 21:45:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 21:45:30 --> Language Class Initialized
DEBUG - 2018-05-11 21:45:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-11 21:45:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 21:45:30 --> Input Class Initialized
ERROR - 2018-05-11 21:45:30 --> 404 Page Not Found: /index
INFO - 2018-05-11 21:45:30 --> Input Class Initialized
INFO - 2018-05-11 21:45:30 --> Input Class Initialized
INFO - 2018-05-11 21:45:30 --> Language Class Initialized
ERROR - 2018-05-11 21:45:30 --> 404 Page Not Found: /index
INFO - 2018-05-11 21:45:30 --> Language Class Initialized
INFO - 2018-05-11 21:45:30 --> Language Class Initialized
ERROR - 2018-05-11 21:45:30 --> 404 Page Not Found: /index
ERROR - 2018-05-11 21:45:30 --> 404 Page Not Found: /index
INFO - 2018-05-11 21:47:52 --> Config Class Initialized
INFO - 2018-05-11 21:47:52 --> Hooks Class Initialized
DEBUG - 2018-05-11 21:47:52 --> UTF-8 Support Enabled
INFO - 2018-05-11 21:47:52 --> Utf8 Class Initialized
INFO - 2018-05-11 21:47:52 --> URI Class Initialized
INFO - 2018-05-11 21:47:52 --> Router Class Initialized
INFO - 2018-05-11 21:47:52 --> Output Class Initialized
INFO - 2018-05-11 21:47:52 --> Security Class Initialized
DEBUG - 2018-05-11 21:47:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 21:47:52 --> Input Class Initialized
INFO - 2018-05-11 21:47:52 --> Language Class Initialized
ERROR - 2018-05-11 21:47:52 --> 404 Page Not Found: /index
INFO - 2018-05-11 21:48:00 --> Config Class Initialized
INFO - 2018-05-11 21:48:00 --> Hooks Class Initialized
DEBUG - 2018-05-11 21:48:00 --> UTF-8 Support Enabled
INFO - 2018-05-11 21:48:00 --> Utf8 Class Initialized
INFO - 2018-05-11 21:48:00 --> URI Class Initialized
INFO - 2018-05-11 21:48:00 --> Router Class Initialized
INFO - 2018-05-11 21:48:00 --> Output Class Initialized
INFO - 2018-05-11 21:48:00 --> Security Class Initialized
DEBUG - 2018-05-11 21:48:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 21:48:00 --> Input Class Initialized
INFO - 2018-05-11 21:48:00 --> Language Class Initialized
INFO - 2018-05-11 21:48:00 --> Language Class Initialized
INFO - 2018-05-11 21:48:00 --> Config Class Initialized
INFO - 2018-05-11 21:48:00 --> Loader Class Initialized
DEBUG - 2018-05-11 21:48:00 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-11 21:48:00 --> Helper loaded: url_helper
INFO - 2018-05-11 21:48:00 --> Helper loaded: form_helper
INFO - 2018-05-11 21:48:00 --> Helper loaded: date_helper
INFO - 2018-05-11 21:48:00 --> Helper loaded: util_helper
INFO - 2018-05-11 21:48:00 --> Helper loaded: text_helper
INFO - 2018-05-11 21:48:00 --> Helper loaded: string_helper
INFO - 2018-05-11 21:48:00 --> Database Driver Class Initialized
DEBUG - 2018-05-11 21:48:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-11 21:48:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-11 21:48:00 --> Email Class Initialized
INFO - 2018-05-11 21:48:00 --> Controller Class Initialized
DEBUG - 2018-05-11 21:48:01 --> Login MX_Controller Initialized
INFO - 2018-05-11 21:48:01 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-11 21:48:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-11 21:48:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-11 21:48:01 --> 4 Loggedout
INFO - 2018-05-11 21:48:01 --> Config Class Initialized
INFO - 2018-05-11 21:48:01 --> Hooks Class Initialized
DEBUG - 2018-05-11 21:48:01 --> UTF-8 Support Enabled
INFO - 2018-05-11 21:48:01 --> Utf8 Class Initialized
INFO - 2018-05-11 21:48:01 --> URI Class Initialized
INFO - 2018-05-11 21:48:01 --> Router Class Initialized
INFO - 2018-05-11 21:48:01 --> Output Class Initialized
INFO - 2018-05-11 21:48:01 --> Security Class Initialized
DEBUG - 2018-05-11 21:48:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 21:48:01 --> Input Class Initialized
INFO - 2018-05-11 21:48:01 --> Language Class Initialized
INFO - 2018-05-11 21:48:01 --> Language Class Initialized
INFO - 2018-05-11 21:48:01 --> Config Class Initialized
INFO - 2018-05-11 21:48:01 --> Loader Class Initialized
DEBUG - 2018-05-11 21:48:01 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-11 21:48:01 --> Helper loaded: url_helper
INFO - 2018-05-11 21:48:01 --> Helper loaded: form_helper
INFO - 2018-05-11 21:48:01 --> Helper loaded: date_helper
INFO - 2018-05-11 21:48:01 --> Helper loaded: util_helper
INFO - 2018-05-11 21:48:01 --> Helper loaded: text_helper
INFO - 2018-05-11 21:48:01 --> Helper loaded: string_helper
INFO - 2018-05-11 21:48:01 --> Database Driver Class Initialized
DEBUG - 2018-05-11 21:48:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-11 21:48:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-11 21:48:01 --> Email Class Initialized
INFO - 2018-05-11 21:48:01 --> Controller Class Initialized
DEBUG - 2018-05-11 21:48:01 --> Home MX_Controller Initialized
DEBUG - 2018-05-11 21:48:01 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-11 21:48:01 --> Login MX_Controller Initialized
INFO - 2018-05-11 21:48:01 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-11 21:48:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-11 21:48:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-11 21:48:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/login.php
INFO - 2018-05-11 21:48:04 --> Config Class Initialized
INFO - 2018-05-11 21:48:04 --> Hooks Class Initialized
DEBUG - 2018-05-11 21:48:04 --> UTF-8 Support Enabled
INFO - 2018-05-11 21:48:04 --> Utf8 Class Initialized
INFO - 2018-05-11 21:48:04 --> URI Class Initialized
INFO - 2018-05-11 21:48:04 --> Router Class Initialized
INFO - 2018-05-11 21:48:04 --> Output Class Initialized
INFO - 2018-05-11 21:48:04 --> Security Class Initialized
DEBUG - 2018-05-11 21:48:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 21:48:04 --> Input Class Initialized
INFO - 2018-05-11 21:48:04 --> Language Class Initialized
INFO - 2018-05-11 21:48:04 --> Language Class Initialized
INFO - 2018-05-11 21:48:04 --> Config Class Initialized
INFO - 2018-05-11 21:48:04 --> Loader Class Initialized
DEBUG - 2018-05-11 21:48:04 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-11 21:48:04 --> Helper loaded: url_helper
INFO - 2018-05-11 21:48:04 --> Helper loaded: form_helper
INFO - 2018-05-11 21:48:04 --> Helper loaded: date_helper
INFO - 2018-05-11 21:48:04 --> Helper loaded: util_helper
INFO - 2018-05-11 21:48:04 --> Helper loaded: text_helper
INFO - 2018-05-11 21:48:04 --> Helper loaded: string_helper
INFO - 2018-05-11 21:48:04 --> Database Driver Class Initialized
DEBUG - 2018-05-11 21:48:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-11 21:48:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-11 21:48:04 --> Email Class Initialized
INFO - 2018-05-11 21:48:04 --> Controller Class Initialized
DEBUG - 2018-05-11 21:48:04 --> Login MX_Controller Initialized
INFO - 2018-05-11 21:48:04 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-11 21:48:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-11 21:48:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-11 21:48:04 --> Email starts for gopipanguluri123@gmail.com fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-05-11 21:48:04 --> User session created for 4
INFO - 2018-05-11 21:48:04 --> Login status gopipanguluri123@gmail.com - success
INFO - 2018-05-11 21:48:04 --> Final output sent to browser
DEBUG - 2018-05-11 21:48:05 --> Total execution time: 0.5529
INFO - 2018-05-11 21:48:05 --> Config Class Initialized
INFO - 2018-05-11 21:48:05 --> Hooks Class Initialized
DEBUG - 2018-05-11 21:48:05 --> UTF-8 Support Enabled
INFO - 2018-05-11 21:48:05 --> Utf8 Class Initialized
INFO - 2018-05-11 21:48:05 --> URI Class Initialized
INFO - 2018-05-11 21:48:05 --> Router Class Initialized
INFO - 2018-05-11 21:48:05 --> Output Class Initialized
INFO - 2018-05-11 21:48:05 --> Security Class Initialized
DEBUG - 2018-05-11 21:48:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 21:48:05 --> Input Class Initialized
INFO - 2018-05-11 21:48:05 --> Language Class Initialized
INFO - 2018-05-11 21:48:05 --> Language Class Initialized
INFO - 2018-05-11 21:48:05 --> Config Class Initialized
INFO - 2018-05-11 21:48:05 --> Loader Class Initialized
DEBUG - 2018-05-11 21:48:05 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-11 21:48:05 --> Helper loaded: url_helper
INFO - 2018-05-11 21:48:05 --> Helper loaded: form_helper
INFO - 2018-05-11 21:48:05 --> Helper loaded: date_helper
INFO - 2018-05-11 21:48:05 --> Helper loaded: util_helper
INFO - 2018-05-11 21:48:05 --> Helper loaded: text_helper
INFO - 2018-05-11 21:48:05 --> Helper loaded: string_helper
INFO - 2018-05-11 21:48:05 --> Database Driver Class Initialized
DEBUG - 2018-05-11 21:48:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-11 21:48:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-11 21:48:05 --> Email Class Initialized
INFO - 2018-05-11 21:48:05 --> Controller Class Initialized
DEBUG - 2018-05-11 21:48:05 --> Home MX_Controller Initialized
DEBUG - 2018-05-11 21:48:05 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-11 21:48:05 --> Login MX_Controller Initialized
INFO - 2018-05-11 21:48:05 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-11 21:48:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-11 21:48:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-11 21:48:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-05-11 21:48:05 --> Final output sent to browser
DEBUG - 2018-05-11 21:48:05 --> Total execution time: 0.5220
INFO - 2018-05-11 21:48:05 --> Config Class Initialized
INFO - 2018-05-11 21:48:05 --> Hooks Class Initialized
DEBUG - 2018-05-11 21:48:05 --> UTF-8 Support Enabled
INFO - 2018-05-11 21:48:05 --> Utf8 Class Initialized
INFO - 2018-05-11 21:48:05 --> URI Class Initialized
INFO - 2018-05-11 21:48:05 --> Router Class Initialized
INFO - 2018-05-11 21:48:05 --> Output Class Initialized
INFO - 2018-05-11 21:48:05 --> Security Class Initialized
DEBUG - 2018-05-11 21:48:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 21:48:05 --> Input Class Initialized
INFO - 2018-05-11 21:48:05 --> Language Class Initialized
ERROR - 2018-05-11 21:48:05 --> 404 Page Not Found: /index
INFO - 2018-05-11 21:48:06 --> Config Class Initialized
INFO - 2018-05-11 21:48:06 --> Hooks Class Initialized
INFO - 2018-05-11 21:48:06 --> Config Class Initialized
INFO - 2018-05-11 21:48:06 --> Config Class Initialized
INFO - 2018-05-11 21:48:06 --> Hooks Class Initialized
INFO - 2018-05-11 21:48:06 --> Hooks Class Initialized
DEBUG - 2018-05-11 21:48:06 --> UTF-8 Support Enabled
INFO - 2018-05-11 21:48:06 --> Config Class Initialized
INFO - 2018-05-11 21:48:06 --> Config Class Initialized
INFO - 2018-05-11 21:48:06 --> Config Class Initialized
INFO - 2018-05-11 21:48:06 --> Hooks Class Initialized
DEBUG - 2018-05-11 21:48:06 --> UTF-8 Support Enabled
DEBUG - 2018-05-11 21:48:06 --> UTF-8 Support Enabled
INFO - 2018-05-11 21:48:06 --> Utf8 Class Initialized
INFO - 2018-05-11 21:48:06 --> Hooks Class Initialized
INFO - 2018-05-11 21:48:06 --> Hooks Class Initialized
INFO - 2018-05-11 21:48:06 --> Utf8 Class Initialized
DEBUG - 2018-05-11 21:48:06 --> UTF-8 Support Enabled
DEBUG - 2018-05-11 21:48:06 --> UTF-8 Support Enabled
DEBUG - 2018-05-11 21:48:06 --> UTF-8 Support Enabled
INFO - 2018-05-11 21:48:06 --> Utf8 Class Initialized
INFO - 2018-05-11 21:48:06 --> URI Class Initialized
INFO - 2018-05-11 21:48:06 --> URI Class Initialized
INFO - 2018-05-11 21:48:06 --> Utf8 Class Initialized
INFO - 2018-05-11 21:48:06 --> Router Class Initialized
INFO - 2018-05-11 21:48:06 --> Utf8 Class Initialized
INFO - 2018-05-11 21:48:06 --> URI Class Initialized
INFO - 2018-05-11 21:48:06 --> Router Class Initialized
INFO - 2018-05-11 21:48:06 --> Output Class Initialized
INFO - 2018-05-11 21:48:06 --> Output Class Initialized
INFO - 2018-05-11 21:48:06 --> Router Class Initialized
INFO - 2018-05-11 21:48:06 --> URI Class Initialized
INFO - 2018-05-11 21:48:06 --> Utf8 Class Initialized
INFO - 2018-05-11 21:48:06 --> URI Class Initialized
INFO - 2018-05-11 21:48:06 --> Security Class Initialized
INFO - 2018-05-11 21:48:06 --> Output Class Initialized
INFO - 2018-05-11 21:48:06 --> Security Class Initialized
INFO - 2018-05-11 21:48:06 --> Router Class Initialized
INFO - 2018-05-11 21:48:06 --> Router Class Initialized
INFO - 2018-05-11 21:48:06 --> URI Class Initialized
INFO - 2018-05-11 21:48:06 --> Security Class Initialized
DEBUG - 2018-05-11 21:48:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 21:48:06 --> Output Class Initialized
INFO - 2018-05-11 21:48:06 --> Output Class Initialized
INFO - 2018-05-11 21:48:06 --> Router Class Initialized
DEBUG - 2018-05-11 21:48:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-11 21:48:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 21:48:06 --> Input Class Initialized
INFO - 2018-05-11 21:48:06 --> Language Class Initialized
ERROR - 2018-05-11 21:48:06 --> 404 Page Not Found: /index
INFO - 2018-05-11 21:48:06 --> Input Class Initialized
INFO - 2018-05-11 21:48:06 --> Security Class Initialized
INFO - 2018-05-11 21:48:06 --> Security Class Initialized
INFO - 2018-05-11 21:48:06 --> Input Class Initialized
INFO - 2018-05-11 21:48:06 --> Output Class Initialized
INFO - 2018-05-11 21:48:06 --> Config Class Initialized
INFO - 2018-05-11 21:48:06 --> Language Class Initialized
INFO - 2018-05-11 21:48:06 --> Hooks Class Initialized
DEBUG - 2018-05-11 21:48:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 21:48:06 --> Language Class Initialized
ERROR - 2018-05-11 21:48:06 --> 404 Page Not Found: /index
INFO - 2018-05-11 21:48:06 --> Security Class Initialized
DEBUG - 2018-05-11 21:48:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 21:48:06 --> Input Class Initialized
ERROR - 2018-05-11 21:48:06 --> 404 Page Not Found: /index
DEBUG - 2018-05-11 21:48:06 --> UTF-8 Support Enabled
INFO - 2018-05-11 21:48:06 --> Config Class Initialized
DEBUG - 2018-05-11 21:48:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 21:48:06 --> Input Class Initialized
INFO - 2018-05-11 21:48:06 --> Hooks Class Initialized
INFO - 2018-05-11 21:48:06 --> Utf8 Class Initialized
INFO - 2018-05-11 21:48:06 --> Input Class Initialized
INFO - 2018-05-11 21:48:06 --> Language Class Initialized
INFO - 2018-05-11 21:48:06 --> Language Class Initialized
DEBUG - 2018-05-11 21:48:06 --> UTF-8 Support Enabled
INFO - 2018-05-11 21:48:06 --> Utf8 Class Initialized
INFO - 2018-05-11 21:48:06 --> URI Class Initialized
ERROR - 2018-05-11 21:48:06 --> 404 Page Not Found: /index
INFO - 2018-05-11 21:48:06 --> Language Class Initialized
ERROR - 2018-05-11 21:48:06 --> 404 Page Not Found: /index
INFO - 2018-05-11 21:48:06 --> URI Class Initialized
INFO - 2018-05-11 21:48:06 --> Router Class Initialized
INFO - 2018-05-11 21:48:06 --> Config Class Initialized
ERROR - 2018-05-11 21:48:06 --> 404 Page Not Found: /index
INFO - 2018-05-11 21:48:06 --> Router Class Initialized
INFO - 2018-05-11 21:48:06 --> Config Class Initialized
INFO - 2018-05-11 21:48:06 --> Hooks Class Initialized
INFO - 2018-05-11 21:48:06 --> Hooks Class Initialized
INFO - 2018-05-11 21:48:06 --> Output Class Initialized
INFO - 2018-05-11 21:48:06 --> Output Class Initialized
DEBUG - 2018-05-11 21:48:06 --> UTF-8 Support Enabled
DEBUG - 2018-05-11 21:48:06 --> UTF-8 Support Enabled
INFO - 2018-05-11 21:48:06 --> Security Class Initialized
INFO - 2018-05-11 21:48:06 --> Security Class Initialized
INFO - 2018-05-11 21:48:06 --> Utf8 Class Initialized
INFO - 2018-05-11 21:48:06 --> Utf8 Class Initialized
DEBUG - 2018-05-11 21:48:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-11 21:48:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 21:48:07 --> URI Class Initialized
INFO - 2018-05-11 21:48:07 --> Input Class Initialized
INFO - 2018-05-11 21:48:07 --> Input Class Initialized
INFO - 2018-05-11 21:48:07 --> URI Class Initialized
INFO - 2018-05-11 21:48:07 --> Router Class Initialized
INFO - 2018-05-11 21:48:07 --> Language Class Initialized
INFO - 2018-05-11 21:48:07 --> Language Class Initialized
INFO - 2018-05-11 21:48:07 --> Output Class Initialized
INFO - 2018-05-11 21:48:07 --> Router Class Initialized
INFO - 2018-05-11 21:48:07 --> Config Class Initialized
INFO - 2018-05-11 21:48:07 --> Hooks Class Initialized
ERROR - 2018-05-11 21:48:07 --> 404 Page Not Found: /index
ERROR - 2018-05-11 21:48:07 --> 404 Page Not Found: /index
INFO - 2018-05-11 21:48:07 --> Security Class Initialized
INFO - 2018-05-11 21:48:07 --> Output Class Initialized
DEBUG - 2018-05-11 21:48:07 --> UTF-8 Support Enabled
INFO - 2018-05-11 21:48:07 --> Utf8 Class Initialized
INFO - 2018-05-11 21:48:07 --> URI Class Initialized
INFO - 2018-05-11 21:48:07 --> Security Class Initialized
DEBUG - 2018-05-11 21:48:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 21:48:07 --> Router Class Initialized
INFO - 2018-05-11 21:48:07 --> Config Class Initialized
INFO - 2018-05-11 21:48:07 --> Config Class Initialized
INFO - 2018-05-11 21:48:07 --> Hooks Class Initialized
INFO - 2018-05-11 21:48:07 --> Hooks Class Initialized
DEBUG - 2018-05-11 21:48:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 21:48:07 --> Output Class Initialized
INFO - 2018-05-11 21:48:07 --> Input Class Initialized
DEBUG - 2018-05-11 21:48:07 --> UTF-8 Support Enabled
INFO - 2018-05-11 21:48:07 --> Utf8 Class Initialized
INFO - 2018-05-11 21:48:07 --> URI Class Initialized
INFO - 2018-05-11 21:48:07 --> Router Class Initialized
INFO - 2018-05-11 21:48:07 --> Output Class Initialized
INFO - 2018-05-11 21:48:07 --> Security Class Initialized
INFO - 2018-05-11 21:48:07 --> Input Class Initialized
INFO - 2018-05-11 21:48:07 --> Language Class Initialized
INFO - 2018-05-11 21:48:07 --> Security Class Initialized
DEBUG - 2018-05-11 21:48:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-11 21:48:07 --> UTF-8 Support Enabled
INFO - 2018-05-11 21:48:07 --> Input Class Initialized
ERROR - 2018-05-11 21:48:07 --> 404 Page Not Found: /index
DEBUG - 2018-05-11 21:48:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 21:48:07 --> Utf8 Class Initialized
INFO - 2018-05-11 21:48:07 --> Language Class Initialized
INFO - 2018-05-11 21:48:07 --> Input Class Initialized
INFO - 2018-05-11 21:48:07 --> URI Class Initialized
ERROR - 2018-05-11 21:48:07 --> 404 Page Not Found: /index
INFO - 2018-05-11 21:48:07 --> Language Class Initialized
INFO - 2018-05-11 21:48:07 --> Language Class Initialized
ERROR - 2018-05-11 21:48:07 --> 404 Page Not Found: /index
INFO - 2018-05-11 21:48:07 --> Router Class Initialized
ERROR - 2018-05-11 21:48:07 --> 404 Page Not Found: /index
INFO - 2018-05-11 21:48:07 --> Output Class Initialized
INFO - 2018-05-11 21:48:07 --> Security Class Initialized
DEBUG - 2018-05-11 21:48:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 21:48:07 --> Input Class Initialized
INFO - 2018-05-11 21:48:07 --> Language Class Initialized
ERROR - 2018-05-11 21:48:07 --> 404 Page Not Found: /index
INFO - 2018-05-11 21:48:08 --> Config Class Initialized
INFO - 2018-05-11 21:48:08 --> Config Class Initialized
INFO - 2018-05-11 21:48:08 --> Config Class Initialized
INFO - 2018-05-11 21:48:08 --> Hooks Class Initialized
INFO - 2018-05-11 21:48:08 --> Hooks Class Initialized
INFO - 2018-05-11 21:48:08 --> Hooks Class Initialized
DEBUG - 2018-05-11 21:48:08 --> UTF-8 Support Enabled
INFO - 2018-05-11 21:48:08 --> Utf8 Class Initialized
INFO - 2018-05-11 21:48:08 --> URI Class Initialized
DEBUG - 2018-05-11 21:48:08 --> UTF-8 Support Enabled
DEBUG - 2018-05-11 21:48:08 --> UTF-8 Support Enabled
INFO - 2018-05-11 21:48:08 --> Utf8 Class Initialized
INFO - 2018-05-11 21:48:08 --> Utf8 Class Initialized
INFO - 2018-05-11 21:48:08 --> Router Class Initialized
INFO - 2018-05-11 21:48:08 --> URI Class Initialized
INFO - 2018-05-11 21:48:08 --> Router Class Initialized
INFO - 2018-05-11 21:48:08 --> Output Class Initialized
INFO - 2018-05-11 21:48:08 --> Security Class Initialized
DEBUG - 2018-05-11 21:48:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 21:48:08 --> Input Class Initialized
INFO - 2018-05-11 21:48:08 --> Language Class Initialized
ERROR - 2018-05-11 21:48:08 --> 404 Page Not Found: /index
INFO - 2018-05-11 21:48:08 --> URI Class Initialized
INFO - 2018-05-11 21:48:08 --> Output Class Initialized
INFO - 2018-05-11 21:48:08 --> Security Class Initialized
INFO - 2018-05-11 21:48:08 --> Router Class Initialized
INFO - 2018-05-11 21:48:08 --> Output Class Initialized
DEBUG - 2018-05-11 21:48:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 21:48:08 --> Security Class Initialized
DEBUG - 2018-05-11 21:48:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 21:48:08 --> Input Class Initialized
INFO - 2018-05-11 21:48:08 --> Input Class Initialized
INFO - 2018-05-11 21:48:08 --> Language Class Initialized
INFO - 2018-05-11 21:48:08 --> Language Class Initialized
ERROR - 2018-05-11 21:48:08 --> 404 Page Not Found: /index
ERROR - 2018-05-11 21:48:08 --> 404 Page Not Found: /index
INFO - 2018-05-11 21:48:11 --> Config Class Initialized
INFO - 2018-05-11 21:48:11 --> Hooks Class Initialized
DEBUG - 2018-05-11 21:48:11 --> UTF-8 Support Enabled
INFO - 2018-05-11 21:48:11 --> Utf8 Class Initialized
INFO - 2018-05-11 21:48:11 --> URI Class Initialized
INFO - 2018-05-11 21:48:11 --> Router Class Initialized
INFO - 2018-05-11 21:48:11 --> Output Class Initialized
INFO - 2018-05-11 21:48:11 --> Security Class Initialized
DEBUG - 2018-05-11 21:48:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 21:48:11 --> Input Class Initialized
INFO - 2018-05-11 21:48:11 --> Language Class Initialized
INFO - 2018-05-11 21:48:11 --> Language Class Initialized
INFO - 2018-05-11 21:48:11 --> Config Class Initialized
INFO - 2018-05-11 21:48:11 --> Loader Class Initialized
DEBUG - 2018-05-11 21:48:11 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-11 21:48:11 --> Helper loaded: url_helper
INFO - 2018-05-11 21:48:11 --> Helper loaded: form_helper
INFO - 2018-05-11 21:48:11 --> Helper loaded: date_helper
INFO - 2018-05-11 21:48:11 --> Helper loaded: util_helper
INFO - 2018-05-11 21:48:11 --> Helper loaded: text_helper
INFO - 2018-05-11 21:48:11 --> Helper loaded: string_helper
INFO - 2018-05-11 21:48:11 --> Database Driver Class Initialized
DEBUG - 2018-05-11 21:48:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-11 21:48:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-11 21:48:11 --> Email Class Initialized
INFO - 2018-05-11 21:48:11 --> Controller Class Initialized
DEBUG - 2018-05-11 21:48:11 --> Login MX_Controller Initialized
INFO - 2018-05-11 21:48:11 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-11 21:48:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-11 21:48:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-11 21:48:11 --> 4 Loggedout
INFO - 2018-05-11 21:48:11 --> Config Class Initialized
INFO - 2018-05-11 21:48:12 --> Hooks Class Initialized
DEBUG - 2018-05-11 21:48:12 --> UTF-8 Support Enabled
INFO - 2018-05-11 21:48:12 --> Utf8 Class Initialized
INFO - 2018-05-11 21:48:12 --> URI Class Initialized
INFO - 2018-05-11 21:48:12 --> Router Class Initialized
INFO - 2018-05-11 21:48:12 --> Output Class Initialized
INFO - 2018-05-11 21:48:12 --> Security Class Initialized
DEBUG - 2018-05-11 21:48:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 21:48:12 --> Input Class Initialized
INFO - 2018-05-11 21:48:12 --> Language Class Initialized
INFO - 2018-05-11 21:48:12 --> Language Class Initialized
INFO - 2018-05-11 21:48:12 --> Config Class Initialized
INFO - 2018-05-11 21:48:12 --> Loader Class Initialized
DEBUG - 2018-05-11 21:48:12 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-11 21:48:12 --> Helper loaded: url_helper
INFO - 2018-05-11 21:48:12 --> Helper loaded: form_helper
INFO - 2018-05-11 21:48:12 --> Helper loaded: date_helper
INFO - 2018-05-11 21:48:12 --> Helper loaded: util_helper
INFO - 2018-05-11 21:48:12 --> Helper loaded: text_helper
INFO - 2018-05-11 21:48:12 --> Helper loaded: string_helper
INFO - 2018-05-11 21:48:12 --> Database Driver Class Initialized
DEBUG - 2018-05-11 21:48:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-11 21:48:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-11 21:48:12 --> Email Class Initialized
INFO - 2018-05-11 21:48:12 --> Controller Class Initialized
DEBUG - 2018-05-11 21:48:12 --> Home MX_Controller Initialized
DEBUG - 2018-05-11 21:48:12 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-11 21:48:12 --> Login MX_Controller Initialized
INFO - 2018-05-11 21:48:12 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-11 21:48:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-11 21:48:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-11 21:48:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/login.php
INFO - 2018-05-11 21:56:17 --> Config Class Initialized
INFO - 2018-05-11 21:56:17 --> Hooks Class Initialized
DEBUG - 2018-05-11 21:56:17 --> UTF-8 Support Enabled
INFO - 2018-05-11 21:56:17 --> Utf8 Class Initialized
INFO - 2018-05-11 21:56:17 --> URI Class Initialized
INFO - 2018-05-11 21:56:17 --> Router Class Initialized
INFO - 2018-05-11 21:56:17 --> Output Class Initialized
INFO - 2018-05-11 21:56:17 --> Security Class Initialized
DEBUG - 2018-05-11 21:56:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 21:56:17 --> Input Class Initialized
INFO - 2018-05-11 21:56:17 --> Language Class Initialized
INFO - 2018-05-11 21:56:17 --> Language Class Initialized
INFO - 2018-05-11 21:56:17 --> Config Class Initialized
INFO - 2018-05-11 21:56:17 --> Loader Class Initialized
DEBUG - 2018-05-11 21:56:17 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-11 21:56:17 --> Helper loaded: url_helper
INFO - 2018-05-11 21:56:17 --> Helper loaded: form_helper
INFO - 2018-05-11 21:56:17 --> Helper loaded: date_helper
INFO - 2018-05-11 21:56:17 --> Helper loaded: util_helper
INFO - 2018-05-11 21:56:17 --> Helper loaded: text_helper
INFO - 2018-05-11 21:56:17 --> Helper loaded: string_helper
INFO - 2018-05-11 21:56:17 --> Database Driver Class Initialized
DEBUG - 2018-05-11 21:56:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-11 21:56:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-11 21:56:17 --> Email Class Initialized
INFO - 2018-05-11 21:56:17 --> Controller Class Initialized
DEBUG - 2018-05-11 21:56:17 --> Home MX_Controller Initialized
DEBUG - 2018-05-11 21:56:17 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-11 21:56:17 --> Login MX_Controller Initialized
INFO - 2018-05-11 21:56:17 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-11 21:56:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-11 21:56:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-11 21:56:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/login.php
INFO - 2018-05-11 21:56:46 --> Config Class Initialized
INFO - 2018-05-11 21:56:46 --> Hooks Class Initialized
DEBUG - 2018-05-11 21:56:46 --> UTF-8 Support Enabled
INFO - 2018-05-11 21:56:46 --> Utf8 Class Initialized
INFO - 2018-05-11 21:56:46 --> URI Class Initialized
INFO - 2018-05-11 21:56:46 --> Router Class Initialized
INFO - 2018-05-11 21:56:46 --> Output Class Initialized
INFO - 2018-05-11 21:56:46 --> Security Class Initialized
DEBUG - 2018-05-11 21:56:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 21:56:46 --> Input Class Initialized
INFO - 2018-05-11 21:56:46 --> Language Class Initialized
INFO - 2018-05-11 21:56:46 --> Language Class Initialized
INFO - 2018-05-11 21:56:46 --> Config Class Initialized
INFO - 2018-05-11 21:56:46 --> Loader Class Initialized
DEBUG - 2018-05-11 21:56:46 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-11 21:56:46 --> Helper loaded: url_helper
INFO - 2018-05-11 21:56:46 --> Helper loaded: form_helper
INFO - 2018-05-11 21:56:46 --> Helper loaded: date_helper
INFO - 2018-05-11 21:56:46 --> Helper loaded: util_helper
INFO - 2018-05-11 21:56:47 --> Helper loaded: text_helper
INFO - 2018-05-11 21:56:47 --> Helper loaded: string_helper
INFO - 2018-05-11 21:56:47 --> Database Driver Class Initialized
DEBUG - 2018-05-11 21:56:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-11 21:56:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-11 21:56:47 --> Email Class Initialized
INFO - 2018-05-11 21:56:47 --> Controller Class Initialized
DEBUG - 2018-05-11 21:56:47 --> Login MX_Controller Initialized
INFO - 2018-05-11 21:56:47 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-11 21:56:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-11 21:56:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-11 21:56:47 --> Email starts for gopipanguluri123@gmail.com fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-05-11 21:56:47 --> User session created for 4
INFO - 2018-05-11 21:56:47 --> Login status gopipanguluri123@gmail.com - success
INFO - 2018-05-11 21:56:47 --> Final output sent to browser
DEBUG - 2018-05-11 21:56:47 --> Total execution time: 0.5347
INFO - 2018-05-11 21:56:47 --> Config Class Initialized
INFO - 2018-05-11 21:56:47 --> Hooks Class Initialized
DEBUG - 2018-05-11 21:56:47 --> UTF-8 Support Enabled
INFO - 2018-05-11 21:56:47 --> Utf8 Class Initialized
INFO - 2018-05-11 21:56:47 --> URI Class Initialized
INFO - 2018-05-11 21:56:47 --> Router Class Initialized
INFO - 2018-05-11 21:56:47 --> Output Class Initialized
INFO - 2018-05-11 21:56:47 --> Security Class Initialized
DEBUG - 2018-05-11 21:56:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 21:56:47 --> Input Class Initialized
INFO - 2018-05-11 21:56:47 --> Language Class Initialized
INFO - 2018-05-11 21:56:47 --> Language Class Initialized
INFO - 2018-05-11 21:56:47 --> Config Class Initialized
INFO - 2018-05-11 21:56:47 --> Loader Class Initialized
DEBUG - 2018-05-11 21:56:47 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-11 21:56:47 --> Helper loaded: url_helper
INFO - 2018-05-11 21:56:47 --> Helper loaded: form_helper
INFO - 2018-05-11 21:56:47 --> Helper loaded: date_helper
INFO - 2018-05-11 21:56:47 --> Helper loaded: util_helper
INFO - 2018-05-11 21:56:47 --> Helper loaded: text_helper
INFO - 2018-05-11 21:56:47 --> Helper loaded: string_helper
INFO - 2018-05-11 21:56:47 --> Database Driver Class Initialized
DEBUG - 2018-05-11 21:56:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-11 21:56:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-11 21:56:47 --> Email Class Initialized
INFO - 2018-05-11 21:56:47 --> Controller Class Initialized
DEBUG - 2018-05-11 21:56:47 --> Home MX_Controller Initialized
DEBUG - 2018-05-11 21:56:47 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-11 21:56:47 --> Login MX_Controller Initialized
INFO - 2018-05-11 21:56:47 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-11 21:56:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-11 21:56:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-11 21:56:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-05-11 21:56:47 --> Final output sent to browser
DEBUG - 2018-05-11 21:56:47 --> Total execution time: 0.5373
INFO - 2018-05-11 21:56:47 --> Config Class Initialized
INFO - 2018-05-11 21:56:47 --> Hooks Class Initialized
DEBUG - 2018-05-11 21:56:47 --> UTF-8 Support Enabled
INFO - 2018-05-11 21:56:48 --> Utf8 Class Initialized
INFO - 2018-05-11 21:56:48 --> URI Class Initialized
INFO - 2018-05-11 21:56:48 --> Router Class Initialized
INFO - 2018-05-11 21:56:48 --> Output Class Initialized
INFO - 2018-05-11 21:56:48 --> Security Class Initialized
DEBUG - 2018-05-11 21:56:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 21:56:48 --> Input Class Initialized
INFO - 2018-05-11 21:56:48 --> Language Class Initialized
ERROR - 2018-05-11 21:56:48 --> 404 Page Not Found: /index
INFO - 2018-05-11 21:56:49 --> Config Class Initialized
INFO - 2018-05-11 21:56:49 --> Config Class Initialized
INFO - 2018-05-11 21:56:49 --> Config Class Initialized
INFO - 2018-05-11 21:56:49 --> Hooks Class Initialized
INFO - 2018-05-11 21:56:49 --> Hooks Class Initialized
INFO - 2018-05-11 21:56:49 --> Hooks Class Initialized
INFO - 2018-05-11 21:56:49 --> Config Class Initialized
INFO - 2018-05-11 21:56:49 --> Config Class Initialized
DEBUG - 2018-05-11 21:56:49 --> UTF-8 Support Enabled
INFO - 2018-05-11 21:56:49 --> Config Class Initialized
DEBUG - 2018-05-11 21:56:49 --> UTF-8 Support Enabled
DEBUG - 2018-05-11 21:56:49 --> UTF-8 Support Enabled
INFO - 2018-05-11 21:56:49 --> Utf8 Class Initialized
INFO - 2018-05-11 21:56:49 --> Utf8 Class Initialized
INFO - 2018-05-11 21:56:49 --> Hooks Class Initialized
INFO - 2018-05-11 21:56:49 --> Hooks Class Initialized
INFO - 2018-05-11 21:56:49 --> Hooks Class Initialized
INFO - 2018-05-11 21:56:49 --> Utf8 Class Initialized
INFO - 2018-05-11 21:56:49 --> URI Class Initialized
INFO - 2018-05-11 21:56:49 --> Router Class Initialized
INFO - 2018-05-11 21:56:49 --> Output Class Initialized
INFO - 2018-05-11 21:56:49 --> Security Class Initialized
INFO - 2018-05-11 21:56:49 --> URI Class Initialized
DEBUG - 2018-05-11 21:56:49 --> UTF-8 Support Enabled
DEBUG - 2018-05-11 21:56:49 --> UTF-8 Support Enabled
DEBUG - 2018-05-11 21:56:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 21:56:49 --> URI Class Initialized
DEBUG - 2018-05-11 21:56:49 --> UTF-8 Support Enabled
INFO - 2018-05-11 21:56:49 --> Router Class Initialized
INFO - 2018-05-11 21:56:49 --> Utf8 Class Initialized
INFO - 2018-05-11 21:56:49 --> Input Class Initialized
INFO - 2018-05-11 21:56:49 --> Router Class Initialized
INFO - 2018-05-11 21:56:49 --> Utf8 Class Initialized
INFO - 2018-05-11 21:56:49 --> Utf8 Class Initialized
INFO - 2018-05-11 21:56:49 --> URI Class Initialized
INFO - 2018-05-11 21:56:49 --> Output Class Initialized
INFO - 2018-05-11 21:56:49 --> Router Class Initialized
INFO - 2018-05-11 21:56:49 --> URI Class Initialized
INFO - 2018-05-11 21:56:49 --> URI Class Initialized
INFO - 2018-05-11 21:56:49 --> Output Class Initialized
INFO - 2018-05-11 21:56:49 --> Language Class Initialized
INFO - 2018-05-11 21:56:49 --> Security Class Initialized
INFO - 2018-05-11 21:56:49 --> Output Class Initialized
INFO - 2018-05-11 21:56:49 --> Router Class Initialized
INFO - 2018-05-11 21:56:49 --> Output Class Initialized
INFO - 2018-05-11 21:56:49 --> Security Class Initialized
DEBUG - 2018-05-11 21:56:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 21:56:49 --> Input Class Initialized
INFO - 2018-05-11 21:56:49 --> Language Class Initialized
INFO - 2018-05-11 21:56:49 --> Security Class Initialized
DEBUG - 2018-05-11 21:56:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-05-11 21:56:49 --> 404 Page Not Found: /index
INFO - 2018-05-11 21:56:49 --> Security Class Initialized
ERROR - 2018-05-11 21:56:49 --> 404 Page Not Found: /index
INFO - 2018-05-11 21:56:49 --> Router Class Initialized
DEBUG - 2018-05-11 21:56:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 21:56:50 --> Output Class Initialized
DEBUG - 2018-05-11 21:56:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 21:56:50 --> Input Class Initialized
INFO - 2018-05-11 21:56:50 --> Config Class Initialized
INFO - 2018-05-11 21:56:50 --> Config Class Initialized
INFO - 2018-05-11 21:56:50 --> Input Class Initialized
INFO - 2018-05-11 21:56:50 --> Hooks Class Initialized
INFO - 2018-05-11 21:56:50 --> Hooks Class Initialized
INFO - 2018-05-11 21:56:50 --> Security Class Initialized
INFO - 2018-05-11 21:56:50 --> Language Class Initialized
INFO - 2018-05-11 21:56:50 --> Language Class Initialized
INFO - 2018-05-11 21:56:50 --> Input Class Initialized
DEBUG - 2018-05-11 21:56:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-05-11 21:56:50 --> 404 Page Not Found: /index
ERROR - 2018-05-11 21:56:50 --> 404 Page Not Found: /index
DEBUG - 2018-05-11 21:56:50 --> UTF-8 Support Enabled
INFO - 2018-05-11 21:56:50 --> Language Class Initialized
DEBUG - 2018-05-11 21:56:50 --> UTF-8 Support Enabled
INFO - 2018-05-11 21:56:50 --> Input Class Initialized
INFO - 2018-05-11 21:56:50 --> Language Class Initialized
INFO - 2018-05-11 21:56:50 --> Utf8 Class Initialized
INFO - 2018-05-11 21:56:50 --> Config Class Initialized
INFO - 2018-05-11 21:56:50 --> Config Class Initialized
ERROR - 2018-05-11 21:56:50 --> 404 Page Not Found: /index
INFO - 2018-05-11 21:56:50 --> Utf8 Class Initialized
ERROR - 2018-05-11 21:56:50 --> 404 Page Not Found: /index
INFO - 2018-05-11 21:56:50 --> Hooks Class Initialized
INFO - 2018-05-11 21:56:50 --> Hooks Class Initialized
INFO - 2018-05-11 21:56:50 --> URI Class Initialized
INFO - 2018-05-11 21:56:50 --> Config Class Initialized
INFO - 2018-05-11 21:56:50 --> URI Class Initialized
INFO - 2018-05-11 21:56:50 --> Hooks Class Initialized
DEBUG - 2018-05-11 21:56:50 --> UTF-8 Support Enabled
DEBUG - 2018-05-11 21:56:50 --> UTF-8 Support Enabled
INFO - 2018-05-11 21:56:50 --> Router Class Initialized
INFO - 2018-05-11 21:56:50 --> Router Class Initialized
DEBUG - 2018-05-11 21:56:50 --> UTF-8 Support Enabled
INFO - 2018-05-11 21:56:50 --> Utf8 Class Initialized
INFO - 2018-05-11 21:56:50 --> Utf8 Class Initialized
INFO - 2018-05-11 21:56:50 --> Utf8 Class Initialized
INFO - 2018-05-11 21:56:50 --> Output Class Initialized
INFO - 2018-05-11 21:56:50 --> Output Class Initialized
INFO - 2018-05-11 21:56:50 --> URI Class Initialized
INFO - 2018-05-11 21:56:50 --> URI Class Initialized
INFO - 2018-05-11 21:56:50 --> Security Class Initialized
INFO - 2018-05-11 21:56:50 --> Security Class Initialized
INFO - 2018-05-11 21:56:50 --> Router Class Initialized
INFO - 2018-05-11 21:56:50 --> URI Class Initialized
INFO - 2018-05-11 21:56:50 --> Router Class Initialized
INFO - 2018-05-11 21:56:50 --> Router Class Initialized
DEBUG - 2018-05-11 21:56:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 21:56:50 --> Output Class Initialized
INFO - 2018-05-11 21:56:50 --> Security Class Initialized
INFO - 2018-05-11 21:56:50 --> Input Class Initialized
DEBUG - 2018-05-11 21:56:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 21:56:50 --> Output Class Initialized
DEBUG - 2018-05-11 21:56:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 21:56:50 --> Output Class Initialized
INFO - 2018-05-11 21:56:51 --> Language Class Initialized
INFO - 2018-05-11 21:56:51 --> Security Class Initialized
INFO - 2018-05-11 21:56:51 --> Security Class Initialized
INFO - 2018-05-11 21:56:51 --> Input Class Initialized
INFO - 2018-05-11 21:56:51 --> Input Class Initialized
ERROR - 2018-05-11 21:56:51 --> 404 Page Not Found: /index
DEBUG - 2018-05-11 21:56:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 21:56:51 --> Language Class Initialized
INFO - 2018-05-11 21:56:51 --> Language Class Initialized
DEBUG - 2018-05-11 21:56:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 21:56:51 --> Input Class Initialized
INFO - 2018-05-11 21:56:51 --> Language Class Initialized
ERROR - 2018-05-11 21:56:51 --> 404 Page Not Found: /index
INFO - 2018-05-11 21:56:51 --> Input Class Initialized
ERROR - 2018-05-11 21:56:51 --> 404 Page Not Found: /index
ERROR - 2018-05-11 21:56:51 --> 404 Page Not Found: /index
INFO - 2018-05-11 21:56:51 --> Config Class Initialized
INFO - 2018-05-11 21:56:51 --> Language Class Initialized
INFO - 2018-05-11 21:56:51 --> Config Class Initialized
INFO - 2018-05-11 21:56:51 --> Config Class Initialized
INFO - 2018-05-11 21:56:51 --> Config Class Initialized
INFO - 2018-05-11 21:56:51 --> Hooks Class Initialized
INFO - 2018-05-11 21:56:51 --> Hooks Class Initialized
INFO - 2018-05-11 21:56:51 --> Hooks Class Initialized
INFO - 2018-05-11 21:56:51 --> Hooks Class Initialized
ERROR - 2018-05-11 21:56:51 --> 404 Page Not Found: /index
DEBUG - 2018-05-11 21:56:51 --> UTF-8 Support Enabled
DEBUG - 2018-05-11 21:56:51 --> UTF-8 Support Enabled
DEBUG - 2018-05-11 21:56:51 --> UTF-8 Support Enabled
DEBUG - 2018-05-11 21:56:51 --> UTF-8 Support Enabled
INFO - 2018-05-11 21:56:51 --> Config Class Initialized
INFO - 2018-05-11 21:56:51 --> Hooks Class Initialized
INFO - 2018-05-11 21:56:51 --> Utf8 Class Initialized
INFO - 2018-05-11 21:56:51 --> Utf8 Class Initialized
INFO - 2018-05-11 21:56:51 --> Utf8 Class Initialized
INFO - 2018-05-11 21:56:51 --> Utf8 Class Initialized
DEBUG - 2018-05-11 21:56:51 --> UTF-8 Support Enabled
INFO - 2018-05-11 21:56:51 --> URI Class Initialized
INFO - 2018-05-11 21:56:51 --> URI Class Initialized
INFO - 2018-05-11 21:56:51 --> URI Class Initialized
INFO - 2018-05-11 21:56:51 --> Utf8 Class Initialized
INFO - 2018-05-11 21:56:51 --> URI Class Initialized
INFO - 2018-05-11 21:56:51 --> URI Class Initialized
INFO - 2018-05-11 21:56:51 --> Router Class Initialized
INFO - 2018-05-11 21:56:51 --> Router Class Initialized
INFO - 2018-05-11 21:56:51 --> Router Class Initialized
INFO - 2018-05-11 21:56:51 --> Router Class Initialized
INFO - 2018-05-11 21:56:51 --> Output Class Initialized
INFO - 2018-05-11 21:56:51 --> Output Class Initialized
INFO - 2018-05-11 21:56:51 --> Router Class Initialized
INFO - 2018-05-11 21:56:51 --> Security Class Initialized
INFO - 2018-05-11 21:56:51 --> Security Class Initialized
DEBUG - 2018-05-11 21:56:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-11 21:56:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 21:56:51 --> Input Class Initialized
INFO - 2018-05-11 21:56:51 --> Input Class Initialized
INFO - 2018-05-11 21:56:51 --> Output Class Initialized
INFO - 2018-05-11 21:56:51 --> Output Class Initialized
INFO - 2018-05-11 21:56:51 --> Output Class Initialized
INFO - 2018-05-11 21:56:51 --> Language Class Initialized
INFO - 2018-05-11 21:56:51 --> Language Class Initialized
INFO - 2018-05-11 21:56:51 --> Security Class Initialized
INFO - 2018-05-11 21:56:51 --> Security Class Initialized
INFO - 2018-05-11 21:56:51 --> Security Class Initialized
ERROR - 2018-05-11 21:56:51 --> 404 Page Not Found: /index
ERROR - 2018-05-11 21:56:51 --> 404 Page Not Found: /index
DEBUG - 2018-05-11 21:56:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-11 21:56:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 21:56:51 --> Input Class Initialized
INFO - 2018-05-11 21:56:51 --> Language Class Initialized
DEBUG - 2018-05-11 21:56:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 21:56:51 --> Input Class Initialized
ERROR - 2018-05-11 21:56:51 --> 404 Page Not Found: /index
INFO - 2018-05-11 21:56:51 --> Input Class Initialized
INFO - 2018-05-11 21:56:51 --> Language Class Initialized
INFO - 2018-05-11 21:56:51 --> Language Class Initialized
ERROR - 2018-05-11 21:56:51 --> 404 Page Not Found: /index
ERROR - 2018-05-11 21:56:51 --> 404 Page Not Found: /index
INFO - 2018-05-11 21:57:59 --> Config Class Initialized
INFO - 2018-05-11 21:57:59 --> Hooks Class Initialized
DEBUG - 2018-05-11 21:57:59 --> UTF-8 Support Enabled
INFO - 2018-05-11 21:57:59 --> Utf8 Class Initialized
INFO - 2018-05-11 21:57:59 --> URI Class Initialized
INFO - 2018-05-11 21:57:59 --> Router Class Initialized
INFO - 2018-05-11 21:57:59 --> Output Class Initialized
INFO - 2018-05-11 21:57:59 --> Security Class Initialized
DEBUG - 2018-05-11 21:57:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 21:57:59 --> Input Class Initialized
INFO - 2018-05-11 21:57:59 --> Language Class Initialized
INFO - 2018-05-11 21:58:00 --> Language Class Initialized
INFO - 2018-05-11 21:58:00 --> Config Class Initialized
INFO - 2018-05-11 21:58:00 --> Loader Class Initialized
DEBUG - 2018-05-11 21:58:00 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-11 21:58:00 --> Helper loaded: url_helper
INFO - 2018-05-11 21:58:00 --> Helper loaded: form_helper
INFO - 2018-05-11 21:58:00 --> Helper loaded: date_helper
INFO - 2018-05-11 21:58:00 --> Helper loaded: util_helper
INFO - 2018-05-11 21:58:00 --> Helper loaded: text_helper
INFO - 2018-05-11 21:58:00 --> Helper loaded: string_helper
INFO - 2018-05-11 21:58:00 --> Database Driver Class Initialized
DEBUG - 2018-05-11 21:58:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-11 21:58:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-11 21:58:00 --> Email Class Initialized
INFO - 2018-05-11 21:58:00 --> Controller Class Initialized
DEBUG - 2018-05-11 21:58:00 --> Login MX_Controller Initialized
INFO - 2018-05-11 21:58:00 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-11 21:58:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-11 21:58:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-11 21:58:00 --> 4 Loggedout
INFO - 2018-05-11 21:58:00 --> Config Class Initialized
INFO - 2018-05-11 21:58:00 --> Hooks Class Initialized
DEBUG - 2018-05-11 21:58:00 --> UTF-8 Support Enabled
INFO - 2018-05-11 21:58:00 --> Utf8 Class Initialized
INFO - 2018-05-11 21:58:00 --> URI Class Initialized
INFO - 2018-05-11 21:58:00 --> Router Class Initialized
INFO - 2018-05-11 21:58:00 --> Output Class Initialized
INFO - 2018-05-11 21:58:00 --> Security Class Initialized
DEBUG - 2018-05-11 21:58:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 21:58:00 --> Input Class Initialized
INFO - 2018-05-11 21:58:00 --> Language Class Initialized
INFO - 2018-05-11 21:58:00 --> Language Class Initialized
INFO - 2018-05-11 21:58:00 --> Config Class Initialized
INFO - 2018-05-11 21:58:00 --> Loader Class Initialized
DEBUG - 2018-05-11 21:58:00 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-11 21:58:00 --> Helper loaded: url_helper
INFO - 2018-05-11 21:58:00 --> Helper loaded: form_helper
INFO - 2018-05-11 21:58:00 --> Helper loaded: date_helper
INFO - 2018-05-11 21:58:00 --> Helper loaded: util_helper
INFO - 2018-05-11 21:58:00 --> Helper loaded: text_helper
INFO - 2018-05-11 21:58:00 --> Helper loaded: string_helper
INFO - 2018-05-11 21:58:00 --> Database Driver Class Initialized
DEBUG - 2018-05-11 21:58:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-11 21:58:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-11 21:58:00 --> Email Class Initialized
INFO - 2018-05-11 21:58:00 --> Controller Class Initialized
DEBUG - 2018-05-11 21:58:00 --> Home MX_Controller Initialized
DEBUG - 2018-05-11 21:58:00 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-11 21:58:00 --> Login MX_Controller Initialized
INFO - 2018-05-11 21:58:00 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-11 21:58:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-11 21:58:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-11 21:58:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/login.php
INFO - 2018-05-11 21:58:03 --> Config Class Initialized
INFO - 2018-05-11 21:58:03 --> Hooks Class Initialized
DEBUG - 2018-05-11 21:58:03 --> UTF-8 Support Enabled
INFO - 2018-05-11 21:58:03 --> Utf8 Class Initialized
INFO - 2018-05-11 21:58:03 --> URI Class Initialized
INFO - 2018-05-11 21:58:03 --> Router Class Initialized
INFO - 2018-05-11 21:58:03 --> Output Class Initialized
INFO - 2018-05-11 21:58:03 --> Security Class Initialized
DEBUG - 2018-05-11 21:58:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 21:58:03 --> Input Class Initialized
INFO - 2018-05-11 21:58:03 --> Language Class Initialized
INFO - 2018-05-11 21:58:03 --> Language Class Initialized
INFO - 2018-05-11 21:58:03 --> Config Class Initialized
INFO - 2018-05-11 21:58:03 --> Loader Class Initialized
DEBUG - 2018-05-11 21:58:03 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-11 21:58:03 --> Helper loaded: url_helper
INFO - 2018-05-11 21:58:03 --> Helper loaded: form_helper
INFO - 2018-05-11 21:58:03 --> Helper loaded: date_helper
INFO - 2018-05-11 21:58:03 --> Helper loaded: util_helper
INFO - 2018-05-11 21:58:03 --> Helper loaded: text_helper
INFO - 2018-05-11 21:58:03 --> Helper loaded: string_helper
INFO - 2018-05-11 21:58:03 --> Database Driver Class Initialized
DEBUG - 2018-05-11 21:58:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-11 21:58:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-11 21:58:03 --> Email Class Initialized
INFO - 2018-05-11 21:58:03 --> Controller Class Initialized
DEBUG - 2018-05-11 21:58:03 --> Login MX_Controller Initialized
INFO - 2018-05-11 21:58:03 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-11 21:58:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-11 21:58:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-11 21:58:04 --> Email starts for gopipanguluri123@gmail.com fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-05-11 21:58:04 --> User session created for 4
INFO - 2018-05-11 21:58:04 --> Login status gopipanguluri123@gmail.com - success
INFO - 2018-05-11 21:58:04 --> Final output sent to browser
DEBUG - 2018-05-11 21:58:04 --> Total execution time: 0.5954
INFO - 2018-05-11 21:58:04 --> Config Class Initialized
INFO - 2018-05-11 21:58:04 --> Hooks Class Initialized
DEBUG - 2018-05-11 21:58:04 --> UTF-8 Support Enabled
INFO - 2018-05-11 21:58:04 --> Utf8 Class Initialized
INFO - 2018-05-11 21:58:04 --> URI Class Initialized
INFO - 2018-05-11 21:58:04 --> Router Class Initialized
INFO - 2018-05-11 21:58:04 --> Output Class Initialized
INFO - 2018-05-11 21:58:04 --> Security Class Initialized
DEBUG - 2018-05-11 21:58:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 21:58:04 --> Input Class Initialized
INFO - 2018-05-11 21:58:04 --> Language Class Initialized
INFO - 2018-05-11 21:58:04 --> Language Class Initialized
INFO - 2018-05-11 21:58:04 --> Config Class Initialized
INFO - 2018-05-11 21:58:04 --> Loader Class Initialized
DEBUG - 2018-05-11 21:58:04 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-11 21:58:04 --> Helper loaded: url_helper
INFO - 2018-05-11 21:58:04 --> Helper loaded: form_helper
INFO - 2018-05-11 21:58:04 --> Helper loaded: date_helper
INFO - 2018-05-11 21:58:04 --> Helper loaded: util_helper
INFO - 2018-05-11 21:58:04 --> Helper loaded: text_helper
INFO - 2018-05-11 21:58:04 --> Helper loaded: string_helper
INFO - 2018-05-11 21:58:04 --> Database Driver Class Initialized
DEBUG - 2018-05-11 21:58:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-11 21:58:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-11 21:58:04 --> Email Class Initialized
INFO - 2018-05-11 21:58:04 --> Controller Class Initialized
DEBUG - 2018-05-11 21:58:04 --> Home MX_Controller Initialized
DEBUG - 2018-05-11 21:58:04 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-11 21:58:04 --> Login MX_Controller Initialized
INFO - 2018-05-11 21:58:04 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-11 21:58:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-11 21:58:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-11 21:58:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-05-11 21:58:04 --> Final output sent to browser
DEBUG - 2018-05-11 21:58:04 --> Total execution time: 0.5766
INFO - 2018-05-11 21:58:04 --> Config Class Initialized
INFO - 2018-05-11 21:58:04 --> Hooks Class Initialized
DEBUG - 2018-05-11 21:58:04 --> UTF-8 Support Enabled
INFO - 2018-05-11 21:58:04 --> Utf8 Class Initialized
INFO - 2018-05-11 21:58:05 --> URI Class Initialized
INFO - 2018-05-11 21:58:05 --> Router Class Initialized
INFO - 2018-05-11 21:58:05 --> Output Class Initialized
INFO - 2018-05-11 21:58:05 --> Security Class Initialized
DEBUG - 2018-05-11 21:58:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 21:58:05 --> Input Class Initialized
INFO - 2018-05-11 21:58:05 --> Language Class Initialized
ERROR - 2018-05-11 21:58:05 --> 404 Page Not Found: /index
INFO - 2018-05-11 21:58:05 --> Config Class Initialized
INFO - 2018-05-11 21:58:05 --> Config Class Initialized
INFO - 2018-05-11 21:58:05 --> Config Class Initialized
INFO - 2018-05-11 21:58:05 --> Hooks Class Initialized
INFO - 2018-05-11 21:58:05 --> Hooks Class Initialized
INFO - 2018-05-11 21:58:05 --> Hooks Class Initialized
INFO - 2018-05-11 21:58:05 --> Config Class Initialized
DEBUG - 2018-05-11 21:58:05 --> UTF-8 Support Enabled
DEBUG - 2018-05-11 21:58:05 --> UTF-8 Support Enabled
DEBUG - 2018-05-11 21:58:05 --> UTF-8 Support Enabled
INFO - 2018-05-11 21:58:05 --> Config Class Initialized
INFO - 2018-05-11 21:58:05 --> Hooks Class Initialized
INFO - 2018-05-11 21:58:05 --> Config Class Initialized
INFO - 2018-05-11 21:58:05 --> Utf8 Class Initialized
INFO - 2018-05-11 21:58:05 --> Utf8 Class Initialized
INFO - 2018-05-11 21:58:05 --> Hooks Class Initialized
INFO - 2018-05-11 21:58:05 --> Hooks Class Initialized
INFO - 2018-05-11 21:58:05 --> Utf8 Class Initialized
DEBUG - 2018-05-11 21:58:05 --> UTF-8 Support Enabled
INFO - 2018-05-11 21:58:05 --> URI Class Initialized
INFO - 2018-05-11 21:58:05 --> Router Class Initialized
INFO - 2018-05-11 21:58:05 --> URI Class Initialized
DEBUG - 2018-05-11 21:58:05 --> UTF-8 Support Enabled
INFO - 2018-05-11 21:58:05 --> Utf8 Class Initialized
INFO - 2018-05-11 21:58:05 --> URI Class Initialized
DEBUG - 2018-05-11 21:58:05 --> UTF-8 Support Enabled
INFO - 2018-05-11 21:58:05 --> URI Class Initialized
INFO - 2018-05-11 21:58:05 --> Router Class Initialized
INFO - 2018-05-11 21:58:05 --> Output Class Initialized
INFO - 2018-05-11 21:58:05 --> Router Class Initialized
INFO - 2018-05-11 21:58:05 --> Utf8 Class Initialized
INFO - 2018-05-11 21:58:05 --> Utf8 Class Initialized
INFO - 2018-05-11 21:58:05 --> Output Class Initialized
INFO - 2018-05-11 21:58:05 --> Router Class Initialized
INFO - 2018-05-11 21:58:05 --> Output Class Initialized
INFO - 2018-05-11 21:58:05 --> Security Class Initialized
INFO - 2018-05-11 21:58:05 --> Security Class Initialized
INFO - 2018-05-11 21:58:05 --> Output Class Initialized
INFO - 2018-05-11 21:58:05 --> URI Class Initialized
INFO - 2018-05-11 21:58:05 --> URI Class Initialized
INFO - 2018-05-11 21:58:05 --> Security Class Initialized
DEBUG - 2018-05-11 21:58:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-11 21:58:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-11 21:58:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 21:58:05 --> Security Class Initialized
INFO - 2018-05-11 21:58:05 --> Input Class Initialized
INFO - 2018-05-11 21:58:05 --> Router Class Initialized
INFO - 2018-05-11 21:58:05 --> Router Class Initialized
INFO - 2018-05-11 21:58:05 --> Input Class Initialized
INFO - 2018-05-11 21:58:05 --> Input Class Initialized
DEBUG - 2018-05-11 21:58:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 21:58:05 --> Output Class Initialized
INFO - 2018-05-11 21:58:05 --> Language Class Initialized
INFO - 2018-05-11 21:58:05 --> Output Class Initialized
INFO - 2018-05-11 21:58:05 --> Language Class Initialized
ERROR - 2018-05-11 21:58:05 --> 404 Page Not Found: /index
INFO - 2018-05-11 21:58:05 --> Input Class Initialized
INFO - 2018-05-11 21:58:05 --> Language Class Initialized
INFO - 2018-05-11 21:58:05 --> Config Class Initialized
INFO - 2018-05-11 21:58:05 --> Security Class Initialized
ERROR - 2018-05-11 21:58:06 --> 404 Page Not Found: /index
INFO - 2018-05-11 21:58:06 --> Security Class Initialized
INFO - 2018-05-11 21:58:06 --> Language Class Initialized
INFO - 2018-05-11 21:58:06 --> Hooks Class Initialized
ERROR - 2018-05-11 21:58:06 --> 404 Page Not Found: /index
ERROR - 2018-05-11 21:58:06 --> 404 Page Not Found: /index
DEBUG - 2018-05-11 21:58:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-11 21:58:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 21:58:06 --> Input Class Initialized
DEBUG - 2018-05-11 21:58:06 --> UTF-8 Support Enabled
INFO - 2018-05-11 21:58:06 --> Input Class Initialized
INFO - 2018-05-11 21:58:06 --> Language Class Initialized
INFO - 2018-05-11 21:58:06 --> Config Class Initialized
INFO - 2018-05-11 21:58:06 --> Config Class Initialized
INFO - 2018-05-11 21:58:06 --> Utf8 Class Initialized
INFO - 2018-05-11 21:58:06 --> Language Class Initialized
INFO - 2018-05-11 21:58:06 --> URI Class Initialized
ERROR - 2018-05-11 21:58:06 --> 404 Page Not Found: /index
INFO - 2018-05-11 21:58:06 --> Hooks Class Initialized
INFO - 2018-05-11 21:58:06 --> Hooks Class Initialized
ERROR - 2018-05-11 21:58:06 --> 404 Page Not Found: /index
DEBUG - 2018-05-11 21:58:06 --> UTF-8 Support Enabled
DEBUG - 2018-05-11 21:58:06 --> UTF-8 Support Enabled
INFO - 2018-05-11 21:58:06 --> Router Class Initialized
INFO - 2018-05-11 21:58:06 --> Utf8 Class Initialized
INFO - 2018-05-11 21:58:06 --> Output Class Initialized
INFO - 2018-05-11 21:58:06 --> Utf8 Class Initialized
INFO - 2018-05-11 21:58:06 --> URI Class Initialized
INFO - 2018-05-11 21:58:06 --> Security Class Initialized
INFO - 2018-05-11 21:58:06 --> URI Class Initialized
DEBUG - 2018-05-11 21:58:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 21:58:06 --> Router Class Initialized
INFO - 2018-05-11 21:58:06 --> Router Class Initialized
INFO - 2018-05-11 21:58:06 --> Output Class Initialized
INFO - 2018-05-11 21:58:06 --> Security Class Initialized
INFO - 2018-05-11 21:58:06 --> Input Class Initialized
INFO - 2018-05-11 21:58:06 --> Language Class Initialized
INFO - 2018-05-11 21:58:06 --> Output Class Initialized
DEBUG - 2018-05-11 21:58:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-05-11 21:58:06 --> 404 Page Not Found: /index
INFO - 2018-05-11 21:58:06 --> Security Class Initialized
DEBUG - 2018-05-11 21:58:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 21:58:06 --> Input Class Initialized
INFO - 2018-05-11 21:58:06 --> Input Class Initialized
INFO - 2018-05-11 21:58:06 --> Language Class Initialized
ERROR - 2018-05-11 21:58:06 --> 404 Page Not Found: /index
INFO - 2018-05-11 21:58:06 --> Language Class Initialized
ERROR - 2018-05-11 21:58:06 --> 404 Page Not Found: /index
INFO - 2018-05-11 21:58:06 --> Config Class Initialized
INFO - 2018-05-11 21:58:06 --> Config Class Initialized
INFO - 2018-05-11 21:58:06 --> Config Class Initialized
INFO - 2018-05-11 21:58:06 --> Config Class Initialized
INFO - 2018-05-11 21:58:06 --> Config Class Initialized
INFO - 2018-05-11 21:58:06 --> Hooks Class Initialized
INFO - 2018-05-11 21:58:06 --> Hooks Class Initialized
INFO - 2018-05-11 21:58:06 --> Hooks Class Initialized
INFO - 2018-05-11 21:58:06 --> Hooks Class Initialized
INFO - 2018-05-11 21:58:06 --> Hooks Class Initialized
DEBUG - 2018-05-11 21:58:06 --> UTF-8 Support Enabled
INFO - 2018-05-11 21:58:06 --> Utf8 Class Initialized
INFO - 2018-05-11 21:58:06 --> URI Class Initialized
DEBUG - 2018-05-11 21:58:06 --> UTF-8 Support Enabled
DEBUG - 2018-05-11 21:58:06 --> UTF-8 Support Enabled
DEBUG - 2018-05-11 21:58:06 --> UTF-8 Support Enabled
INFO - 2018-05-11 21:58:06 --> Router Class Initialized
DEBUG - 2018-05-11 21:58:06 --> UTF-8 Support Enabled
INFO - 2018-05-11 21:58:06 --> Utf8 Class Initialized
INFO - 2018-05-11 21:58:06 --> Utf8 Class Initialized
INFO - 2018-05-11 21:58:06 --> Utf8 Class Initialized
INFO - 2018-05-11 21:58:06 --> Utf8 Class Initialized
INFO - 2018-05-11 21:58:06 --> Output Class Initialized
INFO - 2018-05-11 21:58:06 --> Security Class Initialized
INFO - 2018-05-11 21:58:06 --> URI Class Initialized
DEBUG - 2018-05-11 21:58:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 21:58:06 --> Router Class Initialized
INFO - 2018-05-11 21:58:06 --> Input Class Initialized
INFO - 2018-05-11 21:58:06 --> Output Class Initialized
INFO - 2018-05-11 21:58:06 --> Security Class Initialized
INFO - 2018-05-11 21:58:06 --> Language Class Initialized
DEBUG - 2018-05-11 21:58:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-05-11 21:58:07 --> 404 Page Not Found: /index
INFO - 2018-05-11 21:58:07 --> Input Class Initialized
INFO - 2018-05-11 21:58:07 --> Language Class Initialized
INFO - 2018-05-11 21:58:07 --> URI Class Initialized
INFO - 2018-05-11 21:58:07 --> URI Class Initialized
INFO - 2018-05-11 21:58:07 --> URI Class Initialized
ERROR - 2018-05-11 21:58:07 --> 404 Page Not Found: /index
INFO - 2018-05-11 21:58:07 --> Router Class Initialized
INFO - 2018-05-11 21:58:07 --> Router Class Initialized
INFO - 2018-05-11 21:58:07 --> Router Class Initialized
INFO - 2018-05-11 21:58:07 --> Output Class Initialized
INFO - 2018-05-11 21:58:07 --> Output Class Initialized
INFO - 2018-05-11 21:58:07 --> Output Class Initialized
INFO - 2018-05-11 21:58:07 --> Security Class Initialized
INFO - 2018-05-11 21:58:07 --> Security Class Initialized
INFO - 2018-05-11 21:58:07 --> Security Class Initialized
DEBUG - 2018-05-11 21:58:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-11 21:58:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 21:58:07 --> Input Class Initialized
INFO - 2018-05-11 21:58:07 --> Input Class Initialized
DEBUG - 2018-05-11 21:58:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 21:58:07 --> Language Class Initialized
INFO - 2018-05-11 21:58:07 --> Input Class Initialized
INFO - 2018-05-11 21:58:07 --> Language Class Initialized
ERROR - 2018-05-11 21:58:07 --> 404 Page Not Found: /index
INFO - 2018-05-11 21:58:07 --> Config Class Initialized
INFO - 2018-05-11 21:58:07 --> Hooks Class Initialized
DEBUG - 2018-05-11 21:58:07 --> UTF-8 Support Enabled
INFO - 2018-05-11 21:58:07 --> Utf8 Class Initialized
INFO - 2018-05-11 21:58:07 --> URI Class Initialized
INFO - 2018-05-11 21:58:07 --> Router Class Initialized
INFO - 2018-05-11 21:58:07 --> Output Class Initialized
ERROR - 2018-05-11 21:58:07 --> 404 Page Not Found: /index
INFO - 2018-05-11 21:58:07 --> Language Class Initialized
INFO - 2018-05-11 21:58:07 --> Security Class Initialized
DEBUG - 2018-05-11 21:58:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 21:58:07 --> Input Class Initialized
INFO - 2018-05-11 21:58:07 --> Config Class Initialized
INFO - 2018-05-11 21:58:07 --> Hooks Class Initialized
INFO - 2018-05-11 21:58:07 --> Language Class Initialized
ERROR - 2018-05-11 21:58:07 --> 404 Page Not Found: /index
DEBUG - 2018-05-11 21:58:07 --> UTF-8 Support Enabled
INFO - 2018-05-11 21:58:07 --> Utf8 Class Initialized
INFO - 2018-05-11 21:58:07 --> URI Class Initialized
INFO - 2018-05-11 21:58:07 --> Router Class Initialized
ERROR - 2018-05-11 21:58:07 --> 404 Page Not Found: /index
INFO - 2018-05-11 21:58:07 --> Output Class Initialized
INFO - 2018-05-11 21:58:07 --> Security Class Initialized
DEBUG - 2018-05-11 21:58:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 21:58:07 --> Input Class Initialized
INFO - 2018-05-11 21:58:07 --> Language Class Initialized
ERROR - 2018-05-11 21:58:07 --> 404 Page Not Found: /index
INFO - 2018-05-11 21:58:09 --> Config Class Initialized
INFO - 2018-05-11 21:58:09 --> Hooks Class Initialized
DEBUG - 2018-05-11 21:58:09 --> UTF-8 Support Enabled
INFO - 2018-05-11 21:58:09 --> Utf8 Class Initialized
INFO - 2018-05-11 21:58:09 --> URI Class Initialized
INFO - 2018-05-11 21:58:09 --> Router Class Initialized
INFO - 2018-05-11 21:58:09 --> Output Class Initialized
INFO - 2018-05-11 21:58:09 --> Security Class Initialized
DEBUG - 2018-05-11 21:58:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 21:58:09 --> Input Class Initialized
INFO - 2018-05-11 21:58:09 --> Language Class Initialized
INFO - 2018-05-11 21:58:09 --> Language Class Initialized
INFO - 2018-05-11 21:58:09 --> Config Class Initialized
INFO - 2018-05-11 21:58:09 --> Loader Class Initialized
DEBUG - 2018-05-11 21:58:09 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-11 21:58:09 --> Helper loaded: url_helper
INFO - 2018-05-11 21:58:09 --> Helper loaded: form_helper
INFO - 2018-05-11 21:58:09 --> Helper loaded: date_helper
INFO - 2018-05-11 21:58:09 --> Helper loaded: util_helper
INFO - 2018-05-11 21:58:09 --> Helper loaded: text_helper
INFO - 2018-05-11 21:58:09 --> Helper loaded: string_helper
INFO - 2018-05-11 21:58:09 --> Database Driver Class Initialized
DEBUG - 2018-05-11 21:58:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-11 21:58:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-11 21:58:09 --> Email Class Initialized
INFO - 2018-05-11 21:58:09 --> Controller Class Initialized
DEBUG - 2018-05-11 21:58:09 --> Login MX_Controller Initialized
INFO - 2018-05-11 21:58:09 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-11 21:58:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-11 21:58:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-11 21:58:10 --> 4 Loggedout
INFO - 2018-05-11 21:58:10 --> Config Class Initialized
INFO - 2018-05-11 21:58:10 --> Hooks Class Initialized
DEBUG - 2018-05-11 21:58:10 --> UTF-8 Support Enabled
INFO - 2018-05-11 21:58:10 --> Utf8 Class Initialized
INFO - 2018-05-11 21:58:10 --> URI Class Initialized
INFO - 2018-05-11 21:58:10 --> Router Class Initialized
INFO - 2018-05-11 21:58:10 --> Output Class Initialized
INFO - 2018-05-11 21:58:10 --> Security Class Initialized
DEBUG - 2018-05-11 21:58:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 21:58:10 --> Input Class Initialized
INFO - 2018-05-11 21:58:10 --> Language Class Initialized
INFO - 2018-05-11 21:58:10 --> Language Class Initialized
INFO - 2018-05-11 21:58:10 --> Config Class Initialized
INFO - 2018-05-11 21:58:10 --> Loader Class Initialized
DEBUG - 2018-05-11 21:58:10 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-11 21:58:10 --> Helper loaded: url_helper
INFO - 2018-05-11 21:58:10 --> Helper loaded: form_helper
INFO - 2018-05-11 21:58:10 --> Helper loaded: date_helper
INFO - 2018-05-11 21:58:10 --> Helper loaded: util_helper
INFO - 2018-05-11 21:58:10 --> Helper loaded: text_helper
INFO - 2018-05-11 21:58:10 --> Helper loaded: string_helper
INFO - 2018-05-11 21:58:10 --> Database Driver Class Initialized
DEBUG - 2018-05-11 21:58:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-11 21:58:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-11 21:58:10 --> Email Class Initialized
INFO - 2018-05-11 21:58:10 --> Controller Class Initialized
DEBUG - 2018-05-11 21:58:10 --> Home MX_Controller Initialized
DEBUG - 2018-05-11 21:58:10 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-11 21:58:10 --> Login MX_Controller Initialized
INFO - 2018-05-11 21:58:10 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-11 21:58:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-11 21:58:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-11 21:58:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/login.php
INFO - 2018-05-11 21:58:47 --> Config Class Initialized
INFO - 2018-05-11 21:58:47 --> Hooks Class Initialized
DEBUG - 2018-05-11 21:58:47 --> UTF-8 Support Enabled
INFO - 2018-05-11 21:58:47 --> Utf8 Class Initialized
INFO - 2018-05-11 21:58:47 --> URI Class Initialized
INFO - 2018-05-11 21:58:47 --> Router Class Initialized
INFO - 2018-05-11 21:58:47 --> Output Class Initialized
INFO - 2018-05-11 21:58:47 --> Security Class Initialized
DEBUG - 2018-05-11 21:58:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 21:58:47 --> Input Class Initialized
INFO - 2018-05-11 21:58:47 --> Language Class Initialized
INFO - 2018-05-11 21:58:47 --> Language Class Initialized
INFO - 2018-05-11 21:58:47 --> Config Class Initialized
INFO - 2018-05-11 21:58:47 --> Loader Class Initialized
DEBUG - 2018-05-11 21:58:47 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-11 21:58:47 --> Helper loaded: url_helper
INFO - 2018-05-11 21:58:47 --> Helper loaded: form_helper
INFO - 2018-05-11 21:58:47 --> Helper loaded: date_helper
INFO - 2018-05-11 21:58:47 --> Helper loaded: util_helper
INFO - 2018-05-11 21:58:47 --> Helper loaded: text_helper
INFO - 2018-05-11 21:58:47 --> Helper loaded: string_helper
INFO - 2018-05-11 21:58:47 --> Database Driver Class Initialized
DEBUG - 2018-05-11 21:58:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-11 21:58:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-11 21:58:47 --> Email Class Initialized
INFO - 2018-05-11 21:58:47 --> Controller Class Initialized
DEBUG - 2018-05-11 21:58:47 --> Login MX_Controller Initialized
INFO - 2018-05-11 21:58:47 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-11 21:58:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-11 21:58:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-11 21:58:47 --> Email starts for gopipanguluri123@gmail.com fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-05-11 21:58:47 --> User session created for 4
INFO - 2018-05-11 21:58:47 --> Login status gopipanguluri123@gmail.com - success
INFO - 2018-05-11 21:58:47 --> Final output sent to browser
DEBUG - 2018-05-11 21:58:47 --> Total execution time: 0.5580
INFO - 2018-05-11 21:58:47 --> Config Class Initialized
INFO - 2018-05-11 21:58:47 --> Hooks Class Initialized
DEBUG - 2018-05-11 21:58:47 --> UTF-8 Support Enabled
INFO - 2018-05-11 21:58:47 --> Utf8 Class Initialized
INFO - 2018-05-11 21:58:47 --> URI Class Initialized
INFO - 2018-05-11 21:58:47 --> Router Class Initialized
INFO - 2018-05-11 21:58:47 --> Output Class Initialized
INFO - 2018-05-11 21:58:47 --> Security Class Initialized
DEBUG - 2018-05-11 21:58:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 21:58:47 --> Input Class Initialized
INFO - 2018-05-11 21:58:47 --> Language Class Initialized
INFO - 2018-05-11 21:58:47 --> Language Class Initialized
INFO - 2018-05-11 21:58:48 --> Config Class Initialized
INFO - 2018-05-11 21:58:48 --> Loader Class Initialized
DEBUG - 2018-05-11 21:58:48 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-11 21:58:48 --> Helper loaded: url_helper
INFO - 2018-05-11 21:58:48 --> Helper loaded: form_helper
INFO - 2018-05-11 21:58:48 --> Helper loaded: date_helper
INFO - 2018-05-11 21:58:48 --> Helper loaded: util_helper
INFO - 2018-05-11 21:58:48 --> Helper loaded: text_helper
INFO - 2018-05-11 21:58:48 --> Helper loaded: string_helper
INFO - 2018-05-11 21:58:48 --> Database Driver Class Initialized
DEBUG - 2018-05-11 21:58:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-11 21:58:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-11 21:58:48 --> Email Class Initialized
INFO - 2018-05-11 21:58:48 --> Controller Class Initialized
DEBUG - 2018-05-11 21:58:48 --> Home MX_Controller Initialized
DEBUG - 2018-05-11 21:58:48 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-11 21:58:48 --> Login MX_Controller Initialized
INFO - 2018-05-11 21:58:48 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-11 21:58:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-11 21:58:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-11 21:58:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-05-11 21:58:48 --> Final output sent to browser
DEBUG - 2018-05-11 21:58:48 --> Total execution time: 0.5649
INFO - 2018-05-11 21:58:48 --> Config Class Initialized
INFO - 2018-05-11 21:58:48 --> Hooks Class Initialized
DEBUG - 2018-05-11 21:58:48 --> UTF-8 Support Enabled
INFO - 2018-05-11 21:58:48 --> Utf8 Class Initialized
INFO - 2018-05-11 21:58:48 --> URI Class Initialized
INFO - 2018-05-11 21:58:48 --> Router Class Initialized
INFO - 2018-05-11 21:58:48 --> Output Class Initialized
INFO - 2018-05-11 21:58:48 --> Security Class Initialized
DEBUG - 2018-05-11 21:58:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 21:58:48 --> Input Class Initialized
INFO - 2018-05-11 21:58:48 --> Language Class Initialized
ERROR - 2018-05-11 21:58:48 --> 404 Page Not Found: /index
INFO - 2018-05-11 21:58:49 --> Config Class Initialized
INFO - 2018-05-11 21:58:49 --> Hooks Class Initialized
INFO - 2018-05-11 21:58:49 --> Config Class Initialized
INFO - 2018-05-11 21:58:49 --> Config Class Initialized
INFO - 2018-05-11 21:58:49 --> Hooks Class Initialized
INFO - 2018-05-11 21:58:49 --> Hooks Class Initialized
INFO - 2018-05-11 21:58:49 --> Config Class Initialized
DEBUG - 2018-05-11 21:58:49 --> UTF-8 Support Enabled
INFO - 2018-05-11 21:58:49 --> Hooks Class Initialized
INFO - 2018-05-11 21:58:49 --> Config Class Initialized
INFO - 2018-05-11 21:58:49 --> Config Class Initialized
DEBUG - 2018-05-11 21:58:49 --> UTF-8 Support Enabled
INFO - 2018-05-11 21:58:49 --> Utf8 Class Initialized
DEBUG - 2018-05-11 21:58:49 --> UTF-8 Support Enabled
INFO - 2018-05-11 21:58:49 --> Utf8 Class Initialized
DEBUG - 2018-05-11 21:58:49 --> UTF-8 Support Enabled
INFO - 2018-05-11 21:58:49 --> URI Class Initialized
INFO - 2018-05-11 21:58:49 --> Utf8 Class Initialized
INFO - 2018-05-11 21:58:49 --> Hooks Class Initialized
INFO - 2018-05-11 21:58:49 --> Hooks Class Initialized
INFO - 2018-05-11 21:58:49 --> URI Class Initialized
DEBUG - 2018-05-11 21:58:49 --> UTF-8 Support Enabled
DEBUG - 2018-05-11 21:58:49 --> UTF-8 Support Enabled
INFO - 2018-05-11 21:58:49 --> URI Class Initialized
INFO - 2018-05-11 21:58:49 --> Router Class Initialized
INFO - 2018-05-11 21:58:49 --> Utf8 Class Initialized
INFO - 2018-05-11 21:58:49 --> Router Class Initialized
INFO - 2018-05-11 21:58:49 --> Utf8 Class Initialized
INFO - 2018-05-11 21:58:49 --> Output Class Initialized
INFO - 2018-05-11 21:58:49 --> Router Class Initialized
INFO - 2018-05-11 21:58:49 --> URI Class Initialized
INFO - 2018-05-11 21:58:49 --> Utf8 Class Initialized
INFO - 2018-05-11 21:58:49 --> Output Class Initialized
INFO - 2018-05-11 21:58:49 --> URI Class Initialized
INFO - 2018-05-11 21:58:49 --> Router Class Initialized
INFO - 2018-05-11 21:58:49 --> Output Class Initialized
INFO - 2018-05-11 21:58:49 --> Security Class Initialized
INFO - 2018-05-11 21:58:49 --> Security Class Initialized
INFO - 2018-05-11 21:58:49 --> Output Class Initialized
INFO - 2018-05-11 21:58:49 --> Router Class Initialized
INFO - 2018-05-11 21:58:49 --> URI Class Initialized
INFO - 2018-05-11 21:58:49 --> Security Class Initialized
DEBUG - 2018-05-11 21:58:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-11 21:58:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 21:58:49 --> Input Class Initialized
DEBUG - 2018-05-11 21:58:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 21:58:49 --> Router Class Initialized
INFO - 2018-05-11 21:58:49 --> Output Class Initialized
INFO - 2018-05-11 21:58:49 --> Security Class Initialized
INFO - 2018-05-11 21:58:49 --> Input Class Initialized
INFO - 2018-05-11 21:58:49 --> Language Class Initialized
INFO - 2018-05-11 21:58:49 --> Language Class Initialized
DEBUG - 2018-05-11 21:58:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 21:58:49 --> Security Class Initialized
INFO - 2018-05-11 21:58:49 --> Output Class Initialized
INFO - 2018-05-11 21:58:49 --> Input Class Initialized
ERROR - 2018-05-11 21:58:49 --> 404 Page Not Found: /index
INFO - 2018-05-11 21:58:49 --> Input Class Initialized
INFO - 2018-05-11 21:58:49 --> Security Class Initialized
DEBUG - 2018-05-11 21:58:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 21:58:49 --> Language Class Initialized
ERROR - 2018-05-11 21:58:49 --> 404 Page Not Found: /index
DEBUG - 2018-05-11 21:58:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 21:58:49 --> Language Class Initialized
INFO - 2018-05-11 21:58:49 --> Input Class Initialized
ERROR - 2018-05-11 21:58:49 --> 404 Page Not Found: /index
INFO - 2018-05-11 21:58:49 --> Language Class Initialized
ERROR - 2018-05-11 21:58:49 --> 404 Page Not Found: /index
INFO - 2018-05-11 21:58:49 --> Input Class Initialized
ERROR - 2018-05-11 21:58:49 --> 404 Page Not Found: /index
INFO - 2018-05-11 21:58:49 --> Language Class Initialized
ERROR - 2018-05-11 21:58:49 --> 404 Page Not Found: /index
INFO - 2018-05-11 21:58:50 --> Config Class Initialized
INFO - 2018-05-11 21:58:50 --> Config Class Initialized
INFO - 2018-05-11 21:58:50 --> Config Class Initialized
INFO - 2018-05-11 21:58:50 --> Config Class Initialized
INFO - 2018-05-11 21:58:50 --> Config Class Initialized
INFO - 2018-05-11 21:58:50 --> Hooks Class Initialized
INFO - 2018-05-11 21:58:50 --> Hooks Class Initialized
INFO - 2018-05-11 21:58:50 --> Hooks Class Initialized
INFO - 2018-05-11 21:58:50 --> Hooks Class Initialized
INFO - 2018-05-11 21:58:50 --> Hooks Class Initialized
DEBUG - 2018-05-11 21:58:50 --> UTF-8 Support Enabled
DEBUG - 2018-05-11 21:58:50 --> UTF-8 Support Enabled
DEBUG - 2018-05-11 21:58:50 --> UTF-8 Support Enabled
DEBUG - 2018-05-11 21:58:50 --> UTF-8 Support Enabled
DEBUG - 2018-05-11 21:58:50 --> UTF-8 Support Enabled
INFO - 2018-05-11 21:58:50 --> Utf8 Class Initialized
INFO - 2018-05-11 21:58:50 --> Utf8 Class Initialized
INFO - 2018-05-11 21:58:50 --> Utf8 Class Initialized
INFO - 2018-05-11 21:58:50 --> Utf8 Class Initialized
INFO - 2018-05-11 21:58:50 --> Utf8 Class Initialized
INFO - 2018-05-11 21:58:50 --> URI Class Initialized
INFO - 2018-05-11 21:58:50 --> URI Class Initialized
INFO - 2018-05-11 21:58:50 --> URI Class Initialized
INFO - 2018-05-11 21:58:50 --> URI Class Initialized
INFO - 2018-05-11 21:58:50 --> URI Class Initialized
INFO - 2018-05-11 21:58:50 --> Router Class Initialized
INFO - 2018-05-11 21:58:50 --> Output Class Initialized
INFO - 2018-05-11 21:58:50 --> Security Class Initialized
INFO - 2018-05-11 21:58:50 --> Router Class Initialized
INFO - 2018-05-11 21:58:50 --> Router Class Initialized
INFO - 2018-05-11 21:58:50 --> Router Class Initialized
INFO - 2018-05-11 21:58:50 --> Router Class Initialized
DEBUG - 2018-05-11 21:58:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 21:58:50 --> Output Class Initialized
INFO - 2018-05-11 21:58:50 --> Output Class Initialized
INFO - 2018-05-11 21:58:50 --> Output Class Initialized
INFO - 2018-05-11 21:58:50 --> Security Class Initialized
INFO - 2018-05-11 21:58:50 --> Input Class Initialized
INFO - 2018-05-11 21:58:50 --> Output Class Initialized
INFO - 2018-05-11 21:58:50 --> Security Class Initialized
INFO - 2018-05-11 21:58:50 --> Language Class Initialized
INFO - 2018-05-11 21:58:50 --> Security Class Initialized
INFO - 2018-05-11 21:58:50 --> Security Class Initialized
DEBUG - 2018-05-11 21:58:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-05-11 21:58:50 --> 404 Page Not Found: /index
DEBUG - 2018-05-11 21:58:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-11 21:58:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-11 21:58:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 21:58:50 --> Input Class Initialized
INFO - 2018-05-11 21:58:50 --> Input Class Initialized
INFO - 2018-05-11 21:58:50 --> Input Class Initialized
INFO - 2018-05-11 21:58:50 --> Input Class Initialized
INFO - 2018-05-11 21:58:50 --> Language Class Initialized
INFO - 2018-05-11 21:58:50 --> Language Class Initialized
INFO - 2018-05-11 21:58:50 --> Language Class Initialized
INFO - 2018-05-11 21:58:50 --> Language Class Initialized
ERROR - 2018-05-11 21:58:50 --> 404 Page Not Found: /index
ERROR - 2018-05-11 21:58:50 --> 404 Page Not Found: /index
ERROR - 2018-05-11 21:58:50 --> 404 Page Not Found: /index
ERROR - 2018-05-11 21:58:50 --> 404 Page Not Found: /index
INFO - 2018-05-11 21:58:50 --> Config Class Initialized
INFO - 2018-05-11 21:58:51 --> Config Class Initialized
INFO - 2018-05-11 21:58:51 --> Config Class Initialized
INFO - 2018-05-11 21:58:51 --> Config Class Initialized
INFO - 2018-05-11 21:58:51 --> Config Class Initialized
INFO - 2018-05-11 21:58:51 --> Hooks Class Initialized
INFO - 2018-05-11 21:58:51 --> Hooks Class Initialized
INFO - 2018-05-11 21:58:51 --> Hooks Class Initialized
INFO - 2018-05-11 21:58:51 --> Hooks Class Initialized
INFO - 2018-05-11 21:58:51 --> Hooks Class Initialized
DEBUG - 2018-05-11 21:58:51 --> UTF-8 Support Enabled
DEBUG - 2018-05-11 21:58:51 --> UTF-8 Support Enabled
DEBUG - 2018-05-11 21:58:51 --> UTF-8 Support Enabled
DEBUG - 2018-05-11 21:58:51 --> UTF-8 Support Enabled
DEBUG - 2018-05-11 21:58:51 --> UTF-8 Support Enabled
INFO - 2018-05-11 21:58:51 --> Utf8 Class Initialized
INFO - 2018-05-11 21:58:51 --> URI Class Initialized
INFO - 2018-05-11 21:58:51 --> Utf8 Class Initialized
INFO - 2018-05-11 21:58:51 --> Utf8 Class Initialized
INFO - 2018-05-11 21:58:51 --> Utf8 Class Initialized
INFO - 2018-05-11 21:58:51 --> Utf8 Class Initialized
INFO - 2018-05-11 21:58:51 --> Router Class Initialized
INFO - 2018-05-11 21:58:51 --> URI Class Initialized
INFO - 2018-05-11 21:58:51 --> URI Class Initialized
INFO - 2018-05-11 21:58:51 --> Output Class Initialized
INFO - 2018-05-11 21:58:51 --> URI Class Initialized
INFO - 2018-05-11 21:58:51 --> URI Class Initialized
INFO - 2018-05-11 21:58:51 --> Router Class Initialized
INFO - 2018-05-11 21:58:51 --> Security Class Initialized
INFO - 2018-05-11 21:58:51 --> Router Class Initialized
INFO - 2018-05-11 21:58:51 --> Router Class Initialized
INFO - 2018-05-11 21:58:51 --> Output Class Initialized
INFO - 2018-05-11 21:58:51 --> Router Class Initialized
DEBUG - 2018-05-11 21:58:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 21:58:51 --> Output Class Initialized
INFO - 2018-05-11 21:58:51 --> Output Class Initialized
INFO - 2018-05-11 21:58:51 --> Security Class Initialized
INFO - 2018-05-11 21:58:51 --> Output Class Initialized
INFO - 2018-05-11 21:58:51 --> Input Class Initialized
INFO - 2018-05-11 21:58:51 --> Security Class Initialized
DEBUG - 2018-05-11 21:58:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 21:58:51 --> Input Class Initialized
INFO - 2018-05-11 21:58:51 --> Language Class Initialized
ERROR - 2018-05-11 21:58:51 --> 404 Page Not Found: /index
INFO - 2018-05-11 21:58:51 --> Security Class Initialized
DEBUG - 2018-05-11 21:58:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 21:58:51 --> Language Class Initialized
INFO - 2018-05-11 21:58:51 --> Input Class Initialized
INFO - 2018-05-11 21:58:51 --> Security Class Initialized
ERROR - 2018-05-11 21:58:51 --> 404 Page Not Found: /index
DEBUG - 2018-05-11 21:58:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-11 21:58:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 21:58:51 --> Language Class Initialized
INFO - 2018-05-11 21:58:51 --> Input Class Initialized
INFO - 2018-05-11 21:58:51 --> Input Class Initialized
INFO - 2018-05-11 21:58:51 --> Language Class Initialized
ERROR - 2018-05-11 21:58:51 --> 404 Page Not Found: /index
INFO - 2018-05-11 21:58:51 --> Language Class Initialized
ERROR - 2018-05-11 21:58:51 --> 404 Page Not Found: /index
ERROR - 2018-05-11 21:58:51 --> 404 Page Not Found: /index
INFO - 2018-05-11 21:59:15 --> Config Class Initialized
INFO - 2018-05-11 21:59:15 --> Hooks Class Initialized
DEBUG - 2018-05-11 21:59:15 --> UTF-8 Support Enabled
INFO - 2018-05-11 21:59:15 --> Utf8 Class Initialized
INFO - 2018-05-11 21:59:15 --> URI Class Initialized
INFO - 2018-05-11 21:59:15 --> Router Class Initialized
INFO - 2018-05-11 21:59:15 --> Output Class Initialized
INFO - 2018-05-11 21:59:15 --> Security Class Initialized
DEBUG - 2018-05-11 21:59:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 21:59:15 --> Input Class Initialized
INFO - 2018-05-11 21:59:15 --> Language Class Initialized
INFO - 2018-05-11 21:59:15 --> Language Class Initialized
INFO - 2018-05-11 21:59:15 --> Config Class Initialized
INFO - 2018-05-11 21:59:15 --> Loader Class Initialized
DEBUG - 2018-05-11 21:59:15 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-11 21:59:15 --> Helper loaded: url_helper
INFO - 2018-05-11 21:59:15 --> Helper loaded: form_helper
INFO - 2018-05-11 21:59:15 --> Helper loaded: date_helper
INFO - 2018-05-11 21:59:15 --> Helper loaded: util_helper
INFO - 2018-05-11 21:59:15 --> Helper loaded: text_helper
INFO - 2018-05-11 21:59:15 --> Helper loaded: string_helper
INFO - 2018-05-11 21:59:15 --> Database Driver Class Initialized
DEBUG - 2018-05-11 21:59:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-11 21:59:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-11 21:59:15 --> Email Class Initialized
INFO - 2018-05-11 21:59:15 --> Controller Class Initialized
DEBUG - 2018-05-11 21:59:15 --> Login MX_Controller Initialized
INFO - 2018-05-11 21:59:15 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-11 21:59:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-11 21:59:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-11 21:59:15 --> 4 Loggedout
INFO - 2018-05-11 21:59:16 --> Config Class Initialized
INFO - 2018-05-11 21:59:16 --> Hooks Class Initialized
DEBUG - 2018-05-11 21:59:16 --> UTF-8 Support Enabled
INFO - 2018-05-11 21:59:16 --> Utf8 Class Initialized
INFO - 2018-05-11 21:59:16 --> URI Class Initialized
INFO - 2018-05-11 21:59:16 --> Router Class Initialized
INFO - 2018-05-11 21:59:16 --> Output Class Initialized
INFO - 2018-05-11 21:59:16 --> Security Class Initialized
DEBUG - 2018-05-11 21:59:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 21:59:16 --> Input Class Initialized
INFO - 2018-05-11 21:59:16 --> Language Class Initialized
INFO - 2018-05-11 21:59:16 --> Language Class Initialized
INFO - 2018-05-11 21:59:16 --> Config Class Initialized
INFO - 2018-05-11 21:59:16 --> Loader Class Initialized
DEBUG - 2018-05-11 21:59:16 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-11 21:59:16 --> Helper loaded: url_helper
INFO - 2018-05-11 21:59:16 --> Helper loaded: form_helper
INFO - 2018-05-11 21:59:16 --> Helper loaded: date_helper
INFO - 2018-05-11 21:59:16 --> Helper loaded: util_helper
INFO - 2018-05-11 21:59:16 --> Helper loaded: text_helper
INFO - 2018-05-11 21:59:16 --> Helper loaded: string_helper
INFO - 2018-05-11 21:59:16 --> Database Driver Class Initialized
DEBUG - 2018-05-11 21:59:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-11 21:59:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-11 21:59:16 --> Email Class Initialized
INFO - 2018-05-11 21:59:16 --> Controller Class Initialized
DEBUG - 2018-05-11 21:59:16 --> Home MX_Controller Initialized
DEBUG - 2018-05-11 21:59:16 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-11 21:59:16 --> Login MX_Controller Initialized
INFO - 2018-05-11 21:59:16 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-11 21:59:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-11 21:59:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-11 21:59:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/login.php
INFO - 2018-05-11 21:59:18 --> Config Class Initialized
INFO - 2018-05-11 21:59:18 --> Hooks Class Initialized
DEBUG - 2018-05-11 21:59:18 --> UTF-8 Support Enabled
INFO - 2018-05-11 21:59:18 --> Utf8 Class Initialized
INFO - 2018-05-11 21:59:18 --> URI Class Initialized
INFO - 2018-05-11 21:59:18 --> Router Class Initialized
INFO - 2018-05-11 21:59:18 --> Output Class Initialized
INFO - 2018-05-11 21:59:18 --> Security Class Initialized
DEBUG - 2018-05-11 21:59:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 21:59:18 --> Input Class Initialized
INFO - 2018-05-11 21:59:18 --> Language Class Initialized
INFO - 2018-05-11 21:59:18 --> Language Class Initialized
INFO - 2018-05-11 21:59:18 --> Config Class Initialized
INFO - 2018-05-11 21:59:18 --> Loader Class Initialized
DEBUG - 2018-05-11 21:59:18 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-11 21:59:18 --> Helper loaded: url_helper
INFO - 2018-05-11 21:59:18 --> Helper loaded: form_helper
INFO - 2018-05-11 21:59:18 --> Helper loaded: date_helper
INFO - 2018-05-11 21:59:18 --> Helper loaded: util_helper
INFO - 2018-05-11 21:59:18 --> Helper loaded: text_helper
INFO - 2018-05-11 21:59:18 --> Helper loaded: string_helper
INFO - 2018-05-11 21:59:18 --> Database Driver Class Initialized
DEBUG - 2018-05-11 21:59:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-11 21:59:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-11 21:59:18 --> Email Class Initialized
INFO - 2018-05-11 21:59:18 --> Controller Class Initialized
DEBUG - 2018-05-11 21:59:18 --> Login MX_Controller Initialized
INFO - 2018-05-11 21:59:18 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-11 21:59:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-11 21:59:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-11 21:59:18 --> Email starts for gopipanguluri123@gmail.com fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-05-11 21:59:19 --> User session created for 4
INFO - 2018-05-11 21:59:19 --> Login status gopipanguluri123@gmail.com - success
INFO - 2018-05-11 21:59:19 --> Final output sent to browser
DEBUG - 2018-05-11 21:59:19 --> Total execution time: 0.5839
INFO - 2018-05-11 21:59:19 --> Config Class Initialized
INFO - 2018-05-11 21:59:19 --> Hooks Class Initialized
DEBUG - 2018-05-11 21:59:19 --> UTF-8 Support Enabled
INFO - 2018-05-11 21:59:19 --> Utf8 Class Initialized
INFO - 2018-05-11 21:59:19 --> URI Class Initialized
INFO - 2018-05-11 21:59:19 --> Router Class Initialized
INFO - 2018-05-11 21:59:19 --> Output Class Initialized
INFO - 2018-05-11 21:59:19 --> Security Class Initialized
DEBUG - 2018-05-11 21:59:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 21:59:19 --> Input Class Initialized
INFO - 2018-05-11 21:59:19 --> Language Class Initialized
INFO - 2018-05-11 21:59:19 --> Language Class Initialized
INFO - 2018-05-11 21:59:19 --> Config Class Initialized
INFO - 2018-05-11 21:59:19 --> Loader Class Initialized
DEBUG - 2018-05-11 21:59:19 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-11 21:59:19 --> Helper loaded: url_helper
INFO - 2018-05-11 21:59:19 --> Helper loaded: form_helper
INFO - 2018-05-11 21:59:19 --> Helper loaded: date_helper
INFO - 2018-05-11 21:59:19 --> Helper loaded: util_helper
INFO - 2018-05-11 21:59:19 --> Helper loaded: text_helper
INFO - 2018-05-11 21:59:19 --> Helper loaded: string_helper
INFO - 2018-05-11 21:59:19 --> Database Driver Class Initialized
DEBUG - 2018-05-11 21:59:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-11 21:59:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-11 21:59:19 --> Email Class Initialized
INFO - 2018-05-11 21:59:19 --> Controller Class Initialized
DEBUG - 2018-05-11 21:59:19 --> Home MX_Controller Initialized
DEBUG - 2018-05-11 21:59:19 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-11 21:59:19 --> Login MX_Controller Initialized
INFO - 2018-05-11 21:59:19 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-11 21:59:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-11 21:59:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-11 21:59:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-05-11 21:59:19 --> Final output sent to browser
DEBUG - 2018-05-11 21:59:19 --> Total execution time: 0.5691
INFO - 2018-05-11 21:59:19 --> Config Class Initialized
INFO - 2018-05-11 21:59:19 --> Hooks Class Initialized
DEBUG - 2018-05-11 21:59:19 --> UTF-8 Support Enabled
INFO - 2018-05-11 21:59:19 --> Utf8 Class Initialized
INFO - 2018-05-11 21:59:19 --> URI Class Initialized
INFO - 2018-05-11 21:59:19 --> Router Class Initialized
INFO - 2018-05-11 21:59:19 --> Output Class Initialized
INFO - 2018-05-11 21:59:19 --> Security Class Initialized
DEBUG - 2018-05-11 21:59:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 21:59:20 --> Input Class Initialized
INFO - 2018-05-11 21:59:20 --> Language Class Initialized
ERROR - 2018-05-11 21:59:20 --> 404 Page Not Found: /index
INFO - 2018-05-11 21:59:20 --> Config Class Initialized
INFO - 2018-05-11 21:59:20 --> Hooks Class Initialized
INFO - 2018-05-11 21:59:20 --> Config Class Initialized
INFO - 2018-05-11 21:59:20 --> Config Class Initialized
INFO - 2018-05-11 21:59:20 --> Config Class Initialized
INFO - 2018-05-11 21:59:20 --> Hooks Class Initialized
INFO - 2018-05-11 21:59:20 --> Hooks Class Initialized
INFO - 2018-05-11 21:59:20 --> Hooks Class Initialized
INFO - 2018-05-11 21:59:20 --> Config Class Initialized
DEBUG - 2018-05-11 21:59:20 --> UTF-8 Support Enabled
INFO - 2018-05-11 21:59:20 --> Config Class Initialized
DEBUG - 2018-05-11 21:59:20 --> UTF-8 Support Enabled
DEBUG - 2018-05-11 21:59:20 --> UTF-8 Support Enabled
INFO - 2018-05-11 21:59:20 --> Hooks Class Initialized
INFO - 2018-05-11 21:59:20 --> Utf8 Class Initialized
INFO - 2018-05-11 21:59:20 --> Hooks Class Initialized
DEBUG - 2018-05-11 21:59:20 --> UTF-8 Support Enabled
INFO - 2018-05-11 21:59:20 --> Utf8 Class Initialized
INFO - 2018-05-11 21:59:20 --> URI Class Initialized
INFO - 2018-05-11 21:59:20 --> Utf8 Class Initialized
INFO - 2018-05-11 21:59:20 --> URI Class Initialized
DEBUG - 2018-05-11 21:59:20 --> UTF-8 Support Enabled
DEBUG - 2018-05-11 21:59:20 --> UTF-8 Support Enabled
INFO - 2018-05-11 21:59:20 --> Utf8 Class Initialized
INFO - 2018-05-11 21:59:20 --> Router Class Initialized
INFO - 2018-05-11 21:59:20 --> URI Class Initialized
INFO - 2018-05-11 21:59:20 --> Utf8 Class Initialized
INFO - 2018-05-11 21:59:20 --> Output Class Initialized
INFO - 2018-05-11 21:59:20 --> Utf8 Class Initialized
INFO - 2018-05-11 21:59:20 --> Router Class Initialized
INFO - 2018-05-11 21:59:20 --> Router Class Initialized
INFO - 2018-05-11 21:59:20 --> URI Class Initialized
INFO - 2018-05-11 21:59:20 --> Security Class Initialized
INFO - 2018-05-11 21:59:20 --> URI Class Initialized
INFO - 2018-05-11 21:59:20 --> URI Class Initialized
INFO - 2018-05-11 21:59:20 --> Output Class Initialized
INFO - 2018-05-11 21:59:20 --> Router Class Initialized
DEBUG - 2018-05-11 21:59:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 21:59:20 --> Router Class Initialized
INFO - 2018-05-11 21:59:20 --> Output Class Initialized
INFO - 2018-05-11 21:59:20 --> Router Class Initialized
INFO - 2018-05-11 21:59:20 --> Security Class Initialized
INFO - 2018-05-11 21:59:20 --> Output Class Initialized
INFO - 2018-05-11 21:59:20 --> Security Class Initialized
INFO - 2018-05-11 21:59:20 --> Input Class Initialized
INFO - 2018-05-11 21:59:20 --> Security Class Initialized
DEBUG - 2018-05-11 21:59:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 21:59:20 --> Output Class Initialized
INFO - 2018-05-11 21:59:20 --> Output Class Initialized
DEBUG - 2018-05-11 21:59:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 21:59:20 --> Language Class Initialized
INFO - 2018-05-11 21:59:20 --> Input Class Initialized
INFO - 2018-05-11 21:59:20 --> Security Class Initialized
INFO - 2018-05-11 21:59:20 --> Security Class Initialized
INFO - 2018-05-11 21:59:20 --> Input Class Initialized
DEBUG - 2018-05-11 21:59:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-05-11 21:59:20 --> 404 Page Not Found: /index
INFO - 2018-05-11 21:59:20 --> Language Class Initialized
ERROR - 2018-05-11 21:59:20 --> 404 Page Not Found: /index
INFO - 2018-05-11 21:59:20 --> Input Class Initialized
INFO - 2018-05-11 21:59:21 --> Config Class Initialized
INFO - 2018-05-11 21:59:21 --> Config Class Initialized
INFO - 2018-05-11 21:59:21 --> Hooks Class Initialized
INFO - 2018-05-11 21:59:21 --> Hooks Class Initialized
INFO - 2018-05-11 21:59:21 --> Language Class Initialized
DEBUG - 2018-05-11 21:59:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-11 21:59:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 21:59:21 --> Language Class Initialized
DEBUG - 2018-05-11 21:59:21 --> UTF-8 Support Enabled
INFO - 2018-05-11 21:59:21 --> Utf8 Class Initialized
ERROR - 2018-05-11 21:59:21 --> 404 Page Not Found: /index
INFO - 2018-05-11 21:59:21 --> Input Class Initialized
INFO - 2018-05-11 21:59:21 --> Input Class Initialized
ERROR - 2018-05-11 21:59:21 --> 404 Page Not Found: /index
DEBUG - 2018-05-11 21:59:21 --> UTF-8 Support Enabled
INFO - 2018-05-11 21:59:21 --> URI Class Initialized
INFO - 2018-05-11 21:59:21 --> Router Class Initialized
INFO - 2018-05-11 21:59:21 --> Output Class Initialized
INFO - 2018-05-11 21:59:21 --> Language Class Initialized
INFO - 2018-05-11 21:59:21 --> Language Class Initialized
INFO - 2018-05-11 21:59:21 --> Utf8 Class Initialized
INFO - 2018-05-11 21:59:21 --> Security Class Initialized
INFO - 2018-05-11 21:59:21 --> Config Class Initialized
INFO - 2018-05-11 21:59:21 --> Hooks Class Initialized
ERROR - 2018-05-11 21:59:21 --> 404 Page Not Found: /index
DEBUG - 2018-05-11 21:59:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 21:59:21 --> URI Class Initialized
ERROR - 2018-05-11 21:59:21 --> 404 Page Not Found: /index
INFO - 2018-05-11 21:59:21 --> Input Class Initialized
INFO - 2018-05-11 21:59:21 --> Router Class Initialized
INFO - 2018-05-11 21:59:21 --> Config Class Initialized
INFO - 2018-05-11 21:59:21 --> Config Class Initialized
DEBUG - 2018-05-11 21:59:21 --> UTF-8 Support Enabled
INFO - 2018-05-11 21:59:21 --> Hooks Class Initialized
INFO - 2018-05-11 21:59:21 --> Hooks Class Initialized
INFO - 2018-05-11 21:59:21 --> Language Class Initialized
INFO - 2018-05-11 21:59:21 --> Utf8 Class Initialized
INFO - 2018-05-11 21:59:21 --> Output Class Initialized
DEBUG - 2018-05-11 21:59:21 --> UTF-8 Support Enabled
INFO - 2018-05-11 21:59:21 --> Utf8 Class Initialized
INFO - 2018-05-11 21:59:21 --> URI Class Initialized
INFO - 2018-05-11 21:59:21 --> Router Class Initialized
ERROR - 2018-05-11 21:59:21 --> 404 Page Not Found: /index
INFO - 2018-05-11 21:59:21 --> URI Class Initialized
DEBUG - 2018-05-11 21:59:21 --> UTF-8 Support Enabled
INFO - 2018-05-11 21:59:21 --> Security Class Initialized
INFO - 2018-05-11 21:59:21 --> Output Class Initialized
INFO - 2018-05-11 21:59:21 --> Security Class Initialized
INFO - 2018-05-11 21:59:21 --> Utf8 Class Initialized
DEBUG - 2018-05-11 21:59:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 21:59:21 --> Router Class Initialized
INFO - 2018-05-11 21:59:21 --> URI Class Initialized
INFO - 2018-05-11 21:59:21 --> Input Class Initialized
DEBUG - 2018-05-11 21:59:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 21:59:21 --> Output Class Initialized
INFO - 2018-05-11 21:59:21 --> Router Class Initialized
INFO - 2018-05-11 21:59:21 --> Input Class Initialized
INFO - 2018-05-11 21:59:21 --> Language Class Initialized
INFO - 2018-05-11 21:59:21 --> Security Class Initialized
INFO - 2018-05-11 21:59:21 --> Output Class Initialized
DEBUG - 2018-05-11 21:59:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 21:59:21 --> Language Class Initialized
INFO - 2018-05-11 21:59:21 --> Security Class Initialized
ERROR - 2018-05-11 21:59:21 --> 404 Page Not Found: /index
INFO - 2018-05-11 21:59:21 --> Input Class Initialized
INFO - 2018-05-11 21:59:21 --> Language Class Initialized
DEBUG - 2018-05-11 21:59:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 21:59:21 --> Input Class Initialized
ERROR - 2018-05-11 21:59:21 --> 404 Page Not Found: /index
ERROR - 2018-05-11 21:59:21 --> 404 Page Not Found: /index
INFO - 2018-05-11 21:59:21 --> Language Class Initialized
ERROR - 2018-05-11 21:59:21 --> 404 Page Not Found: /index
INFO - 2018-05-11 21:59:22 --> Config Class Initialized
INFO - 2018-05-11 21:59:22 --> Config Class Initialized
INFO - 2018-05-11 21:59:22 --> Config Class Initialized
INFO - 2018-05-11 21:59:22 --> Config Class Initialized
INFO - 2018-05-11 21:59:22 --> Hooks Class Initialized
INFO - 2018-05-11 21:59:22 --> Hooks Class Initialized
INFO - 2018-05-11 21:59:22 --> Hooks Class Initialized
INFO - 2018-05-11 21:59:22 --> Hooks Class Initialized
DEBUG - 2018-05-11 21:59:22 --> UTF-8 Support Enabled
DEBUG - 2018-05-11 21:59:22 --> UTF-8 Support Enabled
INFO - 2018-05-11 21:59:22 --> Utf8 Class Initialized
DEBUG - 2018-05-11 21:59:22 --> UTF-8 Support Enabled
DEBUG - 2018-05-11 21:59:22 --> UTF-8 Support Enabled
INFO - 2018-05-11 21:59:22 --> Config Class Initialized
INFO - 2018-05-11 21:59:22 --> URI Class Initialized
INFO - 2018-05-11 21:59:22 --> Utf8 Class Initialized
INFO - 2018-05-11 21:59:22 --> Utf8 Class Initialized
INFO - 2018-05-11 21:59:22 --> Utf8 Class Initialized
INFO - 2018-05-11 21:59:22 --> Hooks Class Initialized
INFO - 2018-05-11 21:59:22 --> URI Class Initialized
INFO - 2018-05-11 21:59:22 --> URI Class Initialized
INFO - 2018-05-11 21:59:22 --> URI Class Initialized
INFO - 2018-05-11 21:59:22 --> Router Class Initialized
DEBUG - 2018-05-11 21:59:22 --> UTF-8 Support Enabled
INFO - 2018-05-11 21:59:22 --> Router Class Initialized
INFO - 2018-05-11 21:59:22 --> Router Class Initialized
INFO - 2018-05-11 21:59:22 --> Output Class Initialized
INFO - 2018-05-11 21:59:22 --> Security Class Initialized
DEBUG - 2018-05-11 21:59:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 21:59:22 --> Input Class Initialized
INFO - 2018-05-11 21:59:22 --> Language Class Initialized
ERROR - 2018-05-11 21:59:22 --> 404 Page Not Found: /index
INFO - 2018-05-11 21:59:22 --> Utf8 Class Initialized
INFO - 2018-05-11 21:59:22 --> Output Class Initialized
INFO - 2018-05-11 21:59:22 --> Output Class Initialized
INFO - 2018-05-11 21:59:22 --> Router Class Initialized
INFO - 2018-05-11 21:59:22 --> Security Class Initialized
INFO - 2018-05-11 21:59:22 --> Security Class Initialized
INFO - 2018-05-11 21:59:22 --> URI Class Initialized
INFO - 2018-05-11 21:59:22 --> Output Class Initialized
DEBUG - 2018-05-11 21:59:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-11 21:59:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 21:59:22 --> Security Class Initialized
INFO - 2018-05-11 21:59:22 --> Router Class Initialized
INFO - 2018-05-11 21:59:22 --> Input Class Initialized
INFO - 2018-05-11 21:59:22 --> Input Class Initialized
DEBUG - 2018-05-11 21:59:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 21:59:22 --> Output Class Initialized
INFO - 2018-05-11 21:59:22 --> Input Class Initialized
INFO - 2018-05-11 21:59:22 --> Language Class Initialized
INFO - 2018-05-11 21:59:22 --> Language Class Initialized
INFO - 2018-05-11 21:59:22 --> Security Class Initialized
ERROR - 2018-05-11 21:59:22 --> 404 Page Not Found: /index
INFO - 2018-05-11 21:59:22 --> Language Class Initialized
DEBUG - 2018-05-11 21:59:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-05-11 21:59:22 --> 404 Page Not Found: /index
ERROR - 2018-05-11 21:59:22 --> 404 Page Not Found: /index
INFO - 2018-05-11 21:59:22 --> Input Class Initialized
INFO - 2018-05-11 21:59:22 --> Language Class Initialized
ERROR - 2018-05-11 21:59:22 --> 404 Page Not Found: /index
INFO - 2018-05-11 21:59:30 --> Config Class Initialized
INFO - 2018-05-11 21:59:30 --> Hooks Class Initialized
DEBUG - 2018-05-11 21:59:30 --> UTF-8 Support Enabled
INFO - 2018-05-11 21:59:30 --> Utf8 Class Initialized
INFO - 2018-05-11 21:59:30 --> URI Class Initialized
INFO - 2018-05-11 21:59:30 --> Router Class Initialized
INFO - 2018-05-11 21:59:30 --> Output Class Initialized
INFO - 2018-05-11 21:59:30 --> Security Class Initialized
DEBUG - 2018-05-11 21:59:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 21:59:30 --> Input Class Initialized
INFO - 2018-05-11 21:59:30 --> Language Class Initialized
INFO - 2018-05-11 21:59:30 --> Language Class Initialized
INFO - 2018-05-11 21:59:30 --> Config Class Initialized
INFO - 2018-05-11 21:59:30 --> Loader Class Initialized
DEBUG - 2018-05-11 21:59:30 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-11 21:59:30 --> Helper loaded: url_helper
INFO - 2018-05-11 21:59:30 --> Helper loaded: form_helper
INFO - 2018-05-11 21:59:30 --> Helper loaded: date_helper
INFO - 2018-05-11 21:59:30 --> Helper loaded: util_helper
INFO - 2018-05-11 21:59:30 --> Helper loaded: text_helper
INFO - 2018-05-11 21:59:30 --> Helper loaded: string_helper
INFO - 2018-05-11 21:59:30 --> Database Driver Class Initialized
DEBUG - 2018-05-11 21:59:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-11 21:59:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-11 21:59:31 --> Email Class Initialized
INFO - 2018-05-11 21:59:31 --> Controller Class Initialized
DEBUG - 2018-05-11 21:59:31 --> Login MX_Controller Initialized
INFO - 2018-05-11 21:59:31 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-11 21:59:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-11 21:59:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-11 21:59:31 --> 4 Loggedout
INFO - 2018-05-11 21:59:31 --> Config Class Initialized
INFO - 2018-05-11 21:59:31 --> Hooks Class Initialized
DEBUG - 2018-05-11 21:59:31 --> UTF-8 Support Enabled
INFO - 2018-05-11 21:59:31 --> Utf8 Class Initialized
INFO - 2018-05-11 21:59:31 --> URI Class Initialized
INFO - 2018-05-11 21:59:31 --> Router Class Initialized
INFO - 2018-05-11 21:59:31 --> Output Class Initialized
INFO - 2018-05-11 21:59:31 --> Security Class Initialized
DEBUG - 2018-05-11 21:59:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 21:59:31 --> Input Class Initialized
INFO - 2018-05-11 21:59:31 --> Language Class Initialized
INFO - 2018-05-11 21:59:31 --> Language Class Initialized
INFO - 2018-05-11 21:59:31 --> Config Class Initialized
INFO - 2018-05-11 21:59:31 --> Loader Class Initialized
DEBUG - 2018-05-11 21:59:31 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-11 21:59:31 --> Helper loaded: url_helper
INFO - 2018-05-11 21:59:31 --> Helper loaded: form_helper
INFO - 2018-05-11 21:59:31 --> Helper loaded: date_helper
INFO - 2018-05-11 21:59:31 --> Helper loaded: util_helper
INFO - 2018-05-11 21:59:31 --> Helper loaded: text_helper
INFO - 2018-05-11 21:59:31 --> Helper loaded: string_helper
INFO - 2018-05-11 21:59:31 --> Database Driver Class Initialized
DEBUG - 2018-05-11 21:59:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-11 21:59:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-11 21:59:31 --> Email Class Initialized
INFO - 2018-05-11 21:59:31 --> Controller Class Initialized
DEBUG - 2018-05-11 21:59:31 --> Home MX_Controller Initialized
DEBUG - 2018-05-11 21:59:31 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-11 21:59:31 --> Login MX_Controller Initialized
INFO - 2018-05-11 21:59:31 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-11 21:59:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-11 21:59:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-11 21:59:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/login.php
INFO - 2018-05-11 21:59:36 --> Config Class Initialized
INFO - 2018-05-11 21:59:36 --> Hooks Class Initialized
DEBUG - 2018-05-11 21:59:36 --> UTF-8 Support Enabled
INFO - 2018-05-11 21:59:36 --> Utf8 Class Initialized
INFO - 2018-05-11 21:59:36 --> URI Class Initialized
INFO - 2018-05-11 21:59:36 --> Router Class Initialized
INFO - 2018-05-11 21:59:36 --> Output Class Initialized
INFO - 2018-05-11 21:59:36 --> Security Class Initialized
DEBUG - 2018-05-11 21:59:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 21:59:36 --> Input Class Initialized
INFO - 2018-05-11 21:59:36 --> Language Class Initialized
INFO - 2018-05-11 21:59:36 --> Language Class Initialized
INFO - 2018-05-11 21:59:36 --> Config Class Initialized
INFO - 2018-05-11 21:59:36 --> Loader Class Initialized
DEBUG - 2018-05-11 21:59:36 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-11 21:59:36 --> Helper loaded: url_helper
INFO - 2018-05-11 21:59:36 --> Helper loaded: form_helper
INFO - 2018-05-11 21:59:36 --> Helper loaded: date_helper
INFO - 2018-05-11 21:59:36 --> Helper loaded: util_helper
INFO - 2018-05-11 21:59:36 --> Helper loaded: text_helper
INFO - 2018-05-11 21:59:36 --> Helper loaded: string_helper
INFO - 2018-05-11 21:59:36 --> Database Driver Class Initialized
DEBUG - 2018-05-11 21:59:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-11 21:59:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-11 21:59:36 --> Email Class Initialized
INFO - 2018-05-11 21:59:36 --> Controller Class Initialized
DEBUG - 2018-05-11 21:59:36 --> Login MX_Controller Initialized
INFO - 2018-05-11 21:59:36 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-11 21:59:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-11 21:59:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-11 21:59:36 --> Email starts for gopipanguluri123@gmail.com fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-05-11 21:59:36 --> User session created for 4
INFO - 2018-05-11 21:59:37 --> Login status gopipanguluri123@gmail.com - success
INFO - 2018-05-11 21:59:37 --> Final output sent to browser
DEBUG - 2018-05-11 21:59:37 --> Total execution time: 0.5825
INFO - 2018-05-11 21:59:37 --> Config Class Initialized
INFO - 2018-05-11 21:59:37 --> Hooks Class Initialized
DEBUG - 2018-05-11 21:59:37 --> UTF-8 Support Enabled
INFO - 2018-05-11 21:59:37 --> Utf8 Class Initialized
INFO - 2018-05-11 21:59:37 --> URI Class Initialized
INFO - 2018-05-11 21:59:37 --> Router Class Initialized
INFO - 2018-05-11 21:59:37 --> Output Class Initialized
INFO - 2018-05-11 21:59:37 --> Security Class Initialized
DEBUG - 2018-05-11 21:59:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 21:59:37 --> Input Class Initialized
INFO - 2018-05-11 21:59:37 --> Language Class Initialized
INFO - 2018-05-11 21:59:37 --> Language Class Initialized
INFO - 2018-05-11 21:59:37 --> Config Class Initialized
INFO - 2018-05-11 21:59:37 --> Loader Class Initialized
DEBUG - 2018-05-11 21:59:37 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-11 21:59:37 --> Helper loaded: url_helper
INFO - 2018-05-11 21:59:37 --> Helper loaded: form_helper
INFO - 2018-05-11 21:59:37 --> Helper loaded: date_helper
INFO - 2018-05-11 21:59:37 --> Helper loaded: util_helper
INFO - 2018-05-11 21:59:37 --> Helper loaded: text_helper
INFO - 2018-05-11 21:59:37 --> Helper loaded: string_helper
INFO - 2018-05-11 21:59:37 --> Database Driver Class Initialized
DEBUG - 2018-05-11 21:59:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-11 21:59:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-11 21:59:37 --> Email Class Initialized
INFO - 2018-05-11 21:59:37 --> Controller Class Initialized
DEBUG - 2018-05-11 21:59:37 --> Home MX_Controller Initialized
DEBUG - 2018-05-11 21:59:37 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-11 21:59:37 --> Login MX_Controller Initialized
INFO - 2018-05-11 21:59:37 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-11 21:59:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-11 21:59:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-11 21:59:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-05-11 21:59:37 --> Final output sent to browser
DEBUG - 2018-05-11 21:59:37 --> Total execution time: 0.5711
INFO - 2018-05-11 21:59:37 --> Config Class Initialized
INFO - 2018-05-11 21:59:37 --> Hooks Class Initialized
DEBUG - 2018-05-11 21:59:37 --> UTF-8 Support Enabled
INFO - 2018-05-11 21:59:37 --> Utf8 Class Initialized
INFO - 2018-05-11 21:59:37 --> URI Class Initialized
INFO - 2018-05-11 21:59:37 --> Router Class Initialized
INFO - 2018-05-11 21:59:37 --> Output Class Initialized
INFO - 2018-05-11 21:59:37 --> Security Class Initialized
DEBUG - 2018-05-11 21:59:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 21:59:37 --> Input Class Initialized
INFO - 2018-05-11 21:59:38 --> Language Class Initialized
ERROR - 2018-05-11 21:59:38 --> 404 Page Not Found: /index
INFO - 2018-05-11 21:59:38 --> Config Class Initialized
INFO - 2018-05-11 21:59:38 --> Config Class Initialized
INFO - 2018-05-11 21:59:38 --> Hooks Class Initialized
INFO - 2018-05-11 21:59:38 --> Hooks Class Initialized
INFO - 2018-05-11 21:59:38 --> Config Class Initialized
INFO - 2018-05-11 21:59:38 --> Config Class Initialized
DEBUG - 2018-05-11 21:59:38 --> UTF-8 Support Enabled
INFO - 2018-05-11 21:59:38 --> Hooks Class Initialized
INFO - 2018-05-11 21:59:38 --> Config Class Initialized
DEBUG - 2018-05-11 21:59:38 --> UTF-8 Support Enabled
INFO - 2018-05-11 21:59:38 --> Hooks Class Initialized
INFO - 2018-05-11 21:59:38 --> Config Class Initialized
INFO - 2018-05-11 21:59:38 --> Hooks Class Initialized
INFO - 2018-05-11 21:59:38 --> Utf8 Class Initialized
INFO - 2018-05-11 21:59:38 --> Hooks Class Initialized
INFO - 2018-05-11 21:59:38 --> Utf8 Class Initialized
DEBUG - 2018-05-11 21:59:38 --> UTF-8 Support Enabled
DEBUG - 2018-05-11 21:59:38 --> UTF-8 Support Enabled
DEBUG - 2018-05-11 21:59:38 --> UTF-8 Support Enabled
INFO - 2018-05-11 21:59:38 --> Utf8 Class Initialized
INFO - 2018-05-11 21:59:38 --> Utf8 Class Initialized
INFO - 2018-05-11 21:59:38 --> URI Class Initialized
DEBUG - 2018-05-11 21:59:38 --> UTF-8 Support Enabled
INFO - 2018-05-11 21:59:38 --> Utf8 Class Initialized
INFO - 2018-05-11 21:59:38 --> URI Class Initialized
INFO - 2018-05-11 21:59:38 --> URI Class Initialized
INFO - 2018-05-11 21:59:38 --> URI Class Initialized
INFO - 2018-05-11 21:59:38 --> Utf8 Class Initialized
INFO - 2018-05-11 21:59:38 --> Router Class Initialized
INFO - 2018-05-11 21:59:38 --> URI Class Initialized
INFO - 2018-05-11 21:59:38 --> Router Class Initialized
INFO - 2018-05-11 21:59:38 --> Router Class Initialized
INFO - 2018-05-11 21:59:38 --> URI Class Initialized
INFO - 2018-05-11 21:59:38 --> Output Class Initialized
INFO - 2018-05-11 21:59:38 --> Router Class Initialized
INFO - 2018-05-11 21:59:38 --> Output Class Initialized
INFO - 2018-05-11 21:59:38 --> Output Class Initialized
INFO - 2018-05-11 21:59:38 --> Router Class Initialized
INFO - 2018-05-11 21:59:38 --> Router Class Initialized
INFO - 2018-05-11 21:59:38 --> Output Class Initialized
INFO - 2018-05-11 21:59:38 --> Security Class Initialized
DEBUG - 2018-05-11 21:59:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 21:59:38 --> Input Class Initialized
INFO - 2018-05-11 21:59:39 --> Language Class Initialized
ERROR - 2018-05-11 21:59:39 --> 404 Page Not Found: /index
INFO - 2018-05-11 21:59:39 --> Output Class Initialized
INFO - 2018-05-11 21:59:39 --> Security Class Initialized
INFO - 2018-05-11 21:59:39 --> Security Class Initialized
INFO - 2018-05-11 21:59:39 --> Output Class Initialized
INFO - 2018-05-11 21:59:39 --> Security Class Initialized
INFO - 2018-05-11 21:59:39 --> Security Class Initialized
DEBUG - 2018-05-11 21:59:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 21:59:39 --> Input Class Initialized
DEBUG - 2018-05-11 21:59:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-11 21:59:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 21:59:39 --> Security Class Initialized
DEBUG - 2018-05-11 21:59:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 21:59:39 --> Language Class Initialized
INFO - 2018-05-11 21:59:39 --> Input Class Initialized
INFO - 2018-05-11 21:59:39 --> Language Class Initialized
ERROR - 2018-05-11 21:59:39 --> 404 Page Not Found: /index
INFO - 2018-05-11 21:59:39 --> Input Class Initialized
ERROR - 2018-05-11 21:59:39 --> 404 Page Not Found: /index
INFO - 2018-05-11 21:59:39 --> Input Class Initialized
DEBUG - 2018-05-11 21:59:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 21:59:39 --> Input Class Initialized
INFO - 2018-05-11 21:59:39 --> Language Class Initialized
INFO - 2018-05-11 21:59:39 --> Language Class Initialized
ERROR - 2018-05-11 21:59:39 --> 404 Page Not Found: /index
INFO - 2018-05-11 21:59:39 --> Language Class Initialized
ERROR - 2018-05-11 21:59:39 --> 404 Page Not Found: /index
ERROR - 2018-05-11 21:59:39 --> 404 Page Not Found: /index
INFO - 2018-05-11 21:59:39 --> Config Class Initialized
INFO - 2018-05-11 21:59:39 --> Hooks Class Initialized
DEBUG - 2018-05-11 21:59:39 --> UTF-8 Support Enabled
INFO - 2018-05-11 21:59:39 --> Config Class Initialized
INFO - 2018-05-11 21:59:39 --> Utf8 Class Initialized
INFO - 2018-05-11 21:59:39 --> URI Class Initialized
INFO - 2018-05-11 21:59:39 --> Config Class Initialized
INFO - 2018-05-11 21:59:39 --> Config Class Initialized
INFO - 2018-05-11 21:59:39 --> Hooks Class Initialized
INFO - 2018-05-11 21:59:39 --> Hooks Class Initialized
INFO - 2018-05-11 21:59:39 --> Hooks Class Initialized
INFO - 2018-05-11 21:59:39 --> Router Class Initialized
INFO - 2018-05-11 21:59:39 --> Config Class Initialized
INFO - 2018-05-11 21:59:39 --> Hooks Class Initialized
DEBUG - 2018-05-11 21:59:39 --> UTF-8 Support Enabled
INFO - 2018-05-11 21:59:39 --> Output Class Initialized
DEBUG - 2018-05-11 21:59:39 --> UTF-8 Support Enabled
DEBUG - 2018-05-11 21:59:39 --> UTF-8 Support Enabled
INFO - 2018-05-11 21:59:39 --> Utf8 Class Initialized
DEBUG - 2018-05-11 21:59:39 --> UTF-8 Support Enabled
INFO - 2018-05-11 21:59:39 --> Utf8 Class Initialized
INFO - 2018-05-11 21:59:39 --> Utf8 Class Initialized
INFO - 2018-05-11 21:59:39 --> Security Class Initialized
INFO - 2018-05-11 21:59:40 --> Utf8 Class Initialized
INFO - 2018-05-11 21:59:40 --> URI Class Initialized
INFO - 2018-05-11 21:59:40 --> URI Class Initialized
INFO - 2018-05-11 21:59:40 --> URI Class Initialized
DEBUG - 2018-05-11 21:59:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 21:59:40 --> URI Class Initialized
INFO - 2018-05-11 21:59:40 --> Router Class Initialized
INFO - 2018-05-11 21:59:40 --> Input Class Initialized
INFO - 2018-05-11 21:59:40 --> Router Class Initialized
INFO - 2018-05-11 21:59:40 --> Router Class Initialized
INFO - 2018-05-11 21:59:40 --> Router Class Initialized
INFO - 2018-05-11 21:59:40 --> Language Class Initialized
INFO - 2018-05-11 21:59:40 --> Output Class Initialized
INFO - 2018-05-11 21:59:40 --> Output Class Initialized
INFO - 2018-05-11 21:59:40 --> Output Class Initialized
INFO - 2018-05-11 21:59:40 --> Output Class Initialized
ERROR - 2018-05-11 21:59:40 --> 404 Page Not Found: /index
INFO - 2018-05-11 21:59:40 --> Security Class Initialized
DEBUG - 2018-05-11 21:59:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 21:59:40 --> Input Class Initialized
INFO - 2018-05-11 21:59:40 --> Language Class Initialized
ERROR - 2018-05-11 21:59:40 --> 404 Page Not Found: /index
INFO - 2018-05-11 21:59:40 --> Security Class Initialized
DEBUG - 2018-05-11 21:59:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 21:59:40 --> Security Class Initialized
INFO - 2018-05-11 21:59:40 --> Security Class Initialized
INFO - 2018-05-11 21:59:40 --> Input Class Initialized
DEBUG - 2018-05-11 21:59:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-11 21:59:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 21:59:40 --> Input Class Initialized
INFO - 2018-05-11 21:59:40 --> Input Class Initialized
INFO - 2018-05-11 21:59:40 --> Language Class Initialized
INFO - 2018-05-11 21:59:40 --> Language Class Initialized
ERROR - 2018-05-11 21:59:40 --> 404 Page Not Found: /index
INFO - 2018-05-11 21:59:40 --> Language Class Initialized
ERROR - 2018-05-11 21:59:40 --> 404 Page Not Found: /index
INFO - 2018-05-11 21:59:40 --> Config Class Initialized
INFO - 2018-05-11 21:59:40 --> Config Class Initialized
ERROR - 2018-05-11 21:59:40 --> 404 Page Not Found: /index
INFO - 2018-05-11 21:59:40 --> Hooks Class Initialized
INFO - 2018-05-11 21:59:40 --> Hooks Class Initialized
DEBUG - 2018-05-11 21:59:40 --> UTF-8 Support Enabled
DEBUG - 2018-05-11 21:59:40 --> UTF-8 Support Enabled
INFO - 2018-05-11 21:59:40 --> Utf8 Class Initialized
INFO - 2018-05-11 21:59:40 --> Config Class Initialized
INFO - 2018-05-11 21:59:40 --> Hooks Class Initialized
INFO - 2018-05-11 21:59:40 --> URI Class Initialized
INFO - 2018-05-11 21:59:40 --> Utf8 Class Initialized
DEBUG - 2018-05-11 21:59:40 --> UTF-8 Support Enabled
INFO - 2018-05-11 21:59:40 --> Utf8 Class Initialized
INFO - 2018-05-11 21:59:40 --> Config Class Initialized
INFO - 2018-05-11 21:59:40 --> Config Class Initialized
INFO - 2018-05-11 21:59:40 --> URI Class Initialized
INFO - 2018-05-11 21:59:40 --> Router Class Initialized
INFO - 2018-05-11 21:59:40 --> Hooks Class Initialized
INFO - 2018-05-11 21:59:40 --> Hooks Class Initialized
INFO - 2018-05-11 21:59:40 --> URI Class Initialized
INFO - 2018-05-11 21:59:40 --> Router Class Initialized
INFO - 2018-05-11 21:59:40 --> Output Class Initialized
DEBUG - 2018-05-11 21:59:40 --> UTF-8 Support Enabled
DEBUG - 2018-05-11 21:59:40 --> UTF-8 Support Enabled
INFO - 2018-05-11 21:59:40 --> Security Class Initialized
INFO - 2018-05-11 21:59:40 --> Output Class Initialized
INFO - 2018-05-11 21:59:40 --> Router Class Initialized
INFO - 2018-05-11 21:59:40 --> Utf8 Class Initialized
INFO - 2018-05-11 21:59:40 --> Security Class Initialized
INFO - 2018-05-11 21:59:40 --> Output Class Initialized
DEBUG - 2018-05-11 21:59:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 21:59:40 --> Utf8 Class Initialized
INFO - 2018-05-11 21:59:40 --> URI Class Initialized
DEBUG - 2018-05-11 21:59:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 21:59:40 --> Security Class Initialized
INFO - 2018-05-11 21:59:40 --> Input Class Initialized
INFO - 2018-05-11 21:59:40 --> URI Class Initialized
INFO - 2018-05-11 21:59:41 --> Router Class Initialized
INFO - 2018-05-11 21:59:41 --> Language Class Initialized
DEBUG - 2018-05-11 21:59:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 21:59:41 --> Router Class Initialized
INFO - 2018-05-11 21:59:41 --> Input Class Initialized
INFO - 2018-05-11 21:59:41 --> Output Class Initialized
ERROR - 2018-05-11 21:59:41 --> 404 Page Not Found: /index
INFO - 2018-05-11 21:59:41 --> Security Class Initialized
INFO - 2018-05-11 21:59:41 --> Output Class Initialized
INFO - 2018-05-11 21:59:41 --> Language Class Initialized
INFO - 2018-05-11 21:59:41 --> Input Class Initialized
DEBUG - 2018-05-11 21:59:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 21:59:41 --> Language Class Initialized
INFO - 2018-05-11 21:59:41 --> Input Class Initialized
ERROR - 2018-05-11 21:59:41 --> 404 Page Not Found: /index
INFO - 2018-05-11 21:59:41 --> Security Class Initialized
ERROR - 2018-05-11 21:59:41 --> 404 Page Not Found: /index
INFO - 2018-05-11 21:59:41 --> Language Class Initialized
DEBUG - 2018-05-11 21:59:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-05-11 21:59:41 --> 404 Page Not Found: /index
INFO - 2018-05-11 21:59:41 --> Input Class Initialized
INFO - 2018-05-11 21:59:41 --> Language Class Initialized
ERROR - 2018-05-11 21:59:41 --> 404 Page Not Found: /index
INFO - 2018-05-11 21:59:49 --> Config Class Initialized
INFO - 2018-05-11 21:59:49 --> Hooks Class Initialized
DEBUG - 2018-05-11 21:59:49 --> UTF-8 Support Enabled
INFO - 2018-05-11 21:59:49 --> Utf8 Class Initialized
INFO - 2018-05-11 21:59:49 --> URI Class Initialized
INFO - 2018-05-11 21:59:49 --> Router Class Initialized
INFO - 2018-05-11 21:59:49 --> Output Class Initialized
INFO - 2018-05-11 21:59:49 --> Security Class Initialized
DEBUG - 2018-05-11 21:59:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 21:59:49 --> Input Class Initialized
INFO - 2018-05-11 21:59:49 --> Language Class Initialized
INFO - 2018-05-11 21:59:49 --> Language Class Initialized
INFO - 2018-05-11 21:59:49 --> Config Class Initialized
INFO - 2018-05-11 21:59:49 --> Loader Class Initialized
DEBUG - 2018-05-11 21:59:49 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-11 21:59:49 --> Helper loaded: url_helper
INFO - 2018-05-11 21:59:49 --> Helper loaded: form_helper
INFO - 2018-05-11 21:59:49 --> Helper loaded: date_helper
INFO - 2018-05-11 21:59:49 --> Helper loaded: util_helper
INFO - 2018-05-11 21:59:49 --> Helper loaded: text_helper
INFO - 2018-05-11 21:59:49 --> Helper loaded: string_helper
INFO - 2018-05-11 21:59:49 --> Database Driver Class Initialized
DEBUG - 2018-05-11 21:59:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-11 21:59:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-11 21:59:49 --> Email Class Initialized
INFO - 2018-05-11 21:59:49 --> Controller Class Initialized
DEBUG - 2018-05-11 21:59:49 --> Login MX_Controller Initialized
INFO - 2018-05-11 21:59:49 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-11 21:59:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-11 21:59:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-11 21:59:49 --> 4 Loggedout
INFO - 2018-05-11 21:59:50 --> Config Class Initialized
INFO - 2018-05-11 21:59:50 --> Hooks Class Initialized
DEBUG - 2018-05-11 21:59:50 --> UTF-8 Support Enabled
INFO - 2018-05-11 21:59:50 --> Utf8 Class Initialized
INFO - 2018-05-11 21:59:50 --> URI Class Initialized
INFO - 2018-05-11 21:59:50 --> Router Class Initialized
INFO - 2018-05-11 21:59:50 --> Output Class Initialized
INFO - 2018-05-11 21:59:50 --> Security Class Initialized
DEBUG - 2018-05-11 21:59:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 21:59:50 --> Input Class Initialized
INFO - 2018-05-11 21:59:50 --> Language Class Initialized
INFO - 2018-05-11 21:59:50 --> Language Class Initialized
INFO - 2018-05-11 21:59:50 --> Config Class Initialized
INFO - 2018-05-11 21:59:50 --> Loader Class Initialized
DEBUG - 2018-05-11 21:59:50 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-11 21:59:50 --> Helper loaded: url_helper
INFO - 2018-05-11 21:59:50 --> Helper loaded: form_helper
INFO - 2018-05-11 21:59:50 --> Helper loaded: date_helper
INFO - 2018-05-11 21:59:50 --> Helper loaded: util_helper
INFO - 2018-05-11 21:59:50 --> Helper loaded: text_helper
INFO - 2018-05-11 21:59:50 --> Helper loaded: string_helper
INFO - 2018-05-11 21:59:50 --> Database Driver Class Initialized
DEBUG - 2018-05-11 21:59:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-11 21:59:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-11 21:59:50 --> Email Class Initialized
INFO - 2018-05-11 21:59:50 --> Controller Class Initialized
DEBUG - 2018-05-11 21:59:50 --> Home MX_Controller Initialized
DEBUG - 2018-05-11 21:59:50 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-11 21:59:50 --> Login MX_Controller Initialized
INFO - 2018-05-11 21:59:50 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-11 21:59:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-11 21:59:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-11 21:59:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/login.php
INFO - 2018-05-11 22:00:21 --> Config Class Initialized
INFO - 2018-05-11 22:00:21 --> Hooks Class Initialized
DEBUG - 2018-05-11 22:00:21 --> UTF-8 Support Enabled
INFO - 2018-05-11 22:00:21 --> Utf8 Class Initialized
INFO - 2018-05-11 22:00:21 --> URI Class Initialized
INFO - 2018-05-11 22:00:21 --> Router Class Initialized
INFO - 2018-05-11 22:00:21 --> Output Class Initialized
INFO - 2018-05-11 22:00:21 --> Security Class Initialized
DEBUG - 2018-05-11 22:00:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 22:00:21 --> Input Class Initialized
INFO - 2018-05-11 22:00:21 --> Language Class Initialized
INFO - 2018-05-11 22:00:21 --> Language Class Initialized
INFO - 2018-05-11 22:00:21 --> Config Class Initialized
INFO - 2018-05-11 22:00:21 --> Loader Class Initialized
DEBUG - 2018-05-11 22:00:21 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-11 22:00:21 --> Helper loaded: url_helper
INFO - 2018-05-11 22:00:21 --> Helper loaded: form_helper
INFO - 2018-05-11 22:00:21 --> Helper loaded: date_helper
INFO - 2018-05-11 22:00:21 --> Helper loaded: util_helper
INFO - 2018-05-11 22:00:21 --> Helper loaded: text_helper
INFO - 2018-05-11 22:00:21 --> Helper loaded: string_helper
INFO - 2018-05-11 22:00:21 --> Database Driver Class Initialized
DEBUG - 2018-05-11 22:00:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-11 22:00:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-11 22:00:21 --> Email Class Initialized
INFO - 2018-05-11 22:00:21 --> Controller Class Initialized
DEBUG - 2018-05-11 22:00:21 --> Login MX_Controller Initialized
INFO - 2018-05-11 22:00:21 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-11 22:00:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-11 22:00:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-11 22:00:21 --> Email starts for gopipanguluri123@gmail.com fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-05-11 22:00:21 --> User session created for 4
INFO - 2018-05-11 22:00:21 --> Login status gopipanguluri123@gmail.com - success
INFO - 2018-05-11 22:00:21 --> Final output sent to browser
DEBUG - 2018-05-11 22:00:21 --> Total execution time: 0.7038
INFO - 2018-05-11 22:00:21 --> Config Class Initialized
INFO - 2018-05-11 22:00:21 --> Hooks Class Initialized
DEBUG - 2018-05-11 22:00:21 --> UTF-8 Support Enabled
INFO - 2018-05-11 22:00:21 --> Utf8 Class Initialized
INFO - 2018-05-11 22:00:21 --> URI Class Initialized
INFO - 2018-05-11 22:00:21 --> Router Class Initialized
INFO - 2018-05-11 22:00:21 --> Output Class Initialized
INFO - 2018-05-11 22:00:21 --> Security Class Initialized
DEBUG - 2018-05-11 22:00:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 22:00:21 --> Input Class Initialized
INFO - 2018-05-11 22:00:21 --> Language Class Initialized
INFO - 2018-05-11 22:00:21 --> Language Class Initialized
INFO - 2018-05-11 22:00:22 --> Config Class Initialized
INFO - 2018-05-11 22:00:22 --> Loader Class Initialized
DEBUG - 2018-05-11 22:00:22 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-11 22:00:22 --> Helper loaded: url_helper
INFO - 2018-05-11 22:00:22 --> Helper loaded: form_helper
INFO - 2018-05-11 22:00:22 --> Helper loaded: date_helper
INFO - 2018-05-11 22:00:22 --> Helper loaded: util_helper
INFO - 2018-05-11 22:00:22 --> Helper loaded: text_helper
INFO - 2018-05-11 22:00:22 --> Helper loaded: string_helper
INFO - 2018-05-11 22:00:22 --> Database Driver Class Initialized
DEBUG - 2018-05-11 22:00:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-11 22:00:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-11 22:00:22 --> Email Class Initialized
INFO - 2018-05-11 22:00:22 --> Controller Class Initialized
DEBUG - 2018-05-11 22:00:22 --> Home MX_Controller Initialized
DEBUG - 2018-05-11 22:00:22 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-11 22:00:22 --> Login MX_Controller Initialized
INFO - 2018-05-11 22:00:22 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-11 22:00:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-11 22:00:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-11 22:00:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-05-11 22:00:22 --> Final output sent to browser
INFO - 2018-05-11 22:00:22 --> Config Class Initialized
DEBUG - 2018-05-11 22:00:22 --> Total execution time: 0.5975
INFO - 2018-05-11 22:00:22 --> Hooks Class Initialized
DEBUG - 2018-05-11 22:00:22 --> UTF-8 Support Enabled
INFO - 2018-05-11 22:00:22 --> Utf8 Class Initialized
INFO - 2018-05-11 22:00:22 --> URI Class Initialized
INFO - 2018-05-11 22:00:22 --> Router Class Initialized
INFO - 2018-05-11 22:00:22 --> Output Class Initialized
INFO - 2018-05-11 22:00:22 --> Security Class Initialized
DEBUG - 2018-05-11 22:00:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 22:00:22 --> Input Class Initialized
INFO - 2018-05-11 22:00:22 --> Language Class Initialized
ERROR - 2018-05-11 22:00:22 --> 404 Page Not Found: /index
INFO - 2018-05-11 22:00:22 --> Config Class Initialized
INFO - 2018-05-11 22:00:22 --> Config Class Initialized
INFO - 2018-05-11 22:00:22 --> Config Class Initialized
INFO - 2018-05-11 22:00:22 --> Config Class Initialized
INFO - 2018-05-11 22:00:22 --> Hooks Class Initialized
INFO - 2018-05-11 22:00:22 --> Hooks Class Initialized
INFO - 2018-05-11 22:00:22 --> Hooks Class Initialized
INFO - 2018-05-11 22:00:22 --> Config Class Initialized
INFO - 2018-05-11 22:00:23 --> Config Class Initialized
INFO - 2018-05-11 22:00:23 --> Hooks Class Initialized
DEBUG - 2018-05-11 22:00:23 --> UTF-8 Support Enabled
INFO - 2018-05-11 22:00:23 --> Utf8 Class Initialized
INFO - 2018-05-11 22:00:23 --> URI Class Initialized
INFO - 2018-05-11 22:00:23 --> Router Class Initialized
DEBUG - 2018-05-11 22:00:23 --> UTF-8 Support Enabled
DEBUG - 2018-05-11 22:00:23 --> UTF-8 Support Enabled
INFO - 2018-05-11 22:00:23 --> Hooks Class Initialized
INFO - 2018-05-11 22:00:23 --> Hooks Class Initialized
INFO - 2018-05-11 22:00:23 --> Output Class Initialized
DEBUG - 2018-05-11 22:00:23 --> UTF-8 Support Enabled
INFO - 2018-05-11 22:00:23 --> Utf8 Class Initialized
DEBUG - 2018-05-11 22:00:23 --> UTF-8 Support Enabled
DEBUG - 2018-05-11 22:00:23 --> UTF-8 Support Enabled
INFO - 2018-05-11 22:00:23 --> Utf8 Class Initialized
INFO - 2018-05-11 22:00:23 --> Utf8 Class Initialized
INFO - 2018-05-11 22:00:23 --> Security Class Initialized
INFO - 2018-05-11 22:00:23 --> Utf8 Class Initialized
INFO - 2018-05-11 22:00:23 --> Utf8 Class Initialized
INFO - 2018-05-11 22:00:23 --> URI Class Initialized
INFO - 2018-05-11 22:00:23 --> URI Class Initialized
DEBUG - 2018-05-11 22:00:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 22:00:23 --> URI Class Initialized
INFO - 2018-05-11 22:00:23 --> URI Class Initialized
INFO - 2018-05-11 22:00:23 --> Router Class Initialized
INFO - 2018-05-11 22:00:23 --> Output Class Initialized
INFO - 2018-05-11 22:00:23 --> URI Class Initialized
INFO - 2018-05-11 22:00:23 --> Router Class Initialized
INFO - 2018-05-11 22:00:23 --> Router Class Initialized
INFO - 2018-05-11 22:00:23 --> Input Class Initialized
INFO - 2018-05-11 22:00:23 --> Security Class Initialized
INFO - 2018-05-11 22:00:23 --> Router Class Initialized
INFO - 2018-05-11 22:00:23 --> Output Class Initialized
INFO - 2018-05-11 22:00:23 --> Router Class Initialized
INFO - 2018-05-11 22:00:23 --> Security Class Initialized
INFO - 2018-05-11 22:00:23 --> Output Class Initialized
DEBUG - 2018-05-11 22:00:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 22:00:23 --> Language Class Initialized
DEBUG - 2018-05-11 22:00:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 22:00:23 --> Output Class Initialized
INFO - 2018-05-11 22:00:23 --> Output Class Initialized
INFO - 2018-05-11 22:00:23 --> Security Class Initialized
INFO - 2018-05-11 22:00:23 --> Security Class Initialized
INFO - 2018-05-11 22:00:23 --> Security Class Initialized
INFO - 2018-05-11 22:00:23 --> Input Class Initialized
ERROR - 2018-05-11 22:00:23 --> 404 Page Not Found: /index
INFO - 2018-05-11 22:00:23 --> Input Class Initialized
DEBUG - 2018-05-11 22:00:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-11 22:00:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 22:00:23 --> Input Class Initialized
INFO - 2018-05-11 22:00:23 --> Language Class Initialized
ERROR - 2018-05-11 22:00:23 --> 404 Page Not Found: /index
INFO - 2018-05-11 22:00:23 --> Input Class Initialized
INFO - 2018-05-11 22:00:23 --> Language Class Initialized
INFO - 2018-05-11 22:00:23 --> Language Class Initialized
DEBUG - 2018-05-11 22:00:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 22:00:23 --> Language Class Initialized
INFO - 2018-05-11 22:00:23 --> Config Class Initialized
INFO - 2018-05-11 22:00:23 --> Hooks Class Initialized
ERROR - 2018-05-11 22:00:23 --> 404 Page Not Found: /index
ERROR - 2018-05-11 22:00:23 --> 404 Page Not Found: /index
INFO - 2018-05-11 22:00:23 --> Input Class Initialized
ERROR - 2018-05-11 22:00:23 --> 404 Page Not Found: /index
DEBUG - 2018-05-11 22:00:23 --> UTF-8 Support Enabled
INFO - 2018-05-11 22:00:23 --> Utf8 Class Initialized
INFO - 2018-05-11 22:00:23 --> Language Class Initialized
INFO - 2018-05-11 22:00:23 --> URI Class Initialized
ERROR - 2018-05-11 22:00:23 --> 404 Page Not Found: /index
INFO - 2018-05-11 22:00:23 --> Router Class Initialized
INFO - 2018-05-11 22:00:23 --> Config Class Initialized
INFO - 2018-05-11 22:00:23 --> Hooks Class Initialized
INFO - 2018-05-11 22:00:23 --> Output Class Initialized
INFO - 2018-05-11 22:00:23 --> Config Class Initialized
INFO - 2018-05-11 22:00:23 --> Config Class Initialized
INFO - 2018-05-11 22:00:24 --> Hooks Class Initialized
INFO - 2018-05-11 22:00:24 --> Hooks Class Initialized
DEBUG - 2018-05-11 22:00:24 --> UTF-8 Support Enabled
INFO - 2018-05-11 22:00:24 --> Security Class Initialized
DEBUG - 2018-05-11 22:00:24 --> UTF-8 Support Enabled
INFO - 2018-05-11 22:00:24 --> Utf8 Class Initialized
DEBUG - 2018-05-11 22:00:24 --> UTF-8 Support Enabled
DEBUG - 2018-05-11 22:00:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 22:00:24 --> Utf8 Class Initialized
INFO - 2018-05-11 22:00:24 --> Input Class Initialized
INFO - 2018-05-11 22:00:24 --> URI Class Initialized
INFO - 2018-05-11 22:00:24 --> Config Class Initialized
INFO - 2018-05-11 22:00:24 --> Utf8 Class Initialized
INFO - 2018-05-11 22:00:24 --> Hooks Class Initialized
INFO - 2018-05-11 22:00:24 --> URI Class Initialized
INFO - 2018-05-11 22:00:24 --> URI Class Initialized
INFO - 2018-05-11 22:00:24 --> Router Class Initialized
INFO - 2018-05-11 22:00:24 --> Language Class Initialized
DEBUG - 2018-05-11 22:00:24 --> UTF-8 Support Enabled
INFO - 2018-05-11 22:00:24 --> Utf8 Class Initialized
INFO - 2018-05-11 22:00:24 --> Router Class Initialized
INFO - 2018-05-11 22:00:24 --> Output Class Initialized
INFO - 2018-05-11 22:00:24 --> Router Class Initialized
INFO - 2018-05-11 22:00:24 --> URI Class Initialized
ERROR - 2018-05-11 22:00:24 --> 404 Page Not Found: /index
INFO - 2018-05-11 22:00:24 --> Output Class Initialized
INFO - 2018-05-11 22:00:24 --> Security Class Initialized
INFO - 2018-05-11 22:00:24 --> Output Class Initialized
INFO - 2018-05-11 22:00:24 --> Config Class Initialized
INFO - 2018-05-11 22:00:24 --> Router Class Initialized
DEBUG - 2018-05-11 22:00:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 22:00:24 --> Hooks Class Initialized
INFO - 2018-05-11 22:00:24 --> Security Class Initialized
INFO - 2018-05-11 22:00:24 --> Security Class Initialized
INFO - 2018-05-11 22:00:24 --> Output Class Initialized
DEBUG - 2018-05-11 22:00:24 --> UTF-8 Support Enabled
INFO - 2018-05-11 22:00:24 --> Input Class Initialized
DEBUG - 2018-05-11 22:00:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-11 22:00:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 22:00:24 --> Security Class Initialized
INFO - 2018-05-11 22:00:24 --> Utf8 Class Initialized
INFO - 2018-05-11 22:00:24 --> URI Class Initialized
INFO - 2018-05-11 22:00:24 --> Router Class Initialized
DEBUG - 2018-05-11 22:00:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 22:00:24 --> Input Class Initialized
INFO - 2018-05-11 22:00:24 --> Language Class Initialized
ERROR - 2018-05-11 22:00:24 --> 404 Page Not Found: /index
INFO - 2018-05-11 22:00:24 --> Output Class Initialized
INFO - 2018-05-11 22:00:24 --> Security Class Initialized
INFO - 2018-05-11 22:00:24 --> Config Class Initialized
INFO - 2018-05-11 22:00:24 --> Input Class Initialized
INFO - 2018-05-11 22:00:24 --> Input Class Initialized
INFO - 2018-05-11 22:00:24 --> Language Class Initialized
INFO - 2018-05-11 22:00:24 --> Hooks Class Initialized
INFO - 2018-05-11 22:00:24 --> Language Class Initialized
ERROR - 2018-05-11 22:00:24 --> 404 Page Not Found: /index
DEBUG - 2018-05-11 22:00:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 22:00:24 --> Language Class Initialized
DEBUG - 2018-05-11 22:00:24 --> UTF-8 Support Enabled
ERROR - 2018-05-11 22:00:24 --> 404 Page Not Found: /index
INFO - 2018-05-11 22:00:24 --> Utf8 Class Initialized
INFO - 2018-05-11 22:00:24 --> URI Class Initialized
INFO - 2018-05-11 22:00:24 --> Input Class Initialized
ERROR - 2018-05-11 22:00:24 --> 404 Page Not Found: /index
INFO - 2018-05-11 22:00:24 --> Router Class Initialized
INFO - 2018-05-11 22:00:24 --> Config Class Initialized
INFO - 2018-05-11 22:00:24 --> Config Class Initialized
INFO - 2018-05-11 22:00:24 --> Hooks Class Initialized
INFO - 2018-05-11 22:00:24 --> Hooks Class Initialized
INFO - 2018-05-11 22:00:24 --> Language Class Initialized
INFO - 2018-05-11 22:00:24 --> Output Class Initialized
INFO - 2018-05-11 22:00:24 --> Config Class Initialized
INFO - 2018-05-11 22:00:24 --> Hooks Class Initialized
DEBUG - 2018-05-11 22:00:24 --> UTF-8 Support Enabled
ERROR - 2018-05-11 22:00:24 --> 404 Page Not Found: /index
DEBUG - 2018-05-11 22:00:24 --> UTF-8 Support Enabled
INFO - 2018-05-11 22:00:24 --> Security Class Initialized
INFO - 2018-05-11 22:00:24 --> Utf8 Class Initialized
INFO - 2018-05-11 22:00:24 --> Utf8 Class Initialized
DEBUG - 2018-05-11 22:00:24 --> UTF-8 Support Enabled
DEBUG - 2018-05-11 22:00:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 22:00:24 --> URI Class Initialized
INFO - 2018-05-11 22:00:24 --> Router Class Initialized
INFO - 2018-05-11 22:00:24 --> Utf8 Class Initialized
INFO - 2018-05-11 22:00:24 --> URI Class Initialized
INFO - 2018-05-11 22:00:24 --> Input Class Initialized
INFO - 2018-05-11 22:00:24 --> URI Class Initialized
INFO - 2018-05-11 22:00:24 --> Router Class Initialized
INFO - 2018-05-11 22:00:24 --> Language Class Initialized
INFO - 2018-05-11 22:00:24 --> Output Class Initialized
INFO - 2018-05-11 22:00:24 --> Output Class Initialized
INFO - 2018-05-11 22:00:24 --> Security Class Initialized
INFO - 2018-05-11 22:00:24 --> Router Class Initialized
INFO - 2018-05-11 22:00:24 --> Security Class Initialized
DEBUG - 2018-05-11 22:00:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-11 22:00:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 22:00:24 --> Output Class Initialized
ERROR - 2018-05-11 22:00:24 --> 404 Page Not Found: /index
INFO - 2018-05-11 22:00:24 --> Input Class Initialized
INFO - 2018-05-11 22:00:24 --> Input Class Initialized
INFO - 2018-05-11 22:00:24 --> Language Class Initialized
ERROR - 2018-05-11 22:00:24 --> 404 Page Not Found: /index
INFO - 2018-05-11 22:00:24 --> Language Class Initialized
INFO - 2018-05-11 22:00:24 --> Security Class Initialized
ERROR - 2018-05-11 22:00:24 --> 404 Page Not Found: /index
DEBUG - 2018-05-11 22:00:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 22:00:25 --> Input Class Initialized
INFO - 2018-05-11 22:00:25 --> Language Class Initialized
ERROR - 2018-05-11 22:00:25 --> 404 Page Not Found: /index
INFO - 2018-05-11 22:00:26 --> Config Class Initialized
INFO - 2018-05-11 22:00:26 --> Hooks Class Initialized
DEBUG - 2018-05-11 22:00:26 --> UTF-8 Support Enabled
INFO - 2018-05-11 22:00:26 --> Utf8 Class Initialized
INFO - 2018-05-11 22:00:26 --> URI Class Initialized
INFO - 2018-05-11 22:00:26 --> Router Class Initialized
INFO - 2018-05-11 22:00:26 --> Output Class Initialized
INFO - 2018-05-11 22:00:26 --> Security Class Initialized
DEBUG - 2018-05-11 22:00:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 22:00:26 --> Input Class Initialized
INFO - 2018-05-11 22:00:26 --> Language Class Initialized
ERROR - 2018-05-11 22:00:26 --> 404 Page Not Found: /index
INFO - 2018-05-11 22:00:48 --> Config Class Initialized
INFO - 2018-05-11 22:00:48 --> Hooks Class Initialized
DEBUG - 2018-05-11 22:00:48 --> UTF-8 Support Enabled
INFO - 2018-05-11 22:00:48 --> Utf8 Class Initialized
INFO - 2018-05-11 22:00:48 --> URI Class Initialized
INFO - 2018-05-11 22:00:48 --> Router Class Initialized
INFO - 2018-05-11 22:00:48 --> Output Class Initialized
INFO - 2018-05-11 22:00:48 --> Security Class Initialized
DEBUG - 2018-05-11 22:00:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 22:00:48 --> Input Class Initialized
INFO - 2018-05-11 22:00:48 --> Language Class Initialized
ERROR - 2018-05-11 22:00:48 --> 404 Page Not Found: /index
INFO - 2018-05-11 22:09:13 --> Config Class Initialized
INFO - 2018-05-11 22:09:13 --> Hooks Class Initialized
DEBUG - 2018-05-11 22:09:13 --> UTF-8 Support Enabled
INFO - 2018-05-11 22:09:13 --> Utf8 Class Initialized
INFO - 2018-05-11 22:09:13 --> URI Class Initialized
INFO - 2018-05-11 22:09:13 --> Router Class Initialized
INFO - 2018-05-11 22:09:13 --> Output Class Initialized
INFO - 2018-05-11 22:09:13 --> Security Class Initialized
DEBUG - 2018-05-11 22:09:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 22:09:13 --> Input Class Initialized
INFO - 2018-05-11 22:09:13 --> Language Class Initialized
INFO - 2018-05-11 22:09:13 --> Language Class Initialized
INFO - 2018-05-11 22:09:13 --> Config Class Initialized
INFO - 2018-05-11 22:09:13 --> Loader Class Initialized
DEBUG - 2018-05-11 22:09:13 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-11 22:09:13 --> Helper loaded: url_helper
INFO - 2018-05-11 22:09:13 --> Helper loaded: form_helper
INFO - 2018-05-11 22:09:13 --> Helper loaded: date_helper
INFO - 2018-05-11 22:09:13 --> Helper loaded: util_helper
INFO - 2018-05-11 22:09:13 --> Helper loaded: text_helper
INFO - 2018-05-11 22:09:13 --> Helper loaded: string_helper
INFO - 2018-05-11 22:09:13 --> Database Driver Class Initialized
DEBUG - 2018-05-11 22:09:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-11 22:09:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-11 22:09:14 --> Email Class Initialized
INFO - 2018-05-11 22:09:14 --> Controller Class Initialized
DEBUG - 2018-05-11 22:09:14 --> Admin MX_Controller Initialized
INFO - 2018-05-11 22:09:14 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-11 22:09:14 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-11 22:09:14 --> Login MX_Controller Initialized
DEBUG - 2018-05-11 22:09:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-11 22:09:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-11 22:09:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-05-11 22:09:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-05-11 22:09:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-05-11 22:09:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-05-11 22:09:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-05-11 22:09:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/dashboard.php
INFO - 2018-05-11 22:09:14 --> Final output sent to browser
DEBUG - 2018-05-11 22:09:14 --> Total execution time: 0.7025
INFO - 2018-05-11 22:09:14 --> Config Class Initialized
INFO - 2018-05-11 22:09:14 --> Hooks Class Initialized
DEBUG - 2018-05-11 22:09:14 --> UTF-8 Support Enabled
INFO - 2018-05-11 22:09:14 --> Utf8 Class Initialized
INFO - 2018-05-11 22:09:14 --> URI Class Initialized
INFO - 2018-05-11 22:09:14 --> Router Class Initialized
INFO - 2018-05-11 22:09:14 --> Output Class Initialized
INFO - 2018-05-11 22:09:14 --> Security Class Initialized
DEBUG - 2018-05-11 22:09:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 22:09:14 --> Config Class Initialized
INFO - 2018-05-11 22:09:14 --> Hooks Class Initialized
INFO - 2018-05-11 22:09:14 --> Input Class Initialized
INFO - 2018-05-11 22:09:14 --> Language Class Initialized
DEBUG - 2018-05-11 22:09:14 --> UTF-8 Support Enabled
INFO - 2018-05-11 22:09:14 --> Utf8 Class Initialized
ERROR - 2018-05-11 22:09:14 --> 404 Page Not Found: /index
INFO - 2018-05-11 22:09:14 --> URI Class Initialized
INFO - 2018-05-11 22:09:14 --> Router Class Initialized
INFO - 2018-05-11 22:09:14 --> Config Class Initialized
INFO - 2018-05-11 22:09:14 --> Hooks Class Initialized
INFO - 2018-05-11 22:09:14 --> Output Class Initialized
DEBUG - 2018-05-11 22:09:14 --> UTF-8 Support Enabled
INFO - 2018-05-11 22:09:15 --> Security Class Initialized
DEBUG - 2018-05-11 22:09:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 22:09:15 --> Utf8 Class Initialized
INFO - 2018-05-11 22:09:15 --> Input Class Initialized
INFO - 2018-05-11 22:09:15 --> URI Class Initialized
INFO - 2018-05-11 22:09:15 --> Language Class Initialized
INFO - 2018-05-11 22:09:15 --> Router Class Initialized
ERROR - 2018-05-11 22:09:15 --> 404 Page Not Found: /index
INFO - 2018-05-11 22:09:15 --> Output Class Initialized
INFO - 2018-05-11 22:09:15 --> Security Class Initialized
DEBUG - 2018-05-11 22:09:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 22:09:15 --> Input Class Initialized
INFO - 2018-05-11 22:09:15 --> Language Class Initialized
ERROR - 2018-05-11 22:09:15 --> 404 Page Not Found: /index
INFO - 2018-05-11 22:23:52 --> Config Class Initialized
INFO - 2018-05-11 22:23:52 --> Hooks Class Initialized
DEBUG - 2018-05-11 22:23:52 --> UTF-8 Support Enabled
INFO - 2018-05-11 22:23:52 --> Utf8 Class Initialized
INFO - 2018-05-11 22:23:52 --> URI Class Initialized
INFO - 2018-05-11 22:23:52 --> Router Class Initialized
INFO - 2018-05-11 22:23:52 --> Output Class Initialized
INFO - 2018-05-11 22:23:52 --> Security Class Initialized
DEBUG - 2018-05-11 22:23:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 22:23:52 --> Input Class Initialized
INFO - 2018-05-11 22:23:52 --> Language Class Initialized
INFO - 2018-05-11 22:23:52 --> Language Class Initialized
INFO - 2018-05-11 22:23:52 --> Config Class Initialized
INFO - 2018-05-11 22:23:52 --> Loader Class Initialized
DEBUG - 2018-05-11 22:23:52 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-11 22:23:52 --> Helper loaded: url_helper
INFO - 2018-05-11 22:23:52 --> Helper loaded: form_helper
INFO - 2018-05-11 22:23:52 --> Helper loaded: date_helper
INFO - 2018-05-11 22:23:52 --> Helper loaded: util_helper
INFO - 2018-05-11 22:23:52 --> Helper loaded: text_helper
INFO - 2018-05-11 22:23:52 --> Helper loaded: string_helper
INFO - 2018-05-11 22:23:52 --> Database Driver Class Initialized
DEBUG - 2018-05-11 22:23:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-11 22:23:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-11 22:23:52 --> Email Class Initialized
INFO - 2018-05-11 22:23:52 --> Controller Class Initialized
DEBUG - 2018-05-11 22:23:52 --> Profile MX_Controller Initialized
INFO - 2018-05-11 22:23:52 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-11 22:23:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-11 22:23:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Profile_model.php
DEBUG - 2018-05-11 22:23:53 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-11 22:23:53 --> Login MX_Controller Initialized
DEBUG - 2018-05-11 22:23:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-11 22:23:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-05-11 22:23:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-05-11 22:23:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-05-11 22:23:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-05-11 22:23:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-05-11 22:23:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/admin_password.php
INFO - 2018-05-11 22:23:53 --> Final output sent to browser
DEBUG - 2018-05-11 22:23:53 --> Total execution time: 0.8184
INFO - 2018-05-11 22:23:53 --> Config Class Initialized
INFO - 2018-05-11 22:23:53 --> Hooks Class Initialized
DEBUG - 2018-05-11 22:23:53 --> UTF-8 Support Enabled
INFO - 2018-05-11 22:23:53 --> Utf8 Class Initialized
INFO - 2018-05-11 22:23:53 --> URI Class Initialized
INFO - 2018-05-11 22:23:53 --> Router Class Initialized
INFO - 2018-05-11 22:23:53 --> Output Class Initialized
INFO - 2018-05-11 22:23:53 --> Security Class Initialized
DEBUG - 2018-05-11 22:23:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 22:23:53 --> Input Class Initialized
INFO - 2018-05-11 22:23:53 --> Language Class Initialized
ERROR - 2018-05-11 22:23:53 --> 404 Page Not Found: /index
INFO - 2018-05-11 22:24:15 --> Config Class Initialized
INFO - 2018-05-11 22:24:16 --> Hooks Class Initialized
DEBUG - 2018-05-11 22:24:16 --> UTF-8 Support Enabled
INFO - 2018-05-11 22:24:16 --> Utf8 Class Initialized
INFO - 2018-05-11 22:24:16 --> URI Class Initialized
INFO - 2018-05-11 22:24:16 --> Router Class Initialized
INFO - 2018-05-11 22:24:16 --> Output Class Initialized
INFO - 2018-05-11 22:24:16 --> Security Class Initialized
DEBUG - 2018-05-11 22:24:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 22:24:16 --> Input Class Initialized
INFO - 2018-05-11 22:24:16 --> Language Class Initialized
INFO - 2018-05-11 22:24:16 --> Language Class Initialized
INFO - 2018-05-11 22:24:16 --> Config Class Initialized
INFO - 2018-05-11 22:24:16 --> Loader Class Initialized
DEBUG - 2018-05-11 22:24:16 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-11 22:24:16 --> Helper loaded: url_helper
INFO - 2018-05-11 22:24:16 --> Helper loaded: form_helper
INFO - 2018-05-11 22:24:16 --> Helper loaded: date_helper
INFO - 2018-05-11 22:24:16 --> Helper loaded: util_helper
INFO - 2018-05-11 22:24:16 --> Helper loaded: text_helper
INFO - 2018-05-11 22:24:16 --> Helper loaded: string_helper
INFO - 2018-05-11 22:24:16 --> Database Driver Class Initialized
DEBUG - 2018-05-11 22:24:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-11 22:24:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-11 22:24:16 --> Email Class Initialized
INFO - 2018-05-11 22:24:16 --> Controller Class Initialized
DEBUG - 2018-05-11 22:24:16 --> Programs MX_Controller Initialized
INFO - 2018-05-11 22:24:16 --> Language file loaded: language/english/data_lang.php
ERROR - 2018-05-11 22:24:16 --> Severity: error --> Exception: Unable to locate the model you have specified: Programs_model E:\xampp\htdocs\consulting\system\core\Loader.php 348
INFO - 2018-05-11 22:28:59 --> Config Class Initialized
INFO - 2018-05-11 22:28:59 --> Hooks Class Initialized
DEBUG - 2018-05-11 22:28:59 --> UTF-8 Support Enabled
INFO - 2018-05-11 22:28:59 --> Utf8 Class Initialized
INFO - 2018-05-11 22:28:59 --> URI Class Initialized
INFO - 2018-05-11 22:28:59 --> Router Class Initialized
INFO - 2018-05-11 22:28:59 --> Output Class Initialized
INFO - 2018-05-11 22:29:00 --> Security Class Initialized
DEBUG - 2018-05-11 22:29:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 22:29:00 --> Input Class Initialized
INFO - 2018-05-11 22:29:00 --> Language Class Initialized
INFO - 2018-05-11 22:29:00 --> Language Class Initialized
INFO - 2018-05-11 22:29:00 --> Config Class Initialized
INFO - 2018-05-11 22:29:00 --> Loader Class Initialized
DEBUG - 2018-05-11 22:29:00 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-11 22:29:00 --> Helper loaded: url_helper
INFO - 2018-05-11 22:29:00 --> Helper loaded: form_helper
INFO - 2018-05-11 22:29:00 --> Helper loaded: date_helper
INFO - 2018-05-11 22:29:00 --> Helper loaded: util_helper
INFO - 2018-05-11 22:29:00 --> Helper loaded: text_helper
INFO - 2018-05-11 22:29:00 --> Helper loaded: string_helper
INFO - 2018-05-11 22:29:00 --> Database Driver Class Initialized
DEBUG - 2018-05-11 22:29:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-11 22:29:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-11 22:29:00 --> Email Class Initialized
INFO - 2018-05-11 22:29:00 --> Controller Class Initialized
DEBUG - 2018-05-11 22:29:00 --> Programs MX_Controller Initialized
INFO - 2018-05-11 22:29:00 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-11 22:29:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-05-11 22:29:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-11 22:29:00 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-11 22:29:00 --> Login MX_Controller Initialized
DEBUG - 2018-05-11 22:29:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-11 22:29:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-05-11 22:29:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-05-11 22:29:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-05-11 22:29:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-05-11 22:29:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-05-11 22:29:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/programs/programs.php
INFO - 2018-05-11 22:29:00 --> Final output sent to browser
DEBUG - 2018-05-11 22:29:00 --> Total execution time: 0.7232
INFO - 2018-05-11 22:29:00 --> Config Class Initialized
INFO - 2018-05-11 22:29:00 --> Hooks Class Initialized
DEBUG - 2018-05-11 22:29:00 --> UTF-8 Support Enabled
INFO - 2018-05-11 22:29:00 --> Config Class Initialized
INFO - 2018-05-11 22:29:00 --> Hooks Class Initialized
INFO - 2018-05-11 22:29:00 --> Utf8 Class Initialized
DEBUG - 2018-05-11 22:29:00 --> UTF-8 Support Enabled
INFO - 2018-05-11 22:29:00 --> Utf8 Class Initialized
INFO - 2018-05-11 22:29:00 --> URI Class Initialized
INFO - 2018-05-11 22:29:00 --> URI Class Initialized
INFO - 2018-05-11 22:29:00 --> Router Class Initialized
INFO - 2018-05-11 22:29:00 --> Output Class Initialized
INFO - 2018-05-11 22:29:00 --> Router Class Initialized
INFO - 2018-05-11 22:29:00 --> Security Class Initialized
INFO - 2018-05-11 22:29:01 --> Output Class Initialized
INFO - 2018-05-11 22:29:01 --> Security Class Initialized
DEBUG - 2018-05-11 22:29:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 22:29:01 --> Input Class Initialized
DEBUG - 2018-05-11 22:29:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 22:29:01 --> Language Class Initialized
INFO - 2018-05-11 22:29:01 --> Input Class Initialized
ERROR - 2018-05-11 22:29:01 --> 404 Page Not Found: /index
INFO - 2018-05-11 22:29:01 --> Language Class Initialized
ERROR - 2018-05-11 22:29:01 --> 404 Page Not Found: /index
INFO - 2018-05-11 22:29:01 --> Config Class Initialized
INFO - 2018-05-11 22:29:01 --> Hooks Class Initialized
DEBUG - 2018-05-11 22:29:01 --> UTF-8 Support Enabled
INFO - 2018-05-11 22:29:01 --> Utf8 Class Initialized
INFO - 2018-05-11 22:29:01 --> URI Class Initialized
INFO - 2018-05-11 22:29:01 --> Router Class Initialized
INFO - 2018-05-11 22:29:01 --> Output Class Initialized
INFO - 2018-05-11 22:29:01 --> Security Class Initialized
DEBUG - 2018-05-11 22:29:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 22:29:01 --> Input Class Initialized
INFO - 2018-05-11 22:29:01 --> Language Class Initialized
INFO - 2018-05-11 22:29:01 --> Language Class Initialized
INFO - 2018-05-11 22:29:01 --> Config Class Initialized
INFO - 2018-05-11 22:29:01 --> Loader Class Initialized
DEBUG - 2018-05-11 22:29:01 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-11 22:29:01 --> Helper loaded: url_helper
INFO - 2018-05-11 22:29:01 --> Helper loaded: form_helper
INFO - 2018-05-11 22:29:01 --> Helper loaded: date_helper
INFO - 2018-05-11 22:29:01 --> Helper loaded: util_helper
INFO - 2018-05-11 22:29:01 --> Helper loaded: text_helper
INFO - 2018-05-11 22:29:01 --> Helper loaded: string_helper
INFO - 2018-05-11 22:29:01 --> Database Driver Class Initialized
DEBUG - 2018-05-11 22:29:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-11 22:29:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-11 22:29:01 --> Email Class Initialized
INFO - 2018-05-11 22:29:01 --> Controller Class Initialized
DEBUG - 2018-05-11 22:29:01 --> Company_types MX_Controller Initialized
INFO - 2018-05-11 22:29:01 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-11 22:29:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Company_types_model.php
DEBUG - 2018-05-11 22:29:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-11 22:29:01 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-11 22:29:01 --> Login MX_Controller Initialized
DEBUG - 2018-05-11 22:29:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
ERROR - 2018-05-11 22:29:01 --> Query error: Table 'consulting.company_types' doesn't exist - Invalid query: SELECT  company_types.ct_id,company_types.ct_name,company_types.added_date,company_types.status,company_types.ct_id FROM   company_types   WHERE company_types.ct_id!= ''     LIMIT 0, 10
INFO - 2018-05-11 22:29:01 --> Language file loaded: language/english/db_lang.php
INFO - 2018-05-11 22:30:40 --> Config Class Initialized
INFO - 2018-05-11 22:30:40 --> Hooks Class Initialized
DEBUG - 2018-05-11 22:30:40 --> UTF-8 Support Enabled
INFO - 2018-05-11 22:30:40 --> Utf8 Class Initialized
INFO - 2018-05-11 22:30:40 --> URI Class Initialized
INFO - 2018-05-11 22:30:40 --> Router Class Initialized
INFO - 2018-05-11 22:30:40 --> Output Class Initialized
INFO - 2018-05-11 22:30:40 --> Security Class Initialized
DEBUG - 2018-05-11 22:30:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 22:30:40 --> Input Class Initialized
INFO - 2018-05-11 22:30:40 --> Language Class Initialized
INFO - 2018-05-11 22:30:40 --> Language Class Initialized
INFO - 2018-05-11 22:30:40 --> Config Class Initialized
INFO - 2018-05-11 22:30:40 --> Loader Class Initialized
DEBUG - 2018-05-11 22:30:40 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-11 22:30:40 --> Helper loaded: url_helper
INFO - 2018-05-11 22:30:40 --> Helper loaded: form_helper
INFO - 2018-05-11 22:30:40 --> Helper loaded: date_helper
INFO - 2018-05-11 22:30:40 --> Helper loaded: util_helper
INFO - 2018-05-11 22:30:40 --> Helper loaded: text_helper
INFO - 2018-05-11 22:30:40 --> Helper loaded: string_helper
INFO - 2018-05-11 22:30:40 --> Database Driver Class Initialized
DEBUG - 2018-05-11 22:30:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-11 22:30:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-11 22:30:40 --> Email Class Initialized
INFO - 2018-05-11 22:30:40 --> Controller Class Initialized
DEBUG - 2018-05-11 22:30:40 --> Programs MX_Controller Initialized
INFO - 2018-05-11 22:30:40 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-11 22:30:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-05-11 22:30:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-11 22:30:40 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-11 22:30:40 --> Login MX_Controller Initialized
DEBUG - 2018-05-11 22:30:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-11 22:30:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-05-11 22:30:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-05-11 22:30:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-05-11 22:30:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-05-11 22:30:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-05-11 22:30:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/programs/programs.php
INFO - 2018-05-11 22:30:40 --> Final output sent to browser
DEBUG - 2018-05-11 22:30:40 --> Total execution time: 0.7238
INFO - 2018-05-11 22:30:40 --> Config Class Initialized
INFO - 2018-05-11 22:30:40 --> Hooks Class Initialized
INFO - 2018-05-11 22:30:40 --> Config Class Initialized
INFO - 2018-05-11 22:30:40 --> Hooks Class Initialized
DEBUG - 2018-05-11 22:30:40 --> UTF-8 Support Enabled
INFO - 2018-05-11 22:30:40 --> Utf8 Class Initialized
DEBUG - 2018-05-11 22:30:41 --> UTF-8 Support Enabled
INFO - 2018-05-11 22:30:41 --> URI Class Initialized
INFO - 2018-05-11 22:30:41 --> Utf8 Class Initialized
INFO - 2018-05-11 22:30:41 --> Router Class Initialized
INFO - 2018-05-11 22:30:41 --> URI Class Initialized
INFO - 2018-05-11 22:30:41 --> Output Class Initialized
INFO - 2018-05-11 22:30:41 --> Router Class Initialized
INFO - 2018-05-11 22:30:41 --> Output Class Initialized
INFO - 2018-05-11 22:30:41 --> Security Class Initialized
INFO - 2018-05-11 22:30:41 --> Security Class Initialized
DEBUG - 2018-05-11 22:30:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-11 22:30:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 22:30:41 --> Input Class Initialized
INFO - 2018-05-11 22:30:41 --> Language Class Initialized
ERROR - 2018-05-11 22:30:41 --> 404 Page Not Found: /index
INFO - 2018-05-11 22:30:41 --> Input Class Initialized
INFO - 2018-05-11 22:30:41 --> Language Class Initialized
ERROR - 2018-05-11 22:30:41 --> 404 Page Not Found: /index
INFO - 2018-05-11 22:30:41 --> Config Class Initialized
INFO - 2018-05-11 22:30:41 --> Hooks Class Initialized
DEBUG - 2018-05-11 22:30:41 --> UTF-8 Support Enabled
INFO - 2018-05-11 22:30:41 --> Utf8 Class Initialized
INFO - 2018-05-11 22:30:41 --> URI Class Initialized
INFO - 2018-05-11 22:30:41 --> Router Class Initialized
INFO - 2018-05-11 22:30:41 --> Output Class Initialized
INFO - 2018-05-11 22:30:41 --> Security Class Initialized
DEBUG - 2018-05-11 22:30:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 22:30:41 --> Input Class Initialized
INFO - 2018-05-11 22:30:41 --> Language Class Initialized
INFO - 2018-05-11 22:30:41 --> Language Class Initialized
INFO - 2018-05-11 22:30:41 --> Config Class Initialized
INFO - 2018-05-11 22:30:41 --> Loader Class Initialized
DEBUG - 2018-05-11 22:30:41 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-11 22:30:41 --> Helper loaded: url_helper
INFO - 2018-05-11 22:30:41 --> Helper loaded: form_helper
INFO - 2018-05-11 22:30:41 --> Helper loaded: date_helper
INFO - 2018-05-11 22:30:41 --> Helper loaded: util_helper
INFO - 2018-05-11 22:30:41 --> Helper loaded: text_helper
INFO - 2018-05-11 22:30:41 --> Helper loaded: string_helper
INFO - 2018-05-11 22:30:41 --> Database Driver Class Initialized
DEBUG - 2018-05-11 22:30:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-11 22:30:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-11 22:30:41 --> Email Class Initialized
INFO - 2018-05-11 22:30:41 --> Controller Class Initialized
DEBUG - 2018-05-11 22:30:41 --> Company_types MX_Controller Initialized
INFO - 2018-05-11 22:30:41 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-11 22:30:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Company_types_model.php
DEBUG - 2018-05-11 22:30:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-11 22:30:41 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-11 22:30:42 --> Login MX_Controller Initialized
DEBUG - 2018-05-11 22:30:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
ERROR - 2018-05-11 22:30:42 --> Query error: Table 'consulting.company_types' doesn't exist - Invalid query: SELECT  company_types.ct_id,company_types.ct_name,company_types.added_date,company_types.status,company_types.ct_id FROM   company_types   WHERE company_types.ct_id!= ''     LIMIT 0, 10
INFO - 2018-05-11 22:30:42 --> Language file loaded: language/english/db_lang.php
INFO - 2018-05-11 22:31:59 --> Config Class Initialized
INFO - 2018-05-11 22:31:59 --> Hooks Class Initialized
DEBUG - 2018-05-11 22:31:59 --> UTF-8 Support Enabled
INFO - 2018-05-11 22:31:59 --> Utf8 Class Initialized
INFO - 2018-05-11 22:31:59 --> URI Class Initialized
INFO - 2018-05-11 22:31:59 --> Router Class Initialized
INFO - 2018-05-11 22:31:59 --> Output Class Initialized
INFO - 2018-05-11 22:31:59 --> Security Class Initialized
DEBUG - 2018-05-11 22:31:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 22:31:59 --> Input Class Initialized
INFO - 2018-05-11 22:31:59 --> Language Class Initialized
INFO - 2018-05-11 22:31:59 --> Language Class Initialized
INFO - 2018-05-11 22:31:59 --> Config Class Initialized
INFO - 2018-05-11 22:31:59 --> Loader Class Initialized
DEBUG - 2018-05-11 22:31:59 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-11 22:31:59 --> Helper loaded: url_helper
INFO - 2018-05-11 22:31:59 --> Helper loaded: form_helper
INFO - 2018-05-11 22:31:59 --> Helper loaded: date_helper
INFO - 2018-05-11 22:31:59 --> Helper loaded: util_helper
INFO - 2018-05-11 22:31:59 --> Helper loaded: text_helper
INFO - 2018-05-11 22:31:59 --> Helper loaded: string_helper
INFO - 2018-05-11 22:31:59 --> Database Driver Class Initialized
DEBUG - 2018-05-11 22:31:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-11 22:31:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-11 22:31:59 --> Email Class Initialized
INFO - 2018-05-11 22:31:59 --> Controller Class Initialized
DEBUG - 2018-05-11 22:31:59 --> Programs MX_Controller Initialized
INFO - 2018-05-11 22:31:59 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-11 22:31:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-05-11 22:31:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-11 22:31:59 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-11 22:31:59 --> Login MX_Controller Initialized
DEBUG - 2018-05-11 22:31:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-11 22:31:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-05-11 22:31:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-05-11 22:31:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-05-11 22:31:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-05-11 22:31:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-05-11 22:31:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/programs/programs.php
INFO - 2018-05-11 22:31:59 --> Final output sent to browser
DEBUG - 2018-05-11 22:32:00 --> Total execution time: 0.7285
INFO - 2018-05-11 22:32:00 --> Config Class Initialized
INFO - 2018-05-11 22:32:00 --> Config Class Initialized
INFO - 2018-05-11 22:32:00 --> Hooks Class Initialized
INFO - 2018-05-11 22:32:00 --> Hooks Class Initialized
DEBUG - 2018-05-11 22:32:00 --> UTF-8 Support Enabled
INFO - 2018-05-11 22:32:00 --> Utf8 Class Initialized
INFO - 2018-05-11 22:32:00 --> URI Class Initialized
INFO - 2018-05-11 22:32:00 --> Router Class Initialized
INFO - 2018-05-11 22:32:00 --> Output Class Initialized
INFO - 2018-05-11 22:32:00 --> Security Class Initialized
DEBUG - 2018-05-11 22:32:00 --> UTF-8 Support Enabled
DEBUG - 2018-05-11 22:32:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 22:32:00 --> Utf8 Class Initialized
INFO - 2018-05-11 22:32:00 --> Input Class Initialized
INFO - 2018-05-11 22:32:00 --> URI Class Initialized
INFO - 2018-05-11 22:32:00 --> Language Class Initialized
ERROR - 2018-05-11 22:32:00 --> 404 Page Not Found: /index
INFO - 2018-05-11 22:32:00 --> Router Class Initialized
INFO - 2018-05-11 22:32:00 --> Output Class Initialized
INFO - 2018-05-11 22:32:00 --> Security Class Initialized
DEBUG - 2018-05-11 22:32:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 22:32:00 --> Input Class Initialized
INFO - 2018-05-11 22:32:00 --> Language Class Initialized
ERROR - 2018-05-11 22:32:00 --> 404 Page Not Found: /index
INFO - 2018-05-11 22:32:00 --> Config Class Initialized
INFO - 2018-05-11 22:32:00 --> Hooks Class Initialized
DEBUG - 2018-05-11 22:32:00 --> UTF-8 Support Enabled
INFO - 2018-05-11 22:32:00 --> Utf8 Class Initialized
INFO - 2018-05-11 22:32:01 --> URI Class Initialized
INFO - 2018-05-11 22:32:01 --> Router Class Initialized
INFO - 2018-05-11 22:32:01 --> Output Class Initialized
INFO - 2018-05-11 22:32:01 --> Security Class Initialized
DEBUG - 2018-05-11 22:32:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 22:32:01 --> Input Class Initialized
INFO - 2018-05-11 22:32:01 --> Language Class Initialized
INFO - 2018-05-11 22:32:01 --> Language Class Initialized
INFO - 2018-05-11 22:32:01 --> Config Class Initialized
INFO - 2018-05-11 22:32:01 --> Loader Class Initialized
DEBUG - 2018-05-11 22:32:01 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-11 22:32:01 --> Helper loaded: url_helper
INFO - 2018-05-11 22:32:01 --> Helper loaded: form_helper
INFO - 2018-05-11 22:32:01 --> Helper loaded: date_helper
INFO - 2018-05-11 22:32:01 --> Helper loaded: util_helper
INFO - 2018-05-11 22:32:01 --> Helper loaded: text_helper
INFO - 2018-05-11 22:32:01 --> Helper loaded: string_helper
INFO - 2018-05-11 22:32:01 --> Database Driver Class Initialized
DEBUG - 2018-05-11 22:32:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-11 22:32:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-11 22:32:01 --> Email Class Initialized
INFO - 2018-05-11 22:32:01 --> Controller Class Initialized
DEBUG - 2018-05-11 22:32:01 --> Company_types MX_Controller Initialized
INFO - 2018-05-11 22:32:01 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-11 22:32:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Company_types_model.php
DEBUG - 2018-05-11 22:32:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-11 22:32:01 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-11 22:32:01 --> Login MX_Controller Initialized
DEBUG - 2018-05-11 22:32:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
ERROR - 2018-05-11 22:32:01 --> Query error: Table 'consulting.company_types' doesn't exist - Invalid query: SELECT  company_types.ct_id,company_types.ct_name,company_types.added_date,company_types.status,company_types.ct_id FROM   company_types   WHERE company_types.ct_id!= ''     LIMIT 0, 10
INFO - 2018-05-11 22:32:01 --> Language file loaded: language/english/db_lang.php
INFO - 2018-05-11 22:32:14 --> Config Class Initialized
INFO - 2018-05-11 22:32:14 --> Hooks Class Initialized
DEBUG - 2018-05-11 22:32:14 --> UTF-8 Support Enabled
INFO - 2018-05-11 22:32:14 --> Utf8 Class Initialized
INFO - 2018-05-11 22:32:14 --> URI Class Initialized
INFO - 2018-05-11 22:32:14 --> Router Class Initialized
INFO - 2018-05-11 22:32:14 --> Output Class Initialized
INFO - 2018-05-11 22:32:14 --> Security Class Initialized
DEBUG - 2018-05-11 22:32:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 22:32:14 --> Input Class Initialized
INFO - 2018-05-11 22:32:14 --> Language Class Initialized
ERROR - 2018-05-11 22:32:14 --> 404 Page Not Found: /index
INFO - 2018-05-11 22:33:02 --> Config Class Initialized
INFO - 2018-05-11 22:33:02 --> Hooks Class Initialized
DEBUG - 2018-05-11 22:33:02 --> UTF-8 Support Enabled
INFO - 2018-05-11 22:33:02 --> Utf8 Class Initialized
INFO - 2018-05-11 22:33:02 --> URI Class Initialized
INFO - 2018-05-11 22:33:02 --> Router Class Initialized
INFO - 2018-05-11 22:33:02 --> Output Class Initialized
INFO - 2018-05-11 22:33:02 --> Security Class Initialized
DEBUG - 2018-05-11 22:33:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 22:33:02 --> Input Class Initialized
INFO - 2018-05-11 22:33:02 --> Language Class Initialized
INFO - 2018-05-11 22:33:02 --> Language Class Initialized
INFO - 2018-05-11 22:33:02 --> Config Class Initialized
INFO - 2018-05-11 22:33:02 --> Loader Class Initialized
DEBUG - 2018-05-11 22:33:02 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-11 22:33:02 --> Helper loaded: url_helper
INFO - 2018-05-11 22:33:02 --> Helper loaded: form_helper
INFO - 2018-05-11 22:33:02 --> Helper loaded: date_helper
INFO - 2018-05-11 22:33:02 --> Helper loaded: util_helper
INFO - 2018-05-11 22:33:02 --> Helper loaded: text_helper
INFO - 2018-05-11 22:33:02 --> Helper loaded: string_helper
INFO - 2018-05-11 22:33:02 --> Database Driver Class Initialized
DEBUG - 2018-05-11 22:33:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-11 22:33:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-11 22:33:02 --> Email Class Initialized
INFO - 2018-05-11 22:33:02 --> Controller Class Initialized
DEBUG - 2018-05-11 22:33:02 --> Programs MX_Controller Initialized
INFO - 2018-05-11 22:33:02 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-11 22:33:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-05-11 22:33:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-11 22:33:02 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-11 22:33:02 --> Login MX_Controller Initialized
DEBUG - 2018-05-11 22:33:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-11 22:33:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-05-11 22:33:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-05-11 22:33:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-05-11 22:33:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-05-11 22:33:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-05-11 22:33:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/programs/programs.php
INFO - 2018-05-11 22:33:03 --> Final output sent to browser
DEBUG - 2018-05-11 22:33:03 --> Total execution time: 0.7127
INFO - 2018-05-11 22:33:03 --> Config Class Initialized
INFO - 2018-05-11 22:33:03 --> Hooks Class Initialized
DEBUG - 2018-05-11 22:33:03 --> UTF-8 Support Enabled
INFO - 2018-05-11 22:33:03 --> Utf8 Class Initialized
INFO - 2018-05-11 22:33:03 --> URI Class Initialized
INFO - 2018-05-11 22:33:03 --> Router Class Initialized
INFO - 2018-05-11 22:33:03 --> Output Class Initialized
INFO - 2018-05-11 22:33:03 --> Security Class Initialized
DEBUG - 2018-05-11 22:33:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 22:33:03 --> Input Class Initialized
INFO - 2018-05-11 22:33:03 --> Language Class Initialized
ERROR - 2018-05-11 22:33:03 --> 404 Page Not Found: /index
INFO - 2018-05-11 22:33:03 --> Config Class Initialized
INFO - 2018-05-11 22:33:03 --> Hooks Class Initialized
DEBUG - 2018-05-11 22:33:03 --> UTF-8 Support Enabled
INFO - 2018-05-11 22:33:03 --> Utf8 Class Initialized
INFO - 2018-05-11 22:33:04 --> URI Class Initialized
INFO - 2018-05-11 22:33:04 --> Router Class Initialized
INFO - 2018-05-11 22:33:04 --> Output Class Initialized
INFO - 2018-05-11 22:33:04 --> Security Class Initialized
DEBUG - 2018-05-11 22:33:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 22:33:04 --> Input Class Initialized
INFO - 2018-05-11 22:33:04 --> Language Class Initialized
INFO - 2018-05-11 22:33:04 --> Language Class Initialized
INFO - 2018-05-11 22:33:04 --> Config Class Initialized
INFO - 2018-05-11 22:33:04 --> Loader Class Initialized
DEBUG - 2018-05-11 22:33:04 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-11 22:33:04 --> Helper loaded: url_helper
INFO - 2018-05-11 22:33:04 --> Helper loaded: form_helper
INFO - 2018-05-11 22:33:04 --> Helper loaded: date_helper
INFO - 2018-05-11 22:33:04 --> Helper loaded: util_helper
INFO - 2018-05-11 22:33:04 --> Helper loaded: text_helper
INFO - 2018-05-11 22:33:04 --> Helper loaded: string_helper
INFO - 2018-05-11 22:33:04 --> Database Driver Class Initialized
DEBUG - 2018-05-11 22:33:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-11 22:33:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-11 22:33:04 --> Email Class Initialized
INFO - 2018-05-11 22:33:04 --> Controller Class Initialized
DEBUG - 2018-05-11 22:33:04 --> Company_types MX_Controller Initialized
INFO - 2018-05-11 22:33:04 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-11 22:33:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Company_types_model.php
DEBUG - 2018-05-11 22:33:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-11 22:33:04 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-11 22:33:04 --> Login MX_Controller Initialized
DEBUG - 2018-05-11 22:33:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
ERROR - 2018-05-11 22:33:04 --> Query error: Table 'consulting.company_types' doesn't exist - Invalid query: SELECT  company_types.ct_id,company_types.ct_name,company_types.added_date,company_types.status,company_types.ct_id FROM   company_types   WHERE company_types.ct_id!= ''     LIMIT 0, 10
INFO - 2018-05-11 22:33:04 --> Language file loaded: language/english/db_lang.php
INFO - 2018-05-11 22:35:19 --> Config Class Initialized
INFO - 2018-05-11 22:35:19 --> Hooks Class Initialized
DEBUG - 2018-05-11 22:35:19 --> UTF-8 Support Enabled
INFO - 2018-05-11 22:35:19 --> Utf8 Class Initialized
INFO - 2018-05-11 22:35:19 --> URI Class Initialized
INFO - 2018-05-11 22:35:19 --> Router Class Initialized
INFO - 2018-05-11 22:35:19 --> Output Class Initialized
INFO - 2018-05-11 22:35:19 --> Security Class Initialized
DEBUG - 2018-05-11 22:35:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 22:35:19 --> Input Class Initialized
INFO - 2018-05-11 22:35:19 --> Language Class Initialized
INFO - 2018-05-11 22:35:19 --> Language Class Initialized
INFO - 2018-05-11 22:35:19 --> Config Class Initialized
INFO - 2018-05-11 22:35:19 --> Loader Class Initialized
DEBUG - 2018-05-11 22:35:19 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-11 22:35:19 --> Helper loaded: url_helper
INFO - 2018-05-11 22:35:19 --> Helper loaded: form_helper
INFO - 2018-05-11 22:35:19 --> Helper loaded: date_helper
INFO - 2018-05-11 22:35:19 --> Helper loaded: util_helper
INFO - 2018-05-11 22:35:19 --> Helper loaded: text_helper
INFO - 2018-05-11 22:35:19 --> Helper loaded: string_helper
INFO - 2018-05-11 22:35:19 --> Database Driver Class Initialized
DEBUG - 2018-05-11 22:35:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-11 22:35:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-11 22:35:19 --> Email Class Initialized
INFO - 2018-05-11 22:35:19 --> Controller Class Initialized
DEBUG - 2018-05-11 22:35:19 --> Programs MX_Controller Initialized
INFO - 2018-05-11 22:35:19 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-11 22:35:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-05-11 22:35:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-11 22:35:19 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-11 22:35:19 --> Login MX_Controller Initialized
DEBUG - 2018-05-11 22:35:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-11 22:35:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-05-11 22:35:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-05-11 22:35:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-05-11 22:35:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-05-11 22:35:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-05-11 22:35:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/programs/programs.php
INFO - 2018-05-11 22:35:19 --> Final output sent to browser
DEBUG - 2018-05-11 22:35:19 --> Total execution time: 0.7296
INFO - 2018-05-11 22:35:20 --> Config Class Initialized
INFO - 2018-05-11 22:35:20 --> Hooks Class Initialized
DEBUG - 2018-05-11 22:35:20 --> UTF-8 Support Enabled
INFO - 2018-05-11 22:35:20 --> Utf8 Class Initialized
INFO - 2018-05-11 22:35:20 --> URI Class Initialized
INFO - 2018-05-11 22:35:21 --> Router Class Initialized
INFO - 2018-05-11 22:35:21 --> Output Class Initialized
INFO - 2018-05-11 22:35:21 --> Security Class Initialized
DEBUG - 2018-05-11 22:35:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 22:35:21 --> Input Class Initialized
INFO - 2018-05-11 22:35:21 --> Language Class Initialized
INFO - 2018-05-11 22:35:21 --> Language Class Initialized
INFO - 2018-05-11 22:35:21 --> Config Class Initialized
INFO - 2018-05-11 22:35:21 --> Loader Class Initialized
DEBUG - 2018-05-11 22:35:21 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-11 22:35:21 --> Helper loaded: url_helper
INFO - 2018-05-11 22:35:21 --> Helper loaded: form_helper
INFO - 2018-05-11 22:35:21 --> Helper loaded: date_helper
INFO - 2018-05-11 22:35:21 --> Helper loaded: util_helper
INFO - 2018-05-11 22:35:21 --> Helper loaded: text_helper
INFO - 2018-05-11 22:35:21 --> Helper loaded: string_helper
INFO - 2018-05-11 22:35:21 --> Database Driver Class Initialized
DEBUG - 2018-05-11 22:35:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-11 22:35:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-11 22:35:21 --> Email Class Initialized
INFO - 2018-05-11 22:35:21 --> Controller Class Initialized
DEBUG - 2018-05-11 22:35:21 --> Company_types MX_Controller Initialized
INFO - 2018-05-11 22:35:21 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-11 22:35:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Company_types_model.php
DEBUG - 2018-05-11 22:35:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-11 22:35:21 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-11 22:35:21 --> Login MX_Controller Initialized
DEBUG - 2018-05-11 22:35:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
ERROR - 2018-05-11 22:35:21 --> Query error: Table 'consulting.company_types' doesn't exist - Invalid query: SELECT  company_types.ct_id,company_types.ct_name,company_types.added_date,company_types.status,company_types.ct_id FROM   company_types   WHERE company_types.ct_id!= ''     LIMIT 0, 10
INFO - 2018-05-11 22:35:21 --> Language file loaded: language/english/db_lang.php
INFO - 2018-05-11 22:35:25 --> Config Class Initialized
INFO - 2018-05-11 22:35:25 --> Hooks Class Initialized
DEBUG - 2018-05-11 22:35:25 --> UTF-8 Support Enabled
INFO - 2018-05-11 22:35:25 --> Utf8 Class Initialized
INFO - 2018-05-11 22:35:25 --> URI Class Initialized
INFO - 2018-05-11 22:35:25 --> Router Class Initialized
INFO - 2018-05-11 22:35:25 --> Output Class Initialized
INFO - 2018-05-11 22:35:25 --> Security Class Initialized
DEBUG - 2018-05-11 22:35:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 22:35:25 --> Input Class Initialized
INFO - 2018-05-11 22:35:25 --> Language Class Initialized
INFO - 2018-05-11 22:35:25 --> Language Class Initialized
INFO - 2018-05-11 22:35:26 --> Config Class Initialized
INFO - 2018-05-11 22:35:26 --> Loader Class Initialized
DEBUG - 2018-05-11 22:35:26 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-11 22:35:26 --> Helper loaded: url_helper
INFO - 2018-05-11 22:35:26 --> Helper loaded: form_helper
INFO - 2018-05-11 22:35:26 --> Helper loaded: date_helper
INFO - 2018-05-11 22:35:26 --> Helper loaded: util_helper
INFO - 2018-05-11 22:35:26 --> Helper loaded: text_helper
INFO - 2018-05-11 22:35:26 --> Helper loaded: string_helper
INFO - 2018-05-11 22:35:26 --> Database Driver Class Initialized
DEBUG - 2018-05-11 22:35:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-11 22:35:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-11 22:35:26 --> Email Class Initialized
INFO - 2018-05-11 22:35:26 --> Controller Class Initialized
DEBUG - 2018-05-11 22:35:26 --> Company_types MX_Controller Initialized
INFO - 2018-05-11 22:35:26 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-11 22:35:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Company_types_model.php
DEBUG - 2018-05-11 22:35:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-11 22:35:26 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-11 22:35:26 --> Login MX_Controller Initialized
DEBUG - 2018-05-11 22:35:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
ERROR - 2018-05-11 22:35:26 --> Query error: Table 'consulting.company_types' doesn't exist - Invalid query: SELECT  company_types.ct_id,company_types.ct_name,company_types.added_date,company_types.status,company_types.ct_id FROM   company_types   WHERE company_types.ct_id!= ''     
INFO - 2018-05-11 22:35:26 --> Language file loaded: language/english/db_lang.php
INFO - 2018-05-11 22:36:04 --> Config Class Initialized
INFO - 2018-05-11 22:36:04 --> Hooks Class Initialized
DEBUG - 2018-05-11 22:36:04 --> UTF-8 Support Enabled
INFO - 2018-05-11 22:36:04 --> Utf8 Class Initialized
INFO - 2018-05-11 22:36:04 --> URI Class Initialized
INFO - 2018-05-11 22:36:04 --> Router Class Initialized
INFO - 2018-05-11 22:36:04 --> Output Class Initialized
INFO - 2018-05-11 22:36:04 --> Security Class Initialized
DEBUG - 2018-05-11 22:36:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 22:36:04 --> Input Class Initialized
INFO - 2018-05-11 22:36:04 --> Language Class Initialized
INFO - 2018-05-11 22:36:04 --> Language Class Initialized
INFO - 2018-05-11 22:36:04 --> Config Class Initialized
INFO - 2018-05-11 22:36:04 --> Loader Class Initialized
DEBUG - 2018-05-11 22:36:04 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-11 22:36:04 --> Helper loaded: url_helper
INFO - 2018-05-11 22:36:04 --> Helper loaded: form_helper
INFO - 2018-05-11 22:36:04 --> Helper loaded: date_helper
INFO - 2018-05-11 22:36:04 --> Helper loaded: util_helper
INFO - 2018-05-11 22:36:04 --> Helper loaded: text_helper
INFO - 2018-05-11 22:36:04 --> Helper loaded: string_helper
INFO - 2018-05-11 22:36:04 --> Database Driver Class Initialized
DEBUG - 2018-05-11 22:36:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-11 22:36:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-11 22:36:04 --> Email Class Initialized
INFO - 2018-05-11 22:36:04 --> Controller Class Initialized
DEBUG - 2018-05-11 22:36:04 --> Company_types MX_Controller Initialized
INFO - 2018-05-11 22:36:05 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-11 22:36:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Company_types_model.php
DEBUG - 2018-05-11 22:36:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-11 22:36:05 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-11 22:36:05 --> Login MX_Controller Initialized
DEBUG - 2018-05-11 22:36:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
ERROR - 2018-05-11 22:36:05 --> Query error: Table 'consulting.company_types' doesn't exist - Invalid query: SELECT  company_types.ct_id,company_types.ct_name,company_types.added_date,company_types.status,company_types.ct_id FROM   company_types   WHERE company_types.ct_id!= ''     
INFO - 2018-05-11 22:36:05 --> Language file loaded: language/english/db_lang.php
INFO - 2018-05-11 22:36:08 --> Config Class Initialized
INFO - 2018-05-11 22:36:08 --> Hooks Class Initialized
DEBUG - 2018-05-11 22:36:08 --> UTF-8 Support Enabled
INFO - 2018-05-11 22:36:08 --> Utf8 Class Initialized
INFO - 2018-05-11 22:36:08 --> URI Class Initialized
INFO - 2018-05-11 22:36:08 --> Router Class Initialized
INFO - 2018-05-11 22:36:08 --> Output Class Initialized
INFO - 2018-05-11 22:36:08 --> Security Class Initialized
DEBUG - 2018-05-11 22:36:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 22:36:08 --> Input Class Initialized
INFO - 2018-05-11 22:36:08 --> Language Class Initialized
INFO - 2018-05-11 22:36:08 --> Language Class Initialized
INFO - 2018-05-11 22:36:08 --> Config Class Initialized
INFO - 2018-05-11 22:36:08 --> Loader Class Initialized
DEBUG - 2018-05-11 22:36:08 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-11 22:36:08 --> Helper loaded: url_helper
INFO - 2018-05-11 22:36:08 --> Helper loaded: form_helper
INFO - 2018-05-11 22:36:08 --> Helper loaded: date_helper
INFO - 2018-05-11 22:36:08 --> Helper loaded: util_helper
INFO - 2018-05-11 22:36:08 --> Helper loaded: text_helper
INFO - 2018-05-11 22:36:08 --> Helper loaded: string_helper
INFO - 2018-05-11 22:36:08 --> Database Driver Class Initialized
DEBUG - 2018-05-11 22:36:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-11 22:36:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-11 22:36:08 --> Email Class Initialized
INFO - 2018-05-11 22:36:08 --> Controller Class Initialized
DEBUG - 2018-05-11 22:36:08 --> Programs MX_Controller Initialized
INFO - 2018-05-11 22:36:08 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-11 22:36:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-05-11 22:36:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-11 22:36:08 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-11 22:36:08 --> Login MX_Controller Initialized
DEBUG - 2018-05-11 22:36:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-11 22:36:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-05-11 22:36:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-05-11 22:36:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-05-11 22:36:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-05-11 22:36:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-05-11 22:36:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/programs/programs.php
INFO - 2018-05-11 22:36:08 --> Final output sent to browser
DEBUG - 2018-05-11 22:36:09 --> Total execution time: 0.7482
INFO - 2018-05-11 22:36:09 --> Config Class Initialized
INFO - 2018-05-11 22:36:09 --> Hooks Class Initialized
DEBUG - 2018-05-11 22:36:09 --> UTF-8 Support Enabled
INFO - 2018-05-11 22:36:09 --> Utf8 Class Initialized
INFO - 2018-05-11 22:36:10 --> URI Class Initialized
INFO - 2018-05-11 22:36:10 --> Router Class Initialized
INFO - 2018-05-11 22:36:10 --> Output Class Initialized
INFO - 2018-05-11 22:36:10 --> Security Class Initialized
DEBUG - 2018-05-11 22:36:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 22:36:10 --> Input Class Initialized
INFO - 2018-05-11 22:36:10 --> Language Class Initialized
INFO - 2018-05-11 22:36:10 --> Language Class Initialized
INFO - 2018-05-11 22:36:10 --> Config Class Initialized
INFO - 2018-05-11 22:36:10 --> Loader Class Initialized
DEBUG - 2018-05-11 22:36:10 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-11 22:36:10 --> Helper loaded: url_helper
INFO - 2018-05-11 22:36:10 --> Helper loaded: form_helper
INFO - 2018-05-11 22:36:10 --> Helper loaded: date_helper
INFO - 2018-05-11 22:36:10 --> Helper loaded: util_helper
INFO - 2018-05-11 22:36:10 --> Helper loaded: text_helper
INFO - 2018-05-11 22:36:10 --> Helper loaded: string_helper
INFO - 2018-05-11 22:36:10 --> Database Driver Class Initialized
DEBUG - 2018-05-11 22:36:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-11 22:36:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-11 22:36:10 --> Email Class Initialized
INFO - 2018-05-11 22:36:10 --> Controller Class Initialized
DEBUG - 2018-05-11 22:36:10 --> Programs MX_Controller Initialized
INFO - 2018-05-11 22:36:10 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-11 22:36:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-05-11 22:36:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-11 22:36:10 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-11 22:36:10 --> Login MX_Controller Initialized
DEBUG - 2018-05-11 22:36:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-11 22:36:10 --> Final output sent to browser
DEBUG - 2018-05-11 22:36:10 --> Total execution time: 0.7904
INFO - 2018-05-11 22:36:43 --> Config Class Initialized
INFO - 2018-05-11 22:36:43 --> Hooks Class Initialized
DEBUG - 2018-05-11 22:36:43 --> UTF-8 Support Enabled
INFO - 2018-05-11 22:36:43 --> Utf8 Class Initialized
INFO - 2018-05-11 22:36:43 --> URI Class Initialized
INFO - 2018-05-11 22:36:43 --> Router Class Initialized
INFO - 2018-05-11 22:36:43 --> Output Class Initialized
INFO - 2018-05-11 22:36:43 --> Security Class Initialized
DEBUG - 2018-05-11 22:36:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 22:36:44 --> Input Class Initialized
INFO - 2018-05-11 22:36:44 --> Language Class Initialized
INFO - 2018-05-11 22:36:44 --> Language Class Initialized
INFO - 2018-05-11 22:36:44 --> Config Class Initialized
INFO - 2018-05-11 22:36:44 --> Loader Class Initialized
DEBUG - 2018-05-11 22:36:44 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-11 22:36:44 --> Helper loaded: url_helper
INFO - 2018-05-11 22:36:44 --> Helper loaded: form_helper
INFO - 2018-05-11 22:36:44 --> Helper loaded: date_helper
INFO - 2018-05-11 22:36:44 --> Helper loaded: util_helper
INFO - 2018-05-11 22:36:44 --> Helper loaded: text_helper
INFO - 2018-05-11 22:36:44 --> Helper loaded: string_helper
INFO - 2018-05-11 22:36:44 --> Database Driver Class Initialized
DEBUG - 2018-05-11 22:36:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-11 22:36:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-11 22:36:44 --> Email Class Initialized
INFO - 2018-05-11 22:36:44 --> Controller Class Initialized
DEBUG - 2018-05-11 22:36:44 --> Programs MX_Controller Initialized
INFO - 2018-05-11 22:36:44 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-11 22:36:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-05-11 22:36:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-11 22:36:44 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-11 22:36:44 --> Login MX_Controller Initialized
DEBUG - 2018-05-11 22:36:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-11 22:36:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-05-11 22:36:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-05-11 22:36:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-05-11 22:36:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-05-11 22:36:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-05-11 22:36:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/programs/programs.php
INFO - 2018-05-11 22:36:44 --> Final output sent to browser
DEBUG - 2018-05-11 22:36:44 --> Total execution time: 0.7530
INFO - 2018-05-11 22:36:45 --> Config Class Initialized
INFO - 2018-05-11 22:36:45 --> Hooks Class Initialized
DEBUG - 2018-05-11 22:36:45 --> UTF-8 Support Enabled
INFO - 2018-05-11 22:36:45 --> Utf8 Class Initialized
INFO - 2018-05-11 22:36:45 --> URI Class Initialized
INFO - 2018-05-11 22:36:45 --> Router Class Initialized
INFO - 2018-05-11 22:36:45 --> Output Class Initialized
INFO - 2018-05-11 22:36:45 --> Security Class Initialized
DEBUG - 2018-05-11 22:36:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 22:36:45 --> Input Class Initialized
INFO - 2018-05-11 22:36:45 --> Language Class Initialized
INFO - 2018-05-11 22:36:45 --> Language Class Initialized
INFO - 2018-05-11 22:36:45 --> Config Class Initialized
INFO - 2018-05-11 22:36:45 --> Loader Class Initialized
DEBUG - 2018-05-11 22:36:45 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-11 22:36:45 --> Helper loaded: url_helper
INFO - 2018-05-11 22:36:45 --> Helper loaded: form_helper
INFO - 2018-05-11 22:36:45 --> Helper loaded: date_helper
INFO - 2018-05-11 22:36:45 --> Helper loaded: util_helper
INFO - 2018-05-11 22:36:45 --> Helper loaded: text_helper
INFO - 2018-05-11 22:36:45 --> Helper loaded: string_helper
INFO - 2018-05-11 22:36:46 --> Database Driver Class Initialized
DEBUG - 2018-05-11 22:36:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-11 22:36:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-11 22:36:46 --> Email Class Initialized
INFO - 2018-05-11 22:36:46 --> Controller Class Initialized
DEBUG - 2018-05-11 22:36:46 --> Programs MX_Controller Initialized
INFO - 2018-05-11 22:36:46 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-11 22:36:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-05-11 22:36:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-11 22:36:46 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-11 22:36:46 --> Login MX_Controller Initialized
DEBUG - 2018-05-11 22:36:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-11 22:36:46 --> Final output sent to browser
DEBUG - 2018-05-11 22:36:46 --> Total execution time: 0.8821
INFO - 2018-05-11 22:36:48 --> Config Class Initialized
INFO - 2018-05-11 22:36:48 --> Hooks Class Initialized
DEBUG - 2018-05-11 22:36:48 --> UTF-8 Support Enabled
INFO - 2018-05-11 22:36:48 --> Utf8 Class Initialized
INFO - 2018-05-11 22:36:48 --> URI Class Initialized
INFO - 2018-05-11 22:36:48 --> Router Class Initialized
INFO - 2018-05-11 22:36:48 --> Output Class Initialized
INFO - 2018-05-11 22:36:48 --> Security Class Initialized
DEBUG - 2018-05-11 22:36:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 22:36:49 --> Input Class Initialized
INFO - 2018-05-11 22:36:49 --> Language Class Initialized
INFO - 2018-05-11 22:36:49 --> Language Class Initialized
INFO - 2018-05-11 22:36:49 --> Config Class Initialized
INFO - 2018-05-11 22:36:49 --> Loader Class Initialized
DEBUG - 2018-05-11 22:36:49 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-11 22:36:49 --> Helper loaded: url_helper
INFO - 2018-05-11 22:36:49 --> Helper loaded: form_helper
INFO - 2018-05-11 22:36:49 --> Helper loaded: date_helper
INFO - 2018-05-11 22:36:49 --> Helper loaded: util_helper
INFO - 2018-05-11 22:36:49 --> Helper loaded: text_helper
INFO - 2018-05-11 22:36:49 --> Helper loaded: string_helper
INFO - 2018-05-11 22:36:49 --> Database Driver Class Initialized
DEBUG - 2018-05-11 22:36:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-11 22:36:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-11 22:36:49 --> Email Class Initialized
INFO - 2018-05-11 22:36:49 --> Controller Class Initialized
DEBUG - 2018-05-11 22:36:49 --> Programs MX_Controller Initialized
INFO - 2018-05-11 22:36:49 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-11 22:36:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-05-11 22:36:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-11 22:36:49 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-11 22:36:49 --> Login MX_Controller Initialized
DEBUG - 2018-05-11 22:36:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-11 22:37:19 --> Config Class Initialized
INFO - 2018-05-11 22:37:19 --> Hooks Class Initialized
DEBUG - 2018-05-11 22:37:19 --> UTF-8 Support Enabled
INFO - 2018-05-11 22:37:19 --> Utf8 Class Initialized
INFO - 2018-05-11 22:37:19 --> URI Class Initialized
INFO - 2018-05-11 22:37:19 --> Router Class Initialized
INFO - 2018-05-11 22:37:19 --> Output Class Initialized
INFO - 2018-05-11 22:37:19 --> Security Class Initialized
DEBUG - 2018-05-11 22:37:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 22:37:19 --> Input Class Initialized
INFO - 2018-05-11 22:37:19 --> Language Class Initialized
INFO - 2018-05-11 22:37:19 --> Language Class Initialized
INFO - 2018-05-11 22:37:19 --> Config Class Initialized
INFO - 2018-05-11 22:37:19 --> Loader Class Initialized
DEBUG - 2018-05-11 22:37:19 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-11 22:37:19 --> Helper loaded: url_helper
INFO - 2018-05-11 22:37:19 --> Helper loaded: form_helper
INFO - 2018-05-11 22:37:19 --> Helper loaded: date_helper
INFO - 2018-05-11 22:37:19 --> Helper loaded: util_helper
INFO - 2018-05-11 22:37:19 --> Helper loaded: text_helper
INFO - 2018-05-11 22:37:19 --> Helper loaded: string_helper
INFO - 2018-05-11 22:37:19 --> Database Driver Class Initialized
DEBUG - 2018-05-11 22:37:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-11 22:37:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-11 22:37:19 --> Email Class Initialized
INFO - 2018-05-11 22:37:19 --> Controller Class Initialized
DEBUG - 2018-05-11 22:37:19 --> Programs MX_Controller Initialized
INFO - 2018-05-11 22:37:19 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-11 22:37:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-05-11 22:37:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-11 22:37:19 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-11 22:37:19 --> Login MX_Controller Initialized
DEBUG - 2018-05-11 22:37:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-11 22:37:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-05-11 22:37:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-05-11 22:37:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-05-11 22:37:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-05-11 22:37:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-05-11 22:37:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/programs/create_program.php
INFO - 2018-05-11 22:37:19 --> Final output sent to browser
DEBUG - 2018-05-11 22:37:19 --> Total execution time: 0.7503
INFO - 2018-05-11 22:37:19 --> Config Class Initialized
INFO - 2018-05-11 22:37:19 --> Hooks Class Initialized
DEBUG - 2018-05-11 22:37:20 --> UTF-8 Support Enabled
INFO - 2018-05-11 22:37:20 --> Utf8 Class Initialized
INFO - 2018-05-11 22:37:20 --> URI Class Initialized
INFO - 2018-05-11 22:37:20 --> Router Class Initialized
INFO - 2018-05-11 22:37:20 --> Output Class Initialized
INFO - 2018-05-11 22:37:20 --> Security Class Initialized
DEBUG - 2018-05-11 22:37:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 22:37:20 --> Input Class Initialized
INFO - 2018-05-11 22:37:20 --> Language Class Initialized
ERROR - 2018-05-11 22:37:20 --> 404 Page Not Found: /index
INFO - 2018-05-11 22:37:20 --> Config Class Initialized
INFO - 2018-05-11 22:37:20 --> Hooks Class Initialized
DEBUG - 2018-05-11 22:37:20 --> UTF-8 Support Enabled
INFO - 2018-05-11 22:37:20 --> Utf8 Class Initialized
INFO - 2018-05-11 22:37:20 --> URI Class Initialized
INFO - 2018-05-11 22:37:20 --> Router Class Initialized
INFO - 2018-05-11 22:37:20 --> Output Class Initialized
INFO - 2018-05-11 22:37:20 --> Security Class Initialized
DEBUG - 2018-05-11 22:37:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 22:37:20 --> Input Class Initialized
INFO - 2018-05-11 22:37:20 --> Language Class Initialized
ERROR - 2018-05-11 22:37:20 --> 404 Page Not Found: /index
INFO - 2018-05-11 23:04:25 --> Config Class Initialized
INFO - 2018-05-11 23:04:25 --> Config Class Initialized
INFO - 2018-05-11 23:04:25 --> Hooks Class Initialized
INFO - 2018-05-11 23:04:25 --> Hooks Class Initialized
INFO - 2018-05-11 23:04:25 --> Config Class Initialized
INFO - 2018-05-11 23:04:25 --> Config Class Initialized
INFO - 2018-05-11 23:04:25 --> Config Class Initialized
INFO - 2018-05-11 23:04:25 --> Hooks Class Initialized
INFO - 2018-05-11 23:04:25 --> Hooks Class Initialized
DEBUG - 2018-05-11 23:04:25 --> UTF-8 Support Enabled
DEBUG - 2018-05-11 23:04:25 --> UTF-8 Support Enabled
DEBUG - 2018-05-11 23:04:25 --> UTF-8 Support Enabled
DEBUG - 2018-05-11 23:04:25 --> UTF-8 Support Enabled
INFO - 2018-05-11 23:04:25 --> Utf8 Class Initialized
INFO - 2018-05-11 23:04:25 --> Hooks Class Initialized
INFO - 2018-05-11 23:04:25 --> Utf8 Class Initialized
INFO - 2018-05-11 23:04:25 --> Utf8 Class Initialized
INFO - 2018-05-11 23:04:25 --> URI Class Initialized
INFO - 2018-05-11 23:04:25 --> URI Class Initialized
DEBUG - 2018-05-11 23:04:25 --> UTF-8 Support Enabled
INFO - 2018-05-11 23:04:25 --> Utf8 Class Initialized
INFO - 2018-05-11 23:04:25 --> URI Class Initialized
INFO - 2018-05-11 23:04:25 --> Router Class Initialized
INFO - 2018-05-11 23:04:25 --> URI Class Initialized
INFO - 2018-05-11 23:04:25 --> Utf8 Class Initialized
INFO - 2018-05-11 23:04:25 --> Router Class Initialized
INFO - 2018-05-11 23:04:25 --> Router Class Initialized
INFO - 2018-05-11 23:04:25 --> Output Class Initialized
INFO - 2018-05-11 23:04:25 --> Security Class Initialized
INFO - 2018-05-11 23:04:25 --> Output Class Initialized
INFO - 2018-05-11 23:04:25 --> Router Class Initialized
INFO - 2018-05-11 23:04:25 --> URI Class Initialized
INFO - 2018-05-11 23:04:25 --> Output Class Initialized
DEBUG - 2018-05-11 23:04:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 23:04:25 --> Security Class Initialized
DEBUG - 2018-05-11 23:04:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 23:04:25 --> Input Class Initialized
INFO - 2018-05-11 23:04:25 --> Language Class Initialized
ERROR - 2018-05-11 23:04:25 --> 404 Page Not Found: /index
INFO - 2018-05-11 23:04:25 --> Output Class Initialized
INFO - 2018-05-11 23:04:25 --> Router Class Initialized
INFO - 2018-05-11 23:04:25 --> Security Class Initialized
INFO - 2018-05-11 23:04:25 --> Input Class Initialized
INFO - 2018-05-11 23:04:25 --> Security Class Initialized
INFO - 2018-05-11 23:04:25 --> Config Class Initialized
INFO - 2018-05-11 23:04:25 --> Language Class Initialized
DEBUG - 2018-05-11 23:04:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-11 23:04:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 23:04:25 --> Hooks Class Initialized
INFO - 2018-05-11 23:04:25 --> Output Class Initialized
INFO - 2018-05-11 23:04:25 --> Input Class Initialized
INFO - 2018-05-11 23:04:25 --> Input Class Initialized
INFO - 2018-05-11 23:04:25 --> Security Class Initialized
DEBUG - 2018-05-11 23:04:25 --> UTF-8 Support Enabled
ERROR - 2018-05-11 23:04:25 --> 404 Page Not Found: /index
INFO - 2018-05-11 23:04:25 --> Utf8 Class Initialized
INFO - 2018-05-11 23:04:25 --> Language Class Initialized
INFO - 2018-05-11 23:04:25 --> Config Class Initialized
INFO - 2018-05-11 23:04:25 --> Language Class Initialized
DEBUG - 2018-05-11 23:04:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 23:04:25 --> Hooks Class Initialized
INFO - 2018-05-11 23:04:25 --> URI Class Initialized
INFO - 2018-05-11 23:04:25 --> Input Class Initialized
ERROR - 2018-05-11 23:04:25 --> 404 Page Not Found: /index
ERROR - 2018-05-11 23:04:25 --> 404 Page Not Found: /index
DEBUG - 2018-05-11 23:04:25 --> UTF-8 Support Enabled
INFO - 2018-05-11 23:04:25 --> Language Class Initialized
INFO - 2018-05-11 23:04:25 --> Router Class Initialized
INFO - 2018-05-11 23:04:25 --> Config Class Initialized
INFO - 2018-05-11 23:04:25 --> Config Class Initialized
INFO - 2018-05-11 23:04:25 --> Hooks Class Initialized
INFO - 2018-05-11 23:04:25 --> Hooks Class Initialized
ERROR - 2018-05-11 23:04:25 --> 404 Page Not Found: /index
INFO - 2018-05-11 23:04:25 --> Output Class Initialized
INFO - 2018-05-11 23:04:25 --> Utf8 Class Initialized
DEBUG - 2018-05-11 23:04:25 --> UTF-8 Support Enabled
DEBUG - 2018-05-11 23:04:25 --> UTF-8 Support Enabled
INFO - 2018-05-11 23:04:25 --> Security Class Initialized
INFO - 2018-05-11 23:04:25 --> URI Class Initialized
INFO - 2018-05-11 23:04:25 --> Utf8 Class Initialized
DEBUG - 2018-05-11 23:04:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 23:04:25 --> Utf8 Class Initialized
INFO - 2018-05-11 23:04:25 --> Router Class Initialized
INFO - 2018-05-11 23:04:25 --> Output Class Initialized
INFO - 2018-05-11 23:04:25 --> URI Class Initialized
INFO - 2018-05-11 23:04:25 --> Input Class Initialized
INFO - 2018-05-11 23:04:25 --> URI Class Initialized
INFO - 2018-05-11 23:04:26 --> Router Class Initialized
INFO - 2018-05-11 23:04:26 --> Language Class Initialized
INFO - 2018-05-11 23:04:26 --> Router Class Initialized
INFO - 2018-05-11 23:04:26 --> Security Class Initialized
INFO - 2018-05-11 23:04:26 --> Output Class Initialized
DEBUG - 2018-05-11 23:04:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 23:04:26 --> Output Class Initialized
ERROR - 2018-05-11 23:04:26 --> 404 Page Not Found: /index
INFO - 2018-05-11 23:04:26 --> Security Class Initialized
INFO - 2018-05-11 23:04:26 --> Input Class Initialized
INFO - 2018-05-11 23:04:26 --> Security Class Initialized
INFO - 2018-05-11 23:04:26 --> Config Class Initialized
INFO - 2018-05-11 23:04:26 --> Hooks Class Initialized
DEBUG - 2018-05-11 23:04:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-11 23:04:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 23:04:26 --> Input Class Initialized
DEBUG - 2018-05-11 23:04:26 --> UTF-8 Support Enabled
INFO - 2018-05-11 23:04:26 --> Input Class Initialized
INFO - 2018-05-11 23:04:26 --> Language Class Initialized
INFO - 2018-05-11 23:04:26 --> Utf8 Class Initialized
INFO - 2018-05-11 23:04:26 --> Language Class Initialized
ERROR - 2018-05-11 23:04:26 --> 404 Page Not Found: /index
INFO - 2018-05-11 23:04:26 --> URI Class Initialized
INFO - 2018-05-11 23:04:26 --> Language Class Initialized
ERROR - 2018-05-11 23:04:26 --> 404 Page Not Found: /index
INFO - 2018-05-11 23:04:26 --> Config Class Initialized
ERROR - 2018-05-11 23:04:26 --> 404 Page Not Found: /index
INFO - 2018-05-11 23:04:26 --> Router Class Initialized
INFO - 2018-05-11 23:04:26 --> Config Class Initialized
INFO - 2018-05-11 23:04:26 --> Hooks Class Initialized
INFO - 2018-05-11 23:04:26 --> Hooks Class Initialized
INFO - 2018-05-11 23:04:26 --> Output Class Initialized
INFO - 2018-05-11 23:04:26 --> Config Class Initialized
INFO - 2018-05-11 23:04:26 --> Hooks Class Initialized
DEBUG - 2018-05-11 23:04:26 --> UTF-8 Support Enabled
INFO - 2018-05-11 23:04:26 --> Security Class Initialized
DEBUG - 2018-05-11 23:04:26 --> UTF-8 Support Enabled
INFO - 2018-05-11 23:04:26 --> Utf8 Class Initialized
INFO - 2018-05-11 23:04:26 --> Utf8 Class Initialized
DEBUG - 2018-05-11 23:04:26 --> UTF-8 Support Enabled
DEBUG - 2018-05-11 23:04:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 23:04:26 --> Utf8 Class Initialized
INFO - 2018-05-11 23:04:26 --> URI Class Initialized
INFO - 2018-05-11 23:04:26 --> Input Class Initialized
INFO - 2018-05-11 23:04:26 --> URI Class Initialized
INFO - 2018-05-11 23:04:26 --> Router Class Initialized
INFO - 2018-05-11 23:04:26 --> Language Class Initialized
INFO - 2018-05-11 23:04:26 --> Router Class Initialized
INFO - 2018-05-11 23:04:26 --> URI Class Initialized
ERROR - 2018-05-11 23:04:26 --> 404 Page Not Found: /index
INFO - 2018-05-11 23:04:26 --> Router Class Initialized
INFO - 2018-05-11 23:04:26 --> Output Class Initialized
INFO - 2018-05-11 23:04:26 --> Output Class Initialized
INFO - 2018-05-11 23:04:26 --> Output Class Initialized
INFO - 2018-05-11 23:04:26 --> Security Class Initialized
INFO - 2018-05-11 23:04:26 --> Security Class Initialized
INFO - 2018-05-11 23:04:26 --> Security Class Initialized
DEBUG - 2018-05-11 23:04:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 23:04:26 --> Input Class Initialized
DEBUG - 2018-05-11 23:04:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-11 23:04:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 23:04:26 --> Language Class Initialized
INFO - 2018-05-11 23:04:26 --> Input Class Initialized
ERROR - 2018-05-11 23:04:26 --> 404 Page Not Found: /index
INFO - 2018-05-11 23:04:26 --> Input Class Initialized
INFO - 2018-05-11 23:04:26 --> Language Class Initialized
INFO - 2018-05-11 23:04:26 --> Language Class Initialized
ERROR - 2018-05-11 23:04:26 --> 404 Page Not Found: /index
ERROR - 2018-05-11 23:04:26 --> 404 Page Not Found: /index
INFO - 2018-05-11 23:06:47 --> Config Class Initialized
INFO - 2018-05-11 23:06:47 --> Config Class Initialized
INFO - 2018-05-11 23:06:47 --> Config Class Initialized
INFO - 2018-05-11 23:06:48 --> Config Class Initialized
INFO - 2018-05-11 23:06:48 --> Config Class Initialized
INFO - 2018-05-11 23:06:48 --> Hooks Class Initialized
INFO - 2018-05-11 23:06:48 --> Hooks Class Initialized
INFO - 2018-05-11 23:06:48 --> Hooks Class Initialized
INFO - 2018-05-11 23:06:48 --> Hooks Class Initialized
DEBUG - 2018-05-11 23:06:48 --> UTF-8 Support Enabled
DEBUG - 2018-05-11 23:06:48 --> UTF-8 Support Enabled
INFO - 2018-05-11 23:06:48 --> Hooks Class Initialized
DEBUG - 2018-05-11 23:06:48 --> UTF-8 Support Enabled
DEBUG - 2018-05-11 23:06:48 --> UTF-8 Support Enabled
INFO - 2018-05-11 23:06:48 --> Utf8 Class Initialized
INFO - 2018-05-11 23:06:48 --> Utf8 Class Initialized
INFO - 2018-05-11 23:06:48 --> Utf8 Class Initialized
INFO - 2018-05-11 23:06:48 --> Utf8 Class Initialized
INFO - 2018-05-11 23:06:48 --> URI Class Initialized
DEBUG - 2018-05-11 23:06:48 --> UTF-8 Support Enabled
INFO - 2018-05-11 23:06:48 --> URI Class Initialized
INFO - 2018-05-11 23:06:48 --> URI Class Initialized
INFO - 2018-05-11 23:06:48 --> Utf8 Class Initialized
INFO - 2018-05-11 23:06:48 --> URI Class Initialized
INFO - 2018-05-11 23:06:48 --> Router Class Initialized
INFO - 2018-05-11 23:06:48 --> Router Class Initialized
INFO - 2018-05-11 23:06:48 --> Output Class Initialized
INFO - 2018-05-11 23:06:48 --> URI Class Initialized
INFO - 2018-05-11 23:06:48 --> Output Class Initialized
INFO - 2018-05-11 23:06:48 --> Router Class Initialized
INFO - 2018-05-11 23:06:48 --> Security Class Initialized
INFO - 2018-05-11 23:06:48 --> Router Class Initialized
INFO - 2018-05-11 23:06:48 --> Output Class Initialized
INFO - 2018-05-11 23:06:48 --> Router Class Initialized
INFO - 2018-05-11 23:06:48 --> Security Class Initialized
DEBUG - 2018-05-11 23:06:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-11 23:06:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 23:06:48 --> Security Class Initialized
INFO - 2018-05-11 23:06:48 --> Output Class Initialized
INFO - 2018-05-11 23:06:48 --> Output Class Initialized
INFO - 2018-05-11 23:06:48 --> Input Class Initialized
INFO - 2018-05-11 23:06:48 --> Input Class Initialized
INFO - 2018-05-11 23:06:48 --> Language Class Initialized
INFO - 2018-05-11 23:06:48 --> Security Class Initialized
INFO - 2018-05-11 23:06:48 --> Security Class Initialized
DEBUG - 2018-05-11 23:06:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 23:06:48 --> Language Class Initialized
ERROR - 2018-05-11 23:06:48 --> 404 Page Not Found: /index
INFO - 2018-05-11 23:06:48 --> Input Class Initialized
DEBUG - 2018-05-11 23:06:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-11 23:06:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-05-11 23:06:48 --> 404 Page Not Found: /index
INFO - 2018-05-11 23:06:48 --> Input Class Initialized
INFO - 2018-05-11 23:06:48 --> Input Class Initialized
INFO - 2018-05-11 23:06:48 --> Config Class Initialized
INFO - 2018-05-11 23:06:48 --> Hooks Class Initialized
INFO - 2018-05-11 23:06:48 --> Language Class Initialized
INFO - 2018-05-11 23:06:48 --> Language Class Initialized
INFO - 2018-05-11 23:06:48 --> Language Class Initialized
INFO - 2018-05-11 23:06:48 --> Config Class Initialized
INFO - 2018-05-11 23:06:48 --> Hooks Class Initialized
DEBUG - 2018-05-11 23:06:48 --> UTF-8 Support Enabled
ERROR - 2018-05-11 23:06:48 --> 404 Page Not Found: /index
ERROR - 2018-05-11 23:06:48 --> 404 Page Not Found: /index
ERROR - 2018-05-11 23:06:48 --> 404 Page Not Found: /index
DEBUG - 2018-05-11 23:06:48 --> UTF-8 Support Enabled
INFO - 2018-05-11 23:06:48 --> Config Class Initialized
INFO - 2018-05-11 23:06:48 --> Hooks Class Initialized
INFO - 2018-05-11 23:06:48 --> Utf8 Class Initialized
INFO - 2018-05-11 23:06:48 --> URI Class Initialized
DEBUG - 2018-05-11 23:06:48 --> UTF-8 Support Enabled
INFO - 2018-05-11 23:06:48 --> Utf8 Class Initialized
INFO - 2018-05-11 23:06:48 --> Config Class Initialized
INFO - 2018-05-11 23:06:48 --> Hooks Class Initialized
INFO - 2018-05-11 23:06:48 --> Router Class Initialized
INFO - 2018-05-11 23:06:48 --> URI Class Initialized
INFO - 2018-05-11 23:06:48 --> Utf8 Class Initialized
INFO - 2018-05-11 23:06:48 --> URI Class Initialized
DEBUG - 2018-05-11 23:06:48 --> UTF-8 Support Enabled
INFO - 2018-05-11 23:06:48 --> Router Class Initialized
INFO - 2018-05-11 23:06:48 --> Output Class Initialized
INFO - 2018-05-11 23:06:48 --> Router Class Initialized
INFO - 2018-05-11 23:06:48 --> Security Class Initialized
INFO - 2018-05-11 23:06:48 --> Utf8 Class Initialized
INFO - 2018-05-11 23:06:48 --> Output Class Initialized
INFO - 2018-05-11 23:06:48 --> Security Class Initialized
INFO - 2018-05-11 23:06:48 --> URI Class Initialized
INFO - 2018-05-11 23:06:48 --> Output Class Initialized
DEBUG - 2018-05-11 23:06:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 23:06:48 --> Security Class Initialized
INFO - 2018-05-11 23:06:48 --> Router Class Initialized
DEBUG - 2018-05-11 23:06:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 23:06:48 --> Input Class Initialized
DEBUG - 2018-05-11 23:06:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 23:06:48 --> Output Class Initialized
INFO - 2018-05-11 23:06:48 --> Security Class Initialized
INFO - 2018-05-11 23:06:48 --> Input Class Initialized
INFO - 2018-05-11 23:06:48 --> Input Class Initialized
INFO - 2018-05-11 23:06:48 --> Language Class Initialized
INFO - 2018-05-11 23:06:48 --> Language Class Initialized
DEBUG - 2018-05-11 23:06:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-05-11 23:06:48 --> 404 Page Not Found: /index
INFO - 2018-05-11 23:06:48 --> Language Class Initialized
ERROR - 2018-05-11 23:06:48 --> 404 Page Not Found: /index
INFO - 2018-05-11 23:06:48 --> Input Class Initialized
ERROR - 2018-05-11 23:06:48 --> 404 Page Not Found: /index
INFO - 2018-05-11 23:06:48 --> Config Class Initialized
INFO - 2018-05-11 23:06:48 --> Language Class Initialized
INFO - 2018-05-11 23:06:48 --> Hooks Class Initialized
INFO - 2018-05-11 23:06:48 --> Config Class Initialized
INFO - 2018-05-11 23:06:48 --> Hooks Class Initialized
ERROR - 2018-05-11 23:06:48 --> 404 Page Not Found: /index
DEBUG - 2018-05-11 23:06:48 --> UTF-8 Support Enabled
INFO - 2018-05-11 23:06:48 --> Config Class Initialized
INFO - 2018-05-11 23:06:48 --> Hooks Class Initialized
DEBUG - 2018-05-11 23:06:48 --> UTF-8 Support Enabled
INFO - 2018-05-11 23:06:49 --> Utf8 Class Initialized
DEBUG - 2018-05-11 23:06:49 --> UTF-8 Support Enabled
INFO - 2018-05-11 23:06:49 --> Config Class Initialized
INFO - 2018-05-11 23:06:49 --> URI Class Initialized
INFO - 2018-05-11 23:06:49 --> Utf8 Class Initialized
INFO - 2018-05-11 23:06:49 --> Hooks Class Initialized
INFO - 2018-05-11 23:06:49 --> Utf8 Class Initialized
INFO - 2018-05-11 23:06:49 --> URI Class Initialized
INFO - 2018-05-11 23:06:49 --> Router Class Initialized
DEBUG - 2018-05-11 23:06:49 --> UTF-8 Support Enabled
INFO - 2018-05-11 23:06:49 --> Utf8 Class Initialized
INFO - 2018-05-11 23:06:49 --> URI Class Initialized
INFO - 2018-05-11 23:06:49 --> Output Class Initialized
INFO - 2018-05-11 23:06:49 --> URI Class Initialized
INFO - 2018-05-11 23:06:49 --> Router Class Initialized
INFO - 2018-05-11 23:06:49 --> Router Class Initialized
INFO - 2018-05-11 23:06:49 --> Security Class Initialized
DEBUG - 2018-05-11 23:06:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 23:06:49 --> Input Class Initialized
INFO - 2018-05-11 23:06:49 --> Language Class Initialized
ERROR - 2018-05-11 23:06:49 --> 404 Page Not Found: /index
INFO - 2018-05-11 23:06:49 --> Output Class Initialized
INFO - 2018-05-11 23:06:49 --> Router Class Initialized
INFO - 2018-05-11 23:06:49 --> Output Class Initialized
INFO - 2018-05-11 23:06:49 --> Security Class Initialized
INFO - 2018-05-11 23:06:49 --> Security Class Initialized
DEBUG - 2018-05-11 23:06:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 23:06:49 --> Output Class Initialized
INFO - 2018-05-11 23:06:49 --> Input Class Initialized
INFO - 2018-05-11 23:06:49 --> Security Class Initialized
DEBUG - 2018-05-11 23:06:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 23:06:49 --> Input Class Initialized
DEBUG - 2018-05-11 23:06:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 23:06:49 --> Language Class Initialized
INFO - 2018-05-11 23:06:49 --> Input Class Initialized
ERROR - 2018-05-11 23:06:49 --> 404 Page Not Found: /index
INFO - 2018-05-11 23:06:49 --> Language Class Initialized
INFO - 2018-05-11 23:06:49 --> Language Class Initialized
ERROR - 2018-05-11 23:06:49 --> 404 Page Not Found: /index
ERROR - 2018-05-11 23:06:49 --> 404 Page Not Found: /index
INFO - 2018-05-11 23:09:23 --> Config Class Initialized
INFO - 2018-05-11 23:09:23 --> Config Class Initialized
INFO - 2018-05-11 23:09:23 --> Config Class Initialized
INFO - 2018-05-11 23:09:23 --> Config Class Initialized
INFO - 2018-05-11 23:09:23 --> Config Class Initialized
INFO - 2018-05-11 23:09:23 --> Hooks Class Initialized
INFO - 2018-05-11 23:09:23 --> Hooks Class Initialized
INFO - 2018-05-11 23:09:23 --> Hooks Class Initialized
DEBUG - 2018-05-11 23:09:23 --> UTF-8 Support Enabled
INFO - 2018-05-11 23:09:23 --> Hooks Class Initialized
INFO - 2018-05-11 23:09:23 --> Hooks Class Initialized
INFO - 2018-05-11 23:09:23 --> Utf8 Class Initialized
DEBUG - 2018-05-11 23:09:23 --> UTF-8 Support Enabled
DEBUG - 2018-05-11 23:09:23 --> UTF-8 Support Enabled
DEBUG - 2018-05-11 23:09:23 --> UTF-8 Support Enabled
DEBUG - 2018-05-11 23:09:23 --> UTF-8 Support Enabled
INFO - 2018-05-11 23:09:23 --> Utf8 Class Initialized
INFO - 2018-05-11 23:09:23 --> Utf8 Class Initialized
INFO - 2018-05-11 23:09:23 --> Utf8 Class Initialized
INFO - 2018-05-11 23:09:23 --> Utf8 Class Initialized
INFO - 2018-05-11 23:09:23 --> URI Class Initialized
INFO - 2018-05-11 23:09:23 --> URI Class Initialized
INFO - 2018-05-11 23:09:23 --> URI Class Initialized
INFO - 2018-05-11 23:09:23 --> URI Class Initialized
INFO - 2018-05-11 23:09:23 --> Router Class Initialized
INFO - 2018-05-11 23:09:23 --> URI Class Initialized
INFO - 2018-05-11 23:09:23 --> Router Class Initialized
INFO - 2018-05-11 23:09:23 --> Router Class Initialized
INFO - 2018-05-11 23:09:23 --> Output Class Initialized
INFO - 2018-05-11 23:09:23 --> Output Class Initialized
INFO - 2018-05-11 23:09:23 --> Router Class Initialized
INFO - 2018-05-11 23:09:23 --> Output Class Initialized
INFO - 2018-05-11 23:09:23 --> Router Class Initialized
INFO - 2018-05-11 23:09:23 --> Security Class Initialized
INFO - 2018-05-11 23:09:23 --> Security Class Initialized
INFO - 2018-05-11 23:09:23 --> Output Class Initialized
DEBUG - 2018-05-11 23:09:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 23:09:23 --> Security Class Initialized
INFO - 2018-05-11 23:09:23 --> Output Class Initialized
DEBUG - 2018-05-11 23:09:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 23:09:23 --> Security Class Initialized
INFO - 2018-05-11 23:09:23 --> Input Class Initialized
DEBUG - 2018-05-11 23:09:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 23:09:23 --> Security Class Initialized
DEBUG - 2018-05-11 23:09:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 23:09:23 --> Input Class Initialized
INFO - 2018-05-11 23:09:23 --> Language Class Initialized
DEBUG - 2018-05-11 23:09:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 23:09:23 --> Input Class Initialized
INFO - 2018-05-11 23:09:23 --> Input Class Initialized
INFO - 2018-05-11 23:09:23 --> Input Class Initialized
INFO - 2018-05-11 23:09:23 --> Language Class Initialized
ERROR - 2018-05-11 23:09:23 --> 404 Page Not Found: /index
INFO - 2018-05-11 23:09:23 --> Language Class Initialized
INFO - 2018-05-11 23:09:23 --> Language Class Initialized
ERROR - 2018-05-11 23:09:23 --> 404 Page Not Found: /index
ERROR - 2018-05-11 23:09:23 --> 404 Page Not Found: /index
ERROR - 2018-05-11 23:09:23 --> 404 Page Not Found: /index
INFO - 2018-05-11 23:09:23 --> Language Class Initialized
INFO - 2018-05-11 23:09:23 --> Config Class Initialized
INFO - 2018-05-11 23:09:23 --> Hooks Class Initialized
INFO - 2018-05-11 23:09:23 --> Config Class Initialized
INFO - 2018-05-11 23:09:23 --> Hooks Class Initialized
DEBUG - 2018-05-11 23:09:23 --> UTF-8 Support Enabled
ERROR - 2018-05-11 23:09:23 --> 404 Page Not Found: /index
DEBUG - 2018-05-11 23:09:23 --> UTF-8 Support Enabled
INFO - 2018-05-11 23:09:23 --> Config Class Initialized
INFO - 2018-05-11 23:09:23 --> Hooks Class Initialized
INFO - 2018-05-11 23:09:23 --> Utf8 Class Initialized
INFO - 2018-05-11 23:09:23 --> Utf8 Class Initialized
INFO - 2018-05-11 23:09:23 --> Config Class Initialized
INFO - 2018-05-11 23:09:23 --> Hooks Class Initialized
DEBUG - 2018-05-11 23:09:23 --> UTF-8 Support Enabled
INFO - 2018-05-11 23:09:23 --> URI Class Initialized
INFO - 2018-05-11 23:09:23 --> URI Class Initialized
DEBUG - 2018-05-11 23:09:23 --> UTF-8 Support Enabled
INFO - 2018-05-11 23:09:24 --> Router Class Initialized
INFO - 2018-05-11 23:09:24 --> Utf8 Class Initialized
INFO - 2018-05-11 23:09:24 --> Router Class Initialized
INFO - 2018-05-11 23:09:24 --> Utf8 Class Initialized
INFO - 2018-05-11 23:09:24 --> Output Class Initialized
INFO - 2018-05-11 23:09:24 --> URI Class Initialized
INFO - 2018-05-11 23:09:24 --> Output Class Initialized
INFO - 2018-05-11 23:09:24 --> URI Class Initialized
INFO - 2018-05-11 23:09:24 --> Security Class Initialized
DEBUG - 2018-05-11 23:09:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 23:09:24 --> Router Class Initialized
INFO - 2018-05-11 23:09:24 --> Router Class Initialized
INFO - 2018-05-11 23:09:24 --> Security Class Initialized
INFO - 2018-05-11 23:09:24 --> Output Class Initialized
DEBUG - 2018-05-11 23:09:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 23:09:24 --> Output Class Initialized
INFO - 2018-05-11 23:09:24 --> Input Class Initialized
INFO - 2018-05-11 23:09:24 --> Security Class Initialized
INFO - 2018-05-11 23:09:24 --> Language Class Initialized
INFO - 2018-05-11 23:09:24 --> Input Class Initialized
INFO - 2018-05-11 23:09:24 --> Security Class Initialized
DEBUG - 2018-05-11 23:09:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-05-11 23:09:24 --> 404 Page Not Found: /index
INFO - 2018-05-11 23:09:24 --> Config Class Initialized
INFO - 2018-05-11 23:09:24 --> Language Class Initialized
DEBUG - 2018-05-11 23:09:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 23:09:24 --> Input Class Initialized
INFO - 2018-05-11 23:09:24 --> Hooks Class Initialized
DEBUG - 2018-05-11 23:09:24 --> UTF-8 Support Enabled
ERROR - 2018-05-11 23:09:24 --> 404 Page Not Found: /index
INFO - 2018-05-11 23:09:24 --> Input Class Initialized
INFO - 2018-05-11 23:09:24 --> Language Class Initialized
INFO - 2018-05-11 23:09:24 --> Utf8 Class Initialized
INFO - 2018-05-11 23:09:24 --> Config Class Initialized
ERROR - 2018-05-11 23:09:24 --> 404 Page Not Found: /index
INFO - 2018-05-11 23:09:24 --> Language Class Initialized
INFO - 2018-05-11 23:09:24 --> Hooks Class Initialized
INFO - 2018-05-11 23:09:24 --> URI Class Initialized
ERROR - 2018-05-11 23:09:24 --> 404 Page Not Found: /index
INFO - 2018-05-11 23:09:24 --> Config Class Initialized
INFO - 2018-05-11 23:09:24 --> Hooks Class Initialized
DEBUG - 2018-05-11 23:09:24 --> UTF-8 Support Enabled
INFO - 2018-05-11 23:09:24 --> Utf8 Class Initialized
DEBUG - 2018-05-11 23:09:24 --> UTF-8 Support Enabled
INFO - 2018-05-11 23:09:24 --> URI Class Initialized
INFO - 2018-05-11 23:09:24 --> Utf8 Class Initialized
INFO - 2018-05-11 23:09:24 --> Config Class Initialized
INFO - 2018-05-11 23:09:24 --> Router Class Initialized
INFO - 2018-05-11 23:09:24 --> Router Class Initialized
INFO - 2018-05-11 23:09:24 --> Hooks Class Initialized
INFO - 2018-05-11 23:09:24 --> URI Class Initialized
DEBUG - 2018-05-11 23:09:24 --> UTF-8 Support Enabled
INFO - 2018-05-11 23:09:24 --> Router Class Initialized
INFO - 2018-05-11 23:09:24 --> Output Class Initialized
INFO - 2018-05-11 23:09:24 --> Output Class Initialized
INFO - 2018-05-11 23:09:24 --> Utf8 Class Initialized
INFO - 2018-05-11 23:09:24 --> URI Class Initialized
INFO - 2018-05-11 23:09:24 --> Router Class Initialized
INFO - 2018-05-11 23:09:24 --> Output Class Initialized
INFO - 2018-05-11 23:09:24 --> Security Class Initialized
DEBUG - 2018-05-11 23:09:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 23:09:24 --> Input Class Initialized
INFO - 2018-05-11 23:09:24 --> Language Class Initialized
ERROR - 2018-05-11 23:09:24 --> 404 Page Not Found: /index
INFO - 2018-05-11 23:09:24 --> Security Class Initialized
INFO - 2018-05-11 23:09:24 --> Output Class Initialized
INFO - 2018-05-11 23:09:24 --> Security Class Initialized
DEBUG - 2018-05-11 23:09:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 23:09:24 --> Security Class Initialized
INFO - 2018-05-11 23:09:24 --> Input Class Initialized
DEBUG - 2018-05-11 23:09:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-11 23:09:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 23:09:24 --> Language Class Initialized
INFO - 2018-05-11 23:09:24 --> Input Class Initialized
INFO - 2018-05-11 23:09:24 --> Input Class Initialized
INFO - 2018-05-11 23:09:24 --> Language Class Initialized
ERROR - 2018-05-11 23:09:24 --> 404 Page Not Found: /index
INFO - 2018-05-11 23:09:24 --> Language Class Initialized
ERROR - 2018-05-11 23:09:24 --> 404 Page Not Found: /index
ERROR - 2018-05-11 23:09:24 --> 404 Page Not Found: /index
INFO - 2018-05-11 23:09:27 --> Config Class Initialized
INFO - 2018-05-11 23:09:27 --> Config Class Initialized
INFO - 2018-05-11 23:09:27 --> Config Class Initialized
INFO - 2018-05-11 23:09:27 --> Config Class Initialized
INFO - 2018-05-11 23:09:27 --> Config Class Initialized
INFO - 2018-05-11 23:09:28 --> Hooks Class Initialized
INFO - 2018-05-11 23:09:28 --> Hooks Class Initialized
INFO - 2018-05-11 23:09:28 --> Hooks Class Initialized
INFO - 2018-05-11 23:09:28 --> Hooks Class Initialized
INFO - 2018-05-11 23:09:28 --> Hooks Class Initialized
DEBUG - 2018-05-11 23:09:28 --> UTF-8 Support Enabled
INFO - 2018-05-11 23:09:28 --> Utf8 Class Initialized
DEBUG - 2018-05-11 23:09:28 --> UTF-8 Support Enabled
DEBUG - 2018-05-11 23:09:28 --> UTF-8 Support Enabled
INFO - 2018-05-11 23:09:28 --> URI Class Initialized
DEBUG - 2018-05-11 23:09:28 --> UTF-8 Support Enabled
DEBUG - 2018-05-11 23:09:28 --> UTF-8 Support Enabled
INFO - 2018-05-11 23:09:28 --> Utf8 Class Initialized
INFO - 2018-05-11 23:09:28 --> Utf8 Class Initialized
INFO - 2018-05-11 23:09:28 --> Utf8 Class Initialized
INFO - 2018-05-11 23:09:28 --> Utf8 Class Initialized
INFO - 2018-05-11 23:09:28 --> Router Class Initialized
INFO - 2018-05-11 23:09:28 --> URI Class Initialized
INFO - 2018-05-11 23:09:28 --> URI Class Initialized
INFO - 2018-05-11 23:09:28 --> URI Class Initialized
INFO - 2018-05-11 23:09:28 --> Output Class Initialized
INFO - 2018-05-11 23:09:28 --> URI Class Initialized
INFO - 2018-05-11 23:09:28 --> Router Class Initialized
INFO - 2018-05-11 23:09:28 --> Security Class Initialized
INFO - 2018-05-11 23:09:28 --> Router Class Initialized
INFO - 2018-05-11 23:09:28 --> Router Class Initialized
INFO - 2018-05-11 23:09:28 --> Router Class Initialized
INFO - 2018-05-11 23:09:28 --> Output Class Initialized
DEBUG - 2018-05-11 23:09:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 23:09:28 --> Input Class Initialized
INFO - 2018-05-11 23:09:28 --> Language Class Initialized
ERROR - 2018-05-11 23:09:28 --> 404 Page Not Found: /index
INFO - 2018-05-11 23:09:28 --> Security Class Initialized
DEBUG - 2018-05-11 23:09:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 23:09:28 --> Input Class Initialized
INFO - 2018-05-11 23:09:28 --> Language Class Initialized
ERROR - 2018-05-11 23:09:28 --> 404 Page Not Found: /index
INFO - 2018-05-11 23:09:28 --> Config Class Initialized
INFO - 2018-05-11 23:09:28 --> Output Class Initialized
INFO - 2018-05-11 23:09:28 --> Output Class Initialized
INFO - 2018-05-11 23:09:28 --> Output Class Initialized
INFO - 2018-05-11 23:09:28 --> Security Class Initialized
INFO - 2018-05-11 23:09:28 --> Security Class Initialized
INFO - 2018-05-11 23:09:28 --> Hooks Class Initialized
INFO - 2018-05-11 23:09:28 --> Security Class Initialized
DEBUG - 2018-05-11 23:09:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 23:09:28 --> Input Class Initialized
INFO - 2018-05-11 23:09:28 --> Language Class Initialized
ERROR - 2018-05-11 23:09:28 --> 404 Page Not Found: /index
DEBUG - 2018-05-11 23:09:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-11 23:09:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-11 23:09:28 --> UTF-8 Support Enabled
INFO - 2018-05-11 23:09:28 --> Config Class Initialized
INFO - 2018-05-11 23:09:28 --> Hooks Class Initialized
INFO - 2018-05-11 23:09:28 --> Input Class Initialized
INFO - 2018-05-11 23:09:28 --> Utf8 Class Initialized
INFO - 2018-05-11 23:09:28 --> Input Class Initialized
INFO - 2018-05-11 23:09:28 --> Language Class Initialized
DEBUG - 2018-05-11 23:09:28 --> UTF-8 Support Enabled
INFO - 2018-05-11 23:09:28 --> URI Class Initialized
INFO - 2018-05-11 23:09:28 --> Language Class Initialized
INFO - 2018-05-11 23:09:28 --> Utf8 Class Initialized
ERROR - 2018-05-11 23:09:28 --> 404 Page Not Found: /index
INFO - 2018-05-11 23:09:28 --> Router Class Initialized
ERROR - 2018-05-11 23:09:28 --> 404 Page Not Found: /index
INFO - 2018-05-11 23:09:28 --> URI Class Initialized
INFO - 2018-05-11 23:09:28 --> Router Class Initialized
INFO - 2018-05-11 23:09:28 --> Config Class Initialized
INFO - 2018-05-11 23:09:28 --> Hooks Class Initialized
INFO - 2018-05-11 23:09:28 --> Output Class Initialized
INFO - 2018-05-11 23:09:28 --> Output Class Initialized
INFO - 2018-05-11 23:09:28 --> Security Class Initialized
INFO - 2018-05-11 23:09:28 --> Config Class Initialized
INFO - 2018-05-11 23:09:28 --> Security Class Initialized
DEBUG - 2018-05-11 23:09:28 --> UTF-8 Support Enabled
INFO - 2018-05-11 23:09:28 --> Hooks Class Initialized
DEBUG - 2018-05-11 23:09:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 23:09:28 --> Utf8 Class Initialized
DEBUG - 2018-05-11 23:09:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 23:09:29 --> Input Class Initialized
DEBUG - 2018-05-11 23:09:29 --> UTF-8 Support Enabled
INFO - 2018-05-11 23:09:29 --> URI Class Initialized
INFO - 2018-05-11 23:09:29 --> Input Class Initialized
INFO - 2018-05-11 23:09:29 --> Language Class Initialized
INFO - 2018-05-11 23:09:29 --> Utf8 Class Initialized
INFO - 2018-05-11 23:09:29 --> Language Class Initialized
INFO - 2018-05-11 23:09:29 --> Router Class Initialized
ERROR - 2018-05-11 23:09:29 --> 404 Page Not Found: /index
INFO - 2018-05-11 23:09:29 --> Output Class Initialized
ERROR - 2018-05-11 23:09:29 --> 404 Page Not Found: /index
INFO - 2018-05-11 23:09:29 --> URI Class Initialized
INFO - 2018-05-11 23:09:29 --> Security Class Initialized
INFO - 2018-05-11 23:09:29 --> Config Class Initialized
INFO - 2018-05-11 23:09:29 --> Router Class Initialized
INFO - 2018-05-11 23:09:29 --> Hooks Class Initialized
DEBUG - 2018-05-11 23:09:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 23:09:29 --> Config Class Initialized
INFO - 2018-05-11 23:09:29 --> Hooks Class Initialized
INFO - 2018-05-11 23:09:29 --> Output Class Initialized
INFO - 2018-05-11 23:09:29 --> Input Class Initialized
DEBUG - 2018-05-11 23:09:29 --> UTF-8 Support Enabled
INFO - 2018-05-11 23:09:29 --> Utf8 Class Initialized
DEBUG - 2018-05-11 23:09:29 --> UTF-8 Support Enabled
INFO - 2018-05-11 23:09:29 --> Language Class Initialized
INFO - 2018-05-11 23:09:29 --> Security Class Initialized
INFO - 2018-05-11 23:09:29 --> Utf8 Class Initialized
ERROR - 2018-05-11 23:09:29 --> 404 Page Not Found: /index
DEBUG - 2018-05-11 23:09:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 23:09:29 --> URI Class Initialized
INFO - 2018-05-11 23:09:29 --> URI Class Initialized
INFO - 2018-05-11 23:09:29 --> Router Class Initialized
INFO - 2018-05-11 23:09:29 --> Config Class Initialized
INFO - 2018-05-11 23:09:29 --> Hooks Class Initialized
INFO - 2018-05-11 23:09:29 --> Output Class Initialized
INFO - 2018-05-11 23:09:29 --> Security Class Initialized
DEBUG - 2018-05-11 23:09:29 --> UTF-8 Support Enabled
INFO - 2018-05-11 23:09:29 --> Utf8 Class Initialized
DEBUG - 2018-05-11 23:09:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 23:09:29 --> Input Class Initialized
INFO - 2018-05-11 23:09:29 --> Router Class Initialized
INFO - 2018-05-11 23:09:29 --> URI Class Initialized
INFO - 2018-05-11 23:09:29 --> Input Class Initialized
INFO - 2018-05-11 23:09:29 --> Router Class Initialized
INFO - 2018-05-11 23:09:29 --> Output Class Initialized
INFO - 2018-05-11 23:09:29 --> Language Class Initialized
INFO - 2018-05-11 23:09:29 --> Output Class Initialized
INFO - 2018-05-11 23:09:29 --> Language Class Initialized
INFO - 2018-05-11 23:09:29 --> Security Class Initialized
INFO - 2018-05-11 23:09:29 --> Security Class Initialized
DEBUG - 2018-05-11 23:09:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-05-11 23:09:29 --> 404 Page Not Found: /index
ERROR - 2018-05-11 23:09:29 --> 404 Page Not Found: /index
DEBUG - 2018-05-11 23:09:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 23:09:29 --> Input Class Initialized
INFO - 2018-05-11 23:09:29 --> Language Class Initialized
ERROR - 2018-05-11 23:09:29 --> 404 Page Not Found: /index
INFO - 2018-05-11 23:09:29 --> Input Class Initialized
INFO - 2018-05-11 23:09:29 --> Config Class Initialized
INFO - 2018-05-11 23:09:29 --> Hooks Class Initialized
INFO - 2018-05-11 23:09:29 --> Language Class Initialized
DEBUG - 2018-05-11 23:09:29 --> UTF-8 Support Enabled
INFO - 2018-05-11 23:09:29 --> Utf8 Class Initialized
INFO - 2018-05-11 23:09:29 --> URI Class Initialized
ERROR - 2018-05-11 23:09:29 --> 404 Page Not Found: /index
INFO - 2018-05-11 23:09:29 --> Router Class Initialized
INFO - 2018-05-11 23:09:29 --> Output Class Initialized
INFO - 2018-05-11 23:09:29 --> Security Class Initialized
DEBUG - 2018-05-11 23:09:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 23:09:29 --> Input Class Initialized
INFO - 2018-05-11 23:09:29 --> Language Class Initialized
ERROR - 2018-05-11 23:09:29 --> 404 Page Not Found: /index
INFO - 2018-05-11 23:10:45 --> Config Class Initialized
INFO - 2018-05-11 23:10:45 --> Hooks Class Initialized
DEBUG - 2018-05-11 23:10:45 --> UTF-8 Support Enabled
INFO - 2018-05-11 23:10:45 --> Utf8 Class Initialized
INFO - 2018-05-11 23:10:45 --> URI Class Initialized
INFO - 2018-05-11 23:10:45 --> Router Class Initialized
INFO - 2018-05-11 23:10:45 --> Output Class Initialized
INFO - 2018-05-11 23:10:45 --> Security Class Initialized
DEBUG - 2018-05-11 23:10:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 23:10:45 --> Input Class Initialized
INFO - 2018-05-11 23:10:45 --> Language Class Initialized
INFO - 2018-05-11 23:10:45 --> Language Class Initialized
INFO - 2018-05-11 23:10:45 --> Config Class Initialized
INFO - 2018-05-11 23:10:45 --> Loader Class Initialized
DEBUG - 2018-05-11 23:10:45 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-11 23:10:45 --> Helper loaded: url_helper
INFO - 2018-05-11 23:10:45 --> Helper loaded: form_helper
INFO - 2018-05-11 23:10:45 --> Helper loaded: date_helper
INFO - 2018-05-11 23:10:45 --> Helper loaded: util_helper
INFO - 2018-05-11 23:10:45 --> Helper loaded: text_helper
INFO - 2018-05-11 23:10:45 --> Helper loaded: string_helper
INFO - 2018-05-11 23:10:45 --> Database Driver Class Initialized
DEBUG - 2018-05-11 23:10:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-11 23:10:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-11 23:10:45 --> Email Class Initialized
INFO - 2018-05-11 23:10:45 --> Controller Class Initialized
DEBUG - 2018-05-11 23:10:45 --> Programs MX_Controller Initialized
INFO - 2018-05-11 23:10:45 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-11 23:10:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-05-11 23:10:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-11 23:10:45 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-11 23:10:45 --> Login MX_Controller Initialized
DEBUG - 2018-05-11 23:10:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-11 23:10:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-05-11 23:10:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-05-11 23:10:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-05-11 23:10:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-05-11 23:10:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-05-11 23:10:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/programs/create_program.php
INFO - 2018-05-11 23:10:45 --> Final output sent to browser
DEBUG - 2018-05-11 23:10:45 --> Total execution time: 0.7715
INFO - 2018-05-11 23:10:46 --> Config Class Initialized
INFO - 2018-05-11 23:10:46 --> Hooks Class Initialized
DEBUG - 2018-05-11 23:10:46 --> UTF-8 Support Enabled
INFO - 2018-05-11 23:10:46 --> Utf8 Class Initialized
INFO - 2018-05-11 23:10:46 --> URI Class Initialized
INFO - 2018-05-11 23:10:46 --> Router Class Initialized
INFO - 2018-05-11 23:10:46 --> Output Class Initialized
INFO - 2018-05-11 23:10:46 --> Security Class Initialized
DEBUG - 2018-05-11 23:10:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 23:10:47 --> Input Class Initialized
INFO - 2018-05-11 23:10:47 --> Language Class Initialized
ERROR - 2018-05-11 23:10:47 --> 404 Page Not Found: /index
INFO - 2018-05-11 23:11:59 --> Config Class Initialized
INFO - 2018-05-11 23:11:59 --> Hooks Class Initialized
DEBUG - 2018-05-11 23:11:59 --> UTF-8 Support Enabled
INFO - 2018-05-11 23:11:59 --> Utf8 Class Initialized
INFO - 2018-05-11 23:11:59 --> URI Class Initialized
INFO - 2018-05-11 23:11:59 --> Router Class Initialized
INFO - 2018-05-11 23:11:59 --> Output Class Initialized
INFO - 2018-05-11 23:11:59 --> Security Class Initialized
DEBUG - 2018-05-11 23:11:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 23:11:59 --> Input Class Initialized
INFO - 2018-05-11 23:11:59 --> Language Class Initialized
INFO - 2018-05-11 23:11:59 --> Language Class Initialized
INFO - 2018-05-11 23:11:59 --> Config Class Initialized
INFO - 2018-05-11 23:11:59 --> Loader Class Initialized
DEBUG - 2018-05-11 23:11:59 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-11 23:11:59 --> Helper loaded: url_helper
INFO - 2018-05-11 23:11:59 --> Helper loaded: form_helper
INFO - 2018-05-11 23:11:59 --> Helper loaded: date_helper
INFO - 2018-05-11 23:11:59 --> Helper loaded: util_helper
INFO - 2018-05-11 23:11:59 --> Helper loaded: text_helper
INFO - 2018-05-11 23:11:59 --> Helper loaded: string_helper
INFO - 2018-05-11 23:11:59 --> Database Driver Class Initialized
DEBUG - 2018-05-11 23:11:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-11 23:11:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-11 23:11:59 --> Email Class Initialized
INFO - 2018-05-11 23:11:59 --> Controller Class Initialized
DEBUG - 2018-05-11 23:11:59 --> Programs MX_Controller Initialized
INFO - 2018-05-11 23:11:59 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-11 23:11:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-05-11 23:11:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-11 23:11:59 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-11 23:11:59 --> Login MX_Controller Initialized
DEBUG - 2018-05-11 23:11:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-11 23:11:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-05-11 23:11:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-05-11 23:11:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-05-11 23:11:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-05-11 23:11:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-05-11 23:12:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/programs/create_program.php
INFO - 2018-05-11 23:12:00 --> Final output sent to browser
DEBUG - 2018-05-11 23:12:00 --> Total execution time: 0.7611
INFO - 2018-05-11 23:12:00 --> Config Class Initialized
INFO - 2018-05-11 23:12:01 --> Hooks Class Initialized
DEBUG - 2018-05-11 23:12:01 --> UTF-8 Support Enabled
INFO - 2018-05-11 23:12:01 --> Utf8 Class Initialized
INFO - 2018-05-11 23:12:01 --> URI Class Initialized
INFO - 2018-05-11 23:12:01 --> Router Class Initialized
INFO - 2018-05-11 23:12:01 --> Output Class Initialized
INFO - 2018-05-11 23:12:01 --> Security Class Initialized
DEBUG - 2018-05-11 23:12:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 23:12:01 --> Input Class Initialized
INFO - 2018-05-11 23:12:01 --> Language Class Initialized
ERROR - 2018-05-11 23:12:01 --> 404 Page Not Found: /index
INFO - 2018-05-11 23:12:07 --> Config Class Initialized
INFO - 2018-05-11 23:12:07 --> Hooks Class Initialized
DEBUG - 2018-05-11 23:12:07 --> UTF-8 Support Enabled
INFO - 2018-05-11 23:12:07 --> Utf8 Class Initialized
INFO - 2018-05-11 23:12:07 --> URI Class Initialized
INFO - 2018-05-11 23:12:07 --> Router Class Initialized
INFO - 2018-05-11 23:12:07 --> Output Class Initialized
INFO - 2018-05-11 23:12:07 --> Security Class Initialized
DEBUG - 2018-05-11 23:12:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 23:12:07 --> Input Class Initialized
INFO - 2018-05-11 23:12:07 --> Language Class Initialized
INFO - 2018-05-11 23:12:07 --> Language Class Initialized
INFO - 2018-05-11 23:12:07 --> Config Class Initialized
INFO - 2018-05-11 23:12:08 --> Loader Class Initialized
DEBUG - 2018-05-11 23:12:08 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-11 23:12:08 --> Helper loaded: url_helper
INFO - 2018-05-11 23:12:08 --> Helper loaded: form_helper
INFO - 2018-05-11 23:12:08 --> Helper loaded: date_helper
INFO - 2018-05-11 23:12:08 --> Helper loaded: util_helper
INFO - 2018-05-11 23:12:08 --> Helper loaded: text_helper
INFO - 2018-05-11 23:12:08 --> Helper loaded: string_helper
INFO - 2018-05-11 23:12:08 --> Database Driver Class Initialized
DEBUG - 2018-05-11 23:12:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-11 23:12:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-11 23:12:08 --> Email Class Initialized
INFO - 2018-05-11 23:12:08 --> Controller Class Initialized
DEBUG - 2018-05-11 23:12:08 --> Programs MX_Controller Initialized
INFO - 2018-05-11 23:12:08 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-11 23:12:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-05-11 23:12:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-11 23:12:08 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-11 23:12:08 --> Login MX_Controller Initialized
DEBUG - 2018-05-11 23:12:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-11 23:12:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-05-11 23:12:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-05-11 23:12:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-05-11 23:12:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-05-11 23:12:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-05-11 23:12:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/programs/create_program.php
INFO - 2018-05-11 23:12:08 --> Final output sent to browser
DEBUG - 2018-05-11 23:12:08 --> Total execution time: 0.7653
INFO - 2018-05-11 23:12:09 --> Config Class Initialized
INFO - 2018-05-11 23:12:09 --> Hooks Class Initialized
DEBUG - 2018-05-11 23:12:09 --> UTF-8 Support Enabled
INFO - 2018-05-11 23:12:09 --> Utf8 Class Initialized
INFO - 2018-05-11 23:12:09 --> URI Class Initialized
INFO - 2018-05-11 23:12:09 --> Router Class Initialized
INFO - 2018-05-11 23:12:09 --> Output Class Initialized
INFO - 2018-05-11 23:12:09 --> Security Class Initialized
DEBUG - 2018-05-11 23:12:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 23:12:09 --> Input Class Initialized
INFO - 2018-05-11 23:12:09 --> Language Class Initialized
ERROR - 2018-05-11 23:12:09 --> 404 Page Not Found: /index
INFO - 2018-05-11 23:12:26 --> Config Class Initialized
INFO - 2018-05-11 23:12:26 --> Hooks Class Initialized
DEBUG - 2018-05-11 23:12:26 --> UTF-8 Support Enabled
INFO - 2018-05-11 23:12:26 --> Utf8 Class Initialized
INFO - 2018-05-11 23:12:26 --> URI Class Initialized
INFO - 2018-05-11 23:12:26 --> Router Class Initialized
INFO - 2018-05-11 23:12:27 --> Output Class Initialized
INFO - 2018-05-11 23:12:27 --> Security Class Initialized
DEBUG - 2018-05-11 23:12:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 23:12:27 --> Input Class Initialized
INFO - 2018-05-11 23:12:27 --> Language Class Initialized
ERROR - 2018-05-11 23:12:27 --> 404 Page Not Found: /index
INFO - 2018-05-11 23:12:27 --> Config Class Initialized
INFO - 2018-05-11 23:12:27 --> Config Class Initialized
INFO - 2018-05-11 23:12:27 --> Config Class Initialized
INFO - 2018-05-11 23:12:27 --> Config Class Initialized
INFO - 2018-05-11 23:12:27 --> Config Class Initialized
INFO - 2018-05-11 23:12:27 --> Config Class Initialized
INFO - 2018-05-11 23:12:27 --> Hooks Class Initialized
INFO - 2018-05-11 23:12:27 --> Hooks Class Initialized
INFO - 2018-05-11 23:12:27 --> Hooks Class Initialized
INFO - 2018-05-11 23:12:27 --> Hooks Class Initialized
INFO - 2018-05-11 23:12:27 --> Hooks Class Initialized
INFO - 2018-05-11 23:12:27 --> Hooks Class Initialized
DEBUG - 2018-05-11 23:12:27 --> UTF-8 Support Enabled
DEBUG - 2018-05-11 23:12:27 --> UTF-8 Support Enabled
DEBUG - 2018-05-11 23:12:27 --> UTF-8 Support Enabled
DEBUG - 2018-05-11 23:12:27 --> UTF-8 Support Enabled
DEBUG - 2018-05-11 23:12:27 --> UTF-8 Support Enabled
DEBUG - 2018-05-11 23:12:27 --> UTF-8 Support Enabled
INFO - 2018-05-11 23:12:27 --> Utf8 Class Initialized
INFO - 2018-05-11 23:12:27 --> Utf8 Class Initialized
INFO - 2018-05-11 23:12:27 --> Utf8 Class Initialized
INFO - 2018-05-11 23:12:27 --> Utf8 Class Initialized
INFO - 2018-05-11 23:12:27 --> Utf8 Class Initialized
INFO - 2018-05-11 23:12:27 --> Utf8 Class Initialized
INFO - 2018-05-11 23:12:27 --> URI Class Initialized
INFO - 2018-05-11 23:12:28 --> URI Class Initialized
INFO - 2018-05-11 23:12:28 --> Router Class Initialized
INFO - 2018-05-11 23:12:28 --> URI Class Initialized
INFO - 2018-05-11 23:12:28 --> URI Class Initialized
INFO - 2018-05-11 23:12:28 --> URI Class Initialized
INFO - 2018-05-11 23:12:28 --> Router Class Initialized
INFO - 2018-05-11 23:12:28 --> URI Class Initialized
INFO - 2018-05-11 23:12:28 --> Router Class Initialized
INFO - 2018-05-11 23:12:28 --> Router Class Initialized
INFO - 2018-05-11 23:12:28 --> Router Class Initialized
INFO - 2018-05-11 23:12:28 --> Output Class Initialized
INFO - 2018-05-11 23:12:28 --> Output Class Initialized
INFO - 2018-05-11 23:12:28 --> Router Class Initialized
INFO - 2018-05-11 23:12:28 --> Security Class Initialized
INFO - 2018-05-11 23:12:28 --> Output Class Initialized
INFO - 2018-05-11 23:12:28 --> Output Class Initialized
INFO - 2018-05-11 23:12:28 --> Output Class Initialized
INFO - 2018-05-11 23:12:28 --> Output Class Initialized
INFO - 2018-05-11 23:12:28 --> Security Class Initialized
DEBUG - 2018-05-11 23:12:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 23:12:28 --> Input Class Initialized
INFO - 2018-05-11 23:12:28 --> Language Class Initialized
ERROR - 2018-05-11 23:12:28 --> 404 Page Not Found: /index
INFO - 2018-05-11 23:12:28 --> Security Class Initialized
INFO - 2018-05-11 23:12:28 --> Config Class Initialized
DEBUG - 2018-05-11 23:12:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 23:12:28 --> Security Class Initialized
INFO - 2018-05-11 23:12:28 --> Security Class Initialized
INFO - 2018-05-11 23:12:28 --> Security Class Initialized
INFO - 2018-05-11 23:12:28 --> Hooks Class Initialized
INFO - 2018-05-11 23:12:28 --> Input Class Initialized
DEBUG - 2018-05-11 23:12:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-11 23:12:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-11 23:12:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-11 23:12:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 23:12:28 --> Input Class Initialized
DEBUG - 2018-05-11 23:12:28 --> UTF-8 Support Enabled
INFO - 2018-05-11 23:12:28 --> Input Class Initialized
INFO - 2018-05-11 23:12:28 --> Input Class Initialized
INFO - 2018-05-11 23:12:28 --> Input Class Initialized
INFO - 2018-05-11 23:12:28 --> Language Class Initialized
INFO - 2018-05-11 23:12:28 --> Language Class Initialized
ERROR - 2018-05-11 23:12:28 --> 404 Page Not Found: /index
INFO - 2018-05-11 23:12:28 --> Utf8 Class Initialized
INFO - 2018-05-11 23:12:28 --> Language Class Initialized
INFO - 2018-05-11 23:12:28 --> Language Class Initialized
INFO - 2018-05-11 23:12:28 --> Language Class Initialized
ERROR - 2018-05-11 23:12:28 --> 404 Page Not Found: /index
ERROR - 2018-05-11 23:12:28 --> 404 Page Not Found: /index
INFO - 2018-05-11 23:12:28 --> URI Class Initialized
ERROR - 2018-05-11 23:12:28 --> 404 Page Not Found: /index
INFO - 2018-05-11 23:12:28 --> Config Class Initialized
ERROR - 2018-05-11 23:12:28 --> 404 Page Not Found: /index
INFO - 2018-05-11 23:12:28 --> Hooks Class Initialized
INFO - 2018-05-11 23:12:28 --> Config Class Initialized
INFO - 2018-05-11 23:12:28 --> Hooks Class Initialized
DEBUG - 2018-05-11 23:12:28 --> UTF-8 Support Enabled
INFO - 2018-05-11 23:12:28 --> Config Class Initialized
INFO - 2018-05-11 23:12:28 --> Router Class Initialized
INFO - 2018-05-11 23:12:28 --> Config Class Initialized
INFO - 2018-05-11 23:12:28 --> Hooks Class Initialized
INFO - 2018-05-11 23:12:28 --> Hooks Class Initialized
DEBUG - 2018-05-11 23:12:28 --> UTF-8 Support Enabled
INFO - 2018-05-11 23:12:28 --> Output Class Initialized
INFO - 2018-05-11 23:12:28 --> Utf8 Class Initialized
DEBUG - 2018-05-11 23:12:28 --> UTF-8 Support Enabled
INFO - 2018-05-11 23:12:28 --> URI Class Initialized
INFO - 2018-05-11 23:12:28 --> Security Class Initialized
INFO - 2018-05-11 23:12:28 --> Utf8 Class Initialized
DEBUG - 2018-05-11 23:12:28 --> UTF-8 Support Enabled
INFO - 2018-05-11 23:12:28 --> Utf8 Class Initialized
INFO - 2018-05-11 23:12:28 --> Utf8 Class Initialized
INFO - 2018-05-11 23:12:28 --> URI Class Initialized
DEBUG - 2018-05-11 23:12:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 23:12:28 --> Router Class Initialized
INFO - 2018-05-11 23:12:28 --> URI Class Initialized
INFO - 2018-05-11 23:12:28 --> Router Class Initialized
INFO - 2018-05-11 23:12:28 --> Input Class Initialized
INFO - 2018-05-11 23:12:28 --> Output Class Initialized
INFO - 2018-05-11 23:12:28 --> URI Class Initialized
INFO - 2018-05-11 23:12:28 --> Router Class Initialized
INFO - 2018-05-11 23:12:28 --> Router Class Initialized
INFO - 2018-05-11 23:12:28 --> Language Class Initialized
INFO - 2018-05-11 23:12:28 --> Output Class Initialized
INFO - 2018-05-11 23:12:28 --> Security Class Initialized
ERROR - 2018-05-11 23:12:28 --> 404 Page Not Found: /index
INFO - 2018-05-11 23:12:28 --> Output Class Initialized
INFO - 2018-05-11 23:12:28 --> Output Class Initialized
INFO - 2018-05-11 23:12:28 --> Security Class Initialized
INFO - 2018-05-11 23:12:28 --> Security Class Initialized
DEBUG - 2018-05-11 23:12:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-11 23:12:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 23:12:28 --> Security Class Initialized
DEBUG - 2018-05-11 23:12:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 23:12:28 --> Config Class Initialized
INFO - 2018-05-11 23:12:28 --> Input Class Initialized
INFO - 2018-05-11 23:12:28 --> Hooks Class Initialized
INFO - 2018-05-11 23:12:28 --> Input Class Initialized
INFO - 2018-05-11 23:12:28 --> Language Class Initialized
INFO - 2018-05-11 23:12:28 --> Input Class Initialized
DEBUG - 2018-05-11 23:12:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 23:12:28 --> Input Class Initialized
DEBUG - 2018-05-11 23:12:28 --> UTF-8 Support Enabled
INFO - 2018-05-11 23:12:28 --> Language Class Initialized
ERROR - 2018-05-11 23:12:28 --> 404 Page Not Found: /index
INFO - 2018-05-11 23:12:28 --> Language Class Initialized
INFO - 2018-05-11 23:12:28 --> Utf8 Class Initialized
INFO - 2018-05-11 23:12:28 --> Language Class Initialized
ERROR - 2018-05-11 23:12:28 --> 404 Page Not Found: /index
ERROR - 2018-05-11 23:12:28 --> 404 Page Not Found: /index
INFO - 2018-05-11 23:12:28 --> Config Class Initialized
INFO - 2018-05-11 23:12:28 --> Hooks Class Initialized
INFO - 2018-05-11 23:12:28 --> URI Class Initialized
INFO - 2018-05-11 23:12:28 --> Config Class Initialized
ERROR - 2018-05-11 23:12:28 --> 404 Page Not Found: /index
INFO - 2018-05-11 23:12:28 --> Config Class Initialized
INFO - 2018-05-11 23:12:28 --> Hooks Class Initialized
DEBUG - 2018-05-11 23:12:28 --> UTF-8 Support Enabled
INFO - 2018-05-11 23:12:28 --> Hooks Class Initialized
INFO - 2018-05-11 23:12:28 --> Config Class Initialized
INFO - 2018-05-11 23:12:28 --> Router Class Initialized
INFO - 2018-05-11 23:12:28 --> Hooks Class Initialized
DEBUG - 2018-05-11 23:12:28 --> UTF-8 Support Enabled
INFO - 2018-05-11 23:12:28 --> Utf8 Class Initialized
DEBUG - 2018-05-11 23:12:28 --> UTF-8 Support Enabled
INFO - 2018-05-11 23:12:28 --> URI Class Initialized
INFO - 2018-05-11 23:12:28 --> Utf8 Class Initialized
INFO - 2018-05-11 23:12:28 --> Utf8 Class Initialized
DEBUG - 2018-05-11 23:12:28 --> UTF-8 Support Enabled
INFO - 2018-05-11 23:12:28 --> Output Class Initialized
INFO - 2018-05-11 23:12:28 --> Router Class Initialized
INFO - 2018-05-11 23:12:28 --> Security Class Initialized
INFO - 2018-05-11 23:12:28 --> Utf8 Class Initialized
INFO - 2018-05-11 23:12:28 --> URI Class Initialized
INFO - 2018-05-11 23:12:28 --> URI Class Initialized
INFO - 2018-05-11 23:12:28 --> Output Class Initialized
INFO - 2018-05-11 23:12:28 --> Router Class Initialized
INFO - 2018-05-11 23:12:28 --> URI Class Initialized
INFO - 2018-05-11 23:12:28 --> Router Class Initialized
DEBUG - 2018-05-11 23:12:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 23:12:28 --> Security Class Initialized
INFO - 2018-05-11 23:12:28 --> Output Class Initialized
INFO - 2018-05-11 23:12:28 --> Security Class Initialized
INFO - 2018-05-11 23:12:29 --> Router Class Initialized
INFO - 2018-05-11 23:12:29 --> Input Class Initialized
INFO - 2018-05-11 23:12:29 --> Output Class Initialized
DEBUG - 2018-05-11 23:12:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-11 23:12:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 23:12:29 --> Input Class Initialized
INFO - 2018-05-11 23:12:29 --> Security Class Initialized
INFO - 2018-05-11 23:12:29 --> Output Class Initialized
INFO - 2018-05-11 23:12:29 --> Input Class Initialized
INFO - 2018-05-11 23:12:29 --> Language Class Initialized
INFO - 2018-05-11 23:12:29 --> Language Class Initialized
DEBUG - 2018-05-11 23:12:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-05-11 23:12:29 --> 404 Page Not Found: /index
INFO - 2018-05-11 23:12:29 --> Security Class Initialized
ERROR - 2018-05-11 23:12:29 --> 404 Page Not Found: /index
INFO - 2018-05-11 23:12:29 --> Language Class Initialized
DEBUG - 2018-05-11 23:12:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-05-11 23:12:29 --> 404 Page Not Found: /index
INFO - 2018-05-11 23:12:29 --> Input Class Initialized
INFO - 2018-05-11 23:12:29 --> Language Class Initialized
INFO - 2018-05-11 23:12:29 --> Input Class Initialized
INFO - 2018-05-11 23:12:29 --> Language Class Initialized
ERROR - 2018-05-11 23:12:29 --> 404 Page Not Found: /index
ERROR - 2018-05-11 23:12:29 --> 404 Page Not Found: /index
INFO - 2018-05-11 23:12:32 --> Config Class Initialized
INFO - 2018-05-11 23:12:32 --> Hooks Class Initialized
DEBUG - 2018-05-11 23:12:32 --> UTF-8 Support Enabled
INFO - 2018-05-11 23:12:32 --> Utf8 Class Initialized
INFO - 2018-05-11 23:12:32 --> URI Class Initialized
INFO - 2018-05-11 23:12:32 --> Router Class Initialized
INFO - 2018-05-11 23:12:32 --> Output Class Initialized
INFO - 2018-05-11 23:12:33 --> Security Class Initialized
DEBUG - 2018-05-11 23:12:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 23:12:33 --> Input Class Initialized
INFO - 2018-05-11 23:12:33 --> Language Class Initialized
ERROR - 2018-05-11 23:12:33 --> 404 Page Not Found: /index
INFO - 2018-05-11 23:12:33 --> Config Class Initialized
INFO - 2018-05-11 23:12:33 --> Hooks Class Initialized
DEBUG - 2018-05-11 23:12:33 --> UTF-8 Support Enabled
INFO - 2018-05-11 23:12:33 --> Utf8 Class Initialized
INFO - 2018-05-11 23:12:33 --> URI Class Initialized
INFO - 2018-05-11 23:12:33 --> Router Class Initialized
INFO - 2018-05-11 23:12:33 --> Output Class Initialized
INFO - 2018-05-11 23:12:33 --> Security Class Initialized
DEBUG - 2018-05-11 23:12:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 23:12:33 --> Input Class Initialized
INFO - 2018-05-11 23:12:33 --> Language Class Initialized
ERROR - 2018-05-11 23:12:33 --> 404 Page Not Found: /index
INFO - 2018-05-11 23:12:33 --> Config Class Initialized
INFO - 2018-05-11 23:12:33 --> Hooks Class Initialized
DEBUG - 2018-05-11 23:12:33 --> UTF-8 Support Enabled
INFO - 2018-05-11 23:12:33 --> Utf8 Class Initialized
INFO - 2018-05-11 23:12:33 --> URI Class Initialized
INFO - 2018-05-11 23:12:33 --> Router Class Initialized
INFO - 2018-05-11 23:12:33 --> Output Class Initialized
INFO - 2018-05-11 23:12:33 --> Security Class Initialized
DEBUG - 2018-05-11 23:12:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 23:12:33 --> Input Class Initialized
INFO - 2018-05-11 23:12:33 --> Language Class Initialized
ERROR - 2018-05-11 23:12:33 --> 404 Page Not Found: /index
INFO - 2018-05-11 23:12:44 --> Config Class Initialized
INFO - 2018-05-11 23:12:44 --> Hooks Class Initialized
INFO - 2018-05-11 23:12:44 --> Config Class Initialized
INFO - 2018-05-11 23:12:45 --> Config Class Initialized
INFO - 2018-05-11 23:12:45 --> Config Class Initialized
INFO - 2018-05-11 23:12:45 --> Config Class Initialized
INFO - 2018-05-11 23:12:45 --> Hooks Class Initialized
INFO - 2018-05-11 23:12:45 --> Hooks Class Initialized
INFO - 2018-05-11 23:12:45 --> Hooks Class Initialized
DEBUG - 2018-05-11 23:12:45 --> UTF-8 Support Enabled
INFO - 2018-05-11 23:12:45 --> Hooks Class Initialized
DEBUG - 2018-05-11 23:12:45 --> UTF-8 Support Enabled
INFO - 2018-05-11 23:12:45 --> Utf8 Class Initialized
DEBUG - 2018-05-11 23:12:45 --> UTF-8 Support Enabled
DEBUG - 2018-05-11 23:12:45 --> UTF-8 Support Enabled
DEBUG - 2018-05-11 23:12:45 --> UTF-8 Support Enabled
INFO - 2018-05-11 23:12:45 --> Utf8 Class Initialized
INFO - 2018-05-11 23:12:45 --> Utf8 Class Initialized
INFO - 2018-05-11 23:12:45 --> Utf8 Class Initialized
INFO - 2018-05-11 23:12:45 --> URI Class Initialized
INFO - 2018-05-11 23:12:45 --> Utf8 Class Initialized
INFO - 2018-05-11 23:12:45 --> URI Class Initialized
INFO - 2018-05-11 23:12:45 --> Router Class Initialized
INFO - 2018-05-11 23:12:45 --> Output Class Initialized
INFO - 2018-05-11 23:12:45 --> Security Class Initialized
INFO - 2018-05-11 23:12:45 --> URI Class Initialized
INFO - 2018-05-11 23:12:45 --> URI Class Initialized
INFO - 2018-05-11 23:12:45 --> Router Class Initialized
DEBUG - 2018-05-11 23:12:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 23:12:45 --> URI Class Initialized
INFO - 2018-05-11 23:12:45 --> Router Class Initialized
INFO - 2018-05-11 23:12:45 --> Output Class Initialized
INFO - 2018-05-11 23:12:45 --> Input Class Initialized
INFO - 2018-05-11 23:12:45 --> Router Class Initialized
INFO - 2018-05-11 23:12:45 --> Router Class Initialized
INFO - 2018-05-11 23:12:45 --> Output Class Initialized
INFO - 2018-05-11 23:12:45 --> Output Class Initialized
INFO - 2018-05-11 23:12:45 --> Output Class Initialized
INFO - 2018-05-11 23:12:45 --> Language Class Initialized
INFO - 2018-05-11 23:12:45 --> Security Class Initialized
INFO - 2018-05-11 23:12:45 --> Security Class Initialized
INFO - 2018-05-11 23:12:45 --> Security Class Initialized
DEBUG - 2018-05-11 23:12:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-11 23:12:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-05-11 23:12:45 --> 404 Page Not Found: /index
INFO - 2018-05-11 23:12:45 --> Security Class Initialized
DEBUG - 2018-05-11 23:12:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 23:12:45 --> Input Class Initialized
DEBUG - 2018-05-11 23:12:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 23:12:45 --> Input Class Initialized
INFO - 2018-05-11 23:12:45 --> Input Class Initialized
INFO - 2018-05-11 23:12:45 --> Config Class Initialized
INFO - 2018-05-11 23:12:45 --> Language Class Initialized
INFO - 2018-05-11 23:12:45 --> Language Class Initialized
INFO - 2018-05-11 23:12:45 --> Language Class Initialized
INFO - 2018-05-11 23:12:45 --> Input Class Initialized
INFO - 2018-05-11 23:12:45 --> Hooks Class Initialized
DEBUG - 2018-05-11 23:12:45 --> UTF-8 Support Enabled
INFO - 2018-05-11 23:12:45 --> Utf8 Class Initialized
ERROR - 2018-05-11 23:12:45 --> 404 Page Not Found: /index
ERROR - 2018-05-11 23:12:45 --> 404 Page Not Found: /index
ERROR - 2018-05-11 23:12:45 --> 404 Page Not Found: /index
INFO - 2018-05-11 23:12:45 --> Language Class Initialized
INFO - 2018-05-11 23:12:45 --> URI Class Initialized
INFO - 2018-05-11 23:12:45 --> Router Class Initialized
INFO - 2018-05-11 23:12:45 --> Output Class Initialized
INFO - 2018-05-11 23:12:45 --> Security Class Initialized
DEBUG - 2018-05-11 23:12:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 23:12:45 --> Input Class Initialized
INFO - 2018-05-11 23:12:45 --> Language Class Initialized
ERROR - 2018-05-11 23:12:45 --> 404 Page Not Found: /index
ERROR - 2018-05-11 23:12:45 --> 404 Page Not Found: /index
INFO - 2018-05-11 23:12:45 --> Config Class Initialized
INFO - 2018-05-11 23:12:45 --> Config Class Initialized
INFO - 2018-05-11 23:12:46 --> Hooks Class Initialized
INFO - 2018-05-11 23:12:46 --> Hooks Class Initialized
INFO - 2018-05-11 23:12:46 --> Config Class Initialized
INFO - 2018-05-11 23:12:46 --> Hooks Class Initialized
DEBUG - 2018-05-11 23:12:46 --> UTF-8 Support Enabled
DEBUG - 2018-05-11 23:12:46 --> UTF-8 Support Enabled
DEBUG - 2018-05-11 23:12:46 --> UTF-8 Support Enabled
INFO - 2018-05-11 23:12:46 --> Config Class Initialized
INFO - 2018-05-11 23:12:46 --> Hooks Class Initialized
INFO - 2018-05-11 23:12:46 --> Utf8 Class Initialized
DEBUG - 2018-05-11 23:12:46 --> UTF-8 Support Enabled
INFO - 2018-05-11 23:12:46 --> Utf8 Class Initialized
INFO - 2018-05-11 23:12:46 --> Utf8 Class Initialized
INFO - 2018-05-11 23:12:46 --> URI Class Initialized
INFO - 2018-05-11 23:12:46 --> Utf8 Class Initialized
INFO - 2018-05-11 23:12:46 --> Router Class Initialized
INFO - 2018-05-11 23:12:46 --> URI Class Initialized
INFO - 2018-05-11 23:12:46 --> URI Class Initialized
INFO - 2018-05-11 23:12:46 --> Router Class Initialized
INFO - 2018-05-11 23:12:46 --> Output Class Initialized
INFO - 2018-05-11 23:12:46 --> Router Class Initialized
INFO - 2018-05-11 23:12:46 --> URI Class Initialized
INFO - 2018-05-11 23:12:46 --> Security Class Initialized
INFO - 2018-05-11 23:12:46 --> Output Class Initialized
INFO - 2018-05-11 23:12:46 --> Router Class Initialized
INFO - 2018-05-11 23:12:46 --> Output Class Initialized
DEBUG - 2018-05-11 23:12:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 23:12:46 --> Security Class Initialized
DEBUG - 2018-05-11 23:12:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 23:12:46 --> Output Class Initialized
INFO - 2018-05-11 23:12:46 --> Input Class Initialized
INFO - 2018-05-11 23:12:46 --> Input Class Initialized
INFO - 2018-05-11 23:12:46 --> Security Class Initialized
INFO - 2018-05-11 23:12:46 --> Security Class Initialized
DEBUG - 2018-05-11 23:12:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 23:12:46 --> Input Class Initialized
INFO - 2018-05-11 23:12:46 --> Language Class Initialized
ERROR - 2018-05-11 23:12:46 --> 404 Page Not Found: /index
INFO - 2018-05-11 23:12:46 --> Language Class Initialized
ERROR - 2018-05-11 23:12:46 --> 404 Page Not Found: /index
INFO - 2018-05-11 23:12:46 --> Language Class Initialized
INFO - 2018-05-11 23:12:46 --> Config Class Initialized
DEBUG - 2018-05-11 23:12:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 23:12:46 --> Hooks Class Initialized
ERROR - 2018-05-11 23:12:46 --> 404 Page Not Found: /index
INFO - 2018-05-11 23:12:46 --> Input Class Initialized
INFO - 2018-05-11 23:12:46 --> Language Class Initialized
DEBUG - 2018-05-11 23:12:46 --> UTF-8 Support Enabled
INFO - 2018-05-11 23:12:46 --> Utf8 Class Initialized
ERROR - 2018-05-11 23:12:46 --> 404 Page Not Found: /index
INFO - 2018-05-11 23:12:46 --> Config Class Initialized
INFO - 2018-05-11 23:12:46 --> Config Class Initialized
INFO - 2018-05-11 23:12:46 --> Hooks Class Initialized
INFO - 2018-05-11 23:12:46 --> URI Class Initialized
INFO - 2018-05-11 23:12:46 --> Hooks Class Initialized
DEBUG - 2018-05-11 23:12:46 --> UTF-8 Support Enabled
DEBUG - 2018-05-11 23:12:46 --> UTF-8 Support Enabled
INFO - 2018-05-11 23:12:46 --> Router Class Initialized
INFO - 2018-05-11 23:12:46 --> Utf8 Class Initialized
INFO - 2018-05-11 23:12:46 --> URI Class Initialized
INFO - 2018-05-11 23:12:46 --> Router Class Initialized
INFO - 2018-05-11 23:12:46 --> Output Class Initialized
INFO - 2018-05-11 23:12:46 --> Output Class Initialized
INFO - 2018-05-11 23:12:46 --> Security Class Initialized
DEBUG - 2018-05-11 23:12:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 23:12:46 --> Input Class Initialized
INFO - 2018-05-11 23:12:46 --> Language Class Initialized
INFO - 2018-05-11 23:12:46 --> Security Class Initialized
INFO - 2018-05-11 23:12:46 --> Utf8 Class Initialized
ERROR - 2018-05-11 23:12:46 --> 404 Page Not Found: /index
DEBUG - 2018-05-11 23:12:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 23:12:46 --> URI Class Initialized
INFO - 2018-05-11 23:12:46 --> Input Class Initialized
INFO - 2018-05-11 23:12:46 --> Router Class Initialized
INFO - 2018-05-11 23:12:47 --> Language Class Initialized
INFO - 2018-05-11 23:12:47 --> Output Class Initialized
INFO - 2018-05-11 23:12:47 --> Security Class Initialized
ERROR - 2018-05-11 23:12:47 --> 404 Page Not Found: /index
DEBUG - 2018-05-11 23:12:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 23:12:47 --> Input Class Initialized
INFO - 2018-05-11 23:12:47 --> Language Class Initialized
ERROR - 2018-05-11 23:12:47 --> 404 Page Not Found: /index
INFO - 2018-05-11 23:13:11 --> Config Class Initialized
INFO - 2018-05-11 23:13:11 --> Hooks Class Initialized
DEBUG - 2018-05-11 23:13:11 --> UTF-8 Support Enabled
INFO - 2018-05-11 23:13:11 --> Utf8 Class Initialized
INFO - 2018-05-11 23:13:11 --> URI Class Initialized
INFO - 2018-05-11 23:13:11 --> Router Class Initialized
INFO - 2018-05-11 23:13:11 --> Output Class Initialized
INFO - 2018-05-11 23:13:11 --> Security Class Initialized
DEBUG - 2018-05-11 23:13:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 23:13:11 --> Input Class Initialized
INFO - 2018-05-11 23:13:11 --> Language Class Initialized
ERROR - 2018-05-11 23:13:11 --> 404 Page Not Found: /index
INFO - 2018-05-11 23:13:11 --> Config Class Initialized
INFO - 2018-05-11 23:13:11 --> Hooks Class Initialized
DEBUG - 2018-05-11 23:13:11 --> UTF-8 Support Enabled
INFO - 2018-05-11 23:13:11 --> Utf8 Class Initialized
INFO - 2018-05-11 23:13:11 --> URI Class Initialized
INFO - 2018-05-11 23:13:11 --> Router Class Initialized
INFO - 2018-05-11 23:13:11 --> Output Class Initialized
INFO - 2018-05-11 23:13:11 --> Security Class Initialized
DEBUG - 2018-05-11 23:13:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 23:13:11 --> Input Class Initialized
INFO - 2018-05-11 23:13:11 --> Language Class Initialized
ERROR - 2018-05-11 23:13:12 --> 404 Page Not Found: /index
INFO - 2018-05-11 23:13:12 --> Config Class Initialized
INFO - 2018-05-11 23:13:12 --> Hooks Class Initialized
DEBUG - 2018-05-11 23:13:12 --> UTF-8 Support Enabled
INFO - 2018-05-11 23:13:12 --> Utf8 Class Initialized
INFO - 2018-05-11 23:13:12 --> URI Class Initialized
INFO - 2018-05-11 23:13:12 --> Router Class Initialized
INFO - 2018-05-11 23:13:12 --> Output Class Initialized
INFO - 2018-05-11 23:13:12 --> Security Class Initialized
DEBUG - 2018-05-11 23:13:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 23:13:12 --> Input Class Initialized
INFO - 2018-05-11 23:13:12 --> Language Class Initialized
ERROR - 2018-05-11 23:13:12 --> 404 Page Not Found: /index
INFO - 2018-05-11 23:13:16 --> Config Class Initialized
INFO - 2018-05-11 23:13:16 --> Config Class Initialized
INFO - 2018-05-11 23:13:16 --> Config Class Initialized
INFO - 2018-05-11 23:13:16 --> Config Class Initialized
INFO - 2018-05-11 23:13:16 --> Config Class Initialized
INFO - 2018-05-11 23:13:16 --> Hooks Class Initialized
INFO - 2018-05-11 23:13:16 --> Hooks Class Initialized
INFO - 2018-05-11 23:13:16 --> Hooks Class Initialized
INFO - 2018-05-11 23:13:16 --> Hooks Class Initialized
INFO - 2018-05-11 23:13:16 --> Hooks Class Initialized
DEBUG - 2018-05-11 23:13:16 --> UTF-8 Support Enabled
DEBUG - 2018-05-11 23:13:16 --> UTF-8 Support Enabled
DEBUG - 2018-05-11 23:13:16 --> UTF-8 Support Enabled
DEBUG - 2018-05-11 23:13:16 --> UTF-8 Support Enabled
DEBUG - 2018-05-11 23:13:16 --> UTF-8 Support Enabled
INFO - 2018-05-11 23:13:16 --> Utf8 Class Initialized
INFO - 2018-05-11 23:13:16 --> Utf8 Class Initialized
INFO - 2018-05-11 23:13:16 --> Utf8 Class Initialized
INFO - 2018-05-11 23:13:16 --> Utf8 Class Initialized
INFO - 2018-05-11 23:13:16 --> Utf8 Class Initialized
INFO - 2018-05-11 23:13:16 --> URI Class Initialized
INFO - 2018-05-11 23:13:16 --> URI Class Initialized
INFO - 2018-05-11 23:13:16 --> Router Class Initialized
INFO - 2018-05-11 23:13:16 --> URI Class Initialized
INFO - 2018-05-11 23:13:16 --> URI Class Initialized
INFO - 2018-05-11 23:13:16 --> URI Class Initialized
INFO - 2018-05-11 23:13:16 --> Router Class Initialized
INFO - 2018-05-11 23:13:16 --> Output Class Initialized
INFO - 2018-05-11 23:13:16 --> Output Class Initialized
INFO - 2018-05-11 23:13:16 --> Router Class Initialized
INFO - 2018-05-11 23:13:16 --> Router Class Initialized
INFO - 2018-05-11 23:13:16 --> Router Class Initialized
INFO - 2018-05-11 23:13:16 --> Security Class Initialized
INFO - 2018-05-11 23:13:16 --> Security Class Initialized
DEBUG - 2018-05-11 23:13:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 23:13:16 --> Input Class Initialized
INFO - 2018-05-11 23:13:17 --> Language Class Initialized
DEBUG - 2018-05-11 23:13:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 23:13:17 --> Output Class Initialized
ERROR - 2018-05-11 23:13:17 --> 404 Page Not Found: /index
INFO - 2018-05-11 23:13:17 --> Output Class Initialized
INFO - 2018-05-11 23:13:17 --> Output Class Initialized
INFO - 2018-05-11 23:13:17 --> Security Class Initialized
INFO - 2018-05-11 23:13:17 --> Security Class Initialized
INFO - 2018-05-11 23:13:17 --> Input Class Initialized
INFO - 2018-05-11 23:13:17 --> Security Class Initialized
INFO - 2018-05-11 23:13:17 --> Config Class Initialized
DEBUG - 2018-05-11 23:13:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-11 23:13:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-11 23:13:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 23:13:17 --> Language Class Initialized
INFO - 2018-05-11 23:13:17 --> Hooks Class Initialized
INFO - 2018-05-11 23:13:17 --> Input Class Initialized
INFO - 2018-05-11 23:13:17 --> Input Class Initialized
INFO - 2018-05-11 23:13:17 --> Input Class Initialized
ERROR - 2018-05-11 23:13:17 --> 404 Page Not Found: /index
DEBUG - 2018-05-11 23:13:17 --> UTF-8 Support Enabled
INFO - 2018-05-11 23:13:17 --> Language Class Initialized
ERROR - 2018-05-11 23:13:17 --> 404 Page Not Found: /index
INFO - 2018-05-11 23:13:17 --> Utf8 Class Initialized
INFO - 2018-05-11 23:13:17 --> URI Class Initialized
INFO - 2018-05-11 23:13:17 --> Router Class Initialized
INFO - 2018-05-11 23:13:17 --> Output Class Initialized
INFO - 2018-05-11 23:13:17 --> Security Class Initialized
DEBUG - 2018-05-11 23:13:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 23:13:17 --> Input Class Initialized
INFO - 2018-05-11 23:13:17 --> Config Class Initialized
INFO - 2018-05-11 23:13:17 --> Language Class Initialized
INFO - 2018-05-11 23:13:17 --> Language Class Initialized
INFO - 2018-05-11 23:13:17 --> Hooks Class Initialized
INFO - 2018-05-11 23:13:17 --> Language Class Initialized
INFO - 2018-05-11 23:13:17 --> Config Class Initialized
ERROR - 2018-05-11 23:13:17 --> 404 Page Not Found: /index
ERROR - 2018-05-11 23:13:17 --> 404 Page Not Found: /index
INFO - 2018-05-11 23:13:17 --> Hooks Class Initialized
DEBUG - 2018-05-11 23:13:17 --> UTF-8 Support Enabled
ERROR - 2018-05-11 23:13:17 --> 404 Page Not Found: /index
DEBUG - 2018-05-11 23:13:17 --> UTF-8 Support Enabled
INFO - 2018-05-11 23:13:17 --> Config Class Initialized
INFO - 2018-05-11 23:13:17 --> Hooks Class Initialized
INFO - 2018-05-11 23:13:17 --> Utf8 Class Initialized
INFO - 2018-05-11 23:13:17 --> Utf8 Class Initialized
DEBUG - 2018-05-11 23:13:17 --> UTF-8 Support Enabled
INFO - 2018-05-11 23:13:17 --> Config Class Initialized
INFO - 2018-05-11 23:13:17 --> URI Class Initialized
INFO - 2018-05-11 23:13:17 --> Hooks Class Initialized
INFO - 2018-05-11 23:13:17 --> Utf8 Class Initialized
INFO - 2018-05-11 23:13:17 --> Router Class Initialized
INFO - 2018-05-11 23:13:17 --> URI Class Initialized
INFO - 2018-05-11 23:13:17 --> Output Class Initialized
INFO - 2018-05-11 23:13:17 --> URI Class Initialized
INFO - 2018-05-11 23:13:17 --> Router Class Initialized
DEBUG - 2018-05-11 23:13:17 --> UTF-8 Support Enabled
INFO - 2018-05-11 23:13:17 --> Output Class Initialized
INFO - 2018-05-11 23:13:17 --> Security Class Initialized
INFO - 2018-05-11 23:13:17 --> Utf8 Class Initialized
INFO - 2018-05-11 23:13:17 --> Router Class Initialized
INFO - 2018-05-11 23:13:17 --> URI Class Initialized
INFO - 2018-05-11 23:13:17 --> Security Class Initialized
INFO - 2018-05-11 23:13:17 --> Output Class Initialized
DEBUG - 2018-05-11 23:13:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 23:13:17 --> Input Class Initialized
DEBUG - 2018-05-11 23:13:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 23:13:17 --> Security Class Initialized
INFO - 2018-05-11 23:13:17 --> Router Class Initialized
INFO - 2018-05-11 23:13:18 --> Language Class Initialized
ERROR - 2018-05-11 23:13:18 --> 404 Page Not Found: /index
INFO - 2018-05-11 23:13:18 --> Output Class Initialized
INFO - 2018-05-11 23:13:18 --> Input Class Initialized
DEBUG - 2018-05-11 23:13:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 23:13:18 --> Security Class Initialized
INFO - 2018-05-11 23:13:18 --> Language Class Initialized
INFO - 2018-05-11 23:13:18 --> Config Class Initialized
DEBUG - 2018-05-11 23:13:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 23:13:18 --> Hooks Class Initialized
ERROR - 2018-05-11 23:13:18 --> 404 Page Not Found: /index
INFO - 2018-05-11 23:13:18 --> Input Class Initialized
INFO - 2018-05-11 23:13:18 --> Input Class Initialized
DEBUG - 2018-05-11 23:13:18 --> UTF-8 Support Enabled
INFO - 2018-05-11 23:13:18 --> Utf8 Class Initialized
INFO - 2018-05-11 23:13:18 --> Language Class Initialized
INFO - 2018-05-11 23:13:18 --> Config Class Initialized
INFO - 2018-05-11 23:13:18 --> Language Class Initialized
INFO - 2018-05-11 23:13:18 --> URI Class Initialized
INFO - 2018-05-11 23:13:18 --> Hooks Class Initialized
ERROR - 2018-05-11 23:13:18 --> 404 Page Not Found: /index
DEBUG - 2018-05-11 23:13:18 --> UTF-8 Support Enabled
INFO - 2018-05-11 23:13:18 --> Config Class Initialized
INFO - 2018-05-11 23:13:18 --> Hooks Class Initialized
INFO - 2018-05-11 23:13:18 --> Utf8 Class Initialized
ERROR - 2018-05-11 23:13:18 --> 404 Page Not Found: /index
INFO - 2018-05-11 23:13:18 --> Router Class Initialized
DEBUG - 2018-05-11 23:13:18 --> UTF-8 Support Enabled
INFO - 2018-05-11 23:13:18 --> Utf8 Class Initialized
INFO - 2018-05-11 23:13:18 --> URI Class Initialized
INFO - 2018-05-11 23:13:18 --> Router Class Initialized
INFO - 2018-05-11 23:13:18 --> URI Class Initialized
INFO - 2018-05-11 23:13:18 --> Output Class Initialized
INFO - 2018-05-11 23:13:18 --> Security Class Initialized
DEBUG - 2018-05-11 23:13:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 23:13:18 --> Input Class Initialized
INFO - 2018-05-11 23:13:18 --> Language Class Initialized
ERROR - 2018-05-11 23:13:18 --> 404 Page Not Found: /index
INFO - 2018-05-11 23:13:18 --> Output Class Initialized
INFO - 2018-05-11 23:13:18 --> Router Class Initialized
INFO - 2018-05-11 23:13:18 --> Output Class Initialized
INFO - 2018-05-11 23:13:18 --> Security Class Initialized
INFO - 2018-05-11 23:13:18 --> Security Class Initialized
DEBUG - 2018-05-11 23:13:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 23:13:18 --> Input Class Initialized
INFO - 2018-05-11 23:13:18 --> Language Class Initialized
ERROR - 2018-05-11 23:13:18 --> 404 Page Not Found: /index
DEBUG - 2018-05-11 23:13:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 23:13:18 --> Input Class Initialized
INFO - 2018-05-11 23:13:18 --> Language Class Initialized
ERROR - 2018-05-11 23:13:18 --> 404 Page Not Found: /index
INFO - 2018-05-11 23:13:28 --> Config Class Initialized
INFO - 2018-05-11 23:13:28 --> Hooks Class Initialized
DEBUG - 2018-05-11 23:13:29 --> UTF-8 Support Enabled
INFO - 2018-05-11 23:13:29 --> Utf8 Class Initialized
INFO - 2018-05-11 23:13:29 --> URI Class Initialized
INFO - 2018-05-11 23:13:29 --> Router Class Initialized
INFO - 2018-05-11 23:13:29 --> Output Class Initialized
INFO - 2018-05-11 23:13:29 --> Security Class Initialized
DEBUG - 2018-05-11 23:13:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 23:13:29 --> Input Class Initialized
INFO - 2018-05-11 23:13:29 --> Language Class Initialized
ERROR - 2018-05-11 23:13:29 --> 404 Page Not Found: /index
INFO - 2018-05-11 23:13:29 --> Config Class Initialized
INFO - 2018-05-11 23:13:29 --> Hooks Class Initialized
DEBUG - 2018-05-11 23:13:29 --> UTF-8 Support Enabled
INFO - 2018-05-11 23:13:29 --> Utf8 Class Initialized
INFO - 2018-05-11 23:13:29 --> URI Class Initialized
INFO - 2018-05-11 23:13:29 --> Router Class Initialized
INFO - 2018-05-11 23:13:29 --> Output Class Initialized
INFO - 2018-05-11 23:13:29 --> Security Class Initialized
DEBUG - 2018-05-11 23:13:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 23:13:29 --> Input Class Initialized
INFO - 2018-05-11 23:13:29 --> Language Class Initialized
ERROR - 2018-05-11 23:13:29 --> 404 Page Not Found: /index
INFO - 2018-05-11 23:13:29 --> Config Class Initialized
INFO - 2018-05-11 23:13:29 --> Hooks Class Initialized
DEBUG - 2018-05-11 23:13:29 --> UTF-8 Support Enabled
INFO - 2018-05-11 23:13:29 --> Utf8 Class Initialized
INFO - 2018-05-11 23:13:29 --> URI Class Initialized
INFO - 2018-05-11 23:13:29 --> Router Class Initialized
INFO - 2018-05-11 23:13:29 --> Output Class Initialized
INFO - 2018-05-11 23:13:29 --> Security Class Initialized
DEBUG - 2018-05-11 23:13:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 23:13:29 --> Input Class Initialized
INFO - 2018-05-11 23:13:29 --> Language Class Initialized
ERROR - 2018-05-11 23:13:29 --> 404 Page Not Found: /index
INFO - 2018-05-11 23:13:58 --> Config Class Initialized
INFO - 2018-05-11 23:13:58 --> Hooks Class Initialized
DEBUG - 2018-05-11 23:13:58 --> UTF-8 Support Enabled
INFO - 2018-05-11 23:13:58 --> Utf8 Class Initialized
INFO - 2018-05-11 23:13:58 --> URI Class Initialized
INFO - 2018-05-11 23:13:58 --> Router Class Initialized
INFO - 2018-05-11 23:13:58 --> Output Class Initialized
INFO - 2018-05-11 23:13:58 --> Security Class Initialized
DEBUG - 2018-05-11 23:13:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 23:13:58 --> Input Class Initialized
INFO - 2018-05-11 23:13:58 --> Language Class Initialized
INFO - 2018-05-11 23:13:58 --> Language Class Initialized
INFO - 2018-05-11 23:13:58 --> Config Class Initialized
INFO - 2018-05-11 23:13:58 --> Loader Class Initialized
DEBUG - 2018-05-11 23:13:58 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-11 23:13:58 --> Helper loaded: url_helper
INFO - 2018-05-11 23:13:58 --> Helper loaded: form_helper
INFO - 2018-05-11 23:13:58 --> Helper loaded: date_helper
INFO - 2018-05-11 23:13:58 --> Helper loaded: util_helper
INFO - 2018-05-11 23:13:58 --> Helper loaded: text_helper
INFO - 2018-05-11 23:13:58 --> Helper loaded: string_helper
INFO - 2018-05-11 23:13:58 --> Database Driver Class Initialized
DEBUG - 2018-05-11 23:13:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-11 23:13:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-11 23:13:58 --> Email Class Initialized
INFO - 2018-05-11 23:13:58 --> Controller Class Initialized
DEBUG - 2018-05-11 23:13:58 --> Programs MX_Controller Initialized
INFO - 2018-05-11 23:13:58 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-11 23:13:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-05-11 23:13:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-11 23:13:58 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-11 23:13:58 --> Login MX_Controller Initialized
DEBUG - 2018-05-11 23:13:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-11 23:13:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-05-11 23:13:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-05-11 23:13:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-05-11 23:13:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-05-11 23:13:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-05-11 23:13:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/programs/create_program.php
INFO - 2018-05-11 23:13:58 --> Final output sent to browser
DEBUG - 2018-05-11 23:13:59 --> Total execution time: 0.7848
INFO - 2018-05-11 23:13:59 --> Config Class Initialized
INFO - 2018-05-11 23:14:00 --> Hooks Class Initialized
DEBUG - 2018-05-11 23:14:00 --> UTF-8 Support Enabled
INFO - 2018-05-11 23:14:00 --> Utf8 Class Initialized
INFO - 2018-05-11 23:14:00 --> URI Class Initialized
INFO - 2018-05-11 23:14:00 --> Router Class Initialized
INFO - 2018-05-11 23:14:00 --> Output Class Initialized
INFO - 2018-05-11 23:14:00 --> Security Class Initialized
DEBUG - 2018-05-11 23:14:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 23:14:00 --> Input Class Initialized
INFO - 2018-05-11 23:14:00 --> Language Class Initialized
ERROR - 2018-05-11 23:14:00 --> 404 Page Not Found: /index
INFO - 2018-05-11 23:14:20 --> Config Class Initialized
INFO - 2018-05-11 23:14:20 --> Hooks Class Initialized
DEBUG - 2018-05-11 23:14:20 --> UTF-8 Support Enabled
INFO - 2018-05-11 23:14:20 --> Utf8 Class Initialized
INFO - 2018-05-11 23:14:20 --> URI Class Initialized
INFO - 2018-05-11 23:14:20 --> Router Class Initialized
INFO - 2018-05-11 23:14:20 --> Output Class Initialized
INFO - 2018-05-11 23:14:20 --> Security Class Initialized
DEBUG - 2018-05-11 23:14:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 23:14:20 --> Input Class Initialized
INFO - 2018-05-11 23:14:20 --> Language Class Initialized
INFO - 2018-05-11 23:14:20 --> Language Class Initialized
INFO - 2018-05-11 23:14:21 --> Config Class Initialized
INFO - 2018-05-11 23:14:21 --> Loader Class Initialized
DEBUG - 2018-05-11 23:14:21 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-11 23:14:21 --> Helper loaded: url_helper
INFO - 2018-05-11 23:14:21 --> Helper loaded: form_helper
INFO - 2018-05-11 23:14:21 --> Helper loaded: date_helper
INFO - 2018-05-11 23:14:21 --> Helper loaded: util_helper
INFO - 2018-05-11 23:14:21 --> Helper loaded: text_helper
INFO - 2018-05-11 23:14:21 --> Helper loaded: string_helper
INFO - 2018-05-11 23:14:21 --> Database Driver Class Initialized
DEBUG - 2018-05-11 23:14:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-11 23:14:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-11 23:14:21 --> Email Class Initialized
INFO - 2018-05-11 23:14:21 --> Controller Class Initialized
DEBUG - 2018-05-11 23:14:21 --> Programs MX_Controller Initialized
INFO - 2018-05-11 23:14:21 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-11 23:14:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-05-11 23:14:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-11 23:14:21 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-11 23:14:21 --> Login MX_Controller Initialized
DEBUG - 2018-05-11 23:14:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-11 23:14:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-05-11 23:14:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-05-11 23:14:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-05-11 23:14:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-05-11 23:14:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-05-11 23:14:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/programs/create_program.php
INFO - 2018-05-11 23:14:21 --> Final output sent to browser
DEBUG - 2018-05-11 23:14:21 --> Total execution time: 0.7856
INFO - 2018-05-11 23:14:22 --> Config Class Initialized
INFO - 2018-05-11 23:14:22 --> Hooks Class Initialized
DEBUG - 2018-05-11 23:14:22 --> UTF-8 Support Enabled
INFO - 2018-05-11 23:14:22 --> Utf8 Class Initialized
INFO - 2018-05-11 23:14:22 --> URI Class Initialized
INFO - 2018-05-11 23:14:22 --> Router Class Initialized
INFO - 2018-05-11 23:14:22 --> Output Class Initialized
INFO - 2018-05-11 23:14:22 --> Security Class Initialized
DEBUG - 2018-05-11 23:14:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 23:14:22 --> Input Class Initialized
INFO - 2018-05-11 23:14:22 --> Language Class Initialized
ERROR - 2018-05-11 23:14:22 --> 404 Page Not Found: /index
INFO - 2018-05-11 23:14:52 --> Config Class Initialized
INFO - 2018-05-11 23:14:52 --> Hooks Class Initialized
DEBUG - 2018-05-11 23:14:52 --> UTF-8 Support Enabled
INFO - 2018-05-11 23:14:52 --> Utf8 Class Initialized
INFO - 2018-05-11 23:14:52 --> URI Class Initialized
INFO - 2018-05-11 23:14:52 --> Router Class Initialized
INFO - 2018-05-11 23:14:52 --> Output Class Initialized
INFO - 2018-05-11 23:14:52 --> Security Class Initialized
DEBUG - 2018-05-11 23:14:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 23:14:52 --> Input Class Initialized
INFO - 2018-05-11 23:14:52 --> Language Class Initialized
INFO - 2018-05-11 23:14:52 --> Language Class Initialized
INFO - 2018-05-11 23:14:52 --> Config Class Initialized
INFO - 2018-05-11 23:14:52 --> Loader Class Initialized
DEBUG - 2018-05-11 23:14:52 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-11 23:14:52 --> Helper loaded: url_helper
INFO - 2018-05-11 23:14:52 --> Helper loaded: form_helper
INFO - 2018-05-11 23:14:52 --> Helper loaded: date_helper
INFO - 2018-05-11 23:14:52 --> Helper loaded: util_helper
INFO - 2018-05-11 23:14:52 --> Helper loaded: text_helper
INFO - 2018-05-11 23:14:52 --> Helper loaded: string_helper
INFO - 2018-05-11 23:14:52 --> Database Driver Class Initialized
DEBUG - 2018-05-11 23:14:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-11 23:14:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-11 23:14:53 --> Email Class Initialized
INFO - 2018-05-11 23:14:53 --> Controller Class Initialized
DEBUG - 2018-05-11 23:14:53 --> Programs MX_Controller Initialized
INFO - 2018-05-11 23:14:53 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-11 23:14:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-05-11 23:14:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-11 23:14:53 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-11 23:14:53 --> Login MX_Controller Initialized
DEBUG - 2018-05-11 23:14:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-11 23:14:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-05-11 23:14:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-05-11 23:14:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-05-11 23:14:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-05-11 23:14:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-05-11 23:14:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/programs/programs.php
INFO - 2018-05-11 23:14:53 --> Final output sent to browser
DEBUG - 2018-05-11 23:14:53 --> Total execution time: 0.8234
INFO - 2018-05-11 23:14:53 --> Config Class Initialized
INFO - 2018-05-11 23:14:54 --> Hooks Class Initialized
DEBUG - 2018-05-11 23:14:54 --> UTF-8 Support Enabled
INFO - 2018-05-11 23:14:54 --> Utf8 Class Initialized
INFO - 2018-05-11 23:14:54 --> URI Class Initialized
INFO - 2018-05-11 23:14:54 --> Router Class Initialized
INFO - 2018-05-11 23:14:54 --> Output Class Initialized
INFO - 2018-05-11 23:14:54 --> Security Class Initialized
DEBUG - 2018-05-11 23:14:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 23:14:54 --> Input Class Initialized
INFO - 2018-05-11 23:14:54 --> Language Class Initialized
INFO - 2018-05-11 23:14:54 --> Language Class Initialized
INFO - 2018-05-11 23:14:54 --> Config Class Initialized
INFO - 2018-05-11 23:14:54 --> Loader Class Initialized
INFO - 2018-05-11 23:14:54 --> Config Class Initialized
DEBUG - 2018-05-11 23:14:54 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-11 23:14:54 --> Hooks Class Initialized
DEBUG - 2018-05-11 23:14:54 --> UTF-8 Support Enabled
INFO - 2018-05-11 23:14:54 --> Helper loaded: url_helper
INFO - 2018-05-11 23:14:54 --> Helper loaded: form_helper
INFO - 2018-05-11 23:14:54 --> Utf8 Class Initialized
INFO - 2018-05-11 23:14:54 --> Helper loaded: date_helper
INFO - 2018-05-11 23:14:54 --> URI Class Initialized
INFO - 2018-05-11 23:14:54 --> Helper loaded: util_helper
INFO - 2018-05-11 23:14:54 --> Router Class Initialized
INFO - 2018-05-11 23:14:54 --> Output Class Initialized
INFO - 2018-05-11 23:14:54 --> Helper loaded: text_helper
INFO - 2018-05-11 23:14:54 --> Security Class Initialized
INFO - 2018-05-11 23:14:54 --> Helper loaded: string_helper
DEBUG - 2018-05-11 23:14:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 23:14:54 --> Input Class Initialized
INFO - 2018-05-11 23:14:54 --> Database Driver Class Initialized
INFO - 2018-05-11 23:14:54 --> Language Class Initialized
DEBUG - 2018-05-11 23:14:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-11 23:14:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-11 23:14:54 --> Language Class Initialized
INFO - 2018-05-11 23:14:54 --> Config Class Initialized
INFO - 2018-05-11 23:14:54 --> Email Class Initialized
INFO - 2018-05-11 23:14:54 --> Controller Class Initialized
INFO - 2018-05-11 23:14:54 --> Loader Class Initialized
DEBUG - 2018-05-11 23:14:54 --> Programs MX_Controller Initialized
DEBUG - 2018-05-11 23:14:54 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-11 23:14:54 --> Language file loaded: language/english/data_lang.php
INFO - 2018-05-11 23:14:54 --> Helper loaded: url_helper
INFO - 2018-05-11 23:14:54 --> Helper loaded: form_helper
INFO - 2018-05-11 23:14:54 --> Helper loaded: date_helper
INFO - 2018-05-11 23:14:54 --> Helper loaded: util_helper
INFO - 2018-05-11 23:14:54 --> Helper loaded: text_helper
INFO - 2018-05-11 23:14:54 --> Helper loaded: string_helper
DEBUG - 2018-05-11 23:14:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
INFO - 2018-05-11 23:14:55 --> Database Driver Class Initialized
DEBUG - 2018-05-11 23:14:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-11 23:14:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-05-11 23:14:55 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-11 23:14:55 --> Login MX_Controller Initialized
DEBUG - 2018-05-11 23:14:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-11 23:14:55 --> Final output sent to browser
DEBUG - 2018-05-11 23:14:55 --> Total execution time: 1.1236
INFO - 2018-05-11 23:14:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-11 23:14:55 --> Email Class Initialized
INFO - 2018-05-11 23:14:55 --> Controller Class Initialized
DEBUG - 2018-05-11 23:14:55 --> Programs MX_Controller Initialized
INFO - 2018-05-11 23:14:55 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-11 23:14:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-05-11 23:14:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-11 23:14:55 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-11 23:14:55 --> Login MX_Controller Initialized
DEBUG - 2018-05-11 23:14:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-11 23:14:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-05-11 23:14:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-05-11 23:14:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-05-11 23:14:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-05-11 23:14:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-05-11 23:14:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/programs/programs.php
INFO - 2018-05-11 23:14:55 --> Final output sent to browser
DEBUG - 2018-05-11 23:14:55 --> Total execution time: 0.9671
INFO - 2018-05-11 23:14:55 --> Config Class Initialized
INFO - 2018-05-11 23:14:55 --> Hooks Class Initialized
DEBUG - 2018-05-11 23:14:55 --> UTF-8 Support Enabled
INFO - 2018-05-11 23:14:55 --> Utf8 Class Initialized
INFO - 2018-05-11 23:14:55 --> URI Class Initialized
INFO - 2018-05-11 23:14:55 --> Router Class Initialized
INFO - 2018-05-11 23:14:56 --> Output Class Initialized
INFO - 2018-05-11 23:14:56 --> Security Class Initialized
DEBUG - 2018-05-11 23:14:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 23:14:56 --> Input Class Initialized
INFO - 2018-05-11 23:14:56 --> Language Class Initialized
INFO - 2018-05-11 23:14:56 --> Language Class Initialized
INFO - 2018-05-11 23:14:56 --> Config Class Initialized
INFO - 2018-05-11 23:14:56 --> Config Class Initialized
INFO - 2018-05-11 23:14:56 --> Hooks Class Initialized
INFO - 2018-05-11 23:14:56 --> Loader Class Initialized
DEBUG - 2018-05-11 23:14:56 --> UTF-8 Support Enabled
INFO - 2018-05-11 23:14:56 --> Utf8 Class Initialized
INFO - 2018-05-11 23:14:56 --> URI Class Initialized
INFO - 2018-05-11 23:14:56 --> Router Class Initialized
INFO - 2018-05-11 23:14:56 --> Output Class Initialized
INFO - 2018-05-11 23:14:56 --> Security Class Initialized
DEBUG - 2018-05-11 23:14:56 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
DEBUG - 2018-05-11 23:14:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 23:14:56 --> Helper loaded: url_helper
INFO - 2018-05-11 23:14:56 --> Input Class Initialized
INFO - 2018-05-11 23:14:56 --> Helper loaded: form_helper
INFO - 2018-05-11 23:14:56 --> Language Class Initialized
INFO - 2018-05-11 23:14:56 --> Helper loaded: date_helper
INFO - 2018-05-11 23:14:56 --> Helper loaded: util_helper
INFO - 2018-05-11 23:14:56 --> Language Class Initialized
INFO - 2018-05-11 23:14:56 --> Helper loaded: text_helper
INFO - 2018-05-11 23:14:56 --> Config Class Initialized
INFO - 2018-05-11 23:14:56 --> Loader Class Initialized
INFO - 2018-05-11 23:14:56 --> Helper loaded: string_helper
DEBUG - 2018-05-11 23:14:56 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-11 23:14:56 --> Helper loaded: url_helper
INFO - 2018-05-11 23:14:56 --> Helper loaded: form_helper
INFO - 2018-05-11 23:14:56 --> Database Driver Class Initialized
INFO - 2018-05-11 23:14:56 --> Helper loaded: date_helper
DEBUG - 2018-05-11 23:14:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-11 23:14:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-11 23:14:56 --> Helper loaded: util_helper
INFO - 2018-05-11 23:14:56 --> Email Class Initialized
INFO - 2018-05-11 23:14:56 --> Helper loaded: text_helper
INFO - 2018-05-11 23:14:56 --> Controller Class Initialized
INFO - 2018-05-11 23:14:56 --> Helper loaded: string_helper
DEBUG - 2018-05-11 23:14:56 --> Programs MX_Controller Initialized
INFO - 2018-05-11 23:14:56 --> Database Driver Class Initialized
INFO - 2018-05-11 23:14:56 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-11 23:14:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-05-11 23:14:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-11 23:14:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-05-11 23:14:56 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-11 23:14:56 --> Login MX_Controller Initialized
DEBUG - 2018-05-11 23:14:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-11 23:14:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-05-11 23:14:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-05-11 23:14:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-05-11 23:14:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-05-11 23:14:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-05-11 23:14:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/programs/create_program.php
INFO - 2018-05-11 23:14:57 --> Final output sent to browser
DEBUG - 2018-05-11 23:14:57 --> Total execution time: 1.2833
INFO - 2018-05-11 23:14:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-11 23:14:57 --> Email Class Initialized
INFO - 2018-05-11 23:14:57 --> Controller Class Initialized
DEBUG - 2018-05-11 23:14:57 --> Programs MX_Controller Initialized
INFO - 2018-05-11 23:14:57 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-11 23:14:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-05-11 23:14:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-11 23:14:57 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-11 23:14:57 --> Login MX_Controller Initialized
DEBUG - 2018-05-11 23:14:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-11 23:14:57 --> Final output sent to browser
DEBUG - 2018-05-11 23:14:57 --> Total execution time: 1.3839
INFO - 2018-05-11 23:14:57 --> Config Class Initialized
INFO - 2018-05-11 23:14:57 --> Hooks Class Initialized
DEBUG - 2018-05-11 23:14:57 --> UTF-8 Support Enabled
INFO - 2018-05-11 23:14:58 --> Utf8 Class Initialized
INFO - 2018-05-11 23:14:58 --> URI Class Initialized
INFO - 2018-05-11 23:14:58 --> Router Class Initialized
INFO - 2018-05-11 23:14:58 --> Output Class Initialized
INFO - 2018-05-11 23:14:58 --> Security Class Initialized
DEBUG - 2018-05-11 23:14:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 23:14:58 --> Input Class Initialized
INFO - 2018-05-11 23:14:58 --> Language Class Initialized
ERROR - 2018-05-11 23:14:58 --> 404 Page Not Found: /index
INFO - 2018-05-11 23:14:59 --> Config Class Initialized
INFO - 2018-05-11 23:14:59 --> Hooks Class Initialized
DEBUG - 2018-05-11 23:14:59 --> UTF-8 Support Enabled
INFO - 2018-05-11 23:14:59 --> Utf8 Class Initialized
INFO - 2018-05-11 23:14:59 --> URI Class Initialized
INFO - 2018-05-11 23:14:59 --> Router Class Initialized
INFO - 2018-05-11 23:14:59 --> Output Class Initialized
INFO - 2018-05-11 23:14:59 --> Security Class Initialized
DEBUG - 2018-05-11 23:14:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 23:14:59 --> Input Class Initialized
INFO - 2018-05-11 23:14:59 --> Language Class Initialized
INFO - 2018-05-11 23:14:59 --> Language Class Initialized
INFO - 2018-05-11 23:14:59 --> Config Class Initialized
INFO - 2018-05-11 23:14:59 --> Loader Class Initialized
DEBUG - 2018-05-11 23:14:59 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-11 23:14:59 --> Helper loaded: url_helper
INFO - 2018-05-11 23:14:59 --> Helper loaded: form_helper
INFO - 2018-05-11 23:14:59 --> Helper loaded: date_helper
INFO - 2018-05-11 23:14:59 --> Helper loaded: util_helper
INFO - 2018-05-11 23:14:59 --> Helper loaded: text_helper
INFO - 2018-05-11 23:14:59 --> Helper loaded: string_helper
INFO - 2018-05-11 23:14:59 --> Database Driver Class Initialized
DEBUG - 2018-05-11 23:14:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-11 23:14:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-11 23:14:59 --> Email Class Initialized
INFO - 2018-05-11 23:14:59 --> Controller Class Initialized
DEBUG - 2018-05-11 23:14:59 --> Programs MX_Controller Initialized
INFO - 2018-05-11 23:14:59 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-11 23:14:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-05-11 23:14:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-11 23:14:59 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-11 23:14:59 --> Login MX_Controller Initialized
DEBUG - 2018-05-11 23:14:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-11 23:14:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-05-11 23:14:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-05-11 23:14:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-05-11 23:14:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-05-11 23:14:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-05-11 23:14:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/programs/create_program.php
INFO - 2018-05-11 23:15:00 --> Final output sent to browser
DEBUG - 2018-05-11 23:15:00 --> Total execution time: 0.9114
INFO - 2018-05-11 23:15:00 --> Config Class Initialized
INFO - 2018-05-11 23:15:00 --> Hooks Class Initialized
DEBUG - 2018-05-11 23:15:00 --> UTF-8 Support Enabled
INFO - 2018-05-11 23:15:01 --> Utf8 Class Initialized
INFO - 2018-05-11 23:15:01 --> URI Class Initialized
INFO - 2018-05-11 23:15:01 --> Router Class Initialized
INFO - 2018-05-11 23:15:01 --> Output Class Initialized
INFO - 2018-05-11 23:15:01 --> Security Class Initialized
DEBUG - 2018-05-11 23:15:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 23:15:01 --> Input Class Initialized
INFO - 2018-05-11 23:15:01 --> Language Class Initialized
ERROR - 2018-05-11 23:15:01 --> 404 Page Not Found: /index
INFO - 2018-05-11 23:16:22 --> Config Class Initialized
INFO - 2018-05-11 23:16:22 --> Hooks Class Initialized
DEBUG - 2018-05-11 23:16:22 --> UTF-8 Support Enabled
INFO - 2018-05-11 23:16:22 --> Utf8 Class Initialized
INFO - 2018-05-11 23:16:22 --> URI Class Initialized
INFO - 2018-05-11 23:16:22 --> Router Class Initialized
INFO - 2018-05-11 23:16:22 --> Output Class Initialized
INFO - 2018-05-11 23:16:22 --> Security Class Initialized
DEBUG - 2018-05-11 23:16:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 23:16:22 --> Input Class Initialized
INFO - 2018-05-11 23:16:22 --> Language Class Initialized
INFO - 2018-05-11 23:16:22 --> Language Class Initialized
INFO - 2018-05-11 23:16:22 --> Config Class Initialized
INFO - 2018-05-11 23:16:22 --> Loader Class Initialized
DEBUG - 2018-05-11 23:16:22 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-11 23:16:22 --> Helper loaded: url_helper
INFO - 2018-05-11 23:16:22 --> Helper loaded: form_helper
INFO - 2018-05-11 23:16:22 --> Helper loaded: date_helper
INFO - 2018-05-11 23:16:22 --> Helper loaded: util_helper
INFO - 2018-05-11 23:16:22 --> Helper loaded: text_helper
INFO - 2018-05-11 23:16:22 --> Helper loaded: string_helper
INFO - 2018-05-11 23:16:22 --> Database Driver Class Initialized
DEBUG - 2018-05-11 23:16:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-11 23:16:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-11 23:16:22 --> Email Class Initialized
INFO - 2018-05-11 23:16:22 --> Controller Class Initialized
DEBUG - 2018-05-11 23:16:22 --> Programs MX_Controller Initialized
INFO - 2018-05-11 23:16:22 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-11 23:16:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-05-11 23:16:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-11 23:16:22 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-11 23:16:22 --> Login MX_Controller Initialized
DEBUG - 2018-05-11 23:16:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-11 23:16:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-05-11 23:16:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-05-11 23:16:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-05-11 23:16:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-05-11 23:16:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-05-11 23:16:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/programs/create_program.php
INFO - 2018-05-11 23:16:23 --> Final output sent to browser
DEBUG - 2018-05-11 23:16:23 --> Total execution time: 0.8626
INFO - 2018-05-11 23:16:23 --> Config Class Initialized
INFO - 2018-05-11 23:16:23 --> Hooks Class Initialized
DEBUG - 2018-05-11 23:16:24 --> UTF-8 Support Enabled
INFO - 2018-05-11 23:16:24 --> Utf8 Class Initialized
INFO - 2018-05-11 23:16:24 --> URI Class Initialized
INFO - 2018-05-11 23:16:24 --> Router Class Initialized
INFO - 2018-05-11 23:16:24 --> Output Class Initialized
INFO - 2018-05-11 23:16:24 --> Security Class Initialized
DEBUG - 2018-05-11 23:16:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 23:16:24 --> Input Class Initialized
INFO - 2018-05-11 23:16:24 --> Language Class Initialized
ERROR - 2018-05-11 23:16:24 --> 404 Page Not Found: /index
INFO - 2018-05-11 23:19:01 --> Config Class Initialized
INFO - 2018-05-11 23:19:01 --> Hooks Class Initialized
DEBUG - 2018-05-11 23:19:01 --> UTF-8 Support Enabled
INFO - 2018-05-11 23:19:01 --> Utf8 Class Initialized
INFO - 2018-05-11 23:19:01 --> URI Class Initialized
INFO - 2018-05-11 23:19:01 --> Router Class Initialized
INFO - 2018-05-11 23:19:01 --> Output Class Initialized
INFO - 2018-05-11 23:19:01 --> Security Class Initialized
DEBUG - 2018-05-11 23:19:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 23:19:01 --> Input Class Initialized
INFO - 2018-05-11 23:19:01 --> Language Class Initialized
INFO - 2018-05-11 23:19:01 --> Language Class Initialized
INFO - 2018-05-11 23:19:01 --> Config Class Initialized
INFO - 2018-05-11 23:19:01 --> Loader Class Initialized
DEBUG - 2018-05-11 23:19:01 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-11 23:19:01 --> Helper loaded: url_helper
INFO - 2018-05-11 23:19:01 --> Helper loaded: form_helper
INFO - 2018-05-11 23:19:01 --> Helper loaded: date_helper
INFO - 2018-05-11 23:19:02 --> Helper loaded: util_helper
INFO - 2018-05-11 23:19:02 --> Helper loaded: text_helper
INFO - 2018-05-11 23:19:02 --> Helper loaded: string_helper
INFO - 2018-05-11 23:19:02 --> Database Driver Class Initialized
DEBUG - 2018-05-11 23:19:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-11 23:19:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-11 23:19:02 --> Email Class Initialized
INFO - 2018-05-11 23:19:02 --> Controller Class Initialized
DEBUG - 2018-05-11 23:19:02 --> Programs MX_Controller Initialized
INFO - 2018-05-11 23:19:02 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-11 23:19:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-05-11 23:19:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-11 23:19:02 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-11 23:19:02 --> Login MX_Controller Initialized
DEBUG - 2018-05-11 23:19:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-11 23:19:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-05-11 23:19:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-05-11 23:19:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-05-11 23:19:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-05-11 23:19:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-05-11 23:19:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/programs/create_program.php
INFO - 2018-05-11 23:19:02 --> Final output sent to browser
DEBUG - 2018-05-11 23:19:02 --> Total execution time: 0.8814
INFO - 2018-05-11 23:19:03 --> Config Class Initialized
INFO - 2018-05-11 23:19:03 --> Hooks Class Initialized
DEBUG - 2018-05-11 23:19:03 --> UTF-8 Support Enabled
INFO - 2018-05-11 23:19:03 --> Utf8 Class Initialized
INFO - 2018-05-11 23:19:03 --> URI Class Initialized
INFO - 2018-05-11 23:19:03 --> Router Class Initialized
INFO - 2018-05-11 23:19:03 --> Output Class Initialized
INFO - 2018-05-11 23:19:03 --> Security Class Initialized
DEBUG - 2018-05-11 23:19:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 23:19:03 --> Input Class Initialized
INFO - 2018-05-11 23:19:03 --> Language Class Initialized
ERROR - 2018-05-11 23:19:03 --> 404 Page Not Found: /index
INFO - 2018-05-11 23:19:21 --> Config Class Initialized
INFO - 2018-05-11 23:19:21 --> Hooks Class Initialized
DEBUG - 2018-05-11 23:19:21 --> UTF-8 Support Enabled
INFO - 2018-05-11 23:19:21 --> Utf8 Class Initialized
INFO - 2018-05-11 23:19:21 --> URI Class Initialized
INFO - 2018-05-11 23:19:21 --> Router Class Initialized
INFO - 2018-05-11 23:19:21 --> Output Class Initialized
INFO - 2018-05-11 23:19:21 --> Security Class Initialized
DEBUG - 2018-05-11 23:19:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 23:19:21 --> Input Class Initialized
INFO - 2018-05-11 23:19:21 --> Language Class Initialized
INFO - 2018-05-11 23:19:21 --> Language Class Initialized
INFO - 2018-05-11 23:19:21 --> Config Class Initialized
INFO - 2018-05-11 23:19:21 --> Loader Class Initialized
DEBUG - 2018-05-11 23:19:21 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-11 23:19:21 --> Helper loaded: url_helper
INFO - 2018-05-11 23:19:21 --> Helper loaded: form_helper
INFO - 2018-05-11 23:19:21 --> Helper loaded: date_helper
INFO - 2018-05-11 23:19:21 --> Helper loaded: util_helper
INFO - 2018-05-11 23:19:21 --> Helper loaded: text_helper
INFO - 2018-05-11 23:19:21 --> Helper loaded: string_helper
INFO - 2018-05-11 23:19:21 --> Database Driver Class Initialized
DEBUG - 2018-05-11 23:19:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-11 23:19:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-11 23:19:21 --> Email Class Initialized
INFO - 2018-05-11 23:19:21 --> Controller Class Initialized
DEBUG - 2018-05-11 23:19:22 --> Company_types MX_Controller Initialized
INFO - 2018-05-11 23:19:22 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-11 23:19:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Company_types_model.php
DEBUG - 2018-05-11 23:19:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-11 23:19:22 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-11 23:19:22 --> Login MX_Controller Initialized
DEBUG - 2018-05-11 23:19:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
ERROR - 2018-05-11 23:19:22 --> Query error: Table 'consulting.company_types' doesn't exist - Invalid query: SELECT *
FROM `company_types`
WHERE `ct_name` IS NULL
INFO - 2018-05-11 23:19:22 --> Language file loaded: language/english/db_lang.php
INFO - 2018-05-11 23:20:01 --> Config Class Initialized
INFO - 2018-05-11 23:20:01 --> Hooks Class Initialized
DEBUG - 2018-05-11 23:20:01 --> UTF-8 Support Enabled
INFO - 2018-05-11 23:20:01 --> Utf8 Class Initialized
INFO - 2018-05-11 23:20:01 --> URI Class Initialized
INFO - 2018-05-11 23:20:01 --> Router Class Initialized
INFO - 2018-05-11 23:20:01 --> Output Class Initialized
INFO - 2018-05-11 23:20:02 --> Security Class Initialized
DEBUG - 2018-05-11 23:20:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 23:20:02 --> Input Class Initialized
INFO - 2018-05-11 23:20:02 --> Language Class Initialized
INFO - 2018-05-11 23:20:02 --> Language Class Initialized
INFO - 2018-05-11 23:20:02 --> Config Class Initialized
INFO - 2018-05-11 23:20:02 --> Loader Class Initialized
DEBUG - 2018-05-11 23:20:02 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-11 23:20:02 --> Helper loaded: url_helper
INFO - 2018-05-11 23:20:02 --> Helper loaded: form_helper
INFO - 2018-05-11 23:20:02 --> Helper loaded: date_helper
INFO - 2018-05-11 23:20:02 --> Helper loaded: util_helper
INFO - 2018-05-11 23:20:02 --> Helper loaded: text_helper
INFO - 2018-05-11 23:20:02 --> Helper loaded: string_helper
INFO - 2018-05-11 23:20:02 --> Database Driver Class Initialized
DEBUG - 2018-05-11 23:20:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-11 23:20:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-11 23:20:02 --> Email Class Initialized
INFO - 2018-05-11 23:20:02 --> Controller Class Initialized
DEBUG - 2018-05-11 23:20:02 --> Programs MX_Controller Initialized
INFO - 2018-05-11 23:20:02 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-11 23:20:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-05-11 23:20:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-11 23:20:02 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-11 23:20:02 --> Login MX_Controller Initialized
DEBUG - 2018-05-11 23:20:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-11 23:20:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-05-11 23:20:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-05-11 23:20:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-05-11 23:20:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-05-11 23:20:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-05-11 23:20:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/programs/create_program.php
INFO - 2018-05-11 23:20:02 --> Final output sent to browser
DEBUG - 2018-05-11 23:20:02 --> Total execution time: 0.8851
INFO - 2018-05-11 23:20:03 --> Config Class Initialized
INFO - 2018-05-11 23:20:03 --> Hooks Class Initialized
DEBUG - 2018-05-11 23:20:03 --> UTF-8 Support Enabled
INFO - 2018-05-11 23:20:03 --> Utf8 Class Initialized
INFO - 2018-05-11 23:20:03 --> URI Class Initialized
INFO - 2018-05-11 23:20:03 --> Router Class Initialized
INFO - 2018-05-11 23:20:03 --> Output Class Initialized
INFO - 2018-05-11 23:20:03 --> Security Class Initialized
DEBUG - 2018-05-11 23:20:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 23:20:03 --> Input Class Initialized
INFO - 2018-05-11 23:20:03 --> Language Class Initialized
ERROR - 2018-05-11 23:20:03 --> 404 Page Not Found: /index
INFO - 2018-05-11 23:20:15 --> Config Class Initialized
INFO - 2018-05-11 23:20:15 --> Hooks Class Initialized
DEBUG - 2018-05-11 23:20:15 --> UTF-8 Support Enabled
INFO - 2018-05-11 23:20:15 --> Utf8 Class Initialized
INFO - 2018-05-11 23:20:15 --> URI Class Initialized
INFO - 2018-05-11 23:20:15 --> Router Class Initialized
INFO - 2018-05-11 23:20:15 --> Output Class Initialized
INFO - 2018-05-11 23:20:15 --> Security Class Initialized
DEBUG - 2018-05-11 23:20:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 23:20:15 --> Input Class Initialized
INFO - 2018-05-11 23:20:15 --> Language Class Initialized
INFO - 2018-05-11 23:20:16 --> Language Class Initialized
INFO - 2018-05-11 23:20:16 --> Config Class Initialized
INFO - 2018-05-11 23:20:16 --> Loader Class Initialized
DEBUG - 2018-05-11 23:20:16 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-11 23:20:16 --> Helper loaded: url_helper
INFO - 2018-05-11 23:20:16 --> Helper loaded: form_helper
INFO - 2018-05-11 23:20:16 --> Helper loaded: date_helper
INFO - 2018-05-11 23:20:16 --> Helper loaded: util_helper
INFO - 2018-05-11 23:20:16 --> Helper loaded: text_helper
INFO - 2018-05-11 23:20:16 --> Helper loaded: string_helper
INFO - 2018-05-11 23:20:16 --> Database Driver Class Initialized
DEBUG - 2018-05-11 23:20:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-11 23:20:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-11 23:20:16 --> Email Class Initialized
INFO - 2018-05-11 23:20:16 --> Controller Class Initialized
DEBUG - 2018-05-11 23:20:16 --> Programs MX_Controller Initialized
INFO - 2018-05-11 23:20:16 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-11 23:20:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-05-11 23:20:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-11 23:20:16 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-11 23:20:16 --> Login MX_Controller Initialized
DEBUG - 2018-05-11 23:20:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-11 23:20:16 --> Config Class Initialized
INFO - 2018-05-11 23:20:16 --> Hooks Class Initialized
DEBUG - 2018-05-11 23:20:16 --> UTF-8 Support Enabled
INFO - 2018-05-11 23:20:16 --> Utf8 Class Initialized
INFO - 2018-05-11 23:20:16 --> URI Class Initialized
INFO - 2018-05-11 23:20:16 --> Router Class Initialized
INFO - 2018-05-11 23:20:16 --> Output Class Initialized
INFO - 2018-05-11 23:20:16 --> Security Class Initialized
DEBUG - 2018-05-11 23:20:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 23:20:16 --> Input Class Initialized
INFO - 2018-05-11 23:20:16 --> Language Class Initialized
INFO - 2018-05-11 23:20:16 --> Language Class Initialized
INFO - 2018-05-11 23:20:16 --> Config Class Initialized
INFO - 2018-05-11 23:20:17 --> Loader Class Initialized
DEBUG - 2018-05-11 23:20:17 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-11 23:20:17 --> Helper loaded: url_helper
INFO - 2018-05-11 23:20:17 --> Helper loaded: form_helper
INFO - 2018-05-11 23:20:17 --> Helper loaded: date_helper
INFO - 2018-05-11 23:20:17 --> Helper loaded: util_helper
INFO - 2018-05-11 23:20:17 --> Helper loaded: text_helper
INFO - 2018-05-11 23:20:17 --> Helper loaded: string_helper
INFO - 2018-05-11 23:20:17 --> Database Driver Class Initialized
DEBUG - 2018-05-11 23:20:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-11 23:20:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-11 23:20:17 --> Email Class Initialized
INFO - 2018-05-11 23:20:17 --> Controller Class Initialized
DEBUG - 2018-05-11 23:20:17 --> Programs MX_Controller Initialized
INFO - 2018-05-11 23:20:17 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-11 23:20:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-05-11 23:20:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-11 23:20:17 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-11 23:20:17 --> Login MX_Controller Initialized
DEBUG - 2018-05-11 23:20:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-11 23:20:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-05-11 23:20:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-05-11 23:20:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-05-11 23:20:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-05-11 23:20:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-05-11 23:20:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/programs/programs.php
INFO - 2018-05-11 23:20:17 --> Final output sent to browser
DEBUG - 2018-05-11 23:20:17 --> Total execution time: 1.0600
INFO - 2018-05-11 23:20:18 --> Config Class Initialized
INFO - 2018-05-11 23:20:18 --> Hooks Class Initialized
DEBUG - 2018-05-11 23:20:18 --> UTF-8 Support Enabled
INFO - 2018-05-11 23:20:18 --> Utf8 Class Initialized
INFO - 2018-05-11 23:20:18 --> URI Class Initialized
INFO - 2018-05-11 23:20:18 --> Router Class Initialized
INFO - 2018-05-11 23:20:18 --> Output Class Initialized
INFO - 2018-05-11 23:20:18 --> Security Class Initialized
DEBUG - 2018-05-11 23:20:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 23:20:18 --> Input Class Initialized
INFO - 2018-05-11 23:20:18 --> Language Class Initialized
INFO - 2018-05-11 23:20:18 --> Language Class Initialized
INFO - 2018-05-11 23:20:18 --> Config Class Initialized
INFO - 2018-05-11 23:20:18 --> Loader Class Initialized
DEBUG - 2018-05-11 23:20:18 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-11 23:20:18 --> Helper loaded: url_helper
INFO - 2018-05-11 23:20:18 --> Helper loaded: form_helper
INFO - 2018-05-11 23:20:18 --> Helper loaded: date_helper
INFO - 2018-05-11 23:20:18 --> Helper loaded: util_helper
INFO - 2018-05-11 23:20:18 --> Helper loaded: text_helper
INFO - 2018-05-11 23:20:18 --> Helper loaded: string_helper
INFO - 2018-05-11 23:20:19 --> Database Driver Class Initialized
DEBUG - 2018-05-11 23:20:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-11 23:20:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-11 23:20:19 --> Email Class Initialized
INFO - 2018-05-11 23:20:19 --> Controller Class Initialized
DEBUG - 2018-05-11 23:20:19 --> Programs MX_Controller Initialized
INFO - 2018-05-11 23:20:19 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-11 23:20:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-05-11 23:20:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-11 23:20:19 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-11 23:20:19 --> Login MX_Controller Initialized
DEBUG - 2018-05-11 23:20:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-11 23:20:19 --> Final output sent to browser
DEBUG - 2018-05-11 23:20:19 --> Total execution time: 0.8981
INFO - 2018-05-11 23:23:06 --> Config Class Initialized
INFO - 2018-05-11 23:23:06 --> Hooks Class Initialized
DEBUG - 2018-05-11 23:23:06 --> UTF-8 Support Enabled
INFO - 2018-05-11 23:23:06 --> Utf8 Class Initialized
INFO - 2018-05-11 23:23:06 --> URI Class Initialized
INFO - 2018-05-11 23:23:06 --> Router Class Initialized
INFO - 2018-05-11 23:23:06 --> Output Class Initialized
INFO - 2018-05-11 23:23:06 --> Security Class Initialized
DEBUG - 2018-05-11 23:23:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 23:23:06 --> Input Class Initialized
INFO - 2018-05-11 23:23:07 --> Language Class Initialized
INFO - 2018-05-11 23:23:07 --> Language Class Initialized
INFO - 2018-05-11 23:23:07 --> Config Class Initialized
INFO - 2018-05-11 23:23:07 --> Loader Class Initialized
DEBUG - 2018-05-11 23:23:07 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-11 23:23:07 --> Helper loaded: url_helper
INFO - 2018-05-11 23:23:07 --> Helper loaded: form_helper
INFO - 2018-05-11 23:23:07 --> Helper loaded: date_helper
INFO - 2018-05-11 23:23:07 --> Helper loaded: util_helper
INFO - 2018-05-11 23:23:07 --> Helper loaded: text_helper
INFO - 2018-05-11 23:23:07 --> Helper loaded: string_helper
INFO - 2018-05-11 23:23:07 --> Database Driver Class Initialized
DEBUG - 2018-05-11 23:23:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-11 23:23:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-11 23:23:07 --> Email Class Initialized
INFO - 2018-05-11 23:23:07 --> Controller Class Initialized
DEBUG - 2018-05-11 23:23:07 --> Programs MX_Controller Initialized
INFO - 2018-05-11 23:23:07 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-11 23:23:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-05-11 23:23:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-11 23:23:07 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-11 23:23:07 --> Login MX_Controller Initialized
DEBUG - 2018-05-11 23:23:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-11 23:23:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-05-11 23:23:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-05-11 23:23:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-05-11 23:23:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-05-11 23:23:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-05-11 23:23:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/programs/programs.php
INFO - 2018-05-11 23:23:07 --> Final output sent to browser
DEBUG - 2018-05-11 23:23:07 --> Total execution time: 0.8240
INFO - 2018-05-11 23:23:08 --> Config Class Initialized
INFO - 2018-05-11 23:23:08 --> Hooks Class Initialized
DEBUG - 2018-05-11 23:23:08 --> UTF-8 Support Enabled
INFO - 2018-05-11 23:23:08 --> Utf8 Class Initialized
INFO - 2018-05-11 23:23:08 --> URI Class Initialized
INFO - 2018-05-11 23:23:08 --> Router Class Initialized
INFO - 2018-05-11 23:23:08 --> Output Class Initialized
INFO - 2018-05-11 23:23:08 --> Security Class Initialized
DEBUG - 2018-05-11 23:23:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 23:23:09 --> Input Class Initialized
INFO - 2018-05-11 23:23:09 --> Language Class Initialized
INFO - 2018-05-11 23:23:09 --> Language Class Initialized
INFO - 2018-05-11 23:23:09 --> Config Class Initialized
INFO - 2018-05-11 23:23:09 --> Loader Class Initialized
DEBUG - 2018-05-11 23:23:09 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-11 23:23:09 --> Helper loaded: url_helper
INFO - 2018-05-11 23:23:09 --> Helper loaded: form_helper
INFO - 2018-05-11 23:23:09 --> Helper loaded: date_helper
INFO - 2018-05-11 23:23:09 --> Helper loaded: util_helper
INFO - 2018-05-11 23:23:09 --> Helper loaded: text_helper
INFO - 2018-05-11 23:23:09 --> Helper loaded: string_helper
INFO - 2018-05-11 23:23:09 --> Database Driver Class Initialized
DEBUG - 2018-05-11 23:23:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-11 23:23:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-11 23:23:09 --> Email Class Initialized
INFO - 2018-05-11 23:23:09 --> Controller Class Initialized
DEBUG - 2018-05-11 23:23:09 --> Programs MX_Controller Initialized
INFO - 2018-05-11 23:23:09 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-11 23:23:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-05-11 23:23:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-11 23:23:09 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-11 23:23:09 --> Login MX_Controller Initialized
DEBUG - 2018-05-11 23:23:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-11 23:23:09 --> Final output sent to browser
DEBUG - 2018-05-11 23:23:09 --> Total execution time: 0.9768
INFO - 2018-05-11 23:23:52 --> Config Class Initialized
INFO - 2018-05-11 23:23:52 --> Hooks Class Initialized
DEBUG - 2018-05-11 23:23:52 --> UTF-8 Support Enabled
INFO - 2018-05-11 23:23:52 --> Utf8 Class Initialized
INFO - 2018-05-11 23:23:52 --> URI Class Initialized
INFO - 2018-05-11 23:23:52 --> Router Class Initialized
INFO - 2018-05-11 23:23:52 --> Output Class Initialized
INFO - 2018-05-11 23:23:52 --> Security Class Initialized
DEBUG - 2018-05-11 23:23:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 23:23:52 --> Input Class Initialized
INFO - 2018-05-11 23:23:52 --> Language Class Initialized
INFO - 2018-05-11 23:23:52 --> Language Class Initialized
INFO - 2018-05-11 23:23:52 --> Config Class Initialized
INFO - 2018-05-11 23:23:52 --> Loader Class Initialized
DEBUG - 2018-05-11 23:23:52 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-11 23:23:52 --> Helper loaded: url_helper
INFO - 2018-05-11 23:23:52 --> Helper loaded: form_helper
INFO - 2018-05-11 23:23:52 --> Helper loaded: date_helper
INFO - 2018-05-11 23:23:52 --> Helper loaded: util_helper
INFO - 2018-05-11 23:23:52 --> Helper loaded: text_helper
INFO - 2018-05-11 23:23:52 --> Helper loaded: string_helper
INFO - 2018-05-11 23:23:52 --> Database Driver Class Initialized
DEBUG - 2018-05-11 23:23:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-11 23:23:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-11 23:23:52 --> Email Class Initialized
INFO - 2018-05-11 23:23:52 --> Controller Class Initialized
DEBUG - 2018-05-11 23:23:52 --> Programs MX_Controller Initialized
INFO - 2018-05-11 23:23:52 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-11 23:23:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-05-11 23:23:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-11 23:23:52 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-11 23:23:52 --> Login MX_Controller Initialized
DEBUG - 2018-05-11 23:23:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-11 23:23:53 --> Final output sent to browser
DEBUG - 2018-05-11 23:23:53 --> Total execution time: 0.7273
INFO - 2018-05-11 23:25:43 --> Config Class Initialized
INFO - 2018-05-11 23:25:43 --> Hooks Class Initialized
DEBUG - 2018-05-11 23:25:43 --> UTF-8 Support Enabled
INFO - 2018-05-11 23:25:43 --> Utf8 Class Initialized
INFO - 2018-05-11 23:25:43 --> URI Class Initialized
INFO - 2018-05-11 23:25:43 --> Router Class Initialized
INFO - 2018-05-11 23:25:43 --> Output Class Initialized
INFO - 2018-05-11 23:25:43 --> Security Class Initialized
DEBUG - 2018-05-11 23:25:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 23:25:43 --> Input Class Initialized
INFO - 2018-05-11 23:25:43 --> Language Class Initialized
INFO - 2018-05-11 23:25:43 --> Language Class Initialized
INFO - 2018-05-11 23:25:43 --> Config Class Initialized
INFO - 2018-05-11 23:25:43 --> Loader Class Initialized
DEBUG - 2018-05-11 23:25:43 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-11 23:25:43 --> Helper loaded: url_helper
INFO - 2018-05-11 23:25:44 --> Helper loaded: form_helper
INFO - 2018-05-11 23:25:44 --> Helper loaded: date_helper
INFO - 2018-05-11 23:25:44 --> Helper loaded: util_helper
INFO - 2018-05-11 23:25:44 --> Helper loaded: text_helper
INFO - 2018-05-11 23:25:44 --> Helper loaded: string_helper
INFO - 2018-05-11 23:25:44 --> Database Driver Class Initialized
DEBUG - 2018-05-11 23:25:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-11 23:25:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-11 23:25:44 --> Email Class Initialized
INFO - 2018-05-11 23:25:44 --> Controller Class Initialized
DEBUG - 2018-05-11 23:25:44 --> Programs MX_Controller Initialized
INFO - 2018-05-11 23:25:44 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-11 23:25:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-05-11 23:25:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-11 23:25:44 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-11 23:25:44 --> Login MX_Controller Initialized
DEBUG - 2018-05-11 23:25:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-11 23:25:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-05-11 23:25:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-05-11 23:25:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-05-11 23:25:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-05-11 23:25:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-05-11 23:25:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/programs/create_program.php
INFO - 2018-05-11 23:25:44 --> Final output sent to browser
DEBUG - 2018-05-11 23:25:44 --> Total execution time: 0.8285
INFO - 2018-05-11 23:25:45 --> Config Class Initialized
INFO - 2018-05-11 23:25:45 --> Hooks Class Initialized
DEBUG - 2018-05-11 23:25:45 --> UTF-8 Support Enabled
INFO - 2018-05-11 23:25:45 --> Utf8 Class Initialized
INFO - 2018-05-11 23:25:45 --> URI Class Initialized
INFO - 2018-05-11 23:25:45 --> Router Class Initialized
INFO - 2018-05-11 23:25:45 --> Output Class Initialized
INFO - 2018-05-11 23:25:45 --> Security Class Initialized
DEBUG - 2018-05-11 23:25:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 23:25:45 --> Input Class Initialized
INFO - 2018-05-11 23:25:45 --> Language Class Initialized
ERROR - 2018-05-11 23:25:45 --> 404 Page Not Found: /index
INFO - 2018-05-11 23:28:29 --> Config Class Initialized
INFO - 2018-05-11 23:28:29 --> Hooks Class Initialized
DEBUG - 2018-05-11 23:28:29 --> UTF-8 Support Enabled
INFO - 2018-05-11 23:28:29 --> Utf8 Class Initialized
INFO - 2018-05-11 23:28:29 --> URI Class Initialized
INFO - 2018-05-11 23:28:29 --> Router Class Initialized
INFO - 2018-05-11 23:28:29 --> Output Class Initialized
INFO - 2018-05-11 23:28:29 --> Security Class Initialized
DEBUG - 2018-05-11 23:28:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 23:28:29 --> Input Class Initialized
INFO - 2018-05-11 23:28:29 --> Language Class Initialized
INFO - 2018-05-11 23:28:29 --> Language Class Initialized
INFO - 2018-05-11 23:28:29 --> Config Class Initialized
INFO - 2018-05-11 23:28:29 --> Loader Class Initialized
DEBUG - 2018-05-11 23:28:29 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-11 23:28:29 --> Helper loaded: url_helper
INFO - 2018-05-11 23:28:29 --> Helper loaded: form_helper
INFO - 2018-05-11 23:28:29 --> Helper loaded: date_helper
INFO - 2018-05-11 23:28:29 --> Helper loaded: util_helper
INFO - 2018-05-11 23:28:29 --> Helper loaded: text_helper
INFO - 2018-05-11 23:28:29 --> Helper loaded: string_helper
INFO - 2018-05-11 23:28:29 --> Database Driver Class Initialized
DEBUG - 2018-05-11 23:28:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-11 23:28:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-11 23:28:29 --> Email Class Initialized
INFO - 2018-05-11 23:28:29 --> Controller Class Initialized
DEBUG - 2018-05-11 23:28:29 --> Programs MX_Controller Initialized
INFO - 2018-05-11 23:28:29 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-11 23:28:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-05-11 23:28:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-11 23:28:30 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-11 23:28:30 --> Login MX_Controller Initialized
DEBUG - 2018-05-11 23:28:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-11 23:28:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-05-11 23:28:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-05-11 23:28:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-05-11 23:28:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-05-11 23:28:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-05-11 23:28:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/programs/create_program.php
INFO - 2018-05-11 23:28:30 --> Final output sent to browser
DEBUG - 2018-05-11 23:28:30 --> Total execution time: 0.9040
INFO - 2018-05-11 23:28:31 --> Config Class Initialized
INFO - 2018-05-11 23:28:31 --> Hooks Class Initialized
DEBUG - 2018-05-11 23:28:31 --> UTF-8 Support Enabled
INFO - 2018-05-11 23:28:31 --> Utf8 Class Initialized
INFO - 2018-05-11 23:28:31 --> URI Class Initialized
INFO - 2018-05-11 23:28:31 --> Router Class Initialized
INFO - 2018-05-11 23:28:31 --> Output Class Initialized
INFO - 2018-05-11 23:28:31 --> Security Class Initialized
DEBUG - 2018-05-11 23:28:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 23:28:31 --> Input Class Initialized
INFO - 2018-05-11 23:28:31 --> Language Class Initialized
ERROR - 2018-05-11 23:28:31 --> 404 Page Not Found: /index
INFO - 2018-05-11 23:28:47 --> Config Class Initialized
INFO - 2018-05-11 23:28:47 --> Hooks Class Initialized
DEBUG - 2018-05-11 23:28:47 --> UTF-8 Support Enabled
INFO - 2018-05-11 23:28:47 --> Utf8 Class Initialized
INFO - 2018-05-11 23:28:47 --> URI Class Initialized
INFO - 2018-05-11 23:28:47 --> Router Class Initialized
INFO - 2018-05-11 23:28:47 --> Output Class Initialized
INFO - 2018-05-11 23:28:47 --> Security Class Initialized
DEBUG - 2018-05-11 23:28:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 23:28:48 --> Input Class Initialized
INFO - 2018-05-11 23:28:48 --> Language Class Initialized
INFO - 2018-05-11 23:28:48 --> Language Class Initialized
INFO - 2018-05-11 23:28:48 --> Config Class Initialized
INFO - 2018-05-11 23:28:48 --> Loader Class Initialized
DEBUG - 2018-05-11 23:28:48 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-11 23:28:48 --> Helper loaded: url_helper
INFO - 2018-05-11 23:28:48 --> Helper loaded: form_helper
INFO - 2018-05-11 23:28:48 --> Helper loaded: date_helper
INFO - 2018-05-11 23:28:48 --> Helper loaded: util_helper
INFO - 2018-05-11 23:28:48 --> Helper loaded: text_helper
INFO - 2018-05-11 23:28:48 --> Helper loaded: string_helper
INFO - 2018-05-11 23:28:48 --> Database Driver Class Initialized
DEBUG - 2018-05-11 23:28:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-11 23:28:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-11 23:28:48 --> Email Class Initialized
INFO - 2018-05-11 23:28:48 --> Controller Class Initialized
DEBUG - 2018-05-11 23:28:48 --> Programs MX_Controller Initialized
INFO - 2018-05-11 23:28:48 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-11 23:28:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-05-11 23:28:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-11 23:28:48 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-11 23:28:48 --> Login MX_Controller Initialized
DEBUG - 2018-05-11 23:28:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-11 23:28:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-05-11 23:28:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-05-11 23:28:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-05-11 23:28:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-05-11 23:28:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-05-11 23:28:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/programs/create_program.php
INFO - 2018-05-11 23:28:48 --> Final output sent to browser
DEBUG - 2018-05-11 23:28:48 --> Total execution time: 0.9115
INFO - 2018-05-11 23:28:49 --> Config Class Initialized
INFO - 2018-05-11 23:28:49 --> Hooks Class Initialized
DEBUG - 2018-05-11 23:28:49 --> UTF-8 Support Enabled
INFO - 2018-05-11 23:28:49 --> Utf8 Class Initialized
INFO - 2018-05-11 23:28:50 --> URI Class Initialized
INFO - 2018-05-11 23:28:50 --> Router Class Initialized
INFO - 2018-05-11 23:28:50 --> Output Class Initialized
INFO - 2018-05-11 23:28:50 --> Security Class Initialized
DEBUG - 2018-05-11 23:28:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 23:28:50 --> Input Class Initialized
INFO - 2018-05-11 23:28:50 --> Language Class Initialized
ERROR - 2018-05-11 23:28:50 --> 404 Page Not Found: /index
INFO - 2018-05-11 23:28:59 --> Config Class Initialized
INFO - 2018-05-11 23:28:59 --> Hooks Class Initialized
DEBUG - 2018-05-11 23:28:59 --> UTF-8 Support Enabled
INFO - 2018-05-11 23:28:59 --> Utf8 Class Initialized
INFO - 2018-05-11 23:28:59 --> URI Class Initialized
INFO - 2018-05-11 23:28:59 --> Router Class Initialized
INFO - 2018-05-11 23:28:59 --> Output Class Initialized
INFO - 2018-05-11 23:28:59 --> Security Class Initialized
DEBUG - 2018-05-11 23:28:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 23:28:59 --> Input Class Initialized
INFO - 2018-05-11 23:28:59 --> Language Class Initialized
INFO - 2018-05-11 23:28:59 --> Language Class Initialized
INFO - 2018-05-11 23:28:59 --> Config Class Initialized
INFO - 2018-05-11 23:28:59 --> Loader Class Initialized
DEBUG - 2018-05-11 23:28:59 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-11 23:28:59 --> Helper loaded: url_helper
INFO - 2018-05-11 23:28:59 --> Helper loaded: form_helper
INFO - 2018-05-11 23:28:59 --> Helper loaded: date_helper
INFO - 2018-05-11 23:28:59 --> Helper loaded: util_helper
INFO - 2018-05-11 23:28:59 --> Helper loaded: text_helper
INFO - 2018-05-11 23:28:59 --> Helper loaded: string_helper
INFO - 2018-05-11 23:28:59 --> Database Driver Class Initialized
DEBUG - 2018-05-11 23:28:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-11 23:28:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-11 23:28:59 --> Email Class Initialized
INFO - 2018-05-11 23:28:59 --> Controller Class Initialized
DEBUG - 2018-05-11 23:28:59 --> Programs MX_Controller Initialized
INFO - 2018-05-11 23:28:59 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-11 23:28:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-05-11 23:28:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-11 23:28:59 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-11 23:28:59 --> Login MX_Controller Initialized
DEBUG - 2018-05-11 23:28:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-11 23:28:59 --> Config Class Initialized
INFO - 2018-05-11 23:28:59 --> Hooks Class Initialized
DEBUG - 2018-05-11 23:28:59 --> UTF-8 Support Enabled
INFO - 2018-05-11 23:28:59 --> Utf8 Class Initialized
INFO - 2018-05-11 23:28:59 --> URI Class Initialized
INFO - 2018-05-11 23:28:59 --> Router Class Initialized
INFO - 2018-05-11 23:28:59 --> Output Class Initialized
INFO - 2018-05-11 23:28:59 --> Security Class Initialized
DEBUG - 2018-05-11 23:28:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 23:28:59 --> Input Class Initialized
INFO - 2018-05-11 23:28:59 --> Language Class Initialized
INFO - 2018-05-11 23:28:59 --> Language Class Initialized
INFO - 2018-05-11 23:29:00 --> Config Class Initialized
INFO - 2018-05-11 23:29:00 --> Loader Class Initialized
DEBUG - 2018-05-11 23:29:00 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-11 23:29:00 --> Helper loaded: url_helper
INFO - 2018-05-11 23:29:00 --> Helper loaded: form_helper
INFO - 2018-05-11 23:29:00 --> Helper loaded: date_helper
INFO - 2018-05-11 23:29:00 --> Helper loaded: util_helper
INFO - 2018-05-11 23:29:00 --> Helper loaded: text_helper
INFO - 2018-05-11 23:29:00 --> Helper loaded: string_helper
INFO - 2018-05-11 23:29:00 --> Database Driver Class Initialized
DEBUG - 2018-05-11 23:29:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-11 23:29:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-11 23:29:00 --> Email Class Initialized
INFO - 2018-05-11 23:29:00 --> Controller Class Initialized
DEBUG - 2018-05-11 23:29:00 --> Programs MX_Controller Initialized
INFO - 2018-05-11 23:29:00 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-11 23:29:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-05-11 23:29:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-11 23:29:00 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-11 23:29:00 --> Login MX_Controller Initialized
DEBUG - 2018-05-11 23:29:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-11 23:29:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-05-11 23:29:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-05-11 23:29:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-05-11 23:29:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-05-11 23:29:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-05-11 23:29:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/programs/programs.php
INFO - 2018-05-11 23:29:00 --> Final output sent to browser
DEBUG - 2018-05-11 23:29:00 --> Total execution time: 0.8749
INFO - 2018-05-11 23:29:01 --> Config Class Initialized
INFO - 2018-05-11 23:29:01 --> Hooks Class Initialized
DEBUG - 2018-05-11 23:29:01 --> UTF-8 Support Enabled
INFO - 2018-05-11 23:29:01 --> Utf8 Class Initialized
INFO - 2018-05-11 23:29:01 --> URI Class Initialized
INFO - 2018-05-11 23:29:01 --> Router Class Initialized
INFO - 2018-05-11 23:29:01 --> Output Class Initialized
INFO - 2018-05-11 23:29:01 --> Security Class Initialized
DEBUG - 2018-05-11 23:29:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 23:29:01 --> Input Class Initialized
INFO - 2018-05-11 23:29:01 --> Language Class Initialized
INFO - 2018-05-11 23:29:01 --> Language Class Initialized
INFO - 2018-05-11 23:29:01 --> Config Class Initialized
INFO - 2018-05-11 23:29:01 --> Loader Class Initialized
DEBUG - 2018-05-11 23:29:01 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-11 23:29:01 --> Helper loaded: url_helper
INFO - 2018-05-11 23:29:01 --> Helper loaded: form_helper
INFO - 2018-05-11 23:29:01 --> Helper loaded: date_helper
INFO - 2018-05-11 23:29:01 --> Helper loaded: util_helper
INFO - 2018-05-11 23:29:01 --> Helper loaded: text_helper
INFO - 2018-05-11 23:29:01 --> Helper loaded: string_helper
INFO - 2018-05-11 23:29:01 --> Database Driver Class Initialized
DEBUG - 2018-05-11 23:29:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-11 23:29:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-11 23:29:01 --> Email Class Initialized
INFO - 2018-05-11 23:29:02 --> Controller Class Initialized
DEBUG - 2018-05-11 23:29:02 --> Programs MX_Controller Initialized
INFO - 2018-05-11 23:29:02 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-11 23:29:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-05-11 23:29:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-11 23:29:02 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-11 23:29:02 --> Login MX_Controller Initialized
DEBUG - 2018-05-11 23:29:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-11 23:29:02 --> Final output sent to browser
DEBUG - 2018-05-11 23:29:02 --> Total execution time: 0.9417
INFO - 2018-05-11 23:31:31 --> Config Class Initialized
INFO - 2018-05-11 23:31:31 --> Hooks Class Initialized
DEBUG - 2018-05-11 23:31:31 --> UTF-8 Support Enabled
INFO - 2018-05-11 23:31:31 --> Utf8 Class Initialized
INFO - 2018-05-11 23:31:31 --> URI Class Initialized
INFO - 2018-05-11 23:31:31 --> Router Class Initialized
INFO - 2018-05-11 23:31:31 --> Output Class Initialized
INFO - 2018-05-11 23:31:31 --> Security Class Initialized
DEBUG - 2018-05-11 23:31:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 23:31:32 --> Input Class Initialized
INFO - 2018-05-11 23:31:32 --> Language Class Initialized
INFO - 2018-05-11 23:31:32 --> Language Class Initialized
INFO - 2018-05-11 23:31:32 --> Config Class Initialized
INFO - 2018-05-11 23:31:32 --> Loader Class Initialized
DEBUG - 2018-05-11 23:31:32 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-11 23:31:32 --> Helper loaded: url_helper
INFO - 2018-05-11 23:31:32 --> Helper loaded: form_helper
INFO - 2018-05-11 23:31:32 --> Helper loaded: date_helper
INFO - 2018-05-11 23:31:32 --> Helper loaded: util_helper
INFO - 2018-05-11 23:31:32 --> Helper loaded: text_helper
INFO - 2018-05-11 23:31:32 --> Helper loaded: string_helper
INFO - 2018-05-11 23:31:32 --> Database Driver Class Initialized
DEBUG - 2018-05-11 23:31:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-11 23:31:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-11 23:31:32 --> Email Class Initialized
INFO - 2018-05-11 23:31:32 --> Controller Class Initialized
DEBUG - 2018-05-11 23:31:32 --> Programs MX_Controller Initialized
INFO - 2018-05-11 23:31:32 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-11 23:31:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-05-11 23:31:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-11 23:31:32 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-11 23:31:32 --> Login MX_Controller Initialized
DEBUG - 2018-05-11 23:31:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-11 23:31:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-05-11 23:31:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-05-11 23:31:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-05-11 23:31:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-05-11 23:31:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-05-11 23:31:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/programs/create_program.php
INFO - 2018-05-11 23:31:32 --> Final output sent to browser
DEBUG - 2018-05-11 23:31:32 --> Total execution time: 0.8127
INFO - 2018-05-11 23:32:07 --> Config Class Initialized
INFO - 2018-05-11 23:32:07 --> Hooks Class Initialized
DEBUG - 2018-05-11 23:32:07 --> UTF-8 Support Enabled
INFO - 2018-05-11 23:32:07 --> Utf8 Class Initialized
INFO - 2018-05-11 23:32:07 --> URI Class Initialized
INFO - 2018-05-11 23:32:07 --> Router Class Initialized
INFO - 2018-05-11 23:32:07 --> Output Class Initialized
INFO - 2018-05-11 23:32:07 --> Security Class Initialized
DEBUG - 2018-05-11 23:32:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 23:32:07 --> Input Class Initialized
INFO - 2018-05-11 23:32:07 --> Language Class Initialized
INFO - 2018-05-11 23:32:07 --> Language Class Initialized
INFO - 2018-05-11 23:32:07 --> Config Class Initialized
INFO - 2018-05-11 23:32:07 --> Loader Class Initialized
DEBUG - 2018-05-11 23:32:07 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-11 23:32:07 --> Helper loaded: url_helper
INFO - 2018-05-11 23:32:07 --> Helper loaded: form_helper
INFO - 2018-05-11 23:32:07 --> Helper loaded: date_helper
INFO - 2018-05-11 23:32:07 --> Helper loaded: util_helper
INFO - 2018-05-11 23:32:07 --> Helper loaded: text_helper
INFO - 2018-05-11 23:32:07 --> Helper loaded: string_helper
INFO - 2018-05-11 23:32:07 --> Database Driver Class Initialized
DEBUG - 2018-05-11 23:32:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-11 23:32:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-11 23:32:07 --> Email Class Initialized
INFO - 2018-05-11 23:32:07 --> Controller Class Initialized
DEBUG - 2018-05-11 23:32:07 --> Programs MX_Controller Initialized
INFO - 2018-05-11 23:32:07 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-11 23:32:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-05-11 23:32:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-11 23:32:08 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-11 23:32:08 --> Login MX_Controller Initialized
DEBUG - 2018-05-11 23:32:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-11 23:32:11 --> Config Class Initialized
INFO - 2018-05-11 23:32:11 --> Hooks Class Initialized
DEBUG - 2018-05-11 23:32:11 --> UTF-8 Support Enabled
INFO - 2018-05-11 23:32:11 --> Utf8 Class Initialized
INFO - 2018-05-11 23:32:11 --> URI Class Initialized
INFO - 2018-05-11 23:32:11 --> Router Class Initialized
INFO - 2018-05-11 23:32:11 --> Output Class Initialized
INFO - 2018-05-11 23:32:11 --> Security Class Initialized
DEBUG - 2018-05-11 23:32:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 23:32:11 --> Input Class Initialized
INFO - 2018-05-11 23:32:11 --> Language Class Initialized
ERROR - 2018-05-11 23:32:11 --> 404 Page Not Found: /index
INFO - 2018-05-11 23:32:15 --> Config Class Initialized
INFO - 2018-05-11 23:32:15 --> Hooks Class Initialized
DEBUG - 2018-05-11 23:32:15 --> UTF-8 Support Enabled
INFO - 2018-05-11 23:32:15 --> Utf8 Class Initialized
INFO - 2018-05-11 23:32:15 --> URI Class Initialized
INFO - 2018-05-11 23:32:15 --> Router Class Initialized
INFO - 2018-05-11 23:32:15 --> Output Class Initialized
INFO - 2018-05-11 23:32:15 --> Security Class Initialized
DEBUG - 2018-05-11 23:32:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 23:32:15 --> Input Class Initialized
INFO - 2018-05-11 23:32:15 --> Language Class Initialized
INFO - 2018-05-11 23:32:15 --> Language Class Initialized
INFO - 2018-05-11 23:32:15 --> Config Class Initialized
INFO - 2018-05-11 23:32:15 --> Loader Class Initialized
DEBUG - 2018-05-11 23:32:15 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-11 23:32:15 --> Helper loaded: url_helper
INFO - 2018-05-11 23:32:15 --> Helper loaded: form_helper
INFO - 2018-05-11 23:32:15 --> Helper loaded: date_helper
INFO - 2018-05-11 23:32:15 --> Helper loaded: util_helper
INFO - 2018-05-11 23:32:15 --> Helper loaded: text_helper
INFO - 2018-05-11 23:32:15 --> Helper loaded: string_helper
INFO - 2018-05-11 23:32:15 --> Database Driver Class Initialized
DEBUG - 2018-05-11 23:32:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-11 23:32:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-11 23:32:15 --> Email Class Initialized
INFO - 2018-05-11 23:32:15 --> Controller Class Initialized
DEBUG - 2018-05-11 23:32:15 --> Programs MX_Controller Initialized
INFO - 2018-05-11 23:32:15 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-11 23:32:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-05-11 23:32:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-11 23:32:15 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-11 23:32:15 --> Login MX_Controller Initialized
DEBUG - 2018-05-11 23:32:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-11 23:32:24 --> Config Class Initialized
INFO - 2018-05-11 23:32:24 --> Hooks Class Initialized
DEBUG - 2018-05-11 23:32:24 --> UTF-8 Support Enabled
INFO - 2018-05-11 23:32:24 --> Utf8 Class Initialized
INFO - 2018-05-11 23:32:24 --> URI Class Initialized
INFO - 2018-05-11 23:32:24 --> Router Class Initialized
INFO - 2018-05-11 23:32:24 --> Output Class Initialized
INFO - 2018-05-11 23:32:24 --> Security Class Initialized
DEBUG - 2018-05-11 23:32:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 23:32:24 --> Input Class Initialized
INFO - 2018-05-11 23:32:24 --> Language Class Initialized
INFO - 2018-05-11 23:32:24 --> Language Class Initialized
INFO - 2018-05-11 23:32:24 --> Config Class Initialized
INFO - 2018-05-11 23:32:24 --> Loader Class Initialized
DEBUG - 2018-05-11 23:32:24 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-11 23:32:24 --> Helper loaded: url_helper
INFO - 2018-05-11 23:32:24 --> Helper loaded: form_helper
INFO - 2018-05-11 23:32:25 --> Helper loaded: date_helper
INFO - 2018-05-11 23:32:25 --> Helper loaded: util_helper
INFO - 2018-05-11 23:32:25 --> Helper loaded: text_helper
INFO - 2018-05-11 23:32:25 --> Helper loaded: string_helper
INFO - 2018-05-11 23:32:25 --> Database Driver Class Initialized
DEBUG - 2018-05-11 23:32:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-11 23:32:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-11 23:32:25 --> Email Class Initialized
INFO - 2018-05-11 23:32:25 --> Controller Class Initialized
DEBUG - 2018-05-11 23:32:25 --> Programs MX_Controller Initialized
INFO - 2018-05-11 23:32:25 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-11 23:32:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-05-11 23:32:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-11 23:32:25 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-11 23:32:25 --> Login MX_Controller Initialized
DEBUG - 2018-05-11 23:32:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-11 23:33:33 --> Config Class Initialized
INFO - 2018-05-11 23:33:33 --> Hooks Class Initialized
DEBUG - 2018-05-11 23:33:33 --> UTF-8 Support Enabled
INFO - 2018-05-11 23:33:33 --> Utf8 Class Initialized
INFO - 2018-05-11 23:33:33 --> URI Class Initialized
INFO - 2018-05-11 23:33:33 --> Router Class Initialized
INFO - 2018-05-11 23:33:33 --> Output Class Initialized
INFO - 2018-05-11 23:33:33 --> Security Class Initialized
DEBUG - 2018-05-11 23:33:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 23:33:33 --> Input Class Initialized
INFO - 2018-05-11 23:33:33 --> Language Class Initialized
INFO - 2018-05-11 23:33:33 --> Language Class Initialized
INFO - 2018-05-11 23:33:33 --> Config Class Initialized
INFO - 2018-05-11 23:33:33 --> Loader Class Initialized
DEBUG - 2018-05-11 23:33:33 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-11 23:33:33 --> Helper loaded: url_helper
INFO - 2018-05-11 23:33:33 --> Helper loaded: form_helper
INFO - 2018-05-11 23:33:34 --> Helper loaded: date_helper
INFO - 2018-05-11 23:33:34 --> Helper loaded: util_helper
INFO - 2018-05-11 23:33:34 --> Helper loaded: text_helper
INFO - 2018-05-11 23:33:34 --> Helper loaded: string_helper
INFO - 2018-05-11 23:33:34 --> Database Driver Class Initialized
DEBUG - 2018-05-11 23:33:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-11 23:33:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-11 23:33:34 --> Email Class Initialized
INFO - 2018-05-11 23:33:34 --> Controller Class Initialized
DEBUG - 2018-05-11 23:33:34 --> Programs MX_Controller Initialized
INFO - 2018-05-11 23:33:34 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-11 23:33:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-05-11 23:33:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-11 23:33:34 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-11 23:33:34 --> Login MX_Controller Initialized
DEBUG - 2018-05-11 23:33:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-11 23:33:45 --> Config Class Initialized
INFO - 2018-05-11 23:33:45 --> Hooks Class Initialized
DEBUG - 2018-05-11 23:33:45 --> UTF-8 Support Enabled
INFO - 2018-05-11 23:33:45 --> Utf8 Class Initialized
INFO - 2018-05-11 23:33:45 --> URI Class Initialized
INFO - 2018-05-11 23:33:45 --> Router Class Initialized
INFO - 2018-05-11 23:33:45 --> Output Class Initialized
INFO - 2018-05-11 23:33:45 --> Security Class Initialized
DEBUG - 2018-05-11 23:33:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 23:33:45 --> Input Class Initialized
INFO - 2018-05-11 23:33:45 --> Language Class Initialized
INFO - 2018-05-11 23:33:45 --> Language Class Initialized
INFO - 2018-05-11 23:33:45 --> Config Class Initialized
INFO - 2018-05-11 23:33:45 --> Loader Class Initialized
DEBUG - 2018-05-11 23:33:45 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-11 23:33:45 --> Helper loaded: url_helper
INFO - 2018-05-11 23:33:45 --> Helper loaded: form_helper
INFO - 2018-05-11 23:33:45 --> Helper loaded: date_helper
INFO - 2018-05-11 23:33:45 --> Helper loaded: util_helper
INFO - 2018-05-11 23:33:45 --> Helper loaded: text_helper
INFO - 2018-05-11 23:33:45 --> Helper loaded: string_helper
INFO - 2018-05-11 23:33:45 --> Database Driver Class Initialized
DEBUG - 2018-05-11 23:33:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-11 23:33:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-11 23:33:45 --> Email Class Initialized
INFO - 2018-05-11 23:33:45 --> Controller Class Initialized
DEBUG - 2018-05-11 23:33:45 --> Programs MX_Controller Initialized
INFO - 2018-05-11 23:33:45 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-11 23:33:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-05-11 23:33:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-11 23:33:46 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-11 23:33:46 --> Login MX_Controller Initialized
DEBUG - 2018-05-11 23:33:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-11 23:33:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-05-11 23:33:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-05-11 23:33:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-05-11 23:33:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-05-11 23:33:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-05-11 23:33:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/programs/create_program.php
INFO - 2018-05-11 23:33:46 --> Final output sent to browser
DEBUG - 2018-05-11 23:33:46 --> Total execution time: 0.8625
INFO - 2018-05-11 23:33:46 --> Config Class Initialized
INFO - 2018-05-11 23:33:47 --> Hooks Class Initialized
DEBUG - 2018-05-11 23:33:47 --> UTF-8 Support Enabled
INFO - 2018-05-11 23:33:47 --> Utf8 Class Initialized
INFO - 2018-05-11 23:33:47 --> URI Class Initialized
INFO - 2018-05-11 23:33:47 --> Router Class Initialized
INFO - 2018-05-11 23:33:47 --> Output Class Initialized
INFO - 2018-05-11 23:33:47 --> Security Class Initialized
DEBUG - 2018-05-11 23:33:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 23:33:47 --> Input Class Initialized
INFO - 2018-05-11 23:33:47 --> Language Class Initialized
ERROR - 2018-05-11 23:33:47 --> 404 Page Not Found: /index
INFO - 2018-05-11 23:35:21 --> Config Class Initialized
INFO - 2018-05-11 23:35:21 --> Hooks Class Initialized
DEBUG - 2018-05-11 23:35:21 --> UTF-8 Support Enabled
INFO - 2018-05-11 23:35:21 --> Utf8 Class Initialized
INFO - 2018-05-11 23:35:21 --> URI Class Initialized
INFO - 2018-05-11 23:35:21 --> Router Class Initialized
INFO - 2018-05-11 23:35:21 --> Output Class Initialized
INFO - 2018-05-11 23:35:21 --> Security Class Initialized
DEBUG - 2018-05-11 23:35:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 23:35:21 --> Input Class Initialized
INFO - 2018-05-11 23:35:21 --> Language Class Initialized
INFO - 2018-05-11 23:35:21 --> Language Class Initialized
INFO - 2018-05-11 23:35:21 --> Config Class Initialized
INFO - 2018-05-11 23:35:21 --> Loader Class Initialized
DEBUG - 2018-05-11 23:35:21 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-11 23:35:21 --> Helper loaded: url_helper
INFO - 2018-05-11 23:35:21 --> Helper loaded: form_helper
INFO - 2018-05-11 23:35:21 --> Helper loaded: date_helper
INFO - 2018-05-11 23:35:21 --> Helper loaded: util_helper
INFO - 2018-05-11 23:35:21 --> Helper loaded: text_helper
INFO - 2018-05-11 23:35:21 --> Helper loaded: string_helper
INFO - 2018-05-11 23:35:21 --> Database Driver Class Initialized
DEBUG - 2018-05-11 23:35:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-11 23:35:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-11 23:35:21 --> Email Class Initialized
INFO - 2018-05-11 23:35:21 --> Controller Class Initialized
DEBUG - 2018-05-11 23:35:21 --> Programs MX_Controller Initialized
INFO - 2018-05-11 23:35:21 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-11 23:35:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-05-11 23:35:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-11 23:35:22 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-11 23:35:22 --> Login MX_Controller Initialized
DEBUG - 2018-05-11 23:35:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-11 23:36:03 --> Config Class Initialized
INFO - 2018-05-11 23:36:04 --> Hooks Class Initialized
DEBUG - 2018-05-11 23:36:04 --> UTF-8 Support Enabled
INFO - 2018-05-11 23:36:04 --> Utf8 Class Initialized
INFO - 2018-05-11 23:36:04 --> URI Class Initialized
INFO - 2018-05-11 23:36:04 --> Router Class Initialized
INFO - 2018-05-11 23:36:04 --> Output Class Initialized
INFO - 2018-05-11 23:36:04 --> Security Class Initialized
DEBUG - 2018-05-11 23:36:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 23:36:04 --> Input Class Initialized
INFO - 2018-05-11 23:36:04 --> Language Class Initialized
INFO - 2018-05-11 23:36:04 --> Language Class Initialized
INFO - 2018-05-11 23:36:04 --> Config Class Initialized
INFO - 2018-05-11 23:36:04 --> Loader Class Initialized
DEBUG - 2018-05-11 23:36:04 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-11 23:36:04 --> Helper loaded: url_helper
INFO - 2018-05-11 23:36:04 --> Helper loaded: form_helper
INFO - 2018-05-11 23:36:04 --> Helper loaded: date_helper
INFO - 2018-05-11 23:36:04 --> Helper loaded: util_helper
INFO - 2018-05-11 23:36:04 --> Helper loaded: text_helper
INFO - 2018-05-11 23:36:04 --> Helper loaded: string_helper
INFO - 2018-05-11 23:36:04 --> Database Driver Class Initialized
DEBUG - 2018-05-11 23:36:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-11 23:36:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-11 23:36:04 --> Email Class Initialized
INFO - 2018-05-11 23:36:04 --> Controller Class Initialized
DEBUG - 2018-05-11 23:36:04 --> Programs MX_Controller Initialized
INFO - 2018-05-11 23:36:04 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-11 23:36:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-05-11 23:36:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-11 23:36:04 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-11 23:36:04 --> Login MX_Controller Initialized
DEBUG - 2018-05-11 23:36:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-11 23:36:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-05-11 23:36:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-05-11 23:36:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-05-11 23:36:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-05-11 23:36:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-05-11 23:36:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/programs/create_program.php
INFO - 2018-05-11 23:36:05 --> Final output sent to browser
DEBUG - 2018-05-11 23:36:05 --> Total execution time: 1.0730
INFO - 2018-05-11 23:36:06 --> Config Class Initialized
INFO - 2018-05-11 23:36:06 --> Hooks Class Initialized
DEBUG - 2018-05-11 23:36:06 --> UTF-8 Support Enabled
INFO - 2018-05-11 23:36:06 --> Utf8 Class Initialized
INFO - 2018-05-11 23:36:06 --> URI Class Initialized
INFO - 2018-05-11 23:36:06 --> Router Class Initialized
INFO - 2018-05-11 23:36:06 --> Output Class Initialized
INFO - 2018-05-11 23:36:06 --> Security Class Initialized
DEBUG - 2018-05-11 23:36:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 23:36:06 --> Input Class Initialized
INFO - 2018-05-11 23:36:06 --> Language Class Initialized
ERROR - 2018-05-11 23:36:06 --> 404 Page Not Found: /index
INFO - 2018-05-11 23:36:11 --> Config Class Initialized
INFO - 2018-05-11 23:36:12 --> Hooks Class Initialized
DEBUG - 2018-05-11 23:36:12 --> UTF-8 Support Enabled
INFO - 2018-05-11 23:36:12 --> Utf8 Class Initialized
INFO - 2018-05-11 23:36:12 --> URI Class Initialized
INFO - 2018-05-11 23:36:12 --> Router Class Initialized
INFO - 2018-05-11 23:36:12 --> Output Class Initialized
INFO - 2018-05-11 23:36:12 --> Security Class Initialized
DEBUG - 2018-05-11 23:36:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 23:36:12 --> Input Class Initialized
INFO - 2018-05-11 23:36:12 --> Language Class Initialized
INFO - 2018-05-11 23:36:12 --> Language Class Initialized
INFO - 2018-05-11 23:36:12 --> Config Class Initialized
INFO - 2018-05-11 23:36:12 --> Loader Class Initialized
DEBUG - 2018-05-11 23:36:12 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-11 23:36:12 --> Helper loaded: url_helper
INFO - 2018-05-11 23:36:12 --> Helper loaded: form_helper
INFO - 2018-05-11 23:36:12 --> Helper loaded: date_helper
INFO - 2018-05-11 23:36:12 --> Helper loaded: util_helper
INFO - 2018-05-11 23:36:12 --> Helper loaded: text_helper
INFO - 2018-05-11 23:36:12 --> Helper loaded: string_helper
INFO - 2018-05-11 23:36:12 --> Database Driver Class Initialized
DEBUG - 2018-05-11 23:36:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-11 23:36:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-11 23:36:12 --> Email Class Initialized
INFO - 2018-05-11 23:36:12 --> Controller Class Initialized
DEBUG - 2018-05-11 23:36:12 --> Programs MX_Controller Initialized
INFO - 2018-05-11 23:36:12 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-11 23:36:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-05-11 23:36:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-11 23:36:12 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-11 23:36:12 --> Login MX_Controller Initialized
DEBUG - 2018-05-11 23:36:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-11 23:36:46 --> Config Class Initialized
INFO - 2018-05-11 23:36:46 --> Hooks Class Initialized
DEBUG - 2018-05-11 23:36:46 --> UTF-8 Support Enabled
INFO - 2018-05-11 23:36:46 --> Utf8 Class Initialized
INFO - 2018-05-11 23:36:46 --> URI Class Initialized
INFO - 2018-05-11 23:36:47 --> Router Class Initialized
INFO - 2018-05-11 23:36:47 --> Output Class Initialized
INFO - 2018-05-11 23:36:47 --> Security Class Initialized
DEBUG - 2018-05-11 23:36:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 23:36:47 --> Input Class Initialized
INFO - 2018-05-11 23:36:47 --> Language Class Initialized
INFO - 2018-05-11 23:36:47 --> Language Class Initialized
INFO - 2018-05-11 23:36:47 --> Config Class Initialized
INFO - 2018-05-11 23:36:47 --> Loader Class Initialized
DEBUG - 2018-05-11 23:36:47 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-11 23:36:47 --> Helper loaded: url_helper
INFO - 2018-05-11 23:36:47 --> Helper loaded: form_helper
INFO - 2018-05-11 23:36:47 --> Helper loaded: date_helper
INFO - 2018-05-11 23:36:47 --> Helper loaded: util_helper
INFO - 2018-05-11 23:36:47 --> Helper loaded: text_helper
INFO - 2018-05-11 23:36:47 --> Helper loaded: string_helper
INFO - 2018-05-11 23:36:47 --> Database Driver Class Initialized
DEBUG - 2018-05-11 23:36:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-11 23:36:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-11 23:36:47 --> Email Class Initialized
INFO - 2018-05-11 23:36:47 --> Controller Class Initialized
DEBUG - 2018-05-11 23:36:47 --> Programs MX_Controller Initialized
INFO - 2018-05-11 23:36:47 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-11 23:36:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-05-11 23:36:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-11 23:36:47 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-11 23:36:47 --> Login MX_Controller Initialized
DEBUG - 2018-05-11 23:36:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-11 23:36:47 --> Config Class Initialized
INFO - 2018-05-11 23:36:47 --> Hooks Class Initialized
DEBUG - 2018-05-11 23:36:47 --> UTF-8 Support Enabled
INFO - 2018-05-11 23:36:47 --> Utf8 Class Initialized
INFO - 2018-05-11 23:36:47 --> URI Class Initialized
INFO - 2018-05-11 23:36:47 --> Router Class Initialized
INFO - 2018-05-11 23:36:47 --> Output Class Initialized
INFO - 2018-05-11 23:36:47 --> Security Class Initialized
DEBUG - 2018-05-11 23:36:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 23:36:47 --> Input Class Initialized
INFO - 2018-05-11 23:36:47 --> Language Class Initialized
INFO - 2018-05-11 23:36:47 --> Language Class Initialized
INFO - 2018-05-11 23:36:47 --> Config Class Initialized
INFO - 2018-05-11 23:36:48 --> Loader Class Initialized
DEBUG - 2018-05-11 23:36:48 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-11 23:36:48 --> Helper loaded: url_helper
INFO - 2018-05-11 23:36:48 --> Helper loaded: form_helper
INFO - 2018-05-11 23:36:48 --> Helper loaded: date_helper
INFO - 2018-05-11 23:36:48 --> Helper loaded: util_helper
INFO - 2018-05-11 23:36:48 --> Helper loaded: text_helper
INFO - 2018-05-11 23:36:48 --> Helper loaded: string_helper
INFO - 2018-05-11 23:36:48 --> Database Driver Class Initialized
DEBUG - 2018-05-11 23:36:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-11 23:36:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-11 23:36:48 --> Email Class Initialized
INFO - 2018-05-11 23:36:48 --> Controller Class Initialized
DEBUG - 2018-05-11 23:36:48 --> Programs MX_Controller Initialized
INFO - 2018-05-11 23:36:48 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-11 23:36:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-05-11 23:36:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-11 23:36:48 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-11 23:36:48 --> Login MX_Controller Initialized
DEBUG - 2018-05-11 23:36:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-11 23:36:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-05-11 23:36:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-05-11 23:36:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-05-11 23:36:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-05-11 23:36:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-05-11 23:36:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/programs/programs.php
INFO - 2018-05-11 23:36:48 --> Final output sent to browser
DEBUG - 2018-05-11 23:36:48 --> Total execution time: 0.8851
INFO - 2018-05-11 23:36:49 --> Config Class Initialized
INFO - 2018-05-11 23:36:49 --> Hooks Class Initialized
DEBUG - 2018-05-11 23:36:49 --> UTF-8 Support Enabled
INFO - 2018-05-11 23:36:49 --> Utf8 Class Initialized
INFO - 2018-05-11 23:36:49 --> URI Class Initialized
INFO - 2018-05-11 23:36:49 --> Router Class Initialized
INFO - 2018-05-11 23:36:49 --> Output Class Initialized
INFO - 2018-05-11 23:36:49 --> Security Class Initialized
DEBUG - 2018-05-11 23:36:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 23:36:49 --> Input Class Initialized
INFO - 2018-05-11 23:36:49 --> Language Class Initialized
INFO - 2018-05-11 23:36:49 --> Language Class Initialized
INFO - 2018-05-11 23:36:49 --> Config Class Initialized
INFO - 2018-05-11 23:36:49 --> Loader Class Initialized
DEBUG - 2018-05-11 23:36:49 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-11 23:36:49 --> Helper loaded: url_helper
INFO - 2018-05-11 23:36:49 --> Helper loaded: form_helper
INFO - 2018-05-11 23:36:49 --> Helper loaded: date_helper
INFO - 2018-05-11 23:36:49 --> Helper loaded: util_helper
INFO - 2018-05-11 23:36:49 --> Helper loaded: text_helper
INFO - 2018-05-11 23:36:49 --> Helper loaded: string_helper
INFO - 2018-05-11 23:36:50 --> Database Driver Class Initialized
DEBUG - 2018-05-11 23:36:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-11 23:36:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-11 23:36:50 --> Email Class Initialized
INFO - 2018-05-11 23:36:50 --> Controller Class Initialized
DEBUG - 2018-05-11 23:36:50 --> Programs MX_Controller Initialized
INFO - 2018-05-11 23:36:50 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-11 23:36:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-05-11 23:36:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-11 23:36:50 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-11 23:36:50 --> Login MX_Controller Initialized
DEBUG - 2018-05-11 23:36:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-11 23:36:50 --> Final output sent to browser
DEBUG - 2018-05-11 23:36:50 --> Total execution time: 1.0201
INFO - 2018-05-11 23:38:25 --> Config Class Initialized
INFO - 2018-05-11 23:38:25 --> Config Class Initialized
INFO - 2018-05-11 23:38:25 --> Hooks Class Initialized
INFO - 2018-05-11 23:38:25 --> Hooks Class Initialized
DEBUG - 2018-05-11 23:38:25 --> UTF-8 Support Enabled
DEBUG - 2018-05-11 23:38:25 --> UTF-8 Support Enabled
INFO - 2018-05-11 23:38:25 --> Utf8 Class Initialized
INFO - 2018-05-11 23:38:25 --> Utf8 Class Initialized
INFO - 2018-05-11 23:38:25 --> URI Class Initialized
INFO - 2018-05-11 23:38:25 --> Router Class Initialized
INFO - 2018-05-11 23:38:25 --> URI Class Initialized
INFO - 2018-05-11 23:38:25 --> Output Class Initialized
INFO - 2018-05-11 23:38:25 --> Security Class Initialized
DEBUG - 2018-05-11 23:38:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 23:38:25 --> Input Class Initialized
INFO - 2018-05-11 23:38:25 --> Language Class Initialized
INFO - 2018-05-11 23:38:25 --> Language Class Initialized
INFO - 2018-05-11 23:38:25 --> Router Class Initialized
INFO - 2018-05-11 23:38:25 --> Config Class Initialized
INFO - 2018-05-11 23:38:25 --> Output Class Initialized
INFO - 2018-05-11 23:38:25 --> Loader Class Initialized
INFO - 2018-05-11 23:38:25 --> Security Class Initialized
DEBUG - 2018-05-11 23:38:26 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
DEBUG - 2018-05-11 23:38:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 23:38:26 --> Helper loaded: url_helper
INFO - 2018-05-11 23:38:26 --> Input Class Initialized
INFO - 2018-05-11 23:38:26 --> Language Class Initialized
ERROR - 2018-05-11 23:38:26 --> 404 Page Not Found: /index
INFO - 2018-05-11 23:38:26 --> Helper loaded: form_helper
INFO - 2018-05-11 23:38:26 --> Helper loaded: date_helper
INFO - 2018-05-11 23:38:26 --> Helper loaded: util_helper
INFO - 2018-05-11 23:38:26 --> Helper loaded: text_helper
INFO - 2018-05-11 23:38:26 --> Helper loaded: string_helper
INFO - 2018-05-11 23:38:26 --> Database Driver Class Initialized
DEBUG - 2018-05-11 23:38:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-11 23:38:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-11 23:38:26 --> Email Class Initialized
INFO - 2018-05-11 23:38:26 --> Controller Class Initialized
DEBUG - 2018-05-11 23:38:26 --> Admin MX_Controller Initialized
INFO - 2018-05-11 23:38:26 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-11 23:38:26 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-11 23:38:26 --> Login MX_Controller Initialized
DEBUG - 2018-05-11 23:38:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-11 23:38:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-11 23:38:26 --> Final output sent to browser
DEBUG - 2018-05-11 23:38:26 --> Total execution time: 0.8423
INFO - 2018-05-11 23:38:32 --> Config Class Initialized
INFO - 2018-05-11 23:38:32 --> Hooks Class Initialized
DEBUG - 2018-05-11 23:38:32 --> UTF-8 Support Enabled
INFO - 2018-05-11 23:38:32 --> Utf8 Class Initialized
INFO - 2018-05-11 23:38:32 --> URI Class Initialized
INFO - 2018-05-11 23:38:32 --> Router Class Initialized
INFO - 2018-05-11 23:38:32 --> Output Class Initialized
INFO - 2018-05-11 23:38:32 --> Security Class Initialized
DEBUG - 2018-05-11 23:38:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 23:38:32 --> Input Class Initialized
INFO - 2018-05-11 23:38:32 --> Language Class Initialized
ERROR - 2018-05-11 23:38:32 --> 404 Page Not Found: /index
INFO - 2018-05-11 23:39:12 --> Config Class Initialized
INFO - 2018-05-11 23:39:12 --> Hooks Class Initialized
DEBUG - 2018-05-11 23:39:12 --> UTF-8 Support Enabled
INFO - 2018-05-11 23:39:12 --> Utf8 Class Initialized
INFO - 2018-05-11 23:39:12 --> URI Class Initialized
INFO - 2018-05-11 23:39:12 --> Router Class Initialized
INFO - 2018-05-11 23:39:12 --> Output Class Initialized
INFO - 2018-05-11 23:39:12 --> Security Class Initialized
DEBUG - 2018-05-11 23:39:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 23:39:12 --> Input Class Initialized
INFO - 2018-05-11 23:39:12 --> Language Class Initialized
INFO - 2018-05-11 23:39:12 --> Language Class Initialized
INFO - 2018-05-11 23:39:12 --> Config Class Initialized
INFO - 2018-05-11 23:39:12 --> Loader Class Initialized
DEBUG - 2018-05-11 23:39:12 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-11 23:39:12 --> Helper loaded: url_helper
INFO - 2018-05-11 23:39:12 --> Helper loaded: form_helper
INFO - 2018-05-11 23:39:12 --> Helper loaded: date_helper
INFO - 2018-05-11 23:39:12 --> Helper loaded: util_helper
INFO - 2018-05-11 23:39:12 --> Helper loaded: text_helper
INFO - 2018-05-11 23:39:12 --> Helper loaded: string_helper
INFO - 2018-05-11 23:39:12 --> Database Driver Class Initialized
DEBUG - 2018-05-11 23:39:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-11 23:39:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-11 23:39:12 --> Email Class Initialized
INFO - 2018-05-11 23:39:12 --> Controller Class Initialized
DEBUG - 2018-05-11 23:39:12 --> Admin MX_Controller Initialized
INFO - 2018-05-11 23:39:12 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-11 23:39:12 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-11 23:39:12 --> Login MX_Controller Initialized
DEBUG - 2018-05-11 23:39:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-11 23:39:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-11 23:39:12 --> Final output sent to browser
DEBUG - 2018-05-11 23:39:12 --> Total execution time: 0.8164
INFO - 2018-05-11 23:39:13 --> Config Class Initialized
INFO - 2018-05-11 23:39:13 --> Hooks Class Initialized
DEBUG - 2018-05-11 23:39:13 --> UTF-8 Support Enabled
INFO - 2018-05-11 23:39:13 --> Utf8 Class Initialized
INFO - 2018-05-11 23:39:13 --> URI Class Initialized
INFO - 2018-05-11 23:39:13 --> Router Class Initialized
INFO - 2018-05-11 23:39:13 --> Output Class Initialized
INFO - 2018-05-11 23:39:13 --> Security Class Initialized
DEBUG - 2018-05-11 23:39:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 23:39:14 --> Input Class Initialized
INFO - 2018-05-11 23:39:14 --> Language Class Initialized
INFO - 2018-05-11 23:39:14 --> Language Class Initialized
INFO - 2018-05-11 23:39:14 --> Config Class Initialized
INFO - 2018-05-11 23:39:14 --> Loader Class Initialized
DEBUG - 2018-05-11 23:39:14 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-11 23:39:14 --> Helper loaded: url_helper
INFO - 2018-05-11 23:39:14 --> Helper loaded: form_helper
INFO - 2018-05-11 23:39:14 --> Helper loaded: date_helper
INFO - 2018-05-11 23:39:14 --> Helper loaded: util_helper
INFO - 2018-05-11 23:39:14 --> Helper loaded: text_helper
INFO - 2018-05-11 23:39:14 --> Helper loaded: string_helper
INFO - 2018-05-11 23:39:14 --> Database Driver Class Initialized
DEBUG - 2018-05-11 23:39:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-11 23:39:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-11 23:39:14 --> Email Class Initialized
INFO - 2018-05-11 23:39:14 --> Controller Class Initialized
DEBUG - 2018-05-11 23:39:14 --> Admin MX_Controller Initialized
INFO - 2018-05-11 23:39:14 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-11 23:39:14 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-11 23:39:14 --> Login MX_Controller Initialized
DEBUG - 2018-05-11 23:39:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-11 23:39:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-11 23:39:14 --> Final output sent to browser
DEBUG - 2018-05-11 23:39:14 --> Total execution time: 0.7809
INFO - 2018-05-11 23:39:15 --> Config Class Initialized
INFO - 2018-05-11 23:39:15 --> Hooks Class Initialized
DEBUG - 2018-05-11 23:39:15 --> UTF-8 Support Enabled
INFO - 2018-05-11 23:39:15 --> Utf8 Class Initialized
INFO - 2018-05-11 23:39:15 --> URI Class Initialized
INFO - 2018-05-11 23:39:15 --> Router Class Initialized
INFO - 2018-05-11 23:39:15 --> Output Class Initialized
INFO - 2018-05-11 23:39:15 --> Security Class Initialized
DEBUG - 2018-05-11 23:39:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 23:39:15 --> Input Class Initialized
INFO - 2018-05-11 23:39:15 --> Language Class Initialized
INFO - 2018-05-11 23:39:15 --> Language Class Initialized
INFO - 2018-05-11 23:39:15 --> Config Class Initialized
INFO - 2018-05-11 23:39:15 --> Loader Class Initialized
DEBUG - 2018-05-11 23:39:15 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-11 23:39:15 --> Helper loaded: url_helper
INFO - 2018-05-11 23:39:15 --> Helper loaded: form_helper
INFO - 2018-05-11 23:39:15 --> Helper loaded: date_helper
INFO - 2018-05-11 23:39:15 --> Helper loaded: util_helper
INFO - 2018-05-11 23:39:15 --> Helper loaded: text_helper
INFO - 2018-05-11 23:39:16 --> Helper loaded: string_helper
INFO - 2018-05-11 23:39:16 --> Database Driver Class Initialized
DEBUG - 2018-05-11 23:39:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-11 23:39:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-11 23:39:16 --> Email Class Initialized
INFO - 2018-05-11 23:39:16 --> Controller Class Initialized
DEBUG - 2018-05-11 23:39:16 --> Admin MX_Controller Initialized
INFO - 2018-05-11 23:39:16 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-11 23:39:16 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-11 23:39:16 --> Login MX_Controller Initialized
DEBUG - 2018-05-11 23:39:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-11 23:39:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-11 23:39:16 --> Final output sent to browser
DEBUG - 2018-05-11 23:39:16 --> Total execution time: 0.8130
INFO - 2018-05-11 23:39:24 --> Config Class Initialized
INFO - 2018-05-11 23:39:24 --> Hooks Class Initialized
DEBUG - 2018-05-11 23:39:24 --> UTF-8 Support Enabled
INFO - 2018-05-11 23:39:24 --> Utf8 Class Initialized
INFO - 2018-05-11 23:39:24 --> URI Class Initialized
INFO - 2018-05-11 23:39:24 --> Router Class Initialized
INFO - 2018-05-11 23:39:24 --> Output Class Initialized
INFO - 2018-05-11 23:39:24 --> Security Class Initialized
DEBUG - 2018-05-11 23:39:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 23:39:24 --> Input Class Initialized
INFO - 2018-05-11 23:39:24 --> Language Class Initialized
INFO - 2018-05-11 23:39:24 --> Language Class Initialized
INFO - 2018-05-11 23:39:24 --> Config Class Initialized
INFO - 2018-05-11 23:39:24 --> Loader Class Initialized
DEBUG - 2018-05-11 23:39:24 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-11 23:39:24 --> Helper loaded: url_helper
INFO - 2018-05-11 23:39:24 --> Helper loaded: form_helper
INFO - 2018-05-11 23:39:24 --> Config Class Initialized
INFO - 2018-05-11 23:39:24 --> Helper loaded: date_helper
INFO - 2018-05-11 23:39:24 --> Helper loaded: util_helper
INFO - 2018-05-11 23:39:24 --> Hooks Class Initialized
INFO - 2018-05-11 23:39:24 --> Helper loaded: text_helper
INFO - 2018-05-11 23:39:24 --> Helper loaded: string_helper
DEBUG - 2018-05-11 23:39:24 --> UTF-8 Support Enabled
INFO - 2018-05-11 23:39:24 --> Database Driver Class Initialized
INFO - 2018-05-11 23:39:24 --> Utf8 Class Initialized
INFO - 2018-05-11 23:39:24 --> URI Class Initialized
DEBUG - 2018-05-11 23:39:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-11 23:39:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-11 23:39:24 --> Router Class Initialized
INFO - 2018-05-11 23:39:24 --> Email Class Initialized
INFO - 2018-05-11 23:39:24 --> Output Class Initialized
INFO - 2018-05-11 23:39:24 --> Controller Class Initialized
DEBUG - 2018-05-11 23:39:24 --> Programs MX_Controller Initialized
INFO - 2018-05-11 23:39:24 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-11 23:39:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-05-11 23:39:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-11 23:39:24 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
INFO - 2018-05-11 23:39:24 --> Security Class Initialized
DEBUG - 2018-05-11 23:39:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-11 23:39:24 --> Login MX_Controller Initialized
INFO - 2018-05-11 23:39:24 --> Input Class Initialized
INFO - 2018-05-11 23:39:24 --> Language Class Initialized
INFO - 2018-05-11 23:39:24 --> Language Class Initialized
DEBUG - 2018-05-11 23:39:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-11 23:39:24 --> Config Class Initialized
INFO - 2018-05-11 23:39:24 --> Loader Class Initialized
INFO - 2018-05-11 23:39:24 --> Final output sent to browser
DEBUG - 2018-05-11 23:39:25 --> Total execution time: 0.8213
DEBUG - 2018-05-11 23:39:25 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-11 23:39:25 --> Helper loaded: url_helper
INFO - 2018-05-11 23:39:25 --> Helper loaded: form_helper
INFO - 2018-05-11 23:39:25 --> Helper loaded: date_helper
INFO - 2018-05-11 23:39:25 --> Helper loaded: util_helper
INFO - 2018-05-11 23:39:25 --> Helper loaded: text_helper
INFO - 2018-05-11 23:39:25 --> Helper loaded: string_helper
INFO - 2018-05-11 23:39:25 --> Database Driver Class Initialized
DEBUG - 2018-05-11 23:39:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-11 23:39:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-11 23:39:25 --> Config Class Initialized
INFO - 2018-05-11 23:39:25 --> Hooks Class Initialized
INFO - 2018-05-11 23:39:25 --> Email Class Initialized
INFO - 2018-05-11 23:39:25 --> Controller Class Initialized
DEBUG - 2018-05-11 23:39:25 --> UTF-8 Support Enabled
INFO - 2018-05-11 23:39:25 --> Utf8 Class Initialized
DEBUG - 2018-05-11 23:39:25 --> Programs MX_Controller Initialized
INFO - 2018-05-11 23:39:25 --> URI Class Initialized
INFO - 2018-05-11 23:39:25 --> Router Class Initialized
INFO - 2018-05-11 23:39:25 --> Language file loaded: language/english/data_lang.php
INFO - 2018-05-11 23:39:25 --> Output Class Initialized
INFO - 2018-05-11 23:39:25 --> Security Class Initialized
DEBUG - 2018-05-11 23:39:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 23:39:25 --> Input Class Initialized
INFO - 2018-05-11 23:39:25 --> Language Class Initialized
INFO - 2018-05-11 23:39:25 --> Language Class Initialized
DEBUG - 2018-05-11 23:39:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-05-11 23:39:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-05-11 23:39:25 --> Config Class Initialized
DEBUG - 2018-05-11 23:39:25 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
INFO - 2018-05-11 23:39:25 --> Loader Class Initialized
DEBUG - 2018-05-11 23:39:25 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
DEBUG - 2018-05-11 23:39:25 --> Login MX_Controller Initialized
INFO - 2018-05-11 23:39:25 --> Helper loaded: url_helper
DEBUG - 2018-05-11 23:39:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-11 23:39:25 --> Helper loaded: form_helper
INFO - 2018-05-11 23:39:25 --> Final output sent to browser
DEBUG - 2018-05-11 23:39:25 --> Total execution time: 0.9723
INFO - 2018-05-11 23:39:25 --> Helper loaded: date_helper
INFO - 2018-05-11 23:39:25 --> Helper loaded: util_helper
INFO - 2018-05-11 23:39:25 --> Helper loaded: text_helper
INFO - 2018-05-11 23:39:25 --> Helper loaded: string_helper
INFO - 2018-05-11 23:39:25 --> Database Driver Class Initialized
DEBUG - 2018-05-11 23:39:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-11 23:39:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-11 23:39:25 --> Email Class Initialized
INFO - 2018-05-11 23:39:25 --> Controller Class Initialized
DEBUG - 2018-05-11 23:39:25 --> Programs MX_Controller Initialized
INFO - 2018-05-11 23:39:25 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-11 23:39:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-05-11 23:39:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-11 23:39:25 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-11 23:39:25 --> Login MX_Controller Initialized
DEBUG - 2018-05-11 23:39:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-11 23:39:25 --> Final output sent to browser
DEBUG - 2018-05-11 23:39:25 --> Total execution time: 0.6701
INFO - 2018-05-11 23:39:28 --> Config Class Initialized
INFO - 2018-05-11 23:39:28 --> Hooks Class Initialized
DEBUG - 2018-05-11 23:39:28 --> UTF-8 Support Enabled
INFO - 2018-05-11 23:39:28 --> Utf8 Class Initialized
INFO - 2018-05-11 23:39:28 --> URI Class Initialized
INFO - 2018-05-11 23:39:28 --> Router Class Initialized
INFO - 2018-05-11 23:39:28 --> Output Class Initialized
INFO - 2018-05-11 23:39:28 --> Security Class Initialized
DEBUG - 2018-05-11 23:39:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 23:39:28 --> Input Class Initialized
INFO - 2018-05-11 23:39:28 --> Language Class Initialized
INFO - 2018-05-11 23:39:28 --> Language Class Initialized
INFO - 2018-05-11 23:39:28 --> Config Class Initialized
INFO - 2018-05-11 23:39:28 --> Loader Class Initialized
DEBUG - 2018-05-11 23:39:28 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-11 23:39:28 --> Helper loaded: url_helper
INFO - 2018-05-11 23:39:28 --> Helper loaded: form_helper
INFO - 2018-05-11 23:39:28 --> Helper loaded: date_helper
INFO - 2018-05-11 23:39:28 --> Helper loaded: util_helper
INFO - 2018-05-11 23:39:28 --> Helper loaded: text_helper
INFO - 2018-05-11 23:39:28 --> Helper loaded: string_helper
INFO - 2018-05-11 23:39:28 --> Database Driver Class Initialized
DEBUG - 2018-05-11 23:39:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-11 23:39:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-11 23:39:28 --> Email Class Initialized
INFO - 2018-05-11 23:39:28 --> Controller Class Initialized
DEBUG - 2018-05-11 23:39:28 --> Programs MX_Controller Initialized
INFO - 2018-05-11 23:39:28 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-11 23:39:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-05-11 23:39:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-11 23:39:28 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-11 23:39:28 --> Login MX_Controller Initialized
DEBUG - 2018-05-11 23:39:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-11 23:39:28 --> Final output sent to browser
DEBUG - 2018-05-11 23:39:28 --> Total execution time: 0.7674
INFO - 2018-05-11 23:39:58 --> Config Class Initialized
INFO - 2018-05-11 23:39:58 --> Hooks Class Initialized
DEBUG - 2018-05-11 23:39:58 --> UTF-8 Support Enabled
INFO - 2018-05-11 23:39:58 --> Utf8 Class Initialized
INFO - 2018-05-11 23:39:58 --> URI Class Initialized
INFO - 2018-05-11 23:39:58 --> Router Class Initialized
INFO - 2018-05-11 23:39:58 --> Output Class Initialized
INFO - 2018-05-11 23:39:58 --> Security Class Initialized
DEBUG - 2018-05-11 23:39:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 23:39:58 --> Input Class Initialized
INFO - 2018-05-11 23:39:58 --> Language Class Initialized
INFO - 2018-05-11 23:39:58 --> Language Class Initialized
INFO - 2018-05-11 23:39:58 --> Config Class Initialized
INFO - 2018-05-11 23:39:58 --> Loader Class Initialized
DEBUG - 2018-05-11 23:39:58 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-11 23:39:58 --> Helper loaded: url_helper
INFO - 2018-05-11 23:39:58 --> Helper loaded: form_helper
INFO - 2018-05-11 23:39:58 --> Helper loaded: date_helper
INFO - 2018-05-11 23:39:58 --> Helper loaded: util_helper
INFO - 2018-05-11 23:39:58 --> Helper loaded: text_helper
INFO - 2018-05-11 23:39:58 --> Helper loaded: string_helper
INFO - 2018-05-11 23:39:58 --> Database Driver Class Initialized
DEBUG - 2018-05-11 23:39:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-11 23:39:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-11 23:39:58 --> Email Class Initialized
INFO - 2018-05-11 23:39:59 --> Controller Class Initialized
DEBUG - 2018-05-11 23:39:59 --> Programs MX_Controller Initialized
INFO - 2018-05-11 23:39:59 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-11 23:39:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-05-11 23:39:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-11 23:39:59 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-11 23:39:59 --> Login MX_Controller Initialized
DEBUG - 2018-05-11 23:39:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-11 23:39:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-05-11 23:39:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-05-11 23:39:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-05-11 23:39:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-05-11 23:39:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-05-11 23:39:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/programs/programs.php
INFO - 2018-05-11 23:39:59 --> Final output sent to browser
DEBUG - 2018-05-11 23:39:59 --> Total execution time: 0.8598
INFO - 2018-05-11 23:40:00 --> Config Class Initialized
INFO - 2018-05-11 23:40:00 --> Hooks Class Initialized
DEBUG - 2018-05-11 23:40:00 --> UTF-8 Support Enabled
INFO - 2018-05-11 23:40:00 --> Utf8 Class Initialized
INFO - 2018-05-11 23:40:00 --> URI Class Initialized
INFO - 2018-05-11 23:40:00 --> Router Class Initialized
INFO - 2018-05-11 23:40:00 --> Output Class Initialized
INFO - 2018-05-11 23:40:00 --> Security Class Initialized
DEBUG - 2018-05-11 23:40:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 23:40:00 --> Input Class Initialized
INFO - 2018-05-11 23:40:00 --> Language Class Initialized
INFO - 2018-05-11 23:40:00 --> Language Class Initialized
INFO - 2018-05-11 23:40:00 --> Config Class Initialized
INFO - 2018-05-11 23:40:00 --> Loader Class Initialized
DEBUG - 2018-05-11 23:40:00 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-11 23:40:00 --> Helper loaded: url_helper
INFO - 2018-05-11 23:40:00 --> Helper loaded: form_helper
INFO - 2018-05-11 23:40:00 --> Helper loaded: date_helper
INFO - 2018-05-11 23:40:00 --> Helper loaded: util_helper
INFO - 2018-05-11 23:40:00 --> Helper loaded: text_helper
INFO - 2018-05-11 23:40:00 --> Helper loaded: string_helper
INFO - 2018-05-11 23:40:00 --> Database Driver Class Initialized
DEBUG - 2018-05-11 23:40:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-11 23:40:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-11 23:40:00 --> Email Class Initialized
INFO - 2018-05-11 23:40:00 --> Controller Class Initialized
DEBUG - 2018-05-11 23:40:00 --> Programs MX_Controller Initialized
INFO - 2018-05-11 23:40:00 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-11 23:40:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-05-11 23:40:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-11 23:40:00 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-11 23:40:00 --> Login MX_Controller Initialized
DEBUG - 2018-05-11 23:40:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-11 23:40:00 --> Final output sent to browser
DEBUG - 2018-05-11 23:40:00 --> Total execution time: 0.8635
INFO - 2018-05-11 23:40:03 --> Config Class Initialized
INFO - 2018-05-11 23:40:03 --> Hooks Class Initialized
DEBUG - 2018-05-11 23:40:03 --> UTF-8 Support Enabled
INFO - 2018-05-11 23:40:03 --> Utf8 Class Initialized
INFO - 2018-05-11 23:40:03 --> URI Class Initialized
INFO - 2018-05-11 23:40:03 --> Router Class Initialized
INFO - 2018-05-11 23:40:03 --> Output Class Initialized
INFO - 2018-05-11 23:40:03 --> Security Class Initialized
DEBUG - 2018-05-11 23:40:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 23:40:03 --> Input Class Initialized
INFO - 2018-05-11 23:40:03 --> Language Class Initialized
INFO - 2018-05-11 23:40:03 --> Language Class Initialized
INFO - 2018-05-11 23:40:03 --> Config Class Initialized
INFO - 2018-05-11 23:40:03 --> Loader Class Initialized
DEBUG - 2018-05-11 23:40:03 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-11 23:40:03 --> Helper loaded: url_helper
INFO - 2018-05-11 23:40:03 --> Helper loaded: form_helper
INFO - 2018-05-11 23:40:03 --> Helper loaded: date_helper
INFO - 2018-05-11 23:40:03 --> Helper loaded: util_helper
INFO - 2018-05-11 23:40:03 --> Helper loaded: text_helper
INFO - 2018-05-11 23:40:03 --> Helper loaded: string_helper
INFO - 2018-05-11 23:40:03 --> Database Driver Class Initialized
DEBUG - 2018-05-11 23:40:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-11 23:40:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-11 23:40:03 --> Email Class Initialized
INFO - 2018-05-11 23:40:04 --> Controller Class Initialized
DEBUG - 2018-05-11 23:40:04 --> Admin MX_Controller Initialized
INFO - 2018-05-11 23:40:04 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-11 23:40:04 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-11 23:40:04 --> Login MX_Controller Initialized
DEBUG - 2018-05-11 23:40:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-11 23:40:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-11 23:40:04 --> Final output sent to browser
DEBUG - 2018-05-11 23:40:04 --> Total execution time: 0.8962
INFO - 2018-05-11 23:40:05 --> Config Class Initialized
INFO - 2018-05-11 23:40:05 --> Hooks Class Initialized
DEBUG - 2018-05-11 23:40:05 --> UTF-8 Support Enabled
INFO - 2018-05-11 23:40:05 --> Utf8 Class Initialized
INFO - 2018-05-11 23:40:05 --> URI Class Initialized
INFO - 2018-05-11 23:40:05 --> Router Class Initialized
INFO - 2018-05-11 23:40:05 --> Output Class Initialized
INFO - 2018-05-11 23:40:05 --> Security Class Initialized
DEBUG - 2018-05-11 23:40:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 23:40:05 --> Input Class Initialized
INFO - 2018-05-11 23:40:05 --> Language Class Initialized
INFO - 2018-05-11 23:40:05 --> Language Class Initialized
INFO - 2018-05-11 23:40:05 --> Config Class Initialized
INFO - 2018-05-11 23:40:05 --> Loader Class Initialized
DEBUG - 2018-05-11 23:40:05 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-11 23:40:05 --> Helper loaded: url_helper
INFO - 2018-05-11 23:40:05 --> Helper loaded: form_helper
INFO - 2018-05-11 23:40:05 --> Helper loaded: date_helper
INFO - 2018-05-11 23:40:05 --> Helper loaded: util_helper
INFO - 2018-05-11 23:40:05 --> Helper loaded: text_helper
INFO - 2018-05-11 23:40:05 --> Helper loaded: string_helper
INFO - 2018-05-11 23:40:05 --> Database Driver Class Initialized
DEBUG - 2018-05-11 23:40:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-11 23:40:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-11 23:40:05 --> Email Class Initialized
INFO - 2018-05-11 23:40:05 --> Controller Class Initialized
DEBUG - 2018-05-11 23:40:06 --> Admin MX_Controller Initialized
INFO - 2018-05-11 23:40:06 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-11 23:40:06 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-11 23:40:06 --> Login MX_Controller Initialized
DEBUG - 2018-05-11 23:40:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-11 23:40:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-11 23:40:06 --> Final output sent to browser
DEBUG - 2018-05-11 23:40:06 --> Total execution time: 0.7961
INFO - 2018-05-11 23:40:08 --> Config Class Initialized
INFO - 2018-05-11 23:40:08 --> Hooks Class Initialized
DEBUG - 2018-05-11 23:40:08 --> UTF-8 Support Enabled
INFO - 2018-05-11 23:40:08 --> Utf8 Class Initialized
INFO - 2018-05-11 23:40:08 --> URI Class Initialized
INFO - 2018-05-11 23:40:08 --> Router Class Initialized
INFO - 2018-05-11 23:40:08 --> Output Class Initialized
INFO - 2018-05-11 23:40:08 --> Security Class Initialized
DEBUG - 2018-05-11 23:40:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 23:40:08 --> Input Class Initialized
INFO - 2018-05-11 23:40:08 --> Language Class Initialized
INFO - 2018-05-11 23:40:08 --> Language Class Initialized
INFO - 2018-05-11 23:40:08 --> Config Class Initialized
INFO - 2018-05-11 23:40:08 --> Loader Class Initialized
DEBUG - 2018-05-11 23:40:08 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-11 23:40:08 --> Helper loaded: url_helper
INFO - 2018-05-11 23:40:08 --> Helper loaded: form_helper
INFO - 2018-05-11 23:40:08 --> Helper loaded: date_helper
INFO - 2018-05-11 23:40:09 --> Helper loaded: util_helper
INFO - 2018-05-11 23:40:09 --> Helper loaded: text_helper
INFO - 2018-05-11 23:40:09 --> Helper loaded: string_helper
INFO - 2018-05-11 23:40:09 --> Database Driver Class Initialized
DEBUG - 2018-05-11 23:40:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-11 23:40:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-11 23:40:09 --> Email Class Initialized
INFO - 2018-05-11 23:40:09 --> Controller Class Initialized
DEBUG - 2018-05-11 23:40:09 --> Programs MX_Controller Initialized
INFO - 2018-05-11 23:40:09 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-11 23:40:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-05-11 23:40:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-11 23:40:09 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-11 23:40:09 --> Login MX_Controller Initialized
DEBUG - 2018-05-11 23:40:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-11 23:40:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-05-11 23:40:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-05-11 23:40:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-05-11 23:40:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-05-11 23:40:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-05-11 23:40:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/programs/create_program.php
INFO - 2018-05-11 23:40:09 --> Final output sent to browser
DEBUG - 2018-05-11 23:40:09 --> Total execution time: 0.9559
INFO - 2018-05-11 23:40:11 --> Config Class Initialized
INFO - 2018-05-11 23:40:11 --> Hooks Class Initialized
DEBUG - 2018-05-11 23:40:11 --> UTF-8 Support Enabled
INFO - 2018-05-11 23:40:11 --> Utf8 Class Initialized
INFO - 2018-05-11 23:40:11 --> URI Class Initialized
INFO - 2018-05-11 23:40:11 --> Router Class Initialized
INFO - 2018-05-11 23:40:11 --> Output Class Initialized
INFO - 2018-05-11 23:40:11 --> Security Class Initialized
DEBUG - 2018-05-11 23:40:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 23:40:11 --> Input Class Initialized
INFO - 2018-05-11 23:40:11 --> Language Class Initialized
INFO - 2018-05-11 23:40:11 --> Language Class Initialized
INFO - 2018-05-11 23:40:11 --> Config Class Initialized
INFO - 2018-05-11 23:40:11 --> Loader Class Initialized
DEBUG - 2018-05-11 23:40:11 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-11 23:40:11 --> Helper loaded: url_helper
INFO - 2018-05-11 23:40:11 --> Helper loaded: form_helper
INFO - 2018-05-11 23:40:11 --> Helper loaded: date_helper
INFO - 2018-05-11 23:40:11 --> Helper loaded: util_helper
INFO - 2018-05-11 23:40:11 --> Helper loaded: text_helper
INFO - 2018-05-11 23:40:11 --> Helper loaded: string_helper
INFO - 2018-05-11 23:40:11 --> Database Driver Class Initialized
DEBUG - 2018-05-11 23:40:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-11 23:40:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-11 23:40:11 --> Email Class Initialized
INFO - 2018-05-11 23:40:11 --> Controller Class Initialized
DEBUG - 2018-05-11 23:40:11 --> Programs MX_Controller Initialized
INFO - 2018-05-11 23:40:11 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-11 23:40:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-05-11 23:40:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-11 23:40:11 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-11 23:40:11 --> Login MX_Controller Initialized
DEBUG - 2018-05-11 23:40:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-11 23:40:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-05-11 23:40:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-05-11 23:40:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-05-11 23:40:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-05-11 23:40:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-05-11 23:40:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/programs/programs.php
INFO - 2018-05-11 23:40:11 --> Final output sent to browser
DEBUG - 2018-05-11 23:40:12 --> Total execution time: 0.8812
INFO - 2018-05-11 23:40:12 --> Config Class Initialized
INFO - 2018-05-11 23:40:12 --> Hooks Class Initialized
DEBUG - 2018-05-11 23:40:12 --> UTF-8 Support Enabled
INFO - 2018-05-11 23:40:12 --> Utf8 Class Initialized
INFO - 2018-05-11 23:40:12 --> URI Class Initialized
INFO - 2018-05-11 23:40:12 --> Router Class Initialized
INFO - 2018-05-11 23:40:12 --> Output Class Initialized
INFO - 2018-05-11 23:40:12 --> Security Class Initialized
DEBUG - 2018-05-11 23:40:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 23:40:12 --> Input Class Initialized
INFO - 2018-05-11 23:40:12 --> Language Class Initialized
INFO - 2018-05-11 23:40:12 --> Language Class Initialized
INFO - 2018-05-11 23:40:12 --> Config Class Initialized
INFO - 2018-05-11 23:40:12 --> Loader Class Initialized
DEBUG - 2018-05-11 23:40:12 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-11 23:40:12 --> Helper loaded: url_helper
INFO - 2018-05-11 23:40:12 --> Helper loaded: form_helper
INFO - 2018-05-11 23:40:12 --> Helper loaded: date_helper
INFO - 2018-05-11 23:40:12 --> Helper loaded: util_helper
INFO - 2018-05-11 23:40:12 --> Helper loaded: text_helper
INFO - 2018-05-11 23:40:12 --> Helper loaded: string_helper
INFO - 2018-05-11 23:40:12 --> Database Driver Class Initialized
DEBUG - 2018-05-11 23:40:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-11 23:40:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-11 23:40:12 --> Email Class Initialized
INFO - 2018-05-11 23:40:12 --> Controller Class Initialized
DEBUG - 2018-05-11 23:40:13 --> Programs MX_Controller Initialized
INFO - 2018-05-11 23:40:13 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-11 23:40:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-05-11 23:40:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-11 23:40:13 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-11 23:40:13 --> Login MX_Controller Initialized
DEBUG - 2018-05-11 23:40:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-11 23:40:13 --> Final output sent to browser
DEBUG - 2018-05-11 23:40:13 --> Total execution time: 0.8668
INFO - 2018-05-11 23:40:54 --> Config Class Initialized
INFO - 2018-05-11 23:40:54 --> Hooks Class Initialized
DEBUG - 2018-05-11 23:40:54 --> UTF-8 Support Enabled
INFO - 2018-05-11 23:40:54 --> Utf8 Class Initialized
INFO - 2018-05-11 23:40:54 --> URI Class Initialized
INFO - 2018-05-11 23:40:54 --> Router Class Initialized
INFO - 2018-05-11 23:40:54 --> Output Class Initialized
INFO - 2018-05-11 23:40:54 --> Security Class Initialized
DEBUG - 2018-05-11 23:40:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 23:40:54 --> Input Class Initialized
INFO - 2018-05-11 23:40:54 --> Language Class Initialized
INFO - 2018-05-11 23:40:54 --> Language Class Initialized
INFO - 2018-05-11 23:40:54 --> Config Class Initialized
INFO - 2018-05-11 23:40:54 --> Loader Class Initialized
DEBUG - 2018-05-11 23:40:54 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-11 23:40:54 --> Helper loaded: url_helper
INFO - 2018-05-11 23:40:54 --> Helper loaded: form_helper
INFO - 2018-05-11 23:40:54 --> Helper loaded: date_helper
INFO - 2018-05-11 23:40:54 --> Helper loaded: util_helper
INFO - 2018-05-11 23:40:54 --> Helper loaded: text_helper
INFO - 2018-05-11 23:40:54 --> Helper loaded: string_helper
INFO - 2018-05-11 23:40:54 --> Database Driver Class Initialized
DEBUG - 2018-05-11 23:40:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-11 23:40:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-11 23:40:54 --> Email Class Initialized
INFO - 2018-05-11 23:40:54 --> Controller Class Initialized
DEBUG - 2018-05-11 23:40:54 --> Programs MX_Controller Initialized
INFO - 2018-05-11 23:40:54 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-11 23:40:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-05-11 23:40:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-11 23:40:54 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-11 23:40:54 --> Login MX_Controller Initialized
DEBUG - 2018-05-11 23:40:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-11 23:40:55 --> Final output sent to browser
DEBUG - 2018-05-11 23:40:55 --> Total execution time: 0.7520
INFO - 2018-05-11 23:44:16 --> Config Class Initialized
INFO - 2018-05-11 23:44:16 --> Hooks Class Initialized
DEBUG - 2018-05-11 23:44:16 --> UTF-8 Support Enabled
INFO - 2018-05-11 23:44:16 --> Utf8 Class Initialized
INFO - 2018-05-11 23:44:16 --> URI Class Initialized
INFO - 2018-05-11 23:44:16 --> Router Class Initialized
INFO - 2018-05-11 23:44:16 --> Output Class Initialized
INFO - 2018-05-11 23:44:16 --> Security Class Initialized
DEBUG - 2018-05-11 23:44:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 23:44:16 --> Input Class Initialized
INFO - 2018-05-11 23:44:16 --> Language Class Initialized
INFO - 2018-05-11 23:44:16 --> Language Class Initialized
INFO - 2018-05-11 23:44:16 --> Config Class Initialized
INFO - 2018-05-11 23:44:16 --> Loader Class Initialized
DEBUG - 2018-05-11 23:44:16 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-11 23:44:16 --> Helper loaded: url_helper
INFO - 2018-05-11 23:44:16 --> Helper loaded: form_helper
INFO - 2018-05-11 23:44:16 --> Helper loaded: date_helper
INFO - 2018-05-11 23:44:16 --> Helper loaded: util_helper
INFO - 2018-05-11 23:44:16 --> Helper loaded: text_helper
INFO - 2018-05-11 23:44:16 --> Helper loaded: string_helper
INFO - 2018-05-11 23:44:17 --> Database Driver Class Initialized
DEBUG - 2018-05-11 23:44:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-11 23:44:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-11 23:44:17 --> Email Class Initialized
INFO - 2018-05-11 23:44:17 --> Controller Class Initialized
DEBUG - 2018-05-11 23:44:17 --> Programs MX_Controller Initialized
INFO - 2018-05-11 23:44:17 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-11 23:44:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-05-11 23:44:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-11 23:44:17 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-11 23:44:17 --> Login MX_Controller Initialized
DEBUG - 2018-05-11 23:44:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-11 23:44:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-05-11 23:44:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-05-11 23:44:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-05-11 23:44:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-05-11 23:44:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-05-11 23:44:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/programs/programs.php
INFO - 2018-05-11 23:44:17 --> Final output sent to browser
DEBUG - 2018-05-11 23:44:17 --> Total execution time: 0.8899
INFO - 2018-05-11 23:44:18 --> Config Class Initialized
INFO - 2018-05-11 23:44:18 --> Hooks Class Initialized
DEBUG - 2018-05-11 23:44:18 --> UTF-8 Support Enabled
INFO - 2018-05-11 23:44:18 --> Utf8 Class Initialized
INFO - 2018-05-11 23:44:18 --> URI Class Initialized
INFO - 2018-05-11 23:44:18 --> Router Class Initialized
INFO - 2018-05-11 23:44:18 --> Output Class Initialized
INFO - 2018-05-11 23:44:18 --> Security Class Initialized
DEBUG - 2018-05-11 23:44:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 23:44:18 --> Input Class Initialized
INFO - 2018-05-11 23:44:18 --> Language Class Initialized
INFO - 2018-05-11 23:44:18 --> Language Class Initialized
INFO - 2018-05-11 23:44:18 --> Config Class Initialized
INFO - 2018-05-11 23:44:18 --> Loader Class Initialized
DEBUG - 2018-05-11 23:44:18 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-11 23:44:18 --> Helper loaded: url_helper
INFO - 2018-05-11 23:44:18 --> Helper loaded: form_helper
INFO - 2018-05-11 23:44:18 --> Helper loaded: date_helper
INFO - 2018-05-11 23:44:18 --> Helper loaded: util_helper
INFO - 2018-05-11 23:44:18 --> Helper loaded: text_helper
INFO - 2018-05-11 23:44:18 --> Helper loaded: string_helper
INFO - 2018-05-11 23:44:18 --> Database Driver Class Initialized
DEBUG - 2018-05-11 23:44:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-11 23:44:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-11 23:44:18 --> Email Class Initialized
INFO - 2018-05-11 23:44:18 --> Controller Class Initialized
DEBUG - 2018-05-11 23:44:18 --> Programs MX_Controller Initialized
INFO - 2018-05-11 23:44:18 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-11 23:44:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-05-11 23:44:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-11 23:44:19 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-11 23:44:19 --> Login MX_Controller Initialized
DEBUG - 2018-05-11 23:44:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-11 23:44:19 --> Final output sent to browser
DEBUG - 2018-05-11 23:44:19 --> Total execution time: 1.0635
INFO - 2018-05-11 23:45:47 --> Config Class Initialized
INFO - 2018-05-11 23:45:47 --> Hooks Class Initialized
DEBUG - 2018-05-11 23:45:47 --> UTF-8 Support Enabled
INFO - 2018-05-11 23:45:47 --> Utf8 Class Initialized
INFO - 2018-05-11 23:45:47 --> URI Class Initialized
INFO - 2018-05-11 23:45:47 --> Router Class Initialized
INFO - 2018-05-11 23:45:47 --> Output Class Initialized
INFO - 2018-05-11 23:45:47 --> Security Class Initialized
DEBUG - 2018-05-11 23:45:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 23:45:47 --> Input Class Initialized
INFO - 2018-05-11 23:45:47 --> Language Class Initialized
INFO - 2018-05-11 23:45:47 --> Language Class Initialized
INFO - 2018-05-11 23:45:47 --> Config Class Initialized
INFO - 2018-05-11 23:45:47 --> Loader Class Initialized
DEBUG - 2018-05-11 23:45:47 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-11 23:45:47 --> Helper loaded: url_helper
INFO - 2018-05-11 23:45:47 --> Helper loaded: form_helper
INFO - 2018-05-11 23:45:47 --> Helper loaded: date_helper
INFO - 2018-05-11 23:45:47 --> Helper loaded: util_helper
INFO - 2018-05-11 23:45:47 --> Helper loaded: text_helper
INFO - 2018-05-11 23:45:47 --> Helper loaded: string_helper
INFO - 2018-05-11 23:45:47 --> Database Driver Class Initialized
DEBUG - 2018-05-11 23:45:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-11 23:45:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-11 23:45:47 --> Email Class Initialized
INFO - 2018-05-11 23:45:48 --> Controller Class Initialized
DEBUG - 2018-05-11 23:45:48 --> Admin MX_Controller Initialized
INFO - 2018-05-11 23:45:48 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-11 23:45:48 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-11 23:45:48 --> Login MX_Controller Initialized
DEBUG - 2018-05-11 23:45:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-11 23:45:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-11 23:45:48 --> Final output sent to browser
DEBUG - 2018-05-11 23:45:48 --> Total execution time: 0.9999
INFO - 2018-05-11 23:45:49 --> Config Class Initialized
INFO - 2018-05-11 23:45:49 --> Hooks Class Initialized
DEBUG - 2018-05-11 23:45:49 --> UTF-8 Support Enabled
INFO - 2018-05-11 23:45:49 --> Utf8 Class Initialized
INFO - 2018-05-11 23:45:49 --> URI Class Initialized
INFO - 2018-05-11 23:45:49 --> Router Class Initialized
INFO - 2018-05-11 23:45:49 --> Output Class Initialized
INFO - 2018-05-11 23:45:49 --> Security Class Initialized
DEBUG - 2018-05-11 23:45:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 23:45:49 --> Input Class Initialized
INFO - 2018-05-11 23:45:49 --> Language Class Initialized
INFO - 2018-05-11 23:45:49 --> Language Class Initialized
INFO - 2018-05-11 23:45:49 --> Config Class Initialized
INFO - 2018-05-11 23:45:49 --> Loader Class Initialized
DEBUG - 2018-05-11 23:45:49 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-11 23:45:49 --> Helper loaded: url_helper
INFO - 2018-05-11 23:45:49 --> Helper loaded: form_helper
INFO - 2018-05-11 23:45:49 --> Helper loaded: date_helper
INFO - 2018-05-11 23:45:49 --> Helper loaded: util_helper
INFO - 2018-05-11 23:45:50 --> Helper loaded: text_helper
INFO - 2018-05-11 23:45:50 --> Helper loaded: string_helper
INFO - 2018-05-11 23:45:50 --> Database Driver Class Initialized
DEBUG - 2018-05-11 23:45:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-11 23:45:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-11 23:45:50 --> Email Class Initialized
INFO - 2018-05-11 23:45:50 --> Controller Class Initialized
DEBUG - 2018-05-11 23:45:50 --> Admin MX_Controller Initialized
INFO - 2018-05-11 23:45:50 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-11 23:45:50 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-11 23:45:50 --> Login MX_Controller Initialized
DEBUG - 2018-05-11 23:45:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-11 23:45:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-11 23:45:50 --> Final output sent to browser
DEBUG - 2018-05-11 23:45:50 --> Total execution time: 1.0100
INFO - 2018-05-11 23:50:58 --> Config Class Initialized
INFO - 2018-05-11 23:50:58 --> Hooks Class Initialized
DEBUG - 2018-05-11 23:50:58 --> UTF-8 Support Enabled
INFO - 2018-05-11 23:50:58 --> Utf8 Class Initialized
INFO - 2018-05-11 23:50:58 --> URI Class Initialized
INFO - 2018-05-11 23:50:58 --> Router Class Initialized
INFO - 2018-05-11 23:50:58 --> Output Class Initialized
INFO - 2018-05-11 23:50:58 --> Security Class Initialized
DEBUG - 2018-05-11 23:50:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 23:50:58 --> Input Class Initialized
INFO - 2018-05-11 23:50:58 --> Language Class Initialized
INFO - 2018-05-11 23:50:59 --> Language Class Initialized
INFO - 2018-05-11 23:50:59 --> Config Class Initialized
INFO - 2018-05-11 23:50:59 --> Loader Class Initialized
DEBUG - 2018-05-11 23:50:59 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-11 23:50:59 --> Helper loaded: url_helper
INFO - 2018-05-11 23:50:59 --> Helper loaded: form_helper
INFO - 2018-05-11 23:50:59 --> Helper loaded: date_helper
INFO - 2018-05-11 23:50:59 --> Helper loaded: util_helper
INFO - 2018-05-11 23:50:59 --> Helper loaded: text_helper
INFO - 2018-05-11 23:50:59 --> Helper loaded: string_helper
INFO - 2018-05-11 23:50:59 --> Database Driver Class Initialized
DEBUG - 2018-05-11 23:50:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-11 23:50:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-11 23:50:59 --> Email Class Initialized
INFO - 2018-05-11 23:50:59 --> Controller Class Initialized
DEBUG - 2018-05-11 23:50:59 --> Home MX_Controller Initialized
DEBUG - 2018-05-11 23:50:59 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-11 23:50:59 --> Login MX_Controller Initialized
INFO - 2018-05-11 23:50:59 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-11 23:50:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-11 23:50:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-11 23:50:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-05-11 23:50:59 --> Final output sent to browser
INFO - 2018-05-11 23:50:59 --> Config Class Initialized
DEBUG - 2018-05-11 23:50:59 --> Total execution time: 0.8077
INFO - 2018-05-11 23:50:59 --> Hooks Class Initialized
DEBUG - 2018-05-11 23:50:59 --> UTF-8 Support Enabled
INFO - 2018-05-11 23:50:59 --> Utf8 Class Initialized
INFO - 2018-05-11 23:50:59 --> URI Class Initialized
INFO - 2018-05-11 23:50:59 --> Router Class Initialized
INFO - 2018-05-11 23:50:59 --> Output Class Initialized
INFO - 2018-05-11 23:50:59 --> Security Class Initialized
DEBUG - 2018-05-11 23:50:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 23:50:59 --> Input Class Initialized
INFO - 2018-05-11 23:50:59 --> Language Class Initialized
ERROR - 2018-05-11 23:50:59 --> 404 Page Not Found: /index
INFO - 2018-05-11 23:51:00 --> Config Class Initialized
INFO - 2018-05-11 23:51:00 --> Config Class Initialized
INFO - 2018-05-11 23:51:00 --> Config Class Initialized
INFO - 2018-05-11 23:51:00 --> Hooks Class Initialized
INFO - 2018-05-11 23:51:00 --> Hooks Class Initialized
INFO - 2018-05-11 23:51:00 --> Hooks Class Initialized
INFO - 2018-05-11 23:51:00 --> Config Class Initialized
INFO - 2018-05-11 23:51:00 --> Config Class Initialized
INFO - 2018-05-11 23:51:00 --> Config Class Initialized
DEBUG - 2018-05-11 23:51:00 --> UTF-8 Support Enabled
DEBUG - 2018-05-11 23:51:00 --> UTF-8 Support Enabled
INFO - 2018-05-11 23:51:00 --> Hooks Class Initialized
INFO - 2018-05-11 23:51:00 --> Hooks Class Initialized
INFO - 2018-05-11 23:51:00 --> Hooks Class Initialized
DEBUG - 2018-05-11 23:51:00 --> UTF-8 Support Enabled
INFO - 2018-05-11 23:51:00 --> Utf8 Class Initialized
DEBUG - 2018-05-11 23:51:00 --> UTF-8 Support Enabled
INFO - 2018-05-11 23:51:00 --> Utf8 Class Initialized
INFO - 2018-05-11 23:51:00 --> Utf8 Class Initialized
DEBUG - 2018-05-11 23:51:00 --> UTF-8 Support Enabled
DEBUG - 2018-05-11 23:51:00 --> UTF-8 Support Enabled
INFO - 2018-05-11 23:51:00 --> Utf8 Class Initialized
INFO - 2018-05-11 23:51:00 --> URI Class Initialized
INFO - 2018-05-11 23:51:00 --> Utf8 Class Initialized
INFO - 2018-05-11 23:51:00 --> Utf8 Class Initialized
INFO - 2018-05-11 23:51:00 --> URI Class Initialized
INFO - 2018-05-11 23:51:00 --> URI Class Initialized
INFO - 2018-05-11 23:51:00 --> URI Class Initialized
INFO - 2018-05-11 23:51:00 --> URI Class Initialized
INFO - 2018-05-11 23:51:00 --> Router Class Initialized
INFO - 2018-05-11 23:51:00 --> URI Class Initialized
INFO - 2018-05-11 23:51:00 --> Router Class Initialized
INFO - 2018-05-11 23:51:00 --> Router Class Initialized
INFO - 2018-05-11 23:51:01 --> Output Class Initialized
INFO - 2018-05-11 23:51:01 --> Router Class Initialized
INFO - 2018-05-11 23:51:01 --> Output Class Initialized
INFO - 2018-05-11 23:51:01 --> Router Class Initialized
INFO - 2018-05-11 23:51:01 --> Output Class Initialized
INFO - 2018-05-11 23:51:01 --> Router Class Initialized
INFO - 2018-05-11 23:51:01 --> Security Class Initialized
DEBUG - 2018-05-11 23:51:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 23:51:01 --> Output Class Initialized
INFO - 2018-05-11 23:51:01 --> Output Class Initialized
INFO - 2018-05-11 23:51:01 --> Security Class Initialized
INFO - 2018-05-11 23:51:01 --> Security Class Initialized
INFO - 2018-05-11 23:51:01 --> Output Class Initialized
INFO - 2018-05-11 23:51:01 --> Input Class Initialized
INFO - 2018-05-11 23:51:01 --> Security Class Initialized
INFO - 2018-05-11 23:51:01 --> Language Class Initialized
INFO - 2018-05-11 23:51:01 --> Security Class Initialized
DEBUG - 2018-05-11 23:51:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-11 23:51:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 23:51:01 --> Security Class Initialized
DEBUG - 2018-05-11 23:51:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 23:51:01 --> Input Class Initialized
DEBUG - 2018-05-11 23:51:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 23:51:01 --> Input Class Initialized
DEBUG - 2018-05-11 23:51:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 23:51:01 --> Input Class Initialized
ERROR - 2018-05-11 23:51:01 --> 404 Page Not Found: /index
INFO - 2018-05-11 23:51:01 --> Input Class Initialized
INFO - 2018-05-11 23:51:01 --> Language Class Initialized
INFO - 2018-05-11 23:51:01 --> Config Class Initialized
INFO - 2018-05-11 23:51:01 --> Input Class Initialized
INFO - 2018-05-11 23:51:01 --> Language Class Initialized
INFO - 2018-05-11 23:51:01 --> Language Class Initialized
INFO - 2018-05-11 23:51:01 --> Hooks Class Initialized
INFO - 2018-05-11 23:51:01 --> Language Class Initialized
ERROR - 2018-05-11 23:51:01 --> 404 Page Not Found: /index
ERROR - 2018-05-11 23:51:01 --> 404 Page Not Found: /index
ERROR - 2018-05-11 23:51:01 --> 404 Page Not Found: /index
INFO - 2018-05-11 23:51:01 --> Language Class Initialized
ERROR - 2018-05-11 23:51:01 --> 404 Page Not Found: /index
INFO - 2018-05-11 23:51:01 --> Config Class Initialized
DEBUG - 2018-05-11 23:51:01 --> UTF-8 Support Enabled
ERROR - 2018-05-11 23:51:01 --> 404 Page Not Found: /index
INFO - 2018-05-11 23:51:01 --> Config Class Initialized
INFO - 2018-05-11 23:51:01 --> Hooks Class Initialized
INFO - 2018-05-11 23:51:01 --> Hooks Class Initialized
INFO - 2018-05-11 23:51:01 --> Utf8 Class Initialized
INFO - 2018-05-11 23:51:01 --> Config Class Initialized
INFO - 2018-05-11 23:51:01 --> Config Class Initialized
INFO - 2018-05-11 23:51:01 --> Hooks Class Initialized
INFO - 2018-05-11 23:51:01 --> Hooks Class Initialized
DEBUG - 2018-05-11 23:51:01 --> UTF-8 Support Enabled
INFO - 2018-05-11 23:51:01 --> URI Class Initialized
DEBUG - 2018-05-11 23:51:01 --> UTF-8 Support Enabled
INFO - 2018-05-11 23:51:01 --> Utf8 Class Initialized
DEBUG - 2018-05-11 23:51:01 --> UTF-8 Support Enabled
INFO - 2018-05-11 23:51:01 --> Utf8 Class Initialized
DEBUG - 2018-05-11 23:51:01 --> UTF-8 Support Enabled
INFO - 2018-05-11 23:51:01 --> Utf8 Class Initialized
INFO - 2018-05-11 23:51:01 --> Router Class Initialized
INFO - 2018-05-11 23:51:01 --> URI Class Initialized
INFO - 2018-05-11 23:51:01 --> Utf8 Class Initialized
INFO - 2018-05-11 23:51:01 --> URI Class Initialized
INFO - 2018-05-11 23:51:01 --> Output Class Initialized
INFO - 2018-05-11 23:51:01 --> URI Class Initialized
INFO - 2018-05-11 23:51:01 --> Security Class Initialized
INFO - 2018-05-11 23:51:01 --> Router Class Initialized
INFO - 2018-05-11 23:51:01 --> Output Class Initialized
DEBUG - 2018-05-11 23:51:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 23:51:01 --> URI Class Initialized
INFO - 2018-05-11 23:51:01 --> Router Class Initialized
INFO - 2018-05-11 23:51:01 --> Router Class Initialized
INFO - 2018-05-11 23:51:01 --> Input Class Initialized
INFO - 2018-05-11 23:51:01 --> Security Class Initialized
INFO - 2018-05-11 23:51:01 --> Router Class Initialized
DEBUG - 2018-05-11 23:51:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 23:51:01 --> Language Class Initialized
INFO - 2018-05-11 23:51:01 --> Output Class Initialized
INFO - 2018-05-11 23:51:01 --> Output Class Initialized
INFO - 2018-05-11 23:51:01 --> Input Class Initialized
ERROR - 2018-05-11 23:51:01 --> 404 Page Not Found: /index
INFO - 2018-05-11 23:51:01 --> Output Class Initialized
INFO - 2018-05-11 23:51:01 --> Security Class Initialized
INFO - 2018-05-11 23:51:01 --> Security Class Initialized
DEBUG - 2018-05-11 23:51:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 23:51:01 --> Language Class Initialized
INFO - 2018-05-11 23:51:01 --> Config Class Initialized
INFO - 2018-05-11 23:51:01 --> Security Class Initialized
DEBUG - 2018-05-11 23:51:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 23:51:01 --> Hooks Class Initialized
INFO - 2018-05-11 23:51:01 --> Input Class Initialized
INFO - 2018-05-11 23:51:01 --> Language Class Initialized
DEBUG - 2018-05-11 23:51:01 --> UTF-8 Support Enabled
INFO - 2018-05-11 23:51:01 --> Input Class Initialized
DEBUG - 2018-05-11 23:51:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-05-11 23:51:01 --> 404 Page Not Found: /index
INFO - 2018-05-11 23:51:01 --> Utf8 Class Initialized
INFO - 2018-05-11 23:51:01 --> Language Class Initialized
INFO - 2018-05-11 23:51:01 --> Config Class Initialized
ERROR - 2018-05-11 23:51:01 --> 404 Page Not Found: /index
INFO - 2018-05-11 23:51:01 --> Input Class Initialized
INFO - 2018-05-11 23:51:01 --> Hooks Class Initialized
INFO - 2018-05-11 23:51:01 --> URI Class Initialized
ERROR - 2018-05-11 23:51:01 --> 404 Page Not Found: /index
DEBUG - 2018-05-11 23:51:01 --> UTF-8 Support Enabled
INFO - 2018-05-11 23:51:01 --> Router Class Initialized
INFO - 2018-05-11 23:51:01 --> Language Class Initialized
INFO - 2018-05-11 23:51:01 --> Config Class Initialized
INFO - 2018-05-11 23:51:01 --> Config Class Initialized
INFO - 2018-05-11 23:51:01 --> Hooks Class Initialized
INFO - 2018-05-11 23:51:01 --> Utf8 Class Initialized
INFO - 2018-05-11 23:51:01 --> Hooks Class Initialized
INFO - 2018-05-11 23:51:01 --> Output Class Initialized
ERROR - 2018-05-11 23:51:01 --> 404 Page Not Found: /index
INFO - 2018-05-11 23:51:01 --> URI Class Initialized
INFO - 2018-05-11 23:51:01 --> Security Class Initialized
DEBUG - 2018-05-11 23:51:01 --> UTF-8 Support Enabled
DEBUG - 2018-05-11 23:51:01 --> UTF-8 Support Enabled
INFO - 2018-05-11 23:51:01 --> Config Class Initialized
INFO - 2018-05-11 23:51:01 --> Hooks Class Initialized
INFO - 2018-05-11 23:51:01 --> Router Class Initialized
INFO - 2018-05-11 23:51:02 --> Output Class Initialized
DEBUG - 2018-05-11 23:51:02 --> UTF-8 Support Enabled
INFO - 2018-05-11 23:51:02 --> Utf8 Class Initialized
INFO - 2018-05-11 23:51:02 --> Utf8 Class Initialized
DEBUG - 2018-05-11 23:51:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 23:51:02 --> Utf8 Class Initialized
INFO - 2018-05-11 23:51:02 --> URI Class Initialized
INFO - 2018-05-11 23:51:02 --> Security Class Initialized
INFO - 2018-05-11 23:51:02 --> Input Class Initialized
INFO - 2018-05-11 23:51:02 --> URI Class Initialized
INFO - 2018-05-11 23:51:02 --> URI Class Initialized
INFO - 2018-05-11 23:51:02 --> Router Class Initialized
INFO - 2018-05-11 23:51:02 --> Router Class Initialized
INFO - 2018-05-11 23:51:02 --> Output Class Initialized
INFO - 2018-05-11 23:51:02 --> Security Class Initialized
INFO - 2018-05-11 23:51:02 --> Output Class Initialized
INFO - 2018-05-11 23:51:02 --> Language Class Initialized
INFO - 2018-05-11 23:51:02 --> Router Class Initialized
DEBUG - 2018-05-11 23:51:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 23:51:02 --> Security Class Initialized
DEBUG - 2018-05-11 23:51:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 23:51:02 --> Output Class Initialized
ERROR - 2018-05-11 23:51:02 --> 404 Page Not Found: /index
INFO - 2018-05-11 23:51:02 --> Input Class Initialized
INFO - 2018-05-11 23:51:02 --> Input Class Initialized
DEBUG - 2018-05-11 23:51:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 23:51:02 --> Input Class Initialized
INFO - 2018-05-11 23:51:02 --> Language Class Initialized
INFO - 2018-05-11 23:51:02 --> Security Class Initialized
INFO - 2018-05-11 23:51:02 --> Language Class Initialized
ERROR - 2018-05-11 23:51:02 --> 404 Page Not Found: /index
ERROR - 2018-05-11 23:51:02 --> 404 Page Not Found: /index
INFO - 2018-05-11 23:51:02 --> Language Class Initialized
DEBUG - 2018-05-11 23:51:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 23:51:02 --> Input Class Initialized
ERROR - 2018-05-11 23:51:02 --> 404 Page Not Found: /index
INFO - 2018-05-11 23:51:02 --> Language Class Initialized
ERROR - 2018-05-11 23:51:02 --> 404 Page Not Found: /index
INFO - 2018-05-11 23:51:03 --> Config Class Initialized
INFO - 2018-05-11 23:51:03 --> Hooks Class Initialized
DEBUG - 2018-05-11 23:51:03 --> UTF-8 Support Enabled
INFO - 2018-05-11 23:51:03 --> Utf8 Class Initialized
INFO - 2018-05-11 23:51:03 --> URI Class Initialized
INFO - 2018-05-11 23:51:03 --> Router Class Initialized
INFO - 2018-05-11 23:51:03 --> Output Class Initialized
INFO - 2018-05-11 23:51:03 --> Security Class Initialized
DEBUG - 2018-05-11 23:51:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 23:51:03 --> Input Class Initialized
INFO - 2018-05-11 23:51:03 --> Language Class Initialized
ERROR - 2018-05-11 23:51:03 --> 404 Page Not Found: /index
INFO - 2018-05-11 23:51:03 --> Config Class Initialized
INFO - 2018-05-11 23:51:03 --> Hooks Class Initialized
DEBUG - 2018-05-11 23:51:03 --> UTF-8 Support Enabled
INFO - 2018-05-11 23:51:03 --> Utf8 Class Initialized
INFO - 2018-05-11 23:51:03 --> URI Class Initialized
INFO - 2018-05-11 23:51:03 --> Router Class Initialized
INFO - 2018-05-11 23:51:03 --> Output Class Initialized
INFO - 2018-05-11 23:51:03 --> Security Class Initialized
DEBUG - 2018-05-11 23:51:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 23:51:04 --> Input Class Initialized
INFO - 2018-05-11 23:51:04 --> Language Class Initialized
ERROR - 2018-05-11 23:51:04 --> 404 Page Not Found: /index
INFO - 2018-05-11 23:51:04 --> Config Class Initialized
INFO - 2018-05-11 23:51:04 --> Hooks Class Initialized
DEBUG - 2018-05-11 23:51:04 --> UTF-8 Support Enabled
INFO - 2018-05-11 23:51:04 --> Utf8 Class Initialized
INFO - 2018-05-11 23:51:04 --> URI Class Initialized
INFO - 2018-05-11 23:51:04 --> Router Class Initialized
INFO - 2018-05-11 23:51:04 --> Output Class Initialized
INFO - 2018-05-11 23:51:04 --> Security Class Initialized
DEBUG - 2018-05-11 23:51:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 23:51:04 --> Input Class Initialized
INFO - 2018-05-11 23:51:04 --> Language Class Initialized
ERROR - 2018-05-11 23:51:04 --> 404 Page Not Found: /index
INFO - 2018-05-11 23:53:45 --> Config Class Initialized
INFO - 2018-05-11 23:53:45 --> Config Class Initialized
INFO - 2018-05-11 23:53:45 --> Hooks Class Initialized
INFO - 2018-05-11 23:53:45 --> Config Class Initialized
INFO - 2018-05-11 23:53:45 --> Config Class Initialized
INFO - 2018-05-11 23:53:45 --> Hooks Class Initialized
INFO - 2018-05-11 23:53:45 --> Hooks Class Initialized
DEBUG - 2018-05-11 23:53:45 --> UTF-8 Support Enabled
INFO - 2018-05-11 23:53:45 --> Config Class Initialized
INFO - 2018-05-11 23:53:45 --> Hooks Class Initialized
INFO - 2018-05-11 23:53:45 --> Utf8 Class Initialized
DEBUG - 2018-05-11 23:53:45 --> UTF-8 Support Enabled
INFO - 2018-05-11 23:53:45 --> Hooks Class Initialized
DEBUG - 2018-05-11 23:53:45 --> UTF-8 Support Enabled
DEBUG - 2018-05-11 23:53:45 --> UTF-8 Support Enabled
INFO - 2018-05-11 23:53:45 --> Utf8 Class Initialized
INFO - 2018-05-11 23:53:45 --> URI Class Initialized
INFO - 2018-05-11 23:53:45 --> Utf8 Class Initialized
DEBUG - 2018-05-11 23:53:45 --> UTF-8 Support Enabled
INFO - 2018-05-11 23:53:45 --> Utf8 Class Initialized
INFO - 2018-05-11 23:53:45 --> URI Class Initialized
INFO - 2018-05-11 23:53:45 --> Router Class Initialized
INFO - 2018-05-11 23:53:45 --> Output Class Initialized
INFO - 2018-05-11 23:53:45 --> Utf8 Class Initialized
INFO - 2018-05-11 23:53:45 --> URI Class Initialized
INFO - 2018-05-11 23:53:45 --> URI Class Initialized
INFO - 2018-05-11 23:53:45 --> Router Class Initialized
INFO - 2018-05-11 23:53:45 --> Security Class Initialized
INFO - 2018-05-11 23:53:45 --> URI Class Initialized
DEBUG - 2018-05-11 23:53:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 23:53:45 --> Output Class Initialized
INFO - 2018-05-11 23:53:45 --> Router Class Initialized
INFO - 2018-05-11 23:53:45 --> Router Class Initialized
INFO - 2018-05-11 23:53:45 --> Router Class Initialized
INFO - 2018-05-11 23:53:45 --> Input Class Initialized
INFO - 2018-05-11 23:53:46 --> Language Class Initialized
INFO - 2018-05-11 23:53:46 --> Output Class Initialized
INFO - 2018-05-11 23:53:46 --> Security Class Initialized
INFO - 2018-05-11 23:53:46 --> Output Class Initialized
INFO - 2018-05-11 23:53:46 --> Output Class Initialized
ERROR - 2018-05-11 23:53:46 --> 404 Page Not Found: /index
INFO - 2018-05-11 23:53:46 --> Security Class Initialized
INFO - 2018-05-11 23:53:46 --> Security Class Initialized
INFO - 2018-05-11 23:53:46 --> Security Class Initialized
INFO - 2018-05-11 23:53:46 --> Config Class Initialized
DEBUG - 2018-05-11 23:53:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 23:53:46 --> Hooks Class Initialized
DEBUG - 2018-05-11 23:53:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-11 23:53:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-11 23:53:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 23:53:46 --> Input Class Initialized
INFO - 2018-05-11 23:53:46 --> Input Class Initialized
INFO - 2018-05-11 23:53:46 --> Input Class Initialized
INFO - 2018-05-11 23:53:46 --> Input Class Initialized
DEBUG - 2018-05-11 23:53:46 --> UTF-8 Support Enabled
INFO - 2018-05-11 23:53:46 --> Language Class Initialized
INFO - 2018-05-11 23:53:46 --> Language Class Initialized
INFO - 2018-05-11 23:53:46 --> Utf8 Class Initialized
INFO - 2018-05-11 23:53:46 --> Language Class Initialized
INFO - 2018-05-11 23:53:46 --> Language Class Initialized
ERROR - 2018-05-11 23:53:46 --> 404 Page Not Found: /index
ERROR - 2018-05-11 23:53:46 --> 404 Page Not Found: /index
ERROR - 2018-05-11 23:53:46 --> 404 Page Not Found: /index
ERROR - 2018-05-11 23:53:46 --> 404 Page Not Found: /index
INFO - 2018-05-11 23:53:46 --> URI Class Initialized
INFO - 2018-05-11 23:53:46 --> Config Class Initialized
INFO - 2018-05-11 23:53:46 --> Router Class Initialized
INFO - 2018-05-11 23:53:46 --> Config Class Initialized
INFO - 2018-05-11 23:53:46 --> Hooks Class Initialized
INFO - 2018-05-11 23:53:46 --> Hooks Class Initialized
INFO - 2018-05-11 23:53:46 --> Output Class Initialized
INFO - 2018-05-11 23:53:46 --> Config Class Initialized
INFO - 2018-05-11 23:53:46 --> Hooks Class Initialized
DEBUG - 2018-05-11 23:53:46 --> UTF-8 Support Enabled
INFO - 2018-05-11 23:53:46 --> Security Class Initialized
DEBUG - 2018-05-11 23:53:46 --> UTF-8 Support Enabled
DEBUG - 2018-05-11 23:53:46 --> UTF-8 Support Enabled
DEBUG - 2018-05-11 23:53:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 23:53:46 --> Utf8 Class Initialized
INFO - 2018-05-11 23:53:46 --> Utf8 Class Initialized
INFO - 2018-05-11 23:53:46 --> Utf8 Class Initialized
INFO - 2018-05-11 23:53:46 --> URI Class Initialized
INFO - 2018-05-11 23:53:46 --> Input Class Initialized
INFO - 2018-05-11 23:53:46 --> URI Class Initialized
INFO - 2018-05-11 23:53:46 --> URI Class Initialized
INFO - 2018-05-11 23:53:46 --> Language Class Initialized
INFO - 2018-05-11 23:53:46 --> Router Class Initialized
INFO - 2018-05-11 23:53:46 --> Router Class Initialized
INFO - 2018-05-11 23:53:46 --> Router Class Initialized
INFO - 2018-05-11 23:53:46 --> Output Class Initialized
ERROR - 2018-05-11 23:53:46 --> 404 Page Not Found: /index
INFO - 2018-05-11 23:53:46 --> Output Class Initialized
INFO - 2018-05-11 23:53:46 --> Output Class Initialized
INFO - 2018-05-11 23:53:46 --> Config Class Initialized
INFO - 2018-05-11 23:53:46 --> Security Class Initialized
INFO - 2018-05-11 23:53:46 --> Security Class Initialized
INFO - 2018-05-11 23:53:46 --> Security Class Initialized
DEBUG - 2018-05-11 23:53:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 23:53:46 --> Hooks Class Initialized
DEBUG - 2018-05-11 23:53:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-11 23:53:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-11 23:53:46 --> UTF-8 Support Enabled
INFO - 2018-05-11 23:53:46 --> Input Class Initialized
INFO - 2018-05-11 23:53:46 --> Input Class Initialized
INFO - 2018-05-11 23:53:46 --> Input Class Initialized
INFO - 2018-05-11 23:53:46 --> Utf8 Class Initialized
INFO - 2018-05-11 23:53:46 --> Language Class Initialized
INFO - 2018-05-11 23:53:46 --> Language Class Initialized
INFO - 2018-05-11 23:53:46 --> Language Class Initialized
ERROR - 2018-05-11 23:53:46 --> 404 Page Not Found: /index
ERROR - 2018-05-11 23:53:46 --> 404 Page Not Found: /index
ERROR - 2018-05-11 23:53:46 --> 404 Page Not Found: /index
INFO - 2018-05-11 23:53:46 --> URI Class Initialized
INFO - 2018-05-11 23:53:46 --> Config Class Initialized
INFO - 2018-05-11 23:53:46 --> Config Class Initialized
INFO - 2018-05-11 23:53:46 --> Router Class Initialized
INFO - 2018-05-11 23:53:46 --> Config Class Initialized
INFO - 2018-05-11 23:53:46 --> Hooks Class Initialized
INFO - 2018-05-11 23:53:46 --> Hooks Class Initialized
INFO - 2018-05-11 23:53:46 --> Hooks Class Initialized
INFO - 2018-05-11 23:53:46 --> Output Class Initialized
DEBUG - 2018-05-11 23:53:46 --> UTF-8 Support Enabled
DEBUG - 2018-05-11 23:53:46 --> UTF-8 Support Enabled
DEBUG - 2018-05-11 23:53:46 --> UTF-8 Support Enabled
INFO - 2018-05-11 23:53:46 --> Security Class Initialized
INFO - 2018-05-11 23:53:46 --> Utf8 Class Initialized
DEBUG - 2018-05-11 23:53:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 23:53:46 --> Utf8 Class Initialized
INFO - 2018-05-11 23:53:46 --> Utf8 Class Initialized
INFO - 2018-05-11 23:53:46 --> URI Class Initialized
INFO - 2018-05-11 23:53:46 --> Input Class Initialized
INFO - 2018-05-11 23:53:46 --> URI Class Initialized
INFO - 2018-05-11 23:53:46 --> URI Class Initialized
INFO - 2018-05-11 23:53:46 --> Router Class Initialized
INFO - 2018-05-11 23:53:46 --> Language Class Initialized
INFO - 2018-05-11 23:53:46 --> Output Class Initialized
INFO - 2018-05-11 23:53:46 --> Router Class Initialized
INFO - 2018-05-11 23:53:46 --> Router Class Initialized
ERROR - 2018-05-11 23:53:46 --> 404 Page Not Found: /index
INFO - 2018-05-11 23:53:46 --> Output Class Initialized
INFO - 2018-05-11 23:53:46 --> Output Class Initialized
INFO - 2018-05-11 23:53:46 --> Security Class Initialized
INFO - 2018-05-11 23:53:46 --> Security Class Initialized
INFO - 2018-05-11 23:53:46 --> Security Class Initialized
DEBUG - 2018-05-11 23:53:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-11 23:53:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 23:53:46 --> Input Class Initialized
INFO - 2018-05-11 23:53:46 --> Input Class Initialized
DEBUG - 2018-05-11 23:53:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 23:53:46 --> Language Class Initialized
INFO - 2018-05-11 23:53:46 --> Language Class Initialized
INFO - 2018-05-11 23:53:46 --> Input Class Initialized
ERROR - 2018-05-11 23:53:46 --> 404 Page Not Found: /index
INFO - 2018-05-11 23:53:47 --> Language Class Initialized
ERROR - 2018-05-11 23:53:47 --> 404 Page Not Found: /index
ERROR - 2018-05-11 23:53:47 --> 404 Page Not Found: /index
INFO - 2018-05-11 23:54:17 --> Config Class Initialized
INFO - 2018-05-11 23:54:17 --> Hooks Class Initialized
DEBUG - 2018-05-11 23:54:17 --> UTF-8 Support Enabled
INFO - 2018-05-11 23:54:17 --> Utf8 Class Initialized
INFO - 2018-05-11 23:54:17 --> URI Class Initialized
INFO - 2018-05-11 23:54:17 --> Router Class Initialized
INFO - 2018-05-11 23:54:17 --> Output Class Initialized
INFO - 2018-05-11 23:54:17 --> Security Class Initialized
DEBUG - 2018-05-11 23:54:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 23:54:17 --> Input Class Initialized
INFO - 2018-05-11 23:54:17 --> Language Class Initialized
INFO - 2018-05-11 23:54:17 --> Config Class Initialized
INFO - 2018-05-11 23:54:17 --> Config Class Initialized
INFO - 2018-05-11 23:54:18 --> Config Class Initialized
ERROR - 2018-05-11 23:54:18 --> 404 Page Not Found: /index
INFO - 2018-05-11 23:54:18 --> Hooks Class Initialized
INFO - 2018-05-11 23:54:18 --> Config Class Initialized
INFO - 2018-05-11 23:54:18 --> Hooks Class Initialized
INFO - 2018-05-11 23:54:18 --> Hooks Class Initialized
DEBUG - 2018-05-11 23:54:18 --> UTF-8 Support Enabled
INFO - 2018-05-11 23:54:18 --> Config Class Initialized
INFO - 2018-05-11 23:54:18 --> Hooks Class Initialized
DEBUG - 2018-05-11 23:54:18 --> UTF-8 Support Enabled
INFO - 2018-05-11 23:54:18 --> Utf8 Class Initialized
DEBUG - 2018-05-11 23:54:18 --> UTF-8 Support Enabled
INFO - 2018-05-11 23:54:18 --> Hooks Class Initialized
DEBUG - 2018-05-11 23:54:18 --> UTF-8 Support Enabled
INFO - 2018-05-11 23:54:18 --> Utf8 Class Initialized
INFO - 2018-05-11 23:54:18 --> Utf8 Class Initialized
INFO - 2018-05-11 23:54:18 --> Utf8 Class Initialized
INFO - 2018-05-11 23:54:18 --> URI Class Initialized
DEBUG - 2018-05-11 23:54:18 --> UTF-8 Support Enabled
INFO - 2018-05-11 23:54:18 --> URI Class Initialized
INFO - 2018-05-11 23:54:18 --> URI Class Initialized
INFO - 2018-05-11 23:54:18 --> Router Class Initialized
INFO - 2018-05-11 23:54:18 --> Output Class Initialized
INFO - 2018-05-11 23:54:18 --> Security Class Initialized
INFO - 2018-05-11 23:54:18 --> Router Class Initialized
INFO - 2018-05-11 23:54:18 --> Utf8 Class Initialized
INFO - 2018-05-11 23:54:18 --> Router Class Initialized
DEBUG - 2018-05-11 23:54:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 23:54:18 --> URI Class Initialized
INFO - 2018-05-11 23:54:18 --> Output Class Initialized
INFO - 2018-05-11 23:54:18 --> Input Class Initialized
INFO - 2018-05-11 23:54:18 --> Router Class Initialized
INFO - 2018-05-11 23:54:18 --> URI Class Initialized
INFO - 2018-05-11 23:54:18 --> Security Class Initialized
INFO - 2018-05-11 23:54:18 --> Output Class Initialized
INFO - 2018-05-11 23:54:18 --> Security Class Initialized
INFO - 2018-05-11 23:54:18 --> Output Class Initialized
DEBUG - 2018-05-11 23:54:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 23:54:18 --> Language Class Initialized
INFO - 2018-05-11 23:54:18 --> Router Class Initialized
INFO - 2018-05-11 23:54:18 --> Security Class Initialized
INFO - 2018-05-11 23:54:18 --> Input Class Initialized
ERROR - 2018-05-11 23:54:18 --> 404 Page Not Found: /index
INFO - 2018-05-11 23:54:18 --> Output Class Initialized
DEBUG - 2018-05-11 23:54:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 23:54:18 --> Input Class Initialized
DEBUG - 2018-05-11 23:54:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 23:54:18 --> Language Class Initialized
INFO - 2018-05-11 23:54:18 --> Security Class Initialized
INFO - 2018-05-11 23:54:18 --> Config Class Initialized
INFO - 2018-05-11 23:54:18 --> Hooks Class Initialized
INFO - 2018-05-11 23:54:18 --> Language Class Initialized
DEBUG - 2018-05-11 23:54:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-05-11 23:54:18 --> 404 Page Not Found: /index
INFO - 2018-05-11 23:54:18 --> Input Class Initialized
ERROR - 2018-05-11 23:54:18 --> 404 Page Not Found: /index
INFO - 2018-05-11 23:54:18 --> Input Class Initialized
DEBUG - 2018-05-11 23:54:18 --> UTF-8 Support Enabled
INFO - 2018-05-11 23:54:18 --> Config Class Initialized
INFO - 2018-05-11 23:54:18 --> Language Class Initialized
INFO - 2018-05-11 23:54:18 --> Language Class Initialized
INFO - 2018-05-11 23:54:18 --> Hooks Class Initialized
INFO - 2018-05-11 23:54:18 --> Utf8 Class Initialized
ERROR - 2018-05-11 23:54:18 --> 404 Page Not Found: /index
INFO - 2018-05-11 23:54:18 --> Config Class Initialized
INFO - 2018-05-11 23:54:18 --> URI Class Initialized
DEBUG - 2018-05-11 23:54:18 --> UTF-8 Support Enabled
INFO - 2018-05-11 23:54:18 --> Config Class Initialized
ERROR - 2018-05-11 23:54:18 --> 404 Page Not Found: /index
INFO - 2018-05-11 23:54:18 --> Hooks Class Initialized
INFO - 2018-05-11 23:54:18 --> Utf8 Class Initialized
INFO - 2018-05-11 23:54:18 --> Router Class Initialized
INFO - 2018-05-11 23:54:18 --> Hooks Class Initialized
INFO - 2018-05-11 23:54:18 --> Output Class Initialized
INFO - 2018-05-11 23:54:18 --> URI Class Initialized
DEBUG - 2018-05-11 23:54:18 --> UTF-8 Support Enabled
DEBUG - 2018-05-11 23:54:18 --> UTF-8 Support Enabled
INFO - 2018-05-11 23:54:18 --> Utf8 Class Initialized
INFO - 2018-05-11 23:54:18 --> Router Class Initialized
INFO - 2018-05-11 23:54:18 --> Security Class Initialized
INFO - 2018-05-11 23:54:18 --> Utf8 Class Initialized
INFO - 2018-05-11 23:54:18 --> URI Class Initialized
INFO - 2018-05-11 23:54:18 --> Output Class Initialized
INFO - 2018-05-11 23:54:18 --> URI Class Initialized
DEBUG - 2018-05-11 23:54:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 23:54:18 --> Security Class Initialized
INFO - 2018-05-11 23:54:18 --> Router Class Initialized
INFO - 2018-05-11 23:54:18 --> Router Class Initialized
DEBUG - 2018-05-11 23:54:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 23:54:18 --> Input Class Initialized
INFO - 2018-05-11 23:54:18 --> Output Class Initialized
INFO - 2018-05-11 23:54:18 --> Input Class Initialized
INFO - 2018-05-11 23:54:18 --> Output Class Initialized
INFO - 2018-05-11 23:54:18 --> Language Class Initialized
INFO - 2018-05-11 23:54:18 --> Security Class Initialized
INFO - 2018-05-11 23:54:18 --> Language Class Initialized
INFO - 2018-05-11 23:54:18 --> Security Class Initialized
ERROR - 2018-05-11 23:54:18 --> 404 Page Not Found: /index
DEBUG - 2018-05-11 23:54:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 23:54:19 --> Config Class Initialized
INFO - 2018-05-11 23:54:19 --> Hooks Class Initialized
INFO - 2018-05-11 23:54:19 --> Input Class Initialized
DEBUG - 2018-05-11 23:54:19 --> UTF-8 Support Enabled
DEBUG - 2018-05-11 23:54:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 23:54:19 --> Language Class Initialized
ERROR - 2018-05-11 23:54:19 --> 404 Page Not Found: /index
INFO - 2018-05-11 23:54:19 --> Utf8 Class Initialized
ERROR - 2018-05-11 23:54:19 --> 404 Page Not Found: /index
INFO - 2018-05-11 23:54:19 --> Input Class Initialized
INFO - 2018-05-11 23:54:19 --> Config Class Initialized
INFO - 2018-05-11 23:54:19 --> URI Class Initialized
INFO - 2018-05-11 23:54:19 --> Hooks Class Initialized
INFO - 2018-05-11 23:54:19 --> Language Class Initialized
INFO - 2018-05-11 23:54:19 --> Router Class Initialized
INFO - 2018-05-11 23:54:19 --> Config Class Initialized
DEBUG - 2018-05-11 23:54:19 --> UTF-8 Support Enabled
INFO - 2018-05-11 23:54:19 --> Hooks Class Initialized
INFO - 2018-05-11 23:54:19 --> Utf8 Class Initialized
ERROR - 2018-05-11 23:54:19 --> 404 Page Not Found: /index
INFO - 2018-05-11 23:54:19 --> Output Class Initialized
INFO - 2018-05-11 23:54:19 --> URI Class Initialized
INFO - 2018-05-11 23:54:19 --> Security Class Initialized
DEBUG - 2018-05-11 23:54:19 --> UTF-8 Support Enabled
INFO - 2018-05-11 23:54:19 --> Config Class Initialized
INFO - 2018-05-11 23:54:19 --> Hooks Class Initialized
INFO - 2018-05-11 23:54:19 --> Router Class Initialized
INFO - 2018-05-11 23:54:19 --> Utf8 Class Initialized
DEBUG - 2018-05-11 23:54:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 23:54:19 --> Input Class Initialized
DEBUG - 2018-05-11 23:54:19 --> UTF-8 Support Enabled
INFO - 2018-05-11 23:54:19 --> Output Class Initialized
INFO - 2018-05-11 23:54:19 --> Language Class Initialized
INFO - 2018-05-11 23:54:19 --> Utf8 Class Initialized
INFO - 2018-05-11 23:54:19 --> Security Class Initialized
INFO - 2018-05-11 23:54:19 --> URI Class Initialized
ERROR - 2018-05-11 23:54:19 --> 404 Page Not Found: /index
DEBUG - 2018-05-11 23:54:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 23:54:19 --> URI Class Initialized
INFO - 2018-05-11 23:54:19 --> Router Class Initialized
INFO - 2018-05-11 23:54:19 --> Output Class Initialized
INFO - 2018-05-11 23:54:19 --> Security Class Initialized
INFO - 2018-05-11 23:54:19 --> Input Class Initialized
INFO - 2018-05-11 23:54:19 --> Router Class Initialized
INFO - 2018-05-11 23:54:19 --> Output Class Initialized
DEBUG - 2018-05-11 23:54:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-11 23:54:19 --> Language Class Initialized
INFO - 2018-05-11 23:54:19 --> Input Class Initialized
INFO - 2018-05-11 23:54:19 --> Security Class Initialized
ERROR - 2018-05-11 23:54:19 --> 404 Page Not Found: /index
INFO - 2018-05-11 23:54:19 --> Language Class Initialized
DEBUG - 2018-05-11 23:54:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-05-11 23:54:19 --> 404 Page Not Found: /index
INFO - 2018-05-11 23:54:19 --> Input Class Initialized
INFO - 2018-05-11 23:54:19 --> Language Class Initialized
ERROR - 2018-05-11 23:54:19 --> 404 Page Not Found: /index
