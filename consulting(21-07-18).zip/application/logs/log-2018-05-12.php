<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-05-12 00:33:49 --> Config Class Initialized
INFO - 2018-05-12 00:33:49 --> Hooks Class Initialized
DEBUG - 2018-05-12 00:33:49 --> UTF-8 Support Enabled
INFO - 2018-05-12 00:33:49 --> Utf8 Class Initialized
INFO - 2018-05-12 00:33:49 --> URI Class Initialized
INFO - 2018-05-12 00:33:49 --> Router Class Initialized
INFO - 2018-05-12 00:33:49 --> Output Class Initialized
INFO - 2018-05-12 00:33:49 --> Security Class Initialized
DEBUG - 2018-05-12 00:33:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 00:33:49 --> Input Class Initialized
INFO - 2018-05-12 00:33:49 --> Language Class Initialized
INFO - 2018-05-12 00:33:49 --> Language Class Initialized
INFO - 2018-05-12 00:33:49 --> Config Class Initialized
INFO - 2018-05-12 00:33:49 --> Loader Class Initialized
DEBUG - 2018-05-12 00:33:49 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-12 00:33:49 --> Helper loaded: url_helper
INFO - 2018-05-12 00:33:49 --> Helper loaded: form_helper
INFO - 2018-05-12 00:33:49 --> Helper loaded: date_helper
INFO - 2018-05-12 00:33:49 --> Helper loaded: util_helper
INFO - 2018-05-12 00:33:49 --> Helper loaded: text_helper
INFO - 2018-05-12 00:33:49 --> Helper loaded: string_helper
INFO - 2018-05-12 00:33:49 --> Database Driver Class Initialized
DEBUG - 2018-05-12 00:33:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-12 00:33:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-12 00:33:49 --> Email Class Initialized
INFO - 2018-05-12 00:33:49 --> Controller Class Initialized
DEBUG - 2018-05-12 00:33:49 --> Home MX_Controller Initialized
DEBUG - 2018-05-12 00:33:49 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-12 00:33:49 --> Login MX_Controller Initialized
INFO - 2018-05-12 00:33:49 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-12 00:33:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-12 00:33:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-12 00:33:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-05-12 00:33:49 --> Final output sent to browser
DEBUG - 2018-05-12 00:33:49 --> Total execution time: 0.3527
INFO - 2018-05-12 00:33:50 --> Config Class Initialized
INFO - 2018-05-12 00:33:50 --> Hooks Class Initialized
DEBUG - 2018-05-12 00:33:50 --> UTF-8 Support Enabled
INFO - 2018-05-12 00:33:50 --> Utf8 Class Initialized
INFO - 2018-05-12 00:33:50 --> URI Class Initialized
INFO - 2018-05-12 00:33:50 --> Router Class Initialized
INFO - 2018-05-12 00:33:50 --> Output Class Initialized
INFO - 2018-05-12 00:33:50 --> Security Class Initialized
DEBUG - 2018-05-12 00:33:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 00:33:50 --> Input Class Initialized
INFO - 2018-05-12 00:33:50 --> Language Class Initialized
ERROR - 2018-05-12 00:33:50 --> 404 Page Not Found: /index
INFO - 2018-05-12 00:33:50 --> Config Class Initialized
INFO - 2018-05-12 00:33:50 --> Hooks Class Initialized
DEBUG - 2018-05-12 00:33:50 --> UTF-8 Support Enabled
INFO - 2018-05-12 00:33:50 --> Utf8 Class Initialized
INFO - 2018-05-12 00:33:50 --> URI Class Initialized
INFO - 2018-05-12 00:33:51 --> Router Class Initialized
INFO - 2018-05-12 00:33:51 --> Output Class Initialized
INFO - 2018-05-12 00:33:51 --> Security Class Initialized
DEBUG - 2018-05-12 00:33:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 00:33:51 --> Input Class Initialized
INFO - 2018-05-12 00:33:51 --> Language Class Initialized
ERROR - 2018-05-12 00:33:51 --> 404 Page Not Found: /index
INFO - 2018-05-12 00:33:51 --> Config Class Initialized
INFO - 2018-05-12 00:33:51 --> Hooks Class Initialized
DEBUG - 2018-05-12 00:33:51 --> UTF-8 Support Enabled
INFO - 2018-05-12 00:33:51 --> Utf8 Class Initialized
INFO - 2018-05-12 00:33:51 --> URI Class Initialized
INFO - 2018-05-12 00:33:51 --> Router Class Initialized
INFO - 2018-05-12 00:33:51 --> Output Class Initialized
INFO - 2018-05-12 00:33:51 --> Security Class Initialized
DEBUG - 2018-05-12 00:33:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 00:33:51 --> Input Class Initialized
INFO - 2018-05-12 00:33:51 --> Language Class Initialized
ERROR - 2018-05-12 00:33:51 --> 404 Page Not Found: /index
INFO - 2018-05-12 00:35:53 --> Config Class Initialized
INFO - 2018-05-12 00:35:53 --> Hooks Class Initialized
DEBUG - 2018-05-12 00:35:53 --> UTF-8 Support Enabled
INFO - 2018-05-12 00:35:53 --> Utf8 Class Initialized
INFO - 2018-05-12 00:35:53 --> URI Class Initialized
INFO - 2018-05-12 00:35:53 --> Router Class Initialized
INFO - 2018-05-12 00:35:53 --> Output Class Initialized
INFO - 2018-05-12 00:35:53 --> Security Class Initialized
DEBUG - 2018-05-12 00:35:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 00:35:53 --> Input Class Initialized
INFO - 2018-05-12 00:35:53 --> Language Class Initialized
INFO - 2018-05-12 00:35:53 --> Language Class Initialized
INFO - 2018-05-12 00:35:53 --> Config Class Initialized
INFO - 2018-05-12 00:35:53 --> Loader Class Initialized
DEBUG - 2018-05-12 00:35:53 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-12 00:35:53 --> Helper loaded: url_helper
INFO - 2018-05-12 00:35:53 --> Helper loaded: form_helper
INFO - 2018-05-12 00:35:53 --> Helper loaded: date_helper
INFO - 2018-05-12 00:35:53 --> Helper loaded: util_helper
INFO - 2018-05-12 00:35:53 --> Helper loaded: text_helper
INFO - 2018-05-12 00:35:53 --> Helper loaded: string_helper
INFO - 2018-05-12 00:35:53 --> Database Driver Class Initialized
DEBUG - 2018-05-12 00:35:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-12 00:35:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-12 00:35:53 --> Email Class Initialized
INFO - 2018-05-12 00:35:53 --> Controller Class Initialized
DEBUG - 2018-05-12 00:35:53 --> Admin MX_Controller Initialized
INFO - 2018-05-12 00:35:53 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-12 00:35:53 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-12 00:35:53 --> Login MX_Controller Initialized
DEBUG - 2018-05-12 00:35:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-12 00:35:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-12 00:35:53 --> Final output sent to browser
DEBUG - 2018-05-12 00:35:53 --> Total execution time: 0.4378
INFO - 2018-05-12 00:35:55 --> Config Class Initialized
INFO - 2018-05-12 00:35:55 --> Hooks Class Initialized
DEBUG - 2018-05-12 00:35:55 --> UTF-8 Support Enabled
INFO - 2018-05-12 00:35:55 --> Utf8 Class Initialized
INFO - 2018-05-12 00:35:55 --> URI Class Initialized
INFO - 2018-05-12 00:35:55 --> Router Class Initialized
INFO - 2018-05-12 00:35:55 --> Output Class Initialized
INFO - 2018-05-12 00:35:55 --> Security Class Initialized
DEBUG - 2018-05-12 00:35:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 00:35:55 --> Input Class Initialized
INFO - 2018-05-12 00:35:55 --> Language Class Initialized
INFO - 2018-05-12 00:35:55 --> Language Class Initialized
INFO - 2018-05-12 00:35:55 --> Config Class Initialized
INFO - 2018-05-12 00:35:55 --> Loader Class Initialized
DEBUG - 2018-05-12 00:35:55 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-12 00:35:55 --> Helper loaded: url_helper
INFO - 2018-05-12 00:35:55 --> Helper loaded: form_helper
INFO - 2018-05-12 00:35:55 --> Helper loaded: date_helper
INFO - 2018-05-12 00:35:55 --> Helper loaded: util_helper
INFO - 2018-05-12 00:35:55 --> Helper loaded: text_helper
INFO - 2018-05-12 00:35:55 --> Helper loaded: string_helper
INFO - 2018-05-12 00:35:55 --> Database Driver Class Initialized
DEBUG - 2018-05-12 00:35:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-12 00:35:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-12 00:35:55 --> Email Class Initialized
INFO - 2018-05-12 00:35:55 --> Controller Class Initialized
DEBUG - 2018-05-12 00:35:55 --> Admin MX_Controller Initialized
INFO - 2018-05-12 00:35:55 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-12 00:35:55 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-12 00:35:55 --> Login MX_Controller Initialized
DEBUG - 2018-05-12 00:35:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-12 00:35:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-12 00:35:55 --> Final output sent to browser
DEBUG - 2018-05-12 00:35:55 --> Total execution time: 0.4242
INFO - 2018-05-12 00:36:02 --> Config Class Initialized
INFO - 2018-05-12 00:36:02 --> Hooks Class Initialized
DEBUG - 2018-05-12 00:36:02 --> UTF-8 Support Enabled
INFO - 2018-05-12 00:36:02 --> Utf8 Class Initialized
INFO - 2018-05-12 00:36:02 --> URI Class Initialized
INFO - 2018-05-12 00:36:02 --> Router Class Initialized
INFO - 2018-05-12 00:36:02 --> Output Class Initialized
INFO - 2018-05-12 00:36:02 --> Security Class Initialized
DEBUG - 2018-05-12 00:36:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 00:36:02 --> Input Class Initialized
INFO - 2018-05-12 00:36:02 --> Language Class Initialized
INFO - 2018-05-12 00:36:02 --> Language Class Initialized
INFO - 2018-05-12 00:36:02 --> Config Class Initialized
INFO - 2018-05-12 00:36:02 --> Loader Class Initialized
DEBUG - 2018-05-12 00:36:02 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-12 00:36:02 --> Helper loaded: url_helper
INFO - 2018-05-12 00:36:02 --> Helper loaded: form_helper
INFO - 2018-05-12 00:36:02 --> Helper loaded: date_helper
INFO - 2018-05-12 00:36:02 --> Helper loaded: util_helper
INFO - 2018-05-12 00:36:02 --> Helper loaded: text_helper
INFO - 2018-05-12 00:36:02 --> Helper loaded: string_helper
INFO - 2018-05-12 00:36:02 --> Database Driver Class Initialized
DEBUG - 2018-05-12 00:36:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-12 00:36:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-12 00:36:02 --> Email Class Initialized
INFO - 2018-05-12 00:36:02 --> Controller Class Initialized
DEBUG - 2018-05-12 00:36:02 --> Profile MX_Controller Initialized
INFO - 2018-05-12 00:36:02 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-12 00:36:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-12 00:36:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Profile_model.php
DEBUG - 2018-05-12 00:36:02 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-12 00:36:02 --> Login MX_Controller Initialized
DEBUG - 2018-05-12 00:36:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-12 00:36:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-05-12 00:36:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-05-12 00:36:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-05-12 00:36:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-05-12 00:36:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-05-12 00:36:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/admin_password.php
INFO - 2018-05-12 00:36:02 --> Final output sent to browser
DEBUG - 2018-05-12 00:36:02 --> Total execution time: 0.3876
INFO - 2018-05-12 00:36:05 --> Config Class Initialized
INFO - 2018-05-12 00:36:05 --> Hooks Class Initialized
DEBUG - 2018-05-12 00:36:05 --> UTF-8 Support Enabled
INFO - 2018-05-12 00:36:05 --> Utf8 Class Initialized
INFO - 2018-05-12 00:36:05 --> URI Class Initialized
INFO - 2018-05-12 00:36:05 --> Router Class Initialized
INFO - 2018-05-12 00:36:05 --> Output Class Initialized
INFO - 2018-05-12 00:36:05 --> Security Class Initialized
DEBUG - 2018-05-12 00:36:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 00:36:05 --> Input Class Initialized
INFO - 2018-05-12 00:36:05 --> Language Class Initialized
INFO - 2018-05-12 00:36:05 --> Language Class Initialized
INFO - 2018-05-12 00:36:05 --> Config Class Initialized
INFO - 2018-05-12 00:36:05 --> Loader Class Initialized
DEBUG - 2018-05-12 00:36:05 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-12 00:36:05 --> Helper loaded: url_helper
INFO - 2018-05-12 00:36:05 --> Helper loaded: form_helper
INFO - 2018-05-12 00:36:05 --> Helper loaded: date_helper
INFO - 2018-05-12 00:36:05 --> Helper loaded: util_helper
INFO - 2018-05-12 00:36:05 --> Helper loaded: text_helper
INFO - 2018-05-12 00:36:05 --> Helper loaded: string_helper
INFO - 2018-05-12 00:36:05 --> Database Driver Class Initialized
DEBUG - 2018-05-12 00:36:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-12 00:36:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-12 00:36:05 --> Email Class Initialized
INFO - 2018-05-12 00:36:05 --> Controller Class Initialized
DEBUG - 2018-05-12 00:36:05 --> Admin MX_Controller Initialized
INFO - 2018-05-12 00:36:05 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-12 00:36:05 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-12 00:36:05 --> Login MX_Controller Initialized
DEBUG - 2018-05-12 00:36:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-12 00:36:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-12 00:36:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-05-12 00:36:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-05-12 00:36:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-05-12 00:36:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-05-12 00:36:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-05-12 00:36:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/dashboard.php
INFO - 2018-05-12 00:36:05 --> Final output sent to browser
DEBUG - 2018-05-12 00:36:05 --> Total execution time: 0.3914
INFO - 2018-05-12 00:36:05 --> Config Class Initialized
INFO - 2018-05-12 00:36:05 --> Hooks Class Initialized
INFO - 2018-05-12 00:36:05 --> Config Class Initialized
INFO - 2018-05-12 00:36:05 --> Hooks Class Initialized
DEBUG - 2018-05-12 00:36:05 --> UTF-8 Support Enabled
INFO - 2018-05-12 00:36:05 --> Utf8 Class Initialized
DEBUG - 2018-05-12 00:36:05 --> UTF-8 Support Enabled
INFO - 2018-05-12 00:36:05 --> Utf8 Class Initialized
INFO - 2018-05-12 00:36:05 --> URI Class Initialized
INFO - 2018-05-12 00:36:05 --> URI Class Initialized
INFO - 2018-05-12 00:36:05 --> Router Class Initialized
INFO - 2018-05-12 00:36:05 --> Output Class Initialized
INFO - 2018-05-12 00:36:05 --> Router Class Initialized
INFO - 2018-05-12 00:36:05 --> Security Class Initialized
INFO - 2018-05-12 00:36:05 --> Output Class Initialized
DEBUG - 2018-05-12 00:36:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 00:36:05 --> Security Class Initialized
INFO - 2018-05-12 00:36:05 --> Input Class Initialized
DEBUG - 2018-05-12 00:36:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 00:36:05 --> Language Class Initialized
INFO - 2018-05-12 00:36:05 --> Input Class Initialized
ERROR - 2018-05-12 00:36:05 --> 404 Page Not Found: /index
INFO - 2018-05-12 00:36:05 --> Language Class Initialized
ERROR - 2018-05-12 00:36:05 --> 404 Page Not Found: /index
INFO - 2018-05-12 00:36:08 --> Config Class Initialized
INFO - 2018-05-12 00:36:08 --> Hooks Class Initialized
DEBUG - 2018-05-12 00:36:08 --> UTF-8 Support Enabled
INFO - 2018-05-12 00:36:08 --> Utf8 Class Initialized
INFO - 2018-05-12 00:36:08 --> URI Class Initialized
INFO - 2018-05-12 00:36:08 --> Router Class Initialized
INFO - 2018-05-12 00:36:08 --> Output Class Initialized
INFO - 2018-05-12 00:36:08 --> Security Class Initialized
DEBUG - 2018-05-12 00:36:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 00:36:08 --> Input Class Initialized
INFO - 2018-05-12 00:36:08 --> Language Class Initialized
INFO - 2018-05-12 00:36:08 --> Language Class Initialized
INFO - 2018-05-12 00:36:08 --> Config Class Initialized
INFO - 2018-05-12 00:36:08 --> Loader Class Initialized
DEBUG - 2018-05-12 00:36:08 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-12 00:36:08 --> Helper loaded: url_helper
INFO - 2018-05-12 00:36:08 --> Helper loaded: form_helper
INFO - 2018-05-12 00:36:08 --> Helper loaded: date_helper
INFO - 2018-05-12 00:36:08 --> Helper loaded: util_helper
INFO - 2018-05-12 00:36:08 --> Helper loaded: text_helper
INFO - 2018-05-12 00:36:08 --> Helper loaded: string_helper
INFO - 2018-05-12 00:36:08 --> Database Driver Class Initialized
DEBUG - 2018-05-12 00:36:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-12 00:36:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-12 00:36:08 --> Email Class Initialized
INFO - 2018-05-12 00:36:08 --> Controller Class Initialized
DEBUG - 2018-05-12 00:36:08 --> Programs MX_Controller Initialized
INFO - 2018-05-12 00:36:08 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-12 00:36:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-05-12 00:36:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-12 00:36:08 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-12 00:36:08 --> Login MX_Controller Initialized
DEBUG - 2018-05-12 00:36:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-12 00:36:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-05-12 00:36:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-05-12 00:36:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-05-12 00:36:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-05-12 00:36:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-05-12 00:36:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/programs/programs.php
INFO - 2018-05-12 00:36:08 --> Final output sent to browser
DEBUG - 2018-05-12 00:36:08 --> Total execution time: 0.4014
INFO - 2018-05-12 00:36:08 --> Config Class Initialized
INFO - 2018-05-12 00:36:08 --> Hooks Class Initialized
DEBUG - 2018-05-12 00:36:08 --> UTF-8 Support Enabled
INFO - 2018-05-12 00:36:08 --> Utf8 Class Initialized
INFO - 2018-05-12 00:36:08 --> URI Class Initialized
INFO - 2018-05-12 00:36:08 --> Router Class Initialized
INFO - 2018-05-12 00:36:08 --> Output Class Initialized
INFO - 2018-05-12 00:36:09 --> Security Class Initialized
DEBUG - 2018-05-12 00:36:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 00:36:09 --> Input Class Initialized
INFO - 2018-05-12 00:36:09 --> Language Class Initialized
INFO - 2018-05-12 00:36:09 --> Language Class Initialized
INFO - 2018-05-12 00:36:09 --> Config Class Initialized
INFO - 2018-05-12 00:36:09 --> Loader Class Initialized
DEBUG - 2018-05-12 00:36:09 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-12 00:36:09 --> Helper loaded: url_helper
INFO - 2018-05-12 00:36:09 --> Helper loaded: form_helper
INFO - 2018-05-12 00:36:09 --> Helper loaded: date_helper
INFO - 2018-05-12 00:36:09 --> Helper loaded: util_helper
INFO - 2018-05-12 00:36:09 --> Helper loaded: text_helper
INFO - 2018-05-12 00:36:09 --> Helper loaded: string_helper
INFO - 2018-05-12 00:36:09 --> Database Driver Class Initialized
DEBUG - 2018-05-12 00:36:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-12 00:36:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-12 00:36:09 --> Email Class Initialized
INFO - 2018-05-12 00:36:09 --> Controller Class Initialized
DEBUG - 2018-05-12 00:36:09 --> Programs MX_Controller Initialized
INFO - 2018-05-12 00:36:09 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-12 00:36:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-05-12 00:36:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-12 00:36:09 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-12 00:36:09 --> Login MX_Controller Initialized
DEBUG - 2018-05-12 00:36:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-12 00:36:09 --> Final output sent to browser
DEBUG - 2018-05-12 00:36:09 --> Total execution time: 0.5497
INFO - 2018-05-12 00:36:30 --> Config Class Initialized
INFO - 2018-05-12 00:36:30 --> Hooks Class Initialized
DEBUG - 2018-05-12 00:36:30 --> UTF-8 Support Enabled
INFO - 2018-05-12 00:36:30 --> Utf8 Class Initialized
INFO - 2018-05-12 00:36:30 --> URI Class Initialized
INFO - 2018-05-12 00:36:30 --> Router Class Initialized
INFO - 2018-05-12 00:36:30 --> Output Class Initialized
INFO - 2018-05-12 00:36:30 --> Security Class Initialized
DEBUG - 2018-05-12 00:36:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 00:36:30 --> Input Class Initialized
INFO - 2018-05-12 00:36:30 --> Language Class Initialized
INFO - 2018-05-12 00:36:30 --> Language Class Initialized
INFO - 2018-05-12 00:36:30 --> Config Class Initialized
INFO - 2018-05-12 00:36:30 --> Loader Class Initialized
DEBUG - 2018-05-12 00:36:30 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-12 00:36:30 --> Helper loaded: url_helper
INFO - 2018-05-12 00:36:30 --> Helper loaded: form_helper
INFO - 2018-05-12 00:36:30 --> Helper loaded: date_helper
INFO - 2018-05-12 00:36:30 --> Helper loaded: util_helper
INFO - 2018-05-12 00:36:30 --> Helper loaded: text_helper
INFO - 2018-05-12 00:36:30 --> Helper loaded: string_helper
INFO - 2018-05-12 00:36:30 --> Database Driver Class Initialized
DEBUG - 2018-05-12 00:36:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-12 00:36:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-12 00:36:30 --> Email Class Initialized
INFO - 2018-05-12 00:36:30 --> Controller Class Initialized
DEBUG - 2018-05-12 00:36:30 --> Programs MX_Controller Initialized
INFO - 2018-05-12 00:36:30 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-12 00:36:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-05-12 00:36:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-12 00:36:30 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-12 00:36:30 --> Login MX_Controller Initialized
DEBUG - 2018-05-12 00:36:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-12 00:36:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-05-12 00:36:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-05-12 00:36:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-05-12 00:36:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-05-12 00:36:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-05-12 00:36:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/programs/programs.php
INFO - 2018-05-12 00:36:31 --> Final output sent to browser
DEBUG - 2018-05-12 00:36:31 --> Total execution time: 0.4221
INFO - 2018-05-12 00:36:31 --> Config Class Initialized
INFO - 2018-05-12 00:36:31 --> Hooks Class Initialized
DEBUG - 2018-05-12 00:36:31 --> UTF-8 Support Enabled
INFO - 2018-05-12 00:36:31 --> Utf8 Class Initialized
INFO - 2018-05-12 00:36:31 --> URI Class Initialized
INFO - 2018-05-12 00:36:31 --> Router Class Initialized
INFO - 2018-05-12 00:36:31 --> Output Class Initialized
INFO - 2018-05-12 00:36:31 --> Security Class Initialized
DEBUG - 2018-05-12 00:36:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 00:36:31 --> Input Class Initialized
INFO - 2018-05-12 00:36:31 --> Language Class Initialized
INFO - 2018-05-12 00:36:31 --> Language Class Initialized
INFO - 2018-05-12 00:36:31 --> Config Class Initialized
INFO - 2018-05-12 00:36:31 --> Loader Class Initialized
DEBUG - 2018-05-12 00:36:31 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-12 00:36:31 --> Helper loaded: url_helper
INFO - 2018-05-12 00:36:31 --> Helper loaded: form_helper
INFO - 2018-05-12 00:36:31 --> Helper loaded: date_helper
INFO - 2018-05-12 00:36:31 --> Helper loaded: util_helper
INFO - 2018-05-12 00:36:31 --> Helper loaded: text_helper
INFO - 2018-05-12 00:36:31 --> Helper loaded: string_helper
INFO - 2018-05-12 00:36:31 --> Database Driver Class Initialized
DEBUG - 2018-05-12 00:36:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-12 00:36:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-12 00:36:31 --> Email Class Initialized
INFO - 2018-05-12 00:36:31 --> Controller Class Initialized
DEBUG - 2018-05-12 00:36:31 --> Programs MX_Controller Initialized
INFO - 2018-05-12 00:36:31 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-12 00:36:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-05-12 00:36:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-12 00:36:31 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-12 00:36:31 --> Login MX_Controller Initialized
DEBUG - 2018-05-12 00:36:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-12 00:36:31 --> Final output sent to browser
DEBUG - 2018-05-12 00:36:31 --> Total execution time: 0.4443
INFO - 2018-05-12 00:37:51 --> Config Class Initialized
INFO - 2018-05-12 00:37:51 --> Hooks Class Initialized
DEBUG - 2018-05-12 00:37:51 --> UTF-8 Support Enabled
INFO - 2018-05-12 00:37:51 --> Utf8 Class Initialized
INFO - 2018-05-12 00:37:51 --> URI Class Initialized
INFO - 2018-05-12 00:37:51 --> Router Class Initialized
INFO - 2018-05-12 00:37:51 --> Output Class Initialized
INFO - 2018-05-12 00:37:51 --> Security Class Initialized
DEBUG - 2018-05-12 00:37:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 00:37:51 --> Input Class Initialized
INFO - 2018-05-12 00:37:51 --> Language Class Initialized
INFO - 2018-05-12 00:37:51 --> Language Class Initialized
INFO - 2018-05-12 00:37:51 --> Config Class Initialized
INFO - 2018-05-12 00:37:51 --> Loader Class Initialized
DEBUG - 2018-05-12 00:37:51 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-12 00:37:51 --> Helper loaded: url_helper
INFO - 2018-05-12 00:37:51 --> Helper loaded: form_helper
INFO - 2018-05-12 00:37:51 --> Helper loaded: date_helper
INFO - 2018-05-12 00:37:51 --> Helper loaded: util_helper
INFO - 2018-05-12 00:37:51 --> Helper loaded: text_helper
INFO - 2018-05-12 00:37:51 --> Helper loaded: string_helper
INFO - 2018-05-12 00:37:51 --> Database Driver Class Initialized
DEBUG - 2018-05-12 00:37:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-12 00:37:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-12 00:37:51 --> Email Class Initialized
INFO - 2018-05-12 00:37:51 --> Controller Class Initialized
DEBUG - 2018-05-12 00:37:51 --> Programs MX_Controller Initialized
INFO - 2018-05-12 00:37:51 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-12 00:37:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-05-12 00:37:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-12 00:37:51 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-12 00:37:51 --> Login MX_Controller Initialized
DEBUG - 2018-05-12 00:37:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-12 00:37:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-05-12 00:37:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-05-12 00:37:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-05-12 00:37:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-05-12 00:37:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-05-12 00:37:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/programs/programs.php
INFO - 2018-05-12 00:37:51 --> Final output sent to browser
DEBUG - 2018-05-12 00:37:51 --> Total execution time: 0.4939
INFO - 2018-05-12 00:37:52 --> Config Class Initialized
INFO - 2018-05-12 00:37:52 --> Hooks Class Initialized
DEBUG - 2018-05-12 00:37:52 --> UTF-8 Support Enabled
INFO - 2018-05-12 00:37:52 --> Utf8 Class Initialized
INFO - 2018-05-12 00:37:52 --> URI Class Initialized
INFO - 2018-05-12 00:37:52 --> Router Class Initialized
INFO - 2018-05-12 00:37:52 --> Output Class Initialized
INFO - 2018-05-12 00:37:52 --> Security Class Initialized
DEBUG - 2018-05-12 00:37:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 00:37:52 --> Input Class Initialized
INFO - 2018-05-12 00:37:52 --> Language Class Initialized
INFO - 2018-05-12 00:37:52 --> Language Class Initialized
INFO - 2018-05-12 00:37:52 --> Config Class Initialized
INFO - 2018-05-12 00:37:52 --> Loader Class Initialized
DEBUG - 2018-05-12 00:37:52 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-12 00:37:52 --> Helper loaded: url_helper
INFO - 2018-05-12 00:37:52 --> Helper loaded: form_helper
INFO - 2018-05-12 00:37:52 --> Helper loaded: date_helper
INFO - 2018-05-12 00:37:52 --> Helper loaded: util_helper
INFO - 2018-05-12 00:37:52 --> Helper loaded: text_helper
INFO - 2018-05-12 00:37:52 --> Helper loaded: string_helper
INFO - 2018-05-12 00:37:52 --> Database Driver Class Initialized
DEBUG - 2018-05-12 00:37:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-12 00:37:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-12 00:37:52 --> Email Class Initialized
INFO - 2018-05-12 00:37:52 --> Controller Class Initialized
DEBUG - 2018-05-12 00:37:52 --> Programs MX_Controller Initialized
INFO - 2018-05-12 00:37:52 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-12 00:37:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-05-12 00:37:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-12 00:37:52 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-12 00:37:52 --> Login MX_Controller Initialized
DEBUG - 2018-05-12 00:37:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-12 00:37:52 --> Final output sent to browser
DEBUG - 2018-05-12 00:37:52 --> Total execution time: 0.6162
INFO - 2018-05-12 00:39:35 --> Config Class Initialized
INFO - 2018-05-12 00:39:35 --> Hooks Class Initialized
DEBUG - 2018-05-12 00:39:35 --> UTF-8 Support Enabled
INFO - 2018-05-12 00:39:35 --> Utf8 Class Initialized
INFO - 2018-05-12 00:39:35 --> URI Class Initialized
INFO - 2018-05-12 00:39:35 --> Router Class Initialized
INFO - 2018-05-12 00:39:35 --> Output Class Initialized
INFO - 2018-05-12 00:39:35 --> Security Class Initialized
DEBUG - 2018-05-12 00:39:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 00:39:35 --> Input Class Initialized
INFO - 2018-05-12 00:39:35 --> Language Class Initialized
INFO - 2018-05-12 00:39:35 --> Language Class Initialized
INFO - 2018-05-12 00:39:35 --> Config Class Initialized
INFO - 2018-05-12 00:39:35 --> Loader Class Initialized
DEBUG - 2018-05-12 00:39:35 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-12 00:39:35 --> Helper loaded: url_helper
INFO - 2018-05-12 00:39:35 --> Helper loaded: form_helper
INFO - 2018-05-12 00:39:35 --> Helper loaded: date_helper
INFO - 2018-05-12 00:39:35 --> Helper loaded: util_helper
INFO - 2018-05-12 00:39:35 --> Helper loaded: text_helper
INFO - 2018-05-12 00:39:35 --> Helper loaded: string_helper
INFO - 2018-05-12 00:39:35 --> Database Driver Class Initialized
DEBUG - 2018-05-12 00:39:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-12 00:39:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-12 00:39:35 --> Email Class Initialized
INFO - 2018-05-12 00:39:35 --> Controller Class Initialized
DEBUG - 2018-05-12 00:39:35 --> Programs MX_Controller Initialized
INFO - 2018-05-12 00:39:35 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-12 00:39:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-05-12 00:39:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-12 00:39:35 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-12 00:39:35 --> Login MX_Controller Initialized
DEBUG - 2018-05-12 00:39:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-12 00:39:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-05-12 00:39:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-05-12 00:39:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-05-12 00:39:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-05-12 00:39:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-05-12 00:39:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/programs/programs.php
INFO - 2018-05-12 00:39:35 --> Final output sent to browser
DEBUG - 2018-05-12 00:39:35 --> Total execution time: 0.4152
INFO - 2018-05-12 00:39:36 --> Config Class Initialized
INFO - 2018-05-12 00:39:36 --> Hooks Class Initialized
DEBUG - 2018-05-12 00:39:36 --> UTF-8 Support Enabled
INFO - 2018-05-12 00:39:36 --> Utf8 Class Initialized
INFO - 2018-05-12 00:39:36 --> URI Class Initialized
INFO - 2018-05-12 00:39:36 --> Router Class Initialized
INFO - 2018-05-12 00:39:36 --> Output Class Initialized
INFO - 2018-05-12 00:39:36 --> Security Class Initialized
DEBUG - 2018-05-12 00:39:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 00:39:36 --> Input Class Initialized
INFO - 2018-05-12 00:39:36 --> Language Class Initialized
INFO - 2018-05-12 00:39:36 --> Language Class Initialized
INFO - 2018-05-12 00:39:36 --> Config Class Initialized
INFO - 2018-05-12 00:39:36 --> Loader Class Initialized
DEBUG - 2018-05-12 00:39:36 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-12 00:39:36 --> Helper loaded: url_helper
INFO - 2018-05-12 00:39:36 --> Helper loaded: form_helper
INFO - 2018-05-12 00:39:36 --> Helper loaded: date_helper
INFO - 2018-05-12 00:39:36 --> Helper loaded: util_helper
INFO - 2018-05-12 00:39:36 --> Helper loaded: text_helper
INFO - 2018-05-12 00:39:36 --> Helper loaded: string_helper
INFO - 2018-05-12 00:39:36 --> Database Driver Class Initialized
DEBUG - 2018-05-12 00:39:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-12 00:39:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-12 00:39:36 --> Email Class Initialized
INFO - 2018-05-12 00:39:36 --> Controller Class Initialized
DEBUG - 2018-05-12 00:39:36 --> Programs MX_Controller Initialized
INFO - 2018-05-12 00:39:36 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-12 00:39:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-05-12 00:39:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-12 00:39:36 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-12 00:39:36 --> Login MX_Controller Initialized
DEBUG - 2018-05-12 00:39:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-12 00:39:36 --> Final output sent to browser
DEBUG - 2018-05-12 00:39:36 --> Total execution time: 0.5258
INFO - 2018-05-12 00:45:28 --> Config Class Initialized
INFO - 2018-05-12 00:45:28 --> Hooks Class Initialized
DEBUG - 2018-05-12 00:45:28 --> UTF-8 Support Enabled
INFO - 2018-05-12 00:45:28 --> Utf8 Class Initialized
INFO - 2018-05-12 00:45:28 --> URI Class Initialized
INFO - 2018-05-12 00:45:28 --> Router Class Initialized
INFO - 2018-05-12 00:45:28 --> Output Class Initialized
INFO - 2018-05-12 00:45:28 --> Security Class Initialized
DEBUG - 2018-05-12 00:45:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 00:45:28 --> Input Class Initialized
INFO - 2018-05-12 00:45:28 --> Language Class Initialized
INFO - 2018-05-12 00:45:28 --> Language Class Initialized
INFO - 2018-05-12 00:45:28 --> Config Class Initialized
INFO - 2018-05-12 00:45:29 --> Loader Class Initialized
DEBUG - 2018-05-12 00:45:29 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-12 00:45:29 --> Helper loaded: url_helper
INFO - 2018-05-12 00:45:29 --> Helper loaded: form_helper
INFO - 2018-05-12 00:45:29 --> Helper loaded: date_helper
INFO - 2018-05-12 00:45:29 --> Helper loaded: util_helper
INFO - 2018-05-12 00:45:29 --> Helper loaded: text_helper
INFO - 2018-05-12 00:45:29 --> Helper loaded: string_helper
INFO - 2018-05-12 00:45:29 --> Database Driver Class Initialized
DEBUG - 2018-05-12 00:45:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-12 00:45:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-12 00:45:29 --> Email Class Initialized
INFO - 2018-05-12 00:45:29 --> Controller Class Initialized
DEBUG - 2018-05-12 00:45:29 --> Programs MX_Controller Initialized
INFO - 2018-05-12 00:45:29 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-12 00:45:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-05-12 00:45:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-12 00:45:29 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-12 00:45:29 --> Login MX_Controller Initialized
DEBUG - 2018-05-12 00:45:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-12 00:45:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-05-12 00:45:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-05-12 00:45:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-05-12 00:45:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-05-12 00:45:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-05-12 00:45:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/programs/programs.php
INFO - 2018-05-12 00:45:29 --> Final output sent to browser
DEBUG - 2018-05-12 00:45:29 --> Total execution time: 0.4119
INFO - 2018-05-12 00:45:30 --> Config Class Initialized
INFO - 2018-05-12 00:45:30 --> Hooks Class Initialized
DEBUG - 2018-05-12 00:45:30 --> UTF-8 Support Enabled
INFO - 2018-05-12 00:45:30 --> Utf8 Class Initialized
INFO - 2018-05-12 00:45:30 --> URI Class Initialized
INFO - 2018-05-12 00:45:30 --> Router Class Initialized
INFO - 2018-05-12 00:45:30 --> Output Class Initialized
INFO - 2018-05-12 00:45:30 --> Security Class Initialized
DEBUG - 2018-05-12 00:45:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 00:45:30 --> Input Class Initialized
INFO - 2018-05-12 00:45:30 --> Language Class Initialized
INFO - 2018-05-12 00:45:30 --> Language Class Initialized
INFO - 2018-05-12 00:45:30 --> Config Class Initialized
INFO - 2018-05-12 00:45:30 --> Loader Class Initialized
DEBUG - 2018-05-12 00:45:30 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-12 00:45:30 --> Helper loaded: url_helper
INFO - 2018-05-12 00:45:30 --> Helper loaded: form_helper
INFO - 2018-05-12 00:45:30 --> Helper loaded: date_helper
INFO - 2018-05-12 00:45:30 --> Helper loaded: util_helper
INFO - 2018-05-12 00:45:30 --> Helper loaded: text_helper
INFO - 2018-05-12 00:45:30 --> Helper loaded: string_helper
INFO - 2018-05-12 00:45:30 --> Database Driver Class Initialized
DEBUG - 2018-05-12 00:45:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-12 00:45:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-12 00:45:30 --> Email Class Initialized
INFO - 2018-05-12 00:45:30 --> Controller Class Initialized
DEBUG - 2018-05-12 00:45:30 --> Programs MX_Controller Initialized
INFO - 2018-05-12 00:45:30 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-12 00:45:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-05-12 00:45:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-12 00:45:30 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-12 00:45:30 --> Login MX_Controller Initialized
DEBUG - 2018-05-12 00:45:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-12 00:45:30 --> Final output sent to browser
DEBUG - 2018-05-12 00:45:30 --> Total execution time: 0.7010
INFO - 2018-05-12 00:51:30 --> Config Class Initialized
INFO - 2018-05-12 00:51:30 --> Hooks Class Initialized
INFO - 2018-05-12 00:51:30 --> Config Class Initialized
INFO - 2018-05-12 00:51:30 --> Hooks Class Initialized
DEBUG - 2018-05-12 00:51:30 --> UTF-8 Support Enabled
INFO - 2018-05-12 00:51:30 --> Config Class Initialized
INFO - 2018-05-12 00:51:30 --> Config Class Initialized
INFO - 2018-05-12 00:51:30 --> Config Class Initialized
INFO - 2018-05-12 00:51:30 --> Utf8 Class Initialized
INFO - 2018-05-12 00:51:30 --> Hooks Class Initialized
INFO - 2018-05-12 00:51:30 --> Hooks Class Initialized
INFO - 2018-05-12 00:51:30 --> Hooks Class Initialized
DEBUG - 2018-05-12 00:51:30 --> UTF-8 Support Enabled
INFO - 2018-05-12 00:51:30 --> URI Class Initialized
DEBUG - 2018-05-12 00:51:30 --> UTF-8 Support Enabled
DEBUG - 2018-05-12 00:51:30 --> UTF-8 Support Enabled
DEBUG - 2018-05-12 00:51:30 --> UTF-8 Support Enabled
INFO - 2018-05-12 00:51:30 --> Utf8 Class Initialized
INFO - 2018-05-12 00:51:30 --> Utf8 Class Initialized
INFO - 2018-05-12 00:51:30 --> Utf8 Class Initialized
INFO - 2018-05-12 00:51:30 --> Utf8 Class Initialized
INFO - 2018-05-12 00:51:30 --> Router Class Initialized
INFO - 2018-05-12 00:51:30 --> URI Class Initialized
INFO - 2018-05-12 00:51:30 --> Output Class Initialized
INFO - 2018-05-12 00:51:30 --> URI Class Initialized
INFO - 2018-05-12 00:51:30 --> URI Class Initialized
INFO - 2018-05-12 00:51:30 --> URI Class Initialized
INFO - 2018-05-12 00:51:30 --> Router Class Initialized
INFO - 2018-05-12 00:51:30 --> Router Class Initialized
INFO - 2018-05-12 00:51:30 --> Security Class Initialized
INFO - 2018-05-12 00:51:30 --> Output Class Initialized
INFO - 2018-05-12 00:51:30 --> Security Class Initialized
DEBUG - 2018-05-12 00:51:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 00:51:30 --> Input Class Initialized
INFO - 2018-05-12 00:51:30 --> Language Class Initialized
ERROR - 2018-05-12 00:51:30 --> 404 Page Not Found: /index
INFO - 2018-05-12 00:51:30 --> Config Class Initialized
INFO - 2018-05-12 00:51:30 --> Hooks Class Initialized
DEBUG - 2018-05-12 00:51:30 --> UTF-8 Support Enabled
INFO - 2018-05-12 00:51:30 --> Utf8 Class Initialized
INFO - 2018-05-12 00:51:30 --> URI Class Initialized
INFO - 2018-05-12 00:51:30 --> Output Class Initialized
INFO - 2018-05-12 00:51:30 --> Router Class Initialized
INFO - 2018-05-12 00:51:30 --> Router Class Initialized
INFO - 2018-05-12 00:51:30 --> Router Class Initialized
INFO - 2018-05-12 00:51:30 --> Output Class Initialized
DEBUG - 2018-05-12 00:51:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 00:51:30 --> Security Class Initialized
INFO - 2018-05-12 00:51:30 --> Output Class Initialized
INFO - 2018-05-12 00:51:30 --> Security Class Initialized
INFO - 2018-05-12 00:51:30 --> Output Class Initialized
INFO - 2018-05-12 00:51:30 --> Input Class Initialized
DEBUG - 2018-05-12 00:51:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 00:51:30 --> Security Class Initialized
DEBUG - 2018-05-12 00:51:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 00:51:30 --> Security Class Initialized
INFO - 2018-05-12 00:51:30 --> Input Class Initialized
INFO - 2018-05-12 00:51:30 --> Input Class Initialized
DEBUG - 2018-05-12 00:51:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 00:51:30 --> Language Class Initialized
DEBUG - 2018-05-12 00:51:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 00:51:30 --> Input Class Initialized
INFO - 2018-05-12 00:51:30 --> Language Class Initialized
INFO - 2018-05-12 00:51:30 --> Language Class Initialized
INFO - 2018-05-12 00:51:30 --> Input Class Initialized
ERROR - 2018-05-12 00:51:30 --> 404 Page Not Found: /index
ERROR - 2018-05-12 00:51:30 --> 404 Page Not Found: /index
ERROR - 2018-05-12 00:51:30 --> 404 Page Not Found: /index
INFO - 2018-05-12 00:51:30 --> Language Class Initialized
INFO - 2018-05-12 00:51:30 --> Language Class Initialized
INFO - 2018-05-12 00:51:30 --> Config Class Initialized
ERROR - 2018-05-12 00:51:30 --> 404 Page Not Found: /index
ERROR - 2018-05-12 00:51:30 --> 404 Page Not Found: /index
INFO - 2018-05-12 00:51:30 --> Config Class Initialized
INFO - 2018-05-12 00:51:30 --> Hooks Class Initialized
INFO - 2018-05-12 00:51:30 --> Hooks Class Initialized
DEBUG - 2018-05-12 00:51:30 --> UTF-8 Support Enabled
INFO - 2018-05-12 00:51:30 --> Utf8 Class Initialized
INFO - 2018-05-12 00:51:30 --> Config Class Initialized
INFO - 2018-05-12 00:51:30 --> Hooks Class Initialized
INFO - 2018-05-12 00:51:30 --> Config Class Initialized
INFO - 2018-05-12 00:51:30 --> URI Class Initialized
DEBUG - 2018-05-12 00:51:30 --> UTF-8 Support Enabled
INFO - 2018-05-12 00:51:30 --> Hooks Class Initialized
DEBUG - 2018-05-12 00:51:30 --> UTF-8 Support Enabled
INFO - 2018-05-12 00:51:30 --> Utf8 Class Initialized
INFO - 2018-05-12 00:51:30 --> Router Class Initialized
INFO - 2018-05-12 00:51:30 --> Utf8 Class Initialized
INFO - 2018-05-12 00:51:30 --> Output Class Initialized
DEBUG - 2018-05-12 00:51:31 --> UTF-8 Support Enabled
INFO - 2018-05-12 00:51:31 --> URI Class Initialized
INFO - 2018-05-12 00:51:31 --> Utf8 Class Initialized
INFO - 2018-05-12 00:51:31 --> Security Class Initialized
INFO - 2018-05-12 00:51:31 --> Router Class Initialized
INFO - 2018-05-12 00:51:31 --> URI Class Initialized
DEBUG - 2018-05-12 00:51:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 00:51:31 --> URI Class Initialized
INFO - 2018-05-12 00:51:31 --> Output Class Initialized
INFO - 2018-05-12 00:51:31 --> Router Class Initialized
INFO - 2018-05-12 00:51:31 --> Input Class Initialized
INFO - 2018-05-12 00:51:31 --> Security Class Initialized
INFO - 2018-05-12 00:51:31 --> Output Class Initialized
INFO - 2018-05-12 00:51:31 --> Language Class Initialized
INFO - 2018-05-12 00:51:31 --> Router Class Initialized
INFO - 2018-05-12 00:51:31 --> Security Class Initialized
DEBUG - 2018-05-12 00:51:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 00:51:31 --> Output Class Initialized
ERROR - 2018-05-12 00:51:31 --> 404 Page Not Found: /index
DEBUG - 2018-05-12 00:51:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 00:51:31 --> Input Class Initialized
INFO - 2018-05-12 00:51:31 --> Security Class Initialized
INFO - 2018-05-12 00:51:31 --> Input Class Initialized
INFO - 2018-05-12 00:51:31 --> Config Class Initialized
DEBUG - 2018-05-12 00:51:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 00:51:31 --> Language Class Initialized
INFO - 2018-05-12 00:51:31 --> Input Class Initialized
INFO - 2018-05-12 00:51:31 --> Hooks Class Initialized
INFO - 2018-05-12 00:51:31 --> Language Class Initialized
ERROR - 2018-05-12 00:51:31 --> 404 Page Not Found: /index
INFO - 2018-05-12 00:51:31 --> Language Class Initialized
DEBUG - 2018-05-12 00:51:31 --> UTF-8 Support Enabled
ERROR - 2018-05-12 00:51:31 --> 404 Page Not Found: /index
ERROR - 2018-05-12 00:51:31 --> 404 Page Not Found: /index
INFO - 2018-05-12 00:51:31 --> Config Class Initialized
INFO - 2018-05-12 00:51:31 --> Hooks Class Initialized
INFO - 2018-05-12 00:51:31 --> Config Class Initialized
INFO - 2018-05-12 00:51:31 --> Utf8 Class Initialized
INFO - 2018-05-12 00:51:31 --> Hooks Class Initialized
DEBUG - 2018-05-12 00:51:31 --> UTF-8 Support Enabled
DEBUG - 2018-05-12 00:51:31 --> UTF-8 Support Enabled
INFO - 2018-05-12 00:51:31 --> Utf8 Class Initialized
INFO - 2018-05-12 00:51:31 --> Utf8 Class Initialized
INFO - 2018-05-12 00:51:31 --> URI Class Initialized
INFO - 2018-05-12 00:51:31 --> URI Class Initialized
INFO - 2018-05-12 00:51:31 --> Router Class Initialized
INFO - 2018-05-12 00:51:31 --> Router Class Initialized
INFO - 2018-05-12 00:51:31 --> URI Class Initialized
INFO - 2018-05-12 00:51:31 --> Output Class Initialized
INFO - 2018-05-12 00:51:31 --> Output Class Initialized
INFO - 2018-05-12 00:51:31 --> Router Class Initialized
INFO - 2018-05-12 00:51:31 --> Security Class Initialized
INFO - 2018-05-12 00:51:31 --> Security Class Initialized
INFO - 2018-05-12 00:51:31 --> Output Class Initialized
INFO - 2018-05-12 00:51:31 --> Security Class Initialized
DEBUG - 2018-05-12 00:51:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-12 00:51:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-12 00:51:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 00:51:31 --> Input Class Initialized
INFO - 2018-05-12 00:51:31 --> Input Class Initialized
INFO - 2018-05-12 00:51:31 --> Input Class Initialized
INFO - 2018-05-12 00:51:31 --> Language Class Initialized
INFO - 2018-05-12 00:51:31 --> Language Class Initialized
INFO - 2018-05-12 00:51:31 --> Language Class Initialized
ERROR - 2018-05-12 00:51:31 --> 404 Page Not Found: /index
ERROR - 2018-05-12 00:51:31 --> 404 Page Not Found: /index
ERROR - 2018-05-12 00:51:31 --> 404 Page Not Found: /index
INFO - 2018-05-12 00:52:41 --> Config Class Initialized
INFO - 2018-05-12 00:52:42 --> Hooks Class Initialized
DEBUG - 2018-05-12 00:52:42 --> UTF-8 Support Enabled
INFO - 2018-05-12 00:52:42 --> Utf8 Class Initialized
INFO - 2018-05-12 00:52:42 --> URI Class Initialized
INFO - 2018-05-12 00:52:42 --> Router Class Initialized
INFO - 2018-05-12 00:52:42 --> Output Class Initialized
INFO - 2018-05-12 00:52:42 --> Security Class Initialized
DEBUG - 2018-05-12 00:52:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 00:52:42 --> Input Class Initialized
INFO - 2018-05-12 00:52:42 --> Language Class Initialized
ERROR - 2018-05-12 00:52:42 --> 404 Page Not Found: /index
INFO - 2018-05-12 00:52:42 --> Config Class Initialized
INFO - 2018-05-12 00:52:42 --> Hooks Class Initialized
DEBUG - 2018-05-12 00:52:42 --> UTF-8 Support Enabled
INFO - 2018-05-12 00:52:42 --> Config Class Initialized
INFO - 2018-05-12 00:52:42 --> Config Class Initialized
INFO - 2018-05-12 00:52:42 --> Config Class Initialized
INFO - 2018-05-12 00:52:42 --> Config Class Initialized
INFO - 2018-05-12 00:52:42 --> Hooks Class Initialized
INFO - 2018-05-12 00:52:42 --> Hooks Class Initialized
INFO - 2018-05-12 00:52:42 --> Hooks Class Initialized
INFO - 2018-05-12 00:52:42 --> Utf8 Class Initialized
INFO - 2018-05-12 00:52:42 --> Hooks Class Initialized
DEBUG - 2018-05-12 00:52:42 --> UTF-8 Support Enabled
DEBUG - 2018-05-12 00:52:42 --> UTF-8 Support Enabled
DEBUG - 2018-05-12 00:52:42 --> UTF-8 Support Enabled
INFO - 2018-05-12 00:52:42 --> Config Class Initialized
INFO - 2018-05-12 00:52:42 --> URI Class Initialized
DEBUG - 2018-05-12 00:52:42 --> UTF-8 Support Enabled
INFO - 2018-05-12 00:52:42 --> Hooks Class Initialized
INFO - 2018-05-12 00:52:42 --> Utf8 Class Initialized
INFO - 2018-05-12 00:52:42 --> Utf8 Class Initialized
INFO - 2018-05-12 00:52:42 --> Router Class Initialized
INFO - 2018-05-12 00:52:42 --> Utf8 Class Initialized
INFO - 2018-05-12 00:52:42 --> Utf8 Class Initialized
INFO - 2018-05-12 00:52:42 --> URI Class Initialized
INFO - 2018-05-12 00:52:42 --> URI Class Initialized
DEBUG - 2018-05-12 00:52:42 --> UTF-8 Support Enabled
INFO - 2018-05-12 00:52:42 --> Output Class Initialized
INFO - 2018-05-12 00:52:42 --> URI Class Initialized
INFO - 2018-05-12 00:52:42 --> URI Class Initialized
INFO - 2018-05-12 00:52:42 --> Utf8 Class Initialized
INFO - 2018-05-12 00:52:42 --> Router Class Initialized
INFO - 2018-05-12 00:52:42 --> URI Class Initialized
INFO - 2018-05-12 00:52:42 --> Security Class Initialized
INFO - 2018-05-12 00:52:42 --> Router Class Initialized
INFO - 2018-05-12 00:52:42 --> Router Class Initialized
INFO - 2018-05-12 00:52:42 --> Router Class Initialized
INFO - 2018-05-12 00:52:42 --> Router Class Initialized
INFO - 2018-05-12 00:52:42 --> Output Class Initialized
DEBUG - 2018-05-12 00:52:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 00:52:42 --> Output Class Initialized
INFO - 2018-05-12 00:52:42 --> Output Class Initialized
INFO - 2018-05-12 00:52:42 --> Output Class Initialized
INFO - 2018-05-12 00:52:42 --> Security Class Initialized
INFO - 2018-05-12 00:52:42 --> Output Class Initialized
INFO - 2018-05-12 00:52:42 --> Input Class Initialized
INFO - 2018-05-12 00:52:42 --> Security Class Initialized
INFO - 2018-05-12 00:52:42 --> Security Class Initialized
INFO - 2018-05-12 00:52:42 --> Security Class Initialized
DEBUG - 2018-05-12 00:52:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-12 00:52:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-12 00:52:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 00:52:42 --> Language Class Initialized
DEBUG - 2018-05-12 00:52:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 00:52:42 --> Security Class Initialized
INFO - 2018-05-12 00:52:42 --> Input Class Initialized
INFO - 2018-05-12 00:52:42 --> Input Class Initialized
INFO - 2018-05-12 00:52:42 --> Input Class Initialized
ERROR - 2018-05-12 00:52:42 --> 404 Page Not Found: /index
INFO - 2018-05-12 00:52:42 --> Input Class Initialized
DEBUG - 2018-05-12 00:52:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 00:52:42 --> Language Class Initialized
INFO - 2018-05-12 00:52:42 --> Language Class Initialized
INFO - 2018-05-12 00:52:42 --> Language Class Initialized
INFO - 2018-05-12 00:52:42 --> Config Class Initialized
INFO - 2018-05-12 00:52:42 --> Language Class Initialized
INFO - 2018-05-12 00:52:42 --> Input Class Initialized
INFO - 2018-05-12 00:52:42 --> Hooks Class Initialized
ERROR - 2018-05-12 00:52:42 --> 404 Page Not Found: /index
ERROR - 2018-05-12 00:52:42 --> 404 Page Not Found: /index
ERROR - 2018-05-12 00:52:42 --> 404 Page Not Found: /index
ERROR - 2018-05-12 00:52:42 --> 404 Page Not Found: /index
INFO - 2018-05-12 00:52:42 --> Language Class Initialized
DEBUG - 2018-05-12 00:52:42 --> UTF-8 Support Enabled
INFO - 2018-05-12 00:52:42 --> Utf8 Class Initialized
INFO - 2018-05-12 00:52:42 --> URI Class Initialized
INFO - 2018-05-12 00:52:42 --> Router Class Initialized
ERROR - 2018-05-12 00:52:42 --> 404 Page Not Found: /index
INFO - 2018-05-12 00:52:42 --> Output Class Initialized
INFO - 2018-05-12 00:52:42 --> Security Class Initialized
DEBUG - 2018-05-12 00:52:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 00:52:42 --> Config Class Initialized
INFO - 2018-05-12 00:52:42 --> Config Class Initialized
INFO - 2018-05-12 00:52:42 --> Config Class Initialized
INFO - 2018-05-12 00:52:42 --> Config Class Initialized
INFO - 2018-05-12 00:52:43 --> Hooks Class Initialized
INFO - 2018-05-12 00:52:43 --> Hooks Class Initialized
INFO - 2018-05-12 00:52:43 --> Hooks Class Initialized
INFO - 2018-05-12 00:52:43 --> Hooks Class Initialized
INFO - 2018-05-12 00:52:43 --> Input Class Initialized
DEBUG - 2018-05-12 00:52:43 --> UTF-8 Support Enabled
DEBUG - 2018-05-12 00:52:43 --> UTF-8 Support Enabled
INFO - 2018-05-12 00:52:43 --> Language Class Initialized
DEBUG - 2018-05-12 00:52:43 --> UTF-8 Support Enabled
DEBUG - 2018-05-12 00:52:43 --> UTF-8 Support Enabled
INFO - 2018-05-12 00:52:43 --> Utf8 Class Initialized
INFO - 2018-05-12 00:52:43 --> URI Class Initialized
INFO - 2018-05-12 00:52:43 --> Utf8 Class Initialized
INFO - 2018-05-12 00:52:43 --> Utf8 Class Initialized
INFO - 2018-05-12 00:52:43 --> Utf8 Class Initialized
ERROR - 2018-05-12 00:52:43 --> 404 Page Not Found: /index
INFO - 2018-05-12 00:52:43 --> URI Class Initialized
INFO - 2018-05-12 00:52:43 --> URI Class Initialized
INFO - 2018-05-12 00:52:43 --> URI Class Initialized
INFO - 2018-05-12 00:52:43 --> Router Class Initialized
INFO - 2018-05-12 00:52:43 --> Router Class Initialized
INFO - 2018-05-12 00:52:43 --> Output Class Initialized
INFO - 2018-05-12 00:52:43 --> Config Class Initialized
INFO - 2018-05-12 00:52:43 --> Router Class Initialized
INFO - 2018-05-12 00:52:43 --> Router Class Initialized
INFO - 2018-05-12 00:52:43 --> Security Class Initialized
INFO - 2018-05-12 00:52:43 --> Hooks Class Initialized
INFO - 2018-05-12 00:52:43 --> Output Class Initialized
INFO - 2018-05-12 00:52:43 --> Output Class Initialized
INFO - 2018-05-12 00:52:43 --> Output Class Initialized
DEBUG - 2018-05-12 00:52:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-12 00:52:43 --> UTF-8 Support Enabled
INFO - 2018-05-12 00:52:43 --> Security Class Initialized
INFO - 2018-05-12 00:52:43 --> Input Class Initialized
INFO - 2018-05-12 00:52:43 --> Security Class Initialized
DEBUG - 2018-05-12 00:52:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 00:52:43 --> Utf8 Class Initialized
INFO - 2018-05-12 00:52:43 --> Security Class Initialized
INFO - 2018-05-12 00:52:43 --> Language Class Initialized
ERROR - 2018-05-12 00:52:43 --> 404 Page Not Found: /index
INFO - 2018-05-12 00:52:43 --> Config Class Initialized
INFO - 2018-05-12 00:52:43 --> Hooks Class Initialized
DEBUG - 2018-05-12 00:52:43 --> UTF-8 Support Enabled
INFO - 2018-05-12 00:52:43 --> Utf8 Class Initialized
INFO - 2018-05-12 00:52:43 --> URI Class Initialized
INFO - 2018-05-12 00:52:43 --> Router Class Initialized
INFO - 2018-05-12 00:52:43 --> Output Class Initialized
INFO - 2018-05-12 00:52:43 --> Security Class Initialized
DEBUG - 2018-05-12 00:52:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-12 00:52:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 00:52:43 --> URI Class Initialized
INFO - 2018-05-12 00:52:43 --> Input Class Initialized
INFO - 2018-05-12 00:52:43 --> Input Class Initialized
DEBUG - 2018-05-12 00:52:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 00:52:43 --> Input Class Initialized
INFO - 2018-05-12 00:52:43 --> Language Class Initialized
INFO - 2018-05-12 00:52:43 --> Router Class Initialized
INFO - 2018-05-12 00:52:43 --> Language Class Initialized
INFO - 2018-05-12 00:52:43 --> Language Class Initialized
INFO - 2018-05-12 00:52:43 --> Output Class Initialized
ERROR - 2018-05-12 00:52:43 --> 404 Page Not Found: /index
INFO - 2018-05-12 00:52:43 --> Input Class Initialized
ERROR - 2018-05-12 00:52:43 --> 404 Page Not Found: /index
ERROR - 2018-05-12 00:52:43 --> 404 Page Not Found: /index
INFO - 2018-05-12 00:52:43 --> Language Class Initialized
INFO - 2018-05-12 00:52:43 --> Config Class Initialized
INFO - 2018-05-12 00:52:43 --> Security Class Initialized
INFO - 2018-05-12 00:52:43 --> Hooks Class Initialized
DEBUG - 2018-05-12 00:52:43 --> UTF-8 Support Enabled
INFO - 2018-05-12 00:52:43 --> Utf8 Class Initialized
INFO - 2018-05-12 00:52:43 --> URI Class Initialized
INFO - 2018-05-12 00:52:43 --> Router Class Initialized
ERROR - 2018-05-12 00:52:43 --> 404 Page Not Found: /index
INFO - 2018-05-12 00:52:43 --> Config Class Initialized
DEBUG - 2018-05-12 00:52:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 00:52:43 --> Hooks Class Initialized
INFO - 2018-05-12 00:52:43 --> Output Class Initialized
INFO - 2018-05-12 00:52:43 --> Input Class Initialized
INFO - 2018-05-12 00:52:43 --> Config Class Initialized
INFO - 2018-05-12 00:52:43 --> Hooks Class Initialized
DEBUG - 2018-05-12 00:52:43 --> UTF-8 Support Enabled
INFO - 2018-05-12 00:52:43 --> Language Class Initialized
INFO - 2018-05-12 00:52:43 --> Utf8 Class Initialized
ERROR - 2018-05-12 00:52:43 --> 404 Page Not Found: /index
DEBUG - 2018-05-12 00:52:43 --> UTF-8 Support Enabled
INFO - 2018-05-12 00:52:43 --> Security Class Initialized
INFO - 2018-05-12 00:52:43 --> Utf8 Class Initialized
INFO - 2018-05-12 00:52:43 --> URI Class Initialized
INFO - 2018-05-12 00:52:43 --> URI Class Initialized
DEBUG - 2018-05-12 00:52:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 00:52:43 --> Config Class Initialized
INFO - 2018-05-12 00:52:43 --> Router Class Initialized
INFO - 2018-05-12 00:52:43 --> Hooks Class Initialized
INFO - 2018-05-12 00:52:43 --> Router Class Initialized
INFO - 2018-05-12 00:52:43 --> Input Class Initialized
INFO - 2018-05-12 00:52:43 --> Output Class Initialized
DEBUG - 2018-05-12 00:52:43 --> UTF-8 Support Enabled
INFO - 2018-05-12 00:52:43 --> Output Class Initialized
INFO - 2018-05-12 00:52:43 --> Language Class Initialized
INFO - 2018-05-12 00:52:43 --> Security Class Initialized
INFO - 2018-05-12 00:52:43 --> Utf8 Class Initialized
INFO - 2018-05-12 00:52:43 --> URI Class Initialized
INFO - 2018-05-12 00:52:43 --> Router Class Initialized
INFO - 2018-05-12 00:52:43 --> Output Class Initialized
INFO - 2018-05-12 00:52:43 --> Security Class Initialized
DEBUG - 2018-05-12 00:52:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 00:52:43 --> Input Class Initialized
ERROR - 2018-05-12 00:52:43 --> 404 Page Not Found: /index
INFO - 2018-05-12 00:52:43 --> Security Class Initialized
DEBUG - 2018-05-12 00:52:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 00:52:43 --> Language Class Initialized
DEBUG - 2018-05-12 00:52:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 00:52:43 --> Input Class Initialized
INFO - 2018-05-12 00:52:43 --> Language Class Initialized
ERROR - 2018-05-12 00:52:43 --> 404 Page Not Found: /index
ERROR - 2018-05-12 00:52:43 --> 404 Page Not Found: /index
INFO - 2018-05-12 00:52:43 --> Input Class Initialized
INFO - 2018-05-12 00:52:43 --> Language Class Initialized
ERROR - 2018-05-12 00:52:44 --> 404 Page Not Found: /index
INFO - 2018-05-12 00:52:44 --> Config Class Initialized
INFO - 2018-05-12 00:52:44 --> Hooks Class Initialized
DEBUG - 2018-05-12 00:52:44 --> UTF-8 Support Enabled
INFO - 2018-05-12 00:52:44 --> Utf8 Class Initialized
INFO - 2018-05-12 00:52:44 --> URI Class Initialized
INFO - 2018-05-12 00:52:44 --> Router Class Initialized
INFO - 2018-05-12 00:52:44 --> Output Class Initialized
INFO - 2018-05-12 00:52:44 --> Security Class Initialized
DEBUG - 2018-05-12 00:52:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 00:52:44 --> Input Class Initialized
INFO - 2018-05-12 00:52:44 --> Language Class Initialized
ERROR - 2018-05-12 00:52:44 --> 404 Page Not Found: /index
INFO - 2018-05-12 00:52:44 --> Config Class Initialized
INFO - 2018-05-12 00:52:44 --> Hooks Class Initialized
DEBUG - 2018-05-12 00:52:44 --> UTF-8 Support Enabled
INFO - 2018-05-12 00:52:44 --> Utf8 Class Initialized
INFO - 2018-05-12 00:52:44 --> URI Class Initialized
INFO - 2018-05-12 00:52:44 --> Router Class Initialized
INFO - 2018-05-12 00:52:44 --> Output Class Initialized
INFO - 2018-05-12 00:52:44 --> Security Class Initialized
DEBUG - 2018-05-12 00:52:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 00:52:44 --> Input Class Initialized
INFO - 2018-05-12 00:52:44 --> Language Class Initialized
ERROR - 2018-05-12 00:52:44 --> 404 Page Not Found: /index
INFO - 2018-05-12 00:52:44 --> Config Class Initialized
INFO - 2018-05-12 00:52:44 --> Hooks Class Initialized
DEBUG - 2018-05-12 00:52:44 --> UTF-8 Support Enabled
INFO - 2018-05-12 00:52:44 --> Utf8 Class Initialized
INFO - 2018-05-12 00:52:44 --> URI Class Initialized
INFO - 2018-05-12 00:52:44 --> Router Class Initialized
INFO - 2018-05-12 00:52:44 --> Output Class Initialized
INFO - 2018-05-12 00:52:44 --> Security Class Initialized
DEBUG - 2018-05-12 00:52:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 00:52:44 --> Input Class Initialized
INFO - 2018-05-12 00:52:44 --> Language Class Initialized
ERROR - 2018-05-12 00:52:44 --> 404 Page Not Found: /index
INFO - 2018-05-12 00:52:48 --> Config Class Initialized
INFO - 2018-05-12 00:52:48 --> Config Class Initialized
INFO - 2018-05-12 00:52:48 --> Config Class Initialized
INFO - 2018-05-12 00:52:49 --> Config Class Initialized
INFO - 2018-05-12 00:52:49 --> Config Class Initialized
INFO - 2018-05-12 00:52:49 --> Hooks Class Initialized
INFO - 2018-05-12 00:52:49 --> Hooks Class Initialized
INFO - 2018-05-12 00:52:49 --> Hooks Class Initialized
INFO - 2018-05-12 00:52:49 --> Hooks Class Initialized
INFO - 2018-05-12 00:52:49 --> Hooks Class Initialized
DEBUG - 2018-05-12 00:52:49 --> UTF-8 Support Enabled
DEBUG - 2018-05-12 00:52:49 --> UTF-8 Support Enabled
DEBUG - 2018-05-12 00:52:49 --> UTF-8 Support Enabled
DEBUG - 2018-05-12 00:52:49 --> UTF-8 Support Enabled
DEBUG - 2018-05-12 00:52:49 --> UTF-8 Support Enabled
INFO - 2018-05-12 00:52:49 --> Utf8 Class Initialized
INFO - 2018-05-12 00:52:49 --> URI Class Initialized
INFO - 2018-05-12 00:52:49 --> Router Class Initialized
INFO - 2018-05-12 00:52:49 --> Utf8 Class Initialized
INFO - 2018-05-12 00:52:49 --> Utf8 Class Initialized
INFO - 2018-05-12 00:52:49 --> Utf8 Class Initialized
INFO - 2018-05-12 00:52:49 --> Utf8 Class Initialized
INFO - 2018-05-12 00:52:49 --> Output Class Initialized
INFO - 2018-05-12 00:52:49 --> URI Class Initialized
INFO - 2018-05-12 00:52:49 --> Router Class Initialized
INFO - 2018-05-12 00:52:49 --> URI Class Initialized
INFO - 2018-05-12 00:52:49 --> URI Class Initialized
INFO - 2018-05-12 00:52:49 --> URI Class Initialized
INFO - 2018-05-12 00:52:49 --> Security Class Initialized
INFO - 2018-05-12 00:52:49 --> Output Class Initialized
DEBUG - 2018-05-12 00:52:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 00:52:49 --> Router Class Initialized
INFO - 2018-05-12 00:52:49 --> Router Class Initialized
INFO - 2018-05-12 00:52:49 --> Router Class Initialized
INFO - 2018-05-12 00:52:49 --> Security Class Initialized
INFO - 2018-05-12 00:52:49 --> Output Class Initialized
INFO - 2018-05-12 00:52:49 --> Input Class Initialized
INFO - 2018-05-12 00:52:49 --> Output Class Initialized
INFO - 2018-05-12 00:52:49 --> Output Class Initialized
DEBUG - 2018-05-12 00:52:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 00:52:49 --> Security Class Initialized
INFO - 2018-05-12 00:52:49 --> Security Class Initialized
INFO - 2018-05-12 00:52:49 --> Language Class Initialized
INFO - 2018-05-12 00:52:49 --> Security Class Initialized
INFO - 2018-05-12 00:52:49 --> Input Class Initialized
INFO - 2018-05-12 00:52:49 --> Language Class Initialized
DEBUG - 2018-05-12 00:52:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-12 00:52:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-05-12 00:52:49 --> 404 Page Not Found: /index
DEBUG - 2018-05-12 00:52:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 00:52:49 --> Input Class Initialized
INFO - 2018-05-12 00:52:49 --> Input Class Initialized
INFO - 2018-05-12 00:52:49 --> Input Class Initialized
ERROR - 2018-05-12 00:52:49 --> 404 Page Not Found: /index
INFO - 2018-05-12 00:52:49 --> Language Class Initialized
INFO - 2018-05-12 00:52:49 --> Language Class Initialized
INFO - 2018-05-12 00:52:49 --> Config Class Initialized
INFO - 2018-05-12 00:52:49 --> Language Class Initialized
INFO - 2018-05-12 00:52:49 --> Config Class Initialized
INFO - 2018-05-12 00:52:49 --> Hooks Class Initialized
INFO - 2018-05-12 00:52:49 --> Hooks Class Initialized
ERROR - 2018-05-12 00:52:49 --> 404 Page Not Found: /index
ERROR - 2018-05-12 00:52:49 --> 404 Page Not Found: /index
ERROR - 2018-05-12 00:52:49 --> 404 Page Not Found: /index
DEBUG - 2018-05-12 00:52:49 --> UTF-8 Support Enabled
INFO - 2018-05-12 00:52:49 --> Utf8 Class Initialized
INFO - 2018-05-12 00:52:49 --> URI Class Initialized
INFO - 2018-05-12 00:52:49 --> Router Class Initialized
INFO - 2018-05-12 00:52:49 --> Output Class Initialized
INFO - 2018-05-12 00:52:49 --> Security Class Initialized
DEBUG - 2018-05-12 00:52:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 00:52:49 --> Input Class Initialized
INFO - 2018-05-12 00:52:49 --> Language Class Initialized
ERROR - 2018-05-12 00:52:49 --> 404 Page Not Found: /index
DEBUG - 2018-05-12 00:52:49 --> UTF-8 Support Enabled
INFO - 2018-05-12 00:52:49 --> Config Class Initialized
INFO - 2018-05-12 00:52:49 --> Config Class Initialized
INFO - 2018-05-12 00:52:49 --> Config Class Initialized
INFO - 2018-05-12 00:52:49 --> Hooks Class Initialized
INFO - 2018-05-12 00:52:49 --> Hooks Class Initialized
INFO - 2018-05-12 00:52:49 --> Hooks Class Initialized
INFO - 2018-05-12 00:52:49 --> Utf8 Class Initialized
DEBUG - 2018-05-12 00:52:49 --> UTF-8 Support Enabled
DEBUG - 2018-05-12 00:52:49 --> UTF-8 Support Enabled
INFO - 2018-05-12 00:52:49 --> Utf8 Class Initialized
INFO - 2018-05-12 00:52:49 --> Utf8 Class Initialized
INFO - 2018-05-12 00:52:49 --> URI Class Initialized
DEBUG - 2018-05-12 00:52:49 --> UTF-8 Support Enabled
INFO - 2018-05-12 00:52:49 --> URI Class Initialized
INFO - 2018-05-12 00:52:49 --> URI Class Initialized
INFO - 2018-05-12 00:52:49 --> Utf8 Class Initialized
INFO - 2018-05-12 00:52:49 --> Router Class Initialized
INFO - 2018-05-12 00:52:49 --> Output Class Initialized
INFO - 2018-05-12 00:52:49 --> Router Class Initialized
INFO - 2018-05-12 00:52:49 --> Router Class Initialized
INFO - 2018-05-12 00:52:50 --> URI Class Initialized
INFO - 2018-05-12 00:52:50 --> Security Class Initialized
INFO - 2018-05-12 00:52:50 --> Output Class Initialized
INFO - 2018-05-12 00:52:50 --> Router Class Initialized
INFO - 2018-05-12 00:52:50 --> Output Class Initialized
DEBUG - 2018-05-12 00:52:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 00:52:50 --> Output Class Initialized
INFO - 2018-05-12 00:52:50 --> Security Class Initialized
INFO - 2018-05-12 00:52:50 --> Security Class Initialized
INFO - 2018-05-12 00:52:50 --> Input Class Initialized
DEBUG - 2018-05-12 00:52:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 00:52:50 --> Security Class Initialized
INFO - 2018-05-12 00:52:50 --> Language Class Initialized
DEBUG - 2018-05-12 00:52:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 00:52:50 --> Input Class Initialized
DEBUG - 2018-05-12 00:52:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 00:52:50 --> Input Class Initialized
ERROR - 2018-05-12 00:52:50 --> 404 Page Not Found: /index
INFO - 2018-05-12 00:52:50 --> Input Class Initialized
INFO - 2018-05-12 00:52:50 --> Language Class Initialized
INFO - 2018-05-12 00:52:50 --> Language Class Initialized
INFO - 2018-05-12 00:52:50 --> Language Class Initialized
INFO - 2018-05-12 00:52:50 --> Config Class Initialized
ERROR - 2018-05-12 00:52:50 --> 404 Page Not Found: /index
INFO - 2018-05-12 00:52:50 --> Hooks Class Initialized
ERROR - 2018-05-12 00:52:50 --> 404 Page Not Found: /index
ERROR - 2018-05-12 00:52:50 --> 404 Page Not Found: /index
DEBUG - 2018-05-12 00:52:50 --> UTF-8 Support Enabled
INFO - 2018-05-12 00:52:50 --> Config Class Initialized
INFO - 2018-05-12 00:52:50 --> Utf8 Class Initialized
INFO - 2018-05-12 00:52:50 --> Hooks Class Initialized
INFO - 2018-05-12 00:52:50 --> Config Class Initialized
INFO - 2018-05-12 00:52:50 --> Hooks Class Initialized
DEBUG - 2018-05-12 00:52:50 --> UTF-8 Support Enabled
INFO - 2018-05-12 00:52:50 --> URI Class Initialized
DEBUG - 2018-05-12 00:52:50 --> UTF-8 Support Enabled
INFO - 2018-05-12 00:52:50 --> Utf8 Class Initialized
INFO - 2018-05-12 00:52:50 --> URI Class Initialized
INFO - 2018-05-12 00:52:50 --> Router Class Initialized
INFO - 2018-05-12 00:52:50 --> Output Class Initialized
INFO - 2018-05-12 00:52:50 --> Security Class Initialized
DEBUG - 2018-05-12 00:52:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 00:52:50 --> Utf8 Class Initialized
INFO - 2018-05-12 00:52:50 --> Input Class Initialized
INFO - 2018-05-12 00:52:50 --> Router Class Initialized
INFO - 2018-05-12 00:52:50 --> URI Class Initialized
INFO - 2018-05-12 00:52:50 --> Language Class Initialized
INFO - 2018-05-12 00:52:50 --> Output Class Initialized
ERROR - 2018-05-12 00:52:50 --> 404 Page Not Found: /index
INFO - 2018-05-12 00:52:50 --> Security Class Initialized
INFO - 2018-05-12 00:52:50 --> Router Class Initialized
DEBUG - 2018-05-12 00:52:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 00:52:50 --> Output Class Initialized
INFO - 2018-05-12 00:52:50 --> Input Class Initialized
INFO - 2018-05-12 00:52:50 --> Language Class Initialized
INFO - 2018-05-12 00:52:50 --> Security Class Initialized
DEBUG - 2018-05-12 00:52:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-05-12 00:52:50 --> 404 Page Not Found: /index
INFO - 2018-05-12 00:52:50 --> Input Class Initialized
INFO - 2018-05-12 00:52:50 --> Language Class Initialized
ERROR - 2018-05-12 00:52:50 --> 404 Page Not Found: /index
INFO - 2018-05-12 00:53:02 --> Config Class Initialized
INFO - 2018-05-12 00:53:02 --> Hooks Class Initialized
DEBUG - 2018-05-12 00:53:02 --> UTF-8 Support Enabled
INFO - 2018-05-12 00:53:02 --> Utf8 Class Initialized
INFO - 2018-05-12 00:53:02 --> URI Class Initialized
INFO - 2018-05-12 00:53:02 --> Router Class Initialized
INFO - 2018-05-12 00:53:02 --> Output Class Initialized
INFO - 2018-05-12 00:53:02 --> Security Class Initialized
DEBUG - 2018-05-12 00:53:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 00:53:02 --> Input Class Initialized
INFO - 2018-05-12 00:53:02 --> Language Class Initialized
INFO - 2018-05-12 00:53:02 --> Language Class Initialized
INFO - 2018-05-12 00:53:02 --> Config Class Initialized
INFO - 2018-05-12 00:53:02 --> Loader Class Initialized
DEBUG - 2018-05-12 00:53:02 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-12 00:53:02 --> Helper loaded: url_helper
INFO - 2018-05-12 00:53:02 --> Helper loaded: form_helper
INFO - 2018-05-12 00:53:02 --> Helper loaded: date_helper
INFO - 2018-05-12 00:53:02 --> Helper loaded: util_helper
INFO - 2018-05-12 00:53:02 --> Helper loaded: text_helper
INFO - 2018-05-12 00:53:02 --> Helper loaded: string_helper
INFO - 2018-05-12 00:53:02 --> Database Driver Class Initialized
DEBUG - 2018-05-12 00:53:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-12 00:53:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-12 00:53:02 --> Email Class Initialized
INFO - 2018-05-12 00:53:02 --> Controller Class Initialized
DEBUG - 2018-05-12 00:53:02 --> Programs MX_Controller Initialized
INFO - 2018-05-12 00:53:02 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-12 00:53:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-05-12 00:53:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-12 00:53:02 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-12 00:53:02 --> Login MX_Controller Initialized
DEBUG - 2018-05-12 00:53:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-12 00:53:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-05-12 00:53:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-05-12 00:53:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-05-12 00:53:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-05-12 00:53:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-05-12 00:53:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/programs/programs.php
INFO - 2018-05-12 00:53:02 --> Final output sent to browser
DEBUG - 2018-05-12 00:53:02 --> Total execution time: 0.4572
INFO - 2018-05-12 00:53:03 --> Config Class Initialized
INFO - 2018-05-12 00:53:03 --> Hooks Class Initialized
DEBUG - 2018-05-12 00:53:03 --> UTF-8 Support Enabled
INFO - 2018-05-12 00:53:03 --> Utf8 Class Initialized
INFO - 2018-05-12 00:53:03 --> URI Class Initialized
INFO - 2018-05-12 00:53:03 --> Router Class Initialized
INFO - 2018-05-12 00:53:03 --> Output Class Initialized
INFO - 2018-05-12 00:53:03 --> Security Class Initialized
DEBUG - 2018-05-12 00:53:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 00:53:03 --> Input Class Initialized
INFO - 2018-05-12 00:53:03 --> Language Class Initialized
INFO - 2018-05-12 00:53:03 --> Language Class Initialized
INFO - 2018-05-12 00:53:03 --> Config Class Initialized
INFO - 2018-05-12 00:53:03 --> Loader Class Initialized
DEBUG - 2018-05-12 00:53:03 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-12 00:53:03 --> Helper loaded: url_helper
INFO - 2018-05-12 00:53:03 --> Helper loaded: form_helper
INFO - 2018-05-12 00:53:03 --> Helper loaded: date_helper
INFO - 2018-05-12 00:53:03 --> Helper loaded: util_helper
INFO - 2018-05-12 00:53:03 --> Helper loaded: text_helper
INFO - 2018-05-12 00:53:03 --> Helper loaded: string_helper
INFO - 2018-05-12 00:53:03 --> Database Driver Class Initialized
DEBUG - 2018-05-12 00:53:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-12 00:53:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-12 00:53:03 --> Email Class Initialized
INFO - 2018-05-12 00:53:03 --> Controller Class Initialized
DEBUG - 2018-05-12 00:53:03 --> Programs MX_Controller Initialized
INFO - 2018-05-12 00:53:03 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-12 00:53:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-05-12 00:53:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-12 00:53:03 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-12 00:53:03 --> Login MX_Controller Initialized
DEBUG - 2018-05-12 00:53:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-12 00:53:03 --> Final output sent to browser
DEBUG - 2018-05-12 00:53:03 --> Total execution time: 0.6155
INFO - 2018-05-12 01:28:41 --> Config Class Initialized
INFO - 2018-05-12 01:28:41 --> Hooks Class Initialized
DEBUG - 2018-05-12 01:28:41 --> UTF-8 Support Enabled
INFO - 2018-05-12 01:28:41 --> Utf8 Class Initialized
INFO - 2018-05-12 01:28:41 --> URI Class Initialized
INFO - 2018-05-12 01:28:41 --> Router Class Initialized
INFO - 2018-05-12 01:28:41 --> Output Class Initialized
INFO - 2018-05-12 01:28:41 --> Security Class Initialized
DEBUG - 2018-05-12 01:28:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 01:28:41 --> Input Class Initialized
INFO - 2018-05-12 01:28:41 --> Language Class Initialized
INFO - 2018-05-12 01:28:41 --> Language Class Initialized
INFO - 2018-05-12 01:28:41 --> Config Class Initialized
INFO - 2018-05-12 01:28:41 --> Loader Class Initialized
DEBUG - 2018-05-12 01:28:41 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-12 01:28:42 --> Helper loaded: url_helper
INFO - 2018-05-12 01:28:42 --> Helper loaded: form_helper
INFO - 2018-05-12 01:28:42 --> Helper loaded: date_helper
INFO - 2018-05-12 01:28:42 --> Helper loaded: util_helper
INFO - 2018-05-12 01:28:42 --> Helper loaded: text_helper
INFO - 2018-05-12 01:28:42 --> Helper loaded: string_helper
INFO - 2018-05-12 01:28:42 --> Database Driver Class Initialized
DEBUG - 2018-05-12 01:28:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-12 01:28:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-12 01:28:42 --> Email Class Initialized
INFO - 2018-05-12 01:28:42 --> Controller Class Initialized
DEBUG - 2018-05-12 01:28:42 --> Chapters MX_Controller Initialized
INFO - 2018-05-12 01:28:42 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-12 01:28:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Chapters_model.php
DEBUG - 2018-05-12 01:28:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-12 01:28:42 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-12 01:28:42 --> Login MX_Controller Initialized
DEBUG - 2018-05-12 01:28:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-12 01:28:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-05-12 01:28:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-05-12 01:28:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-05-12 01:28:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-05-12 01:28:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-05-12 01:28:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/chapters/chapters.php
INFO - 2018-05-12 01:28:42 --> Final output sent to browser
DEBUG - 2018-05-12 01:28:42 --> Total execution time: 1.1650
INFO - 2018-05-12 01:28:43 --> Config Class Initialized
INFO - 2018-05-12 01:28:43 --> Hooks Class Initialized
DEBUG - 2018-05-12 01:28:43 --> UTF-8 Support Enabled
INFO - 2018-05-12 01:28:43 --> Utf8 Class Initialized
INFO - 2018-05-12 01:28:43 --> URI Class Initialized
INFO - 2018-05-12 01:28:43 --> Router Class Initialized
INFO - 2018-05-12 01:28:43 --> Output Class Initialized
INFO - 2018-05-12 01:28:43 --> Security Class Initialized
DEBUG - 2018-05-12 01:28:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 01:28:43 --> Input Class Initialized
INFO - 2018-05-12 01:28:43 --> Language Class Initialized
INFO - 2018-05-12 01:28:43 --> Language Class Initialized
INFO - 2018-05-12 01:28:43 --> Config Class Initialized
INFO - 2018-05-12 01:28:43 --> Loader Class Initialized
DEBUG - 2018-05-12 01:28:43 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-12 01:28:43 --> Helper loaded: url_helper
INFO - 2018-05-12 01:28:43 --> Helper loaded: form_helper
INFO - 2018-05-12 01:28:43 --> Helper loaded: date_helper
INFO - 2018-05-12 01:28:43 --> Helper loaded: util_helper
INFO - 2018-05-12 01:28:43 --> Helper loaded: text_helper
INFO - 2018-05-12 01:28:43 --> Helper loaded: string_helper
INFO - 2018-05-12 01:28:43 --> Database Driver Class Initialized
DEBUG - 2018-05-12 01:28:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-12 01:28:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-12 01:28:43 --> Email Class Initialized
INFO - 2018-05-12 01:28:43 --> Controller Class Initialized
DEBUG - 2018-05-12 01:28:43 --> Chapters MX_Controller Initialized
INFO - 2018-05-12 01:28:43 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-12 01:28:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Chapters_model.php
DEBUG - 2018-05-12 01:28:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-12 01:28:43 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-12 01:28:43 --> Login MX_Controller Initialized
DEBUG - 2018-05-12 01:28:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
ERROR - 2018-05-12 01:28:43 --> Query error: Unknown column 'chapters.chapter_id' in 'field list' - Invalid query: SELECT  chapters.chapter_id,chapters.chapter_name,chapters.chapter_description,chapters.added_date,chapters.status,chapters.chapter_id FROM   chapters   WHERE chapters.chapter_id!= ''     LIMIT 0, 10
INFO - 2018-05-12 01:28:43 --> Language file loaded: language/english/db_lang.php
INFO - 2018-05-12 01:29:43 --> Config Class Initialized
INFO - 2018-05-12 01:29:43 --> Hooks Class Initialized
DEBUG - 2018-05-12 01:29:43 --> UTF-8 Support Enabled
INFO - 2018-05-12 01:29:43 --> Utf8 Class Initialized
INFO - 2018-05-12 01:29:43 --> URI Class Initialized
INFO - 2018-05-12 01:29:44 --> Router Class Initialized
INFO - 2018-05-12 01:29:44 --> Output Class Initialized
INFO - 2018-05-12 01:29:44 --> Security Class Initialized
DEBUG - 2018-05-12 01:29:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 01:29:44 --> Input Class Initialized
INFO - 2018-05-12 01:29:44 --> Language Class Initialized
INFO - 2018-05-12 01:29:44 --> Language Class Initialized
INFO - 2018-05-12 01:29:44 --> Config Class Initialized
INFO - 2018-05-12 01:29:44 --> Loader Class Initialized
DEBUG - 2018-05-12 01:29:44 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-12 01:29:44 --> Helper loaded: url_helper
INFO - 2018-05-12 01:29:44 --> Helper loaded: form_helper
INFO - 2018-05-12 01:29:44 --> Helper loaded: date_helper
INFO - 2018-05-12 01:29:44 --> Helper loaded: util_helper
INFO - 2018-05-12 01:29:44 --> Helper loaded: text_helper
INFO - 2018-05-12 01:29:44 --> Helper loaded: string_helper
INFO - 2018-05-12 01:29:44 --> Database Driver Class Initialized
DEBUG - 2018-05-12 01:29:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-12 01:29:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-12 01:29:44 --> Email Class Initialized
INFO - 2018-05-12 01:29:44 --> Controller Class Initialized
DEBUG - 2018-05-12 01:29:44 --> Chapters MX_Controller Initialized
INFO - 2018-05-12 01:29:44 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-12 01:29:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Chapters_model.php
DEBUG - 2018-05-12 01:29:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-12 01:29:44 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-12 01:29:44 --> Login MX_Controller Initialized
DEBUG - 2018-05-12 01:29:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-12 01:29:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-05-12 01:29:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-05-12 01:29:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-05-12 01:29:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-05-12 01:29:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-05-12 01:29:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/chapters/chapters.php
INFO - 2018-05-12 01:29:44 --> Final output sent to browser
DEBUG - 2018-05-12 01:29:44 --> Total execution time: 0.4033
INFO - 2018-05-12 01:29:44 --> Config Class Initialized
INFO - 2018-05-12 01:29:44 --> Hooks Class Initialized
DEBUG - 2018-05-12 01:29:44 --> UTF-8 Support Enabled
INFO - 2018-05-12 01:29:44 --> Utf8 Class Initialized
INFO - 2018-05-12 01:29:44 --> URI Class Initialized
INFO - 2018-05-12 01:29:44 --> Router Class Initialized
INFO - 2018-05-12 01:29:44 --> Output Class Initialized
INFO - 2018-05-12 01:29:44 --> Security Class Initialized
DEBUG - 2018-05-12 01:29:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 01:29:44 --> Input Class Initialized
INFO - 2018-05-12 01:29:44 --> Language Class Initialized
INFO - 2018-05-12 01:29:44 --> Language Class Initialized
INFO - 2018-05-12 01:29:44 --> Config Class Initialized
INFO - 2018-05-12 01:29:44 --> Loader Class Initialized
DEBUG - 2018-05-12 01:29:44 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-12 01:29:45 --> Helper loaded: url_helper
INFO - 2018-05-12 01:29:45 --> Helper loaded: form_helper
INFO - 2018-05-12 01:29:45 --> Helper loaded: date_helper
INFO - 2018-05-12 01:29:45 --> Helper loaded: util_helper
INFO - 2018-05-12 01:29:45 --> Helper loaded: text_helper
INFO - 2018-05-12 01:29:45 --> Helper loaded: string_helper
INFO - 2018-05-12 01:29:45 --> Database Driver Class Initialized
DEBUG - 2018-05-12 01:29:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-12 01:29:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-12 01:29:45 --> Email Class Initialized
INFO - 2018-05-12 01:29:45 --> Controller Class Initialized
DEBUG - 2018-05-12 01:29:45 --> Chapters MX_Controller Initialized
INFO - 2018-05-12 01:29:45 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-12 01:29:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Chapters_model.php
DEBUG - 2018-05-12 01:29:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-12 01:29:45 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-12 01:29:45 --> Login MX_Controller Initialized
DEBUG - 2018-05-12 01:29:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
ERROR - 2018-05-12 01:29:45 --> Query error: Unknown column 'chapters.chapter_description' in 'field list' - Invalid query: SELECT  chapters.chapter_id,chapters.chapter_name,chapters.chapter_description,chapters.added_date,chapters.status,chapters.chapter_id FROM   chapters   WHERE chapters.chapter_id!= ''     LIMIT 0, 10
INFO - 2018-05-12 01:29:45 --> Language file loaded: language/english/db_lang.php
INFO - 2018-05-12 01:29:51 --> Config Class Initialized
INFO - 2018-05-12 01:29:51 --> Hooks Class Initialized
DEBUG - 2018-05-12 01:29:51 --> UTF-8 Support Enabled
INFO - 2018-05-12 01:29:51 --> Utf8 Class Initialized
INFO - 2018-05-12 01:29:51 --> URI Class Initialized
INFO - 2018-05-12 01:29:51 --> Router Class Initialized
INFO - 2018-05-12 01:29:51 --> Output Class Initialized
INFO - 2018-05-12 01:29:51 --> Security Class Initialized
DEBUG - 2018-05-12 01:29:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 01:29:51 --> Input Class Initialized
INFO - 2018-05-12 01:29:51 --> Language Class Initialized
INFO - 2018-05-12 01:29:51 --> Language Class Initialized
INFO - 2018-05-12 01:29:51 --> Config Class Initialized
INFO - 2018-05-12 01:29:51 --> Loader Class Initialized
DEBUG - 2018-05-12 01:29:51 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-12 01:29:51 --> Helper loaded: url_helper
INFO - 2018-05-12 01:29:51 --> Helper loaded: form_helper
INFO - 2018-05-12 01:29:51 --> Helper loaded: date_helper
INFO - 2018-05-12 01:29:51 --> Helper loaded: util_helper
INFO - 2018-05-12 01:29:51 --> Helper loaded: text_helper
INFO - 2018-05-12 01:29:51 --> Helper loaded: string_helper
INFO - 2018-05-12 01:29:51 --> Database Driver Class Initialized
DEBUG - 2018-05-12 01:29:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-12 01:29:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-12 01:29:51 --> Email Class Initialized
INFO - 2018-05-12 01:29:51 --> Controller Class Initialized
DEBUG - 2018-05-12 01:29:51 --> Chapters MX_Controller Initialized
INFO - 2018-05-12 01:29:51 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-12 01:29:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Chapters_model.php
DEBUG - 2018-05-12 01:29:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-12 01:29:51 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-12 01:29:51 --> Login MX_Controller Initialized
DEBUG - 2018-05-12 01:29:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
ERROR - 2018-05-12 01:29:52 --> Query error: Unknown column 'chapters.chapter_description' in 'field list' - Invalid query: SELECT  chapters.chapter_id,chapters.chapter_name,chapters.chapter_description,chapters.added_date,chapters.status,chapters.chapter_id FROM   chapters   WHERE chapters.chapter_id!= ''    ORDER BY  chapters.chapter_name asc LIMIT 0, 10
INFO - 2018-05-12 01:29:52 --> Language file loaded: language/english/db_lang.php
INFO - 2018-05-12 01:29:55 --> Config Class Initialized
INFO - 2018-05-12 01:29:55 --> Hooks Class Initialized
DEBUG - 2018-05-12 01:29:55 --> UTF-8 Support Enabled
INFO - 2018-05-12 01:29:55 --> Utf8 Class Initialized
INFO - 2018-05-12 01:29:55 --> URI Class Initialized
INFO - 2018-05-12 01:29:55 --> Router Class Initialized
INFO - 2018-05-12 01:29:55 --> Output Class Initialized
INFO - 2018-05-12 01:29:55 --> Security Class Initialized
DEBUG - 2018-05-12 01:29:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 01:29:55 --> Input Class Initialized
INFO - 2018-05-12 01:29:55 --> Language Class Initialized
INFO - 2018-05-12 01:29:55 --> Language Class Initialized
INFO - 2018-05-12 01:29:55 --> Config Class Initialized
INFO - 2018-05-12 01:29:55 --> Loader Class Initialized
DEBUG - 2018-05-12 01:29:55 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-12 01:29:56 --> Helper loaded: url_helper
INFO - 2018-05-12 01:29:56 --> Helper loaded: form_helper
INFO - 2018-05-12 01:29:56 --> Helper loaded: date_helper
INFO - 2018-05-12 01:29:56 --> Helper loaded: util_helper
INFO - 2018-05-12 01:29:56 --> Helper loaded: text_helper
INFO - 2018-05-12 01:29:56 --> Helper loaded: string_helper
INFO - 2018-05-12 01:29:56 --> Database Driver Class Initialized
DEBUG - 2018-05-12 01:29:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-12 01:29:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-12 01:29:56 --> Email Class Initialized
INFO - 2018-05-12 01:29:56 --> Controller Class Initialized
DEBUG - 2018-05-12 01:29:56 --> Chapters MX_Controller Initialized
INFO - 2018-05-12 01:29:56 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-12 01:29:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Chapters_model.php
DEBUG - 2018-05-12 01:29:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-12 01:29:56 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-12 01:29:56 --> Login MX_Controller Initialized
DEBUG - 2018-05-12 01:29:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
ERROR - 2018-05-12 01:29:56 --> Query error: Unknown column 'chapters.chapter_description' in 'field list' - Invalid query: SELECT  chapters.chapter_id,chapters.chapter_name,chapters.chapter_description,chapters.added_date,chapters.status,chapters.chapter_id FROM   chapters   WHERE chapters.chapter_id!= ''     
INFO - 2018-05-12 01:29:56 --> Language file loaded: language/english/db_lang.php
INFO - 2018-05-12 01:31:20 --> Config Class Initialized
INFO - 2018-05-12 01:31:20 --> Hooks Class Initialized
DEBUG - 2018-05-12 01:31:20 --> UTF-8 Support Enabled
INFO - 2018-05-12 01:31:20 --> Utf8 Class Initialized
INFO - 2018-05-12 01:31:20 --> URI Class Initialized
INFO - 2018-05-12 01:31:20 --> Router Class Initialized
INFO - 2018-05-12 01:31:20 --> Output Class Initialized
INFO - 2018-05-12 01:31:20 --> Security Class Initialized
DEBUG - 2018-05-12 01:31:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 01:31:20 --> Input Class Initialized
INFO - 2018-05-12 01:31:20 --> Language Class Initialized
INFO - 2018-05-12 01:31:20 --> Language Class Initialized
INFO - 2018-05-12 01:31:20 --> Config Class Initialized
INFO - 2018-05-12 01:31:20 --> Loader Class Initialized
DEBUG - 2018-05-12 01:31:20 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-12 01:31:20 --> Helper loaded: url_helper
INFO - 2018-05-12 01:31:20 --> Helper loaded: form_helper
INFO - 2018-05-12 01:31:20 --> Helper loaded: date_helper
INFO - 2018-05-12 01:31:20 --> Helper loaded: util_helper
INFO - 2018-05-12 01:31:20 --> Helper loaded: text_helper
INFO - 2018-05-12 01:31:20 --> Helper loaded: string_helper
INFO - 2018-05-12 01:31:20 --> Database Driver Class Initialized
DEBUG - 2018-05-12 01:31:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-12 01:31:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-12 01:31:20 --> Email Class Initialized
INFO - 2018-05-12 01:31:20 --> Controller Class Initialized
DEBUG - 2018-05-12 01:31:20 --> Chapters MX_Controller Initialized
INFO - 2018-05-12 01:31:20 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-12 01:31:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Chapters_model.php
DEBUG - 2018-05-12 01:31:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-12 01:31:20 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-12 01:31:20 --> Login MX_Controller Initialized
DEBUG - 2018-05-12 01:31:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
ERROR - 2018-05-12 01:31:20 --> Severity: Notice --> Undefined index: sEcho E:\xampp\htdocs\consulting\system\database\DB_query_builder.php 2920
INFO - 2018-05-12 01:31:20 --> Final output sent to browser
DEBUG - 2018-05-12 01:31:20 --> Total execution time: 0.3889
INFO - 2018-05-12 01:31:23 --> Config Class Initialized
INFO - 2018-05-12 01:31:23 --> Hooks Class Initialized
DEBUG - 2018-05-12 01:31:23 --> UTF-8 Support Enabled
INFO - 2018-05-12 01:31:24 --> Utf8 Class Initialized
INFO - 2018-05-12 01:31:24 --> URI Class Initialized
INFO - 2018-05-12 01:31:24 --> Router Class Initialized
INFO - 2018-05-12 01:31:24 --> Output Class Initialized
INFO - 2018-05-12 01:31:24 --> Security Class Initialized
DEBUG - 2018-05-12 01:31:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 01:31:24 --> Input Class Initialized
INFO - 2018-05-12 01:31:24 --> Language Class Initialized
INFO - 2018-05-12 01:31:24 --> Language Class Initialized
INFO - 2018-05-12 01:31:24 --> Config Class Initialized
INFO - 2018-05-12 01:31:24 --> Loader Class Initialized
DEBUG - 2018-05-12 01:31:24 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-12 01:31:24 --> Helper loaded: url_helper
INFO - 2018-05-12 01:31:24 --> Helper loaded: form_helper
INFO - 2018-05-12 01:31:24 --> Helper loaded: date_helper
INFO - 2018-05-12 01:31:24 --> Helper loaded: util_helper
INFO - 2018-05-12 01:31:24 --> Helper loaded: text_helper
INFO - 2018-05-12 01:31:24 --> Helper loaded: string_helper
INFO - 2018-05-12 01:31:24 --> Database Driver Class Initialized
DEBUG - 2018-05-12 01:31:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-12 01:31:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-12 01:31:24 --> Email Class Initialized
INFO - 2018-05-12 01:31:24 --> Controller Class Initialized
DEBUG - 2018-05-12 01:31:24 --> Chapters MX_Controller Initialized
INFO - 2018-05-12 01:31:24 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-12 01:31:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Chapters_model.php
DEBUG - 2018-05-12 01:31:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-12 01:31:24 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-12 01:31:24 --> Login MX_Controller Initialized
DEBUG - 2018-05-12 01:31:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-12 01:31:24 --> Final output sent to browser
DEBUG - 2018-05-12 01:31:24 --> Total execution time: 0.3702
INFO - 2018-05-12 01:31:27 --> Config Class Initialized
INFO - 2018-05-12 01:31:27 --> Hooks Class Initialized
DEBUG - 2018-05-12 01:31:27 --> UTF-8 Support Enabled
INFO - 2018-05-12 01:31:27 --> Utf8 Class Initialized
INFO - 2018-05-12 01:31:27 --> URI Class Initialized
INFO - 2018-05-12 01:31:27 --> Router Class Initialized
INFO - 2018-05-12 01:31:27 --> Output Class Initialized
INFO - 2018-05-12 01:31:27 --> Security Class Initialized
DEBUG - 2018-05-12 01:31:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 01:31:27 --> Input Class Initialized
INFO - 2018-05-12 01:31:27 --> Language Class Initialized
INFO - 2018-05-12 01:31:27 --> Language Class Initialized
INFO - 2018-05-12 01:31:27 --> Config Class Initialized
INFO - 2018-05-12 01:31:27 --> Loader Class Initialized
DEBUG - 2018-05-12 01:31:27 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-12 01:31:27 --> Helper loaded: url_helper
INFO - 2018-05-12 01:31:27 --> Helper loaded: form_helper
INFO - 2018-05-12 01:31:27 --> Helper loaded: date_helper
INFO - 2018-05-12 01:31:27 --> Helper loaded: util_helper
INFO - 2018-05-12 01:31:27 --> Helper loaded: text_helper
INFO - 2018-05-12 01:31:27 --> Helper loaded: string_helper
INFO - 2018-05-12 01:31:27 --> Database Driver Class Initialized
DEBUG - 2018-05-12 01:31:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-12 01:31:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-12 01:31:27 --> Email Class Initialized
INFO - 2018-05-12 01:31:27 --> Controller Class Initialized
ERROR - 2018-05-12 01:31:27 --> 404 Page Not Found: ../modules/admin/controllers/Admin/videos
INFO - 2018-05-12 01:31:30 --> Config Class Initialized
INFO - 2018-05-12 01:31:30 --> Hooks Class Initialized
DEBUG - 2018-05-12 01:31:30 --> UTF-8 Support Enabled
INFO - 2018-05-12 01:31:30 --> Utf8 Class Initialized
INFO - 2018-05-12 01:31:30 --> URI Class Initialized
INFO - 2018-05-12 01:31:30 --> Router Class Initialized
INFO - 2018-05-12 01:31:30 --> Output Class Initialized
INFO - 2018-05-12 01:31:30 --> Security Class Initialized
DEBUG - 2018-05-12 01:31:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 01:31:30 --> Input Class Initialized
INFO - 2018-05-12 01:31:30 --> Language Class Initialized
INFO - 2018-05-12 01:31:30 --> Language Class Initialized
INFO - 2018-05-12 01:31:30 --> Config Class Initialized
INFO - 2018-05-12 01:31:30 --> Loader Class Initialized
DEBUG - 2018-05-12 01:31:30 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-12 01:31:30 --> Helper loaded: url_helper
INFO - 2018-05-12 01:31:30 --> Helper loaded: form_helper
INFO - 2018-05-12 01:31:30 --> Helper loaded: date_helper
INFO - 2018-05-12 01:31:30 --> Helper loaded: util_helper
INFO - 2018-05-12 01:31:30 --> Helper loaded: text_helper
INFO - 2018-05-12 01:31:30 --> Helper loaded: string_helper
INFO - 2018-05-12 01:31:30 --> Database Driver Class Initialized
DEBUG - 2018-05-12 01:31:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-12 01:31:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-12 01:31:30 --> Email Class Initialized
INFO - 2018-05-12 01:31:30 --> Controller Class Initialized
DEBUG - 2018-05-12 01:31:30 --> Chapters MX_Controller Initialized
INFO - 2018-05-12 01:31:30 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-12 01:31:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Chapters_model.php
DEBUG - 2018-05-12 01:31:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-12 01:31:30 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-12 01:31:30 --> Login MX_Controller Initialized
DEBUG - 2018-05-12 01:31:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-12 01:31:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-05-12 01:31:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-05-12 01:31:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-05-12 01:31:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-05-12 01:31:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-05-12 01:31:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/chapters/chapters.php
INFO - 2018-05-12 01:31:30 --> Final output sent to browser
DEBUG - 2018-05-12 01:31:30 --> Total execution time: 0.4187
INFO - 2018-05-12 01:31:31 --> Config Class Initialized
INFO - 2018-05-12 01:31:31 --> Hooks Class Initialized
DEBUG - 2018-05-12 01:31:31 --> UTF-8 Support Enabled
INFO - 2018-05-12 01:31:31 --> Utf8 Class Initialized
INFO - 2018-05-12 01:31:31 --> URI Class Initialized
INFO - 2018-05-12 01:31:31 --> Router Class Initialized
INFO - 2018-05-12 01:31:31 --> Output Class Initialized
INFO - 2018-05-12 01:31:31 --> Security Class Initialized
DEBUG - 2018-05-12 01:31:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 01:31:31 --> Input Class Initialized
INFO - 2018-05-12 01:31:31 --> Language Class Initialized
INFO - 2018-05-12 01:31:31 --> Language Class Initialized
INFO - 2018-05-12 01:31:31 --> Config Class Initialized
INFO - 2018-05-12 01:31:31 --> Loader Class Initialized
DEBUG - 2018-05-12 01:31:31 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-12 01:31:31 --> Helper loaded: url_helper
INFO - 2018-05-12 01:31:31 --> Helper loaded: form_helper
INFO - 2018-05-12 01:31:31 --> Helper loaded: date_helper
INFO - 2018-05-12 01:31:31 --> Helper loaded: util_helper
INFO - 2018-05-12 01:31:31 --> Helper loaded: text_helper
INFO - 2018-05-12 01:31:31 --> Helper loaded: string_helper
INFO - 2018-05-12 01:31:31 --> Database Driver Class Initialized
DEBUG - 2018-05-12 01:31:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-12 01:31:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-12 01:31:31 --> Email Class Initialized
INFO - 2018-05-12 01:31:31 --> Controller Class Initialized
DEBUG - 2018-05-12 01:31:31 --> Chapters MX_Controller Initialized
INFO - 2018-05-12 01:31:31 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-12 01:31:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Chapters_model.php
DEBUG - 2018-05-12 01:31:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-12 01:31:31 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-12 01:31:31 --> Login MX_Controller Initialized
DEBUG - 2018-05-12 01:31:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-12 01:31:32 --> Final output sent to browser
DEBUG - 2018-05-12 01:31:32 --> Total execution time: 0.6532
INFO - 2018-05-12 01:31:34 --> Config Class Initialized
INFO - 2018-05-12 01:31:34 --> Hooks Class Initialized
DEBUG - 2018-05-12 01:31:34 --> UTF-8 Support Enabled
INFO - 2018-05-12 01:31:34 --> Utf8 Class Initialized
INFO - 2018-05-12 01:31:34 --> URI Class Initialized
INFO - 2018-05-12 01:31:34 --> Router Class Initialized
INFO - 2018-05-12 01:31:34 --> Output Class Initialized
INFO - 2018-05-12 01:31:34 --> Security Class Initialized
DEBUG - 2018-05-12 01:31:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 01:31:34 --> Input Class Initialized
INFO - 2018-05-12 01:31:34 --> Language Class Initialized
INFO - 2018-05-12 01:31:34 --> Language Class Initialized
INFO - 2018-05-12 01:31:34 --> Config Class Initialized
INFO - 2018-05-12 01:31:34 --> Loader Class Initialized
DEBUG - 2018-05-12 01:31:34 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-12 01:31:34 --> Helper loaded: url_helper
INFO - 2018-05-12 01:31:34 --> Helper loaded: form_helper
INFO - 2018-05-12 01:31:34 --> Helper loaded: date_helper
INFO - 2018-05-12 01:31:34 --> Helper loaded: util_helper
INFO - 2018-05-12 01:31:34 --> Helper loaded: text_helper
INFO - 2018-05-12 01:31:34 --> Helper loaded: string_helper
INFO - 2018-05-12 01:31:34 --> Database Driver Class Initialized
DEBUG - 2018-05-12 01:31:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-12 01:31:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-12 01:31:34 --> Email Class Initialized
INFO - 2018-05-12 01:31:34 --> Controller Class Initialized
DEBUG - 2018-05-12 01:31:34 --> Chapters MX_Controller Initialized
INFO - 2018-05-12 01:31:34 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-12 01:31:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Chapters_model.php
DEBUG - 2018-05-12 01:31:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-12 01:31:34 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-12 01:31:34 --> Login MX_Controller Initialized
DEBUG - 2018-05-12 01:31:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-12 01:31:34 --> Final output sent to browser
DEBUG - 2018-05-12 01:31:34 --> Total execution time: 0.3649
INFO - 2018-05-12 01:31:35 --> Config Class Initialized
INFO - 2018-05-12 01:31:35 --> Hooks Class Initialized
DEBUG - 2018-05-12 01:31:35 --> UTF-8 Support Enabled
INFO - 2018-05-12 01:31:35 --> Utf8 Class Initialized
INFO - 2018-05-12 01:31:35 --> URI Class Initialized
INFO - 2018-05-12 01:31:35 --> Router Class Initialized
INFO - 2018-05-12 01:31:35 --> Output Class Initialized
INFO - 2018-05-12 01:31:35 --> Security Class Initialized
DEBUG - 2018-05-12 01:31:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 01:31:35 --> Input Class Initialized
INFO - 2018-05-12 01:31:35 --> Language Class Initialized
INFO - 2018-05-12 01:31:35 --> Language Class Initialized
INFO - 2018-05-12 01:31:35 --> Config Class Initialized
INFO - 2018-05-12 01:31:35 --> Loader Class Initialized
DEBUG - 2018-05-12 01:31:35 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-12 01:31:35 --> Helper loaded: url_helper
INFO - 2018-05-12 01:31:35 --> Helper loaded: form_helper
INFO - 2018-05-12 01:31:35 --> Helper loaded: date_helper
INFO - 2018-05-12 01:31:35 --> Helper loaded: util_helper
INFO - 2018-05-12 01:31:35 --> Helper loaded: text_helper
INFO - 2018-05-12 01:31:35 --> Helper loaded: string_helper
INFO - 2018-05-12 01:31:35 --> Database Driver Class Initialized
DEBUG - 2018-05-12 01:31:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-12 01:31:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-12 01:31:35 --> Email Class Initialized
INFO - 2018-05-12 01:31:35 --> Controller Class Initialized
DEBUG - 2018-05-12 01:31:35 --> Chapters MX_Controller Initialized
INFO - 2018-05-12 01:31:35 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-12 01:31:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Chapters_model.php
DEBUG - 2018-05-12 01:31:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-12 01:31:35 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-12 01:31:35 --> Login MX_Controller Initialized
DEBUG - 2018-05-12 01:31:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-12 01:31:35 --> Final output sent to browser
DEBUG - 2018-05-12 01:31:35 --> Total execution time: 0.4607
INFO - 2018-05-12 01:31:41 --> Config Class Initialized
INFO - 2018-05-12 01:31:41 --> Hooks Class Initialized
DEBUG - 2018-05-12 01:31:41 --> UTF-8 Support Enabled
INFO - 2018-05-12 01:31:41 --> Utf8 Class Initialized
INFO - 2018-05-12 01:31:41 --> URI Class Initialized
INFO - 2018-05-12 01:31:41 --> Router Class Initialized
INFO - 2018-05-12 01:31:41 --> Output Class Initialized
INFO - 2018-05-12 01:31:41 --> Security Class Initialized
DEBUG - 2018-05-12 01:31:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 01:31:41 --> Input Class Initialized
INFO - 2018-05-12 01:31:41 --> Language Class Initialized
INFO - 2018-05-12 01:31:41 --> Language Class Initialized
INFO - 2018-05-12 01:31:41 --> Config Class Initialized
INFO - 2018-05-12 01:31:41 --> Loader Class Initialized
DEBUG - 2018-05-12 01:31:41 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-12 01:31:41 --> Helper loaded: url_helper
INFO - 2018-05-12 01:31:41 --> Helper loaded: form_helper
INFO - 2018-05-12 01:31:41 --> Helper loaded: date_helper
INFO - 2018-05-12 01:31:41 --> Helper loaded: util_helper
INFO - 2018-05-12 01:31:41 --> Helper loaded: text_helper
INFO - 2018-05-12 01:31:41 --> Helper loaded: string_helper
INFO - 2018-05-12 01:31:41 --> Database Driver Class Initialized
DEBUG - 2018-05-12 01:31:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-12 01:31:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-12 01:31:41 --> Email Class Initialized
INFO - 2018-05-12 01:31:41 --> Controller Class Initialized
DEBUG - 2018-05-12 01:31:41 --> Chapters MX_Controller Initialized
INFO - 2018-05-12 01:31:41 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-12 01:31:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Chapters_model.php
DEBUG - 2018-05-12 01:31:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-12 01:31:41 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-12 01:31:41 --> Login MX_Controller Initialized
DEBUG - 2018-05-12 01:31:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-12 01:31:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-05-12 01:31:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-05-12 01:31:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-05-12 01:31:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-05-12 01:31:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-05-12 01:31:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/chapters/create_chapter.php
INFO - 2018-05-12 01:31:41 --> Final output sent to browser
DEBUG - 2018-05-12 01:31:41 --> Total execution time: 0.4684
INFO - 2018-05-12 01:31:46 --> Config Class Initialized
INFO - 2018-05-12 01:31:46 --> Hooks Class Initialized
DEBUG - 2018-05-12 01:31:46 --> UTF-8 Support Enabled
INFO - 2018-05-12 01:31:46 --> Utf8 Class Initialized
INFO - 2018-05-12 01:31:46 --> URI Class Initialized
INFO - 2018-05-12 01:31:46 --> Router Class Initialized
INFO - 2018-05-12 01:31:46 --> Output Class Initialized
INFO - 2018-05-12 01:31:46 --> Security Class Initialized
DEBUG - 2018-05-12 01:31:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 01:31:46 --> Input Class Initialized
INFO - 2018-05-12 01:31:46 --> Language Class Initialized
INFO - 2018-05-12 01:31:46 --> Language Class Initialized
INFO - 2018-05-12 01:31:46 --> Config Class Initialized
INFO - 2018-05-12 01:31:46 --> Loader Class Initialized
DEBUG - 2018-05-12 01:31:46 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-12 01:31:46 --> Helper loaded: url_helper
INFO - 2018-05-12 01:31:46 --> Helper loaded: form_helper
INFO - 2018-05-12 01:31:46 --> Helper loaded: date_helper
INFO - 2018-05-12 01:31:46 --> Helper loaded: util_helper
INFO - 2018-05-12 01:31:47 --> Helper loaded: text_helper
INFO - 2018-05-12 01:31:47 --> Helper loaded: string_helper
INFO - 2018-05-12 01:31:47 --> Database Driver Class Initialized
DEBUG - 2018-05-12 01:31:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-12 01:31:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-12 01:31:47 --> Email Class Initialized
INFO - 2018-05-12 01:31:47 --> Controller Class Initialized
DEBUG - 2018-05-12 01:31:47 --> Chapters MX_Controller Initialized
INFO - 2018-05-12 01:31:47 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-12 01:31:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Chapters_model.php
DEBUG - 2018-05-12 01:31:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-12 01:31:47 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-12 01:31:47 --> Login MX_Controller Initialized
DEBUG - 2018-05-12 01:31:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-12 01:31:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-05-12 01:31:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-05-12 01:31:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-05-12 01:31:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-05-12 01:31:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-05-12 01:31:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/chapters/chapters.php
INFO - 2018-05-12 01:31:47 --> Final output sent to browser
DEBUG - 2018-05-12 01:31:47 --> Total execution time: 0.4339
INFO - 2018-05-12 01:31:47 --> Config Class Initialized
INFO - 2018-05-12 01:31:47 --> Hooks Class Initialized
DEBUG - 2018-05-12 01:31:47 --> UTF-8 Support Enabled
INFO - 2018-05-12 01:31:47 --> Utf8 Class Initialized
INFO - 2018-05-12 01:31:47 --> URI Class Initialized
INFO - 2018-05-12 01:31:47 --> Router Class Initialized
INFO - 2018-05-12 01:31:47 --> Output Class Initialized
INFO - 2018-05-12 01:31:47 --> Security Class Initialized
DEBUG - 2018-05-12 01:31:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 01:31:47 --> Input Class Initialized
INFO - 2018-05-12 01:31:47 --> Language Class Initialized
INFO - 2018-05-12 01:31:47 --> Language Class Initialized
INFO - 2018-05-12 01:31:47 --> Config Class Initialized
INFO - 2018-05-12 01:31:47 --> Loader Class Initialized
DEBUG - 2018-05-12 01:31:47 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-12 01:31:47 --> Helper loaded: url_helper
INFO - 2018-05-12 01:31:47 --> Helper loaded: form_helper
INFO - 2018-05-12 01:31:47 --> Helper loaded: date_helper
INFO - 2018-05-12 01:31:47 --> Helper loaded: util_helper
INFO - 2018-05-12 01:31:47 --> Helper loaded: text_helper
INFO - 2018-05-12 01:31:47 --> Helper loaded: string_helper
INFO - 2018-05-12 01:31:47 --> Database Driver Class Initialized
DEBUG - 2018-05-12 01:31:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-12 01:31:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-12 01:31:47 --> Email Class Initialized
INFO - 2018-05-12 01:31:47 --> Controller Class Initialized
DEBUG - 2018-05-12 01:31:47 --> Chapters MX_Controller Initialized
INFO - 2018-05-12 01:31:47 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-12 01:31:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Chapters_model.php
DEBUG - 2018-05-12 01:31:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-12 01:31:47 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-12 01:31:47 --> Login MX_Controller Initialized
DEBUG - 2018-05-12 01:31:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-12 01:31:48 --> Final output sent to browser
DEBUG - 2018-05-12 01:31:48 --> Total execution time: 0.4771
INFO - 2018-05-12 01:35:45 --> Config Class Initialized
INFO - 2018-05-12 01:35:45 --> Hooks Class Initialized
DEBUG - 2018-05-12 01:35:45 --> UTF-8 Support Enabled
INFO - 2018-05-12 01:35:45 --> Utf8 Class Initialized
INFO - 2018-05-12 01:35:45 --> URI Class Initialized
INFO - 2018-05-12 01:35:45 --> Router Class Initialized
INFO - 2018-05-12 01:35:45 --> Output Class Initialized
INFO - 2018-05-12 01:35:45 --> Security Class Initialized
DEBUG - 2018-05-12 01:35:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 01:35:45 --> Input Class Initialized
INFO - 2018-05-12 01:35:45 --> Language Class Initialized
INFO - 2018-05-12 01:35:45 --> Language Class Initialized
INFO - 2018-05-12 01:35:45 --> Config Class Initialized
INFO - 2018-05-12 01:35:45 --> Loader Class Initialized
DEBUG - 2018-05-12 01:35:45 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-12 01:35:45 --> Helper loaded: url_helper
INFO - 2018-05-12 01:35:45 --> Helper loaded: form_helper
INFO - 2018-05-12 01:35:45 --> Helper loaded: date_helper
INFO - 2018-05-12 01:35:45 --> Helper loaded: util_helper
INFO - 2018-05-12 01:35:45 --> Helper loaded: text_helper
INFO - 2018-05-12 01:35:45 --> Helper loaded: string_helper
INFO - 2018-05-12 01:35:45 --> Database Driver Class Initialized
DEBUG - 2018-05-12 01:35:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-12 01:35:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-12 01:35:45 --> Email Class Initialized
INFO - 2018-05-12 01:35:45 --> Controller Class Initialized
DEBUG - 2018-05-12 01:35:45 --> Chapters MX_Controller Initialized
INFO - 2018-05-12 01:35:45 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-12 01:35:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Chapters_model.php
DEBUG - 2018-05-12 01:35:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-12 01:35:45 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-12 01:35:45 --> Login MX_Controller Initialized
DEBUG - 2018-05-12 01:35:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-12 01:35:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-05-12 01:35:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-05-12 01:35:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-05-12 01:35:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-05-12 01:35:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-05-12 01:35:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/chapters/chapters.php
INFO - 2018-05-12 01:35:45 --> Final output sent to browser
DEBUG - 2018-05-12 01:35:45 --> Total execution time: 0.4155
INFO - 2018-05-12 01:35:46 --> Config Class Initialized
INFO - 2018-05-12 01:35:46 --> Hooks Class Initialized
DEBUG - 2018-05-12 01:35:46 --> UTF-8 Support Enabled
INFO - 2018-05-12 01:35:46 --> Utf8 Class Initialized
INFO - 2018-05-12 01:35:46 --> URI Class Initialized
INFO - 2018-05-12 01:35:46 --> Router Class Initialized
INFO - 2018-05-12 01:35:46 --> Output Class Initialized
INFO - 2018-05-12 01:35:46 --> Security Class Initialized
DEBUG - 2018-05-12 01:35:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 01:35:46 --> Input Class Initialized
INFO - 2018-05-12 01:35:46 --> Language Class Initialized
INFO - 2018-05-12 01:35:46 --> Language Class Initialized
INFO - 2018-05-12 01:35:46 --> Config Class Initialized
INFO - 2018-05-12 01:35:46 --> Loader Class Initialized
DEBUG - 2018-05-12 01:35:46 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-12 01:35:46 --> Helper loaded: url_helper
INFO - 2018-05-12 01:35:46 --> Helper loaded: form_helper
INFO - 2018-05-12 01:35:46 --> Helper loaded: date_helper
INFO - 2018-05-12 01:35:46 --> Helper loaded: util_helper
INFO - 2018-05-12 01:35:46 --> Helper loaded: text_helper
INFO - 2018-05-12 01:35:46 --> Helper loaded: string_helper
INFO - 2018-05-12 01:35:46 --> Database Driver Class Initialized
DEBUG - 2018-05-12 01:35:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-12 01:35:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-12 01:35:46 --> Email Class Initialized
INFO - 2018-05-12 01:35:46 --> Controller Class Initialized
DEBUG - 2018-05-12 01:35:46 --> Chapters MX_Controller Initialized
INFO - 2018-05-12 01:35:46 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-12 01:35:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Chapters_model.php
DEBUG - 2018-05-12 01:35:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-12 01:35:46 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-12 01:35:46 --> Login MX_Controller Initialized
DEBUG - 2018-05-12 01:35:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
ERROR - 2018-05-12 01:35:46 --> Query error: Unknown column 'programs.chapter_id' in 'on clause' - Invalid query: SELECT  chapters.chapter_id,chapters.chapter_name,programs.program_name,chapters.added_date,chapters.status,chapters.chapter_id FROM   chapters left join programs on chapters.chapter_id = programs.chapter_id  WHERE chapters.chapter_id!= ''     LIMIT 0, 10
INFO - 2018-05-12 01:35:46 --> Language file loaded: language/english/db_lang.php
INFO - 2018-05-12 01:35:53 --> Config Class Initialized
INFO - 2018-05-12 01:35:53 --> Hooks Class Initialized
DEBUG - 2018-05-12 01:35:53 --> UTF-8 Support Enabled
INFO - 2018-05-12 01:35:53 --> Utf8 Class Initialized
INFO - 2018-05-12 01:35:53 --> URI Class Initialized
INFO - 2018-05-12 01:35:53 --> Router Class Initialized
INFO - 2018-05-12 01:35:53 --> Output Class Initialized
INFO - 2018-05-12 01:35:53 --> Security Class Initialized
DEBUG - 2018-05-12 01:35:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 01:35:53 --> Input Class Initialized
INFO - 2018-05-12 01:35:53 --> Language Class Initialized
INFO - 2018-05-12 01:35:53 --> Language Class Initialized
INFO - 2018-05-12 01:35:53 --> Config Class Initialized
INFO - 2018-05-12 01:35:53 --> Loader Class Initialized
DEBUG - 2018-05-12 01:35:53 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-12 01:35:53 --> Helper loaded: url_helper
INFO - 2018-05-12 01:35:53 --> Helper loaded: form_helper
INFO - 2018-05-12 01:35:53 --> Helper loaded: date_helper
INFO - 2018-05-12 01:35:53 --> Helper loaded: util_helper
INFO - 2018-05-12 01:35:53 --> Helper loaded: text_helper
INFO - 2018-05-12 01:35:53 --> Helper loaded: string_helper
INFO - 2018-05-12 01:35:53 --> Database Driver Class Initialized
DEBUG - 2018-05-12 01:35:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-12 01:35:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-12 01:35:53 --> Email Class Initialized
INFO - 2018-05-12 01:35:53 --> Controller Class Initialized
DEBUG - 2018-05-12 01:35:53 --> Chapters MX_Controller Initialized
INFO - 2018-05-12 01:35:53 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-12 01:35:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Chapters_model.php
DEBUG - 2018-05-12 01:35:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-12 01:35:53 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-12 01:35:53 --> Login MX_Controller Initialized
DEBUG - 2018-05-12 01:35:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
ERROR - 2018-05-12 01:35:53 --> Query error: Unknown column 'programs.chapter_id' in 'on clause' - Invalid query: SELECT  chapters.chapter_id,chapters.chapter_name,programs.program_name,chapters.added_date,chapters.status,chapters.chapter_id FROM   chapters left join programs on chapters.chapter_id = programs.chapter_id  WHERE chapters.chapter_id!= ''    ORDER BY  chapters.chapter_name asc LIMIT 0, 10
INFO - 2018-05-12 01:35:53 --> Language file loaded: language/english/db_lang.php
INFO - 2018-05-12 01:35:58 --> Config Class Initialized
INFO - 2018-05-12 01:35:58 --> Hooks Class Initialized
DEBUG - 2018-05-12 01:35:58 --> UTF-8 Support Enabled
INFO - 2018-05-12 01:35:58 --> Utf8 Class Initialized
INFO - 2018-05-12 01:35:58 --> URI Class Initialized
INFO - 2018-05-12 01:35:58 --> Router Class Initialized
INFO - 2018-05-12 01:35:58 --> Output Class Initialized
INFO - 2018-05-12 01:35:58 --> Security Class Initialized
DEBUG - 2018-05-12 01:35:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 01:35:58 --> Input Class Initialized
INFO - 2018-05-12 01:35:58 --> Language Class Initialized
INFO - 2018-05-12 01:35:58 --> Language Class Initialized
INFO - 2018-05-12 01:35:58 --> Config Class Initialized
INFO - 2018-05-12 01:35:58 --> Loader Class Initialized
DEBUG - 2018-05-12 01:35:58 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-12 01:35:58 --> Helper loaded: url_helper
INFO - 2018-05-12 01:35:58 --> Helper loaded: form_helper
INFO - 2018-05-12 01:35:58 --> Helper loaded: date_helper
INFO - 2018-05-12 01:35:58 --> Helper loaded: util_helper
INFO - 2018-05-12 01:35:58 --> Helper loaded: text_helper
INFO - 2018-05-12 01:35:58 --> Helper loaded: string_helper
INFO - 2018-05-12 01:35:58 --> Database Driver Class Initialized
DEBUG - 2018-05-12 01:35:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-12 01:35:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-12 01:35:58 --> Email Class Initialized
INFO - 2018-05-12 01:35:58 --> Controller Class Initialized
DEBUG - 2018-05-12 01:35:59 --> Chapters MX_Controller Initialized
INFO - 2018-05-12 01:35:59 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-12 01:35:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Chapters_model.php
DEBUG - 2018-05-12 01:35:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-12 01:35:59 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-12 01:35:59 --> Login MX_Controller Initialized
DEBUG - 2018-05-12 01:35:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
ERROR - 2018-05-12 01:35:59 --> Query error: Unknown column 'programs.chapter_id' in 'on clause' - Invalid query: SELECT  chapters.chapter_id,chapters.chapter_name,programs.program_name,chapters.added_date,chapters.status,chapters.chapter_id FROM   chapters left join programs on chapters.chapter_id = programs.chapter_id  WHERE chapters.chapter_id!= ''     
INFO - 2018-05-12 01:35:59 --> Language file loaded: language/english/db_lang.php
INFO - 2018-05-12 01:36:44 --> Config Class Initialized
INFO - 2018-05-12 01:36:44 --> Hooks Class Initialized
DEBUG - 2018-05-12 01:36:44 --> UTF-8 Support Enabled
INFO - 2018-05-12 01:36:44 --> Utf8 Class Initialized
INFO - 2018-05-12 01:36:44 --> URI Class Initialized
INFO - 2018-05-12 01:36:44 --> Router Class Initialized
INFO - 2018-05-12 01:36:44 --> Output Class Initialized
INFO - 2018-05-12 01:36:44 --> Security Class Initialized
DEBUG - 2018-05-12 01:36:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 01:36:44 --> Input Class Initialized
INFO - 2018-05-12 01:36:44 --> Language Class Initialized
INFO - 2018-05-12 01:36:44 --> Language Class Initialized
INFO - 2018-05-12 01:36:44 --> Config Class Initialized
INFO - 2018-05-12 01:36:44 --> Loader Class Initialized
DEBUG - 2018-05-12 01:36:44 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-12 01:36:44 --> Helper loaded: url_helper
INFO - 2018-05-12 01:36:44 --> Helper loaded: form_helper
INFO - 2018-05-12 01:36:44 --> Helper loaded: date_helper
INFO - 2018-05-12 01:36:44 --> Helper loaded: util_helper
INFO - 2018-05-12 01:36:44 --> Helper loaded: text_helper
INFO - 2018-05-12 01:36:44 --> Helper loaded: string_helper
INFO - 2018-05-12 01:36:44 --> Database Driver Class Initialized
DEBUG - 2018-05-12 01:36:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-12 01:36:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-12 01:36:44 --> Email Class Initialized
INFO - 2018-05-12 01:36:44 --> Controller Class Initialized
DEBUG - 2018-05-12 01:36:44 --> Chapters MX_Controller Initialized
INFO - 2018-05-12 01:36:44 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-12 01:36:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Chapters_model.php
DEBUG - 2018-05-12 01:36:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-12 01:36:44 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-12 01:36:44 --> Login MX_Controller Initialized
DEBUG - 2018-05-12 01:36:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
ERROR - 2018-05-12 01:36:44 --> Severity: Notice --> Undefined index: sEcho E:\xampp\htdocs\consulting\system\database\DB_query_builder.php 2920
INFO - 2018-05-12 01:36:44 --> Final output sent to browser
DEBUG - 2018-05-12 01:36:44 --> Total execution time: 0.3963
INFO - 2018-05-12 01:36:55 --> Config Class Initialized
INFO - 2018-05-12 01:36:55 --> Hooks Class Initialized
DEBUG - 2018-05-12 01:36:55 --> UTF-8 Support Enabled
INFO - 2018-05-12 01:36:55 --> Utf8 Class Initialized
INFO - 2018-05-12 01:36:55 --> URI Class Initialized
INFO - 2018-05-12 01:36:55 --> Router Class Initialized
INFO - 2018-05-12 01:36:55 --> Output Class Initialized
INFO - 2018-05-12 01:36:55 --> Security Class Initialized
DEBUG - 2018-05-12 01:36:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 01:36:55 --> Input Class Initialized
INFO - 2018-05-12 01:36:55 --> Language Class Initialized
INFO - 2018-05-12 01:36:55 --> Language Class Initialized
INFO - 2018-05-12 01:36:55 --> Config Class Initialized
INFO - 2018-05-12 01:36:55 --> Loader Class Initialized
DEBUG - 2018-05-12 01:36:55 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-12 01:36:55 --> Helper loaded: url_helper
INFO - 2018-05-12 01:36:55 --> Helper loaded: form_helper
INFO - 2018-05-12 01:36:55 --> Helper loaded: date_helper
INFO - 2018-05-12 01:36:55 --> Helper loaded: util_helper
INFO - 2018-05-12 01:36:55 --> Helper loaded: text_helper
INFO - 2018-05-12 01:36:55 --> Helper loaded: string_helper
INFO - 2018-05-12 01:36:55 --> Database Driver Class Initialized
DEBUG - 2018-05-12 01:36:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-12 01:36:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-12 01:36:55 --> Email Class Initialized
INFO - 2018-05-12 01:36:55 --> Controller Class Initialized
DEBUG - 2018-05-12 01:36:55 --> Chapters MX_Controller Initialized
INFO - 2018-05-12 01:36:55 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-12 01:36:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Chapters_model.php
DEBUG - 2018-05-12 01:36:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-12 01:36:55 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-12 01:36:55 --> Login MX_Controller Initialized
DEBUG - 2018-05-12 01:36:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
ERROR - 2018-05-12 01:36:55 --> Severity: Notice --> Undefined index: sEcho E:\xampp\htdocs\consulting\system\database\DB_query_builder.php 2920
INFO - 2018-05-12 01:36:55 --> Final output sent to browser
DEBUG - 2018-05-12 01:36:55 --> Total execution time: 0.3707
INFO - 2018-05-12 01:37:15 --> Config Class Initialized
INFO - 2018-05-12 01:37:15 --> Hooks Class Initialized
DEBUG - 2018-05-12 01:37:15 --> UTF-8 Support Enabled
INFO - 2018-05-12 01:37:15 --> Utf8 Class Initialized
INFO - 2018-05-12 01:37:15 --> URI Class Initialized
INFO - 2018-05-12 01:37:15 --> Router Class Initialized
INFO - 2018-05-12 01:37:15 --> Output Class Initialized
INFO - 2018-05-12 01:37:15 --> Security Class Initialized
DEBUG - 2018-05-12 01:37:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 01:37:15 --> Input Class Initialized
INFO - 2018-05-12 01:37:15 --> Language Class Initialized
INFO - 2018-05-12 01:37:15 --> Language Class Initialized
INFO - 2018-05-12 01:37:15 --> Config Class Initialized
INFO - 2018-05-12 01:37:15 --> Loader Class Initialized
DEBUG - 2018-05-12 01:37:15 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-12 01:37:15 --> Helper loaded: url_helper
INFO - 2018-05-12 01:37:15 --> Helper loaded: form_helper
INFO - 2018-05-12 01:37:15 --> Helper loaded: date_helper
INFO - 2018-05-12 01:37:15 --> Helper loaded: util_helper
INFO - 2018-05-12 01:37:15 --> Helper loaded: text_helper
INFO - 2018-05-12 01:37:15 --> Helper loaded: string_helper
INFO - 2018-05-12 01:37:15 --> Database Driver Class Initialized
DEBUG - 2018-05-12 01:37:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-12 01:37:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-12 01:37:15 --> Email Class Initialized
INFO - 2018-05-12 01:37:15 --> Controller Class Initialized
DEBUG - 2018-05-12 01:37:15 --> Chapters MX_Controller Initialized
INFO - 2018-05-12 01:37:15 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-12 01:37:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Chapters_model.php
DEBUG - 2018-05-12 01:37:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-12 01:37:15 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-12 01:37:15 --> Login MX_Controller Initialized
DEBUG - 2018-05-12 01:37:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-12 01:37:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-05-12 01:37:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-05-12 01:37:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-05-12 01:37:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-05-12 01:37:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-05-12 01:37:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/chapters/chapters.php
INFO - 2018-05-12 01:37:15 --> Final output sent to browser
DEBUG - 2018-05-12 01:37:15 --> Total execution time: 0.5011
INFO - 2018-05-12 01:37:17 --> Config Class Initialized
INFO - 2018-05-12 01:37:17 --> Hooks Class Initialized
DEBUG - 2018-05-12 01:37:17 --> UTF-8 Support Enabled
INFO - 2018-05-12 01:37:17 --> Utf8 Class Initialized
INFO - 2018-05-12 01:37:17 --> URI Class Initialized
INFO - 2018-05-12 01:37:17 --> Router Class Initialized
INFO - 2018-05-12 01:37:17 --> Output Class Initialized
INFO - 2018-05-12 01:37:17 --> Security Class Initialized
DEBUG - 2018-05-12 01:37:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 01:37:17 --> Input Class Initialized
INFO - 2018-05-12 01:37:17 --> Language Class Initialized
INFO - 2018-05-12 01:37:17 --> Language Class Initialized
INFO - 2018-05-12 01:37:17 --> Config Class Initialized
INFO - 2018-05-12 01:37:17 --> Loader Class Initialized
DEBUG - 2018-05-12 01:37:17 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-12 01:37:17 --> Helper loaded: url_helper
INFO - 2018-05-12 01:37:17 --> Helper loaded: form_helper
INFO - 2018-05-12 01:37:17 --> Helper loaded: date_helper
INFO - 2018-05-12 01:37:17 --> Helper loaded: util_helper
INFO - 2018-05-12 01:37:17 --> Helper loaded: text_helper
INFO - 2018-05-12 01:37:17 --> Helper loaded: string_helper
INFO - 2018-05-12 01:37:17 --> Database Driver Class Initialized
DEBUG - 2018-05-12 01:37:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-12 01:37:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-12 01:37:17 --> Email Class Initialized
INFO - 2018-05-12 01:37:17 --> Controller Class Initialized
DEBUG - 2018-05-12 01:37:17 --> Chapters MX_Controller Initialized
INFO - 2018-05-12 01:37:17 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-12 01:37:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Chapters_model.php
DEBUG - 2018-05-12 01:37:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-12 01:37:17 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-12 01:37:17 --> Login MX_Controller Initialized
DEBUG - 2018-05-12 01:37:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-12 01:37:17 --> Final output sent to browser
DEBUG - 2018-05-12 01:37:17 --> Total execution time: 0.5729
INFO - 2018-05-12 01:37:31 --> Config Class Initialized
INFO - 2018-05-12 01:37:31 --> Hooks Class Initialized
DEBUG - 2018-05-12 01:37:32 --> UTF-8 Support Enabled
INFO - 2018-05-12 01:37:32 --> Utf8 Class Initialized
INFO - 2018-05-12 01:37:32 --> URI Class Initialized
INFO - 2018-05-12 01:37:32 --> Router Class Initialized
INFO - 2018-05-12 01:37:32 --> Output Class Initialized
INFO - 2018-05-12 01:37:32 --> Security Class Initialized
DEBUG - 2018-05-12 01:37:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 01:37:32 --> Input Class Initialized
INFO - 2018-05-12 01:37:32 --> Language Class Initialized
INFO - 2018-05-12 01:37:32 --> Language Class Initialized
INFO - 2018-05-12 01:37:32 --> Config Class Initialized
INFO - 2018-05-12 01:37:32 --> Loader Class Initialized
DEBUG - 2018-05-12 01:37:32 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-12 01:37:32 --> Helper loaded: url_helper
INFO - 2018-05-12 01:37:32 --> Helper loaded: form_helper
INFO - 2018-05-12 01:37:32 --> Helper loaded: date_helper
INFO - 2018-05-12 01:37:32 --> Helper loaded: util_helper
INFO - 2018-05-12 01:37:32 --> Helper loaded: text_helper
INFO - 2018-05-12 01:37:32 --> Helper loaded: string_helper
INFO - 2018-05-12 01:37:32 --> Database Driver Class Initialized
DEBUG - 2018-05-12 01:37:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-12 01:37:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-12 01:37:32 --> Email Class Initialized
INFO - 2018-05-12 01:37:32 --> Controller Class Initialized
DEBUG - 2018-05-12 01:37:32 --> Chapters MX_Controller Initialized
INFO - 2018-05-12 01:37:32 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-12 01:37:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Chapters_model.php
DEBUG - 2018-05-12 01:37:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-12 01:37:32 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-12 01:37:32 --> Login MX_Controller Initialized
DEBUG - 2018-05-12 01:37:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-12 01:37:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-05-12 01:37:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-05-12 01:37:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-05-12 01:37:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-05-12 01:37:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-05-12 01:37:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/chapters/chapters.php
INFO - 2018-05-12 01:37:32 --> Final output sent to browser
DEBUG - 2018-05-12 01:37:32 --> Total execution time: 0.5521
INFO - 2018-05-12 01:37:33 --> Config Class Initialized
INFO - 2018-05-12 01:37:33 --> Hooks Class Initialized
DEBUG - 2018-05-12 01:37:33 --> UTF-8 Support Enabled
INFO - 2018-05-12 01:37:33 --> Utf8 Class Initialized
INFO - 2018-05-12 01:37:33 --> URI Class Initialized
INFO - 2018-05-12 01:37:33 --> Router Class Initialized
INFO - 2018-05-12 01:37:33 --> Output Class Initialized
INFO - 2018-05-12 01:37:33 --> Security Class Initialized
DEBUG - 2018-05-12 01:37:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 01:37:33 --> Input Class Initialized
INFO - 2018-05-12 01:37:33 --> Language Class Initialized
INFO - 2018-05-12 01:37:33 --> Language Class Initialized
INFO - 2018-05-12 01:37:33 --> Config Class Initialized
INFO - 2018-05-12 01:37:33 --> Loader Class Initialized
DEBUG - 2018-05-12 01:37:33 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-12 01:37:33 --> Helper loaded: url_helper
INFO - 2018-05-12 01:37:33 --> Helper loaded: form_helper
INFO - 2018-05-12 01:37:33 --> Helper loaded: date_helper
INFO - 2018-05-12 01:37:33 --> Helper loaded: util_helper
INFO - 2018-05-12 01:37:33 --> Helper loaded: text_helper
INFO - 2018-05-12 01:37:33 --> Helper loaded: string_helper
INFO - 2018-05-12 01:37:33 --> Database Driver Class Initialized
DEBUG - 2018-05-12 01:37:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-12 01:37:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-12 01:37:33 --> Email Class Initialized
INFO - 2018-05-12 01:37:33 --> Controller Class Initialized
DEBUG - 2018-05-12 01:37:33 --> Chapters MX_Controller Initialized
INFO - 2018-05-12 01:37:33 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-12 01:37:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Chapters_model.php
DEBUG - 2018-05-12 01:37:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-12 01:37:33 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-12 01:37:33 --> Login MX_Controller Initialized
DEBUG - 2018-05-12 01:37:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-12 01:37:33 --> Final output sent to browser
DEBUG - 2018-05-12 01:37:33 --> Total execution time: 0.6548
INFO - 2018-05-12 01:37:35 --> Config Class Initialized
INFO - 2018-05-12 01:37:35 --> Hooks Class Initialized
DEBUG - 2018-05-12 01:37:35 --> UTF-8 Support Enabled
INFO - 2018-05-12 01:37:35 --> Utf8 Class Initialized
INFO - 2018-05-12 01:37:35 --> URI Class Initialized
INFO - 2018-05-12 01:37:35 --> Router Class Initialized
INFO - 2018-05-12 01:37:35 --> Output Class Initialized
INFO - 2018-05-12 01:37:35 --> Security Class Initialized
DEBUG - 2018-05-12 01:37:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 01:37:35 --> Input Class Initialized
INFO - 2018-05-12 01:37:35 --> Language Class Initialized
INFO - 2018-05-12 01:37:35 --> Language Class Initialized
INFO - 2018-05-12 01:37:35 --> Config Class Initialized
INFO - 2018-05-12 01:37:35 --> Loader Class Initialized
DEBUG - 2018-05-12 01:37:35 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-12 01:37:35 --> Helper loaded: url_helper
INFO - 2018-05-12 01:37:35 --> Helper loaded: form_helper
INFO - 2018-05-12 01:37:35 --> Helper loaded: date_helper
INFO - 2018-05-12 01:37:35 --> Helper loaded: util_helper
INFO - 2018-05-12 01:37:35 --> Helper loaded: text_helper
INFO - 2018-05-12 01:37:35 --> Helper loaded: string_helper
INFO - 2018-05-12 01:37:35 --> Database Driver Class Initialized
DEBUG - 2018-05-12 01:37:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-12 01:37:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-12 01:37:35 --> Email Class Initialized
INFO - 2018-05-12 01:37:35 --> Controller Class Initialized
DEBUG - 2018-05-12 01:37:35 --> Chapters MX_Controller Initialized
INFO - 2018-05-12 01:37:35 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-12 01:37:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Chapters_model.php
DEBUG - 2018-05-12 01:37:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-12 01:37:35 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-12 01:37:35 --> Login MX_Controller Initialized
DEBUG - 2018-05-12 01:37:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-12 01:37:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-05-12 01:37:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-05-12 01:37:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-05-12 01:37:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-05-12 01:37:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-05-12 01:37:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/chapters/create_chapter.php
INFO - 2018-05-12 01:37:35 --> Final output sent to browser
DEBUG - 2018-05-12 01:37:36 --> Total execution time: 0.4786
INFO - 2018-05-12 01:37:36 --> Config Class Initialized
INFO - 2018-05-12 01:37:36 --> Hooks Class Initialized
DEBUG - 2018-05-12 01:37:36 --> UTF-8 Support Enabled
INFO - 2018-05-12 01:37:36 --> Utf8 Class Initialized
INFO - 2018-05-12 01:37:37 --> URI Class Initialized
INFO - 2018-05-12 01:37:37 --> Router Class Initialized
INFO - 2018-05-12 01:37:37 --> Output Class Initialized
INFO - 2018-05-12 01:37:37 --> Security Class Initialized
DEBUG - 2018-05-12 01:37:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 01:37:37 --> Input Class Initialized
INFO - 2018-05-12 01:37:37 --> Language Class Initialized
ERROR - 2018-05-12 01:37:37 --> 404 Page Not Found: /index
INFO - 2018-05-12 01:39:14 --> Config Class Initialized
INFO - 2018-05-12 01:39:14 --> Hooks Class Initialized
DEBUG - 2018-05-12 01:39:14 --> UTF-8 Support Enabled
INFO - 2018-05-12 01:39:14 --> Utf8 Class Initialized
INFO - 2018-05-12 01:39:14 --> URI Class Initialized
INFO - 2018-05-12 01:39:14 --> Router Class Initialized
INFO - 2018-05-12 01:39:14 --> Output Class Initialized
INFO - 2018-05-12 01:39:14 --> Security Class Initialized
DEBUG - 2018-05-12 01:39:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 01:39:14 --> Input Class Initialized
INFO - 2018-05-12 01:39:14 --> Language Class Initialized
INFO - 2018-05-12 01:39:14 --> Language Class Initialized
INFO - 2018-05-12 01:39:14 --> Config Class Initialized
INFO - 2018-05-12 01:39:14 --> Loader Class Initialized
DEBUG - 2018-05-12 01:39:14 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-12 01:39:14 --> Helper loaded: url_helper
INFO - 2018-05-12 01:39:14 --> Helper loaded: form_helper
INFO - 2018-05-12 01:39:14 --> Helper loaded: date_helper
INFO - 2018-05-12 01:39:14 --> Helper loaded: util_helper
INFO - 2018-05-12 01:39:14 --> Helper loaded: text_helper
INFO - 2018-05-12 01:39:14 --> Helper loaded: string_helper
INFO - 2018-05-12 01:39:14 --> Database Driver Class Initialized
DEBUG - 2018-05-12 01:39:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-12 01:39:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-12 01:39:14 --> Email Class Initialized
INFO - 2018-05-12 01:39:14 --> Controller Class Initialized
DEBUG - 2018-05-12 01:39:14 --> Chapters MX_Controller Initialized
INFO - 2018-05-12 01:39:14 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-12 01:39:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Chapters_model.php
DEBUG - 2018-05-12 01:39:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-12 01:39:14 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-12 01:39:14 --> Login MX_Controller Initialized
DEBUG - 2018-05-12 01:39:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-12 01:39:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-05-12 01:39:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-05-12 01:39:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-05-12 01:39:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-05-12 01:39:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-05-12 01:39:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/chapters/create_chapter.php
INFO - 2018-05-12 01:39:14 --> Final output sent to browser
DEBUG - 2018-05-12 01:39:14 --> Total execution time: 0.4529
INFO - 2018-05-12 01:39:15 --> Config Class Initialized
INFO - 2018-05-12 01:39:15 --> Hooks Class Initialized
DEBUG - 2018-05-12 01:39:15 --> UTF-8 Support Enabled
INFO - 2018-05-12 01:39:15 --> Utf8 Class Initialized
INFO - 2018-05-12 01:39:15 --> URI Class Initialized
INFO - 2018-05-12 01:39:15 --> Router Class Initialized
INFO - 2018-05-12 01:39:15 --> Output Class Initialized
INFO - 2018-05-12 01:39:15 --> Security Class Initialized
DEBUG - 2018-05-12 01:39:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 01:39:15 --> Input Class Initialized
INFO - 2018-05-12 01:39:15 --> Language Class Initialized
ERROR - 2018-05-12 01:39:15 --> 404 Page Not Found: /index
INFO - 2018-05-12 01:39:42 --> Config Class Initialized
INFO - 2018-05-12 01:39:42 --> Hooks Class Initialized
DEBUG - 2018-05-12 01:39:42 --> UTF-8 Support Enabled
INFO - 2018-05-12 01:39:42 --> Utf8 Class Initialized
INFO - 2018-05-12 01:39:42 --> URI Class Initialized
INFO - 2018-05-12 01:39:42 --> Router Class Initialized
INFO - 2018-05-12 01:39:42 --> Output Class Initialized
INFO - 2018-05-12 01:39:42 --> Security Class Initialized
DEBUG - 2018-05-12 01:39:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 01:39:42 --> Input Class Initialized
INFO - 2018-05-12 01:39:42 --> Language Class Initialized
INFO - 2018-05-12 01:39:42 --> Language Class Initialized
INFO - 2018-05-12 01:39:42 --> Config Class Initialized
INFO - 2018-05-12 01:39:42 --> Loader Class Initialized
DEBUG - 2018-05-12 01:39:42 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-12 01:39:42 --> Helper loaded: url_helper
INFO - 2018-05-12 01:39:42 --> Helper loaded: form_helper
INFO - 2018-05-12 01:39:42 --> Helper loaded: date_helper
INFO - 2018-05-12 01:39:42 --> Helper loaded: util_helper
INFO - 2018-05-12 01:39:42 --> Helper loaded: text_helper
INFO - 2018-05-12 01:39:42 --> Helper loaded: string_helper
INFO - 2018-05-12 01:39:42 --> Database Driver Class Initialized
DEBUG - 2018-05-12 01:39:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-12 01:39:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-12 01:39:42 --> Email Class Initialized
INFO - 2018-05-12 01:39:43 --> Controller Class Initialized
DEBUG - 2018-05-12 01:39:43 --> Chapters MX_Controller Initialized
INFO - 2018-05-12 01:39:43 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-12 01:39:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Chapters_model.php
DEBUG - 2018-05-12 01:39:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-12 01:39:43 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-12 01:39:43 --> Login MX_Controller Initialized
DEBUG - 2018-05-12 01:39:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-12 01:41:17 --> Config Class Initialized
INFO - 2018-05-12 01:41:17 --> Hooks Class Initialized
DEBUG - 2018-05-12 01:41:17 --> UTF-8 Support Enabled
INFO - 2018-05-12 01:41:17 --> Utf8 Class Initialized
INFO - 2018-05-12 01:41:17 --> URI Class Initialized
INFO - 2018-05-12 01:41:17 --> Router Class Initialized
INFO - 2018-05-12 01:41:17 --> Output Class Initialized
INFO - 2018-05-12 01:41:17 --> Security Class Initialized
DEBUG - 2018-05-12 01:41:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 01:41:17 --> Input Class Initialized
INFO - 2018-05-12 01:41:17 --> Language Class Initialized
INFO - 2018-05-12 01:41:17 --> Language Class Initialized
INFO - 2018-05-12 01:41:17 --> Config Class Initialized
INFO - 2018-05-12 01:41:17 --> Loader Class Initialized
DEBUG - 2018-05-12 01:41:17 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-12 01:41:17 --> Helper loaded: url_helper
INFO - 2018-05-12 01:41:17 --> Helper loaded: form_helper
INFO - 2018-05-12 01:41:17 --> Helper loaded: date_helper
INFO - 2018-05-12 01:41:17 --> Helper loaded: util_helper
INFO - 2018-05-12 01:41:17 --> Helper loaded: text_helper
INFO - 2018-05-12 01:41:17 --> Helper loaded: string_helper
INFO - 2018-05-12 01:41:17 --> Database Driver Class Initialized
DEBUG - 2018-05-12 01:41:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-12 01:41:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-12 01:41:18 --> Email Class Initialized
INFO - 2018-05-12 01:41:18 --> Controller Class Initialized
DEBUG - 2018-05-12 01:41:18 --> Chapters MX_Controller Initialized
INFO - 2018-05-12 01:41:18 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-12 01:41:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Chapters_model.php
DEBUG - 2018-05-12 01:41:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-12 01:41:18 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-12 01:41:18 --> Login MX_Controller Initialized
DEBUG - 2018-05-12 01:41:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
ERROR - 2018-05-12 01:41:18 --> Severity: Notice --> Undefined variable: rw_programs_ls E:\xampp\htdocs\consulting\application\modules\admin\controllers\Chapters.php 78
INFO - 2018-05-12 01:41:37 --> Config Class Initialized
INFO - 2018-05-12 01:41:37 --> Hooks Class Initialized
DEBUG - 2018-05-12 01:41:37 --> UTF-8 Support Enabled
INFO - 2018-05-12 01:41:37 --> Utf8 Class Initialized
INFO - 2018-05-12 01:41:37 --> URI Class Initialized
INFO - 2018-05-12 01:41:37 --> Router Class Initialized
INFO - 2018-05-12 01:41:37 --> Output Class Initialized
INFO - 2018-05-12 01:41:37 --> Security Class Initialized
DEBUG - 2018-05-12 01:41:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 01:41:37 --> Input Class Initialized
INFO - 2018-05-12 01:41:37 --> Language Class Initialized
INFO - 2018-05-12 01:41:37 --> Language Class Initialized
INFO - 2018-05-12 01:41:37 --> Config Class Initialized
INFO - 2018-05-12 01:41:37 --> Loader Class Initialized
DEBUG - 2018-05-12 01:41:37 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-12 01:41:37 --> Helper loaded: url_helper
INFO - 2018-05-12 01:41:37 --> Helper loaded: form_helper
INFO - 2018-05-12 01:41:37 --> Helper loaded: date_helper
INFO - 2018-05-12 01:41:37 --> Helper loaded: util_helper
INFO - 2018-05-12 01:41:37 --> Helper loaded: text_helper
INFO - 2018-05-12 01:41:37 --> Helper loaded: string_helper
INFO - 2018-05-12 01:41:37 --> Database Driver Class Initialized
DEBUG - 2018-05-12 01:41:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-12 01:41:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-12 01:41:37 --> Email Class Initialized
INFO - 2018-05-12 01:41:37 --> Controller Class Initialized
DEBUG - 2018-05-12 01:41:37 --> Chapters MX_Controller Initialized
INFO - 2018-05-12 01:41:37 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-12 01:41:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Chapters_model.php
DEBUG - 2018-05-12 01:41:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-12 01:41:37 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-12 01:41:37 --> Login MX_Controller Initialized
DEBUG - 2018-05-12 01:41:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
ERROR - 2018-05-12 01:41:37 --> Severity: Notice --> Undefined index: Consulting Accelerator E:\xampp\htdocs\consulting\application\modules\admin\controllers\Chapters.php 79
INFO - 2018-05-12 01:42:01 --> Config Class Initialized
INFO - 2018-05-12 01:42:01 --> Hooks Class Initialized
DEBUG - 2018-05-12 01:42:01 --> UTF-8 Support Enabled
INFO - 2018-05-12 01:42:01 --> Utf8 Class Initialized
INFO - 2018-05-12 01:42:01 --> URI Class Initialized
INFO - 2018-05-12 01:42:01 --> Router Class Initialized
INFO - 2018-05-12 01:42:01 --> Output Class Initialized
INFO - 2018-05-12 01:42:01 --> Security Class Initialized
DEBUG - 2018-05-12 01:42:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 01:42:01 --> Input Class Initialized
INFO - 2018-05-12 01:42:01 --> Language Class Initialized
INFO - 2018-05-12 01:42:01 --> Language Class Initialized
INFO - 2018-05-12 01:42:01 --> Config Class Initialized
INFO - 2018-05-12 01:42:01 --> Loader Class Initialized
DEBUG - 2018-05-12 01:42:01 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-12 01:42:01 --> Helper loaded: url_helper
INFO - 2018-05-12 01:42:01 --> Helper loaded: form_helper
INFO - 2018-05-12 01:42:01 --> Helper loaded: date_helper
INFO - 2018-05-12 01:42:01 --> Helper loaded: util_helper
INFO - 2018-05-12 01:42:01 --> Helper loaded: text_helper
INFO - 2018-05-12 01:42:01 --> Helper loaded: string_helper
INFO - 2018-05-12 01:42:01 --> Database Driver Class Initialized
DEBUG - 2018-05-12 01:42:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-12 01:42:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-12 01:42:01 --> Email Class Initialized
INFO - 2018-05-12 01:42:01 --> Controller Class Initialized
DEBUG - 2018-05-12 01:42:01 --> Chapters MX_Controller Initialized
INFO - 2018-05-12 01:42:01 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-12 01:42:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Chapters_model.php
DEBUG - 2018-05-12 01:42:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-12 01:42:01 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-12 01:42:01 --> Login MX_Controller Initialized
DEBUG - 2018-05-12 01:42:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-12 01:42:13 --> Config Class Initialized
INFO - 2018-05-12 01:42:13 --> Hooks Class Initialized
DEBUG - 2018-05-12 01:42:13 --> UTF-8 Support Enabled
INFO - 2018-05-12 01:42:13 --> Utf8 Class Initialized
INFO - 2018-05-12 01:42:13 --> URI Class Initialized
INFO - 2018-05-12 01:42:13 --> Router Class Initialized
INFO - 2018-05-12 01:42:13 --> Output Class Initialized
INFO - 2018-05-12 01:42:13 --> Security Class Initialized
DEBUG - 2018-05-12 01:42:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 01:42:13 --> Input Class Initialized
INFO - 2018-05-12 01:42:13 --> Language Class Initialized
INFO - 2018-05-12 01:42:13 --> Language Class Initialized
INFO - 2018-05-12 01:42:13 --> Config Class Initialized
INFO - 2018-05-12 01:42:13 --> Loader Class Initialized
DEBUG - 2018-05-12 01:42:13 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-12 01:42:13 --> Helper loaded: url_helper
INFO - 2018-05-12 01:42:13 --> Helper loaded: form_helper
INFO - 2018-05-12 01:42:13 --> Helper loaded: date_helper
INFO - 2018-05-12 01:42:13 --> Helper loaded: util_helper
INFO - 2018-05-12 01:42:13 --> Helper loaded: text_helper
INFO - 2018-05-12 01:42:13 --> Helper loaded: string_helper
INFO - 2018-05-12 01:42:13 --> Database Driver Class Initialized
DEBUG - 2018-05-12 01:42:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-12 01:42:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-12 01:42:13 --> Email Class Initialized
INFO - 2018-05-12 01:42:13 --> Controller Class Initialized
DEBUG - 2018-05-12 01:42:13 --> Chapters MX_Controller Initialized
INFO - 2018-05-12 01:42:13 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-12 01:42:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Chapters_model.php
DEBUG - 2018-05-12 01:42:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-12 01:42:13 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-12 01:42:13 --> Login MX_Controller Initialized
DEBUG - 2018-05-12 01:42:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-12 01:42:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-05-12 01:42:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-05-12 01:42:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-05-12 01:42:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-05-12 01:42:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-05-12 01:42:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/chapters/create_chapter.php
INFO - 2018-05-12 01:42:13 --> Final output sent to browser
DEBUG - 2018-05-12 01:42:13 --> Total execution time: 0.4771
INFO - 2018-05-12 01:42:14 --> Config Class Initialized
INFO - 2018-05-12 01:42:14 --> Hooks Class Initialized
DEBUG - 2018-05-12 01:42:14 --> UTF-8 Support Enabled
INFO - 2018-05-12 01:42:14 --> Utf8 Class Initialized
INFO - 2018-05-12 01:42:14 --> URI Class Initialized
INFO - 2018-05-12 01:42:14 --> Router Class Initialized
INFO - 2018-05-12 01:42:15 --> Output Class Initialized
INFO - 2018-05-12 01:42:15 --> Security Class Initialized
DEBUG - 2018-05-12 01:42:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 01:42:15 --> Input Class Initialized
INFO - 2018-05-12 01:42:15 --> Language Class Initialized
ERROR - 2018-05-12 01:42:15 --> 404 Page Not Found: /index
INFO - 2018-05-12 01:45:08 --> Config Class Initialized
INFO - 2018-05-12 01:45:09 --> Hooks Class Initialized
DEBUG - 2018-05-12 01:45:09 --> UTF-8 Support Enabled
INFO - 2018-05-12 01:45:09 --> Utf8 Class Initialized
INFO - 2018-05-12 01:45:09 --> URI Class Initialized
INFO - 2018-05-12 01:45:09 --> Router Class Initialized
INFO - 2018-05-12 01:45:09 --> Output Class Initialized
INFO - 2018-05-12 01:45:09 --> Security Class Initialized
DEBUG - 2018-05-12 01:45:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 01:45:09 --> Input Class Initialized
INFO - 2018-05-12 01:45:09 --> Language Class Initialized
INFO - 2018-05-12 01:45:09 --> Language Class Initialized
INFO - 2018-05-12 01:45:09 --> Config Class Initialized
INFO - 2018-05-12 01:45:09 --> Loader Class Initialized
DEBUG - 2018-05-12 01:45:09 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-12 01:45:09 --> Helper loaded: url_helper
INFO - 2018-05-12 01:45:09 --> Helper loaded: form_helper
INFO - 2018-05-12 01:45:09 --> Helper loaded: date_helper
INFO - 2018-05-12 01:45:09 --> Helper loaded: util_helper
INFO - 2018-05-12 01:45:09 --> Helper loaded: text_helper
INFO - 2018-05-12 01:45:09 --> Helper loaded: string_helper
INFO - 2018-05-12 01:45:09 --> Database Driver Class Initialized
DEBUG - 2018-05-12 01:45:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-12 01:45:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-12 01:45:09 --> Email Class Initialized
INFO - 2018-05-12 01:45:09 --> Controller Class Initialized
DEBUG - 2018-05-12 01:45:09 --> Chapters MX_Controller Initialized
INFO - 2018-05-12 01:45:09 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-12 01:45:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Chapters_model.php
DEBUG - 2018-05-12 01:45:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-12 01:45:09 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-12 01:45:09 --> Login MX_Controller Initialized
DEBUG - 2018-05-12 01:45:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-12 01:45:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-05-12 01:45:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-05-12 01:45:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-05-12 01:45:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-05-12 01:45:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-05-12 01:45:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/chapters/create_chapter.php
INFO - 2018-05-12 01:45:09 --> Final output sent to browser
DEBUG - 2018-05-12 01:45:09 --> Total execution time: 0.4726
INFO - 2018-05-12 01:45:10 --> Config Class Initialized
INFO - 2018-05-12 01:45:10 --> Hooks Class Initialized
DEBUG - 2018-05-12 01:45:10 --> UTF-8 Support Enabled
INFO - 2018-05-12 01:45:10 --> Utf8 Class Initialized
INFO - 2018-05-12 01:45:10 --> URI Class Initialized
INFO - 2018-05-12 01:45:10 --> Router Class Initialized
INFO - 2018-05-12 01:45:10 --> Output Class Initialized
INFO - 2018-05-12 01:45:10 --> Security Class Initialized
DEBUG - 2018-05-12 01:45:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 01:45:10 --> Input Class Initialized
INFO - 2018-05-12 01:45:10 --> Language Class Initialized
ERROR - 2018-05-12 01:45:10 --> 404 Page Not Found: /index
INFO - 2018-05-12 01:45:56 --> Config Class Initialized
INFO - 2018-05-12 01:45:56 --> Hooks Class Initialized
DEBUG - 2018-05-12 01:45:56 --> UTF-8 Support Enabled
INFO - 2018-05-12 01:45:56 --> Utf8 Class Initialized
INFO - 2018-05-12 01:45:56 --> URI Class Initialized
INFO - 2018-05-12 01:45:56 --> Router Class Initialized
INFO - 2018-05-12 01:45:56 --> Output Class Initialized
INFO - 2018-05-12 01:45:56 --> Security Class Initialized
DEBUG - 2018-05-12 01:45:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 01:45:56 --> Input Class Initialized
INFO - 2018-05-12 01:45:56 --> Language Class Initialized
INFO - 2018-05-12 01:45:56 --> Language Class Initialized
INFO - 2018-05-12 01:45:56 --> Config Class Initialized
INFO - 2018-05-12 01:45:56 --> Loader Class Initialized
DEBUG - 2018-05-12 01:45:56 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-12 01:45:56 --> Helper loaded: url_helper
INFO - 2018-05-12 01:45:56 --> Helper loaded: form_helper
INFO - 2018-05-12 01:45:56 --> Helper loaded: date_helper
INFO - 2018-05-12 01:45:56 --> Helper loaded: util_helper
INFO - 2018-05-12 01:45:56 --> Helper loaded: text_helper
INFO - 2018-05-12 01:45:56 --> Helper loaded: string_helper
INFO - 2018-05-12 01:45:56 --> Database Driver Class Initialized
DEBUG - 2018-05-12 01:45:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-12 01:45:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-12 01:45:56 --> Email Class Initialized
INFO - 2018-05-12 01:45:56 --> Controller Class Initialized
DEBUG - 2018-05-12 01:45:56 --> Chapters MX_Controller Initialized
INFO - 2018-05-12 01:45:56 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-12 01:45:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Chapters_model.php
DEBUG - 2018-05-12 01:45:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-12 01:45:56 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-12 01:45:56 --> Login MX_Controller Initialized
DEBUG - 2018-05-12 01:45:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-12 01:45:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-05-12 01:45:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-05-12 01:45:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-05-12 01:45:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-05-12 01:45:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-05-12 01:45:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/chapters/create_chapter.php
INFO - 2018-05-12 01:45:56 --> Final output sent to browser
DEBUG - 2018-05-12 01:45:57 --> Total execution time: 0.4817
INFO - 2018-05-12 01:45:58 --> Config Class Initialized
INFO - 2018-05-12 01:45:58 --> Hooks Class Initialized
DEBUG - 2018-05-12 01:45:58 --> UTF-8 Support Enabled
INFO - 2018-05-12 01:45:58 --> Utf8 Class Initialized
INFO - 2018-05-12 01:45:58 --> URI Class Initialized
INFO - 2018-05-12 01:45:58 --> Router Class Initialized
INFO - 2018-05-12 01:45:58 --> Output Class Initialized
INFO - 2018-05-12 01:45:58 --> Security Class Initialized
DEBUG - 2018-05-12 01:45:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 01:45:58 --> Input Class Initialized
INFO - 2018-05-12 01:45:58 --> Language Class Initialized
ERROR - 2018-05-12 01:45:58 --> 404 Page Not Found: /index
INFO - 2018-05-12 01:46:25 --> Config Class Initialized
INFO - 2018-05-12 01:46:25 --> Hooks Class Initialized
DEBUG - 2018-05-12 01:46:25 --> UTF-8 Support Enabled
INFO - 2018-05-12 01:46:25 --> Utf8 Class Initialized
INFO - 2018-05-12 01:46:25 --> URI Class Initialized
INFO - 2018-05-12 01:46:25 --> Router Class Initialized
INFO - 2018-05-12 01:46:25 --> Output Class Initialized
INFO - 2018-05-12 01:46:25 --> Security Class Initialized
DEBUG - 2018-05-12 01:46:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 01:46:25 --> Input Class Initialized
INFO - 2018-05-12 01:46:25 --> Language Class Initialized
INFO - 2018-05-12 01:46:25 --> Language Class Initialized
INFO - 2018-05-12 01:46:25 --> Config Class Initialized
INFO - 2018-05-12 01:46:25 --> Loader Class Initialized
DEBUG - 2018-05-12 01:46:25 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-12 01:46:25 --> Helper loaded: url_helper
INFO - 2018-05-12 01:46:25 --> Helper loaded: form_helper
INFO - 2018-05-12 01:46:25 --> Helper loaded: date_helper
INFO - 2018-05-12 01:46:25 --> Helper loaded: util_helper
INFO - 2018-05-12 01:46:25 --> Helper loaded: text_helper
INFO - 2018-05-12 01:46:25 --> Helper loaded: string_helper
INFO - 2018-05-12 01:46:25 --> Database Driver Class Initialized
DEBUG - 2018-05-12 01:46:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-12 01:46:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-12 01:46:25 --> Email Class Initialized
INFO - 2018-05-12 01:46:25 --> Controller Class Initialized
DEBUG - 2018-05-12 01:46:25 --> Chapters MX_Controller Initialized
INFO - 2018-05-12 01:46:25 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-12 01:46:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Chapters_model.php
DEBUG - 2018-05-12 01:46:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-12 01:46:25 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-12 01:46:25 --> Login MX_Controller Initialized
DEBUG - 2018-05-12 01:46:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-12 01:46:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-05-12 01:46:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-05-12 01:46:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-05-12 01:46:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-05-12 01:46:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-05-12 01:46:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/chapters/create_chapter.php
INFO - 2018-05-12 01:46:25 --> Final output sent to browser
DEBUG - 2018-05-12 01:46:25 --> Total execution time: 0.4695
INFO - 2018-05-12 01:46:26 --> Config Class Initialized
INFO - 2018-05-12 01:46:26 --> Hooks Class Initialized
DEBUG - 2018-05-12 01:46:26 --> UTF-8 Support Enabled
INFO - 2018-05-12 01:46:26 --> Utf8 Class Initialized
INFO - 2018-05-12 01:46:26 --> URI Class Initialized
INFO - 2018-05-12 01:46:27 --> Router Class Initialized
INFO - 2018-05-12 01:46:27 --> Output Class Initialized
INFO - 2018-05-12 01:46:27 --> Security Class Initialized
DEBUG - 2018-05-12 01:46:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 01:46:27 --> Input Class Initialized
INFO - 2018-05-12 01:46:27 --> Language Class Initialized
ERROR - 2018-05-12 01:46:27 --> 404 Page Not Found: /index
INFO - 2018-05-12 01:48:04 --> Config Class Initialized
INFO - 2018-05-12 01:48:04 --> Hooks Class Initialized
DEBUG - 2018-05-12 01:48:04 --> UTF-8 Support Enabled
INFO - 2018-05-12 01:48:04 --> Utf8 Class Initialized
INFO - 2018-05-12 01:48:04 --> URI Class Initialized
INFO - 2018-05-12 01:48:04 --> Router Class Initialized
INFO - 2018-05-12 01:48:04 --> Output Class Initialized
INFO - 2018-05-12 01:48:04 --> Security Class Initialized
DEBUG - 2018-05-12 01:48:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 01:48:04 --> Input Class Initialized
INFO - 2018-05-12 01:48:04 --> Language Class Initialized
INFO - 2018-05-12 01:48:04 --> Language Class Initialized
INFO - 2018-05-12 01:48:04 --> Config Class Initialized
INFO - 2018-05-12 01:48:04 --> Loader Class Initialized
DEBUG - 2018-05-12 01:48:04 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-12 01:48:04 --> Helper loaded: url_helper
INFO - 2018-05-12 01:48:04 --> Helper loaded: form_helper
INFO - 2018-05-12 01:48:04 --> Helper loaded: date_helper
INFO - 2018-05-12 01:48:04 --> Helper loaded: util_helper
INFO - 2018-05-12 01:48:04 --> Helper loaded: text_helper
INFO - 2018-05-12 01:48:04 --> Helper loaded: string_helper
INFO - 2018-05-12 01:48:04 --> Database Driver Class Initialized
DEBUG - 2018-05-12 01:48:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-12 01:48:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-12 01:48:04 --> Email Class Initialized
INFO - 2018-05-12 01:48:04 --> Controller Class Initialized
DEBUG - 2018-05-12 01:48:04 --> Chapters MX_Controller Initialized
INFO - 2018-05-12 01:48:04 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-12 01:48:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Chapters_model.php
DEBUG - 2018-05-12 01:48:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-12 01:48:04 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-12 01:48:04 --> Login MX_Controller Initialized
DEBUG - 2018-05-12 01:48:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-12 01:48:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-05-12 01:48:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-05-12 01:48:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-05-12 01:48:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-05-12 01:48:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-05-12 01:48:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/chapters/create_chapter.php
INFO - 2018-05-12 01:48:05 --> Final output sent to browser
DEBUG - 2018-05-12 01:48:05 --> Total execution time: 0.4710
INFO - 2018-05-12 01:48:06 --> Config Class Initialized
INFO - 2018-05-12 01:48:06 --> Hooks Class Initialized
DEBUG - 2018-05-12 01:48:06 --> UTF-8 Support Enabled
INFO - 2018-05-12 01:48:06 --> Utf8 Class Initialized
INFO - 2018-05-12 01:48:06 --> URI Class Initialized
INFO - 2018-05-12 01:48:06 --> Router Class Initialized
INFO - 2018-05-12 01:48:06 --> Output Class Initialized
INFO - 2018-05-12 01:48:06 --> Security Class Initialized
DEBUG - 2018-05-12 01:48:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 01:48:06 --> Input Class Initialized
INFO - 2018-05-12 01:48:06 --> Language Class Initialized
ERROR - 2018-05-12 01:48:06 --> 404 Page Not Found: /index
INFO - 2018-05-12 01:50:06 --> Config Class Initialized
INFO - 2018-05-12 01:50:06 --> Hooks Class Initialized
DEBUG - 2018-05-12 01:50:06 --> UTF-8 Support Enabled
INFO - 2018-05-12 01:50:06 --> Utf8 Class Initialized
INFO - 2018-05-12 01:50:06 --> URI Class Initialized
INFO - 2018-05-12 01:50:06 --> Router Class Initialized
INFO - 2018-05-12 01:50:06 --> Output Class Initialized
INFO - 2018-05-12 01:50:06 --> Security Class Initialized
DEBUG - 2018-05-12 01:50:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 01:50:06 --> Input Class Initialized
INFO - 2018-05-12 01:50:06 --> Language Class Initialized
INFO - 2018-05-12 01:50:06 --> Language Class Initialized
INFO - 2018-05-12 01:50:06 --> Config Class Initialized
INFO - 2018-05-12 01:50:06 --> Loader Class Initialized
DEBUG - 2018-05-12 01:50:06 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-12 01:50:06 --> Helper loaded: url_helper
INFO - 2018-05-12 01:50:06 --> Helper loaded: form_helper
INFO - 2018-05-12 01:50:06 --> Helper loaded: date_helper
INFO - 2018-05-12 01:50:06 --> Helper loaded: util_helper
INFO - 2018-05-12 01:50:06 --> Helper loaded: text_helper
INFO - 2018-05-12 01:50:06 --> Helper loaded: string_helper
INFO - 2018-05-12 01:50:06 --> Database Driver Class Initialized
DEBUG - 2018-05-12 01:50:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-12 01:50:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-12 01:50:06 --> Email Class Initialized
INFO - 2018-05-12 01:50:06 --> Controller Class Initialized
DEBUG - 2018-05-12 01:50:06 --> Chapters MX_Controller Initialized
INFO - 2018-05-12 01:50:06 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-12 01:50:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Chapters_model.php
DEBUG - 2018-05-12 01:50:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-12 01:50:06 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-12 01:50:06 --> Login MX_Controller Initialized
DEBUG - 2018-05-12 01:50:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-12 01:50:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-05-12 01:50:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-05-12 01:50:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-05-12 01:50:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-05-12 01:50:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-05-12 01:50:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/chapters/create_chapter.php
INFO - 2018-05-12 01:50:07 --> Final output sent to browser
DEBUG - 2018-05-12 01:50:07 --> Total execution time: 0.5358
INFO - 2018-05-12 01:50:07 --> Config Class Initialized
INFO - 2018-05-12 01:50:07 --> Hooks Class Initialized
DEBUG - 2018-05-12 01:50:08 --> UTF-8 Support Enabled
INFO - 2018-05-12 01:50:08 --> Utf8 Class Initialized
INFO - 2018-05-12 01:50:08 --> URI Class Initialized
INFO - 2018-05-12 01:50:08 --> Router Class Initialized
INFO - 2018-05-12 01:50:08 --> Output Class Initialized
INFO - 2018-05-12 01:50:08 --> Security Class Initialized
DEBUG - 2018-05-12 01:50:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 01:50:08 --> Input Class Initialized
INFO - 2018-05-12 01:50:08 --> Language Class Initialized
ERROR - 2018-05-12 01:50:08 --> 404 Page Not Found: /index
INFO - 2018-05-12 01:51:42 --> Config Class Initialized
INFO - 2018-05-12 01:51:42 --> Hooks Class Initialized
DEBUG - 2018-05-12 01:51:42 --> UTF-8 Support Enabled
INFO - 2018-05-12 01:51:42 --> Utf8 Class Initialized
INFO - 2018-05-12 01:51:42 --> URI Class Initialized
INFO - 2018-05-12 01:51:42 --> Router Class Initialized
INFO - 2018-05-12 01:51:42 --> Output Class Initialized
INFO - 2018-05-12 01:51:42 --> Security Class Initialized
DEBUG - 2018-05-12 01:51:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 01:51:42 --> Input Class Initialized
INFO - 2018-05-12 01:51:42 --> Language Class Initialized
INFO - 2018-05-12 01:51:42 --> Language Class Initialized
INFO - 2018-05-12 01:51:42 --> Config Class Initialized
INFO - 2018-05-12 01:51:42 --> Loader Class Initialized
DEBUG - 2018-05-12 01:51:42 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-12 01:51:42 --> Helper loaded: url_helper
INFO - 2018-05-12 01:51:42 --> Helper loaded: form_helper
INFO - 2018-05-12 01:51:42 --> Helper loaded: date_helper
INFO - 2018-05-12 01:51:42 --> Helper loaded: util_helper
INFO - 2018-05-12 01:51:42 --> Helper loaded: text_helper
INFO - 2018-05-12 01:51:42 --> Helper loaded: string_helper
INFO - 2018-05-12 01:51:42 --> Database Driver Class Initialized
DEBUG - 2018-05-12 01:51:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-12 01:51:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-12 01:51:42 --> Email Class Initialized
INFO - 2018-05-12 01:51:42 --> Controller Class Initialized
DEBUG - 2018-05-12 01:51:42 --> Chapters MX_Controller Initialized
INFO - 2018-05-12 01:51:42 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-12 01:51:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Chapters_model.php
DEBUG - 2018-05-12 01:51:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-12 01:51:42 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-12 01:51:42 --> Login MX_Controller Initialized
DEBUG - 2018-05-12 01:51:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-12 01:51:42 --> Config Class Initialized
INFO - 2018-05-12 01:51:42 --> Hooks Class Initialized
DEBUG - 2018-05-12 01:51:42 --> UTF-8 Support Enabled
INFO - 2018-05-12 01:51:42 --> Utf8 Class Initialized
INFO - 2018-05-12 01:51:42 --> URI Class Initialized
INFO - 2018-05-12 01:51:42 --> Router Class Initialized
INFO - 2018-05-12 01:51:42 --> Output Class Initialized
INFO - 2018-05-12 01:51:42 --> Security Class Initialized
DEBUG - 2018-05-12 01:51:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 01:51:42 --> Input Class Initialized
INFO - 2018-05-12 01:51:42 --> Language Class Initialized
INFO - 2018-05-12 01:51:42 --> Language Class Initialized
INFO - 2018-05-12 01:51:42 --> Config Class Initialized
INFO - 2018-05-12 01:51:42 --> Loader Class Initialized
DEBUG - 2018-05-12 01:51:42 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-12 01:51:42 --> Helper loaded: url_helper
INFO - 2018-05-12 01:51:42 --> Helper loaded: form_helper
INFO - 2018-05-12 01:51:42 --> Helper loaded: date_helper
INFO - 2018-05-12 01:51:42 --> Helper loaded: util_helper
INFO - 2018-05-12 01:51:42 --> Helper loaded: text_helper
INFO - 2018-05-12 01:51:42 --> Helper loaded: string_helper
INFO - 2018-05-12 01:51:42 --> Database Driver Class Initialized
DEBUG - 2018-05-12 01:51:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-12 01:51:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-12 01:51:42 --> Email Class Initialized
INFO - 2018-05-12 01:51:42 --> Controller Class Initialized
DEBUG - 2018-05-12 01:51:43 --> Chapters MX_Controller Initialized
INFO - 2018-05-12 01:51:43 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-12 01:51:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Chapters_model.php
DEBUG - 2018-05-12 01:51:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-12 01:51:43 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-12 01:51:43 --> Login MX_Controller Initialized
DEBUG - 2018-05-12 01:51:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-12 01:51:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-05-12 01:51:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-05-12 01:51:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-05-12 01:51:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-05-12 01:51:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-05-12 01:51:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/chapters/chapters.php
INFO - 2018-05-12 01:51:43 --> Final output sent to browser
DEBUG - 2018-05-12 01:51:43 --> Total execution time: 0.7601
INFO - 2018-05-12 01:51:44 --> Config Class Initialized
INFO - 2018-05-12 01:51:44 --> Hooks Class Initialized
DEBUG - 2018-05-12 01:51:44 --> UTF-8 Support Enabled
INFO - 2018-05-12 01:51:44 --> Utf8 Class Initialized
INFO - 2018-05-12 01:51:44 --> URI Class Initialized
INFO - 2018-05-12 01:51:44 --> Router Class Initialized
INFO - 2018-05-12 01:51:44 --> Output Class Initialized
INFO - 2018-05-12 01:51:44 --> Security Class Initialized
DEBUG - 2018-05-12 01:51:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 01:51:44 --> Input Class Initialized
INFO - 2018-05-12 01:51:44 --> Language Class Initialized
INFO - 2018-05-12 01:51:44 --> Language Class Initialized
INFO - 2018-05-12 01:51:44 --> Config Class Initialized
INFO - 2018-05-12 01:51:44 --> Loader Class Initialized
DEBUG - 2018-05-12 01:51:44 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-12 01:51:44 --> Helper loaded: url_helper
INFO - 2018-05-12 01:51:44 --> Helper loaded: form_helper
INFO - 2018-05-12 01:51:44 --> Helper loaded: date_helper
INFO - 2018-05-12 01:51:44 --> Helper loaded: util_helper
INFO - 2018-05-12 01:51:44 --> Helper loaded: text_helper
INFO - 2018-05-12 01:51:44 --> Helper loaded: string_helper
INFO - 2018-05-12 01:51:44 --> Database Driver Class Initialized
DEBUG - 2018-05-12 01:51:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-12 01:51:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-12 01:51:44 --> Email Class Initialized
INFO - 2018-05-12 01:51:44 --> Controller Class Initialized
DEBUG - 2018-05-12 01:51:44 --> Chapters MX_Controller Initialized
INFO - 2018-05-12 01:51:44 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-12 01:51:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Chapters_model.php
DEBUG - 2018-05-12 01:51:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-12 01:51:44 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-12 01:51:44 --> Login MX_Controller Initialized
DEBUG - 2018-05-12 01:51:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-12 01:51:44 --> Final output sent to browser
DEBUG - 2018-05-12 01:51:44 --> Total execution time: 0.7464
INFO - 2018-05-12 01:51:48 --> Config Class Initialized
INFO - 2018-05-12 01:51:48 --> Hooks Class Initialized
DEBUG - 2018-05-12 01:51:48 --> UTF-8 Support Enabled
INFO - 2018-05-12 01:51:48 --> Utf8 Class Initialized
INFO - 2018-05-12 01:51:48 --> URI Class Initialized
INFO - 2018-05-12 01:51:48 --> Router Class Initialized
INFO - 2018-05-12 01:51:48 --> Output Class Initialized
INFO - 2018-05-12 01:51:48 --> Security Class Initialized
DEBUG - 2018-05-12 01:51:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 01:51:48 --> Input Class Initialized
INFO - 2018-05-12 01:51:48 --> Language Class Initialized
INFO - 2018-05-12 01:51:48 --> Language Class Initialized
INFO - 2018-05-12 01:51:48 --> Config Class Initialized
INFO - 2018-05-12 01:51:48 --> Loader Class Initialized
DEBUG - 2018-05-12 01:51:48 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-12 01:51:48 --> Helper loaded: url_helper
INFO - 2018-05-12 01:51:48 --> Helper loaded: form_helper
INFO - 2018-05-12 01:51:48 --> Helper loaded: date_helper
INFO - 2018-05-12 01:51:48 --> Helper loaded: util_helper
INFO - 2018-05-12 01:51:48 --> Helper loaded: text_helper
INFO - 2018-05-12 01:51:48 --> Helper loaded: string_helper
INFO - 2018-05-12 01:51:48 --> Database Driver Class Initialized
DEBUG - 2018-05-12 01:51:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-12 01:51:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-12 01:51:48 --> Email Class Initialized
INFO - 2018-05-12 01:51:48 --> Controller Class Initialized
DEBUG - 2018-05-12 01:51:48 --> Chapters MX_Controller Initialized
INFO - 2018-05-12 01:51:48 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-12 01:51:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Chapters_model.php
DEBUG - 2018-05-12 01:51:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-12 01:51:48 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-12 01:51:49 --> Login MX_Controller Initialized
DEBUG - 2018-05-12 01:51:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-12 01:51:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-05-12 01:51:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-05-12 01:51:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-05-12 01:51:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-05-12 01:51:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-05-12 01:51:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/chapters/create_chapter.php
INFO - 2018-05-12 01:51:49 --> Final output sent to browser
DEBUG - 2018-05-12 01:51:49 --> Total execution time: 0.4788
INFO - 2018-05-12 01:51:52 --> Config Class Initialized
INFO - 2018-05-12 01:51:52 --> Hooks Class Initialized
DEBUG - 2018-05-12 01:51:52 --> UTF-8 Support Enabled
INFO - 2018-05-12 01:51:52 --> Utf8 Class Initialized
INFO - 2018-05-12 01:51:52 --> URI Class Initialized
INFO - 2018-05-12 01:51:52 --> Router Class Initialized
INFO - 2018-05-12 01:51:52 --> Output Class Initialized
INFO - 2018-05-12 01:51:52 --> Security Class Initialized
DEBUG - 2018-05-12 01:51:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 01:51:52 --> Input Class Initialized
INFO - 2018-05-12 01:51:52 --> Language Class Initialized
INFO - 2018-05-12 01:51:52 --> Language Class Initialized
INFO - 2018-05-12 01:51:52 --> Config Class Initialized
INFO - 2018-05-12 01:51:52 --> Loader Class Initialized
DEBUG - 2018-05-12 01:51:52 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-12 01:51:52 --> Helper loaded: url_helper
INFO - 2018-05-12 01:51:52 --> Helper loaded: form_helper
INFO - 2018-05-12 01:51:52 --> Helper loaded: date_helper
INFO - 2018-05-12 01:51:52 --> Helper loaded: util_helper
INFO - 2018-05-12 01:51:52 --> Helper loaded: text_helper
INFO - 2018-05-12 01:51:52 --> Helper loaded: string_helper
INFO - 2018-05-12 01:51:52 --> Database Driver Class Initialized
DEBUG - 2018-05-12 01:51:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-12 01:51:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-12 01:51:52 --> Email Class Initialized
INFO - 2018-05-12 01:51:52 --> Controller Class Initialized
DEBUG - 2018-05-12 01:51:52 --> Chapters MX_Controller Initialized
INFO - 2018-05-12 01:51:52 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-12 01:51:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Chapters_model.php
DEBUG - 2018-05-12 01:51:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-12 01:51:52 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-12 01:51:52 --> Login MX_Controller Initialized
DEBUG - 2018-05-12 01:51:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-12 01:51:52 --> Config Class Initialized
INFO - 2018-05-12 01:51:52 --> Hooks Class Initialized
DEBUG - 2018-05-12 01:51:52 --> UTF-8 Support Enabled
INFO - 2018-05-12 01:51:52 --> Utf8 Class Initialized
INFO - 2018-05-12 01:51:53 --> URI Class Initialized
INFO - 2018-05-12 01:51:53 --> Router Class Initialized
INFO - 2018-05-12 01:51:53 --> Output Class Initialized
INFO - 2018-05-12 01:51:53 --> Security Class Initialized
DEBUG - 2018-05-12 01:51:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 01:51:53 --> Input Class Initialized
INFO - 2018-05-12 01:51:53 --> Language Class Initialized
INFO - 2018-05-12 01:51:53 --> Language Class Initialized
INFO - 2018-05-12 01:51:53 --> Config Class Initialized
INFO - 2018-05-12 01:51:53 --> Loader Class Initialized
DEBUG - 2018-05-12 01:51:53 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-12 01:51:53 --> Helper loaded: url_helper
INFO - 2018-05-12 01:51:53 --> Helper loaded: form_helper
INFO - 2018-05-12 01:51:53 --> Helper loaded: date_helper
INFO - 2018-05-12 01:51:53 --> Helper loaded: util_helper
INFO - 2018-05-12 01:51:53 --> Helper loaded: text_helper
INFO - 2018-05-12 01:51:53 --> Helper loaded: string_helper
INFO - 2018-05-12 01:51:53 --> Database Driver Class Initialized
DEBUG - 2018-05-12 01:51:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-12 01:51:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-12 01:51:53 --> Email Class Initialized
INFO - 2018-05-12 01:51:53 --> Controller Class Initialized
DEBUG - 2018-05-12 01:51:53 --> Chapters MX_Controller Initialized
INFO - 2018-05-12 01:51:53 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-12 01:51:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Chapters_model.php
DEBUG - 2018-05-12 01:51:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-12 01:51:53 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-12 01:51:53 --> Login MX_Controller Initialized
DEBUG - 2018-05-12 01:51:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-12 01:51:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-05-12 01:51:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-05-12 01:51:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-05-12 01:51:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-05-12 01:51:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-05-12 01:51:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/chapters/chapters.php
INFO - 2018-05-12 01:51:53 --> Final output sent to browser
DEBUG - 2018-05-12 01:51:53 --> Total execution time: 0.5067
INFO - 2018-05-12 01:51:53 --> Config Class Initialized
INFO - 2018-05-12 01:51:53 --> Hooks Class Initialized
DEBUG - 2018-05-12 01:51:54 --> UTF-8 Support Enabled
INFO - 2018-05-12 01:51:54 --> Utf8 Class Initialized
INFO - 2018-05-12 01:51:54 --> URI Class Initialized
INFO - 2018-05-12 01:51:54 --> Router Class Initialized
INFO - 2018-05-12 01:51:54 --> Output Class Initialized
INFO - 2018-05-12 01:51:54 --> Security Class Initialized
DEBUG - 2018-05-12 01:51:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 01:51:54 --> Input Class Initialized
INFO - 2018-05-12 01:51:54 --> Language Class Initialized
INFO - 2018-05-12 01:51:54 --> Language Class Initialized
INFO - 2018-05-12 01:51:54 --> Config Class Initialized
INFO - 2018-05-12 01:51:54 --> Loader Class Initialized
DEBUG - 2018-05-12 01:51:54 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-12 01:51:54 --> Helper loaded: url_helper
INFO - 2018-05-12 01:51:54 --> Helper loaded: form_helper
INFO - 2018-05-12 01:51:54 --> Helper loaded: date_helper
INFO - 2018-05-12 01:51:54 --> Helper loaded: util_helper
INFO - 2018-05-12 01:51:54 --> Helper loaded: text_helper
INFO - 2018-05-12 01:51:54 --> Helper loaded: string_helper
INFO - 2018-05-12 01:51:54 --> Database Driver Class Initialized
DEBUG - 2018-05-12 01:51:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-12 01:51:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-12 01:51:54 --> Email Class Initialized
INFO - 2018-05-12 01:51:54 --> Controller Class Initialized
DEBUG - 2018-05-12 01:51:54 --> Chapters MX_Controller Initialized
INFO - 2018-05-12 01:51:54 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-12 01:51:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Chapters_model.php
DEBUG - 2018-05-12 01:51:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-12 01:51:54 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-12 01:51:54 --> Login MX_Controller Initialized
DEBUG - 2018-05-12 01:51:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-12 01:51:54 --> Final output sent to browser
DEBUG - 2018-05-12 01:51:54 --> Total execution time: 0.5559
INFO - 2018-05-12 01:51:57 --> Config Class Initialized
INFO - 2018-05-12 01:51:57 --> Hooks Class Initialized
DEBUG - 2018-05-12 01:51:57 --> UTF-8 Support Enabled
INFO - 2018-05-12 01:51:57 --> Utf8 Class Initialized
INFO - 2018-05-12 01:51:57 --> URI Class Initialized
INFO - 2018-05-12 01:51:57 --> Router Class Initialized
INFO - 2018-05-12 01:51:57 --> Output Class Initialized
INFO - 2018-05-12 01:51:57 --> Security Class Initialized
DEBUG - 2018-05-12 01:51:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 01:51:57 --> Input Class Initialized
INFO - 2018-05-12 01:51:57 --> Language Class Initialized
INFO - 2018-05-12 01:51:57 --> Language Class Initialized
INFO - 2018-05-12 01:51:57 --> Config Class Initialized
INFO - 2018-05-12 01:51:57 --> Loader Class Initialized
DEBUG - 2018-05-12 01:51:57 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-12 01:51:57 --> Helper loaded: url_helper
INFO - 2018-05-12 01:51:57 --> Helper loaded: form_helper
INFO - 2018-05-12 01:51:57 --> Helper loaded: date_helper
INFO - 2018-05-12 01:51:57 --> Helper loaded: util_helper
INFO - 2018-05-12 01:51:57 --> Helper loaded: text_helper
INFO - 2018-05-12 01:51:57 --> Helper loaded: string_helper
INFO - 2018-05-12 01:51:57 --> Database Driver Class Initialized
DEBUG - 2018-05-12 01:51:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-12 01:51:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-12 01:51:57 --> Email Class Initialized
INFO - 2018-05-12 01:51:57 --> Controller Class Initialized
DEBUG - 2018-05-12 01:51:57 --> Chapters MX_Controller Initialized
INFO - 2018-05-12 01:51:57 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-12 01:51:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Chapters_model.php
DEBUG - 2018-05-12 01:51:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-12 01:51:57 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-12 01:51:57 --> Login MX_Controller Initialized
DEBUG - 2018-05-12 01:51:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-12 01:51:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-05-12 01:51:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-05-12 01:51:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-05-12 01:51:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-05-12 01:51:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-05-12 01:51:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/chapters/create_chapter.php
INFO - 2018-05-12 01:51:57 --> Final output sent to browser
DEBUG - 2018-05-12 01:51:57 --> Total execution time: 0.4713
INFO - 2018-05-12 01:51:59 --> Config Class Initialized
INFO - 2018-05-12 01:51:59 --> Hooks Class Initialized
DEBUG - 2018-05-12 01:51:59 --> UTF-8 Support Enabled
INFO - 2018-05-12 01:51:59 --> Utf8 Class Initialized
INFO - 2018-05-12 01:51:59 --> URI Class Initialized
INFO - 2018-05-12 01:51:59 --> Router Class Initialized
INFO - 2018-05-12 01:51:59 --> Output Class Initialized
INFO - 2018-05-12 01:51:59 --> Security Class Initialized
DEBUG - 2018-05-12 01:51:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 01:51:59 --> Input Class Initialized
INFO - 2018-05-12 01:51:59 --> Language Class Initialized
INFO - 2018-05-12 01:51:59 --> Language Class Initialized
INFO - 2018-05-12 01:51:59 --> Config Class Initialized
INFO - 2018-05-12 01:51:59 --> Loader Class Initialized
DEBUG - 2018-05-12 01:51:59 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-12 01:51:59 --> Helper loaded: url_helper
INFO - 2018-05-12 01:51:59 --> Helper loaded: form_helper
INFO - 2018-05-12 01:51:59 --> Helper loaded: date_helper
INFO - 2018-05-12 01:51:59 --> Helper loaded: util_helper
INFO - 2018-05-12 01:51:59 --> Helper loaded: text_helper
INFO - 2018-05-12 01:51:59 --> Helper loaded: string_helper
INFO - 2018-05-12 01:51:59 --> Database Driver Class Initialized
DEBUG - 2018-05-12 01:51:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-12 01:51:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-12 01:51:59 --> Email Class Initialized
INFO - 2018-05-12 01:51:59 --> Controller Class Initialized
DEBUG - 2018-05-12 01:51:59 --> Chapters MX_Controller Initialized
INFO - 2018-05-12 01:51:59 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-12 01:51:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Chapters_model.php
DEBUG - 2018-05-12 01:51:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-12 01:51:59 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-12 01:51:59 --> Login MX_Controller Initialized
DEBUG - 2018-05-12 01:51:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-12 01:51:59 --> Config Class Initialized
INFO - 2018-05-12 01:51:59 --> Hooks Class Initialized
DEBUG - 2018-05-12 01:51:59 --> UTF-8 Support Enabled
INFO - 2018-05-12 01:51:59 --> Utf8 Class Initialized
INFO - 2018-05-12 01:51:59 --> URI Class Initialized
INFO - 2018-05-12 01:51:59 --> Router Class Initialized
INFO - 2018-05-12 01:51:59 --> Output Class Initialized
INFO - 2018-05-12 01:51:59 --> Security Class Initialized
DEBUG - 2018-05-12 01:51:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 01:51:59 --> Input Class Initialized
INFO - 2018-05-12 01:51:59 --> Language Class Initialized
INFO - 2018-05-12 01:51:59 --> Language Class Initialized
INFO - 2018-05-12 01:52:00 --> Config Class Initialized
INFO - 2018-05-12 01:52:00 --> Loader Class Initialized
DEBUG - 2018-05-12 01:52:00 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-12 01:52:00 --> Helper loaded: url_helper
INFO - 2018-05-12 01:52:00 --> Helper loaded: form_helper
INFO - 2018-05-12 01:52:00 --> Helper loaded: date_helper
INFO - 2018-05-12 01:52:00 --> Helper loaded: util_helper
INFO - 2018-05-12 01:52:00 --> Helper loaded: text_helper
INFO - 2018-05-12 01:52:00 --> Helper loaded: string_helper
INFO - 2018-05-12 01:52:00 --> Database Driver Class Initialized
DEBUG - 2018-05-12 01:52:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-12 01:52:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-12 01:52:00 --> Email Class Initialized
INFO - 2018-05-12 01:52:00 --> Controller Class Initialized
DEBUG - 2018-05-12 01:52:00 --> Chapters MX_Controller Initialized
INFO - 2018-05-12 01:52:00 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-12 01:52:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Chapters_model.php
DEBUG - 2018-05-12 01:52:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-12 01:52:00 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-12 01:52:00 --> Login MX_Controller Initialized
DEBUG - 2018-05-12 01:52:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-12 01:52:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-05-12 01:52:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-05-12 01:52:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-05-12 01:52:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-05-12 01:52:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-05-12 01:52:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/chapters/chapters.php
INFO - 2018-05-12 01:52:00 --> Final output sent to browser
DEBUG - 2018-05-12 01:52:00 --> Total execution time: 0.5048
INFO - 2018-05-12 01:52:00 --> Config Class Initialized
INFO - 2018-05-12 01:52:00 --> Hooks Class Initialized
DEBUG - 2018-05-12 01:52:00 --> UTF-8 Support Enabled
INFO - 2018-05-12 01:52:00 --> Utf8 Class Initialized
INFO - 2018-05-12 01:52:00 --> URI Class Initialized
INFO - 2018-05-12 01:52:00 --> Router Class Initialized
INFO - 2018-05-12 01:52:00 --> Output Class Initialized
INFO - 2018-05-12 01:52:00 --> Security Class Initialized
DEBUG - 2018-05-12 01:52:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 01:52:00 --> Input Class Initialized
INFO - 2018-05-12 01:52:00 --> Language Class Initialized
INFO - 2018-05-12 01:52:00 --> Language Class Initialized
INFO - 2018-05-12 01:52:00 --> Config Class Initialized
INFO - 2018-05-12 01:52:00 --> Loader Class Initialized
DEBUG - 2018-05-12 01:52:00 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-12 01:52:00 --> Helper loaded: url_helper
INFO - 2018-05-12 01:52:00 --> Helper loaded: form_helper
INFO - 2018-05-12 01:52:00 --> Helper loaded: date_helper
INFO - 2018-05-12 01:52:00 --> Helper loaded: util_helper
INFO - 2018-05-12 01:52:01 --> Helper loaded: text_helper
INFO - 2018-05-12 01:52:01 --> Helper loaded: string_helper
INFO - 2018-05-12 01:52:01 --> Database Driver Class Initialized
DEBUG - 2018-05-12 01:52:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-12 01:52:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-12 01:52:01 --> Email Class Initialized
INFO - 2018-05-12 01:52:01 --> Controller Class Initialized
DEBUG - 2018-05-12 01:52:01 --> Chapters MX_Controller Initialized
INFO - 2018-05-12 01:52:01 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-12 01:52:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Chapters_model.php
DEBUG - 2018-05-12 01:52:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-12 01:52:01 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-12 01:52:01 --> Login MX_Controller Initialized
DEBUG - 2018-05-12 01:52:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-12 01:52:01 --> Final output sent to browser
DEBUG - 2018-05-12 01:52:01 --> Total execution time: 0.5380
INFO - 2018-05-12 01:52:37 --> Config Class Initialized
INFO - 2018-05-12 01:52:37 --> Hooks Class Initialized
DEBUG - 2018-05-12 01:52:37 --> UTF-8 Support Enabled
INFO - 2018-05-12 01:52:37 --> Utf8 Class Initialized
INFO - 2018-05-12 01:52:37 --> URI Class Initialized
INFO - 2018-05-12 01:52:37 --> Router Class Initialized
INFO - 2018-05-12 01:52:37 --> Output Class Initialized
INFO - 2018-05-12 01:52:37 --> Security Class Initialized
DEBUG - 2018-05-12 01:52:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 01:52:37 --> Input Class Initialized
INFO - 2018-05-12 01:52:37 --> Language Class Initialized
INFO - 2018-05-12 01:52:37 --> Language Class Initialized
INFO - 2018-05-12 01:52:37 --> Config Class Initialized
INFO - 2018-05-12 01:52:37 --> Loader Class Initialized
DEBUG - 2018-05-12 01:52:37 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-12 01:52:37 --> Helper loaded: url_helper
INFO - 2018-05-12 01:52:37 --> Helper loaded: form_helper
INFO - 2018-05-12 01:52:37 --> Helper loaded: date_helper
INFO - 2018-05-12 01:52:37 --> Helper loaded: util_helper
INFO - 2018-05-12 01:52:37 --> Helper loaded: text_helper
INFO - 2018-05-12 01:52:37 --> Helper loaded: string_helper
INFO - 2018-05-12 01:52:37 --> Database Driver Class Initialized
DEBUG - 2018-05-12 01:52:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-12 01:52:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-12 01:52:37 --> Email Class Initialized
INFO - 2018-05-12 01:52:37 --> Controller Class Initialized
DEBUG - 2018-05-12 01:52:37 --> Admin MX_Controller Initialized
INFO - 2018-05-12 01:52:37 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-12 01:52:37 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-12 01:52:37 --> Login MX_Controller Initialized
DEBUG - 2018-05-12 01:52:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-12 01:52:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-12 01:52:37 --> Final output sent to browser
DEBUG - 2018-05-12 01:52:38 --> Total execution time: 0.4788
INFO - 2018-05-12 01:52:38 --> Config Class Initialized
INFO - 2018-05-12 01:52:38 --> Hooks Class Initialized
DEBUG - 2018-05-12 01:52:38 --> UTF-8 Support Enabled
INFO - 2018-05-12 01:52:38 --> Utf8 Class Initialized
INFO - 2018-05-12 01:52:38 --> URI Class Initialized
INFO - 2018-05-12 01:52:38 --> Router Class Initialized
INFO - 2018-05-12 01:52:38 --> Output Class Initialized
INFO - 2018-05-12 01:52:38 --> Security Class Initialized
DEBUG - 2018-05-12 01:52:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 01:52:38 --> Input Class Initialized
INFO - 2018-05-12 01:52:38 --> Language Class Initialized
INFO - 2018-05-12 01:52:38 --> Language Class Initialized
INFO - 2018-05-12 01:52:38 --> Config Class Initialized
INFO - 2018-05-12 01:52:38 --> Loader Class Initialized
DEBUG - 2018-05-12 01:52:38 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-12 01:52:38 --> Helper loaded: url_helper
INFO - 2018-05-12 01:52:38 --> Helper loaded: form_helper
INFO - 2018-05-12 01:52:38 --> Helper loaded: date_helper
INFO - 2018-05-12 01:52:38 --> Helper loaded: util_helper
INFO - 2018-05-12 01:52:38 --> Helper loaded: text_helper
INFO - 2018-05-12 01:52:38 --> Helper loaded: string_helper
INFO - 2018-05-12 01:52:38 --> Database Driver Class Initialized
DEBUG - 2018-05-12 01:52:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-12 01:52:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-12 01:52:39 --> Email Class Initialized
INFO - 2018-05-12 01:52:39 --> Controller Class Initialized
DEBUG - 2018-05-12 01:52:39 --> Admin MX_Controller Initialized
INFO - 2018-05-12 01:52:39 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-12 01:52:39 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-12 01:52:39 --> Login MX_Controller Initialized
DEBUG - 2018-05-12 01:52:39 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-12 01:52:39 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-12 01:52:39 --> Final output sent to browser
DEBUG - 2018-05-12 01:52:39 --> Total execution time: 0.4523
INFO - 2018-05-12 01:52:39 --> Config Class Initialized
INFO - 2018-05-12 01:52:39 --> Hooks Class Initialized
DEBUG - 2018-05-12 01:52:39 --> UTF-8 Support Enabled
INFO - 2018-05-12 01:52:39 --> Utf8 Class Initialized
INFO - 2018-05-12 01:52:39 --> URI Class Initialized
INFO - 2018-05-12 01:52:39 --> Router Class Initialized
INFO - 2018-05-12 01:52:39 --> Output Class Initialized
INFO - 2018-05-12 01:52:39 --> Security Class Initialized
DEBUG - 2018-05-12 01:52:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 01:52:39 --> Input Class Initialized
INFO - 2018-05-12 01:52:39 --> Language Class Initialized
INFO - 2018-05-12 01:52:39 --> Language Class Initialized
INFO - 2018-05-12 01:52:39 --> Config Class Initialized
INFO - 2018-05-12 01:52:39 --> Loader Class Initialized
DEBUG - 2018-05-12 01:52:39 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-12 01:52:39 --> Helper loaded: url_helper
INFO - 2018-05-12 01:52:39 --> Helper loaded: form_helper
INFO - 2018-05-12 01:52:39 --> Helper loaded: date_helper
INFO - 2018-05-12 01:52:39 --> Helper loaded: util_helper
INFO - 2018-05-12 01:52:39 --> Helper loaded: text_helper
INFO - 2018-05-12 01:52:39 --> Helper loaded: string_helper
INFO - 2018-05-12 01:52:39 --> Database Driver Class Initialized
DEBUG - 2018-05-12 01:52:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-12 01:52:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-12 01:52:39 --> Email Class Initialized
INFO - 2018-05-12 01:52:39 --> Controller Class Initialized
DEBUG - 2018-05-12 01:52:39 --> Admin MX_Controller Initialized
INFO - 2018-05-12 01:52:39 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-12 01:52:40 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-12 01:52:40 --> Login MX_Controller Initialized
DEBUG - 2018-05-12 01:52:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-12 01:52:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-12 01:52:40 --> Final output sent to browser
DEBUG - 2018-05-12 01:52:40 --> Total execution time: 0.4526
INFO - 2018-05-12 01:52:41 --> Config Class Initialized
INFO - 2018-05-12 01:52:41 --> Hooks Class Initialized
DEBUG - 2018-05-12 01:52:41 --> UTF-8 Support Enabled
INFO - 2018-05-12 01:52:41 --> Utf8 Class Initialized
INFO - 2018-05-12 01:52:41 --> URI Class Initialized
INFO - 2018-05-12 01:52:41 --> Router Class Initialized
INFO - 2018-05-12 01:52:41 --> Output Class Initialized
INFO - 2018-05-12 01:52:41 --> Security Class Initialized
DEBUG - 2018-05-12 01:52:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 01:52:41 --> Input Class Initialized
INFO - 2018-05-12 01:52:41 --> Language Class Initialized
INFO - 2018-05-12 01:52:41 --> Language Class Initialized
INFO - 2018-05-12 01:52:41 --> Config Class Initialized
INFO - 2018-05-12 01:52:41 --> Loader Class Initialized
DEBUG - 2018-05-12 01:52:41 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-12 01:52:41 --> Helper loaded: url_helper
INFO - 2018-05-12 01:52:41 --> Helper loaded: form_helper
INFO - 2018-05-12 01:52:41 --> Helper loaded: date_helper
INFO - 2018-05-12 01:52:41 --> Helper loaded: util_helper
INFO - 2018-05-12 01:52:41 --> Helper loaded: text_helper
INFO - 2018-05-12 01:52:41 --> Helper loaded: string_helper
INFO - 2018-05-12 01:52:41 --> Database Driver Class Initialized
DEBUG - 2018-05-12 01:52:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-12 01:52:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-12 01:52:41 --> Email Class Initialized
INFO - 2018-05-12 01:52:41 --> Controller Class Initialized
DEBUG - 2018-05-12 01:52:41 --> Chapters MX_Controller Initialized
INFO - 2018-05-12 01:52:41 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-12 01:52:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Chapters_model.php
DEBUG - 2018-05-12 01:52:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-12 01:52:41 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-12 01:52:41 --> Login MX_Controller Initialized
DEBUG - 2018-05-12 01:52:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-12 01:52:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-05-12 01:52:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-05-12 01:52:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-05-12 01:52:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-05-12 01:52:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-05-12 01:52:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/chapters/chapters.php
INFO - 2018-05-12 01:52:41 --> Final output sent to browser
DEBUG - 2018-05-12 01:52:41 --> Total execution time: 0.4814
INFO - 2018-05-12 01:52:42 --> Config Class Initialized
INFO - 2018-05-12 01:52:42 --> Hooks Class Initialized
DEBUG - 2018-05-12 01:52:42 --> UTF-8 Support Enabled
INFO - 2018-05-12 01:52:42 --> Utf8 Class Initialized
INFO - 2018-05-12 01:52:42 --> URI Class Initialized
INFO - 2018-05-12 01:52:42 --> Router Class Initialized
INFO - 2018-05-12 01:52:42 --> Output Class Initialized
INFO - 2018-05-12 01:52:42 --> Security Class Initialized
DEBUG - 2018-05-12 01:52:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 01:52:42 --> Input Class Initialized
INFO - 2018-05-12 01:52:42 --> Language Class Initialized
INFO - 2018-05-12 01:52:42 --> Language Class Initialized
INFO - 2018-05-12 01:52:42 --> Config Class Initialized
INFO - 2018-05-12 01:52:42 --> Loader Class Initialized
DEBUG - 2018-05-12 01:52:42 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-12 01:52:42 --> Helper loaded: url_helper
INFO - 2018-05-12 01:52:42 --> Helper loaded: form_helper
INFO - 2018-05-12 01:52:42 --> Helper loaded: date_helper
INFO - 2018-05-12 01:52:42 --> Helper loaded: util_helper
INFO - 2018-05-12 01:52:42 --> Helper loaded: text_helper
INFO - 2018-05-12 01:52:42 --> Helper loaded: string_helper
INFO - 2018-05-12 01:52:42 --> Database Driver Class Initialized
DEBUG - 2018-05-12 01:52:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-12 01:52:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-12 01:52:42 --> Email Class Initialized
INFO - 2018-05-12 01:52:42 --> Controller Class Initialized
DEBUG - 2018-05-12 01:52:42 --> Chapters MX_Controller Initialized
INFO - 2018-05-12 01:52:42 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-12 01:52:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Chapters_model.php
DEBUG - 2018-05-12 01:52:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-12 01:52:42 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-12 01:52:42 --> Login MX_Controller Initialized
DEBUG - 2018-05-12 01:52:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-12 01:52:42 --> Final output sent to browser
DEBUG - 2018-05-12 01:52:42 --> Total execution time: 0.6496
INFO - 2018-05-12 01:52:44 --> Config Class Initialized
INFO - 2018-05-12 01:52:44 --> Hooks Class Initialized
DEBUG - 2018-05-12 01:52:44 --> UTF-8 Support Enabled
INFO - 2018-05-12 01:52:44 --> Utf8 Class Initialized
INFO - 2018-05-12 01:52:44 --> URI Class Initialized
INFO - 2018-05-12 01:52:44 --> Router Class Initialized
INFO - 2018-05-12 01:52:44 --> Output Class Initialized
INFO - 2018-05-12 01:52:44 --> Security Class Initialized
DEBUG - 2018-05-12 01:52:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 01:52:44 --> Input Class Initialized
INFO - 2018-05-12 01:52:44 --> Language Class Initialized
INFO - 2018-05-12 01:52:44 --> Language Class Initialized
INFO - 2018-05-12 01:52:44 --> Config Class Initialized
INFO - 2018-05-12 01:52:44 --> Loader Class Initialized
DEBUG - 2018-05-12 01:52:44 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-12 01:52:44 --> Helper loaded: url_helper
INFO - 2018-05-12 01:52:44 --> Helper loaded: form_helper
INFO - 2018-05-12 01:52:44 --> Helper loaded: date_helper
INFO - 2018-05-12 01:52:44 --> Helper loaded: util_helper
INFO - 2018-05-12 01:52:44 --> Helper loaded: text_helper
INFO - 2018-05-12 01:52:44 --> Helper loaded: string_helper
INFO - 2018-05-12 01:52:44 --> Database Driver Class Initialized
DEBUG - 2018-05-12 01:52:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-12 01:52:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-12 01:52:44 --> Email Class Initialized
INFO - 2018-05-12 01:52:44 --> Controller Class Initialized
DEBUG - 2018-05-12 01:52:44 --> Admin MX_Controller Initialized
INFO - 2018-05-12 01:52:45 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-12 01:52:45 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-12 01:52:45 --> Login MX_Controller Initialized
DEBUG - 2018-05-12 01:52:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-12 01:52:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-12 01:52:45 --> Final output sent to browser
DEBUG - 2018-05-12 01:52:45 --> Total execution time: 0.4645
INFO - 2018-05-12 01:52:47 --> Config Class Initialized
INFO - 2018-05-12 01:52:47 --> Hooks Class Initialized
DEBUG - 2018-05-12 01:52:47 --> UTF-8 Support Enabled
INFO - 2018-05-12 01:52:47 --> Utf8 Class Initialized
INFO - 2018-05-12 01:52:47 --> URI Class Initialized
INFO - 2018-05-12 01:52:47 --> Router Class Initialized
INFO - 2018-05-12 01:52:47 --> Output Class Initialized
INFO - 2018-05-12 01:52:47 --> Security Class Initialized
DEBUG - 2018-05-12 01:52:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 01:52:47 --> Input Class Initialized
INFO - 2018-05-12 01:52:47 --> Language Class Initialized
INFO - 2018-05-12 01:52:47 --> Language Class Initialized
INFO - 2018-05-12 01:52:47 --> Config Class Initialized
INFO - 2018-05-12 01:52:47 --> Loader Class Initialized
DEBUG - 2018-05-12 01:52:47 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-12 01:52:47 --> Helper loaded: url_helper
INFO - 2018-05-12 01:52:47 --> Helper loaded: form_helper
INFO - 2018-05-12 01:52:47 --> Helper loaded: date_helper
INFO - 2018-05-12 01:52:47 --> Helper loaded: util_helper
INFO - 2018-05-12 01:52:47 --> Helper loaded: text_helper
INFO - 2018-05-12 01:52:47 --> Helper loaded: string_helper
INFO - 2018-05-12 01:52:47 --> Database Driver Class Initialized
DEBUG - 2018-05-12 01:52:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-12 01:52:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-12 01:52:47 --> Email Class Initialized
INFO - 2018-05-12 01:52:47 --> Controller Class Initialized
DEBUG - 2018-05-12 01:52:47 --> Programs MX_Controller Initialized
INFO - 2018-05-12 01:52:47 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-12 01:52:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-05-12 01:52:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-12 01:52:47 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-12 01:52:47 --> Login MX_Controller Initialized
DEBUG - 2018-05-12 01:52:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-12 01:52:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-05-12 01:52:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-05-12 01:52:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-05-12 01:52:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-05-12 01:52:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-05-12 01:52:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/programs/programs.php
INFO - 2018-05-12 01:52:48 --> Final output sent to browser
DEBUG - 2018-05-12 01:52:48 --> Total execution time: 0.6521
INFO - 2018-05-12 01:52:48 --> Config Class Initialized
INFO - 2018-05-12 01:52:48 --> Hooks Class Initialized
DEBUG - 2018-05-12 01:52:48 --> UTF-8 Support Enabled
INFO - 2018-05-12 01:52:48 --> Utf8 Class Initialized
INFO - 2018-05-12 01:52:48 --> URI Class Initialized
INFO - 2018-05-12 01:52:48 --> Router Class Initialized
INFO - 2018-05-12 01:52:48 --> Output Class Initialized
INFO - 2018-05-12 01:52:48 --> Security Class Initialized
DEBUG - 2018-05-12 01:52:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 01:52:48 --> Input Class Initialized
INFO - 2018-05-12 01:52:48 --> Language Class Initialized
INFO - 2018-05-12 01:52:48 --> Language Class Initialized
INFO - 2018-05-12 01:52:48 --> Config Class Initialized
INFO - 2018-05-12 01:52:48 --> Loader Class Initialized
DEBUG - 2018-05-12 01:52:48 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-12 01:52:48 --> Helper loaded: url_helper
INFO - 2018-05-12 01:52:48 --> Helper loaded: form_helper
INFO - 2018-05-12 01:52:48 --> Helper loaded: date_helper
INFO - 2018-05-12 01:52:48 --> Helper loaded: util_helper
INFO - 2018-05-12 01:52:48 --> Helper loaded: text_helper
INFO - 2018-05-12 01:52:48 --> Helper loaded: string_helper
INFO - 2018-05-12 01:52:48 --> Database Driver Class Initialized
DEBUG - 2018-05-12 01:52:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-12 01:52:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-12 01:52:48 --> Email Class Initialized
INFO - 2018-05-12 01:52:48 --> Controller Class Initialized
DEBUG - 2018-05-12 01:52:48 --> Programs MX_Controller Initialized
INFO - 2018-05-12 01:52:48 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-12 01:52:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-05-12 01:52:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-12 01:52:48 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-12 01:52:48 --> Login MX_Controller Initialized
DEBUG - 2018-05-12 01:52:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-12 01:52:48 --> Final output sent to browser
DEBUG - 2018-05-12 01:52:48 --> Total execution time: 0.5442
INFO - 2018-05-12 01:52:50 --> Config Class Initialized
INFO - 2018-05-12 01:52:50 --> Hooks Class Initialized
DEBUG - 2018-05-12 01:52:50 --> UTF-8 Support Enabled
INFO - 2018-05-12 01:52:50 --> Utf8 Class Initialized
INFO - 2018-05-12 01:52:50 --> URI Class Initialized
INFO - 2018-05-12 01:52:50 --> Router Class Initialized
INFO - 2018-05-12 01:52:50 --> Output Class Initialized
INFO - 2018-05-12 01:52:50 --> Security Class Initialized
DEBUG - 2018-05-12 01:52:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 01:52:50 --> Input Class Initialized
INFO - 2018-05-12 01:52:50 --> Language Class Initialized
INFO - 2018-05-12 01:52:50 --> Language Class Initialized
INFO - 2018-05-12 01:52:50 --> Config Class Initialized
INFO - 2018-05-12 01:52:50 --> Loader Class Initialized
DEBUG - 2018-05-12 01:52:50 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-12 01:52:50 --> Helper loaded: url_helper
INFO - 2018-05-12 01:52:50 --> Helper loaded: form_helper
INFO - 2018-05-12 01:52:50 --> Helper loaded: date_helper
INFO - 2018-05-12 01:52:50 --> Helper loaded: util_helper
INFO - 2018-05-12 01:52:50 --> Helper loaded: text_helper
INFO - 2018-05-12 01:52:50 --> Helper loaded: string_helper
INFO - 2018-05-12 01:52:50 --> Database Driver Class Initialized
DEBUG - 2018-05-12 01:52:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-12 01:52:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-12 01:52:50 --> Email Class Initialized
INFO - 2018-05-12 01:52:50 --> Controller Class Initialized
DEBUG - 2018-05-12 01:52:50 --> Chapters MX_Controller Initialized
INFO - 2018-05-12 01:52:50 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-12 01:52:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Chapters_model.php
DEBUG - 2018-05-12 01:52:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-12 01:52:50 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-12 01:52:50 --> Login MX_Controller Initialized
DEBUG - 2018-05-12 01:52:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-12 01:52:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-05-12 01:52:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-05-12 01:52:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-05-12 01:52:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-05-12 01:52:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-05-12 01:52:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/chapters/chapters.php
INFO - 2018-05-12 01:52:50 --> Final output sent to browser
DEBUG - 2018-05-12 01:52:50 --> Total execution time: 0.4873
INFO - 2018-05-12 01:52:51 --> Config Class Initialized
INFO - 2018-05-12 01:52:51 --> Hooks Class Initialized
DEBUG - 2018-05-12 01:52:51 --> UTF-8 Support Enabled
INFO - 2018-05-12 01:52:51 --> Utf8 Class Initialized
INFO - 2018-05-12 01:52:51 --> URI Class Initialized
INFO - 2018-05-12 01:52:51 --> Router Class Initialized
INFO - 2018-05-12 01:52:51 --> Output Class Initialized
INFO - 2018-05-12 01:52:51 --> Security Class Initialized
DEBUG - 2018-05-12 01:52:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 01:52:51 --> Input Class Initialized
INFO - 2018-05-12 01:52:51 --> Language Class Initialized
INFO - 2018-05-12 01:52:51 --> Language Class Initialized
INFO - 2018-05-12 01:52:51 --> Config Class Initialized
INFO - 2018-05-12 01:52:51 --> Loader Class Initialized
DEBUG - 2018-05-12 01:52:51 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-12 01:52:51 --> Helper loaded: url_helper
INFO - 2018-05-12 01:52:51 --> Helper loaded: form_helper
INFO - 2018-05-12 01:52:51 --> Helper loaded: date_helper
INFO - 2018-05-12 01:52:51 --> Helper loaded: util_helper
INFO - 2018-05-12 01:52:51 --> Helper loaded: text_helper
INFO - 2018-05-12 01:52:51 --> Helper loaded: string_helper
INFO - 2018-05-12 01:52:51 --> Database Driver Class Initialized
DEBUG - 2018-05-12 01:52:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-12 01:52:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-12 01:52:51 --> Email Class Initialized
INFO - 2018-05-12 01:52:51 --> Controller Class Initialized
DEBUG - 2018-05-12 01:52:51 --> Chapters MX_Controller Initialized
INFO - 2018-05-12 01:52:51 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-12 01:52:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Chapters_model.php
DEBUG - 2018-05-12 01:52:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-12 01:52:51 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-12 01:52:51 --> Login MX_Controller Initialized
DEBUG - 2018-05-12 01:52:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-12 01:52:51 --> Final output sent to browser
DEBUG - 2018-05-12 01:52:51 --> Total execution time: 0.5645
INFO - 2018-05-12 02:01:16 --> Config Class Initialized
INFO - 2018-05-12 02:01:16 --> Hooks Class Initialized
DEBUG - 2018-05-12 02:01:16 --> UTF-8 Support Enabled
INFO - 2018-05-12 02:01:16 --> Utf8 Class Initialized
INFO - 2018-05-12 02:01:16 --> URI Class Initialized
INFO - 2018-05-12 02:01:16 --> Router Class Initialized
INFO - 2018-05-12 02:01:16 --> Output Class Initialized
INFO - 2018-05-12 02:01:16 --> Security Class Initialized
DEBUG - 2018-05-12 02:01:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 02:01:16 --> Input Class Initialized
INFO - 2018-05-12 02:01:16 --> Language Class Initialized
INFO - 2018-05-12 02:01:16 --> Language Class Initialized
INFO - 2018-05-12 02:01:16 --> Config Class Initialized
INFO - 2018-05-12 02:01:16 --> Loader Class Initialized
DEBUG - 2018-05-12 02:01:16 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-12 02:01:16 --> Helper loaded: url_helper
INFO - 2018-05-12 02:01:16 --> Helper loaded: form_helper
INFO - 2018-05-12 02:01:16 --> Helper loaded: date_helper
INFO - 2018-05-12 02:01:16 --> Helper loaded: util_helper
INFO - 2018-05-12 02:01:16 --> Helper loaded: text_helper
INFO - 2018-05-12 02:01:16 --> Helper loaded: string_helper
INFO - 2018-05-12 02:01:16 --> Database Driver Class Initialized
DEBUG - 2018-05-12 02:01:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-12 02:01:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-12 02:01:16 --> Email Class Initialized
INFO - 2018-05-12 02:01:16 --> Controller Class Initialized
ERROR - 2018-05-12 02:01:16 --> 404 Page Not Found: ../modules/admin/controllers/Videos/index
INFO - 2018-05-12 02:01:23 --> Config Class Initialized
INFO - 2018-05-12 02:01:23 --> Hooks Class Initialized
DEBUG - 2018-05-12 02:01:23 --> UTF-8 Support Enabled
INFO - 2018-05-12 02:01:23 --> Utf8 Class Initialized
INFO - 2018-05-12 02:01:23 --> URI Class Initialized
INFO - 2018-05-12 02:01:23 --> Router Class Initialized
INFO - 2018-05-12 02:01:23 --> Output Class Initialized
INFO - 2018-05-12 02:01:23 --> Security Class Initialized
DEBUG - 2018-05-12 02:01:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 02:01:23 --> Input Class Initialized
INFO - 2018-05-12 02:01:23 --> Language Class Initialized
INFO - 2018-05-12 02:01:23 --> Language Class Initialized
INFO - 2018-05-12 02:01:23 --> Config Class Initialized
INFO - 2018-05-12 02:01:23 --> Loader Class Initialized
DEBUG - 2018-05-12 02:01:23 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-12 02:01:23 --> Helper loaded: url_helper
INFO - 2018-05-12 02:01:23 --> Helper loaded: form_helper
INFO - 2018-05-12 02:01:23 --> Helper loaded: date_helper
INFO - 2018-05-12 02:01:23 --> Helper loaded: util_helper
INFO - 2018-05-12 02:01:23 --> Helper loaded: text_helper
INFO - 2018-05-12 02:01:23 --> Helper loaded: string_helper
INFO - 2018-05-12 02:01:23 --> Database Driver Class Initialized
DEBUG - 2018-05-12 02:01:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-12 02:01:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-12 02:01:23 --> Email Class Initialized
INFO - 2018-05-12 02:01:23 --> Controller Class Initialized
ERROR - 2018-05-12 02:01:23 --> 404 Page Not Found: ../modules/admin/controllers/Videos/index
INFO - 2018-05-12 02:08:40 --> Config Class Initialized
INFO - 2018-05-12 02:08:40 --> Hooks Class Initialized
DEBUG - 2018-05-12 02:08:40 --> UTF-8 Support Enabled
INFO - 2018-05-12 02:08:40 --> Utf8 Class Initialized
INFO - 2018-05-12 02:08:40 --> URI Class Initialized
INFO - 2018-05-12 02:08:40 --> Router Class Initialized
INFO - 2018-05-12 02:08:40 --> Output Class Initialized
INFO - 2018-05-12 02:08:40 --> Security Class Initialized
DEBUG - 2018-05-12 02:08:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 02:08:40 --> Input Class Initialized
INFO - 2018-05-12 02:08:40 --> Language Class Initialized
INFO - 2018-05-12 02:08:40 --> Language Class Initialized
INFO - 2018-05-12 02:08:40 --> Config Class Initialized
INFO - 2018-05-12 02:08:40 --> Loader Class Initialized
DEBUG - 2018-05-12 02:08:40 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-12 02:08:40 --> Helper loaded: url_helper
INFO - 2018-05-12 02:08:40 --> Helper loaded: form_helper
INFO - 2018-05-12 02:08:40 --> Helper loaded: date_helper
INFO - 2018-05-12 02:08:40 --> Helper loaded: util_helper
INFO - 2018-05-12 02:08:40 --> Helper loaded: text_helper
INFO - 2018-05-12 02:08:40 --> Helper loaded: string_helper
INFO - 2018-05-12 02:08:40 --> Database Driver Class Initialized
DEBUG - 2018-05-12 02:08:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-12 02:08:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-12 02:08:40 --> Email Class Initialized
INFO - 2018-05-12 02:08:40 --> Controller Class Initialized
ERROR - 2018-05-12 02:08:40 --> 404 Page Not Found: ../modules/admin/controllers/Videos/index
INFO - 2018-05-12 02:10:51 --> Config Class Initialized
INFO - 2018-05-12 02:10:52 --> Hooks Class Initialized
DEBUG - 2018-05-12 02:10:52 --> UTF-8 Support Enabled
INFO - 2018-05-12 02:10:52 --> Utf8 Class Initialized
INFO - 2018-05-12 02:10:52 --> URI Class Initialized
INFO - 2018-05-12 02:10:52 --> Router Class Initialized
INFO - 2018-05-12 02:10:52 --> Output Class Initialized
INFO - 2018-05-12 02:10:52 --> Security Class Initialized
DEBUG - 2018-05-12 02:10:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 02:10:52 --> Input Class Initialized
INFO - 2018-05-12 02:10:52 --> Language Class Initialized
INFO - 2018-05-12 02:10:52 --> Language Class Initialized
INFO - 2018-05-12 02:10:52 --> Config Class Initialized
INFO - 2018-05-12 02:10:52 --> Loader Class Initialized
DEBUG - 2018-05-12 02:10:52 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-12 02:10:52 --> Helper loaded: url_helper
INFO - 2018-05-12 02:10:52 --> Helper loaded: form_helper
INFO - 2018-05-12 02:10:52 --> Helper loaded: date_helper
INFO - 2018-05-12 02:10:52 --> Helper loaded: util_helper
INFO - 2018-05-12 02:10:52 --> Helper loaded: text_helper
INFO - 2018-05-12 02:10:52 --> Helper loaded: string_helper
INFO - 2018-05-12 02:10:52 --> Database Driver Class Initialized
DEBUG - 2018-05-12 02:10:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-12 02:10:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-12 02:10:52 --> Email Class Initialized
INFO - 2018-05-12 02:10:52 --> Controller Class Initialized
DEBUG - 2018-05-12 02:10:52 --> videos MX_Controller Initialized
INFO - 2018-05-12 02:10:52 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-12 02:10:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-05-12 02:10:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-12 02:10:52 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-12 02:10:52 --> Login MX_Controller Initialized
DEBUG - 2018-05-12 02:10:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-12 02:10:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-05-12 02:10:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-05-12 02:10:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-05-12 02:10:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-05-12 02:10:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-05-12 02:10:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/videos/videos.php
INFO - 2018-05-12 02:10:52 --> Final output sent to browser
DEBUG - 2018-05-12 02:10:52 --> Total execution time: 0.5254
INFO - 2018-05-12 02:10:53 --> Config Class Initialized
INFO - 2018-05-12 02:10:53 --> Hooks Class Initialized
DEBUG - 2018-05-12 02:10:53 --> UTF-8 Support Enabled
INFO - 2018-05-12 02:10:53 --> Utf8 Class Initialized
INFO - 2018-05-12 02:10:53 --> URI Class Initialized
INFO - 2018-05-12 02:10:53 --> Router Class Initialized
INFO - 2018-05-12 02:10:53 --> Output Class Initialized
INFO - 2018-05-12 02:10:53 --> Security Class Initialized
DEBUG - 2018-05-12 02:10:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 02:10:53 --> Input Class Initialized
INFO - 2018-05-12 02:10:53 --> Language Class Initialized
INFO - 2018-05-12 02:10:53 --> Language Class Initialized
INFO - 2018-05-12 02:10:53 --> Config Class Initialized
INFO - 2018-05-12 02:10:53 --> Loader Class Initialized
DEBUG - 2018-05-12 02:10:53 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-12 02:10:53 --> Helper loaded: url_helper
INFO - 2018-05-12 02:10:53 --> Helper loaded: form_helper
INFO - 2018-05-12 02:10:53 --> Helper loaded: date_helper
INFO - 2018-05-12 02:10:53 --> Helper loaded: util_helper
INFO - 2018-05-12 02:10:53 --> Helper loaded: text_helper
INFO - 2018-05-12 02:10:53 --> Helper loaded: string_helper
INFO - 2018-05-12 02:10:53 --> Database Driver Class Initialized
DEBUG - 2018-05-12 02:10:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-12 02:10:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-12 02:10:53 --> Email Class Initialized
INFO - 2018-05-12 02:10:53 --> Controller Class Initialized
DEBUG - 2018-05-12 02:10:53 --> Chapters MX_Controller Initialized
INFO - 2018-05-12 02:10:53 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-12 02:10:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Chapters_model.php
DEBUG - 2018-05-12 02:10:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-12 02:10:53 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-12 02:10:53 --> Login MX_Controller Initialized
DEBUG - 2018-05-12 02:10:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-12 02:10:53 --> Final output sent to browser
DEBUG - 2018-05-12 02:10:53 --> Total execution time: 0.5863
INFO - 2018-05-12 02:11:11 --> Config Class Initialized
INFO - 2018-05-12 02:11:11 --> Hooks Class Initialized
DEBUG - 2018-05-12 02:11:11 --> UTF-8 Support Enabled
INFO - 2018-05-12 02:11:11 --> Utf8 Class Initialized
INFO - 2018-05-12 02:11:11 --> URI Class Initialized
INFO - 2018-05-12 02:11:11 --> Router Class Initialized
INFO - 2018-05-12 02:11:11 --> Output Class Initialized
INFO - 2018-05-12 02:11:11 --> Security Class Initialized
DEBUG - 2018-05-12 02:11:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 02:11:11 --> Input Class Initialized
INFO - 2018-05-12 02:11:11 --> Language Class Initialized
INFO - 2018-05-12 02:11:11 --> Language Class Initialized
INFO - 2018-05-12 02:11:11 --> Config Class Initialized
INFO - 2018-05-12 02:11:11 --> Loader Class Initialized
DEBUG - 2018-05-12 02:11:11 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-12 02:11:11 --> Helper loaded: url_helper
INFO - 2018-05-12 02:11:11 --> Helper loaded: form_helper
INFO - 2018-05-12 02:11:11 --> Helper loaded: date_helper
INFO - 2018-05-12 02:11:12 --> Helper loaded: util_helper
INFO - 2018-05-12 02:11:12 --> Helper loaded: text_helper
INFO - 2018-05-12 02:11:12 --> Helper loaded: string_helper
INFO - 2018-05-12 02:11:12 --> Database Driver Class Initialized
DEBUG - 2018-05-12 02:11:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-12 02:11:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-12 02:11:12 --> Email Class Initialized
INFO - 2018-05-12 02:11:12 --> Controller Class Initialized
DEBUG - 2018-05-12 02:11:12 --> videos MX_Controller Initialized
INFO - 2018-05-12 02:11:12 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-12 02:11:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-05-12 02:11:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-12 02:11:12 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-12 02:11:12 --> Login MX_Controller Initialized
DEBUG - 2018-05-12 02:11:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-12 02:11:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-05-12 02:11:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-05-12 02:11:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-05-12 02:11:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-05-12 02:11:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-05-12 02:11:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/videos/videos.php
INFO - 2018-05-12 02:11:12 --> Final output sent to browser
DEBUG - 2018-05-12 02:11:12 --> Total execution time: 0.5275
INFO - 2018-05-12 02:11:12 --> Config Class Initialized
INFO - 2018-05-12 02:11:12 --> Hooks Class Initialized
DEBUG - 2018-05-12 02:11:12 --> UTF-8 Support Enabled
INFO - 2018-05-12 02:11:12 --> Utf8 Class Initialized
INFO - 2018-05-12 02:11:12 --> URI Class Initialized
INFO - 2018-05-12 02:11:12 --> Router Class Initialized
INFO - 2018-05-12 02:11:13 --> Output Class Initialized
INFO - 2018-05-12 02:11:13 --> Security Class Initialized
DEBUG - 2018-05-12 02:11:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 02:11:13 --> Input Class Initialized
INFO - 2018-05-12 02:11:13 --> Language Class Initialized
INFO - 2018-05-12 02:11:13 --> Language Class Initialized
INFO - 2018-05-12 02:11:13 --> Config Class Initialized
INFO - 2018-05-12 02:11:13 --> Loader Class Initialized
DEBUG - 2018-05-12 02:11:13 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-12 02:11:13 --> Helper loaded: url_helper
INFO - 2018-05-12 02:11:13 --> Helper loaded: form_helper
INFO - 2018-05-12 02:11:13 --> Helper loaded: date_helper
INFO - 2018-05-12 02:11:13 --> Helper loaded: util_helper
INFO - 2018-05-12 02:11:13 --> Helper loaded: text_helper
INFO - 2018-05-12 02:11:13 --> Helper loaded: string_helper
INFO - 2018-05-12 02:11:13 --> Database Driver Class Initialized
DEBUG - 2018-05-12 02:11:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-12 02:11:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-12 02:11:13 --> Email Class Initialized
INFO - 2018-05-12 02:11:13 --> Controller Class Initialized
DEBUG - 2018-05-12 02:11:13 --> Chapters MX_Controller Initialized
INFO - 2018-05-12 02:11:13 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-12 02:11:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Chapters_model.php
DEBUG - 2018-05-12 02:11:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-12 02:11:13 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-12 02:11:13 --> Login MX_Controller Initialized
DEBUG - 2018-05-12 02:11:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-12 02:11:13 --> Final output sent to browser
DEBUG - 2018-05-12 02:11:13 --> Total execution time: 0.5561
INFO - 2018-05-12 02:11:40 --> Config Class Initialized
INFO - 2018-05-12 02:11:40 --> Hooks Class Initialized
DEBUG - 2018-05-12 02:11:40 --> UTF-8 Support Enabled
INFO - 2018-05-12 02:11:40 --> Utf8 Class Initialized
INFO - 2018-05-12 02:11:40 --> URI Class Initialized
INFO - 2018-05-12 02:11:40 --> Router Class Initialized
INFO - 2018-05-12 02:11:40 --> Output Class Initialized
INFO - 2018-05-12 02:11:40 --> Security Class Initialized
DEBUG - 2018-05-12 02:11:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 02:11:40 --> Input Class Initialized
INFO - 2018-05-12 02:11:40 --> Language Class Initialized
INFO - 2018-05-12 02:11:40 --> Language Class Initialized
INFO - 2018-05-12 02:11:40 --> Config Class Initialized
INFO - 2018-05-12 02:11:40 --> Loader Class Initialized
DEBUG - 2018-05-12 02:11:40 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-12 02:11:40 --> Helper loaded: url_helper
INFO - 2018-05-12 02:11:40 --> Helper loaded: form_helper
INFO - 2018-05-12 02:11:40 --> Helper loaded: date_helper
INFO - 2018-05-12 02:11:40 --> Helper loaded: util_helper
INFO - 2018-05-12 02:11:40 --> Helper loaded: text_helper
INFO - 2018-05-12 02:11:40 --> Helper loaded: string_helper
INFO - 2018-05-12 02:11:40 --> Database Driver Class Initialized
DEBUG - 2018-05-12 02:11:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-12 02:11:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-12 02:11:40 --> Email Class Initialized
INFO - 2018-05-12 02:11:40 --> Controller Class Initialized
DEBUG - 2018-05-12 02:11:40 --> videos MX_Controller Initialized
INFO - 2018-05-12 02:11:40 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-12 02:11:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-05-12 02:11:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-12 02:11:40 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-12 02:11:40 --> Login MX_Controller Initialized
DEBUG - 2018-05-12 02:11:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-12 02:11:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-05-12 02:11:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-05-12 02:11:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-05-12 02:11:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-05-12 02:11:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-05-12 02:11:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/videos/videos.php
INFO - 2018-05-12 02:11:40 --> Final output sent to browser
DEBUG - 2018-05-12 02:11:41 --> Total execution time: 0.5214
INFO - 2018-05-12 02:11:41 --> Config Class Initialized
INFO - 2018-05-12 02:11:41 --> Hooks Class Initialized
DEBUG - 2018-05-12 02:11:41 --> UTF-8 Support Enabled
INFO - 2018-05-12 02:11:41 --> Utf8 Class Initialized
INFO - 2018-05-12 02:11:41 --> URI Class Initialized
INFO - 2018-05-12 02:11:41 --> Router Class Initialized
INFO - 2018-05-12 02:11:41 --> Output Class Initialized
INFO - 2018-05-12 02:11:41 --> Security Class Initialized
DEBUG - 2018-05-12 02:11:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 02:11:41 --> Input Class Initialized
INFO - 2018-05-12 02:11:41 --> Language Class Initialized
INFO - 2018-05-12 02:11:42 --> Language Class Initialized
INFO - 2018-05-12 02:11:42 --> Config Class Initialized
INFO - 2018-05-12 02:11:42 --> Loader Class Initialized
DEBUG - 2018-05-12 02:11:42 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-12 02:11:42 --> Helper loaded: url_helper
INFO - 2018-05-12 02:11:42 --> Helper loaded: form_helper
INFO - 2018-05-12 02:11:42 --> Helper loaded: date_helper
INFO - 2018-05-12 02:11:42 --> Helper loaded: util_helper
INFO - 2018-05-12 02:11:42 --> Helper loaded: text_helper
INFO - 2018-05-12 02:11:42 --> Helper loaded: string_helper
INFO - 2018-05-12 02:11:42 --> Database Driver Class Initialized
DEBUG - 2018-05-12 02:11:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-12 02:11:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-12 02:11:42 --> Email Class Initialized
INFO - 2018-05-12 02:11:42 --> Controller Class Initialized
DEBUG - 2018-05-12 02:11:42 --> videos MX_Controller Initialized
INFO - 2018-05-12 02:11:42 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-12 02:11:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-05-12 02:11:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-12 02:11:42 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-12 02:11:42 --> Login MX_Controller Initialized
DEBUG - 2018-05-12 02:11:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
ERROR - 2018-05-12 02:11:42 --> Query error: Table 'consulting.videos' doesn't exist - Invalid query: SELECT  videos.video_id,videos.video_name,chapters.chapter_name,videos.added_date,videos.status,videos.video_id FROM   videos left join chapters on videos.chapter_id = chapters.chapter_id  WHERE videos.video_id!= ''     LIMIT 0, 10
INFO - 2018-05-12 02:11:42 --> Language file loaded: language/english/db_lang.php
INFO - 2018-05-12 02:11:48 --> Config Class Initialized
INFO - 2018-05-12 02:11:48 --> Hooks Class Initialized
DEBUG - 2018-05-12 02:11:48 --> UTF-8 Support Enabled
INFO - 2018-05-12 02:11:48 --> Utf8 Class Initialized
INFO - 2018-05-12 02:11:48 --> URI Class Initialized
INFO - 2018-05-12 02:11:48 --> Router Class Initialized
INFO - 2018-05-12 02:11:48 --> Output Class Initialized
INFO - 2018-05-12 02:11:48 --> Security Class Initialized
DEBUG - 2018-05-12 02:11:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 02:11:48 --> Input Class Initialized
INFO - 2018-05-12 02:11:48 --> Language Class Initialized
INFO - 2018-05-12 02:11:48 --> Language Class Initialized
INFO - 2018-05-12 02:11:48 --> Config Class Initialized
INFO - 2018-05-12 02:11:48 --> Loader Class Initialized
DEBUG - 2018-05-12 02:11:49 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-12 02:11:49 --> Helper loaded: url_helper
INFO - 2018-05-12 02:11:49 --> Helper loaded: form_helper
INFO - 2018-05-12 02:11:49 --> Helper loaded: date_helper
INFO - 2018-05-12 02:11:49 --> Helper loaded: util_helper
INFO - 2018-05-12 02:11:49 --> Helper loaded: text_helper
INFO - 2018-05-12 02:11:49 --> Helper loaded: string_helper
INFO - 2018-05-12 02:11:49 --> Database Driver Class Initialized
DEBUG - 2018-05-12 02:11:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-12 02:11:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-12 02:11:49 --> Email Class Initialized
INFO - 2018-05-12 02:11:49 --> Controller Class Initialized
DEBUG - 2018-05-12 02:11:49 --> videos MX_Controller Initialized
INFO - 2018-05-12 02:11:49 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-12 02:11:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-05-12 02:11:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-12 02:11:49 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-12 02:11:49 --> Login MX_Controller Initialized
DEBUG - 2018-05-12 02:11:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
ERROR - 2018-05-12 02:11:49 --> Query error: Table 'consulting.videos' doesn't exist - Invalid query: SELECT  videos.video_id,videos.video_name,chapters.chapter_name,videos.added_date,videos.status,videos.video_id FROM   videos left join chapters on videos.chapter_id = chapters.chapter_id  WHERE videos.video_id!= ''    ORDER BY  videos.video_name asc LIMIT 0, 10
INFO - 2018-05-12 02:11:49 --> Language file loaded: language/english/db_lang.php
INFO - 2018-05-12 02:11:52 --> Config Class Initialized
INFO - 2018-05-12 02:11:52 --> Hooks Class Initialized
DEBUG - 2018-05-12 02:11:53 --> UTF-8 Support Enabled
INFO - 2018-05-12 02:11:53 --> Utf8 Class Initialized
INFO - 2018-05-12 02:11:53 --> URI Class Initialized
INFO - 2018-05-12 02:11:53 --> Router Class Initialized
INFO - 2018-05-12 02:11:53 --> Output Class Initialized
INFO - 2018-05-12 02:11:53 --> Security Class Initialized
DEBUG - 2018-05-12 02:11:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 02:11:53 --> Input Class Initialized
INFO - 2018-05-12 02:11:53 --> Language Class Initialized
INFO - 2018-05-12 02:11:53 --> Language Class Initialized
INFO - 2018-05-12 02:11:53 --> Config Class Initialized
INFO - 2018-05-12 02:11:53 --> Loader Class Initialized
DEBUG - 2018-05-12 02:11:53 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-12 02:11:53 --> Helper loaded: url_helper
INFO - 2018-05-12 02:11:53 --> Helper loaded: form_helper
INFO - 2018-05-12 02:11:53 --> Helper loaded: date_helper
INFO - 2018-05-12 02:11:53 --> Helper loaded: util_helper
INFO - 2018-05-12 02:11:53 --> Helper loaded: text_helper
INFO - 2018-05-12 02:11:53 --> Helper loaded: string_helper
INFO - 2018-05-12 02:11:53 --> Database Driver Class Initialized
DEBUG - 2018-05-12 02:11:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-12 02:11:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-12 02:11:53 --> Email Class Initialized
INFO - 2018-05-12 02:11:53 --> Controller Class Initialized
DEBUG - 2018-05-12 02:11:53 --> videos MX_Controller Initialized
INFO - 2018-05-12 02:11:53 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-12 02:11:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-05-12 02:11:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-12 02:11:53 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-12 02:11:53 --> Login MX_Controller Initialized
DEBUG - 2018-05-12 02:11:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
ERROR - 2018-05-12 02:11:53 --> Query error: Table 'consulting.videos' doesn't exist - Invalid query: SELECT  videos.video_id,videos.video_name,chapters.chapter_name,videos.added_date,videos.status,videos.video_id FROM   videos left join chapters on videos.chapter_id = chapters.chapter_id  WHERE videos.video_id!= ''     
INFO - 2018-05-12 02:11:53 --> Language file loaded: language/english/db_lang.php
INFO - 2018-05-12 02:12:11 --> Config Class Initialized
INFO - 2018-05-12 02:12:11 --> Hooks Class Initialized
DEBUG - 2018-05-12 02:12:11 --> UTF-8 Support Enabled
INFO - 2018-05-12 02:12:11 --> Utf8 Class Initialized
INFO - 2018-05-12 02:12:11 --> URI Class Initialized
INFO - 2018-05-12 02:12:11 --> Router Class Initialized
INFO - 2018-05-12 02:12:11 --> Output Class Initialized
INFO - 2018-05-12 02:12:11 --> Security Class Initialized
DEBUG - 2018-05-12 02:12:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 02:12:11 --> Input Class Initialized
INFO - 2018-05-12 02:12:11 --> Language Class Initialized
INFO - 2018-05-12 02:12:11 --> Language Class Initialized
INFO - 2018-05-12 02:12:11 --> Config Class Initialized
INFO - 2018-05-12 02:12:11 --> Loader Class Initialized
DEBUG - 2018-05-12 02:12:11 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-12 02:12:11 --> Helper loaded: url_helper
INFO - 2018-05-12 02:12:11 --> Helper loaded: form_helper
INFO - 2018-05-12 02:12:11 --> Helper loaded: date_helper
INFO - 2018-05-12 02:12:11 --> Helper loaded: util_helper
INFO - 2018-05-12 02:12:11 --> Helper loaded: text_helper
INFO - 2018-05-12 02:12:11 --> Helper loaded: string_helper
INFO - 2018-05-12 02:12:11 --> Database Driver Class Initialized
DEBUG - 2018-05-12 02:12:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-12 02:12:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-12 02:12:11 --> Email Class Initialized
INFO - 2018-05-12 02:12:11 --> Controller Class Initialized
DEBUG - 2018-05-12 02:12:11 --> videos MX_Controller Initialized
INFO - 2018-05-12 02:12:11 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-12 02:12:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-05-12 02:12:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-12 02:12:11 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-12 02:12:11 --> Login MX_Controller Initialized
DEBUG - 2018-05-12 02:12:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
ERROR - 2018-05-12 02:12:11 --> Severity: Notice --> Undefined index: sEcho E:\xampp\htdocs\consulting\system\database\DB_query_builder.php 2920
INFO - 2018-05-12 02:12:11 --> Final output sent to browser
DEBUG - 2018-05-12 02:12:11 --> Total execution time: 0.5408
INFO - 2018-05-12 02:12:15 --> Config Class Initialized
INFO - 2018-05-12 02:12:15 --> Hooks Class Initialized
DEBUG - 2018-05-12 02:12:15 --> UTF-8 Support Enabled
INFO - 2018-05-12 02:12:15 --> Utf8 Class Initialized
INFO - 2018-05-12 02:12:15 --> URI Class Initialized
INFO - 2018-05-12 02:12:15 --> Router Class Initialized
INFO - 2018-05-12 02:12:15 --> Output Class Initialized
INFO - 2018-05-12 02:12:15 --> Security Class Initialized
DEBUG - 2018-05-12 02:12:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 02:12:15 --> Input Class Initialized
INFO - 2018-05-12 02:12:15 --> Language Class Initialized
INFO - 2018-05-12 02:12:15 --> Language Class Initialized
INFO - 2018-05-12 02:12:15 --> Config Class Initialized
INFO - 2018-05-12 02:12:15 --> Loader Class Initialized
DEBUG - 2018-05-12 02:12:15 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-12 02:12:15 --> Helper loaded: url_helper
INFO - 2018-05-12 02:12:15 --> Helper loaded: form_helper
INFO - 2018-05-12 02:12:15 --> Helper loaded: date_helper
INFO - 2018-05-12 02:12:15 --> Helper loaded: util_helper
INFO - 2018-05-12 02:12:15 --> Helper loaded: text_helper
INFO - 2018-05-12 02:12:15 --> Helper loaded: string_helper
INFO - 2018-05-12 02:12:15 --> Database Driver Class Initialized
DEBUG - 2018-05-12 02:12:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-12 02:12:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-12 02:12:15 --> Email Class Initialized
INFO - 2018-05-12 02:12:15 --> Controller Class Initialized
DEBUG - 2018-05-12 02:12:15 --> videos MX_Controller Initialized
INFO - 2018-05-12 02:12:15 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-12 02:12:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-05-12 02:12:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-12 02:12:15 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-12 02:12:15 --> Login MX_Controller Initialized
DEBUG - 2018-05-12 02:12:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-12 02:12:15 --> Final output sent to browser
DEBUG - 2018-05-12 02:12:15 --> Total execution time: 0.5318
INFO - 2018-05-12 02:12:46 --> Config Class Initialized
INFO - 2018-05-12 02:12:46 --> Hooks Class Initialized
DEBUG - 2018-05-12 02:12:46 --> UTF-8 Support Enabled
INFO - 2018-05-12 02:12:46 --> Utf8 Class Initialized
INFO - 2018-05-12 02:12:46 --> URI Class Initialized
INFO - 2018-05-12 02:12:46 --> Router Class Initialized
INFO - 2018-05-12 02:12:46 --> Output Class Initialized
INFO - 2018-05-12 02:12:46 --> Security Class Initialized
DEBUG - 2018-05-12 02:12:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 02:12:46 --> Input Class Initialized
INFO - 2018-05-12 02:12:46 --> Language Class Initialized
INFO - 2018-05-12 02:12:46 --> Language Class Initialized
INFO - 2018-05-12 02:12:46 --> Config Class Initialized
INFO - 2018-05-12 02:12:46 --> Loader Class Initialized
DEBUG - 2018-05-12 02:12:46 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-12 02:12:46 --> Helper loaded: url_helper
INFO - 2018-05-12 02:12:46 --> Helper loaded: form_helper
INFO - 2018-05-12 02:12:46 --> Helper loaded: date_helper
INFO - 2018-05-12 02:12:46 --> Helper loaded: util_helper
INFO - 2018-05-12 02:12:46 --> Helper loaded: text_helper
INFO - 2018-05-12 02:12:46 --> Helper loaded: string_helper
INFO - 2018-05-12 02:12:46 --> Database Driver Class Initialized
DEBUG - 2018-05-12 02:12:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-12 02:12:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-12 02:12:46 --> Email Class Initialized
INFO - 2018-05-12 02:12:46 --> Controller Class Initialized
DEBUG - 2018-05-12 02:12:46 --> videos MX_Controller Initialized
INFO - 2018-05-12 02:12:46 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-12 02:12:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-05-12 02:12:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-12 02:12:46 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-12 02:12:46 --> Login MX_Controller Initialized
DEBUG - 2018-05-12 02:12:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
ERROR - 2018-05-12 02:12:46 --> Severity: Notice --> Undefined index: video_id E:\xampp\htdocs\consulting\application\modules\admin\controllers\Videos.php 79
DEBUG - 2018-05-12 02:12:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-05-12 02:12:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-05-12 02:12:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-05-12 02:12:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-05-12 02:12:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-05-12 02:12:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/videos/create_video.php
INFO - 2018-05-12 02:12:46 --> Final output sent to browser
DEBUG - 2018-05-12 02:12:47 --> Total execution time: 0.6164
INFO - 2018-05-12 02:14:35 --> Config Class Initialized
INFO - 2018-05-12 02:14:35 --> Hooks Class Initialized
DEBUG - 2018-05-12 02:14:35 --> UTF-8 Support Enabled
INFO - 2018-05-12 02:14:35 --> Utf8 Class Initialized
INFO - 2018-05-12 02:14:35 --> URI Class Initialized
INFO - 2018-05-12 02:14:35 --> Router Class Initialized
INFO - 2018-05-12 02:14:35 --> Output Class Initialized
INFO - 2018-05-12 02:14:35 --> Security Class Initialized
DEBUG - 2018-05-12 02:14:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 02:14:35 --> Input Class Initialized
INFO - 2018-05-12 02:14:35 --> Language Class Initialized
INFO - 2018-05-12 02:14:35 --> Language Class Initialized
INFO - 2018-05-12 02:14:35 --> Config Class Initialized
INFO - 2018-05-12 02:14:35 --> Loader Class Initialized
DEBUG - 2018-05-12 02:14:35 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-12 02:14:35 --> Helper loaded: url_helper
INFO - 2018-05-12 02:14:35 --> Helper loaded: form_helper
INFO - 2018-05-12 02:14:35 --> Helper loaded: date_helper
INFO - 2018-05-12 02:14:35 --> Helper loaded: util_helper
INFO - 2018-05-12 02:14:35 --> Helper loaded: text_helper
INFO - 2018-05-12 02:14:35 --> Helper loaded: string_helper
INFO - 2018-05-12 02:14:35 --> Database Driver Class Initialized
DEBUG - 2018-05-12 02:14:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-12 02:14:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-12 02:14:35 --> Email Class Initialized
INFO - 2018-05-12 02:14:35 --> Controller Class Initialized
DEBUG - 2018-05-12 02:14:35 --> videos MX_Controller Initialized
INFO - 2018-05-12 02:14:35 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-12 02:14:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-05-12 02:14:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-12 02:14:35 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-12 02:14:35 --> Login MX_Controller Initialized
DEBUG - 2018-05-12 02:14:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-12 02:14:46 --> Config Class Initialized
INFO - 2018-05-12 02:14:46 --> Hooks Class Initialized
DEBUG - 2018-05-12 02:14:46 --> UTF-8 Support Enabled
INFO - 2018-05-12 02:14:46 --> Utf8 Class Initialized
INFO - 2018-05-12 02:14:46 --> URI Class Initialized
INFO - 2018-05-12 02:14:46 --> Router Class Initialized
INFO - 2018-05-12 02:14:46 --> Output Class Initialized
INFO - 2018-05-12 02:14:46 --> Security Class Initialized
DEBUG - 2018-05-12 02:14:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 02:14:46 --> Input Class Initialized
INFO - 2018-05-12 02:14:46 --> Language Class Initialized
INFO - 2018-05-12 02:14:46 --> Language Class Initialized
INFO - 2018-05-12 02:14:46 --> Config Class Initialized
INFO - 2018-05-12 02:14:46 --> Loader Class Initialized
DEBUG - 2018-05-12 02:14:46 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-12 02:14:46 --> Helper loaded: url_helper
INFO - 2018-05-12 02:14:46 --> Helper loaded: form_helper
INFO - 2018-05-12 02:14:46 --> Helper loaded: date_helper
INFO - 2018-05-12 02:14:46 --> Helper loaded: util_helper
INFO - 2018-05-12 02:14:46 --> Helper loaded: text_helper
INFO - 2018-05-12 02:14:46 --> Helper loaded: string_helper
INFO - 2018-05-12 02:14:46 --> Database Driver Class Initialized
DEBUG - 2018-05-12 02:14:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-12 02:14:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-12 02:14:46 --> Email Class Initialized
INFO - 2018-05-12 02:14:46 --> Controller Class Initialized
DEBUG - 2018-05-12 02:14:47 --> videos MX_Controller Initialized
INFO - 2018-05-12 02:14:47 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-12 02:14:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-05-12 02:14:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-12 02:14:47 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-12 02:14:47 --> Login MX_Controller Initialized
DEBUG - 2018-05-12 02:14:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-12 02:14:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-05-12 02:14:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-05-12 02:14:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
ERROR - 2018-05-12 02:14:47 --> Severity: Notice --> Undefined variable: programs E:\xampp\htdocs\consulting\application\modules\admin\views\videos\create_video.php 143
DEBUG - 2018-05-12 02:14:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-05-12 02:14:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-05-12 02:14:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/videos/create_video.php
INFO - 2018-05-12 02:14:47 --> Final output sent to browser
DEBUG - 2018-05-12 02:14:47 --> Total execution time: 0.5378
INFO - 2018-05-12 02:15:11 --> Config Class Initialized
INFO - 2018-05-12 02:15:11 --> Hooks Class Initialized
DEBUG - 2018-05-12 02:15:11 --> UTF-8 Support Enabled
INFO - 2018-05-12 02:15:11 --> Utf8 Class Initialized
INFO - 2018-05-12 02:15:11 --> URI Class Initialized
INFO - 2018-05-12 02:15:11 --> Router Class Initialized
INFO - 2018-05-12 02:15:11 --> Output Class Initialized
INFO - 2018-05-12 02:15:11 --> Security Class Initialized
DEBUG - 2018-05-12 02:15:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 02:15:11 --> Input Class Initialized
INFO - 2018-05-12 02:15:11 --> Language Class Initialized
INFO - 2018-05-12 02:15:11 --> Language Class Initialized
INFO - 2018-05-12 02:15:11 --> Config Class Initialized
INFO - 2018-05-12 02:15:11 --> Loader Class Initialized
DEBUG - 2018-05-12 02:15:11 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-12 02:15:11 --> Helper loaded: url_helper
INFO - 2018-05-12 02:15:11 --> Helper loaded: form_helper
INFO - 2018-05-12 02:15:11 --> Helper loaded: date_helper
INFO - 2018-05-12 02:15:11 --> Helper loaded: util_helper
INFO - 2018-05-12 02:15:11 --> Helper loaded: text_helper
INFO - 2018-05-12 02:15:11 --> Helper loaded: string_helper
INFO - 2018-05-12 02:15:11 --> Database Driver Class Initialized
DEBUG - 2018-05-12 02:15:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-12 02:15:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-12 02:15:11 --> Email Class Initialized
INFO - 2018-05-12 02:15:11 --> Controller Class Initialized
DEBUG - 2018-05-12 02:15:11 --> videos MX_Controller Initialized
INFO - 2018-05-12 02:15:11 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-12 02:15:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-05-12 02:15:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-12 02:15:11 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-12 02:15:11 --> Login MX_Controller Initialized
DEBUG - 2018-05-12 02:15:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-12 02:15:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-05-12 02:15:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-05-12 02:15:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-05-12 02:15:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-05-12 02:15:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-05-12 02:15:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/videos/create_video.php
INFO - 2018-05-12 02:15:12 --> Final output sent to browser
DEBUG - 2018-05-12 02:15:12 --> Total execution time: 0.5299
INFO - 2018-05-12 02:15:24 --> Config Class Initialized
INFO - 2018-05-12 02:15:24 --> Hooks Class Initialized
DEBUG - 2018-05-12 02:15:24 --> UTF-8 Support Enabled
INFO - 2018-05-12 02:15:24 --> Utf8 Class Initialized
INFO - 2018-05-12 02:15:24 --> URI Class Initialized
INFO - 2018-05-12 02:15:24 --> Router Class Initialized
INFO - 2018-05-12 02:15:24 --> Output Class Initialized
INFO - 2018-05-12 02:15:24 --> Security Class Initialized
DEBUG - 2018-05-12 02:15:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 02:15:24 --> Input Class Initialized
INFO - 2018-05-12 02:15:24 --> Language Class Initialized
INFO - 2018-05-12 02:15:24 --> Language Class Initialized
INFO - 2018-05-12 02:15:24 --> Config Class Initialized
INFO - 2018-05-12 02:15:24 --> Loader Class Initialized
DEBUG - 2018-05-12 02:15:24 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-12 02:15:24 --> Helper loaded: url_helper
INFO - 2018-05-12 02:15:24 --> Helper loaded: form_helper
INFO - 2018-05-12 02:15:24 --> Helper loaded: date_helper
INFO - 2018-05-12 02:15:24 --> Helper loaded: util_helper
INFO - 2018-05-12 02:15:24 --> Helper loaded: text_helper
INFO - 2018-05-12 02:15:24 --> Helper loaded: string_helper
INFO - 2018-05-12 02:15:24 --> Database Driver Class Initialized
DEBUG - 2018-05-12 02:15:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-12 02:15:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-12 02:15:24 --> Email Class Initialized
INFO - 2018-05-12 02:15:24 --> Controller Class Initialized
DEBUG - 2018-05-12 02:15:24 --> videos MX_Controller Initialized
INFO - 2018-05-12 02:15:24 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-12 02:15:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-05-12 02:15:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-12 02:15:24 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-12 02:15:24 --> Login MX_Controller Initialized
DEBUG - 2018-05-12 02:15:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-12 02:15:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-05-12 02:15:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-05-12 02:15:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-05-12 02:15:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-05-12 02:15:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-05-12 02:15:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/videos/create_video.php
INFO - 2018-05-12 02:15:25 --> Final output sent to browser
DEBUG - 2018-05-12 02:15:25 --> Total execution time: 0.5606
INFO - 2018-05-12 02:18:17 --> Config Class Initialized
INFO - 2018-05-12 02:18:17 --> Hooks Class Initialized
DEBUG - 2018-05-12 02:18:17 --> UTF-8 Support Enabled
INFO - 2018-05-12 02:18:17 --> Utf8 Class Initialized
INFO - 2018-05-12 02:18:17 --> URI Class Initialized
INFO - 2018-05-12 02:18:17 --> Router Class Initialized
INFO - 2018-05-12 02:18:17 --> Output Class Initialized
INFO - 2018-05-12 02:18:17 --> Security Class Initialized
DEBUG - 2018-05-12 02:18:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 02:18:17 --> Input Class Initialized
INFO - 2018-05-12 02:18:17 --> Language Class Initialized
INFO - 2018-05-12 02:18:17 --> Language Class Initialized
INFO - 2018-05-12 02:18:17 --> Config Class Initialized
INFO - 2018-05-12 02:18:17 --> Loader Class Initialized
DEBUG - 2018-05-12 02:18:17 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-12 02:18:17 --> Helper loaded: url_helper
INFO - 2018-05-12 02:18:17 --> Helper loaded: form_helper
INFO - 2018-05-12 02:18:18 --> Helper loaded: date_helper
INFO - 2018-05-12 02:18:18 --> Helper loaded: util_helper
INFO - 2018-05-12 02:18:18 --> Helper loaded: text_helper
INFO - 2018-05-12 02:18:18 --> Helper loaded: string_helper
INFO - 2018-05-12 02:18:18 --> Database Driver Class Initialized
DEBUG - 2018-05-12 02:18:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-12 02:18:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-12 02:18:18 --> Email Class Initialized
INFO - 2018-05-12 02:18:18 --> Controller Class Initialized
DEBUG - 2018-05-12 02:18:18 --> videos MX_Controller Initialized
INFO - 2018-05-12 02:18:18 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-12 02:18:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-05-12 02:18:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-12 02:18:18 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-12 02:18:18 --> Login MX_Controller Initialized
DEBUG - 2018-05-12 02:18:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-12 02:18:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-05-12 02:18:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-05-12 02:18:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-05-12 02:18:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-05-12 02:18:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-05-12 02:18:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/videos/create_video.php
INFO - 2018-05-12 02:18:18 --> Final output sent to browser
DEBUG - 2018-05-12 02:18:18 --> Total execution time: 0.5562
INFO - 2018-05-12 02:21:06 --> Config Class Initialized
INFO - 2018-05-12 02:21:06 --> Hooks Class Initialized
DEBUG - 2018-05-12 02:21:06 --> UTF-8 Support Enabled
INFO - 2018-05-12 02:21:06 --> Utf8 Class Initialized
INFO - 2018-05-12 02:21:06 --> URI Class Initialized
INFO - 2018-05-12 02:21:06 --> Router Class Initialized
INFO - 2018-05-12 02:21:06 --> Output Class Initialized
INFO - 2018-05-12 02:21:06 --> Security Class Initialized
DEBUG - 2018-05-12 02:21:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 02:21:06 --> Input Class Initialized
INFO - 2018-05-12 02:21:06 --> Language Class Initialized
INFO - 2018-05-12 02:21:06 --> Language Class Initialized
INFO - 2018-05-12 02:21:06 --> Config Class Initialized
INFO - 2018-05-12 02:21:06 --> Loader Class Initialized
DEBUG - 2018-05-12 02:21:06 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-12 02:21:06 --> Helper loaded: url_helper
INFO - 2018-05-12 02:21:06 --> Helper loaded: form_helper
INFO - 2018-05-12 02:21:06 --> Helper loaded: date_helper
INFO - 2018-05-12 02:21:06 --> Helper loaded: util_helper
INFO - 2018-05-12 02:21:06 --> Helper loaded: text_helper
INFO - 2018-05-12 02:21:06 --> Helper loaded: string_helper
INFO - 2018-05-12 02:21:06 --> Database Driver Class Initialized
DEBUG - 2018-05-12 02:21:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-12 02:21:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-12 02:21:06 --> Email Class Initialized
INFO - 2018-05-12 02:21:06 --> Controller Class Initialized
DEBUG - 2018-05-12 02:21:06 --> videos MX_Controller Initialized
INFO - 2018-05-12 02:21:06 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-12 02:21:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-05-12 02:21:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-12 02:21:06 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-12 02:21:06 --> Login MX_Controller Initialized
DEBUG - 2018-05-12 02:21:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-12 02:21:09 --> Config Class Initialized
INFO - 2018-05-12 02:21:09 --> Hooks Class Initialized
DEBUG - 2018-05-12 02:21:09 --> UTF-8 Support Enabled
INFO - 2018-05-12 02:21:09 --> Utf8 Class Initialized
INFO - 2018-05-12 02:21:09 --> URI Class Initialized
INFO - 2018-05-12 02:21:09 --> Router Class Initialized
INFO - 2018-05-12 02:21:09 --> Output Class Initialized
INFO - 2018-05-12 02:21:09 --> Security Class Initialized
DEBUG - 2018-05-12 02:21:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 02:21:09 --> Input Class Initialized
INFO - 2018-05-12 02:21:09 --> Language Class Initialized
ERROR - 2018-05-12 02:21:09 --> 404 Page Not Found: /index
INFO - 2018-05-12 02:21:17 --> Config Class Initialized
INFO - 2018-05-12 02:21:17 --> Hooks Class Initialized
DEBUG - 2018-05-12 02:21:17 --> UTF-8 Support Enabled
INFO - 2018-05-12 02:21:17 --> Utf8 Class Initialized
INFO - 2018-05-12 02:21:17 --> URI Class Initialized
INFO - 2018-05-12 02:21:17 --> Router Class Initialized
INFO - 2018-05-12 02:21:17 --> Output Class Initialized
INFO - 2018-05-12 02:21:17 --> Security Class Initialized
DEBUG - 2018-05-12 02:21:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 02:21:17 --> Input Class Initialized
INFO - 2018-05-12 02:21:17 --> Language Class Initialized
INFO - 2018-05-12 02:21:17 --> Language Class Initialized
INFO - 2018-05-12 02:21:17 --> Config Class Initialized
INFO - 2018-05-12 02:21:17 --> Loader Class Initialized
DEBUG - 2018-05-12 02:21:17 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-12 02:21:17 --> Helper loaded: url_helper
INFO - 2018-05-12 02:21:17 --> Helper loaded: form_helper
INFO - 2018-05-12 02:21:17 --> Helper loaded: date_helper
INFO - 2018-05-12 02:21:17 --> Helper loaded: util_helper
INFO - 2018-05-12 02:21:17 --> Helper loaded: text_helper
INFO - 2018-05-12 02:21:17 --> Helper loaded: string_helper
INFO - 2018-05-12 02:21:17 --> Database Driver Class Initialized
DEBUG - 2018-05-12 02:21:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-12 02:21:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-12 02:21:17 --> Email Class Initialized
INFO - 2018-05-12 02:21:17 --> Controller Class Initialized
DEBUG - 2018-05-12 02:21:17 --> videos MX_Controller Initialized
INFO - 2018-05-12 02:21:17 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-12 02:21:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-05-12 02:21:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-12 02:21:17 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-12 02:21:17 --> Login MX_Controller Initialized
DEBUG - 2018-05-12 02:21:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-12 02:22:03 --> Config Class Initialized
INFO - 2018-05-12 02:22:03 --> Hooks Class Initialized
DEBUG - 2018-05-12 02:22:03 --> UTF-8 Support Enabled
INFO - 2018-05-12 02:22:03 --> Utf8 Class Initialized
INFO - 2018-05-12 02:22:03 --> URI Class Initialized
INFO - 2018-05-12 02:22:03 --> Router Class Initialized
INFO - 2018-05-12 02:22:03 --> Output Class Initialized
INFO - 2018-05-12 02:22:03 --> Security Class Initialized
DEBUG - 2018-05-12 02:22:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 02:22:03 --> Input Class Initialized
INFO - 2018-05-12 02:22:03 --> Language Class Initialized
INFO - 2018-05-12 02:22:03 --> Language Class Initialized
INFO - 2018-05-12 02:22:03 --> Config Class Initialized
INFO - 2018-05-12 02:22:03 --> Loader Class Initialized
DEBUG - 2018-05-12 02:22:03 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-12 02:22:03 --> Helper loaded: url_helper
INFO - 2018-05-12 02:22:03 --> Helper loaded: form_helper
INFO - 2018-05-12 02:22:03 --> Helper loaded: date_helper
INFO - 2018-05-12 02:22:03 --> Helper loaded: util_helper
INFO - 2018-05-12 02:22:03 --> Helper loaded: text_helper
INFO - 2018-05-12 02:22:03 --> Helper loaded: string_helper
INFO - 2018-05-12 02:22:03 --> Database Driver Class Initialized
DEBUG - 2018-05-12 02:22:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-12 02:22:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-12 02:22:03 --> Email Class Initialized
INFO - 2018-05-12 02:22:03 --> Controller Class Initialized
DEBUG - 2018-05-12 02:22:03 --> videos MX_Controller Initialized
INFO - 2018-05-12 02:22:03 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-12 02:22:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-05-12 02:22:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-12 02:22:03 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-12 02:22:03 --> Login MX_Controller Initialized
DEBUG - 2018-05-12 02:22:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-12 02:22:04 --> Config Class Initialized
INFO - 2018-05-12 02:22:04 --> Hooks Class Initialized
DEBUG - 2018-05-12 02:22:04 --> UTF-8 Support Enabled
INFO - 2018-05-12 02:22:04 --> Utf8 Class Initialized
INFO - 2018-05-12 02:22:04 --> URI Class Initialized
INFO - 2018-05-12 02:22:04 --> Router Class Initialized
INFO - 2018-05-12 02:22:04 --> Output Class Initialized
INFO - 2018-05-12 02:22:04 --> Security Class Initialized
DEBUG - 2018-05-12 02:22:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 02:22:04 --> Input Class Initialized
INFO - 2018-05-12 02:22:04 --> Language Class Initialized
INFO - 2018-05-12 02:22:04 --> Language Class Initialized
INFO - 2018-05-12 02:22:04 --> Config Class Initialized
INFO - 2018-05-12 02:22:04 --> Loader Class Initialized
DEBUG - 2018-05-12 02:22:04 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-12 02:22:04 --> Helper loaded: url_helper
INFO - 2018-05-12 02:22:04 --> Helper loaded: form_helper
INFO - 2018-05-12 02:22:04 --> Helper loaded: date_helper
INFO - 2018-05-12 02:22:04 --> Helper loaded: util_helper
INFO - 2018-05-12 02:22:04 --> Helper loaded: text_helper
INFO - 2018-05-12 02:22:04 --> Helper loaded: string_helper
INFO - 2018-05-12 02:22:04 --> Database Driver Class Initialized
DEBUG - 2018-05-12 02:22:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-12 02:22:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-12 02:22:04 --> Email Class Initialized
INFO - 2018-05-12 02:22:04 --> Controller Class Initialized
DEBUG - 2018-05-12 02:22:04 --> videos MX_Controller Initialized
INFO - 2018-05-12 02:22:04 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-12 02:22:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-05-12 02:22:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-12 02:22:04 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-12 02:22:04 --> Login MX_Controller Initialized
DEBUG - 2018-05-12 02:22:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-12 02:22:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-05-12 02:22:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-05-12 02:22:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-05-12 02:22:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-05-12 02:22:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-05-12 02:22:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/videos/videos.php
INFO - 2018-05-12 02:22:04 --> Final output sent to browser
DEBUG - 2018-05-12 02:22:04 --> Total execution time: 0.6282
INFO - 2018-05-12 02:22:05 --> Config Class Initialized
INFO - 2018-05-12 02:22:05 --> Hooks Class Initialized
DEBUG - 2018-05-12 02:22:05 --> UTF-8 Support Enabled
INFO - 2018-05-12 02:22:05 --> Utf8 Class Initialized
INFO - 2018-05-12 02:22:05 --> URI Class Initialized
INFO - 2018-05-12 02:22:05 --> Router Class Initialized
INFO - 2018-05-12 02:22:05 --> Output Class Initialized
INFO - 2018-05-12 02:22:05 --> Security Class Initialized
DEBUG - 2018-05-12 02:22:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 02:22:05 --> Input Class Initialized
INFO - 2018-05-12 02:22:05 --> Language Class Initialized
INFO - 2018-05-12 02:22:05 --> Language Class Initialized
INFO - 2018-05-12 02:22:05 --> Config Class Initialized
INFO - 2018-05-12 02:22:05 --> Loader Class Initialized
DEBUG - 2018-05-12 02:22:05 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-12 02:22:05 --> Helper loaded: url_helper
INFO - 2018-05-12 02:22:05 --> Helper loaded: form_helper
INFO - 2018-05-12 02:22:05 --> Helper loaded: date_helper
INFO - 2018-05-12 02:22:05 --> Helper loaded: util_helper
INFO - 2018-05-12 02:22:05 --> Helper loaded: text_helper
INFO - 2018-05-12 02:22:05 --> Helper loaded: string_helper
INFO - 2018-05-12 02:22:05 --> Database Driver Class Initialized
DEBUG - 2018-05-12 02:22:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-12 02:22:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-12 02:22:06 --> Email Class Initialized
INFO - 2018-05-12 02:22:06 --> Controller Class Initialized
DEBUG - 2018-05-12 02:22:06 --> videos MX_Controller Initialized
INFO - 2018-05-12 02:22:06 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-12 02:22:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-05-12 02:22:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-12 02:22:06 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-12 02:22:06 --> Login MX_Controller Initialized
DEBUG - 2018-05-12 02:22:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-12 02:22:06 --> Final output sent to browser
DEBUG - 2018-05-12 02:22:06 --> Total execution time: 0.7120
INFO - 2018-05-12 02:22:10 --> Config Class Initialized
INFO - 2018-05-12 02:22:10 --> Hooks Class Initialized
DEBUG - 2018-05-12 02:22:10 --> UTF-8 Support Enabled
INFO - 2018-05-12 02:22:10 --> Utf8 Class Initialized
INFO - 2018-05-12 02:22:10 --> URI Class Initialized
INFO - 2018-05-12 02:22:10 --> Router Class Initialized
INFO - 2018-05-12 02:22:10 --> Output Class Initialized
INFO - 2018-05-12 02:22:10 --> Security Class Initialized
DEBUG - 2018-05-12 02:22:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 02:22:10 --> Input Class Initialized
INFO - 2018-05-12 02:22:10 --> Language Class Initialized
INFO - 2018-05-12 02:22:10 --> Language Class Initialized
INFO - 2018-05-12 02:22:10 --> Config Class Initialized
INFO - 2018-05-12 02:22:10 --> Loader Class Initialized
DEBUG - 2018-05-12 02:22:10 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-12 02:22:11 --> Helper loaded: url_helper
INFO - 2018-05-12 02:22:11 --> Helper loaded: form_helper
INFO - 2018-05-12 02:22:11 --> Helper loaded: date_helper
INFO - 2018-05-12 02:22:11 --> Helper loaded: util_helper
INFO - 2018-05-12 02:22:11 --> Helper loaded: text_helper
INFO - 2018-05-12 02:22:11 --> Helper loaded: string_helper
INFO - 2018-05-12 02:22:11 --> Database Driver Class Initialized
DEBUG - 2018-05-12 02:22:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-12 02:22:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-12 02:22:11 --> Email Class Initialized
INFO - 2018-05-12 02:22:11 --> Controller Class Initialized
DEBUG - 2018-05-12 02:22:11 --> videos MX_Controller Initialized
INFO - 2018-05-12 02:22:11 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-12 02:22:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-05-12 02:22:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-12 02:22:11 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-12 02:22:11 --> Login MX_Controller Initialized
DEBUG - 2018-05-12 02:22:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-12 02:22:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-05-12 02:22:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-05-12 02:22:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-05-12 02:22:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-05-12 02:22:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-05-12 02:22:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/videos/create_video.php
INFO - 2018-05-12 02:22:11 --> Final output sent to browser
DEBUG - 2018-05-12 02:22:11 --> Total execution time: 0.5918
INFO - 2018-05-12 02:22:12 --> Config Class Initialized
INFO - 2018-05-12 02:22:12 --> Hooks Class Initialized
DEBUG - 2018-05-12 02:22:12 --> UTF-8 Support Enabled
INFO - 2018-05-12 02:22:12 --> Utf8 Class Initialized
INFO - 2018-05-12 02:22:12 --> URI Class Initialized
INFO - 2018-05-12 02:22:12 --> Router Class Initialized
INFO - 2018-05-12 02:22:12 --> Output Class Initialized
INFO - 2018-05-12 02:22:12 --> Security Class Initialized
DEBUG - 2018-05-12 02:22:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 02:22:12 --> Input Class Initialized
INFO - 2018-05-12 02:22:12 --> Language Class Initialized
ERROR - 2018-05-12 02:22:12 --> 404 Page Not Found: /index
INFO - 2018-05-12 02:22:15 --> Config Class Initialized
INFO - 2018-05-12 02:22:15 --> Hooks Class Initialized
DEBUG - 2018-05-12 02:22:15 --> UTF-8 Support Enabled
INFO - 2018-05-12 02:22:15 --> Utf8 Class Initialized
INFO - 2018-05-12 02:22:15 --> URI Class Initialized
INFO - 2018-05-12 02:22:15 --> Router Class Initialized
INFO - 2018-05-12 02:22:15 --> Output Class Initialized
INFO - 2018-05-12 02:22:15 --> Security Class Initialized
DEBUG - 2018-05-12 02:22:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 02:22:15 --> Input Class Initialized
INFO - 2018-05-12 02:22:15 --> Language Class Initialized
INFO - 2018-05-12 02:22:15 --> Language Class Initialized
INFO - 2018-05-12 02:22:15 --> Config Class Initialized
INFO - 2018-05-12 02:22:15 --> Loader Class Initialized
DEBUG - 2018-05-12 02:22:15 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-12 02:22:15 --> Helper loaded: url_helper
INFO - 2018-05-12 02:22:15 --> Helper loaded: form_helper
INFO - 2018-05-12 02:22:15 --> Helper loaded: date_helper
INFO - 2018-05-12 02:22:15 --> Helper loaded: util_helper
INFO - 2018-05-12 02:22:15 --> Helper loaded: text_helper
INFO - 2018-05-12 02:22:15 --> Helper loaded: string_helper
INFO - 2018-05-12 02:22:15 --> Database Driver Class Initialized
DEBUG - 2018-05-12 02:22:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-12 02:22:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-12 02:22:15 --> Email Class Initialized
INFO - 2018-05-12 02:22:15 --> Controller Class Initialized
DEBUG - 2018-05-12 02:22:15 --> videos MX_Controller Initialized
INFO - 2018-05-12 02:22:15 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-12 02:22:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-05-12 02:22:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-12 02:22:15 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-12 02:22:15 --> Login MX_Controller Initialized
DEBUG - 2018-05-12 02:22:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-12 02:22:16 --> Config Class Initialized
INFO - 2018-05-12 02:22:16 --> Hooks Class Initialized
DEBUG - 2018-05-12 02:22:16 --> UTF-8 Support Enabled
INFO - 2018-05-12 02:22:16 --> Utf8 Class Initialized
INFO - 2018-05-12 02:22:16 --> URI Class Initialized
INFO - 2018-05-12 02:22:16 --> Router Class Initialized
INFO - 2018-05-12 02:22:16 --> Output Class Initialized
INFO - 2018-05-12 02:22:16 --> Security Class Initialized
DEBUG - 2018-05-12 02:22:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 02:22:16 --> Input Class Initialized
INFO - 2018-05-12 02:22:16 --> Language Class Initialized
INFO - 2018-05-12 02:22:16 --> Language Class Initialized
INFO - 2018-05-12 02:22:16 --> Config Class Initialized
INFO - 2018-05-12 02:22:16 --> Loader Class Initialized
DEBUG - 2018-05-12 02:22:16 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-12 02:22:16 --> Helper loaded: url_helper
INFO - 2018-05-12 02:22:16 --> Helper loaded: form_helper
INFO - 2018-05-12 02:22:16 --> Helper loaded: date_helper
INFO - 2018-05-12 02:22:16 --> Helper loaded: util_helper
INFO - 2018-05-12 02:22:16 --> Helper loaded: text_helper
INFO - 2018-05-12 02:22:16 --> Helper loaded: string_helper
INFO - 2018-05-12 02:22:16 --> Database Driver Class Initialized
DEBUG - 2018-05-12 02:22:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-12 02:22:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-12 02:22:16 --> Email Class Initialized
INFO - 2018-05-12 02:22:16 --> Controller Class Initialized
DEBUG - 2018-05-12 02:22:16 --> videos MX_Controller Initialized
INFO - 2018-05-12 02:22:16 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-12 02:22:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-05-12 02:22:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-12 02:22:16 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-12 02:22:16 --> Login MX_Controller Initialized
DEBUG - 2018-05-12 02:22:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-12 02:22:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-05-12 02:22:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-05-12 02:22:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-05-12 02:22:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-05-12 02:22:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-05-12 02:22:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/videos/videos.php
INFO - 2018-05-12 02:22:16 --> Final output sent to browser
DEBUG - 2018-05-12 02:22:16 --> Total execution time: 0.6160
INFO - 2018-05-12 02:22:17 --> Config Class Initialized
INFO - 2018-05-12 02:22:17 --> Hooks Class Initialized
DEBUG - 2018-05-12 02:22:17 --> UTF-8 Support Enabled
INFO - 2018-05-12 02:22:17 --> Utf8 Class Initialized
INFO - 2018-05-12 02:22:17 --> URI Class Initialized
INFO - 2018-05-12 02:22:17 --> Router Class Initialized
INFO - 2018-05-12 02:22:17 --> Output Class Initialized
INFO - 2018-05-12 02:22:17 --> Security Class Initialized
DEBUG - 2018-05-12 02:22:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 02:22:17 --> Input Class Initialized
INFO - 2018-05-12 02:22:17 --> Language Class Initialized
INFO - 2018-05-12 02:22:17 --> Language Class Initialized
INFO - 2018-05-12 02:22:17 --> Config Class Initialized
INFO - 2018-05-12 02:22:17 --> Loader Class Initialized
DEBUG - 2018-05-12 02:22:17 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-12 02:22:17 --> Helper loaded: url_helper
INFO - 2018-05-12 02:22:17 --> Helper loaded: form_helper
INFO - 2018-05-12 02:22:17 --> Helper loaded: date_helper
INFO - 2018-05-12 02:22:17 --> Helper loaded: util_helper
INFO - 2018-05-12 02:22:17 --> Helper loaded: text_helper
INFO - 2018-05-12 02:22:17 --> Helper loaded: string_helper
INFO - 2018-05-12 02:22:17 --> Database Driver Class Initialized
DEBUG - 2018-05-12 02:22:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-12 02:22:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-12 02:22:17 --> Email Class Initialized
INFO - 2018-05-12 02:22:18 --> Controller Class Initialized
DEBUG - 2018-05-12 02:22:18 --> videos MX_Controller Initialized
INFO - 2018-05-12 02:22:18 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-12 02:22:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-05-12 02:22:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-12 02:22:18 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-12 02:22:18 --> Login MX_Controller Initialized
DEBUG - 2018-05-12 02:22:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-12 02:22:18 --> Final output sent to browser
DEBUG - 2018-05-12 02:22:18 --> Total execution time: 0.7254
INFO - 2018-05-12 02:23:03 --> Config Class Initialized
INFO - 2018-05-12 02:23:03 --> Hooks Class Initialized
DEBUG - 2018-05-12 02:23:03 --> UTF-8 Support Enabled
INFO - 2018-05-12 02:23:03 --> Utf8 Class Initialized
INFO - 2018-05-12 02:23:03 --> URI Class Initialized
INFO - 2018-05-12 02:23:03 --> Router Class Initialized
INFO - 2018-05-12 02:23:03 --> Output Class Initialized
INFO - 2018-05-12 02:23:03 --> Security Class Initialized
DEBUG - 2018-05-12 02:23:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 02:23:03 --> Input Class Initialized
INFO - 2018-05-12 02:23:03 --> Language Class Initialized
INFO - 2018-05-12 02:23:03 --> Language Class Initialized
INFO - 2018-05-12 02:23:03 --> Config Class Initialized
INFO - 2018-05-12 02:23:03 --> Loader Class Initialized
DEBUG - 2018-05-12 02:23:03 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-12 02:23:03 --> Helper loaded: url_helper
INFO - 2018-05-12 02:23:03 --> Helper loaded: form_helper
INFO - 2018-05-12 02:23:03 --> Helper loaded: date_helper
INFO - 2018-05-12 02:23:03 --> Helper loaded: util_helper
INFO - 2018-05-12 02:23:03 --> Helper loaded: text_helper
INFO - 2018-05-12 02:23:03 --> Helper loaded: string_helper
INFO - 2018-05-12 02:23:03 --> Database Driver Class Initialized
DEBUG - 2018-05-12 02:23:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-12 02:23:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-12 02:23:03 --> Email Class Initialized
INFO - 2018-05-12 02:23:03 --> Controller Class Initialized
DEBUG - 2018-05-12 02:23:03 --> videos MX_Controller Initialized
INFO - 2018-05-12 02:23:03 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-12 02:23:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-05-12 02:23:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-12 02:23:03 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-12 02:23:03 --> Login MX_Controller Initialized
DEBUG - 2018-05-12 02:23:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-12 02:23:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-05-12 02:23:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-05-12 02:23:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-05-12 02:23:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-05-12 02:23:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-05-12 02:23:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/videos/create_video.php
INFO - 2018-05-12 02:23:04 --> Final output sent to browser
DEBUG - 2018-05-12 02:23:04 --> Total execution time: 0.5510
INFO - 2018-05-12 02:23:04 --> Config Class Initialized
INFO - 2018-05-12 02:23:04 --> Hooks Class Initialized
DEBUG - 2018-05-12 02:23:04 --> UTF-8 Support Enabled
INFO - 2018-05-12 02:23:04 --> Utf8 Class Initialized
INFO - 2018-05-12 02:23:05 --> URI Class Initialized
INFO - 2018-05-12 02:23:05 --> Router Class Initialized
INFO - 2018-05-12 02:23:05 --> Output Class Initialized
INFO - 2018-05-12 02:23:05 --> Security Class Initialized
DEBUG - 2018-05-12 02:23:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 02:23:05 --> Input Class Initialized
INFO - 2018-05-12 02:23:05 --> Language Class Initialized
ERROR - 2018-05-12 02:23:05 --> 404 Page Not Found: /index
INFO - 2018-05-12 02:23:09 --> Config Class Initialized
INFO - 2018-05-12 02:23:09 --> Hooks Class Initialized
DEBUG - 2018-05-12 02:23:09 --> UTF-8 Support Enabled
INFO - 2018-05-12 02:23:09 --> Utf8 Class Initialized
INFO - 2018-05-12 02:23:09 --> URI Class Initialized
INFO - 2018-05-12 02:23:09 --> Router Class Initialized
INFO - 2018-05-12 02:23:09 --> Output Class Initialized
INFO - 2018-05-12 02:23:09 --> Security Class Initialized
DEBUG - 2018-05-12 02:23:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 02:23:09 --> Input Class Initialized
INFO - 2018-05-12 02:23:09 --> Language Class Initialized
INFO - 2018-05-12 02:23:09 --> Language Class Initialized
INFO - 2018-05-12 02:23:09 --> Config Class Initialized
INFO - 2018-05-12 02:23:09 --> Loader Class Initialized
DEBUG - 2018-05-12 02:23:09 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-12 02:23:09 --> Helper loaded: url_helper
INFO - 2018-05-12 02:23:09 --> Helper loaded: form_helper
INFO - 2018-05-12 02:23:09 --> Helper loaded: date_helper
INFO - 2018-05-12 02:23:09 --> Helper loaded: util_helper
INFO - 2018-05-12 02:23:09 --> Helper loaded: text_helper
INFO - 2018-05-12 02:23:09 --> Helper loaded: string_helper
INFO - 2018-05-12 02:23:09 --> Database Driver Class Initialized
DEBUG - 2018-05-12 02:23:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-12 02:23:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-12 02:23:09 --> Email Class Initialized
INFO - 2018-05-12 02:23:09 --> Controller Class Initialized
DEBUG - 2018-05-12 02:23:09 --> videos MX_Controller Initialized
INFO - 2018-05-12 02:23:09 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-12 02:23:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-05-12 02:23:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-12 02:23:09 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-12 02:23:09 --> Login MX_Controller Initialized
DEBUG - 2018-05-12 02:23:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-12 02:23:40 --> Config Class Initialized
INFO - 2018-05-12 02:23:40 --> Hooks Class Initialized
DEBUG - 2018-05-12 02:23:40 --> UTF-8 Support Enabled
INFO - 2018-05-12 02:23:40 --> Utf8 Class Initialized
INFO - 2018-05-12 02:23:40 --> URI Class Initialized
INFO - 2018-05-12 02:23:40 --> Router Class Initialized
INFO - 2018-05-12 02:23:40 --> Output Class Initialized
INFO - 2018-05-12 02:23:40 --> Security Class Initialized
DEBUG - 2018-05-12 02:23:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 02:23:40 --> Input Class Initialized
INFO - 2018-05-12 02:23:40 --> Language Class Initialized
INFO - 2018-05-12 02:23:40 --> Language Class Initialized
INFO - 2018-05-12 02:23:40 --> Config Class Initialized
INFO - 2018-05-12 02:23:40 --> Loader Class Initialized
DEBUG - 2018-05-12 02:23:40 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-12 02:23:40 --> Helper loaded: url_helper
INFO - 2018-05-12 02:23:40 --> Helper loaded: form_helper
INFO - 2018-05-12 02:23:40 --> Helper loaded: date_helper
INFO - 2018-05-12 02:23:40 --> Helper loaded: util_helper
INFO - 2018-05-12 02:23:40 --> Helper loaded: text_helper
INFO - 2018-05-12 02:23:40 --> Helper loaded: string_helper
INFO - 2018-05-12 02:23:40 --> Database Driver Class Initialized
DEBUG - 2018-05-12 02:23:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-12 02:23:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-12 02:23:40 --> Email Class Initialized
INFO - 2018-05-12 02:23:40 --> Controller Class Initialized
DEBUG - 2018-05-12 02:23:40 --> videos MX_Controller Initialized
INFO - 2018-05-12 02:23:40 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-12 02:23:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-05-12 02:23:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-12 02:23:40 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-12 02:23:40 --> Login MX_Controller Initialized
DEBUG - 2018-05-12 02:23:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-12 02:23:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-05-12 02:23:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-05-12 02:23:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-05-12 02:23:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-05-12 02:23:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-05-12 02:23:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/videos/videos.php
INFO - 2018-05-12 02:23:40 --> Final output sent to browser
DEBUG - 2018-05-12 02:23:40 --> Total execution time: 0.5596
INFO - 2018-05-12 02:23:41 --> Config Class Initialized
INFO - 2018-05-12 02:23:41 --> Hooks Class Initialized
DEBUG - 2018-05-12 02:23:41 --> UTF-8 Support Enabled
INFO - 2018-05-12 02:23:41 --> Utf8 Class Initialized
INFO - 2018-05-12 02:23:41 --> URI Class Initialized
INFO - 2018-05-12 02:23:41 --> Router Class Initialized
INFO - 2018-05-12 02:23:41 --> Output Class Initialized
INFO - 2018-05-12 02:23:41 --> Security Class Initialized
DEBUG - 2018-05-12 02:23:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 02:23:41 --> Input Class Initialized
INFO - 2018-05-12 02:23:41 --> Language Class Initialized
INFO - 2018-05-12 02:23:41 --> Language Class Initialized
INFO - 2018-05-12 02:23:41 --> Config Class Initialized
INFO - 2018-05-12 02:23:41 --> Loader Class Initialized
DEBUG - 2018-05-12 02:23:41 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-12 02:23:41 --> Helper loaded: url_helper
INFO - 2018-05-12 02:23:41 --> Helper loaded: form_helper
INFO - 2018-05-12 02:23:41 --> Helper loaded: date_helper
INFO - 2018-05-12 02:23:41 --> Helper loaded: util_helper
INFO - 2018-05-12 02:23:42 --> Helper loaded: text_helper
INFO - 2018-05-12 02:23:42 --> Helper loaded: string_helper
INFO - 2018-05-12 02:23:42 --> Database Driver Class Initialized
DEBUG - 2018-05-12 02:23:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-12 02:23:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-12 02:23:42 --> Email Class Initialized
INFO - 2018-05-12 02:23:42 --> Controller Class Initialized
DEBUG - 2018-05-12 02:23:42 --> videos MX_Controller Initialized
INFO - 2018-05-12 02:23:42 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-12 02:23:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-05-12 02:23:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-12 02:23:42 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-12 02:23:42 --> Login MX_Controller Initialized
DEBUG - 2018-05-12 02:23:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-12 02:23:42 --> Final output sent to browser
DEBUG - 2018-05-12 02:23:42 --> Total execution time: 0.8109
INFO - 2018-05-12 02:23:45 --> Config Class Initialized
INFO - 2018-05-12 02:23:45 --> Hooks Class Initialized
DEBUG - 2018-05-12 02:23:45 --> UTF-8 Support Enabled
INFO - 2018-05-12 02:23:45 --> Utf8 Class Initialized
INFO - 2018-05-12 02:23:45 --> URI Class Initialized
INFO - 2018-05-12 02:23:45 --> Router Class Initialized
INFO - 2018-05-12 02:23:45 --> Output Class Initialized
INFO - 2018-05-12 02:23:45 --> Security Class Initialized
DEBUG - 2018-05-12 02:23:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 02:23:45 --> Input Class Initialized
INFO - 2018-05-12 02:23:45 --> Language Class Initialized
INFO - 2018-05-12 02:23:45 --> Language Class Initialized
INFO - 2018-05-12 02:23:45 --> Config Class Initialized
INFO - 2018-05-12 02:23:45 --> Loader Class Initialized
DEBUG - 2018-05-12 02:23:45 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-12 02:23:45 --> Helper loaded: url_helper
INFO - 2018-05-12 02:23:45 --> Helper loaded: form_helper
INFO - 2018-05-12 02:23:45 --> Helper loaded: date_helper
INFO - 2018-05-12 02:23:45 --> Helper loaded: util_helper
INFO - 2018-05-12 02:23:46 --> Helper loaded: text_helper
INFO - 2018-05-12 02:23:46 --> Helper loaded: string_helper
INFO - 2018-05-12 02:23:46 --> Database Driver Class Initialized
DEBUG - 2018-05-12 02:23:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-12 02:23:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-12 02:23:46 --> Email Class Initialized
INFO - 2018-05-12 02:23:46 --> Controller Class Initialized
DEBUG - 2018-05-12 02:23:46 --> Admin MX_Controller Initialized
INFO - 2018-05-12 02:23:46 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-12 02:23:46 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-12 02:23:46 --> Login MX_Controller Initialized
DEBUG - 2018-05-12 02:23:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-12 02:23:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-12 02:23:46 --> Final output sent to browser
DEBUG - 2018-05-12 02:23:46 --> Total execution time: 0.5627
INFO - 2018-05-12 02:24:11 --> Config Class Initialized
INFO - 2018-05-12 02:24:11 --> Hooks Class Initialized
DEBUG - 2018-05-12 02:24:11 --> UTF-8 Support Enabled
INFO - 2018-05-12 02:24:11 --> Utf8 Class Initialized
INFO - 2018-05-12 02:24:11 --> URI Class Initialized
INFO - 2018-05-12 02:24:11 --> Router Class Initialized
INFO - 2018-05-12 02:24:11 --> Output Class Initialized
INFO - 2018-05-12 02:24:11 --> Security Class Initialized
DEBUG - 2018-05-12 02:24:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 02:24:11 --> Input Class Initialized
INFO - 2018-05-12 02:24:12 --> Language Class Initialized
INFO - 2018-05-12 02:24:12 --> Language Class Initialized
INFO - 2018-05-12 02:24:12 --> Config Class Initialized
INFO - 2018-05-12 02:24:12 --> Loader Class Initialized
DEBUG - 2018-05-12 02:24:12 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-12 02:24:12 --> Helper loaded: url_helper
INFO - 2018-05-12 02:24:12 --> Helper loaded: form_helper
INFO - 2018-05-12 02:24:12 --> Helper loaded: date_helper
INFO - 2018-05-12 02:24:12 --> Helper loaded: util_helper
INFO - 2018-05-12 02:24:12 --> Helper loaded: text_helper
INFO - 2018-05-12 02:24:12 --> Helper loaded: string_helper
INFO - 2018-05-12 02:24:12 --> Database Driver Class Initialized
DEBUG - 2018-05-12 02:24:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-12 02:24:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-12 02:24:12 --> Email Class Initialized
INFO - 2018-05-12 02:24:12 --> Controller Class Initialized
DEBUG - 2018-05-12 02:24:12 --> videos MX_Controller Initialized
INFO - 2018-05-12 02:24:12 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-12 02:24:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-05-12 02:24:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-12 02:24:12 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-12 02:24:12 --> Login MX_Controller Initialized
DEBUG - 2018-05-12 02:24:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-12 02:24:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-05-12 02:24:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-05-12 02:24:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-05-12 02:24:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-05-12 02:24:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-05-12 02:24:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/videos/videos.php
INFO - 2018-05-12 02:24:12 --> Final output sent to browser
DEBUG - 2018-05-12 02:24:12 --> Total execution time: 0.5660
INFO - 2018-05-12 02:24:13 --> Config Class Initialized
INFO - 2018-05-12 02:24:13 --> Hooks Class Initialized
DEBUG - 2018-05-12 02:24:13 --> UTF-8 Support Enabled
INFO - 2018-05-12 02:24:13 --> Utf8 Class Initialized
INFO - 2018-05-12 02:24:13 --> URI Class Initialized
INFO - 2018-05-12 02:24:13 --> Router Class Initialized
INFO - 2018-05-12 02:24:13 --> Output Class Initialized
INFO - 2018-05-12 02:24:13 --> Security Class Initialized
DEBUG - 2018-05-12 02:24:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 02:24:13 --> Input Class Initialized
INFO - 2018-05-12 02:24:13 --> Language Class Initialized
INFO - 2018-05-12 02:24:13 --> Language Class Initialized
INFO - 2018-05-12 02:24:13 --> Config Class Initialized
INFO - 2018-05-12 02:24:13 --> Loader Class Initialized
DEBUG - 2018-05-12 02:24:13 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-12 02:24:13 --> Helper loaded: url_helper
INFO - 2018-05-12 02:24:13 --> Helper loaded: form_helper
INFO - 2018-05-12 02:24:13 --> Helper loaded: date_helper
INFO - 2018-05-12 02:24:14 --> Helper loaded: util_helper
INFO - 2018-05-12 02:24:14 --> Helper loaded: text_helper
INFO - 2018-05-12 02:24:14 --> Helper loaded: string_helper
INFO - 2018-05-12 02:24:14 --> Database Driver Class Initialized
DEBUG - 2018-05-12 02:24:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-12 02:24:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-12 02:24:14 --> Email Class Initialized
INFO - 2018-05-12 02:24:14 --> Controller Class Initialized
DEBUG - 2018-05-12 02:24:14 --> videos MX_Controller Initialized
INFO - 2018-05-12 02:24:14 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-12 02:24:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-05-12 02:24:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-12 02:24:14 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-12 02:24:14 --> Login MX_Controller Initialized
DEBUG - 2018-05-12 02:24:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-12 02:24:14 --> Final output sent to browser
DEBUG - 2018-05-12 02:24:14 --> Total execution time: 0.9111
INFO - 2018-05-12 02:24:19 --> Config Class Initialized
INFO - 2018-05-12 02:24:19 --> Hooks Class Initialized
DEBUG - 2018-05-12 02:24:19 --> UTF-8 Support Enabled
INFO - 2018-05-12 02:24:19 --> Utf8 Class Initialized
INFO - 2018-05-12 02:24:19 --> URI Class Initialized
INFO - 2018-05-12 02:24:19 --> Router Class Initialized
INFO - 2018-05-12 02:24:19 --> Output Class Initialized
INFO - 2018-05-12 02:24:19 --> Security Class Initialized
DEBUG - 2018-05-12 02:24:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 02:24:19 --> Input Class Initialized
INFO - 2018-05-12 02:24:19 --> Language Class Initialized
INFO - 2018-05-12 02:24:19 --> Language Class Initialized
INFO - 2018-05-12 02:24:19 --> Config Class Initialized
INFO - 2018-05-12 02:24:19 --> Loader Class Initialized
DEBUG - 2018-05-12 02:24:19 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-12 02:24:19 --> Helper loaded: url_helper
INFO - 2018-05-12 02:24:19 --> Helper loaded: form_helper
INFO - 2018-05-12 02:24:19 --> Helper loaded: date_helper
INFO - 2018-05-12 02:24:19 --> Helper loaded: util_helper
INFO - 2018-05-12 02:24:19 --> Helper loaded: text_helper
INFO - 2018-05-12 02:24:19 --> Helper loaded: string_helper
INFO - 2018-05-12 02:24:19 --> Database Driver Class Initialized
DEBUG - 2018-05-12 02:24:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-12 02:24:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-12 02:24:19 --> Email Class Initialized
INFO - 2018-05-12 02:24:19 --> Controller Class Initialized
DEBUG - 2018-05-12 02:24:19 --> videos MX_Controller Initialized
INFO - 2018-05-12 02:24:19 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-12 02:24:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-05-12 02:24:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-12 02:24:19 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-12 02:24:19 --> Login MX_Controller Initialized
DEBUG - 2018-05-12 02:24:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-12 02:24:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-05-12 02:24:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-05-12 02:24:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-05-12 02:24:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-05-12 02:24:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-05-12 02:24:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/videos/create_video.php
INFO - 2018-05-12 02:24:20 --> Final output sent to browser
DEBUG - 2018-05-12 02:24:20 --> Total execution time: 0.5582
INFO - 2018-05-12 02:24:21 --> Config Class Initialized
INFO - 2018-05-12 02:24:21 --> Hooks Class Initialized
DEBUG - 2018-05-12 02:24:21 --> UTF-8 Support Enabled
INFO - 2018-05-12 02:24:21 --> Utf8 Class Initialized
INFO - 2018-05-12 02:24:21 --> URI Class Initialized
INFO - 2018-05-12 02:24:21 --> Router Class Initialized
INFO - 2018-05-12 02:24:22 --> Output Class Initialized
INFO - 2018-05-12 02:24:22 --> Security Class Initialized
DEBUG - 2018-05-12 02:24:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 02:24:22 --> Input Class Initialized
INFO - 2018-05-12 02:24:22 --> Language Class Initialized
INFO - 2018-05-12 02:24:22 --> Language Class Initialized
INFO - 2018-05-12 02:24:22 --> Config Class Initialized
INFO - 2018-05-12 02:24:22 --> Loader Class Initialized
DEBUG - 2018-05-12 02:24:22 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-12 02:24:22 --> Helper loaded: url_helper
INFO - 2018-05-12 02:24:22 --> Helper loaded: form_helper
INFO - 2018-05-12 02:24:22 --> Helper loaded: date_helper
INFO - 2018-05-12 02:24:22 --> Helper loaded: util_helper
INFO - 2018-05-12 02:24:22 --> Helper loaded: text_helper
INFO - 2018-05-12 02:24:22 --> Helper loaded: string_helper
INFO - 2018-05-12 02:24:22 --> Database Driver Class Initialized
DEBUG - 2018-05-12 02:24:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-12 02:24:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-12 02:24:22 --> Email Class Initialized
INFO - 2018-05-12 02:24:22 --> Controller Class Initialized
DEBUG - 2018-05-12 02:24:22 --> videos MX_Controller Initialized
INFO - 2018-05-12 02:24:22 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-12 02:24:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-05-12 02:24:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-12 02:24:22 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-12 02:24:22 --> Login MX_Controller Initialized
DEBUG - 2018-05-12 02:24:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-12 02:24:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-05-12 02:24:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-05-12 02:24:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-05-12 02:24:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-05-12 02:24:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-05-12 02:24:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/videos/videos.php
INFO - 2018-05-12 02:24:22 --> Final output sent to browser
DEBUG - 2018-05-12 02:24:22 --> Total execution time: 0.5594
INFO - 2018-05-12 02:24:22 --> Config Class Initialized
INFO - 2018-05-12 02:24:22 --> Hooks Class Initialized
DEBUG - 2018-05-12 02:24:22 --> UTF-8 Support Enabled
INFO - 2018-05-12 02:24:22 --> Utf8 Class Initialized
INFO - 2018-05-12 02:24:22 --> URI Class Initialized
INFO - 2018-05-12 02:24:22 --> Router Class Initialized
INFO - 2018-05-12 02:24:23 --> Output Class Initialized
INFO - 2018-05-12 02:24:23 --> Security Class Initialized
DEBUG - 2018-05-12 02:24:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 02:24:23 --> Input Class Initialized
INFO - 2018-05-12 02:24:23 --> Language Class Initialized
INFO - 2018-05-12 02:24:23 --> Language Class Initialized
INFO - 2018-05-12 02:24:23 --> Config Class Initialized
INFO - 2018-05-12 02:24:23 --> Loader Class Initialized
DEBUG - 2018-05-12 02:24:23 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-12 02:24:23 --> Helper loaded: url_helper
INFO - 2018-05-12 02:24:23 --> Helper loaded: form_helper
INFO - 2018-05-12 02:24:23 --> Helper loaded: date_helper
INFO - 2018-05-12 02:24:23 --> Helper loaded: util_helper
INFO - 2018-05-12 02:24:23 --> Helper loaded: text_helper
INFO - 2018-05-12 02:24:23 --> Helper loaded: string_helper
INFO - 2018-05-12 02:24:23 --> Database Driver Class Initialized
DEBUG - 2018-05-12 02:24:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-12 02:24:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-12 02:24:23 --> Email Class Initialized
INFO - 2018-05-12 02:24:23 --> Controller Class Initialized
DEBUG - 2018-05-12 02:24:23 --> videos MX_Controller Initialized
INFO - 2018-05-12 02:24:23 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-12 02:24:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-05-12 02:24:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-12 02:24:23 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-12 02:24:23 --> Login MX_Controller Initialized
DEBUG - 2018-05-12 02:24:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-12 02:24:23 --> Final output sent to browser
DEBUG - 2018-05-12 02:24:23 --> Total execution time: 0.6389
INFO - 2018-05-12 02:24:43 --> Config Class Initialized
INFO - 2018-05-12 02:24:43 --> Hooks Class Initialized
DEBUG - 2018-05-12 02:24:43 --> UTF-8 Support Enabled
INFO - 2018-05-12 02:24:43 --> Utf8 Class Initialized
INFO - 2018-05-12 02:24:43 --> URI Class Initialized
INFO - 2018-05-12 02:24:43 --> Router Class Initialized
INFO - 2018-05-12 02:24:43 --> Output Class Initialized
INFO - 2018-05-12 02:24:43 --> Security Class Initialized
DEBUG - 2018-05-12 02:24:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 02:24:43 --> Input Class Initialized
INFO - 2018-05-12 02:24:43 --> Language Class Initialized
INFO - 2018-05-12 02:24:43 --> Language Class Initialized
INFO - 2018-05-12 02:24:43 --> Config Class Initialized
INFO - 2018-05-12 02:24:43 --> Loader Class Initialized
DEBUG - 2018-05-12 02:24:43 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-12 02:24:43 --> Helper loaded: url_helper
INFO - 2018-05-12 02:24:43 --> Helper loaded: form_helper
INFO - 2018-05-12 02:24:43 --> Helper loaded: date_helper
INFO - 2018-05-12 02:24:43 --> Helper loaded: util_helper
INFO - 2018-05-12 02:24:43 --> Helper loaded: text_helper
INFO - 2018-05-12 02:24:43 --> Helper loaded: string_helper
INFO - 2018-05-12 02:24:43 --> Database Driver Class Initialized
DEBUG - 2018-05-12 02:24:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-12 02:24:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-12 02:24:43 --> Email Class Initialized
INFO - 2018-05-12 02:24:43 --> Controller Class Initialized
DEBUG - 2018-05-12 02:24:43 --> videos MX_Controller Initialized
INFO - 2018-05-12 02:24:43 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-12 02:24:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-05-12 02:24:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-12 02:24:43 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-12 02:24:43 --> Login MX_Controller Initialized
DEBUG - 2018-05-12 02:24:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-12 02:24:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-05-12 02:24:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-05-12 02:24:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-05-12 02:24:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-05-12 02:24:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-05-12 02:24:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/videos/create_video.php
INFO - 2018-05-12 02:24:43 --> Final output sent to browser
DEBUG - 2018-05-12 02:24:44 --> Total execution time: 0.6216
INFO - 2018-05-12 02:27:15 --> Config Class Initialized
INFO - 2018-05-12 02:27:15 --> Hooks Class Initialized
DEBUG - 2018-05-12 02:27:15 --> UTF-8 Support Enabled
INFO - 2018-05-12 02:27:15 --> Utf8 Class Initialized
INFO - 2018-05-12 02:27:15 --> URI Class Initialized
INFO - 2018-05-12 02:27:15 --> Router Class Initialized
INFO - 2018-05-12 02:27:15 --> Output Class Initialized
INFO - 2018-05-12 02:27:15 --> Security Class Initialized
DEBUG - 2018-05-12 02:27:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 02:27:15 --> Input Class Initialized
INFO - 2018-05-12 02:27:15 --> Language Class Initialized
INFO - 2018-05-12 02:27:15 --> Language Class Initialized
INFO - 2018-05-12 02:27:15 --> Config Class Initialized
INFO - 2018-05-12 02:27:15 --> Loader Class Initialized
DEBUG - 2018-05-12 02:27:15 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-12 02:27:15 --> Helper loaded: url_helper
INFO - 2018-05-12 02:27:15 --> Helper loaded: form_helper
INFO - 2018-05-12 02:27:15 --> Helper loaded: date_helper
INFO - 2018-05-12 02:27:15 --> Helper loaded: util_helper
INFO - 2018-05-12 02:27:15 --> Helper loaded: text_helper
INFO - 2018-05-12 02:27:15 --> Helper loaded: string_helper
INFO - 2018-05-12 02:27:15 --> Database Driver Class Initialized
DEBUG - 2018-05-12 02:27:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-12 02:27:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-12 02:27:15 --> Email Class Initialized
INFO - 2018-05-12 02:27:15 --> Controller Class Initialized
DEBUG - 2018-05-12 02:27:15 --> videos MX_Controller Initialized
INFO - 2018-05-12 02:27:15 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-12 02:27:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-05-12 02:27:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-12 02:27:15 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-12 02:27:15 --> Login MX_Controller Initialized
DEBUG - 2018-05-12 02:27:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-12 02:27:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-05-12 02:27:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-05-12 02:27:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-05-12 02:27:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-05-12 02:27:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-05-12 02:27:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/videos/create_video.php
INFO - 2018-05-12 02:27:15 --> Final output sent to browser
DEBUG - 2018-05-12 02:27:15 --> Total execution time: 0.5722
INFO - 2018-05-12 02:31:23 --> Config Class Initialized
INFO - 2018-05-12 02:31:23 --> Hooks Class Initialized
DEBUG - 2018-05-12 02:31:23 --> UTF-8 Support Enabled
INFO - 2018-05-12 02:31:23 --> Utf8 Class Initialized
INFO - 2018-05-12 02:31:23 --> URI Class Initialized
INFO - 2018-05-12 02:31:23 --> Router Class Initialized
INFO - 2018-05-12 02:31:24 --> Output Class Initialized
INFO - 2018-05-12 02:31:24 --> Security Class Initialized
DEBUG - 2018-05-12 02:31:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 02:31:24 --> Input Class Initialized
INFO - 2018-05-12 02:31:24 --> Language Class Initialized
INFO - 2018-05-12 02:31:24 --> Language Class Initialized
INFO - 2018-05-12 02:31:24 --> Config Class Initialized
INFO - 2018-05-12 02:31:24 --> Loader Class Initialized
DEBUG - 2018-05-12 02:31:24 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-12 02:31:24 --> Helper loaded: url_helper
INFO - 2018-05-12 02:31:24 --> Helper loaded: form_helper
INFO - 2018-05-12 02:31:24 --> Helper loaded: date_helper
INFO - 2018-05-12 02:31:24 --> Helper loaded: util_helper
INFO - 2018-05-12 02:31:24 --> Helper loaded: text_helper
INFO - 2018-05-12 02:31:24 --> Helper loaded: string_helper
INFO - 2018-05-12 02:31:24 --> Database Driver Class Initialized
DEBUG - 2018-05-12 02:31:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-12 02:31:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-12 02:31:24 --> Email Class Initialized
INFO - 2018-05-12 02:31:24 --> Controller Class Initialized
DEBUG - 2018-05-12 02:31:24 --> videos MX_Controller Initialized
INFO - 2018-05-12 02:31:24 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-12 02:31:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-05-12 02:31:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-12 02:31:24 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-12 02:31:24 --> Login MX_Controller Initialized
DEBUG - 2018-05-12 02:31:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-12 02:31:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-05-12 02:31:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-05-12 02:31:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-05-12 02:31:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-05-12 02:31:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-05-12 02:31:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/videos/create_video.php
INFO - 2018-05-12 02:31:24 --> Final output sent to browser
DEBUG - 2018-05-12 02:31:24 --> Total execution time: 0.5854
INFO - 2018-05-12 02:38:42 --> Config Class Initialized
INFO - 2018-05-12 02:38:42 --> Hooks Class Initialized
DEBUG - 2018-05-12 02:38:42 --> UTF-8 Support Enabled
INFO - 2018-05-12 02:38:42 --> Utf8 Class Initialized
INFO - 2018-05-12 02:38:42 --> URI Class Initialized
INFO - 2018-05-12 02:38:42 --> Router Class Initialized
INFO - 2018-05-12 02:38:42 --> Output Class Initialized
INFO - 2018-05-12 02:38:42 --> Security Class Initialized
DEBUG - 2018-05-12 02:38:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 02:38:42 --> Input Class Initialized
INFO - 2018-05-12 02:38:42 --> Language Class Initialized
ERROR - 2018-05-12 02:38:42 --> 404 Page Not Found: /index
INFO - 2018-05-12 02:52:46 --> Config Class Initialized
INFO - 2018-05-12 02:52:46 --> Hooks Class Initialized
DEBUG - 2018-05-12 02:52:46 --> UTF-8 Support Enabled
INFO - 2018-05-12 02:52:46 --> Utf8 Class Initialized
INFO - 2018-05-12 02:52:46 --> URI Class Initialized
INFO - 2018-05-12 02:52:46 --> Router Class Initialized
INFO - 2018-05-12 02:52:46 --> Output Class Initialized
INFO - 2018-05-12 02:52:46 --> Security Class Initialized
DEBUG - 2018-05-12 02:52:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 02:52:47 --> Input Class Initialized
INFO - 2018-05-12 02:52:47 --> Language Class Initialized
INFO - 2018-05-12 02:52:47 --> Language Class Initialized
INFO - 2018-05-12 02:52:47 --> Config Class Initialized
INFO - 2018-05-12 02:52:47 --> Loader Class Initialized
DEBUG - 2018-05-12 02:52:47 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-12 02:52:47 --> Helper loaded: url_helper
INFO - 2018-05-12 02:52:47 --> Helper loaded: form_helper
INFO - 2018-05-12 02:52:47 --> Helper loaded: date_helper
INFO - 2018-05-12 02:52:47 --> Helper loaded: util_helper
INFO - 2018-05-12 02:52:47 --> Helper loaded: text_helper
INFO - 2018-05-12 02:52:47 --> Helper loaded: string_helper
INFO - 2018-05-12 02:52:47 --> Database Driver Class Initialized
DEBUG - 2018-05-12 02:52:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-12 02:52:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-12 02:52:47 --> Email Class Initialized
INFO - 2018-05-12 02:52:47 --> Controller Class Initialized
DEBUG - 2018-05-12 02:52:47 --> videos MX_Controller Initialized
INFO - 2018-05-12 02:52:47 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-12 02:52:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-05-12 02:52:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-12 02:52:47 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-12 02:52:47 --> Login MX_Controller Initialized
DEBUG - 2018-05-12 02:52:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-12 02:52:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-05-12 02:52:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-05-12 02:52:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-05-12 02:52:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-05-12 02:52:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-05-12 02:52:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/videos/create_video.php
INFO - 2018-05-12 02:52:47 --> Final output sent to browser
DEBUG - 2018-05-12 02:52:47 --> Total execution time: 0.5923
INFO - 2018-05-12 03:05:57 --> Config Class Initialized
INFO - 2018-05-12 03:05:57 --> Hooks Class Initialized
DEBUG - 2018-05-12 03:05:57 --> UTF-8 Support Enabled
INFO - 2018-05-12 03:05:57 --> Utf8 Class Initialized
INFO - 2018-05-12 03:05:57 --> URI Class Initialized
INFO - 2018-05-12 03:05:57 --> Router Class Initialized
INFO - 2018-05-12 03:05:57 --> Output Class Initialized
INFO - 2018-05-12 03:05:57 --> Security Class Initialized
DEBUG - 2018-05-12 03:05:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 03:05:57 --> Input Class Initialized
INFO - 2018-05-12 03:05:57 --> Language Class Initialized
ERROR - 2018-05-12 03:05:57 --> 404 Page Not Found: /index
INFO - 2018-05-12 03:08:01 --> Config Class Initialized
INFO - 2018-05-12 03:08:01 --> Hooks Class Initialized
DEBUG - 2018-05-12 03:08:01 --> UTF-8 Support Enabled
INFO - 2018-05-12 03:08:01 --> Utf8 Class Initialized
INFO - 2018-05-12 03:08:01 --> URI Class Initialized
INFO - 2018-05-12 03:08:01 --> Router Class Initialized
INFO - 2018-05-12 03:08:01 --> Output Class Initialized
INFO - 2018-05-12 03:08:02 --> Security Class Initialized
DEBUG - 2018-05-12 03:08:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 03:08:02 --> Input Class Initialized
INFO - 2018-05-12 03:08:02 --> Language Class Initialized
ERROR - 2018-05-12 03:08:02 --> 404 Page Not Found: /index
INFO - 2018-05-12 03:10:59 --> Config Class Initialized
INFO - 2018-05-12 03:10:59 --> Hooks Class Initialized
DEBUG - 2018-05-12 03:10:59 --> UTF-8 Support Enabled
INFO - 2018-05-12 03:10:59 --> Utf8 Class Initialized
INFO - 2018-05-12 03:10:59 --> URI Class Initialized
INFO - 2018-05-12 03:10:59 --> Router Class Initialized
INFO - 2018-05-12 03:10:59 --> Output Class Initialized
INFO - 2018-05-12 03:10:59 --> Security Class Initialized
DEBUG - 2018-05-12 03:10:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 03:10:59 --> Input Class Initialized
INFO - 2018-05-12 03:10:59 --> Language Class Initialized
INFO - 2018-05-12 03:10:59 --> Language Class Initialized
INFO - 2018-05-12 03:10:59 --> Config Class Initialized
INFO - 2018-05-12 03:10:59 --> Loader Class Initialized
DEBUG - 2018-05-12 03:10:59 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-12 03:10:59 --> Helper loaded: url_helper
INFO - 2018-05-12 03:10:59 --> Helper loaded: form_helper
INFO - 2018-05-12 03:10:59 --> Helper loaded: date_helper
INFO - 2018-05-12 03:10:59 --> Helper loaded: util_helper
INFO - 2018-05-12 03:10:59 --> Helper loaded: text_helper
INFO - 2018-05-12 03:10:59 --> Helper loaded: string_helper
INFO - 2018-05-12 03:10:59 --> Database Driver Class Initialized
DEBUG - 2018-05-12 03:10:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-12 03:10:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-12 03:10:59 --> Email Class Initialized
INFO - 2018-05-12 03:10:59 --> Controller Class Initialized
DEBUG - 2018-05-12 03:10:59 --> videos MX_Controller Initialized
INFO - 2018-05-12 03:10:59 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-12 03:10:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-05-12 03:10:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-12 03:10:59 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-12 03:10:59 --> Login MX_Controller Initialized
DEBUG - 2018-05-12 03:10:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-12 03:10:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-05-12 03:10:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-05-12 03:10:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-05-12 03:10:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-05-12 03:10:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-05-12 03:10:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/videos/create_video.php
INFO - 2018-05-12 03:10:59 --> Final output sent to browser
DEBUG - 2018-05-12 03:10:59 --> Total execution time: 0.6205
INFO - 2018-05-12 03:11:00 --> Config Class Initialized
INFO - 2018-05-12 03:11:00 --> Hooks Class Initialized
DEBUG - 2018-05-12 03:11:01 --> UTF-8 Support Enabled
INFO - 2018-05-12 03:11:01 --> Utf8 Class Initialized
INFO - 2018-05-12 03:11:01 --> URI Class Initialized
INFO - 2018-05-12 03:11:01 --> Router Class Initialized
INFO - 2018-05-12 03:11:01 --> Output Class Initialized
INFO - 2018-05-12 03:11:01 --> Security Class Initialized
DEBUG - 2018-05-12 03:11:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 03:11:01 --> Input Class Initialized
INFO - 2018-05-12 03:11:01 --> Language Class Initialized
ERROR - 2018-05-12 03:11:01 --> 404 Page Not Found: /index
INFO - 2018-05-12 03:11:41 --> Config Class Initialized
INFO - 2018-05-12 03:11:41 --> Hooks Class Initialized
DEBUG - 2018-05-12 03:11:41 --> UTF-8 Support Enabled
INFO - 2018-05-12 03:11:41 --> Utf8 Class Initialized
INFO - 2018-05-12 03:11:41 --> URI Class Initialized
INFO - 2018-05-12 03:11:41 --> Router Class Initialized
INFO - 2018-05-12 03:11:41 --> Output Class Initialized
INFO - 2018-05-12 03:11:41 --> Security Class Initialized
DEBUG - 2018-05-12 03:11:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 03:11:41 --> Input Class Initialized
INFO - 2018-05-12 03:11:41 --> Language Class Initialized
INFO - 2018-05-12 03:11:41 --> Language Class Initialized
INFO - 2018-05-12 03:11:41 --> Config Class Initialized
INFO - 2018-05-12 03:11:41 --> Loader Class Initialized
DEBUG - 2018-05-12 03:11:41 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-12 03:11:41 --> Helper loaded: url_helper
INFO - 2018-05-12 03:11:41 --> Helper loaded: form_helper
INFO - 2018-05-12 03:11:41 --> Helper loaded: date_helper
INFO - 2018-05-12 03:11:41 --> Helper loaded: util_helper
INFO - 2018-05-12 03:11:41 --> Helper loaded: text_helper
INFO - 2018-05-12 03:11:41 --> Helper loaded: string_helper
INFO - 2018-05-12 03:11:41 --> Database Driver Class Initialized
DEBUG - 2018-05-12 03:11:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-12 03:11:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-12 03:11:41 --> Email Class Initialized
INFO - 2018-05-12 03:11:41 --> Controller Class Initialized
DEBUG - 2018-05-12 03:11:41 --> videos MX_Controller Initialized
INFO - 2018-05-12 03:11:41 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-12 03:11:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-05-12 03:11:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-12 03:11:41 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-12 03:11:41 --> Login MX_Controller Initialized
DEBUG - 2018-05-12 03:11:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-12 03:11:57 --> Config Class Initialized
INFO - 2018-05-12 03:11:57 --> Hooks Class Initialized
DEBUG - 2018-05-12 03:11:57 --> UTF-8 Support Enabled
INFO - 2018-05-12 03:11:57 --> Utf8 Class Initialized
INFO - 2018-05-12 03:11:57 --> URI Class Initialized
INFO - 2018-05-12 03:11:57 --> Router Class Initialized
INFO - 2018-05-12 03:11:57 --> Output Class Initialized
INFO - 2018-05-12 03:11:57 --> Security Class Initialized
DEBUG - 2018-05-12 03:11:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 03:11:57 --> Input Class Initialized
INFO - 2018-05-12 03:11:57 --> Language Class Initialized
INFO - 2018-05-12 03:11:57 --> Language Class Initialized
INFO - 2018-05-12 03:11:57 --> Config Class Initialized
INFO - 2018-05-12 03:11:57 --> Loader Class Initialized
DEBUG - 2018-05-12 03:11:57 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-12 03:11:58 --> Helper loaded: url_helper
INFO - 2018-05-12 03:11:58 --> Helper loaded: form_helper
INFO - 2018-05-12 03:11:58 --> Helper loaded: date_helper
INFO - 2018-05-12 03:11:58 --> Helper loaded: util_helper
INFO - 2018-05-12 03:11:58 --> Helper loaded: text_helper
INFO - 2018-05-12 03:11:58 --> Helper loaded: string_helper
INFO - 2018-05-12 03:11:58 --> Database Driver Class Initialized
DEBUG - 2018-05-12 03:11:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-12 03:11:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-12 03:11:58 --> Email Class Initialized
INFO - 2018-05-12 03:11:58 --> Controller Class Initialized
DEBUG - 2018-05-12 03:11:58 --> videos MX_Controller Initialized
INFO - 2018-05-12 03:11:58 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-12 03:11:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-05-12 03:11:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-12 03:11:58 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-12 03:11:58 --> Login MX_Controller Initialized
DEBUG - 2018-05-12 03:11:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
ERROR - 2018-05-12 03:11:58 --> Severity: Notice --> Undefined index: n_name E:\xampp\htdocs\consulting\application\modules\admin\controllers\Videos.php 120
ERROR - 2018-05-12 03:11:58 --> Severity: Notice --> Undefined property: CI::$upload_model E:\xampp\htdocs\consulting\application\third_party\MX\Controller.php 59
ERROR - 2018-05-12 03:11:58 --> Severity: error --> Exception: Call to a member function uploadDocuments() on null E:\xampp\htdocs\consulting\application\modules\admin\controllers\Videos.php 129
INFO - 2018-05-12 03:12:42 --> Config Class Initialized
INFO - 2018-05-12 03:12:42 --> Hooks Class Initialized
DEBUG - 2018-05-12 03:12:42 --> UTF-8 Support Enabled
INFO - 2018-05-12 03:12:42 --> Utf8 Class Initialized
INFO - 2018-05-12 03:12:42 --> URI Class Initialized
INFO - 2018-05-12 03:12:42 --> Router Class Initialized
INFO - 2018-05-12 03:12:42 --> Output Class Initialized
INFO - 2018-05-12 03:12:42 --> Security Class Initialized
DEBUG - 2018-05-12 03:12:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 03:12:42 --> Input Class Initialized
INFO - 2018-05-12 03:12:42 --> Language Class Initialized
INFO - 2018-05-12 03:12:42 --> Language Class Initialized
INFO - 2018-05-12 03:12:42 --> Config Class Initialized
INFO - 2018-05-12 03:12:42 --> Loader Class Initialized
DEBUG - 2018-05-12 03:12:42 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-12 03:12:42 --> Helper loaded: url_helper
INFO - 2018-05-12 03:12:42 --> Helper loaded: form_helper
INFO - 2018-05-12 03:12:42 --> Helper loaded: date_helper
INFO - 2018-05-12 03:12:42 --> Helper loaded: util_helper
INFO - 2018-05-12 03:12:42 --> Helper loaded: text_helper
INFO - 2018-05-12 03:12:42 --> Helper loaded: string_helper
INFO - 2018-05-12 03:12:42 --> Database Driver Class Initialized
DEBUG - 2018-05-12 03:12:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-12 03:12:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-12 03:12:42 --> Email Class Initialized
INFO - 2018-05-12 03:12:42 --> Controller Class Initialized
DEBUG - 2018-05-12 03:12:42 --> videos MX_Controller Initialized
INFO - 2018-05-12 03:12:42 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-12 03:12:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-05-12 03:12:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-12 03:12:42 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-12 03:12:42 --> Login MX_Controller Initialized
DEBUG - 2018-05-12 03:12:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
ERROR - 2018-05-12 03:12:42 --> Severity: Notice --> Undefined property: CI::$upload_model E:\xampp\htdocs\consulting\application\third_party\MX\Controller.php 59
ERROR - 2018-05-12 03:12:42 --> Severity: error --> Exception: Call to a member function uploadDocuments() on null E:\xampp\htdocs\consulting\application\modules\admin\controllers\Videos.php 125
INFO - 2018-05-12 03:13:07 --> Config Class Initialized
INFO - 2018-05-12 03:13:07 --> Hooks Class Initialized
DEBUG - 2018-05-12 03:13:07 --> UTF-8 Support Enabled
INFO - 2018-05-12 03:13:07 --> Utf8 Class Initialized
INFO - 2018-05-12 03:13:07 --> URI Class Initialized
INFO - 2018-05-12 03:13:07 --> Router Class Initialized
INFO - 2018-05-12 03:13:07 --> Output Class Initialized
INFO - 2018-05-12 03:13:07 --> Security Class Initialized
DEBUG - 2018-05-12 03:13:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 03:13:07 --> Input Class Initialized
INFO - 2018-05-12 03:13:07 --> Language Class Initialized
INFO - 2018-05-12 03:13:07 --> Language Class Initialized
INFO - 2018-05-12 03:13:07 --> Config Class Initialized
INFO - 2018-05-12 03:13:07 --> Loader Class Initialized
DEBUG - 2018-05-12 03:13:07 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-12 03:13:07 --> Helper loaded: url_helper
INFO - 2018-05-12 03:13:07 --> Helper loaded: form_helper
INFO - 2018-05-12 03:13:07 --> Helper loaded: date_helper
INFO - 2018-05-12 03:13:07 --> Helper loaded: util_helper
INFO - 2018-05-12 03:13:07 --> Helper loaded: text_helper
INFO - 2018-05-12 03:13:07 --> Helper loaded: string_helper
INFO - 2018-05-12 03:13:07 --> Database Driver Class Initialized
DEBUG - 2018-05-12 03:13:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-12 03:13:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-12 03:13:07 --> Email Class Initialized
INFO - 2018-05-12 03:13:07 --> Controller Class Initialized
DEBUG - 2018-05-12 03:13:07 --> videos MX_Controller Initialized
INFO - 2018-05-12 03:13:07 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-12 03:13:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-05-12 03:13:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-12 03:13:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-05-12 03:13:07 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-12 03:13:08 --> Login MX_Controller Initialized
DEBUG - 2018-05-12 03:13:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-12 03:13:08 --> Upload Class Initialized
INFO - 2018-05-12 03:24:30 --> Config Class Initialized
INFO - 2018-05-12 03:24:30 --> Hooks Class Initialized
DEBUG - 2018-05-12 03:24:30 --> UTF-8 Support Enabled
INFO - 2018-05-12 03:24:30 --> Utf8 Class Initialized
INFO - 2018-05-12 03:24:30 --> URI Class Initialized
INFO - 2018-05-12 03:24:30 --> Router Class Initialized
INFO - 2018-05-12 03:24:30 --> Output Class Initialized
INFO - 2018-05-12 03:24:30 --> Security Class Initialized
DEBUG - 2018-05-12 03:24:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 03:24:30 --> Input Class Initialized
INFO - 2018-05-12 03:24:30 --> Language Class Initialized
INFO - 2018-05-12 03:24:30 --> Language Class Initialized
INFO - 2018-05-12 03:24:30 --> Config Class Initialized
INFO - 2018-05-12 03:24:30 --> Loader Class Initialized
DEBUG - 2018-05-12 03:24:30 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-12 03:24:30 --> Helper loaded: url_helper
INFO - 2018-05-12 03:24:30 --> Helper loaded: form_helper
INFO - 2018-05-12 03:24:30 --> Helper loaded: date_helper
INFO - 2018-05-12 03:24:30 --> Helper loaded: util_helper
INFO - 2018-05-12 03:24:30 --> Helper loaded: text_helper
INFO - 2018-05-12 03:24:30 --> Helper loaded: string_helper
INFO - 2018-05-12 03:24:30 --> Database Driver Class Initialized
DEBUG - 2018-05-12 03:24:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-12 03:24:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-12 03:24:30 --> Email Class Initialized
INFO - 2018-05-12 03:24:30 --> Controller Class Initialized
DEBUG - 2018-05-12 03:24:30 --> videos MX_Controller Initialized
INFO - 2018-05-12 03:24:30 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-12 03:24:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-05-12 03:24:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-12 03:24:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-05-12 03:24:30 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-12 03:24:30 --> Login MX_Controller Initialized
DEBUG - 2018-05-12 03:24:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-12 03:24:30 --> Upload Class Initialized
INFO - 2018-05-12 03:24:30 --> Config Class Initialized
INFO - 2018-05-12 03:24:30 --> Hooks Class Initialized
DEBUG - 2018-05-12 03:24:30 --> UTF-8 Support Enabled
INFO - 2018-05-12 03:24:31 --> Utf8 Class Initialized
INFO - 2018-05-12 03:24:31 --> URI Class Initialized
INFO - 2018-05-12 03:24:31 --> Router Class Initialized
INFO - 2018-05-12 03:24:31 --> Output Class Initialized
INFO - 2018-05-12 03:24:31 --> Security Class Initialized
DEBUG - 2018-05-12 03:24:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 03:24:31 --> Input Class Initialized
INFO - 2018-05-12 03:24:31 --> Language Class Initialized
INFO - 2018-05-12 03:24:31 --> Language Class Initialized
INFO - 2018-05-12 03:24:31 --> Config Class Initialized
INFO - 2018-05-12 03:24:31 --> Loader Class Initialized
DEBUG - 2018-05-12 03:24:31 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-12 03:24:31 --> Helper loaded: url_helper
INFO - 2018-05-12 03:24:31 --> Helper loaded: form_helper
INFO - 2018-05-12 03:24:31 --> Helper loaded: date_helper
INFO - 2018-05-12 03:24:31 --> Helper loaded: util_helper
INFO - 2018-05-12 03:24:31 --> Helper loaded: text_helper
INFO - 2018-05-12 03:24:31 --> Helper loaded: string_helper
INFO - 2018-05-12 03:24:31 --> Database Driver Class Initialized
DEBUG - 2018-05-12 03:24:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-12 03:24:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-12 03:24:31 --> Email Class Initialized
INFO - 2018-05-12 03:24:31 --> Controller Class Initialized
DEBUG - 2018-05-12 03:24:31 --> videos MX_Controller Initialized
INFO - 2018-05-12 03:24:31 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-12 03:24:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-05-12 03:24:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-12 03:24:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-05-12 03:24:31 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-12 03:24:31 --> Login MX_Controller Initialized
DEBUG - 2018-05-12 03:24:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-12 03:24:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-05-12 03:24:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-05-12 03:24:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-05-12 03:24:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-05-12 03:24:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-05-12 03:24:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/videos/videos.php
INFO - 2018-05-12 03:24:31 --> Final output sent to browser
DEBUG - 2018-05-12 03:24:31 --> Total execution time: 0.6947
INFO - 2018-05-12 03:24:32 --> Config Class Initialized
INFO - 2018-05-12 03:24:32 --> Hooks Class Initialized
DEBUG - 2018-05-12 03:24:32 --> UTF-8 Support Enabled
INFO - 2018-05-12 03:24:32 --> Utf8 Class Initialized
INFO - 2018-05-12 03:24:32 --> URI Class Initialized
INFO - 2018-05-12 03:24:32 --> Router Class Initialized
INFO - 2018-05-12 03:24:32 --> Output Class Initialized
INFO - 2018-05-12 03:24:32 --> Security Class Initialized
DEBUG - 2018-05-12 03:24:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 03:24:32 --> Input Class Initialized
INFO - 2018-05-12 03:24:32 --> Language Class Initialized
INFO - 2018-05-12 03:24:32 --> Language Class Initialized
INFO - 2018-05-12 03:24:32 --> Config Class Initialized
INFO - 2018-05-12 03:24:32 --> Loader Class Initialized
DEBUG - 2018-05-12 03:24:32 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-12 03:24:32 --> Helper loaded: url_helper
INFO - 2018-05-12 03:24:32 --> Helper loaded: form_helper
INFO - 2018-05-12 03:24:32 --> Helper loaded: date_helper
INFO - 2018-05-12 03:24:32 --> Helper loaded: util_helper
INFO - 2018-05-12 03:24:32 --> Helper loaded: text_helper
INFO - 2018-05-12 03:24:32 --> Helper loaded: string_helper
INFO - 2018-05-12 03:24:33 --> Database Driver Class Initialized
DEBUG - 2018-05-12 03:24:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-12 03:24:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-12 03:24:33 --> Email Class Initialized
INFO - 2018-05-12 03:24:33 --> Controller Class Initialized
DEBUG - 2018-05-12 03:24:33 --> videos MX_Controller Initialized
INFO - 2018-05-12 03:24:33 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-12 03:24:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-05-12 03:24:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-12 03:24:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-05-12 03:24:33 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-12 03:24:33 --> Login MX_Controller Initialized
DEBUG - 2018-05-12 03:24:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-12 03:24:33 --> Final output sent to browser
DEBUG - 2018-05-12 03:24:33 --> Total execution time: 0.8121
INFO - 2018-05-12 03:24:45 --> Config Class Initialized
INFO - 2018-05-12 03:24:45 --> Hooks Class Initialized
DEBUG - 2018-05-12 03:24:45 --> UTF-8 Support Enabled
INFO - 2018-05-12 03:24:45 --> Utf8 Class Initialized
INFO - 2018-05-12 03:24:45 --> URI Class Initialized
INFO - 2018-05-12 03:24:45 --> Router Class Initialized
INFO - 2018-05-12 03:24:45 --> Output Class Initialized
INFO - 2018-05-12 03:24:45 --> Security Class Initialized
DEBUG - 2018-05-12 03:24:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 03:24:45 --> Input Class Initialized
INFO - 2018-05-12 03:24:45 --> Language Class Initialized
INFO - 2018-05-12 03:24:45 --> Language Class Initialized
INFO - 2018-05-12 03:24:45 --> Config Class Initialized
INFO - 2018-05-12 03:24:45 --> Loader Class Initialized
DEBUG - 2018-05-12 03:24:45 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-12 03:24:45 --> Helper loaded: url_helper
INFO - 2018-05-12 03:24:45 --> Helper loaded: form_helper
INFO - 2018-05-12 03:24:45 --> Helper loaded: date_helper
INFO - 2018-05-12 03:24:45 --> Helper loaded: util_helper
INFO - 2018-05-12 03:24:45 --> Helper loaded: text_helper
INFO - 2018-05-12 03:24:45 --> Helper loaded: string_helper
INFO - 2018-05-12 03:24:45 --> Database Driver Class Initialized
DEBUG - 2018-05-12 03:24:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-12 03:24:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-12 03:24:45 --> Email Class Initialized
INFO - 2018-05-12 03:24:45 --> Controller Class Initialized
DEBUG - 2018-05-12 03:24:45 --> videos MX_Controller Initialized
INFO - 2018-05-12 03:24:45 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-12 03:24:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-05-12 03:24:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-12 03:24:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-05-12 03:24:45 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-12 03:24:45 --> Login MX_Controller Initialized
DEBUG - 2018-05-12 03:24:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-12 03:24:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-05-12 03:24:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-05-12 03:24:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-05-12 03:24:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-05-12 03:24:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-05-12 03:24:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/videos/create_video.php
INFO - 2018-05-12 03:24:45 --> Final output sent to browser
DEBUG - 2018-05-12 03:24:45 --> Total execution time: 0.6152
INFO - 2018-05-12 03:24:46 --> Config Class Initialized
INFO - 2018-05-12 03:24:46 --> Hooks Class Initialized
DEBUG - 2018-05-12 03:24:46 --> UTF-8 Support Enabled
INFO - 2018-05-12 03:24:46 --> Utf8 Class Initialized
INFO - 2018-05-12 03:24:46 --> URI Class Initialized
INFO - 2018-05-12 03:24:46 --> Router Class Initialized
INFO - 2018-05-12 03:24:46 --> Output Class Initialized
INFO - 2018-05-12 03:24:46 --> Security Class Initialized
DEBUG - 2018-05-12 03:24:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 03:24:46 --> Input Class Initialized
INFO - 2018-05-12 03:24:46 --> Language Class Initialized
ERROR - 2018-05-12 03:24:46 --> 404 Page Not Found: /index
INFO - 2018-05-12 03:24:49 --> Config Class Initialized
INFO - 2018-05-12 03:24:49 --> Hooks Class Initialized
DEBUG - 2018-05-12 03:24:49 --> UTF-8 Support Enabled
INFO - 2018-05-12 03:24:49 --> Utf8 Class Initialized
INFO - 2018-05-12 03:24:49 --> URI Class Initialized
INFO - 2018-05-12 03:24:49 --> Router Class Initialized
INFO - 2018-05-12 03:24:49 --> Output Class Initialized
INFO - 2018-05-12 03:24:49 --> Security Class Initialized
DEBUG - 2018-05-12 03:24:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 03:24:49 --> Input Class Initialized
INFO - 2018-05-12 03:24:49 --> Language Class Initialized
INFO - 2018-05-12 03:24:49 --> Language Class Initialized
INFO - 2018-05-12 03:24:49 --> Config Class Initialized
INFO - 2018-05-12 03:24:49 --> Loader Class Initialized
DEBUG - 2018-05-12 03:24:49 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-12 03:24:49 --> Helper loaded: url_helper
INFO - 2018-05-12 03:24:49 --> Helper loaded: form_helper
INFO - 2018-05-12 03:24:49 --> Helper loaded: date_helper
INFO - 2018-05-12 03:24:49 --> Helper loaded: util_helper
INFO - 2018-05-12 03:24:49 --> Helper loaded: text_helper
INFO - 2018-05-12 03:24:49 --> Helper loaded: string_helper
INFO - 2018-05-12 03:24:49 --> Database Driver Class Initialized
DEBUG - 2018-05-12 03:24:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-12 03:24:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-12 03:24:49 --> Email Class Initialized
INFO - 2018-05-12 03:24:49 --> Controller Class Initialized
DEBUG - 2018-05-12 03:24:49 --> videos MX_Controller Initialized
INFO - 2018-05-12 03:24:49 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-12 03:24:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-05-12 03:24:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-12 03:24:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-05-12 03:24:49 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-12 03:24:49 --> Login MX_Controller Initialized
DEBUG - 2018-05-12 03:24:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-12 03:24:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-05-12 03:24:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-05-12 03:24:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-05-12 03:24:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-05-12 03:24:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-05-12 03:24:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/videos/videos.php
INFO - 2018-05-12 03:24:49 --> Final output sent to browser
DEBUG - 2018-05-12 03:24:49 --> Total execution time: 0.6481
INFO - 2018-05-12 03:24:50 --> Config Class Initialized
INFO - 2018-05-12 03:24:50 --> Hooks Class Initialized
DEBUG - 2018-05-12 03:24:50 --> UTF-8 Support Enabled
INFO - 2018-05-12 03:24:50 --> Utf8 Class Initialized
INFO - 2018-05-12 03:24:50 --> URI Class Initialized
INFO - 2018-05-12 03:24:50 --> Router Class Initialized
INFO - 2018-05-12 03:24:50 --> Output Class Initialized
INFO - 2018-05-12 03:24:51 --> Security Class Initialized
DEBUG - 2018-05-12 03:24:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 03:24:51 --> Input Class Initialized
INFO - 2018-05-12 03:24:51 --> Language Class Initialized
INFO - 2018-05-12 03:24:51 --> Language Class Initialized
INFO - 2018-05-12 03:24:51 --> Config Class Initialized
INFO - 2018-05-12 03:24:51 --> Loader Class Initialized
DEBUG - 2018-05-12 03:24:51 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-12 03:24:51 --> Helper loaded: url_helper
INFO - 2018-05-12 03:24:51 --> Helper loaded: form_helper
INFO - 2018-05-12 03:24:51 --> Helper loaded: date_helper
INFO - 2018-05-12 03:24:51 --> Helper loaded: util_helper
INFO - 2018-05-12 03:24:51 --> Helper loaded: text_helper
INFO - 2018-05-12 03:24:51 --> Helper loaded: string_helper
INFO - 2018-05-12 03:24:51 --> Database Driver Class Initialized
DEBUG - 2018-05-12 03:24:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-12 03:24:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-12 03:24:51 --> Email Class Initialized
INFO - 2018-05-12 03:24:51 --> Controller Class Initialized
DEBUG - 2018-05-12 03:24:51 --> videos MX_Controller Initialized
INFO - 2018-05-12 03:24:51 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-12 03:24:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-05-12 03:24:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-12 03:24:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-05-12 03:24:51 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-12 03:24:51 --> Login MX_Controller Initialized
DEBUG - 2018-05-12 03:24:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-12 03:24:51 --> Final output sent to browser
DEBUG - 2018-05-12 03:24:51 --> Total execution time: 0.8052
INFO - 2018-05-12 03:24:53 --> Config Class Initialized
INFO - 2018-05-12 03:24:53 --> Hooks Class Initialized
DEBUG - 2018-05-12 03:24:53 --> UTF-8 Support Enabled
INFO - 2018-05-12 03:24:53 --> Utf8 Class Initialized
INFO - 2018-05-12 03:24:53 --> URI Class Initialized
INFO - 2018-05-12 03:24:53 --> Router Class Initialized
INFO - 2018-05-12 03:24:53 --> Output Class Initialized
INFO - 2018-05-12 03:24:53 --> Security Class Initialized
DEBUG - 2018-05-12 03:24:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 03:24:53 --> Input Class Initialized
INFO - 2018-05-12 03:24:53 --> Language Class Initialized
INFO - 2018-05-12 03:24:53 --> Language Class Initialized
INFO - 2018-05-12 03:24:53 --> Config Class Initialized
INFO - 2018-05-12 03:24:53 --> Loader Class Initialized
DEBUG - 2018-05-12 03:24:53 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-12 03:24:53 --> Helper loaded: url_helper
INFO - 2018-05-12 03:24:53 --> Helper loaded: form_helper
INFO - 2018-05-12 03:24:53 --> Helper loaded: date_helper
INFO - 2018-05-12 03:24:53 --> Helper loaded: util_helper
INFO - 2018-05-12 03:24:53 --> Helper loaded: text_helper
INFO - 2018-05-12 03:24:53 --> Helper loaded: string_helper
INFO - 2018-05-12 03:24:53 --> Database Driver Class Initialized
DEBUG - 2018-05-12 03:24:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-12 03:24:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-12 03:24:53 --> Email Class Initialized
INFO - 2018-05-12 03:24:53 --> Controller Class Initialized
DEBUG - 2018-05-12 03:24:53 --> videos MX_Controller Initialized
INFO - 2018-05-12 03:24:53 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-12 03:24:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-05-12 03:24:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-12 03:24:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-05-12 03:24:53 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-12 03:24:53 --> Login MX_Controller Initialized
DEBUG - 2018-05-12 03:24:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-12 03:24:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-05-12 03:24:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-05-12 03:24:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-05-12 03:24:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-05-12 03:24:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-05-12 03:24:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/videos/create_video.php
INFO - 2018-05-12 03:24:53 --> Final output sent to browser
DEBUG - 2018-05-12 03:24:54 --> Total execution time: 0.6190
INFO - 2018-05-12 03:24:54 --> Config Class Initialized
INFO - 2018-05-12 03:24:54 --> Hooks Class Initialized
DEBUG - 2018-05-12 03:24:54 --> UTF-8 Support Enabled
INFO - 2018-05-12 03:24:54 --> Utf8 Class Initialized
INFO - 2018-05-12 03:24:54 --> URI Class Initialized
INFO - 2018-05-12 03:24:54 --> Router Class Initialized
INFO - 2018-05-12 03:24:54 --> Output Class Initialized
INFO - 2018-05-12 03:24:54 --> Security Class Initialized
DEBUG - 2018-05-12 03:24:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 03:24:54 --> Input Class Initialized
INFO - 2018-05-12 03:24:54 --> Language Class Initialized
INFO - 2018-05-12 03:24:54 --> Language Class Initialized
INFO - 2018-05-12 03:24:54 --> Config Class Initialized
INFO - 2018-05-12 03:24:54 --> Loader Class Initialized
DEBUG - 2018-05-12 03:24:54 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-12 03:24:54 --> Helper loaded: url_helper
INFO - 2018-05-12 03:24:54 --> Helper loaded: form_helper
INFO - 2018-05-12 03:24:54 --> Helper loaded: date_helper
INFO - 2018-05-12 03:24:54 --> Config Class Initialized
INFO - 2018-05-12 03:24:54 --> Hooks Class Initialized
INFO - 2018-05-12 03:24:54 --> Helper loaded: util_helper
INFO - 2018-05-12 03:24:54 --> Helper loaded: text_helper
DEBUG - 2018-05-12 03:24:54 --> UTF-8 Support Enabled
INFO - 2018-05-12 03:24:54 --> Helper loaded: string_helper
INFO - 2018-05-12 03:24:54 --> Database Driver Class Initialized
INFO - 2018-05-12 03:24:54 --> Utf8 Class Initialized
DEBUG - 2018-05-12 03:24:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-12 03:24:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-12 03:24:54 --> URI Class Initialized
INFO - 2018-05-12 03:24:54 --> Email Class Initialized
INFO - 2018-05-12 03:24:54 --> Router Class Initialized
INFO - 2018-05-12 03:24:55 --> Controller Class Initialized
DEBUG - 2018-05-12 03:24:55 --> videos MX_Controller Initialized
INFO - 2018-05-12 03:24:55 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-12 03:24:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-05-12 03:24:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-12 03:24:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
INFO - 2018-05-12 03:24:55 --> Output Class Initialized
DEBUG - 2018-05-12 03:24:55 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
INFO - 2018-05-12 03:24:55 --> Security Class Initialized
DEBUG - 2018-05-12 03:24:55 --> Login MX_Controller Initialized
DEBUG - 2018-05-12 03:24:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-12 03:24:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-12 03:24:55 --> Input Class Initialized
INFO - 2018-05-12 03:24:55 --> Language Class Initialized
DEBUG - 2018-05-12 03:24:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-05-12 03:24:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
ERROR - 2018-05-12 03:24:55 --> 404 Page Not Found: /index
DEBUG - 2018-05-12 03:24:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-05-12 03:24:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-05-12 03:24:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-05-12 03:24:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/videos/create_video.php
INFO - 2018-05-12 03:24:55 --> Final output sent to browser
DEBUG - 2018-05-12 03:24:55 --> Total execution time: 1.0699
INFO - 2018-05-12 03:26:50 --> Config Class Initialized
INFO - 2018-05-12 03:26:50 --> Hooks Class Initialized
DEBUG - 2018-05-12 03:26:50 --> UTF-8 Support Enabled
INFO - 2018-05-12 03:26:50 --> Utf8 Class Initialized
INFO - 2018-05-12 03:26:50 --> URI Class Initialized
INFO - 2018-05-12 03:26:50 --> Router Class Initialized
INFO - 2018-05-12 03:26:50 --> Output Class Initialized
INFO - 2018-05-12 03:26:50 --> Security Class Initialized
DEBUG - 2018-05-12 03:26:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 03:26:50 --> Input Class Initialized
INFO - 2018-05-12 03:26:50 --> Language Class Initialized
INFO - 2018-05-12 03:26:50 --> Language Class Initialized
INFO - 2018-05-12 03:26:50 --> Config Class Initialized
INFO - 2018-05-12 03:26:50 --> Loader Class Initialized
DEBUG - 2018-05-12 03:26:50 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-12 03:26:50 --> Helper loaded: url_helper
INFO - 2018-05-12 03:26:50 --> Helper loaded: form_helper
INFO - 2018-05-12 03:26:50 --> Helper loaded: date_helper
INFO - 2018-05-12 03:26:50 --> Helper loaded: util_helper
INFO - 2018-05-12 03:26:50 --> Helper loaded: text_helper
INFO - 2018-05-12 03:26:50 --> Helper loaded: string_helper
INFO - 2018-05-12 03:26:50 --> Database Driver Class Initialized
DEBUG - 2018-05-12 03:26:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-12 03:26:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-12 03:26:50 --> Email Class Initialized
INFO - 2018-05-12 03:26:50 --> Controller Class Initialized
DEBUG - 2018-05-12 03:26:50 --> videos MX_Controller Initialized
INFO - 2018-05-12 03:26:50 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-12 03:26:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-05-12 03:26:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-12 03:26:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-05-12 03:26:50 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-12 03:26:50 --> Login MX_Controller Initialized
DEBUG - 2018-05-12 03:26:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-12 03:26:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-05-12 03:26:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-05-12 03:26:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-05-12 03:26:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-05-12 03:26:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-05-12 03:26:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/videos/create_video.php
INFO - 2018-05-12 03:26:50 --> Final output sent to browser
DEBUG - 2018-05-12 03:26:51 --> Total execution time: 0.6323
INFO - 2018-05-12 03:26:51 --> Config Class Initialized
INFO - 2018-05-12 03:26:51 --> Hooks Class Initialized
DEBUG - 2018-05-12 03:26:51 --> UTF-8 Support Enabled
INFO - 2018-05-12 03:26:51 --> Utf8 Class Initialized
INFO - 2018-05-12 03:26:51 --> URI Class Initialized
INFO - 2018-05-12 03:26:51 --> Router Class Initialized
INFO - 2018-05-12 03:26:51 --> Output Class Initialized
INFO - 2018-05-12 03:26:51 --> Security Class Initialized
DEBUG - 2018-05-12 03:26:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 03:26:51 --> Input Class Initialized
INFO - 2018-05-12 03:26:51 --> Language Class Initialized
ERROR - 2018-05-12 03:26:51 --> 404 Page Not Found: /index
INFO - 2018-05-12 03:26:56 --> Config Class Initialized
INFO - 2018-05-12 03:26:56 --> Hooks Class Initialized
DEBUG - 2018-05-12 03:26:56 --> UTF-8 Support Enabled
INFO - 2018-05-12 03:26:56 --> Utf8 Class Initialized
INFO - 2018-05-12 03:26:56 --> URI Class Initialized
INFO - 2018-05-12 03:26:56 --> Router Class Initialized
INFO - 2018-05-12 03:26:57 --> Output Class Initialized
INFO - 2018-05-12 03:26:57 --> Security Class Initialized
DEBUG - 2018-05-12 03:26:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 03:26:57 --> Input Class Initialized
INFO - 2018-05-12 03:26:57 --> Language Class Initialized
ERROR - 2018-05-12 03:26:57 --> 404 Page Not Found: /index
INFO - 2018-05-12 03:27:04 --> Config Class Initialized
INFO - 2018-05-12 03:27:04 --> Hooks Class Initialized
DEBUG - 2018-05-12 03:27:04 --> UTF-8 Support Enabled
INFO - 2018-05-12 03:27:04 --> Utf8 Class Initialized
INFO - 2018-05-12 03:27:04 --> URI Class Initialized
INFO - 2018-05-12 03:27:04 --> Router Class Initialized
INFO - 2018-05-12 03:27:04 --> Output Class Initialized
INFO - 2018-05-12 03:27:04 --> Security Class Initialized
DEBUG - 2018-05-12 03:27:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 03:27:04 --> Input Class Initialized
INFO - 2018-05-12 03:27:04 --> Language Class Initialized
ERROR - 2018-05-12 03:27:04 --> 404 Page Not Found: /index
INFO - 2018-05-12 03:27:15 --> Config Class Initialized
INFO - 2018-05-12 03:27:15 --> Hooks Class Initialized
DEBUG - 2018-05-12 03:27:15 --> UTF-8 Support Enabled
INFO - 2018-05-12 03:27:15 --> Utf8 Class Initialized
INFO - 2018-05-12 03:27:15 --> URI Class Initialized
INFO - 2018-05-12 03:27:15 --> Router Class Initialized
INFO - 2018-05-12 03:27:15 --> Output Class Initialized
INFO - 2018-05-12 03:27:15 --> Security Class Initialized
DEBUG - 2018-05-12 03:27:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 03:27:15 --> Input Class Initialized
INFO - 2018-05-12 03:27:15 --> Language Class Initialized
INFO - 2018-05-12 03:27:15 --> Language Class Initialized
INFO - 2018-05-12 03:27:15 --> Config Class Initialized
INFO - 2018-05-12 03:27:15 --> Loader Class Initialized
DEBUG - 2018-05-12 03:27:15 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-12 03:27:15 --> Helper loaded: url_helper
INFO - 2018-05-12 03:27:15 --> Helper loaded: form_helper
INFO - 2018-05-12 03:27:15 --> Helper loaded: date_helper
INFO - 2018-05-12 03:27:15 --> Helper loaded: util_helper
INFO - 2018-05-12 03:27:15 --> Helper loaded: text_helper
INFO - 2018-05-12 03:27:15 --> Helper loaded: string_helper
INFO - 2018-05-12 03:27:15 --> Database Driver Class Initialized
DEBUG - 2018-05-12 03:27:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-12 03:27:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-12 03:27:15 --> Email Class Initialized
INFO - 2018-05-12 03:27:15 --> Controller Class Initialized
DEBUG - 2018-05-12 03:27:15 --> videos MX_Controller Initialized
INFO - 2018-05-12 03:27:15 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-12 03:27:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-05-12 03:27:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-12 03:27:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-05-12 03:27:15 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-12 03:27:15 --> Login MX_Controller Initialized
DEBUG - 2018-05-12 03:27:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-12 03:27:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-05-12 03:27:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-05-12 03:27:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-05-12 03:27:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-05-12 03:27:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-05-12 03:27:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/videos/create_video.php
INFO - 2018-05-12 03:27:16 --> Final output sent to browser
DEBUG - 2018-05-12 03:27:16 --> Total execution time: 0.8329
INFO - 2018-05-12 03:27:17 --> Config Class Initialized
INFO - 2018-05-12 03:27:17 --> Hooks Class Initialized
DEBUG - 2018-05-12 03:27:17 --> UTF-8 Support Enabled
INFO - 2018-05-12 03:27:17 --> Utf8 Class Initialized
INFO - 2018-05-12 03:27:17 --> URI Class Initialized
INFO - 2018-05-12 03:27:17 --> Router Class Initialized
INFO - 2018-05-12 03:27:17 --> Output Class Initialized
INFO - 2018-05-12 03:27:17 --> Security Class Initialized
DEBUG - 2018-05-12 03:27:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 03:27:17 --> Input Class Initialized
INFO - 2018-05-12 03:27:17 --> Language Class Initialized
ERROR - 2018-05-12 03:27:17 --> 404 Page Not Found: /index
INFO - 2018-05-12 03:27:56 --> Config Class Initialized
INFO - 2018-05-12 03:27:56 --> Hooks Class Initialized
DEBUG - 2018-05-12 03:27:57 --> UTF-8 Support Enabled
INFO - 2018-05-12 03:27:57 --> Utf8 Class Initialized
INFO - 2018-05-12 03:27:57 --> URI Class Initialized
INFO - 2018-05-12 03:27:57 --> Router Class Initialized
INFO - 2018-05-12 03:27:57 --> Output Class Initialized
INFO - 2018-05-12 03:27:57 --> Security Class Initialized
DEBUG - 2018-05-12 03:27:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 03:27:57 --> Input Class Initialized
INFO - 2018-05-12 03:27:57 --> Language Class Initialized
INFO - 2018-05-12 03:27:57 --> Language Class Initialized
INFO - 2018-05-12 03:27:57 --> Config Class Initialized
INFO - 2018-05-12 03:27:57 --> Loader Class Initialized
DEBUG - 2018-05-12 03:27:57 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-12 03:27:57 --> Helper loaded: url_helper
INFO - 2018-05-12 03:27:57 --> Helper loaded: form_helper
INFO - 2018-05-12 03:27:57 --> Helper loaded: date_helper
INFO - 2018-05-12 03:27:57 --> Helper loaded: util_helper
INFO - 2018-05-12 03:27:57 --> Helper loaded: text_helper
INFO - 2018-05-12 03:27:57 --> Helper loaded: string_helper
INFO - 2018-05-12 03:27:57 --> Database Driver Class Initialized
DEBUG - 2018-05-12 03:27:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-12 03:27:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-12 03:27:57 --> Email Class Initialized
INFO - 2018-05-12 03:27:57 --> Controller Class Initialized
DEBUG - 2018-05-12 03:27:57 --> videos MX_Controller Initialized
INFO - 2018-05-12 03:27:57 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-12 03:27:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-05-12 03:27:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-12 03:27:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-05-12 03:27:57 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-12 03:27:57 --> Login MX_Controller Initialized
DEBUG - 2018-05-12 03:27:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-12 03:27:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-05-12 03:27:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-05-12 03:27:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-05-12 03:27:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-05-12 03:27:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-05-12 03:27:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/videos/create_video.php
INFO - 2018-05-12 03:27:57 --> Final output sent to browser
DEBUG - 2018-05-12 03:27:57 --> Total execution time: 0.6954
INFO - 2018-05-12 03:30:49 --> Config Class Initialized
INFO - 2018-05-12 03:30:49 --> Hooks Class Initialized
DEBUG - 2018-05-12 03:30:49 --> UTF-8 Support Enabled
INFO - 2018-05-12 03:30:49 --> Utf8 Class Initialized
INFO - 2018-05-12 03:30:49 --> URI Class Initialized
INFO - 2018-05-12 03:30:49 --> Router Class Initialized
INFO - 2018-05-12 03:30:49 --> Output Class Initialized
INFO - 2018-05-12 03:30:49 --> Security Class Initialized
DEBUG - 2018-05-12 03:30:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 03:30:49 --> Input Class Initialized
INFO - 2018-05-12 03:30:49 --> Language Class Initialized
INFO - 2018-05-12 03:30:49 --> Language Class Initialized
INFO - 2018-05-12 03:30:49 --> Config Class Initialized
INFO - 2018-05-12 03:30:49 --> Loader Class Initialized
DEBUG - 2018-05-12 03:30:49 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-12 03:30:49 --> Helper loaded: url_helper
INFO - 2018-05-12 03:30:49 --> Helper loaded: form_helper
INFO - 2018-05-12 03:30:49 --> Helper loaded: date_helper
INFO - 2018-05-12 03:30:49 --> Helper loaded: util_helper
INFO - 2018-05-12 03:30:49 --> Helper loaded: text_helper
INFO - 2018-05-12 03:30:49 --> Helper loaded: string_helper
INFO - 2018-05-12 03:30:49 --> Database Driver Class Initialized
DEBUG - 2018-05-12 03:30:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-12 03:30:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-12 03:30:49 --> Email Class Initialized
INFO - 2018-05-12 03:30:49 --> Controller Class Initialized
DEBUG - 2018-05-12 03:30:49 --> videos MX_Controller Initialized
INFO - 2018-05-12 03:30:49 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-12 03:30:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-05-12 03:30:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-12 03:30:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-05-12 03:30:49 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-12 03:30:49 --> Login MX_Controller Initialized
DEBUG - 2018-05-12 03:30:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-12 03:30:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-05-12 03:30:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-05-12 03:30:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-05-12 03:30:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-05-12 03:30:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-05-12 03:30:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/videos/create_video.php
INFO - 2018-05-12 03:30:50 --> Final output sent to browser
DEBUG - 2018-05-12 03:30:50 --> Total execution time: 0.6278
INFO - 2018-05-12 03:31:33 --> Config Class Initialized
INFO - 2018-05-12 03:31:33 --> Hooks Class Initialized
DEBUG - 2018-05-12 03:31:33 --> UTF-8 Support Enabled
INFO - 2018-05-12 03:31:33 --> Utf8 Class Initialized
INFO - 2018-05-12 03:31:33 --> URI Class Initialized
INFO - 2018-05-12 03:31:33 --> Router Class Initialized
INFO - 2018-05-12 03:31:33 --> Output Class Initialized
INFO - 2018-05-12 03:31:33 --> Security Class Initialized
DEBUG - 2018-05-12 03:31:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 03:31:33 --> Input Class Initialized
INFO - 2018-05-12 03:31:33 --> Language Class Initialized
INFO - 2018-05-12 03:31:33 --> Language Class Initialized
INFO - 2018-05-12 03:31:33 --> Config Class Initialized
INFO - 2018-05-12 03:31:33 --> Loader Class Initialized
DEBUG - 2018-05-12 03:31:33 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-12 03:31:33 --> Helper loaded: url_helper
INFO - 2018-05-12 03:31:33 --> Helper loaded: form_helper
INFO - 2018-05-12 03:31:33 --> Helper loaded: date_helper
INFO - 2018-05-12 03:31:33 --> Helper loaded: util_helper
INFO - 2018-05-12 03:31:33 --> Helper loaded: text_helper
INFO - 2018-05-12 03:31:33 --> Helper loaded: string_helper
INFO - 2018-05-12 03:31:33 --> Database Driver Class Initialized
DEBUG - 2018-05-12 03:31:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-12 03:31:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-12 03:31:33 --> Email Class Initialized
INFO - 2018-05-12 03:31:34 --> Controller Class Initialized
DEBUG - 2018-05-12 03:31:34 --> videos MX_Controller Initialized
INFO - 2018-05-12 03:31:34 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-12 03:31:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-05-12 03:31:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-12 03:31:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-05-12 03:31:34 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-12 03:31:34 --> Login MX_Controller Initialized
DEBUG - 2018-05-12 03:31:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-12 03:31:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-05-12 03:31:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-05-12 03:31:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-05-12 03:31:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-05-12 03:31:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-05-12 03:31:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/videos/create_video.php
INFO - 2018-05-12 03:31:34 --> Final output sent to browser
DEBUG - 2018-05-12 03:31:34 --> Total execution time: 0.6441
INFO - 2018-05-12 03:33:28 --> Config Class Initialized
INFO - 2018-05-12 03:33:28 --> Hooks Class Initialized
DEBUG - 2018-05-12 03:33:28 --> UTF-8 Support Enabled
INFO - 2018-05-12 03:33:28 --> Utf8 Class Initialized
INFO - 2018-05-12 03:33:28 --> URI Class Initialized
INFO - 2018-05-12 03:33:28 --> Router Class Initialized
INFO - 2018-05-12 03:33:28 --> Output Class Initialized
INFO - 2018-05-12 03:33:28 --> Security Class Initialized
DEBUG - 2018-05-12 03:33:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 03:33:28 --> Input Class Initialized
INFO - 2018-05-12 03:33:28 --> Language Class Initialized
INFO - 2018-05-12 03:33:28 --> Language Class Initialized
INFO - 2018-05-12 03:33:28 --> Config Class Initialized
INFO - 2018-05-12 03:33:28 --> Loader Class Initialized
DEBUG - 2018-05-12 03:33:28 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-12 03:33:28 --> Helper loaded: url_helper
INFO - 2018-05-12 03:33:28 --> Helper loaded: form_helper
INFO - 2018-05-12 03:33:28 --> Helper loaded: date_helper
INFO - 2018-05-12 03:33:28 --> Helper loaded: util_helper
INFO - 2018-05-12 03:33:28 --> Helper loaded: text_helper
INFO - 2018-05-12 03:33:28 --> Helper loaded: string_helper
INFO - 2018-05-12 03:33:28 --> Database Driver Class Initialized
DEBUG - 2018-05-12 03:33:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-12 03:33:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-12 03:33:28 --> Email Class Initialized
INFO - 2018-05-12 03:33:28 --> Controller Class Initialized
DEBUG - 2018-05-12 03:33:28 --> videos MX_Controller Initialized
INFO - 2018-05-12 03:33:28 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-12 03:33:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-05-12 03:33:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-12 03:33:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-05-12 03:33:28 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-12 03:33:28 --> Login MX_Controller Initialized
DEBUG - 2018-05-12 03:33:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-12 03:33:28 --> Upload Class Initialized
INFO - 2018-05-12 03:33:28 --> Config Class Initialized
INFO - 2018-05-12 03:33:28 --> Hooks Class Initialized
DEBUG - 2018-05-12 03:33:28 --> UTF-8 Support Enabled
INFO - 2018-05-12 03:33:28 --> Utf8 Class Initialized
INFO - 2018-05-12 03:33:29 --> URI Class Initialized
INFO - 2018-05-12 03:33:29 --> Router Class Initialized
INFO - 2018-05-12 03:33:29 --> Output Class Initialized
INFO - 2018-05-12 03:33:29 --> Security Class Initialized
DEBUG - 2018-05-12 03:33:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 03:33:29 --> Input Class Initialized
INFO - 2018-05-12 03:33:29 --> Language Class Initialized
INFO - 2018-05-12 03:33:29 --> Language Class Initialized
INFO - 2018-05-12 03:33:29 --> Config Class Initialized
INFO - 2018-05-12 03:33:29 --> Loader Class Initialized
DEBUG - 2018-05-12 03:33:29 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-12 03:33:29 --> Helper loaded: url_helper
INFO - 2018-05-12 03:33:29 --> Helper loaded: form_helper
INFO - 2018-05-12 03:33:29 --> Helper loaded: date_helper
INFO - 2018-05-12 03:33:29 --> Helper loaded: util_helper
INFO - 2018-05-12 03:33:29 --> Helper loaded: text_helper
INFO - 2018-05-12 03:33:29 --> Helper loaded: string_helper
INFO - 2018-05-12 03:33:29 --> Database Driver Class Initialized
DEBUG - 2018-05-12 03:33:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-12 03:33:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-12 03:33:29 --> Email Class Initialized
INFO - 2018-05-12 03:33:29 --> Controller Class Initialized
DEBUG - 2018-05-12 03:33:29 --> videos MX_Controller Initialized
INFO - 2018-05-12 03:33:29 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-12 03:33:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-05-12 03:33:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-12 03:33:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-05-12 03:33:29 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-12 03:33:29 --> Login MX_Controller Initialized
DEBUG - 2018-05-12 03:33:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-12 03:33:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-05-12 03:33:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-05-12 03:33:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-05-12 03:33:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-05-12 03:33:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-05-12 03:33:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/videos/videos.php
INFO - 2018-05-12 03:33:29 --> Final output sent to browser
DEBUG - 2018-05-12 03:33:29 --> Total execution time: 0.7116
INFO - 2018-05-12 03:33:30 --> Config Class Initialized
INFO - 2018-05-12 03:33:30 --> Hooks Class Initialized
DEBUG - 2018-05-12 03:33:30 --> UTF-8 Support Enabled
INFO - 2018-05-12 03:33:30 --> Utf8 Class Initialized
INFO - 2018-05-12 03:33:30 --> URI Class Initialized
INFO - 2018-05-12 03:33:30 --> Router Class Initialized
INFO - 2018-05-12 03:33:30 --> Output Class Initialized
INFO - 2018-05-12 03:33:30 --> Security Class Initialized
DEBUG - 2018-05-12 03:33:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 03:33:30 --> Input Class Initialized
INFO - 2018-05-12 03:33:30 --> Language Class Initialized
INFO - 2018-05-12 03:33:30 --> Language Class Initialized
INFO - 2018-05-12 03:33:30 --> Config Class Initialized
INFO - 2018-05-12 03:33:30 --> Loader Class Initialized
DEBUG - 2018-05-12 03:33:30 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-12 03:33:30 --> Helper loaded: url_helper
INFO - 2018-05-12 03:33:30 --> Helper loaded: form_helper
INFO - 2018-05-12 03:33:30 --> Helper loaded: date_helper
INFO - 2018-05-12 03:33:30 --> Helper loaded: util_helper
INFO - 2018-05-12 03:33:30 --> Helper loaded: text_helper
INFO - 2018-05-12 03:33:30 --> Helper loaded: string_helper
INFO - 2018-05-12 03:33:30 --> Database Driver Class Initialized
DEBUG - 2018-05-12 03:33:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-12 03:33:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-12 03:33:30 --> Email Class Initialized
INFO - 2018-05-12 03:33:30 --> Controller Class Initialized
DEBUG - 2018-05-12 03:33:30 --> videos MX_Controller Initialized
INFO - 2018-05-12 03:33:30 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-12 03:33:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-05-12 03:33:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-12 03:33:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-05-12 03:33:30 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-12 03:33:30 --> Login MX_Controller Initialized
DEBUG - 2018-05-12 03:33:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-12 03:33:30 --> Final output sent to browser
DEBUG - 2018-05-12 03:33:30 --> Total execution time: 0.7095
INFO - 2018-05-12 03:34:17 --> Config Class Initialized
INFO - 2018-05-12 03:34:17 --> Hooks Class Initialized
DEBUG - 2018-05-12 03:34:17 --> UTF-8 Support Enabled
INFO - 2018-05-12 03:34:17 --> Utf8 Class Initialized
INFO - 2018-05-12 03:34:17 --> URI Class Initialized
INFO - 2018-05-12 03:34:17 --> Router Class Initialized
INFO - 2018-05-12 03:34:17 --> Output Class Initialized
INFO - 2018-05-12 03:34:17 --> Security Class Initialized
DEBUG - 2018-05-12 03:34:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 03:34:17 --> Input Class Initialized
INFO - 2018-05-12 03:34:17 --> Language Class Initialized
INFO - 2018-05-12 03:34:17 --> Language Class Initialized
INFO - 2018-05-12 03:34:17 --> Config Class Initialized
INFO - 2018-05-12 03:34:17 --> Loader Class Initialized
DEBUG - 2018-05-12 03:34:17 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-12 03:34:17 --> Helper loaded: url_helper
INFO - 2018-05-12 03:34:17 --> Helper loaded: form_helper
INFO - 2018-05-12 03:34:17 --> Helper loaded: date_helper
INFO - 2018-05-12 03:34:17 --> Helper loaded: util_helper
INFO - 2018-05-12 03:34:17 --> Helper loaded: text_helper
INFO - 2018-05-12 03:34:17 --> Helper loaded: string_helper
INFO - 2018-05-12 03:34:17 --> Database Driver Class Initialized
DEBUG - 2018-05-12 03:34:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-12 03:34:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-12 03:34:17 --> Email Class Initialized
INFO - 2018-05-12 03:34:17 --> Controller Class Initialized
DEBUG - 2018-05-12 03:34:17 --> videos MX_Controller Initialized
INFO - 2018-05-12 03:34:17 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-12 03:34:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-05-12 03:34:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-12 03:34:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-05-12 03:34:17 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-12 03:34:17 --> Login MX_Controller Initialized
DEBUG - 2018-05-12 03:34:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-12 03:34:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-05-12 03:34:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-05-12 03:34:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-05-12 03:34:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-05-12 03:34:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-05-12 03:34:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/videos/create_video.php
INFO - 2018-05-12 03:34:17 --> Final output sent to browser
DEBUG - 2018-05-12 03:34:17 --> Total execution time: 0.6594
INFO - 2018-05-12 03:34:31 --> Config Class Initialized
INFO - 2018-05-12 03:34:31 --> Hooks Class Initialized
DEBUG - 2018-05-12 03:34:31 --> UTF-8 Support Enabled
INFO - 2018-05-12 03:34:31 --> Utf8 Class Initialized
INFO - 2018-05-12 03:34:31 --> URI Class Initialized
INFO - 2018-05-12 03:34:31 --> Router Class Initialized
INFO - 2018-05-12 03:34:31 --> Output Class Initialized
INFO - 2018-05-12 03:34:31 --> Security Class Initialized
DEBUG - 2018-05-12 03:34:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 03:34:31 --> Input Class Initialized
INFO - 2018-05-12 03:34:31 --> Language Class Initialized
INFO - 2018-05-12 03:34:31 --> Language Class Initialized
INFO - 2018-05-12 03:34:31 --> Config Class Initialized
INFO - 2018-05-12 03:34:31 --> Loader Class Initialized
DEBUG - 2018-05-12 03:34:31 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-12 03:34:31 --> Helper loaded: url_helper
INFO - 2018-05-12 03:34:31 --> Helper loaded: form_helper
INFO - 2018-05-12 03:34:31 --> Helper loaded: date_helper
INFO - 2018-05-12 03:34:31 --> Helper loaded: util_helper
INFO - 2018-05-12 03:34:31 --> Helper loaded: text_helper
INFO - 2018-05-12 03:34:31 --> Helper loaded: string_helper
INFO - 2018-05-12 03:34:31 --> Database Driver Class Initialized
DEBUG - 2018-05-12 03:34:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-12 03:34:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-12 03:34:31 --> Email Class Initialized
INFO - 2018-05-12 03:34:31 --> Controller Class Initialized
DEBUG - 2018-05-12 03:34:31 --> videos MX_Controller Initialized
INFO - 2018-05-12 03:34:31 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-12 03:34:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-05-12 03:34:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-12 03:34:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-05-12 03:34:31 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-12 03:34:31 --> Login MX_Controller Initialized
DEBUG - 2018-05-12 03:34:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-12 03:34:31 --> Upload Class Initialized
INFO - 2018-05-12 03:34:32 --> Config Class Initialized
INFO - 2018-05-12 03:34:32 --> Hooks Class Initialized
DEBUG - 2018-05-12 03:34:32 --> UTF-8 Support Enabled
INFO - 2018-05-12 03:34:32 --> Utf8 Class Initialized
INFO - 2018-05-12 03:34:32 --> URI Class Initialized
INFO - 2018-05-12 03:34:32 --> Router Class Initialized
INFO - 2018-05-12 03:34:32 --> Output Class Initialized
INFO - 2018-05-12 03:34:32 --> Security Class Initialized
DEBUG - 2018-05-12 03:34:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 03:34:32 --> Input Class Initialized
INFO - 2018-05-12 03:34:32 --> Language Class Initialized
INFO - 2018-05-12 03:34:32 --> Language Class Initialized
INFO - 2018-05-12 03:34:32 --> Config Class Initialized
INFO - 2018-05-12 03:34:32 --> Loader Class Initialized
DEBUG - 2018-05-12 03:34:32 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-12 03:34:32 --> Helper loaded: url_helper
INFO - 2018-05-12 03:34:32 --> Helper loaded: form_helper
INFO - 2018-05-12 03:34:32 --> Helper loaded: date_helper
INFO - 2018-05-12 03:34:32 --> Helper loaded: util_helper
INFO - 2018-05-12 03:34:32 --> Helper loaded: text_helper
INFO - 2018-05-12 03:34:32 --> Helper loaded: string_helper
INFO - 2018-05-12 03:34:32 --> Database Driver Class Initialized
DEBUG - 2018-05-12 03:34:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-12 03:34:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-12 03:34:32 --> Email Class Initialized
INFO - 2018-05-12 03:34:32 --> Controller Class Initialized
DEBUG - 2018-05-12 03:34:32 --> videos MX_Controller Initialized
INFO - 2018-05-12 03:34:32 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-12 03:34:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-05-12 03:34:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-12 03:34:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-05-12 03:34:32 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-12 03:34:32 --> Login MX_Controller Initialized
DEBUG - 2018-05-12 03:34:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-12 03:34:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-05-12 03:34:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-05-12 03:34:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-05-12 03:34:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-05-12 03:34:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-05-12 03:34:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/videos/videos.php
INFO - 2018-05-12 03:34:32 --> Final output sent to browser
DEBUG - 2018-05-12 03:34:32 --> Total execution time: 0.7510
INFO - 2018-05-12 03:34:33 --> Config Class Initialized
INFO - 2018-05-12 03:34:33 --> Hooks Class Initialized
DEBUG - 2018-05-12 03:34:33 --> UTF-8 Support Enabled
INFO - 2018-05-12 03:34:33 --> Utf8 Class Initialized
INFO - 2018-05-12 03:34:33 --> URI Class Initialized
INFO - 2018-05-12 03:34:33 --> Router Class Initialized
INFO - 2018-05-12 03:34:33 --> Output Class Initialized
INFO - 2018-05-12 03:34:33 --> Security Class Initialized
DEBUG - 2018-05-12 03:34:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 03:34:33 --> Input Class Initialized
INFO - 2018-05-12 03:34:33 --> Language Class Initialized
INFO - 2018-05-12 03:34:33 --> Language Class Initialized
INFO - 2018-05-12 03:34:33 --> Config Class Initialized
INFO - 2018-05-12 03:34:33 --> Loader Class Initialized
DEBUG - 2018-05-12 03:34:33 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-12 03:34:33 --> Helper loaded: url_helper
INFO - 2018-05-12 03:34:33 --> Helper loaded: form_helper
INFO - 2018-05-12 03:34:33 --> Helper loaded: date_helper
INFO - 2018-05-12 03:34:33 --> Helper loaded: util_helper
INFO - 2018-05-12 03:34:33 --> Helper loaded: text_helper
INFO - 2018-05-12 03:34:33 --> Helper loaded: string_helper
INFO - 2018-05-12 03:34:33 --> Database Driver Class Initialized
DEBUG - 2018-05-12 03:34:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-12 03:34:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-12 03:34:33 --> Email Class Initialized
INFO - 2018-05-12 03:34:33 --> Controller Class Initialized
DEBUG - 2018-05-12 03:34:33 --> videos MX_Controller Initialized
INFO - 2018-05-12 03:34:33 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-12 03:34:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-05-12 03:34:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-12 03:34:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-05-12 03:34:33 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-12 03:34:33 --> Login MX_Controller Initialized
DEBUG - 2018-05-12 03:34:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-12 03:34:33 --> Final output sent to browser
DEBUG - 2018-05-12 03:34:33 --> Total execution time: 0.7200
INFO - 2018-05-12 03:35:17 --> Config Class Initialized
INFO - 2018-05-12 03:35:17 --> Hooks Class Initialized
DEBUG - 2018-05-12 03:35:17 --> UTF-8 Support Enabled
INFO - 2018-05-12 03:35:17 --> Utf8 Class Initialized
INFO - 2018-05-12 03:35:17 --> URI Class Initialized
INFO - 2018-05-12 03:35:17 --> Router Class Initialized
INFO - 2018-05-12 03:35:17 --> Output Class Initialized
INFO - 2018-05-12 03:35:17 --> Security Class Initialized
DEBUG - 2018-05-12 03:35:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 03:35:17 --> Input Class Initialized
INFO - 2018-05-12 03:35:17 --> Language Class Initialized
INFO - 2018-05-12 03:35:18 --> Language Class Initialized
INFO - 2018-05-12 03:35:18 --> Config Class Initialized
INFO - 2018-05-12 03:35:18 --> Loader Class Initialized
DEBUG - 2018-05-12 03:35:18 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-12 03:35:18 --> Helper loaded: url_helper
INFO - 2018-05-12 03:35:18 --> Helper loaded: form_helper
INFO - 2018-05-12 03:35:18 --> Helper loaded: date_helper
INFO - 2018-05-12 03:35:18 --> Helper loaded: util_helper
INFO - 2018-05-12 03:35:18 --> Helper loaded: text_helper
INFO - 2018-05-12 03:35:18 --> Helper loaded: string_helper
INFO - 2018-05-12 03:35:18 --> Database Driver Class Initialized
DEBUG - 2018-05-12 03:35:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-12 03:35:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-12 03:35:18 --> Email Class Initialized
INFO - 2018-05-12 03:35:18 --> Controller Class Initialized
DEBUG - 2018-05-12 03:35:18 --> videos MX_Controller Initialized
INFO - 2018-05-12 03:35:18 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-12 03:35:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-05-12 03:35:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-12 03:35:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-05-12 03:35:18 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-12 03:35:18 --> Login MX_Controller Initialized
DEBUG - 2018-05-12 03:35:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-12 03:35:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-05-12 03:35:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-05-12 03:35:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-05-12 03:35:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-05-12 03:35:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-05-12 03:35:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/videos/create_video.php
INFO - 2018-05-12 03:35:18 --> Final output sent to browser
DEBUG - 2018-05-12 03:35:18 --> Total execution time: 0.6276
INFO - 2018-05-12 03:35:28 --> Config Class Initialized
INFO - 2018-05-12 03:35:28 --> Hooks Class Initialized
DEBUG - 2018-05-12 03:35:28 --> UTF-8 Support Enabled
INFO - 2018-05-12 03:35:28 --> Utf8 Class Initialized
INFO - 2018-05-12 03:35:28 --> URI Class Initialized
INFO - 2018-05-12 03:35:28 --> Router Class Initialized
INFO - 2018-05-12 03:35:28 --> Output Class Initialized
INFO - 2018-05-12 03:35:28 --> Security Class Initialized
DEBUG - 2018-05-12 03:35:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 03:35:28 --> Input Class Initialized
INFO - 2018-05-12 03:35:28 --> Language Class Initialized
INFO - 2018-05-12 03:35:28 --> Language Class Initialized
INFO - 2018-05-12 03:35:28 --> Config Class Initialized
INFO - 2018-05-12 03:35:28 --> Loader Class Initialized
DEBUG - 2018-05-12 03:35:28 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-12 03:35:28 --> Helper loaded: url_helper
INFO - 2018-05-12 03:35:28 --> Helper loaded: form_helper
INFO - 2018-05-12 03:35:28 --> Helper loaded: date_helper
INFO - 2018-05-12 03:35:28 --> Helper loaded: util_helper
INFO - 2018-05-12 03:35:28 --> Helper loaded: text_helper
INFO - 2018-05-12 03:35:28 --> Helper loaded: string_helper
INFO - 2018-05-12 03:35:28 --> Database Driver Class Initialized
DEBUG - 2018-05-12 03:35:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-12 03:35:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-12 03:35:28 --> Email Class Initialized
INFO - 2018-05-12 03:35:28 --> Controller Class Initialized
DEBUG - 2018-05-12 03:35:28 --> videos MX_Controller Initialized
INFO - 2018-05-12 03:35:28 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-12 03:35:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-05-12 03:35:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-12 03:35:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-05-12 03:35:29 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-12 03:35:29 --> Login MX_Controller Initialized
DEBUG - 2018-05-12 03:35:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-12 03:35:31 --> Config Class Initialized
INFO - 2018-05-12 03:35:31 --> Hooks Class Initialized
DEBUG - 2018-05-12 03:35:32 --> UTF-8 Support Enabled
INFO - 2018-05-12 03:35:32 --> Utf8 Class Initialized
INFO - 2018-05-12 03:35:32 --> URI Class Initialized
INFO - 2018-05-12 03:35:32 --> Router Class Initialized
INFO - 2018-05-12 03:35:32 --> Output Class Initialized
INFO - 2018-05-12 03:35:32 --> Security Class Initialized
DEBUG - 2018-05-12 03:35:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 03:35:32 --> Input Class Initialized
INFO - 2018-05-12 03:35:32 --> Language Class Initialized
ERROR - 2018-05-12 03:35:32 --> 404 Page Not Found: /index
INFO - 2018-05-12 03:35:33 --> Config Class Initialized
INFO - 2018-05-12 03:35:33 --> Hooks Class Initialized
DEBUG - 2018-05-12 03:35:33 --> UTF-8 Support Enabled
INFO - 2018-05-12 03:35:33 --> Utf8 Class Initialized
INFO - 2018-05-12 03:35:33 --> URI Class Initialized
INFO - 2018-05-12 03:35:33 --> Router Class Initialized
INFO - 2018-05-12 03:35:33 --> Output Class Initialized
INFO - 2018-05-12 03:35:33 --> Security Class Initialized
DEBUG - 2018-05-12 03:35:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 03:35:33 --> Input Class Initialized
INFO - 2018-05-12 03:35:33 --> Language Class Initialized
INFO - 2018-05-12 03:35:33 --> Language Class Initialized
INFO - 2018-05-12 03:35:33 --> Config Class Initialized
INFO - 2018-05-12 03:35:33 --> Loader Class Initialized
DEBUG - 2018-05-12 03:35:33 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-12 03:35:33 --> Helper loaded: url_helper
INFO - 2018-05-12 03:35:33 --> Helper loaded: form_helper
INFO - 2018-05-12 03:35:33 --> Helper loaded: date_helper
INFO - 2018-05-12 03:35:33 --> Helper loaded: util_helper
INFO - 2018-05-12 03:35:33 --> Helper loaded: text_helper
INFO - 2018-05-12 03:35:33 --> Helper loaded: string_helper
INFO - 2018-05-12 03:35:33 --> Database Driver Class Initialized
DEBUG - 2018-05-12 03:35:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-12 03:35:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-12 03:35:33 --> Email Class Initialized
INFO - 2018-05-12 03:35:33 --> Controller Class Initialized
DEBUG - 2018-05-12 03:35:33 --> videos MX_Controller Initialized
INFO - 2018-05-12 03:35:33 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-12 03:35:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-05-12 03:35:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-12 03:35:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-05-12 03:35:34 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-12 03:35:34 --> Login MX_Controller Initialized
DEBUG - 2018-05-12 03:35:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-12 03:36:45 --> Config Class Initialized
INFO - 2018-05-12 03:36:45 --> Hooks Class Initialized
DEBUG - 2018-05-12 03:36:45 --> UTF-8 Support Enabled
INFO - 2018-05-12 03:36:45 --> Utf8 Class Initialized
INFO - 2018-05-12 03:36:45 --> URI Class Initialized
INFO - 2018-05-12 03:36:45 --> Router Class Initialized
INFO - 2018-05-12 03:36:45 --> Output Class Initialized
INFO - 2018-05-12 03:36:45 --> Security Class Initialized
DEBUG - 2018-05-12 03:36:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 03:36:45 --> Input Class Initialized
INFO - 2018-05-12 03:36:45 --> Language Class Initialized
INFO - 2018-05-12 03:36:45 --> Language Class Initialized
INFO - 2018-05-12 03:36:45 --> Config Class Initialized
INFO - 2018-05-12 03:36:45 --> Loader Class Initialized
DEBUG - 2018-05-12 03:36:45 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-12 03:36:45 --> Helper loaded: url_helper
INFO - 2018-05-12 03:36:45 --> Helper loaded: form_helper
INFO - 2018-05-12 03:36:45 --> Helper loaded: date_helper
INFO - 2018-05-12 03:36:45 --> Helper loaded: util_helper
INFO - 2018-05-12 03:36:45 --> Helper loaded: text_helper
INFO - 2018-05-12 03:36:45 --> Helper loaded: string_helper
INFO - 2018-05-12 03:36:45 --> Database Driver Class Initialized
DEBUG - 2018-05-12 03:36:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-12 03:36:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-12 03:36:45 --> Email Class Initialized
INFO - 2018-05-12 03:36:45 --> Controller Class Initialized
DEBUG - 2018-05-12 03:36:45 --> videos MX_Controller Initialized
INFO - 2018-05-12 03:36:45 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-12 03:36:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-05-12 03:36:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-12 03:36:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-05-12 03:36:45 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-12 03:36:45 --> Login MX_Controller Initialized
DEBUG - 2018-05-12 03:36:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-12 03:36:45 --> Upload Class Initialized
INFO - 2018-05-12 03:37:09 --> Config Class Initialized
INFO - 2018-05-12 03:37:09 --> Hooks Class Initialized
DEBUG - 2018-05-12 03:37:09 --> UTF-8 Support Enabled
INFO - 2018-05-12 03:37:09 --> Utf8 Class Initialized
INFO - 2018-05-12 03:37:09 --> URI Class Initialized
INFO - 2018-05-12 03:37:09 --> Router Class Initialized
INFO - 2018-05-12 03:37:09 --> Output Class Initialized
INFO - 2018-05-12 03:37:09 --> Security Class Initialized
DEBUG - 2018-05-12 03:37:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 03:37:09 --> Input Class Initialized
INFO - 2018-05-12 03:37:09 --> Language Class Initialized
INFO - 2018-05-12 03:37:09 --> Language Class Initialized
INFO - 2018-05-12 03:37:09 --> Config Class Initialized
INFO - 2018-05-12 03:37:10 --> Loader Class Initialized
DEBUG - 2018-05-12 03:37:10 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-12 03:37:10 --> Helper loaded: url_helper
INFO - 2018-05-12 03:37:10 --> Helper loaded: form_helper
INFO - 2018-05-12 03:37:10 --> Helper loaded: date_helper
INFO - 2018-05-12 03:37:10 --> Helper loaded: util_helper
INFO - 2018-05-12 03:37:10 --> Helper loaded: text_helper
INFO - 2018-05-12 03:37:10 --> Helper loaded: string_helper
INFO - 2018-05-12 03:37:10 --> Database Driver Class Initialized
DEBUG - 2018-05-12 03:37:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-12 03:37:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-12 03:37:10 --> Email Class Initialized
INFO - 2018-05-12 03:37:10 --> Controller Class Initialized
DEBUG - 2018-05-12 03:37:10 --> videos MX_Controller Initialized
INFO - 2018-05-12 03:37:10 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-12 03:37:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-05-12 03:37:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-12 03:37:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-05-12 03:37:10 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-12 03:37:10 --> Login MX_Controller Initialized
DEBUG - 2018-05-12 03:37:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-12 03:37:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-05-12 03:37:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-05-12 03:37:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-05-12 03:37:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-05-12 03:37:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-05-12 03:37:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/videos/create_video.php
INFO - 2018-05-12 03:37:10 --> Final output sent to browser
DEBUG - 2018-05-12 03:37:10 --> Total execution time: 0.6762
INFO - 2018-05-12 03:37:11 --> Config Class Initialized
INFO - 2018-05-12 03:37:11 --> Hooks Class Initialized
DEBUG - 2018-05-12 03:37:11 --> UTF-8 Support Enabled
INFO - 2018-05-12 03:37:11 --> Utf8 Class Initialized
INFO - 2018-05-12 03:37:11 --> URI Class Initialized
INFO - 2018-05-12 03:37:11 --> Router Class Initialized
INFO - 2018-05-12 03:37:11 --> Output Class Initialized
INFO - 2018-05-12 03:37:11 --> Security Class Initialized
DEBUG - 2018-05-12 03:37:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 03:37:11 --> Input Class Initialized
INFO - 2018-05-12 03:37:11 --> Language Class Initialized
ERROR - 2018-05-12 03:37:11 --> 404 Page Not Found: /index
INFO - 2018-05-12 03:38:18 --> Config Class Initialized
INFO - 2018-05-12 03:38:18 --> Hooks Class Initialized
DEBUG - 2018-05-12 03:38:18 --> UTF-8 Support Enabled
INFO - 2018-05-12 03:38:18 --> Utf8 Class Initialized
INFO - 2018-05-12 03:38:18 --> URI Class Initialized
INFO - 2018-05-12 03:38:18 --> Router Class Initialized
INFO - 2018-05-12 03:38:18 --> Output Class Initialized
INFO - 2018-05-12 03:38:18 --> Security Class Initialized
DEBUG - 2018-05-12 03:38:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 03:38:18 --> Input Class Initialized
INFO - 2018-05-12 03:38:18 --> Language Class Initialized
INFO - 2018-05-12 03:38:18 --> Language Class Initialized
INFO - 2018-05-12 03:38:18 --> Config Class Initialized
INFO - 2018-05-12 03:38:18 --> Loader Class Initialized
DEBUG - 2018-05-12 03:38:18 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-12 03:38:18 --> Helper loaded: url_helper
INFO - 2018-05-12 03:38:18 --> Helper loaded: form_helper
INFO - 2018-05-12 03:38:18 --> Helper loaded: date_helper
INFO - 2018-05-12 03:38:18 --> Helper loaded: util_helper
INFO - 2018-05-12 03:38:18 --> Helper loaded: text_helper
INFO - 2018-05-12 03:38:18 --> Helper loaded: string_helper
INFO - 2018-05-12 03:38:18 --> Database Driver Class Initialized
DEBUG - 2018-05-12 03:38:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-12 03:38:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-12 03:38:18 --> Email Class Initialized
INFO - 2018-05-12 03:38:18 --> Controller Class Initialized
DEBUG - 2018-05-12 03:38:19 --> videos MX_Controller Initialized
INFO - 2018-05-12 03:38:19 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-12 03:38:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-05-12 03:38:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-12 03:38:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-05-12 03:38:19 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-12 03:38:19 --> Login MX_Controller Initialized
DEBUG - 2018-05-12 03:38:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-12 03:38:19 --> Upload Class Initialized
INFO - 2018-05-12 03:39:18 --> Config Class Initialized
INFO - 2018-05-12 03:39:18 --> Hooks Class Initialized
DEBUG - 2018-05-12 03:39:18 --> UTF-8 Support Enabled
INFO - 2018-05-12 03:39:18 --> Utf8 Class Initialized
INFO - 2018-05-12 03:39:18 --> URI Class Initialized
INFO - 2018-05-12 03:39:18 --> Router Class Initialized
INFO - 2018-05-12 03:39:18 --> Output Class Initialized
INFO - 2018-05-12 03:39:18 --> Security Class Initialized
DEBUG - 2018-05-12 03:39:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 03:39:18 --> Input Class Initialized
INFO - 2018-05-12 03:39:18 --> Language Class Initialized
INFO - 2018-05-12 03:39:18 --> Language Class Initialized
INFO - 2018-05-12 03:39:18 --> Config Class Initialized
INFO - 2018-05-12 03:39:18 --> Loader Class Initialized
DEBUG - 2018-05-12 03:39:18 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-12 03:39:18 --> Helper loaded: url_helper
INFO - 2018-05-12 03:39:18 --> Helper loaded: form_helper
INFO - 2018-05-12 03:39:18 --> Helper loaded: date_helper
INFO - 2018-05-12 03:39:18 --> Helper loaded: util_helper
INFO - 2018-05-12 03:39:18 --> Helper loaded: text_helper
INFO - 2018-05-12 03:39:18 --> Helper loaded: string_helper
INFO - 2018-05-12 03:39:18 --> Database Driver Class Initialized
DEBUG - 2018-05-12 03:39:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-12 03:39:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-12 03:39:19 --> Email Class Initialized
INFO - 2018-05-12 03:39:19 --> Controller Class Initialized
DEBUG - 2018-05-12 03:39:19 --> videos MX_Controller Initialized
INFO - 2018-05-12 03:39:19 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-12 03:39:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-05-12 03:39:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-12 03:39:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-05-12 03:39:19 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-12 03:39:19 --> Login MX_Controller Initialized
DEBUG - 2018-05-12 03:39:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-12 03:39:19 --> Upload Class Initialized
INFO - 2018-05-12 03:40:18 --> Config Class Initialized
INFO - 2018-05-12 03:40:18 --> Hooks Class Initialized
DEBUG - 2018-05-12 03:40:18 --> UTF-8 Support Enabled
INFO - 2018-05-12 03:40:18 --> Utf8 Class Initialized
INFO - 2018-05-12 03:40:18 --> URI Class Initialized
INFO - 2018-05-12 03:40:18 --> Router Class Initialized
INFO - 2018-05-12 03:40:18 --> Output Class Initialized
INFO - 2018-05-12 03:40:18 --> Security Class Initialized
DEBUG - 2018-05-12 03:40:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 03:40:18 --> Input Class Initialized
INFO - 2018-05-12 03:40:18 --> Language Class Initialized
INFO - 2018-05-12 03:40:18 --> Language Class Initialized
INFO - 2018-05-12 03:40:18 --> Config Class Initialized
INFO - 2018-05-12 03:40:18 --> Loader Class Initialized
DEBUG - 2018-05-12 03:40:18 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-12 03:40:18 --> Helper loaded: url_helper
INFO - 2018-05-12 03:40:18 --> Helper loaded: form_helper
INFO - 2018-05-12 03:40:18 --> Helper loaded: date_helper
INFO - 2018-05-12 03:40:18 --> Helper loaded: util_helper
INFO - 2018-05-12 03:40:18 --> Helper loaded: text_helper
INFO - 2018-05-12 03:40:18 --> Helper loaded: string_helper
INFO - 2018-05-12 03:40:18 --> Database Driver Class Initialized
DEBUG - 2018-05-12 03:40:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-12 03:40:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-12 03:40:18 --> Email Class Initialized
INFO - 2018-05-12 03:40:18 --> Controller Class Initialized
DEBUG - 2018-05-12 03:40:18 --> videos MX_Controller Initialized
INFO - 2018-05-12 03:40:18 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-12 03:40:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-05-12 03:40:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-12 03:40:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-05-12 03:40:18 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-12 03:40:18 --> Login MX_Controller Initialized
DEBUG - 2018-05-12 03:40:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-12 03:40:19 --> Upload Class Initialized
ERROR - 2018-05-12 03:40:19 --> Severity: Warning --> unlink(E:\xampp\htdocs\consulting\assets/images/videos/1526076405.mp4): No such file or directory E:\xampp\htdocs\consulting\application\modules\admin\controllers\Videos.php 200
INFO - 2018-05-12 03:40:29 --> Config Class Initialized
INFO - 2018-05-12 03:40:29 --> Hooks Class Initialized
DEBUG - 2018-05-12 03:40:29 --> UTF-8 Support Enabled
INFO - 2018-05-12 03:40:30 --> Utf8 Class Initialized
INFO - 2018-05-12 03:40:30 --> URI Class Initialized
INFO - 2018-05-12 03:40:30 --> Router Class Initialized
INFO - 2018-05-12 03:40:30 --> Output Class Initialized
INFO - 2018-05-12 03:40:30 --> Security Class Initialized
DEBUG - 2018-05-12 03:40:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 03:40:30 --> Input Class Initialized
INFO - 2018-05-12 03:40:30 --> Language Class Initialized
INFO - 2018-05-12 03:40:30 --> Language Class Initialized
INFO - 2018-05-12 03:40:30 --> Config Class Initialized
INFO - 2018-05-12 03:40:30 --> Loader Class Initialized
DEBUG - 2018-05-12 03:40:30 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-12 03:40:30 --> Helper loaded: url_helper
INFO - 2018-05-12 03:40:30 --> Helper loaded: form_helper
INFO - 2018-05-12 03:40:30 --> Helper loaded: date_helper
INFO - 2018-05-12 03:40:30 --> Helper loaded: util_helper
INFO - 2018-05-12 03:40:30 --> Helper loaded: text_helper
INFO - 2018-05-12 03:40:30 --> Helper loaded: string_helper
INFO - 2018-05-12 03:40:30 --> Database Driver Class Initialized
DEBUG - 2018-05-12 03:40:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-12 03:40:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-12 03:40:30 --> Email Class Initialized
INFO - 2018-05-12 03:40:30 --> Controller Class Initialized
DEBUG - 2018-05-12 03:40:30 --> videos MX_Controller Initialized
INFO - 2018-05-12 03:40:30 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-12 03:40:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-05-12 03:40:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-12 03:40:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-05-12 03:40:30 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-12 03:40:30 --> Login MX_Controller Initialized
DEBUG - 2018-05-12 03:40:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-12 03:40:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-05-12 03:40:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-05-12 03:40:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-05-12 03:40:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-05-12 03:40:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-05-12 03:40:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/videos/create_video.php
INFO - 2018-05-12 03:40:30 --> Final output sent to browser
DEBUG - 2018-05-12 03:40:30 --> Total execution time: 0.6674
INFO - 2018-05-12 03:40:31 --> Config Class Initialized
INFO - 2018-05-12 03:40:31 --> Hooks Class Initialized
DEBUG - 2018-05-12 03:40:31 --> UTF-8 Support Enabled
INFO - 2018-05-12 03:40:31 --> Utf8 Class Initialized
INFO - 2018-05-12 03:40:31 --> URI Class Initialized
INFO - 2018-05-12 03:40:31 --> Router Class Initialized
INFO - 2018-05-12 03:40:31 --> Output Class Initialized
INFO - 2018-05-12 03:40:32 --> Security Class Initialized
DEBUG - 2018-05-12 03:40:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 03:40:32 --> Input Class Initialized
INFO - 2018-05-12 03:40:32 --> Language Class Initialized
ERROR - 2018-05-12 03:40:32 --> 404 Page Not Found: /index
INFO - 2018-05-12 03:40:53 --> Config Class Initialized
INFO - 2018-05-12 03:40:53 --> Hooks Class Initialized
DEBUG - 2018-05-12 03:40:53 --> UTF-8 Support Enabled
INFO - 2018-05-12 03:40:53 --> Utf8 Class Initialized
INFO - 2018-05-12 03:40:53 --> URI Class Initialized
INFO - 2018-05-12 03:40:53 --> Router Class Initialized
INFO - 2018-05-12 03:40:53 --> Output Class Initialized
INFO - 2018-05-12 03:40:53 --> Security Class Initialized
DEBUG - 2018-05-12 03:40:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 03:40:53 --> Input Class Initialized
INFO - 2018-05-12 03:40:53 --> Language Class Initialized
INFO - 2018-05-12 03:40:53 --> Language Class Initialized
INFO - 2018-05-12 03:40:53 --> Config Class Initialized
INFO - 2018-05-12 03:40:53 --> Loader Class Initialized
DEBUG - 2018-05-12 03:40:54 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-12 03:40:54 --> Helper loaded: url_helper
INFO - 2018-05-12 03:40:54 --> Helper loaded: form_helper
INFO - 2018-05-12 03:40:54 --> Helper loaded: date_helper
INFO - 2018-05-12 03:40:54 --> Helper loaded: util_helper
INFO - 2018-05-12 03:40:54 --> Helper loaded: text_helper
INFO - 2018-05-12 03:40:54 --> Helper loaded: string_helper
INFO - 2018-05-12 03:40:54 --> Database Driver Class Initialized
DEBUG - 2018-05-12 03:40:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-12 03:40:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-12 03:40:54 --> Email Class Initialized
INFO - 2018-05-12 03:40:54 --> Controller Class Initialized
DEBUG - 2018-05-12 03:40:54 --> videos MX_Controller Initialized
INFO - 2018-05-12 03:40:54 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-12 03:40:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-05-12 03:40:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-12 03:40:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-05-12 03:40:54 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-12 03:40:54 --> Login MX_Controller Initialized
DEBUG - 2018-05-12 03:40:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-12 03:40:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-05-12 03:40:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-05-12 03:40:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-05-12 03:40:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-05-12 03:40:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-05-12 03:40:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/videos/videos.php
INFO - 2018-05-12 03:40:54 --> Final output sent to browser
DEBUG - 2018-05-12 03:40:54 --> Total execution time: 0.6744
INFO - 2018-05-12 03:40:55 --> Config Class Initialized
INFO - 2018-05-12 03:40:55 --> Hooks Class Initialized
DEBUG - 2018-05-12 03:40:55 --> UTF-8 Support Enabled
INFO - 2018-05-12 03:40:55 --> Utf8 Class Initialized
INFO - 2018-05-12 03:40:55 --> URI Class Initialized
INFO - 2018-05-12 03:40:55 --> Router Class Initialized
INFO - 2018-05-12 03:40:55 --> Output Class Initialized
INFO - 2018-05-12 03:40:55 --> Security Class Initialized
DEBUG - 2018-05-12 03:40:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 03:40:55 --> Input Class Initialized
INFO - 2018-05-12 03:40:55 --> Language Class Initialized
INFO - 2018-05-12 03:40:55 --> Language Class Initialized
INFO - 2018-05-12 03:40:55 --> Config Class Initialized
INFO - 2018-05-12 03:40:55 --> Loader Class Initialized
DEBUG - 2018-05-12 03:40:55 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-12 03:40:55 --> Helper loaded: url_helper
INFO - 2018-05-12 03:40:55 --> Helper loaded: form_helper
INFO - 2018-05-12 03:40:55 --> Helper loaded: date_helper
INFO - 2018-05-12 03:40:55 --> Helper loaded: util_helper
INFO - 2018-05-12 03:40:55 --> Helper loaded: text_helper
INFO - 2018-05-12 03:40:55 --> Helper loaded: string_helper
INFO - 2018-05-12 03:40:55 --> Database Driver Class Initialized
DEBUG - 2018-05-12 03:40:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-12 03:40:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-12 03:40:55 --> Email Class Initialized
INFO - 2018-05-12 03:40:55 --> Controller Class Initialized
DEBUG - 2018-05-12 03:40:55 --> videos MX_Controller Initialized
INFO - 2018-05-12 03:40:55 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-12 03:40:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-05-12 03:40:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-12 03:40:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-05-12 03:40:55 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-12 03:40:55 --> Login MX_Controller Initialized
DEBUG - 2018-05-12 03:40:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-12 03:40:55 --> Final output sent to browser
DEBUG - 2018-05-12 03:40:55 --> Total execution time: 0.7165
INFO - 2018-05-12 04:00:51 --> Config Class Initialized
INFO - 2018-05-12 04:00:51 --> Hooks Class Initialized
DEBUG - 2018-05-12 04:00:51 --> UTF-8 Support Enabled
INFO - 2018-05-12 04:00:51 --> Utf8 Class Initialized
INFO - 2018-05-12 04:00:51 --> URI Class Initialized
INFO - 2018-05-12 04:00:51 --> Router Class Initialized
INFO - 2018-05-12 04:00:51 --> Output Class Initialized
INFO - 2018-05-12 04:00:51 --> Security Class Initialized
DEBUG - 2018-05-12 04:00:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 04:00:51 --> Input Class Initialized
INFO - 2018-05-12 04:00:51 --> Language Class Initialized
INFO - 2018-05-12 04:00:51 --> Language Class Initialized
INFO - 2018-05-12 04:00:51 --> Config Class Initialized
INFO - 2018-05-12 04:00:51 --> Loader Class Initialized
DEBUG - 2018-05-12 04:00:51 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-12 04:00:51 --> Helper loaded: url_helper
INFO - 2018-05-12 04:00:51 --> Helper loaded: form_helper
INFO - 2018-05-12 04:00:51 --> Helper loaded: date_helper
INFO - 2018-05-12 04:00:51 --> Helper loaded: util_helper
INFO - 2018-05-12 04:00:51 --> Helper loaded: text_helper
INFO - 2018-05-12 04:00:52 --> Helper loaded: string_helper
INFO - 2018-05-12 04:00:52 --> Database Driver Class Initialized
DEBUG - 2018-05-12 04:00:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-12 04:00:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-12 04:00:52 --> Email Class Initialized
INFO - 2018-05-12 04:00:52 --> Controller Class Initialized
DEBUG - 2018-05-12 04:00:52 --> videos MX_Controller Initialized
INFO - 2018-05-12 04:00:52 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-12 04:00:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-05-12 04:00:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-12 04:00:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-05-12 04:00:52 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-12 04:00:52 --> Login MX_Controller Initialized
DEBUG - 2018-05-12 04:00:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-12 04:00:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-05-12 04:00:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-05-12 04:00:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-05-12 04:00:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-05-12 04:00:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-05-12 04:00:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/videos/create_video.php
INFO - 2018-05-12 04:00:52 --> Final output sent to browser
DEBUG - 2018-05-12 04:00:52 --> Total execution time: 0.7040
INFO - 2018-05-12 04:03:22 --> Config Class Initialized
INFO - 2018-05-12 04:03:22 --> Hooks Class Initialized
DEBUG - 2018-05-12 04:03:22 --> UTF-8 Support Enabled
INFO - 2018-05-12 04:03:22 --> Utf8 Class Initialized
INFO - 2018-05-12 04:03:22 --> URI Class Initialized
INFO - 2018-05-12 04:03:22 --> Router Class Initialized
INFO - 2018-05-12 04:03:22 --> Output Class Initialized
INFO - 2018-05-12 04:03:22 --> Security Class Initialized
DEBUG - 2018-05-12 04:03:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 04:03:22 --> Input Class Initialized
INFO - 2018-05-12 04:03:22 --> Language Class Initialized
INFO - 2018-05-12 04:03:22 --> Language Class Initialized
INFO - 2018-05-12 04:03:22 --> Config Class Initialized
INFO - 2018-05-12 04:03:22 --> Loader Class Initialized
DEBUG - 2018-05-12 04:03:22 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-12 04:03:22 --> Helper loaded: url_helper
INFO - 2018-05-12 04:03:22 --> Helper loaded: form_helper
INFO - 2018-05-12 04:03:22 --> Helper loaded: date_helper
INFO - 2018-05-12 04:03:22 --> Helper loaded: util_helper
INFO - 2018-05-12 04:03:22 --> Helper loaded: text_helper
INFO - 2018-05-12 04:03:22 --> Helper loaded: string_helper
INFO - 2018-05-12 04:03:22 --> Database Driver Class Initialized
DEBUG - 2018-05-12 04:03:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-12 04:03:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-12 04:03:22 --> Email Class Initialized
INFO - 2018-05-12 04:03:22 --> Controller Class Initialized
DEBUG - 2018-05-12 04:03:22 --> Admin MX_Controller Initialized
INFO - 2018-05-12 04:03:22 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-12 04:03:22 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-12 04:03:22 --> Login MX_Controller Initialized
DEBUG - 2018-05-12 04:03:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-12 04:03:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-12 04:03:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-05-12 04:03:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-05-12 04:03:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-05-12 04:03:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-05-12 04:03:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-05-12 04:03:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/dashboard.php
INFO - 2018-05-12 04:03:22 --> Final output sent to browser
DEBUG - 2018-05-12 04:03:22 --> Total execution time: 0.6708
INFO - 2018-05-12 04:03:22 --> Config Class Initialized
INFO - 2018-05-12 04:03:22 --> Hooks Class Initialized
DEBUG - 2018-05-12 04:03:23 --> UTF-8 Support Enabled
INFO - 2018-05-12 04:03:23 --> Utf8 Class Initialized
INFO - 2018-05-12 04:03:23 --> URI Class Initialized
INFO - 2018-05-12 04:03:23 --> Config Class Initialized
INFO - 2018-05-12 04:03:23 --> Router Class Initialized
INFO - 2018-05-12 04:03:23 --> Hooks Class Initialized
DEBUG - 2018-05-12 04:03:23 --> UTF-8 Support Enabled
INFO - 2018-05-12 04:03:23 --> Output Class Initialized
INFO - 2018-05-12 04:03:23 --> Utf8 Class Initialized
INFO - 2018-05-12 04:03:23 --> URI Class Initialized
INFO - 2018-05-12 04:03:23 --> Security Class Initialized
DEBUG - 2018-05-12 04:03:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 04:03:23 --> Router Class Initialized
INFO - 2018-05-12 04:03:23 --> Output Class Initialized
INFO - 2018-05-12 04:03:23 --> Security Class Initialized
INFO - 2018-05-12 04:03:23 --> Input Class Initialized
DEBUG - 2018-05-12 04:03:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 04:03:23 --> Input Class Initialized
INFO - 2018-05-12 04:03:23 --> Language Class Initialized
ERROR - 2018-05-12 04:03:23 --> 404 Page Not Found: /index
INFO - 2018-05-12 04:03:23 --> Language Class Initialized
ERROR - 2018-05-12 04:03:23 --> 404 Page Not Found: /index
INFO - 2018-05-12 04:03:23 --> Config Class Initialized
INFO - 2018-05-12 04:03:23 --> Hooks Class Initialized
DEBUG - 2018-05-12 04:03:23 --> UTF-8 Support Enabled
INFO - 2018-05-12 04:03:23 --> Utf8 Class Initialized
INFO - 2018-05-12 04:03:23 --> URI Class Initialized
INFO - 2018-05-12 04:03:23 --> Router Class Initialized
INFO - 2018-05-12 04:03:23 --> Output Class Initialized
INFO - 2018-05-12 04:03:23 --> Security Class Initialized
DEBUG - 2018-05-12 04:03:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 04:03:23 --> Input Class Initialized
INFO - 2018-05-12 04:03:23 --> Language Class Initialized
ERROR - 2018-05-12 04:03:23 --> 404 Page Not Found: /index
INFO - 2018-05-12 04:03:27 --> Config Class Initialized
INFO - 2018-05-12 04:03:27 --> Hooks Class Initialized
DEBUG - 2018-05-12 04:03:27 --> UTF-8 Support Enabled
INFO - 2018-05-12 04:03:27 --> Utf8 Class Initialized
INFO - 2018-05-12 04:03:27 --> URI Class Initialized
INFO - 2018-05-12 04:03:27 --> Router Class Initialized
INFO - 2018-05-12 04:03:27 --> Output Class Initialized
INFO - 2018-05-12 04:03:27 --> Security Class Initialized
DEBUG - 2018-05-12 04:03:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 04:03:27 --> Input Class Initialized
INFO - 2018-05-12 04:03:27 --> Language Class Initialized
INFO - 2018-05-12 04:03:27 --> Language Class Initialized
INFO - 2018-05-12 04:03:27 --> Config Class Initialized
INFO - 2018-05-12 04:03:27 --> Loader Class Initialized
DEBUG - 2018-05-12 04:03:27 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-12 04:03:27 --> Helper loaded: url_helper
INFO - 2018-05-12 04:03:28 --> Helper loaded: form_helper
INFO - 2018-05-12 04:03:28 --> Helper loaded: date_helper
INFO - 2018-05-12 04:03:28 --> Helper loaded: util_helper
INFO - 2018-05-12 04:03:28 --> Helper loaded: text_helper
INFO - 2018-05-12 04:03:28 --> Helper loaded: string_helper
INFO - 2018-05-12 04:03:28 --> Database Driver Class Initialized
DEBUG - 2018-05-12 04:03:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-12 04:03:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-12 04:03:28 --> Email Class Initialized
INFO - 2018-05-12 04:03:28 --> Controller Class Initialized
DEBUG - 2018-05-12 04:03:28 --> Login MX_Controller Initialized
INFO - 2018-05-12 04:03:28 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-12 04:03:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-12 04:03:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-12 04:03:28 --> 4 Loggedout
INFO - 2018-05-12 04:03:28 --> Config Class Initialized
INFO - 2018-05-12 04:03:28 --> Hooks Class Initialized
DEBUG - 2018-05-12 04:03:28 --> UTF-8 Support Enabled
INFO - 2018-05-12 04:03:28 --> Utf8 Class Initialized
INFO - 2018-05-12 04:03:28 --> URI Class Initialized
INFO - 2018-05-12 04:03:28 --> Router Class Initialized
INFO - 2018-05-12 04:03:28 --> Output Class Initialized
INFO - 2018-05-12 04:03:28 --> Security Class Initialized
DEBUG - 2018-05-12 04:03:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 04:03:28 --> Input Class Initialized
INFO - 2018-05-12 04:03:28 --> Language Class Initialized
INFO - 2018-05-12 04:03:28 --> Language Class Initialized
INFO - 2018-05-12 04:03:28 --> Config Class Initialized
INFO - 2018-05-12 04:03:28 --> Loader Class Initialized
DEBUG - 2018-05-12 04:03:28 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-12 04:03:28 --> Helper loaded: url_helper
INFO - 2018-05-12 04:03:28 --> Helper loaded: form_helper
INFO - 2018-05-12 04:03:28 --> Helper loaded: date_helper
INFO - 2018-05-12 04:03:28 --> Helper loaded: util_helper
INFO - 2018-05-12 04:03:28 --> Helper loaded: text_helper
INFO - 2018-05-12 04:03:28 --> Helper loaded: string_helper
INFO - 2018-05-12 04:03:28 --> Database Driver Class Initialized
DEBUG - 2018-05-12 04:03:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-12 04:03:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-12 04:03:28 --> Email Class Initialized
INFO - 2018-05-12 04:03:28 --> Controller Class Initialized
DEBUG - 2018-05-12 04:03:28 --> Home MX_Controller Initialized
DEBUG - 2018-05-12 04:03:28 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-12 04:03:28 --> Login MX_Controller Initialized
INFO - 2018-05-12 04:03:28 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-12 04:03:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-12 04:03:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-12 04:03:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/login.php
INFO - 2018-05-12 04:03:30 --> Config Class Initialized
INFO - 2018-05-12 04:03:30 --> Hooks Class Initialized
DEBUG - 2018-05-12 04:03:30 --> UTF-8 Support Enabled
INFO - 2018-05-12 04:03:30 --> Utf8 Class Initialized
INFO - 2018-05-12 04:03:30 --> URI Class Initialized
INFO - 2018-05-12 04:03:30 --> Router Class Initialized
INFO - 2018-05-12 04:03:30 --> Output Class Initialized
INFO - 2018-05-12 04:03:30 --> Security Class Initialized
DEBUG - 2018-05-12 04:03:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 04:03:30 --> Input Class Initialized
INFO - 2018-05-12 04:03:30 --> Language Class Initialized
INFO - 2018-05-12 04:03:30 --> Language Class Initialized
INFO - 2018-05-12 04:03:30 --> Config Class Initialized
INFO - 2018-05-12 04:03:30 --> Loader Class Initialized
DEBUG - 2018-05-12 04:03:30 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-12 04:03:30 --> Helper loaded: url_helper
INFO - 2018-05-12 04:03:30 --> Helper loaded: form_helper
INFO - 2018-05-12 04:03:30 --> Helper loaded: date_helper
INFO - 2018-05-12 04:03:30 --> Helper loaded: util_helper
INFO - 2018-05-12 04:03:30 --> Helper loaded: text_helper
INFO - 2018-05-12 04:03:30 --> Helper loaded: string_helper
INFO - 2018-05-12 04:03:30 --> Database Driver Class Initialized
DEBUG - 2018-05-12 04:03:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-12 04:03:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-12 04:03:30 --> Email Class Initialized
INFO - 2018-05-12 04:03:30 --> Controller Class Initialized
DEBUG - 2018-05-12 04:03:30 --> Login MX_Controller Initialized
INFO - 2018-05-12 04:03:30 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-12 04:03:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-12 04:03:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-12 04:03:30 --> Email starts for gopipanguluri123@gmail.com fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-05-12 04:03:30 --> User session created for 4
INFO - 2018-05-12 04:03:30 --> Login status gopipanguluri123@gmail.com - success
INFO - 2018-05-12 04:03:30 --> Final output sent to browser
DEBUG - 2018-05-12 04:03:30 --> Total execution time: 0.5681
INFO - 2018-05-12 04:03:30 --> Config Class Initialized
INFO - 2018-05-12 04:03:30 --> Hooks Class Initialized
DEBUG - 2018-05-12 04:03:30 --> UTF-8 Support Enabled
INFO - 2018-05-12 04:03:30 --> Utf8 Class Initialized
INFO - 2018-05-12 04:03:30 --> URI Class Initialized
INFO - 2018-05-12 04:03:30 --> Router Class Initialized
INFO - 2018-05-12 04:03:30 --> Output Class Initialized
INFO - 2018-05-12 04:03:30 --> Security Class Initialized
DEBUG - 2018-05-12 04:03:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 04:03:30 --> Input Class Initialized
INFO - 2018-05-12 04:03:30 --> Language Class Initialized
INFO - 2018-05-12 04:03:30 --> Language Class Initialized
INFO - 2018-05-12 04:03:30 --> Config Class Initialized
INFO - 2018-05-12 04:03:30 --> Loader Class Initialized
DEBUG - 2018-05-12 04:03:30 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-12 04:03:30 --> Helper loaded: url_helper
INFO - 2018-05-12 04:03:30 --> Helper loaded: form_helper
INFO - 2018-05-12 04:03:30 --> Helper loaded: date_helper
INFO - 2018-05-12 04:03:30 --> Helper loaded: util_helper
INFO - 2018-05-12 04:03:30 --> Helper loaded: text_helper
INFO - 2018-05-12 04:03:30 --> Helper loaded: string_helper
INFO - 2018-05-12 04:03:31 --> Database Driver Class Initialized
DEBUG - 2018-05-12 04:03:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-12 04:03:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-12 04:03:31 --> Email Class Initialized
INFO - 2018-05-12 04:03:31 --> Controller Class Initialized
DEBUG - 2018-05-12 04:03:31 --> Home MX_Controller Initialized
DEBUG - 2018-05-12 04:03:31 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-12 04:03:31 --> Login MX_Controller Initialized
INFO - 2018-05-12 04:03:31 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-12 04:03:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-12 04:03:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-12 04:03:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-05-12 04:03:31 --> Final output sent to browser
INFO - 2018-05-12 04:03:31 --> Config Class Initialized
DEBUG - 2018-05-12 04:03:31 --> Total execution time: 0.6276
INFO - 2018-05-12 04:03:31 --> Hooks Class Initialized
DEBUG - 2018-05-12 04:03:31 --> UTF-8 Support Enabled
INFO - 2018-05-12 04:03:31 --> Utf8 Class Initialized
INFO - 2018-05-12 04:03:31 --> URI Class Initialized
INFO - 2018-05-12 04:03:31 --> Router Class Initialized
INFO - 2018-05-12 04:03:31 --> Output Class Initialized
INFO - 2018-05-12 04:03:31 --> Security Class Initialized
DEBUG - 2018-05-12 04:03:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 04:03:31 --> Config Class Initialized
INFO - 2018-05-12 04:03:31 --> Config Class Initialized
INFO - 2018-05-12 04:03:31 --> Config Class Initialized
INFO - 2018-05-12 04:03:31 --> Hooks Class Initialized
INFO - 2018-05-12 04:03:31 --> Hooks Class Initialized
INFO - 2018-05-12 04:03:31 --> Hooks Class Initialized
INFO - 2018-05-12 04:03:31 --> Config Class Initialized
INFO - 2018-05-12 04:03:31 --> Input Class Initialized
DEBUG - 2018-05-12 04:03:31 --> UTF-8 Support Enabled
INFO - 2018-05-12 04:03:31 --> Config Class Initialized
INFO - 2018-05-12 04:03:31 --> Hooks Class Initialized
INFO - 2018-05-12 04:03:31 --> Utf8 Class Initialized
INFO - 2018-05-12 04:03:31 --> Hooks Class Initialized
INFO - 2018-05-12 04:03:31 --> Language Class Initialized
DEBUG - 2018-05-12 04:03:31 --> UTF-8 Support Enabled
DEBUG - 2018-05-12 04:03:31 --> UTF-8 Support Enabled
DEBUG - 2018-05-12 04:03:31 --> UTF-8 Support Enabled
INFO - 2018-05-12 04:03:31 --> Utf8 Class Initialized
INFO - 2018-05-12 04:03:31 --> URI Class Initialized
ERROR - 2018-05-12 04:03:31 --> 404 Page Not Found: /index
DEBUG - 2018-05-12 04:03:31 --> UTF-8 Support Enabled
INFO - 2018-05-12 04:03:31 --> Utf8 Class Initialized
INFO - 2018-05-12 04:03:31 --> Utf8 Class Initialized
INFO - 2018-05-12 04:03:31 --> URI Class Initialized
INFO - 2018-05-12 04:03:31 --> Router Class Initialized
INFO - 2018-05-12 04:03:31 --> Router Class Initialized
INFO - 2018-05-12 04:03:31 --> URI Class Initialized
INFO - 2018-05-12 04:03:31 --> URI Class Initialized
INFO - 2018-05-12 04:03:31 --> Utf8 Class Initialized
INFO - 2018-05-12 04:03:31 --> Config Class Initialized
INFO - 2018-05-12 04:03:31 --> Output Class Initialized
INFO - 2018-05-12 04:03:31 --> Router Class Initialized
INFO - 2018-05-12 04:03:31 --> Router Class Initialized
INFO - 2018-05-12 04:03:31 --> URI Class Initialized
INFO - 2018-05-12 04:03:31 --> Hooks Class Initialized
INFO - 2018-05-12 04:03:31 --> Output Class Initialized
INFO - 2018-05-12 04:03:31 --> Security Class Initialized
DEBUG - 2018-05-12 04:03:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 04:03:31 --> Input Class Initialized
DEBUG - 2018-05-12 04:03:31 --> UTF-8 Support Enabled
INFO - 2018-05-12 04:03:31 --> Security Class Initialized
INFO - 2018-05-12 04:03:31 --> Router Class Initialized
INFO - 2018-05-12 04:03:31 --> Output Class Initialized
INFO - 2018-05-12 04:03:31 --> Output Class Initialized
INFO - 2018-05-12 04:03:31 --> Language Class Initialized
INFO - 2018-05-12 04:03:31 --> Utf8 Class Initialized
INFO - 2018-05-12 04:03:31 --> URI Class Initialized
ERROR - 2018-05-12 04:03:31 --> 404 Page Not Found: /index
INFO - 2018-05-12 04:03:31 --> Router Class Initialized
INFO - 2018-05-12 04:03:31 --> Security Class Initialized
INFO - 2018-05-12 04:03:32 --> Output Class Initialized
DEBUG - 2018-05-12 04:03:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 04:03:32 --> Config Class Initialized
INFO - 2018-05-12 04:03:32 --> Input Class Initialized
INFO - 2018-05-12 04:03:32 --> Security Class Initialized
INFO - 2018-05-12 04:03:32 --> Security Class Initialized
DEBUG - 2018-05-12 04:03:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 04:03:32 --> Output Class Initialized
INFO - 2018-05-12 04:03:32 --> Hooks Class Initialized
DEBUG - 2018-05-12 04:03:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 04:03:32 --> Input Class Initialized
INFO - 2018-05-12 04:03:32 --> Language Class Initialized
DEBUG - 2018-05-12 04:03:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 04:03:32 --> Security Class Initialized
INFO - 2018-05-12 04:03:32 --> Input Class Initialized
INFO - 2018-05-12 04:03:32 --> Language Class Initialized
DEBUG - 2018-05-12 04:03:32 --> UTF-8 Support Enabled
DEBUG - 2018-05-12 04:03:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 04:03:32 --> Input Class Initialized
ERROR - 2018-05-12 04:03:32 --> 404 Page Not Found: /index
INFO - 2018-05-12 04:03:32 --> Language Class Initialized
ERROR - 2018-05-12 04:03:32 --> 404 Page Not Found: /index
INFO - 2018-05-12 04:03:32 --> Config Class Initialized
INFO - 2018-05-12 04:03:32 --> Hooks Class Initialized
DEBUG - 2018-05-12 04:03:32 --> UTF-8 Support Enabled
INFO - 2018-05-12 04:03:32 --> Utf8 Class Initialized
INFO - 2018-05-12 04:03:32 --> URI Class Initialized
ERROR - 2018-05-12 04:03:32 --> 404 Page Not Found: /index
INFO - 2018-05-12 04:03:32 --> Utf8 Class Initialized
INFO - 2018-05-12 04:03:32 --> Input Class Initialized
INFO - 2018-05-12 04:03:32 --> Language Class Initialized
INFO - 2018-05-12 04:03:32 --> Router Class Initialized
INFO - 2018-05-12 04:03:32 --> Config Class Initialized
ERROR - 2018-05-12 04:03:32 --> 404 Page Not Found: /index
INFO - 2018-05-12 04:03:32 --> URI Class Initialized
INFO - 2018-05-12 04:03:32 --> Language Class Initialized
INFO - 2018-05-12 04:03:32 --> Output Class Initialized
INFO - 2018-05-12 04:03:32 --> Hooks Class Initialized
ERROR - 2018-05-12 04:03:32 --> 404 Page Not Found: /index
INFO - 2018-05-12 04:03:32 --> Router Class Initialized
INFO - 2018-05-12 04:03:32 --> Security Class Initialized
INFO - 2018-05-12 04:03:32 --> Config Class Initialized
INFO - 2018-05-12 04:03:32 --> Hooks Class Initialized
INFO - 2018-05-12 04:03:32 --> Output Class Initialized
DEBUG - 2018-05-12 04:03:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 04:03:32 --> Config Class Initialized
DEBUG - 2018-05-12 04:03:32 --> UTF-8 Support Enabled
INFO - 2018-05-12 04:03:32 --> Hooks Class Initialized
DEBUG - 2018-05-12 04:03:32 --> UTF-8 Support Enabled
DEBUG - 2018-05-12 04:03:32 --> UTF-8 Support Enabled
INFO - 2018-05-12 04:03:32 --> Input Class Initialized
INFO - 2018-05-12 04:03:32 --> Security Class Initialized
INFO - 2018-05-12 04:03:32 --> Utf8 Class Initialized
INFO - 2018-05-12 04:03:32 --> Utf8 Class Initialized
INFO - 2018-05-12 04:03:32 --> URI Class Initialized
INFO - 2018-05-12 04:03:32 --> Language Class Initialized
INFO - 2018-05-12 04:03:32 --> Utf8 Class Initialized
DEBUG - 2018-05-12 04:03:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 04:03:32 --> URI Class Initialized
ERROR - 2018-05-12 04:03:32 --> 404 Page Not Found: /index
INFO - 2018-05-12 04:03:32 --> Router Class Initialized
INFO - 2018-05-12 04:03:32 --> Output Class Initialized
INFO - 2018-05-12 04:03:32 --> Config Class Initialized
INFO - 2018-05-12 04:03:32 --> Input Class Initialized
INFO - 2018-05-12 04:03:32 --> Router Class Initialized
INFO - 2018-05-12 04:03:32 --> URI Class Initialized
INFO - 2018-05-12 04:03:32 --> Hooks Class Initialized
INFO - 2018-05-12 04:03:32 --> Language Class Initialized
INFO - 2018-05-12 04:03:32 --> Output Class Initialized
INFO - 2018-05-12 04:03:32 --> Security Class Initialized
INFO - 2018-05-12 04:03:32 --> Router Class Initialized
DEBUG - 2018-05-12 04:03:32 --> UTF-8 Support Enabled
INFO - 2018-05-12 04:03:32 --> Output Class Initialized
ERROR - 2018-05-12 04:03:32 --> 404 Page Not Found: /index
INFO - 2018-05-12 04:03:32 --> Security Class Initialized
DEBUG - 2018-05-12 04:03:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 04:03:32 --> Config Class Initialized
INFO - 2018-05-12 04:03:32 --> Utf8 Class Initialized
INFO - 2018-05-12 04:03:32 --> Security Class Initialized
DEBUG - 2018-05-12 04:03:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 04:03:32 --> Input Class Initialized
INFO - 2018-05-12 04:03:32 --> URI Class Initialized
INFO - 2018-05-12 04:03:32 --> Router Class Initialized
INFO - 2018-05-12 04:03:32 --> Output Class Initialized
INFO - 2018-05-12 04:03:32 --> Security Class Initialized
DEBUG - 2018-05-12 04:03:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 04:03:32 --> Input Class Initialized
INFO - 2018-05-12 04:03:32 --> Language Class Initialized
ERROR - 2018-05-12 04:03:32 --> 404 Page Not Found: /index
INFO - 2018-05-12 04:03:33 --> Hooks Class Initialized
DEBUG - 2018-05-12 04:03:33 --> UTF-8 Support Enabled
INFO - 2018-05-12 04:03:33 --> Utf8 Class Initialized
INFO - 2018-05-12 04:03:33 --> URI Class Initialized
DEBUG - 2018-05-12 04:03:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 04:03:33 --> Language Class Initialized
INFO - 2018-05-12 04:03:33 --> Input Class Initialized
INFO - 2018-05-12 04:03:33 --> Router Class Initialized
INFO - 2018-05-12 04:03:33 --> Input Class Initialized
INFO - 2018-05-12 04:03:33 --> Output Class Initialized
INFO - 2018-05-12 04:03:33 --> Language Class Initialized
INFO - 2018-05-12 04:03:33 --> Language Class Initialized
ERROR - 2018-05-12 04:03:33 --> 404 Page Not Found: /index
ERROR - 2018-05-12 04:03:33 --> 404 Page Not Found: /index
INFO - 2018-05-12 04:03:33 --> Security Class Initialized
ERROR - 2018-05-12 04:03:33 --> 404 Page Not Found: /index
INFO - 2018-05-12 04:03:33 --> Config Class Initialized
INFO - 2018-05-12 04:03:33 --> Hooks Class Initialized
INFO - 2018-05-12 04:03:33 --> Config Class Initialized
DEBUG - 2018-05-12 04:03:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 04:03:33 --> Hooks Class Initialized
DEBUG - 2018-05-12 04:03:33 --> UTF-8 Support Enabled
INFO - 2018-05-12 04:03:33 --> Config Class Initialized
INFO - 2018-05-12 04:03:33 --> Input Class Initialized
INFO - 2018-05-12 04:03:33 --> Language Class Initialized
DEBUG - 2018-05-12 04:03:33 --> UTF-8 Support Enabled
INFO - 2018-05-12 04:03:33 --> Hooks Class Initialized
INFO - 2018-05-12 04:03:33 --> Utf8 Class Initialized
INFO - 2018-05-12 04:03:33 --> Utf8 Class Initialized
INFO - 2018-05-12 04:03:33 --> URI Class Initialized
DEBUG - 2018-05-12 04:03:33 --> UTF-8 Support Enabled
ERROR - 2018-05-12 04:03:33 --> 404 Page Not Found: /index
INFO - 2018-05-12 04:03:33 --> URI Class Initialized
INFO - 2018-05-12 04:03:33 --> Router Class Initialized
INFO - 2018-05-12 04:03:33 --> Output Class Initialized
INFO - 2018-05-12 04:03:33 --> Utf8 Class Initialized
INFO - 2018-05-12 04:03:33 --> Router Class Initialized
INFO - 2018-05-12 04:03:33 --> Security Class Initialized
INFO - 2018-05-12 04:03:33 --> Output Class Initialized
INFO - 2018-05-12 04:03:33 --> URI Class Initialized
DEBUG - 2018-05-12 04:03:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 04:03:33 --> Security Class Initialized
DEBUG - 2018-05-12 04:03:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 04:03:33 --> Input Class Initialized
INFO - 2018-05-12 04:03:33 --> Router Class Initialized
INFO - 2018-05-12 04:03:33 --> Input Class Initialized
INFO - 2018-05-12 04:03:33 --> Output Class Initialized
INFO - 2018-05-12 04:03:33 --> Language Class Initialized
INFO - 2018-05-12 04:03:33 --> Security Class Initialized
INFO - 2018-05-12 04:03:33 --> Language Class Initialized
DEBUG - 2018-05-12 04:03:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-05-12 04:03:33 --> 404 Page Not Found: /index
INFO - 2018-05-12 04:03:33 --> Input Class Initialized
INFO - 2018-05-12 04:03:33 --> Language Class Initialized
ERROR - 2018-05-12 04:03:33 --> 404 Page Not Found: /index
ERROR - 2018-05-12 04:03:33 --> 404 Page Not Found: /index
INFO - 2018-05-12 04:03:33 --> Config Class Initialized
INFO - 2018-05-12 04:03:33 --> Hooks Class Initialized
DEBUG - 2018-05-12 04:03:33 --> UTF-8 Support Enabled
INFO - 2018-05-12 04:03:33 --> Utf8 Class Initialized
INFO - 2018-05-12 04:03:33 --> URI Class Initialized
INFO - 2018-05-12 04:03:33 --> Router Class Initialized
INFO - 2018-05-12 04:03:33 --> Output Class Initialized
INFO - 2018-05-12 04:03:33 --> Security Class Initialized
DEBUG - 2018-05-12 04:03:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 04:03:33 --> Input Class Initialized
INFO - 2018-05-12 04:03:33 --> Language Class Initialized
ERROR - 2018-05-12 04:03:33 --> 404 Page Not Found: /index
INFO - 2018-05-12 04:03:33 --> Config Class Initialized
INFO - 2018-05-12 04:03:33 --> Hooks Class Initialized
DEBUG - 2018-05-12 04:03:33 --> UTF-8 Support Enabled
INFO - 2018-05-12 04:03:33 --> Utf8 Class Initialized
INFO - 2018-05-12 04:03:33 --> URI Class Initialized
INFO - 2018-05-12 04:03:33 --> Router Class Initialized
INFO - 2018-05-12 04:03:33 --> Output Class Initialized
INFO - 2018-05-12 04:03:33 --> Security Class Initialized
DEBUG - 2018-05-12 04:03:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 04:03:34 --> Input Class Initialized
INFO - 2018-05-12 04:03:34 --> Language Class Initialized
ERROR - 2018-05-12 04:03:34 --> 404 Page Not Found: /index
INFO - 2018-05-12 04:03:34 --> Config Class Initialized
INFO - 2018-05-12 04:03:34 --> Hooks Class Initialized
DEBUG - 2018-05-12 04:03:34 --> UTF-8 Support Enabled
INFO - 2018-05-12 04:03:34 --> Utf8 Class Initialized
INFO - 2018-05-12 04:03:34 --> URI Class Initialized
INFO - 2018-05-12 04:03:34 --> Router Class Initialized
INFO - 2018-05-12 04:03:34 --> Output Class Initialized
INFO - 2018-05-12 04:03:34 --> Security Class Initialized
DEBUG - 2018-05-12 04:03:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 04:03:34 --> Input Class Initialized
INFO - 2018-05-12 04:03:34 --> Language Class Initialized
ERROR - 2018-05-12 04:03:34 --> 404 Page Not Found: /index
INFO - 2018-05-12 04:06:04 --> Config Class Initialized
INFO - 2018-05-12 04:06:04 --> Hooks Class Initialized
DEBUG - 2018-05-12 04:06:04 --> UTF-8 Support Enabled
INFO - 2018-05-12 04:06:04 --> Utf8 Class Initialized
INFO - 2018-05-12 04:06:04 --> URI Class Initialized
INFO - 2018-05-12 04:06:04 --> Router Class Initialized
INFO - 2018-05-12 04:06:04 --> Output Class Initialized
INFO - 2018-05-12 04:06:04 --> Security Class Initialized
DEBUG - 2018-05-12 04:06:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 04:06:04 --> Input Class Initialized
INFO - 2018-05-12 04:06:04 --> Language Class Initialized
INFO - 2018-05-12 04:06:04 --> Language Class Initialized
INFO - 2018-05-12 04:06:04 --> Config Class Initialized
INFO - 2018-05-12 04:06:04 --> Loader Class Initialized
DEBUG - 2018-05-12 04:06:04 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-12 04:06:04 --> Helper loaded: url_helper
INFO - 2018-05-12 04:06:05 --> Helper loaded: form_helper
INFO - 2018-05-12 04:06:05 --> Helper loaded: date_helper
INFO - 2018-05-12 04:06:05 --> Helper loaded: util_helper
INFO - 2018-05-12 04:06:05 --> Helper loaded: text_helper
INFO - 2018-05-12 04:06:05 --> Helper loaded: string_helper
INFO - 2018-05-12 04:06:05 --> Database Driver Class Initialized
DEBUG - 2018-05-12 04:06:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-12 04:06:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-12 04:06:05 --> Email Class Initialized
INFO - 2018-05-12 04:06:05 --> Controller Class Initialized
DEBUG - 2018-05-12 04:06:05 --> Admin MX_Controller Initialized
INFO - 2018-05-12 04:06:05 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-12 04:06:05 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-12 04:06:05 --> Login MX_Controller Initialized
DEBUG - 2018-05-12 04:06:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-12 04:06:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-12 04:06:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-05-12 04:06:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-05-12 04:06:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-05-12 04:06:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-05-12 04:06:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-05-12 04:06:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/dashboard.php
INFO - 2018-05-12 04:06:05 --> Final output sent to browser
DEBUG - 2018-05-12 04:06:05 --> Total execution time: 0.6514
INFO - 2018-05-12 04:06:05 --> Config Class Initialized
INFO - 2018-05-12 04:06:05 --> Hooks Class Initialized
DEBUG - 2018-05-12 04:06:05 --> UTF-8 Support Enabled
INFO - 2018-05-12 04:06:05 --> Utf8 Class Initialized
INFO - 2018-05-12 04:06:05 --> URI Class Initialized
INFO - 2018-05-12 04:06:05 --> Router Class Initialized
INFO - 2018-05-12 04:06:05 --> Output Class Initialized
INFO - 2018-05-12 04:06:05 --> Security Class Initialized
DEBUG - 2018-05-12 04:06:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 04:06:05 --> Input Class Initialized
INFO - 2018-05-12 04:06:05 --> Language Class Initialized
INFO - 2018-05-12 04:06:05 --> Config Class Initialized
INFO - 2018-05-12 04:06:05 --> Hooks Class Initialized
ERROR - 2018-05-12 04:06:05 --> 404 Page Not Found: /index
DEBUG - 2018-05-12 04:06:05 --> UTF-8 Support Enabled
INFO - 2018-05-12 04:06:05 --> Utf8 Class Initialized
INFO - 2018-05-12 04:06:06 --> URI Class Initialized
INFO - 2018-05-12 04:06:06 --> Router Class Initialized
INFO - 2018-05-12 04:06:06 --> Output Class Initialized
INFO - 2018-05-12 04:06:06 --> Security Class Initialized
DEBUG - 2018-05-12 04:06:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 04:06:06 --> Input Class Initialized
INFO - 2018-05-12 04:06:06 --> Language Class Initialized
ERROR - 2018-05-12 04:06:06 --> 404 Page Not Found: /index
INFO - 2018-05-12 04:06:36 --> Config Class Initialized
INFO - 2018-05-12 04:06:36 --> Hooks Class Initialized
DEBUG - 2018-05-12 04:06:36 --> UTF-8 Support Enabled
INFO - 2018-05-12 04:06:36 --> Utf8 Class Initialized
INFO - 2018-05-12 04:06:36 --> URI Class Initialized
INFO - 2018-05-12 04:06:36 --> Router Class Initialized
INFO - 2018-05-12 04:06:36 --> Output Class Initialized
INFO - 2018-05-12 04:06:36 --> Security Class Initialized
DEBUG - 2018-05-12 04:06:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 04:06:36 --> Input Class Initialized
INFO - 2018-05-12 04:06:36 --> Language Class Initialized
INFO - 2018-05-12 04:06:36 --> Language Class Initialized
INFO - 2018-05-12 04:06:36 --> Config Class Initialized
INFO - 2018-05-12 04:06:36 --> Loader Class Initialized
DEBUG - 2018-05-12 04:06:36 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-12 04:06:36 --> Helper loaded: url_helper
INFO - 2018-05-12 04:06:36 --> Helper loaded: form_helper
INFO - 2018-05-12 04:06:36 --> Helper loaded: date_helper
INFO - 2018-05-12 04:06:36 --> Helper loaded: util_helper
INFO - 2018-05-12 04:06:36 --> Helper loaded: text_helper
INFO - 2018-05-12 04:06:36 --> Helper loaded: string_helper
INFO - 2018-05-12 04:06:36 --> Database Driver Class Initialized
DEBUG - 2018-05-12 04:06:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-12 04:06:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-12 04:06:36 --> Email Class Initialized
INFO - 2018-05-12 04:06:36 --> Controller Class Initialized
DEBUG - 2018-05-12 04:06:36 --> Admin MX_Controller Initialized
INFO - 2018-05-12 04:06:36 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-12 04:06:36 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-12 04:06:37 --> Login MX_Controller Initialized
DEBUG - 2018-05-12 04:06:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-12 04:06:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-12 04:06:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-05-12 04:06:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-05-12 04:06:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-05-12 04:06:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-05-12 04:06:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-05-12 04:06:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/dashboard.php
INFO - 2018-05-12 04:06:37 --> Final output sent to browser
DEBUG - 2018-05-12 04:06:37 --> Total execution time: 0.6455
INFO - 2018-05-12 04:06:37 --> Config Class Initialized
INFO - 2018-05-12 04:06:37 --> Hooks Class Initialized
DEBUG - 2018-05-12 04:06:37 --> UTF-8 Support Enabled
INFO - 2018-05-12 04:06:37 --> Utf8 Class Initialized
INFO - 2018-05-12 04:06:37 --> URI Class Initialized
INFO - 2018-05-12 04:06:37 --> Router Class Initialized
INFO - 2018-05-12 04:06:37 --> Output Class Initialized
INFO - 2018-05-12 04:06:37 --> Security Class Initialized
DEBUG - 2018-05-12 04:06:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 04:06:37 --> Input Class Initialized
INFO - 2018-05-12 04:06:37 --> Language Class Initialized
ERROR - 2018-05-12 04:06:37 --> 404 Page Not Found: /index
INFO - 2018-05-12 04:06:37 --> Config Class Initialized
INFO - 2018-05-12 04:06:37 --> Hooks Class Initialized
DEBUG - 2018-05-12 04:06:37 --> UTF-8 Support Enabled
INFO - 2018-05-12 04:06:37 --> Utf8 Class Initialized
INFO - 2018-05-12 04:06:37 --> URI Class Initialized
INFO - 2018-05-12 04:06:37 --> Router Class Initialized
INFO - 2018-05-12 04:06:37 --> Output Class Initialized
INFO - 2018-05-12 04:06:37 --> Security Class Initialized
DEBUG - 2018-05-12 04:06:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 04:06:37 --> Input Class Initialized
INFO - 2018-05-12 04:06:37 --> Language Class Initialized
ERROR - 2018-05-12 04:06:37 --> 404 Page Not Found: /index
INFO - 2018-05-12 04:06:52 --> Config Class Initialized
INFO - 2018-05-12 04:06:52 --> Hooks Class Initialized
DEBUG - 2018-05-12 04:06:52 --> UTF-8 Support Enabled
INFO - 2018-05-12 04:06:52 --> Utf8 Class Initialized
INFO - 2018-05-12 04:06:52 --> URI Class Initialized
INFO - 2018-05-12 04:06:52 --> Router Class Initialized
INFO - 2018-05-12 04:06:52 --> Output Class Initialized
INFO - 2018-05-12 04:06:52 --> Security Class Initialized
DEBUG - 2018-05-12 04:06:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 04:06:52 --> Input Class Initialized
INFO - 2018-05-12 04:06:52 --> Language Class Initialized
INFO - 2018-05-12 04:06:52 --> Language Class Initialized
INFO - 2018-05-12 04:06:52 --> Config Class Initialized
INFO - 2018-05-12 04:06:52 --> Loader Class Initialized
DEBUG - 2018-05-12 04:06:52 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-12 04:06:52 --> Helper loaded: url_helper
INFO - 2018-05-12 04:06:52 --> Helper loaded: form_helper
INFO - 2018-05-12 04:06:52 --> Helper loaded: date_helper
INFO - 2018-05-12 04:06:52 --> Helper loaded: util_helper
INFO - 2018-05-12 04:06:52 --> Helper loaded: text_helper
INFO - 2018-05-12 04:06:52 --> Helper loaded: string_helper
INFO - 2018-05-12 04:06:52 --> Database Driver Class Initialized
DEBUG - 2018-05-12 04:06:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-12 04:06:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-12 04:06:52 --> Email Class Initialized
INFO - 2018-05-12 04:06:52 --> Controller Class Initialized
DEBUG - 2018-05-12 04:06:52 --> Admin MX_Controller Initialized
INFO - 2018-05-12 04:06:52 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-12 04:06:52 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-12 04:06:52 --> Login MX_Controller Initialized
DEBUG - 2018-05-12 04:06:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-12 04:06:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-12 04:06:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-05-12 04:06:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-05-12 04:06:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-05-12 04:06:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-05-12 04:06:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-05-12 04:06:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/dashboard.php
INFO - 2018-05-12 04:06:53 --> Final output sent to browser
DEBUG - 2018-05-12 04:06:53 --> Total execution time: 0.6527
INFO - 2018-05-12 04:06:53 --> Config Class Initialized
INFO - 2018-05-12 04:06:53 --> Hooks Class Initialized
DEBUG - 2018-05-12 04:06:53 --> UTF-8 Support Enabled
INFO - 2018-05-12 04:06:53 --> Utf8 Class Initialized
INFO - 2018-05-12 04:06:53 --> URI Class Initialized
INFO - 2018-05-12 04:06:53 --> Router Class Initialized
INFO - 2018-05-12 04:06:53 --> Output Class Initialized
INFO - 2018-05-12 04:06:53 --> Security Class Initialized
DEBUG - 2018-05-12 04:06:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 04:06:53 --> Input Class Initialized
INFO - 2018-05-12 04:06:53 --> Language Class Initialized
ERROR - 2018-05-12 04:06:53 --> 404 Page Not Found: /index
INFO - 2018-05-12 04:06:53 --> Config Class Initialized
INFO - 2018-05-12 04:06:53 --> Hooks Class Initialized
DEBUG - 2018-05-12 04:06:53 --> UTF-8 Support Enabled
INFO - 2018-05-12 04:06:53 --> Utf8 Class Initialized
INFO - 2018-05-12 04:06:53 --> URI Class Initialized
INFO - 2018-05-12 04:06:53 --> Router Class Initialized
INFO - 2018-05-12 04:06:53 --> Output Class Initialized
INFO - 2018-05-12 04:06:54 --> Security Class Initialized
DEBUG - 2018-05-12 04:06:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 04:06:54 --> Input Class Initialized
INFO - 2018-05-12 04:06:54 --> Language Class Initialized
ERROR - 2018-05-12 04:06:54 --> 404 Page Not Found: /index
INFO - 2018-05-12 04:07:28 --> Config Class Initialized
INFO - 2018-05-12 04:07:28 --> Hooks Class Initialized
DEBUG - 2018-05-12 04:07:28 --> UTF-8 Support Enabled
INFO - 2018-05-12 04:07:28 --> Utf8 Class Initialized
INFO - 2018-05-12 04:07:28 --> URI Class Initialized
INFO - 2018-05-12 04:07:28 --> Router Class Initialized
INFO - 2018-05-12 04:07:28 --> Output Class Initialized
INFO - 2018-05-12 04:07:28 --> Security Class Initialized
DEBUG - 2018-05-12 04:07:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 04:07:29 --> Input Class Initialized
INFO - 2018-05-12 04:07:29 --> Language Class Initialized
INFO - 2018-05-12 04:07:29 --> Language Class Initialized
INFO - 2018-05-12 04:07:29 --> Config Class Initialized
INFO - 2018-05-12 04:07:29 --> Loader Class Initialized
DEBUG - 2018-05-12 04:07:29 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-12 04:07:29 --> Helper loaded: url_helper
INFO - 2018-05-12 04:07:29 --> Helper loaded: form_helper
INFO - 2018-05-12 04:07:29 --> Helper loaded: date_helper
INFO - 2018-05-12 04:07:29 --> Helper loaded: util_helper
INFO - 2018-05-12 04:07:29 --> Helper loaded: text_helper
INFO - 2018-05-12 04:07:29 --> Helper loaded: string_helper
INFO - 2018-05-12 04:07:29 --> Database Driver Class Initialized
DEBUG - 2018-05-12 04:07:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-12 04:07:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-12 04:07:29 --> Email Class Initialized
INFO - 2018-05-12 04:07:29 --> Controller Class Initialized
DEBUG - 2018-05-12 04:07:29 --> Admin MX_Controller Initialized
INFO - 2018-05-12 04:07:29 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-12 04:07:29 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-12 04:07:29 --> Login MX_Controller Initialized
DEBUG - 2018-05-12 04:07:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-12 04:07:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-12 04:07:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-05-12 04:07:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-05-12 04:07:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-05-12 04:07:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-05-12 04:07:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-05-12 04:07:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/dashboard.php
INFO - 2018-05-12 04:07:29 --> Final output sent to browser
DEBUG - 2018-05-12 04:07:29 --> Total execution time: 0.6382
INFO - 2018-05-12 04:07:29 --> Config Class Initialized
INFO - 2018-05-12 04:07:29 --> Config Class Initialized
INFO - 2018-05-12 04:07:29 --> Hooks Class Initialized
INFO - 2018-05-12 04:07:29 --> Hooks Class Initialized
DEBUG - 2018-05-12 04:07:29 --> UTF-8 Support Enabled
DEBUG - 2018-05-12 04:07:29 --> UTF-8 Support Enabled
INFO - 2018-05-12 04:07:29 --> Utf8 Class Initialized
INFO - 2018-05-12 04:07:29 --> Utf8 Class Initialized
INFO - 2018-05-12 04:07:29 --> URI Class Initialized
INFO - 2018-05-12 04:07:29 --> URI Class Initialized
INFO - 2018-05-12 04:07:29 --> Router Class Initialized
INFO - 2018-05-12 04:07:29 --> Router Class Initialized
INFO - 2018-05-12 04:07:29 --> Output Class Initialized
INFO - 2018-05-12 04:07:29 --> Security Class Initialized
DEBUG - 2018-05-12 04:07:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 04:07:29 --> Input Class Initialized
INFO - 2018-05-12 04:07:29 --> Language Class Initialized
ERROR - 2018-05-12 04:07:29 --> 404 Page Not Found: /index
INFO - 2018-05-12 04:07:29 --> Output Class Initialized
INFO - 2018-05-12 04:07:29 --> Security Class Initialized
DEBUG - 2018-05-12 04:07:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 04:07:29 --> Input Class Initialized
INFO - 2018-05-12 04:07:30 --> Language Class Initialized
ERROR - 2018-05-12 04:07:30 --> 404 Page Not Found: /index
INFO - 2018-05-12 04:08:18 --> Config Class Initialized
INFO - 2018-05-12 04:08:18 --> Hooks Class Initialized
DEBUG - 2018-05-12 04:08:18 --> UTF-8 Support Enabled
INFO - 2018-05-12 04:08:18 --> Utf8 Class Initialized
INFO - 2018-05-12 04:08:18 --> URI Class Initialized
INFO - 2018-05-12 04:08:18 --> Router Class Initialized
INFO - 2018-05-12 04:08:18 --> Output Class Initialized
INFO - 2018-05-12 04:08:18 --> Security Class Initialized
DEBUG - 2018-05-12 04:08:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 04:08:18 --> Input Class Initialized
INFO - 2018-05-12 04:08:18 --> Language Class Initialized
INFO - 2018-05-12 04:08:18 --> Language Class Initialized
INFO - 2018-05-12 04:08:18 --> Config Class Initialized
INFO - 2018-05-12 04:08:18 --> Loader Class Initialized
DEBUG - 2018-05-12 04:08:18 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-12 04:08:18 --> Helper loaded: url_helper
INFO - 2018-05-12 04:08:18 --> Helper loaded: form_helper
INFO - 2018-05-12 04:08:18 --> Helper loaded: date_helper
INFO - 2018-05-12 04:08:18 --> Helper loaded: util_helper
INFO - 2018-05-12 04:08:18 --> Helper loaded: text_helper
INFO - 2018-05-12 04:08:18 --> Helper loaded: string_helper
INFO - 2018-05-12 04:08:18 --> Database Driver Class Initialized
DEBUG - 2018-05-12 04:08:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-12 04:08:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-12 04:08:18 --> Email Class Initialized
INFO - 2018-05-12 04:08:18 --> Controller Class Initialized
DEBUG - 2018-05-12 04:08:18 --> Admin MX_Controller Initialized
INFO - 2018-05-12 04:08:18 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-12 04:08:18 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-12 04:08:18 --> Login MX_Controller Initialized
DEBUG - 2018-05-12 04:08:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-12 04:08:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-12 04:08:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-05-12 04:08:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-05-12 04:08:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
ERROR - 2018-05-12 04:08:18 --> Severity: error --> Exception: Call to undefined function base() E:\xampp\htdocs\consulting\application\modules\common\views\common\footer.php 5
INFO - 2018-05-12 04:08:19 --> Config Class Initialized
INFO - 2018-05-12 04:08:19 --> Hooks Class Initialized
DEBUG - 2018-05-12 04:08:19 --> UTF-8 Support Enabled
INFO - 2018-05-12 04:08:19 --> Utf8 Class Initialized
INFO - 2018-05-12 04:08:19 --> URI Class Initialized
INFO - 2018-05-12 04:08:19 --> Router Class Initialized
INFO - 2018-05-12 04:08:19 --> Output Class Initialized
INFO - 2018-05-12 04:08:19 --> Security Class Initialized
DEBUG - 2018-05-12 04:08:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 04:08:19 --> Input Class Initialized
INFO - 2018-05-12 04:08:19 --> Language Class Initialized
ERROR - 2018-05-12 04:08:19 --> 404 Page Not Found: /index
INFO - 2018-05-12 04:08:29 --> Config Class Initialized
INFO - 2018-05-12 04:08:30 --> Hooks Class Initialized
DEBUG - 2018-05-12 04:08:30 --> UTF-8 Support Enabled
INFO - 2018-05-12 04:08:30 --> Utf8 Class Initialized
INFO - 2018-05-12 04:08:30 --> URI Class Initialized
INFO - 2018-05-12 04:08:30 --> Router Class Initialized
INFO - 2018-05-12 04:08:30 --> Output Class Initialized
INFO - 2018-05-12 04:08:30 --> Security Class Initialized
DEBUG - 2018-05-12 04:08:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 04:08:30 --> Input Class Initialized
INFO - 2018-05-12 04:08:30 --> Language Class Initialized
INFO - 2018-05-12 04:08:30 --> Language Class Initialized
INFO - 2018-05-12 04:08:30 --> Config Class Initialized
INFO - 2018-05-12 04:08:30 --> Loader Class Initialized
DEBUG - 2018-05-12 04:08:30 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-12 04:08:30 --> Helper loaded: url_helper
INFO - 2018-05-12 04:08:30 --> Helper loaded: form_helper
INFO - 2018-05-12 04:08:30 --> Helper loaded: date_helper
INFO - 2018-05-12 04:08:30 --> Helper loaded: util_helper
INFO - 2018-05-12 04:08:30 --> Helper loaded: text_helper
INFO - 2018-05-12 04:08:30 --> Helper loaded: string_helper
INFO - 2018-05-12 04:08:30 --> Database Driver Class Initialized
DEBUG - 2018-05-12 04:08:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-12 04:08:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-12 04:08:30 --> Email Class Initialized
INFO - 2018-05-12 04:08:30 --> Controller Class Initialized
DEBUG - 2018-05-12 04:08:30 --> Admin MX_Controller Initialized
INFO - 2018-05-12 04:08:30 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-12 04:08:30 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-12 04:08:30 --> Login MX_Controller Initialized
DEBUG - 2018-05-12 04:08:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-12 04:08:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-12 04:08:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-05-12 04:08:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-05-12 04:08:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-05-12 04:08:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-05-12 04:08:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-05-12 04:08:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/dashboard.php
INFO - 2018-05-12 04:08:30 --> Final output sent to browser
DEBUG - 2018-05-12 04:08:30 --> Total execution time: 0.6466
INFO - 2018-05-12 04:08:30 --> Config Class Initialized
INFO - 2018-05-12 04:08:30 --> Hooks Class Initialized
DEBUG - 2018-05-12 04:08:30 --> UTF-8 Support Enabled
INFO - 2018-05-12 04:08:30 --> Utf8 Class Initialized
INFO - 2018-05-12 04:08:30 --> URI Class Initialized
INFO - 2018-05-12 04:08:30 --> Router Class Initialized
INFO - 2018-05-12 04:08:31 --> Output Class Initialized
INFO - 2018-05-12 04:08:31 --> Security Class Initialized
DEBUG - 2018-05-12 04:08:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 04:08:31 --> Input Class Initialized
INFO - 2018-05-12 04:08:31 --> Config Class Initialized
INFO - 2018-05-12 04:08:31 --> Hooks Class Initialized
INFO - 2018-05-12 04:08:31 --> Language Class Initialized
DEBUG - 2018-05-12 04:08:31 --> UTF-8 Support Enabled
ERROR - 2018-05-12 04:08:31 --> 404 Page Not Found: /index
INFO - 2018-05-12 04:08:31 --> Utf8 Class Initialized
INFO - 2018-05-12 04:08:31 --> URI Class Initialized
INFO - 2018-05-12 04:08:31 --> Router Class Initialized
INFO - 2018-05-12 04:08:31 --> Output Class Initialized
INFO - 2018-05-12 04:08:31 --> Security Class Initialized
DEBUG - 2018-05-12 04:08:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 04:08:31 --> Input Class Initialized
INFO - 2018-05-12 04:08:31 --> Language Class Initialized
ERROR - 2018-05-12 04:08:31 --> 404 Page Not Found: /index
INFO - 2018-05-12 04:08:32 --> Config Class Initialized
INFO - 2018-05-12 04:08:32 --> Hooks Class Initialized
DEBUG - 2018-05-12 04:08:32 --> UTF-8 Support Enabled
INFO - 2018-05-12 04:08:32 --> Utf8 Class Initialized
INFO - 2018-05-12 04:08:32 --> URI Class Initialized
DEBUG - 2018-05-12 04:08:32 --> No URI present. Default controller set.
INFO - 2018-05-12 04:08:32 --> Router Class Initialized
INFO - 2018-05-12 04:08:32 --> Output Class Initialized
INFO - 2018-05-12 04:08:32 --> Security Class Initialized
DEBUG - 2018-05-12 04:08:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 04:08:32 --> Input Class Initialized
INFO - 2018-05-12 04:08:32 --> Language Class Initialized
INFO - 2018-05-12 04:08:32 --> Language Class Initialized
INFO - 2018-05-12 04:08:32 --> Config Class Initialized
INFO - 2018-05-12 04:08:32 --> Loader Class Initialized
DEBUG - 2018-05-12 04:08:33 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-12 04:08:33 --> Helper loaded: url_helper
INFO - 2018-05-12 04:08:33 --> Helper loaded: form_helper
INFO - 2018-05-12 04:08:33 --> Helper loaded: date_helper
INFO - 2018-05-12 04:08:33 --> Helper loaded: util_helper
INFO - 2018-05-12 04:08:33 --> Helper loaded: text_helper
INFO - 2018-05-12 04:08:33 --> Helper loaded: string_helper
INFO - 2018-05-12 04:08:33 --> Database Driver Class Initialized
DEBUG - 2018-05-12 04:08:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-12 04:08:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-12 04:08:33 --> Email Class Initialized
INFO - 2018-05-12 04:08:33 --> Controller Class Initialized
DEBUG - 2018-05-12 04:08:33 --> Home MX_Controller Initialized
DEBUG - 2018-05-12 04:08:33 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-12 04:08:33 --> Login MX_Controller Initialized
INFO - 2018-05-12 04:08:33 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-12 04:08:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-12 04:08:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-12 04:08:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-05-12 04:08:33 --> Final output sent to browser
INFO - 2018-05-12 04:08:33 --> Config Class Initialized
DEBUG - 2018-05-12 04:08:33 --> Total execution time: 0.7021
INFO - 2018-05-12 04:08:33 --> Hooks Class Initialized
DEBUG - 2018-05-12 04:08:33 --> UTF-8 Support Enabled
INFO - 2018-05-12 04:08:33 --> Utf8 Class Initialized
INFO - 2018-05-12 04:08:33 --> URI Class Initialized
INFO - 2018-05-12 04:08:33 --> Router Class Initialized
INFO - 2018-05-12 04:08:33 --> Output Class Initialized
INFO - 2018-05-12 04:08:33 --> Security Class Initialized
INFO - 2018-05-12 04:08:33 --> Config Class Initialized
INFO - 2018-05-12 04:08:33 --> Config Class Initialized
INFO - 2018-05-12 04:08:33 --> Config Class Initialized
INFO - 2018-05-12 04:08:33 --> Config Class Initialized
DEBUG - 2018-05-12 04:08:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 04:08:33 --> Config Class Initialized
INFO - 2018-05-12 04:08:33 --> Hooks Class Initialized
DEBUG - 2018-05-12 04:08:33 --> UTF-8 Support Enabled
INFO - 2018-05-12 04:08:33 --> Utf8 Class Initialized
INFO - 2018-05-12 04:08:33 --> URI Class Initialized
INFO - 2018-05-12 04:08:33 --> Router Class Initialized
INFO - 2018-05-12 04:08:33 --> Output Class Initialized
INFO - 2018-05-12 04:08:33 --> Security Class Initialized
DEBUG - 2018-05-12 04:08:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 04:08:33 --> Input Class Initialized
INFO - 2018-05-12 04:08:33 --> Language Class Initialized
ERROR - 2018-05-12 04:08:33 --> 404 Page Not Found: /index
INFO - 2018-05-12 04:08:34 --> Hooks Class Initialized
INFO - 2018-05-12 04:08:34 --> Hooks Class Initialized
INFO - 2018-05-12 04:08:34 --> Hooks Class Initialized
INFO - 2018-05-12 04:08:34 --> Hooks Class Initialized
INFO - 2018-05-12 04:08:34 --> Input Class Initialized
DEBUG - 2018-05-12 04:08:34 --> UTF-8 Support Enabled
INFO - 2018-05-12 04:08:34 --> Config Class Initialized
INFO - 2018-05-12 04:08:34 --> Language Class Initialized
DEBUG - 2018-05-12 04:08:34 --> UTF-8 Support Enabled
DEBUG - 2018-05-12 04:08:34 --> UTF-8 Support Enabled
DEBUG - 2018-05-12 04:08:34 --> UTF-8 Support Enabled
INFO - 2018-05-12 04:08:34 --> Utf8 Class Initialized
INFO - 2018-05-12 04:08:34 --> URI Class Initialized
INFO - 2018-05-12 04:08:34 --> Utf8 Class Initialized
INFO - 2018-05-12 04:08:34 --> Router Class Initialized
INFO - 2018-05-12 04:08:34 --> Utf8 Class Initialized
ERROR - 2018-05-12 04:08:34 --> 404 Page Not Found: /index
INFO - 2018-05-12 04:08:34 --> Hooks Class Initialized
INFO - 2018-05-12 04:08:34 --> URI Class Initialized
INFO - 2018-05-12 04:08:34 --> Router Class Initialized
INFO - 2018-05-12 04:08:34 --> Output Class Initialized
INFO - 2018-05-12 04:08:34 --> Security Class Initialized
DEBUG - 2018-05-12 04:08:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 04:08:34 --> Input Class Initialized
INFO - 2018-05-12 04:08:34 --> Language Class Initialized
ERROR - 2018-05-12 04:08:34 --> 404 Page Not Found: /index
INFO - 2018-05-12 04:08:34 --> Utf8 Class Initialized
INFO - 2018-05-12 04:08:34 --> Config Class Initialized
INFO - 2018-05-12 04:08:34 --> Hooks Class Initialized
DEBUG - 2018-05-12 04:08:34 --> UTF-8 Support Enabled
INFO - 2018-05-12 04:08:34 --> URI Class Initialized
DEBUG - 2018-05-12 04:08:34 --> UTF-8 Support Enabled
INFO - 2018-05-12 04:08:34 --> Output Class Initialized
INFO - 2018-05-12 04:08:34 --> Utf8 Class Initialized
INFO - 2018-05-12 04:08:34 --> Router Class Initialized
INFO - 2018-05-12 04:08:34 --> Utf8 Class Initialized
INFO - 2018-05-12 04:08:34 --> Security Class Initialized
INFO - 2018-05-12 04:08:34 --> URI Class Initialized
INFO - 2018-05-12 04:08:34 --> Output Class Initialized
INFO - 2018-05-12 04:08:34 --> URI Class Initialized
INFO - 2018-05-12 04:08:34 --> Router Class Initialized
INFO - 2018-05-12 04:08:34 --> Security Class Initialized
INFO - 2018-05-12 04:08:34 --> URI Class Initialized
DEBUG - 2018-05-12 04:08:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 04:08:34 --> Router Class Initialized
INFO - 2018-05-12 04:08:34 --> Router Class Initialized
INFO - 2018-05-12 04:08:34 --> Output Class Initialized
INFO - 2018-05-12 04:08:34 --> Output Class Initialized
DEBUG - 2018-05-12 04:08:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 04:08:34 --> Security Class Initialized
INFO - 2018-05-12 04:08:34 --> Input Class Initialized
INFO - 2018-05-12 04:08:34 --> Security Class Initialized
INFO - 2018-05-12 04:08:34 --> Output Class Initialized
INFO - 2018-05-12 04:08:34 --> Security Class Initialized
DEBUG - 2018-05-12 04:08:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 04:08:34 --> Input Class Initialized
INFO - 2018-05-12 04:08:34 --> Language Class Initialized
DEBUG - 2018-05-12 04:08:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-05-12 04:08:34 --> 404 Page Not Found: /index
INFO - 2018-05-12 04:08:34 --> Input Class Initialized
DEBUG - 2018-05-12 04:08:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 04:08:34 --> Input Class Initialized
INFO - 2018-05-12 04:08:34 --> Language Class Initialized
INFO - 2018-05-12 04:08:34 --> Language Class Initialized
INFO - 2018-05-12 04:08:34 --> Input Class Initialized
INFO - 2018-05-12 04:08:34 --> Language Class Initialized
ERROR - 2018-05-12 04:08:34 --> 404 Page Not Found: /index
INFO - 2018-05-12 04:08:34 --> Config Class Initialized
INFO - 2018-05-12 04:08:34 --> Hooks Class Initialized
INFO - 2018-05-12 04:08:34 --> Language Class Initialized
ERROR - 2018-05-12 04:08:34 --> 404 Page Not Found: /index
DEBUG - 2018-05-12 04:08:34 --> UTF-8 Support Enabled
ERROR - 2018-05-12 04:08:34 --> 404 Page Not Found: /index
ERROR - 2018-05-12 04:08:34 --> 404 Page Not Found: /index
INFO - 2018-05-12 04:08:34 --> Config Class Initialized
INFO - 2018-05-12 04:08:34 --> Utf8 Class Initialized
INFO - 2018-05-12 04:08:35 --> Config Class Initialized
INFO - 2018-05-12 04:08:35 --> Config Class Initialized
INFO - 2018-05-12 04:08:35 --> Hooks Class Initialized
INFO - 2018-05-12 04:08:35 --> Config Class Initialized
INFO - 2018-05-12 04:08:35 --> Hooks Class Initialized
INFO - 2018-05-12 04:08:35 --> URI Class Initialized
DEBUG - 2018-05-12 04:08:35 --> UTF-8 Support Enabled
INFO - 2018-05-12 04:08:35 --> Utf8 Class Initialized
DEBUG - 2018-05-12 04:08:35 --> UTF-8 Support Enabled
INFO - 2018-05-12 04:08:35 --> Utf8 Class Initialized
INFO - 2018-05-12 04:08:35 --> URI Class Initialized
INFO - 2018-05-12 04:08:35 --> Hooks Class Initialized
INFO - 2018-05-12 04:08:35 --> Hooks Class Initialized
INFO - 2018-05-12 04:08:35 --> Router Class Initialized
INFO - 2018-05-12 04:08:35 --> Output Class Initialized
DEBUG - 2018-05-12 04:08:35 --> UTF-8 Support Enabled
DEBUG - 2018-05-12 04:08:35 --> UTF-8 Support Enabled
INFO - 2018-05-12 04:08:35 --> URI Class Initialized
INFO - 2018-05-12 04:08:35 --> Router Class Initialized
INFO - 2018-05-12 04:08:35 --> Output Class Initialized
INFO - 2018-05-12 04:08:35 --> Utf8 Class Initialized
INFO - 2018-05-12 04:08:35 --> Utf8 Class Initialized
INFO - 2018-05-12 04:08:35 --> Security Class Initialized
INFO - 2018-05-12 04:08:35 --> Router Class Initialized
INFO - 2018-05-12 04:08:35 --> Output Class Initialized
INFO - 2018-05-12 04:08:35 --> URI Class Initialized
INFO - 2018-05-12 04:08:35 --> Security Class Initialized
DEBUG - 2018-05-12 04:08:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 04:08:35 --> URI Class Initialized
INFO - 2018-05-12 04:08:35 --> Security Class Initialized
INFO - 2018-05-12 04:08:35 --> Router Class Initialized
INFO - 2018-05-12 04:08:35 --> Input Class Initialized
DEBUG - 2018-05-12 04:08:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-12 04:08:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 04:08:35 --> Router Class Initialized
INFO - 2018-05-12 04:08:35 --> Language Class Initialized
INFO - 2018-05-12 04:08:35 --> Output Class Initialized
INFO - 2018-05-12 04:08:35 --> Input Class Initialized
INFO - 2018-05-12 04:08:35 --> Input Class Initialized
INFO - 2018-05-12 04:08:35 --> Output Class Initialized
ERROR - 2018-05-12 04:08:35 --> 404 Page Not Found: /index
INFO - 2018-05-12 04:08:35 --> Security Class Initialized
INFO - 2018-05-12 04:08:35 --> Language Class Initialized
INFO - 2018-05-12 04:08:35 --> Language Class Initialized
DEBUG - 2018-05-12 04:08:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 04:08:35 --> Config Class Initialized
INFO - 2018-05-12 04:08:35 --> Hooks Class Initialized
INFO - 2018-05-12 04:08:35 --> Input Class Initialized
INFO - 2018-05-12 04:08:35 --> Config Class Initialized
ERROR - 2018-05-12 04:08:35 --> 404 Page Not Found: /index
ERROR - 2018-05-12 04:08:35 --> 404 Page Not Found: /index
INFO - 2018-05-12 04:08:35 --> Security Class Initialized
INFO - 2018-05-12 04:08:35 --> Hooks Class Initialized
DEBUG - 2018-05-12 04:08:35 --> UTF-8 Support Enabled
INFO - 2018-05-12 04:08:35 --> Config Class Initialized
INFO - 2018-05-12 04:08:35 --> Language Class Initialized
DEBUG - 2018-05-12 04:08:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 04:08:35 --> Config Class Initialized
INFO - 2018-05-12 04:08:35 --> Hooks Class Initialized
DEBUG - 2018-05-12 04:08:35 --> UTF-8 Support Enabled
INFO - 2018-05-12 04:08:35 --> Utf8 Class Initialized
INFO - 2018-05-12 04:08:35 --> Utf8 Class Initialized
DEBUG - 2018-05-12 04:08:35 --> UTF-8 Support Enabled
INFO - 2018-05-12 04:08:35 --> URI Class Initialized
ERROR - 2018-05-12 04:08:35 --> 404 Page Not Found: /index
INFO - 2018-05-12 04:08:35 --> Input Class Initialized
INFO - 2018-05-12 04:08:35 --> Hooks Class Initialized
INFO - 2018-05-12 04:08:35 --> Utf8 Class Initialized
INFO - 2018-05-12 04:08:35 --> URI Class Initialized
INFO - 2018-05-12 04:08:35 --> Language Class Initialized
INFO - 2018-05-12 04:08:35 --> Router Class Initialized
DEBUG - 2018-05-12 04:08:35 --> UTF-8 Support Enabled
INFO - 2018-05-12 04:08:35 --> URI Class Initialized
INFO - 2018-05-12 04:08:35 --> Utf8 Class Initialized
INFO - 2018-05-12 04:08:35 --> Router Class Initialized
INFO - 2018-05-12 04:08:35 --> Output Class Initialized
ERROR - 2018-05-12 04:08:35 --> 404 Page Not Found: /index
INFO - 2018-05-12 04:08:35 --> Router Class Initialized
INFO - 2018-05-12 04:08:35 --> Output Class Initialized
INFO - 2018-05-12 04:08:35 --> Security Class Initialized
INFO - 2018-05-12 04:08:35 --> Output Class Initialized
INFO - 2018-05-12 04:08:35 --> URI Class Initialized
DEBUG - 2018-05-12 04:08:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 04:08:35 --> Security Class Initialized
INFO - 2018-05-12 04:08:35 --> Router Class Initialized
INFO - 2018-05-12 04:08:35 --> Security Class Initialized
INFO - 2018-05-12 04:08:35 --> Input Class Initialized
DEBUG - 2018-05-12 04:08:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 04:08:35 --> Output Class Initialized
DEBUG - 2018-05-12 04:08:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 04:08:35 --> Input Class Initialized
INFO - 2018-05-12 04:08:35 --> Security Class Initialized
INFO - 2018-05-12 04:08:35 --> Input Class Initialized
INFO - 2018-05-12 04:08:35 --> Language Class Initialized
INFO - 2018-05-12 04:08:35 --> Language Class Initialized
ERROR - 2018-05-12 04:08:35 --> 404 Page Not Found: /index
ERROR - 2018-05-12 04:08:35 --> 404 Page Not Found: /index
INFO - 2018-05-12 04:08:35 --> Language Class Initialized
DEBUG - 2018-05-12 04:08:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-05-12 04:08:35 --> 404 Page Not Found: /index
INFO - 2018-05-12 04:08:35 --> Input Class Initialized
INFO - 2018-05-12 04:08:35 --> Language Class Initialized
ERROR - 2018-05-12 04:08:35 --> 404 Page Not Found: /index
INFO - 2018-05-12 04:08:40 --> Config Class Initialized
INFO - 2018-05-12 04:08:40 --> Hooks Class Initialized
DEBUG - 2018-05-12 04:08:40 --> UTF-8 Support Enabled
INFO - 2018-05-12 04:08:40 --> Utf8 Class Initialized
INFO - 2018-05-12 04:08:40 --> URI Class Initialized
INFO - 2018-05-12 04:08:40 --> Router Class Initialized
INFO - 2018-05-12 04:08:40 --> Output Class Initialized
INFO - 2018-05-12 04:08:40 --> Security Class Initialized
DEBUG - 2018-05-12 04:08:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 04:08:40 --> Input Class Initialized
INFO - 2018-05-12 04:08:40 --> Language Class Initialized
INFO - 2018-05-12 04:08:40 --> Language Class Initialized
INFO - 2018-05-12 04:08:40 --> Config Class Initialized
INFO - 2018-05-12 04:08:40 --> Loader Class Initialized
DEBUG - 2018-05-12 04:08:40 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-12 04:08:40 --> Helper loaded: url_helper
INFO - 2018-05-12 04:08:40 --> Helper loaded: form_helper
INFO - 2018-05-12 04:08:40 --> Helper loaded: date_helper
INFO - 2018-05-12 04:08:40 --> Helper loaded: util_helper
INFO - 2018-05-12 04:08:40 --> Helper loaded: text_helper
INFO - 2018-05-12 04:08:40 --> Helper loaded: string_helper
INFO - 2018-05-12 04:08:40 --> Database Driver Class Initialized
DEBUG - 2018-05-12 04:08:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-12 04:08:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-12 04:08:40 --> Email Class Initialized
INFO - 2018-05-12 04:08:40 --> Controller Class Initialized
DEBUG - 2018-05-12 04:08:40 --> Admin MX_Controller Initialized
INFO - 2018-05-12 04:08:40 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-12 04:08:40 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-12 04:08:40 --> Login MX_Controller Initialized
DEBUG - 2018-05-12 04:08:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-12 04:08:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-12 04:08:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-05-12 04:08:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-05-12 04:08:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-05-12 04:08:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-05-12 04:08:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-05-12 04:08:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/dashboard.php
INFO - 2018-05-12 04:08:40 --> Final output sent to browser
DEBUG - 2018-05-12 04:08:40 --> Total execution time: 0.6786
INFO - 2018-05-12 04:08:41 --> Config Class Initialized
INFO - 2018-05-12 04:08:41 --> Hooks Class Initialized
DEBUG - 2018-05-12 04:08:41 --> UTF-8 Support Enabled
INFO - 2018-05-12 04:08:41 --> Utf8 Class Initialized
INFO - 2018-05-12 04:08:41 --> URI Class Initialized
INFO - 2018-05-12 04:08:41 --> Router Class Initialized
INFO - 2018-05-12 04:08:41 --> Output Class Initialized
INFO - 2018-05-12 04:08:41 --> Security Class Initialized
INFO - 2018-05-12 04:08:41 --> Config Class Initialized
DEBUG - 2018-05-12 04:08:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 04:08:41 --> Hooks Class Initialized
INFO - 2018-05-12 04:08:41 --> Input Class Initialized
DEBUG - 2018-05-12 04:08:41 --> UTF-8 Support Enabled
INFO - 2018-05-12 04:08:41 --> Utf8 Class Initialized
INFO - 2018-05-12 04:08:41 --> Language Class Initialized
INFO - 2018-05-12 04:08:41 --> URI Class Initialized
ERROR - 2018-05-12 04:08:41 --> 404 Page Not Found: /index
INFO - 2018-05-12 04:08:41 --> Router Class Initialized
INFO - 2018-05-12 04:08:41 --> Output Class Initialized
INFO - 2018-05-12 04:08:41 --> Security Class Initialized
DEBUG - 2018-05-12 04:08:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 04:08:41 --> Input Class Initialized
INFO - 2018-05-12 04:08:41 --> Language Class Initialized
ERROR - 2018-05-12 04:08:41 --> 404 Page Not Found: /index
INFO - 2018-05-12 04:08:44 --> Config Class Initialized
INFO - 2018-05-12 04:08:44 --> Hooks Class Initialized
DEBUG - 2018-05-12 04:08:44 --> UTF-8 Support Enabled
INFO - 2018-05-12 04:08:44 --> Utf8 Class Initialized
INFO - 2018-05-12 04:08:44 --> URI Class Initialized
DEBUG - 2018-05-12 04:08:44 --> No URI present. Default controller set.
INFO - 2018-05-12 04:08:44 --> Router Class Initialized
INFO - 2018-05-12 04:08:44 --> Output Class Initialized
INFO - 2018-05-12 04:08:44 --> Security Class Initialized
DEBUG - 2018-05-12 04:08:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 04:08:44 --> Input Class Initialized
INFO - 2018-05-12 04:08:44 --> Language Class Initialized
INFO - 2018-05-12 04:08:44 --> Language Class Initialized
INFO - 2018-05-12 04:08:44 --> Config Class Initialized
INFO - 2018-05-12 04:08:45 --> Loader Class Initialized
DEBUG - 2018-05-12 04:08:45 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-12 04:08:45 --> Helper loaded: url_helper
INFO - 2018-05-12 04:08:45 --> Helper loaded: form_helper
INFO - 2018-05-12 04:08:45 --> Helper loaded: date_helper
INFO - 2018-05-12 04:08:45 --> Helper loaded: util_helper
INFO - 2018-05-12 04:08:45 --> Helper loaded: text_helper
INFO - 2018-05-12 04:08:45 --> Helper loaded: string_helper
INFO - 2018-05-12 04:08:45 --> Database Driver Class Initialized
DEBUG - 2018-05-12 04:08:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-12 04:08:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-12 04:08:45 --> Email Class Initialized
INFO - 2018-05-12 04:08:45 --> Controller Class Initialized
DEBUG - 2018-05-12 04:08:45 --> Home MX_Controller Initialized
DEBUG - 2018-05-12 04:08:45 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-12 04:08:45 --> Login MX_Controller Initialized
INFO - 2018-05-12 04:08:45 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-12 04:08:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-12 04:08:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-12 04:08:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-05-12 04:08:45 --> Final output sent to browser
INFO - 2018-05-12 04:08:45 --> Config Class Initialized
DEBUG - 2018-05-12 04:08:45 --> Total execution time: 0.9019
INFO - 2018-05-12 04:08:45 --> Hooks Class Initialized
DEBUG - 2018-05-12 04:08:45 --> UTF-8 Support Enabled
INFO - 2018-05-12 04:08:45 --> Utf8 Class Initialized
INFO - 2018-05-12 04:08:45 --> URI Class Initialized
INFO - 2018-05-12 04:08:45 --> Router Class Initialized
INFO - 2018-05-12 04:08:45 --> Config Class Initialized
INFO - 2018-05-12 04:08:45 --> Config Class Initialized
INFO - 2018-05-12 04:08:45 --> Config Class Initialized
INFO - 2018-05-12 04:08:45 --> Config Class Initialized
INFO - 2018-05-12 04:08:45 --> Config Class Initialized
INFO - 2018-05-12 04:08:45 --> Hooks Class Initialized
INFO - 2018-05-12 04:08:45 --> Hooks Class Initialized
INFO - 2018-05-12 04:08:45 --> Hooks Class Initialized
INFO - 2018-05-12 04:08:45 --> Output Class Initialized
INFO - 2018-05-12 04:08:45 --> Hooks Class Initialized
INFO - 2018-05-12 04:08:45 --> Hooks Class Initialized
DEBUG - 2018-05-12 04:08:45 --> UTF-8 Support Enabled
DEBUG - 2018-05-12 04:08:45 --> UTF-8 Support Enabled
DEBUG - 2018-05-12 04:08:45 --> UTF-8 Support Enabled
DEBUG - 2018-05-12 04:08:45 --> UTF-8 Support Enabled
INFO - 2018-05-12 04:08:45 --> Utf8 Class Initialized
DEBUG - 2018-05-12 04:08:45 --> UTF-8 Support Enabled
INFO - 2018-05-12 04:08:45 --> Security Class Initialized
INFO - 2018-05-12 04:08:45 --> Utf8 Class Initialized
INFO - 2018-05-12 04:08:45 --> Utf8 Class Initialized
DEBUG - 2018-05-12 04:08:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 04:08:45 --> URI Class Initialized
INFO - 2018-05-12 04:08:45 --> Utf8 Class Initialized
INFO - 2018-05-12 04:08:45 --> Utf8 Class Initialized
INFO - 2018-05-12 04:08:45 --> URI Class Initialized
INFO - 2018-05-12 04:08:45 --> Input Class Initialized
INFO - 2018-05-12 04:08:45 --> URI Class Initialized
INFO - 2018-05-12 04:08:45 --> Router Class Initialized
INFO - 2018-05-12 04:08:45 --> URI Class Initialized
INFO - 2018-05-12 04:08:45 --> URI Class Initialized
INFO - 2018-05-12 04:08:45 --> Router Class Initialized
INFO - 2018-05-12 04:08:45 --> Language Class Initialized
ERROR - 2018-05-12 04:08:46 --> 404 Page Not Found: /index
INFO - 2018-05-12 04:08:46 --> Output Class Initialized
INFO - 2018-05-12 04:08:46 --> Router Class Initialized
INFO - 2018-05-12 04:08:46 --> Router Class Initialized
INFO - 2018-05-12 04:08:46 --> Router Class Initialized
INFO - 2018-05-12 04:08:46 --> Output Class Initialized
INFO - 2018-05-12 04:08:46 --> Config Class Initialized
INFO - 2018-05-12 04:08:46 --> Output Class Initialized
INFO - 2018-05-12 04:08:46 --> Output Class Initialized
INFO - 2018-05-12 04:08:46 --> Hooks Class Initialized
INFO - 2018-05-12 04:08:46 --> Security Class Initialized
INFO - 2018-05-12 04:08:46 --> Output Class Initialized
INFO - 2018-05-12 04:08:46 --> Security Class Initialized
INFO - 2018-05-12 04:08:46 --> Security Class Initialized
DEBUG - 2018-05-12 04:08:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-12 04:08:46 --> UTF-8 Support Enabled
INFO - 2018-05-12 04:08:46 --> Security Class Initialized
DEBUG - 2018-05-12 04:08:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 04:08:46 --> Security Class Initialized
INFO - 2018-05-12 04:08:46 --> Utf8 Class Initialized
INFO - 2018-05-12 04:08:46 --> Input Class Initialized
DEBUG - 2018-05-12 04:08:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-12 04:08:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 04:08:46 --> Input Class Initialized
DEBUG - 2018-05-12 04:08:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 04:08:46 --> URI Class Initialized
INFO - 2018-05-12 04:08:46 --> Input Class Initialized
INFO - 2018-05-12 04:08:46 --> Language Class Initialized
INFO - 2018-05-12 04:08:46 --> Router Class Initialized
INFO - 2018-05-12 04:08:46 --> Language Class Initialized
INFO - 2018-05-12 04:08:46 --> Output Class Initialized
ERROR - 2018-05-12 04:08:46 --> 404 Page Not Found: /index
INFO - 2018-05-12 04:08:46 --> Input Class Initialized
INFO - 2018-05-12 04:08:46 --> Input Class Initialized
INFO - 2018-05-12 04:08:46 --> Language Class Initialized
INFO - 2018-05-12 04:08:46 --> Security Class Initialized
ERROR - 2018-05-12 04:08:46 --> 404 Page Not Found: /index
INFO - 2018-05-12 04:08:46 --> Config Class Initialized
INFO - 2018-05-12 04:08:46 --> Config Class Initialized
INFO - 2018-05-12 04:08:46 --> Hooks Class Initialized
INFO - 2018-05-12 04:08:46 --> Hooks Class Initialized
INFO - 2018-05-12 04:08:46 --> Language Class Initialized
INFO - 2018-05-12 04:08:46 --> Language Class Initialized
ERROR - 2018-05-12 04:08:46 --> 404 Page Not Found: /index
DEBUG - 2018-05-12 04:08:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 04:08:46 --> Input Class Initialized
DEBUG - 2018-05-12 04:08:46 --> UTF-8 Support Enabled
INFO - 2018-05-12 04:08:46 --> Config Class Initialized
DEBUG - 2018-05-12 04:08:46 --> UTF-8 Support Enabled
ERROR - 2018-05-12 04:08:46 --> 404 Page Not Found: /index
ERROR - 2018-05-12 04:08:46 --> 404 Page Not Found: /index
INFO - 2018-05-12 04:08:46 --> Language Class Initialized
INFO - 2018-05-12 04:08:46 --> Utf8 Class Initialized
INFO - 2018-05-12 04:08:46 --> Hooks Class Initialized
INFO - 2018-05-12 04:08:46 --> Utf8 Class Initialized
INFO - 2018-05-12 04:08:46 --> Config Class Initialized
INFO - 2018-05-12 04:08:46 --> Hooks Class Initialized
ERROR - 2018-05-12 04:08:46 --> 404 Page Not Found: /index
INFO - 2018-05-12 04:08:46 --> URI Class Initialized
DEBUG - 2018-05-12 04:08:46 --> UTF-8 Support Enabled
INFO - 2018-05-12 04:08:46 --> URI Class Initialized
DEBUG - 2018-05-12 04:08:46 --> UTF-8 Support Enabled
INFO - 2018-05-12 04:08:46 --> Router Class Initialized
INFO - 2018-05-12 04:08:46 --> Router Class Initialized
INFO - 2018-05-12 04:08:46 --> Config Class Initialized
INFO - 2018-05-12 04:08:46 --> Hooks Class Initialized
INFO - 2018-05-12 04:08:46 --> Utf8 Class Initialized
INFO - 2018-05-12 04:08:46 --> Output Class Initialized
INFO - 2018-05-12 04:08:46 --> Output Class Initialized
INFO - 2018-05-12 04:08:46 --> Utf8 Class Initialized
INFO - 2018-05-12 04:08:46 --> Config Class Initialized
INFO - 2018-05-12 04:08:46 --> Hooks Class Initialized
DEBUG - 2018-05-12 04:08:46 --> UTF-8 Support Enabled
INFO - 2018-05-12 04:08:46 --> Config Class Initialized
INFO - 2018-05-12 04:08:46 --> Config Class Initialized
INFO - 2018-05-12 04:08:46 --> Security Class Initialized
INFO - 2018-05-12 04:08:46 --> URI Class Initialized
INFO - 2018-05-12 04:08:46 --> Security Class Initialized
INFO - 2018-05-12 04:08:46 --> URI Class Initialized
DEBUG - 2018-05-12 04:08:46 --> UTF-8 Support Enabled
INFO - 2018-05-12 04:08:46 --> Config Class Initialized
INFO - 2018-05-12 04:08:46 --> Hooks Class Initialized
INFO - 2018-05-12 04:08:46 --> Utf8 Class Initialized
DEBUG - 2018-05-12 04:08:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 04:08:46 --> Hooks Class Initialized
INFO - 2018-05-12 04:08:46 --> Router Class Initialized
INFO - 2018-05-12 04:08:46 --> Router Class Initialized
DEBUG - 2018-05-12 04:08:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 04:08:46 --> Config Class Initialized
INFO - 2018-05-12 04:08:46 --> Utf8 Class Initialized
INFO - 2018-05-12 04:08:46 --> Hooks Class Initialized
INFO - 2018-05-12 04:08:46 --> Input Class Initialized
INFO - 2018-05-12 04:08:46 --> Output Class Initialized
INFO - 2018-05-12 04:08:46 --> Output Class Initialized
INFO - 2018-05-12 04:08:46 --> Input Class Initialized
INFO - 2018-05-12 04:08:46 --> URI Class Initialized
DEBUG - 2018-05-12 04:08:46 --> UTF-8 Support Enabled
INFO - 2018-05-12 04:08:46 --> Hooks Class Initialized
INFO - 2018-05-12 04:08:46 --> URI Class Initialized
DEBUG - 2018-05-12 04:08:46 --> UTF-8 Support Enabled
INFO - 2018-05-12 04:08:46 --> Language Class Initialized
INFO - 2018-05-12 04:08:46 --> Security Class Initialized
INFO - 2018-05-12 04:08:46 --> Security Class Initialized
INFO - 2018-05-12 04:08:46 --> Language Class Initialized
INFO - 2018-05-12 04:08:46 --> Utf8 Class Initialized
INFO - 2018-05-12 04:08:46 --> Router Class Initialized
INFO - 2018-05-12 04:08:46 --> Router Class Initialized
INFO - 2018-05-12 04:08:46 --> Utf8 Class Initialized
DEBUG - 2018-05-12 04:08:46 --> UTF-8 Support Enabled
DEBUG - 2018-05-12 04:08:46 --> UTF-8 Support Enabled
ERROR - 2018-05-12 04:08:46 --> 404 Page Not Found: /index
INFO - 2018-05-12 04:08:46 --> Output Class Initialized
INFO - 2018-05-12 04:08:46 --> URI Class Initialized
INFO - 2018-05-12 04:08:46 --> Output Class Initialized
ERROR - 2018-05-12 04:08:46 --> 404 Page Not Found: /index
DEBUG - 2018-05-12 04:08:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-12 04:08:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 04:08:46 --> Utf8 Class Initialized
INFO - 2018-05-12 04:08:46 --> Utf8 Class Initialized
INFO - 2018-05-12 04:08:46 --> URI Class Initialized
INFO - 2018-05-12 04:08:46 --> URI Class Initialized
INFO - 2018-05-12 04:08:46 --> URI Class Initialized
INFO - 2018-05-12 04:08:46 --> Security Class Initialized
INFO - 2018-05-12 04:08:46 --> Input Class Initialized
INFO - 2018-05-12 04:08:46 --> Input Class Initialized
INFO - 2018-05-12 04:08:46 --> Router Class Initialized
INFO - 2018-05-12 04:08:46 --> Security Class Initialized
INFO - 2018-05-12 04:08:46 --> Router Class Initialized
INFO - 2018-05-12 04:08:46 --> Router Class Initialized
INFO - 2018-05-12 04:08:46 --> Output Class Initialized
INFO - 2018-05-12 04:08:46 --> Output Class Initialized
INFO - 2018-05-12 04:08:46 --> Language Class Initialized
INFO - 2018-05-12 04:08:46 --> Language Class Initialized
DEBUG - 2018-05-12 04:08:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 04:08:46 --> Router Class Initialized
INFO - 2018-05-12 04:08:46 --> Output Class Initialized
INFO - 2018-05-12 04:08:46 --> Security Class Initialized
DEBUG - 2018-05-12 04:08:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 04:08:46 --> Security Class Initialized
INFO - 2018-05-12 04:08:46 --> Security Class Initialized
ERROR - 2018-05-12 04:08:46 --> 404 Page Not Found: /index
ERROR - 2018-05-12 04:08:46 --> 404 Page Not Found: /index
INFO - 2018-05-12 04:08:46 --> Input Class Initialized
INFO - 2018-05-12 04:08:46 --> Output Class Initialized
DEBUG - 2018-05-12 04:08:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 04:08:46 --> Input Class Initialized
INFO - 2018-05-12 04:08:46 --> Language Class Initialized
ERROR - 2018-05-12 04:08:46 --> 404 Page Not Found: /index
DEBUG - 2018-05-12 04:08:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-12 04:08:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 04:08:46 --> Language Class Initialized
INFO - 2018-05-12 04:08:46 --> Security Class Initialized
INFO - 2018-05-12 04:08:46 --> Input Class Initialized
INFO - 2018-05-12 04:08:46 --> Input Class Initialized
ERROR - 2018-05-12 04:08:46 --> 404 Page Not Found: /index
INFO - 2018-05-12 04:08:46 --> Language Class Initialized
INFO - 2018-05-12 04:08:46 --> Input Class Initialized
DEBUG - 2018-05-12 04:08:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 04:08:47 --> Language Class Initialized
ERROR - 2018-05-12 04:08:47 --> 404 Page Not Found: /index
ERROR - 2018-05-12 04:08:47 --> 404 Page Not Found: /index
INFO - 2018-05-12 04:08:47 --> Input Class Initialized
INFO - 2018-05-12 04:08:47 --> Language Class Initialized
INFO - 2018-05-12 04:08:47 --> Language Class Initialized
ERROR - 2018-05-12 04:08:47 --> 404 Page Not Found: /index
ERROR - 2018-05-12 04:08:47 --> 404 Page Not Found: /index
INFO - 2018-05-12 04:09:06 --> Config Class Initialized
INFO - 2018-05-12 04:09:06 --> Hooks Class Initialized
DEBUG - 2018-05-12 04:09:06 --> UTF-8 Support Enabled
INFO - 2018-05-12 04:09:06 --> Utf8 Class Initialized
INFO - 2018-05-12 04:09:06 --> URI Class Initialized
DEBUG - 2018-05-12 04:09:06 --> No URI present. Default controller set.
INFO - 2018-05-12 04:09:06 --> Router Class Initialized
INFO - 2018-05-12 04:09:06 --> Output Class Initialized
INFO - 2018-05-12 04:09:06 --> Security Class Initialized
DEBUG - 2018-05-12 04:09:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 04:09:06 --> Input Class Initialized
INFO - 2018-05-12 04:09:06 --> Language Class Initialized
INFO - 2018-05-12 04:09:06 --> Language Class Initialized
INFO - 2018-05-12 04:09:06 --> Config Class Initialized
INFO - 2018-05-12 04:09:06 --> Loader Class Initialized
DEBUG - 2018-05-12 04:09:06 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-12 04:09:06 --> Helper loaded: url_helper
INFO - 2018-05-12 04:09:06 --> Helper loaded: form_helper
INFO - 2018-05-12 04:09:06 --> Helper loaded: date_helper
INFO - 2018-05-12 04:09:06 --> Helper loaded: util_helper
INFO - 2018-05-12 04:09:06 --> Helper loaded: text_helper
INFO - 2018-05-12 04:09:06 --> Helper loaded: string_helper
INFO - 2018-05-12 04:09:06 --> Database Driver Class Initialized
DEBUG - 2018-05-12 04:09:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-12 04:09:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-12 04:09:06 --> Email Class Initialized
INFO - 2018-05-12 04:09:06 --> Controller Class Initialized
DEBUG - 2018-05-12 04:09:06 --> Home MX_Controller Initialized
DEBUG - 2018-05-12 04:09:07 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-12 04:09:07 --> Login MX_Controller Initialized
INFO - 2018-05-12 04:09:07 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-12 04:09:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-12 04:09:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-12 04:09:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-05-12 04:09:07 --> Final output sent to browser
DEBUG - 2018-05-12 04:09:07 --> Total execution time: 0.7126
INFO - 2018-05-12 04:09:07 --> Config Class Initialized
INFO - 2018-05-12 04:09:07 --> Hooks Class Initialized
DEBUG - 2018-05-12 04:09:07 --> UTF-8 Support Enabled
INFO - 2018-05-12 04:09:07 --> Utf8 Class Initialized
INFO - 2018-05-12 04:09:07 --> URI Class Initialized
INFO - 2018-05-12 04:09:07 --> Router Class Initialized
INFO - 2018-05-12 04:09:07 --> Output Class Initialized
INFO - 2018-05-12 04:09:07 --> Config Class Initialized
INFO - 2018-05-12 04:09:07 --> Config Class Initialized
INFO - 2018-05-12 04:09:07 --> Hooks Class Initialized
INFO - 2018-05-12 04:09:07 --> Hooks Class Initialized
INFO - 2018-05-12 04:09:07 --> Security Class Initialized
INFO - 2018-05-12 04:09:07 --> Config Class Initialized
INFO - 2018-05-12 04:09:07 --> Config Class Initialized
DEBUG - 2018-05-12 04:09:07 --> UTF-8 Support Enabled
DEBUG - 2018-05-12 04:09:07 --> UTF-8 Support Enabled
INFO - 2018-05-12 04:09:07 --> Config Class Initialized
INFO - 2018-05-12 04:09:07 --> Hooks Class Initialized
DEBUG - 2018-05-12 04:09:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 04:09:07 --> Hooks Class Initialized
INFO - 2018-05-12 04:09:07 --> Utf8 Class Initialized
DEBUG - 2018-05-12 04:09:07 --> UTF-8 Support Enabled
DEBUG - 2018-05-12 04:09:07 --> UTF-8 Support Enabled
INFO - 2018-05-12 04:09:07 --> Input Class Initialized
INFO - 2018-05-12 04:09:07 --> Hooks Class Initialized
INFO - 2018-05-12 04:09:07 --> Utf8 Class Initialized
INFO - 2018-05-12 04:09:07 --> Config Class Initialized
INFO - 2018-05-12 04:09:07 --> Config Class Initialized
INFO - 2018-05-12 04:09:07 --> Hooks Class Initialized
INFO - 2018-05-12 04:09:07 --> Hooks Class Initialized
INFO - 2018-05-12 04:09:07 --> URI Class Initialized
INFO - 2018-05-12 04:09:07 --> URI Class Initialized
DEBUG - 2018-05-12 04:09:07 --> UTF-8 Support Enabled
INFO - 2018-05-12 04:09:07 --> Utf8 Class Initialized
INFO - 2018-05-12 04:09:07 --> Utf8 Class Initialized
INFO - 2018-05-12 04:09:07 --> Language Class Initialized
INFO - 2018-05-12 04:09:07 --> Config Class Initialized
INFO - 2018-05-12 04:09:07 --> Hooks Class Initialized
DEBUG - 2018-05-12 04:09:07 --> UTF-8 Support Enabled
INFO - 2018-05-12 04:09:07 --> Config Class Initialized
ERROR - 2018-05-12 04:09:07 --> 404 Page Not Found: /index
INFO - 2018-05-12 04:09:07 --> URI Class Initialized
INFO - 2018-05-12 04:09:07 --> Utf8 Class Initialized
INFO - 2018-05-12 04:09:07 --> Router Class Initialized
INFO - 2018-05-12 04:09:07 --> Router Class Initialized
INFO - 2018-05-12 04:09:07 --> Output Class Initialized
DEBUG - 2018-05-12 04:09:07 --> UTF-8 Support Enabled
INFO - 2018-05-12 04:09:07 --> Output Class Initialized
INFO - 2018-05-12 04:09:07 --> URI Class Initialized
INFO - 2018-05-12 04:09:07 --> URI Class Initialized
INFO - 2018-05-12 04:09:07 --> Utf8 Class Initialized
DEBUG - 2018-05-12 04:09:07 --> UTF-8 Support Enabled
INFO - 2018-05-12 04:09:07 --> Hooks Class Initialized
INFO - 2018-05-12 04:09:07 --> Router Class Initialized
INFO - 2018-05-12 04:09:07 --> Utf8 Class Initialized
INFO - 2018-05-12 04:09:07 --> Security Class Initialized
INFO - 2018-05-12 04:09:07 --> Router Class Initialized
INFO - 2018-05-12 04:09:07 --> Router Class Initialized
INFO - 2018-05-12 04:09:07 --> Utf8 Class Initialized
INFO - 2018-05-12 04:09:07 --> URI Class Initialized
INFO - 2018-05-12 04:09:07 --> Output Class Initialized
DEBUG - 2018-05-12 04:09:07 --> UTF-8 Support Enabled
INFO - 2018-05-12 04:09:07 --> Security Class Initialized
INFO - 2018-05-12 04:09:07 --> URI Class Initialized
INFO - 2018-05-12 04:09:07 --> Router Class Initialized
DEBUG - 2018-05-12 04:09:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 04:09:07 --> Output Class Initialized
INFO - 2018-05-12 04:09:07 --> Utf8 Class Initialized
DEBUG - 2018-05-12 04:09:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 04:09:07 --> Security Class Initialized
INFO - 2018-05-12 04:09:07 --> URI Class Initialized
INFO - 2018-05-12 04:09:07 --> Router Class Initialized
INFO - 2018-05-12 04:09:07 --> Input Class Initialized
INFO - 2018-05-12 04:09:07 --> URI Class Initialized
INFO - 2018-05-12 04:09:07 --> Output Class Initialized
INFO - 2018-05-12 04:09:07 --> Output Class Initialized
INFO - 2018-05-12 04:09:07 --> Input Class Initialized
INFO - 2018-05-12 04:09:07 --> Security Class Initialized
DEBUG - 2018-05-12 04:09:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 04:09:07 --> Output Class Initialized
INFO - 2018-05-12 04:09:07 --> Router Class Initialized
INFO - 2018-05-12 04:09:07 --> Language Class Initialized
INFO - 2018-05-12 04:09:07 --> Output Class Initialized
INFO - 2018-05-12 04:09:07 --> Input Class Initialized
INFO - 2018-05-12 04:09:07 --> Security Class Initialized
DEBUG - 2018-05-12 04:09:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 04:09:07 --> Language Class Initialized
INFO - 2018-05-12 04:09:07 --> Security Class Initialized
INFO - 2018-05-12 04:09:07 --> Security Class Initialized
INFO - 2018-05-12 04:09:07 --> Router Class Initialized
ERROR - 2018-05-12 04:09:07 --> 404 Page Not Found: /index
INFO - 2018-05-12 04:09:07 --> Language Class Initialized
INFO - 2018-05-12 04:09:07 --> Input Class Initialized
DEBUG - 2018-05-12 04:09:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-05-12 04:09:07 --> 404 Page Not Found: /index
DEBUG - 2018-05-12 04:09:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-12 04:09:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 04:09:07 --> Output Class Initialized
INFO - 2018-05-12 04:09:07 --> Security Class Initialized
ERROR - 2018-05-12 04:09:07 --> 404 Page Not Found: /index
INFO - 2018-05-12 04:09:07 --> Input Class Initialized
INFO - 2018-05-12 04:09:07 --> Input Class Initialized
INFO - 2018-05-12 04:09:07 --> Language Class Initialized
DEBUG - 2018-05-12 04:09:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 04:09:07 --> Input Class Initialized
INFO - 2018-05-12 04:09:07 --> Security Class Initialized
INFO - 2018-05-12 04:09:07 --> Language Class Initialized
INFO - 2018-05-12 04:09:07 --> Language Class Initialized
ERROR - 2018-05-12 04:09:07 --> 404 Page Not Found: /index
INFO - 2018-05-12 04:09:07 --> Input Class Initialized
INFO - 2018-05-12 04:09:07 --> Language Class Initialized
DEBUG - 2018-05-12 04:09:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-05-12 04:09:07 --> 404 Page Not Found: /index
ERROR - 2018-05-12 04:09:07 --> 404 Page Not Found: /index
INFO - 2018-05-12 04:09:07 --> Input Class Initialized
ERROR - 2018-05-12 04:09:07 --> 404 Page Not Found: /index
INFO - 2018-05-12 04:09:07 --> Language Class Initialized
ERROR - 2018-05-12 04:09:07 --> 404 Page Not Found: /index
INFO - 2018-05-12 04:09:07 --> Language Class Initialized
ERROR - 2018-05-12 04:09:07 --> 404 Page Not Found: /index
INFO - 2018-05-12 05:58:18 --> Config Class Initialized
INFO - 2018-05-12 05:58:18 --> Hooks Class Initialized
DEBUG - 2018-05-12 05:58:18 --> UTF-8 Support Enabled
INFO - 2018-05-12 05:58:18 --> Utf8 Class Initialized
INFO - 2018-05-12 05:58:18 --> URI Class Initialized
INFO - 2018-05-12 05:58:18 --> Router Class Initialized
INFO - 2018-05-12 05:58:18 --> Output Class Initialized
INFO - 2018-05-12 05:58:18 --> Security Class Initialized
DEBUG - 2018-05-12 05:58:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 05:58:18 --> Input Class Initialized
INFO - 2018-05-12 05:58:18 --> Language Class Initialized
INFO - 2018-05-12 05:58:18 --> Language Class Initialized
INFO - 2018-05-12 05:58:18 --> Config Class Initialized
INFO - 2018-05-12 05:58:18 --> Loader Class Initialized
DEBUG - 2018-05-12 05:58:18 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-12 05:58:18 --> Helper loaded: url_helper
INFO - 2018-05-12 05:58:18 --> Helper loaded: form_helper
INFO - 2018-05-12 05:58:18 --> Helper loaded: date_helper
INFO - 2018-05-12 05:58:18 --> Helper loaded: util_helper
INFO - 2018-05-12 05:58:18 --> Helper loaded: text_helper
INFO - 2018-05-12 05:58:19 --> Helper loaded: string_helper
INFO - 2018-05-12 05:58:19 --> Database Driver Class Initialized
DEBUG - 2018-05-12 05:58:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-12 05:58:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-12 05:58:19 --> Email Class Initialized
INFO - 2018-05-12 05:58:19 --> Controller Class Initialized
DEBUG - 2018-05-12 05:58:19 --> Admin MX_Controller Initialized
INFO - 2018-05-12 05:58:19 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-12 05:58:19 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-12 05:58:19 --> Login MX_Controller Initialized
DEBUG - 2018-05-12 05:58:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-12 05:58:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-12 05:58:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-05-12 05:58:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-05-12 05:58:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-05-12 05:58:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-05-12 05:58:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-05-12 05:58:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/dashboard.php
INFO - 2018-05-12 05:58:19 --> Final output sent to browser
DEBUG - 2018-05-12 05:58:19 --> Total execution time: 0.8094
INFO - 2018-05-12 05:58:20 --> Config Class Initialized
INFO - 2018-05-12 05:58:20 --> Hooks Class Initialized
DEBUG - 2018-05-12 05:58:20 --> UTF-8 Support Enabled
INFO - 2018-05-12 05:58:20 --> Utf8 Class Initialized
INFO - 2018-05-12 05:58:20 --> URI Class Initialized
INFO - 2018-05-12 05:58:20 --> Router Class Initialized
INFO - 2018-05-12 05:58:20 --> Output Class Initialized
INFO - 2018-05-12 05:58:20 --> Security Class Initialized
DEBUG - 2018-05-12 05:58:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 05:58:20 --> Input Class Initialized
INFO - 2018-05-12 05:58:20 --> Language Class Initialized
INFO - 2018-05-12 05:58:20 --> Language Class Initialized
INFO - 2018-05-12 05:58:20 --> Config Class Initialized
INFO - 2018-05-12 05:58:20 --> Loader Class Initialized
DEBUG - 2018-05-12 05:58:20 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-12 05:58:20 --> Helper loaded: url_helper
INFO - 2018-05-12 05:58:20 --> Helper loaded: form_helper
INFO - 2018-05-12 05:58:20 --> Helper loaded: date_helper
INFO - 2018-05-12 05:58:20 --> Helper loaded: util_helper
INFO - 2018-05-12 05:58:20 --> Helper loaded: text_helper
INFO - 2018-05-12 05:58:20 --> Helper loaded: string_helper
INFO - 2018-05-12 05:58:20 --> Database Driver Class Initialized
DEBUG - 2018-05-12 05:58:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-12 05:58:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-12 05:58:20 --> Email Class Initialized
INFO - 2018-05-12 05:58:20 --> Controller Class Initialized
DEBUG - 2018-05-12 05:58:20 --> Home MX_Controller Initialized
DEBUG - 2018-05-12 05:58:20 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-12 05:58:20 --> Login MX_Controller Initialized
INFO - 2018-05-12 05:58:20 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-12 05:58:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-12 05:58:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-12 05:58:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-05-12 05:58:20 --> Final output sent to browser
DEBUG - 2018-05-12 05:58:20 --> Total execution time: 0.7124
INFO - 2018-05-12 05:58:20 --> Config Class Initialized
INFO - 2018-05-12 05:58:20 --> Hooks Class Initialized
DEBUG - 2018-05-12 05:58:20 --> UTF-8 Support Enabled
INFO - 2018-05-12 05:58:21 --> Utf8 Class Initialized
INFO - 2018-05-12 05:58:21 --> URI Class Initialized
INFO - 2018-05-12 05:58:21 --> Router Class Initialized
INFO - 2018-05-12 05:58:21 --> Output Class Initialized
INFO - 2018-05-12 05:58:21 --> Security Class Initialized
DEBUG - 2018-05-12 05:58:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 05:58:21 --> Input Class Initialized
INFO - 2018-05-12 05:58:21 --> Language Class Initialized
ERROR - 2018-05-12 05:58:21 --> 404 Page Not Found: /index
INFO - 2018-05-12 05:58:21 --> Config Class Initialized
INFO - 2018-05-12 05:58:21 --> Config Class Initialized
INFO - 2018-05-12 05:58:21 --> Config Class Initialized
INFO - 2018-05-12 05:58:21 --> Config Class Initialized
INFO - 2018-05-12 05:58:21 --> Config Class Initialized
INFO - 2018-05-12 05:58:21 --> Config Class Initialized
INFO - 2018-05-12 05:58:21 --> Hooks Class Initialized
INFO - 2018-05-12 05:58:21 --> Hooks Class Initialized
INFO - 2018-05-12 05:58:21 --> Hooks Class Initialized
INFO - 2018-05-12 05:58:21 --> Hooks Class Initialized
INFO - 2018-05-12 05:58:21 --> Hooks Class Initialized
INFO - 2018-05-12 05:58:21 --> Hooks Class Initialized
DEBUG - 2018-05-12 05:58:21 --> UTF-8 Support Enabled
INFO - 2018-05-12 05:58:21 --> Utf8 Class Initialized
INFO - 2018-05-12 05:58:21 --> URI Class Initialized
INFO - 2018-05-12 05:58:21 --> Router Class Initialized
INFO - 2018-05-12 05:58:21 --> Output Class Initialized
INFO - 2018-05-12 05:58:21 --> Security Class Initialized
DEBUG - 2018-05-12 05:58:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 05:58:21 --> Input Class Initialized
INFO - 2018-05-12 05:58:21 --> Language Class Initialized
ERROR - 2018-05-12 05:58:21 --> 404 Page Not Found: /index
DEBUG - 2018-05-12 05:58:21 --> UTF-8 Support Enabled
DEBUG - 2018-05-12 05:58:21 --> UTF-8 Support Enabled
DEBUG - 2018-05-12 05:58:21 --> UTF-8 Support Enabled
DEBUG - 2018-05-12 05:58:21 --> UTF-8 Support Enabled
DEBUG - 2018-05-12 05:58:21 --> UTF-8 Support Enabled
INFO - 2018-05-12 05:58:21 --> Utf8 Class Initialized
INFO - 2018-05-12 05:58:22 --> URI Class Initialized
INFO - 2018-05-12 05:58:22 --> Router Class Initialized
INFO - 2018-05-12 05:58:22 --> Output Class Initialized
INFO - 2018-05-12 05:58:22 --> Security Class Initialized
DEBUG - 2018-05-12 05:58:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 05:58:22 --> Input Class Initialized
INFO - 2018-05-12 05:58:22 --> Language Class Initialized
ERROR - 2018-05-12 05:58:22 --> 404 Page Not Found: /index
INFO - 2018-05-12 05:58:22 --> Utf8 Class Initialized
INFO - 2018-05-12 05:58:22 --> Utf8 Class Initialized
INFO - 2018-05-12 05:58:22 --> Config Class Initialized
INFO - 2018-05-12 05:58:22 --> Utf8 Class Initialized
INFO - 2018-05-12 05:58:22 --> Utf8 Class Initialized
INFO - 2018-05-12 05:58:22 --> URI Class Initialized
INFO - 2018-05-12 05:58:22 --> URI Class Initialized
INFO - 2018-05-12 05:58:22 --> Hooks Class Initialized
INFO - 2018-05-12 05:58:22 --> URI Class Initialized
INFO - 2018-05-12 05:58:22 --> URI Class Initialized
INFO - 2018-05-12 05:58:22 --> Router Class Initialized
INFO - 2018-05-12 05:58:22 --> Router Class Initialized
INFO - 2018-05-12 05:58:22 --> Router Class Initialized
INFO - 2018-05-12 05:58:22 --> Router Class Initialized
DEBUG - 2018-05-12 05:58:22 --> UTF-8 Support Enabled
INFO - 2018-05-12 05:58:22 --> Output Class Initialized
INFO - 2018-05-12 05:58:22 --> Security Class Initialized
DEBUG - 2018-05-12 05:58:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 05:58:22 --> Input Class Initialized
INFO - 2018-05-12 05:58:22 --> Language Class Initialized
ERROR - 2018-05-12 05:58:22 --> 404 Page Not Found: /index
INFO - 2018-05-12 05:58:22 --> Config Class Initialized
INFO - 2018-05-12 05:58:22 --> Hooks Class Initialized
DEBUG - 2018-05-12 05:58:22 --> UTF-8 Support Enabled
INFO - 2018-05-12 05:58:22 --> Utf8 Class Initialized
INFO - 2018-05-12 05:58:22 --> Utf8 Class Initialized
INFO - 2018-05-12 05:58:22 --> Output Class Initialized
INFO - 2018-05-12 05:58:22 --> Output Class Initialized
INFO - 2018-05-12 05:58:22 --> Output Class Initialized
INFO - 2018-05-12 05:58:22 --> URI Class Initialized
INFO - 2018-05-12 05:58:22 --> URI Class Initialized
INFO - 2018-05-12 05:58:22 --> Security Class Initialized
INFO - 2018-05-12 05:58:22 --> Security Class Initialized
INFO - 2018-05-12 05:58:22 --> Security Class Initialized
DEBUG - 2018-05-12 05:58:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 05:58:22 --> Router Class Initialized
DEBUG - 2018-05-12 05:58:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 05:58:22 --> Router Class Initialized
DEBUG - 2018-05-12 05:58:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 05:58:22 --> Input Class Initialized
INFO - 2018-05-12 05:58:22 --> Language Class Initialized
ERROR - 2018-05-12 05:58:22 --> 404 Page Not Found: /index
INFO - 2018-05-12 05:58:22 --> Output Class Initialized
INFO - 2018-05-12 05:58:22 --> Output Class Initialized
INFO - 2018-05-12 05:58:22 --> Config Class Initialized
INFO - 2018-05-12 05:58:22 --> Input Class Initialized
INFO - 2018-05-12 05:58:22 --> Input Class Initialized
INFO - 2018-05-12 05:58:22 --> Security Class Initialized
DEBUG - 2018-05-12 05:58:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 05:58:22 --> Security Class Initialized
INFO - 2018-05-12 05:58:22 --> Hooks Class Initialized
INFO - 2018-05-12 05:58:22 --> Language Class Initialized
INFO - 2018-05-12 05:58:22 --> Language Class Initialized
INFO - 2018-05-12 05:58:22 --> Input Class Initialized
INFO - 2018-05-12 05:58:22 --> Language Class Initialized
ERROR - 2018-05-12 05:58:22 --> 404 Page Not Found: /index
INFO - 2018-05-12 05:58:22 --> Config Class Initialized
INFO - 2018-05-12 05:58:22 --> Hooks Class Initialized
DEBUG - 2018-05-12 05:58:22 --> UTF-8 Support Enabled
INFO - 2018-05-12 05:58:22 --> Utf8 Class Initialized
INFO - 2018-05-12 05:58:22 --> URI Class Initialized
DEBUG - 2018-05-12 05:58:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-05-12 05:58:22 --> 404 Page Not Found: /index
ERROR - 2018-05-12 05:58:22 --> 404 Page Not Found: /index
DEBUG - 2018-05-12 05:58:22 --> UTF-8 Support Enabled
INFO - 2018-05-12 05:58:22 --> Input Class Initialized
INFO - 2018-05-12 05:58:22 --> Router Class Initialized
INFO - 2018-05-12 05:58:22 --> Config Class Initialized
INFO - 2018-05-12 05:58:22 --> Utf8 Class Initialized
INFO - 2018-05-12 05:58:23 --> Config Class Initialized
INFO - 2018-05-12 05:58:23 --> Hooks Class Initialized
INFO - 2018-05-12 05:58:23 --> URI Class Initialized
INFO - 2018-05-12 05:58:23 --> Output Class Initialized
INFO - 2018-05-12 05:58:23 --> Language Class Initialized
INFO - 2018-05-12 05:58:23 --> Hooks Class Initialized
INFO - 2018-05-12 05:58:23 --> Security Class Initialized
DEBUG - 2018-05-12 05:58:23 --> UTF-8 Support Enabled
ERROR - 2018-05-12 05:58:23 --> 404 Page Not Found: /index
INFO - 2018-05-12 05:58:23 --> Router Class Initialized
DEBUG - 2018-05-12 05:58:23 --> UTF-8 Support Enabled
INFO - 2018-05-12 05:58:23 --> Utf8 Class Initialized
INFO - 2018-05-12 05:58:23 --> Output Class Initialized
DEBUG - 2018-05-12 05:58:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 05:58:23 --> Config Class Initialized
INFO - 2018-05-12 05:58:23 --> Utf8 Class Initialized
INFO - 2018-05-12 05:58:23 --> Hooks Class Initialized
INFO - 2018-05-12 05:58:23 --> URI Class Initialized
INFO - 2018-05-12 05:58:23 --> URI Class Initialized
INFO - 2018-05-12 05:58:23 --> Input Class Initialized
INFO - 2018-05-12 05:58:23 --> Security Class Initialized
DEBUG - 2018-05-12 05:58:23 --> UTF-8 Support Enabled
INFO - 2018-05-12 05:58:23 --> Router Class Initialized
DEBUG - 2018-05-12 05:58:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 05:58:23 --> Language Class Initialized
INFO - 2018-05-12 05:58:23 --> Router Class Initialized
INFO - 2018-05-12 05:58:23 --> Utf8 Class Initialized
INFO - 2018-05-12 05:58:23 --> Output Class Initialized
INFO - 2018-05-12 05:58:23 --> Input Class Initialized
INFO - 2018-05-12 05:58:23 --> Output Class Initialized
ERROR - 2018-05-12 05:58:23 --> 404 Page Not Found: /index
INFO - 2018-05-12 05:58:23 --> Language Class Initialized
INFO - 2018-05-12 05:58:23 --> URI Class Initialized
INFO - 2018-05-12 05:58:23 --> Security Class Initialized
INFO - 2018-05-12 05:58:23 --> Security Class Initialized
INFO - 2018-05-12 05:58:23 --> Config Class Initialized
INFO - 2018-05-12 05:58:23 --> Hooks Class Initialized
ERROR - 2018-05-12 05:58:23 --> 404 Page Not Found: /index
DEBUG - 2018-05-12 05:58:23 --> UTF-8 Support Enabled
INFO - 2018-05-12 05:58:23 --> Utf8 Class Initialized
INFO - 2018-05-12 05:58:23 --> URI Class Initialized
INFO - 2018-05-12 05:58:23 --> Router Class Initialized
INFO - 2018-05-12 05:58:23 --> Output Class Initialized
INFO - 2018-05-12 05:58:23 --> Security Class Initialized
DEBUG - 2018-05-12 05:58:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 05:58:23 --> Router Class Initialized
DEBUG - 2018-05-12 05:58:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 05:58:23 --> Input Class Initialized
DEBUG - 2018-05-12 05:58:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 05:58:23 --> Input Class Initialized
INFO - 2018-05-12 05:58:23 --> Output Class Initialized
INFO - 2018-05-12 05:58:23 --> Config Class Initialized
INFO - 2018-05-12 05:58:23 --> Hooks Class Initialized
INFO - 2018-05-12 05:58:23 --> Language Class Initialized
INFO - 2018-05-12 05:58:23 --> Input Class Initialized
INFO - 2018-05-12 05:58:23 --> Language Class Initialized
INFO - 2018-05-12 05:58:23 --> Security Class Initialized
DEBUG - 2018-05-12 05:58:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-05-12 05:58:23 --> 404 Page Not Found: /index
ERROR - 2018-05-12 05:58:23 --> 404 Page Not Found: /index
INFO - 2018-05-12 05:58:23 --> Language Class Initialized
DEBUG - 2018-05-12 05:58:23 --> UTF-8 Support Enabled
INFO - 2018-05-12 05:58:23 --> Input Class Initialized
INFO - 2018-05-12 05:58:23 --> Language Class Initialized
ERROR - 2018-05-12 05:58:23 --> 404 Page Not Found: /index
INFO - 2018-05-12 05:58:23 --> Utf8 Class Initialized
ERROR - 2018-05-12 05:58:23 --> 404 Page Not Found: /index
INFO - 2018-05-12 05:58:23 --> URI Class Initialized
INFO - 2018-05-12 05:58:23 --> Config Class Initialized
INFO - 2018-05-12 05:58:23 --> Hooks Class Initialized
INFO - 2018-05-12 05:58:23 --> Router Class Initialized
INFO - 2018-05-12 05:58:23 --> Output Class Initialized
DEBUG - 2018-05-12 05:58:23 --> UTF-8 Support Enabled
INFO - 2018-05-12 05:58:23 --> Utf8 Class Initialized
INFO - 2018-05-12 05:58:23 --> Security Class Initialized
INFO - 2018-05-12 05:58:23 --> URI Class Initialized
DEBUG - 2018-05-12 05:58:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 05:58:23 --> Router Class Initialized
INFO - 2018-05-12 05:58:23 --> Input Class Initialized
INFO - 2018-05-12 05:58:23 --> Output Class Initialized
INFO - 2018-05-12 05:58:23 --> Language Class Initialized
INFO - 2018-05-12 05:58:23 --> Security Class Initialized
ERROR - 2018-05-12 05:58:23 --> 404 Page Not Found: /index
DEBUG - 2018-05-12 05:58:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 05:58:23 --> Input Class Initialized
INFO - 2018-05-12 05:58:23 --> Language Class Initialized
ERROR - 2018-05-12 05:58:23 --> 404 Page Not Found: /index
INFO - 2018-05-12 05:58:35 --> Config Class Initialized
INFO - 2018-05-12 05:58:36 --> Hooks Class Initialized
DEBUG - 2018-05-12 05:58:36 --> UTF-8 Support Enabled
INFO - 2018-05-12 05:58:36 --> Utf8 Class Initialized
INFO - 2018-05-12 05:58:36 --> URI Class Initialized
INFO - 2018-05-12 05:58:36 --> Router Class Initialized
INFO - 2018-05-12 05:58:36 --> Output Class Initialized
INFO - 2018-05-12 05:58:36 --> Security Class Initialized
DEBUG - 2018-05-12 05:58:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 05:58:36 --> Input Class Initialized
INFO - 2018-05-12 05:58:36 --> Language Class Initialized
ERROR - 2018-05-12 05:58:36 --> 404 Page Not Found: /index
INFO - 2018-05-12 05:58:36 --> Config Class Initialized
INFO - 2018-05-12 05:58:36 --> Hooks Class Initialized
DEBUG - 2018-05-12 05:58:36 --> UTF-8 Support Enabled
INFO - 2018-05-12 05:58:36 --> Utf8 Class Initialized
INFO - 2018-05-12 05:58:36 --> URI Class Initialized
INFO - 2018-05-12 05:58:36 --> Router Class Initialized
INFO - 2018-05-12 05:58:36 --> Output Class Initialized
INFO - 2018-05-12 05:58:36 --> Security Class Initialized
DEBUG - 2018-05-12 05:58:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 05:58:36 --> Input Class Initialized
INFO - 2018-05-12 05:58:36 --> Language Class Initialized
ERROR - 2018-05-12 05:58:36 --> 404 Page Not Found: /index
INFO - 2018-05-12 05:58:36 --> Config Class Initialized
INFO - 2018-05-12 05:58:36 --> Hooks Class Initialized
DEBUG - 2018-05-12 05:58:36 --> UTF-8 Support Enabled
INFO - 2018-05-12 05:58:36 --> Utf8 Class Initialized
INFO - 2018-05-12 05:58:36 --> URI Class Initialized
INFO - 2018-05-12 05:58:36 --> Router Class Initialized
INFO - 2018-05-12 05:58:36 --> Output Class Initialized
INFO - 2018-05-12 05:58:36 --> Security Class Initialized
DEBUG - 2018-05-12 05:58:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-12 05:58:36 --> Input Class Initialized
INFO - 2018-05-12 05:58:36 --> Language Class Initialized
ERROR - 2018-05-12 05:58:36 --> 404 Page Not Found: /index
