<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-05-14 21:23:29 --> Config Class Initialized
INFO - 2018-05-14 21:23:29 --> Config Class Initialized
INFO - 2018-05-14 21:23:29 --> Hooks Class Initialized
INFO - 2018-05-14 21:23:29 --> Hooks Class Initialized
DEBUG - 2018-05-14 21:23:29 --> UTF-8 Support Enabled
DEBUG - 2018-05-14 21:23:29 --> UTF-8 Support Enabled
INFO - 2018-05-14 21:23:29 --> Utf8 Class Initialized
INFO - 2018-05-14 21:23:29 --> Utf8 Class Initialized
INFO - 2018-05-14 21:23:29 --> URI Class Initialized
INFO - 2018-05-14 21:23:29 --> URI Class Initialized
INFO - 2018-05-14 21:23:29 --> Router Class Initialized
INFO - 2018-05-14 21:23:29 --> Router Class Initialized
INFO - 2018-05-14 21:23:29 --> Output Class Initialized
INFO - 2018-05-14 21:23:29 --> Output Class Initialized
INFO - 2018-05-14 21:23:30 --> Security Class Initialized
INFO - 2018-05-14 21:23:30 --> Security Class Initialized
DEBUG - 2018-05-14 21:23:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-14 21:23:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 21:23:30 --> Input Class Initialized
INFO - 2018-05-14 21:23:30 --> Input Class Initialized
INFO - 2018-05-14 21:23:30 --> Language Class Initialized
INFO - 2018-05-14 21:23:30 --> Language Class Initialized
INFO - 2018-05-14 21:23:31 --> Language Class Initialized
INFO - 2018-05-14 21:23:31 --> Language Class Initialized
INFO - 2018-05-14 21:23:31 --> Config Class Initialized
INFO - 2018-05-14 21:23:31 --> Config Class Initialized
INFO - 2018-05-14 21:23:31 --> Config Class Initialized
INFO - 2018-05-14 21:23:31 --> Hooks Class Initialized
DEBUG - 2018-05-14 21:23:31 --> UTF-8 Support Enabled
INFO - 2018-05-14 21:23:31 --> Utf8 Class Initialized
INFO - 2018-05-14 21:23:31 --> URI Class Initialized
INFO - 2018-05-14 21:23:31 --> Router Class Initialized
INFO - 2018-05-14 21:23:31 --> Output Class Initialized
INFO - 2018-05-14 21:23:31 --> Security Class Initialized
DEBUG - 2018-05-14 21:23:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 21:23:31 --> Input Class Initialized
INFO - 2018-05-14 21:23:31 --> Language Class Initialized
ERROR - 2018-05-14 21:23:32 --> 404 Page Not Found: /index
INFO - 2018-05-14 21:23:32 --> Loader Class Initialized
INFO - 2018-05-14 21:23:32 --> Loader Class Initialized
DEBUG - 2018-05-14 21:23:33 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
DEBUG - 2018-05-14 21:23:33 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-14 21:23:33 --> Helper loaded: url_helper
INFO - 2018-05-14 21:23:33 --> Helper loaded: url_helper
INFO - 2018-05-14 21:23:33 --> Helper loaded: form_helper
INFO - 2018-05-14 21:23:33 --> Helper loaded: form_helper
INFO - 2018-05-14 21:23:33 --> Helper loaded: date_helper
INFO - 2018-05-14 21:23:33 --> Helper loaded: date_helper
INFO - 2018-05-14 21:23:33 --> Helper loaded: util_helper
INFO - 2018-05-14 21:23:33 --> Helper loaded: util_helper
INFO - 2018-05-14 21:23:33 --> Helper loaded: text_helper
INFO - 2018-05-14 21:23:33 --> Helper loaded: text_helper
INFO - 2018-05-14 21:23:33 --> Helper loaded: string_helper
INFO - 2018-05-14 21:23:33 --> Helper loaded: string_helper
INFO - 2018-05-14 21:23:33 --> Database Driver Class Initialized
INFO - 2018-05-14 21:23:33 --> Database Driver Class Initialized
DEBUG - 2018-05-14 21:23:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-05-14 21:23:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-14 21:23:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-14 21:23:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-14 21:23:36 --> Email Class Initialized
INFO - 2018-05-14 21:23:36 --> Email Class Initialized
INFO - 2018-05-14 21:23:36 --> Controller Class Initialized
INFO - 2018-05-14 21:23:36 --> Controller Class Initialized
DEBUG - 2018-05-14 21:23:36 --> Admin MX_Controller Initialized
DEBUG - 2018-05-14 21:23:36 --> Home MX_Controller Initialized
INFO - 2018-05-14 21:23:36 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-14 21:23:36 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-14 21:23:36 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-14 21:23:36 --> Login MX_Controller Initialized
DEBUG - 2018-05-14 21:23:36 --> Login MX_Controller Initialized
INFO - 2018-05-14 21:23:36 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-14 21:23:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-14 21:23:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-14 21:23:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-14 21:23:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-14 21:23:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/login.php
DEBUG - 2018-05-14 21:23:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/logins/login.php
INFO - 2018-05-14 21:23:38 --> Config Class Initialized
INFO - 2018-05-14 21:23:38 --> Hooks Class Initialized
DEBUG - 2018-05-14 21:23:38 --> UTF-8 Support Enabled
INFO - 2018-05-14 21:23:38 --> Utf8 Class Initialized
INFO - 2018-05-14 21:23:38 --> URI Class Initialized
INFO - 2018-05-14 21:23:38 --> Router Class Initialized
INFO - 2018-05-14 21:23:38 --> Output Class Initialized
INFO - 2018-05-14 21:23:38 --> Security Class Initialized
DEBUG - 2018-05-14 21:23:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 21:23:38 --> Input Class Initialized
INFO - 2018-05-14 21:23:38 --> Language Class Initialized
ERROR - 2018-05-14 21:23:38 --> 404 Page Not Found: /index
INFO - 2018-05-14 21:23:39 --> Config Class Initialized
INFO - 2018-05-14 21:23:39 --> Hooks Class Initialized
DEBUG - 2018-05-14 21:23:39 --> UTF-8 Support Enabled
INFO - 2018-05-14 21:23:39 --> Utf8 Class Initialized
INFO - 2018-05-14 21:23:39 --> URI Class Initialized
INFO - 2018-05-14 21:23:39 --> Router Class Initialized
INFO - 2018-05-14 21:23:39 --> Output Class Initialized
INFO - 2018-05-14 21:23:39 --> Security Class Initialized
DEBUG - 2018-05-14 21:23:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 21:23:39 --> Input Class Initialized
INFO - 2018-05-14 21:23:39 --> Language Class Initialized
ERROR - 2018-05-14 21:23:39 --> 404 Page Not Found: /index
INFO - 2018-05-14 21:23:44 --> Config Class Initialized
INFO - 2018-05-14 21:23:44 --> Hooks Class Initialized
DEBUG - 2018-05-14 21:23:44 --> UTF-8 Support Enabled
INFO - 2018-05-14 21:23:44 --> Utf8 Class Initialized
INFO - 2018-05-14 21:23:44 --> URI Class Initialized
INFO - 2018-05-14 21:23:44 --> Router Class Initialized
INFO - 2018-05-14 21:23:44 --> Output Class Initialized
INFO - 2018-05-14 21:23:44 --> Security Class Initialized
DEBUG - 2018-05-14 21:23:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 21:23:44 --> Input Class Initialized
INFO - 2018-05-14 21:23:44 --> Language Class Initialized
INFO - 2018-05-14 21:23:44 --> Language Class Initialized
INFO - 2018-05-14 21:23:44 --> Config Class Initialized
INFO - 2018-05-14 21:23:44 --> Loader Class Initialized
DEBUG - 2018-05-14 21:23:44 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-14 21:23:44 --> Helper loaded: url_helper
INFO - 2018-05-14 21:23:44 --> Helper loaded: form_helper
INFO - 2018-05-14 21:23:44 --> Helper loaded: date_helper
INFO - 2018-05-14 21:23:44 --> Helper loaded: util_helper
INFO - 2018-05-14 21:23:44 --> Helper loaded: text_helper
INFO - 2018-05-14 21:23:44 --> Helper loaded: string_helper
INFO - 2018-05-14 21:23:44 --> Database Driver Class Initialized
DEBUG - 2018-05-14 21:23:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-14 21:23:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-14 21:23:44 --> Email Class Initialized
INFO - 2018-05-14 21:23:44 --> Controller Class Initialized
DEBUG - 2018-05-14 21:23:44 --> Login MX_Controller Initialized
INFO - 2018-05-14 21:23:44 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-14 21:23:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-14 21:23:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-14 21:23:44 --> Email starts for gopipanguluri123@gmail.com fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-05-14 21:23:45 --> Login status gopipanguluri123@gmail.com - failure
INFO - 2018-05-14 21:23:45 --> Final output sent to browser
DEBUG - 2018-05-14 21:23:45 --> Total execution time: 0.8348
INFO - 2018-05-14 21:23:49 --> Config Class Initialized
INFO - 2018-05-14 21:23:49 --> Hooks Class Initialized
DEBUG - 2018-05-14 21:23:49 --> UTF-8 Support Enabled
INFO - 2018-05-14 21:23:49 --> Utf8 Class Initialized
INFO - 2018-05-14 21:23:49 --> URI Class Initialized
INFO - 2018-05-14 21:23:49 --> Router Class Initialized
INFO - 2018-05-14 21:23:49 --> Output Class Initialized
INFO - 2018-05-14 21:23:49 --> Security Class Initialized
DEBUG - 2018-05-14 21:23:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 21:23:49 --> Input Class Initialized
INFO - 2018-05-14 21:23:49 --> Language Class Initialized
INFO - 2018-05-14 21:23:49 --> Language Class Initialized
INFO - 2018-05-14 21:23:50 --> Config Class Initialized
INFO - 2018-05-14 21:23:50 --> Loader Class Initialized
DEBUG - 2018-05-14 21:23:50 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-14 21:23:50 --> Helper loaded: url_helper
INFO - 2018-05-14 21:23:50 --> Helper loaded: form_helper
INFO - 2018-05-14 21:23:50 --> Helper loaded: date_helper
INFO - 2018-05-14 21:23:50 --> Helper loaded: util_helper
INFO - 2018-05-14 21:23:50 --> Helper loaded: text_helper
INFO - 2018-05-14 21:23:50 --> Helper loaded: string_helper
INFO - 2018-05-14 21:23:50 --> Database Driver Class Initialized
DEBUG - 2018-05-14 21:23:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-14 21:23:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-14 21:23:50 --> Email Class Initialized
INFO - 2018-05-14 21:23:50 --> Controller Class Initialized
DEBUG - 2018-05-14 21:23:50 --> Login MX_Controller Initialized
INFO - 2018-05-14 21:23:50 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-14 21:23:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-14 21:23:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-14 21:23:50 --> Email starts for admin@consulting.com fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-05-14 21:23:50 --> User session created for 1
INFO - 2018-05-14 21:23:50 --> Login status admin@consulting.com - success
INFO - 2018-05-14 21:23:50 --> Final output sent to browser
DEBUG - 2018-05-14 21:23:50 --> Total execution time: 0.4885
INFO - 2018-05-14 21:23:50 --> Config Class Initialized
INFO - 2018-05-14 21:23:50 --> Hooks Class Initialized
DEBUG - 2018-05-14 21:23:50 --> UTF-8 Support Enabled
INFO - 2018-05-14 21:23:50 --> Utf8 Class Initialized
INFO - 2018-05-14 21:23:50 --> URI Class Initialized
INFO - 2018-05-14 21:23:50 --> Router Class Initialized
INFO - 2018-05-14 21:23:50 --> Output Class Initialized
INFO - 2018-05-14 21:23:50 --> Security Class Initialized
DEBUG - 2018-05-14 21:23:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 21:23:50 --> Input Class Initialized
INFO - 2018-05-14 21:23:50 --> Language Class Initialized
INFO - 2018-05-14 21:23:50 --> Language Class Initialized
INFO - 2018-05-14 21:23:50 --> Config Class Initialized
INFO - 2018-05-14 21:23:50 --> Loader Class Initialized
DEBUG - 2018-05-14 21:23:50 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-14 21:23:50 --> Helper loaded: url_helper
INFO - 2018-05-14 21:23:50 --> Helper loaded: form_helper
INFO - 2018-05-14 21:23:50 --> Helper loaded: date_helper
INFO - 2018-05-14 21:23:50 --> Helper loaded: util_helper
INFO - 2018-05-14 21:23:50 --> Helper loaded: text_helper
INFO - 2018-05-14 21:23:50 --> Helper loaded: string_helper
INFO - 2018-05-14 21:23:50 --> Database Driver Class Initialized
DEBUG - 2018-05-14 21:23:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-14 21:23:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-14 21:23:50 --> Email Class Initialized
INFO - 2018-05-14 21:23:50 --> Controller Class Initialized
DEBUG - 2018-05-14 21:23:50 --> Admin MX_Controller Initialized
INFO - 2018-05-14 21:23:50 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-14 21:23:50 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-14 21:23:50 --> Login MX_Controller Initialized
DEBUG - 2018-05-14 21:23:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-14 21:23:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-14 21:23:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-05-14 21:23:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-05-14 21:23:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-05-14 21:23:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-05-14 21:23:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-05-14 21:23:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/dashboard.php
INFO - 2018-05-14 21:23:51 --> Final output sent to browser
DEBUG - 2018-05-14 21:23:51 --> Total execution time: 1.1117
INFO - 2018-05-14 21:23:52 --> Config Class Initialized
INFO - 2018-05-14 21:23:52 --> Hooks Class Initialized
DEBUG - 2018-05-14 21:23:52 --> UTF-8 Support Enabled
INFO - 2018-05-14 21:23:52 --> Utf8 Class Initialized
INFO - 2018-05-14 21:23:52 --> URI Class Initialized
INFO - 2018-05-14 21:23:52 --> Router Class Initialized
INFO - 2018-05-14 21:23:52 --> Output Class Initialized
INFO - 2018-05-14 21:23:52 --> Security Class Initialized
DEBUG - 2018-05-14 21:23:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 21:23:52 --> Input Class Initialized
INFO - 2018-05-14 21:23:52 --> Language Class Initialized
ERROR - 2018-05-14 21:23:52 --> 404 Page Not Found: /index
INFO - 2018-05-14 21:23:55 --> Config Class Initialized
INFO - 2018-05-14 21:23:55 --> Hooks Class Initialized
DEBUG - 2018-05-14 21:23:55 --> UTF-8 Support Enabled
INFO - 2018-05-14 21:23:55 --> Utf8 Class Initialized
INFO - 2018-05-14 21:23:55 --> URI Class Initialized
INFO - 2018-05-14 21:23:55 --> Router Class Initialized
INFO - 2018-05-14 21:23:55 --> Output Class Initialized
INFO - 2018-05-14 21:23:55 --> Security Class Initialized
DEBUG - 2018-05-14 21:23:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 21:23:55 --> Input Class Initialized
INFO - 2018-05-14 21:23:55 --> Language Class Initialized
INFO - 2018-05-14 21:23:55 --> Language Class Initialized
INFO - 2018-05-14 21:23:55 --> Config Class Initialized
INFO - 2018-05-14 21:23:55 --> Loader Class Initialized
DEBUG - 2018-05-14 21:23:55 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-14 21:23:55 --> Helper loaded: url_helper
INFO - 2018-05-14 21:23:55 --> Helper loaded: form_helper
INFO - 2018-05-14 21:23:55 --> Helper loaded: date_helper
INFO - 2018-05-14 21:23:55 --> Helper loaded: util_helper
INFO - 2018-05-14 21:23:55 --> Helper loaded: text_helper
INFO - 2018-05-14 21:23:55 --> Helper loaded: string_helper
INFO - 2018-05-14 21:23:55 --> Database Driver Class Initialized
DEBUG - 2018-05-14 21:23:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-14 21:23:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-14 21:23:55 --> Email Class Initialized
INFO - 2018-05-14 21:23:55 --> Controller Class Initialized
DEBUG - 2018-05-14 21:23:55 --> Login MX_Controller Initialized
INFO - 2018-05-14 21:23:55 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-14 21:23:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-14 21:23:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-14 21:23:55 --> Email starts for gopipanguluri123@gmail.com fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-05-14 21:23:56 --> User session created for 4
INFO - 2018-05-14 21:23:56 --> Login status gopipanguluri123@gmail.com - success
INFO - 2018-05-14 21:23:56 --> Final output sent to browser
DEBUG - 2018-05-14 21:23:56 --> Total execution time: 0.8189
INFO - 2018-05-14 21:23:56 --> Config Class Initialized
INFO - 2018-05-14 21:23:56 --> Hooks Class Initialized
DEBUG - 2018-05-14 21:23:56 --> UTF-8 Support Enabled
INFO - 2018-05-14 21:23:56 --> Utf8 Class Initialized
INFO - 2018-05-14 21:23:56 --> URI Class Initialized
INFO - 2018-05-14 21:23:56 --> Router Class Initialized
INFO - 2018-05-14 21:23:56 --> Output Class Initialized
INFO - 2018-05-14 21:23:56 --> Security Class Initialized
DEBUG - 2018-05-14 21:23:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 21:23:56 --> Input Class Initialized
INFO - 2018-05-14 21:23:56 --> Language Class Initialized
INFO - 2018-05-14 21:23:56 --> Language Class Initialized
INFO - 2018-05-14 21:23:56 --> Config Class Initialized
INFO - 2018-05-14 21:23:56 --> Loader Class Initialized
DEBUG - 2018-05-14 21:23:56 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-14 21:23:56 --> Helper loaded: url_helper
INFO - 2018-05-14 21:23:56 --> Helper loaded: form_helper
INFO - 2018-05-14 21:23:56 --> Helper loaded: date_helper
INFO - 2018-05-14 21:23:56 --> Helper loaded: util_helper
INFO - 2018-05-14 21:23:56 --> Helper loaded: text_helper
INFO - 2018-05-14 21:23:56 --> Helper loaded: string_helper
INFO - 2018-05-14 21:23:56 --> Database Driver Class Initialized
DEBUG - 2018-05-14 21:23:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-14 21:23:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-14 21:23:56 --> Email Class Initialized
INFO - 2018-05-14 21:23:56 --> Controller Class Initialized
DEBUG - 2018-05-14 21:23:56 --> Home MX_Controller Initialized
DEBUG - 2018-05-14 21:23:56 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-14 21:23:56 --> Login MX_Controller Initialized
INFO - 2018-05-14 21:23:56 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-14 21:23:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-14 21:23:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-14 21:23:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-05-14 21:23:57 --> Final output sent to browser
DEBUG - 2018-05-14 21:23:57 --> Total execution time: 0.6063
INFO - 2018-05-14 21:23:57 --> Config Class Initialized
INFO - 2018-05-14 21:23:57 --> Hooks Class Initialized
DEBUG - 2018-05-14 21:23:57 --> UTF-8 Support Enabled
INFO - 2018-05-14 21:23:57 --> Utf8 Class Initialized
INFO - 2018-05-14 21:23:57 --> URI Class Initialized
INFO - 2018-05-14 21:23:57 --> Router Class Initialized
INFO - 2018-05-14 21:23:57 --> Output Class Initialized
INFO - 2018-05-14 21:23:57 --> Security Class Initialized
DEBUG - 2018-05-14 21:23:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 21:23:57 --> Input Class Initialized
INFO - 2018-05-14 21:23:57 --> Language Class Initialized
ERROR - 2018-05-14 21:23:57 --> 404 Page Not Found: /index
INFO - 2018-05-14 21:23:57 --> Config Class Initialized
INFO - 2018-05-14 21:23:57 --> Hooks Class Initialized
DEBUG - 2018-05-14 21:23:57 --> UTF-8 Support Enabled
INFO - 2018-05-14 21:23:57 --> Utf8 Class Initialized
INFO - 2018-05-14 21:23:57 --> URI Class Initialized
INFO - 2018-05-14 21:23:57 --> Router Class Initialized
INFO - 2018-05-14 21:23:57 --> Output Class Initialized
INFO - 2018-05-14 21:23:58 --> Security Class Initialized
DEBUG - 2018-05-14 21:23:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 21:23:58 --> Input Class Initialized
INFO - 2018-05-14 21:23:58 --> Language Class Initialized
ERROR - 2018-05-14 21:23:58 --> 404 Page Not Found: /index
INFO - 2018-05-14 21:23:58 --> Config Class Initialized
INFO - 2018-05-14 21:23:58 --> Hooks Class Initialized
DEBUG - 2018-05-14 21:23:58 --> UTF-8 Support Enabled
INFO - 2018-05-14 21:23:58 --> Utf8 Class Initialized
INFO - 2018-05-14 21:23:58 --> URI Class Initialized
INFO - 2018-05-14 21:23:58 --> Router Class Initialized
INFO - 2018-05-14 21:23:58 --> Output Class Initialized
INFO - 2018-05-14 21:23:58 --> Security Class Initialized
DEBUG - 2018-05-14 21:23:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 21:23:58 --> Input Class Initialized
INFO - 2018-05-14 21:23:58 --> Language Class Initialized
ERROR - 2018-05-14 21:23:58 --> 404 Page Not Found: /index
INFO - 2018-05-14 21:23:58 --> Config Class Initialized
INFO - 2018-05-14 21:23:58 --> Hooks Class Initialized
DEBUG - 2018-05-14 21:23:58 --> UTF-8 Support Enabled
INFO - 2018-05-14 21:23:58 --> Utf8 Class Initialized
INFO - 2018-05-14 21:23:58 --> URI Class Initialized
INFO - 2018-05-14 21:23:58 --> Router Class Initialized
INFO - 2018-05-14 21:23:58 --> Output Class Initialized
INFO - 2018-05-14 21:23:58 --> Security Class Initialized
DEBUG - 2018-05-14 21:23:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 21:23:58 --> Input Class Initialized
INFO - 2018-05-14 21:23:58 --> Language Class Initialized
ERROR - 2018-05-14 21:23:58 --> 404 Page Not Found: /index
INFO - 2018-05-14 21:23:59 --> Config Class Initialized
INFO - 2018-05-14 21:23:59 --> Config Class Initialized
INFO - 2018-05-14 21:23:59 --> Config Class Initialized
INFO - 2018-05-14 21:23:59 --> Config Class Initialized
INFO - 2018-05-14 21:23:59 --> Config Class Initialized
INFO - 2018-05-14 21:23:59 --> Hooks Class Initialized
INFO - 2018-05-14 21:23:59 --> Hooks Class Initialized
INFO - 2018-05-14 21:23:59 --> Hooks Class Initialized
DEBUG - 2018-05-14 21:23:59 --> UTF-8 Support Enabled
INFO - 2018-05-14 21:23:59 --> Hooks Class Initialized
INFO - 2018-05-14 21:23:59 --> Hooks Class Initialized
INFO - 2018-05-14 21:23:59 --> Utf8 Class Initialized
DEBUG - 2018-05-14 21:23:59 --> UTF-8 Support Enabled
DEBUG - 2018-05-14 21:23:59 --> UTF-8 Support Enabled
DEBUG - 2018-05-14 21:23:59 --> UTF-8 Support Enabled
DEBUG - 2018-05-14 21:23:59 --> UTF-8 Support Enabled
INFO - 2018-05-14 21:23:59 --> Utf8 Class Initialized
INFO - 2018-05-14 21:23:59 --> URI Class Initialized
INFO - 2018-05-14 21:23:59 --> Utf8 Class Initialized
INFO - 2018-05-14 21:23:59 --> URI Class Initialized
INFO - 2018-05-14 21:23:59 --> Router Class Initialized
INFO - 2018-05-14 21:23:59 --> Utf8 Class Initialized
INFO - 2018-05-14 21:23:59 --> Utf8 Class Initialized
INFO - 2018-05-14 21:23:59 --> URI Class Initialized
INFO - 2018-05-14 21:23:59 --> Router Class Initialized
INFO - 2018-05-14 21:23:59 --> Output Class Initialized
INFO - 2018-05-14 21:23:59 --> Output Class Initialized
INFO - 2018-05-14 21:23:59 --> Router Class Initialized
INFO - 2018-05-14 21:23:59 --> URI Class Initialized
INFO - 2018-05-14 21:23:59 --> URI Class Initialized
INFO - 2018-05-14 21:23:59 --> Security Class Initialized
INFO - 2018-05-14 21:23:59 --> Security Class Initialized
INFO - 2018-05-14 21:23:59 --> Output Class Initialized
INFO - 2018-05-14 21:23:59 --> Router Class Initialized
INFO - 2018-05-14 21:23:59 --> Router Class Initialized
DEBUG - 2018-05-14 21:23:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 21:23:59 --> Output Class Initialized
INFO - 2018-05-14 21:23:59 --> Security Class Initialized
DEBUG - 2018-05-14 21:23:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 21:23:59 --> Input Class Initialized
INFO - 2018-05-14 21:23:59 --> Language Class Initialized
ERROR - 2018-05-14 21:23:59 --> 404 Page Not Found: /index
INFO - 2018-05-14 21:23:59 --> Config Class Initialized
INFO - 2018-05-14 21:23:59 --> Input Class Initialized
DEBUG - 2018-05-14 21:23:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 21:23:59 --> Security Class Initialized
INFO - 2018-05-14 21:23:59 --> Hooks Class Initialized
INFO - 2018-05-14 21:23:59 --> Output Class Initialized
INFO - 2018-05-14 21:23:59 --> Security Class Initialized
DEBUG - 2018-05-14 21:23:59 --> UTF-8 Support Enabled
DEBUG - 2018-05-14 21:23:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 21:23:59 --> Input Class Initialized
INFO - 2018-05-14 21:23:59 --> Language Class Initialized
INFO - 2018-05-14 21:23:59 --> Utf8 Class Initialized
INFO - 2018-05-14 21:23:59 --> Input Class Initialized
ERROR - 2018-05-14 21:23:59 --> 404 Page Not Found: /index
INFO - 2018-05-14 21:23:59 --> Language Class Initialized
DEBUG - 2018-05-14 21:23:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 21:23:59 --> Input Class Initialized
INFO - 2018-05-14 21:23:59 --> URI Class Initialized
ERROR - 2018-05-14 21:23:59 --> 404 Page Not Found: /index
INFO - 2018-05-14 21:23:59 --> Language Class Initialized
INFO - 2018-05-14 21:23:59 --> Config Class Initialized
INFO - 2018-05-14 21:23:59 --> Router Class Initialized
INFO - 2018-05-14 21:23:59 --> Language Class Initialized
INFO - 2018-05-14 21:23:59 --> Config Class Initialized
ERROR - 2018-05-14 21:23:59 --> 404 Page Not Found: /index
INFO - 2018-05-14 21:23:59 --> Hooks Class Initialized
INFO - 2018-05-14 21:23:59 --> Hooks Class Initialized
ERROR - 2018-05-14 21:23:59 --> 404 Page Not Found: /index
INFO - 2018-05-14 21:23:59 --> Output Class Initialized
INFO - 2018-05-14 21:23:59 --> Config Class Initialized
INFO - 2018-05-14 21:23:59 --> Hooks Class Initialized
DEBUG - 2018-05-14 21:23:59 --> UTF-8 Support Enabled
DEBUG - 2018-05-14 21:23:59 --> UTF-8 Support Enabled
INFO - 2018-05-14 21:23:59 --> Security Class Initialized
INFO - 2018-05-14 21:23:59 --> Config Class Initialized
INFO - 2018-05-14 21:23:59 --> Hooks Class Initialized
DEBUG - 2018-05-14 21:23:59 --> UTF-8 Support Enabled
INFO - 2018-05-14 21:23:59 --> Utf8 Class Initialized
INFO - 2018-05-14 21:23:59 --> Utf8 Class Initialized
DEBUG - 2018-05-14 21:23:59 --> UTF-8 Support Enabled
DEBUG - 2018-05-14 21:23:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 21:23:59 --> Utf8 Class Initialized
INFO - 2018-05-14 21:23:59 --> Utf8 Class Initialized
INFO - 2018-05-14 21:23:59 --> URI Class Initialized
INFO - 2018-05-14 21:23:59 --> URI Class Initialized
INFO - 2018-05-14 21:23:59 --> URI Class Initialized
INFO - 2018-05-14 21:23:59 --> Input Class Initialized
INFO - 2018-05-14 21:23:59 --> URI Class Initialized
INFO - 2018-05-14 21:23:59 --> Router Class Initialized
INFO - 2018-05-14 21:23:59 --> Router Class Initialized
INFO - 2018-05-14 21:23:59 --> Router Class Initialized
INFO - 2018-05-14 21:23:59 --> Router Class Initialized
INFO - 2018-05-14 21:23:59 --> Output Class Initialized
INFO - 2018-05-14 21:23:59 --> Output Class Initialized
INFO - 2018-05-14 21:23:59 --> Output Class Initialized
INFO - 2018-05-14 21:23:59 --> Output Class Initialized
INFO - 2018-05-14 21:23:59 --> Language Class Initialized
INFO - 2018-05-14 21:23:59 --> Security Class Initialized
INFO - 2018-05-14 21:23:59 --> Security Class Initialized
DEBUG - 2018-05-14 21:23:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-14 21:23:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 21:23:59 --> Input Class Initialized
INFO - 2018-05-14 21:23:59 --> Security Class Initialized
INFO - 2018-05-14 21:23:59 --> Input Class Initialized
INFO - 2018-05-14 21:23:59 --> Language Class Initialized
ERROR - 2018-05-14 21:23:59 --> 404 Page Not Found: /index
DEBUG - 2018-05-14 21:23:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 21:23:59 --> Input Class Initialized
INFO - 2018-05-14 21:23:59 --> Language Class Initialized
ERROR - 2018-05-14 21:23:59 --> 404 Page Not Found: /index
ERROR - 2018-05-14 21:23:59 --> 404 Page Not Found: /index
INFO - 2018-05-14 21:23:59 --> Security Class Initialized
DEBUG - 2018-05-14 21:23:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 21:23:59 --> Input Class Initialized
INFO - 2018-05-14 21:23:59 --> Language Class Initialized
ERROR - 2018-05-14 21:23:59 --> 404 Page Not Found: /index
INFO - 2018-05-14 21:23:59 --> Language Class Initialized
ERROR - 2018-05-14 21:24:00 --> 404 Page Not Found: /index
INFO - 2018-05-14 21:24:00 --> Config Class Initialized
INFO - 2018-05-14 21:24:00 --> Hooks Class Initialized
INFO - 2018-05-14 21:24:00 --> Config Class Initialized
INFO - 2018-05-14 21:24:00 --> Hooks Class Initialized
DEBUG - 2018-05-14 21:24:00 --> UTF-8 Support Enabled
INFO - 2018-05-14 21:24:00 --> Utf8 Class Initialized
DEBUG - 2018-05-14 21:24:00 --> UTF-8 Support Enabled
INFO - 2018-05-14 21:24:00 --> Utf8 Class Initialized
INFO - 2018-05-14 21:24:00 --> URI Class Initialized
INFO - 2018-05-14 21:24:00 --> URI Class Initialized
INFO - 2018-05-14 21:24:00 --> Router Class Initialized
INFO - 2018-05-14 21:24:00 --> Router Class Initialized
INFO - 2018-05-14 21:24:00 --> Output Class Initialized
INFO - 2018-05-14 21:24:00 --> Output Class Initialized
INFO - 2018-05-14 21:24:00 --> Security Class Initialized
INFO - 2018-05-14 21:24:00 --> Config Class Initialized
INFO - 2018-05-14 21:24:00 --> Config Class Initialized
INFO - 2018-05-14 21:24:00 --> Hooks Class Initialized
INFO - 2018-05-14 21:24:00 --> Security Class Initialized
INFO - 2018-05-14 21:24:00 --> Config Class Initialized
INFO - 2018-05-14 21:24:00 --> Hooks Class Initialized
DEBUG - 2018-05-14 21:24:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 21:24:00 --> Input Class Initialized
DEBUG - 2018-05-14 21:24:00 --> UTF-8 Support Enabled
DEBUG - 2018-05-14 21:24:00 --> UTF-8 Support Enabled
INFO - 2018-05-14 21:24:00 --> Hooks Class Initialized
DEBUG - 2018-05-14 21:24:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 21:24:00 --> Utf8 Class Initialized
INFO - 2018-05-14 21:24:00 --> Language Class Initialized
INFO - 2018-05-14 21:24:00 --> Input Class Initialized
DEBUG - 2018-05-14 21:24:00 --> UTF-8 Support Enabled
INFO - 2018-05-14 21:24:00 --> Utf8 Class Initialized
INFO - 2018-05-14 21:24:00 --> URI Class Initialized
INFO - 2018-05-14 21:24:00 --> URI Class Initialized
INFO - 2018-05-14 21:24:00 --> Utf8 Class Initialized
ERROR - 2018-05-14 21:24:00 --> 404 Page Not Found: /index
INFO - 2018-05-14 21:24:00 --> Language Class Initialized
INFO - 2018-05-14 21:24:00 --> Router Class Initialized
INFO - 2018-05-14 21:24:00 --> Router Class Initialized
ERROR - 2018-05-14 21:24:00 --> 404 Page Not Found: /index
INFO - 2018-05-14 21:24:00 --> URI Class Initialized
INFO - 2018-05-14 21:24:00 --> Output Class Initialized
INFO - 2018-05-14 21:24:00 --> Security Class Initialized
DEBUG - 2018-05-14 21:24:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 21:24:00 --> Input Class Initialized
INFO - 2018-05-14 21:24:00 --> Language Class Initialized
INFO - 2018-05-14 21:24:00 --> Output Class Initialized
INFO - 2018-05-14 21:24:00 --> Router Class Initialized
INFO - 2018-05-14 21:24:00 --> Security Class Initialized
ERROR - 2018-05-14 21:24:00 --> 404 Page Not Found: /index
INFO - 2018-05-14 21:24:00 --> Output Class Initialized
DEBUG - 2018-05-14 21:24:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 21:24:00 --> Security Class Initialized
INFO - 2018-05-14 21:24:00 --> Input Class Initialized
INFO - 2018-05-14 21:24:00 --> Language Class Initialized
DEBUG - 2018-05-14 21:24:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 21:24:00 --> Input Class Initialized
ERROR - 2018-05-14 21:24:00 --> 404 Page Not Found: /index
INFO - 2018-05-14 21:24:00 --> Language Class Initialized
ERROR - 2018-05-14 21:24:01 --> 404 Page Not Found: /index
INFO - 2018-05-14 21:24:01 --> Config Class Initialized
INFO - 2018-05-14 21:24:01 --> Hooks Class Initialized
DEBUG - 2018-05-14 21:24:01 --> UTF-8 Support Enabled
INFO - 2018-05-14 21:24:01 --> Utf8 Class Initialized
INFO - 2018-05-14 21:24:01 --> URI Class Initialized
INFO - 2018-05-14 21:24:01 --> Router Class Initialized
INFO - 2018-05-14 21:24:01 --> Output Class Initialized
INFO - 2018-05-14 21:24:01 --> Security Class Initialized
DEBUG - 2018-05-14 21:24:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 21:24:01 --> Input Class Initialized
INFO - 2018-05-14 21:24:01 --> Language Class Initialized
ERROR - 2018-05-14 21:24:01 --> 404 Page Not Found: /index
INFO - 2018-05-14 21:24:04 --> Config Class Initialized
INFO - 2018-05-14 21:24:04 --> Hooks Class Initialized
DEBUG - 2018-05-14 21:24:04 --> UTF-8 Support Enabled
INFO - 2018-05-14 21:24:04 --> Utf8 Class Initialized
INFO - 2018-05-14 21:24:04 --> URI Class Initialized
INFO - 2018-05-14 21:24:04 --> Router Class Initialized
INFO - 2018-05-14 21:24:04 --> Output Class Initialized
INFO - 2018-05-14 21:24:04 --> Security Class Initialized
DEBUG - 2018-05-14 21:24:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 21:24:04 --> Input Class Initialized
INFO - 2018-05-14 21:24:04 --> Language Class Initialized
ERROR - 2018-05-14 21:24:04 --> 404 Page Not Found: /index
INFO - 2018-05-14 21:24:04 --> Config Class Initialized
INFO - 2018-05-14 21:24:04 --> Hooks Class Initialized
DEBUG - 2018-05-14 21:24:04 --> UTF-8 Support Enabled
INFO - 2018-05-14 21:24:04 --> Utf8 Class Initialized
INFO - 2018-05-14 21:24:05 --> URI Class Initialized
INFO - 2018-05-14 21:24:05 --> Router Class Initialized
INFO - 2018-05-14 21:24:05 --> Output Class Initialized
INFO - 2018-05-14 21:24:05 --> Security Class Initialized
DEBUG - 2018-05-14 21:24:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 21:24:05 --> Input Class Initialized
INFO - 2018-05-14 21:24:05 --> Language Class Initialized
ERROR - 2018-05-14 21:24:05 --> 404 Page Not Found: /index
INFO - 2018-05-14 21:24:05 --> Config Class Initialized
INFO - 2018-05-14 21:24:05 --> Hooks Class Initialized
DEBUG - 2018-05-14 21:24:05 --> UTF-8 Support Enabled
INFO - 2018-05-14 21:24:05 --> Utf8 Class Initialized
INFO - 2018-05-14 21:24:05 --> URI Class Initialized
INFO - 2018-05-14 21:24:05 --> Router Class Initialized
INFO - 2018-05-14 21:24:05 --> Output Class Initialized
INFO - 2018-05-14 21:24:05 --> Security Class Initialized
DEBUG - 2018-05-14 21:24:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 21:24:05 --> Input Class Initialized
INFO - 2018-05-14 21:24:05 --> Language Class Initialized
ERROR - 2018-05-14 21:24:05 --> 404 Page Not Found: /index
INFO - 2018-05-14 21:27:51 --> Config Class Initialized
INFO - 2018-05-14 21:27:51 --> Hooks Class Initialized
DEBUG - 2018-05-14 21:27:51 --> UTF-8 Support Enabled
INFO - 2018-05-14 21:27:51 --> Utf8 Class Initialized
INFO - 2018-05-14 21:27:51 --> URI Class Initialized
INFO - 2018-05-14 21:27:51 --> Router Class Initialized
INFO - 2018-05-14 21:27:51 --> Output Class Initialized
INFO - 2018-05-14 21:27:51 --> Security Class Initialized
DEBUG - 2018-05-14 21:27:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 21:27:51 --> Input Class Initialized
INFO - 2018-05-14 21:27:51 --> Language Class Initialized
INFO - 2018-05-14 21:27:51 --> Language Class Initialized
INFO - 2018-05-14 21:27:51 --> Config Class Initialized
INFO - 2018-05-14 21:27:51 --> Loader Class Initialized
DEBUG - 2018-05-14 21:27:51 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-14 21:27:51 --> Helper loaded: url_helper
INFO - 2018-05-14 21:27:51 --> Helper loaded: form_helper
INFO - 2018-05-14 21:27:51 --> Helper loaded: date_helper
INFO - 2018-05-14 21:27:51 --> Helper loaded: util_helper
INFO - 2018-05-14 21:27:52 --> Helper loaded: text_helper
INFO - 2018-05-14 21:27:52 --> Helper loaded: string_helper
INFO - 2018-05-14 21:27:52 --> Database Driver Class Initialized
DEBUG - 2018-05-14 21:27:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-14 21:27:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-14 21:27:52 --> Email Class Initialized
INFO - 2018-05-14 21:27:52 --> Controller Class Initialized
DEBUG - 2018-05-14 21:27:52 --> Home MX_Controller Initialized
DEBUG - 2018-05-14 21:27:52 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-14 21:27:52 --> Login MX_Controller Initialized
INFO - 2018-05-14 21:27:52 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-14 21:27:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-14 21:27:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-14 21:27:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-05-14 21:27:52 --> Final output sent to browser
DEBUG - 2018-05-14 21:27:52 --> Total execution time: 0.3603
INFO - 2018-05-14 21:27:52 --> Config Class Initialized
INFO - 2018-05-14 21:27:52 --> Hooks Class Initialized
DEBUG - 2018-05-14 21:27:52 --> UTF-8 Support Enabled
INFO - 2018-05-14 21:27:52 --> Utf8 Class Initialized
INFO - 2018-05-14 21:27:52 --> URI Class Initialized
INFO - 2018-05-14 21:27:52 --> Router Class Initialized
INFO - 2018-05-14 21:27:52 --> Output Class Initialized
INFO - 2018-05-14 21:27:52 --> Security Class Initialized
DEBUG - 2018-05-14 21:27:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 21:27:52 --> Input Class Initialized
INFO - 2018-05-14 21:27:52 --> Language Class Initialized
ERROR - 2018-05-14 21:27:52 --> 404 Page Not Found: /index
INFO - 2018-05-14 21:27:52 --> Config Class Initialized
INFO - 2018-05-14 21:27:52 --> Hooks Class Initialized
DEBUG - 2018-05-14 21:27:52 --> UTF-8 Support Enabled
INFO - 2018-05-14 21:27:53 --> Utf8 Class Initialized
INFO - 2018-05-14 21:27:53 --> URI Class Initialized
INFO - 2018-05-14 21:27:53 --> Config Class Initialized
INFO - 2018-05-14 21:27:53 --> Router Class Initialized
INFO - 2018-05-14 21:27:53 --> Config Class Initialized
INFO - 2018-05-14 21:27:53 --> Hooks Class Initialized
INFO - 2018-05-14 21:27:53 --> Hooks Class Initialized
INFO - 2018-05-14 21:27:53 --> Output Class Initialized
INFO - 2018-05-14 21:27:53 --> Config Class Initialized
INFO - 2018-05-14 21:27:53 --> Security Class Initialized
DEBUG - 2018-05-14 21:27:53 --> UTF-8 Support Enabled
DEBUG - 2018-05-14 21:27:53 --> UTF-8 Support Enabled
INFO - 2018-05-14 21:27:53 --> Hooks Class Initialized
INFO - 2018-05-14 21:27:53 --> Config Class Initialized
INFO - 2018-05-14 21:27:53 --> Utf8 Class Initialized
DEBUG - 2018-05-14 21:27:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 21:27:53 --> Hooks Class Initialized
DEBUG - 2018-05-14 21:27:53 --> UTF-8 Support Enabled
INFO - 2018-05-14 21:27:53 --> Config Class Initialized
INFO - 2018-05-14 21:27:53 --> URI Class Initialized
INFO - 2018-05-14 21:27:53 --> Utf8 Class Initialized
INFO - 2018-05-14 21:27:53 --> Input Class Initialized
INFO - 2018-05-14 21:27:53 --> Router Class Initialized
INFO - 2018-05-14 21:27:53 --> Utf8 Class Initialized
INFO - 2018-05-14 21:27:53 --> Hooks Class Initialized
DEBUG - 2018-05-14 21:27:53 --> UTF-8 Support Enabled
INFO - 2018-05-14 21:27:53 --> URI Class Initialized
INFO - 2018-05-14 21:27:53 --> Language Class Initialized
INFO - 2018-05-14 21:27:53 --> Output Class Initialized
INFO - 2018-05-14 21:27:53 --> Utf8 Class Initialized
INFO - 2018-05-14 21:27:53 --> URI Class Initialized
DEBUG - 2018-05-14 21:27:53 --> UTF-8 Support Enabled
ERROR - 2018-05-14 21:27:53 --> 404 Page Not Found: /index
INFO - 2018-05-14 21:27:53 --> Security Class Initialized
INFO - 2018-05-14 21:27:53 --> Utf8 Class Initialized
INFO - 2018-05-14 21:27:53 --> Router Class Initialized
INFO - 2018-05-14 21:27:53 --> Router Class Initialized
INFO - 2018-05-14 21:27:53 --> URI Class Initialized
INFO - 2018-05-14 21:27:53 --> Output Class Initialized
INFO - 2018-05-14 21:27:53 --> Output Class Initialized
INFO - 2018-05-14 21:27:53 --> URI Class Initialized
DEBUG - 2018-05-14 21:27:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 21:27:53 --> Router Class Initialized
INFO - 2018-05-14 21:27:53 --> Security Class Initialized
INFO - 2018-05-14 21:27:53 --> Security Class Initialized
INFO - 2018-05-14 21:27:53 --> Router Class Initialized
INFO - 2018-05-14 21:27:53 --> Input Class Initialized
INFO - 2018-05-14 21:27:53 --> Output Class Initialized
INFO - 2018-05-14 21:27:53 --> Output Class Initialized
DEBUG - 2018-05-14 21:27:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-14 21:27:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 21:27:53 --> Security Class Initialized
INFO - 2018-05-14 21:27:53 --> Language Class Initialized
INFO - 2018-05-14 21:27:53 --> Input Class Initialized
INFO - 2018-05-14 21:27:53 --> Security Class Initialized
INFO - 2018-05-14 21:27:53 --> Input Class Initialized
DEBUG - 2018-05-14 21:27:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-05-14 21:27:53 --> 404 Page Not Found: /index
DEBUG - 2018-05-14 21:27:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 21:27:53 --> Language Class Initialized
INFO - 2018-05-14 21:27:53 --> Input Class Initialized
INFO - 2018-05-14 21:27:53 --> Language Class Initialized
INFO - 2018-05-14 21:27:53 --> Input Class Initialized
INFO - 2018-05-14 21:27:53 --> Language Class Initialized
ERROR - 2018-05-14 21:27:53 --> 404 Page Not Found: /index
ERROR - 2018-05-14 21:27:53 --> 404 Page Not Found: /index
INFO - 2018-05-14 21:27:53 --> Language Class Initialized
ERROR - 2018-05-14 21:27:53 --> 404 Page Not Found: /index
ERROR - 2018-05-14 21:27:53 --> 404 Page Not Found: /index
INFO - 2018-05-14 21:27:53 --> Config Class Initialized
INFO - 2018-05-14 21:27:53 --> Config Class Initialized
INFO - 2018-05-14 21:27:53 --> Hooks Class Initialized
INFO - 2018-05-14 21:27:53 --> Config Class Initialized
DEBUG - 2018-05-14 21:27:53 --> UTF-8 Support Enabled
INFO - 2018-05-14 21:27:53 --> Config Class Initialized
INFO - 2018-05-14 21:27:53 --> Utf8 Class Initialized
INFO - 2018-05-14 21:27:53 --> Config Class Initialized
INFO - 2018-05-14 21:27:53 --> Hooks Class Initialized
INFO - 2018-05-14 21:27:53 --> Hooks Class Initialized
INFO - 2018-05-14 21:27:53 --> Hooks Class Initialized
INFO - 2018-05-14 21:27:53 --> Hooks Class Initialized
INFO - 2018-05-14 21:27:53 --> URI Class Initialized
DEBUG - 2018-05-14 21:27:53 --> UTF-8 Support Enabled
INFO - 2018-05-14 21:27:53 --> Router Class Initialized
DEBUG - 2018-05-14 21:27:53 --> UTF-8 Support Enabled
DEBUG - 2018-05-14 21:27:53 --> UTF-8 Support Enabled
DEBUG - 2018-05-14 21:27:53 --> UTF-8 Support Enabled
INFO - 2018-05-14 21:27:53 --> Utf8 Class Initialized
INFO - 2018-05-14 21:27:53 --> Utf8 Class Initialized
INFO - 2018-05-14 21:27:53 --> Output Class Initialized
INFO - 2018-05-14 21:27:53 --> Utf8 Class Initialized
INFO - 2018-05-14 21:27:53 --> Utf8 Class Initialized
INFO - 2018-05-14 21:27:53 --> Security Class Initialized
INFO - 2018-05-14 21:27:53 --> URI Class Initialized
INFO - 2018-05-14 21:27:53 --> URI Class Initialized
INFO - 2018-05-14 21:27:53 --> URI Class Initialized
INFO - 2018-05-14 21:27:53 --> URI Class Initialized
DEBUG - 2018-05-14 21:27:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 21:27:53 --> Router Class Initialized
INFO - 2018-05-14 21:27:53 --> Router Class Initialized
INFO - 2018-05-14 21:27:53 --> Router Class Initialized
INFO - 2018-05-14 21:27:53 --> Router Class Initialized
INFO - 2018-05-14 21:27:53 --> Input Class Initialized
INFO - 2018-05-14 21:27:53 --> Output Class Initialized
INFO - 2018-05-14 21:27:53 --> Output Class Initialized
INFO - 2018-05-14 21:27:53 --> Output Class Initialized
INFO - 2018-05-14 21:27:53 --> Output Class Initialized
INFO - 2018-05-14 21:27:53 --> Language Class Initialized
INFO - 2018-05-14 21:27:53 --> Security Class Initialized
INFO - 2018-05-14 21:27:53 --> Security Class Initialized
INFO - 2018-05-14 21:27:53 --> Security Class Initialized
INFO - 2018-05-14 21:27:53 --> Security Class Initialized
ERROR - 2018-05-14 21:27:53 --> 404 Page Not Found: /index
DEBUG - 2018-05-14 21:27:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-14 21:27:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-14 21:27:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-14 21:27:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 21:27:53 --> Input Class Initialized
INFO - 2018-05-14 21:27:53 --> Language Class Initialized
INFO - 2018-05-14 21:27:53 --> Input Class Initialized
ERROR - 2018-05-14 21:27:53 --> 404 Page Not Found: /index
INFO - 2018-05-14 21:27:53 --> Input Class Initialized
INFO - 2018-05-14 21:27:53 --> Input Class Initialized
INFO - 2018-05-14 21:27:53 --> Language Class Initialized
INFO - 2018-05-14 21:27:53 --> Language Class Initialized
INFO - 2018-05-14 21:27:53 --> Language Class Initialized
ERROR - 2018-05-14 21:27:53 --> 404 Page Not Found: /index
ERROR - 2018-05-14 21:27:53 --> 404 Page Not Found: /index
ERROR - 2018-05-14 21:27:53 --> 404 Page Not Found: /index
INFO - 2018-05-14 21:27:53 --> Config Class Initialized
INFO - 2018-05-14 21:27:53 --> Config Class Initialized
INFO - 2018-05-14 21:27:53 --> Hooks Class Initialized
DEBUG - 2018-05-14 21:27:53 --> UTF-8 Support Enabled
INFO - 2018-05-14 21:27:53 --> Hooks Class Initialized
INFO - 2018-05-14 21:27:53 --> Config Class Initialized
INFO - 2018-05-14 21:27:53 --> Utf8 Class Initialized
INFO - 2018-05-14 21:27:53 --> Config Class Initialized
INFO - 2018-05-14 21:27:53 --> URI Class Initialized
INFO - 2018-05-14 21:27:53 --> Config Class Initialized
INFO - 2018-05-14 21:27:53 --> Hooks Class Initialized
INFO - 2018-05-14 21:27:53 --> Hooks Class Initialized
INFO - 2018-05-14 21:27:53 --> Hooks Class Initialized
DEBUG - 2018-05-14 21:27:53 --> UTF-8 Support Enabled
INFO - 2018-05-14 21:27:53 --> Router Class Initialized
INFO - 2018-05-14 21:27:53 --> Utf8 Class Initialized
INFO - 2018-05-14 21:27:53 --> Output Class Initialized
DEBUG - 2018-05-14 21:27:53 --> UTF-8 Support Enabled
DEBUG - 2018-05-14 21:27:53 --> UTF-8 Support Enabled
DEBUG - 2018-05-14 21:27:53 --> UTF-8 Support Enabled
INFO - 2018-05-14 21:27:53 --> Utf8 Class Initialized
INFO - 2018-05-14 21:27:53 --> Utf8 Class Initialized
INFO - 2018-05-14 21:27:53 --> Utf8 Class Initialized
INFO - 2018-05-14 21:27:53 --> URI Class Initialized
INFO - 2018-05-14 21:27:53 --> Security Class Initialized
INFO - 2018-05-14 21:27:53 --> URI Class Initialized
INFO - 2018-05-14 21:27:53 --> URI Class Initialized
INFO - 2018-05-14 21:27:53 --> Router Class Initialized
DEBUG - 2018-05-14 21:27:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 21:27:53 --> URI Class Initialized
INFO - 2018-05-14 21:27:53 --> Input Class Initialized
INFO - 2018-05-14 21:27:53 --> Output Class Initialized
INFO - 2018-05-14 21:27:53 --> Router Class Initialized
INFO - 2018-05-14 21:27:53 --> Router Class Initialized
INFO - 2018-05-14 21:27:53 --> Router Class Initialized
INFO - 2018-05-14 21:27:53 --> Output Class Initialized
INFO - 2018-05-14 21:27:53 --> Output Class Initialized
INFO - 2018-05-14 21:27:53 --> Language Class Initialized
INFO - 2018-05-14 21:27:53 --> Security Class Initialized
INFO - 2018-05-14 21:27:53 --> Output Class Initialized
ERROR - 2018-05-14 21:27:53 --> 404 Page Not Found: /index
DEBUG - 2018-05-14 21:27:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 21:27:53 --> Security Class Initialized
INFO - 2018-05-14 21:27:53 --> Security Class Initialized
INFO - 2018-05-14 21:27:53 --> Security Class Initialized
INFO - 2018-05-14 21:27:53 --> Input Class Initialized
DEBUG - 2018-05-14 21:27:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-14 21:27:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-14 21:27:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 21:27:53 --> Input Class Initialized
INFO - 2018-05-14 21:27:53 --> Input Class Initialized
INFO - 2018-05-14 21:27:53 --> Input Class Initialized
INFO - 2018-05-14 21:27:53 --> Language Class Initialized
INFO - 2018-05-14 21:27:53 --> Language Class Initialized
INFO - 2018-05-14 21:27:53 --> Language Class Initialized
INFO - 2018-05-14 21:27:53 --> Language Class Initialized
ERROR - 2018-05-14 21:27:53 --> 404 Page Not Found: /index
ERROR - 2018-05-14 21:27:53 --> 404 Page Not Found: /index
ERROR - 2018-05-14 21:27:53 --> 404 Page Not Found: /index
ERROR - 2018-05-14 21:27:53 --> 404 Page Not Found: /index
INFO - 2018-05-14 21:27:54 --> Config Class Initialized
INFO - 2018-05-14 21:27:54 --> Hooks Class Initialized
DEBUG - 2018-05-14 21:27:54 --> UTF-8 Support Enabled
INFO - 2018-05-14 21:27:54 --> Utf8 Class Initialized
INFO - 2018-05-14 21:27:54 --> URI Class Initialized
INFO - 2018-05-14 21:27:54 --> Router Class Initialized
INFO - 2018-05-14 21:27:54 --> Output Class Initialized
INFO - 2018-05-14 21:27:54 --> Security Class Initialized
DEBUG - 2018-05-14 21:27:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 21:27:54 --> Input Class Initialized
INFO - 2018-05-14 21:27:54 --> Language Class Initialized
INFO - 2018-05-14 21:27:54 --> Language Class Initialized
INFO - 2018-05-14 21:27:54 --> Config Class Initialized
INFO - 2018-05-14 21:27:54 --> Loader Class Initialized
DEBUG - 2018-05-14 21:27:54 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-14 21:27:54 --> Helper loaded: url_helper
INFO - 2018-05-14 21:27:54 --> Helper loaded: form_helper
INFO - 2018-05-14 21:27:54 --> Helper loaded: date_helper
INFO - 2018-05-14 21:27:54 --> Helper loaded: util_helper
INFO - 2018-05-14 21:27:54 --> Helper loaded: text_helper
INFO - 2018-05-14 21:27:54 --> Helper loaded: string_helper
INFO - 2018-05-14 21:27:54 --> Database Driver Class Initialized
DEBUG - 2018-05-14 21:27:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-14 21:27:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-14 21:27:54 --> Email Class Initialized
INFO - 2018-05-14 21:27:54 --> Controller Class Initialized
DEBUG - 2018-05-14 21:27:55 --> videos MX_Controller Initialized
INFO - 2018-05-14 21:27:55 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-14 21:27:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-05-14 21:27:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-14 21:27:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-05-14 21:27:55 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-14 21:27:55 --> Login MX_Controller Initialized
DEBUG - 2018-05-14 21:27:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-14 21:27:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-05-14 21:27:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-05-14 21:27:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-05-14 21:27:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-05-14 21:27:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-05-14 21:27:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/videos/videos.php
INFO - 2018-05-14 21:27:55 --> Final output sent to browser
DEBUG - 2018-05-14 21:27:55 --> Total execution time: 0.9116
INFO - 2018-05-14 21:27:55 --> Config Class Initialized
INFO - 2018-05-14 21:27:55 --> Hooks Class Initialized
DEBUG - 2018-05-14 21:27:55 --> UTF-8 Support Enabled
INFO - 2018-05-14 21:27:56 --> Utf8 Class Initialized
INFO - 2018-05-14 21:27:56 --> URI Class Initialized
INFO - 2018-05-14 21:27:56 --> Router Class Initialized
INFO - 2018-05-14 21:27:56 --> Output Class Initialized
INFO - 2018-05-14 21:27:56 --> Security Class Initialized
DEBUG - 2018-05-14 21:27:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 21:27:56 --> Input Class Initialized
INFO - 2018-05-14 21:27:56 --> Language Class Initialized
INFO - 2018-05-14 21:27:56 --> Language Class Initialized
INFO - 2018-05-14 21:27:56 --> Config Class Initialized
INFO - 2018-05-14 21:27:56 --> Loader Class Initialized
DEBUG - 2018-05-14 21:27:56 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-14 21:27:56 --> Helper loaded: url_helper
INFO - 2018-05-14 21:27:56 --> Helper loaded: form_helper
INFO - 2018-05-14 21:27:56 --> Helper loaded: date_helper
INFO - 2018-05-14 21:27:56 --> Helper loaded: util_helper
INFO - 2018-05-14 21:27:56 --> Helper loaded: text_helper
INFO - 2018-05-14 21:27:56 --> Helper loaded: string_helper
INFO - 2018-05-14 21:27:56 --> Database Driver Class Initialized
DEBUG - 2018-05-14 21:27:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-14 21:27:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-14 21:27:56 --> Email Class Initialized
INFO - 2018-05-14 21:27:56 --> Controller Class Initialized
DEBUG - 2018-05-14 21:27:56 --> videos MX_Controller Initialized
INFO - 2018-05-14 21:27:56 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-14 21:27:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-05-14 21:27:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-14 21:27:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-05-14 21:27:56 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-14 21:27:56 --> Login MX_Controller Initialized
DEBUG - 2018-05-14 21:27:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-14 21:27:56 --> Final output sent to browser
DEBUG - 2018-05-14 21:27:56 --> Total execution time: 0.4733
INFO - 2018-05-14 21:36:06 --> Config Class Initialized
INFO - 2018-05-14 21:36:06 --> Hooks Class Initialized
DEBUG - 2018-05-14 21:36:06 --> UTF-8 Support Enabled
INFO - 2018-05-14 21:36:06 --> Utf8 Class Initialized
INFO - 2018-05-14 21:36:06 --> URI Class Initialized
INFO - 2018-05-14 21:36:06 --> Router Class Initialized
INFO - 2018-05-14 21:36:06 --> Output Class Initialized
INFO - 2018-05-14 21:36:06 --> Security Class Initialized
DEBUG - 2018-05-14 21:36:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 21:36:06 --> Input Class Initialized
INFO - 2018-05-14 21:36:06 --> Language Class Initialized
INFO - 2018-05-14 21:36:06 --> Language Class Initialized
INFO - 2018-05-14 21:36:06 --> Config Class Initialized
INFO - 2018-05-14 21:36:06 --> Loader Class Initialized
DEBUG - 2018-05-14 21:36:06 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-14 21:36:06 --> Helper loaded: url_helper
INFO - 2018-05-14 21:36:06 --> Helper loaded: form_helper
INFO - 2018-05-14 21:36:06 --> Helper loaded: date_helper
INFO - 2018-05-14 21:36:06 --> Helper loaded: util_helper
INFO - 2018-05-14 21:36:06 --> Helper loaded: text_helper
INFO - 2018-05-14 21:36:06 --> Helper loaded: string_helper
INFO - 2018-05-14 21:36:07 --> Database Driver Class Initialized
DEBUG - 2018-05-14 21:36:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-14 21:36:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-14 21:36:07 --> Email Class Initialized
INFO - 2018-05-14 21:36:07 --> Controller Class Initialized
DEBUG - 2018-05-14 21:36:07 --> videos MX_Controller Initialized
INFO - 2018-05-14 21:36:07 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-14 21:36:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-05-14 21:36:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-14 21:36:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-05-14 21:36:07 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-14 21:36:07 --> Login MX_Controller Initialized
DEBUG - 2018-05-14 21:36:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-14 21:36:07 --> Config Class Initialized
INFO - 2018-05-14 21:36:07 --> Hooks Class Initialized
INFO - 2018-05-14 21:36:07 --> Final output sent to browser
DEBUG - 2018-05-14 21:36:07 --> Total execution time: 0.4830
DEBUG - 2018-05-14 21:36:07 --> UTF-8 Support Enabled
INFO - 2018-05-14 21:36:07 --> Utf8 Class Initialized
INFO - 2018-05-14 21:36:07 --> URI Class Initialized
INFO - 2018-05-14 21:36:07 --> Router Class Initialized
INFO - 2018-05-14 21:36:07 --> Output Class Initialized
INFO - 2018-05-14 21:36:07 --> Security Class Initialized
DEBUG - 2018-05-14 21:36:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 21:36:07 --> Input Class Initialized
INFO - 2018-05-14 21:36:07 --> Language Class Initialized
INFO - 2018-05-14 21:36:07 --> Language Class Initialized
INFO - 2018-05-14 21:36:07 --> Config Class Initialized
INFO - 2018-05-14 21:36:07 --> Loader Class Initialized
DEBUG - 2018-05-14 21:36:07 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-14 21:36:07 --> Helper loaded: url_helper
INFO - 2018-05-14 21:36:07 --> Helper loaded: form_helper
INFO - 2018-05-14 21:36:07 --> Helper loaded: date_helper
INFO - 2018-05-14 21:36:07 --> Helper loaded: util_helper
INFO - 2018-05-14 21:36:07 --> Helper loaded: text_helper
INFO - 2018-05-14 21:36:07 --> Helper loaded: string_helper
INFO - 2018-05-14 21:36:07 --> Database Driver Class Initialized
DEBUG - 2018-05-14 21:36:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-14 21:36:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-14 21:36:07 --> Email Class Initialized
INFO - 2018-05-14 21:36:07 --> Controller Class Initialized
DEBUG - 2018-05-14 21:36:07 --> videos MX_Controller Initialized
INFO - 2018-05-14 21:36:07 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-14 21:36:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-05-14 21:36:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-14 21:36:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-05-14 21:36:07 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-14 21:36:07 --> Login MX_Controller Initialized
DEBUG - 2018-05-14 21:36:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-14 21:36:07 --> Final output sent to browser
DEBUG - 2018-05-14 21:36:07 --> Total execution time: 0.4312
INFO - 2018-05-14 21:36:09 --> Config Class Initialized
INFO - 2018-05-14 21:36:09 --> Hooks Class Initialized
DEBUG - 2018-05-14 21:36:09 --> UTF-8 Support Enabled
INFO - 2018-05-14 21:36:09 --> Utf8 Class Initialized
INFO - 2018-05-14 21:36:09 --> URI Class Initialized
INFO - 2018-05-14 21:36:09 --> Router Class Initialized
INFO - 2018-05-14 21:36:09 --> Output Class Initialized
INFO - 2018-05-14 21:36:09 --> Security Class Initialized
DEBUG - 2018-05-14 21:36:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 21:36:09 --> Input Class Initialized
INFO - 2018-05-14 21:36:09 --> Language Class Initialized
INFO - 2018-05-14 21:36:09 --> Language Class Initialized
INFO - 2018-05-14 21:36:09 --> Config Class Initialized
INFO - 2018-05-14 21:36:09 --> Loader Class Initialized
DEBUG - 2018-05-14 21:36:09 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-14 21:36:09 --> Helper loaded: url_helper
INFO - 2018-05-14 21:36:09 --> Helper loaded: form_helper
INFO - 2018-05-14 21:36:09 --> Helper loaded: date_helper
INFO - 2018-05-14 21:36:09 --> Helper loaded: util_helper
INFO - 2018-05-14 21:36:09 --> Helper loaded: text_helper
INFO - 2018-05-14 21:36:09 --> Helper loaded: string_helper
INFO - 2018-05-14 21:36:09 --> Database Driver Class Initialized
DEBUG - 2018-05-14 21:36:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-14 21:36:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-14 21:36:09 --> Email Class Initialized
INFO - 2018-05-14 21:36:09 --> Controller Class Initialized
DEBUG - 2018-05-14 21:36:09 --> videos MX_Controller Initialized
INFO - 2018-05-14 21:36:09 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-14 21:36:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-05-14 21:36:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-14 21:36:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-05-14 21:36:09 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-14 21:36:09 --> Login MX_Controller Initialized
DEBUG - 2018-05-14 21:36:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-14 21:36:09 --> Final output sent to browser
DEBUG - 2018-05-14 21:36:09 --> Total execution time: 0.4209
INFO - 2018-05-14 22:35:17 --> Config Class Initialized
INFO - 2018-05-14 22:35:17 --> Hooks Class Initialized
DEBUG - 2018-05-14 22:35:17 --> UTF-8 Support Enabled
INFO - 2018-05-14 22:35:17 --> Utf8 Class Initialized
INFO - 2018-05-14 22:35:17 --> URI Class Initialized
INFO - 2018-05-14 22:35:18 --> Router Class Initialized
INFO - 2018-05-14 22:35:18 --> Output Class Initialized
INFO - 2018-05-14 22:35:18 --> Security Class Initialized
DEBUG - 2018-05-14 22:35:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 22:35:18 --> Input Class Initialized
INFO - 2018-05-14 22:35:18 --> Language Class Initialized
INFO - 2018-05-14 22:35:18 --> Language Class Initialized
INFO - 2018-05-14 22:35:18 --> Config Class Initialized
INFO - 2018-05-14 22:35:18 --> Loader Class Initialized
DEBUG - 2018-05-14 22:35:18 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-14 22:35:18 --> Helper loaded: url_helper
INFO - 2018-05-14 22:35:18 --> Helper loaded: form_helper
INFO - 2018-05-14 22:35:18 --> Helper loaded: date_helper
INFO - 2018-05-14 22:35:18 --> Helper loaded: util_helper
INFO - 2018-05-14 22:35:18 --> Helper loaded: text_helper
INFO - 2018-05-14 22:35:18 --> Helper loaded: string_helper
INFO - 2018-05-14 22:35:18 --> Database Driver Class Initialized
DEBUG - 2018-05-14 22:35:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-14 22:35:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-14 22:35:18 --> Email Class Initialized
INFO - 2018-05-14 22:35:18 --> Controller Class Initialized
DEBUG - 2018-05-14 22:35:18 --> videos MX_Controller Initialized
INFO - 2018-05-14 22:35:18 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-14 22:35:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-05-14 22:35:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-14 22:35:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-05-14 22:35:18 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-14 22:35:18 --> Login MX_Controller Initialized
DEBUG - 2018-05-14 22:35:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-14 22:35:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-05-14 22:35:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-05-14 22:35:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-05-14 22:35:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-05-14 22:35:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-05-14 22:35:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/videos/videos.php
INFO - 2018-05-14 22:35:19 --> Final output sent to browser
DEBUG - 2018-05-14 22:35:19 --> Total execution time: 1.4227
INFO - 2018-05-14 22:35:19 --> Config Class Initialized
INFO - 2018-05-14 22:35:19 --> Hooks Class Initialized
DEBUG - 2018-05-14 22:35:19 --> UTF-8 Support Enabled
INFO - 2018-05-14 22:35:19 --> Utf8 Class Initialized
INFO - 2018-05-14 22:35:19 --> URI Class Initialized
INFO - 2018-05-14 22:35:19 --> Router Class Initialized
INFO - 2018-05-14 22:35:19 --> Output Class Initialized
INFO - 2018-05-14 22:35:19 --> Security Class Initialized
DEBUG - 2018-05-14 22:35:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 22:35:19 --> Input Class Initialized
INFO - 2018-05-14 22:35:19 --> Language Class Initialized
INFO - 2018-05-14 22:35:19 --> Language Class Initialized
INFO - 2018-05-14 22:35:19 --> Config Class Initialized
INFO - 2018-05-14 22:35:19 --> Loader Class Initialized
DEBUG - 2018-05-14 22:35:19 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-14 22:35:19 --> Helper loaded: url_helper
INFO - 2018-05-14 22:35:19 --> Helper loaded: form_helper
INFO - 2018-05-14 22:35:19 --> Helper loaded: date_helper
INFO - 2018-05-14 22:35:19 --> Helper loaded: util_helper
INFO - 2018-05-14 22:35:19 --> Helper loaded: text_helper
INFO - 2018-05-14 22:35:19 --> Helper loaded: string_helper
INFO - 2018-05-14 22:35:19 --> Database Driver Class Initialized
DEBUG - 2018-05-14 22:35:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-14 22:35:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-14 22:35:19 --> Email Class Initialized
INFO - 2018-05-14 22:35:19 --> Controller Class Initialized
DEBUG - 2018-05-14 22:35:19 --> Home MX_Controller Initialized
DEBUG - 2018-05-14 22:35:19 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-14 22:35:19 --> Login MX_Controller Initialized
INFO - 2018-05-14 22:35:19 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-14 22:35:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-14 22:35:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-14 22:35:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-05-14 22:35:19 --> Final output sent to browser
DEBUG - 2018-05-14 22:35:19 --> Total execution time: 0.4702
INFO - 2018-05-14 22:35:19 --> Config Class Initialized
INFO - 2018-05-14 22:35:19 --> Hooks Class Initialized
DEBUG - 2018-05-14 22:35:19 --> UTF-8 Support Enabled
INFO - 2018-05-14 22:35:19 --> Utf8 Class Initialized
INFO - 2018-05-14 22:35:19 --> URI Class Initialized
INFO - 2018-05-14 22:35:19 --> Router Class Initialized
INFO - 2018-05-14 22:35:19 --> Output Class Initialized
INFO - 2018-05-14 22:35:19 --> Security Class Initialized
DEBUG - 2018-05-14 22:35:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 22:35:20 --> Input Class Initialized
INFO - 2018-05-14 22:35:20 --> Language Class Initialized
ERROR - 2018-05-14 22:35:20 --> 404 Page Not Found: /index
INFO - 2018-05-14 22:35:20 --> Config Class Initialized
INFO - 2018-05-14 22:35:20 --> Hooks Class Initialized
DEBUG - 2018-05-14 22:35:20 --> UTF-8 Support Enabled
INFO - 2018-05-14 22:35:20 --> Utf8 Class Initialized
INFO - 2018-05-14 22:35:20 --> URI Class Initialized
INFO - 2018-05-14 22:35:20 --> Router Class Initialized
INFO - 2018-05-14 22:35:20 --> Output Class Initialized
INFO - 2018-05-14 22:35:20 --> Security Class Initialized
DEBUG - 2018-05-14 22:35:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 22:35:20 --> Input Class Initialized
INFO - 2018-05-14 22:35:20 --> Language Class Initialized
ERROR - 2018-05-14 22:35:20 --> 404 Page Not Found: /index
INFO - 2018-05-14 22:35:21 --> Config Class Initialized
INFO - 2018-05-14 22:35:21 --> Config Class Initialized
INFO - 2018-05-14 22:35:21 --> Config Class Initialized
INFO - 2018-05-14 22:35:21 --> Hooks Class Initialized
INFO - 2018-05-14 22:35:21 --> Hooks Class Initialized
INFO - 2018-05-14 22:35:21 --> Hooks Class Initialized
INFO - 2018-05-14 22:35:21 --> Config Class Initialized
DEBUG - 2018-05-14 22:35:21 --> UTF-8 Support Enabled
DEBUG - 2018-05-14 22:35:21 --> UTF-8 Support Enabled
INFO - 2018-05-14 22:35:21 --> Hooks Class Initialized
INFO - 2018-05-14 22:35:21 --> Config Class Initialized
INFO - 2018-05-14 22:35:21 --> Utf8 Class Initialized
INFO - 2018-05-14 22:35:21 --> Config Class Initialized
INFO - 2018-05-14 22:35:21 --> Hooks Class Initialized
INFO - 2018-05-14 22:35:21 --> Utf8 Class Initialized
INFO - 2018-05-14 22:35:21 --> Hooks Class Initialized
INFO - 2018-05-14 22:35:21 --> URI Class Initialized
DEBUG - 2018-05-14 22:35:21 --> UTF-8 Support Enabled
DEBUG - 2018-05-14 22:35:21 --> UTF-8 Support Enabled
INFO - 2018-05-14 22:35:21 --> Utf8 Class Initialized
DEBUG - 2018-05-14 22:35:21 --> UTF-8 Support Enabled
INFO - 2018-05-14 22:35:21 --> Router Class Initialized
INFO - 2018-05-14 22:35:21 --> URI Class Initialized
INFO - 2018-05-14 22:35:21 --> Utf8 Class Initialized
DEBUG - 2018-05-14 22:35:21 --> UTF-8 Support Enabled
INFO - 2018-05-14 22:35:21 --> Utf8 Class Initialized
INFO - 2018-05-14 22:35:21 --> Utf8 Class Initialized
INFO - 2018-05-14 22:35:21 --> URI Class Initialized
INFO - 2018-05-14 22:35:21 --> URI Class Initialized
INFO - 2018-05-14 22:35:21 --> Router Class Initialized
INFO - 2018-05-14 22:35:21 --> Output Class Initialized
INFO - 2018-05-14 22:35:21 --> URI Class Initialized
INFO - 2018-05-14 22:35:21 --> Output Class Initialized
INFO - 2018-05-14 22:35:21 --> Router Class Initialized
INFO - 2018-05-14 22:35:21 --> Router Class Initialized
INFO - 2018-05-14 22:35:21 --> URI Class Initialized
INFO - 2018-05-14 22:35:21 --> Security Class Initialized
INFO - 2018-05-14 22:35:21 --> Security Class Initialized
INFO - 2018-05-14 22:35:21 --> Router Class Initialized
INFO - 2018-05-14 22:35:21 --> Output Class Initialized
INFO - 2018-05-14 22:35:21 --> Output Class Initialized
DEBUG - 2018-05-14 22:35:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 22:35:21 --> Router Class Initialized
DEBUG - 2018-05-14 22:35:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 22:35:21 --> Output Class Initialized
INFO - 2018-05-14 22:35:21 --> Security Class Initialized
INFO - 2018-05-14 22:35:21 --> Output Class Initialized
INFO - 2018-05-14 22:35:21 --> Input Class Initialized
INFO - 2018-05-14 22:35:21 --> Security Class Initialized
INFO - 2018-05-14 22:35:21 --> Input Class Initialized
INFO - 2018-05-14 22:35:21 --> Language Class Initialized
INFO - 2018-05-14 22:35:21 --> Security Class Initialized
DEBUG - 2018-05-14 22:35:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 22:35:21 --> Security Class Initialized
DEBUG - 2018-05-14 22:35:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 22:35:21 --> Language Class Initialized
INFO - 2018-05-14 22:35:21 --> Input Class Initialized
DEBUG - 2018-05-14 22:35:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-05-14 22:35:21 --> 404 Page Not Found: /index
DEBUG - 2018-05-14 22:35:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 22:35:21 --> Input Class Initialized
INFO - 2018-05-14 22:35:21 --> Input Class Initialized
ERROR - 2018-05-14 22:35:21 --> 404 Page Not Found: /index
INFO - 2018-05-14 22:35:21 --> Language Class Initialized
INFO - 2018-05-14 22:35:21 --> Language Class Initialized
INFO - 2018-05-14 22:35:21 --> Language Class Initialized
INFO - 2018-05-14 22:35:21 --> Input Class Initialized
ERROR - 2018-05-14 22:35:21 --> 404 Page Not Found: /index
ERROR - 2018-05-14 22:35:21 --> 404 Page Not Found: /index
INFO - 2018-05-14 22:35:21 --> Language Class Initialized
ERROR - 2018-05-14 22:35:21 --> 404 Page Not Found: /index
ERROR - 2018-05-14 22:35:21 --> 404 Page Not Found: /index
INFO - 2018-05-14 22:35:21 --> Config Class Initialized
INFO - 2018-05-14 22:35:21 --> Config Class Initialized
INFO - 2018-05-14 22:35:21 --> Hooks Class Initialized
INFO - 2018-05-14 22:35:21 --> Config Class Initialized
INFO - 2018-05-14 22:35:21 --> Hooks Class Initialized
INFO - 2018-05-14 22:35:21 --> Hooks Class Initialized
DEBUG - 2018-05-14 22:35:21 --> UTF-8 Support Enabled
INFO - 2018-05-14 22:35:21 --> Utf8 Class Initialized
DEBUG - 2018-05-14 22:35:21 --> UTF-8 Support Enabled
INFO - 2018-05-14 22:35:21 --> Config Class Initialized
DEBUG - 2018-05-14 22:35:21 --> UTF-8 Support Enabled
INFO - 2018-05-14 22:35:21 --> URI Class Initialized
INFO - 2018-05-14 22:35:21 --> Config Class Initialized
INFO - 2018-05-14 22:35:21 --> Hooks Class Initialized
INFO - 2018-05-14 22:35:21 --> Hooks Class Initialized
INFO - 2018-05-14 22:35:21 --> Utf8 Class Initialized
INFO - 2018-05-14 22:35:21 --> Utf8 Class Initialized
INFO - 2018-05-14 22:35:21 --> Router Class Initialized
DEBUG - 2018-05-14 22:35:21 --> UTF-8 Support Enabled
INFO - 2018-05-14 22:35:21 --> URI Class Initialized
INFO - 2018-05-14 22:35:21 --> URI Class Initialized
INFO - 2018-05-14 22:35:21 --> Output Class Initialized
DEBUG - 2018-05-14 22:35:21 --> UTF-8 Support Enabled
INFO - 2018-05-14 22:35:21 --> Utf8 Class Initialized
INFO - 2018-05-14 22:35:21 --> Router Class Initialized
INFO - 2018-05-14 22:35:21 --> Router Class Initialized
INFO - 2018-05-14 22:35:21 --> Utf8 Class Initialized
INFO - 2018-05-14 22:35:21 --> Security Class Initialized
INFO - 2018-05-14 22:35:21 --> URI Class Initialized
INFO - 2018-05-14 22:35:21 --> Output Class Initialized
INFO - 2018-05-14 22:35:21 --> Output Class Initialized
DEBUG - 2018-05-14 22:35:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 22:35:21 --> URI Class Initialized
INFO - 2018-05-14 22:35:21 --> Router Class Initialized
INFO - 2018-05-14 22:35:21 --> Security Class Initialized
INFO - 2018-05-14 22:35:21 --> Output Class Initialized
INFO - 2018-05-14 22:35:21 --> Input Class Initialized
INFO - 2018-05-14 22:35:21 --> Security Class Initialized
INFO - 2018-05-14 22:35:21 --> Router Class Initialized
INFO - 2018-05-14 22:35:21 --> Output Class Initialized
INFO - 2018-05-14 22:35:21 --> Language Class Initialized
DEBUG - 2018-05-14 22:35:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 22:35:21 --> Security Class Initialized
DEBUG - 2018-05-14 22:35:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 22:35:21 --> Input Class Initialized
ERROR - 2018-05-14 22:35:21 --> 404 Page Not Found: /index
INFO - 2018-05-14 22:35:21 --> Input Class Initialized
INFO - 2018-05-14 22:35:21 --> Security Class Initialized
DEBUG - 2018-05-14 22:35:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 22:35:21 --> Language Class Initialized
DEBUG - 2018-05-14 22:35:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 22:35:21 --> Input Class Initialized
INFO - 2018-05-14 22:35:21 --> Language Class Initialized
INFO - 2018-05-14 22:35:21 --> Input Class Initialized
ERROR - 2018-05-14 22:35:21 --> 404 Page Not Found: /index
ERROR - 2018-05-14 22:35:21 --> 404 Page Not Found: /index
INFO - 2018-05-14 22:35:21 --> Language Class Initialized
INFO - 2018-05-14 22:35:21 --> Language Class Initialized
ERROR - 2018-05-14 22:35:21 --> 404 Page Not Found: /index
ERROR - 2018-05-14 22:35:21 --> 404 Page Not Found: /index
INFO - 2018-05-14 22:35:21 --> Config Class Initialized
INFO - 2018-05-14 22:35:21 --> Config Class Initialized
INFO - 2018-05-14 22:35:21 --> Hooks Class Initialized
INFO - 2018-05-14 22:35:21 --> Hooks Class Initialized
DEBUG - 2018-05-14 22:35:21 --> UTF-8 Support Enabled
INFO - 2018-05-14 22:35:21 --> Config Class Initialized
INFO - 2018-05-14 22:35:21 --> Hooks Class Initialized
INFO - 2018-05-14 22:35:21 --> Utf8 Class Initialized
DEBUG - 2018-05-14 22:35:21 --> UTF-8 Support Enabled
INFO - 2018-05-14 22:35:21 --> Utf8 Class Initialized
INFO - 2018-05-14 22:35:21 --> URI Class Initialized
DEBUG - 2018-05-14 22:35:21 --> UTF-8 Support Enabled
INFO - 2018-05-14 22:35:21 --> Utf8 Class Initialized
INFO - 2018-05-14 22:35:21 --> URI Class Initialized
INFO - 2018-05-14 22:35:21 --> Router Class Initialized
INFO - 2018-05-14 22:35:21 --> URI Class Initialized
INFO - 2018-05-14 22:35:21 --> Output Class Initialized
INFO - 2018-05-14 22:35:21 --> Router Class Initialized
INFO - 2018-05-14 22:35:21 --> Router Class Initialized
INFO - 2018-05-14 22:35:21 --> Config Class Initialized
INFO - 2018-05-14 22:35:21 --> Hooks Class Initialized
INFO - 2018-05-14 22:35:21 --> Security Class Initialized
INFO - 2018-05-14 22:35:21 --> Output Class Initialized
INFO - 2018-05-14 22:35:21 --> Output Class Initialized
INFO - 2018-05-14 22:35:21 --> Config Class Initialized
INFO - 2018-05-14 22:35:21 --> Security Class Initialized
INFO - 2018-05-14 22:35:21 --> Hooks Class Initialized
DEBUG - 2018-05-14 22:35:21 --> UTF-8 Support Enabled
INFO - 2018-05-14 22:35:21 --> Security Class Initialized
DEBUG - 2018-05-14 22:35:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 22:35:21 --> Input Class Initialized
INFO - 2018-05-14 22:35:21 --> Utf8 Class Initialized
DEBUG - 2018-05-14 22:35:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-14 22:35:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-14 22:35:21 --> UTF-8 Support Enabled
INFO - 2018-05-14 22:35:21 --> Input Class Initialized
INFO - 2018-05-14 22:35:21 --> Input Class Initialized
INFO - 2018-05-14 22:35:21 --> Utf8 Class Initialized
INFO - 2018-05-14 22:35:21 --> Language Class Initialized
INFO - 2018-05-14 22:35:21 --> URI Class Initialized
INFO - 2018-05-14 22:35:21 --> Language Class Initialized
INFO - 2018-05-14 22:35:21 --> Language Class Initialized
INFO - 2018-05-14 22:35:21 --> URI Class Initialized
ERROR - 2018-05-14 22:35:21 --> 404 Page Not Found: /index
INFO - 2018-05-14 22:35:21 --> Router Class Initialized
ERROR - 2018-05-14 22:35:21 --> 404 Page Not Found: /index
INFO - 2018-05-14 22:35:21 --> Language Class Initialized
INFO - 2018-05-14 22:35:21 --> Router Class Initialized
INFO - 2018-05-14 22:35:21 --> Config Class Initialized
INFO - 2018-05-14 22:35:21 --> Output Class Initialized
INFO - 2018-05-14 22:35:21 --> Config Class Initialized
INFO - 2018-05-14 22:35:21 --> Output Class Initialized
INFO - 2018-05-14 22:35:21 --> Security Class Initialized
INFO - 2018-05-14 22:35:21 --> Hooks Class Initialized
INFO - 2018-05-14 22:35:21 --> Security Class Initialized
INFO - 2018-05-14 22:35:21 --> Loader Class Initialized
DEBUG - 2018-05-14 22:35:21 --> UTF-8 Support Enabled
DEBUG - 2018-05-14 22:35:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-14 22:35:21 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
DEBUG - 2018-05-14 22:35:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 22:35:21 --> Input Class Initialized
INFO - 2018-05-14 22:35:21 --> Utf8 Class Initialized
INFO - 2018-05-14 22:35:21 --> Input Class Initialized
INFO - 2018-05-14 22:35:21 --> Helper loaded: url_helper
INFO - 2018-05-14 22:35:21 --> URI Class Initialized
INFO - 2018-05-14 22:35:21 --> Language Class Initialized
INFO - 2018-05-14 22:35:21 --> Language Class Initialized
ERROR - 2018-05-14 22:35:21 --> 404 Page Not Found: /index
ERROR - 2018-05-14 22:35:21 --> 404 Page Not Found: /index
INFO - 2018-05-14 22:35:21 --> Helper loaded: form_helper
INFO - 2018-05-14 22:35:21 --> Helper loaded: date_helper
INFO - 2018-05-14 22:35:21 --> Helper loaded: util_helper
INFO - 2018-05-14 22:35:21 --> Helper loaded: text_helper
INFO - 2018-05-14 22:35:21 --> Helper loaded: string_helper
INFO - 2018-05-14 22:35:21 --> Database Driver Class Initialized
INFO - 2018-05-14 22:35:21 --> Router Class Initialized
INFO - 2018-05-14 22:35:21 --> Output Class Initialized
DEBUG - 2018-05-14 22:35:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-14 22:35:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-14 22:35:21 --> Security Class Initialized
INFO - 2018-05-14 22:35:21 --> Email Class Initialized
INFO - 2018-05-14 22:35:21 --> Controller Class Initialized
DEBUG - 2018-05-14 22:35:21 --> videos MX_Controller Initialized
INFO - 2018-05-14 22:35:21 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-14 22:35:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-05-14 22:35:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-14 22:35:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-05-14 22:35:22 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-14 22:35:22 --> Login MX_Controller Initialized
DEBUG - 2018-05-14 22:35:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-14 22:35:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 22:35:22 --> Input Class Initialized
INFO - 2018-05-14 22:35:22 --> Language Class Initialized
ERROR - 2018-05-14 22:35:22 --> 404 Page Not Found: /index
INFO - 2018-05-14 22:35:22 --> Final output sent to browser
DEBUG - 2018-05-14 22:35:22 --> Total execution time: 0.4719
INFO - 2018-05-14 22:35:22 --> Config Class Initialized
INFO - 2018-05-14 22:35:22 --> Hooks Class Initialized
DEBUG - 2018-05-14 22:35:22 --> UTF-8 Support Enabled
INFO - 2018-05-14 22:35:22 --> Utf8 Class Initialized
INFO - 2018-05-14 22:35:22 --> URI Class Initialized
INFO - 2018-05-14 22:35:22 --> Router Class Initialized
INFO - 2018-05-14 22:35:22 --> Output Class Initialized
INFO - 2018-05-14 22:35:22 --> Security Class Initialized
DEBUG - 2018-05-14 22:35:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 22:35:22 --> Input Class Initialized
INFO - 2018-05-14 22:35:22 --> Language Class Initialized
ERROR - 2018-05-14 22:35:22 --> 404 Page Not Found: /index
INFO - 2018-05-14 22:35:22 --> Config Class Initialized
INFO - 2018-05-14 22:35:22 --> Hooks Class Initialized
DEBUG - 2018-05-14 22:35:22 --> UTF-8 Support Enabled
INFO - 2018-05-14 22:35:22 --> Utf8 Class Initialized
INFO - 2018-05-14 22:35:22 --> URI Class Initialized
INFO - 2018-05-14 22:35:22 --> Router Class Initialized
INFO - 2018-05-14 22:35:22 --> Output Class Initialized
INFO - 2018-05-14 22:35:22 --> Security Class Initialized
DEBUG - 2018-05-14 22:35:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 22:35:23 --> Input Class Initialized
INFO - 2018-05-14 22:35:23 --> Language Class Initialized
ERROR - 2018-05-14 22:35:23 --> 404 Page Not Found: /index
INFO - 2018-05-14 22:35:23 --> Config Class Initialized
INFO - 2018-05-14 22:35:23 --> Hooks Class Initialized
DEBUG - 2018-05-14 22:35:23 --> UTF-8 Support Enabled
INFO - 2018-05-14 22:35:23 --> Utf8 Class Initialized
INFO - 2018-05-14 22:35:23 --> URI Class Initialized
INFO - 2018-05-14 22:35:23 --> Router Class Initialized
INFO - 2018-05-14 22:35:23 --> Output Class Initialized
INFO - 2018-05-14 22:35:23 --> Security Class Initialized
DEBUG - 2018-05-14 22:35:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 22:35:23 --> Input Class Initialized
INFO - 2018-05-14 22:35:23 --> Language Class Initialized
ERROR - 2018-05-14 22:35:23 --> 404 Page Not Found: /index
INFO - 2018-05-14 22:35:24 --> Config Class Initialized
INFO - 2018-05-14 22:35:24 --> Hooks Class Initialized
DEBUG - 2018-05-14 22:35:24 --> UTF-8 Support Enabled
INFO - 2018-05-14 22:35:24 --> Utf8 Class Initialized
INFO - 2018-05-14 22:35:24 --> URI Class Initialized
INFO - 2018-05-14 22:35:24 --> Router Class Initialized
INFO - 2018-05-14 22:35:24 --> Output Class Initialized
INFO - 2018-05-14 22:35:24 --> Security Class Initialized
DEBUG - 2018-05-14 22:35:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 22:35:24 --> Input Class Initialized
INFO - 2018-05-14 22:35:24 --> Language Class Initialized
ERROR - 2018-05-14 22:35:24 --> 404 Page Not Found: /index
INFO - 2018-05-14 22:35:24 --> Config Class Initialized
INFO - 2018-05-14 22:35:24 --> Hooks Class Initialized
INFO - 2018-05-14 22:35:24 --> Config Class Initialized
INFO - 2018-05-14 22:35:24 --> Config Class Initialized
INFO - 2018-05-14 22:35:24 --> Config Class Initialized
INFO - 2018-05-14 22:35:24 --> Config Class Initialized
DEBUG - 2018-05-14 22:35:24 --> UTF-8 Support Enabled
INFO - 2018-05-14 22:35:24 --> Hooks Class Initialized
INFO - 2018-05-14 22:35:24 --> Hooks Class Initialized
INFO - 2018-05-14 22:35:24 --> Hooks Class Initialized
INFO - 2018-05-14 22:35:24 --> Hooks Class Initialized
INFO - 2018-05-14 22:35:24 --> Utf8 Class Initialized
DEBUG - 2018-05-14 22:35:24 --> UTF-8 Support Enabled
INFO - 2018-05-14 22:35:24 --> Utf8 Class Initialized
INFO - 2018-05-14 22:35:24 --> URI Class Initialized
INFO - 2018-05-14 22:35:24 --> Router Class Initialized
INFO - 2018-05-14 22:35:24 --> Output Class Initialized
INFO - 2018-05-14 22:35:24 --> Security Class Initialized
DEBUG - 2018-05-14 22:35:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 22:35:24 --> Input Class Initialized
INFO - 2018-05-14 22:35:24 --> Language Class Initialized
ERROR - 2018-05-14 22:35:24 --> 404 Page Not Found: /index
INFO - 2018-05-14 22:35:24 --> Config Class Initialized
INFO - 2018-05-14 22:35:24 --> Hooks Class Initialized
DEBUG - 2018-05-14 22:35:24 --> UTF-8 Support Enabled
DEBUG - 2018-05-14 22:35:24 --> UTF-8 Support Enabled
DEBUG - 2018-05-14 22:35:24 --> UTF-8 Support Enabled
DEBUG - 2018-05-14 22:35:24 --> UTF-8 Support Enabled
INFO - 2018-05-14 22:35:24 --> URI Class Initialized
INFO - 2018-05-14 22:35:24 --> Utf8 Class Initialized
INFO - 2018-05-14 22:35:24 --> URI Class Initialized
INFO - 2018-05-14 22:35:24 --> Router Class Initialized
INFO - 2018-05-14 22:35:24 --> Output Class Initialized
INFO - 2018-05-14 22:35:24 --> Security Class Initialized
DEBUG - 2018-05-14 22:35:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 22:35:24 --> Input Class Initialized
INFO - 2018-05-14 22:35:25 --> Language Class Initialized
ERROR - 2018-05-14 22:35:25 --> 404 Page Not Found: /index
INFO - 2018-05-14 22:35:25 --> Utf8 Class Initialized
INFO - 2018-05-14 22:35:25 --> Config Class Initialized
INFO - 2018-05-14 22:35:25 --> Utf8 Class Initialized
INFO - 2018-05-14 22:35:25 --> Utf8 Class Initialized
INFO - 2018-05-14 22:35:25 --> Router Class Initialized
INFO - 2018-05-14 22:35:25 --> URI Class Initialized
INFO - 2018-05-14 22:35:25 --> Router Class Initialized
INFO - 2018-05-14 22:35:25 --> Output Class Initialized
INFO - 2018-05-14 22:35:25 --> Security Class Initialized
DEBUG - 2018-05-14 22:35:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 22:35:25 --> Input Class Initialized
INFO - 2018-05-14 22:35:25 --> Language Class Initialized
ERROR - 2018-05-14 22:35:25 --> 404 Page Not Found: /index
INFO - 2018-05-14 22:35:25 --> Config Class Initialized
INFO - 2018-05-14 22:35:25 --> Hooks Class Initialized
DEBUG - 2018-05-14 22:35:25 --> UTF-8 Support Enabled
INFO - 2018-05-14 22:35:25 --> Utf8 Class Initialized
INFO - 2018-05-14 22:35:25 --> URI Class Initialized
INFO - 2018-05-14 22:35:25 --> Hooks Class Initialized
INFO - 2018-05-14 22:35:25 --> URI Class Initialized
INFO - 2018-05-14 22:35:25 --> URI Class Initialized
INFO - 2018-05-14 22:35:25 --> Output Class Initialized
INFO - 2018-05-14 22:35:25 --> Router Class Initialized
INFO - 2018-05-14 22:35:25 --> Output Class Initialized
INFO - 2018-05-14 22:35:25 --> Security Class Initialized
DEBUG - 2018-05-14 22:35:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 22:35:25 --> Input Class Initialized
INFO - 2018-05-14 22:35:25 --> Language Class Initialized
INFO - 2018-05-14 22:35:25 --> Security Class Initialized
ERROR - 2018-05-14 22:35:25 --> 404 Page Not Found: /index
INFO - 2018-05-14 22:35:25 --> Router Class Initialized
INFO - 2018-05-14 22:35:25 --> Router Class Initialized
DEBUG - 2018-05-14 22:35:25 --> UTF-8 Support Enabled
DEBUG - 2018-05-14 22:35:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 22:35:25 --> Utf8 Class Initialized
INFO - 2018-05-14 22:35:25 --> Config Class Initialized
INFO - 2018-05-14 22:35:25 --> Output Class Initialized
INFO - 2018-05-14 22:35:25 --> Output Class Initialized
INFO - 2018-05-14 22:35:25 --> Hooks Class Initialized
INFO - 2018-05-14 22:35:25 --> URI Class Initialized
INFO - 2018-05-14 22:35:25 --> Input Class Initialized
INFO - 2018-05-14 22:35:25 --> Security Class Initialized
INFO - 2018-05-14 22:35:25 --> Security Class Initialized
DEBUG - 2018-05-14 22:35:25 --> UTF-8 Support Enabled
INFO - 2018-05-14 22:35:25 --> Language Class Initialized
INFO - 2018-05-14 22:35:25 --> Router Class Initialized
DEBUG - 2018-05-14 22:35:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-14 22:35:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 22:35:25 --> Utf8 Class Initialized
INFO - 2018-05-14 22:35:25 --> URI Class Initialized
ERROR - 2018-05-14 22:35:25 --> 404 Page Not Found: /index
INFO - 2018-05-14 22:35:25 --> Input Class Initialized
INFO - 2018-05-14 22:35:25 --> Input Class Initialized
INFO - 2018-05-14 22:35:25 --> Router Class Initialized
INFO - 2018-05-14 22:35:25 --> Output Class Initialized
INFO - 2018-05-14 22:35:25 --> Output Class Initialized
INFO - 2018-05-14 22:35:25 --> Language Class Initialized
INFO - 2018-05-14 22:35:25 --> Language Class Initialized
INFO - 2018-05-14 22:35:25 --> Security Class Initialized
DEBUG - 2018-05-14 22:35:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 22:35:25 --> Security Class Initialized
ERROR - 2018-05-14 22:35:25 --> 404 Page Not Found: /index
ERROR - 2018-05-14 22:35:25 --> 404 Page Not Found: /index
INFO - 2018-05-14 22:35:25 --> Input Class Initialized
INFO - 2018-05-14 22:35:25 --> Language Class Initialized
DEBUG - 2018-05-14 22:35:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-05-14 22:35:25 --> 404 Page Not Found: /index
INFO - 2018-05-14 22:35:25 --> Input Class Initialized
INFO - 2018-05-14 22:35:25 --> Language Class Initialized
ERROR - 2018-05-14 22:35:25 --> 404 Page Not Found: /index
INFO - 2018-05-14 22:35:25 --> Config Class Initialized
INFO - 2018-05-14 22:35:25 --> Hooks Class Initialized
INFO - 2018-05-14 22:35:25 --> Config Class Initialized
INFO - 2018-05-14 22:35:25 --> Hooks Class Initialized
DEBUG - 2018-05-14 22:35:25 --> UTF-8 Support Enabled
INFO - 2018-05-14 22:35:25 --> Utf8 Class Initialized
DEBUG - 2018-05-14 22:35:25 --> UTF-8 Support Enabled
INFO - 2018-05-14 22:35:25 --> Utf8 Class Initialized
INFO - 2018-05-14 22:35:25 --> URI Class Initialized
INFO - 2018-05-14 22:35:25 --> URI Class Initialized
INFO - 2018-05-14 22:35:25 --> Config Class Initialized
INFO - 2018-05-14 22:35:25 --> Router Class Initialized
INFO - 2018-05-14 22:35:25 --> Config Class Initialized
INFO - 2018-05-14 22:35:25 --> Router Class Initialized
INFO - 2018-05-14 22:35:25 --> Config Class Initialized
INFO - 2018-05-14 22:35:25 --> Hooks Class Initialized
INFO - 2018-05-14 22:35:25 --> Hooks Class Initialized
INFO - 2018-05-14 22:35:25 --> Output Class Initialized
INFO - 2018-05-14 22:35:25 --> Output Class Initialized
INFO - 2018-05-14 22:35:25 --> Hooks Class Initialized
INFO - 2018-05-14 22:35:25 --> Security Class Initialized
DEBUG - 2018-05-14 22:35:25 --> UTF-8 Support Enabled
DEBUG - 2018-05-14 22:35:25 --> UTF-8 Support Enabled
DEBUG - 2018-05-14 22:35:25 --> UTF-8 Support Enabled
INFO - 2018-05-14 22:35:25 --> Security Class Initialized
INFO - 2018-05-14 22:35:25 --> Utf8 Class Initialized
INFO - 2018-05-14 22:35:25 --> Utf8 Class Initialized
INFO - 2018-05-14 22:35:25 --> Utf8 Class Initialized
DEBUG - 2018-05-14 22:35:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-14 22:35:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 22:35:25 --> Input Class Initialized
INFO - 2018-05-14 22:35:25 --> URI Class Initialized
INFO - 2018-05-14 22:35:25 --> URI Class Initialized
INFO - 2018-05-14 22:35:25 --> Input Class Initialized
INFO - 2018-05-14 22:35:25 --> URI Class Initialized
INFO - 2018-05-14 22:35:25 --> Language Class Initialized
INFO - 2018-05-14 22:35:25 --> Router Class Initialized
INFO - 2018-05-14 22:35:25 --> Router Class Initialized
INFO - 2018-05-14 22:35:25 --> Language Class Initialized
INFO - 2018-05-14 22:35:25 --> Router Class Initialized
ERROR - 2018-05-14 22:35:25 --> 404 Page Not Found: /index
INFO - 2018-05-14 22:35:25 --> Output Class Initialized
INFO - 2018-05-14 22:35:25 --> Output Class Initialized
INFO - 2018-05-14 22:35:25 --> Output Class Initialized
ERROR - 2018-05-14 22:35:25 --> 404 Page Not Found: /index
INFO - 2018-05-14 22:35:25 --> Security Class Initialized
INFO - 2018-05-14 22:35:25 --> Security Class Initialized
INFO - 2018-05-14 22:35:25 --> Security Class Initialized
DEBUG - 2018-05-14 22:35:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-14 22:35:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-14 22:35:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 22:35:25 --> Input Class Initialized
INFO - 2018-05-14 22:35:25 --> Input Class Initialized
INFO - 2018-05-14 22:35:25 --> Input Class Initialized
INFO - 2018-05-14 22:35:25 --> Language Class Initialized
ERROR - 2018-05-14 22:35:25 --> 404 Page Not Found: /index
INFO - 2018-05-14 22:35:25 --> Language Class Initialized
INFO - 2018-05-14 22:35:25 --> Language Class Initialized
ERROR - 2018-05-14 22:35:26 --> 404 Page Not Found: /index
ERROR - 2018-05-14 22:35:26 --> 404 Page Not Found: /index
INFO - 2018-05-14 22:35:26 --> Config Class Initialized
INFO - 2018-05-14 22:35:26 --> Config Class Initialized
INFO - 2018-05-14 22:35:26 --> Hooks Class Initialized
INFO - 2018-05-14 22:35:26 --> Hooks Class Initialized
DEBUG - 2018-05-14 22:35:26 --> UTF-8 Support Enabled
INFO - 2018-05-14 22:35:26 --> Utf8 Class Initialized
DEBUG - 2018-05-14 22:35:26 --> UTF-8 Support Enabled
INFO - 2018-05-14 22:35:26 --> Utf8 Class Initialized
INFO - 2018-05-14 22:35:26 --> URI Class Initialized
INFO - 2018-05-14 22:35:26 --> Router Class Initialized
INFO - 2018-05-14 22:35:26 --> Output Class Initialized
INFO - 2018-05-14 22:35:26 --> URI Class Initialized
INFO - 2018-05-14 22:35:26 --> Security Class Initialized
DEBUG - 2018-05-14 22:35:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 22:35:26 --> Input Class Initialized
INFO - 2018-05-14 22:35:26 --> Language Class Initialized
ERROR - 2018-05-14 22:35:26 --> 404 Page Not Found: /index
INFO - 2018-05-14 22:35:26 --> Router Class Initialized
INFO - 2018-05-14 22:35:26 --> Output Class Initialized
INFO - 2018-05-14 22:35:26 --> Security Class Initialized
DEBUG - 2018-05-14 22:35:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 22:35:26 --> Input Class Initialized
INFO - 2018-05-14 22:35:26 --> Language Class Initialized
ERROR - 2018-05-14 22:35:26 --> 404 Page Not Found: /index
INFO - 2018-05-14 23:22:05 --> Config Class Initialized
INFO - 2018-05-14 23:22:05 --> Hooks Class Initialized
DEBUG - 2018-05-14 23:22:05 --> UTF-8 Support Enabled
INFO - 2018-05-14 23:22:05 --> Utf8 Class Initialized
INFO - 2018-05-14 23:22:05 --> URI Class Initialized
INFO - 2018-05-14 23:22:05 --> Router Class Initialized
INFO - 2018-05-14 23:22:05 --> Output Class Initialized
INFO - 2018-05-14 23:22:05 --> Security Class Initialized
DEBUG - 2018-05-14 23:22:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 23:22:05 --> Input Class Initialized
INFO - 2018-05-14 23:22:05 --> Language Class Initialized
INFO - 2018-05-14 23:22:05 --> Language Class Initialized
INFO - 2018-05-14 23:22:05 --> Config Class Initialized
INFO - 2018-05-14 23:22:05 --> Loader Class Initialized
DEBUG - 2018-05-14 23:22:05 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-14 23:22:05 --> Helper loaded: url_helper
INFO - 2018-05-14 23:22:05 --> Helper loaded: form_helper
INFO - 2018-05-14 23:22:05 --> Helper loaded: date_helper
INFO - 2018-05-14 23:22:05 --> Helper loaded: util_helper
INFO - 2018-05-14 23:22:05 --> Helper loaded: text_helper
INFO - 2018-05-14 23:22:05 --> Helper loaded: string_helper
INFO - 2018-05-14 23:22:05 --> Database Driver Class Initialized
DEBUG - 2018-05-14 23:22:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-14 23:22:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-14 23:22:05 --> Email Class Initialized
INFO - 2018-05-14 23:22:05 --> Controller Class Initialized
DEBUG - 2018-05-14 23:22:05 --> videos MX_Controller Initialized
INFO - 2018-05-14 23:22:05 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-14 23:22:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-05-14 23:22:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-14 23:22:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-05-14 23:22:05 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-14 23:22:05 --> Login MX_Controller Initialized
DEBUG - 2018-05-14 23:22:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-14 23:22:05 --> Final output sent to browser
DEBUG - 2018-05-14 23:22:05 --> Total execution time: 0.4031
INFO - 2018-05-14 23:22:06 --> Config Class Initialized
INFO - 2018-05-14 23:22:06 --> Hooks Class Initialized
DEBUG - 2018-05-14 23:22:06 --> UTF-8 Support Enabled
INFO - 2018-05-14 23:22:06 --> Utf8 Class Initialized
INFO - 2018-05-14 23:22:06 --> URI Class Initialized
INFO - 2018-05-14 23:22:06 --> Router Class Initialized
INFO - 2018-05-14 23:22:06 --> Output Class Initialized
INFO - 2018-05-14 23:22:06 --> Security Class Initialized
DEBUG - 2018-05-14 23:22:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 23:22:06 --> Input Class Initialized
INFO - 2018-05-14 23:22:06 --> Language Class Initialized
INFO - 2018-05-14 23:22:06 --> Language Class Initialized
INFO - 2018-05-14 23:22:06 --> Config Class Initialized
INFO - 2018-05-14 23:22:06 --> Loader Class Initialized
DEBUG - 2018-05-14 23:22:06 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-14 23:22:06 --> Helper loaded: url_helper
INFO - 2018-05-14 23:22:06 --> Helper loaded: form_helper
INFO - 2018-05-14 23:22:06 --> Helper loaded: date_helper
INFO - 2018-05-14 23:22:06 --> Helper loaded: util_helper
INFO - 2018-05-14 23:22:06 --> Helper loaded: text_helper
INFO - 2018-05-14 23:22:06 --> Helper loaded: string_helper
INFO - 2018-05-14 23:22:06 --> Database Driver Class Initialized
DEBUG - 2018-05-14 23:22:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-14 23:22:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-14 23:22:06 --> Email Class Initialized
INFO - 2018-05-14 23:22:06 --> Controller Class Initialized
DEBUG - 2018-05-14 23:22:06 --> videos MX_Controller Initialized
INFO - 2018-05-14 23:22:06 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-14 23:22:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-05-14 23:22:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-14 23:22:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-05-14 23:22:06 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-14 23:22:06 --> Login MX_Controller Initialized
DEBUG - 2018-05-14 23:22:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-14 23:22:06 --> Final output sent to browser
DEBUG - 2018-05-14 23:22:06 --> Total execution time: 0.4194
INFO - 2018-05-14 23:24:08 --> Config Class Initialized
INFO - 2018-05-14 23:24:08 --> Hooks Class Initialized
DEBUG - 2018-05-14 23:24:08 --> UTF-8 Support Enabled
INFO - 2018-05-14 23:24:08 --> Utf8 Class Initialized
INFO - 2018-05-14 23:24:08 --> URI Class Initialized
INFO - 2018-05-14 23:24:08 --> Router Class Initialized
INFO - 2018-05-14 23:24:08 --> Output Class Initialized
INFO - 2018-05-14 23:24:08 --> Security Class Initialized
DEBUG - 2018-05-14 23:24:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 23:24:08 --> Input Class Initialized
INFO - 2018-05-14 23:24:08 --> Language Class Initialized
INFO - 2018-05-14 23:24:08 --> Language Class Initialized
INFO - 2018-05-14 23:24:08 --> Config Class Initialized
INFO - 2018-05-14 23:24:08 --> Loader Class Initialized
DEBUG - 2018-05-14 23:24:08 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-14 23:24:08 --> Helper loaded: url_helper
INFO - 2018-05-14 23:24:08 --> Helper loaded: form_helper
INFO - 2018-05-14 23:24:08 --> Helper loaded: date_helper
INFO - 2018-05-14 23:24:08 --> Helper loaded: util_helper
INFO - 2018-05-14 23:24:08 --> Helper loaded: text_helper
INFO - 2018-05-14 23:24:08 --> Helper loaded: string_helper
INFO - 2018-05-14 23:24:08 --> Database Driver Class Initialized
DEBUG - 2018-05-14 23:24:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-14 23:24:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-14 23:24:08 --> Email Class Initialized
INFO - 2018-05-14 23:24:08 --> Controller Class Initialized
DEBUG - 2018-05-14 23:24:08 --> videos MX_Controller Initialized
INFO - 2018-05-14 23:24:08 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-14 23:24:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-05-14 23:24:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-14 23:24:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-05-14 23:24:08 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-14 23:24:08 --> Login MX_Controller Initialized
DEBUG - 2018-05-14 23:24:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-14 23:24:08 --> Final output sent to browser
DEBUG - 2018-05-14 23:24:08 --> Total execution time: 0.3707
INFO - 2018-05-14 23:24:09 --> Config Class Initialized
INFO - 2018-05-14 23:24:09 --> Hooks Class Initialized
DEBUG - 2018-05-14 23:24:09 --> UTF-8 Support Enabled
INFO - 2018-05-14 23:24:09 --> Utf8 Class Initialized
INFO - 2018-05-14 23:24:09 --> URI Class Initialized
INFO - 2018-05-14 23:24:09 --> Router Class Initialized
INFO - 2018-05-14 23:24:09 --> Output Class Initialized
INFO - 2018-05-14 23:24:09 --> Security Class Initialized
DEBUG - 2018-05-14 23:24:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 23:24:09 --> Input Class Initialized
INFO - 2018-05-14 23:24:09 --> Language Class Initialized
INFO - 2018-05-14 23:24:09 --> Language Class Initialized
INFO - 2018-05-14 23:24:09 --> Config Class Initialized
INFO - 2018-05-14 23:24:09 --> Loader Class Initialized
DEBUG - 2018-05-14 23:24:09 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-14 23:24:09 --> Helper loaded: url_helper
INFO - 2018-05-14 23:24:09 --> Helper loaded: form_helper
INFO - 2018-05-14 23:24:09 --> Helper loaded: date_helper
INFO - 2018-05-14 23:24:09 --> Helper loaded: util_helper
INFO - 2018-05-14 23:24:09 --> Helper loaded: text_helper
INFO - 2018-05-14 23:24:09 --> Helper loaded: string_helper
INFO - 2018-05-14 23:24:09 --> Database Driver Class Initialized
DEBUG - 2018-05-14 23:24:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-14 23:24:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-14 23:24:09 --> Email Class Initialized
INFO - 2018-05-14 23:24:09 --> Controller Class Initialized
DEBUG - 2018-05-14 23:24:09 --> videos MX_Controller Initialized
INFO - 2018-05-14 23:24:09 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-14 23:24:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-05-14 23:24:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-14 23:24:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-05-14 23:24:09 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-14 23:24:09 --> Login MX_Controller Initialized
DEBUG - 2018-05-14 23:24:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-14 23:24:09 --> Final output sent to browser
DEBUG - 2018-05-14 23:24:09 --> Total execution time: 0.3632
INFO - 2018-05-14 23:24:09 --> Config Class Initialized
INFO - 2018-05-14 23:24:09 --> Hooks Class Initialized
DEBUG - 2018-05-14 23:24:09 --> UTF-8 Support Enabled
INFO - 2018-05-14 23:24:09 --> Utf8 Class Initialized
INFO - 2018-05-14 23:24:09 --> URI Class Initialized
INFO - 2018-05-14 23:24:09 --> Router Class Initialized
INFO - 2018-05-14 23:24:09 --> Output Class Initialized
INFO - 2018-05-14 23:24:10 --> Security Class Initialized
DEBUG - 2018-05-14 23:24:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 23:24:10 --> Input Class Initialized
INFO - 2018-05-14 23:24:10 --> Language Class Initialized
INFO - 2018-05-14 23:24:10 --> Language Class Initialized
INFO - 2018-05-14 23:24:10 --> Config Class Initialized
INFO - 2018-05-14 23:24:10 --> Loader Class Initialized
DEBUG - 2018-05-14 23:24:10 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-14 23:24:10 --> Helper loaded: url_helper
INFO - 2018-05-14 23:24:10 --> Helper loaded: form_helper
INFO - 2018-05-14 23:24:10 --> Helper loaded: date_helper
INFO - 2018-05-14 23:24:10 --> Helper loaded: util_helper
INFO - 2018-05-14 23:24:10 --> Helper loaded: text_helper
INFO - 2018-05-14 23:24:10 --> Helper loaded: string_helper
INFO - 2018-05-14 23:24:10 --> Database Driver Class Initialized
DEBUG - 2018-05-14 23:24:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-14 23:24:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-14 23:24:10 --> Email Class Initialized
INFO - 2018-05-14 23:24:10 --> Controller Class Initialized
DEBUG - 2018-05-14 23:24:10 --> videos MX_Controller Initialized
INFO - 2018-05-14 23:24:10 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-14 23:24:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-05-14 23:24:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-14 23:24:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-05-14 23:24:10 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-14 23:24:10 --> Login MX_Controller Initialized
DEBUG - 2018-05-14 23:24:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-14 23:24:10 --> Final output sent to browser
DEBUG - 2018-05-14 23:24:10 --> Total execution time: 0.3854
INFO - 2018-05-14 23:24:12 --> Config Class Initialized
INFO - 2018-05-14 23:24:12 --> Hooks Class Initialized
DEBUG - 2018-05-14 23:24:12 --> UTF-8 Support Enabled
INFO - 2018-05-14 23:24:12 --> Utf8 Class Initialized
INFO - 2018-05-14 23:24:12 --> URI Class Initialized
INFO - 2018-05-14 23:24:12 --> Router Class Initialized
INFO - 2018-05-14 23:24:12 --> Output Class Initialized
INFO - 2018-05-14 23:24:12 --> Security Class Initialized
DEBUG - 2018-05-14 23:24:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 23:24:12 --> Input Class Initialized
INFO - 2018-05-14 23:24:12 --> Language Class Initialized
INFO - 2018-05-14 23:24:12 --> Language Class Initialized
INFO - 2018-05-14 23:24:12 --> Config Class Initialized
INFO - 2018-05-14 23:24:12 --> Loader Class Initialized
DEBUG - 2018-05-14 23:24:12 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-14 23:24:12 --> Helper loaded: url_helper
INFO - 2018-05-14 23:24:12 --> Helper loaded: form_helper
INFO - 2018-05-14 23:24:12 --> Helper loaded: date_helper
INFO - 2018-05-14 23:24:12 --> Helper loaded: util_helper
INFO - 2018-05-14 23:24:12 --> Helper loaded: text_helper
INFO - 2018-05-14 23:24:12 --> Helper loaded: string_helper
INFO - 2018-05-14 23:24:12 --> Database Driver Class Initialized
DEBUG - 2018-05-14 23:24:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-14 23:24:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-14 23:24:12 --> Email Class Initialized
INFO - 2018-05-14 23:24:12 --> Controller Class Initialized
DEBUG - 2018-05-14 23:24:12 --> videos MX_Controller Initialized
INFO - 2018-05-14 23:24:12 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-14 23:24:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-05-14 23:24:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-14 23:24:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-05-14 23:24:12 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-14 23:24:12 --> Login MX_Controller Initialized
DEBUG - 2018-05-14 23:24:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-14 23:24:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-05-14 23:24:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-05-14 23:24:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-05-14 23:24:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-05-14 23:24:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-05-14 23:24:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/videos/videos.php
INFO - 2018-05-14 23:24:12 --> Final output sent to browser
DEBUG - 2018-05-14 23:24:12 --> Total execution time: 0.4178
INFO - 2018-05-14 23:24:13 --> Config Class Initialized
INFO - 2018-05-14 23:24:13 --> Hooks Class Initialized
DEBUG - 2018-05-14 23:24:13 --> UTF-8 Support Enabled
INFO - 2018-05-14 23:24:13 --> Utf8 Class Initialized
INFO - 2018-05-14 23:24:13 --> URI Class Initialized
INFO - 2018-05-14 23:24:13 --> Router Class Initialized
INFO - 2018-05-14 23:24:13 --> Output Class Initialized
INFO - 2018-05-14 23:24:13 --> Security Class Initialized
DEBUG - 2018-05-14 23:24:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 23:24:13 --> Input Class Initialized
INFO - 2018-05-14 23:24:13 --> Language Class Initialized
INFO - 2018-05-14 23:24:13 --> Language Class Initialized
INFO - 2018-05-14 23:24:13 --> Config Class Initialized
INFO - 2018-05-14 23:24:13 --> Loader Class Initialized
DEBUG - 2018-05-14 23:24:13 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-14 23:24:13 --> Helper loaded: url_helper
INFO - 2018-05-14 23:24:13 --> Helper loaded: form_helper
INFO - 2018-05-14 23:24:13 --> Helper loaded: date_helper
INFO - 2018-05-14 23:24:13 --> Helper loaded: util_helper
INFO - 2018-05-14 23:24:13 --> Helper loaded: text_helper
INFO - 2018-05-14 23:24:13 --> Helper loaded: string_helper
INFO - 2018-05-14 23:24:13 --> Database Driver Class Initialized
DEBUG - 2018-05-14 23:24:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-14 23:24:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-14 23:24:13 --> Email Class Initialized
INFO - 2018-05-14 23:24:13 --> Controller Class Initialized
DEBUG - 2018-05-14 23:24:13 --> videos MX_Controller Initialized
INFO - 2018-05-14 23:24:13 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-14 23:24:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-05-14 23:24:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-14 23:24:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-05-14 23:24:13 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-14 23:24:13 --> Login MX_Controller Initialized
DEBUG - 2018-05-14 23:24:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-14 23:24:13 --> Final output sent to browser
DEBUG - 2018-05-14 23:24:13 --> Total execution time: 0.4675
INFO - 2018-05-14 23:24:15 --> Config Class Initialized
INFO - 2018-05-14 23:24:15 --> Hooks Class Initialized
DEBUG - 2018-05-14 23:24:15 --> UTF-8 Support Enabled
INFO - 2018-05-14 23:24:15 --> Utf8 Class Initialized
INFO - 2018-05-14 23:24:15 --> URI Class Initialized
INFO - 2018-05-14 23:24:15 --> Router Class Initialized
INFO - 2018-05-14 23:24:15 --> Output Class Initialized
INFO - 2018-05-14 23:24:15 --> Security Class Initialized
DEBUG - 2018-05-14 23:24:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 23:24:15 --> Input Class Initialized
INFO - 2018-05-14 23:24:15 --> Language Class Initialized
INFO - 2018-05-14 23:24:15 --> Language Class Initialized
INFO - 2018-05-14 23:24:15 --> Config Class Initialized
INFO - 2018-05-14 23:24:15 --> Loader Class Initialized
DEBUG - 2018-05-14 23:24:15 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-14 23:24:15 --> Helper loaded: url_helper
INFO - 2018-05-14 23:24:15 --> Helper loaded: form_helper
INFO - 2018-05-14 23:24:15 --> Helper loaded: date_helper
INFO - 2018-05-14 23:24:15 --> Helper loaded: util_helper
INFO - 2018-05-14 23:24:15 --> Helper loaded: text_helper
INFO - 2018-05-14 23:24:15 --> Helper loaded: string_helper
INFO - 2018-05-14 23:24:15 --> Database Driver Class Initialized
DEBUG - 2018-05-14 23:24:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-14 23:24:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-14 23:24:15 --> Email Class Initialized
INFO - 2018-05-14 23:24:15 --> Controller Class Initialized
DEBUG - 2018-05-14 23:24:15 --> Programs MX_Controller Initialized
INFO - 2018-05-14 23:24:15 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-14 23:24:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-05-14 23:24:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-14 23:24:15 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-14 23:24:15 --> Login MX_Controller Initialized
DEBUG - 2018-05-14 23:24:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-14 23:24:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-05-14 23:24:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-05-14 23:24:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-05-14 23:24:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-05-14 23:24:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-05-14 23:24:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/programs/programs.php
INFO - 2018-05-14 23:24:15 --> Final output sent to browser
DEBUG - 2018-05-14 23:24:15 --> Total execution time: 0.4096
INFO - 2018-05-14 23:24:16 --> Config Class Initialized
INFO - 2018-05-14 23:24:16 --> Hooks Class Initialized
DEBUG - 2018-05-14 23:24:16 --> UTF-8 Support Enabled
INFO - 2018-05-14 23:24:16 --> Utf8 Class Initialized
INFO - 2018-05-14 23:24:16 --> URI Class Initialized
INFO - 2018-05-14 23:24:16 --> Router Class Initialized
INFO - 2018-05-14 23:24:16 --> Output Class Initialized
INFO - 2018-05-14 23:24:16 --> Security Class Initialized
DEBUG - 2018-05-14 23:24:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 23:24:16 --> Input Class Initialized
INFO - 2018-05-14 23:24:16 --> Language Class Initialized
INFO - 2018-05-14 23:24:16 --> Language Class Initialized
INFO - 2018-05-14 23:24:16 --> Config Class Initialized
INFO - 2018-05-14 23:24:16 --> Loader Class Initialized
DEBUG - 2018-05-14 23:24:16 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-14 23:24:16 --> Helper loaded: url_helper
INFO - 2018-05-14 23:24:16 --> Helper loaded: form_helper
INFO - 2018-05-14 23:24:16 --> Helper loaded: date_helper
INFO - 2018-05-14 23:24:16 --> Helper loaded: util_helper
INFO - 2018-05-14 23:24:16 --> Helper loaded: text_helper
INFO - 2018-05-14 23:24:16 --> Helper loaded: string_helper
INFO - 2018-05-14 23:24:16 --> Database Driver Class Initialized
DEBUG - 2018-05-14 23:24:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-14 23:24:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-14 23:24:16 --> Email Class Initialized
INFO - 2018-05-14 23:24:16 --> Controller Class Initialized
DEBUG - 2018-05-14 23:24:16 --> Programs MX_Controller Initialized
INFO - 2018-05-14 23:24:16 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-14 23:24:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-05-14 23:24:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-14 23:24:16 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-14 23:24:16 --> Login MX_Controller Initialized
DEBUG - 2018-05-14 23:24:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-14 23:24:16 --> Final output sent to browser
DEBUG - 2018-05-14 23:24:16 --> Total execution time: 0.4873
INFO - 2018-05-14 23:24:17 --> Config Class Initialized
INFO - 2018-05-14 23:24:17 --> Hooks Class Initialized
DEBUG - 2018-05-14 23:24:17 --> UTF-8 Support Enabled
INFO - 2018-05-14 23:24:17 --> Utf8 Class Initialized
INFO - 2018-05-14 23:24:17 --> URI Class Initialized
INFO - 2018-05-14 23:24:17 --> Router Class Initialized
INFO - 2018-05-14 23:24:17 --> Output Class Initialized
INFO - 2018-05-14 23:24:17 --> Security Class Initialized
DEBUG - 2018-05-14 23:24:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 23:24:17 --> Input Class Initialized
INFO - 2018-05-14 23:24:17 --> Language Class Initialized
INFO - 2018-05-14 23:24:17 --> Language Class Initialized
INFO - 2018-05-14 23:24:17 --> Config Class Initialized
INFO - 2018-05-14 23:24:17 --> Loader Class Initialized
DEBUG - 2018-05-14 23:24:17 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-14 23:24:17 --> Helper loaded: url_helper
INFO - 2018-05-14 23:24:17 --> Helper loaded: form_helper
INFO - 2018-05-14 23:24:17 --> Helper loaded: date_helper
INFO - 2018-05-14 23:24:17 --> Helper loaded: util_helper
INFO - 2018-05-14 23:24:17 --> Helper loaded: text_helper
INFO - 2018-05-14 23:24:17 --> Helper loaded: string_helper
INFO - 2018-05-14 23:24:17 --> Database Driver Class Initialized
DEBUG - 2018-05-14 23:24:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-14 23:24:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-14 23:24:17 --> Email Class Initialized
INFO - 2018-05-14 23:24:17 --> Controller Class Initialized
DEBUG - 2018-05-14 23:24:17 --> Chapters MX_Controller Initialized
INFO - 2018-05-14 23:24:17 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-14 23:24:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Chapters_model.php
DEBUG - 2018-05-14 23:24:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-14 23:24:17 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-14 23:24:17 --> Login MX_Controller Initialized
DEBUG - 2018-05-14 23:24:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-14 23:24:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-05-14 23:24:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-05-14 23:24:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-05-14 23:24:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-05-14 23:24:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-05-14 23:24:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/chapters/chapters.php
INFO - 2018-05-14 23:24:17 --> Final output sent to browser
DEBUG - 2018-05-14 23:24:17 --> Total execution time: 0.4236
INFO - 2018-05-14 23:24:18 --> Config Class Initialized
INFO - 2018-05-14 23:24:18 --> Hooks Class Initialized
DEBUG - 2018-05-14 23:24:18 --> UTF-8 Support Enabled
INFO - 2018-05-14 23:24:18 --> Utf8 Class Initialized
INFO - 2018-05-14 23:24:18 --> URI Class Initialized
INFO - 2018-05-14 23:24:18 --> Router Class Initialized
INFO - 2018-05-14 23:24:18 --> Output Class Initialized
INFO - 2018-05-14 23:24:18 --> Security Class Initialized
DEBUG - 2018-05-14 23:24:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 23:24:18 --> Input Class Initialized
INFO - 2018-05-14 23:24:18 --> Language Class Initialized
INFO - 2018-05-14 23:24:18 --> Language Class Initialized
INFO - 2018-05-14 23:24:18 --> Config Class Initialized
INFO - 2018-05-14 23:24:18 --> Loader Class Initialized
DEBUG - 2018-05-14 23:24:18 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-14 23:24:18 --> Helper loaded: url_helper
INFO - 2018-05-14 23:24:18 --> Helper loaded: form_helper
INFO - 2018-05-14 23:24:18 --> Helper loaded: date_helper
INFO - 2018-05-14 23:24:18 --> Helper loaded: util_helper
INFO - 2018-05-14 23:24:18 --> Helper loaded: text_helper
INFO - 2018-05-14 23:24:18 --> Helper loaded: string_helper
INFO - 2018-05-14 23:24:18 --> Database Driver Class Initialized
DEBUG - 2018-05-14 23:24:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-14 23:24:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-14 23:24:18 --> Email Class Initialized
INFO - 2018-05-14 23:24:18 --> Controller Class Initialized
DEBUG - 2018-05-14 23:24:18 --> Chapters MX_Controller Initialized
INFO - 2018-05-14 23:24:18 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-14 23:24:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Chapters_model.php
DEBUG - 2018-05-14 23:24:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-14 23:24:18 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-14 23:24:18 --> Login MX_Controller Initialized
DEBUG - 2018-05-14 23:24:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-14 23:24:18 --> Final output sent to browser
DEBUG - 2018-05-14 23:24:18 --> Total execution time: 0.4746
INFO - 2018-05-14 23:24:18 --> Config Class Initialized
INFO - 2018-05-14 23:24:18 --> Hooks Class Initialized
DEBUG - 2018-05-14 23:24:18 --> UTF-8 Support Enabled
INFO - 2018-05-14 23:24:18 --> Utf8 Class Initialized
INFO - 2018-05-14 23:24:18 --> URI Class Initialized
INFO - 2018-05-14 23:24:18 --> Router Class Initialized
INFO - 2018-05-14 23:24:18 --> Output Class Initialized
INFO - 2018-05-14 23:24:18 --> Security Class Initialized
DEBUG - 2018-05-14 23:24:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 23:24:18 --> Input Class Initialized
INFO - 2018-05-14 23:24:18 --> Language Class Initialized
INFO - 2018-05-14 23:24:18 --> Language Class Initialized
INFO - 2018-05-14 23:24:18 --> Config Class Initialized
INFO - 2018-05-14 23:24:18 --> Loader Class Initialized
DEBUG - 2018-05-14 23:24:18 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-14 23:24:18 --> Helper loaded: url_helper
INFO - 2018-05-14 23:24:18 --> Helper loaded: form_helper
INFO - 2018-05-14 23:24:18 --> Helper loaded: date_helper
INFO - 2018-05-14 23:24:18 --> Helper loaded: util_helper
INFO - 2018-05-14 23:24:18 --> Helper loaded: text_helper
INFO - 2018-05-14 23:24:18 --> Helper loaded: string_helper
INFO - 2018-05-14 23:24:18 --> Database Driver Class Initialized
DEBUG - 2018-05-14 23:24:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-14 23:24:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-14 23:24:19 --> Email Class Initialized
INFO - 2018-05-14 23:24:19 --> Controller Class Initialized
DEBUG - 2018-05-14 23:24:19 --> Chapters MX_Controller Initialized
INFO - 2018-05-14 23:24:19 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-14 23:24:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Chapters_model.php
DEBUG - 2018-05-14 23:24:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-14 23:24:19 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-14 23:24:19 --> Login MX_Controller Initialized
DEBUG - 2018-05-14 23:24:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-14 23:24:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-05-14 23:24:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-05-14 23:24:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-05-14 23:24:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-05-14 23:24:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-05-14 23:24:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/chapters/chapters.php
INFO - 2018-05-14 23:24:19 --> Final output sent to browser
DEBUG - 2018-05-14 23:24:19 --> Total execution time: 0.4556
INFO - 2018-05-14 23:24:19 --> Config Class Initialized
INFO - 2018-05-14 23:24:19 --> Hooks Class Initialized
DEBUG - 2018-05-14 23:24:19 --> UTF-8 Support Enabled
INFO - 2018-05-14 23:24:19 --> Utf8 Class Initialized
INFO - 2018-05-14 23:24:19 --> URI Class Initialized
INFO - 2018-05-14 23:24:19 --> Router Class Initialized
INFO - 2018-05-14 23:24:19 --> Output Class Initialized
INFO - 2018-05-14 23:24:19 --> Security Class Initialized
DEBUG - 2018-05-14 23:24:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 23:24:19 --> Input Class Initialized
INFO - 2018-05-14 23:24:19 --> Language Class Initialized
INFO - 2018-05-14 23:24:19 --> Language Class Initialized
INFO - 2018-05-14 23:24:19 --> Config Class Initialized
INFO - 2018-05-14 23:24:19 --> Loader Class Initialized
DEBUG - 2018-05-14 23:24:19 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-14 23:24:19 --> Helper loaded: url_helper
INFO - 2018-05-14 23:24:19 --> Helper loaded: form_helper
INFO - 2018-05-14 23:24:19 --> Helper loaded: date_helper
INFO - 2018-05-14 23:24:19 --> Helper loaded: util_helper
INFO - 2018-05-14 23:24:19 --> Helper loaded: text_helper
INFO - 2018-05-14 23:24:19 --> Helper loaded: string_helper
INFO - 2018-05-14 23:24:19 --> Database Driver Class Initialized
DEBUG - 2018-05-14 23:24:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-14 23:24:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-14 23:24:19 --> Email Class Initialized
INFO - 2018-05-14 23:24:19 --> Controller Class Initialized
DEBUG - 2018-05-14 23:24:19 --> Chapters MX_Controller Initialized
INFO - 2018-05-14 23:24:19 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-14 23:24:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Chapters_model.php
DEBUG - 2018-05-14 23:24:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-14 23:24:19 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-14 23:24:19 --> Login MX_Controller Initialized
DEBUG - 2018-05-14 23:24:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-14 23:24:19 --> Final output sent to browser
DEBUG - 2018-05-14 23:24:19 --> Total execution time: 0.4769
INFO - 2018-05-14 23:24:20 --> Config Class Initialized
INFO - 2018-05-14 23:24:20 --> Hooks Class Initialized
DEBUG - 2018-05-14 23:24:20 --> UTF-8 Support Enabled
INFO - 2018-05-14 23:24:20 --> Utf8 Class Initialized
INFO - 2018-05-14 23:24:20 --> URI Class Initialized
INFO - 2018-05-14 23:24:20 --> Router Class Initialized
INFO - 2018-05-14 23:24:20 --> Output Class Initialized
INFO - 2018-05-14 23:24:20 --> Security Class Initialized
DEBUG - 2018-05-14 23:24:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 23:24:20 --> Input Class Initialized
INFO - 2018-05-14 23:24:20 --> Language Class Initialized
INFO - 2018-05-14 23:24:20 --> Language Class Initialized
INFO - 2018-05-14 23:24:20 --> Config Class Initialized
INFO - 2018-05-14 23:24:20 --> Loader Class Initialized
DEBUG - 2018-05-14 23:24:20 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-14 23:24:20 --> Helper loaded: url_helper
INFO - 2018-05-14 23:24:20 --> Helper loaded: form_helper
INFO - 2018-05-14 23:24:20 --> Helper loaded: date_helper
INFO - 2018-05-14 23:24:20 --> Helper loaded: util_helper
INFO - 2018-05-14 23:24:20 --> Helper loaded: text_helper
INFO - 2018-05-14 23:24:20 --> Helper loaded: string_helper
INFO - 2018-05-14 23:24:20 --> Database Driver Class Initialized
DEBUG - 2018-05-14 23:24:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-14 23:24:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-14 23:24:20 --> Email Class Initialized
INFO - 2018-05-14 23:24:20 --> Controller Class Initialized
DEBUG - 2018-05-14 23:24:20 --> Admin MX_Controller Initialized
INFO - 2018-05-14 23:24:20 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-14 23:24:20 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-14 23:24:20 --> Login MX_Controller Initialized
DEBUG - 2018-05-14 23:24:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-14 23:24:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-14 23:24:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-05-14 23:24:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-05-14 23:24:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-05-14 23:24:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-05-14 23:24:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-05-14 23:24:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/dashboard.php
INFO - 2018-05-14 23:24:21 --> Final output sent to browser
DEBUG - 2018-05-14 23:24:21 --> Total execution time: 0.4062
INFO - 2018-05-14 23:24:21 --> Config Class Initialized
INFO - 2018-05-14 23:24:21 --> Hooks Class Initialized
DEBUG - 2018-05-14 23:24:21 --> UTF-8 Support Enabled
INFO - 2018-05-14 23:24:21 --> Utf8 Class Initialized
INFO - 2018-05-14 23:24:21 --> URI Class Initialized
INFO - 2018-05-14 23:24:21 --> Router Class Initialized
INFO - 2018-05-14 23:24:21 --> Output Class Initialized
INFO - 2018-05-14 23:24:21 --> Config Class Initialized
INFO - 2018-05-14 23:24:21 --> Hooks Class Initialized
INFO - 2018-05-14 23:24:21 --> Security Class Initialized
DEBUG - 2018-05-14 23:24:21 --> UTF-8 Support Enabled
DEBUG - 2018-05-14 23:24:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 23:24:21 --> Utf8 Class Initialized
INFO - 2018-05-14 23:24:21 --> Input Class Initialized
INFO - 2018-05-14 23:24:21 --> Language Class Initialized
INFO - 2018-05-14 23:24:21 --> URI Class Initialized
INFO - 2018-05-14 23:24:21 --> Router Class Initialized
INFO - 2018-05-14 23:24:21 --> Output Class Initialized
INFO - 2018-05-14 23:24:21 --> Security Class Initialized
DEBUG - 2018-05-14 23:24:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-05-14 23:24:21 --> 404 Page Not Found: /index
INFO - 2018-05-14 23:24:21 --> Input Class Initialized
INFO - 2018-05-14 23:24:21 --> Language Class Initialized
ERROR - 2018-05-14 23:24:21 --> 404 Page Not Found: /index
INFO - 2018-05-14 23:24:25 --> Config Class Initialized
INFO - 2018-05-14 23:24:25 --> Hooks Class Initialized
DEBUG - 2018-05-14 23:24:25 --> UTF-8 Support Enabled
INFO - 2018-05-14 23:24:25 --> Utf8 Class Initialized
INFO - 2018-05-14 23:24:25 --> URI Class Initialized
INFO - 2018-05-14 23:24:25 --> Router Class Initialized
INFO - 2018-05-14 23:24:25 --> Output Class Initialized
INFO - 2018-05-14 23:24:25 --> Security Class Initialized
DEBUG - 2018-05-14 23:24:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 23:24:25 --> Input Class Initialized
INFO - 2018-05-14 23:24:25 --> Language Class Initialized
INFO - 2018-05-14 23:24:25 --> Language Class Initialized
INFO - 2018-05-14 23:24:25 --> Config Class Initialized
INFO - 2018-05-14 23:24:25 --> Loader Class Initialized
DEBUG - 2018-05-14 23:24:25 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-14 23:24:25 --> Helper loaded: url_helper
INFO - 2018-05-14 23:24:25 --> Helper loaded: form_helper
INFO - 2018-05-14 23:24:25 --> Helper loaded: date_helper
INFO - 2018-05-14 23:24:25 --> Helper loaded: util_helper
INFO - 2018-05-14 23:24:25 --> Helper loaded: text_helper
INFO - 2018-05-14 23:24:25 --> Helper loaded: string_helper
INFO - 2018-05-14 23:24:25 --> Database Driver Class Initialized
DEBUG - 2018-05-14 23:24:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-14 23:24:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-14 23:24:25 --> Email Class Initialized
INFO - 2018-05-14 23:24:25 --> Controller Class Initialized
DEBUG - 2018-05-14 23:24:25 --> Programs MX_Controller Initialized
INFO - 2018-05-14 23:24:25 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-14 23:24:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-05-14 23:24:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-14 23:24:25 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-14 23:24:25 --> Login MX_Controller Initialized
DEBUG - 2018-05-14 23:24:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-14 23:24:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-05-14 23:24:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-05-14 23:24:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-05-14 23:24:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-05-14 23:24:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-05-14 23:24:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/programs/programs.php
INFO - 2018-05-14 23:24:25 --> Final output sent to browser
DEBUG - 2018-05-14 23:24:26 --> Total execution time: 0.4267
INFO - 2018-05-14 23:24:26 --> Config Class Initialized
INFO - 2018-05-14 23:24:26 --> Hooks Class Initialized
DEBUG - 2018-05-14 23:24:26 --> UTF-8 Support Enabled
INFO - 2018-05-14 23:24:26 --> Utf8 Class Initialized
INFO - 2018-05-14 23:24:26 --> URI Class Initialized
INFO - 2018-05-14 23:24:26 --> Router Class Initialized
INFO - 2018-05-14 23:24:26 --> Output Class Initialized
INFO - 2018-05-14 23:24:26 --> Security Class Initialized
DEBUG - 2018-05-14 23:24:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 23:24:26 --> Input Class Initialized
INFO - 2018-05-14 23:24:26 --> Language Class Initialized
INFO - 2018-05-14 23:24:26 --> Language Class Initialized
INFO - 2018-05-14 23:24:26 --> Config Class Initialized
INFO - 2018-05-14 23:24:26 --> Loader Class Initialized
DEBUG - 2018-05-14 23:24:26 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-14 23:24:26 --> Helper loaded: url_helper
INFO - 2018-05-14 23:24:26 --> Helper loaded: form_helper
INFO - 2018-05-14 23:24:26 --> Helper loaded: date_helper
INFO - 2018-05-14 23:24:26 --> Helper loaded: util_helper
INFO - 2018-05-14 23:24:26 --> Helper loaded: text_helper
INFO - 2018-05-14 23:24:26 --> Helper loaded: string_helper
INFO - 2018-05-14 23:24:26 --> Database Driver Class Initialized
DEBUG - 2018-05-14 23:24:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-14 23:24:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-14 23:24:26 --> Email Class Initialized
INFO - 2018-05-14 23:24:26 --> Controller Class Initialized
DEBUG - 2018-05-14 23:24:26 --> Programs MX_Controller Initialized
INFO - 2018-05-14 23:24:26 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-14 23:24:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-05-14 23:24:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-14 23:24:26 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-14 23:24:26 --> Login MX_Controller Initialized
DEBUG - 2018-05-14 23:24:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-14 23:24:26 --> Final output sent to browser
DEBUG - 2018-05-14 23:24:26 --> Total execution time: 0.4882
INFO - 2018-05-14 23:24:29 --> Config Class Initialized
INFO - 2018-05-14 23:24:29 --> Hooks Class Initialized
DEBUG - 2018-05-14 23:24:29 --> UTF-8 Support Enabled
INFO - 2018-05-14 23:24:29 --> Utf8 Class Initialized
INFO - 2018-05-14 23:24:29 --> URI Class Initialized
INFO - 2018-05-14 23:24:29 --> Router Class Initialized
INFO - 2018-05-14 23:24:29 --> Output Class Initialized
INFO - 2018-05-14 23:24:29 --> Security Class Initialized
DEBUG - 2018-05-14 23:24:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 23:24:29 --> Input Class Initialized
INFO - 2018-05-14 23:24:29 --> Language Class Initialized
INFO - 2018-05-14 23:24:29 --> Language Class Initialized
INFO - 2018-05-14 23:24:29 --> Config Class Initialized
INFO - 2018-05-14 23:24:29 --> Loader Class Initialized
DEBUG - 2018-05-14 23:24:29 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-14 23:24:29 --> Helper loaded: url_helper
INFO - 2018-05-14 23:24:29 --> Helper loaded: form_helper
INFO - 2018-05-14 23:24:29 --> Helper loaded: date_helper
INFO - 2018-05-14 23:24:29 --> Helper loaded: util_helper
INFO - 2018-05-14 23:24:29 --> Helper loaded: text_helper
INFO - 2018-05-14 23:24:29 --> Helper loaded: string_helper
INFO - 2018-05-14 23:24:29 --> Database Driver Class Initialized
DEBUG - 2018-05-14 23:24:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-14 23:24:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-14 23:24:29 --> Email Class Initialized
INFO - 2018-05-14 23:24:29 --> Controller Class Initialized
DEBUG - 2018-05-14 23:24:29 --> Chapters MX_Controller Initialized
INFO - 2018-05-14 23:24:29 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-14 23:24:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Chapters_model.php
DEBUG - 2018-05-14 23:24:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-14 23:24:29 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-14 23:24:29 --> Login MX_Controller Initialized
DEBUG - 2018-05-14 23:24:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-14 23:24:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-05-14 23:24:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-05-14 23:24:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-05-14 23:24:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-05-14 23:24:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-05-14 23:24:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/chapters/chapters.php
INFO - 2018-05-14 23:24:29 --> Final output sent to browser
DEBUG - 2018-05-14 23:24:29 --> Total execution time: 0.4197
INFO - 2018-05-14 23:24:30 --> Config Class Initialized
INFO - 2018-05-14 23:24:30 --> Hooks Class Initialized
DEBUG - 2018-05-14 23:24:30 --> UTF-8 Support Enabled
INFO - 2018-05-14 23:24:30 --> Utf8 Class Initialized
INFO - 2018-05-14 23:24:30 --> URI Class Initialized
INFO - 2018-05-14 23:24:30 --> Router Class Initialized
INFO - 2018-05-14 23:24:30 --> Output Class Initialized
INFO - 2018-05-14 23:24:30 --> Security Class Initialized
DEBUG - 2018-05-14 23:24:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 23:24:30 --> Input Class Initialized
INFO - 2018-05-14 23:24:30 --> Language Class Initialized
INFO - 2018-05-14 23:24:30 --> Language Class Initialized
INFO - 2018-05-14 23:24:30 --> Config Class Initialized
INFO - 2018-05-14 23:24:30 --> Loader Class Initialized
DEBUG - 2018-05-14 23:24:30 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-14 23:24:30 --> Helper loaded: url_helper
INFO - 2018-05-14 23:24:30 --> Helper loaded: form_helper
INFO - 2018-05-14 23:24:30 --> Helper loaded: date_helper
INFO - 2018-05-14 23:24:30 --> Helper loaded: util_helper
INFO - 2018-05-14 23:24:30 --> Helper loaded: text_helper
INFO - 2018-05-14 23:24:30 --> Helper loaded: string_helper
INFO - 2018-05-14 23:24:30 --> Database Driver Class Initialized
DEBUG - 2018-05-14 23:24:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-14 23:24:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-14 23:24:30 --> Email Class Initialized
INFO - 2018-05-14 23:24:30 --> Controller Class Initialized
DEBUG - 2018-05-14 23:24:30 --> Chapters MX_Controller Initialized
INFO - 2018-05-14 23:24:30 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-14 23:24:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Chapters_model.php
DEBUG - 2018-05-14 23:24:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-14 23:24:30 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-14 23:24:30 --> Login MX_Controller Initialized
DEBUG - 2018-05-14 23:24:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-14 23:24:30 --> Final output sent to browser
DEBUG - 2018-05-14 23:24:30 --> Total execution time: 0.4984
INFO - 2018-05-14 23:24:33 --> Config Class Initialized
INFO - 2018-05-14 23:24:33 --> Hooks Class Initialized
DEBUG - 2018-05-14 23:24:33 --> UTF-8 Support Enabled
INFO - 2018-05-14 23:24:33 --> Utf8 Class Initialized
INFO - 2018-05-14 23:24:33 --> URI Class Initialized
INFO - 2018-05-14 23:24:33 --> Router Class Initialized
INFO - 2018-05-14 23:24:33 --> Output Class Initialized
INFO - 2018-05-14 23:24:33 --> Security Class Initialized
DEBUG - 2018-05-14 23:24:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 23:24:33 --> Input Class Initialized
INFO - 2018-05-14 23:24:33 --> Language Class Initialized
INFO - 2018-05-14 23:24:33 --> Language Class Initialized
INFO - 2018-05-14 23:24:33 --> Config Class Initialized
INFO - 2018-05-14 23:24:33 --> Loader Class Initialized
DEBUG - 2018-05-14 23:24:33 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-14 23:24:33 --> Helper loaded: url_helper
INFO - 2018-05-14 23:24:33 --> Helper loaded: form_helper
INFO - 2018-05-14 23:24:33 --> Helper loaded: date_helper
INFO - 2018-05-14 23:24:33 --> Helper loaded: util_helper
INFO - 2018-05-14 23:24:33 --> Helper loaded: text_helper
INFO - 2018-05-14 23:24:33 --> Helper loaded: string_helper
INFO - 2018-05-14 23:24:33 --> Database Driver Class Initialized
DEBUG - 2018-05-14 23:24:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-14 23:24:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-14 23:24:33 --> Email Class Initialized
INFO - 2018-05-14 23:24:33 --> Controller Class Initialized
DEBUG - 2018-05-14 23:24:33 --> videos MX_Controller Initialized
INFO - 2018-05-14 23:24:33 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-14 23:24:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-05-14 23:24:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-14 23:24:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-05-14 23:24:33 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-14 23:24:33 --> Login MX_Controller Initialized
DEBUG - 2018-05-14 23:24:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-14 23:24:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-05-14 23:24:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-05-14 23:24:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-05-14 23:24:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-05-14 23:24:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-05-14 23:24:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/videos/videos.php
INFO - 2018-05-14 23:24:34 --> Final output sent to browser
DEBUG - 2018-05-14 23:24:34 --> Total execution time: 0.4358
INFO - 2018-05-14 23:24:34 --> Config Class Initialized
INFO - 2018-05-14 23:24:34 --> Hooks Class Initialized
DEBUG - 2018-05-14 23:24:34 --> UTF-8 Support Enabled
INFO - 2018-05-14 23:24:34 --> Utf8 Class Initialized
INFO - 2018-05-14 23:24:34 --> URI Class Initialized
INFO - 2018-05-14 23:24:34 --> Router Class Initialized
INFO - 2018-05-14 23:24:34 --> Output Class Initialized
INFO - 2018-05-14 23:24:34 --> Security Class Initialized
DEBUG - 2018-05-14 23:24:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 23:24:34 --> Input Class Initialized
INFO - 2018-05-14 23:24:34 --> Language Class Initialized
INFO - 2018-05-14 23:24:34 --> Language Class Initialized
INFO - 2018-05-14 23:24:34 --> Config Class Initialized
INFO - 2018-05-14 23:24:34 --> Loader Class Initialized
DEBUG - 2018-05-14 23:24:34 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-14 23:24:34 --> Helper loaded: url_helper
INFO - 2018-05-14 23:24:34 --> Helper loaded: form_helper
INFO - 2018-05-14 23:24:34 --> Helper loaded: date_helper
INFO - 2018-05-14 23:24:34 --> Helper loaded: util_helper
INFO - 2018-05-14 23:24:34 --> Helper loaded: text_helper
INFO - 2018-05-14 23:24:34 --> Helper loaded: string_helper
INFO - 2018-05-14 23:24:34 --> Database Driver Class Initialized
DEBUG - 2018-05-14 23:24:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-14 23:24:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-14 23:24:34 --> Email Class Initialized
INFO - 2018-05-14 23:24:34 --> Controller Class Initialized
DEBUG - 2018-05-14 23:24:34 --> videos MX_Controller Initialized
INFO - 2018-05-14 23:24:34 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-14 23:24:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-05-14 23:24:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-14 23:24:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-05-14 23:24:34 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-14 23:24:34 --> Login MX_Controller Initialized
DEBUG - 2018-05-14 23:24:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-14 23:24:34 --> Final output sent to browser
DEBUG - 2018-05-14 23:24:34 --> Total execution time: 0.4960
INFO - 2018-05-14 23:24:37 --> Config Class Initialized
INFO - 2018-05-14 23:24:37 --> Hooks Class Initialized
DEBUG - 2018-05-14 23:24:37 --> UTF-8 Support Enabled
INFO - 2018-05-14 23:24:37 --> Utf8 Class Initialized
INFO - 2018-05-14 23:24:37 --> URI Class Initialized
INFO - 2018-05-14 23:24:37 --> Router Class Initialized
INFO - 2018-05-14 23:24:37 --> Output Class Initialized
INFO - 2018-05-14 23:24:37 --> Security Class Initialized
DEBUG - 2018-05-14 23:24:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 23:24:37 --> Input Class Initialized
INFO - 2018-05-14 23:24:37 --> Language Class Initialized
INFO - 2018-05-14 23:24:37 --> Language Class Initialized
INFO - 2018-05-14 23:24:37 --> Config Class Initialized
INFO - 2018-05-14 23:24:37 --> Loader Class Initialized
DEBUG - 2018-05-14 23:24:37 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-14 23:24:37 --> Helper loaded: url_helper
INFO - 2018-05-14 23:24:37 --> Helper loaded: form_helper
INFO - 2018-05-14 23:24:37 --> Helper loaded: date_helper
INFO - 2018-05-14 23:24:37 --> Helper loaded: util_helper
INFO - 2018-05-14 23:24:37 --> Helper loaded: text_helper
INFO - 2018-05-14 23:24:37 --> Helper loaded: string_helper
INFO - 2018-05-14 23:24:37 --> Database Driver Class Initialized
DEBUG - 2018-05-14 23:24:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-14 23:24:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-14 23:24:37 --> Email Class Initialized
INFO - 2018-05-14 23:24:37 --> Controller Class Initialized
DEBUG - 2018-05-14 23:24:37 --> Admin MX_Controller Initialized
INFO - 2018-05-14 23:24:37 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-14 23:24:37 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-14 23:24:37 --> Login MX_Controller Initialized
DEBUG - 2018-05-14 23:24:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-14 23:24:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-14 23:24:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-05-14 23:24:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-05-14 23:24:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-05-14 23:24:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-05-14 23:24:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-05-14 23:24:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/dashboard.php
INFO - 2018-05-14 23:24:37 --> Final output sent to browser
DEBUG - 2018-05-14 23:24:37 --> Total execution time: 0.4206
INFO - 2018-05-14 23:24:37 --> Config Class Initialized
INFO - 2018-05-14 23:24:37 --> Hooks Class Initialized
DEBUG - 2018-05-14 23:24:37 --> UTF-8 Support Enabled
INFO - 2018-05-14 23:24:37 --> Config Class Initialized
INFO - 2018-05-14 23:24:37 --> Utf8 Class Initialized
INFO - 2018-05-14 23:24:37 --> Hooks Class Initialized
INFO - 2018-05-14 23:24:37 --> URI Class Initialized
DEBUG - 2018-05-14 23:24:37 --> UTF-8 Support Enabled
INFO - 2018-05-14 23:24:37 --> Utf8 Class Initialized
INFO - 2018-05-14 23:24:37 --> Router Class Initialized
INFO - 2018-05-14 23:24:37 --> URI Class Initialized
INFO - 2018-05-14 23:24:37 --> Output Class Initialized
INFO - 2018-05-14 23:24:37 --> Router Class Initialized
INFO - 2018-05-14 23:24:37 --> Security Class Initialized
INFO - 2018-05-14 23:24:37 --> Output Class Initialized
INFO - 2018-05-14 23:24:37 --> Security Class Initialized
DEBUG - 2018-05-14 23:24:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-14 23:24:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 23:24:37 --> Input Class Initialized
INFO - 2018-05-14 23:24:37 --> Language Class Initialized
ERROR - 2018-05-14 23:24:37 --> 404 Page Not Found: /index
INFO - 2018-05-14 23:24:37 --> Input Class Initialized
INFO - 2018-05-14 23:24:37 --> Language Class Initialized
ERROR - 2018-05-14 23:24:37 --> 404 Page Not Found: /index
INFO - 2018-05-14 23:24:38 --> Config Class Initialized
INFO - 2018-05-14 23:24:38 --> Hooks Class Initialized
DEBUG - 2018-05-14 23:24:38 --> UTF-8 Support Enabled
INFO - 2018-05-14 23:24:38 --> Utf8 Class Initialized
INFO - 2018-05-14 23:24:38 --> URI Class Initialized
INFO - 2018-05-14 23:24:38 --> Router Class Initialized
INFO - 2018-05-14 23:24:38 --> Output Class Initialized
INFO - 2018-05-14 23:24:38 --> Security Class Initialized
DEBUG - 2018-05-14 23:24:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 23:24:38 --> Input Class Initialized
INFO - 2018-05-14 23:24:38 --> Language Class Initialized
ERROR - 2018-05-14 23:24:38 --> 404 Page Not Found: /index
INFO - 2018-05-14 23:35:27 --> Config Class Initialized
INFO - 2018-05-14 23:35:27 --> Config Class Initialized
INFO - 2018-05-14 23:35:27 --> Config Class Initialized
INFO - 2018-05-14 23:35:27 --> Hooks Class Initialized
INFO - 2018-05-14 23:35:27 --> Hooks Class Initialized
INFO - 2018-05-14 23:35:27 --> Config Class Initialized
INFO - 2018-05-14 23:35:27 --> Config Class Initialized
INFO - 2018-05-14 23:35:27 --> Hooks Class Initialized
DEBUG - 2018-05-14 23:35:27 --> UTF-8 Support Enabled
INFO - 2018-05-14 23:35:27 --> Utf8 Class Initialized
INFO - 2018-05-14 23:35:27 --> URI Class Initialized
INFO - 2018-05-14 23:35:27 --> Router Class Initialized
INFO - 2018-05-14 23:35:27 --> Hooks Class Initialized
INFO - 2018-05-14 23:35:27 --> Hooks Class Initialized
INFO - 2018-05-14 23:35:27 --> Output Class Initialized
DEBUG - 2018-05-14 23:35:27 --> UTF-8 Support Enabled
DEBUG - 2018-05-14 23:35:27 --> UTF-8 Support Enabled
INFO - 2018-05-14 23:35:27 --> Utf8 Class Initialized
INFO - 2018-05-14 23:35:27 --> Security Class Initialized
DEBUG - 2018-05-14 23:35:27 --> UTF-8 Support Enabled
DEBUG - 2018-05-14 23:35:27 --> UTF-8 Support Enabled
INFO - 2018-05-14 23:35:27 --> Utf8 Class Initialized
INFO - 2018-05-14 23:35:27 --> Utf8 Class Initialized
INFO - 2018-05-14 23:35:27 --> URI Class Initialized
INFO - 2018-05-14 23:35:27 --> Utf8 Class Initialized
DEBUG - 2018-05-14 23:35:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 23:35:27 --> URI Class Initialized
INFO - 2018-05-14 23:35:27 --> URI Class Initialized
INFO - 2018-05-14 23:35:27 --> Router Class Initialized
INFO - 2018-05-14 23:35:27 --> Router Class Initialized
INFO - 2018-05-14 23:35:27 --> Input Class Initialized
INFO - 2018-05-14 23:35:27 --> Router Class Initialized
INFO - 2018-05-14 23:35:27 --> URI Class Initialized
INFO - 2018-05-14 23:35:27 --> Language Class Initialized
INFO - 2018-05-14 23:35:27 --> Output Class Initialized
INFO - 2018-05-14 23:35:27 --> Output Class Initialized
INFO - 2018-05-14 23:35:27 --> Output Class Initialized
INFO - 2018-05-14 23:35:27 --> Router Class Initialized
INFO - 2018-05-14 23:35:27 --> Security Class Initialized
INFO - 2018-05-14 23:35:27 --> Output Class Initialized
ERROR - 2018-05-14 23:35:27 --> 404 Page Not Found: /index
INFO - 2018-05-14 23:35:27 --> Security Class Initialized
INFO - 2018-05-14 23:35:27 --> Security Class Initialized
DEBUG - 2018-05-14 23:35:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-14 23:35:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-14 23:35:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 23:35:27 --> Security Class Initialized
INFO - 2018-05-14 23:35:27 --> Config Class Initialized
INFO - 2018-05-14 23:35:27 --> Hooks Class Initialized
INFO - 2018-05-14 23:35:27 --> Input Class Initialized
DEBUG - 2018-05-14 23:35:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 23:35:27 --> Input Class Initialized
INFO - 2018-05-14 23:35:27 --> Input Class Initialized
INFO - 2018-05-14 23:35:27 --> Language Class Initialized
DEBUG - 2018-05-14 23:35:27 --> UTF-8 Support Enabled
INFO - 2018-05-14 23:35:27 --> Utf8 Class Initialized
INFO - 2018-05-14 23:35:27 --> Language Class Initialized
ERROR - 2018-05-14 23:35:27 --> 404 Page Not Found: /index
INFO - 2018-05-14 23:35:27 --> Input Class Initialized
INFO - 2018-05-14 23:35:27 --> Language Class Initialized
INFO - 2018-05-14 23:35:27 --> URI Class Initialized
ERROR - 2018-05-14 23:35:27 --> 404 Page Not Found: /index
ERROR - 2018-05-14 23:35:27 --> 404 Page Not Found: /index
INFO - 2018-05-14 23:35:27 --> Language Class Initialized
INFO - 2018-05-14 23:35:27 --> Router Class Initialized
INFO - 2018-05-14 23:35:27 --> Config Class Initialized
ERROR - 2018-05-14 23:35:27 --> 404 Page Not Found: /index
INFO - 2018-05-14 23:35:27 --> Hooks Class Initialized
INFO - 2018-05-14 23:35:27 --> Config Class Initialized
INFO - 2018-05-14 23:35:27 --> Output Class Initialized
INFO - 2018-05-14 23:35:27 --> Hooks Class Initialized
INFO - 2018-05-14 23:35:27 --> Security Class Initialized
DEBUG - 2018-05-14 23:35:27 --> UTF-8 Support Enabled
INFO - 2018-05-14 23:35:27 --> Config Class Initialized
INFO - 2018-05-14 23:35:28 --> Utf8 Class Initialized
INFO - 2018-05-14 23:35:28 --> Hooks Class Initialized
DEBUG - 2018-05-14 23:35:28 --> UTF-8 Support Enabled
DEBUG - 2018-05-14 23:35:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 23:35:28 --> URI Class Initialized
INFO - 2018-05-14 23:35:28 --> Input Class Initialized
INFO - 2018-05-14 23:35:28 --> Utf8 Class Initialized
DEBUG - 2018-05-14 23:35:28 --> UTF-8 Support Enabled
INFO - 2018-05-14 23:35:28 --> Utf8 Class Initialized
INFO - 2018-05-14 23:35:28 --> URI Class Initialized
INFO - 2018-05-14 23:35:28 --> Language Class Initialized
INFO - 2018-05-14 23:35:28 --> Router Class Initialized
ERROR - 2018-05-14 23:35:28 --> 404 Page Not Found: /index
INFO - 2018-05-14 23:35:28 --> Output Class Initialized
INFO - 2018-05-14 23:35:28 --> URI Class Initialized
INFO - 2018-05-14 23:35:28 --> Router Class Initialized
INFO - 2018-05-14 23:35:28 --> Output Class Initialized
INFO - 2018-05-14 23:35:28 --> Router Class Initialized
INFO - 2018-05-14 23:35:28 --> Security Class Initialized
INFO - 2018-05-14 23:35:28 --> Output Class Initialized
DEBUG - 2018-05-14 23:35:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 23:35:28 --> Security Class Initialized
INFO - 2018-05-14 23:35:28 --> Input Class Initialized
DEBUG - 2018-05-14 23:35:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 23:35:28 --> Security Class Initialized
INFO - 2018-05-14 23:35:28 --> Input Class Initialized
INFO - 2018-05-14 23:35:28 --> Language Class Initialized
DEBUG - 2018-05-14 23:35:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 23:35:28 --> Input Class Initialized
ERROR - 2018-05-14 23:35:28 --> 404 Page Not Found: /index
INFO - 2018-05-14 23:35:28 --> Language Class Initialized
INFO - 2018-05-14 23:35:28 --> Language Class Initialized
ERROR - 2018-05-14 23:35:28 --> 404 Page Not Found: /index
ERROR - 2018-05-14 23:35:28 --> 404 Page Not Found: /index
INFO - 2018-05-14 23:35:28 --> Config Class Initialized
INFO - 2018-05-14 23:35:28 --> Config Class Initialized
INFO - 2018-05-14 23:35:28 --> Hooks Class Initialized
INFO - 2018-05-14 23:35:28 --> Hooks Class Initialized
DEBUG - 2018-05-14 23:35:28 --> UTF-8 Support Enabled
INFO - 2018-05-14 23:35:28 --> Config Class Initialized
INFO - 2018-05-14 23:35:28 --> Config Class Initialized
INFO - 2018-05-14 23:35:28 --> Hooks Class Initialized
INFO - 2018-05-14 23:35:28 --> Hooks Class Initialized
INFO - 2018-05-14 23:35:28 --> Utf8 Class Initialized
DEBUG - 2018-05-14 23:35:28 --> UTF-8 Support Enabled
DEBUG - 2018-05-14 23:35:28 --> UTF-8 Support Enabled
DEBUG - 2018-05-14 23:35:28 --> UTF-8 Support Enabled
INFO - 2018-05-14 23:35:28 --> Utf8 Class Initialized
INFO - 2018-05-14 23:35:28 --> URI Class Initialized
INFO - 2018-05-14 23:35:28 --> Utf8 Class Initialized
INFO - 2018-05-14 23:35:28 --> URI Class Initialized
INFO - 2018-05-14 23:35:28 --> Utf8 Class Initialized
INFO - 2018-05-14 23:35:28 --> Router Class Initialized
INFO - 2018-05-14 23:35:28 --> URI Class Initialized
INFO - 2018-05-14 23:35:28 --> Router Class Initialized
INFO - 2018-05-14 23:35:28 --> Output Class Initialized
INFO - 2018-05-14 23:35:28 --> URI Class Initialized
INFO - 2018-05-14 23:35:28 --> Router Class Initialized
INFO - 2018-05-14 23:35:28 --> Output Class Initialized
INFO - 2018-05-14 23:35:28 --> Security Class Initialized
INFO - 2018-05-14 23:35:28 --> Router Class Initialized
INFO - 2018-05-14 23:35:28 --> Output Class Initialized
DEBUG - 2018-05-14 23:35:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 23:35:28 --> Output Class Initialized
INFO - 2018-05-14 23:35:28 --> Security Class Initialized
INFO - 2018-05-14 23:35:28 --> Input Class Initialized
INFO - 2018-05-14 23:35:28 --> Security Class Initialized
DEBUG - 2018-05-14 23:35:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 23:35:28 --> Security Class Initialized
DEBUG - 2018-05-14 23:35:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-14 23:35:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-14 23:35:28 --> Input Class Initialized
INFO - 2018-05-14 23:35:28 --> Language Class Initialized
INFO - 2018-05-14 23:35:28 --> Input Class Initialized
INFO - 2018-05-14 23:35:28 --> Input Class Initialized
INFO - 2018-05-14 23:35:28 --> Language Class Initialized
ERROR - 2018-05-14 23:35:28 --> 404 Page Not Found: /index
INFO - 2018-05-14 23:35:28 --> Language Class Initialized
ERROR - 2018-05-14 23:35:28 --> 404 Page Not Found: /index
INFO - 2018-05-14 23:35:28 --> Language Class Initialized
ERROR - 2018-05-14 23:35:28 --> 404 Page Not Found: /index
ERROR - 2018-05-14 23:35:28 --> 404 Page Not Found: /index
