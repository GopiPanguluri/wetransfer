<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-05-15 00:48:22 --> Config Class Initialized
INFO - 2018-05-15 00:48:22 --> Hooks Class Initialized
DEBUG - 2018-05-15 00:48:22 --> UTF-8 Support Enabled
INFO - 2018-05-15 00:48:22 --> Utf8 Class Initialized
INFO - 2018-05-15 00:48:22 --> URI Class Initialized
INFO - 2018-05-15 00:48:22 --> Router Class Initialized
INFO - 2018-05-15 00:48:22 --> Output Class Initialized
INFO - 2018-05-15 00:48:22 --> Security Class Initialized
DEBUG - 2018-05-15 00:48:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 00:48:22 --> Input Class Initialized
INFO - 2018-05-15 00:48:22 --> Language Class Initialized
ERROR - 2018-05-15 00:48:22 --> 404 Page Not Found: /index
INFO - 2018-05-15 02:34:08 --> Config Class Initialized
INFO - 2018-05-15 02:34:08 --> Hooks Class Initialized
DEBUG - 2018-05-15 02:34:08 --> UTF-8 Support Enabled
INFO - 2018-05-15 02:34:08 --> Utf8 Class Initialized
INFO - 2018-05-15 02:34:08 --> URI Class Initialized
INFO - 2018-05-15 02:34:08 --> Router Class Initialized
INFO - 2018-05-15 02:34:08 --> Output Class Initialized
INFO - 2018-05-15 02:34:08 --> Security Class Initialized
DEBUG - 2018-05-15 02:34:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 02:34:08 --> Input Class Initialized
INFO - 2018-05-15 02:34:08 --> Language Class Initialized
INFO - 2018-05-15 02:34:08 --> Language Class Initialized
INFO - 2018-05-15 02:34:08 --> Config Class Initialized
INFO - 2018-05-15 02:34:08 --> Loader Class Initialized
DEBUG - 2018-05-15 02:34:08 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-15 02:34:08 --> Helper loaded: url_helper
INFO - 2018-05-15 02:34:08 --> Helper loaded: form_helper
INFO - 2018-05-15 02:34:08 --> Helper loaded: date_helper
INFO - 2018-05-15 02:34:08 --> Helper loaded: util_helper
INFO - 2018-05-15 02:34:08 --> Helper loaded: text_helper
INFO - 2018-05-15 02:34:08 --> Helper loaded: string_helper
INFO - 2018-05-15 02:34:08 --> Database Driver Class Initialized
DEBUG - 2018-05-15 02:34:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-15 02:34:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-15 02:34:08 --> Email Class Initialized
INFO - 2018-05-15 02:34:08 --> Controller Class Initialized
DEBUG - 2018-05-15 02:34:08 --> Home MX_Controller Initialized
DEBUG - 2018-05-15 02:34:08 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-15 02:34:08 --> Login MX_Controller Initialized
INFO - 2018-05-15 02:34:08 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-15 02:34:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-15 02:34:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-15 02:34:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/login.php
INFO - 2018-05-15 02:34:11 --> Config Class Initialized
INFO - 2018-05-15 02:34:11 --> Hooks Class Initialized
DEBUG - 2018-05-15 02:34:11 --> UTF-8 Support Enabled
INFO - 2018-05-15 02:34:11 --> Utf8 Class Initialized
INFO - 2018-05-15 02:34:11 --> URI Class Initialized
INFO - 2018-05-15 02:34:11 --> Router Class Initialized
INFO - 2018-05-15 02:34:11 --> Output Class Initialized
INFO - 2018-05-15 02:34:11 --> Security Class Initialized
DEBUG - 2018-05-15 02:34:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 02:34:11 --> Input Class Initialized
INFO - 2018-05-15 02:34:11 --> Language Class Initialized
INFO - 2018-05-15 02:34:11 --> Language Class Initialized
INFO - 2018-05-15 02:34:11 --> Config Class Initialized
INFO - 2018-05-15 02:34:11 --> Loader Class Initialized
DEBUG - 2018-05-15 02:34:11 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-15 02:34:11 --> Helper loaded: url_helper
INFO - 2018-05-15 02:34:11 --> Helper loaded: form_helper
INFO - 2018-05-15 02:34:11 --> Helper loaded: date_helper
INFO - 2018-05-15 02:34:11 --> Helper loaded: util_helper
INFO - 2018-05-15 02:34:11 --> Helper loaded: text_helper
INFO - 2018-05-15 02:34:11 --> Helper loaded: string_helper
INFO - 2018-05-15 02:34:11 --> Database Driver Class Initialized
DEBUG - 2018-05-15 02:34:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-15 02:34:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-15 02:34:11 --> Email Class Initialized
INFO - 2018-05-15 02:34:11 --> Controller Class Initialized
DEBUG - 2018-05-15 02:34:11 --> Login MX_Controller Initialized
INFO - 2018-05-15 02:34:11 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-15 02:34:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-15 02:34:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-15 02:34:11 --> Email starts for gopipanguluri123@gmail.com fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-05-15 02:34:11 --> User session created for 4
INFO - 2018-05-15 02:34:12 --> Login status gopipanguluri123@gmail.com - success
ERROR - 2018-05-15 02:34:12 --> Severity: Notice --> Undefined variable: data E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php 311
INFO - 2018-05-15 02:34:12 --> Final output sent to browser
DEBUG - 2018-05-15 02:34:12 --> Total execution time: 0.3083
INFO - 2018-05-15 02:34:15 --> Config Class Initialized
INFO - 2018-05-15 02:34:15 --> Hooks Class Initialized
DEBUG - 2018-05-15 02:34:15 --> UTF-8 Support Enabled
INFO - 2018-05-15 02:34:15 --> Utf8 Class Initialized
INFO - 2018-05-15 02:34:15 --> URI Class Initialized
INFO - 2018-05-15 02:34:15 --> Router Class Initialized
INFO - 2018-05-15 02:34:15 --> Output Class Initialized
INFO - 2018-05-15 02:34:15 --> Security Class Initialized
DEBUG - 2018-05-15 02:34:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 02:34:15 --> Input Class Initialized
INFO - 2018-05-15 02:34:15 --> Language Class Initialized
INFO - 2018-05-15 02:34:15 --> Language Class Initialized
INFO - 2018-05-15 02:34:15 --> Config Class Initialized
INFO - 2018-05-15 02:34:15 --> Loader Class Initialized
DEBUG - 2018-05-15 02:34:15 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-15 02:34:15 --> Helper loaded: url_helper
INFO - 2018-05-15 02:34:15 --> Helper loaded: form_helper
INFO - 2018-05-15 02:34:15 --> Helper loaded: date_helper
INFO - 2018-05-15 02:34:15 --> Helper loaded: util_helper
INFO - 2018-05-15 02:34:15 --> Helper loaded: text_helper
INFO - 2018-05-15 02:34:15 --> Helper loaded: string_helper
INFO - 2018-05-15 02:34:15 --> Database Driver Class Initialized
DEBUG - 2018-05-15 02:34:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-15 02:34:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-15 02:34:15 --> Email Class Initialized
INFO - 2018-05-15 02:34:15 --> Controller Class Initialized
DEBUG - 2018-05-15 02:34:15 --> Login MX_Controller Initialized
INFO - 2018-05-15 02:34:15 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-15 02:34:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-15 02:34:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-15 02:34:15 --> Email starts for gopipanguluri123@gmail.com fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-05-15 02:34:15 --> User session created for 4
INFO - 2018-05-15 02:34:15 --> Login status gopipanguluri123@gmail.com - success
ERROR - 2018-05-15 02:34:15 --> Severity: Notice --> Undefined variable: data E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php 311
INFO - 2018-05-15 02:34:15 --> Final output sent to browser
DEBUG - 2018-05-15 02:34:15 --> Total execution time: 0.3276
INFO - 2018-05-15 02:34:16 --> Config Class Initialized
INFO - 2018-05-15 02:34:16 --> Hooks Class Initialized
DEBUG - 2018-05-15 02:34:16 --> UTF-8 Support Enabled
INFO - 2018-05-15 02:34:16 --> Utf8 Class Initialized
INFO - 2018-05-15 02:34:16 --> URI Class Initialized
INFO - 2018-05-15 02:34:16 --> Router Class Initialized
INFO - 2018-05-15 02:34:16 --> Output Class Initialized
INFO - 2018-05-15 02:34:16 --> Security Class Initialized
DEBUG - 2018-05-15 02:34:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 02:34:16 --> Input Class Initialized
INFO - 2018-05-15 02:34:16 --> Language Class Initialized
INFO - 2018-05-15 02:34:16 --> Language Class Initialized
INFO - 2018-05-15 02:34:16 --> Config Class Initialized
INFO - 2018-05-15 02:34:16 --> Loader Class Initialized
DEBUG - 2018-05-15 02:34:16 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-15 02:34:16 --> Helper loaded: url_helper
INFO - 2018-05-15 02:34:16 --> Helper loaded: form_helper
INFO - 2018-05-15 02:34:16 --> Helper loaded: date_helper
INFO - 2018-05-15 02:34:16 --> Config Class Initialized
INFO - 2018-05-15 02:34:16 --> Hooks Class Initialized
INFO - 2018-05-15 02:34:16 --> Helper loaded: util_helper
INFO - 2018-05-15 02:34:16 --> Helper loaded: text_helper
DEBUG - 2018-05-15 02:34:16 --> UTF-8 Support Enabled
INFO - 2018-05-15 02:34:16 --> Utf8 Class Initialized
INFO - 2018-05-15 02:34:16 --> Helper loaded: string_helper
INFO - 2018-05-15 02:34:16 --> URI Class Initialized
INFO - 2018-05-15 02:34:16 --> Database Driver Class Initialized
INFO - 2018-05-15 02:34:16 --> Router Class Initialized
DEBUG - 2018-05-15 02:34:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-15 02:34:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-15 02:34:16 --> Output Class Initialized
INFO - 2018-05-15 02:34:16 --> Security Class Initialized
INFO - 2018-05-15 02:34:16 --> Email Class Initialized
INFO - 2018-05-15 02:34:16 --> Controller Class Initialized
DEBUG - 2018-05-15 02:34:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 02:34:16 --> Input Class Initialized
DEBUG - 2018-05-15 02:34:16 --> Login MX_Controller Initialized
INFO - 2018-05-15 02:34:16 --> Language file loaded: language/english/data_lang.php
INFO - 2018-05-15 02:34:16 --> Language Class Initialized
DEBUG - 2018-05-15 02:34:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-05-15 02:34:16 --> Language Class Initialized
INFO - 2018-05-15 02:34:16 --> Config Class Initialized
DEBUG - 2018-05-15 02:34:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-15 02:34:16 --> Loader Class Initialized
INFO - 2018-05-15 02:34:16 --> Email starts for gopipanguluri123@gmail.com fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
DEBUG - 2018-05-15 02:34:16 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-15 02:34:16 --> User session created for 4
INFO - 2018-05-15 02:34:16 --> Helper loaded: url_helper
INFO - 2018-05-15 02:34:16 --> Helper loaded: form_helper
INFO - 2018-05-15 02:34:16 --> Helper loaded: date_helper
INFO - 2018-05-15 02:34:16 --> Helper loaded: util_helper
INFO - 2018-05-15 02:34:16 --> Helper loaded: text_helper
INFO - 2018-05-15 02:34:16 --> Login status gopipanguluri123@gmail.com - success
INFO - 2018-05-15 02:34:16 --> Config Class Initialized
INFO - 2018-05-15 02:34:16 --> Hooks Class Initialized
ERROR - 2018-05-15 02:34:16 --> Severity: Notice --> Undefined variable: data E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php 311
INFO - 2018-05-15 02:34:16 --> Helper loaded: string_helper
INFO - 2018-05-15 02:34:16 --> Final output sent to browser
DEBUG - 2018-05-15 02:34:16 --> UTF-8 Support Enabled
INFO - 2018-05-15 02:34:16 --> Database Driver Class Initialized
DEBUG - 2018-05-15 02:34:16 --> Total execution time: 0.3464
INFO - 2018-05-15 02:34:16 --> Utf8 Class Initialized
DEBUG - 2018-05-15 02:34:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-15 02:34:16 --> URI Class Initialized
INFO - 2018-05-15 02:34:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-15 02:34:16 --> Router Class Initialized
INFO - 2018-05-15 02:34:16 --> Email Class Initialized
INFO - 2018-05-15 02:34:16 --> Controller Class Initialized
INFO - 2018-05-15 02:34:16 --> Output Class Initialized
DEBUG - 2018-05-15 02:34:16 --> Login MX_Controller Initialized
INFO - 2018-05-15 02:34:16 --> Language file loaded: language/english/data_lang.php
INFO - 2018-05-15 02:34:16 --> Security Class Initialized
DEBUG - 2018-05-15 02:34:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-15 02:34:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 02:34:16 --> Input Class Initialized
DEBUG - 2018-05-15 02:34:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-15 02:34:16 --> Language Class Initialized
INFO - 2018-05-15 02:34:16 --> Email starts for gopipanguluri123@gmail.com fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-05-15 02:34:16 --> User session created for 4
INFO - 2018-05-15 02:34:16 --> Language Class Initialized
INFO - 2018-05-15 02:34:16 --> Config Class Initialized
INFO - 2018-05-15 02:34:16 --> Login status gopipanguluri123@gmail.com - success
ERROR - 2018-05-15 02:34:16 --> Severity: Notice --> Undefined variable: data E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php 311
INFO - 2018-05-15 02:34:16 --> Loader Class Initialized
INFO - 2018-05-15 02:34:16 --> Final output sent to browser
DEBUG - 2018-05-15 02:34:16 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
DEBUG - 2018-05-15 02:34:16 --> Total execution time: 0.3134
INFO - 2018-05-15 02:34:16 --> Helper loaded: url_helper
INFO - 2018-05-15 02:34:16 --> Helper loaded: form_helper
INFO - 2018-05-15 02:34:16 --> Config Class Initialized
INFO - 2018-05-15 02:34:16 --> Hooks Class Initialized
INFO - 2018-05-15 02:34:16 --> Helper loaded: date_helper
DEBUG - 2018-05-15 02:34:16 --> UTF-8 Support Enabled
INFO - 2018-05-15 02:34:16 --> Helper loaded: util_helper
INFO - 2018-05-15 02:34:16 --> Utf8 Class Initialized
INFO - 2018-05-15 02:34:16 --> URI Class Initialized
INFO - 2018-05-15 02:34:17 --> Router Class Initialized
INFO - 2018-05-15 02:34:17 --> Helper loaded: text_helper
INFO - 2018-05-15 02:34:17 --> Output Class Initialized
INFO - 2018-05-15 02:34:17 --> Security Class Initialized
DEBUG - 2018-05-15 02:34:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 02:34:17 --> Input Class Initialized
INFO - 2018-05-15 02:34:17 --> Language Class Initialized
INFO - 2018-05-15 02:34:17 --> Language Class Initialized
INFO - 2018-05-15 02:34:17 --> Config Class Initialized
INFO - 2018-05-15 02:34:17 --> Loader Class Initialized
INFO - 2018-05-15 02:34:17 --> Helper loaded: string_helper
DEBUG - 2018-05-15 02:34:17 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-15 02:34:17 --> Helper loaded: url_helper
INFO - 2018-05-15 02:34:17 --> Helper loaded: form_helper
INFO - 2018-05-15 02:34:17 --> Helper loaded: date_helper
INFO - 2018-05-15 02:34:17 --> Helper loaded: util_helper
INFO - 2018-05-15 02:34:17 --> Helper loaded: text_helper
INFO - 2018-05-15 02:34:17 --> Helper loaded: string_helper
INFO - 2018-05-15 02:34:17 --> Database Driver Class Initialized
INFO - 2018-05-15 02:34:17 --> Database Driver Class Initialized
DEBUG - 2018-05-15 02:34:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-05-15 02:34:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-15 02:34:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-15 02:34:17 --> Email Class Initialized
INFO - 2018-05-15 02:34:17 --> Controller Class Initialized
DEBUG - 2018-05-15 02:34:17 --> Login MX_Controller Initialized
INFO - 2018-05-15 02:34:17 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-15 02:34:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-15 02:34:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-15 02:34:17 --> Email starts for gopipanguluri123@gmail.com fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-05-15 02:34:17 --> User session created for 4
INFO - 2018-05-15 02:34:17 --> Login status gopipanguluri123@gmail.com - success
ERROR - 2018-05-15 02:34:17 --> Severity: Notice --> Undefined variable: data E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php 311
INFO - 2018-05-15 02:34:17 --> Final output sent to browser
DEBUG - 2018-05-15 02:34:17 --> Total execution time: 0.5179
INFO - 2018-05-15 02:34:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-15 02:34:17 --> Email Class Initialized
INFO - 2018-05-15 02:34:17 --> Controller Class Initialized
DEBUG - 2018-05-15 02:34:17 --> Login MX_Controller Initialized
INFO - 2018-05-15 02:34:17 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-15 02:34:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-15 02:34:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-15 02:34:17 --> Email starts for gopipanguluri123@gmail.com fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-05-15 02:34:17 --> User session created for 4
INFO - 2018-05-15 02:34:17 --> Login status gopipanguluri123@gmail.com - success
ERROR - 2018-05-15 02:34:17 --> Severity: Notice --> Undefined variable: data E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php 311
INFO - 2018-05-15 02:34:17 --> Final output sent to browser
DEBUG - 2018-05-15 02:34:17 --> Total execution time: 0.4578
INFO - 2018-05-15 02:34:22 --> Config Class Initialized
INFO - 2018-05-15 02:34:22 --> Hooks Class Initialized
DEBUG - 2018-05-15 02:34:22 --> UTF-8 Support Enabled
INFO - 2018-05-15 02:34:22 --> Utf8 Class Initialized
INFO - 2018-05-15 02:34:22 --> URI Class Initialized
INFO - 2018-05-15 02:34:22 --> Router Class Initialized
INFO - 2018-05-15 02:34:22 --> Output Class Initialized
INFO - 2018-05-15 02:34:22 --> Security Class Initialized
DEBUG - 2018-05-15 02:34:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 02:34:22 --> Input Class Initialized
INFO - 2018-05-15 02:34:22 --> Language Class Initialized
INFO - 2018-05-15 02:34:22 --> Language Class Initialized
INFO - 2018-05-15 02:34:22 --> Config Class Initialized
INFO - 2018-05-15 02:34:22 --> Loader Class Initialized
DEBUG - 2018-05-15 02:34:22 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-15 02:34:22 --> Helper loaded: url_helper
INFO - 2018-05-15 02:34:22 --> Helper loaded: form_helper
INFO - 2018-05-15 02:34:22 --> Helper loaded: date_helper
INFO - 2018-05-15 02:34:22 --> Helper loaded: util_helper
INFO - 2018-05-15 02:34:22 --> Helper loaded: text_helper
INFO - 2018-05-15 02:34:22 --> Helper loaded: string_helper
INFO - 2018-05-15 02:34:22 --> Database Driver Class Initialized
DEBUG - 2018-05-15 02:34:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-15 02:34:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-15 02:34:22 --> Email Class Initialized
INFO - 2018-05-15 02:34:22 --> Controller Class Initialized
DEBUG - 2018-05-15 02:34:22 --> Login MX_Controller Initialized
INFO - 2018-05-15 02:34:22 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-15 02:34:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-15 02:34:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-15 02:34:22 --> Email starts for gopipanguluri123@gmail.com fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-05-15 02:34:22 --> User session created for 4
INFO - 2018-05-15 02:34:22 --> Login status gopipanguluri123@gmail.com - success
ERROR - 2018-05-15 02:34:22 --> Severity: Notice --> Undefined variable: data E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php 311
INFO - 2018-05-15 02:34:22 --> Final output sent to browser
DEBUG - 2018-05-15 02:34:22 --> Total execution time: 0.3667
INFO - 2018-05-15 02:34:53 --> Config Class Initialized
INFO - 2018-05-15 02:34:53 --> Hooks Class Initialized
DEBUG - 2018-05-15 02:34:53 --> UTF-8 Support Enabled
INFO - 2018-05-15 02:34:53 --> Utf8 Class Initialized
INFO - 2018-05-15 02:34:53 --> URI Class Initialized
INFO - 2018-05-15 02:34:53 --> Router Class Initialized
INFO - 2018-05-15 02:34:53 --> Output Class Initialized
INFO - 2018-05-15 02:34:53 --> Security Class Initialized
DEBUG - 2018-05-15 02:34:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 02:34:53 --> Input Class Initialized
INFO - 2018-05-15 02:34:53 --> Language Class Initialized
INFO - 2018-05-15 02:34:53 --> Language Class Initialized
INFO - 2018-05-15 02:34:53 --> Config Class Initialized
INFO - 2018-05-15 02:34:53 --> Loader Class Initialized
DEBUG - 2018-05-15 02:34:53 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-15 02:34:53 --> Helper loaded: url_helper
INFO - 2018-05-15 02:34:53 --> Helper loaded: form_helper
INFO - 2018-05-15 02:34:53 --> Helper loaded: date_helper
INFO - 2018-05-15 02:34:53 --> Helper loaded: util_helper
INFO - 2018-05-15 02:34:53 --> Helper loaded: text_helper
INFO - 2018-05-15 02:34:53 --> Helper loaded: string_helper
INFO - 2018-05-15 02:34:53 --> Database Driver Class Initialized
DEBUG - 2018-05-15 02:34:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-15 02:34:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-15 02:34:53 --> Email Class Initialized
INFO - 2018-05-15 02:34:53 --> Controller Class Initialized
DEBUG - 2018-05-15 02:34:53 --> Login MX_Controller Initialized
INFO - 2018-05-15 02:34:53 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-15 02:34:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-15 02:34:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-15 02:34:53 --> Email starts for gopipanguluri123@gmail.com fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-05-15 02:34:53 --> User session created for 4
INFO - 2018-05-15 02:34:53 --> Login status gopipanguluri123@gmail.com - success
ERROR - 2018-05-15 02:34:53 --> Severity: Notice --> Undefined variable: data E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php 310
INFO - 2018-05-15 02:35:10 --> Config Class Initialized
INFO - 2018-05-15 02:35:10 --> Hooks Class Initialized
DEBUG - 2018-05-15 02:35:10 --> UTF-8 Support Enabled
INFO - 2018-05-15 02:35:10 --> Utf8 Class Initialized
INFO - 2018-05-15 02:35:10 --> URI Class Initialized
INFO - 2018-05-15 02:35:10 --> Router Class Initialized
INFO - 2018-05-15 02:35:10 --> Output Class Initialized
INFO - 2018-05-15 02:35:10 --> Security Class Initialized
DEBUG - 2018-05-15 02:35:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 02:35:10 --> Input Class Initialized
INFO - 2018-05-15 02:35:10 --> Language Class Initialized
INFO - 2018-05-15 02:35:10 --> Language Class Initialized
INFO - 2018-05-15 02:35:10 --> Config Class Initialized
INFO - 2018-05-15 02:35:10 --> Loader Class Initialized
DEBUG - 2018-05-15 02:35:10 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-15 02:35:10 --> Helper loaded: url_helper
INFO - 2018-05-15 02:35:10 --> Helper loaded: form_helper
INFO - 2018-05-15 02:35:10 --> Helper loaded: date_helper
INFO - 2018-05-15 02:35:10 --> Helper loaded: util_helper
INFO - 2018-05-15 02:35:10 --> Helper loaded: text_helper
INFO - 2018-05-15 02:35:10 --> Helper loaded: string_helper
INFO - 2018-05-15 02:35:10 --> Database Driver Class Initialized
DEBUG - 2018-05-15 02:35:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-15 02:35:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-15 02:35:11 --> Email Class Initialized
INFO - 2018-05-15 02:35:11 --> Controller Class Initialized
DEBUG - 2018-05-15 02:35:11 --> Login MX_Controller Initialized
INFO - 2018-05-15 02:35:11 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-15 02:35:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-15 02:35:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-15 02:35:11 --> Email starts for gopipanguluri123@gmail.com fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-05-15 02:35:11 --> User session created for 4
INFO - 2018-05-15 02:35:11 --> Login status gopipanguluri123@gmail.com - success
INFO - 2018-05-15 02:37:08 --> Config Class Initialized
INFO - 2018-05-15 02:37:08 --> Hooks Class Initialized
DEBUG - 2018-05-15 02:37:08 --> UTF-8 Support Enabled
INFO - 2018-05-15 02:37:08 --> Utf8 Class Initialized
INFO - 2018-05-15 02:37:08 --> URI Class Initialized
INFO - 2018-05-15 02:37:08 --> Router Class Initialized
INFO - 2018-05-15 02:37:08 --> Output Class Initialized
INFO - 2018-05-15 02:37:08 --> Security Class Initialized
DEBUG - 2018-05-15 02:37:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 02:37:08 --> Input Class Initialized
INFO - 2018-05-15 02:37:08 --> Language Class Initialized
INFO - 2018-05-15 02:37:08 --> Language Class Initialized
INFO - 2018-05-15 02:37:08 --> Config Class Initialized
INFO - 2018-05-15 02:37:08 --> Loader Class Initialized
DEBUG - 2018-05-15 02:37:08 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-15 02:37:08 --> Helper loaded: url_helper
INFO - 2018-05-15 02:37:08 --> Helper loaded: form_helper
INFO - 2018-05-15 02:37:08 --> Helper loaded: date_helper
INFO - 2018-05-15 02:37:08 --> Helper loaded: util_helper
INFO - 2018-05-15 02:37:08 --> Helper loaded: text_helper
INFO - 2018-05-15 02:37:08 --> Helper loaded: string_helper
INFO - 2018-05-15 02:37:08 --> Database Driver Class Initialized
DEBUG - 2018-05-15 02:37:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-15 02:37:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-15 02:37:08 --> Email Class Initialized
INFO - 2018-05-15 02:37:08 --> Controller Class Initialized
DEBUG - 2018-05-15 02:37:08 --> Login MX_Controller Initialized
INFO - 2018-05-15 02:37:08 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-15 02:37:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-15 02:37:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-15 02:37:08 --> Email starts for gopipanguluri123@gmail.com fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-05-15 02:37:08 --> User session created for 4
INFO - 2018-05-15 02:37:09 --> Login status gopipanguluri123@gmail.com - success
INFO - 2018-05-15 02:37:33 --> Config Class Initialized
INFO - 2018-05-15 02:37:33 --> Hooks Class Initialized
DEBUG - 2018-05-15 02:37:33 --> UTF-8 Support Enabled
INFO - 2018-05-15 02:37:33 --> Utf8 Class Initialized
INFO - 2018-05-15 02:37:33 --> URI Class Initialized
INFO - 2018-05-15 02:37:33 --> Router Class Initialized
INFO - 2018-05-15 02:37:33 --> Output Class Initialized
INFO - 2018-05-15 02:37:33 --> Security Class Initialized
DEBUG - 2018-05-15 02:37:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 02:37:33 --> Input Class Initialized
INFO - 2018-05-15 02:37:33 --> Language Class Initialized
INFO - 2018-05-15 02:37:33 --> Language Class Initialized
INFO - 2018-05-15 02:37:33 --> Config Class Initialized
INFO - 2018-05-15 02:37:33 --> Loader Class Initialized
DEBUG - 2018-05-15 02:37:33 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-15 02:37:33 --> Helper loaded: url_helper
INFO - 2018-05-15 02:37:33 --> Helper loaded: form_helper
INFO - 2018-05-15 02:37:33 --> Helper loaded: date_helper
INFO - 2018-05-15 02:37:33 --> Helper loaded: util_helper
INFO - 2018-05-15 02:37:33 --> Helper loaded: text_helper
INFO - 2018-05-15 02:37:33 --> Helper loaded: string_helper
INFO - 2018-05-15 02:37:33 --> Database Driver Class Initialized
DEBUG - 2018-05-15 02:37:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-15 02:37:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-15 02:37:33 --> Email Class Initialized
INFO - 2018-05-15 02:37:33 --> Controller Class Initialized
DEBUG - 2018-05-15 02:37:33 --> Login MX_Controller Initialized
INFO - 2018-05-15 02:37:33 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-15 02:37:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-15 02:37:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-15 02:37:33 --> Email starts for gopipanguluri123@gmail.com fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-05-15 02:37:33 --> User session created for 4
INFO - 2018-05-15 02:37:33 --> Login status gopipanguluri123@gmail.com - success
INFO - 2018-05-15 02:38:38 --> Config Class Initialized
INFO - 2018-05-15 02:38:38 --> Hooks Class Initialized
DEBUG - 2018-05-15 02:38:38 --> UTF-8 Support Enabled
INFO - 2018-05-15 02:38:38 --> Utf8 Class Initialized
INFO - 2018-05-15 02:38:38 --> URI Class Initialized
INFO - 2018-05-15 02:38:38 --> Router Class Initialized
INFO - 2018-05-15 02:38:38 --> Output Class Initialized
INFO - 2018-05-15 02:38:38 --> Security Class Initialized
DEBUG - 2018-05-15 02:38:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 02:38:38 --> Input Class Initialized
INFO - 2018-05-15 02:38:38 --> Language Class Initialized
INFO - 2018-05-15 02:38:38 --> Language Class Initialized
INFO - 2018-05-15 02:38:38 --> Config Class Initialized
INFO - 2018-05-15 02:38:38 --> Loader Class Initialized
DEBUG - 2018-05-15 02:38:38 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-15 02:38:38 --> Helper loaded: url_helper
INFO - 2018-05-15 02:38:38 --> Helper loaded: form_helper
INFO - 2018-05-15 02:38:38 --> Helper loaded: date_helper
INFO - 2018-05-15 02:38:38 --> Helper loaded: util_helper
INFO - 2018-05-15 02:38:38 --> Helper loaded: text_helper
INFO - 2018-05-15 02:38:38 --> Helper loaded: string_helper
INFO - 2018-05-15 02:38:38 --> Database Driver Class Initialized
DEBUG - 2018-05-15 02:38:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-15 02:38:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-15 02:38:38 --> Email Class Initialized
INFO - 2018-05-15 02:38:38 --> Controller Class Initialized
DEBUG - 2018-05-15 02:38:38 --> Login MX_Controller Initialized
INFO - 2018-05-15 02:38:38 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-15 02:38:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-15 02:38:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-15 02:38:38 --> Email starts for gopipanguluri123@gmail.com fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-05-15 02:38:38 --> User session created for 4
INFO - 2018-05-15 02:38:38 --> Login status gopipanguluri123@gmail.com - success
INFO - 2018-05-15 02:38:47 --> Config Class Initialized
INFO - 2018-05-15 02:38:47 --> Hooks Class Initialized
DEBUG - 2018-05-15 02:38:47 --> UTF-8 Support Enabled
INFO - 2018-05-15 02:38:47 --> Utf8 Class Initialized
INFO - 2018-05-15 02:38:47 --> URI Class Initialized
INFO - 2018-05-15 02:38:47 --> Router Class Initialized
INFO - 2018-05-15 02:38:47 --> Output Class Initialized
INFO - 2018-05-15 02:38:47 --> Security Class Initialized
DEBUG - 2018-05-15 02:38:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 02:38:47 --> Input Class Initialized
INFO - 2018-05-15 02:38:47 --> Language Class Initialized
INFO - 2018-05-15 02:38:47 --> Language Class Initialized
INFO - 2018-05-15 02:38:47 --> Config Class Initialized
INFO - 2018-05-15 02:38:47 --> Loader Class Initialized
DEBUG - 2018-05-15 02:38:47 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-15 02:38:47 --> Helper loaded: url_helper
INFO - 2018-05-15 02:38:47 --> Helper loaded: form_helper
INFO - 2018-05-15 02:38:47 --> Helper loaded: date_helper
INFO - 2018-05-15 02:38:47 --> Helper loaded: util_helper
INFO - 2018-05-15 02:38:47 --> Helper loaded: text_helper
INFO - 2018-05-15 02:38:47 --> Helper loaded: string_helper
INFO - 2018-05-15 02:38:47 --> Database Driver Class Initialized
DEBUG - 2018-05-15 02:38:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-15 02:38:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-15 02:38:47 --> Email Class Initialized
INFO - 2018-05-15 02:38:47 --> Controller Class Initialized
DEBUG - 2018-05-15 02:38:47 --> Login MX_Controller Initialized
INFO - 2018-05-15 02:38:47 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-15 02:38:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-15 02:38:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-15 02:38:47 --> Email starts for gopipanguluri123@gmail.com fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-05-15 02:38:47 --> User session created for 4
INFO - 2018-05-15 02:38:47 --> Login status gopipanguluri123@gmail.com - success
INFO - 2018-05-15 02:38:47 --> Final output sent to browser
DEBUG - 2018-05-15 02:38:47 --> Total execution time: 0.3226
INFO - 2018-05-15 02:38:47 --> Config Class Initialized
INFO - 2018-05-15 02:38:47 --> Hooks Class Initialized
DEBUG - 2018-05-15 02:38:47 --> UTF-8 Support Enabled
INFO - 2018-05-15 02:38:47 --> Utf8 Class Initialized
INFO - 2018-05-15 02:38:47 --> URI Class Initialized
INFO - 2018-05-15 02:38:47 --> Router Class Initialized
INFO - 2018-05-15 02:38:47 --> Output Class Initialized
INFO - 2018-05-15 02:38:47 --> Security Class Initialized
DEBUG - 2018-05-15 02:38:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 02:38:48 --> Input Class Initialized
INFO - 2018-05-15 02:38:48 --> Language Class Initialized
INFO - 2018-05-15 02:38:48 --> Language Class Initialized
INFO - 2018-05-15 02:38:48 --> Config Class Initialized
INFO - 2018-05-15 02:38:48 --> Loader Class Initialized
DEBUG - 2018-05-15 02:38:48 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-15 02:38:48 --> Helper loaded: url_helper
INFO - 2018-05-15 02:38:48 --> Helper loaded: form_helper
INFO - 2018-05-15 02:38:48 --> Helper loaded: date_helper
INFO - 2018-05-15 02:38:48 --> Helper loaded: util_helper
INFO - 2018-05-15 02:38:48 --> Helper loaded: text_helper
INFO - 2018-05-15 02:38:48 --> Helper loaded: string_helper
INFO - 2018-05-15 02:38:48 --> Database Driver Class Initialized
DEBUG - 2018-05-15 02:38:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-15 02:38:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-15 02:38:48 --> Email Class Initialized
INFO - 2018-05-15 02:38:48 --> Controller Class Initialized
DEBUG - 2018-05-15 02:38:48 --> Home MX_Controller Initialized
DEBUG - 2018-05-15 02:38:48 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-15 02:38:48 --> Login MX_Controller Initialized
INFO - 2018-05-15 02:38:48 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-15 02:38:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-15 02:38:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
ERROR - 2018-05-15 02:38:48 --> Severity: Notice --> Undefined property: CI::$home_model E:\xampp\htdocs\consulting\application\third_party\MX\Controller.php 59
ERROR - 2018-05-15 02:38:48 --> Severity: error --> Exception: Call to a member function get_programs_list() on null E:\xampp\htdocs\consulting\application\modules\home\controllers\Home.php 14
INFO - 2018-05-15 02:39:20 --> Config Class Initialized
INFO - 2018-05-15 02:39:20 --> Hooks Class Initialized
DEBUG - 2018-05-15 02:39:20 --> UTF-8 Support Enabled
INFO - 2018-05-15 02:39:20 --> Utf8 Class Initialized
INFO - 2018-05-15 02:39:20 --> URI Class Initialized
INFO - 2018-05-15 02:39:20 --> Router Class Initialized
INFO - 2018-05-15 02:39:20 --> Output Class Initialized
INFO - 2018-05-15 02:39:20 --> Security Class Initialized
DEBUG - 2018-05-15 02:39:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 02:39:20 --> Input Class Initialized
INFO - 2018-05-15 02:39:20 --> Language Class Initialized
INFO - 2018-05-15 02:39:20 --> Language Class Initialized
INFO - 2018-05-15 02:39:20 --> Config Class Initialized
INFO - 2018-05-15 02:39:20 --> Loader Class Initialized
DEBUG - 2018-05-15 02:39:20 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-15 02:39:21 --> Helper loaded: url_helper
INFO - 2018-05-15 02:39:21 --> Helper loaded: form_helper
INFO - 2018-05-15 02:39:21 --> Helper loaded: date_helper
INFO - 2018-05-15 02:39:21 --> Helper loaded: util_helper
INFO - 2018-05-15 02:39:21 --> Helper loaded: text_helper
INFO - 2018-05-15 02:39:21 --> Helper loaded: string_helper
INFO - 2018-05-15 02:39:21 --> Database Driver Class Initialized
DEBUG - 2018-05-15 02:39:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-15 02:39:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-15 02:39:21 --> Email Class Initialized
INFO - 2018-05-15 02:39:21 --> Controller Class Initialized
DEBUG - 2018-05-15 02:39:21 --> Home MX_Controller Initialized
DEBUG - 2018-05-15 02:39:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-15 02:39:21 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-15 02:39:21 --> Login MX_Controller Initialized
INFO - 2018-05-15 02:39:21 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-15 02:39:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-15 02:39:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-15 02:39:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-05-15 02:39:21 --> Final output sent to browser
INFO - 2018-05-15 02:39:21 --> Config Class Initialized
INFO - 2018-05-15 02:39:21 --> Hooks Class Initialized
DEBUG - 2018-05-15 02:39:21 --> Total execution time: 0.3556
DEBUG - 2018-05-15 02:39:21 --> UTF-8 Support Enabled
INFO - 2018-05-15 02:39:21 --> Utf8 Class Initialized
INFO - 2018-05-15 02:39:21 --> URI Class Initialized
INFO - 2018-05-15 02:39:21 --> Router Class Initialized
INFO - 2018-05-15 02:39:21 --> Output Class Initialized
INFO - 2018-05-15 02:39:21 --> Security Class Initialized
DEBUG - 2018-05-15 02:39:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 02:39:21 --> Input Class Initialized
INFO - 2018-05-15 02:39:21 --> Language Class Initialized
ERROR - 2018-05-15 02:39:21 --> 404 Page Not Found: /index
INFO - 2018-05-15 02:39:21 --> Config Class Initialized
INFO - 2018-05-15 02:39:21 --> Hooks Class Initialized
DEBUG - 2018-05-15 02:39:21 --> UTF-8 Support Enabled
INFO - 2018-05-15 02:39:21 --> Utf8 Class Initialized
INFO - 2018-05-15 02:39:21 --> URI Class Initialized
INFO - 2018-05-15 02:39:21 --> Router Class Initialized
INFO - 2018-05-15 02:39:21 --> Output Class Initialized
INFO - 2018-05-15 02:39:21 --> Security Class Initialized
DEBUG - 2018-05-15 02:39:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 02:39:21 --> Input Class Initialized
INFO - 2018-05-15 02:39:21 --> Language Class Initialized
ERROR - 2018-05-15 02:39:21 --> 404 Page Not Found: /index
INFO - 2018-05-15 02:39:21 --> Config Class Initialized
INFO - 2018-05-15 02:39:21 --> Config Class Initialized
INFO - 2018-05-15 02:39:21 --> Config Class Initialized
INFO - 2018-05-15 02:39:21 --> Config Class Initialized
INFO - 2018-05-15 02:39:21 --> Config Class Initialized
INFO - 2018-05-15 02:39:21 --> Config Class Initialized
INFO - 2018-05-15 02:39:21 --> Hooks Class Initialized
INFO - 2018-05-15 02:39:21 --> Hooks Class Initialized
INFO - 2018-05-15 02:39:21 --> Hooks Class Initialized
INFO - 2018-05-15 02:39:21 --> Hooks Class Initialized
INFO - 2018-05-15 02:39:21 --> Hooks Class Initialized
INFO - 2018-05-15 02:39:21 --> Hooks Class Initialized
DEBUG - 2018-05-15 02:39:21 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 02:39:21 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 02:39:21 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 02:39:21 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 02:39:21 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 02:39:21 --> UTF-8 Support Enabled
INFO - 2018-05-15 02:39:21 --> Utf8 Class Initialized
INFO - 2018-05-15 02:39:21 --> Utf8 Class Initialized
INFO - 2018-05-15 02:39:21 --> Utf8 Class Initialized
INFO - 2018-05-15 02:39:21 --> Utf8 Class Initialized
INFO - 2018-05-15 02:39:21 --> Utf8 Class Initialized
INFO - 2018-05-15 02:39:21 --> Utf8 Class Initialized
INFO - 2018-05-15 02:39:21 --> URI Class Initialized
INFO - 2018-05-15 02:39:21 --> URI Class Initialized
INFO - 2018-05-15 02:39:21 --> URI Class Initialized
INFO - 2018-05-15 02:39:21 --> URI Class Initialized
INFO - 2018-05-15 02:39:21 --> URI Class Initialized
INFO - 2018-05-15 02:39:21 --> URI Class Initialized
INFO - 2018-05-15 02:39:21 --> Router Class Initialized
INFO - 2018-05-15 02:39:21 --> Router Class Initialized
INFO - 2018-05-15 02:39:21 --> Router Class Initialized
INFO - 2018-05-15 02:39:21 --> Router Class Initialized
INFO - 2018-05-15 02:39:21 --> Router Class Initialized
INFO - 2018-05-15 02:39:21 --> Router Class Initialized
INFO - 2018-05-15 02:39:22 --> Output Class Initialized
INFO - 2018-05-15 02:39:22 --> Output Class Initialized
INFO - 2018-05-15 02:39:22 --> Output Class Initialized
INFO - 2018-05-15 02:39:22 --> Output Class Initialized
INFO - 2018-05-15 02:39:22 --> Output Class Initialized
INFO - 2018-05-15 02:39:22 --> Output Class Initialized
INFO - 2018-05-15 02:39:22 --> Security Class Initialized
INFO - 2018-05-15 02:39:22 --> Security Class Initialized
INFO - 2018-05-15 02:39:22 --> Security Class Initialized
INFO - 2018-05-15 02:39:22 --> Security Class Initialized
INFO - 2018-05-15 02:39:22 --> Security Class Initialized
INFO - 2018-05-15 02:39:22 --> Security Class Initialized
DEBUG - 2018-05-15 02:39:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 02:39:22 --> Input Class Initialized
DEBUG - 2018-05-15 02:39:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-15 02:39:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-15 02:39:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-15 02:39:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-15 02:39:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 02:39:22 --> Language Class Initialized
INFO - 2018-05-15 02:39:22 --> Input Class Initialized
INFO - 2018-05-15 02:39:22 --> Input Class Initialized
ERROR - 2018-05-15 02:39:22 --> 404 Page Not Found: /index
INFO - 2018-05-15 02:39:22 --> Input Class Initialized
INFO - 2018-05-15 02:39:22 --> Input Class Initialized
INFO - 2018-05-15 02:39:22 --> Input Class Initialized
INFO - 2018-05-15 02:39:22 --> Language Class Initialized
INFO - 2018-05-15 02:39:22 --> Language Class Initialized
INFO - 2018-05-15 02:39:22 --> Language Class Initialized
ERROR - 2018-05-15 02:39:22 --> 404 Page Not Found: /index
INFO - 2018-05-15 02:39:22 --> Language Class Initialized
INFO - 2018-05-15 02:39:22 --> Language Class Initialized
ERROR - 2018-05-15 02:39:22 --> 404 Page Not Found: /index
ERROR - 2018-05-15 02:39:22 --> 404 Page Not Found: /index
ERROR - 2018-05-15 02:39:22 --> 404 Page Not Found: /index
ERROR - 2018-05-15 02:39:22 --> 404 Page Not Found: /index
INFO - 2018-05-15 02:39:22 --> Config Class Initialized
INFO - 2018-05-15 02:39:22 --> Config Class Initialized
INFO - 2018-05-15 02:39:22 --> Config Class Initialized
INFO - 2018-05-15 02:39:22 --> Config Class Initialized
INFO - 2018-05-15 02:39:22 --> Config Class Initialized
INFO - 2018-05-15 02:39:22 --> Hooks Class Initialized
INFO - 2018-05-15 02:39:22 --> Hooks Class Initialized
INFO - 2018-05-15 02:39:22 --> Hooks Class Initialized
INFO - 2018-05-15 02:39:22 --> Hooks Class Initialized
INFO - 2018-05-15 02:39:22 --> Hooks Class Initialized
DEBUG - 2018-05-15 02:39:22 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 02:39:22 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 02:39:22 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 02:39:22 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 02:39:22 --> UTF-8 Support Enabled
INFO - 2018-05-15 02:39:22 --> Utf8 Class Initialized
INFO - 2018-05-15 02:39:22 --> Utf8 Class Initialized
INFO - 2018-05-15 02:39:22 --> Utf8 Class Initialized
INFO - 2018-05-15 02:39:22 --> Utf8 Class Initialized
INFO - 2018-05-15 02:39:22 --> Utf8 Class Initialized
INFO - 2018-05-15 02:39:22 --> URI Class Initialized
INFO - 2018-05-15 02:39:22 --> URI Class Initialized
INFO - 2018-05-15 02:39:22 --> URI Class Initialized
INFO - 2018-05-15 02:39:22 --> URI Class Initialized
INFO - 2018-05-15 02:39:22 --> URI Class Initialized
INFO - 2018-05-15 02:39:22 --> Router Class Initialized
INFO - 2018-05-15 02:39:22 --> Router Class Initialized
INFO - 2018-05-15 02:39:22 --> Router Class Initialized
INFO - 2018-05-15 02:39:22 --> Router Class Initialized
INFO - 2018-05-15 02:39:22 --> Router Class Initialized
INFO - 2018-05-15 02:39:22 --> Output Class Initialized
INFO - 2018-05-15 02:39:22 --> Output Class Initialized
INFO - 2018-05-15 02:39:22 --> Output Class Initialized
INFO - 2018-05-15 02:39:22 --> Output Class Initialized
INFO - 2018-05-15 02:39:22 --> Output Class Initialized
INFO - 2018-05-15 02:39:22 --> Security Class Initialized
INFO - 2018-05-15 02:39:22 --> Security Class Initialized
INFO - 2018-05-15 02:39:22 --> Security Class Initialized
INFO - 2018-05-15 02:39:22 --> Security Class Initialized
INFO - 2018-05-15 02:39:22 --> Security Class Initialized
DEBUG - 2018-05-15 02:39:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-15 02:39:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-15 02:39:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-15 02:39:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-15 02:39:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 02:39:22 --> Input Class Initialized
INFO - 2018-05-15 02:39:22 --> Language Class Initialized
INFO - 2018-05-15 02:39:22 --> Input Class Initialized
ERROR - 2018-05-15 02:39:22 --> 404 Page Not Found: /index
INFO - 2018-05-15 02:39:22 --> Input Class Initialized
INFO - 2018-05-15 02:39:22 --> Input Class Initialized
INFO - 2018-05-15 02:39:22 --> Language Class Initialized
INFO - 2018-05-15 02:39:22 --> Input Class Initialized
INFO - 2018-05-15 02:39:22 --> Language Class Initialized
INFO - 2018-05-15 02:39:22 --> Config Class Initialized
INFO - 2018-05-15 02:39:22 --> Hooks Class Initialized
ERROR - 2018-05-15 02:39:22 --> 404 Page Not Found: /index
INFO - 2018-05-15 02:39:22 --> Language Class Initialized
ERROR - 2018-05-15 02:39:22 --> 404 Page Not Found: /index
INFO - 2018-05-15 02:39:22 --> Language Class Initialized
DEBUG - 2018-05-15 02:39:22 --> UTF-8 Support Enabled
ERROR - 2018-05-15 02:39:22 --> 404 Page Not Found: /index
ERROR - 2018-05-15 02:39:22 --> 404 Page Not Found: /index
INFO - 2018-05-15 02:39:22 --> Utf8 Class Initialized
INFO - 2018-05-15 02:39:22 --> Config Class Initialized
INFO - 2018-05-15 02:39:22 --> Config Class Initialized
INFO - 2018-05-15 02:39:22 --> Config Class Initialized
INFO - 2018-05-15 02:39:22 --> Config Class Initialized
INFO - 2018-05-15 02:39:22 --> Hooks Class Initialized
INFO - 2018-05-15 02:39:22 --> Hooks Class Initialized
INFO - 2018-05-15 02:39:22 --> Hooks Class Initialized
INFO - 2018-05-15 02:39:22 --> Hooks Class Initialized
INFO - 2018-05-15 02:39:22 --> URI Class Initialized
DEBUG - 2018-05-15 02:39:22 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 02:39:22 --> UTF-8 Support Enabled
INFO - 2018-05-15 02:39:22 --> Router Class Initialized
DEBUG - 2018-05-15 02:39:22 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 02:39:22 --> UTF-8 Support Enabled
INFO - 2018-05-15 02:39:22 --> Utf8 Class Initialized
INFO - 2018-05-15 02:39:22 --> Utf8 Class Initialized
INFO - 2018-05-15 02:39:22 --> Utf8 Class Initialized
INFO - 2018-05-15 02:39:22 --> Output Class Initialized
INFO - 2018-05-15 02:39:22 --> Utf8 Class Initialized
INFO - 2018-05-15 02:39:22 --> Security Class Initialized
INFO - 2018-05-15 02:39:22 --> URI Class Initialized
INFO - 2018-05-15 02:39:22 --> URI Class Initialized
INFO - 2018-05-15 02:39:22 --> URI Class Initialized
INFO - 2018-05-15 02:39:22 --> Router Class Initialized
DEBUG - 2018-05-15 02:39:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 02:39:22 --> Router Class Initialized
INFO - 2018-05-15 02:39:22 --> Router Class Initialized
INFO - 2018-05-15 02:39:22 --> URI Class Initialized
INFO - 2018-05-15 02:39:22 --> Output Class Initialized
INFO - 2018-05-15 02:39:22 --> Security Class Initialized
INFO - 2018-05-15 02:39:22 --> Output Class Initialized
INFO - 2018-05-15 02:39:22 --> Input Class Initialized
INFO - 2018-05-15 02:39:22 --> Output Class Initialized
INFO - 2018-05-15 02:39:22 --> Router Class Initialized
INFO - 2018-05-15 02:39:22 --> Language Class Initialized
INFO - 2018-05-15 02:39:22 --> Security Class Initialized
DEBUG - 2018-05-15 02:39:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 02:39:22 --> Security Class Initialized
INFO - 2018-05-15 02:39:22 --> Output Class Initialized
ERROR - 2018-05-15 02:39:22 --> 404 Page Not Found: /index
DEBUG - 2018-05-15 02:39:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 02:39:22 --> Security Class Initialized
INFO - 2018-05-15 02:39:22 --> Input Class Initialized
DEBUG - 2018-05-15 02:39:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 02:39:22 --> Input Class Initialized
DEBUG - 2018-05-15 02:39:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 02:39:22 --> Language Class Initialized
INFO - 2018-05-15 02:39:23 --> Language Class Initialized
INFO - 2018-05-15 02:39:23 --> Input Class Initialized
ERROR - 2018-05-15 02:39:23 --> 404 Page Not Found: /index
INFO - 2018-05-15 02:39:23 --> Input Class Initialized
INFO - 2018-05-15 02:39:23 --> Language Class Initialized
ERROR - 2018-05-15 02:39:23 --> 404 Page Not Found: /index
INFO - 2018-05-15 02:39:23 --> Language Class Initialized
ERROR - 2018-05-15 02:39:23 --> 404 Page Not Found: /index
ERROR - 2018-05-15 02:39:23 --> 404 Page Not Found: /index
INFO - 2018-05-15 02:39:26 --> Config Class Initialized
INFO - 2018-05-15 02:39:26 --> Hooks Class Initialized
DEBUG - 2018-05-15 02:39:26 --> UTF-8 Support Enabled
INFO - 2018-05-15 02:39:26 --> Utf8 Class Initialized
INFO - 2018-05-15 02:39:26 --> URI Class Initialized
INFO - 2018-05-15 02:39:26 --> Router Class Initialized
INFO - 2018-05-15 02:39:26 --> Output Class Initialized
INFO - 2018-05-15 02:39:26 --> Security Class Initialized
DEBUG - 2018-05-15 02:39:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 02:39:26 --> Input Class Initialized
INFO - 2018-05-15 02:39:26 --> Language Class Initialized
ERROR - 2018-05-15 02:39:26 --> 404 Page Not Found: /index
INFO - 2018-05-15 02:39:26 --> Config Class Initialized
INFO - 2018-05-15 02:39:26 --> Hooks Class Initialized
DEBUG - 2018-05-15 02:39:26 --> UTF-8 Support Enabled
INFO - 2018-05-15 02:39:26 --> Utf8 Class Initialized
INFO - 2018-05-15 02:39:26 --> URI Class Initialized
INFO - 2018-05-15 02:39:26 --> Router Class Initialized
INFO - 2018-05-15 02:39:26 --> Output Class Initialized
INFO - 2018-05-15 02:39:26 --> Security Class Initialized
DEBUG - 2018-05-15 02:39:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 02:39:26 --> Input Class Initialized
INFO - 2018-05-15 02:39:26 --> Language Class Initialized
ERROR - 2018-05-15 02:39:26 --> 404 Page Not Found: /index
INFO - 2018-05-15 02:39:26 --> Config Class Initialized
INFO - 2018-05-15 02:39:26 --> Hooks Class Initialized
DEBUG - 2018-05-15 02:39:26 --> UTF-8 Support Enabled
INFO - 2018-05-15 02:39:26 --> Utf8 Class Initialized
INFO - 2018-05-15 02:39:26 --> URI Class Initialized
INFO - 2018-05-15 02:39:26 --> Router Class Initialized
INFO - 2018-05-15 02:39:26 --> Output Class Initialized
INFO - 2018-05-15 02:39:26 --> Security Class Initialized
DEBUG - 2018-05-15 02:39:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 02:39:26 --> Input Class Initialized
INFO - 2018-05-15 02:39:26 --> Language Class Initialized
ERROR - 2018-05-15 02:39:26 --> 404 Page Not Found: /index
INFO - 2018-05-15 02:39:27 --> Config Class Initialized
INFO - 2018-05-15 02:39:27 --> Hooks Class Initialized
DEBUG - 2018-05-15 02:39:28 --> UTF-8 Support Enabled
INFO - 2018-05-15 02:39:28 --> Utf8 Class Initialized
INFO - 2018-05-15 02:39:28 --> URI Class Initialized
INFO - 2018-05-15 02:39:28 --> Router Class Initialized
INFO - 2018-05-15 02:39:28 --> Output Class Initialized
INFO - 2018-05-15 02:39:28 --> Security Class Initialized
DEBUG - 2018-05-15 02:39:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 02:39:28 --> Input Class Initialized
INFO - 2018-05-15 02:39:28 --> Language Class Initialized
ERROR - 2018-05-15 02:39:28 --> 404 Page Not Found: /index
INFO - 2018-05-15 02:41:49 --> Config Class Initialized
INFO - 2018-05-15 02:41:49 --> Hooks Class Initialized
DEBUG - 2018-05-15 02:41:49 --> UTF-8 Support Enabled
INFO - 2018-05-15 02:41:49 --> Utf8 Class Initialized
INFO - 2018-05-15 02:41:49 --> URI Class Initialized
INFO - 2018-05-15 02:41:49 --> Router Class Initialized
INFO - 2018-05-15 02:41:49 --> Output Class Initialized
INFO - 2018-05-15 02:41:49 --> Security Class Initialized
DEBUG - 2018-05-15 02:41:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 02:41:49 --> Input Class Initialized
INFO - 2018-05-15 02:41:49 --> Language Class Initialized
INFO - 2018-05-15 02:41:49 --> Language Class Initialized
INFO - 2018-05-15 02:41:49 --> Config Class Initialized
INFO - 2018-05-15 02:41:49 --> Loader Class Initialized
DEBUG - 2018-05-15 02:41:49 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-15 02:41:49 --> Helper loaded: url_helper
INFO - 2018-05-15 02:41:49 --> Helper loaded: form_helper
INFO - 2018-05-15 02:41:49 --> Helper loaded: date_helper
INFO - 2018-05-15 02:41:49 --> Helper loaded: util_helper
INFO - 2018-05-15 02:41:49 --> Helper loaded: text_helper
INFO - 2018-05-15 02:41:49 --> Helper loaded: string_helper
INFO - 2018-05-15 02:41:49 --> Database Driver Class Initialized
DEBUG - 2018-05-15 02:41:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-15 02:41:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-15 02:41:49 --> Email Class Initialized
INFO - 2018-05-15 02:41:49 --> Controller Class Initialized
DEBUG - 2018-05-15 02:41:49 --> Home MX_Controller Initialized
DEBUG - 2018-05-15 02:41:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-15 02:41:49 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-15 02:41:49 --> Login MX_Controller Initialized
INFO - 2018-05-15 02:41:49 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-15 02:41:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-15 02:41:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-15 02:41:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-05-15 02:41:49 --> Final output sent to browser
DEBUG - 2018-05-15 02:41:49 --> Total execution time: 0.3254
INFO - 2018-05-15 02:41:49 --> Config Class Initialized
INFO - 2018-05-15 02:41:49 --> Hooks Class Initialized
DEBUG - 2018-05-15 02:41:49 --> UTF-8 Support Enabled
INFO - 2018-05-15 02:41:50 --> Utf8 Class Initialized
INFO - 2018-05-15 02:41:50 --> URI Class Initialized
INFO - 2018-05-15 02:41:50 --> Router Class Initialized
INFO - 2018-05-15 02:41:50 --> Output Class Initialized
INFO - 2018-05-15 02:41:50 --> Security Class Initialized
DEBUG - 2018-05-15 02:41:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 02:41:50 --> Input Class Initialized
INFO - 2018-05-15 02:41:50 --> Language Class Initialized
ERROR - 2018-05-15 02:41:50 --> 404 Page Not Found: /index
INFO - 2018-05-15 02:41:50 --> Config Class Initialized
INFO - 2018-05-15 02:41:50 --> Config Class Initialized
INFO - 2018-05-15 02:41:50 --> Config Class Initialized
INFO - 2018-05-15 02:41:50 --> Config Class Initialized
INFO - 2018-05-15 02:41:50 --> Config Class Initialized
INFO - 2018-05-15 02:41:50 --> Hooks Class Initialized
INFO - 2018-05-15 02:41:50 --> Hooks Class Initialized
INFO - 2018-05-15 02:41:50 --> Hooks Class Initialized
INFO - 2018-05-15 02:41:50 --> Hooks Class Initialized
INFO - 2018-05-15 02:41:50 --> Hooks Class Initialized
INFO - 2018-05-15 02:41:50 --> Config Class Initialized
DEBUG - 2018-05-15 02:41:50 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 02:41:50 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 02:41:50 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 02:41:50 --> UTF-8 Support Enabled
INFO - 2018-05-15 02:41:50 --> Hooks Class Initialized
DEBUG - 2018-05-15 02:41:50 --> UTF-8 Support Enabled
INFO - 2018-05-15 02:41:50 --> Utf8 Class Initialized
INFO - 2018-05-15 02:41:50 --> URI Class Initialized
INFO - 2018-05-15 02:41:50 --> Router Class Initialized
INFO - 2018-05-15 02:41:50 --> Output Class Initialized
INFO - 2018-05-15 02:41:50 --> Utf8 Class Initialized
INFO - 2018-05-15 02:41:50 --> Utf8 Class Initialized
DEBUG - 2018-05-15 02:41:50 --> UTF-8 Support Enabled
INFO - 2018-05-15 02:41:50 --> Utf8 Class Initialized
INFO - 2018-05-15 02:41:50 --> Utf8 Class Initialized
INFO - 2018-05-15 02:41:50 --> Security Class Initialized
INFO - 2018-05-15 02:41:50 --> Utf8 Class Initialized
INFO - 2018-05-15 02:41:50 --> URI Class Initialized
INFO - 2018-05-15 02:41:50 --> URI Class Initialized
INFO - 2018-05-15 02:41:50 --> URI Class Initialized
DEBUG - 2018-05-15 02:41:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 02:41:50 --> URI Class Initialized
INFO - 2018-05-15 02:41:50 --> Input Class Initialized
INFO - 2018-05-15 02:41:50 --> Router Class Initialized
INFO - 2018-05-15 02:41:50 --> Router Class Initialized
INFO - 2018-05-15 02:41:50 --> Router Class Initialized
INFO - 2018-05-15 02:41:50 --> URI Class Initialized
INFO - 2018-05-15 02:41:50 --> Router Class Initialized
INFO - 2018-05-15 02:41:50 --> Router Class Initialized
INFO - 2018-05-15 02:41:50 --> Output Class Initialized
INFO - 2018-05-15 02:41:50 --> Language Class Initialized
INFO - 2018-05-15 02:41:50 --> Output Class Initialized
INFO - 2018-05-15 02:41:50 --> Output Class Initialized
INFO - 2018-05-15 02:41:50 --> Output Class Initialized
INFO - 2018-05-15 02:41:50 --> Output Class Initialized
INFO - 2018-05-15 02:41:50 --> Security Class Initialized
INFO - 2018-05-15 02:41:50 --> Security Class Initialized
ERROR - 2018-05-15 02:41:50 --> 404 Page Not Found: /index
INFO - 2018-05-15 02:41:50 --> Security Class Initialized
INFO - 2018-05-15 02:41:50 --> Security Class Initialized
DEBUG - 2018-05-15 02:41:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 02:41:50 --> Security Class Initialized
DEBUG - 2018-05-15 02:41:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-15 02:41:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-15 02:41:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 02:41:50 --> Config Class Initialized
INFO - 2018-05-15 02:41:50 --> Hooks Class Initialized
DEBUG - 2018-05-15 02:41:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 02:41:50 --> Input Class Initialized
INFO - 2018-05-15 02:41:50 --> Input Class Initialized
INFO - 2018-05-15 02:41:50 --> Input Class Initialized
INFO - 2018-05-15 02:41:50 --> Input Class Initialized
DEBUG - 2018-05-15 02:41:50 --> UTF-8 Support Enabled
INFO - 2018-05-15 02:41:50 --> Input Class Initialized
INFO - 2018-05-15 02:41:50 --> Language Class Initialized
INFO - 2018-05-15 02:41:50 --> Language Class Initialized
INFO - 2018-05-15 02:41:50 --> Language Class Initialized
INFO - 2018-05-15 02:41:50 --> Language Class Initialized
INFO - 2018-05-15 02:41:50 --> Utf8 Class Initialized
INFO - 2018-05-15 02:41:50 --> Language Class Initialized
ERROR - 2018-05-15 02:41:50 --> 404 Page Not Found: /index
ERROR - 2018-05-15 02:41:50 --> 404 Page Not Found: /index
ERROR - 2018-05-15 02:41:50 --> 404 Page Not Found: /index
ERROR - 2018-05-15 02:41:50 --> 404 Page Not Found: /index
INFO - 2018-05-15 02:41:50 --> URI Class Initialized
ERROR - 2018-05-15 02:41:50 --> 404 Page Not Found: /index
INFO - 2018-05-15 02:41:50 --> Config Class Initialized
INFO - 2018-05-15 02:41:50 --> Config Class Initialized
INFO - 2018-05-15 02:41:50 --> Hooks Class Initialized
INFO - 2018-05-15 02:41:50 --> Router Class Initialized
INFO - 2018-05-15 02:41:50 --> Hooks Class Initialized
INFO - 2018-05-15 02:41:50 --> Config Class Initialized
DEBUG - 2018-05-15 02:41:50 --> UTF-8 Support Enabled
INFO - 2018-05-15 02:41:50 --> Config Class Initialized
INFO - 2018-05-15 02:41:50 --> Hooks Class Initialized
INFO - 2018-05-15 02:41:50 --> Hooks Class Initialized
INFO - 2018-05-15 02:41:50 --> Output Class Initialized
INFO - 2018-05-15 02:41:50 --> Utf8 Class Initialized
DEBUG - 2018-05-15 02:41:50 --> UTF-8 Support Enabled
INFO - 2018-05-15 02:41:50 --> Utf8 Class Initialized
DEBUG - 2018-05-15 02:41:50 --> UTF-8 Support Enabled
INFO - 2018-05-15 02:41:50 --> Utf8 Class Initialized
INFO - 2018-05-15 02:41:50 --> URI Class Initialized
DEBUG - 2018-05-15 02:41:50 --> UTF-8 Support Enabled
INFO - 2018-05-15 02:41:50 --> Security Class Initialized
INFO - 2018-05-15 02:41:50 --> URI Class Initialized
INFO - 2018-05-15 02:41:50 --> URI Class Initialized
INFO - 2018-05-15 02:41:50 --> Utf8 Class Initialized
INFO - 2018-05-15 02:41:50 --> Router Class Initialized
DEBUG - 2018-05-15 02:41:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 02:41:50 --> Router Class Initialized
INFO - 2018-05-15 02:41:50 --> Output Class Initialized
INFO - 2018-05-15 02:41:50 --> Input Class Initialized
INFO - 2018-05-15 02:41:50 --> Router Class Initialized
INFO - 2018-05-15 02:41:50 --> Output Class Initialized
INFO - 2018-05-15 02:41:50 --> URI Class Initialized
INFO - 2018-05-15 02:41:50 --> Output Class Initialized
INFO - 2018-05-15 02:41:50 --> Language Class Initialized
INFO - 2018-05-15 02:41:50 --> Router Class Initialized
INFO - 2018-05-15 02:41:50 --> Security Class Initialized
INFO - 2018-05-15 02:41:50 --> Security Class Initialized
INFO - 2018-05-15 02:41:50 --> Security Class Initialized
ERROR - 2018-05-15 02:41:50 --> 404 Page Not Found: /index
DEBUG - 2018-05-15 02:41:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-15 02:41:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 02:41:50 --> Output Class Initialized
DEBUG - 2018-05-15 02:41:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 02:41:50 --> Input Class Initialized
INFO - 2018-05-15 02:41:50 --> Input Class Initialized
INFO - 2018-05-15 02:41:50 --> Security Class Initialized
INFO - 2018-05-15 02:41:50 --> Config Class Initialized
INFO - 2018-05-15 02:41:50 --> Hooks Class Initialized
INFO - 2018-05-15 02:41:50 --> Input Class Initialized
INFO - 2018-05-15 02:41:50 --> Language Class Initialized
INFO - 2018-05-15 02:41:50 --> Language Class Initialized
DEBUG - 2018-05-15 02:41:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-15 02:41:50 --> UTF-8 Support Enabled
ERROR - 2018-05-15 02:41:50 --> 404 Page Not Found: /index
INFO - 2018-05-15 02:41:50 --> Language Class Initialized
ERROR - 2018-05-15 02:41:50 --> 404 Page Not Found: /index
INFO - 2018-05-15 02:41:50 --> Input Class Initialized
INFO - 2018-05-15 02:41:50 --> Utf8 Class Initialized
INFO - 2018-05-15 02:41:50 --> Language Class Initialized
ERROR - 2018-05-15 02:41:50 --> 404 Page Not Found: /index
INFO - 2018-05-15 02:41:50 --> URI Class Initialized
INFO - 2018-05-15 02:41:50 --> Config Class Initialized
INFO - 2018-05-15 02:41:50 --> Config Class Initialized
INFO - 2018-05-15 02:41:50 --> Hooks Class Initialized
ERROR - 2018-05-15 02:41:50 --> 404 Page Not Found: /index
INFO - 2018-05-15 02:41:50 --> Hooks Class Initialized
INFO - 2018-05-15 02:41:50 --> Router Class Initialized
INFO - 2018-05-15 02:41:50 --> Config Class Initialized
DEBUG - 2018-05-15 02:41:50 --> UTF-8 Support Enabled
INFO - 2018-05-15 02:41:50 --> Config Class Initialized
DEBUG - 2018-05-15 02:41:50 --> UTF-8 Support Enabled
INFO - 2018-05-15 02:41:50 --> Hooks Class Initialized
INFO - 2018-05-15 02:41:50 --> Output Class Initialized
INFO - 2018-05-15 02:41:50 --> Hooks Class Initialized
INFO - 2018-05-15 02:41:50 --> Utf8 Class Initialized
DEBUG - 2018-05-15 02:41:50 --> UTF-8 Support Enabled
INFO - 2018-05-15 02:41:50 --> Utf8 Class Initialized
INFO - 2018-05-15 02:41:50 --> Security Class Initialized
INFO - 2018-05-15 02:41:50 --> URI Class Initialized
DEBUG - 2018-05-15 02:41:50 --> UTF-8 Support Enabled
INFO - 2018-05-15 02:41:50 --> Utf8 Class Initialized
INFO - 2018-05-15 02:41:50 --> URI Class Initialized
DEBUG - 2018-05-15 02:41:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 02:41:51 --> Utf8 Class Initialized
INFO - 2018-05-15 02:41:51 --> URI Class Initialized
INFO - 2018-05-15 02:41:51 --> Router Class Initialized
INFO - 2018-05-15 02:41:51 --> Input Class Initialized
INFO - 2018-05-15 02:41:51 --> Router Class Initialized
INFO - 2018-05-15 02:41:51 --> URI Class Initialized
INFO - 2018-05-15 02:41:51 --> Language Class Initialized
INFO - 2018-05-15 02:41:51 --> Output Class Initialized
INFO - 2018-05-15 02:41:51 --> Router Class Initialized
INFO - 2018-05-15 02:41:51 --> Output Class Initialized
INFO - 2018-05-15 02:41:51 --> Router Class Initialized
ERROR - 2018-05-15 02:41:51 --> 404 Page Not Found: /index
INFO - 2018-05-15 02:41:51 --> Output Class Initialized
INFO - 2018-05-15 02:41:51 --> Security Class Initialized
INFO - 2018-05-15 02:41:51 --> Security Class Initialized
INFO - 2018-05-15 02:41:51 --> Output Class Initialized
INFO - 2018-05-15 02:41:51 --> Security Class Initialized
DEBUG - 2018-05-15 02:41:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-15 02:41:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-15 02:41:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 02:41:51 --> Security Class Initialized
INFO - 2018-05-15 02:41:51 --> Input Class Initialized
INFO - 2018-05-15 02:41:51 --> Input Class Initialized
DEBUG - 2018-05-15 02:41:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 02:41:51 --> Input Class Initialized
INFO - 2018-05-15 02:41:51 --> Language Class Initialized
INFO - 2018-05-15 02:41:51 --> Language Class Initialized
INFO - 2018-05-15 02:41:51 --> Input Class Initialized
INFO - 2018-05-15 02:41:51 --> Language Class Initialized
ERROR - 2018-05-15 02:41:51 --> 404 Page Not Found: /index
ERROR - 2018-05-15 02:41:51 --> 404 Page Not Found: /index
INFO - 2018-05-15 02:41:51 --> Language Class Initialized
ERROR - 2018-05-15 02:41:51 --> 404 Page Not Found: /index
ERROR - 2018-05-15 02:41:51 --> 404 Page Not Found: /index
INFO - 2018-05-15 02:41:53 --> Config Class Initialized
INFO - 2018-05-15 02:41:53 --> Hooks Class Initialized
DEBUG - 2018-05-15 02:41:53 --> UTF-8 Support Enabled
INFO - 2018-05-15 02:41:53 --> Utf8 Class Initialized
INFO - 2018-05-15 02:41:53 --> URI Class Initialized
INFO - 2018-05-15 02:41:53 --> Router Class Initialized
INFO - 2018-05-15 02:41:53 --> Output Class Initialized
INFO - 2018-05-15 02:41:53 --> Security Class Initialized
DEBUG - 2018-05-15 02:41:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 02:41:53 --> Input Class Initialized
INFO - 2018-05-15 02:41:53 --> Language Class Initialized
ERROR - 2018-05-15 02:41:53 --> 404 Page Not Found: /index
INFO - 2018-05-15 02:41:53 --> Config Class Initialized
INFO - 2018-05-15 02:41:53 --> Hooks Class Initialized
DEBUG - 2018-05-15 02:41:53 --> UTF-8 Support Enabled
INFO - 2018-05-15 02:41:53 --> Utf8 Class Initialized
INFO - 2018-05-15 02:41:53 --> URI Class Initialized
INFO - 2018-05-15 02:41:53 --> Router Class Initialized
INFO - 2018-05-15 02:41:53 --> Output Class Initialized
INFO - 2018-05-15 02:41:53 --> Security Class Initialized
DEBUG - 2018-05-15 02:41:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 02:41:53 --> Input Class Initialized
INFO - 2018-05-15 02:41:53 --> Language Class Initialized
ERROR - 2018-05-15 02:41:53 --> 404 Page Not Found: /index
INFO - 2018-05-15 02:41:53 --> Config Class Initialized
INFO - 2018-05-15 02:41:53 --> Hooks Class Initialized
DEBUG - 2018-05-15 02:41:53 --> UTF-8 Support Enabled
INFO - 2018-05-15 02:41:53 --> Utf8 Class Initialized
INFO - 2018-05-15 02:41:53 --> URI Class Initialized
INFO - 2018-05-15 02:41:53 --> Router Class Initialized
INFO - 2018-05-15 02:41:53 --> Output Class Initialized
INFO - 2018-05-15 02:41:53 --> Security Class Initialized
DEBUG - 2018-05-15 02:41:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 02:41:53 --> Input Class Initialized
INFO - 2018-05-15 02:41:53 --> Language Class Initialized
ERROR - 2018-05-15 02:41:53 --> 404 Page Not Found: /index
INFO - 2018-05-15 02:41:57 --> Config Class Initialized
INFO - 2018-05-15 02:41:57 --> Hooks Class Initialized
DEBUG - 2018-05-15 02:41:57 --> UTF-8 Support Enabled
INFO - 2018-05-15 02:41:57 --> Utf8 Class Initialized
INFO - 2018-05-15 02:41:57 --> URI Class Initialized
INFO - 2018-05-15 02:41:57 --> Router Class Initialized
INFO - 2018-05-15 02:41:57 --> Output Class Initialized
INFO - 2018-05-15 02:41:57 --> Security Class Initialized
DEBUG - 2018-05-15 02:41:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 02:41:57 --> Input Class Initialized
INFO - 2018-05-15 02:41:57 --> Language Class Initialized
INFO - 2018-05-15 02:41:57 --> Language Class Initialized
INFO - 2018-05-15 02:41:57 --> Config Class Initialized
INFO - 2018-05-15 02:41:57 --> Loader Class Initialized
DEBUG - 2018-05-15 02:41:57 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-15 02:41:57 --> Helper loaded: url_helper
INFO - 2018-05-15 02:41:57 --> Helper loaded: form_helper
INFO - 2018-05-15 02:41:57 --> Helper loaded: date_helper
INFO - 2018-05-15 02:41:57 --> Helper loaded: util_helper
INFO - 2018-05-15 02:41:57 --> Helper loaded: text_helper
INFO - 2018-05-15 02:41:57 --> Helper loaded: string_helper
INFO - 2018-05-15 02:41:57 --> Database Driver Class Initialized
DEBUG - 2018-05-15 02:41:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-15 02:41:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-15 02:41:57 --> Email Class Initialized
INFO - 2018-05-15 02:41:57 --> Controller Class Initialized
DEBUG - 2018-05-15 02:41:57 --> Programs MX_Controller Initialized
INFO - 2018-05-15 02:41:57 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-15 02:41:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-05-15 02:41:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-15 02:41:57 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-15 02:41:57 --> Login MX_Controller Initialized
DEBUG - 2018-05-15 02:41:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-15 02:41:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/logins/login.php
INFO - 2018-05-15 02:41:57 --> Config Class Initialized
INFO - 2018-05-15 02:41:57 --> Hooks Class Initialized
DEBUG - 2018-05-15 02:41:57 --> UTF-8 Support Enabled
INFO - 2018-05-15 02:41:57 --> Utf8 Class Initialized
INFO - 2018-05-15 02:41:57 --> URI Class Initialized
INFO - 2018-05-15 02:41:57 --> Router Class Initialized
INFO - 2018-05-15 02:41:57 --> Output Class Initialized
INFO - 2018-05-15 02:41:57 --> Security Class Initialized
DEBUG - 2018-05-15 02:41:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 02:41:57 --> Input Class Initialized
INFO - 2018-05-15 02:41:57 --> Language Class Initialized
ERROR - 2018-05-15 02:41:57 --> 404 Page Not Found: /index
INFO - 2018-05-15 02:41:58 --> Config Class Initialized
INFO - 2018-05-15 02:41:58 --> Hooks Class Initialized
DEBUG - 2018-05-15 02:41:58 --> UTF-8 Support Enabled
INFO - 2018-05-15 02:41:58 --> Utf8 Class Initialized
INFO - 2018-05-15 02:41:58 --> URI Class Initialized
INFO - 2018-05-15 02:41:58 --> Router Class Initialized
INFO - 2018-05-15 02:41:58 --> Output Class Initialized
INFO - 2018-05-15 02:41:58 --> Security Class Initialized
DEBUG - 2018-05-15 02:41:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 02:41:58 --> Input Class Initialized
INFO - 2018-05-15 02:41:58 --> Language Class Initialized
ERROR - 2018-05-15 02:41:58 --> 404 Page Not Found: /index
INFO - 2018-05-15 02:42:02 --> Config Class Initialized
INFO - 2018-05-15 02:42:02 --> Hooks Class Initialized
DEBUG - 2018-05-15 02:42:02 --> UTF-8 Support Enabled
INFO - 2018-05-15 02:42:02 --> Utf8 Class Initialized
INFO - 2018-05-15 02:42:02 --> URI Class Initialized
INFO - 2018-05-15 02:42:02 --> Router Class Initialized
INFO - 2018-05-15 02:42:02 --> Output Class Initialized
INFO - 2018-05-15 02:42:02 --> Security Class Initialized
DEBUG - 2018-05-15 02:42:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 02:42:02 --> Input Class Initialized
INFO - 2018-05-15 02:42:02 --> Language Class Initialized
INFO - 2018-05-15 02:42:02 --> Language Class Initialized
INFO - 2018-05-15 02:42:02 --> Config Class Initialized
INFO - 2018-05-15 02:42:02 --> Loader Class Initialized
DEBUG - 2018-05-15 02:42:02 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-15 02:42:02 --> Helper loaded: url_helper
INFO - 2018-05-15 02:42:02 --> Helper loaded: form_helper
INFO - 2018-05-15 02:42:02 --> Helper loaded: date_helper
INFO - 2018-05-15 02:42:02 --> Helper loaded: util_helper
INFO - 2018-05-15 02:42:02 --> Helper loaded: text_helper
INFO - 2018-05-15 02:42:02 --> Helper loaded: string_helper
INFO - 2018-05-15 02:42:02 --> Database Driver Class Initialized
DEBUG - 2018-05-15 02:42:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-15 02:42:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-15 02:42:02 --> Email Class Initialized
INFO - 2018-05-15 02:42:02 --> Controller Class Initialized
DEBUG - 2018-05-15 02:42:02 --> Login MX_Controller Initialized
INFO - 2018-05-15 02:42:02 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-15 02:42:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-15 02:42:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-15 02:42:02 --> Email starts for admin@consulting.com fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-05-15 02:42:02 --> User session created for 1
INFO - 2018-05-15 02:42:03 --> Login status admin@consulting.com - success
INFO - 2018-05-15 02:42:03 --> Final output sent to browser
DEBUG - 2018-05-15 02:42:03 --> Total execution time: 0.3421
INFO - 2018-05-15 02:42:03 --> Config Class Initialized
INFO - 2018-05-15 02:42:03 --> Hooks Class Initialized
DEBUG - 2018-05-15 02:42:03 --> UTF-8 Support Enabled
INFO - 2018-05-15 02:42:03 --> Utf8 Class Initialized
INFO - 2018-05-15 02:42:03 --> URI Class Initialized
INFO - 2018-05-15 02:42:03 --> Router Class Initialized
INFO - 2018-05-15 02:42:03 --> Output Class Initialized
INFO - 2018-05-15 02:42:03 --> Security Class Initialized
DEBUG - 2018-05-15 02:42:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 02:42:03 --> Input Class Initialized
INFO - 2018-05-15 02:42:03 --> Language Class Initialized
INFO - 2018-05-15 02:42:03 --> Language Class Initialized
INFO - 2018-05-15 02:42:03 --> Config Class Initialized
INFO - 2018-05-15 02:42:03 --> Loader Class Initialized
DEBUG - 2018-05-15 02:42:03 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-15 02:42:03 --> Helper loaded: url_helper
INFO - 2018-05-15 02:42:03 --> Helper loaded: form_helper
INFO - 2018-05-15 02:42:03 --> Helper loaded: date_helper
INFO - 2018-05-15 02:42:03 --> Helper loaded: util_helper
INFO - 2018-05-15 02:42:03 --> Helper loaded: text_helper
INFO - 2018-05-15 02:42:03 --> Helper loaded: string_helper
INFO - 2018-05-15 02:42:03 --> Database Driver Class Initialized
DEBUG - 2018-05-15 02:42:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-15 02:42:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-15 02:42:03 --> Email Class Initialized
INFO - 2018-05-15 02:42:03 --> Controller Class Initialized
DEBUG - 2018-05-15 02:42:03 --> Admin MX_Controller Initialized
INFO - 2018-05-15 02:42:03 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-15 02:42:03 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-15 02:42:03 --> Login MX_Controller Initialized
DEBUG - 2018-05-15 02:42:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-15 02:42:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-15 02:42:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-05-15 02:42:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-05-15 02:42:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-05-15 02:42:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-05-15 02:42:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-05-15 02:42:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/dashboard.php
INFO - 2018-05-15 02:42:03 --> Final output sent to browser
DEBUG - 2018-05-15 02:42:03 --> Total execution time: 0.3836
INFO - 2018-05-15 02:42:03 --> Config Class Initialized
INFO - 2018-05-15 02:42:03 --> Hooks Class Initialized
DEBUG - 2018-05-15 02:42:03 --> UTF-8 Support Enabled
INFO - 2018-05-15 02:42:03 --> Utf8 Class Initialized
INFO - 2018-05-15 02:42:03 --> URI Class Initialized
INFO - 2018-05-15 02:42:03 --> Router Class Initialized
INFO - 2018-05-15 02:42:03 --> Output Class Initialized
INFO - 2018-05-15 02:42:03 --> Security Class Initialized
DEBUG - 2018-05-15 02:42:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 02:42:03 --> Input Class Initialized
INFO - 2018-05-15 02:42:03 --> Language Class Initialized
ERROR - 2018-05-15 02:42:03 --> 404 Page Not Found: /index
INFO - 2018-05-15 02:42:04 --> Config Class Initialized
INFO - 2018-05-15 02:42:04 --> Hooks Class Initialized
DEBUG - 2018-05-15 02:42:04 --> UTF-8 Support Enabled
INFO - 2018-05-15 02:42:04 --> Utf8 Class Initialized
INFO - 2018-05-15 02:42:04 --> URI Class Initialized
INFO - 2018-05-15 02:42:04 --> Router Class Initialized
INFO - 2018-05-15 02:42:04 --> Output Class Initialized
INFO - 2018-05-15 02:42:04 --> Security Class Initialized
DEBUG - 2018-05-15 02:42:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 02:42:04 --> Input Class Initialized
INFO - 2018-05-15 02:42:04 --> Language Class Initialized
ERROR - 2018-05-15 02:42:04 --> 404 Page Not Found: /index
INFO - 2018-05-15 02:42:09 --> Config Class Initialized
INFO - 2018-05-15 02:42:09 --> Hooks Class Initialized
DEBUG - 2018-05-15 02:42:09 --> UTF-8 Support Enabled
INFO - 2018-05-15 02:42:09 --> Utf8 Class Initialized
INFO - 2018-05-15 02:42:09 --> URI Class Initialized
INFO - 2018-05-15 02:42:09 --> Router Class Initialized
INFO - 2018-05-15 02:42:09 --> Output Class Initialized
INFO - 2018-05-15 02:42:09 --> Security Class Initialized
DEBUG - 2018-05-15 02:42:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 02:42:09 --> Input Class Initialized
INFO - 2018-05-15 02:42:09 --> Language Class Initialized
INFO - 2018-05-15 02:42:09 --> Language Class Initialized
INFO - 2018-05-15 02:42:09 --> Config Class Initialized
INFO - 2018-05-15 02:42:09 --> Loader Class Initialized
DEBUG - 2018-05-15 02:42:09 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-15 02:42:09 --> Helper loaded: url_helper
INFO - 2018-05-15 02:42:09 --> Helper loaded: form_helper
INFO - 2018-05-15 02:42:09 --> Helper loaded: date_helper
INFO - 2018-05-15 02:42:09 --> Helper loaded: util_helper
INFO - 2018-05-15 02:42:09 --> Helper loaded: text_helper
INFO - 2018-05-15 02:42:09 --> Helper loaded: string_helper
INFO - 2018-05-15 02:42:09 --> Database Driver Class Initialized
DEBUG - 2018-05-15 02:42:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-15 02:42:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-15 02:42:09 --> Email Class Initialized
INFO - 2018-05-15 02:42:09 --> Controller Class Initialized
DEBUG - 2018-05-15 02:42:09 --> Login MX_Controller Initialized
INFO - 2018-05-15 02:42:09 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-15 02:42:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-15 02:42:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-15 02:42:09 --> 1 Loggedout
INFO - 2018-05-15 02:42:09 --> Config Class Initialized
INFO - 2018-05-15 02:42:09 --> Hooks Class Initialized
DEBUG - 2018-05-15 02:42:09 --> UTF-8 Support Enabled
INFO - 2018-05-15 02:42:09 --> Utf8 Class Initialized
INFO - 2018-05-15 02:42:09 --> URI Class Initialized
INFO - 2018-05-15 02:42:09 --> Router Class Initialized
INFO - 2018-05-15 02:42:09 --> Output Class Initialized
INFO - 2018-05-15 02:42:09 --> Security Class Initialized
DEBUG - 2018-05-15 02:42:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 02:42:09 --> Input Class Initialized
INFO - 2018-05-15 02:42:10 --> Language Class Initialized
INFO - 2018-05-15 02:42:10 --> Language Class Initialized
INFO - 2018-05-15 02:42:10 --> Config Class Initialized
INFO - 2018-05-15 02:42:10 --> Loader Class Initialized
DEBUG - 2018-05-15 02:42:10 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-15 02:42:10 --> Helper loaded: url_helper
INFO - 2018-05-15 02:42:10 --> Helper loaded: form_helper
INFO - 2018-05-15 02:42:10 --> Helper loaded: date_helper
INFO - 2018-05-15 02:42:10 --> Helper loaded: util_helper
INFO - 2018-05-15 02:42:10 --> Helper loaded: text_helper
INFO - 2018-05-15 02:42:10 --> Helper loaded: string_helper
INFO - 2018-05-15 02:42:10 --> Database Driver Class Initialized
DEBUG - 2018-05-15 02:42:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-15 02:42:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-15 02:42:10 --> Email Class Initialized
INFO - 2018-05-15 02:42:10 --> Controller Class Initialized
DEBUG - 2018-05-15 02:42:10 --> Admin MX_Controller Initialized
INFO - 2018-05-15 02:42:10 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-15 02:42:10 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-15 02:42:10 --> Login MX_Controller Initialized
DEBUG - 2018-05-15 02:42:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-15 02:42:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-15 02:42:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/logins/login.php
INFO - 2018-05-15 02:42:10 --> Config Class Initialized
INFO - 2018-05-15 02:42:10 --> Hooks Class Initialized
DEBUG - 2018-05-15 02:42:10 --> UTF-8 Support Enabled
INFO - 2018-05-15 02:42:10 --> Utf8 Class Initialized
INFO - 2018-05-15 02:42:10 --> URI Class Initialized
INFO - 2018-05-15 02:42:10 --> Router Class Initialized
INFO - 2018-05-15 02:42:10 --> Output Class Initialized
INFO - 2018-05-15 02:42:10 --> Security Class Initialized
DEBUG - 2018-05-15 02:42:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 02:42:10 --> Input Class Initialized
INFO - 2018-05-15 02:42:10 --> Language Class Initialized
ERROR - 2018-05-15 02:42:10 --> 404 Page Not Found: /index
INFO - 2018-05-15 02:42:16 --> Config Class Initialized
INFO - 2018-05-15 02:42:16 --> Hooks Class Initialized
DEBUG - 2018-05-15 02:42:16 --> UTF-8 Support Enabled
INFO - 2018-05-15 02:42:16 --> Utf8 Class Initialized
INFO - 2018-05-15 02:42:16 --> URI Class Initialized
INFO - 2018-05-15 02:42:16 --> Router Class Initialized
INFO - 2018-05-15 02:42:16 --> Output Class Initialized
INFO - 2018-05-15 02:42:16 --> Security Class Initialized
DEBUG - 2018-05-15 02:42:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 02:42:16 --> Input Class Initialized
INFO - 2018-05-15 02:42:16 --> Language Class Initialized
INFO - 2018-05-15 02:42:16 --> Language Class Initialized
INFO - 2018-05-15 02:42:16 --> Config Class Initialized
INFO - 2018-05-15 02:42:16 --> Loader Class Initialized
DEBUG - 2018-05-15 02:42:16 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-15 02:42:16 --> Helper loaded: url_helper
INFO - 2018-05-15 02:42:16 --> Helper loaded: form_helper
INFO - 2018-05-15 02:42:16 --> Helper loaded: date_helper
INFO - 2018-05-15 02:42:16 --> Helper loaded: util_helper
INFO - 2018-05-15 02:42:16 --> Helper loaded: text_helper
INFO - 2018-05-15 02:42:16 --> Helper loaded: string_helper
INFO - 2018-05-15 02:42:16 --> Database Driver Class Initialized
DEBUG - 2018-05-15 02:42:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-15 02:42:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-15 02:42:16 --> Email Class Initialized
INFO - 2018-05-15 02:42:16 --> Controller Class Initialized
DEBUG - 2018-05-15 02:42:16 --> Admin MX_Controller Initialized
INFO - 2018-05-15 02:42:16 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-15 02:42:16 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-15 02:42:16 --> Login MX_Controller Initialized
DEBUG - 2018-05-15 02:42:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-15 02:42:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-15 02:42:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/logins/login.php
INFO - 2018-05-15 02:42:17 --> Config Class Initialized
INFO - 2018-05-15 02:42:17 --> Hooks Class Initialized
DEBUG - 2018-05-15 02:42:17 --> UTF-8 Support Enabled
INFO - 2018-05-15 02:42:17 --> Utf8 Class Initialized
INFO - 2018-05-15 02:42:17 --> URI Class Initialized
INFO - 2018-05-15 02:42:17 --> Router Class Initialized
INFO - 2018-05-15 02:42:17 --> Output Class Initialized
INFO - 2018-05-15 02:42:17 --> Security Class Initialized
DEBUG - 2018-05-15 02:42:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 02:42:17 --> Input Class Initialized
INFO - 2018-05-15 02:42:17 --> Language Class Initialized
ERROR - 2018-05-15 02:42:17 --> 404 Page Not Found: /index
INFO - 2018-05-15 02:42:18 --> Config Class Initialized
INFO - 2018-05-15 02:42:18 --> Hooks Class Initialized
DEBUG - 2018-05-15 02:42:18 --> UTF-8 Support Enabled
INFO - 2018-05-15 02:42:18 --> Utf8 Class Initialized
INFO - 2018-05-15 02:42:18 --> URI Class Initialized
INFO - 2018-05-15 02:42:18 --> Router Class Initialized
INFO - 2018-05-15 02:42:18 --> Output Class Initialized
INFO - 2018-05-15 02:42:18 --> Security Class Initialized
DEBUG - 2018-05-15 02:42:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 02:42:18 --> Input Class Initialized
INFO - 2018-05-15 02:42:18 --> Language Class Initialized
ERROR - 2018-05-15 02:42:18 --> 404 Page Not Found: /index
INFO - 2018-05-15 02:42:20 --> Config Class Initialized
INFO - 2018-05-15 02:42:20 --> Hooks Class Initialized
DEBUG - 2018-05-15 02:42:20 --> UTF-8 Support Enabled
INFO - 2018-05-15 02:42:20 --> Utf8 Class Initialized
INFO - 2018-05-15 02:42:20 --> URI Class Initialized
INFO - 2018-05-15 02:42:20 --> Router Class Initialized
INFO - 2018-05-15 02:42:20 --> Output Class Initialized
INFO - 2018-05-15 02:42:20 --> Security Class Initialized
DEBUG - 2018-05-15 02:42:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 02:42:20 --> Input Class Initialized
INFO - 2018-05-15 02:42:20 --> Language Class Initialized
INFO - 2018-05-15 02:42:20 --> Language Class Initialized
INFO - 2018-05-15 02:42:20 --> Config Class Initialized
INFO - 2018-05-15 02:42:20 --> Loader Class Initialized
DEBUG - 2018-05-15 02:42:20 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-15 02:42:20 --> Helper loaded: url_helper
INFO - 2018-05-15 02:42:20 --> Helper loaded: form_helper
INFO - 2018-05-15 02:42:20 --> Helper loaded: date_helper
INFO - 2018-05-15 02:42:20 --> Helper loaded: util_helper
INFO - 2018-05-15 02:42:20 --> Helper loaded: text_helper
INFO - 2018-05-15 02:42:20 --> Helper loaded: string_helper
INFO - 2018-05-15 02:42:20 --> Database Driver Class Initialized
DEBUG - 2018-05-15 02:42:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-15 02:42:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-15 02:42:20 --> Email Class Initialized
INFO - 2018-05-15 02:42:20 --> Controller Class Initialized
DEBUG - 2018-05-15 02:42:20 --> Login MX_Controller Initialized
INFO - 2018-05-15 02:42:20 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-15 02:42:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-15 02:42:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-15 02:42:20 --> Email starts for admin@consulting.com fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-05-15 02:42:20 --> User session created for 1
INFO - 2018-05-15 02:42:20 --> Login status admin@consulting.com - success
INFO - 2018-05-15 02:42:20 --> Final output sent to browser
DEBUG - 2018-05-15 02:42:20 --> Total execution time: 0.3363
INFO - 2018-05-15 02:42:20 --> Config Class Initialized
INFO - 2018-05-15 02:42:21 --> Hooks Class Initialized
DEBUG - 2018-05-15 02:42:21 --> UTF-8 Support Enabled
INFO - 2018-05-15 02:42:21 --> Utf8 Class Initialized
INFO - 2018-05-15 02:42:21 --> URI Class Initialized
INFO - 2018-05-15 02:42:21 --> Router Class Initialized
INFO - 2018-05-15 02:42:21 --> Output Class Initialized
INFO - 2018-05-15 02:42:21 --> Security Class Initialized
DEBUG - 2018-05-15 02:42:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 02:42:21 --> Input Class Initialized
INFO - 2018-05-15 02:42:21 --> Language Class Initialized
INFO - 2018-05-15 02:42:21 --> Language Class Initialized
INFO - 2018-05-15 02:42:21 --> Config Class Initialized
INFO - 2018-05-15 02:42:21 --> Loader Class Initialized
DEBUG - 2018-05-15 02:42:21 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-15 02:42:21 --> Helper loaded: url_helper
INFO - 2018-05-15 02:42:21 --> Helper loaded: form_helper
INFO - 2018-05-15 02:42:21 --> Helper loaded: date_helper
INFO - 2018-05-15 02:42:21 --> Helper loaded: util_helper
INFO - 2018-05-15 02:42:21 --> Helper loaded: text_helper
INFO - 2018-05-15 02:42:21 --> Helper loaded: string_helper
INFO - 2018-05-15 02:42:21 --> Database Driver Class Initialized
DEBUG - 2018-05-15 02:42:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-15 02:42:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-15 02:42:21 --> Email Class Initialized
INFO - 2018-05-15 02:42:21 --> Controller Class Initialized
DEBUG - 2018-05-15 02:42:21 --> Admin MX_Controller Initialized
INFO - 2018-05-15 02:42:21 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-15 02:42:21 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-15 02:42:21 --> Login MX_Controller Initialized
DEBUG - 2018-05-15 02:42:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-15 02:42:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-15 02:42:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-05-15 02:42:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-05-15 02:42:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-05-15 02:42:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-05-15 02:42:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-05-15 02:42:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/dashboard.php
INFO - 2018-05-15 02:42:21 --> Final output sent to browser
INFO - 2018-05-15 02:42:21 --> Config Class Initialized
DEBUG - 2018-05-15 02:42:21 --> Total execution time: 0.3969
INFO - 2018-05-15 02:42:21 --> Config Class Initialized
INFO - 2018-05-15 02:42:21 --> Hooks Class Initialized
DEBUG - 2018-05-15 02:42:21 --> UTF-8 Support Enabled
INFO - 2018-05-15 02:42:21 --> Utf8 Class Initialized
INFO - 2018-05-15 02:42:21 --> URI Class Initialized
INFO - 2018-05-15 02:42:21 --> Router Class Initialized
INFO - 2018-05-15 02:42:21 --> Output Class Initialized
INFO - 2018-05-15 02:42:21 --> Security Class Initialized
DEBUG - 2018-05-15 02:42:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 02:42:21 --> Input Class Initialized
INFO - 2018-05-15 02:42:21 --> Language Class Initialized
INFO - 2018-05-15 02:42:21 --> Hooks Class Initialized
ERROR - 2018-05-15 02:42:21 --> 404 Page Not Found: /index
DEBUG - 2018-05-15 02:42:21 --> UTF-8 Support Enabled
INFO - 2018-05-15 02:42:21 --> Utf8 Class Initialized
INFO - 2018-05-15 02:42:21 --> URI Class Initialized
INFO - 2018-05-15 02:42:21 --> Router Class Initialized
INFO - 2018-05-15 02:42:21 --> Output Class Initialized
INFO - 2018-05-15 02:42:21 --> Security Class Initialized
DEBUG - 2018-05-15 02:42:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 02:42:21 --> Input Class Initialized
INFO - 2018-05-15 02:42:21 --> Language Class Initialized
ERROR - 2018-05-15 02:42:21 --> 404 Page Not Found: /index
INFO - 2018-05-15 02:42:22 --> Config Class Initialized
INFO - 2018-05-15 02:42:22 --> Hooks Class Initialized
DEBUG - 2018-05-15 02:42:22 --> UTF-8 Support Enabled
INFO - 2018-05-15 02:42:22 --> Utf8 Class Initialized
INFO - 2018-05-15 02:42:22 --> URI Class Initialized
INFO - 2018-05-15 02:42:22 --> Router Class Initialized
INFO - 2018-05-15 02:42:22 --> Output Class Initialized
INFO - 2018-05-15 02:42:22 --> Security Class Initialized
DEBUG - 2018-05-15 02:42:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 02:42:22 --> Input Class Initialized
INFO - 2018-05-15 02:42:22 --> Language Class Initialized
ERROR - 2018-05-15 02:42:22 --> 404 Page Not Found: /index
INFO - 2018-05-15 02:42:29 --> Config Class Initialized
INFO - 2018-05-15 02:42:29 --> Hooks Class Initialized
DEBUG - 2018-05-15 02:42:29 --> UTF-8 Support Enabled
INFO - 2018-05-15 02:42:29 --> Utf8 Class Initialized
INFO - 2018-05-15 02:42:29 --> URI Class Initialized
INFO - 2018-05-15 02:42:29 --> Router Class Initialized
INFO - 2018-05-15 02:42:29 --> Output Class Initialized
INFO - 2018-05-15 02:42:29 --> Security Class Initialized
DEBUG - 2018-05-15 02:42:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 02:42:29 --> Input Class Initialized
INFO - 2018-05-15 02:42:29 --> Language Class Initialized
INFO - 2018-05-15 02:42:29 --> Language Class Initialized
INFO - 2018-05-15 02:42:29 --> Config Class Initialized
INFO - 2018-05-15 02:42:29 --> Loader Class Initialized
DEBUG - 2018-05-15 02:42:29 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-15 02:42:29 --> Helper loaded: url_helper
INFO - 2018-05-15 02:42:29 --> Helper loaded: form_helper
INFO - 2018-05-15 02:42:29 --> Helper loaded: date_helper
INFO - 2018-05-15 02:42:29 --> Helper loaded: util_helper
INFO - 2018-05-15 02:42:29 --> Helper loaded: text_helper
INFO - 2018-05-15 02:42:29 --> Helper loaded: string_helper
INFO - 2018-05-15 02:42:29 --> Database Driver Class Initialized
DEBUG - 2018-05-15 02:42:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-15 02:42:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-15 02:42:29 --> Email Class Initialized
INFO - 2018-05-15 02:42:29 --> Controller Class Initialized
DEBUG - 2018-05-15 02:42:29 --> Programs MX_Controller Initialized
INFO - 2018-05-15 02:42:29 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-15 02:42:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-05-15 02:42:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-15 02:42:29 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-15 02:42:29 --> Login MX_Controller Initialized
DEBUG - 2018-05-15 02:42:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-15 02:42:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-05-15 02:42:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-05-15 02:42:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-05-15 02:42:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-05-15 02:42:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-05-15 02:42:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/programs/programs.php
INFO - 2018-05-15 02:42:29 --> Final output sent to browser
DEBUG - 2018-05-15 02:42:29 --> Total execution time: 0.4072
INFO - 2018-05-15 02:42:29 --> Config Class Initialized
INFO - 2018-05-15 02:42:29 --> Hooks Class Initialized
DEBUG - 2018-05-15 02:42:29 --> UTF-8 Support Enabled
INFO - 2018-05-15 02:42:29 --> Utf8 Class Initialized
INFO - 2018-05-15 02:42:29 --> URI Class Initialized
INFO - 2018-05-15 02:42:30 --> Router Class Initialized
INFO - 2018-05-15 02:42:30 --> Output Class Initialized
INFO - 2018-05-15 02:42:30 --> Security Class Initialized
DEBUG - 2018-05-15 02:42:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 02:42:30 --> Input Class Initialized
INFO - 2018-05-15 02:42:30 --> Language Class Initialized
INFO - 2018-05-15 02:42:30 --> Language Class Initialized
INFO - 2018-05-15 02:42:30 --> Config Class Initialized
INFO - 2018-05-15 02:42:30 --> Loader Class Initialized
DEBUG - 2018-05-15 02:42:30 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-15 02:42:30 --> Helper loaded: url_helper
INFO - 2018-05-15 02:42:30 --> Helper loaded: form_helper
INFO - 2018-05-15 02:42:30 --> Helper loaded: date_helper
INFO - 2018-05-15 02:42:30 --> Helper loaded: util_helper
INFO - 2018-05-15 02:42:30 --> Helper loaded: text_helper
INFO - 2018-05-15 02:42:30 --> Helper loaded: string_helper
INFO - 2018-05-15 02:42:30 --> Database Driver Class Initialized
DEBUG - 2018-05-15 02:42:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-15 02:42:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-15 02:42:30 --> Email Class Initialized
INFO - 2018-05-15 02:42:30 --> Controller Class Initialized
DEBUG - 2018-05-15 02:42:30 --> Programs MX_Controller Initialized
INFO - 2018-05-15 02:42:30 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-15 02:42:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-05-15 02:42:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-15 02:42:30 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-15 02:42:30 --> Login MX_Controller Initialized
DEBUG - 2018-05-15 02:42:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-15 02:42:30 --> Final output sent to browser
DEBUG - 2018-05-15 02:42:30 --> Total execution time: 0.4373
INFO - 2018-05-15 02:43:00 --> Config Class Initialized
INFO - 2018-05-15 02:43:00 --> Hooks Class Initialized
DEBUG - 2018-05-15 02:43:00 --> UTF-8 Support Enabled
INFO - 2018-05-15 02:43:00 --> Utf8 Class Initialized
INFO - 2018-05-15 02:43:00 --> URI Class Initialized
INFO - 2018-05-15 02:43:00 --> Router Class Initialized
INFO - 2018-05-15 02:43:00 --> Output Class Initialized
INFO - 2018-05-15 02:43:00 --> Security Class Initialized
DEBUG - 2018-05-15 02:43:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 02:43:00 --> Input Class Initialized
INFO - 2018-05-15 02:43:00 --> Language Class Initialized
INFO - 2018-05-15 02:43:00 --> Language Class Initialized
INFO - 2018-05-15 02:43:00 --> Config Class Initialized
INFO - 2018-05-15 02:43:00 --> Loader Class Initialized
DEBUG - 2018-05-15 02:43:00 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-15 02:43:00 --> Helper loaded: url_helper
INFO - 2018-05-15 02:43:00 --> Helper loaded: form_helper
INFO - 2018-05-15 02:43:00 --> Helper loaded: date_helper
INFO - 2018-05-15 02:43:00 --> Helper loaded: util_helper
INFO - 2018-05-15 02:43:00 --> Helper loaded: text_helper
INFO - 2018-05-15 02:43:00 --> Helper loaded: string_helper
INFO - 2018-05-15 02:43:00 --> Database Driver Class Initialized
DEBUG - 2018-05-15 02:43:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-15 02:43:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-15 02:43:00 --> Email Class Initialized
INFO - 2018-05-15 02:43:00 --> Controller Class Initialized
DEBUG - 2018-05-15 02:43:00 --> Home MX_Controller Initialized
DEBUG - 2018-05-15 02:43:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-15 02:43:00 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-15 02:43:00 --> Login MX_Controller Initialized
INFO - 2018-05-15 02:43:00 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-15 02:43:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-15 02:43:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-15 02:43:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-05-15 02:43:00 --> Final output sent to browser
DEBUG - 2018-05-15 02:43:00 --> Total execution time: 0.3691
INFO - 2018-05-15 02:43:00 --> Config Class Initialized
INFO - 2018-05-15 02:43:00 --> Hooks Class Initialized
DEBUG - 2018-05-15 02:43:00 --> UTF-8 Support Enabled
INFO - 2018-05-15 02:43:00 --> Utf8 Class Initialized
INFO - 2018-05-15 02:43:00 --> URI Class Initialized
INFO - 2018-05-15 02:43:00 --> Router Class Initialized
INFO - 2018-05-15 02:43:00 --> Output Class Initialized
INFO - 2018-05-15 02:43:00 --> Security Class Initialized
DEBUG - 2018-05-15 02:43:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 02:43:00 --> Input Class Initialized
INFO - 2018-05-15 02:43:00 --> Language Class Initialized
ERROR - 2018-05-15 02:43:00 --> 404 Page Not Found: /index
INFO - 2018-05-15 02:43:01 --> Config Class Initialized
INFO - 2018-05-15 02:43:01 --> Hooks Class Initialized
DEBUG - 2018-05-15 02:43:01 --> UTF-8 Support Enabled
INFO - 2018-05-15 02:43:01 --> Utf8 Class Initialized
INFO - 2018-05-15 02:43:01 --> URI Class Initialized
INFO - 2018-05-15 02:43:01 --> Config Class Initialized
INFO - 2018-05-15 02:43:01 --> Config Class Initialized
INFO - 2018-05-15 02:43:01 --> Hooks Class Initialized
INFO - 2018-05-15 02:43:01 --> Router Class Initialized
INFO - 2018-05-15 02:43:01 --> Config Class Initialized
INFO - 2018-05-15 02:43:01 --> Hooks Class Initialized
DEBUG - 2018-05-15 02:43:01 --> UTF-8 Support Enabled
INFO - 2018-05-15 02:43:01 --> Hooks Class Initialized
INFO - 2018-05-15 02:43:01 --> Output Class Initialized
INFO - 2018-05-15 02:43:01 --> Config Class Initialized
DEBUG - 2018-05-15 02:43:01 --> UTF-8 Support Enabled
INFO - 2018-05-15 02:43:01 --> Config Class Initialized
INFO - 2018-05-15 02:43:01 --> Hooks Class Initialized
INFO - 2018-05-15 02:43:01 --> Security Class Initialized
INFO - 2018-05-15 02:43:01 --> Utf8 Class Initialized
INFO - 2018-05-15 02:43:01 --> Hooks Class Initialized
INFO - 2018-05-15 02:43:01 --> Utf8 Class Initialized
DEBUG - 2018-05-15 02:43:01 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 02:43:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-15 02:43:01 --> UTF-8 Support Enabled
INFO - 2018-05-15 02:43:01 --> URI Class Initialized
INFO - 2018-05-15 02:43:01 --> URI Class Initialized
INFO - 2018-05-15 02:43:01 --> Utf8 Class Initialized
DEBUG - 2018-05-15 02:43:01 --> UTF-8 Support Enabled
INFO - 2018-05-15 02:43:01 --> Utf8 Class Initialized
INFO - 2018-05-15 02:43:01 --> Input Class Initialized
INFO - 2018-05-15 02:43:01 --> Router Class Initialized
INFO - 2018-05-15 02:43:01 --> Utf8 Class Initialized
INFO - 2018-05-15 02:43:01 --> Router Class Initialized
INFO - 2018-05-15 02:43:01 --> URI Class Initialized
INFO - 2018-05-15 02:43:01 --> Output Class Initialized
INFO - 2018-05-15 02:43:01 --> URI Class Initialized
INFO - 2018-05-15 02:43:01 --> Language Class Initialized
INFO - 2018-05-15 02:43:01 --> Output Class Initialized
INFO - 2018-05-15 02:43:01 --> URI Class Initialized
INFO - 2018-05-15 02:43:01 --> Router Class Initialized
INFO - 2018-05-15 02:43:01 --> Security Class Initialized
ERROR - 2018-05-15 02:43:01 --> 404 Page Not Found: /index
INFO - 2018-05-15 02:43:01 --> Router Class Initialized
INFO - 2018-05-15 02:43:01 --> Router Class Initialized
INFO - 2018-05-15 02:43:01 --> Security Class Initialized
INFO - 2018-05-15 02:43:01 --> Output Class Initialized
INFO - 2018-05-15 02:43:01 --> Output Class Initialized
DEBUG - 2018-05-15 02:43:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 02:43:01 --> Config Class Initialized
DEBUG - 2018-05-15 02:43:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 02:43:01 --> Output Class Initialized
INFO - 2018-05-15 02:43:01 --> Security Class Initialized
INFO - 2018-05-15 02:43:01 --> Hooks Class Initialized
INFO - 2018-05-15 02:43:01 --> Security Class Initialized
DEBUG - 2018-05-15 02:43:01 --> UTF-8 Support Enabled
INFO - 2018-05-15 02:43:01 --> Utf8 Class Initialized
INFO - 2018-05-15 02:43:01 --> URI Class Initialized
INFO - 2018-05-15 02:43:01 --> Router Class Initialized
INFO - 2018-05-15 02:43:01 --> Output Class Initialized
INFO - 2018-05-15 02:43:01 --> Security Class Initialized
DEBUG - 2018-05-15 02:43:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 02:43:01 --> Input Class Initialized
INFO - 2018-05-15 02:43:01 --> Language Class Initialized
ERROR - 2018-05-15 02:43:01 --> 404 Page Not Found: /index
INFO - 2018-05-15 02:43:01 --> Security Class Initialized
DEBUG - 2018-05-15 02:43:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-15 02:43:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 02:43:01 --> Input Class Initialized
DEBUG - 2018-05-15 02:43:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 02:43:01 --> Input Class Initialized
INFO - 2018-05-15 02:43:01 --> Input Class Initialized
INFO - 2018-05-15 02:43:01 --> Config Class Initialized
INFO - 2018-05-15 02:43:01 --> Hooks Class Initialized
INFO - 2018-05-15 02:43:01 --> Input Class Initialized
DEBUG - 2018-05-15 02:43:01 --> UTF-8 Support Enabled
INFO - 2018-05-15 02:43:01 --> Utf8 Class Initialized
INFO - 2018-05-15 02:43:01 --> Language Class Initialized
INFO - 2018-05-15 02:43:01 --> Input Class Initialized
INFO - 2018-05-15 02:43:01 --> Language Class Initialized
INFO - 2018-05-15 02:43:01 --> Language Class Initialized
INFO - 2018-05-15 02:43:01 --> Language Class Initialized
INFO - 2018-05-15 02:43:01 --> URI Class Initialized
ERROR - 2018-05-15 02:43:01 --> 404 Page Not Found: /index
ERROR - 2018-05-15 02:43:01 --> 404 Page Not Found: /index
INFO - 2018-05-15 02:43:01 --> Router Class Initialized
ERROR - 2018-05-15 02:43:01 --> 404 Page Not Found: /index
INFO - 2018-05-15 02:43:01 --> Language Class Initialized
ERROR - 2018-05-15 02:43:01 --> 404 Page Not Found: /index
INFO - 2018-05-15 02:43:01 --> Output Class Initialized
ERROR - 2018-05-15 02:43:01 --> 404 Page Not Found: /index
INFO - 2018-05-15 02:43:01 --> Config Class Initialized
INFO - 2018-05-15 02:43:01 --> Config Class Initialized
INFO - 2018-05-15 02:43:01 --> Config Class Initialized
INFO - 2018-05-15 02:43:01 --> Hooks Class Initialized
INFO - 2018-05-15 02:43:01 --> Hooks Class Initialized
INFO - 2018-05-15 02:43:01 --> Hooks Class Initialized
DEBUG - 2018-05-15 02:43:01 --> UTF-8 Support Enabled
INFO - 2018-05-15 02:43:01 --> Security Class Initialized
INFO - 2018-05-15 02:43:01 --> Config Class Initialized
INFO - 2018-05-15 02:43:01 --> Hooks Class Initialized
INFO - 2018-05-15 02:43:01 --> Utf8 Class Initialized
DEBUG - 2018-05-15 02:43:01 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 02:43:01 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 02:43:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 02:43:01 --> Utf8 Class Initialized
INFO - 2018-05-15 02:43:01 --> Utf8 Class Initialized
INFO - 2018-05-15 02:43:01 --> URI Class Initialized
INFO - 2018-05-15 02:43:01 --> Input Class Initialized
DEBUG - 2018-05-15 02:43:01 --> UTF-8 Support Enabled
INFO - 2018-05-15 02:43:01 --> URI Class Initialized
INFO - 2018-05-15 02:43:01 --> Utf8 Class Initialized
INFO - 2018-05-15 02:43:01 --> Router Class Initialized
INFO - 2018-05-15 02:43:01 --> URI Class Initialized
INFO - 2018-05-15 02:43:01 --> Language Class Initialized
ERROR - 2018-05-15 02:43:02 --> 404 Page Not Found: /index
INFO - 2018-05-15 02:43:02 --> Output Class Initialized
INFO - 2018-05-15 02:43:02 --> URI Class Initialized
INFO - 2018-05-15 02:43:02 --> Router Class Initialized
INFO - 2018-05-15 02:43:02 --> Router Class Initialized
INFO - 2018-05-15 02:43:02 --> Security Class Initialized
INFO - 2018-05-15 02:43:02 --> Output Class Initialized
INFO - 2018-05-15 02:43:02 --> Output Class Initialized
INFO - 2018-05-15 02:43:02 --> Config Class Initialized
INFO - 2018-05-15 02:43:02 --> Router Class Initialized
INFO - 2018-05-15 02:43:02 --> Hooks Class Initialized
INFO - 2018-05-15 02:43:02 --> Security Class Initialized
INFO - 2018-05-15 02:43:02 --> Security Class Initialized
DEBUG - 2018-05-15 02:43:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 02:43:02 --> Output Class Initialized
DEBUG - 2018-05-15 02:43:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-15 02:43:02 --> UTF-8 Support Enabled
INFO - 2018-05-15 02:43:02 --> Input Class Initialized
DEBUG - 2018-05-15 02:43:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 02:43:02 --> Security Class Initialized
INFO - 2018-05-15 02:43:02 --> Utf8 Class Initialized
INFO - 2018-05-15 02:43:02 --> Input Class Initialized
INFO - 2018-05-15 02:43:02 --> Input Class Initialized
INFO - 2018-05-15 02:43:02 --> Language Class Initialized
DEBUG - 2018-05-15 02:43:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 02:43:02 --> URI Class Initialized
INFO - 2018-05-15 02:43:02 --> Input Class Initialized
INFO - 2018-05-15 02:43:02 --> Language Class Initialized
INFO - 2018-05-15 02:43:02 --> Language Class Initialized
ERROR - 2018-05-15 02:43:02 --> 404 Page Not Found: /index
INFO - 2018-05-15 02:43:02 --> Router Class Initialized
ERROR - 2018-05-15 02:43:02 --> 404 Page Not Found: /index
ERROR - 2018-05-15 02:43:02 --> 404 Page Not Found: /index
INFO - 2018-05-15 02:43:02 --> Language Class Initialized
INFO - 2018-05-15 02:43:02 --> Config Class Initialized
INFO - 2018-05-15 02:43:02 --> Hooks Class Initialized
INFO - 2018-05-15 02:43:02 --> Output Class Initialized
ERROR - 2018-05-15 02:43:02 --> 404 Page Not Found: /index
INFO - 2018-05-15 02:43:02 --> Config Class Initialized
INFO - 2018-05-15 02:43:02 --> Config Class Initialized
INFO - 2018-05-15 02:43:02 --> Hooks Class Initialized
INFO - 2018-05-15 02:43:02 --> Hooks Class Initialized
INFO - 2018-05-15 02:43:02 --> Security Class Initialized
DEBUG - 2018-05-15 02:43:02 --> UTF-8 Support Enabled
INFO - 2018-05-15 02:43:02 --> Utf8 Class Initialized
DEBUG - 2018-05-15 02:43:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-15 02:43:02 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 02:43:02 --> UTF-8 Support Enabled
INFO - 2018-05-15 02:43:02 --> Utf8 Class Initialized
INFO - 2018-05-15 02:43:02 --> Input Class Initialized
INFO - 2018-05-15 02:43:02 --> URI Class Initialized
INFO - 2018-05-15 02:43:02 --> Utf8 Class Initialized
INFO - 2018-05-15 02:43:02 --> Config Class Initialized
INFO - 2018-05-15 02:43:02 --> Hooks Class Initialized
INFO - 2018-05-15 02:43:02 --> URI Class Initialized
INFO - 2018-05-15 02:43:02 --> Language Class Initialized
INFO - 2018-05-15 02:43:02 --> URI Class Initialized
INFO - 2018-05-15 02:43:02 --> Router Class Initialized
DEBUG - 2018-05-15 02:43:02 --> UTF-8 Support Enabled
INFO - 2018-05-15 02:43:02 --> Utf8 Class Initialized
INFO - 2018-05-15 02:43:02 --> Router Class Initialized
ERROR - 2018-05-15 02:43:02 --> 404 Page Not Found: /index
INFO - 2018-05-15 02:43:02 --> Router Class Initialized
INFO - 2018-05-15 02:43:02 --> Output Class Initialized
INFO - 2018-05-15 02:43:02 --> URI Class Initialized
INFO - 2018-05-15 02:43:02 --> Output Class Initialized
INFO - 2018-05-15 02:43:02 --> Output Class Initialized
INFO - 2018-05-15 02:43:02 --> Security Class Initialized
INFO - 2018-05-15 02:43:02 --> Router Class Initialized
INFO - 2018-05-15 02:43:02 --> Security Class Initialized
INFO - 2018-05-15 02:43:02 --> Security Class Initialized
DEBUG - 2018-05-15 02:43:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 02:43:02 --> Output Class Initialized
INFO - 2018-05-15 02:43:02 --> Input Class Initialized
DEBUG - 2018-05-15 02:43:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-15 02:43:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 02:43:02 --> Input Class Initialized
INFO - 2018-05-15 02:43:02 --> Security Class Initialized
INFO - 2018-05-15 02:43:02 --> Input Class Initialized
DEBUG - 2018-05-15 02:43:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 02:43:02 --> Language Class Initialized
INFO - 2018-05-15 02:43:02 --> Language Class Initialized
INFO - 2018-05-15 02:43:02 --> Language Class Initialized
INFO - 2018-05-15 02:43:02 --> Input Class Initialized
ERROR - 2018-05-15 02:43:02 --> 404 Page Not Found: /index
ERROR - 2018-05-15 02:43:02 --> 404 Page Not Found: /index
ERROR - 2018-05-15 02:43:02 --> 404 Page Not Found: /index
INFO - 2018-05-15 02:43:02 --> Language Class Initialized
ERROR - 2018-05-15 02:43:02 --> 404 Page Not Found: /index
INFO - 2018-05-15 02:43:04 --> Config Class Initialized
INFO - 2018-05-15 02:43:04 --> Hooks Class Initialized
DEBUG - 2018-05-15 02:43:04 --> UTF-8 Support Enabled
INFO - 2018-05-15 02:43:04 --> Utf8 Class Initialized
INFO - 2018-05-15 02:43:04 --> URI Class Initialized
INFO - 2018-05-15 02:43:04 --> Router Class Initialized
INFO - 2018-05-15 02:43:04 --> Output Class Initialized
INFO - 2018-05-15 02:43:04 --> Security Class Initialized
DEBUG - 2018-05-15 02:43:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 02:43:04 --> Input Class Initialized
INFO - 2018-05-15 02:43:04 --> Language Class Initialized
ERROR - 2018-05-15 02:43:04 --> 404 Page Not Found: /index
INFO - 2018-05-15 02:43:04 --> Config Class Initialized
INFO - 2018-05-15 02:43:04 --> Hooks Class Initialized
DEBUG - 2018-05-15 02:43:04 --> UTF-8 Support Enabled
INFO - 2018-05-15 02:43:04 --> Utf8 Class Initialized
INFO - 2018-05-15 02:43:04 --> URI Class Initialized
INFO - 2018-05-15 02:43:04 --> Router Class Initialized
INFO - 2018-05-15 02:43:04 --> Output Class Initialized
INFO - 2018-05-15 02:43:04 --> Security Class Initialized
DEBUG - 2018-05-15 02:43:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 02:43:04 --> Input Class Initialized
INFO - 2018-05-15 02:43:04 --> Language Class Initialized
ERROR - 2018-05-15 02:43:04 --> 404 Page Not Found: /index
INFO - 2018-05-15 02:43:04 --> Config Class Initialized
INFO - 2018-05-15 02:43:04 --> Hooks Class Initialized
DEBUG - 2018-05-15 02:43:04 --> UTF-8 Support Enabled
INFO - 2018-05-15 02:43:04 --> Utf8 Class Initialized
INFO - 2018-05-15 02:43:04 --> URI Class Initialized
INFO - 2018-05-15 02:43:04 --> Router Class Initialized
INFO - 2018-05-15 02:43:04 --> Output Class Initialized
INFO - 2018-05-15 02:43:04 --> Security Class Initialized
DEBUG - 2018-05-15 02:43:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 02:43:04 --> Input Class Initialized
INFO - 2018-05-15 02:43:04 --> Language Class Initialized
ERROR - 2018-05-15 02:43:04 --> 404 Page Not Found: /index
INFO - 2018-05-15 02:43:09 --> Config Class Initialized
INFO - 2018-05-15 02:43:09 --> Hooks Class Initialized
DEBUG - 2018-05-15 02:43:09 --> UTF-8 Support Enabled
INFO - 2018-05-15 02:43:09 --> Utf8 Class Initialized
INFO - 2018-05-15 02:43:09 --> URI Class Initialized
INFO - 2018-05-15 02:43:09 --> Router Class Initialized
INFO - 2018-05-15 02:43:09 --> Output Class Initialized
INFO - 2018-05-15 02:43:09 --> Security Class Initialized
DEBUG - 2018-05-15 02:43:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 02:43:09 --> Input Class Initialized
INFO - 2018-05-15 02:43:09 --> Language Class Initialized
INFO - 2018-05-15 02:43:09 --> Language Class Initialized
INFO - 2018-05-15 02:43:09 --> Config Class Initialized
INFO - 2018-05-15 02:43:09 --> Loader Class Initialized
DEBUG - 2018-05-15 02:43:09 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-15 02:43:09 --> Helper loaded: url_helper
INFO - 2018-05-15 02:43:09 --> Helper loaded: form_helper
INFO - 2018-05-15 02:43:09 --> Helper loaded: date_helper
INFO - 2018-05-15 02:43:09 --> Helper loaded: util_helper
INFO - 2018-05-15 02:43:09 --> Helper loaded: text_helper
INFO - 2018-05-15 02:43:09 --> Helper loaded: string_helper
INFO - 2018-05-15 02:43:09 --> Database Driver Class Initialized
DEBUG - 2018-05-15 02:43:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-15 02:43:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-15 02:43:09 --> Email Class Initialized
INFO - 2018-05-15 02:43:10 --> Controller Class Initialized
DEBUG - 2018-05-15 02:43:10 --> Programs MX_Controller Initialized
INFO - 2018-05-15 02:43:10 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-15 02:43:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-05-15 02:43:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-15 02:43:10 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-15 02:43:10 --> Login MX_Controller Initialized
DEBUG - 2018-05-15 02:43:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-15 02:43:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-05-15 02:43:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-05-15 02:43:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-05-15 02:43:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-05-15 02:43:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-05-15 02:43:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/programs/create_program.php
INFO - 2018-05-15 02:43:10 --> Final output sent to browser
DEBUG - 2018-05-15 02:43:10 --> Total execution time: 0.4943
INFO - 2018-05-15 02:43:21 --> Config Class Initialized
INFO - 2018-05-15 02:43:21 --> Hooks Class Initialized
DEBUG - 2018-05-15 02:43:21 --> UTF-8 Support Enabled
INFO - 2018-05-15 02:43:21 --> Utf8 Class Initialized
INFO - 2018-05-15 02:43:21 --> URI Class Initialized
INFO - 2018-05-15 02:43:21 --> Router Class Initialized
INFO - 2018-05-15 02:43:21 --> Output Class Initialized
INFO - 2018-05-15 02:43:21 --> Security Class Initialized
DEBUG - 2018-05-15 02:43:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 02:43:21 --> Input Class Initialized
INFO - 2018-05-15 02:43:21 --> Language Class Initialized
INFO - 2018-05-15 02:43:21 --> Language Class Initialized
INFO - 2018-05-15 02:43:21 --> Config Class Initialized
INFO - 2018-05-15 02:43:21 --> Loader Class Initialized
DEBUG - 2018-05-15 02:43:21 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-15 02:43:21 --> Helper loaded: url_helper
INFO - 2018-05-15 02:43:21 --> Helper loaded: form_helper
INFO - 2018-05-15 02:43:21 --> Helper loaded: date_helper
INFO - 2018-05-15 02:43:21 --> Helper loaded: util_helper
INFO - 2018-05-15 02:43:21 --> Helper loaded: text_helper
INFO - 2018-05-15 02:43:21 --> Helper loaded: string_helper
INFO - 2018-05-15 02:43:21 --> Database Driver Class Initialized
DEBUG - 2018-05-15 02:43:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-15 02:43:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-15 02:43:21 --> Email Class Initialized
INFO - 2018-05-15 02:43:21 --> Controller Class Initialized
DEBUG - 2018-05-15 02:43:21 --> Programs MX_Controller Initialized
INFO - 2018-05-15 02:43:21 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-15 02:43:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-05-15 02:43:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-15 02:43:21 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-15 02:43:21 --> Login MX_Controller Initialized
DEBUG - 2018-05-15 02:43:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-15 02:43:21 --> Config Class Initialized
INFO - 2018-05-15 02:43:21 --> Hooks Class Initialized
DEBUG - 2018-05-15 02:43:21 --> UTF-8 Support Enabled
INFO - 2018-05-15 02:43:21 --> Utf8 Class Initialized
INFO - 2018-05-15 02:43:21 --> URI Class Initialized
INFO - 2018-05-15 02:43:21 --> Router Class Initialized
INFO - 2018-05-15 02:43:21 --> Output Class Initialized
INFO - 2018-05-15 02:43:21 --> Security Class Initialized
DEBUG - 2018-05-15 02:43:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 02:43:21 --> Input Class Initialized
INFO - 2018-05-15 02:43:21 --> Language Class Initialized
INFO - 2018-05-15 02:43:21 --> Language Class Initialized
INFO - 2018-05-15 02:43:21 --> Config Class Initialized
INFO - 2018-05-15 02:43:21 --> Loader Class Initialized
DEBUG - 2018-05-15 02:43:21 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-15 02:43:21 --> Helper loaded: url_helper
INFO - 2018-05-15 02:43:21 --> Helper loaded: form_helper
INFO - 2018-05-15 02:43:21 --> Helper loaded: date_helper
INFO - 2018-05-15 02:43:21 --> Helper loaded: util_helper
INFO - 2018-05-15 02:43:21 --> Helper loaded: text_helper
INFO - 2018-05-15 02:43:21 --> Helper loaded: string_helper
INFO - 2018-05-15 02:43:21 --> Database Driver Class Initialized
DEBUG - 2018-05-15 02:43:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-15 02:43:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-15 02:43:21 --> Email Class Initialized
INFO - 2018-05-15 02:43:21 --> Controller Class Initialized
DEBUG - 2018-05-15 02:43:21 --> Programs MX_Controller Initialized
INFO - 2018-05-15 02:43:21 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-15 02:43:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-05-15 02:43:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-15 02:43:21 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-15 02:43:21 --> Login MX_Controller Initialized
DEBUG - 2018-05-15 02:43:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-15 02:43:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-05-15 02:43:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-05-15 02:43:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-05-15 02:43:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-05-15 02:43:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-05-15 02:43:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/programs/programs.php
INFO - 2018-05-15 02:43:22 --> Final output sent to browser
DEBUG - 2018-05-15 02:43:22 --> Total execution time: 0.4840
INFO - 2018-05-15 02:43:22 --> Config Class Initialized
INFO - 2018-05-15 02:43:22 --> Hooks Class Initialized
DEBUG - 2018-05-15 02:43:22 --> UTF-8 Support Enabled
INFO - 2018-05-15 02:43:22 --> Utf8 Class Initialized
INFO - 2018-05-15 02:43:22 --> URI Class Initialized
INFO - 2018-05-15 02:43:22 --> Router Class Initialized
INFO - 2018-05-15 02:43:22 --> Output Class Initialized
INFO - 2018-05-15 02:43:22 --> Security Class Initialized
DEBUG - 2018-05-15 02:43:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 02:43:22 --> Input Class Initialized
INFO - 2018-05-15 02:43:22 --> Language Class Initialized
INFO - 2018-05-15 02:43:22 --> Language Class Initialized
INFO - 2018-05-15 02:43:22 --> Config Class Initialized
INFO - 2018-05-15 02:43:22 --> Loader Class Initialized
DEBUG - 2018-05-15 02:43:22 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-15 02:43:22 --> Helper loaded: url_helper
INFO - 2018-05-15 02:43:22 --> Helper loaded: form_helper
INFO - 2018-05-15 02:43:22 --> Helper loaded: date_helper
INFO - 2018-05-15 02:43:22 --> Helper loaded: util_helper
INFO - 2018-05-15 02:43:22 --> Helper loaded: text_helper
INFO - 2018-05-15 02:43:22 --> Helper loaded: string_helper
INFO - 2018-05-15 02:43:22 --> Database Driver Class Initialized
DEBUG - 2018-05-15 02:43:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-15 02:43:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-15 02:43:22 --> Email Class Initialized
INFO - 2018-05-15 02:43:22 --> Controller Class Initialized
DEBUG - 2018-05-15 02:43:22 --> Programs MX_Controller Initialized
INFO - 2018-05-15 02:43:22 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-15 02:43:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-05-15 02:43:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-15 02:43:22 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-15 02:43:22 --> Login MX_Controller Initialized
DEBUG - 2018-05-15 02:43:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-15 02:43:22 --> Final output sent to browser
DEBUG - 2018-05-15 02:43:22 --> Total execution time: 0.4358
INFO - 2018-05-15 02:43:24 --> Config Class Initialized
INFO - 2018-05-15 02:43:24 --> Hooks Class Initialized
DEBUG - 2018-05-15 02:43:24 --> UTF-8 Support Enabled
INFO - 2018-05-15 02:43:24 --> Utf8 Class Initialized
INFO - 2018-05-15 02:43:24 --> URI Class Initialized
INFO - 2018-05-15 02:43:24 --> Router Class Initialized
INFO - 2018-05-15 02:43:24 --> Output Class Initialized
INFO - 2018-05-15 02:43:24 --> Security Class Initialized
DEBUG - 2018-05-15 02:43:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 02:43:24 --> Input Class Initialized
INFO - 2018-05-15 02:43:24 --> Language Class Initialized
INFO - 2018-05-15 02:43:24 --> Language Class Initialized
INFO - 2018-05-15 02:43:24 --> Config Class Initialized
INFO - 2018-05-15 02:43:24 --> Loader Class Initialized
DEBUG - 2018-05-15 02:43:24 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-15 02:43:24 --> Helper loaded: url_helper
INFO - 2018-05-15 02:43:24 --> Helper loaded: form_helper
INFO - 2018-05-15 02:43:24 --> Helper loaded: date_helper
INFO - 2018-05-15 02:43:24 --> Helper loaded: util_helper
INFO - 2018-05-15 02:43:24 --> Helper loaded: text_helper
INFO - 2018-05-15 02:43:24 --> Helper loaded: string_helper
INFO - 2018-05-15 02:43:24 --> Database Driver Class Initialized
DEBUG - 2018-05-15 02:43:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-15 02:43:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-15 02:43:24 --> Email Class Initialized
INFO - 2018-05-15 02:43:24 --> Controller Class Initialized
DEBUG - 2018-05-15 02:43:24 --> Programs MX_Controller Initialized
INFO - 2018-05-15 02:43:24 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-15 02:43:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-05-15 02:43:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-15 02:43:24 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-15 02:43:24 --> Login MX_Controller Initialized
DEBUG - 2018-05-15 02:43:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-15 02:43:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-05-15 02:43:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-05-15 02:43:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-05-15 02:43:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-05-15 02:43:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-05-15 02:43:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/programs/create_program.php
INFO - 2018-05-15 02:43:24 --> Final output sent to browser
DEBUG - 2018-05-15 02:43:24 --> Total execution time: 0.5354
INFO - 2018-05-15 02:43:39 --> Config Class Initialized
INFO - 2018-05-15 02:43:39 --> Hooks Class Initialized
DEBUG - 2018-05-15 02:43:39 --> UTF-8 Support Enabled
INFO - 2018-05-15 02:43:39 --> Utf8 Class Initialized
INFO - 2018-05-15 02:43:39 --> URI Class Initialized
INFO - 2018-05-15 02:43:39 --> Router Class Initialized
INFO - 2018-05-15 02:43:39 --> Output Class Initialized
INFO - 2018-05-15 02:43:39 --> Security Class Initialized
DEBUG - 2018-05-15 02:43:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 02:43:39 --> Input Class Initialized
INFO - 2018-05-15 02:43:39 --> Language Class Initialized
INFO - 2018-05-15 02:43:39 --> Language Class Initialized
INFO - 2018-05-15 02:43:39 --> Config Class Initialized
INFO - 2018-05-15 02:43:39 --> Loader Class Initialized
DEBUG - 2018-05-15 02:43:39 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-15 02:43:39 --> Helper loaded: url_helper
INFO - 2018-05-15 02:43:39 --> Helper loaded: form_helper
INFO - 2018-05-15 02:43:39 --> Helper loaded: date_helper
INFO - 2018-05-15 02:43:39 --> Helper loaded: util_helper
INFO - 2018-05-15 02:43:39 --> Helper loaded: text_helper
INFO - 2018-05-15 02:43:39 --> Helper loaded: string_helper
INFO - 2018-05-15 02:43:39 --> Database Driver Class Initialized
DEBUG - 2018-05-15 02:43:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-15 02:43:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-15 02:43:39 --> Email Class Initialized
INFO - 2018-05-15 02:43:39 --> Controller Class Initialized
DEBUG - 2018-05-15 02:43:39 --> Programs MX_Controller Initialized
INFO - 2018-05-15 02:43:39 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-15 02:43:39 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-05-15 02:43:39 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-15 02:43:39 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-15 02:43:39 --> Login MX_Controller Initialized
DEBUG - 2018-05-15 02:43:39 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-15 02:43:39 --> Config Class Initialized
INFO - 2018-05-15 02:43:39 --> Hooks Class Initialized
DEBUG - 2018-05-15 02:43:39 --> UTF-8 Support Enabled
INFO - 2018-05-15 02:43:39 --> Utf8 Class Initialized
INFO - 2018-05-15 02:43:39 --> URI Class Initialized
INFO - 2018-05-15 02:43:39 --> Router Class Initialized
INFO - 2018-05-15 02:43:39 --> Output Class Initialized
INFO - 2018-05-15 02:43:39 --> Security Class Initialized
DEBUG - 2018-05-15 02:43:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 02:43:39 --> Input Class Initialized
INFO - 2018-05-15 02:43:39 --> Language Class Initialized
INFO - 2018-05-15 02:43:39 --> Language Class Initialized
INFO - 2018-05-15 02:43:39 --> Config Class Initialized
INFO - 2018-05-15 02:43:39 --> Loader Class Initialized
DEBUG - 2018-05-15 02:43:39 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-15 02:43:39 --> Helper loaded: url_helper
INFO - 2018-05-15 02:43:39 --> Helper loaded: form_helper
INFO - 2018-05-15 02:43:39 --> Helper loaded: date_helper
INFO - 2018-05-15 02:43:39 --> Helper loaded: util_helper
INFO - 2018-05-15 02:43:39 --> Helper loaded: text_helper
INFO - 2018-05-15 02:43:39 --> Helper loaded: string_helper
INFO - 2018-05-15 02:43:39 --> Database Driver Class Initialized
DEBUG - 2018-05-15 02:43:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-15 02:43:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-15 02:43:40 --> Email Class Initialized
INFO - 2018-05-15 02:43:40 --> Controller Class Initialized
DEBUG - 2018-05-15 02:43:40 --> Programs MX_Controller Initialized
INFO - 2018-05-15 02:43:40 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-15 02:43:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-05-15 02:43:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-15 02:43:40 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-15 02:43:40 --> Login MX_Controller Initialized
DEBUG - 2018-05-15 02:43:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-15 02:43:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-05-15 02:43:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-05-15 02:43:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-05-15 02:43:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-05-15 02:43:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-05-15 02:43:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/programs/programs.php
INFO - 2018-05-15 02:43:40 --> Final output sent to browser
DEBUG - 2018-05-15 02:43:40 --> Total execution time: 0.4916
INFO - 2018-05-15 02:43:40 --> Config Class Initialized
INFO - 2018-05-15 02:43:40 --> Hooks Class Initialized
DEBUG - 2018-05-15 02:43:40 --> UTF-8 Support Enabled
INFO - 2018-05-15 02:43:40 --> Utf8 Class Initialized
INFO - 2018-05-15 02:43:40 --> URI Class Initialized
INFO - 2018-05-15 02:43:40 --> Router Class Initialized
INFO - 2018-05-15 02:43:40 --> Output Class Initialized
INFO - 2018-05-15 02:43:40 --> Security Class Initialized
DEBUG - 2018-05-15 02:43:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 02:43:40 --> Input Class Initialized
INFO - 2018-05-15 02:43:40 --> Language Class Initialized
INFO - 2018-05-15 02:43:40 --> Language Class Initialized
INFO - 2018-05-15 02:43:40 --> Config Class Initialized
INFO - 2018-05-15 02:43:40 --> Loader Class Initialized
DEBUG - 2018-05-15 02:43:40 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-15 02:43:40 --> Helper loaded: url_helper
INFO - 2018-05-15 02:43:40 --> Helper loaded: form_helper
INFO - 2018-05-15 02:43:40 --> Helper loaded: date_helper
INFO - 2018-05-15 02:43:40 --> Helper loaded: util_helper
INFO - 2018-05-15 02:43:40 --> Helper loaded: text_helper
INFO - 2018-05-15 02:43:40 --> Helper loaded: string_helper
INFO - 2018-05-15 02:43:40 --> Database Driver Class Initialized
DEBUG - 2018-05-15 02:43:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-15 02:43:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-15 02:43:40 --> Email Class Initialized
INFO - 2018-05-15 02:43:40 --> Controller Class Initialized
DEBUG - 2018-05-15 02:43:40 --> Programs MX_Controller Initialized
INFO - 2018-05-15 02:43:40 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-15 02:43:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-05-15 02:43:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-15 02:43:40 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-15 02:43:40 --> Login MX_Controller Initialized
DEBUG - 2018-05-15 02:43:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-15 02:43:40 --> Final output sent to browser
DEBUG - 2018-05-15 02:43:40 --> Total execution time: 0.4241
INFO - 2018-05-15 02:43:55 --> Config Class Initialized
INFO - 2018-05-15 02:43:55 --> Hooks Class Initialized
DEBUG - 2018-05-15 02:43:55 --> UTF-8 Support Enabled
INFO - 2018-05-15 02:43:55 --> Utf8 Class Initialized
INFO - 2018-05-15 02:43:55 --> URI Class Initialized
INFO - 2018-05-15 02:43:55 --> Router Class Initialized
INFO - 2018-05-15 02:43:55 --> Output Class Initialized
INFO - 2018-05-15 02:43:55 --> Security Class Initialized
DEBUG - 2018-05-15 02:43:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 02:43:55 --> Input Class Initialized
INFO - 2018-05-15 02:43:55 --> Language Class Initialized
INFO - 2018-05-15 02:43:55 --> Language Class Initialized
INFO - 2018-05-15 02:43:55 --> Config Class Initialized
INFO - 2018-05-15 02:43:55 --> Loader Class Initialized
DEBUG - 2018-05-15 02:43:55 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-15 02:43:55 --> Helper loaded: url_helper
INFO - 2018-05-15 02:43:55 --> Helper loaded: form_helper
INFO - 2018-05-15 02:43:55 --> Helper loaded: date_helper
INFO - 2018-05-15 02:43:55 --> Helper loaded: util_helper
INFO - 2018-05-15 02:43:55 --> Helper loaded: text_helper
INFO - 2018-05-15 02:43:55 --> Helper loaded: string_helper
INFO - 2018-05-15 02:43:55 --> Database Driver Class Initialized
DEBUG - 2018-05-15 02:43:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-15 02:43:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-15 02:43:55 --> Email Class Initialized
INFO - 2018-05-15 02:43:55 --> Controller Class Initialized
DEBUG - 2018-05-15 02:43:55 --> Home MX_Controller Initialized
DEBUG - 2018-05-15 02:43:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-15 02:43:55 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-15 02:43:55 --> Login MX_Controller Initialized
INFO - 2018-05-15 02:43:55 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-15 02:43:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-15 02:43:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-15 02:43:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-05-15 02:43:55 --> Final output sent to browser
DEBUG - 2018-05-15 02:43:55 --> Total execution time: 0.3846
INFO - 2018-05-15 02:43:55 --> Config Class Initialized
INFO - 2018-05-15 02:43:55 --> Hooks Class Initialized
DEBUG - 2018-05-15 02:43:55 --> UTF-8 Support Enabled
INFO - 2018-05-15 02:43:55 --> Utf8 Class Initialized
INFO - 2018-05-15 02:43:55 --> URI Class Initialized
INFO - 2018-05-15 02:43:55 --> Router Class Initialized
INFO - 2018-05-15 02:43:55 --> Output Class Initialized
INFO - 2018-05-15 02:43:55 --> Security Class Initialized
DEBUG - 2018-05-15 02:43:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 02:43:55 --> Input Class Initialized
INFO - 2018-05-15 02:43:55 --> Language Class Initialized
ERROR - 2018-05-15 02:43:55 --> 404 Page Not Found: /index
INFO - 2018-05-15 02:43:56 --> Config Class Initialized
INFO - 2018-05-15 02:43:56 --> Config Class Initialized
INFO - 2018-05-15 02:43:56 --> Config Class Initialized
INFO - 2018-05-15 02:43:56 --> Hooks Class Initialized
INFO - 2018-05-15 02:43:56 --> Hooks Class Initialized
INFO - 2018-05-15 02:43:56 --> Hooks Class Initialized
INFO - 2018-05-15 02:43:56 --> Config Class Initialized
DEBUG - 2018-05-15 02:43:56 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 02:43:56 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 02:43:56 --> UTF-8 Support Enabled
INFO - 2018-05-15 02:43:56 --> Config Class Initialized
INFO - 2018-05-15 02:43:56 --> Config Class Initialized
INFO - 2018-05-15 02:43:56 --> Hooks Class Initialized
INFO - 2018-05-15 02:43:56 --> Hooks Class Initialized
INFO - 2018-05-15 02:43:56 --> Utf8 Class Initialized
DEBUG - 2018-05-15 02:43:56 --> UTF-8 Support Enabled
INFO - 2018-05-15 02:43:56 --> Utf8 Class Initialized
INFO - 2018-05-15 02:43:56 --> Utf8 Class Initialized
INFO - 2018-05-15 02:43:56 --> Hooks Class Initialized
INFO - 2018-05-15 02:43:56 --> Utf8 Class Initialized
INFO - 2018-05-15 02:43:56 --> URI Class Initialized
INFO - 2018-05-15 02:43:56 --> URI Class Initialized
INFO - 2018-05-15 02:43:56 --> URI Class Initialized
DEBUG - 2018-05-15 02:43:56 --> UTF-8 Support Enabled
INFO - 2018-05-15 02:43:56 --> Router Class Initialized
INFO - 2018-05-15 02:43:56 --> URI Class Initialized
DEBUG - 2018-05-15 02:43:56 --> UTF-8 Support Enabled
INFO - 2018-05-15 02:43:56 --> Router Class Initialized
INFO - 2018-05-15 02:43:56 --> Router Class Initialized
INFO - 2018-05-15 02:43:56 --> Utf8 Class Initialized
INFO - 2018-05-15 02:43:56 --> URI Class Initialized
INFO - 2018-05-15 02:43:56 --> Output Class Initialized
INFO - 2018-05-15 02:43:56 --> Router Class Initialized
INFO - 2018-05-15 02:43:56 --> Utf8 Class Initialized
INFO - 2018-05-15 02:43:56 --> Output Class Initialized
INFO - 2018-05-15 02:43:56 --> Output Class Initialized
INFO - 2018-05-15 02:43:56 --> Router Class Initialized
INFO - 2018-05-15 02:43:56 --> Security Class Initialized
INFO - 2018-05-15 02:43:56 --> Output Class Initialized
DEBUG - 2018-05-15 02:43:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 02:43:56 --> Output Class Initialized
INFO - 2018-05-15 02:43:56 --> Security Class Initialized
INFO - 2018-05-15 02:43:56 --> URI Class Initialized
INFO - 2018-05-15 02:43:56 --> Security Class Initialized
INFO - 2018-05-15 02:43:56 --> Security Class Initialized
INFO - 2018-05-15 02:43:56 --> Input Class Initialized
INFO - 2018-05-15 02:43:56 --> Router Class Initialized
DEBUG - 2018-05-15 02:43:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 02:43:56 --> Security Class Initialized
DEBUG - 2018-05-15 02:43:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-15 02:43:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 02:43:56 --> Input Class Initialized
INFO - 2018-05-15 02:43:56 --> Language Class Initialized
INFO - 2018-05-15 02:43:56 --> Output Class Initialized
INFO - 2018-05-15 02:43:56 --> Input Class Initialized
INFO - 2018-05-15 02:43:56 --> Input Class Initialized
DEBUG - 2018-05-15 02:43:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 02:43:56 --> Language Class Initialized
INFO - 2018-05-15 02:43:56 --> Language Class Initialized
INFO - 2018-05-15 02:43:56 --> Input Class Initialized
INFO - 2018-05-15 02:43:56 --> Language Class Initialized
INFO - 2018-05-15 02:43:56 --> Security Class Initialized
ERROR - 2018-05-15 02:43:56 --> 404 Page Not Found: /index
ERROR - 2018-05-15 02:43:56 --> 404 Page Not Found: /index
DEBUG - 2018-05-15 02:43:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 02:43:56 --> Config Class Initialized
INFO - 2018-05-15 02:43:56 --> Language Class Initialized
ERROR - 2018-05-15 02:43:56 --> 404 Page Not Found: /index
ERROR - 2018-05-15 02:43:56 --> 404 Page Not Found: /index
INFO - 2018-05-15 02:43:56 --> Hooks Class Initialized
INFO - 2018-05-15 02:43:56 --> Input Class Initialized
ERROR - 2018-05-15 02:43:56 --> 404 Page Not Found: /index
INFO - 2018-05-15 02:43:56 --> Language Class Initialized
DEBUG - 2018-05-15 02:43:56 --> UTF-8 Support Enabled
INFO - 2018-05-15 02:43:56 --> Utf8 Class Initialized
ERROR - 2018-05-15 02:43:56 --> 404 Page Not Found: /index
INFO - 2018-05-15 02:43:56 --> Config Class Initialized
INFO - 2018-05-15 02:43:56 --> Config Class Initialized
INFO - 2018-05-15 02:43:56 --> Config Class Initialized
INFO - 2018-05-15 02:43:56 --> Hooks Class Initialized
INFO - 2018-05-15 02:43:56 --> Hooks Class Initialized
INFO - 2018-05-15 02:43:56 --> Hooks Class Initialized
INFO - 2018-05-15 02:43:56 --> Config Class Initialized
INFO - 2018-05-15 02:43:56 --> URI Class Initialized
INFO - 2018-05-15 02:43:56 --> Hooks Class Initialized
DEBUG - 2018-05-15 02:43:56 --> UTF-8 Support Enabled
INFO - 2018-05-15 02:43:56 --> Router Class Initialized
DEBUG - 2018-05-15 02:43:56 --> UTF-8 Support Enabled
INFO - 2018-05-15 02:43:56 --> Utf8 Class Initialized
DEBUG - 2018-05-15 02:43:56 --> UTF-8 Support Enabled
INFO - 2018-05-15 02:43:56 --> Utf8 Class Initialized
INFO - 2018-05-15 02:43:56 --> Output Class Initialized
INFO - 2018-05-15 02:43:56 --> Utf8 Class Initialized
INFO - 2018-05-15 02:43:56 --> URI Class Initialized
INFO - 2018-05-15 02:43:56 --> URI Class Initialized
DEBUG - 2018-05-15 02:43:56 --> UTF-8 Support Enabled
INFO - 2018-05-15 02:43:56 --> Security Class Initialized
INFO - 2018-05-15 02:43:56 --> URI Class Initialized
INFO - 2018-05-15 02:43:56 --> Utf8 Class Initialized
INFO - 2018-05-15 02:43:56 --> Router Class Initialized
INFO - 2018-05-15 02:43:56 --> Router Class Initialized
DEBUG - 2018-05-15 02:43:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 02:43:56 --> Input Class Initialized
INFO - 2018-05-15 02:43:56 --> Output Class Initialized
INFO - 2018-05-15 02:43:56 --> Router Class Initialized
INFO - 2018-05-15 02:43:56 --> URI Class Initialized
INFO - 2018-05-15 02:43:56 --> Output Class Initialized
INFO - 2018-05-15 02:43:56 --> Output Class Initialized
INFO - 2018-05-15 02:43:56 --> Language Class Initialized
INFO - 2018-05-15 02:43:56 --> Security Class Initialized
INFO - 2018-05-15 02:43:56 --> Security Class Initialized
INFO - 2018-05-15 02:43:56 --> Router Class Initialized
INFO - 2018-05-15 02:43:56 --> Security Class Initialized
ERROR - 2018-05-15 02:43:56 --> 404 Page Not Found: /index
DEBUG - 2018-05-15 02:43:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-15 02:43:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 02:43:56 --> Output Class Initialized
DEBUG - 2018-05-15 02:43:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 02:43:56 --> Input Class Initialized
INFO - 2018-05-15 02:43:56 --> Input Class Initialized
INFO - 2018-05-15 02:43:56 --> Security Class Initialized
INFO - 2018-05-15 02:43:56 --> Config Class Initialized
INFO - 2018-05-15 02:43:56 --> Input Class Initialized
INFO - 2018-05-15 02:43:56 --> Hooks Class Initialized
INFO - 2018-05-15 02:43:56 --> Language Class Initialized
ERROR - 2018-05-15 02:43:56 --> 404 Page Not Found: /index
INFO - 2018-05-15 02:43:56 --> Language Class Initialized
ERROR - 2018-05-15 02:43:56 --> 404 Page Not Found: /index
INFO - 2018-05-15 02:43:56 --> Language Class Initialized
DEBUG - 2018-05-15 02:43:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-15 02:43:56 --> UTF-8 Support Enabled
INFO - 2018-05-15 02:43:56 --> Utf8 Class Initialized
INFO - 2018-05-15 02:43:56 --> Config Class Initialized
INFO - 2018-05-15 02:43:56 --> Config Class Initialized
INFO - 2018-05-15 02:43:56 --> Hooks Class Initialized
INFO - 2018-05-15 02:43:56 --> Hooks Class Initialized
INFO - 2018-05-15 02:43:56 --> Input Class Initialized
ERROR - 2018-05-15 02:43:56 --> 404 Page Not Found: /index
INFO - 2018-05-15 02:43:56 --> URI Class Initialized
DEBUG - 2018-05-15 02:43:57 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 02:43:57 --> UTF-8 Support Enabled
INFO - 2018-05-15 02:43:57 --> Config Class Initialized
INFO - 2018-05-15 02:43:57 --> Router Class Initialized
INFO - 2018-05-15 02:43:57 --> Language Class Initialized
INFO - 2018-05-15 02:43:57 --> Hooks Class Initialized
INFO - 2018-05-15 02:43:57 --> Utf8 Class Initialized
INFO - 2018-05-15 02:43:57 --> Output Class Initialized
INFO - 2018-05-15 02:43:57 --> Utf8 Class Initialized
ERROR - 2018-05-15 02:43:57 --> 404 Page Not Found: /index
INFO - 2018-05-15 02:43:57 --> URI Class Initialized
DEBUG - 2018-05-15 02:43:57 --> UTF-8 Support Enabled
INFO - 2018-05-15 02:43:57 --> Security Class Initialized
INFO - 2018-05-15 02:43:57 --> URI Class Initialized
INFO - 2018-05-15 02:43:57 --> Utf8 Class Initialized
DEBUG - 2018-05-15 02:43:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 02:43:57 --> Router Class Initialized
INFO - 2018-05-15 02:43:57 --> Router Class Initialized
INFO - 2018-05-15 02:43:57 --> Input Class Initialized
INFO - 2018-05-15 02:43:57 --> Output Class Initialized
INFO - 2018-05-15 02:43:57 --> URI Class Initialized
INFO - 2018-05-15 02:43:57 --> Output Class Initialized
INFO - 2018-05-15 02:43:57 --> Security Class Initialized
INFO - 2018-05-15 02:43:57 --> Language Class Initialized
INFO - 2018-05-15 02:43:57 --> Security Class Initialized
INFO - 2018-05-15 02:43:57 --> Router Class Initialized
INFO - 2018-05-15 02:43:57 --> Output Class Initialized
ERROR - 2018-05-15 02:43:57 --> 404 Page Not Found: /index
DEBUG - 2018-05-15 02:43:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-15 02:43:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 02:43:57 --> Input Class Initialized
INFO - 2018-05-15 02:43:57 --> Input Class Initialized
INFO - 2018-05-15 02:43:57 --> Security Class Initialized
DEBUG - 2018-05-15 02:43:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 02:43:57 --> Language Class Initialized
INFO - 2018-05-15 02:43:57 --> Language Class Initialized
INFO - 2018-05-15 02:43:57 --> Input Class Initialized
ERROR - 2018-05-15 02:43:57 --> 404 Page Not Found: /index
ERROR - 2018-05-15 02:43:57 --> 404 Page Not Found: /index
INFO - 2018-05-15 02:43:57 --> Language Class Initialized
ERROR - 2018-05-15 02:43:57 --> 404 Page Not Found: /index
INFO - 2018-05-15 02:43:57 --> Config Class Initialized
INFO - 2018-05-15 02:43:57 --> Hooks Class Initialized
DEBUG - 2018-05-15 02:43:57 --> UTF-8 Support Enabled
INFO - 2018-05-15 02:43:57 --> Utf8 Class Initialized
INFO - 2018-05-15 02:43:57 --> URI Class Initialized
INFO - 2018-05-15 02:43:57 --> Router Class Initialized
INFO - 2018-05-15 02:43:57 --> Output Class Initialized
INFO - 2018-05-15 02:43:57 --> Security Class Initialized
DEBUG - 2018-05-15 02:43:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 02:43:57 --> Input Class Initialized
INFO - 2018-05-15 02:43:57 --> Language Class Initialized
ERROR - 2018-05-15 02:43:57 --> 404 Page Not Found: /index
INFO - 2018-05-15 02:44:00 --> Config Class Initialized
INFO - 2018-05-15 02:44:00 --> Hooks Class Initialized
DEBUG - 2018-05-15 02:44:00 --> UTF-8 Support Enabled
INFO - 2018-05-15 02:44:00 --> Utf8 Class Initialized
INFO - 2018-05-15 02:44:00 --> URI Class Initialized
INFO - 2018-05-15 02:44:00 --> Router Class Initialized
INFO - 2018-05-15 02:44:00 --> Output Class Initialized
INFO - 2018-05-15 02:44:00 --> Security Class Initialized
DEBUG - 2018-05-15 02:44:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 02:44:00 --> Input Class Initialized
INFO - 2018-05-15 02:44:00 --> Language Class Initialized
ERROR - 2018-05-15 02:44:00 --> 404 Page Not Found: /index
INFO - 2018-05-15 02:44:00 --> Config Class Initialized
INFO - 2018-05-15 02:44:00 --> Hooks Class Initialized
DEBUG - 2018-05-15 02:44:00 --> UTF-8 Support Enabled
INFO - 2018-05-15 02:44:00 --> Utf8 Class Initialized
INFO - 2018-05-15 02:44:00 --> URI Class Initialized
INFO - 2018-05-15 02:44:00 --> Router Class Initialized
INFO - 2018-05-15 02:44:00 --> Output Class Initialized
INFO - 2018-05-15 02:44:00 --> Security Class Initialized
DEBUG - 2018-05-15 02:44:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 02:44:00 --> Input Class Initialized
INFO - 2018-05-15 02:44:00 --> Language Class Initialized
ERROR - 2018-05-15 02:44:00 --> 404 Page Not Found: /index
INFO - 2018-05-15 02:44:00 --> Config Class Initialized
INFO - 2018-05-15 02:44:00 --> Hooks Class Initialized
DEBUG - 2018-05-15 02:44:00 --> UTF-8 Support Enabled
INFO - 2018-05-15 02:44:00 --> Utf8 Class Initialized
INFO - 2018-05-15 02:44:00 --> URI Class Initialized
INFO - 2018-05-15 02:44:00 --> Router Class Initialized
INFO - 2018-05-15 02:44:00 --> Output Class Initialized
INFO - 2018-05-15 02:44:00 --> Security Class Initialized
DEBUG - 2018-05-15 02:44:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 02:44:00 --> Input Class Initialized
INFO - 2018-05-15 02:44:00 --> Language Class Initialized
ERROR - 2018-05-15 02:44:00 --> 404 Page Not Found: /index
INFO - 2018-05-15 02:44:26 --> Config Class Initialized
INFO - 2018-05-15 02:44:26 --> Hooks Class Initialized
DEBUG - 2018-05-15 02:44:26 --> UTF-8 Support Enabled
INFO - 2018-05-15 02:44:26 --> Utf8 Class Initialized
INFO - 2018-05-15 02:44:26 --> URI Class Initialized
INFO - 2018-05-15 02:44:26 --> Router Class Initialized
INFO - 2018-05-15 02:44:26 --> Output Class Initialized
INFO - 2018-05-15 02:44:26 --> Security Class Initialized
DEBUG - 2018-05-15 02:44:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 02:44:26 --> Input Class Initialized
INFO - 2018-05-15 02:44:26 --> Language Class Initialized
INFO - 2018-05-15 02:44:26 --> Language Class Initialized
INFO - 2018-05-15 02:44:26 --> Config Class Initialized
INFO - 2018-05-15 02:44:26 --> Loader Class Initialized
DEBUG - 2018-05-15 02:44:26 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-15 02:44:26 --> Helper loaded: url_helper
INFO - 2018-05-15 02:44:26 --> Helper loaded: form_helper
INFO - 2018-05-15 02:44:26 --> Helper loaded: date_helper
INFO - 2018-05-15 02:44:26 --> Helper loaded: util_helper
INFO - 2018-05-15 02:44:26 --> Helper loaded: text_helper
INFO - 2018-05-15 02:44:26 --> Helper loaded: string_helper
INFO - 2018-05-15 02:44:26 --> Database Driver Class Initialized
DEBUG - 2018-05-15 02:44:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-15 02:44:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-15 02:44:26 --> Email Class Initialized
INFO - 2018-05-15 02:44:26 --> Controller Class Initialized
DEBUG - 2018-05-15 02:44:26 --> Admin MX_Controller Initialized
INFO - 2018-05-15 02:44:26 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-15 02:44:26 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-15 02:44:26 --> Login MX_Controller Initialized
DEBUG - 2018-05-15 02:44:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-15 02:44:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-15 02:44:26 --> Final output sent to browser
DEBUG - 2018-05-15 02:44:26 --> Total execution time: 0.4732
INFO - 2018-05-15 02:44:26 --> Config Class Initialized
INFO - 2018-05-15 02:44:26 --> Hooks Class Initialized
DEBUG - 2018-05-15 02:44:26 --> UTF-8 Support Enabled
INFO - 2018-05-15 02:44:26 --> Utf8 Class Initialized
INFO - 2018-05-15 02:44:26 --> URI Class Initialized
INFO - 2018-05-15 02:44:26 --> Router Class Initialized
INFO - 2018-05-15 02:44:26 --> Output Class Initialized
INFO - 2018-05-15 02:44:26 --> Security Class Initialized
DEBUG - 2018-05-15 02:44:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 02:44:26 --> Input Class Initialized
INFO - 2018-05-15 02:44:26 --> Language Class Initialized
INFO - 2018-05-15 02:44:26 --> Language Class Initialized
INFO - 2018-05-15 02:44:26 --> Config Class Initialized
INFO - 2018-05-15 02:44:26 --> Loader Class Initialized
DEBUG - 2018-05-15 02:44:26 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-15 02:44:26 --> Helper loaded: url_helper
INFO - 2018-05-15 02:44:26 --> Helper loaded: form_helper
INFO - 2018-05-15 02:44:27 --> Helper loaded: date_helper
INFO - 2018-05-15 02:44:27 --> Helper loaded: util_helper
INFO - 2018-05-15 02:44:27 --> Helper loaded: text_helper
INFO - 2018-05-15 02:44:27 --> Helper loaded: string_helper
INFO - 2018-05-15 02:44:27 --> Database Driver Class Initialized
DEBUG - 2018-05-15 02:44:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-15 02:44:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-15 02:44:27 --> Email Class Initialized
INFO - 2018-05-15 02:44:27 --> Controller Class Initialized
DEBUG - 2018-05-15 02:44:27 --> Admin MX_Controller Initialized
INFO - 2018-05-15 02:44:27 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-15 02:44:27 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-15 02:44:27 --> Login MX_Controller Initialized
DEBUG - 2018-05-15 02:44:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-15 02:44:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-15 02:44:27 --> Final output sent to browser
DEBUG - 2018-05-15 02:44:27 --> Total execution time: 0.4822
INFO - 2018-05-15 02:44:30 --> Config Class Initialized
INFO - 2018-05-15 02:44:30 --> Hooks Class Initialized
DEBUG - 2018-05-15 02:44:30 --> UTF-8 Support Enabled
INFO - 2018-05-15 02:44:30 --> Utf8 Class Initialized
INFO - 2018-05-15 02:44:30 --> URI Class Initialized
INFO - 2018-05-15 02:44:30 --> Router Class Initialized
INFO - 2018-05-15 02:44:30 --> Output Class Initialized
INFO - 2018-05-15 02:44:30 --> Security Class Initialized
DEBUG - 2018-05-15 02:44:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 02:44:30 --> Input Class Initialized
INFO - 2018-05-15 02:44:30 --> Language Class Initialized
INFO - 2018-05-15 02:44:30 --> Language Class Initialized
INFO - 2018-05-15 02:44:30 --> Config Class Initialized
INFO - 2018-05-15 02:44:30 --> Loader Class Initialized
DEBUG - 2018-05-15 02:44:30 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-15 02:44:30 --> Helper loaded: url_helper
INFO - 2018-05-15 02:44:30 --> Helper loaded: form_helper
INFO - 2018-05-15 02:44:30 --> Helper loaded: date_helper
INFO - 2018-05-15 02:44:30 --> Helper loaded: util_helper
INFO - 2018-05-15 02:44:30 --> Helper loaded: text_helper
INFO - 2018-05-15 02:44:30 --> Helper loaded: string_helper
INFO - 2018-05-15 02:44:30 --> Database Driver Class Initialized
DEBUG - 2018-05-15 02:44:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-15 02:44:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-15 02:44:30 --> Email Class Initialized
INFO - 2018-05-15 02:44:30 --> Controller Class Initialized
DEBUG - 2018-05-15 02:44:30 --> Home MX_Controller Initialized
DEBUG - 2018-05-15 02:44:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-15 02:44:30 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-15 02:44:30 --> Login MX_Controller Initialized
INFO - 2018-05-15 02:44:30 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-15 02:44:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-15 02:44:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-15 02:44:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-05-15 02:44:30 --> Final output sent to browser
DEBUG - 2018-05-15 02:44:30 --> Total execution time: 0.3951
INFO - 2018-05-15 02:44:30 --> Config Class Initialized
INFO - 2018-05-15 02:44:30 --> Hooks Class Initialized
DEBUG - 2018-05-15 02:44:30 --> UTF-8 Support Enabled
INFO - 2018-05-15 02:44:30 --> Utf8 Class Initialized
INFO - 2018-05-15 02:44:30 --> URI Class Initialized
INFO - 2018-05-15 02:44:30 --> Router Class Initialized
INFO - 2018-05-15 02:44:30 --> Output Class Initialized
INFO - 2018-05-15 02:44:30 --> Security Class Initialized
DEBUG - 2018-05-15 02:44:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 02:44:30 --> Input Class Initialized
INFO - 2018-05-15 02:44:30 --> Language Class Initialized
ERROR - 2018-05-15 02:44:30 --> 404 Page Not Found: /index
INFO - 2018-05-15 02:44:31 --> Config Class Initialized
INFO - 2018-05-15 02:44:31 --> Hooks Class Initialized
DEBUG - 2018-05-15 02:44:31 --> UTF-8 Support Enabled
INFO - 2018-05-15 02:44:31 --> Utf8 Class Initialized
INFO - 2018-05-15 02:44:31 --> URI Class Initialized
INFO - 2018-05-15 02:44:31 --> Router Class Initialized
INFO - 2018-05-15 02:44:31 --> Output Class Initialized
INFO - 2018-05-15 02:44:31 --> Security Class Initialized
DEBUG - 2018-05-15 02:44:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 02:44:31 --> Input Class Initialized
INFO - 2018-05-15 02:44:31 --> Language Class Initialized
ERROR - 2018-05-15 02:44:31 --> 404 Page Not Found: /index
INFO - 2018-05-15 02:44:31 --> Config Class Initialized
INFO - 2018-05-15 02:44:31 --> Config Class Initialized
INFO - 2018-05-15 02:44:31 --> Hooks Class Initialized
INFO - 2018-05-15 02:44:31 --> Hooks Class Initialized
DEBUG - 2018-05-15 02:44:31 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 02:44:31 --> UTF-8 Support Enabled
INFO - 2018-05-15 02:44:31 --> Config Class Initialized
INFO - 2018-05-15 02:44:31 --> Config Class Initialized
INFO - 2018-05-15 02:44:31 --> Utf8 Class Initialized
INFO - 2018-05-15 02:44:31 --> Hooks Class Initialized
INFO - 2018-05-15 02:44:31 --> Hooks Class Initialized
INFO - 2018-05-15 02:44:31 --> Utf8 Class Initialized
INFO - 2018-05-15 02:44:31 --> Config Class Initialized
INFO - 2018-05-15 02:44:31 --> Config Class Initialized
DEBUG - 2018-05-15 02:44:31 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 02:44:31 --> UTF-8 Support Enabled
INFO - 2018-05-15 02:44:31 --> URI Class Initialized
INFO - 2018-05-15 02:44:31 --> Hooks Class Initialized
INFO - 2018-05-15 02:44:31 --> Hooks Class Initialized
INFO - 2018-05-15 02:44:31 --> URI Class Initialized
INFO - 2018-05-15 02:44:31 --> Utf8 Class Initialized
INFO - 2018-05-15 02:44:31 --> Router Class Initialized
DEBUG - 2018-05-15 02:44:31 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 02:44:31 --> UTF-8 Support Enabled
INFO - 2018-05-15 02:44:31 --> Utf8 Class Initialized
INFO - 2018-05-15 02:44:31 --> Router Class Initialized
INFO - 2018-05-15 02:44:31 --> URI Class Initialized
INFO - 2018-05-15 02:44:32 --> Utf8 Class Initialized
INFO - 2018-05-15 02:44:32 --> Output Class Initialized
INFO - 2018-05-15 02:44:32 --> Router Class Initialized
INFO - 2018-05-15 02:44:32 --> Output Class Initialized
INFO - 2018-05-15 02:44:32 --> URI Class Initialized
INFO - 2018-05-15 02:44:32 --> Utf8 Class Initialized
INFO - 2018-05-15 02:44:32 --> URI Class Initialized
INFO - 2018-05-15 02:44:32 --> URI Class Initialized
INFO - 2018-05-15 02:44:32 --> Security Class Initialized
INFO - 2018-05-15 02:44:32 --> Router Class Initialized
INFO - 2018-05-15 02:44:32 --> Output Class Initialized
INFO - 2018-05-15 02:44:32 --> Security Class Initialized
INFO - 2018-05-15 02:44:32 --> Router Class Initialized
INFO - 2018-05-15 02:44:32 --> Router Class Initialized
INFO - 2018-05-15 02:44:32 --> Output Class Initialized
INFO - 2018-05-15 02:44:32 --> Security Class Initialized
DEBUG - 2018-05-15 02:44:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 02:44:32 --> Input Class Initialized
INFO - 2018-05-15 02:44:32 --> Language Class Initialized
ERROR - 2018-05-15 02:44:32 --> 404 Page Not Found: /index
INFO - 2018-05-15 02:44:32 --> Config Class Initialized
INFO - 2018-05-15 02:44:32 --> Hooks Class Initialized
DEBUG - 2018-05-15 02:44:32 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 02:44:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 02:44:32 --> Output Class Initialized
DEBUG - 2018-05-15 02:44:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 02:44:32 --> Output Class Initialized
INFO - 2018-05-15 02:44:32 --> Security Class Initialized
INFO - 2018-05-15 02:44:32 --> Utf8 Class Initialized
INFO - 2018-05-15 02:44:32 --> Input Class Initialized
DEBUG - 2018-05-15 02:44:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 02:44:32 --> Security Class Initialized
INFO - 2018-05-15 02:44:32 --> Input Class Initialized
INFO - 2018-05-15 02:44:32 --> Security Class Initialized
INFO - 2018-05-15 02:44:32 --> Language Class Initialized
INFO - 2018-05-15 02:44:32 --> URI Class Initialized
DEBUG - 2018-05-15 02:44:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 02:44:32 --> Language Class Initialized
INFO - 2018-05-15 02:44:32 --> Input Class Initialized
DEBUG - 2018-05-15 02:44:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-05-15 02:44:32 --> 404 Page Not Found: /index
INFO - 2018-05-15 02:44:32 --> Router Class Initialized
INFO - 2018-05-15 02:44:32 --> Input Class Initialized
INFO - 2018-05-15 02:44:32 --> Language Class Initialized
ERROR - 2018-05-15 02:44:32 --> 404 Page Not Found: /index
INFO - 2018-05-15 02:44:32 --> Input Class Initialized
INFO - 2018-05-15 02:44:32 --> Output Class Initialized
INFO - 2018-05-15 02:44:32 --> Config Class Initialized
INFO - 2018-05-15 02:44:32 --> Hooks Class Initialized
INFO - 2018-05-15 02:44:32 --> Security Class Initialized
INFO - 2018-05-15 02:44:32 --> Language Class Initialized
ERROR - 2018-05-15 02:44:32 --> 404 Page Not Found: /index
INFO - 2018-05-15 02:44:32 --> Language Class Initialized
DEBUG - 2018-05-15 02:44:32 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 02:44:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-05-15 02:44:32 --> 404 Page Not Found: /index
ERROR - 2018-05-15 02:44:32 --> 404 Page Not Found: /index
INFO - 2018-05-15 02:44:32 --> Utf8 Class Initialized
INFO - 2018-05-15 02:44:32 --> Config Class Initialized
INFO - 2018-05-15 02:44:32 --> Hooks Class Initialized
INFO - 2018-05-15 02:44:32 --> URI Class Initialized
INFO - 2018-05-15 02:44:32 --> Config Class Initialized
INFO - 2018-05-15 02:44:32 --> Config Class Initialized
INFO - 2018-05-15 02:44:32 --> Hooks Class Initialized
INFO - 2018-05-15 02:44:32 --> Hooks Class Initialized
DEBUG - 2018-05-15 02:44:32 --> UTF-8 Support Enabled
INFO - 2018-05-15 02:44:32 --> Router Class Initialized
INFO - 2018-05-15 02:44:32 --> Input Class Initialized
DEBUG - 2018-05-15 02:44:32 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 02:44:32 --> UTF-8 Support Enabled
INFO - 2018-05-15 02:44:32 --> Utf8 Class Initialized
INFO - 2018-05-15 02:44:32 --> Output Class Initialized
INFO - 2018-05-15 02:44:32 --> Language Class Initialized
INFO - 2018-05-15 02:44:32 --> Utf8 Class Initialized
INFO - 2018-05-15 02:44:32 --> Utf8 Class Initialized
INFO - 2018-05-15 02:44:32 --> URI Class Initialized
INFO - 2018-05-15 02:44:32 --> Security Class Initialized
ERROR - 2018-05-15 02:44:32 --> 404 Page Not Found: /index
INFO - 2018-05-15 02:44:32 --> URI Class Initialized
INFO - 2018-05-15 02:44:32 --> URI Class Initialized
INFO - 2018-05-15 02:44:32 --> Router Class Initialized
DEBUG - 2018-05-15 02:44:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 02:44:32 --> Router Class Initialized
INFO - 2018-05-15 02:44:32 --> Router Class Initialized
INFO - 2018-05-15 02:44:32 --> Input Class Initialized
INFO - 2018-05-15 02:44:32 --> Output Class Initialized
INFO - 2018-05-15 02:44:32 --> Config Class Initialized
INFO - 2018-05-15 02:44:32 --> Output Class Initialized
INFO - 2018-05-15 02:44:32 --> Language Class Initialized
INFO - 2018-05-15 02:44:32 --> Security Class Initialized
INFO - 2018-05-15 02:44:32 --> Hooks Class Initialized
INFO - 2018-05-15 02:44:32 --> Output Class Initialized
ERROR - 2018-05-15 02:44:32 --> 404 Page Not Found: /index
INFO - 2018-05-15 02:44:32 --> Security Class Initialized
DEBUG - 2018-05-15 02:44:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 02:44:32 --> Security Class Initialized
DEBUG - 2018-05-15 02:44:32 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 02:44:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 02:44:32 --> Input Class Initialized
INFO - 2018-05-15 02:44:32 --> Config Class Initialized
INFO - 2018-05-15 02:44:32 --> Utf8 Class Initialized
DEBUG - 2018-05-15 02:44:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 02:44:32 --> Hooks Class Initialized
INFO - 2018-05-15 02:44:32 --> Input Class Initialized
INFO - 2018-05-15 02:44:32 --> Language Class Initialized
INFO - 2018-05-15 02:44:32 --> Input Class Initialized
INFO - 2018-05-15 02:44:32 --> URI Class Initialized
INFO - 2018-05-15 02:44:32 --> Language Class Initialized
DEBUG - 2018-05-15 02:44:32 --> UTF-8 Support Enabled
ERROR - 2018-05-15 02:44:32 --> 404 Page Not Found: /index
INFO - 2018-05-15 02:44:32 --> Language Class Initialized
INFO - 2018-05-15 02:44:32 --> Utf8 Class Initialized
ERROR - 2018-05-15 02:44:32 --> 404 Page Not Found: /index
ERROR - 2018-05-15 02:44:32 --> 404 Page Not Found: /index
INFO - 2018-05-15 02:44:32 --> Router Class Initialized
INFO - 2018-05-15 02:44:32 --> URI Class Initialized
INFO - 2018-05-15 02:44:32 --> Router Class Initialized
INFO - 2018-05-15 02:44:32 --> Output Class Initialized
INFO - 2018-05-15 02:44:32 --> Security Class Initialized
DEBUG - 2018-05-15 02:44:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 02:44:32 --> Input Class Initialized
INFO - 2018-05-15 02:44:32 --> Config Class Initialized
INFO - 2018-05-15 02:44:32 --> Config Class Initialized
INFO - 2018-05-15 02:44:32 --> Config Class Initialized
INFO - 2018-05-15 02:44:32 --> Hooks Class Initialized
INFO - 2018-05-15 02:44:32 --> Hooks Class Initialized
INFO - 2018-05-15 02:44:32 --> Hooks Class Initialized
INFO - 2018-05-15 02:44:32 --> Language Class Initialized
INFO - 2018-05-15 02:44:32 --> Output Class Initialized
DEBUG - 2018-05-15 02:44:32 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 02:44:32 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 02:44:32 --> UTF-8 Support Enabled
INFO - 2018-05-15 02:44:32 --> Security Class Initialized
ERROR - 2018-05-15 02:44:32 --> 404 Page Not Found: /index
INFO - 2018-05-15 02:44:32 --> Utf8 Class Initialized
INFO - 2018-05-15 02:44:32 --> Utf8 Class Initialized
INFO - 2018-05-15 02:44:32 --> Utf8 Class Initialized
DEBUG - 2018-05-15 02:44:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 02:44:32 --> URI Class Initialized
INFO - 2018-05-15 02:44:32 --> URI Class Initialized
INFO - 2018-05-15 02:44:32 --> Input Class Initialized
INFO - 2018-05-15 02:44:32 --> URI Class Initialized
INFO - 2018-05-15 02:44:32 --> Router Class Initialized
INFO - 2018-05-15 02:44:32 --> Router Class Initialized
INFO - 2018-05-15 02:44:32 --> Language Class Initialized
INFO - 2018-05-15 02:44:32 --> Router Class Initialized
INFO - 2018-05-15 02:44:32 --> Output Class Initialized
INFO - 2018-05-15 02:44:32 --> Output Class Initialized
ERROR - 2018-05-15 02:44:32 --> 404 Page Not Found: /index
INFO - 2018-05-15 02:44:32 --> Security Class Initialized
INFO - 2018-05-15 02:44:32 --> Security Class Initialized
INFO - 2018-05-15 02:44:32 --> Output Class Initialized
DEBUG - 2018-05-15 02:44:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-15 02:44:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 02:44:32 --> Security Class Initialized
INFO - 2018-05-15 02:44:32 --> Input Class Initialized
INFO - 2018-05-15 02:44:32 --> Input Class Initialized
DEBUG - 2018-05-15 02:44:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 02:44:32 --> Language Class Initialized
INFO - 2018-05-15 02:44:32 --> Input Class Initialized
ERROR - 2018-05-15 02:44:32 --> 404 Page Not Found: /index
INFO - 2018-05-15 02:44:32 --> Language Class Initialized
INFO - 2018-05-15 02:44:32 --> Language Class Initialized
ERROR - 2018-05-15 02:44:32 --> 404 Page Not Found: /index
ERROR - 2018-05-15 02:44:32 --> 404 Page Not Found: /index
INFO - 2018-05-15 02:44:36 --> Config Class Initialized
INFO - 2018-05-15 02:44:36 --> Hooks Class Initialized
DEBUG - 2018-05-15 02:44:36 --> UTF-8 Support Enabled
INFO - 2018-05-15 02:44:36 --> Utf8 Class Initialized
INFO - 2018-05-15 02:44:36 --> URI Class Initialized
INFO - 2018-05-15 02:44:36 --> Router Class Initialized
INFO - 2018-05-15 02:44:36 --> Output Class Initialized
INFO - 2018-05-15 02:44:36 --> Security Class Initialized
DEBUG - 2018-05-15 02:44:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 02:44:36 --> Input Class Initialized
INFO - 2018-05-15 02:44:36 --> Language Class Initialized
ERROR - 2018-05-15 02:44:36 --> 404 Page Not Found: /index
INFO - 2018-05-15 02:44:36 --> Config Class Initialized
INFO - 2018-05-15 02:44:36 --> Hooks Class Initialized
DEBUG - 2018-05-15 02:44:36 --> UTF-8 Support Enabled
INFO - 2018-05-15 02:44:36 --> Utf8 Class Initialized
INFO - 2018-05-15 02:44:36 --> URI Class Initialized
INFO - 2018-05-15 02:44:36 --> Router Class Initialized
INFO - 2018-05-15 02:44:36 --> Output Class Initialized
INFO - 2018-05-15 02:44:36 --> Security Class Initialized
DEBUG - 2018-05-15 02:44:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 02:44:36 --> Input Class Initialized
INFO - 2018-05-15 02:44:36 --> Language Class Initialized
ERROR - 2018-05-15 02:44:36 --> 404 Page Not Found: /index
INFO - 2018-05-15 02:44:36 --> Config Class Initialized
INFO - 2018-05-15 02:44:36 --> Hooks Class Initialized
DEBUG - 2018-05-15 02:44:36 --> UTF-8 Support Enabled
INFO - 2018-05-15 02:44:36 --> Utf8 Class Initialized
INFO - 2018-05-15 02:44:36 --> URI Class Initialized
INFO - 2018-05-15 02:44:36 --> Router Class Initialized
INFO - 2018-05-15 02:44:36 --> Output Class Initialized
INFO - 2018-05-15 02:44:36 --> Security Class Initialized
DEBUG - 2018-05-15 02:44:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 02:44:36 --> Input Class Initialized
INFO - 2018-05-15 02:44:36 --> Language Class Initialized
ERROR - 2018-05-15 02:44:36 --> 404 Page Not Found: /index
INFO - 2018-05-15 02:51:23 --> Config Class Initialized
INFO - 2018-05-15 02:51:23 --> Hooks Class Initialized
DEBUG - 2018-05-15 02:51:23 --> UTF-8 Support Enabled
INFO - 2018-05-15 02:51:23 --> Utf8 Class Initialized
INFO - 2018-05-15 02:51:23 --> URI Class Initialized
INFO - 2018-05-15 02:51:23 --> Router Class Initialized
INFO - 2018-05-15 02:51:23 --> Output Class Initialized
INFO - 2018-05-15 02:51:23 --> Security Class Initialized
DEBUG - 2018-05-15 02:51:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 02:51:23 --> Input Class Initialized
INFO - 2018-05-15 02:51:23 --> Language Class Initialized
INFO - 2018-05-15 02:51:23 --> Language Class Initialized
INFO - 2018-05-15 02:51:23 --> Config Class Initialized
INFO - 2018-05-15 02:51:23 --> Loader Class Initialized
DEBUG - 2018-05-15 02:51:23 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-15 02:51:23 --> Helper loaded: url_helper
INFO - 2018-05-15 02:51:23 --> Helper loaded: form_helper
INFO - 2018-05-15 02:51:23 --> Helper loaded: date_helper
INFO - 2018-05-15 02:51:23 --> Helper loaded: util_helper
INFO - 2018-05-15 02:51:23 --> Helper loaded: text_helper
INFO - 2018-05-15 02:51:23 --> Helper loaded: string_helper
INFO - 2018-05-15 02:51:23 --> Database Driver Class Initialized
DEBUG - 2018-05-15 02:51:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-15 02:51:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-15 02:51:23 --> Email Class Initialized
INFO - 2018-05-15 02:51:23 --> Controller Class Initialized
DEBUG - 2018-05-15 02:51:23 --> Home MX_Controller Initialized
DEBUG - 2018-05-15 02:51:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-15 02:51:23 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-15 02:51:23 --> Login MX_Controller Initialized
INFO - 2018-05-15 02:51:23 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-15 02:51:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-15 02:51:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-15 02:51:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-05-15 02:51:24 --> Final output sent to browser
DEBUG - 2018-05-15 02:51:24 --> Total execution time: 0.4551
INFO - 2018-05-15 02:51:24 --> Config Class Initialized
INFO - 2018-05-15 02:51:24 --> Hooks Class Initialized
DEBUG - 2018-05-15 02:51:24 --> UTF-8 Support Enabled
INFO - 2018-05-15 02:51:24 --> Utf8 Class Initialized
INFO - 2018-05-15 02:51:24 --> URI Class Initialized
INFO - 2018-05-15 02:51:24 --> Router Class Initialized
INFO - 2018-05-15 02:51:24 --> Output Class Initialized
INFO - 2018-05-15 02:51:24 --> Security Class Initialized
DEBUG - 2018-05-15 02:51:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 02:51:24 --> Input Class Initialized
INFO - 2018-05-15 02:51:24 --> Language Class Initialized
ERROR - 2018-05-15 02:51:24 --> 404 Page Not Found: /index
INFO - 2018-05-15 02:51:24 --> Config Class Initialized
INFO - 2018-05-15 02:51:24 --> Hooks Class Initialized
DEBUG - 2018-05-15 02:51:24 --> UTF-8 Support Enabled
INFO - 2018-05-15 02:51:24 --> Utf8 Class Initialized
INFO - 2018-05-15 02:51:24 --> URI Class Initialized
INFO - 2018-05-15 02:51:24 --> Router Class Initialized
INFO - 2018-05-15 02:51:24 --> Output Class Initialized
INFO - 2018-05-15 02:51:24 --> Security Class Initialized
DEBUG - 2018-05-15 02:51:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 02:51:24 --> Input Class Initialized
INFO - 2018-05-15 02:51:24 --> Config Class Initialized
INFO - 2018-05-15 02:51:24 --> Hooks Class Initialized
INFO - 2018-05-15 02:51:24 --> Language Class Initialized
INFO - 2018-05-15 02:51:24 --> Config Class Initialized
INFO - 2018-05-15 02:51:24 --> Hooks Class Initialized
DEBUG - 2018-05-15 02:51:24 --> UTF-8 Support Enabled
INFO - 2018-05-15 02:51:24 --> Config Class Initialized
ERROR - 2018-05-15 02:51:24 --> 404 Page Not Found: /index
INFO - 2018-05-15 02:51:24 --> Config Class Initialized
INFO - 2018-05-15 02:51:24 --> Utf8 Class Initialized
INFO - 2018-05-15 02:51:24 --> Hooks Class Initialized
DEBUG - 2018-05-15 02:51:24 --> UTF-8 Support Enabled
INFO - 2018-05-15 02:51:24 --> Hooks Class Initialized
INFO - 2018-05-15 02:51:24 --> Config Class Initialized
INFO - 2018-05-15 02:51:24 --> Config Class Initialized
INFO - 2018-05-15 02:51:24 --> URI Class Initialized
INFO - 2018-05-15 02:51:24 --> Router Class Initialized
INFO - 2018-05-15 02:51:24 --> Hooks Class Initialized
INFO - 2018-05-15 02:51:24 --> Utf8 Class Initialized
INFO - 2018-05-15 02:51:24 --> Hooks Class Initialized
INFO - 2018-05-15 02:51:24 --> Output Class Initialized
DEBUG - 2018-05-15 02:51:24 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 02:51:24 --> UTF-8 Support Enabled
INFO - 2018-05-15 02:51:24 --> URI Class Initialized
INFO - 2018-05-15 02:51:24 --> Utf8 Class Initialized
DEBUG - 2018-05-15 02:51:24 --> UTF-8 Support Enabled
INFO - 2018-05-15 02:51:24 --> Utf8 Class Initialized
INFO - 2018-05-15 02:51:24 --> Security Class Initialized
DEBUG - 2018-05-15 02:51:24 --> UTF-8 Support Enabled
INFO - 2018-05-15 02:51:24 --> Utf8 Class Initialized
INFO - 2018-05-15 02:51:24 --> Router Class Initialized
INFO - 2018-05-15 02:51:24 --> URI Class Initialized
INFO - 2018-05-15 02:51:24 --> URI Class Initialized
INFO - 2018-05-15 02:51:24 --> Router Class Initialized
INFO - 2018-05-15 02:51:24 --> Output Class Initialized
INFO - 2018-05-15 02:51:24 --> Security Class Initialized
DEBUG - 2018-05-15 02:51:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 02:51:24 --> Output Class Initialized
INFO - 2018-05-15 02:51:24 --> Router Class Initialized
INFO - 2018-05-15 02:51:24 --> URI Class Initialized
DEBUG - 2018-05-15 02:51:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 02:51:24 --> Utf8 Class Initialized
INFO - 2018-05-15 02:51:24 --> Input Class Initialized
INFO - 2018-05-15 02:51:24 --> URI Class Initialized
INFO - 2018-05-15 02:51:24 --> Security Class Initialized
INFO - 2018-05-15 02:51:24 --> Input Class Initialized
INFO - 2018-05-15 02:51:24 --> Output Class Initialized
INFO - 2018-05-15 02:51:24 --> Router Class Initialized
DEBUG - 2018-05-15 02:51:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 02:51:24 --> Language Class Initialized
INFO - 2018-05-15 02:51:24 --> Language Class Initialized
INFO - 2018-05-15 02:51:24 --> Security Class Initialized
INFO - 2018-05-15 02:51:24 --> Router Class Initialized
INFO - 2018-05-15 02:51:24 --> Output Class Initialized
INFO - 2018-05-15 02:51:24 --> Input Class Initialized
INFO - 2018-05-15 02:51:24 --> Output Class Initialized
ERROR - 2018-05-15 02:51:24 --> 404 Page Not Found: /index
ERROR - 2018-05-15 02:51:24 --> 404 Page Not Found: /index
DEBUG - 2018-05-15 02:51:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 02:51:25 --> Security Class Initialized
DEBUG - 2018-05-15 02:51:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 02:51:25 --> Language Class Initialized
INFO - 2018-05-15 02:51:25 --> Input Class Initialized
INFO - 2018-05-15 02:51:25 --> Security Class Initialized
INFO - 2018-05-15 02:51:25 --> Config Class Initialized
INFO - 2018-05-15 02:51:25 --> Hooks Class Initialized
INFO - 2018-05-15 02:51:25 --> Input Class Initialized
INFO - 2018-05-15 02:51:25 --> Language Class Initialized
ERROR - 2018-05-15 02:51:25 --> 404 Page Not Found: /index
DEBUG - 2018-05-15 02:51:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 02:51:25 --> Language Class Initialized
DEBUG - 2018-05-15 02:51:25 --> UTF-8 Support Enabled
ERROR - 2018-05-15 02:51:25 --> 404 Page Not Found: /index
INFO - 2018-05-15 02:51:25 --> Input Class Initialized
INFO - 2018-05-15 02:51:25 --> Config Class Initialized
INFO - 2018-05-15 02:51:25 --> Hooks Class Initialized
ERROR - 2018-05-15 02:51:25 --> 404 Page Not Found: /index
INFO - 2018-05-15 02:51:25 --> Language Class Initialized
INFO - 2018-05-15 02:51:25 --> Config Class Initialized
INFO - 2018-05-15 02:51:25 --> Hooks Class Initialized
INFO - 2018-05-15 02:51:25 --> Utf8 Class Initialized
ERROR - 2018-05-15 02:51:25 --> 404 Page Not Found: /index
DEBUG - 2018-05-15 02:51:25 --> UTF-8 Support Enabled
INFO - 2018-05-15 02:51:25 --> Config Class Initialized
INFO - 2018-05-15 02:51:25 --> Hooks Class Initialized
INFO - 2018-05-15 02:51:25 --> URI Class Initialized
DEBUG - 2018-05-15 02:51:25 --> UTF-8 Support Enabled
INFO - 2018-05-15 02:51:25 --> Utf8 Class Initialized
INFO - 2018-05-15 02:51:25 --> Utf8 Class Initialized
INFO - 2018-05-15 02:51:25 --> Config Class Initialized
DEBUG - 2018-05-15 02:51:25 --> UTF-8 Support Enabled
INFO - 2018-05-15 02:51:25 --> URI Class Initialized
INFO - 2018-05-15 02:51:25 --> Hooks Class Initialized
INFO - 2018-05-15 02:51:25 --> URI Class Initialized
INFO - 2018-05-15 02:51:25 --> Utf8 Class Initialized
INFO - 2018-05-15 02:51:25 --> Router Class Initialized
INFO - 2018-05-15 02:51:25 --> Router Class Initialized
DEBUG - 2018-05-15 02:51:25 --> UTF-8 Support Enabled
INFO - 2018-05-15 02:51:25 --> Router Class Initialized
INFO - 2018-05-15 02:51:25 --> URI Class Initialized
INFO - 2018-05-15 02:51:25 --> Output Class Initialized
INFO - 2018-05-15 02:51:25 --> Utf8 Class Initialized
INFO - 2018-05-15 02:51:25 --> Output Class Initialized
INFO - 2018-05-15 02:51:25 --> Security Class Initialized
INFO - 2018-05-15 02:51:25 --> Router Class Initialized
INFO - 2018-05-15 02:51:25 --> Output Class Initialized
INFO - 2018-05-15 02:51:25 --> Security Class Initialized
DEBUG - 2018-05-15 02:51:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 02:51:25 --> URI Class Initialized
INFO - 2018-05-15 02:51:25 --> Output Class Initialized
INFO - 2018-05-15 02:51:25 --> Security Class Initialized
INFO - 2018-05-15 02:51:25 --> Input Class Initialized
INFO - 2018-05-15 02:51:25 --> Security Class Initialized
DEBUG - 2018-05-15 02:51:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-15 02:51:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 02:51:25 --> Router Class Initialized
INFO - 2018-05-15 02:51:25 --> Input Class Initialized
INFO - 2018-05-15 02:51:25 --> Output Class Initialized
INFO - 2018-05-15 02:51:25 --> Input Class Initialized
INFO - 2018-05-15 02:51:25 --> Language Class Initialized
DEBUG - 2018-05-15 02:51:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 02:51:25 --> Input Class Initialized
INFO - 2018-05-15 02:51:25 --> Language Class Initialized
INFO - 2018-05-15 02:51:25 --> Language Class Initialized
ERROR - 2018-05-15 02:51:25 --> 404 Page Not Found: /index
INFO - 2018-05-15 02:51:25 --> Security Class Initialized
INFO - 2018-05-15 02:51:25 --> Config Class Initialized
DEBUG - 2018-05-15 02:51:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-05-15 02:51:25 --> 404 Page Not Found: /index
ERROR - 2018-05-15 02:51:25 --> 404 Page Not Found: /index
INFO - 2018-05-15 02:51:25 --> Language Class Initialized
INFO - 2018-05-15 02:51:25 --> Hooks Class Initialized
INFO - 2018-05-15 02:51:25 --> Input Class Initialized
ERROR - 2018-05-15 02:51:25 --> 404 Page Not Found: /index
DEBUG - 2018-05-15 02:51:25 --> UTF-8 Support Enabled
INFO - 2018-05-15 02:51:25 --> Config Class Initialized
INFO - 2018-05-15 02:51:25 --> Language Class Initialized
INFO - 2018-05-15 02:51:25 --> Config Class Initialized
INFO - 2018-05-15 02:51:25 --> Config Class Initialized
INFO - 2018-05-15 02:51:25 --> Hooks Class Initialized
INFO - 2018-05-15 02:51:25 --> Hooks Class Initialized
INFO - 2018-05-15 02:51:25 --> Utf8 Class Initialized
INFO - 2018-05-15 02:51:25 --> Hooks Class Initialized
ERROR - 2018-05-15 02:51:25 --> 404 Page Not Found: /index
DEBUG - 2018-05-15 02:51:25 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 02:51:25 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 02:51:25 --> UTF-8 Support Enabled
INFO - 2018-05-15 02:51:25 --> URI Class Initialized
INFO - 2018-05-15 02:51:25 --> Config Class Initialized
INFO - 2018-05-15 02:51:25 --> Hooks Class Initialized
INFO - 2018-05-15 02:51:25 --> Utf8 Class Initialized
INFO - 2018-05-15 02:51:25 --> Utf8 Class Initialized
INFO - 2018-05-15 02:51:25 --> Router Class Initialized
INFO - 2018-05-15 02:51:25 --> Utf8 Class Initialized
DEBUG - 2018-05-15 02:51:25 --> UTF-8 Support Enabled
INFO - 2018-05-15 02:51:25 --> URI Class Initialized
INFO - 2018-05-15 02:51:25 --> URI Class Initialized
INFO - 2018-05-15 02:51:25 --> Output Class Initialized
INFO - 2018-05-15 02:51:25 --> URI Class Initialized
INFO - 2018-05-15 02:51:25 --> Utf8 Class Initialized
INFO - 2018-05-15 02:51:25 --> Router Class Initialized
INFO - 2018-05-15 02:51:25 --> Router Class Initialized
INFO - 2018-05-15 02:51:25 --> Security Class Initialized
INFO - 2018-05-15 02:51:25 --> Router Class Initialized
INFO - 2018-05-15 02:51:25 --> URI Class Initialized
INFO - 2018-05-15 02:51:25 --> Output Class Initialized
INFO - 2018-05-15 02:51:25 --> Output Class Initialized
INFO - 2018-05-15 02:51:25 --> Output Class Initialized
DEBUG - 2018-05-15 02:51:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 02:51:25 --> Security Class Initialized
INFO - 2018-05-15 02:51:25 --> Router Class Initialized
INFO - 2018-05-15 02:51:25 --> Security Class Initialized
INFO - 2018-05-15 02:51:25 --> Input Class Initialized
INFO - 2018-05-15 02:51:25 --> Security Class Initialized
INFO - 2018-05-15 02:51:25 --> Output Class Initialized
DEBUG - 2018-05-15 02:51:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-15 02:51:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 02:51:25 --> Language Class Initialized
DEBUG - 2018-05-15 02:51:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 02:51:25 --> Security Class Initialized
INFO - 2018-05-15 02:51:25 --> Input Class Initialized
INFO - 2018-05-15 02:51:25 --> Input Class Initialized
ERROR - 2018-05-15 02:51:25 --> 404 Page Not Found: /index
INFO - 2018-05-15 02:51:25 --> Input Class Initialized
INFO - 2018-05-15 02:51:25 --> Language Class Initialized
DEBUG - 2018-05-15 02:51:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 02:51:25 --> Language Class Initialized
INFO - 2018-05-15 02:51:25 --> Language Class Initialized
INFO - 2018-05-15 02:51:25 --> Input Class Initialized
ERROR - 2018-05-15 02:51:25 --> 404 Page Not Found: /index
ERROR - 2018-05-15 02:51:25 --> 404 Page Not Found: /index
ERROR - 2018-05-15 02:51:25 --> 404 Page Not Found: /index
INFO - 2018-05-15 02:51:25 --> Language Class Initialized
ERROR - 2018-05-15 02:51:25 --> 404 Page Not Found: /index
INFO - 2018-05-15 02:51:28 --> Config Class Initialized
INFO - 2018-05-15 02:51:28 --> Hooks Class Initialized
DEBUG - 2018-05-15 02:51:28 --> UTF-8 Support Enabled
INFO - 2018-05-15 02:51:28 --> Utf8 Class Initialized
INFO - 2018-05-15 02:51:28 --> URI Class Initialized
INFO - 2018-05-15 02:51:28 --> Router Class Initialized
INFO - 2018-05-15 02:51:28 --> Output Class Initialized
INFO - 2018-05-15 02:51:28 --> Security Class Initialized
DEBUG - 2018-05-15 02:51:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 02:51:28 --> Input Class Initialized
INFO - 2018-05-15 02:51:28 --> Language Class Initialized
ERROR - 2018-05-15 02:51:28 --> 404 Page Not Found: /index
INFO - 2018-05-15 02:51:29 --> Config Class Initialized
INFO - 2018-05-15 02:51:29 --> Hooks Class Initialized
DEBUG - 2018-05-15 02:51:29 --> UTF-8 Support Enabled
INFO - 2018-05-15 02:51:29 --> Utf8 Class Initialized
INFO - 2018-05-15 02:51:29 --> URI Class Initialized
INFO - 2018-05-15 02:51:29 --> Router Class Initialized
INFO - 2018-05-15 02:51:29 --> Output Class Initialized
INFO - 2018-05-15 02:51:29 --> Security Class Initialized
DEBUG - 2018-05-15 02:51:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 02:51:29 --> Input Class Initialized
INFO - 2018-05-15 02:51:29 --> Language Class Initialized
ERROR - 2018-05-15 02:51:29 --> 404 Page Not Found: /index
INFO - 2018-05-15 02:51:29 --> Config Class Initialized
INFO - 2018-05-15 02:51:29 --> Hooks Class Initialized
DEBUG - 2018-05-15 02:51:29 --> UTF-8 Support Enabled
INFO - 2018-05-15 02:51:29 --> Utf8 Class Initialized
INFO - 2018-05-15 02:51:29 --> URI Class Initialized
INFO - 2018-05-15 02:51:29 --> Router Class Initialized
INFO - 2018-05-15 02:51:29 --> Output Class Initialized
INFO - 2018-05-15 02:51:29 --> Security Class Initialized
DEBUG - 2018-05-15 02:51:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 02:51:29 --> Input Class Initialized
INFO - 2018-05-15 02:51:29 --> Language Class Initialized
ERROR - 2018-05-15 02:51:29 --> 404 Page Not Found: /index
INFO - 2018-05-15 02:52:38 --> Config Class Initialized
INFO - 2018-05-15 02:52:38 --> Hooks Class Initialized
DEBUG - 2018-05-15 02:52:38 --> UTF-8 Support Enabled
INFO - 2018-05-15 02:52:38 --> Utf8 Class Initialized
INFO - 2018-05-15 02:52:38 --> URI Class Initialized
INFO - 2018-05-15 02:52:38 --> Router Class Initialized
INFO - 2018-05-15 02:52:38 --> Output Class Initialized
INFO - 2018-05-15 02:52:38 --> Security Class Initialized
DEBUG - 2018-05-15 02:52:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 02:52:38 --> Input Class Initialized
INFO - 2018-05-15 02:52:38 --> Language Class Initialized
INFO - 2018-05-15 02:52:38 --> Language Class Initialized
INFO - 2018-05-15 02:52:38 --> Config Class Initialized
INFO - 2018-05-15 02:52:38 --> Loader Class Initialized
DEBUG - 2018-05-15 02:52:38 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-15 02:52:38 --> Helper loaded: url_helper
INFO - 2018-05-15 02:52:38 --> Helper loaded: form_helper
INFO - 2018-05-15 02:52:38 --> Helper loaded: date_helper
INFO - 2018-05-15 02:52:38 --> Helper loaded: util_helper
INFO - 2018-05-15 02:52:38 --> Helper loaded: text_helper
INFO - 2018-05-15 02:52:38 --> Helper loaded: string_helper
INFO - 2018-05-15 02:52:38 --> Database Driver Class Initialized
DEBUG - 2018-05-15 02:52:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-15 02:52:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-15 02:52:38 --> Email Class Initialized
INFO - 2018-05-15 02:52:38 --> Controller Class Initialized
DEBUG - 2018-05-15 02:52:38 --> Home MX_Controller Initialized
DEBUG - 2018-05-15 02:52:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-15 02:52:38 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-15 02:52:38 --> Login MX_Controller Initialized
INFO - 2018-05-15 02:52:38 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-15 02:52:39 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-15 02:52:39 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-15 02:52:39 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-05-15 02:52:39 --> Final output sent to browser
DEBUG - 2018-05-15 02:52:39 --> Total execution time: 0.3988
INFO - 2018-05-15 02:52:39 --> Config Class Initialized
INFO - 2018-05-15 02:52:39 --> Hooks Class Initialized
DEBUG - 2018-05-15 02:52:39 --> UTF-8 Support Enabled
INFO - 2018-05-15 02:52:39 --> Utf8 Class Initialized
INFO - 2018-05-15 02:52:39 --> URI Class Initialized
INFO - 2018-05-15 02:52:39 --> Router Class Initialized
INFO - 2018-05-15 02:52:39 --> Output Class Initialized
INFO - 2018-05-15 02:52:39 --> Security Class Initialized
DEBUG - 2018-05-15 02:52:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 02:52:39 --> Input Class Initialized
INFO - 2018-05-15 02:52:39 --> Language Class Initialized
ERROR - 2018-05-15 02:52:39 --> 404 Page Not Found: /index
INFO - 2018-05-15 02:52:39 --> Config Class Initialized
INFO - 2018-05-15 02:52:39 --> Config Class Initialized
INFO - 2018-05-15 02:52:39 --> Config Class Initialized
INFO - 2018-05-15 02:52:39 --> Config Class Initialized
INFO - 2018-05-15 02:52:39 --> Hooks Class Initialized
INFO - 2018-05-15 02:52:39 --> Hooks Class Initialized
INFO - 2018-05-15 02:52:39 --> Hooks Class Initialized
INFO - 2018-05-15 02:52:39 --> Config Class Initialized
INFO - 2018-05-15 02:52:39 --> Hooks Class Initialized
INFO - 2018-05-15 02:52:39 --> Config Class Initialized
DEBUG - 2018-05-15 02:52:39 --> UTF-8 Support Enabled
INFO - 2018-05-15 02:52:39 --> Hooks Class Initialized
DEBUG - 2018-05-15 02:52:39 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 02:52:39 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 02:52:39 --> UTF-8 Support Enabled
INFO - 2018-05-15 02:52:39 --> Utf8 Class Initialized
INFO - 2018-05-15 02:52:39 --> Hooks Class Initialized
INFO - 2018-05-15 02:52:39 --> URI Class Initialized
INFO - 2018-05-15 02:52:39 --> Utf8 Class Initialized
DEBUG - 2018-05-15 02:52:39 --> UTF-8 Support Enabled
INFO - 2018-05-15 02:52:39 --> Utf8 Class Initialized
INFO - 2018-05-15 02:52:39 --> Utf8 Class Initialized
DEBUG - 2018-05-15 02:52:39 --> UTF-8 Support Enabled
INFO - 2018-05-15 02:52:39 --> URI Class Initialized
INFO - 2018-05-15 02:52:39 --> Utf8 Class Initialized
INFO - 2018-05-15 02:52:39 --> Router Class Initialized
INFO - 2018-05-15 02:52:39 --> URI Class Initialized
INFO - 2018-05-15 02:52:39 --> URI Class Initialized
INFO - 2018-05-15 02:52:39 --> Router Class Initialized
INFO - 2018-05-15 02:52:39 --> Utf8 Class Initialized
INFO - 2018-05-15 02:52:39 --> Router Class Initialized
INFO - 2018-05-15 02:52:39 --> Router Class Initialized
INFO - 2018-05-15 02:52:39 --> Output Class Initialized
INFO - 2018-05-15 02:52:39 --> URI Class Initialized
INFO - 2018-05-15 02:52:39 --> Output Class Initialized
INFO - 2018-05-15 02:52:39 --> Output Class Initialized
INFO - 2018-05-15 02:52:39 --> URI Class Initialized
INFO - 2018-05-15 02:52:39 --> Security Class Initialized
DEBUG - 2018-05-15 02:52:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 02:52:39 --> Security Class Initialized
INFO - 2018-05-15 02:52:39 --> Router Class Initialized
INFO - 2018-05-15 02:52:39 --> Security Class Initialized
INFO - 2018-05-15 02:52:39 --> Output Class Initialized
INFO - 2018-05-15 02:52:39 --> Input Class Initialized
INFO - 2018-05-15 02:52:39 --> Router Class Initialized
DEBUG - 2018-05-15 02:52:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-15 02:52:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 02:52:39 --> Output Class Initialized
INFO - 2018-05-15 02:52:39 --> Language Class Initialized
INFO - 2018-05-15 02:52:39 --> Security Class Initialized
INFO - 2018-05-15 02:52:39 --> Output Class Initialized
INFO - 2018-05-15 02:52:39 --> Input Class Initialized
INFO - 2018-05-15 02:52:39 --> Security Class Initialized
ERROR - 2018-05-15 02:52:39 --> 404 Page Not Found: /index
INFO - 2018-05-15 02:52:39 --> Security Class Initialized
DEBUG - 2018-05-15 02:52:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 02:52:39 --> Input Class Initialized
INFO - 2018-05-15 02:52:39 --> Language Class Initialized
DEBUG - 2018-05-15 02:52:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-15 02:52:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 02:52:39 --> Input Class Initialized
INFO - 2018-05-15 02:52:39 --> Language Class Initialized
INFO - 2018-05-15 02:52:39 --> Config Class Initialized
INFO - 2018-05-15 02:52:39 --> Hooks Class Initialized
INFO - 2018-05-15 02:52:39 --> Input Class Initialized
INFO - 2018-05-15 02:52:39 --> Input Class Initialized
INFO - 2018-05-15 02:52:39 --> Language Class Initialized
ERROR - 2018-05-15 02:52:39 --> 404 Page Not Found: /index
ERROR - 2018-05-15 02:52:39 --> 404 Page Not Found: /index
DEBUG - 2018-05-15 02:52:39 --> UTF-8 Support Enabled
INFO - 2018-05-15 02:52:39 --> Language Class Initialized
ERROR - 2018-05-15 02:52:39 --> 404 Page Not Found: /index
INFO - 2018-05-15 02:52:39 --> Language Class Initialized
INFO - 2018-05-15 02:52:39 --> Config Class Initialized
INFO - 2018-05-15 02:52:39 --> Utf8 Class Initialized
INFO - 2018-05-15 02:52:39 --> Hooks Class Initialized
ERROR - 2018-05-15 02:52:39 --> 404 Page Not Found: /index
ERROR - 2018-05-15 02:52:39 --> 404 Page Not Found: /index
INFO - 2018-05-15 02:52:39 --> Config Class Initialized
INFO - 2018-05-15 02:52:39 --> Hooks Class Initialized
INFO - 2018-05-15 02:52:39 --> URI Class Initialized
DEBUG - 2018-05-15 02:52:39 --> UTF-8 Support Enabled
INFO - 2018-05-15 02:52:39 --> Config Class Initialized
DEBUG - 2018-05-15 02:52:39 --> UTF-8 Support Enabled
INFO - 2018-05-15 02:52:39 --> Config Class Initialized
INFO - 2018-05-15 02:52:39 --> Utf8 Class Initialized
INFO - 2018-05-15 02:52:39 --> Router Class Initialized
INFO - 2018-05-15 02:52:39 --> Hooks Class Initialized
INFO - 2018-05-15 02:52:39 --> Hooks Class Initialized
INFO - 2018-05-15 02:52:39 --> Utf8 Class Initialized
INFO - 2018-05-15 02:52:39 --> Output Class Initialized
INFO - 2018-05-15 02:52:39 --> URI Class Initialized
INFO - 2018-05-15 02:52:39 --> URI Class Initialized
INFO - 2018-05-15 02:52:39 --> Security Class Initialized
DEBUG - 2018-05-15 02:52:39 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 02:52:39 --> UTF-8 Support Enabled
INFO - 2018-05-15 02:52:39 --> Router Class Initialized
INFO - 2018-05-15 02:52:39 --> Utf8 Class Initialized
INFO - 2018-05-15 02:52:39 --> Utf8 Class Initialized
INFO - 2018-05-15 02:52:39 --> Router Class Initialized
DEBUG - 2018-05-15 02:52:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 02:52:39 --> Output Class Initialized
INFO - 2018-05-15 02:52:39 --> Input Class Initialized
INFO - 2018-05-15 02:52:39 --> Security Class Initialized
INFO - 2018-05-15 02:52:39 --> URI Class Initialized
INFO - 2018-05-15 02:52:39 --> Output Class Initialized
INFO - 2018-05-15 02:52:39 --> URI Class Initialized
INFO - 2018-05-15 02:52:39 --> Language Class Initialized
INFO - 2018-05-15 02:52:39 --> Router Class Initialized
INFO - 2018-05-15 02:52:39 --> Output Class Initialized
ERROR - 2018-05-15 02:52:39 --> 404 Page Not Found: /index
DEBUG - 2018-05-15 02:52:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 02:52:39 --> Router Class Initialized
INFO - 2018-05-15 02:52:39 --> Security Class Initialized
INFO - 2018-05-15 02:52:39 --> Security Class Initialized
DEBUG - 2018-05-15 02:52:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 02:52:40 --> Input Class Initialized
INFO - 2018-05-15 02:52:40 --> Output Class Initialized
DEBUG - 2018-05-15 02:52:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 02:52:40 --> Input Class Initialized
INFO - 2018-05-15 02:52:40 --> Security Class Initialized
INFO - 2018-05-15 02:52:40 --> Input Class Initialized
INFO - 2018-05-15 02:52:40 --> Language Class Initialized
INFO - 2018-05-15 02:52:40 --> Language Class Initialized
DEBUG - 2018-05-15 02:52:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 02:52:40 --> Input Class Initialized
INFO - 2018-05-15 02:52:40 --> Config Class Initialized
ERROR - 2018-05-15 02:52:40 --> 404 Page Not Found: /index
ERROR - 2018-05-15 02:52:40 --> 404 Page Not Found: /index
INFO - 2018-05-15 02:52:40 --> Language Class Initialized
INFO - 2018-05-15 02:52:40 --> Hooks Class Initialized
INFO - 2018-05-15 02:52:40 --> Language Class Initialized
ERROR - 2018-05-15 02:52:40 --> 404 Page Not Found: /index
INFO - 2018-05-15 02:52:40 --> Config Class Initialized
INFO - 2018-05-15 02:52:40 --> Config Class Initialized
INFO - 2018-05-15 02:52:40 --> Hooks Class Initialized
INFO - 2018-05-15 02:52:40 --> Hooks Class Initialized
DEBUG - 2018-05-15 02:52:40 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 02:52:40 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 02:52:40 --> UTF-8 Support Enabled
INFO - 2018-05-15 02:52:40 --> Config Class Initialized
INFO - 2018-05-15 02:52:40 --> Utf8 Class Initialized
ERROR - 2018-05-15 02:52:40 --> 404 Page Not Found: /index
INFO - 2018-05-15 02:52:40 --> Hooks Class Initialized
INFO - 2018-05-15 02:52:40 --> Utf8 Class Initialized
INFO - 2018-05-15 02:52:40 --> Utf8 Class Initialized
INFO - 2018-05-15 02:52:40 --> URI Class Initialized
DEBUG - 2018-05-15 02:52:40 --> UTF-8 Support Enabled
INFO - 2018-05-15 02:52:40 --> Config Class Initialized
INFO - 2018-05-15 02:52:40 --> Utf8 Class Initialized
INFO - 2018-05-15 02:52:40 --> Hooks Class Initialized
INFO - 2018-05-15 02:52:40 --> URI Class Initialized
INFO - 2018-05-15 02:52:40 --> Router Class Initialized
INFO - 2018-05-15 02:52:40 --> URI Class Initialized
INFO - 2018-05-15 02:52:40 --> URI Class Initialized
INFO - 2018-05-15 02:52:40 --> Output Class Initialized
INFO - 2018-05-15 02:52:40 --> Router Class Initialized
INFO - 2018-05-15 02:52:40 --> Router Class Initialized
INFO - 2018-05-15 02:52:40 --> Security Class Initialized
DEBUG - 2018-05-15 02:52:40 --> UTF-8 Support Enabled
INFO - 2018-05-15 02:52:40 --> Router Class Initialized
INFO - 2018-05-15 02:52:40 --> Output Class Initialized
INFO - 2018-05-15 02:52:40 --> Output Class Initialized
INFO - 2018-05-15 02:52:40 --> Security Class Initialized
DEBUG - 2018-05-15 02:52:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 02:52:40 --> Output Class Initialized
INFO - 2018-05-15 02:52:40 --> Security Class Initialized
INFO - 2018-05-15 02:52:40 --> Security Class Initialized
DEBUG - 2018-05-15 02:52:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-15 02:52:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 02:52:40 --> Utf8 Class Initialized
INFO - 2018-05-15 02:52:40 --> Input Class Initialized
INFO - 2018-05-15 02:52:40 --> Input Class Initialized
INFO - 2018-05-15 02:52:40 --> URI Class Initialized
INFO - 2018-05-15 02:52:40 --> Input Class Initialized
DEBUG - 2018-05-15 02:52:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 02:52:40 --> Language Class Initialized
INFO - 2018-05-15 02:52:40 --> Input Class Initialized
INFO - 2018-05-15 02:52:40 --> Language Class Initialized
INFO - 2018-05-15 02:52:40 --> Language Class Initialized
INFO - 2018-05-15 02:52:40 --> Router Class Initialized
ERROR - 2018-05-15 02:52:40 --> 404 Page Not Found: /index
INFO - 2018-05-15 02:52:40 --> Output Class Initialized
ERROR - 2018-05-15 02:52:40 --> 404 Page Not Found: /index
INFO - 2018-05-15 02:52:40 --> Language Class Initialized
ERROR - 2018-05-15 02:52:40 --> 404 Page Not Found: /index
ERROR - 2018-05-15 02:52:40 --> 404 Page Not Found: /index
INFO - 2018-05-15 02:52:40 --> Security Class Initialized
DEBUG - 2018-05-15 02:52:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 02:52:40 --> Input Class Initialized
INFO - 2018-05-15 02:52:40 --> Language Class Initialized
ERROR - 2018-05-15 02:52:40 --> 404 Page Not Found: /index
INFO - 2018-05-15 02:52:43 --> Config Class Initialized
INFO - 2018-05-15 02:52:43 --> Hooks Class Initialized
DEBUG - 2018-05-15 02:52:43 --> UTF-8 Support Enabled
INFO - 2018-05-15 02:52:43 --> Utf8 Class Initialized
INFO - 2018-05-15 02:52:43 --> URI Class Initialized
INFO - 2018-05-15 02:52:43 --> Router Class Initialized
INFO - 2018-05-15 02:52:43 --> Output Class Initialized
INFO - 2018-05-15 02:52:43 --> Security Class Initialized
DEBUG - 2018-05-15 02:52:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 02:52:43 --> Input Class Initialized
INFO - 2018-05-15 02:52:43 --> Language Class Initialized
ERROR - 2018-05-15 02:52:43 --> 404 Page Not Found: /index
INFO - 2018-05-15 02:52:43 --> Config Class Initialized
INFO - 2018-05-15 02:52:43 --> Hooks Class Initialized
DEBUG - 2018-05-15 02:52:43 --> UTF-8 Support Enabled
INFO - 2018-05-15 02:52:44 --> Utf8 Class Initialized
INFO - 2018-05-15 02:52:44 --> URI Class Initialized
INFO - 2018-05-15 02:52:44 --> Router Class Initialized
INFO - 2018-05-15 02:52:44 --> Output Class Initialized
INFO - 2018-05-15 02:52:44 --> Security Class Initialized
DEBUG - 2018-05-15 02:52:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 02:52:44 --> Input Class Initialized
INFO - 2018-05-15 02:52:44 --> Language Class Initialized
ERROR - 2018-05-15 02:52:44 --> 404 Page Not Found: /index
INFO - 2018-05-15 02:52:44 --> Config Class Initialized
INFO - 2018-05-15 02:52:44 --> Hooks Class Initialized
DEBUG - 2018-05-15 02:52:44 --> UTF-8 Support Enabled
INFO - 2018-05-15 02:52:44 --> Utf8 Class Initialized
INFO - 2018-05-15 02:52:44 --> URI Class Initialized
INFO - 2018-05-15 02:52:44 --> Router Class Initialized
INFO - 2018-05-15 02:52:44 --> Output Class Initialized
INFO - 2018-05-15 02:52:44 --> Security Class Initialized
DEBUG - 2018-05-15 02:52:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 02:52:44 --> Input Class Initialized
INFO - 2018-05-15 02:52:44 --> Language Class Initialized
ERROR - 2018-05-15 02:52:44 --> 404 Page Not Found: /index
INFO - 2018-05-15 02:52:49 --> Config Class Initialized
INFO - 2018-05-15 02:52:49 --> Hooks Class Initialized
DEBUG - 2018-05-15 02:52:49 --> UTF-8 Support Enabled
INFO - 2018-05-15 02:52:49 --> Utf8 Class Initialized
INFO - 2018-05-15 02:52:49 --> URI Class Initialized
INFO - 2018-05-15 02:52:49 --> Router Class Initialized
INFO - 2018-05-15 02:52:49 --> Output Class Initialized
INFO - 2018-05-15 02:52:49 --> Security Class Initialized
DEBUG - 2018-05-15 02:52:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 02:52:49 --> Input Class Initialized
INFO - 2018-05-15 02:52:49 --> Language Class Initialized
ERROR - 2018-05-15 02:52:49 --> 404 Page Not Found: /index
INFO - 2018-05-15 02:53:07 --> Config Class Initialized
INFO - 2018-05-15 02:53:07 --> Hooks Class Initialized
DEBUG - 2018-05-15 02:53:07 --> UTF-8 Support Enabled
INFO - 2018-05-15 02:53:07 --> Utf8 Class Initialized
INFO - 2018-05-15 02:53:07 --> URI Class Initialized
INFO - 2018-05-15 02:53:07 --> Router Class Initialized
INFO - 2018-05-15 02:53:07 --> Output Class Initialized
INFO - 2018-05-15 02:53:07 --> Security Class Initialized
DEBUG - 2018-05-15 02:53:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 02:53:07 --> Input Class Initialized
INFO - 2018-05-15 02:53:07 --> Language Class Initialized
INFO - 2018-05-15 02:53:07 --> Language Class Initialized
INFO - 2018-05-15 02:53:07 --> Config Class Initialized
INFO - 2018-05-15 02:53:07 --> Loader Class Initialized
DEBUG - 2018-05-15 02:53:07 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-15 02:53:07 --> Helper loaded: url_helper
INFO - 2018-05-15 02:53:07 --> Helper loaded: form_helper
INFO - 2018-05-15 02:53:07 --> Helper loaded: date_helper
INFO - 2018-05-15 02:53:07 --> Helper loaded: util_helper
INFO - 2018-05-15 02:53:07 --> Helper loaded: text_helper
INFO - 2018-05-15 02:53:07 --> Helper loaded: string_helper
INFO - 2018-05-15 02:53:07 --> Database Driver Class Initialized
DEBUG - 2018-05-15 02:53:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-15 02:53:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-15 02:53:07 --> Email Class Initialized
INFO - 2018-05-15 02:53:07 --> Controller Class Initialized
DEBUG - 2018-05-15 02:53:07 --> Home MX_Controller Initialized
DEBUG - 2018-05-15 02:53:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-15 02:53:07 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-15 02:53:07 --> Login MX_Controller Initialized
INFO - 2018-05-15 02:53:07 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-15 02:53:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-15 02:53:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-15 02:53:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-05-15 02:53:07 --> Final output sent to browser
DEBUG - 2018-05-15 02:53:07 --> Total execution time: 0.4509
INFO - 2018-05-15 02:53:07 --> Config Class Initialized
INFO - 2018-05-15 02:53:07 --> Hooks Class Initialized
DEBUG - 2018-05-15 02:53:07 --> UTF-8 Support Enabled
INFO - 2018-05-15 02:53:07 --> Utf8 Class Initialized
INFO - 2018-05-15 02:53:07 --> URI Class Initialized
INFO - 2018-05-15 02:53:07 --> Router Class Initialized
INFO - 2018-05-15 02:53:07 --> Output Class Initialized
INFO - 2018-05-15 02:53:07 --> Security Class Initialized
DEBUG - 2018-05-15 02:53:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 02:53:07 --> Input Class Initialized
INFO - 2018-05-15 02:53:07 --> Language Class Initialized
ERROR - 2018-05-15 02:53:07 --> 404 Page Not Found: /index
INFO - 2018-05-15 02:53:07 --> Config Class Initialized
INFO - 2018-05-15 02:53:07 --> Config Class Initialized
INFO - 2018-05-15 02:53:08 --> Config Class Initialized
INFO - 2018-05-15 02:53:08 --> Hooks Class Initialized
INFO - 2018-05-15 02:53:08 --> Hooks Class Initialized
INFO - 2018-05-15 02:53:08 --> Hooks Class Initialized
INFO - 2018-05-15 02:53:08 --> Config Class Initialized
INFO - 2018-05-15 02:53:08 --> Config Class Initialized
INFO - 2018-05-15 02:53:08 --> Config Class Initialized
INFO - 2018-05-15 02:53:08 --> Hooks Class Initialized
INFO - 2018-05-15 02:53:08 --> Hooks Class Initialized
DEBUG - 2018-05-15 02:53:08 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 02:53:08 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 02:53:08 --> UTF-8 Support Enabled
INFO - 2018-05-15 02:53:08 --> Hooks Class Initialized
INFO - 2018-05-15 02:53:08 --> Utf8 Class Initialized
INFO - 2018-05-15 02:53:08 --> Utf8 Class Initialized
INFO - 2018-05-15 02:53:08 --> Utf8 Class Initialized
DEBUG - 2018-05-15 02:53:08 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 02:53:08 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 02:53:08 --> UTF-8 Support Enabled
INFO - 2018-05-15 02:53:08 --> Utf8 Class Initialized
INFO - 2018-05-15 02:53:08 --> URI Class Initialized
INFO - 2018-05-15 02:53:08 --> URI Class Initialized
INFO - 2018-05-15 02:53:08 --> Utf8 Class Initialized
INFO - 2018-05-15 02:53:08 --> URI Class Initialized
INFO - 2018-05-15 02:53:08 --> Utf8 Class Initialized
INFO - 2018-05-15 02:53:08 --> Router Class Initialized
INFO - 2018-05-15 02:53:08 --> Router Class Initialized
INFO - 2018-05-15 02:53:08 --> URI Class Initialized
INFO - 2018-05-15 02:53:08 --> Router Class Initialized
INFO - 2018-05-15 02:53:08 --> URI Class Initialized
INFO - 2018-05-15 02:53:08 --> URI Class Initialized
INFO - 2018-05-15 02:53:08 --> Output Class Initialized
INFO - 2018-05-15 02:53:08 --> Output Class Initialized
INFO - 2018-05-15 02:53:08 --> Router Class Initialized
INFO - 2018-05-15 02:53:08 --> Router Class Initialized
INFO - 2018-05-15 02:53:08 --> Output Class Initialized
INFO - 2018-05-15 02:53:08 --> Router Class Initialized
INFO - 2018-05-15 02:53:08 --> Security Class Initialized
INFO - 2018-05-15 02:53:08 --> Security Class Initialized
INFO - 2018-05-15 02:53:08 --> Output Class Initialized
INFO - 2018-05-15 02:53:08 --> Output Class Initialized
INFO - 2018-05-15 02:53:08 --> Output Class Initialized
INFO - 2018-05-15 02:53:08 --> Security Class Initialized
DEBUG - 2018-05-15 02:53:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 02:53:08 --> Security Class Initialized
INFO - 2018-05-15 02:53:08 --> Security Class Initialized
INFO - 2018-05-15 02:53:08 --> Security Class Initialized
DEBUG - 2018-05-15 02:53:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 02:53:08 --> Input Class Initialized
DEBUG - 2018-05-15 02:53:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-15 02:53:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-15 02:53:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-15 02:53:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 02:53:08 --> Input Class Initialized
INFO - 2018-05-15 02:53:08 --> Input Class Initialized
INFO - 2018-05-15 02:53:08 --> Language Class Initialized
INFO - 2018-05-15 02:53:08 --> Input Class Initialized
INFO - 2018-05-15 02:53:08 --> Input Class Initialized
INFO - 2018-05-15 02:53:08 --> Input Class Initialized
INFO - 2018-05-15 02:53:08 --> Language Class Initialized
INFO - 2018-05-15 02:53:08 --> Language Class Initialized
ERROR - 2018-05-15 02:53:08 --> 404 Page Not Found: /index
INFO - 2018-05-15 02:53:08 --> Language Class Initialized
ERROR - 2018-05-15 02:53:08 --> 404 Page Not Found: /index
ERROR - 2018-05-15 02:53:08 --> 404 Page Not Found: /index
INFO - 2018-05-15 02:53:08 --> Config Class Initialized
INFO - 2018-05-15 02:53:08 --> Language Class Initialized
ERROR - 2018-05-15 02:53:08 --> 404 Page Not Found: /index
INFO - 2018-05-15 02:53:08 --> Language Class Initialized
INFO - 2018-05-15 02:53:08 --> Config Class Initialized
INFO - 2018-05-15 02:53:08 --> Hooks Class Initialized
INFO - 2018-05-15 02:53:08 --> Hooks Class Initialized
ERROR - 2018-05-15 02:53:08 --> 404 Page Not Found: /index
ERROR - 2018-05-15 02:53:08 --> 404 Page Not Found: /index
INFO - 2018-05-15 02:53:08 --> Config Class Initialized
DEBUG - 2018-05-15 02:53:08 --> UTF-8 Support Enabled
INFO - 2018-05-15 02:53:08 --> Hooks Class Initialized
DEBUG - 2018-05-15 02:53:08 --> UTF-8 Support Enabled
INFO - 2018-05-15 02:53:08 --> Config Class Initialized
INFO - 2018-05-15 02:53:08 --> Config Class Initialized
INFO - 2018-05-15 02:53:08 --> Hooks Class Initialized
INFO - 2018-05-15 02:53:08 --> Utf8 Class Initialized
INFO - 2018-05-15 02:53:08 --> Hooks Class Initialized
INFO - 2018-05-15 02:53:08 --> Utf8 Class Initialized
DEBUG - 2018-05-15 02:53:08 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 02:53:08 --> UTF-8 Support Enabled
INFO - 2018-05-15 02:53:08 --> URI Class Initialized
DEBUG - 2018-05-15 02:53:08 --> UTF-8 Support Enabled
INFO - 2018-05-15 02:53:08 --> Utf8 Class Initialized
INFO - 2018-05-15 02:53:08 --> Utf8 Class Initialized
INFO - 2018-05-15 02:53:08 --> URI Class Initialized
INFO - 2018-05-15 02:53:08 --> URI Class Initialized
INFO - 2018-05-15 02:53:08 --> Utf8 Class Initialized
INFO - 2018-05-15 02:53:08 --> URI Class Initialized
INFO - 2018-05-15 02:53:08 --> Router Class Initialized
INFO - 2018-05-15 02:53:08 --> Router Class Initialized
INFO - 2018-05-15 02:53:08 --> Router Class Initialized
INFO - 2018-05-15 02:53:08 --> Router Class Initialized
INFO - 2018-05-15 02:53:08 --> Output Class Initialized
INFO - 2018-05-15 02:53:08 --> URI Class Initialized
INFO - 2018-05-15 02:53:08 --> Output Class Initialized
INFO - 2018-05-15 02:53:08 --> Output Class Initialized
INFO - 2018-05-15 02:53:08 --> Output Class Initialized
INFO - 2018-05-15 02:53:08 --> Security Class Initialized
DEBUG - 2018-05-15 02:53:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 02:53:08 --> Input Class Initialized
INFO - 2018-05-15 02:53:08 --> Security Class Initialized
INFO - 2018-05-15 02:53:08 --> Security Class Initialized
INFO - 2018-05-15 02:53:08 --> Language Class Initialized
INFO - 2018-05-15 02:53:08 --> Router Class Initialized
INFO - 2018-05-15 02:53:08 --> Security Class Initialized
DEBUG - 2018-05-15 02:53:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-15 02:53:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-05-15 02:53:08 --> 404 Page Not Found: /index
DEBUG - 2018-05-15 02:53:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 02:53:08 --> Output Class Initialized
INFO - 2018-05-15 02:53:08 --> Input Class Initialized
INFO - 2018-05-15 02:53:08 --> Security Class Initialized
INFO - 2018-05-15 02:53:08 --> Input Class Initialized
INFO - 2018-05-15 02:53:08 --> Input Class Initialized
INFO - 2018-05-15 02:53:08 --> Config Class Initialized
INFO - 2018-05-15 02:53:08 --> Hooks Class Initialized
INFO - 2018-05-15 02:53:08 --> Language Class Initialized
INFO - 2018-05-15 02:53:08 --> Language Class Initialized
DEBUG - 2018-05-15 02:53:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 02:53:08 --> Language Class Initialized
ERROR - 2018-05-15 02:53:08 --> 404 Page Not Found: /index
INFO - 2018-05-15 02:53:08 --> Input Class Initialized
ERROR - 2018-05-15 02:53:08 --> 404 Page Not Found: /index
DEBUG - 2018-05-15 02:53:08 --> UTF-8 Support Enabled
ERROR - 2018-05-15 02:53:08 --> 404 Page Not Found: /index
INFO - 2018-05-15 02:53:08 --> Language Class Initialized
INFO - 2018-05-15 02:53:08 --> Utf8 Class Initialized
INFO - 2018-05-15 02:53:08 --> URI Class Initialized
ERROR - 2018-05-15 02:53:08 --> 404 Page Not Found: /index
INFO - 2018-05-15 02:53:08 --> Router Class Initialized
INFO - 2018-05-15 02:53:08 --> Output Class Initialized
INFO - 2018-05-15 02:53:08 --> Security Class Initialized
INFO - 2018-05-15 02:53:08 --> Config Class Initialized
INFO - 2018-05-15 02:53:08 --> Config Class Initialized
DEBUG - 2018-05-15 02:53:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 02:53:08 --> Config Class Initialized
INFO - 2018-05-15 02:53:08 --> Config Class Initialized
INFO - 2018-05-15 02:53:08 --> Hooks Class Initialized
INFO - 2018-05-15 02:53:08 --> Hooks Class Initialized
INFO - 2018-05-15 02:53:08 --> Hooks Class Initialized
INFO - 2018-05-15 02:53:08 --> Input Class Initialized
DEBUG - 2018-05-15 02:53:08 --> UTF-8 Support Enabled
INFO - 2018-05-15 02:53:08 --> Hooks Class Initialized
DEBUG - 2018-05-15 02:53:08 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 02:53:08 --> UTF-8 Support Enabled
INFO - 2018-05-15 02:53:08 --> Language Class Initialized
INFO - 2018-05-15 02:53:08 --> Utf8 Class Initialized
INFO - 2018-05-15 02:53:08 --> Utf8 Class Initialized
INFO - 2018-05-15 02:53:08 --> Utf8 Class Initialized
DEBUG - 2018-05-15 02:53:08 --> UTF-8 Support Enabled
ERROR - 2018-05-15 02:53:08 --> 404 Page Not Found: /index
INFO - 2018-05-15 02:53:08 --> URI Class Initialized
INFO - 2018-05-15 02:53:08 --> Utf8 Class Initialized
INFO - 2018-05-15 02:53:08 --> URI Class Initialized
INFO - 2018-05-15 02:53:08 --> URI Class Initialized
INFO - 2018-05-15 02:53:08 --> Router Class Initialized
INFO - 2018-05-15 02:53:08 --> URI Class Initialized
INFO - 2018-05-15 02:53:08 --> Router Class Initialized
INFO - 2018-05-15 02:53:08 --> Router Class Initialized
INFO - 2018-05-15 02:53:08 --> Output Class Initialized
INFO - 2018-05-15 02:53:09 --> Security Class Initialized
DEBUG - 2018-05-15 02:53:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 02:53:09 --> Router Class Initialized
INFO - 2018-05-15 02:53:09 --> Output Class Initialized
INFO - 2018-05-15 02:53:09 --> Output Class Initialized
INFO - 2018-05-15 02:53:09 --> Input Class Initialized
INFO - 2018-05-15 02:53:09 --> Language Class Initialized
INFO - 2018-05-15 02:53:09 --> Output Class Initialized
INFO - 2018-05-15 02:53:09 --> Security Class Initialized
INFO - 2018-05-15 02:53:09 --> Security Class Initialized
ERROR - 2018-05-15 02:53:09 --> 404 Page Not Found: /index
INFO - 2018-05-15 02:53:09 --> Security Class Initialized
DEBUG - 2018-05-15 02:53:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-15 02:53:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 02:53:09 --> Input Class Initialized
INFO - 2018-05-15 02:53:09 --> Input Class Initialized
DEBUG - 2018-05-15 02:53:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 02:53:09 --> Language Class Initialized
INFO - 2018-05-15 02:53:09 --> Language Class Initialized
INFO - 2018-05-15 02:53:09 --> Input Class Initialized
ERROR - 2018-05-15 02:53:09 --> 404 Page Not Found: /index
ERROR - 2018-05-15 02:53:09 --> 404 Page Not Found: /index
INFO - 2018-05-15 02:53:09 --> Language Class Initialized
ERROR - 2018-05-15 02:53:09 --> 404 Page Not Found: /index
INFO - 2018-05-15 02:53:14 --> Config Class Initialized
INFO - 2018-05-15 02:53:14 --> Hooks Class Initialized
DEBUG - 2018-05-15 02:53:14 --> UTF-8 Support Enabled
INFO - 2018-05-15 02:53:14 --> Utf8 Class Initialized
INFO - 2018-05-15 02:53:14 --> URI Class Initialized
INFO - 2018-05-15 02:53:14 --> Router Class Initialized
INFO - 2018-05-15 02:53:14 --> Output Class Initialized
INFO - 2018-05-15 02:53:14 --> Security Class Initialized
DEBUG - 2018-05-15 02:53:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 02:53:14 --> Input Class Initialized
INFO - 2018-05-15 02:53:14 --> Language Class Initialized
ERROR - 2018-05-15 02:53:14 --> 404 Page Not Found: /index
INFO - 2018-05-15 02:53:14 --> Config Class Initialized
INFO - 2018-05-15 02:53:14 --> Hooks Class Initialized
DEBUG - 2018-05-15 02:53:14 --> UTF-8 Support Enabled
INFO - 2018-05-15 02:53:14 --> Utf8 Class Initialized
INFO - 2018-05-15 02:53:14 --> URI Class Initialized
INFO - 2018-05-15 02:53:14 --> Router Class Initialized
INFO - 2018-05-15 02:53:14 --> Output Class Initialized
INFO - 2018-05-15 02:53:14 --> Security Class Initialized
DEBUG - 2018-05-15 02:53:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 02:53:14 --> Input Class Initialized
INFO - 2018-05-15 02:53:14 --> Language Class Initialized
ERROR - 2018-05-15 02:53:14 --> 404 Page Not Found: /index
INFO - 2018-05-15 02:53:14 --> Config Class Initialized
INFO - 2018-05-15 02:53:14 --> Hooks Class Initialized
DEBUG - 2018-05-15 02:53:14 --> UTF-8 Support Enabled
INFO - 2018-05-15 02:53:14 --> Utf8 Class Initialized
INFO - 2018-05-15 02:53:14 --> URI Class Initialized
INFO - 2018-05-15 02:53:14 --> Router Class Initialized
INFO - 2018-05-15 02:53:14 --> Output Class Initialized
INFO - 2018-05-15 02:53:15 --> Security Class Initialized
DEBUG - 2018-05-15 02:53:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 02:53:15 --> Input Class Initialized
INFO - 2018-05-15 02:53:15 --> Language Class Initialized
ERROR - 2018-05-15 02:53:15 --> 404 Page Not Found: /index
INFO - 2018-05-15 02:54:45 --> Config Class Initialized
INFO - 2018-05-15 02:54:45 --> Hooks Class Initialized
DEBUG - 2018-05-15 02:54:45 --> UTF-8 Support Enabled
INFO - 2018-05-15 02:54:45 --> Utf8 Class Initialized
INFO - 2018-05-15 02:54:45 --> URI Class Initialized
INFO - 2018-05-15 02:54:45 --> Router Class Initialized
INFO - 2018-05-15 02:54:45 --> Output Class Initialized
INFO - 2018-05-15 02:54:45 --> Security Class Initialized
DEBUG - 2018-05-15 02:54:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 02:54:45 --> Input Class Initialized
INFO - 2018-05-15 02:54:45 --> Language Class Initialized
INFO - 2018-05-15 02:54:45 --> Language Class Initialized
INFO - 2018-05-15 02:54:45 --> Config Class Initialized
INFO - 2018-05-15 02:54:45 --> Loader Class Initialized
DEBUG - 2018-05-15 02:54:45 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-15 02:54:45 --> Helper loaded: url_helper
INFO - 2018-05-15 02:54:45 --> Helper loaded: form_helper
INFO - 2018-05-15 02:54:45 --> Helper loaded: date_helper
INFO - 2018-05-15 02:54:45 --> Helper loaded: util_helper
INFO - 2018-05-15 02:54:45 --> Helper loaded: text_helper
INFO - 2018-05-15 02:54:45 --> Helper loaded: string_helper
INFO - 2018-05-15 02:54:45 --> Database Driver Class Initialized
DEBUG - 2018-05-15 02:54:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-15 02:54:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-15 02:54:45 --> Email Class Initialized
INFO - 2018-05-15 02:54:45 --> Controller Class Initialized
DEBUG - 2018-05-15 02:54:45 --> Home MX_Controller Initialized
DEBUG - 2018-05-15 02:54:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-15 02:54:45 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-15 02:54:45 --> Login MX_Controller Initialized
INFO - 2018-05-15 02:54:45 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-15 02:54:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-15 02:54:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-15 02:54:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-05-15 02:54:45 --> Final output sent to browser
DEBUG - 2018-05-15 02:54:45 --> Total execution time: 0.4329
INFO - 2018-05-15 02:54:45 --> Config Class Initialized
INFO - 2018-05-15 02:54:45 --> Hooks Class Initialized
DEBUG - 2018-05-15 02:54:45 --> UTF-8 Support Enabled
INFO - 2018-05-15 02:54:45 --> Utf8 Class Initialized
INFO - 2018-05-15 02:54:45 --> URI Class Initialized
INFO - 2018-05-15 02:54:45 --> Router Class Initialized
INFO - 2018-05-15 02:54:45 --> Output Class Initialized
INFO - 2018-05-15 02:54:45 --> Security Class Initialized
DEBUG - 2018-05-15 02:54:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 02:54:45 --> Input Class Initialized
INFO - 2018-05-15 02:54:45 --> Language Class Initialized
ERROR - 2018-05-15 02:54:45 --> 404 Page Not Found: /index
INFO - 2018-05-15 02:54:45 --> Config Class Initialized
INFO - 2018-05-15 02:54:45 --> Hooks Class Initialized
DEBUG - 2018-05-15 02:54:45 --> UTF-8 Support Enabled
INFO - 2018-05-15 02:54:45 --> Utf8 Class Initialized
INFO - 2018-05-15 02:54:45 --> URI Class Initialized
INFO - 2018-05-15 02:54:45 --> Config Class Initialized
INFO - 2018-05-15 02:54:45 --> Config Class Initialized
INFO - 2018-05-15 02:54:45 --> Config Class Initialized
INFO - 2018-05-15 02:54:45 --> Config Class Initialized
INFO - 2018-05-15 02:54:45 --> Config Class Initialized
INFO - 2018-05-15 02:54:45 --> Hooks Class Initialized
INFO - 2018-05-15 02:54:45 --> Router Class Initialized
INFO - 2018-05-15 02:54:46 --> Output Class Initialized
DEBUG - 2018-05-15 02:54:46 --> UTF-8 Support Enabled
INFO - 2018-05-15 02:54:46 --> Utf8 Class Initialized
INFO - 2018-05-15 02:54:46 --> Security Class Initialized
INFO - 2018-05-15 02:54:46 --> Hooks Class Initialized
INFO - 2018-05-15 02:54:46 --> Hooks Class Initialized
INFO - 2018-05-15 02:54:46 --> Hooks Class Initialized
INFO - 2018-05-15 02:54:46 --> Hooks Class Initialized
INFO - 2018-05-15 02:54:46 --> URI Class Initialized
DEBUG - 2018-05-15 02:54:46 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 02:54:46 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 02:54:46 --> UTF-8 Support Enabled
INFO - 2018-05-15 02:54:46 --> Utf8 Class Initialized
INFO - 2018-05-15 02:54:46 --> Utf8 Class Initialized
DEBUG - 2018-05-15 02:54:46 --> UTF-8 Support Enabled
INFO - 2018-05-15 02:54:46 --> Utf8 Class Initialized
DEBUG - 2018-05-15 02:54:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 02:54:46 --> Router Class Initialized
INFO - 2018-05-15 02:54:46 --> URI Class Initialized
INFO - 2018-05-15 02:54:46 --> URI Class Initialized
INFO - 2018-05-15 02:54:46 --> Utf8 Class Initialized
INFO - 2018-05-15 02:54:46 --> URI Class Initialized
INFO - 2018-05-15 02:54:46 --> Input Class Initialized
INFO - 2018-05-15 02:54:46 --> Output Class Initialized
INFO - 2018-05-15 02:54:46 --> URI Class Initialized
INFO - 2018-05-15 02:54:46 --> Router Class Initialized
INFO - 2018-05-15 02:54:46 --> Router Class Initialized
INFO - 2018-05-15 02:54:46 --> Language Class Initialized
INFO - 2018-05-15 02:54:46 --> Router Class Initialized
INFO - 2018-05-15 02:54:46 --> Security Class Initialized
INFO - 2018-05-15 02:54:46 --> Output Class Initialized
INFO - 2018-05-15 02:54:46 --> Router Class Initialized
INFO - 2018-05-15 02:54:46 --> Output Class Initialized
INFO - 2018-05-15 02:54:46 --> Output Class Initialized
ERROR - 2018-05-15 02:54:46 --> 404 Page Not Found: /index
DEBUG - 2018-05-15 02:54:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 02:54:46 --> Config Class Initialized
INFO - 2018-05-15 02:54:46 --> Input Class Initialized
INFO - 2018-05-15 02:54:46 --> Security Class Initialized
INFO - 2018-05-15 02:54:46 --> Output Class Initialized
INFO - 2018-05-15 02:54:46 --> Security Class Initialized
INFO - 2018-05-15 02:54:46 --> Security Class Initialized
INFO - 2018-05-15 02:54:46 --> Hooks Class Initialized
DEBUG - 2018-05-15 02:54:46 --> UTF-8 Support Enabled
INFO - 2018-05-15 02:54:46 --> Security Class Initialized
INFO - 2018-05-15 02:54:46 --> Language Class Initialized
DEBUG - 2018-05-15 02:54:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-15 02:54:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-15 02:54:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 02:54:46 --> Utf8 Class Initialized
INFO - 2018-05-15 02:54:46 --> Input Class Initialized
INFO - 2018-05-15 02:54:46 --> Input Class Initialized
ERROR - 2018-05-15 02:54:46 --> 404 Page Not Found: /index
INFO - 2018-05-15 02:54:46 --> Input Class Initialized
DEBUG - 2018-05-15 02:54:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 02:54:46 --> Input Class Initialized
INFO - 2018-05-15 02:54:46 --> URI Class Initialized
INFO - 2018-05-15 02:54:46 --> Language Class Initialized
INFO - 2018-05-15 02:54:46 --> Language Class Initialized
INFO - 2018-05-15 02:54:46 --> Language Class Initialized
INFO - 2018-05-15 02:54:46 --> Language Class Initialized
INFO - 2018-05-15 02:54:46 --> Router Class Initialized
ERROR - 2018-05-15 02:54:46 --> 404 Page Not Found: /index
ERROR - 2018-05-15 02:54:46 --> 404 Page Not Found: /index
ERROR - 2018-05-15 02:54:46 --> 404 Page Not Found: /index
INFO - 2018-05-15 02:54:46 --> Output Class Initialized
ERROR - 2018-05-15 02:54:46 --> 404 Page Not Found: /index
INFO - 2018-05-15 02:54:46 --> Security Class Initialized
INFO - 2018-05-15 02:54:46 --> Config Class Initialized
INFO - 2018-05-15 02:54:46 --> Config Class Initialized
INFO - 2018-05-15 02:54:46 --> Hooks Class Initialized
INFO - 2018-05-15 02:54:46 --> Hooks Class Initialized
DEBUG - 2018-05-15 02:54:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 02:54:46 --> Config Class Initialized
INFO - 2018-05-15 02:54:46 --> Config Class Initialized
INFO - 2018-05-15 02:54:46 --> Hooks Class Initialized
DEBUG - 2018-05-15 02:54:46 --> UTF-8 Support Enabled
INFO - 2018-05-15 02:54:46 --> Input Class Initialized
INFO - 2018-05-15 02:54:46 --> Hooks Class Initialized
DEBUG - 2018-05-15 02:54:46 --> UTF-8 Support Enabled
INFO - 2018-05-15 02:54:46 --> Utf8 Class Initialized
INFO - 2018-05-15 02:54:46 --> URI Class Initialized
INFO - 2018-05-15 02:54:46 --> Router Class Initialized
INFO - 2018-05-15 02:54:46 --> Output Class Initialized
INFO - 2018-05-15 02:54:46 --> Security Class Initialized
DEBUG - 2018-05-15 02:54:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-15 02:54:46 --> UTF-8 Support Enabled
INFO - 2018-05-15 02:54:46 --> Input Class Initialized
INFO - 2018-05-15 02:54:46 --> Language Class Initialized
INFO - 2018-05-15 02:54:46 --> Language Class Initialized
INFO - 2018-05-15 02:54:46 --> Utf8 Class Initialized
INFO - 2018-05-15 02:54:46 --> Utf8 Class Initialized
DEBUG - 2018-05-15 02:54:46 --> UTF-8 Support Enabled
ERROR - 2018-05-15 02:54:46 --> 404 Page Not Found: /index
INFO - 2018-05-15 02:54:46 --> Utf8 Class Initialized
ERROR - 2018-05-15 02:54:46 --> 404 Page Not Found: /index
INFO - 2018-05-15 02:54:46 --> URI Class Initialized
INFO - 2018-05-15 02:54:46 --> URI Class Initialized
INFO - 2018-05-15 02:54:46 --> URI Class Initialized
INFO - 2018-05-15 02:54:46 --> Config Class Initialized
INFO - 2018-05-15 02:54:46 --> Hooks Class Initialized
INFO - 2018-05-15 02:54:46 --> Router Class Initialized
INFO - 2018-05-15 02:54:46 --> Router Class Initialized
INFO - 2018-05-15 02:54:46 --> Router Class Initialized
DEBUG - 2018-05-15 02:54:46 --> UTF-8 Support Enabled
INFO - 2018-05-15 02:54:46 --> Output Class Initialized
INFO - 2018-05-15 02:54:46 --> Output Class Initialized
INFO - 2018-05-15 02:54:46 --> Output Class Initialized
INFO - 2018-05-15 02:54:46 --> Utf8 Class Initialized
INFO - 2018-05-15 02:54:46 --> Config Class Initialized
INFO - 2018-05-15 02:54:46 --> URI Class Initialized
INFO - 2018-05-15 02:54:46 --> Hooks Class Initialized
INFO - 2018-05-15 02:54:46 --> Router Class Initialized
INFO - 2018-05-15 02:54:46 --> Security Class Initialized
INFO - 2018-05-15 02:54:46 --> Security Class Initialized
INFO - 2018-05-15 02:54:46 --> Security Class Initialized
INFO - 2018-05-15 02:54:46 --> Output Class Initialized
DEBUG - 2018-05-15 02:54:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-15 02:54:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-15 02:54:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 02:54:46 --> Security Class Initialized
DEBUG - 2018-05-15 02:54:46 --> UTF-8 Support Enabled
INFO - 2018-05-15 02:54:46 --> Input Class Initialized
INFO - 2018-05-15 02:54:46 --> Input Class Initialized
DEBUG - 2018-05-15 02:54:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 02:54:46 --> Input Class Initialized
INFO - 2018-05-15 02:54:46 --> Utf8 Class Initialized
INFO - 2018-05-15 02:54:46 --> Language Class Initialized
INFO - 2018-05-15 02:54:46 --> Input Class Initialized
INFO - 2018-05-15 02:54:46 --> Language Class Initialized
INFO - 2018-05-15 02:54:46 --> URI Class Initialized
INFO - 2018-05-15 02:54:46 --> Language Class Initialized
ERROR - 2018-05-15 02:54:46 --> 404 Page Not Found: /index
INFO - 2018-05-15 02:54:46 --> Language Class Initialized
ERROR - 2018-05-15 02:54:46 --> 404 Page Not Found: /index
INFO - 2018-05-15 02:54:46 --> Router Class Initialized
ERROR - 2018-05-15 02:54:46 --> 404 Page Not Found: /index
INFO - 2018-05-15 02:54:46 --> Config Class Initialized
INFO - 2018-05-15 02:54:46 --> Output Class Initialized
ERROR - 2018-05-15 02:54:46 --> 404 Page Not Found: /index
INFO - 2018-05-15 02:54:46 --> Hooks Class Initialized
INFO - 2018-05-15 02:54:46 --> Security Class Initialized
INFO - 2018-05-15 02:54:46 --> Config Class Initialized
INFO - 2018-05-15 02:54:46 --> Config Class Initialized
INFO - 2018-05-15 02:54:46 --> Hooks Class Initialized
INFO - 2018-05-15 02:54:46 --> Hooks Class Initialized
DEBUG - 2018-05-15 02:54:46 --> UTF-8 Support Enabled
INFO - 2018-05-15 02:54:46 --> Config Class Initialized
DEBUG - 2018-05-15 02:54:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 02:54:46 --> Hooks Class Initialized
INFO - 2018-05-15 02:54:46 --> Utf8 Class Initialized
DEBUG - 2018-05-15 02:54:46 --> UTF-8 Support Enabled
INFO - 2018-05-15 02:54:46 --> Input Class Initialized
DEBUG - 2018-05-15 02:54:46 --> UTF-8 Support Enabled
INFO - 2018-05-15 02:54:46 --> Utf8 Class Initialized
INFO - 2018-05-15 02:54:46 --> Utf8 Class Initialized
DEBUG - 2018-05-15 02:54:47 --> UTF-8 Support Enabled
INFO - 2018-05-15 02:54:47 --> URI Class Initialized
INFO - 2018-05-15 02:54:47 --> Language Class Initialized
INFO - 2018-05-15 02:54:47 --> Utf8 Class Initialized
ERROR - 2018-05-15 02:54:47 --> 404 Page Not Found: /index
INFO - 2018-05-15 02:54:47 --> URI Class Initialized
INFO - 2018-05-15 02:54:47 --> Router Class Initialized
INFO - 2018-05-15 02:54:47 --> URI Class Initialized
INFO - 2018-05-15 02:54:47 --> URI Class Initialized
INFO - 2018-05-15 02:54:47 --> Router Class Initialized
INFO - 2018-05-15 02:54:47 --> Output Class Initialized
INFO - 2018-05-15 02:54:47 --> Router Class Initialized
INFO - 2018-05-15 02:54:47 --> Output Class Initialized
INFO - 2018-05-15 02:54:47 --> Router Class Initialized
INFO - 2018-05-15 02:54:47 --> Output Class Initialized
INFO - 2018-05-15 02:54:47 --> Security Class Initialized
INFO - 2018-05-15 02:54:47 --> Output Class Initialized
INFO - 2018-05-15 02:54:47 --> Security Class Initialized
DEBUG - 2018-05-15 02:54:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 02:54:47 --> Security Class Initialized
INFO - 2018-05-15 02:54:47 --> Input Class Initialized
DEBUG - 2018-05-15 02:54:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 02:54:47 --> Security Class Initialized
DEBUG - 2018-05-15 02:54:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 02:54:47 --> Input Class Initialized
INFO - 2018-05-15 02:54:47 --> Language Class Initialized
DEBUG - 2018-05-15 02:54:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 02:54:47 --> Input Class Initialized
INFO - 2018-05-15 02:54:47 --> Language Class Initialized
INFO - 2018-05-15 02:54:47 --> Input Class Initialized
ERROR - 2018-05-15 02:54:47 --> 404 Page Not Found: /index
INFO - 2018-05-15 02:54:47 --> Language Class Initialized
ERROR - 2018-05-15 02:54:47 --> 404 Page Not Found: /index
ERROR - 2018-05-15 02:54:47 --> 404 Page Not Found: /index
INFO - 2018-05-15 02:54:47 --> Language Class Initialized
ERROR - 2018-05-15 02:54:47 --> 404 Page Not Found: /index
INFO - 2018-05-15 02:54:49 --> Config Class Initialized
INFO - 2018-05-15 02:54:49 --> Hooks Class Initialized
DEBUG - 2018-05-15 02:54:49 --> UTF-8 Support Enabled
INFO - 2018-05-15 02:54:49 --> Utf8 Class Initialized
INFO - 2018-05-15 02:54:49 --> URI Class Initialized
INFO - 2018-05-15 02:54:49 --> Router Class Initialized
INFO - 2018-05-15 02:54:49 --> Output Class Initialized
INFO - 2018-05-15 02:54:49 --> Security Class Initialized
DEBUG - 2018-05-15 02:54:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 02:54:49 --> Input Class Initialized
INFO - 2018-05-15 02:54:49 --> Language Class Initialized
ERROR - 2018-05-15 02:54:49 --> 404 Page Not Found: /index
INFO - 2018-05-15 02:54:49 --> Config Class Initialized
INFO - 2018-05-15 02:54:49 --> Hooks Class Initialized
DEBUG - 2018-05-15 02:54:49 --> UTF-8 Support Enabled
INFO - 2018-05-15 02:54:49 --> Utf8 Class Initialized
INFO - 2018-05-15 02:54:49 --> URI Class Initialized
INFO - 2018-05-15 02:54:49 --> Router Class Initialized
INFO - 2018-05-15 02:54:49 --> Output Class Initialized
INFO - 2018-05-15 02:54:49 --> Security Class Initialized
DEBUG - 2018-05-15 02:54:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 02:54:49 --> Input Class Initialized
INFO - 2018-05-15 02:54:49 --> Language Class Initialized
ERROR - 2018-05-15 02:54:49 --> 404 Page Not Found: /index
INFO - 2018-05-15 02:54:49 --> Config Class Initialized
INFO - 2018-05-15 02:54:49 --> Hooks Class Initialized
DEBUG - 2018-05-15 02:54:49 --> UTF-8 Support Enabled
INFO - 2018-05-15 02:54:49 --> Utf8 Class Initialized
INFO - 2018-05-15 02:54:49 --> URI Class Initialized
INFO - 2018-05-15 02:54:49 --> Router Class Initialized
INFO - 2018-05-15 02:54:49 --> Output Class Initialized
INFO - 2018-05-15 02:54:49 --> Security Class Initialized
DEBUG - 2018-05-15 02:54:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 02:54:49 --> Input Class Initialized
INFO - 2018-05-15 02:54:49 --> Language Class Initialized
ERROR - 2018-05-15 02:54:49 --> 404 Page Not Found: /index
INFO - 2018-05-15 03:11:04 --> Config Class Initialized
INFO - 2018-05-15 03:11:04 --> Hooks Class Initialized
DEBUG - 2018-05-15 03:11:04 --> UTF-8 Support Enabled
INFO - 2018-05-15 03:11:04 --> Utf8 Class Initialized
INFO - 2018-05-15 03:11:04 --> URI Class Initialized
INFO - 2018-05-15 03:11:04 --> Router Class Initialized
INFO - 2018-05-15 03:11:04 --> Output Class Initialized
INFO - 2018-05-15 03:11:04 --> Security Class Initialized
DEBUG - 2018-05-15 03:11:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 03:11:04 --> Input Class Initialized
INFO - 2018-05-15 03:11:04 --> Language Class Initialized
INFO - 2018-05-15 03:11:04 --> Language Class Initialized
INFO - 2018-05-15 03:11:04 --> Config Class Initialized
INFO - 2018-05-15 03:11:04 --> Loader Class Initialized
DEBUG - 2018-05-15 03:11:04 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-15 03:11:04 --> Helper loaded: url_helper
INFO - 2018-05-15 03:11:04 --> Helper loaded: form_helper
INFO - 2018-05-15 03:11:04 --> Helper loaded: date_helper
INFO - 2018-05-15 03:11:04 --> Helper loaded: util_helper
INFO - 2018-05-15 03:11:04 --> Helper loaded: text_helper
INFO - 2018-05-15 03:11:04 --> Helper loaded: string_helper
INFO - 2018-05-15 03:11:04 --> Database Driver Class Initialized
DEBUG - 2018-05-15 03:11:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-15 03:11:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-15 03:11:04 --> Email Class Initialized
INFO - 2018-05-15 03:11:04 --> Controller Class Initialized
DEBUG - 2018-05-15 03:11:05 --> Login MX_Controller Initialized
INFO - 2018-05-15 03:11:05 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-15 03:11:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-15 03:11:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-15 03:11:05 --> 4 Loggedout
INFO - 2018-05-15 03:11:05 --> Config Class Initialized
INFO - 2018-05-15 03:11:05 --> Hooks Class Initialized
DEBUG - 2018-05-15 03:11:05 --> UTF-8 Support Enabled
INFO - 2018-05-15 03:11:05 --> Utf8 Class Initialized
INFO - 2018-05-15 03:11:05 --> URI Class Initialized
INFO - 2018-05-15 03:11:05 --> Router Class Initialized
INFO - 2018-05-15 03:11:05 --> Output Class Initialized
INFO - 2018-05-15 03:11:05 --> Security Class Initialized
DEBUG - 2018-05-15 03:11:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 03:11:05 --> Input Class Initialized
INFO - 2018-05-15 03:11:05 --> Language Class Initialized
INFO - 2018-05-15 03:11:05 --> Language Class Initialized
INFO - 2018-05-15 03:11:05 --> Config Class Initialized
INFO - 2018-05-15 03:11:05 --> Loader Class Initialized
DEBUG - 2018-05-15 03:11:05 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-15 03:11:05 --> Helper loaded: url_helper
INFO - 2018-05-15 03:11:05 --> Helper loaded: form_helper
INFO - 2018-05-15 03:11:05 --> Helper loaded: date_helper
INFO - 2018-05-15 03:11:05 --> Helper loaded: util_helper
INFO - 2018-05-15 03:11:05 --> Helper loaded: text_helper
INFO - 2018-05-15 03:11:05 --> Helper loaded: string_helper
INFO - 2018-05-15 03:11:05 --> Database Driver Class Initialized
DEBUG - 2018-05-15 03:11:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-15 03:11:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-15 03:11:05 --> Email Class Initialized
INFO - 2018-05-15 03:11:05 --> Controller Class Initialized
DEBUG - 2018-05-15 03:11:05 --> Home MX_Controller Initialized
DEBUG - 2018-05-15 03:11:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-15 03:11:05 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-15 03:11:05 --> Login MX_Controller Initialized
INFO - 2018-05-15 03:11:05 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-15 03:11:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-15 03:11:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-15 03:11:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/login.php
INFO - 2018-05-15 03:11:07 --> Config Class Initialized
INFO - 2018-05-15 03:11:07 --> Hooks Class Initialized
DEBUG - 2018-05-15 03:11:07 --> UTF-8 Support Enabled
INFO - 2018-05-15 03:11:07 --> Utf8 Class Initialized
INFO - 2018-05-15 03:11:07 --> URI Class Initialized
INFO - 2018-05-15 03:11:07 --> Router Class Initialized
INFO - 2018-05-15 03:11:07 --> Output Class Initialized
INFO - 2018-05-15 03:11:07 --> Security Class Initialized
DEBUG - 2018-05-15 03:11:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 03:11:07 --> Input Class Initialized
INFO - 2018-05-15 03:11:07 --> Language Class Initialized
INFO - 2018-05-15 03:11:07 --> Language Class Initialized
INFO - 2018-05-15 03:11:07 --> Config Class Initialized
INFO - 2018-05-15 03:11:07 --> Loader Class Initialized
DEBUG - 2018-05-15 03:11:07 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-15 03:11:07 --> Helper loaded: url_helper
INFO - 2018-05-15 03:11:07 --> Helper loaded: form_helper
INFO - 2018-05-15 03:11:07 --> Helper loaded: date_helper
INFO - 2018-05-15 03:11:07 --> Helper loaded: util_helper
INFO - 2018-05-15 03:11:07 --> Helper loaded: text_helper
INFO - 2018-05-15 03:11:07 --> Helper loaded: string_helper
INFO - 2018-05-15 03:11:07 --> Database Driver Class Initialized
DEBUG - 2018-05-15 03:11:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-15 03:11:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-15 03:11:07 --> Email Class Initialized
INFO - 2018-05-15 03:11:07 --> Controller Class Initialized
DEBUG - 2018-05-15 03:11:07 --> Login MX_Controller Initialized
INFO - 2018-05-15 03:11:07 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-15 03:11:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-15 03:11:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-15 03:11:07 --> Email starts for gopipanguluri123@gmail.com fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-05-15 03:11:07 --> User session created for 4
INFO - 2018-05-15 03:11:07 --> Login status gopipanguluri123@gmail.com - success
INFO - 2018-05-15 03:11:07 --> Final output sent to browser
DEBUG - 2018-05-15 03:11:07 --> Total execution time: 0.4414
INFO - 2018-05-15 03:11:07 --> Config Class Initialized
INFO - 2018-05-15 03:11:07 --> Hooks Class Initialized
DEBUG - 2018-05-15 03:11:07 --> UTF-8 Support Enabled
INFO - 2018-05-15 03:11:07 --> Utf8 Class Initialized
INFO - 2018-05-15 03:11:07 --> URI Class Initialized
INFO - 2018-05-15 03:11:07 --> Router Class Initialized
INFO - 2018-05-15 03:11:08 --> Output Class Initialized
INFO - 2018-05-15 03:11:08 --> Security Class Initialized
DEBUG - 2018-05-15 03:11:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 03:11:08 --> Input Class Initialized
INFO - 2018-05-15 03:11:08 --> Language Class Initialized
INFO - 2018-05-15 03:11:08 --> Language Class Initialized
INFO - 2018-05-15 03:11:08 --> Config Class Initialized
INFO - 2018-05-15 03:11:08 --> Loader Class Initialized
DEBUG - 2018-05-15 03:11:08 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-15 03:11:08 --> Helper loaded: url_helper
INFO - 2018-05-15 03:11:08 --> Helper loaded: form_helper
INFO - 2018-05-15 03:11:08 --> Helper loaded: date_helper
INFO - 2018-05-15 03:11:08 --> Helper loaded: util_helper
INFO - 2018-05-15 03:11:08 --> Helper loaded: text_helper
INFO - 2018-05-15 03:11:08 --> Helper loaded: string_helper
INFO - 2018-05-15 03:11:08 --> Database Driver Class Initialized
DEBUG - 2018-05-15 03:11:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-15 03:11:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-15 03:11:08 --> Email Class Initialized
INFO - 2018-05-15 03:11:08 --> Controller Class Initialized
DEBUG - 2018-05-15 03:11:08 --> Home MX_Controller Initialized
DEBUG - 2018-05-15 03:11:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-15 03:11:08 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-15 03:11:08 --> Login MX_Controller Initialized
INFO - 2018-05-15 03:11:08 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-15 03:11:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-15 03:11:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-15 03:11:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-05-15 03:11:08 --> Final output sent to browser
DEBUG - 2018-05-15 03:11:08 --> Total execution time: 0.4432
INFO - 2018-05-15 03:11:08 --> Config Class Initialized
INFO - 2018-05-15 03:11:08 --> Hooks Class Initialized
DEBUG - 2018-05-15 03:11:08 --> UTF-8 Support Enabled
INFO - 2018-05-15 03:11:08 --> Utf8 Class Initialized
INFO - 2018-05-15 03:11:08 --> URI Class Initialized
INFO - 2018-05-15 03:11:08 --> Router Class Initialized
INFO - 2018-05-15 03:11:08 --> Output Class Initialized
INFO - 2018-05-15 03:11:08 --> Security Class Initialized
DEBUG - 2018-05-15 03:11:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 03:11:08 --> Config Class Initialized
INFO - 2018-05-15 03:11:08 --> Config Class Initialized
INFO - 2018-05-15 03:11:08 --> Hooks Class Initialized
INFO - 2018-05-15 03:11:08 --> Hooks Class Initialized
INFO - 2018-05-15 03:11:08 --> Input Class Initialized
INFO - 2018-05-15 03:11:08 --> Config Class Initialized
INFO - 2018-05-15 03:11:08 --> Config Class Initialized
INFO - 2018-05-15 03:11:08 --> Config Class Initialized
INFO - 2018-05-15 03:11:08 --> Hooks Class Initialized
DEBUG - 2018-05-15 03:11:08 --> UTF-8 Support Enabled
INFO - 2018-05-15 03:11:08 --> Hooks Class Initialized
INFO - 2018-05-15 03:11:08 --> Hooks Class Initialized
INFO - 2018-05-15 03:11:08 --> Language Class Initialized
DEBUG - 2018-05-15 03:11:08 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 03:11:08 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 03:11:08 --> UTF-8 Support Enabled
INFO - 2018-05-15 03:11:08 --> Utf8 Class Initialized
INFO - 2018-05-15 03:11:08 --> Utf8 Class Initialized
INFO - 2018-05-15 03:11:08 --> Utf8 Class Initialized
INFO - 2018-05-15 03:11:08 --> Utf8 Class Initialized
DEBUG - 2018-05-15 03:11:08 --> UTF-8 Support Enabled
ERROR - 2018-05-15 03:11:08 --> 404 Page Not Found: /index
INFO - 2018-05-15 03:11:08 --> Config Class Initialized
INFO - 2018-05-15 03:11:08 --> Utf8 Class Initialized
INFO - 2018-05-15 03:11:08 --> URI Class Initialized
INFO - 2018-05-15 03:11:08 --> URI Class Initialized
INFO - 2018-05-15 03:11:08 --> URI Class Initialized
INFO - 2018-05-15 03:11:08 --> URI Class Initialized
INFO - 2018-05-15 03:11:08 --> Hooks Class Initialized
INFO - 2018-05-15 03:11:08 --> Router Class Initialized
INFO - 2018-05-15 03:11:08 --> URI Class Initialized
INFO - 2018-05-15 03:11:08 --> Router Class Initialized
INFO - 2018-05-15 03:11:08 --> Router Class Initialized
INFO - 2018-05-15 03:11:08 --> Router Class Initialized
INFO - 2018-05-15 03:11:08 --> Output Class Initialized
INFO - 2018-05-15 03:11:08 --> Output Class Initialized
INFO - 2018-05-15 03:11:08 --> Router Class Initialized
DEBUG - 2018-05-15 03:11:08 --> UTF-8 Support Enabled
INFO - 2018-05-15 03:11:08 --> Output Class Initialized
INFO - 2018-05-15 03:11:08 --> Output Class Initialized
INFO - 2018-05-15 03:11:08 --> Security Class Initialized
INFO - 2018-05-15 03:11:08 --> Utf8 Class Initialized
INFO - 2018-05-15 03:11:08 --> Security Class Initialized
INFO - 2018-05-15 03:11:08 --> Output Class Initialized
INFO - 2018-05-15 03:11:08 --> Security Class Initialized
INFO - 2018-05-15 03:11:08 --> Security Class Initialized
DEBUG - 2018-05-15 03:11:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 03:11:08 --> Security Class Initialized
INFO - 2018-05-15 03:11:08 --> URI Class Initialized
DEBUG - 2018-05-15 03:11:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-15 03:11:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-15 03:11:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 03:11:08 --> Input Class Initialized
INFO - 2018-05-15 03:11:08 --> Language Class Initialized
ERROR - 2018-05-15 03:11:08 --> 404 Page Not Found: /index
INFO - 2018-05-15 03:11:08 --> Config Class Initialized
DEBUG - 2018-05-15 03:11:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 03:11:08 --> Router Class Initialized
INFO - 2018-05-15 03:11:08 --> Input Class Initialized
INFO - 2018-05-15 03:11:08 --> Input Class Initialized
INFO - 2018-05-15 03:11:08 --> Input Class Initialized
INFO - 2018-05-15 03:11:08 --> Hooks Class Initialized
DEBUG - 2018-05-15 03:11:09 --> UTF-8 Support Enabled
INFO - 2018-05-15 03:11:09 --> Input Class Initialized
INFO - 2018-05-15 03:11:09 --> Output Class Initialized
INFO - 2018-05-15 03:11:09 --> Language Class Initialized
INFO - 2018-05-15 03:11:09 --> Language Class Initialized
INFO - 2018-05-15 03:11:09 --> Language Class Initialized
INFO - 2018-05-15 03:11:09 --> Utf8 Class Initialized
INFO - 2018-05-15 03:11:09 --> Language Class Initialized
ERROR - 2018-05-15 03:11:09 --> 404 Page Not Found: /index
ERROR - 2018-05-15 03:11:09 --> 404 Page Not Found: /index
INFO - 2018-05-15 03:11:09 --> Security Class Initialized
ERROR - 2018-05-15 03:11:09 --> 404 Page Not Found: /index
ERROR - 2018-05-15 03:11:09 --> 404 Page Not Found: /index
INFO - 2018-05-15 03:11:09 --> URI Class Initialized
DEBUG - 2018-05-15 03:11:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 03:11:09 --> Input Class Initialized
INFO - 2018-05-15 03:11:09 --> Config Class Initialized
INFO - 2018-05-15 03:11:09 --> Config Class Initialized
INFO - 2018-05-15 03:11:09 --> Router Class Initialized
INFO - 2018-05-15 03:11:09 --> Config Class Initialized
INFO - 2018-05-15 03:11:09 --> Hooks Class Initialized
INFO - 2018-05-15 03:11:09 --> Language Class Initialized
INFO - 2018-05-15 03:11:09 --> Output Class Initialized
DEBUG - 2018-05-15 03:11:09 --> UTF-8 Support Enabled
INFO - 2018-05-15 03:11:09 --> Utf8 Class Initialized
INFO - 2018-05-15 03:11:09 --> URI Class Initialized
INFO - 2018-05-15 03:11:09 --> Security Class Initialized
INFO - 2018-05-15 03:11:09 --> Hooks Class Initialized
INFO - 2018-05-15 03:11:09 --> Hooks Class Initialized
ERROR - 2018-05-15 03:11:09 --> 404 Page Not Found: /index
INFO - 2018-05-15 03:11:09 --> Router Class Initialized
INFO - 2018-05-15 03:11:09 --> Config Class Initialized
DEBUG - 2018-05-15 03:11:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-15 03:11:09 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 03:11:09 --> UTF-8 Support Enabled
INFO - 2018-05-15 03:11:09 --> Output Class Initialized
INFO - 2018-05-15 03:11:09 --> Hooks Class Initialized
INFO - 2018-05-15 03:11:09 --> Input Class Initialized
INFO - 2018-05-15 03:11:09 --> Utf8 Class Initialized
INFO - 2018-05-15 03:11:09 --> Utf8 Class Initialized
INFO - 2018-05-15 03:11:09 --> Security Class Initialized
DEBUG - 2018-05-15 03:11:09 --> UTF-8 Support Enabled
INFO - 2018-05-15 03:11:09 --> Language Class Initialized
DEBUG - 2018-05-15 03:11:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 03:11:09 --> URI Class Initialized
INFO - 2018-05-15 03:11:09 --> URI Class Initialized
INFO - 2018-05-15 03:11:09 --> Utf8 Class Initialized
INFO - 2018-05-15 03:11:09 --> URI Class Initialized
INFO - 2018-05-15 03:11:09 --> Router Class Initialized
INFO - 2018-05-15 03:11:09 --> Input Class Initialized
INFO - 2018-05-15 03:11:09 --> Router Class Initialized
INFO - 2018-05-15 03:11:09 --> Router Class Initialized
ERROR - 2018-05-15 03:11:09 --> 404 Page Not Found: /index
INFO - 2018-05-15 03:11:09 --> Output Class Initialized
INFO - 2018-05-15 03:11:09 --> Output Class Initialized
INFO - 2018-05-15 03:11:09 --> Output Class Initialized
INFO - 2018-05-15 03:11:09 --> Security Class Initialized
INFO - 2018-05-15 03:11:09 --> Language Class Initialized
INFO - 2018-05-15 03:11:09 --> Config Class Initialized
INFO - 2018-05-15 03:11:09 --> Hooks Class Initialized
INFO - 2018-05-15 03:11:09 --> Security Class Initialized
ERROR - 2018-05-15 03:11:09 --> 404 Page Not Found: /index
DEBUG - 2018-05-15 03:11:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 03:11:09 --> Security Class Initialized
DEBUG - 2018-05-15 03:11:09 --> UTF-8 Support Enabled
INFO - 2018-05-15 03:11:09 --> Utf8 Class Initialized
INFO - 2018-05-15 03:11:09 --> URI Class Initialized
INFO - 2018-05-15 03:11:09 --> Router Class Initialized
INFO - 2018-05-15 03:11:09 --> Output Class Initialized
INFO - 2018-05-15 03:11:09 --> Security Class Initialized
DEBUG - 2018-05-15 03:11:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 03:11:09 --> Input Class Initialized
DEBUG - 2018-05-15 03:11:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 03:11:09 --> Input Class Initialized
DEBUG - 2018-05-15 03:11:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 03:11:09 --> Input Class Initialized
INFO - 2018-05-15 03:11:09 --> Language Class Initialized
INFO - 2018-05-15 03:11:09 --> Language Class Initialized
INFO - 2018-05-15 03:11:09 --> Input Class Initialized
INFO - 2018-05-15 03:11:09 --> Language Class Initialized
ERROR - 2018-05-15 03:11:09 --> 404 Page Not Found: /index
INFO - 2018-05-15 03:11:09 --> Language Class Initialized
ERROR - 2018-05-15 03:11:10 --> 404 Page Not Found: /index
ERROR - 2018-05-15 03:11:10 --> 404 Page Not Found: /index
ERROR - 2018-05-15 03:11:10 --> 404 Page Not Found: /index
INFO - 2018-05-15 03:11:10 --> Config Class Initialized
INFO - 2018-05-15 03:11:10 --> Config Class Initialized
INFO - 2018-05-15 03:11:10 --> Hooks Class Initialized
INFO - 2018-05-15 03:11:10 --> Config Class Initialized
INFO - 2018-05-15 03:11:10 --> Config Class Initialized
INFO - 2018-05-15 03:11:10 --> Hooks Class Initialized
INFO - 2018-05-15 03:11:10 --> Hooks Class Initialized
INFO - 2018-05-15 03:11:10 --> Hooks Class Initialized
DEBUG - 2018-05-15 03:11:10 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 03:11:10 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 03:11:10 --> UTF-8 Support Enabled
INFO - 2018-05-15 03:11:10 --> Utf8 Class Initialized
DEBUG - 2018-05-15 03:11:10 --> UTF-8 Support Enabled
INFO - 2018-05-15 03:11:10 --> Utf8 Class Initialized
INFO - 2018-05-15 03:11:10 --> Utf8 Class Initialized
INFO - 2018-05-15 03:11:10 --> Utf8 Class Initialized
INFO - 2018-05-15 03:11:10 --> URI Class Initialized
INFO - 2018-05-15 03:11:10 --> URI Class Initialized
INFO - 2018-05-15 03:11:10 --> URI Class Initialized
INFO - 2018-05-15 03:11:10 --> URI Class Initialized
INFO - 2018-05-15 03:11:10 --> Router Class Initialized
INFO - 2018-05-15 03:11:10 --> Router Class Initialized
INFO - 2018-05-15 03:11:10 --> Output Class Initialized
INFO - 2018-05-15 03:11:10 --> Output Class Initialized
INFO - 2018-05-15 03:11:10 --> Router Class Initialized
INFO - 2018-05-15 03:11:10 --> Router Class Initialized
INFO - 2018-05-15 03:11:10 --> Security Class Initialized
INFO - 2018-05-15 03:11:10 --> Security Class Initialized
INFO - 2018-05-15 03:11:10 --> Output Class Initialized
INFO - 2018-05-15 03:11:10 --> Output Class Initialized
DEBUG - 2018-05-15 03:11:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-15 03:11:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 03:11:10 --> Security Class Initialized
INFO - 2018-05-15 03:11:10 --> Security Class Initialized
INFO - 2018-05-15 03:11:10 --> Input Class Initialized
INFO - 2018-05-15 03:11:10 --> Language Class Initialized
INFO - 2018-05-15 03:11:10 --> Input Class Initialized
DEBUG - 2018-05-15 03:11:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-15 03:11:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-05-15 03:11:10 --> 404 Page Not Found: /index
INFO - 2018-05-15 03:11:10 --> Language Class Initialized
INFO - 2018-05-15 03:11:10 --> Input Class Initialized
INFO - 2018-05-15 03:11:10 --> Input Class Initialized
ERROR - 2018-05-15 03:11:10 --> 404 Page Not Found: /index
INFO - 2018-05-15 03:11:10 --> Language Class Initialized
INFO - 2018-05-15 03:11:10 --> Language Class Initialized
ERROR - 2018-05-15 03:11:10 --> 404 Page Not Found: /index
ERROR - 2018-05-15 03:11:10 --> 404 Page Not Found: /index
INFO - 2018-05-15 03:53:35 --> Config Class Initialized
INFO - 2018-05-15 03:53:35 --> Hooks Class Initialized
DEBUG - 2018-05-15 03:53:35 --> UTF-8 Support Enabled
INFO - 2018-05-15 03:53:35 --> Utf8 Class Initialized
INFO - 2018-05-15 03:53:35 --> URI Class Initialized
INFO - 2018-05-15 03:53:35 --> Router Class Initialized
INFO - 2018-05-15 03:53:35 --> Output Class Initialized
INFO - 2018-05-15 03:53:35 --> Security Class Initialized
DEBUG - 2018-05-15 03:53:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 03:53:35 --> Input Class Initialized
INFO - 2018-05-15 03:53:35 --> Language Class Initialized
INFO - 2018-05-15 03:53:35 --> Language Class Initialized
INFO - 2018-05-15 03:53:36 --> Config Class Initialized
INFO - 2018-05-15 03:53:36 --> Loader Class Initialized
DEBUG - 2018-05-15 03:53:36 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-15 03:53:36 --> Helper loaded: url_helper
INFO - 2018-05-15 03:53:36 --> Helper loaded: form_helper
INFO - 2018-05-15 03:53:36 --> Helper loaded: date_helper
INFO - 2018-05-15 03:53:36 --> Helper loaded: util_helper
INFO - 2018-05-15 03:53:36 --> Helper loaded: text_helper
INFO - 2018-05-15 03:53:36 --> Helper loaded: string_helper
INFO - 2018-05-15 03:53:36 --> Database Driver Class Initialized
DEBUG - 2018-05-15 03:53:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-15 03:53:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-15 03:53:36 --> Email Class Initialized
INFO - 2018-05-15 03:53:36 --> Controller Class Initialized
DEBUG - 2018-05-15 03:53:36 --> Programs MX_Controller Initialized
INFO - 2018-05-15 03:53:36 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-15 03:53:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-05-15 03:53:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-15 03:53:36 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-15 03:53:36 --> Login MX_Controller Initialized
DEBUG - 2018-05-15 03:53:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-15 03:53:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-05-15 03:53:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-05-15 03:53:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-05-15 03:53:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-05-15 03:53:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-05-15 03:53:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/programs/programs.php
INFO - 2018-05-15 03:53:36 --> Final output sent to browser
DEBUG - 2018-05-15 03:53:36 --> Total execution time: 0.5193
INFO - 2018-05-15 03:53:36 --> Config Class Initialized
INFO - 2018-05-15 03:53:36 --> Hooks Class Initialized
DEBUG - 2018-05-15 03:53:36 --> UTF-8 Support Enabled
INFO - 2018-05-15 03:53:36 --> Utf8 Class Initialized
INFO - 2018-05-15 03:53:36 --> URI Class Initialized
INFO - 2018-05-15 03:53:36 --> Router Class Initialized
INFO - 2018-05-15 03:53:36 --> Output Class Initialized
INFO - 2018-05-15 03:53:36 --> Security Class Initialized
DEBUG - 2018-05-15 03:53:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 03:53:36 --> Input Class Initialized
INFO - 2018-05-15 03:53:36 --> Language Class Initialized
INFO - 2018-05-15 03:53:36 --> Language Class Initialized
INFO - 2018-05-15 03:53:36 --> Config Class Initialized
INFO - 2018-05-15 03:53:36 --> Loader Class Initialized
DEBUG - 2018-05-15 03:53:36 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-15 03:53:36 --> Helper loaded: url_helper
INFO - 2018-05-15 03:53:36 --> Helper loaded: form_helper
INFO - 2018-05-15 03:53:36 --> Helper loaded: date_helper
INFO - 2018-05-15 03:53:36 --> Helper loaded: util_helper
INFO - 2018-05-15 03:53:36 --> Helper loaded: text_helper
INFO - 2018-05-15 03:53:37 --> Helper loaded: string_helper
INFO - 2018-05-15 03:53:37 --> Database Driver Class Initialized
DEBUG - 2018-05-15 03:53:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-15 03:53:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-15 03:53:37 --> Email Class Initialized
INFO - 2018-05-15 03:53:37 --> Controller Class Initialized
DEBUG - 2018-05-15 03:53:37 --> Programs MX_Controller Initialized
INFO - 2018-05-15 03:53:37 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-15 03:53:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-05-15 03:53:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-15 03:53:37 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-15 03:53:37 --> Login MX_Controller Initialized
DEBUG - 2018-05-15 03:53:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-15 03:53:37 --> Final output sent to browser
DEBUG - 2018-05-15 03:53:37 --> Total execution time: 0.5067
INFO - 2018-05-15 04:50:35 --> Config Class Initialized
INFO - 2018-05-15 04:50:35 --> Hooks Class Initialized
DEBUG - 2018-05-15 04:50:35 --> UTF-8 Support Enabled
INFO - 2018-05-15 04:50:35 --> Utf8 Class Initialized
INFO - 2018-05-15 04:50:35 --> URI Class Initialized
INFO - 2018-05-15 04:50:35 --> Router Class Initialized
INFO - 2018-05-15 04:50:35 --> Output Class Initialized
INFO - 2018-05-15 04:50:35 --> Security Class Initialized
DEBUG - 2018-05-15 04:50:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:50:35 --> Input Class Initialized
INFO - 2018-05-15 04:50:35 --> Language Class Initialized
INFO - 2018-05-15 04:50:35 --> Config Class Initialized
INFO - 2018-05-15 04:50:35 --> Config Class Initialized
INFO - 2018-05-15 04:50:35 --> Config Class Initialized
INFO - 2018-05-15 04:50:35 --> Hooks Class Initialized
INFO - 2018-05-15 04:50:35 --> Hooks Class Initialized
INFO - 2018-05-15 04:50:35 --> Hooks Class Initialized
ERROR - 2018-05-15 04:50:35 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:50:35 --> Config Class Initialized
DEBUG - 2018-05-15 04:50:35 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 04:50:35 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 04:50:35 --> UTF-8 Support Enabled
INFO - 2018-05-15 04:50:35 --> Config Class Initialized
INFO - 2018-05-15 04:50:35 --> Hooks Class Initialized
INFO - 2018-05-15 04:50:35 --> Hooks Class Initialized
INFO - 2018-05-15 04:50:35 --> Utf8 Class Initialized
INFO - 2018-05-15 04:50:35 --> Config Class Initialized
DEBUG - 2018-05-15 04:50:35 --> UTF-8 Support Enabled
INFO - 2018-05-15 04:50:35 --> Utf8 Class Initialized
INFO - 2018-05-15 04:50:35 --> Utf8 Class Initialized
DEBUG - 2018-05-15 04:50:35 --> UTF-8 Support Enabled
INFO - 2018-05-15 04:50:35 --> URI Class Initialized
INFO - 2018-05-15 04:50:35 --> Utf8 Class Initialized
INFO - 2018-05-15 04:50:35 --> URI Class Initialized
INFO - 2018-05-15 04:50:35 --> Hooks Class Initialized
INFO - 2018-05-15 04:50:35 --> URI Class Initialized
INFO - 2018-05-15 04:50:35 --> Utf8 Class Initialized
INFO - 2018-05-15 04:50:36 --> Router Class Initialized
INFO - 2018-05-15 04:50:36 --> Router Class Initialized
INFO - 2018-05-15 04:50:36 --> Output Class Initialized
INFO - 2018-05-15 04:50:36 --> Security Class Initialized
DEBUG - 2018-05-15 04:50:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:50:36 --> Input Class Initialized
INFO - 2018-05-15 04:50:36 --> URI Class Initialized
DEBUG - 2018-05-15 04:50:36 --> UTF-8 Support Enabled
INFO - 2018-05-15 04:50:36 --> Router Class Initialized
INFO - 2018-05-15 04:50:36 --> URI Class Initialized
INFO - 2018-05-15 04:50:36 --> Language Class Initialized
INFO - 2018-05-15 04:50:36 --> Output Class Initialized
INFO - 2018-05-15 04:50:36 --> Output Class Initialized
INFO - 2018-05-15 04:50:36 --> Router Class Initialized
INFO - 2018-05-15 04:50:36 --> Security Class Initialized
INFO - 2018-05-15 04:50:36 --> Output Class Initialized
DEBUG - 2018-05-15 04:50:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:50:36 --> Security Class Initialized
INFO - 2018-05-15 04:50:36 --> Security Class Initialized
ERROR - 2018-05-15 04:50:36 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:50:36 --> Utf8 Class Initialized
INFO - 2018-05-15 04:50:36 --> Router Class Initialized
INFO - 2018-05-15 04:50:36 --> Input Class Initialized
DEBUG - 2018-05-15 04:50:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-15 04:50:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:50:36 --> Language Class Initialized
INFO - 2018-05-15 04:50:36 --> URI Class Initialized
INFO - 2018-05-15 04:50:36 --> Output Class Initialized
INFO - 2018-05-15 04:50:36 --> Input Class Initialized
INFO - 2018-05-15 04:50:36 --> Config Class Initialized
INFO - 2018-05-15 04:50:36 --> Input Class Initialized
INFO - 2018-05-15 04:50:36 --> Security Class Initialized
INFO - 2018-05-15 04:50:36 --> Router Class Initialized
INFO - 2018-05-15 04:50:36 --> Hooks Class Initialized
INFO - 2018-05-15 04:50:36 --> Language Class Initialized
ERROR - 2018-05-15 04:50:36 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:50:36 --> Language Class Initialized
ERROR - 2018-05-15 04:50:36 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:50:36 --> Config Class Initialized
INFO - 2018-05-15 04:50:36 --> Config Class Initialized
ERROR - 2018-05-15 04:50:36 --> 404 Page Not Found: /index
DEBUG - 2018-05-15 04:50:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:50:36 --> Output Class Initialized
DEBUG - 2018-05-15 04:50:36 --> UTF-8 Support Enabled
INFO - 2018-05-15 04:50:36 --> Hooks Class Initialized
DEBUG - 2018-05-15 04:50:36 --> UTF-8 Support Enabled
INFO - 2018-05-15 04:50:36 --> Security Class Initialized
INFO - 2018-05-15 04:50:36 --> Utf8 Class Initialized
INFO - 2018-05-15 04:50:36 --> Hooks Class Initialized
INFO - 2018-05-15 04:50:36 --> Input Class Initialized
INFO - 2018-05-15 04:50:36 --> Utf8 Class Initialized
INFO - 2018-05-15 04:50:36 --> URI Class Initialized
INFO - 2018-05-15 04:50:36 --> URI Class Initialized
INFO - 2018-05-15 04:50:36 --> Language Class Initialized
DEBUG - 2018-05-15 04:50:36 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 04:50:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:50:36 --> Input Class Initialized
INFO - 2018-05-15 04:50:36 --> Utf8 Class Initialized
INFO - 2018-05-15 04:50:36 --> Router Class Initialized
INFO - 2018-05-15 04:50:36 --> Router Class Initialized
ERROR - 2018-05-15 04:50:36 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:50:36 --> Language Class Initialized
INFO - 2018-05-15 04:50:36 --> URI Class Initialized
INFO - 2018-05-15 04:50:36 --> Output Class Initialized
INFO - 2018-05-15 04:50:36 --> Output Class Initialized
ERROR - 2018-05-15 04:50:36 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:50:36 --> Config Class Initialized
INFO - 2018-05-15 04:50:36 --> Hooks Class Initialized
INFO - 2018-05-15 04:50:36 --> Router Class Initialized
DEBUG - 2018-05-15 04:50:36 --> UTF-8 Support Enabled
INFO - 2018-05-15 04:50:36 --> Output Class Initialized
INFO - 2018-05-15 04:50:36 --> Utf8 Class Initialized
INFO - 2018-05-15 04:50:36 --> Security Class Initialized
INFO - 2018-05-15 04:50:36 --> Security Class Initialized
INFO - 2018-05-15 04:50:36 --> Security Class Initialized
INFO - 2018-05-15 04:50:36 --> URI Class Initialized
DEBUG - 2018-05-15 04:50:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-15 04:50:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:50:36 --> Config Class Initialized
INFO - 2018-05-15 04:50:36 --> Input Class Initialized
DEBUG - 2018-05-15 04:50:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:50:36 --> Input Class Initialized
INFO - 2018-05-15 04:50:36 --> Input Class Initialized
INFO - 2018-05-15 04:50:36 --> Language Class Initialized
INFO - 2018-05-15 04:50:36 --> Hooks Class Initialized
INFO - 2018-05-15 04:50:36 --> Router Class Initialized
INFO - 2018-05-15 04:50:36 --> Language Class Initialized
INFO - 2018-05-15 04:50:36 --> Language Class Initialized
ERROR - 2018-05-15 04:50:36 --> 404 Page Not Found: /index
ERROR - 2018-05-15 04:50:36 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:50:36 --> Output Class Initialized
DEBUG - 2018-05-15 04:50:36 --> UTF-8 Support Enabled
INFO - 2018-05-15 04:50:36 --> Utf8 Class Initialized
ERROR - 2018-05-15 04:50:36 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:50:36 --> Security Class Initialized
DEBUG - 2018-05-15 04:50:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:50:36 --> URI Class Initialized
INFO - 2018-05-15 04:50:36 --> Input Class Initialized
INFO - 2018-05-15 04:50:36 --> Config Class Initialized
INFO - 2018-05-15 04:50:36 --> Config Class Initialized
INFO - 2018-05-15 04:50:36 --> Router Class Initialized
INFO - 2018-05-15 04:50:36 --> Hooks Class Initialized
INFO - 2018-05-15 04:50:36 --> Hooks Class Initialized
INFO - 2018-05-15 04:50:36 --> Language Class Initialized
INFO - 2018-05-15 04:50:36 --> Output Class Initialized
INFO - 2018-05-15 04:50:36 --> Config Class Initialized
INFO - 2018-05-15 04:50:36 --> Hooks Class Initialized
ERROR - 2018-05-15 04:50:36 --> 404 Page Not Found: /index
DEBUG - 2018-05-15 04:50:36 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 04:50:36 --> UTF-8 Support Enabled
INFO - 2018-05-15 04:50:36 --> Security Class Initialized
DEBUG - 2018-05-15 04:50:36 --> UTF-8 Support Enabled
INFO - 2018-05-15 04:50:36 --> Utf8 Class Initialized
INFO - 2018-05-15 04:50:36 --> Utf8 Class Initialized
INFO - 2018-05-15 04:50:36 --> Utf8 Class Initialized
DEBUG - 2018-05-15 04:50:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:50:36 --> URI Class Initialized
INFO - 2018-05-15 04:50:36 --> URI Class Initialized
INFO - 2018-05-15 04:50:36 --> URI Class Initialized
INFO - 2018-05-15 04:50:36 --> Input Class Initialized
INFO - 2018-05-15 04:50:36 --> Router Class Initialized
INFO - 2018-05-15 04:50:36 --> Router Class Initialized
INFO - 2018-05-15 04:50:36 --> Language Class Initialized
INFO - 2018-05-15 04:50:36 --> Output Class Initialized
INFO - 2018-05-15 04:50:36 --> Router Class Initialized
INFO - 2018-05-15 04:50:36 --> Security Class Initialized
INFO - 2018-05-15 04:50:36 --> Output Class Initialized
ERROR - 2018-05-15 04:50:36 --> 404 Page Not Found: /index
DEBUG - 2018-05-15 04:50:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:50:36 --> Security Class Initialized
INFO - 2018-05-15 04:50:36 --> Output Class Initialized
INFO - 2018-05-15 04:50:37 --> Config Class Initialized
INFO - 2018-05-15 04:50:37 --> Hooks Class Initialized
INFO - 2018-05-15 04:50:37 --> Input Class Initialized
INFO - 2018-05-15 04:50:37 --> Config Class Initialized
INFO - 2018-05-15 04:50:37 --> Security Class Initialized
DEBUG - 2018-05-15 04:50:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:50:37 --> Hooks Class Initialized
DEBUG - 2018-05-15 04:50:37 --> UTF-8 Support Enabled
INFO - 2018-05-15 04:50:37 --> Language Class Initialized
INFO - 2018-05-15 04:50:37 --> Input Class Initialized
DEBUG - 2018-05-15 04:50:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-15 04:50:37 --> UTF-8 Support Enabled
ERROR - 2018-05-15 04:50:37 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:50:37 --> Utf8 Class Initialized
INFO - 2018-05-15 04:50:37 --> Input Class Initialized
INFO - 2018-05-15 04:50:37 --> Language Class Initialized
INFO - 2018-05-15 04:50:37 --> Utf8 Class Initialized
ERROR - 2018-05-15 04:50:37 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:50:37 --> URI Class Initialized
INFO - 2018-05-15 04:50:37 --> Language Class Initialized
ERROR - 2018-05-15 04:50:37 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:50:37 --> URI Class Initialized
INFO - 2018-05-15 04:50:37 --> Router Class Initialized
INFO - 2018-05-15 04:50:37 --> Output Class Initialized
INFO - 2018-05-15 04:50:37 --> Security Class Initialized
DEBUG - 2018-05-15 04:50:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:50:37 --> Router Class Initialized
INFO - 2018-05-15 04:50:37 --> Input Class Initialized
INFO - 2018-05-15 04:50:37 --> Output Class Initialized
INFO - 2018-05-15 04:50:37 --> Language Class Initialized
INFO - 2018-05-15 04:50:37 --> Security Class Initialized
ERROR - 2018-05-15 04:50:37 --> 404 Page Not Found: /index
DEBUG - 2018-05-15 04:50:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:50:37 --> Input Class Initialized
INFO - 2018-05-15 04:50:37 --> Language Class Initialized
ERROR - 2018-05-15 04:50:37 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:50:40 --> Config Class Initialized
INFO - 2018-05-15 04:50:40 --> Config Class Initialized
INFO - 2018-05-15 04:50:40 --> Config Class Initialized
INFO - 2018-05-15 04:50:40 --> Config Class Initialized
INFO - 2018-05-15 04:50:40 --> Hooks Class Initialized
INFO - 2018-05-15 04:50:40 --> Hooks Class Initialized
INFO - 2018-05-15 04:50:40 --> Hooks Class Initialized
INFO - 2018-05-15 04:50:40 --> Hooks Class Initialized
INFO - 2018-05-15 04:50:40 --> Config Class Initialized
DEBUG - 2018-05-15 04:50:40 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 04:50:40 --> UTF-8 Support Enabled
INFO - 2018-05-15 04:50:40 --> Hooks Class Initialized
INFO - 2018-05-15 04:50:40 --> Utf8 Class Initialized
INFO - 2018-05-15 04:50:40 --> Utf8 Class Initialized
DEBUG - 2018-05-15 04:50:40 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 04:50:40 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 04:50:40 --> UTF-8 Support Enabled
INFO - 2018-05-15 04:50:40 --> Utf8 Class Initialized
INFO - 2018-05-15 04:50:40 --> URI Class Initialized
INFO - 2018-05-15 04:50:40 --> URI Class Initialized
INFO - 2018-05-15 04:50:40 --> Router Class Initialized
INFO - 2018-05-15 04:50:40 --> URI Class Initialized
INFO - 2018-05-15 04:50:40 --> Utf8 Class Initialized
INFO - 2018-05-15 04:50:40 --> Utf8 Class Initialized
INFO - 2018-05-15 04:50:40 --> Output Class Initialized
INFO - 2018-05-15 04:50:40 --> Router Class Initialized
INFO - 2018-05-15 04:50:40 --> Output Class Initialized
INFO - 2018-05-15 04:50:40 --> Security Class Initialized
INFO - 2018-05-15 04:50:40 --> Router Class Initialized
INFO - 2018-05-15 04:50:40 --> URI Class Initialized
INFO - 2018-05-15 04:50:40 --> URI Class Initialized
INFO - 2018-05-15 04:50:40 --> Security Class Initialized
DEBUG - 2018-05-15 04:50:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:50:40 --> Router Class Initialized
INFO - 2018-05-15 04:50:40 --> Router Class Initialized
INFO - 2018-05-15 04:50:40 --> Output Class Initialized
INFO - 2018-05-15 04:50:40 --> Input Class Initialized
INFO - 2018-05-15 04:50:40 --> Output Class Initialized
INFO - 2018-05-15 04:50:40 --> Output Class Initialized
INFO - 2018-05-15 04:50:40 --> Security Class Initialized
DEBUG - 2018-05-15 04:50:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:50:40 --> Language Class Initialized
ERROR - 2018-05-15 04:50:40 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:50:40 --> Config Class Initialized
INFO - 2018-05-15 04:50:40 --> Hooks Class Initialized
DEBUG - 2018-05-15 04:50:40 --> UTF-8 Support Enabled
INFO - 2018-05-15 04:50:40 --> Utf8 Class Initialized
INFO - 2018-05-15 04:50:40 --> Input Class Initialized
INFO - 2018-05-15 04:50:40 --> URI Class Initialized
DEBUG - 2018-05-15 04:50:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:50:40 --> Security Class Initialized
INFO - 2018-05-15 04:50:40 --> Security Class Initialized
INFO - 2018-05-15 04:50:40 --> Input Class Initialized
INFO - 2018-05-15 04:50:40 --> Router Class Initialized
INFO - 2018-05-15 04:50:40 --> Language Class Initialized
DEBUG - 2018-05-15 04:50:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-15 04:50:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:50:40 --> Language Class Initialized
INFO - 2018-05-15 04:50:40 --> Output Class Initialized
INFO - 2018-05-15 04:50:40 --> Input Class Initialized
ERROR - 2018-05-15 04:50:40 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:50:40 --> Input Class Initialized
ERROR - 2018-05-15 04:50:40 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:50:40 --> Security Class Initialized
INFO - 2018-05-15 04:50:40 --> Config Class Initialized
INFO - 2018-05-15 04:50:40 --> Language Class Initialized
INFO - 2018-05-15 04:50:40 --> Hooks Class Initialized
INFO - 2018-05-15 04:50:40 --> Config Class Initialized
INFO - 2018-05-15 04:50:40 --> Language Class Initialized
DEBUG - 2018-05-15 04:50:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-05-15 04:50:40 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:50:41 --> Hooks Class Initialized
DEBUG - 2018-05-15 04:50:41 --> UTF-8 Support Enabled
INFO - 2018-05-15 04:50:41 --> Utf8 Class Initialized
DEBUG - 2018-05-15 04:50:41 --> UTF-8 Support Enabled
INFO - 2018-05-15 04:50:41 --> Utf8 Class Initialized
INFO - 2018-05-15 04:50:41 --> URI Class Initialized
INFO - 2018-05-15 04:50:41 --> Input Class Initialized
ERROR - 2018-05-15 04:50:41 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:50:41 --> URI Class Initialized
INFO - 2018-05-15 04:50:41 --> Language Class Initialized
INFO - 2018-05-15 04:50:41 --> Config Class Initialized
INFO - 2018-05-15 04:50:41 --> Router Class Initialized
INFO - 2018-05-15 04:50:41 --> Hooks Class Initialized
ERROR - 2018-05-15 04:50:41 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:50:41 --> Output Class Initialized
INFO - 2018-05-15 04:50:41 --> Router Class Initialized
DEBUG - 2018-05-15 04:50:41 --> UTF-8 Support Enabled
INFO - 2018-05-15 04:50:41 --> Output Class Initialized
INFO - 2018-05-15 04:50:41 --> Security Class Initialized
INFO - 2018-05-15 04:50:41 --> Config Class Initialized
INFO - 2018-05-15 04:50:41 --> Utf8 Class Initialized
DEBUG - 2018-05-15 04:50:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:50:41 --> Security Class Initialized
INFO - 2018-05-15 04:50:41 --> Hooks Class Initialized
INFO - 2018-05-15 04:50:41 --> URI Class Initialized
INFO - 2018-05-15 04:50:41 --> Router Class Initialized
INFO - 2018-05-15 04:50:41 --> Output Class Initialized
INFO - 2018-05-15 04:50:41 --> Security Class Initialized
DEBUG - 2018-05-15 04:50:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:50:41 --> Input Class Initialized
INFO - 2018-05-15 04:50:41 --> Language Class Initialized
ERROR - 2018-05-15 04:50:41 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:50:41 --> Input Class Initialized
DEBUG - 2018-05-15 04:50:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-15 04:50:41 --> UTF-8 Support Enabled
INFO - 2018-05-15 04:50:41 --> Config Class Initialized
INFO - 2018-05-15 04:50:41 --> Hooks Class Initialized
INFO - 2018-05-15 04:50:41 --> Language Class Initialized
INFO - 2018-05-15 04:50:41 --> Utf8 Class Initialized
INFO - 2018-05-15 04:50:41 --> Input Class Initialized
DEBUG - 2018-05-15 04:50:41 --> UTF-8 Support Enabled
INFO - 2018-05-15 04:50:41 --> Utf8 Class Initialized
INFO - 2018-05-15 04:50:41 --> URI Class Initialized
INFO - 2018-05-15 04:50:41 --> Language Class Initialized
ERROR - 2018-05-15 04:50:41 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:50:41 --> URI Class Initialized
INFO - 2018-05-15 04:50:41 --> Router Class Initialized
INFO - 2018-05-15 04:50:41 --> Output Class Initialized
ERROR - 2018-05-15 04:50:41 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:50:41 --> Router Class Initialized
INFO - 2018-05-15 04:50:41 --> Config Class Initialized
INFO - 2018-05-15 04:50:41 --> Hooks Class Initialized
INFO - 2018-05-15 04:50:41 --> Security Class Initialized
INFO - 2018-05-15 04:50:41 --> Output Class Initialized
INFO - 2018-05-15 04:50:41 --> Config Class Initialized
INFO - 2018-05-15 04:50:41 --> Hooks Class Initialized
DEBUG - 2018-05-15 04:50:41 --> UTF-8 Support Enabled
INFO - 2018-05-15 04:50:41 --> Security Class Initialized
DEBUG - 2018-05-15 04:50:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:50:41 --> Utf8 Class Initialized
DEBUG - 2018-05-15 04:50:41 --> UTF-8 Support Enabled
INFO - 2018-05-15 04:50:41 --> Input Class Initialized
DEBUG - 2018-05-15 04:50:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:50:41 --> URI Class Initialized
INFO - 2018-05-15 04:50:41 --> Utf8 Class Initialized
INFO - 2018-05-15 04:50:41 --> Input Class Initialized
INFO - 2018-05-15 04:50:41 --> Language Class Initialized
ERROR - 2018-05-15 04:50:41 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:50:41 --> URI Class Initialized
INFO - 2018-05-15 04:50:41 --> Router Class Initialized
INFO - 2018-05-15 04:50:41 --> Language Class Initialized
ERROR - 2018-05-15 04:50:41 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:50:41 --> Output Class Initialized
INFO - 2018-05-15 04:50:41 --> Router Class Initialized
INFO - 2018-05-15 04:50:41 --> Security Class Initialized
INFO - 2018-05-15 04:50:41 --> Output Class Initialized
DEBUG - 2018-05-15 04:50:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:50:41 --> Input Class Initialized
INFO - 2018-05-15 04:50:41 --> Language Class Initialized
INFO - 2018-05-15 04:50:41 --> Security Class Initialized
ERROR - 2018-05-15 04:50:41 --> 404 Page Not Found: /index
DEBUG - 2018-05-15 04:50:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:50:41 --> Input Class Initialized
INFO - 2018-05-15 04:50:41 --> Language Class Initialized
ERROR - 2018-05-15 04:50:41 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:50:49 --> Config Class Initialized
INFO - 2018-05-15 04:50:49 --> Config Class Initialized
INFO - 2018-05-15 04:50:49 --> Config Class Initialized
INFO - 2018-05-15 04:50:49 --> Config Class Initialized
INFO - 2018-05-15 04:50:49 --> Config Class Initialized
INFO - 2018-05-15 04:50:49 --> Hooks Class Initialized
INFO - 2018-05-15 04:50:49 --> Hooks Class Initialized
INFO - 2018-05-15 04:50:49 --> Hooks Class Initialized
INFO - 2018-05-15 04:50:49 --> Hooks Class Initialized
INFO - 2018-05-15 04:50:49 --> Hooks Class Initialized
DEBUG - 2018-05-15 04:50:49 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 04:50:49 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 04:50:49 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 04:50:49 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 04:50:49 --> UTF-8 Support Enabled
INFO - 2018-05-15 04:50:49 --> Utf8 Class Initialized
INFO - 2018-05-15 04:50:49 --> Utf8 Class Initialized
INFO - 2018-05-15 04:50:49 --> Utf8 Class Initialized
INFO - 2018-05-15 04:50:49 --> Utf8 Class Initialized
INFO - 2018-05-15 04:50:49 --> Utf8 Class Initialized
INFO - 2018-05-15 04:50:49 --> URI Class Initialized
INFO - 2018-05-15 04:50:49 --> URI Class Initialized
INFO - 2018-05-15 04:50:49 --> Router Class Initialized
INFO - 2018-05-15 04:50:49 --> URI Class Initialized
INFO - 2018-05-15 04:50:49 --> URI Class Initialized
INFO - 2018-05-15 04:50:49 --> Router Class Initialized
INFO - 2018-05-15 04:50:49 --> URI Class Initialized
INFO - 2018-05-15 04:50:49 --> Output Class Initialized
INFO - 2018-05-15 04:50:49 --> Router Class Initialized
INFO - 2018-05-15 04:50:49 --> Output Class Initialized
INFO - 2018-05-15 04:50:49 --> Router Class Initialized
INFO - 2018-05-15 04:50:49 --> Router Class Initialized
INFO - 2018-05-15 04:50:49 --> Output Class Initialized
INFO - 2018-05-15 04:50:49 --> Security Class Initialized
INFO - 2018-05-15 04:50:49 --> Output Class Initialized
INFO - 2018-05-15 04:50:49 --> Security Class Initialized
INFO - 2018-05-15 04:50:49 --> Output Class Initialized
DEBUG - 2018-05-15 04:50:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:50:49 --> Security Class Initialized
DEBUG - 2018-05-15 04:50:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:50:49 --> Security Class Initialized
INFO - 2018-05-15 04:50:49 --> Security Class Initialized
INFO - 2018-05-15 04:50:49 --> Input Class Initialized
INFO - 2018-05-15 04:50:49 --> Language Class Initialized
ERROR - 2018-05-15 04:50:49 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:50:50 --> Config Class Initialized
DEBUG - 2018-05-15 04:50:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:50:50 --> Input Class Initialized
DEBUG - 2018-05-15 04:50:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-15 04:50:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:50:50 --> Hooks Class Initialized
DEBUG - 2018-05-15 04:50:50 --> UTF-8 Support Enabled
INFO - 2018-05-15 04:50:50 --> Input Class Initialized
INFO - 2018-05-15 04:50:50 --> Input Class Initialized
INFO - 2018-05-15 04:50:50 --> Language Class Initialized
INFO - 2018-05-15 04:50:50 --> Input Class Initialized
INFO - 2018-05-15 04:50:50 --> Utf8 Class Initialized
INFO - 2018-05-15 04:50:50 --> URI Class Initialized
ERROR - 2018-05-15 04:50:50 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:50:50 --> Language Class Initialized
INFO - 2018-05-15 04:50:50 --> Language Class Initialized
INFO - 2018-05-15 04:50:50 --> Language Class Initialized
ERROR - 2018-05-15 04:50:50 --> 404 Page Not Found: /index
ERROR - 2018-05-15 04:50:50 --> 404 Page Not Found: /index
ERROR - 2018-05-15 04:50:50 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:50:50 --> Router Class Initialized
INFO - 2018-05-15 04:50:50 --> Config Class Initialized
INFO - 2018-05-15 04:50:50 --> Hooks Class Initialized
INFO - 2018-05-15 04:50:50 --> Output Class Initialized
DEBUG - 2018-05-15 04:50:50 --> UTF-8 Support Enabled
INFO - 2018-05-15 04:50:50 --> Config Class Initialized
INFO - 2018-05-15 04:50:50 --> Config Class Initialized
INFO - 2018-05-15 04:50:50 --> Hooks Class Initialized
INFO - 2018-05-15 04:50:50 --> Hooks Class Initialized
INFO - 2018-05-15 04:50:50 --> Security Class Initialized
INFO - 2018-05-15 04:50:50 --> Utf8 Class Initialized
DEBUG - 2018-05-15 04:50:50 --> UTF-8 Support Enabled
INFO - 2018-05-15 04:50:50 --> URI Class Initialized
DEBUG - 2018-05-15 04:50:50 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 04:50:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:50:50 --> Utf8 Class Initialized
INFO - 2018-05-15 04:50:50 --> Utf8 Class Initialized
INFO - 2018-05-15 04:50:50 --> Router Class Initialized
INFO - 2018-05-15 04:50:50 --> Input Class Initialized
INFO - 2018-05-15 04:50:50 --> Output Class Initialized
INFO - 2018-05-15 04:50:50 --> URI Class Initialized
INFO - 2018-05-15 04:50:50 --> URI Class Initialized
INFO - 2018-05-15 04:50:50 --> Router Class Initialized
INFO - 2018-05-15 04:50:50 --> Language Class Initialized
INFO - 2018-05-15 04:50:50 --> Router Class Initialized
INFO - 2018-05-15 04:50:50 --> Security Class Initialized
DEBUG - 2018-05-15 04:50:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:50:50 --> Output Class Initialized
ERROR - 2018-05-15 04:50:50 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:50:50 --> Output Class Initialized
INFO - 2018-05-15 04:50:50 --> Input Class Initialized
INFO - 2018-05-15 04:50:50 --> Security Class Initialized
INFO - 2018-05-15 04:50:50 --> Security Class Initialized
INFO - 2018-05-15 04:50:50 --> Config Class Initialized
INFO - 2018-05-15 04:50:50 --> Hooks Class Initialized
INFO - 2018-05-15 04:50:50 --> Language Class Initialized
DEBUG - 2018-05-15 04:50:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-15 04:50:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-05-15 04:50:50 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:50:50 --> Input Class Initialized
INFO - 2018-05-15 04:50:50 --> Input Class Initialized
DEBUG - 2018-05-15 04:50:50 --> UTF-8 Support Enabled
INFO - 2018-05-15 04:50:50 --> Language Class Initialized
INFO - 2018-05-15 04:50:50 --> Language Class Initialized
INFO - 2018-05-15 04:50:50 --> Utf8 Class Initialized
INFO - 2018-05-15 04:50:50 --> Config Class Initialized
ERROR - 2018-05-15 04:50:50 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:50:50 --> Hooks Class Initialized
ERROR - 2018-05-15 04:50:50 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:50:50 --> URI Class Initialized
DEBUG - 2018-05-15 04:50:50 --> UTF-8 Support Enabled
INFO - 2018-05-15 04:50:50 --> Config Class Initialized
INFO - 2018-05-15 04:50:50 --> Router Class Initialized
INFO - 2018-05-15 04:50:50 --> Config Class Initialized
INFO - 2018-05-15 04:50:50 --> Hooks Class Initialized
INFO - 2018-05-15 04:50:50 --> Hooks Class Initialized
INFO - 2018-05-15 04:50:50 --> Utf8 Class Initialized
INFO - 2018-05-15 04:50:50 --> Output Class Initialized
DEBUG - 2018-05-15 04:50:50 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 04:50:50 --> UTF-8 Support Enabled
INFO - 2018-05-15 04:50:50 --> Security Class Initialized
INFO - 2018-05-15 04:50:50 --> URI Class Initialized
INFO - 2018-05-15 04:50:50 --> Utf8 Class Initialized
INFO - 2018-05-15 04:50:50 --> Utf8 Class Initialized
DEBUG - 2018-05-15 04:50:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:50:50 --> Router Class Initialized
INFO - 2018-05-15 04:50:50 --> URI Class Initialized
INFO - 2018-05-15 04:50:50 --> Input Class Initialized
INFO - 2018-05-15 04:50:50 --> URI Class Initialized
INFO - 2018-05-15 04:50:50 --> Output Class Initialized
INFO - 2018-05-15 04:50:50 --> Router Class Initialized
INFO - 2018-05-15 04:50:50 --> Language Class Initialized
INFO - 2018-05-15 04:50:50 --> Router Class Initialized
INFO - 2018-05-15 04:50:50 --> Security Class Initialized
ERROR - 2018-05-15 04:50:50 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:50:50 --> Output Class Initialized
INFO - 2018-05-15 04:50:50 --> Output Class Initialized
DEBUG - 2018-05-15 04:50:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:50:50 --> Security Class Initialized
INFO - 2018-05-15 04:50:50 --> Security Class Initialized
INFO - 2018-05-15 04:50:50 --> Input Class Initialized
DEBUG - 2018-05-15 04:50:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:50:50 --> Input Class Initialized
INFO - 2018-05-15 04:50:50 --> Language Class Initialized
DEBUG - 2018-05-15 04:50:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-05-15 04:50:50 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:50:50 --> Input Class Initialized
INFO - 2018-05-15 04:50:50 --> Language Class Initialized
ERROR - 2018-05-15 04:50:50 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:50:50 --> Language Class Initialized
ERROR - 2018-05-15 04:50:50 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:50:57 --> Config Class Initialized
INFO - 2018-05-15 04:50:57 --> Config Class Initialized
INFO - 2018-05-15 04:50:57 --> Config Class Initialized
INFO - 2018-05-15 04:50:57 --> Config Class Initialized
INFO - 2018-05-15 04:50:57 --> Config Class Initialized
INFO - 2018-05-15 04:50:57 --> Hooks Class Initialized
INFO - 2018-05-15 04:50:57 --> Hooks Class Initialized
INFO - 2018-05-15 04:50:57 --> Hooks Class Initialized
INFO - 2018-05-15 04:50:57 --> Hooks Class Initialized
INFO - 2018-05-15 04:50:57 --> Hooks Class Initialized
DEBUG - 2018-05-15 04:50:57 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 04:50:57 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 04:50:57 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 04:50:57 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 04:50:57 --> UTF-8 Support Enabled
INFO - 2018-05-15 04:50:57 --> Utf8 Class Initialized
INFO - 2018-05-15 04:50:57 --> Utf8 Class Initialized
INFO - 2018-05-15 04:50:57 --> Utf8 Class Initialized
INFO - 2018-05-15 04:50:57 --> Utf8 Class Initialized
INFO - 2018-05-15 04:50:57 --> Utf8 Class Initialized
INFO - 2018-05-15 04:50:57 --> URI Class Initialized
INFO - 2018-05-15 04:50:57 --> URI Class Initialized
INFO - 2018-05-15 04:50:58 --> URI Class Initialized
INFO - 2018-05-15 04:50:58 --> URI Class Initialized
INFO - 2018-05-15 04:50:58 --> URI Class Initialized
INFO - 2018-05-15 04:50:58 --> Router Class Initialized
INFO - 2018-05-15 04:50:58 --> Router Class Initialized
INFO - 2018-05-15 04:50:58 --> Output Class Initialized
INFO - 2018-05-15 04:50:58 --> Security Class Initialized
INFO - 2018-05-15 04:50:58 --> Router Class Initialized
DEBUG - 2018-05-15 04:50:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:50:58 --> Router Class Initialized
INFO - 2018-05-15 04:50:58 --> Router Class Initialized
INFO - 2018-05-15 04:50:58 --> Output Class Initialized
INFO - 2018-05-15 04:50:58 --> Output Class Initialized
INFO - 2018-05-15 04:50:58 --> Security Class Initialized
INFO - 2018-05-15 04:50:58 --> Output Class Initialized
INFO - 2018-05-15 04:50:58 --> Output Class Initialized
INFO - 2018-05-15 04:50:58 --> Input Class Initialized
INFO - 2018-05-15 04:50:58 --> Security Class Initialized
DEBUG - 2018-05-15 04:50:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:50:58 --> Input Class Initialized
INFO - 2018-05-15 04:50:58 --> Language Class Initialized
DEBUG - 2018-05-15 04:50:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:50:58 --> Security Class Initialized
ERROR - 2018-05-15 04:50:58 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:50:58 --> Language Class Initialized
INFO - 2018-05-15 04:50:58 --> Input Class Initialized
INFO - 2018-05-15 04:50:58 --> Security Class Initialized
DEBUG - 2018-05-15 04:50:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:50:58 --> Language Class Initialized
ERROR - 2018-05-15 04:50:58 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:50:58 --> Input Class Initialized
INFO - 2018-05-15 04:50:58 --> Config Class Initialized
DEBUG - 2018-05-15 04:50:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-05-15 04:50:58 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:50:58 --> Hooks Class Initialized
INFO - 2018-05-15 04:50:58 --> Input Class Initialized
INFO - 2018-05-15 04:50:58 --> Language Class Initialized
INFO - 2018-05-15 04:50:58 --> Config Class Initialized
INFO - 2018-05-15 04:50:58 --> Hooks Class Initialized
DEBUG - 2018-05-15 04:50:58 --> UTF-8 Support Enabled
INFO - 2018-05-15 04:50:58 --> Config Class Initialized
INFO - 2018-05-15 04:50:58 --> Utf8 Class Initialized
INFO - 2018-05-15 04:50:58 --> Hooks Class Initialized
INFO - 2018-05-15 04:50:58 --> URI Class Initialized
DEBUG - 2018-05-15 04:50:58 --> UTF-8 Support Enabled
INFO - 2018-05-15 04:50:58 --> Language Class Initialized
ERROR - 2018-05-15 04:50:58 --> 404 Page Not Found: /index
DEBUG - 2018-05-15 04:50:58 --> UTF-8 Support Enabled
INFO - 2018-05-15 04:50:58 --> Router Class Initialized
ERROR - 2018-05-15 04:50:58 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:50:58 --> Utf8 Class Initialized
INFO - 2018-05-15 04:50:58 --> Config Class Initialized
INFO - 2018-05-15 04:50:58 --> Hooks Class Initialized
INFO - 2018-05-15 04:50:58 --> Utf8 Class Initialized
INFO - 2018-05-15 04:50:58 --> Output Class Initialized
INFO - 2018-05-15 04:50:58 --> URI Class Initialized
INFO - 2018-05-15 04:50:58 --> URI Class Initialized
INFO - 2018-05-15 04:50:58 --> Security Class Initialized
DEBUG - 2018-05-15 04:50:58 --> UTF-8 Support Enabled
INFO - 2018-05-15 04:50:58 --> Router Class Initialized
DEBUG - 2018-05-15 04:50:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:50:58 --> Utf8 Class Initialized
INFO - 2018-05-15 04:50:58 --> Router Class Initialized
INFO - 2018-05-15 04:50:58 --> Output Class Initialized
INFO - 2018-05-15 04:50:58 --> Input Class Initialized
INFO - 2018-05-15 04:50:58 --> URI Class Initialized
INFO - 2018-05-15 04:50:58 --> Security Class Initialized
INFO - 2018-05-15 04:50:58 --> Output Class Initialized
INFO - 2018-05-15 04:50:58 --> Router Class Initialized
INFO - 2018-05-15 04:50:58 --> Language Class Initialized
DEBUG - 2018-05-15 04:50:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:50:58 --> Security Class Initialized
INFO - 2018-05-15 04:50:58 --> Output Class Initialized
INFO - 2018-05-15 04:50:58 --> Input Class Initialized
ERROR - 2018-05-15 04:50:58 --> 404 Page Not Found: /index
DEBUG - 2018-05-15 04:50:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:50:58 --> Input Class Initialized
INFO - 2018-05-15 04:50:58 --> Language Class Initialized
INFO - 2018-05-15 04:50:58 --> Security Class Initialized
INFO - 2018-05-15 04:50:58 --> Config Class Initialized
INFO - 2018-05-15 04:50:58 --> Hooks Class Initialized
DEBUG - 2018-05-15 04:50:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:50:58 --> Language Class Initialized
ERROR - 2018-05-15 04:50:58 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:50:58 --> Input Class Initialized
ERROR - 2018-05-15 04:50:58 --> 404 Page Not Found: /index
DEBUG - 2018-05-15 04:50:58 --> UTF-8 Support Enabled
INFO - 2018-05-15 04:50:58 --> Config Class Initialized
INFO - 2018-05-15 04:50:58 --> Utf8 Class Initialized
INFO - 2018-05-15 04:50:58 --> Hooks Class Initialized
INFO - 2018-05-15 04:50:58 --> Language Class Initialized
ERROR - 2018-05-15 04:50:58 --> 404 Page Not Found: /index
DEBUG - 2018-05-15 04:50:58 --> UTF-8 Support Enabled
INFO - 2018-05-15 04:50:58 --> URI Class Initialized
INFO - 2018-05-15 04:50:58 --> Config Class Initialized
INFO - 2018-05-15 04:50:58 --> Hooks Class Initialized
INFO - 2018-05-15 04:50:58 --> Utf8 Class Initialized
INFO - 2018-05-15 04:50:58 --> Router Class Initialized
INFO - 2018-05-15 04:50:58 --> Config Class Initialized
INFO - 2018-05-15 04:50:58 --> Hooks Class Initialized
DEBUG - 2018-05-15 04:50:58 --> UTF-8 Support Enabled
INFO - 2018-05-15 04:50:58 --> Output Class Initialized
INFO - 2018-05-15 04:50:58 --> URI Class Initialized
DEBUG - 2018-05-15 04:50:58 --> UTF-8 Support Enabled
INFO - 2018-05-15 04:50:58 --> Utf8 Class Initialized
INFO - 2018-05-15 04:50:58 --> Utf8 Class Initialized
INFO - 2018-05-15 04:50:58 --> Security Class Initialized
INFO - 2018-05-15 04:50:58 --> Router Class Initialized
INFO - 2018-05-15 04:50:58 --> URI Class Initialized
DEBUG - 2018-05-15 04:50:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:50:58 --> URI Class Initialized
INFO - 2018-05-15 04:50:58 --> Output Class Initialized
INFO - 2018-05-15 04:50:58 --> Security Class Initialized
INFO - 2018-05-15 04:50:58 --> Input Class Initialized
INFO - 2018-05-15 04:50:58 --> Router Class Initialized
INFO - 2018-05-15 04:50:58 --> Router Class Initialized
INFO - 2018-05-15 04:50:58 --> Output Class Initialized
INFO - 2018-05-15 04:50:58 --> Language Class Initialized
INFO - 2018-05-15 04:50:58 --> Output Class Initialized
DEBUG - 2018-05-15 04:50:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:50:58 --> Input Class Initialized
INFO - 2018-05-15 04:50:58 --> Security Class Initialized
ERROR - 2018-05-15 04:50:58 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:50:58 --> Security Class Initialized
INFO - 2018-05-15 04:50:58 --> Language Class Initialized
DEBUG - 2018-05-15 04:50:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-15 04:50:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-05-15 04:50:58 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:50:58 --> Input Class Initialized
INFO - 2018-05-15 04:50:58 --> Input Class Initialized
INFO - 2018-05-15 04:50:58 --> Language Class Initialized
INFO - 2018-05-15 04:50:58 --> Language Class Initialized
ERROR - 2018-05-15 04:50:58 --> 404 Page Not Found: /index
ERROR - 2018-05-15 04:50:58 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:51:01 --> Config Class Initialized
INFO - 2018-05-15 04:51:01 --> Config Class Initialized
INFO - 2018-05-15 04:51:01 --> Config Class Initialized
INFO - 2018-05-15 04:51:01 --> Config Class Initialized
INFO - 2018-05-15 04:51:01 --> Config Class Initialized
INFO - 2018-05-15 04:51:01 --> Hooks Class Initialized
INFO - 2018-05-15 04:51:01 --> Hooks Class Initialized
INFO - 2018-05-15 04:51:01 --> Hooks Class Initialized
INFO - 2018-05-15 04:51:01 --> Hooks Class Initialized
INFO - 2018-05-15 04:51:01 --> Hooks Class Initialized
DEBUG - 2018-05-15 04:51:01 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 04:51:01 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 04:51:01 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 04:51:01 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 04:51:01 --> UTF-8 Support Enabled
INFO - 2018-05-15 04:51:01 --> Utf8 Class Initialized
INFO - 2018-05-15 04:51:01 --> Utf8 Class Initialized
INFO - 2018-05-15 04:51:01 --> Utf8 Class Initialized
INFO - 2018-05-15 04:51:01 --> Utf8 Class Initialized
INFO - 2018-05-15 04:51:01 --> Utf8 Class Initialized
INFO - 2018-05-15 04:51:01 --> URI Class Initialized
INFO - 2018-05-15 04:51:01 --> URI Class Initialized
INFO - 2018-05-15 04:51:01 --> URI Class Initialized
INFO - 2018-05-15 04:51:01 --> URI Class Initialized
INFO - 2018-05-15 04:51:01 --> URI Class Initialized
INFO - 2018-05-15 04:51:01 --> Router Class Initialized
INFO - 2018-05-15 04:51:01 --> Router Class Initialized
INFO - 2018-05-15 04:51:01 --> Router Class Initialized
INFO - 2018-05-15 04:51:01 --> Router Class Initialized
INFO - 2018-05-15 04:51:01 --> Router Class Initialized
INFO - 2018-05-15 04:51:01 --> Output Class Initialized
INFO - 2018-05-15 04:51:01 --> Output Class Initialized
INFO - 2018-05-15 04:51:01 --> Output Class Initialized
INFO - 2018-05-15 04:51:01 --> Output Class Initialized
INFO - 2018-05-15 04:51:01 --> Output Class Initialized
INFO - 2018-05-15 04:51:01 --> Security Class Initialized
INFO - 2018-05-15 04:51:01 --> Security Class Initialized
INFO - 2018-05-15 04:51:01 --> Security Class Initialized
INFO - 2018-05-15 04:51:01 --> Security Class Initialized
INFO - 2018-05-15 04:51:01 --> Security Class Initialized
DEBUG - 2018-05-15 04:51:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-15 04:51:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-15 04:51:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-15 04:51:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-15 04:51:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:51:01 --> Input Class Initialized
INFO - 2018-05-15 04:51:01 --> Input Class Initialized
INFO - 2018-05-15 04:51:01 --> Input Class Initialized
INFO - 2018-05-15 04:51:01 --> Input Class Initialized
INFO - 2018-05-15 04:51:01 --> Input Class Initialized
INFO - 2018-05-15 04:51:01 --> Language Class Initialized
INFO - 2018-05-15 04:51:01 --> Language Class Initialized
INFO - 2018-05-15 04:51:01 --> Language Class Initialized
INFO - 2018-05-15 04:51:01 --> Language Class Initialized
INFO - 2018-05-15 04:51:01 --> Language Class Initialized
ERROR - 2018-05-15 04:51:01 --> 404 Page Not Found: /index
ERROR - 2018-05-15 04:51:01 --> 404 Page Not Found: /index
ERROR - 2018-05-15 04:51:01 --> 404 Page Not Found: /index
ERROR - 2018-05-15 04:51:01 --> 404 Page Not Found: /index
ERROR - 2018-05-15 04:51:01 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:51:01 --> Config Class Initialized
INFO - 2018-05-15 04:51:01 --> Config Class Initialized
INFO - 2018-05-15 04:51:01 --> Config Class Initialized
INFO - 2018-05-15 04:51:01 --> Config Class Initialized
INFO - 2018-05-15 04:51:01 --> Hooks Class Initialized
INFO - 2018-05-15 04:51:01 --> Hooks Class Initialized
INFO - 2018-05-15 04:51:01 --> Hooks Class Initialized
INFO - 2018-05-15 04:51:01 --> Hooks Class Initialized
DEBUG - 2018-05-15 04:51:01 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 04:51:01 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 04:51:01 --> UTF-8 Support Enabled
INFO - 2018-05-15 04:51:01 --> Utf8 Class Initialized
DEBUG - 2018-05-15 04:51:01 --> UTF-8 Support Enabled
INFO - 2018-05-15 04:51:01 --> Utf8 Class Initialized
INFO - 2018-05-15 04:51:01 --> Utf8 Class Initialized
INFO - 2018-05-15 04:51:01 --> Utf8 Class Initialized
INFO - 2018-05-15 04:51:01 --> URI Class Initialized
INFO - 2018-05-15 04:51:01 --> URI Class Initialized
INFO - 2018-05-15 04:51:01 --> URI Class Initialized
INFO - 2018-05-15 04:51:01 --> URI Class Initialized
INFO - 2018-05-15 04:51:01 --> Router Class Initialized
INFO - 2018-05-15 04:51:01 --> Router Class Initialized
INFO - 2018-05-15 04:51:01 --> Output Class Initialized
INFO - 2018-05-15 04:51:01 --> Output Class Initialized
INFO - 2018-05-15 04:51:01 --> Router Class Initialized
INFO - 2018-05-15 04:51:01 --> Router Class Initialized
INFO - 2018-05-15 04:51:01 --> Output Class Initialized
INFO - 2018-05-15 04:51:01 --> Security Class Initialized
INFO - 2018-05-15 04:51:01 --> Output Class Initialized
INFO - 2018-05-15 04:51:01 --> Security Class Initialized
DEBUG - 2018-05-15 04:51:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-15 04:51:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:51:01 --> Security Class Initialized
INFO - 2018-05-15 04:51:01 --> Security Class Initialized
INFO - 2018-05-15 04:51:01 --> Input Class Initialized
DEBUG - 2018-05-15 04:51:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:51:01 --> Input Class Initialized
DEBUG - 2018-05-15 04:51:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:51:02 --> Language Class Initialized
INFO - 2018-05-15 04:51:02 --> Input Class Initialized
INFO - 2018-05-15 04:51:02 --> Input Class Initialized
INFO - 2018-05-15 04:51:02 --> Language Class Initialized
ERROR - 2018-05-15 04:51:02 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:51:02 --> Language Class Initialized
INFO - 2018-05-15 04:51:02 --> Language Class Initialized
ERROR - 2018-05-15 04:51:02 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:51:02 --> Config Class Initialized
INFO - 2018-05-15 04:51:02 --> Config Class Initialized
ERROR - 2018-05-15 04:51:02 --> 404 Page Not Found: /index
ERROR - 2018-05-15 04:51:02 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:51:02 --> Hooks Class Initialized
INFO - 2018-05-15 04:51:02 --> Hooks Class Initialized
INFO - 2018-05-15 04:51:02 --> Config Class Initialized
INFO - 2018-05-15 04:51:02 --> Config Class Initialized
INFO - 2018-05-15 04:51:02 --> Hooks Class Initialized
INFO - 2018-05-15 04:51:02 --> Hooks Class Initialized
DEBUG - 2018-05-15 04:51:02 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 04:51:02 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 04:51:02 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 04:51:02 --> UTF-8 Support Enabled
INFO - 2018-05-15 04:51:02 --> Utf8 Class Initialized
INFO - 2018-05-15 04:51:02 --> Utf8 Class Initialized
INFO - 2018-05-15 04:51:02 --> Utf8 Class Initialized
INFO - 2018-05-15 04:51:02 --> Utf8 Class Initialized
INFO - 2018-05-15 04:51:02 --> URI Class Initialized
INFO - 2018-05-15 04:51:02 --> URI Class Initialized
INFO - 2018-05-15 04:51:02 --> URI Class Initialized
INFO - 2018-05-15 04:51:02 --> URI Class Initialized
INFO - 2018-05-15 04:51:02 --> Router Class Initialized
INFO - 2018-05-15 04:51:02 --> Router Class Initialized
INFO - 2018-05-15 04:51:02 --> Router Class Initialized
INFO - 2018-05-15 04:51:02 --> Router Class Initialized
INFO - 2018-05-15 04:51:02 --> Output Class Initialized
INFO - 2018-05-15 04:51:02 --> Output Class Initialized
INFO - 2018-05-15 04:51:02 --> Output Class Initialized
INFO - 2018-05-15 04:51:02 --> Output Class Initialized
INFO - 2018-05-15 04:51:02 --> Security Class Initialized
DEBUG - 2018-05-15 04:51:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:51:02 --> Input Class Initialized
INFO - 2018-05-15 04:51:02 --> Language Class Initialized
ERROR - 2018-05-15 04:51:02 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:51:02 --> Security Class Initialized
INFO - 2018-05-15 04:51:02 --> Security Class Initialized
INFO - 2018-05-15 04:51:02 --> Security Class Initialized
DEBUG - 2018-05-15 04:51:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:51:02 --> Input Class Initialized
INFO - 2018-05-15 04:51:02 --> Language Class Initialized
DEBUG - 2018-05-15 04:51:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-05-15 04:51:02 --> 404 Page Not Found: /index
DEBUG - 2018-05-15 04:51:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:51:02 --> Input Class Initialized
INFO - 2018-05-15 04:51:02 --> Language Class Initialized
ERROR - 2018-05-15 04:51:02 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:51:02 --> Input Class Initialized
INFO - 2018-05-15 04:51:02 --> Language Class Initialized
ERROR - 2018-05-15 04:51:02 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:51:07 --> Config Class Initialized
INFO - 2018-05-15 04:51:07 --> Hooks Class Initialized
DEBUG - 2018-05-15 04:51:07 --> UTF-8 Support Enabled
INFO - 2018-05-15 04:51:07 --> Utf8 Class Initialized
INFO - 2018-05-15 04:51:07 --> URI Class Initialized
INFO - 2018-05-15 04:51:07 --> Router Class Initialized
INFO - 2018-05-15 04:51:07 --> Output Class Initialized
INFO - 2018-05-15 04:51:07 --> Config Class Initialized
INFO - 2018-05-15 04:51:07 --> Config Class Initialized
INFO - 2018-05-15 04:51:07 --> Config Class Initialized
INFO - 2018-05-15 04:51:07 --> Config Class Initialized
INFO - 2018-05-15 04:51:07 --> Config Class Initialized
INFO - 2018-05-15 04:51:07 --> Hooks Class Initialized
INFO - 2018-05-15 04:51:07 --> Hooks Class Initialized
INFO - 2018-05-15 04:51:07 --> Hooks Class Initialized
INFO - 2018-05-15 04:51:07 --> Security Class Initialized
INFO - 2018-05-15 04:51:07 --> Hooks Class Initialized
INFO - 2018-05-15 04:51:07 --> Hooks Class Initialized
DEBUG - 2018-05-15 04:51:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-15 04:51:07 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 04:51:07 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 04:51:07 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 04:51:07 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 04:51:07 --> UTF-8 Support Enabled
INFO - 2018-05-15 04:51:07 --> Utf8 Class Initialized
INFO - 2018-05-15 04:51:07 --> Utf8 Class Initialized
INFO - 2018-05-15 04:51:07 --> Utf8 Class Initialized
INFO - 2018-05-15 04:51:07 --> Input Class Initialized
INFO - 2018-05-15 04:51:07 --> Utf8 Class Initialized
INFO - 2018-05-15 04:51:07 --> Utf8 Class Initialized
INFO - 2018-05-15 04:51:07 --> URI Class Initialized
INFO - 2018-05-15 04:51:07 --> Router Class Initialized
INFO - 2018-05-15 04:51:07 --> URI Class Initialized
INFO - 2018-05-15 04:51:07 --> URI Class Initialized
INFO - 2018-05-15 04:51:07 --> URI Class Initialized
INFO - 2018-05-15 04:51:07 --> Output Class Initialized
INFO - 2018-05-15 04:51:07 --> URI Class Initialized
INFO - 2018-05-15 04:51:07 --> Router Class Initialized
INFO - 2018-05-15 04:51:07 --> Language Class Initialized
INFO - 2018-05-15 04:51:07 --> Router Class Initialized
INFO - 2018-05-15 04:51:07 --> Security Class Initialized
INFO - 2018-05-15 04:51:07 --> Router Class Initialized
INFO - 2018-05-15 04:51:07 --> Router Class Initialized
INFO - 2018-05-15 04:51:07 --> Output Class Initialized
DEBUG - 2018-05-15 04:51:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:51:07 --> Output Class Initialized
INFO - 2018-05-15 04:51:07 --> Output Class Initialized
INFO - 2018-05-15 04:51:07 --> Output Class Initialized
ERROR - 2018-05-15 04:51:07 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:51:07 --> Input Class Initialized
INFO - 2018-05-15 04:51:07 --> Security Class Initialized
INFO - 2018-05-15 04:51:07 --> Security Class Initialized
INFO - 2018-05-15 04:51:07 --> Security Class Initialized
INFO - 2018-05-15 04:51:07 --> Security Class Initialized
INFO - 2018-05-15 04:51:07 --> Language Class Initialized
DEBUG - 2018-05-15 04:51:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-15 04:51:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-15 04:51:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-15 04:51:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:51:07 --> Input Class Initialized
INFO - 2018-05-15 04:51:07 --> Input Class Initialized
INFO - 2018-05-15 04:51:07 --> Input Class Initialized
ERROR - 2018-05-15 04:51:07 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:51:07 --> Input Class Initialized
INFO - 2018-05-15 04:51:08 --> Language Class Initialized
INFO - 2018-05-15 04:51:08 --> Language Class Initialized
ERROR - 2018-05-15 04:51:08 --> 404 Page Not Found: /index
ERROR - 2018-05-15 04:51:08 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:51:08 --> Language Class Initialized
INFO - 2018-05-15 04:51:08 --> Language Class Initialized
ERROR - 2018-05-15 04:51:08 --> 404 Page Not Found: /index
ERROR - 2018-05-15 04:51:08 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:51:08 --> Config Class Initialized
INFO - 2018-05-15 04:51:08 --> Config Class Initialized
INFO - 2018-05-15 04:51:08 --> Config Class Initialized
INFO - 2018-05-15 04:51:08 --> Config Class Initialized
INFO - 2018-05-15 04:51:08 --> Hooks Class Initialized
INFO - 2018-05-15 04:51:08 --> Hooks Class Initialized
INFO - 2018-05-15 04:51:08 --> Hooks Class Initialized
INFO - 2018-05-15 04:51:08 --> Hooks Class Initialized
DEBUG - 2018-05-15 04:51:08 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 04:51:08 --> UTF-8 Support Enabled
INFO - 2018-05-15 04:51:08 --> Utf8 Class Initialized
INFO - 2018-05-15 04:51:08 --> Utf8 Class Initialized
DEBUG - 2018-05-15 04:51:08 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 04:51:08 --> UTF-8 Support Enabled
INFO - 2018-05-15 04:51:08 --> URI Class Initialized
INFO - 2018-05-15 04:51:08 --> Utf8 Class Initialized
INFO - 2018-05-15 04:51:08 --> Utf8 Class Initialized
INFO - 2018-05-15 04:51:08 --> URI Class Initialized
INFO - 2018-05-15 04:51:08 --> Router Class Initialized
INFO - 2018-05-15 04:51:08 --> URI Class Initialized
INFO - 2018-05-15 04:51:08 --> Router Class Initialized
INFO - 2018-05-15 04:51:08 --> URI Class Initialized
INFO - 2018-05-15 04:51:08 --> Output Class Initialized
INFO - 2018-05-15 04:51:08 --> Output Class Initialized
INFO - 2018-05-15 04:51:08 --> Router Class Initialized
INFO - 2018-05-15 04:51:08 --> Router Class Initialized
INFO - 2018-05-15 04:51:08 --> Output Class Initialized
INFO - 2018-05-15 04:51:08 --> Security Class Initialized
INFO - 2018-05-15 04:51:08 --> Output Class Initialized
INFO - 2018-05-15 04:51:08 --> Security Class Initialized
DEBUG - 2018-05-15 04:51:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:51:08 --> Security Class Initialized
INFO - 2018-05-15 04:51:08 --> Security Class Initialized
DEBUG - 2018-05-15 04:51:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:51:08 --> Input Class Initialized
DEBUG - 2018-05-15 04:51:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:51:08 --> Input Class Initialized
DEBUG - 2018-05-15 04:51:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:51:08 --> Input Class Initialized
INFO - 2018-05-15 04:51:08 --> Language Class Initialized
INFO - 2018-05-15 04:51:08 --> Input Class Initialized
INFO - 2018-05-15 04:51:08 --> Language Class Initialized
ERROR - 2018-05-15 04:51:08 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:51:08 --> Language Class Initialized
INFO - 2018-05-15 04:51:08 --> Language Class Initialized
ERROR - 2018-05-15 04:51:08 --> 404 Page Not Found: /index
ERROR - 2018-05-15 04:51:08 --> 404 Page Not Found: /index
ERROR - 2018-05-15 04:51:08 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:51:08 --> Config Class Initialized
INFO - 2018-05-15 04:51:08 --> Hooks Class Initialized
INFO - 2018-05-15 04:51:08 --> Config Class Initialized
INFO - 2018-05-15 04:51:08 --> Hooks Class Initialized
INFO - 2018-05-15 04:51:08 --> Config Class Initialized
DEBUG - 2018-05-15 04:51:08 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 04:51:08 --> UTF-8 Support Enabled
INFO - 2018-05-15 04:51:08 --> Config Class Initialized
INFO - 2018-05-15 04:51:08 --> Utf8 Class Initialized
INFO - 2018-05-15 04:51:08 --> Hooks Class Initialized
INFO - 2018-05-15 04:51:08 --> Utf8 Class Initialized
INFO - 2018-05-15 04:51:08 --> Hooks Class Initialized
INFO - 2018-05-15 04:51:08 --> URI Class Initialized
INFO - 2018-05-15 04:51:08 --> Router Class Initialized
INFO - 2018-05-15 04:51:08 --> URI Class Initialized
DEBUG - 2018-05-15 04:51:08 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 04:51:08 --> UTF-8 Support Enabled
INFO - 2018-05-15 04:51:08 --> Utf8 Class Initialized
INFO - 2018-05-15 04:51:08 --> Router Class Initialized
INFO - 2018-05-15 04:51:08 --> Utf8 Class Initialized
INFO - 2018-05-15 04:51:08 --> Output Class Initialized
INFO - 2018-05-15 04:51:08 --> Security Class Initialized
INFO - 2018-05-15 04:51:08 --> URI Class Initialized
INFO - 2018-05-15 04:51:08 --> URI Class Initialized
INFO - 2018-05-15 04:51:08 --> Output Class Initialized
DEBUG - 2018-05-15 04:51:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:51:08 --> Security Class Initialized
DEBUG - 2018-05-15 04:51:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:51:08 --> Router Class Initialized
INFO - 2018-05-15 04:51:08 --> Input Class Initialized
INFO - 2018-05-15 04:51:08 --> Router Class Initialized
INFO - 2018-05-15 04:51:08 --> Language Class Initialized
INFO - 2018-05-15 04:51:08 --> Output Class Initialized
INFO - 2018-05-15 04:51:08 --> Input Class Initialized
INFO - 2018-05-15 04:51:08 --> Output Class Initialized
INFO - 2018-05-15 04:51:08 --> Language Class Initialized
INFO - 2018-05-15 04:51:08 --> Security Class Initialized
INFO - 2018-05-15 04:51:08 --> Security Class Initialized
ERROR - 2018-05-15 04:51:08 --> 404 Page Not Found: /index
DEBUG - 2018-05-15 04:51:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-15 04:51:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-05-15 04:51:08 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:51:08 --> Input Class Initialized
INFO - 2018-05-15 04:51:08 --> Input Class Initialized
INFO - 2018-05-15 04:51:08 --> Language Class Initialized
ERROR - 2018-05-15 04:51:08 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:51:08 --> Language Class Initialized
ERROR - 2018-05-15 04:51:08 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:51:32 --> Config Class Initialized
INFO - 2018-05-15 04:51:32 --> Hooks Class Initialized
DEBUG - 2018-05-15 04:51:32 --> UTF-8 Support Enabled
INFO - 2018-05-15 04:51:32 --> Utf8 Class Initialized
INFO - 2018-05-15 04:51:32 --> URI Class Initialized
INFO - 2018-05-15 04:51:32 --> Router Class Initialized
INFO - 2018-05-15 04:51:32 --> Output Class Initialized
INFO - 2018-05-15 04:51:32 --> Security Class Initialized
DEBUG - 2018-05-15 04:51:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:51:32 --> Input Class Initialized
INFO - 2018-05-15 04:51:32 --> Language Class Initialized
INFO - 2018-05-15 04:51:32 --> Config Class Initialized
INFO - 2018-05-15 04:51:32 --> Config Class Initialized
INFO - 2018-05-15 04:51:32 --> Config Class Initialized
INFO - 2018-05-15 04:51:32 --> Config Class Initialized
INFO - 2018-05-15 04:51:32 --> Config Class Initialized
INFO - 2018-05-15 04:51:32 --> Hooks Class Initialized
INFO - 2018-05-15 04:51:32 --> Hooks Class Initialized
INFO - 2018-05-15 04:51:32 --> Hooks Class Initialized
ERROR - 2018-05-15 04:51:32 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:51:32 --> Hooks Class Initialized
INFO - 2018-05-15 04:51:32 --> Hooks Class Initialized
DEBUG - 2018-05-15 04:51:32 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 04:51:32 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 04:51:32 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 04:51:32 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 04:51:32 --> UTF-8 Support Enabled
INFO - 2018-05-15 04:51:33 --> Utf8 Class Initialized
INFO - 2018-05-15 04:51:33 --> Utf8 Class Initialized
INFO - 2018-05-15 04:51:33 --> Utf8 Class Initialized
INFO - 2018-05-15 04:51:33 --> Utf8 Class Initialized
INFO - 2018-05-15 04:51:33 --> Utf8 Class Initialized
INFO - 2018-05-15 04:51:33 --> URI Class Initialized
INFO - 2018-05-15 04:51:33 --> URI Class Initialized
INFO - 2018-05-15 04:51:33 --> URI Class Initialized
INFO - 2018-05-15 04:51:33 --> Router Class Initialized
INFO - 2018-05-15 04:51:33 --> URI Class Initialized
INFO - 2018-05-15 04:51:33 --> URI Class Initialized
INFO - 2018-05-15 04:51:33 --> Router Class Initialized
INFO - 2018-05-15 04:51:33 --> Router Class Initialized
INFO - 2018-05-15 04:51:33 --> Output Class Initialized
INFO - 2018-05-15 04:51:33 --> Router Class Initialized
INFO - 2018-05-15 04:51:33 --> Router Class Initialized
INFO - 2018-05-15 04:51:33 --> Output Class Initialized
INFO - 2018-05-15 04:51:33 --> Output Class Initialized
INFO - 2018-05-15 04:51:33 --> Security Class Initialized
DEBUG - 2018-05-15 04:51:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:51:33 --> Input Class Initialized
INFO - 2018-05-15 04:51:33 --> Language Class Initialized
ERROR - 2018-05-15 04:51:33 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:51:33 --> Config Class Initialized
INFO - 2018-05-15 04:51:33 --> Hooks Class Initialized
DEBUG - 2018-05-15 04:51:33 --> UTF-8 Support Enabled
INFO - 2018-05-15 04:51:33 --> Utf8 Class Initialized
INFO - 2018-05-15 04:51:33 --> URI Class Initialized
INFO - 2018-05-15 04:51:33 --> Security Class Initialized
INFO - 2018-05-15 04:51:33 --> Output Class Initialized
INFO - 2018-05-15 04:51:33 --> Security Class Initialized
INFO - 2018-05-15 04:51:33 --> Output Class Initialized
INFO - 2018-05-15 04:51:33 --> Router Class Initialized
INFO - 2018-05-15 04:51:33 --> Output Class Initialized
INFO - 2018-05-15 04:51:33 --> Security Class Initialized
DEBUG - 2018-05-15 04:51:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:51:33 --> Input Class Initialized
DEBUG - 2018-05-15 04:51:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:51:33 --> Security Class Initialized
DEBUG - 2018-05-15 04:51:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:51:33 --> Language Class Initialized
INFO - 2018-05-15 04:51:33 --> Security Class Initialized
INFO - 2018-05-15 04:51:33 --> Input Class Initialized
DEBUG - 2018-05-15 04:51:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:51:33 --> Input Class Initialized
ERROR - 2018-05-15 04:51:33 --> 404 Page Not Found: /index
DEBUG - 2018-05-15 04:51:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:51:33 --> Language Class Initialized
INFO - 2018-05-15 04:51:33 --> Language Class Initialized
INFO - 2018-05-15 04:51:33 --> Input Class Initialized
ERROR - 2018-05-15 04:51:33 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:51:33 --> Input Class Initialized
INFO - 2018-05-15 04:51:33 --> Config Class Initialized
INFO - 2018-05-15 04:51:33 --> Language Class Initialized
ERROR - 2018-05-15 04:51:33 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:51:33 --> Hooks Class Initialized
INFO - 2018-05-15 04:51:33 --> Language Class Initialized
INFO - 2018-05-15 04:51:33 --> Config Class Initialized
INFO - 2018-05-15 04:51:33 --> Hooks Class Initialized
ERROR - 2018-05-15 04:51:33 --> 404 Page Not Found: /index
DEBUG - 2018-05-15 04:51:33 --> UTF-8 Support Enabled
ERROR - 2018-05-15 04:51:33 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:51:33 --> Config Class Initialized
INFO - 2018-05-15 04:51:33 --> Hooks Class Initialized
INFO - 2018-05-15 04:51:33 --> Utf8 Class Initialized
DEBUG - 2018-05-15 04:51:33 --> UTF-8 Support Enabled
INFO - 2018-05-15 04:51:33 --> Config Class Initialized
INFO - 2018-05-15 04:51:33 --> Hooks Class Initialized
DEBUG - 2018-05-15 04:51:33 --> UTF-8 Support Enabled
INFO - 2018-05-15 04:51:33 --> Utf8 Class Initialized
INFO - 2018-05-15 04:51:33 --> URI Class Initialized
DEBUG - 2018-05-15 04:51:33 --> UTF-8 Support Enabled
INFO - 2018-05-15 04:51:33 --> Utf8 Class Initialized
INFO - 2018-05-15 04:51:33 --> URI Class Initialized
INFO - 2018-05-15 04:51:33 --> Utf8 Class Initialized
INFO - 2018-05-15 04:51:33 --> Router Class Initialized
INFO - 2018-05-15 04:51:33 --> URI Class Initialized
INFO - 2018-05-15 04:51:33 --> Router Class Initialized
INFO - 2018-05-15 04:51:33 --> Output Class Initialized
INFO - 2018-05-15 04:51:33 --> Router Class Initialized
INFO - 2018-05-15 04:51:33 --> Output Class Initialized
INFO - 2018-05-15 04:51:33 --> URI Class Initialized
INFO - 2018-05-15 04:51:33 --> Security Class Initialized
INFO - 2018-05-15 04:51:33 --> Security Class Initialized
INFO - 2018-05-15 04:51:33 --> Output Class Initialized
INFO - 2018-05-15 04:51:33 --> Router Class Initialized
DEBUG - 2018-05-15 04:51:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:51:33 --> Security Class Initialized
INFO - 2018-05-15 04:51:33 --> Output Class Initialized
INFO - 2018-05-15 04:51:33 --> Input Class Initialized
DEBUG - 2018-05-15 04:51:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-15 04:51:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:51:33 --> Security Class Initialized
INFO - 2018-05-15 04:51:33 --> Input Class Initialized
INFO - 2018-05-15 04:51:33 --> Input Class Initialized
INFO - 2018-05-15 04:51:33 --> Language Class Initialized
DEBUG - 2018-05-15 04:51:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:51:33 --> Language Class Initialized
ERROR - 2018-05-15 04:51:33 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:51:33 --> Language Class Initialized
INFO - 2018-05-15 04:51:33 --> Input Class Initialized
ERROR - 2018-05-15 04:51:33 --> 404 Page Not Found: /index
ERROR - 2018-05-15 04:51:33 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:51:33 --> Config Class Initialized
INFO - 2018-05-15 04:51:33 --> Config Class Initialized
INFO - 2018-05-15 04:51:33 --> Language Class Initialized
INFO - 2018-05-15 04:51:33 --> Hooks Class Initialized
INFO - 2018-05-15 04:51:33 --> Hooks Class Initialized
ERROR - 2018-05-15 04:51:33 --> 404 Page Not Found: /index
DEBUG - 2018-05-15 04:51:33 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 04:51:34 --> UTF-8 Support Enabled
INFO - 2018-05-15 04:51:34 --> Utf8 Class Initialized
INFO - 2018-05-15 04:51:34 --> Config Class Initialized
INFO - 2018-05-15 04:51:34 --> Hooks Class Initialized
INFO - 2018-05-15 04:51:34 --> URI Class Initialized
INFO - 2018-05-15 04:51:34 --> Utf8 Class Initialized
DEBUG - 2018-05-15 04:51:34 --> UTF-8 Support Enabled
INFO - 2018-05-15 04:51:34 --> Utf8 Class Initialized
INFO - 2018-05-15 04:51:34 --> URI Class Initialized
INFO - 2018-05-15 04:51:34 --> Router Class Initialized
INFO - 2018-05-15 04:51:34 --> URI Class Initialized
INFO - 2018-05-15 04:51:34 --> Output Class Initialized
INFO - 2018-05-15 04:51:34 --> Router Class Initialized
INFO - 2018-05-15 04:51:34 --> Security Class Initialized
INFO - 2018-05-15 04:51:34 --> Output Class Initialized
DEBUG - 2018-05-15 04:51:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:51:34 --> Input Class Initialized
INFO - 2018-05-15 04:51:34 --> Security Class Initialized
INFO - 2018-05-15 04:51:34 --> Router Class Initialized
DEBUG - 2018-05-15 04:51:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:51:34 --> Language Class Initialized
INFO - 2018-05-15 04:51:34 --> Output Class Initialized
INFO - 2018-05-15 04:51:34 --> Input Class Initialized
INFO - 2018-05-15 04:51:34 --> Security Class Initialized
ERROR - 2018-05-15 04:51:34 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:51:34 --> Language Class Initialized
DEBUG - 2018-05-15 04:51:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:51:34 --> Input Class Initialized
ERROR - 2018-05-15 04:51:34 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:51:34 --> Language Class Initialized
ERROR - 2018-05-15 04:51:34 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:51:35 --> Config Class Initialized
INFO - 2018-05-15 04:51:35 --> Hooks Class Initialized
DEBUG - 2018-05-15 04:51:35 --> UTF-8 Support Enabled
INFO - 2018-05-15 04:51:35 --> Utf8 Class Initialized
INFO - 2018-05-15 04:51:35 --> Config Class Initialized
INFO - 2018-05-15 04:51:35 --> Config Class Initialized
INFO - 2018-05-15 04:51:35 --> Config Class Initialized
INFO - 2018-05-15 04:51:35 --> Config Class Initialized
INFO - 2018-05-15 04:51:35 --> Config Class Initialized
INFO - 2018-05-15 04:51:35 --> Hooks Class Initialized
INFO - 2018-05-15 04:51:35 --> Hooks Class Initialized
INFO - 2018-05-15 04:51:35 --> Hooks Class Initialized
INFO - 2018-05-15 04:51:35 --> Hooks Class Initialized
INFO - 2018-05-15 04:51:35 --> Hooks Class Initialized
INFO - 2018-05-15 04:51:35 --> URI Class Initialized
DEBUG - 2018-05-15 04:51:35 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 04:51:35 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 04:51:35 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 04:51:35 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 04:51:35 --> UTF-8 Support Enabled
INFO - 2018-05-15 04:51:35 --> Router Class Initialized
INFO - 2018-05-15 04:51:35 --> Utf8 Class Initialized
INFO - 2018-05-15 04:51:35 --> Utf8 Class Initialized
INFO - 2018-05-15 04:51:35 --> Utf8 Class Initialized
INFO - 2018-05-15 04:51:35 --> Utf8 Class Initialized
INFO - 2018-05-15 04:51:35 --> Utf8 Class Initialized
INFO - 2018-05-15 04:51:35 --> Output Class Initialized
INFO - 2018-05-15 04:51:35 --> URI Class Initialized
INFO - 2018-05-15 04:51:35 --> Router Class Initialized
INFO - 2018-05-15 04:51:35 --> Output Class Initialized
INFO - 2018-05-15 04:51:35 --> URI Class Initialized
INFO - 2018-05-15 04:51:35 --> Security Class Initialized
INFO - 2018-05-15 04:51:35 --> URI Class Initialized
INFO - 2018-05-15 04:51:35 --> URI Class Initialized
INFO - 2018-05-15 04:51:35 --> URI Class Initialized
INFO - 2018-05-15 04:51:35 --> Security Class Initialized
DEBUG - 2018-05-15 04:51:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:51:35 --> Router Class Initialized
INFO - 2018-05-15 04:51:35 --> Router Class Initialized
INFO - 2018-05-15 04:51:35 --> Router Class Initialized
DEBUG - 2018-05-15 04:51:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:51:35 --> Router Class Initialized
INFO - 2018-05-15 04:51:35 --> Output Class Initialized
INFO - 2018-05-15 04:51:35 --> Output Class Initialized
INFO - 2018-05-15 04:51:35 --> Input Class Initialized
INFO - 2018-05-15 04:51:35 --> Output Class Initialized
INFO - 2018-05-15 04:51:35 --> Input Class Initialized
INFO - 2018-05-15 04:51:35 --> Output Class Initialized
INFO - 2018-05-15 04:51:35 --> Security Class Initialized
INFO - 2018-05-15 04:51:35 --> Language Class Initialized
INFO - 2018-05-15 04:51:35 --> Security Class Initialized
ERROR - 2018-05-15 04:51:35 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:51:35 --> Language Class Initialized
DEBUG - 2018-05-15 04:51:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-15 04:51:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:51:35 --> Security Class Initialized
INFO - 2018-05-15 04:51:35 --> Security Class Initialized
INFO - 2018-05-15 04:51:35 --> Input Class Initialized
INFO - 2018-05-15 04:51:35 --> Input Class Initialized
DEBUG - 2018-05-15 04:51:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-05-15 04:51:35 --> 404 Page Not Found: /index
DEBUG - 2018-05-15 04:51:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:51:35 --> Input Class Initialized
INFO - 2018-05-15 04:51:35 --> Language Class Initialized
INFO - 2018-05-15 04:51:35 --> Input Class Initialized
INFO - 2018-05-15 04:51:35 --> Language Class Initialized
INFO - 2018-05-15 04:51:35 --> Config Class Initialized
INFO - 2018-05-15 04:51:35 --> Hooks Class Initialized
INFO - 2018-05-15 04:51:35 --> Language Class Initialized
INFO - 2018-05-15 04:51:35 --> Language Class Initialized
ERROR - 2018-05-15 04:51:35 --> 404 Page Not Found: /index
ERROR - 2018-05-15 04:51:35 --> 404 Page Not Found: /index
DEBUG - 2018-05-15 04:51:35 --> UTF-8 Support Enabled
ERROR - 2018-05-15 04:51:35 --> 404 Page Not Found: /index
ERROR - 2018-05-15 04:51:35 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:51:35 --> Utf8 Class Initialized
INFO - 2018-05-15 04:51:35 --> URI Class Initialized
INFO - 2018-05-15 04:51:35 --> Router Class Initialized
INFO - 2018-05-15 04:51:35 --> Output Class Initialized
INFO - 2018-05-15 04:51:35 --> Security Class Initialized
INFO - 2018-05-15 04:51:35 --> Config Class Initialized
INFO - 2018-05-15 04:51:35 --> Hooks Class Initialized
DEBUG - 2018-05-15 04:51:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:51:35 --> Config Class Initialized
INFO - 2018-05-15 04:51:35 --> Config Class Initialized
INFO - 2018-05-15 04:51:35 --> Hooks Class Initialized
INFO - 2018-05-15 04:51:35 --> Input Class Initialized
INFO - 2018-05-15 04:51:35 --> Hooks Class Initialized
DEBUG - 2018-05-15 04:51:35 --> UTF-8 Support Enabled
INFO - 2018-05-15 04:51:35 --> Utf8 Class Initialized
INFO - 2018-05-15 04:51:35 --> Language Class Initialized
DEBUG - 2018-05-15 04:51:35 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 04:51:35 --> UTF-8 Support Enabled
INFO - 2018-05-15 04:51:35 --> Utf8 Class Initialized
INFO - 2018-05-15 04:51:35 --> URI Class Initialized
INFO - 2018-05-15 04:51:35 --> Utf8 Class Initialized
ERROR - 2018-05-15 04:51:35 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:51:35 --> URI Class Initialized
INFO - 2018-05-15 04:51:35 --> URI Class Initialized
INFO - 2018-05-15 04:51:35 --> Router Class Initialized
INFO - 2018-05-15 04:51:35 --> Config Class Initialized
INFO - 2018-05-15 04:51:36 --> Hooks Class Initialized
INFO - 2018-05-15 04:51:36 --> Router Class Initialized
DEBUG - 2018-05-15 04:51:36 --> UTF-8 Support Enabled
INFO - 2018-05-15 04:51:36 --> Output Class Initialized
INFO - 2018-05-15 04:51:36 --> Router Class Initialized
INFO - 2018-05-15 04:51:36 --> Output Class Initialized
INFO - 2018-05-15 04:51:36 --> Utf8 Class Initialized
INFO - 2018-05-15 04:51:36 --> Security Class Initialized
INFO - 2018-05-15 04:51:36 --> Output Class Initialized
INFO - 2018-05-15 04:51:36 --> URI Class Initialized
DEBUG - 2018-05-15 04:51:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:51:36 --> Security Class Initialized
INFO - 2018-05-15 04:51:36 --> Security Class Initialized
INFO - 2018-05-15 04:51:36 --> Input Class Initialized
INFO - 2018-05-15 04:51:36 --> Router Class Initialized
DEBUG - 2018-05-15 04:51:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-15 04:51:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:51:36 --> Output Class Initialized
INFO - 2018-05-15 04:51:36 --> Input Class Initialized
INFO - 2018-05-15 04:51:36 --> Input Class Initialized
INFO - 2018-05-15 04:51:36 --> Language Class Initialized
INFO - 2018-05-15 04:51:36 --> Security Class Initialized
INFO - 2018-05-15 04:51:36 --> Language Class Initialized
INFO - 2018-05-15 04:51:36 --> Language Class Initialized
ERROR - 2018-05-15 04:51:36 --> 404 Page Not Found: /index
DEBUG - 2018-05-15 04:51:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-05-15 04:51:36 --> 404 Page Not Found: /index
ERROR - 2018-05-15 04:51:36 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:51:36 --> Config Class Initialized
INFO - 2018-05-15 04:51:36 --> Hooks Class Initialized
INFO - 2018-05-15 04:51:36 --> Input Class Initialized
INFO - 2018-05-15 04:51:36 --> Config Class Initialized
INFO - 2018-05-15 04:51:36 --> Config Class Initialized
INFO - 2018-05-15 04:51:36 --> Hooks Class Initialized
INFO - 2018-05-15 04:51:36 --> Hooks Class Initialized
DEBUG - 2018-05-15 04:51:36 --> UTF-8 Support Enabled
INFO - 2018-05-15 04:51:36 --> Language Class Initialized
ERROR - 2018-05-15 04:51:36 --> 404 Page Not Found: /index
DEBUG - 2018-05-15 04:51:36 --> UTF-8 Support Enabled
INFO - 2018-05-15 04:51:36 --> Utf8 Class Initialized
DEBUG - 2018-05-15 04:51:36 --> UTF-8 Support Enabled
INFO - 2018-05-15 04:51:36 --> Utf8 Class Initialized
INFO - 2018-05-15 04:51:36 --> URI Class Initialized
INFO - 2018-05-15 04:51:36 --> Utf8 Class Initialized
INFO - 2018-05-15 04:51:36 --> URI Class Initialized
INFO - 2018-05-15 04:51:36 --> URI Class Initialized
INFO - 2018-05-15 04:51:36 --> Router Class Initialized
INFO - 2018-05-15 04:51:36 --> Output Class Initialized
INFO - 2018-05-15 04:51:36 --> Router Class Initialized
INFO - 2018-05-15 04:51:36 --> Router Class Initialized
INFO - 2018-05-15 04:51:36 --> Security Class Initialized
INFO - 2018-05-15 04:51:36 --> Output Class Initialized
INFO - 2018-05-15 04:51:36 --> Output Class Initialized
DEBUG - 2018-05-15 04:51:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:51:36 --> Security Class Initialized
INFO - 2018-05-15 04:51:36 --> Security Class Initialized
INFO - 2018-05-15 04:51:36 --> Input Class Initialized
DEBUG - 2018-05-15 04:51:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-15 04:51:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:51:36 --> Input Class Initialized
INFO - 2018-05-15 04:51:36 --> Input Class Initialized
INFO - 2018-05-15 04:51:36 --> Language Class Initialized
INFO - 2018-05-15 04:51:36 --> Language Class Initialized
ERROR - 2018-05-15 04:51:36 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:51:36 --> Language Class Initialized
ERROR - 2018-05-15 04:51:36 --> 404 Page Not Found: /index
ERROR - 2018-05-15 04:51:36 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:51:36 --> Config Class Initialized
INFO - 2018-05-15 04:51:36 --> Hooks Class Initialized
DEBUG - 2018-05-15 04:51:37 --> UTF-8 Support Enabled
INFO - 2018-05-15 04:51:37 --> Utf8 Class Initialized
INFO - 2018-05-15 04:51:37 --> URI Class Initialized
INFO - 2018-05-15 04:51:37 --> Router Class Initialized
INFO - 2018-05-15 04:51:37 --> Config Class Initialized
INFO - 2018-05-15 04:51:37 --> Config Class Initialized
INFO - 2018-05-15 04:51:37 --> Config Class Initialized
INFO - 2018-05-15 04:51:37 --> Config Class Initialized
INFO - 2018-05-15 04:51:37 --> Config Class Initialized
INFO - 2018-05-15 04:51:37 --> Output Class Initialized
INFO - 2018-05-15 04:51:37 --> Hooks Class Initialized
INFO - 2018-05-15 04:51:37 --> Hooks Class Initialized
INFO - 2018-05-15 04:51:37 --> Hooks Class Initialized
INFO - 2018-05-15 04:51:37 --> Hooks Class Initialized
INFO - 2018-05-15 04:51:37 --> Hooks Class Initialized
INFO - 2018-05-15 04:51:37 --> Security Class Initialized
DEBUG - 2018-05-15 04:51:37 --> UTF-8 Support Enabled
INFO - 2018-05-15 04:51:37 --> Utf8 Class Initialized
DEBUG - 2018-05-15 04:51:37 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 04:51:37 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 04:51:37 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 04:51:37 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 04:51:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:51:37 --> URI Class Initialized
INFO - 2018-05-15 04:51:37 --> Utf8 Class Initialized
INFO - 2018-05-15 04:51:37 --> URI Class Initialized
INFO - 2018-05-15 04:51:37 --> Utf8 Class Initialized
INFO - 2018-05-15 04:51:37 --> Utf8 Class Initialized
INFO - 2018-05-15 04:51:37 --> Utf8 Class Initialized
INFO - 2018-05-15 04:51:37 --> Input Class Initialized
INFO - 2018-05-15 04:51:37 --> Router Class Initialized
INFO - 2018-05-15 04:51:37 --> Router Class Initialized
INFO - 2018-05-15 04:51:37 --> URI Class Initialized
INFO - 2018-05-15 04:51:37 --> Router Class Initialized
INFO - 2018-05-15 04:51:37 --> URI Class Initialized
INFO - 2018-05-15 04:51:37 --> URI Class Initialized
INFO - 2018-05-15 04:51:37 --> Language Class Initialized
INFO - 2018-05-15 04:51:37 --> Output Class Initialized
INFO - 2018-05-15 04:51:37 --> Output Class Initialized
INFO - 2018-05-15 04:51:37 --> Output Class Initialized
INFO - 2018-05-15 04:51:37 --> Router Class Initialized
INFO - 2018-05-15 04:51:37 --> Router Class Initialized
INFO - 2018-05-15 04:51:37 --> Security Class Initialized
INFO - 2018-05-15 04:51:37 --> Security Class Initialized
INFO - 2018-05-15 04:51:37 --> Security Class Initialized
ERROR - 2018-05-15 04:51:37 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:51:37 --> Output Class Initialized
INFO - 2018-05-15 04:51:37 --> Security Class Initialized
DEBUG - 2018-05-15 04:51:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:51:37 --> Output Class Initialized
DEBUG - 2018-05-15 04:51:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-15 04:51:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-15 04:51:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:51:37 --> Input Class Initialized
INFO - 2018-05-15 04:51:37 --> Language Class Initialized
INFO - 2018-05-15 04:51:37 --> Input Class Initialized
INFO - 2018-05-15 04:51:37 --> Input Class Initialized
INFO - 2018-05-15 04:51:37 --> Input Class Initialized
INFO - 2018-05-15 04:51:37 --> Security Class Initialized
ERROR - 2018-05-15 04:51:37 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:51:37 --> Language Class Initialized
DEBUG - 2018-05-15 04:51:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:51:37 --> Language Class Initialized
INFO - 2018-05-15 04:51:37 --> Language Class Initialized
INFO - 2018-05-15 04:51:37 --> Config Class Initialized
INFO - 2018-05-15 04:51:37 --> Hooks Class Initialized
ERROR - 2018-05-15 04:51:37 --> 404 Page Not Found: /index
ERROR - 2018-05-15 04:51:37 --> 404 Page Not Found: /index
ERROR - 2018-05-15 04:51:37 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:51:37 --> Input Class Initialized
DEBUG - 2018-05-15 04:51:37 --> UTF-8 Support Enabled
INFO - 2018-05-15 04:51:37 --> Utf8 Class Initialized
INFO - 2018-05-15 04:51:37 --> URI Class Initialized
INFO - 2018-05-15 04:51:37 --> Language Class Initialized
INFO - 2018-05-15 04:51:37 --> Config Class Initialized
INFO - 2018-05-15 04:51:37 --> Router Class Initialized
INFO - 2018-05-15 04:51:37 --> Config Class Initialized
ERROR - 2018-05-15 04:51:37 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:51:37 --> Hooks Class Initialized
INFO - 2018-05-15 04:51:37 --> Config Class Initialized
INFO - 2018-05-15 04:51:37 --> Output Class Initialized
INFO - 2018-05-15 04:51:37 --> Hooks Class Initialized
INFO - 2018-05-15 04:51:38 --> Hooks Class Initialized
INFO - 2018-05-15 04:51:38 --> Security Class Initialized
DEBUG - 2018-05-15 04:51:38 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 04:51:38 --> UTF-8 Support Enabled
INFO - 2018-05-15 04:51:38 --> Utf8 Class Initialized
DEBUG - 2018-05-15 04:51:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:51:38 --> Utf8 Class Initialized
DEBUG - 2018-05-15 04:51:38 --> UTF-8 Support Enabled
INFO - 2018-05-15 04:51:38 --> Utf8 Class Initialized
INFO - 2018-05-15 04:51:38 --> URI Class Initialized
INFO - 2018-05-15 04:51:38 --> Input Class Initialized
INFO - 2018-05-15 04:51:38 --> URI Class Initialized
INFO - 2018-05-15 04:51:38 --> Language Class Initialized
INFO - 2018-05-15 04:51:38 --> Router Class Initialized
INFO - 2018-05-15 04:51:38 --> URI Class Initialized
INFO - 2018-05-15 04:51:38 --> Router Class Initialized
INFO - 2018-05-15 04:51:38 --> Output Class Initialized
ERROR - 2018-05-15 04:51:38 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:51:38 --> Output Class Initialized
INFO - 2018-05-15 04:51:38 --> Router Class Initialized
INFO - 2018-05-15 04:51:38 --> Security Class Initialized
INFO - 2018-05-15 04:51:38 --> Output Class Initialized
INFO - 2018-05-15 04:51:38 --> Security Class Initialized
INFO - 2018-05-15 04:51:38 --> Config Class Initialized
INFO - 2018-05-15 04:51:38 --> Hooks Class Initialized
DEBUG - 2018-05-15 04:51:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-15 04:51:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:51:38 --> Input Class Initialized
INFO - 2018-05-15 04:51:38 --> Input Class Initialized
DEBUG - 2018-05-15 04:51:38 --> UTF-8 Support Enabled
INFO - 2018-05-15 04:51:38 --> Security Class Initialized
INFO - 2018-05-15 04:51:38 --> Utf8 Class Initialized
INFO - 2018-05-15 04:51:38 --> Language Class Initialized
INFO - 2018-05-15 04:51:38 --> Language Class Initialized
DEBUG - 2018-05-15 04:51:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:51:38 --> URI Class Initialized
ERROR - 2018-05-15 04:51:38 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:51:38 --> Input Class Initialized
ERROR - 2018-05-15 04:51:38 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:51:38 --> Router Class Initialized
INFO - 2018-05-15 04:51:38 --> Config Class Initialized
INFO - 2018-05-15 04:51:38 --> Config Class Initialized
INFO - 2018-05-15 04:51:38 --> Language Class Initialized
INFO - 2018-05-15 04:51:38 --> Hooks Class Initialized
INFO - 2018-05-15 04:51:38 --> Hooks Class Initialized
INFO - 2018-05-15 04:51:38 --> Output Class Initialized
ERROR - 2018-05-15 04:51:38 --> 404 Page Not Found: /index
DEBUG - 2018-05-15 04:51:38 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 04:51:38 --> UTF-8 Support Enabled
INFO - 2018-05-15 04:51:38 --> Security Class Initialized
INFO - 2018-05-15 04:51:38 --> Config Class Initialized
INFO - 2018-05-15 04:51:38 --> Utf8 Class Initialized
DEBUG - 2018-05-15 04:51:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:51:38 --> Hooks Class Initialized
INFO - 2018-05-15 04:51:38 --> Utf8 Class Initialized
INFO - 2018-05-15 04:51:38 --> URI Class Initialized
INFO - 2018-05-15 04:51:38 --> Input Class Initialized
INFO - 2018-05-15 04:51:38 --> URI Class Initialized
DEBUG - 2018-05-15 04:51:38 --> UTF-8 Support Enabled
INFO - 2018-05-15 04:51:38 --> Utf8 Class Initialized
INFO - 2018-05-15 04:51:38 --> Router Class Initialized
INFO - 2018-05-15 04:51:38 --> Language Class Initialized
INFO - 2018-05-15 04:51:38 --> Router Class Initialized
INFO - 2018-05-15 04:51:38 --> Output Class Initialized
ERROR - 2018-05-15 04:51:38 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:51:38 --> Output Class Initialized
INFO - 2018-05-15 04:51:38 --> URI Class Initialized
INFO - 2018-05-15 04:51:38 --> Security Class Initialized
INFO - 2018-05-15 04:51:38 --> Router Class Initialized
INFO - 2018-05-15 04:51:38 --> Output Class Initialized
DEBUG - 2018-05-15 04:51:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:51:38 --> Security Class Initialized
DEBUG - 2018-05-15 04:51:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:51:38 --> Input Class Initialized
INFO - 2018-05-15 04:51:38 --> Security Class Initialized
DEBUG - 2018-05-15 04:51:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:51:38 --> Input Class Initialized
INFO - 2018-05-15 04:51:38 --> Language Class Initialized
ERROR - 2018-05-15 04:51:38 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:51:38 --> Input Class Initialized
INFO - 2018-05-15 04:51:38 --> Language Class Initialized
ERROR - 2018-05-15 04:51:38 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:51:38 --> Language Class Initialized
ERROR - 2018-05-15 04:51:38 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:51:40 --> Config Class Initialized
INFO - 2018-05-15 04:51:40 --> Hooks Class Initialized
DEBUG - 2018-05-15 04:51:40 --> UTF-8 Support Enabled
INFO - 2018-05-15 04:51:40 --> Utf8 Class Initialized
INFO - 2018-05-15 04:51:40 --> URI Class Initialized
INFO - 2018-05-15 04:51:40 --> Router Class Initialized
INFO - 2018-05-15 04:51:40 --> Output Class Initialized
INFO - 2018-05-15 04:51:40 --> Security Class Initialized
INFO - 2018-05-15 04:51:40 --> Config Class Initialized
INFO - 2018-05-15 04:51:40 --> Config Class Initialized
INFO - 2018-05-15 04:51:40 --> Config Class Initialized
INFO - 2018-05-15 04:51:40 --> Config Class Initialized
INFO - 2018-05-15 04:51:40 --> Config Class Initialized
INFO - 2018-05-15 04:51:40 --> Hooks Class Initialized
INFO - 2018-05-15 04:51:40 --> Hooks Class Initialized
INFO - 2018-05-15 04:51:40 --> Hooks Class Initialized
INFO - 2018-05-15 04:51:40 --> Hooks Class Initialized
INFO - 2018-05-15 04:51:40 --> Hooks Class Initialized
DEBUG - 2018-05-15 04:51:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-15 04:51:40 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 04:51:40 --> UTF-8 Support Enabled
INFO - 2018-05-15 04:51:40 --> Input Class Initialized
DEBUG - 2018-05-15 04:51:40 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 04:51:40 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 04:51:40 --> UTF-8 Support Enabled
INFO - 2018-05-15 04:51:40 --> Utf8 Class Initialized
INFO - 2018-05-15 04:51:40 --> Utf8 Class Initialized
INFO - 2018-05-15 04:51:40 --> Language Class Initialized
INFO - 2018-05-15 04:51:40 --> Utf8 Class Initialized
INFO - 2018-05-15 04:51:40 --> Utf8 Class Initialized
INFO - 2018-05-15 04:51:40 --> Utf8 Class Initialized
INFO - 2018-05-15 04:51:40 --> URI Class Initialized
INFO - 2018-05-15 04:51:40 --> Router Class Initialized
ERROR - 2018-05-15 04:51:40 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:51:40 --> URI Class Initialized
INFO - 2018-05-15 04:51:40 --> URI Class Initialized
INFO - 2018-05-15 04:51:40 --> URI Class Initialized
INFO - 2018-05-15 04:51:40 --> URI Class Initialized
INFO - 2018-05-15 04:51:40 --> Output Class Initialized
INFO - 2018-05-15 04:51:40 --> Security Class Initialized
INFO - 2018-05-15 04:51:40 --> Router Class Initialized
INFO - 2018-05-15 04:51:40 --> Router Class Initialized
INFO - 2018-05-15 04:51:40 --> Router Class Initialized
INFO - 2018-05-15 04:51:40 --> Output Class Initialized
INFO - 2018-05-15 04:51:40 --> Output Class Initialized
INFO - 2018-05-15 04:51:40 --> Router Class Initialized
DEBUG - 2018-05-15 04:51:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:51:40 --> Config Class Initialized
INFO - 2018-05-15 04:51:40 --> Output Class Initialized
INFO - 2018-05-15 04:51:40 --> Security Class Initialized
INFO - 2018-05-15 04:51:40 --> Hooks Class Initialized
INFO - 2018-05-15 04:51:40 --> Security Class Initialized
INFO - 2018-05-15 04:51:40 --> Security Class Initialized
INFO - 2018-05-15 04:51:40 --> Output Class Initialized
INFO - 2018-05-15 04:51:40 --> Input Class Initialized
DEBUG - 2018-05-15 04:51:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-15 04:51:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-15 04:51:40 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 04:51:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:51:40 --> Security Class Initialized
INFO - 2018-05-15 04:51:40 --> Language Class Initialized
INFO - 2018-05-15 04:51:40 --> Utf8 Class Initialized
INFO - 2018-05-15 04:51:40 --> Input Class Initialized
INFO - 2018-05-15 04:51:40 --> Input Class Initialized
INFO - 2018-05-15 04:51:40 --> Input Class Initialized
DEBUG - 2018-05-15 04:51:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-05-15 04:51:40 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:51:40 --> Language Class Initialized
INFO - 2018-05-15 04:51:40 --> Language Class Initialized
INFO - 2018-05-15 04:51:40 --> Language Class Initialized
INFO - 2018-05-15 04:51:40 --> Input Class Initialized
INFO - 2018-05-15 04:51:40 --> URI Class Initialized
INFO - 2018-05-15 04:51:40 --> Config Class Initialized
INFO - 2018-05-15 04:51:40 --> Config Class Initialized
ERROR - 2018-05-15 04:51:40 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:51:40 --> Hooks Class Initialized
INFO - 2018-05-15 04:51:40 --> Hooks Class Initialized
INFO - 2018-05-15 04:51:40 --> Config Class Initialized
ERROR - 2018-05-15 04:51:40 --> 404 Page Not Found: /index
ERROR - 2018-05-15 04:51:40 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:51:40 --> Language Class Initialized
INFO - 2018-05-15 04:51:40 --> Router Class Initialized
INFO - 2018-05-15 04:51:40 --> Config Class Initialized
INFO - 2018-05-15 04:51:40 --> Hooks Class Initialized
INFO - 2018-05-15 04:51:40 --> Config Class Initialized
DEBUG - 2018-05-15 04:51:40 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 04:51:40 --> UTF-8 Support Enabled
ERROR - 2018-05-15 04:51:40 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:51:40 --> Hooks Class Initialized
INFO - 2018-05-15 04:51:40 --> Output Class Initialized
INFO - 2018-05-15 04:51:40 --> Utf8 Class Initialized
DEBUG - 2018-05-15 04:51:40 --> UTF-8 Support Enabled
INFO - 2018-05-15 04:51:41 --> Hooks Class Initialized
INFO - 2018-05-15 04:51:41 --> Utf8 Class Initialized
INFO - 2018-05-15 04:51:41 --> Security Class Initialized
DEBUG - 2018-05-15 04:51:41 --> UTF-8 Support Enabled
INFO - 2018-05-15 04:51:41 --> Utf8 Class Initialized
INFO - 2018-05-15 04:51:41 --> URI Class Initialized
DEBUG - 2018-05-15 04:51:41 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 04:51:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:51:41 --> Utf8 Class Initialized
INFO - 2018-05-15 04:51:41 --> URI Class Initialized
INFO - 2018-05-15 04:51:41 --> Utf8 Class Initialized
INFO - 2018-05-15 04:51:41 --> URI Class Initialized
INFO - 2018-05-15 04:51:41 --> Router Class Initialized
INFO - 2018-05-15 04:51:41 --> Input Class Initialized
INFO - 2018-05-15 04:51:41 --> URI Class Initialized
INFO - 2018-05-15 04:51:41 --> Router Class Initialized
INFO - 2018-05-15 04:51:41 --> Output Class Initialized
INFO - 2018-05-15 04:51:41 --> URI Class Initialized
INFO - 2018-05-15 04:51:41 --> Security Class Initialized
DEBUG - 2018-05-15 04:51:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:51:41 --> Output Class Initialized
INFO - 2018-05-15 04:51:41 --> Router Class Initialized
INFO - 2018-05-15 04:51:41 --> Language Class Initialized
INFO - 2018-05-15 04:51:41 --> Input Class Initialized
INFO - 2018-05-15 04:51:41 --> Router Class Initialized
INFO - 2018-05-15 04:51:41 --> Router Class Initialized
INFO - 2018-05-15 04:51:41 --> Security Class Initialized
INFO - 2018-05-15 04:51:41 --> Output Class Initialized
ERROR - 2018-05-15 04:51:41 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:51:41 --> Language Class Initialized
INFO - 2018-05-15 04:51:41 --> Output Class Initialized
INFO - 2018-05-15 04:51:41 --> Output Class Initialized
DEBUG - 2018-05-15 04:51:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-05-15 04:51:41 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:51:41 --> Security Class Initialized
INFO - 2018-05-15 04:51:41 --> Security Class Initialized
INFO - 2018-05-15 04:51:41 --> Security Class Initialized
INFO - 2018-05-15 04:51:41 --> Input Class Initialized
DEBUG - 2018-05-15 04:51:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-15 04:51:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-15 04:51:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:51:41 --> Input Class Initialized
INFO - 2018-05-15 04:51:41 --> Input Class Initialized
INFO - 2018-05-15 04:51:41 --> Input Class Initialized
INFO - 2018-05-15 04:51:41 --> Language Class Initialized
ERROR - 2018-05-15 04:51:41 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:51:41 --> Language Class Initialized
INFO - 2018-05-15 04:51:41 --> Language Class Initialized
INFO - 2018-05-15 04:51:41 --> Language Class Initialized
ERROR - 2018-05-15 04:51:41 --> 404 Page Not Found: /index
ERROR - 2018-05-15 04:51:41 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:51:41 --> Config Class Initialized
ERROR - 2018-05-15 04:51:41 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:51:41 --> Hooks Class Initialized
DEBUG - 2018-05-15 04:51:41 --> UTF-8 Support Enabled
INFO - 2018-05-15 04:51:41 --> Utf8 Class Initialized
INFO - 2018-05-15 04:51:41 --> URI Class Initialized
INFO - 2018-05-15 04:51:41 --> Config Class Initialized
INFO - 2018-05-15 04:51:41 --> Config Class Initialized
INFO - 2018-05-15 04:51:41 --> Config Class Initialized
INFO - 2018-05-15 04:51:41 --> Hooks Class Initialized
INFO - 2018-05-15 04:51:41 --> Hooks Class Initialized
INFO - 2018-05-15 04:51:41 --> Hooks Class Initialized
INFO - 2018-05-15 04:51:41 --> Router Class Initialized
DEBUG - 2018-05-15 04:51:41 --> UTF-8 Support Enabled
INFO - 2018-05-15 04:51:41 --> Utf8 Class Initialized
DEBUG - 2018-05-15 04:51:41 --> UTF-8 Support Enabled
INFO - 2018-05-15 04:51:41 --> Output Class Initialized
INFO - 2018-05-15 04:51:41 --> URI Class Initialized
DEBUG - 2018-05-15 04:51:41 --> UTF-8 Support Enabled
INFO - 2018-05-15 04:51:41 --> Security Class Initialized
INFO - 2018-05-15 04:51:41 --> Utf8 Class Initialized
INFO - 2018-05-15 04:51:41 --> Utf8 Class Initialized
INFO - 2018-05-15 04:51:41 --> Router Class Initialized
INFO - 2018-05-15 04:51:41 --> Output Class Initialized
INFO - 2018-05-15 04:51:41 --> URI Class Initialized
DEBUG - 2018-05-15 04:51:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:51:41 --> URI Class Initialized
INFO - 2018-05-15 04:51:41 --> Router Class Initialized
INFO - 2018-05-15 04:51:41 --> Input Class Initialized
INFO - 2018-05-15 04:51:41 --> Security Class Initialized
INFO - 2018-05-15 04:51:41 --> Router Class Initialized
INFO - 2018-05-15 04:51:41 --> Output Class Initialized
DEBUG - 2018-05-15 04:51:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:51:41 --> Language Class Initialized
INFO - 2018-05-15 04:51:41 --> Output Class Initialized
ERROR - 2018-05-15 04:51:41 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:51:41 --> Input Class Initialized
INFO - 2018-05-15 04:51:41 --> Security Class Initialized
INFO - 2018-05-15 04:51:41 --> Security Class Initialized
INFO - 2018-05-15 04:51:41 --> Language Class Initialized
DEBUG - 2018-05-15 04:51:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-15 04:51:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:51:41 --> Config Class Initialized
INFO - 2018-05-15 04:51:41 --> Hooks Class Initialized
INFO - 2018-05-15 04:51:41 --> Input Class Initialized
INFO - 2018-05-15 04:51:41 --> Input Class Initialized
ERROR - 2018-05-15 04:51:41 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:51:41 --> Language Class Initialized
INFO - 2018-05-15 04:51:41 --> Language Class Initialized
DEBUG - 2018-05-15 04:51:41 --> UTF-8 Support Enabled
INFO - 2018-05-15 04:51:41 --> Config Class Initialized
INFO - 2018-05-15 04:51:41 --> Hooks Class Initialized
DEBUG - 2018-05-15 04:51:41 --> UTF-8 Support Enabled
ERROR - 2018-05-15 04:51:41 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:51:41 --> Utf8 Class Initialized
ERROR - 2018-05-15 04:51:41 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:51:41 --> Utf8 Class Initialized
INFO - 2018-05-15 04:51:41 --> URI Class Initialized
INFO - 2018-05-15 04:51:41 --> Config Class Initialized
INFO - 2018-05-15 04:51:41 --> Config Class Initialized
INFO - 2018-05-15 04:51:41 --> Hooks Class Initialized
INFO - 2018-05-15 04:51:41 --> Hooks Class Initialized
INFO - 2018-05-15 04:51:41 --> URI Class Initialized
INFO - 2018-05-15 04:51:41 --> Router Class Initialized
INFO - 2018-05-15 04:51:41 --> Output Class Initialized
DEBUG - 2018-05-15 04:51:41 --> UTF-8 Support Enabled
INFO - 2018-05-15 04:51:41 --> Router Class Initialized
DEBUG - 2018-05-15 04:51:41 --> UTF-8 Support Enabled
INFO - 2018-05-15 04:51:41 --> Utf8 Class Initialized
INFO - 2018-05-15 04:51:41 --> Output Class Initialized
INFO - 2018-05-15 04:51:41 --> Utf8 Class Initialized
INFO - 2018-05-15 04:51:41 --> Security Class Initialized
INFO - 2018-05-15 04:51:41 --> Security Class Initialized
INFO - 2018-05-15 04:51:41 --> URI Class Initialized
INFO - 2018-05-15 04:51:41 --> URI Class Initialized
DEBUG - 2018-05-15 04:51:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:51:41 --> Input Class Initialized
DEBUG - 2018-05-15 04:51:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:51:41 --> Router Class Initialized
INFO - 2018-05-15 04:51:41 --> Router Class Initialized
INFO - 2018-05-15 04:51:41 --> Input Class Initialized
INFO - 2018-05-15 04:51:41 --> Output Class Initialized
INFO - 2018-05-15 04:51:41 --> Language Class Initialized
INFO - 2018-05-15 04:51:41 --> Output Class Initialized
ERROR - 2018-05-15 04:51:41 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:51:41 --> Language Class Initialized
INFO - 2018-05-15 04:51:41 --> Security Class Initialized
INFO - 2018-05-15 04:51:41 --> Security Class Initialized
DEBUG - 2018-05-15 04:51:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-15 04:51:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-05-15 04:51:41 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:51:41 --> Input Class Initialized
INFO - 2018-05-15 04:51:41 --> Input Class Initialized
INFO - 2018-05-15 04:51:41 --> Language Class Initialized
INFO - 2018-05-15 04:51:41 --> Language Class Initialized
ERROR - 2018-05-15 04:51:41 --> 404 Page Not Found: /index
ERROR - 2018-05-15 04:51:41 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:51:52 --> Config Class Initialized
INFO - 2018-05-15 04:51:52 --> Hooks Class Initialized
DEBUG - 2018-05-15 04:51:52 --> UTF-8 Support Enabled
INFO - 2018-05-15 04:51:52 --> Utf8 Class Initialized
INFO - 2018-05-15 04:51:52 --> URI Class Initialized
INFO - 2018-05-15 04:51:52 --> Config Class Initialized
INFO - 2018-05-15 04:51:52 --> Config Class Initialized
INFO - 2018-05-15 04:51:52 --> Config Class Initialized
INFO - 2018-05-15 04:51:52 --> Config Class Initialized
INFO - 2018-05-15 04:51:52 --> Config Class Initialized
INFO - 2018-05-15 04:51:52 --> Hooks Class Initialized
INFO - 2018-05-15 04:51:52 --> Hooks Class Initialized
INFO - 2018-05-15 04:51:52 --> Hooks Class Initialized
INFO - 2018-05-15 04:51:52 --> Hooks Class Initialized
INFO - 2018-05-15 04:51:52 --> Router Class Initialized
INFO - 2018-05-15 04:51:52 --> Hooks Class Initialized
DEBUG - 2018-05-15 04:51:52 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 04:51:52 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 04:51:52 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 04:51:52 --> UTF-8 Support Enabled
INFO - 2018-05-15 04:51:52 --> Output Class Initialized
INFO - 2018-05-15 04:51:52 --> Utf8 Class Initialized
INFO - 2018-05-15 04:51:52 --> Utf8 Class Initialized
INFO - 2018-05-15 04:51:52 --> Utf8 Class Initialized
INFO - 2018-05-15 04:51:52 --> Utf8 Class Initialized
DEBUG - 2018-05-15 04:51:52 --> UTF-8 Support Enabled
INFO - 2018-05-15 04:51:52 --> Security Class Initialized
INFO - 2018-05-15 04:51:52 --> URI Class Initialized
INFO - 2018-05-15 04:51:52 --> URI Class Initialized
INFO - 2018-05-15 04:51:52 --> URI Class Initialized
INFO - 2018-05-15 04:51:52 --> URI Class Initialized
INFO - 2018-05-15 04:51:52 --> Utf8 Class Initialized
DEBUG - 2018-05-15 04:51:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:51:52 --> Router Class Initialized
INFO - 2018-05-15 04:51:52 --> Router Class Initialized
INFO - 2018-05-15 04:51:52 --> Router Class Initialized
INFO - 2018-05-15 04:51:52 --> URI Class Initialized
INFO - 2018-05-15 04:51:52 --> Input Class Initialized
INFO - 2018-05-15 04:51:52 --> Router Class Initialized
INFO - 2018-05-15 04:51:52 --> Output Class Initialized
INFO - 2018-05-15 04:51:52 --> Output Class Initialized
INFO - 2018-05-15 04:51:52 --> Output Class Initialized
INFO - 2018-05-15 04:51:52 --> Language Class Initialized
INFO - 2018-05-15 04:51:52 --> Router Class Initialized
INFO - 2018-05-15 04:51:52 --> Output Class Initialized
INFO - 2018-05-15 04:51:52 --> Security Class Initialized
DEBUG - 2018-05-15 04:51:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:51:52 --> Input Class Initialized
INFO - 2018-05-15 04:51:52 --> Security Class Initialized
INFO - 2018-05-15 04:51:52 --> Output Class Initialized
ERROR - 2018-05-15 04:51:52 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:51:52 --> Security Class Initialized
INFO - 2018-05-15 04:51:52 --> Language Class Initialized
INFO - 2018-05-15 04:51:52 --> Security Class Initialized
INFO - 2018-05-15 04:51:52 --> Security Class Initialized
DEBUG - 2018-05-15 04:51:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-05-15 04:51:52 --> 404 Page Not Found: /index
DEBUG - 2018-05-15 04:51:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-15 04:51:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:51:52 --> Input Class Initialized
INFO - 2018-05-15 04:51:52 --> Input Class Initialized
INFO - 2018-05-15 04:51:52 --> Config Class Initialized
INFO - 2018-05-15 04:51:52 --> Input Class Initialized
DEBUG - 2018-05-15 04:51:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:51:53 --> Hooks Class Initialized
INFO - 2018-05-15 04:51:53 --> Language Class Initialized
INFO - 2018-05-15 04:51:53 --> Language Class Initialized
INFO - 2018-05-15 04:51:53 --> Input Class Initialized
INFO - 2018-05-15 04:51:53 --> Language Class Initialized
DEBUG - 2018-05-15 04:51:53 --> UTF-8 Support Enabled
INFO - 2018-05-15 04:51:53 --> Utf8 Class Initialized
INFO - 2018-05-15 04:51:53 --> URI Class Initialized
INFO - 2018-05-15 04:51:53 --> Router Class Initialized
INFO - 2018-05-15 04:51:53 --> Output Class Initialized
INFO - 2018-05-15 04:51:53 --> Language Class Initialized
ERROR - 2018-05-15 04:51:53 --> 404 Page Not Found: /index
ERROR - 2018-05-15 04:51:53 --> 404 Page Not Found: /index
ERROR - 2018-05-15 04:51:53 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:51:53 --> Security Class Initialized
ERROR - 2018-05-15 04:51:53 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:51:53 --> Config Class Initialized
INFO - 2018-05-15 04:51:53 --> Config Class Initialized
DEBUG - 2018-05-15 04:51:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:51:53 --> Hooks Class Initialized
INFO - 2018-05-15 04:51:53 --> Config Class Initialized
INFO - 2018-05-15 04:51:53 --> Hooks Class Initialized
DEBUG - 2018-05-15 04:51:53 --> UTF-8 Support Enabled
INFO - 2018-05-15 04:51:53 --> Hooks Class Initialized
INFO - 2018-05-15 04:51:53 --> Input Class Initialized
INFO - 2018-05-15 04:51:53 --> Language Class Initialized
DEBUG - 2018-05-15 04:51:53 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 04:51:53 --> UTF-8 Support Enabled
INFO - 2018-05-15 04:51:53 --> Utf8 Class Initialized
INFO - 2018-05-15 04:51:53 --> Utf8 Class Initialized
INFO - 2018-05-15 04:51:53 --> Utf8 Class Initialized
ERROR - 2018-05-15 04:51:53 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:51:53 --> URI Class Initialized
INFO - 2018-05-15 04:51:53 --> Router Class Initialized
INFO - 2018-05-15 04:51:53 --> URI Class Initialized
INFO - 2018-05-15 04:51:53 --> URI Class Initialized
INFO - 2018-05-15 04:51:53 --> Config Class Initialized
INFO - 2018-05-15 04:51:53 --> Hooks Class Initialized
INFO - 2018-05-15 04:51:53 --> Output Class Initialized
INFO - 2018-05-15 04:51:53 --> Router Class Initialized
INFO - 2018-05-15 04:51:53 --> Router Class Initialized
INFO - 2018-05-15 04:51:53 --> Output Class Initialized
DEBUG - 2018-05-15 04:51:53 --> UTF-8 Support Enabled
INFO - 2018-05-15 04:51:53 --> Security Class Initialized
INFO - 2018-05-15 04:51:53 --> Output Class Initialized
INFO - 2018-05-15 04:51:53 --> Utf8 Class Initialized
DEBUG - 2018-05-15 04:51:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:51:53 --> Security Class Initialized
INFO - 2018-05-15 04:51:53 --> Security Class Initialized
INFO - 2018-05-15 04:51:53 --> URI Class Initialized
INFO - 2018-05-15 04:51:53 --> Input Class Initialized
DEBUG - 2018-05-15 04:51:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-15 04:51:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:51:53 --> Input Class Initialized
INFO - 2018-05-15 04:51:53 --> Router Class Initialized
INFO - 2018-05-15 04:51:53 --> Language Class Initialized
INFO - 2018-05-15 04:51:53 --> Input Class Initialized
INFO - 2018-05-15 04:51:53 --> Output Class Initialized
INFO - 2018-05-15 04:51:53 --> Language Class Initialized
INFO - 2018-05-15 04:51:53 --> Language Class Initialized
ERROR - 2018-05-15 04:51:53 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:51:53 --> Security Class Initialized
ERROR - 2018-05-15 04:51:53 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:51:53 --> Config Class Initialized
ERROR - 2018-05-15 04:51:53 --> 404 Page Not Found: /index
DEBUG - 2018-05-15 04:51:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:51:53 --> Hooks Class Initialized
INFO - 2018-05-15 04:51:53 --> Config Class Initialized
INFO - 2018-05-15 04:51:53 --> Config Class Initialized
INFO - 2018-05-15 04:51:53 --> Hooks Class Initialized
INFO - 2018-05-15 04:51:53 --> Hooks Class Initialized
INFO - 2018-05-15 04:51:53 --> Input Class Initialized
DEBUG - 2018-05-15 04:51:53 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 04:51:53 --> UTF-8 Support Enabled
INFO - 2018-05-15 04:51:53 --> Language Class Initialized
INFO - 2018-05-15 04:51:53 --> Utf8 Class Initialized
DEBUG - 2018-05-15 04:51:53 --> UTF-8 Support Enabled
INFO - 2018-05-15 04:51:53 --> Utf8 Class Initialized
INFO - 2018-05-15 04:51:53 --> URI Class Initialized
ERROR - 2018-05-15 04:51:53 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:51:53 --> Utf8 Class Initialized
INFO - 2018-05-15 04:51:53 --> URI Class Initialized
INFO - 2018-05-15 04:51:53 --> Router Class Initialized
INFO - 2018-05-15 04:51:53 --> URI Class Initialized
INFO - 2018-05-15 04:51:53 --> Router Class Initialized
INFO - 2018-05-15 04:51:53 --> Output Class Initialized
INFO - 2018-05-15 04:51:53 --> Output Class Initialized
INFO - 2018-05-15 04:51:53 --> Router Class Initialized
INFO - 2018-05-15 04:51:53 --> Security Class Initialized
INFO - 2018-05-15 04:51:53 --> Output Class Initialized
INFO - 2018-05-15 04:51:53 --> Security Class Initialized
DEBUG - 2018-05-15 04:51:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-15 04:51:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:51:53 --> Security Class Initialized
INFO - 2018-05-15 04:51:53 --> Input Class Initialized
INFO - 2018-05-15 04:51:53 --> Input Class Initialized
DEBUG - 2018-05-15 04:51:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:51:53 --> Language Class Initialized
INFO - 2018-05-15 04:51:53 --> Language Class Initialized
INFO - 2018-05-15 04:51:53 --> Input Class Initialized
ERROR - 2018-05-15 04:51:53 --> 404 Page Not Found: /index
ERROR - 2018-05-15 04:51:53 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:51:53 --> Language Class Initialized
ERROR - 2018-05-15 04:51:53 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:53:12 --> Config Class Initialized
INFO - 2018-05-15 04:53:12 --> Hooks Class Initialized
DEBUG - 2018-05-15 04:53:12 --> UTF-8 Support Enabled
INFO - 2018-05-15 04:53:12 --> Utf8 Class Initialized
INFO - 2018-05-15 04:53:12 --> URI Class Initialized
INFO - 2018-05-15 04:53:12 --> Router Class Initialized
INFO - 2018-05-15 04:53:12 --> Output Class Initialized
INFO - 2018-05-15 04:53:12 --> Security Class Initialized
DEBUG - 2018-05-15 04:53:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:53:12 --> Input Class Initialized
INFO - 2018-05-15 04:53:12 --> Config Class Initialized
INFO - 2018-05-15 04:53:12 --> Config Class Initialized
INFO - 2018-05-15 04:53:12 --> Config Class Initialized
INFO - 2018-05-15 04:53:12 --> Config Class Initialized
INFO - 2018-05-15 04:53:12 --> Config Class Initialized
INFO - 2018-05-15 04:53:12 --> Hooks Class Initialized
INFO - 2018-05-15 04:53:12 --> Hooks Class Initialized
INFO - 2018-05-15 04:53:12 --> Hooks Class Initialized
INFO - 2018-05-15 04:53:12 --> Hooks Class Initialized
INFO - 2018-05-15 04:53:12 --> Hooks Class Initialized
INFO - 2018-05-15 04:53:12 --> Language Class Initialized
DEBUG - 2018-05-15 04:53:12 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 04:53:12 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 04:53:12 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 04:53:12 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 04:53:12 --> UTF-8 Support Enabled
ERROR - 2018-05-15 04:53:12 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:53:12 --> Utf8 Class Initialized
INFO - 2018-05-15 04:53:12 --> Utf8 Class Initialized
INFO - 2018-05-15 04:53:12 --> Utf8 Class Initialized
INFO - 2018-05-15 04:53:12 --> Utf8 Class Initialized
INFO - 2018-05-15 04:53:12 --> Utf8 Class Initialized
INFO - 2018-05-15 04:53:12 --> URI Class Initialized
INFO - 2018-05-15 04:53:12 --> URI Class Initialized
INFO - 2018-05-15 04:53:12 --> URI Class Initialized
INFO - 2018-05-15 04:53:12 --> URI Class Initialized
INFO - 2018-05-15 04:53:12 --> URI Class Initialized
INFO - 2018-05-15 04:53:12 --> Router Class Initialized
INFO - 2018-05-15 04:53:12 --> Router Class Initialized
INFO - 2018-05-15 04:53:12 --> Router Class Initialized
INFO - 2018-05-15 04:53:12 --> Router Class Initialized
INFO - 2018-05-15 04:53:12 --> Router Class Initialized
INFO - 2018-05-15 04:53:12 --> Output Class Initialized
INFO - 2018-05-15 04:53:12 --> Output Class Initialized
INFO - 2018-05-15 04:53:12 --> Output Class Initialized
INFO - 2018-05-15 04:53:12 --> Security Class Initialized
INFO - 2018-05-15 04:53:12 --> Output Class Initialized
INFO - 2018-05-15 04:53:12 --> Output Class Initialized
INFO - 2018-05-15 04:53:12 --> Security Class Initialized
DEBUG - 2018-05-15 04:53:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:53:12 --> Input Class Initialized
INFO - 2018-05-15 04:53:12 --> Language Class Initialized
ERROR - 2018-05-15 04:53:12 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:53:12 --> Security Class Initialized
INFO - 2018-05-15 04:53:12 --> Config Class Initialized
DEBUG - 2018-05-15 04:53:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:53:12 --> Security Class Initialized
INFO - 2018-05-15 04:53:12 --> Security Class Initialized
INFO - 2018-05-15 04:53:12 --> Hooks Class Initialized
DEBUG - 2018-05-15 04:53:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-15 04:53:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-15 04:53:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:53:12 --> Input Class Initialized
DEBUG - 2018-05-15 04:53:12 --> UTF-8 Support Enabled
INFO - 2018-05-15 04:53:12 --> Utf8 Class Initialized
INFO - 2018-05-15 04:53:12 --> URI Class Initialized
INFO - 2018-05-15 04:53:12 --> Router Class Initialized
INFO - 2018-05-15 04:53:12 --> Output Class Initialized
INFO - 2018-05-15 04:53:12 --> Language Class Initialized
INFO - 2018-05-15 04:53:12 --> Input Class Initialized
INFO - 2018-05-15 04:53:12 --> Input Class Initialized
INFO - 2018-05-15 04:53:12 --> Input Class Initialized
INFO - 2018-05-15 04:53:13 --> Security Class Initialized
INFO - 2018-05-15 04:53:13 --> Language Class Initialized
INFO - 2018-05-15 04:53:13 --> Language Class Initialized
INFO - 2018-05-15 04:53:13 --> Language Class Initialized
ERROR - 2018-05-15 04:53:13 --> 404 Page Not Found: /index
DEBUG - 2018-05-15 04:53:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-05-15 04:53:13 --> 404 Page Not Found: /index
ERROR - 2018-05-15 04:53:13 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:53:13 --> Config Class Initialized
INFO - 2018-05-15 04:53:13 --> Input Class Initialized
ERROR - 2018-05-15 04:53:13 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:53:13 --> Language Class Initialized
INFO - 2018-05-15 04:53:13 --> Hooks Class Initialized
INFO - 2018-05-15 04:53:13 --> Config Class Initialized
INFO - 2018-05-15 04:53:13 --> Config Class Initialized
INFO - 2018-05-15 04:53:13 --> Hooks Class Initialized
INFO - 2018-05-15 04:53:13 --> Hooks Class Initialized
ERROR - 2018-05-15 04:53:13 --> 404 Page Not Found: /index
DEBUG - 2018-05-15 04:53:13 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 04:53:13 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 04:53:13 --> UTF-8 Support Enabled
INFO - 2018-05-15 04:53:13 --> Utf8 Class Initialized
INFO - 2018-05-15 04:53:13 --> Utf8 Class Initialized
INFO - 2018-05-15 04:53:13 --> Utf8 Class Initialized
INFO - 2018-05-15 04:53:13 --> Config Class Initialized
INFO - 2018-05-15 04:53:13 --> URI Class Initialized
INFO - 2018-05-15 04:53:13 --> Hooks Class Initialized
INFO - 2018-05-15 04:53:13 --> URI Class Initialized
INFO - 2018-05-15 04:53:13 --> Router Class Initialized
INFO - 2018-05-15 04:53:13 --> URI Class Initialized
DEBUG - 2018-05-15 04:53:13 --> UTF-8 Support Enabled
INFO - 2018-05-15 04:53:13 --> Router Class Initialized
INFO - 2018-05-15 04:53:13 --> Router Class Initialized
INFO - 2018-05-15 04:53:13 --> Utf8 Class Initialized
INFO - 2018-05-15 04:53:13 --> URI Class Initialized
INFO - 2018-05-15 04:53:13 --> Router Class Initialized
INFO - 2018-05-15 04:53:13 --> Output Class Initialized
INFO - 2018-05-15 04:53:13 --> Output Class Initialized
INFO - 2018-05-15 04:53:13 --> Output Class Initialized
INFO - 2018-05-15 04:53:13 --> Security Class Initialized
DEBUG - 2018-05-15 04:53:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:53:13 --> Input Class Initialized
INFO - 2018-05-15 04:53:13 --> Language Class Initialized
ERROR - 2018-05-15 04:53:13 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:53:13 --> Security Class Initialized
INFO - 2018-05-15 04:53:13 --> Output Class Initialized
INFO - 2018-05-15 04:53:13 --> Security Class Initialized
DEBUG - 2018-05-15 04:53:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:53:13 --> Security Class Initialized
DEBUG - 2018-05-15 04:53:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:53:13 --> Input Class Initialized
INFO - 2018-05-15 04:53:13 --> Language Class Initialized
ERROR - 2018-05-15 04:53:13 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:53:13 --> Config Class Initialized
DEBUG - 2018-05-15 04:53:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:53:13 --> Input Class Initialized
INFO - 2018-05-15 04:53:13 --> Hooks Class Initialized
INFO - 2018-05-15 04:53:13 --> Input Class Initialized
DEBUG - 2018-05-15 04:53:13 --> UTF-8 Support Enabled
INFO - 2018-05-15 04:53:13 --> Language Class Initialized
INFO - 2018-05-15 04:53:13 --> Utf8 Class Initialized
INFO - 2018-05-15 04:53:13 --> Language Class Initialized
ERROR - 2018-05-15 04:53:13 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:53:13 --> URI Class Initialized
ERROR - 2018-05-15 04:53:13 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:53:13 --> Router Class Initialized
INFO - 2018-05-15 04:53:13 --> Config Class Initialized
INFO - 2018-05-15 04:53:13 --> Hooks Class Initialized
INFO - 2018-05-15 04:53:13 --> Output Class Initialized
INFO - 2018-05-15 04:53:13 --> Config Class Initialized
INFO - 2018-05-15 04:53:13 --> Hooks Class Initialized
DEBUG - 2018-05-15 04:53:13 --> UTF-8 Support Enabled
INFO - 2018-05-15 04:53:13 --> Security Class Initialized
INFO - 2018-05-15 04:53:13 --> Utf8 Class Initialized
DEBUG - 2018-05-15 04:53:13 --> UTF-8 Support Enabled
INFO - 2018-05-15 04:53:13 --> Utf8 Class Initialized
INFO - 2018-05-15 04:53:13 --> URI Class Initialized
DEBUG - 2018-05-15 04:53:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:53:13 --> URI Class Initialized
INFO - 2018-05-15 04:53:13 --> Router Class Initialized
INFO - 2018-05-15 04:53:13 --> Input Class Initialized
INFO - 2018-05-15 04:53:13 --> Output Class Initialized
INFO - 2018-05-15 04:53:13 --> Router Class Initialized
INFO - 2018-05-15 04:53:13 --> Language Class Initialized
INFO - 2018-05-15 04:53:13 --> Output Class Initialized
INFO - 2018-05-15 04:53:13 --> Security Class Initialized
INFO - 2018-05-15 04:53:13 --> Security Class Initialized
DEBUG - 2018-05-15 04:53:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-15 04:53:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:53:13 --> Input Class Initialized
INFO - 2018-05-15 04:53:13 --> Language Class Initialized
ERROR - 2018-05-15 04:53:13 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:53:13 --> Input Class Initialized
ERROR - 2018-05-15 04:53:13 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:53:13 --> Language Class Initialized
ERROR - 2018-05-15 04:53:13 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:53:15 --> Config Class Initialized
INFO - 2018-05-15 04:53:15 --> Hooks Class Initialized
DEBUG - 2018-05-15 04:53:15 --> UTF-8 Support Enabled
INFO - 2018-05-15 04:53:15 --> Utf8 Class Initialized
INFO - 2018-05-15 04:53:15 --> URI Class Initialized
INFO - 2018-05-15 04:53:15 --> Router Class Initialized
INFO - 2018-05-15 04:53:15 --> Output Class Initialized
INFO - 2018-05-15 04:53:15 --> Security Class Initialized
DEBUG - 2018-05-15 04:53:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:53:15 --> Input Class Initialized
INFO - 2018-05-15 04:53:15 --> Language Class Initialized
ERROR - 2018-05-15 04:53:15 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:54:25 --> Config Class Initialized
INFO - 2018-05-15 04:54:25 --> Hooks Class Initialized
DEBUG - 2018-05-15 04:54:25 --> UTF-8 Support Enabled
INFO - 2018-05-15 04:54:25 --> Utf8 Class Initialized
INFO - 2018-05-15 04:54:25 --> URI Class Initialized
INFO - 2018-05-15 04:54:25 --> Router Class Initialized
INFO - 2018-05-15 04:54:25 --> Output Class Initialized
INFO - 2018-05-15 04:54:25 --> Security Class Initialized
DEBUG - 2018-05-15 04:54:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:54:25 --> Input Class Initialized
INFO - 2018-05-15 04:54:25 --> Language Class Initialized
ERROR - 2018-05-15 04:54:25 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:54:25 --> Config Class Initialized
INFO - 2018-05-15 04:54:25 --> Config Class Initialized
INFO - 2018-05-15 04:54:25 --> Config Class Initialized
INFO - 2018-05-15 04:54:25 --> Config Class Initialized
INFO - 2018-05-15 04:54:25 --> Config Class Initialized
INFO - 2018-05-15 04:54:25 --> Hooks Class Initialized
INFO - 2018-05-15 04:54:25 --> Hooks Class Initialized
INFO - 2018-05-15 04:54:25 --> Hooks Class Initialized
INFO - 2018-05-15 04:54:25 --> Hooks Class Initialized
INFO - 2018-05-15 04:54:25 --> Hooks Class Initialized
DEBUG - 2018-05-15 04:54:25 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 04:54:25 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 04:54:25 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 04:54:25 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 04:54:25 --> UTF-8 Support Enabled
INFO - 2018-05-15 04:54:25 --> Utf8 Class Initialized
INFO - 2018-05-15 04:54:25 --> Utf8 Class Initialized
INFO - 2018-05-15 04:54:25 --> Utf8 Class Initialized
INFO - 2018-05-15 04:54:25 --> Utf8 Class Initialized
INFO - 2018-05-15 04:54:25 --> Utf8 Class Initialized
INFO - 2018-05-15 04:54:25 --> URI Class Initialized
INFO - 2018-05-15 04:54:25 --> URI Class Initialized
INFO - 2018-05-15 04:54:25 --> URI Class Initialized
INFO - 2018-05-15 04:54:25 --> Router Class Initialized
INFO - 2018-05-15 04:54:25 --> Router Class Initialized
INFO - 2018-05-15 04:54:25 --> URI Class Initialized
INFO - 2018-05-15 04:54:25 --> Router Class Initialized
INFO - 2018-05-15 04:54:25 --> URI Class Initialized
INFO - 2018-05-15 04:54:25 --> Output Class Initialized
INFO - 2018-05-15 04:54:25 --> Output Class Initialized
INFO - 2018-05-15 04:54:25 --> Router Class Initialized
INFO - 2018-05-15 04:54:25 --> Security Class Initialized
INFO - 2018-05-15 04:54:25 --> Security Class Initialized
INFO - 2018-05-15 04:54:25 --> Output Class Initialized
INFO - 2018-05-15 04:54:25 --> Output Class Initialized
INFO - 2018-05-15 04:54:25 --> Router Class Initialized
DEBUG - 2018-05-15 04:54:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-15 04:54:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:54:25 --> Output Class Initialized
INFO - 2018-05-15 04:54:25 --> Input Class Initialized
INFO - 2018-05-15 04:54:25 --> Security Class Initialized
INFO - 2018-05-15 04:54:25 --> Security Class Initialized
INFO - 2018-05-15 04:54:26 --> Input Class Initialized
INFO - 2018-05-15 04:54:26 --> Security Class Initialized
INFO - 2018-05-15 04:54:26 --> Language Class Initialized
DEBUG - 2018-05-15 04:54:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-15 04:54:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:54:26 --> Language Class Initialized
ERROR - 2018-05-15 04:54:26 --> 404 Page Not Found: /index
DEBUG - 2018-05-15 04:54:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:54:26 --> Input Class Initialized
INFO - 2018-05-15 04:54:26 --> Input Class Initialized
INFO - 2018-05-15 04:54:26 --> Input Class Initialized
ERROR - 2018-05-15 04:54:26 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:54:26 --> Language Class Initialized
INFO - 2018-05-15 04:54:26 --> Language Class Initialized
INFO - 2018-05-15 04:54:26 --> Language Class Initialized
ERROR - 2018-05-15 04:54:26 --> 404 Page Not Found: /index
ERROR - 2018-05-15 04:54:26 --> 404 Page Not Found: /index
ERROR - 2018-05-15 04:54:26 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:54:26 --> Config Class Initialized
INFO - 2018-05-15 04:54:26 --> Config Class Initialized
INFO - 2018-05-15 04:54:26 --> Config Class Initialized
INFO - 2018-05-15 04:54:26 --> Config Class Initialized
INFO - 2018-05-15 04:54:26 --> Hooks Class Initialized
INFO - 2018-05-15 04:54:26 --> Hooks Class Initialized
INFO - 2018-05-15 04:54:26 --> Hooks Class Initialized
INFO - 2018-05-15 04:54:26 --> Hooks Class Initialized
DEBUG - 2018-05-15 04:54:26 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 04:54:26 --> UTF-8 Support Enabled
INFO - 2018-05-15 04:54:26 --> Utf8 Class Initialized
DEBUG - 2018-05-15 04:54:26 --> UTF-8 Support Enabled
INFO - 2018-05-15 04:54:26 --> Utf8 Class Initialized
DEBUG - 2018-05-15 04:54:26 --> UTF-8 Support Enabled
INFO - 2018-05-15 04:54:26 --> URI Class Initialized
INFO - 2018-05-15 04:54:26 --> Utf8 Class Initialized
INFO - 2018-05-15 04:54:26 --> Utf8 Class Initialized
INFO - 2018-05-15 04:54:26 --> Router Class Initialized
INFO - 2018-05-15 04:54:26 --> URI Class Initialized
INFO - 2018-05-15 04:54:26 --> URI Class Initialized
INFO - 2018-05-15 04:54:26 --> URI Class Initialized
INFO - 2018-05-15 04:54:26 --> Router Class Initialized
INFO - 2018-05-15 04:54:26 --> Output Class Initialized
INFO - 2018-05-15 04:54:26 --> Router Class Initialized
INFO - 2018-05-15 04:54:26 --> Router Class Initialized
INFO - 2018-05-15 04:54:26 --> Output Class Initialized
INFO - 2018-05-15 04:54:26 --> Security Class Initialized
INFO - 2018-05-15 04:54:26 --> Output Class Initialized
INFO - 2018-05-15 04:54:26 --> Output Class Initialized
INFO - 2018-05-15 04:54:26 --> Security Class Initialized
DEBUG - 2018-05-15 04:54:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:54:26 --> Input Class Initialized
INFO - 2018-05-15 04:54:26 --> Language Class Initialized
ERROR - 2018-05-15 04:54:26 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:54:26 --> Config Class Initialized
INFO - 2018-05-15 04:54:26 --> Hooks Class Initialized
DEBUG - 2018-05-15 04:54:26 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 04:54:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:54:26 --> Security Class Initialized
INFO - 2018-05-15 04:54:26 --> Utf8 Class Initialized
INFO - 2018-05-15 04:54:26 --> Security Class Initialized
INFO - 2018-05-15 04:54:26 --> URI Class Initialized
INFO - 2018-05-15 04:54:26 --> Router Class Initialized
DEBUG - 2018-05-15 04:54:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:54:26 --> Output Class Initialized
INFO - 2018-05-15 04:54:26 --> Security Class Initialized
DEBUG - 2018-05-15 04:54:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:54:26 --> Input Class Initialized
INFO - 2018-05-15 04:54:26 --> Language Class Initialized
ERROR - 2018-05-15 04:54:26 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:54:26 --> Input Class Initialized
INFO - 2018-05-15 04:54:26 --> Input Class Initialized
DEBUG - 2018-05-15 04:54:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:54:26 --> Language Class Initialized
INFO - 2018-05-15 04:54:26 --> Input Class Initialized
INFO - 2018-05-15 04:54:26 --> Language Class Initialized
ERROR - 2018-05-15 04:54:26 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:54:26 --> Config Class Initialized
INFO - 2018-05-15 04:54:26 --> Hooks Class Initialized
INFO - 2018-05-15 04:54:26 --> Language Class Initialized
DEBUG - 2018-05-15 04:54:26 --> UTF-8 Support Enabled
ERROR - 2018-05-15 04:54:26 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:54:26 --> Utf8 Class Initialized
INFO - 2018-05-15 04:54:26 --> URI Class Initialized
INFO - 2018-05-15 04:54:26 --> Router Class Initialized
INFO - 2018-05-15 04:54:26 --> Output Class Initialized
INFO - 2018-05-15 04:54:26 --> Security Class Initialized
DEBUG - 2018-05-15 04:54:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:54:26 --> Input Class Initialized
INFO - 2018-05-15 04:54:27 --> Language Class Initialized
ERROR - 2018-05-15 04:54:27 --> 404 Page Not Found: /index
ERROR - 2018-05-15 04:54:27 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:54:27 --> Config Class Initialized
INFO - 2018-05-15 04:54:27 --> Config Class Initialized
INFO - 2018-05-15 04:54:27 --> Hooks Class Initialized
INFO - 2018-05-15 04:54:27 --> Hooks Class Initialized
DEBUG - 2018-05-15 04:54:27 --> UTF-8 Support Enabled
INFO - 2018-05-15 04:54:27 --> Utf8 Class Initialized
DEBUG - 2018-05-15 04:54:27 --> UTF-8 Support Enabled
INFO - 2018-05-15 04:54:27 --> URI Class Initialized
INFO - 2018-05-15 04:54:27 --> Utf8 Class Initialized
INFO - 2018-05-15 04:54:27 --> URI Class Initialized
INFO - 2018-05-15 04:54:27 --> Router Class Initialized
INFO - 2018-05-15 04:54:27 --> Router Class Initialized
INFO - 2018-05-15 04:54:27 --> Output Class Initialized
INFO - 2018-05-15 04:54:27 --> Output Class Initialized
INFO - 2018-05-15 04:54:27 --> Security Class Initialized
INFO - 2018-05-15 04:54:27 --> Security Class Initialized
DEBUG - 2018-05-15 04:54:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:54:27 --> Input Class Initialized
DEBUG - 2018-05-15 04:54:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:54:27 --> Language Class Initialized
INFO - 2018-05-15 04:54:27 --> Input Class Initialized
ERROR - 2018-05-15 04:54:27 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:54:27 --> Language Class Initialized
ERROR - 2018-05-15 04:54:27 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:55:34 --> Config Class Initialized
INFO - 2018-05-15 04:55:34 --> Hooks Class Initialized
DEBUG - 2018-05-15 04:55:34 --> UTF-8 Support Enabled
INFO - 2018-05-15 04:55:34 --> Utf8 Class Initialized
INFO - 2018-05-15 04:55:34 --> URI Class Initialized
INFO - 2018-05-15 04:55:34 --> Router Class Initialized
INFO - 2018-05-15 04:55:34 --> Output Class Initialized
INFO - 2018-05-15 04:55:34 --> Security Class Initialized
DEBUG - 2018-05-15 04:55:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:55:34 --> Input Class Initialized
INFO - 2018-05-15 04:55:34 --> Language Class Initialized
ERROR - 2018-05-15 04:55:34 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:55:41 --> Config Class Initialized
INFO - 2018-05-15 04:55:41 --> Hooks Class Initialized
DEBUG - 2018-05-15 04:55:41 --> UTF-8 Support Enabled
INFO - 2018-05-15 04:55:41 --> Utf8 Class Initialized
INFO - 2018-05-15 04:55:41 --> URI Class Initialized
INFO - 2018-05-15 04:55:41 --> Router Class Initialized
INFO - 2018-05-15 04:55:41 --> Output Class Initialized
INFO - 2018-05-15 04:55:41 --> Security Class Initialized
DEBUG - 2018-05-15 04:55:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:55:42 --> Input Class Initialized
INFO - 2018-05-15 04:55:42 --> Language Class Initialized
INFO - 2018-05-15 04:55:42 --> Config Class Initialized
INFO - 2018-05-15 04:55:42 --> Config Class Initialized
INFO - 2018-05-15 04:55:42 --> Config Class Initialized
INFO - 2018-05-15 04:55:42 --> Hooks Class Initialized
INFO - 2018-05-15 04:55:42 --> Hooks Class Initialized
INFO - 2018-05-15 04:55:42 --> Hooks Class Initialized
INFO - 2018-05-15 04:55:42 --> Config Class Initialized
ERROR - 2018-05-15 04:55:42 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:55:42 --> Config Class Initialized
DEBUG - 2018-05-15 04:55:42 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 04:55:42 --> UTF-8 Support Enabled
INFO - 2018-05-15 04:55:42 --> Hooks Class Initialized
INFO - 2018-05-15 04:55:42 --> Hooks Class Initialized
DEBUG - 2018-05-15 04:55:42 --> UTF-8 Support Enabled
INFO - 2018-05-15 04:55:42 --> Utf8 Class Initialized
INFO - 2018-05-15 04:55:42 --> URI Class Initialized
INFO - 2018-05-15 04:55:42 --> Router Class Initialized
INFO - 2018-05-15 04:55:42 --> Output Class Initialized
INFO - 2018-05-15 04:55:42 --> Security Class Initialized
DEBUG - 2018-05-15 04:55:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:55:42 --> Input Class Initialized
INFO - 2018-05-15 04:55:42 --> Language Class Initialized
INFO - 2018-05-15 04:55:42 --> Utf8 Class Initialized
DEBUG - 2018-05-15 04:55:42 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 04:55:42 --> UTF-8 Support Enabled
INFO - 2018-05-15 04:55:42 --> Utf8 Class Initialized
ERROR - 2018-05-15 04:55:42 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:55:42 --> URI Class Initialized
INFO - 2018-05-15 04:55:42 --> Router Class Initialized
INFO - 2018-05-15 04:55:42 --> Output Class Initialized
INFO - 2018-05-15 04:55:42 --> Config Class Initialized
INFO - 2018-05-15 04:55:42 --> URI Class Initialized
INFO - 2018-05-15 04:55:42 --> Utf8 Class Initialized
INFO - 2018-05-15 04:55:42 --> Utf8 Class Initialized
INFO - 2018-05-15 04:55:42 --> Security Class Initialized
INFO - 2018-05-15 04:55:42 --> Hooks Class Initialized
INFO - 2018-05-15 04:55:42 --> Router Class Initialized
INFO - 2018-05-15 04:55:42 --> URI Class Initialized
INFO - 2018-05-15 04:55:42 --> URI Class Initialized
DEBUG - 2018-05-15 04:55:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-15 04:55:42 --> UTF-8 Support Enabled
INFO - 2018-05-15 04:55:42 --> Router Class Initialized
INFO - 2018-05-15 04:55:42 --> Utf8 Class Initialized
INFO - 2018-05-15 04:55:42 --> Input Class Initialized
INFO - 2018-05-15 04:55:42 --> Output Class Initialized
INFO - 2018-05-15 04:55:42 --> Router Class Initialized
INFO - 2018-05-15 04:55:42 --> Language Class Initialized
INFO - 2018-05-15 04:55:42 --> URI Class Initialized
INFO - 2018-05-15 04:55:42 --> Output Class Initialized
INFO - 2018-05-15 04:55:42 --> Security Class Initialized
INFO - 2018-05-15 04:55:42 --> Output Class Initialized
DEBUG - 2018-05-15 04:55:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:55:42 --> Security Class Initialized
ERROR - 2018-05-15 04:55:42 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:55:42 --> Router Class Initialized
INFO - 2018-05-15 04:55:42 --> Security Class Initialized
INFO - 2018-05-15 04:55:42 --> Output Class Initialized
DEBUG - 2018-05-15 04:55:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:55:42 --> Input Class Initialized
DEBUG - 2018-05-15 04:55:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:55:42 --> Input Class Initialized
INFO - 2018-05-15 04:55:42 --> Input Class Initialized
INFO - 2018-05-15 04:55:42 --> Language Class Initialized
INFO - 2018-05-15 04:55:42 --> Security Class Initialized
INFO - 2018-05-15 04:55:42 --> Language Class Initialized
ERROR - 2018-05-15 04:55:42 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:55:42 --> Language Class Initialized
DEBUG - 2018-05-15 04:55:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:55:42 --> Input Class Initialized
ERROR - 2018-05-15 04:55:42 --> 404 Page Not Found: /index
ERROR - 2018-05-15 04:55:42 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:55:42 --> Language Class Initialized
ERROR - 2018-05-15 04:55:42 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:55:42 --> Config Class Initialized
INFO - 2018-05-15 04:55:42 --> Config Class Initialized
INFO - 2018-05-15 04:55:42 --> Config Class Initialized
INFO - 2018-05-15 04:55:42 --> Hooks Class Initialized
INFO - 2018-05-15 04:55:42 --> Hooks Class Initialized
INFO - 2018-05-15 04:55:42 --> Hooks Class Initialized
DEBUG - 2018-05-15 04:55:42 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 04:55:42 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 04:55:42 --> UTF-8 Support Enabled
INFO - 2018-05-15 04:55:42 --> Utf8 Class Initialized
INFO - 2018-05-15 04:55:42 --> Utf8 Class Initialized
INFO - 2018-05-15 04:55:42 --> Utf8 Class Initialized
INFO - 2018-05-15 04:55:42 --> Config Class Initialized
INFO - 2018-05-15 04:55:42 --> Hooks Class Initialized
INFO - 2018-05-15 04:55:42 --> URI Class Initialized
INFO - 2018-05-15 04:55:42 --> URI Class Initialized
INFO - 2018-05-15 04:55:42 --> URI Class Initialized
DEBUG - 2018-05-15 04:55:42 --> UTF-8 Support Enabled
INFO - 2018-05-15 04:55:42 --> Router Class Initialized
INFO - 2018-05-15 04:55:42 --> Utf8 Class Initialized
INFO - 2018-05-15 04:55:42 --> URI Class Initialized
INFO - 2018-05-15 04:55:43 --> Router Class Initialized
INFO - 2018-05-15 04:55:43 --> Output Class Initialized
INFO - 2018-05-15 04:55:43 --> Router Class Initialized
INFO - 2018-05-15 04:55:43 --> Output Class Initialized
INFO - 2018-05-15 04:55:43 --> Security Class Initialized
DEBUG - 2018-05-15 04:55:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:55:43 --> Input Class Initialized
INFO - 2018-05-15 04:55:43 --> Language Class Initialized
ERROR - 2018-05-15 04:55:43 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:55:43 --> Router Class Initialized
INFO - 2018-05-15 04:55:43 --> Output Class Initialized
INFO - 2018-05-15 04:55:43 --> Security Class Initialized
DEBUG - 2018-05-15 04:55:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:55:43 --> Security Class Initialized
INFO - 2018-05-15 04:55:43 --> Input Class Initialized
INFO - 2018-05-15 04:55:43 --> Output Class Initialized
DEBUG - 2018-05-15 04:55:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:55:43 --> Input Class Initialized
INFO - 2018-05-15 04:55:43 --> Language Class Initialized
ERROR - 2018-05-15 04:55:43 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:55:43 --> Language Class Initialized
INFO - 2018-05-15 04:55:43 --> Security Class Initialized
INFO - 2018-05-15 04:55:43 --> Config Class Initialized
INFO - 2018-05-15 04:55:43 --> Hooks Class Initialized
ERROR - 2018-05-15 04:55:43 --> 404 Page Not Found: /index
DEBUG - 2018-05-15 04:55:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-15 04:55:43 --> UTF-8 Support Enabled
INFO - 2018-05-15 04:55:43 --> Utf8 Class Initialized
INFO - 2018-05-15 04:55:43 --> Config Class Initialized
INFO - 2018-05-15 04:55:43 --> Hooks Class Initialized
INFO - 2018-05-15 04:55:43 --> URI Class Initialized
INFO - 2018-05-15 04:55:43 --> Input Class Initialized
DEBUG - 2018-05-15 04:55:43 --> UTF-8 Support Enabled
INFO - 2018-05-15 04:55:43 --> Language Class Initialized
INFO - 2018-05-15 04:55:43 --> Utf8 Class Initialized
INFO - 2018-05-15 04:55:43 --> URI Class Initialized
ERROR - 2018-05-15 04:55:43 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:55:43 --> Router Class Initialized
INFO - 2018-05-15 04:55:43 --> Router Class Initialized
INFO - 2018-05-15 04:55:43 --> Output Class Initialized
INFO - 2018-05-15 04:55:43 --> Output Class Initialized
INFO - 2018-05-15 04:55:43 --> Security Class Initialized
DEBUG - 2018-05-15 04:55:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:55:43 --> Input Class Initialized
INFO - 2018-05-15 04:55:43 --> Language Class Initialized
ERROR - 2018-05-15 04:55:43 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:55:43 --> Security Class Initialized
DEBUG - 2018-05-15 04:55:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:55:43 --> Input Class Initialized
INFO - 2018-05-15 04:55:43 --> Language Class Initialized
ERROR - 2018-05-15 04:55:43 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:55:43 --> Config Class Initialized
INFO - 2018-05-15 04:55:43 --> Hooks Class Initialized
DEBUG - 2018-05-15 04:55:43 --> UTF-8 Support Enabled
INFO - 2018-05-15 04:55:43 --> Utf8 Class Initialized
INFO - 2018-05-15 04:55:43 --> URI Class Initialized
INFO - 2018-05-15 04:55:43 --> Router Class Initialized
INFO - 2018-05-15 04:55:43 --> Output Class Initialized
INFO - 2018-05-15 04:55:44 --> Security Class Initialized
DEBUG - 2018-05-15 04:55:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:55:44 --> Input Class Initialized
INFO - 2018-05-15 04:55:44 --> Language Class Initialized
ERROR - 2018-05-15 04:55:44 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:55:50 --> Config Class Initialized
INFO - 2018-05-15 04:55:50 --> Hooks Class Initialized
DEBUG - 2018-05-15 04:55:50 --> UTF-8 Support Enabled
INFO - 2018-05-15 04:55:50 --> Utf8 Class Initialized
INFO - 2018-05-15 04:55:50 --> URI Class Initialized
INFO - 2018-05-15 04:55:50 --> Router Class Initialized
INFO - 2018-05-15 04:55:50 --> Output Class Initialized
INFO - 2018-05-15 04:55:50 --> Config Class Initialized
INFO - 2018-05-15 04:55:50 --> Config Class Initialized
INFO - 2018-05-15 04:55:50 --> Config Class Initialized
INFO - 2018-05-15 04:55:50 --> Config Class Initialized
INFO - 2018-05-15 04:55:50 --> Config Class Initialized
INFO - 2018-05-15 04:55:50 --> Hooks Class Initialized
INFO - 2018-05-15 04:55:50 --> Hooks Class Initialized
INFO - 2018-05-15 04:55:50 --> Hooks Class Initialized
INFO - 2018-05-15 04:55:50 --> Security Class Initialized
INFO - 2018-05-15 04:55:50 --> Hooks Class Initialized
INFO - 2018-05-15 04:55:50 --> Hooks Class Initialized
DEBUG - 2018-05-15 04:55:50 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 04:55:50 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 04:55:50 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 04:55:50 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 04:55:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-15 04:55:50 --> UTF-8 Support Enabled
INFO - 2018-05-15 04:55:50 --> Utf8 Class Initialized
INFO - 2018-05-15 04:55:50 --> URI Class Initialized
INFO - 2018-05-15 04:55:50 --> Utf8 Class Initialized
INFO - 2018-05-15 04:55:50 --> Utf8 Class Initialized
INFO - 2018-05-15 04:55:50 --> Utf8 Class Initialized
INFO - 2018-05-15 04:55:50 --> Utf8 Class Initialized
INFO - 2018-05-15 04:55:50 --> Input Class Initialized
INFO - 2018-05-15 04:55:50 --> URI Class Initialized
INFO - 2018-05-15 04:55:50 --> URI Class Initialized
INFO - 2018-05-15 04:55:50 --> Router Class Initialized
INFO - 2018-05-15 04:55:50 --> Language Class Initialized
INFO - 2018-05-15 04:55:50 --> URI Class Initialized
INFO - 2018-05-15 04:55:50 --> URI Class Initialized
INFO - 2018-05-15 04:55:50 --> Output Class Initialized
ERROR - 2018-05-15 04:55:50 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:55:50 --> Router Class Initialized
INFO - 2018-05-15 04:55:50 --> Router Class Initialized
INFO - 2018-05-15 04:55:50 --> Router Class Initialized
INFO - 2018-05-15 04:55:50 --> Router Class Initialized
INFO - 2018-05-15 04:55:50 --> Output Class Initialized
INFO - 2018-05-15 04:55:50 --> Config Class Initialized
INFO - 2018-05-15 04:55:50 --> Output Class Initialized
INFO - 2018-05-15 04:55:50 --> Output Class Initialized
INFO - 2018-05-15 04:55:50 --> Output Class Initialized
INFO - 2018-05-15 04:55:50 --> Security Class Initialized
INFO - 2018-05-15 04:55:50 --> Hooks Class Initialized
INFO - 2018-05-15 04:55:50 --> Security Class Initialized
INFO - 2018-05-15 04:55:50 --> Security Class Initialized
INFO - 2018-05-15 04:55:50 --> Security Class Initialized
DEBUG - 2018-05-15 04:55:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:55:50 --> Security Class Initialized
DEBUG - 2018-05-15 04:55:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-15 04:55:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:55:50 --> Input Class Initialized
DEBUG - 2018-05-15 04:55:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-15 04:55:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-15 04:55:50 --> UTF-8 Support Enabled
INFO - 2018-05-15 04:55:50 --> Utf8 Class Initialized
INFO - 2018-05-15 04:55:50 --> Input Class Initialized
INFO - 2018-05-15 04:55:50 --> Language Class Initialized
INFO - 2018-05-15 04:55:50 --> Input Class Initialized
INFO - 2018-05-15 04:55:50 --> Input Class Initialized
INFO - 2018-05-15 04:55:50 --> Input Class Initialized
INFO - 2018-05-15 04:55:50 --> URI Class Initialized
INFO - 2018-05-15 04:55:50 --> Router Class Initialized
INFO - 2018-05-15 04:55:50 --> Output Class Initialized
INFO - 2018-05-15 04:55:50 --> Security Class Initialized
DEBUG - 2018-05-15 04:55:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:55:50 --> Language Class Initialized
INFO - 2018-05-15 04:55:50 --> Language Class Initialized
INFO - 2018-05-15 04:55:50 --> Language Class Initialized
ERROR - 2018-05-15 04:55:50 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:55:50 --> Language Class Initialized
INFO - 2018-05-15 04:55:50 --> Input Class Initialized
ERROR - 2018-05-15 04:55:50 --> 404 Page Not Found: /index
ERROR - 2018-05-15 04:55:50 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:55:50 --> Language Class Initialized
ERROR - 2018-05-15 04:55:50 --> 404 Page Not Found: /index
ERROR - 2018-05-15 04:55:50 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:55:50 --> Config Class Initialized
INFO - 2018-05-15 04:55:50 --> Hooks Class Initialized
INFO - 2018-05-15 04:55:51 --> Config Class Initialized
INFO - 2018-05-15 04:55:51 --> Hooks Class Initialized
ERROR - 2018-05-15 04:55:51 --> 404 Page Not Found: /index
DEBUG - 2018-05-15 04:55:51 --> UTF-8 Support Enabled
INFO - 2018-05-15 04:55:51 --> Config Class Initialized
INFO - 2018-05-15 04:55:51 --> Hooks Class Initialized
DEBUG - 2018-05-15 04:55:51 --> UTF-8 Support Enabled
INFO - 2018-05-15 04:55:51 --> Utf8 Class Initialized
DEBUG - 2018-05-15 04:55:51 --> UTF-8 Support Enabled
INFO - 2018-05-15 04:55:51 --> Config Class Initialized
INFO - 2018-05-15 04:55:51 --> Config Class Initialized
INFO - 2018-05-15 04:55:51 --> URI Class Initialized
INFO - 2018-05-15 04:55:51 --> Utf8 Class Initialized
INFO - 2018-05-15 04:55:51 --> Utf8 Class Initialized
INFO - 2018-05-15 04:55:51 --> Hooks Class Initialized
INFO - 2018-05-15 04:55:51 --> URI Class Initialized
INFO - 2018-05-15 04:55:51 --> Hooks Class Initialized
INFO - 2018-05-15 04:55:51 --> Router Class Initialized
INFO - 2018-05-15 04:55:51 --> URI Class Initialized
DEBUG - 2018-05-15 04:55:51 --> UTF-8 Support Enabled
INFO - 2018-05-15 04:55:51 --> Utf8 Class Initialized
INFO - 2018-05-15 04:55:51 --> Router Class Initialized
INFO - 2018-05-15 04:55:51 --> Output Class Initialized
DEBUG - 2018-05-15 04:55:51 --> UTF-8 Support Enabled
INFO - 2018-05-15 04:55:51 --> Router Class Initialized
INFO - 2018-05-15 04:55:51 --> Utf8 Class Initialized
INFO - 2018-05-15 04:55:51 --> URI Class Initialized
INFO - 2018-05-15 04:55:51 --> Output Class Initialized
INFO - 2018-05-15 04:55:51 --> Security Class Initialized
INFO - 2018-05-15 04:55:51 --> Output Class Initialized
INFO - 2018-05-15 04:55:51 --> Security Class Initialized
DEBUG - 2018-05-15 04:55:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:55:51 --> URI Class Initialized
INFO - 2018-05-15 04:55:51 --> Security Class Initialized
INFO - 2018-05-15 04:55:51 --> Router Class Initialized
INFO - 2018-05-15 04:55:51 --> Output Class Initialized
DEBUG - 2018-05-15 04:55:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-15 04:55:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:55:51 --> Input Class Initialized
INFO - 2018-05-15 04:55:51 --> Router Class Initialized
INFO - 2018-05-15 04:55:51 --> Output Class Initialized
INFO - 2018-05-15 04:55:51 --> Language Class Initialized
INFO - 2018-05-15 04:55:51 --> Input Class Initialized
INFO - 2018-05-15 04:55:51 --> Input Class Initialized
INFO - 2018-05-15 04:55:51 --> Security Class Initialized
INFO - 2018-05-15 04:55:51 --> Security Class Initialized
DEBUG - 2018-05-15 04:55:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:55:51 --> Language Class Initialized
INFO - 2018-05-15 04:55:51 --> Language Class Initialized
ERROR - 2018-05-15 04:55:51 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:55:51 --> Input Class Initialized
ERROR - 2018-05-15 04:55:51 --> 404 Page Not Found: /index
ERROR - 2018-05-15 04:55:51 --> 404 Page Not Found: /index
DEBUG - 2018-05-15 04:55:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:55:51 --> Language Class Initialized
INFO - 2018-05-15 04:55:51 --> Input Class Initialized
ERROR - 2018-05-15 04:55:51 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:55:51 --> Language Class Initialized
ERROR - 2018-05-15 04:55:51 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:55:51 --> Config Class Initialized
INFO - 2018-05-15 04:55:51 --> Config Class Initialized
INFO - 2018-05-15 04:55:51 --> Config Class Initialized
INFO - 2018-05-15 04:55:51 --> Config Class Initialized
INFO - 2018-05-15 04:55:51 --> Config Class Initialized
INFO - 2018-05-15 04:55:51 --> Hooks Class Initialized
INFO - 2018-05-15 04:55:51 --> Hooks Class Initialized
INFO - 2018-05-15 04:55:51 --> Hooks Class Initialized
INFO - 2018-05-15 04:55:51 --> Hooks Class Initialized
INFO - 2018-05-15 04:55:51 --> Hooks Class Initialized
DEBUG - 2018-05-15 04:55:51 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 04:55:51 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 04:55:51 --> UTF-8 Support Enabled
INFO - 2018-05-15 04:55:51 --> Utf8 Class Initialized
DEBUG - 2018-05-15 04:55:51 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 04:55:51 --> UTF-8 Support Enabled
INFO - 2018-05-15 04:55:51 --> Utf8 Class Initialized
INFO - 2018-05-15 04:55:51 --> Utf8 Class Initialized
INFO - 2018-05-15 04:55:51 --> Utf8 Class Initialized
INFO - 2018-05-15 04:55:51 --> URI Class Initialized
INFO - 2018-05-15 04:55:51 --> URI Class Initialized
INFO - 2018-05-15 04:55:51 --> Utf8 Class Initialized
INFO - 2018-05-15 04:55:51 --> URI Class Initialized
INFO - 2018-05-15 04:55:51 --> URI Class Initialized
INFO - 2018-05-15 04:55:51 --> URI Class Initialized
INFO - 2018-05-15 04:55:51 --> Router Class Initialized
INFO - 2018-05-15 04:55:51 --> Router Class Initialized
INFO - 2018-05-15 04:55:51 --> Router Class Initialized
INFO - 2018-05-15 04:55:51 --> Router Class Initialized
INFO - 2018-05-15 04:55:51 --> Router Class Initialized
INFO - 2018-05-15 04:55:51 --> Output Class Initialized
INFO - 2018-05-15 04:55:51 --> Output Class Initialized
INFO - 2018-05-15 04:55:51 --> Output Class Initialized
INFO - 2018-05-15 04:55:51 --> Output Class Initialized
INFO - 2018-05-15 04:55:51 --> Output Class Initialized
INFO - 2018-05-15 04:55:51 --> Security Class Initialized
INFO - 2018-05-15 04:55:51 --> Security Class Initialized
DEBUG - 2018-05-15 04:55:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:55:51 --> Security Class Initialized
DEBUG - 2018-05-15 04:55:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:55:51 --> Security Class Initialized
INFO - 2018-05-15 04:55:51 --> Security Class Initialized
DEBUG - 2018-05-15 04:55:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:55:51 --> Input Class Initialized
INFO - 2018-05-15 04:55:51 --> Input Class Initialized
DEBUG - 2018-05-15 04:55:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-15 04:55:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:55:51 --> Input Class Initialized
INFO - 2018-05-15 04:55:51 --> Input Class Initialized
INFO - 2018-05-15 04:55:51 --> Language Class Initialized
INFO - 2018-05-15 04:55:51 --> Input Class Initialized
INFO - 2018-05-15 04:55:51 --> Language Class Initialized
INFO - 2018-05-15 04:55:51 --> Language Class Initialized
ERROR - 2018-05-15 04:55:51 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:55:51 --> Language Class Initialized
INFO - 2018-05-15 04:55:51 --> Language Class Initialized
ERROR - 2018-05-15 04:55:51 --> 404 Page Not Found: /index
ERROR - 2018-05-15 04:55:51 --> 404 Page Not Found: /index
ERROR - 2018-05-15 04:55:51 --> 404 Page Not Found: /index
ERROR - 2018-05-15 04:55:51 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:56:09 --> Config Class Initialized
INFO - 2018-05-15 04:56:09 --> Hooks Class Initialized
DEBUG - 2018-05-15 04:56:09 --> UTF-8 Support Enabled
INFO - 2018-05-15 04:56:09 --> Utf8 Class Initialized
INFO - 2018-05-15 04:56:09 --> URI Class Initialized
INFO - 2018-05-15 04:56:09 --> Router Class Initialized
INFO - 2018-05-15 04:56:09 --> Output Class Initialized
INFO - 2018-05-15 04:56:09 --> Security Class Initialized
DEBUG - 2018-05-15 04:56:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:56:09 --> Input Class Initialized
INFO - 2018-05-15 04:56:09 --> Language Class Initialized
ERROR - 2018-05-15 04:56:09 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:56:09 --> Config Class Initialized
INFO - 2018-05-15 04:56:09 --> Config Class Initialized
INFO - 2018-05-15 04:56:09 --> Hooks Class Initialized
INFO - 2018-05-15 04:56:09 --> Config Class Initialized
INFO - 2018-05-15 04:56:09 --> Config Class Initialized
INFO - 2018-05-15 04:56:09 --> Hooks Class Initialized
INFO - 2018-05-15 04:56:09 --> Config Class Initialized
INFO - 2018-05-15 04:56:09 --> Config Class Initialized
INFO - 2018-05-15 04:56:09 --> Hooks Class Initialized
INFO - 2018-05-15 04:56:09 --> Hooks Class Initialized
DEBUG - 2018-05-15 04:56:09 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 04:56:09 --> UTF-8 Support Enabled
INFO - 2018-05-15 04:56:09 --> Hooks Class Initialized
INFO - 2018-05-15 04:56:09 --> Hooks Class Initialized
DEBUG - 2018-05-15 04:56:09 --> UTF-8 Support Enabled
INFO - 2018-05-15 04:56:09 --> Utf8 Class Initialized
INFO - 2018-05-15 04:56:09 --> URI Class Initialized
DEBUG - 2018-05-15 04:56:09 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 04:56:09 --> UTF-8 Support Enabled
INFO - 2018-05-15 04:56:09 --> Utf8 Class Initialized
INFO - 2018-05-15 04:56:09 --> Utf8 Class Initialized
INFO - 2018-05-15 04:56:09 --> Router Class Initialized
DEBUG - 2018-05-15 04:56:09 --> UTF-8 Support Enabled
INFO - 2018-05-15 04:56:09 --> Utf8 Class Initialized
INFO - 2018-05-15 04:56:09 --> Utf8 Class Initialized
INFO - 2018-05-15 04:56:09 --> Utf8 Class Initialized
INFO - 2018-05-15 04:56:09 --> URI Class Initialized
INFO - 2018-05-15 04:56:09 --> URI Class Initialized
INFO - 2018-05-15 04:56:09 --> Output Class Initialized
INFO - 2018-05-15 04:56:09 --> URI Class Initialized
INFO - 2018-05-15 04:56:09 --> URI Class Initialized
INFO - 2018-05-15 04:56:09 --> Router Class Initialized
INFO - 2018-05-15 04:56:09 --> Security Class Initialized
INFO - 2018-05-15 04:56:09 --> Router Class Initialized
INFO - 2018-05-15 04:56:09 --> URI Class Initialized
INFO - 2018-05-15 04:56:09 --> Router Class Initialized
INFO - 2018-05-15 04:56:09 --> Output Class Initialized
INFO - 2018-05-15 04:56:09 --> Router Class Initialized
DEBUG - 2018-05-15 04:56:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:56:09 --> Output Class Initialized
INFO - 2018-05-15 04:56:09 --> Security Class Initialized
INFO - 2018-05-15 04:56:09 --> Router Class Initialized
INFO - 2018-05-15 04:56:09 --> Output Class Initialized
INFO - 2018-05-15 04:56:09 --> Output Class Initialized
INFO - 2018-05-15 04:56:09 --> Security Class Initialized
INFO - 2018-05-15 04:56:09 --> Output Class Initialized
DEBUG - 2018-05-15 04:56:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:56:09 --> Input Class Initialized
INFO - 2018-05-15 04:56:09 --> Security Class Initialized
DEBUG - 2018-05-15 04:56:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:56:09 --> Language Class Initialized
INFO - 2018-05-15 04:56:09 --> Input Class Initialized
INFO - 2018-05-15 04:56:09 --> Security Class Initialized
INFO - 2018-05-15 04:56:09 --> Security Class Initialized
DEBUG - 2018-05-15 04:56:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:56:09 --> Input Class Initialized
ERROR - 2018-05-15 04:56:09 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:56:09 --> Input Class Initialized
DEBUG - 2018-05-15 04:56:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-15 04:56:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:56:09 --> Language Class Initialized
INFO - 2018-05-15 04:56:09 --> Language Class Initialized
INFO - 2018-05-15 04:56:09 --> Language Class Initialized
ERROR - 2018-05-15 04:56:09 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:56:09 --> Input Class Initialized
INFO - 2018-05-15 04:56:09 --> Input Class Initialized
INFO - 2018-05-15 04:56:09 --> Config Class Initialized
INFO - 2018-05-15 04:56:09 --> Hooks Class Initialized
ERROR - 2018-05-15 04:56:09 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:56:09 --> Language Class Initialized
INFO - 2018-05-15 04:56:09 --> Language Class Initialized
INFO - 2018-05-15 04:56:09 --> Config Class Initialized
ERROR - 2018-05-15 04:56:09 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:56:09 --> Hooks Class Initialized
DEBUG - 2018-05-15 04:56:09 --> UTF-8 Support Enabled
INFO - 2018-05-15 04:56:09 --> Utf8 Class Initialized
DEBUG - 2018-05-15 04:56:09 --> UTF-8 Support Enabled
ERROR - 2018-05-15 04:56:09 --> 404 Page Not Found: /index
ERROR - 2018-05-15 04:56:09 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:56:09 --> URI Class Initialized
INFO - 2018-05-15 04:56:09 --> Router Class Initialized
INFO - 2018-05-15 04:56:09 --> Utf8 Class Initialized
INFO - 2018-05-15 04:56:09 --> Output Class Initialized
INFO - 2018-05-15 04:56:10 --> URI Class Initialized
INFO - 2018-05-15 04:56:10 --> Config Class Initialized
INFO - 2018-05-15 04:56:10 --> Hooks Class Initialized
INFO - 2018-05-15 04:56:10 --> Router Class Initialized
INFO - 2018-05-15 04:56:10 --> Security Class Initialized
DEBUG - 2018-05-15 04:56:10 --> UTF-8 Support Enabled
INFO - 2018-05-15 04:56:10 --> Config Class Initialized
INFO - 2018-05-15 04:56:10 --> Config Class Initialized
INFO - 2018-05-15 04:56:10 --> Output Class Initialized
INFO - 2018-05-15 04:56:10 --> Hooks Class Initialized
INFO - 2018-05-15 04:56:10 --> Hooks Class Initialized
INFO - 2018-05-15 04:56:10 --> Utf8 Class Initialized
INFO - 2018-05-15 04:56:10 --> Security Class Initialized
DEBUG - 2018-05-15 04:56:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-15 04:56:10 --> UTF-8 Support Enabled
INFO - 2018-05-15 04:56:10 --> Input Class Initialized
DEBUG - 2018-05-15 04:56:10 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 04:56:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:56:10 --> URI Class Initialized
INFO - 2018-05-15 04:56:10 --> Language Class Initialized
INFO - 2018-05-15 04:56:10 --> Utf8 Class Initialized
INFO - 2018-05-15 04:56:10 --> Input Class Initialized
INFO - 2018-05-15 04:56:10 --> Utf8 Class Initialized
INFO - 2018-05-15 04:56:10 --> Router Class Initialized
ERROR - 2018-05-15 04:56:10 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:56:10 --> Language Class Initialized
INFO - 2018-05-15 04:56:10 --> URI Class Initialized
INFO - 2018-05-15 04:56:10 --> Output Class Initialized
INFO - 2018-05-15 04:56:10 --> URI Class Initialized
INFO - 2018-05-15 04:56:10 --> Router Class Initialized
INFO - 2018-05-15 04:56:10 --> Config Class Initialized
INFO - 2018-05-15 04:56:10 --> Hooks Class Initialized
INFO - 2018-05-15 04:56:10 --> Output Class Initialized
ERROR - 2018-05-15 04:56:10 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:56:10 --> Router Class Initialized
INFO - 2018-05-15 04:56:10 --> Security Class Initialized
DEBUG - 2018-05-15 04:56:10 --> UTF-8 Support Enabled
INFO - 2018-05-15 04:56:10 --> Utf8 Class Initialized
DEBUG - 2018-05-15 04:56:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:56:10 --> URI Class Initialized
INFO - 2018-05-15 04:56:10 --> Security Class Initialized
INFO - 2018-05-15 04:56:10 --> Output Class Initialized
INFO - 2018-05-15 04:56:10 --> Config Class Initialized
INFO - 2018-05-15 04:56:10 --> Hooks Class Initialized
INFO - 2018-05-15 04:56:10 --> Input Class Initialized
INFO - 2018-05-15 04:56:10 --> Security Class Initialized
DEBUG - 2018-05-15 04:56:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:56:10 --> Router Class Initialized
INFO - 2018-05-15 04:56:10 --> Language Class Initialized
INFO - 2018-05-15 04:56:10 --> Output Class Initialized
DEBUG - 2018-05-15 04:56:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:56:10 --> Input Class Initialized
DEBUG - 2018-05-15 04:56:10 --> UTF-8 Support Enabled
INFO - 2018-05-15 04:56:10 --> Utf8 Class Initialized
INFO - 2018-05-15 04:56:10 --> Security Class Initialized
INFO - 2018-05-15 04:56:10 --> Input Class Initialized
ERROR - 2018-05-15 04:56:10 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:56:10 --> Language Class Initialized
INFO - 2018-05-15 04:56:10 --> Language Class Initialized
INFO - 2018-05-15 04:56:10 --> URI Class Initialized
DEBUG - 2018-05-15 04:56:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-05-15 04:56:10 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:56:10 --> Config Class Initialized
INFO - 2018-05-15 04:56:10 --> Hooks Class Initialized
ERROR - 2018-05-15 04:56:10 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:56:10 --> Input Class Initialized
INFO - 2018-05-15 04:56:10 --> Router Class Initialized
INFO - 2018-05-15 04:56:10 --> Config Class Initialized
INFO - 2018-05-15 04:56:10 --> Hooks Class Initialized
DEBUG - 2018-05-15 04:56:10 --> UTF-8 Support Enabled
INFO - 2018-05-15 04:56:10 --> Output Class Initialized
INFO - 2018-05-15 04:56:10 --> Language Class Initialized
INFO - 2018-05-15 04:56:10 --> Config Class Initialized
DEBUG - 2018-05-15 04:56:10 --> UTF-8 Support Enabled
INFO - 2018-05-15 04:56:10 --> Hooks Class Initialized
INFO - 2018-05-15 04:56:10 --> Utf8 Class Initialized
INFO - 2018-05-15 04:56:10 --> Utf8 Class Initialized
INFO - 2018-05-15 04:56:10 --> Security Class Initialized
ERROR - 2018-05-15 04:56:10 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:56:10 --> URI Class Initialized
INFO - 2018-05-15 04:56:10 --> URI Class Initialized
DEBUG - 2018-05-15 04:56:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-15 04:56:10 --> UTF-8 Support Enabled
INFO - 2018-05-15 04:56:10 --> Input Class Initialized
INFO - 2018-05-15 04:56:10 --> Utf8 Class Initialized
INFO - 2018-05-15 04:56:10 --> Router Class Initialized
INFO - 2018-05-15 04:56:10 --> Router Class Initialized
INFO - 2018-05-15 04:56:10 --> URI Class Initialized
INFO - 2018-05-15 04:56:10 --> Language Class Initialized
INFO - 2018-05-15 04:56:10 --> Output Class Initialized
INFO - 2018-05-15 04:56:10 --> Output Class Initialized
INFO - 2018-05-15 04:56:10 --> Security Class Initialized
ERROR - 2018-05-15 04:56:10 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:56:10 --> Security Class Initialized
INFO - 2018-05-15 04:56:10 --> Router Class Initialized
INFO - 2018-05-15 04:56:10 --> Output Class Initialized
DEBUG - 2018-05-15 04:56:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:56:10 --> Security Class Initialized
DEBUG - 2018-05-15 04:56:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-15 04:56:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:56:10 --> Input Class Initialized
INFO - 2018-05-15 04:56:10 --> Input Class Initialized
INFO - 2018-05-15 04:56:10 --> Input Class Initialized
INFO - 2018-05-15 04:56:10 --> Language Class Initialized
INFO - 2018-05-15 04:56:10 --> Language Class Initialized
ERROR - 2018-05-15 04:56:10 --> 404 Page Not Found: /index
ERROR - 2018-05-15 04:56:10 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:56:10 --> Language Class Initialized
ERROR - 2018-05-15 04:56:10 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:56:16 --> Config Class Initialized
INFO - 2018-05-15 04:56:16 --> Hooks Class Initialized
DEBUG - 2018-05-15 04:56:16 --> UTF-8 Support Enabled
INFO - 2018-05-15 04:56:16 --> Utf8 Class Initialized
INFO - 2018-05-15 04:56:16 --> Config Class Initialized
INFO - 2018-05-15 04:56:16 --> Config Class Initialized
INFO - 2018-05-15 04:56:16 --> Config Class Initialized
INFO - 2018-05-15 04:56:16 --> Config Class Initialized
INFO - 2018-05-15 04:56:16 --> Config Class Initialized
INFO - 2018-05-15 04:56:16 --> Hooks Class Initialized
INFO - 2018-05-15 04:56:16 --> Hooks Class Initialized
INFO - 2018-05-15 04:56:16 --> Hooks Class Initialized
INFO - 2018-05-15 04:56:16 --> Hooks Class Initialized
INFO - 2018-05-15 04:56:16 --> Hooks Class Initialized
INFO - 2018-05-15 04:56:16 --> URI Class Initialized
DEBUG - 2018-05-15 04:56:16 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 04:56:16 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 04:56:16 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 04:56:16 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 04:56:16 --> UTF-8 Support Enabled
INFO - 2018-05-15 04:56:16 --> Router Class Initialized
INFO - 2018-05-15 04:56:16 --> Utf8 Class Initialized
INFO - 2018-05-15 04:56:16 --> Utf8 Class Initialized
INFO - 2018-05-15 04:56:16 --> Utf8 Class Initialized
INFO - 2018-05-15 04:56:16 --> Utf8 Class Initialized
INFO - 2018-05-15 04:56:16 --> Utf8 Class Initialized
INFO - 2018-05-15 04:56:16 --> Output Class Initialized
INFO - 2018-05-15 04:56:16 --> URI Class Initialized
INFO - 2018-05-15 04:56:16 --> Security Class Initialized
INFO - 2018-05-15 04:56:16 --> URI Class Initialized
INFO - 2018-05-15 04:56:16 --> URI Class Initialized
INFO - 2018-05-15 04:56:16 --> URI Class Initialized
INFO - 2018-05-15 04:56:16 --> Router Class Initialized
INFO - 2018-05-15 04:56:16 --> URI Class Initialized
DEBUG - 2018-05-15 04:56:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:56:17 --> Input Class Initialized
INFO - 2018-05-15 04:56:17 --> Language Class Initialized
ERROR - 2018-05-15 04:56:17 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:56:17 --> Router Class Initialized
INFO - 2018-05-15 04:56:17 --> Router Class Initialized
INFO - 2018-05-15 04:56:17 --> Output Class Initialized
INFO - 2018-05-15 04:56:17 --> Router Class Initialized
INFO - 2018-05-15 04:56:17 --> Router Class Initialized
INFO - 2018-05-15 04:56:17 --> Config Class Initialized
INFO - 2018-05-15 04:56:17 --> Hooks Class Initialized
INFO - 2018-05-15 04:56:17 --> Output Class Initialized
INFO - 2018-05-15 04:56:17 --> Security Class Initialized
INFO - 2018-05-15 04:56:17 --> Output Class Initialized
INFO - 2018-05-15 04:56:17 --> Output Class Initialized
INFO - 2018-05-15 04:56:17 --> Output Class Initialized
DEBUG - 2018-05-15 04:56:17 --> UTF-8 Support Enabled
INFO - 2018-05-15 04:56:17 --> Security Class Initialized
INFO - 2018-05-15 04:56:17 --> Security Class Initialized
DEBUG - 2018-05-15 04:56:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:56:17 --> Security Class Initialized
INFO - 2018-05-15 04:56:17 --> Security Class Initialized
DEBUG - 2018-05-15 04:56:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:56:17 --> Utf8 Class Initialized
INFO - 2018-05-15 04:56:17 --> Input Class Initialized
DEBUG - 2018-05-15 04:56:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-15 04:56:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-15 04:56:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:56:17 --> Input Class Initialized
INFO - 2018-05-15 04:56:17 --> Language Class Initialized
INFO - 2018-05-15 04:56:17 --> Input Class Initialized
INFO - 2018-05-15 04:56:17 --> Input Class Initialized
INFO - 2018-05-15 04:56:17 --> URI Class Initialized
INFO - 2018-05-15 04:56:17 --> Input Class Initialized
ERROR - 2018-05-15 04:56:17 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:56:17 --> Router Class Initialized
INFO - 2018-05-15 04:56:17 --> Language Class Initialized
INFO - 2018-05-15 04:56:17 --> Language Class Initialized
INFO - 2018-05-15 04:56:17 --> Language Class Initialized
INFO - 2018-05-15 04:56:17 --> Language Class Initialized
ERROR - 2018-05-15 04:56:17 --> 404 Page Not Found: /index
ERROR - 2018-05-15 04:56:17 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:56:17 --> Config Class Initialized
INFO - 2018-05-15 04:56:17 --> Output Class Initialized
ERROR - 2018-05-15 04:56:17 --> 404 Page Not Found: /index
ERROR - 2018-05-15 04:56:17 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:56:17 --> Hooks Class Initialized
DEBUG - 2018-05-15 04:56:17 --> UTF-8 Support Enabled
INFO - 2018-05-15 04:56:17 --> Utf8 Class Initialized
INFO - 2018-05-15 04:56:17 --> Config Class Initialized
INFO - 2018-05-15 04:56:17 --> Hooks Class Initialized
INFO - 2018-05-15 04:56:17 --> URI Class Initialized
DEBUG - 2018-05-15 04:56:17 --> UTF-8 Support Enabled
INFO - 2018-05-15 04:56:17 --> Router Class Initialized
INFO - 2018-05-15 04:56:17 --> Config Class Initialized
INFO - 2018-05-15 04:56:17 --> Utf8 Class Initialized
INFO - 2018-05-15 04:56:17 --> Security Class Initialized
INFO - 2018-05-15 04:56:17 --> Config Class Initialized
INFO - 2018-05-15 04:56:17 --> URI Class Initialized
INFO - 2018-05-15 04:56:17 --> Hooks Class Initialized
INFO - 2018-05-15 04:56:17 --> Hooks Class Initialized
DEBUG - 2018-05-15 04:56:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:56:17 --> Output Class Initialized
INFO - 2018-05-15 04:56:17 --> Router Class Initialized
DEBUG - 2018-05-15 04:56:17 --> UTF-8 Support Enabled
INFO - 2018-05-15 04:56:17 --> Input Class Initialized
INFO - 2018-05-15 04:56:17 --> Security Class Initialized
DEBUG - 2018-05-15 04:56:17 --> UTF-8 Support Enabled
INFO - 2018-05-15 04:56:17 --> Utf8 Class Initialized
INFO - 2018-05-15 04:56:17 --> Output Class Initialized
INFO - 2018-05-15 04:56:17 --> Utf8 Class Initialized
INFO - 2018-05-15 04:56:17 --> Language Class Initialized
DEBUG - 2018-05-15 04:56:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-05-15 04:56:17 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:56:17 --> URI Class Initialized
INFO - 2018-05-15 04:56:17 --> URI Class Initialized
INFO - 2018-05-15 04:56:17 --> Security Class Initialized
INFO - 2018-05-15 04:56:17 --> Input Class Initialized
INFO - 2018-05-15 04:56:17 --> Router Class Initialized
INFO - 2018-05-15 04:56:17 --> Router Class Initialized
DEBUG - 2018-05-15 04:56:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:56:17 --> Language Class Initialized
INFO - 2018-05-15 04:56:17 --> Config Class Initialized
INFO - 2018-05-15 04:56:17 --> Hooks Class Initialized
INFO - 2018-05-15 04:56:17 --> Input Class Initialized
INFO - 2018-05-15 04:56:17 --> Output Class Initialized
INFO - 2018-05-15 04:56:17 --> Output Class Initialized
ERROR - 2018-05-15 04:56:17 --> 404 Page Not Found: /index
DEBUG - 2018-05-15 04:56:17 --> UTF-8 Support Enabled
INFO - 2018-05-15 04:56:17 --> Config Class Initialized
INFO - 2018-05-15 04:56:17 --> Security Class Initialized
INFO - 2018-05-15 04:56:17 --> Hooks Class Initialized
INFO - 2018-05-15 04:56:17 --> Security Class Initialized
DEBUG - 2018-05-15 04:56:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:56:17 --> Language Class Initialized
INFO - 2018-05-15 04:56:17 --> Utf8 Class Initialized
INFO - 2018-05-15 04:56:17 --> Input Class Initialized
DEBUG - 2018-05-15 04:56:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-05-15 04:56:17 --> 404 Page Not Found: /index
DEBUG - 2018-05-15 04:56:17 --> UTF-8 Support Enabled
INFO - 2018-05-15 04:56:17 --> URI Class Initialized
INFO - 2018-05-15 04:56:17 --> Utf8 Class Initialized
INFO - 2018-05-15 04:56:17 --> Input Class Initialized
INFO - 2018-05-15 04:56:17 --> Config Class Initialized
INFO - 2018-05-15 04:56:17 --> Language Class Initialized
INFO - 2018-05-15 04:56:17 --> Router Class Initialized
INFO - 2018-05-15 04:56:17 --> Hooks Class Initialized
INFO - 2018-05-15 04:56:17 --> URI Class Initialized
INFO - 2018-05-15 04:56:17 --> Language Class Initialized
ERROR - 2018-05-15 04:56:17 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:56:17 --> Output Class Initialized
DEBUG - 2018-05-15 04:56:17 --> UTF-8 Support Enabled
INFO - 2018-05-15 04:56:17 --> Config Class Initialized
INFO - 2018-05-15 04:56:17 --> Security Class Initialized
ERROR - 2018-05-15 04:56:17 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:56:17 --> Router Class Initialized
DEBUG - 2018-05-15 04:56:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:56:17 --> Hooks Class Initialized
INFO - 2018-05-15 04:56:17 --> Input Class Initialized
INFO - 2018-05-15 04:56:17 --> Config Class Initialized
INFO - 2018-05-15 04:56:17 --> Output Class Initialized
INFO - 2018-05-15 04:56:17 --> Utf8 Class Initialized
INFO - 2018-05-15 04:56:17 --> Hooks Class Initialized
INFO - 2018-05-15 04:56:17 --> Security Class Initialized
DEBUG - 2018-05-15 04:56:17 --> UTF-8 Support Enabled
INFO - 2018-05-15 04:56:17 --> Language Class Initialized
INFO - 2018-05-15 04:56:17 --> URI Class Initialized
DEBUG - 2018-05-15 04:56:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:56:17 --> Utf8 Class Initialized
INFO - 2018-05-15 04:56:17 --> Router Class Initialized
ERROR - 2018-05-15 04:56:17 --> 404 Page Not Found: /index
DEBUG - 2018-05-15 04:56:17 --> UTF-8 Support Enabled
INFO - 2018-05-15 04:56:17 --> Input Class Initialized
INFO - 2018-05-15 04:56:17 --> URI Class Initialized
INFO - 2018-05-15 04:56:17 --> Output Class Initialized
INFO - 2018-05-15 04:56:17 --> Utf8 Class Initialized
INFO - 2018-05-15 04:56:17 --> Config Class Initialized
INFO - 2018-05-15 04:56:18 --> Hooks Class Initialized
INFO - 2018-05-15 04:56:18 --> Router Class Initialized
INFO - 2018-05-15 04:56:18 --> URI Class Initialized
INFO - 2018-05-15 04:56:18 --> Security Class Initialized
INFO - 2018-05-15 04:56:18 --> Language Class Initialized
ERROR - 2018-05-15 04:56:18 --> 404 Page Not Found: /index
DEBUG - 2018-05-15 04:56:18 --> UTF-8 Support Enabled
INFO - 2018-05-15 04:56:18 --> Output Class Initialized
DEBUG - 2018-05-15 04:56:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:56:18 --> Router Class Initialized
INFO - 2018-05-15 04:56:18 --> Security Class Initialized
INFO - 2018-05-15 04:56:18 --> Utf8 Class Initialized
INFO - 2018-05-15 04:56:18 --> Input Class Initialized
INFO - 2018-05-15 04:56:18 --> Output Class Initialized
INFO - 2018-05-15 04:56:18 --> URI Class Initialized
INFO - 2018-05-15 04:56:18 --> Language Class Initialized
DEBUG - 2018-05-15 04:56:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:56:18 --> Security Class Initialized
ERROR - 2018-05-15 04:56:18 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:56:18 --> Input Class Initialized
DEBUG - 2018-05-15 04:56:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:56:18 --> Router Class Initialized
INFO - 2018-05-15 04:56:18 --> Output Class Initialized
INFO - 2018-05-15 04:56:18 --> Input Class Initialized
INFO - 2018-05-15 04:56:18 --> Security Class Initialized
INFO - 2018-05-15 04:56:18 --> Language Class Initialized
DEBUG - 2018-05-15 04:56:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:56:18 --> Language Class Initialized
ERROR - 2018-05-15 04:56:18 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:56:18 --> Input Class Initialized
ERROR - 2018-05-15 04:56:18 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:56:18 --> Language Class Initialized
ERROR - 2018-05-15 04:56:18 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:56:21 --> Config Class Initialized
INFO - 2018-05-15 04:56:21 --> Hooks Class Initialized
DEBUG - 2018-05-15 04:56:21 --> UTF-8 Support Enabled
INFO - 2018-05-15 04:56:21 --> Utf8 Class Initialized
INFO - 2018-05-15 04:56:21 --> URI Class Initialized
INFO - 2018-05-15 04:56:21 --> Router Class Initialized
INFO - 2018-05-15 04:56:21 --> Output Class Initialized
INFO - 2018-05-15 04:56:21 --> Security Class Initialized
DEBUG - 2018-05-15 04:56:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:56:21 --> Input Class Initialized
INFO - 2018-05-15 04:56:21 --> Language Class Initialized
ERROR - 2018-05-15 04:56:21 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:56:21 --> Config Class Initialized
INFO - 2018-05-15 04:56:21 --> Config Class Initialized
INFO - 2018-05-15 04:56:21 --> Config Class Initialized
INFO - 2018-05-15 04:56:21 --> Config Class Initialized
INFO - 2018-05-15 04:56:21 --> Config Class Initialized
INFO - 2018-05-15 04:56:21 --> Hooks Class Initialized
DEBUG - 2018-05-15 04:56:21 --> UTF-8 Support Enabled
INFO - 2018-05-15 04:56:21 --> Utf8 Class Initialized
INFO - 2018-05-15 04:56:21 --> URI Class Initialized
INFO - 2018-05-15 04:56:22 --> Router Class Initialized
INFO - 2018-05-15 04:56:22 --> Output Class Initialized
INFO - 2018-05-15 04:56:22 --> Security Class Initialized
DEBUG - 2018-05-15 04:56:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:56:22 --> Input Class Initialized
INFO - 2018-05-15 04:56:22 --> Hooks Class Initialized
INFO - 2018-05-15 04:56:22 --> Hooks Class Initialized
INFO - 2018-05-15 04:56:22 --> Hooks Class Initialized
INFO - 2018-05-15 04:56:22 --> Hooks Class Initialized
INFO - 2018-05-15 04:56:22 --> Language Class Initialized
DEBUG - 2018-05-15 04:56:22 --> UTF-8 Support Enabled
INFO - 2018-05-15 04:56:22 --> Utf8 Class Initialized
DEBUG - 2018-05-15 04:56:22 --> UTF-8 Support Enabled
INFO - 2018-05-15 04:56:22 --> Utf8 Class Initialized
INFO - 2018-05-15 04:56:22 --> URI Class Initialized
ERROR - 2018-05-15 04:56:22 --> 404 Page Not Found: /index
DEBUG - 2018-05-15 04:56:22 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 04:56:22 --> UTF-8 Support Enabled
INFO - 2018-05-15 04:56:22 --> URI Class Initialized
INFO - 2018-05-15 04:56:22 --> Router Class Initialized
INFO - 2018-05-15 04:56:22 --> Output Class Initialized
INFO - 2018-05-15 04:56:22 --> Router Class Initialized
INFO - 2018-05-15 04:56:22 --> Output Class Initialized
INFO - 2018-05-15 04:56:22 --> Security Class Initialized
INFO - 2018-05-15 04:56:22 --> Utf8 Class Initialized
INFO - 2018-05-15 04:56:22 --> Utf8 Class Initialized
INFO - 2018-05-15 04:56:22 --> Security Class Initialized
DEBUG - 2018-05-15 04:56:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:56:22 --> Input Class Initialized
DEBUG - 2018-05-15 04:56:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:56:22 --> URI Class Initialized
INFO - 2018-05-15 04:56:22 --> URI Class Initialized
INFO - 2018-05-15 04:56:22 --> Language Class Initialized
INFO - 2018-05-15 04:56:22 --> Input Class Initialized
INFO - 2018-05-15 04:56:22 --> Router Class Initialized
INFO - 2018-05-15 04:56:22 --> Router Class Initialized
ERROR - 2018-05-15 04:56:22 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:56:22 --> Language Class Initialized
INFO - 2018-05-15 04:56:22 --> Output Class Initialized
INFO - 2018-05-15 04:56:22 --> Output Class Initialized
ERROR - 2018-05-15 04:56:22 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:56:22 --> Config Class Initialized
INFO - 2018-05-15 04:56:22 --> Hooks Class Initialized
DEBUG - 2018-05-15 04:56:22 --> UTF-8 Support Enabled
INFO - 2018-05-15 04:56:22 --> Config Class Initialized
INFO - 2018-05-15 04:56:22 --> Security Class Initialized
INFO - 2018-05-15 04:56:22 --> Security Class Initialized
INFO - 2018-05-15 04:56:22 --> Utf8 Class Initialized
INFO - 2018-05-15 04:56:22 --> URI Class Initialized
INFO - 2018-05-15 04:56:22 --> Router Class Initialized
DEBUG - 2018-05-15 04:56:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:56:22 --> Hooks Class Initialized
INFO - 2018-05-15 04:56:22 --> Output Class Initialized
INFO - 2018-05-15 04:56:22 --> Security Class Initialized
DEBUG - 2018-05-15 04:56:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:56:22 --> Input Class Initialized
INFO - 2018-05-15 04:56:22 --> Language Class Initialized
ERROR - 2018-05-15 04:56:22 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:56:22 --> Config Class Initialized
DEBUG - 2018-05-15 04:56:22 --> UTF-8 Support Enabled
INFO - 2018-05-15 04:56:22 --> Input Class Initialized
DEBUG - 2018-05-15 04:56:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:56:22 --> Hooks Class Initialized
INFO - 2018-05-15 04:56:22 --> Utf8 Class Initialized
DEBUG - 2018-05-15 04:56:22 --> UTF-8 Support Enabled
INFO - 2018-05-15 04:56:22 --> Language Class Initialized
INFO - 2018-05-15 04:56:22 --> Input Class Initialized
INFO - 2018-05-15 04:56:22 --> URI Class Initialized
INFO - 2018-05-15 04:56:22 --> Utf8 Class Initialized
INFO - 2018-05-15 04:56:22 --> Language Class Initialized
ERROR - 2018-05-15 04:56:22 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:56:22 --> URI Class Initialized
INFO - 2018-05-15 04:56:22 --> Router Class Initialized
INFO - 2018-05-15 04:56:22 --> Output Class Initialized
INFO - 2018-05-15 04:56:22 --> Router Class Initialized
INFO - 2018-05-15 04:56:22 --> Output Class Initialized
INFO - 2018-05-15 04:56:22 --> Security Class Initialized
INFO - 2018-05-15 04:56:22 --> Config Class Initialized
INFO - 2018-05-15 04:56:22 --> Security Class Initialized
ERROR - 2018-05-15 04:56:22 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:56:22 --> Hooks Class Initialized
DEBUG - 2018-05-15 04:56:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-15 04:56:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:56:22 --> Config Class Initialized
INFO - 2018-05-15 04:56:22 --> Hooks Class Initialized
DEBUG - 2018-05-15 04:56:22 --> UTF-8 Support Enabled
INFO - 2018-05-15 04:56:22 --> Input Class Initialized
INFO - 2018-05-15 04:56:22 --> Input Class Initialized
INFO - 2018-05-15 04:56:22 --> Utf8 Class Initialized
INFO - 2018-05-15 04:56:22 --> Language Class Initialized
INFO - 2018-05-15 04:56:22 --> Language Class Initialized
DEBUG - 2018-05-15 04:56:22 --> UTF-8 Support Enabled
INFO - 2018-05-15 04:56:22 --> URI Class Initialized
ERROR - 2018-05-15 04:56:22 --> 404 Page Not Found: /index
ERROR - 2018-05-15 04:56:22 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:56:22 --> Utf8 Class Initialized
INFO - 2018-05-15 04:56:22 --> Router Class Initialized
INFO - 2018-05-15 04:56:22 --> Config Class Initialized
INFO - 2018-05-15 04:56:22 --> URI Class Initialized
INFO - 2018-05-15 04:56:22 --> Hooks Class Initialized
INFO - 2018-05-15 04:56:22 --> Output Class Initialized
DEBUG - 2018-05-15 04:56:22 --> UTF-8 Support Enabled
INFO - 2018-05-15 04:56:22 --> Security Class Initialized
INFO - 2018-05-15 04:56:22 --> Utf8 Class Initialized
INFO - 2018-05-15 04:56:22 --> URI Class Initialized
INFO - 2018-05-15 04:56:22 --> Router Class Initialized
DEBUG - 2018-05-15 04:56:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:56:22 --> Router Class Initialized
INFO - 2018-05-15 04:56:23 --> Input Class Initialized
INFO - 2018-05-15 04:56:23 --> Output Class Initialized
INFO - 2018-05-15 04:56:23 --> Output Class Initialized
INFO - 2018-05-15 04:56:23 --> Security Class Initialized
INFO - 2018-05-15 04:56:23 --> Language Class Initialized
INFO - 2018-05-15 04:56:23 --> Security Class Initialized
DEBUG - 2018-05-15 04:56:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-15 04:56:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:56:23 --> Input Class Initialized
INFO - 2018-05-15 04:56:23 --> Language Class Initialized
INFO - 2018-05-15 04:56:23 --> Input Class Initialized
ERROR - 2018-05-15 04:56:23 --> 404 Page Not Found: /index
ERROR - 2018-05-15 04:56:23 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:56:23 --> Language Class Initialized
INFO - 2018-05-15 04:56:23 --> Config Class Initialized
INFO - 2018-05-15 04:56:23 --> Hooks Class Initialized
ERROR - 2018-05-15 04:56:23 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:56:23 --> Config Class Initialized
INFO - 2018-05-15 04:56:23 --> Hooks Class Initialized
DEBUG - 2018-05-15 04:56:23 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 04:56:23 --> UTF-8 Support Enabled
INFO - 2018-05-15 04:56:23 --> Utf8 Class Initialized
INFO - 2018-05-15 04:56:23 --> Utf8 Class Initialized
INFO - 2018-05-15 04:56:23 --> URI Class Initialized
INFO - 2018-05-15 04:56:23 --> URI Class Initialized
INFO - 2018-05-15 04:56:23 --> Router Class Initialized
INFO - 2018-05-15 04:56:23 --> Router Class Initialized
INFO - 2018-05-15 04:56:23 --> Output Class Initialized
INFO - 2018-05-15 04:56:23 --> Output Class Initialized
INFO - 2018-05-15 04:56:23 --> Security Class Initialized
INFO - 2018-05-15 04:56:23 --> Security Class Initialized
DEBUG - 2018-05-15 04:56:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:56:23 --> Input Class Initialized
INFO - 2018-05-15 04:56:23 --> Language Class Initialized
ERROR - 2018-05-15 04:56:23 --> 404 Page Not Found: /index
DEBUG - 2018-05-15 04:56:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:56:23 --> Input Class Initialized
INFO - 2018-05-15 04:56:23 --> Language Class Initialized
ERROR - 2018-05-15 04:56:23 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:56:28 --> Config Class Initialized
INFO - 2018-05-15 04:56:28 --> Hooks Class Initialized
DEBUG - 2018-05-15 04:56:28 --> UTF-8 Support Enabled
INFO - 2018-05-15 04:56:28 --> Utf8 Class Initialized
INFO - 2018-05-15 04:56:28 --> URI Class Initialized
INFO - 2018-05-15 04:56:28 --> Router Class Initialized
INFO - 2018-05-15 04:56:28 --> Output Class Initialized
INFO - 2018-05-15 04:56:28 --> Security Class Initialized
DEBUG - 2018-05-15 04:56:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:56:28 --> Input Class Initialized
INFO - 2018-05-15 04:56:28 --> Language Class Initialized
ERROR - 2018-05-15 04:56:28 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:56:30 --> Config Class Initialized
INFO - 2018-05-15 04:56:30 --> Hooks Class Initialized
DEBUG - 2018-05-15 04:56:30 --> UTF-8 Support Enabled
INFO - 2018-05-15 04:56:30 --> Utf8 Class Initialized
INFO - 2018-05-15 04:56:30 --> Config Class Initialized
INFO - 2018-05-15 04:56:30 --> Config Class Initialized
INFO - 2018-05-15 04:56:30 --> Config Class Initialized
INFO - 2018-05-15 04:56:30 --> Config Class Initialized
INFO - 2018-05-15 04:56:30 --> Config Class Initialized
INFO - 2018-05-15 04:56:30 --> Hooks Class Initialized
INFO - 2018-05-15 04:56:30 --> Hooks Class Initialized
INFO - 2018-05-15 04:56:30 --> Hooks Class Initialized
INFO - 2018-05-15 04:56:30 --> Hooks Class Initialized
INFO - 2018-05-15 04:56:30 --> Hooks Class Initialized
INFO - 2018-05-15 04:56:30 --> URI Class Initialized
DEBUG - 2018-05-15 04:56:31 --> UTF-8 Support Enabled
INFO - 2018-05-15 04:56:31 --> Router Class Initialized
DEBUG - 2018-05-15 04:56:31 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 04:56:31 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 04:56:31 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 04:56:31 --> UTF-8 Support Enabled
INFO - 2018-05-15 04:56:31 --> Utf8 Class Initialized
INFO - 2018-05-15 04:56:31 --> URI Class Initialized
INFO - 2018-05-15 04:56:31 --> Utf8 Class Initialized
INFO - 2018-05-15 04:56:31 --> Router Class Initialized
INFO - 2018-05-15 04:56:31 --> URI Class Initialized
INFO - 2018-05-15 04:56:31 --> Output Class Initialized
INFO - 2018-05-15 04:56:31 --> Output Class Initialized
INFO - 2018-05-15 04:56:31 --> Utf8 Class Initialized
INFO - 2018-05-15 04:56:31 --> Utf8 Class Initialized
INFO - 2018-05-15 04:56:31 --> Utf8 Class Initialized
INFO - 2018-05-15 04:56:31 --> Router Class Initialized
INFO - 2018-05-15 04:56:31 --> Security Class Initialized
INFO - 2018-05-15 04:56:31 --> Security Class Initialized
DEBUG - 2018-05-15 04:56:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:56:31 --> Output Class Initialized
DEBUG - 2018-05-15 04:56:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:56:31 --> URI Class Initialized
INFO - 2018-05-15 04:56:31 --> URI Class Initialized
INFO - 2018-05-15 04:56:31 --> URI Class Initialized
INFO - 2018-05-15 04:56:31 --> Security Class Initialized
INFO - 2018-05-15 04:56:31 --> Input Class Initialized
INFO - 2018-05-15 04:56:31 --> Router Class Initialized
INFO - 2018-05-15 04:56:31 --> Router Class Initialized
INFO - 2018-05-15 04:56:31 --> Router Class Initialized
INFO - 2018-05-15 04:56:31 --> Input Class Initialized
DEBUG - 2018-05-15 04:56:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:56:31 --> Language Class Initialized
INFO - 2018-05-15 04:56:31 --> Output Class Initialized
INFO - 2018-05-15 04:56:31 --> Output Class Initialized
INFO - 2018-05-15 04:56:31 --> Language Class Initialized
INFO - 2018-05-15 04:56:31 --> Input Class Initialized
INFO - 2018-05-15 04:56:31 --> Output Class Initialized
INFO - 2018-05-15 04:56:31 --> Security Class Initialized
ERROR - 2018-05-15 04:56:31 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:56:31 --> Security Class Initialized
INFO - 2018-05-15 04:56:31 --> Language Class Initialized
INFO - 2018-05-15 04:56:31 --> Security Class Initialized
ERROR - 2018-05-15 04:56:31 --> 404 Page Not Found: /index
DEBUG - 2018-05-15 04:56:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-05-15 04:56:31 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:56:31 --> Input Class Initialized
DEBUG - 2018-05-15 04:56:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-15 04:56:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:56:31 --> Config Class Initialized
INFO - 2018-05-15 04:56:31 --> Hooks Class Initialized
INFO - 2018-05-15 04:56:31 --> Language Class Initialized
INFO - 2018-05-15 04:56:31 --> Input Class Initialized
DEBUG - 2018-05-15 04:56:31 --> UTF-8 Support Enabled
INFO - 2018-05-15 04:56:31 --> Utf8 Class Initialized
INFO - 2018-05-15 04:56:31 --> Language Class Initialized
INFO - 2018-05-15 04:56:31 --> Input Class Initialized
ERROR - 2018-05-15 04:56:31 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:56:31 --> URI Class Initialized
INFO - 2018-05-15 04:56:31 --> Language Class Initialized
ERROR - 2018-05-15 04:56:31 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:56:31 --> Config Class Initialized
INFO - 2018-05-15 04:56:31 --> Hooks Class Initialized
INFO - 2018-05-15 04:56:31 --> Router Class Initialized
DEBUG - 2018-05-15 04:56:31 --> UTF-8 Support Enabled
ERROR - 2018-05-15 04:56:31 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:56:31 --> Output Class Initialized
INFO - 2018-05-15 04:56:31 --> Utf8 Class Initialized
INFO - 2018-05-15 04:56:31 --> Config Class Initialized
INFO - 2018-05-15 04:56:31 --> Hooks Class Initialized
INFO - 2018-05-15 04:56:31 --> Config Class Initialized
INFO - 2018-05-15 04:56:31 --> Hooks Class Initialized
DEBUG - 2018-05-15 04:56:31 --> UTF-8 Support Enabled
INFO - 2018-05-15 04:56:31 --> Security Class Initialized
INFO - 2018-05-15 04:56:31 --> URI Class Initialized
DEBUG - 2018-05-15 04:56:31 --> UTF-8 Support Enabled
INFO - 2018-05-15 04:56:31 --> Utf8 Class Initialized
INFO - 2018-05-15 04:56:31 --> Router Class Initialized
DEBUG - 2018-05-15 04:56:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:56:31 --> Utf8 Class Initialized
INFO - 2018-05-15 04:56:31 --> URI Class Initialized
INFO - 2018-05-15 04:56:31 --> URI Class Initialized
INFO - 2018-05-15 04:56:31 --> Input Class Initialized
INFO - 2018-05-15 04:56:31 --> Output Class Initialized
INFO - 2018-05-15 04:56:31 --> Security Class Initialized
INFO - 2018-05-15 04:56:31 --> Language Class Initialized
INFO - 2018-05-15 04:56:31 --> Router Class Initialized
INFO - 2018-05-15 04:56:31 --> Router Class Initialized
DEBUG - 2018-05-15 04:56:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:56:31 --> Output Class Initialized
INFO - 2018-05-15 04:56:31 --> Input Class Initialized
INFO - 2018-05-15 04:56:31 --> Security Class Initialized
ERROR - 2018-05-15 04:56:31 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:56:31 --> Output Class Initialized
INFO - 2018-05-15 04:56:31 --> Language Class Initialized
INFO - 2018-05-15 04:56:31 --> Config Class Initialized
INFO - 2018-05-15 04:56:31 --> Security Class Initialized
DEBUG - 2018-05-15 04:56:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:56:31 --> Hooks Class Initialized
INFO - 2018-05-15 04:56:31 --> Input Class Initialized
DEBUG - 2018-05-15 04:56:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-05-15 04:56:31 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:56:31 --> Language Class Initialized
DEBUG - 2018-05-15 04:56:31 --> UTF-8 Support Enabled
INFO - 2018-05-15 04:56:31 --> Input Class Initialized
INFO - 2018-05-15 04:56:31 --> Config Class Initialized
INFO - 2018-05-15 04:56:31 --> Hooks Class Initialized
INFO - 2018-05-15 04:56:31 --> Utf8 Class Initialized
INFO - 2018-05-15 04:56:31 --> Language Class Initialized
ERROR - 2018-05-15 04:56:31 --> 404 Page Not Found: /index
DEBUG - 2018-05-15 04:56:31 --> UTF-8 Support Enabled
INFO - 2018-05-15 04:56:31 --> URI Class Initialized
ERROR - 2018-05-15 04:56:31 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:56:32 --> Config Class Initialized
INFO - 2018-05-15 04:56:32 --> Hooks Class Initialized
INFO - 2018-05-15 04:56:32 --> Utf8 Class Initialized
INFO - 2018-05-15 04:56:32 --> Config Class Initialized
DEBUG - 2018-05-15 04:56:32 --> UTF-8 Support Enabled
INFO - 2018-05-15 04:56:32 --> URI Class Initialized
INFO - 2018-05-15 04:56:32 --> Hooks Class Initialized
INFO - 2018-05-15 04:56:32 --> Utf8 Class Initialized
INFO - 2018-05-15 04:56:32 --> Router Class Initialized
INFO - 2018-05-15 04:56:32 --> Output Class Initialized
INFO - 2018-05-15 04:56:32 --> Router Class Initialized
INFO - 2018-05-15 04:56:32 --> URI Class Initialized
DEBUG - 2018-05-15 04:56:32 --> UTF-8 Support Enabled
INFO - 2018-05-15 04:56:32 --> Output Class Initialized
INFO - 2018-05-15 04:56:32 --> Utf8 Class Initialized
INFO - 2018-05-15 04:56:32 --> Security Class Initialized
INFO - 2018-05-15 04:56:32 --> Router Class Initialized
DEBUG - 2018-05-15 04:56:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:56:32 --> Output Class Initialized
INFO - 2018-05-15 04:56:32 --> Security Class Initialized
INFO - 2018-05-15 04:56:32 --> URI Class Initialized
INFO - 2018-05-15 04:56:32 --> Input Class Initialized
DEBUG - 2018-05-15 04:56:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:56:32 --> Security Class Initialized
INFO - 2018-05-15 04:56:32 --> Router Class Initialized
INFO - 2018-05-15 04:56:32 --> Language Class Initialized
ERROR - 2018-05-15 04:56:32 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:56:32 --> Input Class Initialized
INFO - 2018-05-15 04:56:32 --> Output Class Initialized
DEBUG - 2018-05-15 04:56:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:56:32 --> Security Class Initialized
INFO - 2018-05-15 04:56:32 --> Input Class Initialized
INFO - 2018-05-15 04:56:32 --> Language Class Initialized
ERROR - 2018-05-15 04:56:32 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:56:32 --> Language Class Initialized
DEBUG - 2018-05-15 04:56:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:56:32 --> Input Class Initialized
INFO - 2018-05-15 04:56:32 --> Language Class Initialized
ERROR - 2018-05-15 04:56:32 --> 404 Page Not Found: /index
ERROR - 2018-05-15 04:56:32 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:56:58 --> Config Class Initialized
INFO - 2018-05-15 04:56:58 --> Hooks Class Initialized
DEBUG - 2018-05-15 04:56:58 --> UTF-8 Support Enabled
INFO - 2018-05-15 04:56:58 --> Utf8 Class Initialized
INFO - 2018-05-15 04:56:58 --> URI Class Initialized
INFO - 2018-05-15 04:56:58 --> Config Class Initialized
INFO - 2018-05-15 04:56:58 --> Config Class Initialized
INFO - 2018-05-15 04:56:58 --> Config Class Initialized
INFO - 2018-05-15 04:56:58 --> Config Class Initialized
INFO - 2018-05-15 04:56:58 --> Hooks Class Initialized
INFO - 2018-05-15 04:56:58 --> Hooks Class Initialized
INFO - 2018-05-15 04:56:58 --> Hooks Class Initialized
INFO - 2018-05-15 04:56:58 --> Hooks Class Initialized
INFO - 2018-05-15 04:56:58 --> Router Class Initialized
INFO - 2018-05-15 04:56:58 --> Config Class Initialized
DEBUG - 2018-05-15 04:56:58 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 04:56:58 --> UTF-8 Support Enabled
INFO - 2018-05-15 04:56:58 --> Hooks Class Initialized
INFO - 2018-05-15 04:56:58 --> Output Class Initialized
INFO - 2018-05-15 04:56:58 --> Utf8 Class Initialized
INFO - 2018-05-15 04:56:58 --> URI Class Initialized
INFO - 2018-05-15 04:56:58 --> Router Class Initialized
INFO - 2018-05-15 04:56:58 --> Output Class Initialized
INFO - 2018-05-15 04:56:58 --> Security Class Initialized
DEBUG - 2018-05-15 04:56:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:56:58 --> Input Class Initialized
INFO - 2018-05-15 04:56:58 --> Security Class Initialized
INFO - 2018-05-15 04:56:58 --> Utf8 Class Initialized
DEBUG - 2018-05-15 04:56:58 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 04:56:58 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 04:56:58 --> UTF-8 Support Enabled
INFO - 2018-05-15 04:56:58 --> Language Class Initialized
INFO - 2018-05-15 04:56:58 --> URI Class Initialized
INFO - 2018-05-15 04:56:58 --> Utf8 Class Initialized
INFO - 2018-05-15 04:56:58 --> Utf8 Class Initialized
INFO - 2018-05-15 04:56:58 --> Utf8 Class Initialized
ERROR - 2018-05-15 04:56:58 --> 404 Page Not Found: /index
DEBUG - 2018-05-15 04:56:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:56:58 --> URI Class Initialized
INFO - 2018-05-15 04:56:58 --> URI Class Initialized
INFO - 2018-05-15 04:56:58 --> URI Class Initialized
INFO - 2018-05-15 04:56:58 --> Input Class Initialized
INFO - 2018-05-15 04:56:58 --> Router Class Initialized
INFO - 2018-05-15 04:56:58 --> Config Class Initialized
INFO - 2018-05-15 04:56:58 --> Router Class Initialized
INFO - 2018-05-15 04:56:58 --> Router Class Initialized
INFO - 2018-05-15 04:56:58 --> Language Class Initialized
INFO - 2018-05-15 04:56:58 --> Output Class Initialized
INFO - 2018-05-15 04:56:58 --> Router Class Initialized
INFO - 2018-05-15 04:56:58 --> Output Class Initialized
INFO - 2018-05-15 04:56:58 --> Output Class Initialized
ERROR - 2018-05-15 04:56:58 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:56:58 --> Security Class Initialized
INFO - 2018-05-15 04:56:58 --> Hooks Class Initialized
INFO - 2018-05-15 04:56:58 --> Output Class Initialized
INFO - 2018-05-15 04:56:59 --> Security Class Initialized
DEBUG - 2018-05-15 04:56:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:56:59 --> Security Class Initialized
DEBUG - 2018-05-15 04:56:59 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 04:56:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:56:59 --> Security Class Initialized
INFO - 2018-05-15 04:56:59 --> Input Class Initialized
INFO - 2018-05-15 04:56:59 --> Config Class Initialized
INFO - 2018-05-15 04:56:59 --> Utf8 Class Initialized
INFO - 2018-05-15 04:56:59 --> Input Class Initialized
DEBUG - 2018-05-15 04:56:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:56:59 --> Hooks Class Initialized
INFO - 2018-05-15 04:56:59 --> Language Class Initialized
DEBUG - 2018-05-15 04:56:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:56:59 --> URI Class Initialized
INFO - 2018-05-15 04:56:59 --> Router Class Initialized
INFO - 2018-05-15 04:56:59 --> Input Class Initialized
INFO - 2018-05-15 04:56:59 --> Input Class Initialized
ERROR - 2018-05-15 04:56:59 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:56:59 --> Output Class Initialized
INFO - 2018-05-15 04:56:59 --> Language Class Initialized
DEBUG - 2018-05-15 04:56:59 --> UTF-8 Support Enabled
INFO - 2018-05-15 04:56:59 --> Utf8 Class Initialized
INFO - 2018-05-15 04:56:59 --> Language Class Initialized
ERROR - 2018-05-15 04:56:59 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:56:59 --> Language Class Initialized
INFO - 2018-05-15 04:56:59 --> Config Class Initialized
INFO - 2018-05-15 04:56:59 --> Security Class Initialized
ERROR - 2018-05-15 04:56:59 --> 404 Page Not Found: /index
ERROR - 2018-05-15 04:56:59 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:56:59 --> URI Class Initialized
INFO - 2018-05-15 04:56:59 --> Config Class Initialized
INFO - 2018-05-15 04:56:59 --> Hooks Class Initialized
INFO - 2018-05-15 04:56:59 --> Hooks Class Initialized
INFO - 2018-05-15 04:56:59 --> Router Class Initialized
DEBUG - 2018-05-15 04:56:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-15 04:56:59 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 04:56:59 --> UTF-8 Support Enabled
INFO - 2018-05-15 04:56:59 --> Config Class Initialized
INFO - 2018-05-15 04:56:59 --> Config Class Initialized
INFO - 2018-05-15 04:56:59 --> Hooks Class Initialized
INFO - 2018-05-15 04:56:59 --> Hooks Class Initialized
INFO - 2018-05-15 04:56:59 --> Utf8 Class Initialized
INFO - 2018-05-15 04:56:59 --> Utf8 Class Initialized
INFO - 2018-05-15 04:56:59 --> Input Class Initialized
INFO - 2018-05-15 04:56:59 --> Output Class Initialized
DEBUG - 2018-05-15 04:56:59 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 04:56:59 --> UTF-8 Support Enabled
INFO - 2018-05-15 04:56:59 --> URI Class Initialized
INFO - 2018-05-15 04:56:59 --> URI Class Initialized
INFO - 2018-05-15 04:56:59 --> Language Class Initialized
INFO - 2018-05-15 04:56:59 --> Security Class Initialized
ERROR - 2018-05-15 04:56:59 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:56:59 --> Utf8 Class Initialized
INFO - 2018-05-15 04:56:59 --> Router Class Initialized
INFO - 2018-05-15 04:56:59 --> Utf8 Class Initialized
INFO - 2018-05-15 04:56:59 --> Router Class Initialized
DEBUG - 2018-05-15 04:56:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:56:59 --> URI Class Initialized
INFO - 2018-05-15 04:56:59 --> Router Class Initialized
INFO - 2018-05-15 04:56:59 --> Output Class Initialized
INFO - 2018-05-15 04:56:59 --> Security Class Initialized
DEBUG - 2018-05-15 04:56:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:56:59 --> Input Class Initialized
INFO - 2018-05-15 04:56:59 --> Output Class Initialized
INFO - 2018-05-15 04:56:59 --> Output Class Initialized
INFO - 2018-05-15 04:56:59 --> URI Class Initialized
INFO - 2018-05-15 04:56:59 --> Input Class Initialized
INFO - 2018-05-15 04:56:59 --> Language Class Initialized
ERROR - 2018-05-15 04:56:59 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:56:59 --> Config Class Initialized
INFO - 2018-05-15 04:56:59 --> Hooks Class Initialized
DEBUG - 2018-05-15 04:56:59 --> UTF-8 Support Enabled
INFO - 2018-05-15 04:56:59 --> Utf8 Class Initialized
INFO - 2018-05-15 04:56:59 --> URI Class Initialized
INFO - 2018-05-15 04:56:59 --> Router Class Initialized
INFO - 2018-05-15 04:56:59 --> Security Class Initialized
INFO - 2018-05-15 04:56:59 --> Security Class Initialized
INFO - 2018-05-15 04:56:59 --> Router Class Initialized
INFO - 2018-05-15 04:56:59 --> Language Class Initialized
INFO - 2018-05-15 04:56:59 --> Output Class Initialized
DEBUG - 2018-05-15 04:56:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:57:00 --> Security Class Initialized
ERROR - 2018-05-15 04:57:00 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:57:00 --> Output Class Initialized
INFO - 2018-05-15 04:57:00 --> Input Class Initialized
DEBUG - 2018-05-15 04:57:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:57:00 --> Config Class Initialized
INFO - 2018-05-15 04:57:00 --> Security Class Initialized
INFO - 2018-05-15 04:57:00 --> Language Class Initialized
INFO - 2018-05-15 04:57:00 --> Input Class Initialized
DEBUG - 2018-05-15 04:57:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:57:00 --> Hooks Class Initialized
INFO - 2018-05-15 04:57:00 --> Input Class Initialized
INFO - 2018-05-15 04:57:00 --> Language Class Initialized
ERROR - 2018-05-15 04:57:00 --> 404 Page Not Found: /index
DEBUG - 2018-05-15 04:57:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-15 04:57:00 --> UTF-8 Support Enabled
ERROR - 2018-05-15 04:57:00 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:57:00 --> Input Class Initialized
INFO - 2018-05-15 04:57:00 --> Utf8 Class Initialized
INFO - 2018-05-15 04:57:00 --> Language Class Initialized
INFO - 2018-05-15 04:57:00 --> Config Class Initialized
INFO - 2018-05-15 04:57:00 --> Language Class Initialized
INFO - 2018-05-15 04:57:00 --> URI Class Initialized
ERROR - 2018-05-15 04:57:00 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:57:00 --> Hooks Class Initialized
INFO - 2018-05-15 04:57:00 --> Config Class Initialized
ERROR - 2018-05-15 04:57:00 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:57:00 --> Hooks Class Initialized
INFO - 2018-05-15 04:57:00 --> Router Class Initialized
DEBUG - 2018-05-15 04:57:00 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 04:57:00 --> UTF-8 Support Enabled
INFO - 2018-05-15 04:57:00 --> Utf8 Class Initialized
INFO - 2018-05-15 04:57:00 --> Utf8 Class Initialized
INFO - 2018-05-15 04:57:00 --> Output Class Initialized
INFO - 2018-05-15 04:57:00 --> URI Class Initialized
INFO - 2018-05-15 04:57:00 --> URI Class Initialized
INFO - 2018-05-15 04:57:00 --> Router Class Initialized
INFO - 2018-05-15 04:57:00 --> Output Class Initialized
INFO - 2018-05-15 04:57:00 --> Security Class Initialized
INFO - 2018-05-15 04:57:00 --> Security Class Initialized
INFO - 2018-05-15 04:57:00 --> Router Class Initialized
DEBUG - 2018-05-15 04:57:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:57:00 --> Input Class Initialized
INFO - 2018-05-15 04:57:00 --> Output Class Initialized
DEBUG - 2018-05-15 04:57:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:57:00 --> Config Class Initialized
INFO - 2018-05-15 04:57:00 --> Hooks Class Initialized
DEBUG - 2018-05-15 04:57:00 --> UTF-8 Support Enabled
INFO - 2018-05-15 04:57:00 --> Language Class Initialized
INFO - 2018-05-15 04:57:00 --> Utf8 Class Initialized
INFO - 2018-05-15 04:57:00 --> Input Class Initialized
INFO - 2018-05-15 04:57:00 --> Security Class Initialized
INFO - 2018-05-15 04:57:00 --> URI Class Initialized
ERROR - 2018-05-15 04:57:00 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:57:00 --> Language Class Initialized
DEBUG - 2018-05-15 04:57:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-05-15 04:57:00 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:57:00 --> Input Class Initialized
INFO - 2018-05-15 04:57:00 --> Router Class Initialized
INFO - 2018-05-15 04:57:00 --> Output Class Initialized
INFO - 2018-05-15 04:57:01 --> Language Class Initialized
INFO - 2018-05-15 04:57:01 --> Security Class Initialized
DEBUG - 2018-05-15 04:57:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-05-15 04:57:01 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:57:01 --> Input Class Initialized
INFO - 2018-05-15 04:57:01 --> Language Class Initialized
ERROR - 2018-05-15 04:57:01 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:57:09 --> Config Class Initialized
INFO - 2018-05-15 04:57:09 --> Hooks Class Initialized
DEBUG - 2018-05-15 04:57:09 --> UTF-8 Support Enabled
INFO - 2018-05-15 04:57:09 --> Utf8 Class Initialized
INFO - 2018-05-15 04:57:09 --> URI Class Initialized
INFO - 2018-05-15 04:57:09 --> Router Class Initialized
INFO - 2018-05-15 04:57:09 --> Output Class Initialized
INFO - 2018-05-15 04:57:09 --> Security Class Initialized
DEBUG - 2018-05-15 04:57:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:57:09 --> Config Class Initialized
INFO - 2018-05-15 04:57:09 --> Config Class Initialized
INFO - 2018-05-15 04:57:09 --> Config Class Initialized
INFO - 2018-05-15 04:57:09 --> Config Class Initialized
INFO - 2018-05-15 04:57:09 --> Hooks Class Initialized
INFO - 2018-05-15 04:57:09 --> Hooks Class Initialized
INFO - 2018-05-15 04:57:09 --> Hooks Class Initialized
INFO - 2018-05-15 04:57:09 --> Hooks Class Initialized
INFO - 2018-05-15 04:57:09 --> Input Class Initialized
INFO - 2018-05-15 04:57:09 --> Config Class Initialized
DEBUG - 2018-05-15 04:57:09 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 04:57:09 --> UTF-8 Support Enabled
INFO - 2018-05-15 04:57:09 --> Language Class Initialized
DEBUG - 2018-05-15 04:57:09 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 04:57:09 --> UTF-8 Support Enabled
INFO - 2018-05-15 04:57:09 --> Hooks Class Initialized
INFO - 2018-05-15 04:57:09 --> Utf8 Class Initialized
INFO - 2018-05-15 04:57:09 --> Utf8 Class Initialized
INFO - 2018-05-15 04:57:09 --> Utf8 Class Initialized
INFO - 2018-05-15 04:57:09 --> Utf8 Class Initialized
ERROR - 2018-05-15 04:57:09 --> 404 Page Not Found: /index
DEBUG - 2018-05-15 04:57:09 --> UTF-8 Support Enabled
INFO - 2018-05-15 04:57:09 --> URI Class Initialized
INFO - 2018-05-15 04:57:09 --> URI Class Initialized
INFO - 2018-05-15 04:57:09 --> URI Class Initialized
INFO - 2018-05-15 04:57:09 --> Utf8 Class Initialized
INFO - 2018-05-15 04:57:09 --> URI Class Initialized
INFO - 2018-05-15 04:57:09 --> Router Class Initialized
INFO - 2018-05-15 04:57:09 --> Output Class Initialized
INFO - 2018-05-15 04:57:09 --> URI Class Initialized
INFO - 2018-05-15 04:57:09 --> Router Class Initialized
INFO - 2018-05-15 04:57:09 --> Router Class Initialized
INFO - 2018-05-15 04:57:09 --> Router Class Initialized
INFO - 2018-05-15 04:57:09 --> Security Class Initialized
INFO - 2018-05-15 04:57:09 --> Router Class Initialized
INFO - 2018-05-15 04:57:09 --> Output Class Initialized
INFO - 2018-05-15 04:57:09 --> Output Class Initialized
INFO - 2018-05-15 04:57:09 --> Output Class Initialized
DEBUG - 2018-05-15 04:57:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:57:09 --> Security Class Initialized
INFO - 2018-05-15 04:57:09 --> Output Class Initialized
INFO - 2018-05-15 04:57:09 --> Security Class Initialized
INFO - 2018-05-15 04:57:09 --> Security Class Initialized
INFO - 2018-05-15 04:57:09 --> Input Class Initialized
INFO - 2018-05-15 04:57:09 --> Security Class Initialized
DEBUG - 2018-05-15 04:57:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:57:09 --> Language Class Initialized
DEBUG - 2018-05-15 04:57:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-15 04:57:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-15 04:57:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:57:09 --> Input Class Initialized
INFO - 2018-05-15 04:57:10 --> Language Class Initialized
ERROR - 2018-05-15 04:57:10 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:57:10 --> Input Class Initialized
INFO - 2018-05-15 04:57:10 --> Language Class Initialized
INFO - 2018-05-15 04:57:10 --> Input Class Initialized
INFO - 2018-05-15 04:57:10 --> Input Class Initialized
ERROR - 2018-05-15 04:57:10 --> 404 Page Not Found: /index
ERROR - 2018-05-15 04:57:10 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:57:10 --> Config Class Initialized
INFO - 2018-05-15 04:57:10 --> Hooks Class Initialized
INFO - 2018-05-15 04:57:10 --> Language Class Initialized
INFO - 2018-05-15 04:57:10 --> Language Class Initialized
DEBUG - 2018-05-15 04:57:10 --> UTF-8 Support Enabled
INFO - 2018-05-15 04:57:10 --> Utf8 Class Initialized
ERROR - 2018-05-15 04:57:10 --> 404 Page Not Found: /index
ERROR - 2018-05-15 04:57:10 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:57:10 --> URI Class Initialized
INFO - 2018-05-15 04:57:10 --> Config Class Initialized
INFO - 2018-05-15 04:57:10 --> Config Class Initialized
INFO - 2018-05-15 04:57:10 --> Config Class Initialized
INFO - 2018-05-15 04:57:10 --> Hooks Class Initialized
INFO - 2018-05-15 04:57:10 --> Hooks Class Initialized
INFO - 2018-05-15 04:57:10 --> Hooks Class Initialized
INFO - 2018-05-15 04:57:10 --> Router Class Initialized
DEBUG - 2018-05-15 04:57:10 --> UTF-8 Support Enabled
INFO - 2018-05-15 04:57:10 --> Utf8 Class Initialized
DEBUG - 2018-05-15 04:57:10 --> UTF-8 Support Enabled
INFO - 2018-05-15 04:57:10 --> Output Class Initialized
DEBUG - 2018-05-15 04:57:10 --> UTF-8 Support Enabled
INFO - 2018-05-15 04:57:10 --> Utf8 Class Initialized
INFO - 2018-05-15 04:57:10 --> URI Class Initialized
INFO - 2018-05-15 04:57:10 --> Utf8 Class Initialized
INFO - 2018-05-15 04:57:10 --> Security Class Initialized
INFO - 2018-05-15 04:57:10 --> URI Class Initialized
INFO - 2018-05-15 04:57:10 --> URI Class Initialized
INFO - 2018-05-15 04:57:10 --> Router Class Initialized
INFO - 2018-05-15 04:57:10 --> Router Class Initialized
DEBUG - 2018-05-15 04:57:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:57:10 --> Output Class Initialized
INFO - 2018-05-15 04:57:10 --> Router Class Initialized
INFO - 2018-05-15 04:57:10 --> Output Class Initialized
INFO - 2018-05-15 04:57:10 --> Security Class Initialized
DEBUG - 2018-05-15 04:57:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:57:10 --> Input Class Initialized
INFO - 2018-05-15 04:57:10 --> Output Class Initialized
INFO - 2018-05-15 04:57:10 --> Security Class Initialized
DEBUG - 2018-05-15 04:57:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:57:10 --> Language Class Initialized
INFO - 2018-05-15 04:57:10 --> Input Class Initialized
INFO - 2018-05-15 04:57:10 --> Security Class Initialized
DEBUG - 2018-05-15 04:57:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:57:10 --> Input Class Initialized
INFO - 2018-05-15 04:57:10 --> Language Class Initialized
ERROR - 2018-05-15 04:57:10 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:57:10 --> Language Class Initialized
ERROR - 2018-05-15 04:57:10 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:57:10 --> Input Class Initialized
INFO - 2018-05-15 04:57:10 --> Config Class Initialized
INFO - 2018-05-15 04:57:10 --> Hooks Class Initialized
ERROR - 2018-05-15 04:57:10 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:57:10 --> Language Class Initialized
INFO - 2018-05-15 04:57:10 --> Config Class Initialized
INFO - 2018-05-15 04:57:10 --> Hooks Class Initialized
DEBUG - 2018-05-15 04:57:10 --> UTF-8 Support Enabled
ERROR - 2018-05-15 04:57:10 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:57:10 --> Config Class Initialized
INFO - 2018-05-15 04:57:10 --> Hooks Class Initialized
DEBUG - 2018-05-15 04:57:10 --> UTF-8 Support Enabled
INFO - 2018-05-15 04:57:10 --> Config Class Initialized
INFO - 2018-05-15 04:57:10 --> Utf8 Class Initialized
INFO - 2018-05-15 04:57:10 --> Hooks Class Initialized
DEBUG - 2018-05-15 04:57:10 --> UTF-8 Support Enabled
INFO - 2018-05-15 04:57:10 --> Utf8 Class Initialized
INFO - 2018-05-15 04:57:10 --> URI Class Initialized
INFO - 2018-05-15 04:57:10 --> URI Class Initialized
INFO - 2018-05-15 04:57:10 --> Utf8 Class Initialized
DEBUG - 2018-05-15 04:57:10 --> UTF-8 Support Enabled
INFO - 2018-05-15 04:57:10 --> Router Class Initialized
INFO - 2018-05-15 04:57:10 --> Utf8 Class Initialized
INFO - 2018-05-15 04:57:10 --> Output Class Initialized
INFO - 2018-05-15 04:57:10 --> Router Class Initialized
INFO - 2018-05-15 04:57:10 --> URI Class Initialized
INFO - 2018-05-15 04:57:10 --> Security Class Initialized
INFO - 2018-05-15 04:57:10 --> Output Class Initialized
INFO - 2018-05-15 04:57:10 --> URI Class Initialized
INFO - 2018-05-15 04:57:10 --> Router Class Initialized
DEBUG - 2018-05-15 04:57:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:57:10 --> Output Class Initialized
INFO - 2018-05-15 04:57:10 --> Security Class Initialized
INFO - 2018-05-15 04:57:10 --> Router Class Initialized
INFO - 2018-05-15 04:57:10 --> Output Class Initialized
INFO - 2018-05-15 04:57:10 --> Security Class Initialized
DEBUG - 2018-05-15 04:57:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:57:10 --> Input Class Initialized
INFO - 2018-05-15 04:57:10 --> Input Class Initialized
INFO - 2018-05-15 04:57:10 --> Language Class Initialized
DEBUG - 2018-05-15 04:57:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:57:10 --> Security Class Initialized
DEBUG - 2018-05-15 04:57:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:57:10 --> Input Class Initialized
INFO - 2018-05-15 04:57:10 --> Language Class Initialized
ERROR - 2018-05-15 04:57:10 --> 404 Page Not Found: /index
ERROR - 2018-05-15 04:57:10 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:57:10 --> Input Class Initialized
INFO - 2018-05-15 04:57:10 --> Language Class Initialized
INFO - 2018-05-15 04:57:10 --> Language Class Initialized
ERROR - 2018-05-15 04:57:10 --> 404 Page Not Found: /index
ERROR - 2018-05-15 04:57:10 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:57:22 --> Config Class Initialized
INFO - 2018-05-15 04:57:22 --> Hooks Class Initialized
DEBUG - 2018-05-15 04:57:22 --> UTF-8 Support Enabled
INFO - 2018-05-15 04:57:22 --> Utf8 Class Initialized
INFO - 2018-05-15 04:57:22 --> URI Class Initialized
INFO - 2018-05-15 04:57:22 --> Config Class Initialized
INFO - 2018-05-15 04:57:22 --> Config Class Initialized
INFO - 2018-05-15 04:57:22 --> Hooks Class Initialized
INFO - 2018-05-15 04:57:22 --> Router Class Initialized
DEBUG - 2018-05-15 04:57:22 --> UTF-8 Support Enabled
INFO - 2018-05-15 04:57:22 --> Config Class Initialized
INFO - 2018-05-15 04:57:22 --> Config Class Initialized
INFO - 2018-05-15 04:57:22 --> Hooks Class Initialized
INFO - 2018-05-15 04:57:22 --> Output Class Initialized
INFO - 2018-05-15 04:57:22 --> Config Class Initialized
INFO - 2018-05-15 04:57:22 --> Utf8 Class Initialized
INFO - 2018-05-15 04:57:22 --> Hooks Class Initialized
INFO - 2018-05-15 04:57:22 --> Security Class Initialized
INFO - 2018-05-15 04:57:22 --> Hooks Class Initialized
INFO - 2018-05-15 04:57:22 --> Hooks Class Initialized
DEBUG - 2018-05-15 04:57:22 --> UTF-8 Support Enabled
INFO - 2018-05-15 04:57:22 --> URI Class Initialized
DEBUG - 2018-05-15 04:57:22 --> UTF-8 Support Enabled
INFO - 2018-05-15 04:57:22 --> Utf8 Class Initialized
DEBUG - 2018-05-15 04:57:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-15 04:57:22 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 04:57:22 --> UTF-8 Support Enabled
INFO - 2018-05-15 04:57:22 --> Utf8 Class Initialized
INFO - 2018-05-15 04:57:22 --> Router Class Initialized
INFO - 2018-05-15 04:57:22 --> URI Class Initialized
INFO - 2018-05-15 04:57:22 --> Input Class Initialized
INFO - 2018-05-15 04:57:22 --> Language Class Initialized
INFO - 2018-05-15 04:57:22 --> Utf8 Class Initialized
INFO - 2018-05-15 04:57:22 --> Utf8 Class Initialized
INFO - 2018-05-15 04:57:22 --> URI Class Initialized
INFO - 2018-05-15 04:57:22 --> Output Class Initialized
INFO - 2018-05-15 04:57:22 --> Router Class Initialized
ERROR - 2018-05-15 04:57:22 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:57:22 --> URI Class Initialized
INFO - 2018-05-15 04:57:22 --> Security Class Initialized
INFO - 2018-05-15 04:57:22 --> Router Class Initialized
INFO - 2018-05-15 04:57:22 --> Output Class Initialized
INFO - 2018-05-15 04:57:22 --> URI Class Initialized
INFO - 2018-05-15 04:57:22 --> Router Class Initialized
INFO - 2018-05-15 04:57:22 --> Output Class Initialized
INFO - 2018-05-15 04:57:22 --> Security Class Initialized
DEBUG - 2018-05-15 04:57:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-15 04:57:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:57:22 --> Security Class Initialized
INFO - 2018-05-15 04:57:22 --> Router Class Initialized
INFO - 2018-05-15 04:57:22 --> Input Class Initialized
INFO - 2018-05-15 04:57:22 --> Output Class Initialized
INFO - 2018-05-15 04:57:22 --> Security Class Initialized
DEBUG - 2018-05-15 04:57:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:57:22 --> Input Class Initialized
INFO - 2018-05-15 04:57:22 --> Output Class Initialized
INFO - 2018-05-15 04:57:22 --> Language Class Initialized
DEBUG - 2018-05-15 04:57:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:57:23 --> Input Class Initialized
ERROR - 2018-05-15 04:57:23 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:57:23 --> Language Class Initialized
INFO - 2018-05-15 04:57:23 --> Security Class Initialized
INFO - 2018-05-15 04:57:23 --> Input Class Initialized
INFO - 2018-05-15 04:57:23 --> Language Class Initialized
ERROR - 2018-05-15 04:57:23 --> 404 Page Not Found: /index
DEBUG - 2018-05-15 04:57:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:57:23 --> Config Class Initialized
INFO - 2018-05-15 04:57:23 --> Hooks Class Initialized
INFO - 2018-05-15 04:57:23 --> Language Class Initialized
INFO - 2018-05-15 04:57:23 --> Input Class Initialized
ERROR - 2018-05-15 04:57:23 --> 404 Page Not Found: /index
ERROR - 2018-05-15 04:57:23 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:57:23 --> Language Class Initialized
DEBUG - 2018-05-15 04:57:23 --> UTF-8 Support Enabled
INFO - 2018-05-15 04:57:23 --> Config Class Initialized
INFO - 2018-05-15 04:57:23 --> Hooks Class Initialized
INFO - 2018-05-15 04:57:23 --> Config Class Initialized
DEBUG - 2018-05-15 04:57:23 --> UTF-8 Support Enabled
INFO - 2018-05-15 04:57:23 --> Utf8 Class Initialized
INFO - 2018-05-15 04:57:23 --> Hooks Class Initialized
ERROR - 2018-05-15 04:57:23 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:57:23 --> Utf8 Class Initialized
INFO - 2018-05-15 04:57:23 --> URI Class Initialized
DEBUG - 2018-05-15 04:57:23 --> UTF-8 Support Enabled
INFO - 2018-05-15 04:57:23 --> URI Class Initialized
INFO - 2018-05-15 04:57:23 --> Config Class Initialized
INFO - 2018-05-15 04:57:23 --> Utf8 Class Initialized
INFO - 2018-05-15 04:57:23 --> Hooks Class Initialized
INFO - 2018-05-15 04:57:23 --> Router Class Initialized
INFO - 2018-05-15 04:57:23 --> Router Class Initialized
INFO - 2018-05-15 04:57:23 --> URI Class Initialized
DEBUG - 2018-05-15 04:57:23 --> UTF-8 Support Enabled
INFO - 2018-05-15 04:57:23 --> Utf8 Class Initialized
INFO - 2018-05-15 04:57:23 --> Output Class Initialized
INFO - 2018-05-15 04:57:23 --> Output Class Initialized
INFO - 2018-05-15 04:57:23 --> Router Class Initialized
INFO - 2018-05-15 04:57:23 --> Output Class Initialized
INFO - 2018-05-15 04:57:23 --> URI Class Initialized
INFO - 2018-05-15 04:57:23 --> Security Class Initialized
INFO - 2018-05-15 04:57:23 --> Security Class Initialized
DEBUG - 2018-05-15 04:57:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-15 04:57:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:57:23 --> Security Class Initialized
INFO - 2018-05-15 04:57:23 --> Router Class Initialized
INFO - 2018-05-15 04:57:23 --> Output Class Initialized
INFO - 2018-05-15 04:57:23 --> Input Class Initialized
INFO - 2018-05-15 04:57:23 --> Input Class Initialized
DEBUG - 2018-05-15 04:57:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:57:23 --> Language Class Initialized
INFO - 2018-05-15 04:57:23 --> Language Class Initialized
INFO - 2018-05-15 04:57:23 --> Input Class Initialized
INFO - 2018-05-15 04:57:23 --> Security Class Initialized
DEBUG - 2018-05-15 04:57:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-05-15 04:57:23 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:57:23 --> Language Class Initialized
ERROR - 2018-05-15 04:57:23 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:57:23 --> Input Class Initialized
ERROR - 2018-05-15 04:57:23 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:57:23 --> Config Class Initialized
INFO - 2018-05-15 04:57:23 --> Config Class Initialized
INFO - 2018-05-15 04:57:23 --> Hooks Class Initialized
INFO - 2018-05-15 04:57:23 --> Hooks Class Initialized
INFO - 2018-05-15 04:57:23 --> Config Class Initialized
INFO - 2018-05-15 04:57:23 --> Language Class Initialized
INFO - 2018-05-15 04:57:23 --> Hooks Class Initialized
DEBUG - 2018-05-15 04:57:23 --> UTF-8 Support Enabled
ERROR - 2018-05-15 04:57:23 --> 404 Page Not Found: /index
DEBUG - 2018-05-15 04:57:23 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 04:57:23 --> UTF-8 Support Enabled
INFO - 2018-05-15 04:57:23 --> Utf8 Class Initialized
INFO - 2018-05-15 04:57:23 --> Utf8 Class Initialized
INFO - 2018-05-15 04:57:23 --> Config Class Initialized
INFO - 2018-05-15 04:57:23 --> Hooks Class Initialized
INFO - 2018-05-15 04:57:23 --> Utf8 Class Initialized
INFO - 2018-05-15 04:57:23 --> URI Class Initialized
INFO - 2018-05-15 04:57:23 --> URI Class Initialized
INFO - 2018-05-15 04:57:23 --> URI Class Initialized
INFO - 2018-05-15 04:57:23 --> Router Class Initialized
INFO - 2018-05-15 04:57:23 --> Router Class Initialized
DEBUG - 2018-05-15 04:57:23 --> UTF-8 Support Enabled
INFO - 2018-05-15 04:57:23 --> Router Class Initialized
INFO - 2018-05-15 04:57:23 --> Output Class Initialized
INFO - 2018-05-15 04:57:23 --> Utf8 Class Initialized
INFO - 2018-05-15 04:57:23 --> Output Class Initialized
INFO - 2018-05-15 04:57:23 --> Security Class Initialized
INFO - 2018-05-15 04:57:23 --> URI Class Initialized
INFO - 2018-05-15 04:57:23 --> Security Class Initialized
INFO - 2018-05-15 04:57:23 --> Output Class Initialized
DEBUG - 2018-05-15 04:57:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:57:23 --> Security Class Initialized
DEBUG - 2018-05-15 04:57:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-15 04:57:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:57:23 --> Input Class Initialized
INFO - 2018-05-15 04:57:23 --> Router Class Initialized
INFO - 2018-05-15 04:57:23 --> Input Class Initialized
INFO - 2018-05-15 04:57:23 --> Language Class Initialized
INFO - 2018-05-15 04:57:23 --> Input Class Initialized
INFO - 2018-05-15 04:57:23 --> Output Class Initialized
INFO - 2018-05-15 04:57:23 --> Security Class Initialized
INFO - 2018-05-15 04:57:23 --> Language Class Initialized
INFO - 2018-05-15 04:57:23 --> Language Class Initialized
ERROR - 2018-05-15 04:57:23 --> 404 Page Not Found: /index
DEBUG - 2018-05-15 04:57:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-05-15 04:57:23 --> 404 Page Not Found: /index
ERROR - 2018-05-15 04:57:23 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:57:23 --> Input Class Initialized
INFO - 2018-05-15 04:57:23 --> Language Class Initialized
ERROR - 2018-05-15 04:57:23 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:57:30 --> Config Class Initialized
INFO - 2018-05-15 04:57:30 --> Hooks Class Initialized
DEBUG - 2018-05-15 04:57:30 --> UTF-8 Support Enabled
INFO - 2018-05-15 04:57:30 --> Utf8 Class Initialized
INFO - 2018-05-15 04:57:30 --> URI Class Initialized
INFO - 2018-05-15 04:57:30 --> Router Class Initialized
INFO - 2018-05-15 04:57:30 --> Output Class Initialized
INFO - 2018-05-15 04:57:30 --> Security Class Initialized
DEBUG - 2018-05-15 04:57:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:57:31 --> Config Class Initialized
INFO - 2018-05-15 04:57:31 --> Config Class Initialized
INFO - 2018-05-15 04:57:31 --> Config Class Initialized
INFO - 2018-05-15 04:57:31 --> Hooks Class Initialized
INFO - 2018-05-15 04:57:31 --> Hooks Class Initialized
INFO - 2018-05-15 04:57:31 --> Hooks Class Initialized
INFO - 2018-05-15 04:57:31 --> Input Class Initialized
INFO - 2018-05-15 04:57:31 --> Config Class Initialized
INFO - 2018-05-15 04:57:31 --> Config Class Initialized
DEBUG - 2018-05-15 04:57:31 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 04:57:31 --> UTF-8 Support Enabled
INFO - 2018-05-15 04:57:31 --> Hooks Class Initialized
INFO - 2018-05-15 04:57:31 --> Hooks Class Initialized
INFO - 2018-05-15 04:57:31 --> Language Class Initialized
DEBUG - 2018-05-15 04:57:31 --> UTF-8 Support Enabled
INFO - 2018-05-15 04:57:31 --> Utf8 Class Initialized
DEBUG - 2018-05-15 04:57:31 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 04:57:31 --> UTF-8 Support Enabled
ERROR - 2018-05-15 04:57:31 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:57:31 --> Utf8 Class Initialized
INFO - 2018-05-15 04:57:31 --> Utf8 Class Initialized
INFO - 2018-05-15 04:57:31 --> URI Class Initialized
INFO - 2018-05-15 04:57:31 --> Utf8 Class Initialized
INFO - 2018-05-15 04:57:31 --> Utf8 Class Initialized
INFO - 2018-05-15 04:57:31 --> URI Class Initialized
INFO - 2018-05-15 04:57:31 --> URI Class Initialized
INFO - 2018-05-15 04:57:31 --> URI Class Initialized
INFO - 2018-05-15 04:57:31 --> Router Class Initialized
INFO - 2018-05-15 04:57:31 --> Router Class Initialized
INFO - 2018-05-15 04:57:31 --> URI Class Initialized
INFO - 2018-05-15 04:57:31 --> Router Class Initialized
INFO - 2018-05-15 04:57:31 --> Router Class Initialized
INFO - 2018-05-15 04:57:31 --> Output Class Initialized
INFO - 2018-05-15 04:57:31 --> Output Class Initialized
INFO - 2018-05-15 04:57:31 --> Output Class Initialized
INFO - 2018-05-15 04:57:31 --> Router Class Initialized
INFO - 2018-05-15 04:57:31 --> Output Class Initialized
INFO - 2018-05-15 04:57:31 --> Security Class Initialized
DEBUG - 2018-05-15 04:57:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:57:31 --> Security Class Initialized
INFO - 2018-05-15 04:57:31 --> Output Class Initialized
INFO - 2018-05-15 04:57:31 --> Security Class Initialized
INFO - 2018-05-15 04:57:31 --> Input Class Initialized
INFO - 2018-05-15 04:57:31 --> Security Class Initialized
DEBUG - 2018-05-15 04:57:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:57:31 --> Security Class Initialized
INFO - 2018-05-15 04:57:31 --> Language Class Initialized
DEBUG - 2018-05-15 04:57:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-15 04:57:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:57:31 --> Input Class Initialized
INFO - 2018-05-15 04:57:31 --> Input Class Initialized
INFO - 2018-05-15 04:57:31 --> Input Class Initialized
ERROR - 2018-05-15 04:57:31 --> 404 Page Not Found: /index
DEBUG - 2018-05-15 04:57:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:57:31 --> Language Class Initialized
INFO - 2018-05-15 04:57:31 --> Language Class Initialized
INFO - 2018-05-15 04:57:31 --> Input Class Initialized
ERROR - 2018-05-15 04:57:31 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:57:31 --> Language Class Initialized
ERROR - 2018-05-15 04:57:31 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:57:31 --> Config Class Initialized
INFO - 2018-05-15 04:57:31 --> Hooks Class Initialized
DEBUG - 2018-05-15 04:57:31 --> UTF-8 Support Enabled
INFO - 2018-05-15 04:57:31 --> Config Class Initialized
ERROR - 2018-05-15 04:57:31 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:57:31 --> Language Class Initialized
INFO - 2018-05-15 04:57:31 --> Utf8 Class Initialized
ERROR - 2018-05-15 04:57:31 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:57:31 --> Hooks Class Initialized
INFO - 2018-05-15 04:57:31 --> Config Class Initialized
INFO - 2018-05-15 04:57:31 --> Hooks Class Initialized
INFO - 2018-05-15 04:57:31 --> URI Class Initialized
DEBUG - 2018-05-15 04:57:31 --> UTF-8 Support Enabled
INFO - 2018-05-15 04:57:31 --> Config Class Initialized
INFO - 2018-05-15 04:57:31 --> Hooks Class Initialized
DEBUG - 2018-05-15 04:57:31 --> UTF-8 Support Enabled
INFO - 2018-05-15 04:57:31 --> Router Class Initialized
INFO - 2018-05-15 04:57:31 --> Utf8 Class Initialized
DEBUG - 2018-05-15 04:57:31 --> UTF-8 Support Enabled
INFO - 2018-05-15 04:57:31 --> Utf8 Class Initialized
INFO - 2018-05-15 04:57:31 --> Output Class Initialized
INFO - 2018-05-15 04:57:31 --> URI Class Initialized
INFO - 2018-05-15 04:57:31 --> URI Class Initialized
INFO - 2018-05-15 04:57:31 --> Utf8 Class Initialized
INFO - 2018-05-15 04:57:31 --> URI Class Initialized
INFO - 2018-05-15 04:57:31 --> Security Class Initialized
INFO - 2018-05-15 04:57:31 --> Router Class Initialized
INFO - 2018-05-15 04:57:31 --> Router Class Initialized
INFO - 2018-05-15 04:57:31 --> Output Class Initialized
INFO - 2018-05-15 04:57:31 --> Router Class Initialized
INFO - 2018-05-15 04:57:31 --> Output Class Initialized
INFO - 2018-05-15 04:57:31 --> Output Class Initialized
DEBUG - 2018-05-15 04:57:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:57:31 --> Security Class Initialized
INFO - 2018-05-15 04:57:31 --> Security Class Initialized
INFO - 2018-05-15 04:57:31 --> Security Class Initialized
DEBUG - 2018-05-15 04:57:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-15 04:57:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:57:31 --> Input Class Initialized
DEBUG - 2018-05-15 04:57:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:57:31 --> Input Class Initialized
INFO - 2018-05-15 04:57:31 --> Input Class Initialized
INFO - 2018-05-15 04:57:31 --> Input Class Initialized
INFO - 2018-05-15 04:57:31 --> Language Class Initialized
ERROR - 2018-05-15 04:57:31 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:57:31 --> Language Class Initialized
INFO - 2018-05-15 04:57:31 --> Language Class Initialized
INFO - 2018-05-15 04:57:31 --> Language Class Initialized
ERROR - 2018-05-15 04:57:31 --> 404 Page Not Found: /index
ERROR - 2018-05-15 04:57:31 --> 404 Page Not Found: /index
ERROR - 2018-05-15 04:57:31 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:57:31 --> Config Class Initialized
INFO - 2018-05-15 04:57:31 --> Hooks Class Initialized
INFO - 2018-05-15 04:57:31 --> Config Class Initialized
INFO - 2018-05-15 04:57:31 --> Config Class Initialized
INFO - 2018-05-15 04:57:32 --> Hooks Class Initialized
INFO - 2018-05-15 04:57:32 --> Hooks Class Initialized
DEBUG - 2018-05-15 04:57:32 --> UTF-8 Support Enabled
INFO - 2018-05-15 04:57:32 --> Config Class Initialized
INFO - 2018-05-15 04:57:32 --> Hooks Class Initialized
DEBUG - 2018-05-15 04:57:32 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 04:57:32 --> UTF-8 Support Enabled
INFO - 2018-05-15 04:57:32 --> Utf8 Class Initialized
INFO - 2018-05-15 04:57:32 --> Utf8 Class Initialized
INFO - 2018-05-15 04:57:32 --> Utf8 Class Initialized
DEBUG - 2018-05-15 04:57:32 --> UTF-8 Support Enabled
INFO - 2018-05-15 04:57:32 --> URI Class Initialized
INFO - 2018-05-15 04:57:32 --> Router Class Initialized
INFO - 2018-05-15 04:57:32 --> Utf8 Class Initialized
INFO - 2018-05-15 04:57:32 --> URI Class Initialized
INFO - 2018-05-15 04:57:32 --> URI Class Initialized
INFO - 2018-05-15 04:57:32 --> Output Class Initialized
INFO - 2018-05-15 04:57:32 --> Router Class Initialized
INFO - 2018-05-15 04:57:32 --> URI Class Initialized
INFO - 2018-05-15 04:57:32 --> Router Class Initialized
INFO - 2018-05-15 04:57:32 --> Security Class Initialized
INFO - 2018-05-15 04:57:32 --> Output Class Initialized
INFO - 2018-05-15 04:57:32 --> Router Class Initialized
INFO - 2018-05-15 04:57:32 --> Output Class Initialized
DEBUG - 2018-05-15 04:57:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:57:32 --> Security Class Initialized
INFO - 2018-05-15 04:57:32 --> Security Class Initialized
INFO - 2018-05-15 04:57:32 --> Output Class Initialized
DEBUG - 2018-05-15 04:57:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:57:32 --> Input Class Initialized
DEBUG - 2018-05-15 04:57:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:57:32 --> Security Class Initialized
INFO - 2018-05-15 04:57:32 --> Language Class Initialized
INFO - 2018-05-15 04:57:32 --> Input Class Initialized
DEBUG - 2018-05-15 04:57:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:57:32 --> Input Class Initialized
INFO - 2018-05-15 04:57:32 --> Language Class Initialized
ERROR - 2018-05-15 04:57:32 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:57:32 --> Input Class Initialized
INFO - 2018-05-15 04:57:32 --> Language Class Initialized
ERROR - 2018-05-15 04:57:32 --> 404 Page Not Found: /index
ERROR - 2018-05-15 04:57:32 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:57:32 --> Language Class Initialized
ERROR - 2018-05-15 04:57:32 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:58:41 --> Config Class Initialized
INFO - 2018-05-15 04:58:41 --> Hooks Class Initialized
DEBUG - 2018-05-15 04:58:41 --> UTF-8 Support Enabled
INFO - 2018-05-15 04:58:41 --> Utf8 Class Initialized
INFO - 2018-05-15 04:58:41 --> URI Class Initialized
INFO - 2018-05-15 04:58:41 --> Router Class Initialized
INFO - 2018-05-15 04:58:41 --> Output Class Initialized
INFO - 2018-05-15 04:58:41 --> Config Class Initialized
INFO - 2018-05-15 04:58:41 --> Security Class Initialized
INFO - 2018-05-15 04:58:41 --> Config Class Initialized
INFO - 2018-05-15 04:58:41 --> Config Class Initialized
INFO - 2018-05-15 04:58:41 --> Config Class Initialized
INFO - 2018-05-15 04:58:41 --> Config Class Initialized
INFO - 2018-05-15 04:58:41 --> Hooks Class Initialized
INFO - 2018-05-15 04:58:41 --> Hooks Class Initialized
INFO - 2018-05-15 04:58:41 --> Hooks Class Initialized
INFO - 2018-05-15 04:58:41 --> Hooks Class Initialized
DEBUG - 2018-05-15 04:58:41 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 04:58:41 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 04:58:41 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 04:58:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:58:41 --> Hooks Class Initialized
INFO - 2018-05-15 04:58:41 --> Utf8 Class Initialized
INFO - 2018-05-15 04:58:41 --> Input Class Initialized
DEBUG - 2018-05-15 04:58:41 --> UTF-8 Support Enabled
INFO - 2018-05-15 04:58:41 --> Utf8 Class Initialized
DEBUG - 2018-05-15 04:58:41 --> UTF-8 Support Enabled
INFO - 2018-05-15 04:58:41 --> Utf8 Class Initialized
INFO - 2018-05-15 04:58:41 --> URI Class Initialized
INFO - 2018-05-15 04:58:41 --> URI Class Initialized
INFO - 2018-05-15 04:58:41 --> Utf8 Class Initialized
INFO - 2018-05-15 04:58:41 --> URI Class Initialized
INFO - 2018-05-15 04:58:41 --> Utf8 Class Initialized
INFO - 2018-05-15 04:58:41 --> Language Class Initialized
INFO - 2018-05-15 04:58:41 --> Router Class Initialized
INFO - 2018-05-15 04:58:41 --> Router Class Initialized
INFO - 2018-05-15 04:58:41 --> URI Class Initialized
ERROR - 2018-05-15 04:58:41 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:58:41 --> Router Class Initialized
INFO - 2018-05-15 04:58:41 --> Output Class Initialized
INFO - 2018-05-15 04:58:41 --> URI Class Initialized
INFO - 2018-05-15 04:58:41 --> Output Class Initialized
INFO - 2018-05-15 04:58:41 --> Router Class Initialized
INFO - 2018-05-15 04:58:41 --> Output Class Initialized
INFO - 2018-05-15 04:58:41 --> Security Class Initialized
INFO - 2018-05-15 04:58:41 --> Router Class Initialized
DEBUG - 2018-05-15 04:58:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:58:41 --> Security Class Initialized
INFO - 2018-05-15 04:58:41 --> Output Class Initialized
INFO - 2018-05-15 04:58:41 --> Security Class Initialized
INFO - 2018-05-15 04:58:41 --> Output Class Initialized
INFO - 2018-05-15 04:58:41 --> Input Class Initialized
INFO - 2018-05-15 04:58:41 --> Security Class Initialized
DEBUG - 2018-05-15 04:58:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-15 04:58:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:58:41 --> Security Class Initialized
INFO - 2018-05-15 04:58:41 --> Language Class Initialized
ERROR - 2018-05-15 04:58:41 --> 404 Page Not Found: /index
DEBUG - 2018-05-15 04:58:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:58:41 --> Input Class Initialized
INFO - 2018-05-15 04:58:41 --> Input Class Initialized
DEBUG - 2018-05-15 04:58:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:58:41 --> Input Class Initialized
INFO - 2018-05-15 04:58:41 --> Config Class Initialized
INFO - 2018-05-15 04:58:41 --> Input Class Initialized
INFO - 2018-05-15 04:58:41 --> Language Class Initialized
INFO - 2018-05-15 04:58:41 --> Language Class Initialized
INFO - 2018-05-15 04:58:41 --> Hooks Class Initialized
INFO - 2018-05-15 04:58:41 --> Language Class Initialized
ERROR - 2018-05-15 04:58:41 --> 404 Page Not Found: /index
ERROR - 2018-05-15 04:58:41 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:58:41 --> Language Class Initialized
DEBUG - 2018-05-15 04:58:41 --> UTF-8 Support Enabled
INFO - 2018-05-15 04:58:41 --> Config Class Initialized
ERROR - 2018-05-15 04:58:41 --> 404 Page Not Found: /index
ERROR - 2018-05-15 04:58:41 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:58:41 --> Hooks Class Initialized
INFO - 2018-05-15 04:58:41 --> Utf8 Class Initialized
INFO - 2018-05-15 04:58:41 --> Config Class Initialized
INFO - 2018-05-15 04:58:41 --> Config Class Initialized
INFO - 2018-05-15 04:58:41 --> Hooks Class Initialized
INFO - 2018-05-15 04:58:41 --> Hooks Class Initialized
DEBUG - 2018-05-15 04:58:41 --> UTF-8 Support Enabled
INFO - 2018-05-15 04:58:41 --> URI Class Initialized
DEBUG - 2018-05-15 04:58:42 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 04:58:42 --> UTF-8 Support Enabled
INFO - 2018-05-15 04:58:42 --> Utf8 Class Initialized
INFO - 2018-05-15 04:58:42 --> Router Class Initialized
INFO - 2018-05-15 04:58:42 --> Utf8 Class Initialized
INFO - 2018-05-15 04:58:42 --> URI Class Initialized
INFO - 2018-05-15 04:58:42 --> Utf8 Class Initialized
INFO - 2018-05-15 04:58:42 --> Output Class Initialized
INFO - 2018-05-15 04:58:42 --> URI Class Initialized
INFO - 2018-05-15 04:58:42 --> URI Class Initialized
INFO - 2018-05-15 04:58:42 --> Router Class Initialized
INFO - 2018-05-15 04:58:42 --> Security Class Initialized
DEBUG - 2018-05-15 04:58:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:58:42 --> Router Class Initialized
INFO - 2018-05-15 04:58:42 --> Router Class Initialized
INFO - 2018-05-15 04:58:42 --> Output Class Initialized
INFO - 2018-05-15 04:58:42 --> Input Class Initialized
INFO - 2018-05-15 04:58:42 --> Output Class Initialized
INFO - 2018-05-15 04:58:42 --> Output Class Initialized
INFO - 2018-05-15 04:58:42 --> Security Class Initialized
INFO - 2018-05-15 04:58:42 --> Language Class Initialized
INFO - 2018-05-15 04:58:42 --> Security Class Initialized
INFO - 2018-05-15 04:58:42 --> Security Class Initialized
DEBUG - 2018-05-15 04:58:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-15 04:58:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-15 04:58:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-05-15 04:58:42 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:58:42 --> Input Class Initialized
INFO - 2018-05-15 04:58:42 --> Input Class Initialized
INFO - 2018-05-15 04:58:42 --> Language Class Initialized
INFO - 2018-05-15 04:58:42 --> Input Class Initialized
INFO - 2018-05-15 04:58:42 --> Language Class Initialized
ERROR - 2018-05-15 04:58:42 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:58:42 --> Language Class Initialized
INFO - 2018-05-15 04:58:42 --> Config Class Initialized
INFO - 2018-05-15 04:58:42 --> Hooks Class Initialized
ERROR - 2018-05-15 04:58:42 --> 404 Page Not Found: /index
ERROR - 2018-05-15 04:58:42 --> 404 Page Not Found: /index
DEBUG - 2018-05-15 04:58:42 --> UTF-8 Support Enabled
INFO - 2018-05-15 04:58:42 --> Config Class Initialized
INFO - 2018-05-15 04:58:42 --> Hooks Class Initialized
INFO - 2018-05-15 04:58:42 --> Utf8 Class Initialized
INFO - 2018-05-15 04:58:42 --> Config Class Initialized
INFO - 2018-05-15 04:58:42 --> Config Class Initialized
DEBUG - 2018-05-15 04:58:42 --> UTF-8 Support Enabled
INFO - 2018-05-15 04:58:42 --> URI Class Initialized
INFO - 2018-05-15 04:58:42 --> Hooks Class Initialized
INFO - 2018-05-15 04:58:42 --> Hooks Class Initialized
INFO - 2018-05-15 04:58:42 --> Utf8 Class Initialized
INFO - 2018-05-15 04:58:42 --> Router Class Initialized
INFO - 2018-05-15 04:58:42 --> URI Class Initialized
DEBUG - 2018-05-15 04:58:42 --> UTF-8 Support Enabled
INFO - 2018-05-15 04:58:42 --> Output Class Initialized
DEBUG - 2018-05-15 04:58:42 --> UTF-8 Support Enabled
INFO - 2018-05-15 04:58:42 --> Utf8 Class Initialized
INFO - 2018-05-15 04:58:42 --> Security Class Initialized
INFO - 2018-05-15 04:58:42 --> Utf8 Class Initialized
INFO - 2018-05-15 04:58:42 --> Router Class Initialized
DEBUG - 2018-05-15 04:58:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:58:42 --> URI Class Initialized
INFO - 2018-05-15 04:58:42 --> URI Class Initialized
INFO - 2018-05-15 04:58:42 --> Output Class Initialized
INFO - 2018-05-15 04:58:42 --> Input Class Initialized
INFO - 2018-05-15 04:58:42 --> Router Class Initialized
INFO - 2018-05-15 04:58:42 --> Security Class Initialized
INFO - 2018-05-15 04:58:42 --> Router Class Initialized
INFO - 2018-05-15 04:58:42 --> Output Class Initialized
INFO - 2018-05-15 04:58:42 --> Language Class Initialized
DEBUG - 2018-05-15 04:58:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:58:42 --> Output Class Initialized
INFO - 2018-05-15 04:58:42 --> Input Class Initialized
ERROR - 2018-05-15 04:58:42 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:58:42 --> Security Class Initialized
INFO - 2018-05-15 04:58:42 --> Security Class Initialized
INFO - 2018-05-15 04:58:42 --> Language Class Initialized
DEBUG - 2018-05-15 04:58:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-05-15 04:58:42 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:58:42 --> Input Class Initialized
DEBUG - 2018-05-15 04:58:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:58:42 --> Input Class Initialized
INFO - 2018-05-15 04:58:42 --> Language Class Initialized
ERROR - 2018-05-15 04:58:42 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:58:42 --> Language Class Initialized
ERROR - 2018-05-15 04:58:42 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:58:52 --> Config Class Initialized
INFO - 2018-05-15 04:58:52 --> Hooks Class Initialized
DEBUG - 2018-05-15 04:58:52 --> UTF-8 Support Enabled
INFO - 2018-05-15 04:58:52 --> Utf8 Class Initialized
INFO - 2018-05-15 04:58:52 --> URI Class Initialized
INFO - 2018-05-15 04:58:52 --> Router Class Initialized
INFO - 2018-05-15 04:58:53 --> Config Class Initialized
INFO - 2018-05-15 04:58:53 --> Config Class Initialized
INFO - 2018-05-15 04:58:53 --> Hooks Class Initialized
INFO - 2018-05-15 04:58:53 --> Hooks Class Initialized
INFO - 2018-05-15 04:58:53 --> Config Class Initialized
INFO - 2018-05-15 04:58:53 --> Output Class Initialized
INFO - 2018-05-15 04:58:53 --> Config Class Initialized
DEBUG - 2018-05-15 04:58:53 --> UTF-8 Support Enabled
INFO - 2018-05-15 04:58:53 --> Hooks Class Initialized
DEBUG - 2018-05-15 04:58:53 --> UTF-8 Support Enabled
INFO - 2018-05-15 04:58:53 --> Config Class Initialized
INFO - 2018-05-15 04:58:53 --> Security Class Initialized
INFO - 2018-05-15 04:58:53 --> Hooks Class Initialized
INFO - 2018-05-15 04:58:53 --> Utf8 Class Initialized
INFO - 2018-05-15 04:58:53 --> Hooks Class Initialized
DEBUG - 2018-05-15 04:58:53 --> UTF-8 Support Enabled
INFO - 2018-05-15 04:58:53 --> Utf8 Class Initialized
DEBUG - 2018-05-15 04:58:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-15 04:58:53 --> UTF-8 Support Enabled
INFO - 2018-05-15 04:58:53 --> Utf8 Class Initialized
INFO - 2018-05-15 04:58:53 --> URI Class Initialized
DEBUG - 2018-05-15 04:58:53 --> UTF-8 Support Enabled
INFO - 2018-05-15 04:58:53 --> Input Class Initialized
INFO - 2018-05-15 04:58:53 --> Utf8 Class Initialized
INFO - 2018-05-15 04:58:53 --> URI Class Initialized
INFO - 2018-05-15 04:58:53 --> URI Class Initialized
INFO - 2018-05-15 04:58:53 --> URI Class Initialized
INFO - 2018-05-15 04:58:53 --> Language Class Initialized
INFO - 2018-05-15 04:58:53 --> Router Class Initialized
INFO - 2018-05-15 04:58:53 --> Utf8 Class Initialized
INFO - 2018-05-15 04:58:53 --> Router Class Initialized
INFO - 2018-05-15 04:58:53 --> Router Class Initialized
INFO - 2018-05-15 04:58:53 --> Router Class Initialized
INFO - 2018-05-15 04:58:53 --> Output Class Initialized
INFO - 2018-05-15 04:58:53 --> Output Class Initialized
ERROR - 2018-05-15 04:58:53 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:58:53 --> URI Class Initialized
INFO - 2018-05-15 04:58:53 --> Output Class Initialized
INFO - 2018-05-15 04:58:53 --> Security Class Initialized
INFO - 2018-05-15 04:58:53 --> Output Class Initialized
INFO - 2018-05-15 04:58:53 --> Security Class Initialized
INFO - 2018-05-15 04:58:53 --> Router Class Initialized
INFO - 2018-05-15 04:58:53 --> Security Class Initialized
DEBUG - 2018-05-15 04:58:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-15 04:58:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:58:53 --> Output Class Initialized
INFO - 2018-05-15 04:58:53 --> Security Class Initialized
INFO - 2018-05-15 04:58:53 --> Input Class Initialized
INFO - 2018-05-15 04:58:53 --> Input Class Initialized
DEBUG - 2018-05-15 04:58:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-15 04:58:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:58:53 --> Language Class Initialized
INFO - 2018-05-15 04:58:53 --> Security Class Initialized
INFO - 2018-05-15 04:58:53 --> Language Class Initialized
INFO - 2018-05-15 04:58:53 --> Input Class Initialized
INFO - 2018-05-15 04:58:53 --> Input Class Initialized
ERROR - 2018-05-15 04:58:53 --> 404 Page Not Found: /index
DEBUG - 2018-05-15 04:58:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:58:53 --> Input Class Initialized
INFO - 2018-05-15 04:58:53 --> Language Class Initialized
INFO - 2018-05-15 04:58:53 --> Language Class Initialized
INFO - 2018-05-15 04:58:53 --> Language Class Initialized
ERROR - 2018-05-15 04:58:53 --> 404 Page Not Found: /index
ERROR - 2018-05-15 04:58:53 --> 404 Page Not Found: /index
ERROR - 2018-05-15 04:58:53 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:58:53 --> Config Class Initialized
ERROR - 2018-05-15 04:58:53 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:58:53 --> Hooks Class Initialized
INFO - 2018-05-15 04:58:53 --> Config Class Initialized
INFO - 2018-05-15 04:58:53 --> Hooks Class Initialized
DEBUG - 2018-05-15 04:58:53 --> UTF-8 Support Enabled
INFO - 2018-05-15 04:58:53 --> Config Class Initialized
INFO - 2018-05-15 04:58:53 --> Hooks Class Initialized
DEBUG - 2018-05-15 04:58:53 --> UTF-8 Support Enabled
INFO - 2018-05-15 04:58:53 --> Config Class Initialized
INFO - 2018-05-15 04:58:53 --> Utf8 Class Initialized
INFO - 2018-05-15 04:58:53 --> Utf8 Class Initialized
INFO - 2018-05-15 04:58:53 --> Hooks Class Initialized
DEBUG - 2018-05-15 04:58:53 --> UTF-8 Support Enabled
INFO - 2018-05-15 04:58:53 --> URI Class Initialized
INFO - 2018-05-15 04:58:53 --> Router Class Initialized
INFO - 2018-05-15 04:58:53 --> Utf8 Class Initialized
INFO - 2018-05-15 04:58:53 --> URI Class Initialized
DEBUG - 2018-05-15 04:58:53 --> UTF-8 Support Enabled
INFO - 2018-05-15 04:58:53 --> URI Class Initialized
INFO - 2018-05-15 04:58:53 --> Utf8 Class Initialized
INFO - 2018-05-15 04:58:53 --> Router Class Initialized
INFO - 2018-05-15 04:58:53 --> Output Class Initialized
INFO - 2018-05-15 04:58:53 --> URI Class Initialized
INFO - 2018-05-15 04:58:53 --> Output Class Initialized
INFO - 2018-05-15 04:58:53 --> Router Class Initialized
INFO - 2018-05-15 04:58:53 --> Security Class Initialized
INFO - 2018-05-15 04:58:53 --> Output Class Initialized
INFO - 2018-05-15 04:58:53 --> Security Class Initialized
INFO - 2018-05-15 04:58:53 --> Router Class Initialized
DEBUG - 2018-05-15 04:58:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:58:53 --> Input Class Initialized
INFO - 2018-05-15 04:58:53 --> Output Class Initialized
INFO - 2018-05-15 04:58:53 --> Security Class Initialized
DEBUG - 2018-05-15 04:58:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-15 04:58:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:58:53 --> Input Class Initialized
INFO - 2018-05-15 04:58:53 --> Language Class Initialized
INFO - 2018-05-15 04:58:53 --> Security Class Initialized
DEBUG - 2018-05-15 04:58:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:58:53 --> Input Class Initialized
ERROR - 2018-05-15 04:58:53 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:58:53 --> Language Class Initialized
INFO - 2018-05-15 04:58:53 --> Config Class Initialized
INFO - 2018-05-15 04:58:53 --> Input Class Initialized
INFO - 2018-05-15 04:58:53 --> Language Class Initialized
ERROR - 2018-05-15 04:58:53 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:58:54 --> Hooks Class Initialized
DEBUG - 2018-05-15 04:58:54 --> UTF-8 Support Enabled
INFO - 2018-05-15 04:58:54 --> Utf8 Class Initialized
INFO - 2018-05-15 04:58:54 --> URI Class Initialized
INFO - 2018-05-15 04:58:54 --> Router Class Initialized
INFO - 2018-05-15 04:58:54 --> Language Class Initialized
ERROR - 2018-05-15 04:58:54 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:58:54 --> Output Class Initialized
INFO - 2018-05-15 04:58:54 --> Config Class Initialized
INFO - 2018-05-15 04:58:54 --> Hooks Class Initialized
ERROR - 2018-05-15 04:58:54 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:58:54 --> Security Class Initialized
INFO - 2018-05-15 04:58:54 --> Config Class Initialized
INFO - 2018-05-15 04:58:54 --> Hooks Class Initialized
DEBUG - 2018-05-15 04:58:54 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 04:58:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:58:54 --> Config Class Initialized
INFO - 2018-05-15 04:58:54 --> Hooks Class Initialized
DEBUG - 2018-05-15 04:58:54 --> UTF-8 Support Enabled
INFO - 2018-05-15 04:58:54 --> Utf8 Class Initialized
INFO - 2018-05-15 04:58:54 --> Input Class Initialized
INFO - 2018-05-15 04:58:54 --> Utf8 Class Initialized
INFO - 2018-05-15 04:58:54 --> Language Class Initialized
DEBUG - 2018-05-15 04:58:54 --> UTF-8 Support Enabled
INFO - 2018-05-15 04:58:54 --> URI Class Initialized
INFO - 2018-05-15 04:58:54 --> URI Class Initialized
INFO - 2018-05-15 04:58:54 --> Utf8 Class Initialized
INFO - 2018-05-15 04:58:54 --> Router Class Initialized
ERROR - 2018-05-15 04:58:54 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:58:54 --> Output Class Initialized
INFO - 2018-05-15 04:58:54 --> Router Class Initialized
INFO - 2018-05-15 04:58:54 --> URI Class Initialized
INFO - 2018-05-15 04:58:54 --> Security Class Initialized
INFO - 2018-05-15 04:58:54 --> Router Class Initialized
INFO - 2018-05-15 04:58:54 --> Output Class Initialized
INFO - 2018-05-15 04:58:54 --> Output Class Initialized
INFO - 2018-05-15 04:58:54 --> Security Class Initialized
DEBUG - 2018-05-15 04:58:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:58:54 --> Input Class Initialized
DEBUG - 2018-05-15 04:58:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:58:54 --> Security Class Initialized
DEBUG - 2018-05-15 04:58:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:58:54 --> Input Class Initialized
INFO - 2018-05-15 04:58:54 --> Language Class Initialized
INFO - 2018-05-15 04:58:54 --> Language Class Initialized
ERROR - 2018-05-15 04:58:54 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:58:54 --> Input Class Initialized
ERROR - 2018-05-15 04:58:54 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:58:54 --> Language Class Initialized
ERROR - 2018-05-15 04:58:54 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:58:54 --> Config Class Initialized
INFO - 2018-05-15 04:58:54 --> Hooks Class Initialized
DEBUG - 2018-05-15 04:58:55 --> UTF-8 Support Enabled
INFO - 2018-05-15 04:58:55 --> Config Class Initialized
INFO - 2018-05-15 04:58:55 --> Config Class Initialized
INFO - 2018-05-15 04:58:55 --> Config Class Initialized
INFO - 2018-05-15 04:58:55 --> Config Class Initialized
INFO - 2018-05-15 04:58:55 --> Config Class Initialized
INFO - 2018-05-15 04:58:55 --> Hooks Class Initialized
INFO - 2018-05-15 04:58:55 --> Hooks Class Initialized
INFO - 2018-05-15 04:58:55 --> Hooks Class Initialized
INFO - 2018-05-15 04:58:55 --> Utf8 Class Initialized
INFO - 2018-05-15 04:58:55 --> Hooks Class Initialized
INFO - 2018-05-15 04:58:55 --> Hooks Class Initialized
DEBUG - 2018-05-15 04:58:55 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 04:58:55 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 04:58:55 --> UTF-8 Support Enabled
INFO - 2018-05-15 04:58:55 --> URI Class Initialized
INFO - 2018-05-15 04:58:55 --> Utf8 Class Initialized
DEBUG - 2018-05-15 04:58:55 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 04:58:55 --> UTF-8 Support Enabled
INFO - 2018-05-15 04:58:55 --> Utf8 Class Initialized
INFO - 2018-05-15 04:58:55 --> Utf8 Class Initialized
INFO - 2018-05-15 04:58:55 --> Utf8 Class Initialized
INFO - 2018-05-15 04:58:55 --> URI Class Initialized
INFO - 2018-05-15 04:58:55 --> Router Class Initialized
INFO - 2018-05-15 04:58:55 --> Utf8 Class Initialized
INFO - 2018-05-15 04:58:55 --> URI Class Initialized
INFO - 2018-05-15 04:58:55 --> URI Class Initialized
INFO - 2018-05-15 04:58:55 --> URI Class Initialized
INFO - 2018-05-15 04:58:55 --> Router Class Initialized
INFO - 2018-05-15 04:58:55 --> URI Class Initialized
INFO - 2018-05-15 04:58:55 --> Output Class Initialized
INFO - 2018-05-15 04:58:55 --> Router Class Initialized
INFO - 2018-05-15 04:58:55 --> Output Class Initialized
INFO - 2018-05-15 04:58:55 --> Router Class Initialized
INFO - 2018-05-15 04:58:55 --> Router Class Initialized
INFO - 2018-05-15 04:58:55 --> Security Class Initialized
INFO - 2018-05-15 04:58:55 --> Router Class Initialized
INFO - 2018-05-15 04:58:55 --> Output Class Initialized
DEBUG - 2018-05-15 04:58:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:58:55 --> Output Class Initialized
INFO - 2018-05-15 04:58:55 --> Output Class Initialized
INFO - 2018-05-15 04:58:55 --> Output Class Initialized
INFO - 2018-05-15 04:58:55 --> Security Class Initialized
INFO - 2018-05-15 04:58:55 --> Security Class Initialized
DEBUG - 2018-05-15 04:58:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:58:55 --> Security Class Initialized
INFO - 2018-05-15 04:58:55 --> Security Class Initialized
INFO - 2018-05-15 04:58:55 --> Input Class Initialized
INFO - 2018-05-15 04:58:55 --> Security Class Initialized
DEBUG - 2018-05-15 04:58:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:58:55 --> Input Class Initialized
DEBUG - 2018-05-15 04:58:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:58:55 --> Input Class Initialized
DEBUG - 2018-05-15 04:58:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:58:55 --> Language Class Initialized
DEBUG - 2018-05-15 04:58:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:58:55 --> Input Class Initialized
INFO - 2018-05-15 04:58:55 --> Input Class Initialized
INFO - 2018-05-15 04:58:55 --> Language Class Initialized
INFO - 2018-05-15 04:58:55 --> Language Class Initialized
INFO - 2018-05-15 04:58:55 --> Input Class Initialized
ERROR - 2018-05-15 04:58:55 --> 404 Page Not Found: /index
ERROR - 2018-05-15 04:58:55 --> 404 Page Not Found: /index
ERROR - 2018-05-15 04:58:55 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:58:55 --> Language Class Initialized
INFO - 2018-05-15 04:58:55 --> Language Class Initialized
INFO - 2018-05-15 04:58:55 --> Config Class Initialized
INFO - 2018-05-15 04:58:55 --> Language Class Initialized
INFO - 2018-05-15 04:58:55 --> Hooks Class Initialized
ERROR - 2018-05-15 04:58:55 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:58:55 --> Config Class Initialized
ERROR - 2018-05-15 04:58:55 --> 404 Page Not Found: /index
ERROR - 2018-05-15 04:58:55 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:58:55 --> Hooks Class Initialized
DEBUG - 2018-05-15 04:58:55 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 04:58:55 --> UTF-8 Support Enabled
INFO - 2018-05-15 04:58:55 --> Utf8 Class Initialized
INFO - 2018-05-15 04:58:55 --> URI Class Initialized
INFO - 2018-05-15 04:58:55 --> Utf8 Class Initialized
INFO - 2018-05-15 04:58:55 --> Router Class Initialized
INFO - 2018-05-15 04:58:55 --> Config Class Initialized
INFO - 2018-05-15 04:58:55 --> Config Class Initialized
INFO - 2018-05-15 04:58:55 --> Hooks Class Initialized
INFO - 2018-05-15 04:58:55 --> Hooks Class Initialized
INFO - 2018-05-15 04:58:55 --> Config Class Initialized
INFO - 2018-05-15 04:58:55 --> URI Class Initialized
INFO - 2018-05-15 04:58:55 --> Output Class Initialized
INFO - 2018-05-15 04:58:55 --> Hooks Class Initialized
DEBUG - 2018-05-15 04:58:55 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 04:58:55 --> UTF-8 Support Enabled
INFO - 2018-05-15 04:58:55 --> Security Class Initialized
INFO - 2018-05-15 04:58:55 --> Router Class Initialized
DEBUG - 2018-05-15 04:58:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-15 04:58:55 --> UTF-8 Support Enabled
INFO - 2018-05-15 04:58:55 --> Output Class Initialized
INFO - 2018-05-15 04:58:55 --> Utf8 Class Initialized
INFO - 2018-05-15 04:58:55 --> Utf8 Class Initialized
INFO - 2018-05-15 04:58:55 --> Utf8 Class Initialized
INFO - 2018-05-15 04:58:55 --> Security Class Initialized
INFO - 2018-05-15 04:58:55 --> Input Class Initialized
INFO - 2018-05-15 04:58:55 --> URI Class Initialized
INFO - 2018-05-15 04:58:55 --> URI Class Initialized
DEBUG - 2018-05-15 04:58:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:58:55 --> Language Class Initialized
INFO - 2018-05-15 04:58:55 --> URI Class Initialized
INFO - 2018-05-15 04:58:55 --> Router Class Initialized
INFO - 2018-05-15 04:58:55 --> Input Class Initialized
INFO - 2018-05-15 04:58:55 --> Router Class Initialized
ERROR - 2018-05-15 04:58:55 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:58:55 --> Router Class Initialized
INFO - 2018-05-15 04:58:56 --> Output Class Initialized
INFO - 2018-05-15 04:58:56 --> Output Class Initialized
INFO - 2018-05-15 04:58:56 --> Language Class Initialized
INFO - 2018-05-15 04:58:56 --> Output Class Initialized
INFO - 2018-05-15 04:58:56 --> Config Class Initialized
ERROR - 2018-05-15 04:58:56 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:58:56 --> Security Class Initialized
INFO - 2018-05-15 04:58:56 --> Hooks Class Initialized
INFO - 2018-05-15 04:58:56 --> Security Class Initialized
INFO - 2018-05-15 04:58:56 --> Security Class Initialized
DEBUG - 2018-05-15 04:58:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-15 04:58:56 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 04:58:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:58:56 --> Config Class Initialized
INFO - 2018-05-15 04:58:56 --> Hooks Class Initialized
INFO - 2018-05-15 04:58:56 --> Input Class Initialized
INFO - 2018-05-15 04:58:56 --> Utf8 Class Initialized
DEBUG - 2018-05-15 04:58:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:58:56 --> Input Class Initialized
INFO - 2018-05-15 04:58:56 --> Language Class Initialized
INFO - 2018-05-15 04:58:56 --> Language Class Initialized
INFO - 2018-05-15 04:58:56 --> Input Class Initialized
INFO - 2018-05-15 04:58:56 --> URI Class Initialized
DEBUG - 2018-05-15 04:58:56 --> UTF-8 Support Enabled
ERROR - 2018-05-15 04:58:56 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:58:56 --> Utf8 Class Initialized
INFO - 2018-05-15 04:58:56 --> Language Class Initialized
ERROR - 2018-05-15 04:58:56 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:58:56 --> Router Class Initialized
INFO - 2018-05-15 04:58:56 --> Config Class Initialized
INFO - 2018-05-15 04:58:56 --> Hooks Class Initialized
ERROR - 2018-05-15 04:58:56 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:58:56 --> Output Class Initialized
INFO - 2018-05-15 04:58:56 --> Config Class Initialized
INFO - 2018-05-15 04:58:56 --> URI Class Initialized
INFO - 2018-05-15 04:58:56 --> Hooks Class Initialized
DEBUG - 2018-05-15 04:58:56 --> UTF-8 Support Enabled
INFO - 2018-05-15 04:58:56 --> Router Class Initialized
INFO - 2018-05-15 04:58:56 --> Security Class Initialized
INFO - 2018-05-15 04:58:56 --> Config Class Initialized
INFO - 2018-05-15 04:58:56 --> Hooks Class Initialized
DEBUG - 2018-05-15 04:58:56 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 04:58:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:58:56 --> Output Class Initialized
INFO - 2018-05-15 04:58:56 --> Utf8 Class Initialized
INFO - 2018-05-15 04:58:56 --> Utf8 Class Initialized
INFO - 2018-05-15 04:58:56 --> URI Class Initialized
INFO - 2018-05-15 04:58:56 --> Input Class Initialized
INFO - 2018-05-15 04:58:56 --> Security Class Initialized
DEBUG - 2018-05-15 04:58:56 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 04:58:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:58:56 --> Language Class Initialized
INFO - 2018-05-15 04:58:56 --> Utf8 Class Initialized
INFO - 2018-05-15 04:58:56 --> Router Class Initialized
INFO - 2018-05-15 04:58:56 --> URI Class Initialized
INFO - 2018-05-15 04:58:56 --> Input Class Initialized
INFO - 2018-05-15 04:58:56 --> URI Class Initialized
ERROR - 2018-05-15 04:58:56 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:58:56 --> Output Class Initialized
INFO - 2018-05-15 04:58:56 --> Router Class Initialized
INFO - 2018-05-15 04:58:56 --> Language Class Initialized
ERROR - 2018-05-15 04:58:56 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:58:56 --> Security Class Initialized
INFO - 2018-05-15 04:58:56 --> Router Class Initialized
INFO - 2018-05-15 04:58:56 --> Output Class Initialized
INFO - 2018-05-15 04:58:56 --> Security Class Initialized
INFO - 2018-05-15 04:58:56 --> Output Class Initialized
DEBUG - 2018-05-15 04:58:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:58:56 --> Config Class Initialized
INFO - 2018-05-15 04:58:56 --> Hooks Class Initialized
DEBUG - 2018-05-15 04:58:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:58:56 --> Input Class Initialized
INFO - 2018-05-15 04:58:56 --> Security Class Initialized
INFO - 2018-05-15 04:58:56 --> Input Class Initialized
DEBUG - 2018-05-15 04:58:56 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 04:58:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:58:56 --> Language Class Initialized
ERROR - 2018-05-15 04:58:56 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:58:56 --> Utf8 Class Initialized
INFO - 2018-05-15 04:58:56 --> Input Class Initialized
INFO - 2018-05-15 04:58:56 --> Language Class Initialized
ERROR - 2018-05-15 04:58:56 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:58:56 --> Language Class Initialized
ERROR - 2018-05-15 04:58:56 --> 404 Page Not Found: /index
INFO - 2018-05-15 04:58:56 --> URI Class Initialized
INFO - 2018-05-15 04:58:56 --> Router Class Initialized
INFO - 2018-05-15 04:58:56 --> Output Class Initialized
INFO - 2018-05-15 04:58:56 --> Security Class Initialized
DEBUG - 2018-05-15 04:58:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 04:58:56 --> Input Class Initialized
INFO - 2018-05-15 04:58:56 --> Language Class Initialized
ERROR - 2018-05-15 04:58:56 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:00:00 --> Config Class Initialized
INFO - 2018-05-15 05:00:00 --> Hooks Class Initialized
DEBUG - 2018-05-15 05:00:00 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:00:00 --> Utf8 Class Initialized
INFO - 2018-05-15 05:00:00 --> URI Class Initialized
INFO - 2018-05-15 05:00:00 --> Router Class Initialized
INFO - 2018-05-15 05:00:00 --> Output Class Initialized
INFO - 2018-05-15 05:00:00 --> Security Class Initialized
DEBUG - 2018-05-15 05:00:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:00:00 --> Config Class Initialized
INFO - 2018-05-15 05:00:00 --> Config Class Initialized
INFO - 2018-05-15 05:00:00 --> Config Class Initialized
INFO - 2018-05-15 05:00:00 --> Config Class Initialized
INFO - 2018-05-15 05:00:00 --> Hooks Class Initialized
INFO - 2018-05-15 05:00:00 --> Hooks Class Initialized
INFO - 2018-05-15 05:00:00 --> Hooks Class Initialized
INFO - 2018-05-15 05:00:00 --> Input Class Initialized
INFO - 2018-05-15 05:00:00 --> Config Class Initialized
INFO - 2018-05-15 05:00:00 --> Hooks Class Initialized
DEBUG - 2018-05-15 05:00:00 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 05:00:00 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:00:00 --> Language Class Initialized
INFO - 2018-05-15 05:00:00 --> Hooks Class Initialized
DEBUG - 2018-05-15 05:00:00 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 05:00:00 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:00:00 --> Utf8 Class Initialized
INFO - 2018-05-15 05:00:00 --> Utf8 Class Initialized
INFO - 2018-05-15 05:00:00 --> Utf8 Class Initialized
INFO - 2018-05-15 05:00:00 --> URI Class Initialized
ERROR - 2018-05-15 05:00:00 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:00:00 --> Utf8 Class Initialized
DEBUG - 2018-05-15 05:00:00 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:00:00 --> URI Class Initialized
INFO - 2018-05-15 05:00:00 --> URI Class Initialized
INFO - 2018-05-15 05:00:00 --> Router Class Initialized
INFO - 2018-05-15 05:00:00 --> Router Class Initialized
INFO - 2018-05-15 05:00:00 --> Router Class Initialized
INFO - 2018-05-15 05:00:00 --> Utf8 Class Initialized
INFO - 2018-05-15 05:00:00 --> URI Class Initialized
INFO - 2018-05-15 05:00:00 --> Output Class Initialized
INFO - 2018-05-15 05:00:00 --> Output Class Initialized
INFO - 2018-05-15 05:00:00 --> URI Class Initialized
INFO - 2018-05-15 05:00:00 --> Output Class Initialized
INFO - 2018-05-15 05:00:00 --> Router Class Initialized
INFO - 2018-05-15 05:00:00 --> Security Class Initialized
INFO - 2018-05-15 05:00:00 --> Security Class Initialized
INFO - 2018-05-15 05:00:00 --> Security Class Initialized
INFO - 2018-05-15 05:00:00 --> Router Class Initialized
DEBUG - 2018-05-15 05:00:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-15 05:00:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:00:01 --> Output Class Initialized
DEBUG - 2018-05-15 05:00:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:00:01 --> Output Class Initialized
INFO - 2018-05-15 05:00:01 --> Security Class Initialized
INFO - 2018-05-15 05:00:01 --> Input Class Initialized
INFO - 2018-05-15 05:00:01 --> Input Class Initialized
INFO - 2018-05-15 05:00:01 --> Input Class Initialized
INFO - 2018-05-15 05:00:01 --> Security Class Initialized
INFO - 2018-05-15 05:00:01 --> Language Class Initialized
DEBUG - 2018-05-15 05:00:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:00:01 --> Language Class Initialized
INFO - 2018-05-15 05:00:01 --> Language Class Initialized
DEBUG - 2018-05-15 05:00:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-05-15 05:00:01 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:00:01 --> Input Class Initialized
ERROR - 2018-05-15 05:00:01 --> 404 Page Not Found: /index
ERROR - 2018-05-15 05:00:01 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:00:01 --> Input Class Initialized
INFO - 2018-05-15 05:00:01 --> Language Class Initialized
INFO - 2018-05-15 05:00:01 --> Language Class Initialized
INFO - 2018-05-15 05:00:01 --> Config Class Initialized
ERROR - 2018-05-15 05:00:01 --> 404 Page Not Found: /index
ERROR - 2018-05-15 05:00:01 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:00:01 --> Hooks Class Initialized
INFO - 2018-05-15 05:00:01 --> Config Class Initialized
INFO - 2018-05-15 05:00:01 --> Hooks Class Initialized
DEBUG - 2018-05-15 05:00:01 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:00:01 --> Config Class Initialized
INFO - 2018-05-15 05:00:01 --> Config Class Initialized
INFO - 2018-05-15 05:00:01 --> Hooks Class Initialized
INFO - 2018-05-15 05:00:01 --> Hooks Class Initialized
DEBUG - 2018-05-15 05:00:01 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:00:01 --> Utf8 Class Initialized
DEBUG - 2018-05-15 05:00:01 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 05:00:01 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:00:01 --> Utf8 Class Initialized
INFO - 2018-05-15 05:00:01 --> URI Class Initialized
INFO - 2018-05-15 05:00:01 --> Utf8 Class Initialized
INFO - 2018-05-15 05:00:01 --> Utf8 Class Initialized
INFO - 2018-05-15 05:00:01 --> URI Class Initialized
INFO - 2018-05-15 05:00:01 --> Router Class Initialized
INFO - 2018-05-15 05:00:01 --> URI Class Initialized
INFO - 2018-05-15 05:00:01 --> URI Class Initialized
INFO - 2018-05-15 05:00:01 --> Router Class Initialized
INFO - 2018-05-15 05:00:01 --> Output Class Initialized
INFO - 2018-05-15 05:00:01 --> Output Class Initialized
INFO - 2018-05-15 05:00:01 --> Security Class Initialized
INFO - 2018-05-15 05:00:01 --> Router Class Initialized
INFO - 2018-05-15 05:00:01 --> Router Class Initialized
DEBUG - 2018-05-15 05:00:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:00:01 --> Output Class Initialized
INFO - 2018-05-15 05:00:01 --> Security Class Initialized
INFO - 2018-05-15 05:00:01 --> Output Class Initialized
INFO - 2018-05-15 05:00:01 --> Input Class Initialized
DEBUG - 2018-05-15 05:00:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:00:01 --> Security Class Initialized
INFO - 2018-05-15 05:00:01 --> Security Class Initialized
INFO - 2018-05-15 05:00:01 --> Input Class Initialized
DEBUG - 2018-05-15 05:00:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-15 05:00:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:00:01 --> Language Class Initialized
INFO - 2018-05-15 05:00:01 --> Input Class Initialized
INFO - 2018-05-15 05:00:01 --> Input Class Initialized
INFO - 2018-05-15 05:00:01 --> Language Class Initialized
ERROR - 2018-05-15 05:00:01 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:00:01 --> Language Class Initialized
ERROR - 2018-05-15 05:00:01 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:00:01 --> Language Class Initialized
INFO - 2018-05-15 05:00:01 --> Config Class Initialized
INFO - 2018-05-15 05:00:01 --> Hooks Class Initialized
ERROR - 2018-05-15 05:00:01 --> 404 Page Not Found: /index
ERROR - 2018-05-15 05:00:01 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:00:01 --> Config Class Initialized
INFO - 2018-05-15 05:00:01 --> Hooks Class Initialized
DEBUG - 2018-05-15 05:00:01 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:00:01 --> Config Class Initialized
INFO - 2018-05-15 05:00:01 --> Config Class Initialized
INFO - 2018-05-15 05:00:01 --> Hooks Class Initialized
INFO - 2018-05-15 05:00:01 --> Hooks Class Initialized
INFO - 2018-05-15 05:00:01 --> Utf8 Class Initialized
DEBUG - 2018-05-15 05:00:01 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 05:00:01 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:00:01 --> Utf8 Class Initialized
INFO - 2018-05-15 05:00:01 --> URI Class Initialized
DEBUG - 2018-05-15 05:00:01 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:00:01 --> Utf8 Class Initialized
INFO - 2018-05-15 05:00:01 --> URI Class Initialized
INFO - 2018-05-15 05:00:01 --> Utf8 Class Initialized
INFO - 2018-05-15 05:00:01 --> Router Class Initialized
INFO - 2018-05-15 05:00:01 --> URI Class Initialized
INFO - 2018-05-15 05:00:01 --> URI Class Initialized
INFO - 2018-05-15 05:00:01 --> Router Class Initialized
INFO - 2018-05-15 05:00:01 --> Output Class Initialized
INFO - 2018-05-15 05:00:01 --> Output Class Initialized
INFO - 2018-05-15 05:00:01 --> Router Class Initialized
INFO - 2018-05-15 05:00:01 --> Security Class Initialized
INFO - 2018-05-15 05:00:01 --> Router Class Initialized
DEBUG - 2018-05-15 05:00:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:00:01 --> Security Class Initialized
INFO - 2018-05-15 05:00:01 --> Output Class Initialized
INFO - 2018-05-15 05:00:01 --> Output Class Initialized
INFO - 2018-05-15 05:00:01 --> Input Class Initialized
INFO - 2018-05-15 05:00:01 --> Security Class Initialized
INFO - 2018-05-15 05:00:01 --> Security Class Initialized
DEBUG - 2018-05-15 05:00:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:00:01 --> Input Class Initialized
DEBUG - 2018-05-15 05:00:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-15 05:00:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:00:01 --> Language Class Initialized
INFO - 2018-05-15 05:00:01 --> Input Class Initialized
INFO - 2018-05-15 05:00:01 --> Language Class Initialized
INFO - 2018-05-15 05:00:01 --> Input Class Initialized
ERROR - 2018-05-15 05:00:01 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:00:01 --> Language Class Initialized
INFO - 2018-05-15 05:00:01 --> Language Class Initialized
ERROR - 2018-05-15 05:00:01 --> 404 Page Not Found: /index
ERROR - 2018-05-15 05:00:01 --> 404 Page Not Found: /index
ERROR - 2018-05-15 05:00:01 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:00:07 --> Config Class Initialized
INFO - 2018-05-15 05:00:07 --> Hooks Class Initialized
DEBUG - 2018-05-15 05:00:07 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:00:07 --> Utf8 Class Initialized
INFO - 2018-05-15 05:00:07 --> URI Class Initialized
INFO - 2018-05-15 05:00:07 --> Router Class Initialized
INFO - 2018-05-15 05:00:07 --> Config Class Initialized
INFO - 2018-05-15 05:00:07 --> Hooks Class Initialized
INFO - 2018-05-15 05:00:07 --> Config Class Initialized
INFO - 2018-05-15 05:00:07 --> Output Class Initialized
INFO - 2018-05-15 05:00:07 --> Hooks Class Initialized
DEBUG - 2018-05-15 05:00:07 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:00:07 --> Config Class Initialized
INFO - 2018-05-15 05:00:07 --> Security Class Initialized
INFO - 2018-05-15 05:00:07 --> Config Class Initialized
INFO - 2018-05-15 05:00:07 --> Config Class Initialized
DEBUG - 2018-05-15 05:00:07 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:00:07 --> Utf8 Class Initialized
INFO - 2018-05-15 05:00:07 --> URI Class Initialized
INFO - 2018-05-15 05:00:07 --> Router Class Initialized
INFO - 2018-05-15 05:00:07 --> Output Class Initialized
INFO - 2018-05-15 05:00:07 --> Hooks Class Initialized
INFO - 2018-05-15 05:00:07 --> Hooks Class Initialized
DEBUG - 2018-05-15 05:00:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:00:07 --> Hooks Class Initialized
INFO - 2018-05-15 05:00:07 --> Utf8 Class Initialized
INFO - 2018-05-15 05:00:07 --> Security Class Initialized
DEBUG - 2018-05-15 05:00:07 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 05:00:07 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:00:07 --> Input Class Initialized
DEBUG - 2018-05-15 05:00:07 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:00:07 --> URI Class Initialized
DEBUG - 2018-05-15 05:00:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:00:07 --> Utf8 Class Initialized
INFO - 2018-05-15 05:00:07 --> Language Class Initialized
INFO - 2018-05-15 05:00:07 --> Utf8 Class Initialized
INFO - 2018-05-15 05:00:07 --> Input Class Initialized
INFO - 2018-05-15 05:00:07 --> Utf8 Class Initialized
INFO - 2018-05-15 05:00:07 --> Router Class Initialized
INFO - 2018-05-15 05:00:07 --> URI Class Initialized
ERROR - 2018-05-15 05:00:07 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:00:07 --> Language Class Initialized
INFO - 2018-05-15 05:00:07 --> URI Class Initialized
INFO - 2018-05-15 05:00:07 --> URI Class Initialized
INFO - 2018-05-15 05:00:07 --> Output Class Initialized
INFO - 2018-05-15 05:00:07 --> Router Class Initialized
ERROR - 2018-05-15 05:00:07 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:00:07 --> Security Class Initialized
INFO - 2018-05-15 05:00:07 --> Router Class Initialized
INFO - 2018-05-15 05:00:07 --> Router Class Initialized
INFO - 2018-05-15 05:00:07 --> Output Class Initialized
INFO - 2018-05-15 05:00:07 --> Security Class Initialized
INFO - 2018-05-15 05:00:07 --> Output Class Initialized
INFO - 2018-05-15 05:00:07 --> Output Class Initialized
DEBUG - 2018-05-15 05:00:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-15 05:00:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:00:07 --> Input Class Initialized
INFO - 2018-05-15 05:00:07 --> Input Class Initialized
INFO - 2018-05-15 05:00:07 --> Security Class Initialized
INFO - 2018-05-15 05:00:07 --> Security Class Initialized
INFO - 2018-05-15 05:00:07 --> Language Class Initialized
DEBUG - 2018-05-15 05:00:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-15 05:00:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:00:07 --> Language Class Initialized
INFO - 2018-05-15 05:00:07 --> Input Class Initialized
ERROR - 2018-05-15 05:00:07 --> 404 Page Not Found: /index
ERROR - 2018-05-15 05:00:07 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:00:07 --> Input Class Initialized
INFO - 2018-05-15 05:00:07 --> Language Class Initialized
INFO - 2018-05-15 05:00:07 --> Language Class Initialized
ERROR - 2018-05-15 05:00:07 --> 404 Page Not Found: /index
ERROR - 2018-05-15 05:00:07 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:00:08 --> Config Class Initialized
INFO - 2018-05-15 05:00:08 --> Config Class Initialized
INFO - 2018-05-15 05:00:08 --> Config Class Initialized
INFO - 2018-05-15 05:00:08 --> Config Class Initialized
INFO - 2018-05-15 05:00:08 --> Hooks Class Initialized
DEBUG - 2018-05-15 05:00:08 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:00:08 --> Hooks Class Initialized
INFO - 2018-05-15 05:00:08 --> Hooks Class Initialized
INFO - 2018-05-15 05:00:08 --> Hooks Class Initialized
INFO - 2018-05-15 05:00:08 --> Utf8 Class Initialized
DEBUG - 2018-05-15 05:00:08 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 05:00:08 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:00:08 --> URI Class Initialized
DEBUG - 2018-05-15 05:00:08 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:00:08 --> Utf8 Class Initialized
INFO - 2018-05-15 05:00:08 --> Utf8 Class Initialized
INFO - 2018-05-15 05:00:08 --> Utf8 Class Initialized
INFO - 2018-05-15 05:00:08 --> Router Class Initialized
INFO - 2018-05-15 05:00:08 --> URI Class Initialized
INFO - 2018-05-15 05:00:08 --> URI Class Initialized
INFO - 2018-05-15 05:00:08 --> URI Class Initialized
INFO - 2018-05-15 05:00:08 --> Output Class Initialized
INFO - 2018-05-15 05:00:08 --> Security Class Initialized
INFO - 2018-05-15 05:00:08 --> Router Class Initialized
INFO - 2018-05-15 05:00:08 --> Router Class Initialized
INFO - 2018-05-15 05:00:08 --> Router Class Initialized
DEBUG - 2018-05-15 05:00:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:00:08 --> Output Class Initialized
INFO - 2018-05-15 05:00:08 --> Output Class Initialized
INFO - 2018-05-15 05:00:08 --> Output Class Initialized
INFO - 2018-05-15 05:00:08 --> Input Class Initialized
INFO - 2018-05-15 05:00:08 --> Security Class Initialized
INFO - 2018-05-15 05:00:08 --> Security Class Initialized
INFO - 2018-05-15 05:00:08 --> Security Class Initialized
DEBUG - 2018-05-15 05:00:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-15 05:00:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:00:08 --> Language Class Initialized
DEBUG - 2018-05-15 05:00:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:00:08 --> Input Class Initialized
INFO - 2018-05-15 05:00:08 --> Input Class Initialized
INFO - 2018-05-15 05:00:08 --> Input Class Initialized
ERROR - 2018-05-15 05:00:08 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:00:08 --> Language Class Initialized
INFO - 2018-05-15 05:00:08 --> Language Class Initialized
INFO - 2018-05-15 05:00:08 --> Language Class Initialized
INFO - 2018-05-15 05:00:08 --> Config Class Initialized
INFO - 2018-05-15 05:00:08 --> Hooks Class Initialized
ERROR - 2018-05-15 05:00:08 --> 404 Page Not Found: /index
ERROR - 2018-05-15 05:00:08 --> 404 Page Not Found: /index
ERROR - 2018-05-15 05:00:08 --> 404 Page Not Found: /index
DEBUG - 2018-05-15 05:00:08 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:00:08 --> Config Class Initialized
INFO - 2018-05-15 05:00:08 --> Hooks Class Initialized
INFO - 2018-05-15 05:00:08 --> Utf8 Class Initialized
DEBUG - 2018-05-15 05:00:08 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:00:08 --> URI Class Initialized
INFO - 2018-05-15 05:00:08 --> Utf8 Class Initialized
INFO - 2018-05-15 05:00:08 --> Config Class Initialized
INFO - 2018-05-15 05:00:08 --> Config Class Initialized
INFO - 2018-05-15 05:00:08 --> Hooks Class Initialized
INFO - 2018-05-15 05:00:08 --> Hooks Class Initialized
INFO - 2018-05-15 05:00:08 --> Router Class Initialized
DEBUG - 2018-05-15 05:00:08 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 05:00:08 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:00:08 --> URI Class Initialized
INFO - 2018-05-15 05:00:08 --> Output Class Initialized
INFO - 2018-05-15 05:00:08 --> Utf8 Class Initialized
INFO - 2018-05-15 05:00:08 --> Utf8 Class Initialized
INFO - 2018-05-15 05:00:08 --> Router Class Initialized
INFO - 2018-05-15 05:00:08 --> Security Class Initialized
INFO - 2018-05-15 05:00:08 --> URI Class Initialized
INFO - 2018-05-15 05:00:08 --> Output Class Initialized
INFO - 2018-05-15 05:00:08 --> Router Class Initialized
DEBUG - 2018-05-15 05:00:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:00:08 --> URI Class Initialized
INFO - 2018-05-15 05:00:08 --> Security Class Initialized
INFO - 2018-05-15 05:00:08 --> Output Class Initialized
DEBUG - 2018-05-15 05:00:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:00:08 --> Security Class Initialized
INFO - 2018-05-15 05:00:08 --> Input Class Initialized
INFO - 2018-05-15 05:00:08 --> Router Class Initialized
INFO - 2018-05-15 05:00:08 --> Input Class Initialized
DEBUG - 2018-05-15 05:00:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:00:08 --> Language Class Initialized
INFO - 2018-05-15 05:00:08 --> Output Class Initialized
INFO - 2018-05-15 05:00:08 --> Input Class Initialized
INFO - 2018-05-15 05:00:08 --> Language Class Initialized
INFO - 2018-05-15 05:00:08 --> Security Class Initialized
ERROR - 2018-05-15 05:00:08 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:00:08 --> Language Class Initialized
DEBUG - 2018-05-15 05:00:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-05-15 05:00:08 --> 404 Page Not Found: /index
ERROR - 2018-05-15 05:00:08 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:00:08 --> Input Class Initialized
INFO - 2018-05-15 05:00:08 --> Language Class Initialized
ERROR - 2018-05-15 05:00:08 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:00:12 --> Config Class Initialized
INFO - 2018-05-15 05:00:12 --> Hooks Class Initialized
DEBUG - 2018-05-15 05:00:12 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:00:12 --> Utf8 Class Initialized
INFO - 2018-05-15 05:00:12 --> URI Class Initialized
INFO - 2018-05-15 05:00:12 --> Router Class Initialized
INFO - 2018-05-15 05:00:12 --> Config Class Initialized
INFO - 2018-05-15 05:00:12 --> Config Class Initialized
INFO - 2018-05-15 05:00:12 --> Config Class Initialized
INFO - 2018-05-15 05:00:12 --> Config Class Initialized
INFO - 2018-05-15 05:00:12 --> Config Class Initialized
INFO - 2018-05-15 05:00:12 --> Hooks Class Initialized
INFO - 2018-05-15 05:00:12 --> Hooks Class Initialized
INFO - 2018-05-15 05:00:12 --> Hooks Class Initialized
INFO - 2018-05-15 05:00:12 --> Hooks Class Initialized
INFO - 2018-05-15 05:00:12 --> Output Class Initialized
INFO - 2018-05-15 05:00:12 --> Hooks Class Initialized
DEBUG - 2018-05-15 05:00:12 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 05:00:12 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 05:00:12 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 05:00:12 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:00:12 --> Security Class Initialized
DEBUG - 2018-05-15 05:00:12 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:00:12 --> Utf8 Class Initialized
INFO - 2018-05-15 05:00:12 --> Utf8 Class Initialized
INFO - 2018-05-15 05:00:12 --> Utf8 Class Initialized
INFO - 2018-05-15 05:00:12 --> Utf8 Class Initialized
DEBUG - 2018-05-15 05:00:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:00:12 --> Utf8 Class Initialized
INFO - 2018-05-15 05:00:12 --> URI Class Initialized
INFO - 2018-05-15 05:00:12 --> URI Class Initialized
INFO - 2018-05-15 05:00:12 --> Router Class Initialized
INFO - 2018-05-15 05:00:12 --> Output Class Initialized
INFO - 2018-05-15 05:00:12 --> Router Class Initialized
INFO - 2018-05-15 05:00:12 --> URI Class Initialized
INFO - 2018-05-15 05:00:12 --> Input Class Initialized
INFO - 2018-05-15 05:00:12 --> URI Class Initialized
INFO - 2018-05-15 05:00:12 --> URI Class Initialized
INFO - 2018-05-15 05:00:12 --> Security Class Initialized
INFO - 2018-05-15 05:00:12 --> Output Class Initialized
DEBUG - 2018-05-15 05:00:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:00:12 --> Router Class Initialized
INFO - 2018-05-15 05:00:12 --> Router Class Initialized
INFO - 2018-05-15 05:00:12 --> Language Class Initialized
INFO - 2018-05-15 05:00:12 --> Security Class Initialized
INFO - 2018-05-15 05:00:12 --> Router Class Initialized
INFO - 2018-05-15 05:00:12 --> Input Class Initialized
INFO - 2018-05-15 05:00:12 --> Language Class Initialized
DEBUG - 2018-05-15 05:00:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:00:13 --> Output Class Initialized
ERROR - 2018-05-15 05:00:13 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:00:13 --> Output Class Initialized
INFO - 2018-05-15 05:00:13 --> Output Class Initialized
ERROR - 2018-05-15 05:00:13 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:00:13 --> Input Class Initialized
INFO - 2018-05-15 05:00:13 --> Language Class Initialized
INFO - 2018-05-15 05:00:13 --> Security Class Initialized
INFO - 2018-05-15 05:00:13 --> Security Class Initialized
INFO - 2018-05-15 05:00:13 --> Security Class Initialized
DEBUG - 2018-05-15 05:00:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-15 05:00:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-15 05:00:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-05-15 05:00:13 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:00:13 --> Input Class Initialized
INFO - 2018-05-15 05:00:13 --> Config Class Initialized
INFO - 2018-05-15 05:00:13 --> Hooks Class Initialized
INFO - 2018-05-15 05:00:13 --> Language Class Initialized
INFO - 2018-05-15 05:00:13 --> Config Class Initialized
INFO - 2018-05-15 05:00:13 --> Input Class Initialized
INFO - 2018-05-15 05:00:13 --> Input Class Initialized
DEBUG - 2018-05-15 05:00:13 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:00:13 --> Hooks Class Initialized
INFO - 2018-05-15 05:00:13 --> Language Class Initialized
INFO - 2018-05-15 05:00:13 --> Language Class Initialized
ERROR - 2018-05-15 05:00:13 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:00:13 --> Utf8 Class Initialized
ERROR - 2018-05-15 05:00:13 --> 404 Page Not Found: /index
DEBUG - 2018-05-15 05:00:13 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:00:13 --> Config Class Initialized
ERROR - 2018-05-15 05:00:13 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:00:13 --> URI Class Initialized
INFO - 2018-05-15 05:00:13 --> Hooks Class Initialized
INFO - 2018-05-15 05:00:13 --> Utf8 Class Initialized
INFO - 2018-05-15 05:00:13 --> Config Class Initialized
INFO - 2018-05-15 05:00:13 --> Router Class Initialized
INFO - 2018-05-15 05:00:13 --> Hooks Class Initialized
DEBUG - 2018-05-15 05:00:13 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:00:13 --> URI Class Initialized
INFO - 2018-05-15 05:00:13 --> Output Class Initialized
DEBUG - 2018-05-15 05:00:13 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:00:13 --> Utf8 Class Initialized
INFO - 2018-05-15 05:00:13 --> Router Class Initialized
INFO - 2018-05-15 05:00:13 --> Security Class Initialized
INFO - 2018-05-15 05:00:13 --> Utf8 Class Initialized
INFO - 2018-05-15 05:00:13 --> URI Class Initialized
INFO - 2018-05-15 05:00:13 --> Output Class Initialized
DEBUG - 2018-05-15 05:00:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:00:13 --> URI Class Initialized
INFO - 2018-05-15 05:00:13 --> Input Class Initialized
INFO - 2018-05-15 05:00:13 --> Security Class Initialized
INFO - 2018-05-15 05:00:13 --> Router Class Initialized
INFO - 2018-05-15 05:00:13 --> Router Class Initialized
INFO - 2018-05-15 05:00:13 --> Output Class Initialized
DEBUG - 2018-05-15 05:00:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:00:13 --> Language Class Initialized
INFO - 2018-05-15 05:00:13 --> Input Class Initialized
ERROR - 2018-05-15 05:00:13 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:00:13 --> Output Class Initialized
INFO - 2018-05-15 05:00:13 --> Security Class Initialized
INFO - 2018-05-15 05:00:13 --> Security Class Initialized
INFO - 2018-05-15 05:00:13 --> Language Class Initialized
DEBUG - 2018-05-15 05:00:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:00:13 --> Config Class Initialized
INFO - 2018-05-15 05:00:13 --> Hooks Class Initialized
INFO - 2018-05-15 05:00:13 --> Input Class Initialized
DEBUG - 2018-05-15 05:00:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-05-15 05:00:13 --> 404 Page Not Found: /index
DEBUG - 2018-05-15 05:00:13 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:00:13 --> Config Class Initialized
INFO - 2018-05-15 05:00:13 --> Hooks Class Initialized
INFO - 2018-05-15 05:00:13 --> Utf8 Class Initialized
INFO - 2018-05-15 05:00:13 --> Language Class Initialized
INFO - 2018-05-15 05:00:13 --> Input Class Initialized
DEBUG - 2018-05-15 05:00:13 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:00:13 --> Utf8 Class Initialized
INFO - 2018-05-15 05:00:13 --> URI Class Initialized
INFO - 2018-05-15 05:00:13 --> Router Class Initialized
INFO - 2018-05-15 05:00:13 --> Language Class Initialized
INFO - 2018-05-15 05:00:13 --> URI Class Initialized
ERROR - 2018-05-15 05:00:13 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:00:13 --> Router Class Initialized
INFO - 2018-05-15 05:00:13 --> Config Class Initialized
INFO - 2018-05-15 05:00:13 --> Output Class Initialized
ERROR - 2018-05-15 05:00:13 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:00:13 --> Hooks Class Initialized
INFO - 2018-05-15 05:00:13 --> Security Class Initialized
INFO - 2018-05-15 05:00:13 --> Output Class Initialized
INFO - 2018-05-15 05:00:13 --> Config Class Initialized
INFO - 2018-05-15 05:00:13 --> Hooks Class Initialized
DEBUG - 2018-05-15 05:00:13 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:00:13 --> Security Class Initialized
INFO - 2018-05-15 05:00:13 --> Utf8 Class Initialized
DEBUG - 2018-05-15 05:00:13 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 05:00:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:00:13 --> Utf8 Class Initialized
INFO - 2018-05-15 05:00:13 --> Input Class Initialized
INFO - 2018-05-15 05:00:13 --> URI Class Initialized
DEBUG - 2018-05-15 05:00:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:00:13 --> Language Class Initialized
INFO - 2018-05-15 05:00:13 --> URI Class Initialized
INFO - 2018-05-15 05:00:13 --> Input Class Initialized
INFO - 2018-05-15 05:00:13 --> Router Class Initialized
INFO - 2018-05-15 05:00:13 --> Router Class Initialized
INFO - 2018-05-15 05:00:13 --> Output Class Initialized
ERROR - 2018-05-15 05:00:13 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:00:13 --> Language Class Initialized
ERROR - 2018-05-15 05:00:13 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:00:13 --> Output Class Initialized
INFO - 2018-05-15 05:00:13 --> Security Class Initialized
DEBUG - 2018-05-15 05:00:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:00:13 --> Security Class Initialized
INFO - 2018-05-15 05:00:13 --> Input Class Initialized
DEBUG - 2018-05-15 05:00:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:00:13 --> Input Class Initialized
INFO - 2018-05-15 05:00:13 --> Language Class Initialized
INFO - 2018-05-15 05:00:13 --> Language Class Initialized
ERROR - 2018-05-15 05:00:13 --> 404 Page Not Found: /index
ERROR - 2018-05-15 05:00:13 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:00:15 --> Config Class Initialized
INFO - 2018-05-15 05:00:15 --> Hooks Class Initialized
DEBUG - 2018-05-15 05:00:15 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:00:16 --> Utf8 Class Initialized
INFO - 2018-05-15 05:00:16 --> Config Class Initialized
INFO - 2018-05-15 05:00:16 --> URI Class Initialized
INFO - 2018-05-15 05:00:16 --> Hooks Class Initialized
DEBUG - 2018-05-15 05:00:16 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:00:16 --> Utf8 Class Initialized
INFO - 2018-05-15 05:00:16 --> URI Class Initialized
INFO - 2018-05-15 05:00:16 --> Router Class Initialized
INFO - 2018-05-15 05:00:16 --> Output Class Initialized
INFO - 2018-05-15 05:00:16 --> Security Class Initialized
DEBUG - 2018-05-15 05:00:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:00:16 --> Input Class Initialized
INFO - 2018-05-15 05:00:16 --> Config Class Initialized
INFO - 2018-05-15 05:00:16 --> Config Class Initialized
INFO - 2018-05-15 05:00:16 --> Config Class Initialized
INFO - 2018-05-15 05:00:16 --> Config Class Initialized
INFO - 2018-05-15 05:00:16 --> Language Class Initialized
INFO - 2018-05-15 05:00:16 --> Router Class Initialized
INFO - 2018-05-15 05:00:16 --> Hooks Class Initialized
INFO - 2018-05-15 05:00:16 --> Hooks Class Initialized
INFO - 2018-05-15 05:00:16 --> Hooks Class Initialized
INFO - 2018-05-15 05:00:16 --> Hooks Class Initialized
ERROR - 2018-05-15 05:00:16 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:00:16 --> Output Class Initialized
DEBUG - 2018-05-15 05:00:16 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 05:00:16 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 05:00:16 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:00:16 --> Security Class Initialized
DEBUG - 2018-05-15 05:00:16 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:00:16 --> Utf8 Class Initialized
INFO - 2018-05-15 05:00:16 --> Config Class Initialized
INFO - 2018-05-15 05:00:16 --> Utf8 Class Initialized
INFO - 2018-05-15 05:00:16 --> Utf8 Class Initialized
INFO - 2018-05-15 05:00:16 --> URI Class Initialized
INFO - 2018-05-15 05:00:16 --> Utf8 Class Initialized
DEBUG - 2018-05-15 05:00:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:00:16 --> Hooks Class Initialized
INFO - 2018-05-15 05:00:16 --> URI Class Initialized
INFO - 2018-05-15 05:00:16 --> Router Class Initialized
INFO - 2018-05-15 05:00:16 --> URI Class Initialized
INFO - 2018-05-15 05:00:16 --> Input Class Initialized
INFO - 2018-05-15 05:00:16 --> URI Class Initialized
INFO - 2018-05-15 05:00:16 --> Output Class Initialized
INFO - 2018-05-15 05:00:16 --> Router Class Initialized
INFO - 2018-05-15 05:00:16 --> Router Class Initialized
INFO - 2018-05-15 05:00:16 --> Language Class Initialized
INFO - 2018-05-15 05:00:16 --> Router Class Initialized
DEBUG - 2018-05-15 05:00:16 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:00:16 --> Security Class Initialized
INFO - 2018-05-15 05:00:16 --> Output Class Initialized
INFO - 2018-05-15 05:00:16 --> Output Class Initialized
ERROR - 2018-05-15 05:00:16 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:00:16 --> Output Class Initialized
INFO - 2018-05-15 05:00:16 --> Utf8 Class Initialized
INFO - 2018-05-15 05:00:16 --> Security Class Initialized
DEBUG - 2018-05-15 05:00:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:00:16 --> Input Class Initialized
DEBUG - 2018-05-15 05:00:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:00:16 --> URI Class Initialized
INFO - 2018-05-15 05:00:16 --> Security Class Initialized
INFO - 2018-05-15 05:00:16 --> Security Class Initialized
INFO - 2018-05-15 05:00:16 --> Language Class Initialized
ERROR - 2018-05-15 05:00:16 --> 404 Page Not Found: /index
DEBUG - 2018-05-15 05:00:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-15 05:00:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:00:16 --> Router Class Initialized
INFO - 2018-05-15 05:00:16 --> Input Class Initialized
INFO - 2018-05-15 05:00:16 --> Config Class Initialized
INFO - 2018-05-15 05:00:16 --> Hooks Class Initialized
INFO - 2018-05-15 05:00:16 --> Input Class Initialized
INFO - 2018-05-15 05:00:16 --> Language Class Initialized
INFO - 2018-05-15 05:00:16 --> Output Class Initialized
INFO - 2018-05-15 05:00:16 --> Input Class Initialized
INFO - 2018-05-15 05:00:16 --> Language Class Initialized
DEBUG - 2018-05-15 05:00:16 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:00:16 --> Language Class Initialized
INFO - 2018-05-15 05:00:16 --> Security Class Initialized
ERROR - 2018-05-15 05:00:16 --> 404 Page Not Found: /index
ERROR - 2018-05-15 05:00:16 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:00:16 --> Utf8 Class Initialized
INFO - 2018-05-15 05:00:16 --> URI Class Initialized
DEBUG - 2018-05-15 05:00:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:00:16 --> Config Class Initialized
ERROR - 2018-05-15 05:00:16 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:00:16 --> Router Class Initialized
INFO - 2018-05-15 05:00:16 --> Hooks Class Initialized
INFO - 2018-05-15 05:00:16 --> Input Class Initialized
INFO - 2018-05-15 05:00:16 --> Output Class Initialized
INFO - 2018-05-15 05:00:16 --> Config Class Initialized
INFO - 2018-05-15 05:00:16 --> Hooks Class Initialized
DEBUG - 2018-05-15 05:00:16 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:00:16 --> Utf8 Class Initialized
DEBUG - 2018-05-15 05:00:16 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:00:16 --> Security Class Initialized
INFO - 2018-05-15 05:00:16 --> Language Class Initialized
INFO - 2018-05-15 05:00:16 --> Utf8 Class Initialized
INFO - 2018-05-15 05:00:16 --> URI Class Initialized
DEBUG - 2018-05-15 05:00:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-05-15 05:00:16 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:00:16 --> URI Class Initialized
INFO - 2018-05-15 05:00:16 --> Input Class Initialized
INFO - 2018-05-15 05:00:16 --> Router Class Initialized
INFO - 2018-05-15 05:00:17 --> Config Class Initialized
INFO - 2018-05-15 05:00:17 --> Hooks Class Initialized
INFO - 2018-05-15 05:00:17 --> Language Class Initialized
INFO - 2018-05-15 05:00:17 --> Router Class Initialized
INFO - 2018-05-15 05:00:17 --> Output Class Initialized
DEBUG - 2018-05-15 05:00:17 --> UTF-8 Support Enabled
ERROR - 2018-05-15 05:00:17 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:00:17 --> Output Class Initialized
INFO - 2018-05-15 05:00:17 --> Security Class Initialized
INFO - 2018-05-15 05:00:17 --> Utf8 Class Initialized
INFO - 2018-05-15 05:00:17 --> URI Class Initialized
INFO - 2018-05-15 05:00:17 --> Config Class Initialized
INFO - 2018-05-15 05:00:17 --> Hooks Class Initialized
INFO - 2018-05-15 05:00:17 --> Security Class Initialized
DEBUG - 2018-05-15 05:00:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:00:17 --> Router Class Initialized
INFO - 2018-05-15 05:00:17 --> Input Class Initialized
DEBUG - 2018-05-15 05:00:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-15 05:00:17 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:00:17 --> Output Class Initialized
INFO - 2018-05-15 05:00:17 --> Utf8 Class Initialized
INFO - 2018-05-15 05:00:17 --> Input Class Initialized
INFO - 2018-05-15 05:00:17 --> Security Class Initialized
INFO - 2018-05-15 05:00:17 --> Language Class Initialized
INFO - 2018-05-15 05:00:17 --> URI Class Initialized
DEBUG - 2018-05-15 05:00:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-05-15 05:00:17 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:00:17 --> Language Class Initialized
INFO - 2018-05-15 05:00:17 --> Input Class Initialized
INFO - 2018-05-15 05:00:17 --> Router Class Initialized
INFO - 2018-05-15 05:00:17 --> Config Class Initialized
ERROR - 2018-05-15 05:00:17 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:00:17 --> Hooks Class Initialized
INFO - 2018-05-15 05:00:17 --> Output Class Initialized
INFO - 2018-05-15 05:00:17 --> Config Class Initialized
INFO - 2018-05-15 05:00:17 --> Language Class Initialized
INFO - 2018-05-15 05:00:17 --> Hooks Class Initialized
INFO - 2018-05-15 05:00:17 --> Security Class Initialized
DEBUG - 2018-05-15 05:00:17 --> UTF-8 Support Enabled
ERROR - 2018-05-15 05:00:17 --> 404 Page Not Found: /index
DEBUG - 2018-05-15 05:00:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:00:17 --> Utf8 Class Initialized
DEBUG - 2018-05-15 05:00:17 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:00:17 --> Config Class Initialized
INFO - 2018-05-15 05:00:17 --> Hooks Class Initialized
INFO - 2018-05-15 05:00:17 --> Input Class Initialized
INFO - 2018-05-15 05:00:17 --> Utf8 Class Initialized
DEBUG - 2018-05-15 05:00:17 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:00:17 --> URI Class Initialized
INFO - 2018-05-15 05:00:17 --> Language Class Initialized
INFO - 2018-05-15 05:00:17 --> Utf8 Class Initialized
ERROR - 2018-05-15 05:00:17 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:00:17 --> URI Class Initialized
INFO - 2018-05-15 05:00:17 --> Router Class Initialized
INFO - 2018-05-15 05:00:17 --> Router Class Initialized
INFO - 2018-05-15 05:00:17 --> Output Class Initialized
INFO - 2018-05-15 05:00:17 --> Output Class Initialized
INFO - 2018-05-15 05:00:17 --> URI Class Initialized
INFO - 2018-05-15 05:00:17 --> Security Class Initialized
INFO - 2018-05-15 05:00:17 --> Security Class Initialized
DEBUG - 2018-05-15 05:00:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-15 05:00:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:00:17 --> Input Class Initialized
INFO - 2018-05-15 05:00:17 --> Router Class Initialized
INFO - 2018-05-15 05:00:17 --> Input Class Initialized
INFO - 2018-05-15 05:00:17 --> Output Class Initialized
INFO - 2018-05-15 05:00:17 --> Language Class Initialized
INFO - 2018-05-15 05:00:17 --> Language Class Initialized
ERROR - 2018-05-15 05:00:17 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:00:17 --> Security Class Initialized
ERROR - 2018-05-15 05:00:17 --> 404 Page Not Found: /index
DEBUG - 2018-05-15 05:00:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:00:17 --> Input Class Initialized
INFO - 2018-05-15 05:00:17 --> Language Class Initialized
ERROR - 2018-05-15 05:00:17 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:00:21 --> Config Class Initialized
INFO - 2018-05-15 05:00:21 --> Hooks Class Initialized
DEBUG - 2018-05-15 05:00:21 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:00:21 --> Utf8 Class Initialized
INFO - 2018-05-15 05:00:21 --> URI Class Initialized
INFO - 2018-05-15 05:00:21 --> Config Class Initialized
INFO - 2018-05-15 05:00:21 --> Hooks Class Initialized
INFO - 2018-05-15 05:00:21 --> Router Class Initialized
DEBUG - 2018-05-15 05:00:21 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:00:21 --> Utf8 Class Initialized
INFO - 2018-05-15 05:00:21 --> URI Class Initialized
INFO - 2018-05-15 05:00:21 --> Router Class Initialized
INFO - 2018-05-15 05:00:21 --> Output Class Initialized
INFO - 2018-05-15 05:00:21 --> Security Class Initialized
DEBUG - 2018-05-15 05:00:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:00:21 --> Input Class Initialized
INFO - 2018-05-15 05:00:21 --> Language Class Initialized
ERROR - 2018-05-15 05:00:21 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:00:21 --> Output Class Initialized
INFO - 2018-05-15 05:00:21 --> Security Class Initialized
INFO - 2018-05-15 05:00:21 --> Config Class Initialized
INFO - 2018-05-15 05:00:21 --> Config Class Initialized
INFO - 2018-05-15 05:00:21 --> Config Class Initialized
INFO - 2018-05-15 05:00:21 --> Config Class Initialized
INFO - 2018-05-15 05:00:21 --> Config Class Initialized
INFO - 2018-05-15 05:00:21 --> Hooks Class Initialized
INFO - 2018-05-15 05:00:21 --> Hooks Class Initialized
INFO - 2018-05-15 05:00:21 --> Hooks Class Initialized
INFO - 2018-05-15 05:00:21 --> Hooks Class Initialized
INFO - 2018-05-15 05:00:21 --> Hooks Class Initialized
DEBUG - 2018-05-15 05:00:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-15 05:00:21 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:00:21 --> Utf8 Class Initialized
DEBUG - 2018-05-15 05:00:21 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 05:00:21 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 05:00:21 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:00:21 --> Input Class Initialized
DEBUG - 2018-05-15 05:00:21 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:00:21 --> Utf8 Class Initialized
INFO - 2018-05-15 05:00:21 --> Utf8 Class Initialized
INFO - 2018-05-15 05:00:21 --> Utf8 Class Initialized
INFO - 2018-05-15 05:00:21 --> Language Class Initialized
INFO - 2018-05-15 05:00:21 --> Utf8 Class Initialized
INFO - 2018-05-15 05:00:21 --> URI Class Initialized
INFO - 2018-05-15 05:00:21 --> URI Class Initialized
INFO - 2018-05-15 05:00:21 --> Router Class Initialized
INFO - 2018-05-15 05:00:21 --> URI Class Initialized
ERROR - 2018-05-15 05:00:21 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:00:21 --> URI Class Initialized
INFO - 2018-05-15 05:00:21 --> Router Class Initialized
INFO - 2018-05-15 05:00:21 --> Output Class Initialized
INFO - 2018-05-15 05:00:21 --> Router Class Initialized
INFO - 2018-05-15 05:00:21 --> Output Class Initialized
INFO - 2018-05-15 05:00:21 --> Security Class Initialized
INFO - 2018-05-15 05:00:21 --> Output Class Initialized
INFO - 2018-05-15 05:00:21 --> URI Class Initialized
INFO - 2018-05-15 05:00:21 --> Router Class Initialized
INFO - 2018-05-15 05:00:21 --> Security Class Initialized
DEBUG - 2018-05-15 05:00:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:00:21 --> Security Class Initialized
INFO - 2018-05-15 05:00:21 --> Output Class Initialized
INFO - 2018-05-15 05:00:21 --> Router Class Initialized
DEBUG - 2018-05-15 05:00:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:00:21 --> Input Class Initialized
INFO - 2018-05-15 05:00:21 --> Language Class Initialized
DEBUG - 2018-05-15 05:00:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:00:21 --> Security Class Initialized
INFO - 2018-05-15 05:00:21 --> Input Class Initialized
INFO - 2018-05-15 05:00:21 --> Output Class Initialized
DEBUG - 2018-05-15 05:00:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-05-15 05:00:21 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:00:21 --> Language Class Initialized
INFO - 2018-05-15 05:00:21 --> Input Class Initialized
INFO - 2018-05-15 05:00:21 --> Security Class Initialized
ERROR - 2018-05-15 05:00:21 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:00:21 --> Config Class Initialized
INFO - 2018-05-15 05:00:21 --> Language Class Initialized
INFO - 2018-05-15 05:00:21 --> Input Class Initialized
DEBUG - 2018-05-15 05:00:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:00:21 --> Hooks Class Initialized
INFO - 2018-05-15 05:00:21 --> Input Class Initialized
ERROR - 2018-05-15 05:00:21 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:00:21 --> Language Class Initialized
INFO - 2018-05-15 05:00:21 --> Config Class Initialized
INFO - 2018-05-15 05:00:22 --> Hooks Class Initialized
INFO - 2018-05-15 05:00:22 --> Language Class Initialized
DEBUG - 2018-05-15 05:00:22 --> UTF-8 Support Enabled
ERROR - 2018-05-15 05:00:22 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:00:22 --> Config Class Initialized
INFO - 2018-05-15 05:00:22 --> Hooks Class Initialized
DEBUG - 2018-05-15 05:00:22 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 05:00:22 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:00:22 --> Utf8 Class Initialized
INFO - 2018-05-15 05:00:22 --> Utf8 Class Initialized
INFO - 2018-05-15 05:00:22 --> URI Class Initialized
ERROR - 2018-05-15 05:00:22 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:00:22 --> Utf8 Class Initialized
INFO - 2018-05-15 05:00:22 --> URI Class Initialized
INFO - 2018-05-15 05:00:22 --> Router Class Initialized
INFO - 2018-05-15 05:00:22 --> URI Class Initialized
INFO - 2018-05-15 05:00:22 --> Output Class Initialized
INFO - 2018-05-15 05:00:22 --> Router Class Initialized
INFO - 2018-05-15 05:00:22 --> Router Class Initialized
INFO - 2018-05-15 05:00:22 --> Config Class Initialized
INFO - 2018-05-15 05:00:22 --> Hooks Class Initialized
INFO - 2018-05-15 05:00:22 --> Output Class Initialized
INFO - 2018-05-15 05:00:22 --> Security Class Initialized
INFO - 2018-05-15 05:00:22 --> Output Class Initialized
INFO - 2018-05-15 05:00:22 --> Security Class Initialized
DEBUG - 2018-05-15 05:00:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-15 05:00:22 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:00:22 --> Security Class Initialized
INFO - 2018-05-15 05:00:22 --> Utf8 Class Initialized
INFO - 2018-05-15 05:00:22 --> Input Class Initialized
DEBUG - 2018-05-15 05:00:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-15 05:00:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:00:22 --> Input Class Initialized
INFO - 2018-05-15 05:00:22 --> Input Class Initialized
INFO - 2018-05-15 05:00:22 --> Language Class Initialized
INFO - 2018-05-15 05:00:22 --> URI Class Initialized
INFO - 2018-05-15 05:00:22 --> Language Class Initialized
INFO - 2018-05-15 05:00:22 --> Language Class Initialized
ERROR - 2018-05-15 05:00:22 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:00:22 --> Router Class Initialized
INFO - 2018-05-15 05:00:22 --> Output Class Initialized
ERROR - 2018-05-15 05:00:22 --> 404 Page Not Found: /index
ERROR - 2018-05-15 05:00:22 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:00:22 --> Config Class Initialized
INFO - 2018-05-15 05:00:22 --> Hooks Class Initialized
DEBUG - 2018-05-15 05:00:22 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:00:22 --> Config Class Initialized
INFO - 2018-05-15 05:00:22 --> Security Class Initialized
INFO - 2018-05-15 05:00:22 --> Hooks Class Initialized
INFO - 2018-05-15 05:00:22 --> Utf8 Class Initialized
INFO - 2018-05-15 05:00:22 --> Config Class Initialized
DEBUG - 2018-05-15 05:00:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:00:22 --> Hooks Class Initialized
DEBUG - 2018-05-15 05:00:22 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:00:22 --> Input Class Initialized
INFO - 2018-05-15 05:00:22 --> URI Class Initialized
INFO - 2018-05-15 05:00:22 --> Utf8 Class Initialized
DEBUG - 2018-05-15 05:00:22 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:00:22 --> Router Class Initialized
INFO - 2018-05-15 05:00:22 --> Language Class Initialized
INFO - 2018-05-15 05:00:22 --> Utf8 Class Initialized
INFO - 2018-05-15 05:00:22 --> Output Class Initialized
INFO - 2018-05-15 05:00:22 --> URI Class Initialized
INFO - 2018-05-15 05:00:22 --> URI Class Initialized
ERROR - 2018-05-15 05:00:22 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:00:22 --> Security Class Initialized
INFO - 2018-05-15 05:00:22 --> Router Class Initialized
INFO - 2018-05-15 05:00:22 --> Router Class Initialized
INFO - 2018-05-15 05:00:22 --> Config Class Initialized
INFO - 2018-05-15 05:00:22 --> Hooks Class Initialized
DEBUG - 2018-05-15 05:00:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:00:22 --> Output Class Initialized
INFO - 2018-05-15 05:00:22 --> Output Class Initialized
INFO - 2018-05-15 05:00:22 --> Input Class Initialized
INFO - 2018-05-15 05:00:22 --> Security Class Initialized
DEBUG - 2018-05-15 05:00:22 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:00:22 --> Security Class Initialized
DEBUG - 2018-05-15 05:00:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-15 05:00:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:00:22 --> Utf8 Class Initialized
INFO - 2018-05-15 05:00:22 --> Language Class Initialized
INFO - 2018-05-15 05:00:22 --> Input Class Initialized
INFO - 2018-05-15 05:00:22 --> Input Class Initialized
ERROR - 2018-05-15 05:00:22 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:00:22 --> URI Class Initialized
INFO - 2018-05-15 05:00:22 --> Language Class Initialized
INFO - 2018-05-15 05:00:22 --> Language Class Initialized
INFO - 2018-05-15 05:00:22 --> Router Class Initialized
INFO - 2018-05-15 05:00:22 --> Output Class Initialized
ERROR - 2018-05-15 05:00:22 --> 404 Page Not Found: /index
ERROR - 2018-05-15 05:00:22 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:00:22 --> Security Class Initialized
DEBUG - 2018-05-15 05:00:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:00:22 --> Input Class Initialized
INFO - 2018-05-15 05:00:22 --> Language Class Initialized
ERROR - 2018-05-15 05:00:22 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:00:25 --> Config Class Initialized
INFO - 2018-05-15 05:00:25 --> Hooks Class Initialized
DEBUG - 2018-05-15 05:00:25 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:00:25 --> Config Class Initialized
INFO - 2018-05-15 05:00:25 --> Hooks Class Initialized
INFO - 2018-05-15 05:00:25 --> Utf8 Class Initialized
DEBUG - 2018-05-15 05:00:25 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:00:25 --> Utf8 Class Initialized
INFO - 2018-05-15 05:00:25 --> URI Class Initialized
INFO - 2018-05-15 05:00:25 --> URI Class Initialized
INFO - 2018-05-15 05:00:25 --> Config Class Initialized
INFO - 2018-05-15 05:00:25 --> Config Class Initialized
INFO - 2018-05-15 05:00:25 --> Config Class Initialized
INFO - 2018-05-15 05:00:25 --> Config Class Initialized
INFO - 2018-05-15 05:00:25 --> Hooks Class Initialized
INFO - 2018-05-15 05:00:25 --> Hooks Class Initialized
INFO - 2018-05-15 05:00:25 --> Hooks Class Initialized
INFO - 2018-05-15 05:00:25 --> Hooks Class Initialized
INFO - 2018-05-15 05:00:25 --> Router Class Initialized
INFO - 2018-05-15 05:00:25 --> Router Class Initialized
DEBUG - 2018-05-15 05:00:25 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:00:25 --> Output Class Initialized
INFO - 2018-05-15 05:00:25 --> Output Class Initialized
DEBUG - 2018-05-15 05:00:25 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 05:00:25 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 05:00:25 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:00:25 --> Utf8 Class Initialized
INFO - 2018-05-15 05:00:25 --> Utf8 Class Initialized
INFO - 2018-05-15 05:00:25 --> Security Class Initialized
INFO - 2018-05-15 05:00:25 --> Security Class Initialized
INFO - 2018-05-15 05:00:25 --> Utf8 Class Initialized
INFO - 2018-05-15 05:00:25 --> Utf8 Class Initialized
INFO - 2018-05-15 05:00:25 --> URI Class Initialized
INFO - 2018-05-15 05:00:25 --> URI Class Initialized
INFO - 2018-05-15 05:00:25 --> URI Class Initialized
DEBUG - 2018-05-15 05:00:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-15 05:00:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:00:25 --> URI Class Initialized
INFO - 2018-05-15 05:00:25 --> Router Class Initialized
INFO - 2018-05-15 05:00:25 --> Router Class Initialized
INFO - 2018-05-15 05:00:25 --> Output Class Initialized
INFO - 2018-05-15 05:00:25 --> Router Class Initialized
INFO - 2018-05-15 05:00:25 --> Input Class Initialized
INFO - 2018-05-15 05:00:25 --> Input Class Initialized
INFO - 2018-05-15 05:00:25 --> Output Class Initialized
INFO - 2018-05-15 05:00:25 --> Language Class Initialized
INFO - 2018-05-15 05:00:25 --> Router Class Initialized
INFO - 2018-05-15 05:00:25 --> Security Class Initialized
ERROR - 2018-05-15 05:00:25 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:00:25 --> Output Class Initialized
INFO - 2018-05-15 05:00:25 --> Security Class Initialized
INFO - 2018-05-15 05:00:25 --> Language Class Initialized
INFO - 2018-05-15 05:00:25 --> Output Class Initialized
DEBUG - 2018-05-15 05:00:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:00:25 --> Security Class Initialized
DEBUG - 2018-05-15 05:00:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-05-15 05:00:25 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:00:25 --> Security Class Initialized
INFO - 2018-05-15 05:00:25 --> Input Class Initialized
INFO - 2018-05-15 05:00:25 --> Config Class Initialized
INFO - 2018-05-15 05:00:25 --> Input Class Initialized
DEBUG - 2018-05-15 05:00:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:00:25 --> Language Class Initialized
INFO - 2018-05-15 05:00:25 --> Hooks Class Initialized
DEBUG - 2018-05-15 05:00:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:00:25 --> Input Class Initialized
ERROR - 2018-05-15 05:00:25 --> 404 Page Not Found: /index
DEBUG - 2018-05-15 05:00:25 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:00:25 --> Input Class Initialized
INFO - 2018-05-15 05:00:25 --> Language Class Initialized
INFO - 2018-05-15 05:00:25 --> Utf8 Class Initialized
ERROR - 2018-05-15 05:00:25 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:00:25 --> Language Class Initialized
INFO - 2018-05-15 05:00:25 --> Language Class Initialized
INFO - 2018-05-15 05:00:25 --> Config Class Initialized
INFO - 2018-05-15 05:00:25 --> Hooks Class Initialized
INFO - 2018-05-15 05:00:25 --> URI Class Initialized
DEBUG - 2018-05-15 05:00:25 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:00:25 --> Router Class Initialized
ERROR - 2018-05-15 05:00:25 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:00:25 --> Config Class Initialized
INFO - 2018-05-15 05:00:25 --> Utf8 Class Initialized
ERROR - 2018-05-15 05:00:25 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:00:25 --> Hooks Class Initialized
INFO - 2018-05-15 05:00:25 --> Output Class Initialized
INFO - 2018-05-15 05:00:25 --> URI Class Initialized
DEBUG - 2018-05-15 05:00:25 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:00:25 --> Security Class Initialized
INFO - 2018-05-15 05:00:25 --> Config Class Initialized
INFO - 2018-05-15 05:00:25 --> Hooks Class Initialized
INFO - 2018-05-15 05:00:25 --> Router Class Initialized
DEBUG - 2018-05-15 05:00:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-15 05:00:26 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:00:26 --> Utf8 Class Initialized
INFO - 2018-05-15 05:00:26 --> Output Class Initialized
INFO - 2018-05-15 05:00:26 --> Utf8 Class Initialized
INFO - 2018-05-15 05:00:26 --> URI Class Initialized
INFO - 2018-05-15 05:00:26 --> Input Class Initialized
INFO - 2018-05-15 05:00:26 --> Security Class Initialized
INFO - 2018-05-15 05:00:26 --> Language Class Initialized
INFO - 2018-05-15 05:00:26 --> Router Class Initialized
DEBUG - 2018-05-15 05:00:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:00:26 --> URI Class Initialized
ERROR - 2018-05-15 05:00:26 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:00:26 --> Output Class Initialized
INFO - 2018-05-15 05:00:26 --> Config Class Initialized
INFO - 2018-05-15 05:00:26 --> Hooks Class Initialized
INFO - 2018-05-15 05:00:26 --> Security Class Initialized
INFO - 2018-05-15 05:00:26 --> Input Class Initialized
DEBUG - 2018-05-15 05:00:26 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:00:26 --> Router Class Initialized
DEBUG - 2018-05-15 05:00:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:00:26 --> Language Class Initialized
INFO - 2018-05-15 05:00:26 --> Utf8 Class Initialized
INFO - 2018-05-15 05:00:26 --> URI Class Initialized
ERROR - 2018-05-15 05:00:26 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:00:26 --> Output Class Initialized
INFO - 2018-05-15 05:00:26 --> Input Class Initialized
INFO - 2018-05-15 05:00:26 --> Router Class Initialized
INFO - 2018-05-15 05:00:26 --> Security Class Initialized
INFO - 2018-05-15 05:00:26 --> Config Class Initialized
INFO - 2018-05-15 05:00:26 --> Hooks Class Initialized
DEBUG - 2018-05-15 05:00:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:00:26 --> Language Class Initialized
INFO - 2018-05-15 05:00:26 --> Output Class Initialized
INFO - 2018-05-15 05:00:26 --> Input Class Initialized
DEBUG - 2018-05-15 05:00:26 --> UTF-8 Support Enabled
ERROR - 2018-05-15 05:00:26 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:00:26 --> Security Class Initialized
INFO - 2018-05-15 05:00:26 --> Utf8 Class Initialized
DEBUG - 2018-05-15 05:00:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:00:26 --> Language Class Initialized
INFO - 2018-05-15 05:00:26 --> Config Class Initialized
INFO - 2018-05-15 05:00:26 --> Hooks Class Initialized
INFO - 2018-05-15 05:00:26 --> URI Class Initialized
ERROR - 2018-05-15 05:00:26 --> 404 Page Not Found: /index
DEBUG - 2018-05-15 05:00:26 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:00:26 --> Input Class Initialized
INFO - 2018-05-15 05:00:26 --> Router Class Initialized
INFO - 2018-05-15 05:00:26 --> Utf8 Class Initialized
INFO - 2018-05-15 05:00:26 --> Language Class Initialized
INFO - 2018-05-15 05:00:26 --> Output Class Initialized
INFO - 2018-05-15 05:00:26 --> Config Class Initialized
INFO - 2018-05-15 05:00:26 --> Hooks Class Initialized
INFO - 2018-05-15 05:00:26 --> URI Class Initialized
ERROR - 2018-05-15 05:00:26 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:00:26 --> Router Class Initialized
DEBUG - 2018-05-15 05:00:26 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:00:26 --> Security Class Initialized
INFO - 2018-05-15 05:00:26 --> Utf8 Class Initialized
INFO - 2018-05-15 05:00:26 --> Output Class Initialized
DEBUG - 2018-05-15 05:00:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:00:26 --> Config Class Initialized
INFO - 2018-05-15 05:00:26 --> URI Class Initialized
INFO - 2018-05-15 05:00:26 --> Input Class Initialized
INFO - 2018-05-15 05:00:26 --> Security Class Initialized
INFO - 2018-05-15 05:00:26 --> Hooks Class Initialized
DEBUG - 2018-05-15 05:00:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:00:26 --> Language Class Initialized
DEBUG - 2018-05-15 05:00:26 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:00:26 --> Router Class Initialized
INFO - 2018-05-15 05:00:26 --> Input Class Initialized
ERROR - 2018-05-15 05:00:26 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:00:26 --> Utf8 Class Initialized
INFO - 2018-05-15 05:00:26 --> Output Class Initialized
INFO - 2018-05-15 05:00:26 --> Security Class Initialized
INFO - 2018-05-15 05:00:26 --> Language Class Initialized
INFO - 2018-05-15 05:00:26 --> URI Class Initialized
DEBUG - 2018-05-15 05:00:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:00:26 --> Router Class Initialized
INFO - 2018-05-15 05:00:26 --> Input Class Initialized
ERROR - 2018-05-15 05:00:26 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:00:26 --> Output Class Initialized
INFO - 2018-05-15 05:00:26 --> Security Class Initialized
INFO - 2018-05-15 05:00:26 --> Language Class Initialized
ERROR - 2018-05-15 05:00:26 --> 404 Page Not Found: /index
DEBUG - 2018-05-15 05:00:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:00:26 --> Input Class Initialized
INFO - 2018-05-15 05:00:26 --> Language Class Initialized
ERROR - 2018-05-15 05:00:26 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:00:29 --> Config Class Initialized
INFO - 2018-05-15 05:00:29 --> Config Class Initialized
INFO - 2018-05-15 05:00:29 --> Config Class Initialized
INFO - 2018-05-15 05:00:29 --> Config Class Initialized
INFO - 2018-05-15 05:00:29 --> Config Class Initialized
INFO - 2018-05-15 05:00:29 --> Hooks Class Initialized
INFO - 2018-05-15 05:00:29 --> Hooks Class Initialized
INFO - 2018-05-15 05:00:29 --> Hooks Class Initialized
INFO - 2018-05-15 05:00:29 --> Hooks Class Initialized
INFO - 2018-05-15 05:00:29 --> Hooks Class Initialized
DEBUG - 2018-05-15 05:00:29 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:00:29 --> Utf8 Class Initialized
DEBUG - 2018-05-15 05:00:29 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 05:00:29 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 05:00:29 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 05:00:29 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:00:29 --> Utf8 Class Initialized
INFO - 2018-05-15 05:00:29 --> Utf8 Class Initialized
INFO - 2018-05-15 05:00:29 --> Utf8 Class Initialized
INFO - 2018-05-15 05:00:29 --> Utf8 Class Initialized
INFO - 2018-05-15 05:00:29 --> URI Class Initialized
INFO - 2018-05-15 05:00:29 --> URI Class Initialized
INFO - 2018-05-15 05:00:29 --> URI Class Initialized
INFO - 2018-05-15 05:00:29 --> URI Class Initialized
INFO - 2018-05-15 05:00:29 --> URI Class Initialized
INFO - 2018-05-15 05:00:29 --> Router Class Initialized
INFO - 2018-05-15 05:00:29 --> Router Class Initialized
INFO - 2018-05-15 05:00:29 --> Output Class Initialized
INFO - 2018-05-15 05:00:29 --> Router Class Initialized
INFO - 2018-05-15 05:00:29 --> Router Class Initialized
INFO - 2018-05-15 05:00:29 --> Output Class Initialized
INFO - 2018-05-15 05:00:29 --> Output Class Initialized
INFO - 2018-05-15 05:00:29 --> Router Class Initialized
INFO - 2018-05-15 05:00:29 --> Output Class Initialized
INFO - 2018-05-15 05:00:29 --> Security Class Initialized
INFO - 2018-05-15 05:00:29 --> Security Class Initialized
INFO - 2018-05-15 05:00:29 --> Security Class Initialized
INFO - 2018-05-15 05:00:29 --> Output Class Initialized
DEBUG - 2018-05-15 05:00:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:00:29 --> Security Class Initialized
DEBUG - 2018-05-15 05:00:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:00:29 --> Input Class Initialized
DEBUG - 2018-05-15 05:00:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:00:29 --> Security Class Initialized
DEBUG - 2018-05-15 05:00:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:00:29 --> Input Class Initialized
INFO - 2018-05-15 05:00:29 --> Input Class Initialized
INFO - 2018-05-15 05:00:29 --> Language Class Initialized
INFO - 2018-05-15 05:00:29 --> Language Class Initialized
DEBUG - 2018-05-15 05:00:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:00:29 --> Input Class Initialized
INFO - 2018-05-15 05:00:29 --> Language Class Initialized
ERROR - 2018-05-15 05:00:29 --> 404 Page Not Found: /index
ERROR - 2018-05-15 05:00:29 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:00:29 --> Input Class Initialized
INFO - 2018-05-15 05:00:29 --> Language Class Initialized
ERROR - 2018-05-15 05:00:29 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:00:29 --> Language Class Initialized
ERROR - 2018-05-15 05:00:29 --> 404 Page Not Found: /index
ERROR - 2018-05-15 05:00:29 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:00:29 --> Config Class Initialized
INFO - 2018-05-15 05:00:29 --> Config Class Initialized
INFO - 2018-05-15 05:00:29 --> Config Class Initialized
INFO - 2018-05-15 05:00:29 --> Config Class Initialized
INFO - 2018-05-15 05:00:29 --> Hooks Class Initialized
INFO - 2018-05-15 05:00:29 --> Hooks Class Initialized
INFO - 2018-05-15 05:00:29 --> Hooks Class Initialized
INFO - 2018-05-15 05:00:29 --> Hooks Class Initialized
DEBUG - 2018-05-15 05:00:29 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:00:29 --> Utf8 Class Initialized
DEBUG - 2018-05-15 05:00:29 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 05:00:29 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 05:00:29 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:00:29 --> Utf8 Class Initialized
INFO - 2018-05-15 05:00:29 --> Utf8 Class Initialized
INFO - 2018-05-15 05:00:29 --> Utf8 Class Initialized
INFO - 2018-05-15 05:00:29 --> URI Class Initialized
INFO - 2018-05-15 05:00:29 --> URI Class Initialized
INFO - 2018-05-15 05:00:29 --> URI Class Initialized
INFO - 2018-05-15 05:00:29 --> URI Class Initialized
INFO - 2018-05-15 05:00:29 --> Router Class Initialized
INFO - 2018-05-15 05:00:29 --> Router Class Initialized
INFO - 2018-05-15 05:00:29 --> Output Class Initialized
INFO - 2018-05-15 05:00:29 --> Router Class Initialized
INFO - 2018-05-15 05:00:29 --> Router Class Initialized
INFO - 2018-05-15 05:00:30 --> Output Class Initialized
INFO - 2018-05-15 05:00:30 --> Security Class Initialized
INFO - 2018-05-15 05:00:30 --> Output Class Initialized
INFO - 2018-05-15 05:00:30 --> Output Class Initialized
DEBUG - 2018-05-15 05:00:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:00:30 --> Security Class Initialized
INFO - 2018-05-15 05:00:30 --> Security Class Initialized
INFO - 2018-05-15 05:00:30 --> Security Class Initialized
INFO - 2018-05-15 05:00:30 --> Input Class Initialized
INFO - 2018-05-15 05:00:30 --> Language Class Initialized
DEBUG - 2018-05-15 05:00:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-15 05:00:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-15 05:00:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-05-15 05:00:30 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:00:30 --> Input Class Initialized
INFO - 2018-05-15 05:00:30 --> Input Class Initialized
INFO - 2018-05-15 05:00:30 --> Config Class Initialized
INFO - 2018-05-15 05:00:30 --> Language Class Initialized
INFO - 2018-05-15 05:00:30 --> Input Class Initialized
INFO - 2018-05-15 05:00:30 --> Hooks Class Initialized
INFO - 2018-05-15 05:00:30 --> Language Class Initialized
ERROR - 2018-05-15 05:00:30 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:00:30 --> Language Class Initialized
DEBUG - 2018-05-15 05:00:30 --> UTF-8 Support Enabled
ERROR - 2018-05-15 05:00:30 --> 404 Page Not Found: /index
ERROR - 2018-05-15 05:00:30 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:00:30 --> Config Class Initialized
INFO - 2018-05-15 05:00:30 --> Hooks Class Initialized
INFO - 2018-05-15 05:00:30 --> Utf8 Class Initialized
INFO - 2018-05-15 05:00:30 --> Config Class Initialized
INFO - 2018-05-15 05:00:30 --> Config Class Initialized
INFO - 2018-05-15 05:00:30 --> Hooks Class Initialized
DEBUG - 2018-05-15 05:00:30 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:00:30 --> Utf8 Class Initialized
DEBUG - 2018-05-15 05:00:30 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:00:30 --> Hooks Class Initialized
INFO - 2018-05-15 05:00:30 --> Utf8 Class Initialized
INFO - 2018-05-15 05:00:30 --> URI Class Initialized
INFO - 2018-05-15 05:00:30 --> URI Class Initialized
INFO - 2018-05-15 05:00:30 --> URI Class Initialized
INFO - 2018-05-15 05:00:30 --> Router Class Initialized
INFO - 2018-05-15 05:00:30 --> Router Class Initialized
DEBUG - 2018-05-15 05:00:30 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:00:30 --> Utf8 Class Initialized
INFO - 2018-05-15 05:00:30 --> Output Class Initialized
INFO - 2018-05-15 05:00:30 --> Router Class Initialized
INFO - 2018-05-15 05:00:30 --> Output Class Initialized
INFO - 2018-05-15 05:00:30 --> URI Class Initialized
INFO - 2018-05-15 05:00:30 --> Output Class Initialized
INFO - 2018-05-15 05:00:30 --> Security Class Initialized
INFO - 2018-05-15 05:00:30 --> Security Class Initialized
DEBUG - 2018-05-15 05:00:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:00:30 --> Security Class Initialized
DEBUG - 2018-05-15 05:00:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:00:30 --> Router Class Initialized
INFO - 2018-05-15 05:00:30 --> Input Class Initialized
INFO - 2018-05-15 05:00:30 --> Input Class Initialized
DEBUG - 2018-05-15 05:00:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:00:30 --> Output Class Initialized
INFO - 2018-05-15 05:00:30 --> Input Class Initialized
INFO - 2018-05-15 05:00:30 --> Language Class Initialized
INFO - 2018-05-15 05:00:30 --> Language Class Initialized
INFO - 2018-05-15 05:00:30 --> Security Class Initialized
INFO - 2018-05-15 05:00:30 --> Language Class Initialized
DEBUG - 2018-05-15 05:00:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-05-15 05:00:30 --> 404 Page Not Found: /index
ERROR - 2018-05-15 05:00:30 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:00:30 --> Input Class Initialized
ERROR - 2018-05-15 05:00:30 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:00:30 --> Language Class Initialized
ERROR - 2018-05-15 05:00:30 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:00:38 --> Config Class Initialized
INFO - 2018-05-15 05:00:38 --> Hooks Class Initialized
INFO - 2018-05-15 05:00:38 --> Config Class Initialized
INFO - 2018-05-15 05:00:38 --> Hooks Class Initialized
DEBUG - 2018-05-15 05:00:38 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:00:38 --> Utf8 Class Initialized
DEBUG - 2018-05-15 05:00:38 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:00:38 --> URI Class Initialized
INFO - 2018-05-15 05:00:38 --> Router Class Initialized
INFO - 2018-05-15 05:00:38 --> Output Class Initialized
INFO - 2018-05-15 05:00:38 --> Config Class Initialized
INFO - 2018-05-15 05:00:38 --> Config Class Initialized
INFO - 2018-05-15 05:00:38 --> Utf8 Class Initialized
INFO - 2018-05-15 05:00:38 --> Hooks Class Initialized
INFO - 2018-05-15 05:00:38 --> Hooks Class Initialized
INFO - 2018-05-15 05:00:38 --> Security Class Initialized
INFO - 2018-05-15 05:00:38 --> Config Class Initialized
INFO - 2018-05-15 05:00:38 --> URI Class Initialized
INFO - 2018-05-15 05:00:38 --> Config Class Initialized
INFO - 2018-05-15 05:00:38 --> Hooks Class Initialized
DEBUG - 2018-05-15 05:00:38 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:00:38 --> Hooks Class Initialized
DEBUG - 2018-05-15 05:00:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:00:38 --> Router Class Initialized
DEBUG - 2018-05-15 05:00:38 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:00:38 --> Utf8 Class Initialized
DEBUG - 2018-05-15 05:00:38 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 05:00:38 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:00:38 --> Utf8 Class Initialized
INFO - 2018-05-15 05:00:38 --> Input Class Initialized
INFO - 2018-05-15 05:00:38 --> Utf8 Class Initialized
INFO - 2018-05-15 05:00:38 --> Output Class Initialized
INFO - 2018-05-15 05:00:38 --> Utf8 Class Initialized
INFO - 2018-05-15 05:00:38 --> URI Class Initialized
INFO - 2018-05-15 05:00:38 --> URI Class Initialized
INFO - 2018-05-15 05:00:38 --> URI Class Initialized
INFO - 2018-05-15 05:00:38 --> URI Class Initialized
INFO - 2018-05-15 05:00:38 --> Security Class Initialized
INFO - 2018-05-15 05:00:38 --> Router Class Initialized
INFO - 2018-05-15 05:00:38 --> Router Class Initialized
INFO - 2018-05-15 05:00:38 --> Language Class Initialized
INFO - 2018-05-15 05:00:38 --> Router Class Initialized
INFO - 2018-05-15 05:00:38 --> Output Class Initialized
INFO - 2018-05-15 05:00:38 --> Security Class Initialized
DEBUG - 2018-05-15 05:00:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:00:38 --> Router Class Initialized
INFO - 2018-05-15 05:00:38 --> Output Class Initialized
INFO - 2018-05-15 05:00:38 --> Output Class Initialized
ERROR - 2018-05-15 05:00:38 --> 404 Page Not Found: /index
DEBUG - 2018-05-15 05:00:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:00:38 --> Input Class Initialized
INFO - 2018-05-15 05:00:38 --> Language Class Initialized
INFO - 2018-05-15 05:00:38 --> Output Class Initialized
INFO - 2018-05-15 05:00:38 --> Security Class Initialized
INFO - 2018-05-15 05:00:38 --> Security Class Initialized
INFO - 2018-05-15 05:00:38 --> Security Class Initialized
ERROR - 2018-05-15 05:00:38 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:00:38 --> Input Class Initialized
INFO - 2018-05-15 05:00:38 --> Config Class Initialized
DEBUG - 2018-05-15 05:00:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:00:38 --> Hooks Class Initialized
DEBUG - 2018-05-15 05:00:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-15 05:00:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:00:38 --> Language Class Initialized
INFO - 2018-05-15 05:00:38 --> Input Class Initialized
INFO - 2018-05-15 05:00:38 --> Input Class Initialized
ERROR - 2018-05-15 05:00:38 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:00:38 --> Input Class Initialized
DEBUG - 2018-05-15 05:00:38 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:00:38 --> Utf8 Class Initialized
INFO - 2018-05-15 05:00:38 --> Language Class Initialized
INFO - 2018-05-15 05:00:38 --> Language Class Initialized
INFO - 2018-05-15 05:00:38 --> Language Class Initialized
INFO - 2018-05-15 05:00:38 --> URI Class Initialized
ERROR - 2018-05-15 05:00:38 --> 404 Page Not Found: /index
ERROR - 2018-05-15 05:00:38 --> 404 Page Not Found: /index
ERROR - 2018-05-15 05:00:38 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:00:38 --> Router Class Initialized
INFO - 2018-05-15 05:00:38 --> Config Class Initialized
INFO - 2018-05-15 05:00:38 --> Config Class Initialized
INFO - 2018-05-15 05:00:38 --> Config Class Initialized
INFO - 2018-05-15 05:00:38 --> Hooks Class Initialized
INFO - 2018-05-15 05:00:38 --> Hooks Class Initialized
INFO - 2018-05-15 05:00:38 --> Hooks Class Initialized
INFO - 2018-05-15 05:00:38 --> Output Class Initialized
DEBUG - 2018-05-15 05:00:39 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 05:00:39 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 05:00:39 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:00:39 --> Security Class Initialized
INFO - 2018-05-15 05:00:39 --> Utf8 Class Initialized
INFO - 2018-05-15 05:00:39 --> Utf8 Class Initialized
DEBUG - 2018-05-15 05:00:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:00:39 --> Utf8 Class Initialized
INFO - 2018-05-15 05:00:39 --> Input Class Initialized
INFO - 2018-05-15 05:00:39 --> URI Class Initialized
INFO - 2018-05-15 05:00:39 --> Language Class Initialized
INFO - 2018-05-15 05:00:39 --> URI Class Initialized
INFO - 2018-05-15 05:00:39 --> URI Class Initialized
ERROR - 2018-05-15 05:00:39 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:00:39 --> Router Class Initialized
INFO - 2018-05-15 05:00:39 --> Router Class Initialized
INFO - 2018-05-15 05:00:39 --> Router Class Initialized
INFO - 2018-05-15 05:00:39 --> Output Class Initialized
INFO - 2018-05-15 05:00:39 --> Output Class Initialized
INFO - 2018-05-15 05:00:39 --> Output Class Initialized
INFO - 2018-05-15 05:00:39 --> Config Class Initialized
INFO - 2018-05-15 05:00:39 --> Hooks Class Initialized
INFO - 2018-05-15 05:00:39 --> Security Class Initialized
INFO - 2018-05-15 05:00:39 --> Security Class Initialized
INFO - 2018-05-15 05:00:39 --> Security Class Initialized
DEBUG - 2018-05-15 05:00:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-15 05:00:39 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 05:00:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-15 05:00:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:00:39 --> Utf8 Class Initialized
INFO - 2018-05-15 05:00:39 --> Input Class Initialized
INFO - 2018-05-15 05:00:39 --> Input Class Initialized
INFO - 2018-05-15 05:00:39 --> Input Class Initialized
INFO - 2018-05-15 05:00:39 --> URI Class Initialized
INFO - 2018-05-15 05:00:39 --> Language Class Initialized
INFO - 2018-05-15 05:00:39 --> Language Class Initialized
INFO - 2018-05-15 05:00:39 --> Language Class Initialized
ERROR - 2018-05-15 05:00:39 --> 404 Page Not Found: /index
ERROR - 2018-05-15 05:00:39 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:00:39 --> Router Class Initialized
ERROR - 2018-05-15 05:00:39 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:00:39 --> Output Class Initialized
INFO - 2018-05-15 05:00:39 --> Config Class Initialized
INFO - 2018-05-15 05:00:39 --> Hooks Class Initialized
INFO - 2018-05-15 05:00:39 --> Security Class Initialized
INFO - 2018-05-15 05:00:39 --> Config Class Initialized
INFO - 2018-05-15 05:00:39 --> Hooks Class Initialized
DEBUG - 2018-05-15 05:00:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-15 05:00:39 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:00:39 --> Config Class Initialized
INFO - 2018-05-15 05:00:39 --> Hooks Class Initialized
DEBUG - 2018-05-15 05:00:39 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:00:39 --> Utf8 Class Initialized
INFO - 2018-05-15 05:00:39 --> Input Class Initialized
INFO - 2018-05-15 05:00:39 --> Utf8 Class Initialized
INFO - 2018-05-15 05:00:39 --> Language Class Initialized
INFO - 2018-05-15 05:00:39 --> URI Class Initialized
DEBUG - 2018-05-15 05:00:39 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:00:39 --> Utf8 Class Initialized
INFO - 2018-05-15 05:00:39 --> URI Class Initialized
ERROR - 2018-05-15 05:00:39 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:00:39 --> Router Class Initialized
INFO - 2018-05-15 05:00:39 --> Router Class Initialized
INFO - 2018-05-15 05:00:39 --> URI Class Initialized
INFO - 2018-05-15 05:00:39 --> Output Class Initialized
INFO - 2018-05-15 05:00:39 --> Config Class Initialized
INFO - 2018-05-15 05:00:39 --> Hooks Class Initialized
INFO - 2018-05-15 05:00:39 --> Output Class Initialized
INFO - 2018-05-15 05:00:39 --> Security Class Initialized
INFO - 2018-05-15 05:00:39 --> Router Class Initialized
INFO - 2018-05-15 05:00:39 --> Security Class Initialized
INFO - 2018-05-15 05:00:39 --> Output Class Initialized
DEBUG - 2018-05-15 05:00:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-15 05:00:39 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:00:39 --> Input Class Initialized
INFO - 2018-05-15 05:00:39 --> Security Class Initialized
INFO - 2018-05-15 05:00:39 --> Utf8 Class Initialized
DEBUG - 2018-05-15 05:00:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:00:39 --> Language Class Initialized
DEBUG - 2018-05-15 05:00:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:00:39 --> Input Class Initialized
INFO - 2018-05-15 05:00:39 --> URI Class Initialized
INFO - 2018-05-15 05:00:39 --> Input Class Initialized
INFO - 2018-05-15 05:00:39 --> Language Class Initialized
ERROR - 2018-05-15 05:00:39 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:00:39 --> Router Class Initialized
INFO - 2018-05-15 05:00:39 --> Language Class Initialized
ERROR - 2018-05-15 05:00:39 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:00:39 --> Output Class Initialized
ERROR - 2018-05-15 05:00:39 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:00:39 --> Security Class Initialized
DEBUG - 2018-05-15 05:00:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:00:39 --> Input Class Initialized
INFO - 2018-05-15 05:00:39 --> Language Class Initialized
ERROR - 2018-05-15 05:00:39 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:00:43 --> Config Class Initialized
INFO - 2018-05-15 05:00:43 --> Hooks Class Initialized
DEBUG - 2018-05-15 05:00:43 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:00:43 --> Utf8 Class Initialized
INFO - 2018-05-15 05:00:43 --> URI Class Initialized
INFO - 2018-05-15 05:00:43 --> Router Class Initialized
INFO - 2018-05-15 05:00:43 --> Output Class Initialized
INFO - 2018-05-15 05:00:43 --> Security Class Initialized
INFO - 2018-05-15 05:00:43 --> Config Class Initialized
INFO - 2018-05-15 05:00:43 --> Hooks Class Initialized
DEBUG - 2018-05-15 05:00:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-15 05:00:43 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:00:43 --> Utf8 Class Initialized
INFO - 2018-05-15 05:00:43 --> Input Class Initialized
INFO - 2018-05-15 05:00:43 --> Language Class Initialized
INFO - 2018-05-15 05:00:43 --> URI Class Initialized
INFO - 2018-05-15 05:00:43 --> Router Class Initialized
ERROR - 2018-05-15 05:00:43 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:00:43 --> Output Class Initialized
INFO - 2018-05-15 05:00:43 --> Config Class Initialized
INFO - 2018-05-15 05:00:43 --> Config Class Initialized
INFO - 2018-05-15 05:00:43 --> Config Class Initialized
INFO - 2018-05-15 05:00:43 --> Config Class Initialized
INFO - 2018-05-15 05:00:43 --> Config Class Initialized
INFO - 2018-05-15 05:00:43 --> Hooks Class Initialized
INFO - 2018-05-15 05:00:43 --> Hooks Class Initialized
INFO - 2018-05-15 05:00:43 --> Hooks Class Initialized
INFO - 2018-05-15 05:00:43 --> Hooks Class Initialized
INFO - 2018-05-15 05:00:43 --> Security Class Initialized
INFO - 2018-05-15 05:00:43 --> Hooks Class Initialized
DEBUG - 2018-05-15 05:00:43 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:00:43 --> Utf8 Class Initialized
DEBUG - 2018-05-15 05:00:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-15 05:00:43 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 05:00:43 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:00:43 --> URI Class Initialized
DEBUG - 2018-05-15 05:00:43 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 05:00:43 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:00:43 --> Input Class Initialized
INFO - 2018-05-15 05:00:43 --> Utf8 Class Initialized
INFO - 2018-05-15 05:00:43 --> Utf8 Class Initialized
INFO - 2018-05-15 05:00:43 --> Utf8 Class Initialized
INFO - 2018-05-15 05:00:43 --> Utf8 Class Initialized
INFO - 2018-05-15 05:00:43 --> Language Class Initialized
INFO - 2018-05-15 05:00:43 --> Router Class Initialized
INFO - 2018-05-15 05:00:43 --> URI Class Initialized
INFO - 2018-05-15 05:00:44 --> Router Class Initialized
INFO - 2018-05-15 05:00:44 --> Output Class Initialized
INFO - 2018-05-15 05:00:44 --> URI Class Initialized
INFO - 2018-05-15 05:00:44 --> URI Class Initialized
INFO - 2018-05-15 05:00:44 --> URI Class Initialized
ERROR - 2018-05-15 05:00:44 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:00:44 --> Output Class Initialized
INFO - 2018-05-15 05:00:44 --> Security Class Initialized
INFO - 2018-05-15 05:00:44 --> Router Class Initialized
INFO - 2018-05-15 05:00:44 --> Router Class Initialized
INFO - 2018-05-15 05:00:44 --> Security Class Initialized
DEBUG - 2018-05-15 05:00:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:00:44 --> Router Class Initialized
INFO - 2018-05-15 05:00:44 --> Output Class Initialized
INFO - 2018-05-15 05:00:44 --> Security Class Initialized
DEBUG - 2018-05-15 05:00:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:00:44 --> Input Class Initialized
INFO - 2018-05-15 05:00:44 --> Output Class Initialized
DEBUG - 2018-05-15 05:00:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:00:44 --> Input Class Initialized
INFO - 2018-05-15 05:00:44 --> Output Class Initialized
INFO - 2018-05-15 05:00:44 --> Input Class Initialized
INFO - 2018-05-15 05:00:44 --> Security Class Initialized
INFO - 2018-05-15 05:00:44 --> Language Class Initialized
INFO - 2018-05-15 05:00:44 --> Language Class Initialized
INFO - 2018-05-15 05:00:44 --> Security Class Initialized
ERROR - 2018-05-15 05:00:44 --> 404 Page Not Found: /index
DEBUG - 2018-05-15 05:00:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-15 05:00:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-05-15 05:00:44 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:00:44 --> Language Class Initialized
INFO - 2018-05-15 05:00:44 --> Input Class Initialized
INFO - 2018-05-15 05:00:44 --> Input Class Initialized
ERROR - 2018-05-15 05:00:44 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:00:44 --> Config Class Initialized
INFO - 2018-05-15 05:00:44 --> Hooks Class Initialized
INFO - 2018-05-15 05:00:44 --> Language Class Initialized
DEBUG - 2018-05-15 05:00:44 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:00:44 --> Language Class Initialized
ERROR - 2018-05-15 05:00:44 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:00:44 --> Config Class Initialized
INFO - 2018-05-15 05:00:44 --> Hooks Class Initialized
INFO - 2018-05-15 05:00:44 --> Utf8 Class Initialized
ERROR - 2018-05-15 05:00:44 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:00:44 --> Config Class Initialized
INFO - 2018-05-15 05:00:44 --> Hooks Class Initialized
INFO - 2018-05-15 05:00:44 --> URI Class Initialized
DEBUG - 2018-05-15 05:00:44 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:00:44 --> Config Class Initialized
INFO - 2018-05-15 05:00:44 --> Hooks Class Initialized
DEBUG - 2018-05-15 05:00:44 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:00:44 --> Router Class Initialized
INFO - 2018-05-15 05:00:44 --> Utf8 Class Initialized
INFO - 2018-05-15 05:00:44 --> Utf8 Class Initialized
INFO - 2018-05-15 05:00:44 --> URI Class Initialized
DEBUG - 2018-05-15 05:00:44 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:00:44 --> Output Class Initialized
INFO - 2018-05-15 05:00:44 --> Utf8 Class Initialized
INFO - 2018-05-15 05:00:44 --> Security Class Initialized
INFO - 2018-05-15 05:00:44 --> URI Class Initialized
INFO - 2018-05-15 05:00:44 --> Router Class Initialized
INFO - 2018-05-15 05:00:44 --> Output Class Initialized
INFO - 2018-05-15 05:00:44 --> URI Class Initialized
DEBUG - 2018-05-15 05:00:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:00:44 --> Router Class Initialized
INFO - 2018-05-15 05:00:44 --> Output Class Initialized
INFO - 2018-05-15 05:00:44 --> Input Class Initialized
INFO - 2018-05-15 05:00:44 --> Router Class Initialized
INFO - 2018-05-15 05:00:44 --> Security Class Initialized
DEBUG - 2018-05-15 05:00:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:00:44 --> Output Class Initialized
INFO - 2018-05-15 05:00:44 --> Language Class Initialized
INFO - 2018-05-15 05:00:44 --> Security Class Initialized
INFO - 2018-05-15 05:00:44 --> Security Class Initialized
DEBUG - 2018-05-15 05:00:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:00:44 --> Input Class Initialized
ERROR - 2018-05-15 05:00:44 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:00:44 --> Input Class Initialized
DEBUG - 2018-05-15 05:00:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:00:44 --> Language Class Initialized
INFO - 2018-05-15 05:00:44 --> Config Class Initialized
INFO - 2018-05-15 05:00:44 --> Hooks Class Initialized
INFO - 2018-05-15 05:00:44 --> Input Class Initialized
INFO - 2018-05-15 05:00:44 --> Language Class Initialized
ERROR - 2018-05-15 05:00:44 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:00:44 --> Language Class Initialized
DEBUG - 2018-05-15 05:00:44 --> UTF-8 Support Enabled
ERROR - 2018-05-15 05:00:44 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:00:44 --> Config Class Initialized
INFO - 2018-05-15 05:00:44 --> Hooks Class Initialized
INFO - 2018-05-15 05:00:44 --> Utf8 Class Initialized
ERROR - 2018-05-15 05:00:44 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:00:44 --> Config Class Initialized
INFO - 2018-05-15 05:00:44 --> Hooks Class Initialized
DEBUG - 2018-05-15 05:00:44 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:00:44 --> URI Class Initialized
INFO - 2018-05-15 05:00:44 --> Config Class Initialized
INFO - 2018-05-15 05:00:44 --> Hooks Class Initialized
DEBUG - 2018-05-15 05:00:44 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:00:44 --> Utf8 Class Initialized
DEBUG - 2018-05-15 05:00:44 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:00:44 --> Router Class Initialized
INFO - 2018-05-15 05:00:44 --> Utf8 Class Initialized
INFO - 2018-05-15 05:00:44 --> URI Class Initialized
INFO - 2018-05-15 05:00:44 --> Utf8 Class Initialized
INFO - 2018-05-15 05:00:44 --> Output Class Initialized
INFO - 2018-05-15 05:00:44 --> URI Class Initialized
INFO - 2018-05-15 05:00:44 --> URI Class Initialized
INFO - 2018-05-15 05:00:44 --> Security Class Initialized
INFO - 2018-05-15 05:00:44 --> Router Class Initialized
INFO - 2018-05-15 05:00:44 --> Router Class Initialized
INFO - 2018-05-15 05:00:44 --> Output Class Initialized
INFO - 2018-05-15 05:00:44 --> Router Class Initialized
INFO - 2018-05-15 05:00:44 --> Output Class Initialized
DEBUG - 2018-05-15 05:00:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:00:44 --> Input Class Initialized
INFO - 2018-05-15 05:00:44 --> Security Class Initialized
INFO - 2018-05-15 05:00:44 --> Output Class Initialized
INFO - 2018-05-15 05:00:44 --> Security Class Initialized
INFO - 2018-05-15 05:00:44 --> Language Class Initialized
DEBUG - 2018-05-15 05:00:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:00:44 --> Security Class Initialized
DEBUG - 2018-05-15 05:00:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:00:44 --> Input Class Initialized
INFO - 2018-05-15 05:00:44 --> Input Class Initialized
ERROR - 2018-05-15 05:00:44 --> 404 Page Not Found: /index
DEBUG - 2018-05-15 05:00:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:00:44 --> Language Class Initialized
INFO - 2018-05-15 05:00:44 --> Input Class Initialized
INFO - 2018-05-15 05:00:44 --> Language Class Initialized
ERROR - 2018-05-15 05:00:44 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:00:44 --> Language Class Initialized
ERROR - 2018-05-15 05:00:44 --> 404 Page Not Found: /index
ERROR - 2018-05-15 05:00:44 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:00:56 --> Config Class Initialized
INFO - 2018-05-15 05:00:56 --> Hooks Class Initialized
DEBUG - 2018-05-15 05:00:56 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:00:56 --> Utf8 Class Initialized
INFO - 2018-05-15 05:00:56 --> Config Class Initialized
INFO - 2018-05-15 05:00:56 --> Hooks Class Initialized
INFO - 2018-05-15 05:00:56 --> URI Class Initialized
DEBUG - 2018-05-15 05:00:56 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:00:56 --> Utf8 Class Initialized
INFO - 2018-05-15 05:00:56 --> URI Class Initialized
INFO - 2018-05-15 05:00:56 --> Router Class Initialized
INFO - 2018-05-15 05:00:56 --> Output Class Initialized
INFO - 2018-05-15 05:00:56 --> Router Class Initialized
INFO - 2018-05-15 05:00:56 --> Config Class Initialized
INFO - 2018-05-15 05:00:56 --> Config Class Initialized
INFO - 2018-05-15 05:00:56 --> Config Class Initialized
INFO - 2018-05-15 05:00:56 --> Config Class Initialized
INFO - 2018-05-15 05:00:56 --> Hooks Class Initialized
INFO - 2018-05-15 05:00:56 --> Security Class Initialized
INFO - 2018-05-15 05:00:56 --> Hooks Class Initialized
INFO - 2018-05-15 05:00:56 --> Hooks Class Initialized
INFO - 2018-05-15 05:00:56 --> Hooks Class Initialized
DEBUG - 2018-05-15 05:00:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:00:56 --> Output Class Initialized
DEBUG - 2018-05-15 05:00:56 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 05:00:56 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:00:56 --> Utf8 Class Initialized
INFO - 2018-05-15 05:00:56 --> URI Class Initialized
INFO - 2018-05-15 05:00:57 --> Utf8 Class Initialized
INFO - 2018-05-15 05:00:57 --> Input Class Initialized
INFO - 2018-05-15 05:00:57 --> Security Class Initialized
INFO - 2018-05-15 05:00:57 --> Router Class Initialized
DEBUG - 2018-05-15 05:00:57 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 05:00:57 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:00:57 --> Language Class Initialized
INFO - 2018-05-15 05:00:57 --> Output Class Initialized
DEBUG - 2018-05-15 05:00:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:00:57 --> Utf8 Class Initialized
INFO - 2018-05-15 05:00:57 --> Utf8 Class Initialized
INFO - 2018-05-15 05:00:57 --> URI Class Initialized
INFO - 2018-05-15 05:00:57 --> Router Class Initialized
ERROR - 2018-05-15 05:00:57 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:00:57 --> Input Class Initialized
INFO - 2018-05-15 05:00:57 --> Security Class Initialized
INFO - 2018-05-15 05:00:57 --> URI Class Initialized
INFO - 2018-05-15 05:00:57 --> URI Class Initialized
INFO - 2018-05-15 05:00:57 --> Output Class Initialized
DEBUG - 2018-05-15 05:00:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:00:57 --> Config Class Initialized
INFO - 2018-05-15 05:00:57 --> Router Class Initialized
INFO - 2018-05-15 05:00:57 --> Language Class Initialized
INFO - 2018-05-15 05:00:57 --> Router Class Initialized
INFO - 2018-05-15 05:00:57 --> Security Class Initialized
INFO - 2018-05-15 05:00:57 --> Hooks Class Initialized
INFO - 2018-05-15 05:00:57 --> Output Class Initialized
ERROR - 2018-05-15 05:00:57 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:00:57 --> Output Class Initialized
DEBUG - 2018-05-15 05:00:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:00:57 --> Input Class Initialized
DEBUG - 2018-05-15 05:00:57 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:00:57 --> Input Class Initialized
INFO - 2018-05-15 05:00:57 --> Language Class Initialized
INFO - 2018-05-15 05:00:57 --> Security Class Initialized
INFO - 2018-05-15 05:00:57 --> Utf8 Class Initialized
INFO - 2018-05-15 05:00:57 --> Security Class Initialized
ERROR - 2018-05-15 05:00:57 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:00:57 --> Language Class Initialized
DEBUG - 2018-05-15 05:00:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:00:57 --> URI Class Initialized
DEBUG - 2018-05-15 05:00:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-05-15 05:00:57 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:00:57 --> Input Class Initialized
INFO - 2018-05-15 05:00:57 --> Language Class Initialized
ERROR - 2018-05-15 05:00:57 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:00:57 --> Input Class Initialized
INFO - 2018-05-15 05:00:57 --> Router Class Initialized
INFO - 2018-05-15 05:00:57 --> Config Class Initialized
INFO - 2018-05-15 05:00:57 --> Hooks Class Initialized
INFO - 2018-05-15 05:00:57 --> Language Class Initialized
INFO - 2018-05-15 05:00:57 --> Config Class Initialized
INFO - 2018-05-15 05:00:57 --> Output Class Initialized
INFO - 2018-05-15 05:00:57 --> Hooks Class Initialized
DEBUG - 2018-05-15 05:00:57 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:00:57 --> Utf8 Class Initialized
INFO - 2018-05-15 05:00:57 --> Security Class Initialized
ERROR - 2018-05-15 05:00:57 --> 404 Page Not Found: /index
DEBUG - 2018-05-15 05:00:57 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:00:57 --> Utf8 Class Initialized
INFO - 2018-05-15 05:00:57 --> URI Class Initialized
INFO - 2018-05-15 05:00:57 --> Config Class Initialized
DEBUG - 2018-05-15 05:00:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:00:57 --> Hooks Class Initialized
INFO - 2018-05-15 05:00:57 --> URI Class Initialized
INFO - 2018-05-15 05:00:57 --> Input Class Initialized
INFO - 2018-05-15 05:00:57 --> Router Class Initialized
DEBUG - 2018-05-15 05:00:57 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:00:57 --> Output Class Initialized
INFO - 2018-05-15 05:00:57 --> Router Class Initialized
INFO - 2018-05-15 05:00:57 --> Language Class Initialized
INFO - 2018-05-15 05:00:57 --> Utf8 Class Initialized
INFO - 2018-05-15 05:00:57 --> Output Class Initialized
INFO - 2018-05-15 05:00:57 --> Security Class Initialized
INFO - 2018-05-15 05:00:57 --> URI Class Initialized
DEBUG - 2018-05-15 05:00:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-05-15 05:00:57 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:00:57 --> Security Class Initialized
INFO - 2018-05-15 05:00:57 --> Input Class Initialized
INFO - 2018-05-15 05:00:57 --> Router Class Initialized
DEBUG - 2018-05-15 05:00:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:00:57 --> Config Class Initialized
INFO - 2018-05-15 05:00:57 --> Hooks Class Initialized
INFO - 2018-05-15 05:00:57 --> Language Class Initialized
INFO - 2018-05-15 05:00:57 --> Input Class Initialized
INFO - 2018-05-15 05:00:57 --> Output Class Initialized
ERROR - 2018-05-15 05:00:57 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:00:57 --> Security Class Initialized
DEBUG - 2018-05-15 05:00:57 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:00:57 --> Language Class Initialized
INFO - 2018-05-15 05:00:57 --> Utf8 Class Initialized
ERROR - 2018-05-15 05:00:57 --> 404 Page Not Found: /index
DEBUG - 2018-05-15 05:00:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:00:57 --> Config Class Initialized
INFO - 2018-05-15 05:00:57 --> Hooks Class Initialized
INFO - 2018-05-15 05:00:57 --> Input Class Initialized
INFO - 2018-05-15 05:00:57 --> URI Class Initialized
INFO - 2018-05-15 05:00:57 --> Config Class Initialized
INFO - 2018-05-15 05:00:57 --> Hooks Class Initialized
INFO - 2018-05-15 05:00:57 --> Language Class Initialized
DEBUG - 2018-05-15 05:00:57 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:00:57 --> Router Class Initialized
INFO - 2018-05-15 05:00:57 --> Utf8 Class Initialized
INFO - 2018-05-15 05:00:57 --> Output Class Initialized
ERROR - 2018-05-15 05:00:57 --> 404 Page Not Found: /index
DEBUG - 2018-05-15 05:00:57 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:00:57 --> Security Class Initialized
INFO - 2018-05-15 05:00:57 --> Utf8 Class Initialized
INFO - 2018-05-15 05:00:57 --> URI Class Initialized
INFO - 2018-05-15 05:00:57 --> URI Class Initialized
INFO - 2018-05-15 05:00:57 --> Router Class Initialized
DEBUG - 2018-05-15 05:00:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:00:57 --> Config Class Initialized
INFO - 2018-05-15 05:00:57 --> Hooks Class Initialized
INFO - 2018-05-15 05:00:57 --> Input Class Initialized
INFO - 2018-05-15 05:00:57 --> Output Class Initialized
INFO - 2018-05-15 05:00:57 --> Router Class Initialized
DEBUG - 2018-05-15 05:00:57 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:00:57 --> Security Class Initialized
INFO - 2018-05-15 05:00:57 --> Output Class Initialized
INFO - 2018-05-15 05:00:57 --> Utf8 Class Initialized
INFO - 2018-05-15 05:00:57 --> Language Class Initialized
INFO - 2018-05-15 05:00:57 --> Security Class Initialized
DEBUG - 2018-05-15 05:00:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-05-15 05:00:57 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:00:57 --> URI Class Initialized
INFO - 2018-05-15 05:00:58 --> Input Class Initialized
DEBUG - 2018-05-15 05:00:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:00:58 --> Router Class Initialized
INFO - 2018-05-15 05:00:58 --> Config Class Initialized
INFO - 2018-05-15 05:00:58 --> Hooks Class Initialized
INFO - 2018-05-15 05:00:58 --> Input Class Initialized
INFO - 2018-05-15 05:00:58 --> Language Class Initialized
INFO - 2018-05-15 05:00:58 --> Output Class Initialized
INFO - 2018-05-15 05:00:58 --> Language Class Initialized
ERROR - 2018-05-15 05:00:58 --> 404 Page Not Found: /index
DEBUG - 2018-05-15 05:00:58 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:00:58 --> Security Class Initialized
DEBUG - 2018-05-15 05:00:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:00:58 --> Utf8 Class Initialized
ERROR - 2018-05-15 05:00:58 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:00:58 --> Input Class Initialized
INFO - 2018-05-15 05:00:58 --> URI Class Initialized
INFO - 2018-05-15 05:00:58 --> Language Class Initialized
INFO - 2018-05-15 05:00:58 --> Router Class Initialized
INFO - 2018-05-15 05:00:58 --> Output Class Initialized
ERROR - 2018-05-15 05:00:58 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:00:58 --> Security Class Initialized
DEBUG - 2018-05-15 05:00:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:00:58 --> Input Class Initialized
INFO - 2018-05-15 05:00:58 --> Language Class Initialized
ERROR - 2018-05-15 05:00:58 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:05:49 --> Config Class Initialized
INFO - 2018-05-15 05:05:49 --> Hooks Class Initialized
DEBUG - 2018-05-15 05:05:49 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:05:49 --> Utf8 Class Initialized
INFO - 2018-05-15 05:05:49 --> URI Class Initialized
INFO - 2018-05-15 05:05:49 --> Router Class Initialized
INFO - 2018-05-15 05:05:49 --> Output Class Initialized
INFO - 2018-05-15 05:05:49 --> Security Class Initialized
DEBUG - 2018-05-15 05:05:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:05:50 --> Input Class Initialized
INFO - 2018-05-15 05:05:50 --> Language Class Initialized
INFO - 2018-05-15 05:05:50 --> Language Class Initialized
INFO - 2018-05-15 05:05:50 --> Config Class Initialized
INFO - 2018-05-15 05:05:50 --> Loader Class Initialized
DEBUG - 2018-05-15 05:05:50 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-15 05:05:50 --> Helper loaded: url_helper
INFO - 2018-05-15 05:05:50 --> Helper loaded: form_helper
INFO - 2018-05-15 05:05:50 --> Helper loaded: date_helper
INFO - 2018-05-15 05:05:50 --> Helper loaded: util_helper
INFO - 2018-05-15 05:05:50 --> Helper loaded: text_helper
INFO - 2018-05-15 05:05:50 --> Helper loaded: string_helper
INFO - 2018-05-15 05:05:50 --> Database Driver Class Initialized
DEBUG - 2018-05-15 05:05:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-15 05:05:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-15 05:05:50 --> Email Class Initialized
INFO - 2018-05-15 05:05:50 --> Controller Class Initialized
DEBUG - 2018-05-15 05:05:50 --> Programs MX_Controller Initialized
INFO - 2018-05-15 05:05:50 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-15 05:05:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-05-15 05:05:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-15 05:05:50 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-15 05:05:50 --> Login MX_Controller Initialized
DEBUG - 2018-05-15 05:05:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-15 05:05:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-05-15 05:05:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-05-15 05:05:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-05-15 05:05:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-05-15 05:05:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-05-15 05:05:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/programs/programs.php
INFO - 2018-05-15 05:05:50 --> Final output sent to browser
DEBUG - 2018-05-15 05:05:50 --> Total execution time: 0.7375
INFO - 2018-05-15 05:05:51 --> Config Class Initialized
INFO - 2018-05-15 05:05:51 --> Hooks Class Initialized
DEBUG - 2018-05-15 05:05:51 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:05:51 --> Utf8 Class Initialized
INFO - 2018-05-15 05:05:51 --> URI Class Initialized
INFO - 2018-05-15 05:05:51 --> Router Class Initialized
INFO - 2018-05-15 05:05:51 --> Output Class Initialized
INFO - 2018-05-15 05:05:51 --> Security Class Initialized
DEBUG - 2018-05-15 05:05:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:05:51 --> Input Class Initialized
INFO - 2018-05-15 05:05:51 --> Language Class Initialized
INFO - 2018-05-15 05:05:51 --> Language Class Initialized
INFO - 2018-05-15 05:05:51 --> Config Class Initialized
INFO - 2018-05-15 05:05:51 --> Loader Class Initialized
DEBUG - 2018-05-15 05:05:51 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-15 05:05:51 --> Helper loaded: url_helper
INFO - 2018-05-15 05:05:51 --> Helper loaded: form_helper
INFO - 2018-05-15 05:05:51 --> Helper loaded: date_helper
INFO - 2018-05-15 05:05:51 --> Helper loaded: util_helper
INFO - 2018-05-15 05:05:51 --> Helper loaded: text_helper
INFO - 2018-05-15 05:05:51 --> Helper loaded: string_helper
INFO - 2018-05-15 05:05:51 --> Database Driver Class Initialized
DEBUG - 2018-05-15 05:05:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-15 05:05:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-15 05:05:51 --> Email Class Initialized
INFO - 2018-05-15 05:05:51 --> Controller Class Initialized
DEBUG - 2018-05-15 05:05:51 --> Programs MX_Controller Initialized
INFO - 2018-05-15 05:05:51 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-15 05:05:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-05-15 05:05:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-15 05:05:51 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-15 05:05:51 --> Login MX_Controller Initialized
DEBUG - 2018-05-15 05:05:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-15 05:05:51 --> Final output sent to browser
DEBUG - 2018-05-15 05:05:51 --> Total execution time: 0.8282
INFO - 2018-05-15 05:08:17 --> Config Class Initialized
INFO - 2018-05-15 05:08:17 --> Hooks Class Initialized
DEBUG - 2018-05-15 05:08:17 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:08:17 --> Utf8 Class Initialized
INFO - 2018-05-15 05:08:17 --> URI Class Initialized
INFO - 2018-05-15 05:08:17 --> Router Class Initialized
INFO - 2018-05-15 05:08:17 --> Output Class Initialized
INFO - 2018-05-15 05:08:17 --> Security Class Initialized
DEBUG - 2018-05-15 05:08:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:08:17 --> Input Class Initialized
INFO - 2018-05-15 05:08:17 --> Language Class Initialized
ERROR - 2018-05-15 05:08:17 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:16:56 --> Config Class Initialized
INFO - 2018-05-15 05:16:56 --> Hooks Class Initialized
DEBUG - 2018-05-15 05:16:56 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:16:56 --> Utf8 Class Initialized
INFO - 2018-05-15 05:16:56 --> URI Class Initialized
INFO - 2018-05-15 05:16:56 --> Router Class Initialized
INFO - 2018-05-15 05:16:56 --> Output Class Initialized
INFO - 2018-05-15 05:16:56 --> Security Class Initialized
DEBUG - 2018-05-15 05:16:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:16:56 --> Input Class Initialized
INFO - 2018-05-15 05:16:56 --> Language Class Initialized
ERROR - 2018-05-15 05:16:56 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:17:01 --> Config Class Initialized
INFO - 2018-05-15 05:17:01 --> Hooks Class Initialized
DEBUG - 2018-05-15 05:17:01 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:17:01 --> Utf8 Class Initialized
INFO - 2018-05-15 05:17:01 --> URI Class Initialized
INFO - 2018-05-15 05:17:01 --> Router Class Initialized
INFO - 2018-05-15 05:17:01 --> Output Class Initialized
INFO - 2018-05-15 05:17:01 --> Security Class Initialized
DEBUG - 2018-05-15 05:17:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:17:01 --> Input Class Initialized
INFO - 2018-05-15 05:17:01 --> Language Class Initialized
ERROR - 2018-05-15 05:17:01 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:17:02 --> Config Class Initialized
INFO - 2018-05-15 05:17:02 --> Config Class Initialized
INFO - 2018-05-15 05:17:02 --> Config Class Initialized
INFO - 2018-05-15 05:17:02 --> Config Class Initialized
INFO - 2018-05-15 05:17:02 --> Config Class Initialized
INFO - 2018-05-15 05:17:02 --> Config Class Initialized
INFO - 2018-05-15 05:17:02 --> Hooks Class Initialized
INFO - 2018-05-15 05:17:02 --> Hooks Class Initialized
INFO - 2018-05-15 05:17:02 --> Hooks Class Initialized
INFO - 2018-05-15 05:17:02 --> Hooks Class Initialized
INFO - 2018-05-15 05:17:02 --> Hooks Class Initialized
INFO - 2018-05-15 05:17:02 --> Hooks Class Initialized
DEBUG - 2018-05-15 05:17:02 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:17:02 --> Utf8 Class Initialized
INFO - 2018-05-15 05:17:02 --> URI Class Initialized
INFO - 2018-05-15 05:17:02 --> Router Class Initialized
DEBUG - 2018-05-15 05:17:02 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 05:17:02 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 05:17:02 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:17:02 --> Output Class Initialized
DEBUG - 2018-05-15 05:17:02 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 05:17:02 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:17:02 --> Utf8 Class Initialized
INFO - 2018-05-15 05:17:02 --> URI Class Initialized
INFO - 2018-05-15 05:17:02 --> Utf8 Class Initialized
INFO - 2018-05-15 05:17:02 --> Router Class Initialized
INFO - 2018-05-15 05:17:02 --> URI Class Initialized
INFO - 2018-05-15 05:17:02 --> Utf8 Class Initialized
INFO - 2018-05-15 05:17:02 --> Router Class Initialized
INFO - 2018-05-15 05:17:02 --> Utf8 Class Initialized
INFO - 2018-05-15 05:17:02 --> Utf8 Class Initialized
INFO - 2018-05-15 05:17:02 --> Output Class Initialized
INFO - 2018-05-15 05:17:02 --> Security Class Initialized
INFO - 2018-05-15 05:17:02 --> URI Class Initialized
INFO - 2018-05-15 05:17:02 --> Output Class Initialized
INFO - 2018-05-15 05:17:02 --> URI Class Initialized
INFO - 2018-05-15 05:17:02 --> Security Class Initialized
INFO - 2018-05-15 05:17:02 --> URI Class Initialized
DEBUG - 2018-05-15 05:17:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:17:02 --> Input Class Initialized
INFO - 2018-05-15 05:17:02 --> Language Class Initialized
ERROR - 2018-05-15 05:17:02 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:17:02 --> Router Class Initialized
INFO - 2018-05-15 05:17:02 --> Router Class Initialized
INFO - 2018-05-15 05:17:02 --> Security Class Initialized
DEBUG - 2018-05-15 05:17:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:17:02 --> Router Class Initialized
INFO - 2018-05-15 05:17:02 --> Output Class Initialized
INFO - 2018-05-15 05:17:02 --> Config Class Initialized
INFO - 2018-05-15 05:17:02 --> Security Class Initialized
DEBUG - 2018-05-15 05:17:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:17:02 --> Input Class Initialized
INFO - 2018-05-15 05:17:02 --> Language Class Initialized
ERROR - 2018-05-15 05:17:02 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:17:02 --> Config Class Initialized
INFO - 2018-05-15 05:17:02 --> Hooks Class Initialized
DEBUG - 2018-05-15 05:17:02 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:17:02 --> Output Class Initialized
DEBUG - 2018-05-15 05:17:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:17:02 --> Output Class Initialized
INFO - 2018-05-15 05:17:02 --> Hooks Class Initialized
INFO - 2018-05-15 05:17:02 --> Utf8 Class Initialized
INFO - 2018-05-15 05:17:02 --> Input Class Initialized
DEBUG - 2018-05-15 05:17:02 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:17:02 --> Security Class Initialized
INFO - 2018-05-15 05:17:02 --> Input Class Initialized
INFO - 2018-05-15 05:17:02 --> Security Class Initialized
INFO - 2018-05-15 05:17:02 --> Language Class Initialized
INFO - 2018-05-15 05:17:02 --> URI Class Initialized
DEBUG - 2018-05-15 05:17:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-15 05:17:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:17:02 --> Language Class Initialized
ERROR - 2018-05-15 05:17:02 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:17:02 --> Router Class Initialized
INFO - 2018-05-15 05:17:02 --> Utf8 Class Initialized
INFO - 2018-05-15 05:17:02 --> Input Class Initialized
INFO - 2018-05-15 05:17:03 --> Language Class Initialized
INFO - 2018-05-15 05:17:03 --> Input Class Initialized
ERROR - 2018-05-15 05:17:03 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:17:03 --> Config Class Initialized
INFO - 2018-05-15 05:17:03 --> Output Class Initialized
ERROR - 2018-05-15 05:17:03 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:17:03 --> URI Class Initialized
INFO - 2018-05-15 05:17:03 --> Hooks Class Initialized
INFO - 2018-05-15 05:17:03 --> Language Class Initialized
INFO - 2018-05-15 05:17:03 --> Router Class Initialized
INFO - 2018-05-15 05:17:03 --> Security Class Initialized
INFO - 2018-05-15 05:17:03 --> Config Class Initialized
INFO - 2018-05-15 05:17:03 --> Hooks Class Initialized
DEBUG - 2018-05-15 05:17:03 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 05:17:03 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:17:03 --> Utf8 Class Initialized
INFO - 2018-05-15 05:17:03 --> URI Class Initialized
INFO - 2018-05-15 05:17:03 --> Utf8 Class Initialized
INFO - 2018-05-15 05:17:03 --> Router Class Initialized
ERROR - 2018-05-15 05:17:03 --> 404 Page Not Found: /index
DEBUG - 2018-05-15 05:17:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:17:03 --> Output Class Initialized
INFO - 2018-05-15 05:17:03 --> Output Class Initialized
INFO - 2018-05-15 05:17:03 --> Input Class Initialized
INFO - 2018-05-15 05:17:03 --> Config Class Initialized
INFO - 2018-05-15 05:17:03 --> Security Class Initialized
INFO - 2018-05-15 05:17:03 --> URI Class Initialized
INFO - 2018-05-15 05:17:03 --> Hooks Class Initialized
INFO - 2018-05-15 05:17:03 --> Security Class Initialized
INFO - 2018-05-15 05:17:03 --> Router Class Initialized
DEBUG - 2018-05-15 05:17:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:17:03 --> Language Class Initialized
DEBUG - 2018-05-15 05:17:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:17:03 --> Input Class Initialized
INFO - 2018-05-15 05:17:03 --> Output Class Initialized
ERROR - 2018-05-15 05:17:03 --> 404 Page Not Found: /index
DEBUG - 2018-05-15 05:17:03 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:17:03 --> Input Class Initialized
INFO - 2018-05-15 05:17:03 --> Language Class Initialized
INFO - 2018-05-15 05:17:03 --> Language Class Initialized
INFO - 2018-05-15 05:17:03 --> Security Class Initialized
INFO - 2018-05-15 05:17:03 --> Utf8 Class Initialized
INFO - 2018-05-15 05:17:03 --> Config Class Initialized
ERROR - 2018-05-15 05:17:03 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:17:03 --> Hooks Class Initialized
ERROR - 2018-05-15 05:17:03 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:17:03 --> URI Class Initialized
INFO - 2018-05-15 05:17:03 --> Config Class Initialized
DEBUG - 2018-05-15 05:17:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:17:03 --> Hooks Class Initialized
DEBUG - 2018-05-15 05:17:03 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:17:03 --> Config Class Initialized
INFO - 2018-05-15 05:17:03 --> Hooks Class Initialized
DEBUG - 2018-05-15 05:17:03 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:17:03 --> Input Class Initialized
INFO - 2018-05-15 05:17:03 --> Router Class Initialized
INFO - 2018-05-15 05:17:03 --> Utf8 Class Initialized
INFO - 2018-05-15 05:17:03 --> Utf8 Class Initialized
DEBUG - 2018-05-15 05:17:03 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:17:03 --> URI Class Initialized
INFO - 2018-05-15 05:17:03 --> Output Class Initialized
INFO - 2018-05-15 05:17:03 --> Language Class Initialized
INFO - 2018-05-15 05:17:03 --> URI Class Initialized
INFO - 2018-05-15 05:17:03 --> Utf8 Class Initialized
ERROR - 2018-05-15 05:17:03 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:17:03 --> Security Class Initialized
INFO - 2018-05-15 05:17:03 --> Router Class Initialized
INFO - 2018-05-15 05:17:03 --> Router Class Initialized
INFO - 2018-05-15 05:17:03 --> URI Class Initialized
INFO - 2018-05-15 05:17:03 --> Output Class Initialized
INFO - 2018-05-15 05:17:03 --> Output Class Initialized
INFO - 2018-05-15 05:17:03 --> Router Class Initialized
DEBUG - 2018-05-15 05:17:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:17:03 --> Security Class Initialized
INFO - 2018-05-15 05:17:03 --> Config Class Initialized
INFO - 2018-05-15 05:17:03 --> Output Class Initialized
INFO - 2018-05-15 05:17:03 --> Input Class Initialized
INFO - 2018-05-15 05:17:03 --> Hooks Class Initialized
INFO - 2018-05-15 05:17:03 --> Security Class Initialized
DEBUG - 2018-05-15 05:17:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:17:03 --> Security Class Initialized
INFO - 2018-05-15 05:17:03 --> Input Class Initialized
DEBUG - 2018-05-15 05:17:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:17:03 --> Language Class Initialized
DEBUG - 2018-05-15 05:17:03 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 05:17:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:17:03 --> Language Class Initialized
ERROR - 2018-05-15 05:17:03 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:17:03 --> Utf8 Class Initialized
INFO - 2018-05-15 05:17:03 --> URI Class Initialized
INFO - 2018-05-15 05:17:03 --> Input Class Initialized
INFO - 2018-05-15 05:17:03 --> Input Class Initialized
ERROR - 2018-05-15 05:17:03 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:17:03 --> Router Class Initialized
INFO - 2018-05-15 05:17:03 --> Language Class Initialized
ERROR - 2018-05-15 05:17:03 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:17:03 --> Language Class Initialized
INFO - 2018-05-15 05:17:03 --> Output Class Initialized
INFO - 2018-05-15 05:17:03 --> Config Class Initialized
INFO - 2018-05-15 05:17:03 --> Hooks Class Initialized
ERROR - 2018-05-15 05:17:03 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:17:03 --> Security Class Initialized
DEBUG - 2018-05-15 05:17:03 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:17:03 --> Utf8 Class Initialized
INFO - 2018-05-15 05:17:04 --> URI Class Initialized
INFO - 2018-05-15 05:17:04 --> Router Class Initialized
INFO - 2018-05-15 05:17:04 --> Output Class Initialized
INFO - 2018-05-15 05:17:04 --> Security Class Initialized
DEBUG - 2018-05-15 05:17:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-15 05:17:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:17:04 --> Input Class Initialized
INFO - 2018-05-15 05:17:04 --> Language Class Initialized
ERROR - 2018-05-15 05:17:04 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:17:04 --> Input Class Initialized
INFO - 2018-05-15 05:17:04 --> Language Class Initialized
ERROR - 2018-05-15 05:17:04 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:17:04 --> Config Class Initialized
INFO - 2018-05-15 05:17:04 --> Hooks Class Initialized
DEBUG - 2018-05-15 05:17:04 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:17:04 --> Utf8 Class Initialized
INFO - 2018-05-15 05:17:04 --> URI Class Initialized
INFO - 2018-05-15 05:17:04 --> Router Class Initialized
INFO - 2018-05-15 05:17:04 --> Output Class Initialized
INFO - 2018-05-15 05:17:04 --> Security Class Initialized
DEBUG - 2018-05-15 05:17:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:17:04 --> Input Class Initialized
INFO - 2018-05-15 05:17:04 --> Language Class Initialized
ERROR - 2018-05-15 05:17:04 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:17:04 --> Config Class Initialized
INFO - 2018-05-15 05:17:04 --> Hooks Class Initialized
DEBUG - 2018-05-15 05:17:04 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:17:04 --> Utf8 Class Initialized
INFO - 2018-05-15 05:17:04 --> URI Class Initialized
INFO - 2018-05-15 05:17:05 --> Router Class Initialized
INFO - 2018-05-15 05:17:05 --> Output Class Initialized
INFO - 2018-05-15 05:17:05 --> Security Class Initialized
DEBUG - 2018-05-15 05:17:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:17:05 --> Input Class Initialized
INFO - 2018-05-15 05:17:05 --> Language Class Initialized
ERROR - 2018-05-15 05:17:05 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:17:05 --> Config Class Initialized
INFO - 2018-05-15 05:17:05 --> Hooks Class Initialized
DEBUG - 2018-05-15 05:17:05 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:17:05 --> Utf8 Class Initialized
INFO - 2018-05-15 05:17:05 --> URI Class Initialized
INFO - 2018-05-15 05:17:05 --> Router Class Initialized
INFO - 2018-05-15 05:17:05 --> Output Class Initialized
INFO - 2018-05-15 05:17:05 --> Security Class Initialized
DEBUG - 2018-05-15 05:17:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:17:05 --> Input Class Initialized
INFO - 2018-05-15 05:17:05 --> Language Class Initialized
ERROR - 2018-05-15 05:17:05 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:17:07 --> Config Class Initialized
INFO - 2018-05-15 05:17:07 --> Hooks Class Initialized
DEBUG - 2018-05-15 05:17:07 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:17:07 --> Utf8 Class Initialized
INFO - 2018-05-15 05:17:07 --> URI Class Initialized
INFO - 2018-05-15 05:17:07 --> Config Class Initialized
INFO - 2018-05-15 05:17:07 --> Config Class Initialized
INFO - 2018-05-15 05:17:07 --> Config Class Initialized
INFO - 2018-05-15 05:17:07 --> Config Class Initialized
INFO - 2018-05-15 05:17:07 --> Config Class Initialized
INFO - 2018-05-15 05:17:07 --> Hooks Class Initialized
INFO - 2018-05-15 05:17:07 --> Hooks Class Initialized
INFO - 2018-05-15 05:17:07 --> Hooks Class Initialized
INFO - 2018-05-15 05:17:07 --> Hooks Class Initialized
INFO - 2018-05-15 05:17:07 --> Hooks Class Initialized
INFO - 2018-05-15 05:17:07 --> Router Class Initialized
DEBUG - 2018-05-15 05:17:07 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 05:17:07 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 05:17:07 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:17:07 --> Output Class Initialized
DEBUG - 2018-05-15 05:17:07 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 05:17:07 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:17:07 --> Utf8 Class Initialized
INFO - 2018-05-15 05:17:07 --> URI Class Initialized
INFO - 2018-05-15 05:17:07 --> Router Class Initialized
INFO - 2018-05-15 05:17:07 --> Utf8 Class Initialized
INFO - 2018-05-15 05:17:07 --> Utf8 Class Initialized
INFO - 2018-05-15 05:17:07 --> Security Class Initialized
INFO - 2018-05-15 05:17:07 --> Utf8 Class Initialized
INFO - 2018-05-15 05:17:07 --> Utf8 Class Initialized
INFO - 2018-05-15 05:17:07 --> Output Class Initialized
INFO - 2018-05-15 05:17:07 --> URI Class Initialized
INFO - 2018-05-15 05:17:07 --> URI Class Initialized
DEBUG - 2018-05-15 05:17:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:17:07 --> URI Class Initialized
INFO - 2018-05-15 05:17:07 --> URI Class Initialized
INFO - 2018-05-15 05:17:07 --> Security Class Initialized
INFO - 2018-05-15 05:17:07 --> Router Class Initialized
INFO - 2018-05-15 05:17:07 --> Input Class Initialized
INFO - 2018-05-15 05:17:07 --> Router Class Initialized
INFO - 2018-05-15 05:17:07 --> Router Class Initialized
INFO - 2018-05-15 05:17:07 --> Router Class Initialized
DEBUG - 2018-05-15 05:17:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:17:07 --> Language Class Initialized
INFO - 2018-05-15 05:17:07 --> Output Class Initialized
INFO - 2018-05-15 05:17:07 --> Output Class Initialized
INFO - 2018-05-15 05:17:07 --> Output Class Initialized
INFO - 2018-05-15 05:17:07 --> Output Class Initialized
INFO - 2018-05-15 05:17:07 --> Input Class Initialized
ERROR - 2018-05-15 05:17:07 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:17:08 --> Language Class Initialized
ERROR - 2018-05-15 05:17:08 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:17:08 --> Security Class Initialized
INFO - 2018-05-15 05:17:08 --> Security Class Initialized
INFO - 2018-05-15 05:17:08 --> Security Class Initialized
INFO - 2018-05-15 05:17:08 --> Security Class Initialized
INFO - 2018-05-15 05:17:08 --> Config Class Initialized
INFO - 2018-05-15 05:17:08 --> Hooks Class Initialized
DEBUG - 2018-05-15 05:17:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-15 05:17:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-15 05:17:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-15 05:17:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:17:08 --> Input Class Initialized
DEBUG - 2018-05-15 05:17:08 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:17:08 --> Input Class Initialized
INFO - 2018-05-15 05:17:08 --> Language Class Initialized
ERROR - 2018-05-15 05:17:08 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:17:08 --> Utf8 Class Initialized
INFO - 2018-05-15 05:17:08 --> Input Class Initialized
INFO - 2018-05-15 05:17:08 --> Language Class Initialized
INFO - 2018-05-15 05:17:08 --> Input Class Initialized
INFO - 2018-05-15 05:17:08 --> Config Class Initialized
INFO - 2018-05-15 05:17:08 --> URI Class Initialized
INFO - 2018-05-15 05:17:08 --> Hooks Class Initialized
INFO - 2018-05-15 05:17:08 --> Language Class Initialized
ERROR - 2018-05-15 05:17:08 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:17:08 --> Language Class Initialized
INFO - 2018-05-15 05:17:08 --> Router Class Initialized
ERROR - 2018-05-15 05:17:08 --> 404 Page Not Found: /index
DEBUG - 2018-05-15 05:17:08 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:17:08 --> Output Class Initialized
INFO - 2018-05-15 05:17:08 --> Config Class Initialized
ERROR - 2018-05-15 05:17:08 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:17:08 --> Hooks Class Initialized
INFO - 2018-05-15 05:17:08 --> Config Class Initialized
INFO - 2018-05-15 05:17:08 --> Hooks Class Initialized
DEBUG - 2018-05-15 05:17:08 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:17:08 --> Utf8 Class Initialized
DEBUG - 2018-05-15 05:17:08 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:17:08 --> Security Class Initialized
INFO - 2018-05-15 05:17:08 --> Utf8 Class Initialized
INFO - 2018-05-15 05:17:08 --> URI Class Initialized
INFO - 2018-05-15 05:17:08 --> Utf8 Class Initialized
INFO - 2018-05-15 05:17:08 --> URI Class Initialized
DEBUG - 2018-05-15 05:17:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:17:08 --> URI Class Initialized
INFO - 2018-05-15 05:17:08 --> Input Class Initialized
INFO - 2018-05-15 05:17:08 --> Router Class Initialized
INFO - 2018-05-15 05:17:08 --> Router Class Initialized
INFO - 2018-05-15 05:17:08 --> Router Class Initialized
INFO - 2018-05-15 05:17:08 --> Output Class Initialized
INFO - 2018-05-15 05:17:08 --> Language Class Initialized
INFO - 2018-05-15 05:17:08 --> Output Class Initialized
INFO - 2018-05-15 05:17:08 --> Security Class Initialized
INFO - 2018-05-15 05:17:08 --> Security Class Initialized
INFO - 2018-05-15 05:17:08 --> Output Class Initialized
DEBUG - 2018-05-15 05:17:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:17:08 --> Input Class Initialized
INFO - 2018-05-15 05:17:08 --> Language Class Initialized
ERROR - 2018-05-15 05:17:08 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:17:08 --> Config Class Initialized
INFO - 2018-05-15 05:17:08 --> Security Class Initialized
DEBUG - 2018-05-15 05:17:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-05-15 05:17:08 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:17:08 --> Hooks Class Initialized
DEBUG - 2018-05-15 05:17:08 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 05:17:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:17:08 --> Utf8 Class Initialized
INFO - 2018-05-15 05:17:08 --> URI Class Initialized
INFO - 2018-05-15 05:17:08 --> Input Class Initialized
INFO - 2018-05-15 05:17:08 --> Router Class Initialized
INFO - 2018-05-15 05:17:08 --> Input Class Initialized
INFO - 2018-05-15 05:17:08 --> Language Class Initialized
INFO - 2018-05-15 05:17:08 --> Output Class Initialized
INFO - 2018-05-15 05:17:08 --> Language Class Initialized
INFO - 2018-05-15 05:17:08 --> Security Class Initialized
ERROR - 2018-05-15 05:17:08 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:17:08 --> Config Class Initialized
ERROR - 2018-05-15 05:17:08 --> 404 Page Not Found: /index
DEBUG - 2018-05-15 05:17:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:17:08 --> Hooks Class Initialized
INFO - 2018-05-15 05:17:08 --> Input Class Initialized
INFO - 2018-05-15 05:17:08 --> Config Class Initialized
INFO - 2018-05-15 05:17:08 --> Config Class Initialized
INFO - 2018-05-15 05:17:08 --> Language Class Initialized
INFO - 2018-05-15 05:17:08 --> Hooks Class Initialized
INFO - 2018-05-15 05:17:08 --> Hooks Class Initialized
DEBUG - 2018-05-15 05:17:08 --> UTF-8 Support Enabled
ERROR - 2018-05-15 05:17:08 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:17:08 --> Utf8 Class Initialized
DEBUG - 2018-05-15 05:17:08 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 05:17:08 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:17:08 --> Utf8 Class Initialized
INFO - 2018-05-15 05:17:08 --> Utf8 Class Initialized
INFO - 2018-05-15 05:17:08 --> URI Class Initialized
INFO - 2018-05-15 05:17:09 --> URI Class Initialized
INFO - 2018-05-15 05:17:09 --> Router Class Initialized
INFO - 2018-05-15 05:17:09 --> Router Class Initialized
INFO - 2018-05-15 05:17:09 --> URI Class Initialized
INFO - 2018-05-15 05:17:09 --> Output Class Initialized
INFO - 2018-05-15 05:17:09 --> Output Class Initialized
INFO - 2018-05-15 05:17:09 --> Security Class Initialized
DEBUG - 2018-05-15 05:17:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:17:09 --> Security Class Initialized
INFO - 2018-05-15 05:17:09 --> Input Class Initialized
INFO - 2018-05-15 05:17:09 --> Router Class Initialized
DEBUG - 2018-05-15 05:17:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:17:09 --> Output Class Initialized
INFO - 2018-05-15 05:17:09 --> Input Class Initialized
INFO - 2018-05-15 05:17:09 --> Security Class Initialized
INFO - 2018-05-15 05:17:09 --> Language Class Initialized
INFO - 2018-05-15 05:17:09 --> Language Class Initialized
DEBUG - 2018-05-15 05:17:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-05-15 05:17:09 --> 404 Page Not Found: /index
ERROR - 2018-05-15 05:17:09 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:17:09 --> Input Class Initialized
INFO - 2018-05-15 05:17:09 --> Language Class Initialized
ERROR - 2018-05-15 05:17:09 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:17:20 --> Config Class Initialized
INFO - 2018-05-15 05:17:20 --> Hooks Class Initialized
DEBUG - 2018-05-15 05:17:20 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:17:20 --> Utf8 Class Initialized
INFO - 2018-05-15 05:17:20 --> URI Class Initialized
INFO - 2018-05-15 05:17:20 --> Router Class Initialized
INFO - 2018-05-15 05:17:20 --> Output Class Initialized
INFO - 2018-05-15 05:17:20 --> Security Class Initialized
DEBUG - 2018-05-15 05:17:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:17:20 --> Input Class Initialized
INFO - 2018-05-15 05:17:20 --> Language Class Initialized
ERROR - 2018-05-15 05:17:20 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:17:22 --> Config Class Initialized
INFO - 2018-05-15 05:17:22 --> Hooks Class Initialized
DEBUG - 2018-05-15 05:17:22 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:17:22 --> Config Class Initialized
INFO - 2018-05-15 05:17:22 --> Config Class Initialized
INFO - 2018-05-15 05:17:22 --> Config Class Initialized
INFO - 2018-05-15 05:17:22 --> Hooks Class Initialized
INFO - 2018-05-15 05:17:22 --> Hooks Class Initialized
INFO - 2018-05-15 05:17:22 --> Hooks Class Initialized
INFO - 2018-05-15 05:17:22 --> Utf8 Class Initialized
INFO - 2018-05-15 05:17:22 --> Config Class Initialized
INFO - 2018-05-15 05:17:22 --> Config Class Initialized
INFO - 2018-05-15 05:17:22 --> Hooks Class Initialized
INFO - 2018-05-15 05:17:22 --> Hooks Class Initialized
DEBUG - 2018-05-15 05:17:22 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 05:17:22 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 05:17:22 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:17:22 --> URI Class Initialized
INFO - 2018-05-15 05:17:22 --> Utf8 Class Initialized
INFO - 2018-05-15 05:17:22 --> Utf8 Class Initialized
INFO - 2018-05-15 05:17:22 --> Utf8 Class Initialized
DEBUG - 2018-05-15 05:17:22 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:17:22 --> Router Class Initialized
DEBUG - 2018-05-15 05:17:22 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:17:23 --> URI Class Initialized
INFO - 2018-05-15 05:17:23 --> URI Class Initialized
INFO - 2018-05-15 05:17:23 --> Router Class Initialized
INFO - 2018-05-15 05:17:23 --> URI Class Initialized
INFO - 2018-05-15 05:17:23 --> Utf8 Class Initialized
INFO - 2018-05-15 05:17:23 --> Output Class Initialized
INFO - 2018-05-15 05:17:23 --> Utf8 Class Initialized
INFO - 2018-05-15 05:17:23 --> Output Class Initialized
INFO - 2018-05-15 05:17:23 --> Router Class Initialized
INFO - 2018-05-15 05:17:23 --> Security Class Initialized
INFO - 2018-05-15 05:17:23 --> URI Class Initialized
INFO - 2018-05-15 05:17:23 --> URI Class Initialized
INFO - 2018-05-15 05:17:23 --> Router Class Initialized
INFO - 2018-05-15 05:17:23 --> Security Class Initialized
INFO - 2018-05-15 05:17:23 --> Output Class Initialized
INFO - 2018-05-15 05:17:23 --> Router Class Initialized
INFO - 2018-05-15 05:17:23 --> Output Class Initialized
DEBUG - 2018-05-15 05:17:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:17:23 --> Security Class Initialized
DEBUG - 2018-05-15 05:17:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:17:23 --> Input Class Initialized
INFO - 2018-05-15 05:17:23 --> Output Class Initialized
INFO - 2018-05-15 05:17:23 --> Security Class Initialized
INFO - 2018-05-15 05:17:23 --> Router Class Initialized
DEBUG - 2018-05-15 05:17:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:17:23 --> Output Class Initialized
INFO - 2018-05-15 05:17:23 --> Security Class Initialized
DEBUG - 2018-05-15 05:17:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:17:23 --> Input Class Initialized
INFO - 2018-05-15 05:17:23 --> Input Class Initialized
INFO - 2018-05-15 05:17:23 --> Language Class Initialized
INFO - 2018-05-15 05:17:23 --> Input Class Initialized
INFO - 2018-05-15 05:17:23 --> Security Class Initialized
INFO - 2018-05-15 05:17:23 --> Language Class Initialized
ERROR - 2018-05-15 05:17:23 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:17:23 --> Language Class Initialized
DEBUG - 2018-05-15 05:17:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:17:23 --> Language Class Initialized
INFO - 2018-05-15 05:17:23 --> Input Class Initialized
DEBUG - 2018-05-15 05:17:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-05-15 05:17:23 --> 404 Page Not Found: /index
ERROR - 2018-05-15 05:17:23 --> 404 Page Not Found: /index
ERROR - 2018-05-15 05:17:23 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:17:23 --> Input Class Initialized
INFO - 2018-05-15 05:17:23 --> Config Class Initialized
INFO - 2018-05-15 05:17:23 --> Language Class Initialized
INFO - 2018-05-15 05:17:23 --> Config Class Initialized
ERROR - 2018-05-15 05:17:23 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:17:23 --> Hooks Class Initialized
INFO - 2018-05-15 05:17:23 --> Hooks Class Initialized
INFO - 2018-05-15 05:17:23 --> Language Class Initialized
DEBUG - 2018-05-15 05:17:23 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:17:23 --> Utf8 Class Initialized
INFO - 2018-05-15 05:17:23 --> Config Class Initialized
INFO - 2018-05-15 05:17:23 --> Hooks Class Initialized
INFO - 2018-05-15 05:17:23 --> URI Class Initialized
ERROR - 2018-05-15 05:17:23 --> 404 Page Not Found: /index
DEBUG - 2018-05-15 05:17:23 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:17:23 --> Utf8 Class Initialized
INFO - 2018-05-15 05:17:23 --> Router Class Initialized
DEBUG - 2018-05-15 05:17:23 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:17:23 --> Config Class Initialized
INFO - 2018-05-15 05:17:23 --> Hooks Class Initialized
INFO - 2018-05-15 05:17:23 --> URI Class Initialized
INFO - 2018-05-15 05:17:23 --> Output Class Initialized
INFO - 2018-05-15 05:17:23 --> Utf8 Class Initialized
DEBUG - 2018-05-15 05:17:23 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:17:23 --> URI Class Initialized
INFO - 2018-05-15 05:17:23 --> Security Class Initialized
INFO - 2018-05-15 05:17:23 --> Router Class Initialized
INFO - 2018-05-15 05:17:23 --> Router Class Initialized
INFO - 2018-05-15 05:17:23 --> Utf8 Class Initialized
DEBUG - 2018-05-15 05:17:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:17:23 --> Output Class Initialized
INFO - 2018-05-15 05:17:23 --> URI Class Initialized
INFO - 2018-05-15 05:17:23 --> Security Class Initialized
INFO - 2018-05-15 05:17:23 --> Input Class Initialized
INFO - 2018-05-15 05:17:23 --> Output Class Initialized
DEBUG - 2018-05-15 05:17:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:17:23 --> Security Class Initialized
INFO - 2018-05-15 05:17:23 --> Language Class Initialized
INFO - 2018-05-15 05:17:23 --> Router Class Initialized
INFO - 2018-05-15 05:17:23 --> Input Class Initialized
DEBUG - 2018-05-15 05:17:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-05-15 05:17:23 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:17:23 --> Output Class Initialized
INFO - 2018-05-15 05:17:23 --> Language Class Initialized
INFO - 2018-05-15 05:17:23 --> Security Class Initialized
INFO - 2018-05-15 05:17:23 --> Input Class Initialized
INFO - 2018-05-15 05:17:23 --> Config Class Initialized
ERROR - 2018-05-15 05:17:23 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:17:23 --> Language Class Initialized
INFO - 2018-05-15 05:17:23 --> Hooks Class Initialized
INFO - 2018-05-15 05:17:23 --> Config Class Initialized
DEBUG - 2018-05-15 05:17:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:17:23 --> Hooks Class Initialized
DEBUG - 2018-05-15 05:17:23 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:17:23 --> Input Class Initialized
ERROR - 2018-05-15 05:17:23 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:17:23 --> Utf8 Class Initialized
DEBUG - 2018-05-15 05:17:23 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:17:23 --> Utf8 Class Initialized
INFO - 2018-05-15 05:17:23 --> URI Class Initialized
INFO - 2018-05-15 05:17:23 --> Config Class Initialized
INFO - 2018-05-15 05:17:23 --> Language Class Initialized
INFO - 2018-05-15 05:17:23 --> URI Class Initialized
INFO - 2018-05-15 05:17:23 --> Hooks Class Initialized
ERROR - 2018-05-15 05:17:23 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:17:23 --> Router Class Initialized
INFO - 2018-05-15 05:17:23 --> Router Class Initialized
DEBUG - 2018-05-15 05:17:23 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:17:23 --> Config Class Initialized
INFO - 2018-05-15 05:17:23 --> Output Class Initialized
INFO - 2018-05-15 05:17:23 --> Utf8 Class Initialized
INFO - 2018-05-15 05:17:23 --> Hooks Class Initialized
INFO - 2018-05-15 05:17:23 --> Output Class Initialized
INFO - 2018-05-15 05:17:23 --> Security Class Initialized
DEBUG - 2018-05-15 05:17:23 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:17:23 --> URI Class Initialized
INFO - 2018-05-15 05:17:23 --> Security Class Initialized
DEBUG - 2018-05-15 05:17:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:17:23 --> Utf8 Class Initialized
INFO - 2018-05-15 05:17:23 --> URI Class Initialized
INFO - 2018-05-15 05:17:23 --> Input Class Initialized
INFO - 2018-05-15 05:17:23 --> Router Class Initialized
DEBUG - 2018-05-15 05:17:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:17:24 --> Output Class Initialized
INFO - 2018-05-15 05:17:24 --> Security Class Initialized
INFO - 2018-05-15 05:17:24 --> Input Class Initialized
INFO - 2018-05-15 05:17:24 --> Router Class Initialized
INFO - 2018-05-15 05:17:24 --> Language Class Initialized
ERROR - 2018-05-15 05:17:24 --> 404 Page Not Found: /index
DEBUG - 2018-05-15 05:17:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:17:24 --> Language Class Initialized
INFO - 2018-05-15 05:17:24 --> Output Class Initialized
ERROR - 2018-05-15 05:17:24 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:17:24 --> Input Class Initialized
INFO - 2018-05-15 05:17:24 --> Security Class Initialized
DEBUG - 2018-05-15 05:17:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:17:24 --> Input Class Initialized
INFO - 2018-05-15 05:17:24 --> Language Class Initialized
ERROR - 2018-05-15 05:17:24 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:17:24 --> Language Class Initialized
ERROR - 2018-05-15 05:17:24 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:17:24 --> Config Class Initialized
INFO - 2018-05-15 05:17:24 --> Hooks Class Initialized
DEBUG - 2018-05-15 05:17:24 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:17:24 --> Utf8 Class Initialized
INFO - 2018-05-15 05:17:24 --> Config Class Initialized
INFO - 2018-05-15 05:17:24 --> Config Class Initialized
INFO - 2018-05-15 05:17:24 --> Config Class Initialized
INFO - 2018-05-15 05:17:24 --> Config Class Initialized
INFO - 2018-05-15 05:17:24 --> Config Class Initialized
INFO - 2018-05-15 05:17:24 --> Hooks Class Initialized
INFO - 2018-05-15 05:17:24 --> Hooks Class Initialized
INFO - 2018-05-15 05:17:24 --> Hooks Class Initialized
INFO - 2018-05-15 05:17:24 --> Hooks Class Initialized
INFO - 2018-05-15 05:17:24 --> Hooks Class Initialized
INFO - 2018-05-15 05:17:24 --> URI Class Initialized
DEBUG - 2018-05-15 05:17:24 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 05:17:24 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 05:17:24 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 05:17:24 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:17:24 --> Router Class Initialized
INFO - 2018-05-15 05:17:24 --> Utf8 Class Initialized
DEBUG - 2018-05-15 05:17:24 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:17:24 --> Output Class Initialized
INFO - 2018-05-15 05:17:24 --> Utf8 Class Initialized
INFO - 2018-05-15 05:17:24 --> Security Class Initialized
INFO - 2018-05-15 05:17:24 --> Utf8 Class Initialized
INFO - 2018-05-15 05:17:24 --> URI Class Initialized
INFO - 2018-05-15 05:17:24 --> Utf8 Class Initialized
INFO - 2018-05-15 05:17:24 --> Utf8 Class Initialized
INFO - 2018-05-15 05:17:24 --> URI Class Initialized
INFO - 2018-05-15 05:17:24 --> URI Class Initialized
INFO - 2018-05-15 05:17:24 --> URI Class Initialized
INFO - 2018-05-15 05:17:24 --> Router Class Initialized
INFO - 2018-05-15 05:17:24 --> URI Class Initialized
DEBUG - 2018-05-15 05:17:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:17:24 --> Router Class Initialized
INFO - 2018-05-15 05:17:24 --> Router Class Initialized
INFO - 2018-05-15 05:17:24 --> Output Class Initialized
INFO - 2018-05-15 05:17:24 --> Router Class Initialized
INFO - 2018-05-15 05:17:24 --> Input Class Initialized
INFO - 2018-05-15 05:17:24 --> Router Class Initialized
INFO - 2018-05-15 05:17:24 --> Output Class Initialized
INFO - 2018-05-15 05:17:24 --> Output Class Initialized
INFO - 2018-05-15 05:17:24 --> Security Class Initialized
INFO - 2018-05-15 05:17:24 --> Language Class Initialized
INFO - 2018-05-15 05:17:24 --> Output Class Initialized
INFO - 2018-05-15 05:17:24 --> Security Class Initialized
INFO - 2018-05-15 05:17:24 --> Output Class Initialized
INFO - 2018-05-15 05:17:24 --> Security Class Initialized
ERROR - 2018-05-15 05:17:24 --> 404 Page Not Found: /index
DEBUG - 2018-05-15 05:17:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:17:24 --> Security Class Initialized
DEBUG - 2018-05-15 05:17:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:17:24 --> Security Class Initialized
DEBUG - 2018-05-15 05:17:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:17:24 --> Input Class Initialized
INFO - 2018-05-15 05:17:24 --> Input Class Initialized
DEBUG - 2018-05-15 05:17:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:17:24 --> Input Class Initialized
DEBUG - 2018-05-15 05:17:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:17:24 --> Language Class Initialized
INFO - 2018-05-15 05:17:24 --> Language Class Initialized
INFO - 2018-05-15 05:17:24 --> Input Class Initialized
INFO - 2018-05-15 05:17:24 --> Input Class Initialized
INFO - 2018-05-15 05:17:24 --> Language Class Initialized
ERROR - 2018-05-15 05:17:25 --> 404 Page Not Found: /index
ERROR - 2018-05-15 05:17:25 --> 404 Page Not Found: /index
ERROR - 2018-05-15 05:17:25 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:17:25 --> Config Class Initialized
INFO - 2018-05-15 05:17:25 --> Language Class Initialized
INFO - 2018-05-15 05:17:25 --> Config Class Initialized
INFO - 2018-05-15 05:17:25 --> Hooks Class Initialized
INFO - 2018-05-15 05:17:25 --> Hooks Class Initialized
INFO - 2018-05-15 05:17:25 --> Config Class Initialized
ERROR - 2018-05-15 05:17:25 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:17:25 --> Language Class Initialized
DEBUG - 2018-05-15 05:17:25 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:17:25 --> Utf8 Class Initialized
INFO - 2018-05-15 05:17:25 --> URI Class Initialized
INFO - 2018-05-15 05:17:25 --> Router Class Initialized
INFO - 2018-05-15 05:17:25 --> Config Class Initialized
DEBUG - 2018-05-15 05:17:25 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:17:25 --> Hooks Class Initialized
ERROR - 2018-05-15 05:17:25 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:17:25 --> Hooks Class Initialized
INFO - 2018-05-15 05:17:25 --> Output Class Initialized
DEBUG - 2018-05-15 05:17:25 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:17:25 --> Utf8 Class Initialized
DEBUG - 2018-05-15 05:17:25 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:17:25 --> URI Class Initialized
INFO - 2018-05-15 05:17:25 --> Utf8 Class Initialized
INFO - 2018-05-15 05:17:25 --> Security Class Initialized
INFO - 2018-05-15 05:17:25 --> Utf8 Class Initialized
INFO - 2018-05-15 05:17:25 --> Config Class Initialized
INFO - 2018-05-15 05:17:25 --> Config Class Initialized
INFO - 2018-05-15 05:17:25 --> Config Class Initialized
INFO - 2018-05-15 05:17:25 --> Hooks Class Initialized
INFO - 2018-05-15 05:17:25 --> Hooks Class Initialized
INFO - 2018-05-15 05:17:25 --> Router Class Initialized
INFO - 2018-05-15 05:17:25 --> Config Class Initialized
INFO - 2018-05-15 05:17:25 --> Config Class Initialized
INFO - 2018-05-15 05:17:25 --> URI Class Initialized
DEBUG - 2018-05-15 05:17:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:17:25 --> URI Class Initialized
INFO - 2018-05-15 05:17:25 --> Hooks Class Initialized
DEBUG - 2018-05-15 05:17:25 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:17:26 --> Utf8 Class Initialized
INFO - 2018-05-15 05:17:26 --> Output Class Initialized
INFO - 2018-05-15 05:17:26 --> Hooks Class Initialized
DEBUG - 2018-05-15 05:17:26 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:17:26 --> Hooks Class Initialized
INFO - 2018-05-15 05:17:26 --> Router Class Initialized
INFO - 2018-05-15 05:17:26 --> Input Class Initialized
INFO - 2018-05-15 05:17:26 --> Router Class Initialized
DEBUG - 2018-05-15 05:17:26 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:17:26 --> URI Class Initialized
INFO - 2018-05-15 05:17:26 --> Utf8 Class Initialized
DEBUG - 2018-05-15 05:17:26 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 05:17:26 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:17:26 --> Language Class Initialized
INFO - 2018-05-15 05:17:26 --> Output Class Initialized
INFO - 2018-05-15 05:17:26 --> Utf8 Class Initialized
INFO - 2018-05-15 05:17:26 --> Output Class Initialized
INFO - 2018-05-15 05:17:26 --> Security Class Initialized
INFO - 2018-05-15 05:17:26 --> Router Class Initialized
INFO - 2018-05-15 05:17:26 --> Utf8 Class Initialized
INFO - 2018-05-15 05:17:26 --> Output Class Initialized
DEBUG - 2018-05-15 05:17:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-05-15 05:17:26 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:17:26 --> Security Class Initialized
INFO - 2018-05-15 05:17:26 --> URI Class Initialized
INFO - 2018-05-15 05:17:26 --> Security Class Initialized
INFO - 2018-05-15 05:17:26 --> URI Class Initialized
INFO - 2018-05-15 05:17:26 --> Utf8 Class Initialized
INFO - 2018-05-15 05:17:26 --> Security Class Initialized
INFO - 2018-05-15 05:17:26 --> URI Class Initialized
DEBUG - 2018-05-15 05:17:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:17:26 --> Router Class Initialized
INFO - 2018-05-15 05:17:26 --> Router Class Initialized
INFO - 2018-05-15 05:17:26 --> Input Class Initialized
INFO - 2018-05-15 05:17:26 --> URI Class Initialized
DEBUG - 2018-05-15 05:17:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:17:26 --> Input Class Initialized
INFO - 2018-05-15 05:17:26 --> Router Class Initialized
INFO - 2018-05-15 05:17:26 --> Language Class Initialized
INFO - 2018-05-15 05:17:26 --> Language Class Initialized
INFO - 2018-05-15 05:17:26 --> Output Class Initialized
INFO - 2018-05-15 05:17:26 --> Output Class Initialized
DEBUG - 2018-05-15 05:17:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:17:26 --> Input Class Initialized
INFO - 2018-05-15 05:17:26 --> Router Class Initialized
INFO - 2018-05-15 05:17:26 --> Output Class Initialized
INFO - 2018-05-15 05:17:26 --> Input Class Initialized
INFO - 2018-05-15 05:17:26 --> Language Class Initialized
INFO - 2018-05-15 05:17:26 --> Security Class Initialized
INFO - 2018-05-15 05:17:26 --> Security Class Initialized
INFO - 2018-05-15 05:17:26 --> Output Class Initialized
ERROR - 2018-05-15 05:17:26 --> 404 Page Not Found: /index
ERROR - 2018-05-15 05:17:26 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:17:26 --> Security Class Initialized
DEBUG - 2018-05-15 05:17:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:17:26 --> Security Class Initialized
DEBUG - 2018-05-15 05:17:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-15 05:17:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-05-15 05:17:26 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:17:26 --> Language Class Initialized
INFO - 2018-05-15 05:17:26 --> Input Class Initialized
ERROR - 2018-05-15 05:17:26 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:17:26 --> Input Class Initialized
INFO - 2018-05-15 05:17:26 --> Config Class Initialized
INFO - 2018-05-15 05:17:26 --> Input Class Initialized
DEBUG - 2018-05-15 05:17:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:17:26 --> Language Class Initialized
INFO - 2018-05-15 05:17:26 --> Hooks Class Initialized
INFO - 2018-05-15 05:17:26 --> Config Class Initialized
INFO - 2018-05-15 05:17:26 --> Config Class Initialized
DEBUG - 2018-05-15 05:17:26 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:17:26 --> Config Class Initialized
INFO - 2018-05-15 05:17:26 --> Hooks Class Initialized
INFO - 2018-05-15 05:17:26 --> Utf8 Class Initialized
ERROR - 2018-05-15 05:17:26 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:17:26 --> Input Class Initialized
INFO - 2018-05-15 05:17:26 --> Language Class Initialized
INFO - 2018-05-15 05:17:26 --> Language Class Initialized
INFO - 2018-05-15 05:17:26 --> Hooks Class Initialized
INFO - 2018-05-15 05:17:26 --> Hooks Class Initialized
DEBUG - 2018-05-15 05:17:26 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:17:26 --> Utf8 Class Initialized
INFO - 2018-05-15 05:17:26 --> Config Class Initialized
INFO - 2018-05-15 05:17:26 --> Config Class Initialized
INFO - 2018-05-15 05:17:26 --> Config Class Initialized
INFO - 2018-05-15 05:17:26 --> Hooks Class Initialized
INFO - 2018-05-15 05:17:26 --> URI Class Initialized
INFO - 2018-05-15 05:17:26 --> Hooks Class Initialized
INFO - 2018-05-15 05:17:26 --> Hooks Class Initialized
INFO - 2018-05-15 05:17:26 --> Config Class Initialized
DEBUG - 2018-05-15 05:17:26 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 05:17:26 --> UTF-8 Support Enabled
ERROR - 2018-05-15 05:17:26 --> 404 Page Not Found: /index
ERROR - 2018-05-15 05:17:26 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:17:26 --> Language Class Initialized
INFO - 2018-05-15 05:17:26 --> URI Class Initialized
INFO - 2018-05-15 05:17:26 --> Hooks Class Initialized
DEBUG - 2018-05-15 05:17:26 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:17:26 --> Config Class Initialized
INFO - 2018-05-15 05:17:26 --> Router Class Initialized
INFO - 2018-05-15 05:17:26 --> Router Class Initialized
DEBUG - 2018-05-15 05:17:26 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 05:17:26 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:17:26 --> Utf8 Class Initialized
INFO - 2018-05-15 05:17:26 --> Utf8 Class Initialized
ERROR - 2018-05-15 05:17:26 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:17:26 --> Hooks Class Initialized
INFO - 2018-05-15 05:17:26 --> Utf8 Class Initialized
INFO - 2018-05-15 05:17:26 --> Output Class Initialized
INFO - 2018-05-15 05:17:26 --> Utf8 Class Initialized
INFO - 2018-05-15 05:17:26 --> Utf8 Class Initialized
INFO - 2018-05-15 05:17:26 --> Output Class Initialized
INFO - 2018-05-15 05:17:26 --> URI Class Initialized
INFO - 2018-05-15 05:17:26 --> URI Class Initialized
DEBUG - 2018-05-15 05:17:26 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:17:26 --> URI Class Initialized
INFO - 2018-05-15 05:17:26 --> Security Class Initialized
INFO - 2018-05-15 05:17:26 --> URI Class Initialized
INFO - 2018-05-15 05:17:26 --> Security Class Initialized
INFO - 2018-05-15 05:17:26 --> URI Class Initialized
INFO - 2018-05-15 05:17:26 --> Router Class Initialized
INFO - 2018-05-15 05:17:26 --> Utf8 Class Initialized
INFO - 2018-05-15 05:17:26 --> Router Class Initialized
DEBUG - 2018-05-15 05:17:26 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:17:26 --> Router Class Initialized
INFO - 2018-05-15 05:17:27 --> Utf8 Class Initialized
INFO - 2018-05-15 05:17:27 --> URI Class Initialized
INFO - 2018-05-15 05:17:27 --> Output Class Initialized
INFO - 2018-05-15 05:17:27 --> Output Class Initialized
INFO - 2018-05-15 05:17:27 --> Router Class Initialized
DEBUG - 2018-05-15 05:17:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-15 05:17:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:17:27 --> Router Class Initialized
INFO - 2018-05-15 05:17:27 --> Output Class Initialized
INFO - 2018-05-15 05:17:27 --> Security Class Initialized
INFO - 2018-05-15 05:17:27 --> Security Class Initialized
INFO - 2018-05-15 05:17:27 --> Security Class Initialized
INFO - 2018-05-15 05:17:27 --> Input Class Initialized
INFO - 2018-05-15 05:17:27 --> Input Class Initialized
INFO - 2018-05-15 05:17:27 --> Output Class Initialized
INFO - 2018-05-15 05:17:27 --> URI Class Initialized
INFO - 2018-05-15 05:17:27 --> Output Class Initialized
INFO - 2018-05-15 05:17:27 --> Router Class Initialized
INFO - 2018-05-15 05:17:27 --> Security Class Initialized
INFO - 2018-05-15 05:17:27 --> Language Class Initialized
DEBUG - 2018-05-15 05:17:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-15 05:17:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:17:27 --> Language Class Initialized
INFO - 2018-05-15 05:17:27 --> Security Class Initialized
INFO - 2018-05-15 05:17:27 --> Router Class Initialized
DEBUG - 2018-05-15 05:17:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:17:27 --> Output Class Initialized
INFO - 2018-05-15 05:17:27 --> Input Class Initialized
DEBUG - 2018-05-15 05:17:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:17:27 --> Input Class Initialized
INFO - 2018-05-15 05:17:27 --> Output Class Initialized
DEBUG - 2018-05-15 05:17:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:17:27 --> Input Class Initialized
ERROR - 2018-05-15 05:17:27 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:17:27 --> Security Class Initialized
ERROR - 2018-05-15 05:17:27 --> 404 Page Not Found: /index
DEBUG - 2018-05-15 05:17:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:17:27 --> Language Class Initialized
INFO - 2018-05-15 05:17:27 --> Security Class Initialized
INFO - 2018-05-15 05:17:27 --> Input Class Initialized
INFO - 2018-05-15 05:17:27 --> Language Class Initialized
INFO - 2018-05-15 05:17:27 --> Language Class Initialized
INFO - 2018-05-15 05:17:27 --> Input Class Initialized
ERROR - 2018-05-15 05:17:27 --> 404 Page Not Found: /index
DEBUG - 2018-05-15 05:17:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:17:27 --> Language Class Initialized
ERROR - 2018-05-15 05:17:27 --> 404 Page Not Found: /index
ERROR - 2018-05-15 05:17:27 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:17:27 --> Language Class Initialized
INFO - 2018-05-15 05:17:27 --> Input Class Initialized
INFO - 2018-05-15 05:17:27 --> Input Class Initialized
ERROR - 2018-05-15 05:17:27 --> 404 Page Not Found: /index
ERROR - 2018-05-15 05:17:27 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:17:27 --> Language Class Initialized
INFO - 2018-05-15 05:17:27 --> Language Class Initialized
INFO - 2018-05-15 05:17:27 --> Config Class Initialized
ERROR - 2018-05-15 05:17:27 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:17:27 --> Config Class Initialized
INFO - 2018-05-15 05:17:27 --> Hooks Class Initialized
INFO - 2018-05-15 05:17:27 --> Hooks Class Initialized
ERROR - 2018-05-15 05:17:27 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:17:27 --> Config Class Initialized
INFO - 2018-05-15 05:17:27 --> Hooks Class Initialized
DEBUG - 2018-05-15 05:17:27 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 05:17:27 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:17:27 --> Config Class Initialized
INFO - 2018-05-15 05:17:27 --> Hooks Class Initialized
DEBUG - 2018-05-15 05:17:27 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:17:27 --> Utf8 Class Initialized
INFO - 2018-05-15 05:17:27 --> Utf8 Class Initialized
DEBUG - 2018-05-15 05:17:27 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:17:27 --> Utf8 Class Initialized
INFO - 2018-05-15 05:17:27 --> URI Class Initialized
INFO - 2018-05-15 05:17:27 --> URI Class Initialized
INFO - 2018-05-15 05:17:27 --> Utf8 Class Initialized
INFO - 2018-05-15 05:17:27 --> URI Class Initialized
INFO - 2018-05-15 05:17:27 --> Router Class Initialized
INFO - 2018-05-15 05:17:27 --> URI Class Initialized
INFO - 2018-05-15 05:17:27 --> Router Class Initialized
INFO - 2018-05-15 05:17:27 --> Router Class Initialized
INFO - 2018-05-15 05:17:27 --> Output Class Initialized
INFO - 2018-05-15 05:17:27 --> Output Class Initialized
INFO - 2018-05-15 05:17:27 --> Router Class Initialized
INFO - 2018-05-15 05:17:27 --> Output Class Initialized
INFO - 2018-05-15 05:17:27 --> Output Class Initialized
INFO - 2018-05-15 05:17:27 --> Security Class Initialized
INFO - 2018-05-15 05:17:27 --> Security Class Initialized
INFO - 2018-05-15 05:17:27 --> Security Class Initialized
DEBUG - 2018-05-15 05:17:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:17:27 --> Security Class Initialized
DEBUG - 2018-05-15 05:17:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-15 05:17:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-15 05:17:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:17:27 --> Input Class Initialized
INFO - 2018-05-15 05:17:27 --> Input Class Initialized
INFO - 2018-05-15 05:17:27 --> Input Class Initialized
INFO - 2018-05-15 05:17:27 --> Input Class Initialized
INFO - 2018-05-15 05:17:27 --> Language Class Initialized
INFO - 2018-05-15 05:17:27 --> Language Class Initialized
INFO - 2018-05-15 05:17:27 --> Language Class Initialized
ERROR - 2018-05-15 05:17:27 --> 404 Page Not Found: /index
ERROR - 2018-05-15 05:17:27 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:17:27 --> Language Class Initialized
ERROR - 2018-05-15 05:17:27 --> 404 Page Not Found: /index
ERROR - 2018-05-15 05:17:27 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:17:27 --> Config Class Initialized
INFO - 2018-05-15 05:17:27 --> Config Class Initialized
INFO - 2018-05-15 05:17:27 --> Config Class Initialized
INFO - 2018-05-15 05:17:27 --> Hooks Class Initialized
INFO - 2018-05-15 05:17:27 --> Hooks Class Initialized
INFO - 2018-05-15 05:17:27 --> Hooks Class Initialized
INFO - 2018-05-15 05:17:27 --> Config Class Initialized
INFO - 2018-05-15 05:17:27 --> Hooks Class Initialized
DEBUG - 2018-05-15 05:17:27 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 05:17:27 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:17:27 --> Utf8 Class Initialized
DEBUG - 2018-05-15 05:17:27 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 05:17:27 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:17:27 --> URI Class Initialized
INFO - 2018-05-15 05:17:27 --> Utf8 Class Initialized
INFO - 2018-05-15 05:17:27 --> Utf8 Class Initialized
INFO - 2018-05-15 05:17:27 --> Utf8 Class Initialized
INFO - 2018-05-15 05:17:27 --> URI Class Initialized
INFO - 2018-05-15 05:17:27 --> URI Class Initialized
INFO - 2018-05-15 05:17:27 --> Router Class Initialized
INFO - 2018-05-15 05:17:27 --> URI Class Initialized
INFO - 2018-05-15 05:17:27 --> Output Class Initialized
INFO - 2018-05-15 05:17:27 --> Router Class Initialized
INFO - 2018-05-15 05:17:27 --> Router Class Initialized
INFO - 2018-05-15 05:17:27 --> Router Class Initialized
INFO - 2018-05-15 05:17:27 --> Output Class Initialized
INFO - 2018-05-15 05:17:27 --> Output Class Initialized
INFO - 2018-05-15 05:17:27 --> Output Class Initialized
INFO - 2018-05-15 05:17:27 --> Security Class Initialized
INFO - 2018-05-15 05:17:27 --> Security Class Initialized
DEBUG - 2018-05-15 05:17:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:17:27 --> Security Class Initialized
INFO - 2018-05-15 05:17:27 --> Security Class Initialized
DEBUG - 2018-05-15 05:17:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-15 05:17:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-15 05:17:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:17:27 --> Input Class Initialized
INFO - 2018-05-15 05:17:27 --> Input Class Initialized
INFO - 2018-05-15 05:17:27 --> Language Class Initialized
INFO - 2018-05-15 05:17:27 --> Input Class Initialized
INFO - 2018-05-15 05:17:27 --> Language Class Initialized
INFO - 2018-05-15 05:17:27 --> Input Class Initialized
INFO - 2018-05-15 05:17:27 --> Language Class Initialized
ERROR - 2018-05-15 05:17:27 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:17:27 --> Language Class Initialized
ERROR - 2018-05-15 05:17:27 --> 404 Page Not Found: /index
ERROR - 2018-05-15 05:17:28 --> 404 Page Not Found: /index
ERROR - 2018-05-15 05:17:28 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:17:31 --> Config Class Initialized
INFO - 2018-05-15 05:17:31 --> Hooks Class Initialized
DEBUG - 2018-05-15 05:17:31 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:17:31 --> Config Class Initialized
INFO - 2018-05-15 05:17:31 --> Hooks Class Initialized
INFO - 2018-05-15 05:17:31 --> Utf8 Class Initialized
DEBUG - 2018-05-15 05:17:31 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:17:31 --> Utf8 Class Initialized
INFO - 2018-05-15 05:17:31 --> URI Class Initialized
INFO - 2018-05-15 05:17:31 --> Config Class Initialized
INFO - 2018-05-15 05:17:31 --> Config Class Initialized
INFO - 2018-05-15 05:17:31 --> Config Class Initialized
INFO - 2018-05-15 05:17:31 --> Config Class Initialized
INFO - 2018-05-15 05:17:31 --> Hooks Class Initialized
INFO - 2018-05-15 05:17:31 --> Hooks Class Initialized
INFO - 2018-05-15 05:17:31 --> Hooks Class Initialized
INFO - 2018-05-15 05:17:31 --> Hooks Class Initialized
INFO - 2018-05-15 05:17:31 --> Router Class Initialized
INFO - 2018-05-15 05:17:31 --> URI Class Initialized
DEBUG - 2018-05-15 05:17:32 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 05:17:32 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 05:17:32 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 05:17:32 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:17:32 --> Output Class Initialized
INFO - 2018-05-15 05:17:32 --> Router Class Initialized
INFO - 2018-05-15 05:17:32 --> Utf8 Class Initialized
INFO - 2018-05-15 05:17:32 --> Utf8 Class Initialized
INFO - 2018-05-15 05:17:32 --> Output Class Initialized
INFO - 2018-05-15 05:17:32 --> Security Class Initialized
INFO - 2018-05-15 05:17:32 --> Utf8 Class Initialized
INFO - 2018-05-15 05:17:32 --> Utf8 Class Initialized
INFO - 2018-05-15 05:17:32 --> URI Class Initialized
INFO - 2018-05-15 05:17:32 --> Security Class Initialized
DEBUG - 2018-05-15 05:17:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:17:32 --> URI Class Initialized
INFO - 2018-05-15 05:17:32 --> URI Class Initialized
INFO - 2018-05-15 05:17:32 --> URI Class Initialized
DEBUG - 2018-05-15 05:17:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:17:32 --> Input Class Initialized
INFO - 2018-05-15 05:17:32 --> Router Class Initialized
INFO - 2018-05-15 05:17:32 --> Router Class Initialized
INFO - 2018-05-15 05:17:32 --> Router Class Initialized
INFO - 2018-05-15 05:17:32 --> Router Class Initialized
INFO - 2018-05-15 05:17:32 --> Input Class Initialized
INFO - 2018-05-15 05:17:32 --> Language Class Initialized
ERROR - 2018-05-15 05:17:32 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:17:32 --> Output Class Initialized
INFO - 2018-05-15 05:17:32 --> Output Class Initialized
INFO - 2018-05-15 05:17:32 --> Output Class Initialized
INFO - 2018-05-15 05:17:32 --> Output Class Initialized
INFO - 2018-05-15 05:17:32 --> Language Class Initialized
INFO - 2018-05-15 05:17:32 --> Config Class Initialized
INFO - 2018-05-15 05:17:32 --> Hooks Class Initialized
INFO - 2018-05-15 05:17:32 --> Security Class Initialized
ERROR - 2018-05-15 05:17:32 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:17:32 --> Security Class Initialized
INFO - 2018-05-15 05:17:32 --> Security Class Initialized
INFO - 2018-05-15 05:17:32 --> Security Class Initialized
DEBUG - 2018-05-15 05:17:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-15 05:17:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-15 05:17:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-15 05:17:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-15 05:17:32 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:17:32 --> Utf8 Class Initialized
INFO - 2018-05-15 05:17:32 --> Input Class Initialized
INFO - 2018-05-15 05:17:32 --> Input Class Initialized
INFO - 2018-05-15 05:17:32 --> Input Class Initialized
INFO - 2018-05-15 05:17:32 --> Input Class Initialized
INFO - 2018-05-15 05:17:32 --> URI Class Initialized
INFO - 2018-05-15 05:17:32 --> Language Class Initialized
INFO - 2018-05-15 05:17:32 --> Language Class Initialized
INFO - 2018-05-15 05:17:32 --> Language Class Initialized
INFO - 2018-05-15 05:17:32 --> Language Class Initialized
ERROR - 2018-05-15 05:17:32 --> 404 Page Not Found: /index
ERROR - 2018-05-15 05:17:32 --> 404 Page Not Found: /index
ERROR - 2018-05-15 05:17:32 --> 404 Page Not Found: /index
ERROR - 2018-05-15 05:17:32 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:17:32 --> Router Class Initialized
INFO - 2018-05-15 05:17:32 --> Config Class Initialized
INFO - 2018-05-15 05:17:32 --> Config Class Initialized
INFO - 2018-05-15 05:17:32 --> Output Class Initialized
INFO - 2018-05-15 05:17:32 --> Config Class Initialized
INFO - 2018-05-15 05:17:32 --> Hooks Class Initialized
INFO - 2018-05-15 05:17:32 --> Hooks Class Initialized
INFO - 2018-05-15 05:17:32 --> Hooks Class Initialized
INFO - 2018-05-15 05:17:32 --> Security Class Initialized
DEBUG - 2018-05-15 05:17:32 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 05:17:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-15 05:17:32 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 05:17:32 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:17:32 --> Utf8 Class Initialized
INFO - 2018-05-15 05:17:32 --> Utf8 Class Initialized
INFO - 2018-05-15 05:17:32 --> Utf8 Class Initialized
INFO - 2018-05-15 05:17:32 --> URI Class Initialized
INFO - 2018-05-15 05:17:32 --> Input Class Initialized
INFO - 2018-05-15 05:17:32 --> URI Class Initialized
INFO - 2018-05-15 05:17:32 --> Language Class Initialized
INFO - 2018-05-15 05:17:32 --> URI Class Initialized
INFO - 2018-05-15 05:17:32 --> Router Class Initialized
ERROR - 2018-05-15 05:17:32 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:17:32 --> Router Class Initialized
INFO - 2018-05-15 05:17:32 --> Output Class Initialized
INFO - 2018-05-15 05:17:32 --> Router Class Initialized
INFO - 2018-05-15 05:17:32 --> Output Class Initialized
INFO - 2018-05-15 05:17:32 --> Config Class Initialized
INFO - 2018-05-15 05:17:32 --> Security Class Initialized
INFO - 2018-05-15 05:17:32 --> Output Class Initialized
INFO - 2018-05-15 05:17:32 --> Hooks Class Initialized
INFO - 2018-05-15 05:17:32 --> Security Class Initialized
DEBUG - 2018-05-15 05:17:32 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:17:32 --> Security Class Initialized
DEBUG - 2018-05-15 05:17:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-15 05:17:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-15 05:17:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:17:32 --> Utf8 Class Initialized
INFO - 2018-05-15 05:17:32 --> Input Class Initialized
INFO - 2018-05-15 05:17:32 --> Input Class Initialized
INFO - 2018-05-15 05:17:32 --> Input Class Initialized
INFO - 2018-05-15 05:17:32 --> Language Class Initialized
INFO - 2018-05-15 05:17:32 --> Language Class Initialized
INFO - 2018-05-15 05:17:32 --> Language Class Initialized
INFO - 2018-05-15 05:17:32 --> URI Class Initialized
ERROR - 2018-05-15 05:17:32 --> 404 Page Not Found: /index
ERROR - 2018-05-15 05:17:32 --> 404 Page Not Found: /index
ERROR - 2018-05-15 05:17:32 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:17:32 --> Router Class Initialized
INFO - 2018-05-15 05:17:32 --> Config Class Initialized
INFO - 2018-05-15 05:17:32 --> Output Class Initialized
INFO - 2018-05-15 05:17:32 --> Config Class Initialized
INFO - 2018-05-15 05:17:32 --> Config Class Initialized
INFO - 2018-05-15 05:17:32 --> Hooks Class Initialized
INFO - 2018-05-15 05:17:32 --> Hooks Class Initialized
INFO - 2018-05-15 05:17:32 --> Hooks Class Initialized
INFO - 2018-05-15 05:17:32 --> Security Class Initialized
DEBUG - 2018-05-15 05:17:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-15 05:17:32 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 05:17:32 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 05:17:32 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:17:32 --> Utf8 Class Initialized
INFO - 2018-05-15 05:17:32 --> Utf8 Class Initialized
INFO - 2018-05-15 05:17:32 --> Input Class Initialized
INFO - 2018-05-15 05:17:32 --> Utf8 Class Initialized
INFO - 2018-05-15 05:17:32 --> URI Class Initialized
INFO - 2018-05-15 05:17:32 --> URI Class Initialized
INFO - 2018-05-15 05:17:32 --> Language Class Initialized
INFO - 2018-05-15 05:17:32 --> URI Class Initialized
ERROR - 2018-05-15 05:17:33 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:17:33 --> Router Class Initialized
INFO - 2018-05-15 05:17:33 --> Router Class Initialized
INFO - 2018-05-15 05:17:33 --> Router Class Initialized
INFO - 2018-05-15 05:17:33 --> Config Class Initialized
INFO - 2018-05-15 05:17:33 --> Output Class Initialized
INFO - 2018-05-15 05:17:33 --> Output Class Initialized
INFO - 2018-05-15 05:17:33 --> Output Class Initialized
INFO - 2018-05-15 05:17:33 --> Security Class Initialized
INFO - 2018-05-15 05:17:33 --> Hooks Class Initialized
INFO - 2018-05-15 05:17:33 --> Security Class Initialized
INFO - 2018-05-15 05:17:33 --> Security Class Initialized
DEBUG - 2018-05-15 05:17:33 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 05:17:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-15 05:17:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-15 05:17:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:17:33 --> Utf8 Class Initialized
INFO - 2018-05-15 05:17:33 --> URI Class Initialized
INFO - 2018-05-15 05:17:33 --> Input Class Initialized
INFO - 2018-05-15 05:17:33 --> Input Class Initialized
INFO - 2018-05-15 05:17:33 --> Input Class Initialized
INFO - 2018-05-15 05:17:33 --> Language Class Initialized
INFO - 2018-05-15 05:17:33 --> Language Class Initialized
INFO - 2018-05-15 05:17:33 --> Language Class Initialized
INFO - 2018-05-15 05:17:33 --> Router Class Initialized
ERROR - 2018-05-15 05:17:33 --> 404 Page Not Found: /index
ERROR - 2018-05-15 05:17:33 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:17:33 --> Output Class Initialized
ERROR - 2018-05-15 05:17:33 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:17:33 --> Security Class Initialized
DEBUG - 2018-05-15 05:17:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:17:33 --> Input Class Initialized
INFO - 2018-05-15 05:17:33 --> Language Class Initialized
ERROR - 2018-05-15 05:17:33 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:17:39 --> Config Class Initialized
INFO - 2018-05-15 05:17:39 --> Config Class Initialized
INFO - 2018-05-15 05:17:39 --> Config Class Initialized
INFO - 2018-05-15 05:17:39 --> Config Class Initialized
INFO - 2018-05-15 05:17:39 --> Config Class Initialized
INFO - 2018-05-15 05:17:39 --> Hooks Class Initialized
INFO - 2018-05-15 05:17:39 --> Hooks Class Initialized
INFO - 2018-05-15 05:17:39 --> Hooks Class Initialized
INFO - 2018-05-15 05:17:39 --> Hooks Class Initialized
INFO - 2018-05-15 05:17:39 --> Hooks Class Initialized
DEBUG - 2018-05-15 05:17:39 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 05:17:39 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 05:17:39 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 05:17:39 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 05:17:39 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:17:39 --> Utf8 Class Initialized
INFO - 2018-05-15 05:17:39 --> Utf8 Class Initialized
INFO - 2018-05-15 05:17:39 --> Utf8 Class Initialized
INFO - 2018-05-15 05:17:39 --> Utf8 Class Initialized
INFO - 2018-05-15 05:17:39 --> Utf8 Class Initialized
INFO - 2018-05-15 05:17:39 --> URI Class Initialized
INFO - 2018-05-15 05:17:39 --> Router Class Initialized
INFO - 2018-05-15 05:17:39 --> Output Class Initialized
INFO - 2018-05-15 05:17:39 --> URI Class Initialized
INFO - 2018-05-15 05:17:39 --> URI Class Initialized
INFO - 2018-05-15 05:17:39 --> URI Class Initialized
INFO - 2018-05-15 05:17:39 --> URI Class Initialized
INFO - 2018-05-15 05:17:39 --> Security Class Initialized
INFO - 2018-05-15 05:17:39 --> Router Class Initialized
INFO - 2018-05-15 05:17:39 --> Router Class Initialized
INFO - 2018-05-15 05:17:39 --> Router Class Initialized
INFO - 2018-05-15 05:17:39 --> Router Class Initialized
DEBUG - 2018-05-15 05:17:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:17:40 --> Input Class Initialized
INFO - 2018-05-15 05:17:40 --> Output Class Initialized
INFO - 2018-05-15 05:17:40 --> Output Class Initialized
INFO - 2018-05-15 05:17:40 --> Output Class Initialized
INFO - 2018-05-15 05:17:40 --> Output Class Initialized
INFO - 2018-05-15 05:17:40 --> Language Class Initialized
INFO - 2018-05-15 05:17:40 --> Security Class Initialized
DEBUG - 2018-05-15 05:17:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:17:40 --> Security Class Initialized
INFO - 2018-05-15 05:17:40 --> Security Class Initialized
INFO - 2018-05-15 05:17:40 --> Security Class Initialized
ERROR - 2018-05-15 05:17:40 --> 404 Page Not Found: /index
DEBUG - 2018-05-15 05:17:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-15 05:17:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-15 05:17:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:17:40 --> Input Class Initialized
INFO - 2018-05-15 05:17:40 --> Input Class Initialized
INFO - 2018-05-15 05:17:40 --> Input Class Initialized
INFO - 2018-05-15 05:17:40 --> Language Class Initialized
INFO - 2018-05-15 05:17:40 --> Input Class Initialized
INFO - 2018-05-15 05:17:40 --> Language Class Initialized
INFO - 2018-05-15 05:17:40 --> Language Class Initialized
ERROR - 2018-05-15 05:17:40 --> 404 Page Not Found: /index
ERROR - 2018-05-15 05:17:40 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:17:40 --> Language Class Initialized
ERROR - 2018-05-15 05:17:40 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:17:40 --> Config Class Initialized
ERROR - 2018-05-15 05:17:40 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:17:40 --> Config Class Initialized
INFO - 2018-05-15 05:17:40 --> Config Class Initialized
INFO - 2018-05-15 05:17:40 --> Hooks Class Initialized
INFO - 2018-05-15 05:17:40 --> Hooks Class Initialized
INFO - 2018-05-15 05:17:40 --> Hooks Class Initialized
INFO - 2018-05-15 05:17:40 --> Config Class Initialized
INFO - 2018-05-15 05:17:40 --> Hooks Class Initialized
DEBUG - 2018-05-15 05:17:40 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 05:17:40 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 05:17:40 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 05:17:40 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:17:40 --> Utf8 Class Initialized
INFO - 2018-05-15 05:17:40 --> URI Class Initialized
INFO - 2018-05-15 05:17:40 --> Utf8 Class Initialized
INFO - 2018-05-15 05:17:40 --> Utf8 Class Initialized
INFO - 2018-05-15 05:17:40 --> URI Class Initialized
INFO - 2018-05-15 05:17:40 --> Utf8 Class Initialized
INFO - 2018-05-15 05:17:40 --> URI Class Initialized
INFO - 2018-05-15 05:17:40 --> Router Class Initialized
INFO - 2018-05-15 05:17:40 --> URI Class Initialized
INFO - 2018-05-15 05:17:40 --> Output Class Initialized
INFO - 2018-05-15 05:17:40 --> Router Class Initialized
INFO - 2018-05-15 05:17:40 --> Router Class Initialized
INFO - 2018-05-15 05:17:40 --> Output Class Initialized
INFO - 2018-05-15 05:17:40 --> Router Class Initialized
INFO - 2018-05-15 05:17:40 --> Security Class Initialized
INFO - 2018-05-15 05:17:40 --> Output Class Initialized
INFO - 2018-05-15 05:17:40 --> Security Class Initialized
INFO - 2018-05-15 05:17:40 --> Security Class Initialized
DEBUG - 2018-05-15 05:17:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:17:40 --> Output Class Initialized
DEBUG - 2018-05-15 05:17:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:17:40 --> Input Class Initialized
INFO - 2018-05-15 05:17:40 --> Security Class Initialized
DEBUG - 2018-05-15 05:17:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:17:40 --> Language Class Initialized
DEBUG - 2018-05-15 05:17:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:17:40 --> Input Class Initialized
INFO - 2018-05-15 05:17:40 --> Input Class Initialized
INFO - 2018-05-15 05:17:40 --> Language Class Initialized
INFO - 2018-05-15 05:17:40 --> Input Class Initialized
ERROR - 2018-05-15 05:17:40 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:17:40 --> Language Class Initialized
INFO - 2018-05-15 05:17:40 --> Language Class Initialized
INFO - 2018-05-15 05:17:40 --> Config Class Initialized
ERROR - 2018-05-15 05:17:40 --> 404 Page Not Found: /index
ERROR - 2018-05-15 05:17:40 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:17:40 --> Hooks Class Initialized
ERROR - 2018-05-15 05:17:40 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:17:40 --> Config Class Initialized
INFO - 2018-05-15 05:17:40 --> Config Class Initialized
INFO - 2018-05-15 05:17:40 --> Hooks Class Initialized
INFO - 2018-05-15 05:17:40 --> Hooks Class Initialized
DEBUG - 2018-05-15 05:17:40 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:17:40 --> Config Class Initialized
INFO - 2018-05-15 05:17:40 --> Hooks Class Initialized
DEBUG - 2018-05-15 05:17:40 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 05:17:40 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:17:40 --> Utf8 Class Initialized
DEBUG - 2018-05-15 05:17:40 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:17:40 --> URI Class Initialized
INFO - 2018-05-15 05:17:40 --> Utf8 Class Initialized
INFO - 2018-05-15 05:17:40 --> Utf8 Class Initialized
INFO - 2018-05-15 05:17:40 --> Utf8 Class Initialized
INFO - 2018-05-15 05:17:40 --> URI Class Initialized
INFO - 2018-05-15 05:17:40 --> Router Class Initialized
INFO - 2018-05-15 05:17:40 --> URI Class Initialized
INFO - 2018-05-15 05:17:40 --> Output Class Initialized
INFO - 2018-05-15 05:17:40 --> URI Class Initialized
INFO - 2018-05-15 05:17:40 --> Router Class Initialized
INFO - 2018-05-15 05:17:40 --> Router Class Initialized
INFO - 2018-05-15 05:17:40 --> Router Class Initialized
INFO - 2018-05-15 05:17:40 --> Output Class Initialized
INFO - 2018-05-15 05:17:40 --> Output Class Initialized
INFO - 2018-05-15 05:17:40 --> Security Class Initialized
INFO - 2018-05-15 05:17:40 --> Output Class Initialized
INFO - 2018-05-15 05:17:40 --> Security Class Initialized
DEBUG - 2018-05-15 05:17:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:17:40 --> Input Class Initialized
INFO - 2018-05-15 05:17:40 --> Language Class Initialized
ERROR - 2018-05-15 05:17:40 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:17:41 --> Security Class Initialized
INFO - 2018-05-15 05:17:41 --> Security Class Initialized
DEBUG - 2018-05-15 05:17:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:17:41 --> Input Class Initialized
DEBUG - 2018-05-15 05:17:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-15 05:17:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:17:41 --> Input Class Initialized
INFO - 2018-05-15 05:17:41 --> Input Class Initialized
INFO - 2018-05-15 05:17:41 --> Language Class Initialized
INFO - 2018-05-15 05:17:41 --> Language Class Initialized
INFO - 2018-05-15 05:17:41 --> Language Class Initialized
ERROR - 2018-05-15 05:17:41 --> 404 Page Not Found: /index
ERROR - 2018-05-15 05:17:41 --> 404 Page Not Found: /index
ERROR - 2018-05-15 05:17:41 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:17:54 --> Config Class Initialized
INFO - 2018-05-15 05:17:54 --> Config Class Initialized
INFO - 2018-05-15 05:17:54 --> Config Class Initialized
INFO - 2018-05-15 05:17:54 --> Config Class Initialized
INFO - 2018-05-15 05:17:54 --> Config Class Initialized
INFO - 2018-05-15 05:17:54 --> Hooks Class Initialized
INFO - 2018-05-15 05:17:54 --> Hooks Class Initialized
INFO - 2018-05-15 05:17:54 --> Hooks Class Initialized
INFO - 2018-05-15 05:17:54 --> Hooks Class Initialized
INFO - 2018-05-15 05:17:54 --> Hooks Class Initialized
DEBUG - 2018-05-15 05:17:54 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 05:17:54 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 05:17:54 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:17:54 --> Utf8 Class Initialized
DEBUG - 2018-05-15 05:17:54 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 05:17:54 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:17:54 --> Utf8 Class Initialized
INFO - 2018-05-15 05:17:54 --> URI Class Initialized
INFO - 2018-05-15 05:17:54 --> Utf8 Class Initialized
INFO - 2018-05-15 05:17:54 --> Utf8 Class Initialized
INFO - 2018-05-15 05:17:54 --> Utf8 Class Initialized
INFO - 2018-05-15 05:17:54 --> URI Class Initialized
INFO - 2018-05-15 05:17:54 --> Router Class Initialized
INFO - 2018-05-15 05:17:54 --> URI Class Initialized
INFO - 2018-05-15 05:17:54 --> URI Class Initialized
INFO - 2018-05-15 05:17:54 --> URI Class Initialized
INFO - 2018-05-15 05:17:54 --> Output Class Initialized
INFO - 2018-05-15 05:17:54 --> Router Class Initialized
INFO - 2018-05-15 05:17:54 --> Router Class Initialized
INFO - 2018-05-15 05:17:54 --> Router Class Initialized
INFO - 2018-05-15 05:17:54 --> Router Class Initialized
INFO - 2018-05-15 05:17:54 --> Output Class Initialized
INFO - 2018-05-15 05:17:54 --> Output Class Initialized
INFO - 2018-05-15 05:17:54 --> Output Class Initialized
INFO - 2018-05-15 05:17:54 --> Output Class Initialized
INFO - 2018-05-15 05:17:54 --> Security Class Initialized
INFO - 2018-05-15 05:17:54 --> Security Class Initialized
INFO - 2018-05-15 05:17:54 --> Security Class Initialized
INFO - 2018-05-15 05:17:54 --> Security Class Initialized
INFO - 2018-05-15 05:17:54 --> Security Class Initialized
DEBUG - 2018-05-15 05:17:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-15 05:17:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-15 05:17:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-15 05:17:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:17:54 --> Input Class Initialized
DEBUG - 2018-05-15 05:17:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:17:54 --> Input Class Initialized
INFO - 2018-05-15 05:17:54 --> Language Class Initialized
ERROR - 2018-05-15 05:17:54 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:17:54 --> Config Class Initialized
INFO - 2018-05-15 05:17:54 --> Hooks Class Initialized
INFO - 2018-05-15 05:17:54 --> Input Class Initialized
INFO - 2018-05-15 05:17:54 --> Language Class Initialized
INFO - 2018-05-15 05:17:54 --> Input Class Initialized
INFO - 2018-05-15 05:17:54 --> Input Class Initialized
DEBUG - 2018-05-15 05:17:54 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:17:54 --> Utf8 Class Initialized
ERROR - 2018-05-15 05:17:54 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:17:54 --> Language Class Initialized
INFO - 2018-05-15 05:17:54 --> Language Class Initialized
INFO - 2018-05-15 05:17:54 --> Language Class Initialized
ERROR - 2018-05-15 05:17:54 --> 404 Page Not Found: /index
ERROR - 2018-05-15 05:17:54 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:17:54 --> URI Class Initialized
ERROR - 2018-05-15 05:17:54 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:17:54 --> Router Class Initialized
INFO - 2018-05-15 05:17:54 --> Config Class Initialized
INFO - 2018-05-15 05:17:55 --> Config Class Initialized
INFO - 2018-05-15 05:17:55 --> Config Class Initialized
INFO - 2018-05-15 05:17:55 --> Hooks Class Initialized
INFO - 2018-05-15 05:17:55 --> Hooks Class Initialized
INFO - 2018-05-15 05:17:55 --> Hooks Class Initialized
INFO - 2018-05-15 05:17:55 --> Output Class Initialized
DEBUG - 2018-05-15 05:17:55 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:17:55 --> Security Class Initialized
DEBUG - 2018-05-15 05:17:55 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 05:17:55 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 05:17:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:17:55 --> Utf8 Class Initialized
INFO - 2018-05-15 05:17:55 --> Utf8 Class Initialized
INFO - 2018-05-15 05:17:55 --> Utf8 Class Initialized
INFO - 2018-05-15 05:17:55 --> Input Class Initialized
INFO - 2018-05-15 05:17:55 --> URI Class Initialized
INFO - 2018-05-15 05:17:55 --> URI Class Initialized
INFO - 2018-05-15 05:17:55 --> URI Class Initialized
INFO - 2018-05-15 05:17:55 --> Language Class Initialized
INFO - 2018-05-15 05:17:55 --> Router Class Initialized
ERROR - 2018-05-15 05:17:55 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:17:55 --> Output Class Initialized
INFO - 2018-05-15 05:17:55 --> Security Class Initialized
INFO - 2018-05-15 05:17:55 --> Config Class Initialized
DEBUG - 2018-05-15 05:17:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:17:55 --> Hooks Class Initialized
INFO - 2018-05-15 05:17:55 --> Router Class Initialized
INFO - 2018-05-15 05:17:55 --> Router Class Initialized
INFO - 2018-05-15 05:17:55 --> Output Class Initialized
INFO - 2018-05-15 05:17:55 --> Input Class Initialized
INFO - 2018-05-15 05:17:55 --> Output Class Initialized
DEBUG - 2018-05-15 05:17:55 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:17:55 --> Security Class Initialized
DEBUG - 2018-05-15 05:17:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:17:55 --> Input Class Initialized
INFO - 2018-05-15 05:17:55 --> Language Class Initialized
ERROR - 2018-05-15 05:17:55 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:17:55 --> Config Class Initialized
INFO - 2018-05-15 05:17:55 --> Hooks Class Initialized
DEBUG - 2018-05-15 05:17:55 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:17:55 --> Language Class Initialized
INFO - 2018-05-15 05:17:55 --> Utf8 Class Initialized
INFO - 2018-05-15 05:17:55 --> URI Class Initialized
INFO - 2018-05-15 05:17:55 --> Security Class Initialized
INFO - 2018-05-15 05:17:55 --> Utf8 Class Initialized
ERROR - 2018-05-15 05:17:55 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:17:55 --> URI Class Initialized
DEBUG - 2018-05-15 05:17:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:17:55 --> Config Class Initialized
INFO - 2018-05-15 05:17:55 --> Router Class Initialized
INFO - 2018-05-15 05:17:55 --> Hooks Class Initialized
INFO - 2018-05-15 05:17:55 --> Router Class Initialized
DEBUG - 2018-05-15 05:17:55 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:17:55 --> Output Class Initialized
INFO - 2018-05-15 05:17:55 --> Output Class Initialized
INFO - 2018-05-15 05:17:55 --> Utf8 Class Initialized
INFO - 2018-05-15 05:17:55 --> URI Class Initialized
INFO - 2018-05-15 05:17:55 --> Router Class Initialized
INFO - 2018-05-15 05:17:55 --> Security Class Initialized
INFO - 2018-05-15 05:17:55 --> Input Class Initialized
INFO - 2018-05-15 05:17:55 --> Output Class Initialized
INFO - 2018-05-15 05:17:55 --> Security Class Initialized
DEBUG - 2018-05-15 05:17:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:17:55 --> Input Class Initialized
INFO - 2018-05-15 05:17:55 --> Language Class Initialized
INFO - 2018-05-15 05:17:55 --> Language Class Initialized
DEBUG - 2018-05-15 05:17:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:17:55 --> Security Class Initialized
ERROR - 2018-05-15 05:17:55 --> 404 Page Not Found: /index
ERROR - 2018-05-15 05:17:55 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:17:55 --> Config Class Initialized
INFO - 2018-05-15 05:17:55 --> Input Class Initialized
DEBUG - 2018-05-15 05:17:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:17:55 --> Hooks Class Initialized
DEBUG - 2018-05-15 05:17:55 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:17:55 --> Language Class Initialized
INFO - 2018-05-15 05:17:55 --> Utf8 Class Initialized
INFO - 2018-05-15 05:17:55 --> Input Class Initialized
INFO - 2018-05-15 05:17:55 --> URI Class Initialized
ERROR - 2018-05-15 05:17:55 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:17:55 --> Language Class Initialized
INFO - 2018-05-15 05:17:55 --> Router Class Initialized
ERROR - 2018-05-15 05:17:55 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:17:55 --> Output Class Initialized
INFO - 2018-05-15 05:17:55 --> Security Class Initialized
DEBUG - 2018-05-15 05:17:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:17:56 --> Input Class Initialized
INFO - 2018-05-15 05:17:56 --> Language Class Initialized
ERROR - 2018-05-15 05:17:56 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:19:12 --> Config Class Initialized
INFO - 2018-05-15 05:19:12 --> Hooks Class Initialized
DEBUG - 2018-05-15 05:19:12 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:19:12 --> Utf8 Class Initialized
INFO - 2018-05-15 05:19:12 --> URI Class Initialized
INFO - 2018-05-15 05:19:12 --> Router Class Initialized
INFO - 2018-05-15 05:19:12 --> Output Class Initialized
INFO - 2018-05-15 05:19:12 --> Security Class Initialized
DEBUG - 2018-05-15 05:19:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:19:12 --> Input Class Initialized
INFO - 2018-05-15 05:19:12 --> Language Class Initialized
ERROR - 2018-05-15 05:19:12 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:19:12 --> Config Class Initialized
INFO - 2018-05-15 05:19:12 --> Hooks Class Initialized
DEBUG - 2018-05-15 05:19:12 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:19:12 --> Config Class Initialized
INFO - 2018-05-15 05:19:12 --> Config Class Initialized
INFO - 2018-05-15 05:19:12 --> Config Class Initialized
INFO - 2018-05-15 05:19:13 --> Config Class Initialized
INFO - 2018-05-15 05:19:13 --> Config Class Initialized
INFO - 2018-05-15 05:19:13 --> Utf8 Class Initialized
INFO - 2018-05-15 05:19:13 --> URI Class Initialized
INFO - 2018-05-15 05:19:13 --> Hooks Class Initialized
INFO - 2018-05-15 05:19:13 --> Hooks Class Initialized
INFO - 2018-05-15 05:19:13 --> Hooks Class Initialized
INFO - 2018-05-15 05:19:13 --> Hooks Class Initialized
INFO - 2018-05-15 05:19:13 --> Hooks Class Initialized
INFO - 2018-05-15 05:19:13 --> Router Class Initialized
DEBUG - 2018-05-15 05:19:13 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:19:13 --> Output Class Initialized
INFO - 2018-05-15 05:19:13 --> Utf8 Class Initialized
INFO - 2018-05-15 05:19:13 --> URI Class Initialized
DEBUG - 2018-05-15 05:19:13 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 05:19:13 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 05:19:13 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 05:19:13 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:19:13 --> Security Class Initialized
INFO - 2018-05-15 05:19:13 --> Router Class Initialized
INFO - 2018-05-15 05:19:13 --> Utf8 Class Initialized
INFO - 2018-05-15 05:19:13 --> Output Class Initialized
INFO - 2018-05-15 05:19:13 --> Utf8 Class Initialized
DEBUG - 2018-05-15 05:19:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:19:13 --> Utf8 Class Initialized
INFO - 2018-05-15 05:19:13 --> Utf8 Class Initialized
INFO - 2018-05-15 05:19:13 --> URI Class Initialized
INFO - 2018-05-15 05:19:13 --> Security Class Initialized
INFO - 2018-05-15 05:19:13 --> URI Class Initialized
INFO - 2018-05-15 05:19:13 --> Router Class Initialized
INFO - 2018-05-15 05:19:13 --> URI Class Initialized
INFO - 2018-05-15 05:19:13 --> Input Class Initialized
INFO - 2018-05-15 05:19:13 --> URI Class Initialized
DEBUG - 2018-05-15 05:19:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:19:13 --> Output Class Initialized
INFO - 2018-05-15 05:19:13 --> Router Class Initialized
INFO - 2018-05-15 05:19:13 --> Input Class Initialized
INFO - 2018-05-15 05:19:13 --> Router Class Initialized
INFO - 2018-05-15 05:19:13 --> Security Class Initialized
INFO - 2018-05-15 05:19:13 --> Output Class Initialized
INFO - 2018-05-15 05:19:13 --> Router Class Initialized
INFO - 2018-05-15 05:19:13 --> Language Class Initialized
INFO - 2018-05-15 05:19:13 --> Language Class Initialized
INFO - 2018-05-15 05:19:13 --> Output Class Initialized
INFO - 2018-05-15 05:19:13 --> Output Class Initialized
ERROR - 2018-05-15 05:19:13 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:19:13 --> Security Class Initialized
DEBUG - 2018-05-15 05:19:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-05-15 05:19:13 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:19:13 --> Security Class Initialized
DEBUG - 2018-05-15 05:19:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:19:13 --> Security Class Initialized
DEBUG - 2018-05-15 05:19:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-15 05:19:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:19:13 --> Config Class Initialized
INFO - 2018-05-15 05:19:13 --> Input Class Initialized
INFO - 2018-05-15 05:19:13 --> Input Class Initialized
INFO - 2018-05-15 05:19:13 --> Input Class Initialized
INFO - 2018-05-15 05:19:13 --> Hooks Class Initialized
INFO - 2018-05-15 05:19:13 --> Language Class Initialized
INFO - 2018-05-15 05:19:13 --> Language Class Initialized
INFO - 2018-05-15 05:19:13 --> Language Class Initialized
INFO - 2018-05-15 05:19:13 --> Input Class Initialized
ERROR - 2018-05-15 05:19:13 --> 404 Page Not Found: /index
ERROR - 2018-05-15 05:19:13 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:19:13 --> Language Class Initialized
ERROR - 2018-05-15 05:19:13 --> 404 Page Not Found: /index
DEBUG - 2018-05-15 05:19:13 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:19:13 --> Config Class Initialized
INFO - 2018-05-15 05:19:13 --> Utf8 Class Initialized
ERROR - 2018-05-15 05:19:13 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:19:13 --> Config Class Initialized
INFO - 2018-05-15 05:19:13 --> Hooks Class Initialized
INFO - 2018-05-15 05:19:13 --> Hooks Class Initialized
INFO - 2018-05-15 05:19:13 --> Config Class Initialized
INFO - 2018-05-15 05:19:13 --> URI Class Initialized
INFO - 2018-05-15 05:19:13 --> Config Class Initialized
INFO - 2018-05-15 05:19:13 --> Hooks Class Initialized
DEBUG - 2018-05-15 05:19:13 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:19:13 --> Router Class Initialized
INFO - 2018-05-15 05:19:13 --> Hooks Class Initialized
DEBUG - 2018-05-15 05:19:13 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:19:13 --> Utf8 Class Initialized
DEBUG - 2018-05-15 05:19:13 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 05:19:13 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:19:13 --> Output Class Initialized
INFO - 2018-05-15 05:19:13 --> Utf8 Class Initialized
INFO - 2018-05-15 05:19:13 --> URI Class Initialized
INFO - 2018-05-15 05:19:13 --> URI Class Initialized
INFO - 2018-05-15 05:19:13 --> Utf8 Class Initialized
INFO - 2018-05-15 05:19:13 --> Utf8 Class Initialized
INFO - 2018-05-15 05:19:13 --> Security Class Initialized
INFO - 2018-05-15 05:19:13 --> URI Class Initialized
INFO - 2018-05-15 05:19:13 --> Router Class Initialized
INFO - 2018-05-15 05:19:13 --> URI Class Initialized
INFO - 2018-05-15 05:19:13 --> Router Class Initialized
INFO - 2018-05-15 05:19:13 --> Router Class Initialized
INFO - 2018-05-15 05:19:13 --> Output Class Initialized
INFO - 2018-05-15 05:19:13 --> Router Class Initialized
INFO - 2018-05-15 05:19:13 --> Output Class Initialized
DEBUG - 2018-05-15 05:19:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:19:13 --> Output Class Initialized
INFO - 2018-05-15 05:19:13 --> Security Class Initialized
DEBUG - 2018-05-15 05:19:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:19:13 --> Input Class Initialized
INFO - 2018-05-15 05:19:13 --> Security Class Initialized
INFO - 2018-05-15 05:19:13 --> Output Class Initialized
INFO - 2018-05-15 05:19:13 --> Security Class Initialized
INFO - 2018-05-15 05:19:13 --> Input Class Initialized
INFO - 2018-05-15 05:19:13 --> Security Class Initialized
DEBUG - 2018-05-15 05:19:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-15 05:19:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:19:13 --> Language Class Initialized
INFO - 2018-05-15 05:19:13 --> Language Class Initialized
DEBUG - 2018-05-15 05:19:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:19:13 --> Input Class Initialized
INFO - 2018-05-15 05:19:14 --> Language Class Initialized
ERROR - 2018-05-15 05:19:14 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:19:14 --> Config Class Initialized
ERROR - 2018-05-15 05:19:14 --> 404 Page Not Found: /index
ERROR - 2018-05-15 05:19:14 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:19:14 --> Input Class Initialized
INFO - 2018-05-15 05:19:14 --> Input Class Initialized
INFO - 2018-05-15 05:19:14 --> Hooks Class Initialized
DEBUG - 2018-05-15 05:19:14 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:19:14 --> Config Class Initialized
INFO - 2018-05-15 05:19:14 --> Hooks Class Initialized
INFO - 2018-05-15 05:19:14 --> Utf8 Class Initialized
INFO - 2018-05-15 05:19:14 --> Language Class Initialized
INFO - 2018-05-15 05:19:14 --> Language Class Initialized
INFO - 2018-05-15 05:19:14 --> Config Class Initialized
INFO - 2018-05-15 05:19:14 --> Hooks Class Initialized
DEBUG - 2018-05-15 05:19:14 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:19:14 --> URI Class Initialized
ERROR - 2018-05-15 05:19:14 --> 404 Page Not Found: /index
ERROR - 2018-05-15 05:19:14 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:19:14 --> Router Class Initialized
INFO - 2018-05-15 05:19:14 --> Config Class Initialized
DEBUG - 2018-05-15 05:19:14 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:19:14 --> Utf8 Class Initialized
INFO - 2018-05-15 05:19:14 --> Config Class Initialized
INFO - 2018-05-15 05:19:14 --> Hooks Class Initialized
INFO - 2018-05-15 05:19:14 --> Hooks Class Initialized
INFO - 2018-05-15 05:19:14 --> Output Class Initialized
INFO - 2018-05-15 05:19:14 --> URI Class Initialized
INFO - 2018-05-15 05:19:14 --> Utf8 Class Initialized
DEBUG - 2018-05-15 05:19:14 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 05:19:14 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:19:14 --> URI Class Initialized
INFO - 2018-05-15 05:19:14 --> Security Class Initialized
INFO - 2018-05-15 05:19:14 --> Router Class Initialized
INFO - 2018-05-15 05:19:14 --> Utf8 Class Initialized
INFO - 2018-05-15 05:19:14 --> URI Class Initialized
INFO - 2018-05-15 05:19:14 --> Router Class Initialized
INFO - 2018-05-15 05:19:14 --> Output Class Initialized
DEBUG - 2018-05-15 05:19:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:19:14 --> Router Class Initialized
INFO - 2018-05-15 05:19:14 --> Output Class Initialized
INFO - 2018-05-15 05:19:14 --> Input Class Initialized
INFO - 2018-05-15 05:19:14 --> Output Class Initialized
INFO - 2018-05-15 05:19:14 --> Security Class Initialized
INFO - 2018-05-15 05:19:14 --> Utf8 Class Initialized
INFO - 2018-05-15 05:19:14 --> Security Class Initialized
INFO - 2018-05-15 05:19:14 --> Security Class Initialized
INFO - 2018-05-15 05:19:14 --> Language Class Initialized
INFO - 2018-05-15 05:19:14 --> URI Class Initialized
DEBUG - 2018-05-15 05:19:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-15 05:19:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-05-15 05:19:14 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:19:14 --> Input Class Initialized
INFO - 2018-05-15 05:19:14 --> Input Class Initialized
DEBUG - 2018-05-15 05:19:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:19:14 --> Router Class Initialized
INFO - 2018-05-15 05:19:14 --> Output Class Initialized
INFO - 2018-05-15 05:19:14 --> Language Class Initialized
INFO - 2018-05-15 05:19:14 --> Security Class Initialized
INFO - 2018-05-15 05:19:14 --> Language Class Initialized
INFO - 2018-05-15 05:19:14 --> Input Class Initialized
DEBUG - 2018-05-15 05:19:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:19:14 --> Language Class Initialized
ERROR - 2018-05-15 05:19:14 --> 404 Page Not Found: /index
ERROR - 2018-05-15 05:19:14 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:19:14 --> Input Class Initialized
INFO - 2018-05-15 05:19:14 --> Language Class Initialized
ERROR - 2018-05-15 05:19:14 --> 404 Page Not Found: /index
ERROR - 2018-05-15 05:19:14 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:19:14 --> Config Class Initialized
INFO - 2018-05-15 05:19:14 --> Hooks Class Initialized
DEBUG - 2018-05-15 05:19:14 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:19:14 --> Utf8 Class Initialized
INFO - 2018-05-15 05:19:14 --> URI Class Initialized
INFO - 2018-05-15 05:19:14 --> Router Class Initialized
INFO - 2018-05-15 05:19:14 --> Output Class Initialized
INFO - 2018-05-15 05:19:14 --> Security Class Initialized
DEBUG - 2018-05-15 05:19:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:19:14 --> Input Class Initialized
INFO - 2018-05-15 05:19:14 --> Language Class Initialized
ERROR - 2018-05-15 05:19:14 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:19:15 --> Config Class Initialized
INFO - 2018-05-15 05:19:16 --> Hooks Class Initialized
DEBUG - 2018-05-15 05:19:16 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:19:16 --> Utf8 Class Initialized
INFO - 2018-05-15 05:19:16 --> URI Class Initialized
INFO - 2018-05-15 05:19:16 --> Router Class Initialized
INFO - 2018-05-15 05:19:16 --> Output Class Initialized
INFO - 2018-05-15 05:19:16 --> Security Class Initialized
DEBUG - 2018-05-15 05:19:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:19:16 --> Input Class Initialized
INFO - 2018-05-15 05:19:16 --> Language Class Initialized
ERROR - 2018-05-15 05:19:16 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:19:16 --> Config Class Initialized
INFO - 2018-05-15 05:19:16 --> Hooks Class Initialized
DEBUG - 2018-05-15 05:19:16 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:19:16 --> Utf8 Class Initialized
INFO - 2018-05-15 05:19:16 --> URI Class Initialized
INFO - 2018-05-15 05:19:16 --> Router Class Initialized
INFO - 2018-05-15 05:19:16 --> Output Class Initialized
INFO - 2018-05-15 05:19:16 --> Security Class Initialized
DEBUG - 2018-05-15 05:19:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:19:16 --> Input Class Initialized
INFO - 2018-05-15 05:19:16 --> Language Class Initialized
ERROR - 2018-05-15 05:19:16 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:19:16 --> Config Class Initialized
INFO - 2018-05-15 05:19:16 --> Hooks Class Initialized
DEBUG - 2018-05-15 05:19:16 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:19:16 --> Utf8 Class Initialized
INFO - 2018-05-15 05:19:16 --> URI Class Initialized
INFO - 2018-05-15 05:19:16 --> Router Class Initialized
INFO - 2018-05-15 05:19:16 --> Output Class Initialized
INFO - 2018-05-15 05:19:16 --> Security Class Initialized
DEBUG - 2018-05-15 05:19:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:19:16 --> Input Class Initialized
INFO - 2018-05-15 05:19:16 --> Language Class Initialized
ERROR - 2018-05-15 05:19:16 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:19:17 --> Config Class Initialized
INFO - 2018-05-15 05:19:17 --> Config Class Initialized
INFO - 2018-05-15 05:19:17 --> Config Class Initialized
INFO - 2018-05-15 05:19:17 --> Config Class Initialized
INFO - 2018-05-15 05:19:17 --> Config Class Initialized
INFO - 2018-05-15 05:19:17 --> Hooks Class Initialized
INFO - 2018-05-15 05:19:17 --> Hooks Class Initialized
INFO - 2018-05-15 05:19:17 --> Hooks Class Initialized
INFO - 2018-05-15 05:19:17 --> Hooks Class Initialized
INFO - 2018-05-15 05:19:17 --> Hooks Class Initialized
DEBUG - 2018-05-15 05:19:17 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:19:17 --> Utf8 Class Initialized
INFO - 2018-05-15 05:19:17 --> URI Class Initialized
INFO - 2018-05-15 05:19:17 --> Router Class Initialized
INFO - 2018-05-15 05:19:17 --> Output Class Initialized
DEBUG - 2018-05-15 05:19:17 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 05:19:17 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 05:19:17 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 05:19:17 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:19:17 --> Security Class Initialized
INFO - 2018-05-15 05:19:17 --> Utf8 Class Initialized
INFO - 2018-05-15 05:19:17 --> Utf8 Class Initialized
INFO - 2018-05-15 05:19:17 --> Utf8 Class Initialized
DEBUG - 2018-05-15 05:19:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:19:17 --> Utf8 Class Initialized
INFO - 2018-05-15 05:19:17 --> URI Class Initialized
INFO - 2018-05-15 05:19:17 --> URI Class Initialized
INFO - 2018-05-15 05:19:17 --> Router Class Initialized
INFO - 2018-05-15 05:19:17 --> Input Class Initialized
INFO - 2018-05-15 05:19:17 --> URI Class Initialized
INFO - 2018-05-15 05:19:17 --> URI Class Initialized
INFO - 2018-05-15 05:19:18 --> Router Class Initialized
INFO - 2018-05-15 05:19:18 --> Router Class Initialized
INFO - 2018-05-15 05:19:18 --> Router Class Initialized
INFO - 2018-05-15 05:19:18 --> Language Class Initialized
INFO - 2018-05-15 05:19:18 --> Output Class Initialized
INFO - 2018-05-15 05:19:18 --> Output Class Initialized
INFO - 2018-05-15 05:19:18 --> Security Class Initialized
ERROR - 2018-05-15 05:19:18 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:19:18 --> Output Class Initialized
INFO - 2018-05-15 05:19:18 --> Output Class Initialized
INFO - 2018-05-15 05:19:18 --> Security Class Initialized
DEBUG - 2018-05-15 05:19:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:19:18 --> Input Class Initialized
INFO - 2018-05-15 05:19:18 --> Language Class Initialized
ERROR - 2018-05-15 05:19:18 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:19:18 --> Security Class Initialized
INFO - 2018-05-15 05:19:18 --> Config Class Initialized
INFO - 2018-05-15 05:19:18 --> Security Class Initialized
DEBUG - 2018-05-15 05:19:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:19:18 --> Hooks Class Initialized
DEBUG - 2018-05-15 05:19:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:19:18 --> Input Class Initialized
DEBUG - 2018-05-15 05:19:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:19:18 --> Input Class Initialized
DEBUG - 2018-05-15 05:19:18 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:19:18 --> Language Class Initialized
INFO - 2018-05-15 05:19:18 --> Input Class Initialized
INFO - 2018-05-15 05:19:18 --> Language Class Initialized
ERROR - 2018-05-15 05:19:18 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:19:18 --> Language Class Initialized
INFO - 2018-05-15 05:19:18 --> Config Class Initialized
INFO - 2018-05-15 05:19:18 --> Hooks Class Initialized
ERROR - 2018-05-15 05:19:18 --> 404 Page Not Found: /index
ERROR - 2018-05-15 05:19:18 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:19:18 --> Utf8 Class Initialized
DEBUG - 2018-05-15 05:19:18 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:19:18 --> Utf8 Class Initialized
INFO - 2018-05-15 05:19:18 --> Config Class Initialized
INFO - 2018-05-15 05:19:18 --> URI Class Initialized
INFO - 2018-05-15 05:19:18 --> URI Class Initialized
INFO - 2018-05-15 05:19:18 --> Config Class Initialized
INFO - 2018-05-15 05:19:18 --> Hooks Class Initialized
DEBUG - 2018-05-15 05:19:18 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:19:18 --> Utf8 Class Initialized
INFO - 2018-05-15 05:19:18 --> URI Class Initialized
INFO - 2018-05-15 05:19:18 --> Router Class Initialized
INFO - 2018-05-15 05:19:18 --> Hooks Class Initialized
INFO - 2018-05-15 05:19:18 --> Router Class Initialized
INFO - 2018-05-15 05:19:18 --> Router Class Initialized
INFO - 2018-05-15 05:19:18 --> Output Class Initialized
INFO - 2018-05-15 05:19:18 --> Output Class Initialized
DEBUG - 2018-05-15 05:19:18 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:19:18 --> Output Class Initialized
INFO - 2018-05-15 05:19:18 --> Security Class Initialized
INFO - 2018-05-15 05:19:18 --> Security Class Initialized
DEBUG - 2018-05-15 05:19:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:19:18 --> Input Class Initialized
INFO - 2018-05-15 05:19:18 --> Language Class Initialized
INFO - 2018-05-15 05:19:18 --> Utf8 Class Initialized
INFO - 2018-05-15 05:19:18 --> Security Class Initialized
DEBUG - 2018-05-15 05:19:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-05-15 05:19:18 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:19:18 --> URI Class Initialized
INFO - 2018-05-15 05:19:18 --> Router Class Initialized
DEBUG - 2018-05-15 05:19:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:19:18 --> Input Class Initialized
INFO - 2018-05-15 05:19:18 --> Config Class Initialized
INFO - 2018-05-15 05:19:18 --> Hooks Class Initialized
INFO - 2018-05-15 05:19:18 --> Output Class Initialized
INFO - 2018-05-15 05:19:18 --> Language Class Initialized
INFO - 2018-05-15 05:19:18 --> Input Class Initialized
DEBUG - 2018-05-15 05:19:18 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:19:18 --> Security Class Initialized
INFO - 2018-05-15 05:19:18 --> Language Class Initialized
ERROR - 2018-05-15 05:19:18 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:19:18 --> Utf8 Class Initialized
INFO - 2018-05-15 05:19:18 --> Config Class Initialized
INFO - 2018-05-15 05:19:18 --> Hooks Class Initialized
INFO - 2018-05-15 05:19:18 --> URI Class Initialized
DEBUG - 2018-05-15 05:19:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-05-15 05:19:18 --> 404 Page Not Found: /index
DEBUG - 2018-05-15 05:19:18 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:19:18 --> Config Class Initialized
INFO - 2018-05-15 05:19:19 --> Hooks Class Initialized
INFO - 2018-05-15 05:19:19 --> Utf8 Class Initialized
INFO - 2018-05-15 05:19:19 --> Input Class Initialized
INFO - 2018-05-15 05:19:19 --> Router Class Initialized
DEBUG - 2018-05-15 05:19:19 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:19:19 --> Output Class Initialized
INFO - 2018-05-15 05:19:19 --> URI Class Initialized
INFO - 2018-05-15 05:19:19 --> Utf8 Class Initialized
INFO - 2018-05-15 05:19:19 --> URI Class Initialized
INFO - 2018-05-15 05:19:19 --> Router Class Initialized
INFO - 2018-05-15 05:19:19 --> Router Class Initialized
INFO - 2018-05-15 05:19:19 --> Language Class Initialized
INFO - 2018-05-15 05:19:19 --> Security Class Initialized
ERROR - 2018-05-15 05:19:19 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:19:19 --> Output Class Initialized
INFO - 2018-05-15 05:19:19 --> Output Class Initialized
DEBUG - 2018-05-15 05:19:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:19:19 --> Input Class Initialized
INFO - 2018-05-15 05:19:19 --> Language Class Initialized
ERROR - 2018-05-15 05:19:19 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:19:19 --> Security Class Initialized
INFO - 2018-05-15 05:19:19 --> Security Class Initialized
INFO - 2018-05-15 05:19:19 --> Config Class Initialized
INFO - 2018-05-15 05:19:19 --> Hooks Class Initialized
DEBUG - 2018-05-15 05:19:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-15 05:19:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-15 05:19:19 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:19:19 --> Utf8 Class Initialized
INFO - 2018-05-15 05:19:19 --> Input Class Initialized
INFO - 2018-05-15 05:19:19 --> Input Class Initialized
INFO - 2018-05-15 05:19:19 --> URI Class Initialized
INFO - 2018-05-15 05:19:19 --> Language Class Initialized
ERROR - 2018-05-15 05:19:19 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:19:19 --> Router Class Initialized
INFO - 2018-05-15 05:19:19 --> Language Class Initialized
INFO - 2018-05-15 05:19:19 --> Output Class Initialized
INFO - 2018-05-15 05:19:19 --> Security Class Initialized
ERROR - 2018-05-15 05:19:19 --> 404 Page Not Found: /index
DEBUG - 2018-05-15 05:19:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:19:19 --> Input Class Initialized
INFO - 2018-05-15 05:19:19 --> Language Class Initialized
ERROR - 2018-05-15 05:19:19 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:19:28 --> Config Class Initialized
INFO - 2018-05-15 05:19:28 --> Config Class Initialized
INFO - 2018-05-15 05:19:28 --> Config Class Initialized
INFO - 2018-05-15 05:19:28 --> Config Class Initialized
INFO - 2018-05-15 05:19:28 --> Config Class Initialized
INFO - 2018-05-15 05:19:28 --> Hooks Class Initialized
INFO - 2018-05-15 05:19:28 --> Hooks Class Initialized
INFO - 2018-05-15 05:19:28 --> Hooks Class Initialized
INFO - 2018-05-15 05:19:28 --> Hooks Class Initialized
INFO - 2018-05-15 05:19:28 --> Hooks Class Initialized
DEBUG - 2018-05-15 05:19:28 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 05:19:28 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 05:19:28 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:19:28 --> Utf8 Class Initialized
DEBUG - 2018-05-15 05:19:28 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 05:19:28 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:19:28 --> Utf8 Class Initialized
INFO - 2018-05-15 05:19:28 --> Utf8 Class Initialized
INFO - 2018-05-15 05:19:28 --> URI Class Initialized
INFO - 2018-05-15 05:19:28 --> Utf8 Class Initialized
INFO - 2018-05-15 05:19:28 --> URI Class Initialized
INFO - 2018-05-15 05:19:28 --> Utf8 Class Initialized
INFO - 2018-05-15 05:19:28 --> URI Class Initialized
INFO - 2018-05-15 05:19:28 --> Router Class Initialized
INFO - 2018-05-15 05:19:28 --> Router Class Initialized
INFO - 2018-05-15 05:19:28 --> URI Class Initialized
INFO - 2018-05-15 05:19:28 --> URI Class Initialized
INFO - 2018-05-15 05:19:28 --> Output Class Initialized
INFO - 2018-05-15 05:19:28 --> Router Class Initialized
INFO - 2018-05-15 05:19:28 --> Output Class Initialized
INFO - 2018-05-15 05:19:28 --> Router Class Initialized
INFO - 2018-05-15 05:19:28 --> Router Class Initialized
INFO - 2018-05-15 05:19:28 --> Security Class Initialized
DEBUG - 2018-05-15 05:19:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:19:28 --> Input Class Initialized
INFO - 2018-05-15 05:19:28 --> Output Class Initialized
INFO - 2018-05-15 05:19:28 --> Output Class Initialized
INFO - 2018-05-15 05:19:28 --> Security Class Initialized
INFO - 2018-05-15 05:19:28 --> Output Class Initialized
INFO - 2018-05-15 05:19:28 --> Language Class Initialized
INFO - 2018-05-15 05:19:28 --> Security Class Initialized
INFO - 2018-05-15 05:19:28 --> Security Class Initialized
ERROR - 2018-05-15 05:19:28 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:19:28 --> Security Class Initialized
DEBUG - 2018-05-15 05:19:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-15 05:19:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:19:28 --> Input Class Initialized
INFO - 2018-05-15 05:19:28 --> Language Class Initialized
ERROR - 2018-05-15 05:19:28 --> 404 Page Not Found: /index
DEBUG - 2018-05-15 05:19:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-15 05:19:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:19:28 --> Config Class Initialized
INFO - 2018-05-15 05:19:28 --> Input Class Initialized
INFO - 2018-05-15 05:19:28 --> Hooks Class Initialized
INFO - 2018-05-15 05:19:28 --> Config Class Initialized
INFO - 2018-05-15 05:19:28 --> Input Class Initialized
INFO - 2018-05-15 05:19:28 --> Hooks Class Initialized
DEBUG - 2018-05-15 05:19:28 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:19:28 --> Language Class Initialized
INFO - 2018-05-15 05:19:28 --> Input Class Initialized
INFO - 2018-05-15 05:19:28 --> Language Class Initialized
DEBUG - 2018-05-15 05:19:28 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:19:28 --> Language Class Initialized
ERROR - 2018-05-15 05:19:28 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:19:28 --> Utf8 Class Initialized
ERROR - 2018-05-15 05:19:28 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:19:28 --> URI Class Initialized
INFO - 2018-05-15 05:19:28 --> Utf8 Class Initialized
ERROR - 2018-05-15 05:19:28 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:19:28 --> Config Class Initialized
INFO - 2018-05-15 05:19:28 --> Hooks Class Initialized
INFO - 2018-05-15 05:19:28 --> Router Class Initialized
INFO - 2018-05-15 05:19:28 --> URI Class Initialized
INFO - 2018-05-15 05:19:28 --> Config Class Initialized
INFO - 2018-05-15 05:19:28 --> Hooks Class Initialized
DEBUG - 2018-05-15 05:19:28 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:19:28 --> Router Class Initialized
INFO - 2018-05-15 05:19:28 --> Output Class Initialized
DEBUG - 2018-05-15 05:19:28 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:19:28 --> Security Class Initialized
INFO - 2018-05-15 05:19:28 --> Output Class Initialized
INFO - 2018-05-15 05:19:28 --> Utf8 Class Initialized
INFO - 2018-05-15 05:19:28 --> Utf8 Class Initialized
INFO - 2018-05-15 05:19:29 --> URI Class Initialized
INFO - 2018-05-15 05:19:29 --> Router Class Initialized
INFO - 2018-05-15 05:19:29 --> URI Class Initialized
DEBUG - 2018-05-15 05:19:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:19:29 --> Output Class Initialized
INFO - 2018-05-15 05:19:29 --> Security Class Initialized
DEBUG - 2018-05-15 05:19:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:19:29 --> Input Class Initialized
INFO - 2018-05-15 05:19:29 --> Security Class Initialized
INFO - 2018-05-15 05:19:29 --> Input Class Initialized
INFO - 2018-05-15 05:19:29 --> Router Class Initialized
DEBUG - 2018-05-15 05:19:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:19:29 --> Language Class Initialized
INFO - 2018-05-15 05:19:29 --> Output Class Initialized
INFO - 2018-05-15 05:19:29 --> Language Class Initialized
INFO - 2018-05-15 05:19:29 --> Input Class Initialized
ERROR - 2018-05-15 05:19:29 --> 404 Page Not Found: /index
ERROR - 2018-05-15 05:19:29 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:19:29 --> Security Class Initialized
INFO - 2018-05-15 05:19:29 --> Language Class Initialized
DEBUG - 2018-05-15 05:19:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-05-15 05:19:29 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:19:29 --> Config Class Initialized
INFO - 2018-05-15 05:19:29 --> Config Class Initialized
INFO - 2018-05-15 05:19:29 --> Hooks Class Initialized
INFO - 2018-05-15 05:19:29 --> Hooks Class Initialized
INFO - 2018-05-15 05:19:29 --> Input Class Initialized
INFO - 2018-05-15 05:19:29 --> Config Class Initialized
INFO - 2018-05-15 05:19:29 --> Hooks Class Initialized
DEBUG - 2018-05-15 05:19:29 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 05:19:29 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:19:29 --> Language Class Initialized
DEBUG - 2018-05-15 05:19:29 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:19:29 --> Utf8 Class Initialized
INFO - 2018-05-15 05:19:29 --> Utf8 Class Initialized
INFO - 2018-05-15 05:19:29 --> Utf8 Class Initialized
ERROR - 2018-05-15 05:19:29 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:19:29 --> URI Class Initialized
INFO - 2018-05-15 05:19:29 --> URI Class Initialized
INFO - 2018-05-15 05:19:29 --> Router Class Initialized
INFO - 2018-05-15 05:19:29 --> URI Class Initialized
INFO - 2018-05-15 05:19:29 --> Router Class Initialized
INFO - 2018-05-15 05:19:29 --> Config Class Initialized
INFO - 2018-05-15 05:19:29 --> Hooks Class Initialized
INFO - 2018-05-15 05:19:29 --> Output Class Initialized
INFO - 2018-05-15 05:19:29 --> Output Class Initialized
INFO - 2018-05-15 05:19:29 --> Router Class Initialized
DEBUG - 2018-05-15 05:19:29 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:19:29 --> Security Class Initialized
INFO - 2018-05-15 05:19:29 --> Output Class Initialized
INFO - 2018-05-15 05:19:29 --> Security Class Initialized
INFO - 2018-05-15 05:19:29 --> Utf8 Class Initialized
DEBUG - 2018-05-15 05:19:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:19:29 --> Security Class Initialized
DEBUG - 2018-05-15 05:19:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-15 05:19:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:19:29 --> Input Class Initialized
INFO - 2018-05-15 05:19:29 --> URI Class Initialized
INFO - 2018-05-15 05:19:29 --> Input Class Initialized
INFO - 2018-05-15 05:19:29 --> Input Class Initialized
INFO - 2018-05-15 05:19:29 --> Router Class Initialized
INFO - 2018-05-15 05:19:29 --> Language Class Initialized
INFO - 2018-05-15 05:19:29 --> Language Class Initialized
INFO - 2018-05-15 05:19:29 --> Output Class Initialized
INFO - 2018-05-15 05:19:29 --> Language Class Initialized
ERROR - 2018-05-15 05:19:29 --> 404 Page Not Found: /index
ERROR - 2018-05-15 05:19:29 --> 404 Page Not Found: /index
ERROR - 2018-05-15 05:19:29 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:19:29 --> Security Class Initialized
DEBUG - 2018-05-15 05:19:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:19:29 --> Input Class Initialized
INFO - 2018-05-15 05:19:29 --> Language Class Initialized
ERROR - 2018-05-15 05:19:29 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:31:33 --> Config Class Initialized
INFO - 2018-05-15 05:31:33 --> Hooks Class Initialized
DEBUG - 2018-05-15 05:31:33 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:31:33 --> Utf8 Class Initialized
INFO - 2018-05-15 05:31:33 --> URI Class Initialized
INFO - 2018-05-15 05:31:33 --> Router Class Initialized
INFO - 2018-05-15 05:31:34 --> Output Class Initialized
INFO - 2018-05-15 05:31:34 --> Security Class Initialized
DEBUG - 2018-05-15 05:31:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:31:34 --> Input Class Initialized
INFO - 2018-05-15 05:31:34 --> Language Class Initialized
INFO - 2018-05-15 05:31:34 --> Language Class Initialized
INFO - 2018-05-15 05:31:34 --> Config Class Initialized
INFO - 2018-05-15 05:31:34 --> Loader Class Initialized
DEBUG - 2018-05-15 05:31:34 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-15 05:31:34 --> Helper loaded: url_helper
INFO - 2018-05-15 05:31:34 --> Helper loaded: form_helper
INFO - 2018-05-15 05:31:34 --> Helper loaded: date_helper
INFO - 2018-05-15 05:31:34 --> Helper loaded: util_helper
INFO - 2018-05-15 05:31:34 --> Helper loaded: text_helper
INFO - 2018-05-15 05:31:34 --> Helper loaded: string_helper
INFO - 2018-05-15 05:31:34 --> Database Driver Class Initialized
DEBUG - 2018-05-15 05:31:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-15 05:31:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-15 05:31:34 --> Email Class Initialized
INFO - 2018-05-15 05:31:34 --> Controller Class Initialized
DEBUG - 2018-05-15 05:31:34 --> Home MX_Controller Initialized
DEBUG - 2018-05-15 05:31:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-15 05:31:34 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-15 05:31:34 --> Login MX_Controller Initialized
INFO - 2018-05-15 05:31:34 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-15 05:31:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-15 05:31:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-15 05:31:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/login.php
INFO - 2018-05-15 05:33:13 --> Config Class Initialized
INFO - 2018-05-15 05:33:13 --> Hooks Class Initialized
DEBUG - 2018-05-15 05:33:13 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:33:13 --> Utf8 Class Initialized
INFO - 2018-05-15 05:33:13 --> URI Class Initialized
INFO - 2018-05-15 05:33:13 --> Router Class Initialized
INFO - 2018-05-15 05:33:13 --> Output Class Initialized
INFO - 2018-05-15 05:33:13 --> Security Class Initialized
DEBUG - 2018-05-15 05:33:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:33:13 --> Input Class Initialized
INFO - 2018-05-15 05:33:13 --> Language Class Initialized
INFO - 2018-05-15 05:33:14 --> Language Class Initialized
INFO - 2018-05-15 05:33:14 --> Config Class Initialized
INFO - 2018-05-15 05:33:14 --> Loader Class Initialized
DEBUG - 2018-05-15 05:33:14 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-15 05:33:14 --> Helper loaded: url_helper
INFO - 2018-05-15 05:33:14 --> Helper loaded: form_helper
INFO - 2018-05-15 05:33:14 --> Helper loaded: date_helper
INFO - 2018-05-15 05:33:14 --> Helper loaded: util_helper
INFO - 2018-05-15 05:33:14 --> Helper loaded: text_helper
INFO - 2018-05-15 05:33:14 --> Helper loaded: string_helper
INFO - 2018-05-15 05:33:14 --> Database Driver Class Initialized
DEBUG - 2018-05-15 05:33:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-15 05:33:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-15 05:33:14 --> Email Class Initialized
INFO - 2018-05-15 05:33:14 --> Controller Class Initialized
DEBUG - 2018-05-15 05:33:14 --> Login MX_Controller Initialized
INFO - 2018-05-15 05:33:14 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-15 05:33:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-15 05:33:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-15 05:33:14 --> Email starts for gopipanguluri123@gmail.com fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-05-15 05:33:14 --> User session created for 4
INFO - 2018-05-15 05:33:14 --> Login status gopipanguluri123@gmail.com - success
INFO - 2018-05-15 05:33:14 --> Final output sent to browser
DEBUG - 2018-05-15 05:33:14 --> Total execution time: 1.0232
INFO - 2018-05-15 05:33:14 --> Config Class Initialized
INFO - 2018-05-15 05:33:14 --> Hooks Class Initialized
DEBUG - 2018-05-15 05:33:14 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:33:14 --> Utf8 Class Initialized
INFO - 2018-05-15 05:33:14 --> URI Class Initialized
INFO - 2018-05-15 05:33:14 --> Router Class Initialized
INFO - 2018-05-15 05:33:14 --> Output Class Initialized
INFO - 2018-05-15 05:33:14 --> Security Class Initialized
DEBUG - 2018-05-15 05:33:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:33:14 --> Input Class Initialized
INFO - 2018-05-15 05:33:14 --> Language Class Initialized
INFO - 2018-05-15 05:33:14 --> Language Class Initialized
INFO - 2018-05-15 05:33:15 --> Config Class Initialized
INFO - 2018-05-15 05:33:15 --> Loader Class Initialized
DEBUG - 2018-05-15 05:33:15 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-15 05:33:15 --> Helper loaded: url_helper
INFO - 2018-05-15 05:33:15 --> Helper loaded: form_helper
INFO - 2018-05-15 05:33:15 --> Helper loaded: date_helper
INFO - 2018-05-15 05:33:15 --> Helper loaded: util_helper
INFO - 2018-05-15 05:33:15 --> Helper loaded: text_helper
INFO - 2018-05-15 05:33:15 --> Helper loaded: string_helper
INFO - 2018-05-15 05:33:15 --> Database Driver Class Initialized
DEBUG - 2018-05-15 05:33:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-15 05:33:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-15 05:33:15 --> Email Class Initialized
INFO - 2018-05-15 05:33:15 --> Controller Class Initialized
DEBUG - 2018-05-15 05:33:15 --> Home MX_Controller Initialized
DEBUG - 2018-05-15 05:33:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-15 05:33:15 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-15 05:33:15 --> Login MX_Controller Initialized
INFO - 2018-05-15 05:33:15 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-15 05:33:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-15 05:33:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-15 05:33:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-05-15 05:33:15 --> Final output sent to browser
DEBUG - 2018-05-15 05:33:15 --> Total execution time: 0.7696
INFO - 2018-05-15 05:33:15 --> Config Class Initialized
INFO - 2018-05-15 05:33:15 --> Hooks Class Initialized
DEBUG - 2018-05-15 05:33:15 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:33:15 --> Utf8 Class Initialized
INFO - 2018-05-15 05:33:15 --> URI Class Initialized
INFO - 2018-05-15 05:33:15 --> Router Class Initialized
INFO - 2018-05-15 05:33:15 --> Output Class Initialized
INFO - 2018-05-15 05:33:15 --> Security Class Initialized
DEBUG - 2018-05-15 05:33:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:33:15 --> Input Class Initialized
INFO - 2018-05-15 05:33:15 --> Language Class Initialized
INFO - 2018-05-15 05:33:15 --> Config Class Initialized
INFO - 2018-05-15 05:33:15 --> Config Class Initialized
INFO - 2018-05-15 05:33:15 --> Config Class Initialized
INFO - 2018-05-15 05:33:15 --> Config Class Initialized
INFO - 2018-05-15 05:33:15 --> Hooks Class Initialized
INFO - 2018-05-15 05:33:15 --> Hooks Class Initialized
INFO - 2018-05-15 05:33:15 --> Hooks Class Initialized
ERROR - 2018-05-15 05:33:15 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:33:15 --> Hooks Class Initialized
INFO - 2018-05-15 05:33:15 --> Config Class Initialized
INFO - 2018-05-15 05:33:16 --> Hooks Class Initialized
DEBUG - 2018-05-15 05:33:16 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 05:33:16 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:33:16 --> Config Class Initialized
DEBUG - 2018-05-15 05:33:16 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 05:33:16 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:33:16 --> Utf8 Class Initialized
INFO - 2018-05-15 05:33:16 --> Hooks Class Initialized
DEBUG - 2018-05-15 05:33:16 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:33:16 --> Utf8 Class Initialized
INFO - 2018-05-15 05:33:16 --> Utf8 Class Initialized
INFO - 2018-05-15 05:33:16 --> Utf8 Class Initialized
INFO - 2018-05-15 05:33:16 --> Utf8 Class Initialized
INFO - 2018-05-15 05:33:16 --> URI Class Initialized
DEBUG - 2018-05-15 05:33:16 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:33:16 --> URI Class Initialized
INFO - 2018-05-15 05:33:16 --> URI Class Initialized
INFO - 2018-05-15 05:33:16 --> URI Class Initialized
INFO - 2018-05-15 05:33:16 --> URI Class Initialized
INFO - 2018-05-15 05:33:16 --> Router Class Initialized
INFO - 2018-05-15 05:33:16 --> Output Class Initialized
INFO - 2018-05-15 05:33:16 --> Router Class Initialized
INFO - 2018-05-15 05:33:16 --> Router Class Initialized
INFO - 2018-05-15 05:33:16 --> Utf8 Class Initialized
INFO - 2018-05-15 05:33:16 --> Router Class Initialized
INFO - 2018-05-15 05:33:16 --> Security Class Initialized
DEBUG - 2018-05-15 05:33:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:33:16 --> Output Class Initialized
INFO - 2018-05-15 05:33:16 --> Router Class Initialized
INFO - 2018-05-15 05:33:16 --> Output Class Initialized
INFO - 2018-05-15 05:33:16 --> URI Class Initialized
INFO - 2018-05-15 05:33:16 --> Output Class Initialized
INFO - 2018-05-15 05:33:16 --> Input Class Initialized
INFO - 2018-05-15 05:33:16 --> Security Class Initialized
DEBUG - 2018-05-15 05:33:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:33:16 --> Input Class Initialized
INFO - 2018-05-15 05:33:16 --> Language Class Initialized
INFO - 2018-05-15 05:33:16 --> Security Class Initialized
INFO - 2018-05-15 05:33:16 --> Router Class Initialized
INFO - 2018-05-15 05:33:16 --> Language Class Initialized
INFO - 2018-05-15 05:33:16 --> Security Class Initialized
INFO - 2018-05-15 05:33:16 --> Output Class Initialized
ERROR - 2018-05-15 05:33:16 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:33:16 --> Security Class Initialized
ERROR - 2018-05-15 05:33:16 --> 404 Page Not Found: /index
DEBUG - 2018-05-15 05:33:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:33:16 --> Output Class Initialized
DEBUG - 2018-05-15 05:33:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:33:16 --> Config Class Initialized
DEBUG - 2018-05-15 05:33:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:33:16 --> Input Class Initialized
INFO - 2018-05-15 05:33:16 --> Config Class Initialized
INFO - 2018-05-15 05:33:16 --> Input Class Initialized
INFO - 2018-05-15 05:33:16 --> Input Class Initialized
INFO - 2018-05-15 05:33:16 --> Hooks Class Initialized
INFO - 2018-05-15 05:33:16 --> Language Class Initialized
INFO - 2018-05-15 05:33:16 --> Security Class Initialized
INFO - 2018-05-15 05:33:16 --> Hooks Class Initialized
DEBUG - 2018-05-15 05:33:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-05-15 05:33:16 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:33:16 --> Language Class Initialized
DEBUG - 2018-05-15 05:33:16 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:33:16 --> Language Class Initialized
DEBUG - 2018-05-15 05:33:16 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:33:16 --> Utf8 Class Initialized
INFO - 2018-05-15 05:33:16 --> Utf8 Class Initialized
ERROR - 2018-05-15 05:33:16 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:33:16 --> Input Class Initialized
ERROR - 2018-05-15 05:33:16 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:33:16 --> URI Class Initialized
INFO - 2018-05-15 05:33:16 --> Config Class Initialized
INFO - 2018-05-15 05:33:16 --> Language Class Initialized
INFO - 2018-05-15 05:33:16 --> URI Class Initialized
INFO - 2018-05-15 05:33:16 --> Config Class Initialized
INFO - 2018-05-15 05:33:16 --> Hooks Class Initialized
INFO - 2018-05-15 05:33:16 --> Hooks Class Initialized
INFO - 2018-05-15 05:33:16 --> Router Class Initialized
ERROR - 2018-05-15 05:33:16 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:33:16 --> Router Class Initialized
DEBUG - 2018-05-15 05:33:16 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:33:16 --> Output Class Initialized
INFO - 2018-05-15 05:33:16 --> Utf8 Class Initialized
DEBUG - 2018-05-15 05:33:16 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:33:16 --> Output Class Initialized
INFO - 2018-05-15 05:33:17 --> Config Class Initialized
INFO - 2018-05-15 05:33:17 --> Security Class Initialized
INFO - 2018-05-15 05:33:17 --> Hooks Class Initialized
INFO - 2018-05-15 05:33:17 --> Security Class Initialized
INFO - 2018-05-15 05:33:17 --> Utf8 Class Initialized
INFO - 2018-05-15 05:33:17 --> URI Class Initialized
DEBUG - 2018-05-15 05:33:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:33:17 --> Input Class Initialized
DEBUG - 2018-05-15 05:33:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:33:17 --> URI Class Initialized
DEBUG - 2018-05-15 05:33:17 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:33:17 --> Router Class Initialized
INFO - 2018-05-15 05:33:17 --> Language Class Initialized
INFO - 2018-05-15 05:33:17 --> Input Class Initialized
INFO - 2018-05-15 05:33:17 --> Utf8 Class Initialized
INFO - 2018-05-15 05:33:17 --> Router Class Initialized
INFO - 2018-05-15 05:33:17 --> Output Class Initialized
INFO - 2018-05-15 05:33:17 --> Language Class Initialized
INFO - 2018-05-15 05:33:17 --> URI Class Initialized
ERROR - 2018-05-15 05:33:17 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:33:17 --> Output Class Initialized
INFO - 2018-05-15 05:33:17 --> Security Class Initialized
ERROR - 2018-05-15 05:33:17 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:33:17 --> Security Class Initialized
DEBUG - 2018-05-15 05:33:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:33:17 --> Config Class Initialized
INFO - 2018-05-15 05:33:17 --> Router Class Initialized
INFO - 2018-05-15 05:33:17 --> Hooks Class Initialized
INFO - 2018-05-15 05:33:17 --> Config Class Initialized
INFO - 2018-05-15 05:33:17 --> Output Class Initialized
INFO - 2018-05-15 05:33:17 --> Input Class Initialized
DEBUG - 2018-05-15 05:33:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:33:17 --> Hooks Class Initialized
INFO - 2018-05-15 05:33:17 --> Input Class Initialized
INFO - 2018-05-15 05:33:17 --> Security Class Initialized
INFO - 2018-05-15 05:33:17 --> Language Class Initialized
DEBUG - 2018-05-15 05:33:17 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 05:33:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:33:17 --> Language Class Initialized
DEBUG - 2018-05-15 05:33:17 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:33:17 --> Utf8 Class Initialized
ERROR - 2018-05-15 05:33:17 --> 404 Page Not Found: /index
ERROR - 2018-05-15 05:33:17 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:33:17 --> Utf8 Class Initialized
INFO - 2018-05-15 05:33:17 --> URI Class Initialized
INFO - 2018-05-15 05:33:17 --> Input Class Initialized
INFO - 2018-05-15 05:33:17 --> Config Class Initialized
INFO - 2018-05-15 05:33:17 --> Config Class Initialized
INFO - 2018-05-15 05:33:17 --> Hooks Class Initialized
INFO - 2018-05-15 05:33:17 --> Hooks Class Initialized
INFO - 2018-05-15 05:33:17 --> Language Class Initialized
INFO - 2018-05-15 05:33:17 --> URI Class Initialized
INFO - 2018-05-15 05:33:17 --> Router Class Initialized
DEBUG - 2018-05-15 05:33:17 --> UTF-8 Support Enabled
ERROR - 2018-05-15 05:33:17 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:33:17 --> Output Class Initialized
INFO - 2018-05-15 05:33:17 --> Router Class Initialized
DEBUG - 2018-05-15 05:33:17 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:33:17 --> Output Class Initialized
INFO - 2018-05-15 05:33:17 --> Utf8 Class Initialized
INFO - 2018-05-15 05:33:17 --> Utf8 Class Initialized
INFO - 2018-05-15 05:33:17 --> Security Class Initialized
INFO - 2018-05-15 05:33:17 --> URI Class Initialized
INFO - 2018-05-15 05:33:17 --> URI Class Initialized
DEBUG - 2018-05-15 05:33:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:33:17 --> Security Class Initialized
INFO - 2018-05-15 05:33:17 --> Router Class Initialized
INFO - 2018-05-15 05:33:17 --> Router Class Initialized
DEBUG - 2018-05-15 05:33:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:33:17 --> Input Class Initialized
INFO - 2018-05-15 05:33:17 --> Input Class Initialized
INFO - 2018-05-15 05:33:17 --> Output Class Initialized
INFO - 2018-05-15 05:33:17 --> Language Class Initialized
INFO - 2018-05-15 05:33:17 --> Output Class Initialized
INFO - 2018-05-15 05:33:17 --> Language Class Initialized
INFO - 2018-05-15 05:33:17 --> Config Class Initialized
INFO - 2018-05-15 05:33:17 --> Hooks Class Initialized
ERROR - 2018-05-15 05:33:17 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:33:17 --> Security Class Initialized
ERROR - 2018-05-15 05:33:17 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:33:17 --> Security Class Initialized
DEBUG - 2018-05-15 05:33:17 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:33:17 --> Utf8 Class Initialized
DEBUG - 2018-05-15 05:33:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-15 05:33:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:33:17 --> URI Class Initialized
INFO - 2018-05-15 05:33:17 --> Input Class Initialized
INFO - 2018-05-15 05:33:17 --> Input Class Initialized
INFO - 2018-05-15 05:33:17 --> Router Class Initialized
INFO - 2018-05-15 05:33:17 --> Language Class Initialized
INFO - 2018-05-15 05:33:17 --> Output Class Initialized
INFO - 2018-05-15 05:33:17 --> Language Class Initialized
ERROR - 2018-05-15 05:33:17 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:33:17 --> Security Class Initialized
ERROR - 2018-05-15 05:33:17 --> 404 Page Not Found: /index
DEBUG - 2018-05-15 05:33:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:33:17 --> Input Class Initialized
INFO - 2018-05-15 05:33:17 --> Language Class Initialized
ERROR - 2018-05-15 05:33:17 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:46:05 --> Config Class Initialized
INFO - 2018-05-15 05:46:05 --> Config Class Initialized
INFO - 2018-05-15 05:46:05 --> Config Class Initialized
INFO - 2018-05-15 05:46:05 --> Config Class Initialized
INFO - 2018-05-15 05:46:05 --> Config Class Initialized
INFO - 2018-05-15 05:46:05 --> Hooks Class Initialized
INFO - 2018-05-15 05:46:05 --> Hooks Class Initialized
DEBUG - 2018-05-15 05:46:05 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:46:05 --> Utf8 Class Initialized
INFO - 2018-05-15 05:46:05 --> Hooks Class Initialized
INFO - 2018-05-15 05:46:05 --> Hooks Class Initialized
INFO - 2018-05-15 05:46:05 --> Hooks Class Initialized
DEBUG - 2018-05-15 05:46:05 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:46:05 --> URI Class Initialized
DEBUG - 2018-05-15 05:46:05 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:46:06 --> Utf8 Class Initialized
INFO - 2018-05-15 05:46:06 --> Router Class Initialized
DEBUG - 2018-05-15 05:46:06 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 05:46:06 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:46:06 --> Utf8 Class Initialized
INFO - 2018-05-15 05:46:06 --> URI Class Initialized
INFO - 2018-05-15 05:46:06 --> Router Class Initialized
INFO - 2018-05-15 05:46:06 --> Utf8 Class Initialized
INFO - 2018-05-15 05:46:06 --> Output Class Initialized
INFO - 2018-05-15 05:46:06 --> Utf8 Class Initialized
INFO - 2018-05-15 05:46:06 --> Output Class Initialized
INFO - 2018-05-15 05:46:06 --> URI Class Initialized
INFO - 2018-05-15 05:46:06 --> Security Class Initialized
INFO - 2018-05-15 05:46:06 --> Security Class Initialized
INFO - 2018-05-15 05:46:06 --> URI Class Initialized
INFO - 2018-05-15 05:46:06 --> URI Class Initialized
INFO - 2018-05-15 05:46:06 --> Router Class Initialized
DEBUG - 2018-05-15 05:46:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:46:06 --> Router Class Initialized
DEBUG - 2018-05-15 05:46:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:46:06 --> Router Class Initialized
INFO - 2018-05-15 05:46:06 --> Output Class Initialized
INFO - 2018-05-15 05:46:06 --> Input Class Initialized
INFO - 2018-05-15 05:46:06 --> Output Class Initialized
INFO - 2018-05-15 05:46:06 --> Input Class Initialized
INFO - 2018-05-15 05:46:06 --> Security Class Initialized
INFO - 2018-05-15 05:46:06 --> Output Class Initialized
INFO - 2018-05-15 05:46:06 --> Security Class Initialized
INFO - 2018-05-15 05:46:06 --> Language Class Initialized
DEBUG - 2018-05-15 05:46:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:46:06 --> Language Class Initialized
INFO - 2018-05-15 05:46:06 --> Security Class Initialized
DEBUG - 2018-05-15 05:46:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-05-15 05:46:06 --> 404 Page Not Found: /index
DEBUG - 2018-05-15 05:46:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-05-15 05:46:06 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:46:06 --> Input Class Initialized
INFO - 2018-05-15 05:46:06 --> Input Class Initialized
INFO - 2018-05-15 05:46:06 --> Language Class Initialized
ERROR - 2018-05-15 05:46:06 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:46:06 --> Config Class Initialized
INFO - 2018-05-15 05:46:06 --> Hooks Class Initialized
INFO - 2018-05-15 05:46:06 --> Input Class Initialized
DEBUG - 2018-05-15 05:46:06 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:46:06 --> Config Class Initialized
INFO - 2018-05-15 05:46:06 --> Language Class Initialized
INFO - 2018-05-15 05:46:06 --> Utf8 Class Initialized
INFO - 2018-05-15 05:46:06 --> Hooks Class Initialized
INFO - 2018-05-15 05:46:06 --> Language Class Initialized
ERROR - 2018-05-15 05:46:06 --> 404 Page Not Found: /index
ERROR - 2018-05-15 05:46:06 --> 404 Page Not Found: /index
DEBUG - 2018-05-15 05:46:06 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:46:06 --> URI Class Initialized
INFO - 2018-05-15 05:46:06 --> Config Class Initialized
INFO - 2018-05-15 05:46:06 --> Hooks Class Initialized
INFO - 2018-05-15 05:46:06 --> Config Class Initialized
INFO - 2018-05-15 05:46:06 --> Hooks Class Initialized
DEBUG - 2018-05-15 05:46:06 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:46:06 --> Utf8 Class Initialized
INFO - 2018-05-15 05:46:06 --> Router Class Initialized
DEBUG - 2018-05-15 05:46:06 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:46:06 --> Output Class Initialized
INFO - 2018-05-15 05:46:06 --> URI Class Initialized
INFO - 2018-05-15 05:46:06 --> Utf8 Class Initialized
INFO - 2018-05-15 05:46:06 --> Utf8 Class Initialized
INFO - 2018-05-15 05:46:06 --> Security Class Initialized
INFO - 2018-05-15 05:46:06 --> URI Class Initialized
INFO - 2018-05-15 05:46:06 --> Router Class Initialized
INFO - 2018-05-15 05:46:06 --> URI Class Initialized
DEBUG - 2018-05-15 05:46:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:46:06 --> Input Class Initialized
INFO - 2018-05-15 05:46:06 --> Output Class Initialized
INFO - 2018-05-15 05:46:06 --> Router Class Initialized
INFO - 2018-05-15 05:46:06 --> Router Class Initialized
INFO - 2018-05-15 05:46:06 --> Output Class Initialized
INFO - 2018-05-15 05:46:06 --> Output Class Initialized
INFO - 2018-05-15 05:46:06 --> Security Class Initialized
INFO - 2018-05-15 05:46:06 --> Language Class Initialized
ERROR - 2018-05-15 05:46:06 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:46:06 --> Security Class Initialized
INFO - 2018-05-15 05:46:06 --> Security Class Initialized
DEBUG - 2018-05-15 05:46:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-15 05:46:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:46:06 --> Input Class Initialized
DEBUG - 2018-05-15 05:46:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:46:06 --> Config Class Initialized
INFO - 2018-05-15 05:46:06 --> Hooks Class Initialized
INFO - 2018-05-15 05:46:06 --> Language Class Initialized
INFO - 2018-05-15 05:46:06 --> Input Class Initialized
INFO - 2018-05-15 05:46:06 --> Input Class Initialized
ERROR - 2018-05-15 05:46:06 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:46:06 --> Language Class Initialized
INFO - 2018-05-15 05:46:06 --> Language Class Initialized
DEBUG - 2018-05-15 05:46:06 --> UTF-8 Support Enabled
ERROR - 2018-05-15 05:46:06 --> 404 Page Not Found: /index
ERROR - 2018-05-15 05:46:06 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:46:06 --> Utf8 Class Initialized
INFO - 2018-05-15 05:46:06 --> Config Class Initialized
INFO - 2018-05-15 05:46:06 --> Hooks Class Initialized
INFO - 2018-05-15 05:46:06 --> Config Class Initialized
INFO - 2018-05-15 05:46:06 --> URI Class Initialized
INFO - 2018-05-15 05:46:06 --> Config Class Initialized
INFO - 2018-05-15 05:46:06 --> Hooks Class Initialized
DEBUG - 2018-05-15 05:46:06 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:46:06 --> Router Class Initialized
INFO - 2018-05-15 05:46:07 --> Hooks Class Initialized
INFO - 2018-05-15 05:46:07 --> Utf8 Class Initialized
DEBUG - 2018-05-15 05:46:07 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:46:07 --> Output Class Initialized
DEBUG - 2018-05-15 05:46:07 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:46:07 --> Utf8 Class Initialized
INFO - 2018-05-15 05:46:07 --> Security Class Initialized
INFO - 2018-05-15 05:46:07 --> Utf8 Class Initialized
INFO - 2018-05-15 05:46:07 --> URI Class Initialized
INFO - 2018-05-15 05:46:07 --> URI Class Initialized
INFO - 2018-05-15 05:46:07 --> Router Class Initialized
DEBUG - 2018-05-15 05:46:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:46:07 --> Router Class Initialized
INFO - 2018-05-15 05:46:07 --> Output Class Initialized
INFO - 2018-05-15 05:46:07 --> Input Class Initialized
INFO - 2018-05-15 05:46:07 --> URI Class Initialized
INFO - 2018-05-15 05:46:07 --> Security Class Initialized
INFO - 2018-05-15 05:46:07 --> Output Class Initialized
INFO - 2018-05-15 05:46:07 --> Security Class Initialized
INFO - 2018-05-15 05:46:07 --> Router Class Initialized
INFO - 2018-05-15 05:46:07 --> Language Class Initialized
INFO - 2018-05-15 05:46:07 --> Output Class Initialized
DEBUG - 2018-05-15 05:46:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-15 05:46:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-05-15 05:46:07 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:46:07 --> Security Class Initialized
INFO - 2018-05-15 05:46:07 --> Input Class Initialized
INFO - 2018-05-15 05:46:07 --> Input Class Initialized
DEBUG - 2018-05-15 05:46:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:46:07 --> Language Class Initialized
INFO - 2018-05-15 05:46:07 --> Input Class Initialized
INFO - 2018-05-15 05:46:07 --> Language Class Initialized
INFO - 2018-05-15 05:46:07 --> Language Class Initialized
ERROR - 2018-05-15 05:46:07 --> 404 Page Not Found: /index
ERROR - 2018-05-15 05:46:07 --> 404 Page Not Found: /index
ERROR - 2018-05-15 05:46:07 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:54:58 --> Config Class Initialized
INFO - 2018-05-15 05:54:58 --> Hooks Class Initialized
DEBUG - 2018-05-15 05:54:58 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:54:58 --> Utf8 Class Initialized
INFO - 2018-05-15 05:54:58 --> URI Class Initialized
INFO - 2018-05-15 05:54:58 --> Router Class Initialized
INFO - 2018-05-15 05:54:58 --> Config Class Initialized
INFO - 2018-05-15 05:54:58 --> Hooks Class Initialized
INFO - 2018-05-15 05:54:58 --> Output Class Initialized
DEBUG - 2018-05-15 05:54:58 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:54:58 --> Utf8 Class Initialized
INFO - 2018-05-15 05:54:58 --> URI Class Initialized
INFO - 2018-05-15 05:54:58 --> Router Class Initialized
INFO - 2018-05-15 05:54:58 --> Output Class Initialized
INFO - 2018-05-15 05:54:58 --> Security Class Initialized
INFO - 2018-05-15 05:54:58 --> Security Class Initialized
DEBUG - 2018-05-15 05:54:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:54:58 --> Config Class Initialized
INFO - 2018-05-15 05:54:58 --> Config Class Initialized
INFO - 2018-05-15 05:54:58 --> Config Class Initialized
INFO - 2018-05-15 05:54:58 --> Config Class Initialized
INFO - 2018-05-15 05:54:58 --> Hooks Class Initialized
INFO - 2018-05-15 05:54:58 --> Hooks Class Initialized
INFO - 2018-05-15 05:54:58 --> Hooks Class Initialized
DEBUG - 2018-05-15 05:54:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-15 05:54:58 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:54:58 --> Hooks Class Initialized
INFO - 2018-05-15 05:54:58 --> Input Class Initialized
DEBUG - 2018-05-15 05:54:58 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:54:58 --> Language Class Initialized
INFO - 2018-05-15 05:54:58 --> Utf8 Class Initialized
DEBUG - 2018-05-15 05:54:58 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:54:58 --> Input Class Initialized
DEBUG - 2018-05-15 05:54:58 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:54:58 --> Utf8 Class Initialized
ERROR - 2018-05-15 05:54:58 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:54:59 --> Config Class Initialized
INFO - 2018-05-15 05:54:59 --> URI Class Initialized
INFO - 2018-05-15 05:54:59 --> Language Class Initialized
INFO - 2018-05-15 05:54:59 --> Utf8 Class Initialized
INFO - 2018-05-15 05:54:59 --> Utf8 Class Initialized
INFO - 2018-05-15 05:54:59 --> URI Class Initialized
ERROR - 2018-05-15 05:54:59 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:54:59 --> URI Class Initialized
INFO - 2018-05-15 05:54:59 --> Router Class Initialized
INFO - 2018-05-15 05:54:59 --> URI Class Initialized
INFO - 2018-05-15 05:54:59 --> Router Class Initialized
INFO - 2018-05-15 05:54:59 --> Hooks Class Initialized
DEBUG - 2018-05-15 05:54:59 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:54:59 --> Router Class Initialized
INFO - 2018-05-15 05:54:59 --> Output Class Initialized
INFO - 2018-05-15 05:54:59 --> Output Class Initialized
INFO - 2018-05-15 05:54:59 --> Router Class Initialized
INFO - 2018-05-15 05:54:59 --> Utf8 Class Initialized
INFO - 2018-05-15 05:54:59 --> Security Class Initialized
INFO - 2018-05-15 05:54:59 --> Security Class Initialized
INFO - 2018-05-15 05:54:59 --> Output Class Initialized
INFO - 2018-05-15 05:54:59 --> URI Class Initialized
INFO - 2018-05-15 05:54:59 --> Output Class Initialized
DEBUG - 2018-05-15 05:54:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:54:59 --> Security Class Initialized
INFO - 2018-05-15 05:54:59 --> Router Class Initialized
INFO - 2018-05-15 05:54:59 --> Security Class Initialized
DEBUG - 2018-05-15 05:54:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:54:59 --> Input Class Initialized
INFO - 2018-05-15 05:54:59 --> Input Class Initialized
DEBUG - 2018-05-15 05:54:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:54:59 --> Output Class Initialized
INFO - 2018-05-15 05:54:59 --> Language Class Initialized
DEBUG - 2018-05-15 05:54:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:54:59 --> Input Class Initialized
ERROR - 2018-05-15 05:54:59 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:54:59 --> Security Class Initialized
INFO - 2018-05-15 05:54:59 --> Input Class Initialized
INFO - 2018-05-15 05:54:59 --> Language Class Initialized
INFO - 2018-05-15 05:54:59 --> Language Class Initialized
ERROR - 2018-05-15 05:54:59 --> 404 Page Not Found: /index
ERROR - 2018-05-15 05:54:59 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:54:59 --> Config Class Initialized
INFO - 2018-05-15 05:54:59 --> Config Class Initialized
DEBUG - 2018-05-15 05:54:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:54:59 --> Language Class Initialized
INFO - 2018-05-15 05:54:59 --> Hooks Class Initialized
INFO - 2018-05-15 05:54:59 --> Config Class Initialized
ERROR - 2018-05-15 05:54:59 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:54:59 --> Input Class Initialized
INFO - 2018-05-15 05:54:59 --> Hooks Class Initialized
INFO - 2018-05-15 05:54:59 --> Hooks Class Initialized
DEBUG - 2018-05-15 05:54:59 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 05:54:59 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:54:59 --> Language Class Initialized
ERROR - 2018-05-15 05:54:59 --> 404 Page Not Found: /index
DEBUG - 2018-05-15 05:54:59 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:54:59 --> Config Class Initialized
INFO - 2018-05-15 05:54:59 --> Hooks Class Initialized
INFO - 2018-05-15 05:54:59 --> Utf8 Class Initialized
DEBUG - 2018-05-15 05:54:59 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:54:59 --> Utf8 Class Initialized
INFO - 2018-05-15 05:54:59 --> Utf8 Class Initialized
INFO - 2018-05-15 05:54:59 --> Utf8 Class Initialized
INFO - 2018-05-15 05:54:59 --> URI Class Initialized
INFO - 2018-05-15 05:54:59 --> URI Class Initialized
INFO - 2018-05-15 05:54:59 --> URI Class Initialized
INFO - 2018-05-15 05:54:59 --> Router Class Initialized
INFO - 2018-05-15 05:54:59 --> URI Class Initialized
INFO - 2018-05-15 05:54:59 --> Router Class Initialized
INFO - 2018-05-15 05:54:59 --> Output Class Initialized
INFO - 2018-05-15 05:54:59 --> Router Class Initialized
INFO - 2018-05-15 05:54:59 --> Router Class Initialized
INFO - 2018-05-15 05:54:59 --> Security Class Initialized
INFO - 2018-05-15 05:54:59 --> Output Class Initialized
INFO - 2018-05-15 05:54:59 --> Output Class Initialized
INFO - 2018-05-15 05:54:59 --> Output Class Initialized
DEBUG - 2018-05-15 05:54:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:54:59 --> Security Class Initialized
INFO - 2018-05-15 05:54:59 --> Security Class Initialized
INFO - 2018-05-15 05:54:59 --> Input Class Initialized
INFO - 2018-05-15 05:54:59 --> Security Class Initialized
DEBUG - 2018-05-15 05:54:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:54:59 --> Input Class Initialized
INFO - 2018-05-15 05:55:00 --> Language Class Initialized
DEBUG - 2018-05-15 05:55:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-15 05:55:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:55:00 --> Language Class Initialized
ERROR - 2018-05-15 05:55:00 --> 404 Page Not Found: /index
ERROR - 2018-05-15 05:55:00 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:55:00 --> Config Class Initialized
INFO - 2018-05-15 05:55:00 --> Config Class Initialized
INFO - 2018-05-15 05:55:00 --> Input Class Initialized
INFO - 2018-05-15 05:55:00 --> Input Class Initialized
INFO - 2018-05-15 05:55:00 --> Hooks Class Initialized
DEBUG - 2018-05-15 05:55:00 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:55:00 --> Language Class Initialized
INFO - 2018-05-15 05:55:00 --> Language Class Initialized
INFO - 2018-05-15 05:55:00 --> Hooks Class Initialized
INFO - 2018-05-15 05:55:00 --> Utf8 Class Initialized
ERROR - 2018-05-15 05:55:00 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:55:00 --> URI Class Initialized
ERROR - 2018-05-15 05:55:00 --> 404 Page Not Found: /index
DEBUG - 2018-05-15 05:55:00 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:55:00 --> Config Class Initialized
INFO - 2018-05-15 05:55:00 --> Router Class Initialized
INFO - 2018-05-15 05:55:00 --> Hooks Class Initialized
INFO - 2018-05-15 05:55:00 --> Utf8 Class Initialized
INFO - 2018-05-15 05:55:00 --> Config Class Initialized
INFO - 2018-05-15 05:55:00 --> Hooks Class Initialized
INFO - 2018-05-15 05:55:00 --> Output Class Initialized
DEBUG - 2018-05-15 05:55:00 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:55:00 --> URI Class Initialized
DEBUG - 2018-05-15 05:55:00 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:55:00 --> Router Class Initialized
INFO - 2018-05-15 05:55:00 --> Security Class Initialized
INFO - 2018-05-15 05:55:00 --> Utf8 Class Initialized
INFO - 2018-05-15 05:55:00 --> URI Class Initialized
INFO - 2018-05-15 05:55:00 --> Utf8 Class Initialized
DEBUG - 2018-05-15 05:55:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:55:00 --> Output Class Initialized
INFO - 2018-05-15 05:55:00 --> Router Class Initialized
INFO - 2018-05-15 05:55:00 --> Input Class Initialized
INFO - 2018-05-15 05:55:00 --> Security Class Initialized
INFO - 2018-05-15 05:55:00 --> Output Class Initialized
INFO - 2018-05-15 05:55:00 --> URI Class Initialized
INFO - 2018-05-15 05:55:00 --> Language Class Initialized
DEBUG - 2018-05-15 05:55:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:55:00 --> Security Class Initialized
INFO - 2018-05-15 05:55:00 --> Router Class Initialized
ERROR - 2018-05-15 05:55:00 --> 404 Page Not Found: /index
DEBUG - 2018-05-15 05:55:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:55:00 --> Output Class Initialized
INFO - 2018-05-15 05:55:00 --> Input Class Initialized
INFO - 2018-05-15 05:55:00 --> Input Class Initialized
INFO - 2018-05-15 05:55:00 --> Security Class Initialized
INFO - 2018-05-15 05:55:00 --> Language Class Initialized
DEBUG - 2018-05-15 05:55:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:55:00 --> Language Class Initialized
ERROR - 2018-05-15 05:55:00 --> 404 Page Not Found: /index
ERROR - 2018-05-15 05:55:00 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:55:00 --> Input Class Initialized
INFO - 2018-05-15 05:55:00 --> Language Class Initialized
ERROR - 2018-05-15 05:55:00 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:55:08 --> Config Class Initialized
INFO - 2018-05-15 05:55:08 --> Config Class Initialized
INFO - 2018-05-15 05:55:08 --> Config Class Initialized
INFO - 2018-05-15 05:55:08 --> Config Class Initialized
INFO - 2018-05-15 05:55:08 --> Config Class Initialized
INFO - 2018-05-15 05:55:08 --> Hooks Class Initialized
INFO - 2018-05-15 05:55:09 --> Hooks Class Initialized
INFO - 2018-05-15 05:55:09 --> Hooks Class Initialized
INFO - 2018-05-15 05:55:09 --> Hooks Class Initialized
INFO - 2018-05-15 05:55:09 --> Hooks Class Initialized
DEBUG - 2018-05-15 05:55:09 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 05:55:09 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:55:09 --> Utf8 Class Initialized
DEBUG - 2018-05-15 05:55:09 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:55:09 --> Utf8 Class Initialized
INFO - 2018-05-15 05:55:09 --> URI Class Initialized
DEBUG - 2018-05-15 05:55:09 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 05:55:09 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:55:09 --> Utf8 Class Initialized
INFO - 2018-05-15 05:55:09 --> URI Class Initialized
INFO - 2018-05-15 05:55:09 --> Utf8 Class Initialized
INFO - 2018-05-15 05:55:09 --> Utf8 Class Initialized
INFO - 2018-05-15 05:55:09 --> URI Class Initialized
INFO - 2018-05-15 05:55:09 --> Router Class Initialized
INFO - 2018-05-15 05:55:09 --> Router Class Initialized
INFO - 2018-05-15 05:55:09 --> URI Class Initialized
INFO - 2018-05-15 05:55:09 --> Router Class Initialized
INFO - 2018-05-15 05:55:09 --> Output Class Initialized
INFO - 2018-05-15 05:55:09 --> URI Class Initialized
INFO - 2018-05-15 05:55:09 --> Output Class Initialized
INFO - 2018-05-15 05:55:09 --> Security Class Initialized
INFO - 2018-05-15 05:55:09 --> Output Class Initialized
INFO - 2018-05-15 05:55:09 --> Router Class Initialized
INFO - 2018-05-15 05:55:09 --> Security Class Initialized
INFO - 2018-05-15 05:55:09 --> Router Class Initialized
DEBUG - 2018-05-15 05:55:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:55:09 --> Input Class Initialized
INFO - 2018-05-15 05:55:09 --> Security Class Initialized
INFO - 2018-05-15 05:55:09 --> Output Class Initialized
DEBUG - 2018-05-15 05:55:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:55:09 --> Language Class Initialized
INFO - 2018-05-15 05:55:09 --> Output Class Initialized
INFO - 2018-05-15 05:55:09 --> Security Class Initialized
INFO - 2018-05-15 05:55:09 --> Security Class Initialized
INFO - 2018-05-15 05:55:09 --> Input Class Initialized
DEBUG - 2018-05-15 05:55:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-05-15 05:55:09 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:55:09 --> Language Class Initialized
DEBUG - 2018-05-15 05:55:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:55:09 --> Input Class Initialized
INFO - 2018-05-15 05:55:09 --> Config Class Initialized
DEBUG - 2018-05-15 05:55:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:55:09 --> Hooks Class Initialized
ERROR - 2018-05-15 05:55:09 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:55:09 --> Input Class Initialized
INFO - 2018-05-15 05:55:09 --> Language Class Initialized
INFO - 2018-05-15 05:55:09 --> Input Class Initialized
INFO - 2018-05-15 05:55:09 --> Language Class Initialized
DEBUG - 2018-05-15 05:55:09 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:55:09 --> Config Class Initialized
INFO - 2018-05-15 05:55:09 --> Language Class Initialized
ERROR - 2018-05-15 05:55:09 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:55:09 --> Hooks Class Initialized
ERROR - 2018-05-15 05:55:09 --> 404 Page Not Found: /index
ERROR - 2018-05-15 05:55:09 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:55:09 --> Config Class Initialized
INFO - 2018-05-15 05:55:09 --> Utf8 Class Initialized
DEBUG - 2018-05-15 05:55:09 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:55:09 --> Hooks Class Initialized
INFO - 2018-05-15 05:55:09 --> Config Class Initialized
DEBUG - 2018-05-15 05:55:09 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:55:09 --> Hooks Class Initialized
INFO - 2018-05-15 05:55:09 --> Utf8 Class Initialized
INFO - 2018-05-15 05:55:09 --> Utf8 Class Initialized
INFO - 2018-05-15 05:55:09 --> URI Class Initialized
INFO - 2018-05-15 05:55:10 --> URI Class Initialized
INFO - 2018-05-15 05:55:10 --> Router Class Initialized
DEBUG - 2018-05-15 05:55:10 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:55:10 --> URI Class Initialized
INFO - 2018-05-15 05:55:10 --> Utf8 Class Initialized
INFO - 2018-05-15 05:55:10 --> Output Class Initialized
INFO - 2018-05-15 05:55:10 --> Router Class Initialized
INFO - 2018-05-15 05:55:10 --> URI Class Initialized
INFO - 2018-05-15 05:55:10 --> Router Class Initialized
INFO - 2018-05-15 05:55:10 --> Security Class Initialized
INFO - 2018-05-15 05:55:10 --> Output Class Initialized
INFO - 2018-05-15 05:55:10 --> Output Class Initialized
INFO - 2018-05-15 05:55:10 --> Router Class Initialized
INFO - 2018-05-15 05:55:10 --> Security Class Initialized
INFO - 2018-05-15 05:55:10 --> Output Class Initialized
DEBUG - 2018-05-15 05:55:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:55:10 --> Security Class Initialized
DEBUG - 2018-05-15 05:55:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-15 05:55:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:55:10 --> Input Class Initialized
INFO - 2018-05-15 05:55:10 --> Security Class Initialized
INFO - 2018-05-15 05:55:10 --> Input Class Initialized
INFO - 2018-05-15 05:55:10 --> Language Class Initialized
INFO - 2018-05-15 05:55:10 --> Input Class Initialized
DEBUG - 2018-05-15 05:55:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:55:10 --> Input Class Initialized
INFO - 2018-05-15 05:55:10 --> Language Class Initialized
ERROR - 2018-05-15 05:55:10 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:55:10 --> Language Class Initialized
INFO - 2018-05-15 05:55:10 --> Config Class Initialized
INFO - 2018-05-15 05:55:10 --> Language Class Initialized
ERROR - 2018-05-15 05:55:10 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:55:10 --> Hooks Class Initialized
ERROR - 2018-05-15 05:55:10 --> 404 Page Not Found: /index
ERROR - 2018-05-15 05:55:10 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:55:10 --> Config Class Initialized
DEBUG - 2018-05-15 05:55:10 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:55:10 --> Config Class Initialized
INFO - 2018-05-15 05:55:10 --> Hooks Class Initialized
INFO - 2018-05-15 05:55:10 --> Hooks Class Initialized
INFO - 2018-05-15 05:55:10 --> Config Class Initialized
INFO - 2018-05-15 05:55:10 --> Utf8 Class Initialized
INFO - 2018-05-15 05:55:10 --> Hooks Class Initialized
DEBUG - 2018-05-15 05:55:10 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:55:10 --> URI Class Initialized
DEBUG - 2018-05-15 05:55:10 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:55:10 --> Utf8 Class Initialized
INFO - 2018-05-15 05:55:10 --> Utf8 Class Initialized
INFO - 2018-05-15 05:55:10 --> Router Class Initialized
DEBUG - 2018-05-15 05:55:10 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:55:10 --> Utf8 Class Initialized
INFO - 2018-05-15 05:55:10 --> URI Class Initialized
INFO - 2018-05-15 05:55:10 --> Output Class Initialized
INFO - 2018-05-15 05:55:10 --> URI Class Initialized
INFO - 2018-05-15 05:55:10 --> Router Class Initialized
INFO - 2018-05-15 05:55:10 --> Router Class Initialized
INFO - 2018-05-15 05:55:10 --> URI Class Initialized
INFO - 2018-05-15 05:55:10 --> Security Class Initialized
INFO - 2018-05-15 05:55:10 --> Output Class Initialized
INFO - 2018-05-15 05:55:10 --> Router Class Initialized
INFO - 2018-05-15 05:55:10 --> Output Class Initialized
DEBUG - 2018-05-15 05:55:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:55:10 --> Input Class Initialized
INFO - 2018-05-15 05:55:10 --> Security Class Initialized
INFO - 2018-05-15 05:55:10 --> Security Class Initialized
INFO - 2018-05-15 05:55:10 --> Output Class Initialized
DEBUG - 2018-05-15 05:55:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-15 05:55:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:55:10 --> Language Class Initialized
INFO - 2018-05-15 05:55:10 --> Security Class Initialized
INFO - 2018-05-15 05:55:10 --> Input Class Initialized
ERROR - 2018-05-15 05:55:10 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:55:10 --> Input Class Initialized
DEBUG - 2018-05-15 05:55:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:55:10 --> Input Class Initialized
INFO - 2018-05-15 05:55:10 --> Language Class Initialized
INFO - 2018-05-15 05:55:10 --> Language Class Initialized
ERROR - 2018-05-15 05:55:10 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:55:10 --> Language Class Initialized
ERROR - 2018-05-15 05:55:10 --> 404 Page Not Found: /index
ERROR - 2018-05-15 05:55:10 --> 404 Page Not Found: /index
INFO - 2018-05-15 05:56:37 --> Config Class Initialized
INFO - 2018-05-15 05:56:37 --> Hooks Class Initialized
DEBUG - 2018-05-15 05:56:37 --> UTF-8 Support Enabled
INFO - 2018-05-15 05:56:37 --> Utf8 Class Initialized
INFO - 2018-05-15 05:56:37 --> URI Class Initialized
INFO - 2018-05-15 05:56:37 --> Router Class Initialized
INFO - 2018-05-15 05:56:37 --> Output Class Initialized
INFO - 2018-05-15 05:56:37 --> Security Class Initialized
DEBUG - 2018-05-15 05:56:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 05:56:37 --> Input Class Initialized
INFO - 2018-05-15 05:56:37 --> Language Class Initialized
ERROR - 2018-05-15 05:56:37 --> 404 Page Not Found: /index
INFO - 2018-05-15 21:28:21 --> Config Class Initialized
INFO - 2018-05-15 21:28:22 --> Hooks Class Initialized
DEBUG - 2018-05-15 21:28:22 --> UTF-8 Support Enabled
INFO - 2018-05-15 21:28:22 --> Utf8 Class Initialized
INFO - 2018-05-15 21:28:22 --> URI Class Initialized
INFO - 2018-05-15 21:28:22 --> Router Class Initialized
INFO - 2018-05-15 21:28:22 --> Output Class Initialized
INFO - 2018-05-15 21:28:22 --> Security Class Initialized
DEBUG - 2018-05-15 21:28:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 21:28:22 --> Input Class Initialized
INFO - 2018-05-15 21:28:22 --> Language Class Initialized
INFO - 2018-05-15 21:28:23 --> Language Class Initialized
INFO - 2018-05-15 21:28:23 --> Config Class Initialized
INFO - 2018-05-15 21:28:23 --> Loader Class Initialized
DEBUG - 2018-05-15 21:28:23 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-15 21:28:23 --> Helper loaded: url_helper
INFO - 2018-05-15 21:28:23 --> Helper loaded: form_helper
INFO - 2018-05-15 21:28:23 --> Helper loaded: date_helper
INFO - 2018-05-15 21:28:23 --> Helper loaded: util_helper
INFO - 2018-05-15 21:28:23 --> Helper loaded: text_helper
INFO - 2018-05-15 21:28:23 --> Helper loaded: string_helper
INFO - 2018-05-15 21:28:23 --> Database Driver Class Initialized
DEBUG - 2018-05-15 21:28:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-15 21:28:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-15 21:28:24 --> Email Class Initialized
INFO - 2018-05-15 21:28:24 --> Controller Class Initialized
DEBUG - 2018-05-15 21:28:24 --> Home MX_Controller Initialized
DEBUG - 2018-05-15 21:28:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-15 21:28:24 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-15 21:28:24 --> Login MX_Controller Initialized
INFO - 2018-05-15 21:28:24 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-15 21:28:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-15 21:28:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-15 21:28:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/login.php
INFO - 2018-05-15 21:31:49 --> Config Class Initialized
INFO - 2018-05-15 21:31:49 --> Hooks Class Initialized
DEBUG - 2018-05-15 21:31:49 --> UTF-8 Support Enabled
INFO - 2018-05-15 21:31:49 --> Utf8 Class Initialized
INFO - 2018-05-15 21:31:49 --> URI Class Initialized
INFO - 2018-05-15 21:31:49 --> Router Class Initialized
INFO - 2018-05-15 21:31:49 --> Output Class Initialized
INFO - 2018-05-15 21:31:49 --> Security Class Initialized
DEBUG - 2018-05-15 21:31:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 21:31:49 --> Input Class Initialized
INFO - 2018-05-15 21:31:49 --> Language Class Initialized
INFO - 2018-05-15 21:31:49 --> Language Class Initialized
INFO - 2018-05-15 21:31:49 --> Config Class Initialized
INFO - 2018-05-15 21:31:49 --> Loader Class Initialized
DEBUG - 2018-05-15 21:31:49 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-15 21:31:49 --> Helper loaded: url_helper
INFO - 2018-05-15 21:31:49 --> Helper loaded: form_helper
INFO - 2018-05-15 21:31:49 --> Helper loaded: date_helper
INFO - 2018-05-15 21:31:49 --> Helper loaded: util_helper
INFO - 2018-05-15 21:31:49 --> Helper loaded: text_helper
INFO - 2018-05-15 21:31:50 --> Helper loaded: string_helper
INFO - 2018-05-15 21:31:50 --> Database Driver Class Initialized
DEBUG - 2018-05-15 21:31:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-15 21:31:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-15 21:31:50 --> Email Class Initialized
INFO - 2018-05-15 21:31:50 --> Controller Class Initialized
DEBUG - 2018-05-15 21:31:50 --> Login MX_Controller Initialized
INFO - 2018-05-15 21:31:50 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-15 21:31:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-15 21:31:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-15 21:31:50 --> Email starts for gopipanguluri123@gmail.com fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-05-15 21:31:50 --> User session created for 4
INFO - 2018-05-15 21:31:50 --> Login status gopipanguluri123@gmail.com - success
INFO - 2018-05-15 21:31:50 --> Final output sent to browser
DEBUG - 2018-05-15 21:31:50 --> Total execution time: 0.9736
INFO - 2018-05-15 21:31:51 --> Config Class Initialized
INFO - 2018-05-15 21:31:51 --> Hooks Class Initialized
DEBUG - 2018-05-15 21:31:51 --> UTF-8 Support Enabled
INFO - 2018-05-15 21:31:51 --> Utf8 Class Initialized
INFO - 2018-05-15 21:31:51 --> URI Class Initialized
INFO - 2018-05-15 21:31:51 --> Router Class Initialized
INFO - 2018-05-15 21:31:51 --> Output Class Initialized
INFO - 2018-05-15 21:31:51 --> Security Class Initialized
DEBUG - 2018-05-15 21:31:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 21:31:51 --> Input Class Initialized
INFO - 2018-05-15 21:31:51 --> Language Class Initialized
INFO - 2018-05-15 21:31:51 --> Language Class Initialized
INFO - 2018-05-15 21:31:51 --> Config Class Initialized
INFO - 2018-05-15 21:31:51 --> Loader Class Initialized
DEBUG - 2018-05-15 21:31:51 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-15 21:31:51 --> Helper loaded: url_helper
INFO - 2018-05-15 21:31:51 --> Helper loaded: form_helper
INFO - 2018-05-15 21:31:51 --> Helper loaded: date_helper
INFO - 2018-05-15 21:31:51 --> Helper loaded: util_helper
INFO - 2018-05-15 21:31:51 --> Helper loaded: text_helper
INFO - 2018-05-15 21:31:51 --> Helper loaded: string_helper
INFO - 2018-05-15 21:31:51 --> Database Driver Class Initialized
DEBUG - 2018-05-15 21:31:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-15 21:31:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-15 21:31:51 --> Email Class Initialized
INFO - 2018-05-15 21:31:51 --> Controller Class Initialized
DEBUG - 2018-05-15 21:31:51 --> Home MX_Controller Initialized
DEBUG - 2018-05-15 21:31:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-15 21:31:51 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-15 21:31:51 --> Login MX_Controller Initialized
INFO - 2018-05-15 21:31:51 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-15 21:31:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-15 21:31:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-15 21:31:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-05-15 21:31:51 --> Final output sent to browser
DEBUG - 2018-05-15 21:31:51 --> Total execution time: 0.8637
INFO - 2018-05-15 21:31:51 --> Config Class Initialized
INFO - 2018-05-15 21:31:51 --> Hooks Class Initialized
DEBUG - 2018-05-15 21:31:52 --> UTF-8 Support Enabled
INFO - 2018-05-15 21:31:52 --> Utf8 Class Initialized
INFO - 2018-05-15 21:31:52 --> URI Class Initialized
INFO - 2018-05-15 21:31:52 --> Router Class Initialized
INFO - 2018-05-15 21:31:52 --> Output Class Initialized
INFO - 2018-05-15 21:31:52 --> Security Class Initialized
DEBUG - 2018-05-15 21:31:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 21:31:52 --> Input Class Initialized
INFO - 2018-05-15 21:31:52 --> Language Class Initialized
ERROR - 2018-05-15 21:31:52 --> 404 Page Not Found: /index
INFO - 2018-05-15 21:31:53 --> Config Class Initialized
INFO - 2018-05-15 21:31:53 --> Config Class Initialized
INFO - 2018-05-15 21:31:53 --> Config Class Initialized
INFO - 2018-05-15 21:31:53 --> Config Class Initialized
INFO - 2018-05-15 21:31:53 --> Config Class Initialized
INFO - 2018-05-15 21:31:53 --> Hooks Class Initialized
INFO - 2018-05-15 21:31:53 --> Hooks Class Initialized
INFO - 2018-05-15 21:31:53 --> Hooks Class Initialized
INFO - 2018-05-15 21:31:53 --> Hooks Class Initialized
INFO - 2018-05-15 21:31:53 --> Hooks Class Initialized
DEBUG - 2018-05-15 21:31:53 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 21:31:53 --> UTF-8 Support Enabled
INFO - 2018-05-15 21:31:53 --> Utf8 Class Initialized
INFO - 2018-05-15 21:31:53 --> Config Class Initialized
DEBUG - 2018-05-15 21:31:53 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 21:31:53 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 21:31:53 --> UTF-8 Support Enabled
INFO - 2018-05-15 21:31:53 --> Hooks Class Initialized
INFO - 2018-05-15 21:31:53 --> Utf8 Class Initialized
INFO - 2018-05-15 21:31:53 --> Utf8 Class Initialized
INFO - 2018-05-15 21:31:53 --> Utf8 Class Initialized
INFO - 2018-05-15 21:31:53 --> Utf8 Class Initialized
INFO - 2018-05-15 21:31:53 --> URI Class Initialized
DEBUG - 2018-05-15 21:31:53 --> UTF-8 Support Enabled
INFO - 2018-05-15 21:31:53 --> Router Class Initialized
INFO - 2018-05-15 21:31:53 --> URI Class Initialized
INFO - 2018-05-15 21:31:53 --> URI Class Initialized
INFO - 2018-05-15 21:31:53 --> URI Class Initialized
INFO - 2018-05-15 21:31:53 --> URI Class Initialized
INFO - 2018-05-15 21:31:53 --> Output Class Initialized
INFO - 2018-05-15 21:31:53 --> Utf8 Class Initialized
INFO - 2018-05-15 21:31:53 --> Router Class Initialized
INFO - 2018-05-15 21:31:53 --> Router Class Initialized
INFO - 2018-05-15 21:31:53 --> Router Class Initialized
INFO - 2018-05-15 21:31:53 --> Router Class Initialized
INFO - 2018-05-15 21:31:53 --> Security Class Initialized
DEBUG - 2018-05-15 21:31:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 21:31:53 --> Input Class Initialized
INFO - 2018-05-15 21:31:53 --> Language Class Initialized
ERROR - 2018-05-15 21:31:53 --> 404 Page Not Found: /index
INFO - 2018-05-15 21:31:53 --> Output Class Initialized
INFO - 2018-05-15 21:31:53 --> Security Class Initialized
DEBUG - 2018-05-15 21:31:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 21:31:53 --> Input Class Initialized
INFO - 2018-05-15 21:31:53 --> URI Class Initialized
INFO - 2018-05-15 21:31:53 --> Output Class Initialized
INFO - 2018-05-15 21:31:53 --> Output Class Initialized
INFO - 2018-05-15 21:31:53 --> Output Class Initialized
INFO - 2018-05-15 21:31:53 --> Language Class Initialized
INFO - 2018-05-15 21:31:53 --> Security Class Initialized
INFO - 2018-05-15 21:31:53 --> Router Class Initialized
INFO - 2018-05-15 21:31:53 --> Security Class Initialized
INFO - 2018-05-15 21:31:53 --> Security Class Initialized
ERROR - 2018-05-15 21:31:53 --> 404 Page Not Found: /index
DEBUG - 2018-05-15 21:31:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-15 21:31:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 21:31:53 --> Output Class Initialized
DEBUG - 2018-05-15 21:31:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 21:31:53 --> Input Class Initialized
INFO - 2018-05-15 21:31:53 --> Input Class Initialized
INFO - 2018-05-15 21:31:53 --> Config Class Initialized
INFO - 2018-05-15 21:31:53 --> Input Class Initialized
INFO - 2018-05-15 21:31:53 --> Security Class Initialized
INFO - 2018-05-15 21:31:53 --> Hooks Class Initialized
INFO - 2018-05-15 21:31:53 --> Language Class Initialized
INFO - 2018-05-15 21:31:53 --> Language Class Initialized
INFO - 2018-05-15 21:31:53 --> Language Class Initialized
DEBUG - 2018-05-15 21:31:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 21:31:53 --> Input Class Initialized
ERROR - 2018-05-15 21:31:53 --> 404 Page Not Found: /index
ERROR - 2018-05-15 21:31:53 --> 404 Page Not Found: /index
DEBUG - 2018-05-15 21:31:53 --> UTF-8 Support Enabled
ERROR - 2018-05-15 21:31:53 --> 404 Page Not Found: /index
INFO - 2018-05-15 21:31:53 --> Config Class Initialized
INFO - 2018-05-15 21:31:53 --> Config Class Initialized
INFO - 2018-05-15 21:31:53 --> Utf8 Class Initialized
INFO - 2018-05-15 21:31:53 --> Language Class Initialized
INFO - 2018-05-15 21:31:53 --> Hooks Class Initialized
INFO - 2018-05-15 21:31:53 --> Hooks Class Initialized
ERROR - 2018-05-15 21:31:53 --> 404 Page Not Found: /index
INFO - 2018-05-15 21:31:53 --> URI Class Initialized
INFO - 2018-05-15 21:31:53 --> Config Class Initialized
INFO - 2018-05-15 21:31:53 --> Hooks Class Initialized
DEBUG - 2018-05-15 21:31:53 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 21:31:53 --> UTF-8 Support Enabled
INFO - 2018-05-15 21:31:53 --> Router Class Initialized
INFO - 2018-05-15 21:31:53 --> Config Class Initialized
INFO - 2018-05-15 21:31:53 --> Hooks Class Initialized
DEBUG - 2018-05-15 21:31:53 --> UTF-8 Support Enabled
INFO - 2018-05-15 21:31:53 --> Utf8 Class Initialized
INFO - 2018-05-15 21:31:53 --> Utf8 Class Initialized
INFO - 2018-05-15 21:31:53 --> Utf8 Class Initialized
INFO - 2018-05-15 21:31:53 --> Output Class Initialized
DEBUG - 2018-05-15 21:31:53 --> UTF-8 Support Enabled
INFO - 2018-05-15 21:31:53 --> Utf8 Class Initialized
INFO - 2018-05-15 21:31:53 --> URI Class Initialized
INFO - 2018-05-15 21:31:53 --> URI Class Initialized
INFO - 2018-05-15 21:31:53 --> URI Class Initialized
INFO - 2018-05-15 21:31:53 --> Security Class Initialized
INFO - 2018-05-15 21:31:54 --> URI Class Initialized
INFO - 2018-05-15 21:31:54 --> Router Class Initialized
INFO - 2018-05-15 21:31:54 --> Output Class Initialized
INFO - 2018-05-15 21:31:54 --> Router Class Initialized
DEBUG - 2018-05-15 21:31:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 21:31:54 --> Router Class Initialized
INFO - 2018-05-15 21:31:54 --> Router Class Initialized
INFO - 2018-05-15 21:31:54 --> Security Class Initialized
INFO - 2018-05-15 21:31:54 --> Output Class Initialized
INFO - 2018-05-15 21:31:54 --> Output Class Initialized
INFO - 2018-05-15 21:31:54 --> Output Class Initialized
INFO - 2018-05-15 21:31:54 --> Input Class Initialized
INFO - 2018-05-15 21:31:54 --> Security Class Initialized
INFO - 2018-05-15 21:31:54 --> Security Class Initialized
INFO - 2018-05-15 21:31:54 --> Security Class Initialized
INFO - 2018-05-15 21:31:54 --> Language Class Initialized
DEBUG - 2018-05-15 21:31:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-15 21:31:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-15 21:31:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-05-15 21:31:54 --> 404 Page Not Found: /index
INFO - 2018-05-15 21:31:54 --> Input Class Initialized
DEBUG - 2018-05-15 21:31:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 21:31:54 --> Input Class Initialized
INFO - 2018-05-15 21:31:54 --> Input Class Initialized
INFO - 2018-05-15 21:31:54 --> Language Class Initialized
INFO - 2018-05-15 21:31:54 --> Input Class Initialized
INFO - 2018-05-15 21:31:54 --> Config Class Initialized
INFO - 2018-05-15 21:31:54 --> Hooks Class Initialized
INFO - 2018-05-15 21:31:54 --> Language Class Initialized
INFO - 2018-05-15 21:31:54 --> Language Class Initialized
ERROR - 2018-05-15 21:31:54 --> 404 Page Not Found: /index
INFO - 2018-05-15 21:31:54 --> Language Class Initialized
ERROR - 2018-05-15 21:31:54 --> 404 Page Not Found: /index
ERROR - 2018-05-15 21:31:54 --> 404 Page Not Found: /index
DEBUG - 2018-05-15 21:31:54 --> UTF-8 Support Enabled
ERROR - 2018-05-15 21:31:54 --> 404 Page Not Found: /index
INFO - 2018-05-15 21:31:54 --> Utf8 Class Initialized
INFO - 2018-05-15 21:31:54 --> Config Class Initialized
INFO - 2018-05-15 21:31:54 --> Config Class Initialized
INFO - 2018-05-15 21:31:54 --> Config Class Initialized
INFO - 2018-05-15 21:31:54 --> Hooks Class Initialized
INFO - 2018-05-15 21:31:54 --> Hooks Class Initialized
INFO - 2018-05-15 21:31:54 --> Hooks Class Initialized
INFO - 2018-05-15 21:31:54 --> URI Class Initialized
DEBUG - 2018-05-15 21:31:54 --> UTF-8 Support Enabled
INFO - 2018-05-15 21:31:54 --> Config Class Initialized
DEBUG - 2018-05-15 21:31:54 --> UTF-8 Support Enabled
INFO - 2018-05-15 21:31:54 --> Hooks Class Initialized
INFO - 2018-05-15 21:31:54 --> Utf8 Class Initialized
INFO - 2018-05-15 21:31:54 --> Utf8 Class Initialized
DEBUG - 2018-05-15 21:31:54 --> UTF-8 Support Enabled
INFO - 2018-05-15 21:31:54 --> Router Class Initialized
INFO - 2018-05-15 21:31:54 --> URI Class Initialized
INFO - 2018-05-15 21:31:54 --> Output Class Initialized
DEBUG - 2018-05-15 21:31:54 --> UTF-8 Support Enabled
INFO - 2018-05-15 21:31:54 --> Utf8 Class Initialized
INFO - 2018-05-15 21:31:54 --> URI Class Initialized
INFO - 2018-05-15 21:31:54 --> Utf8 Class Initialized
INFO - 2018-05-15 21:31:54 --> Router Class Initialized
INFO - 2018-05-15 21:31:54 --> URI Class Initialized
INFO - 2018-05-15 21:31:54 --> Router Class Initialized
INFO - 2018-05-15 21:31:54 --> Security Class Initialized
INFO - 2018-05-15 21:31:54 --> URI Class Initialized
INFO - 2018-05-15 21:31:54 --> Output Class Initialized
DEBUG - 2018-05-15 21:31:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 21:31:54 --> Output Class Initialized
INFO - 2018-05-15 21:31:54 --> Router Class Initialized
INFO - 2018-05-15 21:31:54 --> Security Class Initialized
INFO - 2018-05-15 21:31:54 --> Router Class Initialized
INFO - 2018-05-15 21:31:54 --> Security Class Initialized
INFO - 2018-05-15 21:31:54 --> Input Class Initialized
INFO - 2018-05-15 21:31:54 --> Output Class Initialized
DEBUG - 2018-05-15 21:31:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 21:31:54 --> Output Class Initialized
INFO - 2018-05-15 21:31:54 --> Security Class Initialized
DEBUG - 2018-05-15 21:31:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 21:31:54 --> Language Class Initialized
INFO - 2018-05-15 21:31:54 --> Input Class Initialized
INFO - 2018-05-15 21:31:54 --> Input Class Initialized
INFO - 2018-05-15 21:31:54 --> Language Class Initialized
ERROR - 2018-05-15 21:31:54 --> 404 Page Not Found: /index
DEBUG - 2018-05-15 21:31:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 21:31:54 --> Security Class Initialized
INFO - 2018-05-15 21:31:54 --> Language Class Initialized
INFO - 2018-05-15 21:31:54 --> Input Class Initialized
ERROR - 2018-05-15 21:31:54 --> 404 Page Not Found: /index
DEBUG - 2018-05-15 21:31:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-05-15 21:31:54 --> 404 Page Not Found: /index
INFO - 2018-05-15 21:31:54 --> Input Class Initialized
INFO - 2018-05-15 21:31:54 --> Language Class Initialized
INFO - 2018-05-15 21:31:54 --> Language Class Initialized
ERROR - 2018-05-15 21:31:54 --> 404 Page Not Found: /index
ERROR - 2018-05-15 21:31:54 --> 404 Page Not Found: /index
INFO - 2018-05-15 21:32:05 --> Config Class Initialized
INFO - 2018-05-15 21:32:05 --> Hooks Class Initialized
DEBUG - 2018-05-15 21:32:05 --> UTF-8 Support Enabled
INFO - 2018-05-15 21:32:05 --> Utf8 Class Initialized
INFO - 2018-05-15 21:32:05 --> URI Class Initialized
INFO - 2018-05-15 21:32:05 --> Router Class Initialized
INFO - 2018-05-15 21:32:05 --> Output Class Initialized
INFO - 2018-05-15 21:32:05 --> Security Class Initialized
DEBUG - 2018-05-15 21:32:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 21:32:06 --> Input Class Initialized
INFO - 2018-05-15 21:32:06 --> Language Class Initialized
ERROR - 2018-05-15 21:32:06 --> 404 Page Not Found: /index
INFO - 2018-05-15 21:32:06 --> Config Class Initialized
INFO - 2018-05-15 21:32:06 --> Hooks Class Initialized
DEBUG - 2018-05-15 21:32:06 --> UTF-8 Support Enabled
INFO - 2018-05-15 21:32:06 --> Utf8 Class Initialized
INFO - 2018-05-15 21:32:06 --> URI Class Initialized
INFO - 2018-05-15 21:32:06 --> Router Class Initialized
INFO - 2018-05-15 21:32:06 --> Output Class Initialized
INFO - 2018-05-15 21:32:06 --> Security Class Initialized
DEBUG - 2018-05-15 21:32:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 21:32:06 --> Input Class Initialized
INFO - 2018-05-15 21:32:06 --> Language Class Initialized
ERROR - 2018-05-15 21:32:06 --> 404 Page Not Found: /index
INFO - 2018-05-15 21:32:06 --> Config Class Initialized
INFO - 2018-05-15 21:32:06 --> Hooks Class Initialized
DEBUG - 2018-05-15 21:32:06 --> UTF-8 Support Enabled
INFO - 2018-05-15 21:32:06 --> Utf8 Class Initialized
INFO - 2018-05-15 21:32:06 --> URI Class Initialized
INFO - 2018-05-15 21:32:06 --> Router Class Initialized
INFO - 2018-05-15 21:32:06 --> Output Class Initialized
INFO - 2018-05-15 21:32:06 --> Security Class Initialized
DEBUG - 2018-05-15 21:32:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 21:32:06 --> Input Class Initialized
INFO - 2018-05-15 21:32:06 --> Language Class Initialized
ERROR - 2018-05-15 21:32:06 --> 404 Page Not Found: /index
INFO - 2018-05-15 23:36:01 --> Config Class Initialized
INFO - 2018-05-15 23:36:02 --> Hooks Class Initialized
DEBUG - 2018-05-15 23:36:02 --> UTF-8 Support Enabled
INFO - 2018-05-15 23:36:02 --> Utf8 Class Initialized
INFO - 2018-05-15 23:36:02 --> URI Class Initialized
INFO - 2018-05-15 23:36:02 --> Router Class Initialized
INFO - 2018-05-15 23:36:02 --> Output Class Initialized
INFO - 2018-05-15 23:36:02 --> Security Class Initialized
DEBUG - 2018-05-15 23:36:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 23:36:02 --> Input Class Initialized
INFO - 2018-05-15 23:36:02 --> Language Class Initialized
INFO - 2018-05-15 23:36:02 --> Language Class Initialized
INFO - 2018-05-15 23:36:02 --> Config Class Initialized
INFO - 2018-05-15 23:36:02 --> Loader Class Initialized
DEBUG - 2018-05-15 23:36:02 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-15 23:36:02 --> Helper loaded: url_helper
INFO - 2018-05-15 23:36:02 --> Helper loaded: form_helper
INFO - 2018-05-15 23:36:03 --> Helper loaded: date_helper
INFO - 2018-05-15 23:36:03 --> Helper loaded: util_helper
INFO - 2018-05-15 23:36:03 --> Helper loaded: text_helper
INFO - 2018-05-15 23:36:03 --> Helper loaded: string_helper
INFO - 2018-05-15 23:36:03 --> Database Driver Class Initialized
DEBUG - 2018-05-15 23:36:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-15 23:36:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-15 23:36:03 --> Email Class Initialized
INFO - 2018-05-15 23:36:03 --> Controller Class Initialized
DEBUG - 2018-05-15 23:36:03 --> Login MX_Controller Initialized
INFO - 2018-05-15 23:36:03 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-15 23:36:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-15 23:36:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
ERROR - 2018-05-15 23:36:03 --> Severity: Notice --> Undefined index: home_user_id E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php 541
INFO - 2018-05-15 23:36:03 --> Config Class Initialized
INFO - 2018-05-15 23:36:03 --> Hooks Class Initialized
DEBUG - 2018-05-15 23:36:03 --> UTF-8 Support Enabled
INFO - 2018-05-15 23:36:03 --> Utf8 Class Initialized
INFO - 2018-05-15 23:36:03 --> URI Class Initialized
INFO - 2018-05-15 23:36:03 --> Router Class Initialized
INFO - 2018-05-15 23:36:03 --> Output Class Initialized
INFO - 2018-05-15 23:36:03 --> Security Class Initialized
DEBUG - 2018-05-15 23:36:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 23:36:03 --> Input Class Initialized
INFO - 2018-05-15 23:36:03 --> Language Class Initialized
INFO - 2018-05-15 23:36:04 --> Language Class Initialized
INFO - 2018-05-15 23:36:04 --> Config Class Initialized
INFO - 2018-05-15 23:36:04 --> Loader Class Initialized
DEBUG - 2018-05-15 23:36:04 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-15 23:36:04 --> Helper loaded: url_helper
INFO - 2018-05-15 23:36:04 --> Helper loaded: form_helper
INFO - 2018-05-15 23:36:04 --> Helper loaded: date_helper
INFO - 2018-05-15 23:36:04 --> Helper loaded: util_helper
INFO - 2018-05-15 23:36:04 --> Helper loaded: text_helper
INFO - 2018-05-15 23:36:04 --> Helper loaded: string_helper
INFO - 2018-05-15 23:36:04 --> Database Driver Class Initialized
DEBUG - 2018-05-15 23:36:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-15 23:36:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-15 23:36:04 --> Email Class Initialized
INFO - 2018-05-15 23:36:04 --> Controller Class Initialized
DEBUG - 2018-05-15 23:36:04 --> Home MX_Controller Initialized
DEBUG - 2018-05-15 23:36:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-15 23:36:04 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-15 23:36:04 --> Login MX_Controller Initialized
INFO - 2018-05-15 23:36:04 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-15 23:36:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-15 23:36:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-15 23:36:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/login.php
INFO - 2018-05-15 23:36:06 --> Config Class Initialized
INFO - 2018-05-15 23:36:06 --> Hooks Class Initialized
DEBUG - 2018-05-15 23:36:06 --> UTF-8 Support Enabled
INFO - 2018-05-15 23:36:06 --> Utf8 Class Initialized
INFO - 2018-05-15 23:36:06 --> URI Class Initialized
INFO - 2018-05-15 23:36:06 --> Router Class Initialized
INFO - 2018-05-15 23:36:06 --> Output Class Initialized
INFO - 2018-05-15 23:36:06 --> Security Class Initialized
DEBUG - 2018-05-15 23:36:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 23:36:06 --> Input Class Initialized
INFO - 2018-05-15 23:36:06 --> Language Class Initialized
INFO - 2018-05-15 23:36:06 --> Language Class Initialized
INFO - 2018-05-15 23:36:06 --> Config Class Initialized
INFO - 2018-05-15 23:36:06 --> Loader Class Initialized
DEBUG - 2018-05-15 23:36:06 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-15 23:36:06 --> Helper loaded: url_helper
INFO - 2018-05-15 23:36:06 --> Helper loaded: form_helper
INFO - 2018-05-15 23:36:06 --> Helper loaded: date_helper
INFO - 2018-05-15 23:36:06 --> Helper loaded: util_helper
INFO - 2018-05-15 23:36:06 --> Helper loaded: text_helper
INFO - 2018-05-15 23:36:06 --> Helper loaded: string_helper
INFO - 2018-05-15 23:36:06 --> Database Driver Class Initialized
DEBUG - 2018-05-15 23:36:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-15 23:36:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-15 23:36:06 --> Email Class Initialized
INFO - 2018-05-15 23:36:06 --> Controller Class Initialized
DEBUG - 2018-05-15 23:36:06 --> Login MX_Controller Initialized
INFO - 2018-05-15 23:36:06 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-15 23:36:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-15 23:36:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-15 23:36:06 --> Email starts for gopipanguluri123@gmail.com fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-05-15 23:36:06 --> User session created for 4
INFO - 2018-05-15 23:36:06 --> Login status gopipanguluri123@gmail.com - success
INFO - 2018-05-15 23:36:06 --> Final output sent to browser
DEBUG - 2018-05-15 23:36:06 --> Total execution time: 0.7059
INFO - 2018-05-15 23:36:06 --> Config Class Initialized
INFO - 2018-05-15 23:36:06 --> Hooks Class Initialized
DEBUG - 2018-05-15 23:36:06 --> UTF-8 Support Enabled
INFO - 2018-05-15 23:36:06 --> Utf8 Class Initialized
INFO - 2018-05-15 23:36:06 --> URI Class Initialized
INFO - 2018-05-15 23:36:06 --> Router Class Initialized
INFO - 2018-05-15 23:36:06 --> Output Class Initialized
INFO - 2018-05-15 23:36:06 --> Security Class Initialized
DEBUG - 2018-05-15 23:36:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 23:36:07 --> Input Class Initialized
INFO - 2018-05-15 23:36:07 --> Language Class Initialized
INFO - 2018-05-15 23:36:07 --> Language Class Initialized
INFO - 2018-05-15 23:36:07 --> Config Class Initialized
INFO - 2018-05-15 23:36:07 --> Loader Class Initialized
DEBUG - 2018-05-15 23:36:07 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-15 23:36:07 --> Helper loaded: url_helper
INFO - 2018-05-15 23:36:07 --> Helper loaded: form_helper
INFO - 2018-05-15 23:36:07 --> Helper loaded: date_helper
INFO - 2018-05-15 23:36:07 --> Helper loaded: util_helper
INFO - 2018-05-15 23:36:07 --> Helper loaded: text_helper
INFO - 2018-05-15 23:36:07 --> Helper loaded: string_helper
INFO - 2018-05-15 23:36:07 --> Database Driver Class Initialized
DEBUG - 2018-05-15 23:36:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-15 23:36:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-15 23:36:07 --> Email Class Initialized
INFO - 2018-05-15 23:36:07 --> Controller Class Initialized
DEBUG - 2018-05-15 23:36:07 --> Home MX_Controller Initialized
DEBUG - 2018-05-15 23:36:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-15 23:36:07 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-15 23:36:07 --> Login MX_Controller Initialized
INFO - 2018-05-15 23:36:07 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-15 23:36:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-15 23:36:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-15 23:36:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-05-15 23:36:07 --> Final output sent to browser
INFO - 2018-05-15 23:36:07 --> Config Class Initialized
DEBUG - 2018-05-15 23:36:07 --> Total execution time: 0.8464
INFO - 2018-05-15 23:36:07 --> Hooks Class Initialized
DEBUG - 2018-05-15 23:36:07 --> UTF-8 Support Enabled
INFO - 2018-05-15 23:36:07 --> Utf8 Class Initialized
INFO - 2018-05-15 23:36:07 --> URI Class Initialized
INFO - 2018-05-15 23:36:07 --> Router Class Initialized
INFO - 2018-05-15 23:36:07 --> Output Class Initialized
INFO - 2018-05-15 23:36:07 --> Security Class Initialized
DEBUG - 2018-05-15 23:36:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 23:36:08 --> Input Class Initialized
INFO - 2018-05-15 23:36:08 --> Language Class Initialized
ERROR - 2018-05-15 23:36:08 --> 404 Page Not Found: /index
INFO - 2018-05-15 23:36:08 --> Config Class Initialized
INFO - 2018-05-15 23:36:08 --> Config Class Initialized
INFO - 2018-05-15 23:36:08 --> Hooks Class Initialized
INFO - 2018-05-15 23:36:08 --> Hooks Class Initialized
INFO - 2018-05-15 23:36:08 --> Config Class Initialized
INFO - 2018-05-15 23:36:08 --> Config Class Initialized
INFO - 2018-05-15 23:36:08 --> Config Class Initialized
INFO - 2018-05-15 23:36:08 --> Hooks Class Initialized
DEBUG - 2018-05-15 23:36:08 --> UTF-8 Support Enabled
INFO - 2018-05-15 23:36:08 --> Config Class Initialized
DEBUG - 2018-05-15 23:36:08 --> UTF-8 Support Enabled
INFO - 2018-05-15 23:36:08 --> Hooks Class Initialized
INFO - 2018-05-15 23:36:08 --> Hooks Class Initialized
INFO - 2018-05-15 23:36:08 --> Hooks Class Initialized
DEBUG - 2018-05-15 23:36:08 --> UTF-8 Support Enabled
INFO - 2018-05-15 23:36:08 --> Utf8 Class Initialized
DEBUG - 2018-05-15 23:36:08 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 23:36:08 --> UTF-8 Support Enabled
INFO - 2018-05-15 23:36:08 --> Utf8 Class Initialized
INFO - 2018-05-15 23:36:08 --> Utf8 Class Initialized
DEBUG - 2018-05-15 23:36:08 --> UTF-8 Support Enabled
INFO - 2018-05-15 23:36:08 --> Utf8 Class Initialized
INFO - 2018-05-15 23:36:08 --> Utf8 Class Initialized
INFO - 2018-05-15 23:36:08 --> URI Class Initialized
INFO - 2018-05-15 23:36:08 --> Utf8 Class Initialized
INFO - 2018-05-15 23:36:08 --> URI Class Initialized
INFO - 2018-05-15 23:36:08 --> URI Class Initialized
INFO - 2018-05-15 23:36:08 --> URI Class Initialized
INFO - 2018-05-15 23:36:08 --> Router Class Initialized
INFO - 2018-05-15 23:36:08 --> Router Class Initialized
INFO - 2018-05-15 23:36:08 --> URI Class Initialized
INFO - 2018-05-15 23:36:08 --> URI Class Initialized
INFO - 2018-05-15 23:36:08 --> Router Class Initialized
INFO - 2018-05-15 23:36:08 --> Output Class Initialized
INFO - 2018-05-15 23:36:08 --> Router Class Initialized
INFO - 2018-05-15 23:36:08 --> Router Class Initialized
INFO - 2018-05-15 23:36:08 --> Router Class Initialized
INFO - 2018-05-15 23:36:08 --> Output Class Initialized
INFO - 2018-05-15 23:36:08 --> Output Class Initialized
INFO - 2018-05-15 23:36:08 --> Security Class Initialized
INFO - 2018-05-15 23:36:08 --> Security Class Initialized
INFO - 2018-05-15 23:36:08 --> Security Class Initialized
INFO - 2018-05-15 23:36:08 --> Output Class Initialized
INFO - 2018-05-15 23:36:08 --> Output Class Initialized
INFO - 2018-05-15 23:36:08 --> Output Class Initialized
DEBUG - 2018-05-15 23:36:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 23:36:08 --> Input Class Initialized
DEBUG - 2018-05-15 23:36:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 23:36:08 --> Security Class Initialized
INFO - 2018-05-15 23:36:08 --> Security Class Initialized
DEBUG - 2018-05-15 23:36:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 23:36:08 --> Security Class Initialized
INFO - 2018-05-15 23:36:08 --> Input Class Initialized
INFO - 2018-05-15 23:36:08 --> Language Class Initialized
DEBUG - 2018-05-15 23:36:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-15 23:36:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 23:36:08 --> Input Class Initialized
DEBUG - 2018-05-15 23:36:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 23:36:08 --> Input Class Initialized
INFO - 2018-05-15 23:36:08 --> Input Class Initialized
INFO - 2018-05-15 23:36:08 --> Language Class Initialized
INFO - 2018-05-15 23:36:08 --> Language Class Initialized
INFO - 2018-05-15 23:36:08 --> Input Class Initialized
ERROR - 2018-05-15 23:36:08 --> 404 Page Not Found: /index
INFO - 2018-05-15 23:36:08 --> Language Class Initialized
INFO - 2018-05-15 23:36:08 --> Language Class Initialized
INFO - 2018-05-15 23:36:08 --> Language Class Initialized
ERROR - 2018-05-15 23:36:08 --> 404 Page Not Found: /index
ERROR - 2018-05-15 23:36:08 --> 404 Page Not Found: /index
ERROR - 2018-05-15 23:36:08 --> 404 Page Not Found: /index
INFO - 2018-05-15 23:36:08 --> Config Class Initialized
INFO - 2018-05-15 23:36:08 --> Hooks Class Initialized
INFO - 2018-05-15 23:36:08 --> Config Class Initialized
INFO - 2018-05-15 23:36:08 --> Hooks Class Initialized
ERROR - 2018-05-15 23:36:08 --> 404 Page Not Found: /index
DEBUG - 2018-05-15 23:36:08 --> UTF-8 Support Enabled
ERROR - 2018-05-15 23:36:08 --> 404 Page Not Found: /index
INFO - 2018-05-15 23:36:08 --> Config Class Initialized
DEBUG - 2018-05-15 23:36:08 --> UTF-8 Support Enabled
INFO - 2018-05-15 23:36:08 --> Utf8 Class Initialized
INFO - 2018-05-15 23:36:08 --> Config Class Initialized
INFO - 2018-05-15 23:36:08 --> Hooks Class Initialized
INFO - 2018-05-15 23:36:08 --> Config Class Initialized
INFO - 2018-05-15 23:36:08 --> Hooks Class Initialized
INFO - 2018-05-15 23:36:08 --> Utf8 Class Initialized
DEBUG - 2018-05-15 23:36:08 --> UTF-8 Support Enabled
INFO - 2018-05-15 23:36:08 --> Utf8 Class Initialized
INFO - 2018-05-15 23:36:08 --> Hooks Class Initialized
DEBUG - 2018-05-15 23:36:08 --> UTF-8 Support Enabled
INFO - 2018-05-15 23:36:08 --> URI Class Initialized
INFO - 2018-05-15 23:36:08 --> URI Class Initialized
INFO - 2018-05-15 23:36:08 --> URI Class Initialized
DEBUG - 2018-05-15 23:36:08 --> UTF-8 Support Enabled
INFO - 2018-05-15 23:36:09 --> Utf8 Class Initialized
INFO - 2018-05-15 23:36:09 --> URI Class Initialized
INFO - 2018-05-15 23:36:09 --> Router Class Initialized
INFO - 2018-05-15 23:36:09 --> Router Class Initialized
INFO - 2018-05-15 23:36:09 --> Router Class Initialized
INFO - 2018-05-15 23:36:09 --> Router Class Initialized
INFO - 2018-05-15 23:36:09 --> Output Class Initialized
INFO - 2018-05-15 23:36:09 --> Output Class Initialized
INFO - 2018-05-15 23:36:09 --> Utf8 Class Initialized
INFO - 2018-05-15 23:36:09 --> Output Class Initialized
INFO - 2018-05-15 23:36:09 --> Output Class Initialized
INFO - 2018-05-15 23:36:09 --> Security Class Initialized
INFO - 2018-05-15 23:36:09 --> Security Class Initialized
INFO - 2018-05-15 23:36:09 --> Security Class Initialized
INFO - 2018-05-15 23:36:09 --> Security Class Initialized
INFO - 2018-05-15 23:36:09 --> URI Class Initialized
DEBUG - 2018-05-15 23:36:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-15 23:36:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 23:36:09 --> Router Class Initialized
DEBUG - 2018-05-15 23:36:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 23:36:09 --> Input Class Initialized
DEBUG - 2018-05-15 23:36:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 23:36:09 --> Input Class Initialized
INFO - 2018-05-15 23:36:09 --> Output Class Initialized
INFO - 2018-05-15 23:36:09 --> Input Class Initialized
INFO - 2018-05-15 23:36:09 --> Language Class Initialized
INFO - 2018-05-15 23:36:09 --> Language Class Initialized
INFO - 2018-05-15 23:36:09 --> Input Class Initialized
INFO - 2018-05-15 23:36:09 --> Security Class Initialized
INFO - 2018-05-15 23:36:09 --> Language Class Initialized
DEBUG - 2018-05-15 23:36:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 23:36:09 --> Language Class Initialized
ERROR - 2018-05-15 23:36:09 --> 404 Page Not Found: /index
ERROR - 2018-05-15 23:36:09 --> 404 Page Not Found: /index
ERROR - 2018-05-15 23:36:09 --> 404 Page Not Found: /index
ERROR - 2018-05-15 23:36:09 --> 404 Page Not Found: /index
INFO - 2018-05-15 23:36:09 --> Config Class Initialized
INFO - 2018-05-15 23:36:09 --> Config Class Initialized
INFO - 2018-05-15 23:36:09 --> Config Class Initialized
INFO - 2018-05-15 23:36:09 --> Input Class Initialized
INFO - 2018-05-15 23:36:09 --> Hooks Class Initialized
INFO - 2018-05-15 23:36:09 --> Hooks Class Initialized
INFO - 2018-05-15 23:36:09 --> Hooks Class Initialized
INFO - 2018-05-15 23:36:09 --> Language Class Initialized
INFO - 2018-05-15 23:36:09 --> Config Class Initialized
DEBUG - 2018-05-15 23:36:09 --> UTF-8 Support Enabled
INFO - 2018-05-15 23:36:09 --> Hooks Class Initialized
ERROR - 2018-05-15 23:36:09 --> 404 Page Not Found: /index
DEBUG - 2018-05-15 23:36:09 --> UTF-8 Support Enabled
DEBUG - 2018-05-15 23:36:09 --> UTF-8 Support Enabled
INFO - 2018-05-15 23:36:09 --> Config Class Initialized
DEBUG - 2018-05-15 23:36:09 --> UTF-8 Support Enabled
INFO - 2018-05-15 23:36:09 --> Utf8 Class Initialized
INFO - 2018-05-15 23:36:09 --> Hooks Class Initialized
INFO - 2018-05-15 23:36:09 --> Utf8 Class Initialized
INFO - 2018-05-15 23:36:09 --> URI Class Initialized
INFO - 2018-05-15 23:36:09 --> Utf8 Class Initialized
INFO - 2018-05-15 23:36:09 --> Utf8 Class Initialized
INFO - 2018-05-15 23:36:09 --> URI Class Initialized
DEBUG - 2018-05-15 23:36:09 --> UTF-8 Support Enabled
INFO - 2018-05-15 23:36:09 --> URI Class Initialized
INFO - 2018-05-15 23:36:09 --> URI Class Initialized
INFO - 2018-05-15 23:36:09 --> Router Class Initialized
INFO - 2018-05-15 23:36:09 --> Router Class Initialized
INFO - 2018-05-15 23:36:09 --> Utf8 Class Initialized
INFO - 2018-05-15 23:36:09 --> Router Class Initialized
INFO - 2018-05-15 23:36:09 --> Router Class Initialized
INFO - 2018-05-15 23:36:09 --> Output Class Initialized
INFO - 2018-05-15 23:36:09 --> Output Class Initialized
INFO - 2018-05-15 23:36:09 --> URI Class Initialized
INFO - 2018-05-15 23:36:09 --> Security Class Initialized
INFO - 2018-05-15 23:36:09 --> Output Class Initialized
INFO - 2018-05-15 23:36:09 --> Security Class Initialized
INFO - 2018-05-15 23:36:09 --> Router Class Initialized
DEBUG - 2018-05-15 23:36:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 23:36:09 --> Security Class Initialized
INFO - 2018-05-15 23:36:09 --> Output Class Initialized
INFO - 2018-05-15 23:36:09 --> Output Class Initialized
INFO - 2018-05-15 23:36:09 --> Input Class Initialized
DEBUG - 2018-05-15 23:36:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-15 23:36:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 23:36:09 --> Security Class Initialized
INFO - 2018-05-15 23:36:09 --> Input Class Initialized
INFO - 2018-05-15 23:36:09 --> Language Class Initialized
INFO - 2018-05-15 23:36:09 --> Security Class Initialized
DEBUG - 2018-05-15 23:36:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-15 23:36:09 --> Input Class Initialized
INFO - 2018-05-15 23:36:09 --> Input Class Initialized
INFO - 2018-05-15 23:36:09 --> Language Class Initialized
INFO - 2018-05-15 23:36:09 --> Language Class Initialized
DEBUG - 2018-05-15 23:36:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-05-15 23:36:09 --> 404 Page Not Found: /index
INFO - 2018-05-15 23:36:09 --> Input Class Initialized
ERROR - 2018-05-15 23:36:09 --> 404 Page Not Found: /index
INFO - 2018-05-15 23:36:09 --> Language Class Initialized
INFO - 2018-05-15 23:36:09 --> Language Class Initialized
ERROR - 2018-05-15 23:36:09 --> 404 Page Not Found: /index
ERROR - 2018-05-15 23:36:09 --> 404 Page Not Found: /index
ERROR - 2018-05-15 23:36:09 --> 404 Page Not Found: /index
