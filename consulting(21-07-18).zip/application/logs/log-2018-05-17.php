<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-05-17 00:45:13 --> Config Class Initialized
INFO - 2018-05-17 00:45:13 --> Hooks Class Initialized
DEBUG - 2018-05-17 00:45:13 --> UTF-8 Support Enabled
INFO - 2018-05-17 00:45:13 --> Utf8 Class Initialized
INFO - 2018-05-17 00:45:13 --> URI Class Initialized
INFO - 2018-05-17 00:45:13 --> Router Class Initialized
INFO - 2018-05-17 00:45:13 --> Output Class Initialized
INFO - 2018-05-17 00:45:13 --> Security Class Initialized
DEBUG - 2018-05-17 00:45:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 00:45:13 --> Input Class Initialized
INFO - 2018-05-17 00:45:13 --> Language Class Initialized
INFO - 2018-05-17 00:45:13 --> Language Class Initialized
INFO - 2018-05-17 00:45:13 --> Config Class Initialized
INFO - 2018-05-17 00:45:13 --> Loader Class Initialized
DEBUG - 2018-05-17 00:45:13 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-17 00:45:13 --> Helper loaded: url_helper
INFO - 2018-05-17 00:45:13 --> Helper loaded: form_helper
INFO - 2018-05-17 00:45:13 --> Helper loaded: date_helper
INFO - 2018-05-17 00:45:13 --> Helper loaded: util_helper
INFO - 2018-05-17 00:45:13 --> Helper loaded: text_helper
INFO - 2018-05-17 00:45:13 --> Helper loaded: string_helper
INFO - 2018-05-17 00:45:13 --> Database Driver Class Initialized
DEBUG - 2018-05-17 00:45:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-17 00:45:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-17 00:45:13 --> Email Class Initialized
INFO - 2018-05-17 00:45:13 --> Controller Class Initialized
DEBUG - 2018-05-17 00:45:13 --> Home MX_Controller Initialized
DEBUG - 2018-05-17 00:45:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-17 00:45:13 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-17 00:45:13 --> Login MX_Controller Initialized
INFO - 2018-05-17 00:45:13 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-17 00:45:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-17 00:45:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-17 00:45:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-17 00:45:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-17 00:45:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-17 00:45:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-17 00:45:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-17 00:45:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-05-17 00:45:13 --> Final output sent to browser
DEBUG - 2018-05-17 00:45:13 --> Total execution time: 0.4618
INFO - 2018-05-17 00:45:28 --> Config Class Initialized
INFO - 2018-05-17 00:45:28 --> Hooks Class Initialized
DEBUG - 2018-05-17 00:45:28 --> UTF-8 Support Enabled
INFO - 2018-05-17 00:45:28 --> Utf8 Class Initialized
INFO - 2018-05-17 00:45:28 --> URI Class Initialized
INFO - 2018-05-17 00:45:28 --> Router Class Initialized
INFO - 2018-05-17 00:45:28 --> Output Class Initialized
INFO - 2018-05-17 00:45:28 --> Security Class Initialized
DEBUG - 2018-05-17 00:45:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 00:45:28 --> Input Class Initialized
INFO - 2018-05-17 00:45:28 --> Language Class Initialized
INFO - 2018-05-17 00:45:28 --> Language Class Initialized
INFO - 2018-05-17 00:45:28 --> Config Class Initialized
INFO - 2018-05-17 00:45:28 --> Loader Class Initialized
DEBUG - 2018-05-17 00:45:28 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-17 00:45:28 --> Helper loaded: url_helper
INFO - 2018-05-17 00:45:28 --> Helper loaded: form_helper
INFO - 2018-05-17 00:45:28 --> Helper loaded: date_helper
INFO - 2018-05-17 00:45:28 --> Helper loaded: util_helper
INFO - 2018-05-17 00:45:28 --> Helper loaded: text_helper
INFO - 2018-05-17 00:45:28 --> Helper loaded: string_helper
INFO - 2018-05-17 00:45:28 --> Database Driver Class Initialized
DEBUG - 2018-05-17 00:45:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-17 00:45:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-17 00:45:28 --> Email Class Initialized
INFO - 2018-05-17 00:45:28 --> Controller Class Initialized
DEBUG - 2018-05-17 00:45:28 --> Home MX_Controller Initialized
DEBUG - 2018-05-17 00:45:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-17 00:45:28 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-17 00:45:28 --> Login MX_Controller Initialized
INFO - 2018-05-17 00:45:28 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-17 00:45:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-17 00:45:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-17 00:45:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-17 00:45:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-17 00:45:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-17 00:45:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-17 00:45:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-17 00:45:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-05-17 00:45:28 --> Final output sent to browser
DEBUG - 2018-05-17 00:45:28 --> Total execution time: 0.3499
INFO - 2018-05-17 00:45:31 --> Config Class Initialized
INFO - 2018-05-17 00:45:31 --> Hooks Class Initialized
INFO - 2018-05-17 00:45:31 --> Config Class Initialized
INFO - 2018-05-17 00:45:31 --> Hooks Class Initialized
DEBUG - 2018-05-17 00:45:31 --> UTF-8 Support Enabled
DEBUG - 2018-05-17 00:45:31 --> UTF-8 Support Enabled
INFO - 2018-05-17 00:45:31 --> Utf8 Class Initialized
INFO - 2018-05-17 00:45:31 --> URI Class Initialized
INFO - 2018-05-17 00:45:31 --> Router Class Initialized
INFO - 2018-05-17 00:45:31 --> Output Class Initialized
INFO - 2018-05-17 00:45:31 --> Utf8 Class Initialized
INFO - 2018-05-17 00:45:31 --> Security Class Initialized
INFO - 2018-05-17 00:45:31 --> URI Class Initialized
INFO - 2018-05-17 00:45:31 --> Router Class Initialized
DEBUG - 2018-05-17 00:45:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 00:45:31 --> Input Class Initialized
INFO - 2018-05-17 00:45:31 --> Output Class Initialized
INFO - 2018-05-17 00:45:31 --> Language Class Initialized
INFO - 2018-05-17 00:45:31 --> Security Class Initialized
DEBUG - 2018-05-17 00:45:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-05-17 00:45:31 --> 404 Page Not Found: /index
INFO - 2018-05-17 00:45:31 --> Input Class Initialized
INFO - 2018-05-17 00:45:31 --> Language Class Initialized
ERROR - 2018-05-17 00:45:31 --> 404 Page Not Found: /index
INFO - 2018-05-17 00:45:31 --> Config Class Initialized
INFO - 2018-05-17 00:45:31 --> Hooks Class Initialized
DEBUG - 2018-05-17 00:45:31 --> UTF-8 Support Enabled
INFO - 2018-05-17 00:45:31 --> Utf8 Class Initialized
INFO - 2018-05-17 00:45:31 --> URI Class Initialized
INFO - 2018-05-17 00:45:31 --> Router Class Initialized
INFO - 2018-05-17 00:45:31 --> Output Class Initialized
INFO - 2018-05-17 00:45:31 --> Security Class Initialized
DEBUG - 2018-05-17 00:45:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 00:45:31 --> Input Class Initialized
INFO - 2018-05-17 00:45:31 --> Language Class Initialized
ERROR - 2018-05-17 00:45:31 --> 404 Page Not Found: /index
INFO - 2018-05-17 00:45:31 --> Config Class Initialized
INFO - 2018-05-17 00:45:31 --> Hooks Class Initialized
DEBUG - 2018-05-17 00:45:31 --> UTF-8 Support Enabled
INFO - 2018-05-17 00:45:31 --> Utf8 Class Initialized
INFO - 2018-05-17 00:45:31 --> URI Class Initialized
INFO - 2018-05-17 00:45:31 --> Router Class Initialized
INFO - 2018-05-17 00:45:31 --> Output Class Initialized
INFO - 2018-05-17 00:45:31 --> Security Class Initialized
DEBUG - 2018-05-17 00:45:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 00:45:31 --> Input Class Initialized
INFO - 2018-05-17 00:45:31 --> Language Class Initialized
ERROR - 2018-05-17 00:45:31 --> 404 Page Not Found: /index
INFO - 2018-05-17 00:45:38 --> Config Class Initialized
INFO - 2018-05-17 00:45:38 --> Hooks Class Initialized
DEBUG - 2018-05-17 00:45:38 --> UTF-8 Support Enabled
INFO - 2018-05-17 00:45:38 --> Utf8 Class Initialized
INFO - 2018-05-17 00:45:38 --> URI Class Initialized
INFO - 2018-05-17 00:45:38 --> Router Class Initialized
INFO - 2018-05-17 00:45:38 --> Output Class Initialized
INFO - 2018-05-17 00:45:38 --> Security Class Initialized
DEBUG - 2018-05-17 00:45:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 00:45:38 --> Input Class Initialized
INFO - 2018-05-17 00:45:38 --> Language Class Initialized
ERROR - 2018-05-17 00:45:38 --> 404 Page Not Found: /index
INFO - 2018-05-17 00:45:38 --> Config Class Initialized
INFO - 2018-05-17 00:45:38 --> Hooks Class Initialized
DEBUG - 2018-05-17 00:45:38 --> UTF-8 Support Enabled
INFO - 2018-05-17 00:45:38 --> Utf8 Class Initialized
INFO - 2018-05-17 00:45:38 --> URI Class Initialized
INFO - 2018-05-17 00:45:38 --> Router Class Initialized
INFO - 2018-05-17 00:45:38 --> Output Class Initialized
INFO - 2018-05-17 00:45:38 --> Security Class Initialized
DEBUG - 2018-05-17 00:45:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 00:45:38 --> Input Class Initialized
INFO - 2018-05-17 00:45:38 --> Language Class Initialized
ERROR - 2018-05-17 00:45:38 --> 404 Page Not Found: /index
INFO - 2018-05-17 00:45:38 --> Config Class Initialized
INFO - 2018-05-17 00:45:38 --> Hooks Class Initialized
DEBUG - 2018-05-17 00:45:38 --> UTF-8 Support Enabled
INFO - 2018-05-17 00:45:38 --> Utf8 Class Initialized
INFO - 2018-05-17 00:45:38 --> URI Class Initialized
INFO - 2018-05-17 00:45:38 --> Router Class Initialized
INFO - 2018-05-17 00:45:38 --> Output Class Initialized
INFO - 2018-05-17 00:45:38 --> Security Class Initialized
DEBUG - 2018-05-17 00:45:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 00:45:38 --> Input Class Initialized
INFO - 2018-05-17 00:45:39 --> Language Class Initialized
ERROR - 2018-05-17 00:45:39 --> 404 Page Not Found: /index
INFO - 2018-05-17 00:46:32 --> Config Class Initialized
INFO - 2018-05-17 00:46:32 --> Hooks Class Initialized
DEBUG - 2018-05-17 00:46:32 --> UTF-8 Support Enabled
INFO - 2018-05-17 00:46:32 --> Utf8 Class Initialized
INFO - 2018-05-17 00:46:32 --> URI Class Initialized
INFO - 2018-05-17 00:46:32 --> Router Class Initialized
INFO - 2018-05-17 00:46:32 --> Output Class Initialized
INFO - 2018-05-17 00:46:32 --> Security Class Initialized
DEBUG - 2018-05-17 00:46:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 00:46:32 --> Input Class Initialized
INFO - 2018-05-17 00:46:32 --> Language Class Initialized
INFO - 2018-05-17 00:46:32 --> Language Class Initialized
INFO - 2018-05-17 00:46:32 --> Config Class Initialized
INFO - 2018-05-17 00:46:32 --> Loader Class Initialized
DEBUG - 2018-05-17 00:46:32 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-17 00:46:32 --> Helper loaded: url_helper
INFO - 2018-05-17 00:46:32 --> Helper loaded: form_helper
INFO - 2018-05-17 00:46:32 --> Helper loaded: date_helper
INFO - 2018-05-17 00:46:32 --> Helper loaded: util_helper
INFO - 2018-05-17 00:46:32 --> Helper loaded: text_helper
INFO - 2018-05-17 00:46:32 --> Helper loaded: string_helper
INFO - 2018-05-17 00:46:32 --> Database Driver Class Initialized
DEBUG - 2018-05-17 00:46:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-17 00:46:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-17 00:46:32 --> Email Class Initialized
INFO - 2018-05-17 00:46:32 --> Controller Class Initialized
DEBUG - 2018-05-17 00:46:32 --> Home MX_Controller Initialized
DEBUG - 2018-05-17 00:46:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-17 00:46:33 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-17 00:46:33 --> Login MX_Controller Initialized
INFO - 2018-05-17 00:46:33 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-17 00:46:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-17 00:46:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-17 00:46:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-17 00:46:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-17 00:46:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-17 00:46:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-17 00:46:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-05-17 00:46:33 --> Final output sent to browser
DEBUG - 2018-05-17 00:46:33 --> Total execution time: 0.3494
INFO - 2018-05-17 00:46:34 --> Config Class Initialized
INFO - 2018-05-17 00:46:34 --> Hooks Class Initialized
INFO - 2018-05-17 00:46:34 --> Config Class Initialized
INFO - 2018-05-17 00:46:34 --> Hooks Class Initialized
DEBUG - 2018-05-17 00:46:34 --> UTF-8 Support Enabled
DEBUG - 2018-05-17 00:46:34 --> UTF-8 Support Enabled
INFO - 2018-05-17 00:46:34 --> Utf8 Class Initialized
INFO - 2018-05-17 00:46:34 --> URI Class Initialized
INFO - 2018-05-17 00:46:34 --> Utf8 Class Initialized
INFO - 2018-05-17 00:46:34 --> Router Class Initialized
INFO - 2018-05-17 00:46:34 --> URI Class Initialized
INFO - 2018-05-17 00:46:34 --> Output Class Initialized
INFO - 2018-05-17 00:46:34 --> Router Class Initialized
INFO - 2018-05-17 00:46:34 --> Security Class Initialized
INFO - 2018-05-17 00:46:34 --> Output Class Initialized
DEBUG - 2018-05-17 00:46:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 00:46:34 --> Input Class Initialized
INFO - 2018-05-17 00:46:34 --> Security Class Initialized
INFO - 2018-05-17 00:46:34 --> Language Class Initialized
DEBUG - 2018-05-17 00:46:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-05-17 00:46:34 --> 404 Page Not Found: /index
INFO - 2018-05-17 00:46:34 --> Input Class Initialized
INFO - 2018-05-17 00:46:34 --> Language Class Initialized
ERROR - 2018-05-17 00:46:34 --> 404 Page Not Found: /index
INFO - 2018-05-17 00:46:34 --> Config Class Initialized
INFO - 2018-05-17 00:46:34 --> Hooks Class Initialized
DEBUG - 2018-05-17 00:46:34 --> UTF-8 Support Enabled
INFO - 2018-05-17 00:46:34 --> Utf8 Class Initialized
INFO - 2018-05-17 00:46:34 --> URI Class Initialized
INFO - 2018-05-17 00:46:34 --> Router Class Initialized
INFO - 2018-05-17 00:46:34 --> Output Class Initialized
INFO - 2018-05-17 00:46:34 --> Security Class Initialized
DEBUG - 2018-05-17 00:46:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 00:46:34 --> Input Class Initialized
INFO - 2018-05-17 00:46:34 --> Language Class Initialized
ERROR - 2018-05-17 00:46:34 --> 404 Page Not Found: /index
INFO - 2018-05-17 00:46:34 --> Config Class Initialized
INFO - 2018-05-17 00:46:34 --> Hooks Class Initialized
DEBUG - 2018-05-17 00:46:34 --> UTF-8 Support Enabled
INFO - 2018-05-17 00:46:34 --> Utf8 Class Initialized
INFO - 2018-05-17 00:46:34 --> URI Class Initialized
INFO - 2018-05-17 00:46:34 --> Router Class Initialized
INFO - 2018-05-17 00:46:34 --> Output Class Initialized
INFO - 2018-05-17 00:46:34 --> Security Class Initialized
DEBUG - 2018-05-17 00:46:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 00:46:34 --> Input Class Initialized
INFO - 2018-05-17 00:46:34 --> Language Class Initialized
ERROR - 2018-05-17 00:46:34 --> 404 Page Not Found: /index
INFO - 2018-05-17 00:46:38 --> Config Class Initialized
INFO - 2018-05-17 00:46:38 --> Hooks Class Initialized
DEBUG - 2018-05-17 00:46:38 --> UTF-8 Support Enabled
INFO - 2018-05-17 00:46:38 --> Utf8 Class Initialized
INFO - 2018-05-17 00:46:38 --> URI Class Initialized
INFO - 2018-05-17 00:46:38 --> Router Class Initialized
INFO - 2018-05-17 00:46:38 --> Output Class Initialized
INFO - 2018-05-17 00:46:38 --> Security Class Initialized
DEBUG - 2018-05-17 00:46:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 00:46:38 --> Input Class Initialized
INFO - 2018-05-17 00:46:38 --> Language Class Initialized
ERROR - 2018-05-17 00:46:38 --> 404 Page Not Found: /index
INFO - 2018-05-17 00:46:38 --> Config Class Initialized
INFO - 2018-05-17 00:46:38 --> Hooks Class Initialized
DEBUG - 2018-05-17 00:46:38 --> UTF-8 Support Enabled
INFO - 2018-05-17 00:46:38 --> Utf8 Class Initialized
INFO - 2018-05-17 00:46:38 --> URI Class Initialized
INFO - 2018-05-17 00:46:38 --> Router Class Initialized
INFO - 2018-05-17 00:46:38 --> Output Class Initialized
INFO - 2018-05-17 00:46:38 --> Security Class Initialized
DEBUG - 2018-05-17 00:46:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 00:46:38 --> Input Class Initialized
INFO - 2018-05-17 00:46:38 --> Language Class Initialized
ERROR - 2018-05-17 00:46:38 --> 404 Page Not Found: /index
INFO - 2018-05-17 00:46:38 --> Config Class Initialized
INFO - 2018-05-17 00:46:38 --> Hooks Class Initialized
DEBUG - 2018-05-17 00:46:38 --> UTF-8 Support Enabled
INFO - 2018-05-17 00:46:38 --> Utf8 Class Initialized
INFO - 2018-05-17 00:46:38 --> URI Class Initialized
INFO - 2018-05-17 00:46:38 --> Router Class Initialized
INFO - 2018-05-17 00:46:38 --> Output Class Initialized
INFO - 2018-05-17 00:46:38 --> Security Class Initialized
DEBUG - 2018-05-17 00:46:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 00:46:38 --> Input Class Initialized
INFO - 2018-05-17 00:46:38 --> Language Class Initialized
ERROR - 2018-05-17 00:46:38 --> 404 Page Not Found: /index
INFO - 2018-05-17 00:47:48 --> Config Class Initialized
INFO - 2018-05-17 00:47:48 --> Hooks Class Initialized
DEBUG - 2018-05-17 00:47:48 --> UTF-8 Support Enabled
INFO - 2018-05-17 00:47:48 --> Utf8 Class Initialized
INFO - 2018-05-17 00:47:48 --> URI Class Initialized
INFO - 2018-05-17 00:47:48 --> Router Class Initialized
INFO - 2018-05-17 00:47:48 --> Output Class Initialized
INFO - 2018-05-17 00:47:48 --> Security Class Initialized
DEBUG - 2018-05-17 00:47:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 00:47:48 --> Input Class Initialized
INFO - 2018-05-17 00:47:48 --> Language Class Initialized
INFO - 2018-05-17 00:47:48 --> Language Class Initialized
INFO - 2018-05-17 00:47:48 --> Config Class Initialized
INFO - 2018-05-17 00:47:48 --> Loader Class Initialized
DEBUG - 2018-05-17 00:47:48 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-17 00:47:48 --> Helper loaded: url_helper
INFO - 2018-05-17 00:47:48 --> Helper loaded: form_helper
INFO - 2018-05-17 00:47:48 --> Helper loaded: date_helper
INFO - 2018-05-17 00:47:48 --> Helper loaded: util_helper
INFO - 2018-05-17 00:47:48 --> Helper loaded: text_helper
INFO - 2018-05-17 00:47:48 --> Helper loaded: string_helper
INFO - 2018-05-17 00:47:48 --> Database Driver Class Initialized
DEBUG - 2018-05-17 00:47:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-17 00:47:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-17 00:47:48 --> Email Class Initialized
INFO - 2018-05-17 00:47:48 --> Controller Class Initialized
DEBUG - 2018-05-17 00:47:48 --> Home MX_Controller Initialized
DEBUG - 2018-05-17 00:47:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-17 00:47:48 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-17 00:47:48 --> Login MX_Controller Initialized
INFO - 2018-05-17 00:47:48 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-17 00:47:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-17 00:47:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-17 00:47:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-17 00:47:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
INFO - 2018-05-17 00:47:50 --> Config Class Initialized
INFO - 2018-05-17 00:47:50 --> Hooks Class Initialized
DEBUG - 2018-05-17 00:47:50 --> UTF-8 Support Enabled
INFO - 2018-05-17 00:47:50 --> Utf8 Class Initialized
INFO - 2018-05-17 00:47:50 --> URI Class Initialized
INFO - 2018-05-17 00:47:50 --> Router Class Initialized
INFO - 2018-05-17 00:47:50 --> Output Class Initialized
INFO - 2018-05-17 00:47:50 --> Security Class Initialized
DEBUG - 2018-05-17 00:47:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 00:47:50 --> Input Class Initialized
INFO - 2018-05-17 00:47:50 --> Language Class Initialized
ERROR - 2018-05-17 00:47:50 --> 404 Page Not Found: /index
INFO - 2018-05-17 00:47:50 --> Config Class Initialized
INFO - 2018-05-17 00:47:50 --> Hooks Class Initialized
DEBUG - 2018-05-17 00:47:50 --> UTF-8 Support Enabled
INFO - 2018-05-17 00:47:50 --> Utf8 Class Initialized
INFO - 2018-05-17 00:47:50 --> URI Class Initialized
INFO - 2018-05-17 00:47:50 --> Router Class Initialized
INFO - 2018-05-17 00:47:50 --> Output Class Initialized
INFO - 2018-05-17 00:47:50 --> Security Class Initialized
DEBUG - 2018-05-17 00:47:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 00:47:50 --> Input Class Initialized
INFO - 2018-05-17 00:47:50 --> Language Class Initialized
ERROR - 2018-05-17 00:47:50 --> 404 Page Not Found: /index
INFO - 2018-05-17 00:47:50 --> Config Class Initialized
INFO - 2018-05-17 00:47:50 --> Hooks Class Initialized
DEBUG - 2018-05-17 00:47:50 --> UTF-8 Support Enabled
INFO - 2018-05-17 00:47:50 --> Utf8 Class Initialized
INFO - 2018-05-17 00:47:50 --> URI Class Initialized
INFO - 2018-05-17 00:47:50 --> Router Class Initialized
INFO - 2018-05-17 00:47:50 --> Output Class Initialized
INFO - 2018-05-17 00:47:50 --> Security Class Initialized
DEBUG - 2018-05-17 00:47:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 00:47:50 --> Input Class Initialized
INFO - 2018-05-17 00:47:50 --> Language Class Initialized
ERROR - 2018-05-17 00:47:50 --> 404 Page Not Found: /index
INFO - 2018-05-17 00:48:20 --> Config Class Initialized
INFO - 2018-05-17 00:48:20 --> Hooks Class Initialized
DEBUG - 2018-05-17 00:48:20 --> UTF-8 Support Enabled
INFO - 2018-05-17 00:48:20 --> Utf8 Class Initialized
INFO - 2018-05-17 00:48:20 --> URI Class Initialized
INFO - 2018-05-17 00:48:20 --> Router Class Initialized
INFO - 2018-05-17 00:48:20 --> Output Class Initialized
INFO - 2018-05-17 00:48:20 --> Security Class Initialized
DEBUG - 2018-05-17 00:48:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 00:48:20 --> Input Class Initialized
INFO - 2018-05-17 00:48:20 --> Language Class Initialized
INFO - 2018-05-17 00:48:20 --> Language Class Initialized
INFO - 2018-05-17 00:48:20 --> Config Class Initialized
INFO - 2018-05-17 00:48:20 --> Loader Class Initialized
DEBUG - 2018-05-17 00:48:20 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-17 00:48:20 --> Helper loaded: url_helper
INFO - 2018-05-17 00:48:20 --> Helper loaded: form_helper
INFO - 2018-05-17 00:48:20 --> Helper loaded: date_helper
INFO - 2018-05-17 00:48:20 --> Helper loaded: util_helper
INFO - 2018-05-17 00:48:20 --> Helper loaded: text_helper
INFO - 2018-05-17 00:48:20 --> Helper loaded: string_helper
INFO - 2018-05-17 00:48:20 --> Database Driver Class Initialized
DEBUG - 2018-05-17 00:48:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-17 00:48:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-17 00:48:20 --> Email Class Initialized
INFO - 2018-05-17 00:48:20 --> Controller Class Initialized
DEBUG - 2018-05-17 00:48:20 --> Home MX_Controller Initialized
DEBUG - 2018-05-17 00:48:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-17 00:48:20 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-17 00:48:20 --> Login MX_Controller Initialized
INFO - 2018-05-17 00:48:20 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-17 00:48:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-17 00:48:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-17 00:48:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-17 00:48:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
INFO - 2018-05-17 00:48:21 --> Config Class Initialized
INFO - 2018-05-17 00:48:21 --> Hooks Class Initialized
DEBUG - 2018-05-17 00:48:21 --> UTF-8 Support Enabled
INFO - 2018-05-17 00:48:21 --> Utf8 Class Initialized
INFO - 2018-05-17 00:48:21 --> URI Class Initialized
INFO - 2018-05-17 00:48:21 --> Router Class Initialized
INFO - 2018-05-17 00:48:21 --> Output Class Initialized
INFO - 2018-05-17 00:48:21 --> Security Class Initialized
DEBUG - 2018-05-17 00:48:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 00:48:21 --> Input Class Initialized
INFO - 2018-05-17 00:48:21 --> Language Class Initialized
ERROR - 2018-05-17 00:48:21 --> 404 Page Not Found: /index
INFO - 2018-05-17 00:48:21 --> Config Class Initialized
INFO - 2018-05-17 00:48:21 --> Hooks Class Initialized
DEBUG - 2018-05-17 00:48:21 --> UTF-8 Support Enabled
INFO - 2018-05-17 00:48:21 --> Utf8 Class Initialized
INFO - 2018-05-17 00:48:21 --> URI Class Initialized
INFO - 2018-05-17 00:48:21 --> Router Class Initialized
INFO - 2018-05-17 00:48:21 --> Output Class Initialized
INFO - 2018-05-17 00:48:21 --> Security Class Initialized
DEBUG - 2018-05-17 00:48:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 00:48:22 --> Input Class Initialized
INFO - 2018-05-17 00:48:22 --> Language Class Initialized
ERROR - 2018-05-17 00:48:22 --> 404 Page Not Found: /index
INFO - 2018-05-17 00:48:22 --> Config Class Initialized
INFO - 2018-05-17 00:48:22 --> Hooks Class Initialized
DEBUG - 2018-05-17 00:48:22 --> UTF-8 Support Enabled
INFO - 2018-05-17 00:48:22 --> Utf8 Class Initialized
INFO - 2018-05-17 00:48:22 --> URI Class Initialized
INFO - 2018-05-17 00:48:22 --> Router Class Initialized
INFO - 2018-05-17 00:48:22 --> Output Class Initialized
INFO - 2018-05-17 00:48:22 --> Security Class Initialized
DEBUG - 2018-05-17 00:48:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 00:48:22 --> Input Class Initialized
INFO - 2018-05-17 00:48:22 --> Language Class Initialized
ERROR - 2018-05-17 00:48:22 --> 404 Page Not Found: /index
INFO - 2018-05-17 00:48:25 --> Config Class Initialized
INFO - 2018-05-17 00:48:25 --> Hooks Class Initialized
DEBUG - 2018-05-17 00:48:25 --> UTF-8 Support Enabled
INFO - 2018-05-17 00:48:25 --> Utf8 Class Initialized
INFO - 2018-05-17 00:48:25 --> URI Class Initialized
INFO - 2018-05-17 00:48:25 --> Router Class Initialized
INFO - 2018-05-17 00:48:25 --> Output Class Initialized
INFO - 2018-05-17 00:48:25 --> Security Class Initialized
DEBUG - 2018-05-17 00:48:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 00:48:25 --> Input Class Initialized
INFO - 2018-05-17 00:48:25 --> Language Class Initialized
INFO - 2018-05-17 00:48:25 --> Language Class Initialized
INFO - 2018-05-17 00:48:25 --> Config Class Initialized
INFO - 2018-05-17 00:48:25 --> Loader Class Initialized
DEBUG - 2018-05-17 00:48:25 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-17 00:48:25 --> Helper loaded: url_helper
INFO - 2018-05-17 00:48:25 --> Helper loaded: form_helper
INFO - 2018-05-17 00:48:25 --> Helper loaded: date_helper
INFO - 2018-05-17 00:48:25 --> Helper loaded: util_helper
INFO - 2018-05-17 00:48:25 --> Helper loaded: text_helper
INFO - 2018-05-17 00:48:25 --> Helper loaded: string_helper
INFO - 2018-05-17 00:48:25 --> Database Driver Class Initialized
DEBUG - 2018-05-17 00:48:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-17 00:48:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-17 00:48:25 --> Email Class Initialized
INFO - 2018-05-17 00:48:25 --> Controller Class Initialized
DEBUG - 2018-05-17 00:48:26 --> Home MX_Controller Initialized
DEBUG - 2018-05-17 00:48:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-17 00:48:26 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-17 00:48:26 --> Login MX_Controller Initialized
INFO - 2018-05-17 00:48:26 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-17 00:48:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-17 00:48:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-17 00:48:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-17 00:48:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-17 00:48:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-17 00:48:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-17 00:48:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-17 00:48:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-05-17 00:48:26 --> Final output sent to browser
DEBUG - 2018-05-17 00:48:26 --> Total execution time: 0.3766
INFO - 2018-05-17 00:48:26 --> Config Class Initialized
INFO - 2018-05-17 00:48:26 --> Hooks Class Initialized
INFO - 2018-05-17 00:48:26 --> Config Class Initialized
INFO - 2018-05-17 00:48:26 --> Hooks Class Initialized
DEBUG - 2018-05-17 00:48:26 --> UTF-8 Support Enabled
INFO - 2018-05-17 00:48:26 --> Utf8 Class Initialized
DEBUG - 2018-05-17 00:48:26 --> UTF-8 Support Enabled
INFO - 2018-05-17 00:48:26 --> Utf8 Class Initialized
INFO - 2018-05-17 00:48:26 --> URI Class Initialized
INFO - 2018-05-17 00:48:27 --> URI Class Initialized
INFO - 2018-05-17 00:48:27 --> Router Class Initialized
INFO - 2018-05-17 00:48:27 --> Output Class Initialized
INFO - 2018-05-17 00:48:27 --> Router Class Initialized
INFO - 2018-05-17 00:48:27 --> Output Class Initialized
INFO - 2018-05-17 00:48:27 --> Security Class Initialized
DEBUG - 2018-05-17 00:48:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 00:48:27 --> Security Class Initialized
INFO - 2018-05-17 00:48:27 --> Input Class Initialized
INFO - 2018-05-17 00:48:27 --> Language Class Initialized
ERROR - 2018-05-17 00:48:27 --> 404 Page Not Found: /index
DEBUG - 2018-05-17 00:48:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 00:48:27 --> Input Class Initialized
INFO - 2018-05-17 00:48:27 --> Language Class Initialized
ERROR - 2018-05-17 00:48:27 --> 404 Page Not Found: /index
INFO - 2018-05-17 00:48:27 --> Config Class Initialized
INFO - 2018-05-17 00:48:27 --> Hooks Class Initialized
DEBUG - 2018-05-17 00:48:27 --> UTF-8 Support Enabled
INFO - 2018-05-17 00:48:27 --> Utf8 Class Initialized
INFO - 2018-05-17 00:48:27 --> URI Class Initialized
INFO - 2018-05-17 00:48:27 --> Router Class Initialized
INFO - 2018-05-17 00:48:27 --> Output Class Initialized
INFO - 2018-05-17 00:48:27 --> Security Class Initialized
DEBUG - 2018-05-17 00:48:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 00:48:27 --> Input Class Initialized
INFO - 2018-05-17 00:48:27 --> Language Class Initialized
ERROR - 2018-05-17 00:48:27 --> 404 Page Not Found: /index
INFO - 2018-05-17 00:48:27 --> Config Class Initialized
INFO - 2018-05-17 00:48:27 --> Hooks Class Initialized
DEBUG - 2018-05-17 00:48:27 --> UTF-8 Support Enabled
INFO - 2018-05-17 00:48:27 --> Utf8 Class Initialized
INFO - 2018-05-17 00:48:27 --> URI Class Initialized
INFO - 2018-05-17 00:48:27 --> Router Class Initialized
INFO - 2018-05-17 00:48:27 --> Output Class Initialized
INFO - 2018-05-17 00:48:27 --> Security Class Initialized
DEBUG - 2018-05-17 00:48:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 00:48:27 --> Input Class Initialized
INFO - 2018-05-17 00:48:27 --> Language Class Initialized
ERROR - 2018-05-17 00:48:27 --> 404 Page Not Found: /index
INFO - 2018-05-17 00:48:31 --> Config Class Initialized
INFO - 2018-05-17 00:48:31 --> Hooks Class Initialized
DEBUG - 2018-05-17 00:48:31 --> UTF-8 Support Enabled
INFO - 2018-05-17 00:48:31 --> Utf8 Class Initialized
INFO - 2018-05-17 00:48:31 --> URI Class Initialized
INFO - 2018-05-17 00:48:31 --> Router Class Initialized
INFO - 2018-05-17 00:48:31 --> Output Class Initialized
INFO - 2018-05-17 00:48:31 --> Security Class Initialized
DEBUG - 2018-05-17 00:48:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 00:48:31 --> Input Class Initialized
INFO - 2018-05-17 00:48:31 --> Language Class Initialized
ERROR - 2018-05-17 00:48:31 --> 404 Page Not Found: /index
INFO - 2018-05-17 00:48:31 --> Config Class Initialized
INFO - 2018-05-17 00:48:31 --> Hooks Class Initialized
DEBUG - 2018-05-17 00:48:31 --> UTF-8 Support Enabled
INFO - 2018-05-17 00:48:31 --> Utf8 Class Initialized
INFO - 2018-05-17 00:48:31 --> URI Class Initialized
INFO - 2018-05-17 00:48:31 --> Router Class Initialized
INFO - 2018-05-17 00:48:31 --> Output Class Initialized
INFO - 2018-05-17 00:48:31 --> Security Class Initialized
DEBUG - 2018-05-17 00:48:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 00:48:31 --> Input Class Initialized
INFO - 2018-05-17 00:48:31 --> Language Class Initialized
ERROR - 2018-05-17 00:48:31 --> 404 Page Not Found: /index
INFO - 2018-05-17 00:48:31 --> Config Class Initialized
INFO - 2018-05-17 00:48:31 --> Hooks Class Initialized
DEBUG - 2018-05-17 00:48:31 --> UTF-8 Support Enabled
INFO - 2018-05-17 00:48:31 --> Utf8 Class Initialized
INFO - 2018-05-17 00:48:31 --> URI Class Initialized
INFO - 2018-05-17 00:48:31 --> Router Class Initialized
INFO - 2018-05-17 00:48:31 --> Output Class Initialized
INFO - 2018-05-17 00:48:31 --> Security Class Initialized
DEBUG - 2018-05-17 00:48:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 00:48:31 --> Input Class Initialized
INFO - 2018-05-17 00:48:31 --> Language Class Initialized
ERROR - 2018-05-17 00:48:31 --> 404 Page Not Found: /index
INFO - 2018-05-17 00:49:03 --> Config Class Initialized
INFO - 2018-05-17 00:49:03 --> Hooks Class Initialized
DEBUG - 2018-05-17 00:49:03 --> UTF-8 Support Enabled
INFO - 2018-05-17 00:49:03 --> Utf8 Class Initialized
INFO - 2018-05-17 00:49:03 --> URI Class Initialized
INFO - 2018-05-17 00:49:03 --> Router Class Initialized
INFO - 2018-05-17 00:49:03 --> Output Class Initialized
INFO - 2018-05-17 00:49:03 --> Security Class Initialized
DEBUG - 2018-05-17 00:49:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 00:49:03 --> Input Class Initialized
INFO - 2018-05-17 00:49:03 --> Language Class Initialized
INFO - 2018-05-17 00:49:03 --> Language Class Initialized
INFO - 2018-05-17 00:49:03 --> Config Class Initialized
INFO - 2018-05-17 00:49:03 --> Loader Class Initialized
DEBUG - 2018-05-17 00:49:03 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-17 00:49:03 --> Helper loaded: url_helper
INFO - 2018-05-17 00:49:03 --> Helper loaded: form_helper
INFO - 2018-05-17 00:49:03 --> Helper loaded: date_helper
INFO - 2018-05-17 00:49:03 --> Helper loaded: util_helper
INFO - 2018-05-17 00:49:03 --> Helper loaded: text_helper
INFO - 2018-05-17 00:49:03 --> Helper loaded: string_helper
INFO - 2018-05-17 00:49:03 --> Database Driver Class Initialized
DEBUG - 2018-05-17 00:49:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-17 00:49:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-17 00:49:03 --> Email Class Initialized
INFO - 2018-05-17 00:49:03 --> Controller Class Initialized
DEBUG - 2018-05-17 00:49:03 --> Home MX_Controller Initialized
DEBUG - 2018-05-17 00:49:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-17 00:49:04 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-17 00:49:04 --> Login MX_Controller Initialized
INFO - 2018-05-17 00:49:04 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-17 00:49:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-17 00:49:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-17 00:49:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-17 00:49:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-17 00:49:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-17 00:49:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-17 00:49:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-17 00:49:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-05-17 00:49:04 --> Final output sent to browser
DEBUG - 2018-05-17 00:49:04 --> Total execution time: 0.3889
INFO - 2018-05-17 00:49:04 --> Config Class Initialized
INFO - 2018-05-17 00:49:04 --> Hooks Class Initialized
INFO - 2018-05-17 00:49:04 --> Config Class Initialized
INFO - 2018-05-17 00:49:04 --> Hooks Class Initialized
DEBUG - 2018-05-17 00:49:04 --> UTF-8 Support Enabled
DEBUG - 2018-05-17 00:49:04 --> UTF-8 Support Enabled
INFO - 2018-05-17 00:49:04 --> Utf8 Class Initialized
INFO - 2018-05-17 00:49:04 --> Utf8 Class Initialized
INFO - 2018-05-17 00:49:04 --> URI Class Initialized
INFO - 2018-05-17 00:49:04 --> URI Class Initialized
INFO - 2018-05-17 00:49:04 --> Router Class Initialized
INFO - 2018-05-17 00:49:04 --> Output Class Initialized
INFO - 2018-05-17 00:49:04 --> Router Class Initialized
INFO - 2018-05-17 00:49:04 --> Security Class Initialized
INFO - 2018-05-17 00:49:04 --> Output Class Initialized
INFO - 2018-05-17 00:49:04 --> Security Class Initialized
DEBUG - 2018-05-17 00:49:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 00:49:04 --> Input Class Initialized
DEBUG - 2018-05-17 00:49:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 00:49:04 --> Input Class Initialized
INFO - 2018-05-17 00:49:04 --> Language Class Initialized
INFO - 2018-05-17 00:49:04 --> Language Class Initialized
ERROR - 2018-05-17 00:49:04 --> 404 Page Not Found: /index
ERROR - 2018-05-17 00:49:05 --> 404 Page Not Found: /index
INFO - 2018-05-17 00:49:05 --> Config Class Initialized
INFO - 2018-05-17 00:49:05 --> Hooks Class Initialized
DEBUG - 2018-05-17 00:49:05 --> UTF-8 Support Enabled
INFO - 2018-05-17 00:49:05 --> Utf8 Class Initialized
INFO - 2018-05-17 00:49:05 --> URI Class Initialized
INFO - 2018-05-17 00:49:05 --> Router Class Initialized
INFO - 2018-05-17 00:49:05 --> Output Class Initialized
INFO - 2018-05-17 00:49:05 --> Security Class Initialized
DEBUG - 2018-05-17 00:49:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 00:49:05 --> Input Class Initialized
INFO - 2018-05-17 00:49:05 --> Language Class Initialized
ERROR - 2018-05-17 00:49:05 --> 404 Page Not Found: /index
INFO - 2018-05-17 00:49:05 --> Config Class Initialized
INFO - 2018-05-17 00:49:05 --> Hooks Class Initialized
DEBUG - 2018-05-17 00:49:05 --> UTF-8 Support Enabled
INFO - 2018-05-17 00:49:05 --> Utf8 Class Initialized
INFO - 2018-05-17 00:49:05 --> URI Class Initialized
INFO - 2018-05-17 00:49:05 --> Router Class Initialized
INFO - 2018-05-17 00:49:05 --> Output Class Initialized
INFO - 2018-05-17 00:49:05 --> Security Class Initialized
DEBUG - 2018-05-17 00:49:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 00:49:05 --> Input Class Initialized
INFO - 2018-05-17 00:49:05 --> Language Class Initialized
ERROR - 2018-05-17 00:49:05 --> 404 Page Not Found: /index
INFO - 2018-05-17 00:49:06 --> Config Class Initialized
INFO - 2018-05-17 00:49:06 --> Hooks Class Initialized
DEBUG - 2018-05-17 00:49:06 --> UTF-8 Support Enabled
INFO - 2018-05-17 00:49:06 --> Utf8 Class Initialized
INFO - 2018-05-17 00:49:06 --> URI Class Initialized
DEBUG - 2018-05-17 00:49:06 --> No URI present. Default controller set.
INFO - 2018-05-17 00:49:06 --> Router Class Initialized
INFO - 2018-05-17 00:49:06 --> Output Class Initialized
INFO - 2018-05-17 00:49:07 --> Security Class Initialized
DEBUG - 2018-05-17 00:49:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 00:49:07 --> Input Class Initialized
INFO - 2018-05-17 00:49:07 --> Language Class Initialized
INFO - 2018-05-17 00:49:07 --> Language Class Initialized
INFO - 2018-05-17 00:49:07 --> Config Class Initialized
INFO - 2018-05-17 00:49:07 --> Loader Class Initialized
DEBUG - 2018-05-17 00:49:07 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-17 00:49:07 --> Helper loaded: url_helper
INFO - 2018-05-17 00:49:07 --> Helper loaded: form_helper
INFO - 2018-05-17 00:49:07 --> Helper loaded: date_helper
INFO - 2018-05-17 00:49:07 --> Helper loaded: util_helper
INFO - 2018-05-17 00:49:07 --> Helper loaded: text_helper
INFO - 2018-05-17 00:49:07 --> Helper loaded: string_helper
INFO - 2018-05-17 00:49:07 --> Database Driver Class Initialized
DEBUG - 2018-05-17 00:49:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-17 00:49:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-17 00:49:07 --> Email Class Initialized
INFO - 2018-05-17 00:49:07 --> Controller Class Initialized
DEBUG - 2018-05-17 00:49:07 --> Home MX_Controller Initialized
DEBUG - 2018-05-17 00:49:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-17 00:49:07 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-17 00:49:07 --> Login MX_Controller Initialized
INFO - 2018-05-17 00:49:07 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-17 00:49:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-17 00:49:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-17 00:49:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-17 00:49:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-17 00:49:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-17 00:49:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-17 00:49:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-17 00:49:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-05-17 00:49:07 --> Final output sent to browser
DEBUG - 2018-05-17 00:49:07 --> Total execution time: 0.5047
INFO - 2018-05-17 00:49:07 --> Config Class Initialized
INFO - 2018-05-17 00:49:07 --> Hooks Class Initialized
DEBUG - 2018-05-17 00:49:07 --> UTF-8 Support Enabled
INFO - 2018-05-17 00:49:08 --> Utf8 Class Initialized
INFO - 2018-05-17 00:49:08 --> URI Class Initialized
INFO - 2018-05-17 00:49:08 --> Router Class Initialized
INFO - 2018-05-17 00:49:08 --> Output Class Initialized
INFO - 2018-05-17 00:49:08 --> Security Class Initialized
DEBUG - 2018-05-17 00:49:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 00:49:08 --> Input Class Initialized
INFO - 2018-05-17 00:49:08 --> Language Class Initialized
ERROR - 2018-05-17 00:49:08 --> 404 Page Not Found: /index
INFO - 2018-05-17 00:49:08 --> Config Class Initialized
INFO - 2018-05-17 00:49:08 --> Hooks Class Initialized
DEBUG - 2018-05-17 00:49:08 --> UTF-8 Support Enabled
INFO - 2018-05-17 00:49:08 --> Utf8 Class Initialized
INFO - 2018-05-17 00:49:08 --> URI Class Initialized
INFO - 2018-05-17 00:49:08 --> Router Class Initialized
INFO - 2018-05-17 00:49:08 --> Output Class Initialized
INFO - 2018-05-17 00:49:08 --> Security Class Initialized
DEBUG - 2018-05-17 00:49:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 00:49:08 --> Input Class Initialized
INFO - 2018-05-17 00:49:08 --> Language Class Initialized
ERROR - 2018-05-17 00:49:08 --> 404 Page Not Found: /index
INFO - 2018-05-17 00:49:08 --> Config Class Initialized
INFO - 2018-05-17 00:49:08 --> Hooks Class Initialized
DEBUG - 2018-05-17 00:49:08 --> UTF-8 Support Enabled
INFO - 2018-05-17 00:49:08 --> Utf8 Class Initialized
INFO - 2018-05-17 00:49:08 --> URI Class Initialized
INFO - 2018-05-17 00:49:08 --> Router Class Initialized
INFO - 2018-05-17 00:49:08 --> Output Class Initialized
INFO - 2018-05-17 00:49:08 --> Security Class Initialized
DEBUG - 2018-05-17 00:49:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 00:49:08 --> Input Class Initialized
INFO - 2018-05-17 00:49:08 --> Language Class Initialized
ERROR - 2018-05-17 00:49:08 --> 404 Page Not Found: /index
INFO - 2018-05-17 00:49:09 --> Config Class Initialized
INFO - 2018-05-17 00:49:09 --> Hooks Class Initialized
DEBUG - 2018-05-17 00:49:09 --> UTF-8 Support Enabled
INFO - 2018-05-17 00:49:09 --> Utf8 Class Initialized
INFO - 2018-05-17 00:49:09 --> URI Class Initialized
DEBUG - 2018-05-17 00:49:09 --> No URI present. Default controller set.
INFO - 2018-05-17 00:49:09 --> Router Class Initialized
INFO - 2018-05-17 00:49:09 --> Output Class Initialized
INFO - 2018-05-17 00:49:09 --> Security Class Initialized
DEBUG - 2018-05-17 00:49:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 00:49:09 --> Input Class Initialized
INFO - 2018-05-17 00:49:09 --> Language Class Initialized
INFO - 2018-05-17 00:49:09 --> Language Class Initialized
INFO - 2018-05-17 00:49:09 --> Config Class Initialized
INFO - 2018-05-17 00:49:09 --> Loader Class Initialized
DEBUG - 2018-05-17 00:49:09 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-17 00:49:09 --> Helper loaded: url_helper
INFO - 2018-05-17 00:49:09 --> Helper loaded: form_helper
INFO - 2018-05-17 00:49:09 --> Helper loaded: date_helper
INFO - 2018-05-17 00:49:09 --> Helper loaded: util_helper
INFO - 2018-05-17 00:49:09 --> Helper loaded: text_helper
INFO - 2018-05-17 00:49:09 --> Helper loaded: string_helper
INFO - 2018-05-17 00:49:09 --> Database Driver Class Initialized
DEBUG - 2018-05-17 00:49:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-17 00:49:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-17 00:49:09 --> Email Class Initialized
INFO - 2018-05-17 00:49:09 --> Controller Class Initialized
DEBUG - 2018-05-17 00:49:09 --> Home MX_Controller Initialized
DEBUG - 2018-05-17 00:49:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-17 00:49:09 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-17 00:49:09 --> Login MX_Controller Initialized
INFO - 2018-05-17 00:49:09 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-17 00:49:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-17 00:49:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-17 00:49:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-17 00:49:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-17 00:49:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-17 00:49:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-17 00:49:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-17 00:49:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-05-17 00:49:09 --> Final output sent to browser
DEBUG - 2018-05-17 00:49:09 --> Total execution time: 0.4012
INFO - 2018-05-17 00:49:10 --> Config Class Initialized
INFO - 2018-05-17 00:49:10 --> Hooks Class Initialized
DEBUG - 2018-05-17 00:49:10 --> UTF-8 Support Enabled
INFO - 2018-05-17 00:49:10 --> Utf8 Class Initialized
INFO - 2018-05-17 00:49:10 --> URI Class Initialized
INFO - 2018-05-17 00:49:10 --> Router Class Initialized
INFO - 2018-05-17 00:49:10 --> Output Class Initialized
INFO - 2018-05-17 00:49:10 --> Security Class Initialized
DEBUG - 2018-05-17 00:49:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 00:49:10 --> Input Class Initialized
INFO - 2018-05-17 00:49:10 --> Language Class Initialized
ERROR - 2018-05-17 00:49:10 --> 404 Page Not Found: /index
INFO - 2018-05-17 00:49:10 --> Config Class Initialized
INFO - 2018-05-17 00:49:10 --> Hooks Class Initialized
DEBUG - 2018-05-17 00:49:10 --> UTF-8 Support Enabled
INFO - 2018-05-17 00:49:10 --> Utf8 Class Initialized
INFO - 2018-05-17 00:49:10 --> URI Class Initialized
INFO - 2018-05-17 00:49:10 --> Router Class Initialized
INFO - 2018-05-17 00:49:10 --> Output Class Initialized
INFO - 2018-05-17 00:49:10 --> Security Class Initialized
DEBUG - 2018-05-17 00:49:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 00:49:10 --> Input Class Initialized
INFO - 2018-05-17 00:49:10 --> Language Class Initialized
ERROR - 2018-05-17 00:49:10 --> 404 Page Not Found: /index
INFO - 2018-05-17 00:49:10 --> Config Class Initialized
INFO - 2018-05-17 00:49:10 --> Hooks Class Initialized
DEBUG - 2018-05-17 00:49:10 --> UTF-8 Support Enabled
INFO - 2018-05-17 00:49:10 --> Utf8 Class Initialized
INFO - 2018-05-17 00:49:10 --> URI Class Initialized
INFO - 2018-05-17 00:49:10 --> Router Class Initialized
INFO - 2018-05-17 00:49:10 --> Output Class Initialized
INFO - 2018-05-17 00:49:10 --> Security Class Initialized
DEBUG - 2018-05-17 00:49:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 00:49:11 --> Input Class Initialized
INFO - 2018-05-17 00:49:11 --> Language Class Initialized
ERROR - 2018-05-17 00:49:11 --> 404 Page Not Found: /index
INFO - 2018-05-17 00:49:39 --> Config Class Initialized
INFO - 2018-05-17 00:49:39 --> Hooks Class Initialized
DEBUG - 2018-05-17 00:49:39 --> UTF-8 Support Enabled
INFO - 2018-05-17 00:49:39 --> Utf8 Class Initialized
INFO - 2018-05-17 00:49:39 --> URI Class Initialized
INFO - 2018-05-17 00:49:39 --> Router Class Initialized
INFO - 2018-05-17 00:49:39 --> Output Class Initialized
INFO - 2018-05-17 00:49:39 --> Security Class Initialized
DEBUG - 2018-05-17 00:49:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 00:49:39 --> Input Class Initialized
INFO - 2018-05-17 00:49:39 --> Language Class Initialized
INFO - 2018-05-17 00:49:39 --> Language Class Initialized
INFO - 2018-05-17 00:49:39 --> Config Class Initialized
INFO - 2018-05-17 00:49:39 --> Loader Class Initialized
DEBUG - 2018-05-17 00:49:39 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-17 00:49:39 --> Helper loaded: url_helper
INFO - 2018-05-17 00:49:39 --> Helper loaded: form_helper
INFO - 2018-05-17 00:49:39 --> Helper loaded: date_helper
INFO - 2018-05-17 00:49:39 --> Helper loaded: util_helper
INFO - 2018-05-17 00:49:39 --> Helper loaded: text_helper
INFO - 2018-05-17 00:49:39 --> Helper loaded: string_helper
INFO - 2018-05-17 00:49:39 --> Database Driver Class Initialized
DEBUG - 2018-05-17 00:49:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-17 00:49:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-17 00:49:39 --> Email Class Initialized
INFO - 2018-05-17 00:49:39 --> Controller Class Initialized
DEBUG - 2018-05-17 00:49:39 --> Home MX_Controller Initialized
DEBUG - 2018-05-17 00:49:39 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-17 00:49:39 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-17 00:49:39 --> Login MX_Controller Initialized
INFO - 2018-05-17 00:49:39 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-17 00:49:39 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-17 00:49:39 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-17 00:49:39 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-17 00:49:39 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-17 00:49:39 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-17 00:49:39 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-17 00:49:39 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-17 00:49:39 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-05-17 00:49:39 --> Final output sent to browser
DEBUG - 2018-05-17 00:49:39 --> Total execution time: 0.3943
INFO - 2018-05-17 00:49:40 --> Config Class Initialized
INFO - 2018-05-17 00:49:40 --> Config Class Initialized
INFO - 2018-05-17 00:49:40 --> Hooks Class Initialized
INFO - 2018-05-17 00:49:40 --> Hooks Class Initialized
DEBUG - 2018-05-17 00:49:40 --> UTF-8 Support Enabled
DEBUG - 2018-05-17 00:49:40 --> UTF-8 Support Enabled
INFO - 2018-05-17 00:49:40 --> Utf8 Class Initialized
INFO - 2018-05-17 00:49:40 --> Utf8 Class Initialized
INFO - 2018-05-17 00:49:40 --> URI Class Initialized
INFO - 2018-05-17 00:49:40 --> URI Class Initialized
INFO - 2018-05-17 00:49:40 --> Router Class Initialized
INFO - 2018-05-17 00:49:40 --> Router Class Initialized
INFO - 2018-05-17 00:49:40 --> Output Class Initialized
INFO - 2018-05-17 00:49:40 --> Output Class Initialized
INFO - 2018-05-17 00:49:40 --> Security Class Initialized
INFO - 2018-05-17 00:49:40 --> Security Class Initialized
DEBUG - 2018-05-17 00:49:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 00:49:40 --> Input Class Initialized
DEBUG - 2018-05-17 00:49:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 00:49:40 --> Language Class Initialized
INFO - 2018-05-17 00:49:40 --> Input Class Initialized
INFO - 2018-05-17 00:49:40 --> Language Class Initialized
ERROR - 2018-05-17 00:49:40 --> 404 Page Not Found: /index
ERROR - 2018-05-17 00:49:40 --> 404 Page Not Found: /index
INFO - 2018-05-17 00:49:41 --> Config Class Initialized
INFO - 2018-05-17 00:49:41 --> Hooks Class Initialized
DEBUG - 2018-05-17 00:49:41 --> UTF-8 Support Enabled
INFO - 2018-05-17 00:49:41 --> Utf8 Class Initialized
INFO - 2018-05-17 00:49:41 --> URI Class Initialized
INFO - 2018-05-17 00:49:41 --> Router Class Initialized
INFO - 2018-05-17 00:49:41 --> Output Class Initialized
INFO - 2018-05-17 00:49:41 --> Security Class Initialized
DEBUG - 2018-05-17 00:49:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 00:49:41 --> Input Class Initialized
INFO - 2018-05-17 00:49:41 --> Language Class Initialized
ERROR - 2018-05-17 00:49:41 --> 404 Page Not Found: /index
INFO - 2018-05-17 00:49:41 --> Config Class Initialized
INFO - 2018-05-17 00:49:41 --> Hooks Class Initialized
DEBUG - 2018-05-17 00:49:41 --> UTF-8 Support Enabled
INFO - 2018-05-17 00:49:41 --> Utf8 Class Initialized
INFO - 2018-05-17 00:49:41 --> URI Class Initialized
INFO - 2018-05-17 00:49:41 --> Router Class Initialized
INFO - 2018-05-17 00:49:41 --> Output Class Initialized
INFO - 2018-05-17 00:49:41 --> Security Class Initialized
DEBUG - 2018-05-17 00:49:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 00:49:41 --> Input Class Initialized
INFO - 2018-05-17 00:49:41 --> Language Class Initialized
ERROR - 2018-05-17 00:49:41 --> 404 Page Not Found: /index
INFO - 2018-05-17 01:31:09 --> Config Class Initialized
INFO - 2018-05-17 01:31:09 --> Hooks Class Initialized
DEBUG - 2018-05-17 01:31:09 --> UTF-8 Support Enabled
INFO - 2018-05-17 01:31:09 --> Utf8 Class Initialized
INFO - 2018-05-17 01:31:09 --> URI Class Initialized
INFO - 2018-05-17 01:31:09 --> Router Class Initialized
INFO - 2018-05-17 01:31:09 --> Output Class Initialized
INFO - 2018-05-17 01:31:09 --> Security Class Initialized
DEBUG - 2018-05-17 01:31:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 01:31:09 --> Input Class Initialized
INFO - 2018-05-17 01:31:09 --> Language Class Initialized
INFO - 2018-05-17 01:31:09 --> Language Class Initialized
INFO - 2018-05-17 01:31:09 --> Config Class Initialized
INFO - 2018-05-17 01:31:09 --> Loader Class Initialized
DEBUG - 2018-05-17 01:31:09 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-17 01:31:09 --> Helper loaded: url_helper
INFO - 2018-05-17 01:31:09 --> Helper loaded: form_helper
INFO - 2018-05-17 01:31:09 --> Helper loaded: date_helper
INFO - 2018-05-17 01:31:09 --> Helper loaded: util_helper
INFO - 2018-05-17 01:31:09 --> Helper loaded: text_helper
INFO - 2018-05-17 01:31:09 --> Helper loaded: string_helper
INFO - 2018-05-17 01:31:09 --> Database Driver Class Initialized
DEBUG - 2018-05-17 01:31:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-17 01:31:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-17 01:31:09 --> Email Class Initialized
INFO - 2018-05-17 01:31:09 --> Controller Class Initialized
DEBUG - 2018-05-17 01:31:09 --> Home MX_Controller Initialized
DEBUG - 2018-05-17 01:31:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-17 01:31:09 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-17 01:31:09 --> Login MX_Controller Initialized
INFO - 2018-05-17 01:31:09 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-17 01:31:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-17 01:31:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-17 01:31:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-17 01:31:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-17 01:31:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-17 01:31:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-17 01:31:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-17 01:31:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-05-17 01:31:09 --> Final output sent to browser
DEBUG - 2018-05-17 01:31:09 --> Total execution time: 0.3993
INFO - 2018-05-17 01:31:11 --> Config Class Initialized
INFO - 2018-05-17 01:31:11 --> Config Class Initialized
INFO - 2018-05-17 01:31:11 --> Hooks Class Initialized
INFO - 2018-05-17 01:31:11 --> Hooks Class Initialized
DEBUG - 2018-05-17 01:31:11 --> UTF-8 Support Enabled
DEBUG - 2018-05-17 01:31:11 --> UTF-8 Support Enabled
INFO - 2018-05-17 01:31:11 --> Utf8 Class Initialized
INFO - 2018-05-17 01:31:11 --> URI Class Initialized
INFO - 2018-05-17 01:31:11 --> Router Class Initialized
INFO - 2018-05-17 01:31:11 --> Output Class Initialized
INFO - 2018-05-17 01:31:11 --> Security Class Initialized
DEBUG - 2018-05-17 01:31:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 01:31:11 --> Input Class Initialized
INFO - 2018-05-17 01:31:11 --> Language Class Initialized
ERROR - 2018-05-17 01:31:11 --> 404 Page Not Found: /index
INFO - 2018-05-17 01:31:11 --> Utf8 Class Initialized
INFO - 2018-05-17 01:31:11 --> URI Class Initialized
INFO - 2018-05-17 01:31:11 --> Router Class Initialized
INFO - 2018-05-17 01:31:11 --> Output Class Initialized
INFO - 2018-05-17 01:31:11 --> Security Class Initialized
DEBUG - 2018-05-17 01:31:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 01:31:11 --> Input Class Initialized
INFO - 2018-05-17 01:31:11 --> Language Class Initialized
INFO - 2018-05-17 01:31:11 --> Config Class Initialized
INFO - 2018-05-17 01:31:11 --> Hooks Class Initialized
ERROR - 2018-05-17 01:31:11 --> 404 Page Not Found: /index
DEBUG - 2018-05-17 01:31:11 --> UTF-8 Support Enabled
INFO - 2018-05-17 01:31:11 --> Utf8 Class Initialized
INFO - 2018-05-17 01:31:11 --> URI Class Initialized
INFO - 2018-05-17 01:31:11 --> Router Class Initialized
INFO - 2018-05-17 01:31:11 --> Output Class Initialized
INFO - 2018-05-17 01:31:11 --> Security Class Initialized
DEBUG - 2018-05-17 01:31:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 01:31:11 --> Input Class Initialized
INFO - 2018-05-17 01:31:11 --> Language Class Initialized
ERROR - 2018-05-17 01:31:11 --> 404 Page Not Found: /index
INFO - 2018-05-17 01:31:11 --> Config Class Initialized
INFO - 2018-05-17 01:31:12 --> Hooks Class Initialized
DEBUG - 2018-05-17 01:31:12 --> UTF-8 Support Enabled
INFO - 2018-05-17 01:31:12 --> Utf8 Class Initialized
INFO - 2018-05-17 01:31:12 --> URI Class Initialized
INFO - 2018-05-17 01:31:12 --> Router Class Initialized
INFO - 2018-05-17 01:31:12 --> Output Class Initialized
INFO - 2018-05-17 01:31:12 --> Security Class Initialized
DEBUG - 2018-05-17 01:31:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 01:31:12 --> Input Class Initialized
INFO - 2018-05-17 01:31:12 --> Language Class Initialized
ERROR - 2018-05-17 01:31:12 --> 404 Page Not Found: /index
INFO - 2018-05-17 01:42:19 --> Config Class Initialized
INFO - 2018-05-17 01:42:19 --> Hooks Class Initialized
DEBUG - 2018-05-17 01:42:19 --> UTF-8 Support Enabled
INFO - 2018-05-17 01:42:19 --> Utf8 Class Initialized
INFO - 2018-05-17 01:42:19 --> URI Class Initialized
INFO - 2018-05-17 01:42:19 --> Router Class Initialized
INFO - 2018-05-17 01:42:19 --> Output Class Initialized
INFO - 2018-05-17 01:42:19 --> Security Class Initialized
DEBUG - 2018-05-17 01:42:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 01:42:19 --> Input Class Initialized
INFO - 2018-05-17 01:42:19 --> Language Class Initialized
INFO - 2018-05-17 01:42:19 --> Language Class Initialized
INFO - 2018-05-17 01:42:19 --> Config Class Initialized
INFO - 2018-05-17 01:42:20 --> Loader Class Initialized
DEBUG - 2018-05-17 01:42:20 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-17 01:42:20 --> Helper loaded: url_helper
INFO - 2018-05-17 01:42:20 --> Helper loaded: form_helper
INFO - 2018-05-17 01:42:20 --> Helper loaded: date_helper
INFO - 2018-05-17 01:42:20 --> Helper loaded: util_helper
INFO - 2018-05-17 01:42:20 --> Helper loaded: text_helper
INFO - 2018-05-17 01:42:20 --> Helper loaded: string_helper
INFO - 2018-05-17 01:42:20 --> Database Driver Class Initialized
DEBUG - 2018-05-17 01:42:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-17 01:42:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-17 01:42:20 --> Email Class Initialized
INFO - 2018-05-17 01:42:20 --> Controller Class Initialized
DEBUG - 2018-05-17 01:42:20 --> Home MX_Controller Initialized
DEBUG - 2018-05-17 01:42:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-17 01:42:20 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-17 01:42:20 --> Login MX_Controller Initialized
INFO - 2018-05-17 01:42:20 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-17 01:42:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-17 01:42:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-17 01:43:29 --> Config Class Initialized
INFO - 2018-05-17 01:43:29 --> Hooks Class Initialized
DEBUG - 2018-05-17 01:43:29 --> UTF-8 Support Enabled
INFO - 2018-05-17 01:43:29 --> Utf8 Class Initialized
INFO - 2018-05-17 01:43:29 --> URI Class Initialized
INFO - 2018-05-17 01:43:29 --> Router Class Initialized
INFO - 2018-05-17 01:43:29 --> Output Class Initialized
INFO - 2018-05-17 01:43:29 --> Security Class Initialized
DEBUG - 2018-05-17 01:43:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 01:43:29 --> Input Class Initialized
INFO - 2018-05-17 01:43:29 --> Language Class Initialized
INFO - 2018-05-17 01:43:29 --> Language Class Initialized
INFO - 2018-05-17 01:43:29 --> Config Class Initialized
INFO - 2018-05-17 01:43:29 --> Loader Class Initialized
DEBUG - 2018-05-17 01:43:29 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-17 01:43:29 --> Helper loaded: url_helper
INFO - 2018-05-17 01:43:29 --> Helper loaded: form_helper
INFO - 2018-05-17 01:43:29 --> Helper loaded: date_helper
INFO - 2018-05-17 01:43:29 --> Helper loaded: util_helper
INFO - 2018-05-17 01:43:29 --> Helper loaded: text_helper
INFO - 2018-05-17 01:43:29 --> Helper loaded: string_helper
INFO - 2018-05-17 01:43:29 --> Database Driver Class Initialized
DEBUG - 2018-05-17 01:43:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-17 01:43:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-17 01:43:29 --> Email Class Initialized
INFO - 2018-05-17 01:43:29 --> Controller Class Initialized
DEBUG - 2018-05-17 01:43:29 --> Home MX_Controller Initialized
DEBUG - 2018-05-17 01:43:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-17 01:43:29 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-17 01:43:29 --> Login MX_Controller Initialized
INFO - 2018-05-17 01:43:29 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-17 01:43:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-17 01:43:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-17 01:43:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-17 01:43:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-17 01:43:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-17 01:43:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-17 01:43:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-17 01:43:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-05-17 01:43:29 --> Final output sent to browser
DEBUG - 2018-05-17 01:43:29 --> Total execution time: 0.3819
INFO - 2018-05-17 01:43:32 --> Config Class Initialized
INFO - 2018-05-17 01:43:32 --> Hooks Class Initialized
INFO - 2018-05-17 01:43:32 --> Config Class Initialized
DEBUG - 2018-05-17 01:43:32 --> UTF-8 Support Enabled
INFO - 2018-05-17 01:43:32 --> Utf8 Class Initialized
INFO - 2018-05-17 01:43:32 --> URI Class Initialized
INFO - 2018-05-17 01:43:32 --> Router Class Initialized
INFO - 2018-05-17 01:43:32 --> Output Class Initialized
INFO - 2018-05-17 01:43:32 --> Hooks Class Initialized
INFO - 2018-05-17 01:43:32 --> Security Class Initialized
DEBUG - 2018-05-17 01:43:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-17 01:43:32 --> UTF-8 Support Enabled
INFO - 2018-05-17 01:43:32 --> Input Class Initialized
INFO - 2018-05-17 01:43:32 --> Utf8 Class Initialized
INFO - 2018-05-17 01:43:32 --> Language Class Initialized
ERROR - 2018-05-17 01:43:32 --> 404 Page Not Found: /index
INFO - 2018-05-17 01:43:32 --> URI Class Initialized
INFO - 2018-05-17 01:43:32 --> Router Class Initialized
INFO - 2018-05-17 01:43:32 --> Output Class Initialized
INFO - 2018-05-17 01:43:32 --> Security Class Initialized
DEBUG - 2018-05-17 01:43:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 01:43:32 --> Input Class Initialized
INFO - 2018-05-17 01:43:32 --> Language Class Initialized
ERROR - 2018-05-17 01:43:32 --> 404 Page Not Found: /index
INFO - 2018-05-17 01:43:32 --> Config Class Initialized
INFO - 2018-05-17 01:43:32 --> Hooks Class Initialized
DEBUG - 2018-05-17 01:43:32 --> UTF-8 Support Enabled
INFO - 2018-05-17 01:43:32 --> Utf8 Class Initialized
INFO - 2018-05-17 01:43:32 --> URI Class Initialized
INFO - 2018-05-17 01:43:32 --> Router Class Initialized
INFO - 2018-05-17 01:43:32 --> Output Class Initialized
INFO - 2018-05-17 01:43:32 --> Security Class Initialized
DEBUG - 2018-05-17 01:43:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 01:43:32 --> Input Class Initialized
INFO - 2018-05-17 01:43:32 --> Language Class Initialized
ERROR - 2018-05-17 01:43:32 --> 404 Page Not Found: /index
INFO - 2018-05-17 01:43:32 --> Config Class Initialized
INFO - 2018-05-17 01:43:32 --> Hooks Class Initialized
DEBUG - 2018-05-17 01:43:32 --> UTF-8 Support Enabled
INFO - 2018-05-17 01:43:32 --> Utf8 Class Initialized
INFO - 2018-05-17 01:43:32 --> URI Class Initialized
INFO - 2018-05-17 01:43:32 --> Router Class Initialized
INFO - 2018-05-17 01:43:32 --> Output Class Initialized
INFO - 2018-05-17 01:43:32 --> Security Class Initialized
DEBUG - 2018-05-17 01:43:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 01:43:33 --> Input Class Initialized
INFO - 2018-05-17 01:43:33 --> Language Class Initialized
ERROR - 2018-05-17 01:43:33 --> 404 Page Not Found: /index
INFO - 2018-05-17 01:43:39 --> Config Class Initialized
INFO - 2018-05-17 01:43:39 --> Hooks Class Initialized
DEBUG - 2018-05-17 01:43:39 --> UTF-8 Support Enabled
INFO - 2018-05-17 01:43:39 --> Utf8 Class Initialized
INFO - 2018-05-17 01:43:39 --> URI Class Initialized
INFO - 2018-05-17 01:43:39 --> Router Class Initialized
INFO - 2018-05-17 01:43:39 --> Output Class Initialized
INFO - 2018-05-17 01:43:39 --> Security Class Initialized
DEBUG - 2018-05-17 01:43:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 01:43:39 --> Input Class Initialized
INFO - 2018-05-17 01:43:39 --> Language Class Initialized
INFO - 2018-05-17 01:43:39 --> Language Class Initialized
INFO - 2018-05-17 01:43:39 --> Config Class Initialized
INFO - 2018-05-17 01:43:39 --> Loader Class Initialized
DEBUG - 2018-05-17 01:43:39 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-17 01:43:39 --> Helper loaded: url_helper
INFO - 2018-05-17 01:43:39 --> Helper loaded: form_helper
INFO - 2018-05-17 01:43:39 --> Helper loaded: date_helper
INFO - 2018-05-17 01:43:39 --> Helper loaded: util_helper
INFO - 2018-05-17 01:43:39 --> Helper loaded: text_helper
INFO - 2018-05-17 01:43:39 --> Helper loaded: string_helper
INFO - 2018-05-17 01:43:39 --> Database Driver Class Initialized
DEBUG - 2018-05-17 01:43:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-17 01:43:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-17 01:43:39 --> Email Class Initialized
INFO - 2018-05-17 01:43:39 --> Controller Class Initialized
DEBUG - 2018-05-17 01:43:39 --> Home MX_Controller Initialized
DEBUG - 2018-05-17 01:43:39 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-17 01:43:39 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-17 01:43:39 --> Login MX_Controller Initialized
INFO - 2018-05-17 01:43:39 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-17 01:43:39 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-17 01:43:39 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
ERROR - 2018-05-17 01:43:39 --> Severity: Notice --> Undefined variable: chapters_ls E:\xampp\htdocs\consulting\application\modules\home\controllers\Home.php 25
DEBUG - 2018-05-17 01:43:39 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-17 01:43:39 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-17 01:43:39 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-17 01:43:39 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-17 01:43:39 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-17 01:43:39 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-05-17 01:43:39 --> Final output sent to browser
DEBUG - 2018-05-17 01:43:39 --> Total execution time: 0.4841
INFO - 2018-05-17 01:43:40 --> Config Class Initialized
INFO - 2018-05-17 01:43:40 --> Config Class Initialized
INFO - 2018-05-17 01:43:40 --> Hooks Class Initialized
INFO - 2018-05-17 01:43:40 --> Hooks Class Initialized
DEBUG - 2018-05-17 01:43:40 --> UTF-8 Support Enabled
DEBUG - 2018-05-17 01:43:40 --> UTF-8 Support Enabled
INFO - 2018-05-17 01:43:40 --> Utf8 Class Initialized
INFO - 2018-05-17 01:43:40 --> URI Class Initialized
INFO - 2018-05-17 01:43:40 --> Utf8 Class Initialized
INFO - 2018-05-17 01:43:40 --> URI Class Initialized
INFO - 2018-05-17 01:43:40 --> Router Class Initialized
INFO - 2018-05-17 01:43:40 --> Router Class Initialized
INFO - 2018-05-17 01:43:40 --> Output Class Initialized
INFO - 2018-05-17 01:43:40 --> Security Class Initialized
INFO - 2018-05-17 01:43:40 --> Output Class Initialized
DEBUG - 2018-05-17 01:43:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 01:43:40 --> Input Class Initialized
INFO - 2018-05-17 01:43:40 --> Language Class Initialized
ERROR - 2018-05-17 01:43:40 --> 404 Page Not Found: /index
INFO - 2018-05-17 01:43:40 --> Security Class Initialized
INFO - 2018-05-17 01:43:40 --> Config Class Initialized
INFO - 2018-05-17 01:43:40 --> Hooks Class Initialized
DEBUG - 2018-05-17 01:43:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-17 01:43:40 --> UTF-8 Support Enabled
INFO - 2018-05-17 01:43:40 --> Utf8 Class Initialized
INFO - 2018-05-17 01:43:40 --> URI Class Initialized
INFO - 2018-05-17 01:43:40 --> Router Class Initialized
INFO - 2018-05-17 01:43:40 --> Output Class Initialized
INFO - 2018-05-17 01:43:40 --> Security Class Initialized
DEBUG - 2018-05-17 01:43:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 01:43:40 --> Input Class Initialized
INFO - 2018-05-17 01:43:40 --> Language Class Initialized
ERROR - 2018-05-17 01:43:40 --> 404 Page Not Found: /index
INFO - 2018-05-17 01:43:40 --> Input Class Initialized
INFO - 2018-05-17 01:43:40 --> Language Class Initialized
ERROR - 2018-05-17 01:43:40 --> 404 Page Not Found: /index
INFO - 2018-05-17 01:43:40 --> Config Class Initialized
INFO - 2018-05-17 01:43:40 --> Hooks Class Initialized
DEBUG - 2018-05-17 01:43:40 --> UTF-8 Support Enabled
INFO - 2018-05-17 01:43:40 --> Utf8 Class Initialized
INFO - 2018-05-17 01:43:40 --> URI Class Initialized
INFO - 2018-05-17 01:43:40 --> Router Class Initialized
INFO - 2018-05-17 01:43:40 --> Output Class Initialized
INFO - 2018-05-17 01:43:40 --> Security Class Initialized
DEBUG - 2018-05-17 01:43:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 01:43:40 --> Input Class Initialized
INFO - 2018-05-17 01:43:40 --> Language Class Initialized
ERROR - 2018-05-17 01:43:40 --> 404 Page Not Found: /index
INFO - 2018-05-17 01:43:42 --> Config Class Initialized
INFO - 2018-05-17 01:43:42 --> Hooks Class Initialized
DEBUG - 2018-05-17 01:43:42 --> UTF-8 Support Enabled
INFO - 2018-05-17 01:43:42 --> Utf8 Class Initialized
INFO - 2018-05-17 01:43:42 --> URI Class Initialized
INFO - 2018-05-17 01:43:42 --> Router Class Initialized
INFO - 2018-05-17 01:43:42 --> Output Class Initialized
INFO - 2018-05-17 01:43:42 --> Security Class Initialized
DEBUG - 2018-05-17 01:43:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 01:43:42 --> Input Class Initialized
INFO - 2018-05-17 01:43:42 --> Language Class Initialized
INFO - 2018-05-17 01:43:42 --> Language Class Initialized
INFO - 2018-05-17 01:43:42 --> Config Class Initialized
INFO - 2018-05-17 01:43:42 --> Loader Class Initialized
DEBUG - 2018-05-17 01:43:42 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-17 01:43:42 --> Helper loaded: url_helper
INFO - 2018-05-17 01:43:42 --> Helper loaded: form_helper
INFO - 2018-05-17 01:43:42 --> Helper loaded: date_helper
INFO - 2018-05-17 01:43:42 --> Helper loaded: util_helper
INFO - 2018-05-17 01:43:42 --> Helper loaded: text_helper
INFO - 2018-05-17 01:43:43 --> Helper loaded: string_helper
INFO - 2018-05-17 01:43:43 --> Database Driver Class Initialized
DEBUG - 2018-05-17 01:43:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-17 01:43:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-17 01:43:43 --> Email Class Initialized
INFO - 2018-05-17 01:43:43 --> Controller Class Initialized
DEBUG - 2018-05-17 01:43:43 --> Home MX_Controller Initialized
DEBUG - 2018-05-17 01:43:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-17 01:43:43 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-17 01:43:43 --> Login MX_Controller Initialized
INFO - 2018-05-17 01:43:43 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-17 01:43:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-17 01:43:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-17 01:43:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-17 01:43:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-17 01:43:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-17 01:43:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-17 01:43:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-17 01:43:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-05-17 01:43:43 --> Final output sent to browser
DEBUG - 2018-05-17 01:43:43 --> Total execution time: 0.4020
INFO - 2018-05-17 01:43:49 --> Config Class Initialized
INFO - 2018-05-17 01:43:49 --> Hooks Class Initialized
DEBUG - 2018-05-17 01:43:49 --> UTF-8 Support Enabled
INFO - 2018-05-17 01:43:49 --> Utf8 Class Initialized
INFO - 2018-05-17 01:43:49 --> URI Class Initialized
INFO - 2018-05-17 01:43:49 --> Router Class Initialized
INFO - 2018-05-17 01:43:49 --> Output Class Initialized
INFO - 2018-05-17 01:43:49 --> Security Class Initialized
DEBUG - 2018-05-17 01:43:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 01:43:49 --> Input Class Initialized
INFO - 2018-05-17 01:43:49 --> Language Class Initialized
ERROR - 2018-05-17 01:43:49 --> 404 Page Not Found: /index
INFO - 2018-05-17 01:43:49 --> Config Class Initialized
INFO - 2018-05-17 01:43:49 --> Hooks Class Initialized
DEBUG - 2018-05-17 01:43:49 --> UTF-8 Support Enabled
INFO - 2018-05-17 01:43:49 --> Utf8 Class Initialized
INFO - 2018-05-17 01:43:49 --> URI Class Initialized
INFO - 2018-05-17 01:43:49 --> Router Class Initialized
INFO - 2018-05-17 01:43:49 --> Output Class Initialized
INFO - 2018-05-17 01:43:49 --> Security Class Initialized
DEBUG - 2018-05-17 01:43:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 01:43:49 --> Input Class Initialized
INFO - 2018-05-17 01:43:49 --> Language Class Initialized
ERROR - 2018-05-17 01:43:49 --> 404 Page Not Found: /index
INFO - 2018-05-17 01:43:49 --> Config Class Initialized
INFO - 2018-05-17 01:43:49 --> Hooks Class Initialized
DEBUG - 2018-05-17 01:43:49 --> UTF-8 Support Enabled
INFO - 2018-05-17 01:43:49 --> Utf8 Class Initialized
INFO - 2018-05-17 01:43:49 --> URI Class Initialized
INFO - 2018-05-17 01:43:49 --> Router Class Initialized
INFO - 2018-05-17 01:43:49 --> Output Class Initialized
INFO - 2018-05-17 01:43:49 --> Security Class Initialized
DEBUG - 2018-05-17 01:43:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 01:43:49 --> Input Class Initialized
INFO - 2018-05-17 01:43:49 --> Language Class Initialized
ERROR - 2018-05-17 01:43:49 --> 404 Page Not Found: /index
INFO - 2018-05-17 01:44:43 --> Config Class Initialized
INFO - 2018-05-17 01:44:43 --> Hooks Class Initialized
DEBUG - 2018-05-17 01:44:43 --> UTF-8 Support Enabled
INFO - 2018-05-17 01:44:43 --> Utf8 Class Initialized
INFO - 2018-05-17 01:44:43 --> URI Class Initialized
INFO - 2018-05-17 01:44:43 --> Router Class Initialized
INFO - 2018-05-17 01:44:43 --> Output Class Initialized
INFO - 2018-05-17 01:44:43 --> Security Class Initialized
DEBUG - 2018-05-17 01:44:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 01:44:43 --> Input Class Initialized
INFO - 2018-05-17 01:44:43 --> Language Class Initialized
INFO - 2018-05-17 01:44:43 --> Language Class Initialized
INFO - 2018-05-17 01:44:43 --> Config Class Initialized
INFO - 2018-05-17 01:44:43 --> Loader Class Initialized
DEBUG - 2018-05-17 01:44:43 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-17 01:44:43 --> Helper loaded: url_helper
INFO - 2018-05-17 01:44:43 --> Helper loaded: form_helper
INFO - 2018-05-17 01:44:43 --> Helper loaded: date_helper
INFO - 2018-05-17 01:44:43 --> Helper loaded: util_helper
INFO - 2018-05-17 01:44:43 --> Helper loaded: text_helper
INFO - 2018-05-17 01:44:43 --> Helper loaded: string_helper
INFO - 2018-05-17 01:44:43 --> Database Driver Class Initialized
DEBUG - 2018-05-17 01:44:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-17 01:44:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-17 01:44:43 --> Email Class Initialized
INFO - 2018-05-17 01:44:43 --> Controller Class Initialized
DEBUG - 2018-05-17 01:44:43 --> Home MX_Controller Initialized
DEBUG - 2018-05-17 01:44:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-17 01:44:43 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-17 01:44:43 --> Login MX_Controller Initialized
INFO - 2018-05-17 01:44:43 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-17 01:44:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-17 01:44:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
ERROR - 2018-05-17 01:44:43 --> Severity: Notice --> Undefined variable: chapters_ls E:\xampp\htdocs\consulting\application\modules\home\controllers\Home.php 25
DEBUG - 2018-05-17 01:44:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-17 01:44:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-17 01:44:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-17 01:44:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-17 01:44:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-17 01:44:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-05-17 01:44:43 --> Final output sent to browser
DEBUG - 2018-05-17 01:44:43 --> Total execution time: 0.4107
INFO - 2018-05-17 01:44:44 --> Config Class Initialized
INFO - 2018-05-17 01:44:44 --> Config Class Initialized
INFO - 2018-05-17 01:44:44 --> Hooks Class Initialized
INFO - 2018-05-17 01:44:44 --> Hooks Class Initialized
DEBUG - 2018-05-17 01:44:44 --> UTF-8 Support Enabled
DEBUG - 2018-05-17 01:44:44 --> UTF-8 Support Enabled
INFO - 2018-05-17 01:44:44 --> Utf8 Class Initialized
INFO - 2018-05-17 01:44:44 --> Utf8 Class Initialized
INFO - 2018-05-17 01:44:44 --> URI Class Initialized
INFO - 2018-05-17 01:44:44 --> URI Class Initialized
INFO - 2018-05-17 01:44:44 --> Router Class Initialized
INFO - 2018-05-17 01:44:44 --> Router Class Initialized
INFO - 2018-05-17 01:44:44 --> Output Class Initialized
INFO - 2018-05-17 01:44:44 --> Output Class Initialized
INFO - 2018-05-17 01:44:44 --> Security Class Initialized
INFO - 2018-05-17 01:44:44 --> Security Class Initialized
DEBUG - 2018-05-17 01:44:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-17 01:44:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 01:44:44 --> Input Class Initialized
INFO - 2018-05-17 01:44:44 --> Input Class Initialized
INFO - 2018-05-17 01:44:44 --> Language Class Initialized
ERROR - 2018-05-17 01:44:44 --> 404 Page Not Found: /index
INFO - 2018-05-17 01:44:44 --> Language Class Initialized
ERROR - 2018-05-17 01:44:44 --> 404 Page Not Found: /index
INFO - 2018-05-17 01:44:44 --> Config Class Initialized
INFO - 2018-05-17 01:44:44 --> Hooks Class Initialized
DEBUG - 2018-05-17 01:44:44 --> UTF-8 Support Enabled
INFO - 2018-05-17 01:44:44 --> Utf8 Class Initialized
INFO - 2018-05-17 01:44:44 --> URI Class Initialized
INFO - 2018-05-17 01:44:44 --> Router Class Initialized
INFO - 2018-05-17 01:44:44 --> Output Class Initialized
INFO - 2018-05-17 01:44:44 --> Security Class Initialized
DEBUG - 2018-05-17 01:44:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 01:44:44 --> Input Class Initialized
INFO - 2018-05-17 01:44:44 --> Language Class Initialized
ERROR - 2018-05-17 01:44:44 --> 404 Page Not Found: /index
INFO - 2018-05-17 01:44:44 --> Config Class Initialized
INFO - 2018-05-17 01:44:44 --> Hooks Class Initialized
DEBUG - 2018-05-17 01:44:44 --> UTF-8 Support Enabled
INFO - 2018-05-17 01:44:44 --> Utf8 Class Initialized
INFO - 2018-05-17 01:44:44 --> URI Class Initialized
INFO - 2018-05-17 01:44:44 --> Router Class Initialized
INFO - 2018-05-17 01:44:44 --> Output Class Initialized
INFO - 2018-05-17 01:44:44 --> Security Class Initialized
DEBUG - 2018-05-17 01:44:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 01:44:44 --> Input Class Initialized
INFO - 2018-05-17 01:44:44 --> Language Class Initialized
ERROR - 2018-05-17 01:44:44 --> 404 Page Not Found: /index
INFO - 2018-05-17 01:44:46 --> Config Class Initialized
INFO - 2018-05-17 01:44:46 --> Hooks Class Initialized
DEBUG - 2018-05-17 01:44:46 --> UTF-8 Support Enabled
INFO - 2018-05-17 01:44:46 --> Utf8 Class Initialized
INFO - 2018-05-17 01:44:46 --> URI Class Initialized
INFO - 2018-05-17 01:44:46 --> Router Class Initialized
INFO - 2018-05-17 01:44:46 --> Output Class Initialized
INFO - 2018-05-17 01:44:46 --> Security Class Initialized
DEBUG - 2018-05-17 01:44:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 01:44:46 --> Input Class Initialized
INFO - 2018-05-17 01:44:46 --> Language Class Initialized
INFO - 2018-05-17 01:44:46 --> Language Class Initialized
INFO - 2018-05-17 01:44:46 --> Config Class Initialized
INFO - 2018-05-17 01:44:47 --> Loader Class Initialized
DEBUG - 2018-05-17 01:44:47 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-17 01:44:47 --> Helper loaded: url_helper
INFO - 2018-05-17 01:44:47 --> Helper loaded: form_helper
INFO - 2018-05-17 01:44:47 --> Helper loaded: date_helper
INFO - 2018-05-17 01:44:47 --> Helper loaded: util_helper
INFO - 2018-05-17 01:44:47 --> Helper loaded: text_helper
INFO - 2018-05-17 01:44:47 --> Helper loaded: string_helper
INFO - 2018-05-17 01:44:47 --> Database Driver Class Initialized
DEBUG - 2018-05-17 01:44:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-17 01:44:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-17 01:44:47 --> Email Class Initialized
INFO - 2018-05-17 01:44:47 --> Controller Class Initialized
DEBUG - 2018-05-17 01:44:47 --> Home MX_Controller Initialized
DEBUG - 2018-05-17 01:44:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-17 01:44:47 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-17 01:44:47 --> Login MX_Controller Initialized
INFO - 2018-05-17 01:44:47 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-17 01:44:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-17 01:44:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-17 01:44:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-17 01:44:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-17 01:44:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-17 01:44:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-17 01:44:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-17 01:44:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-05-17 01:44:47 --> Final output sent to browser
DEBUG - 2018-05-17 01:44:47 --> Total execution time: 0.4671
INFO - 2018-05-17 01:45:44 --> Config Class Initialized
INFO - 2018-05-17 01:45:44 --> Hooks Class Initialized
DEBUG - 2018-05-17 01:45:44 --> UTF-8 Support Enabled
INFO - 2018-05-17 01:45:44 --> Utf8 Class Initialized
INFO - 2018-05-17 01:45:44 --> URI Class Initialized
INFO - 2018-05-17 01:45:44 --> Router Class Initialized
INFO - 2018-05-17 01:45:44 --> Output Class Initialized
INFO - 2018-05-17 01:45:44 --> Security Class Initialized
DEBUG - 2018-05-17 01:45:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 01:45:44 --> Input Class Initialized
INFO - 2018-05-17 01:45:44 --> Language Class Initialized
INFO - 2018-05-17 01:45:44 --> Language Class Initialized
INFO - 2018-05-17 01:45:44 --> Config Class Initialized
INFO - 2018-05-17 01:45:44 --> Loader Class Initialized
DEBUG - 2018-05-17 01:45:44 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-17 01:45:44 --> Helper loaded: url_helper
INFO - 2018-05-17 01:45:44 --> Helper loaded: form_helper
INFO - 2018-05-17 01:45:44 --> Helper loaded: date_helper
INFO - 2018-05-17 01:45:44 --> Helper loaded: util_helper
INFO - 2018-05-17 01:45:44 --> Helper loaded: text_helper
INFO - 2018-05-17 01:45:44 --> Helper loaded: string_helper
INFO - 2018-05-17 01:45:44 --> Database Driver Class Initialized
DEBUG - 2018-05-17 01:45:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-17 01:45:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-17 01:45:44 --> Email Class Initialized
INFO - 2018-05-17 01:45:44 --> Controller Class Initialized
DEBUG - 2018-05-17 01:45:44 --> Home MX_Controller Initialized
DEBUG - 2018-05-17 01:45:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-17 01:45:44 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-17 01:45:44 --> Login MX_Controller Initialized
INFO - 2018-05-17 01:45:44 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-17 01:45:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-17 01:45:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-17 01:45:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-17 01:45:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-17 01:45:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-17 01:45:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-17 01:45:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-17 01:45:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-05-17 01:45:44 --> Final output sent to browser
DEBUG - 2018-05-17 01:45:44 --> Total execution time: 0.3917
INFO - 2018-05-17 01:45:49 --> Config Class Initialized
INFO - 2018-05-17 01:45:49 --> Config Class Initialized
INFO - 2018-05-17 01:45:49 --> Hooks Class Initialized
INFO - 2018-05-17 01:45:49 --> Hooks Class Initialized
DEBUG - 2018-05-17 01:45:49 --> UTF-8 Support Enabled
DEBUG - 2018-05-17 01:45:49 --> UTF-8 Support Enabled
INFO - 2018-05-17 01:45:49 --> Utf8 Class Initialized
INFO - 2018-05-17 01:45:49 --> Utf8 Class Initialized
INFO - 2018-05-17 01:45:49 --> URI Class Initialized
INFO - 2018-05-17 01:45:49 --> URI Class Initialized
INFO - 2018-05-17 01:45:49 --> Router Class Initialized
INFO - 2018-05-17 01:45:49 --> Router Class Initialized
INFO - 2018-05-17 01:45:49 --> Output Class Initialized
INFO - 2018-05-17 01:45:49 --> Output Class Initialized
INFO - 2018-05-17 01:45:49 --> Security Class Initialized
INFO - 2018-05-17 01:45:49 --> Security Class Initialized
DEBUG - 2018-05-17 01:45:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 01:45:49 --> Input Class Initialized
INFO - 2018-05-17 01:45:50 --> Language Class Initialized
DEBUG - 2018-05-17 01:45:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-05-17 01:45:50 --> 404 Page Not Found: /index
INFO - 2018-05-17 01:45:50 --> Input Class Initialized
INFO - 2018-05-17 01:45:50 --> Language Class Initialized
ERROR - 2018-05-17 01:45:50 --> 404 Page Not Found: /index
INFO - 2018-05-17 01:45:50 --> Config Class Initialized
INFO - 2018-05-17 01:45:50 --> Hooks Class Initialized
DEBUG - 2018-05-17 01:45:50 --> UTF-8 Support Enabled
INFO - 2018-05-17 01:45:50 --> Utf8 Class Initialized
INFO - 2018-05-17 01:45:50 --> URI Class Initialized
INFO - 2018-05-17 01:45:50 --> Router Class Initialized
INFO - 2018-05-17 01:45:50 --> Output Class Initialized
INFO - 2018-05-17 01:45:50 --> Security Class Initialized
DEBUG - 2018-05-17 01:45:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 01:45:50 --> Input Class Initialized
INFO - 2018-05-17 01:45:50 --> Language Class Initialized
ERROR - 2018-05-17 01:45:50 --> 404 Page Not Found: /index
INFO - 2018-05-17 01:45:50 --> Config Class Initialized
INFO - 2018-05-17 01:45:50 --> Hooks Class Initialized
DEBUG - 2018-05-17 01:45:50 --> UTF-8 Support Enabled
INFO - 2018-05-17 01:45:50 --> Utf8 Class Initialized
INFO - 2018-05-17 01:45:50 --> URI Class Initialized
INFO - 2018-05-17 01:45:50 --> Router Class Initialized
INFO - 2018-05-17 01:45:50 --> Output Class Initialized
INFO - 2018-05-17 01:45:50 --> Security Class Initialized
DEBUG - 2018-05-17 01:45:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 01:45:50 --> Input Class Initialized
INFO - 2018-05-17 01:45:50 --> Language Class Initialized
ERROR - 2018-05-17 01:45:50 --> 404 Page Not Found: /index
INFO - 2018-05-17 01:46:14 --> Config Class Initialized
INFO - 2018-05-17 01:46:14 --> Hooks Class Initialized
DEBUG - 2018-05-17 01:46:14 --> UTF-8 Support Enabled
INFO - 2018-05-17 01:46:14 --> Utf8 Class Initialized
INFO - 2018-05-17 01:46:14 --> URI Class Initialized
INFO - 2018-05-17 01:46:14 --> Router Class Initialized
INFO - 2018-05-17 01:46:14 --> Output Class Initialized
INFO - 2018-05-17 01:46:14 --> Security Class Initialized
DEBUG - 2018-05-17 01:46:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 01:46:14 --> Input Class Initialized
INFO - 2018-05-17 01:46:14 --> Language Class Initialized
ERROR - 2018-05-17 01:46:14 --> 404 Page Not Found: /index
INFO - 2018-05-17 01:46:15 --> Config Class Initialized
INFO - 2018-05-17 01:46:15 --> Hooks Class Initialized
DEBUG - 2018-05-17 01:46:15 --> UTF-8 Support Enabled
INFO - 2018-05-17 01:46:15 --> Utf8 Class Initialized
INFO - 2018-05-17 01:46:15 --> URI Class Initialized
INFO - 2018-05-17 01:46:15 --> Router Class Initialized
INFO - 2018-05-17 01:46:15 --> Output Class Initialized
INFO - 2018-05-17 01:46:15 --> Security Class Initialized
DEBUG - 2018-05-17 01:46:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 01:46:15 --> Input Class Initialized
INFO - 2018-05-17 01:46:15 --> Language Class Initialized
ERROR - 2018-05-17 01:46:15 --> 404 Page Not Found: /index
INFO - 2018-05-17 01:46:15 --> Config Class Initialized
INFO - 2018-05-17 01:46:15 --> Hooks Class Initialized
DEBUG - 2018-05-17 01:46:15 --> UTF-8 Support Enabled
INFO - 2018-05-17 01:46:15 --> Utf8 Class Initialized
INFO - 2018-05-17 01:46:15 --> URI Class Initialized
INFO - 2018-05-17 01:46:15 --> Router Class Initialized
INFO - 2018-05-17 01:46:15 --> Output Class Initialized
INFO - 2018-05-17 01:46:15 --> Security Class Initialized
DEBUG - 2018-05-17 01:46:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 01:46:15 --> Input Class Initialized
INFO - 2018-05-17 01:46:15 --> Language Class Initialized
ERROR - 2018-05-17 01:46:15 --> 404 Page Not Found: /index
INFO - 2018-05-17 01:46:23 --> Config Class Initialized
INFO - 2018-05-17 01:46:23 --> Hooks Class Initialized
DEBUG - 2018-05-17 01:46:23 --> UTF-8 Support Enabled
INFO - 2018-05-17 01:46:23 --> Utf8 Class Initialized
INFO - 2018-05-17 01:46:23 --> URI Class Initialized
INFO - 2018-05-17 01:46:23 --> Router Class Initialized
INFO - 2018-05-17 01:46:23 --> Output Class Initialized
INFO - 2018-05-17 01:46:23 --> Security Class Initialized
DEBUG - 2018-05-17 01:46:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 01:46:23 --> Input Class Initialized
INFO - 2018-05-17 01:46:23 --> Language Class Initialized
INFO - 2018-05-17 01:46:23 --> Language Class Initialized
INFO - 2018-05-17 01:46:23 --> Config Class Initialized
INFO - 2018-05-17 01:46:23 --> Loader Class Initialized
DEBUG - 2018-05-17 01:46:23 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-17 01:46:23 --> Helper loaded: url_helper
INFO - 2018-05-17 01:46:23 --> Helper loaded: form_helper
INFO - 2018-05-17 01:46:23 --> Helper loaded: date_helper
INFO - 2018-05-17 01:46:23 --> Helper loaded: util_helper
INFO - 2018-05-17 01:46:23 --> Helper loaded: text_helper
INFO - 2018-05-17 01:46:23 --> Helper loaded: string_helper
INFO - 2018-05-17 01:46:23 --> Database Driver Class Initialized
DEBUG - 2018-05-17 01:46:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-17 01:46:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-17 01:46:23 --> Email Class Initialized
INFO - 2018-05-17 01:46:23 --> Controller Class Initialized
DEBUG - 2018-05-17 01:46:23 --> Home MX_Controller Initialized
DEBUG - 2018-05-17 01:46:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-17 01:46:24 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-17 01:46:24 --> Login MX_Controller Initialized
INFO - 2018-05-17 01:46:24 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-17 01:46:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-17 01:46:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-17 01:46:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-17 01:46:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-17 01:46:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-17 01:46:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-17 01:46:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-17 01:46:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-05-17 01:46:24 --> Final output sent to browser
DEBUG - 2018-05-17 01:46:24 --> Total execution time: 0.4050
INFO - 2018-05-17 01:46:24 --> Config Class Initialized
INFO - 2018-05-17 01:46:24 --> Config Class Initialized
INFO - 2018-05-17 01:46:24 --> Hooks Class Initialized
INFO - 2018-05-17 01:46:24 --> Hooks Class Initialized
DEBUG - 2018-05-17 01:46:24 --> UTF-8 Support Enabled
DEBUG - 2018-05-17 01:46:24 --> UTF-8 Support Enabled
INFO - 2018-05-17 01:46:24 --> Utf8 Class Initialized
INFO - 2018-05-17 01:46:24 --> URI Class Initialized
INFO - 2018-05-17 01:46:24 --> Router Class Initialized
INFO - 2018-05-17 01:46:25 --> Output Class Initialized
INFO - 2018-05-17 01:46:25 --> Security Class Initialized
DEBUG - 2018-05-17 01:46:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 01:46:25 --> Input Class Initialized
INFO - 2018-05-17 01:46:25 --> Language Class Initialized
ERROR - 2018-05-17 01:46:25 --> 404 Page Not Found: /index
INFO - 2018-05-17 01:46:25 --> Utf8 Class Initialized
INFO - 2018-05-17 01:46:25 --> URI Class Initialized
INFO - 2018-05-17 01:46:25 --> Router Class Initialized
INFO - 2018-05-17 01:46:25 --> Output Class Initialized
INFO - 2018-05-17 01:46:25 --> Security Class Initialized
DEBUG - 2018-05-17 01:46:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 01:46:25 --> Config Class Initialized
INFO - 2018-05-17 01:46:25 --> Hooks Class Initialized
INFO - 2018-05-17 01:46:25 --> Input Class Initialized
DEBUG - 2018-05-17 01:46:25 --> UTF-8 Support Enabled
INFO - 2018-05-17 01:46:25 --> Utf8 Class Initialized
INFO - 2018-05-17 01:46:25 --> URI Class Initialized
INFO - 2018-05-17 01:46:25 --> Router Class Initialized
INFO - 2018-05-17 01:46:25 --> Output Class Initialized
INFO - 2018-05-17 01:46:25 --> Security Class Initialized
DEBUG - 2018-05-17 01:46:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 01:46:25 --> Input Class Initialized
INFO - 2018-05-17 01:46:25 --> Language Class Initialized
INFO - 2018-05-17 01:46:25 --> Language Class Initialized
ERROR - 2018-05-17 01:46:25 --> 404 Page Not Found: /index
ERROR - 2018-05-17 01:46:25 --> 404 Page Not Found: /index
INFO - 2018-05-17 01:46:25 --> Config Class Initialized
INFO - 2018-05-17 01:46:25 --> Hooks Class Initialized
DEBUG - 2018-05-17 01:46:25 --> UTF-8 Support Enabled
INFO - 2018-05-17 01:46:25 --> Utf8 Class Initialized
INFO - 2018-05-17 01:46:25 --> URI Class Initialized
INFO - 2018-05-17 01:46:25 --> Router Class Initialized
INFO - 2018-05-17 01:46:25 --> Output Class Initialized
INFO - 2018-05-17 01:46:25 --> Security Class Initialized
DEBUG - 2018-05-17 01:46:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 01:46:25 --> Input Class Initialized
INFO - 2018-05-17 01:46:25 --> Language Class Initialized
ERROR - 2018-05-17 01:46:25 --> 404 Page Not Found: /index
INFO - 2018-05-17 01:46:32 --> Config Class Initialized
INFO - 2018-05-17 01:46:32 --> Hooks Class Initialized
DEBUG - 2018-05-17 01:46:32 --> UTF-8 Support Enabled
INFO - 2018-05-17 01:46:32 --> Utf8 Class Initialized
INFO - 2018-05-17 01:46:32 --> URI Class Initialized
INFO - 2018-05-17 01:46:32 --> Router Class Initialized
INFO - 2018-05-17 01:46:32 --> Output Class Initialized
INFO - 2018-05-17 01:46:32 --> Security Class Initialized
DEBUG - 2018-05-17 01:46:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 01:46:32 --> Input Class Initialized
INFO - 2018-05-17 01:46:32 --> Language Class Initialized
INFO - 2018-05-17 01:46:32 --> Language Class Initialized
INFO - 2018-05-17 01:46:32 --> Config Class Initialized
INFO - 2018-05-17 01:46:32 --> Loader Class Initialized
DEBUG - 2018-05-17 01:46:32 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-17 01:46:32 --> Helper loaded: url_helper
INFO - 2018-05-17 01:46:32 --> Helper loaded: form_helper
INFO - 2018-05-17 01:46:32 --> Helper loaded: date_helper
INFO - 2018-05-17 01:46:32 --> Helper loaded: util_helper
INFO - 2018-05-17 01:46:32 --> Helper loaded: text_helper
INFO - 2018-05-17 01:46:32 --> Helper loaded: string_helper
INFO - 2018-05-17 01:46:32 --> Database Driver Class Initialized
DEBUG - 2018-05-17 01:46:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-17 01:46:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-17 01:46:32 --> Email Class Initialized
INFO - 2018-05-17 01:46:32 --> Controller Class Initialized
DEBUG - 2018-05-17 01:46:32 --> Home MX_Controller Initialized
DEBUG - 2018-05-17 01:46:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-17 01:46:32 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-17 01:46:32 --> Login MX_Controller Initialized
INFO - 2018-05-17 01:46:32 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-17 01:46:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-17 01:46:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
ERROR - 2018-05-17 01:46:32 --> Severity: Notice --> Undefined variable: chapters_ls E:\xampp\htdocs\consulting\application\modules\home\controllers\Home.php 25
DEBUG - 2018-05-17 01:46:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-17 01:46:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-17 01:46:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-17 01:46:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-17 01:46:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-17 01:46:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-05-17 01:46:32 --> Final output sent to browser
DEBUG - 2018-05-17 01:46:32 --> Total execution time: 0.4715
INFO - 2018-05-17 01:46:33 --> Config Class Initialized
INFO - 2018-05-17 01:46:33 --> Config Class Initialized
INFO - 2018-05-17 01:46:33 --> Hooks Class Initialized
INFO - 2018-05-17 01:46:33 --> Hooks Class Initialized
DEBUG - 2018-05-17 01:46:33 --> UTF-8 Support Enabled
DEBUG - 2018-05-17 01:46:33 --> UTF-8 Support Enabled
INFO - 2018-05-17 01:46:33 --> Utf8 Class Initialized
INFO - 2018-05-17 01:46:33 --> Utf8 Class Initialized
INFO - 2018-05-17 01:46:33 --> URI Class Initialized
INFO - 2018-05-17 01:46:33 --> URI Class Initialized
INFO - 2018-05-17 01:46:33 --> Router Class Initialized
INFO - 2018-05-17 01:46:33 --> Router Class Initialized
INFO - 2018-05-17 01:46:33 --> Output Class Initialized
INFO - 2018-05-17 01:46:33 --> Output Class Initialized
INFO - 2018-05-17 01:46:33 --> Security Class Initialized
INFO - 2018-05-17 01:46:33 --> Security Class Initialized
DEBUG - 2018-05-17 01:46:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-17 01:46:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 01:46:33 --> Input Class Initialized
INFO - 2018-05-17 01:46:33 --> Input Class Initialized
INFO - 2018-05-17 01:46:33 --> Language Class Initialized
ERROR - 2018-05-17 01:46:33 --> 404 Page Not Found: /index
INFO - 2018-05-17 01:46:33 --> Language Class Initialized
ERROR - 2018-05-17 01:46:33 --> 404 Page Not Found: /index
INFO - 2018-05-17 01:46:34 --> Config Class Initialized
INFO - 2018-05-17 01:46:34 --> Hooks Class Initialized
DEBUG - 2018-05-17 01:46:34 --> UTF-8 Support Enabled
INFO - 2018-05-17 01:46:34 --> Utf8 Class Initialized
INFO - 2018-05-17 01:46:34 --> URI Class Initialized
INFO - 2018-05-17 01:46:34 --> Router Class Initialized
INFO - 2018-05-17 01:46:34 --> Output Class Initialized
INFO - 2018-05-17 01:46:34 --> Security Class Initialized
DEBUG - 2018-05-17 01:46:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 01:46:34 --> Input Class Initialized
INFO - 2018-05-17 01:46:34 --> Language Class Initialized
ERROR - 2018-05-17 01:46:34 --> 404 Page Not Found: /index
INFO - 2018-05-17 01:46:34 --> Config Class Initialized
INFO - 2018-05-17 01:46:34 --> Hooks Class Initialized
DEBUG - 2018-05-17 01:46:34 --> UTF-8 Support Enabled
INFO - 2018-05-17 01:46:34 --> Utf8 Class Initialized
INFO - 2018-05-17 01:46:34 --> URI Class Initialized
INFO - 2018-05-17 01:46:34 --> Router Class Initialized
INFO - 2018-05-17 01:46:34 --> Output Class Initialized
INFO - 2018-05-17 01:46:34 --> Security Class Initialized
DEBUG - 2018-05-17 01:46:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 01:46:34 --> Input Class Initialized
INFO - 2018-05-17 01:46:34 --> Language Class Initialized
ERROR - 2018-05-17 01:46:34 --> 404 Page Not Found: /index
INFO - 2018-05-17 01:47:00 --> Config Class Initialized
INFO - 2018-05-17 01:47:00 --> Hooks Class Initialized
DEBUG - 2018-05-17 01:47:00 --> UTF-8 Support Enabled
INFO - 2018-05-17 01:47:00 --> Utf8 Class Initialized
INFO - 2018-05-17 01:47:00 --> URI Class Initialized
INFO - 2018-05-17 01:47:00 --> Router Class Initialized
INFO - 2018-05-17 01:47:00 --> Output Class Initialized
INFO - 2018-05-17 01:47:00 --> Security Class Initialized
DEBUG - 2018-05-17 01:47:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 01:47:00 --> Input Class Initialized
INFO - 2018-05-17 01:47:00 --> Language Class Initialized
INFO - 2018-05-17 01:47:00 --> Language Class Initialized
INFO - 2018-05-17 01:47:00 --> Config Class Initialized
INFO - 2018-05-17 01:47:01 --> Loader Class Initialized
DEBUG - 2018-05-17 01:47:01 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-17 01:47:01 --> Helper loaded: url_helper
INFO - 2018-05-17 01:47:01 --> Helper loaded: form_helper
INFO - 2018-05-17 01:47:01 --> Helper loaded: date_helper
INFO - 2018-05-17 01:47:01 --> Helper loaded: util_helper
INFO - 2018-05-17 01:47:01 --> Helper loaded: text_helper
INFO - 2018-05-17 01:47:01 --> Helper loaded: string_helper
INFO - 2018-05-17 01:47:01 --> Database Driver Class Initialized
DEBUG - 2018-05-17 01:47:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-17 01:47:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-17 01:47:01 --> Email Class Initialized
INFO - 2018-05-17 01:47:01 --> Controller Class Initialized
DEBUG - 2018-05-17 01:47:01 --> Home MX_Controller Initialized
DEBUG - 2018-05-17 01:47:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-17 01:47:01 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-17 01:47:01 --> Login MX_Controller Initialized
INFO - 2018-05-17 01:47:01 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-17 01:47:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-17 01:47:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-17 01:47:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-17 01:47:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-17 01:47:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-17 01:47:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-17 01:47:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-17 01:47:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-05-17 01:47:01 --> Final output sent to browser
DEBUG - 2018-05-17 01:47:01 --> Total execution time: 0.4197
INFO - 2018-05-17 01:47:03 --> Config Class Initialized
INFO - 2018-05-17 01:47:03 --> Hooks Class Initialized
DEBUG - 2018-05-17 01:47:03 --> UTF-8 Support Enabled
INFO - 2018-05-17 01:47:03 --> Utf8 Class Initialized
INFO - 2018-05-17 01:47:03 --> URI Class Initialized
INFO - 2018-05-17 01:47:03 --> Router Class Initialized
INFO - 2018-05-17 01:47:03 --> Output Class Initialized
INFO - 2018-05-17 01:47:03 --> Security Class Initialized
DEBUG - 2018-05-17 01:47:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 01:47:03 --> Input Class Initialized
INFO - 2018-05-17 01:47:03 --> Language Class Initialized
ERROR - 2018-05-17 01:47:03 --> 404 Page Not Found: /index
INFO - 2018-05-17 01:47:03 --> Config Class Initialized
INFO - 2018-05-17 01:47:03 --> Hooks Class Initialized
DEBUG - 2018-05-17 01:47:04 --> UTF-8 Support Enabled
INFO - 2018-05-17 01:47:04 --> Utf8 Class Initialized
INFO - 2018-05-17 01:47:04 --> URI Class Initialized
INFO - 2018-05-17 01:47:04 --> Router Class Initialized
INFO - 2018-05-17 01:47:04 --> Output Class Initialized
INFO - 2018-05-17 01:47:04 --> Security Class Initialized
DEBUG - 2018-05-17 01:47:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 01:47:04 --> Input Class Initialized
INFO - 2018-05-17 01:47:04 --> Language Class Initialized
ERROR - 2018-05-17 01:47:04 --> 404 Page Not Found: /index
INFO - 2018-05-17 01:47:04 --> Config Class Initialized
INFO - 2018-05-17 01:47:04 --> Hooks Class Initialized
DEBUG - 2018-05-17 01:47:04 --> UTF-8 Support Enabled
INFO - 2018-05-17 01:47:04 --> Utf8 Class Initialized
INFO - 2018-05-17 01:47:04 --> URI Class Initialized
INFO - 2018-05-17 01:47:04 --> Router Class Initialized
INFO - 2018-05-17 01:47:04 --> Output Class Initialized
INFO - 2018-05-17 01:47:04 --> Security Class Initialized
DEBUG - 2018-05-17 01:47:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 01:47:04 --> Input Class Initialized
INFO - 2018-05-17 01:47:04 --> Language Class Initialized
ERROR - 2018-05-17 01:47:04 --> 404 Page Not Found: /index
INFO - 2018-05-17 01:47:22 --> Config Class Initialized
INFO - 2018-05-17 01:47:22 --> Hooks Class Initialized
DEBUG - 2018-05-17 01:47:22 --> UTF-8 Support Enabled
INFO - 2018-05-17 01:47:22 --> Utf8 Class Initialized
INFO - 2018-05-17 01:47:22 --> URI Class Initialized
INFO - 2018-05-17 01:47:22 --> Router Class Initialized
INFO - 2018-05-17 01:47:22 --> Output Class Initialized
INFO - 2018-05-17 01:47:22 --> Security Class Initialized
DEBUG - 2018-05-17 01:47:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 01:47:22 --> Input Class Initialized
INFO - 2018-05-17 01:47:22 --> Language Class Initialized
INFO - 2018-05-17 01:47:22 --> Language Class Initialized
INFO - 2018-05-17 01:47:22 --> Config Class Initialized
INFO - 2018-05-17 01:47:22 --> Loader Class Initialized
DEBUG - 2018-05-17 01:47:22 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-17 01:47:22 --> Helper loaded: url_helper
INFO - 2018-05-17 01:47:22 --> Helper loaded: form_helper
INFO - 2018-05-17 01:47:22 --> Helper loaded: date_helper
INFO - 2018-05-17 01:47:22 --> Helper loaded: util_helper
INFO - 2018-05-17 01:47:22 --> Helper loaded: text_helper
INFO - 2018-05-17 01:47:22 --> Helper loaded: string_helper
INFO - 2018-05-17 01:47:22 --> Database Driver Class Initialized
DEBUG - 2018-05-17 01:47:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-17 01:47:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-17 01:47:22 --> Email Class Initialized
INFO - 2018-05-17 01:47:22 --> Controller Class Initialized
DEBUG - 2018-05-17 01:47:22 --> Home MX_Controller Initialized
DEBUG - 2018-05-17 01:47:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-17 01:47:22 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-17 01:47:22 --> Login MX_Controller Initialized
INFO - 2018-05-17 01:47:23 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-17 01:47:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-17 01:47:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-17 01:47:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-17 01:47:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-17 01:47:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-17 01:47:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-17 01:47:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-17 01:47:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-05-17 01:47:23 --> Final output sent to browser
DEBUG - 2018-05-17 01:47:23 --> Total execution time: 0.4164
INFO - 2018-05-17 01:47:24 --> Config Class Initialized
INFO - 2018-05-17 01:47:24 --> Config Class Initialized
INFO - 2018-05-17 01:47:24 --> Hooks Class Initialized
INFO - 2018-05-17 01:47:24 --> Hooks Class Initialized
DEBUG - 2018-05-17 01:47:24 --> UTF-8 Support Enabled
DEBUG - 2018-05-17 01:47:24 --> UTF-8 Support Enabled
INFO - 2018-05-17 01:47:24 --> Utf8 Class Initialized
INFO - 2018-05-17 01:47:24 --> Utf8 Class Initialized
INFO - 2018-05-17 01:47:24 --> URI Class Initialized
INFO - 2018-05-17 01:47:24 --> URI Class Initialized
INFO - 2018-05-17 01:47:24 --> Router Class Initialized
INFO - 2018-05-17 01:47:24 --> Router Class Initialized
INFO - 2018-05-17 01:47:24 --> Output Class Initialized
INFO - 2018-05-17 01:47:24 --> Output Class Initialized
INFO - 2018-05-17 01:47:24 --> Security Class Initialized
INFO - 2018-05-17 01:47:24 --> Security Class Initialized
DEBUG - 2018-05-17 01:47:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-17 01:47:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 01:47:24 --> Input Class Initialized
INFO - 2018-05-17 01:47:24 --> Input Class Initialized
INFO - 2018-05-17 01:47:24 --> Language Class Initialized
ERROR - 2018-05-17 01:47:24 --> 404 Page Not Found: /index
INFO - 2018-05-17 01:47:24 --> Language Class Initialized
ERROR - 2018-05-17 01:47:24 --> 404 Page Not Found: /index
INFO - 2018-05-17 01:47:24 --> Config Class Initialized
INFO - 2018-05-17 01:47:24 --> Hooks Class Initialized
DEBUG - 2018-05-17 01:47:24 --> UTF-8 Support Enabled
INFO - 2018-05-17 01:47:24 --> Utf8 Class Initialized
INFO - 2018-05-17 01:47:24 --> URI Class Initialized
INFO - 2018-05-17 01:47:24 --> Router Class Initialized
INFO - 2018-05-17 01:47:24 --> Output Class Initialized
INFO - 2018-05-17 01:47:24 --> Security Class Initialized
DEBUG - 2018-05-17 01:47:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 01:47:24 --> Input Class Initialized
INFO - 2018-05-17 01:47:24 --> Language Class Initialized
ERROR - 2018-05-17 01:47:24 --> 404 Page Not Found: /index
INFO - 2018-05-17 01:47:24 --> Config Class Initialized
INFO - 2018-05-17 01:47:24 --> Hooks Class Initialized
DEBUG - 2018-05-17 01:47:24 --> UTF-8 Support Enabled
INFO - 2018-05-17 01:47:24 --> Utf8 Class Initialized
INFO - 2018-05-17 01:47:24 --> URI Class Initialized
INFO - 2018-05-17 01:47:24 --> Router Class Initialized
INFO - 2018-05-17 01:47:24 --> Output Class Initialized
INFO - 2018-05-17 01:47:24 --> Security Class Initialized
DEBUG - 2018-05-17 01:47:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 01:47:24 --> Input Class Initialized
INFO - 2018-05-17 01:47:24 --> Language Class Initialized
ERROR - 2018-05-17 01:47:24 --> 404 Page Not Found: /index
INFO - 2018-05-17 01:47:29 --> Config Class Initialized
INFO - 2018-05-17 01:47:29 --> Hooks Class Initialized
DEBUG - 2018-05-17 01:47:29 --> UTF-8 Support Enabled
INFO - 2018-05-17 01:47:29 --> Utf8 Class Initialized
INFO - 2018-05-17 01:47:29 --> URI Class Initialized
INFO - 2018-05-17 01:47:29 --> Router Class Initialized
INFO - 2018-05-17 01:47:29 --> Output Class Initialized
INFO - 2018-05-17 01:47:29 --> Security Class Initialized
DEBUG - 2018-05-17 01:47:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 01:47:29 --> Input Class Initialized
INFO - 2018-05-17 01:47:29 --> Language Class Initialized
INFO - 2018-05-17 01:47:29 --> Language Class Initialized
INFO - 2018-05-17 01:47:29 --> Config Class Initialized
INFO - 2018-05-17 01:47:29 --> Loader Class Initialized
DEBUG - 2018-05-17 01:47:29 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-17 01:47:29 --> Helper loaded: url_helper
INFO - 2018-05-17 01:47:29 --> Helper loaded: form_helper
INFO - 2018-05-17 01:47:29 --> Helper loaded: date_helper
INFO - 2018-05-17 01:47:29 --> Helper loaded: util_helper
INFO - 2018-05-17 01:47:29 --> Helper loaded: text_helper
INFO - 2018-05-17 01:47:29 --> Helper loaded: string_helper
INFO - 2018-05-17 01:47:29 --> Database Driver Class Initialized
DEBUG - 2018-05-17 01:47:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-17 01:47:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-17 01:47:29 --> Email Class Initialized
INFO - 2018-05-17 01:47:29 --> Controller Class Initialized
DEBUG - 2018-05-17 01:47:29 --> Home MX_Controller Initialized
DEBUG - 2018-05-17 01:47:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-17 01:47:29 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-17 01:47:29 --> Login MX_Controller Initialized
INFO - 2018-05-17 01:47:29 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-17 01:47:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-17 01:47:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-17 01:47:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-17 01:47:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-17 01:47:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-17 01:47:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-17 01:47:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-17 01:47:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-05-17 01:47:30 --> Final output sent to browser
DEBUG - 2018-05-17 01:47:30 --> Total execution time: 0.5676
INFO - 2018-05-17 01:47:30 --> Config Class Initialized
INFO - 2018-05-17 01:47:30 --> Config Class Initialized
INFO - 2018-05-17 01:47:30 --> Hooks Class Initialized
INFO - 2018-05-17 01:47:30 --> Hooks Class Initialized
DEBUG - 2018-05-17 01:47:30 --> UTF-8 Support Enabled
INFO - 2018-05-17 01:47:30 --> Utf8 Class Initialized
INFO - 2018-05-17 01:47:30 --> URI Class Initialized
INFO - 2018-05-17 01:47:30 --> Router Class Initialized
INFO - 2018-05-17 01:47:30 --> Output Class Initialized
INFO - 2018-05-17 01:47:30 --> Security Class Initialized
DEBUG - 2018-05-17 01:47:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 01:47:30 --> Input Class Initialized
INFO - 2018-05-17 01:47:30 --> Language Class Initialized
ERROR - 2018-05-17 01:47:31 --> 404 Page Not Found: /index
DEBUG - 2018-05-17 01:47:31 --> UTF-8 Support Enabled
INFO - 2018-05-17 01:47:31 --> Utf8 Class Initialized
INFO - 2018-05-17 01:47:31 --> Config Class Initialized
INFO - 2018-05-17 01:47:31 --> Hooks Class Initialized
INFO - 2018-05-17 01:47:31 --> URI Class Initialized
DEBUG - 2018-05-17 01:47:31 --> UTF-8 Support Enabled
INFO - 2018-05-17 01:47:31 --> Utf8 Class Initialized
INFO - 2018-05-17 01:47:31 --> URI Class Initialized
INFO - 2018-05-17 01:47:31 --> Router Class Initialized
INFO - 2018-05-17 01:47:31 --> Output Class Initialized
INFO - 2018-05-17 01:47:31 --> Router Class Initialized
INFO - 2018-05-17 01:47:31 --> Output Class Initialized
INFO - 2018-05-17 01:47:31 --> Security Class Initialized
DEBUG - 2018-05-17 01:47:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 01:47:31 --> Security Class Initialized
INFO - 2018-05-17 01:47:31 --> Input Class Initialized
DEBUG - 2018-05-17 01:47:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 01:47:31 --> Input Class Initialized
INFO - 2018-05-17 01:47:31 --> Language Class Initialized
INFO - 2018-05-17 01:47:31 --> Language Class Initialized
ERROR - 2018-05-17 01:47:31 --> 404 Page Not Found: /index
ERROR - 2018-05-17 01:47:31 --> 404 Page Not Found: /index
INFO - 2018-05-17 01:47:31 --> Config Class Initialized
INFO - 2018-05-17 01:47:31 --> Hooks Class Initialized
DEBUG - 2018-05-17 01:47:31 --> UTF-8 Support Enabled
INFO - 2018-05-17 01:47:31 --> Utf8 Class Initialized
INFO - 2018-05-17 01:47:31 --> URI Class Initialized
INFO - 2018-05-17 01:47:31 --> Router Class Initialized
INFO - 2018-05-17 01:47:31 --> Output Class Initialized
INFO - 2018-05-17 01:47:31 --> Security Class Initialized
DEBUG - 2018-05-17 01:47:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 01:47:31 --> Input Class Initialized
INFO - 2018-05-17 01:47:31 --> Language Class Initialized
ERROR - 2018-05-17 01:47:31 --> 404 Page Not Found: /index
INFO - 2018-05-17 01:48:02 --> Config Class Initialized
INFO - 2018-05-17 01:48:02 --> Hooks Class Initialized
DEBUG - 2018-05-17 01:48:02 --> UTF-8 Support Enabled
INFO - 2018-05-17 01:48:02 --> Utf8 Class Initialized
INFO - 2018-05-17 01:48:02 --> URI Class Initialized
INFO - 2018-05-17 01:48:02 --> Router Class Initialized
INFO - 2018-05-17 01:48:02 --> Output Class Initialized
INFO - 2018-05-17 01:48:02 --> Security Class Initialized
DEBUG - 2018-05-17 01:48:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 01:48:02 --> Input Class Initialized
INFO - 2018-05-17 01:48:02 --> Language Class Initialized
ERROR - 2018-05-17 01:48:02 --> 404 Page Not Found: /index
INFO - 2018-05-17 01:48:02 --> Config Class Initialized
INFO - 2018-05-17 01:48:02 --> Hooks Class Initialized
DEBUG - 2018-05-17 01:48:02 --> UTF-8 Support Enabled
INFO - 2018-05-17 01:48:02 --> Utf8 Class Initialized
INFO - 2018-05-17 01:48:02 --> URI Class Initialized
INFO - 2018-05-17 01:48:02 --> Router Class Initialized
INFO - 2018-05-17 01:48:02 --> Output Class Initialized
INFO - 2018-05-17 01:48:02 --> Security Class Initialized
DEBUG - 2018-05-17 01:48:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 01:48:02 --> Input Class Initialized
INFO - 2018-05-17 01:48:02 --> Language Class Initialized
ERROR - 2018-05-17 01:48:02 --> 404 Page Not Found: /index
INFO - 2018-05-17 01:48:02 --> Config Class Initialized
INFO - 2018-05-17 01:48:02 --> Hooks Class Initialized
DEBUG - 2018-05-17 01:48:02 --> UTF-8 Support Enabled
INFO - 2018-05-17 01:48:02 --> Utf8 Class Initialized
INFO - 2018-05-17 01:48:02 --> URI Class Initialized
INFO - 2018-05-17 01:48:02 --> Router Class Initialized
INFO - 2018-05-17 01:48:02 --> Output Class Initialized
INFO - 2018-05-17 01:48:02 --> Security Class Initialized
DEBUG - 2018-05-17 01:48:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 01:48:02 --> Input Class Initialized
INFO - 2018-05-17 01:48:02 --> Language Class Initialized
ERROR - 2018-05-17 01:48:02 --> 404 Page Not Found: /index
INFO - 2018-05-17 01:48:11 --> Config Class Initialized
INFO - 2018-05-17 01:48:11 --> Hooks Class Initialized
DEBUG - 2018-05-17 01:48:11 --> UTF-8 Support Enabled
INFO - 2018-05-17 01:48:11 --> Utf8 Class Initialized
INFO - 2018-05-17 01:48:11 --> URI Class Initialized
INFO - 2018-05-17 01:48:11 --> Router Class Initialized
INFO - 2018-05-17 01:48:11 --> Output Class Initialized
INFO - 2018-05-17 01:48:11 --> Security Class Initialized
DEBUG - 2018-05-17 01:48:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 01:48:11 --> Input Class Initialized
INFO - 2018-05-17 01:48:11 --> Language Class Initialized
INFO - 2018-05-17 01:48:11 --> Language Class Initialized
INFO - 2018-05-17 01:48:11 --> Config Class Initialized
INFO - 2018-05-17 01:48:11 --> Loader Class Initialized
DEBUG - 2018-05-17 01:48:11 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-17 01:48:11 --> Helper loaded: url_helper
INFO - 2018-05-17 01:48:11 --> Helper loaded: form_helper
INFO - 2018-05-17 01:48:11 --> Helper loaded: date_helper
INFO - 2018-05-17 01:48:11 --> Helper loaded: util_helper
INFO - 2018-05-17 01:48:11 --> Helper loaded: text_helper
INFO - 2018-05-17 01:48:11 --> Helper loaded: string_helper
INFO - 2018-05-17 01:48:11 --> Database Driver Class Initialized
DEBUG - 2018-05-17 01:48:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-17 01:48:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-17 01:48:11 --> Email Class Initialized
INFO - 2018-05-17 01:48:11 --> Controller Class Initialized
DEBUG - 2018-05-17 01:48:11 --> Home MX_Controller Initialized
DEBUG - 2018-05-17 01:48:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-17 01:48:11 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-17 01:48:11 --> Login MX_Controller Initialized
INFO - 2018-05-17 01:48:11 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-17 01:48:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-17 01:48:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-17 01:48:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-17 01:48:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-17 01:48:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-17 01:48:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-17 01:48:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-17 01:48:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-05-17 01:48:11 --> Final output sent to browser
DEBUG - 2018-05-17 01:48:11 --> Total execution time: 0.4330
INFO - 2018-05-17 01:48:12 --> Config Class Initialized
INFO - 2018-05-17 01:48:12 --> Hooks Class Initialized
DEBUG - 2018-05-17 01:48:12 --> UTF-8 Support Enabled
INFO - 2018-05-17 01:48:12 --> Config Class Initialized
INFO - 2018-05-17 01:48:12 --> Utf8 Class Initialized
INFO - 2018-05-17 01:48:12 --> URI Class Initialized
INFO - 2018-05-17 01:48:12 --> Router Class Initialized
INFO - 2018-05-17 01:48:12 --> Output Class Initialized
INFO - 2018-05-17 01:48:12 --> Security Class Initialized
DEBUG - 2018-05-17 01:48:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 01:48:12 --> Input Class Initialized
INFO - 2018-05-17 01:48:12 --> Hooks Class Initialized
DEBUG - 2018-05-17 01:48:12 --> UTF-8 Support Enabled
INFO - 2018-05-17 01:48:12 --> Language Class Initialized
INFO - 2018-05-17 01:48:12 --> Utf8 Class Initialized
INFO - 2018-05-17 01:48:12 --> URI Class Initialized
INFO - 2018-05-17 01:48:12 --> Router Class Initialized
INFO - 2018-05-17 01:48:12 --> Output Class Initialized
INFO - 2018-05-17 01:48:13 --> Security Class Initialized
ERROR - 2018-05-17 01:48:13 --> 404 Page Not Found: /index
DEBUG - 2018-05-17 01:48:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 01:48:13 --> Input Class Initialized
INFO - 2018-05-17 01:48:13 --> Language Class Initialized
ERROR - 2018-05-17 01:48:13 --> 404 Page Not Found: /index
INFO - 2018-05-17 01:48:13 --> Config Class Initialized
INFO - 2018-05-17 01:48:13 --> Hooks Class Initialized
DEBUG - 2018-05-17 01:48:13 --> UTF-8 Support Enabled
INFO - 2018-05-17 01:48:13 --> Utf8 Class Initialized
INFO - 2018-05-17 01:48:13 --> URI Class Initialized
INFO - 2018-05-17 01:48:13 --> Router Class Initialized
INFO - 2018-05-17 01:48:13 --> Output Class Initialized
INFO - 2018-05-17 01:48:13 --> Security Class Initialized
DEBUG - 2018-05-17 01:48:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 01:48:13 --> Input Class Initialized
INFO - 2018-05-17 01:48:13 --> Language Class Initialized
ERROR - 2018-05-17 01:48:13 --> 404 Page Not Found: /index
INFO - 2018-05-17 01:48:13 --> Config Class Initialized
INFO - 2018-05-17 01:48:13 --> Hooks Class Initialized
DEBUG - 2018-05-17 01:48:13 --> UTF-8 Support Enabled
INFO - 2018-05-17 01:48:13 --> Utf8 Class Initialized
INFO - 2018-05-17 01:48:13 --> URI Class Initialized
INFO - 2018-05-17 01:48:13 --> Router Class Initialized
INFO - 2018-05-17 01:48:13 --> Output Class Initialized
INFO - 2018-05-17 01:48:13 --> Security Class Initialized
DEBUG - 2018-05-17 01:48:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 01:48:13 --> Input Class Initialized
INFO - 2018-05-17 01:48:13 --> Language Class Initialized
ERROR - 2018-05-17 01:48:13 --> 404 Page Not Found: /index
INFO - 2018-05-17 01:48:25 --> Config Class Initialized
INFO - 2018-05-17 01:48:25 --> Hooks Class Initialized
DEBUG - 2018-05-17 01:48:25 --> UTF-8 Support Enabled
INFO - 2018-05-17 01:48:25 --> Utf8 Class Initialized
INFO - 2018-05-17 01:48:25 --> URI Class Initialized
INFO - 2018-05-17 01:48:25 --> Router Class Initialized
INFO - 2018-05-17 01:48:25 --> Output Class Initialized
INFO - 2018-05-17 01:48:25 --> Security Class Initialized
DEBUG - 2018-05-17 01:48:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 01:48:25 --> Input Class Initialized
INFO - 2018-05-17 01:48:25 --> Language Class Initialized
INFO - 2018-05-17 01:48:25 --> Language Class Initialized
INFO - 2018-05-17 01:48:25 --> Config Class Initialized
INFO - 2018-05-17 01:48:25 --> Loader Class Initialized
DEBUG - 2018-05-17 01:48:25 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-17 01:48:25 --> Helper loaded: url_helper
INFO - 2018-05-17 01:48:25 --> Helper loaded: form_helper
INFO - 2018-05-17 01:48:25 --> Helper loaded: date_helper
INFO - 2018-05-17 01:48:25 --> Helper loaded: util_helper
INFO - 2018-05-17 01:48:25 --> Helper loaded: text_helper
INFO - 2018-05-17 01:48:25 --> Helper loaded: string_helper
INFO - 2018-05-17 01:48:25 --> Database Driver Class Initialized
DEBUG - 2018-05-17 01:48:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-17 01:48:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-17 01:48:25 --> Email Class Initialized
INFO - 2018-05-17 01:48:25 --> Controller Class Initialized
DEBUG - 2018-05-17 01:48:25 --> Home MX_Controller Initialized
DEBUG - 2018-05-17 01:48:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-17 01:48:25 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-17 01:48:25 --> Login MX_Controller Initialized
INFO - 2018-05-17 01:48:25 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-17 01:48:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-17 01:48:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-17 01:48:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-17 01:48:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-17 01:48:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-17 01:48:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-17 01:48:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-17 01:48:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-05-17 01:48:25 --> Final output sent to browser
DEBUG - 2018-05-17 01:48:25 --> Total execution time: 0.4394
INFO - 2018-05-17 01:48:26 --> Config Class Initialized
INFO - 2018-05-17 01:48:26 --> Config Class Initialized
INFO - 2018-05-17 01:48:26 --> Hooks Class Initialized
INFO - 2018-05-17 01:48:26 --> Hooks Class Initialized
DEBUG - 2018-05-17 01:48:26 --> UTF-8 Support Enabled
DEBUG - 2018-05-17 01:48:26 --> UTF-8 Support Enabled
INFO - 2018-05-17 01:48:26 --> Utf8 Class Initialized
INFO - 2018-05-17 01:48:26 --> URI Class Initialized
INFO - 2018-05-17 01:48:26 --> Utf8 Class Initialized
INFO - 2018-05-17 01:48:26 --> Router Class Initialized
INFO - 2018-05-17 01:48:26 --> URI Class Initialized
INFO - 2018-05-17 01:48:26 --> Output Class Initialized
INFO - 2018-05-17 01:48:26 --> Router Class Initialized
INFO - 2018-05-17 01:48:26 --> Security Class Initialized
DEBUG - 2018-05-17 01:48:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 01:48:26 --> Output Class Initialized
INFO - 2018-05-17 01:48:26 --> Input Class Initialized
INFO - 2018-05-17 01:48:26 --> Security Class Initialized
INFO - 2018-05-17 01:48:26 --> Language Class Initialized
DEBUG - 2018-05-17 01:48:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 01:48:26 --> Input Class Initialized
INFO - 2018-05-17 01:48:26 --> Language Class Initialized
ERROR - 2018-05-17 01:48:26 --> 404 Page Not Found: /index
ERROR - 2018-05-17 01:48:26 --> 404 Page Not Found: /index
INFO - 2018-05-17 01:48:26 --> Config Class Initialized
INFO - 2018-05-17 01:48:26 --> Hooks Class Initialized
DEBUG - 2018-05-17 01:48:26 --> UTF-8 Support Enabled
INFO - 2018-05-17 01:48:26 --> Utf8 Class Initialized
INFO - 2018-05-17 01:48:26 --> URI Class Initialized
INFO - 2018-05-17 01:48:26 --> Router Class Initialized
INFO - 2018-05-17 01:48:27 --> Output Class Initialized
INFO - 2018-05-17 01:48:27 --> Security Class Initialized
DEBUG - 2018-05-17 01:48:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 01:48:27 --> Input Class Initialized
INFO - 2018-05-17 01:48:27 --> Language Class Initialized
ERROR - 2018-05-17 01:48:27 --> 404 Page Not Found: /index
INFO - 2018-05-17 01:48:27 --> Config Class Initialized
INFO - 2018-05-17 01:48:27 --> Hooks Class Initialized
DEBUG - 2018-05-17 01:48:27 --> UTF-8 Support Enabled
INFO - 2018-05-17 01:48:27 --> Utf8 Class Initialized
INFO - 2018-05-17 01:48:27 --> URI Class Initialized
INFO - 2018-05-17 01:48:27 --> Router Class Initialized
INFO - 2018-05-17 01:48:27 --> Output Class Initialized
INFO - 2018-05-17 01:48:27 --> Security Class Initialized
DEBUG - 2018-05-17 01:48:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 01:48:27 --> Input Class Initialized
INFO - 2018-05-17 01:48:27 --> Language Class Initialized
ERROR - 2018-05-17 01:48:27 --> 404 Page Not Found: /index
INFO - 2018-05-17 01:48:30 --> Config Class Initialized
INFO - 2018-05-17 01:48:30 --> Hooks Class Initialized
DEBUG - 2018-05-17 01:48:30 --> UTF-8 Support Enabled
INFO - 2018-05-17 01:48:30 --> Utf8 Class Initialized
INFO - 2018-05-17 01:48:30 --> URI Class Initialized
INFO - 2018-05-17 01:48:30 --> Router Class Initialized
INFO - 2018-05-17 01:48:30 --> Output Class Initialized
INFO - 2018-05-17 01:48:30 --> Security Class Initialized
DEBUG - 2018-05-17 01:48:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 01:48:30 --> Input Class Initialized
INFO - 2018-05-17 01:48:30 --> Language Class Initialized
ERROR - 2018-05-17 01:48:30 --> 404 Page Not Found: /index
INFO - 2018-05-17 01:48:30 --> Config Class Initialized
INFO - 2018-05-17 01:48:30 --> Hooks Class Initialized
DEBUG - 2018-05-17 01:48:30 --> UTF-8 Support Enabled
INFO - 2018-05-17 01:48:30 --> Utf8 Class Initialized
INFO - 2018-05-17 01:48:30 --> URI Class Initialized
INFO - 2018-05-17 01:48:30 --> Router Class Initialized
INFO - 2018-05-17 01:48:30 --> Output Class Initialized
INFO - 2018-05-17 01:48:30 --> Security Class Initialized
DEBUG - 2018-05-17 01:48:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 01:48:30 --> Input Class Initialized
INFO - 2018-05-17 01:48:30 --> Language Class Initialized
ERROR - 2018-05-17 01:48:30 --> 404 Page Not Found: /index
INFO - 2018-05-17 01:48:30 --> Config Class Initialized
INFO - 2018-05-17 01:48:30 --> Hooks Class Initialized
DEBUG - 2018-05-17 01:48:30 --> UTF-8 Support Enabled
INFO - 2018-05-17 01:48:30 --> Utf8 Class Initialized
INFO - 2018-05-17 01:48:30 --> URI Class Initialized
INFO - 2018-05-17 01:48:30 --> Router Class Initialized
INFO - 2018-05-17 01:48:30 --> Output Class Initialized
INFO - 2018-05-17 01:48:30 --> Security Class Initialized
DEBUG - 2018-05-17 01:48:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 01:48:30 --> Input Class Initialized
INFO - 2018-05-17 01:48:30 --> Language Class Initialized
ERROR - 2018-05-17 01:48:30 --> 404 Page Not Found: /index
INFO - 2018-05-17 01:48:32 --> Config Class Initialized
INFO - 2018-05-17 01:48:32 --> Hooks Class Initialized
DEBUG - 2018-05-17 01:48:32 --> UTF-8 Support Enabled
INFO - 2018-05-17 01:48:32 --> Utf8 Class Initialized
INFO - 2018-05-17 01:48:32 --> URI Class Initialized
INFO - 2018-05-17 01:48:32 --> Router Class Initialized
INFO - 2018-05-17 01:48:32 --> Output Class Initialized
INFO - 2018-05-17 01:48:32 --> Security Class Initialized
DEBUG - 2018-05-17 01:48:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 01:48:32 --> Input Class Initialized
INFO - 2018-05-17 01:48:32 --> Language Class Initialized
INFO - 2018-05-17 01:48:32 --> Language Class Initialized
INFO - 2018-05-17 01:48:32 --> Config Class Initialized
INFO - 2018-05-17 01:48:32 --> Loader Class Initialized
DEBUG - 2018-05-17 01:48:32 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-17 01:48:32 --> Helper loaded: url_helper
INFO - 2018-05-17 01:48:32 --> Helper loaded: form_helper
INFO - 2018-05-17 01:48:32 --> Helper loaded: date_helper
INFO - 2018-05-17 01:48:32 --> Helper loaded: util_helper
INFO - 2018-05-17 01:48:32 --> Helper loaded: text_helper
INFO - 2018-05-17 01:48:32 --> Helper loaded: string_helper
INFO - 2018-05-17 01:48:32 --> Database Driver Class Initialized
DEBUG - 2018-05-17 01:48:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-17 01:48:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-17 01:48:32 --> Email Class Initialized
INFO - 2018-05-17 01:48:32 --> Controller Class Initialized
DEBUG - 2018-05-17 01:48:32 --> Home MX_Controller Initialized
DEBUG - 2018-05-17 01:48:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-17 01:48:32 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-17 01:48:32 --> Login MX_Controller Initialized
INFO - 2018-05-17 01:48:32 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-17 01:48:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-17 01:48:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-17 01:48:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-17 01:48:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-17 01:48:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-17 01:48:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-17 01:48:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-17 01:48:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-05-17 01:48:32 --> Final output sent to browser
DEBUG - 2018-05-17 01:48:32 --> Total execution time: 0.4491
INFO - 2018-05-17 01:48:33 --> Config Class Initialized
INFO - 2018-05-17 01:48:33 --> Config Class Initialized
INFO - 2018-05-17 01:48:33 --> Hooks Class Initialized
INFO - 2018-05-17 01:48:33 --> Hooks Class Initialized
DEBUG - 2018-05-17 01:48:33 --> UTF-8 Support Enabled
DEBUG - 2018-05-17 01:48:33 --> UTF-8 Support Enabled
INFO - 2018-05-17 01:48:33 --> Utf8 Class Initialized
INFO - 2018-05-17 01:48:33 --> Utf8 Class Initialized
INFO - 2018-05-17 01:48:33 --> URI Class Initialized
INFO - 2018-05-17 01:48:33 --> URI Class Initialized
INFO - 2018-05-17 01:48:33 --> Router Class Initialized
INFO - 2018-05-17 01:48:33 --> Router Class Initialized
INFO - 2018-05-17 01:48:33 --> Output Class Initialized
INFO - 2018-05-17 01:48:33 --> Output Class Initialized
INFO - 2018-05-17 01:48:33 --> Security Class Initialized
INFO - 2018-05-17 01:48:33 --> Security Class Initialized
DEBUG - 2018-05-17 01:48:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-17 01:48:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 01:48:33 --> Input Class Initialized
INFO - 2018-05-17 01:48:33 --> Input Class Initialized
INFO - 2018-05-17 01:48:33 --> Language Class Initialized
INFO - 2018-05-17 01:48:33 --> Language Class Initialized
ERROR - 2018-05-17 01:48:33 --> 404 Page Not Found: /index
ERROR - 2018-05-17 01:48:33 --> 404 Page Not Found: /index
INFO - 2018-05-17 01:48:33 --> Config Class Initialized
INFO - 2018-05-17 01:48:33 --> Hooks Class Initialized
DEBUG - 2018-05-17 01:48:33 --> UTF-8 Support Enabled
INFO - 2018-05-17 01:48:33 --> Utf8 Class Initialized
INFO - 2018-05-17 01:48:33 --> URI Class Initialized
INFO - 2018-05-17 01:48:33 --> Router Class Initialized
INFO - 2018-05-17 01:48:33 --> Output Class Initialized
INFO - 2018-05-17 01:48:33 --> Security Class Initialized
DEBUG - 2018-05-17 01:48:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 01:48:33 --> Input Class Initialized
INFO - 2018-05-17 01:48:33 --> Language Class Initialized
ERROR - 2018-05-17 01:48:33 --> 404 Page Not Found: /index
INFO - 2018-05-17 01:48:34 --> Config Class Initialized
INFO - 2018-05-17 01:48:34 --> Hooks Class Initialized
DEBUG - 2018-05-17 01:48:34 --> UTF-8 Support Enabled
INFO - 2018-05-17 01:48:34 --> Utf8 Class Initialized
INFO - 2018-05-17 01:48:34 --> URI Class Initialized
INFO - 2018-05-17 01:48:34 --> Router Class Initialized
INFO - 2018-05-17 01:48:34 --> Output Class Initialized
INFO - 2018-05-17 01:48:34 --> Security Class Initialized
DEBUG - 2018-05-17 01:48:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 01:48:34 --> Input Class Initialized
INFO - 2018-05-17 01:48:34 --> Language Class Initialized
ERROR - 2018-05-17 01:48:34 --> 404 Page Not Found: /index
INFO - 2018-05-17 01:49:19 --> Config Class Initialized
INFO - 2018-05-17 01:49:19 --> Hooks Class Initialized
DEBUG - 2018-05-17 01:49:19 --> UTF-8 Support Enabled
INFO - 2018-05-17 01:49:19 --> Utf8 Class Initialized
INFO - 2018-05-17 01:49:19 --> URI Class Initialized
INFO - 2018-05-17 01:49:19 --> Router Class Initialized
INFO - 2018-05-17 01:49:19 --> Output Class Initialized
INFO - 2018-05-17 01:49:19 --> Security Class Initialized
DEBUG - 2018-05-17 01:49:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 01:49:19 --> Input Class Initialized
INFO - 2018-05-17 01:49:19 --> Language Class Initialized
INFO - 2018-05-17 01:49:19 --> Language Class Initialized
INFO - 2018-05-17 01:49:19 --> Config Class Initialized
INFO - 2018-05-17 01:49:19 --> Loader Class Initialized
DEBUG - 2018-05-17 01:49:19 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-17 01:49:19 --> Helper loaded: url_helper
INFO - 2018-05-17 01:49:19 --> Helper loaded: form_helper
INFO - 2018-05-17 01:49:19 --> Helper loaded: date_helper
INFO - 2018-05-17 01:49:19 --> Helper loaded: util_helper
INFO - 2018-05-17 01:49:19 --> Helper loaded: text_helper
INFO - 2018-05-17 01:49:19 --> Helper loaded: string_helper
INFO - 2018-05-17 01:49:19 --> Database Driver Class Initialized
DEBUG - 2018-05-17 01:49:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-17 01:49:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-17 01:49:19 --> Email Class Initialized
INFO - 2018-05-17 01:49:19 --> Controller Class Initialized
DEBUG - 2018-05-17 01:49:20 --> Home MX_Controller Initialized
DEBUG - 2018-05-17 01:49:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-17 01:49:20 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-17 01:49:20 --> Login MX_Controller Initialized
INFO - 2018-05-17 01:49:20 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-17 01:49:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-17 01:49:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-17 01:49:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-17 01:49:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-17 01:49:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-17 01:49:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-17 01:49:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-17 01:49:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-05-17 01:49:20 --> Final output sent to browser
DEBUG - 2018-05-17 01:49:20 --> Total execution time: 0.4411
INFO - 2018-05-17 01:49:20 --> Config Class Initialized
INFO - 2018-05-17 01:49:20 --> Hooks Class Initialized
INFO - 2018-05-17 01:49:20 --> Config Class Initialized
INFO - 2018-05-17 01:49:20 --> Hooks Class Initialized
DEBUG - 2018-05-17 01:49:20 --> UTF-8 Support Enabled
INFO - 2018-05-17 01:49:20 --> Utf8 Class Initialized
DEBUG - 2018-05-17 01:49:20 --> UTF-8 Support Enabled
INFO - 2018-05-17 01:49:20 --> URI Class Initialized
INFO - 2018-05-17 01:49:20 --> Router Class Initialized
INFO - 2018-05-17 01:49:20 --> Output Class Initialized
INFO - 2018-05-17 01:49:20 --> Security Class Initialized
INFO - 2018-05-17 01:49:20 --> Utf8 Class Initialized
DEBUG - 2018-05-17 01:49:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 01:49:20 --> Input Class Initialized
INFO - 2018-05-17 01:49:20 --> URI Class Initialized
INFO - 2018-05-17 01:49:20 --> Language Class Initialized
INFO - 2018-05-17 01:49:20 --> Router Class Initialized
ERROR - 2018-05-17 01:49:20 --> 404 Page Not Found: /index
INFO - 2018-05-17 01:49:21 --> Output Class Initialized
INFO - 2018-05-17 01:49:21 --> Security Class Initialized
DEBUG - 2018-05-17 01:49:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 01:49:21 --> Input Class Initialized
INFO - 2018-05-17 01:49:21 --> Language Class Initialized
ERROR - 2018-05-17 01:49:21 --> 404 Page Not Found: /index
INFO - 2018-05-17 01:49:21 --> Config Class Initialized
INFO - 2018-05-17 01:49:21 --> Hooks Class Initialized
DEBUG - 2018-05-17 01:49:21 --> UTF-8 Support Enabled
INFO - 2018-05-17 01:49:21 --> Utf8 Class Initialized
INFO - 2018-05-17 01:49:21 --> URI Class Initialized
INFO - 2018-05-17 01:49:21 --> Router Class Initialized
INFO - 2018-05-17 01:49:21 --> Output Class Initialized
INFO - 2018-05-17 01:49:21 --> Security Class Initialized
DEBUG - 2018-05-17 01:49:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 01:49:21 --> Input Class Initialized
INFO - 2018-05-17 01:49:21 --> Language Class Initialized
ERROR - 2018-05-17 01:49:21 --> 404 Page Not Found: /index
INFO - 2018-05-17 01:49:21 --> Config Class Initialized
INFO - 2018-05-17 01:49:21 --> Hooks Class Initialized
DEBUG - 2018-05-17 01:49:21 --> UTF-8 Support Enabled
INFO - 2018-05-17 01:49:21 --> Utf8 Class Initialized
INFO - 2018-05-17 01:49:21 --> URI Class Initialized
INFO - 2018-05-17 01:49:21 --> Router Class Initialized
INFO - 2018-05-17 01:49:21 --> Output Class Initialized
INFO - 2018-05-17 01:49:21 --> Security Class Initialized
DEBUG - 2018-05-17 01:49:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 01:49:21 --> Input Class Initialized
INFO - 2018-05-17 01:49:21 --> Language Class Initialized
ERROR - 2018-05-17 01:49:21 --> 404 Page Not Found: /index
INFO - 2018-05-17 01:49:34 --> Config Class Initialized
INFO - 2018-05-17 01:49:34 --> Hooks Class Initialized
DEBUG - 2018-05-17 01:49:34 --> UTF-8 Support Enabled
INFO - 2018-05-17 01:49:34 --> Utf8 Class Initialized
INFO - 2018-05-17 01:49:34 --> URI Class Initialized
INFO - 2018-05-17 01:49:34 --> Router Class Initialized
INFO - 2018-05-17 01:49:34 --> Output Class Initialized
INFO - 2018-05-17 01:49:34 --> Security Class Initialized
DEBUG - 2018-05-17 01:49:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 01:49:34 --> Input Class Initialized
INFO - 2018-05-17 01:49:34 --> Language Class Initialized
INFO - 2018-05-17 01:49:34 --> Language Class Initialized
INFO - 2018-05-17 01:49:34 --> Config Class Initialized
INFO - 2018-05-17 01:49:34 --> Loader Class Initialized
DEBUG - 2018-05-17 01:49:34 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-17 01:49:34 --> Helper loaded: url_helper
INFO - 2018-05-17 01:49:34 --> Helper loaded: form_helper
INFO - 2018-05-17 01:49:34 --> Helper loaded: date_helper
INFO - 2018-05-17 01:49:34 --> Helper loaded: util_helper
INFO - 2018-05-17 01:49:34 --> Helper loaded: text_helper
INFO - 2018-05-17 01:49:34 --> Helper loaded: string_helper
INFO - 2018-05-17 01:49:34 --> Database Driver Class Initialized
DEBUG - 2018-05-17 01:49:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-17 01:49:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-17 01:49:34 --> Email Class Initialized
INFO - 2018-05-17 01:49:34 --> Controller Class Initialized
DEBUG - 2018-05-17 01:49:34 --> Home MX_Controller Initialized
DEBUG - 2018-05-17 01:49:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-17 01:49:34 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-17 01:49:34 --> Login MX_Controller Initialized
INFO - 2018-05-17 01:49:34 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-17 01:49:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-17 01:49:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-17 01:49:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-17 01:49:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-17 01:49:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-17 01:49:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-17 01:49:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-17 01:49:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-05-17 01:49:34 --> Final output sent to browser
DEBUG - 2018-05-17 01:49:34 --> Total execution time: 0.4489
INFO - 2018-05-17 01:49:35 --> Config Class Initialized
INFO - 2018-05-17 01:49:35 --> Config Class Initialized
INFO - 2018-05-17 01:49:35 --> Hooks Class Initialized
INFO - 2018-05-17 01:49:35 --> Hooks Class Initialized
DEBUG - 2018-05-17 01:49:35 --> UTF-8 Support Enabled
DEBUG - 2018-05-17 01:49:35 --> UTF-8 Support Enabled
INFO - 2018-05-17 01:49:35 --> Utf8 Class Initialized
INFO - 2018-05-17 01:49:35 --> Utf8 Class Initialized
INFO - 2018-05-17 01:49:35 --> URI Class Initialized
INFO - 2018-05-17 01:49:35 --> URI Class Initialized
INFO - 2018-05-17 01:49:35 --> Router Class Initialized
INFO - 2018-05-17 01:49:35 --> Router Class Initialized
INFO - 2018-05-17 01:49:35 --> Output Class Initialized
INFO - 2018-05-17 01:49:35 --> Security Class Initialized
INFO - 2018-05-17 01:49:35 --> Output Class Initialized
DEBUG - 2018-05-17 01:49:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 01:49:35 --> Security Class Initialized
DEBUG - 2018-05-17 01:49:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 01:49:35 --> Input Class Initialized
INFO - 2018-05-17 01:49:35 --> Input Class Initialized
INFO - 2018-05-17 01:49:35 --> Language Class Initialized
INFO - 2018-05-17 01:49:35 --> Language Class Initialized
ERROR - 2018-05-17 01:49:35 --> 404 Page Not Found: /index
ERROR - 2018-05-17 01:49:35 --> 404 Page Not Found: /index
INFO - 2018-05-17 01:49:35 --> Config Class Initialized
INFO - 2018-05-17 01:49:35 --> Hooks Class Initialized
DEBUG - 2018-05-17 01:49:35 --> UTF-8 Support Enabled
INFO - 2018-05-17 01:49:35 --> Utf8 Class Initialized
INFO - 2018-05-17 01:49:35 --> URI Class Initialized
INFO - 2018-05-17 01:49:35 --> Router Class Initialized
INFO - 2018-05-17 01:49:35 --> Output Class Initialized
INFO - 2018-05-17 01:49:35 --> Security Class Initialized
DEBUG - 2018-05-17 01:49:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 01:49:35 --> Input Class Initialized
INFO - 2018-05-17 01:49:35 --> Language Class Initialized
ERROR - 2018-05-17 01:49:35 --> 404 Page Not Found: /index
INFO - 2018-05-17 01:49:35 --> Config Class Initialized
INFO - 2018-05-17 01:49:35 --> Hooks Class Initialized
DEBUG - 2018-05-17 01:49:35 --> UTF-8 Support Enabled
INFO - 2018-05-17 01:49:35 --> Utf8 Class Initialized
INFO - 2018-05-17 01:49:35 --> URI Class Initialized
INFO - 2018-05-17 01:49:36 --> Router Class Initialized
INFO - 2018-05-17 01:49:36 --> Output Class Initialized
INFO - 2018-05-17 01:49:36 --> Security Class Initialized
DEBUG - 2018-05-17 01:49:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 01:49:36 --> Input Class Initialized
INFO - 2018-05-17 01:49:36 --> Language Class Initialized
ERROR - 2018-05-17 01:49:36 --> 404 Page Not Found: /index
INFO - 2018-05-17 01:49:38 --> Config Class Initialized
INFO - 2018-05-17 01:49:38 --> Hooks Class Initialized
DEBUG - 2018-05-17 01:49:38 --> UTF-8 Support Enabled
INFO - 2018-05-17 01:49:38 --> Utf8 Class Initialized
INFO - 2018-05-17 01:49:38 --> URI Class Initialized
INFO - 2018-05-17 01:49:38 --> Router Class Initialized
INFO - 2018-05-17 01:49:38 --> Output Class Initialized
INFO - 2018-05-17 01:49:38 --> Security Class Initialized
DEBUG - 2018-05-17 01:49:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 01:49:38 --> Input Class Initialized
INFO - 2018-05-17 01:49:38 --> Language Class Initialized
INFO - 2018-05-17 01:49:38 --> Language Class Initialized
INFO - 2018-05-17 01:49:38 --> Config Class Initialized
INFO - 2018-05-17 01:49:38 --> Loader Class Initialized
DEBUG - 2018-05-17 01:49:38 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-17 01:49:38 --> Helper loaded: url_helper
INFO - 2018-05-17 01:49:38 --> Helper loaded: form_helper
INFO - 2018-05-17 01:49:38 --> Helper loaded: date_helper
INFO - 2018-05-17 01:49:38 --> Helper loaded: util_helper
INFO - 2018-05-17 01:49:39 --> Helper loaded: text_helper
INFO - 2018-05-17 01:49:39 --> Helper loaded: string_helper
INFO - 2018-05-17 01:49:39 --> Database Driver Class Initialized
DEBUG - 2018-05-17 01:49:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-17 01:49:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-17 01:49:39 --> Email Class Initialized
INFO - 2018-05-17 01:49:39 --> Controller Class Initialized
DEBUG - 2018-05-17 01:49:39 --> Home MX_Controller Initialized
DEBUG - 2018-05-17 01:49:39 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-17 01:49:39 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-17 01:49:39 --> Login MX_Controller Initialized
INFO - 2018-05-17 01:49:39 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-17 01:49:39 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-17 01:49:39 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-17 01:49:39 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-17 01:49:39 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-17 01:49:39 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-17 01:49:39 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-17 01:49:39 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-17 01:49:39 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-05-17 01:49:39 --> Final output sent to browser
DEBUG - 2018-05-17 01:49:39 --> Total execution time: 0.5187
INFO - 2018-05-17 01:49:39 --> Config Class Initialized
INFO - 2018-05-17 01:49:39 --> Config Class Initialized
INFO - 2018-05-17 01:49:39 --> Hooks Class Initialized
INFO - 2018-05-17 01:49:39 --> Hooks Class Initialized
DEBUG - 2018-05-17 01:49:39 --> UTF-8 Support Enabled
DEBUG - 2018-05-17 01:49:39 --> UTF-8 Support Enabled
INFO - 2018-05-17 01:49:39 --> Utf8 Class Initialized
INFO - 2018-05-17 01:49:40 --> URI Class Initialized
INFO - 2018-05-17 01:49:40 --> Utf8 Class Initialized
INFO - 2018-05-17 01:49:40 --> Router Class Initialized
INFO - 2018-05-17 01:49:40 --> Output Class Initialized
INFO - 2018-05-17 01:49:40 --> URI Class Initialized
INFO - 2018-05-17 01:49:40 --> Security Class Initialized
INFO - 2018-05-17 01:49:40 --> Router Class Initialized
INFO - 2018-05-17 01:49:40 --> Output Class Initialized
INFO - 2018-05-17 01:49:40 --> Security Class Initialized
DEBUG - 2018-05-17 01:49:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-17 01:49:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 01:49:40 --> Input Class Initialized
INFO - 2018-05-17 01:49:40 --> Input Class Initialized
INFO - 2018-05-17 01:49:40 --> Language Class Initialized
ERROR - 2018-05-17 01:49:40 --> 404 Page Not Found: /index
INFO - 2018-05-17 01:49:40 --> Language Class Initialized
ERROR - 2018-05-17 01:49:40 --> 404 Page Not Found: /index
INFO - 2018-05-17 01:49:40 --> Config Class Initialized
INFO - 2018-05-17 01:49:40 --> Hooks Class Initialized
DEBUG - 2018-05-17 01:49:40 --> UTF-8 Support Enabled
INFO - 2018-05-17 01:49:40 --> Utf8 Class Initialized
INFO - 2018-05-17 01:49:40 --> URI Class Initialized
INFO - 2018-05-17 01:49:40 --> Router Class Initialized
INFO - 2018-05-17 01:49:40 --> Output Class Initialized
INFO - 2018-05-17 01:49:40 --> Security Class Initialized
DEBUG - 2018-05-17 01:49:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 01:49:40 --> Input Class Initialized
INFO - 2018-05-17 01:49:40 --> Language Class Initialized
ERROR - 2018-05-17 01:49:40 --> 404 Page Not Found: /index
INFO - 2018-05-17 01:49:40 --> Config Class Initialized
INFO - 2018-05-17 01:49:40 --> Hooks Class Initialized
DEBUG - 2018-05-17 01:49:40 --> UTF-8 Support Enabled
INFO - 2018-05-17 01:49:40 --> Utf8 Class Initialized
INFO - 2018-05-17 01:49:40 --> URI Class Initialized
INFO - 2018-05-17 01:49:40 --> Router Class Initialized
INFO - 2018-05-17 01:49:40 --> Output Class Initialized
INFO - 2018-05-17 01:49:40 --> Security Class Initialized
DEBUG - 2018-05-17 01:49:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 01:49:40 --> Input Class Initialized
INFO - 2018-05-17 01:49:40 --> Language Class Initialized
ERROR - 2018-05-17 01:49:40 --> 404 Page Not Found: /index
INFO - 2018-05-17 01:49:44 --> Config Class Initialized
INFO - 2018-05-17 01:49:44 --> Hooks Class Initialized
DEBUG - 2018-05-17 01:49:44 --> UTF-8 Support Enabled
INFO - 2018-05-17 01:49:44 --> Utf8 Class Initialized
INFO - 2018-05-17 01:49:44 --> URI Class Initialized
INFO - 2018-05-17 01:49:44 --> Router Class Initialized
INFO - 2018-05-17 01:49:44 --> Output Class Initialized
INFO - 2018-05-17 01:49:44 --> Security Class Initialized
DEBUG - 2018-05-17 01:49:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 01:49:44 --> Input Class Initialized
INFO - 2018-05-17 01:49:45 --> Language Class Initialized
INFO - 2018-05-17 01:49:45 --> Language Class Initialized
INFO - 2018-05-17 01:49:45 --> Config Class Initialized
INFO - 2018-05-17 01:49:45 --> Loader Class Initialized
DEBUG - 2018-05-17 01:49:45 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-17 01:49:45 --> Helper loaded: url_helper
INFO - 2018-05-17 01:49:45 --> Helper loaded: form_helper
INFO - 2018-05-17 01:49:45 --> Helper loaded: date_helper
INFO - 2018-05-17 01:49:45 --> Helper loaded: util_helper
INFO - 2018-05-17 01:49:45 --> Helper loaded: text_helper
INFO - 2018-05-17 01:49:45 --> Helper loaded: string_helper
INFO - 2018-05-17 01:49:45 --> Database Driver Class Initialized
DEBUG - 2018-05-17 01:49:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-17 01:49:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-17 01:49:45 --> Email Class Initialized
INFO - 2018-05-17 01:49:45 --> Controller Class Initialized
DEBUG - 2018-05-17 01:49:45 --> Home MX_Controller Initialized
DEBUG - 2018-05-17 01:49:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-17 01:49:45 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-17 01:49:45 --> Login MX_Controller Initialized
INFO - 2018-05-17 01:49:45 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-17 01:49:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-17 01:49:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-17 01:49:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-17 01:49:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-17 01:49:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-17 01:49:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-17 01:49:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-17 01:49:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-05-17 01:49:45 --> Final output sent to browser
DEBUG - 2018-05-17 01:49:45 --> Total execution time: 0.4812
INFO - 2018-05-17 01:49:45 --> Config Class Initialized
INFO - 2018-05-17 01:49:45 --> Config Class Initialized
INFO - 2018-05-17 01:49:45 --> Hooks Class Initialized
INFO - 2018-05-17 01:49:45 --> Hooks Class Initialized
DEBUG - 2018-05-17 01:49:45 --> UTF-8 Support Enabled
DEBUG - 2018-05-17 01:49:45 --> UTF-8 Support Enabled
INFO - 2018-05-17 01:49:45 --> Utf8 Class Initialized
INFO - 2018-05-17 01:49:45 --> Utf8 Class Initialized
INFO - 2018-05-17 01:49:46 --> URI Class Initialized
INFO - 2018-05-17 01:49:46 --> URI Class Initialized
INFO - 2018-05-17 01:49:46 --> Router Class Initialized
INFO - 2018-05-17 01:49:46 --> Output Class Initialized
INFO - 2018-05-17 01:49:46 --> Router Class Initialized
INFO - 2018-05-17 01:49:46 --> Security Class Initialized
INFO - 2018-05-17 01:49:46 --> Output Class Initialized
INFO - 2018-05-17 01:49:46 --> Security Class Initialized
DEBUG - 2018-05-17 01:49:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-17 01:49:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 01:49:46 --> Input Class Initialized
INFO - 2018-05-17 01:49:46 --> Input Class Initialized
INFO - 2018-05-17 01:49:46 --> Language Class Initialized
ERROR - 2018-05-17 01:49:46 --> 404 Page Not Found: /index
INFO - 2018-05-17 01:49:46 --> Language Class Initialized
ERROR - 2018-05-17 01:49:46 --> 404 Page Not Found: /index
INFO - 2018-05-17 01:49:46 --> Config Class Initialized
INFO - 2018-05-17 01:49:46 --> Hooks Class Initialized
DEBUG - 2018-05-17 01:49:46 --> UTF-8 Support Enabled
INFO - 2018-05-17 01:49:46 --> Utf8 Class Initialized
INFO - 2018-05-17 01:49:46 --> URI Class Initialized
INFO - 2018-05-17 01:49:46 --> Router Class Initialized
INFO - 2018-05-17 01:49:46 --> Output Class Initialized
INFO - 2018-05-17 01:49:46 --> Security Class Initialized
DEBUG - 2018-05-17 01:49:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 01:49:46 --> Input Class Initialized
INFO - 2018-05-17 01:49:46 --> Language Class Initialized
ERROR - 2018-05-17 01:49:46 --> 404 Page Not Found: /index
INFO - 2018-05-17 01:49:46 --> Config Class Initialized
INFO - 2018-05-17 01:49:46 --> Hooks Class Initialized
DEBUG - 2018-05-17 01:49:46 --> UTF-8 Support Enabled
INFO - 2018-05-17 01:49:46 --> Utf8 Class Initialized
INFO - 2018-05-17 01:49:46 --> URI Class Initialized
INFO - 2018-05-17 01:49:46 --> Router Class Initialized
INFO - 2018-05-17 01:49:46 --> Output Class Initialized
INFO - 2018-05-17 01:49:46 --> Security Class Initialized
DEBUG - 2018-05-17 01:49:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 01:49:46 --> Input Class Initialized
INFO - 2018-05-17 01:49:46 --> Language Class Initialized
ERROR - 2018-05-17 01:49:46 --> 404 Page Not Found: /index
INFO - 2018-05-17 02:38:41 --> Config Class Initialized
INFO - 2018-05-17 02:38:41 --> Hooks Class Initialized
DEBUG - 2018-05-17 02:38:41 --> UTF-8 Support Enabled
INFO - 2018-05-17 02:38:41 --> Utf8 Class Initialized
INFO - 2018-05-17 02:38:41 --> URI Class Initialized
DEBUG - 2018-05-17 02:38:41 --> No URI present. Default controller set.
INFO - 2018-05-17 02:38:41 --> Router Class Initialized
INFO - 2018-05-17 02:38:41 --> Output Class Initialized
INFO - 2018-05-17 02:38:41 --> Security Class Initialized
DEBUG - 2018-05-17 02:38:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 02:38:41 --> Input Class Initialized
INFO - 2018-05-17 02:38:41 --> Language Class Initialized
INFO - 2018-05-17 02:38:41 --> Language Class Initialized
INFO - 2018-05-17 02:38:41 --> Config Class Initialized
INFO - 2018-05-17 02:38:41 --> Loader Class Initialized
DEBUG - 2018-05-17 02:38:41 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-17 02:38:41 --> Helper loaded: url_helper
INFO - 2018-05-17 02:38:41 --> Helper loaded: form_helper
INFO - 2018-05-17 02:38:41 --> Helper loaded: date_helper
INFO - 2018-05-17 02:38:41 --> Helper loaded: util_helper
INFO - 2018-05-17 02:38:41 --> Helper loaded: text_helper
INFO - 2018-05-17 02:38:41 --> Helper loaded: string_helper
INFO - 2018-05-17 02:38:41 --> Database Driver Class Initialized
DEBUG - 2018-05-17 02:38:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-17 02:38:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-17 02:38:42 --> Email Class Initialized
INFO - 2018-05-17 02:38:42 --> Controller Class Initialized
DEBUG - 2018-05-17 02:38:42 --> Home MX_Controller Initialized
DEBUG - 2018-05-17 02:38:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-17 02:38:42 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-17 02:38:42 --> Login MX_Controller Initialized
INFO - 2018-05-17 02:38:42 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-17 02:38:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-17 02:38:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-17 02:38:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-17 02:38:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-17 02:38:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-17 02:38:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-17 02:38:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-17 02:38:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-05-17 02:38:42 --> Final output sent to browser
DEBUG - 2018-05-17 02:38:42 --> Total execution time: 0.4912
INFO - 2018-05-17 02:38:43 --> Config Class Initialized
INFO - 2018-05-17 02:38:43 --> Hooks Class Initialized
DEBUG - 2018-05-17 02:38:43 --> UTF-8 Support Enabled
INFO - 2018-05-17 02:38:43 --> Utf8 Class Initialized
INFO - 2018-05-17 02:38:43 --> URI Class Initialized
INFO - 2018-05-17 02:38:43 --> Router Class Initialized
INFO - 2018-05-17 02:38:43 --> Output Class Initialized
INFO - 2018-05-17 02:38:43 --> Security Class Initialized
DEBUG - 2018-05-17 02:38:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 02:38:43 --> Input Class Initialized
INFO - 2018-05-17 02:38:43 --> Language Class Initialized
ERROR - 2018-05-17 02:38:44 --> 404 Page Not Found: /index
INFO - 2018-05-17 02:38:44 --> Config Class Initialized
INFO - 2018-05-17 02:38:44 --> Hooks Class Initialized
DEBUG - 2018-05-17 02:38:44 --> UTF-8 Support Enabled
INFO - 2018-05-17 02:38:44 --> Utf8 Class Initialized
INFO - 2018-05-17 02:38:44 --> URI Class Initialized
INFO - 2018-05-17 02:38:44 --> Router Class Initialized
INFO - 2018-05-17 02:38:44 --> Output Class Initialized
INFO - 2018-05-17 02:38:44 --> Security Class Initialized
DEBUG - 2018-05-17 02:38:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 02:38:44 --> Input Class Initialized
INFO - 2018-05-17 02:38:44 --> Language Class Initialized
ERROR - 2018-05-17 02:38:44 --> 404 Page Not Found: /index
INFO - 2018-05-17 02:38:44 --> Config Class Initialized
INFO - 2018-05-17 02:38:44 --> Hooks Class Initialized
DEBUG - 2018-05-17 02:38:44 --> UTF-8 Support Enabled
INFO - 2018-05-17 02:38:44 --> Utf8 Class Initialized
INFO - 2018-05-17 02:38:44 --> URI Class Initialized
INFO - 2018-05-17 02:38:44 --> Router Class Initialized
INFO - 2018-05-17 02:38:44 --> Output Class Initialized
INFO - 2018-05-17 02:38:44 --> Security Class Initialized
DEBUG - 2018-05-17 02:38:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 02:38:44 --> Input Class Initialized
INFO - 2018-05-17 02:38:44 --> Language Class Initialized
ERROR - 2018-05-17 02:38:44 --> 404 Page Not Found: /index
INFO - 2018-05-17 02:38:51 --> Config Class Initialized
INFO - 2018-05-17 02:38:51 --> Hooks Class Initialized
DEBUG - 2018-05-17 02:38:51 --> UTF-8 Support Enabled
INFO - 2018-05-17 02:38:51 --> Utf8 Class Initialized
INFO - 2018-05-17 02:38:51 --> URI Class Initialized
INFO - 2018-05-17 02:38:51 --> Router Class Initialized
INFO - 2018-05-17 02:38:51 --> Output Class Initialized
INFO - 2018-05-17 02:38:51 --> Security Class Initialized
DEBUG - 2018-05-17 02:38:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 02:38:51 --> Input Class Initialized
INFO - 2018-05-17 02:38:51 --> Language Class Initialized
INFO - 2018-05-17 02:38:51 --> Language Class Initialized
INFO - 2018-05-17 02:38:51 --> Config Class Initialized
INFO - 2018-05-17 02:38:51 --> Loader Class Initialized
DEBUG - 2018-05-17 02:38:51 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-17 02:38:51 --> Helper loaded: url_helper
INFO - 2018-05-17 02:38:51 --> Helper loaded: form_helper
INFO - 2018-05-17 02:38:51 --> Helper loaded: date_helper
INFO - 2018-05-17 02:38:51 --> Helper loaded: util_helper
INFO - 2018-05-17 02:38:51 --> Helper loaded: text_helper
INFO - 2018-05-17 02:38:51 --> Helper loaded: string_helper
INFO - 2018-05-17 02:38:51 --> Database Driver Class Initialized
DEBUG - 2018-05-17 02:38:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-17 02:38:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-17 02:38:51 --> Email Class Initialized
INFO - 2018-05-17 02:38:51 --> Controller Class Initialized
DEBUG - 2018-05-17 02:38:51 --> Admin MX_Controller Initialized
INFO - 2018-05-17 02:38:51 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-17 02:38:51 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-17 02:38:51 --> Login MX_Controller Initialized
DEBUG - 2018-05-17 02:38:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-17 02:38:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-17 02:38:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/logins/login.php
INFO - 2018-05-17 02:38:51 --> Config Class Initialized
INFO - 2018-05-17 02:38:51 --> Hooks Class Initialized
DEBUG - 2018-05-17 02:38:51 --> UTF-8 Support Enabled
INFO - 2018-05-17 02:38:51 --> Utf8 Class Initialized
INFO - 2018-05-17 02:38:51 --> URI Class Initialized
INFO - 2018-05-17 02:38:51 --> Router Class Initialized
INFO - 2018-05-17 02:38:51 --> Output Class Initialized
INFO - 2018-05-17 02:38:52 --> Security Class Initialized
DEBUG - 2018-05-17 02:38:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 02:38:52 --> Input Class Initialized
INFO - 2018-05-17 02:38:52 --> Language Class Initialized
ERROR - 2018-05-17 02:38:52 --> 404 Page Not Found: /index
INFO - 2018-05-17 02:38:53 --> Config Class Initialized
INFO - 2018-05-17 02:38:53 --> Hooks Class Initialized
DEBUG - 2018-05-17 02:38:53 --> UTF-8 Support Enabled
INFO - 2018-05-17 02:38:53 --> Utf8 Class Initialized
INFO - 2018-05-17 02:38:53 --> URI Class Initialized
INFO - 2018-05-17 02:38:53 --> Router Class Initialized
INFO - 2018-05-17 02:38:53 --> Output Class Initialized
INFO - 2018-05-17 02:38:53 --> Security Class Initialized
DEBUG - 2018-05-17 02:38:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 02:38:53 --> Input Class Initialized
INFO - 2018-05-17 02:38:53 --> Language Class Initialized
ERROR - 2018-05-17 02:38:53 --> 404 Page Not Found: /index
INFO - 2018-05-17 02:38:54 --> Config Class Initialized
INFO - 2018-05-17 02:38:54 --> Hooks Class Initialized
DEBUG - 2018-05-17 02:38:54 --> UTF-8 Support Enabled
INFO - 2018-05-17 02:38:54 --> Utf8 Class Initialized
INFO - 2018-05-17 02:38:54 --> URI Class Initialized
INFO - 2018-05-17 02:38:54 --> Router Class Initialized
INFO - 2018-05-17 02:38:54 --> Output Class Initialized
INFO - 2018-05-17 02:38:54 --> Security Class Initialized
DEBUG - 2018-05-17 02:38:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 02:38:54 --> Input Class Initialized
INFO - 2018-05-17 02:38:54 --> Language Class Initialized
INFO - 2018-05-17 02:38:54 --> Language Class Initialized
INFO - 2018-05-17 02:38:54 --> Config Class Initialized
INFO - 2018-05-17 02:38:54 --> Loader Class Initialized
DEBUG - 2018-05-17 02:38:54 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-17 02:38:54 --> Helper loaded: url_helper
INFO - 2018-05-17 02:38:54 --> Helper loaded: form_helper
INFO - 2018-05-17 02:38:54 --> Helper loaded: date_helper
INFO - 2018-05-17 02:38:54 --> Helper loaded: util_helper
INFO - 2018-05-17 02:38:54 --> Helper loaded: text_helper
INFO - 2018-05-17 02:38:54 --> Helper loaded: string_helper
INFO - 2018-05-17 02:38:54 --> Database Driver Class Initialized
DEBUG - 2018-05-17 02:38:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-17 02:38:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-17 02:38:54 --> Email Class Initialized
INFO - 2018-05-17 02:38:54 --> Controller Class Initialized
DEBUG - 2018-05-17 02:38:54 --> Admin MX_Controller Initialized
INFO - 2018-05-17 02:38:54 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-17 02:38:54 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-17 02:38:54 --> Login MX_Controller Initialized
DEBUG - 2018-05-17 02:38:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-17 02:38:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-17 02:38:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/logins/login.php
INFO - 2018-05-17 02:38:54 --> Config Class Initialized
INFO - 2018-05-17 02:38:54 --> Hooks Class Initialized
DEBUG - 2018-05-17 02:38:54 --> UTF-8 Support Enabled
INFO - 2018-05-17 02:38:54 --> Utf8 Class Initialized
INFO - 2018-05-17 02:38:54 --> URI Class Initialized
INFO - 2018-05-17 02:38:55 --> Router Class Initialized
INFO - 2018-05-17 02:38:55 --> Output Class Initialized
INFO - 2018-05-17 02:38:55 --> Security Class Initialized
DEBUG - 2018-05-17 02:38:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 02:38:55 --> Input Class Initialized
INFO - 2018-05-17 02:38:55 --> Language Class Initialized
ERROR - 2018-05-17 02:38:55 --> 404 Page Not Found: /index
INFO - 2018-05-17 02:38:55 --> Config Class Initialized
INFO - 2018-05-17 02:38:55 --> Hooks Class Initialized
DEBUG - 2018-05-17 02:38:55 --> UTF-8 Support Enabled
INFO - 2018-05-17 02:38:55 --> Utf8 Class Initialized
INFO - 2018-05-17 02:38:55 --> URI Class Initialized
INFO - 2018-05-17 02:38:55 --> Router Class Initialized
INFO - 2018-05-17 02:38:55 --> Output Class Initialized
INFO - 2018-05-17 02:38:55 --> Security Class Initialized
DEBUG - 2018-05-17 02:38:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 02:38:55 --> Input Class Initialized
INFO - 2018-05-17 02:38:55 --> Language Class Initialized
INFO - 2018-05-17 02:38:55 --> Language Class Initialized
INFO - 2018-05-17 02:38:55 --> Config Class Initialized
INFO - 2018-05-17 02:38:55 --> Loader Class Initialized
DEBUG - 2018-05-17 02:38:55 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-17 02:38:55 --> Helper loaded: url_helper
INFO - 2018-05-17 02:38:55 --> Helper loaded: form_helper
INFO - 2018-05-17 02:38:55 --> Helper loaded: date_helper
INFO - 2018-05-17 02:38:55 --> Helper loaded: util_helper
INFO - 2018-05-17 02:38:55 --> Helper loaded: text_helper
INFO - 2018-05-17 02:38:56 --> Helper loaded: string_helper
INFO - 2018-05-17 02:38:56 --> Database Driver Class Initialized
DEBUG - 2018-05-17 02:38:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-17 02:38:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-17 02:38:56 --> Email Class Initialized
INFO - 2018-05-17 02:38:56 --> Controller Class Initialized
DEBUG - 2018-05-17 02:38:56 --> Admin MX_Controller Initialized
INFO - 2018-05-17 02:38:56 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-17 02:38:56 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-17 02:38:56 --> Login MX_Controller Initialized
DEBUG - 2018-05-17 02:38:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-17 02:38:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-17 02:38:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/logins/login.php
INFO - 2018-05-17 02:38:56 --> Config Class Initialized
INFO - 2018-05-17 02:38:56 --> Hooks Class Initialized
DEBUG - 2018-05-17 02:38:56 --> UTF-8 Support Enabled
INFO - 2018-05-17 02:38:56 --> Utf8 Class Initialized
INFO - 2018-05-17 02:38:56 --> URI Class Initialized
INFO - 2018-05-17 02:38:56 --> Router Class Initialized
INFO - 2018-05-17 02:38:56 --> Output Class Initialized
INFO - 2018-05-17 02:38:56 --> Security Class Initialized
DEBUG - 2018-05-17 02:38:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 02:38:56 --> Input Class Initialized
INFO - 2018-05-17 02:38:56 --> Language Class Initialized
INFO - 2018-05-17 02:38:56 --> Language Class Initialized
INFO - 2018-05-17 02:38:56 --> Config Class Initialized
INFO - 2018-05-17 02:38:56 --> Loader Class Initialized
DEBUG - 2018-05-17 02:38:56 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-17 02:38:56 --> Helper loaded: url_helper
INFO - 2018-05-17 02:38:56 --> Helper loaded: form_helper
INFO - 2018-05-17 02:38:56 --> Helper loaded: date_helper
INFO - 2018-05-17 02:38:56 --> Helper loaded: util_helper
INFO - 2018-05-17 02:38:56 --> Helper loaded: text_helper
INFO - 2018-05-17 02:38:56 --> Helper loaded: string_helper
INFO - 2018-05-17 02:38:56 --> Database Driver Class Initialized
DEBUG - 2018-05-17 02:38:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-17 02:38:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-17 02:38:56 --> Email Class Initialized
INFO - 2018-05-17 02:38:56 --> Controller Class Initialized
DEBUG - 2018-05-17 02:38:56 --> videos MX_Controller Initialized
INFO - 2018-05-17 02:38:56 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-17 02:38:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-05-17 02:38:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-17 02:38:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-05-17 02:38:57 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-17 02:38:57 --> Login MX_Controller Initialized
DEBUG - 2018-05-17 02:38:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-17 02:38:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/logins/login.php
INFO - 2018-05-17 02:39:01 --> Config Class Initialized
INFO - 2018-05-17 02:39:01 --> Hooks Class Initialized
DEBUG - 2018-05-17 02:39:01 --> UTF-8 Support Enabled
INFO - 2018-05-17 02:39:01 --> Utf8 Class Initialized
INFO - 2018-05-17 02:39:01 --> URI Class Initialized
INFO - 2018-05-17 02:39:01 --> Router Class Initialized
INFO - 2018-05-17 02:39:01 --> Output Class Initialized
INFO - 2018-05-17 02:39:01 --> Security Class Initialized
DEBUG - 2018-05-17 02:39:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 02:39:01 --> Input Class Initialized
INFO - 2018-05-17 02:39:01 --> Language Class Initialized
INFO - 2018-05-17 02:39:01 --> Language Class Initialized
INFO - 2018-05-17 02:39:01 --> Config Class Initialized
INFO - 2018-05-17 02:39:01 --> Loader Class Initialized
DEBUG - 2018-05-17 02:39:01 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-17 02:39:01 --> Helper loaded: url_helper
INFO - 2018-05-17 02:39:01 --> Helper loaded: form_helper
INFO - 2018-05-17 02:39:01 --> Helper loaded: date_helper
INFO - 2018-05-17 02:39:01 --> Helper loaded: util_helper
INFO - 2018-05-17 02:39:01 --> Helper loaded: text_helper
INFO - 2018-05-17 02:39:01 --> Helper loaded: string_helper
INFO - 2018-05-17 02:39:01 --> Database Driver Class Initialized
DEBUG - 2018-05-17 02:39:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-17 02:39:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-17 02:39:01 --> Email Class Initialized
INFO - 2018-05-17 02:39:01 --> Controller Class Initialized
DEBUG - 2018-05-17 02:39:01 --> Login MX_Controller Initialized
INFO - 2018-05-17 02:39:01 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-17 02:39:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-17 02:39:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-17 02:39:01 --> Email starts for admin@consulting.com fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-05-17 02:39:01 --> User session created for 1
INFO - 2018-05-17 02:39:01 --> Login status admin@consulting.com - success
INFO - 2018-05-17 02:39:01 --> Final output sent to browser
DEBUG - 2018-05-17 02:39:01 --> Total execution time: 0.3980
INFO - 2018-05-17 02:39:01 --> Config Class Initialized
INFO - 2018-05-17 02:39:01 --> Hooks Class Initialized
DEBUG - 2018-05-17 02:39:01 --> UTF-8 Support Enabled
INFO - 2018-05-17 02:39:01 --> Utf8 Class Initialized
INFO - 2018-05-17 02:39:01 --> URI Class Initialized
INFO - 2018-05-17 02:39:01 --> Router Class Initialized
INFO - 2018-05-17 02:39:01 --> Output Class Initialized
INFO - 2018-05-17 02:39:01 --> Security Class Initialized
DEBUG - 2018-05-17 02:39:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 02:39:01 --> Input Class Initialized
INFO - 2018-05-17 02:39:01 --> Language Class Initialized
INFO - 2018-05-17 02:39:01 --> Language Class Initialized
INFO - 2018-05-17 02:39:01 --> Config Class Initialized
INFO - 2018-05-17 02:39:01 --> Loader Class Initialized
DEBUG - 2018-05-17 02:39:01 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-17 02:39:01 --> Helper loaded: url_helper
INFO - 2018-05-17 02:39:01 --> Helper loaded: form_helper
INFO - 2018-05-17 02:39:01 --> Helper loaded: date_helper
INFO - 2018-05-17 02:39:01 --> Helper loaded: util_helper
INFO - 2018-05-17 02:39:01 --> Helper loaded: text_helper
INFO - 2018-05-17 02:39:01 --> Helper loaded: string_helper
INFO - 2018-05-17 02:39:01 --> Database Driver Class Initialized
DEBUG - 2018-05-17 02:39:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-17 02:39:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-17 02:39:01 --> Email Class Initialized
INFO - 2018-05-17 02:39:01 --> Controller Class Initialized
DEBUG - 2018-05-17 02:39:01 --> Admin MX_Controller Initialized
INFO - 2018-05-17 02:39:01 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-17 02:39:01 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-17 02:39:01 --> Login MX_Controller Initialized
DEBUG - 2018-05-17 02:39:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-17 02:39:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-17 02:39:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-05-17 02:39:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-05-17 02:39:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-05-17 02:39:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-05-17 02:39:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-05-17 02:39:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/dashboard.php
INFO - 2018-05-17 02:39:02 --> Final output sent to browser
INFO - 2018-05-17 02:39:02 --> Config Class Initialized
DEBUG - 2018-05-17 02:39:02 --> Total execution time: 0.5203
INFO - 2018-05-17 02:39:02 --> Hooks Class Initialized
INFO - 2018-05-17 02:39:02 --> Config Class Initialized
INFO - 2018-05-17 02:39:02 --> Hooks Class Initialized
DEBUG - 2018-05-17 02:39:02 --> UTF-8 Support Enabled
INFO - 2018-05-17 02:39:02 --> Utf8 Class Initialized
DEBUG - 2018-05-17 02:39:02 --> UTF-8 Support Enabled
INFO - 2018-05-17 02:39:02 --> Utf8 Class Initialized
INFO - 2018-05-17 02:39:02 --> URI Class Initialized
INFO - 2018-05-17 02:39:02 --> URI Class Initialized
INFO - 2018-05-17 02:39:02 --> Router Class Initialized
INFO - 2018-05-17 02:39:02 --> Output Class Initialized
INFO - 2018-05-17 02:39:02 --> Router Class Initialized
INFO - 2018-05-17 02:39:02 --> Security Class Initialized
INFO - 2018-05-17 02:39:02 --> Output Class Initialized
DEBUG - 2018-05-17 02:39:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 02:39:02 --> Security Class Initialized
INFO - 2018-05-17 02:39:02 --> Input Class Initialized
DEBUG - 2018-05-17 02:39:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 02:39:02 --> Language Class Initialized
INFO - 2018-05-17 02:39:02 --> Input Class Initialized
ERROR - 2018-05-17 02:39:02 --> 404 Page Not Found: /index
INFO - 2018-05-17 02:39:02 --> Language Class Initialized
ERROR - 2018-05-17 02:39:02 --> 404 Page Not Found: /index
INFO - 2018-05-17 02:39:06 --> Config Class Initialized
INFO - 2018-05-17 02:39:06 --> Hooks Class Initialized
DEBUG - 2018-05-17 02:39:06 --> UTF-8 Support Enabled
INFO - 2018-05-17 02:39:06 --> Utf8 Class Initialized
INFO - 2018-05-17 02:39:06 --> URI Class Initialized
DEBUG - 2018-05-17 02:39:06 --> No URI present. Default controller set.
INFO - 2018-05-17 02:39:06 --> Router Class Initialized
INFO - 2018-05-17 02:39:06 --> Output Class Initialized
INFO - 2018-05-17 02:39:06 --> Security Class Initialized
DEBUG - 2018-05-17 02:39:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 02:39:06 --> Input Class Initialized
INFO - 2018-05-17 02:39:07 --> Language Class Initialized
INFO - 2018-05-17 02:39:07 --> Language Class Initialized
INFO - 2018-05-17 02:39:07 --> Config Class Initialized
INFO - 2018-05-17 02:39:07 --> Loader Class Initialized
DEBUG - 2018-05-17 02:39:07 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-17 02:39:07 --> Helper loaded: url_helper
INFO - 2018-05-17 02:39:07 --> Helper loaded: form_helper
INFO - 2018-05-17 02:39:07 --> Helper loaded: date_helper
INFO - 2018-05-17 02:39:07 --> Helper loaded: util_helper
INFO - 2018-05-17 02:39:07 --> Helper loaded: text_helper
INFO - 2018-05-17 02:39:07 --> Helper loaded: string_helper
INFO - 2018-05-17 02:39:07 --> Database Driver Class Initialized
DEBUG - 2018-05-17 02:39:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-17 02:39:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-17 02:39:07 --> Email Class Initialized
INFO - 2018-05-17 02:39:07 --> Controller Class Initialized
DEBUG - 2018-05-17 02:39:07 --> Home MX_Controller Initialized
DEBUG - 2018-05-17 02:39:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-17 02:39:07 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-17 02:39:07 --> Login MX_Controller Initialized
INFO - 2018-05-17 02:39:07 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-17 02:39:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-17 02:39:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-17 02:39:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-17 02:39:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-17 02:39:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-17 02:39:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-17 02:39:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-17 02:39:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-05-17 02:39:07 --> Final output sent to browser
DEBUG - 2018-05-17 02:39:07 --> Total execution time: 0.5157
INFO - 2018-05-17 02:39:08 --> Config Class Initialized
INFO - 2018-05-17 02:39:08 --> Hooks Class Initialized
DEBUG - 2018-05-17 02:39:08 --> UTF-8 Support Enabled
INFO - 2018-05-17 02:39:08 --> Utf8 Class Initialized
INFO - 2018-05-17 02:39:08 --> URI Class Initialized
INFO - 2018-05-17 02:39:08 --> Router Class Initialized
INFO - 2018-05-17 02:39:08 --> Output Class Initialized
INFO - 2018-05-17 02:39:08 --> Security Class Initialized
DEBUG - 2018-05-17 02:39:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 02:39:08 --> Input Class Initialized
INFO - 2018-05-17 02:39:08 --> Language Class Initialized
ERROR - 2018-05-17 02:39:08 --> 404 Page Not Found: /index
INFO - 2018-05-17 02:39:08 --> Config Class Initialized
INFO - 2018-05-17 02:39:08 --> Hooks Class Initialized
DEBUG - 2018-05-17 02:39:08 --> UTF-8 Support Enabled
INFO - 2018-05-17 02:39:08 --> Utf8 Class Initialized
INFO - 2018-05-17 02:39:08 --> URI Class Initialized
INFO - 2018-05-17 02:39:08 --> Router Class Initialized
INFO - 2018-05-17 02:39:08 --> Output Class Initialized
INFO - 2018-05-17 02:39:08 --> Security Class Initialized
DEBUG - 2018-05-17 02:39:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 02:39:08 --> Input Class Initialized
INFO - 2018-05-17 02:39:08 --> Language Class Initialized
ERROR - 2018-05-17 02:39:08 --> 404 Page Not Found: /index
INFO - 2018-05-17 02:39:08 --> Config Class Initialized
INFO - 2018-05-17 02:39:08 --> Hooks Class Initialized
DEBUG - 2018-05-17 02:39:08 --> UTF-8 Support Enabled
INFO - 2018-05-17 02:39:08 --> Utf8 Class Initialized
INFO - 2018-05-17 02:39:08 --> URI Class Initialized
INFO - 2018-05-17 02:39:08 --> Router Class Initialized
INFO - 2018-05-17 02:39:08 --> Output Class Initialized
INFO - 2018-05-17 02:39:08 --> Security Class Initialized
DEBUG - 2018-05-17 02:39:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 02:39:08 --> Input Class Initialized
INFO - 2018-05-17 02:39:08 --> Language Class Initialized
ERROR - 2018-05-17 02:39:08 --> 404 Page Not Found: /index
INFO - 2018-05-17 02:59:01 --> Config Class Initialized
INFO - 2018-05-17 02:59:01 --> Hooks Class Initialized
DEBUG - 2018-05-17 02:59:01 --> UTF-8 Support Enabled
INFO - 2018-05-17 02:59:01 --> Utf8 Class Initialized
INFO - 2018-05-17 02:59:01 --> URI Class Initialized
INFO - 2018-05-17 02:59:01 --> Router Class Initialized
INFO - 2018-05-17 02:59:01 --> Output Class Initialized
INFO - 2018-05-17 02:59:01 --> Security Class Initialized
DEBUG - 2018-05-17 02:59:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 02:59:01 --> Input Class Initialized
INFO - 2018-05-17 02:59:01 --> Language Class Initialized
INFO - 2018-05-17 02:59:01 --> Language Class Initialized
INFO - 2018-05-17 02:59:01 --> Config Class Initialized
INFO - 2018-05-17 02:59:01 --> Loader Class Initialized
DEBUG - 2018-05-17 02:59:01 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-17 02:59:01 --> Helper loaded: url_helper
INFO - 2018-05-17 02:59:01 --> Helper loaded: form_helper
INFO - 2018-05-17 02:59:01 --> Helper loaded: date_helper
INFO - 2018-05-17 02:59:01 --> Helper loaded: util_helper
INFO - 2018-05-17 02:59:01 --> Helper loaded: text_helper
INFO - 2018-05-17 02:59:01 --> Helper loaded: string_helper
INFO - 2018-05-17 02:59:01 --> Database Driver Class Initialized
DEBUG - 2018-05-17 02:59:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-17 02:59:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-17 02:59:01 --> Email Class Initialized
INFO - 2018-05-17 02:59:01 --> Controller Class Initialized
DEBUG - 2018-05-17 02:59:01 --> Home MX_Controller Initialized
DEBUG - 2018-05-17 02:59:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-17 02:59:01 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-17 02:59:01 --> Login MX_Controller Initialized
INFO - 2018-05-17 02:59:01 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-17 02:59:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-17 02:59:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-17 02:59:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-17 02:59:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-17 02:59:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-17 02:59:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-17 02:59:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-17 02:59:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-05-17 02:59:01 --> Final output sent to browser
DEBUG - 2018-05-17 02:59:01 --> Total execution time: 0.4850
INFO - 2018-05-17 02:59:03 --> Config Class Initialized
INFO - 2018-05-17 02:59:03 --> Config Class Initialized
INFO - 2018-05-17 02:59:03 --> Hooks Class Initialized
INFO - 2018-05-17 02:59:03 --> Hooks Class Initialized
DEBUG - 2018-05-17 02:59:03 --> UTF-8 Support Enabled
DEBUG - 2018-05-17 02:59:03 --> UTF-8 Support Enabled
INFO - 2018-05-17 02:59:03 --> Utf8 Class Initialized
INFO - 2018-05-17 02:59:03 --> URI Class Initialized
INFO - 2018-05-17 02:59:03 --> Router Class Initialized
INFO - 2018-05-17 02:59:03 --> Output Class Initialized
INFO - 2018-05-17 02:59:03 --> Security Class Initialized
DEBUG - 2018-05-17 02:59:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 02:59:03 --> Input Class Initialized
INFO - 2018-05-17 02:59:03 --> Language Class Initialized
INFO - 2018-05-17 02:59:03 --> Utf8 Class Initialized
ERROR - 2018-05-17 02:59:03 --> 404 Page Not Found: /index
INFO - 2018-05-17 02:59:03 --> URI Class Initialized
INFO - 2018-05-17 02:59:03 --> Router Class Initialized
INFO - 2018-05-17 02:59:03 --> Output Class Initialized
INFO - 2018-05-17 02:59:03 --> Security Class Initialized
DEBUG - 2018-05-17 02:59:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 02:59:03 --> Input Class Initialized
INFO - 2018-05-17 02:59:03 --> Language Class Initialized
ERROR - 2018-05-17 02:59:03 --> 404 Page Not Found: /index
INFO - 2018-05-17 02:59:03 --> Config Class Initialized
INFO - 2018-05-17 02:59:03 --> Hooks Class Initialized
DEBUG - 2018-05-17 02:59:03 --> UTF-8 Support Enabled
INFO - 2018-05-17 02:59:03 --> Utf8 Class Initialized
INFO - 2018-05-17 02:59:03 --> URI Class Initialized
INFO - 2018-05-17 02:59:03 --> Router Class Initialized
INFO - 2018-05-17 02:59:03 --> Output Class Initialized
INFO - 2018-05-17 02:59:03 --> Security Class Initialized
DEBUG - 2018-05-17 02:59:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 02:59:03 --> Input Class Initialized
INFO - 2018-05-17 02:59:03 --> Language Class Initialized
ERROR - 2018-05-17 02:59:03 --> 404 Page Not Found: /index
INFO - 2018-05-17 02:59:03 --> Config Class Initialized
INFO - 2018-05-17 02:59:03 --> Hooks Class Initialized
DEBUG - 2018-05-17 02:59:03 --> UTF-8 Support Enabled
INFO - 2018-05-17 02:59:03 --> Utf8 Class Initialized
INFO - 2018-05-17 02:59:03 --> URI Class Initialized
INFO - 2018-05-17 02:59:04 --> Router Class Initialized
INFO - 2018-05-17 02:59:04 --> Output Class Initialized
INFO - 2018-05-17 02:59:04 --> Security Class Initialized
DEBUG - 2018-05-17 02:59:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 02:59:04 --> Input Class Initialized
INFO - 2018-05-17 02:59:04 --> Language Class Initialized
ERROR - 2018-05-17 02:59:04 --> 404 Page Not Found: /index
INFO - 2018-05-17 02:59:12 --> Config Class Initialized
INFO - 2018-05-17 02:59:12 --> Hooks Class Initialized
DEBUG - 2018-05-17 02:59:12 --> UTF-8 Support Enabled
INFO - 2018-05-17 02:59:12 --> Utf8 Class Initialized
INFO - 2018-05-17 02:59:12 --> URI Class Initialized
INFO - 2018-05-17 02:59:12 --> Router Class Initialized
INFO - 2018-05-17 02:59:12 --> Output Class Initialized
INFO - 2018-05-17 02:59:12 --> Security Class Initialized
DEBUG - 2018-05-17 02:59:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 02:59:12 --> Input Class Initialized
INFO - 2018-05-17 02:59:12 --> Language Class Initialized
INFO - 2018-05-17 02:59:12 --> Language Class Initialized
INFO - 2018-05-17 02:59:12 --> Config Class Initialized
INFO - 2018-05-17 02:59:12 --> Loader Class Initialized
DEBUG - 2018-05-17 02:59:12 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-17 02:59:12 --> Helper loaded: url_helper
INFO - 2018-05-17 02:59:12 --> Helper loaded: form_helper
INFO - 2018-05-17 02:59:12 --> Helper loaded: date_helper
INFO - 2018-05-17 02:59:12 --> Helper loaded: util_helper
INFO - 2018-05-17 02:59:12 --> Helper loaded: text_helper
INFO - 2018-05-17 02:59:12 --> Helper loaded: string_helper
INFO - 2018-05-17 02:59:12 --> Database Driver Class Initialized
DEBUG - 2018-05-17 02:59:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-17 02:59:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-17 02:59:12 --> Email Class Initialized
INFO - 2018-05-17 02:59:12 --> Controller Class Initialized
DEBUG - 2018-05-17 02:59:12 --> Home MX_Controller Initialized
DEBUG - 2018-05-17 02:59:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-17 02:59:12 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-17 02:59:12 --> Login MX_Controller Initialized
INFO - 2018-05-17 02:59:12 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-17 02:59:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-17 02:59:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-17 02:59:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-17 02:59:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-17 02:59:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-17 02:59:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-17 02:59:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-17 02:59:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-05-17 02:59:12 --> Final output sent to browser
DEBUG - 2018-05-17 02:59:12 --> Total execution time: 0.5359
INFO - 2018-05-17 02:59:13 --> Config Class Initialized
INFO - 2018-05-17 02:59:13 --> Hooks Class Initialized
DEBUG - 2018-05-17 02:59:13 --> UTF-8 Support Enabled
INFO - 2018-05-17 02:59:13 --> Config Class Initialized
INFO - 2018-05-17 02:59:13 --> Hooks Class Initialized
INFO - 2018-05-17 02:59:13 --> Utf8 Class Initialized
DEBUG - 2018-05-17 02:59:13 --> UTF-8 Support Enabled
INFO - 2018-05-17 02:59:13 --> Utf8 Class Initialized
INFO - 2018-05-17 02:59:13 --> URI Class Initialized
INFO - 2018-05-17 02:59:13 --> URI Class Initialized
INFO - 2018-05-17 02:59:13 --> Router Class Initialized
INFO - 2018-05-17 02:59:13 --> Router Class Initialized
INFO - 2018-05-17 02:59:13 --> Output Class Initialized
INFO - 2018-05-17 02:59:13 --> Security Class Initialized
DEBUG - 2018-05-17 02:59:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 02:59:13 --> Input Class Initialized
INFO - 2018-05-17 02:59:13 --> Language Class Initialized
INFO - 2018-05-17 02:59:13 --> Output Class Initialized
ERROR - 2018-05-17 02:59:13 --> 404 Page Not Found: /index
INFO - 2018-05-17 02:59:13 --> Security Class Initialized
DEBUG - 2018-05-17 02:59:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 02:59:13 --> Input Class Initialized
INFO - 2018-05-17 02:59:13 --> Language Class Initialized
ERROR - 2018-05-17 02:59:13 --> 404 Page Not Found: /index
INFO - 2018-05-17 02:59:13 --> Config Class Initialized
INFO - 2018-05-17 02:59:13 --> Hooks Class Initialized
DEBUG - 2018-05-17 02:59:13 --> UTF-8 Support Enabled
INFO - 2018-05-17 02:59:13 --> Utf8 Class Initialized
INFO - 2018-05-17 02:59:13 --> URI Class Initialized
INFO - 2018-05-17 02:59:13 --> Router Class Initialized
INFO - 2018-05-17 02:59:13 --> Output Class Initialized
INFO - 2018-05-17 02:59:13 --> Security Class Initialized
DEBUG - 2018-05-17 02:59:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 02:59:13 --> Input Class Initialized
INFO - 2018-05-17 02:59:13 --> Language Class Initialized
ERROR - 2018-05-17 02:59:13 --> 404 Page Not Found: /index
INFO - 2018-05-17 02:59:14 --> Config Class Initialized
INFO - 2018-05-17 02:59:14 --> Hooks Class Initialized
DEBUG - 2018-05-17 02:59:14 --> UTF-8 Support Enabled
INFO - 2018-05-17 02:59:14 --> Utf8 Class Initialized
INFO - 2018-05-17 02:59:14 --> URI Class Initialized
INFO - 2018-05-17 02:59:14 --> Router Class Initialized
INFO - 2018-05-17 02:59:14 --> Output Class Initialized
INFO - 2018-05-17 02:59:14 --> Security Class Initialized
DEBUG - 2018-05-17 02:59:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 02:59:14 --> Input Class Initialized
INFO - 2018-05-17 02:59:14 --> Language Class Initialized
ERROR - 2018-05-17 02:59:14 --> 404 Page Not Found: /index
INFO - 2018-05-17 02:59:21 --> Config Class Initialized
INFO - 2018-05-17 02:59:21 --> Hooks Class Initialized
DEBUG - 2018-05-17 02:59:21 --> UTF-8 Support Enabled
INFO - 2018-05-17 02:59:21 --> Utf8 Class Initialized
INFO - 2018-05-17 02:59:21 --> URI Class Initialized
INFO - 2018-05-17 02:59:21 --> Router Class Initialized
INFO - 2018-05-17 02:59:21 --> Output Class Initialized
INFO - 2018-05-17 02:59:21 --> Security Class Initialized
DEBUG - 2018-05-17 02:59:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 02:59:22 --> Config Class Initialized
INFO - 2018-05-17 02:59:22 --> Hooks Class Initialized
INFO - 2018-05-17 02:59:22 --> Input Class Initialized
DEBUG - 2018-05-17 02:59:22 --> UTF-8 Support Enabled
INFO - 2018-05-17 02:59:22 --> Utf8 Class Initialized
INFO - 2018-05-17 02:59:22 --> URI Class Initialized
INFO - 2018-05-17 02:59:22 --> Router Class Initialized
INFO - 2018-05-17 02:59:22 --> Output Class Initialized
INFO - 2018-05-17 02:59:22 --> Security Class Initialized
DEBUG - 2018-05-17 02:59:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 02:59:22 --> Language Class Initialized
INFO - 2018-05-17 02:59:22 --> Input Class Initialized
ERROR - 2018-05-17 02:59:22 --> 404 Page Not Found: /index
INFO - 2018-05-17 02:59:22 --> Language Class Initialized
ERROR - 2018-05-17 02:59:22 --> 404 Page Not Found: /index
INFO - 2018-05-17 02:59:22 --> Config Class Initialized
INFO - 2018-05-17 02:59:22 --> Config Class Initialized
INFO - 2018-05-17 02:59:22 --> Hooks Class Initialized
INFO - 2018-05-17 02:59:22 --> Hooks Class Initialized
DEBUG - 2018-05-17 02:59:22 --> UTF-8 Support Enabled
DEBUG - 2018-05-17 02:59:22 --> UTF-8 Support Enabled
INFO - 2018-05-17 02:59:22 --> Utf8 Class Initialized
INFO - 2018-05-17 02:59:22 --> Utf8 Class Initialized
INFO - 2018-05-17 02:59:22 --> URI Class Initialized
INFO - 2018-05-17 02:59:22 --> URI Class Initialized
INFO - 2018-05-17 02:59:22 --> Router Class Initialized
INFO - 2018-05-17 02:59:22 --> Router Class Initialized
INFO - 2018-05-17 02:59:22 --> Output Class Initialized
INFO - 2018-05-17 02:59:22 --> Output Class Initialized
INFO - 2018-05-17 02:59:22 --> Security Class Initialized
INFO - 2018-05-17 02:59:22 --> Security Class Initialized
DEBUG - 2018-05-17 02:59:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-17 02:59:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 02:59:22 --> Input Class Initialized
INFO - 2018-05-17 02:59:22 --> Language Class Initialized
INFO - 2018-05-17 02:59:22 --> Input Class Initialized
INFO - 2018-05-17 02:59:22 --> Language Class Initialized
ERROR - 2018-05-17 02:59:22 --> 404 Page Not Found: /index
ERROR - 2018-05-17 02:59:22 --> 404 Page Not Found: /index
INFO - 2018-05-17 02:59:22 --> Config Class Initialized
INFO - 2018-05-17 02:59:22 --> Hooks Class Initialized
DEBUG - 2018-05-17 02:59:22 --> UTF-8 Support Enabled
INFO - 2018-05-17 02:59:22 --> Utf8 Class Initialized
INFO - 2018-05-17 02:59:22 --> URI Class Initialized
INFO - 2018-05-17 02:59:22 --> Router Class Initialized
INFO - 2018-05-17 02:59:22 --> Output Class Initialized
INFO - 2018-05-17 02:59:23 --> Security Class Initialized
DEBUG - 2018-05-17 02:59:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 02:59:23 --> Input Class Initialized
INFO - 2018-05-17 02:59:23 --> Language Class Initialized
ERROR - 2018-05-17 02:59:23 --> 404 Page Not Found: /index
INFO - 2018-05-17 02:59:23 --> Config Class Initialized
INFO - 2018-05-17 02:59:23 --> Hooks Class Initialized
DEBUG - 2018-05-17 02:59:23 --> UTF-8 Support Enabled
INFO - 2018-05-17 02:59:23 --> Utf8 Class Initialized
INFO - 2018-05-17 02:59:23 --> URI Class Initialized
INFO - 2018-05-17 02:59:23 --> Router Class Initialized
INFO - 2018-05-17 02:59:23 --> Output Class Initialized
INFO - 2018-05-17 02:59:23 --> Security Class Initialized
DEBUG - 2018-05-17 02:59:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 02:59:23 --> Input Class Initialized
INFO - 2018-05-17 02:59:23 --> Language Class Initialized
ERROR - 2018-05-17 02:59:23 --> 404 Page Not Found: /index
INFO - 2018-05-17 02:59:30 --> Config Class Initialized
INFO - 2018-05-17 02:59:30 --> Hooks Class Initialized
DEBUG - 2018-05-17 02:59:30 --> UTF-8 Support Enabled
INFO - 2018-05-17 02:59:30 --> Utf8 Class Initialized
INFO - 2018-05-17 02:59:30 --> URI Class Initialized
INFO - 2018-05-17 02:59:30 --> Router Class Initialized
INFO - 2018-05-17 02:59:30 --> Output Class Initialized
INFO - 2018-05-17 02:59:30 --> Security Class Initialized
DEBUG - 2018-05-17 02:59:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 02:59:30 --> Input Class Initialized
INFO - 2018-05-17 02:59:30 --> Language Class Initialized
ERROR - 2018-05-17 02:59:30 --> 404 Page Not Found: /index
INFO - 2018-05-17 02:59:30 --> Config Class Initialized
INFO - 2018-05-17 02:59:30 --> Hooks Class Initialized
INFO - 2018-05-17 02:59:30 --> Config Class Initialized
INFO - 2018-05-17 02:59:30 --> Hooks Class Initialized
DEBUG - 2018-05-17 02:59:30 --> UTF-8 Support Enabled
DEBUG - 2018-05-17 02:59:30 --> UTF-8 Support Enabled
INFO - 2018-05-17 02:59:30 --> Utf8 Class Initialized
INFO - 2018-05-17 02:59:30 --> Utf8 Class Initialized
INFO - 2018-05-17 02:59:30 --> URI Class Initialized
INFO - 2018-05-17 02:59:31 --> URI Class Initialized
INFO - 2018-05-17 02:59:31 --> Router Class Initialized
INFO - 2018-05-17 02:59:31 --> Router Class Initialized
INFO - 2018-05-17 02:59:31 --> Output Class Initialized
INFO - 2018-05-17 02:59:31 --> Output Class Initialized
INFO - 2018-05-17 02:59:31 --> Security Class Initialized
INFO - 2018-05-17 02:59:31 --> Security Class Initialized
DEBUG - 2018-05-17 02:59:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-17 02:59:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 02:59:31 --> Input Class Initialized
INFO - 2018-05-17 02:59:31 --> Input Class Initialized
INFO - 2018-05-17 02:59:31 --> Language Class Initialized
INFO - 2018-05-17 02:59:31 --> Language Class Initialized
ERROR - 2018-05-17 02:59:31 --> 404 Page Not Found: /index
ERROR - 2018-05-17 02:59:31 --> 404 Page Not Found: /index
INFO - 2018-05-17 02:59:31 --> Config Class Initialized
INFO - 2018-05-17 02:59:31 --> Hooks Class Initialized
DEBUG - 2018-05-17 02:59:31 --> UTF-8 Support Enabled
INFO - 2018-05-17 02:59:31 --> Utf8 Class Initialized
INFO - 2018-05-17 02:59:31 --> URI Class Initialized
INFO - 2018-05-17 02:59:31 --> Router Class Initialized
INFO - 2018-05-17 02:59:31 --> Output Class Initialized
INFO - 2018-05-17 02:59:31 --> Security Class Initialized
DEBUG - 2018-05-17 02:59:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 02:59:31 --> Input Class Initialized
INFO - 2018-05-17 02:59:31 --> Language Class Initialized
ERROR - 2018-05-17 02:59:31 --> 404 Page Not Found: /index
INFO - 2018-05-17 02:59:31 --> Config Class Initialized
INFO - 2018-05-17 02:59:31 --> Hooks Class Initialized
DEBUG - 2018-05-17 02:59:31 --> UTF-8 Support Enabled
INFO - 2018-05-17 02:59:31 --> Config Class Initialized
INFO - 2018-05-17 02:59:31 --> Hooks Class Initialized
INFO - 2018-05-17 02:59:31 --> Utf8 Class Initialized
DEBUG - 2018-05-17 02:59:31 --> UTF-8 Support Enabled
INFO - 2018-05-17 02:59:31 --> Utf8 Class Initialized
INFO - 2018-05-17 02:59:31 --> URI Class Initialized
INFO - 2018-05-17 02:59:31 --> Router Class Initialized
INFO - 2018-05-17 02:59:31 --> URI Class Initialized
INFO - 2018-05-17 02:59:31 --> Router Class Initialized
INFO - 2018-05-17 02:59:31 --> Output Class Initialized
INFO - 2018-05-17 02:59:31 --> Security Class Initialized
INFO - 2018-05-17 02:59:31 --> Output Class Initialized
DEBUG - 2018-05-17 02:59:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 02:59:31 --> Security Class Initialized
INFO - 2018-05-17 02:59:31 --> Input Class Initialized
INFO - 2018-05-17 02:59:31 --> Language Class Initialized
DEBUG - 2018-05-17 02:59:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-05-17 02:59:31 --> 404 Page Not Found: /index
INFO - 2018-05-17 02:59:31 --> Input Class Initialized
INFO - 2018-05-17 02:59:31 --> Language Class Initialized
ERROR - 2018-05-17 02:59:31 --> 404 Page Not Found: /index
INFO - 2018-05-17 02:59:41 --> Config Class Initialized
INFO - 2018-05-17 02:59:41 --> Hooks Class Initialized
DEBUG - 2018-05-17 02:59:41 --> UTF-8 Support Enabled
INFO - 2018-05-17 02:59:41 --> Utf8 Class Initialized
INFO - 2018-05-17 03:00:06 --> Config Class Initialized
INFO - 2018-05-17 03:00:06 --> Hooks Class Initialized
DEBUG - 2018-05-17 03:00:06 --> UTF-8 Support Enabled
INFO - 2018-05-17 03:00:06 --> Utf8 Class Initialized
INFO - 2018-05-17 03:00:06 --> URI Class Initialized
INFO - 2018-05-17 03:00:06 --> Router Class Initialized
INFO - 2018-05-17 03:00:06 --> Output Class Initialized
INFO - 2018-05-17 03:00:06 --> Security Class Initialized
DEBUG - 2018-05-17 03:00:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 03:00:06 --> Input Class Initialized
INFO - 2018-05-17 03:00:06 --> Language Class Initialized
INFO - 2018-05-17 03:00:06 --> Language Class Initialized
INFO - 2018-05-17 03:00:06 --> Config Class Initialized
INFO - 2018-05-17 03:00:06 --> Loader Class Initialized
DEBUG - 2018-05-17 03:00:06 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-17 03:00:06 --> Helper loaded: url_helper
INFO - 2018-05-17 03:00:06 --> Helper loaded: form_helper
INFO - 2018-05-17 03:00:06 --> Helper loaded: date_helper
INFO - 2018-05-17 03:00:06 --> Helper loaded: util_helper
INFO - 2018-05-17 03:00:06 --> Helper loaded: text_helper
INFO - 2018-05-17 03:00:06 --> Helper loaded: string_helper
INFO - 2018-05-17 03:00:06 --> Database Driver Class Initialized
DEBUG - 2018-05-17 03:00:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-17 03:00:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-17 03:00:06 --> Email Class Initialized
INFO - 2018-05-17 03:00:06 --> Controller Class Initialized
DEBUG - 2018-05-17 03:00:06 --> Home MX_Controller Initialized
DEBUG - 2018-05-17 03:00:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-17 03:00:06 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-17 03:00:06 --> Login MX_Controller Initialized
INFO - 2018-05-17 03:00:06 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-17 03:00:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-17 03:00:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-17 03:00:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-17 03:00:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-17 03:00:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-17 03:00:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-17 03:00:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-17 03:00:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-05-17 03:00:06 --> Final output sent to browser
DEBUG - 2018-05-17 03:00:06 --> Total execution time: 0.5035
INFO - 2018-05-17 03:00:07 --> Config Class Initialized
INFO - 2018-05-17 03:00:07 --> Config Class Initialized
INFO - 2018-05-17 03:00:07 --> Hooks Class Initialized
INFO - 2018-05-17 03:00:07 --> Hooks Class Initialized
DEBUG - 2018-05-17 03:00:07 --> UTF-8 Support Enabled
INFO - 2018-05-17 03:00:07 --> Utf8 Class Initialized
INFO - 2018-05-17 03:00:07 --> URI Class Initialized
INFO - 2018-05-17 03:00:07 --> Router Class Initialized
DEBUG - 2018-05-17 03:00:07 --> UTF-8 Support Enabled
INFO - 2018-05-17 03:00:07 --> Output Class Initialized
INFO - 2018-05-17 03:00:07 --> Security Class Initialized
INFO - 2018-05-17 03:00:07 --> Utf8 Class Initialized
DEBUG - 2018-05-17 03:00:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 03:00:07 --> URI Class Initialized
INFO - 2018-05-17 03:00:07 --> Input Class Initialized
INFO - 2018-05-17 03:00:07 --> Router Class Initialized
INFO - 2018-05-17 03:00:07 --> Output Class Initialized
INFO - 2018-05-17 03:00:07 --> Language Class Initialized
ERROR - 2018-05-17 03:00:07 --> 404 Page Not Found: /index
INFO - 2018-05-17 03:00:07 --> Security Class Initialized
DEBUG - 2018-05-17 03:00:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 03:00:08 --> Input Class Initialized
INFO - 2018-05-17 03:00:08 --> Language Class Initialized
ERROR - 2018-05-17 03:00:08 --> 404 Page Not Found: /index
INFO - 2018-05-17 03:00:08 --> Config Class Initialized
INFO - 2018-05-17 03:00:08 --> Hooks Class Initialized
DEBUG - 2018-05-17 03:00:08 --> UTF-8 Support Enabled
INFO - 2018-05-17 03:00:08 --> Utf8 Class Initialized
INFO - 2018-05-17 03:00:08 --> URI Class Initialized
INFO - 2018-05-17 03:00:08 --> Router Class Initialized
INFO - 2018-05-17 03:00:08 --> Output Class Initialized
INFO - 2018-05-17 03:00:08 --> Security Class Initialized
DEBUG - 2018-05-17 03:00:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 03:00:08 --> Input Class Initialized
INFO - 2018-05-17 03:00:08 --> Language Class Initialized
ERROR - 2018-05-17 03:00:08 --> 404 Page Not Found: /index
INFO - 2018-05-17 03:00:08 --> Config Class Initialized
INFO - 2018-05-17 03:00:08 --> Hooks Class Initialized
DEBUG - 2018-05-17 03:00:08 --> UTF-8 Support Enabled
INFO - 2018-05-17 03:00:08 --> Utf8 Class Initialized
INFO - 2018-05-17 03:00:08 --> URI Class Initialized
INFO - 2018-05-17 03:00:08 --> Router Class Initialized
INFO - 2018-05-17 03:00:08 --> Output Class Initialized
INFO - 2018-05-17 03:00:08 --> Security Class Initialized
DEBUG - 2018-05-17 03:00:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 03:00:08 --> Input Class Initialized
INFO - 2018-05-17 03:00:08 --> Language Class Initialized
ERROR - 2018-05-17 03:00:08 --> 404 Page Not Found: /index
INFO - 2018-05-17 03:00:12 --> Config Class Initialized
INFO - 2018-05-17 03:00:12 --> Hooks Class Initialized
DEBUG - 2018-05-17 03:00:12 --> UTF-8 Support Enabled
INFO - 2018-05-17 03:00:12 --> Utf8 Class Initialized
INFO - 2018-05-17 03:00:14 --> Config Class Initialized
INFO - 2018-05-17 03:00:14 --> Hooks Class Initialized
DEBUG - 2018-05-17 03:00:14 --> UTF-8 Support Enabled
INFO - 2018-05-17 03:00:14 --> Utf8 Class Initialized
INFO - 2018-05-17 03:03:14 --> Config Class Initialized
INFO - 2018-05-17 03:03:14 --> Hooks Class Initialized
DEBUG - 2018-05-17 03:03:14 --> UTF-8 Support Enabled
INFO - 2018-05-17 03:03:14 --> Utf8 Class Initialized
INFO - 2018-05-17 03:03:14 --> URI Class Initialized
INFO - 2018-05-17 03:03:14 --> Router Class Initialized
INFO - 2018-05-17 03:03:14 --> Output Class Initialized
INFO - 2018-05-17 03:03:14 --> Security Class Initialized
DEBUG - 2018-05-17 03:03:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 03:03:14 --> Input Class Initialized
INFO - 2018-05-17 03:03:14 --> Language Class Initialized
INFO - 2018-05-17 03:03:14 --> Language Class Initialized
INFO - 2018-05-17 03:03:14 --> Config Class Initialized
INFO - 2018-05-17 03:03:14 --> Loader Class Initialized
DEBUG - 2018-05-17 03:03:14 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-17 03:03:14 --> Helper loaded: url_helper
INFO - 2018-05-17 03:03:14 --> Helper loaded: form_helper
INFO - 2018-05-17 03:03:14 --> Helper loaded: date_helper
INFO - 2018-05-17 03:03:14 --> Helper loaded: util_helper
INFO - 2018-05-17 03:03:14 --> Helper loaded: text_helper
INFO - 2018-05-17 03:03:14 --> Helper loaded: string_helper
INFO - 2018-05-17 03:03:14 --> Database Driver Class Initialized
DEBUG - 2018-05-17 03:03:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-17 03:03:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-17 03:03:14 --> Email Class Initialized
INFO - 2018-05-17 03:03:14 --> Controller Class Initialized
DEBUG - 2018-05-17 03:03:14 --> Home MX_Controller Initialized
DEBUG - 2018-05-17 03:03:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-17 03:03:14 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-17 03:03:14 --> Login MX_Controller Initialized
INFO - 2018-05-17 03:03:14 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-17 03:03:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-17 03:03:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-17 03:03:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-17 03:03:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-17 03:03:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
INFO - 2018-05-17 03:03:45 --> Config Class Initialized
INFO - 2018-05-17 03:03:45 --> Hooks Class Initialized
DEBUG - 2018-05-17 03:03:45 --> UTF-8 Support Enabled
INFO - 2018-05-17 03:03:45 --> Utf8 Class Initialized
INFO - 2018-05-17 03:03:45 --> URI Class Initialized
INFO - 2018-05-17 03:03:45 --> Router Class Initialized
INFO - 2018-05-17 03:03:45 --> Output Class Initialized
INFO - 2018-05-17 03:03:45 --> Security Class Initialized
DEBUG - 2018-05-17 03:03:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 03:03:45 --> Input Class Initialized
INFO - 2018-05-17 03:03:45 --> Language Class Initialized
INFO - 2018-05-17 03:03:45 --> Language Class Initialized
INFO - 2018-05-17 03:03:45 --> Config Class Initialized
INFO - 2018-05-17 03:03:45 --> Loader Class Initialized
DEBUG - 2018-05-17 03:03:45 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-17 03:03:45 --> Helper loaded: url_helper
INFO - 2018-05-17 03:03:45 --> Helper loaded: form_helper
INFO - 2018-05-17 03:03:45 --> Helper loaded: date_helper
INFO - 2018-05-17 03:03:45 --> Helper loaded: util_helper
INFO - 2018-05-17 03:03:45 --> Helper loaded: text_helper
INFO - 2018-05-17 03:03:45 --> Helper loaded: string_helper
INFO - 2018-05-17 03:03:45 --> Database Driver Class Initialized
DEBUG - 2018-05-17 03:03:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-17 03:03:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-17 03:03:45 --> Email Class Initialized
INFO - 2018-05-17 03:03:45 --> Controller Class Initialized
DEBUG - 2018-05-17 03:03:45 --> Home MX_Controller Initialized
DEBUG - 2018-05-17 03:03:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-17 03:03:45 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-17 03:03:45 --> Login MX_Controller Initialized
INFO - 2018-05-17 03:03:45 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-17 03:03:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-17 03:03:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-17 03:03:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-17 03:03:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-17 03:03:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
INFO - 2018-05-17 03:03:47 --> Config Class Initialized
INFO - 2018-05-17 03:03:47 --> Hooks Class Initialized
DEBUG - 2018-05-17 03:03:47 --> UTF-8 Support Enabled
INFO - 2018-05-17 03:03:47 --> Utf8 Class Initialized
INFO - 2018-05-17 03:03:47 --> URI Class Initialized
INFO - 2018-05-17 03:03:47 --> Router Class Initialized
INFO - 2018-05-17 03:03:47 --> Output Class Initialized
INFO - 2018-05-17 03:03:47 --> Security Class Initialized
DEBUG - 2018-05-17 03:03:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 03:03:47 --> Input Class Initialized
INFO - 2018-05-17 03:03:47 --> Language Class Initialized
ERROR - 2018-05-17 03:03:47 --> 404 Page Not Found: /index
INFO - 2018-05-17 03:03:47 --> Config Class Initialized
INFO - 2018-05-17 03:03:47 --> Hooks Class Initialized
DEBUG - 2018-05-17 03:03:48 --> UTF-8 Support Enabled
INFO - 2018-05-17 03:03:48 --> Utf8 Class Initialized
INFO - 2018-05-17 03:03:48 --> URI Class Initialized
INFO - 2018-05-17 03:03:48 --> Router Class Initialized
INFO - 2018-05-17 03:03:48 --> Output Class Initialized
INFO - 2018-05-17 03:03:48 --> Security Class Initialized
DEBUG - 2018-05-17 03:03:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 03:03:48 --> Input Class Initialized
INFO - 2018-05-17 03:03:48 --> Language Class Initialized
ERROR - 2018-05-17 03:03:48 --> 404 Page Not Found: /index
INFO - 2018-05-17 03:03:48 --> Config Class Initialized
INFO - 2018-05-17 03:03:48 --> Hooks Class Initialized
DEBUG - 2018-05-17 03:03:48 --> UTF-8 Support Enabled
INFO - 2018-05-17 03:03:48 --> Utf8 Class Initialized
INFO - 2018-05-17 03:03:48 --> URI Class Initialized
INFO - 2018-05-17 03:03:48 --> Router Class Initialized
INFO - 2018-05-17 03:03:48 --> Output Class Initialized
INFO - 2018-05-17 03:03:48 --> Security Class Initialized
DEBUG - 2018-05-17 03:03:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 03:03:48 --> Input Class Initialized
INFO - 2018-05-17 03:03:48 --> Language Class Initialized
ERROR - 2018-05-17 03:03:48 --> 404 Page Not Found: /index
INFO - 2018-05-17 03:03:49 --> Config Class Initialized
INFO - 2018-05-17 03:03:49 --> Hooks Class Initialized
DEBUG - 2018-05-17 03:03:49 --> UTF-8 Support Enabled
INFO - 2018-05-17 03:03:49 --> Utf8 Class Initialized
INFO - 2018-05-17 03:03:49 --> URI Class Initialized
INFO - 2018-05-17 03:03:49 --> Router Class Initialized
INFO - 2018-05-17 03:03:49 --> Output Class Initialized
INFO - 2018-05-17 03:03:49 --> Security Class Initialized
DEBUG - 2018-05-17 03:03:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 03:03:49 --> Input Class Initialized
INFO - 2018-05-17 03:03:49 --> Language Class Initialized
ERROR - 2018-05-17 03:03:49 --> 404 Page Not Found: /index
INFO - 2018-05-17 03:03:49 --> Config Class Initialized
INFO - 2018-05-17 03:03:49 --> Hooks Class Initialized
DEBUG - 2018-05-17 03:03:49 --> UTF-8 Support Enabled
INFO - 2018-05-17 03:03:49 --> Utf8 Class Initialized
INFO - 2018-05-17 03:03:49 --> URI Class Initialized
INFO - 2018-05-17 03:03:49 --> Router Class Initialized
INFO - 2018-05-17 03:03:49 --> Output Class Initialized
INFO - 2018-05-17 03:03:49 --> Security Class Initialized
DEBUG - 2018-05-17 03:03:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 03:03:49 --> Input Class Initialized
INFO - 2018-05-17 03:03:49 --> Language Class Initialized
ERROR - 2018-05-17 03:03:49 --> 404 Page Not Found: /index
INFO - 2018-05-17 03:03:49 --> Config Class Initialized
INFO - 2018-05-17 03:03:49 --> Hooks Class Initialized
DEBUG - 2018-05-17 03:03:49 --> UTF-8 Support Enabled
INFO - 2018-05-17 03:03:49 --> Utf8 Class Initialized
INFO - 2018-05-17 03:03:49 --> URI Class Initialized
INFO - 2018-05-17 03:03:49 --> Router Class Initialized
INFO - 2018-05-17 03:03:49 --> Output Class Initialized
INFO - 2018-05-17 03:03:49 --> Security Class Initialized
DEBUG - 2018-05-17 03:03:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 03:03:49 --> Input Class Initialized
INFO - 2018-05-17 03:03:49 --> Language Class Initialized
ERROR - 2018-05-17 03:03:49 --> 404 Page Not Found: /index
INFO - 2018-05-17 03:03:57 --> Config Class Initialized
INFO - 2018-05-17 03:03:57 --> Hooks Class Initialized
DEBUG - 2018-05-17 03:03:57 --> UTF-8 Support Enabled
INFO - 2018-05-17 03:03:57 --> Utf8 Class Initialized
INFO - 2018-05-17 03:03:57 --> URI Class Initialized
INFO - 2018-05-17 03:03:57 --> Router Class Initialized
INFO - 2018-05-17 03:03:57 --> Output Class Initialized
INFO - 2018-05-17 03:03:57 --> Security Class Initialized
DEBUG - 2018-05-17 03:03:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 03:03:57 --> Input Class Initialized
INFO - 2018-05-17 03:03:57 --> Language Class Initialized
INFO - 2018-05-17 03:03:57 --> Language Class Initialized
INFO - 2018-05-17 03:03:57 --> Config Class Initialized
INFO - 2018-05-17 03:03:57 --> Loader Class Initialized
DEBUG - 2018-05-17 03:03:57 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-17 03:03:57 --> Helper loaded: url_helper
INFO - 2018-05-17 03:03:57 --> Helper loaded: form_helper
INFO - 2018-05-17 03:03:57 --> Helper loaded: date_helper
INFO - 2018-05-17 03:03:57 --> Helper loaded: util_helper
INFO - 2018-05-17 03:03:57 --> Helper loaded: text_helper
INFO - 2018-05-17 03:03:57 --> Helper loaded: string_helper
INFO - 2018-05-17 03:03:57 --> Database Driver Class Initialized
DEBUG - 2018-05-17 03:03:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-17 03:03:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-17 03:03:57 --> Email Class Initialized
INFO - 2018-05-17 03:03:57 --> Controller Class Initialized
DEBUG - 2018-05-17 03:03:57 --> Home MX_Controller Initialized
DEBUG - 2018-05-17 03:03:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-17 03:03:57 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-17 03:03:57 --> Login MX_Controller Initialized
INFO - 2018-05-17 03:03:57 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-17 03:03:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-17 03:03:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-17 03:03:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-17 03:03:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-17 03:03:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-17 03:03:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-17 03:03:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-17 03:03:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-05-17 03:03:57 --> Final output sent to browser
DEBUG - 2018-05-17 03:03:57 --> Total execution time: 0.4886
INFO - 2018-05-17 03:03:58 --> Config Class Initialized
INFO - 2018-05-17 03:03:58 --> Config Class Initialized
INFO - 2018-05-17 03:03:58 --> Hooks Class Initialized
INFO - 2018-05-17 03:03:58 --> Hooks Class Initialized
DEBUG - 2018-05-17 03:03:58 --> UTF-8 Support Enabled
DEBUG - 2018-05-17 03:03:58 --> UTF-8 Support Enabled
INFO - 2018-05-17 03:03:58 --> Utf8 Class Initialized
INFO - 2018-05-17 03:03:58 --> Utf8 Class Initialized
INFO - 2018-05-17 03:03:58 --> URI Class Initialized
INFO - 2018-05-17 03:03:58 --> Router Class Initialized
INFO - 2018-05-17 03:03:58 --> Output Class Initialized
INFO - 2018-05-17 03:03:58 --> Security Class Initialized
DEBUG - 2018-05-17 03:03:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 03:03:58 --> Input Class Initialized
INFO - 2018-05-17 03:03:58 --> Language Class Initialized
INFO - 2018-05-17 03:03:58 --> URI Class Initialized
ERROR - 2018-05-17 03:03:58 --> 404 Page Not Found: /index
INFO - 2018-05-17 03:03:58 --> Router Class Initialized
INFO - 2018-05-17 03:03:58 --> Output Class Initialized
INFO - 2018-05-17 03:03:58 --> Security Class Initialized
DEBUG - 2018-05-17 03:03:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 03:03:58 --> Input Class Initialized
INFO - 2018-05-17 03:03:58 --> Language Class Initialized
ERROR - 2018-05-17 03:03:58 --> 404 Page Not Found: /index
INFO - 2018-05-17 03:03:58 --> Config Class Initialized
INFO - 2018-05-17 03:03:58 --> Hooks Class Initialized
DEBUG - 2018-05-17 03:03:58 --> UTF-8 Support Enabled
INFO - 2018-05-17 03:03:58 --> Utf8 Class Initialized
INFO - 2018-05-17 03:03:58 --> URI Class Initialized
INFO - 2018-05-17 03:03:58 --> Router Class Initialized
INFO - 2018-05-17 03:03:58 --> Output Class Initialized
INFO - 2018-05-17 03:03:59 --> Security Class Initialized
DEBUG - 2018-05-17 03:03:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 03:03:59 --> Input Class Initialized
INFO - 2018-05-17 03:03:59 --> Language Class Initialized
ERROR - 2018-05-17 03:03:59 --> 404 Page Not Found: /index
INFO - 2018-05-17 03:03:59 --> Config Class Initialized
INFO - 2018-05-17 03:03:59 --> Hooks Class Initialized
DEBUG - 2018-05-17 03:03:59 --> UTF-8 Support Enabled
INFO - 2018-05-17 03:03:59 --> Utf8 Class Initialized
INFO - 2018-05-17 03:03:59 --> URI Class Initialized
INFO - 2018-05-17 03:03:59 --> Router Class Initialized
INFO - 2018-05-17 03:03:59 --> Output Class Initialized
INFO - 2018-05-17 03:03:59 --> Security Class Initialized
DEBUG - 2018-05-17 03:03:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 03:03:59 --> Input Class Initialized
INFO - 2018-05-17 03:03:59 --> Language Class Initialized
ERROR - 2018-05-17 03:03:59 --> 404 Page Not Found: /index
INFO - 2018-05-17 03:04:02 --> Config Class Initialized
INFO - 2018-05-17 03:04:02 --> Hooks Class Initialized
DEBUG - 2018-05-17 03:04:02 --> UTF-8 Support Enabled
INFO - 2018-05-17 03:04:02 --> Utf8 Class Initialized
INFO - 2018-05-17 03:04:02 --> URI Class Initialized
INFO - 2018-05-17 03:04:02 --> Router Class Initialized
INFO - 2018-05-17 03:04:02 --> Output Class Initialized
INFO - 2018-05-17 03:04:02 --> Security Class Initialized
DEBUG - 2018-05-17 03:04:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 03:04:02 --> Input Class Initialized
INFO - 2018-05-17 03:04:02 --> Language Class Initialized
INFO - 2018-05-17 03:04:02 --> Language Class Initialized
INFO - 2018-05-17 03:04:02 --> Config Class Initialized
INFO - 2018-05-17 03:04:02 --> Loader Class Initialized
DEBUG - 2018-05-17 03:04:02 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-17 03:04:02 --> Helper loaded: url_helper
INFO - 2018-05-17 03:04:02 --> Helper loaded: form_helper
INFO - 2018-05-17 03:04:02 --> Helper loaded: date_helper
INFO - 2018-05-17 03:04:02 --> Helper loaded: util_helper
INFO - 2018-05-17 03:04:02 --> Helper loaded: text_helper
INFO - 2018-05-17 03:04:02 --> Helper loaded: string_helper
INFO - 2018-05-17 03:04:02 --> Database Driver Class Initialized
DEBUG - 2018-05-17 03:04:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-17 03:04:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-17 03:04:02 --> Email Class Initialized
INFO - 2018-05-17 03:04:02 --> Controller Class Initialized
ERROR - 2018-05-17 03:04:02 --> 404 Page Not Found: ../modules/home/controllers/Home/productsConsulting-Accelerator
INFO - 2018-05-17 03:04:12 --> Config Class Initialized
INFO - 2018-05-17 03:04:12 --> Hooks Class Initialized
DEBUG - 2018-05-17 03:04:12 --> UTF-8 Support Enabled
INFO - 2018-05-17 03:04:12 --> Utf8 Class Initialized
INFO - 2018-05-17 03:04:12 --> URI Class Initialized
INFO - 2018-05-17 03:04:12 --> Router Class Initialized
INFO - 2018-05-17 03:04:12 --> Output Class Initialized
INFO - 2018-05-17 03:04:12 --> Security Class Initialized
DEBUG - 2018-05-17 03:04:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 03:04:12 --> Input Class Initialized
INFO - 2018-05-17 03:04:12 --> Language Class Initialized
INFO - 2018-05-17 03:04:12 --> Language Class Initialized
INFO - 2018-05-17 03:04:12 --> Config Class Initialized
INFO - 2018-05-17 03:04:12 --> Loader Class Initialized
DEBUG - 2018-05-17 03:04:12 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-17 03:04:12 --> Helper loaded: url_helper
INFO - 2018-05-17 03:04:12 --> Helper loaded: form_helper
INFO - 2018-05-17 03:04:12 --> Helper loaded: date_helper
INFO - 2018-05-17 03:04:12 --> Helper loaded: util_helper
INFO - 2018-05-17 03:04:12 --> Helper loaded: text_helper
INFO - 2018-05-17 03:04:12 --> Helper loaded: string_helper
INFO - 2018-05-17 03:04:12 --> Database Driver Class Initialized
DEBUG - 2018-05-17 03:04:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-17 03:04:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-17 03:04:13 --> Email Class Initialized
INFO - 2018-05-17 03:04:13 --> Controller Class Initialized
DEBUG - 2018-05-17 03:04:13 --> Home MX_Controller Initialized
DEBUG - 2018-05-17 03:04:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-17 03:04:13 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-17 03:04:13 --> Login MX_Controller Initialized
INFO - 2018-05-17 03:04:13 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-17 03:04:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-17 03:04:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-17 03:04:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-17 03:04:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-17 03:04:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-17 03:04:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-17 03:04:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-17 03:04:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-05-17 03:04:13 --> Final output sent to browser
DEBUG - 2018-05-17 03:04:13 --> Total execution time: 0.5074
INFO - 2018-05-17 03:04:29 --> Config Class Initialized
INFO - 2018-05-17 03:04:29 --> Hooks Class Initialized
DEBUG - 2018-05-17 03:04:29 --> UTF-8 Support Enabled
INFO - 2018-05-17 03:04:29 --> Utf8 Class Initialized
INFO - 2018-05-17 03:04:29 --> URI Class Initialized
INFO - 2018-05-17 03:04:29 --> Router Class Initialized
INFO - 2018-05-17 03:04:29 --> Output Class Initialized
INFO - 2018-05-17 03:04:29 --> Security Class Initialized
DEBUG - 2018-05-17 03:04:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 03:04:29 --> Input Class Initialized
INFO - 2018-05-17 03:04:29 --> Language Class Initialized
INFO - 2018-05-17 03:04:29 --> Language Class Initialized
INFO - 2018-05-17 03:04:29 --> Config Class Initialized
INFO - 2018-05-17 03:04:29 --> Loader Class Initialized
DEBUG - 2018-05-17 03:04:29 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-17 03:04:29 --> Helper loaded: url_helper
INFO - 2018-05-17 03:04:29 --> Helper loaded: form_helper
INFO - 2018-05-17 03:04:29 --> Helper loaded: date_helper
INFO - 2018-05-17 03:04:29 --> Helper loaded: util_helper
INFO - 2018-05-17 03:04:29 --> Helper loaded: text_helper
INFO - 2018-05-17 03:04:29 --> Helper loaded: string_helper
INFO - 2018-05-17 03:04:29 --> Database Driver Class Initialized
DEBUG - 2018-05-17 03:04:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-17 03:04:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-17 03:04:29 --> Email Class Initialized
INFO - 2018-05-17 03:04:29 --> Controller Class Initialized
DEBUG - 2018-05-17 03:04:29 --> Home MX_Controller Initialized
DEBUG - 2018-05-17 03:04:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-17 03:04:29 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-17 03:04:29 --> Login MX_Controller Initialized
INFO - 2018-05-17 03:04:29 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-17 03:04:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-17 03:04:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-17 03:04:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-17 03:04:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-17 03:04:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-17 03:04:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-17 03:04:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-17 03:04:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-05-17 03:04:30 --> Final output sent to browser
DEBUG - 2018-05-17 03:04:30 --> Total execution time: 0.5854
INFO - 2018-05-17 03:04:30 --> Config Class Initialized
INFO - 2018-05-17 03:04:30 --> Config Class Initialized
INFO - 2018-05-17 03:04:30 --> Hooks Class Initialized
INFO - 2018-05-17 03:04:30 --> Hooks Class Initialized
DEBUG - 2018-05-17 03:04:30 --> UTF-8 Support Enabled
INFO - 2018-05-17 03:04:30 --> Utf8 Class Initialized
DEBUG - 2018-05-17 03:04:30 --> UTF-8 Support Enabled
INFO - 2018-05-17 03:04:30 --> Utf8 Class Initialized
INFO - 2018-05-17 03:04:30 --> URI Class Initialized
INFO - 2018-05-17 03:04:30 --> URI Class Initialized
INFO - 2018-05-17 03:04:30 --> Router Class Initialized
INFO - 2018-05-17 03:04:30 --> Router Class Initialized
INFO - 2018-05-17 03:04:30 --> Output Class Initialized
INFO - 2018-05-17 03:04:30 --> Output Class Initialized
INFO - 2018-05-17 03:04:30 --> Security Class Initialized
INFO - 2018-05-17 03:04:30 --> Security Class Initialized
DEBUG - 2018-05-17 03:04:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 03:04:30 --> Input Class Initialized
DEBUG - 2018-05-17 03:04:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 03:04:30 --> Input Class Initialized
INFO - 2018-05-17 03:04:30 --> Language Class Initialized
INFO - 2018-05-17 03:04:30 --> Language Class Initialized
ERROR - 2018-05-17 03:04:30 --> 404 Page Not Found: /index
ERROR - 2018-05-17 03:04:31 --> 404 Page Not Found: /index
INFO - 2018-05-17 03:04:31 --> Config Class Initialized
INFO - 2018-05-17 03:04:31 --> Hooks Class Initialized
DEBUG - 2018-05-17 03:04:31 --> UTF-8 Support Enabled
INFO - 2018-05-17 03:04:31 --> Utf8 Class Initialized
INFO - 2018-05-17 03:04:31 --> URI Class Initialized
INFO - 2018-05-17 03:04:31 --> Router Class Initialized
INFO - 2018-05-17 03:04:31 --> Output Class Initialized
INFO - 2018-05-17 03:04:31 --> Security Class Initialized
DEBUG - 2018-05-17 03:04:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 03:04:31 --> Input Class Initialized
INFO - 2018-05-17 03:04:31 --> Language Class Initialized
ERROR - 2018-05-17 03:04:31 --> 404 Page Not Found: /index
INFO - 2018-05-17 03:04:31 --> Config Class Initialized
INFO - 2018-05-17 03:04:31 --> Hooks Class Initialized
DEBUG - 2018-05-17 03:04:31 --> UTF-8 Support Enabled
INFO - 2018-05-17 03:04:31 --> Utf8 Class Initialized
INFO - 2018-05-17 03:04:31 --> URI Class Initialized
INFO - 2018-05-17 03:04:31 --> Router Class Initialized
INFO - 2018-05-17 03:04:31 --> Output Class Initialized
INFO - 2018-05-17 03:04:31 --> Security Class Initialized
DEBUG - 2018-05-17 03:04:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 03:04:31 --> Input Class Initialized
INFO - 2018-05-17 03:04:31 --> Language Class Initialized
ERROR - 2018-05-17 03:04:31 --> 404 Page Not Found: /index
INFO - 2018-05-17 03:04:36 --> Config Class Initialized
INFO - 2018-05-17 03:04:36 --> Hooks Class Initialized
DEBUG - 2018-05-17 03:04:36 --> UTF-8 Support Enabled
INFO - 2018-05-17 03:04:36 --> Utf8 Class Initialized
INFO - 2018-05-17 03:04:36 --> URI Class Initialized
INFO - 2018-05-17 03:04:36 --> Router Class Initialized
INFO - 2018-05-17 03:04:36 --> Output Class Initialized
INFO - 2018-05-17 03:04:36 --> Security Class Initialized
DEBUG - 2018-05-17 03:04:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 03:04:36 --> Input Class Initialized
INFO - 2018-05-17 03:04:36 --> Language Class Initialized
INFO - 2018-05-17 03:04:36 --> Language Class Initialized
INFO - 2018-05-17 03:04:36 --> Config Class Initialized
INFO - 2018-05-17 03:04:36 --> Loader Class Initialized
DEBUG - 2018-05-17 03:04:36 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-17 03:04:36 --> Helper loaded: url_helper
INFO - 2018-05-17 03:04:36 --> Helper loaded: form_helper
INFO - 2018-05-17 03:04:36 --> Helper loaded: date_helper
INFO - 2018-05-17 03:04:36 --> Helper loaded: util_helper
INFO - 2018-05-17 03:04:36 --> Helper loaded: text_helper
INFO - 2018-05-17 03:04:36 --> Helper loaded: string_helper
INFO - 2018-05-17 03:04:36 --> Database Driver Class Initialized
DEBUG - 2018-05-17 03:04:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-17 03:04:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-17 03:04:36 --> Email Class Initialized
INFO - 2018-05-17 03:04:36 --> Controller Class Initialized
DEBUG - 2018-05-17 03:04:36 --> Home MX_Controller Initialized
DEBUG - 2018-05-17 03:04:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-17 03:04:37 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-17 03:04:37 --> Login MX_Controller Initialized
INFO - 2018-05-17 03:04:37 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-17 03:04:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-17 03:04:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-17 03:04:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-17 03:04:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-17 03:04:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-17 03:04:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-17 03:04:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-17 03:04:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-05-17 03:04:37 --> Final output sent to browser
DEBUG - 2018-05-17 03:04:37 --> Total execution time: 0.5294
INFO - 2018-05-17 03:04:37 --> Config Class Initialized
INFO - 2018-05-17 03:04:37 --> Config Class Initialized
INFO - 2018-05-17 03:04:37 --> Hooks Class Initialized
INFO - 2018-05-17 03:04:37 --> Hooks Class Initialized
DEBUG - 2018-05-17 03:04:37 --> UTF-8 Support Enabled
DEBUG - 2018-05-17 03:04:37 --> UTF-8 Support Enabled
INFO - 2018-05-17 03:04:37 --> Utf8 Class Initialized
INFO - 2018-05-17 03:04:37 --> URI Class Initialized
INFO - 2018-05-17 03:04:37 --> Router Class Initialized
INFO - 2018-05-17 03:04:37 --> Utf8 Class Initialized
INFO - 2018-05-17 03:04:37 --> Output Class Initialized
INFO - 2018-05-17 03:04:37 --> URI Class Initialized
INFO - 2018-05-17 03:04:37 --> Security Class Initialized
INFO - 2018-05-17 03:04:37 --> Router Class Initialized
DEBUG - 2018-05-17 03:04:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 03:04:37 --> Input Class Initialized
INFO - 2018-05-17 03:04:37 --> Language Class Initialized
ERROR - 2018-05-17 03:04:38 --> 404 Page Not Found: /index
INFO - 2018-05-17 03:04:38 --> Output Class Initialized
INFO - 2018-05-17 03:04:38 --> Security Class Initialized
INFO - 2018-05-17 03:04:38 --> Config Class Initialized
INFO - 2018-05-17 03:04:38 --> Hooks Class Initialized
DEBUG - 2018-05-17 03:04:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-17 03:04:38 --> UTF-8 Support Enabled
INFO - 2018-05-17 03:04:38 --> Utf8 Class Initialized
INFO - 2018-05-17 03:04:38 --> URI Class Initialized
INFO - 2018-05-17 03:04:38 --> Router Class Initialized
INFO - 2018-05-17 03:04:38 --> Output Class Initialized
INFO - 2018-05-17 03:04:38 --> Security Class Initialized
DEBUG - 2018-05-17 03:04:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 03:04:38 --> Input Class Initialized
INFO - 2018-05-17 03:04:38 --> Language Class Initialized
ERROR - 2018-05-17 03:04:38 --> 404 Page Not Found: /index
INFO - 2018-05-17 03:04:38 --> Input Class Initialized
INFO - 2018-05-17 03:04:38 --> Config Class Initialized
INFO - 2018-05-17 03:04:38 --> Language Class Initialized
INFO - 2018-05-17 03:04:38 --> Hooks Class Initialized
DEBUG - 2018-05-17 03:04:38 --> UTF-8 Support Enabled
ERROR - 2018-05-17 03:04:38 --> 404 Page Not Found: /index
INFO - 2018-05-17 03:04:38 --> Utf8 Class Initialized
INFO - 2018-05-17 03:04:38 --> URI Class Initialized
INFO - 2018-05-17 03:04:38 --> Router Class Initialized
INFO - 2018-05-17 03:04:38 --> Output Class Initialized
INFO - 2018-05-17 03:04:38 --> Security Class Initialized
DEBUG - 2018-05-17 03:04:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 03:04:38 --> Input Class Initialized
INFO - 2018-05-17 03:04:38 --> Language Class Initialized
ERROR - 2018-05-17 03:04:38 --> 404 Page Not Found: /index
INFO - 2018-05-17 03:04:42 --> Config Class Initialized
INFO - 2018-05-17 03:04:42 --> Hooks Class Initialized
DEBUG - 2018-05-17 03:04:42 --> UTF-8 Support Enabled
INFO - 2018-05-17 03:04:42 --> Utf8 Class Initialized
INFO - 2018-05-17 03:04:42 --> URI Class Initialized
INFO - 2018-05-17 03:04:42 --> Router Class Initialized
INFO - 2018-05-17 03:04:42 --> Output Class Initialized
INFO - 2018-05-17 03:04:42 --> Security Class Initialized
DEBUG - 2018-05-17 03:04:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 03:04:42 --> Input Class Initialized
INFO - 2018-05-17 03:04:42 --> Language Class Initialized
INFO - 2018-05-17 03:04:42 --> Language Class Initialized
INFO - 2018-05-17 03:04:42 --> Config Class Initialized
INFO - 2018-05-17 03:04:42 --> Loader Class Initialized
DEBUG - 2018-05-17 03:04:42 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-17 03:04:42 --> Helper loaded: url_helper
INFO - 2018-05-17 03:04:42 --> Helper loaded: form_helper
INFO - 2018-05-17 03:04:42 --> Helper loaded: date_helper
INFO - 2018-05-17 03:04:42 --> Helper loaded: util_helper
INFO - 2018-05-17 03:04:42 --> Helper loaded: text_helper
INFO - 2018-05-17 03:04:42 --> Helper loaded: string_helper
INFO - 2018-05-17 03:04:42 --> Database Driver Class Initialized
DEBUG - 2018-05-17 03:04:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-17 03:04:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-17 03:04:42 --> Email Class Initialized
INFO - 2018-05-17 03:04:42 --> Controller Class Initialized
DEBUG - 2018-05-17 03:04:42 --> Home MX_Controller Initialized
DEBUG - 2018-05-17 03:04:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-17 03:04:42 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-17 03:04:42 --> Login MX_Controller Initialized
INFO - 2018-05-17 03:04:42 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-17 03:04:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-17 03:04:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-17 03:04:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-17 03:04:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-17 03:04:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
INFO - 2018-05-17 03:04:43 --> Config Class Initialized
INFO - 2018-05-17 03:04:43 --> Hooks Class Initialized
DEBUG - 2018-05-17 03:04:43 --> UTF-8 Support Enabled
INFO - 2018-05-17 03:04:43 --> Utf8 Class Initialized
INFO - 2018-05-17 03:04:43 --> URI Class Initialized
INFO - 2018-05-17 03:04:43 --> Router Class Initialized
INFO - 2018-05-17 03:04:43 --> Output Class Initialized
INFO - 2018-05-17 03:04:44 --> Security Class Initialized
DEBUG - 2018-05-17 03:04:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 03:04:44 --> Input Class Initialized
INFO - 2018-05-17 03:04:44 --> Language Class Initialized
ERROR - 2018-05-17 03:04:44 --> 404 Page Not Found: /index
INFO - 2018-05-17 03:04:44 --> Config Class Initialized
INFO - 2018-05-17 03:04:44 --> Hooks Class Initialized
DEBUG - 2018-05-17 03:04:44 --> UTF-8 Support Enabled
INFO - 2018-05-17 03:04:44 --> Utf8 Class Initialized
INFO - 2018-05-17 03:04:44 --> URI Class Initialized
INFO - 2018-05-17 03:04:44 --> Router Class Initialized
INFO - 2018-05-17 03:04:44 --> Output Class Initialized
INFO - 2018-05-17 03:04:44 --> Security Class Initialized
DEBUG - 2018-05-17 03:04:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 03:04:44 --> Input Class Initialized
INFO - 2018-05-17 03:04:44 --> Language Class Initialized
ERROR - 2018-05-17 03:04:44 --> 404 Page Not Found: /index
INFO - 2018-05-17 03:04:44 --> Config Class Initialized
INFO - 2018-05-17 03:04:44 --> Hooks Class Initialized
DEBUG - 2018-05-17 03:04:44 --> UTF-8 Support Enabled
INFO - 2018-05-17 03:04:44 --> Utf8 Class Initialized
INFO - 2018-05-17 03:04:44 --> URI Class Initialized
INFO - 2018-05-17 03:04:44 --> Router Class Initialized
INFO - 2018-05-17 03:04:44 --> Output Class Initialized
INFO - 2018-05-17 03:04:44 --> Security Class Initialized
DEBUG - 2018-05-17 03:04:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 03:04:44 --> Input Class Initialized
INFO - 2018-05-17 03:04:44 --> Language Class Initialized
ERROR - 2018-05-17 03:04:44 --> 404 Page Not Found: /index
INFO - 2018-05-17 03:04:54 --> Config Class Initialized
INFO - 2018-05-17 03:04:54 --> Hooks Class Initialized
DEBUG - 2018-05-17 03:04:54 --> UTF-8 Support Enabled
INFO - 2018-05-17 03:04:54 --> Utf8 Class Initialized
INFO - 2018-05-17 03:04:54 --> URI Class Initialized
INFO - 2018-05-17 03:04:54 --> Router Class Initialized
INFO - 2018-05-17 03:04:54 --> Output Class Initialized
INFO - 2018-05-17 03:04:54 --> Security Class Initialized
DEBUG - 2018-05-17 03:04:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 03:04:54 --> Input Class Initialized
INFO - 2018-05-17 03:04:54 --> Language Class Initialized
ERROR - 2018-05-17 03:04:54 --> 404 Page Not Found: /index
INFO - 2018-05-17 03:04:54 --> Config Class Initialized
INFO - 2018-05-17 03:04:54 --> Hooks Class Initialized
DEBUG - 2018-05-17 03:04:54 --> UTF-8 Support Enabled
INFO - 2018-05-17 03:04:54 --> Utf8 Class Initialized
INFO - 2018-05-17 03:04:54 --> URI Class Initialized
INFO - 2018-05-17 03:04:54 --> Router Class Initialized
INFO - 2018-05-17 03:04:54 --> Output Class Initialized
INFO - 2018-05-17 03:04:54 --> Security Class Initialized
DEBUG - 2018-05-17 03:04:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 03:04:54 --> Input Class Initialized
INFO - 2018-05-17 03:04:54 --> Language Class Initialized
ERROR - 2018-05-17 03:04:54 --> 404 Page Not Found: /index
INFO - 2018-05-17 03:04:54 --> Config Class Initialized
INFO - 2018-05-17 03:04:54 --> Hooks Class Initialized
DEBUG - 2018-05-17 03:04:54 --> UTF-8 Support Enabled
INFO - 2018-05-17 03:04:54 --> Utf8 Class Initialized
INFO - 2018-05-17 03:04:54 --> URI Class Initialized
INFO - 2018-05-17 03:04:54 --> Router Class Initialized
INFO - 2018-05-17 03:04:54 --> Output Class Initialized
INFO - 2018-05-17 03:04:54 --> Security Class Initialized
DEBUG - 2018-05-17 03:04:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 03:04:54 --> Input Class Initialized
INFO - 2018-05-17 03:04:54 --> Language Class Initialized
ERROR - 2018-05-17 03:04:54 --> 404 Page Not Found: /index
INFO - 2018-05-17 03:12:41 --> Config Class Initialized
INFO - 2018-05-17 03:12:41 --> Hooks Class Initialized
DEBUG - 2018-05-17 03:12:41 --> UTF-8 Support Enabled
INFO - 2018-05-17 03:12:41 --> Utf8 Class Initialized
INFO - 2018-05-17 03:12:41 --> URI Class Initialized
INFO - 2018-05-17 03:12:41 --> Router Class Initialized
INFO - 2018-05-17 03:12:41 --> Output Class Initialized
INFO - 2018-05-17 03:12:41 --> Security Class Initialized
DEBUG - 2018-05-17 03:12:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 03:12:41 --> Input Class Initialized
INFO - 2018-05-17 03:12:41 --> Language Class Initialized
INFO - 2018-05-17 03:12:41 --> Language Class Initialized
INFO - 2018-05-17 03:12:41 --> Config Class Initialized
INFO - 2018-05-17 03:12:41 --> Loader Class Initialized
DEBUG - 2018-05-17 03:12:41 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-17 03:12:41 --> Helper loaded: url_helper
INFO - 2018-05-17 03:12:41 --> Helper loaded: form_helper
INFO - 2018-05-17 03:12:41 --> Helper loaded: date_helper
INFO - 2018-05-17 03:12:41 --> Helper loaded: util_helper
INFO - 2018-05-17 03:12:41 --> Helper loaded: text_helper
INFO - 2018-05-17 03:12:41 --> Helper loaded: string_helper
INFO - 2018-05-17 03:12:41 --> Database Driver Class Initialized
DEBUG - 2018-05-17 03:12:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-17 03:12:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-17 03:12:41 --> Email Class Initialized
INFO - 2018-05-17 03:12:41 --> Controller Class Initialized
DEBUG - 2018-05-17 03:12:41 --> Home MX_Controller Initialized
DEBUG - 2018-05-17 03:12:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-17 03:12:41 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-17 03:12:41 --> Login MX_Controller Initialized
INFO - 2018-05-17 03:12:41 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-17 03:12:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-17 03:12:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-17 03:12:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-17 03:12:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-17 03:12:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
INFO - 2018-05-17 03:12:44 --> Config Class Initialized
INFO - 2018-05-17 03:12:44 --> Hooks Class Initialized
DEBUG - 2018-05-17 03:12:44 --> UTF-8 Support Enabled
INFO - 2018-05-17 03:12:44 --> Utf8 Class Initialized
INFO - 2018-05-17 03:12:44 --> URI Class Initialized
INFO - 2018-05-17 03:12:44 --> Router Class Initialized
INFO - 2018-05-17 03:12:44 --> Output Class Initialized
INFO - 2018-05-17 03:12:44 --> Security Class Initialized
DEBUG - 2018-05-17 03:12:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 03:12:44 --> Input Class Initialized
INFO - 2018-05-17 03:12:44 --> Language Class Initialized
ERROR - 2018-05-17 03:12:44 --> 404 Page Not Found: /index
INFO - 2018-05-17 03:12:44 --> Config Class Initialized
INFO - 2018-05-17 03:12:44 --> Hooks Class Initialized
DEBUG - 2018-05-17 03:12:44 --> UTF-8 Support Enabled
INFO - 2018-05-17 03:12:44 --> Utf8 Class Initialized
INFO - 2018-05-17 03:12:44 --> URI Class Initialized
INFO - 2018-05-17 03:12:44 --> Router Class Initialized
INFO - 2018-05-17 03:12:44 --> Output Class Initialized
INFO - 2018-05-17 03:12:44 --> Security Class Initialized
DEBUG - 2018-05-17 03:12:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 03:12:44 --> Input Class Initialized
INFO - 2018-05-17 03:12:44 --> Language Class Initialized
ERROR - 2018-05-17 03:12:44 --> 404 Page Not Found: /index
INFO - 2018-05-17 03:12:44 --> Config Class Initialized
INFO - 2018-05-17 03:12:44 --> Hooks Class Initialized
DEBUG - 2018-05-17 03:12:44 --> UTF-8 Support Enabled
INFO - 2018-05-17 03:12:44 --> Utf8 Class Initialized
INFO - 2018-05-17 03:12:44 --> URI Class Initialized
INFO - 2018-05-17 03:12:44 --> Router Class Initialized
INFO - 2018-05-17 03:12:44 --> Output Class Initialized
INFO - 2018-05-17 03:12:44 --> Security Class Initialized
DEBUG - 2018-05-17 03:12:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 03:12:44 --> Input Class Initialized
INFO - 2018-05-17 03:12:44 --> Language Class Initialized
ERROR - 2018-05-17 03:12:45 --> 404 Page Not Found: /index
INFO - 2018-05-17 03:12:52 --> Config Class Initialized
INFO - 2018-05-17 03:12:52 --> Hooks Class Initialized
DEBUG - 2018-05-17 03:12:52 --> UTF-8 Support Enabled
INFO - 2018-05-17 03:12:52 --> Utf8 Class Initialized
INFO - 2018-05-17 03:12:52 --> URI Class Initialized
INFO - 2018-05-17 03:12:52 --> Router Class Initialized
INFO - 2018-05-17 03:12:52 --> Output Class Initialized
INFO - 2018-05-17 03:12:52 --> Security Class Initialized
DEBUG - 2018-05-17 03:12:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 03:12:52 --> Input Class Initialized
INFO - 2018-05-17 03:12:52 --> Language Class Initialized
ERROR - 2018-05-17 03:12:52 --> 404 Page Not Found: /index
INFO - 2018-05-17 03:12:52 --> Config Class Initialized
INFO - 2018-05-17 03:12:52 --> Hooks Class Initialized
DEBUG - 2018-05-17 03:12:52 --> UTF-8 Support Enabled
INFO - 2018-05-17 03:12:52 --> Utf8 Class Initialized
INFO - 2018-05-17 03:12:52 --> URI Class Initialized
INFO - 2018-05-17 03:12:52 --> Router Class Initialized
INFO - 2018-05-17 03:12:52 --> Output Class Initialized
INFO - 2018-05-17 03:12:52 --> Security Class Initialized
DEBUG - 2018-05-17 03:12:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 03:12:52 --> Input Class Initialized
INFO - 2018-05-17 03:12:52 --> Language Class Initialized
ERROR - 2018-05-17 03:12:52 --> 404 Page Not Found: /index
INFO - 2018-05-17 03:12:52 --> Config Class Initialized
INFO - 2018-05-17 03:12:52 --> Hooks Class Initialized
DEBUG - 2018-05-17 03:12:52 --> UTF-8 Support Enabled
INFO - 2018-05-17 03:12:52 --> Utf8 Class Initialized
INFO - 2018-05-17 03:12:52 --> URI Class Initialized
INFO - 2018-05-17 03:12:52 --> Router Class Initialized
INFO - 2018-05-17 03:12:52 --> Output Class Initialized
INFO - 2018-05-17 03:12:52 --> Security Class Initialized
DEBUG - 2018-05-17 03:12:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 03:12:52 --> Input Class Initialized
INFO - 2018-05-17 03:12:52 --> Language Class Initialized
ERROR - 2018-05-17 03:12:52 --> 404 Page Not Found: /index
INFO - 2018-05-17 03:13:11 --> Config Class Initialized
INFO - 2018-05-17 03:13:11 --> Hooks Class Initialized
DEBUG - 2018-05-17 03:13:11 --> UTF-8 Support Enabled
INFO - 2018-05-17 03:13:11 --> Utf8 Class Initialized
INFO - 2018-05-17 03:13:11 --> URI Class Initialized
INFO - 2018-05-17 03:13:11 --> Router Class Initialized
INFO - 2018-05-17 03:13:11 --> Output Class Initialized
INFO - 2018-05-17 03:13:11 --> Security Class Initialized
DEBUG - 2018-05-17 03:13:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 03:13:11 --> Input Class Initialized
INFO - 2018-05-17 03:13:11 --> Language Class Initialized
INFO - 2018-05-17 03:13:11 --> Language Class Initialized
INFO - 2018-05-17 03:13:11 --> Config Class Initialized
INFO - 2018-05-17 03:13:11 --> Loader Class Initialized
DEBUG - 2018-05-17 03:13:11 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-17 03:13:11 --> Helper loaded: url_helper
INFO - 2018-05-17 03:13:11 --> Helper loaded: form_helper
INFO - 2018-05-17 03:13:11 --> Helper loaded: date_helper
INFO - 2018-05-17 03:13:11 --> Helper loaded: util_helper
INFO - 2018-05-17 03:13:11 --> Helper loaded: text_helper
INFO - 2018-05-17 03:13:11 --> Helper loaded: string_helper
INFO - 2018-05-17 03:13:11 --> Database Driver Class Initialized
DEBUG - 2018-05-17 03:13:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-17 03:13:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-17 03:13:11 --> Email Class Initialized
INFO - 2018-05-17 03:13:12 --> Controller Class Initialized
DEBUG - 2018-05-17 03:13:12 --> Home MX_Controller Initialized
DEBUG - 2018-05-17 03:13:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-17 03:13:12 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-17 03:13:12 --> Login MX_Controller Initialized
INFO - 2018-05-17 03:13:12 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-17 03:13:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-17 03:13:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-17 03:13:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-17 03:13:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-17 03:13:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-17 03:13:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-17 03:13:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-17 03:13:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-05-17 03:13:12 --> Final output sent to browser
DEBUG - 2018-05-17 03:13:12 --> Total execution time: 0.5399
INFO - 2018-05-17 03:13:13 --> Config Class Initialized
INFO - 2018-05-17 03:13:13 --> Hooks Class Initialized
INFO - 2018-05-17 03:13:13 --> Config Class Initialized
DEBUG - 2018-05-17 03:13:13 --> UTF-8 Support Enabled
INFO - 2018-05-17 03:13:13 --> Utf8 Class Initialized
INFO - 2018-05-17 03:13:13 --> URI Class Initialized
INFO - 2018-05-17 03:13:13 --> Router Class Initialized
INFO - 2018-05-17 03:13:13 --> Hooks Class Initialized
INFO - 2018-05-17 03:13:13 --> Output Class Initialized
INFO - 2018-05-17 03:13:13 --> Security Class Initialized
DEBUG - 2018-05-17 03:13:13 --> UTF-8 Support Enabled
INFO - 2018-05-17 03:13:13 --> Utf8 Class Initialized
DEBUG - 2018-05-17 03:13:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 03:13:13 --> Input Class Initialized
INFO - 2018-05-17 03:13:13 --> URI Class Initialized
INFO - 2018-05-17 03:13:13 --> Language Class Initialized
INFO - 2018-05-17 03:13:13 --> Router Class Initialized
ERROR - 2018-05-17 03:13:13 --> 404 Page Not Found: /index
INFO - 2018-05-17 03:13:13 --> Output Class Initialized
INFO - 2018-05-17 03:13:13 --> Security Class Initialized
DEBUG - 2018-05-17 03:13:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 03:13:13 --> Input Class Initialized
INFO - 2018-05-17 03:13:13 --> Language Class Initialized
ERROR - 2018-05-17 03:13:13 --> 404 Page Not Found: /index
INFO - 2018-05-17 03:13:13 --> Config Class Initialized
INFO - 2018-05-17 03:13:13 --> Hooks Class Initialized
DEBUG - 2018-05-17 03:13:13 --> UTF-8 Support Enabled
INFO - 2018-05-17 03:13:13 --> Utf8 Class Initialized
INFO - 2018-05-17 03:13:13 --> URI Class Initialized
INFO - 2018-05-17 03:13:13 --> Router Class Initialized
INFO - 2018-05-17 03:13:13 --> Output Class Initialized
INFO - 2018-05-17 03:13:13 --> Security Class Initialized
DEBUG - 2018-05-17 03:13:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 03:13:13 --> Input Class Initialized
INFO - 2018-05-17 03:13:13 --> Language Class Initialized
ERROR - 2018-05-17 03:13:13 --> 404 Page Not Found: /index
INFO - 2018-05-17 03:13:13 --> Config Class Initialized
INFO - 2018-05-17 03:13:13 --> Hooks Class Initialized
DEBUG - 2018-05-17 03:13:14 --> UTF-8 Support Enabled
INFO - 2018-05-17 03:13:14 --> Utf8 Class Initialized
INFO - 2018-05-17 03:13:14 --> URI Class Initialized
INFO - 2018-05-17 03:13:14 --> Router Class Initialized
INFO - 2018-05-17 03:13:14 --> Output Class Initialized
INFO - 2018-05-17 03:13:14 --> Security Class Initialized
DEBUG - 2018-05-17 03:13:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 03:13:14 --> Input Class Initialized
INFO - 2018-05-17 03:13:14 --> Language Class Initialized
ERROR - 2018-05-17 03:13:14 --> 404 Page Not Found: /index
INFO - 2018-05-17 03:13:17 --> Config Class Initialized
INFO - 2018-05-17 03:13:17 --> Hooks Class Initialized
DEBUG - 2018-05-17 03:13:17 --> UTF-8 Support Enabled
INFO - 2018-05-17 03:13:17 --> Utf8 Class Initialized
INFO - 2018-05-17 03:13:17 --> URI Class Initialized
INFO - 2018-05-17 03:13:17 --> Router Class Initialized
INFO - 2018-05-17 03:13:17 --> Output Class Initialized
INFO - 2018-05-17 03:13:17 --> Security Class Initialized
DEBUG - 2018-05-17 03:13:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 03:13:17 --> Input Class Initialized
INFO - 2018-05-17 03:13:17 --> Language Class Initialized
ERROR - 2018-05-17 03:13:17 --> 404 Page Not Found: /index
INFO - 2018-05-17 03:13:17 --> Config Class Initialized
INFO - 2018-05-17 03:13:17 --> Hooks Class Initialized
DEBUG - 2018-05-17 03:13:17 --> UTF-8 Support Enabled
INFO - 2018-05-17 03:13:17 --> Utf8 Class Initialized
INFO - 2018-05-17 03:13:17 --> URI Class Initialized
INFO - 2018-05-17 03:13:17 --> Router Class Initialized
INFO - 2018-05-17 03:13:17 --> Output Class Initialized
INFO - 2018-05-17 03:13:17 --> Security Class Initialized
DEBUG - 2018-05-17 03:13:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 03:13:17 --> Input Class Initialized
INFO - 2018-05-17 03:13:17 --> Language Class Initialized
ERROR - 2018-05-17 03:13:17 --> 404 Page Not Found: /index
INFO - 2018-05-17 03:13:17 --> Config Class Initialized
INFO - 2018-05-17 03:13:17 --> Hooks Class Initialized
DEBUG - 2018-05-17 03:13:17 --> UTF-8 Support Enabled
INFO - 2018-05-17 03:13:17 --> Utf8 Class Initialized
INFO - 2018-05-17 03:13:17 --> URI Class Initialized
INFO - 2018-05-17 03:13:17 --> Router Class Initialized
INFO - 2018-05-17 03:13:17 --> Output Class Initialized
INFO - 2018-05-17 03:13:17 --> Security Class Initialized
DEBUG - 2018-05-17 03:13:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 03:13:17 --> Input Class Initialized
INFO - 2018-05-17 03:13:17 --> Language Class Initialized
ERROR - 2018-05-17 03:13:17 --> 404 Page Not Found: /index
INFO - 2018-05-17 03:13:17 --> Config Class Initialized
INFO - 2018-05-17 03:13:17 --> Hooks Class Initialized
DEBUG - 2018-05-17 03:13:17 --> UTF-8 Support Enabled
INFO - 2018-05-17 03:13:17 --> Utf8 Class Initialized
INFO - 2018-05-17 03:13:17 --> URI Class Initialized
INFO - 2018-05-17 03:13:18 --> Router Class Initialized
INFO - 2018-05-17 03:13:18 --> Output Class Initialized
INFO - 2018-05-17 03:13:18 --> Security Class Initialized
DEBUG - 2018-05-17 03:13:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 03:13:18 --> Input Class Initialized
INFO - 2018-05-17 03:13:18 --> Language Class Initialized
INFO - 2018-05-17 03:13:18 --> Language Class Initialized
INFO - 2018-05-17 03:13:18 --> Config Class Initialized
INFO - 2018-05-17 03:13:18 --> Loader Class Initialized
DEBUG - 2018-05-17 03:13:18 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-17 03:13:18 --> Helper loaded: url_helper
INFO - 2018-05-17 03:13:18 --> Helper loaded: form_helper
INFO - 2018-05-17 03:13:18 --> Helper loaded: date_helper
INFO - 2018-05-17 03:13:18 --> Helper loaded: util_helper
INFO - 2018-05-17 03:13:18 --> Helper loaded: text_helper
INFO - 2018-05-17 03:13:18 --> Helper loaded: string_helper
INFO - 2018-05-17 03:13:18 --> Database Driver Class Initialized
DEBUG - 2018-05-17 03:13:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-17 03:13:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-17 03:13:18 --> Email Class Initialized
INFO - 2018-05-17 03:13:18 --> Controller Class Initialized
DEBUG - 2018-05-17 03:13:18 --> Home MX_Controller Initialized
DEBUG - 2018-05-17 03:13:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-17 03:13:18 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-17 03:13:18 --> Login MX_Controller Initialized
INFO - 2018-05-17 03:13:18 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-17 03:13:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-17 03:13:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-17 03:13:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-17 03:13:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-17 03:13:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-17 03:13:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-17 03:13:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-17 03:13:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-05-17 03:13:18 --> Final output sent to browser
DEBUG - 2018-05-17 03:13:18 --> Total execution time: 0.5696
INFO - 2018-05-17 03:13:18 --> Config Class Initialized
INFO - 2018-05-17 03:13:18 --> Config Class Initialized
INFO - 2018-05-17 03:13:19 --> Hooks Class Initialized
INFO - 2018-05-17 03:13:19 --> Hooks Class Initialized
DEBUG - 2018-05-17 03:13:19 --> UTF-8 Support Enabled
DEBUG - 2018-05-17 03:13:19 --> UTF-8 Support Enabled
INFO - 2018-05-17 03:13:19 --> Utf8 Class Initialized
INFO - 2018-05-17 03:13:19 --> URI Class Initialized
INFO - 2018-05-17 03:13:19 --> Router Class Initialized
INFO - 2018-05-17 03:13:19 --> Utf8 Class Initialized
INFO - 2018-05-17 03:13:19 --> Output Class Initialized
INFO - 2018-05-17 03:13:19 --> URI Class Initialized
INFO - 2018-05-17 03:13:19 --> Security Class Initialized
INFO - 2018-05-17 03:13:19 --> Router Class Initialized
DEBUG - 2018-05-17 03:13:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 03:13:19 --> Output Class Initialized
INFO - 2018-05-17 03:13:19 --> Input Class Initialized
INFO - 2018-05-17 03:13:19 --> Security Class Initialized
DEBUG - 2018-05-17 03:13:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 03:13:19 --> Language Class Initialized
INFO - 2018-05-17 03:13:19 --> Input Class Initialized
ERROR - 2018-05-17 03:13:19 --> 404 Page Not Found: /index
INFO - 2018-05-17 03:13:19 --> Language Class Initialized
ERROR - 2018-05-17 03:13:19 --> 404 Page Not Found: /index
INFO - 2018-05-17 03:13:19 --> Config Class Initialized
INFO - 2018-05-17 03:13:19 --> Hooks Class Initialized
DEBUG - 2018-05-17 03:13:19 --> UTF-8 Support Enabled
INFO - 2018-05-17 03:13:19 --> Utf8 Class Initialized
INFO - 2018-05-17 03:13:19 --> URI Class Initialized
INFO - 2018-05-17 03:13:19 --> Router Class Initialized
INFO - 2018-05-17 03:13:19 --> Output Class Initialized
INFO - 2018-05-17 03:13:19 --> Security Class Initialized
DEBUG - 2018-05-17 03:13:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 03:13:19 --> Input Class Initialized
INFO - 2018-05-17 03:13:19 --> Language Class Initialized
ERROR - 2018-05-17 03:13:19 --> 404 Page Not Found: /index
INFO - 2018-05-17 03:13:19 --> Config Class Initialized
INFO - 2018-05-17 03:13:19 --> Hooks Class Initialized
DEBUG - 2018-05-17 03:13:19 --> UTF-8 Support Enabled
INFO - 2018-05-17 03:13:19 --> Utf8 Class Initialized
INFO - 2018-05-17 03:13:19 --> URI Class Initialized
INFO - 2018-05-17 03:13:19 --> Router Class Initialized
INFO - 2018-05-17 03:13:20 --> Output Class Initialized
INFO - 2018-05-17 03:13:20 --> Security Class Initialized
DEBUG - 2018-05-17 03:13:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 03:13:20 --> Input Class Initialized
INFO - 2018-05-17 03:13:20 --> Language Class Initialized
ERROR - 2018-05-17 03:13:20 --> 404 Page Not Found: /index
INFO - 2018-05-17 03:13:22 --> Config Class Initialized
INFO - 2018-05-17 03:13:22 --> Hooks Class Initialized
DEBUG - 2018-05-17 03:13:22 --> UTF-8 Support Enabled
INFO - 2018-05-17 03:13:22 --> Utf8 Class Initialized
INFO - 2018-05-17 03:13:23 --> URI Class Initialized
INFO - 2018-05-17 03:13:23 --> Router Class Initialized
INFO - 2018-05-17 03:13:23 --> Output Class Initialized
INFO - 2018-05-17 03:13:23 --> Security Class Initialized
DEBUG - 2018-05-17 03:13:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 03:13:23 --> Input Class Initialized
INFO - 2018-05-17 03:13:23 --> Language Class Initialized
INFO - 2018-05-17 03:13:23 --> Language Class Initialized
INFO - 2018-05-17 03:13:23 --> Config Class Initialized
INFO - 2018-05-17 03:13:23 --> Loader Class Initialized
DEBUG - 2018-05-17 03:13:23 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-17 03:13:23 --> Helper loaded: url_helper
INFO - 2018-05-17 03:13:23 --> Helper loaded: form_helper
INFO - 2018-05-17 03:13:23 --> Helper loaded: date_helper
INFO - 2018-05-17 03:13:23 --> Helper loaded: util_helper
INFO - 2018-05-17 03:13:23 --> Helper loaded: text_helper
INFO - 2018-05-17 03:13:23 --> Helper loaded: string_helper
INFO - 2018-05-17 03:13:23 --> Database Driver Class Initialized
DEBUG - 2018-05-17 03:13:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-17 03:13:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-17 03:13:23 --> Email Class Initialized
INFO - 2018-05-17 03:13:23 --> Controller Class Initialized
DEBUG - 2018-05-17 03:13:23 --> Home MX_Controller Initialized
DEBUG - 2018-05-17 03:13:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-17 03:13:23 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-17 03:13:23 --> Login MX_Controller Initialized
INFO - 2018-05-17 03:13:23 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-17 03:13:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-17 03:13:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-17 03:13:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-17 03:13:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-17 03:13:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-17 03:13:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-17 03:13:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-17 03:13:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-05-17 03:13:23 --> Final output sent to browser
DEBUG - 2018-05-17 03:13:23 --> Total execution time: 0.5816
INFO - 2018-05-17 03:13:24 --> Config Class Initialized
INFO - 2018-05-17 03:13:24 --> Config Class Initialized
INFO - 2018-05-17 03:13:24 --> Hooks Class Initialized
INFO - 2018-05-17 03:13:24 --> Hooks Class Initialized
DEBUG - 2018-05-17 03:13:24 --> UTF-8 Support Enabled
DEBUG - 2018-05-17 03:13:24 --> UTF-8 Support Enabled
INFO - 2018-05-17 03:13:24 --> Utf8 Class Initialized
INFO - 2018-05-17 03:13:24 --> Utf8 Class Initialized
INFO - 2018-05-17 03:13:24 --> URI Class Initialized
INFO - 2018-05-17 03:13:24 --> URI Class Initialized
INFO - 2018-05-17 03:13:24 --> Router Class Initialized
INFO - 2018-05-17 03:13:24 --> Router Class Initialized
INFO - 2018-05-17 03:13:24 --> Output Class Initialized
INFO - 2018-05-17 03:13:24 --> Output Class Initialized
INFO - 2018-05-17 03:13:24 --> Security Class Initialized
DEBUG - 2018-05-17 03:13:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 03:13:24 --> Security Class Initialized
INFO - 2018-05-17 03:13:24 --> Input Class Initialized
INFO - 2018-05-17 03:13:24 --> Language Class Initialized
DEBUG - 2018-05-17 03:13:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-05-17 03:13:24 --> 404 Page Not Found: /index
INFO - 2018-05-17 03:13:24 --> Input Class Initialized
INFO - 2018-05-17 03:13:24 --> Language Class Initialized
INFO - 2018-05-17 03:13:24 --> Config Class Initialized
INFO - 2018-05-17 03:13:24 --> Hooks Class Initialized
ERROR - 2018-05-17 03:13:24 --> 404 Page Not Found: /index
DEBUG - 2018-05-17 03:13:24 --> UTF-8 Support Enabled
INFO - 2018-05-17 03:13:24 --> Utf8 Class Initialized
INFO - 2018-05-17 03:13:24 --> URI Class Initialized
INFO - 2018-05-17 03:13:24 --> Router Class Initialized
INFO - 2018-05-17 03:13:24 --> Output Class Initialized
INFO - 2018-05-17 03:13:24 --> Security Class Initialized
DEBUG - 2018-05-17 03:13:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 03:13:24 --> Input Class Initialized
INFO - 2018-05-17 03:13:24 --> Language Class Initialized
ERROR - 2018-05-17 03:13:24 --> 404 Page Not Found: /index
INFO - 2018-05-17 03:13:24 --> Config Class Initialized
INFO - 2018-05-17 03:13:24 --> Hooks Class Initialized
DEBUG - 2018-05-17 03:13:24 --> UTF-8 Support Enabled
INFO - 2018-05-17 03:13:24 --> Utf8 Class Initialized
INFO - 2018-05-17 03:13:24 --> URI Class Initialized
INFO - 2018-05-17 03:13:25 --> Router Class Initialized
INFO - 2018-05-17 03:13:25 --> Output Class Initialized
INFO - 2018-05-17 03:13:25 --> Security Class Initialized
DEBUG - 2018-05-17 03:13:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 03:13:25 --> Input Class Initialized
INFO - 2018-05-17 03:13:25 --> Language Class Initialized
ERROR - 2018-05-17 03:13:25 --> 404 Page Not Found: /index
INFO - 2018-05-17 03:14:05 --> Config Class Initialized
INFO - 2018-05-17 03:14:05 --> Hooks Class Initialized
DEBUG - 2018-05-17 03:14:05 --> UTF-8 Support Enabled
INFO - 2018-05-17 03:14:05 --> Utf8 Class Initialized
INFO - 2018-05-17 03:14:05 --> URI Class Initialized
INFO - 2018-05-17 03:14:05 --> Router Class Initialized
INFO - 2018-05-17 03:14:05 --> Output Class Initialized
INFO - 2018-05-17 03:14:05 --> Security Class Initialized
DEBUG - 2018-05-17 03:14:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 03:14:05 --> Input Class Initialized
INFO - 2018-05-17 03:14:05 --> Language Class Initialized
INFO - 2018-05-17 03:14:05 --> Language Class Initialized
INFO - 2018-05-17 03:14:05 --> Config Class Initialized
INFO - 2018-05-17 03:14:05 --> Loader Class Initialized
DEBUG - 2018-05-17 03:14:05 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-17 03:14:06 --> Helper loaded: url_helper
INFO - 2018-05-17 03:14:06 --> Helper loaded: form_helper
INFO - 2018-05-17 03:14:06 --> Helper loaded: date_helper
INFO - 2018-05-17 03:14:06 --> Helper loaded: util_helper
INFO - 2018-05-17 03:14:06 --> Helper loaded: text_helper
INFO - 2018-05-17 03:14:06 --> Helper loaded: string_helper
INFO - 2018-05-17 03:14:06 --> Database Driver Class Initialized
DEBUG - 2018-05-17 03:14:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-17 03:14:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-17 03:14:06 --> Email Class Initialized
INFO - 2018-05-17 03:14:06 --> Controller Class Initialized
DEBUG - 2018-05-17 03:14:06 --> Home MX_Controller Initialized
DEBUG - 2018-05-17 03:14:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-17 03:14:06 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-17 03:14:06 --> Login MX_Controller Initialized
INFO - 2018-05-17 03:14:06 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-17 03:14:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-17 03:14:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-17 03:14:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-17 03:14:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-17 03:14:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
INFO - 2018-05-17 03:14:07 --> Config Class Initialized
INFO - 2018-05-17 03:14:07 --> Hooks Class Initialized
DEBUG - 2018-05-17 03:14:07 --> UTF-8 Support Enabled
INFO - 2018-05-17 03:14:07 --> Utf8 Class Initialized
INFO - 2018-05-17 03:14:07 --> URI Class Initialized
INFO - 2018-05-17 03:14:07 --> Router Class Initialized
INFO - 2018-05-17 03:14:07 --> Output Class Initialized
INFO - 2018-05-17 03:14:07 --> Security Class Initialized
DEBUG - 2018-05-17 03:14:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 03:14:07 --> Input Class Initialized
INFO - 2018-05-17 03:14:07 --> Language Class Initialized
ERROR - 2018-05-17 03:14:07 --> 404 Page Not Found: /index
INFO - 2018-05-17 03:14:07 --> Config Class Initialized
INFO - 2018-05-17 03:14:07 --> Hooks Class Initialized
DEBUG - 2018-05-17 03:14:07 --> UTF-8 Support Enabled
INFO - 2018-05-17 03:14:07 --> Utf8 Class Initialized
INFO - 2018-05-17 03:14:07 --> URI Class Initialized
INFO - 2018-05-17 03:14:07 --> Router Class Initialized
INFO - 2018-05-17 03:14:07 --> Output Class Initialized
INFO - 2018-05-17 03:14:07 --> Security Class Initialized
DEBUG - 2018-05-17 03:14:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 03:14:07 --> Input Class Initialized
INFO - 2018-05-17 03:14:07 --> Language Class Initialized
ERROR - 2018-05-17 03:14:07 --> 404 Page Not Found: /index
INFO - 2018-05-17 03:14:07 --> Config Class Initialized
INFO - 2018-05-17 03:14:07 --> Hooks Class Initialized
DEBUG - 2018-05-17 03:14:07 --> UTF-8 Support Enabled
INFO - 2018-05-17 03:14:07 --> Utf8 Class Initialized
INFO - 2018-05-17 03:14:07 --> URI Class Initialized
INFO - 2018-05-17 03:14:07 --> Router Class Initialized
INFO - 2018-05-17 03:14:07 --> Output Class Initialized
INFO - 2018-05-17 03:14:07 --> Security Class Initialized
DEBUG - 2018-05-17 03:14:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 03:14:07 --> Input Class Initialized
INFO - 2018-05-17 03:14:07 --> Language Class Initialized
ERROR - 2018-05-17 03:14:07 --> 404 Page Not Found: /index
INFO - 2018-05-17 03:14:10 --> Config Class Initialized
INFO - 2018-05-17 03:14:10 --> Hooks Class Initialized
DEBUG - 2018-05-17 03:14:10 --> UTF-8 Support Enabled
INFO - 2018-05-17 03:14:10 --> Utf8 Class Initialized
INFO - 2018-05-17 03:14:10 --> URI Class Initialized
INFO - 2018-05-17 03:14:10 --> Router Class Initialized
INFO - 2018-05-17 03:14:10 --> Output Class Initialized
INFO - 2018-05-17 03:14:10 --> Security Class Initialized
DEBUG - 2018-05-17 03:14:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 03:14:10 --> Input Class Initialized
INFO - 2018-05-17 03:14:10 --> Language Class Initialized
ERROR - 2018-05-17 03:14:10 --> 404 Page Not Found: /index
INFO - 2018-05-17 03:14:10 --> Config Class Initialized
INFO - 2018-05-17 03:14:10 --> Hooks Class Initialized
DEBUG - 2018-05-17 03:14:10 --> UTF-8 Support Enabled
INFO - 2018-05-17 03:14:10 --> Utf8 Class Initialized
INFO - 2018-05-17 03:14:10 --> URI Class Initialized
INFO - 2018-05-17 03:14:10 --> Router Class Initialized
INFO - 2018-05-17 03:14:10 --> Output Class Initialized
INFO - 2018-05-17 03:14:10 --> Security Class Initialized
DEBUG - 2018-05-17 03:14:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 03:14:10 --> Input Class Initialized
INFO - 2018-05-17 03:14:10 --> Language Class Initialized
ERROR - 2018-05-17 03:14:10 --> 404 Page Not Found: /index
INFO - 2018-05-17 03:14:10 --> Config Class Initialized
INFO - 2018-05-17 03:14:10 --> Hooks Class Initialized
DEBUG - 2018-05-17 03:14:10 --> UTF-8 Support Enabled
INFO - 2018-05-17 03:14:10 --> Utf8 Class Initialized
INFO - 2018-05-17 03:14:10 --> URI Class Initialized
INFO - 2018-05-17 03:14:10 --> Router Class Initialized
INFO - 2018-05-17 03:14:10 --> Output Class Initialized
INFO - 2018-05-17 03:14:10 --> Security Class Initialized
DEBUG - 2018-05-17 03:14:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 03:14:10 --> Input Class Initialized
INFO - 2018-05-17 03:14:10 --> Language Class Initialized
ERROR - 2018-05-17 03:14:10 --> 404 Page Not Found: /index
INFO - 2018-05-17 03:14:37 --> Config Class Initialized
INFO - 2018-05-17 03:14:37 --> Hooks Class Initialized
DEBUG - 2018-05-17 03:14:37 --> UTF-8 Support Enabled
INFO - 2018-05-17 03:14:37 --> Utf8 Class Initialized
INFO - 2018-05-17 03:14:37 --> URI Class Initialized
INFO - 2018-05-17 03:14:37 --> Router Class Initialized
INFO - 2018-05-17 03:14:37 --> Output Class Initialized
INFO - 2018-05-17 03:14:37 --> Security Class Initialized
DEBUG - 2018-05-17 03:14:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 03:14:37 --> Input Class Initialized
INFO - 2018-05-17 03:14:37 --> Language Class Initialized
INFO - 2018-05-17 03:14:37 --> Language Class Initialized
INFO - 2018-05-17 03:14:38 --> Config Class Initialized
INFO - 2018-05-17 03:14:38 --> Loader Class Initialized
DEBUG - 2018-05-17 03:14:38 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-17 03:14:38 --> Helper loaded: url_helper
INFO - 2018-05-17 03:14:38 --> Helper loaded: form_helper
INFO - 2018-05-17 03:14:38 --> Helper loaded: date_helper
INFO - 2018-05-17 03:14:38 --> Helper loaded: util_helper
INFO - 2018-05-17 03:14:38 --> Helper loaded: text_helper
INFO - 2018-05-17 03:14:38 --> Helper loaded: string_helper
INFO - 2018-05-17 03:14:38 --> Database Driver Class Initialized
DEBUG - 2018-05-17 03:14:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-17 03:14:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-17 03:14:38 --> Email Class Initialized
INFO - 2018-05-17 03:14:38 --> Controller Class Initialized
DEBUG - 2018-05-17 03:14:38 --> Home MX_Controller Initialized
DEBUG - 2018-05-17 03:14:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-17 03:14:38 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-17 03:14:38 --> Login MX_Controller Initialized
INFO - 2018-05-17 03:14:38 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-17 03:14:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-17 03:14:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-17 03:14:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-17 03:14:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-17 03:14:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-17 03:14:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-17 03:14:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-17 03:14:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-05-17 03:14:38 --> Final output sent to browser
DEBUG - 2018-05-17 03:14:38 --> Total execution time: 0.5476
INFO - 2018-05-17 03:14:39 --> Config Class Initialized
INFO - 2018-05-17 03:14:39 --> Hooks Class Initialized
DEBUG - 2018-05-17 03:14:39 --> UTF-8 Support Enabled
INFO - 2018-05-17 03:14:39 --> Config Class Initialized
INFO - 2018-05-17 03:14:39 --> Utf8 Class Initialized
INFO - 2018-05-17 03:14:39 --> URI Class Initialized
INFO - 2018-05-17 03:14:39 --> Hooks Class Initialized
INFO - 2018-05-17 03:14:39 --> Router Class Initialized
INFO - 2018-05-17 03:14:39 --> Output Class Initialized
DEBUG - 2018-05-17 03:14:39 --> UTF-8 Support Enabled
INFO - 2018-05-17 03:14:39 --> Utf8 Class Initialized
INFO - 2018-05-17 03:14:39 --> Security Class Initialized
INFO - 2018-05-17 03:14:39 --> URI Class Initialized
DEBUG - 2018-05-17 03:14:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 03:14:39 --> Input Class Initialized
INFO - 2018-05-17 03:14:39 --> Router Class Initialized
INFO - 2018-05-17 03:14:39 --> Output Class Initialized
INFO - 2018-05-17 03:14:39 --> Language Class Initialized
INFO - 2018-05-17 03:14:39 --> Security Class Initialized
ERROR - 2018-05-17 03:14:39 --> 404 Page Not Found: /index
DEBUG - 2018-05-17 03:14:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 03:14:39 --> Input Class Initialized
INFO - 2018-05-17 03:14:39 --> Language Class Initialized
ERROR - 2018-05-17 03:14:39 --> 404 Page Not Found: /index
INFO - 2018-05-17 03:14:39 --> Config Class Initialized
INFO - 2018-05-17 03:14:39 --> Hooks Class Initialized
DEBUG - 2018-05-17 03:14:39 --> UTF-8 Support Enabled
INFO - 2018-05-17 03:14:39 --> Utf8 Class Initialized
INFO - 2018-05-17 03:14:39 --> URI Class Initialized
INFO - 2018-05-17 03:14:39 --> Router Class Initialized
INFO - 2018-05-17 03:14:39 --> Output Class Initialized
INFO - 2018-05-17 03:14:39 --> Security Class Initialized
DEBUG - 2018-05-17 03:14:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 03:14:40 --> Input Class Initialized
INFO - 2018-05-17 03:14:40 --> Language Class Initialized
ERROR - 2018-05-17 03:14:40 --> 404 Page Not Found: /index
INFO - 2018-05-17 03:14:40 --> Config Class Initialized
INFO - 2018-05-17 03:14:40 --> Hooks Class Initialized
DEBUG - 2018-05-17 03:14:40 --> UTF-8 Support Enabled
INFO - 2018-05-17 03:14:40 --> Utf8 Class Initialized
INFO - 2018-05-17 03:14:40 --> URI Class Initialized
INFO - 2018-05-17 03:14:40 --> Router Class Initialized
INFO - 2018-05-17 03:14:40 --> Output Class Initialized
INFO - 2018-05-17 03:14:40 --> Security Class Initialized
DEBUG - 2018-05-17 03:14:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 03:14:40 --> Input Class Initialized
INFO - 2018-05-17 03:14:40 --> Language Class Initialized
ERROR - 2018-05-17 03:14:40 --> 404 Page Not Found: /index
INFO - 2018-05-17 03:14:43 --> Config Class Initialized
INFO - 2018-05-17 03:14:43 --> Hooks Class Initialized
DEBUG - 2018-05-17 03:14:43 --> UTF-8 Support Enabled
INFO - 2018-05-17 03:14:43 --> Utf8 Class Initialized
INFO - 2018-05-17 03:14:43 --> URI Class Initialized
INFO - 2018-05-17 03:14:43 --> Router Class Initialized
INFO - 2018-05-17 03:14:43 --> Output Class Initialized
INFO - 2018-05-17 03:14:43 --> Security Class Initialized
DEBUG - 2018-05-17 03:14:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 03:14:43 --> Input Class Initialized
INFO - 2018-05-17 03:14:43 --> Language Class Initialized
INFO - 2018-05-17 03:14:43 --> Language Class Initialized
INFO - 2018-05-17 03:14:43 --> Config Class Initialized
INFO - 2018-05-17 03:14:43 --> Loader Class Initialized
DEBUG - 2018-05-17 03:14:43 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-17 03:14:43 --> Helper loaded: url_helper
INFO - 2018-05-17 03:14:43 --> Helper loaded: form_helper
INFO - 2018-05-17 03:14:43 --> Helper loaded: date_helper
INFO - 2018-05-17 03:14:43 --> Helper loaded: util_helper
INFO - 2018-05-17 03:14:43 --> Helper loaded: text_helper
INFO - 2018-05-17 03:14:43 --> Helper loaded: string_helper
INFO - 2018-05-17 03:14:43 --> Database Driver Class Initialized
DEBUG - 2018-05-17 03:14:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-17 03:14:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-17 03:14:44 --> Email Class Initialized
INFO - 2018-05-17 03:14:44 --> Controller Class Initialized
DEBUG - 2018-05-17 03:14:44 --> Home MX_Controller Initialized
DEBUG - 2018-05-17 03:14:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-17 03:14:44 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-17 03:14:44 --> Login MX_Controller Initialized
INFO - 2018-05-17 03:14:44 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-17 03:14:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-17 03:14:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-17 03:14:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-17 03:14:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-17 03:14:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-17 03:14:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-17 03:14:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-17 03:14:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-05-17 03:14:44 --> Final output sent to browser
DEBUG - 2018-05-17 03:14:44 --> Total execution time: 0.5869
INFO - 2018-05-17 03:14:44 --> Config Class Initialized
INFO - 2018-05-17 03:14:44 --> Config Class Initialized
INFO - 2018-05-17 03:14:44 --> Hooks Class Initialized
INFO - 2018-05-17 03:14:44 --> Hooks Class Initialized
DEBUG - 2018-05-17 03:14:44 --> UTF-8 Support Enabled
DEBUG - 2018-05-17 03:14:44 --> UTF-8 Support Enabled
INFO - 2018-05-17 03:14:44 --> Utf8 Class Initialized
INFO - 2018-05-17 03:14:44 --> Utf8 Class Initialized
INFO - 2018-05-17 03:14:44 --> URI Class Initialized
INFO - 2018-05-17 03:14:44 --> URI Class Initialized
INFO - 2018-05-17 03:14:44 --> Router Class Initialized
INFO - 2018-05-17 03:14:44 --> Output Class Initialized
INFO - 2018-05-17 03:14:44 --> Router Class Initialized
INFO - 2018-05-17 03:14:44 --> Output Class Initialized
INFO - 2018-05-17 03:14:44 --> Security Class Initialized
INFO - 2018-05-17 03:14:44 --> Security Class Initialized
DEBUG - 2018-05-17 03:14:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 03:14:45 --> Input Class Initialized
INFO - 2018-05-17 03:14:45 --> Language Class Initialized
DEBUG - 2018-05-17 03:14:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 03:14:45 --> Input Class Initialized
ERROR - 2018-05-17 03:14:45 --> 404 Page Not Found: /index
INFO - 2018-05-17 03:14:45 --> Language Class Initialized
ERROR - 2018-05-17 03:14:45 --> 404 Page Not Found: /index
INFO - 2018-05-17 03:14:45 --> Config Class Initialized
INFO - 2018-05-17 03:14:45 --> Hooks Class Initialized
DEBUG - 2018-05-17 03:14:45 --> UTF-8 Support Enabled
INFO - 2018-05-17 03:14:45 --> Utf8 Class Initialized
INFO - 2018-05-17 03:14:45 --> URI Class Initialized
INFO - 2018-05-17 03:14:45 --> Router Class Initialized
INFO - 2018-05-17 03:14:45 --> Output Class Initialized
INFO - 2018-05-17 03:14:45 --> Security Class Initialized
DEBUG - 2018-05-17 03:14:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 03:14:45 --> Input Class Initialized
INFO - 2018-05-17 03:14:45 --> Language Class Initialized
ERROR - 2018-05-17 03:14:45 --> 404 Page Not Found: /index
INFO - 2018-05-17 03:14:45 --> Config Class Initialized
INFO - 2018-05-17 03:14:45 --> Hooks Class Initialized
DEBUG - 2018-05-17 03:14:45 --> UTF-8 Support Enabled
INFO - 2018-05-17 03:14:45 --> Utf8 Class Initialized
INFO - 2018-05-17 03:14:45 --> URI Class Initialized
INFO - 2018-05-17 03:14:45 --> Router Class Initialized
INFO - 2018-05-17 03:14:45 --> Output Class Initialized
INFO - 2018-05-17 03:14:45 --> Security Class Initialized
DEBUG - 2018-05-17 03:14:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 03:14:45 --> Input Class Initialized
INFO - 2018-05-17 03:14:45 --> Language Class Initialized
ERROR - 2018-05-17 03:14:45 --> 404 Page Not Found: /index
INFO - 2018-05-17 03:14:48 --> Config Class Initialized
INFO - 2018-05-17 03:14:48 --> Hooks Class Initialized
DEBUG - 2018-05-17 03:14:48 --> UTF-8 Support Enabled
INFO - 2018-05-17 03:14:48 --> Utf8 Class Initialized
INFO - 2018-05-17 03:14:48 --> URI Class Initialized
INFO - 2018-05-17 03:14:48 --> Router Class Initialized
INFO - 2018-05-17 03:14:48 --> Output Class Initialized
INFO - 2018-05-17 03:14:48 --> Security Class Initialized
DEBUG - 2018-05-17 03:14:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 03:14:48 --> Input Class Initialized
INFO - 2018-05-17 03:14:48 --> Language Class Initialized
ERROR - 2018-05-17 03:14:48 --> 404 Page Not Found: /index
INFO - 2018-05-17 03:14:48 --> Config Class Initialized
INFO - 2018-05-17 03:14:48 --> Hooks Class Initialized
DEBUG - 2018-05-17 03:14:48 --> UTF-8 Support Enabled
INFO - 2018-05-17 03:14:48 --> Utf8 Class Initialized
INFO - 2018-05-17 03:14:48 --> URI Class Initialized
INFO - 2018-05-17 03:14:48 --> Router Class Initialized
INFO - 2018-05-17 03:14:48 --> Output Class Initialized
INFO - 2018-05-17 03:14:48 --> Security Class Initialized
DEBUG - 2018-05-17 03:14:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 03:14:48 --> Input Class Initialized
INFO - 2018-05-17 03:14:48 --> Language Class Initialized
ERROR - 2018-05-17 03:14:48 --> 404 Page Not Found: /index
INFO - 2018-05-17 03:14:48 --> Config Class Initialized
INFO - 2018-05-17 03:14:48 --> Hooks Class Initialized
DEBUG - 2018-05-17 03:14:48 --> UTF-8 Support Enabled
INFO - 2018-05-17 03:14:48 --> Utf8 Class Initialized
INFO - 2018-05-17 03:14:48 --> URI Class Initialized
INFO - 2018-05-17 03:14:48 --> Router Class Initialized
INFO - 2018-05-17 03:14:48 --> Output Class Initialized
INFO - 2018-05-17 03:14:48 --> Security Class Initialized
DEBUG - 2018-05-17 03:14:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 03:14:48 --> Input Class Initialized
INFO - 2018-05-17 03:14:48 --> Language Class Initialized
ERROR - 2018-05-17 03:14:48 --> 404 Page Not Found: /index
INFO - 2018-05-17 03:15:34 --> Config Class Initialized
INFO - 2018-05-17 03:15:35 --> Hooks Class Initialized
DEBUG - 2018-05-17 03:15:35 --> UTF-8 Support Enabled
INFO - 2018-05-17 03:15:35 --> Utf8 Class Initialized
INFO - 2018-05-17 03:15:35 --> URI Class Initialized
INFO - 2018-05-17 03:15:35 --> Router Class Initialized
INFO - 2018-05-17 03:15:35 --> Output Class Initialized
INFO - 2018-05-17 03:15:35 --> Security Class Initialized
DEBUG - 2018-05-17 03:15:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 03:15:35 --> Input Class Initialized
INFO - 2018-05-17 03:15:35 --> Language Class Initialized
INFO - 2018-05-17 03:15:35 --> Language Class Initialized
INFO - 2018-05-17 03:15:35 --> Config Class Initialized
INFO - 2018-05-17 03:15:35 --> Loader Class Initialized
DEBUG - 2018-05-17 03:15:35 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-17 03:15:35 --> Helper loaded: url_helper
INFO - 2018-05-17 03:15:35 --> Helper loaded: form_helper
INFO - 2018-05-17 03:15:35 --> Helper loaded: date_helper
INFO - 2018-05-17 03:15:35 --> Helper loaded: util_helper
INFO - 2018-05-17 03:15:35 --> Helper loaded: text_helper
INFO - 2018-05-17 03:15:35 --> Helper loaded: string_helper
INFO - 2018-05-17 03:15:35 --> Database Driver Class Initialized
DEBUG - 2018-05-17 03:15:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-17 03:15:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-17 03:15:35 --> Email Class Initialized
INFO - 2018-05-17 03:15:35 --> Controller Class Initialized
DEBUG - 2018-05-17 03:15:35 --> Home MX_Controller Initialized
DEBUG - 2018-05-17 03:15:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-17 03:15:35 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-17 03:15:35 --> Login MX_Controller Initialized
INFO - 2018-05-17 03:15:35 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-17 03:15:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-17 03:15:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-17 03:15:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-17 03:15:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-17 03:15:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-17 03:15:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-17 03:15:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-17 03:15:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-05-17 03:15:35 --> Final output sent to browser
DEBUG - 2018-05-17 03:15:35 --> Total execution time: 0.5564
INFO - 2018-05-17 03:15:36 --> Config Class Initialized
INFO - 2018-05-17 03:15:36 --> Hooks Class Initialized
DEBUG - 2018-05-17 03:15:36 --> UTF-8 Support Enabled
INFO - 2018-05-17 03:15:36 --> Utf8 Class Initialized
INFO - 2018-05-17 03:15:36 --> Config Class Initialized
INFO - 2018-05-17 03:15:36 --> URI Class Initialized
INFO - 2018-05-17 03:15:36 --> Hooks Class Initialized
INFO - 2018-05-17 03:15:36 --> Router Class Initialized
DEBUG - 2018-05-17 03:15:36 --> UTF-8 Support Enabled
INFO - 2018-05-17 03:15:36 --> Utf8 Class Initialized
INFO - 2018-05-17 03:15:36 --> Output Class Initialized
INFO - 2018-05-17 03:15:36 --> URI Class Initialized
INFO - 2018-05-17 03:15:36 --> Security Class Initialized
INFO - 2018-05-17 03:15:36 --> Router Class Initialized
INFO - 2018-05-17 03:15:36 --> Output Class Initialized
INFO - 2018-05-17 03:15:36 --> Security Class Initialized
DEBUG - 2018-05-17 03:15:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-17 03:15:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 03:15:36 --> Input Class Initialized
INFO - 2018-05-17 03:15:36 --> Input Class Initialized
INFO - 2018-05-17 03:15:36 --> Language Class Initialized
ERROR - 2018-05-17 03:15:36 --> 404 Page Not Found: /index
INFO - 2018-05-17 03:15:36 --> Language Class Initialized
ERROR - 2018-05-17 03:15:36 --> 404 Page Not Found: /index
INFO - 2018-05-17 03:15:36 --> Config Class Initialized
INFO - 2018-05-17 03:15:36 --> Hooks Class Initialized
DEBUG - 2018-05-17 03:15:36 --> UTF-8 Support Enabled
INFO - 2018-05-17 03:15:37 --> Utf8 Class Initialized
INFO - 2018-05-17 03:15:37 --> URI Class Initialized
INFO - 2018-05-17 03:15:37 --> Router Class Initialized
INFO - 2018-05-17 03:15:37 --> Output Class Initialized
INFO - 2018-05-17 03:15:37 --> Security Class Initialized
DEBUG - 2018-05-17 03:15:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 03:15:37 --> Input Class Initialized
INFO - 2018-05-17 03:15:37 --> Language Class Initialized
ERROR - 2018-05-17 03:15:37 --> 404 Page Not Found: /index
INFO - 2018-05-17 03:15:37 --> Config Class Initialized
INFO - 2018-05-17 03:15:37 --> Hooks Class Initialized
DEBUG - 2018-05-17 03:15:37 --> UTF-8 Support Enabled
INFO - 2018-05-17 03:15:37 --> Utf8 Class Initialized
INFO - 2018-05-17 03:15:37 --> URI Class Initialized
INFO - 2018-05-17 03:15:37 --> Router Class Initialized
INFO - 2018-05-17 03:15:37 --> Output Class Initialized
INFO - 2018-05-17 03:15:37 --> Security Class Initialized
DEBUG - 2018-05-17 03:15:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 03:15:37 --> Input Class Initialized
INFO - 2018-05-17 03:15:37 --> Language Class Initialized
ERROR - 2018-05-17 03:15:37 --> 404 Page Not Found: /index
INFO - 2018-05-17 03:15:40 --> Config Class Initialized
INFO - 2018-05-17 03:15:40 --> Hooks Class Initialized
DEBUG - 2018-05-17 03:15:40 --> UTF-8 Support Enabled
INFO - 2018-05-17 03:15:40 --> Utf8 Class Initialized
INFO - 2018-05-17 03:15:40 --> Config Class Initialized
INFO - 2018-05-17 03:15:40 --> Hooks Class Initialized
INFO - 2018-05-17 03:15:40 --> URI Class Initialized
DEBUG - 2018-05-17 03:15:40 --> UTF-8 Support Enabled
INFO - 2018-05-17 03:15:40 --> Router Class Initialized
INFO - 2018-05-17 03:15:40 --> Utf8 Class Initialized
INFO - 2018-05-17 03:15:40 --> URI Class Initialized
INFO - 2018-05-17 03:15:40 --> Router Class Initialized
INFO - 2018-05-17 03:15:40 --> Output Class Initialized
INFO - 2018-05-17 03:15:40 --> Output Class Initialized
INFO - 2018-05-17 03:15:40 --> Security Class Initialized
DEBUG - 2018-05-17 03:15:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 03:15:40 --> Input Class Initialized
INFO - 2018-05-17 03:15:40 --> Language Class Initialized
INFO - 2018-05-17 03:15:40 --> Language Class Initialized
INFO - 2018-05-17 03:15:40 --> Config Class Initialized
INFO - 2018-05-17 03:15:40 --> Loader Class Initialized
INFO - 2018-05-17 03:15:40 --> Security Class Initialized
DEBUG - 2018-05-17 03:15:40 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-17 03:15:40 --> Helper loaded: url_helper
INFO - 2018-05-17 03:15:40 --> Helper loaded: form_helper
INFO - 2018-05-17 03:15:40 --> Helper loaded: date_helper
INFO - 2018-05-17 03:15:40 --> Helper loaded: util_helper
INFO - 2018-05-17 03:15:40 --> Helper loaded: text_helper
INFO - 2018-05-17 03:15:40 --> Helper loaded: string_helper
DEBUG - 2018-05-17 03:15:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 03:15:40 --> Database Driver Class Initialized
INFO - 2018-05-17 03:15:40 --> Input Class Initialized
DEBUG - 2018-05-17 03:15:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-17 03:15:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-17 03:15:40 --> Language Class Initialized
INFO - 2018-05-17 03:15:40 --> Email Class Initialized
ERROR - 2018-05-17 03:15:40 --> 404 Page Not Found: /index
INFO - 2018-05-17 03:15:40 --> Controller Class Initialized
DEBUG - 2018-05-17 03:15:40 --> Home MX_Controller Initialized
DEBUG - 2018-05-17 03:15:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-17 03:15:40 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
INFO - 2018-05-17 03:15:40 --> Config Class Initialized
DEBUG - 2018-05-17 03:15:40 --> Login MX_Controller Initialized
INFO - 2018-05-17 03:15:40 --> Hooks Class Initialized
INFO - 2018-05-17 03:15:40 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-17 03:15:40 --> UTF-8 Support Enabled
INFO - 2018-05-17 03:15:40 --> Utf8 Class Initialized
DEBUG - 2018-05-17 03:15:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-17 03:15:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-17 03:15:40 --> URI Class Initialized
INFO - 2018-05-17 03:15:40 --> Router Class Initialized
DEBUG - 2018-05-17 03:15:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-17 03:15:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
INFO - 2018-05-17 03:15:40 --> Output Class Initialized
DEBUG - 2018-05-17 03:15:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
INFO - 2018-05-17 03:15:40 --> Security Class Initialized
DEBUG - 2018-05-17 03:15:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-17 03:15:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-17 03:15:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-05-17 03:15:40 --> Final output sent to browser
INFO - 2018-05-17 03:15:40 --> Config Class Initialized
INFO - 2018-05-17 03:15:40 --> Hooks Class Initialized
DEBUG - 2018-05-17 03:15:40 --> Total execution time: 0.5618
DEBUG - 2018-05-17 03:15:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-17 03:15:41 --> UTF-8 Support Enabled
INFO - 2018-05-17 03:15:41 --> Utf8 Class Initialized
INFO - 2018-05-17 03:15:41 --> Input Class Initialized
INFO - 2018-05-17 03:15:41 --> URI Class Initialized
INFO - 2018-05-17 03:15:41 --> Router Class Initialized
INFO - 2018-05-17 03:15:41 --> Language Class Initialized
INFO - 2018-05-17 03:15:41 --> Output Class Initialized
INFO - 2018-05-17 03:15:41 --> Security Class Initialized
ERROR - 2018-05-17 03:15:41 --> 404 Page Not Found: /index
DEBUG - 2018-05-17 03:15:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 03:15:41 --> Input Class Initialized
INFO - 2018-05-17 03:15:41 --> Language Class Initialized
ERROR - 2018-05-17 03:15:41 --> 404 Page Not Found: /index
INFO - 2018-05-17 03:15:41 --> Config Class Initialized
INFO - 2018-05-17 03:15:41 --> Config Class Initialized
INFO - 2018-05-17 03:15:41 --> Hooks Class Initialized
INFO - 2018-05-17 03:15:41 --> Hooks Class Initialized
DEBUG - 2018-05-17 03:15:41 --> UTF-8 Support Enabled
DEBUG - 2018-05-17 03:15:41 --> UTF-8 Support Enabled
INFO - 2018-05-17 03:15:41 --> Utf8 Class Initialized
INFO - 2018-05-17 03:15:41 --> URI Class Initialized
INFO - 2018-05-17 03:15:41 --> Router Class Initialized
INFO - 2018-05-17 03:15:41 --> Utf8 Class Initialized
INFO - 2018-05-17 03:15:41 --> Output Class Initialized
INFO - 2018-05-17 03:15:41 --> URI Class Initialized
INFO - 2018-05-17 03:15:41 --> Security Class Initialized
DEBUG - 2018-05-17 03:15:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 03:15:41 --> Router Class Initialized
INFO - 2018-05-17 03:15:41 --> Input Class Initialized
INFO - 2018-05-17 03:15:41 --> Output Class Initialized
INFO - 2018-05-17 03:15:41 --> Language Class Initialized
INFO - 2018-05-17 03:15:41 --> Security Class Initialized
ERROR - 2018-05-17 03:15:41 --> 404 Page Not Found: /index
DEBUG - 2018-05-17 03:15:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 03:15:41 --> Config Class Initialized
INFO - 2018-05-17 03:15:41 --> Hooks Class Initialized
INFO - 2018-05-17 03:15:41 --> Input Class Initialized
INFO - 2018-05-17 03:15:41 --> Language Class Initialized
DEBUG - 2018-05-17 03:15:41 --> UTF-8 Support Enabled
INFO - 2018-05-17 03:15:42 --> Utf8 Class Initialized
ERROR - 2018-05-17 03:15:42 --> 404 Page Not Found: /index
INFO - 2018-05-17 03:15:42 --> URI Class Initialized
INFO - 2018-05-17 03:15:42 --> Router Class Initialized
INFO - 2018-05-17 03:15:42 --> Output Class Initialized
INFO - 2018-05-17 03:15:42 --> Security Class Initialized
DEBUG - 2018-05-17 03:15:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 03:15:42 --> Input Class Initialized
INFO - 2018-05-17 03:15:42 --> Language Class Initialized
ERROR - 2018-05-17 03:15:42 --> 404 Page Not Found: /index
INFO - 2018-05-17 03:15:42 --> Config Class Initialized
INFO - 2018-05-17 03:15:42 --> Hooks Class Initialized
DEBUG - 2018-05-17 03:15:42 --> UTF-8 Support Enabled
INFO - 2018-05-17 03:15:42 --> Utf8 Class Initialized
INFO - 2018-05-17 03:15:42 --> URI Class Initialized
INFO - 2018-05-17 03:15:42 --> Router Class Initialized
INFO - 2018-05-17 03:15:42 --> Output Class Initialized
INFO - 2018-05-17 03:15:42 --> Security Class Initialized
DEBUG - 2018-05-17 03:15:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 03:15:42 --> Input Class Initialized
INFO - 2018-05-17 03:15:42 --> Language Class Initialized
ERROR - 2018-05-17 03:15:42 --> 404 Page Not Found: /index
INFO - 2018-05-17 03:15:43 --> Config Class Initialized
INFO - 2018-05-17 03:15:43 --> Hooks Class Initialized
DEBUG - 2018-05-17 03:15:43 --> UTF-8 Support Enabled
INFO - 2018-05-17 03:15:43 --> Utf8 Class Initialized
INFO - 2018-05-17 03:15:43 --> URI Class Initialized
INFO - 2018-05-17 03:15:43 --> Router Class Initialized
INFO - 2018-05-17 03:15:43 --> Output Class Initialized
INFO - 2018-05-17 03:15:43 --> Security Class Initialized
DEBUG - 2018-05-17 03:15:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 03:15:43 --> Input Class Initialized
INFO - 2018-05-17 03:15:43 --> Language Class Initialized
ERROR - 2018-05-17 03:15:43 --> 404 Page Not Found: /index
INFO - 2018-05-17 03:15:43 --> Config Class Initialized
INFO - 2018-05-17 03:15:43 --> Hooks Class Initialized
DEBUG - 2018-05-17 03:15:43 --> UTF-8 Support Enabled
INFO - 2018-05-17 03:15:44 --> Utf8 Class Initialized
INFO - 2018-05-17 03:15:44 --> URI Class Initialized
INFO - 2018-05-17 03:15:44 --> Router Class Initialized
INFO - 2018-05-17 03:15:44 --> Output Class Initialized
INFO - 2018-05-17 03:15:44 --> Security Class Initialized
DEBUG - 2018-05-17 03:15:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 03:15:44 --> Input Class Initialized
INFO - 2018-05-17 03:15:44 --> Language Class Initialized
ERROR - 2018-05-17 03:15:44 --> 404 Page Not Found: /index
INFO - 2018-05-17 03:15:47 --> Config Class Initialized
INFO - 2018-05-17 03:15:47 --> Hooks Class Initialized
DEBUG - 2018-05-17 03:15:47 --> UTF-8 Support Enabled
INFO - 2018-05-17 03:15:47 --> Utf8 Class Initialized
INFO - 2018-05-17 03:15:47 --> URI Class Initialized
INFO - 2018-05-17 03:15:47 --> Router Class Initialized
INFO - 2018-05-17 03:15:47 --> Output Class Initialized
INFO - 2018-05-17 03:15:47 --> Security Class Initialized
DEBUG - 2018-05-17 03:15:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 03:15:47 --> Input Class Initialized
INFO - 2018-05-17 03:15:47 --> Language Class Initialized
INFO - 2018-05-17 03:15:47 --> Language Class Initialized
INFO - 2018-05-17 03:15:47 --> Config Class Initialized
INFO - 2018-05-17 03:15:47 --> Loader Class Initialized
DEBUG - 2018-05-17 03:15:47 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-17 03:15:47 --> Helper loaded: url_helper
INFO - 2018-05-17 03:15:47 --> Helper loaded: form_helper
INFO - 2018-05-17 03:15:47 --> Helper loaded: date_helper
INFO - 2018-05-17 03:15:47 --> Helper loaded: util_helper
INFO - 2018-05-17 03:15:47 --> Helper loaded: text_helper
INFO - 2018-05-17 03:15:47 --> Helper loaded: string_helper
INFO - 2018-05-17 03:15:47 --> Database Driver Class Initialized
DEBUG - 2018-05-17 03:15:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-17 03:15:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-17 03:15:48 --> Email Class Initialized
INFO - 2018-05-17 03:15:48 --> Controller Class Initialized
DEBUG - 2018-05-17 03:15:48 --> Home MX_Controller Initialized
DEBUG - 2018-05-17 03:15:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-17 03:15:48 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-17 03:15:48 --> Login MX_Controller Initialized
INFO - 2018-05-17 03:15:48 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-17 03:15:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-17 03:15:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-17 03:15:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-17 03:15:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-17 03:15:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-17 03:15:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-17 03:15:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-17 03:15:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-05-17 03:15:48 --> Final output sent to browser
DEBUG - 2018-05-17 03:15:48 --> Total execution time: 0.5654
INFO - 2018-05-17 03:15:48 --> Config Class Initialized
INFO - 2018-05-17 03:15:48 --> Config Class Initialized
INFO - 2018-05-17 03:15:48 --> Hooks Class Initialized
INFO - 2018-05-17 03:15:48 --> Hooks Class Initialized
DEBUG - 2018-05-17 03:15:48 --> UTF-8 Support Enabled
DEBUG - 2018-05-17 03:15:48 --> UTF-8 Support Enabled
INFO - 2018-05-17 03:15:48 --> Utf8 Class Initialized
INFO - 2018-05-17 03:15:49 --> Utf8 Class Initialized
INFO - 2018-05-17 03:15:49 --> URI Class Initialized
INFO - 2018-05-17 03:15:49 --> URI Class Initialized
INFO - 2018-05-17 03:15:49 --> Router Class Initialized
INFO - 2018-05-17 03:15:49 --> Output Class Initialized
INFO - 2018-05-17 03:15:49 --> Router Class Initialized
INFO - 2018-05-17 03:15:49 --> Security Class Initialized
DEBUG - 2018-05-17 03:15:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 03:15:49 --> Input Class Initialized
INFO - 2018-05-17 03:15:49 --> Language Class Initialized
ERROR - 2018-05-17 03:15:49 --> 404 Page Not Found: /index
INFO - 2018-05-17 03:15:49 --> Output Class Initialized
INFO - 2018-05-17 03:15:49 --> Security Class Initialized
INFO - 2018-05-17 03:15:49 --> Config Class Initialized
INFO - 2018-05-17 03:15:49 --> Hooks Class Initialized
DEBUG - 2018-05-17 03:15:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-17 03:15:49 --> UTF-8 Support Enabled
INFO - 2018-05-17 03:15:49 --> Utf8 Class Initialized
INFO - 2018-05-17 03:15:49 --> Input Class Initialized
INFO - 2018-05-17 03:15:49 --> Language Class Initialized
INFO - 2018-05-17 03:15:49 --> URI Class Initialized
ERROR - 2018-05-17 03:15:49 --> 404 Page Not Found: /index
INFO - 2018-05-17 03:15:49 --> Router Class Initialized
INFO - 2018-05-17 03:15:49 --> Output Class Initialized
INFO - 2018-05-17 03:15:49 --> Security Class Initialized
DEBUG - 2018-05-17 03:15:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 03:15:49 --> Input Class Initialized
INFO - 2018-05-17 03:15:49 --> Language Class Initialized
ERROR - 2018-05-17 03:15:49 --> 404 Page Not Found: /index
INFO - 2018-05-17 03:15:49 --> Config Class Initialized
INFO - 2018-05-17 03:15:49 --> Hooks Class Initialized
DEBUG - 2018-05-17 03:15:49 --> UTF-8 Support Enabled
INFO - 2018-05-17 03:15:49 --> Utf8 Class Initialized
INFO - 2018-05-17 03:15:49 --> URI Class Initialized
INFO - 2018-05-17 03:15:49 --> Router Class Initialized
INFO - 2018-05-17 03:15:49 --> Output Class Initialized
INFO - 2018-05-17 03:15:49 --> Security Class Initialized
DEBUG - 2018-05-17 03:15:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 03:15:49 --> Input Class Initialized
INFO - 2018-05-17 03:15:49 --> Language Class Initialized
ERROR - 2018-05-17 03:15:49 --> 404 Page Not Found: /index
INFO - 2018-05-17 03:17:33 --> Config Class Initialized
INFO - 2018-05-17 03:17:33 --> Hooks Class Initialized
DEBUG - 2018-05-17 03:17:33 --> UTF-8 Support Enabled
INFO - 2018-05-17 03:17:33 --> Utf8 Class Initialized
INFO - 2018-05-17 03:17:33 --> URI Class Initialized
INFO - 2018-05-17 03:17:33 --> Router Class Initialized
INFO - 2018-05-17 03:17:33 --> Output Class Initialized
INFO - 2018-05-17 03:17:33 --> Security Class Initialized
DEBUG - 2018-05-17 03:17:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 03:17:33 --> Input Class Initialized
INFO - 2018-05-17 03:17:33 --> Language Class Initialized
INFO - 2018-05-17 03:17:33 --> Language Class Initialized
INFO - 2018-05-17 03:17:33 --> Config Class Initialized
INFO - 2018-05-17 03:17:33 --> Loader Class Initialized
DEBUG - 2018-05-17 03:17:33 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-17 03:17:33 --> Helper loaded: url_helper
INFO - 2018-05-17 03:17:33 --> Helper loaded: form_helper
INFO - 2018-05-17 03:17:33 --> Helper loaded: date_helper
INFO - 2018-05-17 03:17:33 --> Helper loaded: util_helper
INFO - 2018-05-17 03:17:33 --> Helper loaded: text_helper
INFO - 2018-05-17 03:17:33 --> Helper loaded: string_helper
INFO - 2018-05-17 03:17:33 --> Database Driver Class Initialized
DEBUG - 2018-05-17 03:17:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-17 03:17:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-17 03:17:33 --> Email Class Initialized
INFO - 2018-05-17 03:17:33 --> Controller Class Initialized
DEBUG - 2018-05-17 03:17:33 --> Home MX_Controller Initialized
DEBUG - 2018-05-17 03:17:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-17 03:17:33 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-17 03:17:33 --> Login MX_Controller Initialized
INFO - 2018-05-17 03:17:33 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-17 03:17:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-17 03:17:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-17 03:17:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-17 03:17:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-17 03:17:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-17 03:17:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-17 03:17:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-17 03:17:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-05-17 03:17:33 --> Final output sent to browser
DEBUG - 2018-05-17 03:17:34 --> Total execution time: 0.5580
INFO - 2018-05-17 03:17:34 --> Config Class Initialized
INFO - 2018-05-17 03:17:34 --> Hooks Class Initialized
INFO - 2018-05-17 03:17:34 --> Config Class Initialized
INFO - 2018-05-17 03:17:34 --> Hooks Class Initialized
DEBUG - 2018-05-17 03:17:34 --> UTF-8 Support Enabled
DEBUG - 2018-05-17 03:17:34 --> UTF-8 Support Enabled
INFO - 2018-05-17 03:17:34 --> Utf8 Class Initialized
INFO - 2018-05-17 03:17:34 --> URI Class Initialized
INFO - 2018-05-17 03:17:34 --> Router Class Initialized
INFO - 2018-05-17 03:17:34 --> Utf8 Class Initialized
INFO - 2018-05-17 03:17:34 --> Output Class Initialized
INFO - 2018-05-17 03:17:35 --> URI Class Initialized
INFO - 2018-05-17 03:17:35 --> Security Class Initialized
INFO - 2018-05-17 03:17:35 --> Router Class Initialized
DEBUG - 2018-05-17 03:17:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 03:17:35 --> Input Class Initialized
INFO - 2018-05-17 03:17:35 --> Language Class Initialized
ERROR - 2018-05-17 03:17:35 --> 404 Page Not Found: /index
INFO - 2018-05-17 03:17:35 --> Output Class Initialized
INFO - 2018-05-17 03:17:35 --> Security Class Initialized
INFO - 2018-05-17 03:17:35 --> Config Class Initialized
INFO - 2018-05-17 03:17:35 --> Hooks Class Initialized
DEBUG - 2018-05-17 03:17:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-17 03:17:35 --> UTF-8 Support Enabled
INFO - 2018-05-17 03:17:35 --> Utf8 Class Initialized
INFO - 2018-05-17 03:17:35 --> URI Class Initialized
INFO - 2018-05-17 03:17:35 --> Router Class Initialized
INFO - 2018-05-17 03:17:35 --> Output Class Initialized
INFO - 2018-05-17 03:17:35 --> Security Class Initialized
DEBUG - 2018-05-17 03:17:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 03:17:35 --> Input Class Initialized
INFO - 2018-05-17 03:17:35 --> Language Class Initialized
ERROR - 2018-05-17 03:17:35 --> 404 Page Not Found: /index
INFO - 2018-05-17 03:17:35 --> Input Class Initialized
INFO - 2018-05-17 03:17:35 --> Language Class Initialized
INFO - 2018-05-17 03:17:35 --> Config Class Initialized
ERROR - 2018-05-17 03:17:35 --> 404 Page Not Found: /index
INFO - 2018-05-17 03:17:35 --> Hooks Class Initialized
DEBUG - 2018-05-17 03:17:35 --> UTF-8 Support Enabled
INFO - 2018-05-17 03:17:35 --> Utf8 Class Initialized
INFO - 2018-05-17 03:17:35 --> URI Class Initialized
INFO - 2018-05-17 03:17:35 --> Router Class Initialized
INFO - 2018-05-17 03:17:35 --> Output Class Initialized
INFO - 2018-05-17 03:17:35 --> Security Class Initialized
DEBUG - 2018-05-17 03:17:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 03:17:35 --> Input Class Initialized
INFO - 2018-05-17 03:17:35 --> Language Class Initialized
ERROR - 2018-05-17 03:17:35 --> 404 Page Not Found: /index
INFO - 2018-05-17 03:17:39 --> Config Class Initialized
INFO - 2018-05-17 03:17:39 --> Hooks Class Initialized
DEBUG - 2018-05-17 03:17:39 --> UTF-8 Support Enabled
INFO - 2018-05-17 03:17:39 --> Utf8 Class Initialized
INFO - 2018-05-17 03:17:39 --> URI Class Initialized
INFO - 2018-05-17 03:17:39 --> Router Class Initialized
INFO - 2018-05-17 03:17:39 --> Output Class Initialized
INFO - 2018-05-17 03:17:39 --> Security Class Initialized
DEBUG - 2018-05-17 03:17:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 03:17:39 --> Input Class Initialized
INFO - 2018-05-17 03:17:39 --> Language Class Initialized
ERROR - 2018-05-17 03:17:39 --> 404 Page Not Found: /index
INFO - 2018-05-17 03:17:39 --> Config Class Initialized
INFO - 2018-05-17 03:17:39 --> Hooks Class Initialized
DEBUG - 2018-05-17 03:17:39 --> UTF-8 Support Enabled
INFO - 2018-05-17 03:17:39 --> Utf8 Class Initialized
INFO - 2018-05-17 03:17:39 --> URI Class Initialized
INFO - 2018-05-17 03:17:39 --> Router Class Initialized
INFO - 2018-05-17 03:17:39 --> Output Class Initialized
INFO - 2018-05-17 03:17:39 --> Security Class Initialized
DEBUG - 2018-05-17 03:17:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 03:17:39 --> Input Class Initialized
INFO - 2018-05-17 03:17:39 --> Language Class Initialized
ERROR - 2018-05-17 03:17:39 --> 404 Page Not Found: /index
INFO - 2018-05-17 03:17:39 --> Config Class Initialized
INFO - 2018-05-17 03:17:39 --> Hooks Class Initialized
DEBUG - 2018-05-17 03:17:39 --> UTF-8 Support Enabled
INFO - 2018-05-17 03:17:39 --> Utf8 Class Initialized
INFO - 2018-05-17 03:17:39 --> URI Class Initialized
INFO - 2018-05-17 03:17:39 --> Router Class Initialized
INFO - 2018-05-17 03:17:39 --> Output Class Initialized
INFO - 2018-05-17 03:17:39 --> Security Class Initialized
DEBUG - 2018-05-17 03:17:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 03:17:39 --> Input Class Initialized
INFO - 2018-05-17 03:17:39 --> Language Class Initialized
ERROR - 2018-05-17 03:17:39 --> 404 Page Not Found: /index
INFO - 2018-05-17 03:26:17 --> Config Class Initialized
INFO - 2018-05-17 03:26:17 --> Hooks Class Initialized
DEBUG - 2018-05-17 03:26:17 --> UTF-8 Support Enabled
INFO - 2018-05-17 03:26:17 --> Utf8 Class Initialized
INFO - 2018-05-17 03:26:17 --> URI Class Initialized
INFO - 2018-05-17 03:26:17 --> Router Class Initialized
INFO - 2018-05-17 03:26:17 --> Output Class Initialized
INFO - 2018-05-17 03:26:17 --> Security Class Initialized
DEBUG - 2018-05-17 03:26:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 03:26:17 --> Input Class Initialized
INFO - 2018-05-17 03:26:17 --> Language Class Initialized
INFO - 2018-05-17 03:26:17 --> Language Class Initialized
INFO - 2018-05-17 03:26:17 --> Config Class Initialized
INFO - 2018-05-17 03:26:17 --> Loader Class Initialized
DEBUG - 2018-05-17 03:26:17 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-17 03:26:17 --> Helper loaded: url_helper
INFO - 2018-05-17 03:26:17 --> Helper loaded: form_helper
INFO - 2018-05-17 03:26:17 --> Helper loaded: date_helper
INFO - 2018-05-17 03:26:17 --> Helper loaded: util_helper
INFO - 2018-05-17 03:26:17 --> Helper loaded: text_helper
INFO - 2018-05-17 03:26:17 --> Helper loaded: string_helper
INFO - 2018-05-17 03:26:17 --> Database Driver Class Initialized
DEBUG - 2018-05-17 03:26:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-17 03:26:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-17 03:26:17 --> Email Class Initialized
INFO - 2018-05-17 03:26:17 --> Controller Class Initialized
DEBUG - 2018-05-17 03:26:17 --> Home MX_Controller Initialized
DEBUG - 2018-05-17 03:26:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-17 03:26:17 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-17 03:26:17 --> Login MX_Controller Initialized
INFO - 2018-05-17 03:26:17 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-17 03:26:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-17 03:26:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-17 03:26:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-17 03:26:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-17 03:26:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-17 03:26:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-17 03:26:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-17 03:26:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-05-17 03:26:17 --> Final output sent to browser
DEBUG - 2018-05-17 03:26:17 --> Total execution time: 0.5796
INFO - 2018-05-17 03:26:19 --> Config Class Initialized
INFO - 2018-05-17 03:26:19 --> Config Class Initialized
INFO - 2018-05-17 03:26:19 --> Hooks Class Initialized
INFO - 2018-05-17 03:26:19 --> Hooks Class Initialized
DEBUG - 2018-05-17 03:26:19 --> UTF-8 Support Enabled
DEBUG - 2018-05-17 03:26:19 --> UTF-8 Support Enabled
INFO - 2018-05-17 03:26:19 --> Utf8 Class Initialized
INFO - 2018-05-17 03:26:19 --> Utf8 Class Initialized
INFO - 2018-05-17 03:26:19 --> URI Class Initialized
INFO - 2018-05-17 03:26:19 --> Router Class Initialized
INFO - 2018-05-17 03:26:19 --> Output Class Initialized
INFO - 2018-05-17 03:26:19 --> Security Class Initialized
DEBUG - 2018-05-17 03:26:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 03:26:19 --> Input Class Initialized
INFO - 2018-05-17 03:26:19 --> Language Class Initialized
INFO - 2018-05-17 03:26:19 --> URI Class Initialized
ERROR - 2018-05-17 03:26:19 --> 404 Page Not Found: /index
INFO - 2018-05-17 03:26:19 --> Router Class Initialized
INFO - 2018-05-17 03:26:19 --> Output Class Initialized
INFO - 2018-05-17 03:26:19 --> Security Class Initialized
DEBUG - 2018-05-17 03:26:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 03:26:19 --> Input Class Initialized
INFO - 2018-05-17 03:26:19 --> Language Class Initialized
ERROR - 2018-05-17 03:26:19 --> 404 Page Not Found: /index
INFO - 2018-05-17 03:26:19 --> Config Class Initialized
INFO - 2018-05-17 03:26:19 --> Hooks Class Initialized
DEBUG - 2018-05-17 03:26:19 --> UTF-8 Support Enabled
INFO - 2018-05-17 03:26:19 --> Utf8 Class Initialized
INFO - 2018-05-17 03:26:20 --> URI Class Initialized
INFO - 2018-05-17 03:26:20 --> Router Class Initialized
INFO - 2018-05-17 03:26:20 --> Output Class Initialized
INFO - 2018-05-17 03:26:20 --> Security Class Initialized
DEBUG - 2018-05-17 03:26:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 03:26:20 --> Input Class Initialized
INFO - 2018-05-17 03:26:20 --> Language Class Initialized
ERROR - 2018-05-17 03:26:20 --> 404 Page Not Found: /index
INFO - 2018-05-17 03:26:20 --> Config Class Initialized
INFO - 2018-05-17 03:26:20 --> Hooks Class Initialized
DEBUG - 2018-05-17 03:26:20 --> UTF-8 Support Enabled
INFO - 2018-05-17 03:26:20 --> Utf8 Class Initialized
INFO - 2018-05-17 03:26:20 --> URI Class Initialized
INFO - 2018-05-17 03:26:20 --> Router Class Initialized
INFO - 2018-05-17 03:26:20 --> Output Class Initialized
INFO - 2018-05-17 03:26:20 --> Security Class Initialized
DEBUG - 2018-05-17 03:26:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 03:26:20 --> Input Class Initialized
INFO - 2018-05-17 03:26:20 --> Language Class Initialized
ERROR - 2018-05-17 03:26:20 --> 404 Page Not Found: /index
INFO - 2018-05-17 03:26:28 --> Config Class Initialized
INFO - 2018-05-17 03:26:28 --> Hooks Class Initialized
DEBUG - 2018-05-17 03:26:28 --> UTF-8 Support Enabled
INFO - 2018-05-17 03:26:28 --> Utf8 Class Initialized
INFO - 2018-05-17 03:26:28 --> URI Class Initialized
INFO - 2018-05-17 03:26:28 --> Router Class Initialized
INFO - 2018-05-17 03:26:28 --> Output Class Initialized
INFO - 2018-05-17 03:26:28 --> Security Class Initialized
DEBUG - 2018-05-17 03:26:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 03:26:28 --> Input Class Initialized
INFO - 2018-05-17 03:26:28 --> Language Class Initialized
INFO - 2018-05-17 03:26:28 --> Language Class Initialized
INFO - 2018-05-17 03:26:28 --> Config Class Initialized
INFO - 2018-05-17 03:26:28 --> Loader Class Initialized
DEBUG - 2018-05-17 03:26:28 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-17 03:26:28 --> Helper loaded: url_helper
INFO - 2018-05-17 03:26:28 --> Helper loaded: form_helper
INFO - 2018-05-17 03:26:28 --> Helper loaded: date_helper
INFO - 2018-05-17 03:26:28 --> Helper loaded: util_helper
INFO - 2018-05-17 03:26:28 --> Helper loaded: text_helper
INFO - 2018-05-17 03:26:28 --> Helper loaded: string_helper
INFO - 2018-05-17 03:26:28 --> Database Driver Class Initialized
DEBUG - 2018-05-17 03:26:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-17 03:26:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-17 03:26:28 --> Email Class Initialized
INFO - 2018-05-17 03:26:28 --> Controller Class Initialized
DEBUG - 2018-05-17 03:26:28 --> Home MX_Controller Initialized
DEBUG - 2018-05-17 03:26:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-17 03:26:28 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-17 03:26:28 --> Login MX_Controller Initialized
INFO - 2018-05-17 03:26:28 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-17 03:26:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-17 03:26:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-17 03:26:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-17 03:26:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-17 03:26:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-17 03:26:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-17 03:26:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-17 03:26:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-05-17 03:26:28 --> Final output sent to browser
DEBUG - 2018-05-17 03:26:28 --> Total execution time: 0.5775
INFO - 2018-05-17 03:26:29 --> Config Class Initialized
INFO - 2018-05-17 03:26:29 --> Config Class Initialized
INFO - 2018-05-17 03:26:29 --> Hooks Class Initialized
INFO - 2018-05-17 03:26:29 --> Hooks Class Initialized
DEBUG - 2018-05-17 03:26:29 --> UTF-8 Support Enabled
DEBUG - 2018-05-17 03:26:29 --> UTF-8 Support Enabled
INFO - 2018-05-17 03:26:29 --> Utf8 Class Initialized
INFO - 2018-05-17 03:26:29 --> Utf8 Class Initialized
INFO - 2018-05-17 03:26:29 --> URI Class Initialized
INFO - 2018-05-17 03:26:29 --> Router Class Initialized
INFO - 2018-05-17 03:26:29 --> URI Class Initialized
INFO - 2018-05-17 03:26:29 --> Router Class Initialized
INFO - 2018-05-17 03:26:29 --> Output Class Initialized
INFO - 2018-05-17 03:26:29 --> Output Class Initialized
INFO - 2018-05-17 03:26:29 --> Security Class Initialized
DEBUG - 2018-05-17 03:26:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 03:26:29 --> Security Class Initialized
INFO - 2018-05-17 03:26:29 --> Input Class Initialized
DEBUG - 2018-05-17 03:26:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 03:26:29 --> Language Class Initialized
INFO - 2018-05-17 03:26:29 --> Input Class Initialized
ERROR - 2018-05-17 03:26:29 --> 404 Page Not Found: /index
INFO - 2018-05-17 03:26:29 --> Language Class Initialized
ERROR - 2018-05-17 03:26:29 --> 404 Page Not Found: /index
INFO - 2018-05-17 03:26:29 --> Config Class Initialized
INFO - 2018-05-17 03:26:29 --> Hooks Class Initialized
DEBUG - 2018-05-17 03:26:29 --> UTF-8 Support Enabled
INFO - 2018-05-17 03:26:29 --> Utf8 Class Initialized
INFO - 2018-05-17 03:26:29 --> URI Class Initialized
INFO - 2018-05-17 03:26:29 --> Router Class Initialized
INFO - 2018-05-17 03:26:29 --> Output Class Initialized
INFO - 2018-05-17 03:26:29 --> Security Class Initialized
DEBUG - 2018-05-17 03:26:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 03:26:29 --> Input Class Initialized
INFO - 2018-05-17 03:26:30 --> Language Class Initialized
ERROR - 2018-05-17 03:26:30 --> 404 Page Not Found: /index
INFO - 2018-05-17 03:26:30 --> Config Class Initialized
INFO - 2018-05-17 03:26:30 --> Hooks Class Initialized
DEBUG - 2018-05-17 03:26:30 --> UTF-8 Support Enabled
INFO - 2018-05-17 03:26:30 --> Utf8 Class Initialized
INFO - 2018-05-17 03:26:30 --> URI Class Initialized
INFO - 2018-05-17 03:26:30 --> Router Class Initialized
INFO - 2018-05-17 03:26:30 --> Output Class Initialized
INFO - 2018-05-17 03:26:30 --> Security Class Initialized
DEBUG - 2018-05-17 03:26:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 03:26:30 --> Input Class Initialized
INFO - 2018-05-17 03:26:30 --> Language Class Initialized
ERROR - 2018-05-17 03:26:30 --> 404 Page Not Found: /index
INFO - 2018-05-17 03:27:19 --> Config Class Initialized
INFO - 2018-05-17 03:27:19 --> Hooks Class Initialized
DEBUG - 2018-05-17 03:27:19 --> UTF-8 Support Enabled
INFO - 2018-05-17 03:27:19 --> Utf8 Class Initialized
INFO - 2018-05-17 03:27:19 --> URI Class Initialized
INFO - 2018-05-17 03:27:19 --> Router Class Initialized
INFO - 2018-05-17 03:27:19 --> Output Class Initialized
INFO - 2018-05-17 03:27:19 --> Security Class Initialized
DEBUG - 2018-05-17 03:27:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 03:27:19 --> Input Class Initialized
INFO - 2018-05-17 03:27:19 --> Language Class Initialized
INFO - 2018-05-17 03:27:19 --> Language Class Initialized
INFO - 2018-05-17 03:27:19 --> Config Class Initialized
INFO - 2018-05-17 03:27:19 --> Loader Class Initialized
DEBUG - 2018-05-17 03:27:19 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-17 03:27:19 --> Helper loaded: url_helper
INFO - 2018-05-17 03:27:19 --> Helper loaded: form_helper
INFO - 2018-05-17 03:27:19 --> Helper loaded: date_helper
INFO - 2018-05-17 03:27:19 --> Helper loaded: util_helper
INFO - 2018-05-17 03:27:20 --> Helper loaded: text_helper
INFO - 2018-05-17 03:27:20 --> Helper loaded: string_helper
INFO - 2018-05-17 03:27:20 --> Database Driver Class Initialized
DEBUG - 2018-05-17 03:27:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-17 03:27:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-17 03:27:20 --> Email Class Initialized
INFO - 2018-05-17 03:27:20 --> Controller Class Initialized
DEBUG - 2018-05-17 03:27:20 --> Home MX_Controller Initialized
DEBUG - 2018-05-17 03:27:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-17 03:27:20 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-17 03:27:20 --> Login MX_Controller Initialized
INFO - 2018-05-17 03:27:20 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-17 03:27:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-17 03:27:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-17 03:27:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-17 03:27:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-17 03:27:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-17 03:27:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-17 03:27:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-17 03:27:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-05-17 03:27:20 --> Final output sent to browser
DEBUG - 2018-05-17 03:27:20 --> Total execution time: 0.5741
INFO - 2018-05-17 03:27:20 --> Config Class Initialized
INFO - 2018-05-17 03:27:20 --> Hooks Class Initialized
DEBUG - 2018-05-17 03:27:20 --> UTF-8 Support Enabled
INFO - 2018-05-17 03:27:21 --> Config Class Initialized
INFO - 2018-05-17 03:27:21 --> Hooks Class Initialized
INFO - 2018-05-17 03:27:21 --> Utf8 Class Initialized
DEBUG - 2018-05-17 03:27:21 --> UTF-8 Support Enabled
INFO - 2018-05-17 03:27:21 --> URI Class Initialized
INFO - 2018-05-17 03:27:21 --> Utf8 Class Initialized
INFO - 2018-05-17 03:27:21 --> URI Class Initialized
INFO - 2018-05-17 03:27:21 --> Router Class Initialized
INFO - 2018-05-17 03:27:21 --> Output Class Initialized
INFO - 2018-05-17 03:27:21 --> Router Class Initialized
INFO - 2018-05-17 03:27:21 --> Security Class Initialized
INFO - 2018-05-17 03:27:21 --> Output Class Initialized
DEBUG - 2018-05-17 03:27:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 03:27:21 --> Input Class Initialized
INFO - 2018-05-17 03:27:21 --> Security Class Initialized
DEBUG - 2018-05-17 03:27:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 03:27:21 --> Language Class Initialized
INFO - 2018-05-17 03:27:21 --> Input Class Initialized
INFO - 2018-05-17 03:27:21 --> Language Class Initialized
ERROR - 2018-05-17 03:27:21 --> 404 Page Not Found: /index
ERROR - 2018-05-17 03:27:21 --> 404 Page Not Found: /index
INFO - 2018-05-17 03:27:21 --> Config Class Initialized
INFO - 2018-05-17 03:27:21 --> Hooks Class Initialized
DEBUG - 2018-05-17 03:27:21 --> UTF-8 Support Enabled
INFO - 2018-05-17 03:27:21 --> Utf8 Class Initialized
INFO - 2018-05-17 03:27:21 --> URI Class Initialized
INFO - 2018-05-17 03:27:21 --> Router Class Initialized
INFO - 2018-05-17 03:27:21 --> Output Class Initialized
INFO - 2018-05-17 03:27:21 --> Security Class Initialized
DEBUG - 2018-05-17 03:27:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 03:27:21 --> Input Class Initialized
INFO - 2018-05-17 03:27:21 --> Language Class Initialized
ERROR - 2018-05-17 03:27:21 --> 404 Page Not Found: /index
INFO - 2018-05-17 03:27:21 --> Config Class Initialized
INFO - 2018-05-17 03:27:21 --> Hooks Class Initialized
DEBUG - 2018-05-17 03:27:22 --> UTF-8 Support Enabled
INFO - 2018-05-17 03:27:22 --> Utf8 Class Initialized
INFO - 2018-05-17 03:27:22 --> URI Class Initialized
INFO - 2018-05-17 03:27:22 --> Router Class Initialized
INFO - 2018-05-17 03:27:22 --> Output Class Initialized
INFO - 2018-05-17 03:27:22 --> Security Class Initialized
DEBUG - 2018-05-17 03:27:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 03:27:22 --> Input Class Initialized
INFO - 2018-05-17 03:27:22 --> Language Class Initialized
ERROR - 2018-05-17 03:27:22 --> 404 Page Not Found: /index
INFO - 2018-05-17 03:27:27 --> Config Class Initialized
INFO - 2018-05-17 03:27:27 --> Hooks Class Initialized
DEBUG - 2018-05-17 03:27:27 --> UTF-8 Support Enabled
INFO - 2018-05-17 03:27:27 --> Utf8 Class Initialized
INFO - 2018-05-17 03:27:27 --> URI Class Initialized
INFO - 2018-05-17 03:27:27 --> Router Class Initialized
INFO - 2018-05-17 03:27:27 --> Output Class Initialized
INFO - 2018-05-17 03:27:27 --> Security Class Initialized
DEBUG - 2018-05-17 03:27:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 03:27:27 --> Input Class Initialized
INFO - 2018-05-17 03:27:27 --> Language Class Initialized
INFO - 2018-05-17 03:27:27 --> Language Class Initialized
INFO - 2018-05-17 03:27:27 --> Config Class Initialized
INFO - 2018-05-17 03:27:27 --> Loader Class Initialized
DEBUG - 2018-05-17 03:27:27 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-17 03:27:27 --> Helper loaded: url_helper
INFO - 2018-05-17 03:27:27 --> Helper loaded: form_helper
INFO - 2018-05-17 03:27:27 --> Helper loaded: date_helper
INFO - 2018-05-17 03:27:27 --> Helper loaded: util_helper
INFO - 2018-05-17 03:27:27 --> Helper loaded: text_helper
INFO - 2018-05-17 03:27:27 --> Helper loaded: string_helper
INFO - 2018-05-17 03:27:27 --> Database Driver Class Initialized
DEBUG - 2018-05-17 03:27:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-17 03:27:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-17 03:27:27 --> Email Class Initialized
INFO - 2018-05-17 03:27:27 --> Controller Class Initialized
DEBUG - 2018-05-17 03:27:27 --> Home MX_Controller Initialized
DEBUG - 2018-05-17 03:27:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-17 03:27:27 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-17 03:27:27 --> Login MX_Controller Initialized
INFO - 2018-05-17 03:27:27 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-17 03:27:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-17 03:27:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-17 03:27:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-17 03:27:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-17 03:27:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-17 03:27:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-17 03:27:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-17 03:27:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-05-17 03:27:27 --> Final output sent to browser
DEBUG - 2018-05-17 03:27:27 --> Total execution time: 0.6147
INFO - 2018-05-17 03:27:28 --> Config Class Initialized
INFO - 2018-05-17 03:27:28 --> Config Class Initialized
INFO - 2018-05-17 03:27:28 --> Hooks Class Initialized
INFO - 2018-05-17 03:27:28 --> Hooks Class Initialized
DEBUG - 2018-05-17 03:27:28 --> UTF-8 Support Enabled
DEBUG - 2018-05-17 03:27:28 --> UTF-8 Support Enabled
INFO - 2018-05-17 03:27:28 --> Utf8 Class Initialized
INFO - 2018-05-17 03:27:28 --> Utf8 Class Initialized
INFO - 2018-05-17 03:27:28 --> URI Class Initialized
INFO - 2018-05-17 03:27:28 --> URI Class Initialized
INFO - 2018-05-17 03:27:28 --> Router Class Initialized
INFO - 2018-05-17 03:27:28 --> Router Class Initialized
INFO - 2018-05-17 03:27:28 --> Output Class Initialized
INFO - 2018-05-17 03:27:28 --> Security Class Initialized
INFO - 2018-05-17 03:27:28 --> Output Class Initialized
INFO - 2018-05-17 03:27:28 --> Security Class Initialized
DEBUG - 2018-05-17 03:27:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-17 03:27:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 03:27:28 --> Input Class Initialized
INFO - 2018-05-17 03:27:28 --> Input Class Initialized
INFO - 2018-05-17 03:27:28 --> Language Class Initialized
INFO - 2018-05-17 03:27:28 --> Language Class Initialized
ERROR - 2018-05-17 03:27:28 --> 404 Page Not Found: /index
ERROR - 2018-05-17 03:27:28 --> 404 Page Not Found: /index
INFO - 2018-05-17 03:27:29 --> Config Class Initialized
INFO - 2018-05-17 03:27:29 --> Hooks Class Initialized
DEBUG - 2018-05-17 03:27:29 --> UTF-8 Support Enabled
INFO - 2018-05-17 03:27:29 --> Utf8 Class Initialized
INFO - 2018-05-17 03:27:29 --> URI Class Initialized
INFO - 2018-05-17 03:27:29 --> Router Class Initialized
INFO - 2018-05-17 03:27:29 --> Output Class Initialized
INFO - 2018-05-17 03:27:29 --> Security Class Initialized
DEBUG - 2018-05-17 03:27:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 03:27:29 --> Input Class Initialized
INFO - 2018-05-17 03:27:29 --> Language Class Initialized
ERROR - 2018-05-17 03:27:29 --> 404 Page Not Found: /index
INFO - 2018-05-17 03:27:29 --> Config Class Initialized
INFO - 2018-05-17 03:27:29 --> Hooks Class Initialized
DEBUG - 2018-05-17 03:27:29 --> UTF-8 Support Enabled
INFO - 2018-05-17 03:27:29 --> Utf8 Class Initialized
INFO - 2018-05-17 03:27:29 --> URI Class Initialized
INFO - 2018-05-17 03:27:29 --> Router Class Initialized
INFO - 2018-05-17 03:27:29 --> Output Class Initialized
INFO - 2018-05-17 03:27:29 --> Security Class Initialized
DEBUG - 2018-05-17 03:27:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 03:27:29 --> Input Class Initialized
INFO - 2018-05-17 03:27:29 --> Language Class Initialized
ERROR - 2018-05-17 03:27:29 --> 404 Page Not Found: /index
INFO - 2018-05-17 03:27:44 --> Config Class Initialized
INFO - 2018-05-17 03:27:44 --> Hooks Class Initialized
DEBUG - 2018-05-17 03:27:44 --> UTF-8 Support Enabled
INFO - 2018-05-17 03:27:44 --> Utf8 Class Initialized
INFO - 2018-05-17 03:27:44 --> URI Class Initialized
INFO - 2018-05-17 03:27:44 --> Router Class Initialized
INFO - 2018-05-17 03:27:44 --> Output Class Initialized
INFO - 2018-05-17 03:27:44 --> Security Class Initialized
DEBUG - 2018-05-17 03:27:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 03:27:44 --> Input Class Initialized
INFO - 2018-05-17 03:27:44 --> Language Class Initialized
INFO - 2018-05-17 03:27:44 --> Language Class Initialized
INFO - 2018-05-17 03:27:44 --> Config Class Initialized
INFO - 2018-05-17 03:27:44 --> Loader Class Initialized
DEBUG - 2018-05-17 03:27:44 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-17 03:27:44 --> Helper loaded: url_helper
INFO - 2018-05-17 03:27:44 --> Helper loaded: form_helper
INFO - 2018-05-17 03:27:44 --> Helper loaded: date_helper
INFO - 2018-05-17 03:27:44 --> Helper loaded: util_helper
INFO - 2018-05-17 03:27:44 --> Helper loaded: text_helper
INFO - 2018-05-17 03:27:44 --> Helper loaded: string_helper
INFO - 2018-05-17 03:27:44 --> Database Driver Class Initialized
DEBUG - 2018-05-17 03:27:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-17 03:27:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-17 03:27:44 --> Email Class Initialized
INFO - 2018-05-17 03:27:44 --> Controller Class Initialized
DEBUG - 2018-05-17 03:27:44 --> Home MX_Controller Initialized
DEBUG - 2018-05-17 03:27:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-17 03:27:44 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-17 03:27:44 --> Login MX_Controller Initialized
INFO - 2018-05-17 03:27:44 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-17 03:27:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-17 03:27:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-17 03:27:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-17 03:27:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-17 03:27:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-17 03:27:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-17 03:27:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-17 03:27:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-05-17 03:27:44 --> Final output sent to browser
DEBUG - 2018-05-17 03:27:44 --> Total execution time: 0.6011
INFO - 2018-05-17 03:27:46 --> Config Class Initialized
INFO - 2018-05-17 03:27:46 --> Config Class Initialized
INFO - 2018-05-17 03:27:46 --> Hooks Class Initialized
DEBUG - 2018-05-17 03:27:46 --> UTF-8 Support Enabled
INFO - 2018-05-17 03:27:46 --> Utf8 Class Initialized
INFO - 2018-05-17 03:27:46 --> Hooks Class Initialized
INFO - 2018-05-17 03:27:46 --> URI Class Initialized
DEBUG - 2018-05-17 03:27:46 --> UTF-8 Support Enabled
INFO - 2018-05-17 03:27:46 --> Utf8 Class Initialized
INFO - 2018-05-17 03:27:46 --> Router Class Initialized
INFO - 2018-05-17 03:27:46 --> URI Class Initialized
INFO - 2018-05-17 03:27:46 --> Output Class Initialized
INFO - 2018-05-17 03:27:46 --> Router Class Initialized
INFO - 2018-05-17 03:27:46 --> Security Class Initialized
INFO - 2018-05-17 03:27:46 --> Output Class Initialized
DEBUG - 2018-05-17 03:27:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 03:27:47 --> Security Class Initialized
DEBUG - 2018-05-17 03:27:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 03:27:47 --> Input Class Initialized
INFO - 2018-05-17 03:27:47 --> Input Class Initialized
INFO - 2018-05-17 03:27:47 --> Language Class Initialized
INFO - 2018-05-17 03:27:47 --> Language Class Initialized
ERROR - 2018-05-17 03:27:47 --> 404 Page Not Found: /index
ERROR - 2018-05-17 03:27:47 --> 404 Page Not Found: /index
INFO - 2018-05-17 03:27:47 --> Config Class Initialized
INFO - 2018-05-17 03:27:47 --> Hooks Class Initialized
DEBUG - 2018-05-17 03:27:47 --> UTF-8 Support Enabled
INFO - 2018-05-17 03:27:47 --> Utf8 Class Initialized
INFO - 2018-05-17 03:27:47 --> URI Class Initialized
INFO - 2018-05-17 03:27:47 --> Router Class Initialized
INFO - 2018-05-17 03:27:47 --> Output Class Initialized
INFO - 2018-05-17 03:27:47 --> Security Class Initialized
DEBUG - 2018-05-17 03:27:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 03:27:47 --> Input Class Initialized
INFO - 2018-05-17 03:27:47 --> Language Class Initialized
ERROR - 2018-05-17 03:27:47 --> 404 Page Not Found: /index
INFO - 2018-05-17 03:27:47 --> Config Class Initialized
INFO - 2018-05-17 03:27:47 --> Hooks Class Initialized
DEBUG - 2018-05-17 03:27:47 --> UTF-8 Support Enabled
INFO - 2018-05-17 03:27:47 --> Utf8 Class Initialized
INFO - 2018-05-17 03:27:47 --> URI Class Initialized
INFO - 2018-05-17 03:27:47 --> Router Class Initialized
INFO - 2018-05-17 03:27:47 --> Output Class Initialized
INFO - 2018-05-17 03:27:47 --> Security Class Initialized
DEBUG - 2018-05-17 03:27:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 03:27:47 --> Input Class Initialized
INFO - 2018-05-17 03:27:47 --> Language Class Initialized
ERROR - 2018-05-17 03:27:47 --> 404 Page Not Found: /index
INFO - 2018-05-17 03:27:52 --> Config Class Initialized
INFO - 2018-05-17 03:27:52 --> Hooks Class Initialized
DEBUG - 2018-05-17 03:27:52 --> UTF-8 Support Enabled
INFO - 2018-05-17 03:27:52 --> Utf8 Class Initialized
INFO - 2018-05-17 03:27:52 --> URI Class Initialized
INFO - 2018-05-17 03:27:52 --> Router Class Initialized
INFO - 2018-05-17 03:27:53 --> Output Class Initialized
INFO - 2018-05-17 03:27:53 --> Security Class Initialized
DEBUG - 2018-05-17 03:27:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 03:27:53 --> Input Class Initialized
INFO - 2018-05-17 03:27:53 --> Language Class Initialized
ERROR - 2018-05-17 03:27:53 --> 404 Page Not Found: /index
INFO - 2018-05-17 03:27:53 --> Config Class Initialized
INFO - 2018-05-17 03:27:53 --> Hooks Class Initialized
DEBUG - 2018-05-17 03:27:53 --> UTF-8 Support Enabled
INFO - 2018-05-17 03:27:53 --> Utf8 Class Initialized
INFO - 2018-05-17 03:27:53 --> URI Class Initialized
INFO - 2018-05-17 03:27:53 --> Router Class Initialized
INFO - 2018-05-17 03:27:53 --> Output Class Initialized
INFO - 2018-05-17 03:27:53 --> Security Class Initialized
DEBUG - 2018-05-17 03:27:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 03:27:53 --> Input Class Initialized
INFO - 2018-05-17 03:27:53 --> Language Class Initialized
ERROR - 2018-05-17 03:27:53 --> 404 Page Not Found: /index
INFO - 2018-05-17 03:27:53 --> Config Class Initialized
INFO - 2018-05-17 03:27:53 --> Hooks Class Initialized
DEBUG - 2018-05-17 03:27:53 --> UTF-8 Support Enabled
INFO - 2018-05-17 03:27:53 --> Utf8 Class Initialized
INFO - 2018-05-17 03:27:53 --> URI Class Initialized
INFO - 2018-05-17 03:27:53 --> Router Class Initialized
INFO - 2018-05-17 03:27:53 --> Output Class Initialized
INFO - 2018-05-17 03:27:53 --> Security Class Initialized
DEBUG - 2018-05-17 03:27:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 03:27:53 --> Input Class Initialized
INFO - 2018-05-17 03:27:53 --> Language Class Initialized
ERROR - 2018-05-17 03:27:53 --> 404 Page Not Found: /index
INFO - 2018-05-17 03:27:59 --> Config Class Initialized
INFO - 2018-05-17 03:27:59 --> Hooks Class Initialized
DEBUG - 2018-05-17 03:27:59 --> UTF-8 Support Enabled
INFO - 2018-05-17 03:27:59 --> Utf8 Class Initialized
INFO - 2018-05-17 03:27:59 --> URI Class Initialized
INFO - 2018-05-17 03:27:59 --> Router Class Initialized
INFO - 2018-05-17 03:27:59 --> Output Class Initialized
INFO - 2018-05-17 03:27:59 --> Security Class Initialized
DEBUG - 2018-05-17 03:27:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 03:27:59 --> Input Class Initialized
INFO - 2018-05-17 03:27:59 --> Language Class Initialized
INFO - 2018-05-17 03:27:59 --> Language Class Initialized
INFO - 2018-05-17 03:27:59 --> Config Class Initialized
INFO - 2018-05-17 03:27:59 --> Loader Class Initialized
DEBUG - 2018-05-17 03:27:59 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-17 03:27:59 --> Helper loaded: url_helper
INFO - 2018-05-17 03:27:59 --> Helper loaded: form_helper
INFO - 2018-05-17 03:27:59 --> Helper loaded: date_helper
INFO - 2018-05-17 03:27:59 --> Helper loaded: util_helper
INFO - 2018-05-17 03:27:59 --> Helper loaded: text_helper
INFO - 2018-05-17 03:27:59 --> Helper loaded: string_helper
INFO - 2018-05-17 03:27:59 --> Database Driver Class Initialized
DEBUG - 2018-05-17 03:27:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-17 03:27:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-17 03:27:59 --> Email Class Initialized
INFO - 2018-05-17 03:27:59 --> Controller Class Initialized
DEBUG - 2018-05-17 03:27:59 --> Home MX_Controller Initialized
DEBUG - 2018-05-17 03:27:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-17 03:27:59 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-17 03:27:59 --> Login MX_Controller Initialized
INFO - 2018-05-17 03:27:59 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-17 03:27:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-17 03:27:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-17 03:27:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-17 03:27:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-17 03:27:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-17 03:27:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-17 03:27:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-17 03:27:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-05-17 03:27:59 --> Final output sent to browser
DEBUG - 2018-05-17 03:27:59 --> Total execution time: 0.5902
INFO - 2018-05-17 03:28:00 --> Config Class Initialized
INFO - 2018-05-17 03:28:00 --> Config Class Initialized
INFO - 2018-05-17 03:28:00 --> Hooks Class Initialized
INFO - 2018-05-17 03:28:00 --> Hooks Class Initialized
DEBUG - 2018-05-17 03:28:00 --> UTF-8 Support Enabled
INFO - 2018-05-17 03:28:00 --> Utf8 Class Initialized
INFO - 2018-05-17 03:28:00 --> URI Class Initialized
INFO - 2018-05-17 03:28:00 --> Router Class Initialized
INFO - 2018-05-17 03:28:00 --> Output Class Initialized
DEBUG - 2018-05-17 03:28:00 --> UTF-8 Support Enabled
INFO - 2018-05-17 03:28:00 --> Security Class Initialized
DEBUG - 2018-05-17 03:28:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 03:28:00 --> Utf8 Class Initialized
INFO - 2018-05-17 03:28:00 --> Input Class Initialized
INFO - 2018-05-17 03:28:00 --> URI Class Initialized
INFO - 2018-05-17 03:28:00 --> Language Class Initialized
INFO - 2018-05-17 03:28:00 --> Router Class Initialized
ERROR - 2018-05-17 03:28:00 --> 404 Page Not Found: /index
INFO - 2018-05-17 03:28:00 --> Output Class Initialized
INFO - 2018-05-17 03:28:00 --> Security Class Initialized
DEBUG - 2018-05-17 03:28:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 03:28:00 --> Input Class Initialized
INFO - 2018-05-17 03:28:00 --> Language Class Initialized
ERROR - 2018-05-17 03:28:00 --> 404 Page Not Found: /index
INFO - 2018-05-17 03:28:00 --> Config Class Initialized
INFO - 2018-05-17 03:28:01 --> Hooks Class Initialized
DEBUG - 2018-05-17 03:28:01 --> UTF-8 Support Enabled
INFO - 2018-05-17 03:28:01 --> Utf8 Class Initialized
INFO - 2018-05-17 03:28:01 --> URI Class Initialized
INFO - 2018-05-17 03:28:01 --> Router Class Initialized
INFO - 2018-05-17 03:28:01 --> Output Class Initialized
INFO - 2018-05-17 03:28:01 --> Security Class Initialized
DEBUG - 2018-05-17 03:28:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 03:28:01 --> Input Class Initialized
INFO - 2018-05-17 03:28:01 --> Language Class Initialized
ERROR - 2018-05-17 03:28:01 --> 404 Page Not Found: /index
INFO - 2018-05-17 03:28:01 --> Config Class Initialized
INFO - 2018-05-17 03:28:01 --> Hooks Class Initialized
DEBUG - 2018-05-17 03:28:01 --> UTF-8 Support Enabled
INFO - 2018-05-17 03:28:01 --> Utf8 Class Initialized
INFO - 2018-05-17 03:28:01 --> URI Class Initialized
INFO - 2018-05-17 03:28:01 --> Router Class Initialized
INFO - 2018-05-17 03:28:01 --> Output Class Initialized
INFO - 2018-05-17 03:28:01 --> Security Class Initialized
DEBUG - 2018-05-17 03:28:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 03:28:01 --> Input Class Initialized
INFO - 2018-05-17 03:28:01 --> Language Class Initialized
ERROR - 2018-05-17 03:28:01 --> 404 Page Not Found: /index
INFO - 2018-05-17 03:28:03 --> Config Class Initialized
INFO - 2018-05-17 03:28:03 --> Hooks Class Initialized
DEBUG - 2018-05-17 03:28:03 --> UTF-8 Support Enabled
INFO - 2018-05-17 03:28:03 --> Utf8 Class Initialized
INFO - 2018-05-17 03:28:03 --> URI Class Initialized
INFO - 2018-05-17 03:28:03 --> Router Class Initialized
INFO - 2018-05-17 03:28:03 --> Output Class Initialized
INFO - 2018-05-17 03:28:03 --> Security Class Initialized
DEBUG - 2018-05-17 03:28:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 03:28:03 --> Input Class Initialized
INFO - 2018-05-17 03:28:03 --> Language Class Initialized
INFO - 2018-05-17 03:28:03 --> Language Class Initialized
INFO - 2018-05-17 03:28:03 --> Config Class Initialized
INFO - 2018-05-17 03:28:03 --> Loader Class Initialized
DEBUG - 2018-05-17 03:28:03 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-17 03:28:03 --> Helper loaded: url_helper
INFO - 2018-05-17 03:28:03 --> Helper loaded: form_helper
INFO - 2018-05-17 03:28:03 --> Helper loaded: date_helper
INFO - 2018-05-17 03:28:03 --> Helper loaded: util_helper
INFO - 2018-05-17 03:28:03 --> Helper loaded: text_helper
INFO - 2018-05-17 03:28:03 --> Helper loaded: string_helper
INFO - 2018-05-17 03:28:03 --> Database Driver Class Initialized
DEBUG - 2018-05-17 03:28:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-17 03:28:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-17 03:28:03 --> Email Class Initialized
INFO - 2018-05-17 03:28:03 --> Controller Class Initialized
DEBUG - 2018-05-17 03:28:03 --> Home MX_Controller Initialized
DEBUG - 2018-05-17 03:28:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-17 03:28:03 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-17 03:28:03 --> Login MX_Controller Initialized
INFO - 2018-05-17 03:28:03 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-17 03:28:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-17 03:28:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-17 03:28:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-17 03:28:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-17 03:28:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-17 03:28:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-17 03:28:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-17 03:28:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-05-17 03:28:03 --> Final output sent to browser
DEBUG - 2018-05-17 03:28:03 --> Total execution time: 0.6141
INFO - 2018-05-17 03:28:04 --> Config Class Initialized
INFO - 2018-05-17 03:28:04 --> Config Class Initialized
INFO - 2018-05-17 03:28:04 --> Hooks Class Initialized
INFO - 2018-05-17 03:28:04 --> Hooks Class Initialized
DEBUG - 2018-05-17 03:28:04 --> UTF-8 Support Enabled
INFO - 2018-05-17 03:28:04 --> Utf8 Class Initialized
INFO - 2018-05-17 03:28:04 --> URI Class Initialized
INFO - 2018-05-17 03:28:04 --> Router Class Initialized
INFO - 2018-05-17 03:28:04 --> Output Class Initialized
INFO - 2018-05-17 03:28:04 --> Security Class Initialized
DEBUG - 2018-05-17 03:28:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 03:28:04 --> Input Class Initialized
DEBUG - 2018-05-17 03:28:04 --> UTF-8 Support Enabled
INFO - 2018-05-17 03:28:04 --> Utf8 Class Initialized
INFO - 2018-05-17 03:28:04 --> Language Class Initialized
INFO - 2018-05-17 03:28:04 --> URI Class Initialized
ERROR - 2018-05-17 03:28:04 --> 404 Page Not Found: /index
INFO - 2018-05-17 03:28:04 --> Router Class Initialized
INFO - 2018-05-17 03:28:04 --> Output Class Initialized
INFO - 2018-05-17 03:28:05 --> Security Class Initialized
DEBUG - 2018-05-17 03:28:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 03:28:05 --> Input Class Initialized
INFO - 2018-05-17 03:28:05 --> Language Class Initialized
ERROR - 2018-05-17 03:28:05 --> 404 Page Not Found: /index
INFO - 2018-05-17 03:28:05 --> Config Class Initialized
INFO - 2018-05-17 03:28:05 --> Hooks Class Initialized
DEBUG - 2018-05-17 03:28:05 --> UTF-8 Support Enabled
INFO - 2018-05-17 03:28:05 --> Utf8 Class Initialized
INFO - 2018-05-17 03:28:05 --> URI Class Initialized
INFO - 2018-05-17 03:28:05 --> Router Class Initialized
INFO - 2018-05-17 03:28:05 --> Output Class Initialized
INFO - 2018-05-17 03:28:05 --> Security Class Initialized
DEBUG - 2018-05-17 03:28:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 03:28:05 --> Input Class Initialized
INFO - 2018-05-17 03:28:05 --> Language Class Initialized
ERROR - 2018-05-17 03:28:05 --> 404 Page Not Found: /index
INFO - 2018-05-17 03:28:05 --> Config Class Initialized
INFO - 2018-05-17 03:28:05 --> Hooks Class Initialized
DEBUG - 2018-05-17 03:28:05 --> UTF-8 Support Enabled
INFO - 2018-05-17 03:28:05 --> Utf8 Class Initialized
INFO - 2018-05-17 03:28:05 --> URI Class Initialized
INFO - 2018-05-17 03:28:05 --> Router Class Initialized
INFO - 2018-05-17 03:28:05 --> Output Class Initialized
INFO - 2018-05-17 03:28:05 --> Security Class Initialized
DEBUG - 2018-05-17 03:28:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 03:28:05 --> Input Class Initialized
INFO - 2018-05-17 03:28:05 --> Language Class Initialized
ERROR - 2018-05-17 03:28:05 --> 404 Page Not Found: /index
INFO - 2018-05-17 03:28:06 --> Config Class Initialized
INFO - 2018-05-17 03:28:06 --> Hooks Class Initialized
DEBUG - 2018-05-17 03:28:06 --> UTF-8 Support Enabled
INFO - 2018-05-17 03:28:07 --> Utf8 Class Initialized
INFO - 2018-05-17 03:28:07 --> URI Class Initialized
INFO - 2018-05-17 03:28:07 --> Router Class Initialized
INFO - 2018-05-17 03:28:07 --> Output Class Initialized
INFO - 2018-05-17 03:28:07 --> Security Class Initialized
DEBUG - 2018-05-17 03:28:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 03:28:07 --> Input Class Initialized
INFO - 2018-05-17 03:28:07 --> Language Class Initialized
INFO - 2018-05-17 03:28:07 --> Language Class Initialized
INFO - 2018-05-17 03:28:07 --> Config Class Initialized
INFO - 2018-05-17 03:28:07 --> Loader Class Initialized
DEBUG - 2018-05-17 03:28:07 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-17 03:28:07 --> Helper loaded: url_helper
INFO - 2018-05-17 03:28:07 --> Helper loaded: form_helper
INFO - 2018-05-17 03:28:07 --> Helper loaded: date_helper
INFO - 2018-05-17 03:28:07 --> Helper loaded: util_helper
INFO - 2018-05-17 03:28:07 --> Helper loaded: text_helper
INFO - 2018-05-17 03:28:07 --> Helper loaded: string_helper
INFO - 2018-05-17 03:28:07 --> Database Driver Class Initialized
DEBUG - 2018-05-17 03:28:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-17 03:28:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-17 03:28:07 --> Email Class Initialized
INFO - 2018-05-17 03:28:07 --> Controller Class Initialized
DEBUG - 2018-05-17 03:28:07 --> Home MX_Controller Initialized
DEBUG - 2018-05-17 03:28:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-17 03:28:07 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-17 03:28:07 --> Login MX_Controller Initialized
INFO - 2018-05-17 03:28:07 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-17 03:28:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-17 03:28:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-17 03:28:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-17 03:28:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-17 03:28:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-17 03:28:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-17 03:28:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-17 03:28:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-05-17 03:28:07 --> Final output sent to browser
DEBUG - 2018-05-17 03:28:07 --> Total execution time: 0.7382
INFO - 2018-05-17 03:30:45 --> Config Class Initialized
INFO - 2018-05-17 03:30:45 --> Hooks Class Initialized
DEBUG - 2018-05-17 03:30:45 --> UTF-8 Support Enabled
INFO - 2018-05-17 03:30:45 --> Utf8 Class Initialized
INFO - 2018-05-17 03:30:45 --> URI Class Initialized
INFO - 2018-05-17 03:30:45 --> Router Class Initialized
INFO - 2018-05-17 03:30:45 --> Output Class Initialized
INFO - 2018-05-17 03:30:45 --> Security Class Initialized
DEBUG - 2018-05-17 03:30:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 03:30:45 --> Input Class Initialized
INFO - 2018-05-17 03:30:45 --> Language Class Initialized
INFO - 2018-05-17 03:30:45 --> Language Class Initialized
INFO - 2018-05-17 03:30:45 --> Config Class Initialized
INFO - 2018-05-17 03:30:45 --> Loader Class Initialized
DEBUG - 2018-05-17 03:30:45 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-17 03:30:45 --> Helper loaded: url_helper
INFO - 2018-05-17 03:30:45 --> Helper loaded: form_helper
INFO - 2018-05-17 03:30:45 --> Helper loaded: date_helper
INFO - 2018-05-17 03:30:45 --> Helper loaded: util_helper
INFO - 2018-05-17 03:30:45 --> Helper loaded: text_helper
INFO - 2018-05-17 03:30:45 --> Helper loaded: string_helper
INFO - 2018-05-17 03:30:45 --> Database Driver Class Initialized
DEBUG - 2018-05-17 03:30:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-17 03:30:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-17 03:30:46 --> Email Class Initialized
INFO - 2018-05-17 03:30:46 --> Controller Class Initialized
DEBUG - 2018-05-17 03:30:46 --> Home MX_Controller Initialized
DEBUG - 2018-05-17 03:30:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-17 03:30:46 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-17 03:30:46 --> Login MX_Controller Initialized
INFO - 2018-05-17 03:30:46 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-17 03:30:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-17 03:30:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-17 03:30:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-17 03:30:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-17 03:30:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-17 03:30:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-17 03:30:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-17 03:30:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-05-17 03:30:46 --> Final output sent to browser
DEBUG - 2018-05-17 03:30:46 --> Total execution time: 0.5940
INFO - 2018-05-17 03:30:48 --> Config Class Initialized
INFO - 2018-05-17 03:30:48 --> Config Class Initialized
INFO - 2018-05-17 03:30:48 --> Hooks Class Initialized
DEBUG - 2018-05-17 03:30:48 --> UTF-8 Support Enabled
INFO - 2018-05-17 03:30:48 --> Hooks Class Initialized
INFO - 2018-05-17 03:30:48 --> Utf8 Class Initialized
DEBUG - 2018-05-17 03:30:48 --> UTF-8 Support Enabled
INFO - 2018-05-17 03:30:48 --> Utf8 Class Initialized
INFO - 2018-05-17 03:30:48 --> URI Class Initialized
INFO - 2018-05-17 03:30:48 --> Router Class Initialized
INFO - 2018-05-17 03:30:48 --> Output Class Initialized
INFO - 2018-05-17 03:30:48 --> URI Class Initialized
INFO - 2018-05-17 03:30:48 --> Router Class Initialized
INFO - 2018-05-17 03:30:48 --> Output Class Initialized
INFO - 2018-05-17 03:30:48 --> Security Class Initialized
DEBUG - 2018-05-17 03:30:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 03:30:48 --> Security Class Initialized
DEBUG - 2018-05-17 03:30:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 03:30:48 --> Input Class Initialized
INFO - 2018-05-17 03:30:48 --> Input Class Initialized
INFO - 2018-05-17 03:30:48 --> Language Class Initialized
ERROR - 2018-05-17 03:30:48 --> 404 Page Not Found: /index
INFO - 2018-05-17 03:30:48 --> Language Class Initialized
ERROR - 2018-05-17 03:30:48 --> 404 Page Not Found: /index
INFO - 2018-05-17 03:30:48 --> Config Class Initialized
INFO - 2018-05-17 03:30:48 --> Hooks Class Initialized
DEBUG - 2018-05-17 03:30:48 --> UTF-8 Support Enabled
INFO - 2018-05-17 03:30:48 --> Utf8 Class Initialized
INFO - 2018-05-17 03:30:48 --> URI Class Initialized
INFO - 2018-05-17 03:30:48 --> Router Class Initialized
INFO - 2018-05-17 03:30:48 --> Output Class Initialized
INFO - 2018-05-17 03:30:48 --> Security Class Initialized
DEBUG - 2018-05-17 03:30:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 03:30:48 --> Input Class Initialized
INFO - 2018-05-17 03:30:48 --> Language Class Initialized
ERROR - 2018-05-17 03:30:48 --> 404 Page Not Found: /index
INFO - 2018-05-17 03:30:48 --> Config Class Initialized
INFO - 2018-05-17 03:30:49 --> Hooks Class Initialized
DEBUG - 2018-05-17 03:30:49 --> UTF-8 Support Enabled
INFO - 2018-05-17 03:30:49 --> Utf8 Class Initialized
INFO - 2018-05-17 03:30:49 --> URI Class Initialized
INFO - 2018-05-17 03:30:49 --> Router Class Initialized
INFO - 2018-05-17 03:30:49 --> Output Class Initialized
INFO - 2018-05-17 03:30:49 --> Security Class Initialized
DEBUG - 2018-05-17 03:30:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 03:30:49 --> Input Class Initialized
INFO - 2018-05-17 03:30:49 --> Language Class Initialized
ERROR - 2018-05-17 03:30:49 --> 404 Page Not Found: /index
INFO - 2018-05-17 03:30:52 --> Config Class Initialized
INFO - 2018-05-17 03:30:52 --> Hooks Class Initialized
DEBUG - 2018-05-17 03:30:52 --> UTF-8 Support Enabled
INFO - 2018-05-17 03:30:52 --> Utf8 Class Initialized
INFO - 2018-05-17 03:30:52 --> URI Class Initialized
INFO - 2018-05-17 03:30:52 --> Router Class Initialized
INFO - 2018-05-17 03:30:52 --> Output Class Initialized
INFO - 2018-05-17 03:30:52 --> Security Class Initialized
DEBUG - 2018-05-17 03:30:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 03:30:52 --> Input Class Initialized
INFO - 2018-05-17 03:30:52 --> Language Class Initialized
INFO - 2018-05-17 03:30:52 --> Language Class Initialized
INFO - 2018-05-17 03:30:52 --> Config Class Initialized
INFO - 2018-05-17 03:30:52 --> Loader Class Initialized
DEBUG - 2018-05-17 03:30:52 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-17 03:30:52 --> Helper loaded: url_helper
INFO - 2018-05-17 03:30:52 --> Helper loaded: form_helper
INFO - 2018-05-17 03:30:52 --> Helper loaded: date_helper
INFO - 2018-05-17 03:30:52 --> Helper loaded: util_helper
INFO - 2018-05-17 03:30:53 --> Helper loaded: text_helper
INFO - 2018-05-17 03:30:53 --> Helper loaded: string_helper
INFO - 2018-05-17 03:30:53 --> Database Driver Class Initialized
DEBUG - 2018-05-17 03:30:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-17 03:30:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-17 03:30:53 --> Email Class Initialized
INFO - 2018-05-17 03:30:53 --> Controller Class Initialized
DEBUG - 2018-05-17 03:30:53 --> Home MX_Controller Initialized
DEBUG - 2018-05-17 03:30:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-17 03:30:53 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-17 03:30:53 --> Login MX_Controller Initialized
INFO - 2018-05-17 03:30:53 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-17 03:30:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-17 03:30:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-17 03:30:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-17 03:30:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-17 03:30:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-17 03:30:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-17 03:30:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-17 03:30:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-05-17 03:30:53 --> Final output sent to browser
DEBUG - 2018-05-17 03:30:53 --> Total execution time: 0.8404
INFO - 2018-05-17 03:30:54 --> Config Class Initialized
INFO - 2018-05-17 03:30:54 --> Config Class Initialized
INFO - 2018-05-17 03:30:54 --> Hooks Class Initialized
INFO - 2018-05-17 03:30:54 --> Hooks Class Initialized
DEBUG - 2018-05-17 03:30:54 --> UTF-8 Support Enabled
DEBUG - 2018-05-17 03:30:54 --> UTF-8 Support Enabled
INFO - 2018-05-17 03:30:54 --> Utf8 Class Initialized
INFO - 2018-05-17 03:30:54 --> URI Class Initialized
INFO - 2018-05-17 03:30:54 --> Router Class Initialized
INFO - 2018-05-17 03:30:54 --> Output Class Initialized
INFO - 2018-05-17 03:30:54 --> Security Class Initialized
INFO - 2018-05-17 03:30:54 --> Utf8 Class Initialized
DEBUG - 2018-05-17 03:30:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 03:30:54 --> URI Class Initialized
INFO - 2018-05-17 03:30:54 --> Input Class Initialized
INFO - 2018-05-17 03:30:54 --> Router Class Initialized
INFO - 2018-05-17 03:30:54 --> Language Class Initialized
INFO - 2018-05-17 03:30:54 --> Output Class Initialized
ERROR - 2018-05-17 03:30:54 --> 404 Page Not Found: /index
INFO - 2018-05-17 03:30:54 --> Security Class Initialized
DEBUG - 2018-05-17 03:30:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 03:30:54 --> Input Class Initialized
INFO - 2018-05-17 03:30:54 --> Language Class Initialized
ERROR - 2018-05-17 03:30:54 --> 404 Page Not Found: /index
INFO - 2018-05-17 03:30:55 --> Config Class Initialized
INFO - 2018-05-17 03:30:55 --> Hooks Class Initialized
DEBUG - 2018-05-17 03:30:55 --> UTF-8 Support Enabled
INFO - 2018-05-17 03:30:55 --> Utf8 Class Initialized
INFO - 2018-05-17 03:30:55 --> URI Class Initialized
INFO - 2018-05-17 03:30:55 --> Router Class Initialized
INFO - 2018-05-17 03:30:55 --> Output Class Initialized
INFO - 2018-05-17 03:30:55 --> Security Class Initialized
DEBUG - 2018-05-17 03:30:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 03:30:55 --> Input Class Initialized
INFO - 2018-05-17 03:30:55 --> Language Class Initialized
ERROR - 2018-05-17 03:30:55 --> 404 Page Not Found: /index
INFO - 2018-05-17 03:30:55 --> Config Class Initialized
INFO - 2018-05-17 03:30:56 --> Hooks Class Initialized
DEBUG - 2018-05-17 03:30:56 --> UTF-8 Support Enabled
INFO - 2018-05-17 03:30:56 --> Utf8 Class Initialized
INFO - 2018-05-17 03:30:56 --> URI Class Initialized
INFO - 2018-05-17 03:30:56 --> Router Class Initialized
INFO - 2018-05-17 03:30:56 --> Output Class Initialized
INFO - 2018-05-17 03:30:56 --> Security Class Initialized
DEBUG - 2018-05-17 03:30:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 03:30:56 --> Input Class Initialized
INFO - 2018-05-17 03:30:56 --> Language Class Initialized
ERROR - 2018-05-17 03:30:56 --> 404 Page Not Found: /index
INFO - 2018-05-17 03:30:59 --> Config Class Initialized
INFO - 2018-05-17 03:30:59 --> Hooks Class Initialized
DEBUG - 2018-05-17 03:30:59 --> UTF-8 Support Enabled
INFO - 2018-05-17 03:30:59 --> Utf8 Class Initialized
INFO - 2018-05-17 03:30:59 --> URI Class Initialized
INFO - 2018-05-17 03:30:59 --> Router Class Initialized
INFO - 2018-05-17 03:30:59 --> Output Class Initialized
INFO - 2018-05-17 03:30:59 --> Security Class Initialized
DEBUG - 2018-05-17 03:30:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 03:30:59 --> Input Class Initialized
INFO - 2018-05-17 03:30:59 --> Language Class Initialized
INFO - 2018-05-17 03:30:59 --> Language Class Initialized
INFO - 2018-05-17 03:30:59 --> Config Class Initialized
INFO - 2018-05-17 03:30:59 --> Loader Class Initialized
DEBUG - 2018-05-17 03:30:59 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-17 03:30:59 --> Helper loaded: url_helper
INFO - 2018-05-17 03:30:59 --> Helper loaded: form_helper
INFO - 2018-05-17 03:30:59 --> Helper loaded: date_helper
INFO - 2018-05-17 03:30:59 --> Helper loaded: util_helper
INFO - 2018-05-17 03:30:59 --> Helper loaded: text_helper
INFO - 2018-05-17 03:30:59 --> Helper loaded: string_helper
INFO - 2018-05-17 03:30:59 --> Database Driver Class Initialized
DEBUG - 2018-05-17 03:31:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-17 03:31:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-17 03:31:00 --> Email Class Initialized
INFO - 2018-05-17 03:31:00 --> Controller Class Initialized
DEBUG - 2018-05-17 03:31:00 --> Home MX_Controller Initialized
DEBUG - 2018-05-17 03:31:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-17 03:31:00 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-17 03:31:00 --> Login MX_Controller Initialized
INFO - 2018-05-17 03:31:00 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-17 03:31:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-17 03:31:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-17 03:31:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-17 03:31:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-17 03:31:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-17 03:31:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-17 03:31:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-17 03:31:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-05-17 03:31:00 --> Final output sent to browser
DEBUG - 2018-05-17 03:31:00 --> Total execution time: 0.6910
INFO - 2018-05-17 03:31:01 --> Config Class Initialized
INFO - 2018-05-17 03:31:01 --> Hooks Class Initialized
INFO - 2018-05-17 03:31:01 --> Config Class Initialized
DEBUG - 2018-05-17 03:31:01 --> UTF-8 Support Enabled
INFO - 2018-05-17 03:31:01 --> Utf8 Class Initialized
INFO - 2018-05-17 03:31:01 --> URI Class Initialized
INFO - 2018-05-17 03:31:01 --> Router Class Initialized
INFO - 2018-05-17 03:31:01 --> Hooks Class Initialized
INFO - 2018-05-17 03:31:01 --> Output Class Initialized
INFO - 2018-05-17 03:31:01 --> Security Class Initialized
DEBUG - 2018-05-17 03:31:01 --> UTF-8 Support Enabled
DEBUG - 2018-05-17 03:31:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 03:31:01 --> Input Class Initialized
INFO - 2018-05-17 03:31:01 --> Utf8 Class Initialized
INFO - 2018-05-17 03:31:01 --> Language Class Initialized
ERROR - 2018-05-17 03:31:01 --> 404 Page Not Found: /index
INFO - 2018-05-17 03:31:01 --> URI Class Initialized
INFO - 2018-05-17 03:31:01 --> Router Class Initialized
INFO - 2018-05-17 03:31:01 --> Output Class Initialized
INFO - 2018-05-17 03:31:01 --> Security Class Initialized
DEBUG - 2018-05-17 03:31:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 03:31:01 --> Input Class Initialized
INFO - 2018-05-17 03:31:01 --> Language Class Initialized
ERROR - 2018-05-17 03:31:01 --> 404 Page Not Found: /index
INFO - 2018-05-17 03:31:01 --> Config Class Initialized
INFO - 2018-05-17 03:31:01 --> Hooks Class Initialized
DEBUG - 2018-05-17 03:31:01 --> UTF-8 Support Enabled
INFO - 2018-05-17 03:31:02 --> Utf8 Class Initialized
INFO - 2018-05-17 03:31:02 --> URI Class Initialized
INFO - 2018-05-17 03:31:02 --> Router Class Initialized
INFO - 2018-05-17 03:31:02 --> Output Class Initialized
INFO - 2018-05-17 03:31:02 --> Security Class Initialized
DEBUG - 2018-05-17 03:31:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 03:31:02 --> Input Class Initialized
INFO - 2018-05-17 03:31:02 --> Language Class Initialized
ERROR - 2018-05-17 03:31:02 --> 404 Page Not Found: /index
INFO - 2018-05-17 03:31:02 --> Config Class Initialized
INFO - 2018-05-17 03:31:02 --> Hooks Class Initialized
DEBUG - 2018-05-17 03:31:02 --> UTF-8 Support Enabled
INFO - 2018-05-17 03:31:02 --> Utf8 Class Initialized
INFO - 2018-05-17 03:31:02 --> URI Class Initialized
INFO - 2018-05-17 03:31:02 --> Router Class Initialized
INFO - 2018-05-17 03:31:02 --> Output Class Initialized
INFO - 2018-05-17 03:31:02 --> Security Class Initialized
DEBUG - 2018-05-17 03:31:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 03:31:02 --> Input Class Initialized
INFO - 2018-05-17 03:31:02 --> Language Class Initialized
ERROR - 2018-05-17 03:31:02 --> 404 Page Not Found: /index
INFO - 2018-05-17 03:31:07 --> Config Class Initialized
INFO - 2018-05-17 03:31:07 --> Hooks Class Initialized
DEBUG - 2018-05-17 03:31:07 --> UTF-8 Support Enabled
INFO - 2018-05-17 03:31:07 --> Utf8 Class Initialized
INFO - 2018-05-17 03:31:07 --> URI Class Initialized
INFO - 2018-05-17 03:31:07 --> Router Class Initialized
INFO - 2018-05-17 03:31:07 --> Output Class Initialized
INFO - 2018-05-17 03:31:07 --> Security Class Initialized
DEBUG - 2018-05-17 03:31:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 03:31:07 --> Input Class Initialized
INFO - 2018-05-17 03:31:07 --> Language Class Initialized
INFO - 2018-05-17 03:31:07 --> Language Class Initialized
INFO - 2018-05-17 03:31:07 --> Config Class Initialized
INFO - 2018-05-17 03:31:07 --> Loader Class Initialized
DEBUG - 2018-05-17 03:31:07 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-17 03:31:07 --> Helper loaded: url_helper
INFO - 2018-05-17 03:31:07 --> Helper loaded: form_helper
INFO - 2018-05-17 03:31:07 --> Helper loaded: date_helper
INFO - 2018-05-17 03:31:07 --> Helper loaded: util_helper
INFO - 2018-05-17 03:31:07 --> Helper loaded: text_helper
INFO - 2018-05-17 03:31:07 --> Helper loaded: string_helper
INFO - 2018-05-17 03:31:07 --> Database Driver Class Initialized
DEBUG - 2018-05-17 03:31:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-17 03:31:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-17 03:31:07 --> Email Class Initialized
INFO - 2018-05-17 03:31:07 --> Controller Class Initialized
DEBUG - 2018-05-17 03:31:08 --> Home MX_Controller Initialized
DEBUG - 2018-05-17 03:31:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-17 03:31:08 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-17 03:31:08 --> Login MX_Controller Initialized
INFO - 2018-05-17 03:31:08 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-17 03:31:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-17 03:31:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-17 03:31:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-17 03:31:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-17 03:31:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-17 03:31:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-17 03:31:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-17 03:31:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-05-17 03:31:08 --> Final output sent to browser
DEBUG - 2018-05-17 03:31:08 --> Total execution time: 0.9685
INFO - 2018-05-17 03:31:09 --> Config Class Initialized
INFO - 2018-05-17 03:31:09 --> Config Class Initialized
INFO - 2018-05-17 03:31:09 --> Hooks Class Initialized
INFO - 2018-05-17 03:31:09 --> Hooks Class Initialized
DEBUG - 2018-05-17 03:31:09 --> UTF-8 Support Enabled
DEBUG - 2018-05-17 03:31:09 --> UTF-8 Support Enabled
INFO - 2018-05-17 03:31:09 --> Utf8 Class Initialized
INFO - 2018-05-17 03:31:09 --> Utf8 Class Initialized
INFO - 2018-05-17 03:31:09 --> URI Class Initialized
INFO - 2018-05-17 03:31:09 --> URI Class Initialized
INFO - 2018-05-17 03:31:09 --> Router Class Initialized
INFO - 2018-05-17 03:31:09 --> Output Class Initialized
INFO - 2018-05-17 03:31:09 --> Router Class Initialized
INFO - 2018-05-17 03:31:09 --> Security Class Initialized
DEBUG - 2018-05-17 03:31:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 03:31:09 --> Input Class Initialized
INFO - 2018-05-17 03:31:09 --> Output Class Initialized
INFO - 2018-05-17 03:31:09 --> Language Class Initialized
ERROR - 2018-05-17 03:31:09 --> 404 Page Not Found: /index
INFO - 2018-05-17 03:31:09 --> Security Class Initialized
DEBUG - 2018-05-17 03:31:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 03:31:09 --> Input Class Initialized
INFO - 2018-05-17 03:31:09 --> Language Class Initialized
ERROR - 2018-05-17 03:31:09 --> 404 Page Not Found: /index
INFO - 2018-05-17 03:31:10 --> Config Class Initialized
INFO - 2018-05-17 03:31:10 --> Hooks Class Initialized
DEBUG - 2018-05-17 03:31:10 --> UTF-8 Support Enabled
INFO - 2018-05-17 03:31:10 --> Utf8 Class Initialized
INFO - 2018-05-17 03:31:10 --> URI Class Initialized
INFO - 2018-05-17 03:31:10 --> Router Class Initialized
INFO - 2018-05-17 03:31:10 --> Output Class Initialized
INFO - 2018-05-17 03:31:10 --> Security Class Initialized
DEBUG - 2018-05-17 03:31:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 03:31:10 --> Input Class Initialized
INFO - 2018-05-17 03:31:10 --> Language Class Initialized
ERROR - 2018-05-17 03:31:10 --> 404 Page Not Found: /index
INFO - 2018-05-17 03:31:11 --> Config Class Initialized
INFO - 2018-05-17 03:31:11 --> Hooks Class Initialized
DEBUG - 2018-05-17 03:31:11 --> UTF-8 Support Enabled
INFO - 2018-05-17 03:31:11 --> Utf8 Class Initialized
INFO - 2018-05-17 03:31:11 --> URI Class Initialized
INFO - 2018-05-17 03:31:11 --> Router Class Initialized
INFO - 2018-05-17 03:31:11 --> Output Class Initialized
INFO - 2018-05-17 03:31:11 --> Security Class Initialized
DEBUG - 2018-05-17 03:31:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 03:31:11 --> Input Class Initialized
INFO - 2018-05-17 03:31:11 --> Language Class Initialized
ERROR - 2018-05-17 03:31:11 --> 404 Page Not Found: /index
INFO - 2018-05-17 03:31:13 --> Config Class Initialized
INFO - 2018-05-17 03:31:13 --> Hooks Class Initialized
DEBUG - 2018-05-17 03:31:13 --> UTF-8 Support Enabled
INFO - 2018-05-17 03:31:13 --> Utf8 Class Initialized
INFO - 2018-05-17 03:31:13 --> URI Class Initialized
INFO - 2018-05-17 03:31:13 --> Router Class Initialized
INFO - 2018-05-17 03:31:13 --> Output Class Initialized
INFO - 2018-05-17 03:31:13 --> Security Class Initialized
DEBUG - 2018-05-17 03:31:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 03:31:13 --> Input Class Initialized
INFO - 2018-05-17 03:31:13 --> Language Class Initialized
INFO - 2018-05-17 03:31:13 --> Language Class Initialized
INFO - 2018-05-17 03:31:13 --> Config Class Initialized
INFO - 2018-05-17 03:31:13 --> Loader Class Initialized
DEBUG - 2018-05-17 03:31:13 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-17 03:31:13 --> Helper loaded: url_helper
INFO - 2018-05-17 03:31:13 --> Helper loaded: form_helper
INFO - 2018-05-17 03:31:13 --> Helper loaded: date_helper
INFO - 2018-05-17 03:31:13 --> Helper loaded: util_helper
INFO - 2018-05-17 03:31:13 --> Helper loaded: text_helper
INFO - 2018-05-17 03:31:13 --> Helper loaded: string_helper
INFO - 2018-05-17 03:31:13 --> Database Driver Class Initialized
DEBUG - 2018-05-17 03:31:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-17 03:31:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-17 03:31:13 --> Email Class Initialized
INFO - 2018-05-17 03:31:13 --> Controller Class Initialized
DEBUG - 2018-05-17 03:31:13 --> Home MX_Controller Initialized
DEBUG - 2018-05-17 03:31:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-17 03:31:13 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-17 03:31:13 --> Login MX_Controller Initialized
INFO - 2018-05-17 03:31:14 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-17 03:31:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-17 03:31:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-17 03:31:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-17 03:31:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-17 03:31:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-17 03:31:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-17 03:31:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-17 03:31:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-05-17 03:31:14 --> Final output sent to browser
DEBUG - 2018-05-17 03:31:14 --> Total execution time: 0.9151
INFO - 2018-05-17 03:31:15 --> Config Class Initialized
INFO - 2018-05-17 03:31:15 --> Config Class Initialized
INFO - 2018-05-17 03:31:15 --> Hooks Class Initialized
INFO - 2018-05-17 03:31:15 --> Hooks Class Initialized
DEBUG - 2018-05-17 03:31:15 --> UTF-8 Support Enabled
INFO - 2018-05-17 03:31:15 --> Utf8 Class Initialized
INFO - 2018-05-17 03:31:15 --> URI Class Initialized
INFO - 2018-05-17 03:31:15 --> Router Class Initialized
INFO - 2018-05-17 03:31:15 --> Output Class Initialized
DEBUG - 2018-05-17 03:31:15 --> UTF-8 Support Enabled
INFO - 2018-05-17 03:31:15 --> Utf8 Class Initialized
INFO - 2018-05-17 03:31:15 --> Security Class Initialized
INFO - 2018-05-17 03:31:15 --> URI Class Initialized
INFO - 2018-05-17 03:31:15 --> Router Class Initialized
INFO - 2018-05-17 03:31:15 --> Output Class Initialized
INFO - 2018-05-17 03:31:15 --> Security Class Initialized
DEBUG - 2018-05-17 03:31:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-17 03:31:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 03:31:15 --> Input Class Initialized
INFO - 2018-05-17 03:31:15 --> Input Class Initialized
INFO - 2018-05-17 03:31:15 --> Language Class Initialized
INFO - 2018-05-17 03:31:15 --> Language Class Initialized
ERROR - 2018-05-17 03:31:15 --> 404 Page Not Found: /index
ERROR - 2018-05-17 03:31:15 --> 404 Page Not Found: /index
INFO - 2018-05-17 03:31:16 --> Config Class Initialized
INFO - 2018-05-17 03:31:16 --> Hooks Class Initialized
DEBUG - 2018-05-17 03:31:16 --> UTF-8 Support Enabled
INFO - 2018-05-17 03:31:16 --> Utf8 Class Initialized
INFO - 2018-05-17 03:31:16 --> URI Class Initialized
INFO - 2018-05-17 03:31:16 --> Router Class Initialized
INFO - 2018-05-17 03:31:16 --> Output Class Initialized
INFO - 2018-05-17 03:31:16 --> Security Class Initialized
DEBUG - 2018-05-17 03:31:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 03:31:16 --> Input Class Initialized
INFO - 2018-05-17 03:31:16 --> Language Class Initialized
ERROR - 2018-05-17 03:31:16 --> 404 Page Not Found: /index
INFO - 2018-05-17 03:31:16 --> Config Class Initialized
INFO - 2018-05-17 03:31:16 --> Hooks Class Initialized
DEBUG - 2018-05-17 03:31:16 --> UTF-8 Support Enabled
INFO - 2018-05-17 03:31:16 --> Utf8 Class Initialized
INFO - 2018-05-17 03:31:16 --> URI Class Initialized
INFO - 2018-05-17 03:31:16 --> Router Class Initialized
INFO - 2018-05-17 03:31:16 --> Output Class Initialized
INFO - 2018-05-17 03:31:17 --> Security Class Initialized
DEBUG - 2018-05-17 03:31:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 03:31:17 --> Input Class Initialized
INFO - 2018-05-17 03:31:17 --> Language Class Initialized
ERROR - 2018-05-17 03:31:17 --> 404 Page Not Found: /index
INFO - 2018-05-17 03:32:41 --> Config Class Initialized
INFO - 2018-05-17 03:32:41 --> Hooks Class Initialized
DEBUG - 2018-05-17 03:32:41 --> UTF-8 Support Enabled
INFO - 2018-05-17 03:32:41 --> Utf8 Class Initialized
INFO - 2018-05-17 03:32:41 --> URI Class Initialized
INFO - 2018-05-17 03:32:41 --> Router Class Initialized
INFO - 2018-05-17 03:32:41 --> Output Class Initialized
INFO - 2018-05-17 03:32:41 --> Security Class Initialized
DEBUG - 2018-05-17 03:32:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 03:32:41 --> Input Class Initialized
INFO - 2018-05-17 03:32:41 --> Language Class Initialized
INFO - 2018-05-17 03:32:41 --> Language Class Initialized
INFO - 2018-05-17 03:32:41 --> Config Class Initialized
INFO - 2018-05-17 03:32:41 --> Loader Class Initialized
DEBUG - 2018-05-17 03:32:41 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-17 03:32:41 --> Helper loaded: url_helper
INFO - 2018-05-17 03:32:41 --> Helper loaded: form_helper
INFO - 2018-05-17 03:32:41 --> Helper loaded: date_helper
INFO - 2018-05-17 03:32:41 --> Helper loaded: util_helper
INFO - 2018-05-17 03:32:41 --> Helper loaded: text_helper
INFO - 2018-05-17 03:32:41 --> Helper loaded: string_helper
INFO - 2018-05-17 03:32:41 --> Database Driver Class Initialized
DEBUG - 2018-05-17 03:32:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-17 03:32:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-17 03:32:41 --> Email Class Initialized
INFO - 2018-05-17 03:32:41 --> Controller Class Initialized
DEBUG - 2018-05-17 03:32:41 --> Home MX_Controller Initialized
DEBUG - 2018-05-17 03:32:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-17 03:32:42 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-17 03:32:42 --> Login MX_Controller Initialized
INFO - 2018-05-17 03:32:42 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-17 03:32:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-17 03:32:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-17 03:32:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-17 03:32:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-17 03:32:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-17 03:32:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-17 03:32:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-17 03:32:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-05-17 03:32:42 --> Final output sent to browser
DEBUG - 2018-05-17 03:32:42 --> Total execution time: 0.6226
INFO - 2018-05-17 03:32:43 --> Config Class Initialized
INFO - 2018-05-17 03:32:43 --> Config Class Initialized
INFO - 2018-05-17 03:32:43 --> Hooks Class Initialized
INFO - 2018-05-17 03:32:43 --> Hooks Class Initialized
DEBUG - 2018-05-17 03:32:43 --> UTF-8 Support Enabled
INFO - 2018-05-17 03:32:43 --> Utf8 Class Initialized
INFO - 2018-05-17 03:32:43 --> URI Class Initialized
INFO - 2018-05-17 03:32:43 --> Router Class Initialized
DEBUG - 2018-05-17 03:32:43 --> UTF-8 Support Enabled
INFO - 2018-05-17 03:32:43 --> Output Class Initialized
INFO - 2018-05-17 03:32:43 --> Utf8 Class Initialized
INFO - 2018-05-17 03:32:43 --> URI Class Initialized
INFO - 2018-05-17 03:32:43 --> Router Class Initialized
INFO - 2018-05-17 03:32:43 --> Security Class Initialized
INFO - 2018-05-17 03:32:43 --> Output Class Initialized
DEBUG - 2018-05-17 03:32:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 03:32:43 --> Input Class Initialized
INFO - 2018-05-17 03:32:43 --> Security Class Initialized
INFO - 2018-05-17 03:32:43 --> Language Class Initialized
DEBUG - 2018-05-17 03:32:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-05-17 03:32:43 --> 404 Page Not Found: /index
INFO - 2018-05-17 03:32:43 --> Input Class Initialized
INFO - 2018-05-17 03:32:43 --> Language Class Initialized
INFO - 2018-05-17 03:32:43 --> Config Class Initialized
INFO - 2018-05-17 03:32:43 --> Hooks Class Initialized
ERROR - 2018-05-17 03:32:43 --> 404 Page Not Found: /index
DEBUG - 2018-05-17 03:32:43 --> UTF-8 Support Enabled
INFO - 2018-05-17 03:32:43 --> Utf8 Class Initialized
INFO - 2018-05-17 03:32:43 --> URI Class Initialized
INFO - 2018-05-17 03:32:43 --> Router Class Initialized
INFO - 2018-05-17 03:32:43 --> Output Class Initialized
INFO - 2018-05-17 03:32:43 --> Security Class Initialized
DEBUG - 2018-05-17 03:32:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 03:32:43 --> Input Class Initialized
INFO - 2018-05-17 03:32:43 --> Language Class Initialized
ERROR - 2018-05-17 03:32:43 --> 404 Page Not Found: /index
INFO - 2018-05-17 03:32:43 --> Config Class Initialized
INFO - 2018-05-17 03:32:43 --> Hooks Class Initialized
DEBUG - 2018-05-17 03:32:43 --> UTF-8 Support Enabled
INFO - 2018-05-17 03:32:43 --> Utf8 Class Initialized
INFO - 2018-05-17 03:32:43 --> URI Class Initialized
INFO - 2018-05-17 03:32:44 --> Router Class Initialized
INFO - 2018-05-17 03:32:44 --> Output Class Initialized
INFO - 2018-05-17 03:32:44 --> Security Class Initialized
DEBUG - 2018-05-17 03:32:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 03:32:44 --> Input Class Initialized
INFO - 2018-05-17 03:32:44 --> Language Class Initialized
ERROR - 2018-05-17 03:32:44 --> 404 Page Not Found: /index
INFO - 2018-05-17 03:32:48 --> Config Class Initialized
INFO - 2018-05-17 03:32:48 --> Hooks Class Initialized
DEBUG - 2018-05-17 03:32:48 --> UTF-8 Support Enabled
INFO - 2018-05-17 03:32:48 --> Utf8 Class Initialized
INFO - 2018-05-17 03:32:48 --> URI Class Initialized
INFO - 2018-05-17 03:32:48 --> Router Class Initialized
INFO - 2018-05-17 03:32:48 --> Output Class Initialized
INFO - 2018-05-17 03:32:48 --> Security Class Initialized
DEBUG - 2018-05-17 03:32:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 03:32:48 --> Input Class Initialized
INFO - 2018-05-17 03:32:48 --> Language Class Initialized
ERROR - 2018-05-17 03:32:48 --> 404 Page Not Found: /index
INFO - 2018-05-17 03:32:48 --> Config Class Initialized
INFO - 2018-05-17 03:32:48 --> Hooks Class Initialized
DEBUG - 2018-05-17 03:32:48 --> UTF-8 Support Enabled
INFO - 2018-05-17 03:32:48 --> Utf8 Class Initialized
INFO - 2018-05-17 03:32:48 --> URI Class Initialized
INFO - 2018-05-17 03:32:48 --> Router Class Initialized
INFO - 2018-05-17 03:32:48 --> Output Class Initialized
INFO - 2018-05-17 03:32:48 --> Security Class Initialized
DEBUG - 2018-05-17 03:32:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 03:32:48 --> Input Class Initialized
INFO - 2018-05-17 03:32:48 --> Language Class Initialized
ERROR - 2018-05-17 03:32:48 --> 404 Page Not Found: /index
INFO - 2018-05-17 03:32:48 --> Config Class Initialized
INFO - 2018-05-17 03:32:48 --> Hooks Class Initialized
DEBUG - 2018-05-17 03:32:48 --> UTF-8 Support Enabled
INFO - 2018-05-17 03:32:48 --> Utf8 Class Initialized
INFO - 2018-05-17 03:32:48 --> URI Class Initialized
INFO - 2018-05-17 03:32:48 --> Router Class Initialized
INFO - 2018-05-17 03:32:48 --> Output Class Initialized
INFO - 2018-05-17 03:32:48 --> Security Class Initialized
DEBUG - 2018-05-17 03:32:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 03:32:48 --> Input Class Initialized
INFO - 2018-05-17 03:32:48 --> Language Class Initialized
ERROR - 2018-05-17 03:32:48 --> 404 Page Not Found: /index
INFO - 2018-05-17 03:32:57 --> Config Class Initialized
INFO - 2018-05-17 03:32:57 --> Hooks Class Initialized
DEBUG - 2018-05-17 03:32:57 --> UTF-8 Support Enabled
INFO - 2018-05-17 03:32:57 --> Utf8 Class Initialized
INFO - 2018-05-17 03:32:57 --> URI Class Initialized
INFO - 2018-05-17 03:32:58 --> Router Class Initialized
INFO - 2018-05-17 03:32:58 --> Output Class Initialized
INFO - 2018-05-17 03:32:58 --> Security Class Initialized
DEBUG - 2018-05-17 03:32:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 03:32:58 --> Input Class Initialized
INFO - 2018-05-17 03:32:58 --> Language Class Initialized
INFO - 2018-05-17 03:32:58 --> Language Class Initialized
INFO - 2018-05-17 03:32:58 --> Config Class Initialized
INFO - 2018-05-17 03:32:58 --> Loader Class Initialized
DEBUG - 2018-05-17 03:32:58 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-17 03:32:58 --> Helper loaded: url_helper
INFO - 2018-05-17 03:32:58 --> Helper loaded: form_helper
INFO - 2018-05-17 03:32:58 --> Helper loaded: date_helper
INFO - 2018-05-17 03:32:58 --> Helper loaded: util_helper
INFO - 2018-05-17 03:32:58 --> Helper loaded: text_helper
INFO - 2018-05-17 03:32:58 --> Helper loaded: string_helper
INFO - 2018-05-17 03:32:58 --> Database Driver Class Initialized
DEBUG - 2018-05-17 03:32:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-17 03:32:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-17 03:32:58 --> Email Class Initialized
INFO - 2018-05-17 03:32:58 --> Controller Class Initialized
DEBUG - 2018-05-17 03:32:58 --> Home MX_Controller Initialized
DEBUG - 2018-05-17 03:32:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-17 03:32:58 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-17 03:32:58 --> Login MX_Controller Initialized
INFO - 2018-05-17 03:32:58 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-17 03:32:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-17 03:32:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-17 03:32:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-17 03:32:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-17 03:32:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-17 03:32:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-17 03:32:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-17 03:32:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-05-17 03:32:58 --> Final output sent to browser
DEBUG - 2018-05-17 03:32:58 --> Total execution time: 0.6690
INFO - 2018-05-17 03:32:59 --> Config Class Initialized
INFO - 2018-05-17 03:32:59 --> Hooks Class Initialized
INFO - 2018-05-17 03:32:59 --> Config Class Initialized
DEBUG - 2018-05-17 03:32:59 --> UTF-8 Support Enabled
INFO - 2018-05-17 03:32:59 --> Utf8 Class Initialized
INFO - 2018-05-17 03:32:59 --> URI Class Initialized
INFO - 2018-05-17 03:32:59 --> Router Class Initialized
INFO - 2018-05-17 03:32:59 --> Output Class Initialized
INFO - 2018-05-17 03:32:59 --> Security Class Initialized
DEBUG - 2018-05-17 03:32:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 03:32:59 --> Input Class Initialized
INFO - 2018-05-17 03:32:59 --> Hooks Class Initialized
INFO - 2018-05-17 03:32:59 --> Language Class Initialized
DEBUG - 2018-05-17 03:32:59 --> UTF-8 Support Enabled
ERROR - 2018-05-17 03:32:59 --> 404 Page Not Found: /index
INFO - 2018-05-17 03:32:59 --> Utf8 Class Initialized
INFO - 2018-05-17 03:32:59 --> URI Class Initialized
INFO - 2018-05-17 03:32:59 --> Router Class Initialized
INFO - 2018-05-17 03:32:59 --> Output Class Initialized
INFO - 2018-05-17 03:32:59 --> Security Class Initialized
DEBUG - 2018-05-17 03:32:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 03:32:59 --> Input Class Initialized
INFO - 2018-05-17 03:32:59 --> Language Class Initialized
ERROR - 2018-05-17 03:32:59 --> 404 Page Not Found: /index
INFO - 2018-05-17 03:33:00 --> Config Class Initialized
INFO - 2018-05-17 03:33:00 --> Hooks Class Initialized
DEBUG - 2018-05-17 03:33:00 --> UTF-8 Support Enabled
INFO - 2018-05-17 03:33:00 --> Utf8 Class Initialized
INFO - 2018-05-17 03:33:00 --> URI Class Initialized
INFO - 2018-05-17 03:33:00 --> Router Class Initialized
INFO - 2018-05-17 03:33:00 --> Output Class Initialized
INFO - 2018-05-17 03:33:00 --> Security Class Initialized
DEBUG - 2018-05-17 03:33:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 03:33:00 --> Input Class Initialized
INFO - 2018-05-17 03:33:00 --> Language Class Initialized
ERROR - 2018-05-17 03:33:00 --> 404 Page Not Found: /index
INFO - 2018-05-17 03:33:00 --> Config Class Initialized
INFO - 2018-05-17 03:33:00 --> Hooks Class Initialized
DEBUG - 2018-05-17 03:33:00 --> UTF-8 Support Enabled
INFO - 2018-05-17 03:33:00 --> Utf8 Class Initialized
INFO - 2018-05-17 03:33:00 --> URI Class Initialized
INFO - 2018-05-17 03:33:00 --> Router Class Initialized
INFO - 2018-05-17 03:33:00 --> Output Class Initialized
INFO - 2018-05-17 03:33:00 --> Security Class Initialized
DEBUG - 2018-05-17 03:33:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 03:33:00 --> Input Class Initialized
INFO - 2018-05-17 03:33:00 --> Language Class Initialized
ERROR - 2018-05-17 03:33:00 --> 404 Page Not Found: /index
INFO - 2018-05-17 03:33:03 --> Config Class Initialized
INFO - 2018-05-17 03:33:03 --> Hooks Class Initialized
DEBUG - 2018-05-17 03:33:03 --> UTF-8 Support Enabled
INFO - 2018-05-17 03:33:03 --> Utf8 Class Initialized
INFO - 2018-05-17 03:33:03 --> URI Class Initialized
INFO - 2018-05-17 03:33:03 --> Router Class Initialized
INFO - 2018-05-17 03:33:03 --> Output Class Initialized
INFO - 2018-05-17 03:33:04 --> Security Class Initialized
DEBUG - 2018-05-17 03:33:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 03:33:04 --> Input Class Initialized
INFO - 2018-05-17 03:33:04 --> Language Class Initialized
ERROR - 2018-05-17 03:33:04 --> 404 Page Not Found: /index
INFO - 2018-05-17 03:33:04 --> Config Class Initialized
INFO - 2018-05-17 03:33:04 --> Hooks Class Initialized
DEBUG - 2018-05-17 03:33:04 --> UTF-8 Support Enabled
INFO - 2018-05-17 03:33:04 --> Utf8 Class Initialized
INFO - 2018-05-17 03:33:04 --> URI Class Initialized
INFO - 2018-05-17 03:33:04 --> Router Class Initialized
INFO - 2018-05-17 03:33:04 --> Output Class Initialized
INFO - 2018-05-17 03:33:04 --> Security Class Initialized
DEBUG - 2018-05-17 03:33:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 03:33:04 --> Input Class Initialized
INFO - 2018-05-17 03:33:04 --> Language Class Initialized
ERROR - 2018-05-17 03:33:04 --> 404 Page Not Found: /index
INFO - 2018-05-17 03:33:04 --> Config Class Initialized
INFO - 2018-05-17 03:33:04 --> Hooks Class Initialized
DEBUG - 2018-05-17 03:33:04 --> UTF-8 Support Enabled
INFO - 2018-05-17 03:33:04 --> Utf8 Class Initialized
INFO - 2018-05-17 03:33:04 --> URI Class Initialized
INFO - 2018-05-17 03:33:04 --> Router Class Initialized
INFO - 2018-05-17 03:33:04 --> Output Class Initialized
INFO - 2018-05-17 03:33:04 --> Security Class Initialized
DEBUG - 2018-05-17 03:33:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 03:33:04 --> Input Class Initialized
INFO - 2018-05-17 03:33:04 --> Language Class Initialized
ERROR - 2018-05-17 03:33:04 --> 404 Page Not Found: /index
INFO - 2018-05-17 03:33:06 --> Config Class Initialized
INFO - 2018-05-17 03:33:06 --> Hooks Class Initialized
DEBUG - 2018-05-17 03:33:06 --> UTF-8 Support Enabled
INFO - 2018-05-17 03:33:06 --> Utf8 Class Initialized
INFO - 2018-05-17 03:33:06 --> URI Class Initialized
INFO - 2018-05-17 03:33:06 --> Router Class Initialized
INFO - 2018-05-17 03:33:06 --> Output Class Initialized
INFO - 2018-05-17 03:33:06 --> Security Class Initialized
DEBUG - 2018-05-17 03:33:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 03:33:06 --> Input Class Initialized
INFO - 2018-05-17 03:33:06 --> Language Class Initialized
INFO - 2018-05-17 03:33:06 --> Language Class Initialized
INFO - 2018-05-17 03:33:06 --> Config Class Initialized
INFO - 2018-05-17 03:33:06 --> Loader Class Initialized
DEBUG - 2018-05-17 03:33:06 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-17 03:33:07 --> Helper loaded: url_helper
INFO - 2018-05-17 03:33:07 --> Helper loaded: form_helper
INFO - 2018-05-17 03:33:07 --> Helper loaded: date_helper
INFO - 2018-05-17 03:33:07 --> Helper loaded: util_helper
INFO - 2018-05-17 03:33:07 --> Helper loaded: text_helper
INFO - 2018-05-17 03:33:07 --> Helper loaded: string_helper
INFO - 2018-05-17 03:33:07 --> Database Driver Class Initialized
DEBUG - 2018-05-17 03:33:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-17 03:33:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-17 03:33:07 --> Email Class Initialized
INFO - 2018-05-17 03:33:07 --> Controller Class Initialized
DEBUG - 2018-05-17 03:33:07 --> Home MX_Controller Initialized
DEBUG - 2018-05-17 03:33:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-17 03:33:07 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-17 03:33:07 --> Login MX_Controller Initialized
INFO - 2018-05-17 03:33:07 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-17 03:33:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-17 03:33:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-17 03:33:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-17 03:33:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-17 03:33:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-17 03:33:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-17 03:33:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-17 03:33:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-05-17 03:33:07 --> Final output sent to browser
DEBUG - 2018-05-17 03:33:07 --> Total execution time: 0.6315
INFO - 2018-05-17 03:33:08 --> Config Class Initialized
INFO - 2018-05-17 03:33:08 --> Hooks Class Initialized
INFO - 2018-05-17 03:33:08 --> Config Class Initialized
INFO - 2018-05-17 03:33:08 --> Hooks Class Initialized
DEBUG - 2018-05-17 03:33:08 --> UTF-8 Support Enabled
DEBUG - 2018-05-17 03:33:08 --> UTF-8 Support Enabled
INFO - 2018-05-17 03:33:08 --> Utf8 Class Initialized
INFO - 2018-05-17 03:33:08 --> URI Class Initialized
INFO - 2018-05-17 03:33:08 --> Router Class Initialized
INFO - 2018-05-17 03:33:08 --> Utf8 Class Initialized
INFO - 2018-05-17 03:33:08 --> Output Class Initialized
INFO - 2018-05-17 03:33:08 --> Security Class Initialized
INFO - 2018-05-17 03:33:08 --> URI Class Initialized
INFO - 2018-05-17 03:33:08 --> Router Class Initialized
DEBUG - 2018-05-17 03:33:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 03:33:08 --> Input Class Initialized
INFO - 2018-05-17 03:33:08 --> Output Class Initialized
INFO - 2018-05-17 03:33:08 --> Language Class Initialized
ERROR - 2018-05-17 03:33:08 --> 404 Page Not Found: /index
INFO - 2018-05-17 03:33:08 --> Security Class Initialized
DEBUG - 2018-05-17 03:33:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 03:33:08 --> Input Class Initialized
INFO - 2018-05-17 03:33:08 --> Config Class Initialized
INFO - 2018-05-17 03:33:08 --> Hooks Class Initialized
INFO - 2018-05-17 03:33:08 --> Language Class Initialized
DEBUG - 2018-05-17 03:33:08 --> UTF-8 Support Enabled
ERROR - 2018-05-17 03:33:08 --> 404 Page Not Found: /index
INFO - 2018-05-17 03:33:08 --> Utf8 Class Initialized
INFO - 2018-05-17 03:33:08 --> URI Class Initialized
INFO - 2018-05-17 03:33:09 --> Router Class Initialized
INFO - 2018-05-17 03:33:09 --> Output Class Initialized
INFO - 2018-05-17 03:33:09 --> Security Class Initialized
DEBUG - 2018-05-17 03:33:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 03:33:09 --> Input Class Initialized
INFO - 2018-05-17 03:33:09 --> Language Class Initialized
ERROR - 2018-05-17 03:33:09 --> 404 Page Not Found: /index
INFO - 2018-05-17 03:33:09 --> Config Class Initialized
INFO - 2018-05-17 03:33:09 --> Hooks Class Initialized
DEBUG - 2018-05-17 03:33:09 --> UTF-8 Support Enabled
INFO - 2018-05-17 03:33:09 --> Utf8 Class Initialized
INFO - 2018-05-17 03:33:09 --> URI Class Initialized
INFO - 2018-05-17 03:33:09 --> Router Class Initialized
INFO - 2018-05-17 03:33:09 --> Output Class Initialized
INFO - 2018-05-17 03:33:09 --> Security Class Initialized
DEBUG - 2018-05-17 03:33:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 03:33:09 --> Input Class Initialized
INFO - 2018-05-17 03:33:09 --> Language Class Initialized
ERROR - 2018-05-17 03:33:09 --> 404 Page Not Found: /index
INFO - 2018-05-17 03:33:12 --> Config Class Initialized
INFO - 2018-05-17 03:33:12 --> Hooks Class Initialized
DEBUG - 2018-05-17 03:33:12 --> UTF-8 Support Enabled
INFO - 2018-05-17 03:33:12 --> Utf8 Class Initialized
INFO - 2018-05-17 03:33:12 --> URI Class Initialized
INFO - 2018-05-17 03:33:12 --> Router Class Initialized
INFO - 2018-05-17 03:33:12 --> Output Class Initialized
INFO - 2018-05-17 03:33:12 --> Security Class Initialized
DEBUG - 2018-05-17 03:33:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 03:33:12 --> Input Class Initialized
INFO - 2018-05-17 03:33:12 --> Language Class Initialized
ERROR - 2018-05-17 03:33:12 --> 404 Page Not Found: /index
INFO - 2018-05-17 03:33:12 --> Config Class Initialized
INFO - 2018-05-17 03:33:12 --> Hooks Class Initialized
DEBUG - 2018-05-17 03:33:12 --> UTF-8 Support Enabled
INFO - 2018-05-17 03:33:12 --> Utf8 Class Initialized
INFO - 2018-05-17 03:33:12 --> URI Class Initialized
INFO - 2018-05-17 03:33:12 --> Router Class Initialized
INFO - 2018-05-17 03:33:12 --> Output Class Initialized
INFO - 2018-05-17 03:33:12 --> Security Class Initialized
DEBUG - 2018-05-17 03:33:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 03:33:12 --> Input Class Initialized
INFO - 2018-05-17 03:33:12 --> Language Class Initialized
ERROR - 2018-05-17 03:33:12 --> 404 Page Not Found: /index
INFO - 2018-05-17 03:33:12 --> Config Class Initialized
INFO - 2018-05-17 03:33:12 --> Hooks Class Initialized
DEBUG - 2018-05-17 03:33:12 --> UTF-8 Support Enabled
INFO - 2018-05-17 03:33:12 --> Utf8 Class Initialized
INFO - 2018-05-17 03:33:12 --> URI Class Initialized
INFO - 2018-05-17 03:33:12 --> Router Class Initialized
INFO - 2018-05-17 03:33:12 --> Output Class Initialized
INFO - 2018-05-17 03:33:12 --> Security Class Initialized
DEBUG - 2018-05-17 03:33:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 03:33:12 --> Input Class Initialized
INFO - 2018-05-17 03:33:12 --> Language Class Initialized
ERROR - 2018-05-17 03:33:12 --> 404 Page Not Found: /index
INFO - 2018-05-17 03:39:07 --> Config Class Initialized
INFO - 2018-05-17 03:39:07 --> Hooks Class Initialized
DEBUG - 2018-05-17 03:39:07 --> UTF-8 Support Enabled
INFO - 2018-05-17 03:39:07 --> Utf8 Class Initialized
INFO - 2018-05-17 03:39:07 --> URI Class Initialized
INFO - 2018-05-17 03:39:07 --> Router Class Initialized
INFO - 2018-05-17 03:39:07 --> Output Class Initialized
INFO - 2018-05-17 03:39:07 --> Security Class Initialized
DEBUG - 2018-05-17 03:39:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 03:39:07 --> Input Class Initialized
INFO - 2018-05-17 03:39:07 --> Language Class Initialized
INFO - 2018-05-17 03:39:07 --> Language Class Initialized
INFO - 2018-05-17 03:39:07 --> Config Class Initialized
INFO - 2018-05-17 03:39:07 --> Loader Class Initialized
DEBUG - 2018-05-17 03:39:07 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-17 03:39:07 --> Helper loaded: url_helper
INFO - 2018-05-17 03:39:07 --> Helper loaded: form_helper
INFO - 2018-05-17 03:39:07 --> Helper loaded: date_helper
INFO - 2018-05-17 03:39:07 --> Helper loaded: util_helper
INFO - 2018-05-17 03:39:07 --> Helper loaded: text_helper
INFO - 2018-05-17 03:39:07 --> Helper loaded: string_helper
INFO - 2018-05-17 03:39:07 --> Database Driver Class Initialized
DEBUG - 2018-05-17 03:39:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-17 03:39:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-17 03:39:07 --> Email Class Initialized
INFO - 2018-05-17 03:39:07 --> Controller Class Initialized
DEBUG - 2018-05-17 03:39:08 --> Home MX_Controller Initialized
DEBUG - 2018-05-17 03:39:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-17 03:39:08 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-17 03:39:08 --> Login MX_Controller Initialized
INFO - 2018-05-17 03:39:08 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-17 03:39:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-17 03:39:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
ERROR - 2018-05-17 03:39:08 --> Query error: Unknown column 'chapter_id' in 'where clause' - Invalid query: SELECT *
FROM `programs`
WHERE `chapter_id` = '1'
INFO - 2018-05-17 03:39:08 --> Language file loaded: language/english/db_lang.php
INFO - 2018-05-17 03:39:27 --> Config Class Initialized
INFO - 2018-05-17 03:39:27 --> Hooks Class Initialized
DEBUG - 2018-05-17 03:39:27 --> UTF-8 Support Enabled
INFO - 2018-05-17 03:39:27 --> Utf8 Class Initialized
INFO - 2018-05-17 03:39:27 --> URI Class Initialized
INFO - 2018-05-17 03:39:27 --> Router Class Initialized
INFO - 2018-05-17 03:39:27 --> Output Class Initialized
INFO - 2018-05-17 03:39:27 --> Security Class Initialized
DEBUG - 2018-05-17 03:39:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 03:39:27 --> Input Class Initialized
INFO - 2018-05-17 03:39:27 --> Language Class Initialized
INFO - 2018-05-17 03:39:27 --> Language Class Initialized
INFO - 2018-05-17 03:39:27 --> Config Class Initialized
INFO - 2018-05-17 03:39:27 --> Loader Class Initialized
DEBUG - 2018-05-17 03:39:27 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-17 03:39:27 --> Helper loaded: url_helper
INFO - 2018-05-17 03:39:27 --> Helper loaded: form_helper
INFO - 2018-05-17 03:39:27 --> Helper loaded: date_helper
INFO - 2018-05-17 03:39:27 --> Helper loaded: util_helper
INFO - 2018-05-17 03:39:27 --> Helper loaded: text_helper
INFO - 2018-05-17 03:39:27 --> Helper loaded: string_helper
INFO - 2018-05-17 03:39:27 --> Database Driver Class Initialized
DEBUG - 2018-05-17 03:39:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-17 03:39:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-17 03:39:27 --> Email Class Initialized
INFO - 2018-05-17 03:39:27 --> Controller Class Initialized
DEBUG - 2018-05-17 03:39:27 --> Home MX_Controller Initialized
DEBUG - 2018-05-17 03:39:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-17 03:39:27 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-17 03:39:27 --> Login MX_Controller Initialized
INFO - 2018-05-17 03:39:27 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-17 03:39:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-17 03:39:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
ERROR - 2018-05-17 03:39:27 --> Severity: error --> Exception: Call to undefined method Home_model::get_program() E:\xampp\htdocs\consulting\application\modules\home\controllers\Home.php 31
INFO - 2018-05-17 03:40:00 --> Config Class Initialized
INFO - 2018-05-17 03:40:00 --> Hooks Class Initialized
DEBUG - 2018-05-17 03:40:00 --> UTF-8 Support Enabled
INFO - 2018-05-17 03:40:00 --> Utf8 Class Initialized
INFO - 2018-05-17 03:40:00 --> URI Class Initialized
INFO - 2018-05-17 03:40:00 --> Router Class Initialized
INFO - 2018-05-17 03:40:00 --> Output Class Initialized
INFO - 2018-05-17 03:40:00 --> Security Class Initialized
DEBUG - 2018-05-17 03:40:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 03:40:00 --> Input Class Initialized
INFO - 2018-05-17 03:40:00 --> Language Class Initialized
INFO - 2018-05-17 03:40:00 --> Language Class Initialized
INFO - 2018-05-17 03:40:00 --> Config Class Initialized
INFO - 2018-05-17 03:40:00 --> Loader Class Initialized
DEBUG - 2018-05-17 03:40:00 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-17 03:40:00 --> Helper loaded: url_helper
INFO - 2018-05-17 03:40:00 --> Helper loaded: form_helper
INFO - 2018-05-17 03:40:00 --> Helper loaded: date_helper
INFO - 2018-05-17 03:40:00 --> Helper loaded: util_helper
INFO - 2018-05-17 03:40:00 --> Helper loaded: text_helper
INFO - 2018-05-17 03:40:00 --> Helper loaded: string_helper
INFO - 2018-05-17 03:40:00 --> Database Driver Class Initialized
DEBUG - 2018-05-17 03:40:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-17 03:40:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-17 03:40:00 --> Email Class Initialized
INFO - 2018-05-17 03:40:00 --> Controller Class Initialized
DEBUG - 2018-05-17 03:40:00 --> Home MX_Controller Initialized
DEBUG - 2018-05-17 03:40:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-17 03:40:00 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-17 03:40:00 --> Login MX_Controller Initialized
INFO - 2018-05-17 03:40:00 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-17 03:40:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-17 03:40:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-17 03:43:47 --> Config Class Initialized
INFO - 2018-05-17 03:43:47 --> Hooks Class Initialized
DEBUG - 2018-05-17 03:43:47 --> UTF-8 Support Enabled
INFO - 2018-05-17 03:43:47 --> Utf8 Class Initialized
INFO - 2018-05-17 03:43:47 --> URI Class Initialized
INFO - 2018-05-17 03:43:47 --> Router Class Initialized
INFO - 2018-05-17 03:43:47 --> Output Class Initialized
INFO - 2018-05-17 03:43:47 --> Security Class Initialized
DEBUG - 2018-05-17 03:43:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 03:43:47 --> Input Class Initialized
INFO - 2018-05-17 03:43:47 --> Language Class Initialized
INFO - 2018-05-17 03:43:47 --> Language Class Initialized
INFO - 2018-05-17 03:43:47 --> Config Class Initialized
INFO - 2018-05-17 03:43:47 --> Loader Class Initialized
DEBUG - 2018-05-17 03:43:47 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-17 03:43:47 --> Helper loaded: url_helper
INFO - 2018-05-17 03:43:47 --> Helper loaded: form_helper
INFO - 2018-05-17 03:43:47 --> Helper loaded: date_helper
INFO - 2018-05-17 03:43:47 --> Helper loaded: util_helper
INFO - 2018-05-17 03:43:47 --> Helper loaded: text_helper
INFO - 2018-05-17 03:43:47 --> Helper loaded: string_helper
INFO - 2018-05-17 03:43:47 --> Database Driver Class Initialized
DEBUG - 2018-05-17 03:43:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-17 03:43:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-17 03:43:47 --> Email Class Initialized
INFO - 2018-05-17 03:43:47 --> Controller Class Initialized
DEBUG - 2018-05-17 03:43:47 --> Home MX_Controller Initialized
DEBUG - 2018-05-17 03:43:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-17 03:43:47 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-17 03:43:47 --> Login MX_Controller Initialized
INFO - 2018-05-17 03:43:47 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-17 03:43:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-17 03:43:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-17 03:43:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-17 03:43:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-17 03:43:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
ERROR - 2018-05-17 03:43:47 --> Severity: Notice --> Undefined variable: videos E:\xampp\htdocs\consulting\application\modules\home\views\course.php 135
ERROR - 2018-05-17 03:43:47 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\consulting\application\modules\home\views\course.php 135
DEBUG - 2018-05-17 03:43:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-17 03:43:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-17 03:43:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-05-17 03:43:48 --> Final output sent to browser
DEBUG - 2018-05-17 03:43:48 --> Total execution time: 0.6728
INFO - 2018-05-17 03:43:48 --> Config Class Initialized
INFO - 2018-05-17 03:43:48 --> Hooks Class Initialized
INFO - 2018-05-17 03:43:48 --> Config Class Initialized
INFO - 2018-05-17 03:43:48 --> Hooks Class Initialized
DEBUG - 2018-05-17 03:43:48 --> UTF-8 Support Enabled
DEBUG - 2018-05-17 03:43:48 --> UTF-8 Support Enabled
INFO - 2018-05-17 03:43:48 --> Utf8 Class Initialized
INFO - 2018-05-17 03:43:48 --> Utf8 Class Initialized
INFO - 2018-05-17 03:43:48 --> URI Class Initialized
INFO - 2018-05-17 03:43:48 --> URI Class Initialized
INFO - 2018-05-17 03:43:48 --> Router Class Initialized
INFO - 2018-05-17 03:43:48 --> Router Class Initialized
INFO - 2018-05-17 03:43:48 --> Output Class Initialized
INFO - 2018-05-17 03:43:48 --> Security Class Initialized
DEBUG - 2018-05-17 03:43:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 03:43:49 --> Input Class Initialized
INFO - 2018-05-17 03:43:49 --> Language Class Initialized
ERROR - 2018-05-17 03:43:49 --> 404 Page Not Found: /index
INFO - 2018-05-17 03:43:49 --> Output Class Initialized
INFO - 2018-05-17 03:43:49 --> Security Class Initialized
DEBUG - 2018-05-17 03:43:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 03:43:49 --> Input Class Initialized
INFO - 2018-05-17 03:43:49 --> Language Class Initialized
ERROR - 2018-05-17 03:43:49 --> 404 Page Not Found: /index
INFO - 2018-05-17 03:43:49 --> Config Class Initialized
INFO - 2018-05-17 03:43:49 --> Hooks Class Initialized
DEBUG - 2018-05-17 03:43:49 --> UTF-8 Support Enabled
INFO - 2018-05-17 03:43:49 --> Utf8 Class Initialized
INFO - 2018-05-17 03:43:49 --> URI Class Initialized
INFO - 2018-05-17 03:43:49 --> Router Class Initialized
INFO - 2018-05-17 03:43:49 --> Output Class Initialized
INFO - 2018-05-17 03:43:49 --> Security Class Initialized
DEBUG - 2018-05-17 03:43:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 03:43:49 --> Input Class Initialized
INFO - 2018-05-17 03:43:49 --> Language Class Initialized
ERROR - 2018-05-17 03:43:49 --> 404 Page Not Found: /index
INFO - 2018-05-17 03:43:49 --> Config Class Initialized
INFO - 2018-05-17 03:43:49 --> Hooks Class Initialized
DEBUG - 2018-05-17 03:43:49 --> UTF-8 Support Enabled
INFO - 2018-05-17 03:43:49 --> Utf8 Class Initialized
INFO - 2018-05-17 03:43:49 --> URI Class Initialized
INFO - 2018-05-17 03:43:49 --> Router Class Initialized
INFO - 2018-05-17 03:43:49 --> Output Class Initialized
INFO - 2018-05-17 03:43:49 --> Security Class Initialized
DEBUG - 2018-05-17 03:43:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 03:43:50 --> Input Class Initialized
INFO - 2018-05-17 03:43:50 --> Language Class Initialized
ERROR - 2018-05-17 03:43:50 --> 404 Page Not Found: /index
INFO - 2018-05-17 03:43:51 --> Config Class Initialized
INFO - 2018-05-17 03:43:52 --> Hooks Class Initialized
DEBUG - 2018-05-17 03:43:52 --> UTF-8 Support Enabled
INFO - 2018-05-17 03:43:52 --> Utf8 Class Initialized
INFO - 2018-05-17 03:43:52 --> URI Class Initialized
INFO - 2018-05-17 03:43:52 --> Router Class Initialized
INFO - 2018-05-17 03:43:52 --> Output Class Initialized
INFO - 2018-05-17 03:43:52 --> Security Class Initialized
DEBUG - 2018-05-17 03:43:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 03:43:52 --> Input Class Initialized
INFO - 2018-05-17 03:43:52 --> Language Class Initialized
ERROR - 2018-05-17 03:43:52 --> 404 Page Not Found: /index
INFO - 2018-05-17 03:43:52 --> Config Class Initialized
INFO - 2018-05-17 03:43:52 --> Hooks Class Initialized
DEBUG - 2018-05-17 03:43:52 --> UTF-8 Support Enabled
INFO - 2018-05-17 03:43:52 --> Utf8 Class Initialized
INFO - 2018-05-17 03:43:52 --> URI Class Initialized
INFO - 2018-05-17 03:43:52 --> Router Class Initialized
INFO - 2018-05-17 03:43:52 --> Output Class Initialized
INFO - 2018-05-17 03:43:52 --> Security Class Initialized
DEBUG - 2018-05-17 03:43:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 03:43:52 --> Input Class Initialized
INFO - 2018-05-17 03:43:52 --> Language Class Initialized
ERROR - 2018-05-17 03:43:52 --> 404 Page Not Found: /index
INFO - 2018-05-17 03:43:52 --> Config Class Initialized
INFO - 2018-05-17 03:43:52 --> Hooks Class Initialized
DEBUG - 2018-05-17 03:43:52 --> UTF-8 Support Enabled
INFO - 2018-05-17 03:43:52 --> Utf8 Class Initialized
INFO - 2018-05-17 03:43:52 --> URI Class Initialized
INFO - 2018-05-17 03:43:52 --> Router Class Initialized
INFO - 2018-05-17 03:43:52 --> Output Class Initialized
INFO - 2018-05-17 03:43:52 --> Security Class Initialized
DEBUG - 2018-05-17 03:43:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 03:43:52 --> Input Class Initialized
INFO - 2018-05-17 03:43:52 --> Language Class Initialized
ERROR - 2018-05-17 03:43:52 --> 404 Page Not Found: /index
INFO - 2018-05-17 03:45:27 --> Config Class Initialized
INFO - 2018-05-17 03:45:27 --> Hooks Class Initialized
DEBUG - 2018-05-17 03:45:27 --> UTF-8 Support Enabled
INFO - 2018-05-17 03:45:27 --> Utf8 Class Initialized
INFO - 2018-05-17 03:45:27 --> URI Class Initialized
INFO - 2018-05-17 03:45:27 --> Router Class Initialized
INFO - 2018-05-17 03:45:27 --> Output Class Initialized
INFO - 2018-05-17 03:45:27 --> Security Class Initialized
DEBUG - 2018-05-17 03:45:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 03:45:27 --> Input Class Initialized
INFO - 2018-05-17 03:45:27 --> Language Class Initialized
INFO - 2018-05-17 03:45:27 --> Language Class Initialized
INFO - 2018-05-17 03:45:27 --> Config Class Initialized
INFO - 2018-05-17 03:45:27 --> Loader Class Initialized
DEBUG - 2018-05-17 03:45:27 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-17 03:45:27 --> Helper loaded: url_helper
INFO - 2018-05-17 03:45:27 --> Helper loaded: form_helper
INFO - 2018-05-17 03:45:27 --> Helper loaded: date_helper
INFO - 2018-05-17 03:45:27 --> Helper loaded: util_helper
INFO - 2018-05-17 03:45:27 --> Helper loaded: text_helper
INFO - 2018-05-17 03:45:27 --> Helper loaded: string_helper
INFO - 2018-05-17 03:45:27 --> Database Driver Class Initialized
DEBUG - 2018-05-17 03:45:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-17 03:45:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-17 03:45:27 --> Email Class Initialized
INFO - 2018-05-17 03:45:27 --> Controller Class Initialized
DEBUG - 2018-05-17 03:45:27 --> Home MX_Controller Initialized
DEBUG - 2018-05-17 03:45:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-17 03:45:27 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-17 03:45:27 --> Login MX_Controller Initialized
INFO - 2018-05-17 03:45:27 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-17 03:45:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-17 03:45:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-17 03:47:14 --> Config Class Initialized
INFO - 2018-05-17 03:47:14 --> Hooks Class Initialized
DEBUG - 2018-05-17 03:47:14 --> UTF-8 Support Enabled
INFO - 2018-05-17 03:47:14 --> Utf8 Class Initialized
INFO - 2018-05-17 03:47:14 --> URI Class Initialized
INFO - 2018-05-17 03:47:14 --> Router Class Initialized
INFO - 2018-05-17 03:47:14 --> Output Class Initialized
INFO - 2018-05-17 03:47:14 --> Security Class Initialized
DEBUG - 2018-05-17 03:47:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 03:47:14 --> Input Class Initialized
INFO - 2018-05-17 03:47:14 --> Language Class Initialized
INFO - 2018-05-17 03:47:14 --> Language Class Initialized
INFO - 2018-05-17 03:47:14 --> Config Class Initialized
INFO - 2018-05-17 03:47:14 --> Loader Class Initialized
DEBUG - 2018-05-17 03:47:14 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-17 03:47:14 --> Helper loaded: url_helper
INFO - 2018-05-17 03:47:14 --> Helper loaded: form_helper
INFO - 2018-05-17 03:47:14 --> Helper loaded: date_helper
INFO - 2018-05-17 03:47:14 --> Helper loaded: util_helper
INFO - 2018-05-17 03:47:14 --> Helper loaded: text_helper
INFO - 2018-05-17 03:47:14 --> Helper loaded: string_helper
INFO - 2018-05-17 03:47:14 --> Database Driver Class Initialized
DEBUG - 2018-05-17 03:47:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-17 03:47:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-17 03:47:15 --> Email Class Initialized
INFO - 2018-05-17 03:47:15 --> Controller Class Initialized
DEBUG - 2018-05-17 03:47:15 --> Home MX_Controller Initialized
DEBUG - 2018-05-17 03:47:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-17 03:47:15 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-17 03:47:15 --> Login MX_Controller Initialized
INFO - 2018-05-17 03:47:15 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-17 03:47:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-17 03:47:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-17 03:47:26 --> Config Class Initialized
INFO - 2018-05-17 03:47:26 --> Hooks Class Initialized
DEBUG - 2018-05-17 03:47:26 --> UTF-8 Support Enabled
INFO - 2018-05-17 03:47:26 --> Utf8 Class Initialized
INFO - 2018-05-17 03:47:26 --> URI Class Initialized
INFO - 2018-05-17 03:47:26 --> Router Class Initialized
INFO - 2018-05-17 03:47:26 --> Output Class Initialized
INFO - 2018-05-17 03:47:26 --> Security Class Initialized
DEBUG - 2018-05-17 03:47:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 03:47:26 --> Input Class Initialized
INFO - 2018-05-17 03:47:26 --> Language Class Initialized
INFO - 2018-05-17 03:47:26 --> Language Class Initialized
INFO - 2018-05-17 03:47:26 --> Config Class Initialized
INFO - 2018-05-17 03:47:26 --> Loader Class Initialized
DEBUG - 2018-05-17 03:47:26 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-17 03:47:26 --> Helper loaded: url_helper
INFO - 2018-05-17 03:47:27 --> Helper loaded: form_helper
INFO - 2018-05-17 03:47:27 --> Helper loaded: date_helper
INFO - 2018-05-17 03:47:27 --> Helper loaded: util_helper
INFO - 2018-05-17 03:47:27 --> Helper loaded: text_helper
INFO - 2018-05-17 03:47:27 --> Helper loaded: string_helper
INFO - 2018-05-17 03:47:27 --> Database Driver Class Initialized
DEBUG - 2018-05-17 03:47:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-17 03:47:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-17 03:47:27 --> Email Class Initialized
INFO - 2018-05-17 03:47:27 --> Controller Class Initialized
DEBUG - 2018-05-17 03:47:27 --> Home MX_Controller Initialized
DEBUG - 2018-05-17 03:47:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-17 03:47:27 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-17 03:47:27 --> Login MX_Controller Initialized
INFO - 2018-05-17 03:47:27 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-17 03:47:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-17 03:47:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-17 03:47:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-17 03:47:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-17 03:47:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-17 03:47:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-17 03:47:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-17 03:47:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-05-17 03:47:27 --> Final output sent to browser
DEBUG - 2018-05-17 03:47:27 --> Total execution time: 0.6505
INFO - 2018-05-17 03:47:30 --> Config Class Initialized
INFO - 2018-05-17 03:47:30 --> Config Class Initialized
INFO - 2018-05-17 03:47:30 --> Hooks Class Initialized
INFO - 2018-05-17 03:47:30 --> Hooks Class Initialized
DEBUG - 2018-05-17 03:47:30 --> UTF-8 Support Enabled
INFO - 2018-05-17 03:47:30 --> Utf8 Class Initialized
INFO - 2018-05-17 03:47:30 --> URI Class Initialized
INFO - 2018-05-17 03:47:30 --> Router Class Initialized
INFO - 2018-05-17 03:47:30 --> Output Class Initialized
INFO - 2018-05-17 03:47:30 --> Security Class Initialized
DEBUG - 2018-05-17 03:47:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 03:47:30 --> Input Class Initialized
DEBUG - 2018-05-17 03:47:30 --> UTF-8 Support Enabled
INFO - 2018-05-17 03:47:30 --> Language Class Initialized
ERROR - 2018-05-17 03:47:30 --> 404 Page Not Found: /index
INFO - 2018-05-17 03:47:30 --> Utf8 Class Initialized
INFO - 2018-05-17 03:47:30 --> URI Class Initialized
INFO - 2018-05-17 03:47:30 --> Router Class Initialized
INFO - 2018-05-17 03:47:30 --> Output Class Initialized
INFO - 2018-05-17 03:47:30 --> Security Class Initialized
DEBUG - 2018-05-17 03:47:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 03:47:30 --> Input Class Initialized
INFO - 2018-05-17 03:47:30 --> Language Class Initialized
ERROR - 2018-05-17 03:47:30 --> 404 Page Not Found: /index
INFO - 2018-05-17 03:47:30 --> Config Class Initialized
INFO - 2018-05-17 03:47:30 --> Hooks Class Initialized
DEBUG - 2018-05-17 03:47:30 --> UTF-8 Support Enabled
INFO - 2018-05-17 03:47:30 --> Utf8 Class Initialized
INFO - 2018-05-17 03:47:31 --> URI Class Initialized
INFO - 2018-05-17 03:47:31 --> Router Class Initialized
INFO - 2018-05-17 03:47:31 --> Output Class Initialized
INFO - 2018-05-17 03:47:31 --> Security Class Initialized
DEBUG - 2018-05-17 03:47:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 03:47:31 --> Input Class Initialized
INFO - 2018-05-17 03:47:31 --> Language Class Initialized
ERROR - 2018-05-17 03:47:31 --> 404 Page Not Found: /index
INFO - 2018-05-17 03:47:31 --> Config Class Initialized
INFO - 2018-05-17 03:47:31 --> Hooks Class Initialized
DEBUG - 2018-05-17 03:47:31 --> UTF-8 Support Enabled
INFO - 2018-05-17 03:47:31 --> Utf8 Class Initialized
INFO - 2018-05-17 03:47:31 --> URI Class Initialized
INFO - 2018-05-17 03:47:31 --> Router Class Initialized
INFO - 2018-05-17 03:47:31 --> Output Class Initialized
INFO - 2018-05-17 03:47:31 --> Security Class Initialized
DEBUG - 2018-05-17 03:47:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 03:47:31 --> Input Class Initialized
INFO - 2018-05-17 03:47:31 --> Language Class Initialized
ERROR - 2018-05-17 03:47:31 --> 404 Page Not Found: /index
INFO - 2018-05-17 03:47:34 --> Config Class Initialized
INFO - 2018-05-17 03:47:34 --> Hooks Class Initialized
DEBUG - 2018-05-17 03:47:34 --> UTF-8 Support Enabled
INFO - 2018-05-17 03:47:34 --> Utf8 Class Initialized
INFO - 2018-05-17 03:47:34 --> URI Class Initialized
INFO - 2018-05-17 03:47:34 --> Router Class Initialized
INFO - 2018-05-17 03:47:34 --> Output Class Initialized
INFO - 2018-05-17 03:47:34 --> Security Class Initialized
DEBUG - 2018-05-17 03:47:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 03:47:34 --> Input Class Initialized
INFO - 2018-05-17 03:47:34 --> Language Class Initialized
INFO - 2018-05-17 03:47:34 --> Language Class Initialized
INFO - 2018-05-17 03:47:34 --> Config Class Initialized
INFO - 2018-05-17 03:47:34 --> Loader Class Initialized
DEBUG - 2018-05-17 03:47:34 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-17 03:47:34 --> Helper loaded: url_helper
INFO - 2018-05-17 03:47:34 --> Helper loaded: form_helper
INFO - 2018-05-17 03:47:34 --> Helper loaded: date_helper
INFO - 2018-05-17 03:47:34 --> Helper loaded: util_helper
INFO - 2018-05-17 03:47:34 --> Helper loaded: text_helper
INFO - 2018-05-17 03:47:34 --> Helper loaded: string_helper
INFO - 2018-05-17 03:47:34 --> Database Driver Class Initialized
DEBUG - 2018-05-17 03:47:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-17 03:47:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-17 03:47:34 --> Email Class Initialized
INFO - 2018-05-17 03:47:34 --> Controller Class Initialized
DEBUG - 2018-05-17 03:47:34 --> Home MX_Controller Initialized
DEBUG - 2018-05-17 03:47:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-17 03:47:34 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-17 03:47:34 --> Login MX_Controller Initialized
INFO - 2018-05-17 03:47:34 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-17 03:47:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-17 03:47:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-17 03:47:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-17 03:47:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-17 03:47:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-17 03:47:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-17 03:47:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-17 03:47:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-05-17 03:47:34 --> Final output sent to browser
DEBUG - 2018-05-17 03:47:34 --> Total execution time: 0.6684
INFO - 2018-05-17 03:47:35 --> Config Class Initialized
INFO - 2018-05-17 03:47:35 --> Config Class Initialized
INFO - 2018-05-17 03:47:35 --> Hooks Class Initialized
INFO - 2018-05-17 03:47:35 --> Hooks Class Initialized
DEBUG - 2018-05-17 03:47:35 --> UTF-8 Support Enabled
INFO - 2018-05-17 03:47:35 --> Utf8 Class Initialized
INFO - 2018-05-17 03:47:35 --> URI Class Initialized
INFO - 2018-05-17 03:47:35 --> Router Class Initialized
INFO - 2018-05-17 03:47:35 --> Output Class Initialized
INFO - 2018-05-17 03:47:35 --> Security Class Initialized
DEBUG - 2018-05-17 03:47:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-17 03:47:35 --> UTF-8 Support Enabled
INFO - 2018-05-17 03:47:35 --> Input Class Initialized
INFO - 2018-05-17 03:47:35 --> Utf8 Class Initialized
INFO - 2018-05-17 03:47:35 --> Language Class Initialized
INFO - 2018-05-17 03:47:35 --> URI Class Initialized
ERROR - 2018-05-17 03:47:35 --> 404 Page Not Found: /index
INFO - 2018-05-17 03:47:35 --> Router Class Initialized
INFO - 2018-05-17 03:47:35 --> Output Class Initialized
INFO - 2018-05-17 03:47:36 --> Config Class Initialized
INFO - 2018-05-17 03:47:36 --> Hooks Class Initialized
INFO - 2018-05-17 03:47:36 --> Security Class Initialized
DEBUG - 2018-05-17 03:47:36 --> UTF-8 Support Enabled
INFO - 2018-05-17 03:47:36 --> Utf8 Class Initialized
DEBUG - 2018-05-17 03:47:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 03:47:36 --> URI Class Initialized
INFO - 2018-05-17 03:47:36 --> Input Class Initialized
INFO - 2018-05-17 03:47:36 --> Language Class Initialized
INFO - 2018-05-17 03:47:36 --> Router Class Initialized
INFO - 2018-05-17 03:47:36 --> Output Class Initialized
ERROR - 2018-05-17 03:47:36 --> 404 Page Not Found: /index
INFO - 2018-05-17 03:47:36 --> Security Class Initialized
DEBUG - 2018-05-17 03:47:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 03:47:36 --> Input Class Initialized
INFO - 2018-05-17 03:47:36 --> Language Class Initialized
ERROR - 2018-05-17 03:47:36 --> 404 Page Not Found: /index
INFO - 2018-05-17 03:47:36 --> Config Class Initialized
INFO - 2018-05-17 03:47:36 --> Hooks Class Initialized
DEBUG - 2018-05-17 03:47:36 --> UTF-8 Support Enabled
INFO - 2018-05-17 03:47:36 --> Utf8 Class Initialized
INFO - 2018-05-17 03:47:36 --> URI Class Initialized
INFO - 2018-05-17 03:47:36 --> Router Class Initialized
INFO - 2018-05-17 03:47:36 --> Output Class Initialized
INFO - 2018-05-17 03:47:36 --> Security Class Initialized
DEBUG - 2018-05-17 03:47:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 03:47:36 --> Input Class Initialized
INFO - 2018-05-17 03:47:36 --> Language Class Initialized
ERROR - 2018-05-17 03:47:36 --> 404 Page Not Found: /index
INFO - 2018-05-17 03:47:38 --> Config Class Initialized
INFO - 2018-05-17 03:47:39 --> Hooks Class Initialized
DEBUG - 2018-05-17 03:47:39 --> UTF-8 Support Enabled
INFO - 2018-05-17 03:47:39 --> Utf8 Class Initialized
INFO - 2018-05-17 03:47:39 --> URI Class Initialized
INFO - 2018-05-17 03:47:39 --> Router Class Initialized
INFO - 2018-05-17 03:47:39 --> Output Class Initialized
INFO - 2018-05-17 03:47:39 --> Security Class Initialized
DEBUG - 2018-05-17 03:47:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 03:47:39 --> Input Class Initialized
INFO - 2018-05-17 03:47:39 --> Language Class Initialized
INFO - 2018-05-17 03:47:39 --> Language Class Initialized
INFO - 2018-05-17 03:47:39 --> Config Class Initialized
INFO - 2018-05-17 03:47:39 --> Loader Class Initialized
DEBUG - 2018-05-17 03:47:39 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-17 03:47:39 --> Helper loaded: url_helper
INFO - 2018-05-17 03:47:39 --> Helper loaded: form_helper
INFO - 2018-05-17 03:47:39 --> Helper loaded: date_helper
INFO - 2018-05-17 03:47:39 --> Helper loaded: util_helper
INFO - 2018-05-17 03:47:39 --> Helper loaded: text_helper
INFO - 2018-05-17 03:47:39 --> Helper loaded: string_helper
INFO - 2018-05-17 03:47:39 --> Database Driver Class Initialized
DEBUG - 2018-05-17 03:47:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-17 03:47:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-17 03:47:39 --> Email Class Initialized
INFO - 2018-05-17 03:47:39 --> Controller Class Initialized
DEBUG - 2018-05-17 03:47:39 --> Home MX_Controller Initialized
DEBUG - 2018-05-17 03:47:39 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-17 03:47:39 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-17 03:47:39 --> Login MX_Controller Initialized
INFO - 2018-05-17 03:47:39 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-17 03:47:39 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-17 03:47:39 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-17 03:47:39 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-17 03:47:39 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-17 03:47:39 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-17 03:47:39 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-17 03:47:39 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-17 03:47:39 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-05-17 03:47:39 --> Final output sent to browser
DEBUG - 2018-05-17 03:47:39 --> Total execution time: 0.7109
INFO - 2018-05-17 03:47:40 --> Config Class Initialized
INFO - 2018-05-17 03:47:40 --> Config Class Initialized
INFO - 2018-05-17 03:47:40 --> Hooks Class Initialized
INFO - 2018-05-17 03:47:40 --> Hooks Class Initialized
DEBUG - 2018-05-17 03:47:40 --> UTF-8 Support Enabled
INFO - 2018-05-17 03:47:40 --> Utf8 Class Initialized
DEBUG - 2018-05-17 03:47:40 --> UTF-8 Support Enabled
INFO - 2018-05-17 03:47:40 --> URI Class Initialized
INFO - 2018-05-17 03:47:40 --> Utf8 Class Initialized
INFO - 2018-05-17 03:47:40 --> URI Class Initialized
INFO - 2018-05-17 03:47:40 --> Router Class Initialized
INFO - 2018-05-17 03:47:40 --> Output Class Initialized
INFO - 2018-05-17 03:47:40 --> Security Class Initialized
DEBUG - 2018-05-17 03:47:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 03:47:40 --> Input Class Initialized
INFO - 2018-05-17 03:47:40 --> Router Class Initialized
INFO - 2018-05-17 03:47:40 --> Language Class Initialized
INFO - 2018-05-17 03:47:40 --> Output Class Initialized
ERROR - 2018-05-17 03:47:40 --> 404 Page Not Found: /index
INFO - 2018-05-17 03:47:40 --> Security Class Initialized
DEBUG - 2018-05-17 03:47:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 03:47:41 --> Input Class Initialized
INFO - 2018-05-17 03:47:41 --> Language Class Initialized
ERROR - 2018-05-17 03:47:41 --> 404 Page Not Found: /index
INFO - 2018-05-17 03:47:41 --> Config Class Initialized
INFO - 2018-05-17 03:47:41 --> Hooks Class Initialized
DEBUG - 2018-05-17 03:47:41 --> UTF-8 Support Enabled
INFO - 2018-05-17 03:47:41 --> Utf8 Class Initialized
INFO - 2018-05-17 03:47:41 --> URI Class Initialized
INFO - 2018-05-17 03:47:41 --> Router Class Initialized
INFO - 2018-05-17 03:47:41 --> Output Class Initialized
INFO - 2018-05-17 03:47:41 --> Security Class Initialized
DEBUG - 2018-05-17 03:47:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 03:47:41 --> Input Class Initialized
INFO - 2018-05-17 03:47:41 --> Language Class Initialized
ERROR - 2018-05-17 03:47:41 --> 404 Page Not Found: /index
INFO - 2018-05-17 03:47:41 --> Config Class Initialized
INFO - 2018-05-17 03:47:41 --> Hooks Class Initialized
DEBUG - 2018-05-17 03:47:41 --> UTF-8 Support Enabled
INFO - 2018-05-17 03:47:41 --> Utf8 Class Initialized
INFO - 2018-05-17 03:47:41 --> URI Class Initialized
INFO - 2018-05-17 03:47:41 --> Router Class Initialized
INFO - 2018-05-17 03:47:41 --> Output Class Initialized
INFO - 2018-05-17 03:47:41 --> Security Class Initialized
DEBUG - 2018-05-17 03:47:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 03:47:41 --> Input Class Initialized
INFO - 2018-05-17 03:47:41 --> Language Class Initialized
ERROR - 2018-05-17 03:47:41 --> 404 Page Not Found: /index
INFO - 2018-05-17 03:47:42 --> Config Class Initialized
INFO - 2018-05-17 03:47:42 --> Hooks Class Initialized
DEBUG - 2018-05-17 03:47:42 --> UTF-8 Support Enabled
INFO - 2018-05-17 03:47:42 --> Utf8 Class Initialized
INFO - 2018-05-17 03:47:42 --> URI Class Initialized
INFO - 2018-05-17 03:47:42 --> Router Class Initialized
INFO - 2018-05-17 03:47:42 --> Output Class Initialized
INFO - 2018-05-17 03:47:42 --> Security Class Initialized
DEBUG - 2018-05-17 03:47:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 03:47:42 --> Input Class Initialized
INFO - 2018-05-17 03:47:42 --> Language Class Initialized
ERROR - 2018-05-17 03:47:42 --> 404 Page Not Found: /index
INFO - 2018-05-17 03:47:42 --> Config Class Initialized
INFO - 2018-05-17 03:47:42 --> Hooks Class Initialized
DEBUG - 2018-05-17 03:47:42 --> UTF-8 Support Enabled
INFO - 2018-05-17 03:47:42 --> Utf8 Class Initialized
INFO - 2018-05-17 03:47:42 --> URI Class Initialized
INFO - 2018-05-17 03:47:42 --> Router Class Initialized
INFO - 2018-05-17 03:47:42 --> Output Class Initialized
INFO - 2018-05-17 03:47:42 --> Security Class Initialized
DEBUG - 2018-05-17 03:47:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 03:47:42 --> Input Class Initialized
INFO - 2018-05-17 03:47:42 --> Language Class Initialized
ERROR - 2018-05-17 03:47:42 --> 404 Page Not Found: /index
INFO - 2018-05-17 03:47:42 --> Config Class Initialized
INFO - 2018-05-17 03:47:42 --> Config Class Initialized
INFO - 2018-05-17 03:47:42 --> Hooks Class Initialized
INFO - 2018-05-17 03:47:42 --> Hooks Class Initialized
DEBUG - 2018-05-17 03:47:42 --> UTF-8 Support Enabled
DEBUG - 2018-05-17 03:47:42 --> UTF-8 Support Enabled
INFO - 2018-05-17 03:47:42 --> Utf8 Class Initialized
INFO - 2018-05-17 03:47:42 --> Utf8 Class Initialized
INFO - 2018-05-17 03:47:42 --> URI Class Initialized
INFO - 2018-05-17 03:47:42 --> URI Class Initialized
INFO - 2018-05-17 03:47:42 --> Router Class Initialized
INFO - 2018-05-17 03:47:42 --> Router Class Initialized
INFO - 2018-05-17 03:47:42 --> Output Class Initialized
INFO - 2018-05-17 03:47:42 --> Output Class Initialized
INFO - 2018-05-17 03:47:43 --> Security Class Initialized
INFO - 2018-05-17 03:47:43 --> Security Class Initialized
DEBUG - 2018-05-17 03:47:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-17 03:47:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 03:47:43 --> Input Class Initialized
INFO - 2018-05-17 03:47:43 --> Language Class Initialized
ERROR - 2018-05-17 03:47:43 --> 404 Page Not Found: /index
INFO - 2018-05-17 03:47:43 --> Input Class Initialized
INFO - 2018-05-17 03:47:43 --> Language Class Initialized
INFO - 2018-05-17 03:47:43 --> Language Class Initialized
INFO - 2018-05-17 03:47:43 --> Config Class Initialized
INFO - 2018-05-17 03:47:43 --> Loader Class Initialized
DEBUG - 2018-05-17 03:47:43 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-17 03:47:43 --> Helper loaded: url_helper
INFO - 2018-05-17 03:47:43 --> Helper loaded: form_helper
INFO - 2018-05-17 03:47:43 --> Helper loaded: date_helper
INFO - 2018-05-17 03:47:43 --> Helper loaded: util_helper
INFO - 2018-05-17 03:47:43 --> Helper loaded: text_helper
INFO - 2018-05-17 03:47:43 --> Helper loaded: string_helper
INFO - 2018-05-17 03:47:43 --> Database Driver Class Initialized
DEBUG - 2018-05-17 03:47:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-17 03:47:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-17 03:47:43 --> Email Class Initialized
INFO - 2018-05-17 03:47:43 --> Controller Class Initialized
DEBUG - 2018-05-17 03:47:43 --> Home MX_Controller Initialized
DEBUG - 2018-05-17 03:47:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-17 03:47:43 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-17 03:47:43 --> Login MX_Controller Initialized
INFO - 2018-05-17 03:47:43 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-17 03:47:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-17 03:47:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-17 03:47:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-17 03:47:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-17 03:47:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-17 03:47:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-17 03:47:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-17 03:47:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-05-17 03:47:43 --> Final output sent to browser
DEBUG - 2018-05-17 03:47:43 --> Total execution time: 0.7935
INFO - 2018-05-17 03:47:44 --> Config Class Initialized
INFO - 2018-05-17 03:47:44 --> Hooks Class Initialized
DEBUG - 2018-05-17 03:47:44 --> UTF-8 Support Enabled
INFO - 2018-05-17 03:47:44 --> Utf8 Class Initialized
INFO - 2018-05-17 03:47:44 --> Config Class Initialized
INFO - 2018-05-17 03:47:44 --> Hooks Class Initialized
INFO - 2018-05-17 03:47:44 --> URI Class Initialized
DEBUG - 2018-05-17 03:47:44 --> UTF-8 Support Enabled
INFO - 2018-05-17 03:47:44 --> Utf8 Class Initialized
INFO - 2018-05-17 03:47:44 --> URI Class Initialized
INFO - 2018-05-17 03:47:44 --> Router Class Initialized
INFO - 2018-05-17 03:47:44 --> Output Class Initialized
INFO - 2018-05-17 03:47:44 --> Router Class Initialized
INFO - 2018-05-17 03:47:44 --> Output Class Initialized
INFO - 2018-05-17 03:47:44 --> Security Class Initialized
INFO - 2018-05-17 03:47:44 --> Security Class Initialized
DEBUG - 2018-05-17 03:47:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-17 03:47:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 03:47:44 --> Input Class Initialized
INFO - 2018-05-17 03:47:44 --> Input Class Initialized
INFO - 2018-05-17 03:47:44 --> Language Class Initialized
ERROR - 2018-05-17 03:47:44 --> 404 Page Not Found: /index
INFO - 2018-05-17 03:47:44 --> Language Class Initialized
ERROR - 2018-05-17 03:47:44 --> 404 Page Not Found: /index
INFO - 2018-05-17 03:47:45 --> Config Class Initialized
INFO - 2018-05-17 03:47:45 --> Hooks Class Initialized
DEBUG - 2018-05-17 03:47:45 --> UTF-8 Support Enabled
INFO - 2018-05-17 03:47:45 --> Utf8 Class Initialized
INFO - 2018-05-17 03:47:45 --> URI Class Initialized
INFO - 2018-05-17 03:47:45 --> Router Class Initialized
INFO - 2018-05-17 03:47:45 --> Output Class Initialized
INFO - 2018-05-17 03:47:45 --> Security Class Initialized
DEBUG - 2018-05-17 03:47:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 03:47:45 --> Input Class Initialized
INFO - 2018-05-17 03:47:45 --> Language Class Initialized
ERROR - 2018-05-17 03:47:45 --> 404 Page Not Found: /index
INFO - 2018-05-17 03:47:45 --> Config Class Initialized
INFO - 2018-05-17 03:47:45 --> Hooks Class Initialized
DEBUG - 2018-05-17 03:47:45 --> UTF-8 Support Enabled
INFO - 2018-05-17 03:47:45 --> Utf8 Class Initialized
INFO - 2018-05-17 03:47:45 --> URI Class Initialized
INFO - 2018-05-17 03:47:45 --> Router Class Initialized
INFO - 2018-05-17 03:47:45 --> Output Class Initialized
INFO - 2018-05-17 03:47:45 --> Security Class Initialized
DEBUG - 2018-05-17 03:47:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 03:47:45 --> Input Class Initialized
INFO - 2018-05-17 03:47:45 --> Language Class Initialized
ERROR - 2018-05-17 03:47:45 --> 404 Page Not Found: /index
INFO - 2018-05-17 03:55:29 --> Config Class Initialized
INFO - 2018-05-17 03:55:29 --> Hooks Class Initialized
DEBUG - 2018-05-17 03:55:29 --> UTF-8 Support Enabled
INFO - 2018-05-17 03:55:29 --> Utf8 Class Initialized
INFO - 2018-05-17 03:55:29 --> URI Class Initialized
INFO - 2018-05-17 03:55:29 --> Router Class Initialized
INFO - 2018-05-17 03:55:29 --> Output Class Initialized
INFO - 2018-05-17 03:55:29 --> Security Class Initialized
DEBUG - 2018-05-17 03:55:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 03:55:29 --> Input Class Initialized
INFO - 2018-05-17 03:55:29 --> Language Class Initialized
INFO - 2018-05-17 03:55:29 --> Language Class Initialized
INFO - 2018-05-17 03:55:29 --> Config Class Initialized
INFO - 2018-05-17 03:55:29 --> Loader Class Initialized
DEBUG - 2018-05-17 03:55:29 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-17 03:55:29 --> Helper loaded: url_helper
INFO - 2018-05-17 03:55:29 --> Helper loaded: form_helper
INFO - 2018-05-17 03:55:29 --> Helper loaded: date_helper
INFO - 2018-05-17 03:55:29 --> Helper loaded: util_helper
INFO - 2018-05-17 03:55:29 --> Helper loaded: text_helper
INFO - 2018-05-17 03:55:29 --> Helper loaded: string_helper
INFO - 2018-05-17 03:55:29 --> Database Driver Class Initialized
DEBUG - 2018-05-17 03:55:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-17 03:55:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-17 03:55:29 --> Email Class Initialized
INFO - 2018-05-17 03:55:29 --> Controller Class Initialized
DEBUG - 2018-05-17 03:55:29 --> Home MX_Controller Initialized
DEBUG - 2018-05-17 03:55:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-17 03:55:29 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-17 03:55:29 --> Login MX_Controller Initialized
INFO - 2018-05-17 03:55:29 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-17 03:55:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-17 03:55:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-17 03:55:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-17 03:55:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-17 03:55:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-17 03:55:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-17 03:55:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-17 03:55:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-05-17 03:55:30 --> Final output sent to browser
DEBUG - 2018-05-17 03:55:30 --> Total execution time: 0.6513
INFO - 2018-05-17 03:55:32 --> Config Class Initialized
INFO - 2018-05-17 03:55:32 --> Config Class Initialized
INFO - 2018-05-17 03:55:32 --> Hooks Class Initialized
INFO - 2018-05-17 03:55:32 --> Hooks Class Initialized
DEBUG - 2018-05-17 03:55:32 --> UTF-8 Support Enabled
DEBUG - 2018-05-17 03:55:32 --> UTF-8 Support Enabled
INFO - 2018-05-17 03:55:32 --> Utf8 Class Initialized
INFO - 2018-05-17 03:55:32 --> URI Class Initialized
INFO - 2018-05-17 03:55:32 --> Router Class Initialized
INFO - 2018-05-17 03:55:32 --> Output Class Initialized
INFO - 2018-05-17 03:55:32 --> Security Class Initialized
INFO - 2018-05-17 03:55:32 --> Utf8 Class Initialized
DEBUG - 2018-05-17 03:55:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 03:55:33 --> URI Class Initialized
INFO - 2018-05-17 03:55:33 --> Router Class Initialized
INFO - 2018-05-17 03:55:33 --> Output Class Initialized
INFO - 2018-05-17 03:55:33 --> Security Class Initialized
INFO - 2018-05-17 03:55:33 --> Input Class Initialized
DEBUG - 2018-05-17 03:55:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 03:55:33 --> Language Class Initialized
ERROR - 2018-05-17 03:55:33 --> 404 Page Not Found: /index
INFO - 2018-05-17 03:55:33 --> Input Class Initialized
INFO - 2018-05-17 03:55:33 --> Language Class Initialized
ERROR - 2018-05-17 03:55:33 --> 404 Page Not Found: /index
INFO - 2018-05-17 03:55:33 --> Config Class Initialized
INFO - 2018-05-17 03:55:33 --> Hooks Class Initialized
DEBUG - 2018-05-17 03:55:33 --> UTF-8 Support Enabled
INFO - 2018-05-17 03:55:33 --> Utf8 Class Initialized
INFO - 2018-05-17 03:55:33 --> URI Class Initialized
INFO - 2018-05-17 03:55:33 --> Router Class Initialized
INFO - 2018-05-17 03:55:33 --> Output Class Initialized
INFO - 2018-05-17 03:55:33 --> Security Class Initialized
DEBUG - 2018-05-17 03:55:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 03:55:33 --> Input Class Initialized
INFO - 2018-05-17 03:55:33 --> Language Class Initialized
ERROR - 2018-05-17 03:55:33 --> 404 Page Not Found: /index
INFO - 2018-05-17 03:55:33 --> Config Class Initialized
INFO - 2018-05-17 03:55:33 --> Hooks Class Initialized
DEBUG - 2018-05-17 03:55:33 --> UTF-8 Support Enabled
INFO - 2018-05-17 03:55:33 --> Utf8 Class Initialized
INFO - 2018-05-17 03:55:33 --> URI Class Initialized
INFO - 2018-05-17 03:55:33 --> Router Class Initialized
INFO - 2018-05-17 03:55:33 --> Output Class Initialized
INFO - 2018-05-17 03:55:33 --> Security Class Initialized
DEBUG - 2018-05-17 03:55:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 03:55:33 --> Input Class Initialized
INFO - 2018-05-17 03:55:33 --> Language Class Initialized
ERROR - 2018-05-17 03:55:33 --> 404 Page Not Found: /index
INFO - 2018-05-17 03:55:42 --> Config Class Initialized
INFO - 2018-05-17 03:55:42 --> Hooks Class Initialized
DEBUG - 2018-05-17 03:55:42 --> UTF-8 Support Enabled
INFO - 2018-05-17 03:55:42 --> Utf8 Class Initialized
INFO - 2018-05-17 03:55:42 --> URI Class Initialized
INFO - 2018-05-17 03:55:42 --> Router Class Initialized
INFO - 2018-05-17 03:55:42 --> Output Class Initialized
INFO - 2018-05-17 03:55:42 --> Security Class Initialized
DEBUG - 2018-05-17 03:55:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 03:55:42 --> Input Class Initialized
INFO - 2018-05-17 03:55:42 --> Language Class Initialized
ERROR - 2018-05-17 03:55:42 --> 404 Page Not Found: /index
INFO - 2018-05-17 03:55:42 --> Config Class Initialized
INFO - 2018-05-17 03:55:42 --> Hooks Class Initialized
DEBUG - 2018-05-17 03:55:42 --> UTF-8 Support Enabled
INFO - 2018-05-17 03:55:42 --> Utf8 Class Initialized
INFO - 2018-05-17 03:55:42 --> URI Class Initialized
INFO - 2018-05-17 03:55:42 --> Router Class Initialized
INFO - 2018-05-17 03:55:42 --> Output Class Initialized
INFO - 2018-05-17 03:55:42 --> Security Class Initialized
DEBUG - 2018-05-17 03:55:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 03:55:43 --> Input Class Initialized
INFO - 2018-05-17 03:55:43 --> Language Class Initialized
ERROR - 2018-05-17 03:55:43 --> 404 Page Not Found: /index
INFO - 2018-05-17 03:55:43 --> Config Class Initialized
INFO - 2018-05-17 03:55:43 --> Hooks Class Initialized
DEBUG - 2018-05-17 03:55:43 --> UTF-8 Support Enabled
INFO - 2018-05-17 03:55:43 --> Utf8 Class Initialized
INFO - 2018-05-17 03:55:43 --> URI Class Initialized
INFO - 2018-05-17 03:55:43 --> Router Class Initialized
INFO - 2018-05-17 03:55:43 --> Output Class Initialized
INFO - 2018-05-17 03:55:43 --> Security Class Initialized
DEBUG - 2018-05-17 03:55:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 03:55:43 --> Input Class Initialized
INFO - 2018-05-17 03:55:43 --> Language Class Initialized
ERROR - 2018-05-17 03:55:43 --> 404 Page Not Found: /index
INFO - 2018-05-17 03:59:10 --> Config Class Initialized
INFO - 2018-05-17 03:59:10 --> Hooks Class Initialized
DEBUG - 2018-05-17 03:59:10 --> UTF-8 Support Enabled
INFO - 2018-05-17 03:59:10 --> Utf8 Class Initialized
INFO - 2018-05-17 03:59:10 --> URI Class Initialized
INFO - 2018-05-17 03:59:10 --> Router Class Initialized
INFO - 2018-05-17 03:59:10 --> Output Class Initialized
INFO - 2018-05-17 03:59:10 --> Security Class Initialized
DEBUG - 2018-05-17 03:59:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 03:59:11 --> Input Class Initialized
INFO - 2018-05-17 03:59:11 --> Language Class Initialized
INFO - 2018-05-17 03:59:11 --> Language Class Initialized
INFO - 2018-05-17 03:59:11 --> Config Class Initialized
INFO - 2018-05-17 03:59:11 --> Loader Class Initialized
DEBUG - 2018-05-17 03:59:11 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-17 03:59:11 --> Helper loaded: url_helper
INFO - 2018-05-17 03:59:11 --> Helper loaded: form_helper
INFO - 2018-05-17 03:59:11 --> Helper loaded: date_helper
INFO - 2018-05-17 03:59:11 --> Helper loaded: util_helper
INFO - 2018-05-17 03:59:11 --> Helper loaded: text_helper
INFO - 2018-05-17 03:59:11 --> Helper loaded: string_helper
INFO - 2018-05-17 03:59:11 --> Database Driver Class Initialized
DEBUG - 2018-05-17 03:59:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-17 03:59:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-17 03:59:11 --> Email Class Initialized
INFO - 2018-05-17 03:59:11 --> Controller Class Initialized
DEBUG - 2018-05-17 03:59:11 --> Home MX_Controller Initialized
DEBUG - 2018-05-17 03:59:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-17 03:59:11 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-17 03:59:11 --> Login MX_Controller Initialized
INFO - 2018-05-17 03:59:11 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-17 03:59:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-17 03:59:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-17 04:05:52 --> Config Class Initialized
INFO - 2018-05-17 04:05:52 --> Hooks Class Initialized
DEBUG - 2018-05-17 04:05:52 --> UTF-8 Support Enabled
INFO - 2018-05-17 04:05:52 --> Utf8 Class Initialized
INFO - 2018-05-17 04:05:52 --> URI Class Initialized
INFO - 2018-05-17 04:05:52 --> Router Class Initialized
INFO - 2018-05-17 04:05:52 --> Output Class Initialized
INFO - 2018-05-17 04:05:52 --> Security Class Initialized
DEBUG - 2018-05-17 04:05:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 04:05:52 --> Input Class Initialized
INFO - 2018-05-17 04:05:52 --> Language Class Initialized
INFO - 2018-05-17 04:05:52 --> Language Class Initialized
INFO - 2018-05-17 04:05:52 --> Config Class Initialized
INFO - 2018-05-17 04:05:52 --> Loader Class Initialized
DEBUG - 2018-05-17 04:05:52 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-17 04:05:52 --> Helper loaded: url_helper
INFO - 2018-05-17 04:05:52 --> Helper loaded: form_helper
INFO - 2018-05-17 04:05:52 --> Helper loaded: date_helper
INFO - 2018-05-17 04:05:52 --> Helper loaded: util_helper
INFO - 2018-05-17 04:05:52 --> Helper loaded: text_helper
INFO - 2018-05-17 04:05:52 --> Helper loaded: string_helper
INFO - 2018-05-17 04:05:52 --> Database Driver Class Initialized
DEBUG - 2018-05-17 04:05:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-17 04:05:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-17 04:05:52 --> Email Class Initialized
INFO - 2018-05-17 04:05:52 --> Controller Class Initialized
DEBUG - 2018-05-17 04:05:52 --> Home MX_Controller Initialized
DEBUG - 2018-05-17 04:05:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-17 04:05:52 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-17 04:05:52 --> Login MX_Controller Initialized
INFO - 2018-05-17 04:05:52 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-17 04:05:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-17 04:05:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-17 04:06:17 --> Config Class Initialized
INFO - 2018-05-17 04:06:17 --> Hooks Class Initialized
DEBUG - 2018-05-17 04:06:17 --> UTF-8 Support Enabled
INFO - 2018-05-17 04:06:17 --> Utf8 Class Initialized
INFO - 2018-05-17 04:06:17 --> URI Class Initialized
INFO - 2018-05-17 04:06:17 --> Router Class Initialized
INFO - 2018-05-17 04:06:17 --> Output Class Initialized
INFO - 2018-05-17 04:06:17 --> Security Class Initialized
DEBUG - 2018-05-17 04:06:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 04:06:17 --> Input Class Initialized
INFO - 2018-05-17 04:06:17 --> Language Class Initialized
INFO - 2018-05-17 04:06:17 --> Language Class Initialized
INFO - 2018-05-17 04:06:17 --> Config Class Initialized
INFO - 2018-05-17 04:06:17 --> Loader Class Initialized
DEBUG - 2018-05-17 04:06:17 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-17 04:06:17 --> Helper loaded: url_helper
INFO - 2018-05-17 04:06:17 --> Helper loaded: form_helper
INFO - 2018-05-17 04:06:17 --> Helper loaded: date_helper
INFO - 2018-05-17 04:06:17 --> Helper loaded: util_helper
INFO - 2018-05-17 04:06:17 --> Helper loaded: text_helper
INFO - 2018-05-17 04:06:17 --> Helper loaded: string_helper
INFO - 2018-05-17 04:06:17 --> Database Driver Class Initialized
DEBUG - 2018-05-17 04:06:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-17 04:06:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-17 04:06:17 --> Email Class Initialized
INFO - 2018-05-17 04:06:17 --> Controller Class Initialized
DEBUG - 2018-05-17 04:06:17 --> Home MX_Controller Initialized
DEBUG - 2018-05-17 04:06:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-17 04:06:17 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-17 04:06:17 --> Login MX_Controller Initialized
INFO - 2018-05-17 04:06:17 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-17 04:06:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-17 04:06:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-17 04:47:29 --> Config Class Initialized
INFO - 2018-05-17 04:47:29 --> Hooks Class Initialized
DEBUG - 2018-05-17 04:47:29 --> UTF-8 Support Enabled
INFO - 2018-05-17 04:47:29 --> Utf8 Class Initialized
INFO - 2018-05-17 04:47:29 --> URI Class Initialized
INFO - 2018-05-17 04:47:29 --> Router Class Initialized
INFO - 2018-05-17 04:47:29 --> Output Class Initialized
INFO - 2018-05-17 04:47:29 --> Security Class Initialized
DEBUG - 2018-05-17 04:47:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 04:47:29 --> Input Class Initialized
INFO - 2018-05-17 04:47:29 --> Language Class Initialized
ERROR - 2018-05-17 04:47:29 --> 404 Page Not Found: /index
INFO - 2018-05-17 04:47:31 --> Config Class Initialized
INFO - 2018-05-17 04:47:31 --> Hooks Class Initialized
DEBUG - 2018-05-17 04:47:31 --> UTF-8 Support Enabled
INFO - 2018-05-17 04:47:31 --> Utf8 Class Initialized
INFO - 2018-05-17 04:47:31 --> URI Class Initialized
INFO - 2018-05-17 04:47:31 --> Router Class Initialized
INFO - 2018-05-17 04:47:31 --> Output Class Initialized
INFO - 2018-05-17 04:47:31 --> Security Class Initialized
DEBUG - 2018-05-17 04:47:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 04:47:31 --> Input Class Initialized
INFO - 2018-05-17 04:47:31 --> Language Class Initialized
INFO - 2018-05-17 04:47:31 --> Language Class Initialized
INFO - 2018-05-17 04:47:31 --> Config Class Initialized
INFO - 2018-05-17 04:47:31 --> Loader Class Initialized
DEBUG - 2018-05-17 04:47:31 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-17 04:47:31 --> Helper loaded: url_helper
INFO - 2018-05-17 04:47:31 --> Helper loaded: form_helper
INFO - 2018-05-17 04:47:31 --> Helper loaded: date_helper
INFO - 2018-05-17 04:47:31 --> Helper loaded: util_helper
INFO - 2018-05-17 04:47:31 --> Helper loaded: text_helper
INFO - 2018-05-17 04:47:31 --> Helper loaded: string_helper
INFO - 2018-05-17 04:47:31 --> Database Driver Class Initialized
DEBUG - 2018-05-17 04:47:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-17 04:47:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-17 04:47:31 --> Email Class Initialized
INFO - 2018-05-17 04:47:31 --> Controller Class Initialized
DEBUG - 2018-05-17 04:47:31 --> Admin MX_Controller Initialized
INFO - 2018-05-17 04:47:31 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-17 04:47:31 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-17 04:47:31 --> Login MX_Controller Initialized
DEBUG - 2018-05-17 04:47:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-17 04:47:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-17 04:47:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/logins/login.php
INFO - 2018-05-17 04:47:34 --> Config Class Initialized
INFO - 2018-05-17 04:47:34 --> Hooks Class Initialized
DEBUG - 2018-05-17 04:47:35 --> UTF-8 Support Enabled
INFO - 2018-05-17 04:47:35 --> Utf8 Class Initialized
INFO - 2018-05-17 04:47:35 --> URI Class Initialized
INFO - 2018-05-17 04:47:35 --> Router Class Initialized
INFO - 2018-05-17 04:47:35 --> Output Class Initialized
INFO - 2018-05-17 04:47:35 --> Security Class Initialized
DEBUG - 2018-05-17 04:47:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 04:47:35 --> Input Class Initialized
INFO - 2018-05-17 04:47:35 --> Language Class Initialized
INFO - 2018-05-17 04:47:35 --> Language Class Initialized
INFO - 2018-05-17 04:47:35 --> Config Class Initialized
INFO - 2018-05-17 04:47:35 --> Loader Class Initialized
DEBUG - 2018-05-17 04:47:35 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-17 04:47:35 --> Helper loaded: url_helper
INFO - 2018-05-17 04:47:35 --> Helper loaded: form_helper
INFO - 2018-05-17 04:47:35 --> Helper loaded: date_helper
INFO - 2018-05-17 04:47:35 --> Helper loaded: util_helper
INFO - 2018-05-17 04:47:35 --> Helper loaded: text_helper
INFO - 2018-05-17 04:47:35 --> Helper loaded: string_helper
INFO - 2018-05-17 04:47:35 --> Database Driver Class Initialized
DEBUG - 2018-05-17 04:47:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-17 04:47:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-17 04:47:35 --> Email Class Initialized
INFO - 2018-05-17 04:47:35 --> Controller Class Initialized
DEBUG - 2018-05-17 04:47:35 --> videos MX_Controller Initialized
INFO - 2018-05-17 04:47:35 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-17 04:47:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-05-17 04:47:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-17 04:47:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-05-17 04:47:35 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-17 04:47:35 --> Login MX_Controller Initialized
DEBUG - 2018-05-17 04:47:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-17 04:47:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/logins/login.php
INFO - 2018-05-17 04:47:40 --> Config Class Initialized
INFO - 2018-05-17 04:47:40 --> Hooks Class Initialized
DEBUG - 2018-05-17 04:47:40 --> UTF-8 Support Enabled
INFO - 2018-05-17 04:47:40 --> Utf8 Class Initialized
INFO - 2018-05-17 04:47:40 --> URI Class Initialized
INFO - 2018-05-17 04:47:40 --> Router Class Initialized
INFO - 2018-05-17 04:47:40 --> Output Class Initialized
INFO - 2018-05-17 04:47:40 --> Security Class Initialized
DEBUG - 2018-05-17 04:47:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 04:47:40 --> Input Class Initialized
INFO - 2018-05-17 04:47:40 --> Language Class Initialized
INFO - 2018-05-17 04:47:40 --> Language Class Initialized
INFO - 2018-05-17 04:47:40 --> Config Class Initialized
INFO - 2018-05-17 04:47:41 --> Loader Class Initialized
DEBUG - 2018-05-17 04:47:41 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-17 04:47:41 --> Helper loaded: url_helper
INFO - 2018-05-17 04:47:41 --> Helper loaded: form_helper
INFO - 2018-05-17 04:47:41 --> Helper loaded: date_helper
INFO - 2018-05-17 04:47:41 --> Helper loaded: util_helper
INFO - 2018-05-17 04:47:41 --> Helper loaded: text_helper
INFO - 2018-05-17 04:47:41 --> Helper loaded: string_helper
INFO - 2018-05-17 04:47:41 --> Database Driver Class Initialized
DEBUG - 2018-05-17 04:47:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-17 04:47:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-17 04:47:41 --> Email Class Initialized
INFO - 2018-05-17 04:47:41 --> Controller Class Initialized
DEBUG - 2018-05-17 04:47:41 --> Login MX_Controller Initialized
INFO - 2018-05-17 04:47:41 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-17 04:47:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-17 04:47:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-17 04:47:41 --> Email starts for admin@consulting.com fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-05-17 04:47:41 --> User session created for 1
INFO - 2018-05-17 04:47:41 --> Login status admin@consulting.com - success
INFO - 2018-05-17 04:47:41 --> Final output sent to browser
DEBUG - 2018-05-17 04:47:41 --> Total execution time: 0.6165
INFO - 2018-05-17 04:47:41 --> Config Class Initialized
INFO - 2018-05-17 04:47:41 --> Hooks Class Initialized
DEBUG - 2018-05-17 04:47:41 --> UTF-8 Support Enabled
INFO - 2018-05-17 04:47:41 --> Utf8 Class Initialized
INFO - 2018-05-17 04:47:41 --> URI Class Initialized
INFO - 2018-05-17 04:47:41 --> Router Class Initialized
INFO - 2018-05-17 04:47:41 --> Output Class Initialized
INFO - 2018-05-17 04:47:41 --> Security Class Initialized
DEBUG - 2018-05-17 04:47:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 04:47:41 --> Input Class Initialized
INFO - 2018-05-17 04:47:41 --> Language Class Initialized
INFO - 2018-05-17 04:47:41 --> Language Class Initialized
INFO - 2018-05-17 04:47:41 --> Config Class Initialized
INFO - 2018-05-17 04:47:41 --> Loader Class Initialized
DEBUG - 2018-05-17 04:47:41 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-17 04:47:41 --> Helper loaded: url_helper
INFO - 2018-05-17 04:47:41 --> Helper loaded: form_helper
INFO - 2018-05-17 04:47:41 --> Helper loaded: date_helper
INFO - 2018-05-17 04:47:41 --> Helper loaded: util_helper
INFO - 2018-05-17 04:47:41 --> Helper loaded: text_helper
INFO - 2018-05-17 04:47:41 --> Helper loaded: string_helper
INFO - 2018-05-17 04:47:41 --> Database Driver Class Initialized
DEBUG - 2018-05-17 04:47:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-17 04:47:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-17 04:47:41 --> Email Class Initialized
INFO - 2018-05-17 04:47:41 --> Controller Class Initialized
DEBUG - 2018-05-17 04:47:41 --> Admin MX_Controller Initialized
INFO - 2018-05-17 04:47:41 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-17 04:47:41 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-17 04:47:41 --> Login MX_Controller Initialized
DEBUG - 2018-05-17 04:47:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-17 04:47:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-17 04:47:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-05-17 04:47:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-05-17 04:47:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-05-17 04:47:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-05-17 04:47:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-05-17 04:47:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/dashboard.php
INFO - 2018-05-17 04:47:42 --> Final output sent to browser
INFO - 2018-05-17 04:47:42 --> Config Class Initialized
DEBUG - 2018-05-17 04:47:42 --> Total execution time: 0.6433
INFO - 2018-05-17 04:47:42 --> Hooks Class Initialized
INFO - 2018-05-17 04:47:42 --> Config Class Initialized
INFO - 2018-05-17 04:47:42 --> Hooks Class Initialized
DEBUG - 2018-05-17 04:47:42 --> UTF-8 Support Enabled
INFO - 2018-05-17 04:47:42 --> Utf8 Class Initialized
DEBUG - 2018-05-17 04:47:42 --> UTF-8 Support Enabled
INFO - 2018-05-17 04:47:42 --> Utf8 Class Initialized
INFO - 2018-05-17 04:47:42 --> URI Class Initialized
INFO - 2018-05-17 04:47:42 --> URI Class Initialized
INFO - 2018-05-17 04:47:42 --> Router Class Initialized
INFO - 2018-05-17 04:47:42 --> Router Class Initialized
INFO - 2018-05-17 04:47:42 --> Output Class Initialized
INFO - 2018-05-17 04:47:42 --> Security Class Initialized
DEBUG - 2018-05-17 04:47:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 04:47:42 --> Input Class Initialized
INFO - 2018-05-17 04:47:42 --> Language Class Initialized
INFO - 2018-05-17 04:47:42 --> Output Class Initialized
ERROR - 2018-05-17 04:47:42 --> 404 Page Not Found: /index
INFO - 2018-05-17 04:47:42 --> Security Class Initialized
DEBUG - 2018-05-17 04:47:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 04:47:42 --> Input Class Initialized
INFO - 2018-05-17 04:47:42 --> Language Class Initialized
ERROR - 2018-05-17 04:47:42 --> 404 Page Not Found: /index
INFO - 2018-05-17 04:47:42 --> Config Class Initialized
INFO - 2018-05-17 04:47:42 --> Hooks Class Initialized
DEBUG - 2018-05-17 04:47:42 --> UTF-8 Support Enabled
INFO - 2018-05-17 04:47:42 --> Utf8 Class Initialized
INFO - 2018-05-17 04:47:42 --> URI Class Initialized
INFO - 2018-05-17 04:47:42 --> Router Class Initialized
INFO - 2018-05-17 04:47:42 --> Output Class Initialized
INFO - 2018-05-17 04:47:42 --> Security Class Initialized
DEBUG - 2018-05-17 04:47:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 04:47:42 --> Input Class Initialized
INFO - 2018-05-17 04:47:42 --> Language Class Initialized
ERROR - 2018-05-17 04:47:42 --> 404 Page Not Found: /index
INFO - 2018-05-17 04:47:45 --> Config Class Initialized
INFO - 2018-05-17 04:47:45 --> Hooks Class Initialized
DEBUG - 2018-05-17 04:47:45 --> UTF-8 Support Enabled
INFO - 2018-05-17 04:47:45 --> Utf8 Class Initialized
INFO - 2018-05-17 04:47:45 --> URI Class Initialized
INFO - 2018-05-17 04:47:45 --> Router Class Initialized
INFO - 2018-05-17 04:47:45 --> Output Class Initialized
INFO - 2018-05-17 04:47:45 --> Security Class Initialized
DEBUG - 2018-05-17 04:47:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 04:47:45 --> Input Class Initialized
INFO - 2018-05-17 04:47:45 --> Language Class Initialized
ERROR - 2018-05-17 04:47:45 --> 404 Page Not Found: /index
INFO - 2018-05-17 04:47:46 --> Config Class Initialized
INFO - 2018-05-17 04:47:46 --> Hooks Class Initialized
DEBUG - 2018-05-17 04:47:46 --> UTF-8 Support Enabled
INFO - 2018-05-17 04:47:46 --> Utf8 Class Initialized
INFO - 2018-05-17 04:47:46 --> URI Class Initialized
INFO - 2018-05-17 04:47:46 --> Router Class Initialized
INFO - 2018-05-17 04:47:46 --> Output Class Initialized
INFO - 2018-05-17 04:47:46 --> Security Class Initialized
DEBUG - 2018-05-17 04:47:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 04:47:46 --> Input Class Initialized
INFO - 2018-05-17 04:47:46 --> Language Class Initialized
INFO - 2018-05-17 04:47:46 --> Language Class Initialized
INFO - 2018-05-17 04:47:46 --> Config Class Initialized
INFO - 2018-05-17 04:47:46 --> Loader Class Initialized
DEBUG - 2018-05-17 04:47:46 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-17 04:47:47 --> Helper loaded: url_helper
INFO - 2018-05-17 04:47:47 --> Helper loaded: form_helper
INFO - 2018-05-17 04:47:47 --> Helper loaded: date_helper
INFO - 2018-05-17 04:47:47 --> Helper loaded: util_helper
INFO - 2018-05-17 04:47:47 --> Helper loaded: text_helper
INFO - 2018-05-17 04:47:47 --> Helper loaded: string_helper
INFO - 2018-05-17 04:47:47 --> Database Driver Class Initialized
DEBUG - 2018-05-17 04:47:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-17 04:47:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-17 04:47:47 --> Email Class Initialized
INFO - 2018-05-17 04:47:47 --> Controller Class Initialized
DEBUG - 2018-05-17 04:47:47 --> Admin MX_Controller Initialized
INFO - 2018-05-17 04:47:47 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-17 04:47:47 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-17 04:47:47 --> Login MX_Controller Initialized
DEBUG - 2018-05-17 04:47:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-17 04:47:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-17 04:47:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-05-17 04:47:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-05-17 04:47:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-05-17 04:47:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-05-17 04:47:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-05-17 04:47:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/dashboard.php
INFO - 2018-05-17 04:47:47 --> Final output sent to browser
DEBUG - 2018-05-17 04:47:47 --> Total execution time: 0.6454
INFO - 2018-05-17 04:48:41 --> Config Class Initialized
INFO - 2018-05-17 04:48:41 --> Hooks Class Initialized
DEBUG - 2018-05-17 04:48:41 --> UTF-8 Support Enabled
INFO - 2018-05-17 04:48:41 --> Utf8 Class Initialized
INFO - 2018-05-17 04:48:41 --> URI Class Initialized
INFO - 2018-05-17 04:48:41 --> Router Class Initialized
INFO - 2018-05-17 04:48:41 --> Output Class Initialized
INFO - 2018-05-17 04:48:41 --> Security Class Initialized
DEBUG - 2018-05-17 04:48:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 04:48:41 --> Input Class Initialized
INFO - 2018-05-17 04:48:41 --> Language Class Initialized
INFO - 2018-05-17 04:48:41 --> Language Class Initialized
INFO - 2018-05-17 04:48:41 --> Config Class Initialized
INFO - 2018-05-17 04:48:41 --> Loader Class Initialized
DEBUG - 2018-05-17 04:48:41 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-17 04:48:41 --> Helper loaded: url_helper
INFO - 2018-05-17 04:48:41 --> Helper loaded: form_helper
INFO - 2018-05-17 04:48:41 --> Helper loaded: date_helper
INFO - 2018-05-17 04:48:41 --> Helper loaded: util_helper
INFO - 2018-05-17 04:48:41 --> Helper loaded: text_helper
INFO - 2018-05-17 04:48:41 --> Helper loaded: string_helper
INFO - 2018-05-17 04:48:41 --> Database Driver Class Initialized
DEBUG - 2018-05-17 04:48:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-17 04:48:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-17 04:48:41 --> Email Class Initialized
INFO - 2018-05-17 04:48:41 --> Controller Class Initialized
DEBUG - 2018-05-17 04:48:41 --> Admin MX_Controller Initialized
INFO - 2018-05-17 04:48:41 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-17 04:48:41 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-17 04:48:41 --> Login MX_Controller Initialized
DEBUG - 2018-05-17 04:48:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-17 04:48:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-17 04:48:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-05-17 04:48:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-05-17 04:48:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-05-17 04:48:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-05-17 04:48:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-05-17 04:48:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/dashboard.php
INFO - 2018-05-17 04:48:42 --> Final output sent to browser
INFO - 2018-05-17 04:48:42 --> Config Class Initialized
INFO - 2018-05-17 04:48:42 --> Hooks Class Initialized
DEBUG - 2018-05-17 04:48:42 --> Total execution time: 0.6481
DEBUG - 2018-05-17 04:48:42 --> UTF-8 Support Enabled
INFO - 2018-05-17 04:48:42 --> Utf8 Class Initialized
INFO - 2018-05-17 04:48:42 --> URI Class Initialized
INFO - 2018-05-17 04:48:42 --> Router Class Initialized
INFO - 2018-05-17 04:48:42 --> Config Class Initialized
INFO - 2018-05-17 04:48:42 --> Hooks Class Initialized
INFO - 2018-05-17 04:48:42 --> Output Class Initialized
DEBUG - 2018-05-17 04:48:42 --> UTF-8 Support Enabled
INFO - 2018-05-17 04:48:42 --> Utf8 Class Initialized
INFO - 2018-05-17 04:48:42 --> URI Class Initialized
INFO - 2018-05-17 04:48:42 --> Router Class Initialized
INFO - 2018-05-17 04:48:42 --> Security Class Initialized
INFO - 2018-05-17 04:48:42 --> Output Class Initialized
INFO - 2018-05-17 04:48:42 --> Security Class Initialized
DEBUG - 2018-05-17 04:48:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 04:48:42 --> Input Class Initialized
INFO - 2018-05-17 04:48:42 --> Language Class Initialized
ERROR - 2018-05-17 04:48:42 --> 404 Page Not Found: /index
DEBUG - 2018-05-17 04:48:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 04:48:42 --> Input Class Initialized
INFO - 2018-05-17 04:48:42 --> Language Class Initialized
ERROR - 2018-05-17 04:48:42 --> 404 Page Not Found: /index
INFO - 2018-05-17 04:48:42 --> Config Class Initialized
INFO - 2018-05-17 04:48:42 --> Hooks Class Initialized
DEBUG - 2018-05-17 04:48:42 --> UTF-8 Support Enabled
INFO - 2018-05-17 04:48:42 --> Utf8 Class Initialized
INFO - 2018-05-17 04:48:42 --> URI Class Initialized
INFO - 2018-05-17 04:48:42 --> Router Class Initialized
INFO - 2018-05-17 04:48:42 --> Output Class Initialized
INFO - 2018-05-17 04:48:42 --> Security Class Initialized
DEBUG - 2018-05-17 04:48:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 04:48:43 --> Input Class Initialized
INFO - 2018-05-17 04:48:43 --> Language Class Initialized
ERROR - 2018-05-17 04:48:43 --> 404 Page Not Found: /index
INFO - 2018-05-17 04:48:44 --> Config Class Initialized
INFO - 2018-05-17 04:48:44 --> Hooks Class Initialized
DEBUG - 2018-05-17 04:48:44 --> UTF-8 Support Enabled
INFO - 2018-05-17 04:48:44 --> Utf8 Class Initialized
INFO - 2018-05-17 04:48:44 --> URI Class Initialized
INFO - 2018-05-17 04:48:44 --> Router Class Initialized
INFO - 2018-05-17 04:48:44 --> Output Class Initialized
INFO - 2018-05-17 04:48:44 --> Security Class Initialized
DEBUG - 2018-05-17 04:48:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 04:48:44 --> Input Class Initialized
INFO - 2018-05-17 04:48:44 --> Language Class Initialized
INFO - 2018-05-17 04:48:44 --> Language Class Initialized
INFO - 2018-05-17 04:48:44 --> Config Class Initialized
INFO - 2018-05-17 04:48:44 --> Loader Class Initialized
DEBUG - 2018-05-17 04:48:44 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-17 04:48:44 --> Helper loaded: url_helper
INFO - 2018-05-17 04:48:44 --> Helper loaded: form_helper
INFO - 2018-05-17 04:48:44 --> Helper loaded: date_helper
INFO - 2018-05-17 04:48:44 --> Helper loaded: util_helper
INFO - 2018-05-17 04:48:44 --> Helper loaded: text_helper
INFO - 2018-05-17 04:48:44 --> Helper loaded: string_helper
INFO - 2018-05-17 04:48:44 --> Database Driver Class Initialized
DEBUG - 2018-05-17 04:48:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-17 04:48:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-17 04:48:44 --> Email Class Initialized
INFO - 2018-05-17 04:48:44 --> Controller Class Initialized
DEBUG - 2018-05-17 04:48:44 --> Admin MX_Controller Initialized
INFO - 2018-05-17 04:48:44 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-17 04:48:44 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-17 04:48:44 --> Login MX_Controller Initialized
DEBUG - 2018-05-17 04:48:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-17 04:48:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-17 04:48:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-05-17 04:48:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-05-17 04:48:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-05-17 04:48:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-05-17 04:48:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-05-17 04:48:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/dashboard.php
INFO - 2018-05-17 04:48:45 --> Final output sent to browser
INFO - 2018-05-17 04:48:45 --> Config Class Initialized
INFO - 2018-05-17 04:48:45 --> Config Class Initialized
INFO - 2018-05-17 04:48:45 --> Hooks Class Initialized
DEBUG - 2018-05-17 04:48:45 --> Total execution time: 0.6420
INFO - 2018-05-17 04:48:45 --> Hooks Class Initialized
DEBUG - 2018-05-17 04:48:45 --> UTF-8 Support Enabled
DEBUG - 2018-05-17 04:48:45 --> UTF-8 Support Enabled
INFO - 2018-05-17 04:48:45 --> Utf8 Class Initialized
INFO - 2018-05-17 04:48:45 --> Utf8 Class Initialized
INFO - 2018-05-17 04:48:45 --> URI Class Initialized
INFO - 2018-05-17 04:48:45 --> URI Class Initialized
INFO - 2018-05-17 04:48:45 --> Router Class Initialized
INFO - 2018-05-17 04:48:45 --> Router Class Initialized
INFO - 2018-05-17 04:48:45 --> Output Class Initialized
INFO - 2018-05-17 04:48:45 --> Output Class Initialized
INFO - 2018-05-17 04:48:45 --> Security Class Initialized
INFO - 2018-05-17 04:48:45 --> Security Class Initialized
DEBUG - 2018-05-17 04:48:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-17 04:48:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 04:48:45 --> Input Class Initialized
INFO - 2018-05-17 04:48:45 --> Language Class Initialized
ERROR - 2018-05-17 04:48:45 --> 404 Page Not Found: /index
INFO - 2018-05-17 04:48:45 --> Input Class Initialized
INFO - 2018-05-17 04:48:45 --> Language Class Initialized
ERROR - 2018-05-17 04:48:45 --> 404 Page Not Found: /index
INFO - 2018-05-17 04:48:45 --> Config Class Initialized
INFO - 2018-05-17 04:48:45 --> Hooks Class Initialized
DEBUG - 2018-05-17 04:48:45 --> UTF-8 Support Enabled
INFO - 2018-05-17 04:48:45 --> Utf8 Class Initialized
INFO - 2018-05-17 04:48:45 --> URI Class Initialized
INFO - 2018-05-17 04:48:45 --> Router Class Initialized
INFO - 2018-05-17 04:48:45 --> Output Class Initialized
INFO - 2018-05-17 04:48:45 --> Security Class Initialized
DEBUG - 2018-05-17 04:48:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 04:48:45 --> Input Class Initialized
INFO - 2018-05-17 04:48:45 --> Language Class Initialized
ERROR - 2018-05-17 04:48:45 --> 404 Page Not Found: /index
INFO - 2018-05-17 04:51:32 --> Config Class Initialized
INFO - 2018-05-17 04:51:32 --> Hooks Class Initialized
DEBUG - 2018-05-17 04:51:32 --> UTF-8 Support Enabled
INFO - 2018-05-17 04:51:32 --> Utf8 Class Initialized
INFO - 2018-05-17 04:51:32 --> URI Class Initialized
INFO - 2018-05-17 04:51:32 --> Router Class Initialized
INFO - 2018-05-17 04:51:32 --> Output Class Initialized
INFO - 2018-05-17 04:51:32 --> Security Class Initialized
DEBUG - 2018-05-17 04:51:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 04:51:32 --> Input Class Initialized
INFO - 2018-05-17 04:51:32 --> Language Class Initialized
INFO - 2018-05-17 04:51:32 --> Language Class Initialized
INFO - 2018-05-17 04:51:32 --> Config Class Initialized
INFO - 2018-05-17 04:51:32 --> Loader Class Initialized
DEBUG - 2018-05-17 04:51:32 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-17 04:51:32 --> Helper loaded: url_helper
INFO - 2018-05-17 04:51:32 --> Helper loaded: form_helper
INFO - 2018-05-17 04:51:32 --> Helper loaded: date_helper
INFO - 2018-05-17 04:51:32 --> Helper loaded: util_helper
INFO - 2018-05-17 04:51:32 --> Helper loaded: text_helper
INFO - 2018-05-17 04:51:32 --> Helper loaded: string_helper
INFO - 2018-05-17 04:51:32 --> Database Driver Class Initialized
DEBUG - 2018-05-17 04:51:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-17 04:51:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-17 04:51:32 --> Email Class Initialized
INFO - 2018-05-17 04:51:32 --> Controller Class Initialized
DEBUG - 2018-05-17 04:51:32 --> Home MX_Controller Initialized
DEBUG - 2018-05-17 04:51:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-17 04:51:32 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-17 04:51:32 --> Login MX_Controller Initialized
INFO - 2018-05-17 04:51:32 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-17 04:51:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-17 04:51:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-17 04:52:54 --> Config Class Initialized
INFO - 2018-05-17 04:52:54 --> Hooks Class Initialized
DEBUG - 2018-05-17 04:52:54 --> UTF-8 Support Enabled
INFO - 2018-05-17 04:52:54 --> Utf8 Class Initialized
INFO - 2018-05-17 04:52:54 --> URI Class Initialized
INFO - 2018-05-17 04:52:54 --> Router Class Initialized
INFO - 2018-05-17 04:52:54 --> Output Class Initialized
INFO - 2018-05-17 04:52:54 --> Security Class Initialized
DEBUG - 2018-05-17 04:52:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 04:52:54 --> Input Class Initialized
INFO - 2018-05-17 04:52:54 --> Language Class Initialized
INFO - 2018-05-17 04:52:54 --> Language Class Initialized
INFO - 2018-05-17 04:52:54 --> Config Class Initialized
INFO - 2018-05-17 04:52:54 --> Loader Class Initialized
DEBUG - 2018-05-17 04:52:54 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-17 04:52:54 --> Helper loaded: url_helper
INFO - 2018-05-17 04:52:54 --> Helper loaded: form_helper
INFO - 2018-05-17 04:52:54 --> Helper loaded: date_helper
INFO - 2018-05-17 04:52:54 --> Helper loaded: util_helper
INFO - 2018-05-17 04:52:54 --> Helper loaded: text_helper
INFO - 2018-05-17 04:52:54 --> Helper loaded: string_helper
INFO - 2018-05-17 04:52:54 --> Database Driver Class Initialized
DEBUG - 2018-05-17 04:52:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-17 04:52:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-17 04:52:54 --> Email Class Initialized
INFO - 2018-05-17 04:52:54 --> Controller Class Initialized
DEBUG - 2018-05-17 04:52:54 --> Home MX_Controller Initialized
DEBUG - 2018-05-17 04:52:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-17 04:52:54 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-17 04:52:54 --> Login MX_Controller Initialized
INFO - 2018-05-17 04:52:54 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-17 04:52:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-17 04:52:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-17 04:52:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-17 04:52:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-17 04:52:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-17 04:52:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-17 04:52:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-17 04:52:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-05-17 04:52:54 --> Final output sent to browser
DEBUG - 2018-05-17 04:52:54 --> Total execution time: 0.6891
INFO - 2018-05-17 04:52:57 --> Config Class Initialized
INFO - 2018-05-17 04:52:57 --> Hooks Class Initialized
INFO - 2018-05-17 04:52:57 --> Config Class Initialized
DEBUG - 2018-05-17 04:52:57 --> UTF-8 Support Enabled
INFO - 2018-05-17 04:52:57 --> Utf8 Class Initialized
INFO - 2018-05-17 04:52:57 --> URI Class Initialized
INFO - 2018-05-17 04:52:57 --> Router Class Initialized
INFO - 2018-05-17 04:52:57 --> Output Class Initialized
INFO - 2018-05-17 04:52:57 --> Security Class Initialized
DEBUG - 2018-05-17 04:52:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 04:52:57 --> Input Class Initialized
INFO - 2018-05-17 04:52:57 --> Language Class Initialized
INFO - 2018-05-17 04:52:57 --> Hooks Class Initialized
ERROR - 2018-05-17 04:52:57 --> 404 Page Not Found: /index
DEBUG - 2018-05-17 04:52:58 --> UTF-8 Support Enabled
INFO - 2018-05-17 04:52:58 --> Utf8 Class Initialized
INFO - 2018-05-17 04:52:58 --> URI Class Initialized
INFO - 2018-05-17 04:52:58 --> Router Class Initialized
INFO - 2018-05-17 04:52:58 --> Output Class Initialized
INFO - 2018-05-17 04:52:58 --> Security Class Initialized
DEBUG - 2018-05-17 04:52:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 04:52:58 --> Input Class Initialized
INFO - 2018-05-17 04:52:58 --> Language Class Initialized
ERROR - 2018-05-17 04:52:58 --> 404 Page Not Found: /index
INFO - 2018-05-17 04:52:58 --> Config Class Initialized
INFO - 2018-05-17 04:52:58 --> Hooks Class Initialized
DEBUG - 2018-05-17 04:52:58 --> UTF-8 Support Enabled
INFO - 2018-05-17 04:52:58 --> Utf8 Class Initialized
INFO - 2018-05-17 04:52:58 --> URI Class Initialized
INFO - 2018-05-17 04:52:58 --> Router Class Initialized
INFO - 2018-05-17 04:52:58 --> Output Class Initialized
INFO - 2018-05-17 04:52:58 --> Security Class Initialized
DEBUG - 2018-05-17 04:52:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 04:52:58 --> Input Class Initialized
INFO - 2018-05-17 04:52:58 --> Language Class Initialized
ERROR - 2018-05-17 04:52:58 --> 404 Page Not Found: /index
INFO - 2018-05-17 04:52:58 --> Config Class Initialized
INFO - 2018-05-17 04:52:58 --> Hooks Class Initialized
DEBUG - 2018-05-17 04:52:58 --> UTF-8 Support Enabled
INFO - 2018-05-17 04:52:58 --> Utf8 Class Initialized
INFO - 2018-05-17 04:52:58 --> URI Class Initialized
INFO - 2018-05-17 04:52:58 --> Router Class Initialized
INFO - 2018-05-17 04:52:58 --> Output Class Initialized
INFO - 2018-05-17 04:52:58 --> Security Class Initialized
DEBUG - 2018-05-17 04:52:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 04:52:58 --> Input Class Initialized
INFO - 2018-05-17 04:52:58 --> Language Class Initialized
ERROR - 2018-05-17 04:52:59 --> 404 Page Not Found: /index
INFO - 2018-05-17 04:53:06 --> Config Class Initialized
INFO - 2018-05-17 04:53:06 --> Hooks Class Initialized
DEBUG - 2018-05-17 04:53:06 --> UTF-8 Support Enabled
INFO - 2018-05-17 04:53:06 --> Utf8 Class Initialized
INFO - 2018-05-17 04:53:06 --> URI Class Initialized
INFO - 2018-05-17 04:53:06 --> Router Class Initialized
INFO - 2018-05-17 04:53:06 --> Output Class Initialized
INFO - 2018-05-17 04:53:06 --> Security Class Initialized
DEBUG - 2018-05-17 04:53:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 04:53:06 --> Input Class Initialized
INFO - 2018-05-17 04:53:06 --> Language Class Initialized
ERROR - 2018-05-17 04:53:06 --> 404 Page Not Found: /index
INFO - 2018-05-17 04:53:06 --> Config Class Initialized
INFO - 2018-05-17 04:53:06 --> Hooks Class Initialized
DEBUG - 2018-05-17 04:53:06 --> UTF-8 Support Enabled
INFO - 2018-05-17 04:53:06 --> Utf8 Class Initialized
INFO - 2018-05-17 04:53:06 --> URI Class Initialized
INFO - 2018-05-17 04:53:06 --> Router Class Initialized
INFO - 2018-05-17 04:53:06 --> Output Class Initialized
INFO - 2018-05-17 04:53:06 --> Security Class Initialized
DEBUG - 2018-05-17 04:53:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 04:53:06 --> Input Class Initialized
INFO - 2018-05-17 04:53:06 --> Language Class Initialized
ERROR - 2018-05-17 04:53:06 --> 404 Page Not Found: /index
INFO - 2018-05-17 04:53:07 --> Config Class Initialized
INFO - 2018-05-17 04:53:07 --> Hooks Class Initialized
DEBUG - 2018-05-17 04:53:07 --> UTF-8 Support Enabled
INFO - 2018-05-17 04:53:07 --> Utf8 Class Initialized
INFO - 2018-05-17 04:53:07 --> URI Class Initialized
INFO - 2018-05-17 04:53:07 --> Router Class Initialized
INFO - 2018-05-17 04:53:07 --> Output Class Initialized
INFO - 2018-05-17 04:53:07 --> Security Class Initialized
DEBUG - 2018-05-17 04:53:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 04:53:07 --> Input Class Initialized
INFO - 2018-05-17 04:53:07 --> Language Class Initialized
ERROR - 2018-05-17 04:53:07 --> 404 Page Not Found: /index
INFO - 2018-05-17 05:14:04 --> Config Class Initialized
INFO - 2018-05-17 05:14:04 --> Hooks Class Initialized
DEBUG - 2018-05-17 05:14:05 --> UTF-8 Support Enabled
INFO - 2018-05-17 05:14:05 --> Utf8 Class Initialized
INFO - 2018-05-17 05:14:05 --> URI Class Initialized
INFO - 2018-05-17 05:14:05 --> Router Class Initialized
INFO - 2018-05-17 05:14:05 --> Output Class Initialized
INFO - 2018-05-17 05:14:05 --> Security Class Initialized
DEBUG - 2018-05-17 05:14:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 05:14:05 --> Input Class Initialized
INFO - 2018-05-17 05:14:05 --> Language Class Initialized
INFO - 2018-05-17 05:14:05 --> Language Class Initialized
INFO - 2018-05-17 05:14:05 --> Config Class Initialized
INFO - 2018-05-17 05:14:05 --> Loader Class Initialized
DEBUG - 2018-05-17 05:14:05 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-17 05:14:05 --> Helper loaded: url_helper
INFO - 2018-05-17 05:14:05 --> Helper loaded: form_helper
INFO - 2018-05-17 05:14:05 --> Helper loaded: date_helper
INFO - 2018-05-17 05:14:05 --> Helper loaded: util_helper
INFO - 2018-05-17 05:14:05 --> Helper loaded: text_helper
INFO - 2018-05-17 05:14:05 --> Helper loaded: string_helper
INFO - 2018-05-17 05:14:05 --> Database Driver Class Initialized
DEBUG - 2018-05-17 05:14:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-17 05:14:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-17 05:14:05 --> Email Class Initialized
INFO - 2018-05-17 05:14:05 --> Controller Class Initialized
DEBUG - 2018-05-17 05:14:06 --> Home MX_Controller Initialized
DEBUG - 2018-05-17 05:14:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-17 05:14:06 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-17 05:14:06 --> Login MX_Controller Initialized
INFO - 2018-05-17 05:14:06 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-17 05:14:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-17 05:14:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-17 05:14:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-17 05:14:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-17 05:14:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-17 05:14:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-17 05:14:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-17 05:14:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-05-17 05:14:06 --> Final output sent to browser
DEBUG - 2018-05-17 05:14:06 --> Total execution time: 1.5315
INFO - 2018-05-17 05:14:08 --> Config Class Initialized
INFO - 2018-05-17 05:14:08 --> Hooks Class Initialized
INFO - 2018-05-17 05:14:08 --> Config Class Initialized
INFO - 2018-05-17 05:14:08 --> Hooks Class Initialized
DEBUG - 2018-05-17 05:14:08 --> UTF-8 Support Enabled
DEBUG - 2018-05-17 05:14:08 --> UTF-8 Support Enabled
INFO - 2018-05-17 05:14:08 --> Utf8 Class Initialized
INFO - 2018-05-17 05:14:08 --> Utf8 Class Initialized
INFO - 2018-05-17 05:14:08 --> URI Class Initialized
INFO - 2018-05-17 05:14:08 --> URI Class Initialized
INFO - 2018-05-17 05:14:08 --> Router Class Initialized
INFO - 2018-05-17 05:14:08 --> Router Class Initialized
INFO - 2018-05-17 05:14:08 --> Output Class Initialized
INFO - 2018-05-17 05:14:08 --> Output Class Initialized
INFO - 2018-05-17 05:14:08 --> Security Class Initialized
INFO - 2018-05-17 05:14:08 --> Security Class Initialized
DEBUG - 2018-05-17 05:14:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-17 05:14:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 05:14:08 --> Input Class Initialized
INFO - 2018-05-17 05:14:08 --> Input Class Initialized
INFO - 2018-05-17 05:14:08 --> Language Class Initialized
INFO - 2018-05-17 05:14:08 --> Language Class Initialized
ERROR - 2018-05-17 05:14:08 --> 404 Page Not Found: /index
ERROR - 2018-05-17 05:14:08 --> 404 Page Not Found: /index
INFO - 2018-05-17 05:14:08 --> Config Class Initialized
INFO - 2018-05-17 05:14:08 --> Hooks Class Initialized
DEBUG - 2018-05-17 05:14:08 --> UTF-8 Support Enabled
INFO - 2018-05-17 05:14:08 --> Utf8 Class Initialized
INFO - 2018-05-17 05:14:08 --> URI Class Initialized
INFO - 2018-05-17 05:14:08 --> Router Class Initialized
INFO - 2018-05-17 05:14:08 --> Output Class Initialized
INFO - 2018-05-17 05:14:08 --> Security Class Initialized
DEBUG - 2018-05-17 05:14:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 05:14:08 --> Input Class Initialized
INFO - 2018-05-17 05:14:08 --> Language Class Initialized
ERROR - 2018-05-17 05:14:08 --> 404 Page Not Found: /index
INFO - 2018-05-17 05:14:09 --> Config Class Initialized
INFO - 2018-05-17 05:14:09 --> Hooks Class Initialized
DEBUG - 2018-05-17 05:14:09 --> UTF-8 Support Enabled
INFO - 2018-05-17 05:14:09 --> Utf8 Class Initialized
INFO - 2018-05-17 05:14:09 --> URI Class Initialized
INFO - 2018-05-17 05:14:09 --> Router Class Initialized
INFO - 2018-05-17 05:14:09 --> Output Class Initialized
INFO - 2018-05-17 05:14:09 --> Security Class Initialized
DEBUG - 2018-05-17 05:14:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 05:14:09 --> Input Class Initialized
INFO - 2018-05-17 05:14:09 --> Language Class Initialized
ERROR - 2018-05-17 05:14:09 --> 404 Page Not Found: /index
INFO - 2018-05-17 05:37:39 --> Config Class Initialized
INFO - 2018-05-17 05:37:39 --> Hooks Class Initialized
DEBUG - 2018-05-17 05:37:39 --> UTF-8 Support Enabled
INFO - 2018-05-17 05:37:39 --> Utf8 Class Initialized
INFO - 2018-05-17 05:37:39 --> URI Class Initialized
INFO - 2018-05-17 05:37:39 --> Router Class Initialized
INFO - 2018-05-17 05:37:39 --> Output Class Initialized
INFO - 2018-05-17 05:37:39 --> Security Class Initialized
DEBUG - 2018-05-17 05:37:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 05:37:39 --> Input Class Initialized
INFO - 2018-05-17 05:37:39 --> Language Class Initialized
INFO - 2018-05-17 05:37:39 --> Language Class Initialized
INFO - 2018-05-17 05:37:39 --> Config Class Initialized
INFO - 2018-05-17 05:37:39 --> Loader Class Initialized
DEBUG - 2018-05-17 05:37:39 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-17 05:37:39 --> Helper loaded: url_helper
INFO - 2018-05-17 05:37:39 --> Helper loaded: form_helper
INFO - 2018-05-17 05:37:39 --> Helper loaded: date_helper
INFO - 2018-05-17 05:37:39 --> Helper loaded: util_helper
INFO - 2018-05-17 05:37:39 --> Helper loaded: text_helper
INFO - 2018-05-17 05:37:39 --> Helper loaded: string_helper
INFO - 2018-05-17 05:37:39 --> Database Driver Class Initialized
DEBUG - 2018-05-17 05:37:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-17 05:37:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-17 05:37:39 --> Email Class Initialized
INFO - 2018-05-17 05:37:39 --> Controller Class Initialized
DEBUG - 2018-05-17 05:37:39 --> Home MX_Controller Initialized
DEBUG - 2018-05-17 05:37:39 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-17 05:37:39 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-17 05:37:39 --> Login MX_Controller Initialized
INFO - 2018-05-17 05:37:40 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-17 05:37:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-17 05:37:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-17 05:37:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-17 05:37:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-17 05:37:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-17 05:37:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-17 05:37:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-17 05:37:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-05-17 05:37:40 --> Final output sent to browser
DEBUG - 2018-05-17 05:37:40 --> Total execution time: 0.6861
INFO - 2018-05-17 05:37:41 --> Config Class Initialized
INFO - 2018-05-17 05:37:41 --> Config Class Initialized
INFO - 2018-05-17 05:37:41 --> Hooks Class Initialized
INFO - 2018-05-17 05:37:41 --> Hooks Class Initialized
DEBUG - 2018-05-17 05:37:41 --> UTF-8 Support Enabled
DEBUG - 2018-05-17 05:37:41 --> UTF-8 Support Enabled
INFO - 2018-05-17 05:37:41 --> Utf8 Class Initialized
INFO - 2018-05-17 05:37:41 --> Utf8 Class Initialized
INFO - 2018-05-17 05:37:41 --> URI Class Initialized
INFO - 2018-05-17 05:37:42 --> Router Class Initialized
INFO - 2018-05-17 05:37:42 --> URI Class Initialized
INFO - 2018-05-17 05:37:42 --> Output Class Initialized
INFO - 2018-05-17 05:37:42 --> Router Class Initialized
INFO - 2018-05-17 05:37:42 --> Security Class Initialized
INFO - 2018-05-17 05:37:42 --> Output Class Initialized
INFO - 2018-05-17 05:37:42 --> Security Class Initialized
DEBUG - 2018-05-17 05:37:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 05:37:42 --> Input Class Initialized
DEBUG - 2018-05-17 05:37:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 05:37:42 --> Input Class Initialized
INFO - 2018-05-17 05:37:42 --> Language Class Initialized
ERROR - 2018-05-17 05:37:42 --> 404 Page Not Found: /index
INFO - 2018-05-17 05:37:42 --> Language Class Initialized
ERROR - 2018-05-17 05:37:42 --> 404 Page Not Found: /index
INFO - 2018-05-17 05:37:42 --> Config Class Initialized
INFO - 2018-05-17 05:37:42 --> Hooks Class Initialized
DEBUG - 2018-05-17 05:37:42 --> UTF-8 Support Enabled
INFO - 2018-05-17 05:37:42 --> Utf8 Class Initialized
INFO - 2018-05-17 05:37:42 --> URI Class Initialized
INFO - 2018-05-17 05:37:42 --> Router Class Initialized
INFO - 2018-05-17 05:37:42 --> Output Class Initialized
INFO - 2018-05-17 05:37:42 --> Security Class Initialized
DEBUG - 2018-05-17 05:37:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 05:37:42 --> Input Class Initialized
INFO - 2018-05-17 05:37:42 --> Language Class Initialized
ERROR - 2018-05-17 05:37:42 --> 404 Page Not Found: /index
INFO - 2018-05-17 05:37:42 --> Config Class Initialized
INFO - 2018-05-17 05:37:42 --> Hooks Class Initialized
DEBUG - 2018-05-17 05:37:42 --> UTF-8 Support Enabled
INFO - 2018-05-17 05:37:42 --> Utf8 Class Initialized
INFO - 2018-05-17 05:37:42 --> URI Class Initialized
INFO - 2018-05-17 05:37:42 --> Router Class Initialized
INFO - 2018-05-17 05:37:42 --> Output Class Initialized
INFO - 2018-05-17 05:37:43 --> Security Class Initialized
DEBUG - 2018-05-17 05:37:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 05:37:43 --> Input Class Initialized
INFO - 2018-05-17 05:37:43 --> Language Class Initialized
ERROR - 2018-05-17 05:37:43 --> 404 Page Not Found: /index
INFO - 2018-05-17 22:44:07 --> Config Class Initialized
INFO - 2018-05-17 22:44:07 --> Hooks Class Initialized
DEBUG - 2018-05-17 22:44:08 --> UTF-8 Support Enabled
INFO - 2018-05-17 22:44:08 --> Utf8 Class Initialized
INFO - 2018-05-17 22:44:08 --> URI Class Initialized
INFO - 2018-05-17 22:44:08 --> Router Class Initialized
INFO - 2018-05-17 22:44:08 --> Output Class Initialized
INFO - 2018-05-17 22:44:08 --> Security Class Initialized
DEBUG - 2018-05-17 22:44:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 22:44:08 --> Input Class Initialized
INFO - 2018-05-17 22:44:08 --> Language Class Initialized
ERROR - 2018-05-17 22:44:08 --> 404 Page Not Found: /index
INFO - 2018-05-17 22:44:08 --> Config Class Initialized
INFO - 2018-05-17 22:44:08 --> Hooks Class Initialized
DEBUG - 2018-05-17 22:44:08 --> UTF-8 Support Enabled
INFO - 2018-05-17 22:44:08 --> Utf8 Class Initialized
INFO - 2018-05-17 22:44:08 --> URI Class Initialized
INFO - 2018-05-17 22:44:08 --> Router Class Initialized
INFO - 2018-05-17 22:44:08 --> Output Class Initialized
INFO - 2018-05-17 22:44:09 --> Security Class Initialized
DEBUG - 2018-05-17 22:44:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 22:44:09 --> Input Class Initialized
INFO - 2018-05-17 22:44:09 --> Language Class Initialized
ERROR - 2018-05-17 22:44:09 --> 404 Page Not Found: /index
INFO - 2018-05-17 22:44:09 --> Config Class Initialized
INFO - 2018-05-17 22:44:09 --> Hooks Class Initialized
DEBUG - 2018-05-17 22:44:09 --> UTF-8 Support Enabled
INFO - 2018-05-17 22:44:09 --> Utf8 Class Initialized
INFO - 2018-05-17 22:44:09 --> URI Class Initialized
INFO - 2018-05-17 22:44:09 --> Router Class Initialized
INFO - 2018-05-17 22:44:09 --> Output Class Initialized
INFO - 2018-05-17 22:44:09 --> Security Class Initialized
DEBUG - 2018-05-17 22:44:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 22:44:09 --> Input Class Initialized
INFO - 2018-05-17 22:44:09 --> Language Class Initialized
ERROR - 2018-05-17 22:44:09 --> 404 Page Not Found: /index
INFO - 2018-05-17 22:44:10 --> Config Class Initialized
INFO - 2018-05-17 22:44:10 --> Hooks Class Initialized
DEBUG - 2018-05-17 22:44:10 --> UTF-8 Support Enabled
INFO - 2018-05-17 22:44:10 --> Utf8 Class Initialized
INFO - 2018-05-17 22:44:10 --> URI Class Initialized
INFO - 2018-05-17 22:44:10 --> Router Class Initialized
INFO - 2018-05-17 22:44:10 --> Output Class Initialized
INFO - 2018-05-17 22:44:10 --> Security Class Initialized
DEBUG - 2018-05-17 22:44:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 22:44:10 --> Input Class Initialized
INFO - 2018-05-17 22:44:10 --> Language Class Initialized
ERROR - 2018-05-17 22:44:10 --> 404 Page Not Found: /index
INFO - 2018-05-17 22:44:10 --> Config Class Initialized
INFO - 2018-05-17 22:44:10 --> Hooks Class Initialized
DEBUG - 2018-05-17 22:44:11 --> UTF-8 Support Enabled
INFO - 2018-05-17 22:44:11 --> Utf8 Class Initialized
INFO - 2018-05-17 22:44:11 --> URI Class Initialized
INFO - 2018-05-17 22:44:11 --> Router Class Initialized
INFO - 2018-05-17 22:44:11 --> Output Class Initialized
INFO - 2018-05-17 22:44:11 --> Security Class Initialized
DEBUG - 2018-05-17 22:44:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 22:44:11 --> Input Class Initialized
INFO - 2018-05-17 22:44:11 --> Language Class Initialized
ERROR - 2018-05-17 22:44:11 --> 404 Page Not Found: /index
INFO - 2018-05-17 22:44:11 --> Config Class Initialized
INFO - 2018-05-17 22:44:11 --> Hooks Class Initialized
DEBUG - 2018-05-17 22:44:11 --> UTF-8 Support Enabled
INFO - 2018-05-17 22:44:11 --> Utf8 Class Initialized
INFO - 2018-05-17 22:44:11 --> URI Class Initialized
INFO - 2018-05-17 22:44:11 --> Router Class Initialized
INFO - 2018-05-17 22:44:11 --> Output Class Initialized
INFO - 2018-05-17 22:44:11 --> Security Class Initialized
DEBUG - 2018-05-17 22:44:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 22:44:11 --> Input Class Initialized
INFO - 2018-05-17 22:44:11 --> Language Class Initialized
ERROR - 2018-05-17 22:44:11 --> 404 Page Not Found: /index
INFO - 2018-05-17 22:44:11 --> Config Class Initialized
INFO - 2018-05-17 22:44:11 --> Hooks Class Initialized
DEBUG - 2018-05-17 22:44:11 --> UTF-8 Support Enabled
INFO - 2018-05-17 22:44:11 --> Utf8 Class Initialized
INFO - 2018-05-17 22:44:11 --> URI Class Initialized
INFO - 2018-05-17 22:44:11 --> Router Class Initialized
INFO - 2018-05-17 22:44:11 --> Output Class Initialized
INFO - 2018-05-17 22:44:12 --> Security Class Initialized
DEBUG - 2018-05-17 22:44:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 22:44:12 --> Input Class Initialized
INFO - 2018-05-17 22:44:12 --> Language Class Initialized
ERROR - 2018-05-17 22:44:12 --> 404 Page Not Found: /index
INFO - 2018-05-17 22:44:12 --> Config Class Initialized
INFO - 2018-05-17 22:44:12 --> Hooks Class Initialized
DEBUG - 2018-05-17 22:44:12 --> UTF-8 Support Enabled
INFO - 2018-05-17 22:44:12 --> Utf8 Class Initialized
INFO - 2018-05-17 22:44:12 --> URI Class Initialized
INFO - 2018-05-17 22:44:12 --> Router Class Initialized
INFO - 2018-05-17 22:44:12 --> Output Class Initialized
INFO - 2018-05-17 22:44:12 --> Security Class Initialized
DEBUG - 2018-05-17 22:44:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 22:44:12 --> Input Class Initialized
INFO - 2018-05-17 22:44:12 --> Language Class Initialized
ERROR - 2018-05-17 22:44:12 --> 404 Page Not Found: /index
INFO - 2018-05-17 22:44:12 --> Config Class Initialized
INFO - 2018-05-17 22:44:12 --> Hooks Class Initialized
DEBUG - 2018-05-17 22:44:12 --> UTF-8 Support Enabled
INFO - 2018-05-17 22:44:12 --> Utf8 Class Initialized
INFO - 2018-05-17 22:44:12 --> URI Class Initialized
INFO - 2018-05-17 22:44:12 --> Router Class Initialized
INFO - 2018-05-17 22:44:12 --> Output Class Initialized
INFO - 2018-05-17 22:44:12 --> Security Class Initialized
DEBUG - 2018-05-17 22:44:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 22:44:12 --> Input Class Initialized
INFO - 2018-05-17 22:44:13 --> Language Class Initialized
ERROR - 2018-05-17 22:44:13 --> 404 Page Not Found: /index
INFO - 2018-05-17 22:44:13 --> Config Class Initialized
INFO - 2018-05-17 22:44:13 --> Hooks Class Initialized
DEBUG - 2018-05-17 22:44:13 --> UTF-8 Support Enabled
INFO - 2018-05-17 22:44:13 --> Utf8 Class Initialized
INFO - 2018-05-17 22:44:13 --> URI Class Initialized
INFO - 2018-05-17 22:44:13 --> Router Class Initialized
INFO - 2018-05-17 22:44:13 --> Output Class Initialized
INFO - 2018-05-17 22:44:13 --> Security Class Initialized
DEBUG - 2018-05-17 22:44:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 22:44:13 --> Input Class Initialized
INFO - 2018-05-17 22:44:13 --> Language Class Initialized
ERROR - 2018-05-17 22:44:13 --> 404 Page Not Found: /index
INFO - 2018-05-17 22:44:22 --> Config Class Initialized
INFO - 2018-05-17 22:44:22 --> Hooks Class Initialized
DEBUG - 2018-05-17 22:44:22 --> UTF-8 Support Enabled
INFO - 2018-05-17 22:44:22 --> Utf8 Class Initialized
INFO - 2018-05-17 22:44:22 --> URI Class Initialized
INFO - 2018-05-17 22:44:22 --> Router Class Initialized
INFO - 2018-05-17 22:44:22 --> Output Class Initialized
INFO - 2018-05-17 22:44:22 --> Security Class Initialized
DEBUG - 2018-05-17 22:44:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 22:44:22 --> Input Class Initialized
INFO - 2018-05-17 22:44:22 --> Language Class Initialized
ERROR - 2018-05-17 22:44:22 --> 404 Page Not Found: /index
INFO - 2018-05-17 22:44:22 --> Config Class Initialized
INFO - 2018-05-17 22:44:22 --> Hooks Class Initialized
DEBUG - 2018-05-17 22:44:22 --> UTF-8 Support Enabled
INFO - 2018-05-17 22:44:22 --> Utf8 Class Initialized
INFO - 2018-05-17 22:44:22 --> Config Class Initialized
INFO - 2018-05-17 22:44:22 --> URI Class Initialized
INFO - 2018-05-17 22:44:22 --> Hooks Class Initialized
DEBUG - 2018-05-17 22:44:22 --> UTF-8 Support Enabled
INFO - 2018-05-17 22:44:22 --> Router Class Initialized
INFO - 2018-05-17 22:44:22 --> Utf8 Class Initialized
INFO - 2018-05-17 22:44:22 --> Output Class Initialized
INFO - 2018-05-17 22:44:22 --> URI Class Initialized
INFO - 2018-05-17 22:44:22 --> Security Class Initialized
INFO - 2018-05-17 22:44:22 --> Router Class Initialized
DEBUG - 2018-05-17 22:44:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 22:44:22 --> Input Class Initialized
INFO - 2018-05-17 22:44:22 --> Output Class Initialized
INFO - 2018-05-17 22:44:22 --> Language Class Initialized
INFO - 2018-05-17 22:44:22 --> Security Class Initialized
ERROR - 2018-05-17 22:44:22 --> 404 Page Not Found: /index
DEBUG - 2018-05-17 22:44:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 22:44:22 --> Input Class Initialized
INFO - 2018-05-17 22:44:22 --> Language Class Initialized
ERROR - 2018-05-17 22:44:22 --> 404 Page Not Found: /index
INFO - 2018-05-17 22:44:22 --> Config Class Initialized
INFO - 2018-05-17 22:44:22 --> Hooks Class Initialized
DEBUG - 2018-05-17 22:44:22 --> UTF-8 Support Enabled
INFO - 2018-05-17 22:44:22 --> Utf8 Class Initialized
INFO - 2018-05-17 22:44:22 --> URI Class Initialized
INFO - 2018-05-17 22:44:22 --> Router Class Initialized
INFO - 2018-05-17 22:44:22 --> Output Class Initialized
INFO - 2018-05-17 22:44:22 --> Security Class Initialized
DEBUG - 2018-05-17 22:44:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 22:44:22 --> Input Class Initialized
INFO - 2018-05-17 22:44:22 --> Language Class Initialized
ERROR - 2018-05-17 22:44:22 --> 404 Page Not Found: /index
INFO - 2018-05-17 22:44:25 --> Config Class Initialized
INFO - 2018-05-17 22:44:25 --> Hooks Class Initialized
DEBUG - 2018-05-17 22:44:26 --> UTF-8 Support Enabled
INFO - 2018-05-17 22:44:26 --> Utf8 Class Initialized
INFO - 2018-05-17 22:44:26 --> URI Class Initialized
INFO - 2018-05-17 22:44:26 --> Router Class Initialized
INFO - 2018-05-17 22:44:26 --> Output Class Initialized
INFO - 2018-05-17 22:44:26 --> Security Class Initialized
DEBUG - 2018-05-17 22:44:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 22:44:26 --> Input Class Initialized
INFO - 2018-05-17 22:44:26 --> Language Class Initialized
ERROR - 2018-05-17 22:44:26 --> 404 Page Not Found: /index
INFO - 2018-05-17 22:44:26 --> Config Class Initialized
INFO - 2018-05-17 22:44:26 --> Hooks Class Initialized
DEBUG - 2018-05-17 22:44:26 --> UTF-8 Support Enabled
INFO - 2018-05-17 22:44:26 --> Utf8 Class Initialized
INFO - 2018-05-17 22:44:26 --> Config Class Initialized
INFO - 2018-05-17 22:44:26 --> Hooks Class Initialized
INFO - 2018-05-17 22:44:26 --> URI Class Initialized
DEBUG - 2018-05-17 22:44:26 --> UTF-8 Support Enabled
INFO - 2018-05-17 22:44:26 --> Router Class Initialized
INFO - 2018-05-17 22:44:26 --> Utf8 Class Initialized
INFO - 2018-05-17 22:44:26 --> Output Class Initialized
INFO - 2018-05-17 22:44:26 --> URI Class Initialized
INFO - 2018-05-17 22:44:26 --> Security Class Initialized
DEBUG - 2018-05-17 22:44:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 22:44:26 --> Router Class Initialized
INFO - 2018-05-17 22:44:26 --> Input Class Initialized
INFO - 2018-05-17 22:44:26 --> Output Class Initialized
INFO - 2018-05-17 22:44:26 --> Security Class Initialized
INFO - 2018-05-17 22:44:26 --> Language Class Initialized
DEBUG - 2018-05-17 22:44:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-05-17 22:44:26 --> 404 Page Not Found: /index
INFO - 2018-05-17 22:44:26 --> Input Class Initialized
INFO - 2018-05-17 22:44:26 --> Language Class Initialized
ERROR - 2018-05-17 22:44:26 --> 404 Page Not Found: /index
INFO - 2018-05-17 22:44:27 --> Config Class Initialized
INFO - 2018-05-17 22:44:27 --> Hooks Class Initialized
DEBUG - 2018-05-17 22:44:27 --> UTF-8 Support Enabled
INFO - 2018-05-17 22:44:27 --> Utf8 Class Initialized
INFO - 2018-05-17 22:44:27 --> URI Class Initialized
INFO - 2018-05-17 22:44:27 --> Router Class Initialized
INFO - 2018-05-17 22:44:27 --> Output Class Initialized
INFO - 2018-05-17 22:44:27 --> Security Class Initialized
DEBUG - 2018-05-17 22:44:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 22:44:27 --> Input Class Initialized
INFO - 2018-05-17 22:44:27 --> Language Class Initialized
ERROR - 2018-05-17 22:44:27 --> 404 Page Not Found: /index
INFO - 2018-05-17 22:44:27 --> Config Class Initialized
INFO - 2018-05-17 22:44:27 --> Hooks Class Initialized
DEBUG - 2018-05-17 22:44:27 --> UTF-8 Support Enabled
INFO - 2018-05-17 22:44:27 --> Utf8 Class Initialized
INFO - 2018-05-17 22:44:27 --> URI Class Initialized
INFO - 2018-05-17 22:44:27 --> Router Class Initialized
INFO - 2018-05-17 22:44:27 --> Output Class Initialized
INFO - 2018-05-17 22:44:27 --> Security Class Initialized
DEBUG - 2018-05-17 22:44:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 22:44:27 --> Input Class Initialized
INFO - 2018-05-17 22:44:27 --> Language Class Initialized
ERROR - 2018-05-17 22:44:27 --> 404 Page Not Found: /index
INFO - 2018-05-17 22:44:30 --> Config Class Initialized
INFO - 2018-05-17 22:44:30 --> Hooks Class Initialized
DEBUG - 2018-05-17 22:44:30 --> UTF-8 Support Enabled
INFO - 2018-05-17 22:44:30 --> Utf8 Class Initialized
INFO - 2018-05-17 22:44:30 --> URI Class Initialized
INFO - 2018-05-17 22:44:30 --> Router Class Initialized
INFO - 2018-05-17 22:44:31 --> Output Class Initialized
INFO - 2018-05-17 22:44:31 --> Security Class Initialized
DEBUG - 2018-05-17 22:44:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 22:44:31 --> Input Class Initialized
INFO - 2018-05-17 22:44:31 --> Language Class Initialized
ERROR - 2018-05-17 22:44:31 --> 404 Page Not Found: /index
INFO - 2018-05-17 22:44:31 --> Config Class Initialized
INFO - 2018-05-17 22:44:31 --> Hooks Class Initialized
DEBUG - 2018-05-17 22:44:31 --> UTF-8 Support Enabled
INFO - 2018-05-17 22:44:31 --> Utf8 Class Initialized
INFO - 2018-05-17 22:44:31 --> URI Class Initialized
INFO - 2018-05-17 22:44:31 --> Router Class Initialized
INFO - 2018-05-17 22:44:31 --> Output Class Initialized
INFO - 2018-05-17 22:44:31 --> Security Class Initialized
DEBUG - 2018-05-17 22:44:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 22:44:31 --> Input Class Initialized
INFO - 2018-05-17 22:44:31 --> Language Class Initialized
ERROR - 2018-05-17 22:44:31 --> 404 Page Not Found: /index
INFO - 2018-05-17 22:44:31 --> Config Class Initialized
INFO - 2018-05-17 22:44:31 --> Hooks Class Initialized
DEBUG - 2018-05-17 22:44:31 --> UTF-8 Support Enabled
INFO - 2018-05-17 22:44:31 --> Utf8 Class Initialized
INFO - 2018-05-17 22:44:31 --> URI Class Initialized
INFO - 2018-05-17 22:44:31 --> Router Class Initialized
INFO - 2018-05-17 22:44:31 --> Output Class Initialized
INFO - 2018-05-17 22:44:31 --> Security Class Initialized
DEBUG - 2018-05-17 22:44:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 22:44:31 --> Input Class Initialized
INFO - 2018-05-17 22:44:31 --> Language Class Initialized
ERROR - 2018-05-17 22:44:31 --> 404 Page Not Found: /index
INFO - 2018-05-17 22:44:35 --> Config Class Initialized
INFO - 2018-05-17 22:44:35 --> Hooks Class Initialized
DEBUG - 2018-05-17 22:44:35 --> UTF-8 Support Enabled
INFO - 2018-05-17 22:44:35 --> Utf8 Class Initialized
INFO - 2018-05-17 22:44:35 --> URI Class Initialized
INFO - 2018-05-17 22:44:35 --> Router Class Initialized
INFO - 2018-05-17 22:44:35 --> Output Class Initialized
INFO - 2018-05-17 22:44:35 --> Security Class Initialized
DEBUG - 2018-05-17 22:44:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 22:44:35 --> Input Class Initialized
INFO - 2018-05-17 22:44:35 --> Language Class Initialized
ERROR - 2018-05-17 22:44:35 --> 404 Page Not Found: /index
INFO - 2018-05-17 22:44:36 --> Config Class Initialized
INFO - 2018-05-17 22:44:36 --> Hooks Class Initialized
DEBUG - 2018-05-17 22:44:36 --> UTF-8 Support Enabled
INFO - 2018-05-17 22:44:36 --> Utf8 Class Initialized
INFO - 2018-05-17 22:44:36 --> URI Class Initialized
INFO - 2018-05-17 22:44:36 --> Router Class Initialized
INFO - 2018-05-17 22:44:36 --> Output Class Initialized
INFO - 2018-05-17 22:44:36 --> Security Class Initialized
DEBUG - 2018-05-17 22:44:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 22:44:36 --> Input Class Initialized
INFO - 2018-05-17 22:44:36 --> Language Class Initialized
ERROR - 2018-05-17 22:44:36 --> 404 Page Not Found: /index
INFO - 2018-05-17 22:44:36 --> Config Class Initialized
INFO - 2018-05-17 22:44:36 --> Hooks Class Initialized
DEBUG - 2018-05-17 22:44:36 --> UTF-8 Support Enabled
INFO - 2018-05-17 22:44:36 --> Utf8 Class Initialized
INFO - 2018-05-17 22:44:36 --> URI Class Initialized
INFO - 2018-05-17 22:44:36 --> Router Class Initialized
INFO - 2018-05-17 22:44:36 --> Output Class Initialized
INFO - 2018-05-17 22:44:36 --> Security Class Initialized
DEBUG - 2018-05-17 22:44:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 22:44:36 --> Input Class Initialized
INFO - 2018-05-17 22:44:36 --> Language Class Initialized
ERROR - 2018-05-17 22:44:36 --> 404 Page Not Found: /index
INFO - 2018-05-17 22:44:40 --> Config Class Initialized
INFO - 2018-05-17 22:44:40 --> Hooks Class Initialized
DEBUG - 2018-05-17 22:44:40 --> UTF-8 Support Enabled
INFO - 2018-05-17 22:44:40 --> Utf8 Class Initialized
INFO - 2018-05-17 22:44:40 --> URI Class Initialized
INFO - 2018-05-17 22:44:40 --> Router Class Initialized
INFO - 2018-05-17 22:44:40 --> Output Class Initialized
INFO - 2018-05-17 22:44:40 --> Security Class Initialized
DEBUG - 2018-05-17 22:44:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 22:44:40 --> Input Class Initialized
INFO - 2018-05-17 22:44:40 --> Language Class Initialized
ERROR - 2018-05-17 22:44:40 --> 404 Page Not Found: /index
INFO - 2018-05-17 22:44:40 --> Config Class Initialized
INFO - 2018-05-17 22:44:40 --> Hooks Class Initialized
DEBUG - 2018-05-17 22:44:40 --> UTF-8 Support Enabled
INFO - 2018-05-17 22:44:40 --> Utf8 Class Initialized
INFO - 2018-05-17 22:44:40 --> URI Class Initialized
INFO - 2018-05-17 22:44:40 --> Router Class Initialized
INFO - 2018-05-17 22:44:40 --> Output Class Initialized
INFO - 2018-05-17 22:44:40 --> Security Class Initialized
DEBUG - 2018-05-17 22:44:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 22:44:40 --> Input Class Initialized
INFO - 2018-05-17 22:44:40 --> Language Class Initialized
ERROR - 2018-05-17 22:44:40 --> 404 Page Not Found: /index
INFO - 2018-05-17 22:44:40 --> Config Class Initialized
INFO - 2018-05-17 22:44:40 --> Hooks Class Initialized
DEBUG - 2018-05-17 22:44:40 --> UTF-8 Support Enabled
INFO - 2018-05-17 22:44:40 --> Utf8 Class Initialized
INFO - 2018-05-17 22:44:40 --> URI Class Initialized
INFO - 2018-05-17 22:44:40 --> Router Class Initialized
INFO - 2018-05-17 22:44:40 --> Output Class Initialized
INFO - 2018-05-17 22:44:40 --> Security Class Initialized
DEBUG - 2018-05-17 22:44:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 22:44:41 --> Input Class Initialized
INFO - 2018-05-17 22:44:41 --> Language Class Initialized
ERROR - 2018-05-17 22:44:41 --> 404 Page Not Found: /index
INFO - 2018-05-17 22:44:51 --> Config Class Initialized
INFO - 2018-05-17 22:44:51 --> Hooks Class Initialized
DEBUG - 2018-05-17 22:44:51 --> UTF-8 Support Enabled
INFO - 2018-05-17 22:44:51 --> Utf8 Class Initialized
INFO - 2018-05-17 22:44:51 --> URI Class Initialized
INFO - 2018-05-17 22:44:51 --> Router Class Initialized
INFO - 2018-05-17 22:44:52 --> Output Class Initialized
INFO - 2018-05-17 22:44:52 --> Security Class Initialized
DEBUG - 2018-05-17 22:44:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 22:44:52 --> Input Class Initialized
INFO - 2018-05-17 22:44:52 --> Language Class Initialized
ERROR - 2018-05-17 22:44:52 --> 404 Page Not Found: /index
INFO - 2018-05-17 22:44:53 --> Config Class Initialized
INFO - 2018-05-17 22:44:53 --> Hooks Class Initialized
DEBUG - 2018-05-17 22:44:53 --> UTF-8 Support Enabled
INFO - 2018-05-17 22:44:53 --> Utf8 Class Initialized
INFO - 2018-05-17 22:44:53 --> URI Class Initialized
INFO - 2018-05-17 22:44:53 --> Router Class Initialized
INFO - 2018-05-17 22:44:53 --> Output Class Initialized
INFO - 2018-05-17 22:44:53 --> Security Class Initialized
DEBUG - 2018-05-17 22:44:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 22:44:53 --> Input Class Initialized
INFO - 2018-05-17 22:44:53 --> Language Class Initialized
ERROR - 2018-05-17 22:44:53 --> 404 Page Not Found: /index
INFO - 2018-05-17 22:44:53 --> Config Class Initialized
INFO - 2018-05-17 22:44:53 --> Hooks Class Initialized
DEBUG - 2018-05-17 22:44:53 --> UTF-8 Support Enabled
INFO - 2018-05-17 22:44:53 --> Utf8 Class Initialized
INFO - 2018-05-17 22:44:53 --> URI Class Initialized
INFO - 2018-05-17 22:44:53 --> Router Class Initialized
INFO - 2018-05-17 22:44:53 --> Output Class Initialized
INFO - 2018-05-17 22:44:53 --> Security Class Initialized
DEBUG - 2018-05-17 22:44:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 22:44:53 --> Input Class Initialized
INFO - 2018-05-17 22:44:53 --> Language Class Initialized
ERROR - 2018-05-17 22:44:53 --> 404 Page Not Found: /index
INFO - 2018-05-17 22:44:54 --> Config Class Initialized
INFO - 2018-05-17 22:44:54 --> Hooks Class Initialized
DEBUG - 2018-05-17 22:44:54 --> UTF-8 Support Enabled
INFO - 2018-05-17 22:44:54 --> Utf8 Class Initialized
INFO - 2018-05-17 22:44:54 --> Config Class Initialized
INFO - 2018-05-17 22:44:54 --> Hooks Class Initialized
INFO - 2018-05-17 22:44:54 --> URI Class Initialized
DEBUG - 2018-05-17 22:44:54 --> UTF-8 Support Enabled
INFO - 2018-05-17 22:44:55 --> Utf8 Class Initialized
INFO - 2018-05-17 22:44:55 --> URI Class Initialized
INFO - 2018-05-17 22:44:55 --> Router Class Initialized
INFO - 2018-05-17 22:44:55 --> Router Class Initialized
INFO - 2018-05-17 22:44:55 --> Output Class Initialized
INFO - 2018-05-17 22:44:55 --> Output Class Initialized
INFO - 2018-05-17 22:44:55 --> Security Class Initialized
INFO - 2018-05-17 22:44:55 --> Security Class Initialized
DEBUG - 2018-05-17 22:44:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-17 22:44:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 22:44:55 --> Input Class Initialized
INFO - 2018-05-17 22:44:55 --> Input Class Initialized
INFO - 2018-05-17 22:44:55 --> Language Class Initialized
ERROR - 2018-05-17 22:44:55 --> 404 Page Not Found: /index
INFO - 2018-05-17 22:44:55 --> Language Class Initialized
ERROR - 2018-05-17 22:44:55 --> 404 Page Not Found: /index
INFO - 2018-05-17 22:44:55 --> Config Class Initialized
INFO - 2018-05-17 22:44:55 --> Hooks Class Initialized
DEBUG - 2018-05-17 22:44:55 --> UTF-8 Support Enabled
INFO - 2018-05-17 22:44:55 --> Utf8 Class Initialized
INFO - 2018-05-17 22:44:55 --> URI Class Initialized
INFO - 2018-05-17 22:44:55 --> Router Class Initialized
INFO - 2018-05-17 22:44:55 --> Output Class Initialized
INFO - 2018-05-17 22:44:55 --> Security Class Initialized
DEBUG - 2018-05-17 22:44:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 22:44:55 --> Input Class Initialized
INFO - 2018-05-17 22:44:55 --> Language Class Initialized
ERROR - 2018-05-17 22:44:55 --> 404 Page Not Found: /index
INFO - 2018-05-17 22:44:55 --> Config Class Initialized
INFO - 2018-05-17 22:44:55 --> Hooks Class Initialized
DEBUG - 2018-05-17 22:44:55 --> UTF-8 Support Enabled
INFO - 2018-05-17 22:44:55 --> Utf8 Class Initialized
INFO - 2018-05-17 22:44:55 --> URI Class Initialized
INFO - 2018-05-17 22:44:55 --> Router Class Initialized
INFO - 2018-05-17 22:44:55 --> Output Class Initialized
INFO - 2018-05-17 22:44:55 --> Security Class Initialized
DEBUG - 2018-05-17 22:44:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 22:44:55 --> Input Class Initialized
INFO - 2018-05-17 22:44:55 --> Language Class Initialized
ERROR - 2018-05-17 22:44:55 --> 404 Page Not Found: /index
INFO - 2018-05-17 22:50:16 --> Config Class Initialized
INFO - 2018-05-17 22:50:16 --> Hooks Class Initialized
DEBUG - 2018-05-17 22:50:16 --> UTF-8 Support Enabled
INFO - 2018-05-17 22:50:16 --> Utf8 Class Initialized
INFO - 2018-05-17 22:50:16 --> URI Class Initialized
INFO - 2018-05-17 22:50:16 --> Router Class Initialized
INFO - 2018-05-17 22:50:16 --> Output Class Initialized
INFO - 2018-05-17 22:50:16 --> Security Class Initialized
DEBUG - 2018-05-17 22:50:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 22:50:16 --> Input Class Initialized
INFO - 2018-05-17 22:50:16 --> Language Class Initialized
ERROR - 2018-05-17 22:50:16 --> 404 Page Not Found: /index
INFO - 2018-05-17 22:50:17 --> Config Class Initialized
INFO - 2018-05-17 22:50:17 --> Hooks Class Initialized
DEBUG - 2018-05-17 22:50:17 --> UTF-8 Support Enabled
INFO - 2018-05-17 22:50:17 --> Utf8 Class Initialized
INFO - 2018-05-17 22:50:17 --> Config Class Initialized
INFO - 2018-05-17 22:50:17 --> Hooks Class Initialized
INFO - 2018-05-17 22:50:17 --> URI Class Initialized
DEBUG - 2018-05-17 22:50:17 --> UTF-8 Support Enabled
INFO - 2018-05-17 22:50:17 --> Router Class Initialized
INFO - 2018-05-17 22:50:17 --> Utf8 Class Initialized
INFO - 2018-05-17 22:50:17 --> URI Class Initialized
INFO - 2018-05-17 22:50:17 --> Output Class Initialized
INFO - 2018-05-17 22:50:18 --> Security Class Initialized
INFO - 2018-05-17 22:50:18 --> Router Class Initialized
INFO - 2018-05-17 22:50:18 --> Output Class Initialized
DEBUG - 2018-05-17 22:50:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 22:50:18 --> Input Class Initialized
INFO - 2018-05-17 22:50:18 --> Security Class Initialized
INFO - 2018-05-17 22:50:18 --> Language Class Initialized
DEBUG - 2018-05-17 22:50:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 22:50:18 --> Input Class Initialized
ERROR - 2018-05-17 22:50:18 --> 404 Page Not Found: /index
INFO - 2018-05-17 22:50:18 --> Language Class Initialized
ERROR - 2018-05-17 22:50:18 --> 404 Page Not Found: /index
INFO - 2018-05-17 22:50:18 --> Config Class Initialized
INFO - 2018-05-17 22:50:18 --> Hooks Class Initialized
DEBUG - 2018-05-17 22:50:18 --> UTF-8 Support Enabled
INFO - 2018-05-17 22:50:18 --> Utf8 Class Initialized
INFO - 2018-05-17 22:50:18 --> URI Class Initialized
INFO - 2018-05-17 22:50:18 --> Router Class Initialized
INFO - 2018-05-17 22:50:18 --> Output Class Initialized
INFO - 2018-05-17 22:50:18 --> Security Class Initialized
DEBUG - 2018-05-17 22:50:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 22:50:18 --> Input Class Initialized
INFO - 2018-05-17 22:50:18 --> Language Class Initialized
ERROR - 2018-05-17 22:50:18 --> 404 Page Not Found: /index
INFO - 2018-05-17 22:50:18 --> Config Class Initialized
INFO - 2018-05-17 22:50:18 --> Hooks Class Initialized
DEBUG - 2018-05-17 22:50:18 --> UTF-8 Support Enabled
INFO - 2018-05-17 22:50:18 --> Utf8 Class Initialized
INFO - 2018-05-17 22:50:18 --> URI Class Initialized
INFO - 2018-05-17 22:50:18 --> Router Class Initialized
INFO - 2018-05-17 22:50:18 --> Output Class Initialized
INFO - 2018-05-17 22:50:18 --> Security Class Initialized
DEBUG - 2018-05-17 22:50:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 22:50:18 --> Input Class Initialized
INFO - 2018-05-17 22:50:18 --> Language Class Initialized
ERROR - 2018-05-17 22:50:18 --> 404 Page Not Found: /index
INFO - 2018-05-17 22:51:05 --> Config Class Initialized
INFO - 2018-05-17 22:51:05 --> Hooks Class Initialized
DEBUG - 2018-05-17 22:51:05 --> UTF-8 Support Enabled
INFO - 2018-05-17 22:51:05 --> Utf8 Class Initialized
INFO - 2018-05-17 22:51:05 --> URI Class Initialized
INFO - 2018-05-17 22:51:05 --> Router Class Initialized
INFO - 2018-05-17 22:51:06 --> Output Class Initialized
INFO - 2018-05-17 22:51:06 --> Security Class Initialized
DEBUG - 2018-05-17 22:51:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 22:51:06 --> Input Class Initialized
INFO - 2018-05-17 22:51:06 --> Language Class Initialized
ERROR - 2018-05-17 22:51:06 --> 404 Page Not Found: /index
INFO - 2018-05-17 22:51:06 --> Config Class Initialized
INFO - 2018-05-17 22:51:06 --> Hooks Class Initialized
INFO - 2018-05-17 22:51:06 --> Config Class Initialized
DEBUG - 2018-05-17 22:51:06 --> UTF-8 Support Enabled
INFO - 2018-05-17 22:51:06 --> Hooks Class Initialized
DEBUG - 2018-05-17 22:51:06 --> UTF-8 Support Enabled
INFO - 2018-05-17 22:51:06 --> Utf8 Class Initialized
INFO - 2018-05-17 22:51:06 --> Utf8 Class Initialized
INFO - 2018-05-17 22:51:06 --> URI Class Initialized
INFO - 2018-05-17 22:51:06 --> Router Class Initialized
INFO - 2018-05-17 22:51:06 --> URI Class Initialized
INFO - 2018-05-17 22:51:06 --> Output Class Initialized
INFO - 2018-05-17 22:51:06 --> Router Class Initialized
INFO - 2018-05-17 22:51:06 --> Security Class Initialized
INFO - 2018-05-17 22:51:06 --> Output Class Initialized
DEBUG - 2018-05-17 22:51:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 22:51:06 --> Security Class Initialized
INFO - 2018-05-17 22:51:06 --> Input Class Initialized
DEBUG - 2018-05-17 22:51:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 22:51:06 --> Language Class Initialized
ERROR - 2018-05-17 22:51:06 --> 404 Page Not Found: /index
INFO - 2018-05-17 22:51:06 --> Input Class Initialized
INFO - 2018-05-17 22:51:07 --> Config Class Initialized
INFO - 2018-05-17 22:51:07 --> Hooks Class Initialized
INFO - 2018-05-17 22:51:07 --> Language Class Initialized
DEBUG - 2018-05-17 22:51:07 --> UTF-8 Support Enabled
INFO - 2018-05-17 22:51:07 --> Utf8 Class Initialized
INFO - 2018-05-17 22:51:07 --> URI Class Initialized
INFO - 2018-05-17 22:51:07 --> Router Class Initialized
ERROR - 2018-05-17 22:51:07 --> 404 Page Not Found: /index
INFO - 2018-05-17 22:51:07 --> Output Class Initialized
INFO - 2018-05-17 22:51:07 --> Security Class Initialized
DEBUG - 2018-05-17 22:51:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 22:51:07 --> Input Class Initialized
INFO - 2018-05-17 22:51:07 --> Language Class Initialized
ERROR - 2018-05-17 22:51:07 --> 404 Page Not Found: /index
INFO - 2018-05-17 22:51:07 --> Config Class Initialized
INFO - 2018-05-17 22:51:07 --> Hooks Class Initialized
DEBUG - 2018-05-17 22:51:07 --> UTF-8 Support Enabled
INFO - 2018-05-17 22:51:07 --> Utf8 Class Initialized
INFO - 2018-05-17 22:51:07 --> URI Class Initialized
INFO - 2018-05-17 22:51:07 --> Router Class Initialized
INFO - 2018-05-17 22:51:07 --> Output Class Initialized
INFO - 2018-05-17 22:51:07 --> Security Class Initialized
DEBUG - 2018-05-17 22:51:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 22:51:07 --> Input Class Initialized
INFO - 2018-05-17 22:51:07 --> Language Class Initialized
ERROR - 2018-05-17 22:51:07 --> 404 Page Not Found: /index
INFO - 2018-05-17 22:52:17 --> Config Class Initialized
INFO - 2018-05-17 22:52:17 --> Hooks Class Initialized
DEBUG - 2018-05-17 22:52:17 --> UTF-8 Support Enabled
INFO - 2018-05-17 22:52:17 --> Utf8 Class Initialized
INFO - 2018-05-17 22:52:17 --> URI Class Initialized
INFO - 2018-05-17 22:52:17 --> Router Class Initialized
INFO - 2018-05-17 22:52:17 --> Output Class Initialized
INFO - 2018-05-17 22:52:18 --> Security Class Initialized
DEBUG - 2018-05-17 22:52:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 22:52:18 --> Input Class Initialized
INFO - 2018-05-17 22:52:18 --> Language Class Initialized
ERROR - 2018-05-17 22:52:18 --> 404 Page Not Found: /index
INFO - 2018-05-17 22:52:18 --> Config Class Initialized
INFO - 2018-05-17 22:52:18 --> Hooks Class Initialized
DEBUG - 2018-05-17 22:52:18 --> UTF-8 Support Enabled
INFO - 2018-05-17 22:52:18 --> Utf8 Class Initialized
INFO - 2018-05-17 22:52:18 --> URI Class Initialized
INFO - 2018-05-17 22:52:18 --> Router Class Initialized
INFO - 2018-05-17 22:52:18 --> Output Class Initialized
INFO - 2018-05-17 22:52:18 --> Security Class Initialized
DEBUG - 2018-05-17 22:52:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 22:52:18 --> Input Class Initialized
INFO - 2018-05-17 22:52:18 --> Language Class Initialized
ERROR - 2018-05-17 22:52:18 --> 404 Page Not Found: /index
INFO - 2018-05-17 22:52:18 --> Config Class Initialized
INFO - 2018-05-17 22:52:18 --> Hooks Class Initialized
DEBUG - 2018-05-17 22:52:18 --> UTF-8 Support Enabled
INFO - 2018-05-17 22:52:18 --> Utf8 Class Initialized
INFO - 2018-05-17 22:52:18 --> URI Class Initialized
INFO - 2018-05-17 22:52:18 --> Router Class Initialized
INFO - 2018-05-17 22:52:18 --> Output Class Initialized
INFO - 2018-05-17 22:52:18 --> Security Class Initialized
DEBUG - 2018-05-17 22:52:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 22:52:18 --> Input Class Initialized
INFO - 2018-05-17 22:52:18 --> Language Class Initialized
ERROR - 2018-05-17 22:52:18 --> 404 Page Not Found: /index
INFO - 2018-05-17 23:01:10 --> Config Class Initialized
INFO - 2018-05-17 23:01:10 --> Hooks Class Initialized
DEBUG - 2018-05-17 23:01:10 --> UTF-8 Support Enabled
INFO - 2018-05-17 23:01:11 --> Utf8 Class Initialized
INFO - 2018-05-17 23:01:11 --> URI Class Initialized
INFO - 2018-05-17 23:01:11 --> Config Class Initialized
INFO - 2018-05-17 23:01:11 --> Hooks Class Initialized
INFO - 2018-05-17 23:01:11 --> Router Class Initialized
INFO - 2018-05-17 23:01:11 --> Output Class Initialized
DEBUG - 2018-05-17 23:01:11 --> UTF-8 Support Enabled
INFO - 2018-05-17 23:01:11 --> Security Class Initialized
INFO - 2018-05-17 23:01:11 --> Utf8 Class Initialized
DEBUG - 2018-05-17 23:01:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 23:01:11 --> Input Class Initialized
INFO - 2018-05-17 23:01:11 --> URI Class Initialized
INFO - 2018-05-17 23:01:11 --> Language Class Initialized
ERROR - 2018-05-17 23:01:11 --> 404 Page Not Found: /index
INFO - 2018-05-17 23:01:11 --> Router Class Initialized
INFO - 2018-05-17 23:01:11 --> Output Class Initialized
INFO - 2018-05-17 23:01:11 --> Config Class Initialized
INFO - 2018-05-17 23:01:11 --> Security Class Initialized
INFO - 2018-05-17 23:01:11 --> Hooks Class Initialized
DEBUG - 2018-05-17 23:01:11 --> UTF-8 Support Enabled
DEBUG - 2018-05-17 23:01:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 23:01:11 --> Input Class Initialized
INFO - 2018-05-17 23:01:11 --> Utf8 Class Initialized
INFO - 2018-05-17 23:01:11 --> Language Class Initialized
ERROR - 2018-05-17 23:01:11 --> 404 Page Not Found: /index
INFO - 2018-05-17 23:01:11 --> URI Class Initialized
INFO - 2018-05-17 23:01:11 --> Router Class Initialized
INFO - 2018-05-17 23:01:11 --> Output Class Initialized
INFO - 2018-05-17 23:01:11 --> Security Class Initialized
DEBUG - 2018-05-17 23:01:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 23:01:11 --> Input Class Initialized
INFO - 2018-05-17 23:01:11 --> Language Class Initialized
ERROR - 2018-05-17 23:01:11 --> 404 Page Not Found: /index
INFO - 2018-05-17 23:01:11 --> Config Class Initialized
INFO - 2018-05-17 23:01:11 --> Hooks Class Initialized
DEBUG - 2018-05-17 23:01:11 --> UTF-8 Support Enabled
INFO - 2018-05-17 23:01:11 --> Utf8 Class Initialized
INFO - 2018-05-17 23:01:11 --> URI Class Initialized
INFO - 2018-05-17 23:01:11 --> Router Class Initialized
INFO - 2018-05-17 23:01:11 --> Output Class Initialized
INFO - 2018-05-17 23:01:11 --> Security Class Initialized
DEBUG - 2018-05-17 23:01:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 23:01:11 --> Input Class Initialized
INFO - 2018-05-17 23:01:11 --> Language Class Initialized
ERROR - 2018-05-17 23:01:11 --> 404 Page Not Found: /index
INFO - 2018-05-17 23:01:13 --> Config Class Initialized
INFO - 2018-05-17 23:01:13 --> Hooks Class Initialized
DEBUG - 2018-05-17 23:01:13 --> UTF-8 Support Enabled
INFO - 2018-05-17 23:01:13 --> Utf8 Class Initialized
INFO - 2018-05-17 23:01:13 --> URI Class Initialized
INFO - 2018-05-17 23:01:13 --> Router Class Initialized
INFO - 2018-05-17 23:01:13 --> Output Class Initialized
INFO - 2018-05-17 23:01:13 --> Security Class Initialized
DEBUG - 2018-05-17 23:01:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 23:01:13 --> Input Class Initialized
INFO - 2018-05-17 23:01:13 --> Language Class Initialized
ERROR - 2018-05-17 23:01:13 --> 404 Page Not Found: /index
INFO - 2018-05-17 23:01:13 --> Config Class Initialized
INFO - 2018-05-17 23:01:14 --> Hooks Class Initialized
DEBUG - 2018-05-17 23:01:14 --> UTF-8 Support Enabled
INFO - 2018-05-17 23:01:14 --> Utf8 Class Initialized
INFO - 2018-05-17 23:01:14 --> URI Class Initialized
INFO - 2018-05-17 23:01:14 --> Router Class Initialized
INFO - 2018-05-17 23:01:14 --> Output Class Initialized
INFO - 2018-05-17 23:01:14 --> Security Class Initialized
DEBUG - 2018-05-17 23:01:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 23:01:14 --> Input Class Initialized
INFO - 2018-05-17 23:01:14 --> Language Class Initialized
ERROR - 2018-05-17 23:01:14 --> 404 Page Not Found: /index
INFO - 2018-05-17 23:01:14 --> Config Class Initialized
INFO - 2018-05-17 23:01:14 --> Hooks Class Initialized
DEBUG - 2018-05-17 23:01:14 --> UTF-8 Support Enabled
INFO - 2018-05-17 23:01:14 --> Utf8 Class Initialized
INFO - 2018-05-17 23:01:14 --> URI Class Initialized
INFO - 2018-05-17 23:01:14 --> Router Class Initialized
INFO - 2018-05-17 23:01:14 --> Output Class Initialized
INFO - 2018-05-17 23:01:14 --> Security Class Initialized
DEBUG - 2018-05-17 23:01:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 23:01:14 --> Input Class Initialized
INFO - 2018-05-17 23:01:14 --> Language Class Initialized
ERROR - 2018-05-17 23:01:14 --> 404 Page Not Found: /index
INFO - 2018-05-17 23:01:15 --> Config Class Initialized
INFO - 2018-05-17 23:01:15 --> Hooks Class Initialized
DEBUG - 2018-05-17 23:01:15 --> UTF-8 Support Enabled
INFO - 2018-05-17 23:01:15 --> Utf8 Class Initialized
INFO - 2018-05-17 23:01:16 --> URI Class Initialized
INFO - 2018-05-17 23:01:16 --> Router Class Initialized
INFO - 2018-05-17 23:01:16 --> Output Class Initialized
INFO - 2018-05-17 23:01:16 --> Security Class Initialized
DEBUG - 2018-05-17 23:01:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 23:01:16 --> Input Class Initialized
INFO - 2018-05-17 23:01:16 --> Language Class Initialized
ERROR - 2018-05-17 23:01:16 --> 404 Page Not Found: /index
INFO - 2018-05-17 23:01:16 --> Config Class Initialized
INFO - 2018-05-17 23:01:16 --> Hooks Class Initialized
DEBUG - 2018-05-17 23:01:16 --> UTF-8 Support Enabled
INFO - 2018-05-17 23:01:16 --> Utf8 Class Initialized
INFO - 2018-05-17 23:01:16 --> URI Class Initialized
INFO - 2018-05-17 23:01:16 --> Router Class Initialized
INFO - 2018-05-17 23:01:16 --> Output Class Initialized
INFO - 2018-05-17 23:01:16 --> Security Class Initialized
DEBUG - 2018-05-17 23:01:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 23:01:16 --> Input Class Initialized
INFO - 2018-05-17 23:01:16 --> Language Class Initialized
ERROR - 2018-05-17 23:01:16 --> 404 Page Not Found: /index
INFO - 2018-05-17 23:01:16 --> Config Class Initialized
INFO - 2018-05-17 23:01:16 --> Hooks Class Initialized
DEBUG - 2018-05-17 23:01:16 --> UTF-8 Support Enabled
INFO - 2018-05-17 23:01:16 --> Utf8 Class Initialized
INFO - 2018-05-17 23:01:16 --> URI Class Initialized
INFO - 2018-05-17 23:01:16 --> Router Class Initialized
INFO - 2018-05-17 23:01:16 --> Output Class Initialized
INFO - 2018-05-17 23:01:16 --> Security Class Initialized
DEBUG - 2018-05-17 23:01:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 23:01:16 --> Input Class Initialized
INFO - 2018-05-17 23:01:16 --> Language Class Initialized
ERROR - 2018-05-17 23:01:16 --> 404 Page Not Found: /index
INFO - 2018-05-17 23:01:17 --> Config Class Initialized
INFO - 2018-05-17 23:01:17 --> Hooks Class Initialized
DEBUG - 2018-05-17 23:01:17 --> UTF-8 Support Enabled
INFO - 2018-05-17 23:01:17 --> Utf8 Class Initialized
INFO - 2018-05-17 23:01:17 --> URI Class Initialized
INFO - 2018-05-17 23:01:17 --> Router Class Initialized
INFO - 2018-05-17 23:01:17 --> Output Class Initialized
INFO - 2018-05-17 23:01:17 --> Security Class Initialized
DEBUG - 2018-05-17 23:01:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 23:01:17 --> Input Class Initialized
INFO - 2018-05-17 23:01:17 --> Language Class Initialized
ERROR - 2018-05-17 23:01:17 --> 404 Page Not Found: /index
INFO - 2018-05-17 23:01:17 --> Config Class Initialized
INFO - 2018-05-17 23:01:17 --> Hooks Class Initialized
DEBUG - 2018-05-17 23:01:17 --> UTF-8 Support Enabled
INFO - 2018-05-17 23:01:18 --> Utf8 Class Initialized
INFO - 2018-05-17 23:01:18 --> URI Class Initialized
INFO - 2018-05-17 23:01:18 --> Router Class Initialized
INFO - 2018-05-17 23:01:18 --> Output Class Initialized
INFO - 2018-05-17 23:01:18 --> Security Class Initialized
DEBUG - 2018-05-17 23:01:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 23:01:18 --> Input Class Initialized
INFO - 2018-05-17 23:01:18 --> Language Class Initialized
ERROR - 2018-05-17 23:01:18 --> 404 Page Not Found: /index
INFO - 2018-05-17 23:01:18 --> Config Class Initialized
INFO - 2018-05-17 23:01:18 --> Hooks Class Initialized
DEBUG - 2018-05-17 23:01:18 --> UTF-8 Support Enabled
INFO - 2018-05-17 23:01:18 --> Utf8 Class Initialized
INFO - 2018-05-17 23:01:18 --> URI Class Initialized
INFO - 2018-05-17 23:01:18 --> Router Class Initialized
INFO - 2018-05-17 23:01:18 --> Output Class Initialized
INFO - 2018-05-17 23:01:18 --> Security Class Initialized
DEBUG - 2018-05-17 23:01:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 23:01:18 --> Input Class Initialized
INFO - 2018-05-17 23:01:18 --> Language Class Initialized
ERROR - 2018-05-17 23:01:18 --> 404 Page Not Found: /index
INFO - 2018-05-17 23:01:18 --> Config Class Initialized
INFO - 2018-05-17 23:01:18 --> Hooks Class Initialized
DEBUG - 2018-05-17 23:01:18 --> UTF-8 Support Enabled
INFO - 2018-05-17 23:01:18 --> Utf8 Class Initialized
INFO - 2018-05-17 23:01:18 --> URI Class Initialized
INFO - 2018-05-17 23:01:18 --> Router Class Initialized
INFO - 2018-05-17 23:01:18 --> Output Class Initialized
INFO - 2018-05-17 23:01:18 --> Security Class Initialized
DEBUG - 2018-05-17 23:01:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 23:01:18 --> Input Class Initialized
INFO - 2018-05-17 23:01:18 --> Language Class Initialized
ERROR - 2018-05-17 23:01:18 --> 404 Page Not Found: /index
INFO - 2018-05-17 23:14:02 --> Config Class Initialized
INFO - 2018-05-17 23:14:02 --> Hooks Class Initialized
DEBUG - 2018-05-17 23:14:02 --> UTF-8 Support Enabled
INFO - 2018-05-17 23:14:02 --> Utf8 Class Initialized
INFO - 2018-05-17 23:14:02 --> URI Class Initialized
INFO - 2018-05-17 23:14:02 --> Router Class Initialized
INFO - 2018-05-17 23:14:02 --> Output Class Initialized
INFO - 2018-05-17 23:14:02 --> Security Class Initialized
DEBUG - 2018-05-17 23:14:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 23:14:02 --> Input Class Initialized
INFO - 2018-05-17 23:14:02 --> Language Class Initialized
INFO - 2018-05-17 23:14:02 --> Language Class Initialized
INFO - 2018-05-17 23:14:02 --> Config Class Initialized
INFO - 2018-05-17 23:14:02 --> Loader Class Initialized
DEBUG - 2018-05-17 23:14:02 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-17 23:14:02 --> Helper loaded: url_helper
INFO - 2018-05-17 23:14:02 --> Helper loaded: form_helper
INFO - 2018-05-17 23:14:02 --> Helper loaded: date_helper
INFO - 2018-05-17 23:14:02 --> Helper loaded: util_helper
INFO - 2018-05-17 23:14:03 --> Helper loaded: text_helper
INFO - 2018-05-17 23:14:03 --> Helper loaded: string_helper
INFO - 2018-05-17 23:14:03 --> Database Driver Class Initialized
DEBUG - 2018-05-17 23:14:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-17 23:14:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-17 23:14:03 --> Email Class Initialized
INFO - 2018-05-17 23:14:03 --> Controller Class Initialized
DEBUG - 2018-05-17 23:14:03 --> Home MX_Controller Initialized
DEBUG - 2018-05-17 23:14:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-17 23:14:03 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-17 23:14:03 --> Login MX_Controller Initialized
INFO - 2018-05-17 23:14:03 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-17 23:14:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-17 23:14:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-17 23:14:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/login.php
INFO - 2018-05-17 23:14:03 --> Config Class Initialized
INFO - 2018-05-17 23:14:03 --> Hooks Class Initialized
DEBUG - 2018-05-17 23:14:03 --> UTF-8 Support Enabled
INFO - 2018-05-17 23:14:03 --> Utf8 Class Initialized
INFO - 2018-05-17 23:14:03 --> URI Class Initialized
INFO - 2018-05-17 23:14:03 --> Router Class Initialized
INFO - 2018-05-17 23:14:03 --> Config Class Initialized
INFO - 2018-05-17 23:14:03 --> Hooks Class Initialized
INFO - 2018-05-17 23:14:03 --> Output Class Initialized
DEBUG - 2018-05-17 23:14:03 --> UTF-8 Support Enabled
INFO - 2018-05-17 23:14:04 --> Utf8 Class Initialized
INFO - 2018-05-17 23:14:04 --> URI Class Initialized
INFO - 2018-05-17 23:14:04 --> Security Class Initialized
INFO - 2018-05-17 23:14:04 --> Router Class Initialized
DEBUG - 2018-05-17 23:14:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 23:14:04 --> Input Class Initialized
INFO - 2018-05-17 23:14:04 --> Language Class Initialized
INFO - 2018-05-17 23:14:04 --> Output Class Initialized
INFO - 2018-05-17 23:14:04 --> Language Class Initialized
INFO - 2018-05-17 23:14:04 --> Security Class Initialized
INFO - 2018-05-17 23:14:04 --> Config Class Initialized
INFO - 2018-05-17 23:14:04 --> Loader Class Initialized
DEBUG - 2018-05-17 23:14:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 23:14:04 --> Input Class Initialized
DEBUG - 2018-05-17 23:14:04 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-17 23:14:04 --> Language Class Initialized
ERROR - 2018-05-17 23:14:04 --> 404 Page Not Found: /index
INFO - 2018-05-17 23:14:04 --> Helper loaded: url_helper
INFO - 2018-05-17 23:14:04 --> Helper loaded: form_helper
INFO - 2018-05-17 23:14:04 --> Helper loaded: date_helper
INFO - 2018-05-17 23:14:04 --> Helper loaded: util_helper
INFO - 2018-05-17 23:14:04 --> Helper loaded: text_helper
INFO - 2018-05-17 23:14:04 --> Helper loaded: string_helper
INFO - 2018-05-17 23:14:04 --> Database Driver Class Initialized
DEBUG - 2018-05-17 23:14:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-17 23:14:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-17 23:14:04 --> Email Class Initialized
INFO - 2018-05-17 23:14:04 --> Controller Class Initialized
DEBUG - 2018-05-17 23:14:04 --> Home MX_Controller Initialized
DEBUG - 2018-05-17 23:14:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-17 23:14:04 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-17 23:14:04 --> Login MX_Controller Initialized
INFO - 2018-05-17 23:14:04 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-17 23:14:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-17 23:14:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-17 23:14:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/login.php
INFO - 2018-05-17 23:14:20 --> Config Class Initialized
INFO - 2018-05-17 23:14:20 --> Hooks Class Initialized
DEBUG - 2018-05-17 23:14:20 --> UTF-8 Support Enabled
INFO - 2018-05-17 23:14:20 --> Utf8 Class Initialized
INFO - 2018-05-17 23:14:20 --> URI Class Initialized
INFO - 2018-05-17 23:14:20 --> Router Class Initialized
INFO - 2018-05-17 23:14:20 --> Output Class Initialized
INFO - 2018-05-17 23:14:20 --> Security Class Initialized
DEBUG - 2018-05-17 23:14:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 23:14:20 --> Input Class Initialized
INFO - 2018-05-17 23:14:20 --> Language Class Initialized
INFO - 2018-05-17 23:14:20 --> Language Class Initialized
INFO - 2018-05-17 23:14:20 --> Config Class Initialized
INFO - 2018-05-17 23:14:20 --> Loader Class Initialized
DEBUG - 2018-05-17 23:14:20 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-17 23:14:20 --> Helper loaded: url_helper
INFO - 2018-05-17 23:14:20 --> Helper loaded: form_helper
INFO - 2018-05-17 23:14:20 --> Helper loaded: date_helper
INFO - 2018-05-17 23:14:20 --> Helper loaded: util_helper
INFO - 2018-05-17 23:14:20 --> Helper loaded: text_helper
INFO - 2018-05-17 23:14:20 --> Helper loaded: string_helper
INFO - 2018-05-17 23:14:20 --> Database Driver Class Initialized
DEBUG - 2018-05-17 23:14:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-17 23:14:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-17 23:14:20 --> Email Class Initialized
INFO - 2018-05-17 23:14:20 --> Controller Class Initialized
DEBUG - 2018-05-17 23:14:20 --> Login MX_Controller Initialized
INFO - 2018-05-17 23:14:20 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-17 23:14:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-17 23:14:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-17 23:14:20 --> Email starts for gopipanguluri123@gmail.com fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-05-17 23:14:20 --> User session created for 4
INFO - 2018-05-17 23:14:20 --> Login status gopipanguluri123@gmail.com - success
INFO - 2018-05-17 23:14:20 --> Final output sent to browser
DEBUG - 2018-05-17 23:14:21 --> Total execution time: 0.8158
INFO - 2018-05-17 23:14:21 --> Config Class Initialized
INFO - 2018-05-17 23:14:21 --> Hooks Class Initialized
DEBUG - 2018-05-17 23:14:21 --> UTF-8 Support Enabled
INFO - 2018-05-17 23:14:21 --> Utf8 Class Initialized
INFO - 2018-05-17 23:14:21 --> URI Class Initialized
INFO - 2018-05-17 23:14:21 --> Router Class Initialized
INFO - 2018-05-17 23:14:21 --> Output Class Initialized
INFO - 2018-05-17 23:14:21 --> Security Class Initialized
DEBUG - 2018-05-17 23:14:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 23:14:21 --> Input Class Initialized
INFO - 2018-05-17 23:14:21 --> Language Class Initialized
INFO - 2018-05-17 23:14:21 --> Language Class Initialized
INFO - 2018-05-17 23:14:21 --> Config Class Initialized
INFO - 2018-05-17 23:14:21 --> Loader Class Initialized
DEBUG - 2018-05-17 23:14:21 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-17 23:14:21 --> Helper loaded: url_helper
INFO - 2018-05-17 23:14:21 --> Helper loaded: form_helper
INFO - 2018-05-17 23:14:21 --> Helper loaded: date_helper
INFO - 2018-05-17 23:14:21 --> Helper loaded: util_helper
INFO - 2018-05-17 23:14:21 --> Helper loaded: text_helper
INFO - 2018-05-17 23:14:21 --> Helper loaded: string_helper
INFO - 2018-05-17 23:14:21 --> Database Driver Class Initialized
DEBUG - 2018-05-17 23:14:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-17 23:14:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-17 23:14:21 --> Email Class Initialized
INFO - 2018-05-17 23:14:21 --> Controller Class Initialized
DEBUG - 2018-05-17 23:14:21 --> Home MX_Controller Initialized
DEBUG - 2018-05-17 23:14:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-17 23:14:21 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-17 23:14:21 --> Login MX_Controller Initialized
INFO - 2018-05-17 23:14:21 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-17 23:14:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-17 23:14:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-17 23:14:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-17 23:14:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-17 23:14:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-17 23:14:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-17 23:14:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-17 23:14:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-05-17 23:14:22 --> Final output sent to browser
DEBUG - 2018-05-17 23:14:22 --> Total execution time: 1.0171
INFO - 2018-05-17 23:14:22 --> Config Class Initialized
INFO - 2018-05-17 23:14:22 --> Hooks Class Initialized
DEBUG - 2018-05-17 23:14:22 --> UTF-8 Support Enabled
INFO - 2018-05-17 23:14:22 --> Utf8 Class Initialized
INFO - 2018-05-17 23:14:22 --> URI Class Initialized
INFO - 2018-05-17 23:14:22 --> Router Class Initialized
INFO - 2018-05-17 23:14:22 --> Output Class Initialized
INFO - 2018-05-17 23:14:22 --> Security Class Initialized
DEBUG - 2018-05-17 23:14:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 23:14:22 --> Input Class Initialized
INFO - 2018-05-17 23:14:22 --> Language Class Initialized
ERROR - 2018-05-17 23:14:22 --> 404 Page Not Found: /index
INFO - 2018-05-17 23:14:22 --> Config Class Initialized
INFO - 2018-05-17 23:14:22 --> Hooks Class Initialized
DEBUG - 2018-05-17 23:14:22 --> UTF-8 Support Enabled
INFO - 2018-05-17 23:14:23 --> Utf8 Class Initialized
INFO - 2018-05-17 23:14:23 --> URI Class Initialized
INFO - 2018-05-17 23:14:23 --> Router Class Initialized
INFO - 2018-05-17 23:14:23 --> Output Class Initialized
INFO - 2018-05-17 23:14:23 --> Security Class Initialized
DEBUG - 2018-05-17 23:14:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 23:14:23 --> Input Class Initialized
INFO - 2018-05-17 23:14:23 --> Language Class Initialized
ERROR - 2018-05-17 23:14:23 --> 404 Page Not Found: /index
INFO - 2018-05-17 23:14:23 --> Config Class Initialized
INFO - 2018-05-17 23:14:23 --> Hooks Class Initialized
DEBUG - 2018-05-17 23:14:23 --> UTF-8 Support Enabled
INFO - 2018-05-17 23:14:23 --> Utf8 Class Initialized
INFO - 2018-05-17 23:14:23 --> URI Class Initialized
INFO - 2018-05-17 23:14:23 --> Router Class Initialized
INFO - 2018-05-17 23:14:23 --> Output Class Initialized
INFO - 2018-05-17 23:14:23 --> Security Class Initialized
DEBUG - 2018-05-17 23:14:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 23:14:23 --> Input Class Initialized
INFO - 2018-05-17 23:14:23 --> Language Class Initialized
ERROR - 2018-05-17 23:14:23 --> 404 Page Not Found: /index
INFO - 2018-05-17 23:14:24 --> Config Class Initialized
INFO - 2018-05-17 23:14:24 --> Hooks Class Initialized
DEBUG - 2018-05-17 23:14:24 --> UTF-8 Support Enabled
INFO - 2018-05-17 23:14:24 --> Utf8 Class Initialized
INFO - 2018-05-17 23:14:24 --> URI Class Initialized
INFO - 2018-05-17 23:14:24 --> Router Class Initialized
INFO - 2018-05-17 23:14:24 --> Output Class Initialized
INFO - 2018-05-17 23:14:24 --> Security Class Initialized
DEBUG - 2018-05-17 23:14:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 23:14:24 --> Input Class Initialized
INFO - 2018-05-17 23:14:24 --> Language Class Initialized
INFO - 2018-05-17 23:14:24 --> Language Class Initialized
INFO - 2018-05-17 23:14:24 --> Config Class Initialized
INFO - 2018-05-17 23:14:24 --> Loader Class Initialized
DEBUG - 2018-05-17 23:14:24 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-17 23:14:24 --> Helper loaded: url_helper
INFO - 2018-05-17 23:14:24 --> Helper loaded: form_helper
INFO - 2018-05-17 23:14:24 --> Helper loaded: date_helper
INFO - 2018-05-17 23:14:24 --> Helper loaded: util_helper
INFO - 2018-05-17 23:14:24 --> Helper loaded: text_helper
INFO - 2018-05-17 23:14:24 --> Helper loaded: string_helper
INFO - 2018-05-17 23:14:24 --> Database Driver Class Initialized
DEBUG - 2018-05-17 23:14:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-17 23:14:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-17 23:14:24 --> Email Class Initialized
INFO - 2018-05-17 23:14:24 --> Controller Class Initialized
DEBUG - 2018-05-17 23:14:24 --> Home MX_Controller Initialized
DEBUG - 2018-05-17 23:14:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-17 23:14:24 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-17 23:14:24 --> Login MX_Controller Initialized
INFO - 2018-05-17 23:14:24 --> Language file loaded: language/english/data_lang.php
INFO - 2018-05-17 23:14:24 --> Config Class Initialized
INFO - 2018-05-17 23:14:24 --> Hooks Class Initialized
DEBUG - 2018-05-17 23:14:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-17 23:14:24 --> UTF-8 Support Enabled
DEBUG - 2018-05-17 23:14:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-17 23:14:24 --> Utf8 Class Initialized
INFO - 2018-05-17 23:14:24 --> URI Class Initialized
INFO - 2018-05-17 23:14:24 --> Router Class Initialized
INFO - 2018-05-17 23:14:24 --> Output Class Initialized
INFO - 2018-05-17 23:14:24 --> Security Class Initialized
DEBUG - 2018-05-17 23:14:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-17 23:14:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-17 23:14:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
INFO - 2018-05-17 23:14:24 --> Input Class Initialized
DEBUG - 2018-05-17 23:14:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-17 23:14:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-17 23:14:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
INFO - 2018-05-17 23:14:24 --> Language Class Initialized
DEBUG - 2018-05-17 23:14:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-05-17 23:14:24 --> Final output sent to browser
DEBUG - 2018-05-17 23:14:24 --> Total execution time: 0.9541
INFO - 2018-05-17 23:14:24 --> Language Class Initialized
INFO - 2018-05-17 23:14:25 --> Config Class Initialized
INFO - 2018-05-17 23:14:25 --> Loader Class Initialized
DEBUG - 2018-05-17 23:14:25 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-17 23:14:25 --> Helper loaded: url_helper
INFO - 2018-05-17 23:14:25 --> Helper loaded: form_helper
INFO - 2018-05-17 23:14:25 --> Helper loaded: date_helper
INFO - 2018-05-17 23:14:25 --> Helper loaded: util_helper
INFO - 2018-05-17 23:14:25 --> Helper loaded: text_helper
INFO - 2018-05-17 23:14:25 --> Helper loaded: string_helper
INFO - 2018-05-17 23:14:25 --> Database Driver Class Initialized
DEBUG - 2018-05-17 23:14:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-17 23:14:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-17 23:14:25 --> Email Class Initialized
INFO - 2018-05-17 23:14:25 --> Controller Class Initialized
DEBUG - 2018-05-17 23:14:25 --> Home MX_Controller Initialized
DEBUG - 2018-05-17 23:14:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-17 23:14:25 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-17 23:14:25 --> Login MX_Controller Initialized
INFO - 2018-05-17 23:14:25 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-17 23:14:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-17 23:14:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
ERROR - 2018-05-17 23:14:25 --> Severity: Notice --> Undefined offset: 0 E:\xampp\htdocs\consulting\application\modules\home\controllers\Home.php 28
DEBUG - 2018-05-17 23:14:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-17 23:14:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-17 23:14:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-17 23:14:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-17 23:14:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-17 23:14:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-05-17 23:14:25 --> Final output sent to browser
DEBUG - 2018-05-17 23:14:25 --> Total execution time: 0.9115
INFO - 2018-05-17 23:14:26 --> Config Class Initialized
INFO - 2018-05-17 23:14:26 --> Hooks Class Initialized
DEBUG - 2018-05-17 23:14:26 --> UTF-8 Support Enabled
INFO - 2018-05-17 23:14:26 --> Utf8 Class Initialized
INFO - 2018-05-17 23:14:26 --> URI Class Initialized
INFO - 2018-05-17 23:14:26 --> Router Class Initialized
INFO - 2018-05-17 23:14:26 --> Config Class Initialized
INFO - 2018-05-17 23:14:26 --> Hooks Class Initialized
INFO - 2018-05-17 23:14:26 --> Output Class Initialized
DEBUG - 2018-05-17 23:14:26 --> UTF-8 Support Enabled
INFO - 2018-05-17 23:14:26 --> Utf8 Class Initialized
INFO - 2018-05-17 23:14:26 --> URI Class Initialized
INFO - 2018-05-17 23:14:26 --> Router Class Initialized
INFO - 2018-05-17 23:14:26 --> Output Class Initialized
INFO - 2018-05-17 23:14:26 --> Security Class Initialized
DEBUG - 2018-05-17 23:14:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 23:14:26 --> Security Class Initialized
INFO - 2018-05-17 23:14:26 --> Input Class Initialized
DEBUG - 2018-05-17 23:14:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 23:14:26 --> Input Class Initialized
INFO - 2018-05-17 23:14:26 --> Language Class Initialized
INFO - 2018-05-17 23:14:26 --> Language Class Initialized
INFO - 2018-05-17 23:14:26 --> Language Class Initialized
ERROR - 2018-05-17 23:14:26 --> 404 Page Not Found: /index
INFO - 2018-05-17 23:14:26 --> Config Class Initialized
INFO - 2018-05-17 23:14:26 --> Loader Class Initialized
DEBUG - 2018-05-17 23:14:26 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-17 23:14:26 --> Helper loaded: url_helper
INFO - 2018-05-17 23:14:26 --> Helper loaded: form_helper
INFO - 2018-05-17 23:14:26 --> Helper loaded: date_helper
INFO - 2018-05-17 23:14:26 --> Helper loaded: util_helper
INFO - 2018-05-17 23:14:26 --> Helper loaded: text_helper
INFO - 2018-05-17 23:14:26 --> Helper loaded: string_helper
INFO - 2018-05-17 23:14:26 --> Database Driver Class Initialized
DEBUG - 2018-05-17 23:14:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-17 23:14:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-17 23:14:26 --> Email Class Initialized
INFO - 2018-05-17 23:14:26 --> Controller Class Initialized
DEBUG - 2018-05-17 23:14:26 --> Home MX_Controller Initialized
DEBUG - 2018-05-17 23:14:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-17 23:14:27 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-17 23:14:27 --> Login MX_Controller Initialized
INFO - 2018-05-17 23:14:27 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-17 23:14:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-17 23:14:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-17 23:14:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-17 23:14:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-17 23:14:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-17 23:14:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-17 23:14:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-17 23:14:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-05-17 23:14:27 --> Final output sent to browser
DEBUG - 2018-05-17 23:14:27 --> Total execution time: 1.2120
INFO - 2018-05-17 23:14:29 --> Config Class Initialized
INFO - 2018-05-17 23:14:29 --> Hooks Class Initialized
DEBUG - 2018-05-17 23:14:29 --> UTF-8 Support Enabled
INFO - 2018-05-17 23:14:29 --> Utf8 Class Initialized
INFO - 2018-05-17 23:14:29 --> URI Class Initialized
INFO - 2018-05-17 23:14:29 --> Router Class Initialized
INFO - 2018-05-17 23:14:29 --> Output Class Initialized
INFO - 2018-05-17 23:14:29 --> Security Class Initialized
DEBUG - 2018-05-17 23:14:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 23:14:29 --> Input Class Initialized
INFO - 2018-05-17 23:14:29 --> Language Class Initialized
INFO - 2018-05-17 23:14:29 --> Language Class Initialized
INFO - 2018-05-17 23:14:29 --> Config Class Initialized
INFO - 2018-05-17 23:14:29 --> Loader Class Initialized
DEBUG - 2018-05-17 23:14:29 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-17 23:14:29 --> Helper loaded: url_helper
INFO - 2018-05-17 23:14:29 --> Helper loaded: form_helper
INFO - 2018-05-17 23:14:29 --> Helper loaded: date_helper
INFO - 2018-05-17 23:14:29 --> Helper loaded: util_helper
INFO - 2018-05-17 23:14:29 --> Helper loaded: text_helper
INFO - 2018-05-17 23:14:29 --> Helper loaded: string_helper
INFO - 2018-05-17 23:14:29 --> Database Driver Class Initialized
DEBUG - 2018-05-17 23:14:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-17 23:14:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-17 23:14:29 --> Email Class Initialized
INFO - 2018-05-17 23:14:29 --> Controller Class Initialized
DEBUG - 2018-05-17 23:14:29 --> Home MX_Controller Initialized
DEBUG - 2018-05-17 23:14:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-17 23:14:30 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-17 23:14:30 --> Login MX_Controller Initialized
INFO - 2018-05-17 23:14:30 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-17 23:14:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-17 23:14:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-17 23:14:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-17 23:14:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-17 23:14:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-17 23:14:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-17 23:14:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-17 23:14:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-05-17 23:14:30 --> Final output sent to browser
DEBUG - 2018-05-17 23:14:30 --> Total execution time: 0.7948
INFO - 2018-05-17 23:14:36 --> Config Class Initialized
INFO - 2018-05-17 23:14:36 --> Hooks Class Initialized
DEBUG - 2018-05-17 23:14:36 --> UTF-8 Support Enabled
INFO - 2018-05-17 23:14:36 --> Utf8 Class Initialized
INFO - 2018-05-17 23:14:36 --> URI Class Initialized
INFO - 2018-05-17 23:14:36 --> Router Class Initialized
INFO - 2018-05-17 23:14:36 --> Output Class Initialized
INFO - 2018-05-17 23:14:36 --> Security Class Initialized
DEBUG - 2018-05-17 23:14:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 23:14:36 --> Input Class Initialized
INFO - 2018-05-17 23:14:36 --> Language Class Initialized
INFO - 2018-05-17 23:14:36 --> Language Class Initialized
INFO - 2018-05-17 23:14:36 --> Config Class Initialized
INFO - 2018-05-17 23:14:36 --> Loader Class Initialized
DEBUG - 2018-05-17 23:14:36 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-17 23:14:36 --> Helper loaded: url_helper
INFO - 2018-05-17 23:14:36 --> Helper loaded: form_helper
INFO - 2018-05-17 23:14:36 --> Helper loaded: date_helper
INFO - 2018-05-17 23:14:36 --> Helper loaded: util_helper
INFO - 2018-05-17 23:14:36 --> Helper loaded: text_helper
INFO - 2018-05-17 23:14:36 --> Helper loaded: string_helper
INFO - 2018-05-17 23:14:36 --> Database Driver Class Initialized
DEBUG - 2018-05-17 23:14:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-17 23:14:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-17 23:14:36 --> Email Class Initialized
INFO - 2018-05-17 23:14:36 --> Controller Class Initialized
DEBUG - 2018-05-17 23:14:36 --> Home MX_Controller Initialized
DEBUG - 2018-05-17 23:14:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-17 23:14:36 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-17 23:14:36 --> Login MX_Controller Initialized
INFO - 2018-05-17 23:14:36 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-17 23:14:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-17 23:14:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
ERROR - 2018-05-17 23:14:36 --> Severity: Notice --> Undefined offset: 0 E:\xampp\htdocs\consulting\application\modules\home\controllers\Home.php 28
DEBUG - 2018-05-17 23:14:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-17 23:14:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-17 23:14:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-17 23:14:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-17 23:14:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-17 23:14:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-05-17 23:14:36 --> Final output sent to browser
DEBUG - 2018-05-17 23:14:36 --> Total execution time: 0.7823
INFO - 2018-05-17 23:14:40 --> Config Class Initialized
INFO - 2018-05-17 23:14:40 --> Hooks Class Initialized
DEBUG - 2018-05-17 23:14:40 --> UTF-8 Support Enabled
INFO - 2018-05-17 23:14:40 --> Utf8 Class Initialized
INFO - 2018-05-17 23:14:40 --> URI Class Initialized
INFO - 2018-05-17 23:14:40 --> Router Class Initialized
INFO - 2018-05-17 23:14:40 --> Output Class Initialized
INFO - 2018-05-17 23:14:40 --> Security Class Initialized
DEBUG - 2018-05-17 23:14:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 23:14:40 --> Input Class Initialized
INFO - 2018-05-17 23:14:40 --> Language Class Initialized
INFO - 2018-05-17 23:14:40 --> Language Class Initialized
INFO - 2018-05-17 23:14:40 --> Config Class Initialized
INFO - 2018-05-17 23:14:40 --> Loader Class Initialized
DEBUG - 2018-05-17 23:14:40 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-17 23:14:40 --> Helper loaded: url_helper
INFO - 2018-05-17 23:14:40 --> Helper loaded: form_helper
INFO - 2018-05-17 23:14:40 --> Helper loaded: date_helper
INFO - 2018-05-17 23:14:41 --> Helper loaded: util_helper
INFO - 2018-05-17 23:14:41 --> Helper loaded: text_helper
INFO - 2018-05-17 23:14:41 --> Helper loaded: string_helper
INFO - 2018-05-17 23:14:41 --> Database Driver Class Initialized
DEBUG - 2018-05-17 23:14:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-17 23:14:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-17 23:14:41 --> Email Class Initialized
INFO - 2018-05-17 23:14:41 --> Controller Class Initialized
DEBUG - 2018-05-17 23:14:41 --> Home MX_Controller Initialized
DEBUG - 2018-05-17 23:14:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-17 23:14:41 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-17 23:14:41 --> Login MX_Controller Initialized
INFO - 2018-05-17 23:14:41 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-17 23:14:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-17 23:14:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-17 23:14:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-17 23:14:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-17 23:14:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-17 23:14:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-17 23:14:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-17 23:14:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-05-17 23:14:41 --> Final output sent to browser
DEBUG - 2018-05-17 23:14:41 --> Total execution time: 0.7681
INFO - 2018-05-17 23:14:59 --> Config Class Initialized
INFO - 2018-05-17 23:14:59 --> Hooks Class Initialized
DEBUG - 2018-05-17 23:14:59 --> UTF-8 Support Enabled
INFO - 2018-05-17 23:14:59 --> Utf8 Class Initialized
INFO - 2018-05-17 23:14:59 --> URI Class Initialized
INFO - 2018-05-17 23:14:59 --> Router Class Initialized
INFO - 2018-05-17 23:14:59 --> Output Class Initialized
INFO - 2018-05-17 23:14:59 --> Security Class Initialized
DEBUG - 2018-05-17 23:14:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 23:14:59 --> Input Class Initialized
INFO - 2018-05-17 23:14:59 --> Language Class Initialized
INFO - 2018-05-17 23:14:59 --> Language Class Initialized
INFO - 2018-05-17 23:14:59 --> Config Class Initialized
INFO - 2018-05-17 23:14:59 --> Loader Class Initialized
DEBUG - 2018-05-17 23:14:59 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-17 23:14:59 --> Helper loaded: url_helper
INFO - 2018-05-17 23:14:59 --> Helper loaded: form_helper
INFO - 2018-05-17 23:14:59 --> Helper loaded: date_helper
INFO - 2018-05-17 23:14:59 --> Helper loaded: util_helper
INFO - 2018-05-17 23:15:00 --> Helper loaded: text_helper
INFO - 2018-05-17 23:15:00 --> Helper loaded: string_helper
INFO - 2018-05-17 23:15:00 --> Database Driver Class Initialized
DEBUG - 2018-05-17 23:15:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-17 23:15:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-17 23:15:00 --> Email Class Initialized
INFO - 2018-05-17 23:15:00 --> Controller Class Initialized
DEBUG - 2018-05-17 23:15:00 --> Home MX_Controller Initialized
DEBUG - 2018-05-17 23:15:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-17 23:15:00 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-17 23:15:00 --> Login MX_Controller Initialized
INFO - 2018-05-17 23:15:00 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-17 23:15:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-17 23:15:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
ERROR - 2018-05-17 23:15:00 --> Severity: Notice --> Undefined offset: 0 E:\xampp\htdocs\consulting\application\modules\home\controllers\Home.php 28
DEBUG - 2018-05-17 23:15:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-17 23:15:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-17 23:15:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-17 23:15:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-17 23:15:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-17 23:15:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-05-17 23:15:00 --> Final output sent to browser
DEBUG - 2018-05-17 23:15:00 --> Total execution time: 0.7592
INFO - 2018-05-17 23:15:00 --> Config Class Initialized
INFO - 2018-05-17 23:15:00 --> Config Class Initialized
INFO - 2018-05-17 23:15:00 --> Hooks Class Initialized
INFO - 2018-05-17 23:15:00 --> Hooks Class Initialized
DEBUG - 2018-05-17 23:15:00 --> UTF-8 Support Enabled
DEBUG - 2018-05-17 23:15:00 --> UTF-8 Support Enabled
INFO - 2018-05-17 23:15:00 --> Utf8 Class Initialized
INFO - 2018-05-17 23:15:00 --> Utf8 Class Initialized
INFO - 2018-05-17 23:15:00 --> URI Class Initialized
INFO - 2018-05-17 23:15:00 --> URI Class Initialized
INFO - 2018-05-17 23:15:00 --> Router Class Initialized
INFO - 2018-05-17 23:15:00 --> Output Class Initialized
INFO - 2018-05-17 23:15:00 --> Router Class Initialized
INFO - 2018-05-17 23:15:01 --> Output Class Initialized
INFO - 2018-05-17 23:15:01 --> Security Class Initialized
INFO - 2018-05-17 23:15:01 --> Security Class Initialized
DEBUG - 2018-05-17 23:15:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-17 23:15:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 23:15:01 --> Input Class Initialized
INFO - 2018-05-17 23:15:01 --> Input Class Initialized
INFO - 2018-05-17 23:15:01 --> Language Class Initialized
INFO - 2018-05-17 23:15:01 --> Language Class Initialized
ERROR - 2018-05-17 23:15:01 --> 404 Page Not Found: /index
ERROR - 2018-05-17 23:15:01 --> 404 Page Not Found: /index
INFO - 2018-05-17 23:15:01 --> Config Class Initialized
INFO - 2018-05-17 23:15:01 --> Hooks Class Initialized
DEBUG - 2018-05-17 23:15:01 --> UTF-8 Support Enabled
INFO - 2018-05-17 23:15:01 --> Utf8 Class Initialized
INFO - 2018-05-17 23:15:01 --> URI Class Initialized
INFO - 2018-05-17 23:15:01 --> Router Class Initialized
INFO - 2018-05-17 23:15:01 --> Output Class Initialized
INFO - 2018-05-17 23:15:01 --> Security Class Initialized
DEBUG - 2018-05-17 23:15:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 23:15:01 --> Input Class Initialized
INFO - 2018-05-17 23:15:01 --> Language Class Initialized
ERROR - 2018-05-17 23:15:01 --> 404 Page Not Found: /index
INFO - 2018-05-17 23:15:01 --> Config Class Initialized
INFO - 2018-05-17 23:15:01 --> Hooks Class Initialized
DEBUG - 2018-05-17 23:15:01 --> UTF-8 Support Enabled
INFO - 2018-05-17 23:15:01 --> Utf8 Class Initialized
INFO - 2018-05-17 23:15:01 --> URI Class Initialized
INFO - 2018-05-17 23:15:01 --> Router Class Initialized
INFO - 2018-05-17 23:15:01 --> Output Class Initialized
INFO - 2018-05-17 23:15:01 --> Security Class Initialized
DEBUG - 2018-05-17 23:15:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 23:15:01 --> Input Class Initialized
INFO - 2018-05-17 23:15:01 --> Language Class Initialized
ERROR - 2018-05-17 23:15:02 --> 404 Page Not Found: /index
INFO - 2018-05-17 23:15:03 --> Config Class Initialized
INFO - 2018-05-17 23:15:03 --> Hooks Class Initialized
DEBUG - 2018-05-17 23:15:03 --> UTF-8 Support Enabled
INFO - 2018-05-17 23:15:03 --> Utf8 Class Initialized
INFO - 2018-05-17 23:15:03 --> URI Class Initialized
INFO - 2018-05-17 23:15:03 --> Router Class Initialized
INFO - 2018-05-17 23:15:03 --> Output Class Initialized
INFO - 2018-05-17 23:15:03 --> Security Class Initialized
DEBUG - 2018-05-17 23:15:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 23:15:03 --> Input Class Initialized
INFO - 2018-05-17 23:15:03 --> Language Class Initialized
INFO - 2018-05-17 23:15:03 --> Language Class Initialized
INFO - 2018-05-17 23:15:03 --> Config Class Initialized
INFO - 2018-05-17 23:15:03 --> Loader Class Initialized
DEBUG - 2018-05-17 23:15:03 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-17 23:15:03 --> Helper loaded: url_helper
INFO - 2018-05-17 23:15:03 --> Helper loaded: form_helper
INFO - 2018-05-17 23:15:03 --> Helper loaded: date_helper
INFO - 2018-05-17 23:15:03 --> Helper loaded: util_helper
INFO - 2018-05-17 23:15:03 --> Helper loaded: text_helper
INFO - 2018-05-17 23:15:04 --> Helper loaded: string_helper
INFO - 2018-05-17 23:15:04 --> Database Driver Class Initialized
DEBUG - 2018-05-17 23:15:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-17 23:15:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-17 23:15:04 --> Email Class Initialized
INFO - 2018-05-17 23:15:04 --> Controller Class Initialized
DEBUG - 2018-05-17 23:15:04 --> Home MX_Controller Initialized
DEBUG - 2018-05-17 23:15:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-17 23:15:04 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-17 23:15:04 --> Login MX_Controller Initialized
INFO - 2018-05-17 23:15:04 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-17 23:15:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-17 23:15:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-17 23:15:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-17 23:15:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-17 23:15:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-17 23:15:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-17 23:15:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-17 23:15:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-05-17 23:15:04 --> Final output sent to browser
DEBUG - 2018-05-17 23:15:04 --> Total execution time: 0.8115
INFO - 2018-05-17 23:15:11 --> Config Class Initialized
INFO - 2018-05-17 23:15:11 --> Hooks Class Initialized
DEBUG - 2018-05-17 23:15:11 --> UTF-8 Support Enabled
INFO - 2018-05-17 23:15:11 --> Utf8 Class Initialized
INFO - 2018-05-17 23:15:11 --> URI Class Initialized
INFO - 2018-05-17 23:15:11 --> Router Class Initialized
INFO - 2018-05-17 23:15:11 --> Output Class Initialized
INFO - 2018-05-17 23:15:11 --> Security Class Initialized
DEBUG - 2018-05-17 23:15:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 23:15:11 --> Input Class Initialized
INFO - 2018-05-17 23:15:11 --> Language Class Initialized
INFO - 2018-05-17 23:15:11 --> Language Class Initialized
INFO - 2018-05-17 23:15:11 --> Config Class Initialized
INFO - 2018-05-17 23:15:11 --> Loader Class Initialized
DEBUG - 2018-05-17 23:15:11 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-17 23:15:11 --> Helper loaded: url_helper
INFO - 2018-05-17 23:15:11 --> Helper loaded: form_helper
INFO - 2018-05-17 23:15:11 --> Helper loaded: date_helper
INFO - 2018-05-17 23:15:11 --> Helper loaded: util_helper
INFO - 2018-05-17 23:15:11 --> Helper loaded: text_helper
INFO - 2018-05-17 23:15:11 --> Helper loaded: string_helper
INFO - 2018-05-17 23:15:11 --> Database Driver Class Initialized
DEBUG - 2018-05-17 23:15:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-17 23:15:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-17 23:15:12 --> Email Class Initialized
INFO - 2018-05-17 23:15:12 --> Controller Class Initialized
DEBUG - 2018-05-17 23:15:12 --> Home MX_Controller Initialized
DEBUG - 2018-05-17 23:15:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-17 23:15:12 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-17 23:15:12 --> Login MX_Controller Initialized
INFO - 2018-05-17 23:15:12 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-17 23:15:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-17 23:15:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-17 23:15:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-17 23:15:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-17 23:15:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-17 23:15:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-17 23:15:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-17 23:15:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-05-17 23:15:12 --> Final output sent to browser
DEBUG - 2018-05-17 23:15:12 --> Total execution time: 0.7321
INFO - 2018-05-17 23:15:12 --> Config Class Initialized
INFO - 2018-05-17 23:15:12 --> Config Class Initialized
INFO - 2018-05-17 23:15:12 --> Hooks Class Initialized
INFO - 2018-05-17 23:15:12 --> Hooks Class Initialized
DEBUG - 2018-05-17 23:15:12 --> UTF-8 Support Enabled
DEBUG - 2018-05-17 23:15:12 --> UTF-8 Support Enabled
INFO - 2018-05-17 23:15:12 --> Utf8 Class Initialized
INFO - 2018-05-17 23:15:12 --> Utf8 Class Initialized
INFO - 2018-05-17 23:15:12 --> URI Class Initialized
INFO - 2018-05-17 23:15:12 --> URI Class Initialized
INFO - 2018-05-17 23:15:12 --> Router Class Initialized
INFO - 2018-05-17 23:15:12 --> Output Class Initialized
INFO - 2018-05-17 23:15:12 --> Security Class Initialized
INFO - 2018-05-17 23:15:12 --> Router Class Initialized
DEBUG - 2018-05-17 23:15:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 23:15:12 --> Output Class Initialized
INFO - 2018-05-17 23:15:12 --> Security Class Initialized
INFO - 2018-05-17 23:15:12 --> Input Class Initialized
DEBUG - 2018-05-17 23:15:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 23:15:12 --> Language Class Initialized
INFO - 2018-05-17 23:15:13 --> Input Class Initialized
INFO - 2018-05-17 23:15:13 --> Language Class Initialized
ERROR - 2018-05-17 23:15:13 --> 404 Page Not Found: /index
ERROR - 2018-05-17 23:15:13 --> 404 Page Not Found: /index
INFO - 2018-05-17 23:15:13 --> Config Class Initialized
INFO - 2018-05-17 23:15:13 --> Hooks Class Initialized
DEBUG - 2018-05-17 23:15:13 --> UTF-8 Support Enabled
INFO - 2018-05-17 23:15:13 --> Utf8 Class Initialized
INFO - 2018-05-17 23:15:13 --> URI Class Initialized
INFO - 2018-05-17 23:15:13 --> Router Class Initialized
INFO - 2018-05-17 23:15:13 --> Output Class Initialized
INFO - 2018-05-17 23:15:13 --> Security Class Initialized
DEBUG - 2018-05-17 23:15:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 23:15:13 --> Input Class Initialized
INFO - 2018-05-17 23:15:13 --> Language Class Initialized
ERROR - 2018-05-17 23:15:13 --> 404 Page Not Found: /index
INFO - 2018-05-17 23:15:13 --> Config Class Initialized
INFO - 2018-05-17 23:15:14 --> Hooks Class Initialized
DEBUG - 2018-05-17 23:15:14 --> UTF-8 Support Enabled
INFO - 2018-05-17 23:15:14 --> Utf8 Class Initialized
INFO - 2018-05-17 23:15:14 --> URI Class Initialized
INFO - 2018-05-17 23:15:14 --> Router Class Initialized
INFO - 2018-05-17 23:15:14 --> Output Class Initialized
INFO - 2018-05-17 23:15:14 --> Security Class Initialized
DEBUG - 2018-05-17 23:15:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 23:15:14 --> Input Class Initialized
INFO - 2018-05-17 23:15:14 --> Language Class Initialized
ERROR - 2018-05-17 23:15:14 --> 404 Page Not Found: /index
INFO - 2018-05-17 23:19:56 --> Config Class Initialized
INFO - 2018-05-17 23:19:56 --> Hooks Class Initialized
DEBUG - 2018-05-17 23:19:56 --> UTF-8 Support Enabled
INFO - 2018-05-17 23:19:56 --> Utf8 Class Initialized
INFO - 2018-05-17 23:19:56 --> URI Class Initialized
INFO - 2018-05-17 23:19:56 --> Router Class Initialized
INFO - 2018-05-17 23:19:56 --> Output Class Initialized
INFO - 2018-05-17 23:19:56 --> Security Class Initialized
DEBUG - 2018-05-17 23:19:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 23:19:56 --> Input Class Initialized
INFO - 2018-05-17 23:19:56 --> Language Class Initialized
INFO - 2018-05-17 23:19:56 --> Language Class Initialized
INFO - 2018-05-17 23:19:56 --> Config Class Initialized
INFO - 2018-05-17 23:19:56 --> Loader Class Initialized
DEBUG - 2018-05-17 23:19:56 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-17 23:19:56 --> Helper loaded: url_helper
INFO - 2018-05-17 23:19:56 --> Helper loaded: form_helper
INFO - 2018-05-17 23:19:56 --> Helper loaded: date_helper
INFO - 2018-05-17 23:19:56 --> Helper loaded: util_helper
INFO - 2018-05-17 23:19:56 --> Helper loaded: text_helper
INFO - 2018-05-17 23:19:56 --> Helper loaded: string_helper
INFO - 2018-05-17 23:19:56 --> Database Driver Class Initialized
DEBUG - 2018-05-17 23:19:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-17 23:19:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-17 23:19:56 --> Email Class Initialized
INFO - 2018-05-17 23:19:56 --> Controller Class Initialized
DEBUG - 2018-05-17 23:19:56 --> Home MX_Controller Initialized
DEBUG - 2018-05-17 23:19:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-17 23:19:56 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-17 23:19:56 --> Login MX_Controller Initialized
INFO - 2018-05-17 23:19:56 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-17 23:19:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-17 23:19:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-17 23:19:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-17 23:19:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-17 23:19:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-17 23:19:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-17 23:19:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-17 23:19:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-05-17 23:19:57 --> Final output sent to browser
DEBUG - 2018-05-17 23:19:57 --> Total execution time: 0.7778
INFO - 2018-05-17 23:19:57 --> Config Class Initialized
INFO - 2018-05-17 23:19:57 --> Config Class Initialized
INFO - 2018-05-17 23:19:57 --> Hooks Class Initialized
INFO - 2018-05-17 23:19:57 --> Hooks Class Initialized
DEBUG - 2018-05-17 23:19:57 --> UTF-8 Support Enabled
INFO - 2018-05-17 23:19:57 --> Utf8 Class Initialized
DEBUG - 2018-05-17 23:19:57 --> UTF-8 Support Enabled
INFO - 2018-05-17 23:19:57 --> URI Class Initialized
INFO - 2018-05-17 23:19:57 --> Utf8 Class Initialized
INFO - 2018-05-17 23:19:57 --> Router Class Initialized
INFO - 2018-05-17 23:19:57 --> URI Class Initialized
INFO - 2018-05-17 23:19:57 --> Output Class Initialized
INFO - 2018-05-17 23:19:57 --> Security Class Initialized
INFO - 2018-05-17 23:19:57 --> Router Class Initialized
DEBUG - 2018-05-17 23:19:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 23:19:57 --> Input Class Initialized
INFO - 2018-05-17 23:19:57 --> Language Class Initialized
ERROR - 2018-05-17 23:19:57 --> 404 Page Not Found: /index
INFO - 2018-05-17 23:19:57 --> Output Class Initialized
INFO - 2018-05-17 23:19:57 --> Security Class Initialized
DEBUG - 2018-05-17 23:19:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 23:19:57 --> Config Class Initialized
INFO - 2018-05-17 23:19:57 --> Hooks Class Initialized
INFO - 2018-05-17 23:19:57 --> Input Class Initialized
DEBUG - 2018-05-17 23:19:58 --> UTF-8 Support Enabled
INFO - 2018-05-17 23:19:58 --> Utf8 Class Initialized
INFO - 2018-05-17 23:19:58 --> URI Class Initialized
INFO - 2018-05-17 23:19:58 --> Router Class Initialized
INFO - 2018-05-17 23:19:58 --> Output Class Initialized
INFO - 2018-05-17 23:19:58 --> Security Class Initialized
INFO - 2018-05-17 23:19:58 --> Language Class Initialized
DEBUG - 2018-05-17 23:19:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 23:19:58 --> Input Class Initialized
ERROR - 2018-05-17 23:19:58 --> 404 Page Not Found: /index
INFO - 2018-05-17 23:19:58 --> Language Class Initialized
ERROR - 2018-05-17 23:19:58 --> 404 Page Not Found: /index
INFO - 2018-05-17 23:19:58 --> Config Class Initialized
INFO - 2018-05-17 23:19:58 --> Hooks Class Initialized
DEBUG - 2018-05-17 23:19:58 --> UTF-8 Support Enabled
INFO - 2018-05-17 23:19:58 --> Utf8 Class Initialized
INFO - 2018-05-17 23:19:58 --> URI Class Initialized
INFO - 2018-05-17 23:19:58 --> Router Class Initialized
INFO - 2018-05-17 23:19:58 --> Output Class Initialized
INFO - 2018-05-17 23:19:58 --> Security Class Initialized
DEBUG - 2018-05-17 23:19:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 23:19:58 --> Input Class Initialized
INFO - 2018-05-17 23:19:58 --> Language Class Initialized
ERROR - 2018-05-17 23:19:58 --> 404 Page Not Found: /index
INFO - 2018-05-17 23:20:00 --> Config Class Initialized
INFO - 2018-05-17 23:20:00 --> Hooks Class Initialized
DEBUG - 2018-05-17 23:20:00 --> UTF-8 Support Enabled
INFO - 2018-05-17 23:20:00 --> Utf8 Class Initialized
INFO - 2018-05-17 23:20:00 --> URI Class Initialized
INFO - 2018-05-17 23:20:00 --> Router Class Initialized
INFO - 2018-05-17 23:20:00 --> Output Class Initialized
INFO - 2018-05-17 23:20:00 --> Security Class Initialized
DEBUG - 2018-05-17 23:20:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 23:20:00 --> Input Class Initialized
INFO - 2018-05-17 23:20:00 --> Language Class Initialized
ERROR - 2018-05-17 23:20:00 --> 404 Page Not Found: /index
INFO - 2018-05-17 23:20:01 --> Config Class Initialized
INFO - 2018-05-17 23:20:01 --> Hooks Class Initialized
DEBUG - 2018-05-17 23:20:01 --> UTF-8 Support Enabled
INFO - 2018-05-17 23:20:01 --> Utf8 Class Initialized
INFO - 2018-05-17 23:20:01 --> URI Class Initialized
INFO - 2018-05-17 23:20:01 --> Router Class Initialized
INFO - 2018-05-17 23:20:01 --> Output Class Initialized
INFO - 2018-05-17 23:20:01 --> Security Class Initialized
DEBUG - 2018-05-17 23:20:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 23:20:01 --> Config Class Initialized
INFO - 2018-05-17 23:20:01 --> Hooks Class Initialized
INFO - 2018-05-17 23:20:01 --> Input Class Initialized
DEBUG - 2018-05-17 23:20:01 --> UTF-8 Support Enabled
INFO - 2018-05-17 23:20:01 --> Utf8 Class Initialized
INFO - 2018-05-17 23:20:01 --> Language Class Initialized
INFO - 2018-05-17 23:20:01 --> URI Class Initialized
ERROR - 2018-05-17 23:20:01 --> 404 Page Not Found: /index
INFO - 2018-05-17 23:20:01 --> Router Class Initialized
INFO - 2018-05-17 23:20:01 --> Output Class Initialized
INFO - 2018-05-17 23:20:01 --> Security Class Initialized
INFO - 2018-05-17 23:20:01 --> Config Class Initialized
INFO - 2018-05-17 23:20:01 --> Hooks Class Initialized
DEBUG - 2018-05-17 23:20:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-17 23:20:01 --> UTF-8 Support Enabled
INFO - 2018-05-17 23:20:01 --> Input Class Initialized
INFO - 2018-05-17 23:20:01 --> Language Class Initialized
INFO - 2018-05-17 23:20:01 --> Utf8 Class Initialized
INFO - 2018-05-17 23:20:01 --> Language Class Initialized
INFO - 2018-05-17 23:20:01 --> URI Class Initialized
INFO - 2018-05-17 23:20:01 --> Config Class Initialized
INFO - 2018-05-17 23:20:01 --> Loader Class Initialized
INFO - 2018-05-17 23:20:01 --> Router Class Initialized
DEBUG - 2018-05-17 23:20:01 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-17 23:20:01 --> Helper loaded: url_helper
INFO - 2018-05-17 23:20:01 --> Helper loaded: form_helper
INFO - 2018-05-17 23:20:01 --> Helper loaded: date_helper
INFO - 2018-05-17 23:20:01 --> Output Class Initialized
INFO - 2018-05-17 23:20:01 --> Helper loaded: util_helper
INFO - 2018-05-17 23:20:01 --> Helper loaded: text_helper
INFO - 2018-05-17 23:20:01 --> Security Class Initialized
INFO - 2018-05-17 23:20:01 --> Helper loaded: string_helper
DEBUG - 2018-05-17 23:20:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 23:20:01 --> Database Driver Class Initialized
INFO - 2018-05-17 23:20:01 --> Input Class Initialized
INFO - 2018-05-17 23:20:01 --> Language Class Initialized
DEBUG - 2018-05-17 23:20:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-17 23:20:01 --> Session: Class initialized using 'files' driver.
ERROR - 2018-05-17 23:20:01 --> 404 Page Not Found: /index
INFO - 2018-05-17 23:20:01 --> Email Class Initialized
INFO - 2018-05-17 23:20:01 --> Controller Class Initialized
DEBUG - 2018-05-17 23:20:01 --> Home MX_Controller Initialized
DEBUG - 2018-05-17 23:20:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-17 23:20:01 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-17 23:20:01 --> Login MX_Controller Initialized
INFO - 2018-05-17 23:20:01 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-17 23:20:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-17 23:20:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-17 23:20:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-17 23:20:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-17 23:20:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-17 23:20:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-17 23:20:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-17 23:20:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-05-17 23:20:02 --> Final output sent to browser
DEBUG - 2018-05-17 23:20:02 --> Total execution time: 0.9002
INFO - 2018-05-17 23:20:02 --> Config Class Initialized
INFO - 2018-05-17 23:20:02 --> Config Class Initialized
INFO - 2018-05-17 23:20:02 --> Hooks Class Initialized
INFO - 2018-05-17 23:20:02 --> Hooks Class Initialized
DEBUG - 2018-05-17 23:20:02 --> UTF-8 Support Enabled
INFO - 2018-05-17 23:20:02 --> Utf8 Class Initialized
INFO - 2018-05-17 23:20:02 --> URI Class Initialized
INFO - 2018-05-17 23:20:02 --> Router Class Initialized
DEBUG - 2018-05-17 23:20:02 --> UTF-8 Support Enabled
INFO - 2018-05-17 23:20:02 --> Output Class Initialized
INFO - 2018-05-17 23:20:02 --> Utf8 Class Initialized
INFO - 2018-05-17 23:20:02 --> URI Class Initialized
INFO - 2018-05-17 23:20:02 --> Router Class Initialized
INFO - 2018-05-17 23:20:02 --> Output Class Initialized
INFO - 2018-05-17 23:20:02 --> Security Class Initialized
DEBUG - 2018-05-17 23:20:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 23:20:02 --> Input Class Initialized
INFO - 2018-05-17 23:20:02 --> Language Class Initialized
INFO - 2018-05-17 23:20:02 --> Security Class Initialized
DEBUG - 2018-05-17 23:20:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-05-17 23:20:03 --> 404 Page Not Found: /index
INFO - 2018-05-17 23:20:03 --> Input Class Initialized
INFO - 2018-05-17 23:20:03 --> Language Class Initialized
ERROR - 2018-05-17 23:20:03 --> 404 Page Not Found: /index
INFO - 2018-05-17 23:20:03 --> Config Class Initialized
INFO - 2018-05-17 23:20:03 --> Hooks Class Initialized
DEBUG - 2018-05-17 23:20:03 --> UTF-8 Support Enabled
INFO - 2018-05-17 23:20:03 --> Utf8 Class Initialized
INFO - 2018-05-17 23:20:03 --> URI Class Initialized
INFO - 2018-05-17 23:20:03 --> Router Class Initialized
INFO - 2018-05-17 23:20:03 --> Output Class Initialized
INFO - 2018-05-17 23:20:03 --> Security Class Initialized
DEBUG - 2018-05-17 23:20:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 23:20:03 --> Input Class Initialized
INFO - 2018-05-17 23:20:03 --> Language Class Initialized
ERROR - 2018-05-17 23:20:03 --> 404 Page Not Found: /index
INFO - 2018-05-17 23:20:03 --> Config Class Initialized
INFO - 2018-05-17 23:20:03 --> Hooks Class Initialized
DEBUG - 2018-05-17 23:20:03 --> UTF-8 Support Enabled
INFO - 2018-05-17 23:20:03 --> Utf8 Class Initialized
INFO - 2018-05-17 23:20:03 --> URI Class Initialized
INFO - 2018-05-17 23:20:03 --> Router Class Initialized
INFO - 2018-05-17 23:20:03 --> Output Class Initialized
INFO - 2018-05-17 23:20:03 --> Security Class Initialized
DEBUG - 2018-05-17 23:20:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 23:20:04 --> Input Class Initialized
INFO - 2018-05-17 23:20:04 --> Language Class Initialized
ERROR - 2018-05-17 23:20:04 --> 404 Page Not Found: /index
INFO - 2018-05-17 23:20:09 --> Config Class Initialized
INFO - 2018-05-17 23:20:09 --> Hooks Class Initialized
DEBUG - 2018-05-17 23:20:09 --> UTF-8 Support Enabled
INFO - 2018-05-17 23:20:09 --> Utf8 Class Initialized
INFO - 2018-05-17 23:20:09 --> URI Class Initialized
INFO - 2018-05-17 23:20:09 --> Router Class Initialized
INFO - 2018-05-17 23:20:09 --> Output Class Initialized
INFO - 2018-05-17 23:20:09 --> Security Class Initialized
DEBUG - 2018-05-17 23:20:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 23:20:09 --> Input Class Initialized
INFO - 2018-05-17 23:20:09 --> Language Class Initialized
INFO - 2018-05-17 23:20:09 --> Language Class Initialized
INFO - 2018-05-17 23:20:09 --> Config Class Initialized
INFO - 2018-05-17 23:20:09 --> Loader Class Initialized
DEBUG - 2018-05-17 23:20:09 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-17 23:20:09 --> Helper loaded: url_helper
INFO - 2018-05-17 23:20:09 --> Helper loaded: form_helper
INFO - 2018-05-17 23:20:09 --> Helper loaded: date_helper
INFO - 2018-05-17 23:20:09 --> Helper loaded: util_helper
INFO - 2018-05-17 23:20:09 --> Helper loaded: text_helper
INFO - 2018-05-17 23:20:09 --> Helper loaded: string_helper
INFO - 2018-05-17 23:20:09 --> Database Driver Class Initialized
DEBUG - 2018-05-17 23:20:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-17 23:20:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-17 23:20:09 --> Email Class Initialized
INFO - 2018-05-17 23:20:09 --> Controller Class Initialized
DEBUG - 2018-05-17 23:20:09 --> Home MX_Controller Initialized
DEBUG - 2018-05-17 23:20:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-17 23:20:09 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-17 23:20:09 --> Login MX_Controller Initialized
INFO - 2018-05-17 23:20:09 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-17 23:20:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-17 23:20:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-17 23:20:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-17 23:20:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-17 23:20:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-17 23:20:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-17 23:20:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-17 23:20:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-05-17 23:20:10 --> Final output sent to browser
DEBUG - 2018-05-17 23:20:10 --> Total execution time: 0.8014
INFO - 2018-05-17 23:20:10 --> Config Class Initialized
INFO - 2018-05-17 23:20:10 --> Config Class Initialized
INFO - 2018-05-17 23:20:10 --> Hooks Class Initialized
DEBUG - 2018-05-17 23:20:10 --> UTF-8 Support Enabled
INFO - 2018-05-17 23:20:10 --> Utf8 Class Initialized
INFO - 2018-05-17 23:20:10 --> URI Class Initialized
INFO - 2018-05-17 23:20:10 --> Router Class Initialized
INFO - 2018-05-17 23:20:10 --> Hooks Class Initialized
INFO - 2018-05-17 23:20:10 --> Output Class Initialized
INFO - 2018-05-17 23:20:10 --> Security Class Initialized
DEBUG - 2018-05-17 23:20:10 --> UTF-8 Support Enabled
INFO - 2018-05-17 23:20:10 --> Utf8 Class Initialized
DEBUG - 2018-05-17 23:20:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 23:20:10 --> Input Class Initialized
INFO - 2018-05-17 23:20:10 --> URI Class Initialized
INFO - 2018-05-17 23:20:10 --> Language Class Initialized
ERROR - 2018-05-17 23:20:10 --> 404 Page Not Found: /index
INFO - 2018-05-17 23:20:10 --> Router Class Initialized
INFO - 2018-05-17 23:20:10 --> Output Class Initialized
INFO - 2018-05-17 23:20:10 --> Security Class Initialized
DEBUG - 2018-05-17 23:20:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 23:20:10 --> Input Class Initialized
INFO - 2018-05-17 23:20:10 --> Language Class Initialized
ERROR - 2018-05-17 23:20:10 --> 404 Page Not Found: /index
INFO - 2018-05-17 23:20:11 --> Config Class Initialized
INFO - 2018-05-17 23:20:11 --> Hooks Class Initialized
DEBUG - 2018-05-17 23:20:11 --> UTF-8 Support Enabled
INFO - 2018-05-17 23:20:11 --> Utf8 Class Initialized
INFO - 2018-05-17 23:20:11 --> URI Class Initialized
INFO - 2018-05-17 23:20:11 --> Router Class Initialized
INFO - 2018-05-17 23:20:11 --> Output Class Initialized
INFO - 2018-05-17 23:20:11 --> Security Class Initialized
DEBUG - 2018-05-17 23:20:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 23:20:11 --> Input Class Initialized
INFO - 2018-05-17 23:20:11 --> Language Class Initialized
ERROR - 2018-05-17 23:20:11 --> 404 Page Not Found: /index
INFO - 2018-05-17 23:20:11 --> Config Class Initialized
INFO - 2018-05-17 23:20:11 --> Hooks Class Initialized
DEBUG - 2018-05-17 23:20:11 --> UTF-8 Support Enabled
INFO - 2018-05-17 23:20:11 --> Utf8 Class Initialized
INFO - 2018-05-17 23:20:11 --> URI Class Initialized
INFO - 2018-05-17 23:20:11 --> Router Class Initialized
INFO - 2018-05-17 23:20:11 --> Output Class Initialized
INFO - 2018-05-17 23:20:11 --> Security Class Initialized
DEBUG - 2018-05-17 23:20:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 23:20:11 --> Input Class Initialized
INFO - 2018-05-17 23:20:11 --> Language Class Initialized
ERROR - 2018-05-17 23:20:11 --> 404 Page Not Found: /index
INFO - 2018-05-17 23:20:13 --> Config Class Initialized
INFO - 2018-05-17 23:20:13 --> Hooks Class Initialized
DEBUG - 2018-05-17 23:20:13 --> UTF-8 Support Enabled
INFO - 2018-05-17 23:20:13 --> Utf8 Class Initialized
INFO - 2018-05-17 23:20:13 --> URI Class Initialized
INFO - 2018-05-17 23:20:13 --> Router Class Initialized
INFO - 2018-05-17 23:20:13 --> Output Class Initialized
INFO - 2018-05-17 23:20:13 --> Security Class Initialized
DEBUG - 2018-05-17 23:20:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 23:20:13 --> Input Class Initialized
INFO - 2018-05-17 23:20:13 --> Language Class Initialized
ERROR - 2018-05-17 23:20:13 --> 404 Page Not Found: /index
INFO - 2018-05-17 23:20:13 --> Config Class Initialized
INFO - 2018-05-17 23:20:13 --> Hooks Class Initialized
DEBUG - 2018-05-17 23:20:13 --> UTF-8 Support Enabled
INFO - 2018-05-17 23:20:13 --> Utf8 Class Initialized
INFO - 2018-05-17 23:20:13 --> URI Class Initialized
INFO - 2018-05-17 23:20:13 --> Router Class Initialized
INFO - 2018-05-17 23:20:13 --> Output Class Initialized
INFO - 2018-05-17 23:20:13 --> Security Class Initialized
DEBUG - 2018-05-17 23:20:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 23:20:13 --> Input Class Initialized
INFO - 2018-05-17 23:20:13 --> Language Class Initialized
ERROR - 2018-05-17 23:20:13 --> 404 Page Not Found: /index
INFO - 2018-05-17 23:20:13 --> Config Class Initialized
INFO - 2018-05-17 23:20:13 --> Hooks Class Initialized
DEBUG - 2018-05-17 23:20:13 --> UTF-8 Support Enabled
INFO - 2018-05-17 23:20:13 --> Utf8 Class Initialized
INFO - 2018-05-17 23:20:13 --> URI Class Initialized
INFO - 2018-05-17 23:20:13 --> Router Class Initialized
INFO - 2018-05-17 23:20:13 --> Output Class Initialized
INFO - 2018-05-17 23:20:13 --> Security Class Initialized
DEBUG - 2018-05-17 23:20:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 23:20:13 --> Input Class Initialized
INFO - 2018-05-17 23:20:13 --> Language Class Initialized
ERROR - 2018-05-17 23:20:13 --> 404 Page Not Found: /index
INFO - 2018-05-17 23:20:30 --> Config Class Initialized
INFO - 2018-05-17 23:20:30 --> Hooks Class Initialized
DEBUG - 2018-05-17 23:20:30 --> UTF-8 Support Enabled
INFO - 2018-05-17 23:20:30 --> Utf8 Class Initialized
INFO - 2018-05-17 23:20:30 --> URI Class Initialized
INFO - 2018-05-17 23:20:30 --> Router Class Initialized
INFO - 2018-05-17 23:20:30 --> Output Class Initialized
INFO - 2018-05-17 23:20:30 --> Security Class Initialized
DEBUG - 2018-05-17 23:20:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 23:20:30 --> Input Class Initialized
INFO - 2018-05-17 23:20:30 --> Language Class Initialized
INFO - 2018-05-17 23:20:30 --> Language Class Initialized
INFO - 2018-05-17 23:20:30 --> Config Class Initialized
INFO - 2018-05-17 23:20:30 --> Loader Class Initialized
DEBUG - 2018-05-17 23:20:30 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-17 23:20:31 --> Helper loaded: url_helper
INFO - 2018-05-17 23:20:31 --> Helper loaded: form_helper
INFO - 2018-05-17 23:20:31 --> Helper loaded: date_helper
INFO - 2018-05-17 23:20:31 --> Helper loaded: util_helper
INFO - 2018-05-17 23:20:31 --> Helper loaded: text_helper
INFO - 2018-05-17 23:20:31 --> Helper loaded: string_helper
INFO - 2018-05-17 23:20:31 --> Database Driver Class Initialized
DEBUG - 2018-05-17 23:20:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-17 23:20:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-17 23:20:31 --> Email Class Initialized
INFO - 2018-05-17 23:20:31 --> Controller Class Initialized
DEBUG - 2018-05-17 23:20:31 --> Home MX_Controller Initialized
DEBUG - 2018-05-17 23:20:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-17 23:20:31 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-17 23:20:31 --> Login MX_Controller Initialized
INFO - 2018-05-17 23:20:31 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-17 23:20:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-17 23:20:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-17 23:20:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-17 23:20:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-17 23:20:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-17 23:20:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-17 23:20:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-17 23:20:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-05-17 23:20:31 --> Final output sent to browser
DEBUG - 2018-05-17 23:20:31 --> Total execution time: 0.7666
INFO - 2018-05-17 23:20:31 --> Config Class Initialized
INFO - 2018-05-17 23:20:31 --> Config Class Initialized
INFO - 2018-05-17 23:20:31 --> Hooks Class Initialized
INFO - 2018-05-17 23:20:31 --> Hooks Class Initialized
DEBUG - 2018-05-17 23:20:31 --> UTF-8 Support Enabled
INFO - 2018-05-17 23:20:31 --> Utf8 Class Initialized
INFO - 2018-05-17 23:20:31 --> URI Class Initialized
INFO - 2018-05-17 23:20:31 --> Router Class Initialized
INFO - 2018-05-17 23:20:31 --> Output Class Initialized
INFO - 2018-05-17 23:20:31 --> Security Class Initialized
DEBUG - 2018-05-17 23:20:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 23:20:31 --> Input Class Initialized
DEBUG - 2018-05-17 23:20:31 --> UTF-8 Support Enabled
INFO - 2018-05-17 23:20:31 --> Language Class Initialized
INFO - 2018-05-17 23:20:32 --> Utf8 Class Initialized
ERROR - 2018-05-17 23:20:32 --> 404 Page Not Found: /index
INFO - 2018-05-17 23:20:32 --> URI Class Initialized
INFO - 2018-05-17 23:20:32 --> Router Class Initialized
INFO - 2018-05-17 23:20:32 --> Output Class Initialized
INFO - 2018-05-17 23:20:32 --> Security Class Initialized
DEBUG - 2018-05-17 23:20:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 23:20:32 --> Input Class Initialized
INFO - 2018-05-17 23:20:32 --> Language Class Initialized
ERROR - 2018-05-17 23:20:32 --> 404 Page Not Found: /index
INFO - 2018-05-17 23:20:32 --> Config Class Initialized
INFO - 2018-05-17 23:20:32 --> Hooks Class Initialized
DEBUG - 2018-05-17 23:20:32 --> UTF-8 Support Enabled
INFO - 2018-05-17 23:20:32 --> Utf8 Class Initialized
INFO - 2018-05-17 23:20:32 --> URI Class Initialized
INFO - 2018-05-17 23:20:32 --> Router Class Initialized
INFO - 2018-05-17 23:20:32 --> Output Class Initialized
INFO - 2018-05-17 23:20:32 --> Security Class Initialized
DEBUG - 2018-05-17 23:20:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 23:20:32 --> Input Class Initialized
INFO - 2018-05-17 23:20:32 --> Language Class Initialized
ERROR - 2018-05-17 23:20:32 --> 404 Page Not Found: /index
INFO - 2018-05-17 23:20:33 --> Config Class Initialized
INFO - 2018-05-17 23:20:33 --> Hooks Class Initialized
DEBUG - 2018-05-17 23:20:33 --> UTF-8 Support Enabled
INFO - 2018-05-17 23:20:33 --> Utf8 Class Initialized
INFO - 2018-05-17 23:20:33 --> URI Class Initialized
INFO - 2018-05-17 23:20:33 --> Router Class Initialized
INFO - 2018-05-17 23:20:33 --> Output Class Initialized
INFO - 2018-05-17 23:20:33 --> Security Class Initialized
DEBUG - 2018-05-17 23:20:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 23:20:33 --> Input Class Initialized
INFO - 2018-05-17 23:20:33 --> Language Class Initialized
ERROR - 2018-05-17 23:20:33 --> 404 Page Not Found: /index
INFO - 2018-05-17 23:20:34 --> Config Class Initialized
INFO - 2018-05-17 23:20:34 --> Hooks Class Initialized
DEBUG - 2018-05-17 23:20:34 --> UTF-8 Support Enabled
INFO - 2018-05-17 23:20:34 --> Utf8 Class Initialized
INFO - 2018-05-17 23:20:34 --> URI Class Initialized
INFO - 2018-05-17 23:20:34 --> Router Class Initialized
INFO - 2018-05-17 23:20:34 --> Output Class Initialized
INFO - 2018-05-17 23:20:34 --> Security Class Initialized
DEBUG - 2018-05-17 23:20:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 23:20:34 --> Input Class Initialized
INFO - 2018-05-17 23:20:34 --> Language Class Initialized
ERROR - 2018-05-17 23:20:34 --> 404 Page Not Found: /index
INFO - 2018-05-17 23:20:34 --> Config Class Initialized
INFO - 2018-05-17 23:20:34 --> Hooks Class Initialized
DEBUG - 2018-05-17 23:20:34 --> UTF-8 Support Enabled
INFO - 2018-05-17 23:20:34 --> Utf8 Class Initialized
INFO - 2018-05-17 23:20:34 --> URI Class Initialized
INFO - 2018-05-17 23:20:34 --> Router Class Initialized
INFO - 2018-05-17 23:20:34 --> Output Class Initialized
INFO - 2018-05-17 23:20:34 --> Security Class Initialized
DEBUG - 2018-05-17 23:20:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 23:20:35 --> Input Class Initialized
INFO - 2018-05-17 23:20:35 --> Language Class Initialized
ERROR - 2018-05-17 23:20:35 --> 404 Page Not Found: /index
INFO - 2018-05-17 23:20:35 --> Config Class Initialized
INFO - 2018-05-17 23:20:35 --> Hooks Class Initialized
DEBUG - 2018-05-17 23:20:35 --> UTF-8 Support Enabled
INFO - 2018-05-17 23:20:35 --> Utf8 Class Initialized
INFO - 2018-05-17 23:20:35 --> URI Class Initialized
INFO - 2018-05-17 23:20:35 --> Router Class Initialized
INFO - 2018-05-17 23:20:35 --> Output Class Initialized
INFO - 2018-05-17 23:20:35 --> Security Class Initialized
DEBUG - 2018-05-17 23:20:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 23:20:35 --> Input Class Initialized
INFO - 2018-05-17 23:20:35 --> Language Class Initialized
ERROR - 2018-05-17 23:20:35 --> 404 Page Not Found: /index
INFO - 2018-05-17 23:20:45 --> Config Class Initialized
INFO - 2018-05-17 23:20:45 --> Hooks Class Initialized
DEBUG - 2018-05-17 23:20:45 --> UTF-8 Support Enabled
INFO - 2018-05-17 23:20:45 --> Utf8 Class Initialized
INFO - 2018-05-17 23:20:45 --> URI Class Initialized
INFO - 2018-05-17 23:20:45 --> Router Class Initialized
INFO - 2018-05-17 23:20:45 --> Output Class Initialized
INFO - 2018-05-17 23:20:45 --> Security Class Initialized
DEBUG - 2018-05-17 23:20:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 23:20:45 --> Input Class Initialized
INFO - 2018-05-17 23:20:45 --> Language Class Initialized
INFO - 2018-05-17 23:20:45 --> Language Class Initialized
INFO - 2018-05-17 23:20:45 --> Config Class Initialized
INFO - 2018-05-17 23:20:45 --> Loader Class Initialized
DEBUG - 2018-05-17 23:20:45 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-17 23:20:45 --> Helper loaded: url_helper
INFO - 2018-05-17 23:20:45 --> Helper loaded: form_helper
INFO - 2018-05-17 23:20:45 --> Helper loaded: date_helper
INFO - 2018-05-17 23:20:45 --> Helper loaded: util_helper
INFO - 2018-05-17 23:20:45 --> Helper loaded: text_helper
INFO - 2018-05-17 23:20:45 --> Helper loaded: string_helper
INFO - 2018-05-17 23:20:45 --> Database Driver Class Initialized
DEBUG - 2018-05-17 23:20:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-17 23:20:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-17 23:20:45 --> Email Class Initialized
INFO - 2018-05-17 23:20:45 --> Controller Class Initialized
DEBUG - 2018-05-17 23:20:45 --> Home MX_Controller Initialized
DEBUG - 2018-05-17 23:20:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-17 23:20:45 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-17 23:20:45 --> Login MX_Controller Initialized
INFO - 2018-05-17 23:20:45 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-17 23:20:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-17 23:20:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-17 23:20:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-17 23:20:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-17 23:20:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-17 23:20:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-17 23:20:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-17 23:20:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-05-17 23:20:46 --> Final output sent to browser
DEBUG - 2018-05-17 23:20:46 --> Total execution time: 0.8324
INFO - 2018-05-17 23:20:46 --> Config Class Initialized
INFO - 2018-05-17 23:20:46 --> Config Class Initialized
INFO - 2018-05-17 23:20:46 --> Hooks Class Initialized
INFO - 2018-05-17 23:20:46 --> Hooks Class Initialized
DEBUG - 2018-05-17 23:20:46 --> UTF-8 Support Enabled
INFO - 2018-05-17 23:20:46 --> Utf8 Class Initialized
INFO - 2018-05-17 23:20:46 --> URI Class Initialized
DEBUG - 2018-05-17 23:20:46 --> UTF-8 Support Enabled
INFO - 2018-05-17 23:20:46 --> Router Class Initialized
INFO - 2018-05-17 23:20:46 --> Utf8 Class Initialized
INFO - 2018-05-17 23:20:46 --> Output Class Initialized
INFO - 2018-05-17 23:20:46 --> URI Class Initialized
INFO - 2018-05-17 23:20:46 --> Security Class Initialized
INFO - 2018-05-17 23:20:46 --> Router Class Initialized
DEBUG - 2018-05-17 23:20:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 23:20:46 --> Output Class Initialized
INFO - 2018-05-17 23:20:46 --> Input Class Initialized
INFO - 2018-05-17 23:20:46 --> Security Class Initialized
INFO - 2018-05-17 23:20:46 --> Language Class Initialized
DEBUG - 2018-05-17 23:20:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 23:20:46 --> Input Class Initialized
ERROR - 2018-05-17 23:20:46 --> 404 Page Not Found: /index
INFO - 2018-05-17 23:20:47 --> Language Class Initialized
ERROR - 2018-05-17 23:20:47 --> 404 Page Not Found: /index
INFO - 2018-05-17 23:20:47 --> Config Class Initialized
INFO - 2018-05-17 23:20:47 --> Hooks Class Initialized
DEBUG - 2018-05-17 23:20:47 --> UTF-8 Support Enabled
INFO - 2018-05-17 23:20:47 --> Utf8 Class Initialized
INFO - 2018-05-17 23:20:47 --> URI Class Initialized
INFO - 2018-05-17 23:20:47 --> Router Class Initialized
INFO - 2018-05-17 23:20:47 --> Output Class Initialized
INFO - 2018-05-17 23:20:47 --> Security Class Initialized
DEBUG - 2018-05-17 23:20:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 23:20:47 --> Input Class Initialized
INFO - 2018-05-17 23:20:47 --> Language Class Initialized
ERROR - 2018-05-17 23:20:47 --> 404 Page Not Found: /index
INFO - 2018-05-17 23:20:47 --> Config Class Initialized
INFO - 2018-05-17 23:20:47 --> Hooks Class Initialized
DEBUG - 2018-05-17 23:20:47 --> UTF-8 Support Enabled
INFO - 2018-05-17 23:20:47 --> Utf8 Class Initialized
INFO - 2018-05-17 23:20:47 --> URI Class Initialized
INFO - 2018-05-17 23:20:47 --> Router Class Initialized
INFO - 2018-05-17 23:20:47 --> Output Class Initialized
INFO - 2018-05-17 23:20:48 --> Security Class Initialized
DEBUG - 2018-05-17 23:20:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 23:20:48 --> Input Class Initialized
INFO - 2018-05-17 23:20:48 --> Language Class Initialized
ERROR - 2018-05-17 23:20:48 --> 404 Page Not Found: /index
INFO - 2018-05-17 23:20:48 --> Config Class Initialized
INFO - 2018-05-17 23:20:48 --> Hooks Class Initialized
DEBUG - 2018-05-17 23:20:48 --> UTF-8 Support Enabled
INFO - 2018-05-17 23:20:48 --> Utf8 Class Initialized
INFO - 2018-05-17 23:20:48 --> URI Class Initialized
INFO - 2018-05-17 23:20:48 --> Router Class Initialized
INFO - 2018-05-17 23:20:48 --> Output Class Initialized
INFO - 2018-05-17 23:20:48 --> Security Class Initialized
DEBUG - 2018-05-17 23:20:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 23:20:48 --> Input Class Initialized
INFO - 2018-05-17 23:20:48 --> Language Class Initialized
ERROR - 2018-05-17 23:20:48 --> 404 Page Not Found: /index
INFO - 2018-05-17 23:20:48 --> Config Class Initialized
INFO - 2018-05-17 23:20:48 --> Hooks Class Initialized
DEBUG - 2018-05-17 23:20:48 --> UTF-8 Support Enabled
INFO - 2018-05-17 23:20:48 --> Utf8 Class Initialized
INFO - 2018-05-17 23:20:48 --> URI Class Initialized
INFO - 2018-05-17 23:20:49 --> Router Class Initialized
INFO - 2018-05-17 23:20:49 --> Output Class Initialized
INFO - 2018-05-17 23:20:49 --> Security Class Initialized
DEBUG - 2018-05-17 23:20:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 23:20:49 --> Input Class Initialized
INFO - 2018-05-17 23:20:49 --> Language Class Initialized
ERROR - 2018-05-17 23:20:49 --> 404 Page Not Found: /index
INFO - 2018-05-17 23:20:49 --> Config Class Initialized
INFO - 2018-05-17 23:20:49 --> Hooks Class Initialized
DEBUG - 2018-05-17 23:20:49 --> UTF-8 Support Enabled
INFO - 2018-05-17 23:20:49 --> Utf8 Class Initialized
INFO - 2018-05-17 23:20:49 --> URI Class Initialized
INFO - 2018-05-17 23:20:49 --> Router Class Initialized
INFO - 2018-05-17 23:20:49 --> Output Class Initialized
INFO - 2018-05-17 23:20:49 --> Security Class Initialized
DEBUG - 2018-05-17 23:20:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 23:20:49 --> Input Class Initialized
INFO - 2018-05-17 23:20:49 --> Language Class Initialized
ERROR - 2018-05-17 23:20:49 --> 404 Page Not Found: /index
INFO - 2018-05-17 23:20:55 --> Config Class Initialized
INFO - 2018-05-17 23:20:55 --> Hooks Class Initialized
DEBUG - 2018-05-17 23:20:55 --> UTF-8 Support Enabled
INFO - 2018-05-17 23:20:55 --> Utf8 Class Initialized
INFO - 2018-05-17 23:20:55 --> URI Class Initialized
INFO - 2018-05-17 23:20:55 --> Router Class Initialized
INFO - 2018-05-17 23:20:55 --> Output Class Initialized
INFO - 2018-05-17 23:20:56 --> Security Class Initialized
DEBUG - 2018-05-17 23:20:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 23:20:56 --> Input Class Initialized
INFO - 2018-05-17 23:20:56 --> Language Class Initialized
INFO - 2018-05-17 23:20:56 --> Language Class Initialized
INFO - 2018-05-17 23:20:56 --> Config Class Initialized
INFO - 2018-05-17 23:20:56 --> Loader Class Initialized
DEBUG - 2018-05-17 23:20:56 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-17 23:20:56 --> Helper loaded: url_helper
INFO - 2018-05-17 23:20:56 --> Helper loaded: form_helper
INFO - 2018-05-17 23:20:56 --> Helper loaded: date_helper
INFO - 2018-05-17 23:20:56 --> Helper loaded: util_helper
INFO - 2018-05-17 23:20:56 --> Helper loaded: text_helper
INFO - 2018-05-17 23:20:56 --> Helper loaded: string_helper
INFO - 2018-05-17 23:20:56 --> Database Driver Class Initialized
DEBUG - 2018-05-17 23:20:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-17 23:20:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-17 23:20:56 --> Email Class Initialized
INFO - 2018-05-17 23:20:56 --> Controller Class Initialized
DEBUG - 2018-05-17 23:20:56 --> Home MX_Controller Initialized
DEBUG - 2018-05-17 23:20:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-17 23:20:56 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-17 23:20:56 --> Login MX_Controller Initialized
INFO - 2018-05-17 23:20:56 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-17 23:20:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-17 23:20:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-17 23:20:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-17 23:20:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-17 23:20:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-17 23:20:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-17 23:20:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-17 23:20:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-05-17 23:20:56 --> Final output sent to browser
DEBUG - 2018-05-17 23:20:56 --> Total execution time: 0.7863
INFO - 2018-05-17 23:20:56 --> Config Class Initialized
INFO - 2018-05-17 23:20:56 --> Config Class Initialized
INFO - 2018-05-17 23:20:56 --> Hooks Class Initialized
DEBUG - 2018-05-17 23:20:56 --> UTF-8 Support Enabled
INFO - 2018-05-17 23:20:56 --> Utf8 Class Initialized
INFO - 2018-05-17 23:20:56 --> Hooks Class Initialized
INFO - 2018-05-17 23:20:57 --> URI Class Initialized
INFO - 2018-05-17 23:20:57 --> Router Class Initialized
DEBUG - 2018-05-17 23:20:57 --> UTF-8 Support Enabled
INFO - 2018-05-17 23:20:57 --> Output Class Initialized
INFO - 2018-05-17 23:20:57 --> Security Class Initialized
INFO - 2018-05-17 23:20:57 --> Utf8 Class Initialized
DEBUG - 2018-05-17 23:20:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 23:20:57 --> Input Class Initialized
INFO - 2018-05-17 23:20:57 --> URI Class Initialized
INFO - 2018-05-17 23:20:57 --> Language Class Initialized
ERROR - 2018-05-17 23:20:57 --> 404 Page Not Found: /index
INFO - 2018-05-17 23:20:57 --> Router Class Initialized
INFO - 2018-05-17 23:20:57 --> Output Class Initialized
INFO - 2018-05-17 23:20:57 --> Security Class Initialized
DEBUG - 2018-05-17 23:20:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 23:20:57 --> Input Class Initialized
INFO - 2018-05-17 23:20:57 --> Language Class Initialized
ERROR - 2018-05-17 23:20:57 --> 404 Page Not Found: /index
INFO - 2018-05-17 23:20:57 --> Config Class Initialized
INFO - 2018-05-17 23:20:57 --> Hooks Class Initialized
DEBUG - 2018-05-17 23:20:57 --> UTF-8 Support Enabled
INFO - 2018-05-17 23:20:57 --> Utf8 Class Initialized
INFO - 2018-05-17 23:20:57 --> URI Class Initialized
INFO - 2018-05-17 23:20:57 --> Router Class Initialized
INFO - 2018-05-17 23:20:57 --> Output Class Initialized
INFO - 2018-05-17 23:20:58 --> Security Class Initialized
DEBUG - 2018-05-17 23:20:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 23:20:58 --> Input Class Initialized
INFO - 2018-05-17 23:20:58 --> Language Class Initialized
ERROR - 2018-05-17 23:20:58 --> 404 Page Not Found: /index
INFO - 2018-05-17 23:20:58 --> Config Class Initialized
INFO - 2018-05-17 23:20:58 --> Hooks Class Initialized
DEBUG - 2018-05-17 23:20:58 --> UTF-8 Support Enabled
INFO - 2018-05-17 23:20:58 --> Utf8 Class Initialized
INFO - 2018-05-17 23:20:58 --> URI Class Initialized
INFO - 2018-05-17 23:20:58 --> Router Class Initialized
INFO - 2018-05-17 23:20:58 --> Output Class Initialized
INFO - 2018-05-17 23:20:58 --> Security Class Initialized
DEBUG - 2018-05-17 23:20:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 23:20:58 --> Input Class Initialized
INFO - 2018-05-17 23:20:58 --> Language Class Initialized
ERROR - 2018-05-17 23:20:58 --> 404 Page Not Found: /index
INFO - 2018-05-17 23:20:59 --> Config Class Initialized
INFO - 2018-05-17 23:20:59 --> Hooks Class Initialized
DEBUG - 2018-05-17 23:20:59 --> UTF-8 Support Enabled
INFO - 2018-05-17 23:20:59 --> Utf8 Class Initialized
INFO - 2018-05-17 23:20:59 --> URI Class Initialized
INFO - 2018-05-17 23:20:59 --> Router Class Initialized
INFO - 2018-05-17 23:20:59 --> Output Class Initialized
INFO - 2018-05-17 23:20:59 --> Security Class Initialized
DEBUG - 2018-05-17 23:20:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 23:20:59 --> Input Class Initialized
INFO - 2018-05-17 23:20:59 --> Language Class Initialized
ERROR - 2018-05-17 23:20:59 --> 404 Page Not Found: /index
INFO - 2018-05-17 23:20:59 --> Config Class Initialized
INFO - 2018-05-17 23:20:59 --> Hooks Class Initialized
DEBUG - 2018-05-17 23:20:59 --> UTF-8 Support Enabled
INFO - 2018-05-17 23:20:59 --> Utf8 Class Initialized
INFO - 2018-05-17 23:20:59 --> URI Class Initialized
INFO - 2018-05-17 23:20:59 --> Router Class Initialized
INFO - 2018-05-17 23:20:59 --> Output Class Initialized
INFO - 2018-05-17 23:20:59 --> Security Class Initialized
DEBUG - 2018-05-17 23:20:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 23:20:59 --> Input Class Initialized
INFO - 2018-05-17 23:20:59 --> Language Class Initialized
ERROR - 2018-05-17 23:20:59 --> 404 Page Not Found: /index
INFO - 2018-05-17 23:20:59 --> Config Class Initialized
INFO - 2018-05-17 23:20:59 --> Hooks Class Initialized
DEBUG - 2018-05-17 23:20:59 --> UTF-8 Support Enabled
INFO - 2018-05-17 23:20:59 --> Utf8 Class Initialized
INFO - 2018-05-17 23:20:59 --> URI Class Initialized
INFO - 2018-05-17 23:20:59 --> Router Class Initialized
INFO - 2018-05-17 23:20:59 --> Output Class Initialized
INFO - 2018-05-17 23:20:59 --> Security Class Initialized
DEBUG - 2018-05-17 23:20:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 23:20:59 --> Input Class Initialized
INFO - 2018-05-17 23:20:59 --> Language Class Initialized
ERROR - 2018-05-17 23:20:59 --> 404 Page Not Found: /index
INFO - 2018-05-17 23:21:10 --> Config Class Initialized
INFO - 2018-05-17 23:21:10 --> Hooks Class Initialized
DEBUG - 2018-05-17 23:21:10 --> UTF-8 Support Enabled
INFO - 2018-05-17 23:21:10 --> Utf8 Class Initialized
INFO - 2018-05-17 23:21:10 --> URI Class Initialized
INFO - 2018-05-17 23:21:10 --> Router Class Initialized
INFO - 2018-05-17 23:21:10 --> Output Class Initialized
INFO - 2018-05-17 23:21:10 --> Security Class Initialized
DEBUG - 2018-05-17 23:21:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 23:21:11 --> Input Class Initialized
INFO - 2018-05-17 23:21:11 --> Language Class Initialized
INFO - 2018-05-17 23:21:11 --> Language Class Initialized
INFO - 2018-05-17 23:21:11 --> Config Class Initialized
INFO - 2018-05-17 23:21:11 --> Loader Class Initialized
DEBUG - 2018-05-17 23:21:11 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-17 23:21:11 --> Helper loaded: url_helper
INFO - 2018-05-17 23:21:11 --> Helper loaded: form_helper
INFO - 2018-05-17 23:21:11 --> Helper loaded: date_helper
INFO - 2018-05-17 23:21:11 --> Helper loaded: util_helper
INFO - 2018-05-17 23:21:11 --> Helper loaded: text_helper
INFO - 2018-05-17 23:21:11 --> Helper loaded: string_helper
INFO - 2018-05-17 23:21:11 --> Database Driver Class Initialized
DEBUG - 2018-05-17 23:21:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-17 23:21:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-17 23:21:11 --> Email Class Initialized
INFO - 2018-05-17 23:21:11 --> Controller Class Initialized
DEBUG - 2018-05-17 23:21:11 --> Home MX_Controller Initialized
DEBUG - 2018-05-17 23:21:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-17 23:21:11 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-17 23:21:11 --> Login MX_Controller Initialized
INFO - 2018-05-17 23:21:11 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-17 23:21:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-17 23:21:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-17 23:21:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-17 23:21:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-17 23:21:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-17 23:21:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-17 23:21:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-17 23:21:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-05-17 23:21:11 --> Final output sent to browser
DEBUG - 2018-05-17 23:21:11 --> Total execution time: 0.7670
INFO - 2018-05-17 23:21:11 --> Config Class Initialized
INFO - 2018-05-17 23:21:11 --> Config Class Initialized
INFO - 2018-05-17 23:21:11 --> Hooks Class Initialized
INFO - 2018-05-17 23:21:11 --> Hooks Class Initialized
DEBUG - 2018-05-17 23:21:11 --> UTF-8 Support Enabled
INFO - 2018-05-17 23:21:11 --> Utf8 Class Initialized
DEBUG - 2018-05-17 23:21:11 --> UTF-8 Support Enabled
INFO - 2018-05-17 23:21:12 --> URI Class Initialized
INFO - 2018-05-17 23:21:12 --> Router Class Initialized
INFO - 2018-05-17 23:21:12 --> Output Class Initialized
INFO - 2018-05-17 23:21:12 --> Security Class Initialized
DEBUG - 2018-05-17 23:21:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 23:21:12 --> Utf8 Class Initialized
INFO - 2018-05-17 23:21:12 --> Input Class Initialized
INFO - 2018-05-17 23:21:12 --> URI Class Initialized
INFO - 2018-05-17 23:21:12 --> Router Class Initialized
INFO - 2018-05-17 23:21:12 --> Language Class Initialized
INFO - 2018-05-17 23:21:12 --> Output Class Initialized
INFO - 2018-05-17 23:21:12 --> Security Class Initialized
ERROR - 2018-05-17 23:21:12 --> 404 Page Not Found: /index
DEBUG - 2018-05-17 23:21:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 23:21:12 --> Input Class Initialized
INFO - 2018-05-17 23:21:12 --> Language Class Initialized
ERROR - 2018-05-17 23:21:12 --> 404 Page Not Found: /index
INFO - 2018-05-17 23:21:12 --> Config Class Initialized
INFO - 2018-05-17 23:21:12 --> Hooks Class Initialized
DEBUG - 2018-05-17 23:21:12 --> UTF-8 Support Enabled
INFO - 2018-05-17 23:21:12 --> Utf8 Class Initialized
INFO - 2018-05-17 23:21:12 --> URI Class Initialized
INFO - 2018-05-17 23:21:12 --> Router Class Initialized
INFO - 2018-05-17 23:21:12 --> Output Class Initialized
INFO - 2018-05-17 23:21:12 --> Security Class Initialized
DEBUG - 2018-05-17 23:21:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 23:21:12 --> Input Class Initialized
INFO - 2018-05-17 23:21:12 --> Language Class Initialized
ERROR - 2018-05-17 23:21:12 --> 404 Page Not Found: /index
INFO - 2018-05-17 23:21:13 --> Config Class Initialized
INFO - 2018-05-17 23:21:13 --> Hooks Class Initialized
DEBUG - 2018-05-17 23:21:13 --> UTF-8 Support Enabled
INFO - 2018-05-17 23:21:13 --> Utf8 Class Initialized
INFO - 2018-05-17 23:21:13 --> URI Class Initialized
INFO - 2018-05-17 23:21:13 --> Router Class Initialized
INFO - 2018-05-17 23:21:13 --> Output Class Initialized
INFO - 2018-05-17 23:21:13 --> Security Class Initialized
DEBUG - 2018-05-17 23:21:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 23:21:13 --> Input Class Initialized
INFO - 2018-05-17 23:21:13 --> Language Class Initialized
ERROR - 2018-05-17 23:21:13 --> 404 Page Not Found: /index
INFO - 2018-05-17 23:21:14 --> Config Class Initialized
INFO - 2018-05-17 23:21:14 --> Hooks Class Initialized
DEBUG - 2018-05-17 23:21:14 --> UTF-8 Support Enabled
INFO - 2018-05-17 23:21:14 --> Utf8 Class Initialized
INFO - 2018-05-17 23:21:14 --> URI Class Initialized
INFO - 2018-05-17 23:21:14 --> Router Class Initialized
INFO - 2018-05-17 23:21:14 --> Output Class Initialized
INFO - 2018-05-17 23:21:14 --> Security Class Initialized
DEBUG - 2018-05-17 23:21:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 23:21:14 --> Input Class Initialized
INFO - 2018-05-17 23:21:14 --> Language Class Initialized
ERROR - 2018-05-17 23:21:14 --> 404 Page Not Found: /index
INFO - 2018-05-17 23:21:14 --> Config Class Initialized
INFO - 2018-05-17 23:21:14 --> Hooks Class Initialized
DEBUG - 2018-05-17 23:21:14 --> UTF-8 Support Enabled
INFO - 2018-05-17 23:21:14 --> Utf8 Class Initialized
INFO - 2018-05-17 23:21:14 --> URI Class Initialized
INFO - 2018-05-17 23:21:14 --> Router Class Initialized
INFO - 2018-05-17 23:21:14 --> Output Class Initialized
INFO - 2018-05-17 23:21:14 --> Security Class Initialized
DEBUG - 2018-05-17 23:21:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 23:21:14 --> Input Class Initialized
INFO - 2018-05-17 23:21:14 --> Language Class Initialized
ERROR - 2018-05-17 23:21:14 --> 404 Page Not Found: /index
INFO - 2018-05-17 23:21:14 --> Config Class Initialized
INFO - 2018-05-17 23:21:15 --> Hooks Class Initialized
DEBUG - 2018-05-17 23:21:15 --> UTF-8 Support Enabled
INFO - 2018-05-17 23:21:15 --> Utf8 Class Initialized
INFO - 2018-05-17 23:21:15 --> URI Class Initialized
INFO - 2018-05-17 23:21:15 --> Router Class Initialized
INFO - 2018-05-17 23:21:15 --> Output Class Initialized
INFO - 2018-05-17 23:21:15 --> Security Class Initialized
DEBUG - 2018-05-17 23:21:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 23:21:15 --> Input Class Initialized
INFO - 2018-05-17 23:21:15 --> Language Class Initialized
ERROR - 2018-05-17 23:21:15 --> 404 Page Not Found: /index
INFO - 2018-05-17 23:21:20 --> Config Class Initialized
INFO - 2018-05-17 23:21:20 --> Hooks Class Initialized
DEBUG - 2018-05-17 23:21:20 --> UTF-8 Support Enabled
INFO - 2018-05-17 23:21:20 --> Utf8 Class Initialized
INFO - 2018-05-17 23:21:20 --> URI Class Initialized
INFO - 2018-05-17 23:21:20 --> Router Class Initialized
INFO - 2018-05-17 23:21:20 --> Output Class Initialized
INFO - 2018-05-17 23:21:20 --> Security Class Initialized
DEBUG - 2018-05-17 23:21:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 23:21:20 --> Input Class Initialized
INFO - 2018-05-17 23:21:20 --> Language Class Initialized
INFO - 2018-05-17 23:21:20 --> Language Class Initialized
INFO - 2018-05-17 23:21:20 --> Config Class Initialized
INFO - 2018-05-17 23:21:20 --> Loader Class Initialized
DEBUG - 2018-05-17 23:21:20 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-17 23:21:20 --> Helper loaded: url_helper
INFO - 2018-05-17 23:21:20 --> Helper loaded: form_helper
INFO - 2018-05-17 23:21:20 --> Helper loaded: date_helper
INFO - 2018-05-17 23:21:20 --> Helper loaded: util_helper
INFO - 2018-05-17 23:21:20 --> Helper loaded: text_helper
INFO - 2018-05-17 23:21:20 --> Helper loaded: string_helper
INFO - 2018-05-17 23:21:20 --> Database Driver Class Initialized
DEBUG - 2018-05-17 23:21:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-17 23:21:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-17 23:21:21 --> Email Class Initialized
INFO - 2018-05-17 23:21:21 --> Controller Class Initialized
DEBUG - 2018-05-17 23:21:21 --> Home MX_Controller Initialized
DEBUG - 2018-05-17 23:21:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-17 23:21:21 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-17 23:21:21 --> Login MX_Controller Initialized
INFO - 2018-05-17 23:21:21 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-17 23:21:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-17 23:21:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-17 23:21:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-17 23:21:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-17 23:21:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-17 23:21:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-17 23:21:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-17 23:21:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-05-17 23:21:21 --> Final output sent to browser
DEBUG - 2018-05-17 23:21:21 --> Total execution time: 0.7971
INFO - 2018-05-17 23:21:21 --> Config Class Initialized
INFO - 2018-05-17 23:21:21 --> Config Class Initialized
INFO - 2018-05-17 23:21:21 --> Hooks Class Initialized
INFO - 2018-05-17 23:21:21 --> Hooks Class Initialized
DEBUG - 2018-05-17 23:21:21 --> UTF-8 Support Enabled
DEBUG - 2018-05-17 23:21:21 --> UTF-8 Support Enabled
INFO - 2018-05-17 23:21:22 --> Utf8 Class Initialized
INFO - 2018-05-17 23:21:22 --> URI Class Initialized
INFO - 2018-05-17 23:21:22 --> Router Class Initialized
INFO - 2018-05-17 23:21:22 --> Output Class Initialized
INFO - 2018-05-17 23:21:22 --> Utf8 Class Initialized
INFO - 2018-05-17 23:21:22 --> Security Class Initialized
INFO - 2018-05-17 23:21:22 --> URI Class Initialized
DEBUG - 2018-05-17 23:21:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 23:21:22 --> Router Class Initialized
INFO - 2018-05-17 23:21:22 --> Input Class Initialized
INFO - 2018-05-17 23:21:22 --> Language Class Initialized
ERROR - 2018-05-17 23:21:22 --> 404 Page Not Found: /index
INFO - 2018-05-17 23:21:22 --> Output Class Initialized
INFO - 2018-05-17 23:21:22 --> Security Class Initialized
DEBUG - 2018-05-17 23:21:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 23:21:22 --> Config Class Initialized
INFO - 2018-05-17 23:21:22 --> Input Class Initialized
INFO - 2018-05-17 23:21:22 --> Hooks Class Initialized
DEBUG - 2018-05-17 23:21:22 --> UTF-8 Support Enabled
INFO - 2018-05-17 23:21:22 --> Language Class Initialized
INFO - 2018-05-17 23:21:22 --> Utf8 Class Initialized
ERROR - 2018-05-17 23:21:22 --> 404 Page Not Found: /index
INFO - 2018-05-17 23:21:22 --> URI Class Initialized
INFO - 2018-05-17 23:21:22 --> Router Class Initialized
INFO - 2018-05-17 23:21:22 --> Output Class Initialized
INFO - 2018-05-17 23:21:22 --> Security Class Initialized
DEBUG - 2018-05-17 23:21:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 23:21:22 --> Input Class Initialized
INFO - 2018-05-17 23:21:22 --> Language Class Initialized
ERROR - 2018-05-17 23:21:22 --> 404 Page Not Found: /index
INFO - 2018-05-17 23:21:23 --> Config Class Initialized
INFO - 2018-05-17 23:21:23 --> Hooks Class Initialized
DEBUG - 2018-05-17 23:21:23 --> UTF-8 Support Enabled
INFO - 2018-05-17 23:21:23 --> Utf8 Class Initialized
INFO - 2018-05-17 23:21:23 --> URI Class Initialized
INFO - 2018-05-17 23:21:23 --> Router Class Initialized
INFO - 2018-05-17 23:21:23 --> Output Class Initialized
INFO - 2018-05-17 23:21:23 --> Security Class Initialized
DEBUG - 2018-05-17 23:21:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 23:21:23 --> Input Class Initialized
INFO - 2018-05-17 23:21:23 --> Language Class Initialized
ERROR - 2018-05-17 23:21:23 --> 404 Page Not Found: /index
INFO - 2018-05-17 23:21:28 --> Config Class Initialized
INFO - 2018-05-17 23:21:28 --> Hooks Class Initialized
DEBUG - 2018-05-17 23:21:28 --> UTF-8 Support Enabled
INFO - 2018-05-17 23:21:28 --> Utf8 Class Initialized
INFO - 2018-05-17 23:21:28 --> URI Class Initialized
INFO - 2018-05-17 23:21:28 --> Router Class Initialized
INFO - 2018-05-17 23:21:28 --> Output Class Initialized
INFO - 2018-05-17 23:21:28 --> Security Class Initialized
DEBUG - 2018-05-17 23:21:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 23:21:28 --> Input Class Initialized
INFO - 2018-05-17 23:21:28 --> Language Class Initialized
INFO - 2018-05-17 23:21:28 --> Language Class Initialized
INFO - 2018-05-17 23:21:28 --> Config Class Initialized
INFO - 2018-05-17 23:21:28 --> Loader Class Initialized
DEBUG - 2018-05-17 23:21:28 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-17 23:21:28 --> Helper loaded: url_helper
INFO - 2018-05-17 23:21:28 --> Helper loaded: form_helper
INFO - 2018-05-17 23:21:28 --> Helper loaded: date_helper
INFO - 2018-05-17 23:21:28 --> Helper loaded: util_helper
INFO - 2018-05-17 23:21:28 --> Helper loaded: text_helper
INFO - 2018-05-17 23:21:28 --> Helper loaded: string_helper
INFO - 2018-05-17 23:21:28 --> Database Driver Class Initialized
DEBUG - 2018-05-17 23:21:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-17 23:21:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-17 23:21:28 --> Email Class Initialized
INFO - 2018-05-17 23:21:28 --> Controller Class Initialized
DEBUG - 2018-05-17 23:21:28 --> Home MX_Controller Initialized
DEBUG - 2018-05-17 23:21:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-17 23:21:28 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-17 23:21:28 --> Login MX_Controller Initialized
INFO - 2018-05-17 23:21:28 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-17 23:21:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-17 23:21:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-17 23:21:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-17 23:21:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-17 23:21:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-17 23:21:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-17 23:21:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-17 23:21:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-05-17 23:21:29 --> Final output sent to browser
DEBUG - 2018-05-17 23:21:29 --> Total execution time: 0.8102
INFO - 2018-05-17 23:21:29 --> Config Class Initialized
INFO - 2018-05-17 23:21:29 --> Config Class Initialized
INFO - 2018-05-17 23:21:29 --> Hooks Class Initialized
INFO - 2018-05-17 23:21:29 --> Hooks Class Initialized
DEBUG - 2018-05-17 23:21:29 --> UTF-8 Support Enabled
INFO - 2018-05-17 23:21:29 --> Utf8 Class Initialized
INFO - 2018-05-17 23:21:29 --> URI Class Initialized
INFO - 2018-05-17 23:21:29 --> Router Class Initialized
INFO - 2018-05-17 23:21:29 --> Output Class Initialized
INFO - 2018-05-17 23:21:29 --> Security Class Initialized
DEBUG - 2018-05-17 23:21:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-17 23:21:29 --> UTF-8 Support Enabled
INFO - 2018-05-17 23:21:29 --> Input Class Initialized
INFO - 2018-05-17 23:21:29 --> Utf8 Class Initialized
INFO - 2018-05-17 23:21:29 --> Language Class Initialized
ERROR - 2018-05-17 23:21:29 --> 404 Page Not Found: /index
INFO - 2018-05-17 23:21:29 --> URI Class Initialized
INFO - 2018-05-17 23:21:29 --> Router Class Initialized
INFO - 2018-05-17 23:21:29 --> Config Class Initialized
INFO - 2018-05-17 23:21:29 --> Hooks Class Initialized
INFO - 2018-05-17 23:21:29 --> Output Class Initialized
DEBUG - 2018-05-17 23:21:29 --> UTF-8 Support Enabled
INFO - 2018-05-17 23:21:29 --> Security Class Initialized
INFO - 2018-05-17 23:21:29 --> Utf8 Class Initialized
DEBUG - 2018-05-17 23:21:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 23:21:29 --> Input Class Initialized
INFO - 2018-05-17 23:21:29 --> URI Class Initialized
INFO - 2018-05-17 23:21:29 --> Language Class Initialized
INFO - 2018-05-17 23:21:29 --> Router Class Initialized
INFO - 2018-05-17 23:21:29 --> Output Class Initialized
ERROR - 2018-05-17 23:21:29 --> 404 Page Not Found: /index
INFO - 2018-05-17 23:21:30 --> Security Class Initialized
DEBUG - 2018-05-17 23:21:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 23:21:30 --> Input Class Initialized
INFO - 2018-05-17 23:21:30 --> Language Class Initialized
ERROR - 2018-05-17 23:21:30 --> 404 Page Not Found: /index
INFO - 2018-05-17 23:21:30 --> Config Class Initialized
INFO - 2018-05-17 23:21:30 --> Hooks Class Initialized
DEBUG - 2018-05-17 23:21:30 --> UTF-8 Support Enabled
INFO - 2018-05-17 23:21:30 --> Utf8 Class Initialized
INFO - 2018-05-17 23:21:30 --> URI Class Initialized
INFO - 2018-05-17 23:21:30 --> Router Class Initialized
INFO - 2018-05-17 23:21:30 --> Output Class Initialized
INFO - 2018-05-17 23:21:30 --> Security Class Initialized
DEBUG - 2018-05-17 23:21:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 23:21:30 --> Input Class Initialized
INFO - 2018-05-17 23:21:30 --> Language Class Initialized
ERROR - 2018-05-17 23:21:30 --> 404 Page Not Found: /index
INFO - 2018-05-17 23:21:30 --> Config Class Initialized
INFO - 2018-05-17 23:21:30 --> Hooks Class Initialized
DEBUG - 2018-05-17 23:21:30 --> UTF-8 Support Enabled
INFO - 2018-05-17 23:21:30 --> Utf8 Class Initialized
INFO - 2018-05-17 23:21:30 --> URI Class Initialized
INFO - 2018-05-17 23:21:30 --> Router Class Initialized
INFO - 2018-05-17 23:21:30 --> Output Class Initialized
INFO - 2018-05-17 23:21:30 --> Security Class Initialized
DEBUG - 2018-05-17 23:21:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 23:21:30 --> Input Class Initialized
INFO - 2018-05-17 23:21:30 --> Language Class Initialized
ERROR - 2018-05-17 23:21:30 --> 404 Page Not Found: /index
INFO - 2018-05-17 23:21:31 --> Config Class Initialized
INFO - 2018-05-17 23:21:31 --> Hooks Class Initialized
DEBUG - 2018-05-17 23:21:31 --> UTF-8 Support Enabled
INFO - 2018-05-17 23:21:31 --> Utf8 Class Initialized
INFO - 2018-05-17 23:21:31 --> URI Class Initialized
INFO - 2018-05-17 23:21:31 --> Router Class Initialized
INFO - 2018-05-17 23:21:31 --> Output Class Initialized
INFO - 2018-05-17 23:21:31 --> Security Class Initialized
DEBUG - 2018-05-17 23:21:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 23:21:31 --> Input Class Initialized
INFO - 2018-05-17 23:21:31 --> Language Class Initialized
ERROR - 2018-05-17 23:21:31 --> 404 Page Not Found: /index
INFO - 2018-05-17 23:21:31 --> Config Class Initialized
INFO - 2018-05-17 23:21:31 --> Hooks Class Initialized
DEBUG - 2018-05-17 23:21:31 --> UTF-8 Support Enabled
INFO - 2018-05-17 23:21:31 --> Utf8 Class Initialized
INFO - 2018-05-17 23:21:31 --> URI Class Initialized
INFO - 2018-05-17 23:21:31 --> Router Class Initialized
INFO - 2018-05-17 23:21:31 --> Output Class Initialized
INFO - 2018-05-17 23:21:31 --> Security Class Initialized
DEBUG - 2018-05-17 23:21:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 23:21:31 --> Input Class Initialized
INFO - 2018-05-17 23:21:31 --> Language Class Initialized
ERROR - 2018-05-17 23:21:31 --> 404 Page Not Found: /index
INFO - 2018-05-17 23:21:41 --> Config Class Initialized
INFO - 2018-05-17 23:21:41 --> Hooks Class Initialized
DEBUG - 2018-05-17 23:21:41 --> UTF-8 Support Enabled
INFO - 2018-05-17 23:21:41 --> Utf8 Class Initialized
INFO - 2018-05-17 23:21:41 --> URI Class Initialized
INFO - 2018-05-17 23:21:41 --> Router Class Initialized
INFO - 2018-05-17 23:21:41 --> Output Class Initialized
INFO - 2018-05-17 23:21:41 --> Security Class Initialized
DEBUG - 2018-05-17 23:21:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 23:21:41 --> Input Class Initialized
INFO - 2018-05-17 23:21:41 --> Language Class Initialized
INFO - 2018-05-17 23:21:41 --> Language Class Initialized
INFO - 2018-05-17 23:21:41 --> Config Class Initialized
INFO - 2018-05-17 23:21:41 --> Loader Class Initialized
DEBUG - 2018-05-17 23:21:41 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-17 23:21:41 --> Helper loaded: url_helper
INFO - 2018-05-17 23:21:41 --> Helper loaded: form_helper
INFO - 2018-05-17 23:21:41 --> Helper loaded: date_helper
INFO - 2018-05-17 23:21:41 --> Helper loaded: util_helper
INFO - 2018-05-17 23:21:41 --> Helper loaded: text_helper
INFO - 2018-05-17 23:21:41 --> Helper loaded: string_helper
INFO - 2018-05-17 23:21:41 --> Database Driver Class Initialized
DEBUG - 2018-05-17 23:21:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-17 23:21:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-17 23:21:42 --> Email Class Initialized
INFO - 2018-05-17 23:21:42 --> Controller Class Initialized
DEBUG - 2018-05-17 23:21:42 --> Home MX_Controller Initialized
DEBUG - 2018-05-17 23:21:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-17 23:21:42 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-17 23:21:42 --> Login MX_Controller Initialized
INFO - 2018-05-17 23:21:42 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-17 23:21:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-17 23:21:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-17 23:21:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-17 23:21:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-17 23:21:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-17 23:21:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-17 23:21:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-17 23:21:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-05-17 23:21:42 --> Final output sent to browser
DEBUG - 2018-05-17 23:21:42 --> Total execution time: 0.8097
INFO - 2018-05-17 23:21:42 --> Config Class Initialized
INFO - 2018-05-17 23:21:42 --> Hooks Class Initialized
INFO - 2018-05-17 23:21:42 --> Config Class Initialized
INFO - 2018-05-17 23:21:42 --> Hooks Class Initialized
DEBUG - 2018-05-17 23:21:42 --> UTF-8 Support Enabled
DEBUG - 2018-05-17 23:21:42 --> UTF-8 Support Enabled
INFO - 2018-05-17 23:21:42 --> Utf8 Class Initialized
INFO - 2018-05-17 23:21:42 --> Utf8 Class Initialized
INFO - 2018-05-17 23:21:42 --> URI Class Initialized
INFO - 2018-05-17 23:21:42 --> URI Class Initialized
INFO - 2018-05-17 23:21:42 --> Router Class Initialized
INFO - 2018-05-17 23:21:42 --> Router Class Initialized
INFO - 2018-05-17 23:21:42 --> Output Class Initialized
INFO - 2018-05-17 23:21:42 --> Output Class Initialized
INFO - 2018-05-17 23:21:42 --> Security Class Initialized
DEBUG - 2018-05-17 23:21:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 23:21:43 --> Input Class Initialized
INFO - 2018-05-17 23:21:43 --> Language Class Initialized
ERROR - 2018-05-17 23:21:43 --> 404 Page Not Found: /index
INFO - 2018-05-17 23:21:43 --> Security Class Initialized
DEBUG - 2018-05-17 23:21:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 23:21:43 --> Config Class Initialized
INFO - 2018-05-17 23:21:43 --> Hooks Class Initialized
INFO - 2018-05-17 23:21:43 --> Input Class Initialized
DEBUG - 2018-05-17 23:21:43 --> UTF-8 Support Enabled
INFO - 2018-05-17 23:21:43 --> Utf8 Class Initialized
INFO - 2018-05-17 23:21:43 --> Language Class Initialized
INFO - 2018-05-17 23:21:43 --> URI Class Initialized
INFO - 2018-05-17 23:21:43 --> Router Class Initialized
ERROR - 2018-05-17 23:21:43 --> 404 Page Not Found: /index
INFO - 2018-05-17 23:21:43 --> Output Class Initialized
INFO - 2018-05-17 23:21:43 --> Security Class Initialized
DEBUG - 2018-05-17 23:21:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 23:21:43 --> Input Class Initialized
INFO - 2018-05-17 23:21:43 --> Language Class Initialized
ERROR - 2018-05-17 23:21:43 --> 404 Page Not Found: /index
INFO - 2018-05-17 23:21:43 --> Config Class Initialized
INFO - 2018-05-17 23:21:43 --> Hooks Class Initialized
DEBUG - 2018-05-17 23:21:43 --> UTF-8 Support Enabled
INFO - 2018-05-17 23:21:43 --> Utf8 Class Initialized
INFO - 2018-05-17 23:21:43 --> URI Class Initialized
INFO - 2018-05-17 23:21:43 --> Router Class Initialized
INFO - 2018-05-17 23:21:44 --> Output Class Initialized
INFO - 2018-05-17 23:21:44 --> Security Class Initialized
DEBUG - 2018-05-17 23:21:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 23:21:44 --> Input Class Initialized
INFO - 2018-05-17 23:21:44 --> Language Class Initialized
ERROR - 2018-05-17 23:21:44 --> 404 Page Not Found: /index
INFO - 2018-05-17 23:21:45 --> Config Class Initialized
INFO - 2018-05-17 23:21:45 --> Hooks Class Initialized
DEBUG - 2018-05-17 23:21:45 --> UTF-8 Support Enabled
INFO - 2018-05-17 23:21:45 --> Utf8 Class Initialized
INFO - 2018-05-17 23:21:45 --> URI Class Initialized
INFO - 2018-05-17 23:21:45 --> Router Class Initialized
INFO - 2018-05-17 23:21:45 --> Output Class Initialized
INFO - 2018-05-17 23:21:45 --> Security Class Initialized
DEBUG - 2018-05-17 23:21:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 23:21:45 --> Input Class Initialized
INFO - 2018-05-17 23:21:45 --> Language Class Initialized
ERROR - 2018-05-17 23:21:45 --> 404 Page Not Found: /index
INFO - 2018-05-17 23:21:45 --> Config Class Initialized
INFO - 2018-05-17 23:21:45 --> Hooks Class Initialized
DEBUG - 2018-05-17 23:21:45 --> UTF-8 Support Enabled
INFO - 2018-05-17 23:21:45 --> Utf8 Class Initialized
INFO - 2018-05-17 23:21:45 --> URI Class Initialized
INFO - 2018-05-17 23:21:45 --> Router Class Initialized
INFO - 2018-05-17 23:21:45 --> Output Class Initialized
INFO - 2018-05-17 23:21:45 --> Security Class Initialized
DEBUG - 2018-05-17 23:21:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 23:21:45 --> Input Class Initialized
INFO - 2018-05-17 23:21:45 --> Language Class Initialized
ERROR - 2018-05-17 23:21:45 --> 404 Page Not Found: /index
INFO - 2018-05-17 23:21:45 --> Config Class Initialized
INFO - 2018-05-17 23:21:45 --> Hooks Class Initialized
DEBUG - 2018-05-17 23:21:45 --> UTF-8 Support Enabled
INFO - 2018-05-17 23:21:45 --> Utf8 Class Initialized
INFO - 2018-05-17 23:21:45 --> URI Class Initialized
INFO - 2018-05-17 23:21:45 --> Router Class Initialized
INFO - 2018-05-17 23:21:45 --> Output Class Initialized
INFO - 2018-05-17 23:21:45 --> Security Class Initialized
DEBUG - 2018-05-17 23:21:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 23:21:45 --> Input Class Initialized
INFO - 2018-05-17 23:21:46 --> Language Class Initialized
ERROR - 2018-05-17 23:21:46 --> 404 Page Not Found: /index
INFO - 2018-05-17 23:40:00 --> Config Class Initialized
INFO - 2018-05-17 23:40:00 --> Hooks Class Initialized
DEBUG - 2018-05-17 23:40:00 --> UTF-8 Support Enabled
INFO - 2018-05-17 23:40:00 --> Utf8 Class Initialized
INFO - 2018-05-17 23:40:00 --> URI Class Initialized
INFO - 2018-05-17 23:40:00 --> Router Class Initialized
INFO - 2018-05-17 23:40:00 --> Output Class Initialized
INFO - 2018-05-17 23:40:00 --> Security Class Initialized
DEBUG - 2018-05-17 23:40:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 23:40:00 --> Input Class Initialized
INFO - 2018-05-17 23:40:00 --> Language Class Initialized
INFO - 2018-05-17 23:40:00 --> Language Class Initialized
INFO - 2018-05-17 23:40:00 --> Config Class Initialized
INFO - 2018-05-17 23:40:00 --> Loader Class Initialized
DEBUG - 2018-05-17 23:40:00 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-17 23:40:00 --> Helper loaded: url_helper
INFO - 2018-05-17 23:40:00 --> Helper loaded: form_helper
INFO - 2018-05-17 23:40:00 --> Helper loaded: date_helper
INFO - 2018-05-17 23:40:00 --> Helper loaded: util_helper
INFO - 2018-05-17 23:40:00 --> Helper loaded: text_helper
INFO - 2018-05-17 23:40:00 --> Helper loaded: string_helper
INFO - 2018-05-17 23:40:00 --> Database Driver Class Initialized
DEBUG - 2018-05-17 23:40:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-17 23:40:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-17 23:40:00 --> Email Class Initialized
INFO - 2018-05-17 23:40:00 --> Controller Class Initialized
DEBUG - 2018-05-17 23:40:00 --> Home MX_Controller Initialized
DEBUG - 2018-05-17 23:40:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-17 23:40:00 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-17 23:40:00 --> Login MX_Controller Initialized
INFO - 2018-05-17 23:40:00 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-17 23:40:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-17 23:40:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-17 23:40:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-17 23:40:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-17 23:40:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-17 23:40:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-17 23:40:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-17 23:40:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-05-17 23:40:01 --> Final output sent to browser
DEBUG - 2018-05-17 23:40:01 --> Total execution time: 0.7928
INFO - 2018-05-17 23:40:01 --> Config Class Initialized
INFO - 2018-05-17 23:40:01 --> Hooks Class Initialized
INFO - 2018-05-17 23:40:01 --> Config Class Initialized
INFO - 2018-05-17 23:40:01 --> Hooks Class Initialized
DEBUG - 2018-05-17 23:40:01 --> UTF-8 Support Enabled
INFO - 2018-05-17 23:40:01 --> Utf8 Class Initialized
DEBUG - 2018-05-17 23:40:01 --> UTF-8 Support Enabled
INFO - 2018-05-17 23:40:01 --> URI Class Initialized
INFO - 2018-05-17 23:40:01 --> Utf8 Class Initialized
INFO - 2018-05-17 23:40:01 --> Router Class Initialized
INFO - 2018-05-17 23:40:01 --> URI Class Initialized
INFO - 2018-05-17 23:40:01 --> Output Class Initialized
INFO - 2018-05-17 23:40:01 --> Router Class Initialized
INFO - 2018-05-17 23:40:01 --> Output Class Initialized
INFO - 2018-05-17 23:40:01 --> Security Class Initialized
INFO - 2018-05-17 23:40:01 --> Security Class Initialized
DEBUG - 2018-05-17 23:40:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-17 23:40:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 23:40:01 --> Input Class Initialized
INFO - 2018-05-17 23:40:01 --> Input Class Initialized
INFO - 2018-05-17 23:40:02 --> Language Class Initialized
INFO - 2018-05-17 23:40:02 --> Language Class Initialized
ERROR - 2018-05-17 23:40:02 --> 404 Page Not Found: /index
ERROR - 2018-05-17 23:40:02 --> 404 Page Not Found: /index
INFO - 2018-05-17 23:40:02 --> Config Class Initialized
INFO - 2018-05-17 23:40:02 --> Hooks Class Initialized
DEBUG - 2018-05-17 23:40:02 --> UTF-8 Support Enabled
INFO - 2018-05-17 23:40:02 --> Utf8 Class Initialized
INFO - 2018-05-17 23:40:02 --> URI Class Initialized
INFO - 2018-05-17 23:40:02 --> Router Class Initialized
INFO - 2018-05-17 23:40:02 --> Output Class Initialized
INFO - 2018-05-17 23:40:02 --> Security Class Initialized
DEBUG - 2018-05-17 23:40:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 23:40:02 --> Input Class Initialized
INFO - 2018-05-17 23:40:02 --> Language Class Initialized
ERROR - 2018-05-17 23:40:02 --> 404 Page Not Found: /index
INFO - 2018-05-17 23:40:02 --> Config Class Initialized
INFO - 2018-05-17 23:40:02 --> Hooks Class Initialized
DEBUG - 2018-05-17 23:40:02 --> UTF-8 Support Enabled
INFO - 2018-05-17 23:40:02 --> Utf8 Class Initialized
INFO - 2018-05-17 23:40:02 --> URI Class Initialized
INFO - 2018-05-17 23:40:02 --> Router Class Initialized
INFO - 2018-05-17 23:40:02 --> Output Class Initialized
INFO - 2018-05-17 23:40:02 --> Security Class Initialized
DEBUG - 2018-05-17 23:40:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 23:40:02 --> Input Class Initialized
INFO - 2018-05-17 23:40:02 --> Language Class Initialized
ERROR - 2018-05-17 23:40:02 --> 404 Page Not Found: /index
INFO - 2018-05-17 23:40:04 --> Config Class Initialized
INFO - 2018-05-17 23:40:04 --> Hooks Class Initialized
DEBUG - 2018-05-17 23:40:04 --> UTF-8 Support Enabled
INFO - 2018-05-17 23:40:04 --> Utf8 Class Initialized
INFO - 2018-05-17 23:40:04 --> URI Class Initialized
INFO - 2018-05-17 23:40:04 --> Router Class Initialized
INFO - 2018-05-17 23:40:04 --> Output Class Initialized
INFO - 2018-05-17 23:40:04 --> Security Class Initialized
DEBUG - 2018-05-17 23:40:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 23:40:04 --> Input Class Initialized
INFO - 2018-05-17 23:40:04 --> Language Class Initialized
ERROR - 2018-05-17 23:40:04 --> 404 Page Not Found: /index
INFO - 2018-05-17 23:40:04 --> Config Class Initialized
INFO - 2018-05-17 23:40:04 --> Hooks Class Initialized
DEBUG - 2018-05-17 23:40:05 --> UTF-8 Support Enabled
INFO - 2018-05-17 23:40:05 --> Utf8 Class Initialized
INFO - 2018-05-17 23:40:05 --> URI Class Initialized
INFO - 2018-05-17 23:40:05 --> Router Class Initialized
INFO - 2018-05-17 23:40:05 --> Output Class Initialized
INFO - 2018-05-17 23:40:05 --> Security Class Initialized
DEBUG - 2018-05-17 23:40:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 23:40:05 --> Input Class Initialized
INFO - 2018-05-17 23:40:05 --> Language Class Initialized
ERROR - 2018-05-17 23:40:05 --> 404 Page Not Found: /index
INFO - 2018-05-17 23:40:05 --> Config Class Initialized
INFO - 2018-05-17 23:40:05 --> Hooks Class Initialized
DEBUG - 2018-05-17 23:40:05 --> UTF-8 Support Enabled
INFO - 2018-05-17 23:40:05 --> Utf8 Class Initialized
INFO - 2018-05-17 23:40:05 --> URI Class Initialized
INFO - 2018-05-17 23:40:05 --> Router Class Initialized
INFO - 2018-05-17 23:40:05 --> Output Class Initialized
INFO - 2018-05-17 23:40:05 --> Security Class Initialized
DEBUG - 2018-05-17 23:40:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 23:40:05 --> Input Class Initialized
INFO - 2018-05-17 23:40:05 --> Language Class Initialized
ERROR - 2018-05-17 23:40:05 --> 404 Page Not Found: /index
INFO - 2018-05-17 23:44:31 --> Config Class Initialized
INFO - 2018-05-17 23:44:31 --> Hooks Class Initialized
DEBUG - 2018-05-17 23:44:31 --> UTF-8 Support Enabled
INFO - 2018-05-17 23:44:31 --> Utf8 Class Initialized
INFO - 2018-05-17 23:44:32 --> URI Class Initialized
INFO - 2018-05-17 23:44:32 --> Router Class Initialized
INFO - 2018-05-17 23:44:32 --> Output Class Initialized
INFO - 2018-05-17 23:44:32 --> Security Class Initialized
DEBUG - 2018-05-17 23:44:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 23:44:32 --> Input Class Initialized
INFO - 2018-05-17 23:44:32 --> Language Class Initialized
INFO - 2018-05-17 23:44:32 --> Language Class Initialized
INFO - 2018-05-17 23:44:32 --> Config Class Initialized
INFO - 2018-05-17 23:44:32 --> Loader Class Initialized
DEBUG - 2018-05-17 23:44:32 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-17 23:44:32 --> Helper loaded: url_helper
INFO - 2018-05-17 23:44:32 --> Helper loaded: form_helper
INFO - 2018-05-17 23:44:32 --> Helper loaded: date_helper
INFO - 2018-05-17 23:44:32 --> Helper loaded: util_helper
INFO - 2018-05-17 23:44:32 --> Helper loaded: text_helper
INFO - 2018-05-17 23:44:32 --> Helper loaded: string_helper
INFO - 2018-05-17 23:44:32 --> Database Driver Class Initialized
DEBUG - 2018-05-17 23:44:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-17 23:44:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-17 23:44:32 --> Email Class Initialized
INFO - 2018-05-17 23:44:32 --> Controller Class Initialized
DEBUG - 2018-05-17 23:44:32 --> Home MX_Controller Initialized
DEBUG - 2018-05-17 23:44:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-17 23:44:32 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-17 23:44:32 --> Login MX_Controller Initialized
INFO - 2018-05-17 23:44:32 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-17 23:44:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-17 23:44:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-17 23:44:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-17 23:44:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-17 23:44:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-17 23:44:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-17 23:44:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-17 23:44:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-05-17 23:44:32 --> Final output sent to browser
DEBUG - 2018-05-17 23:44:32 --> Total execution time: 0.8237
INFO - 2018-05-17 23:44:33 --> Config Class Initialized
INFO - 2018-05-17 23:44:33 --> Config Class Initialized
INFO - 2018-05-17 23:44:33 --> Hooks Class Initialized
INFO - 2018-05-17 23:44:33 --> Hooks Class Initialized
DEBUG - 2018-05-17 23:44:33 --> UTF-8 Support Enabled
INFO - 2018-05-17 23:44:33 --> Utf8 Class Initialized
INFO - 2018-05-17 23:44:33 --> URI Class Initialized
INFO - 2018-05-17 23:44:33 --> Router Class Initialized
INFO - 2018-05-17 23:44:33 --> Output Class Initialized
INFO - 2018-05-17 23:44:33 --> Security Class Initialized
DEBUG - 2018-05-17 23:44:33 --> UTF-8 Support Enabled
DEBUG - 2018-05-17 23:44:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 23:44:33 --> Utf8 Class Initialized
INFO - 2018-05-17 23:44:33 --> Input Class Initialized
INFO - 2018-05-17 23:44:33 --> URI Class Initialized
INFO - 2018-05-17 23:44:33 --> Router Class Initialized
INFO - 2018-05-17 23:44:33 --> Language Class Initialized
INFO - 2018-05-17 23:44:33 --> Output Class Initialized
INFO - 2018-05-17 23:44:33 --> Security Class Initialized
ERROR - 2018-05-17 23:44:33 --> 404 Page Not Found: /index
DEBUG - 2018-05-17 23:44:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 23:44:33 --> Input Class Initialized
INFO - 2018-05-17 23:44:33 --> Language Class Initialized
ERROR - 2018-05-17 23:44:33 --> 404 Page Not Found: /index
INFO - 2018-05-17 23:44:33 --> Config Class Initialized
INFO - 2018-05-17 23:44:33 --> Hooks Class Initialized
DEBUG - 2018-05-17 23:44:33 --> UTF-8 Support Enabled
INFO - 2018-05-17 23:44:33 --> Utf8 Class Initialized
INFO - 2018-05-17 23:44:33 --> URI Class Initialized
INFO - 2018-05-17 23:44:34 --> Router Class Initialized
INFO - 2018-05-17 23:44:34 --> Output Class Initialized
INFO - 2018-05-17 23:44:34 --> Security Class Initialized
DEBUG - 2018-05-17 23:44:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 23:44:34 --> Input Class Initialized
INFO - 2018-05-17 23:44:34 --> Language Class Initialized
ERROR - 2018-05-17 23:44:34 --> 404 Page Not Found: /index
INFO - 2018-05-17 23:44:34 --> Config Class Initialized
INFO - 2018-05-17 23:44:34 --> Hooks Class Initialized
DEBUG - 2018-05-17 23:44:34 --> UTF-8 Support Enabled
INFO - 2018-05-17 23:44:34 --> Utf8 Class Initialized
INFO - 2018-05-17 23:44:34 --> URI Class Initialized
INFO - 2018-05-17 23:44:34 --> Router Class Initialized
INFO - 2018-05-17 23:44:34 --> Output Class Initialized
INFO - 2018-05-17 23:44:34 --> Security Class Initialized
DEBUG - 2018-05-17 23:44:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 23:44:34 --> Input Class Initialized
INFO - 2018-05-17 23:44:34 --> Language Class Initialized
ERROR - 2018-05-17 23:44:34 --> 404 Page Not Found: /index
INFO - 2018-05-17 23:44:36 --> Config Class Initialized
INFO - 2018-05-17 23:44:36 --> Hooks Class Initialized
DEBUG - 2018-05-17 23:44:36 --> UTF-8 Support Enabled
INFO - 2018-05-17 23:44:36 --> Utf8 Class Initialized
INFO - 2018-05-17 23:44:36 --> URI Class Initialized
INFO - 2018-05-17 23:44:36 --> Router Class Initialized
INFO - 2018-05-17 23:44:36 --> Output Class Initialized
INFO - 2018-05-17 23:44:36 --> Security Class Initialized
DEBUG - 2018-05-17 23:44:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 23:44:36 --> Input Class Initialized
INFO - 2018-05-17 23:44:36 --> Language Class Initialized
INFO - 2018-05-17 23:44:36 --> Language Class Initialized
INFO - 2018-05-17 23:44:36 --> Config Class Initialized
INFO - 2018-05-17 23:44:36 --> Loader Class Initialized
DEBUG - 2018-05-17 23:44:36 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-17 23:44:36 --> Helper loaded: url_helper
INFO - 2018-05-17 23:44:37 --> Helper loaded: form_helper
INFO - 2018-05-17 23:44:37 --> Helper loaded: date_helper
INFO - 2018-05-17 23:44:37 --> Helper loaded: util_helper
INFO - 2018-05-17 23:44:37 --> Helper loaded: text_helper
INFO - 2018-05-17 23:44:37 --> Helper loaded: string_helper
INFO - 2018-05-17 23:44:37 --> Database Driver Class Initialized
DEBUG - 2018-05-17 23:44:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-17 23:44:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-17 23:44:37 --> Email Class Initialized
INFO - 2018-05-17 23:44:37 --> Controller Class Initialized
DEBUG - 2018-05-17 23:44:37 --> Home MX_Controller Initialized
DEBUG - 2018-05-17 23:44:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-17 23:44:37 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-17 23:44:37 --> Login MX_Controller Initialized
INFO - 2018-05-17 23:44:37 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-17 23:44:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-17 23:44:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-17 23:44:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-17 23:44:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-17 23:44:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-17 23:44:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-17 23:44:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-17 23:44:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-05-17 23:44:37 --> Final output sent to browser
DEBUG - 2018-05-17 23:44:37 --> Total execution time: 0.9197
INFO - 2018-05-17 23:44:37 --> Config Class Initialized
INFO - 2018-05-17 23:44:37 --> Hooks Class Initialized
DEBUG - 2018-05-17 23:44:37 --> UTF-8 Support Enabled
INFO - 2018-05-17 23:44:37 --> Utf8 Class Initialized
INFO - 2018-05-17 23:44:38 --> URI Class Initialized
INFO - 2018-05-17 23:44:38 --> Router Class Initialized
INFO - 2018-05-17 23:44:38 --> Output Class Initialized
INFO - 2018-05-17 23:44:38 --> Security Class Initialized
DEBUG - 2018-05-17 23:44:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 23:44:38 --> Input Class Initialized
INFO - 2018-05-17 23:44:38 --> Language Class Initialized
ERROR - 2018-05-17 23:44:38 --> 404 Page Not Found: /index
INFO - 2018-05-17 23:44:38 --> Config Class Initialized
INFO - 2018-05-17 23:44:38 --> Hooks Class Initialized
DEBUG - 2018-05-17 23:44:38 --> UTF-8 Support Enabled
INFO - 2018-05-17 23:44:38 --> Utf8 Class Initialized
INFO - 2018-05-17 23:44:38 --> URI Class Initialized
INFO - 2018-05-17 23:44:38 --> Router Class Initialized
INFO - 2018-05-17 23:44:38 --> Output Class Initialized
INFO - 2018-05-17 23:44:38 --> Security Class Initialized
DEBUG - 2018-05-17 23:44:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 23:44:38 --> Input Class Initialized
INFO - 2018-05-17 23:44:38 --> Language Class Initialized
ERROR - 2018-05-17 23:44:38 --> 404 Page Not Found: /index
INFO - 2018-05-17 23:44:38 --> Config Class Initialized
INFO - 2018-05-17 23:44:38 --> Hooks Class Initialized
DEBUG - 2018-05-17 23:44:38 --> UTF-8 Support Enabled
INFO - 2018-05-17 23:44:38 --> Utf8 Class Initialized
INFO - 2018-05-17 23:44:38 --> URI Class Initialized
INFO - 2018-05-17 23:44:38 --> Router Class Initialized
INFO - 2018-05-17 23:44:38 --> Output Class Initialized
INFO - 2018-05-17 23:44:38 --> Security Class Initialized
DEBUG - 2018-05-17 23:44:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 23:44:38 --> Input Class Initialized
INFO - 2018-05-17 23:44:38 --> Language Class Initialized
ERROR - 2018-05-17 23:44:38 --> 404 Page Not Found: /index
INFO - 2018-05-17 23:44:42 --> Config Class Initialized
INFO - 2018-05-17 23:44:42 --> Hooks Class Initialized
DEBUG - 2018-05-17 23:44:42 --> UTF-8 Support Enabled
INFO - 2018-05-17 23:44:42 --> Utf8 Class Initialized
INFO - 2018-05-17 23:44:42 --> URI Class Initialized
INFO - 2018-05-17 23:44:42 --> Router Class Initialized
INFO - 2018-05-17 23:44:42 --> Output Class Initialized
INFO - 2018-05-17 23:44:42 --> Security Class Initialized
DEBUG - 2018-05-17 23:44:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 23:44:42 --> Input Class Initialized
INFO - 2018-05-17 23:44:42 --> Language Class Initialized
INFO - 2018-05-17 23:44:42 --> Language Class Initialized
INFO - 2018-05-17 23:44:42 --> Config Class Initialized
INFO - 2018-05-17 23:44:42 --> Loader Class Initialized
DEBUG - 2018-05-17 23:44:42 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-17 23:44:42 --> Helper loaded: url_helper
INFO - 2018-05-17 23:44:42 --> Helper loaded: form_helper
INFO - 2018-05-17 23:44:42 --> Helper loaded: date_helper
INFO - 2018-05-17 23:44:42 --> Helper loaded: util_helper
INFO - 2018-05-17 23:44:42 --> Helper loaded: text_helper
INFO - 2018-05-17 23:44:42 --> Helper loaded: string_helper
INFO - 2018-05-17 23:44:42 --> Database Driver Class Initialized
DEBUG - 2018-05-17 23:44:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-17 23:44:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-17 23:44:42 --> Email Class Initialized
INFO - 2018-05-17 23:44:42 --> Controller Class Initialized
DEBUG - 2018-05-17 23:44:42 --> Home MX_Controller Initialized
DEBUG - 2018-05-17 23:44:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-17 23:44:42 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-17 23:44:42 --> Login MX_Controller Initialized
INFO - 2018-05-17 23:44:42 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-17 23:44:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-17 23:44:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-17 23:44:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-17 23:44:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-17 23:44:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-17 23:44:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-17 23:44:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-17 23:44:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-05-17 23:44:43 --> Final output sent to browser
DEBUG - 2018-05-17 23:44:43 --> Total execution time: 0.8818
INFO - 2018-05-17 23:44:43 --> Config Class Initialized
INFO - 2018-05-17 23:44:43 --> Config Class Initialized
INFO - 2018-05-17 23:44:43 --> Hooks Class Initialized
DEBUG - 2018-05-17 23:44:43 --> UTF-8 Support Enabled
INFO - 2018-05-17 23:44:43 --> Utf8 Class Initialized
INFO - 2018-05-17 23:44:43 --> URI Class Initialized
INFO - 2018-05-17 23:44:43 --> Router Class Initialized
INFO - 2018-05-17 23:44:43 --> Output Class Initialized
INFO - 2018-05-17 23:44:43 --> Hooks Class Initialized
INFO - 2018-05-17 23:44:43 --> Security Class Initialized
DEBUG - 2018-05-17 23:44:43 --> UTF-8 Support Enabled
INFO - 2018-05-17 23:44:43 --> Utf8 Class Initialized
DEBUG - 2018-05-17 23:44:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 23:44:43 --> URI Class Initialized
INFO - 2018-05-17 23:44:43 --> Input Class Initialized
INFO - 2018-05-17 23:44:43 --> Router Class Initialized
INFO - 2018-05-17 23:44:43 --> Language Class Initialized
ERROR - 2018-05-17 23:44:44 --> 404 Page Not Found: /index
INFO - 2018-05-17 23:44:44 --> Output Class Initialized
INFO - 2018-05-17 23:44:44 --> Security Class Initialized
DEBUG - 2018-05-17 23:44:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 23:44:44 --> Input Class Initialized
INFO - 2018-05-17 23:44:44 --> Language Class Initialized
ERROR - 2018-05-17 23:44:44 --> 404 Page Not Found: /index
INFO - 2018-05-17 23:44:44 --> Config Class Initialized
INFO - 2018-05-17 23:44:44 --> Hooks Class Initialized
DEBUG - 2018-05-17 23:44:44 --> UTF-8 Support Enabled
INFO - 2018-05-17 23:44:44 --> Utf8 Class Initialized
INFO - 2018-05-17 23:44:44 --> URI Class Initialized
INFO - 2018-05-17 23:44:44 --> Router Class Initialized
INFO - 2018-05-17 23:44:44 --> Output Class Initialized
INFO - 2018-05-17 23:44:44 --> Security Class Initialized
DEBUG - 2018-05-17 23:44:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 23:44:44 --> Input Class Initialized
INFO - 2018-05-17 23:44:44 --> Language Class Initialized
ERROR - 2018-05-17 23:44:44 --> 404 Page Not Found: /index
INFO - 2018-05-17 23:44:44 --> Config Class Initialized
INFO - 2018-05-17 23:44:45 --> Hooks Class Initialized
DEBUG - 2018-05-17 23:44:45 --> UTF-8 Support Enabled
INFO - 2018-05-17 23:44:45 --> Utf8 Class Initialized
INFO - 2018-05-17 23:44:45 --> URI Class Initialized
INFO - 2018-05-17 23:44:45 --> Router Class Initialized
INFO - 2018-05-17 23:44:45 --> Output Class Initialized
INFO - 2018-05-17 23:44:45 --> Security Class Initialized
DEBUG - 2018-05-17 23:44:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 23:44:45 --> Input Class Initialized
INFO - 2018-05-17 23:44:45 --> Language Class Initialized
ERROR - 2018-05-17 23:44:45 --> 404 Page Not Found: /index
INFO - 2018-05-17 23:44:47 --> Config Class Initialized
INFO - 2018-05-17 23:44:47 --> Hooks Class Initialized
DEBUG - 2018-05-17 23:44:47 --> UTF-8 Support Enabled
INFO - 2018-05-17 23:44:47 --> Utf8 Class Initialized
INFO - 2018-05-17 23:44:47 --> URI Class Initialized
INFO - 2018-05-17 23:44:47 --> Router Class Initialized
INFO - 2018-05-17 23:44:47 --> Output Class Initialized
INFO - 2018-05-17 23:44:47 --> Security Class Initialized
DEBUG - 2018-05-17 23:44:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 23:44:47 --> Input Class Initialized
INFO - 2018-05-17 23:44:47 --> Language Class Initialized
INFO - 2018-05-17 23:44:47 --> Language Class Initialized
INFO - 2018-05-17 23:44:47 --> Config Class Initialized
INFO - 2018-05-17 23:44:47 --> Loader Class Initialized
DEBUG - 2018-05-17 23:44:47 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-17 23:44:47 --> Helper loaded: url_helper
INFO - 2018-05-17 23:44:47 --> Helper loaded: form_helper
INFO - 2018-05-17 23:44:47 --> Helper loaded: date_helper
INFO - 2018-05-17 23:44:47 --> Helper loaded: util_helper
INFO - 2018-05-17 23:44:47 --> Helper loaded: text_helper
INFO - 2018-05-17 23:44:47 --> Helper loaded: string_helper
INFO - 2018-05-17 23:44:47 --> Database Driver Class Initialized
DEBUG - 2018-05-17 23:44:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-17 23:44:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-17 23:44:47 --> Email Class Initialized
INFO - 2018-05-17 23:44:47 --> Controller Class Initialized
DEBUG - 2018-05-17 23:44:47 --> Home MX_Controller Initialized
DEBUG - 2018-05-17 23:44:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-17 23:44:47 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-17 23:44:47 --> Login MX_Controller Initialized
INFO - 2018-05-17 23:44:47 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-17 23:44:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-17 23:44:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-17 23:44:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-17 23:44:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-17 23:44:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-17 23:44:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-17 23:44:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-17 23:44:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-05-17 23:44:48 --> Final output sent to browser
DEBUG - 2018-05-17 23:44:48 --> Total execution time: 0.9349
INFO - 2018-05-17 23:44:48 --> Config Class Initialized
INFO - 2018-05-17 23:44:48 --> Config Class Initialized
INFO - 2018-05-17 23:44:48 --> Hooks Class Initialized
INFO - 2018-05-17 23:44:48 --> Hooks Class Initialized
DEBUG - 2018-05-17 23:44:48 --> UTF-8 Support Enabled
INFO - 2018-05-17 23:44:48 --> Utf8 Class Initialized
INFO - 2018-05-17 23:44:48 --> URI Class Initialized
DEBUG - 2018-05-17 23:44:48 --> UTF-8 Support Enabled
INFO - 2018-05-17 23:44:48 --> Router Class Initialized
INFO - 2018-05-17 23:44:48 --> Utf8 Class Initialized
INFO - 2018-05-17 23:44:48 --> Output Class Initialized
INFO - 2018-05-17 23:44:48 --> URI Class Initialized
INFO - 2018-05-17 23:44:48 --> Security Class Initialized
DEBUG - 2018-05-17 23:44:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 23:44:48 --> Router Class Initialized
INFO - 2018-05-17 23:44:48 --> Input Class Initialized
INFO - 2018-05-17 23:44:48 --> Language Class Initialized
INFO - 2018-05-17 23:44:48 --> Output Class Initialized
ERROR - 2018-05-17 23:44:48 --> 404 Page Not Found: /index
INFO - 2018-05-17 23:44:48 --> Security Class Initialized
DEBUG - 2018-05-17 23:44:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 23:44:48 --> Config Class Initialized
INFO - 2018-05-17 23:44:48 --> Hooks Class Initialized
INFO - 2018-05-17 23:44:48 --> Input Class Initialized
DEBUG - 2018-05-17 23:44:49 --> UTF-8 Support Enabled
INFO - 2018-05-17 23:44:49 --> Utf8 Class Initialized
INFO - 2018-05-17 23:44:49 --> Language Class Initialized
ERROR - 2018-05-17 23:44:49 --> 404 Page Not Found: /index
INFO - 2018-05-17 23:44:49 --> URI Class Initialized
INFO - 2018-05-17 23:44:49 --> Router Class Initialized
INFO - 2018-05-17 23:44:49 --> Output Class Initialized
INFO - 2018-05-17 23:44:49 --> Security Class Initialized
DEBUG - 2018-05-17 23:44:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 23:44:49 --> Input Class Initialized
INFO - 2018-05-17 23:44:49 --> Language Class Initialized
ERROR - 2018-05-17 23:44:49 --> 404 Page Not Found: /index
INFO - 2018-05-17 23:44:49 --> Config Class Initialized
INFO - 2018-05-17 23:44:49 --> Hooks Class Initialized
DEBUG - 2018-05-17 23:44:49 --> UTF-8 Support Enabled
INFO - 2018-05-17 23:44:49 --> Utf8 Class Initialized
INFO - 2018-05-17 23:44:49 --> URI Class Initialized
INFO - 2018-05-17 23:44:49 --> Config Class Initialized
INFO - 2018-05-17 23:44:49 --> Hooks Class Initialized
INFO - 2018-05-17 23:44:49 --> Router Class Initialized
DEBUG - 2018-05-17 23:44:49 --> UTF-8 Support Enabled
INFO - 2018-05-17 23:44:49 --> Output Class Initialized
INFO - 2018-05-17 23:44:49 --> Utf8 Class Initialized
INFO - 2018-05-17 23:44:49 --> Security Class Initialized
DEBUG - 2018-05-17 23:44:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 23:44:49 --> URI Class Initialized
INFO - 2018-05-17 23:44:49 --> Input Class Initialized
INFO - 2018-05-17 23:44:49 --> Router Class Initialized
INFO - 2018-05-17 23:44:49 --> Language Class Initialized
INFO - 2018-05-17 23:44:49 --> Output Class Initialized
ERROR - 2018-05-17 23:44:49 --> 404 Page Not Found: /index
INFO - 2018-05-17 23:44:49 --> Security Class Initialized
DEBUG - 2018-05-17 23:44:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 23:44:50 --> Input Class Initialized
INFO - 2018-05-17 23:44:50 --> Language Class Initialized
INFO - 2018-05-17 23:44:50 --> Language Class Initialized
INFO - 2018-05-17 23:44:50 --> Config Class Initialized
INFO - 2018-05-17 23:44:50 --> Loader Class Initialized
DEBUG - 2018-05-17 23:44:50 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-17 23:44:50 --> Helper loaded: url_helper
INFO - 2018-05-17 23:44:50 --> Helper loaded: form_helper
INFO - 2018-05-17 23:44:50 --> Helper loaded: date_helper
INFO - 2018-05-17 23:44:50 --> Helper loaded: util_helper
INFO - 2018-05-17 23:44:50 --> Helper loaded: text_helper
INFO - 2018-05-17 23:44:50 --> Helper loaded: string_helper
INFO - 2018-05-17 23:44:50 --> Database Driver Class Initialized
DEBUG - 2018-05-17 23:44:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-17 23:44:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-17 23:44:50 --> Email Class Initialized
INFO - 2018-05-17 23:44:50 --> Controller Class Initialized
DEBUG - 2018-05-17 23:44:50 --> Home MX_Controller Initialized
DEBUG - 2018-05-17 23:44:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-17 23:44:50 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-17 23:44:50 --> Login MX_Controller Initialized
INFO - 2018-05-17 23:44:50 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-17 23:44:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-17 23:44:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-17 23:44:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-17 23:44:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-17 23:44:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-17 23:44:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-17 23:44:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-17 23:44:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-05-17 23:44:50 --> Final output sent to browser
DEBUG - 2018-05-17 23:44:50 --> Total execution time: 0.9688
INFO - 2018-05-17 23:44:50 --> Config Class Initialized
INFO - 2018-05-17 23:44:50 --> Config Class Initialized
INFO - 2018-05-17 23:44:51 --> Hooks Class Initialized
DEBUG - 2018-05-17 23:44:51 --> UTF-8 Support Enabled
INFO - 2018-05-17 23:44:51 --> Utf8 Class Initialized
INFO - 2018-05-17 23:44:51 --> Hooks Class Initialized
INFO - 2018-05-17 23:44:51 --> URI Class Initialized
DEBUG - 2018-05-17 23:44:51 --> UTF-8 Support Enabled
INFO - 2018-05-17 23:44:51 --> Utf8 Class Initialized
INFO - 2018-05-17 23:44:51 --> URI Class Initialized
INFO - 2018-05-17 23:44:51 --> Router Class Initialized
INFO - 2018-05-17 23:44:51 --> Router Class Initialized
INFO - 2018-05-17 23:44:51 --> Output Class Initialized
INFO - 2018-05-17 23:44:51 --> Security Class Initialized
DEBUG - 2018-05-17 23:44:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 23:44:51 --> Input Class Initialized
INFO - 2018-05-17 23:44:51 --> Output Class Initialized
INFO - 2018-05-17 23:44:51 --> Security Class Initialized
INFO - 2018-05-17 23:44:51 --> Language Class Initialized
DEBUG - 2018-05-17 23:44:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 23:44:51 --> Input Class Initialized
ERROR - 2018-05-17 23:44:51 --> 404 Page Not Found: /index
INFO - 2018-05-17 23:44:51 --> Language Class Initialized
ERROR - 2018-05-17 23:44:51 --> 404 Page Not Found: /index
INFO - 2018-05-17 23:44:51 --> Config Class Initialized
INFO - 2018-05-17 23:44:51 --> Hooks Class Initialized
DEBUG - 2018-05-17 23:44:51 --> UTF-8 Support Enabled
INFO - 2018-05-17 23:44:51 --> Utf8 Class Initialized
INFO - 2018-05-17 23:44:51 --> URI Class Initialized
INFO - 2018-05-17 23:44:52 --> Router Class Initialized
INFO - 2018-05-17 23:44:52 --> Output Class Initialized
INFO - 2018-05-17 23:44:52 --> Security Class Initialized
DEBUG - 2018-05-17 23:44:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 23:44:52 --> Input Class Initialized
INFO - 2018-05-17 23:44:52 --> Language Class Initialized
ERROR - 2018-05-17 23:44:52 --> 404 Page Not Found: /index
INFO - 2018-05-17 23:44:52 --> Config Class Initialized
INFO - 2018-05-17 23:44:52 --> Hooks Class Initialized
DEBUG - 2018-05-17 23:44:52 --> UTF-8 Support Enabled
INFO - 2018-05-17 23:44:52 --> Utf8 Class Initialized
INFO - 2018-05-17 23:44:52 --> URI Class Initialized
INFO - 2018-05-17 23:44:52 --> Router Class Initialized
INFO - 2018-05-17 23:44:52 --> Output Class Initialized
INFO - 2018-05-17 23:44:52 --> Security Class Initialized
DEBUG - 2018-05-17 23:44:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-17 23:44:52 --> Input Class Initialized
INFO - 2018-05-17 23:44:52 --> Language Class Initialized
ERROR - 2018-05-17 23:44:52 --> 404 Page Not Found: /index
