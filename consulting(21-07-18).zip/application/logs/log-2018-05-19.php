<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-05-19 00:29:55 --> Config Class Initialized
INFO - 2018-05-19 00:29:55 --> Hooks Class Initialized
DEBUG - 2018-05-19 00:29:55 --> UTF-8 Support Enabled
INFO - 2018-05-19 00:29:55 --> Utf8 Class Initialized
INFO - 2018-05-19 00:29:55 --> URI Class Initialized
INFO - 2018-05-19 00:29:55 --> Router Class Initialized
INFO - 2018-05-19 00:29:55 --> Output Class Initialized
INFO - 2018-05-19 00:29:55 --> Security Class Initialized
DEBUG - 2018-05-19 00:29:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 00:29:55 --> Input Class Initialized
INFO - 2018-05-19 00:29:55 --> Language Class Initialized
INFO - 2018-05-19 00:29:55 --> Language Class Initialized
INFO - 2018-05-19 00:29:55 --> Config Class Initialized
INFO - 2018-05-19 00:29:55 --> Loader Class Initialized
DEBUG - 2018-05-19 00:29:55 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-19 00:29:56 --> Helper loaded: url_helper
INFO - 2018-05-19 00:29:56 --> Helper loaded: form_helper
INFO - 2018-05-19 00:29:56 --> Helper loaded: date_helper
INFO - 2018-05-19 00:29:56 --> Helper loaded: util_helper
INFO - 2018-05-19 00:29:56 --> Helper loaded: text_helper
INFO - 2018-05-19 00:29:56 --> Helper loaded: string_helper
INFO - 2018-05-19 00:29:56 --> Database Driver Class Initialized
DEBUG - 2018-05-19 00:29:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-19 00:29:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-19 00:29:56 --> Email Class Initialized
INFO - 2018-05-19 00:29:56 --> Controller Class Initialized
DEBUG - 2018-05-19 00:29:56 --> Admin MX_Controller Initialized
INFO - 2018-05-19 00:29:56 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-19 00:29:56 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-19 00:29:56 --> Login MX_Controller Initialized
DEBUG - 2018-05-19 00:29:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-19 00:29:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-19 00:29:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/logins/login.php
INFO - 2018-05-19 00:29:56 --> Config Class Initialized
INFO - 2018-05-19 00:29:56 --> Hooks Class Initialized
DEBUG - 2018-05-19 00:29:56 --> UTF-8 Support Enabled
INFO - 2018-05-19 00:29:56 --> Utf8 Class Initialized
INFO - 2018-05-19 00:29:56 --> URI Class Initialized
INFO - 2018-05-19 00:29:56 --> Router Class Initialized
INFO - 2018-05-19 00:29:56 --> Output Class Initialized
INFO - 2018-05-19 00:29:56 --> Security Class Initialized
DEBUG - 2018-05-19 00:29:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 00:29:56 --> Input Class Initialized
INFO - 2018-05-19 00:29:56 --> Language Class Initialized
ERROR - 2018-05-19 00:29:56 --> 404 Page Not Found: /index
INFO - 2018-05-19 00:29:56 --> Config Class Initialized
INFO - 2018-05-19 00:29:56 --> Hooks Class Initialized
DEBUG - 2018-05-19 00:29:56 --> UTF-8 Support Enabled
INFO - 2018-05-19 00:29:56 --> Utf8 Class Initialized
INFO - 2018-05-19 00:29:56 --> URI Class Initialized
INFO - 2018-05-19 00:29:56 --> Router Class Initialized
INFO - 2018-05-19 00:29:56 --> Output Class Initialized
INFO - 2018-05-19 00:29:56 --> Security Class Initialized
DEBUG - 2018-05-19 00:29:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 00:29:56 --> Input Class Initialized
INFO - 2018-05-19 00:29:56 --> Language Class Initialized
ERROR - 2018-05-19 00:29:56 --> 404 Page Not Found: /index
INFO - 2018-05-19 00:30:07 --> Config Class Initialized
INFO - 2018-05-19 00:30:07 --> Hooks Class Initialized
DEBUG - 2018-05-19 00:30:07 --> UTF-8 Support Enabled
INFO - 2018-05-19 00:30:07 --> Utf8 Class Initialized
INFO - 2018-05-19 00:30:07 --> URI Class Initialized
INFO - 2018-05-19 00:30:07 --> Router Class Initialized
INFO - 2018-05-19 00:30:07 --> Output Class Initialized
INFO - 2018-05-19 00:30:07 --> Security Class Initialized
DEBUG - 2018-05-19 00:30:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 00:30:07 --> Input Class Initialized
INFO - 2018-05-19 00:30:07 --> Language Class Initialized
INFO - 2018-05-19 00:30:07 --> Language Class Initialized
INFO - 2018-05-19 00:30:07 --> Config Class Initialized
INFO - 2018-05-19 00:30:07 --> Loader Class Initialized
DEBUG - 2018-05-19 00:30:07 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-19 00:30:07 --> Helper loaded: url_helper
INFO - 2018-05-19 00:30:07 --> Helper loaded: form_helper
INFO - 2018-05-19 00:30:07 --> Helper loaded: date_helper
INFO - 2018-05-19 00:30:07 --> Helper loaded: util_helper
INFO - 2018-05-19 00:30:07 --> Helper loaded: text_helper
INFO - 2018-05-19 00:30:07 --> Helper loaded: string_helper
INFO - 2018-05-19 00:30:07 --> Database Driver Class Initialized
DEBUG - 2018-05-19 00:30:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-19 00:30:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-19 00:30:07 --> Email Class Initialized
INFO - 2018-05-19 00:30:07 --> Controller Class Initialized
DEBUG - 2018-05-19 00:30:07 --> Login MX_Controller Initialized
INFO - 2018-05-19 00:30:07 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-19 00:30:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-19 00:30:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-19 00:30:07 --> Email starts for admin@colin.com fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-05-19 00:30:07 --> User session created for 1
INFO - 2018-05-19 00:30:07 --> Login status admin@colin.com - success
INFO - 2018-05-19 00:30:07 --> Final output sent to browser
DEBUG - 2018-05-19 00:30:07 --> Total execution time: 0.4608
INFO - 2018-05-19 00:30:07 --> Config Class Initialized
INFO - 2018-05-19 00:30:07 --> Hooks Class Initialized
DEBUG - 2018-05-19 00:30:07 --> UTF-8 Support Enabled
INFO - 2018-05-19 00:30:07 --> Utf8 Class Initialized
INFO - 2018-05-19 00:30:07 --> URI Class Initialized
INFO - 2018-05-19 00:30:07 --> Router Class Initialized
INFO - 2018-05-19 00:30:07 --> Output Class Initialized
INFO - 2018-05-19 00:30:07 --> Security Class Initialized
DEBUG - 2018-05-19 00:30:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 00:30:07 --> Input Class Initialized
INFO - 2018-05-19 00:30:07 --> Language Class Initialized
INFO - 2018-05-19 00:30:07 --> Language Class Initialized
INFO - 2018-05-19 00:30:07 --> Config Class Initialized
INFO - 2018-05-19 00:30:07 --> Loader Class Initialized
DEBUG - 2018-05-19 00:30:07 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-19 00:30:07 --> Helper loaded: url_helper
INFO - 2018-05-19 00:30:07 --> Helper loaded: form_helper
INFO - 2018-05-19 00:30:07 --> Helper loaded: date_helper
INFO - 2018-05-19 00:30:07 --> Helper loaded: util_helper
INFO - 2018-05-19 00:30:07 --> Helper loaded: text_helper
INFO - 2018-05-19 00:30:07 --> Helper loaded: string_helper
INFO - 2018-05-19 00:30:07 --> Database Driver Class Initialized
DEBUG - 2018-05-19 00:30:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-19 00:30:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-19 00:30:07 --> Email Class Initialized
INFO - 2018-05-19 00:30:07 --> Controller Class Initialized
DEBUG - 2018-05-19 00:30:07 --> Admin MX_Controller Initialized
INFO - 2018-05-19 00:30:07 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-19 00:30:08 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-19 00:30:08 --> Login MX_Controller Initialized
DEBUG - 2018-05-19 00:30:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-19 00:30:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-19 00:30:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-05-19 00:30:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-05-19 00:30:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-05-19 00:30:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-05-19 00:30:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-05-19 00:30:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/dashboard.php
INFO - 2018-05-19 00:30:08 --> Final output sent to browser
DEBUG - 2018-05-19 00:30:08 --> Total execution time: 0.3907
INFO - 2018-05-19 00:30:08 --> Config Class Initialized
INFO - 2018-05-19 00:30:08 --> Hooks Class Initialized
DEBUG - 2018-05-19 00:30:08 --> UTF-8 Support Enabled
INFO - 2018-05-19 00:30:08 --> Utf8 Class Initialized
INFO - 2018-05-19 00:30:08 --> URI Class Initialized
INFO - 2018-05-19 00:30:08 --> Router Class Initialized
INFO - 2018-05-19 00:30:08 --> Output Class Initialized
INFO - 2018-05-19 00:30:08 --> Security Class Initialized
DEBUG - 2018-05-19 00:30:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 00:30:08 --> Input Class Initialized
INFO - 2018-05-19 00:30:08 --> Language Class Initialized
ERROR - 2018-05-19 00:30:08 --> 404 Page Not Found: /index
INFO - 2018-05-19 00:30:09 --> Config Class Initialized
INFO - 2018-05-19 00:30:09 --> Hooks Class Initialized
DEBUG - 2018-05-19 00:30:09 --> UTF-8 Support Enabled
INFO - 2018-05-19 00:30:09 --> Utf8 Class Initialized
INFO - 2018-05-19 00:30:09 --> URI Class Initialized
INFO - 2018-05-19 00:30:09 --> Router Class Initialized
INFO - 2018-05-19 00:30:09 --> Output Class Initialized
INFO - 2018-05-19 00:30:09 --> Security Class Initialized
DEBUG - 2018-05-19 00:30:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 00:30:09 --> Input Class Initialized
INFO - 2018-05-19 00:30:09 --> Language Class Initialized
ERROR - 2018-05-19 00:30:09 --> 404 Page Not Found: /index
INFO - 2018-05-19 00:30:13 --> Config Class Initialized
INFO - 2018-05-19 00:30:13 --> Hooks Class Initialized
DEBUG - 2018-05-19 00:30:13 --> UTF-8 Support Enabled
INFO - 2018-05-19 00:30:13 --> Utf8 Class Initialized
INFO - 2018-05-19 00:30:13 --> URI Class Initialized
INFO - 2018-05-19 00:30:13 --> Router Class Initialized
INFO - 2018-05-19 00:30:13 --> Output Class Initialized
INFO - 2018-05-19 00:30:13 --> Security Class Initialized
DEBUG - 2018-05-19 00:30:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 00:30:13 --> Input Class Initialized
INFO - 2018-05-19 00:30:13 --> Language Class Initialized
INFO - 2018-05-19 00:30:13 --> Language Class Initialized
INFO - 2018-05-19 00:30:13 --> Config Class Initialized
INFO - 2018-05-19 00:30:13 --> Loader Class Initialized
DEBUG - 2018-05-19 00:30:13 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-19 00:30:13 --> Helper loaded: url_helper
INFO - 2018-05-19 00:30:13 --> Helper loaded: form_helper
INFO - 2018-05-19 00:30:13 --> Helper loaded: date_helper
INFO - 2018-05-19 00:30:13 --> Helper loaded: util_helper
INFO - 2018-05-19 00:30:13 --> Helper loaded: text_helper
INFO - 2018-05-19 00:30:13 --> Helper loaded: string_helper
INFO - 2018-05-19 00:30:13 --> Database Driver Class Initialized
DEBUG - 2018-05-19 00:30:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-19 00:30:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-19 00:30:13 --> Email Class Initialized
INFO - 2018-05-19 00:30:13 --> Controller Class Initialized
DEBUG - 2018-05-19 00:30:13 --> Login MX_Controller Initialized
INFO - 2018-05-19 00:30:13 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-19 00:30:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-19 00:30:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-19 00:30:13 --> Email starts for user@colin.com fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-05-19 00:30:13 --> User session created for 4
INFO - 2018-05-19 00:30:13 --> Login status user@colin.com - success
INFO - 2018-05-19 00:30:13 --> Final output sent to browser
DEBUG - 2018-05-19 00:30:13 --> Total execution time: 0.5369
INFO - 2018-05-19 00:30:13 --> Config Class Initialized
INFO - 2018-05-19 00:30:13 --> Hooks Class Initialized
DEBUG - 2018-05-19 00:30:13 --> UTF-8 Support Enabled
INFO - 2018-05-19 00:30:13 --> Utf8 Class Initialized
INFO - 2018-05-19 00:30:13 --> URI Class Initialized
INFO - 2018-05-19 00:30:13 --> Router Class Initialized
INFO - 2018-05-19 00:30:14 --> Output Class Initialized
INFO - 2018-05-19 00:30:14 --> Security Class Initialized
DEBUG - 2018-05-19 00:30:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 00:30:14 --> Input Class Initialized
INFO - 2018-05-19 00:30:14 --> Language Class Initialized
INFO - 2018-05-19 00:30:14 --> Language Class Initialized
INFO - 2018-05-19 00:30:14 --> Config Class Initialized
INFO - 2018-05-19 00:30:14 --> Loader Class Initialized
DEBUG - 2018-05-19 00:30:14 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-19 00:30:14 --> Helper loaded: url_helper
INFO - 2018-05-19 00:30:14 --> Helper loaded: form_helper
INFO - 2018-05-19 00:30:14 --> Helper loaded: date_helper
INFO - 2018-05-19 00:30:14 --> Helper loaded: util_helper
INFO - 2018-05-19 00:30:14 --> Helper loaded: text_helper
INFO - 2018-05-19 00:30:14 --> Helper loaded: string_helper
INFO - 2018-05-19 00:30:14 --> Database Driver Class Initialized
DEBUG - 2018-05-19 00:30:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-19 00:30:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-19 00:30:14 --> Email Class Initialized
INFO - 2018-05-19 00:30:14 --> Controller Class Initialized
DEBUG - 2018-05-19 00:30:14 --> Home MX_Controller Initialized
DEBUG - 2018-05-19 00:30:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-19 00:30:14 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-19 00:30:14 --> Login MX_Controller Initialized
INFO - 2018-05-19 00:30:14 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-19 00:30:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-19 00:30:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-19 00:30:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-19 00:30:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-19 00:30:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-19 00:30:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-19 00:30:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-19 00:30:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-05-19 00:30:14 --> Final output sent to browser
DEBUG - 2018-05-19 00:30:14 --> Total execution time: 0.3934
INFO - 2018-05-19 00:30:15 --> Config Class Initialized
INFO - 2018-05-19 00:30:15 --> Hooks Class Initialized
DEBUG - 2018-05-19 00:30:15 --> UTF-8 Support Enabled
INFO - 2018-05-19 00:30:15 --> Utf8 Class Initialized
INFO - 2018-05-19 00:30:15 --> URI Class Initialized
INFO - 2018-05-19 00:30:15 --> Router Class Initialized
INFO - 2018-05-19 00:30:15 --> Output Class Initialized
INFO - 2018-05-19 00:30:15 --> Security Class Initialized
DEBUG - 2018-05-19 00:30:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 00:30:15 --> Input Class Initialized
INFO - 2018-05-19 00:30:15 --> Language Class Initialized
ERROR - 2018-05-19 00:30:15 --> 404 Page Not Found: /index
INFO - 2018-05-19 00:30:15 --> Config Class Initialized
INFO - 2018-05-19 00:30:15 --> Hooks Class Initialized
DEBUG - 2018-05-19 00:30:15 --> UTF-8 Support Enabled
INFO - 2018-05-19 00:30:15 --> Utf8 Class Initialized
INFO - 2018-05-19 00:30:15 --> URI Class Initialized
INFO - 2018-05-19 00:30:15 --> Router Class Initialized
INFO - 2018-05-19 00:30:15 --> Output Class Initialized
INFO - 2018-05-19 00:30:15 --> Security Class Initialized
DEBUG - 2018-05-19 00:30:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 00:30:16 --> Input Class Initialized
INFO - 2018-05-19 00:30:16 --> Language Class Initialized
ERROR - 2018-05-19 00:30:16 --> 404 Page Not Found: /index
INFO - 2018-05-19 00:30:16 --> Config Class Initialized
INFO - 2018-05-19 00:30:16 --> Hooks Class Initialized
DEBUG - 2018-05-19 00:30:16 --> UTF-8 Support Enabled
INFO - 2018-05-19 00:30:16 --> Utf8 Class Initialized
INFO - 2018-05-19 00:30:16 --> Config Class Initialized
INFO - 2018-05-19 00:30:16 --> Hooks Class Initialized
INFO - 2018-05-19 00:30:16 --> URI Class Initialized
DEBUG - 2018-05-19 00:30:16 --> UTF-8 Support Enabled
INFO - 2018-05-19 00:30:16 --> Utf8 Class Initialized
INFO - 2018-05-19 00:30:16 --> Router Class Initialized
INFO - 2018-05-19 00:30:16 --> URI Class Initialized
INFO - 2018-05-19 00:30:16 --> Output Class Initialized
INFO - 2018-05-19 00:30:16 --> Router Class Initialized
INFO - 2018-05-19 00:30:16 --> Output Class Initialized
INFO - 2018-05-19 00:30:16 --> Security Class Initialized
INFO - 2018-05-19 00:30:16 --> Security Class Initialized
DEBUG - 2018-05-19 00:30:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-19 00:30:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 00:30:16 --> Input Class Initialized
INFO - 2018-05-19 00:30:16 --> Input Class Initialized
INFO - 2018-05-19 00:30:16 --> Language Class Initialized
INFO - 2018-05-19 00:30:16 --> Language Class Initialized
ERROR - 2018-05-19 00:30:16 --> 404 Page Not Found: /index
ERROR - 2018-05-19 00:30:16 --> 404 Page Not Found: /index
INFO - 2018-05-19 00:30:16 --> Config Class Initialized
INFO - 2018-05-19 00:30:16 --> Hooks Class Initialized
DEBUG - 2018-05-19 00:30:16 --> UTF-8 Support Enabled
INFO - 2018-05-19 00:30:16 --> Utf8 Class Initialized
INFO - 2018-05-19 00:30:16 --> URI Class Initialized
INFO - 2018-05-19 00:30:16 --> Router Class Initialized
INFO - 2018-05-19 00:30:16 --> Output Class Initialized
INFO - 2018-05-19 00:30:16 --> Security Class Initialized
DEBUG - 2018-05-19 00:30:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 00:30:16 --> Input Class Initialized
INFO - 2018-05-19 00:30:16 --> Language Class Initialized
ERROR - 2018-05-19 00:30:16 --> 404 Page Not Found: /index
INFO - 2018-05-19 00:30:17 --> Config Class Initialized
INFO - 2018-05-19 00:30:17 --> Hooks Class Initialized
DEBUG - 2018-05-19 00:30:17 --> UTF-8 Support Enabled
INFO - 2018-05-19 00:30:17 --> Utf8 Class Initialized
INFO - 2018-05-19 00:30:17 --> URI Class Initialized
INFO - 2018-05-19 00:30:17 --> Router Class Initialized
INFO - 2018-05-19 00:30:17 --> Output Class Initialized
INFO - 2018-05-19 00:30:17 --> Security Class Initialized
DEBUG - 2018-05-19 00:30:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 00:30:17 --> Input Class Initialized
INFO - 2018-05-19 00:30:17 --> Language Class Initialized
ERROR - 2018-05-19 00:30:17 --> 404 Page Not Found: /index
INFO - 2018-05-19 00:30:17 --> Config Class Initialized
INFO - 2018-05-19 00:30:17 --> Hooks Class Initialized
DEBUG - 2018-05-19 00:30:17 --> UTF-8 Support Enabled
INFO - 2018-05-19 00:30:17 --> Utf8 Class Initialized
INFO - 2018-05-19 00:30:17 --> URI Class Initialized
INFO - 2018-05-19 00:30:17 --> Router Class Initialized
INFO - 2018-05-19 00:30:17 --> Output Class Initialized
INFO - 2018-05-19 00:30:17 --> Security Class Initialized
DEBUG - 2018-05-19 00:30:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 00:30:17 --> Input Class Initialized
INFO - 2018-05-19 00:30:17 --> Language Class Initialized
ERROR - 2018-05-19 00:30:17 --> 404 Page Not Found: /index
INFO - 2018-05-19 00:30:25 --> Config Class Initialized
INFO - 2018-05-19 00:30:25 --> Hooks Class Initialized
DEBUG - 2018-05-19 00:30:25 --> UTF-8 Support Enabled
INFO - 2018-05-19 00:30:25 --> Utf8 Class Initialized
INFO - 2018-05-19 00:30:25 --> URI Class Initialized
INFO - 2018-05-19 00:30:25 --> Router Class Initialized
INFO - 2018-05-19 00:30:25 --> Output Class Initialized
INFO - 2018-05-19 00:30:25 --> Security Class Initialized
DEBUG - 2018-05-19 00:30:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 00:30:25 --> Input Class Initialized
INFO - 2018-05-19 00:30:25 --> Language Class Initialized
INFO - 2018-05-19 00:30:25 --> Language Class Initialized
INFO - 2018-05-19 00:30:25 --> Config Class Initialized
INFO - 2018-05-19 00:30:25 --> Loader Class Initialized
DEBUG - 2018-05-19 00:30:25 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-19 00:30:25 --> Helper loaded: url_helper
INFO - 2018-05-19 00:30:25 --> Helper loaded: form_helper
INFO - 2018-05-19 00:30:25 --> Helper loaded: date_helper
INFO - 2018-05-19 00:30:25 --> Helper loaded: util_helper
INFO - 2018-05-19 00:30:25 --> Helper loaded: text_helper
INFO - 2018-05-19 00:30:25 --> Helper loaded: string_helper
INFO - 2018-05-19 00:30:25 --> Database Driver Class Initialized
DEBUG - 2018-05-19 00:30:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-19 00:30:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-19 00:30:25 --> Email Class Initialized
INFO - 2018-05-19 00:30:25 --> Controller Class Initialized
DEBUG - 2018-05-19 00:30:25 --> Profile MX_Controller Initialized
DEBUG - 2018-05-19 00:30:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-19 00:30:25 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-19 00:30:25 --> Login MX_Controller Initialized
INFO - 2018-05-19 00:30:26 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-19 00:30:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-19 00:30:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-19 00:30:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-19 00:30:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-19 00:30:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-19 00:30:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/profile_left_nav.php
DEBUG - 2018-05-19 00:30:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-19 00:30:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-19 00:30:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/profile.php
INFO - 2018-05-19 00:30:26 --> Final output sent to browser
DEBUG - 2018-05-19 00:30:26 --> Total execution time: 0.4274
INFO - 2018-05-19 00:30:26 --> Config Class Initialized
INFO - 2018-05-19 00:30:26 --> Hooks Class Initialized
DEBUG - 2018-05-19 00:30:26 --> UTF-8 Support Enabled
INFO - 2018-05-19 00:30:26 --> Utf8 Class Initialized
INFO - 2018-05-19 00:30:26 --> URI Class Initialized
INFO - 2018-05-19 00:30:26 --> Config Class Initialized
INFO - 2018-05-19 00:30:26 --> Hooks Class Initialized
INFO - 2018-05-19 00:30:26 --> Router Class Initialized
DEBUG - 2018-05-19 00:30:26 --> UTF-8 Support Enabled
INFO - 2018-05-19 00:30:26 --> Utf8 Class Initialized
INFO - 2018-05-19 00:30:26 --> Output Class Initialized
INFO - 2018-05-19 00:30:26 --> URI Class Initialized
INFO - 2018-05-19 00:30:26 --> Security Class Initialized
DEBUG - 2018-05-19 00:30:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 00:30:26 --> Input Class Initialized
INFO - 2018-05-19 00:30:26 --> Language Class Initialized
ERROR - 2018-05-19 00:30:26 --> 404 Page Not Found: /index
INFO - 2018-05-19 00:30:26 --> Router Class Initialized
INFO - 2018-05-19 00:30:26 --> Config Class Initialized
INFO - 2018-05-19 00:30:26 --> Hooks Class Initialized
INFO - 2018-05-19 00:30:26 --> Output Class Initialized
DEBUG - 2018-05-19 00:30:26 --> UTF-8 Support Enabled
INFO - 2018-05-19 00:30:26 --> Utf8 Class Initialized
INFO - 2018-05-19 00:30:26 --> URI Class Initialized
INFO - 2018-05-19 00:30:26 --> Security Class Initialized
INFO - 2018-05-19 00:30:26 --> Router Class Initialized
DEBUG - 2018-05-19 00:30:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 00:30:26 --> Output Class Initialized
INFO - 2018-05-19 00:30:26 --> Security Class Initialized
INFO - 2018-05-19 00:30:26 --> Input Class Initialized
INFO - 2018-05-19 00:30:27 --> Language Class Initialized
DEBUG - 2018-05-19 00:30:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-05-19 00:30:27 --> 404 Page Not Found: /index
INFO - 2018-05-19 00:30:27 --> Input Class Initialized
INFO - 2018-05-19 00:30:27 --> Language Class Initialized
ERROR - 2018-05-19 00:30:27 --> 404 Page Not Found: /index
INFO - 2018-05-19 00:30:27 --> Config Class Initialized
INFO - 2018-05-19 00:30:27 --> Hooks Class Initialized
DEBUG - 2018-05-19 00:30:27 --> UTF-8 Support Enabled
INFO - 2018-05-19 00:30:27 --> Utf8 Class Initialized
INFO - 2018-05-19 00:30:27 --> URI Class Initialized
INFO - 2018-05-19 00:30:27 --> Router Class Initialized
INFO - 2018-05-19 00:30:27 --> Output Class Initialized
INFO - 2018-05-19 00:30:27 --> Security Class Initialized
DEBUG - 2018-05-19 00:30:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 00:30:27 --> Input Class Initialized
INFO - 2018-05-19 00:30:27 --> Language Class Initialized
ERROR - 2018-05-19 00:30:27 --> 404 Page Not Found: /index
INFO - 2018-05-19 00:30:48 --> Config Class Initialized
INFO - 2018-05-19 00:30:48 --> Hooks Class Initialized
DEBUG - 2018-05-19 00:30:48 --> UTF-8 Support Enabled
INFO - 2018-05-19 00:30:48 --> Utf8 Class Initialized
INFO - 2018-05-19 00:30:48 --> URI Class Initialized
INFO - 2018-05-19 00:30:48 --> Router Class Initialized
INFO - 2018-05-19 00:30:48 --> Output Class Initialized
INFO - 2018-05-19 00:30:48 --> Security Class Initialized
DEBUG - 2018-05-19 00:30:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 00:30:48 --> Input Class Initialized
INFO - 2018-05-19 00:30:48 --> Language Class Initialized
INFO - 2018-05-19 00:30:48 --> Language Class Initialized
INFO - 2018-05-19 00:30:48 --> Config Class Initialized
INFO - 2018-05-19 00:30:48 --> Loader Class Initialized
DEBUG - 2018-05-19 00:30:48 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-19 00:30:48 --> Helper loaded: url_helper
INFO - 2018-05-19 00:30:48 --> Helper loaded: form_helper
INFO - 2018-05-19 00:30:48 --> Helper loaded: date_helper
INFO - 2018-05-19 00:30:49 --> Helper loaded: util_helper
INFO - 2018-05-19 00:30:49 --> Helper loaded: text_helper
INFO - 2018-05-19 00:30:49 --> Helper loaded: string_helper
INFO - 2018-05-19 00:30:49 --> Database Driver Class Initialized
DEBUG - 2018-05-19 00:30:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-19 00:30:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-19 00:30:49 --> Email Class Initialized
INFO - 2018-05-19 00:30:49 --> Controller Class Initialized
DEBUG - 2018-05-19 00:30:49 --> Home MX_Controller Initialized
DEBUG - 2018-05-19 00:30:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-19 00:30:49 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-19 00:30:49 --> Login MX_Controller Initialized
INFO - 2018-05-19 00:30:49 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-19 00:30:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-19 00:30:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-19 00:30:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-19 00:30:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-19 00:30:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-19 00:30:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-19 00:30:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-19 00:30:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/refer_a_friend.php
INFO - 2018-05-19 00:30:49 --> Final output sent to browser
DEBUG - 2018-05-19 00:30:49 --> Total execution time: 0.4259
INFO - 2018-05-19 00:30:49 --> Config Class Initialized
INFO - 2018-05-19 00:30:49 --> Hooks Class Initialized
DEBUG - 2018-05-19 00:30:49 --> UTF-8 Support Enabled
INFO - 2018-05-19 00:30:49 --> Utf8 Class Initialized
INFO - 2018-05-19 00:30:49 --> URI Class Initialized
INFO - 2018-05-19 00:30:49 --> Router Class Initialized
INFO - 2018-05-19 00:30:49 --> Output Class Initialized
INFO - 2018-05-19 00:30:49 --> Security Class Initialized
DEBUG - 2018-05-19 00:30:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 00:30:49 --> Input Class Initialized
INFO - 2018-05-19 00:30:49 --> Language Class Initialized
ERROR - 2018-05-19 00:30:49 --> 404 Page Not Found: /index
INFO - 2018-05-19 00:30:49 --> Config Class Initialized
INFO - 2018-05-19 00:30:50 --> Hooks Class Initialized
DEBUG - 2018-05-19 00:30:50 --> UTF-8 Support Enabled
INFO - 2018-05-19 00:30:50 --> Utf8 Class Initialized
INFO - 2018-05-19 00:30:50 --> URI Class Initialized
INFO - 2018-05-19 00:30:50 --> Router Class Initialized
INFO - 2018-05-19 00:30:50 --> Output Class Initialized
INFO - 2018-05-19 00:30:50 --> Security Class Initialized
DEBUG - 2018-05-19 00:30:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 00:30:50 --> Input Class Initialized
INFO - 2018-05-19 00:30:50 --> Language Class Initialized
ERROR - 2018-05-19 00:30:50 --> 404 Page Not Found: /index
INFO - 2018-05-19 00:30:50 --> Config Class Initialized
INFO - 2018-05-19 00:30:50 --> Hooks Class Initialized
DEBUG - 2018-05-19 00:30:50 --> UTF-8 Support Enabled
INFO - 2018-05-19 00:30:50 --> Utf8 Class Initialized
INFO - 2018-05-19 00:30:50 --> URI Class Initialized
INFO - 2018-05-19 00:30:50 --> Router Class Initialized
INFO - 2018-05-19 00:30:50 --> Output Class Initialized
INFO - 2018-05-19 00:30:50 --> Security Class Initialized
DEBUG - 2018-05-19 00:30:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 00:30:50 --> Input Class Initialized
INFO - 2018-05-19 00:30:50 --> Language Class Initialized
ERROR - 2018-05-19 00:30:50 --> 404 Page Not Found: /index
INFO - 2018-05-19 00:31:11 --> Config Class Initialized
INFO - 2018-05-19 00:31:11 --> Hooks Class Initialized
DEBUG - 2018-05-19 00:31:11 --> UTF-8 Support Enabled
INFO - 2018-05-19 00:31:11 --> Utf8 Class Initialized
INFO - 2018-05-19 00:31:11 --> URI Class Initialized
INFO - 2018-05-19 00:31:11 --> Router Class Initialized
INFO - 2018-05-19 00:31:11 --> Output Class Initialized
INFO - 2018-05-19 00:31:11 --> Security Class Initialized
DEBUG - 2018-05-19 00:31:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 00:31:11 --> Input Class Initialized
INFO - 2018-05-19 00:31:11 --> Language Class Initialized
INFO - 2018-05-19 00:31:11 --> Language Class Initialized
INFO - 2018-05-19 00:31:11 --> Config Class Initialized
INFO - 2018-05-19 00:31:11 --> Loader Class Initialized
DEBUG - 2018-05-19 00:31:11 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-19 00:31:11 --> Helper loaded: url_helper
INFO - 2018-05-19 00:31:11 --> Helper loaded: form_helper
INFO - 2018-05-19 00:31:11 --> Helper loaded: date_helper
INFO - 2018-05-19 00:31:11 --> Helper loaded: util_helper
INFO - 2018-05-19 00:31:11 --> Helper loaded: text_helper
INFO - 2018-05-19 00:31:11 --> Helper loaded: string_helper
INFO - 2018-05-19 00:31:11 --> Database Driver Class Initialized
DEBUG - 2018-05-19 00:31:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-19 00:31:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-19 00:31:11 --> Email Class Initialized
INFO - 2018-05-19 00:31:11 --> Controller Class Initialized
DEBUG - 2018-05-19 00:31:11 --> Home MX_Controller Initialized
DEBUG - 2018-05-19 00:31:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-19 00:31:11 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-19 00:31:11 --> Login MX_Controller Initialized
INFO - 2018-05-19 00:31:11 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-19 00:31:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-19 00:31:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-19 00:31:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-19 00:31:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-19 00:31:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-19 00:31:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-19 00:31:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-19 00:31:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/refer_a_friend.php
INFO - 2018-05-19 00:31:11 --> Final output sent to browser
DEBUG - 2018-05-19 00:31:11 --> Total execution time: 0.4806
INFO - 2018-05-19 00:31:12 --> Config Class Initialized
INFO - 2018-05-19 00:31:12 --> Hooks Class Initialized
DEBUG - 2018-05-19 00:31:12 --> UTF-8 Support Enabled
INFO - 2018-05-19 00:31:12 --> Utf8 Class Initialized
INFO - 2018-05-19 00:31:12 --> URI Class Initialized
INFO - 2018-05-19 00:31:12 --> Router Class Initialized
INFO - 2018-05-19 00:31:12 --> Output Class Initialized
INFO - 2018-05-19 00:31:12 --> Security Class Initialized
DEBUG - 2018-05-19 00:31:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 00:31:12 --> Input Class Initialized
INFO - 2018-05-19 00:31:12 --> Language Class Initialized
ERROR - 2018-05-19 00:31:12 --> 404 Page Not Found: /index
INFO - 2018-05-19 00:31:12 --> Config Class Initialized
INFO - 2018-05-19 00:31:12 --> Hooks Class Initialized
DEBUG - 2018-05-19 00:31:12 --> UTF-8 Support Enabled
INFO - 2018-05-19 00:31:12 --> Utf8 Class Initialized
INFO - 2018-05-19 00:31:12 --> URI Class Initialized
INFO - 2018-05-19 00:31:12 --> Router Class Initialized
INFO - 2018-05-19 00:31:12 --> Output Class Initialized
INFO - 2018-05-19 00:31:12 --> Security Class Initialized
DEBUG - 2018-05-19 00:31:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 00:31:12 --> Input Class Initialized
INFO - 2018-05-19 00:31:12 --> Language Class Initialized
ERROR - 2018-05-19 00:31:12 --> 404 Page Not Found: /index
INFO - 2018-05-19 00:31:12 --> Config Class Initialized
INFO - 2018-05-19 00:31:13 --> Hooks Class Initialized
DEBUG - 2018-05-19 00:31:13 --> UTF-8 Support Enabled
INFO - 2018-05-19 00:31:13 --> Utf8 Class Initialized
INFO - 2018-05-19 00:31:13 --> URI Class Initialized
INFO - 2018-05-19 00:31:13 --> Router Class Initialized
INFO - 2018-05-19 00:31:13 --> Output Class Initialized
INFO - 2018-05-19 00:31:13 --> Security Class Initialized
DEBUG - 2018-05-19 00:31:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 00:31:13 --> Input Class Initialized
INFO - 2018-05-19 00:31:13 --> Language Class Initialized
ERROR - 2018-05-19 00:31:13 --> 404 Page Not Found: /index
INFO - 2018-05-19 00:33:33 --> Config Class Initialized
INFO - 2018-05-19 00:33:33 --> Hooks Class Initialized
DEBUG - 2018-05-19 00:33:33 --> UTF-8 Support Enabled
INFO - 2018-05-19 00:33:33 --> Utf8 Class Initialized
INFO - 2018-05-19 00:33:33 --> URI Class Initialized
INFO - 2018-05-19 00:33:33 --> Router Class Initialized
INFO - 2018-05-19 00:33:33 --> Output Class Initialized
INFO - 2018-05-19 00:33:33 --> Security Class Initialized
DEBUG - 2018-05-19 00:33:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 00:33:33 --> Input Class Initialized
INFO - 2018-05-19 00:33:33 --> Language Class Initialized
ERROR - 2018-05-19 00:33:33 --> 404 Page Not Found: /index
INFO - 2018-05-19 00:33:33 --> Config Class Initialized
INFO - 2018-05-19 00:33:33 --> Hooks Class Initialized
DEBUG - 2018-05-19 00:33:33 --> UTF-8 Support Enabled
INFO - 2018-05-19 00:33:33 --> Utf8 Class Initialized
INFO - 2018-05-19 00:33:33 --> URI Class Initialized
INFO - 2018-05-19 00:33:33 --> Router Class Initialized
INFO - 2018-05-19 00:33:33 --> Output Class Initialized
INFO - 2018-05-19 00:33:33 --> Security Class Initialized
DEBUG - 2018-05-19 00:33:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 00:33:33 --> Input Class Initialized
INFO - 2018-05-19 00:33:33 --> Language Class Initialized
ERROR - 2018-05-19 00:33:33 --> 404 Page Not Found: /index
INFO - 2018-05-19 00:33:33 --> Config Class Initialized
INFO - 2018-05-19 00:33:33 --> Hooks Class Initialized
DEBUG - 2018-05-19 00:33:33 --> UTF-8 Support Enabled
INFO - 2018-05-19 00:33:33 --> Utf8 Class Initialized
INFO - 2018-05-19 00:33:33 --> URI Class Initialized
INFO - 2018-05-19 00:33:34 --> Router Class Initialized
INFO - 2018-05-19 00:33:34 --> Output Class Initialized
INFO - 2018-05-19 00:33:34 --> Security Class Initialized
DEBUG - 2018-05-19 00:33:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 00:33:34 --> Input Class Initialized
INFO - 2018-05-19 00:33:34 --> Language Class Initialized
ERROR - 2018-05-19 00:33:34 --> 404 Page Not Found: /index
INFO - 2018-05-19 00:33:34 --> Config Class Initialized
INFO - 2018-05-19 00:33:34 --> Hooks Class Initialized
DEBUG - 2018-05-19 00:33:34 --> UTF-8 Support Enabled
INFO - 2018-05-19 00:33:34 --> Utf8 Class Initialized
INFO - 2018-05-19 00:33:34 --> URI Class Initialized
INFO - 2018-05-19 00:33:34 --> Router Class Initialized
INFO - 2018-05-19 00:33:34 --> Output Class Initialized
INFO - 2018-05-19 00:33:34 --> Security Class Initialized
DEBUG - 2018-05-19 00:33:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 00:33:34 --> Input Class Initialized
INFO - 2018-05-19 00:33:34 --> Language Class Initialized
ERROR - 2018-05-19 00:33:34 --> 404 Page Not Found: /index
INFO - 2018-05-19 00:34:05 --> Config Class Initialized
INFO - 2018-05-19 00:34:05 --> Hooks Class Initialized
DEBUG - 2018-05-19 00:34:05 --> UTF-8 Support Enabled
INFO - 2018-05-19 00:34:05 --> Utf8 Class Initialized
INFO - 2018-05-19 00:34:05 --> URI Class Initialized
INFO - 2018-05-19 00:34:05 --> Router Class Initialized
INFO - 2018-05-19 00:34:05 --> Output Class Initialized
INFO - 2018-05-19 00:34:05 --> Security Class Initialized
DEBUG - 2018-05-19 00:34:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 00:34:05 --> Input Class Initialized
INFO - 2018-05-19 00:34:05 --> Language Class Initialized
INFO - 2018-05-19 00:34:05 --> Language Class Initialized
INFO - 2018-05-19 00:34:05 --> Config Class Initialized
INFO - 2018-05-19 00:34:05 --> Loader Class Initialized
DEBUG - 2018-05-19 00:34:05 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-19 00:34:05 --> Helper loaded: url_helper
INFO - 2018-05-19 00:34:05 --> Helper loaded: form_helper
INFO - 2018-05-19 00:34:05 --> Helper loaded: date_helper
INFO - 2018-05-19 00:34:05 --> Helper loaded: util_helper
INFO - 2018-05-19 00:34:05 --> Helper loaded: text_helper
INFO - 2018-05-19 00:34:05 --> Helper loaded: string_helper
INFO - 2018-05-19 00:34:05 --> Database Driver Class Initialized
DEBUG - 2018-05-19 00:34:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-19 00:34:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-19 00:34:05 --> Email Class Initialized
INFO - 2018-05-19 00:34:06 --> Controller Class Initialized
DEBUG - 2018-05-19 00:34:06 --> Home MX_Controller Initialized
DEBUG - 2018-05-19 00:34:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-19 00:34:06 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-19 00:34:06 --> Login MX_Controller Initialized
INFO - 2018-05-19 00:34:06 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-19 00:34:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-19 00:34:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-19 00:34:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-19 00:34:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-19 00:34:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-19 00:34:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-19 00:34:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-19 00:34:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/refer_a_friend.php
INFO - 2018-05-19 00:34:06 --> Final output sent to browser
DEBUG - 2018-05-19 00:34:06 --> Total execution time: 0.4100
INFO - 2018-05-19 00:34:06 --> Config Class Initialized
INFO - 2018-05-19 00:34:06 --> Hooks Class Initialized
DEBUG - 2018-05-19 00:34:06 --> UTF-8 Support Enabled
INFO - 2018-05-19 00:34:06 --> Utf8 Class Initialized
INFO - 2018-05-19 00:34:06 --> URI Class Initialized
INFO - 2018-05-19 00:34:06 --> Router Class Initialized
INFO - 2018-05-19 00:34:06 --> Output Class Initialized
INFO - 2018-05-19 00:34:06 --> Security Class Initialized
DEBUG - 2018-05-19 00:34:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 00:34:06 --> Input Class Initialized
INFO - 2018-05-19 00:34:06 --> Language Class Initialized
INFO - 2018-05-19 00:34:06 --> Language Class Initialized
INFO - 2018-05-19 00:34:06 --> Config Class Initialized
INFO - 2018-05-19 00:34:06 --> Loader Class Initialized
DEBUG - 2018-05-19 00:34:06 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-19 00:34:06 --> Config Class Initialized
INFO - 2018-05-19 00:34:06 --> Hooks Class Initialized
INFO - 2018-05-19 00:34:06 --> Helper loaded: url_helper
DEBUG - 2018-05-19 00:34:06 --> UTF-8 Support Enabled
INFO - 2018-05-19 00:34:06 --> Helper loaded: form_helper
INFO - 2018-05-19 00:34:06 --> Utf8 Class Initialized
INFO - 2018-05-19 00:34:06 --> Helper loaded: date_helper
INFO - 2018-05-19 00:34:06 --> Helper loaded: util_helper
INFO - 2018-05-19 00:34:06 --> Helper loaded: text_helper
INFO - 2018-05-19 00:34:06 --> Helper loaded: string_helper
INFO - 2018-05-19 00:34:06 --> Config Class Initialized
INFO - 2018-05-19 00:34:06 --> Hooks Class Initialized
DEBUG - 2018-05-19 00:34:06 --> UTF-8 Support Enabled
INFO - 2018-05-19 00:34:06 --> Database Driver Class Initialized
INFO - 2018-05-19 00:34:06 --> URI Class Initialized
INFO - 2018-05-19 00:34:06 --> Utf8 Class Initialized
INFO - 2018-05-19 00:34:06 --> URI Class Initialized
INFO - 2018-05-19 00:34:06 --> Router Class Initialized
INFO - 2018-05-19 00:34:06 --> Output Class Initialized
INFO - 2018-05-19 00:34:06 --> Security Class Initialized
DEBUG - 2018-05-19 00:34:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 00:34:06 --> Input Class Initialized
INFO - 2018-05-19 00:34:06 --> Router Class Initialized
DEBUG - 2018-05-19 00:34:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-19 00:34:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-19 00:34:06 --> Language Class Initialized
INFO - 2018-05-19 00:34:06 --> Output Class Initialized
INFO - 2018-05-19 00:34:06 --> Security Class Initialized
ERROR - 2018-05-19 00:34:06 --> 404 Page Not Found: /index
INFO - 2018-05-19 00:34:06 --> Email Class Initialized
INFO - 2018-05-19 00:34:06 --> Controller Class Initialized
DEBUG - 2018-05-19 00:34:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 00:34:07 --> Input Class Initialized
ERROR - 2018-05-19 00:34:07 --> 404 Page Not Found: ../modules/home/controllers/Home/js
INFO - 2018-05-19 00:34:07 --> Language Class Initialized
INFO - 2018-05-19 00:34:07 --> Language Class Initialized
INFO - 2018-05-19 00:34:07 --> Config Class Initialized
INFO - 2018-05-19 00:34:07 --> Hooks Class Initialized
INFO - 2018-05-19 00:34:07 --> Config Class Initialized
DEBUG - 2018-05-19 00:34:07 --> UTF-8 Support Enabled
INFO - 2018-05-19 00:34:07 --> Utf8 Class Initialized
INFO - 2018-05-19 00:34:07 --> URI Class Initialized
INFO - 2018-05-19 00:34:07 --> Router Class Initialized
INFO - 2018-05-19 00:34:07 --> Output Class Initialized
INFO - 2018-05-19 00:34:07 --> Security Class Initialized
DEBUG - 2018-05-19 00:34:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 00:34:07 --> Input Class Initialized
INFO - 2018-05-19 00:34:07 --> Language Class Initialized
ERROR - 2018-05-19 00:34:07 --> 404 Page Not Found: /index
INFO - 2018-05-19 00:34:07 --> Loader Class Initialized
DEBUG - 2018-05-19 00:34:07 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-19 00:34:07 --> Helper loaded: url_helper
INFO - 2018-05-19 00:34:07 --> Helper loaded: form_helper
INFO - 2018-05-19 00:34:07 --> Helper loaded: date_helper
INFO - 2018-05-19 00:34:07 --> Helper loaded: util_helper
INFO - 2018-05-19 00:34:07 --> Helper loaded: text_helper
INFO - 2018-05-19 00:34:07 --> Config Class Initialized
INFO - 2018-05-19 00:34:07 --> Hooks Class Initialized
INFO - 2018-05-19 00:34:07 --> Helper loaded: string_helper
DEBUG - 2018-05-19 00:34:07 --> UTF-8 Support Enabled
INFO - 2018-05-19 00:34:07 --> Utf8 Class Initialized
INFO - 2018-05-19 00:34:07 --> URI Class Initialized
INFO - 2018-05-19 00:34:07 --> Router Class Initialized
INFO - 2018-05-19 00:34:07 --> Database Driver Class Initialized
INFO - 2018-05-19 00:34:07 --> Output Class Initialized
INFO - 2018-05-19 00:34:07 --> Security Class Initialized
DEBUG - 2018-05-19 00:34:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 00:34:07 --> Input Class Initialized
DEBUG - 2018-05-19 00:34:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-19 00:34:07 --> Language Class Initialized
INFO - 2018-05-19 00:34:07 --> Session: Class initialized using 'files' driver.
ERROR - 2018-05-19 00:34:07 --> 404 Page Not Found: /index
INFO - 2018-05-19 00:34:07 --> Email Class Initialized
INFO - 2018-05-19 00:34:07 --> Controller Class Initialized
ERROR - 2018-05-19 00:34:07 --> 404 Page Not Found: ../modules/home/controllers/Home/js
INFO - 2018-05-19 00:39:38 --> Config Class Initialized
INFO - 2018-05-19 00:39:38 --> Hooks Class Initialized
DEBUG - 2018-05-19 00:39:38 --> UTF-8 Support Enabled
INFO - 2018-05-19 00:39:38 --> Utf8 Class Initialized
INFO - 2018-05-19 00:39:38 --> URI Class Initialized
INFO - 2018-05-19 00:39:38 --> Router Class Initialized
INFO - 2018-05-19 00:39:38 --> Output Class Initialized
INFO - 2018-05-19 00:39:38 --> Security Class Initialized
DEBUG - 2018-05-19 00:39:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 00:39:38 --> Input Class Initialized
INFO - 2018-05-19 00:39:38 --> Language Class Initialized
INFO - 2018-05-19 00:39:38 --> Language Class Initialized
INFO - 2018-05-19 00:39:38 --> Config Class Initialized
INFO - 2018-05-19 00:39:38 --> Loader Class Initialized
DEBUG - 2018-05-19 00:39:38 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-19 00:39:38 --> Helper loaded: url_helper
INFO - 2018-05-19 00:39:38 --> Helper loaded: form_helper
INFO - 2018-05-19 00:39:38 --> Helper loaded: date_helper
INFO - 2018-05-19 00:39:38 --> Helper loaded: util_helper
INFO - 2018-05-19 00:39:38 --> Helper loaded: text_helper
INFO - 2018-05-19 00:39:38 --> Helper loaded: string_helper
INFO - 2018-05-19 00:39:38 --> Database Driver Class Initialized
DEBUG - 2018-05-19 00:39:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-19 00:39:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-19 00:39:38 --> Email Class Initialized
INFO - 2018-05-19 00:39:38 --> Controller Class Initialized
DEBUG - 2018-05-19 00:39:38 --> Home MX_Controller Initialized
DEBUG - 2018-05-19 00:39:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-19 00:39:38 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-19 00:39:38 --> Login MX_Controller Initialized
INFO - 2018-05-19 00:39:38 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-19 00:39:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-19 00:39:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-19 00:39:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-19 00:39:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-19 00:39:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-19 00:39:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-19 00:39:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-19 00:39:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-05-19 00:39:38 --> Final output sent to browser
DEBUG - 2018-05-19 00:39:38 --> Total execution time: 0.4167
INFO - 2018-05-19 00:39:39 --> Config Class Initialized
INFO - 2018-05-19 00:39:39 --> Hooks Class Initialized
DEBUG - 2018-05-19 00:39:39 --> UTF-8 Support Enabled
INFO - 2018-05-19 00:39:39 --> Utf8 Class Initialized
INFO - 2018-05-19 00:39:39 --> URI Class Initialized
INFO - 2018-05-19 00:39:39 --> Router Class Initialized
INFO - 2018-05-19 00:39:39 --> Output Class Initialized
INFO - 2018-05-19 00:39:39 --> Security Class Initialized
DEBUG - 2018-05-19 00:39:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 00:39:39 --> Input Class Initialized
INFO - 2018-05-19 00:39:39 --> Language Class Initialized
ERROR - 2018-05-19 00:39:39 --> 404 Page Not Found: /index
INFO - 2018-05-19 00:39:39 --> Config Class Initialized
INFO - 2018-05-19 00:39:39 --> Hooks Class Initialized
DEBUG - 2018-05-19 00:39:39 --> UTF-8 Support Enabled
INFO - 2018-05-19 00:39:39 --> Utf8 Class Initialized
INFO - 2018-05-19 00:39:39 --> URI Class Initialized
INFO - 2018-05-19 00:39:39 --> Router Class Initialized
INFO - 2018-05-19 00:39:39 --> Output Class Initialized
INFO - 2018-05-19 00:39:39 --> Security Class Initialized
DEBUG - 2018-05-19 00:39:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 00:39:39 --> Input Class Initialized
INFO - 2018-05-19 00:39:39 --> Language Class Initialized
ERROR - 2018-05-19 00:39:39 --> 404 Page Not Found: /index
INFO - 2018-05-19 00:39:39 --> Config Class Initialized
INFO - 2018-05-19 00:39:39 --> Hooks Class Initialized
DEBUG - 2018-05-19 00:39:39 --> UTF-8 Support Enabled
INFO - 2018-05-19 00:39:39 --> Utf8 Class Initialized
INFO - 2018-05-19 00:39:39 --> URI Class Initialized
INFO - 2018-05-19 00:39:39 --> Router Class Initialized
INFO - 2018-05-19 00:39:39 --> Output Class Initialized
INFO - 2018-05-19 00:39:39 --> Security Class Initialized
DEBUG - 2018-05-19 00:39:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 00:39:39 --> Input Class Initialized
INFO - 2018-05-19 00:39:39 --> Language Class Initialized
ERROR - 2018-05-19 00:39:39 --> 404 Page Not Found: /index
INFO - 2018-05-19 00:39:40 --> Config Class Initialized
INFO - 2018-05-19 00:39:40 --> Hooks Class Initialized
DEBUG - 2018-05-19 00:39:40 --> UTF-8 Support Enabled
INFO - 2018-05-19 00:39:40 --> Utf8 Class Initialized
INFO - 2018-05-19 00:39:40 --> URI Class Initialized
INFO - 2018-05-19 00:39:41 --> Router Class Initialized
INFO - 2018-05-19 00:39:41 --> Output Class Initialized
INFO - 2018-05-19 00:39:41 --> Security Class Initialized
DEBUG - 2018-05-19 00:39:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 00:39:41 --> Input Class Initialized
INFO - 2018-05-19 00:39:41 --> Language Class Initialized
INFO - 2018-05-19 00:39:41 --> Language Class Initialized
INFO - 2018-05-19 00:39:41 --> Config Class Initialized
INFO - 2018-05-19 00:39:41 --> Loader Class Initialized
DEBUG - 2018-05-19 00:39:41 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-19 00:39:41 --> Helper loaded: url_helper
INFO - 2018-05-19 00:39:41 --> Helper loaded: form_helper
INFO - 2018-05-19 00:39:41 --> Helper loaded: date_helper
INFO - 2018-05-19 00:39:41 --> Helper loaded: util_helper
INFO - 2018-05-19 00:39:41 --> Helper loaded: text_helper
INFO - 2018-05-19 00:39:41 --> Helper loaded: string_helper
INFO - 2018-05-19 00:39:41 --> Database Driver Class Initialized
DEBUG - 2018-05-19 00:39:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-19 00:39:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-19 00:39:41 --> Email Class Initialized
INFO - 2018-05-19 00:39:41 --> Controller Class Initialized
DEBUG - 2018-05-19 00:39:41 --> Home MX_Controller Initialized
DEBUG - 2018-05-19 00:39:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-19 00:39:41 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-19 00:39:41 --> Login MX_Controller Initialized
INFO - 2018-05-19 00:39:41 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-19 00:39:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-19 00:39:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-19 00:39:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-19 00:39:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-19 00:39:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-19 00:39:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-19 00:39:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-19 00:39:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/progress.php
INFO - 2018-05-19 00:39:41 --> Final output sent to browser
DEBUG - 2018-05-19 00:39:41 --> Total execution time: 0.4728
INFO - 2018-05-19 00:39:41 --> Config Class Initialized
INFO - 2018-05-19 00:39:41 --> Hooks Class Initialized
DEBUG - 2018-05-19 00:39:41 --> UTF-8 Support Enabled
INFO - 2018-05-19 00:39:41 --> Utf8 Class Initialized
INFO - 2018-05-19 00:39:41 --> URI Class Initialized
INFO - 2018-05-19 00:39:41 --> Router Class Initialized
INFO - 2018-05-19 00:39:41 --> Output Class Initialized
INFO - 2018-05-19 00:39:41 --> Security Class Initialized
DEBUG - 2018-05-19 00:39:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 00:39:41 --> Input Class Initialized
INFO - 2018-05-19 00:39:41 --> Language Class Initialized
ERROR - 2018-05-19 00:39:42 --> 404 Page Not Found: /index
INFO - 2018-05-19 00:39:42 --> Config Class Initialized
INFO - 2018-05-19 00:39:42 --> Hooks Class Initialized
DEBUG - 2018-05-19 00:39:42 --> UTF-8 Support Enabled
INFO - 2018-05-19 00:39:42 --> Utf8 Class Initialized
INFO - 2018-05-19 00:39:42 --> URI Class Initialized
INFO - 2018-05-19 00:39:42 --> Router Class Initialized
INFO - 2018-05-19 00:39:42 --> Output Class Initialized
INFO - 2018-05-19 00:39:42 --> Security Class Initialized
DEBUG - 2018-05-19 00:39:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 00:39:42 --> Input Class Initialized
INFO - 2018-05-19 00:39:42 --> Language Class Initialized
ERROR - 2018-05-19 00:39:42 --> 404 Page Not Found: /index
INFO - 2018-05-19 00:39:42 --> Config Class Initialized
INFO - 2018-05-19 00:39:42 --> Hooks Class Initialized
DEBUG - 2018-05-19 00:39:42 --> UTF-8 Support Enabled
INFO - 2018-05-19 00:39:42 --> Utf8 Class Initialized
INFO - 2018-05-19 00:39:42 --> URI Class Initialized
INFO - 2018-05-19 00:39:42 --> Router Class Initialized
INFO - 2018-05-19 00:39:42 --> Output Class Initialized
INFO - 2018-05-19 00:39:42 --> Security Class Initialized
DEBUG - 2018-05-19 00:39:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 00:39:42 --> Input Class Initialized
INFO - 2018-05-19 00:39:42 --> Language Class Initialized
ERROR - 2018-05-19 00:39:42 --> 404 Page Not Found: /index
INFO - 2018-05-19 00:40:13 --> Config Class Initialized
INFO - 2018-05-19 00:40:13 --> Hooks Class Initialized
DEBUG - 2018-05-19 00:40:13 --> UTF-8 Support Enabled
INFO - 2018-05-19 00:40:13 --> Utf8 Class Initialized
INFO - 2018-05-19 00:40:13 --> URI Class Initialized
INFO - 2018-05-19 00:40:13 --> Router Class Initialized
INFO - 2018-05-19 00:40:13 --> Output Class Initialized
INFO - 2018-05-19 00:40:13 --> Security Class Initialized
DEBUG - 2018-05-19 00:40:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 00:40:13 --> Input Class Initialized
INFO - 2018-05-19 00:40:13 --> Language Class Initialized
INFO - 2018-05-19 00:40:13 --> Language Class Initialized
INFO - 2018-05-19 00:40:13 --> Config Class Initialized
INFO - 2018-05-19 00:40:13 --> Loader Class Initialized
DEBUG - 2018-05-19 00:40:13 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-19 00:40:13 --> Helper loaded: url_helper
INFO - 2018-05-19 00:40:13 --> Helper loaded: form_helper
INFO - 2018-05-19 00:40:13 --> Helper loaded: date_helper
INFO - 2018-05-19 00:40:13 --> Helper loaded: util_helper
INFO - 2018-05-19 00:40:13 --> Helper loaded: text_helper
INFO - 2018-05-19 00:40:13 --> Helper loaded: string_helper
INFO - 2018-05-19 00:40:13 --> Database Driver Class Initialized
DEBUG - 2018-05-19 00:40:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-19 00:40:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-19 00:40:13 --> Email Class Initialized
INFO - 2018-05-19 00:40:13 --> Controller Class Initialized
DEBUG - 2018-05-19 00:40:13 --> Profile MX_Controller Initialized
DEBUG - 2018-05-19 00:40:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-19 00:40:13 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-19 00:40:13 --> Login MX_Controller Initialized
INFO - 2018-05-19 00:40:13 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-19 00:40:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-19 00:40:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-19 00:40:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-19 00:40:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-19 00:40:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-19 00:40:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/profile_left_nav.php
DEBUG - 2018-05-19 00:40:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-19 00:40:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-19 00:40:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/profile.php
INFO - 2018-05-19 00:40:13 --> Final output sent to browser
DEBUG - 2018-05-19 00:40:13 --> Total execution time: 0.4020
INFO - 2018-05-19 00:40:14 --> Config Class Initialized
INFO - 2018-05-19 00:40:14 --> Hooks Class Initialized
DEBUG - 2018-05-19 00:40:14 --> UTF-8 Support Enabled
INFO - 2018-05-19 00:40:14 --> Utf8 Class Initialized
INFO - 2018-05-19 00:40:14 --> URI Class Initialized
INFO - 2018-05-19 00:40:14 --> Config Class Initialized
INFO - 2018-05-19 00:40:14 --> Hooks Class Initialized
INFO - 2018-05-19 00:40:14 --> Router Class Initialized
DEBUG - 2018-05-19 00:40:14 --> UTF-8 Support Enabled
INFO - 2018-05-19 00:40:14 --> Utf8 Class Initialized
INFO - 2018-05-19 00:40:14 --> URI Class Initialized
INFO - 2018-05-19 00:40:14 --> Router Class Initialized
INFO - 2018-05-19 00:40:14 --> Output Class Initialized
INFO - 2018-05-19 00:40:14 --> Security Class Initialized
DEBUG - 2018-05-19 00:40:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 00:40:14 --> Input Class Initialized
INFO - 2018-05-19 00:40:14 --> Output Class Initialized
INFO - 2018-05-19 00:40:14 --> Language Class Initialized
INFO - 2018-05-19 00:40:14 --> Security Class Initialized
ERROR - 2018-05-19 00:40:14 --> 404 Page Not Found: /index
DEBUG - 2018-05-19 00:40:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 00:40:14 --> Input Class Initialized
INFO - 2018-05-19 00:40:14 --> Language Class Initialized
ERROR - 2018-05-19 00:40:14 --> 404 Page Not Found: /index
INFO - 2018-05-19 00:40:14 --> Config Class Initialized
INFO - 2018-05-19 00:40:14 --> Hooks Class Initialized
DEBUG - 2018-05-19 00:40:14 --> UTF-8 Support Enabled
INFO - 2018-05-19 00:40:14 --> Utf8 Class Initialized
INFO - 2018-05-19 00:40:14 --> URI Class Initialized
INFO - 2018-05-19 00:40:14 --> Router Class Initialized
INFO - 2018-05-19 00:40:14 --> Output Class Initialized
INFO - 2018-05-19 00:40:14 --> Security Class Initialized
DEBUG - 2018-05-19 00:40:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 00:40:14 --> Input Class Initialized
INFO - 2018-05-19 00:40:14 --> Language Class Initialized
ERROR - 2018-05-19 00:40:14 --> 404 Page Not Found: /index
INFO - 2018-05-19 00:40:14 --> Config Class Initialized
INFO - 2018-05-19 00:40:14 --> Hooks Class Initialized
DEBUG - 2018-05-19 00:40:14 --> UTF-8 Support Enabled
INFO - 2018-05-19 00:40:14 --> Utf8 Class Initialized
INFO - 2018-05-19 00:40:14 --> URI Class Initialized
INFO - 2018-05-19 00:40:14 --> Router Class Initialized
INFO - 2018-05-19 00:40:14 --> Output Class Initialized
INFO - 2018-05-19 00:40:14 --> Security Class Initialized
DEBUG - 2018-05-19 00:40:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 00:40:15 --> Input Class Initialized
INFO - 2018-05-19 00:40:15 --> Language Class Initialized
ERROR - 2018-05-19 00:40:15 --> 404 Page Not Found: /index
INFO - 2018-05-19 00:41:26 --> Config Class Initialized
INFO - 2018-05-19 00:41:26 --> Hooks Class Initialized
DEBUG - 2018-05-19 00:41:26 --> UTF-8 Support Enabled
INFO - 2018-05-19 00:41:26 --> Utf8 Class Initialized
INFO - 2018-05-19 00:41:26 --> URI Class Initialized
INFO - 2018-05-19 00:41:26 --> Router Class Initialized
INFO - 2018-05-19 00:41:26 --> Output Class Initialized
INFO - 2018-05-19 00:41:26 --> Security Class Initialized
DEBUG - 2018-05-19 00:41:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 00:41:26 --> Input Class Initialized
INFO - 2018-05-19 00:41:26 --> Language Class Initialized
INFO - 2018-05-19 00:41:26 --> Language Class Initialized
INFO - 2018-05-19 00:41:26 --> Config Class Initialized
INFO - 2018-05-19 00:41:26 --> Loader Class Initialized
DEBUG - 2018-05-19 00:41:26 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-19 00:41:26 --> Helper loaded: url_helper
INFO - 2018-05-19 00:41:26 --> Helper loaded: form_helper
INFO - 2018-05-19 00:41:26 --> Helper loaded: date_helper
INFO - 2018-05-19 00:41:26 --> Helper loaded: util_helper
INFO - 2018-05-19 00:41:26 --> Helper loaded: text_helper
INFO - 2018-05-19 00:41:26 --> Helper loaded: string_helper
INFO - 2018-05-19 00:41:26 --> Database Driver Class Initialized
DEBUG - 2018-05-19 00:41:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-19 00:41:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-19 00:41:26 --> Email Class Initialized
INFO - 2018-05-19 00:41:26 --> Controller Class Initialized
DEBUG - 2018-05-19 00:41:26 --> Profile MX_Controller Initialized
DEBUG - 2018-05-19 00:41:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-19 00:41:26 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-19 00:41:26 --> Login MX_Controller Initialized
INFO - 2018-05-19 00:41:26 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-19 00:41:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-19 00:41:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-19 00:41:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-19 00:41:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-19 00:41:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-19 00:41:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/profile_left_nav.php
DEBUG - 2018-05-19 00:41:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-19 00:41:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-19 00:41:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/profile.php
INFO - 2018-05-19 00:41:26 --> Final output sent to browser
DEBUG - 2018-05-19 00:41:26 --> Total execution time: 0.4234
INFO - 2018-05-19 00:41:27 --> Config Class Initialized
INFO - 2018-05-19 00:41:27 --> Hooks Class Initialized
DEBUG - 2018-05-19 00:41:27 --> UTF-8 Support Enabled
INFO - 2018-05-19 00:41:27 --> Utf8 Class Initialized
INFO - 2018-05-19 00:41:27 --> URI Class Initialized
INFO - 2018-05-19 00:41:27 --> Router Class Initialized
INFO - 2018-05-19 00:41:27 --> Config Class Initialized
INFO - 2018-05-19 00:41:27 --> Hooks Class Initialized
INFO - 2018-05-19 00:41:27 --> Output Class Initialized
DEBUG - 2018-05-19 00:41:27 --> UTF-8 Support Enabled
INFO - 2018-05-19 00:41:27 --> Utf8 Class Initialized
INFO - 2018-05-19 00:41:27 --> Security Class Initialized
INFO - 2018-05-19 00:41:27 --> URI Class Initialized
DEBUG - 2018-05-19 00:41:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 00:41:27 --> Router Class Initialized
INFO - 2018-05-19 00:41:27 --> Input Class Initialized
INFO - 2018-05-19 00:41:27 --> Language Class Initialized
INFO - 2018-05-19 00:41:27 --> Output Class Initialized
ERROR - 2018-05-19 00:41:27 --> 404 Page Not Found: /index
INFO - 2018-05-19 00:41:27 --> Security Class Initialized
DEBUG - 2018-05-19 00:41:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 00:41:27 --> Input Class Initialized
INFO - 2018-05-19 00:41:27 --> Language Class Initialized
ERROR - 2018-05-19 00:41:27 --> 404 Page Not Found: /index
INFO - 2018-05-19 00:41:27 --> Config Class Initialized
INFO - 2018-05-19 00:41:27 --> Hooks Class Initialized
DEBUG - 2018-05-19 00:41:27 --> UTF-8 Support Enabled
INFO - 2018-05-19 00:41:27 --> Utf8 Class Initialized
INFO - 2018-05-19 00:41:27 --> URI Class Initialized
INFO - 2018-05-19 00:41:27 --> Router Class Initialized
INFO - 2018-05-19 00:41:27 --> Output Class Initialized
INFO - 2018-05-19 00:41:27 --> Security Class Initialized
DEBUG - 2018-05-19 00:41:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 00:41:27 --> Input Class Initialized
INFO - 2018-05-19 00:41:27 --> Language Class Initialized
ERROR - 2018-05-19 00:41:27 --> 404 Page Not Found: /index
INFO - 2018-05-19 00:41:28 --> Config Class Initialized
INFO - 2018-05-19 00:41:28 --> Hooks Class Initialized
DEBUG - 2018-05-19 00:41:28 --> UTF-8 Support Enabled
INFO - 2018-05-19 00:41:28 --> Utf8 Class Initialized
INFO - 2018-05-19 00:41:28 --> URI Class Initialized
INFO - 2018-05-19 00:41:28 --> Router Class Initialized
INFO - 2018-05-19 00:41:28 --> Output Class Initialized
INFO - 2018-05-19 00:41:28 --> Security Class Initialized
DEBUG - 2018-05-19 00:41:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 00:41:28 --> Input Class Initialized
INFO - 2018-05-19 00:41:28 --> Language Class Initialized
ERROR - 2018-05-19 00:41:28 --> 404 Page Not Found: /index
INFO - 2018-05-19 00:41:29 --> Config Class Initialized
INFO - 2018-05-19 00:41:29 --> Hooks Class Initialized
DEBUG - 2018-05-19 00:41:29 --> UTF-8 Support Enabled
INFO - 2018-05-19 00:41:29 --> Utf8 Class Initialized
INFO - 2018-05-19 00:41:29 --> URI Class Initialized
INFO - 2018-05-19 00:41:29 --> Router Class Initialized
INFO - 2018-05-19 00:41:29 --> Output Class Initialized
INFO - 2018-05-19 00:41:29 --> Security Class Initialized
DEBUG - 2018-05-19 00:41:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 00:41:29 --> Input Class Initialized
INFO - 2018-05-19 00:41:29 --> Language Class Initialized
ERROR - 2018-05-19 00:41:29 --> 404 Page Not Found: /index
INFO - 2018-05-19 00:41:29 --> Config Class Initialized
INFO - 2018-05-19 00:41:29 --> Hooks Class Initialized
DEBUG - 2018-05-19 00:41:29 --> UTF-8 Support Enabled
INFO - 2018-05-19 00:41:29 --> Utf8 Class Initialized
INFO - 2018-05-19 00:41:29 --> URI Class Initialized
INFO - 2018-05-19 00:41:29 --> Router Class Initialized
INFO - 2018-05-19 00:41:29 --> Output Class Initialized
INFO - 2018-05-19 00:41:29 --> Security Class Initialized
DEBUG - 2018-05-19 00:41:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 00:41:29 --> Input Class Initialized
INFO - 2018-05-19 00:41:29 --> Language Class Initialized
ERROR - 2018-05-19 00:41:29 --> 404 Page Not Found: /index
INFO - 2018-05-19 00:41:29 --> Config Class Initialized
INFO - 2018-05-19 00:41:29 --> Hooks Class Initialized
DEBUG - 2018-05-19 00:41:29 --> UTF-8 Support Enabled
INFO - 2018-05-19 00:41:29 --> Utf8 Class Initialized
INFO - 2018-05-19 00:41:29 --> URI Class Initialized
INFO - 2018-05-19 00:41:29 --> Router Class Initialized
INFO - 2018-05-19 00:41:29 --> Output Class Initialized
INFO - 2018-05-19 00:41:29 --> Security Class Initialized
DEBUG - 2018-05-19 00:41:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 00:41:29 --> Input Class Initialized
INFO - 2018-05-19 00:41:29 --> Language Class Initialized
ERROR - 2018-05-19 00:41:29 --> 404 Page Not Found: /index
INFO - 2018-05-19 00:41:30 --> Config Class Initialized
INFO - 2018-05-19 00:41:30 --> Hooks Class Initialized
DEBUG - 2018-05-19 00:41:30 --> UTF-8 Support Enabled
INFO - 2018-05-19 00:41:30 --> Utf8 Class Initialized
INFO - 2018-05-19 00:41:30 --> URI Class Initialized
INFO - 2018-05-19 00:41:30 --> Router Class Initialized
INFO - 2018-05-19 00:41:30 --> Output Class Initialized
INFO - 2018-05-19 00:41:30 --> Security Class Initialized
DEBUG - 2018-05-19 00:41:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 00:41:30 --> Input Class Initialized
INFO - 2018-05-19 00:41:30 --> Language Class Initialized
INFO - 2018-05-19 00:41:30 --> Language Class Initialized
INFO - 2018-05-19 00:41:30 --> Config Class Initialized
INFO - 2018-05-19 00:41:30 --> Loader Class Initialized
DEBUG - 2018-05-19 00:41:30 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-19 00:41:30 --> Helper loaded: url_helper
INFO - 2018-05-19 00:41:30 --> Helper loaded: form_helper
INFO - 2018-05-19 00:41:30 --> Helper loaded: date_helper
INFO - 2018-05-19 00:41:30 --> Helper loaded: util_helper
INFO - 2018-05-19 00:41:30 --> Helper loaded: text_helper
INFO - 2018-05-19 00:41:30 --> Helper loaded: string_helper
INFO - 2018-05-19 00:41:30 --> Database Driver Class Initialized
DEBUG - 2018-05-19 00:41:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-19 00:41:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-19 00:41:30 --> Email Class Initialized
INFO - 2018-05-19 00:41:30 --> Controller Class Initialized
DEBUG - 2018-05-19 00:41:30 --> Login MX_Controller Initialized
INFO - 2018-05-19 00:41:30 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-19 00:41:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-19 00:41:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-19 00:41:30 --> 4 Loggedout
INFO - 2018-05-19 00:41:30 --> Config Class Initialized
INFO - 2018-05-19 00:41:30 --> Hooks Class Initialized
DEBUG - 2018-05-19 00:41:30 --> UTF-8 Support Enabled
INFO - 2018-05-19 00:41:31 --> Utf8 Class Initialized
INFO - 2018-05-19 00:41:31 --> URI Class Initialized
INFO - 2018-05-19 00:41:31 --> Router Class Initialized
INFO - 2018-05-19 00:41:31 --> Output Class Initialized
INFO - 2018-05-19 00:41:31 --> Security Class Initialized
DEBUG - 2018-05-19 00:41:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 00:41:31 --> Input Class Initialized
INFO - 2018-05-19 00:41:31 --> Language Class Initialized
INFO - 2018-05-19 00:41:31 --> Language Class Initialized
INFO - 2018-05-19 00:41:31 --> Config Class Initialized
INFO - 2018-05-19 00:41:31 --> Loader Class Initialized
DEBUG - 2018-05-19 00:41:31 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-19 00:41:31 --> Helper loaded: url_helper
INFO - 2018-05-19 00:41:31 --> Helper loaded: form_helper
INFO - 2018-05-19 00:41:31 --> Helper loaded: date_helper
INFO - 2018-05-19 00:41:31 --> Helper loaded: util_helper
INFO - 2018-05-19 00:41:31 --> Helper loaded: text_helper
INFO - 2018-05-19 00:41:31 --> Helper loaded: string_helper
INFO - 2018-05-19 00:41:31 --> Database Driver Class Initialized
DEBUG - 2018-05-19 00:41:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-19 00:41:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-19 00:41:31 --> Email Class Initialized
INFO - 2018-05-19 00:41:31 --> Controller Class Initialized
DEBUG - 2018-05-19 00:41:31 --> Home MX_Controller Initialized
DEBUG - 2018-05-19 00:41:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-19 00:41:31 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-19 00:41:31 --> Login MX_Controller Initialized
INFO - 2018-05-19 00:41:31 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-19 00:41:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-19 00:41:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-19 00:41:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/login.php
INFO - 2018-05-19 00:41:32 --> Config Class Initialized
INFO - 2018-05-19 00:41:32 --> Hooks Class Initialized
DEBUG - 2018-05-19 00:41:32 --> UTF-8 Support Enabled
INFO - 2018-05-19 00:41:32 --> Utf8 Class Initialized
INFO - 2018-05-19 00:41:32 --> URI Class Initialized
INFO - 2018-05-19 00:41:32 --> Router Class Initialized
INFO - 2018-05-19 00:41:32 --> Output Class Initialized
INFO - 2018-05-19 00:41:32 --> Security Class Initialized
DEBUG - 2018-05-19 00:41:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 00:41:33 --> Input Class Initialized
INFO - 2018-05-19 00:41:33 --> Language Class Initialized
INFO - 2018-05-19 00:41:33 --> Language Class Initialized
INFO - 2018-05-19 00:41:33 --> Config Class Initialized
INFO - 2018-05-19 00:41:33 --> Loader Class Initialized
DEBUG - 2018-05-19 00:41:33 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-19 00:41:33 --> Helper loaded: url_helper
INFO - 2018-05-19 00:41:33 --> Helper loaded: form_helper
INFO - 2018-05-19 00:41:33 --> Helper loaded: date_helper
INFO - 2018-05-19 00:41:33 --> Helper loaded: util_helper
INFO - 2018-05-19 00:41:33 --> Helper loaded: text_helper
INFO - 2018-05-19 00:41:33 --> Helper loaded: string_helper
INFO - 2018-05-19 00:41:33 --> Database Driver Class Initialized
DEBUG - 2018-05-19 00:41:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-19 00:41:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-19 00:41:33 --> Email Class Initialized
INFO - 2018-05-19 00:41:33 --> Controller Class Initialized
DEBUG - 2018-05-19 00:41:33 --> Home MX_Controller Initialized
DEBUG - 2018-05-19 00:41:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-19 00:41:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/register.php
INFO - 2018-05-19 00:41:33 --> Final output sent to browser
DEBUG - 2018-05-19 00:41:33 --> Total execution time: 0.3197
INFO - 2018-05-19 00:41:45 --> Config Class Initialized
INFO - 2018-05-19 00:41:45 --> Hooks Class Initialized
DEBUG - 2018-05-19 00:41:45 --> UTF-8 Support Enabled
INFO - 2018-05-19 00:41:45 --> Utf8 Class Initialized
INFO - 2018-05-19 00:41:45 --> URI Class Initialized
INFO - 2018-05-19 00:41:45 --> Router Class Initialized
INFO - 2018-05-19 00:41:45 --> Output Class Initialized
INFO - 2018-05-19 00:41:45 --> Security Class Initialized
DEBUG - 2018-05-19 00:41:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 00:41:45 --> Input Class Initialized
INFO - 2018-05-19 00:41:45 --> Language Class Initialized
INFO - 2018-05-19 00:41:45 --> Language Class Initialized
INFO - 2018-05-19 00:41:45 --> Config Class Initialized
INFO - 2018-05-19 00:41:45 --> Loader Class Initialized
DEBUG - 2018-05-19 00:41:45 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-19 00:41:45 --> Helper loaded: url_helper
INFO - 2018-05-19 00:41:45 --> Helper loaded: form_helper
INFO - 2018-05-19 00:41:45 --> Helper loaded: date_helper
INFO - 2018-05-19 00:41:45 --> Helper loaded: util_helper
INFO - 2018-05-19 00:41:45 --> Helper loaded: text_helper
INFO - 2018-05-19 00:41:45 --> Helper loaded: string_helper
INFO - 2018-05-19 00:41:45 --> Database Driver Class Initialized
DEBUG - 2018-05-19 00:41:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-19 00:41:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-19 00:41:45 --> Email Class Initialized
INFO - 2018-05-19 00:41:45 --> Controller Class Initialized
DEBUG - 2018-05-19 00:41:45 --> Home MX_Controller Initialized
DEBUG - 2018-05-19 00:41:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-19 00:41:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/register.php
INFO - 2018-05-19 00:41:45 --> Final output sent to browser
DEBUG - 2018-05-19 00:41:45 --> Total execution time: 0.3137
INFO - 2018-05-19 00:41:56 --> Config Class Initialized
INFO - 2018-05-19 00:41:56 --> Hooks Class Initialized
DEBUG - 2018-05-19 00:41:56 --> UTF-8 Support Enabled
INFO - 2018-05-19 00:41:56 --> Utf8 Class Initialized
INFO - 2018-05-19 00:41:56 --> URI Class Initialized
INFO - 2018-05-19 00:41:56 --> Router Class Initialized
INFO - 2018-05-19 00:41:56 --> Output Class Initialized
INFO - 2018-05-19 00:41:56 --> Security Class Initialized
DEBUG - 2018-05-19 00:41:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 00:41:56 --> Input Class Initialized
INFO - 2018-05-19 00:41:56 --> Language Class Initialized
INFO - 2018-05-19 00:41:56 --> Language Class Initialized
INFO - 2018-05-19 00:41:56 --> Config Class Initialized
INFO - 2018-05-19 00:41:56 --> Loader Class Initialized
DEBUG - 2018-05-19 00:41:56 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-19 00:41:56 --> Helper loaded: url_helper
INFO - 2018-05-19 00:41:56 --> Helper loaded: form_helper
INFO - 2018-05-19 00:41:56 --> Helper loaded: date_helper
INFO - 2018-05-19 00:41:56 --> Helper loaded: util_helper
INFO - 2018-05-19 00:41:56 --> Helper loaded: text_helper
INFO - 2018-05-19 00:41:56 --> Helper loaded: string_helper
INFO - 2018-05-19 00:41:56 --> Database Driver Class Initialized
DEBUG - 2018-05-19 00:41:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-19 00:41:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-19 00:41:56 --> Email Class Initialized
INFO - 2018-05-19 00:41:56 --> Controller Class Initialized
DEBUG - 2018-05-19 00:41:56 --> Home MX_Controller Initialized
DEBUG - 2018-05-19 00:41:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-19 00:41:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/register.php
INFO - 2018-05-19 00:41:56 --> Final output sent to browser
DEBUG - 2018-05-19 00:41:56 --> Total execution time: 0.3134
INFO - 2018-05-19 00:42:04 --> Config Class Initialized
INFO - 2018-05-19 00:42:04 --> Hooks Class Initialized
DEBUG - 2018-05-19 00:42:04 --> UTF-8 Support Enabled
INFO - 2018-05-19 00:42:04 --> Utf8 Class Initialized
INFO - 2018-05-19 00:42:04 --> URI Class Initialized
INFO - 2018-05-19 00:42:04 --> Router Class Initialized
INFO - 2018-05-19 00:42:04 --> Output Class Initialized
INFO - 2018-05-19 00:42:04 --> Security Class Initialized
DEBUG - 2018-05-19 00:42:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 00:42:04 --> Input Class Initialized
INFO - 2018-05-19 00:42:04 --> Language Class Initialized
INFO - 2018-05-19 00:42:04 --> Language Class Initialized
INFO - 2018-05-19 00:42:04 --> Config Class Initialized
INFO - 2018-05-19 00:42:04 --> Loader Class Initialized
DEBUG - 2018-05-19 00:42:04 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-19 00:42:04 --> Helper loaded: url_helper
INFO - 2018-05-19 00:42:04 --> Helper loaded: form_helper
INFO - 2018-05-19 00:42:04 --> Helper loaded: date_helper
INFO - 2018-05-19 00:42:04 --> Helper loaded: util_helper
INFO - 2018-05-19 00:42:04 --> Helper loaded: text_helper
INFO - 2018-05-19 00:42:04 --> Helper loaded: string_helper
INFO - 2018-05-19 00:42:04 --> Database Driver Class Initialized
DEBUG - 2018-05-19 00:42:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-19 00:42:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-19 00:42:04 --> Email Class Initialized
INFO - 2018-05-19 00:42:04 --> Controller Class Initialized
DEBUG - 2018-05-19 00:42:04 --> Home MX_Controller Initialized
DEBUG - 2018-05-19 00:42:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-19 00:42:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/register.php
INFO - 2018-05-19 00:42:04 --> Final output sent to browser
DEBUG - 2018-05-19 00:42:04 --> Total execution time: 0.4415
INFO - 2018-05-19 00:42:52 --> Config Class Initialized
INFO - 2018-05-19 00:42:52 --> Hooks Class Initialized
DEBUG - 2018-05-19 00:42:52 --> UTF-8 Support Enabled
INFO - 2018-05-19 00:42:52 --> Utf8 Class Initialized
INFO - 2018-05-19 00:42:52 --> URI Class Initialized
INFO - 2018-05-19 00:42:52 --> Router Class Initialized
INFO - 2018-05-19 00:42:52 --> Output Class Initialized
INFO - 2018-05-19 00:42:52 --> Security Class Initialized
DEBUG - 2018-05-19 00:42:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 00:42:52 --> Input Class Initialized
INFO - 2018-05-19 00:42:52 --> Language Class Initialized
INFO - 2018-05-19 00:42:52 --> Language Class Initialized
INFO - 2018-05-19 00:42:52 --> Config Class Initialized
INFO - 2018-05-19 00:42:52 --> Loader Class Initialized
DEBUG - 2018-05-19 00:42:52 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-19 00:42:52 --> Helper loaded: url_helper
INFO - 2018-05-19 00:42:52 --> Helper loaded: form_helper
INFO - 2018-05-19 00:42:52 --> Helper loaded: date_helper
INFO - 2018-05-19 00:42:52 --> Helper loaded: util_helper
INFO - 2018-05-19 00:42:52 --> Helper loaded: text_helper
INFO - 2018-05-19 00:42:52 --> Helper loaded: string_helper
INFO - 2018-05-19 00:42:52 --> Database Driver Class Initialized
DEBUG - 2018-05-19 00:42:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-19 00:42:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-19 00:42:52 --> Email Class Initialized
INFO - 2018-05-19 00:42:52 --> Controller Class Initialized
DEBUG - 2018-05-19 00:42:52 --> Home MX_Controller Initialized
DEBUG - 2018-05-19 00:42:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-19 00:42:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/register.php
INFO - 2018-05-19 00:42:52 --> Final output sent to browser
DEBUG - 2018-05-19 00:42:52 --> Total execution time: 0.3335
INFO - 2018-05-19 02:30:51 --> Config Class Initialized
INFO - 2018-05-19 02:30:51 --> Hooks Class Initialized
DEBUG - 2018-05-19 02:30:51 --> UTF-8 Support Enabled
INFO - 2018-05-19 02:30:51 --> Utf8 Class Initialized
INFO - 2018-05-19 02:30:51 --> URI Class Initialized
INFO - 2018-05-19 02:30:51 --> Router Class Initialized
INFO - 2018-05-19 02:30:51 --> Output Class Initialized
INFO - 2018-05-19 02:30:51 --> Security Class Initialized
DEBUG - 2018-05-19 02:30:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 02:30:51 --> Input Class Initialized
INFO - 2018-05-19 02:30:51 --> Language Class Initialized
INFO - 2018-05-19 02:30:51 --> Language Class Initialized
INFO - 2018-05-19 02:30:51 --> Config Class Initialized
INFO - 2018-05-19 02:30:51 --> Loader Class Initialized
DEBUG - 2018-05-19 02:30:51 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-19 02:30:51 --> Helper loaded: url_helper
INFO - 2018-05-19 02:30:52 --> Helper loaded: form_helper
INFO - 2018-05-19 02:30:52 --> Helper loaded: date_helper
INFO - 2018-05-19 02:30:52 --> Helper loaded: util_helper
INFO - 2018-05-19 02:30:52 --> Helper loaded: text_helper
INFO - 2018-05-19 02:30:52 --> Helper loaded: string_helper
INFO - 2018-05-19 02:30:52 --> Database Driver Class Initialized
DEBUG - 2018-05-19 02:30:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-19 02:30:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-19 02:30:52 --> Email Class Initialized
INFO - 2018-05-19 02:30:52 --> Controller Class Initialized
DEBUG - 2018-05-19 02:30:52 --> Home MX_Controller Initialized
DEBUG - 2018-05-19 02:30:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-19 02:30:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/register.php
INFO - 2018-05-19 02:30:52 --> Final output sent to browser
DEBUG - 2018-05-19 02:30:52 --> Total execution time: 0.3269
INFO - 2018-05-19 03:39:49 --> Config Class Initialized
INFO - 2018-05-19 03:39:49 --> Hooks Class Initialized
DEBUG - 2018-05-19 03:39:49 --> UTF-8 Support Enabled
INFO - 2018-05-19 03:39:49 --> Utf8 Class Initialized
INFO - 2018-05-19 03:39:49 --> URI Class Initialized
INFO - 2018-05-19 03:39:49 --> Router Class Initialized
INFO - 2018-05-19 03:39:50 --> Output Class Initialized
INFO - 2018-05-19 03:39:50 --> Security Class Initialized
DEBUG - 2018-05-19 03:39:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 03:39:50 --> Input Class Initialized
INFO - 2018-05-19 03:39:50 --> Language Class Initialized
INFO - 2018-05-19 03:39:50 --> Language Class Initialized
INFO - 2018-05-19 03:39:50 --> Config Class Initialized
INFO - 2018-05-19 03:39:50 --> Loader Class Initialized
DEBUG - 2018-05-19 03:39:50 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-19 03:39:50 --> Helper loaded: url_helper
INFO - 2018-05-19 03:39:50 --> Helper loaded: form_helper
INFO - 2018-05-19 03:39:50 --> Helper loaded: date_helper
INFO - 2018-05-19 03:39:50 --> Helper loaded: util_helper
INFO - 2018-05-19 03:39:50 --> Helper loaded: text_helper
INFO - 2018-05-19 03:39:50 --> Helper loaded: string_helper
INFO - 2018-05-19 03:39:50 --> Database Driver Class Initialized
DEBUG - 2018-05-19 03:39:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-19 03:39:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-19 03:39:50 --> Email Class Initialized
INFO - 2018-05-19 03:39:50 --> Controller Class Initialized
DEBUG - 2018-05-19 03:39:50 --> Home MX_Controller Initialized
DEBUG - 2018-05-19 03:39:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-19 03:39:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/register.php
INFO - 2018-05-19 03:39:50 --> Final output sent to browser
DEBUG - 2018-05-19 03:39:50 --> Total execution time: 0.3806
INFO - 2018-05-19 03:40:48 --> Config Class Initialized
INFO - 2018-05-19 03:40:48 --> Hooks Class Initialized
DEBUG - 2018-05-19 03:40:48 --> UTF-8 Support Enabled
INFO - 2018-05-19 03:40:48 --> Utf8 Class Initialized
INFO - 2018-05-19 03:40:48 --> URI Class Initialized
INFO - 2018-05-19 03:40:48 --> Router Class Initialized
INFO - 2018-05-19 03:40:48 --> Output Class Initialized
INFO - 2018-05-19 03:40:48 --> Security Class Initialized
DEBUG - 2018-05-19 03:40:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 03:40:48 --> Input Class Initialized
INFO - 2018-05-19 03:40:48 --> Language Class Initialized
INFO - 2018-05-19 03:40:48 --> Language Class Initialized
INFO - 2018-05-19 03:40:48 --> Config Class Initialized
INFO - 2018-05-19 03:40:48 --> Loader Class Initialized
DEBUG - 2018-05-19 03:40:48 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-19 03:40:48 --> Helper loaded: url_helper
INFO - 2018-05-19 03:40:48 --> Helper loaded: form_helper
INFO - 2018-05-19 03:40:49 --> Helper loaded: date_helper
INFO - 2018-05-19 03:40:49 --> Helper loaded: util_helper
INFO - 2018-05-19 03:40:49 --> Helper loaded: text_helper
INFO - 2018-05-19 03:40:49 --> Helper loaded: string_helper
INFO - 2018-05-19 03:40:49 --> Database Driver Class Initialized
DEBUG - 2018-05-19 03:40:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-19 03:40:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-19 03:40:49 --> Email Class Initialized
INFO - 2018-05-19 03:40:49 --> Controller Class Initialized
DEBUG - 2018-05-19 03:40:49 --> Home MX_Controller Initialized
DEBUG - 2018-05-19 03:40:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-19 03:40:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/register.php
INFO - 2018-05-19 03:40:49 --> Final output sent to browser
DEBUG - 2018-05-19 03:40:49 --> Total execution time: 0.3517
INFO - 2018-05-19 03:42:15 --> Config Class Initialized
INFO - 2018-05-19 03:42:15 --> Hooks Class Initialized
DEBUG - 2018-05-19 03:42:15 --> UTF-8 Support Enabled
INFO - 2018-05-19 03:42:15 --> Utf8 Class Initialized
INFO - 2018-05-19 03:42:15 --> URI Class Initialized
INFO - 2018-05-19 03:42:15 --> Router Class Initialized
INFO - 2018-05-19 03:42:15 --> Output Class Initialized
INFO - 2018-05-19 03:42:15 --> Security Class Initialized
DEBUG - 2018-05-19 03:42:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 03:42:15 --> Input Class Initialized
INFO - 2018-05-19 03:42:15 --> Language Class Initialized
INFO - 2018-05-19 03:42:15 --> Language Class Initialized
INFO - 2018-05-19 03:42:15 --> Config Class Initialized
INFO - 2018-05-19 03:42:15 --> Loader Class Initialized
DEBUG - 2018-05-19 03:42:15 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-19 03:42:15 --> Helper loaded: url_helper
INFO - 2018-05-19 03:42:15 --> Helper loaded: form_helper
INFO - 2018-05-19 03:42:15 --> Helper loaded: date_helper
INFO - 2018-05-19 03:42:15 --> Helper loaded: util_helper
INFO - 2018-05-19 03:42:15 --> Helper loaded: text_helper
INFO - 2018-05-19 03:42:15 --> Helper loaded: string_helper
INFO - 2018-05-19 03:42:15 --> Database Driver Class Initialized
DEBUG - 2018-05-19 03:42:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-19 03:42:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-19 03:42:15 --> Email Class Initialized
INFO - 2018-05-19 03:42:15 --> Controller Class Initialized
DEBUG - 2018-05-19 03:42:15 --> Home MX_Controller Initialized
DEBUG - 2018-05-19 03:42:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-19 03:42:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/register.php
INFO - 2018-05-19 03:42:15 --> Final output sent to browser
DEBUG - 2018-05-19 03:42:15 --> Total execution time: 0.3851
INFO - 2018-05-19 03:42:26 --> Config Class Initialized
INFO - 2018-05-19 03:42:26 --> Hooks Class Initialized
DEBUG - 2018-05-19 03:42:26 --> UTF-8 Support Enabled
INFO - 2018-05-19 03:42:26 --> Utf8 Class Initialized
INFO - 2018-05-19 03:42:26 --> URI Class Initialized
INFO - 2018-05-19 03:42:26 --> Router Class Initialized
INFO - 2018-05-19 03:42:26 --> Output Class Initialized
INFO - 2018-05-19 03:42:26 --> Security Class Initialized
DEBUG - 2018-05-19 03:42:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 03:42:26 --> Input Class Initialized
INFO - 2018-05-19 03:42:26 --> Language Class Initialized
INFO - 2018-05-19 03:42:26 --> Language Class Initialized
INFO - 2018-05-19 03:42:26 --> Config Class Initialized
INFO - 2018-05-19 03:42:26 --> Loader Class Initialized
DEBUG - 2018-05-19 03:42:26 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-19 03:42:26 --> Helper loaded: url_helper
INFO - 2018-05-19 03:42:26 --> Helper loaded: form_helper
INFO - 2018-05-19 03:42:26 --> Helper loaded: date_helper
INFO - 2018-05-19 03:42:26 --> Helper loaded: util_helper
INFO - 2018-05-19 03:42:26 --> Helper loaded: text_helper
INFO - 2018-05-19 03:42:26 --> Helper loaded: string_helper
INFO - 2018-05-19 03:42:26 --> Database Driver Class Initialized
DEBUG - 2018-05-19 03:42:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-19 03:42:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-19 03:42:26 --> Email Class Initialized
INFO - 2018-05-19 03:42:26 --> Controller Class Initialized
DEBUG - 2018-05-19 03:42:26 --> Login MX_Controller Initialized
INFO - 2018-05-19 03:42:26 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-19 03:42:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-19 03:42:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-19 04:00:33 --> Config Class Initialized
INFO - 2018-05-19 04:00:33 --> Hooks Class Initialized
DEBUG - 2018-05-19 04:00:33 --> UTF-8 Support Enabled
INFO - 2018-05-19 04:00:33 --> Utf8 Class Initialized
INFO - 2018-05-19 04:00:33 --> URI Class Initialized
INFO - 2018-05-19 04:00:33 --> Router Class Initialized
INFO - 2018-05-19 04:00:33 --> Output Class Initialized
INFO - 2018-05-19 04:00:33 --> Security Class Initialized
DEBUG - 2018-05-19 04:00:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 04:00:33 --> Input Class Initialized
INFO - 2018-05-19 04:00:33 --> Language Class Initialized
INFO - 2018-05-19 04:00:33 --> Language Class Initialized
INFO - 2018-05-19 04:00:33 --> Config Class Initialized
INFO - 2018-05-19 04:00:33 --> Loader Class Initialized
DEBUG - 2018-05-19 04:00:33 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-19 04:00:33 --> Helper loaded: url_helper
INFO - 2018-05-19 04:00:33 --> Helper loaded: form_helper
INFO - 2018-05-19 04:00:33 --> Helper loaded: date_helper
INFO - 2018-05-19 04:00:33 --> Helper loaded: util_helper
INFO - 2018-05-19 04:00:33 --> Helper loaded: text_helper
INFO - 2018-05-19 04:00:33 --> Helper loaded: string_helper
INFO - 2018-05-19 04:00:33 --> Database Driver Class Initialized
DEBUG - 2018-05-19 04:00:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-19 04:00:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-19 04:00:33 --> Email Class Initialized
INFO - 2018-05-19 04:00:33 --> Controller Class Initialized
DEBUG - 2018-05-19 04:00:33 --> Home MX_Controller Initialized
DEBUG - 2018-05-19 04:00:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-19 04:00:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/register.php
INFO - 2018-05-19 04:00:33 --> Final output sent to browser
DEBUG - 2018-05-19 04:00:33 --> Total execution time: 0.3743
INFO - 2018-05-19 04:00:52 --> Config Class Initialized
INFO - 2018-05-19 04:00:52 --> Hooks Class Initialized
DEBUG - 2018-05-19 04:00:52 --> UTF-8 Support Enabled
INFO - 2018-05-19 04:00:52 --> Utf8 Class Initialized
INFO - 2018-05-19 04:00:52 --> URI Class Initialized
INFO - 2018-05-19 04:00:52 --> Router Class Initialized
INFO - 2018-05-19 04:00:52 --> Output Class Initialized
INFO - 2018-05-19 04:00:52 --> Security Class Initialized
DEBUG - 2018-05-19 04:00:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 04:00:52 --> Input Class Initialized
INFO - 2018-05-19 04:00:52 --> Language Class Initialized
INFO - 2018-05-19 04:00:52 --> Language Class Initialized
INFO - 2018-05-19 04:00:52 --> Config Class Initialized
INFO - 2018-05-19 04:00:52 --> Loader Class Initialized
DEBUG - 2018-05-19 04:00:52 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-19 04:00:52 --> Helper loaded: url_helper
INFO - 2018-05-19 04:00:52 --> Helper loaded: form_helper
INFO - 2018-05-19 04:00:52 --> Helper loaded: date_helper
INFO - 2018-05-19 04:00:52 --> Helper loaded: util_helper
INFO - 2018-05-19 04:00:52 --> Helper loaded: text_helper
INFO - 2018-05-19 04:00:52 --> Helper loaded: string_helper
INFO - 2018-05-19 04:00:52 --> Database Driver Class Initialized
DEBUG - 2018-05-19 04:00:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-19 04:00:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-19 04:00:52 --> Email Class Initialized
INFO - 2018-05-19 04:00:52 --> Controller Class Initialized
DEBUG - 2018-05-19 04:00:52 --> Login MX_Controller Initialized
INFO - 2018-05-19 04:00:52 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-19 04:00:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-19 04:00:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
ERROR - 2018-05-19 04:00:52 --> Query error: Column 'name' cannot be null - Invalid query: INSERT INTO `users` (`name`, `username`, `email`, `mobile`, `status`, `password`, `type`, `confcode`) VALUES (NULL, NULL, NULL, NULL, 3, 'd41d8cd98f00b204e9800998ecf8427e', 2, 'v2A30DGmMOtZhbRa')
INFO - 2018-05-19 04:00:52 --> Language file loaded: language/english/db_lang.php
INFO - 2018-05-19 04:01:00 --> Config Class Initialized
INFO - 2018-05-19 04:01:00 --> Hooks Class Initialized
DEBUG - 2018-05-19 04:01:00 --> UTF-8 Support Enabled
INFO - 2018-05-19 04:01:00 --> Utf8 Class Initialized
INFO - 2018-05-19 04:01:00 --> URI Class Initialized
INFO - 2018-05-19 04:01:00 --> Router Class Initialized
INFO - 2018-05-19 04:01:00 --> Output Class Initialized
INFO - 2018-05-19 04:01:00 --> Security Class Initialized
DEBUG - 2018-05-19 04:01:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 04:01:00 --> Input Class Initialized
INFO - 2018-05-19 04:01:00 --> Language Class Initialized
INFO - 2018-05-19 04:01:00 --> Language Class Initialized
INFO - 2018-05-19 04:01:00 --> Config Class Initialized
INFO - 2018-05-19 04:01:00 --> Loader Class Initialized
DEBUG - 2018-05-19 04:01:00 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-19 04:01:00 --> Helper loaded: url_helper
INFO - 2018-05-19 04:01:00 --> Helper loaded: form_helper
INFO - 2018-05-19 04:01:00 --> Helper loaded: date_helper
INFO - 2018-05-19 04:01:00 --> Helper loaded: util_helper
INFO - 2018-05-19 04:01:00 --> Helper loaded: text_helper
INFO - 2018-05-19 04:01:00 --> Helper loaded: string_helper
INFO - 2018-05-19 04:01:00 --> Database Driver Class Initialized
DEBUG - 2018-05-19 04:01:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-19 04:01:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-19 04:01:00 --> Email Class Initialized
INFO - 2018-05-19 04:01:00 --> Controller Class Initialized
DEBUG - 2018-05-19 04:01:00 --> Login MX_Controller Initialized
INFO - 2018-05-19 04:01:00 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-19 04:01:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-19 04:01:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-19 04:05:02 --> Config Class Initialized
INFO - 2018-05-19 04:05:02 --> Hooks Class Initialized
DEBUG - 2018-05-19 04:05:02 --> UTF-8 Support Enabled
INFO - 2018-05-19 04:05:02 --> Utf8 Class Initialized
INFO - 2018-05-19 04:05:02 --> URI Class Initialized
INFO - 2018-05-19 04:05:02 --> Router Class Initialized
INFO - 2018-05-19 04:05:02 --> Output Class Initialized
INFO - 2018-05-19 04:05:02 --> Security Class Initialized
DEBUG - 2018-05-19 04:05:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 04:05:02 --> Input Class Initialized
INFO - 2018-05-19 04:05:02 --> Language Class Initialized
INFO - 2018-05-19 04:05:02 --> Language Class Initialized
INFO - 2018-05-19 04:05:02 --> Config Class Initialized
INFO - 2018-05-19 04:05:02 --> Loader Class Initialized
DEBUG - 2018-05-19 04:05:02 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-19 04:05:02 --> Helper loaded: url_helper
INFO - 2018-05-19 04:05:02 --> Helper loaded: form_helper
INFO - 2018-05-19 04:05:02 --> Helper loaded: date_helper
INFO - 2018-05-19 04:05:02 --> Helper loaded: util_helper
INFO - 2018-05-19 04:05:02 --> Helper loaded: text_helper
INFO - 2018-05-19 04:05:02 --> Helper loaded: string_helper
INFO - 2018-05-19 04:05:03 --> Database Driver Class Initialized
DEBUG - 2018-05-19 04:05:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-19 04:05:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-19 04:05:03 --> Email Class Initialized
INFO - 2018-05-19 04:05:03 --> Controller Class Initialized
DEBUG - 2018-05-19 04:05:03 --> Home MX_Controller Initialized
DEBUG - 2018-05-19 04:05:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-19 04:05:03 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-19 04:05:03 --> Login MX_Controller Initialized
INFO - 2018-05-19 04:05:03 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-19 04:05:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-19 04:05:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-19 04:05:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/login.php
INFO - 2018-05-19 04:16:16 --> Config Class Initialized
INFO - 2018-05-19 04:16:16 --> Hooks Class Initialized
DEBUG - 2018-05-19 04:16:16 --> UTF-8 Support Enabled
INFO - 2018-05-19 04:16:16 --> Utf8 Class Initialized
INFO - 2018-05-19 04:16:16 --> URI Class Initialized
INFO - 2018-05-19 04:16:16 --> Router Class Initialized
INFO - 2018-05-19 04:16:16 --> Output Class Initialized
INFO - 2018-05-19 04:16:16 --> Security Class Initialized
DEBUG - 2018-05-19 04:16:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 04:16:16 --> Input Class Initialized
INFO - 2018-05-19 04:16:16 --> Language Class Initialized
INFO - 2018-05-19 04:16:16 --> Language Class Initialized
INFO - 2018-05-19 04:16:16 --> Config Class Initialized
INFO - 2018-05-19 04:16:16 --> Loader Class Initialized
DEBUG - 2018-05-19 04:16:16 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-19 04:16:16 --> Helper loaded: url_helper
INFO - 2018-05-19 04:16:16 --> Helper loaded: form_helper
INFO - 2018-05-19 04:16:16 --> Helper loaded: date_helper
INFO - 2018-05-19 04:16:16 --> Helper loaded: util_helper
INFO - 2018-05-19 04:16:16 --> Helper loaded: text_helper
INFO - 2018-05-19 04:16:16 --> Helper loaded: string_helper
INFO - 2018-05-19 04:16:16 --> Database Driver Class Initialized
DEBUG - 2018-05-19 04:16:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-19 04:16:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-19 04:16:16 --> Email Class Initialized
INFO - 2018-05-19 04:16:16 --> Controller Class Initialized
DEBUG - 2018-05-19 04:16:16 --> Login MX_Controller Initialized
INFO - 2018-05-19 04:16:16 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-19 04:16:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-19 04:16:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-19 04:16:30 --> Config Class Initialized
INFO - 2018-05-19 04:16:30 --> Hooks Class Initialized
DEBUG - 2018-05-19 04:16:30 --> UTF-8 Support Enabled
INFO - 2018-05-19 04:16:30 --> Utf8 Class Initialized
INFO - 2018-05-19 04:16:30 --> URI Class Initialized
INFO - 2018-05-19 04:16:30 --> Router Class Initialized
INFO - 2018-05-19 04:16:30 --> Output Class Initialized
INFO - 2018-05-19 04:16:30 --> Security Class Initialized
DEBUG - 2018-05-19 04:16:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 04:16:30 --> Input Class Initialized
INFO - 2018-05-19 04:16:30 --> Language Class Initialized
INFO - 2018-05-19 04:16:30 --> Language Class Initialized
INFO - 2018-05-19 04:16:30 --> Config Class Initialized
INFO - 2018-05-19 04:16:30 --> Loader Class Initialized
DEBUG - 2018-05-19 04:16:30 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-19 04:16:30 --> Helper loaded: url_helper
INFO - 2018-05-19 04:16:31 --> Helper loaded: form_helper
INFO - 2018-05-19 04:16:31 --> Helper loaded: date_helper
INFO - 2018-05-19 04:16:31 --> Helper loaded: util_helper
INFO - 2018-05-19 04:16:31 --> Helper loaded: text_helper
INFO - 2018-05-19 04:16:31 --> Helper loaded: string_helper
INFO - 2018-05-19 04:16:31 --> Database Driver Class Initialized
DEBUG - 2018-05-19 04:16:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-19 04:16:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-19 04:16:31 --> Email Class Initialized
INFO - 2018-05-19 04:16:31 --> Controller Class Initialized
DEBUG - 2018-05-19 04:16:31 --> Login MX_Controller Initialized
INFO - 2018-05-19 04:16:31 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-19 04:16:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-19 04:16:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-19 04:24:14 --> Config Class Initialized
INFO - 2018-05-19 04:24:14 --> Hooks Class Initialized
DEBUG - 2018-05-19 04:24:14 --> UTF-8 Support Enabled
INFO - 2018-05-19 04:24:14 --> Utf8 Class Initialized
INFO - 2018-05-19 04:24:15 --> URI Class Initialized
INFO - 2018-05-19 04:24:15 --> Router Class Initialized
INFO - 2018-05-19 04:24:15 --> Output Class Initialized
INFO - 2018-05-19 04:24:15 --> Security Class Initialized
DEBUG - 2018-05-19 04:24:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 04:24:15 --> Input Class Initialized
INFO - 2018-05-19 04:24:15 --> Language Class Initialized
INFO - 2018-05-19 04:24:15 --> Language Class Initialized
INFO - 2018-05-19 04:24:15 --> Config Class Initialized
INFO - 2018-05-19 04:24:15 --> Loader Class Initialized
DEBUG - 2018-05-19 04:24:15 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-19 04:24:15 --> Helper loaded: url_helper
INFO - 2018-05-19 04:24:15 --> Helper loaded: form_helper
INFO - 2018-05-19 04:24:15 --> Helper loaded: date_helper
INFO - 2018-05-19 04:24:15 --> Helper loaded: util_helper
INFO - 2018-05-19 04:24:15 --> Helper loaded: text_helper
INFO - 2018-05-19 04:24:15 --> Helper loaded: string_helper
INFO - 2018-05-19 04:24:15 --> Database Driver Class Initialized
DEBUG - 2018-05-19 04:24:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-19 04:24:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-19 04:24:15 --> Email Class Initialized
INFO - 2018-05-19 04:24:15 --> Controller Class Initialized
DEBUG - 2018-05-19 04:24:15 --> Login MX_Controller Initialized
INFO - 2018-05-19 04:24:15 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-19 04:24:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-19 04:24:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
ERROR - 2018-05-19 04:24:15 --> Severity: Notice --> Undefined variable: name E:\xampp\htdocs\consulting\application\modules\common\views\common\templates\mail_view.php 1
DEBUG - 2018-05-19 04:24:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/templates/mail_view.php
DEBUG - 2018-05-19 04:24:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Mail_model.php
INFO - 2018-05-19 04:24:15 --> Helper loaded: file_helper
INFO - 2018-05-19 04:24:15 --> Login status gopaltestingfsdfsd@yopmail.com Successfully registered
INFO - 2018-05-19 04:24:15 --> Config Class Initialized
INFO - 2018-05-19 04:24:15 --> Hooks Class Initialized
DEBUG - 2018-05-19 04:24:15 --> UTF-8 Support Enabled
INFO - 2018-05-19 04:24:15 --> Utf8 Class Initialized
INFO - 2018-05-19 04:24:15 --> URI Class Initialized
INFO - 2018-05-19 04:24:15 --> Router Class Initialized
INFO - 2018-05-19 04:24:15 --> Output Class Initialized
INFO - 2018-05-19 04:24:15 --> Security Class Initialized
DEBUG - 2018-05-19 04:24:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 04:24:15 --> Input Class Initialized
INFO - 2018-05-19 04:24:15 --> Language Class Initialized
INFO - 2018-05-19 04:24:15 --> Language Class Initialized
INFO - 2018-05-19 04:24:15 --> Config Class Initialized
INFO - 2018-05-19 04:24:15 --> Loader Class Initialized
DEBUG - 2018-05-19 04:24:15 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-19 04:24:15 --> Helper loaded: url_helper
INFO - 2018-05-19 04:24:15 --> Helper loaded: form_helper
INFO - 2018-05-19 04:24:15 --> Helper loaded: date_helper
INFO - 2018-05-19 04:24:15 --> Helper loaded: util_helper
INFO - 2018-05-19 04:24:15 --> Helper loaded: text_helper
INFO - 2018-05-19 04:24:15 --> Helper loaded: string_helper
INFO - 2018-05-19 04:24:15 --> Database Driver Class Initialized
DEBUG - 2018-05-19 04:24:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-19 04:24:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-19 04:24:15 --> Email Class Initialized
INFO - 2018-05-19 04:24:15 --> Controller Class Initialized
DEBUG - 2018-05-19 04:24:15 --> Home MX_Controller Initialized
DEBUG - 2018-05-19 04:24:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-19 04:24:15 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-19 04:24:15 --> Login MX_Controller Initialized
INFO - 2018-05-19 04:24:15 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-19 04:24:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-19 04:24:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-19 04:24:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/login.php
INFO - 2018-05-19 04:24:37 --> Config Class Initialized
INFO - 2018-05-19 04:24:37 --> Hooks Class Initialized
DEBUG - 2018-05-19 04:24:37 --> UTF-8 Support Enabled
INFO - 2018-05-19 04:24:37 --> Utf8 Class Initialized
INFO - 2018-05-19 04:24:37 --> URI Class Initialized
INFO - 2018-05-19 04:24:37 --> Router Class Initialized
INFO - 2018-05-19 04:24:37 --> Output Class Initialized
INFO - 2018-05-19 04:24:37 --> Security Class Initialized
DEBUG - 2018-05-19 04:24:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 04:24:37 --> Input Class Initialized
INFO - 2018-05-19 04:24:37 --> Language Class Initialized
INFO - 2018-05-19 04:24:37 --> Language Class Initialized
INFO - 2018-05-19 04:24:37 --> Config Class Initialized
INFO - 2018-05-19 04:24:37 --> Loader Class Initialized
DEBUG - 2018-05-19 04:24:37 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-19 04:24:37 --> Helper loaded: url_helper
INFO - 2018-05-19 04:24:37 --> Helper loaded: form_helper
INFO - 2018-05-19 04:24:37 --> Helper loaded: date_helper
INFO - 2018-05-19 04:24:37 --> Helper loaded: util_helper
INFO - 2018-05-19 04:24:37 --> Helper loaded: text_helper
INFO - 2018-05-19 04:24:37 --> Helper loaded: string_helper
INFO - 2018-05-19 04:24:37 --> Database Driver Class Initialized
DEBUG - 2018-05-19 04:24:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-19 04:24:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-19 04:24:37 --> Email Class Initialized
INFO - 2018-05-19 04:24:37 --> Controller Class Initialized
DEBUG - 2018-05-19 04:24:37 --> Login MX_Controller Initialized
INFO - 2018-05-19 04:24:37 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-19 04:24:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-19 04:24:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-19 04:24:37 --> Email starts for gopaltestingfsdfsd@yopmail.com fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-05-19 04:24:37 --> Login status gopaltestingfsdfsd@yopmail.com - failure
INFO - 2018-05-19 04:24:37 --> Final output sent to browser
DEBUG - 2018-05-19 04:24:37 --> Total execution time: 0.3334
INFO - 2018-05-19 04:24:40 --> Config Class Initialized
INFO - 2018-05-19 04:24:40 --> Hooks Class Initialized
DEBUG - 2018-05-19 04:24:40 --> UTF-8 Support Enabled
INFO - 2018-05-19 04:24:40 --> Utf8 Class Initialized
INFO - 2018-05-19 04:24:40 --> URI Class Initialized
INFO - 2018-05-19 04:24:40 --> Router Class Initialized
INFO - 2018-05-19 04:24:40 --> Output Class Initialized
INFO - 2018-05-19 04:24:40 --> Security Class Initialized
DEBUG - 2018-05-19 04:24:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 04:24:40 --> Input Class Initialized
INFO - 2018-05-19 04:24:40 --> Language Class Initialized
INFO - 2018-05-19 04:24:40 --> Language Class Initialized
INFO - 2018-05-19 04:24:40 --> Config Class Initialized
INFO - 2018-05-19 04:24:40 --> Loader Class Initialized
DEBUG - 2018-05-19 04:24:40 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-19 04:24:40 --> Helper loaded: url_helper
INFO - 2018-05-19 04:24:40 --> Helper loaded: form_helper
INFO - 2018-05-19 04:24:40 --> Helper loaded: date_helper
INFO - 2018-05-19 04:24:40 --> Helper loaded: util_helper
INFO - 2018-05-19 04:24:40 --> Helper loaded: text_helper
INFO - 2018-05-19 04:24:40 --> Helper loaded: string_helper
INFO - 2018-05-19 04:24:40 --> Database Driver Class Initialized
DEBUG - 2018-05-19 04:24:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-19 04:24:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-19 04:24:40 --> Email Class Initialized
INFO - 2018-05-19 04:24:40 --> Controller Class Initialized
DEBUG - 2018-05-19 04:24:40 --> Login MX_Controller Initialized
INFO - 2018-05-19 04:24:40 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-19 04:24:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-19 04:24:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-19 04:24:40 --> Email starts for gopaltestingfsdfsd@yopmail.com fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-05-19 04:24:41 --> Login status gopaltestingfsdfsd@yopmail.com - failure
INFO - 2018-05-19 04:24:41 --> Final output sent to browser
DEBUG - 2018-05-19 04:24:41 --> Total execution time: 0.3340
INFO - 2018-05-19 04:25:25 --> Config Class Initialized
INFO - 2018-05-19 04:25:25 --> Hooks Class Initialized
DEBUG - 2018-05-19 04:25:25 --> UTF-8 Support Enabled
INFO - 2018-05-19 04:25:25 --> Utf8 Class Initialized
INFO - 2018-05-19 04:25:25 --> URI Class Initialized
INFO - 2018-05-19 04:25:25 --> Router Class Initialized
INFO - 2018-05-19 04:25:25 --> Output Class Initialized
INFO - 2018-05-19 04:25:25 --> Security Class Initialized
DEBUG - 2018-05-19 04:25:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 04:25:25 --> Input Class Initialized
INFO - 2018-05-19 04:25:25 --> Language Class Initialized
INFO - 2018-05-19 04:25:25 --> Language Class Initialized
INFO - 2018-05-19 04:25:25 --> Config Class Initialized
INFO - 2018-05-19 04:25:25 --> Loader Class Initialized
DEBUG - 2018-05-19 04:25:25 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-19 04:25:25 --> Helper loaded: url_helper
INFO - 2018-05-19 04:25:25 --> Helper loaded: form_helper
INFO - 2018-05-19 04:25:25 --> Helper loaded: date_helper
INFO - 2018-05-19 04:25:25 --> Helper loaded: util_helper
INFO - 2018-05-19 04:25:25 --> Helper loaded: text_helper
INFO - 2018-05-19 04:25:25 --> Helper loaded: string_helper
INFO - 2018-05-19 04:25:25 --> Database Driver Class Initialized
DEBUG - 2018-05-19 04:25:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-19 04:25:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-19 04:25:25 --> Email Class Initialized
INFO - 2018-05-19 04:25:25 --> Controller Class Initialized
DEBUG - 2018-05-19 04:25:25 --> Home MX_Controller Initialized
DEBUG - 2018-05-19 04:25:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-19 04:25:25 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-19 04:25:25 --> Login MX_Controller Initialized
INFO - 2018-05-19 04:25:25 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-19 04:25:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-19 04:25:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-19 04:25:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/login.php
INFO - 2018-05-19 04:25:36 --> Config Class Initialized
INFO - 2018-05-19 04:25:36 --> Hooks Class Initialized
DEBUG - 2018-05-19 04:25:36 --> UTF-8 Support Enabled
INFO - 2018-05-19 04:25:36 --> Utf8 Class Initialized
INFO - 2018-05-19 04:25:36 --> URI Class Initialized
INFO - 2018-05-19 04:25:36 --> Router Class Initialized
INFO - 2018-05-19 04:25:36 --> Output Class Initialized
INFO - 2018-05-19 04:25:36 --> Security Class Initialized
DEBUG - 2018-05-19 04:25:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 04:25:36 --> Input Class Initialized
INFO - 2018-05-19 04:25:36 --> Language Class Initialized
INFO - 2018-05-19 04:25:36 --> Language Class Initialized
INFO - 2018-05-19 04:25:36 --> Config Class Initialized
INFO - 2018-05-19 04:25:36 --> Loader Class Initialized
DEBUG - 2018-05-19 04:25:36 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-19 04:25:36 --> Helper loaded: url_helper
INFO - 2018-05-19 04:25:36 --> Helper loaded: form_helper
INFO - 2018-05-19 04:25:36 --> Helper loaded: date_helper
INFO - 2018-05-19 04:25:36 --> Helper loaded: util_helper
INFO - 2018-05-19 04:25:36 --> Helper loaded: text_helper
INFO - 2018-05-19 04:25:36 --> Helper loaded: string_helper
INFO - 2018-05-19 04:25:36 --> Database Driver Class Initialized
DEBUG - 2018-05-19 04:25:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-19 04:25:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-19 04:25:36 --> Email Class Initialized
INFO - 2018-05-19 04:25:36 --> Controller Class Initialized
DEBUG - 2018-05-19 04:25:36 --> Login MX_Controller Initialized
INFO - 2018-05-19 04:25:36 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-19 04:25:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-19 04:25:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-19 04:25:36 --> Email starts for gopaltestingfsdfsd@yopmail.com fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-05-19 04:25:36 --> Login status gopaltestingfsdfsd@yopmail.com - failure
INFO - 2018-05-19 04:25:36 --> Final output sent to browser
DEBUG - 2018-05-19 04:25:36 --> Total execution time: 0.3253
INFO - 2018-05-19 04:26:34 --> Config Class Initialized
INFO - 2018-05-19 04:26:34 --> Hooks Class Initialized
DEBUG - 2018-05-19 04:26:34 --> UTF-8 Support Enabled
INFO - 2018-05-19 04:26:34 --> Utf8 Class Initialized
INFO - 2018-05-19 04:26:34 --> URI Class Initialized
INFO - 2018-05-19 04:26:34 --> Router Class Initialized
INFO - 2018-05-19 04:26:34 --> Output Class Initialized
INFO - 2018-05-19 04:26:34 --> Security Class Initialized
DEBUG - 2018-05-19 04:26:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 04:26:34 --> Input Class Initialized
INFO - 2018-05-19 04:26:34 --> Language Class Initialized
INFO - 2018-05-19 04:26:34 --> Language Class Initialized
INFO - 2018-05-19 04:26:34 --> Config Class Initialized
INFO - 2018-05-19 04:26:34 --> Loader Class Initialized
DEBUG - 2018-05-19 04:26:34 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-19 04:26:34 --> Helper loaded: url_helper
INFO - 2018-05-19 04:26:34 --> Helper loaded: form_helper
INFO - 2018-05-19 04:26:35 --> Helper loaded: date_helper
INFO - 2018-05-19 04:26:35 --> Helper loaded: util_helper
INFO - 2018-05-19 04:26:35 --> Helper loaded: text_helper
INFO - 2018-05-19 04:26:35 --> Helper loaded: string_helper
INFO - 2018-05-19 04:26:35 --> Database Driver Class Initialized
DEBUG - 2018-05-19 04:26:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-19 04:26:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-19 04:26:35 --> Email Class Initialized
INFO - 2018-05-19 04:26:35 --> Controller Class Initialized
DEBUG - 2018-05-19 04:26:35 --> Login MX_Controller Initialized
INFO - 2018-05-19 04:26:35 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-19 04:26:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-19 04:26:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-19 04:26:35 --> Email starts for gopaltestingfsdfsd@yopmail.com fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-05-19 04:26:35 --> User session created for 30
INFO - 2018-05-19 04:26:35 --> Login status gopaltestingfsdfsd@yopmail.com - success
INFO - 2018-05-19 04:26:35 --> Final output sent to browser
DEBUG - 2018-05-19 04:26:35 --> Total execution time: 0.3699
INFO - 2018-05-19 04:26:35 --> Config Class Initialized
INFO - 2018-05-19 04:26:35 --> Hooks Class Initialized
DEBUG - 2018-05-19 04:26:35 --> UTF-8 Support Enabled
INFO - 2018-05-19 04:26:35 --> Utf8 Class Initialized
INFO - 2018-05-19 04:26:35 --> URI Class Initialized
INFO - 2018-05-19 04:26:35 --> Router Class Initialized
INFO - 2018-05-19 04:26:35 --> Output Class Initialized
INFO - 2018-05-19 04:26:35 --> Security Class Initialized
DEBUG - 2018-05-19 04:26:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 04:26:35 --> Input Class Initialized
INFO - 2018-05-19 04:26:35 --> Language Class Initialized
INFO - 2018-05-19 04:26:35 --> Language Class Initialized
INFO - 2018-05-19 04:26:35 --> Config Class Initialized
INFO - 2018-05-19 04:26:35 --> Loader Class Initialized
DEBUG - 2018-05-19 04:26:35 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-19 04:26:35 --> Helper loaded: url_helper
INFO - 2018-05-19 04:26:35 --> Helper loaded: form_helper
INFO - 2018-05-19 04:26:35 --> Helper loaded: date_helper
INFO - 2018-05-19 04:26:35 --> Helper loaded: util_helper
INFO - 2018-05-19 04:26:35 --> Helper loaded: text_helper
INFO - 2018-05-19 04:26:35 --> Helper loaded: string_helper
INFO - 2018-05-19 04:26:35 --> Database Driver Class Initialized
DEBUG - 2018-05-19 04:26:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-19 04:26:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-19 04:26:35 --> Email Class Initialized
INFO - 2018-05-19 04:26:35 --> Controller Class Initialized
DEBUG - 2018-05-19 04:26:35 --> Home MX_Controller Initialized
DEBUG - 2018-05-19 04:26:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-19 04:26:35 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-19 04:26:35 --> Login MX_Controller Initialized
INFO - 2018-05-19 04:26:35 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-19 04:26:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-19 04:26:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-19 04:26:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-19 04:26:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-19 04:26:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-19 04:26:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-19 04:26:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-19 04:26:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-05-19 04:26:35 --> Final output sent to browser
DEBUG - 2018-05-19 04:26:35 --> Total execution time: 0.4893
INFO - 2018-05-19 04:26:36 --> Config Class Initialized
INFO - 2018-05-19 04:26:36 --> Hooks Class Initialized
DEBUG - 2018-05-19 04:26:36 --> UTF-8 Support Enabled
INFO - 2018-05-19 04:26:36 --> Utf8 Class Initialized
INFO - 2018-05-19 04:26:36 --> URI Class Initialized
INFO - 2018-05-19 04:26:36 --> Router Class Initialized
INFO - 2018-05-19 04:26:36 --> Output Class Initialized
INFO - 2018-05-19 04:26:36 --> Security Class Initialized
DEBUG - 2018-05-19 04:26:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 04:26:36 --> Input Class Initialized
INFO - 2018-05-19 04:26:36 --> Language Class Initialized
ERROR - 2018-05-19 04:26:36 --> 404 Page Not Found: /index
INFO - 2018-05-19 04:26:36 --> Config Class Initialized
INFO - 2018-05-19 04:26:36 --> Hooks Class Initialized
DEBUG - 2018-05-19 04:26:37 --> UTF-8 Support Enabled
INFO - 2018-05-19 04:26:37 --> Utf8 Class Initialized
INFO - 2018-05-19 04:26:37 --> URI Class Initialized
INFO - 2018-05-19 04:26:37 --> Router Class Initialized
INFO - 2018-05-19 04:26:37 --> Output Class Initialized
INFO - 2018-05-19 04:26:37 --> Security Class Initialized
DEBUG - 2018-05-19 04:26:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 04:26:37 --> Input Class Initialized
INFO - 2018-05-19 04:26:37 --> Language Class Initialized
ERROR - 2018-05-19 04:26:37 --> 404 Page Not Found: /index
INFO - 2018-05-19 04:26:37 --> Config Class Initialized
INFO - 2018-05-19 04:26:37 --> Hooks Class Initialized
DEBUG - 2018-05-19 04:26:37 --> UTF-8 Support Enabled
INFO - 2018-05-19 04:26:37 --> Utf8 Class Initialized
INFO - 2018-05-19 04:26:37 --> URI Class Initialized
INFO - 2018-05-19 04:26:37 --> Router Class Initialized
INFO - 2018-05-19 04:26:37 --> Output Class Initialized
INFO - 2018-05-19 04:26:37 --> Security Class Initialized
DEBUG - 2018-05-19 04:26:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 04:26:37 --> Input Class Initialized
INFO - 2018-05-19 04:26:37 --> Language Class Initialized
ERROR - 2018-05-19 04:26:37 --> 404 Page Not Found: /index
INFO - 2018-05-19 04:26:37 --> Config Class Initialized
INFO - 2018-05-19 04:26:37 --> Hooks Class Initialized
DEBUG - 2018-05-19 04:26:38 --> UTF-8 Support Enabled
INFO - 2018-05-19 04:26:38 --> Utf8 Class Initialized
INFO - 2018-05-19 04:26:38 --> URI Class Initialized
INFO - 2018-05-19 04:26:38 --> Router Class Initialized
INFO - 2018-05-19 04:26:38 --> Output Class Initialized
INFO - 2018-05-19 04:26:38 --> Security Class Initialized
DEBUG - 2018-05-19 04:26:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 04:26:38 --> Input Class Initialized
INFO - 2018-05-19 04:26:38 --> Language Class Initialized
ERROR - 2018-05-19 04:26:38 --> 404 Page Not Found: /index
INFO - 2018-05-19 04:26:38 --> Config Class Initialized
INFO - 2018-05-19 04:26:38 --> Hooks Class Initialized
DEBUG - 2018-05-19 04:26:38 --> UTF-8 Support Enabled
INFO - 2018-05-19 04:26:38 --> Utf8 Class Initialized
INFO - 2018-05-19 04:26:38 --> URI Class Initialized
INFO - 2018-05-19 04:26:38 --> Router Class Initialized
INFO - 2018-05-19 04:26:38 --> Output Class Initialized
INFO - 2018-05-19 04:26:38 --> Security Class Initialized
DEBUG - 2018-05-19 04:26:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 04:26:38 --> Input Class Initialized
INFO - 2018-05-19 04:26:38 --> Language Class Initialized
ERROR - 2018-05-19 04:26:38 --> 404 Page Not Found: /index
INFO - 2018-05-19 04:26:38 --> Config Class Initialized
INFO - 2018-05-19 04:26:38 --> Hooks Class Initialized
DEBUG - 2018-05-19 04:26:38 --> UTF-8 Support Enabled
INFO - 2018-05-19 04:26:38 --> Utf8 Class Initialized
INFO - 2018-05-19 04:26:38 --> URI Class Initialized
INFO - 2018-05-19 04:26:39 --> Router Class Initialized
INFO - 2018-05-19 04:26:39 --> Output Class Initialized
INFO - 2018-05-19 04:26:39 --> Security Class Initialized
DEBUG - 2018-05-19 04:26:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 04:26:39 --> Input Class Initialized
INFO - 2018-05-19 04:26:39 --> Language Class Initialized
ERROR - 2018-05-19 04:26:39 --> 404 Page Not Found: /index
INFO - 2018-05-19 04:26:39 --> Config Class Initialized
INFO - 2018-05-19 04:26:39 --> Hooks Class Initialized
DEBUG - 2018-05-19 04:26:39 --> UTF-8 Support Enabled
INFO - 2018-05-19 04:26:39 --> Utf8 Class Initialized
INFO - 2018-05-19 04:26:39 --> URI Class Initialized
INFO - 2018-05-19 04:26:39 --> Router Class Initialized
INFO - 2018-05-19 04:26:39 --> Output Class Initialized
INFO - 2018-05-19 04:26:39 --> Security Class Initialized
DEBUG - 2018-05-19 04:26:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 04:26:39 --> Input Class Initialized
INFO - 2018-05-19 04:26:39 --> Language Class Initialized
ERROR - 2018-05-19 04:26:39 --> 404 Page Not Found: /index
INFO - 2018-05-19 04:26:40 --> Config Class Initialized
INFO - 2018-05-19 04:26:40 --> Hooks Class Initialized
DEBUG - 2018-05-19 04:26:40 --> UTF-8 Support Enabled
INFO - 2018-05-19 04:26:40 --> Utf8 Class Initialized
INFO - 2018-05-19 04:26:40 --> URI Class Initialized
INFO - 2018-05-19 04:26:40 --> Router Class Initialized
INFO - 2018-05-19 04:26:40 --> Output Class Initialized
INFO - 2018-05-19 04:26:40 --> Security Class Initialized
DEBUG - 2018-05-19 04:26:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 04:26:40 --> Input Class Initialized
INFO - 2018-05-19 04:26:40 --> Language Class Initialized
ERROR - 2018-05-19 04:26:40 --> 404 Page Not Found: /index
INFO - 2018-05-19 04:26:40 --> Config Class Initialized
INFO - 2018-05-19 04:26:40 --> Hooks Class Initialized
DEBUG - 2018-05-19 04:26:40 --> UTF-8 Support Enabled
INFO - 2018-05-19 04:26:40 --> Utf8 Class Initialized
INFO - 2018-05-19 04:26:40 --> URI Class Initialized
INFO - 2018-05-19 04:26:40 --> Router Class Initialized
INFO - 2018-05-19 04:26:40 --> Output Class Initialized
INFO - 2018-05-19 04:26:40 --> Security Class Initialized
DEBUG - 2018-05-19 04:26:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 04:26:40 --> Input Class Initialized
INFO - 2018-05-19 04:26:40 --> Language Class Initialized
ERROR - 2018-05-19 04:26:40 --> 404 Page Not Found: /index
INFO - 2018-05-19 04:26:40 --> Config Class Initialized
INFO - 2018-05-19 04:26:40 --> Hooks Class Initialized
DEBUG - 2018-05-19 04:26:40 --> UTF-8 Support Enabled
INFO - 2018-05-19 04:26:40 --> Utf8 Class Initialized
INFO - 2018-05-19 04:26:40 --> URI Class Initialized
INFO - 2018-05-19 04:26:40 --> Router Class Initialized
INFO - 2018-05-19 04:26:40 --> Output Class Initialized
INFO - 2018-05-19 04:26:40 --> Security Class Initialized
DEBUG - 2018-05-19 04:26:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 04:26:40 --> Input Class Initialized
INFO - 2018-05-19 04:26:40 --> Language Class Initialized
ERROR - 2018-05-19 04:26:40 --> 404 Page Not Found: /index
INFO - 2018-05-19 04:26:51 --> Config Class Initialized
INFO - 2018-05-19 04:26:51 --> Hooks Class Initialized
DEBUG - 2018-05-19 04:26:51 --> UTF-8 Support Enabled
INFO - 2018-05-19 04:26:51 --> Utf8 Class Initialized
INFO - 2018-05-19 04:26:51 --> URI Class Initialized
INFO - 2018-05-19 04:26:51 --> Router Class Initialized
INFO - 2018-05-19 04:26:51 --> Output Class Initialized
INFO - 2018-05-19 04:26:51 --> Security Class Initialized
DEBUG - 2018-05-19 04:26:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 04:26:51 --> Input Class Initialized
INFO - 2018-05-19 04:26:51 --> Language Class Initialized
INFO - 2018-05-19 04:26:51 --> Language Class Initialized
INFO - 2018-05-19 04:26:51 --> Config Class Initialized
INFO - 2018-05-19 04:26:51 --> Loader Class Initialized
DEBUG - 2018-05-19 04:26:51 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-19 04:26:51 --> Helper loaded: url_helper
INFO - 2018-05-19 04:26:51 --> Helper loaded: form_helper
INFO - 2018-05-19 04:26:51 --> Helper loaded: date_helper
INFO - 2018-05-19 04:26:51 --> Helper loaded: util_helper
INFO - 2018-05-19 04:26:51 --> Helper loaded: text_helper
INFO - 2018-05-19 04:26:51 --> Helper loaded: string_helper
INFO - 2018-05-19 04:26:51 --> Database Driver Class Initialized
DEBUG - 2018-05-19 04:26:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-19 04:26:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-19 04:26:51 --> Email Class Initialized
INFO - 2018-05-19 04:26:51 --> Controller Class Initialized
DEBUG - 2018-05-19 04:26:51 --> Login MX_Controller Initialized
INFO - 2018-05-19 04:26:51 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-19 04:26:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-19 04:26:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-19 04:26:51 --> 30 Loggedout
INFO - 2018-05-19 04:26:51 --> Config Class Initialized
INFO - 2018-05-19 04:26:51 --> Hooks Class Initialized
DEBUG - 2018-05-19 04:26:51 --> UTF-8 Support Enabled
INFO - 2018-05-19 04:26:51 --> Utf8 Class Initialized
INFO - 2018-05-19 04:26:51 --> URI Class Initialized
INFO - 2018-05-19 04:26:51 --> Router Class Initialized
INFO - 2018-05-19 04:26:51 --> Output Class Initialized
INFO - 2018-05-19 04:26:51 --> Security Class Initialized
DEBUG - 2018-05-19 04:26:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 04:26:51 --> Input Class Initialized
INFO - 2018-05-19 04:26:51 --> Language Class Initialized
INFO - 2018-05-19 04:26:51 --> Language Class Initialized
INFO - 2018-05-19 04:26:51 --> Config Class Initialized
INFO - 2018-05-19 04:26:51 --> Loader Class Initialized
DEBUG - 2018-05-19 04:26:51 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-19 04:26:51 --> Helper loaded: url_helper
INFO - 2018-05-19 04:26:51 --> Helper loaded: form_helper
INFO - 2018-05-19 04:26:51 --> Helper loaded: date_helper
INFO - 2018-05-19 04:26:51 --> Helper loaded: util_helper
INFO - 2018-05-19 04:26:51 --> Helper loaded: text_helper
INFO - 2018-05-19 04:26:51 --> Helper loaded: string_helper
INFO - 2018-05-19 04:26:51 --> Database Driver Class Initialized
DEBUG - 2018-05-19 04:26:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-19 04:26:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-19 04:26:51 --> Email Class Initialized
INFO - 2018-05-19 04:26:51 --> Controller Class Initialized
DEBUG - 2018-05-19 04:26:51 --> Home MX_Controller Initialized
DEBUG - 2018-05-19 04:26:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-19 04:26:51 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-19 04:26:51 --> Login MX_Controller Initialized
INFO - 2018-05-19 04:26:51 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-19 04:26:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-19 04:26:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-19 04:26:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/login.php
INFO - 2018-05-19 04:26:54 --> Config Class Initialized
INFO - 2018-05-19 04:26:54 --> Hooks Class Initialized
DEBUG - 2018-05-19 04:26:54 --> UTF-8 Support Enabled
INFO - 2018-05-19 04:26:54 --> Utf8 Class Initialized
INFO - 2018-05-19 04:26:54 --> URI Class Initialized
INFO - 2018-05-19 04:26:54 --> Router Class Initialized
INFO - 2018-05-19 04:26:54 --> Output Class Initialized
INFO - 2018-05-19 04:26:54 --> Security Class Initialized
DEBUG - 2018-05-19 04:26:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 04:26:54 --> Input Class Initialized
INFO - 2018-05-19 04:26:54 --> Language Class Initialized
INFO - 2018-05-19 04:26:54 --> Language Class Initialized
INFO - 2018-05-19 04:26:54 --> Config Class Initialized
INFO - 2018-05-19 04:26:54 --> Loader Class Initialized
DEBUG - 2018-05-19 04:26:54 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-19 04:26:54 --> Helper loaded: url_helper
INFO - 2018-05-19 04:26:54 --> Helper loaded: form_helper
INFO - 2018-05-19 04:26:54 --> Helper loaded: date_helper
INFO - 2018-05-19 04:26:54 --> Helper loaded: util_helper
INFO - 2018-05-19 04:26:54 --> Helper loaded: text_helper
INFO - 2018-05-19 04:26:54 --> Helper loaded: string_helper
INFO - 2018-05-19 04:26:54 --> Database Driver Class Initialized
DEBUG - 2018-05-19 04:26:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-19 04:26:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-19 04:26:55 --> Email Class Initialized
INFO - 2018-05-19 04:26:55 --> Controller Class Initialized
DEBUG - 2018-05-19 04:26:55 --> Login MX_Controller Initialized
INFO - 2018-05-19 04:26:55 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-19 04:26:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-19 04:26:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-19 04:26:55 --> Email starts for gopipanguluri123@gmail.com fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-05-19 04:26:55 --> Login status gopipanguluri123@gmail.com - failure
INFO - 2018-05-19 04:26:55 --> Final output sent to browser
DEBUG - 2018-05-19 04:26:55 --> Total execution time: 0.3470
INFO - 2018-05-19 04:27:28 --> Config Class Initialized
INFO - 2018-05-19 04:27:28 --> Hooks Class Initialized
DEBUG - 2018-05-19 04:27:28 --> UTF-8 Support Enabled
INFO - 2018-05-19 04:27:28 --> Utf8 Class Initialized
INFO - 2018-05-19 04:27:28 --> URI Class Initialized
INFO - 2018-05-19 04:27:28 --> Router Class Initialized
INFO - 2018-05-19 04:27:28 --> Output Class Initialized
INFO - 2018-05-19 04:27:28 --> Security Class Initialized
DEBUG - 2018-05-19 04:27:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 04:27:28 --> Input Class Initialized
INFO - 2018-05-19 04:27:28 --> Language Class Initialized
INFO - 2018-05-19 04:27:28 --> Language Class Initialized
INFO - 2018-05-19 04:27:28 --> Config Class Initialized
INFO - 2018-05-19 04:27:28 --> Loader Class Initialized
DEBUG - 2018-05-19 04:27:28 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-19 04:27:28 --> Helper loaded: url_helper
INFO - 2018-05-19 04:27:28 --> Helper loaded: form_helper
INFO - 2018-05-19 04:27:28 --> Helper loaded: date_helper
INFO - 2018-05-19 04:27:28 --> Helper loaded: util_helper
INFO - 2018-05-19 04:27:28 --> Helper loaded: text_helper
INFO - 2018-05-19 04:27:28 --> Helper loaded: string_helper
INFO - 2018-05-19 04:27:28 --> Database Driver Class Initialized
DEBUG - 2018-05-19 04:27:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-19 04:27:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-19 04:27:28 --> Email Class Initialized
INFO - 2018-05-19 04:27:28 --> Controller Class Initialized
DEBUG - 2018-05-19 04:27:28 --> Home MX_Controller Initialized
DEBUG - 2018-05-19 04:27:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-19 04:27:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/register.php
INFO - 2018-05-19 04:27:28 --> Final output sent to browser
DEBUG - 2018-05-19 04:27:28 --> Total execution time: 0.3302
INFO - 2018-05-19 04:27:36 --> Config Class Initialized
INFO - 2018-05-19 04:27:36 --> Hooks Class Initialized
DEBUG - 2018-05-19 04:27:36 --> UTF-8 Support Enabled
INFO - 2018-05-19 04:27:36 --> Utf8 Class Initialized
INFO - 2018-05-19 04:27:36 --> URI Class Initialized
INFO - 2018-05-19 04:27:36 --> Router Class Initialized
INFO - 2018-05-19 04:27:36 --> Output Class Initialized
INFO - 2018-05-19 04:27:36 --> Security Class Initialized
DEBUG - 2018-05-19 04:27:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 04:27:36 --> Input Class Initialized
INFO - 2018-05-19 04:27:36 --> Language Class Initialized
INFO - 2018-05-19 04:27:36 --> Language Class Initialized
INFO - 2018-05-19 04:27:36 --> Config Class Initialized
INFO - 2018-05-19 04:27:36 --> Loader Class Initialized
DEBUG - 2018-05-19 04:27:36 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-19 04:27:36 --> Helper loaded: url_helper
INFO - 2018-05-19 04:27:36 --> Helper loaded: form_helper
INFO - 2018-05-19 04:27:36 --> Helper loaded: date_helper
INFO - 2018-05-19 04:27:36 --> Helper loaded: util_helper
INFO - 2018-05-19 04:27:36 --> Helper loaded: text_helper
INFO - 2018-05-19 04:27:36 --> Helper loaded: string_helper
INFO - 2018-05-19 04:27:36 --> Database Driver Class Initialized
DEBUG - 2018-05-19 04:27:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-19 04:27:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-19 04:27:36 --> Email Class Initialized
INFO - 2018-05-19 04:27:36 --> Controller Class Initialized
DEBUG - 2018-05-19 04:27:36 --> Login MX_Controller Initialized
INFO - 2018-05-19 04:27:36 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-19 04:27:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-19 04:27:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-19 04:28:52 --> Config Class Initialized
INFO - 2018-05-19 04:28:52 --> Hooks Class Initialized
DEBUG - 2018-05-19 04:28:52 --> UTF-8 Support Enabled
INFO - 2018-05-19 04:28:52 --> Utf8 Class Initialized
INFO - 2018-05-19 04:28:52 --> URI Class Initialized
INFO - 2018-05-19 04:28:52 --> Router Class Initialized
INFO - 2018-05-19 04:28:52 --> Output Class Initialized
INFO - 2018-05-19 04:28:52 --> Security Class Initialized
DEBUG - 2018-05-19 04:28:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 04:28:52 --> Input Class Initialized
INFO - 2018-05-19 04:28:52 --> Language Class Initialized
INFO - 2018-05-19 04:28:52 --> Language Class Initialized
INFO - 2018-05-19 04:28:52 --> Config Class Initialized
INFO - 2018-05-19 04:28:52 --> Loader Class Initialized
DEBUG - 2018-05-19 04:28:52 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-19 04:28:52 --> Helper loaded: url_helper
INFO - 2018-05-19 04:28:52 --> Helper loaded: form_helper
INFO - 2018-05-19 04:28:52 --> Helper loaded: date_helper
INFO - 2018-05-19 04:28:52 --> Helper loaded: util_helper
INFO - 2018-05-19 04:28:52 --> Helper loaded: text_helper
INFO - 2018-05-19 04:28:52 --> Helper loaded: string_helper
INFO - 2018-05-19 04:28:52 --> Database Driver Class Initialized
DEBUG - 2018-05-19 04:28:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-19 04:28:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-19 04:28:52 --> Email Class Initialized
INFO - 2018-05-19 04:28:52 --> Controller Class Initialized
DEBUG - 2018-05-19 04:28:52 --> Home MX_Controller Initialized
DEBUG - 2018-05-19 04:28:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-19 04:28:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/register.php
INFO - 2018-05-19 04:28:52 --> Final output sent to browser
DEBUG - 2018-05-19 04:28:52 --> Total execution time: 0.3439
INFO - 2018-05-19 04:29:14 --> Config Class Initialized
INFO - 2018-05-19 04:29:14 --> Hooks Class Initialized
DEBUG - 2018-05-19 04:29:14 --> UTF-8 Support Enabled
INFO - 2018-05-19 04:29:14 --> Utf8 Class Initialized
INFO - 2018-05-19 04:29:14 --> URI Class Initialized
INFO - 2018-05-19 04:29:14 --> Router Class Initialized
INFO - 2018-05-19 04:29:14 --> Output Class Initialized
INFO - 2018-05-19 04:29:14 --> Security Class Initialized
DEBUG - 2018-05-19 04:29:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 04:29:14 --> Input Class Initialized
INFO - 2018-05-19 04:29:14 --> Language Class Initialized
INFO - 2018-05-19 04:29:14 --> Language Class Initialized
INFO - 2018-05-19 04:29:14 --> Config Class Initialized
INFO - 2018-05-19 04:29:14 --> Loader Class Initialized
DEBUG - 2018-05-19 04:29:14 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-19 04:29:14 --> Helper loaded: url_helper
INFO - 2018-05-19 04:29:14 --> Helper loaded: form_helper
INFO - 2018-05-19 04:29:14 --> Helper loaded: date_helper
INFO - 2018-05-19 04:29:14 --> Helper loaded: util_helper
INFO - 2018-05-19 04:29:14 --> Helper loaded: text_helper
INFO - 2018-05-19 04:29:14 --> Helper loaded: string_helper
INFO - 2018-05-19 04:29:14 --> Database Driver Class Initialized
DEBUG - 2018-05-19 04:29:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-19 04:29:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-19 04:29:14 --> Email Class Initialized
INFO - 2018-05-19 04:29:14 --> Controller Class Initialized
DEBUG - 2018-05-19 04:29:14 --> Login MX_Controller Initialized
INFO - 2018-05-19 04:29:14 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-19 04:29:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-19 04:29:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-19 04:29:39 --> Config Class Initialized
INFO - 2018-05-19 04:29:39 --> Hooks Class Initialized
DEBUG - 2018-05-19 04:29:39 --> UTF-8 Support Enabled
INFO - 2018-05-19 04:29:39 --> Utf8 Class Initialized
INFO - 2018-05-19 04:29:39 --> URI Class Initialized
INFO - 2018-05-19 04:29:39 --> Router Class Initialized
INFO - 2018-05-19 04:29:39 --> Output Class Initialized
INFO - 2018-05-19 04:29:39 --> Security Class Initialized
DEBUG - 2018-05-19 04:29:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 04:29:39 --> Input Class Initialized
INFO - 2018-05-19 04:29:39 --> Language Class Initialized
INFO - 2018-05-19 04:29:39 --> Language Class Initialized
INFO - 2018-05-19 04:29:39 --> Config Class Initialized
INFO - 2018-05-19 04:29:39 --> Loader Class Initialized
DEBUG - 2018-05-19 04:29:39 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-19 04:29:39 --> Helper loaded: url_helper
INFO - 2018-05-19 04:29:39 --> Helper loaded: form_helper
INFO - 2018-05-19 04:29:39 --> Helper loaded: date_helper
INFO - 2018-05-19 04:29:39 --> Helper loaded: util_helper
INFO - 2018-05-19 04:29:39 --> Helper loaded: text_helper
INFO - 2018-05-19 04:29:39 --> Helper loaded: string_helper
INFO - 2018-05-19 04:29:39 --> Database Driver Class Initialized
DEBUG - 2018-05-19 04:29:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-19 04:29:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-19 04:29:39 --> Email Class Initialized
INFO - 2018-05-19 04:29:39 --> Controller Class Initialized
DEBUG - 2018-05-19 04:29:39 --> Login MX_Controller Initialized
INFO - 2018-05-19 04:29:39 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-19 04:29:39 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-19 04:29:39 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-19 04:30:16 --> Config Class Initialized
INFO - 2018-05-19 04:30:16 --> Hooks Class Initialized
DEBUG - 2018-05-19 04:30:16 --> UTF-8 Support Enabled
INFO - 2018-05-19 04:30:16 --> Utf8 Class Initialized
INFO - 2018-05-19 04:30:16 --> URI Class Initialized
INFO - 2018-05-19 04:30:16 --> Router Class Initialized
INFO - 2018-05-19 04:30:16 --> Output Class Initialized
INFO - 2018-05-19 04:30:16 --> Security Class Initialized
DEBUG - 2018-05-19 04:30:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 04:30:16 --> Input Class Initialized
INFO - 2018-05-19 04:30:16 --> Language Class Initialized
INFO - 2018-05-19 04:30:16 --> Language Class Initialized
INFO - 2018-05-19 04:30:16 --> Config Class Initialized
INFO - 2018-05-19 04:30:16 --> Loader Class Initialized
DEBUG - 2018-05-19 04:30:16 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-19 04:30:16 --> Helper loaded: url_helper
INFO - 2018-05-19 04:30:16 --> Helper loaded: form_helper
INFO - 2018-05-19 04:30:16 --> Helper loaded: date_helper
INFO - 2018-05-19 04:30:16 --> Helper loaded: util_helper
INFO - 2018-05-19 04:30:16 --> Helper loaded: text_helper
INFO - 2018-05-19 04:30:16 --> Helper loaded: string_helper
INFO - 2018-05-19 04:30:16 --> Database Driver Class Initialized
DEBUG - 2018-05-19 04:30:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-19 04:30:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-19 04:30:16 --> Email Class Initialized
INFO - 2018-05-19 04:30:16 --> Controller Class Initialized
DEBUG - 2018-05-19 04:30:16 --> Home MX_Controller Initialized
DEBUG - 2018-05-19 04:30:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-19 04:30:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/register.php
INFO - 2018-05-19 04:30:16 --> Final output sent to browser
DEBUG - 2018-05-19 04:30:16 --> Total execution time: 0.3594
INFO - 2018-05-19 04:30:29 --> Config Class Initialized
INFO - 2018-05-19 04:30:29 --> Hooks Class Initialized
DEBUG - 2018-05-19 04:30:29 --> UTF-8 Support Enabled
INFO - 2018-05-19 04:30:29 --> Utf8 Class Initialized
INFO - 2018-05-19 04:30:29 --> URI Class Initialized
INFO - 2018-05-19 04:30:29 --> Router Class Initialized
INFO - 2018-05-19 04:30:29 --> Output Class Initialized
INFO - 2018-05-19 04:30:29 --> Security Class Initialized
DEBUG - 2018-05-19 04:30:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 04:30:29 --> Input Class Initialized
INFO - 2018-05-19 04:30:29 --> Language Class Initialized
INFO - 2018-05-19 04:30:29 --> Language Class Initialized
INFO - 2018-05-19 04:30:29 --> Config Class Initialized
INFO - 2018-05-19 04:30:29 --> Loader Class Initialized
DEBUG - 2018-05-19 04:30:29 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-19 04:30:29 --> Helper loaded: url_helper
INFO - 2018-05-19 04:30:29 --> Helper loaded: form_helper
INFO - 2018-05-19 04:30:29 --> Helper loaded: date_helper
INFO - 2018-05-19 04:30:29 --> Helper loaded: util_helper
INFO - 2018-05-19 04:30:29 --> Helper loaded: text_helper
INFO - 2018-05-19 04:30:29 --> Helper loaded: string_helper
INFO - 2018-05-19 04:30:29 --> Database Driver Class Initialized
DEBUG - 2018-05-19 04:30:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-19 04:30:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-19 04:30:29 --> Email Class Initialized
INFO - 2018-05-19 04:30:29 --> Controller Class Initialized
DEBUG - 2018-05-19 04:30:29 --> Login MX_Controller Initialized
INFO - 2018-05-19 04:30:29 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-19 04:30:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-19 04:30:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-19 04:32:12 --> Config Class Initialized
INFO - 2018-05-19 04:32:12 --> Hooks Class Initialized
DEBUG - 2018-05-19 04:32:12 --> UTF-8 Support Enabled
INFO - 2018-05-19 04:32:12 --> Utf8 Class Initialized
INFO - 2018-05-19 04:32:12 --> URI Class Initialized
INFO - 2018-05-19 04:32:12 --> Router Class Initialized
INFO - 2018-05-19 04:32:12 --> Output Class Initialized
INFO - 2018-05-19 04:32:12 --> Security Class Initialized
DEBUG - 2018-05-19 04:32:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 04:32:12 --> Input Class Initialized
INFO - 2018-05-19 04:32:12 --> Language Class Initialized
INFO - 2018-05-19 04:32:12 --> Language Class Initialized
INFO - 2018-05-19 04:32:12 --> Config Class Initialized
INFO - 2018-05-19 04:32:12 --> Loader Class Initialized
DEBUG - 2018-05-19 04:32:12 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-19 04:32:12 --> Helper loaded: url_helper
INFO - 2018-05-19 04:32:12 --> Helper loaded: form_helper
INFO - 2018-05-19 04:32:12 --> Helper loaded: date_helper
INFO - 2018-05-19 04:32:12 --> Helper loaded: util_helper
INFO - 2018-05-19 04:32:12 --> Helper loaded: text_helper
INFO - 2018-05-19 04:32:12 --> Helper loaded: string_helper
INFO - 2018-05-19 04:32:12 --> Database Driver Class Initialized
DEBUG - 2018-05-19 04:32:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-19 04:32:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-19 04:32:12 --> Email Class Initialized
INFO - 2018-05-19 04:32:12 --> Controller Class Initialized
DEBUG - 2018-05-19 04:32:12 --> Home MX_Controller Initialized
DEBUG - 2018-05-19 04:32:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-19 04:32:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/register.php
INFO - 2018-05-19 04:32:12 --> Final output sent to browser
DEBUG - 2018-05-19 04:32:12 --> Total execution time: 0.3420
INFO - 2018-05-19 04:32:24 --> Config Class Initialized
INFO - 2018-05-19 04:32:24 --> Hooks Class Initialized
DEBUG - 2018-05-19 04:32:24 --> UTF-8 Support Enabled
INFO - 2018-05-19 04:32:24 --> Utf8 Class Initialized
INFO - 2018-05-19 04:32:24 --> URI Class Initialized
INFO - 2018-05-19 04:32:24 --> Router Class Initialized
INFO - 2018-05-19 04:32:24 --> Output Class Initialized
INFO - 2018-05-19 04:32:24 --> Security Class Initialized
DEBUG - 2018-05-19 04:32:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 04:32:24 --> Input Class Initialized
INFO - 2018-05-19 04:32:24 --> Language Class Initialized
INFO - 2018-05-19 04:32:24 --> Language Class Initialized
INFO - 2018-05-19 04:32:24 --> Config Class Initialized
INFO - 2018-05-19 04:32:24 --> Loader Class Initialized
DEBUG - 2018-05-19 04:32:24 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-19 04:32:24 --> Helper loaded: url_helper
INFO - 2018-05-19 04:32:24 --> Helper loaded: form_helper
INFO - 2018-05-19 04:32:24 --> Helper loaded: date_helper
INFO - 2018-05-19 04:32:24 --> Helper loaded: util_helper
INFO - 2018-05-19 04:32:24 --> Helper loaded: text_helper
INFO - 2018-05-19 04:32:24 --> Helper loaded: string_helper
INFO - 2018-05-19 04:32:24 --> Database Driver Class Initialized
DEBUG - 2018-05-19 04:32:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-19 04:32:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-19 04:32:24 --> Email Class Initialized
INFO - 2018-05-19 04:32:24 --> Controller Class Initialized
DEBUG - 2018-05-19 04:32:24 --> Login MX_Controller Initialized
INFO - 2018-05-19 04:32:24 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-19 04:32:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-19 04:32:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-19 04:32:54 --> Config Class Initialized
INFO - 2018-05-19 04:32:54 --> Hooks Class Initialized
DEBUG - 2018-05-19 04:32:54 --> UTF-8 Support Enabled
INFO - 2018-05-19 04:32:54 --> Utf8 Class Initialized
INFO - 2018-05-19 04:32:54 --> URI Class Initialized
INFO - 2018-05-19 04:32:54 --> Router Class Initialized
INFO - 2018-05-19 04:32:54 --> Output Class Initialized
INFO - 2018-05-19 04:32:54 --> Security Class Initialized
DEBUG - 2018-05-19 04:32:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 04:32:54 --> Input Class Initialized
INFO - 2018-05-19 04:32:54 --> Language Class Initialized
INFO - 2018-05-19 04:32:54 --> Language Class Initialized
INFO - 2018-05-19 04:32:54 --> Config Class Initialized
INFO - 2018-05-19 04:32:54 --> Loader Class Initialized
DEBUG - 2018-05-19 04:32:54 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-19 04:32:54 --> Helper loaded: url_helper
INFO - 2018-05-19 04:32:54 --> Helper loaded: form_helper
INFO - 2018-05-19 04:32:54 --> Helper loaded: date_helper
INFO - 2018-05-19 04:32:54 --> Helper loaded: util_helper
INFO - 2018-05-19 04:32:54 --> Helper loaded: text_helper
INFO - 2018-05-19 04:32:54 --> Helper loaded: string_helper
INFO - 2018-05-19 04:32:54 --> Database Driver Class Initialized
DEBUG - 2018-05-19 04:32:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-19 04:32:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-19 04:32:54 --> Email Class Initialized
INFO - 2018-05-19 04:32:54 --> Controller Class Initialized
DEBUG - 2018-05-19 04:32:54 --> Home MX_Controller Initialized
DEBUG - 2018-05-19 04:32:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-19 04:32:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/register.php
INFO - 2018-05-19 04:32:54 --> Final output sent to browser
DEBUG - 2018-05-19 04:32:54 --> Total execution time: 0.3360
INFO - 2018-05-19 04:33:15 --> Config Class Initialized
INFO - 2018-05-19 04:33:15 --> Hooks Class Initialized
DEBUG - 2018-05-19 04:33:15 --> UTF-8 Support Enabled
INFO - 2018-05-19 04:33:15 --> Utf8 Class Initialized
INFO - 2018-05-19 04:33:15 --> URI Class Initialized
INFO - 2018-05-19 04:33:15 --> Router Class Initialized
INFO - 2018-05-19 04:33:15 --> Output Class Initialized
INFO - 2018-05-19 04:33:15 --> Security Class Initialized
DEBUG - 2018-05-19 04:33:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 04:33:15 --> Input Class Initialized
INFO - 2018-05-19 04:33:15 --> Language Class Initialized
INFO - 2018-05-19 04:33:15 --> Language Class Initialized
INFO - 2018-05-19 04:33:15 --> Config Class Initialized
INFO - 2018-05-19 04:33:15 --> Loader Class Initialized
DEBUG - 2018-05-19 04:33:15 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-19 04:33:15 --> Helper loaded: url_helper
INFO - 2018-05-19 04:33:15 --> Helper loaded: form_helper
INFO - 2018-05-19 04:33:15 --> Helper loaded: date_helper
INFO - 2018-05-19 04:33:15 --> Helper loaded: util_helper
INFO - 2018-05-19 04:33:16 --> Helper loaded: text_helper
INFO - 2018-05-19 04:33:16 --> Helper loaded: string_helper
INFO - 2018-05-19 04:33:16 --> Database Driver Class Initialized
DEBUG - 2018-05-19 04:33:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-19 04:33:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-19 04:33:16 --> Email Class Initialized
INFO - 2018-05-19 04:33:16 --> Controller Class Initialized
DEBUG - 2018-05-19 04:33:16 --> Login MX_Controller Initialized
INFO - 2018-05-19 04:33:16 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-19 04:33:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-19 04:33:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-19 04:34:15 --> Config Class Initialized
INFO - 2018-05-19 04:34:15 --> Hooks Class Initialized
DEBUG - 2018-05-19 04:34:15 --> UTF-8 Support Enabled
INFO - 2018-05-19 04:34:15 --> Utf8 Class Initialized
INFO - 2018-05-19 04:34:15 --> URI Class Initialized
INFO - 2018-05-19 04:34:15 --> Router Class Initialized
INFO - 2018-05-19 04:34:15 --> Output Class Initialized
INFO - 2018-05-19 04:34:15 --> Security Class Initialized
DEBUG - 2018-05-19 04:34:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 04:34:15 --> Input Class Initialized
INFO - 2018-05-19 04:34:15 --> Language Class Initialized
INFO - 2018-05-19 04:34:15 --> Language Class Initialized
INFO - 2018-05-19 04:34:15 --> Config Class Initialized
INFO - 2018-05-19 04:34:15 --> Loader Class Initialized
DEBUG - 2018-05-19 04:34:16 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-19 04:34:16 --> Helper loaded: url_helper
INFO - 2018-05-19 04:34:16 --> Helper loaded: form_helper
INFO - 2018-05-19 04:34:16 --> Helper loaded: date_helper
INFO - 2018-05-19 04:34:16 --> Helper loaded: util_helper
INFO - 2018-05-19 04:34:16 --> Helper loaded: text_helper
INFO - 2018-05-19 04:34:16 --> Helper loaded: string_helper
INFO - 2018-05-19 04:34:16 --> Database Driver Class Initialized
DEBUG - 2018-05-19 04:34:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-19 04:34:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-19 04:34:16 --> Email Class Initialized
INFO - 2018-05-19 04:34:16 --> Controller Class Initialized
DEBUG - 2018-05-19 04:34:16 --> Login MX_Controller Initialized
INFO - 2018-05-19 04:34:16 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-19 04:34:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-19 04:34:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-19 04:34:21 --> Config Class Initialized
INFO - 2018-05-19 04:34:21 --> Hooks Class Initialized
DEBUG - 2018-05-19 04:34:21 --> UTF-8 Support Enabled
INFO - 2018-05-19 04:34:21 --> Utf8 Class Initialized
INFO - 2018-05-19 04:34:21 --> URI Class Initialized
INFO - 2018-05-19 04:34:21 --> Router Class Initialized
INFO - 2018-05-19 04:34:21 --> Output Class Initialized
INFO - 2018-05-19 04:34:21 --> Security Class Initialized
DEBUG - 2018-05-19 04:34:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 04:34:21 --> Input Class Initialized
INFO - 2018-05-19 04:34:21 --> Language Class Initialized
INFO - 2018-05-19 04:34:21 --> Language Class Initialized
INFO - 2018-05-19 04:34:21 --> Config Class Initialized
INFO - 2018-05-19 04:34:21 --> Loader Class Initialized
DEBUG - 2018-05-19 04:34:21 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-19 04:34:21 --> Helper loaded: url_helper
INFO - 2018-05-19 04:34:21 --> Helper loaded: form_helper
INFO - 2018-05-19 04:34:21 --> Helper loaded: date_helper
INFO - 2018-05-19 04:34:21 --> Helper loaded: util_helper
INFO - 2018-05-19 04:34:21 --> Helper loaded: text_helper
INFO - 2018-05-19 04:34:21 --> Helper loaded: string_helper
INFO - 2018-05-19 04:34:21 --> Database Driver Class Initialized
DEBUG - 2018-05-19 04:34:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-19 04:34:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-19 04:34:21 --> Email Class Initialized
INFO - 2018-05-19 04:34:21 --> Controller Class Initialized
DEBUG - 2018-05-19 04:34:21 --> Login MX_Controller Initialized
INFO - 2018-05-19 04:34:21 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-19 04:34:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-19 04:34:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
ERROR - 2018-05-19 04:34:21 --> Severity: Notice --> Undefined variable: name E:\xampp\htdocs\consulting\application\modules\common\views\common\templates\mail_view.php 1
DEBUG - 2018-05-19 04:34:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/templates/mail_view.php
DEBUG - 2018-05-19 04:34:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Mail_model.php
INFO - 2018-05-19 04:34:21 --> Helper loaded: file_helper
INFO - 2018-05-19 04:34:21 --> Login status gopipanguluri123456@gmail.com Successfully registered
INFO - 2018-05-19 04:34:21 --> Config Class Initialized
INFO - 2018-05-19 04:34:21 --> Hooks Class Initialized
DEBUG - 2018-05-19 04:34:21 --> UTF-8 Support Enabled
INFO - 2018-05-19 04:34:21 --> Utf8 Class Initialized
INFO - 2018-05-19 04:34:21 --> URI Class Initialized
INFO - 2018-05-19 04:34:21 --> Router Class Initialized
INFO - 2018-05-19 04:34:21 --> Output Class Initialized
INFO - 2018-05-19 04:34:21 --> Security Class Initialized
DEBUG - 2018-05-19 04:34:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 04:34:21 --> Input Class Initialized
INFO - 2018-05-19 04:34:21 --> Language Class Initialized
INFO - 2018-05-19 04:34:21 --> Language Class Initialized
INFO - 2018-05-19 04:34:21 --> Config Class Initialized
INFO - 2018-05-19 04:34:21 --> Loader Class Initialized
DEBUG - 2018-05-19 04:34:21 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-19 04:34:21 --> Helper loaded: url_helper
INFO - 2018-05-19 04:34:21 --> Helper loaded: form_helper
INFO - 2018-05-19 04:34:21 --> Helper loaded: date_helper
INFO - 2018-05-19 04:34:21 --> Helper loaded: util_helper
INFO - 2018-05-19 04:34:21 --> Helper loaded: text_helper
INFO - 2018-05-19 04:34:21 --> Helper loaded: string_helper
INFO - 2018-05-19 04:34:21 --> Database Driver Class Initialized
DEBUG - 2018-05-19 04:34:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-19 04:34:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-19 04:34:22 --> Email Class Initialized
INFO - 2018-05-19 04:34:22 --> Controller Class Initialized
DEBUG - 2018-05-19 04:34:22 --> Home MX_Controller Initialized
DEBUG - 2018-05-19 04:34:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-19 04:34:22 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-19 04:34:22 --> Login MX_Controller Initialized
INFO - 2018-05-19 04:34:22 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-19 04:34:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-19 04:34:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-19 04:34:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/login.php
INFO - 2018-05-19 04:34:26 --> Config Class Initialized
INFO - 2018-05-19 04:34:26 --> Hooks Class Initialized
DEBUG - 2018-05-19 04:34:26 --> UTF-8 Support Enabled
INFO - 2018-05-19 04:34:26 --> Utf8 Class Initialized
INFO - 2018-05-19 04:34:26 --> URI Class Initialized
INFO - 2018-05-19 04:34:26 --> Router Class Initialized
INFO - 2018-05-19 04:34:26 --> Output Class Initialized
INFO - 2018-05-19 04:34:26 --> Security Class Initialized
DEBUG - 2018-05-19 04:34:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 04:34:26 --> Input Class Initialized
INFO - 2018-05-19 04:34:26 --> Language Class Initialized
INFO - 2018-05-19 04:34:26 --> Language Class Initialized
INFO - 2018-05-19 04:34:26 --> Config Class Initialized
INFO - 2018-05-19 04:34:26 --> Loader Class Initialized
DEBUG - 2018-05-19 04:34:26 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-19 04:34:26 --> Helper loaded: url_helper
INFO - 2018-05-19 04:34:26 --> Helper loaded: form_helper
INFO - 2018-05-19 04:34:26 --> Helper loaded: date_helper
INFO - 2018-05-19 04:34:26 --> Helper loaded: util_helper
INFO - 2018-05-19 04:34:26 --> Helper loaded: text_helper
INFO - 2018-05-19 04:34:26 --> Helper loaded: string_helper
INFO - 2018-05-19 04:34:26 --> Database Driver Class Initialized
DEBUG - 2018-05-19 04:34:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-19 04:34:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-19 04:34:26 --> Email Class Initialized
INFO - 2018-05-19 04:34:26 --> Controller Class Initialized
DEBUG - 2018-05-19 04:34:26 --> Login MX_Controller Initialized
INFO - 2018-05-19 04:34:26 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-19 04:34:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-19 04:34:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-19 04:34:26 --> Email starts for gopipanguluri123456@gmail.com fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-05-19 04:34:26 --> Login status gopipanguluri123456@gmail.com - failure
INFO - 2018-05-19 04:34:26 --> Final output sent to browser
DEBUG - 2018-05-19 04:34:26 --> Total execution time: 0.3549
INFO - 2018-05-19 05:42:58 --> Config Class Initialized
INFO - 2018-05-19 05:42:58 --> Hooks Class Initialized
DEBUG - 2018-05-19 05:42:58 --> UTF-8 Support Enabled
INFO - 2018-05-19 05:42:58 --> Utf8 Class Initialized
INFO - 2018-05-19 05:42:58 --> URI Class Initialized
INFO - 2018-05-19 05:42:58 --> Router Class Initialized
INFO - 2018-05-19 05:42:58 --> Output Class Initialized
INFO - 2018-05-19 05:42:58 --> Security Class Initialized
DEBUG - 2018-05-19 05:42:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 05:42:58 --> Input Class Initialized
INFO - 2018-05-19 05:42:58 --> Language Class Initialized
INFO - 2018-05-19 05:42:58 --> Language Class Initialized
INFO - 2018-05-19 05:42:58 --> Config Class Initialized
INFO - 2018-05-19 05:42:58 --> Loader Class Initialized
DEBUG - 2018-05-19 05:42:58 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-19 05:42:58 --> Helper loaded: url_helper
INFO - 2018-05-19 05:42:58 --> Helper loaded: form_helper
INFO - 2018-05-19 05:42:58 --> Helper loaded: date_helper
INFO - 2018-05-19 05:42:58 --> Helper loaded: util_helper
INFO - 2018-05-19 05:42:58 --> Helper loaded: text_helper
INFO - 2018-05-19 05:42:58 --> Helper loaded: string_helper
INFO - 2018-05-19 05:42:58 --> Database Driver Class Initialized
DEBUG - 2018-05-19 05:42:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-19 05:42:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-19 05:42:58 --> Email Class Initialized
INFO - 2018-05-19 05:42:58 --> Controller Class Initialized
DEBUG - 2018-05-19 05:42:58 --> Login MX_Controller Initialized
INFO - 2018-05-19 05:42:58 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-19 05:42:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-19 05:42:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-19 05:42:58 --> Email starts for gopipanguluri123456@gmail.com fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-05-19 05:42:58 --> Login status gopipanguluri123456@gmail.com - failure
INFO - 2018-05-19 05:42:58 --> Final output sent to browser
DEBUG - 2018-05-19 05:42:58 --> Total execution time: 0.3730
INFO - 2018-05-19 05:43:06 --> Config Class Initialized
INFO - 2018-05-19 05:43:06 --> Hooks Class Initialized
DEBUG - 2018-05-19 05:43:06 --> UTF-8 Support Enabled
INFO - 2018-05-19 05:43:06 --> Utf8 Class Initialized
INFO - 2018-05-19 05:43:06 --> URI Class Initialized
INFO - 2018-05-19 05:43:06 --> Router Class Initialized
INFO - 2018-05-19 05:43:06 --> Output Class Initialized
INFO - 2018-05-19 05:43:06 --> Security Class Initialized
DEBUG - 2018-05-19 05:43:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 05:43:06 --> Input Class Initialized
INFO - 2018-05-19 05:43:06 --> Language Class Initialized
INFO - 2018-05-19 05:43:06 --> Language Class Initialized
INFO - 2018-05-19 05:43:06 --> Config Class Initialized
INFO - 2018-05-19 05:43:06 --> Loader Class Initialized
DEBUG - 2018-05-19 05:43:06 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-19 05:43:06 --> Helper loaded: url_helper
INFO - 2018-05-19 05:43:06 --> Helper loaded: form_helper
INFO - 2018-05-19 05:43:06 --> Helper loaded: date_helper
INFO - 2018-05-19 05:43:06 --> Helper loaded: util_helper
INFO - 2018-05-19 05:43:06 --> Helper loaded: text_helper
INFO - 2018-05-19 05:43:06 --> Helper loaded: string_helper
INFO - 2018-05-19 05:43:06 --> Database Driver Class Initialized
DEBUG - 2018-05-19 05:43:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-19 05:43:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-19 05:43:06 --> Email Class Initialized
INFO - 2018-05-19 05:43:06 --> Controller Class Initialized
DEBUG - 2018-05-19 05:43:06 --> Home MX_Controller Initialized
DEBUG - 2018-05-19 05:43:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-19 05:43:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/register.php
INFO - 2018-05-19 05:43:06 --> Final output sent to browser
DEBUG - 2018-05-19 05:43:06 --> Total execution time: 0.3769
INFO - 2018-05-19 05:44:02 --> Config Class Initialized
INFO - 2018-05-19 05:44:02 --> Hooks Class Initialized
DEBUG - 2018-05-19 05:44:02 --> UTF-8 Support Enabled
INFO - 2018-05-19 05:44:02 --> Utf8 Class Initialized
INFO - 2018-05-19 05:44:02 --> URI Class Initialized
INFO - 2018-05-19 05:44:02 --> Router Class Initialized
INFO - 2018-05-19 05:44:02 --> Output Class Initialized
INFO - 2018-05-19 05:44:02 --> Security Class Initialized
DEBUG - 2018-05-19 05:44:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 05:44:02 --> Input Class Initialized
INFO - 2018-05-19 05:44:02 --> Language Class Initialized
INFO - 2018-05-19 05:44:02 --> Language Class Initialized
INFO - 2018-05-19 05:44:02 --> Config Class Initialized
INFO - 2018-05-19 05:44:02 --> Loader Class Initialized
DEBUG - 2018-05-19 05:44:02 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-19 05:44:02 --> Helper loaded: url_helper
INFO - 2018-05-19 05:44:02 --> Helper loaded: form_helper
INFO - 2018-05-19 05:44:02 --> Helper loaded: date_helper
INFO - 2018-05-19 05:44:02 --> Helper loaded: util_helper
INFO - 2018-05-19 05:44:02 --> Helper loaded: text_helper
INFO - 2018-05-19 05:44:02 --> Helper loaded: string_helper
INFO - 2018-05-19 05:44:02 --> Database Driver Class Initialized
DEBUG - 2018-05-19 05:44:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-19 05:44:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-19 05:44:02 --> Email Class Initialized
INFO - 2018-05-19 05:44:02 --> Controller Class Initialized
DEBUG - 2018-05-19 05:44:02 --> Home MX_Controller Initialized
DEBUG - 2018-05-19 05:44:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-19 05:44:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/register.php
INFO - 2018-05-19 05:44:02 --> Final output sent to browser
DEBUG - 2018-05-19 05:44:02 --> Total execution time: 0.3605
INFO - 2018-05-19 05:44:33 --> Config Class Initialized
INFO - 2018-05-19 05:44:33 --> Hooks Class Initialized
DEBUG - 2018-05-19 05:44:33 --> UTF-8 Support Enabled
INFO - 2018-05-19 05:44:33 --> Utf8 Class Initialized
INFO - 2018-05-19 05:44:33 --> URI Class Initialized
INFO - 2018-05-19 05:44:33 --> Router Class Initialized
INFO - 2018-05-19 05:44:33 --> Output Class Initialized
INFO - 2018-05-19 05:44:33 --> Security Class Initialized
DEBUG - 2018-05-19 05:44:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 05:44:33 --> Input Class Initialized
INFO - 2018-05-19 05:44:33 --> Language Class Initialized
INFO - 2018-05-19 05:44:33 --> Language Class Initialized
INFO - 2018-05-19 05:44:33 --> Config Class Initialized
INFO - 2018-05-19 05:44:33 --> Loader Class Initialized
DEBUG - 2018-05-19 05:44:33 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-19 05:44:33 --> Helper loaded: url_helper
INFO - 2018-05-19 05:44:33 --> Helper loaded: form_helper
INFO - 2018-05-19 05:44:33 --> Helper loaded: date_helper
INFO - 2018-05-19 05:44:33 --> Helper loaded: util_helper
INFO - 2018-05-19 05:44:33 --> Helper loaded: text_helper
INFO - 2018-05-19 05:44:33 --> Helper loaded: string_helper
INFO - 2018-05-19 05:44:33 --> Database Driver Class Initialized
DEBUG - 2018-05-19 05:44:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-19 05:44:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-19 05:44:33 --> Email Class Initialized
INFO - 2018-05-19 05:44:33 --> Controller Class Initialized
DEBUG - 2018-05-19 05:44:33 --> Login MX_Controller Initialized
INFO - 2018-05-19 05:44:33 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-19 05:44:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-19 05:44:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
ERROR - 2018-05-19 05:44:33 --> Severity: Notice --> Undefined variable: name E:\xampp\htdocs\consulting\application\modules\common\views\common\templates\mail_view.php 1
DEBUG - 2018-05-19 05:44:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/templates/mail_view.php
DEBUG - 2018-05-19 05:44:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Mail_model.php
INFO - 2018-05-19 05:44:33 --> Helper loaded: file_helper
INFO - 2018-05-19 05:44:33 --> Login status gopaltesting077548@yopmail.com Successfully registered
INFO - 2018-05-19 05:44:33 --> Config Class Initialized
INFO - 2018-05-19 05:44:34 --> Hooks Class Initialized
DEBUG - 2018-05-19 05:44:34 --> UTF-8 Support Enabled
INFO - 2018-05-19 05:44:34 --> Utf8 Class Initialized
INFO - 2018-05-19 05:44:34 --> URI Class Initialized
INFO - 2018-05-19 05:44:34 --> Router Class Initialized
INFO - 2018-05-19 05:44:34 --> Output Class Initialized
INFO - 2018-05-19 05:44:34 --> Security Class Initialized
DEBUG - 2018-05-19 05:44:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 05:44:34 --> Input Class Initialized
INFO - 2018-05-19 05:44:34 --> Language Class Initialized
INFO - 2018-05-19 05:44:34 --> Language Class Initialized
INFO - 2018-05-19 05:44:34 --> Config Class Initialized
INFO - 2018-05-19 05:44:34 --> Loader Class Initialized
DEBUG - 2018-05-19 05:44:34 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-19 05:44:34 --> Helper loaded: url_helper
INFO - 2018-05-19 05:44:34 --> Helper loaded: form_helper
INFO - 2018-05-19 05:44:34 --> Helper loaded: date_helper
INFO - 2018-05-19 05:44:34 --> Helper loaded: util_helper
INFO - 2018-05-19 05:44:34 --> Helper loaded: text_helper
INFO - 2018-05-19 05:44:34 --> Helper loaded: string_helper
INFO - 2018-05-19 05:44:34 --> Database Driver Class Initialized
DEBUG - 2018-05-19 05:44:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-19 05:44:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-19 05:44:34 --> Email Class Initialized
INFO - 2018-05-19 05:44:34 --> Controller Class Initialized
DEBUG - 2018-05-19 05:44:34 --> Home MX_Controller Initialized
DEBUG - 2018-05-19 05:44:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-19 05:44:34 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-19 05:44:34 --> Login MX_Controller Initialized
INFO - 2018-05-19 05:44:34 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-19 05:44:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-19 05:44:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-19 05:44:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/login.php
INFO - 2018-05-19 05:44:39 --> Config Class Initialized
INFO - 2018-05-19 05:44:39 --> Hooks Class Initialized
DEBUG - 2018-05-19 05:44:39 --> UTF-8 Support Enabled
INFO - 2018-05-19 05:44:39 --> Utf8 Class Initialized
INFO - 2018-05-19 05:44:39 --> URI Class Initialized
INFO - 2018-05-19 05:44:39 --> Router Class Initialized
INFO - 2018-05-19 05:44:40 --> Output Class Initialized
INFO - 2018-05-19 05:44:40 --> Security Class Initialized
DEBUG - 2018-05-19 05:44:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 05:44:40 --> Input Class Initialized
INFO - 2018-05-19 05:44:40 --> Language Class Initialized
INFO - 2018-05-19 05:44:40 --> Language Class Initialized
INFO - 2018-05-19 05:44:40 --> Config Class Initialized
INFO - 2018-05-19 05:44:40 --> Loader Class Initialized
DEBUG - 2018-05-19 05:44:40 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-19 05:44:40 --> Helper loaded: url_helper
INFO - 2018-05-19 05:44:40 --> Helper loaded: form_helper
INFO - 2018-05-19 05:44:40 --> Helper loaded: date_helper
INFO - 2018-05-19 05:44:40 --> Helper loaded: util_helper
INFO - 2018-05-19 05:44:40 --> Helper loaded: text_helper
INFO - 2018-05-19 05:44:40 --> Helper loaded: string_helper
INFO - 2018-05-19 05:44:40 --> Database Driver Class Initialized
DEBUG - 2018-05-19 05:44:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-19 05:44:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-19 05:44:40 --> Email Class Initialized
INFO - 2018-05-19 05:44:40 --> Controller Class Initialized
DEBUG - 2018-05-19 05:44:40 --> Login MX_Controller Initialized
INFO - 2018-05-19 05:44:40 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-19 05:44:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-19 05:44:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-19 05:44:40 --> Email starts for gopaltesting077548@yopmail.com fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-05-19 05:44:40 --> Login status gopaltesting077548@yopmail.com - failure
INFO - 2018-05-19 05:44:40 --> Final output sent to browser
DEBUG - 2018-05-19 05:44:40 --> Total execution time: 0.3627
INFO - 2018-05-19 05:45:27 --> Config Class Initialized
INFO - 2018-05-19 05:45:27 --> Hooks Class Initialized
DEBUG - 2018-05-19 05:45:27 --> UTF-8 Support Enabled
INFO - 2018-05-19 05:45:27 --> Utf8 Class Initialized
INFO - 2018-05-19 05:45:27 --> URI Class Initialized
INFO - 2018-05-19 05:45:27 --> Router Class Initialized
INFO - 2018-05-19 05:45:27 --> Output Class Initialized
INFO - 2018-05-19 05:45:27 --> Security Class Initialized
DEBUG - 2018-05-19 05:45:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 05:45:27 --> Input Class Initialized
INFO - 2018-05-19 05:45:27 --> Language Class Initialized
INFO - 2018-05-19 05:45:27 --> Language Class Initialized
INFO - 2018-05-19 05:45:27 --> Config Class Initialized
INFO - 2018-05-19 05:45:27 --> Loader Class Initialized
DEBUG - 2018-05-19 05:45:28 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-19 05:45:28 --> Helper loaded: url_helper
INFO - 2018-05-19 05:45:28 --> Helper loaded: form_helper
INFO - 2018-05-19 05:45:28 --> Helper loaded: date_helper
INFO - 2018-05-19 05:45:28 --> Helper loaded: util_helper
INFO - 2018-05-19 05:45:28 --> Helper loaded: text_helper
INFO - 2018-05-19 05:45:28 --> Helper loaded: string_helper
INFO - 2018-05-19 05:45:28 --> Database Driver Class Initialized
DEBUG - 2018-05-19 05:45:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-19 05:45:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-19 05:45:28 --> Email Class Initialized
INFO - 2018-05-19 05:45:28 --> Controller Class Initialized
DEBUG - 2018-05-19 05:45:28 --> Home MX_Controller Initialized
DEBUG - 2018-05-19 05:45:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-19 05:45:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/register.php
INFO - 2018-05-19 05:45:28 --> Final output sent to browser
DEBUG - 2018-05-19 05:45:28 --> Total execution time: 0.4214
INFO - 2018-05-19 05:45:54 --> Config Class Initialized
INFO - 2018-05-19 05:45:54 --> Hooks Class Initialized
DEBUG - 2018-05-19 05:45:54 --> UTF-8 Support Enabled
INFO - 2018-05-19 05:45:54 --> Utf8 Class Initialized
INFO - 2018-05-19 05:45:55 --> URI Class Initialized
INFO - 2018-05-19 05:45:55 --> Router Class Initialized
INFO - 2018-05-19 05:45:55 --> Output Class Initialized
INFO - 2018-05-19 05:45:55 --> Security Class Initialized
DEBUG - 2018-05-19 05:45:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 05:45:55 --> Input Class Initialized
INFO - 2018-05-19 05:45:55 --> Language Class Initialized
INFO - 2018-05-19 05:45:55 --> Language Class Initialized
INFO - 2018-05-19 05:45:55 --> Config Class Initialized
INFO - 2018-05-19 05:45:55 --> Loader Class Initialized
DEBUG - 2018-05-19 05:45:55 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-19 05:45:55 --> Helper loaded: url_helper
INFO - 2018-05-19 05:45:55 --> Helper loaded: form_helper
INFO - 2018-05-19 05:45:55 --> Helper loaded: date_helper
INFO - 2018-05-19 05:45:55 --> Helper loaded: util_helper
INFO - 2018-05-19 05:45:55 --> Helper loaded: text_helper
INFO - 2018-05-19 05:45:55 --> Helper loaded: string_helper
INFO - 2018-05-19 05:45:55 --> Database Driver Class Initialized
DEBUG - 2018-05-19 05:45:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-19 05:45:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-19 05:45:55 --> Email Class Initialized
INFO - 2018-05-19 05:45:55 --> Controller Class Initialized
DEBUG - 2018-05-19 05:45:55 --> Login MX_Controller Initialized
INFO - 2018-05-19 05:45:55 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-19 05:45:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-19 05:45:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-19 05:46:10 --> Config Class Initialized
INFO - 2018-05-19 05:46:10 --> Hooks Class Initialized
DEBUG - 2018-05-19 05:46:10 --> UTF-8 Support Enabled
INFO - 2018-05-19 05:46:10 --> Utf8 Class Initialized
INFO - 2018-05-19 05:46:10 --> URI Class Initialized
INFO - 2018-05-19 05:46:10 --> Router Class Initialized
INFO - 2018-05-19 05:46:10 --> Output Class Initialized
INFO - 2018-05-19 05:46:10 --> Security Class Initialized
DEBUG - 2018-05-19 05:46:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 05:46:10 --> Input Class Initialized
INFO - 2018-05-19 05:46:10 --> Language Class Initialized
INFO - 2018-05-19 05:46:10 --> Language Class Initialized
INFO - 2018-05-19 05:46:10 --> Config Class Initialized
INFO - 2018-05-19 05:46:10 --> Loader Class Initialized
DEBUG - 2018-05-19 05:46:10 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-19 05:46:10 --> Helper loaded: url_helper
INFO - 2018-05-19 05:46:10 --> Helper loaded: form_helper
INFO - 2018-05-19 05:46:10 --> Helper loaded: date_helper
INFO - 2018-05-19 05:46:10 --> Helper loaded: util_helper
INFO - 2018-05-19 05:46:10 --> Helper loaded: text_helper
INFO - 2018-05-19 05:46:10 --> Helper loaded: string_helper
INFO - 2018-05-19 05:46:10 --> Database Driver Class Initialized
DEBUG - 2018-05-19 05:46:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-19 05:46:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-19 05:46:10 --> Email Class Initialized
INFO - 2018-05-19 05:46:10 --> Controller Class Initialized
DEBUG - 2018-05-19 05:46:10 --> Login MX_Controller Initialized
INFO - 2018-05-19 05:46:10 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-19 05:46:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-19 05:46:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-19 05:46:22 --> Config Class Initialized
INFO - 2018-05-19 05:46:22 --> Hooks Class Initialized
DEBUG - 2018-05-19 05:46:22 --> UTF-8 Support Enabled
INFO - 2018-05-19 05:46:22 --> Utf8 Class Initialized
INFO - 2018-05-19 05:46:22 --> URI Class Initialized
INFO - 2018-05-19 05:46:22 --> Router Class Initialized
INFO - 2018-05-19 05:46:22 --> Output Class Initialized
INFO - 2018-05-19 05:46:22 --> Security Class Initialized
DEBUG - 2018-05-19 05:46:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 05:46:22 --> Input Class Initialized
INFO - 2018-05-19 05:46:22 --> Language Class Initialized
INFO - 2018-05-19 05:46:22 --> Language Class Initialized
INFO - 2018-05-19 05:46:22 --> Config Class Initialized
INFO - 2018-05-19 05:46:22 --> Loader Class Initialized
DEBUG - 2018-05-19 05:46:22 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-19 05:46:22 --> Helper loaded: url_helper
INFO - 2018-05-19 05:46:22 --> Helper loaded: form_helper
INFO - 2018-05-19 05:46:22 --> Helper loaded: date_helper
INFO - 2018-05-19 05:46:22 --> Helper loaded: util_helper
INFO - 2018-05-19 05:46:22 --> Helper loaded: text_helper
INFO - 2018-05-19 05:46:22 --> Helper loaded: string_helper
INFO - 2018-05-19 05:46:22 --> Database Driver Class Initialized
DEBUG - 2018-05-19 05:46:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-19 05:46:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-19 05:46:22 --> Email Class Initialized
INFO - 2018-05-19 05:46:22 --> Controller Class Initialized
DEBUG - 2018-05-19 05:46:22 --> Login MX_Controller Initialized
INFO - 2018-05-19 05:46:22 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-19 05:46:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-19 05:46:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
ERROR - 2018-05-19 05:46:22 --> Severity: Notice --> Undefined variable: name E:\xampp\htdocs\consulting\application\modules\common\views\common\templates\mail_view.php 1
DEBUG - 2018-05-19 05:46:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/templates/mail_view.php
DEBUG - 2018-05-19 05:46:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Mail_model.php
INFO - 2018-05-19 05:46:22 --> Helper loaded: file_helper
INFO - 2018-05-19 05:46:22 --> Login status gopaltesting077548@yopmail.com Successfully registered
INFO - 2018-05-19 05:46:22 --> Config Class Initialized
INFO - 2018-05-19 05:46:22 --> Hooks Class Initialized
DEBUG - 2018-05-19 05:46:22 --> UTF-8 Support Enabled
INFO - 2018-05-19 05:46:22 --> Utf8 Class Initialized
INFO - 2018-05-19 05:46:22 --> URI Class Initialized
INFO - 2018-05-19 05:46:22 --> Router Class Initialized
INFO - 2018-05-19 05:46:23 --> Output Class Initialized
INFO - 2018-05-19 05:46:23 --> Security Class Initialized
DEBUG - 2018-05-19 05:46:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 05:46:23 --> Input Class Initialized
INFO - 2018-05-19 05:46:23 --> Language Class Initialized
INFO - 2018-05-19 05:46:23 --> Language Class Initialized
INFO - 2018-05-19 05:46:23 --> Config Class Initialized
INFO - 2018-05-19 05:46:23 --> Loader Class Initialized
DEBUG - 2018-05-19 05:46:23 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-19 05:46:23 --> Helper loaded: url_helper
INFO - 2018-05-19 05:46:23 --> Helper loaded: form_helper
INFO - 2018-05-19 05:46:23 --> Helper loaded: date_helper
INFO - 2018-05-19 05:46:23 --> Helper loaded: util_helper
INFO - 2018-05-19 05:46:23 --> Helper loaded: text_helper
INFO - 2018-05-19 05:46:23 --> Helper loaded: string_helper
INFO - 2018-05-19 05:46:23 --> Database Driver Class Initialized
DEBUG - 2018-05-19 05:46:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-19 05:46:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-19 05:46:23 --> Email Class Initialized
INFO - 2018-05-19 05:46:23 --> Controller Class Initialized
DEBUG - 2018-05-19 05:46:23 --> Home MX_Controller Initialized
DEBUG - 2018-05-19 05:46:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-19 05:46:23 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-19 05:46:23 --> Login MX_Controller Initialized
INFO - 2018-05-19 05:46:23 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-19 05:46:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-19 05:46:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-19 05:46:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/login.php
INFO - 2018-05-19 05:46:28 --> Config Class Initialized
INFO - 2018-05-19 05:46:28 --> Hooks Class Initialized
DEBUG - 2018-05-19 05:46:28 --> UTF-8 Support Enabled
INFO - 2018-05-19 05:46:28 --> Utf8 Class Initialized
INFO - 2018-05-19 05:46:28 --> URI Class Initialized
INFO - 2018-05-19 05:46:28 --> Router Class Initialized
INFO - 2018-05-19 05:46:28 --> Output Class Initialized
INFO - 2018-05-19 05:46:28 --> Security Class Initialized
DEBUG - 2018-05-19 05:46:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 05:46:28 --> Input Class Initialized
INFO - 2018-05-19 05:46:28 --> Language Class Initialized
INFO - 2018-05-19 05:46:28 --> Language Class Initialized
INFO - 2018-05-19 05:46:28 --> Config Class Initialized
INFO - 2018-05-19 05:46:28 --> Loader Class Initialized
DEBUG - 2018-05-19 05:46:28 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-19 05:46:28 --> Helper loaded: url_helper
INFO - 2018-05-19 05:46:28 --> Helper loaded: form_helper
INFO - 2018-05-19 05:46:28 --> Helper loaded: date_helper
INFO - 2018-05-19 05:46:29 --> Helper loaded: util_helper
INFO - 2018-05-19 05:46:29 --> Helper loaded: text_helper
INFO - 2018-05-19 05:46:29 --> Helper loaded: string_helper
INFO - 2018-05-19 05:46:29 --> Database Driver Class Initialized
DEBUG - 2018-05-19 05:46:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-19 05:46:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-19 05:46:29 --> Email Class Initialized
INFO - 2018-05-19 05:46:29 --> Controller Class Initialized
DEBUG - 2018-05-19 05:46:29 --> Login MX_Controller Initialized
INFO - 2018-05-19 05:46:29 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-19 05:46:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-19 05:46:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-19 05:46:29 --> Email starts for gopaltesting077548@yopmail.com fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-05-19 05:46:29 --> User session created for 33
INFO - 2018-05-19 05:46:29 --> Login status gopaltesting077548@yopmail.com - success
INFO - 2018-05-19 05:46:29 --> Final output sent to browser
DEBUG - 2018-05-19 05:46:29 --> Total execution time: 0.4505
INFO - 2018-05-19 05:46:29 --> Config Class Initialized
INFO - 2018-05-19 05:46:29 --> Hooks Class Initialized
DEBUG - 2018-05-19 05:46:29 --> UTF-8 Support Enabled
INFO - 2018-05-19 05:46:29 --> Utf8 Class Initialized
INFO - 2018-05-19 05:46:29 --> URI Class Initialized
INFO - 2018-05-19 05:46:29 --> Router Class Initialized
INFO - 2018-05-19 05:46:29 --> Output Class Initialized
INFO - 2018-05-19 05:46:29 --> Security Class Initialized
DEBUG - 2018-05-19 05:46:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 05:46:29 --> Input Class Initialized
INFO - 2018-05-19 05:46:29 --> Language Class Initialized
INFO - 2018-05-19 05:46:29 --> Language Class Initialized
INFO - 2018-05-19 05:46:29 --> Config Class Initialized
INFO - 2018-05-19 05:46:29 --> Loader Class Initialized
DEBUG - 2018-05-19 05:46:29 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-19 05:46:29 --> Helper loaded: url_helper
INFO - 2018-05-19 05:46:29 --> Helper loaded: form_helper
INFO - 2018-05-19 05:46:29 --> Helper loaded: date_helper
INFO - 2018-05-19 05:46:29 --> Helper loaded: util_helper
INFO - 2018-05-19 05:46:29 --> Helper loaded: text_helper
INFO - 2018-05-19 05:46:29 --> Helper loaded: string_helper
INFO - 2018-05-19 05:46:29 --> Database Driver Class Initialized
DEBUG - 2018-05-19 05:46:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-19 05:46:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-19 05:46:29 --> Email Class Initialized
INFO - 2018-05-19 05:46:29 --> Controller Class Initialized
DEBUG - 2018-05-19 05:46:29 --> Home MX_Controller Initialized
DEBUG - 2018-05-19 05:46:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-19 05:46:29 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-19 05:46:29 --> Login MX_Controller Initialized
INFO - 2018-05-19 05:46:29 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-19 05:46:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-19 05:46:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-19 05:46:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-19 05:46:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-19 05:46:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-19 05:46:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-19 05:46:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-19 05:46:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-05-19 05:46:29 --> Final output sent to browser
DEBUG - 2018-05-19 05:46:29 --> Total execution time: 0.5020
INFO - 2018-05-19 05:46:30 --> Config Class Initialized
INFO - 2018-05-19 05:46:30 --> Hooks Class Initialized
DEBUG - 2018-05-19 05:46:30 --> UTF-8 Support Enabled
INFO - 2018-05-19 05:46:30 --> Utf8 Class Initialized
INFO - 2018-05-19 05:46:30 --> URI Class Initialized
INFO - 2018-05-19 05:46:30 --> Router Class Initialized
INFO - 2018-05-19 05:46:30 --> Output Class Initialized
INFO - 2018-05-19 05:46:30 --> Security Class Initialized
DEBUG - 2018-05-19 05:46:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 05:46:30 --> Input Class Initialized
INFO - 2018-05-19 05:46:30 --> Language Class Initialized
ERROR - 2018-05-19 05:46:30 --> 404 Page Not Found: /index
INFO - 2018-05-19 05:46:30 --> Config Class Initialized
INFO - 2018-05-19 05:46:30 --> Hooks Class Initialized
DEBUG - 2018-05-19 05:46:30 --> UTF-8 Support Enabled
INFO - 2018-05-19 05:46:30 --> Utf8 Class Initialized
INFO - 2018-05-19 05:46:31 --> URI Class Initialized
INFO - 2018-05-19 05:46:31 --> Router Class Initialized
INFO - 2018-05-19 05:46:31 --> Config Class Initialized
INFO - 2018-05-19 05:46:31 --> Output Class Initialized
INFO - 2018-05-19 05:46:31 --> Hooks Class Initialized
DEBUG - 2018-05-19 05:46:31 --> UTF-8 Support Enabled
INFO - 2018-05-19 05:46:31 --> Utf8 Class Initialized
INFO - 2018-05-19 05:46:31 --> URI Class Initialized
INFO - 2018-05-19 05:46:31 --> Router Class Initialized
INFO - 2018-05-19 05:46:31 --> Security Class Initialized
INFO - 2018-05-19 05:46:31 --> Output Class Initialized
DEBUG - 2018-05-19 05:46:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 05:46:31 --> Security Class Initialized
DEBUG - 2018-05-19 05:46:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 05:46:31 --> Input Class Initialized
INFO - 2018-05-19 05:46:31 --> Input Class Initialized
INFO - 2018-05-19 05:46:31 --> Language Class Initialized
INFO - 2018-05-19 05:46:31 --> Language Class Initialized
ERROR - 2018-05-19 05:46:31 --> 404 Page Not Found: /index
ERROR - 2018-05-19 05:46:31 --> 404 Page Not Found: /index
INFO - 2018-05-19 05:46:31 --> Config Class Initialized
INFO - 2018-05-19 05:46:31 --> Config Class Initialized
INFO - 2018-05-19 05:46:31 --> Hooks Class Initialized
INFO - 2018-05-19 05:46:31 --> Hooks Class Initialized
DEBUG - 2018-05-19 05:46:31 --> UTF-8 Support Enabled
DEBUG - 2018-05-19 05:46:31 --> UTF-8 Support Enabled
INFO - 2018-05-19 05:46:31 --> Utf8 Class Initialized
INFO - 2018-05-19 05:46:31 --> URI Class Initialized
INFO - 2018-05-19 05:46:31 --> Utf8 Class Initialized
INFO - 2018-05-19 05:46:31 --> Router Class Initialized
INFO - 2018-05-19 05:46:31 --> Output Class Initialized
INFO - 2018-05-19 05:46:31 --> URI Class Initialized
INFO - 2018-05-19 05:46:31 --> Security Class Initialized
INFO - 2018-05-19 05:46:31 --> Router Class Initialized
DEBUG - 2018-05-19 05:46:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 05:46:31 --> Output Class Initialized
INFO - 2018-05-19 05:46:31 --> Input Class Initialized
INFO - 2018-05-19 05:46:31 --> Security Class Initialized
INFO - 2018-05-19 05:46:31 --> Language Class Initialized
DEBUG - 2018-05-19 05:46:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-05-19 05:46:31 --> 404 Page Not Found: /index
INFO - 2018-05-19 05:46:31 --> Input Class Initialized
INFO - 2018-05-19 05:46:31 --> Language Class Initialized
INFO - 2018-05-19 05:46:31 --> Config Class Initialized
ERROR - 2018-05-19 05:46:32 --> 404 Page Not Found: /index
INFO - 2018-05-19 05:46:32 --> Hooks Class Initialized
DEBUG - 2018-05-19 05:46:32 --> UTF-8 Support Enabled
INFO - 2018-05-19 05:46:32 --> Utf8 Class Initialized
INFO - 2018-05-19 05:46:32 --> URI Class Initialized
INFO - 2018-05-19 05:46:32 --> Router Class Initialized
INFO - 2018-05-19 05:46:32 --> Output Class Initialized
INFO - 2018-05-19 05:46:32 --> Security Class Initialized
DEBUG - 2018-05-19 05:46:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 05:46:32 --> Input Class Initialized
INFO - 2018-05-19 05:46:32 --> Language Class Initialized
ERROR - 2018-05-19 05:46:32 --> 404 Page Not Found: /index
INFO - 2018-05-19 05:46:32 --> Config Class Initialized
INFO - 2018-05-19 05:46:32 --> Hooks Class Initialized
DEBUG - 2018-05-19 05:46:32 --> UTF-8 Support Enabled
INFO - 2018-05-19 05:46:32 --> Utf8 Class Initialized
INFO - 2018-05-19 05:46:32 --> URI Class Initialized
INFO - 2018-05-19 05:46:32 --> Router Class Initialized
INFO - 2018-05-19 05:46:32 --> Output Class Initialized
INFO - 2018-05-19 05:46:32 --> Security Class Initialized
DEBUG - 2018-05-19 05:46:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 05:46:32 --> Input Class Initialized
INFO - 2018-05-19 05:46:32 --> Language Class Initialized
ERROR - 2018-05-19 05:46:32 --> 404 Page Not Found: /index
INFO - 2018-05-19 05:46:32 --> Config Class Initialized
INFO - 2018-05-19 05:46:32 --> Hooks Class Initialized
DEBUG - 2018-05-19 05:46:32 --> UTF-8 Support Enabled
INFO - 2018-05-19 05:46:32 --> Utf8 Class Initialized
INFO - 2018-05-19 05:46:32 --> URI Class Initialized
INFO - 2018-05-19 05:46:32 --> Router Class Initialized
INFO - 2018-05-19 05:46:32 --> Output Class Initialized
INFO - 2018-05-19 05:46:33 --> Security Class Initialized
DEBUG - 2018-05-19 05:46:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 05:46:33 --> Input Class Initialized
INFO - 2018-05-19 05:46:33 --> Language Class Initialized
ERROR - 2018-05-19 05:46:33 --> 404 Page Not Found: /index
INFO - 2018-05-19 05:46:33 --> Config Class Initialized
INFO - 2018-05-19 05:46:33 --> Hooks Class Initialized
DEBUG - 2018-05-19 05:46:33 --> UTF-8 Support Enabled
INFO - 2018-05-19 05:46:33 --> Utf8 Class Initialized
INFO - 2018-05-19 05:46:33 --> URI Class Initialized
INFO - 2018-05-19 05:46:33 --> Router Class Initialized
INFO - 2018-05-19 05:46:33 --> Output Class Initialized
INFO - 2018-05-19 05:46:33 --> Security Class Initialized
DEBUG - 2018-05-19 05:46:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 05:46:33 --> Input Class Initialized
INFO - 2018-05-19 05:46:33 --> Language Class Initialized
ERROR - 2018-05-19 05:46:33 --> 404 Page Not Found: /index
INFO - 2018-05-19 05:46:33 --> Config Class Initialized
INFO - 2018-05-19 05:46:33 --> Hooks Class Initialized
DEBUG - 2018-05-19 05:46:33 --> UTF-8 Support Enabled
INFO - 2018-05-19 05:46:33 --> Utf8 Class Initialized
INFO - 2018-05-19 05:46:33 --> URI Class Initialized
INFO - 2018-05-19 05:46:33 --> Router Class Initialized
INFO - 2018-05-19 05:46:33 --> Output Class Initialized
INFO - 2018-05-19 05:46:33 --> Security Class Initialized
DEBUG - 2018-05-19 05:46:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 05:46:33 --> Input Class Initialized
INFO - 2018-05-19 05:46:33 --> Language Class Initialized
ERROR - 2018-05-19 05:46:33 --> 404 Page Not Found: /index
INFO - 2018-05-19 05:46:37 --> Config Class Initialized
INFO - 2018-05-19 05:46:37 --> Hooks Class Initialized
DEBUG - 2018-05-19 05:46:37 --> UTF-8 Support Enabled
INFO - 2018-05-19 05:46:37 --> Utf8 Class Initialized
INFO - 2018-05-19 05:46:37 --> URI Class Initialized
INFO - 2018-05-19 05:46:37 --> Router Class Initialized
INFO - 2018-05-19 05:46:37 --> Output Class Initialized
INFO - 2018-05-19 05:46:37 --> Security Class Initialized
DEBUG - 2018-05-19 05:46:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 05:46:37 --> Input Class Initialized
INFO - 2018-05-19 05:46:37 --> Language Class Initialized
INFO - 2018-05-19 05:46:37 --> Language Class Initialized
INFO - 2018-05-19 05:46:37 --> Config Class Initialized
INFO - 2018-05-19 05:46:37 --> Loader Class Initialized
DEBUG - 2018-05-19 05:46:37 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-19 05:46:37 --> Helper loaded: url_helper
INFO - 2018-05-19 05:46:37 --> Helper loaded: form_helper
INFO - 2018-05-19 05:46:37 --> Helper loaded: date_helper
INFO - 2018-05-19 05:46:37 --> Helper loaded: util_helper
INFO - 2018-05-19 05:46:37 --> Helper loaded: text_helper
INFO - 2018-05-19 05:46:37 --> Helper loaded: string_helper
INFO - 2018-05-19 05:46:37 --> Database Driver Class Initialized
DEBUG - 2018-05-19 05:46:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-19 05:46:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-19 05:46:37 --> Email Class Initialized
INFO - 2018-05-19 05:46:37 --> Controller Class Initialized
DEBUG - 2018-05-19 05:46:37 --> Home MX_Controller Initialized
DEBUG - 2018-05-19 05:46:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-19 05:46:37 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-19 05:46:37 --> Login MX_Controller Initialized
INFO - 2018-05-19 05:46:37 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-19 05:46:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-19 05:46:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-19 05:46:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-19 05:46:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-19 05:46:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-19 05:46:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-19 05:46:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-19 05:46:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-05-19 05:46:37 --> Final output sent to browser
DEBUG - 2018-05-19 05:46:37 --> Total execution time: 0.4922
INFO - 2018-05-19 05:46:37 --> Config Class Initialized
INFO - 2018-05-19 05:46:37 --> Hooks Class Initialized
DEBUG - 2018-05-19 05:46:37 --> UTF-8 Support Enabled
INFO - 2018-05-19 05:46:37 --> Utf8 Class Initialized
INFO - 2018-05-19 05:46:38 --> URI Class Initialized
INFO - 2018-05-19 05:46:38 --> Router Class Initialized
INFO - 2018-05-19 05:46:38 --> Output Class Initialized
INFO - 2018-05-19 05:46:38 --> Security Class Initialized
DEBUG - 2018-05-19 05:46:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 05:46:38 --> Input Class Initialized
INFO - 2018-05-19 05:46:38 --> Language Class Initialized
ERROR - 2018-05-19 05:46:38 --> 404 Page Not Found: /index
INFO - 2018-05-19 05:46:38 --> Config Class Initialized
INFO - 2018-05-19 05:46:38 --> Hooks Class Initialized
DEBUG - 2018-05-19 05:46:38 --> UTF-8 Support Enabled
INFO - 2018-05-19 05:46:38 --> Utf8 Class Initialized
INFO - 2018-05-19 05:46:38 --> URI Class Initialized
INFO - 2018-05-19 05:46:38 --> Router Class Initialized
INFO - 2018-05-19 05:46:38 --> Output Class Initialized
INFO - 2018-05-19 05:46:38 --> Security Class Initialized
DEBUG - 2018-05-19 05:46:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 05:46:38 --> Input Class Initialized
INFO - 2018-05-19 05:46:38 --> Language Class Initialized
ERROR - 2018-05-19 05:46:38 --> 404 Page Not Found: /index
INFO - 2018-05-19 05:46:38 --> Config Class Initialized
INFO - 2018-05-19 05:46:38 --> Hooks Class Initialized
DEBUG - 2018-05-19 05:46:38 --> UTF-8 Support Enabled
INFO - 2018-05-19 05:46:38 --> Utf8 Class Initialized
INFO - 2018-05-19 05:46:38 --> URI Class Initialized
INFO - 2018-05-19 05:46:38 --> Router Class Initialized
INFO - 2018-05-19 05:46:38 --> Output Class Initialized
INFO - 2018-05-19 05:46:38 --> Security Class Initialized
DEBUG - 2018-05-19 05:46:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 05:46:38 --> Input Class Initialized
INFO - 2018-05-19 05:46:38 --> Language Class Initialized
ERROR - 2018-05-19 05:46:38 --> 404 Page Not Found: /index
INFO - 2018-05-19 05:46:39 --> Config Class Initialized
INFO - 2018-05-19 05:46:39 --> Hooks Class Initialized
DEBUG - 2018-05-19 05:46:39 --> UTF-8 Support Enabled
INFO - 2018-05-19 05:46:39 --> Utf8 Class Initialized
INFO - 2018-05-19 05:46:39 --> URI Class Initialized
INFO - 2018-05-19 05:46:39 --> Router Class Initialized
INFO - 2018-05-19 05:46:39 --> Output Class Initialized
INFO - 2018-05-19 05:46:39 --> Security Class Initialized
DEBUG - 2018-05-19 05:46:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 05:46:39 --> Input Class Initialized
INFO - 2018-05-19 05:46:39 --> Language Class Initialized
INFO - 2018-05-19 05:46:39 --> Language Class Initialized
INFO - 2018-05-19 05:46:39 --> Config Class Initialized
INFO - 2018-05-19 05:46:39 --> Loader Class Initialized
DEBUG - 2018-05-19 05:46:39 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-19 05:46:39 --> Helper loaded: url_helper
INFO - 2018-05-19 05:46:39 --> Helper loaded: form_helper
INFO - 2018-05-19 05:46:40 --> Helper loaded: date_helper
INFO - 2018-05-19 05:46:40 --> Helper loaded: util_helper
INFO - 2018-05-19 05:46:40 --> Helper loaded: text_helper
INFO - 2018-05-19 05:46:40 --> Helper loaded: string_helper
INFO - 2018-05-19 05:46:40 --> Database Driver Class Initialized
DEBUG - 2018-05-19 05:46:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-19 05:46:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-19 05:46:40 --> Email Class Initialized
INFO - 2018-05-19 05:46:40 --> Controller Class Initialized
DEBUG - 2018-05-19 05:46:40 --> Home MX_Controller Initialized
DEBUG - 2018-05-19 05:46:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-19 05:46:40 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-19 05:46:40 --> Login MX_Controller Initialized
INFO - 2018-05-19 05:46:40 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-19 05:46:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-19 05:46:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-19 05:46:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-19 05:46:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-19 05:46:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-19 05:46:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-19 05:46:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-19 05:46:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/progress.php
INFO - 2018-05-19 05:46:40 --> Final output sent to browser
DEBUG - 2018-05-19 05:46:40 --> Total execution time: 0.5462
INFO - 2018-05-19 05:46:40 --> Config Class Initialized
INFO - 2018-05-19 05:46:40 --> Hooks Class Initialized
DEBUG - 2018-05-19 05:46:40 --> UTF-8 Support Enabled
INFO - 2018-05-19 05:46:40 --> Utf8 Class Initialized
INFO - 2018-05-19 05:46:40 --> URI Class Initialized
INFO - 2018-05-19 05:46:40 --> Router Class Initialized
INFO - 2018-05-19 05:46:40 --> Output Class Initialized
INFO - 2018-05-19 05:46:40 --> Security Class Initialized
DEBUG - 2018-05-19 05:46:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 05:46:40 --> Input Class Initialized
INFO - 2018-05-19 05:46:40 --> Language Class Initialized
ERROR - 2018-05-19 05:46:40 --> 404 Page Not Found: /index
INFO - 2018-05-19 05:46:41 --> Config Class Initialized
INFO - 2018-05-19 05:46:41 --> Hooks Class Initialized
DEBUG - 2018-05-19 05:46:41 --> UTF-8 Support Enabled
INFO - 2018-05-19 05:46:41 --> Utf8 Class Initialized
INFO - 2018-05-19 05:46:41 --> URI Class Initialized
INFO - 2018-05-19 05:46:41 --> Router Class Initialized
INFO - 2018-05-19 05:46:41 --> Output Class Initialized
INFO - 2018-05-19 05:46:41 --> Security Class Initialized
DEBUG - 2018-05-19 05:46:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 05:46:41 --> Input Class Initialized
INFO - 2018-05-19 05:46:41 --> Language Class Initialized
ERROR - 2018-05-19 05:46:41 --> 404 Page Not Found: /index
INFO - 2018-05-19 05:46:41 --> Config Class Initialized
INFO - 2018-05-19 05:46:41 --> Hooks Class Initialized
DEBUG - 2018-05-19 05:46:41 --> UTF-8 Support Enabled
INFO - 2018-05-19 05:46:41 --> Utf8 Class Initialized
INFO - 2018-05-19 05:46:41 --> URI Class Initialized
INFO - 2018-05-19 05:46:41 --> Router Class Initialized
INFO - 2018-05-19 05:46:41 --> Output Class Initialized
INFO - 2018-05-19 05:46:41 --> Security Class Initialized
DEBUG - 2018-05-19 05:46:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 05:46:41 --> Input Class Initialized
INFO - 2018-05-19 05:46:41 --> Language Class Initialized
ERROR - 2018-05-19 05:46:41 --> 404 Page Not Found: /index
INFO - 2018-05-19 05:48:07 --> Config Class Initialized
INFO - 2018-05-19 05:48:07 --> Hooks Class Initialized
DEBUG - 2018-05-19 05:48:07 --> UTF-8 Support Enabled
INFO - 2018-05-19 05:48:07 --> Utf8 Class Initialized
INFO - 2018-05-19 05:48:07 --> URI Class Initialized
INFO - 2018-05-19 05:48:07 --> Router Class Initialized
INFO - 2018-05-19 05:48:07 --> Output Class Initialized
INFO - 2018-05-19 05:48:07 --> Security Class Initialized
DEBUG - 2018-05-19 05:48:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 05:48:07 --> Input Class Initialized
INFO - 2018-05-19 05:48:07 --> Language Class Initialized
ERROR - 2018-05-19 05:48:07 --> 404 Page Not Found: /index
INFO - 2018-05-19 05:48:08 --> Config Class Initialized
INFO - 2018-05-19 05:48:08 --> Hooks Class Initialized
DEBUG - 2018-05-19 05:48:08 --> UTF-8 Support Enabled
INFO - 2018-05-19 05:48:08 --> Utf8 Class Initialized
INFO - 2018-05-19 05:48:08 --> URI Class Initialized
INFO - 2018-05-19 05:48:08 --> Router Class Initialized
INFO - 2018-05-19 05:48:08 --> Output Class Initialized
INFO - 2018-05-19 05:48:08 --> Security Class Initialized
DEBUG - 2018-05-19 05:48:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 05:48:08 --> Input Class Initialized
INFO - 2018-05-19 05:48:08 --> Language Class Initialized
ERROR - 2018-05-19 05:48:08 --> 404 Page Not Found: /index
INFO - 2018-05-19 05:48:08 --> Config Class Initialized
INFO - 2018-05-19 05:48:08 --> Hooks Class Initialized
DEBUG - 2018-05-19 05:48:09 --> UTF-8 Support Enabled
INFO - 2018-05-19 05:48:09 --> Utf8 Class Initialized
INFO - 2018-05-19 05:48:09 --> URI Class Initialized
INFO - 2018-05-19 05:48:09 --> Router Class Initialized
INFO - 2018-05-19 05:48:09 --> Output Class Initialized
INFO - 2018-05-19 05:48:09 --> Security Class Initialized
DEBUG - 2018-05-19 05:48:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 05:48:09 --> Input Class Initialized
INFO - 2018-05-19 05:48:09 --> Language Class Initialized
ERROR - 2018-05-19 05:48:09 --> 404 Page Not Found: /index
INFO - 2018-05-19 05:48:26 --> Config Class Initialized
INFO - 2018-05-19 05:48:26 --> Hooks Class Initialized
DEBUG - 2018-05-19 05:48:26 --> UTF-8 Support Enabled
INFO - 2018-05-19 05:48:26 --> Utf8 Class Initialized
INFO - 2018-05-19 05:48:26 --> URI Class Initialized
INFO - 2018-05-19 05:48:26 --> Router Class Initialized
INFO - 2018-05-19 05:48:26 --> Output Class Initialized
INFO - 2018-05-19 05:48:26 --> Security Class Initialized
DEBUG - 2018-05-19 05:48:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 05:48:27 --> Input Class Initialized
INFO - 2018-05-19 05:48:27 --> Language Class Initialized
ERROR - 2018-05-19 05:48:27 --> 404 Page Not Found: /index
INFO - 2018-05-19 05:48:27 --> Config Class Initialized
INFO - 2018-05-19 05:48:27 --> Hooks Class Initialized
DEBUG - 2018-05-19 05:48:27 --> UTF-8 Support Enabled
INFO - 2018-05-19 05:48:27 --> Utf8 Class Initialized
INFO - 2018-05-19 05:48:27 --> URI Class Initialized
INFO - 2018-05-19 05:48:27 --> Router Class Initialized
INFO - 2018-05-19 05:48:27 --> Output Class Initialized
INFO - 2018-05-19 05:48:27 --> Security Class Initialized
DEBUG - 2018-05-19 05:48:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 05:48:27 --> Input Class Initialized
INFO - 2018-05-19 05:48:27 --> Language Class Initialized
ERROR - 2018-05-19 05:48:27 --> 404 Page Not Found: /index
INFO - 2018-05-19 05:48:27 --> Config Class Initialized
INFO - 2018-05-19 05:48:27 --> Hooks Class Initialized
DEBUG - 2018-05-19 05:48:27 --> UTF-8 Support Enabled
INFO - 2018-05-19 05:48:27 --> Utf8 Class Initialized
INFO - 2018-05-19 05:48:27 --> URI Class Initialized
INFO - 2018-05-19 05:48:27 --> Router Class Initialized
INFO - 2018-05-19 05:48:27 --> Output Class Initialized
INFO - 2018-05-19 05:48:27 --> Security Class Initialized
DEBUG - 2018-05-19 05:48:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 05:48:27 --> Input Class Initialized
INFO - 2018-05-19 05:48:27 --> Language Class Initialized
ERROR - 2018-05-19 05:48:27 --> 404 Page Not Found: /index
INFO - 2018-05-19 05:48:51 --> Config Class Initialized
INFO - 2018-05-19 05:48:51 --> Hooks Class Initialized
DEBUG - 2018-05-19 05:48:51 --> UTF-8 Support Enabled
INFO - 2018-05-19 05:48:51 --> Utf8 Class Initialized
INFO - 2018-05-19 05:48:51 --> URI Class Initialized
INFO - 2018-05-19 05:48:51 --> Router Class Initialized
INFO - 2018-05-19 05:48:51 --> Output Class Initialized
INFO - 2018-05-19 05:48:51 --> Security Class Initialized
DEBUG - 2018-05-19 05:48:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 05:48:51 --> Input Class Initialized
INFO - 2018-05-19 05:48:51 --> Language Class Initialized
ERROR - 2018-05-19 05:48:51 --> 404 Page Not Found: /index
INFO - 2018-05-19 05:48:51 --> Config Class Initialized
INFO - 2018-05-19 05:48:51 --> Hooks Class Initialized
DEBUG - 2018-05-19 05:48:51 --> UTF-8 Support Enabled
INFO - 2018-05-19 05:48:51 --> Utf8 Class Initialized
INFO - 2018-05-19 05:48:51 --> URI Class Initialized
INFO - 2018-05-19 05:48:51 --> Router Class Initialized
INFO - 2018-05-19 05:48:51 --> Output Class Initialized
INFO - 2018-05-19 05:48:51 --> Security Class Initialized
DEBUG - 2018-05-19 05:48:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 05:48:51 --> Input Class Initialized
INFO - 2018-05-19 05:48:51 --> Language Class Initialized
ERROR - 2018-05-19 05:48:51 --> 404 Page Not Found: /index
INFO - 2018-05-19 05:48:51 --> Config Class Initialized
INFO - 2018-05-19 05:48:51 --> Hooks Class Initialized
DEBUG - 2018-05-19 05:48:51 --> UTF-8 Support Enabled
INFO - 2018-05-19 05:48:51 --> Utf8 Class Initialized
INFO - 2018-05-19 05:48:51 --> URI Class Initialized
INFO - 2018-05-19 05:48:51 --> Router Class Initialized
INFO - 2018-05-19 05:48:51 --> Output Class Initialized
INFO - 2018-05-19 05:48:51 --> Security Class Initialized
DEBUG - 2018-05-19 05:48:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 05:48:52 --> Input Class Initialized
INFO - 2018-05-19 05:48:52 --> Language Class Initialized
ERROR - 2018-05-19 05:48:52 --> 404 Page Not Found: /index
INFO - 2018-05-19 05:49:55 --> Config Class Initialized
INFO - 2018-05-19 05:49:55 --> Hooks Class Initialized
DEBUG - 2018-05-19 05:49:55 --> UTF-8 Support Enabled
INFO - 2018-05-19 05:49:55 --> Utf8 Class Initialized
INFO - 2018-05-19 05:49:55 --> URI Class Initialized
INFO - 2018-05-19 05:49:55 --> Router Class Initialized
INFO - 2018-05-19 05:49:55 --> Output Class Initialized
INFO - 2018-05-19 05:49:55 --> Security Class Initialized
DEBUG - 2018-05-19 05:49:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 05:49:55 --> Input Class Initialized
INFO - 2018-05-19 05:49:55 --> Language Class Initialized
INFO - 2018-05-19 05:49:55 --> Language Class Initialized
INFO - 2018-05-19 05:49:56 --> Config Class Initialized
INFO - 2018-05-19 05:49:56 --> Loader Class Initialized
DEBUG - 2018-05-19 05:49:56 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-19 05:49:56 --> Helper loaded: url_helper
INFO - 2018-05-19 05:49:56 --> Helper loaded: form_helper
INFO - 2018-05-19 05:49:56 --> Helper loaded: date_helper
INFO - 2018-05-19 05:49:56 --> Helper loaded: util_helper
INFO - 2018-05-19 05:49:56 --> Helper loaded: text_helper
INFO - 2018-05-19 05:49:56 --> Helper loaded: string_helper
INFO - 2018-05-19 05:49:56 --> Database Driver Class Initialized
DEBUG - 2018-05-19 05:49:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-19 05:49:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-19 05:49:56 --> Email Class Initialized
INFO - 2018-05-19 05:49:56 --> Controller Class Initialized
DEBUG - 2018-05-19 05:49:56 --> Home MX_Controller Initialized
DEBUG - 2018-05-19 05:49:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-19 05:49:56 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-19 05:49:56 --> Login MX_Controller Initialized
INFO - 2018-05-19 05:49:56 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-19 05:49:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-19 05:49:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-19 05:49:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-19 05:49:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-19 05:49:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-19 05:49:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-19 05:49:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-19 05:49:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/progress.php
INFO - 2018-05-19 05:49:56 --> Final output sent to browser
DEBUG - 2018-05-19 05:49:56 --> Total execution time: 0.5177
INFO - 2018-05-19 05:49:56 --> Config Class Initialized
INFO - 2018-05-19 05:49:56 --> Hooks Class Initialized
DEBUG - 2018-05-19 05:49:56 --> UTF-8 Support Enabled
INFO - 2018-05-19 05:49:56 --> Utf8 Class Initialized
INFO - 2018-05-19 05:49:56 --> URI Class Initialized
INFO - 2018-05-19 05:49:56 --> Router Class Initialized
INFO - 2018-05-19 05:49:56 --> Output Class Initialized
INFO - 2018-05-19 05:49:56 --> Security Class Initialized
DEBUG - 2018-05-19 05:49:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 05:49:56 --> Input Class Initialized
INFO - 2018-05-19 05:49:57 --> Language Class Initialized
ERROR - 2018-05-19 05:49:57 --> 404 Page Not Found: /index
INFO - 2018-05-19 05:49:57 --> Config Class Initialized
INFO - 2018-05-19 05:49:57 --> Hooks Class Initialized
DEBUG - 2018-05-19 05:49:57 --> UTF-8 Support Enabled
INFO - 2018-05-19 05:49:57 --> Utf8 Class Initialized
INFO - 2018-05-19 05:49:57 --> URI Class Initialized
INFO - 2018-05-19 05:49:57 --> Router Class Initialized
INFO - 2018-05-19 05:49:57 --> Output Class Initialized
INFO - 2018-05-19 05:49:57 --> Security Class Initialized
DEBUG - 2018-05-19 05:49:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 05:49:57 --> Input Class Initialized
INFO - 2018-05-19 05:49:57 --> Language Class Initialized
ERROR - 2018-05-19 05:49:57 --> 404 Page Not Found: /index
INFO - 2018-05-19 05:49:57 --> Config Class Initialized
INFO - 2018-05-19 05:49:57 --> Hooks Class Initialized
DEBUG - 2018-05-19 05:49:57 --> UTF-8 Support Enabled
INFO - 2018-05-19 05:49:57 --> Utf8 Class Initialized
INFO - 2018-05-19 05:49:57 --> URI Class Initialized
INFO - 2018-05-19 05:49:57 --> Router Class Initialized
INFO - 2018-05-19 05:49:57 --> Output Class Initialized
INFO - 2018-05-19 05:49:57 --> Security Class Initialized
DEBUG - 2018-05-19 05:49:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 05:49:57 --> Input Class Initialized
INFO - 2018-05-19 05:49:57 --> Language Class Initialized
ERROR - 2018-05-19 05:49:57 --> 404 Page Not Found: /index
INFO - 2018-05-19 05:51:41 --> Config Class Initialized
INFO - 2018-05-19 05:51:41 --> Hooks Class Initialized
DEBUG - 2018-05-19 05:51:41 --> UTF-8 Support Enabled
INFO - 2018-05-19 05:51:41 --> Utf8 Class Initialized
INFO - 2018-05-19 05:51:41 --> URI Class Initialized
INFO - 2018-05-19 05:51:41 --> Router Class Initialized
INFO - 2018-05-19 05:51:41 --> Output Class Initialized
INFO - 2018-05-19 05:51:41 --> Security Class Initialized
DEBUG - 2018-05-19 05:51:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 05:51:41 --> Input Class Initialized
INFO - 2018-05-19 05:51:41 --> Language Class Initialized
ERROR - 2018-05-19 05:51:41 --> 404 Page Not Found: /index
INFO - 2018-05-19 05:51:41 --> Config Class Initialized
INFO - 2018-05-19 05:51:41 --> Hooks Class Initialized
DEBUG - 2018-05-19 05:51:41 --> UTF-8 Support Enabled
INFO - 2018-05-19 05:51:41 --> Utf8 Class Initialized
INFO - 2018-05-19 05:51:41 --> URI Class Initialized
INFO - 2018-05-19 05:51:41 --> Router Class Initialized
INFO - 2018-05-19 05:51:41 --> Output Class Initialized
INFO - 2018-05-19 05:51:41 --> Security Class Initialized
DEBUG - 2018-05-19 05:51:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 05:51:42 --> Input Class Initialized
INFO - 2018-05-19 05:51:42 --> Language Class Initialized
ERROR - 2018-05-19 05:51:42 --> 404 Page Not Found: /index
INFO - 2018-05-19 05:51:42 --> Config Class Initialized
INFO - 2018-05-19 05:51:42 --> Hooks Class Initialized
DEBUG - 2018-05-19 05:51:42 --> UTF-8 Support Enabled
INFO - 2018-05-19 05:51:42 --> Utf8 Class Initialized
INFO - 2018-05-19 05:51:42 --> URI Class Initialized
INFO - 2018-05-19 05:51:42 --> Router Class Initialized
INFO - 2018-05-19 05:51:42 --> Output Class Initialized
INFO - 2018-05-19 05:51:42 --> Security Class Initialized
DEBUG - 2018-05-19 05:51:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 05:51:42 --> Input Class Initialized
INFO - 2018-05-19 05:51:42 --> Language Class Initialized
ERROR - 2018-05-19 05:51:42 --> 404 Page Not Found: /index
INFO - 2018-05-19 05:53:53 --> Config Class Initialized
INFO - 2018-05-19 05:53:53 --> Hooks Class Initialized
DEBUG - 2018-05-19 05:53:53 --> UTF-8 Support Enabled
INFO - 2018-05-19 05:53:53 --> Utf8 Class Initialized
INFO - 2018-05-19 05:53:54 --> URI Class Initialized
INFO - 2018-05-19 05:53:54 --> Router Class Initialized
INFO - 2018-05-19 05:53:54 --> Output Class Initialized
INFO - 2018-05-19 05:53:54 --> Security Class Initialized
DEBUG - 2018-05-19 05:53:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 05:53:54 --> Input Class Initialized
INFO - 2018-05-19 05:53:54 --> Language Class Initialized
INFO - 2018-05-19 05:53:54 --> Language Class Initialized
INFO - 2018-05-19 05:53:54 --> Config Class Initialized
INFO - 2018-05-19 05:53:54 --> Loader Class Initialized
DEBUG - 2018-05-19 05:53:54 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-19 05:53:54 --> Helper loaded: url_helper
INFO - 2018-05-19 05:53:54 --> Helper loaded: form_helper
INFO - 2018-05-19 05:53:54 --> Helper loaded: date_helper
INFO - 2018-05-19 05:53:54 --> Helper loaded: util_helper
INFO - 2018-05-19 05:53:54 --> Helper loaded: text_helper
INFO - 2018-05-19 05:53:54 --> Helper loaded: string_helper
INFO - 2018-05-19 05:53:54 --> Database Driver Class Initialized
DEBUG - 2018-05-19 05:53:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-19 05:53:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-19 05:53:54 --> Email Class Initialized
INFO - 2018-05-19 05:53:54 --> Controller Class Initialized
DEBUG - 2018-05-19 05:53:54 --> Home MX_Controller Initialized
DEBUG - 2018-05-19 05:53:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-19 05:53:54 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-19 05:53:54 --> Login MX_Controller Initialized
INFO - 2018-05-19 05:53:54 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-19 05:53:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-19 05:53:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-19 05:53:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-19 05:53:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-19 05:53:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-19 05:53:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-19 05:53:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-19 05:53:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/progress.php
INFO - 2018-05-19 05:53:54 --> Final output sent to browser
DEBUG - 2018-05-19 05:53:54 --> Total execution time: 0.5228
INFO - 2018-05-19 05:53:54 --> Config Class Initialized
INFO - 2018-05-19 05:53:54 --> Hooks Class Initialized
DEBUG - 2018-05-19 05:53:54 --> UTF-8 Support Enabled
INFO - 2018-05-19 05:53:54 --> Utf8 Class Initialized
INFO - 2018-05-19 05:53:54 --> URI Class Initialized
INFO - 2018-05-19 05:53:55 --> Router Class Initialized
INFO - 2018-05-19 05:53:55 --> Output Class Initialized
INFO - 2018-05-19 05:53:55 --> Security Class Initialized
DEBUG - 2018-05-19 05:53:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 05:53:55 --> Input Class Initialized
INFO - 2018-05-19 05:53:55 --> Language Class Initialized
ERROR - 2018-05-19 05:53:55 --> 404 Page Not Found: /index
INFO - 2018-05-19 05:53:55 --> Config Class Initialized
INFO - 2018-05-19 05:53:55 --> Hooks Class Initialized
DEBUG - 2018-05-19 05:53:55 --> UTF-8 Support Enabled
INFO - 2018-05-19 05:53:55 --> Utf8 Class Initialized
INFO - 2018-05-19 05:53:55 --> URI Class Initialized
INFO - 2018-05-19 05:53:55 --> Router Class Initialized
INFO - 2018-05-19 05:53:55 --> Output Class Initialized
INFO - 2018-05-19 05:53:55 --> Security Class Initialized
DEBUG - 2018-05-19 05:53:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 05:53:55 --> Input Class Initialized
INFO - 2018-05-19 05:53:55 --> Language Class Initialized
ERROR - 2018-05-19 05:53:55 --> 404 Page Not Found: /index
INFO - 2018-05-19 05:53:55 --> Config Class Initialized
INFO - 2018-05-19 05:53:55 --> Hooks Class Initialized
DEBUG - 2018-05-19 05:53:55 --> UTF-8 Support Enabled
INFO - 2018-05-19 05:53:55 --> Utf8 Class Initialized
INFO - 2018-05-19 05:53:55 --> URI Class Initialized
INFO - 2018-05-19 05:53:55 --> Router Class Initialized
INFO - 2018-05-19 05:53:55 --> Output Class Initialized
INFO - 2018-05-19 05:53:55 --> Security Class Initialized
DEBUG - 2018-05-19 05:53:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 05:53:55 --> Input Class Initialized
INFO - 2018-05-19 05:53:55 --> Language Class Initialized
ERROR - 2018-05-19 05:53:55 --> 404 Page Not Found: /index
INFO - 2018-05-19 05:58:55 --> Config Class Initialized
INFO - 2018-05-19 05:58:55 --> Hooks Class Initialized
DEBUG - 2018-05-19 05:58:55 --> UTF-8 Support Enabled
INFO - 2018-05-19 05:58:55 --> Utf8 Class Initialized
INFO - 2018-05-19 05:58:55 --> URI Class Initialized
INFO - 2018-05-19 05:58:55 --> Router Class Initialized
INFO - 2018-05-19 05:58:55 --> Output Class Initialized
INFO - 2018-05-19 05:58:55 --> Security Class Initialized
DEBUG - 2018-05-19 05:58:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 05:58:55 --> Input Class Initialized
INFO - 2018-05-19 05:58:55 --> Language Class Initialized
INFO - 2018-05-19 05:58:55 --> Language Class Initialized
INFO - 2018-05-19 05:58:55 --> Config Class Initialized
INFO - 2018-05-19 05:58:55 --> Loader Class Initialized
DEBUG - 2018-05-19 05:58:55 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-19 05:58:55 --> Helper loaded: url_helper
INFO - 2018-05-19 05:58:55 --> Helper loaded: form_helper
INFO - 2018-05-19 05:58:55 --> Helper loaded: date_helper
INFO - 2018-05-19 05:58:55 --> Helper loaded: util_helper
INFO - 2018-05-19 05:58:55 --> Helper loaded: text_helper
INFO - 2018-05-19 05:58:55 --> Helper loaded: string_helper
INFO - 2018-05-19 05:58:55 --> Database Driver Class Initialized
DEBUG - 2018-05-19 05:58:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-19 05:58:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-19 05:58:55 --> Email Class Initialized
INFO - 2018-05-19 05:58:55 --> Controller Class Initialized
DEBUG - 2018-05-19 05:58:55 --> Home MX_Controller Initialized
DEBUG - 2018-05-19 05:58:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-19 05:58:55 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-19 05:58:55 --> Login MX_Controller Initialized
INFO - 2018-05-19 05:58:55 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-19 05:58:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-19 05:58:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-19 05:58:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-19 05:58:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-19 05:58:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-19 05:58:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-19 05:58:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-19 05:58:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/progress.php
INFO - 2018-05-19 05:58:55 --> Final output sent to browser
DEBUG - 2018-05-19 05:58:55 --> Total execution time: 0.5539
INFO - 2018-05-19 05:58:56 --> Config Class Initialized
INFO - 2018-05-19 05:58:56 --> Hooks Class Initialized
DEBUG - 2018-05-19 05:58:56 --> UTF-8 Support Enabled
INFO - 2018-05-19 05:58:56 --> Utf8 Class Initialized
INFO - 2018-05-19 05:58:56 --> URI Class Initialized
INFO - 2018-05-19 05:58:56 --> Router Class Initialized
INFO - 2018-05-19 05:58:56 --> Output Class Initialized
INFO - 2018-05-19 05:58:56 --> Security Class Initialized
DEBUG - 2018-05-19 05:58:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 05:58:56 --> Input Class Initialized
INFO - 2018-05-19 05:58:56 --> Language Class Initialized
ERROR - 2018-05-19 05:58:56 --> 404 Page Not Found: /index
INFO - 2018-05-19 05:58:56 --> Config Class Initialized
INFO - 2018-05-19 05:58:56 --> Hooks Class Initialized
DEBUG - 2018-05-19 05:58:56 --> UTF-8 Support Enabled
INFO - 2018-05-19 05:58:56 --> Utf8 Class Initialized
INFO - 2018-05-19 05:58:56 --> URI Class Initialized
INFO - 2018-05-19 05:58:56 --> Router Class Initialized
INFO - 2018-05-19 05:58:56 --> Output Class Initialized
INFO - 2018-05-19 05:58:56 --> Security Class Initialized
DEBUG - 2018-05-19 05:58:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 05:58:56 --> Input Class Initialized
INFO - 2018-05-19 05:58:56 --> Language Class Initialized
ERROR - 2018-05-19 05:58:56 --> 404 Page Not Found: /index
INFO - 2018-05-19 05:58:56 --> Config Class Initialized
INFO - 2018-05-19 05:58:57 --> Hooks Class Initialized
DEBUG - 2018-05-19 05:58:57 --> UTF-8 Support Enabled
INFO - 2018-05-19 05:58:57 --> Utf8 Class Initialized
INFO - 2018-05-19 05:58:57 --> URI Class Initialized
INFO - 2018-05-19 05:58:57 --> Router Class Initialized
INFO - 2018-05-19 05:58:57 --> Output Class Initialized
INFO - 2018-05-19 05:58:57 --> Security Class Initialized
DEBUG - 2018-05-19 05:58:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 05:58:57 --> Input Class Initialized
INFO - 2018-05-19 05:58:57 --> Language Class Initialized
ERROR - 2018-05-19 05:58:57 --> 404 Page Not Found: /index
INFO - 2018-05-19 05:59:06 --> Config Class Initialized
INFO - 2018-05-19 05:59:06 --> Hooks Class Initialized
DEBUG - 2018-05-19 05:59:06 --> UTF-8 Support Enabled
INFO - 2018-05-19 05:59:06 --> Utf8 Class Initialized
INFO - 2018-05-19 05:59:06 --> URI Class Initialized
INFO - 2018-05-19 05:59:06 --> Router Class Initialized
INFO - 2018-05-19 05:59:06 --> Output Class Initialized
INFO - 2018-05-19 05:59:07 --> Security Class Initialized
DEBUG - 2018-05-19 05:59:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 05:59:07 --> Input Class Initialized
INFO - 2018-05-19 05:59:07 --> Language Class Initialized
INFO - 2018-05-19 05:59:07 --> Language Class Initialized
INFO - 2018-05-19 05:59:07 --> Config Class Initialized
INFO - 2018-05-19 05:59:07 --> Loader Class Initialized
DEBUG - 2018-05-19 05:59:07 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-19 05:59:07 --> Helper loaded: url_helper
INFO - 2018-05-19 05:59:07 --> Helper loaded: form_helper
INFO - 2018-05-19 05:59:07 --> Helper loaded: date_helper
INFO - 2018-05-19 05:59:07 --> Helper loaded: util_helper
INFO - 2018-05-19 05:59:07 --> Helper loaded: text_helper
INFO - 2018-05-19 05:59:07 --> Helper loaded: string_helper
INFO - 2018-05-19 05:59:07 --> Database Driver Class Initialized
DEBUG - 2018-05-19 05:59:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-19 05:59:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-19 05:59:07 --> Email Class Initialized
INFO - 2018-05-19 05:59:07 --> Controller Class Initialized
DEBUG - 2018-05-19 05:59:07 --> Home MX_Controller Initialized
DEBUG - 2018-05-19 05:59:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-19 05:59:07 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-19 05:59:07 --> Login MX_Controller Initialized
INFO - 2018-05-19 05:59:07 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-19 05:59:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-19 05:59:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-19 05:59:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-19 05:59:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-19 05:59:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-19 05:59:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-19 05:59:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-19 05:59:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/progress.php
INFO - 2018-05-19 05:59:07 --> Final output sent to browser
DEBUG - 2018-05-19 05:59:07 --> Total execution time: 0.5250
INFO - 2018-05-19 05:59:07 --> Config Class Initialized
INFO - 2018-05-19 05:59:07 --> Hooks Class Initialized
DEBUG - 2018-05-19 05:59:07 --> UTF-8 Support Enabled
INFO - 2018-05-19 05:59:08 --> Utf8 Class Initialized
INFO - 2018-05-19 05:59:08 --> URI Class Initialized
INFO - 2018-05-19 05:59:08 --> Router Class Initialized
INFO - 2018-05-19 05:59:08 --> Output Class Initialized
INFO - 2018-05-19 05:59:08 --> Security Class Initialized
DEBUG - 2018-05-19 05:59:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 05:59:08 --> Input Class Initialized
INFO - 2018-05-19 05:59:08 --> Language Class Initialized
ERROR - 2018-05-19 05:59:08 --> 404 Page Not Found: /index
INFO - 2018-05-19 05:59:08 --> Config Class Initialized
INFO - 2018-05-19 05:59:08 --> Hooks Class Initialized
DEBUG - 2018-05-19 05:59:08 --> UTF-8 Support Enabled
INFO - 2018-05-19 05:59:08 --> Utf8 Class Initialized
INFO - 2018-05-19 05:59:08 --> URI Class Initialized
INFO - 2018-05-19 05:59:08 --> Router Class Initialized
INFO - 2018-05-19 05:59:08 --> Output Class Initialized
INFO - 2018-05-19 05:59:08 --> Security Class Initialized
DEBUG - 2018-05-19 05:59:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 05:59:09 --> Input Class Initialized
INFO - 2018-05-19 05:59:09 --> Language Class Initialized
ERROR - 2018-05-19 05:59:09 --> 404 Page Not Found: /index
INFO - 2018-05-19 05:59:09 --> Config Class Initialized
INFO - 2018-05-19 05:59:09 --> Hooks Class Initialized
DEBUG - 2018-05-19 05:59:09 --> UTF-8 Support Enabled
INFO - 2018-05-19 05:59:09 --> Utf8 Class Initialized
INFO - 2018-05-19 05:59:09 --> URI Class Initialized
INFO - 2018-05-19 05:59:09 --> Router Class Initialized
INFO - 2018-05-19 05:59:09 --> Output Class Initialized
INFO - 2018-05-19 05:59:09 --> Security Class Initialized
DEBUG - 2018-05-19 05:59:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 05:59:09 --> Input Class Initialized
INFO - 2018-05-19 05:59:09 --> Language Class Initialized
ERROR - 2018-05-19 05:59:09 --> 404 Page Not Found: /index
INFO - 2018-05-19 06:05:40 --> Config Class Initialized
INFO - 2018-05-19 06:05:40 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:05:40 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:05:40 --> Utf8 Class Initialized
INFO - 2018-05-19 06:05:40 --> URI Class Initialized
INFO - 2018-05-19 06:05:40 --> Router Class Initialized
INFO - 2018-05-19 06:05:40 --> Output Class Initialized
INFO - 2018-05-19 06:05:40 --> Security Class Initialized
DEBUG - 2018-05-19 06:05:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:05:40 --> Input Class Initialized
INFO - 2018-05-19 06:05:40 --> Language Class Initialized
INFO - 2018-05-19 06:05:40 --> Language Class Initialized
INFO - 2018-05-19 06:05:40 --> Config Class Initialized
INFO - 2018-05-19 06:05:40 --> Loader Class Initialized
DEBUG - 2018-05-19 06:05:40 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-19 06:05:40 --> Helper loaded: url_helper
INFO - 2018-05-19 06:05:40 --> Helper loaded: form_helper
INFO - 2018-05-19 06:05:40 --> Helper loaded: date_helper
INFO - 2018-05-19 06:05:40 --> Helper loaded: util_helper
INFO - 2018-05-19 06:05:40 --> Helper loaded: text_helper
INFO - 2018-05-19 06:05:40 --> Helper loaded: string_helper
INFO - 2018-05-19 06:05:40 --> Database Driver Class Initialized
DEBUG - 2018-05-19 06:05:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-19 06:05:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-19 06:05:40 --> Email Class Initialized
INFO - 2018-05-19 06:05:40 --> Controller Class Initialized
DEBUG - 2018-05-19 06:05:40 --> Home MX_Controller Initialized
DEBUG - 2018-05-19 06:05:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-19 06:05:40 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-19 06:05:40 --> Login MX_Controller Initialized
INFO - 2018-05-19 06:05:40 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-19 06:05:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-19 06:05:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-19 06:05:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-19 06:05:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-19 06:05:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-19 06:05:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-19 06:05:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-19 06:05:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/progress.php
INFO - 2018-05-19 06:05:40 --> Final output sent to browser
DEBUG - 2018-05-19 06:05:40 --> Total execution time: 0.5762
INFO - 2018-05-19 06:05:41 --> Config Class Initialized
INFO - 2018-05-19 06:05:41 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:05:41 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:05:41 --> Utf8 Class Initialized
INFO - 2018-05-19 06:05:41 --> URI Class Initialized
INFO - 2018-05-19 06:05:41 --> Router Class Initialized
INFO - 2018-05-19 06:05:41 --> Output Class Initialized
INFO - 2018-05-19 06:05:41 --> Security Class Initialized
DEBUG - 2018-05-19 06:05:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:05:41 --> Input Class Initialized
INFO - 2018-05-19 06:05:41 --> Language Class Initialized
ERROR - 2018-05-19 06:05:41 --> 404 Page Not Found: /index
INFO - 2018-05-19 06:05:41 --> Config Class Initialized
INFO - 2018-05-19 06:05:41 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:05:41 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:05:41 --> Utf8 Class Initialized
INFO - 2018-05-19 06:05:41 --> URI Class Initialized
INFO - 2018-05-19 06:05:41 --> Router Class Initialized
INFO - 2018-05-19 06:05:41 --> Output Class Initialized
INFO - 2018-05-19 06:05:41 --> Security Class Initialized
DEBUG - 2018-05-19 06:05:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:05:41 --> Input Class Initialized
INFO - 2018-05-19 06:05:41 --> Language Class Initialized
ERROR - 2018-05-19 06:05:41 --> 404 Page Not Found: /index
INFO - 2018-05-19 06:05:42 --> Config Class Initialized
INFO - 2018-05-19 06:05:42 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:05:42 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:05:42 --> Utf8 Class Initialized
INFO - 2018-05-19 06:05:42 --> URI Class Initialized
INFO - 2018-05-19 06:05:42 --> Router Class Initialized
INFO - 2018-05-19 06:05:42 --> Output Class Initialized
INFO - 2018-05-19 06:05:42 --> Security Class Initialized
DEBUG - 2018-05-19 06:05:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:05:42 --> Input Class Initialized
INFO - 2018-05-19 06:05:42 --> Language Class Initialized
ERROR - 2018-05-19 06:05:42 --> 404 Page Not Found: /index
INFO - 2018-05-19 06:05:43 --> Config Class Initialized
INFO - 2018-05-19 06:05:43 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:05:44 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:05:44 --> Utf8 Class Initialized
INFO - 2018-05-19 06:05:44 --> URI Class Initialized
INFO - 2018-05-19 06:05:44 --> Router Class Initialized
INFO - 2018-05-19 06:05:44 --> Output Class Initialized
INFO - 2018-05-19 06:05:44 --> Security Class Initialized
DEBUG - 2018-05-19 06:05:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:05:44 --> Input Class Initialized
INFO - 2018-05-19 06:05:44 --> Language Class Initialized
INFO - 2018-05-19 06:05:44 --> Language Class Initialized
INFO - 2018-05-19 06:05:44 --> Config Class Initialized
INFO - 2018-05-19 06:05:44 --> Loader Class Initialized
DEBUG - 2018-05-19 06:05:44 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-19 06:05:44 --> Helper loaded: url_helper
INFO - 2018-05-19 06:05:44 --> Helper loaded: form_helper
INFO - 2018-05-19 06:05:44 --> Helper loaded: date_helper
INFO - 2018-05-19 06:05:44 --> Helper loaded: util_helper
INFO - 2018-05-19 06:05:44 --> Helper loaded: text_helper
INFO - 2018-05-19 06:05:44 --> Helper loaded: string_helper
INFO - 2018-05-19 06:05:44 --> Database Driver Class Initialized
DEBUG - 2018-05-19 06:05:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-19 06:05:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-19 06:05:44 --> Email Class Initialized
INFO - 2018-05-19 06:05:44 --> Controller Class Initialized
DEBUG - 2018-05-19 06:05:44 --> Home MX_Controller Initialized
DEBUG - 2018-05-19 06:05:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-19 06:05:44 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-19 06:05:44 --> Login MX_Controller Initialized
INFO - 2018-05-19 06:05:44 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-19 06:05:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-19 06:05:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-19 06:05:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-19 06:05:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-19 06:05:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-19 06:05:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-19 06:05:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-19 06:05:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/progress_product.php
INFO - 2018-05-19 06:05:44 --> Final output sent to browser
DEBUG - 2018-05-19 06:05:44 --> Total execution time: 0.7665
INFO - 2018-05-19 06:05:45 --> Config Class Initialized
INFO - 2018-05-19 06:05:45 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:05:45 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:05:45 --> Utf8 Class Initialized
INFO - 2018-05-19 06:05:45 --> URI Class Initialized
INFO - 2018-05-19 06:05:45 --> Router Class Initialized
INFO - 2018-05-19 06:05:45 --> Output Class Initialized
INFO - 2018-05-19 06:05:45 --> Security Class Initialized
DEBUG - 2018-05-19 06:05:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:05:45 --> Input Class Initialized
INFO - 2018-05-19 06:05:45 --> Language Class Initialized
ERROR - 2018-05-19 06:05:45 --> 404 Page Not Found: /index
INFO - 2018-05-19 06:05:46 --> Config Class Initialized
INFO - 2018-05-19 06:05:46 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:05:46 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:05:46 --> Utf8 Class Initialized
INFO - 2018-05-19 06:05:46 --> URI Class Initialized
INFO - 2018-05-19 06:05:46 --> Router Class Initialized
INFO - 2018-05-19 06:05:46 --> Output Class Initialized
INFO - 2018-05-19 06:05:46 --> Security Class Initialized
DEBUG - 2018-05-19 06:05:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:05:46 --> Input Class Initialized
INFO - 2018-05-19 06:05:46 --> Language Class Initialized
ERROR - 2018-05-19 06:05:46 --> 404 Page Not Found: /index
INFO - 2018-05-19 06:05:46 --> Config Class Initialized
INFO - 2018-05-19 06:05:46 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:05:46 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:05:46 --> Utf8 Class Initialized
INFO - 2018-05-19 06:05:46 --> URI Class Initialized
INFO - 2018-05-19 06:05:46 --> Router Class Initialized
INFO - 2018-05-19 06:05:47 --> Output Class Initialized
INFO - 2018-05-19 06:05:47 --> Security Class Initialized
DEBUG - 2018-05-19 06:05:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:05:47 --> Input Class Initialized
INFO - 2018-05-19 06:05:47 --> Language Class Initialized
ERROR - 2018-05-19 06:05:47 --> 404 Page Not Found: /index
INFO - 2018-05-19 06:05:55 --> Config Class Initialized
INFO - 2018-05-19 06:05:55 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:05:55 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:05:55 --> Utf8 Class Initialized
INFO - 2018-05-19 06:05:55 --> URI Class Initialized
INFO - 2018-05-19 06:05:56 --> Router Class Initialized
INFO - 2018-05-19 06:05:56 --> Output Class Initialized
INFO - 2018-05-19 06:05:56 --> Security Class Initialized
DEBUG - 2018-05-19 06:05:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:05:56 --> Input Class Initialized
INFO - 2018-05-19 06:05:56 --> Language Class Initialized
ERROR - 2018-05-19 06:05:56 --> 404 Page Not Found: /index
INFO - 2018-05-19 06:06:12 --> Config Class Initialized
INFO - 2018-05-19 06:06:12 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:06:12 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:06:12 --> Utf8 Class Initialized
INFO - 2018-05-19 06:06:13 --> URI Class Initialized
INFO - 2018-05-19 06:06:13 --> Router Class Initialized
INFO - 2018-05-19 06:06:13 --> Output Class Initialized
INFO - 2018-05-19 06:06:13 --> Security Class Initialized
DEBUG - 2018-05-19 06:06:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:06:13 --> Input Class Initialized
INFO - 2018-05-19 06:06:13 --> Language Class Initialized
ERROR - 2018-05-19 06:06:13 --> 404 Page Not Found: /index
INFO - 2018-05-19 06:06:13 --> Config Class Initialized
INFO - 2018-05-19 06:06:13 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:06:13 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:06:13 --> Utf8 Class Initialized
INFO - 2018-05-19 06:06:13 --> URI Class Initialized
INFO - 2018-05-19 06:06:13 --> Router Class Initialized
INFO - 2018-05-19 06:06:13 --> Output Class Initialized
INFO - 2018-05-19 06:06:13 --> Security Class Initialized
DEBUG - 2018-05-19 06:06:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:06:13 --> Input Class Initialized
INFO - 2018-05-19 06:06:13 --> Language Class Initialized
ERROR - 2018-05-19 06:06:13 --> 404 Page Not Found: /index
INFO - 2018-05-19 06:06:13 --> Config Class Initialized
INFO - 2018-05-19 06:06:13 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:06:13 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:06:14 --> Utf8 Class Initialized
INFO - 2018-05-19 06:06:14 --> URI Class Initialized
INFO - 2018-05-19 06:06:14 --> Router Class Initialized
INFO - 2018-05-19 06:06:14 --> Output Class Initialized
INFO - 2018-05-19 06:06:14 --> Security Class Initialized
DEBUG - 2018-05-19 06:06:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:06:14 --> Input Class Initialized
INFO - 2018-05-19 06:06:14 --> Language Class Initialized
ERROR - 2018-05-19 06:06:14 --> 404 Page Not Found: /index
INFO - 2018-05-19 06:06:27 --> Config Class Initialized
INFO - 2018-05-19 06:06:27 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:06:27 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:06:27 --> Utf8 Class Initialized
INFO - 2018-05-19 06:06:27 --> URI Class Initialized
INFO - 2018-05-19 06:06:27 --> Router Class Initialized
INFO - 2018-05-19 06:06:27 --> Output Class Initialized
INFO - 2018-05-19 06:06:27 --> Security Class Initialized
DEBUG - 2018-05-19 06:06:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:06:27 --> Input Class Initialized
INFO - 2018-05-19 06:06:27 --> Language Class Initialized
INFO - 2018-05-19 06:06:27 --> Language Class Initialized
INFO - 2018-05-19 06:06:27 --> Config Class Initialized
INFO - 2018-05-19 06:06:27 --> Loader Class Initialized
DEBUG - 2018-05-19 06:06:27 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-19 06:06:27 --> Helper loaded: url_helper
INFO - 2018-05-19 06:06:27 --> Helper loaded: form_helper
INFO - 2018-05-19 06:06:27 --> Helper loaded: date_helper
INFO - 2018-05-19 06:06:27 --> Helper loaded: util_helper
INFO - 2018-05-19 06:06:27 --> Helper loaded: text_helper
INFO - 2018-05-19 06:06:27 --> Helper loaded: string_helper
INFO - 2018-05-19 06:06:27 --> Database Driver Class Initialized
DEBUG - 2018-05-19 06:06:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-19 06:06:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-19 06:06:27 --> Email Class Initialized
INFO - 2018-05-19 06:06:27 --> Controller Class Initialized
DEBUG - 2018-05-19 06:06:27 --> Home MX_Controller Initialized
DEBUG - 2018-05-19 06:06:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-19 06:06:27 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-19 06:06:27 --> Login MX_Controller Initialized
INFO - 2018-05-19 06:06:27 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-19 06:06:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-19 06:06:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-19 06:06:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-19 06:06:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-19 06:06:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-19 06:06:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-19 06:06:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-19 06:06:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/progress.php
INFO - 2018-05-19 06:06:27 --> Final output sent to browser
DEBUG - 2018-05-19 06:06:27 --> Total execution time: 0.5263
INFO - 2018-05-19 06:06:27 --> Config Class Initialized
INFO - 2018-05-19 06:06:27 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:06:28 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:06:28 --> Utf8 Class Initialized
INFO - 2018-05-19 06:06:28 --> URI Class Initialized
INFO - 2018-05-19 06:06:28 --> Router Class Initialized
INFO - 2018-05-19 06:06:28 --> Output Class Initialized
INFO - 2018-05-19 06:06:28 --> Security Class Initialized
DEBUG - 2018-05-19 06:06:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:06:28 --> Input Class Initialized
INFO - 2018-05-19 06:06:28 --> Language Class Initialized
ERROR - 2018-05-19 06:06:28 --> 404 Page Not Found: /index
INFO - 2018-05-19 06:06:28 --> Config Class Initialized
INFO - 2018-05-19 06:06:28 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:06:28 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:06:28 --> Utf8 Class Initialized
INFO - 2018-05-19 06:06:28 --> URI Class Initialized
INFO - 2018-05-19 06:06:28 --> Router Class Initialized
INFO - 2018-05-19 06:06:28 --> Output Class Initialized
INFO - 2018-05-19 06:06:28 --> Security Class Initialized
DEBUG - 2018-05-19 06:06:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:06:28 --> Input Class Initialized
INFO - 2018-05-19 06:06:28 --> Language Class Initialized
ERROR - 2018-05-19 06:06:28 --> 404 Page Not Found: /index
INFO - 2018-05-19 06:06:29 --> Config Class Initialized
INFO - 2018-05-19 06:06:29 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:06:29 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:06:29 --> Utf8 Class Initialized
INFO - 2018-05-19 06:06:29 --> URI Class Initialized
INFO - 2018-05-19 06:06:29 --> Router Class Initialized
INFO - 2018-05-19 06:06:29 --> Output Class Initialized
INFO - 2018-05-19 06:06:29 --> Security Class Initialized
DEBUG - 2018-05-19 06:06:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:06:29 --> Input Class Initialized
INFO - 2018-05-19 06:06:29 --> Language Class Initialized
ERROR - 2018-05-19 06:06:29 --> 404 Page Not Found: /index
INFO - 2018-05-19 06:07:00 --> Config Class Initialized
INFO - 2018-05-19 06:07:00 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:07:00 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:07:00 --> Utf8 Class Initialized
INFO - 2018-05-19 06:07:00 --> URI Class Initialized
INFO - 2018-05-19 06:07:00 --> Router Class Initialized
INFO - 2018-05-19 06:07:00 --> Output Class Initialized
INFO - 2018-05-19 06:07:00 --> Security Class Initialized
DEBUG - 2018-05-19 06:07:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:07:00 --> Input Class Initialized
INFO - 2018-05-19 06:07:00 --> Language Class Initialized
INFO - 2018-05-19 06:07:00 --> Language Class Initialized
INFO - 2018-05-19 06:07:00 --> Config Class Initialized
INFO - 2018-05-19 06:07:00 --> Loader Class Initialized
DEBUG - 2018-05-19 06:07:00 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-19 06:07:00 --> Helper loaded: url_helper
INFO - 2018-05-19 06:07:00 --> Helper loaded: form_helper
INFO - 2018-05-19 06:07:00 --> Helper loaded: date_helper
INFO - 2018-05-19 06:07:00 --> Helper loaded: util_helper
INFO - 2018-05-19 06:07:00 --> Helper loaded: text_helper
INFO - 2018-05-19 06:07:00 --> Helper loaded: string_helper
INFO - 2018-05-19 06:07:00 --> Database Driver Class Initialized
DEBUG - 2018-05-19 06:07:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-19 06:07:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-19 06:07:00 --> Email Class Initialized
INFO - 2018-05-19 06:07:00 --> Controller Class Initialized
DEBUG - 2018-05-19 06:07:00 --> Home MX_Controller Initialized
DEBUG - 2018-05-19 06:07:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-19 06:07:00 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-19 06:07:00 --> Login MX_Controller Initialized
INFO - 2018-05-19 06:07:00 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-19 06:07:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-19 06:07:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-19 06:07:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-19 06:07:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-19 06:07:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-19 06:07:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-19 06:07:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-19 06:07:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/refer_a_friend.php
INFO - 2018-05-19 06:07:01 --> Final output sent to browser
INFO - 2018-05-19 06:07:01 --> Config Class Initialized
DEBUG - 2018-05-19 06:07:01 --> Total execution time: 0.5417
INFO - 2018-05-19 06:07:01 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:07:01 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:07:01 --> Utf8 Class Initialized
INFO - 2018-05-19 06:07:01 --> URI Class Initialized
INFO - 2018-05-19 06:07:01 --> Router Class Initialized
INFO - 2018-05-19 06:07:01 --> Output Class Initialized
INFO - 2018-05-19 06:07:01 --> Config Class Initialized
INFO - 2018-05-19 06:07:01 --> Hooks Class Initialized
INFO - 2018-05-19 06:07:01 --> Security Class Initialized
DEBUG - 2018-05-19 06:07:01 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:07:01 --> Utf8 Class Initialized
INFO - 2018-05-19 06:07:01 --> URI Class Initialized
INFO - 2018-05-19 06:07:01 --> Router Class Initialized
INFO - 2018-05-19 06:07:01 --> Output Class Initialized
INFO - 2018-05-19 06:07:01 --> Security Class Initialized
DEBUG - 2018-05-19 06:07:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:07:01 --> Input Class Initialized
DEBUG - 2018-05-19 06:07:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:07:01 --> Language Class Initialized
INFO - 2018-05-19 06:07:01 --> Input Class Initialized
INFO - 2018-05-19 06:07:01 --> Language Class Initialized
INFO - 2018-05-19 06:07:01 --> Language Class Initialized
INFO - 2018-05-19 06:07:01 --> Config Class Initialized
INFO - 2018-05-19 06:07:01 --> Language Class Initialized
INFO - 2018-05-19 06:07:01 --> Config Class Initialized
INFO - 2018-05-19 06:07:01 --> Loader Class Initialized
INFO - 2018-05-19 06:07:01 --> Config Class Initialized
INFO - 2018-05-19 06:07:01 --> Hooks Class Initialized
INFO - 2018-05-19 06:07:01 --> Loader Class Initialized
DEBUG - 2018-05-19 06:07:01 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
DEBUG - 2018-05-19 06:07:01 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
DEBUG - 2018-05-19 06:07:01 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:07:01 --> Helper loaded: url_helper
INFO - 2018-05-19 06:07:01 --> Utf8 Class Initialized
INFO - 2018-05-19 06:07:01 --> Helper loaded: url_helper
INFO - 2018-05-19 06:07:01 --> URI Class Initialized
INFO - 2018-05-19 06:07:01 --> Router Class Initialized
INFO - 2018-05-19 06:07:01 --> Output Class Initialized
INFO - 2018-05-19 06:07:01 --> Helper loaded: form_helper
INFO - 2018-05-19 06:07:01 --> Helper loaded: form_helper
INFO - 2018-05-19 06:07:01 --> Security Class Initialized
INFO - 2018-05-19 06:07:01 --> Helper loaded: date_helper
INFO - 2018-05-19 06:07:01 --> Helper loaded: util_helper
INFO - 2018-05-19 06:07:01 --> Helper loaded: text_helper
INFO - 2018-05-19 06:07:01 --> Helper loaded: date_helper
DEBUG - 2018-05-19 06:07:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:07:01 --> Helper loaded: string_helper
INFO - 2018-05-19 06:07:01 --> Helper loaded: util_helper
INFO - 2018-05-19 06:07:01 --> Input Class Initialized
INFO - 2018-05-19 06:07:01 --> Helper loaded: text_helper
INFO - 2018-05-19 06:07:01 --> Database Driver Class Initialized
INFO - 2018-05-19 06:07:02 --> Language Class Initialized
INFO - 2018-05-19 06:07:02 --> Helper loaded: string_helper
ERROR - 2018-05-19 06:07:02 --> 404 Page Not Found: /index
INFO - 2018-05-19 06:07:02 --> Database Driver Class Initialized
DEBUG - 2018-05-19 06:07:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-05-19 06:07:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-19 06:07:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-19 06:07:02 --> Config Class Initialized
INFO - 2018-05-19 06:07:02 --> Hooks Class Initialized
INFO - 2018-05-19 06:07:02 --> Email Class Initialized
DEBUG - 2018-05-19 06:07:02 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:07:02 --> Utf8 Class Initialized
INFO - 2018-05-19 06:07:02 --> URI Class Initialized
INFO - 2018-05-19 06:07:02 --> Router Class Initialized
INFO - 2018-05-19 06:07:02 --> Output Class Initialized
INFO - 2018-05-19 06:07:02 --> Security Class Initialized
DEBUG - 2018-05-19 06:07:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:07:02 --> Input Class Initialized
INFO - 2018-05-19 06:07:02 --> Language Class Initialized
INFO - 2018-05-19 06:07:02 --> Controller Class Initialized
ERROR - 2018-05-19 06:07:02 --> 404 Page Not Found: /index
ERROR - 2018-05-19 06:07:02 --> 404 Page Not Found: ../modules/home/controllers/Home/js
INFO - 2018-05-19 06:07:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-19 06:07:02 --> Email Class Initialized
INFO - 2018-05-19 06:07:02 --> Controller Class Initialized
ERROR - 2018-05-19 06:07:02 --> 404 Page Not Found: ../modules/home/controllers/Home/js
INFO - 2018-05-19 06:07:02 --> Config Class Initialized
INFO - 2018-05-19 06:07:02 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:07:02 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:07:02 --> Utf8 Class Initialized
INFO - 2018-05-19 06:07:02 --> URI Class Initialized
INFO - 2018-05-19 06:07:02 --> Router Class Initialized
INFO - 2018-05-19 06:07:02 --> Output Class Initialized
INFO - 2018-05-19 06:07:02 --> Security Class Initialized
DEBUG - 2018-05-19 06:07:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:07:02 --> Input Class Initialized
INFO - 2018-05-19 06:07:02 --> Language Class Initialized
ERROR - 2018-05-19 06:07:02 --> 404 Page Not Found: /index
INFO - 2018-05-19 06:07:54 --> Config Class Initialized
INFO - 2018-05-19 06:07:54 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:07:54 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:07:54 --> Utf8 Class Initialized
INFO - 2018-05-19 06:07:54 --> URI Class Initialized
INFO - 2018-05-19 06:07:54 --> Router Class Initialized
INFO - 2018-05-19 06:07:54 --> Output Class Initialized
INFO - 2018-05-19 06:07:54 --> Security Class Initialized
DEBUG - 2018-05-19 06:07:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:07:54 --> Input Class Initialized
INFO - 2018-05-19 06:07:54 --> Language Class Initialized
INFO - 2018-05-19 06:07:54 --> Language Class Initialized
INFO - 2018-05-19 06:07:54 --> Config Class Initialized
INFO - 2018-05-19 06:07:54 --> Loader Class Initialized
DEBUG - 2018-05-19 06:07:54 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-19 06:07:54 --> Helper loaded: url_helper
INFO - 2018-05-19 06:07:54 --> Helper loaded: form_helper
INFO - 2018-05-19 06:07:54 --> Helper loaded: date_helper
INFO - 2018-05-19 06:07:54 --> Helper loaded: util_helper
INFO - 2018-05-19 06:07:54 --> Helper loaded: text_helper
INFO - 2018-05-19 06:07:54 --> Helper loaded: string_helper
INFO - 2018-05-19 06:07:54 --> Database Driver Class Initialized
DEBUG - 2018-05-19 06:07:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-19 06:07:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-19 06:07:54 --> Email Class Initialized
INFO - 2018-05-19 06:07:54 --> Controller Class Initialized
DEBUG - 2018-05-19 06:07:54 --> Home MX_Controller Initialized
DEBUG - 2018-05-19 06:07:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-19 06:07:55 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-19 06:07:55 --> Login MX_Controller Initialized
INFO - 2018-05-19 06:07:55 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-19 06:07:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-19 06:07:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-19 06:07:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-19 06:07:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-19 06:07:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-19 06:07:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-19 06:07:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-19 06:07:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/refer_a_friend.php
INFO - 2018-05-19 06:07:55 --> Final output sent to browser
DEBUG - 2018-05-19 06:07:55 --> Total execution time: 0.5875
INFO - 2018-05-19 06:07:55 --> Config Class Initialized
INFO - 2018-05-19 06:07:55 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:07:55 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:07:55 --> Utf8 Class Initialized
INFO - 2018-05-19 06:07:55 --> URI Class Initialized
INFO - 2018-05-19 06:07:55 --> Config Class Initialized
INFO - 2018-05-19 06:07:55 --> Hooks Class Initialized
INFO - 2018-05-19 06:07:55 --> Router Class Initialized
DEBUG - 2018-05-19 06:07:55 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:07:55 --> Utf8 Class Initialized
INFO - 2018-05-19 06:07:55 --> URI Class Initialized
INFO - 2018-05-19 06:07:55 --> Output Class Initialized
INFO - 2018-05-19 06:07:55 --> Security Class Initialized
INFO - 2018-05-19 06:07:55 --> Router Class Initialized
INFO - 2018-05-19 06:07:55 --> Config Class Initialized
DEBUG - 2018-05-19 06:07:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:07:55 --> Hooks Class Initialized
INFO - 2018-05-19 06:07:55 --> Output Class Initialized
INFO - 2018-05-19 06:07:55 --> Input Class Initialized
DEBUG - 2018-05-19 06:07:55 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:07:55 --> Security Class Initialized
INFO - 2018-05-19 06:07:55 --> Language Class Initialized
INFO - 2018-05-19 06:07:55 --> Utf8 Class Initialized
DEBUG - 2018-05-19 06:07:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:07:55 --> Language Class Initialized
INFO - 2018-05-19 06:07:55 --> URI Class Initialized
INFO - 2018-05-19 06:07:55 --> Config Class Initialized
INFO - 2018-05-19 06:07:55 --> Input Class Initialized
INFO - 2018-05-19 06:07:55 --> Router Class Initialized
INFO - 2018-05-19 06:07:55 --> Loader Class Initialized
DEBUG - 2018-05-19 06:07:55 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-19 06:07:55 --> Helper loaded: url_helper
INFO - 2018-05-19 06:07:55 --> Helper loaded: form_helper
INFO - 2018-05-19 06:07:55 --> Language Class Initialized
INFO - 2018-05-19 06:07:55 --> Output Class Initialized
INFO - 2018-05-19 06:07:55 --> Helper loaded: date_helper
INFO - 2018-05-19 06:07:55 --> Security Class Initialized
INFO - 2018-05-19 06:07:55 --> Language Class Initialized
INFO - 2018-05-19 06:07:55 --> Helper loaded: util_helper
INFO - 2018-05-19 06:07:55 --> Config Class Initialized
DEBUG - 2018-05-19 06:07:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:07:55 --> Helper loaded: text_helper
INFO - 2018-05-19 06:07:55 --> Input Class Initialized
INFO - 2018-05-19 06:07:55 --> Helper loaded: string_helper
INFO - 2018-05-19 06:07:55 --> Loader Class Initialized
DEBUG - 2018-05-19 06:07:55 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-19 06:07:55 --> Language Class Initialized
INFO - 2018-05-19 06:07:55 --> Database Driver Class Initialized
ERROR - 2018-05-19 06:07:56 --> 404 Page Not Found: /index
INFO - 2018-05-19 06:07:56 --> Helper loaded: url_helper
INFO - 2018-05-19 06:07:56 --> Helper loaded: form_helper
INFO - 2018-05-19 06:07:56 --> Config Class Initialized
INFO - 2018-05-19 06:07:56 --> Hooks Class Initialized
INFO - 2018-05-19 06:07:56 --> Helper loaded: date_helper
DEBUG - 2018-05-19 06:07:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-19 06:07:56 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-05-19 06:07:56 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:07:56 --> Helper loaded: util_helper
INFO - 2018-05-19 06:07:56 --> Utf8 Class Initialized
INFO - 2018-05-19 06:07:56 --> Email Class Initialized
INFO - 2018-05-19 06:07:56 --> Controller Class Initialized
INFO - 2018-05-19 06:07:56 --> Helper loaded: text_helper
INFO - 2018-05-19 06:07:56 --> URI Class Initialized
INFO - 2018-05-19 06:07:56 --> Helper loaded: string_helper
ERROR - 2018-05-19 06:07:56 --> 404 Page Not Found: ../modules/home/controllers/Home/js
INFO - 2018-05-19 06:07:56 --> Router Class Initialized
INFO - 2018-05-19 06:07:56 --> Output Class Initialized
INFO - 2018-05-19 06:07:56 --> Database Driver Class Initialized
INFO - 2018-05-19 06:07:56 --> Security Class Initialized
DEBUG - 2018-05-19 06:07:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-19 06:07:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-19 06:07:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-19 06:07:56 --> Input Class Initialized
INFO - 2018-05-19 06:07:56 --> Email Class Initialized
INFO - 2018-05-19 06:07:56 --> Controller Class Initialized
ERROR - 2018-05-19 06:07:56 --> 404 Page Not Found: ../modules/home/controllers/Home/js
INFO - 2018-05-19 06:07:56 --> Language Class Initialized
ERROR - 2018-05-19 06:07:56 --> 404 Page Not Found: /index
INFO - 2018-05-19 06:07:56 --> Config Class Initialized
INFO - 2018-05-19 06:07:56 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:07:56 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:07:56 --> Utf8 Class Initialized
INFO - 2018-05-19 06:07:56 --> URI Class Initialized
INFO - 2018-05-19 06:07:56 --> Router Class Initialized
INFO - 2018-05-19 06:07:56 --> Output Class Initialized
INFO - 2018-05-19 06:07:56 --> Security Class Initialized
DEBUG - 2018-05-19 06:07:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:07:56 --> Input Class Initialized
INFO - 2018-05-19 06:07:56 --> Language Class Initialized
ERROR - 2018-05-19 06:07:56 --> 404 Page Not Found: /index
INFO - 2018-05-19 06:07:57 --> Config Class Initialized
INFO - 2018-05-19 06:07:57 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:07:57 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:07:57 --> Utf8 Class Initialized
INFO - 2018-05-19 06:07:57 --> URI Class Initialized
INFO - 2018-05-19 06:07:57 --> Router Class Initialized
INFO - 2018-05-19 06:07:57 --> Output Class Initialized
INFO - 2018-05-19 06:07:57 --> Security Class Initialized
DEBUG - 2018-05-19 06:07:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:07:57 --> Input Class Initialized
INFO - 2018-05-19 06:07:57 --> Language Class Initialized
ERROR - 2018-05-19 06:07:57 --> 404 Page Not Found: /index
INFO - 2018-05-19 06:07:57 --> Config Class Initialized
INFO - 2018-05-19 06:07:57 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:07:57 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:07:57 --> Utf8 Class Initialized
INFO - 2018-05-19 06:07:57 --> URI Class Initialized
INFO - 2018-05-19 06:07:57 --> Router Class Initialized
INFO - 2018-05-19 06:07:57 --> Output Class Initialized
INFO - 2018-05-19 06:07:57 --> Security Class Initialized
DEBUG - 2018-05-19 06:07:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:07:57 --> Input Class Initialized
INFO - 2018-05-19 06:07:57 --> Language Class Initialized
ERROR - 2018-05-19 06:07:57 --> 404 Page Not Found: /index
INFO - 2018-05-19 06:07:57 --> Config Class Initialized
INFO - 2018-05-19 06:07:57 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:07:57 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:07:57 --> Utf8 Class Initialized
INFO - 2018-05-19 06:07:57 --> URI Class Initialized
INFO - 2018-05-19 06:07:57 --> Router Class Initialized
INFO - 2018-05-19 06:07:57 --> Output Class Initialized
INFO - 2018-05-19 06:07:57 --> Security Class Initialized
DEBUG - 2018-05-19 06:07:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:07:57 --> Input Class Initialized
INFO - 2018-05-19 06:07:57 --> Language Class Initialized
ERROR - 2018-05-19 06:07:57 --> 404 Page Not Found: /index
INFO - 2018-05-19 06:08:58 --> Config Class Initialized
INFO - 2018-05-19 06:08:58 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:08:58 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:08:58 --> Utf8 Class Initialized
INFO - 2018-05-19 06:08:58 --> URI Class Initialized
INFO - 2018-05-19 06:08:58 --> Router Class Initialized
INFO - 2018-05-19 06:08:58 --> Output Class Initialized
INFO - 2018-05-19 06:08:58 --> Security Class Initialized
DEBUG - 2018-05-19 06:08:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:08:58 --> Input Class Initialized
INFO - 2018-05-19 06:08:58 --> Language Class Initialized
INFO - 2018-05-19 06:08:58 --> Language Class Initialized
INFO - 2018-05-19 06:08:58 --> Config Class Initialized
INFO - 2018-05-19 06:08:58 --> Loader Class Initialized
DEBUG - 2018-05-19 06:08:58 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-19 06:08:58 --> Helper loaded: url_helper
INFO - 2018-05-19 06:08:58 --> Helper loaded: form_helper
INFO - 2018-05-19 06:08:58 --> Helper loaded: date_helper
INFO - 2018-05-19 06:08:58 --> Helper loaded: util_helper
INFO - 2018-05-19 06:08:58 --> Helper loaded: text_helper
INFO - 2018-05-19 06:08:58 --> Helper loaded: string_helper
INFO - 2018-05-19 06:08:58 --> Database Driver Class Initialized
DEBUG - 2018-05-19 06:08:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-19 06:08:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-19 06:08:59 --> Email Class Initialized
INFO - 2018-05-19 06:08:59 --> Controller Class Initialized
DEBUG - 2018-05-19 06:08:59 --> Home MX_Controller Initialized
DEBUG - 2018-05-19 06:08:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-19 06:08:59 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-19 06:08:59 --> Login MX_Controller Initialized
INFO - 2018-05-19 06:08:59 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-19 06:08:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-19 06:08:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-19 06:08:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-19 06:08:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-19 06:08:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-19 06:08:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-19 06:08:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-19 06:08:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/refer_a_friend.php
INFO - 2018-05-19 06:08:59 --> Final output sent to browser
DEBUG - 2018-05-19 06:08:59 --> Total execution time: 0.5633
INFO - 2018-05-19 06:08:59 --> Config Class Initialized
INFO - 2018-05-19 06:08:59 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:08:59 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:08:59 --> Config Class Initialized
INFO - 2018-05-19 06:08:59 --> Utf8 Class Initialized
INFO - 2018-05-19 06:08:59 --> URI Class Initialized
INFO - 2018-05-19 06:08:59 --> Router Class Initialized
INFO - 2018-05-19 06:08:59 --> Output Class Initialized
INFO - 2018-05-19 06:08:59 --> Security Class Initialized
DEBUG - 2018-05-19 06:08:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:08:59 --> Hooks Class Initialized
INFO - 2018-05-19 06:08:59 --> Input Class Initialized
INFO - 2018-05-19 06:08:59 --> Config Class Initialized
DEBUG - 2018-05-19 06:08:59 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:08:59 --> Utf8 Class Initialized
INFO - 2018-05-19 06:08:59 --> Hooks Class Initialized
INFO - 2018-05-19 06:08:59 --> Language Class Initialized
INFO - 2018-05-19 06:08:59 --> URI Class Initialized
DEBUG - 2018-05-19 06:08:59 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:08:59 --> Utf8 Class Initialized
INFO - 2018-05-19 06:08:59 --> Language Class Initialized
INFO - 2018-05-19 06:08:59 --> Router Class Initialized
INFO - 2018-05-19 06:08:59 --> URI Class Initialized
INFO - 2018-05-19 06:08:59 --> Output Class Initialized
INFO - 2018-05-19 06:08:59 --> Config Class Initialized
INFO - 2018-05-19 06:08:59 --> Router Class Initialized
INFO - 2018-05-19 06:08:59 --> Security Class Initialized
INFO - 2018-05-19 06:09:00 --> Output Class Initialized
INFO - 2018-05-19 06:09:00 --> Loader Class Initialized
DEBUG - 2018-05-19 06:09:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:09:00 --> Input Class Initialized
DEBUG - 2018-05-19 06:09:00 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-19 06:09:00 --> Security Class Initialized
INFO - 2018-05-19 06:09:00 --> Language Class Initialized
INFO - 2018-05-19 06:09:00 --> Helper loaded: url_helper
DEBUG - 2018-05-19 06:09:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:09:00 --> Helper loaded: form_helper
INFO - 2018-05-19 06:09:00 --> Input Class Initialized
INFO - 2018-05-19 06:09:00 --> Language Class Initialized
INFO - 2018-05-19 06:09:00 --> Helper loaded: date_helper
INFO - 2018-05-19 06:09:00 --> Config Class Initialized
INFO - 2018-05-19 06:09:00 --> Helper loaded: util_helper
INFO - 2018-05-19 06:09:00 --> Language Class Initialized
ERROR - 2018-05-19 06:09:00 --> 404 Page Not Found: /index
INFO - 2018-05-19 06:09:00 --> Loader Class Initialized
DEBUG - 2018-05-19 06:09:00 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-19 06:09:00 --> Helper loaded: text_helper
INFO - 2018-05-19 06:09:00 --> Config Class Initialized
INFO - 2018-05-19 06:09:00 --> Hooks Class Initialized
INFO - 2018-05-19 06:09:00 --> Helper loaded: url_helper
INFO - 2018-05-19 06:09:00 --> Helper loaded: string_helper
INFO - 2018-05-19 06:09:00 --> Helper loaded: form_helper
DEBUG - 2018-05-19 06:09:00 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:09:00 --> Database Driver Class Initialized
INFO - 2018-05-19 06:09:00 --> Helper loaded: date_helper
INFO - 2018-05-19 06:09:00 --> Helper loaded: util_helper
INFO - 2018-05-19 06:09:00 --> Helper loaded: text_helper
INFO - 2018-05-19 06:09:00 --> Helper loaded: string_helper
INFO - 2018-05-19 06:09:00 --> Utf8 Class Initialized
INFO - 2018-05-19 06:09:00 --> Database Driver Class Initialized
DEBUG - 2018-05-19 06:09:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-19 06:09:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-19 06:09:00 --> URI Class Initialized
DEBUG - 2018-05-19 06:09:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-19 06:09:00 --> Email Class Initialized
INFO - 2018-05-19 06:09:00 --> Router Class Initialized
INFO - 2018-05-19 06:09:00 --> Controller Class Initialized
INFO - 2018-05-19 06:09:00 --> Output Class Initialized
ERROR - 2018-05-19 06:09:00 --> 404 Page Not Found: ../modules/home/controllers/Home/js
INFO - 2018-05-19 06:09:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-19 06:09:00 --> Security Class Initialized
DEBUG - 2018-05-19 06:09:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:09:00 --> Email Class Initialized
INFO - 2018-05-19 06:09:00 --> Input Class Initialized
INFO - 2018-05-19 06:09:00 --> Controller Class Initialized
ERROR - 2018-05-19 06:09:00 --> 404 Page Not Found: ../modules/home/controllers/Home/js
INFO - 2018-05-19 06:09:00 --> Language Class Initialized
ERROR - 2018-05-19 06:09:00 --> 404 Page Not Found: /index
INFO - 2018-05-19 06:09:00 --> Config Class Initialized
INFO - 2018-05-19 06:09:00 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:09:00 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:09:00 --> Utf8 Class Initialized
INFO - 2018-05-19 06:09:00 --> URI Class Initialized
INFO - 2018-05-19 06:09:00 --> Router Class Initialized
INFO - 2018-05-19 06:09:01 --> Output Class Initialized
INFO - 2018-05-19 06:09:01 --> Security Class Initialized
DEBUG - 2018-05-19 06:09:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:09:01 --> Input Class Initialized
INFO - 2018-05-19 06:09:01 --> Language Class Initialized
ERROR - 2018-05-19 06:09:01 --> 404 Page Not Found: /index
INFO - 2018-05-19 06:09:01 --> Config Class Initialized
INFO - 2018-05-19 06:09:01 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:09:01 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:09:01 --> Utf8 Class Initialized
INFO - 2018-05-19 06:09:01 --> URI Class Initialized
INFO - 2018-05-19 06:09:01 --> Router Class Initialized
INFO - 2018-05-19 06:09:01 --> Output Class Initialized
INFO - 2018-05-19 06:09:01 --> Security Class Initialized
DEBUG - 2018-05-19 06:09:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:09:01 --> Input Class Initialized
INFO - 2018-05-19 06:09:01 --> Language Class Initialized
ERROR - 2018-05-19 06:09:01 --> 404 Page Not Found: /index
INFO - 2018-05-19 06:09:01 --> Config Class Initialized
INFO - 2018-05-19 06:09:01 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:09:01 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:09:01 --> Utf8 Class Initialized
INFO - 2018-05-19 06:09:01 --> URI Class Initialized
INFO - 2018-05-19 06:09:01 --> Router Class Initialized
INFO - 2018-05-19 06:09:01 --> Output Class Initialized
INFO - 2018-05-19 06:09:01 --> Security Class Initialized
DEBUG - 2018-05-19 06:09:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:09:01 --> Input Class Initialized
INFO - 2018-05-19 06:09:01 --> Language Class Initialized
ERROR - 2018-05-19 06:09:01 --> 404 Page Not Found: /index
INFO - 2018-05-19 06:09:01 --> Config Class Initialized
INFO - 2018-05-19 06:09:01 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:09:01 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:09:01 --> Utf8 Class Initialized
INFO - 2018-05-19 06:09:01 --> URI Class Initialized
INFO - 2018-05-19 06:09:01 --> Router Class Initialized
INFO - 2018-05-19 06:09:01 --> Output Class Initialized
INFO - 2018-05-19 06:09:01 --> Security Class Initialized
DEBUG - 2018-05-19 06:09:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:09:01 --> Input Class Initialized
INFO - 2018-05-19 06:09:01 --> Language Class Initialized
ERROR - 2018-05-19 06:09:01 --> 404 Page Not Found: /index
INFO - 2018-05-19 06:09:12 --> Config Class Initialized
INFO - 2018-05-19 06:09:12 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:09:13 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:09:13 --> Utf8 Class Initialized
INFO - 2018-05-19 06:09:13 --> URI Class Initialized
INFO - 2018-05-19 06:09:13 --> Router Class Initialized
INFO - 2018-05-19 06:09:13 --> Output Class Initialized
INFO - 2018-05-19 06:09:13 --> Security Class Initialized
DEBUG - 2018-05-19 06:09:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:09:13 --> Input Class Initialized
INFO - 2018-05-19 06:09:13 --> Language Class Initialized
INFO - 2018-05-19 06:09:13 --> Language Class Initialized
INFO - 2018-05-19 06:09:13 --> Config Class Initialized
INFO - 2018-05-19 06:09:13 --> Loader Class Initialized
DEBUG - 2018-05-19 06:09:13 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-19 06:09:13 --> Helper loaded: url_helper
INFO - 2018-05-19 06:09:13 --> Helper loaded: form_helper
INFO - 2018-05-19 06:09:13 --> Helper loaded: date_helper
INFO - 2018-05-19 06:09:13 --> Helper loaded: util_helper
INFO - 2018-05-19 06:09:13 --> Helper loaded: text_helper
INFO - 2018-05-19 06:09:13 --> Helper loaded: string_helper
INFO - 2018-05-19 06:09:13 --> Database Driver Class Initialized
DEBUG - 2018-05-19 06:09:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-19 06:09:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-19 06:09:13 --> Email Class Initialized
INFO - 2018-05-19 06:09:13 --> Controller Class Initialized
ERROR - 2018-05-19 06:09:13 --> 404 Page Not Found: ../modules/home/controllers/Home/refer-a-friend.html
INFO - 2018-05-19 06:09:15 --> Config Class Initialized
INFO - 2018-05-19 06:09:15 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:09:15 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:09:15 --> Utf8 Class Initialized
INFO - 2018-05-19 06:09:15 --> URI Class Initialized
INFO - 2018-05-19 06:09:15 --> Router Class Initialized
INFO - 2018-05-19 06:09:15 --> Output Class Initialized
INFO - 2018-05-19 06:09:15 --> Security Class Initialized
DEBUG - 2018-05-19 06:09:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:09:15 --> Input Class Initialized
INFO - 2018-05-19 06:09:15 --> Language Class Initialized
INFO - 2018-05-19 06:09:15 --> Language Class Initialized
INFO - 2018-05-19 06:09:15 --> Config Class Initialized
INFO - 2018-05-19 06:09:15 --> Loader Class Initialized
DEBUG - 2018-05-19 06:09:15 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-19 06:09:15 --> Helper loaded: url_helper
INFO - 2018-05-19 06:09:15 --> Helper loaded: form_helper
INFO - 2018-05-19 06:09:15 --> Helper loaded: date_helper
INFO - 2018-05-19 06:09:15 --> Helper loaded: util_helper
INFO - 2018-05-19 06:09:15 --> Helper loaded: text_helper
INFO - 2018-05-19 06:09:15 --> Helper loaded: string_helper
INFO - 2018-05-19 06:09:15 --> Database Driver Class Initialized
DEBUG - 2018-05-19 06:09:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-19 06:09:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-19 06:09:15 --> Email Class Initialized
INFO - 2018-05-19 06:09:15 --> Controller Class Initialized
DEBUG - 2018-05-19 06:09:15 --> Home MX_Controller Initialized
DEBUG - 2018-05-19 06:09:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-19 06:09:15 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-19 06:09:15 --> Login MX_Controller Initialized
INFO - 2018-05-19 06:09:15 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-19 06:09:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-19 06:09:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-19 06:09:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-19 06:09:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-19 06:09:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-19 06:09:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-19 06:09:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-19 06:09:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/refer_a_friend.php
INFO - 2018-05-19 06:09:15 --> Final output sent to browser
DEBUG - 2018-05-19 06:09:15 --> Total execution time: 0.6140
INFO - 2018-05-19 06:09:15 --> Config Class Initialized
INFO - 2018-05-19 06:09:15 --> Config Class Initialized
INFO - 2018-05-19 06:09:15 --> Hooks Class Initialized
INFO - 2018-05-19 06:09:15 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:09:15 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:09:15 --> Utf8 Class Initialized
DEBUG - 2018-05-19 06:09:15 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:09:15 --> URI Class Initialized
INFO - 2018-05-19 06:09:15 --> Utf8 Class Initialized
INFO - 2018-05-19 06:09:15 --> Router Class Initialized
INFO - 2018-05-19 06:09:15 --> URI Class Initialized
INFO - 2018-05-19 06:09:15 --> Output Class Initialized
INFO - 2018-05-19 06:09:15 --> Router Class Initialized
INFO - 2018-05-19 06:09:15 --> Output Class Initialized
INFO - 2018-05-19 06:09:15 --> Security Class Initialized
INFO - 2018-05-19 06:09:15 --> Security Class Initialized
DEBUG - 2018-05-19 06:09:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:09:16 --> Input Class Initialized
INFO - 2018-05-19 06:09:16 --> Language Class Initialized
INFO - 2018-05-19 06:09:16 --> Language Class Initialized
INFO - 2018-05-19 06:09:16 --> Config Class Initialized
DEBUG - 2018-05-19 06:09:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:09:16 --> Loader Class Initialized
INFO - 2018-05-19 06:09:16 --> Input Class Initialized
DEBUG - 2018-05-19 06:09:16 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-19 06:09:16 --> Language Class Initialized
INFO - 2018-05-19 06:09:16 --> Language Class Initialized
INFO - 2018-05-19 06:09:16 --> Config Class Initialized
INFO - 2018-05-19 06:09:16 --> Helper loaded: url_helper
INFO - 2018-05-19 06:09:16 --> Loader Class Initialized
INFO - 2018-05-19 06:09:16 --> Helper loaded: form_helper
DEBUG - 2018-05-19 06:09:16 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-19 06:09:16 --> Helper loaded: date_helper
INFO - 2018-05-19 06:09:16 --> Helper loaded: url_helper
INFO - 2018-05-19 06:09:16 --> Helper loaded: util_helper
INFO - 2018-05-19 06:09:16 --> Helper loaded: form_helper
INFO - 2018-05-19 06:09:16 --> Helper loaded: text_helper
INFO - 2018-05-19 06:09:16 --> Helper loaded: date_helper
INFO - 2018-05-19 06:09:16 --> Helper loaded: util_helper
INFO - 2018-05-19 06:09:16 --> Helper loaded: string_helper
INFO - 2018-05-19 06:09:16 --> Helper loaded: text_helper
INFO - 2018-05-19 06:09:16 --> Database Driver Class Initialized
INFO - 2018-05-19 06:09:16 --> Helper loaded: string_helper
INFO - 2018-05-19 06:09:16 --> Database Driver Class Initialized
DEBUG - 2018-05-19 06:09:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-19 06:09:16 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-05-19 06:09:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-19 06:09:16 --> Email Class Initialized
INFO - 2018-05-19 06:09:16 --> Controller Class Initialized
ERROR - 2018-05-19 06:09:16 --> 404 Page Not Found: ../modules/home/controllers/Home/js
INFO - 2018-05-19 06:09:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-19 06:09:16 --> Email Class Initialized
INFO - 2018-05-19 06:09:16 --> Controller Class Initialized
ERROR - 2018-05-19 06:09:16 --> 404 Page Not Found: ../modules/home/controllers/Home/js
INFO - 2018-05-19 06:09:18 --> Config Class Initialized
INFO - 2018-05-19 06:09:18 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:09:18 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:09:18 --> Utf8 Class Initialized
INFO - 2018-05-19 06:09:18 --> URI Class Initialized
DEBUG - 2018-05-19 06:09:18 --> No URI present. Default controller set.
INFO - 2018-05-19 06:09:18 --> Router Class Initialized
INFO - 2018-05-19 06:09:18 --> Output Class Initialized
INFO - 2018-05-19 06:09:18 --> Security Class Initialized
DEBUG - 2018-05-19 06:09:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:09:18 --> Input Class Initialized
INFO - 2018-05-19 06:09:18 --> Language Class Initialized
INFO - 2018-05-19 06:09:18 --> Language Class Initialized
INFO - 2018-05-19 06:09:18 --> Config Class Initialized
INFO - 2018-05-19 06:09:18 --> Loader Class Initialized
DEBUG - 2018-05-19 06:09:18 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-19 06:09:18 --> Helper loaded: url_helper
INFO - 2018-05-19 06:09:18 --> Helper loaded: form_helper
INFO - 2018-05-19 06:09:18 --> Helper loaded: date_helper
INFO - 2018-05-19 06:09:18 --> Helper loaded: util_helper
INFO - 2018-05-19 06:09:18 --> Helper loaded: text_helper
INFO - 2018-05-19 06:09:18 --> Helper loaded: string_helper
INFO - 2018-05-19 06:09:18 --> Database Driver Class Initialized
DEBUG - 2018-05-19 06:09:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-19 06:09:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-19 06:09:18 --> Email Class Initialized
INFO - 2018-05-19 06:09:18 --> Controller Class Initialized
DEBUG - 2018-05-19 06:09:18 --> Home MX_Controller Initialized
DEBUG - 2018-05-19 06:09:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-19 06:09:18 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-19 06:09:18 --> Login MX_Controller Initialized
INFO - 2018-05-19 06:09:18 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-19 06:09:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-19 06:09:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-19 06:09:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-19 06:09:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-19 06:09:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-19 06:09:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-19 06:09:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-19 06:09:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-05-19 06:09:19 --> Final output sent to browser
DEBUG - 2018-05-19 06:09:19 --> Total execution time: 0.6832
INFO - 2018-05-19 06:09:19 --> Config Class Initialized
INFO - 2018-05-19 06:09:19 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:09:19 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:09:19 --> Utf8 Class Initialized
INFO - 2018-05-19 06:09:19 --> URI Class Initialized
INFO - 2018-05-19 06:09:19 --> Router Class Initialized
INFO - 2018-05-19 06:09:19 --> Output Class Initialized
INFO - 2018-05-19 06:09:19 --> Security Class Initialized
DEBUG - 2018-05-19 06:09:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:09:19 --> Input Class Initialized
INFO - 2018-05-19 06:09:19 --> Language Class Initialized
ERROR - 2018-05-19 06:09:19 --> 404 Page Not Found: /index
INFO - 2018-05-19 06:09:19 --> Config Class Initialized
INFO - 2018-05-19 06:09:19 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:09:19 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:09:19 --> Utf8 Class Initialized
INFO - 2018-05-19 06:09:19 --> URI Class Initialized
INFO - 2018-05-19 06:09:19 --> Router Class Initialized
INFO - 2018-05-19 06:09:19 --> Output Class Initialized
INFO - 2018-05-19 06:09:19 --> Security Class Initialized
DEBUG - 2018-05-19 06:09:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:09:19 --> Input Class Initialized
INFO - 2018-05-19 06:09:19 --> Language Class Initialized
ERROR - 2018-05-19 06:09:20 --> 404 Page Not Found: /index
INFO - 2018-05-19 06:09:20 --> Config Class Initialized
INFO - 2018-05-19 06:09:20 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:09:20 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:09:20 --> Utf8 Class Initialized
INFO - 2018-05-19 06:09:20 --> URI Class Initialized
INFO - 2018-05-19 06:09:20 --> Router Class Initialized
INFO - 2018-05-19 06:09:20 --> Output Class Initialized
INFO - 2018-05-19 06:09:20 --> Security Class Initialized
DEBUG - 2018-05-19 06:09:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:09:20 --> Input Class Initialized
INFO - 2018-05-19 06:09:20 --> Language Class Initialized
ERROR - 2018-05-19 06:09:20 --> 404 Page Not Found: /index
INFO - 2018-05-19 06:09:22 --> Config Class Initialized
INFO - 2018-05-19 06:09:22 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:09:22 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:09:22 --> Utf8 Class Initialized
INFO - 2018-05-19 06:09:22 --> URI Class Initialized
INFO - 2018-05-19 06:09:22 --> Router Class Initialized
INFO - 2018-05-19 06:09:22 --> Output Class Initialized
INFO - 2018-05-19 06:09:22 --> Security Class Initialized
DEBUG - 2018-05-19 06:09:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:09:22 --> Input Class Initialized
INFO - 2018-05-19 06:09:22 --> Language Class Initialized
INFO - 2018-05-19 06:09:22 --> Language Class Initialized
INFO - 2018-05-19 06:09:22 --> Config Class Initialized
INFO - 2018-05-19 06:09:22 --> Loader Class Initialized
DEBUG - 2018-05-19 06:09:22 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-19 06:09:22 --> Helper loaded: url_helper
INFO - 2018-05-19 06:09:22 --> Helper loaded: form_helper
INFO - 2018-05-19 06:09:22 --> Helper loaded: date_helper
INFO - 2018-05-19 06:09:22 --> Helper loaded: util_helper
INFO - 2018-05-19 06:09:22 --> Helper loaded: text_helper
INFO - 2018-05-19 06:09:22 --> Helper loaded: string_helper
INFO - 2018-05-19 06:09:22 --> Database Driver Class Initialized
DEBUG - 2018-05-19 06:09:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-19 06:09:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-19 06:09:22 --> Email Class Initialized
INFO - 2018-05-19 06:09:22 --> Controller Class Initialized
DEBUG - 2018-05-19 06:09:22 --> Home MX_Controller Initialized
DEBUG - 2018-05-19 06:09:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-19 06:09:22 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-19 06:09:22 --> Login MX_Controller Initialized
INFO - 2018-05-19 06:09:22 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-19 06:09:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-19 06:09:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-19 06:09:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-19 06:09:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-19 06:09:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-19 06:09:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-19 06:09:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-19 06:09:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/progress.php
INFO - 2018-05-19 06:09:23 --> Final output sent to browser
DEBUG - 2018-05-19 06:09:23 --> Total execution time: 0.5702
INFO - 2018-05-19 06:09:23 --> Config Class Initialized
INFO - 2018-05-19 06:09:23 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:09:23 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:09:23 --> Utf8 Class Initialized
INFO - 2018-05-19 06:09:23 --> URI Class Initialized
INFO - 2018-05-19 06:09:23 --> Router Class Initialized
INFO - 2018-05-19 06:09:23 --> Output Class Initialized
INFO - 2018-05-19 06:09:23 --> Security Class Initialized
DEBUG - 2018-05-19 06:09:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:09:23 --> Input Class Initialized
INFO - 2018-05-19 06:09:23 --> Language Class Initialized
ERROR - 2018-05-19 06:09:23 --> 404 Page Not Found: /index
INFO - 2018-05-19 06:09:23 --> Config Class Initialized
INFO - 2018-05-19 06:09:23 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:09:23 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:09:23 --> Utf8 Class Initialized
INFO - 2018-05-19 06:09:23 --> URI Class Initialized
INFO - 2018-05-19 06:09:24 --> Router Class Initialized
INFO - 2018-05-19 06:09:24 --> Output Class Initialized
INFO - 2018-05-19 06:09:24 --> Security Class Initialized
DEBUG - 2018-05-19 06:09:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:09:24 --> Input Class Initialized
INFO - 2018-05-19 06:09:24 --> Language Class Initialized
ERROR - 2018-05-19 06:09:24 --> 404 Page Not Found: /index
INFO - 2018-05-19 06:09:24 --> Config Class Initialized
INFO - 2018-05-19 06:09:24 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:09:24 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:09:24 --> Utf8 Class Initialized
INFO - 2018-05-19 06:09:24 --> URI Class Initialized
INFO - 2018-05-19 06:09:24 --> Router Class Initialized
INFO - 2018-05-19 06:09:24 --> Output Class Initialized
INFO - 2018-05-19 06:09:24 --> Security Class Initialized
DEBUG - 2018-05-19 06:09:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:09:24 --> Input Class Initialized
INFO - 2018-05-19 06:09:24 --> Language Class Initialized
ERROR - 2018-05-19 06:09:24 --> 404 Page Not Found: /index
INFO - 2018-05-19 06:09:27 --> Config Class Initialized
INFO - 2018-05-19 06:09:27 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:09:27 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:09:27 --> Utf8 Class Initialized
INFO - 2018-05-19 06:09:27 --> URI Class Initialized
INFO - 2018-05-19 06:09:27 --> Router Class Initialized
INFO - 2018-05-19 06:09:27 --> Output Class Initialized
INFO - 2018-05-19 06:09:27 --> Security Class Initialized
DEBUG - 2018-05-19 06:09:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:09:27 --> Input Class Initialized
INFO - 2018-05-19 06:09:27 --> Language Class Initialized
INFO - 2018-05-19 06:09:27 --> Language Class Initialized
INFO - 2018-05-19 06:09:27 --> Config Class Initialized
INFO - 2018-05-19 06:09:27 --> Loader Class Initialized
DEBUG - 2018-05-19 06:09:27 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-19 06:09:27 --> Helper loaded: url_helper
INFO - 2018-05-19 06:09:27 --> Helper loaded: form_helper
INFO - 2018-05-19 06:09:27 --> Helper loaded: date_helper
INFO - 2018-05-19 06:09:27 --> Helper loaded: util_helper
INFO - 2018-05-19 06:09:27 --> Helper loaded: text_helper
INFO - 2018-05-19 06:09:27 --> Helper loaded: string_helper
INFO - 2018-05-19 06:09:27 --> Database Driver Class Initialized
DEBUG - 2018-05-19 06:09:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-19 06:09:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-19 06:09:27 --> Email Class Initialized
INFO - 2018-05-19 06:09:27 --> Controller Class Initialized
DEBUG - 2018-05-19 06:09:27 --> Home MX_Controller Initialized
DEBUG - 2018-05-19 06:09:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-19 06:09:27 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-19 06:09:27 --> Login MX_Controller Initialized
INFO - 2018-05-19 06:09:27 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-19 06:09:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-19 06:09:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-19 06:09:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-19 06:09:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-19 06:09:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-19 06:09:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-19 06:09:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-19 06:09:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/progress_product.php
INFO - 2018-05-19 06:09:27 --> Final output sent to browser
DEBUG - 2018-05-19 06:09:27 --> Total execution time: 0.5608
INFO - 2018-05-19 06:09:28 --> Config Class Initialized
INFO - 2018-05-19 06:09:28 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:09:28 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:09:28 --> Utf8 Class Initialized
INFO - 2018-05-19 06:09:28 --> URI Class Initialized
INFO - 2018-05-19 06:09:28 --> Router Class Initialized
INFO - 2018-05-19 06:09:28 --> Output Class Initialized
INFO - 2018-05-19 06:09:28 --> Security Class Initialized
DEBUG - 2018-05-19 06:09:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:09:28 --> Input Class Initialized
INFO - 2018-05-19 06:09:28 --> Language Class Initialized
ERROR - 2018-05-19 06:09:28 --> 404 Page Not Found: /index
INFO - 2018-05-19 06:09:28 --> Config Class Initialized
INFO - 2018-05-19 06:09:28 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:09:28 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:09:28 --> Utf8 Class Initialized
INFO - 2018-05-19 06:09:28 --> URI Class Initialized
INFO - 2018-05-19 06:09:28 --> Router Class Initialized
INFO - 2018-05-19 06:09:29 --> Output Class Initialized
INFO - 2018-05-19 06:09:29 --> Security Class Initialized
DEBUG - 2018-05-19 06:09:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:09:29 --> Input Class Initialized
INFO - 2018-05-19 06:09:29 --> Language Class Initialized
ERROR - 2018-05-19 06:09:29 --> 404 Page Not Found: /index
INFO - 2018-05-19 06:09:29 --> Config Class Initialized
INFO - 2018-05-19 06:09:29 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:09:29 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:09:29 --> Utf8 Class Initialized
INFO - 2018-05-19 06:09:29 --> URI Class Initialized
INFO - 2018-05-19 06:09:29 --> Router Class Initialized
INFO - 2018-05-19 06:09:29 --> Output Class Initialized
INFO - 2018-05-19 06:09:29 --> Security Class Initialized
DEBUG - 2018-05-19 06:09:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:09:29 --> Input Class Initialized
INFO - 2018-05-19 06:09:29 --> Language Class Initialized
ERROR - 2018-05-19 06:09:29 --> 404 Page Not Found: /index
INFO - 2018-05-19 06:09:32 --> Config Class Initialized
INFO - 2018-05-19 06:09:32 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:09:32 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:09:32 --> Utf8 Class Initialized
INFO - 2018-05-19 06:09:32 --> URI Class Initialized
INFO - 2018-05-19 06:09:32 --> Router Class Initialized
INFO - 2018-05-19 06:09:32 --> Output Class Initialized
INFO - 2018-05-19 06:09:32 --> Security Class Initialized
DEBUG - 2018-05-19 06:09:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:09:32 --> Input Class Initialized
INFO - 2018-05-19 06:09:32 --> Language Class Initialized
INFO - 2018-05-19 06:09:32 --> Language Class Initialized
INFO - 2018-05-19 06:09:32 --> Config Class Initialized
INFO - 2018-05-19 06:09:32 --> Loader Class Initialized
DEBUG - 2018-05-19 06:09:32 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-19 06:09:32 --> Helper loaded: url_helper
INFO - 2018-05-19 06:09:32 --> Helper loaded: form_helper
INFO - 2018-05-19 06:09:32 --> Helper loaded: date_helper
INFO - 2018-05-19 06:09:32 --> Helper loaded: util_helper
INFO - 2018-05-19 06:09:32 --> Helper loaded: text_helper
INFO - 2018-05-19 06:09:32 --> Helper loaded: string_helper
INFO - 2018-05-19 06:09:32 --> Database Driver Class Initialized
DEBUG - 2018-05-19 06:09:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-19 06:09:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-19 06:09:32 --> Email Class Initialized
INFO - 2018-05-19 06:09:32 --> Controller Class Initialized
DEBUG - 2018-05-19 06:09:32 --> Profile MX_Controller Initialized
DEBUG - 2018-05-19 06:09:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-19 06:09:32 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-19 06:09:32 --> Login MX_Controller Initialized
INFO - 2018-05-19 06:09:32 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-19 06:09:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-19 06:09:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-19 06:09:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-19 06:09:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-19 06:09:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-19 06:09:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/profile_left_nav.php
DEBUG - 2018-05-19 06:09:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-19 06:09:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-19 06:09:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/profile.php
INFO - 2018-05-19 06:09:32 --> Final output sent to browser
DEBUG - 2018-05-19 06:09:32 --> Total execution time: 0.5854
INFO - 2018-05-19 06:09:32 --> Config Class Initialized
INFO - 2018-05-19 06:09:32 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:09:32 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:09:33 --> Config Class Initialized
INFO - 2018-05-19 06:09:33 --> Hooks Class Initialized
INFO - 2018-05-19 06:09:33 --> Utf8 Class Initialized
INFO - 2018-05-19 06:09:33 --> URI Class Initialized
DEBUG - 2018-05-19 06:09:33 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:09:33 --> Utf8 Class Initialized
INFO - 2018-05-19 06:09:33 --> Router Class Initialized
INFO - 2018-05-19 06:09:33 --> URI Class Initialized
INFO - 2018-05-19 06:09:33 --> Output Class Initialized
INFO - 2018-05-19 06:09:33 --> Security Class Initialized
INFO - 2018-05-19 06:09:33 --> Router Class Initialized
INFO - 2018-05-19 06:09:33 --> Output Class Initialized
DEBUG - 2018-05-19 06:09:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:09:33 --> Security Class Initialized
DEBUG - 2018-05-19 06:09:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:09:33 --> Input Class Initialized
INFO - 2018-05-19 06:09:33 --> Language Class Initialized
ERROR - 2018-05-19 06:09:33 --> 404 Page Not Found: /index
INFO - 2018-05-19 06:09:33 --> Input Class Initialized
INFO - 2018-05-19 06:09:33 --> Language Class Initialized
ERROR - 2018-05-19 06:09:33 --> 404 Page Not Found: /index
INFO - 2018-05-19 06:09:33 --> Config Class Initialized
INFO - 2018-05-19 06:09:33 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:09:33 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:09:33 --> Utf8 Class Initialized
INFO - 2018-05-19 06:09:33 --> URI Class Initialized
INFO - 2018-05-19 06:09:33 --> Router Class Initialized
INFO - 2018-05-19 06:09:33 --> Output Class Initialized
INFO - 2018-05-19 06:09:33 --> Security Class Initialized
DEBUG - 2018-05-19 06:09:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:09:33 --> Input Class Initialized
INFO - 2018-05-19 06:09:33 --> Language Class Initialized
ERROR - 2018-05-19 06:09:33 --> 404 Page Not Found: /index
INFO - 2018-05-19 06:09:33 --> Config Class Initialized
INFO - 2018-05-19 06:09:33 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:09:34 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:09:34 --> Utf8 Class Initialized
INFO - 2018-05-19 06:09:34 --> URI Class Initialized
INFO - 2018-05-19 06:09:34 --> Router Class Initialized
INFO - 2018-05-19 06:09:34 --> Output Class Initialized
INFO - 2018-05-19 06:09:34 --> Security Class Initialized
DEBUG - 2018-05-19 06:09:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:09:34 --> Input Class Initialized
INFO - 2018-05-19 06:09:34 --> Language Class Initialized
ERROR - 2018-05-19 06:09:34 --> 404 Page Not Found: /index
INFO - 2018-05-19 06:09:35 --> Config Class Initialized
INFO - 2018-05-19 06:09:35 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:09:35 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:09:35 --> Utf8 Class Initialized
INFO - 2018-05-19 06:09:35 --> URI Class Initialized
INFO - 2018-05-19 06:09:35 --> Router Class Initialized
INFO - 2018-05-19 06:09:35 --> Output Class Initialized
INFO - 2018-05-19 06:09:35 --> Security Class Initialized
DEBUG - 2018-05-19 06:09:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:09:35 --> Input Class Initialized
INFO - 2018-05-19 06:09:35 --> Language Class Initialized
INFO - 2018-05-19 06:09:35 --> Language Class Initialized
INFO - 2018-05-19 06:09:35 --> Config Class Initialized
INFO - 2018-05-19 06:09:35 --> Loader Class Initialized
DEBUG - 2018-05-19 06:09:35 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-19 06:09:35 --> Helper loaded: url_helper
INFO - 2018-05-19 06:09:35 --> Helper loaded: form_helper
INFO - 2018-05-19 06:09:35 --> Helper loaded: date_helper
INFO - 2018-05-19 06:09:35 --> Helper loaded: util_helper
INFO - 2018-05-19 06:09:35 --> Helper loaded: text_helper
INFO - 2018-05-19 06:09:35 --> Helper loaded: string_helper
INFO - 2018-05-19 06:09:35 --> Database Driver Class Initialized
DEBUG - 2018-05-19 06:09:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-19 06:09:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-19 06:09:35 --> Email Class Initialized
INFO - 2018-05-19 06:09:35 --> Controller Class Initialized
DEBUG - 2018-05-19 06:09:35 --> Profile MX_Controller Initialized
DEBUG - 2018-05-19 06:09:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-19 06:09:35 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-19 06:09:35 --> Login MX_Controller Initialized
INFO - 2018-05-19 06:09:35 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-19 06:09:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-19 06:09:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-19 06:09:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-19 06:09:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-19 06:09:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-19 06:09:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/profile_left_nav.php
DEBUG - 2018-05-19 06:09:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-19 06:09:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-19 06:09:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/reset_password.php
INFO - 2018-05-19 06:09:36 --> Final output sent to browser
DEBUG - 2018-05-19 06:09:36 --> Total execution time: 0.5798
INFO - 2018-05-19 06:09:36 --> Config Class Initialized
INFO - 2018-05-19 06:09:36 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:09:36 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:09:36 --> Utf8 Class Initialized
INFO - 2018-05-19 06:09:36 --> URI Class Initialized
INFO - 2018-05-19 06:09:36 --> Router Class Initialized
INFO - 2018-05-19 06:09:36 --> Output Class Initialized
INFO - 2018-05-19 06:09:36 --> Security Class Initialized
DEBUG - 2018-05-19 06:09:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:09:36 --> Input Class Initialized
INFO - 2018-05-19 06:09:36 --> Language Class Initialized
ERROR - 2018-05-19 06:09:36 --> 404 Page Not Found: /index
INFO - 2018-05-19 06:09:36 --> Config Class Initialized
INFO - 2018-05-19 06:09:36 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:09:36 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:09:36 --> Utf8 Class Initialized
INFO - 2018-05-19 06:09:36 --> URI Class Initialized
INFO - 2018-05-19 06:09:36 --> Router Class Initialized
INFO - 2018-05-19 06:09:36 --> Output Class Initialized
INFO - 2018-05-19 06:09:36 --> Security Class Initialized
DEBUG - 2018-05-19 06:09:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:09:36 --> Input Class Initialized
INFO - 2018-05-19 06:09:37 --> Language Class Initialized
ERROR - 2018-05-19 06:09:37 --> 404 Page Not Found: /index
INFO - 2018-05-19 06:09:37 --> Config Class Initialized
INFO - 2018-05-19 06:09:37 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:09:37 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:09:37 --> Utf8 Class Initialized
INFO - 2018-05-19 06:09:37 --> URI Class Initialized
INFO - 2018-05-19 06:09:37 --> Router Class Initialized
INFO - 2018-05-19 06:09:37 --> Output Class Initialized
INFO - 2018-05-19 06:09:37 --> Security Class Initialized
DEBUG - 2018-05-19 06:09:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:09:37 --> Input Class Initialized
INFO - 2018-05-19 06:09:37 --> Language Class Initialized
ERROR - 2018-05-19 06:09:37 --> 404 Page Not Found: /index
INFO - 2018-05-19 06:09:39 --> Config Class Initialized
INFO - 2018-05-19 06:09:39 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:09:39 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:09:39 --> Utf8 Class Initialized
INFO - 2018-05-19 06:09:39 --> URI Class Initialized
INFO - 2018-05-19 06:09:39 --> Router Class Initialized
INFO - 2018-05-19 06:09:39 --> Output Class Initialized
INFO - 2018-05-19 06:09:39 --> Security Class Initialized
DEBUG - 2018-05-19 06:09:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:09:39 --> Input Class Initialized
INFO - 2018-05-19 06:09:39 --> Language Class Initialized
INFO - 2018-05-19 06:09:39 --> Language Class Initialized
INFO - 2018-05-19 06:09:39 --> Config Class Initialized
INFO - 2018-05-19 06:09:39 --> Loader Class Initialized
DEBUG - 2018-05-19 06:09:39 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-19 06:09:39 --> Helper loaded: url_helper
INFO - 2018-05-19 06:09:39 --> Helper loaded: form_helper
INFO - 2018-05-19 06:09:39 --> Helper loaded: date_helper
INFO - 2018-05-19 06:09:39 --> Helper loaded: util_helper
INFO - 2018-05-19 06:09:39 --> Helper loaded: text_helper
INFO - 2018-05-19 06:09:40 --> Helper loaded: string_helper
INFO - 2018-05-19 06:09:40 --> Database Driver Class Initialized
DEBUG - 2018-05-19 06:09:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-19 06:09:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-19 06:09:40 --> Email Class Initialized
INFO - 2018-05-19 06:09:40 --> Controller Class Initialized
DEBUG - 2018-05-19 06:09:40 --> Profile MX_Controller Initialized
DEBUG - 2018-05-19 06:09:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-19 06:09:40 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-19 06:09:40 --> Login MX_Controller Initialized
INFO - 2018-05-19 06:09:40 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-19 06:09:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-19 06:09:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-19 06:09:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-19 06:09:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-19 06:09:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-19 06:09:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/profile_left_nav.php
DEBUG - 2018-05-19 06:09:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-19 06:09:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-19 06:09:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/reset_password.php
INFO - 2018-05-19 06:09:40 --> Final output sent to browser
DEBUG - 2018-05-19 06:09:40 --> Total execution time: 0.5998
INFO - 2018-05-19 06:09:40 --> Config Class Initialized
INFO - 2018-05-19 06:09:40 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:09:40 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:09:40 --> Utf8 Class Initialized
INFO - 2018-05-19 06:09:40 --> URI Class Initialized
INFO - 2018-05-19 06:09:40 --> Router Class Initialized
INFO - 2018-05-19 06:09:40 --> Output Class Initialized
INFO - 2018-05-19 06:09:40 --> Security Class Initialized
DEBUG - 2018-05-19 06:09:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:09:40 --> Input Class Initialized
INFO - 2018-05-19 06:09:40 --> Language Class Initialized
ERROR - 2018-05-19 06:09:40 --> 404 Page Not Found: /index
INFO - 2018-05-19 06:09:41 --> Config Class Initialized
INFO - 2018-05-19 06:09:41 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:09:41 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:09:41 --> Utf8 Class Initialized
INFO - 2018-05-19 06:09:41 --> URI Class Initialized
INFO - 2018-05-19 06:09:41 --> Router Class Initialized
INFO - 2018-05-19 06:09:41 --> Output Class Initialized
INFO - 2018-05-19 06:09:41 --> Security Class Initialized
DEBUG - 2018-05-19 06:09:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:09:41 --> Input Class Initialized
INFO - 2018-05-19 06:09:41 --> Language Class Initialized
ERROR - 2018-05-19 06:09:41 --> 404 Page Not Found: /index
INFO - 2018-05-19 06:09:41 --> Config Class Initialized
INFO - 2018-05-19 06:09:41 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:09:41 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:09:41 --> Utf8 Class Initialized
INFO - 2018-05-19 06:09:41 --> URI Class Initialized
INFO - 2018-05-19 06:09:41 --> Router Class Initialized
INFO - 2018-05-19 06:09:41 --> Output Class Initialized
INFO - 2018-05-19 06:09:41 --> Security Class Initialized
DEBUG - 2018-05-19 06:09:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:09:41 --> Input Class Initialized
INFO - 2018-05-19 06:09:41 --> Language Class Initialized
ERROR - 2018-05-19 06:09:41 --> 404 Page Not Found: /index
INFO - 2018-05-19 06:09:47 --> Config Class Initialized
INFO - 2018-05-19 06:09:47 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:09:47 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:09:47 --> Utf8 Class Initialized
INFO - 2018-05-19 06:09:47 --> URI Class Initialized
INFO - 2018-05-19 06:09:47 --> Router Class Initialized
INFO - 2018-05-19 06:09:47 --> Output Class Initialized
INFO - 2018-05-19 06:09:47 --> Security Class Initialized
DEBUG - 2018-05-19 06:09:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:09:47 --> Input Class Initialized
INFO - 2018-05-19 06:09:47 --> Language Class Initialized
INFO - 2018-05-19 06:09:47 --> Language Class Initialized
INFO - 2018-05-19 06:09:47 --> Config Class Initialized
INFO - 2018-05-19 06:09:47 --> Loader Class Initialized
DEBUG - 2018-05-19 06:09:47 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-19 06:09:47 --> Helper loaded: url_helper
INFO - 2018-05-19 06:09:47 --> Helper loaded: form_helper
INFO - 2018-05-19 06:09:47 --> Helper loaded: date_helper
INFO - 2018-05-19 06:09:47 --> Helper loaded: util_helper
INFO - 2018-05-19 06:09:47 --> Helper loaded: text_helper
INFO - 2018-05-19 06:09:47 --> Helper loaded: string_helper
INFO - 2018-05-19 06:09:47 --> Database Driver Class Initialized
DEBUG - 2018-05-19 06:09:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-19 06:09:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-19 06:09:47 --> Email Class Initialized
INFO - 2018-05-19 06:09:47 --> Controller Class Initialized
DEBUG - 2018-05-19 06:09:47 --> Profile MX_Controller Initialized
DEBUG - 2018-05-19 06:09:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-19 06:09:47 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-19 06:09:47 --> Login MX_Controller Initialized
INFO - 2018-05-19 06:09:47 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-19 06:09:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-19 06:09:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-19 06:09:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-19 06:09:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-19 06:09:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-19 06:09:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/profile_left_nav.php
DEBUG - 2018-05-19 06:09:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-19 06:09:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-19 06:09:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/profile.php
INFO - 2018-05-19 06:09:47 --> Final output sent to browser
DEBUG - 2018-05-19 06:09:47 --> Total execution time: 0.5897
INFO - 2018-05-19 06:09:47 --> Config Class Initialized
INFO - 2018-05-19 06:09:47 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:09:47 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:09:47 --> Config Class Initialized
INFO - 2018-05-19 06:09:48 --> Utf8 Class Initialized
INFO - 2018-05-19 06:09:48 --> Hooks Class Initialized
INFO - 2018-05-19 06:09:48 --> URI Class Initialized
INFO - 2018-05-19 06:09:48 --> Router Class Initialized
INFO - 2018-05-19 06:09:48 --> Output Class Initialized
DEBUG - 2018-05-19 06:09:48 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:09:48 --> Security Class Initialized
INFO - 2018-05-19 06:09:48 --> Utf8 Class Initialized
DEBUG - 2018-05-19 06:09:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:09:48 --> URI Class Initialized
INFO - 2018-05-19 06:09:48 --> Input Class Initialized
INFO - 2018-05-19 06:09:48 --> Language Class Initialized
INFO - 2018-05-19 06:09:48 --> Router Class Initialized
INFO - 2018-05-19 06:09:48 --> Output Class Initialized
ERROR - 2018-05-19 06:09:48 --> 404 Page Not Found: /index
INFO - 2018-05-19 06:09:48 --> Security Class Initialized
DEBUG - 2018-05-19 06:09:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:09:48 --> Input Class Initialized
INFO - 2018-05-19 06:09:48 --> Language Class Initialized
INFO - 2018-05-19 06:09:48 --> Config Class Initialized
INFO - 2018-05-19 06:09:48 --> Hooks Class Initialized
ERROR - 2018-05-19 06:09:48 --> 404 Page Not Found: /index
DEBUG - 2018-05-19 06:09:48 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:09:48 --> Utf8 Class Initialized
INFO - 2018-05-19 06:09:48 --> URI Class Initialized
INFO - 2018-05-19 06:09:48 --> Router Class Initialized
INFO - 2018-05-19 06:09:48 --> Output Class Initialized
INFO - 2018-05-19 06:09:48 --> Security Class Initialized
DEBUG - 2018-05-19 06:09:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:09:48 --> Input Class Initialized
INFO - 2018-05-19 06:09:48 --> Language Class Initialized
ERROR - 2018-05-19 06:09:48 --> 404 Page Not Found: /index
INFO - 2018-05-19 06:09:48 --> Config Class Initialized
INFO - 2018-05-19 06:09:48 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:09:48 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:09:48 --> Utf8 Class Initialized
INFO - 2018-05-19 06:09:48 --> URI Class Initialized
INFO - 2018-05-19 06:09:48 --> Router Class Initialized
INFO - 2018-05-19 06:09:48 --> Output Class Initialized
INFO - 2018-05-19 06:09:48 --> Security Class Initialized
DEBUG - 2018-05-19 06:09:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:09:48 --> Input Class Initialized
INFO - 2018-05-19 06:09:48 --> Language Class Initialized
ERROR - 2018-05-19 06:09:48 --> 404 Page Not Found: /index
INFO - 2018-05-19 06:10:30 --> Config Class Initialized
INFO - 2018-05-19 06:10:30 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:10:30 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:10:30 --> Utf8 Class Initialized
INFO - 2018-05-19 06:10:30 --> URI Class Initialized
INFO - 2018-05-19 06:10:30 --> Router Class Initialized
INFO - 2018-05-19 06:10:30 --> Output Class Initialized
INFO - 2018-05-19 06:10:30 --> Security Class Initialized
DEBUG - 2018-05-19 06:10:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:10:30 --> Input Class Initialized
INFO - 2018-05-19 06:10:30 --> Language Class Initialized
INFO - 2018-05-19 06:10:30 --> Language Class Initialized
INFO - 2018-05-19 06:10:30 --> Config Class Initialized
INFO - 2018-05-19 06:10:30 --> Loader Class Initialized
DEBUG - 2018-05-19 06:10:30 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-19 06:10:30 --> Helper loaded: url_helper
INFO - 2018-05-19 06:10:30 --> Helper loaded: form_helper
INFO - 2018-05-19 06:10:31 --> Helper loaded: date_helper
INFO - 2018-05-19 06:10:31 --> Helper loaded: util_helper
INFO - 2018-05-19 06:10:31 --> Helper loaded: text_helper
INFO - 2018-05-19 06:10:31 --> Helper loaded: string_helper
INFO - 2018-05-19 06:10:31 --> Database Driver Class Initialized
DEBUG - 2018-05-19 06:10:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-19 06:10:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-19 06:10:31 --> Email Class Initialized
INFO - 2018-05-19 06:10:31 --> Controller Class Initialized
DEBUG - 2018-05-19 06:10:31 --> Profile MX_Controller Initialized
DEBUG - 2018-05-19 06:10:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-19 06:10:31 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-19 06:10:31 --> Login MX_Controller Initialized
INFO - 2018-05-19 06:10:31 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-19 06:10:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-19 06:10:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-19 06:10:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-19 06:10:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-19 06:10:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-19 06:10:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/profile_left_nav.php
DEBUG - 2018-05-19 06:10:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-19 06:10:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-19 06:10:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/reset_password.php
INFO - 2018-05-19 06:10:31 --> Final output sent to browser
DEBUG - 2018-05-19 06:10:31 --> Total execution time: 0.5966
INFO - 2018-05-19 06:10:31 --> Config Class Initialized
INFO - 2018-05-19 06:10:31 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:10:31 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:10:31 --> Utf8 Class Initialized
INFO - 2018-05-19 06:10:31 --> URI Class Initialized
INFO - 2018-05-19 06:10:31 --> Router Class Initialized
INFO - 2018-05-19 06:10:31 --> Output Class Initialized
INFO - 2018-05-19 06:10:31 --> Security Class Initialized
DEBUG - 2018-05-19 06:10:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:10:31 --> Input Class Initialized
INFO - 2018-05-19 06:10:32 --> Language Class Initialized
ERROR - 2018-05-19 06:10:32 --> 404 Page Not Found: /index
INFO - 2018-05-19 06:10:32 --> Config Class Initialized
INFO - 2018-05-19 06:10:32 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:10:32 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:10:32 --> Utf8 Class Initialized
INFO - 2018-05-19 06:10:32 --> URI Class Initialized
INFO - 2018-05-19 06:10:32 --> Router Class Initialized
INFO - 2018-05-19 06:10:32 --> Output Class Initialized
INFO - 2018-05-19 06:10:32 --> Security Class Initialized
DEBUG - 2018-05-19 06:10:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:10:32 --> Input Class Initialized
INFO - 2018-05-19 06:10:32 --> Language Class Initialized
ERROR - 2018-05-19 06:10:32 --> 404 Page Not Found: /index
INFO - 2018-05-19 06:10:32 --> Config Class Initialized
INFO - 2018-05-19 06:10:32 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:10:32 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:10:32 --> Utf8 Class Initialized
INFO - 2018-05-19 06:10:32 --> URI Class Initialized
INFO - 2018-05-19 06:10:32 --> Router Class Initialized
INFO - 2018-05-19 06:10:32 --> Output Class Initialized
INFO - 2018-05-19 06:10:32 --> Security Class Initialized
DEBUG - 2018-05-19 06:10:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:10:32 --> Input Class Initialized
INFO - 2018-05-19 06:10:32 --> Language Class Initialized
ERROR - 2018-05-19 06:10:32 --> 404 Page Not Found: /index
INFO - 2018-05-19 06:11:15 --> Config Class Initialized
INFO - 2018-05-19 06:11:15 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:11:15 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:11:15 --> Utf8 Class Initialized
INFO - 2018-05-19 06:11:15 --> URI Class Initialized
INFO - 2018-05-19 06:11:15 --> Router Class Initialized
INFO - 2018-05-19 06:11:15 --> Output Class Initialized
INFO - 2018-05-19 06:11:15 --> Security Class Initialized
DEBUG - 2018-05-19 06:11:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:11:15 --> Input Class Initialized
INFO - 2018-05-19 06:11:15 --> Language Class Initialized
INFO - 2018-05-19 06:11:15 --> Language Class Initialized
INFO - 2018-05-19 06:11:15 --> Config Class Initialized
INFO - 2018-05-19 06:11:15 --> Loader Class Initialized
DEBUG - 2018-05-19 06:11:15 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-19 06:11:15 --> Helper loaded: url_helper
INFO - 2018-05-19 06:11:15 --> Helper loaded: form_helper
INFO - 2018-05-19 06:11:15 --> Helper loaded: date_helper
INFO - 2018-05-19 06:11:15 --> Helper loaded: util_helper
INFO - 2018-05-19 06:11:15 --> Helper loaded: text_helper
INFO - 2018-05-19 06:11:15 --> Helper loaded: string_helper
INFO - 2018-05-19 06:11:15 --> Database Driver Class Initialized
DEBUG - 2018-05-19 06:11:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-19 06:11:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-19 06:11:15 --> Email Class Initialized
INFO - 2018-05-19 06:11:15 --> Controller Class Initialized
DEBUG - 2018-05-19 06:11:15 --> Profile MX_Controller Initialized
DEBUG - 2018-05-19 06:11:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-19 06:11:15 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-19 06:11:15 --> Login MX_Controller Initialized
INFO - 2018-05-19 06:11:15 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-19 06:11:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-19 06:11:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-19 06:11:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-19 06:11:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-19 06:11:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-19 06:11:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/profile_left_nav.php
DEBUG - 2018-05-19 06:11:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-19 06:11:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-19 06:11:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/profile.php
INFO - 2018-05-19 06:11:16 --> Final output sent to browser
DEBUG - 2018-05-19 06:11:16 --> Total execution time: 0.6142
INFO - 2018-05-19 06:11:16 --> Config Class Initialized
INFO - 2018-05-19 06:11:16 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:11:16 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:11:16 --> Utf8 Class Initialized
INFO - 2018-05-19 06:11:16 --> Config Class Initialized
INFO - 2018-05-19 06:11:16 --> Hooks Class Initialized
INFO - 2018-05-19 06:11:16 --> URI Class Initialized
DEBUG - 2018-05-19 06:11:16 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:11:16 --> Utf8 Class Initialized
INFO - 2018-05-19 06:11:16 --> URI Class Initialized
INFO - 2018-05-19 06:11:16 --> Router Class Initialized
INFO - 2018-05-19 06:11:16 --> Router Class Initialized
INFO - 2018-05-19 06:11:16 --> Output Class Initialized
INFO - 2018-05-19 06:11:16 --> Security Class Initialized
INFO - 2018-05-19 06:11:16 --> Output Class Initialized
DEBUG - 2018-05-19 06:11:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:11:16 --> Security Class Initialized
INFO - 2018-05-19 06:11:16 --> Input Class Initialized
DEBUG - 2018-05-19 06:11:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:11:16 --> Language Class Initialized
INFO - 2018-05-19 06:11:16 --> Input Class Initialized
INFO - 2018-05-19 06:11:16 --> Language Class Initialized
ERROR - 2018-05-19 06:11:16 --> 404 Page Not Found: /index
ERROR - 2018-05-19 06:11:16 --> 404 Page Not Found: /index
INFO - 2018-05-19 06:11:16 --> Config Class Initialized
INFO - 2018-05-19 06:11:17 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:11:17 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:11:17 --> Utf8 Class Initialized
INFO - 2018-05-19 06:11:17 --> URI Class Initialized
INFO - 2018-05-19 06:11:17 --> Router Class Initialized
INFO - 2018-05-19 06:11:17 --> Output Class Initialized
INFO - 2018-05-19 06:11:17 --> Security Class Initialized
DEBUG - 2018-05-19 06:11:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:11:17 --> Input Class Initialized
INFO - 2018-05-19 06:11:17 --> Language Class Initialized
ERROR - 2018-05-19 06:11:17 --> 404 Page Not Found: /index
INFO - 2018-05-19 06:11:17 --> Config Class Initialized
INFO - 2018-05-19 06:11:17 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:11:17 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:11:17 --> Utf8 Class Initialized
INFO - 2018-05-19 06:11:17 --> URI Class Initialized
INFO - 2018-05-19 06:11:17 --> Router Class Initialized
INFO - 2018-05-19 06:11:17 --> Output Class Initialized
INFO - 2018-05-19 06:11:17 --> Security Class Initialized
DEBUG - 2018-05-19 06:11:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:11:17 --> Input Class Initialized
INFO - 2018-05-19 06:11:17 --> Language Class Initialized
ERROR - 2018-05-19 06:11:17 --> 404 Page Not Found: /index
INFO - 2018-05-19 06:11:41 --> Config Class Initialized
INFO - 2018-05-19 06:11:41 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:11:41 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:11:41 --> Utf8 Class Initialized
INFO - 2018-05-19 06:11:41 --> URI Class Initialized
INFO - 2018-05-19 06:11:41 --> Router Class Initialized
INFO - 2018-05-19 06:11:41 --> Output Class Initialized
INFO - 2018-05-19 06:11:41 --> Security Class Initialized
DEBUG - 2018-05-19 06:11:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:11:41 --> Input Class Initialized
INFO - 2018-05-19 06:11:41 --> Language Class Initialized
INFO - 2018-05-19 06:11:41 --> Language Class Initialized
INFO - 2018-05-19 06:11:41 --> Config Class Initialized
INFO - 2018-05-19 06:11:41 --> Loader Class Initialized
DEBUG - 2018-05-19 06:11:41 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-19 06:11:41 --> Helper loaded: url_helper
INFO - 2018-05-19 06:11:41 --> Helper loaded: form_helper
INFO - 2018-05-19 06:11:41 --> Helper loaded: date_helper
INFO - 2018-05-19 06:11:41 --> Helper loaded: util_helper
INFO - 2018-05-19 06:11:41 --> Helper loaded: text_helper
INFO - 2018-05-19 06:11:41 --> Helper loaded: string_helper
INFO - 2018-05-19 06:11:41 --> Database Driver Class Initialized
DEBUG - 2018-05-19 06:11:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-19 06:11:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-19 06:11:41 --> Email Class Initialized
INFO - 2018-05-19 06:11:41 --> Controller Class Initialized
DEBUG - 2018-05-19 06:11:41 --> Profile MX_Controller Initialized
DEBUG - 2018-05-19 06:11:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-19 06:11:41 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-19 06:11:41 --> Login MX_Controller Initialized
INFO - 2018-05-19 06:11:41 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-19 06:11:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-19 06:11:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-19 06:11:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-19 06:11:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-19 06:11:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-19 06:11:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/profile_left_nav.php
DEBUG - 2018-05-19 06:11:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-19 06:11:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-19 06:11:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/addresses.php
INFO - 2018-05-19 06:11:41 --> Final output sent to browser
DEBUG - 2018-05-19 06:11:41 --> Total execution time: 0.6039
INFO - 2018-05-19 06:11:42 --> Config Class Initialized
INFO - 2018-05-19 06:11:42 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:11:42 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:11:42 --> Utf8 Class Initialized
INFO - 2018-05-19 06:11:42 --> URI Class Initialized
INFO - 2018-05-19 06:11:42 --> Router Class Initialized
INFO - 2018-05-19 06:11:42 --> Output Class Initialized
INFO - 2018-05-19 06:11:42 --> Security Class Initialized
DEBUG - 2018-05-19 06:11:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:11:42 --> Input Class Initialized
INFO - 2018-05-19 06:11:42 --> Language Class Initialized
ERROR - 2018-05-19 06:11:42 --> 404 Page Not Found: /index
INFO - 2018-05-19 06:11:42 --> Config Class Initialized
INFO - 2018-05-19 06:11:42 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:11:42 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:11:42 --> Utf8 Class Initialized
INFO - 2018-05-19 06:11:42 --> URI Class Initialized
INFO - 2018-05-19 06:11:43 --> Router Class Initialized
INFO - 2018-05-19 06:11:43 --> Output Class Initialized
INFO - 2018-05-19 06:11:43 --> Security Class Initialized
DEBUG - 2018-05-19 06:11:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:11:43 --> Input Class Initialized
INFO - 2018-05-19 06:11:43 --> Language Class Initialized
ERROR - 2018-05-19 06:11:43 --> 404 Page Not Found: /index
INFO - 2018-05-19 06:11:43 --> Config Class Initialized
INFO - 2018-05-19 06:11:43 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:11:43 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:11:43 --> Utf8 Class Initialized
INFO - 2018-05-19 06:11:43 --> URI Class Initialized
INFO - 2018-05-19 06:11:43 --> Router Class Initialized
INFO - 2018-05-19 06:11:43 --> Output Class Initialized
INFO - 2018-05-19 06:11:43 --> Security Class Initialized
DEBUG - 2018-05-19 06:11:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:11:43 --> Input Class Initialized
INFO - 2018-05-19 06:11:43 --> Language Class Initialized
ERROR - 2018-05-19 06:11:43 --> 404 Page Not Found: /index
INFO - 2018-05-19 06:12:07 --> Config Class Initialized
INFO - 2018-05-19 06:12:07 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:12:07 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:12:07 --> Utf8 Class Initialized
INFO - 2018-05-19 06:12:07 --> URI Class Initialized
INFO - 2018-05-19 06:12:07 --> Router Class Initialized
INFO - 2018-05-19 06:12:07 --> Output Class Initialized
INFO - 2018-05-19 06:12:07 --> Security Class Initialized
DEBUG - 2018-05-19 06:12:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:12:07 --> Input Class Initialized
INFO - 2018-05-19 06:12:07 --> Language Class Initialized
INFO - 2018-05-19 06:12:07 --> Language Class Initialized
INFO - 2018-05-19 06:12:07 --> Config Class Initialized
INFO - 2018-05-19 06:12:07 --> Loader Class Initialized
DEBUG - 2018-05-19 06:12:07 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-19 06:12:07 --> Helper loaded: url_helper
INFO - 2018-05-19 06:12:07 --> Helper loaded: form_helper
INFO - 2018-05-19 06:12:07 --> Helper loaded: date_helper
INFO - 2018-05-19 06:12:07 --> Helper loaded: util_helper
INFO - 2018-05-19 06:12:07 --> Helper loaded: text_helper
INFO - 2018-05-19 06:12:07 --> Helper loaded: string_helper
INFO - 2018-05-19 06:12:07 --> Database Driver Class Initialized
DEBUG - 2018-05-19 06:12:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-19 06:12:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-19 06:12:08 --> Email Class Initialized
INFO - 2018-05-19 06:12:08 --> Controller Class Initialized
DEBUG - 2018-05-19 06:12:08 --> Profile MX_Controller Initialized
DEBUG - 2018-05-19 06:12:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-19 06:12:08 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-19 06:12:08 --> Login MX_Controller Initialized
INFO - 2018-05-19 06:12:08 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-19 06:12:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-19 06:12:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-19 06:12:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-19 06:12:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-19 06:12:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-19 06:12:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/profile_left_nav.php
DEBUG - 2018-05-19 06:12:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-19 06:12:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-19 06:12:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/billing.php
INFO - 2018-05-19 06:12:08 --> Final output sent to browser
DEBUG - 2018-05-19 06:12:08 --> Total execution time: 0.7115
INFO - 2018-05-19 06:12:08 --> Config Class Initialized
INFO - 2018-05-19 06:12:08 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:12:08 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:12:08 --> Utf8 Class Initialized
INFO - 2018-05-19 06:12:09 --> URI Class Initialized
INFO - 2018-05-19 06:12:09 --> Router Class Initialized
INFO - 2018-05-19 06:12:09 --> Output Class Initialized
INFO - 2018-05-19 06:12:09 --> Security Class Initialized
DEBUG - 2018-05-19 06:12:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:12:09 --> Input Class Initialized
INFO - 2018-05-19 06:12:09 --> Language Class Initialized
ERROR - 2018-05-19 06:12:09 --> 404 Page Not Found: /index
INFO - 2018-05-19 06:12:09 --> Config Class Initialized
INFO - 2018-05-19 06:12:09 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:12:09 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:12:09 --> Utf8 Class Initialized
INFO - 2018-05-19 06:12:09 --> URI Class Initialized
INFO - 2018-05-19 06:12:09 --> Router Class Initialized
INFO - 2018-05-19 06:12:09 --> Output Class Initialized
INFO - 2018-05-19 06:12:09 --> Security Class Initialized
DEBUG - 2018-05-19 06:12:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:12:09 --> Input Class Initialized
INFO - 2018-05-19 06:12:09 --> Language Class Initialized
ERROR - 2018-05-19 06:12:09 --> 404 Page Not Found: /index
INFO - 2018-05-19 06:12:09 --> Config Class Initialized
INFO - 2018-05-19 06:12:09 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:12:09 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:12:09 --> Utf8 Class Initialized
INFO - 2018-05-19 06:12:09 --> URI Class Initialized
INFO - 2018-05-19 06:12:09 --> Router Class Initialized
INFO - 2018-05-19 06:12:09 --> Output Class Initialized
INFO - 2018-05-19 06:12:09 --> Security Class Initialized
DEBUG - 2018-05-19 06:12:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:12:10 --> Input Class Initialized
INFO - 2018-05-19 06:12:10 --> Language Class Initialized
ERROR - 2018-05-19 06:12:10 --> 404 Page Not Found: /index
INFO - 2018-05-19 06:12:49 --> Config Class Initialized
INFO - 2018-05-19 06:12:49 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:12:49 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:12:49 --> Utf8 Class Initialized
INFO - 2018-05-19 06:12:49 --> URI Class Initialized
INFO - 2018-05-19 06:12:49 --> Router Class Initialized
INFO - 2018-05-19 06:12:49 --> Output Class Initialized
INFO - 2018-05-19 06:12:49 --> Security Class Initialized
DEBUG - 2018-05-19 06:12:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:12:49 --> Input Class Initialized
INFO - 2018-05-19 06:12:49 --> Language Class Initialized
INFO - 2018-05-19 06:12:49 --> Language Class Initialized
INFO - 2018-05-19 06:12:49 --> Config Class Initialized
INFO - 2018-05-19 06:12:49 --> Loader Class Initialized
DEBUG - 2018-05-19 06:12:49 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-19 06:12:49 --> Helper loaded: url_helper
INFO - 2018-05-19 06:12:49 --> Helper loaded: form_helper
INFO - 2018-05-19 06:12:49 --> Helper loaded: date_helper
INFO - 2018-05-19 06:12:49 --> Helper loaded: util_helper
INFO - 2018-05-19 06:12:49 --> Helper loaded: text_helper
INFO - 2018-05-19 06:12:49 --> Helper loaded: string_helper
INFO - 2018-05-19 06:12:49 --> Database Driver Class Initialized
DEBUG - 2018-05-19 06:12:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-19 06:12:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-19 06:12:49 --> Email Class Initialized
INFO - 2018-05-19 06:12:49 --> Controller Class Initialized
DEBUG - 2018-05-19 06:12:49 --> Profile MX_Controller Initialized
DEBUG - 2018-05-19 06:12:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-19 06:12:50 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-19 06:12:50 --> Login MX_Controller Initialized
INFO - 2018-05-19 06:12:50 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-19 06:12:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-19 06:12:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-19 06:12:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-19 06:12:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-19 06:12:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-19 06:12:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/profile_left_nav.php
DEBUG - 2018-05-19 06:12:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-19 06:12:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-19 06:12:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/email_preferences.php
INFO - 2018-05-19 06:12:50 --> Final output sent to browser
DEBUG - 2018-05-19 06:12:50 --> Total execution time: 0.6375
INFO - 2018-05-19 06:12:50 --> Config Class Initialized
INFO - 2018-05-19 06:12:50 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:12:50 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:12:50 --> Utf8 Class Initialized
INFO - 2018-05-19 06:12:50 --> URI Class Initialized
INFO - 2018-05-19 06:12:50 --> Router Class Initialized
INFO - 2018-05-19 06:12:50 --> Output Class Initialized
INFO - 2018-05-19 06:12:50 --> Security Class Initialized
DEBUG - 2018-05-19 06:12:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:12:50 --> Input Class Initialized
INFO - 2018-05-19 06:12:50 --> Language Class Initialized
ERROR - 2018-05-19 06:12:50 --> 404 Page Not Found: /index
INFO - 2018-05-19 06:12:50 --> Config Class Initialized
INFO - 2018-05-19 06:12:50 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:12:50 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:12:50 --> Utf8 Class Initialized
INFO - 2018-05-19 06:12:50 --> URI Class Initialized
INFO - 2018-05-19 06:12:50 --> Router Class Initialized
INFO - 2018-05-19 06:12:50 --> Output Class Initialized
INFO - 2018-05-19 06:12:50 --> Security Class Initialized
DEBUG - 2018-05-19 06:12:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:12:50 --> Input Class Initialized
INFO - 2018-05-19 06:12:50 --> Language Class Initialized
ERROR - 2018-05-19 06:12:50 --> 404 Page Not Found: /index
INFO - 2018-05-19 06:12:51 --> Config Class Initialized
INFO - 2018-05-19 06:12:51 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:12:51 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:12:51 --> Utf8 Class Initialized
INFO - 2018-05-19 06:12:51 --> URI Class Initialized
INFO - 2018-05-19 06:12:51 --> Router Class Initialized
INFO - 2018-05-19 06:12:51 --> Output Class Initialized
INFO - 2018-05-19 06:12:51 --> Security Class Initialized
DEBUG - 2018-05-19 06:12:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:12:51 --> Input Class Initialized
INFO - 2018-05-19 06:12:51 --> Language Class Initialized
ERROR - 2018-05-19 06:12:51 --> 404 Page Not Found: /index
INFO - 2018-05-19 06:16:16 --> Config Class Initialized
INFO - 2018-05-19 06:16:16 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:16:16 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:16:16 --> Utf8 Class Initialized
INFO - 2018-05-19 06:16:16 --> URI Class Initialized
INFO - 2018-05-19 06:16:16 --> Router Class Initialized
INFO - 2018-05-19 06:16:16 --> Output Class Initialized
INFO - 2018-05-19 06:16:16 --> Security Class Initialized
DEBUG - 2018-05-19 06:16:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:16:16 --> Input Class Initialized
INFO - 2018-05-19 06:16:16 --> Language Class Initialized
INFO - 2018-05-19 06:16:16 --> Language Class Initialized
INFO - 2018-05-19 06:16:16 --> Config Class Initialized
INFO - 2018-05-19 06:16:16 --> Loader Class Initialized
DEBUG - 2018-05-19 06:16:16 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-19 06:16:16 --> Helper loaded: url_helper
INFO - 2018-05-19 06:16:16 --> Helper loaded: form_helper
INFO - 2018-05-19 06:16:16 --> Helper loaded: date_helper
INFO - 2018-05-19 06:16:16 --> Helper loaded: util_helper
INFO - 2018-05-19 06:16:16 --> Helper loaded: text_helper
INFO - 2018-05-19 06:16:16 --> Helper loaded: string_helper
INFO - 2018-05-19 06:16:16 --> Database Driver Class Initialized
DEBUG - 2018-05-19 06:16:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-19 06:16:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-19 06:16:16 --> Email Class Initialized
INFO - 2018-05-19 06:16:16 --> Controller Class Initialized
DEBUG - 2018-05-19 06:16:16 --> Profile MX_Controller Initialized
DEBUG - 2018-05-19 06:16:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-19 06:16:16 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-19 06:16:16 --> Login MX_Controller Initialized
INFO - 2018-05-19 06:16:16 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-19 06:16:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-19 06:16:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-19 06:16:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-19 06:16:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-19 06:16:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
ERROR - 2018-05-19 06:16:16 --> Severity: Notice --> Undefined variable: data E:\xampp\htdocs\consulting\application\modules\home\views\common\profile_left_nav.php 1
ERROR - 2018-05-19 06:16:16 --> Severity: Notice --> Undefined variable: data E:\xampp\htdocs\consulting\application\modules\home\views\common\profile_left_nav.php 2
ERROR - 2018-05-19 06:16:16 --> Severity: Notice --> Undefined variable: data E:\xampp\htdocs\consulting\application\modules\home\views\common\profile_left_nav.php 3
ERROR - 2018-05-19 06:16:16 --> Severity: Notice --> Undefined variable: data E:\xampp\htdocs\consulting\application\modules\home\views\common\profile_left_nav.php 4
ERROR - 2018-05-19 06:16:16 --> Severity: Notice --> Undefined variable: data E:\xampp\htdocs\consulting\application\modules\home\views\common\profile_left_nav.php 5
DEBUG - 2018-05-19 06:16:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/profile_left_nav.php
DEBUG - 2018-05-19 06:16:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-19 06:16:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-19 06:16:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/reset_password.php
INFO - 2018-05-19 06:16:16 --> Final output sent to browser
DEBUG - 2018-05-19 06:16:17 --> Total execution time: 0.7108
INFO - 2018-05-19 06:16:17 --> Config Class Initialized
INFO - 2018-05-19 06:16:17 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:16:17 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:16:17 --> Utf8 Class Initialized
INFO - 2018-05-19 06:16:17 --> URI Class Initialized
INFO - 2018-05-19 06:16:17 --> Router Class Initialized
INFO - 2018-05-19 06:16:17 --> Output Class Initialized
INFO - 2018-05-19 06:16:17 --> Security Class Initialized
DEBUG - 2018-05-19 06:16:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:16:17 --> Input Class Initialized
INFO - 2018-05-19 06:16:17 --> Language Class Initialized
ERROR - 2018-05-19 06:16:17 --> 404 Page Not Found: /index
INFO - 2018-05-19 06:16:17 --> Config Class Initialized
INFO - 2018-05-19 06:16:17 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:16:17 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:16:17 --> Utf8 Class Initialized
INFO - 2018-05-19 06:16:17 --> URI Class Initialized
INFO - 2018-05-19 06:16:17 --> Router Class Initialized
INFO - 2018-05-19 06:16:17 --> Output Class Initialized
INFO - 2018-05-19 06:16:17 --> Security Class Initialized
DEBUG - 2018-05-19 06:16:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:16:17 --> Input Class Initialized
INFO - 2018-05-19 06:16:17 --> Language Class Initialized
ERROR - 2018-05-19 06:16:17 --> 404 Page Not Found: /index
INFO - 2018-05-19 06:16:17 --> Config Class Initialized
INFO - 2018-05-19 06:16:17 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:16:17 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:16:17 --> Utf8 Class Initialized
INFO - 2018-05-19 06:16:17 --> URI Class Initialized
INFO - 2018-05-19 06:16:18 --> Router Class Initialized
INFO - 2018-05-19 06:16:18 --> Output Class Initialized
INFO - 2018-05-19 06:16:18 --> Security Class Initialized
DEBUG - 2018-05-19 06:16:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:16:18 --> Input Class Initialized
INFO - 2018-05-19 06:16:18 --> Language Class Initialized
ERROR - 2018-05-19 06:16:18 --> 404 Page Not Found: /index
INFO - 2018-05-19 06:17:39 --> Config Class Initialized
INFO - 2018-05-19 06:17:39 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:17:39 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:17:39 --> Utf8 Class Initialized
INFO - 2018-05-19 06:17:39 --> URI Class Initialized
INFO - 2018-05-19 06:17:39 --> Router Class Initialized
INFO - 2018-05-19 06:17:39 --> Output Class Initialized
INFO - 2018-05-19 06:17:39 --> Security Class Initialized
DEBUG - 2018-05-19 06:17:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:17:39 --> Input Class Initialized
INFO - 2018-05-19 06:17:39 --> Language Class Initialized
INFO - 2018-05-19 06:17:39 --> Language Class Initialized
INFO - 2018-05-19 06:17:39 --> Config Class Initialized
INFO - 2018-05-19 06:17:39 --> Loader Class Initialized
DEBUG - 2018-05-19 06:17:39 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-19 06:17:39 --> Helper loaded: url_helper
INFO - 2018-05-19 06:17:39 --> Helper loaded: form_helper
INFO - 2018-05-19 06:17:39 --> Helper loaded: date_helper
INFO - 2018-05-19 06:17:39 --> Helper loaded: util_helper
INFO - 2018-05-19 06:17:39 --> Helper loaded: text_helper
INFO - 2018-05-19 06:17:39 --> Helper loaded: string_helper
INFO - 2018-05-19 06:17:39 --> Database Driver Class Initialized
DEBUG - 2018-05-19 06:17:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-19 06:17:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-19 06:17:39 --> Email Class Initialized
INFO - 2018-05-19 06:17:39 --> Controller Class Initialized
DEBUG - 2018-05-19 06:17:39 --> Profile MX_Controller Initialized
DEBUG - 2018-05-19 06:17:39 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-19 06:17:39 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-19 06:17:40 --> Login MX_Controller Initialized
INFO - 2018-05-19 06:17:40 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-19 06:17:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-19 06:17:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-19 06:17:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-19 06:17:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-19 06:17:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-19 06:17:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/profile_left_nav.php
DEBUG - 2018-05-19 06:17:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-19 06:17:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-19 06:17:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/reset_password.php
INFO - 2018-05-19 06:17:40 --> Final output sent to browser
DEBUG - 2018-05-19 06:17:40 --> Total execution time: 0.6344
INFO - 2018-05-19 06:17:40 --> Config Class Initialized
INFO - 2018-05-19 06:17:40 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:17:40 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:17:40 --> Utf8 Class Initialized
INFO - 2018-05-19 06:17:40 --> URI Class Initialized
INFO - 2018-05-19 06:17:40 --> Router Class Initialized
INFO - 2018-05-19 06:17:40 --> Output Class Initialized
INFO - 2018-05-19 06:17:40 --> Security Class Initialized
DEBUG - 2018-05-19 06:17:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:17:40 --> Input Class Initialized
INFO - 2018-05-19 06:17:40 --> Language Class Initialized
ERROR - 2018-05-19 06:17:40 --> 404 Page Not Found: /index
INFO - 2018-05-19 06:17:41 --> Config Class Initialized
INFO - 2018-05-19 06:17:41 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:17:41 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:17:41 --> Utf8 Class Initialized
INFO - 2018-05-19 06:17:41 --> URI Class Initialized
INFO - 2018-05-19 06:17:41 --> Router Class Initialized
INFO - 2018-05-19 06:17:41 --> Output Class Initialized
INFO - 2018-05-19 06:17:41 --> Security Class Initialized
DEBUG - 2018-05-19 06:17:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:17:41 --> Input Class Initialized
INFO - 2018-05-19 06:17:41 --> Language Class Initialized
ERROR - 2018-05-19 06:17:41 --> 404 Page Not Found: /index
INFO - 2018-05-19 06:17:41 --> Config Class Initialized
INFO - 2018-05-19 06:17:41 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:17:41 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:17:41 --> Utf8 Class Initialized
INFO - 2018-05-19 06:17:41 --> URI Class Initialized
INFO - 2018-05-19 06:17:41 --> Router Class Initialized
INFO - 2018-05-19 06:17:41 --> Output Class Initialized
INFO - 2018-05-19 06:17:41 --> Security Class Initialized
DEBUG - 2018-05-19 06:17:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:17:41 --> Input Class Initialized
INFO - 2018-05-19 06:17:41 --> Language Class Initialized
ERROR - 2018-05-19 06:17:41 --> 404 Page Not Found: /index
INFO - 2018-05-19 06:17:42 --> Config Class Initialized
INFO - 2018-05-19 06:17:42 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:17:42 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:17:42 --> Utf8 Class Initialized
INFO - 2018-05-19 06:17:42 --> URI Class Initialized
INFO - 2018-05-19 06:17:42 --> Router Class Initialized
INFO - 2018-05-19 06:17:42 --> Output Class Initialized
INFO - 2018-05-19 06:17:42 --> Security Class Initialized
DEBUG - 2018-05-19 06:17:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:17:42 --> Input Class Initialized
INFO - 2018-05-19 06:17:42 --> Language Class Initialized
ERROR - 2018-05-19 06:17:42 --> 404 Page Not Found: /index
INFO - 2018-05-19 06:17:42 --> Config Class Initialized
INFO - 2018-05-19 06:17:42 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:17:42 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:17:42 --> Utf8 Class Initialized
INFO - 2018-05-19 06:17:42 --> URI Class Initialized
INFO - 2018-05-19 06:17:42 --> Router Class Initialized
INFO - 2018-05-19 06:17:42 --> Output Class Initialized
INFO - 2018-05-19 06:17:42 --> Security Class Initialized
DEBUG - 2018-05-19 06:17:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:17:42 --> Input Class Initialized
INFO - 2018-05-19 06:17:42 --> Language Class Initialized
ERROR - 2018-05-19 06:17:42 --> 404 Page Not Found: /index
INFO - 2018-05-19 06:17:42 --> Config Class Initialized
INFO - 2018-05-19 06:17:42 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:17:42 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:17:42 --> Utf8 Class Initialized
INFO - 2018-05-19 06:17:42 --> URI Class Initialized
INFO - 2018-05-19 06:17:42 --> Router Class Initialized
INFO - 2018-05-19 06:17:42 --> Output Class Initialized
INFO - 2018-05-19 06:17:42 --> Security Class Initialized
DEBUG - 2018-05-19 06:17:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:17:42 --> Input Class Initialized
INFO - 2018-05-19 06:17:42 --> Language Class Initialized
ERROR - 2018-05-19 06:17:42 --> 404 Page Not Found: /index
INFO - 2018-05-19 06:17:43 --> Config Class Initialized
INFO - 2018-05-19 06:17:43 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:17:43 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:17:43 --> Utf8 Class Initialized
INFO - 2018-05-19 06:17:43 --> URI Class Initialized
INFO - 2018-05-19 06:17:43 --> Router Class Initialized
INFO - 2018-05-19 06:17:43 --> Output Class Initialized
INFO - 2018-05-19 06:17:43 --> Security Class Initialized
DEBUG - 2018-05-19 06:17:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:17:43 --> Input Class Initialized
INFO - 2018-05-19 06:17:43 --> Language Class Initialized
INFO - 2018-05-19 06:17:43 --> Language Class Initialized
INFO - 2018-05-19 06:17:43 --> Config Class Initialized
INFO - 2018-05-19 06:17:43 --> Loader Class Initialized
DEBUG - 2018-05-19 06:17:43 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-19 06:17:43 --> Helper loaded: url_helper
INFO - 2018-05-19 06:17:43 --> Helper loaded: form_helper
INFO - 2018-05-19 06:17:43 --> Helper loaded: date_helper
INFO - 2018-05-19 06:17:43 --> Helper loaded: util_helper
INFO - 2018-05-19 06:17:43 --> Helper loaded: text_helper
INFO - 2018-05-19 06:17:43 --> Helper loaded: string_helper
INFO - 2018-05-19 06:17:43 --> Database Driver Class Initialized
DEBUG - 2018-05-19 06:17:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-19 06:17:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-19 06:17:43 --> Email Class Initialized
INFO - 2018-05-19 06:17:43 --> Controller Class Initialized
DEBUG - 2018-05-19 06:17:43 --> Profile MX_Controller Initialized
DEBUG - 2018-05-19 06:17:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-19 06:17:43 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-19 06:17:43 --> Login MX_Controller Initialized
INFO - 2018-05-19 06:17:43 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-19 06:17:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-19 06:17:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-19 06:17:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-19 06:17:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-19 06:17:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-19 06:17:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/profile_left_nav.php
DEBUG - 2018-05-19 06:17:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-19 06:17:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-19 06:17:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/profile.php
INFO - 2018-05-19 06:17:43 --> Final output sent to browser
DEBUG - 2018-05-19 06:17:43 --> Total execution time: 0.6359
INFO - 2018-05-19 06:17:44 --> Config Class Initialized
INFO - 2018-05-19 06:17:44 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:17:44 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:17:44 --> Utf8 Class Initialized
INFO - 2018-05-19 06:17:44 --> Config Class Initialized
INFO - 2018-05-19 06:17:44 --> Hooks Class Initialized
INFO - 2018-05-19 06:17:44 --> URI Class Initialized
DEBUG - 2018-05-19 06:17:44 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:17:44 --> Router Class Initialized
INFO - 2018-05-19 06:17:44 --> Utf8 Class Initialized
INFO - 2018-05-19 06:17:44 --> URI Class Initialized
INFO - 2018-05-19 06:17:44 --> Router Class Initialized
INFO - 2018-05-19 06:17:44 --> Output Class Initialized
INFO - 2018-05-19 06:17:44 --> Security Class Initialized
DEBUG - 2018-05-19 06:17:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:17:44 --> Input Class Initialized
INFO - 2018-05-19 06:17:44 --> Language Class Initialized
ERROR - 2018-05-19 06:17:44 --> 404 Page Not Found: /index
INFO - 2018-05-19 06:17:44 --> Output Class Initialized
INFO - 2018-05-19 06:17:44 --> Security Class Initialized
DEBUG - 2018-05-19 06:17:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:17:44 --> Input Class Initialized
INFO - 2018-05-19 06:17:44 --> Language Class Initialized
ERROR - 2018-05-19 06:17:44 --> 404 Page Not Found: /index
INFO - 2018-05-19 06:17:44 --> Config Class Initialized
INFO - 2018-05-19 06:17:44 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:17:44 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:17:45 --> Utf8 Class Initialized
INFO - 2018-05-19 06:17:45 --> URI Class Initialized
INFO - 2018-05-19 06:17:45 --> Router Class Initialized
INFO - 2018-05-19 06:17:45 --> Output Class Initialized
INFO - 2018-05-19 06:17:45 --> Security Class Initialized
DEBUG - 2018-05-19 06:17:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:17:45 --> Input Class Initialized
INFO - 2018-05-19 06:17:45 --> Language Class Initialized
ERROR - 2018-05-19 06:17:45 --> 404 Page Not Found: /index
INFO - 2018-05-19 06:17:45 --> Config Class Initialized
INFO - 2018-05-19 06:17:45 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:17:45 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:17:45 --> Utf8 Class Initialized
INFO - 2018-05-19 06:17:45 --> URI Class Initialized
INFO - 2018-05-19 06:17:45 --> Router Class Initialized
INFO - 2018-05-19 06:17:45 --> Output Class Initialized
INFO - 2018-05-19 06:17:45 --> Security Class Initialized
DEBUG - 2018-05-19 06:17:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:17:45 --> Input Class Initialized
INFO - 2018-05-19 06:17:45 --> Language Class Initialized
ERROR - 2018-05-19 06:17:45 --> 404 Page Not Found: /index
INFO - 2018-05-19 06:17:45 --> Config Class Initialized
INFO - 2018-05-19 06:17:45 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:17:45 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:17:45 --> Utf8 Class Initialized
INFO - 2018-05-19 06:17:45 --> URI Class Initialized
INFO - 2018-05-19 06:17:45 --> Router Class Initialized
INFO - 2018-05-19 06:17:45 --> Output Class Initialized
INFO - 2018-05-19 06:17:45 --> Security Class Initialized
DEBUG - 2018-05-19 06:17:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:17:45 --> Input Class Initialized
INFO - 2018-05-19 06:17:45 --> Language Class Initialized
INFO - 2018-05-19 06:17:45 --> Language Class Initialized
INFO - 2018-05-19 06:17:45 --> Config Class Initialized
INFO - 2018-05-19 06:17:45 --> Loader Class Initialized
DEBUG - 2018-05-19 06:17:45 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-19 06:17:45 --> Helper loaded: url_helper
INFO - 2018-05-19 06:17:45 --> Helper loaded: form_helper
INFO - 2018-05-19 06:17:45 --> Helper loaded: date_helper
INFO - 2018-05-19 06:17:45 --> Helper loaded: util_helper
INFO - 2018-05-19 06:17:45 --> Helper loaded: text_helper
INFO - 2018-05-19 06:17:45 --> Helper loaded: string_helper
INFO - 2018-05-19 06:17:45 --> Database Driver Class Initialized
DEBUG - 2018-05-19 06:17:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-19 06:17:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-19 06:17:45 --> Email Class Initialized
INFO - 2018-05-19 06:17:45 --> Controller Class Initialized
DEBUG - 2018-05-19 06:17:45 --> Profile MX_Controller Initialized
DEBUG - 2018-05-19 06:17:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-19 06:17:45 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-19 06:17:45 --> Login MX_Controller Initialized
INFO - 2018-05-19 06:17:46 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-19 06:17:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-19 06:17:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-19 06:17:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-19 06:17:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-19 06:17:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-19 06:17:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/profile_left_nav.php
DEBUG - 2018-05-19 06:17:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-19 06:17:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-19 06:17:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/addresses.php
INFO - 2018-05-19 06:17:46 --> Final output sent to browser
DEBUG - 2018-05-19 06:17:46 --> Total execution time: 0.6918
INFO - 2018-05-19 06:17:46 --> Config Class Initialized
INFO - 2018-05-19 06:17:46 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:17:46 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:17:46 --> Utf8 Class Initialized
INFO - 2018-05-19 06:17:46 --> URI Class Initialized
INFO - 2018-05-19 06:17:46 --> Router Class Initialized
INFO - 2018-05-19 06:17:46 --> Output Class Initialized
INFO - 2018-05-19 06:17:46 --> Security Class Initialized
DEBUG - 2018-05-19 06:17:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:17:46 --> Input Class Initialized
INFO - 2018-05-19 06:17:46 --> Language Class Initialized
ERROR - 2018-05-19 06:17:46 --> 404 Page Not Found: /index
INFO - 2018-05-19 06:17:46 --> Config Class Initialized
INFO - 2018-05-19 06:17:46 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:17:47 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:17:47 --> Utf8 Class Initialized
INFO - 2018-05-19 06:17:47 --> URI Class Initialized
INFO - 2018-05-19 06:17:47 --> Router Class Initialized
INFO - 2018-05-19 06:17:47 --> Output Class Initialized
INFO - 2018-05-19 06:17:47 --> Security Class Initialized
DEBUG - 2018-05-19 06:17:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:17:47 --> Input Class Initialized
INFO - 2018-05-19 06:17:47 --> Language Class Initialized
ERROR - 2018-05-19 06:17:47 --> 404 Page Not Found: /index
INFO - 2018-05-19 06:17:47 --> Config Class Initialized
INFO - 2018-05-19 06:17:47 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:17:47 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:17:47 --> Utf8 Class Initialized
INFO - 2018-05-19 06:17:47 --> URI Class Initialized
INFO - 2018-05-19 06:17:47 --> Router Class Initialized
INFO - 2018-05-19 06:17:47 --> Output Class Initialized
INFO - 2018-05-19 06:17:47 --> Security Class Initialized
DEBUG - 2018-05-19 06:17:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:17:47 --> Input Class Initialized
INFO - 2018-05-19 06:17:47 --> Language Class Initialized
ERROR - 2018-05-19 06:17:47 --> 404 Page Not Found: /index
INFO - 2018-05-19 06:17:47 --> Config Class Initialized
INFO - 2018-05-19 06:17:47 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:17:47 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:17:47 --> Utf8 Class Initialized
INFO - 2018-05-19 06:17:47 --> URI Class Initialized
INFO - 2018-05-19 06:17:47 --> Router Class Initialized
INFO - 2018-05-19 06:17:47 --> Output Class Initialized
INFO - 2018-05-19 06:17:47 --> Security Class Initialized
DEBUG - 2018-05-19 06:17:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:17:47 --> Input Class Initialized
INFO - 2018-05-19 06:17:47 --> Language Class Initialized
INFO - 2018-05-19 06:17:47 --> Language Class Initialized
INFO - 2018-05-19 06:17:47 --> Config Class Initialized
INFO - 2018-05-19 06:17:47 --> Loader Class Initialized
DEBUG - 2018-05-19 06:17:47 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-19 06:17:47 --> Helper loaded: url_helper
INFO - 2018-05-19 06:17:47 --> Helper loaded: form_helper
INFO - 2018-05-19 06:17:47 --> Helper loaded: date_helper
INFO - 2018-05-19 06:17:47 --> Helper loaded: util_helper
INFO - 2018-05-19 06:17:47 --> Helper loaded: text_helper
INFO - 2018-05-19 06:17:47 --> Helper loaded: string_helper
INFO - 2018-05-19 06:17:48 --> Database Driver Class Initialized
DEBUG - 2018-05-19 06:17:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-19 06:17:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-19 06:17:48 --> Email Class Initialized
INFO - 2018-05-19 06:17:48 --> Controller Class Initialized
DEBUG - 2018-05-19 06:17:48 --> Profile MX_Controller Initialized
DEBUG - 2018-05-19 06:17:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-19 06:17:48 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-19 06:17:48 --> Login MX_Controller Initialized
INFO - 2018-05-19 06:17:48 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-19 06:17:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-19 06:17:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-19 06:17:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-19 06:17:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-19 06:17:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-19 06:17:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/profile_left_nav.php
DEBUG - 2018-05-19 06:17:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-19 06:17:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-19 06:17:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/billing.php
INFO - 2018-05-19 06:17:48 --> Final output sent to browser
DEBUG - 2018-05-19 06:17:48 --> Total execution time: 0.7842
INFO - 2018-05-19 06:17:48 --> Config Class Initialized
INFO - 2018-05-19 06:17:48 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:17:48 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:17:48 --> Utf8 Class Initialized
INFO - 2018-05-19 06:17:48 --> URI Class Initialized
INFO - 2018-05-19 06:17:48 --> Router Class Initialized
INFO - 2018-05-19 06:17:48 --> Output Class Initialized
INFO - 2018-05-19 06:17:48 --> Security Class Initialized
DEBUG - 2018-05-19 06:17:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:17:48 --> Input Class Initialized
INFO - 2018-05-19 06:17:48 --> Language Class Initialized
ERROR - 2018-05-19 06:17:48 --> 404 Page Not Found: /index
INFO - 2018-05-19 06:17:49 --> Config Class Initialized
INFO - 2018-05-19 06:17:49 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:17:49 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:17:49 --> Utf8 Class Initialized
INFO - 2018-05-19 06:17:49 --> URI Class Initialized
INFO - 2018-05-19 06:17:49 --> Router Class Initialized
INFO - 2018-05-19 06:17:49 --> Output Class Initialized
INFO - 2018-05-19 06:17:49 --> Security Class Initialized
DEBUG - 2018-05-19 06:17:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:17:49 --> Input Class Initialized
INFO - 2018-05-19 06:17:49 --> Language Class Initialized
ERROR - 2018-05-19 06:17:49 --> 404 Page Not Found: /index
INFO - 2018-05-19 06:17:49 --> Config Class Initialized
INFO - 2018-05-19 06:17:49 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:17:49 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:17:49 --> Utf8 Class Initialized
INFO - 2018-05-19 06:17:49 --> URI Class Initialized
INFO - 2018-05-19 06:17:49 --> Router Class Initialized
INFO - 2018-05-19 06:17:49 --> Output Class Initialized
INFO - 2018-05-19 06:17:49 --> Security Class Initialized
DEBUG - 2018-05-19 06:17:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:17:49 --> Input Class Initialized
INFO - 2018-05-19 06:17:49 --> Language Class Initialized
ERROR - 2018-05-19 06:17:49 --> 404 Page Not Found: /index
INFO - 2018-05-19 06:17:49 --> Config Class Initialized
INFO - 2018-05-19 06:17:49 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:17:49 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:17:49 --> Utf8 Class Initialized
INFO - 2018-05-19 06:17:49 --> URI Class Initialized
INFO - 2018-05-19 06:17:49 --> Router Class Initialized
INFO - 2018-05-19 06:17:49 --> Output Class Initialized
INFO - 2018-05-19 06:17:49 --> Security Class Initialized
DEBUG - 2018-05-19 06:17:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:17:50 --> Input Class Initialized
INFO - 2018-05-19 06:17:50 --> Language Class Initialized
INFO - 2018-05-19 06:17:50 --> Language Class Initialized
INFO - 2018-05-19 06:17:50 --> Config Class Initialized
INFO - 2018-05-19 06:17:50 --> Loader Class Initialized
DEBUG - 2018-05-19 06:17:50 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-19 06:17:50 --> Helper loaded: url_helper
INFO - 2018-05-19 06:17:50 --> Helper loaded: form_helper
INFO - 2018-05-19 06:17:50 --> Helper loaded: date_helper
INFO - 2018-05-19 06:17:50 --> Helper loaded: util_helper
INFO - 2018-05-19 06:17:50 --> Helper loaded: text_helper
INFO - 2018-05-19 06:17:50 --> Helper loaded: string_helper
INFO - 2018-05-19 06:17:50 --> Database Driver Class Initialized
DEBUG - 2018-05-19 06:17:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-19 06:17:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-19 06:17:50 --> Email Class Initialized
INFO - 2018-05-19 06:17:50 --> Controller Class Initialized
DEBUG - 2018-05-19 06:17:50 --> Profile MX_Controller Initialized
DEBUG - 2018-05-19 06:17:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-19 06:17:50 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-19 06:17:50 --> Login MX_Controller Initialized
INFO - 2018-05-19 06:17:50 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-19 06:17:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-19 06:17:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-19 06:17:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-19 06:17:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-19 06:17:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-19 06:17:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/profile_left_nav.php
DEBUG - 2018-05-19 06:17:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-19 06:17:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-19 06:17:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/email_preferences.php
INFO - 2018-05-19 06:17:50 --> Final output sent to browser
DEBUG - 2018-05-19 06:17:50 --> Total execution time: 0.6470
INFO - 2018-05-19 06:17:50 --> Config Class Initialized
INFO - 2018-05-19 06:17:50 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:17:50 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:17:50 --> Utf8 Class Initialized
INFO - 2018-05-19 06:17:50 --> URI Class Initialized
INFO - 2018-05-19 06:17:50 --> Router Class Initialized
INFO - 2018-05-19 06:17:51 --> Output Class Initialized
INFO - 2018-05-19 06:17:51 --> Security Class Initialized
DEBUG - 2018-05-19 06:17:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:17:51 --> Input Class Initialized
INFO - 2018-05-19 06:17:51 --> Language Class Initialized
ERROR - 2018-05-19 06:17:51 --> 404 Page Not Found: /index
INFO - 2018-05-19 06:17:51 --> Config Class Initialized
INFO - 2018-05-19 06:17:51 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:17:51 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:17:51 --> Utf8 Class Initialized
INFO - 2018-05-19 06:17:51 --> URI Class Initialized
INFO - 2018-05-19 06:17:51 --> Router Class Initialized
INFO - 2018-05-19 06:17:51 --> Output Class Initialized
INFO - 2018-05-19 06:17:51 --> Security Class Initialized
DEBUG - 2018-05-19 06:17:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:17:51 --> Input Class Initialized
INFO - 2018-05-19 06:17:51 --> Language Class Initialized
ERROR - 2018-05-19 06:17:51 --> 404 Page Not Found: /index
INFO - 2018-05-19 06:17:51 --> Config Class Initialized
INFO - 2018-05-19 06:17:51 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:17:51 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:17:51 --> Utf8 Class Initialized
INFO - 2018-05-19 06:17:51 --> URI Class Initialized
INFO - 2018-05-19 06:17:51 --> Router Class Initialized
INFO - 2018-05-19 06:17:51 --> Output Class Initialized
INFO - 2018-05-19 06:17:51 --> Security Class Initialized
DEBUG - 2018-05-19 06:17:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:17:51 --> Input Class Initialized
INFO - 2018-05-19 06:17:51 --> Language Class Initialized
ERROR - 2018-05-19 06:17:51 --> 404 Page Not Found: /index
INFO - 2018-05-19 06:17:52 --> Config Class Initialized
INFO - 2018-05-19 06:17:52 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:17:52 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:17:52 --> Utf8 Class Initialized
INFO - 2018-05-19 06:17:52 --> URI Class Initialized
INFO - 2018-05-19 06:17:52 --> Router Class Initialized
INFO - 2018-05-19 06:17:52 --> Output Class Initialized
INFO - 2018-05-19 06:17:52 --> Security Class Initialized
DEBUG - 2018-05-19 06:17:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:17:52 --> Input Class Initialized
INFO - 2018-05-19 06:17:52 --> Language Class Initialized
INFO - 2018-05-19 06:17:52 --> Language Class Initialized
INFO - 2018-05-19 06:17:52 --> Config Class Initialized
INFO - 2018-05-19 06:17:52 --> Loader Class Initialized
DEBUG - 2018-05-19 06:17:52 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-19 06:17:52 --> Helper loaded: url_helper
INFO - 2018-05-19 06:17:52 --> Helper loaded: form_helper
INFO - 2018-05-19 06:17:52 --> Helper loaded: date_helper
INFO - 2018-05-19 06:17:52 --> Helper loaded: util_helper
INFO - 2018-05-19 06:17:52 --> Helper loaded: text_helper
INFO - 2018-05-19 06:17:52 --> Helper loaded: string_helper
INFO - 2018-05-19 06:17:52 --> Database Driver Class Initialized
DEBUG - 2018-05-19 06:17:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-19 06:17:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-19 06:17:52 --> Email Class Initialized
INFO - 2018-05-19 06:17:52 --> Controller Class Initialized
DEBUG - 2018-05-19 06:17:52 --> Profile MX_Controller Initialized
DEBUG - 2018-05-19 06:17:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-19 06:17:52 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-19 06:17:52 --> Login MX_Controller Initialized
INFO - 2018-05-19 06:17:52 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-19 06:17:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-19 06:17:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-19 06:17:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-19 06:17:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-19 06:17:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-19 06:17:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/profile_left_nav.php
DEBUG - 2018-05-19 06:17:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-19 06:17:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-19 06:17:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/profile.php
INFO - 2018-05-19 06:17:53 --> Final output sent to browser
DEBUG - 2018-05-19 06:17:53 --> Total execution time: 0.7180
INFO - 2018-05-19 06:17:53 --> Config Class Initialized
INFO - 2018-05-19 06:17:53 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:17:53 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:17:53 --> Config Class Initialized
INFO - 2018-05-19 06:17:53 --> Hooks Class Initialized
INFO - 2018-05-19 06:17:53 --> Utf8 Class Initialized
DEBUG - 2018-05-19 06:17:53 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:17:53 --> Utf8 Class Initialized
INFO - 2018-05-19 06:17:53 --> URI Class Initialized
INFO - 2018-05-19 06:17:53 --> URI Class Initialized
INFO - 2018-05-19 06:17:53 --> Router Class Initialized
INFO - 2018-05-19 06:17:53 --> Router Class Initialized
INFO - 2018-05-19 06:17:53 --> Output Class Initialized
INFO - 2018-05-19 06:17:53 --> Security Class Initialized
INFO - 2018-05-19 06:17:53 --> Output Class Initialized
DEBUG - 2018-05-19 06:17:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:17:53 --> Security Class Initialized
INFO - 2018-05-19 06:17:53 --> Input Class Initialized
INFO - 2018-05-19 06:17:53 --> Language Class Initialized
ERROR - 2018-05-19 06:17:53 --> 404 Page Not Found: /index
DEBUG - 2018-05-19 06:17:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:17:53 --> Config Class Initialized
INFO - 2018-05-19 06:17:53 --> Hooks Class Initialized
INFO - 2018-05-19 06:17:53 --> Input Class Initialized
DEBUG - 2018-05-19 06:17:54 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:17:54 --> Utf8 Class Initialized
INFO - 2018-05-19 06:17:54 --> URI Class Initialized
INFO - 2018-05-19 06:17:54 --> Language Class Initialized
INFO - 2018-05-19 06:17:54 --> Router Class Initialized
INFO - 2018-05-19 06:17:54 --> Output Class Initialized
ERROR - 2018-05-19 06:17:54 --> 404 Page Not Found: /index
INFO - 2018-05-19 06:17:54 --> Security Class Initialized
DEBUG - 2018-05-19 06:17:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:17:54 --> Input Class Initialized
INFO - 2018-05-19 06:17:54 --> Language Class Initialized
ERROR - 2018-05-19 06:17:54 --> 404 Page Not Found: /index
INFO - 2018-05-19 06:17:54 --> Config Class Initialized
INFO - 2018-05-19 06:17:54 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:17:54 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:17:54 --> Utf8 Class Initialized
INFO - 2018-05-19 06:17:54 --> URI Class Initialized
INFO - 2018-05-19 06:17:54 --> Router Class Initialized
INFO - 2018-05-19 06:17:54 --> Output Class Initialized
INFO - 2018-05-19 06:17:54 --> Security Class Initialized
DEBUG - 2018-05-19 06:17:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:17:54 --> Input Class Initialized
INFO - 2018-05-19 06:17:54 --> Language Class Initialized
ERROR - 2018-05-19 06:17:54 --> 404 Page Not Found: /index
INFO - 2018-05-19 06:19:33 --> Config Class Initialized
INFO - 2018-05-19 06:19:33 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:19:33 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:19:33 --> Utf8 Class Initialized
INFO - 2018-05-19 06:19:33 --> URI Class Initialized
INFO - 2018-05-19 06:19:33 --> Router Class Initialized
INFO - 2018-05-19 06:19:33 --> Output Class Initialized
INFO - 2018-05-19 06:19:33 --> Security Class Initialized
DEBUG - 2018-05-19 06:19:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:19:33 --> Input Class Initialized
INFO - 2018-05-19 06:19:33 --> Language Class Initialized
INFO - 2018-05-19 06:19:33 --> Language Class Initialized
INFO - 2018-05-19 06:19:33 --> Config Class Initialized
INFO - 2018-05-19 06:19:33 --> Loader Class Initialized
DEBUG - 2018-05-19 06:19:33 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-19 06:19:33 --> Helper loaded: url_helper
INFO - 2018-05-19 06:19:33 --> Helper loaded: form_helper
INFO - 2018-05-19 06:19:33 --> Helper loaded: date_helper
INFO - 2018-05-19 06:19:33 --> Helper loaded: util_helper
INFO - 2018-05-19 06:19:34 --> Helper loaded: text_helper
INFO - 2018-05-19 06:19:34 --> Helper loaded: string_helper
INFO - 2018-05-19 06:19:34 --> Database Driver Class Initialized
DEBUG - 2018-05-19 06:19:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-19 06:19:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-19 06:19:34 --> Email Class Initialized
INFO - 2018-05-19 06:19:34 --> Controller Class Initialized
DEBUG - 2018-05-19 06:19:34 --> Profile MX_Controller Initialized
DEBUG - 2018-05-19 06:19:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-19 06:19:34 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-19 06:19:34 --> Login MX_Controller Initialized
INFO - 2018-05-19 06:19:34 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-19 06:19:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-19 06:19:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-19 06:19:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-19 06:19:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-19 06:19:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-19 06:19:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/profile_left_nav.php
DEBUG - 2018-05-19 06:19:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-19 06:19:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-19 06:19:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/profile.php
INFO - 2018-05-19 06:19:34 --> Final output sent to browser
DEBUG - 2018-05-19 06:19:34 --> Total execution time: 0.6648
INFO - 2018-05-19 06:19:34 --> Config Class Initialized
INFO - 2018-05-19 06:19:34 --> Config Class Initialized
INFO - 2018-05-19 06:19:35 --> Hooks Class Initialized
INFO - 2018-05-19 06:19:35 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:19:35 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:19:35 --> Utf8 Class Initialized
DEBUG - 2018-05-19 06:19:35 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:19:35 --> Utf8 Class Initialized
INFO - 2018-05-19 06:19:35 --> URI Class Initialized
INFO - 2018-05-19 06:19:35 --> URI Class Initialized
INFO - 2018-05-19 06:19:35 --> Router Class Initialized
INFO - 2018-05-19 06:19:35 --> Router Class Initialized
INFO - 2018-05-19 06:19:35 --> Output Class Initialized
INFO - 2018-05-19 06:19:35 --> Security Class Initialized
DEBUG - 2018-05-19 06:19:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:19:35 --> Input Class Initialized
INFO - 2018-05-19 06:19:35 --> Language Class Initialized
INFO - 2018-05-19 06:19:35 --> Output Class Initialized
ERROR - 2018-05-19 06:19:35 --> 404 Page Not Found: /index
INFO - 2018-05-19 06:19:35 --> Security Class Initialized
INFO - 2018-05-19 06:19:35 --> Config Class Initialized
INFO - 2018-05-19 06:19:35 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:19:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-19 06:19:35 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:19:35 --> Input Class Initialized
INFO - 2018-05-19 06:19:35 --> Language Class Initialized
INFO - 2018-05-19 06:19:35 --> Utf8 Class Initialized
INFO - 2018-05-19 06:19:35 --> URI Class Initialized
ERROR - 2018-05-19 06:19:35 --> 404 Page Not Found: /index
INFO - 2018-05-19 06:19:35 --> Router Class Initialized
INFO - 2018-05-19 06:19:35 --> Output Class Initialized
INFO - 2018-05-19 06:19:35 --> Security Class Initialized
DEBUG - 2018-05-19 06:19:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:19:35 --> Input Class Initialized
INFO - 2018-05-19 06:19:35 --> Language Class Initialized
ERROR - 2018-05-19 06:19:35 --> 404 Page Not Found: /index
INFO - 2018-05-19 06:19:35 --> Config Class Initialized
INFO - 2018-05-19 06:19:35 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:19:35 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:19:35 --> Utf8 Class Initialized
INFO - 2018-05-19 06:19:35 --> URI Class Initialized
INFO - 2018-05-19 06:19:35 --> Router Class Initialized
INFO - 2018-05-19 06:19:35 --> Output Class Initialized
INFO - 2018-05-19 06:19:35 --> Security Class Initialized
DEBUG - 2018-05-19 06:19:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:19:36 --> Input Class Initialized
INFO - 2018-05-19 06:19:36 --> Language Class Initialized
ERROR - 2018-05-19 06:19:36 --> 404 Page Not Found: /index
INFO - 2018-05-19 06:25:22 --> Config Class Initialized
INFO - 2018-05-19 06:25:22 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:25:22 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:25:22 --> Utf8 Class Initialized
INFO - 2018-05-19 06:25:23 --> URI Class Initialized
INFO - 2018-05-19 06:25:23 --> Router Class Initialized
INFO - 2018-05-19 06:25:23 --> Output Class Initialized
INFO - 2018-05-19 06:25:23 --> Security Class Initialized
DEBUG - 2018-05-19 06:25:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:25:23 --> Input Class Initialized
INFO - 2018-05-19 06:25:23 --> Language Class Initialized
INFO - 2018-05-19 06:25:23 --> Language Class Initialized
INFO - 2018-05-19 06:25:23 --> Config Class Initialized
INFO - 2018-05-19 06:25:23 --> Loader Class Initialized
DEBUG - 2018-05-19 06:25:23 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-19 06:25:23 --> Helper loaded: url_helper
INFO - 2018-05-19 06:25:23 --> Helper loaded: form_helper
INFO - 2018-05-19 06:25:23 --> Helper loaded: date_helper
INFO - 2018-05-19 06:25:23 --> Helper loaded: util_helper
INFO - 2018-05-19 06:25:23 --> Helper loaded: text_helper
INFO - 2018-05-19 06:25:23 --> Helper loaded: string_helper
INFO - 2018-05-19 06:25:23 --> Database Driver Class Initialized
DEBUG - 2018-05-19 06:25:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-19 06:25:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-19 06:25:23 --> Email Class Initialized
INFO - 2018-05-19 06:25:23 --> Controller Class Initialized
DEBUG - 2018-05-19 06:25:23 --> Profile MX_Controller Initialized
DEBUG - 2018-05-19 06:25:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-19 06:25:23 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-19 06:25:23 --> Login MX_Controller Initialized
INFO - 2018-05-19 06:25:23 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-19 06:25:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-19 06:25:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-19 06:25:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-19 06:25:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-19 06:25:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-19 06:25:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/profile_left_nav.php
DEBUG - 2018-05-19 06:25:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-19 06:25:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-19 06:25:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/addresses.php
INFO - 2018-05-19 06:25:23 --> Final output sent to browser
DEBUG - 2018-05-19 06:25:23 --> Total execution time: 0.6864
INFO - 2018-05-19 06:25:24 --> Config Class Initialized
INFO - 2018-05-19 06:25:24 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:25:24 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:25:24 --> Utf8 Class Initialized
INFO - 2018-05-19 06:25:24 --> URI Class Initialized
INFO - 2018-05-19 06:25:24 --> Router Class Initialized
INFO - 2018-05-19 06:25:24 --> Output Class Initialized
INFO - 2018-05-19 06:25:24 --> Security Class Initialized
DEBUG - 2018-05-19 06:25:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:25:24 --> Input Class Initialized
INFO - 2018-05-19 06:25:24 --> Language Class Initialized
ERROR - 2018-05-19 06:25:24 --> 404 Page Not Found: /index
INFO - 2018-05-19 06:25:24 --> Config Class Initialized
INFO - 2018-05-19 06:25:24 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:25:24 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:25:24 --> Utf8 Class Initialized
INFO - 2018-05-19 06:25:24 --> URI Class Initialized
INFO - 2018-05-19 06:25:24 --> Router Class Initialized
INFO - 2018-05-19 06:25:24 --> Output Class Initialized
INFO - 2018-05-19 06:25:25 --> Security Class Initialized
DEBUG - 2018-05-19 06:25:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:25:25 --> Input Class Initialized
INFO - 2018-05-19 06:25:25 --> Language Class Initialized
ERROR - 2018-05-19 06:25:25 --> 404 Page Not Found: /index
INFO - 2018-05-19 06:25:25 --> Config Class Initialized
INFO - 2018-05-19 06:25:25 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:25:25 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:25:25 --> Utf8 Class Initialized
INFO - 2018-05-19 06:25:25 --> URI Class Initialized
INFO - 2018-05-19 06:25:25 --> Router Class Initialized
INFO - 2018-05-19 06:25:25 --> Output Class Initialized
INFO - 2018-05-19 06:25:25 --> Security Class Initialized
DEBUG - 2018-05-19 06:25:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:25:25 --> Input Class Initialized
INFO - 2018-05-19 06:25:25 --> Language Class Initialized
ERROR - 2018-05-19 06:25:25 --> 404 Page Not Found: /index
INFO - 2018-05-19 06:25:32 --> Config Class Initialized
INFO - 2018-05-19 06:25:32 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:25:32 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:25:33 --> Utf8 Class Initialized
INFO - 2018-05-19 06:25:33 --> URI Class Initialized
INFO - 2018-05-19 06:25:33 --> Router Class Initialized
INFO - 2018-05-19 06:25:33 --> Output Class Initialized
INFO - 2018-05-19 06:25:33 --> Security Class Initialized
DEBUG - 2018-05-19 06:25:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:25:33 --> Input Class Initialized
INFO - 2018-05-19 06:25:33 --> Language Class Initialized
INFO - 2018-05-19 06:25:33 --> Language Class Initialized
INFO - 2018-05-19 06:25:33 --> Config Class Initialized
INFO - 2018-05-19 06:25:33 --> Loader Class Initialized
DEBUG - 2018-05-19 06:25:33 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-19 06:25:33 --> Helper loaded: url_helper
INFO - 2018-05-19 06:25:33 --> Helper loaded: form_helper
INFO - 2018-05-19 06:25:33 --> Helper loaded: date_helper
INFO - 2018-05-19 06:25:33 --> Helper loaded: util_helper
INFO - 2018-05-19 06:25:33 --> Helper loaded: text_helper
INFO - 2018-05-19 06:25:33 --> Helper loaded: string_helper
INFO - 2018-05-19 06:25:33 --> Database Driver Class Initialized
DEBUG - 2018-05-19 06:25:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-19 06:25:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-19 06:25:33 --> Email Class Initialized
INFO - 2018-05-19 06:25:33 --> Controller Class Initialized
DEBUG - 2018-05-19 06:25:33 --> Profile MX_Controller Initialized
DEBUG - 2018-05-19 06:25:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-19 06:25:33 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-19 06:25:33 --> Login MX_Controller Initialized
INFO - 2018-05-19 06:25:33 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-19 06:25:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-19 06:25:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-19 06:25:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-19 06:25:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-19 06:25:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-19 06:25:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/profile_left_nav.php
DEBUG - 2018-05-19 06:25:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-19 06:25:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-19 06:25:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/reset_password.php
INFO - 2018-05-19 06:25:33 --> Final output sent to browser
DEBUG - 2018-05-19 06:25:33 --> Total execution time: 0.7084
INFO - 2018-05-19 06:25:34 --> Config Class Initialized
INFO - 2018-05-19 06:25:34 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:25:34 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:25:34 --> Utf8 Class Initialized
INFO - 2018-05-19 06:25:34 --> URI Class Initialized
INFO - 2018-05-19 06:25:34 --> Router Class Initialized
INFO - 2018-05-19 06:25:34 --> Output Class Initialized
INFO - 2018-05-19 06:25:34 --> Security Class Initialized
DEBUG - 2018-05-19 06:25:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:25:34 --> Input Class Initialized
INFO - 2018-05-19 06:25:34 --> Language Class Initialized
ERROR - 2018-05-19 06:25:34 --> 404 Page Not Found: /index
INFO - 2018-05-19 06:25:34 --> Config Class Initialized
INFO - 2018-05-19 06:25:34 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:25:34 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:25:34 --> Utf8 Class Initialized
INFO - 2018-05-19 06:25:34 --> URI Class Initialized
INFO - 2018-05-19 06:25:34 --> Router Class Initialized
INFO - 2018-05-19 06:25:34 --> Output Class Initialized
INFO - 2018-05-19 06:25:34 --> Security Class Initialized
DEBUG - 2018-05-19 06:25:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:25:34 --> Input Class Initialized
INFO - 2018-05-19 06:25:34 --> Language Class Initialized
ERROR - 2018-05-19 06:25:34 --> 404 Page Not Found: /index
INFO - 2018-05-19 06:25:35 --> Config Class Initialized
INFO - 2018-05-19 06:25:35 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:25:35 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:25:35 --> Utf8 Class Initialized
INFO - 2018-05-19 06:25:35 --> URI Class Initialized
INFO - 2018-05-19 06:25:35 --> Router Class Initialized
INFO - 2018-05-19 06:25:35 --> Output Class Initialized
INFO - 2018-05-19 06:25:35 --> Security Class Initialized
DEBUG - 2018-05-19 06:25:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:25:35 --> Input Class Initialized
INFO - 2018-05-19 06:25:35 --> Language Class Initialized
ERROR - 2018-05-19 06:25:35 --> 404 Page Not Found: /index
INFO - 2018-05-19 06:25:41 --> Config Class Initialized
INFO - 2018-05-19 06:25:41 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:25:41 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:25:41 --> Utf8 Class Initialized
INFO - 2018-05-19 06:25:41 --> URI Class Initialized
INFO - 2018-05-19 06:25:41 --> Router Class Initialized
INFO - 2018-05-19 06:25:41 --> Output Class Initialized
INFO - 2018-05-19 06:25:41 --> Security Class Initialized
DEBUG - 2018-05-19 06:25:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:25:41 --> Input Class Initialized
INFO - 2018-05-19 06:25:41 --> Language Class Initialized
INFO - 2018-05-19 06:25:41 --> Language Class Initialized
INFO - 2018-05-19 06:25:41 --> Config Class Initialized
INFO - 2018-05-19 06:25:41 --> Loader Class Initialized
DEBUG - 2018-05-19 06:25:41 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-19 06:25:41 --> Helper loaded: url_helper
INFO - 2018-05-19 06:25:41 --> Helper loaded: form_helper
INFO - 2018-05-19 06:25:41 --> Helper loaded: date_helper
INFO - 2018-05-19 06:25:41 --> Helper loaded: util_helper
INFO - 2018-05-19 06:25:41 --> Helper loaded: text_helper
INFO - 2018-05-19 06:25:41 --> Helper loaded: string_helper
INFO - 2018-05-19 06:25:41 --> Database Driver Class Initialized
DEBUG - 2018-05-19 06:25:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-19 06:25:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-19 06:25:41 --> Email Class Initialized
INFO - 2018-05-19 06:25:41 --> Controller Class Initialized
DEBUG - 2018-05-19 06:25:41 --> Profile MX_Controller Initialized
DEBUG - 2018-05-19 06:25:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-19 06:25:41 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-19 06:25:41 --> Login MX_Controller Initialized
INFO - 2018-05-19 06:25:41 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-19 06:25:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-19 06:25:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-19 06:25:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-19 06:25:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-19 06:25:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-19 06:25:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/profile_left_nav.php
DEBUG - 2018-05-19 06:25:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-19 06:25:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-19 06:25:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/addresses.php
INFO - 2018-05-19 06:25:42 --> Final output sent to browser
DEBUG - 2018-05-19 06:25:42 --> Total execution time: 0.6947
INFO - 2018-05-19 06:25:45 --> Config Class Initialized
INFO - 2018-05-19 06:25:45 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:25:45 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:25:45 --> Utf8 Class Initialized
INFO - 2018-05-19 06:25:45 --> URI Class Initialized
INFO - 2018-05-19 06:25:45 --> Router Class Initialized
INFO - 2018-05-19 06:25:45 --> Output Class Initialized
INFO - 2018-05-19 06:25:45 --> Security Class Initialized
DEBUG - 2018-05-19 06:25:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:25:45 --> Input Class Initialized
INFO - 2018-05-19 06:25:45 --> Language Class Initialized
INFO - 2018-05-19 06:25:45 --> Language Class Initialized
INFO - 2018-05-19 06:25:45 --> Config Class Initialized
INFO - 2018-05-19 06:25:45 --> Loader Class Initialized
DEBUG - 2018-05-19 06:25:45 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-19 06:25:45 --> Helper loaded: url_helper
INFO - 2018-05-19 06:25:45 --> Helper loaded: form_helper
INFO - 2018-05-19 06:25:45 --> Helper loaded: date_helper
INFO - 2018-05-19 06:25:45 --> Helper loaded: util_helper
INFO - 2018-05-19 06:25:45 --> Helper loaded: text_helper
INFO - 2018-05-19 06:25:45 --> Helper loaded: string_helper
INFO - 2018-05-19 06:25:45 --> Database Driver Class Initialized
DEBUG - 2018-05-19 06:25:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-19 06:25:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-19 06:25:45 --> Email Class Initialized
INFO - 2018-05-19 06:25:45 --> Controller Class Initialized
DEBUG - 2018-05-19 06:25:45 --> Profile MX_Controller Initialized
DEBUG - 2018-05-19 06:25:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-19 06:25:45 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-19 06:25:45 --> Login MX_Controller Initialized
INFO - 2018-05-19 06:25:45 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-19 06:25:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-19 06:25:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-19 06:25:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-19 06:25:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-19 06:25:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-19 06:25:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/profile_left_nav.php
DEBUG - 2018-05-19 06:25:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-19 06:25:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-19 06:25:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/addresses.php
INFO - 2018-05-19 06:25:46 --> Final output sent to browser
DEBUG - 2018-05-19 06:25:46 --> Total execution time: 0.7929
INFO - 2018-05-19 06:25:46 --> Config Class Initialized
INFO - 2018-05-19 06:25:46 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:25:46 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:25:46 --> Utf8 Class Initialized
INFO - 2018-05-19 06:25:46 --> URI Class Initialized
INFO - 2018-05-19 06:25:47 --> Router Class Initialized
INFO - 2018-05-19 06:25:47 --> Output Class Initialized
INFO - 2018-05-19 06:25:47 --> Security Class Initialized
DEBUG - 2018-05-19 06:25:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:25:47 --> Input Class Initialized
INFO - 2018-05-19 06:25:47 --> Language Class Initialized
ERROR - 2018-05-19 06:25:47 --> 404 Page Not Found: /index
INFO - 2018-05-19 06:25:47 --> Config Class Initialized
INFO - 2018-05-19 06:25:47 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:25:47 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:25:47 --> Utf8 Class Initialized
INFO - 2018-05-19 06:25:47 --> URI Class Initialized
INFO - 2018-05-19 06:25:47 --> Router Class Initialized
INFO - 2018-05-19 06:25:47 --> Output Class Initialized
INFO - 2018-05-19 06:25:47 --> Security Class Initialized
DEBUG - 2018-05-19 06:25:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:25:47 --> Input Class Initialized
INFO - 2018-05-19 06:25:47 --> Language Class Initialized
ERROR - 2018-05-19 06:25:47 --> 404 Page Not Found: /index
INFO - 2018-05-19 06:25:48 --> Config Class Initialized
INFO - 2018-05-19 06:25:48 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:25:48 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:25:48 --> Utf8 Class Initialized
INFO - 2018-05-19 06:25:48 --> URI Class Initialized
INFO - 2018-05-19 06:25:48 --> Router Class Initialized
INFO - 2018-05-19 06:25:48 --> Output Class Initialized
INFO - 2018-05-19 06:25:48 --> Security Class Initialized
DEBUG - 2018-05-19 06:25:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:25:48 --> Input Class Initialized
INFO - 2018-05-19 06:25:48 --> Language Class Initialized
ERROR - 2018-05-19 06:25:48 --> 404 Page Not Found: /index
INFO - 2018-05-19 06:26:46 --> Config Class Initialized
INFO - 2018-05-19 06:26:46 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:26:46 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:26:46 --> Utf8 Class Initialized
INFO - 2018-05-19 06:26:46 --> URI Class Initialized
INFO - 2018-05-19 06:26:46 --> Router Class Initialized
INFO - 2018-05-19 06:26:46 --> Output Class Initialized
INFO - 2018-05-19 06:26:46 --> Security Class Initialized
DEBUG - 2018-05-19 06:26:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:26:46 --> Input Class Initialized
INFO - 2018-05-19 06:26:46 --> Language Class Initialized
INFO - 2018-05-19 06:26:46 --> Language Class Initialized
INFO - 2018-05-19 06:26:46 --> Config Class Initialized
INFO - 2018-05-19 06:26:46 --> Loader Class Initialized
DEBUG - 2018-05-19 06:26:46 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-19 06:26:46 --> Helper loaded: url_helper
INFO - 2018-05-19 06:26:46 --> Helper loaded: form_helper
INFO - 2018-05-19 06:26:46 --> Helper loaded: date_helper
INFO - 2018-05-19 06:26:46 --> Helper loaded: util_helper
INFO - 2018-05-19 06:26:46 --> Helper loaded: text_helper
INFO - 2018-05-19 06:26:46 --> Helper loaded: string_helper
INFO - 2018-05-19 06:26:46 --> Database Driver Class Initialized
DEBUG - 2018-05-19 06:26:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-19 06:26:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-19 06:26:46 --> Email Class Initialized
INFO - 2018-05-19 06:26:46 --> Controller Class Initialized
DEBUG - 2018-05-19 06:26:46 --> Profile MX_Controller Initialized
DEBUG - 2018-05-19 06:26:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-19 06:26:46 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-19 06:26:46 --> Login MX_Controller Initialized
INFO - 2018-05-19 06:26:46 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-19 06:26:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-19 06:26:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-19 06:26:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-19 06:26:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-19 06:26:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-19 06:26:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/profile_left_nav.php
DEBUG - 2018-05-19 06:26:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-19 06:26:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-19 06:26:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/billing.php
INFO - 2018-05-19 06:26:47 --> Final output sent to browser
DEBUG - 2018-05-19 06:26:47 --> Total execution time: 0.6802
INFO - 2018-05-19 06:26:47 --> Config Class Initialized
INFO - 2018-05-19 06:26:47 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:26:47 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:26:47 --> Utf8 Class Initialized
INFO - 2018-05-19 06:26:47 --> URI Class Initialized
INFO - 2018-05-19 06:26:47 --> Router Class Initialized
INFO - 2018-05-19 06:26:47 --> Output Class Initialized
INFO - 2018-05-19 06:26:47 --> Security Class Initialized
DEBUG - 2018-05-19 06:26:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:26:47 --> Input Class Initialized
INFO - 2018-05-19 06:26:47 --> Language Class Initialized
ERROR - 2018-05-19 06:26:47 --> 404 Page Not Found: /index
INFO - 2018-05-19 06:26:48 --> Config Class Initialized
INFO - 2018-05-19 06:26:48 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:26:48 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:26:48 --> Utf8 Class Initialized
INFO - 2018-05-19 06:26:48 --> URI Class Initialized
INFO - 2018-05-19 06:26:48 --> Router Class Initialized
INFO - 2018-05-19 06:26:48 --> Output Class Initialized
INFO - 2018-05-19 06:26:48 --> Security Class Initialized
DEBUG - 2018-05-19 06:26:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:26:48 --> Input Class Initialized
INFO - 2018-05-19 06:26:48 --> Language Class Initialized
ERROR - 2018-05-19 06:26:48 --> 404 Page Not Found: /index
INFO - 2018-05-19 06:26:48 --> Config Class Initialized
INFO - 2018-05-19 06:26:48 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:26:49 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:26:49 --> Utf8 Class Initialized
INFO - 2018-05-19 06:26:49 --> URI Class Initialized
INFO - 2018-05-19 06:26:49 --> Router Class Initialized
INFO - 2018-05-19 06:26:49 --> Output Class Initialized
INFO - 2018-05-19 06:26:49 --> Security Class Initialized
DEBUG - 2018-05-19 06:26:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:26:49 --> Input Class Initialized
INFO - 2018-05-19 06:26:49 --> Language Class Initialized
ERROR - 2018-05-19 06:26:49 --> 404 Page Not Found: /index
INFO - 2018-05-19 06:26:53 --> Config Class Initialized
INFO - 2018-05-19 06:26:53 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:26:53 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:26:53 --> Utf8 Class Initialized
INFO - 2018-05-19 06:26:53 --> URI Class Initialized
INFO - 2018-05-19 06:26:53 --> Router Class Initialized
INFO - 2018-05-19 06:26:53 --> Output Class Initialized
INFO - 2018-05-19 06:26:53 --> Security Class Initialized
DEBUG - 2018-05-19 06:26:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:26:53 --> Input Class Initialized
INFO - 2018-05-19 06:26:53 --> Language Class Initialized
INFO - 2018-05-19 06:26:53 --> Language Class Initialized
INFO - 2018-05-19 06:26:53 --> Config Class Initialized
INFO - 2018-05-19 06:26:53 --> Loader Class Initialized
DEBUG - 2018-05-19 06:26:53 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-19 06:26:53 --> Helper loaded: url_helper
INFO - 2018-05-19 06:26:53 --> Helper loaded: form_helper
INFO - 2018-05-19 06:26:53 --> Helper loaded: date_helper
INFO - 2018-05-19 06:26:53 --> Helper loaded: util_helper
INFO - 2018-05-19 06:26:53 --> Helper loaded: text_helper
INFO - 2018-05-19 06:26:53 --> Helper loaded: string_helper
INFO - 2018-05-19 06:26:53 --> Database Driver Class Initialized
DEBUG - 2018-05-19 06:26:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-19 06:26:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-19 06:26:53 --> Email Class Initialized
INFO - 2018-05-19 06:26:53 --> Controller Class Initialized
DEBUG - 2018-05-19 06:26:53 --> Profile MX_Controller Initialized
DEBUG - 2018-05-19 06:26:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-19 06:26:53 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-19 06:26:53 --> Login MX_Controller Initialized
INFO - 2018-05-19 06:26:53 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-19 06:26:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-19 06:26:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-19 06:26:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-19 06:26:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-19 06:26:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-19 06:26:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/profile_left_nav.php
DEBUG - 2018-05-19 06:26:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-19 06:26:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-19 06:26:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/email_preferences.php
INFO - 2018-05-19 06:26:54 --> Final output sent to browser
DEBUG - 2018-05-19 06:26:54 --> Total execution time: 0.7127
INFO - 2018-05-19 06:26:54 --> Config Class Initialized
INFO - 2018-05-19 06:26:54 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:26:54 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:26:54 --> Utf8 Class Initialized
INFO - 2018-05-19 06:26:54 --> URI Class Initialized
INFO - 2018-05-19 06:26:54 --> Router Class Initialized
INFO - 2018-05-19 06:26:54 --> Output Class Initialized
INFO - 2018-05-19 06:26:54 --> Security Class Initialized
DEBUG - 2018-05-19 06:26:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:26:54 --> Input Class Initialized
INFO - 2018-05-19 06:26:54 --> Language Class Initialized
ERROR - 2018-05-19 06:26:54 --> 404 Page Not Found: /index
INFO - 2018-05-19 06:26:55 --> Config Class Initialized
INFO - 2018-05-19 06:26:55 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:26:55 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:26:55 --> Utf8 Class Initialized
INFO - 2018-05-19 06:26:55 --> URI Class Initialized
INFO - 2018-05-19 06:26:55 --> Router Class Initialized
INFO - 2018-05-19 06:26:55 --> Output Class Initialized
INFO - 2018-05-19 06:26:55 --> Security Class Initialized
DEBUG - 2018-05-19 06:26:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:26:55 --> Input Class Initialized
INFO - 2018-05-19 06:26:55 --> Language Class Initialized
ERROR - 2018-05-19 06:26:55 --> 404 Page Not Found: /index
INFO - 2018-05-19 06:26:55 --> Config Class Initialized
INFO - 2018-05-19 06:26:55 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:26:55 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:26:55 --> Utf8 Class Initialized
INFO - 2018-05-19 06:26:55 --> URI Class Initialized
INFO - 2018-05-19 06:26:55 --> Router Class Initialized
INFO - 2018-05-19 06:26:56 --> Output Class Initialized
INFO - 2018-05-19 06:26:56 --> Security Class Initialized
DEBUG - 2018-05-19 06:26:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:26:56 --> Input Class Initialized
INFO - 2018-05-19 06:26:56 --> Language Class Initialized
ERROR - 2018-05-19 06:26:56 --> 404 Page Not Found: /index
INFO - 2018-05-19 06:27:25 --> Config Class Initialized
INFO - 2018-05-19 06:27:25 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:27:25 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:27:25 --> Utf8 Class Initialized
INFO - 2018-05-19 06:27:25 --> URI Class Initialized
INFO - 2018-05-19 06:27:25 --> Router Class Initialized
INFO - 2018-05-19 06:27:25 --> Output Class Initialized
INFO - 2018-05-19 06:27:25 --> Security Class Initialized
DEBUG - 2018-05-19 06:27:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:27:25 --> Input Class Initialized
INFO - 2018-05-19 06:27:25 --> Language Class Initialized
INFO - 2018-05-19 06:27:25 --> Language Class Initialized
INFO - 2018-05-19 06:27:25 --> Config Class Initialized
INFO - 2018-05-19 06:27:25 --> Loader Class Initialized
DEBUG - 2018-05-19 06:27:25 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-19 06:27:25 --> Helper loaded: url_helper
INFO - 2018-05-19 06:27:25 --> Helper loaded: form_helper
INFO - 2018-05-19 06:27:25 --> Helper loaded: date_helper
INFO - 2018-05-19 06:27:25 --> Helper loaded: util_helper
INFO - 2018-05-19 06:27:25 --> Helper loaded: text_helper
INFO - 2018-05-19 06:27:25 --> Helper loaded: string_helper
INFO - 2018-05-19 06:27:25 --> Database Driver Class Initialized
DEBUG - 2018-05-19 06:27:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-19 06:27:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-19 06:27:25 --> Email Class Initialized
INFO - 2018-05-19 06:27:26 --> Controller Class Initialized
DEBUG - 2018-05-19 06:27:26 --> Profile MX_Controller Initialized
DEBUG - 2018-05-19 06:27:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-19 06:27:26 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-19 06:27:26 --> Login MX_Controller Initialized
INFO - 2018-05-19 06:27:26 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-19 06:27:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-19 06:27:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-19 06:27:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-19 06:27:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-19 06:27:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-19 06:27:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/profile_left_nav.php
DEBUG - 2018-05-19 06:27:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-19 06:27:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-19 06:27:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/profile.php
INFO - 2018-05-19 06:27:26 --> Final output sent to browser
DEBUG - 2018-05-19 06:27:26 --> Total execution time: 0.6806
INFO - 2018-05-19 06:27:26 --> Config Class Initialized
INFO - 2018-05-19 06:27:26 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:27:26 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:27:26 --> Config Class Initialized
INFO - 2018-05-19 06:27:26 --> Utf8 Class Initialized
INFO - 2018-05-19 06:27:26 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:27:26 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:27:26 --> URI Class Initialized
INFO - 2018-05-19 06:27:26 --> Utf8 Class Initialized
INFO - 2018-05-19 06:27:26 --> Router Class Initialized
INFO - 2018-05-19 06:27:26 --> URI Class Initialized
INFO - 2018-05-19 06:27:26 --> Router Class Initialized
INFO - 2018-05-19 06:27:26 --> Output Class Initialized
INFO - 2018-05-19 06:27:27 --> Security Class Initialized
INFO - 2018-05-19 06:27:27 --> Output Class Initialized
INFO - 2018-05-19 06:27:27 --> Security Class Initialized
DEBUG - 2018-05-19 06:27:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:27:27 --> Input Class Initialized
DEBUG - 2018-05-19 06:27:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:27:27 --> Language Class Initialized
ERROR - 2018-05-19 06:27:27 --> 404 Page Not Found: /index
INFO - 2018-05-19 06:27:27 --> Input Class Initialized
INFO - 2018-05-19 06:27:27 --> Language Class Initialized
ERROR - 2018-05-19 06:27:27 --> 404 Page Not Found: /index
INFO - 2018-05-19 06:27:27 --> Config Class Initialized
INFO - 2018-05-19 06:27:27 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:27:27 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:27:27 --> Utf8 Class Initialized
INFO - 2018-05-19 06:27:27 --> URI Class Initialized
INFO - 2018-05-19 06:27:27 --> Router Class Initialized
INFO - 2018-05-19 06:27:27 --> Output Class Initialized
INFO - 2018-05-19 06:27:27 --> Security Class Initialized
DEBUG - 2018-05-19 06:27:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:27:27 --> Input Class Initialized
INFO - 2018-05-19 06:27:27 --> Language Class Initialized
ERROR - 2018-05-19 06:27:27 --> 404 Page Not Found: /index
INFO - 2018-05-19 06:27:28 --> Config Class Initialized
INFO - 2018-05-19 06:27:28 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:27:28 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:27:28 --> Utf8 Class Initialized
INFO - 2018-05-19 06:27:28 --> URI Class Initialized
INFO - 2018-05-19 06:27:28 --> Router Class Initialized
INFO - 2018-05-19 06:27:28 --> Output Class Initialized
INFO - 2018-05-19 06:27:28 --> Security Class Initialized
DEBUG - 2018-05-19 06:27:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:27:28 --> Input Class Initialized
INFO - 2018-05-19 06:27:28 --> Language Class Initialized
ERROR - 2018-05-19 06:27:28 --> 404 Page Not Found: /index
INFO - 2018-05-19 06:29:12 --> Config Class Initialized
INFO - 2018-05-19 06:29:12 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:29:12 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:29:12 --> Utf8 Class Initialized
INFO - 2018-05-19 06:29:12 --> URI Class Initialized
INFO - 2018-05-19 06:29:12 --> Router Class Initialized
INFO - 2018-05-19 06:29:12 --> Output Class Initialized
INFO - 2018-05-19 06:29:12 --> Security Class Initialized
DEBUG - 2018-05-19 06:29:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:29:12 --> Input Class Initialized
INFO - 2018-05-19 06:29:12 --> Language Class Initialized
INFO - 2018-05-19 06:29:12 --> Language Class Initialized
INFO - 2018-05-19 06:29:12 --> Config Class Initialized
INFO - 2018-05-19 06:29:12 --> Loader Class Initialized
DEBUG - 2018-05-19 06:29:12 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-19 06:29:12 --> Helper loaded: url_helper
INFO - 2018-05-19 06:29:12 --> Helper loaded: form_helper
INFO - 2018-05-19 06:29:12 --> Helper loaded: date_helper
INFO - 2018-05-19 06:29:12 --> Helper loaded: util_helper
INFO - 2018-05-19 06:29:12 --> Helper loaded: text_helper
INFO - 2018-05-19 06:29:12 --> Helper loaded: string_helper
INFO - 2018-05-19 06:29:12 --> Database Driver Class Initialized
DEBUG - 2018-05-19 06:29:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-19 06:29:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-19 06:29:12 --> Email Class Initialized
INFO - 2018-05-19 06:29:12 --> Controller Class Initialized
DEBUG - 2018-05-19 06:29:12 --> Profile MX_Controller Initialized
DEBUG - 2018-05-19 06:29:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-19 06:29:12 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-19 06:29:12 --> Login MX_Controller Initialized
INFO - 2018-05-19 06:29:12 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-19 06:29:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-19 06:29:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-19 06:29:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-19 06:29:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-19 06:29:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-19 06:29:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/profile_left_nav.php
DEBUG - 2018-05-19 06:29:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-19 06:29:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-19 06:29:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/profile.php
INFO - 2018-05-19 06:29:12 --> Final output sent to browser
DEBUG - 2018-05-19 06:29:13 --> Total execution time: 0.6810
INFO - 2018-05-19 06:29:13 --> Config Class Initialized
INFO - 2018-05-19 06:29:13 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:29:13 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:29:13 --> Utf8 Class Initialized
INFO - 2018-05-19 06:29:13 --> URI Class Initialized
INFO - 2018-05-19 06:29:13 --> Router Class Initialized
INFO - 2018-05-19 06:29:13 --> Output Class Initialized
INFO - 2018-05-19 06:29:13 --> Security Class Initialized
DEBUG - 2018-05-19 06:29:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:29:13 --> Input Class Initialized
INFO - 2018-05-19 06:29:13 --> Language Class Initialized
ERROR - 2018-05-19 06:29:13 --> 404 Page Not Found: /index
INFO - 2018-05-19 06:29:13 --> Config Class Initialized
INFO - 2018-05-19 06:29:13 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:29:13 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:29:13 --> Utf8 Class Initialized
INFO - 2018-05-19 06:29:13 --> Config Class Initialized
INFO - 2018-05-19 06:29:13 --> Hooks Class Initialized
INFO - 2018-05-19 06:29:13 --> URI Class Initialized
DEBUG - 2018-05-19 06:29:13 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:29:13 --> Utf8 Class Initialized
INFO - 2018-05-19 06:29:13 --> URI Class Initialized
INFO - 2018-05-19 06:29:13 --> Router Class Initialized
INFO - 2018-05-19 06:29:13 --> Output Class Initialized
INFO - 2018-05-19 06:29:13 --> Router Class Initialized
INFO - 2018-05-19 06:29:13 --> Security Class Initialized
DEBUG - 2018-05-19 06:29:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:29:13 --> Input Class Initialized
INFO - 2018-05-19 06:29:13 --> Language Class Initialized
ERROR - 2018-05-19 06:29:13 --> 404 Page Not Found: /index
INFO - 2018-05-19 06:29:13 --> Output Class Initialized
INFO - 2018-05-19 06:29:13 --> Security Class Initialized
INFO - 2018-05-19 06:29:13 --> Config Class Initialized
INFO - 2018-05-19 06:29:13 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:29:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-19 06:29:13 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:29:13 --> Utf8 Class Initialized
INFO - 2018-05-19 06:29:13 --> Input Class Initialized
INFO - 2018-05-19 06:29:13 --> URI Class Initialized
INFO - 2018-05-19 06:29:13 --> Router Class Initialized
INFO - 2018-05-19 06:29:14 --> Output Class Initialized
INFO - 2018-05-19 06:29:14 --> Security Class Initialized
INFO - 2018-05-19 06:29:14 --> Language Class Initialized
DEBUG - 2018-05-19 06:29:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:29:14 --> Input Class Initialized
ERROR - 2018-05-19 06:29:14 --> 404 Page Not Found: /index
INFO - 2018-05-19 06:29:14 --> Language Class Initialized
ERROR - 2018-05-19 06:29:14 --> 404 Page Not Found: /index
INFO - 2018-05-19 06:29:14 --> Config Class Initialized
INFO - 2018-05-19 06:29:14 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:29:14 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:29:14 --> Utf8 Class Initialized
INFO - 2018-05-19 06:29:14 --> URI Class Initialized
INFO - 2018-05-19 06:29:14 --> Router Class Initialized
INFO - 2018-05-19 06:29:14 --> Output Class Initialized
INFO - 2018-05-19 06:29:14 --> Security Class Initialized
DEBUG - 2018-05-19 06:29:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:29:14 --> Input Class Initialized
INFO - 2018-05-19 06:29:14 --> Language Class Initialized
ERROR - 2018-05-19 06:29:14 --> 404 Page Not Found: /index
INFO - 2018-05-19 06:29:15 --> Config Class Initialized
INFO - 2018-05-19 06:29:15 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:29:15 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:29:16 --> Utf8 Class Initialized
INFO - 2018-05-19 06:29:16 --> URI Class Initialized
INFO - 2018-05-19 06:29:16 --> Router Class Initialized
INFO - 2018-05-19 06:29:16 --> Output Class Initialized
INFO - 2018-05-19 06:29:16 --> Security Class Initialized
DEBUG - 2018-05-19 06:29:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:29:16 --> Input Class Initialized
INFO - 2018-05-19 06:29:16 --> Language Class Initialized
ERROR - 2018-05-19 06:29:16 --> 404 Page Not Found: /index
INFO - 2018-05-19 06:29:16 --> Config Class Initialized
INFO - 2018-05-19 06:29:16 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:29:16 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:29:16 --> Utf8 Class Initialized
INFO - 2018-05-19 06:29:16 --> URI Class Initialized
INFO - 2018-05-19 06:29:16 --> Router Class Initialized
INFO - 2018-05-19 06:29:16 --> Output Class Initialized
INFO - 2018-05-19 06:29:16 --> Security Class Initialized
DEBUG - 2018-05-19 06:29:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:29:16 --> Input Class Initialized
INFO - 2018-05-19 06:29:16 --> Language Class Initialized
ERROR - 2018-05-19 06:29:16 --> 404 Page Not Found: /index
INFO - 2018-05-19 06:29:16 --> Config Class Initialized
INFO - 2018-05-19 06:29:16 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:29:16 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:29:16 --> Utf8 Class Initialized
INFO - 2018-05-19 06:29:16 --> URI Class Initialized
INFO - 2018-05-19 06:29:16 --> Router Class Initialized
INFO - 2018-05-19 06:29:16 --> Output Class Initialized
INFO - 2018-05-19 06:29:16 --> Security Class Initialized
DEBUG - 2018-05-19 06:29:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:29:16 --> Input Class Initialized
INFO - 2018-05-19 06:29:16 --> Language Class Initialized
ERROR - 2018-05-19 06:29:16 --> 404 Page Not Found: /index
INFO - 2018-05-19 06:32:12 --> Config Class Initialized
INFO - 2018-05-19 06:32:12 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:32:12 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:32:12 --> Utf8 Class Initialized
INFO - 2018-05-19 06:32:12 --> URI Class Initialized
INFO - 2018-05-19 06:32:12 --> Router Class Initialized
INFO - 2018-05-19 06:32:12 --> Output Class Initialized
INFO - 2018-05-19 06:32:12 --> Security Class Initialized
DEBUG - 2018-05-19 06:32:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:32:12 --> Input Class Initialized
INFO - 2018-05-19 06:32:12 --> Language Class Initialized
INFO - 2018-05-19 06:32:12 --> Language Class Initialized
INFO - 2018-05-19 06:32:12 --> Config Class Initialized
INFO - 2018-05-19 06:32:12 --> Loader Class Initialized
DEBUG - 2018-05-19 06:32:12 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-19 06:32:12 --> Helper loaded: url_helper
INFO - 2018-05-19 06:32:13 --> Helper loaded: form_helper
INFO - 2018-05-19 06:32:13 --> Helper loaded: date_helper
INFO - 2018-05-19 06:32:13 --> Helper loaded: util_helper
INFO - 2018-05-19 06:32:13 --> Helper loaded: text_helper
INFO - 2018-05-19 06:32:13 --> Helper loaded: string_helper
INFO - 2018-05-19 06:32:13 --> Database Driver Class Initialized
DEBUG - 2018-05-19 06:32:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-19 06:32:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-19 06:32:13 --> Email Class Initialized
INFO - 2018-05-19 06:32:13 --> Controller Class Initialized
DEBUG - 2018-05-19 06:32:13 --> Profile MX_Controller Initialized
DEBUG - 2018-05-19 06:32:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-19 06:32:13 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-19 06:32:13 --> Login MX_Controller Initialized
INFO - 2018-05-19 06:32:13 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-19 06:32:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-19 06:32:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-19 06:32:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-19 06:32:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-19 06:32:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-19 06:32:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/profile_left_nav.php
DEBUG - 2018-05-19 06:32:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-19 06:32:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-19 06:32:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/profile.php
INFO - 2018-05-19 06:32:13 --> Final output sent to browser
DEBUG - 2018-05-19 06:32:13 --> Total execution time: 0.6906
INFO - 2018-05-19 06:32:13 --> Config Class Initialized
INFO - 2018-05-19 06:32:13 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:32:13 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:32:13 --> Utf8 Class Initialized
INFO - 2018-05-19 06:32:13 --> URI Class Initialized
INFO - 2018-05-19 06:32:13 --> Router Class Initialized
INFO - 2018-05-19 06:32:13 --> Output Class Initialized
INFO - 2018-05-19 06:32:13 --> Security Class Initialized
DEBUG - 2018-05-19 06:32:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:32:13 --> Input Class Initialized
INFO - 2018-05-19 06:32:13 --> Language Class Initialized
ERROR - 2018-05-19 06:32:13 --> 404 Page Not Found: /index
INFO - 2018-05-19 06:32:13 --> Config Class Initialized
INFO - 2018-05-19 06:32:13 --> Hooks Class Initialized
INFO - 2018-05-19 06:32:13 --> Config Class Initialized
INFO - 2018-05-19 06:32:13 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:32:13 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:32:13 --> Utf8 Class Initialized
DEBUG - 2018-05-19 06:32:13 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:32:13 --> Utf8 Class Initialized
INFO - 2018-05-19 06:32:13 --> URI Class Initialized
INFO - 2018-05-19 06:32:14 --> URI Class Initialized
INFO - 2018-05-19 06:32:14 --> Router Class Initialized
INFO - 2018-05-19 06:32:14 --> Router Class Initialized
INFO - 2018-05-19 06:32:14 --> Output Class Initialized
INFO - 2018-05-19 06:32:14 --> Security Class Initialized
DEBUG - 2018-05-19 06:32:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:32:14 --> Input Class Initialized
INFO - 2018-05-19 06:32:14 --> Language Class Initialized
ERROR - 2018-05-19 06:32:14 --> 404 Page Not Found: /index
INFO - 2018-05-19 06:32:14 --> Output Class Initialized
INFO - 2018-05-19 06:32:14 --> Security Class Initialized
DEBUG - 2018-05-19 06:32:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:32:14 --> Input Class Initialized
INFO - 2018-05-19 06:32:14 --> Language Class Initialized
ERROR - 2018-05-19 06:32:14 --> 404 Page Not Found: /index
INFO - 2018-05-19 06:32:14 --> Config Class Initialized
INFO - 2018-05-19 06:32:14 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:32:14 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:32:14 --> Utf8 Class Initialized
INFO - 2018-05-19 06:32:14 --> URI Class Initialized
INFO - 2018-05-19 06:32:14 --> Router Class Initialized
INFO - 2018-05-19 06:32:14 --> Output Class Initialized
INFO - 2018-05-19 06:32:14 --> Security Class Initialized
DEBUG - 2018-05-19 06:32:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:32:14 --> Input Class Initialized
INFO - 2018-05-19 06:32:14 --> Language Class Initialized
ERROR - 2018-05-19 06:32:14 --> 404 Page Not Found: /index
INFO - 2018-05-19 06:32:14 --> Config Class Initialized
INFO - 2018-05-19 06:32:14 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:32:14 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:32:14 --> Utf8 Class Initialized
INFO - 2018-05-19 06:32:14 --> URI Class Initialized
INFO - 2018-05-19 06:32:14 --> Router Class Initialized
INFO - 2018-05-19 06:32:14 --> Output Class Initialized
INFO - 2018-05-19 06:32:14 --> Security Class Initialized
DEBUG - 2018-05-19 06:32:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:32:14 --> Input Class Initialized
INFO - 2018-05-19 06:32:14 --> Language Class Initialized
ERROR - 2018-05-19 06:32:14 --> 404 Page Not Found: /index
INFO - 2018-05-19 06:32:15 --> Config Class Initialized
INFO - 2018-05-19 06:32:15 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:32:15 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:32:15 --> Utf8 Class Initialized
INFO - 2018-05-19 06:32:15 --> URI Class Initialized
INFO - 2018-05-19 06:32:15 --> Router Class Initialized
INFO - 2018-05-19 06:32:16 --> Output Class Initialized
INFO - 2018-05-19 06:32:16 --> Security Class Initialized
DEBUG - 2018-05-19 06:32:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:32:16 --> Input Class Initialized
INFO - 2018-05-19 06:32:16 --> Language Class Initialized
ERROR - 2018-05-19 06:32:16 --> 404 Page Not Found: /index
INFO - 2018-05-19 06:32:16 --> Config Class Initialized
INFO - 2018-05-19 06:32:16 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:32:16 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:32:16 --> Utf8 Class Initialized
INFO - 2018-05-19 06:32:16 --> URI Class Initialized
INFO - 2018-05-19 06:32:16 --> Router Class Initialized
INFO - 2018-05-19 06:32:16 --> Output Class Initialized
INFO - 2018-05-19 06:32:16 --> Security Class Initialized
DEBUG - 2018-05-19 06:32:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:32:16 --> Input Class Initialized
INFO - 2018-05-19 06:32:16 --> Language Class Initialized
ERROR - 2018-05-19 06:32:16 --> 404 Page Not Found: /index
INFO - 2018-05-19 06:32:16 --> Config Class Initialized
INFO - 2018-05-19 06:32:16 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:32:16 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:32:16 --> Utf8 Class Initialized
INFO - 2018-05-19 06:32:16 --> URI Class Initialized
INFO - 2018-05-19 06:32:16 --> Router Class Initialized
INFO - 2018-05-19 06:32:16 --> Output Class Initialized
INFO - 2018-05-19 06:32:16 --> Security Class Initialized
DEBUG - 2018-05-19 06:32:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:32:16 --> Input Class Initialized
INFO - 2018-05-19 06:32:16 --> Language Class Initialized
ERROR - 2018-05-19 06:32:16 --> 404 Page Not Found: /index
INFO - 2018-05-19 06:33:15 --> Config Class Initialized
INFO - 2018-05-19 06:33:15 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:33:15 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:33:15 --> Utf8 Class Initialized
INFO - 2018-05-19 06:33:15 --> URI Class Initialized
INFO - 2018-05-19 06:33:15 --> Router Class Initialized
INFO - 2018-05-19 06:33:15 --> Output Class Initialized
INFO - 2018-05-19 06:33:15 --> Security Class Initialized
DEBUG - 2018-05-19 06:33:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:33:15 --> Input Class Initialized
INFO - 2018-05-19 06:33:15 --> Language Class Initialized
INFO - 2018-05-19 06:33:15 --> Language Class Initialized
INFO - 2018-05-19 06:33:15 --> Config Class Initialized
INFO - 2018-05-19 06:33:15 --> Loader Class Initialized
DEBUG - 2018-05-19 06:33:15 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-19 06:33:15 --> Helper loaded: url_helper
INFO - 2018-05-19 06:33:15 --> Helper loaded: form_helper
INFO - 2018-05-19 06:33:15 --> Helper loaded: date_helper
INFO - 2018-05-19 06:33:15 --> Helper loaded: util_helper
INFO - 2018-05-19 06:33:15 --> Helper loaded: text_helper
INFO - 2018-05-19 06:33:15 --> Helper loaded: string_helper
INFO - 2018-05-19 06:33:15 --> Database Driver Class Initialized
DEBUG - 2018-05-19 06:33:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-19 06:33:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-19 06:33:15 --> Email Class Initialized
INFO - 2018-05-19 06:33:15 --> Controller Class Initialized
DEBUG - 2018-05-19 06:33:15 --> Profile MX_Controller Initialized
DEBUG - 2018-05-19 06:33:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-19 06:33:15 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-19 06:33:15 --> Login MX_Controller Initialized
INFO - 2018-05-19 06:33:15 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-19 06:33:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-19 06:33:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-19 06:33:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-19 06:33:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-19 06:33:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-19 06:33:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/profile_left_nav.php
DEBUG - 2018-05-19 06:33:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-19 06:33:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-19 06:33:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/reset_password.php
INFO - 2018-05-19 06:33:15 --> Final output sent to browser
DEBUG - 2018-05-19 06:33:16 --> Total execution time: 0.8013
INFO - 2018-05-19 06:33:16 --> Config Class Initialized
INFO - 2018-05-19 06:33:16 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:33:16 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:33:16 --> Utf8 Class Initialized
INFO - 2018-05-19 06:33:16 --> URI Class Initialized
INFO - 2018-05-19 06:33:16 --> Router Class Initialized
INFO - 2018-05-19 06:33:16 --> Output Class Initialized
INFO - 2018-05-19 06:33:16 --> Security Class Initialized
DEBUG - 2018-05-19 06:33:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:33:16 --> Input Class Initialized
INFO - 2018-05-19 06:33:16 --> Language Class Initialized
ERROR - 2018-05-19 06:33:16 --> 404 Page Not Found: /index
INFO - 2018-05-19 06:33:16 --> Config Class Initialized
INFO - 2018-05-19 06:33:16 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:33:16 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:33:16 --> Utf8 Class Initialized
INFO - 2018-05-19 06:33:16 --> URI Class Initialized
INFO - 2018-05-19 06:33:16 --> Router Class Initialized
INFO - 2018-05-19 06:33:17 --> Output Class Initialized
INFO - 2018-05-19 06:33:17 --> Security Class Initialized
DEBUG - 2018-05-19 06:33:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:33:17 --> Input Class Initialized
INFO - 2018-05-19 06:33:17 --> Language Class Initialized
ERROR - 2018-05-19 06:33:17 --> 404 Page Not Found: /index
INFO - 2018-05-19 06:33:17 --> Config Class Initialized
INFO - 2018-05-19 06:33:17 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:33:17 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:33:17 --> Utf8 Class Initialized
INFO - 2018-05-19 06:33:17 --> URI Class Initialized
INFO - 2018-05-19 06:33:17 --> Router Class Initialized
INFO - 2018-05-19 06:33:17 --> Output Class Initialized
INFO - 2018-05-19 06:33:17 --> Security Class Initialized
DEBUG - 2018-05-19 06:33:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:33:17 --> Input Class Initialized
INFO - 2018-05-19 06:33:17 --> Language Class Initialized
ERROR - 2018-05-19 06:33:17 --> 404 Page Not Found: /index
INFO - 2018-05-19 06:33:18 --> Config Class Initialized
INFO - 2018-05-19 06:33:18 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:33:18 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:33:18 --> Utf8 Class Initialized
INFO - 2018-05-19 06:33:18 --> URI Class Initialized
INFO - 2018-05-19 06:33:18 --> Router Class Initialized
INFO - 2018-05-19 06:33:18 --> Output Class Initialized
INFO - 2018-05-19 06:33:18 --> Security Class Initialized
DEBUG - 2018-05-19 06:33:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:33:18 --> Input Class Initialized
INFO - 2018-05-19 06:33:18 --> Language Class Initialized
INFO - 2018-05-19 06:33:18 --> Language Class Initialized
INFO - 2018-05-19 06:33:18 --> Config Class Initialized
INFO - 2018-05-19 06:33:18 --> Loader Class Initialized
DEBUG - 2018-05-19 06:33:18 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-19 06:33:18 --> Helper loaded: url_helper
INFO - 2018-05-19 06:33:18 --> Helper loaded: form_helper
INFO - 2018-05-19 06:33:18 --> Helper loaded: date_helper
INFO - 2018-05-19 06:33:18 --> Helper loaded: util_helper
INFO - 2018-05-19 06:33:18 --> Helper loaded: text_helper
INFO - 2018-05-19 06:33:18 --> Helper loaded: string_helper
INFO - 2018-05-19 06:33:18 --> Database Driver Class Initialized
DEBUG - 2018-05-19 06:33:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-19 06:33:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-19 06:33:18 --> Email Class Initialized
INFO - 2018-05-19 06:33:18 --> Controller Class Initialized
DEBUG - 2018-05-19 06:33:18 --> Profile MX_Controller Initialized
DEBUG - 2018-05-19 06:33:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-19 06:33:18 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-19 06:33:18 --> Login MX_Controller Initialized
INFO - 2018-05-19 06:33:18 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-19 06:33:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-19 06:33:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-19 06:33:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-19 06:33:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-19 06:33:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-19 06:33:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/profile_left_nav.php
DEBUG - 2018-05-19 06:33:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-19 06:33:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-19 06:33:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/addresses.php
INFO - 2018-05-19 06:33:19 --> Final output sent to browser
DEBUG - 2018-05-19 06:33:19 --> Total execution time: 0.7347
INFO - 2018-05-19 06:33:19 --> Config Class Initialized
INFO - 2018-05-19 06:33:19 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:33:19 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:33:19 --> Utf8 Class Initialized
INFO - 2018-05-19 06:33:19 --> URI Class Initialized
INFO - 2018-05-19 06:33:19 --> Router Class Initialized
INFO - 2018-05-19 06:33:19 --> Output Class Initialized
INFO - 2018-05-19 06:33:19 --> Security Class Initialized
DEBUG - 2018-05-19 06:33:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:33:19 --> Input Class Initialized
INFO - 2018-05-19 06:33:19 --> Language Class Initialized
ERROR - 2018-05-19 06:33:19 --> 404 Page Not Found: /index
INFO - 2018-05-19 06:33:19 --> Config Class Initialized
INFO - 2018-05-19 06:33:19 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:33:19 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:33:19 --> Utf8 Class Initialized
INFO - 2018-05-19 06:33:19 --> URI Class Initialized
INFO - 2018-05-19 06:33:19 --> Router Class Initialized
INFO - 2018-05-19 06:33:19 --> Output Class Initialized
INFO - 2018-05-19 06:33:20 --> Security Class Initialized
DEBUG - 2018-05-19 06:33:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:33:20 --> Input Class Initialized
INFO - 2018-05-19 06:33:20 --> Language Class Initialized
ERROR - 2018-05-19 06:33:20 --> 404 Page Not Found: /index
INFO - 2018-05-19 06:33:20 --> Config Class Initialized
INFO - 2018-05-19 06:33:20 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:33:20 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:33:20 --> Utf8 Class Initialized
INFO - 2018-05-19 06:33:20 --> URI Class Initialized
INFO - 2018-05-19 06:33:20 --> Router Class Initialized
INFO - 2018-05-19 06:33:20 --> Output Class Initialized
INFO - 2018-05-19 06:33:20 --> Security Class Initialized
DEBUG - 2018-05-19 06:33:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:33:20 --> Input Class Initialized
INFO - 2018-05-19 06:33:20 --> Language Class Initialized
ERROR - 2018-05-19 06:33:20 --> 404 Page Not Found: /index
INFO - 2018-05-19 06:33:20 --> Config Class Initialized
INFO - 2018-05-19 06:33:20 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:33:20 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:33:21 --> Utf8 Class Initialized
INFO - 2018-05-19 06:33:21 --> URI Class Initialized
INFO - 2018-05-19 06:33:21 --> Router Class Initialized
INFO - 2018-05-19 06:33:21 --> Output Class Initialized
INFO - 2018-05-19 06:33:21 --> Security Class Initialized
DEBUG - 2018-05-19 06:33:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:33:21 --> Input Class Initialized
INFO - 2018-05-19 06:33:21 --> Language Class Initialized
INFO - 2018-05-19 06:33:21 --> Language Class Initialized
INFO - 2018-05-19 06:33:21 --> Config Class Initialized
INFO - 2018-05-19 06:33:21 --> Loader Class Initialized
DEBUG - 2018-05-19 06:33:21 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-19 06:33:21 --> Helper loaded: url_helper
INFO - 2018-05-19 06:33:21 --> Helper loaded: form_helper
INFO - 2018-05-19 06:33:21 --> Helper loaded: date_helper
INFO - 2018-05-19 06:33:21 --> Helper loaded: util_helper
INFO - 2018-05-19 06:33:21 --> Helper loaded: text_helper
INFO - 2018-05-19 06:33:21 --> Helper loaded: string_helper
INFO - 2018-05-19 06:33:21 --> Database Driver Class Initialized
DEBUG - 2018-05-19 06:33:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-19 06:33:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-19 06:33:21 --> Email Class Initialized
INFO - 2018-05-19 06:33:21 --> Controller Class Initialized
DEBUG - 2018-05-19 06:33:21 --> Profile MX_Controller Initialized
DEBUG - 2018-05-19 06:33:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-19 06:33:21 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-19 06:33:21 --> Login MX_Controller Initialized
INFO - 2018-05-19 06:33:21 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-19 06:33:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-19 06:33:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-19 06:33:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-19 06:33:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-19 06:33:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-19 06:33:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/profile_left_nav.php
DEBUG - 2018-05-19 06:33:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-19 06:33:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-19 06:33:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/profile.php
INFO - 2018-05-19 06:33:21 --> Final output sent to browser
INFO - 2018-05-19 06:33:21 --> Config Class Initialized
INFO - 2018-05-19 06:33:21 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:33:21 --> Total execution time: 0.6879
DEBUG - 2018-05-19 06:33:21 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:33:21 --> Utf8 Class Initialized
INFO - 2018-05-19 06:33:21 --> URI Class Initialized
INFO - 2018-05-19 06:33:21 --> Router Class Initialized
INFO - 2018-05-19 06:33:21 --> Output Class Initialized
INFO - 2018-05-19 06:33:21 --> Security Class Initialized
INFO - 2018-05-19 06:33:21 --> Config Class Initialized
DEBUG - 2018-05-19 06:33:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:33:21 --> Hooks Class Initialized
INFO - 2018-05-19 06:33:21 --> Config Class Initialized
INFO - 2018-05-19 06:33:22 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:33:22 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:33:22 --> Input Class Initialized
DEBUG - 2018-05-19 06:33:22 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:33:22 --> Utf8 Class Initialized
INFO - 2018-05-19 06:33:22 --> Utf8 Class Initialized
INFO - 2018-05-19 06:33:22 --> Language Class Initialized
INFO - 2018-05-19 06:33:22 --> URI Class Initialized
ERROR - 2018-05-19 06:33:22 --> 404 Page Not Found: /index
INFO - 2018-05-19 06:33:22 --> URI Class Initialized
INFO - 2018-05-19 06:33:22 --> Router Class Initialized
INFO - 2018-05-19 06:33:22 --> Router Class Initialized
INFO - 2018-05-19 06:33:22 --> Output Class Initialized
INFO - 2018-05-19 06:33:22 --> Output Class Initialized
INFO - 2018-05-19 06:33:22 --> Security Class Initialized
DEBUG - 2018-05-19 06:33:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:33:22 --> Security Class Initialized
INFO - 2018-05-19 06:33:22 --> Input Class Initialized
DEBUG - 2018-05-19 06:33:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:33:22 --> Input Class Initialized
INFO - 2018-05-19 06:33:22 --> Language Class Initialized
ERROR - 2018-05-19 06:33:22 --> 404 Page Not Found: /index
INFO - 2018-05-19 06:33:22 --> Language Class Initialized
INFO - 2018-05-19 06:33:22 --> Config Class Initialized
ERROR - 2018-05-19 06:33:22 --> 404 Page Not Found: /index
INFO - 2018-05-19 06:33:22 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:33:22 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:33:22 --> Utf8 Class Initialized
INFO - 2018-05-19 06:33:22 --> URI Class Initialized
INFO - 2018-05-19 06:33:22 --> Router Class Initialized
INFO - 2018-05-19 06:33:22 --> Output Class Initialized
INFO - 2018-05-19 06:33:22 --> Security Class Initialized
DEBUG - 2018-05-19 06:33:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:33:22 --> Input Class Initialized
INFO - 2018-05-19 06:33:22 --> Language Class Initialized
ERROR - 2018-05-19 06:33:22 --> 404 Page Not Found: /index
INFO - 2018-05-19 06:33:22 --> Config Class Initialized
INFO - 2018-05-19 06:33:22 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:33:22 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:33:22 --> Utf8 Class Initialized
INFO - 2018-05-19 06:33:22 --> URI Class Initialized
INFO - 2018-05-19 06:33:22 --> Router Class Initialized
INFO - 2018-05-19 06:33:22 --> Output Class Initialized
INFO - 2018-05-19 06:33:22 --> Security Class Initialized
DEBUG - 2018-05-19 06:33:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:33:22 --> Input Class Initialized
INFO - 2018-05-19 06:33:22 --> Language Class Initialized
ERROR - 2018-05-19 06:33:22 --> 404 Page Not Found: /index
INFO - 2018-05-19 06:33:55 --> Config Class Initialized
INFO - 2018-05-19 06:33:55 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:33:55 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:33:55 --> Utf8 Class Initialized
INFO - 2018-05-19 06:33:55 --> URI Class Initialized
INFO - 2018-05-19 06:33:55 --> Router Class Initialized
INFO - 2018-05-19 06:33:55 --> Output Class Initialized
INFO - 2018-05-19 06:33:55 --> Security Class Initialized
DEBUG - 2018-05-19 06:33:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:33:55 --> Input Class Initialized
INFO - 2018-05-19 06:33:55 --> Language Class Initialized
INFO - 2018-05-19 06:33:55 --> Language Class Initialized
INFO - 2018-05-19 06:33:55 --> Config Class Initialized
INFO - 2018-05-19 06:33:55 --> Loader Class Initialized
DEBUG - 2018-05-19 06:33:55 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-19 06:33:55 --> Helper loaded: url_helper
INFO - 2018-05-19 06:33:55 --> Helper loaded: form_helper
INFO - 2018-05-19 06:33:55 --> Helper loaded: date_helper
INFO - 2018-05-19 06:33:55 --> Helper loaded: util_helper
INFO - 2018-05-19 06:33:55 --> Helper loaded: text_helper
INFO - 2018-05-19 06:33:55 --> Helper loaded: string_helper
INFO - 2018-05-19 06:33:55 --> Database Driver Class Initialized
DEBUG - 2018-05-19 06:33:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-19 06:33:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-19 06:33:55 --> Email Class Initialized
INFO - 2018-05-19 06:33:55 --> Controller Class Initialized
DEBUG - 2018-05-19 06:33:55 --> Home MX_Controller Initialized
DEBUG - 2018-05-19 06:33:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-19 06:33:55 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-19 06:33:55 --> Login MX_Controller Initialized
INFO - 2018-05-19 06:33:55 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-19 06:33:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-19 06:33:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-19 06:33:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-19 06:33:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-19 06:33:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-19 06:33:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-19 06:33:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-19 06:33:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-05-19 06:33:55 --> Final output sent to browser
DEBUG - 2018-05-19 06:33:55 --> Total execution time: 0.6793
INFO - 2018-05-19 06:33:56 --> Config Class Initialized
INFO - 2018-05-19 06:33:56 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:33:56 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:33:56 --> Utf8 Class Initialized
INFO - 2018-05-19 06:33:56 --> URI Class Initialized
INFO - 2018-05-19 06:33:56 --> Router Class Initialized
INFO - 2018-05-19 06:33:56 --> Output Class Initialized
INFO - 2018-05-19 06:33:56 --> Security Class Initialized
DEBUG - 2018-05-19 06:33:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:33:56 --> Input Class Initialized
INFO - 2018-05-19 06:33:56 --> Language Class Initialized
ERROR - 2018-05-19 06:33:56 --> 404 Page Not Found: /index
INFO - 2018-05-19 06:33:56 --> Config Class Initialized
INFO - 2018-05-19 06:33:56 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:33:56 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:33:56 --> Utf8 Class Initialized
INFO - 2018-05-19 06:33:56 --> URI Class Initialized
INFO - 2018-05-19 06:33:56 --> Router Class Initialized
INFO - 2018-05-19 06:33:56 --> Output Class Initialized
INFO - 2018-05-19 06:33:56 --> Security Class Initialized
DEBUG - 2018-05-19 06:33:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:33:56 --> Input Class Initialized
INFO - 2018-05-19 06:33:56 --> Language Class Initialized
ERROR - 2018-05-19 06:33:56 --> 404 Page Not Found: /index
INFO - 2018-05-19 06:33:56 --> Config Class Initialized
INFO - 2018-05-19 06:33:56 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:33:56 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:33:56 --> Utf8 Class Initialized
INFO - 2018-05-19 06:33:57 --> URI Class Initialized
INFO - 2018-05-19 06:33:57 --> Router Class Initialized
INFO - 2018-05-19 06:33:57 --> Output Class Initialized
INFO - 2018-05-19 06:33:57 --> Security Class Initialized
DEBUG - 2018-05-19 06:33:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:33:57 --> Input Class Initialized
INFO - 2018-05-19 06:33:57 --> Language Class Initialized
ERROR - 2018-05-19 06:33:57 --> 404 Page Not Found: /index
INFO - 2018-05-19 06:33:59 --> Config Class Initialized
INFO - 2018-05-19 06:33:59 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:33:59 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:33:59 --> Utf8 Class Initialized
INFO - 2018-05-19 06:33:59 --> URI Class Initialized
INFO - 2018-05-19 06:33:59 --> Router Class Initialized
INFO - 2018-05-19 06:33:59 --> Output Class Initialized
INFO - 2018-05-19 06:33:59 --> Security Class Initialized
DEBUG - 2018-05-19 06:33:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:33:59 --> Input Class Initialized
INFO - 2018-05-19 06:34:00 --> Language Class Initialized
INFO - 2018-05-19 06:34:00 --> Language Class Initialized
INFO - 2018-05-19 06:34:00 --> Config Class Initialized
INFO - 2018-05-19 06:34:00 --> Loader Class Initialized
DEBUG - 2018-05-19 06:34:00 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-19 06:34:00 --> Helper loaded: url_helper
INFO - 2018-05-19 06:34:00 --> Helper loaded: form_helper
INFO - 2018-05-19 06:34:00 --> Helper loaded: date_helper
INFO - 2018-05-19 06:34:00 --> Helper loaded: util_helper
INFO - 2018-05-19 06:34:00 --> Helper loaded: text_helper
INFO - 2018-05-19 06:34:00 --> Helper loaded: string_helper
INFO - 2018-05-19 06:34:00 --> Database Driver Class Initialized
DEBUG - 2018-05-19 06:34:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-19 06:34:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-19 06:34:00 --> Email Class Initialized
INFO - 2018-05-19 06:34:00 --> Controller Class Initialized
DEBUG - 2018-05-19 06:34:00 --> Home MX_Controller Initialized
DEBUG - 2018-05-19 06:34:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-19 06:34:00 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-19 06:34:00 --> Login MX_Controller Initialized
INFO - 2018-05-19 06:34:00 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-19 06:34:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-19 06:34:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-19 06:34:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-19 06:34:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-19 06:34:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-19 06:34:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-19 06:34:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-19 06:34:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-05-19 06:34:00 --> Final output sent to browser
DEBUG - 2018-05-19 06:34:00 --> Total execution time: 0.8930
INFO - 2018-05-19 06:34:00 --> Config Class Initialized
INFO - 2018-05-19 06:34:00 --> Config Class Initialized
INFO - 2018-05-19 06:34:01 --> Hooks Class Initialized
INFO - 2018-05-19 06:34:01 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:34:01 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:34:01 --> Utf8 Class Initialized
INFO - 2018-05-19 06:34:01 --> URI Class Initialized
INFO - 2018-05-19 06:34:01 --> Router Class Initialized
DEBUG - 2018-05-19 06:34:01 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:34:01 --> Output Class Initialized
INFO - 2018-05-19 06:34:01 --> Utf8 Class Initialized
INFO - 2018-05-19 06:34:01 --> URI Class Initialized
INFO - 2018-05-19 06:34:01 --> Security Class Initialized
INFO - 2018-05-19 06:34:01 --> Router Class Initialized
INFO - 2018-05-19 06:34:01 --> Output Class Initialized
INFO - 2018-05-19 06:34:01 --> Security Class Initialized
DEBUG - 2018-05-19 06:34:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-19 06:34:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:34:01 --> Input Class Initialized
INFO - 2018-05-19 06:34:01 --> Input Class Initialized
INFO - 2018-05-19 06:34:01 --> Language Class Initialized
INFO - 2018-05-19 06:34:01 --> Language Class Initialized
ERROR - 2018-05-19 06:34:01 --> 404 Page Not Found: /index
ERROR - 2018-05-19 06:34:01 --> 404 Page Not Found: /index
INFO - 2018-05-19 06:34:02 --> Config Class Initialized
INFO - 2018-05-19 06:34:02 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:34:02 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:34:02 --> Utf8 Class Initialized
INFO - 2018-05-19 06:34:02 --> URI Class Initialized
INFO - 2018-05-19 06:34:02 --> Router Class Initialized
INFO - 2018-05-19 06:34:02 --> Output Class Initialized
INFO - 2018-05-19 06:34:02 --> Security Class Initialized
DEBUG - 2018-05-19 06:34:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:34:02 --> Input Class Initialized
INFO - 2018-05-19 06:34:02 --> Language Class Initialized
ERROR - 2018-05-19 06:34:02 --> 404 Page Not Found: /index
INFO - 2018-05-19 06:34:02 --> Config Class Initialized
INFO - 2018-05-19 06:34:02 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:34:02 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:34:02 --> Utf8 Class Initialized
INFO - 2018-05-19 06:34:02 --> URI Class Initialized
INFO - 2018-05-19 06:34:02 --> Router Class Initialized
INFO - 2018-05-19 06:34:02 --> Output Class Initialized
INFO - 2018-05-19 06:34:02 --> Security Class Initialized
DEBUG - 2018-05-19 06:34:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:34:02 --> Input Class Initialized
INFO - 2018-05-19 06:34:02 --> Language Class Initialized
ERROR - 2018-05-19 06:34:02 --> 404 Page Not Found: /index
INFO - 2018-05-19 06:34:29 --> Config Class Initialized
INFO - 2018-05-19 06:34:30 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:34:30 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:34:30 --> Utf8 Class Initialized
INFO - 2018-05-19 06:34:30 --> URI Class Initialized
INFO - 2018-05-19 06:34:30 --> Router Class Initialized
INFO - 2018-05-19 06:34:30 --> Output Class Initialized
INFO - 2018-05-19 06:34:30 --> Security Class Initialized
DEBUG - 2018-05-19 06:34:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:34:30 --> Input Class Initialized
INFO - 2018-05-19 06:34:30 --> Language Class Initialized
INFO - 2018-05-19 06:34:30 --> Language Class Initialized
INFO - 2018-05-19 06:34:30 --> Config Class Initialized
INFO - 2018-05-19 06:34:30 --> Loader Class Initialized
DEBUG - 2018-05-19 06:34:30 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-19 06:34:30 --> Helper loaded: url_helper
INFO - 2018-05-19 06:34:30 --> Helper loaded: form_helper
INFO - 2018-05-19 06:34:30 --> Helper loaded: date_helper
INFO - 2018-05-19 06:34:30 --> Helper loaded: util_helper
INFO - 2018-05-19 06:34:30 --> Helper loaded: text_helper
INFO - 2018-05-19 06:34:30 --> Helper loaded: string_helper
INFO - 2018-05-19 06:34:30 --> Database Driver Class Initialized
DEBUG - 2018-05-19 06:34:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-19 06:34:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-19 06:34:30 --> Email Class Initialized
INFO - 2018-05-19 06:34:30 --> Controller Class Initialized
DEBUG - 2018-05-19 06:34:30 --> Admin MX_Controller Initialized
INFO - 2018-05-19 06:34:30 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-19 06:34:30 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-19 06:34:30 --> Login MX_Controller Initialized
DEBUG - 2018-05-19 06:34:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-19 06:34:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-19 06:34:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/logins/login.php
INFO - 2018-05-19 06:34:30 --> Config Class Initialized
INFO - 2018-05-19 06:34:30 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:34:30 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:34:30 --> Utf8 Class Initialized
INFO - 2018-05-19 06:34:30 --> URI Class Initialized
INFO - 2018-05-19 06:34:31 --> Router Class Initialized
INFO - 2018-05-19 06:34:31 --> Output Class Initialized
INFO - 2018-05-19 06:34:31 --> Security Class Initialized
DEBUG - 2018-05-19 06:34:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:34:31 --> Input Class Initialized
INFO - 2018-05-19 06:34:31 --> Language Class Initialized
ERROR - 2018-05-19 06:34:31 --> 404 Page Not Found: /index
INFO - 2018-05-19 06:34:45 --> Config Class Initialized
INFO - 2018-05-19 06:34:45 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:34:45 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:34:45 --> Utf8 Class Initialized
INFO - 2018-05-19 06:34:45 --> URI Class Initialized
INFO - 2018-05-19 06:34:45 --> Router Class Initialized
INFO - 2018-05-19 06:34:45 --> Output Class Initialized
INFO - 2018-05-19 06:34:45 --> Security Class Initialized
DEBUG - 2018-05-19 06:34:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:34:45 --> Input Class Initialized
INFO - 2018-05-19 06:34:45 --> Language Class Initialized
INFO - 2018-05-19 06:34:45 --> Language Class Initialized
INFO - 2018-05-19 06:34:45 --> Config Class Initialized
INFO - 2018-05-19 06:34:45 --> Loader Class Initialized
DEBUG - 2018-05-19 06:34:45 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-19 06:34:45 --> Helper loaded: url_helper
INFO - 2018-05-19 06:34:45 --> Helper loaded: form_helper
INFO - 2018-05-19 06:34:45 --> Helper loaded: date_helper
INFO - 2018-05-19 06:34:45 --> Helper loaded: util_helper
INFO - 2018-05-19 06:34:45 --> Helper loaded: text_helper
INFO - 2018-05-19 06:34:45 --> Helper loaded: string_helper
INFO - 2018-05-19 06:34:45 --> Database Driver Class Initialized
DEBUG - 2018-05-19 06:34:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-19 06:34:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-19 06:34:45 --> Email Class Initialized
INFO - 2018-05-19 06:34:45 --> Controller Class Initialized
DEBUG - 2018-05-19 06:34:45 --> Login MX_Controller Initialized
INFO - 2018-05-19 06:34:45 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-19 06:34:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-19 06:34:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-19 06:34:45 --> Email starts for admin@colin.com fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-05-19 06:34:45 --> User session created for 1
INFO - 2018-05-19 06:34:45 --> Login status admin@colin.com - success
INFO - 2018-05-19 06:34:46 --> Final output sent to browser
DEBUG - 2018-05-19 06:34:46 --> Total execution time: 0.6004
INFO - 2018-05-19 06:34:46 --> Config Class Initialized
INFO - 2018-05-19 06:34:46 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:34:46 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:34:46 --> Utf8 Class Initialized
INFO - 2018-05-19 06:34:46 --> URI Class Initialized
INFO - 2018-05-19 06:34:46 --> Router Class Initialized
INFO - 2018-05-19 06:34:46 --> Output Class Initialized
INFO - 2018-05-19 06:34:46 --> Security Class Initialized
DEBUG - 2018-05-19 06:34:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:34:46 --> Input Class Initialized
INFO - 2018-05-19 06:34:46 --> Language Class Initialized
INFO - 2018-05-19 06:34:46 --> Language Class Initialized
INFO - 2018-05-19 06:34:46 --> Config Class Initialized
INFO - 2018-05-19 06:34:46 --> Loader Class Initialized
DEBUG - 2018-05-19 06:34:46 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-19 06:34:46 --> Helper loaded: url_helper
INFO - 2018-05-19 06:34:46 --> Helper loaded: form_helper
INFO - 2018-05-19 06:34:46 --> Helper loaded: date_helper
INFO - 2018-05-19 06:34:46 --> Helper loaded: util_helper
INFO - 2018-05-19 06:34:46 --> Helper loaded: text_helper
INFO - 2018-05-19 06:34:46 --> Helper loaded: string_helper
INFO - 2018-05-19 06:34:46 --> Database Driver Class Initialized
DEBUG - 2018-05-19 06:34:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-19 06:34:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-19 06:34:46 --> Email Class Initialized
INFO - 2018-05-19 06:34:46 --> Controller Class Initialized
DEBUG - 2018-05-19 06:34:46 --> Admin MX_Controller Initialized
INFO - 2018-05-19 06:34:46 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-19 06:34:46 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-19 06:34:46 --> Login MX_Controller Initialized
DEBUG - 2018-05-19 06:34:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-19 06:34:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-19 06:34:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-05-19 06:34:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-05-19 06:34:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-05-19 06:34:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-05-19 06:34:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-05-19 06:34:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/dashboard.php
INFO - 2018-05-19 06:34:46 --> Final output sent to browser
DEBUG - 2018-05-19 06:34:46 --> Total execution time: 0.6685
INFO - 2018-05-19 06:34:46 --> Config Class Initialized
INFO - 2018-05-19 06:34:46 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:34:47 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:34:47 --> Utf8 Class Initialized
INFO - 2018-05-19 06:34:47 --> URI Class Initialized
INFO - 2018-05-19 06:34:47 --> Router Class Initialized
INFO - 2018-05-19 06:34:47 --> Output Class Initialized
INFO - 2018-05-19 06:34:47 --> Security Class Initialized
DEBUG - 2018-05-19 06:34:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:34:47 --> Input Class Initialized
INFO - 2018-05-19 06:34:47 --> Language Class Initialized
ERROR - 2018-05-19 06:34:47 --> 404 Page Not Found: /index
INFO - 2018-05-19 06:34:47 --> Config Class Initialized
INFO - 2018-05-19 06:34:47 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:34:47 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:34:47 --> Utf8 Class Initialized
INFO - 2018-05-19 06:34:47 --> URI Class Initialized
INFO - 2018-05-19 06:34:47 --> Router Class Initialized
INFO - 2018-05-19 06:34:47 --> Output Class Initialized
INFO - 2018-05-19 06:34:47 --> Security Class Initialized
DEBUG - 2018-05-19 06:34:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:34:47 --> Input Class Initialized
INFO - 2018-05-19 06:34:47 --> Language Class Initialized
ERROR - 2018-05-19 06:34:47 --> 404 Page Not Found: /index
INFO - 2018-05-19 06:34:50 --> Config Class Initialized
INFO - 2018-05-19 06:34:50 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:34:50 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:34:50 --> Utf8 Class Initialized
INFO - 2018-05-19 06:34:50 --> URI Class Initialized
INFO - 2018-05-19 06:34:50 --> Router Class Initialized
INFO - 2018-05-19 06:34:50 --> Output Class Initialized
INFO - 2018-05-19 06:34:50 --> Security Class Initialized
DEBUG - 2018-05-19 06:34:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:34:50 --> Input Class Initialized
INFO - 2018-05-19 06:34:50 --> Language Class Initialized
INFO - 2018-05-19 06:34:50 --> Language Class Initialized
INFO - 2018-05-19 06:34:50 --> Config Class Initialized
INFO - 2018-05-19 06:34:50 --> Loader Class Initialized
DEBUG - 2018-05-19 06:34:50 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-19 06:34:50 --> Helper loaded: url_helper
INFO - 2018-05-19 06:34:50 --> Helper loaded: form_helper
INFO - 2018-05-19 06:34:50 --> Helper loaded: date_helper
INFO - 2018-05-19 06:34:50 --> Helper loaded: util_helper
INFO - 2018-05-19 06:34:50 --> Helper loaded: text_helper
INFO - 2018-05-19 06:34:50 --> Helper loaded: string_helper
INFO - 2018-05-19 06:34:50 --> Database Driver Class Initialized
DEBUG - 2018-05-19 06:34:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-19 06:34:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-19 06:34:50 --> Email Class Initialized
INFO - 2018-05-19 06:34:50 --> Controller Class Initialized
DEBUG - 2018-05-19 06:34:50 --> videos MX_Controller Initialized
INFO - 2018-05-19 06:34:50 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-19 06:34:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-05-19 06:34:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-19 06:34:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-05-19 06:34:51 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-19 06:34:51 --> Login MX_Controller Initialized
DEBUG - 2018-05-19 06:34:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-19 06:34:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-05-19 06:34:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-05-19 06:34:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-05-19 06:34:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-05-19 06:34:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-05-19 06:34:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/videos/videos.php
INFO - 2018-05-19 06:34:51 --> Final output sent to browser
DEBUG - 2018-05-19 06:34:51 --> Total execution time: 0.9356
INFO - 2018-05-19 06:34:51 --> Config Class Initialized
INFO - 2018-05-19 06:34:51 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:34:51 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:34:51 --> Utf8 Class Initialized
INFO - 2018-05-19 06:34:51 --> URI Class Initialized
INFO - 2018-05-19 06:34:51 --> Router Class Initialized
INFO - 2018-05-19 06:34:51 --> Output Class Initialized
INFO - 2018-05-19 06:34:51 --> Security Class Initialized
DEBUG - 2018-05-19 06:34:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:34:52 --> Input Class Initialized
INFO - 2018-05-19 06:34:52 --> Language Class Initialized
INFO - 2018-05-19 06:34:52 --> Language Class Initialized
INFO - 2018-05-19 06:34:52 --> Config Class Initialized
INFO - 2018-05-19 06:34:52 --> Loader Class Initialized
DEBUG - 2018-05-19 06:34:52 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-19 06:34:52 --> Helper loaded: url_helper
INFO - 2018-05-19 06:34:52 --> Helper loaded: form_helper
INFO - 2018-05-19 06:34:52 --> Helper loaded: date_helper
INFO - 2018-05-19 06:34:52 --> Helper loaded: util_helper
INFO - 2018-05-19 06:34:52 --> Helper loaded: text_helper
INFO - 2018-05-19 06:34:52 --> Helper loaded: string_helper
INFO - 2018-05-19 06:34:52 --> Database Driver Class Initialized
DEBUG - 2018-05-19 06:34:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-19 06:34:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-19 06:34:52 --> Email Class Initialized
INFO - 2018-05-19 06:34:52 --> Controller Class Initialized
DEBUG - 2018-05-19 06:34:52 --> videos MX_Controller Initialized
INFO - 2018-05-19 06:34:52 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-19 06:34:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-05-19 06:34:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-19 06:34:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-05-19 06:34:53 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-19 06:34:53 --> Login MX_Controller Initialized
DEBUG - 2018-05-19 06:34:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-19 06:34:53 --> Final output sent to browser
DEBUG - 2018-05-19 06:34:53 --> Total execution time: 1.5142
INFO - 2018-05-19 06:35:01 --> Config Class Initialized
INFO - 2018-05-19 06:35:01 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:35:01 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:35:01 --> Utf8 Class Initialized
INFO - 2018-05-19 06:35:01 --> URI Class Initialized
INFO - 2018-05-19 06:35:01 --> Router Class Initialized
INFO - 2018-05-19 06:35:01 --> Output Class Initialized
INFO - 2018-05-19 06:35:01 --> Security Class Initialized
DEBUG - 2018-05-19 06:35:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:35:01 --> Input Class Initialized
INFO - 2018-05-19 06:35:01 --> Language Class Initialized
INFO - 2018-05-19 06:35:01 --> Language Class Initialized
INFO - 2018-05-19 06:35:01 --> Config Class Initialized
INFO - 2018-05-19 06:35:01 --> Loader Class Initialized
DEBUG - 2018-05-19 06:35:01 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-19 06:35:01 --> Helper loaded: url_helper
INFO - 2018-05-19 06:35:01 --> Helper loaded: form_helper
INFO - 2018-05-19 06:35:01 --> Helper loaded: date_helper
INFO - 2018-05-19 06:35:01 --> Helper loaded: util_helper
INFO - 2018-05-19 06:35:01 --> Helper loaded: text_helper
INFO - 2018-05-19 06:35:01 --> Helper loaded: string_helper
INFO - 2018-05-19 06:35:01 --> Database Driver Class Initialized
DEBUG - 2018-05-19 06:35:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-19 06:35:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-19 06:35:01 --> Email Class Initialized
INFO - 2018-05-19 06:35:01 --> Controller Class Initialized
DEBUG - 2018-05-19 06:35:01 --> videos MX_Controller Initialized
INFO - 2018-05-19 06:35:01 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-19 06:35:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-05-19 06:35:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-19 06:35:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-05-19 06:35:01 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-19 06:35:01 --> Login MX_Controller Initialized
DEBUG - 2018-05-19 06:35:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-19 06:35:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-05-19 06:35:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-05-19 06:35:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-05-19 06:35:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-05-19 06:35:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-05-19 06:35:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/videos/create_video.php
INFO - 2018-05-19 06:35:02 --> Final output sent to browser
DEBUG - 2018-05-19 06:35:02 --> Total execution time: 0.7873
INFO - 2018-05-19 06:35:10 --> Config Class Initialized
INFO - 2018-05-19 06:35:10 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:35:10 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:35:10 --> Utf8 Class Initialized
INFO - 2018-05-19 06:35:10 --> URI Class Initialized
INFO - 2018-05-19 06:35:10 --> Router Class Initialized
INFO - 2018-05-19 06:35:10 --> Output Class Initialized
INFO - 2018-05-19 06:35:10 --> Security Class Initialized
DEBUG - 2018-05-19 06:35:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:35:10 --> Input Class Initialized
INFO - 2018-05-19 06:35:10 --> Language Class Initialized
INFO - 2018-05-19 06:35:10 --> Language Class Initialized
INFO - 2018-05-19 06:35:10 --> Config Class Initialized
INFO - 2018-05-19 06:35:10 --> Loader Class Initialized
DEBUG - 2018-05-19 06:35:10 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-19 06:35:10 --> Helper loaded: url_helper
INFO - 2018-05-19 06:35:10 --> Helper loaded: form_helper
INFO - 2018-05-19 06:35:10 --> Helper loaded: date_helper
INFO - 2018-05-19 06:35:10 --> Helper loaded: util_helper
INFO - 2018-05-19 06:35:10 --> Helper loaded: text_helper
INFO - 2018-05-19 06:35:10 --> Helper loaded: string_helper
INFO - 2018-05-19 06:35:10 --> Database Driver Class Initialized
DEBUG - 2018-05-19 06:35:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-19 06:35:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-19 06:35:10 --> Email Class Initialized
INFO - 2018-05-19 06:35:10 --> Controller Class Initialized
DEBUG - 2018-05-19 06:35:10 --> videos MX_Controller Initialized
INFO - 2018-05-19 06:35:10 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-19 06:35:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-05-19 06:35:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-19 06:35:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-05-19 06:35:10 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-19 06:35:10 --> Login MX_Controller Initialized
DEBUG - 2018-05-19 06:35:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-19 06:35:11 --> Config Class Initialized
INFO - 2018-05-19 06:35:11 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:35:11 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:35:11 --> Utf8 Class Initialized
INFO - 2018-05-19 06:35:11 --> URI Class Initialized
INFO - 2018-05-19 06:35:11 --> Router Class Initialized
INFO - 2018-05-19 06:35:11 --> Output Class Initialized
INFO - 2018-05-19 06:35:11 --> Security Class Initialized
DEBUG - 2018-05-19 06:35:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:35:11 --> Input Class Initialized
INFO - 2018-05-19 06:35:11 --> Language Class Initialized
INFO - 2018-05-19 06:35:11 --> Language Class Initialized
INFO - 2018-05-19 06:35:11 --> Config Class Initialized
INFO - 2018-05-19 06:35:11 --> Loader Class Initialized
DEBUG - 2018-05-19 06:35:11 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-19 06:35:11 --> Helper loaded: url_helper
INFO - 2018-05-19 06:35:11 --> Helper loaded: form_helper
INFO - 2018-05-19 06:35:11 --> Helper loaded: date_helper
INFO - 2018-05-19 06:35:11 --> Helper loaded: util_helper
INFO - 2018-05-19 06:35:11 --> Helper loaded: text_helper
INFO - 2018-05-19 06:35:11 --> Helper loaded: string_helper
INFO - 2018-05-19 06:35:11 --> Database Driver Class Initialized
DEBUG - 2018-05-19 06:35:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-19 06:35:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-19 06:35:11 --> Email Class Initialized
INFO - 2018-05-19 06:35:11 --> Controller Class Initialized
DEBUG - 2018-05-19 06:35:11 --> videos MX_Controller Initialized
INFO - 2018-05-19 06:35:11 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-19 06:35:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-05-19 06:35:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-19 06:35:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-05-19 06:35:11 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-19 06:35:11 --> Login MX_Controller Initialized
DEBUG - 2018-05-19 06:35:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-19 06:35:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-05-19 06:35:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-05-19 06:35:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-05-19 06:35:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-05-19 06:35:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-05-19 06:35:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/videos/videos.php
INFO - 2018-05-19 06:35:11 --> Final output sent to browser
DEBUG - 2018-05-19 06:35:11 --> Total execution time: 0.8097
INFO - 2018-05-19 06:35:12 --> Config Class Initialized
INFO - 2018-05-19 06:35:12 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:35:12 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:35:12 --> Utf8 Class Initialized
INFO - 2018-05-19 06:35:12 --> URI Class Initialized
INFO - 2018-05-19 06:35:12 --> Router Class Initialized
INFO - 2018-05-19 06:35:12 --> Output Class Initialized
INFO - 2018-05-19 06:35:12 --> Security Class Initialized
DEBUG - 2018-05-19 06:35:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:35:12 --> Input Class Initialized
INFO - 2018-05-19 06:35:12 --> Language Class Initialized
INFO - 2018-05-19 06:35:12 --> Language Class Initialized
INFO - 2018-05-19 06:35:12 --> Config Class Initialized
INFO - 2018-05-19 06:35:12 --> Loader Class Initialized
DEBUG - 2018-05-19 06:35:12 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-19 06:35:12 --> Helper loaded: url_helper
INFO - 2018-05-19 06:35:12 --> Helper loaded: form_helper
INFO - 2018-05-19 06:35:12 --> Helper loaded: date_helper
INFO - 2018-05-19 06:35:12 --> Helper loaded: util_helper
INFO - 2018-05-19 06:35:12 --> Helper loaded: text_helper
INFO - 2018-05-19 06:35:12 --> Helper loaded: string_helper
INFO - 2018-05-19 06:35:12 --> Database Driver Class Initialized
DEBUG - 2018-05-19 06:35:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-19 06:35:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-19 06:35:12 --> Email Class Initialized
INFO - 2018-05-19 06:35:12 --> Controller Class Initialized
DEBUG - 2018-05-19 06:35:12 --> videos MX_Controller Initialized
INFO - 2018-05-19 06:35:13 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-19 06:35:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-05-19 06:35:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-19 06:35:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-05-19 06:35:13 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-19 06:35:13 --> Login MX_Controller Initialized
DEBUG - 2018-05-19 06:35:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-19 06:35:13 --> Final output sent to browser
DEBUG - 2018-05-19 06:35:13 --> Total execution time: 0.7792
INFO - 2018-05-19 06:35:40 --> Config Class Initialized
INFO - 2018-05-19 06:35:41 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:35:41 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:35:41 --> Utf8 Class Initialized
INFO - 2018-05-19 06:35:41 --> URI Class Initialized
INFO - 2018-05-19 06:35:41 --> Router Class Initialized
INFO - 2018-05-19 06:35:41 --> Output Class Initialized
INFO - 2018-05-19 06:35:41 --> Security Class Initialized
DEBUG - 2018-05-19 06:35:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:35:41 --> Input Class Initialized
INFO - 2018-05-19 06:35:41 --> Language Class Initialized
INFO - 2018-05-19 06:35:41 --> Language Class Initialized
INFO - 2018-05-19 06:35:41 --> Config Class Initialized
INFO - 2018-05-19 06:35:41 --> Loader Class Initialized
DEBUG - 2018-05-19 06:35:41 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-19 06:35:41 --> Helper loaded: url_helper
INFO - 2018-05-19 06:35:41 --> Helper loaded: form_helper
INFO - 2018-05-19 06:35:41 --> Helper loaded: date_helper
INFO - 2018-05-19 06:35:41 --> Helper loaded: util_helper
INFO - 2018-05-19 06:35:41 --> Helper loaded: text_helper
INFO - 2018-05-19 06:35:41 --> Helper loaded: string_helper
INFO - 2018-05-19 06:35:41 --> Database Driver Class Initialized
DEBUG - 2018-05-19 06:35:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-19 06:35:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-19 06:35:41 --> Email Class Initialized
INFO - 2018-05-19 06:35:41 --> Controller Class Initialized
DEBUG - 2018-05-19 06:35:41 --> videos MX_Controller Initialized
INFO - 2018-05-19 06:35:41 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-19 06:35:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-05-19 06:35:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-19 06:35:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-05-19 06:35:41 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-19 06:35:41 --> Login MX_Controller Initialized
DEBUG - 2018-05-19 06:35:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-19 06:35:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-05-19 06:35:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-05-19 06:35:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-05-19 06:35:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-05-19 06:35:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-05-19 06:35:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/videos/create_video.php
INFO - 2018-05-19 06:35:41 --> Final output sent to browser
DEBUG - 2018-05-19 06:35:41 --> Total execution time: 0.7149
INFO - 2018-05-19 06:35:43 --> Config Class Initialized
INFO - 2018-05-19 06:35:43 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:35:43 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:35:43 --> Utf8 Class Initialized
INFO - 2018-05-19 06:35:43 --> URI Class Initialized
INFO - 2018-05-19 06:35:43 --> Router Class Initialized
INFO - 2018-05-19 06:35:43 --> Output Class Initialized
INFO - 2018-05-19 06:35:43 --> Security Class Initialized
DEBUG - 2018-05-19 06:35:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:35:43 --> Input Class Initialized
INFO - 2018-05-19 06:35:43 --> Language Class Initialized
INFO - 2018-05-19 06:35:43 --> Language Class Initialized
INFO - 2018-05-19 06:35:43 --> Config Class Initialized
INFO - 2018-05-19 06:35:43 --> Loader Class Initialized
DEBUG - 2018-05-19 06:35:43 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-19 06:35:43 --> Helper loaded: url_helper
INFO - 2018-05-19 06:35:43 --> Helper loaded: form_helper
INFO - 2018-05-19 06:35:43 --> Helper loaded: date_helper
INFO - 2018-05-19 06:35:43 --> Helper loaded: util_helper
INFO - 2018-05-19 06:35:43 --> Helper loaded: text_helper
INFO - 2018-05-19 06:35:43 --> Helper loaded: string_helper
INFO - 2018-05-19 06:35:43 --> Database Driver Class Initialized
DEBUG - 2018-05-19 06:35:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-19 06:35:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-19 06:35:43 --> Email Class Initialized
INFO - 2018-05-19 06:35:43 --> Controller Class Initialized
DEBUG - 2018-05-19 06:35:43 --> videos MX_Controller Initialized
INFO - 2018-05-19 06:35:43 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-19 06:35:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-05-19 06:35:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-19 06:35:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-05-19 06:35:43 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-19 06:35:43 --> Login MX_Controller Initialized
DEBUG - 2018-05-19 06:35:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-19 06:35:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-05-19 06:35:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-05-19 06:35:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-05-19 06:35:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-05-19 06:35:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-05-19 06:35:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/videos/videos.php
INFO - 2018-05-19 06:35:43 --> Final output sent to browser
DEBUG - 2018-05-19 06:35:43 --> Total execution time: 0.7107
INFO - 2018-05-19 06:35:44 --> Config Class Initialized
INFO - 2018-05-19 06:35:44 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:35:44 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:35:44 --> Utf8 Class Initialized
INFO - 2018-05-19 06:35:44 --> URI Class Initialized
INFO - 2018-05-19 06:35:44 --> Router Class Initialized
INFO - 2018-05-19 06:35:44 --> Output Class Initialized
INFO - 2018-05-19 06:35:44 --> Security Class Initialized
DEBUG - 2018-05-19 06:35:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:35:44 --> Input Class Initialized
INFO - 2018-05-19 06:35:44 --> Language Class Initialized
INFO - 2018-05-19 06:35:44 --> Language Class Initialized
INFO - 2018-05-19 06:35:44 --> Config Class Initialized
INFO - 2018-05-19 06:35:44 --> Loader Class Initialized
DEBUG - 2018-05-19 06:35:44 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-19 06:35:44 --> Helper loaded: url_helper
INFO - 2018-05-19 06:35:44 --> Helper loaded: form_helper
INFO - 2018-05-19 06:35:44 --> Helper loaded: date_helper
INFO - 2018-05-19 06:35:44 --> Helper loaded: util_helper
INFO - 2018-05-19 06:35:44 --> Helper loaded: text_helper
INFO - 2018-05-19 06:35:44 --> Helper loaded: string_helper
INFO - 2018-05-19 06:35:44 --> Database Driver Class Initialized
DEBUG - 2018-05-19 06:35:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-19 06:35:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-19 06:35:44 --> Email Class Initialized
INFO - 2018-05-19 06:35:44 --> Controller Class Initialized
DEBUG - 2018-05-19 06:35:44 --> videos MX_Controller Initialized
INFO - 2018-05-19 06:35:44 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-19 06:35:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-05-19 06:35:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-19 06:35:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-05-19 06:35:44 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-19 06:35:44 --> Login MX_Controller Initialized
DEBUG - 2018-05-19 06:35:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-19 06:35:45 --> Final output sent to browser
DEBUG - 2018-05-19 06:35:45 --> Total execution time: 0.7915
INFO - 2018-05-19 06:35:47 --> Config Class Initialized
INFO - 2018-05-19 06:35:47 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:35:47 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:35:47 --> Utf8 Class Initialized
INFO - 2018-05-19 06:35:47 --> URI Class Initialized
INFO - 2018-05-19 06:35:47 --> Router Class Initialized
INFO - 2018-05-19 06:35:47 --> Output Class Initialized
INFO - 2018-05-19 06:35:47 --> Security Class Initialized
DEBUG - 2018-05-19 06:35:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:35:47 --> Input Class Initialized
INFO - 2018-05-19 06:35:47 --> Language Class Initialized
INFO - 2018-05-19 06:35:47 --> Language Class Initialized
INFO - 2018-05-19 06:35:47 --> Config Class Initialized
INFO - 2018-05-19 06:35:47 --> Loader Class Initialized
DEBUG - 2018-05-19 06:35:47 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-19 06:35:47 --> Helper loaded: url_helper
INFO - 2018-05-19 06:35:47 --> Helper loaded: form_helper
INFO - 2018-05-19 06:35:47 --> Helper loaded: date_helper
INFO - 2018-05-19 06:35:47 --> Helper loaded: util_helper
INFO - 2018-05-19 06:35:47 --> Helper loaded: text_helper
INFO - 2018-05-19 06:35:47 --> Helper loaded: string_helper
INFO - 2018-05-19 06:35:47 --> Database Driver Class Initialized
DEBUG - 2018-05-19 06:35:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-19 06:35:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-19 06:35:47 --> Email Class Initialized
INFO - 2018-05-19 06:35:47 --> Controller Class Initialized
DEBUG - 2018-05-19 06:35:47 --> videos MX_Controller Initialized
INFO - 2018-05-19 06:35:47 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-19 06:35:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-05-19 06:35:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-19 06:35:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-05-19 06:35:48 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-19 06:35:48 --> Login MX_Controller Initialized
DEBUG - 2018-05-19 06:35:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-19 06:35:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-05-19 06:35:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-05-19 06:35:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-05-19 06:35:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-05-19 06:35:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-05-19 06:35:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/videos/create_video.php
INFO - 2018-05-19 06:35:48 --> Final output sent to browser
DEBUG - 2018-05-19 06:35:48 --> Total execution time: 0.7200
INFO - 2018-05-19 06:35:52 --> Config Class Initialized
INFO - 2018-05-19 06:35:52 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:35:52 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:35:52 --> Utf8 Class Initialized
INFO - 2018-05-19 06:35:52 --> URI Class Initialized
INFO - 2018-05-19 06:35:52 --> Router Class Initialized
INFO - 2018-05-19 06:35:52 --> Output Class Initialized
INFO - 2018-05-19 06:35:52 --> Security Class Initialized
DEBUG - 2018-05-19 06:35:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:35:52 --> Input Class Initialized
INFO - 2018-05-19 06:35:52 --> Language Class Initialized
INFO - 2018-05-19 06:35:52 --> Language Class Initialized
INFO - 2018-05-19 06:35:52 --> Config Class Initialized
INFO - 2018-05-19 06:35:52 --> Loader Class Initialized
DEBUG - 2018-05-19 06:35:52 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-19 06:35:52 --> Helper loaded: url_helper
INFO - 2018-05-19 06:35:52 --> Helper loaded: form_helper
INFO - 2018-05-19 06:35:52 --> Helper loaded: date_helper
INFO - 2018-05-19 06:35:52 --> Helper loaded: util_helper
INFO - 2018-05-19 06:35:52 --> Helper loaded: text_helper
INFO - 2018-05-19 06:35:52 --> Helper loaded: string_helper
INFO - 2018-05-19 06:35:52 --> Database Driver Class Initialized
DEBUG - 2018-05-19 06:35:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-19 06:35:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-19 06:35:52 --> Email Class Initialized
INFO - 2018-05-19 06:35:52 --> Controller Class Initialized
DEBUG - 2018-05-19 06:35:52 --> videos MX_Controller Initialized
INFO - 2018-05-19 06:35:53 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-19 06:35:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-05-19 06:35:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-19 06:35:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-05-19 06:35:53 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-19 06:35:53 --> Login MX_Controller Initialized
DEBUG - 2018-05-19 06:35:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-19 06:35:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-05-19 06:35:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-05-19 06:35:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-05-19 06:35:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-05-19 06:35:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-05-19 06:35:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/videos/videos.php
INFO - 2018-05-19 06:35:53 --> Final output sent to browser
DEBUG - 2018-05-19 06:35:53 --> Total execution time: 0.9553
INFO - 2018-05-19 06:35:53 --> Config Class Initialized
INFO - 2018-05-19 06:35:53 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:35:53 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:35:53 --> Utf8 Class Initialized
INFO - 2018-05-19 06:35:53 --> URI Class Initialized
INFO - 2018-05-19 06:35:53 --> Router Class Initialized
INFO - 2018-05-19 06:35:53 --> Output Class Initialized
INFO - 2018-05-19 06:35:53 --> Security Class Initialized
DEBUG - 2018-05-19 06:35:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:35:53 --> Input Class Initialized
INFO - 2018-05-19 06:35:53 --> Language Class Initialized
INFO - 2018-05-19 06:35:53 --> Language Class Initialized
INFO - 2018-05-19 06:35:53 --> Config Class Initialized
INFO - 2018-05-19 06:35:53 --> Loader Class Initialized
DEBUG - 2018-05-19 06:35:53 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-19 06:35:53 --> Helper loaded: url_helper
INFO - 2018-05-19 06:35:53 --> Helper loaded: form_helper
INFO - 2018-05-19 06:35:53 --> Helper loaded: date_helper
INFO - 2018-05-19 06:35:54 --> Helper loaded: util_helper
INFO - 2018-05-19 06:35:54 --> Helper loaded: text_helper
INFO - 2018-05-19 06:35:54 --> Helper loaded: string_helper
INFO - 2018-05-19 06:35:54 --> Database Driver Class Initialized
DEBUG - 2018-05-19 06:35:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-19 06:35:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-19 06:35:54 --> Email Class Initialized
INFO - 2018-05-19 06:35:54 --> Controller Class Initialized
DEBUG - 2018-05-19 06:35:54 --> videos MX_Controller Initialized
INFO - 2018-05-19 06:35:54 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-19 06:35:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-05-19 06:35:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-19 06:35:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-05-19 06:35:54 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-19 06:35:54 --> Login MX_Controller Initialized
DEBUG - 2018-05-19 06:35:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-19 06:35:54 --> Final output sent to browser
DEBUG - 2018-05-19 06:35:54 --> Total execution time: 0.7656
INFO - 2018-05-19 06:35:55 --> Config Class Initialized
INFO - 2018-05-19 06:35:55 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:35:55 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:35:55 --> Utf8 Class Initialized
INFO - 2018-05-19 06:35:55 --> URI Class Initialized
INFO - 2018-05-19 06:35:55 --> Router Class Initialized
INFO - 2018-05-19 06:35:55 --> Output Class Initialized
INFO - 2018-05-19 06:35:55 --> Security Class Initialized
DEBUG - 2018-05-19 06:35:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:35:55 --> Input Class Initialized
INFO - 2018-05-19 06:35:55 --> Language Class Initialized
INFO - 2018-05-19 06:35:55 --> Language Class Initialized
INFO - 2018-05-19 06:35:55 --> Config Class Initialized
INFO - 2018-05-19 06:35:55 --> Loader Class Initialized
DEBUG - 2018-05-19 06:35:55 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-19 06:35:55 --> Helper loaded: url_helper
INFO - 2018-05-19 06:35:55 --> Helper loaded: form_helper
INFO - 2018-05-19 06:35:55 --> Helper loaded: date_helper
INFO - 2018-05-19 06:35:55 --> Helper loaded: util_helper
INFO - 2018-05-19 06:35:55 --> Helper loaded: text_helper
INFO - 2018-05-19 06:35:55 --> Helper loaded: string_helper
INFO - 2018-05-19 06:35:55 --> Database Driver Class Initialized
DEBUG - 2018-05-19 06:35:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-19 06:35:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-19 06:35:55 --> Email Class Initialized
INFO - 2018-05-19 06:35:55 --> Controller Class Initialized
DEBUG - 2018-05-19 06:35:55 --> videos MX_Controller Initialized
INFO - 2018-05-19 06:35:55 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-19 06:35:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-05-19 06:35:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-19 06:35:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-05-19 06:35:55 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-19 06:35:56 --> Login MX_Controller Initialized
DEBUG - 2018-05-19 06:35:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-19 06:35:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-05-19 06:35:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-05-19 06:35:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-05-19 06:35:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-05-19 06:35:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-05-19 06:35:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/videos/create_video.php
INFO - 2018-05-19 06:35:56 --> Final output sent to browser
DEBUG - 2018-05-19 06:35:56 --> Total execution time: 0.7377
INFO - 2018-05-19 06:36:02 --> Config Class Initialized
INFO - 2018-05-19 06:36:02 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:36:02 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:36:02 --> Utf8 Class Initialized
INFO - 2018-05-19 06:36:02 --> URI Class Initialized
INFO - 2018-05-19 06:36:02 --> Router Class Initialized
INFO - 2018-05-19 06:36:02 --> Output Class Initialized
INFO - 2018-05-19 06:36:02 --> Security Class Initialized
DEBUG - 2018-05-19 06:36:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:36:02 --> Input Class Initialized
INFO - 2018-05-19 06:36:02 --> Language Class Initialized
INFO - 2018-05-19 06:36:02 --> Language Class Initialized
INFO - 2018-05-19 06:36:02 --> Config Class Initialized
INFO - 2018-05-19 06:36:02 --> Loader Class Initialized
DEBUG - 2018-05-19 06:36:02 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-19 06:36:02 --> Helper loaded: url_helper
INFO - 2018-05-19 06:36:02 --> Helper loaded: form_helper
INFO - 2018-05-19 06:36:02 --> Helper loaded: date_helper
INFO - 2018-05-19 06:36:02 --> Helper loaded: util_helper
INFO - 2018-05-19 06:36:02 --> Helper loaded: text_helper
INFO - 2018-05-19 06:36:02 --> Helper loaded: string_helper
INFO - 2018-05-19 06:36:02 --> Database Driver Class Initialized
DEBUG - 2018-05-19 06:36:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-19 06:36:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-19 06:36:02 --> Email Class Initialized
INFO - 2018-05-19 06:36:02 --> Controller Class Initialized
DEBUG - 2018-05-19 06:36:02 --> videos MX_Controller Initialized
INFO - 2018-05-19 06:36:02 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-19 06:36:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-05-19 06:36:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-19 06:36:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-05-19 06:36:02 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-19 06:36:02 --> Login MX_Controller Initialized
DEBUG - 2018-05-19 06:36:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-19 06:36:02 --> Config Class Initialized
INFO - 2018-05-19 06:36:02 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:36:02 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:36:02 --> Utf8 Class Initialized
INFO - 2018-05-19 06:36:02 --> URI Class Initialized
INFO - 2018-05-19 06:36:02 --> Router Class Initialized
INFO - 2018-05-19 06:36:02 --> Output Class Initialized
INFO - 2018-05-19 06:36:02 --> Security Class Initialized
DEBUG - 2018-05-19 06:36:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:36:02 --> Input Class Initialized
INFO - 2018-05-19 06:36:02 --> Language Class Initialized
INFO - 2018-05-19 06:36:03 --> Language Class Initialized
INFO - 2018-05-19 06:36:03 --> Config Class Initialized
INFO - 2018-05-19 06:36:03 --> Loader Class Initialized
DEBUG - 2018-05-19 06:36:03 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-19 06:36:03 --> Helper loaded: url_helper
INFO - 2018-05-19 06:36:03 --> Helper loaded: form_helper
INFO - 2018-05-19 06:36:03 --> Helper loaded: date_helper
INFO - 2018-05-19 06:36:03 --> Helper loaded: util_helper
INFO - 2018-05-19 06:36:03 --> Helper loaded: text_helper
INFO - 2018-05-19 06:36:03 --> Helper loaded: string_helper
INFO - 2018-05-19 06:36:03 --> Database Driver Class Initialized
DEBUG - 2018-05-19 06:36:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-19 06:36:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-19 06:36:03 --> Email Class Initialized
INFO - 2018-05-19 06:36:03 --> Controller Class Initialized
DEBUG - 2018-05-19 06:36:03 --> videos MX_Controller Initialized
INFO - 2018-05-19 06:36:03 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-19 06:36:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-05-19 06:36:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-19 06:36:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-05-19 06:36:03 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-19 06:36:03 --> Login MX_Controller Initialized
DEBUG - 2018-05-19 06:36:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-19 06:36:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-05-19 06:36:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-05-19 06:36:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-05-19 06:36:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-05-19 06:36:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-05-19 06:36:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/videos/videos.php
INFO - 2018-05-19 06:36:03 --> Final output sent to browser
DEBUG - 2018-05-19 06:36:03 --> Total execution time: 0.7725
INFO - 2018-05-19 06:36:03 --> Config Class Initialized
INFO - 2018-05-19 06:36:03 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:36:03 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:36:03 --> Utf8 Class Initialized
INFO - 2018-05-19 06:36:04 --> URI Class Initialized
INFO - 2018-05-19 06:36:04 --> Router Class Initialized
INFO - 2018-05-19 06:36:04 --> Output Class Initialized
INFO - 2018-05-19 06:36:04 --> Security Class Initialized
DEBUG - 2018-05-19 06:36:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:36:04 --> Input Class Initialized
INFO - 2018-05-19 06:36:04 --> Language Class Initialized
INFO - 2018-05-19 06:36:04 --> Language Class Initialized
INFO - 2018-05-19 06:36:04 --> Config Class Initialized
INFO - 2018-05-19 06:36:04 --> Loader Class Initialized
DEBUG - 2018-05-19 06:36:04 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-19 06:36:04 --> Helper loaded: url_helper
INFO - 2018-05-19 06:36:04 --> Helper loaded: form_helper
INFO - 2018-05-19 06:36:04 --> Helper loaded: date_helper
INFO - 2018-05-19 06:36:04 --> Helper loaded: util_helper
INFO - 2018-05-19 06:36:04 --> Helper loaded: text_helper
INFO - 2018-05-19 06:36:04 --> Helper loaded: string_helper
INFO - 2018-05-19 06:36:04 --> Database Driver Class Initialized
DEBUG - 2018-05-19 06:36:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-19 06:36:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-19 06:36:04 --> Email Class Initialized
INFO - 2018-05-19 06:36:04 --> Controller Class Initialized
DEBUG - 2018-05-19 06:36:04 --> videos MX_Controller Initialized
INFO - 2018-05-19 06:36:04 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-19 06:36:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-05-19 06:36:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-19 06:36:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-05-19 06:36:04 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-19 06:36:04 --> Login MX_Controller Initialized
DEBUG - 2018-05-19 06:36:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-19 06:36:04 --> Final output sent to browser
DEBUG - 2018-05-19 06:36:04 --> Total execution time: 0.7270
INFO - 2018-05-19 06:36:06 --> Config Class Initialized
INFO - 2018-05-19 06:36:06 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:36:06 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:36:06 --> Utf8 Class Initialized
INFO - 2018-05-19 06:36:06 --> URI Class Initialized
INFO - 2018-05-19 06:36:06 --> Router Class Initialized
INFO - 2018-05-19 06:36:06 --> Output Class Initialized
INFO - 2018-05-19 06:36:06 --> Security Class Initialized
DEBUG - 2018-05-19 06:36:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:36:06 --> Input Class Initialized
INFO - 2018-05-19 06:36:06 --> Language Class Initialized
INFO - 2018-05-19 06:36:06 --> Language Class Initialized
INFO - 2018-05-19 06:36:06 --> Config Class Initialized
INFO - 2018-05-19 06:36:06 --> Loader Class Initialized
DEBUG - 2018-05-19 06:36:06 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-19 06:36:06 --> Helper loaded: url_helper
INFO - 2018-05-19 06:36:06 --> Helper loaded: form_helper
INFO - 2018-05-19 06:36:06 --> Helper loaded: date_helper
INFO - 2018-05-19 06:36:06 --> Helper loaded: util_helper
INFO - 2018-05-19 06:36:06 --> Helper loaded: text_helper
INFO - 2018-05-19 06:36:06 --> Helper loaded: string_helper
INFO - 2018-05-19 06:36:06 --> Database Driver Class Initialized
DEBUG - 2018-05-19 06:36:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-19 06:36:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-19 06:36:06 --> Email Class Initialized
INFO - 2018-05-19 06:36:06 --> Controller Class Initialized
DEBUG - 2018-05-19 06:36:06 --> videos MX_Controller Initialized
INFO - 2018-05-19 06:36:06 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-19 06:36:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-05-19 06:36:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-19 06:36:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-05-19 06:36:06 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-19 06:36:06 --> Login MX_Controller Initialized
DEBUG - 2018-05-19 06:36:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-19 06:36:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-05-19 06:36:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-05-19 06:36:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-05-19 06:36:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-05-19 06:36:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-05-19 06:36:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/videos/create_video.php
INFO - 2018-05-19 06:36:06 --> Final output sent to browser
DEBUG - 2018-05-19 06:36:06 --> Total execution time: 0.7418
INFO - 2018-05-19 06:36:10 --> Config Class Initialized
INFO - 2018-05-19 06:36:10 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:36:10 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:36:10 --> Utf8 Class Initialized
INFO - 2018-05-19 06:36:10 --> URI Class Initialized
INFO - 2018-05-19 06:36:10 --> Router Class Initialized
INFO - 2018-05-19 06:36:10 --> Output Class Initialized
INFO - 2018-05-19 06:36:10 --> Security Class Initialized
DEBUG - 2018-05-19 06:36:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:36:10 --> Input Class Initialized
INFO - 2018-05-19 06:36:10 --> Language Class Initialized
INFO - 2018-05-19 06:36:10 --> Language Class Initialized
INFO - 2018-05-19 06:36:10 --> Config Class Initialized
INFO - 2018-05-19 06:36:10 --> Loader Class Initialized
DEBUG - 2018-05-19 06:36:10 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-19 06:36:10 --> Helper loaded: url_helper
INFO - 2018-05-19 06:36:11 --> Helper loaded: form_helper
INFO - 2018-05-19 06:36:11 --> Helper loaded: date_helper
INFO - 2018-05-19 06:36:11 --> Helper loaded: util_helper
INFO - 2018-05-19 06:36:11 --> Helper loaded: text_helper
INFO - 2018-05-19 06:36:11 --> Helper loaded: string_helper
INFO - 2018-05-19 06:36:11 --> Database Driver Class Initialized
DEBUG - 2018-05-19 06:36:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-19 06:36:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-19 06:36:11 --> Email Class Initialized
INFO - 2018-05-19 06:36:11 --> Controller Class Initialized
DEBUG - 2018-05-19 06:36:11 --> videos MX_Controller Initialized
INFO - 2018-05-19 06:36:11 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-19 06:36:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-05-19 06:36:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-19 06:36:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-05-19 06:36:11 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-19 06:36:11 --> Login MX_Controller Initialized
DEBUG - 2018-05-19 06:36:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-19 06:36:11 --> Config Class Initialized
INFO - 2018-05-19 06:36:11 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:36:11 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:36:11 --> Utf8 Class Initialized
INFO - 2018-05-19 06:36:11 --> URI Class Initialized
INFO - 2018-05-19 06:36:11 --> Router Class Initialized
INFO - 2018-05-19 06:36:11 --> Output Class Initialized
INFO - 2018-05-19 06:36:11 --> Security Class Initialized
DEBUG - 2018-05-19 06:36:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:36:11 --> Input Class Initialized
INFO - 2018-05-19 06:36:11 --> Language Class Initialized
INFO - 2018-05-19 06:36:11 --> Language Class Initialized
INFO - 2018-05-19 06:36:11 --> Config Class Initialized
INFO - 2018-05-19 06:36:11 --> Loader Class Initialized
DEBUG - 2018-05-19 06:36:11 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-19 06:36:11 --> Helper loaded: url_helper
INFO - 2018-05-19 06:36:11 --> Helper loaded: form_helper
INFO - 2018-05-19 06:36:11 --> Helper loaded: date_helper
INFO - 2018-05-19 06:36:11 --> Helper loaded: util_helper
INFO - 2018-05-19 06:36:11 --> Helper loaded: text_helper
INFO - 2018-05-19 06:36:11 --> Helper loaded: string_helper
INFO - 2018-05-19 06:36:11 --> Database Driver Class Initialized
DEBUG - 2018-05-19 06:36:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-19 06:36:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-19 06:36:11 --> Email Class Initialized
INFO - 2018-05-19 06:36:11 --> Controller Class Initialized
DEBUG - 2018-05-19 06:36:11 --> videos MX_Controller Initialized
INFO - 2018-05-19 06:36:11 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-19 06:36:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-05-19 06:36:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-19 06:36:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-05-19 06:36:12 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-19 06:36:12 --> Login MX_Controller Initialized
DEBUG - 2018-05-19 06:36:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-19 06:36:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-05-19 06:36:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-05-19 06:36:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-05-19 06:36:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-05-19 06:36:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-05-19 06:36:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/videos/videos.php
INFO - 2018-05-19 06:36:12 --> Final output sent to browser
DEBUG - 2018-05-19 06:36:12 --> Total execution time: 0.8048
INFO - 2018-05-19 06:36:12 --> Config Class Initialized
INFO - 2018-05-19 06:36:12 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:36:12 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:36:12 --> Utf8 Class Initialized
INFO - 2018-05-19 06:36:12 --> URI Class Initialized
INFO - 2018-05-19 06:36:12 --> Router Class Initialized
INFO - 2018-05-19 06:36:12 --> Output Class Initialized
INFO - 2018-05-19 06:36:12 --> Security Class Initialized
DEBUG - 2018-05-19 06:36:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:36:12 --> Input Class Initialized
INFO - 2018-05-19 06:36:12 --> Language Class Initialized
INFO - 2018-05-19 06:36:12 --> Language Class Initialized
INFO - 2018-05-19 06:36:12 --> Config Class Initialized
INFO - 2018-05-19 06:36:12 --> Loader Class Initialized
DEBUG - 2018-05-19 06:36:12 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-19 06:36:12 --> Helper loaded: url_helper
INFO - 2018-05-19 06:36:12 --> Helper loaded: form_helper
INFO - 2018-05-19 06:36:12 --> Helper loaded: date_helper
INFO - 2018-05-19 06:36:12 --> Helper loaded: util_helper
INFO - 2018-05-19 06:36:13 --> Helper loaded: text_helper
INFO - 2018-05-19 06:36:13 --> Helper loaded: string_helper
INFO - 2018-05-19 06:36:13 --> Database Driver Class Initialized
DEBUG - 2018-05-19 06:36:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-19 06:36:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-19 06:36:13 --> Email Class Initialized
INFO - 2018-05-19 06:36:13 --> Controller Class Initialized
DEBUG - 2018-05-19 06:36:13 --> videos MX_Controller Initialized
INFO - 2018-05-19 06:36:13 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-19 06:36:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-05-19 06:36:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-19 06:36:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-05-19 06:36:13 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-19 06:36:13 --> Login MX_Controller Initialized
DEBUG - 2018-05-19 06:36:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-19 06:36:13 --> Final output sent to browser
DEBUG - 2018-05-19 06:36:13 --> Total execution time: 0.7678
INFO - 2018-05-19 06:36:52 --> Config Class Initialized
INFO - 2018-05-19 06:36:52 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:36:52 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:36:52 --> Utf8 Class Initialized
INFO - 2018-05-19 06:36:52 --> URI Class Initialized
INFO - 2018-05-19 06:36:52 --> Router Class Initialized
INFO - 2018-05-19 06:36:52 --> Output Class Initialized
INFO - 2018-05-19 06:36:52 --> Security Class Initialized
DEBUG - 2018-05-19 06:36:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:36:53 --> Input Class Initialized
INFO - 2018-05-19 06:36:53 --> Language Class Initialized
INFO - 2018-05-19 06:36:53 --> Language Class Initialized
INFO - 2018-05-19 06:36:53 --> Config Class Initialized
INFO - 2018-05-19 06:36:53 --> Loader Class Initialized
DEBUG - 2018-05-19 06:36:53 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-19 06:36:53 --> Helper loaded: url_helper
INFO - 2018-05-19 06:36:53 --> Helper loaded: form_helper
INFO - 2018-05-19 06:36:53 --> Helper loaded: date_helper
INFO - 2018-05-19 06:36:53 --> Helper loaded: util_helper
INFO - 2018-05-19 06:36:53 --> Helper loaded: text_helper
INFO - 2018-05-19 06:36:53 --> Helper loaded: string_helper
INFO - 2018-05-19 06:36:53 --> Database Driver Class Initialized
DEBUG - 2018-05-19 06:36:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-19 06:36:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-19 06:36:53 --> Email Class Initialized
INFO - 2018-05-19 06:36:53 --> Controller Class Initialized
DEBUG - 2018-05-19 06:36:53 --> videos MX_Controller Initialized
INFO - 2018-05-19 06:36:53 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-19 06:36:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-05-19 06:36:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-19 06:36:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-05-19 06:36:53 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-19 06:36:53 --> Login MX_Controller Initialized
DEBUG - 2018-05-19 06:36:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-19 06:36:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-05-19 06:36:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-05-19 06:36:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-05-19 06:36:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-05-19 06:36:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-05-19 06:36:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/videos/create_video.php
INFO - 2018-05-19 06:36:53 --> Final output sent to browser
DEBUG - 2018-05-19 06:36:53 --> Total execution time: 0.8624
INFO - 2018-05-19 06:37:34 --> Config Class Initialized
INFO - 2018-05-19 06:37:34 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:37:34 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:37:34 --> Utf8 Class Initialized
INFO - 2018-05-19 06:37:34 --> URI Class Initialized
INFO - 2018-05-19 06:37:34 --> Router Class Initialized
INFO - 2018-05-19 06:37:34 --> Output Class Initialized
INFO - 2018-05-19 06:37:34 --> Security Class Initialized
DEBUG - 2018-05-19 06:37:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:37:34 --> Input Class Initialized
INFO - 2018-05-19 06:37:34 --> Language Class Initialized
INFO - 2018-05-19 06:37:34 --> Language Class Initialized
INFO - 2018-05-19 06:37:34 --> Config Class Initialized
INFO - 2018-05-19 06:37:34 --> Loader Class Initialized
DEBUG - 2018-05-19 06:37:34 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-19 06:37:34 --> Helper loaded: url_helper
INFO - 2018-05-19 06:37:34 --> Helper loaded: form_helper
INFO - 2018-05-19 06:37:34 --> Helper loaded: date_helper
INFO - 2018-05-19 06:37:34 --> Helper loaded: util_helper
INFO - 2018-05-19 06:37:34 --> Helper loaded: text_helper
INFO - 2018-05-19 06:37:34 --> Helper loaded: string_helper
INFO - 2018-05-19 06:37:34 --> Database Driver Class Initialized
DEBUG - 2018-05-19 06:37:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-19 06:37:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-19 06:37:34 --> Email Class Initialized
INFO - 2018-05-19 06:37:34 --> Controller Class Initialized
DEBUG - 2018-05-19 06:37:34 --> videos MX_Controller Initialized
INFO - 2018-05-19 06:37:34 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-19 06:37:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-05-19 06:37:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-19 06:37:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-05-19 06:37:34 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-19 06:37:34 --> Login MX_Controller Initialized
DEBUG - 2018-05-19 06:37:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-19 06:37:43 --> Config Class Initialized
INFO - 2018-05-19 06:37:43 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:37:43 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:37:43 --> Utf8 Class Initialized
INFO - 2018-05-19 06:37:43 --> URI Class Initialized
INFO - 2018-05-19 06:37:43 --> Router Class Initialized
INFO - 2018-05-19 06:37:43 --> Output Class Initialized
INFO - 2018-05-19 06:37:43 --> Security Class Initialized
DEBUG - 2018-05-19 06:37:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:37:43 --> Input Class Initialized
INFO - 2018-05-19 06:37:43 --> Language Class Initialized
INFO - 2018-05-19 06:37:43 --> Language Class Initialized
INFO - 2018-05-19 06:37:43 --> Config Class Initialized
INFO - 2018-05-19 06:37:43 --> Loader Class Initialized
DEBUG - 2018-05-19 06:37:43 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-19 06:37:43 --> Helper loaded: url_helper
INFO - 2018-05-19 06:37:43 --> Helper loaded: form_helper
INFO - 2018-05-19 06:37:43 --> Helper loaded: date_helper
INFO - 2018-05-19 06:37:43 --> Helper loaded: util_helper
INFO - 2018-05-19 06:37:43 --> Helper loaded: text_helper
INFO - 2018-05-19 06:37:43 --> Helper loaded: string_helper
INFO - 2018-05-19 06:37:43 --> Database Driver Class Initialized
DEBUG - 2018-05-19 06:37:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-19 06:37:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-19 06:37:43 --> Email Class Initialized
INFO - 2018-05-19 06:37:43 --> Controller Class Initialized
DEBUG - 2018-05-19 06:37:43 --> videos MX_Controller Initialized
INFO - 2018-05-19 06:37:43 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-19 06:37:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-05-19 06:37:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-19 06:37:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-05-19 06:37:43 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-19 06:37:43 --> Login MX_Controller Initialized
DEBUG - 2018-05-19 06:37:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-19 06:37:43 --> Config Class Initialized
INFO - 2018-05-19 06:37:44 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:37:44 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:37:44 --> Utf8 Class Initialized
INFO - 2018-05-19 06:37:44 --> URI Class Initialized
INFO - 2018-05-19 06:37:44 --> Router Class Initialized
INFO - 2018-05-19 06:37:44 --> Output Class Initialized
INFO - 2018-05-19 06:37:44 --> Security Class Initialized
DEBUG - 2018-05-19 06:37:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:37:44 --> Input Class Initialized
INFO - 2018-05-19 06:37:44 --> Language Class Initialized
INFO - 2018-05-19 06:37:44 --> Language Class Initialized
INFO - 2018-05-19 06:37:44 --> Config Class Initialized
INFO - 2018-05-19 06:37:44 --> Loader Class Initialized
DEBUG - 2018-05-19 06:37:44 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-19 06:37:44 --> Helper loaded: url_helper
INFO - 2018-05-19 06:37:44 --> Helper loaded: form_helper
INFO - 2018-05-19 06:37:44 --> Helper loaded: date_helper
INFO - 2018-05-19 06:37:44 --> Helper loaded: util_helper
INFO - 2018-05-19 06:37:44 --> Helper loaded: text_helper
INFO - 2018-05-19 06:37:44 --> Helper loaded: string_helper
INFO - 2018-05-19 06:37:44 --> Database Driver Class Initialized
DEBUG - 2018-05-19 06:37:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-19 06:37:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-19 06:37:44 --> Email Class Initialized
INFO - 2018-05-19 06:37:44 --> Controller Class Initialized
DEBUG - 2018-05-19 06:37:44 --> videos MX_Controller Initialized
INFO - 2018-05-19 06:37:44 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-19 06:37:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-05-19 06:37:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-19 06:37:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-05-19 06:37:44 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-19 06:37:44 --> Login MX_Controller Initialized
DEBUG - 2018-05-19 06:37:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-19 06:37:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-05-19 06:37:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-05-19 06:37:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-05-19 06:37:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-05-19 06:37:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-05-19 06:37:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/videos/videos.php
INFO - 2018-05-19 06:37:44 --> Final output sent to browser
DEBUG - 2018-05-19 06:37:44 --> Total execution time: 0.7975
INFO - 2018-05-19 06:37:45 --> Config Class Initialized
INFO - 2018-05-19 06:37:45 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:37:45 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:37:45 --> Utf8 Class Initialized
INFO - 2018-05-19 06:37:45 --> URI Class Initialized
INFO - 2018-05-19 06:37:45 --> Router Class Initialized
INFO - 2018-05-19 06:37:45 --> Output Class Initialized
INFO - 2018-05-19 06:37:45 --> Security Class Initialized
DEBUG - 2018-05-19 06:37:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:37:45 --> Input Class Initialized
INFO - 2018-05-19 06:37:45 --> Language Class Initialized
INFO - 2018-05-19 06:37:45 --> Language Class Initialized
INFO - 2018-05-19 06:37:45 --> Config Class Initialized
INFO - 2018-05-19 06:37:45 --> Loader Class Initialized
DEBUG - 2018-05-19 06:37:45 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-19 06:37:45 --> Helper loaded: url_helper
INFO - 2018-05-19 06:37:45 --> Helper loaded: form_helper
INFO - 2018-05-19 06:37:45 --> Helper loaded: date_helper
INFO - 2018-05-19 06:37:45 --> Helper loaded: util_helper
INFO - 2018-05-19 06:37:45 --> Helper loaded: text_helper
INFO - 2018-05-19 06:37:45 --> Helper loaded: string_helper
INFO - 2018-05-19 06:37:45 --> Database Driver Class Initialized
DEBUG - 2018-05-19 06:37:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-19 06:37:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-19 06:37:45 --> Email Class Initialized
INFO - 2018-05-19 06:37:45 --> Controller Class Initialized
DEBUG - 2018-05-19 06:37:45 --> videos MX_Controller Initialized
INFO - 2018-05-19 06:37:45 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-19 06:37:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-05-19 06:37:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-19 06:37:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-05-19 06:37:46 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-19 06:37:46 --> Login MX_Controller Initialized
DEBUG - 2018-05-19 06:37:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-19 06:37:46 --> Final output sent to browser
DEBUG - 2018-05-19 06:37:46 --> Total execution time: 0.8581
INFO - 2018-05-19 06:37:58 --> Config Class Initialized
INFO - 2018-05-19 06:37:58 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:37:58 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:37:58 --> Utf8 Class Initialized
INFO - 2018-05-19 06:37:58 --> URI Class Initialized
INFO - 2018-05-19 06:37:58 --> Router Class Initialized
INFO - 2018-05-19 06:37:58 --> Output Class Initialized
INFO - 2018-05-19 06:37:58 --> Security Class Initialized
DEBUG - 2018-05-19 06:37:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:37:58 --> Input Class Initialized
INFO - 2018-05-19 06:37:58 --> Language Class Initialized
INFO - 2018-05-19 06:37:58 --> Language Class Initialized
INFO - 2018-05-19 06:37:58 --> Config Class Initialized
INFO - 2018-05-19 06:37:58 --> Loader Class Initialized
DEBUG - 2018-05-19 06:37:58 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-19 06:37:58 --> Helper loaded: url_helper
INFO - 2018-05-19 06:37:58 --> Helper loaded: form_helper
INFO - 2018-05-19 06:37:58 --> Helper loaded: date_helper
INFO - 2018-05-19 06:37:58 --> Helper loaded: util_helper
INFO - 2018-05-19 06:37:58 --> Helper loaded: text_helper
INFO - 2018-05-19 06:37:58 --> Helper loaded: string_helper
INFO - 2018-05-19 06:37:58 --> Database Driver Class Initialized
DEBUG - 2018-05-19 06:37:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-19 06:37:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-19 06:37:58 --> Email Class Initialized
INFO - 2018-05-19 06:37:58 --> Controller Class Initialized
DEBUG - 2018-05-19 06:37:59 --> Home MX_Controller Initialized
DEBUG - 2018-05-19 06:37:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-19 06:37:59 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-19 06:37:59 --> Login MX_Controller Initialized
INFO - 2018-05-19 06:37:59 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-19 06:37:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-19 06:37:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-19 06:37:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-19 06:37:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-19 06:37:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-19 06:37:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-19 06:37:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-19 06:37:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-05-19 06:37:59 --> Final output sent to browser
DEBUG - 2018-05-19 06:37:59 --> Total execution time: 0.7351
INFO - 2018-05-19 06:37:59 --> Config Class Initialized
INFO - 2018-05-19 06:37:59 --> Config Class Initialized
INFO - 2018-05-19 06:37:59 --> Hooks Class Initialized
INFO - 2018-05-19 06:37:59 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:37:59 --> UTF-8 Support Enabled
DEBUG - 2018-05-19 06:37:59 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:37:59 --> Utf8 Class Initialized
INFO - 2018-05-19 06:37:59 --> URI Class Initialized
INFO - 2018-05-19 06:37:59 --> Utf8 Class Initialized
INFO - 2018-05-19 06:37:59 --> Router Class Initialized
INFO - 2018-05-19 06:37:59 --> Output Class Initialized
INFO - 2018-05-19 06:37:59 --> URI Class Initialized
INFO - 2018-05-19 06:37:59 --> Security Class Initialized
INFO - 2018-05-19 06:37:59 --> Router Class Initialized
INFO - 2018-05-19 06:38:00 --> Output Class Initialized
INFO - 2018-05-19 06:38:00 --> Security Class Initialized
DEBUG - 2018-05-19 06:38:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-19 06:38:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:38:00 --> Input Class Initialized
INFO - 2018-05-19 06:38:00 --> Language Class Initialized
ERROR - 2018-05-19 06:38:00 --> 404 Page Not Found: /index
INFO - 2018-05-19 06:38:00 --> Input Class Initialized
INFO - 2018-05-19 06:38:00 --> Config Class Initialized
INFO - 2018-05-19 06:38:00 --> Hooks Class Initialized
INFO - 2018-05-19 06:38:00 --> Language Class Initialized
DEBUG - 2018-05-19 06:38:00 --> UTF-8 Support Enabled
ERROR - 2018-05-19 06:38:00 --> 404 Page Not Found: /index
INFO - 2018-05-19 06:38:00 --> Utf8 Class Initialized
INFO - 2018-05-19 06:38:00 --> URI Class Initialized
INFO - 2018-05-19 06:38:00 --> Router Class Initialized
INFO - 2018-05-19 06:38:00 --> Output Class Initialized
INFO - 2018-05-19 06:38:00 --> Security Class Initialized
DEBUG - 2018-05-19 06:38:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:38:00 --> Input Class Initialized
INFO - 2018-05-19 06:38:00 --> Language Class Initialized
ERROR - 2018-05-19 06:38:00 --> 404 Page Not Found: /index
INFO - 2018-05-19 06:38:00 --> Config Class Initialized
INFO - 2018-05-19 06:38:00 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:38:00 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:38:00 --> Utf8 Class Initialized
INFO - 2018-05-19 06:38:00 --> URI Class Initialized
INFO - 2018-05-19 06:38:00 --> Router Class Initialized
INFO - 2018-05-19 06:38:00 --> Output Class Initialized
INFO - 2018-05-19 06:38:00 --> Security Class Initialized
DEBUG - 2018-05-19 06:38:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:38:00 --> Input Class Initialized
INFO - 2018-05-19 06:38:00 --> Language Class Initialized
ERROR - 2018-05-19 06:38:00 --> 404 Page Not Found: /index
INFO - 2018-05-19 06:39:33 --> Config Class Initialized
INFO - 2018-05-19 06:39:33 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:39:33 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:39:33 --> Utf8 Class Initialized
INFO - 2018-05-19 06:39:33 --> URI Class Initialized
INFO - 2018-05-19 06:39:33 --> Router Class Initialized
INFO - 2018-05-19 06:39:33 --> Output Class Initialized
INFO - 2018-05-19 06:39:33 --> Security Class Initialized
DEBUG - 2018-05-19 06:39:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:39:33 --> Input Class Initialized
INFO - 2018-05-19 06:39:33 --> Language Class Initialized
INFO - 2018-05-19 06:39:33 --> Language Class Initialized
INFO - 2018-05-19 06:39:33 --> Config Class Initialized
INFO - 2018-05-19 06:39:33 --> Loader Class Initialized
DEBUG - 2018-05-19 06:39:33 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-19 06:39:33 --> Helper loaded: url_helper
INFO - 2018-05-19 06:39:33 --> Helper loaded: form_helper
INFO - 2018-05-19 06:39:33 --> Helper loaded: date_helper
INFO - 2018-05-19 06:39:34 --> Helper loaded: util_helper
INFO - 2018-05-19 06:39:34 --> Helper loaded: text_helper
INFO - 2018-05-19 06:39:34 --> Helper loaded: string_helper
INFO - 2018-05-19 06:39:34 --> Database Driver Class Initialized
DEBUG - 2018-05-19 06:39:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-19 06:39:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-19 06:39:34 --> Email Class Initialized
INFO - 2018-05-19 06:39:34 --> Controller Class Initialized
DEBUG - 2018-05-19 06:39:34 --> Home MX_Controller Initialized
DEBUG - 2018-05-19 06:39:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-19 06:39:34 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-19 06:39:34 --> Login MX_Controller Initialized
INFO - 2018-05-19 06:39:34 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-19 06:39:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-19 06:39:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-19 06:39:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-19 06:39:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-19 06:39:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-19 06:39:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-19 06:39:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-19 06:39:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-05-19 06:39:34 --> Final output sent to browser
DEBUG - 2018-05-19 06:39:34 --> Total execution time: 0.7402
INFO - 2018-05-19 06:39:34 --> Config Class Initialized
INFO - 2018-05-19 06:39:34 --> Config Class Initialized
INFO - 2018-05-19 06:39:34 --> Hooks Class Initialized
INFO - 2018-05-19 06:39:34 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:39:34 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:39:34 --> Utf8 Class Initialized
INFO - 2018-05-19 06:39:34 --> URI Class Initialized
DEBUG - 2018-05-19 06:39:34 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:39:34 --> Router Class Initialized
INFO - 2018-05-19 06:39:34 --> Utf8 Class Initialized
INFO - 2018-05-19 06:39:34 --> Output Class Initialized
INFO - 2018-05-19 06:39:34 --> URI Class Initialized
INFO - 2018-05-19 06:39:34 --> Router Class Initialized
INFO - 2018-05-19 06:39:35 --> Output Class Initialized
INFO - 2018-05-19 06:39:35 --> Security Class Initialized
DEBUG - 2018-05-19 06:39:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:39:35 --> Input Class Initialized
INFO - 2018-05-19 06:39:35 --> Language Class Initialized
ERROR - 2018-05-19 06:39:35 --> 404 Page Not Found: /index
INFO - 2018-05-19 06:39:35 --> Security Class Initialized
INFO - 2018-05-19 06:39:35 --> Config Class Initialized
INFO - 2018-05-19 06:39:35 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:39:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-19 06:39:35 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:39:35 --> Utf8 Class Initialized
INFO - 2018-05-19 06:39:35 --> Input Class Initialized
INFO - 2018-05-19 06:39:35 --> URI Class Initialized
INFO - 2018-05-19 06:39:35 --> Language Class Initialized
INFO - 2018-05-19 06:39:35 --> Router Class Initialized
ERROR - 2018-05-19 06:39:35 --> 404 Page Not Found: /index
INFO - 2018-05-19 06:39:35 --> Output Class Initialized
INFO - 2018-05-19 06:39:35 --> Security Class Initialized
DEBUG - 2018-05-19 06:39:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:39:35 --> Input Class Initialized
INFO - 2018-05-19 06:39:35 --> Language Class Initialized
ERROR - 2018-05-19 06:39:35 --> 404 Page Not Found: /index
INFO - 2018-05-19 06:39:35 --> Config Class Initialized
INFO - 2018-05-19 06:39:35 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:39:35 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:39:35 --> Utf8 Class Initialized
INFO - 2018-05-19 06:39:35 --> URI Class Initialized
INFO - 2018-05-19 06:39:35 --> Router Class Initialized
INFO - 2018-05-19 06:39:35 --> Output Class Initialized
INFO - 2018-05-19 06:39:35 --> Security Class Initialized
DEBUG - 2018-05-19 06:39:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:39:35 --> Input Class Initialized
INFO - 2018-05-19 06:39:35 --> Language Class Initialized
ERROR - 2018-05-19 06:39:35 --> 404 Page Not Found: /index
INFO - 2018-05-19 06:40:07 --> Config Class Initialized
INFO - 2018-05-19 06:40:07 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:40:07 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:40:07 --> Utf8 Class Initialized
INFO - 2018-05-19 06:40:07 --> URI Class Initialized
INFO - 2018-05-19 06:40:07 --> Router Class Initialized
INFO - 2018-05-19 06:40:07 --> Output Class Initialized
INFO - 2018-05-19 06:40:07 --> Security Class Initialized
DEBUG - 2018-05-19 06:40:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:40:07 --> Input Class Initialized
INFO - 2018-05-19 06:40:07 --> Language Class Initialized
INFO - 2018-05-19 06:40:07 --> Language Class Initialized
INFO - 2018-05-19 06:40:07 --> Config Class Initialized
INFO - 2018-05-19 06:40:07 --> Loader Class Initialized
DEBUG - 2018-05-19 06:40:07 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-19 06:40:07 --> Helper loaded: url_helper
INFO - 2018-05-19 06:40:07 --> Helper loaded: form_helper
INFO - 2018-05-19 06:40:07 --> Helper loaded: date_helper
INFO - 2018-05-19 06:40:07 --> Helper loaded: util_helper
INFO - 2018-05-19 06:40:07 --> Helper loaded: text_helper
INFO - 2018-05-19 06:40:07 --> Helper loaded: string_helper
INFO - 2018-05-19 06:40:07 --> Database Driver Class Initialized
DEBUG - 2018-05-19 06:40:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-19 06:40:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-19 06:40:07 --> Email Class Initialized
INFO - 2018-05-19 06:40:07 --> Controller Class Initialized
DEBUG - 2018-05-19 06:40:07 --> Home MX_Controller Initialized
DEBUG - 2018-05-19 06:40:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-19 06:40:07 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-19 06:40:07 --> Login MX_Controller Initialized
INFO - 2018-05-19 06:40:07 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-19 06:40:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-19 06:40:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-19 06:40:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-19 06:40:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-19 06:40:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-19 06:40:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-19 06:40:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-19 06:40:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-05-19 06:40:07 --> Final output sent to browser
DEBUG - 2018-05-19 06:40:07 --> Total execution time: 0.7379
INFO - 2018-05-19 06:40:08 --> Config Class Initialized
INFO - 2018-05-19 06:40:08 --> Hooks Class Initialized
INFO - 2018-05-19 06:40:08 --> Config Class Initialized
DEBUG - 2018-05-19 06:40:08 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:40:08 --> Hooks Class Initialized
INFO - 2018-05-19 06:40:08 --> Utf8 Class Initialized
INFO - 2018-05-19 06:40:08 --> URI Class Initialized
DEBUG - 2018-05-19 06:40:08 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:40:08 --> Utf8 Class Initialized
INFO - 2018-05-19 06:40:08 --> Router Class Initialized
INFO - 2018-05-19 06:40:08 --> URI Class Initialized
INFO - 2018-05-19 06:40:08 --> Router Class Initialized
INFO - 2018-05-19 06:40:08 --> Output Class Initialized
INFO - 2018-05-19 06:40:08 --> Security Class Initialized
INFO - 2018-05-19 06:40:08 --> Output Class Initialized
DEBUG - 2018-05-19 06:40:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:40:08 --> Input Class Initialized
INFO - 2018-05-19 06:40:08 --> Language Class Initialized
ERROR - 2018-05-19 06:40:08 --> 404 Page Not Found: /index
INFO - 2018-05-19 06:40:08 --> Security Class Initialized
DEBUG - 2018-05-19 06:40:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:40:08 --> Config Class Initialized
INFO - 2018-05-19 06:40:08 --> Input Class Initialized
INFO - 2018-05-19 06:40:08 --> Hooks Class Initialized
INFO - 2018-05-19 06:40:08 --> Language Class Initialized
DEBUG - 2018-05-19 06:40:08 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:40:08 --> Utf8 Class Initialized
ERROR - 2018-05-19 06:40:08 --> 404 Page Not Found: /index
INFO - 2018-05-19 06:40:08 --> URI Class Initialized
INFO - 2018-05-19 06:40:08 --> Router Class Initialized
INFO - 2018-05-19 06:40:08 --> Output Class Initialized
INFO - 2018-05-19 06:40:08 --> Security Class Initialized
DEBUG - 2018-05-19 06:40:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:40:08 --> Input Class Initialized
INFO - 2018-05-19 06:40:08 --> Language Class Initialized
ERROR - 2018-05-19 06:40:08 --> 404 Page Not Found: /index
INFO - 2018-05-19 06:40:08 --> Config Class Initialized
INFO - 2018-05-19 06:40:09 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:40:09 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:40:09 --> Utf8 Class Initialized
INFO - 2018-05-19 06:40:09 --> URI Class Initialized
INFO - 2018-05-19 06:40:09 --> Router Class Initialized
INFO - 2018-05-19 06:40:09 --> Output Class Initialized
INFO - 2018-05-19 06:40:09 --> Security Class Initialized
DEBUG - 2018-05-19 06:40:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:40:09 --> Input Class Initialized
INFO - 2018-05-19 06:40:09 --> Language Class Initialized
ERROR - 2018-05-19 06:40:09 --> 404 Page Not Found: /index
INFO - 2018-05-19 06:40:10 --> Config Class Initialized
INFO - 2018-05-19 06:40:10 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:40:10 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:40:10 --> Utf8 Class Initialized
INFO - 2018-05-19 06:40:10 --> URI Class Initialized
INFO - 2018-05-19 06:40:10 --> Router Class Initialized
INFO - 2018-05-19 06:40:10 --> Output Class Initialized
INFO - 2018-05-19 06:40:10 --> Security Class Initialized
DEBUG - 2018-05-19 06:40:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:40:10 --> Input Class Initialized
INFO - 2018-05-19 06:40:10 --> Language Class Initialized
ERROR - 2018-05-19 06:40:10 --> 404 Page Not Found: /index
INFO - 2018-05-19 06:40:10 --> Config Class Initialized
INFO - 2018-05-19 06:40:10 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:40:10 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:40:10 --> Utf8 Class Initialized
INFO - 2018-05-19 06:40:10 --> URI Class Initialized
INFO - 2018-05-19 06:40:10 --> Router Class Initialized
INFO - 2018-05-19 06:40:10 --> Output Class Initialized
INFO - 2018-05-19 06:40:10 --> Security Class Initialized
DEBUG - 2018-05-19 06:40:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:40:10 --> Input Class Initialized
INFO - 2018-05-19 06:40:10 --> Language Class Initialized
ERROR - 2018-05-19 06:40:10 --> 404 Page Not Found: /index
INFO - 2018-05-19 06:40:10 --> Config Class Initialized
INFO - 2018-05-19 06:40:10 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:40:10 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:40:10 --> Utf8 Class Initialized
INFO - 2018-05-19 06:40:10 --> URI Class Initialized
INFO - 2018-05-19 06:40:10 --> Router Class Initialized
INFO - 2018-05-19 06:40:10 --> Output Class Initialized
INFO - 2018-05-19 06:40:10 --> Security Class Initialized
DEBUG - 2018-05-19 06:40:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:40:10 --> Input Class Initialized
INFO - 2018-05-19 06:40:10 --> Language Class Initialized
ERROR - 2018-05-19 06:40:10 --> 404 Page Not Found: /index
INFO - 2018-05-19 06:41:34 --> Config Class Initialized
INFO - 2018-05-19 06:41:34 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:41:34 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:41:34 --> Utf8 Class Initialized
INFO - 2018-05-19 06:41:34 --> URI Class Initialized
INFO - 2018-05-19 06:41:34 --> Router Class Initialized
INFO - 2018-05-19 06:41:34 --> Output Class Initialized
INFO - 2018-05-19 06:41:34 --> Security Class Initialized
DEBUG - 2018-05-19 06:41:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:41:34 --> Input Class Initialized
INFO - 2018-05-19 06:41:34 --> Language Class Initialized
INFO - 2018-05-19 06:41:34 --> Language Class Initialized
INFO - 2018-05-19 06:41:34 --> Config Class Initialized
INFO - 2018-05-19 06:41:34 --> Loader Class Initialized
DEBUG - 2018-05-19 06:41:34 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-19 06:41:34 --> Helper loaded: url_helper
INFO - 2018-05-19 06:41:34 --> Helper loaded: form_helper
INFO - 2018-05-19 06:41:34 --> Helper loaded: date_helper
INFO - 2018-05-19 06:41:34 --> Helper loaded: util_helper
INFO - 2018-05-19 06:41:34 --> Helper loaded: text_helper
INFO - 2018-05-19 06:41:34 --> Helper loaded: string_helper
INFO - 2018-05-19 06:41:34 --> Database Driver Class Initialized
DEBUG - 2018-05-19 06:41:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-19 06:41:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-19 06:41:34 --> Email Class Initialized
INFO - 2018-05-19 06:41:34 --> Controller Class Initialized
DEBUG - 2018-05-19 06:41:34 --> Home MX_Controller Initialized
DEBUG - 2018-05-19 06:41:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-19 06:41:34 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-19 06:41:34 --> Login MX_Controller Initialized
INFO - 2018-05-19 06:41:34 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-19 06:41:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-19 06:41:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-19 06:41:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-19 06:41:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-19 06:41:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-19 06:41:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-19 06:41:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-19 06:41:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-05-19 06:41:35 --> Final output sent to browser
DEBUG - 2018-05-19 06:41:35 --> Total execution time: 0.7369
INFO - 2018-05-19 06:41:35 --> Config Class Initialized
INFO - 2018-05-19 06:41:35 --> Hooks Class Initialized
INFO - 2018-05-19 06:41:35 --> Config Class Initialized
INFO - 2018-05-19 06:41:35 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:41:35 --> UTF-8 Support Enabled
DEBUG - 2018-05-19 06:41:35 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:41:35 --> Utf8 Class Initialized
INFO - 2018-05-19 06:41:35 --> URI Class Initialized
INFO - 2018-05-19 06:41:36 --> Router Class Initialized
INFO - 2018-05-19 06:41:36 --> Output Class Initialized
INFO - 2018-05-19 06:41:36 --> Utf8 Class Initialized
INFO - 2018-05-19 06:41:36 --> Security Class Initialized
INFO - 2018-05-19 06:41:36 --> URI Class Initialized
DEBUG - 2018-05-19 06:41:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:41:36 --> Input Class Initialized
INFO - 2018-05-19 06:41:36 --> Router Class Initialized
INFO - 2018-05-19 06:41:36 --> Language Class Initialized
ERROR - 2018-05-19 06:41:36 --> 404 Page Not Found: /index
INFO - 2018-05-19 06:41:36 --> Output Class Initialized
INFO - 2018-05-19 06:41:36 --> Security Class Initialized
INFO - 2018-05-19 06:41:36 --> Config Class Initialized
INFO - 2018-05-19 06:41:36 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:41:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-19 06:41:36 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:41:36 --> Utf8 Class Initialized
INFO - 2018-05-19 06:41:36 --> URI Class Initialized
INFO - 2018-05-19 06:41:36 --> Input Class Initialized
INFO - 2018-05-19 06:41:36 --> Router Class Initialized
INFO - 2018-05-19 06:41:36 --> Language Class Initialized
INFO - 2018-05-19 06:41:36 --> Output Class Initialized
INFO - 2018-05-19 06:41:36 --> Security Class Initialized
ERROR - 2018-05-19 06:41:36 --> 404 Page Not Found: /index
DEBUG - 2018-05-19 06:41:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:41:36 --> Input Class Initialized
INFO - 2018-05-19 06:41:36 --> Language Class Initialized
ERROR - 2018-05-19 06:41:36 --> 404 Page Not Found: /index
INFO - 2018-05-19 06:41:37 --> Config Class Initialized
INFO - 2018-05-19 06:41:37 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:41:37 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:41:37 --> Utf8 Class Initialized
INFO - 2018-05-19 06:41:37 --> URI Class Initialized
INFO - 2018-05-19 06:41:37 --> Router Class Initialized
INFO - 2018-05-19 06:41:37 --> Output Class Initialized
INFO - 2018-05-19 06:41:37 --> Security Class Initialized
DEBUG - 2018-05-19 06:41:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:41:37 --> Input Class Initialized
INFO - 2018-05-19 06:41:37 --> Language Class Initialized
ERROR - 2018-05-19 06:41:37 --> 404 Page Not Found: /index
INFO - 2018-05-19 06:41:46 --> Config Class Initialized
INFO - 2018-05-19 06:41:46 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:41:46 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:41:46 --> Utf8 Class Initialized
INFO - 2018-05-19 06:41:46 --> URI Class Initialized
INFO - 2018-05-19 06:41:46 --> Router Class Initialized
INFO - 2018-05-19 06:41:46 --> Output Class Initialized
INFO - 2018-05-19 06:41:46 --> Security Class Initialized
DEBUG - 2018-05-19 06:41:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:41:46 --> Input Class Initialized
INFO - 2018-05-19 06:41:46 --> Language Class Initialized
INFO - 2018-05-19 06:41:46 --> Language Class Initialized
INFO - 2018-05-19 06:41:46 --> Config Class Initialized
INFO - 2018-05-19 06:41:46 --> Loader Class Initialized
DEBUG - 2018-05-19 06:41:46 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-19 06:41:46 --> Helper loaded: url_helper
INFO - 2018-05-19 06:41:46 --> Helper loaded: form_helper
INFO - 2018-05-19 06:41:46 --> Helper loaded: date_helper
INFO - 2018-05-19 06:41:46 --> Helper loaded: util_helper
INFO - 2018-05-19 06:41:46 --> Helper loaded: text_helper
INFO - 2018-05-19 06:41:46 --> Helper loaded: string_helper
INFO - 2018-05-19 06:41:46 --> Database Driver Class Initialized
DEBUG - 2018-05-19 06:41:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-19 06:41:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-19 06:41:46 --> Email Class Initialized
INFO - 2018-05-19 06:41:46 --> Controller Class Initialized
DEBUG - 2018-05-19 06:41:46 --> Home MX_Controller Initialized
DEBUG - 2018-05-19 06:41:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-19 06:41:46 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-19 06:41:46 --> Login MX_Controller Initialized
INFO - 2018-05-19 06:41:46 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-19 06:41:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-19 06:41:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-19 06:41:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-19 06:41:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-19 06:41:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-19 06:41:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-19 06:41:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-19 06:41:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-05-19 06:41:46 --> Final output sent to browser
DEBUG - 2018-05-19 06:41:46 --> Total execution time: 0.8053
INFO - 2018-05-19 06:41:47 --> Config Class Initialized
INFO - 2018-05-19 06:41:47 --> Hooks Class Initialized
INFO - 2018-05-19 06:41:47 --> Config Class Initialized
INFO - 2018-05-19 06:41:47 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:41:47 --> UTF-8 Support Enabled
DEBUG - 2018-05-19 06:41:47 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:41:47 --> Utf8 Class Initialized
INFO - 2018-05-19 06:41:47 --> Utf8 Class Initialized
INFO - 2018-05-19 06:41:47 --> URI Class Initialized
INFO - 2018-05-19 06:41:47 --> URI Class Initialized
INFO - 2018-05-19 06:41:47 --> Router Class Initialized
INFO - 2018-05-19 06:41:47 --> Output Class Initialized
INFO - 2018-05-19 06:41:47 --> Router Class Initialized
INFO - 2018-05-19 06:41:47 --> Output Class Initialized
INFO - 2018-05-19 06:41:47 --> Security Class Initialized
DEBUG - 2018-05-19 06:41:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:41:47 --> Security Class Initialized
INFO - 2018-05-19 06:41:47 --> Input Class Initialized
DEBUG - 2018-05-19 06:41:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:41:47 --> Language Class Initialized
ERROR - 2018-05-19 06:41:47 --> 404 Page Not Found: /index
INFO - 2018-05-19 06:41:47 --> Input Class Initialized
INFO - 2018-05-19 06:41:47 --> Language Class Initialized
ERROR - 2018-05-19 06:41:47 --> 404 Page Not Found: /index
INFO - 2018-05-19 06:41:48 --> Config Class Initialized
INFO - 2018-05-19 06:41:48 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:41:48 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:41:48 --> Utf8 Class Initialized
INFO - 2018-05-19 06:41:48 --> URI Class Initialized
INFO - 2018-05-19 06:41:48 --> Router Class Initialized
INFO - 2018-05-19 06:41:48 --> Output Class Initialized
INFO - 2018-05-19 06:41:48 --> Security Class Initialized
DEBUG - 2018-05-19 06:41:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:41:48 --> Input Class Initialized
INFO - 2018-05-19 06:41:48 --> Language Class Initialized
ERROR - 2018-05-19 06:41:48 --> 404 Page Not Found: /index
INFO - 2018-05-19 06:41:48 --> Config Class Initialized
INFO - 2018-05-19 06:41:48 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:41:48 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:41:48 --> Utf8 Class Initialized
INFO - 2018-05-19 06:41:48 --> URI Class Initialized
INFO - 2018-05-19 06:41:48 --> Router Class Initialized
INFO - 2018-05-19 06:41:48 --> Output Class Initialized
INFO - 2018-05-19 06:41:48 --> Security Class Initialized
DEBUG - 2018-05-19 06:41:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:41:48 --> Input Class Initialized
INFO - 2018-05-19 06:41:48 --> Language Class Initialized
ERROR - 2018-05-19 06:41:48 --> 404 Page Not Found: /index
INFO - 2018-05-19 06:42:52 --> Config Class Initialized
INFO - 2018-05-19 06:42:52 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:42:52 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:42:52 --> Utf8 Class Initialized
INFO - 2018-05-19 06:42:52 --> URI Class Initialized
INFO - 2018-05-19 06:42:52 --> Router Class Initialized
INFO - 2018-05-19 06:42:52 --> Output Class Initialized
INFO - 2018-05-19 06:42:52 --> Security Class Initialized
DEBUG - 2018-05-19 06:42:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:42:52 --> Input Class Initialized
INFO - 2018-05-19 06:42:52 --> Language Class Initialized
INFO - 2018-05-19 06:42:52 --> Language Class Initialized
INFO - 2018-05-19 06:42:52 --> Config Class Initialized
INFO - 2018-05-19 06:42:52 --> Loader Class Initialized
DEBUG - 2018-05-19 06:42:52 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-19 06:42:52 --> Helper loaded: url_helper
INFO - 2018-05-19 06:42:52 --> Helper loaded: form_helper
INFO - 2018-05-19 06:42:52 --> Helper loaded: date_helper
INFO - 2018-05-19 06:42:52 --> Helper loaded: util_helper
INFO - 2018-05-19 06:42:52 --> Helper loaded: text_helper
INFO - 2018-05-19 06:42:52 --> Helper loaded: string_helper
INFO - 2018-05-19 06:42:52 --> Database Driver Class Initialized
DEBUG - 2018-05-19 06:42:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-19 06:42:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-19 06:42:52 --> Email Class Initialized
INFO - 2018-05-19 06:42:52 --> Controller Class Initialized
DEBUG - 2018-05-19 06:42:52 --> Home MX_Controller Initialized
DEBUG - 2018-05-19 06:42:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-19 06:42:52 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-19 06:42:52 --> Login MX_Controller Initialized
INFO - 2018-05-19 06:42:52 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-19 06:42:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-19 06:42:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-19 06:42:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-19 06:42:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-19 06:42:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-19 06:42:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-19 06:42:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-19 06:42:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-05-19 06:42:52 --> Final output sent to browser
DEBUG - 2018-05-19 06:42:52 --> Total execution time: 0.7781
INFO - 2018-05-19 06:42:53 --> Config Class Initialized
INFO - 2018-05-19 06:42:53 --> Hooks Class Initialized
INFO - 2018-05-19 06:42:53 --> Config Class Initialized
DEBUG - 2018-05-19 06:42:53 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:42:53 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:42:53 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:42:53 --> Utf8 Class Initialized
INFO - 2018-05-19 06:42:53 --> Utf8 Class Initialized
INFO - 2018-05-19 06:42:53 --> URI Class Initialized
INFO - 2018-05-19 06:42:53 --> URI Class Initialized
INFO - 2018-05-19 06:42:53 --> Router Class Initialized
INFO - 2018-05-19 06:42:53 --> Output Class Initialized
INFO - 2018-05-19 06:42:53 --> Router Class Initialized
INFO - 2018-05-19 06:42:53 --> Security Class Initialized
DEBUG - 2018-05-19 06:42:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:42:53 --> Input Class Initialized
INFO - 2018-05-19 06:42:53 --> Output Class Initialized
INFO - 2018-05-19 06:42:53 --> Security Class Initialized
INFO - 2018-05-19 06:42:53 --> Language Class Initialized
DEBUG - 2018-05-19 06:42:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:42:53 --> Input Class Initialized
INFO - 2018-05-19 06:42:53 --> Language Class Initialized
ERROR - 2018-05-19 06:42:53 --> 404 Page Not Found: /index
ERROR - 2018-05-19 06:42:53 --> 404 Page Not Found: /index
INFO - 2018-05-19 06:42:54 --> Config Class Initialized
INFO - 2018-05-19 06:42:54 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:42:54 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:42:54 --> Utf8 Class Initialized
INFO - 2018-05-19 06:42:54 --> URI Class Initialized
INFO - 2018-05-19 06:42:54 --> Router Class Initialized
INFO - 2018-05-19 06:42:54 --> Output Class Initialized
INFO - 2018-05-19 06:42:54 --> Security Class Initialized
DEBUG - 2018-05-19 06:42:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:42:54 --> Input Class Initialized
INFO - 2018-05-19 06:42:54 --> Language Class Initialized
ERROR - 2018-05-19 06:42:54 --> 404 Page Not Found: /index
INFO - 2018-05-19 06:42:55 --> Config Class Initialized
INFO - 2018-05-19 06:42:55 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:42:55 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:42:55 --> Utf8 Class Initialized
INFO - 2018-05-19 06:42:55 --> URI Class Initialized
INFO - 2018-05-19 06:42:55 --> Router Class Initialized
INFO - 2018-05-19 06:42:55 --> Output Class Initialized
INFO - 2018-05-19 06:42:55 --> Security Class Initialized
DEBUG - 2018-05-19 06:42:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:42:55 --> Input Class Initialized
INFO - 2018-05-19 06:42:55 --> Language Class Initialized
ERROR - 2018-05-19 06:42:55 --> 404 Page Not Found: /index
INFO - 2018-05-19 06:43:04 --> Config Class Initialized
INFO - 2018-05-19 06:43:04 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:43:04 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:43:04 --> Utf8 Class Initialized
INFO - 2018-05-19 06:43:04 --> URI Class Initialized
INFO - 2018-05-19 06:43:04 --> Router Class Initialized
INFO - 2018-05-19 06:43:04 --> Output Class Initialized
INFO - 2018-05-19 06:43:04 --> Security Class Initialized
DEBUG - 2018-05-19 06:43:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:43:04 --> Input Class Initialized
INFO - 2018-05-19 06:43:04 --> Language Class Initialized
INFO - 2018-05-19 06:43:04 --> Language Class Initialized
INFO - 2018-05-19 06:43:04 --> Config Class Initialized
INFO - 2018-05-19 06:43:04 --> Loader Class Initialized
DEBUG - 2018-05-19 06:43:04 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-19 06:43:04 --> Helper loaded: url_helper
INFO - 2018-05-19 06:43:04 --> Helper loaded: form_helper
INFO - 2018-05-19 06:43:04 --> Helper loaded: date_helper
INFO - 2018-05-19 06:43:04 --> Helper loaded: util_helper
INFO - 2018-05-19 06:43:04 --> Helper loaded: text_helper
INFO - 2018-05-19 06:43:04 --> Helper loaded: string_helper
INFO - 2018-05-19 06:43:04 --> Database Driver Class Initialized
DEBUG - 2018-05-19 06:43:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-19 06:43:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-19 06:43:04 --> Email Class Initialized
INFO - 2018-05-19 06:43:04 --> Controller Class Initialized
DEBUG - 2018-05-19 06:43:04 --> Home MX_Controller Initialized
DEBUG - 2018-05-19 06:43:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-19 06:43:04 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-19 06:43:04 --> Login MX_Controller Initialized
INFO - 2018-05-19 06:43:04 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-19 06:43:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-19 06:43:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-19 06:43:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-19 06:43:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-19 06:43:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-19 06:43:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-19 06:43:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-19 06:43:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-05-19 06:43:05 --> Final output sent to browser
DEBUG - 2018-05-19 06:43:05 --> Total execution time: 0.7706
INFO - 2018-05-19 06:43:05 --> Config Class Initialized
INFO - 2018-05-19 06:43:05 --> Config Class Initialized
INFO - 2018-05-19 06:43:05 --> Hooks Class Initialized
INFO - 2018-05-19 06:43:05 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:43:05 --> UTF-8 Support Enabled
DEBUG - 2018-05-19 06:43:05 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:43:05 --> Utf8 Class Initialized
INFO - 2018-05-19 06:43:05 --> Utf8 Class Initialized
INFO - 2018-05-19 06:43:05 --> URI Class Initialized
INFO - 2018-05-19 06:43:05 --> URI Class Initialized
INFO - 2018-05-19 06:43:05 --> Router Class Initialized
INFO - 2018-05-19 06:43:05 --> Router Class Initialized
INFO - 2018-05-19 06:43:05 --> Output Class Initialized
INFO - 2018-05-19 06:43:05 --> Security Class Initialized
DEBUG - 2018-05-19 06:43:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:43:05 --> Output Class Initialized
INFO - 2018-05-19 06:43:05 --> Input Class Initialized
INFO - 2018-05-19 06:43:05 --> Security Class Initialized
INFO - 2018-05-19 06:43:05 --> Language Class Initialized
ERROR - 2018-05-19 06:43:05 --> 404 Page Not Found: /index
DEBUG - 2018-05-19 06:43:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:43:06 --> Input Class Initialized
INFO - 2018-05-19 06:43:06 --> Language Class Initialized
ERROR - 2018-05-19 06:43:06 --> 404 Page Not Found: /index
INFO - 2018-05-19 06:43:06 --> Config Class Initialized
INFO - 2018-05-19 06:43:06 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:43:06 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:43:06 --> Utf8 Class Initialized
INFO - 2018-05-19 06:43:06 --> URI Class Initialized
INFO - 2018-05-19 06:43:06 --> Router Class Initialized
INFO - 2018-05-19 06:43:06 --> Output Class Initialized
INFO - 2018-05-19 06:43:06 --> Security Class Initialized
DEBUG - 2018-05-19 06:43:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:43:06 --> Input Class Initialized
INFO - 2018-05-19 06:43:06 --> Language Class Initialized
ERROR - 2018-05-19 06:43:06 --> 404 Page Not Found: /index
INFO - 2018-05-19 06:43:06 --> Config Class Initialized
INFO - 2018-05-19 06:43:06 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:43:06 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:43:06 --> Utf8 Class Initialized
INFO - 2018-05-19 06:43:06 --> URI Class Initialized
INFO - 2018-05-19 06:43:06 --> Router Class Initialized
INFO - 2018-05-19 06:43:06 --> Output Class Initialized
INFO - 2018-05-19 06:43:06 --> Security Class Initialized
DEBUG - 2018-05-19 06:43:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:43:06 --> Input Class Initialized
INFO - 2018-05-19 06:43:07 --> Language Class Initialized
ERROR - 2018-05-19 06:43:07 --> 404 Page Not Found: /index
INFO - 2018-05-19 06:44:05 --> Config Class Initialized
INFO - 2018-05-19 06:44:05 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:44:05 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:44:05 --> Utf8 Class Initialized
INFO - 2018-05-19 06:44:05 --> URI Class Initialized
INFO - 2018-05-19 06:44:05 --> Router Class Initialized
INFO - 2018-05-19 06:44:05 --> Output Class Initialized
INFO - 2018-05-19 06:44:05 --> Security Class Initialized
DEBUG - 2018-05-19 06:44:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:44:05 --> Input Class Initialized
INFO - 2018-05-19 06:44:05 --> Language Class Initialized
INFO - 2018-05-19 06:44:05 --> Language Class Initialized
INFO - 2018-05-19 06:44:05 --> Config Class Initialized
INFO - 2018-05-19 06:44:05 --> Loader Class Initialized
DEBUG - 2018-05-19 06:44:05 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-19 06:44:05 --> Helper loaded: url_helper
INFO - 2018-05-19 06:44:05 --> Helper loaded: form_helper
INFO - 2018-05-19 06:44:05 --> Helper loaded: date_helper
INFO - 2018-05-19 06:44:05 --> Helper loaded: util_helper
INFO - 2018-05-19 06:44:05 --> Helper loaded: text_helper
INFO - 2018-05-19 06:44:05 --> Helper loaded: string_helper
INFO - 2018-05-19 06:44:05 --> Database Driver Class Initialized
DEBUG - 2018-05-19 06:44:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-19 06:44:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-19 06:44:05 --> Email Class Initialized
INFO - 2018-05-19 06:44:05 --> Controller Class Initialized
DEBUG - 2018-05-19 06:44:05 --> Home MX_Controller Initialized
DEBUG - 2018-05-19 06:44:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-19 06:44:06 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-19 06:44:06 --> Login MX_Controller Initialized
INFO - 2018-05-19 06:44:06 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-19 06:44:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-19 06:44:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-19 06:44:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-19 06:44:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-19 06:44:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-19 06:44:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-19 06:44:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-19 06:44:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-05-19 06:44:06 --> Final output sent to browser
DEBUG - 2018-05-19 06:44:06 --> Total execution time: 0.8347
INFO - 2018-05-19 06:44:06 --> Config Class Initialized
INFO - 2018-05-19 06:44:06 --> Config Class Initialized
INFO - 2018-05-19 06:44:06 --> Hooks Class Initialized
INFO - 2018-05-19 06:44:06 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:44:06 --> UTF-8 Support Enabled
DEBUG - 2018-05-19 06:44:06 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:44:06 --> Utf8 Class Initialized
INFO - 2018-05-19 06:44:06 --> URI Class Initialized
INFO - 2018-05-19 06:44:07 --> Utf8 Class Initialized
INFO - 2018-05-19 06:44:07 --> Router Class Initialized
INFO - 2018-05-19 06:44:07 --> URI Class Initialized
INFO - 2018-05-19 06:44:07 --> Output Class Initialized
INFO - 2018-05-19 06:44:07 --> Router Class Initialized
INFO - 2018-05-19 06:44:07 --> Security Class Initialized
INFO - 2018-05-19 06:44:07 --> Output Class Initialized
DEBUG - 2018-05-19 06:44:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:44:07 --> Security Class Initialized
INFO - 2018-05-19 06:44:07 --> Input Class Initialized
DEBUG - 2018-05-19 06:44:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:44:07 --> Input Class Initialized
INFO - 2018-05-19 06:44:07 --> Language Class Initialized
INFO - 2018-05-19 06:44:07 --> Language Class Initialized
ERROR - 2018-05-19 06:44:07 --> 404 Page Not Found: /index
ERROR - 2018-05-19 06:44:07 --> 404 Page Not Found: /index
INFO - 2018-05-19 06:44:07 --> Config Class Initialized
INFO - 2018-05-19 06:44:07 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:44:08 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:44:08 --> Utf8 Class Initialized
INFO - 2018-05-19 06:44:08 --> URI Class Initialized
INFO - 2018-05-19 06:44:08 --> Router Class Initialized
INFO - 2018-05-19 06:44:08 --> Output Class Initialized
INFO - 2018-05-19 06:44:08 --> Security Class Initialized
DEBUG - 2018-05-19 06:44:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:44:08 --> Input Class Initialized
INFO - 2018-05-19 06:44:08 --> Language Class Initialized
ERROR - 2018-05-19 06:44:08 --> 404 Page Not Found: /index
INFO - 2018-05-19 06:44:08 --> Config Class Initialized
INFO - 2018-05-19 06:44:08 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:44:08 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:44:08 --> Utf8 Class Initialized
INFO - 2018-05-19 06:44:08 --> URI Class Initialized
INFO - 2018-05-19 06:44:08 --> Router Class Initialized
INFO - 2018-05-19 06:44:08 --> Output Class Initialized
INFO - 2018-05-19 06:44:08 --> Security Class Initialized
DEBUG - 2018-05-19 06:44:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:44:08 --> Input Class Initialized
INFO - 2018-05-19 06:44:08 --> Language Class Initialized
ERROR - 2018-05-19 06:44:08 --> 404 Page Not Found: /index
INFO - 2018-05-19 06:44:16 --> Config Class Initialized
INFO - 2018-05-19 06:44:16 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:44:16 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:44:16 --> Utf8 Class Initialized
INFO - 2018-05-19 06:44:16 --> URI Class Initialized
INFO - 2018-05-19 06:44:16 --> Router Class Initialized
INFO - 2018-05-19 06:44:16 --> Output Class Initialized
INFO - 2018-05-19 06:44:16 --> Security Class Initialized
DEBUG - 2018-05-19 06:44:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:44:16 --> Input Class Initialized
INFO - 2018-05-19 06:44:16 --> Language Class Initialized
INFO - 2018-05-19 06:44:16 --> Language Class Initialized
INFO - 2018-05-19 06:44:16 --> Config Class Initialized
INFO - 2018-05-19 06:44:16 --> Loader Class Initialized
DEBUG - 2018-05-19 06:44:16 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-19 06:44:17 --> Helper loaded: url_helper
INFO - 2018-05-19 06:44:17 --> Helper loaded: form_helper
INFO - 2018-05-19 06:44:17 --> Helper loaded: date_helper
INFO - 2018-05-19 06:44:17 --> Helper loaded: util_helper
INFO - 2018-05-19 06:44:17 --> Helper loaded: text_helper
INFO - 2018-05-19 06:44:17 --> Helper loaded: string_helper
INFO - 2018-05-19 06:44:17 --> Database Driver Class Initialized
DEBUG - 2018-05-19 06:44:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-19 06:44:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-19 06:44:17 --> Email Class Initialized
INFO - 2018-05-19 06:44:17 --> Controller Class Initialized
DEBUG - 2018-05-19 06:44:17 --> Home MX_Controller Initialized
DEBUG - 2018-05-19 06:44:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-19 06:44:17 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-19 06:44:17 --> Login MX_Controller Initialized
INFO - 2018-05-19 06:44:17 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-19 06:44:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-19 06:44:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-19 06:44:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-19 06:44:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-19 06:44:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-19 06:44:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-19 06:44:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-19 06:44:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-05-19 06:44:17 --> Final output sent to browser
DEBUG - 2018-05-19 06:44:17 --> Total execution time: 0.8013
INFO - 2018-05-19 06:44:18 --> Config Class Initialized
INFO - 2018-05-19 06:44:18 --> Config Class Initialized
INFO - 2018-05-19 06:44:18 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:44:18 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:44:18 --> Utf8 Class Initialized
INFO - 2018-05-19 06:44:18 --> URI Class Initialized
INFO - 2018-05-19 06:44:18 --> Router Class Initialized
INFO - 2018-05-19 06:44:18 --> Output Class Initialized
INFO - 2018-05-19 06:44:18 --> Security Class Initialized
INFO - 2018-05-19 06:44:18 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:44:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-19 06:44:18 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:44:18 --> Utf8 Class Initialized
INFO - 2018-05-19 06:44:18 --> URI Class Initialized
INFO - 2018-05-19 06:44:18 --> Router Class Initialized
INFO - 2018-05-19 06:44:18 --> Output Class Initialized
INFO - 2018-05-19 06:44:18 --> Input Class Initialized
INFO - 2018-05-19 06:44:18 --> Security Class Initialized
INFO - 2018-05-19 06:44:18 --> Language Class Initialized
ERROR - 2018-05-19 06:44:18 --> 404 Page Not Found: /index
DEBUG - 2018-05-19 06:44:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:44:18 --> Input Class Initialized
INFO - 2018-05-19 06:44:18 --> Language Class Initialized
ERROR - 2018-05-19 06:44:18 --> 404 Page Not Found: /index
INFO - 2018-05-19 06:44:19 --> Config Class Initialized
INFO - 2018-05-19 06:44:19 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:44:19 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:44:19 --> Utf8 Class Initialized
INFO - 2018-05-19 06:44:19 --> URI Class Initialized
INFO - 2018-05-19 06:44:19 --> Router Class Initialized
INFO - 2018-05-19 06:44:19 --> Output Class Initialized
INFO - 2018-05-19 06:44:19 --> Security Class Initialized
DEBUG - 2018-05-19 06:44:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:44:19 --> Input Class Initialized
INFO - 2018-05-19 06:44:19 --> Language Class Initialized
ERROR - 2018-05-19 06:44:19 --> 404 Page Not Found: /index
INFO - 2018-05-19 06:44:19 --> Config Class Initialized
INFO - 2018-05-19 06:44:19 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:44:19 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:44:19 --> Utf8 Class Initialized
INFO - 2018-05-19 06:44:19 --> URI Class Initialized
INFO - 2018-05-19 06:44:19 --> Router Class Initialized
INFO - 2018-05-19 06:44:19 --> Output Class Initialized
INFO - 2018-05-19 06:44:19 --> Security Class Initialized
DEBUG - 2018-05-19 06:44:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:44:19 --> Input Class Initialized
INFO - 2018-05-19 06:44:19 --> Language Class Initialized
ERROR - 2018-05-19 06:44:19 --> 404 Page Not Found: /index
INFO - 2018-05-19 06:44:50 --> Config Class Initialized
INFO - 2018-05-19 06:44:50 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:44:50 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:44:50 --> Utf8 Class Initialized
INFO - 2018-05-19 06:44:50 --> URI Class Initialized
INFO - 2018-05-19 06:44:50 --> Router Class Initialized
INFO - 2018-05-19 06:44:50 --> Output Class Initialized
INFO - 2018-05-19 06:44:50 --> Security Class Initialized
DEBUG - 2018-05-19 06:44:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:44:50 --> Input Class Initialized
INFO - 2018-05-19 06:44:50 --> Language Class Initialized
INFO - 2018-05-19 06:44:50 --> Language Class Initialized
INFO - 2018-05-19 06:44:50 --> Config Class Initialized
INFO - 2018-05-19 06:44:50 --> Loader Class Initialized
DEBUG - 2018-05-19 06:44:50 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-19 06:44:50 --> Helper loaded: url_helper
INFO - 2018-05-19 06:44:50 --> Helper loaded: form_helper
INFO - 2018-05-19 06:44:50 --> Helper loaded: date_helper
INFO - 2018-05-19 06:44:50 --> Helper loaded: util_helper
INFO - 2018-05-19 06:44:50 --> Helper loaded: text_helper
INFO - 2018-05-19 06:44:50 --> Helper loaded: string_helper
INFO - 2018-05-19 06:44:50 --> Database Driver Class Initialized
DEBUG - 2018-05-19 06:44:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-19 06:44:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-19 06:44:50 --> Email Class Initialized
INFO - 2018-05-19 06:44:50 --> Controller Class Initialized
DEBUG - 2018-05-19 06:44:50 --> Home MX_Controller Initialized
DEBUG - 2018-05-19 06:44:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-19 06:44:50 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-19 06:44:50 --> Login MX_Controller Initialized
INFO - 2018-05-19 06:44:50 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-19 06:44:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-19 06:44:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-19 06:44:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-19 06:44:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-19 06:44:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-19 06:44:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-19 06:44:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-19 06:44:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-05-19 06:44:50 --> Final output sent to browser
DEBUG - 2018-05-19 06:44:51 --> Total execution time: 0.7771
INFO - 2018-05-19 06:44:51 --> Config Class Initialized
INFO - 2018-05-19 06:44:51 --> Hooks Class Initialized
INFO - 2018-05-19 06:44:51 --> Config Class Initialized
DEBUG - 2018-05-19 06:44:51 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:44:51 --> Utf8 Class Initialized
INFO - 2018-05-19 06:44:51 --> Hooks Class Initialized
INFO - 2018-05-19 06:44:51 --> URI Class Initialized
INFO - 2018-05-19 06:44:51 --> Router Class Initialized
DEBUG - 2018-05-19 06:44:51 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:44:51 --> Utf8 Class Initialized
INFO - 2018-05-19 06:44:51 --> Output Class Initialized
INFO - 2018-05-19 06:44:51 --> URI Class Initialized
INFO - 2018-05-19 06:44:51 --> Security Class Initialized
INFO - 2018-05-19 06:44:51 --> Router Class Initialized
INFO - 2018-05-19 06:44:51 --> Output Class Initialized
INFO - 2018-05-19 06:44:51 --> Security Class Initialized
DEBUG - 2018-05-19 06:44:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:44:52 --> Input Class Initialized
INFO - 2018-05-19 06:44:52 --> Language Class Initialized
DEBUG - 2018-05-19 06:44:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-05-19 06:44:52 --> 404 Page Not Found: /index
INFO - 2018-05-19 06:44:52 --> Input Class Initialized
INFO - 2018-05-19 06:44:52 --> Config Class Initialized
INFO - 2018-05-19 06:44:52 --> Hooks Class Initialized
INFO - 2018-05-19 06:44:52 --> Language Class Initialized
ERROR - 2018-05-19 06:44:52 --> 404 Page Not Found: /index
DEBUG - 2018-05-19 06:44:52 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:44:52 --> Utf8 Class Initialized
INFO - 2018-05-19 06:44:52 --> URI Class Initialized
INFO - 2018-05-19 06:44:52 --> Router Class Initialized
INFO - 2018-05-19 06:44:52 --> Output Class Initialized
INFO - 2018-05-19 06:44:52 --> Security Class Initialized
DEBUG - 2018-05-19 06:44:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:44:52 --> Input Class Initialized
INFO - 2018-05-19 06:44:52 --> Language Class Initialized
ERROR - 2018-05-19 06:44:52 --> 404 Page Not Found: /index
INFO - 2018-05-19 06:44:52 --> Config Class Initialized
INFO - 2018-05-19 06:44:53 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:44:53 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:44:53 --> Utf8 Class Initialized
INFO - 2018-05-19 06:44:53 --> URI Class Initialized
INFO - 2018-05-19 06:44:53 --> Router Class Initialized
INFO - 2018-05-19 06:44:53 --> Output Class Initialized
INFO - 2018-05-19 06:44:53 --> Security Class Initialized
DEBUG - 2018-05-19 06:44:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:44:53 --> Input Class Initialized
INFO - 2018-05-19 06:44:53 --> Language Class Initialized
ERROR - 2018-05-19 06:44:53 --> 404 Page Not Found: /index
INFO - 2018-05-19 06:44:53 --> Config Class Initialized
INFO - 2018-05-19 06:44:53 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:44:53 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:44:53 --> Utf8 Class Initialized
INFO - 2018-05-19 06:44:53 --> URI Class Initialized
INFO - 2018-05-19 06:44:53 --> Router Class Initialized
INFO - 2018-05-19 06:44:53 --> Output Class Initialized
INFO - 2018-05-19 06:44:53 --> Security Class Initialized
DEBUG - 2018-05-19 06:44:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:44:53 --> Input Class Initialized
INFO - 2018-05-19 06:44:53 --> Language Class Initialized
ERROR - 2018-05-19 06:44:53 --> 404 Page Not Found: /index
INFO - 2018-05-19 06:44:53 --> Config Class Initialized
INFO - 2018-05-19 06:44:53 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:44:53 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:44:53 --> Utf8 Class Initialized
INFO - 2018-05-19 06:44:53 --> URI Class Initialized
INFO - 2018-05-19 06:44:53 --> Router Class Initialized
INFO - 2018-05-19 06:44:53 --> Output Class Initialized
INFO - 2018-05-19 06:44:53 --> Security Class Initialized
DEBUG - 2018-05-19 06:44:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:44:53 --> Input Class Initialized
INFO - 2018-05-19 06:44:53 --> Language Class Initialized
ERROR - 2018-05-19 06:44:53 --> 404 Page Not Found: /index
INFO - 2018-05-19 06:44:53 --> Config Class Initialized
INFO - 2018-05-19 06:44:54 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:44:54 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:44:54 --> Utf8 Class Initialized
INFO - 2018-05-19 06:44:54 --> URI Class Initialized
INFO - 2018-05-19 06:44:54 --> Router Class Initialized
INFO - 2018-05-19 06:44:54 --> Output Class Initialized
INFO - 2018-05-19 06:44:54 --> Security Class Initialized
DEBUG - 2018-05-19 06:44:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:44:54 --> Input Class Initialized
INFO - 2018-05-19 06:44:54 --> Language Class Initialized
ERROR - 2018-05-19 06:44:54 --> 404 Page Not Found: /index
INFO - 2018-05-19 06:46:33 --> Config Class Initialized
INFO - 2018-05-19 06:46:33 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:46:33 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:46:33 --> Utf8 Class Initialized
INFO - 2018-05-19 06:46:33 --> URI Class Initialized
INFO - 2018-05-19 06:46:33 --> Router Class Initialized
INFO - 2018-05-19 06:46:33 --> Output Class Initialized
INFO - 2018-05-19 06:46:33 --> Security Class Initialized
DEBUG - 2018-05-19 06:46:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:46:33 --> Input Class Initialized
INFO - 2018-05-19 06:46:33 --> Language Class Initialized
INFO - 2018-05-19 06:46:33 --> Language Class Initialized
INFO - 2018-05-19 06:46:33 --> Config Class Initialized
INFO - 2018-05-19 06:46:33 --> Loader Class Initialized
DEBUG - 2018-05-19 06:46:33 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-19 06:46:33 --> Helper loaded: url_helper
INFO - 2018-05-19 06:46:33 --> Helper loaded: form_helper
INFO - 2018-05-19 06:46:33 --> Helper loaded: date_helper
INFO - 2018-05-19 06:46:33 --> Helper loaded: util_helper
INFO - 2018-05-19 06:46:34 --> Helper loaded: text_helper
INFO - 2018-05-19 06:46:34 --> Helper loaded: string_helper
INFO - 2018-05-19 06:46:34 --> Database Driver Class Initialized
DEBUG - 2018-05-19 06:46:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-19 06:46:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-19 06:46:34 --> Email Class Initialized
INFO - 2018-05-19 06:46:34 --> Controller Class Initialized
DEBUG - 2018-05-19 06:46:34 --> Home MX_Controller Initialized
DEBUG - 2018-05-19 06:46:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-19 06:46:34 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-19 06:46:34 --> Login MX_Controller Initialized
INFO - 2018-05-19 06:46:34 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-19 06:46:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-19 06:46:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-19 06:46:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-19 06:46:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-19 06:46:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
INFO - 2018-05-19 06:47:14 --> Config Class Initialized
INFO - 2018-05-19 06:47:14 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:47:14 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:47:14 --> Utf8 Class Initialized
INFO - 2018-05-19 06:47:14 --> URI Class Initialized
INFO - 2018-05-19 06:47:14 --> Router Class Initialized
INFO - 2018-05-19 06:47:14 --> Output Class Initialized
INFO - 2018-05-19 06:47:14 --> Security Class Initialized
DEBUG - 2018-05-19 06:47:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:47:14 --> Input Class Initialized
INFO - 2018-05-19 06:47:14 --> Language Class Initialized
INFO - 2018-05-19 06:47:14 --> Language Class Initialized
INFO - 2018-05-19 06:47:14 --> Config Class Initialized
INFO - 2018-05-19 06:47:14 --> Loader Class Initialized
DEBUG - 2018-05-19 06:47:14 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-19 06:47:14 --> Helper loaded: url_helper
INFO - 2018-05-19 06:47:14 --> Helper loaded: form_helper
INFO - 2018-05-19 06:47:14 --> Helper loaded: date_helper
INFO - 2018-05-19 06:47:14 --> Helper loaded: util_helper
INFO - 2018-05-19 06:47:14 --> Helper loaded: text_helper
INFO - 2018-05-19 06:47:14 --> Helper loaded: string_helper
INFO - 2018-05-19 06:47:14 --> Database Driver Class Initialized
DEBUG - 2018-05-19 06:47:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-19 06:47:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-19 06:47:14 --> Email Class Initialized
INFO - 2018-05-19 06:47:14 --> Controller Class Initialized
DEBUG - 2018-05-19 06:47:14 --> Home MX_Controller Initialized
DEBUG - 2018-05-19 06:47:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-19 06:47:14 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-19 06:47:14 --> Login MX_Controller Initialized
INFO - 2018-05-19 06:47:14 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-19 06:47:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-19 06:47:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-19 06:47:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-19 06:47:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-19 06:47:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-19 06:47:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-19 06:47:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-19 06:47:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-05-19 06:47:14 --> Final output sent to browser
DEBUG - 2018-05-19 06:47:15 --> Total execution time: 0.8663
INFO - 2018-05-19 06:47:17 --> Config Class Initialized
INFO - 2018-05-19 06:47:17 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:47:17 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:47:17 --> Utf8 Class Initialized
INFO - 2018-05-19 06:47:17 --> URI Class Initialized
INFO - 2018-05-19 06:47:17 --> Router Class Initialized
INFO - 2018-05-19 06:47:17 --> Output Class Initialized
INFO - 2018-05-19 06:47:17 --> Security Class Initialized
DEBUG - 2018-05-19 06:47:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:47:17 --> Input Class Initialized
INFO - 2018-05-19 06:47:17 --> Language Class Initialized
INFO - 2018-05-19 06:47:17 --> Language Class Initialized
INFO - 2018-05-19 06:47:17 --> Config Class Initialized
INFO - 2018-05-19 06:47:17 --> Loader Class Initialized
DEBUG - 2018-05-19 06:47:17 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-19 06:47:17 --> Helper loaded: url_helper
INFO - 2018-05-19 06:47:17 --> Helper loaded: form_helper
INFO - 2018-05-19 06:47:17 --> Helper loaded: date_helper
INFO - 2018-05-19 06:47:17 --> Helper loaded: util_helper
INFO - 2018-05-19 06:47:17 --> Helper loaded: text_helper
INFO - 2018-05-19 06:47:17 --> Helper loaded: string_helper
INFO - 2018-05-19 06:47:17 --> Database Driver Class Initialized
DEBUG - 2018-05-19 06:47:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-19 06:47:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-19 06:47:18 --> Email Class Initialized
INFO - 2018-05-19 06:47:18 --> Controller Class Initialized
DEBUG - 2018-05-19 06:47:18 --> Home MX_Controller Initialized
DEBUG - 2018-05-19 06:47:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-19 06:47:18 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-19 06:47:18 --> Login MX_Controller Initialized
INFO - 2018-05-19 06:47:18 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-19 06:47:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-19 06:47:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-19 06:47:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-19 06:47:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-19 06:47:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-19 06:47:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-19 06:47:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-19 06:47:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-05-19 06:47:18 --> Final output sent to browser
DEBUG - 2018-05-19 06:47:18 --> Total execution time: 0.8787
INFO - 2018-05-19 06:47:18 --> Config Class Initialized
INFO - 2018-05-19 06:47:18 --> Config Class Initialized
INFO - 2018-05-19 06:47:18 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:47:18 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:47:18 --> Utf8 Class Initialized
INFO - 2018-05-19 06:47:18 --> Hooks Class Initialized
INFO - 2018-05-19 06:47:18 --> URI Class Initialized
INFO - 2018-05-19 06:47:19 --> Router Class Initialized
DEBUG - 2018-05-19 06:47:19 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:47:19 --> Utf8 Class Initialized
INFO - 2018-05-19 06:47:19 --> Output Class Initialized
INFO - 2018-05-19 06:47:19 --> URI Class Initialized
INFO - 2018-05-19 06:47:19 --> Security Class Initialized
INFO - 2018-05-19 06:47:19 --> Router Class Initialized
DEBUG - 2018-05-19 06:47:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:47:19 --> Output Class Initialized
INFO - 2018-05-19 06:47:19 --> Input Class Initialized
INFO - 2018-05-19 06:47:19 --> Language Class Initialized
ERROR - 2018-05-19 06:47:19 --> 404 Page Not Found: /index
INFO - 2018-05-19 06:47:19 --> Security Class Initialized
DEBUG - 2018-05-19 06:47:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:47:19 --> Input Class Initialized
INFO - 2018-05-19 06:47:19 --> Language Class Initialized
ERROR - 2018-05-19 06:47:19 --> 404 Page Not Found: /index
INFO - 2018-05-19 06:47:19 --> Config Class Initialized
INFO - 2018-05-19 06:47:19 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:47:20 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:47:20 --> Utf8 Class Initialized
INFO - 2018-05-19 06:47:20 --> URI Class Initialized
INFO - 2018-05-19 06:47:20 --> Router Class Initialized
INFO - 2018-05-19 06:47:20 --> Output Class Initialized
INFO - 2018-05-19 06:47:20 --> Security Class Initialized
DEBUG - 2018-05-19 06:47:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:47:20 --> Input Class Initialized
INFO - 2018-05-19 06:47:20 --> Language Class Initialized
ERROR - 2018-05-19 06:47:20 --> 404 Page Not Found: /index
INFO - 2018-05-19 06:47:20 --> Config Class Initialized
INFO - 2018-05-19 06:47:20 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:47:20 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:47:20 --> Utf8 Class Initialized
INFO - 2018-05-19 06:47:20 --> URI Class Initialized
INFO - 2018-05-19 06:47:20 --> Router Class Initialized
INFO - 2018-05-19 06:47:20 --> Output Class Initialized
INFO - 2018-05-19 06:47:20 --> Security Class Initialized
DEBUG - 2018-05-19 06:47:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:47:20 --> Input Class Initialized
INFO - 2018-05-19 06:47:20 --> Language Class Initialized
ERROR - 2018-05-19 06:47:20 --> 404 Page Not Found: /index
INFO - 2018-05-19 06:47:21 --> Config Class Initialized
INFO - 2018-05-19 06:47:21 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:47:21 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:47:21 --> Utf8 Class Initialized
INFO - 2018-05-19 06:47:21 --> URI Class Initialized
INFO - 2018-05-19 06:47:21 --> Router Class Initialized
INFO - 2018-05-19 06:47:21 --> Output Class Initialized
INFO - 2018-05-19 06:47:21 --> Security Class Initialized
DEBUG - 2018-05-19 06:47:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:47:21 --> Input Class Initialized
INFO - 2018-05-19 06:47:21 --> Language Class Initialized
ERROR - 2018-05-19 06:47:21 --> 404 Page Not Found: /index
INFO - 2018-05-19 06:47:21 --> Config Class Initialized
INFO - 2018-05-19 06:47:21 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:47:21 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:47:21 --> Utf8 Class Initialized
INFO - 2018-05-19 06:47:21 --> URI Class Initialized
INFO - 2018-05-19 06:47:21 --> Router Class Initialized
INFO - 2018-05-19 06:47:21 --> Output Class Initialized
INFO - 2018-05-19 06:47:21 --> Security Class Initialized
DEBUG - 2018-05-19 06:47:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:47:21 --> Input Class Initialized
INFO - 2018-05-19 06:47:21 --> Language Class Initialized
ERROR - 2018-05-19 06:47:21 --> 404 Page Not Found: /index
INFO - 2018-05-19 06:47:21 --> Config Class Initialized
INFO - 2018-05-19 06:47:21 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:47:21 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:47:21 --> Utf8 Class Initialized
INFO - 2018-05-19 06:47:21 --> URI Class Initialized
INFO - 2018-05-19 06:47:21 --> Router Class Initialized
INFO - 2018-05-19 06:47:21 --> Output Class Initialized
INFO - 2018-05-19 06:47:21 --> Security Class Initialized
DEBUG - 2018-05-19 06:47:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:47:21 --> Input Class Initialized
INFO - 2018-05-19 06:47:21 --> Language Class Initialized
ERROR - 2018-05-19 06:47:21 --> 404 Page Not Found: /index
INFO - 2018-05-19 06:47:28 --> Config Class Initialized
INFO - 2018-05-19 06:47:28 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:47:28 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:47:28 --> Utf8 Class Initialized
INFO - 2018-05-19 06:47:28 --> URI Class Initialized
INFO - 2018-05-19 06:47:28 --> Router Class Initialized
INFO - 2018-05-19 06:47:28 --> Output Class Initialized
INFO - 2018-05-19 06:47:28 --> Security Class Initialized
DEBUG - 2018-05-19 06:47:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:47:28 --> Input Class Initialized
INFO - 2018-05-19 06:47:28 --> Language Class Initialized
INFO - 2018-05-19 06:47:28 --> Language Class Initialized
INFO - 2018-05-19 06:47:28 --> Config Class Initialized
INFO - 2018-05-19 06:47:28 --> Loader Class Initialized
DEBUG - 2018-05-19 06:47:28 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-19 06:47:28 --> Helper loaded: url_helper
INFO - 2018-05-19 06:47:28 --> Helper loaded: form_helper
INFO - 2018-05-19 06:47:28 --> Helper loaded: date_helper
INFO - 2018-05-19 06:47:28 --> Helper loaded: util_helper
INFO - 2018-05-19 06:47:28 --> Helper loaded: text_helper
INFO - 2018-05-19 06:47:28 --> Helper loaded: string_helper
INFO - 2018-05-19 06:47:28 --> Database Driver Class Initialized
DEBUG - 2018-05-19 06:47:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-19 06:47:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-19 06:47:28 --> Email Class Initialized
INFO - 2018-05-19 06:47:28 --> Controller Class Initialized
DEBUG - 2018-05-19 06:47:28 --> Home MX_Controller Initialized
DEBUG - 2018-05-19 06:47:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-19 06:47:28 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-19 06:47:28 --> Login MX_Controller Initialized
INFO - 2018-05-19 06:47:28 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-19 06:47:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-19 06:47:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-19 06:47:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-19 06:47:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-19 06:47:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-19 06:47:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-19 06:47:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-19 06:47:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-05-19 06:47:28 --> Final output sent to browser
DEBUG - 2018-05-19 06:47:28 --> Total execution time: 0.7709
INFO - 2018-05-19 06:47:29 --> Config Class Initialized
INFO - 2018-05-19 06:47:29 --> Config Class Initialized
INFO - 2018-05-19 06:47:29 --> Hooks Class Initialized
INFO - 2018-05-19 06:47:29 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:47:29 --> UTF-8 Support Enabled
DEBUG - 2018-05-19 06:47:29 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:47:29 --> Utf8 Class Initialized
INFO - 2018-05-19 06:47:29 --> URI Class Initialized
INFO - 2018-05-19 06:47:29 --> Router Class Initialized
INFO - 2018-05-19 06:47:29 --> Output Class Initialized
INFO - 2018-05-19 06:47:29 --> Security Class Initialized
INFO - 2018-05-19 06:47:29 --> Utf8 Class Initialized
DEBUG - 2018-05-19 06:47:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:47:29 --> URI Class Initialized
INFO - 2018-05-19 06:47:29 --> Input Class Initialized
INFO - 2018-05-19 06:47:29 --> Router Class Initialized
INFO - 2018-05-19 06:47:29 --> Language Class Initialized
INFO - 2018-05-19 06:47:29 --> Output Class Initialized
ERROR - 2018-05-19 06:47:29 --> 404 Page Not Found: /index
INFO - 2018-05-19 06:47:29 --> Security Class Initialized
DEBUG - 2018-05-19 06:47:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:47:29 --> Input Class Initialized
INFO - 2018-05-19 06:47:29 --> Language Class Initialized
ERROR - 2018-05-19 06:47:29 --> 404 Page Not Found: /index
INFO - 2018-05-19 06:47:29 --> Config Class Initialized
INFO - 2018-05-19 06:47:30 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:47:30 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:47:30 --> Utf8 Class Initialized
INFO - 2018-05-19 06:47:30 --> URI Class Initialized
INFO - 2018-05-19 06:47:30 --> Router Class Initialized
INFO - 2018-05-19 06:47:30 --> Output Class Initialized
INFO - 2018-05-19 06:47:30 --> Security Class Initialized
DEBUG - 2018-05-19 06:47:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:47:30 --> Input Class Initialized
INFO - 2018-05-19 06:47:30 --> Language Class Initialized
ERROR - 2018-05-19 06:47:30 --> 404 Page Not Found: /index
INFO - 2018-05-19 06:47:30 --> Config Class Initialized
INFO - 2018-05-19 06:47:30 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:47:30 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:47:30 --> Utf8 Class Initialized
INFO - 2018-05-19 06:47:30 --> URI Class Initialized
INFO - 2018-05-19 06:47:30 --> Router Class Initialized
INFO - 2018-05-19 06:47:30 --> Output Class Initialized
INFO - 2018-05-19 06:47:30 --> Security Class Initialized
DEBUG - 2018-05-19 06:47:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:47:30 --> Input Class Initialized
INFO - 2018-05-19 06:47:30 --> Language Class Initialized
ERROR - 2018-05-19 06:47:30 --> 404 Page Not Found: /index
INFO - 2018-05-19 06:53:09 --> Config Class Initialized
INFO - 2018-05-19 06:53:09 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:53:09 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:53:09 --> Utf8 Class Initialized
INFO - 2018-05-19 06:53:09 --> URI Class Initialized
INFO - 2018-05-19 06:53:09 --> Router Class Initialized
INFO - 2018-05-19 06:53:09 --> Output Class Initialized
INFO - 2018-05-19 06:53:09 --> Security Class Initialized
DEBUG - 2018-05-19 06:53:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:53:09 --> Input Class Initialized
INFO - 2018-05-19 06:53:09 --> Language Class Initialized
INFO - 2018-05-19 06:53:09 --> Language Class Initialized
INFO - 2018-05-19 06:53:09 --> Config Class Initialized
INFO - 2018-05-19 06:53:09 --> Loader Class Initialized
DEBUG - 2018-05-19 06:53:09 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-19 06:53:09 --> Helper loaded: url_helper
INFO - 2018-05-19 06:53:10 --> Helper loaded: form_helper
INFO - 2018-05-19 06:53:10 --> Helper loaded: date_helper
INFO - 2018-05-19 06:53:10 --> Helper loaded: util_helper
INFO - 2018-05-19 06:53:10 --> Helper loaded: text_helper
INFO - 2018-05-19 06:53:10 --> Helper loaded: string_helper
INFO - 2018-05-19 06:53:10 --> Database Driver Class Initialized
DEBUG - 2018-05-19 06:53:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-19 06:53:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-19 06:53:10 --> Email Class Initialized
INFO - 2018-05-19 06:53:10 --> Controller Class Initialized
DEBUG - 2018-05-19 06:53:10 --> Home MX_Controller Initialized
DEBUG - 2018-05-19 06:53:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-19 06:53:10 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-19 06:53:10 --> Login MX_Controller Initialized
INFO - 2018-05-19 06:53:10 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-19 06:53:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-19 06:53:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-19 06:53:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-19 06:53:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-19 06:53:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-19 06:53:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-19 06:53:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-19 06:53:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-05-19 06:53:10 --> Final output sent to browser
DEBUG - 2018-05-19 06:53:10 --> Total execution time: 1.3192
INFO - 2018-05-19 06:53:10 --> Config Class Initialized
INFO - 2018-05-19 06:53:10 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:53:10 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:53:10 --> Utf8 Class Initialized
INFO - 2018-05-19 06:53:10 --> URI Class Initialized
INFO - 2018-05-19 06:53:10 --> Router Class Initialized
INFO - 2018-05-19 06:53:10 --> Output Class Initialized
INFO - 2018-05-19 06:53:11 --> Security Class Initialized
DEBUG - 2018-05-19 06:53:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:53:11 --> Input Class Initialized
INFO - 2018-05-19 06:53:11 --> Language Class Initialized
INFO - 2018-05-19 06:53:11 --> Language Class Initialized
INFO - 2018-05-19 06:53:11 --> Config Class Initialized
INFO - 2018-05-19 06:53:11 --> Loader Class Initialized
DEBUG - 2018-05-19 06:53:11 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-19 06:53:11 --> Helper loaded: url_helper
INFO - 2018-05-19 06:53:11 --> Helper loaded: form_helper
INFO - 2018-05-19 06:53:11 --> Helper loaded: date_helper
INFO - 2018-05-19 06:53:11 --> Helper loaded: util_helper
INFO - 2018-05-19 06:53:11 --> Helper loaded: text_helper
INFO - 2018-05-19 06:53:11 --> Helper loaded: string_helper
INFO - 2018-05-19 06:53:11 --> Database Driver Class Initialized
DEBUG - 2018-05-19 06:53:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-19 06:53:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-19 06:53:11 --> Email Class Initialized
INFO - 2018-05-19 06:53:11 --> Controller Class Initialized
DEBUG - 2018-05-19 06:53:11 --> videos MX_Controller Initialized
INFO - 2018-05-19 06:53:11 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-19 06:53:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-05-19 06:53:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-19 06:53:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-05-19 06:53:11 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-19 06:53:11 --> Login MX_Controller Initialized
DEBUG - 2018-05-19 06:53:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-19 06:53:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-05-19 06:53:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-05-19 06:53:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-05-19 06:53:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-05-19 06:53:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-05-19 06:53:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/videos/videos.php
INFO - 2018-05-19 06:53:12 --> Final output sent to browser
DEBUG - 2018-05-19 06:53:12 --> Total execution time: 1.4918
INFO - 2018-05-19 06:53:12 --> Config Class Initialized
INFO - 2018-05-19 06:53:12 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:53:12 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:53:13 --> Utf8 Class Initialized
INFO - 2018-05-19 06:53:13 --> URI Class Initialized
INFO - 2018-05-19 06:53:13 --> Router Class Initialized
INFO - 2018-05-19 06:53:13 --> Output Class Initialized
INFO - 2018-05-19 06:53:13 --> Security Class Initialized
DEBUG - 2018-05-19 06:53:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:53:13 --> Input Class Initialized
INFO - 2018-05-19 06:53:13 --> Language Class Initialized
INFO - 2018-05-19 06:53:13 --> Language Class Initialized
INFO - 2018-05-19 06:53:13 --> Config Class Initialized
INFO - 2018-05-19 06:53:13 --> Loader Class Initialized
DEBUG - 2018-05-19 06:53:13 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-19 06:53:13 --> Helper loaded: url_helper
INFO - 2018-05-19 06:53:13 --> Helper loaded: form_helper
INFO - 2018-05-19 06:53:13 --> Helper loaded: date_helper
INFO - 2018-05-19 06:53:13 --> Helper loaded: util_helper
INFO - 2018-05-19 06:53:13 --> Helper loaded: text_helper
INFO - 2018-05-19 06:53:13 --> Helper loaded: string_helper
INFO - 2018-05-19 06:53:13 --> Database Driver Class Initialized
DEBUG - 2018-05-19 06:53:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-19 06:53:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-19 06:53:13 --> Email Class Initialized
INFO - 2018-05-19 06:53:13 --> Controller Class Initialized
DEBUG - 2018-05-19 06:53:13 --> videos MX_Controller Initialized
INFO - 2018-05-19 06:53:13 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-19 06:53:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-05-19 06:53:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-19 06:53:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-05-19 06:53:13 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-19 06:53:13 --> Login MX_Controller Initialized
DEBUG - 2018-05-19 06:53:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-19 06:53:13 --> Final output sent to browser
DEBUG - 2018-05-19 06:53:13 --> Total execution time: 0.7403
INFO - 2018-05-19 06:53:13 --> Config Class Initialized
INFO - 2018-05-19 06:53:13 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:53:13 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:53:13 --> Config Class Initialized
INFO - 2018-05-19 06:53:13 --> Hooks Class Initialized
INFO - 2018-05-19 06:53:13 --> Utf8 Class Initialized
DEBUG - 2018-05-19 06:53:14 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:53:14 --> URI Class Initialized
INFO - 2018-05-19 06:53:14 --> Utf8 Class Initialized
INFO - 2018-05-19 06:53:14 --> URI Class Initialized
INFO - 2018-05-19 06:53:14 --> Router Class Initialized
INFO - 2018-05-19 06:53:14 --> Config Class Initialized
INFO - 2018-05-19 06:53:14 --> Router Class Initialized
INFO - 2018-05-19 06:53:14 --> Output Class Initialized
INFO - 2018-05-19 06:53:14 --> Security Class Initialized
DEBUG - 2018-05-19 06:53:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:53:14 --> Input Class Initialized
INFO - 2018-05-19 06:53:14 --> Language Class Initialized
INFO - 2018-05-19 06:53:14 --> Language Class Initialized
INFO - 2018-05-19 06:53:14 --> Config Class Initialized
INFO - 2018-05-19 06:53:14 --> Loader Class Initialized
DEBUG - 2018-05-19 06:53:14 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-19 06:53:14 --> Helper loaded: url_helper
INFO - 2018-05-19 06:53:14 --> Helper loaded: form_helper
INFO - 2018-05-19 06:53:14 --> Helper loaded: date_helper
INFO - 2018-05-19 06:53:14 --> Hooks Class Initialized
INFO - 2018-05-19 06:53:14 --> Output Class Initialized
DEBUG - 2018-05-19 06:53:14 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:53:14 --> Utf8 Class Initialized
INFO - 2018-05-19 06:53:14 --> Helper loaded: util_helper
INFO - 2018-05-19 06:53:14 --> Security Class Initialized
INFO - 2018-05-19 06:53:14 --> Helper loaded: text_helper
DEBUG - 2018-05-19 06:53:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:53:14 --> URI Class Initialized
INFO - 2018-05-19 06:53:14 --> Input Class Initialized
INFO - 2018-05-19 06:53:14 --> Helper loaded: string_helper
INFO - 2018-05-19 06:53:14 --> Router Class Initialized
INFO - 2018-05-19 06:53:14 --> Language Class Initialized
ERROR - 2018-05-19 06:53:14 --> 404 Page Not Found: /index
INFO - 2018-05-19 06:53:14 --> Output Class Initialized
INFO - 2018-05-19 06:53:14 --> Database Driver Class Initialized
INFO - 2018-05-19 06:53:14 --> Security Class Initialized
DEBUG - 2018-05-19 06:53:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-19 06:53:14 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-05-19 06:53:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:53:14 --> Input Class Initialized
INFO - 2018-05-19 06:53:14 --> Email Class Initialized
INFO - 2018-05-19 06:53:14 --> Language Class Initialized
ERROR - 2018-05-19 06:53:14 --> 404 Page Not Found: /index
INFO - 2018-05-19 06:53:14 --> Config Class Initialized
INFO - 2018-05-19 06:53:14 --> Config Class Initialized
INFO - 2018-05-19 06:53:15 --> Controller Class Initialized
INFO - 2018-05-19 06:53:15 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:53:15 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:53:15 --> Utf8 Class Initialized
INFO - 2018-05-19 06:53:15 --> URI Class Initialized
INFO - 2018-05-19 06:53:15 --> Router Class Initialized
INFO - 2018-05-19 06:53:15 --> Output Class Initialized
INFO - 2018-05-19 06:53:15 --> Security Class Initialized
DEBUG - 2018-05-19 06:53:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:53:15 --> Input Class Initialized
INFO - 2018-05-19 06:53:15 --> Language Class Initialized
ERROR - 2018-05-19 06:53:15 --> 404 Page Not Found: /index
INFO - 2018-05-19 06:53:15 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:53:15 --> Admin MX_Controller Initialized
INFO - 2018-05-19 06:53:15 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-19 06:53:15 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-19 06:53:15 --> Login MX_Controller Initialized
DEBUG - 2018-05-19 06:53:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-19 06:53:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-19 06:53:15 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:53:15 --> Utf8 Class Initialized
DEBUG - 2018-05-19 06:53:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-05-19 06:53:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
INFO - 2018-05-19 06:53:15 --> URI Class Initialized
DEBUG - 2018-05-19 06:53:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
INFO - 2018-05-19 06:53:15 --> Router Class Initialized
DEBUG - 2018-05-19 06:53:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
INFO - 2018-05-19 06:53:15 --> Output Class Initialized
DEBUG - 2018-05-19 06:53:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-05-19 06:53:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/dashboard.php
INFO - 2018-05-19 06:53:15 --> Final output sent to browser
DEBUG - 2018-05-19 06:53:15 --> Total execution time: 1.7453
INFO - 2018-05-19 06:53:15 --> Security Class Initialized
DEBUG - 2018-05-19 06:53:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:53:15 --> Input Class Initialized
INFO - 2018-05-19 06:53:16 --> Language Class Initialized
ERROR - 2018-05-19 06:53:16 --> 404 Page Not Found: /index
INFO - 2018-05-19 06:53:16 --> Config Class Initialized
INFO - 2018-05-19 06:53:16 --> Hooks Class Initialized
DEBUG - 2018-05-19 06:53:16 --> UTF-8 Support Enabled
INFO - 2018-05-19 06:53:16 --> Utf8 Class Initialized
INFO - 2018-05-19 06:53:16 --> URI Class Initialized
INFO - 2018-05-19 06:53:16 --> Router Class Initialized
INFO - 2018-05-19 06:53:16 --> Output Class Initialized
INFO - 2018-05-19 06:53:16 --> Security Class Initialized
DEBUG - 2018-05-19 06:53:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-19 06:53:16 --> Input Class Initialized
INFO - 2018-05-19 06:53:16 --> Language Class Initialized
ERROR - 2018-05-19 06:53:16 --> 404 Page Not Found: /index
