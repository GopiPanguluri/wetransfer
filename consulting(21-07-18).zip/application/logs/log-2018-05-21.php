<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-05-21 21:28:22 --> Config Class Initialized
INFO - 2018-05-21 21:28:22 --> Config Class Initialized
INFO - 2018-05-21 21:28:22 --> Hooks Class Initialized
INFO - 2018-05-21 21:28:22 --> Hooks Class Initialized
INFO - 2018-05-21 21:28:22 --> Config Class Initialized
INFO - 2018-05-21 21:28:22 --> Hooks Class Initialized
INFO - 2018-05-21 21:28:22 --> Config Class Initialized
INFO - 2018-05-21 21:28:22 --> Hooks Class Initialized
DEBUG - 2018-05-21 21:28:22 --> UTF-8 Support Enabled
DEBUG - 2018-05-21 21:28:22 --> UTF-8 Support Enabled
DEBUG - 2018-05-21 21:28:22 --> UTF-8 Support Enabled
DEBUG - 2018-05-21 21:28:22 --> UTF-8 Support Enabled
INFO - 2018-05-21 21:28:22 --> Utf8 Class Initialized
INFO - 2018-05-21 21:28:22 --> Utf8 Class Initialized
INFO - 2018-05-21 21:28:22 --> Utf8 Class Initialized
INFO - 2018-05-21 21:28:22 --> Utf8 Class Initialized
INFO - 2018-05-21 21:28:22 --> URI Class Initialized
INFO - 2018-05-21 21:28:22 --> URI Class Initialized
INFO - 2018-05-21 21:28:22 --> URI Class Initialized
INFO - 2018-05-21 21:28:22 --> URI Class Initialized
INFO - 2018-05-21 21:28:22 --> Router Class Initialized
INFO - 2018-05-21 21:28:22 --> Router Class Initialized
INFO - 2018-05-21 21:28:22 --> Router Class Initialized
INFO - 2018-05-21 21:28:22 --> Router Class Initialized
INFO - 2018-05-21 21:28:23 --> Output Class Initialized
INFO - 2018-05-21 21:28:23 --> Output Class Initialized
INFO - 2018-05-21 21:28:23 --> Output Class Initialized
INFO - 2018-05-21 21:28:23 --> Output Class Initialized
INFO - 2018-05-21 21:28:23 --> Security Class Initialized
INFO - 2018-05-21 21:28:23 --> Security Class Initialized
INFO - 2018-05-21 21:28:23 --> Security Class Initialized
INFO - 2018-05-21 21:28:23 --> Security Class Initialized
DEBUG - 2018-05-21 21:28:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-21 21:28:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-21 21:28:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-21 21:28:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-21 21:28:24 --> Input Class Initialized
INFO - 2018-05-21 21:28:24 --> Input Class Initialized
INFO - 2018-05-21 21:28:24 --> Input Class Initialized
INFO - 2018-05-21 21:28:24 --> Language Class Initialized
INFO - 2018-05-21 21:28:24 --> Language Class Initialized
INFO - 2018-05-21 21:28:24 --> Input Class Initialized
INFO - 2018-05-21 21:28:24 --> Language Class Initialized
INFO - 2018-05-21 21:28:24 --> Language Class Initialized
ERROR - 2018-05-21 21:28:24 --> 404 Page Not Found: /index
INFO - 2018-05-21 21:28:25 --> Language Class Initialized
INFO - 2018-05-21 21:28:25 --> Language Class Initialized
INFO - 2018-05-21 21:28:25 --> Language Class Initialized
INFO - 2018-05-21 21:28:25 --> Config Class Initialized
INFO - 2018-05-21 21:28:25 --> Config Class Initialized
INFO - 2018-05-21 21:28:25 --> Config Class Initialized
INFO - 2018-05-21 21:28:25 --> Loader Class Initialized
INFO - 2018-05-21 21:28:25 --> Loader Class Initialized
INFO - 2018-05-21 21:28:25 --> Loader Class Initialized
DEBUG - 2018-05-21 21:28:25 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
DEBUG - 2018-05-21 21:28:25 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
DEBUG - 2018-05-21 21:28:25 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-21 21:28:26 --> Helper loaded: url_helper
INFO - 2018-05-21 21:28:26 --> Helper loaded: url_helper
INFO - 2018-05-21 21:28:26 --> Helper loaded: url_helper
INFO - 2018-05-21 21:28:26 --> Helper loaded: form_helper
INFO - 2018-05-21 21:28:26 --> Helper loaded: form_helper
INFO - 2018-05-21 21:28:26 --> Helper loaded: form_helper
INFO - 2018-05-21 21:28:27 --> Helper loaded: date_helper
INFO - 2018-05-21 21:28:27 --> Helper loaded: date_helper
INFO - 2018-05-21 21:28:27 --> Helper loaded: date_helper
INFO - 2018-05-21 21:28:27 --> Helper loaded: util_helper
INFO - 2018-05-21 21:28:27 --> Helper loaded: util_helper
INFO - 2018-05-21 21:28:27 --> Helper loaded: util_helper
INFO - 2018-05-21 21:28:27 --> Helper loaded: text_helper
INFO - 2018-05-21 21:28:27 --> Helper loaded: text_helper
INFO - 2018-05-21 21:28:27 --> Helper loaded: text_helper
INFO - 2018-05-21 21:28:27 --> Helper loaded: string_helper
INFO - 2018-05-21 21:28:27 --> Helper loaded: string_helper
INFO - 2018-05-21 21:28:27 --> Helper loaded: string_helper
INFO - 2018-05-21 21:28:28 --> Database Driver Class Initialized
INFO - 2018-05-21 21:28:28 --> Database Driver Class Initialized
INFO - 2018-05-21 21:28:28 --> Database Driver Class Initialized
ERROR - 2018-05-21 21:28:30 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 E:\xampp\htdocs\consulting\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2018-05-21 21:28:30 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 E:\xampp\htdocs\consulting\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2018-05-21 21:28:30 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 E:\xampp\htdocs\consulting\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2018-05-21 21:28:30 --> Unable to connect to the database
ERROR - 2018-05-21 21:28:30 --> Unable to connect to the database
ERROR - 2018-05-21 21:28:30 --> Unable to connect to the database
INFO - 2018-05-21 21:28:31 --> Language file loaded: language/english/db_lang.php
INFO - 2018-05-21 21:28:31 --> Language file loaded: language/english/db_lang.php
INFO - 2018-05-21 21:28:31 --> Language file loaded: language/english/db_lang.php
INFO - 2018-05-21 21:30:39 --> Config Class Initialized
INFO - 2018-05-21 21:30:39 --> Hooks Class Initialized
DEBUG - 2018-05-21 21:30:39 --> UTF-8 Support Enabled
INFO - 2018-05-21 21:30:39 --> Utf8 Class Initialized
INFO - 2018-05-21 21:30:39 --> URI Class Initialized
INFO - 2018-05-21 21:30:39 --> Router Class Initialized
INFO - 2018-05-21 21:30:39 --> Output Class Initialized
INFO - 2018-05-21 21:30:39 --> Security Class Initialized
DEBUG - 2018-05-21 21:30:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-21 21:30:39 --> Input Class Initialized
INFO - 2018-05-21 21:30:39 --> Language Class Initialized
INFO - 2018-05-21 21:30:39 --> Language Class Initialized
INFO - 2018-05-21 21:30:39 --> Config Class Initialized
INFO - 2018-05-21 21:30:39 --> Loader Class Initialized
DEBUG - 2018-05-21 21:30:39 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-21 21:30:39 --> Helper loaded: url_helper
INFO - 2018-05-21 21:30:39 --> Helper loaded: form_helper
INFO - 2018-05-21 21:30:39 --> Helper loaded: date_helper
INFO - 2018-05-21 21:30:39 --> Helper loaded: util_helper
INFO - 2018-05-21 21:30:39 --> Helper loaded: text_helper
INFO - 2018-05-21 21:30:39 --> Helper loaded: string_helper
INFO - 2018-05-21 21:30:39 --> Database Driver Class Initialized
DEBUG - 2018-05-21 21:30:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-21 21:30:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-21 21:30:40 --> Email Class Initialized
INFO - 2018-05-21 21:30:40 --> Controller Class Initialized
DEBUG - 2018-05-21 21:30:40 --> Admin MX_Controller Initialized
INFO - 2018-05-21 21:30:40 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-21 21:30:40 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-21 21:30:40 --> Login MX_Controller Initialized
DEBUG - 2018-05-21 21:30:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-21 21:30:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-21 21:30:40 --> Config Class Initialized
INFO - 2018-05-21 21:30:40 --> Hooks Class Initialized
DEBUG - 2018-05-21 21:30:40 --> UTF-8 Support Enabled
INFO - 2018-05-21 21:30:40 --> Utf8 Class Initialized
INFO - 2018-05-21 21:30:40 --> URI Class Initialized
INFO - 2018-05-21 21:30:40 --> Router Class Initialized
INFO - 2018-05-21 21:30:40 --> Output Class Initialized
INFO - 2018-05-21 21:30:40 --> Security Class Initialized
DEBUG - 2018-05-21 21:30:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-21 21:30:40 --> Input Class Initialized
INFO - 2018-05-21 21:30:40 --> Language Class Initialized
INFO - 2018-05-21 21:30:40 --> Language Class Initialized
INFO - 2018-05-21 21:30:40 --> Config Class Initialized
INFO - 2018-05-21 21:30:40 --> Loader Class Initialized
DEBUG - 2018-05-21 21:30:40 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-21 21:30:40 --> Helper loaded: url_helper
DEBUG - 2018-05-21 21:30:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/logins/login.php
INFO - 2018-05-21 21:30:40 --> Helper loaded: form_helper
INFO - 2018-05-21 21:30:40 --> Helper loaded: date_helper
INFO - 2018-05-21 21:30:40 --> Helper loaded: util_helper
INFO - 2018-05-21 21:30:40 --> Helper loaded: text_helper
INFO - 2018-05-21 21:30:40 --> Helper loaded: string_helper
INFO - 2018-05-21 21:30:40 --> Database Driver Class Initialized
DEBUG - 2018-05-21 21:30:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-21 21:30:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-21 21:30:40 --> Email Class Initialized
INFO - 2018-05-21 21:30:40 --> Controller Class Initialized
DEBUG - 2018-05-21 21:30:40 --> Home MX_Controller Initialized
DEBUG - 2018-05-21 21:30:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-05-21 21:30:41 --> Config Class Initialized
INFO - 2018-05-21 21:30:41 --> Hooks Class Initialized
DEBUG - 2018-05-21 21:30:41 --> UTF-8 Support Enabled
INFO - 2018-05-21 21:30:41 --> Utf8 Class Initialized
INFO - 2018-05-21 21:30:41 --> URI Class Initialized
INFO - 2018-05-21 21:30:41 --> Router Class Initialized
INFO - 2018-05-21 21:30:41 --> Output Class Initialized
INFO - 2018-05-21 21:30:41 --> Security Class Initialized
DEBUG - 2018-05-21 21:30:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-21 21:30:41 --> Input Class Initialized
INFO - 2018-05-21 21:30:41 --> Language Class Initialized
ERROR - 2018-05-21 21:30:41 --> 404 Page Not Found: /index
INFO - 2018-05-21 21:30:41 --> Config Class Initialized
INFO - 2018-05-21 21:30:41 --> Hooks Class Initialized
DEBUG - 2018-05-21 21:30:41 --> UTF-8 Support Enabled
INFO - 2018-05-21 21:30:41 --> Utf8 Class Initialized
INFO - 2018-05-21 21:30:41 --> URI Class Initialized
INFO - 2018-05-21 21:30:41 --> Router Class Initialized
INFO - 2018-05-21 21:30:41 --> Output Class Initialized
INFO - 2018-05-21 21:30:41 --> Security Class Initialized
DEBUG - 2018-05-21 21:30:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-21 21:30:41 --> Input Class Initialized
INFO - 2018-05-21 21:30:41 --> Language Class Initialized
INFO - 2018-05-21 21:30:41 --> Language Class Initialized
INFO - 2018-05-21 21:30:41 --> Config Class Initialized
INFO - 2018-05-21 21:30:41 --> Loader Class Initialized
DEBUG - 2018-05-21 21:30:41 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-21 21:30:41 --> Helper loaded: url_helper
INFO - 2018-05-21 21:30:41 --> Helper loaded: form_helper
INFO - 2018-05-21 21:30:41 --> Helper loaded: date_helper
INFO - 2018-05-21 21:30:41 --> Helper loaded: util_helper
INFO - 2018-05-21 21:30:42 --> Helper loaded: text_helper
INFO - 2018-05-21 21:30:42 --> Helper loaded: string_helper
INFO - 2018-05-21 21:30:42 --> Database Driver Class Initialized
INFO - 2018-05-21 21:30:42 --> Config Class Initialized
INFO - 2018-05-21 21:30:42 --> Hooks Class Initialized
DEBUG - 2018-05-21 21:30:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-21 21:30:42 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-05-21 21:30:42 --> UTF-8 Support Enabled
INFO - 2018-05-21 21:30:42 --> Utf8 Class Initialized
INFO - 2018-05-21 21:30:42 --> Email Class Initialized
INFO - 2018-05-21 21:30:42 --> Controller Class Initialized
INFO - 2018-05-21 21:30:42 --> URI Class Initialized
DEBUG - 2018-05-21 21:30:42 --> videos MX_Controller Initialized
INFO - 2018-05-21 21:30:42 --> Router Class Initialized
INFO - 2018-05-21 21:30:42 --> Language file loaded: language/english/data_lang.php
INFO - 2018-05-21 21:30:42 --> Output Class Initialized
INFO - 2018-05-21 21:30:42 --> Security Class Initialized
DEBUG - 2018-05-21 21:30:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-21 21:30:42 --> Input Class Initialized
INFO - 2018-05-21 21:30:42 --> Language Class Initialized
DEBUG - 2018-05-21 21:30:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-05-21 21:30:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
ERROR - 2018-05-21 21:30:42 --> 404 Page Not Found: /index
DEBUG - 2018-05-21 21:30:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-05-21 21:30:42 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-21 21:30:42 --> Login MX_Controller Initialized
DEBUG - 2018-05-21 21:30:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-21 21:30:42 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-21 21:30:42 --> Login MX_Controller Initialized
DEBUG - 2018-05-21 21:30:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/logins/login.php
INFO - 2018-05-21 21:30:42 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-21 21:30:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-21 21:30:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-21 21:30:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/login.php
INFO - 2018-05-21 21:30:42 --> Config Class Initialized
INFO - 2018-05-21 21:30:42 --> Hooks Class Initialized
DEBUG - 2018-05-21 21:30:42 --> UTF-8 Support Enabled
INFO - 2018-05-21 21:30:42 --> Utf8 Class Initialized
INFO - 2018-05-21 21:30:42 --> URI Class Initialized
INFO - 2018-05-21 21:30:42 --> Router Class Initialized
INFO - 2018-05-21 21:30:42 --> Output Class Initialized
INFO - 2018-05-21 21:30:42 --> Security Class Initialized
DEBUG - 2018-05-21 21:30:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-21 21:30:42 --> Input Class Initialized
INFO - 2018-05-21 21:30:42 --> Language Class Initialized
ERROR - 2018-05-21 21:30:42 --> 404 Page Not Found: /index
INFO - 2018-05-21 21:30:43 --> Config Class Initialized
INFO - 2018-05-21 21:30:43 --> Hooks Class Initialized
DEBUG - 2018-05-21 21:30:43 --> UTF-8 Support Enabled
INFO - 2018-05-21 21:30:43 --> Utf8 Class Initialized
INFO - 2018-05-21 21:30:43 --> URI Class Initialized
INFO - 2018-05-21 21:30:43 --> Router Class Initialized
INFO - 2018-05-21 21:30:43 --> Output Class Initialized
INFO - 2018-05-21 21:30:43 --> Security Class Initialized
DEBUG - 2018-05-21 21:30:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-21 21:30:43 --> Input Class Initialized
INFO - 2018-05-21 21:30:43 --> Language Class Initialized
ERROR - 2018-05-21 21:30:43 --> 404 Page Not Found: /index
INFO - 2018-05-21 21:30:43 --> Config Class Initialized
INFO - 2018-05-21 21:30:43 --> Hooks Class Initialized
DEBUG - 2018-05-21 21:30:43 --> UTF-8 Support Enabled
INFO - 2018-05-21 21:30:43 --> Utf8 Class Initialized
INFO - 2018-05-21 21:30:43 --> URI Class Initialized
INFO - 2018-05-21 21:30:43 --> Router Class Initialized
INFO - 2018-05-21 21:30:43 --> Output Class Initialized
INFO - 2018-05-21 21:30:43 --> Security Class Initialized
DEBUG - 2018-05-21 21:30:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-21 21:30:43 --> Input Class Initialized
INFO - 2018-05-21 21:30:43 --> Language Class Initialized
ERROR - 2018-05-21 21:30:43 --> 404 Page Not Found: /index
INFO - 2018-05-21 21:30:43 --> Config Class Initialized
INFO - 2018-05-21 21:30:44 --> Hooks Class Initialized
DEBUG - 2018-05-21 21:30:44 --> UTF-8 Support Enabled
INFO - 2018-05-21 21:30:44 --> Utf8 Class Initialized
INFO - 2018-05-21 21:30:44 --> URI Class Initialized
INFO - 2018-05-21 21:30:44 --> Config Class Initialized
INFO - 2018-05-21 21:30:44 --> Hooks Class Initialized
INFO - 2018-05-21 21:30:44 --> Router Class Initialized
INFO - 2018-05-21 21:30:44 --> Output Class Initialized
DEBUG - 2018-05-21 21:30:44 --> UTF-8 Support Enabled
INFO - 2018-05-21 21:30:44 --> Utf8 Class Initialized
INFO - 2018-05-21 21:30:44 --> Security Class Initialized
INFO - 2018-05-21 21:30:44 --> URI Class Initialized
DEBUG - 2018-05-21 21:30:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-21 21:30:44 --> Input Class Initialized
INFO - 2018-05-21 21:30:44 --> Router Class Initialized
INFO - 2018-05-21 21:30:44 --> Language Class Initialized
INFO - 2018-05-21 21:30:44 --> Output Class Initialized
ERROR - 2018-05-21 21:30:44 --> 404 Page Not Found: /index
INFO - 2018-05-21 21:30:44 --> Security Class Initialized
DEBUG - 2018-05-21 21:30:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-21 21:30:44 --> Input Class Initialized
INFO - 2018-05-21 21:30:44 --> Language Class Initialized
ERROR - 2018-05-21 21:30:44 --> 404 Page Not Found: /index
INFO - 2018-05-21 21:30:44 --> Config Class Initialized
INFO - 2018-05-21 21:30:44 --> Hooks Class Initialized
DEBUG - 2018-05-21 21:30:44 --> UTF-8 Support Enabled
INFO - 2018-05-21 21:30:44 --> Utf8 Class Initialized
INFO - 2018-05-21 21:30:44 --> URI Class Initialized
INFO - 2018-05-21 21:30:44 --> Config Class Initialized
INFO - 2018-05-21 21:30:44 --> Hooks Class Initialized
INFO - 2018-05-21 21:30:44 --> Router Class Initialized
INFO - 2018-05-21 21:30:44 --> Output Class Initialized
DEBUG - 2018-05-21 21:30:44 --> UTF-8 Support Enabled
INFO - 2018-05-21 21:30:44 --> Utf8 Class Initialized
INFO - 2018-05-21 21:30:44 --> Security Class Initialized
INFO - 2018-05-21 21:30:44 --> URI Class Initialized
DEBUG - 2018-05-21 21:30:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-21 21:30:44 --> Input Class Initialized
INFO - 2018-05-21 21:30:44 --> Router Class Initialized
INFO - 2018-05-21 21:30:44 --> Language Class Initialized
INFO - 2018-05-21 21:30:44 --> Output Class Initialized
ERROR - 2018-05-21 21:30:44 --> 404 Page Not Found: /index
INFO - 2018-05-21 21:30:44 --> Security Class Initialized
DEBUG - 2018-05-21 21:30:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-21 21:30:44 --> Input Class Initialized
INFO - 2018-05-21 21:30:44 --> Language Class Initialized
ERROR - 2018-05-21 21:30:44 --> 404 Page Not Found: /index
INFO - 2018-05-21 21:30:44 --> Config Class Initialized
INFO - 2018-05-21 21:30:44 --> Hooks Class Initialized
DEBUG - 2018-05-21 21:30:44 --> UTF-8 Support Enabled
INFO - 2018-05-21 21:30:44 --> Utf8 Class Initialized
INFO - 2018-05-21 21:30:44 --> URI Class Initialized
INFO - 2018-05-21 21:30:44 --> Router Class Initialized
INFO - 2018-05-21 21:30:44 --> Output Class Initialized
INFO - 2018-05-21 21:30:44 --> Security Class Initialized
DEBUG - 2018-05-21 21:30:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-21 21:30:44 --> Input Class Initialized
INFO - 2018-05-21 21:30:44 --> Language Class Initialized
ERROR - 2018-05-21 21:30:44 --> 404 Page Not Found: /index
INFO - 2018-05-21 21:30:44 --> Config Class Initialized
INFO - 2018-05-21 21:30:44 --> Hooks Class Initialized
DEBUG - 2018-05-21 21:30:44 --> UTF-8 Support Enabled
INFO - 2018-05-21 21:30:44 --> Utf8 Class Initialized
INFO - 2018-05-21 21:30:44 --> URI Class Initialized
INFO - 2018-05-21 21:30:44 --> Router Class Initialized
INFO - 2018-05-21 21:30:44 --> Output Class Initialized
INFO - 2018-05-21 21:30:44 --> Security Class Initialized
DEBUG - 2018-05-21 21:30:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-21 21:30:44 --> Input Class Initialized
INFO - 2018-05-21 21:30:44 --> Language Class Initialized
ERROR - 2018-05-21 21:30:44 --> 404 Page Not Found: /index
INFO - 2018-05-21 21:30:45 --> Config Class Initialized
INFO - 2018-05-21 21:30:45 --> Hooks Class Initialized
DEBUG - 2018-05-21 21:30:45 --> UTF-8 Support Enabled
INFO - 2018-05-21 21:30:45 --> Utf8 Class Initialized
INFO - 2018-05-21 21:30:45 --> URI Class Initialized
INFO - 2018-05-21 21:30:45 --> Router Class Initialized
INFO - 2018-05-21 21:30:45 --> Output Class Initialized
INFO - 2018-05-21 21:30:45 --> Security Class Initialized
DEBUG - 2018-05-21 21:30:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-21 21:30:45 --> Input Class Initialized
INFO - 2018-05-21 21:30:45 --> Language Class Initialized
INFO - 2018-05-21 21:30:45 --> Language Class Initialized
INFO - 2018-05-21 21:30:45 --> Config Class Initialized
INFO - 2018-05-21 21:30:45 --> Loader Class Initialized
DEBUG - 2018-05-21 21:30:45 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-21 21:30:45 --> Helper loaded: url_helper
INFO - 2018-05-21 21:30:45 --> Helper loaded: form_helper
INFO - 2018-05-21 21:30:45 --> Helper loaded: date_helper
INFO - 2018-05-21 21:30:45 --> Helper loaded: util_helper
INFO - 2018-05-21 21:30:45 --> Helper loaded: text_helper
INFO - 2018-05-21 21:30:45 --> Helper loaded: string_helper
INFO - 2018-05-21 21:30:45 --> Database Driver Class Initialized
DEBUG - 2018-05-21 21:30:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-21 21:30:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-21 21:30:46 --> Email Class Initialized
INFO - 2018-05-21 21:30:46 --> Controller Class Initialized
DEBUG - 2018-05-21 21:30:46 --> Login MX_Controller Initialized
INFO - 2018-05-21 21:30:46 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-21 21:30:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-21 21:30:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-21 21:30:46 --> Email starts for user@colin.com fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-05-21 21:30:46 --> User session created for 4
INFO - 2018-05-21 21:30:46 --> Login status user@colin.com - success
INFO - 2018-05-21 21:30:46 --> Final output sent to browser
DEBUG - 2018-05-21 21:30:46 --> Total execution time: 0.7587
INFO - 2018-05-21 21:30:46 --> Config Class Initialized
INFO - 2018-05-21 21:30:46 --> Hooks Class Initialized
DEBUG - 2018-05-21 21:30:46 --> UTF-8 Support Enabled
INFO - 2018-05-21 21:30:46 --> Utf8 Class Initialized
INFO - 2018-05-21 21:30:46 --> URI Class Initialized
INFO - 2018-05-21 21:30:46 --> Router Class Initialized
INFO - 2018-05-21 21:30:46 --> Output Class Initialized
INFO - 2018-05-21 21:30:46 --> Security Class Initialized
DEBUG - 2018-05-21 21:30:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-21 21:30:46 --> Input Class Initialized
INFO - 2018-05-21 21:30:46 --> Language Class Initialized
INFO - 2018-05-21 21:30:46 --> Language Class Initialized
INFO - 2018-05-21 21:30:46 --> Config Class Initialized
INFO - 2018-05-21 21:30:46 --> Loader Class Initialized
DEBUG - 2018-05-21 21:30:46 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-21 21:30:46 --> Helper loaded: url_helper
INFO - 2018-05-21 21:30:46 --> Helper loaded: form_helper
INFO - 2018-05-21 21:30:46 --> Helper loaded: date_helper
INFO - 2018-05-21 21:30:46 --> Helper loaded: util_helper
INFO - 2018-05-21 21:30:46 --> Helper loaded: text_helper
INFO - 2018-05-21 21:30:46 --> Helper loaded: string_helper
INFO - 2018-05-21 21:30:46 --> Database Driver Class Initialized
DEBUG - 2018-05-21 21:30:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-21 21:30:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-21 21:30:46 --> Email Class Initialized
INFO - 2018-05-21 21:30:46 --> Controller Class Initialized
DEBUG - 2018-05-21 21:30:46 --> Home MX_Controller Initialized
DEBUG - 2018-05-21 21:30:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-21 21:30:46 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-21 21:30:46 --> Login MX_Controller Initialized
INFO - 2018-05-21 21:30:46 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-21 21:30:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-21 21:30:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-21 21:30:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-21 21:30:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-21 21:30:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-21 21:30:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-21 21:30:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-21 21:30:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-05-21 21:30:47 --> Final output sent to browser
DEBUG - 2018-05-21 21:30:47 --> Total execution time: 0.8510
INFO - 2018-05-21 21:30:47 --> Config Class Initialized
INFO - 2018-05-21 21:30:47 --> Hooks Class Initialized
DEBUG - 2018-05-21 21:30:47 --> UTF-8 Support Enabled
INFO - 2018-05-21 21:30:47 --> Utf8 Class Initialized
INFO - 2018-05-21 21:30:47 --> URI Class Initialized
INFO - 2018-05-21 21:30:47 --> Router Class Initialized
INFO - 2018-05-21 21:30:47 --> Output Class Initialized
INFO - 2018-05-21 21:30:47 --> Security Class Initialized
DEBUG - 2018-05-21 21:30:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-21 21:30:47 --> Input Class Initialized
INFO - 2018-05-21 21:30:47 --> Language Class Initialized
ERROR - 2018-05-21 21:30:47 --> 404 Page Not Found: /index
INFO - 2018-05-21 21:30:47 --> Config Class Initialized
INFO - 2018-05-21 21:30:47 --> Hooks Class Initialized
DEBUG - 2018-05-21 21:30:47 --> UTF-8 Support Enabled
INFO - 2018-05-21 21:30:47 --> Utf8 Class Initialized
INFO - 2018-05-21 21:30:47 --> URI Class Initialized
INFO - 2018-05-21 21:30:47 --> Router Class Initialized
INFO - 2018-05-21 21:30:47 --> Output Class Initialized
INFO - 2018-05-21 21:30:47 --> Security Class Initialized
DEBUG - 2018-05-21 21:30:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-21 21:30:47 --> Input Class Initialized
INFO - 2018-05-21 21:30:47 --> Language Class Initialized
ERROR - 2018-05-21 21:30:47 --> 404 Page Not Found: /index
INFO - 2018-05-21 21:30:48 --> Config Class Initialized
INFO - 2018-05-21 21:30:48 --> Hooks Class Initialized
DEBUG - 2018-05-21 21:30:48 --> UTF-8 Support Enabled
INFO - 2018-05-21 21:30:48 --> Utf8 Class Initialized
INFO - 2018-05-21 21:30:48 --> Config Class Initialized
INFO - 2018-05-21 21:30:48 --> Hooks Class Initialized
INFO - 2018-05-21 21:30:48 --> URI Class Initialized
DEBUG - 2018-05-21 21:30:48 --> UTF-8 Support Enabled
INFO - 2018-05-21 21:30:48 --> Router Class Initialized
INFO - 2018-05-21 21:30:48 --> Utf8 Class Initialized
INFO - 2018-05-21 21:30:48 --> Output Class Initialized
INFO - 2018-05-21 21:30:48 --> URI Class Initialized
INFO - 2018-05-21 21:30:48 --> Security Class Initialized
DEBUG - 2018-05-21 21:30:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-21 21:30:48 --> Router Class Initialized
INFO - 2018-05-21 21:30:48 --> Input Class Initialized
INFO - 2018-05-21 21:30:48 --> Language Class Initialized
ERROR - 2018-05-21 21:30:48 --> 404 Page Not Found: /index
INFO - 2018-05-21 21:30:48 --> Output Class Initialized
INFO - 2018-05-21 21:30:48 --> Security Class Initialized
DEBUG - 2018-05-21 21:30:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-21 21:30:48 --> Input Class Initialized
INFO - 2018-05-21 21:30:48 --> Language Class Initialized
INFO - 2018-05-21 21:30:48 --> Language Class Initialized
INFO - 2018-05-21 21:30:48 --> Config Class Initialized
INFO - 2018-05-21 21:30:48 --> Loader Class Initialized
DEBUG - 2018-05-21 21:30:48 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-21 21:30:48 --> Helper loaded: url_helper
INFO - 2018-05-21 21:30:48 --> Helper loaded: form_helper
INFO - 2018-05-21 21:30:48 --> Helper loaded: date_helper
INFO - 2018-05-21 21:30:48 --> Helper loaded: util_helper
INFO - 2018-05-21 21:30:48 --> Helper loaded: text_helper
INFO - 2018-05-21 21:30:48 --> Helper loaded: string_helper
INFO - 2018-05-21 21:30:48 --> Database Driver Class Initialized
DEBUG - 2018-05-21 21:30:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-21 21:30:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-21 21:30:48 --> Email Class Initialized
INFO - 2018-05-21 21:30:48 --> Controller Class Initialized
DEBUG - 2018-05-21 21:30:48 --> Login MX_Controller Initialized
INFO - 2018-05-21 21:30:48 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-21 21:30:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-21 21:30:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-21 21:30:48 --> Email starts for user@colin.com fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-05-21 21:30:48 --> Login status user@colin.com - failure
INFO - 2018-05-21 21:30:48 --> Final output sent to browser
DEBUG - 2018-05-21 21:30:48 --> Total execution time: 0.3512
INFO - 2018-05-21 21:30:50 --> Config Class Initialized
INFO - 2018-05-21 21:30:50 --> Hooks Class Initialized
DEBUG - 2018-05-21 21:30:50 --> UTF-8 Support Enabled
INFO - 2018-05-21 21:30:50 --> Utf8 Class Initialized
INFO - 2018-05-21 21:30:50 --> URI Class Initialized
INFO - 2018-05-21 21:30:50 --> Router Class Initialized
INFO - 2018-05-21 21:30:50 --> Output Class Initialized
INFO - 2018-05-21 21:30:50 --> Security Class Initialized
DEBUG - 2018-05-21 21:30:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-21 21:30:50 --> Input Class Initialized
INFO - 2018-05-21 21:30:50 --> Language Class Initialized
ERROR - 2018-05-21 21:30:50 --> 404 Page Not Found: /index
INFO - 2018-05-21 21:30:50 --> Config Class Initialized
INFO - 2018-05-21 21:30:50 --> Hooks Class Initialized
DEBUG - 2018-05-21 21:30:50 --> UTF-8 Support Enabled
INFO - 2018-05-21 21:30:50 --> Utf8 Class Initialized
INFO - 2018-05-21 21:30:50 --> URI Class Initialized
INFO - 2018-05-21 21:30:50 --> Router Class Initialized
INFO - 2018-05-21 21:30:50 --> Output Class Initialized
INFO - 2018-05-21 21:30:50 --> Security Class Initialized
DEBUG - 2018-05-21 21:30:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-21 21:30:50 --> Input Class Initialized
INFO - 2018-05-21 21:30:50 --> Language Class Initialized
ERROR - 2018-05-21 21:30:50 --> 404 Page Not Found: /index
INFO - 2018-05-21 21:30:50 --> Config Class Initialized
INFO - 2018-05-21 21:30:50 --> Hooks Class Initialized
DEBUG - 2018-05-21 21:30:50 --> UTF-8 Support Enabled
INFO - 2018-05-21 21:30:50 --> Utf8 Class Initialized
INFO - 2018-05-21 21:30:50 --> URI Class Initialized
INFO - 2018-05-21 21:30:50 --> Router Class Initialized
INFO - 2018-05-21 21:30:50 --> Output Class Initialized
INFO - 2018-05-21 21:30:50 --> Security Class Initialized
DEBUG - 2018-05-21 21:30:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-21 21:30:50 --> Input Class Initialized
INFO - 2018-05-21 21:30:50 --> Language Class Initialized
ERROR - 2018-05-21 21:30:50 --> 404 Page Not Found: /index
INFO - 2018-05-21 21:30:55 --> Config Class Initialized
INFO - 2018-05-21 21:30:55 --> Hooks Class Initialized
DEBUG - 2018-05-21 21:30:55 --> UTF-8 Support Enabled
INFO - 2018-05-21 21:30:55 --> Utf8 Class Initialized
INFO - 2018-05-21 21:30:55 --> URI Class Initialized
INFO - 2018-05-21 21:30:55 --> Router Class Initialized
INFO - 2018-05-21 21:30:55 --> Output Class Initialized
INFO - 2018-05-21 21:30:55 --> Security Class Initialized
DEBUG - 2018-05-21 21:30:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-21 21:30:55 --> Input Class Initialized
INFO - 2018-05-21 21:30:55 --> Language Class Initialized
INFO - 2018-05-21 21:30:55 --> Language Class Initialized
INFO - 2018-05-21 21:30:55 --> Config Class Initialized
INFO - 2018-05-21 21:30:55 --> Loader Class Initialized
DEBUG - 2018-05-21 21:30:55 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-21 21:30:55 --> Helper loaded: url_helper
INFO - 2018-05-21 21:30:55 --> Helper loaded: form_helper
INFO - 2018-05-21 21:30:55 --> Helper loaded: date_helper
INFO - 2018-05-21 21:30:55 --> Helper loaded: util_helper
INFO - 2018-05-21 21:30:55 --> Helper loaded: text_helper
INFO - 2018-05-21 21:30:55 --> Helper loaded: string_helper
INFO - 2018-05-21 21:30:55 --> Database Driver Class Initialized
DEBUG - 2018-05-21 21:30:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-21 21:30:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-21 21:30:55 --> Email Class Initialized
INFO - 2018-05-21 21:30:55 --> Controller Class Initialized
DEBUG - 2018-05-21 21:30:55 --> Login MX_Controller Initialized
INFO - 2018-05-21 21:30:55 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-21 21:30:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-21 21:30:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-21 21:30:55 --> Email starts for admin@colin.com fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-05-21 21:30:55 --> User session created for 1
INFO - 2018-05-21 21:30:55 --> Login status admin@colin.com - success
INFO - 2018-05-21 21:30:55 --> Final output sent to browser
DEBUG - 2018-05-21 21:30:55 --> Total execution time: 0.4672
INFO - 2018-05-21 21:30:55 --> Config Class Initialized
INFO - 2018-05-21 21:30:55 --> Hooks Class Initialized
DEBUG - 2018-05-21 21:30:55 --> UTF-8 Support Enabled
INFO - 2018-05-21 21:30:55 --> Utf8 Class Initialized
INFO - 2018-05-21 21:30:55 --> URI Class Initialized
INFO - 2018-05-21 21:30:55 --> Router Class Initialized
INFO - 2018-05-21 21:30:55 --> Output Class Initialized
INFO - 2018-05-21 21:30:55 --> Security Class Initialized
DEBUG - 2018-05-21 21:30:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-21 21:30:55 --> Input Class Initialized
INFO - 2018-05-21 21:30:55 --> Language Class Initialized
INFO - 2018-05-21 21:30:55 --> Language Class Initialized
INFO - 2018-05-21 21:30:55 --> Config Class Initialized
INFO - 2018-05-21 21:30:55 --> Loader Class Initialized
DEBUG - 2018-05-21 21:30:55 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-21 21:30:55 --> Helper loaded: url_helper
INFO - 2018-05-21 21:30:55 --> Helper loaded: form_helper
INFO - 2018-05-21 21:30:55 --> Helper loaded: date_helper
INFO - 2018-05-21 21:30:55 --> Helper loaded: util_helper
INFO - 2018-05-21 21:30:55 --> Helper loaded: text_helper
INFO - 2018-05-21 21:30:55 --> Helper loaded: string_helper
INFO - 2018-05-21 21:30:55 --> Database Driver Class Initialized
DEBUG - 2018-05-21 21:30:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-21 21:30:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-21 21:30:55 --> Email Class Initialized
INFO - 2018-05-21 21:30:55 --> Controller Class Initialized
DEBUG - 2018-05-21 21:30:55 --> Admin MX_Controller Initialized
INFO - 2018-05-21 21:30:55 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-21 21:30:55 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-21 21:30:55 --> Login MX_Controller Initialized
DEBUG - 2018-05-21 21:30:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-21 21:30:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-21 21:30:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-05-21 21:30:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-05-21 21:30:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-05-21 21:30:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-05-21 21:30:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-05-21 21:30:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/dashboard.php
INFO - 2018-05-21 21:30:57 --> Final output sent to browser
DEBUG - 2018-05-21 21:30:57 --> Total execution time: 1.7176
INFO - 2018-05-21 21:30:57 --> Config Class Initialized
INFO - 2018-05-21 21:30:57 --> Hooks Class Initialized
DEBUG - 2018-05-21 21:30:57 --> UTF-8 Support Enabled
INFO - 2018-05-21 21:30:57 --> Utf8 Class Initialized
INFO - 2018-05-21 21:30:57 --> URI Class Initialized
INFO - 2018-05-21 21:30:57 --> Router Class Initialized
INFO - 2018-05-21 21:30:57 --> Output Class Initialized
INFO - 2018-05-21 21:30:57 --> Security Class Initialized
DEBUG - 2018-05-21 21:30:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-21 21:30:57 --> Input Class Initialized
INFO - 2018-05-21 21:30:57 --> Language Class Initialized
ERROR - 2018-05-21 21:30:57 --> 404 Page Not Found: /index
INFO - 2018-05-21 21:30:57 --> Config Class Initialized
INFO - 2018-05-21 21:30:57 --> Hooks Class Initialized
DEBUG - 2018-05-21 21:30:57 --> UTF-8 Support Enabled
INFO - 2018-05-21 21:30:57 --> Utf8 Class Initialized
INFO - 2018-05-21 21:30:58 --> URI Class Initialized
INFO - 2018-05-21 21:30:58 --> Router Class Initialized
INFO - 2018-05-21 21:30:58 --> Output Class Initialized
INFO - 2018-05-21 21:30:58 --> Security Class Initialized
DEBUG - 2018-05-21 21:30:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-21 21:30:58 --> Input Class Initialized
INFO - 2018-05-21 21:30:58 --> Language Class Initialized
ERROR - 2018-05-21 21:30:58 --> 404 Page Not Found: /index
INFO - 2018-05-21 21:31:00 --> Config Class Initialized
INFO - 2018-05-21 21:31:00 --> Hooks Class Initialized
DEBUG - 2018-05-21 21:31:00 --> UTF-8 Support Enabled
INFO - 2018-05-21 21:31:00 --> Utf8 Class Initialized
INFO - 2018-05-21 21:31:00 --> URI Class Initialized
INFO - 2018-05-21 21:31:00 --> Router Class Initialized
INFO - 2018-05-21 21:31:00 --> Output Class Initialized
INFO - 2018-05-21 21:31:00 --> Security Class Initialized
DEBUG - 2018-05-21 21:31:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-21 21:31:00 --> Input Class Initialized
INFO - 2018-05-21 21:31:00 --> Language Class Initialized
ERROR - 2018-05-21 21:31:00 --> 404 Page Not Found: /index
INFO - 2018-05-21 21:31:00 --> Config Class Initialized
INFO - 2018-05-21 21:31:00 --> Hooks Class Initialized
DEBUG - 2018-05-21 21:31:00 --> UTF-8 Support Enabled
INFO - 2018-05-21 21:31:00 --> Utf8 Class Initialized
INFO - 2018-05-21 21:31:00 --> URI Class Initialized
INFO - 2018-05-21 21:31:00 --> Router Class Initialized
INFO - 2018-05-21 21:31:00 --> Output Class Initialized
INFO - 2018-05-21 21:31:00 --> Security Class Initialized
DEBUG - 2018-05-21 21:31:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-21 21:31:00 --> Input Class Initialized
INFO - 2018-05-21 21:31:00 --> Language Class Initialized
ERROR - 2018-05-21 21:31:00 --> 404 Page Not Found: /index
INFO - 2018-05-21 21:31:04 --> Config Class Initialized
INFO - 2018-05-21 21:31:04 --> Hooks Class Initialized
DEBUG - 2018-05-21 21:31:04 --> UTF-8 Support Enabled
INFO - 2018-05-21 21:31:04 --> Utf8 Class Initialized
INFO - 2018-05-21 21:31:04 --> URI Class Initialized
INFO - 2018-05-21 21:31:04 --> Router Class Initialized
INFO - 2018-05-21 21:31:04 --> Output Class Initialized
INFO - 2018-05-21 21:31:04 --> Security Class Initialized
DEBUG - 2018-05-21 21:31:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-21 21:31:04 --> Input Class Initialized
INFO - 2018-05-21 21:31:04 --> Language Class Initialized
ERROR - 2018-05-21 21:31:04 --> 404 Page Not Found: /index
INFO - 2018-05-21 21:31:04 --> Config Class Initialized
INFO - 2018-05-21 21:31:04 --> Hooks Class Initialized
DEBUG - 2018-05-21 21:31:04 --> UTF-8 Support Enabled
INFO - 2018-05-21 21:31:04 --> Utf8 Class Initialized
INFO - 2018-05-21 21:31:04 --> URI Class Initialized
INFO - 2018-05-21 21:31:04 --> Router Class Initialized
INFO - 2018-05-21 21:31:04 --> Output Class Initialized
INFO - 2018-05-21 21:31:04 --> Security Class Initialized
DEBUG - 2018-05-21 21:31:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-21 21:31:04 --> Input Class Initialized
INFO - 2018-05-21 21:31:04 --> Language Class Initialized
ERROR - 2018-05-21 21:31:04 --> 404 Page Not Found: /index
INFO - 2018-05-21 21:31:04 --> Config Class Initialized
INFO - 2018-05-21 21:31:04 --> Hooks Class Initialized
DEBUG - 2018-05-21 21:31:04 --> UTF-8 Support Enabled
INFO - 2018-05-21 21:31:04 --> Utf8 Class Initialized
INFO - 2018-05-21 21:31:04 --> URI Class Initialized
INFO - 2018-05-21 21:31:04 --> Router Class Initialized
INFO - 2018-05-21 21:31:04 --> Output Class Initialized
INFO - 2018-05-21 21:31:04 --> Security Class Initialized
DEBUG - 2018-05-21 21:31:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-21 21:31:05 --> Input Class Initialized
INFO - 2018-05-21 21:31:05 --> Language Class Initialized
ERROR - 2018-05-21 21:31:05 --> 404 Page Not Found: /index
INFO - 2018-05-21 21:31:05 --> Config Class Initialized
INFO - 2018-05-21 21:31:05 --> Hooks Class Initialized
DEBUG - 2018-05-21 21:31:05 --> UTF-8 Support Enabled
INFO - 2018-05-21 21:31:05 --> Utf8 Class Initialized
INFO - 2018-05-21 21:31:05 --> URI Class Initialized
INFO - 2018-05-21 21:31:05 --> Router Class Initialized
INFO - 2018-05-21 21:31:05 --> Output Class Initialized
INFO - 2018-05-21 21:31:05 --> Security Class Initialized
DEBUG - 2018-05-21 21:31:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-21 21:31:05 --> Input Class Initialized
INFO - 2018-05-21 21:31:05 --> Language Class Initialized
ERROR - 2018-05-21 21:31:05 --> 404 Page Not Found: /index
INFO - 2018-05-21 21:34:11 --> Config Class Initialized
INFO - 2018-05-21 21:34:11 --> Hooks Class Initialized
DEBUG - 2018-05-21 21:34:11 --> UTF-8 Support Enabled
INFO - 2018-05-21 21:34:11 --> Utf8 Class Initialized
INFO - 2018-05-21 21:34:11 --> URI Class Initialized
INFO - 2018-05-21 21:34:11 --> Router Class Initialized
INFO - 2018-05-21 21:34:11 --> Output Class Initialized
INFO - 2018-05-21 21:34:11 --> Security Class Initialized
DEBUG - 2018-05-21 21:34:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-21 21:34:11 --> Input Class Initialized
INFO - 2018-05-21 21:34:12 --> Language Class Initialized
INFO - 2018-05-21 21:34:12 --> Language Class Initialized
INFO - 2018-05-21 21:34:12 --> Config Class Initialized
INFO - 2018-05-21 21:34:12 --> Loader Class Initialized
DEBUG - 2018-05-21 21:34:12 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-21 21:34:12 --> Helper loaded: url_helper
INFO - 2018-05-21 21:34:12 --> Helper loaded: form_helper
INFO - 2018-05-21 21:34:12 --> Helper loaded: date_helper
INFO - 2018-05-21 21:34:12 --> Helper loaded: util_helper
INFO - 2018-05-21 21:34:12 --> Helper loaded: text_helper
INFO - 2018-05-21 21:34:12 --> Helper loaded: string_helper
INFO - 2018-05-21 21:34:12 --> Database Driver Class Initialized
DEBUG - 2018-05-21 21:34:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-21 21:34:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-21 21:34:12 --> Email Class Initialized
INFO - 2018-05-21 21:34:12 --> Controller Class Initialized
DEBUG - 2018-05-21 21:34:12 --> Home MX_Controller Initialized
DEBUG - 2018-05-21 21:34:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-21 21:34:12 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-21 21:34:12 --> Login MX_Controller Initialized
INFO - 2018-05-21 21:34:12 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-21 21:34:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-21 21:34:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-21 21:34:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-21 21:34:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-21 21:34:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-21 21:34:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-21 21:34:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-21 21:34:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-05-21 21:34:12 --> Final output sent to browser
DEBUG - 2018-05-21 21:34:12 --> Total execution time: 0.4766
INFO - 2018-05-21 21:34:12 --> Config Class Initialized
INFO - 2018-05-21 21:34:12 --> Hooks Class Initialized
INFO - 2018-05-21 21:34:12 --> Config Class Initialized
DEBUG - 2018-05-21 21:34:12 --> UTF-8 Support Enabled
INFO - 2018-05-21 21:34:12 --> Utf8 Class Initialized
INFO - 2018-05-21 21:34:12 --> URI Class Initialized
INFO - 2018-05-21 21:34:12 --> Router Class Initialized
INFO - 2018-05-21 21:34:12 --> Output Class Initialized
INFO - 2018-05-21 21:34:12 --> Security Class Initialized
DEBUG - 2018-05-21 21:34:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-21 21:34:12 --> Input Class Initialized
INFO - 2018-05-21 21:34:12 --> Language Class Initialized
ERROR - 2018-05-21 21:34:12 --> 404 Page Not Found: /index
INFO - 2018-05-21 21:34:12 --> Hooks Class Initialized
DEBUG - 2018-05-21 21:34:12 --> UTF-8 Support Enabled
INFO - 2018-05-21 21:34:12 --> Utf8 Class Initialized
INFO - 2018-05-21 21:34:12 --> URI Class Initialized
INFO - 2018-05-21 21:34:12 --> Router Class Initialized
INFO - 2018-05-21 21:34:12 --> Output Class Initialized
INFO - 2018-05-21 21:34:13 --> Security Class Initialized
DEBUG - 2018-05-21 21:34:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-21 21:34:13 --> Input Class Initialized
INFO - 2018-05-21 21:34:13 --> Language Class Initialized
ERROR - 2018-05-21 21:34:13 --> 404 Page Not Found: /index
INFO - 2018-05-21 21:34:13 --> Config Class Initialized
INFO - 2018-05-21 21:34:13 --> Hooks Class Initialized
DEBUG - 2018-05-21 21:34:13 --> UTF-8 Support Enabled
INFO - 2018-05-21 21:34:13 --> Utf8 Class Initialized
INFO - 2018-05-21 21:34:13 --> URI Class Initialized
INFO - 2018-05-21 21:34:13 --> Router Class Initialized
INFO - 2018-05-21 21:34:13 --> Output Class Initialized
INFO - 2018-05-21 21:34:13 --> Security Class Initialized
DEBUG - 2018-05-21 21:34:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-21 21:34:13 --> Input Class Initialized
INFO - 2018-05-21 21:34:13 --> Language Class Initialized
ERROR - 2018-05-21 21:34:13 --> 404 Page Not Found: /index
INFO - 2018-05-21 21:34:13 --> Config Class Initialized
INFO - 2018-05-21 21:34:13 --> Hooks Class Initialized
DEBUG - 2018-05-21 21:34:13 --> UTF-8 Support Enabled
INFO - 2018-05-21 21:34:13 --> Utf8 Class Initialized
INFO - 2018-05-21 21:34:13 --> URI Class Initialized
INFO - 2018-05-21 21:34:13 --> Router Class Initialized
INFO - 2018-05-21 21:34:13 --> Output Class Initialized
INFO - 2018-05-21 21:34:13 --> Security Class Initialized
DEBUG - 2018-05-21 21:34:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-21 21:34:13 --> Input Class Initialized
INFO - 2018-05-21 21:34:13 --> Language Class Initialized
ERROR - 2018-05-21 21:34:13 --> 404 Page Not Found: /index
INFO - 2018-05-21 21:34:16 --> Config Class Initialized
INFO - 2018-05-21 21:34:16 --> Hooks Class Initialized
DEBUG - 2018-05-21 21:34:16 --> UTF-8 Support Enabled
INFO - 2018-05-21 21:34:16 --> Utf8 Class Initialized
INFO - 2018-05-21 21:34:16 --> URI Class Initialized
INFO - 2018-05-21 21:34:16 --> Router Class Initialized
INFO - 2018-05-21 21:34:16 --> Output Class Initialized
INFO - 2018-05-21 21:34:16 --> Security Class Initialized
DEBUG - 2018-05-21 21:34:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-21 21:34:16 --> Input Class Initialized
INFO - 2018-05-21 21:34:16 --> Language Class Initialized
INFO - 2018-05-21 21:34:16 --> Language Class Initialized
INFO - 2018-05-21 21:34:16 --> Config Class Initialized
INFO - 2018-05-21 21:34:16 --> Loader Class Initialized
DEBUG - 2018-05-21 21:34:16 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-21 21:34:16 --> Helper loaded: url_helper
INFO - 2018-05-21 21:34:16 --> Helper loaded: form_helper
INFO - 2018-05-21 21:34:16 --> Helper loaded: date_helper
INFO - 2018-05-21 21:34:16 --> Helper loaded: util_helper
INFO - 2018-05-21 21:34:16 --> Helper loaded: text_helper
INFO - 2018-05-21 21:34:16 --> Helper loaded: string_helper
INFO - 2018-05-21 21:34:16 --> Database Driver Class Initialized
DEBUG - 2018-05-21 21:34:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-21 21:34:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-21 21:34:16 --> Email Class Initialized
INFO - 2018-05-21 21:34:17 --> Controller Class Initialized
DEBUG - 2018-05-21 21:34:17 --> Home MX_Controller Initialized
DEBUG - 2018-05-21 21:34:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-21 21:34:17 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-21 21:34:17 --> Login MX_Controller Initialized
INFO - 2018-05-21 21:34:17 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-21 21:34:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-21 21:34:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-21 21:34:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-21 21:34:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-21 21:34:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-21 21:34:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-21 21:34:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-21 21:34:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-05-21 21:34:17 --> Final output sent to browser
DEBUG - 2018-05-21 21:34:17 --> Total execution time: 0.4669
INFO - 2018-05-21 21:34:17 --> Config Class Initialized
INFO - 2018-05-21 21:34:17 --> Config Class Initialized
INFO - 2018-05-21 21:34:17 --> Hooks Class Initialized
INFO - 2018-05-21 21:34:17 --> Hooks Class Initialized
DEBUG - 2018-05-21 21:34:17 --> UTF-8 Support Enabled
INFO - 2018-05-21 21:34:17 --> Utf8 Class Initialized
INFO - 2018-05-21 21:34:17 --> URI Class Initialized
INFO - 2018-05-21 21:34:17 --> Router Class Initialized
INFO - 2018-05-21 21:34:17 --> Output Class Initialized
INFO - 2018-05-21 21:34:17 --> Security Class Initialized
DEBUG - 2018-05-21 21:34:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-21 21:34:17 --> Input Class Initialized
INFO - 2018-05-21 21:34:17 --> Language Class Initialized
ERROR - 2018-05-21 21:34:17 --> 404 Page Not Found: /index
DEBUG - 2018-05-21 21:34:17 --> UTF-8 Support Enabled
INFO - 2018-05-21 21:34:17 --> Utf8 Class Initialized
INFO - 2018-05-21 21:34:18 --> URI Class Initialized
INFO - 2018-05-21 21:34:18 --> Router Class Initialized
INFO - 2018-05-21 21:34:18 --> Output Class Initialized
INFO - 2018-05-21 21:34:18 --> Security Class Initialized
DEBUG - 2018-05-21 21:34:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-21 21:34:18 --> Input Class Initialized
INFO - 2018-05-21 21:34:18 --> Language Class Initialized
ERROR - 2018-05-21 21:34:18 --> 404 Page Not Found: /index
INFO - 2018-05-21 21:34:18 --> Config Class Initialized
INFO - 2018-05-21 21:34:18 --> Hooks Class Initialized
DEBUG - 2018-05-21 21:34:18 --> UTF-8 Support Enabled
INFO - 2018-05-21 21:34:18 --> Utf8 Class Initialized
INFO - 2018-05-21 21:34:18 --> URI Class Initialized
INFO - 2018-05-21 21:34:18 --> Router Class Initialized
INFO - 2018-05-21 21:34:18 --> Output Class Initialized
INFO - 2018-05-21 21:34:18 --> Security Class Initialized
DEBUG - 2018-05-21 21:34:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-21 21:34:18 --> Input Class Initialized
INFO - 2018-05-21 21:34:18 --> Language Class Initialized
ERROR - 2018-05-21 21:34:18 --> 404 Page Not Found: /index
INFO - 2018-05-21 21:34:18 --> Config Class Initialized
INFO - 2018-05-21 21:34:18 --> Hooks Class Initialized
DEBUG - 2018-05-21 21:34:18 --> UTF-8 Support Enabled
INFO - 2018-05-21 21:34:18 --> Utf8 Class Initialized
INFO - 2018-05-21 21:34:18 --> URI Class Initialized
INFO - 2018-05-21 21:34:18 --> Router Class Initialized
INFO - 2018-05-21 21:34:18 --> Output Class Initialized
INFO - 2018-05-21 21:34:18 --> Security Class Initialized
DEBUG - 2018-05-21 21:34:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-21 21:34:18 --> Input Class Initialized
INFO - 2018-05-21 21:34:18 --> Language Class Initialized
ERROR - 2018-05-21 21:34:18 --> 404 Page Not Found: /index
INFO - 2018-05-21 21:34:20 --> Config Class Initialized
INFO - 2018-05-21 21:34:20 --> Hooks Class Initialized
DEBUG - 2018-05-21 21:34:20 --> UTF-8 Support Enabled
INFO - 2018-05-21 21:34:20 --> Utf8 Class Initialized
INFO - 2018-05-21 21:34:20 --> URI Class Initialized
INFO - 2018-05-21 21:34:20 --> Router Class Initialized
INFO - 2018-05-21 21:34:20 --> Output Class Initialized
INFO - 2018-05-21 21:34:20 --> Security Class Initialized
DEBUG - 2018-05-21 21:34:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-21 21:34:20 --> Input Class Initialized
INFO - 2018-05-21 21:34:20 --> Language Class Initialized
INFO - 2018-05-21 21:34:20 --> Language Class Initialized
INFO - 2018-05-21 21:34:20 --> Config Class Initialized
INFO - 2018-05-21 21:34:20 --> Loader Class Initialized
DEBUG - 2018-05-21 21:34:20 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-21 21:34:20 --> Helper loaded: url_helper
INFO - 2018-05-21 21:34:20 --> Helper loaded: form_helper
INFO - 2018-05-21 21:34:20 --> Helper loaded: date_helper
INFO - 2018-05-21 21:34:20 --> Helper loaded: util_helper
INFO - 2018-05-21 21:34:20 --> Helper loaded: text_helper
INFO - 2018-05-21 21:34:20 --> Helper loaded: string_helper
INFO - 2018-05-21 21:34:20 --> Database Driver Class Initialized
DEBUG - 2018-05-21 21:34:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-21 21:34:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-21 21:34:20 --> Email Class Initialized
INFO - 2018-05-21 21:34:20 --> Controller Class Initialized
DEBUG - 2018-05-21 21:34:20 --> Home MX_Controller Initialized
DEBUG - 2018-05-21 21:34:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-21 21:34:20 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-21 21:34:20 --> Login MX_Controller Initialized
INFO - 2018-05-21 21:34:20 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-21 21:34:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-21 21:34:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-21 21:34:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-21 21:34:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-21 21:34:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-21 21:34:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-21 21:34:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-21 21:34:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-05-21 21:34:20 --> Final output sent to browser
DEBUG - 2018-05-21 21:34:21 --> Total execution time: 0.3829
INFO - 2018-05-21 21:34:21 --> Config Class Initialized
INFO - 2018-05-21 21:34:21 --> Config Class Initialized
INFO - 2018-05-21 21:34:21 --> Hooks Class Initialized
INFO - 2018-05-21 21:34:21 --> Hooks Class Initialized
DEBUG - 2018-05-21 21:34:21 --> UTF-8 Support Enabled
DEBUG - 2018-05-21 21:34:21 --> UTF-8 Support Enabled
INFO - 2018-05-21 21:34:21 --> Utf8 Class Initialized
INFO - 2018-05-21 21:34:21 --> Utf8 Class Initialized
INFO - 2018-05-21 21:34:21 --> URI Class Initialized
INFO - 2018-05-21 21:34:21 --> URI Class Initialized
INFO - 2018-05-21 21:34:21 --> Router Class Initialized
INFO - 2018-05-21 21:34:21 --> Router Class Initialized
INFO - 2018-05-21 21:34:21 --> Output Class Initialized
INFO - 2018-05-21 21:34:21 --> Security Class Initialized
DEBUG - 2018-05-21 21:34:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-21 21:34:21 --> Input Class Initialized
INFO - 2018-05-21 21:34:21 --> Language Class Initialized
ERROR - 2018-05-21 21:34:21 --> 404 Page Not Found: /index
INFO - 2018-05-21 21:34:21 --> Output Class Initialized
INFO - 2018-05-21 21:34:21 --> Config Class Initialized
INFO - 2018-05-21 21:34:21 --> Hooks Class Initialized
INFO - 2018-05-21 21:34:21 --> Security Class Initialized
DEBUG - 2018-05-21 21:34:21 --> UTF-8 Support Enabled
INFO - 2018-05-21 21:34:21 --> Utf8 Class Initialized
INFO - 2018-05-21 21:34:21 --> URI Class Initialized
INFO - 2018-05-21 21:34:21 --> Router Class Initialized
INFO - 2018-05-21 21:34:21 --> Output Class Initialized
INFO - 2018-05-21 21:34:21 --> Security Class Initialized
DEBUG - 2018-05-21 21:34:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-21 21:34:21 --> Input Class Initialized
INFO - 2018-05-21 21:34:21 --> Language Class Initialized
ERROR - 2018-05-21 21:34:21 --> 404 Page Not Found: /index
DEBUG - 2018-05-21 21:34:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-21 21:34:21 --> Input Class Initialized
INFO - 2018-05-21 21:34:21 --> Language Class Initialized
INFO - 2018-05-21 21:34:21 --> Config Class Initialized
INFO - 2018-05-21 21:34:21 --> Hooks Class Initialized
ERROR - 2018-05-21 21:34:21 --> 404 Page Not Found: /index
DEBUG - 2018-05-21 21:34:21 --> UTF-8 Support Enabled
INFO - 2018-05-21 21:34:21 --> Utf8 Class Initialized
INFO - 2018-05-21 21:34:21 --> URI Class Initialized
INFO - 2018-05-21 21:34:21 --> Router Class Initialized
INFO - 2018-05-21 21:34:21 --> Output Class Initialized
INFO - 2018-05-21 21:34:21 --> Security Class Initialized
DEBUG - 2018-05-21 21:34:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-21 21:34:21 --> Input Class Initialized
INFO - 2018-05-21 21:34:21 --> Language Class Initialized
ERROR - 2018-05-21 21:34:21 --> 404 Page Not Found: /index
INFO - 2018-05-21 21:34:32 --> Config Class Initialized
INFO - 2018-05-21 21:34:32 --> Hooks Class Initialized
DEBUG - 2018-05-21 21:34:32 --> UTF-8 Support Enabled
INFO - 2018-05-21 21:34:32 --> Utf8 Class Initialized
INFO - 2018-05-21 21:34:32 --> URI Class Initialized
INFO - 2018-05-21 21:34:32 --> Router Class Initialized
INFO - 2018-05-21 21:34:32 --> Output Class Initialized
INFO - 2018-05-21 21:34:32 --> Security Class Initialized
DEBUG - 2018-05-21 21:34:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-21 21:34:32 --> Input Class Initialized
INFO - 2018-05-21 21:34:32 --> Language Class Initialized
INFO - 2018-05-21 21:34:32 --> Language Class Initialized
INFO - 2018-05-21 21:34:32 --> Config Class Initialized
INFO - 2018-05-21 21:34:32 --> Loader Class Initialized
DEBUG - 2018-05-21 21:34:32 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-21 21:34:32 --> Helper loaded: url_helper
INFO - 2018-05-21 21:34:32 --> Helper loaded: form_helper
INFO - 2018-05-21 21:34:32 --> Helper loaded: date_helper
INFO - 2018-05-21 21:34:32 --> Helper loaded: util_helper
INFO - 2018-05-21 21:34:32 --> Helper loaded: text_helper
INFO - 2018-05-21 21:34:32 --> Helper loaded: string_helper
INFO - 2018-05-21 21:34:32 --> Database Driver Class Initialized
DEBUG - 2018-05-21 21:34:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-21 21:34:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-21 21:34:32 --> Email Class Initialized
INFO - 2018-05-21 21:34:32 --> Controller Class Initialized
DEBUG - 2018-05-21 21:34:32 --> Home MX_Controller Initialized
DEBUG - 2018-05-21 21:34:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-21 21:34:32 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-21 21:34:32 --> Login MX_Controller Initialized
INFO - 2018-05-21 21:34:32 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-21 21:34:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-21 21:34:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-21 21:34:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-21 21:34:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-21 21:34:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-21 21:34:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-21 21:34:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-21 21:34:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-05-21 21:34:32 --> Final output sent to browser
DEBUG - 2018-05-21 21:34:32 --> Total execution time: 0.4311
INFO - 2018-05-21 21:34:33 --> Config Class Initialized
INFO - 2018-05-21 21:34:33 --> Config Class Initialized
INFO - 2018-05-21 21:34:33 --> Hooks Class Initialized
INFO - 2018-05-21 21:34:33 --> Hooks Class Initialized
DEBUG - 2018-05-21 21:34:33 --> UTF-8 Support Enabled
DEBUG - 2018-05-21 21:34:33 --> UTF-8 Support Enabled
INFO - 2018-05-21 21:34:33 --> Utf8 Class Initialized
INFO - 2018-05-21 21:34:33 --> URI Class Initialized
INFO - 2018-05-21 21:34:33 --> Router Class Initialized
INFO - 2018-05-21 21:34:33 --> Output Class Initialized
INFO - 2018-05-21 21:34:33 --> Security Class Initialized
DEBUG - 2018-05-21 21:34:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-21 21:34:33 --> Input Class Initialized
INFO - 2018-05-21 21:34:33 --> Language Class Initialized
ERROR - 2018-05-21 21:34:33 --> 404 Page Not Found: /index
INFO - 2018-05-21 21:34:33 --> Utf8 Class Initialized
INFO - 2018-05-21 21:34:33 --> URI Class Initialized
INFO - 2018-05-21 21:34:33 --> Router Class Initialized
INFO - 2018-05-21 21:34:33 --> Output Class Initialized
INFO - 2018-05-21 21:34:33 --> Security Class Initialized
DEBUG - 2018-05-21 21:34:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-21 21:34:33 --> Config Class Initialized
INFO - 2018-05-21 21:34:33 --> Hooks Class Initialized
INFO - 2018-05-21 21:34:33 --> Input Class Initialized
INFO - 2018-05-21 21:34:33 --> Language Class Initialized
ERROR - 2018-05-21 21:34:33 --> 404 Page Not Found: /index
DEBUG - 2018-05-21 21:34:33 --> UTF-8 Support Enabled
INFO - 2018-05-21 21:34:33 --> Utf8 Class Initialized
INFO - 2018-05-21 21:34:33 --> URI Class Initialized
INFO - 2018-05-21 21:34:33 --> Router Class Initialized
INFO - 2018-05-21 21:34:33 --> Output Class Initialized
INFO - 2018-05-21 21:34:33 --> Security Class Initialized
DEBUG - 2018-05-21 21:34:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-21 21:34:33 --> Input Class Initialized
INFO - 2018-05-21 21:34:33 --> Language Class Initialized
ERROR - 2018-05-21 21:34:33 --> 404 Page Not Found: /index
INFO - 2018-05-21 21:34:33 --> Config Class Initialized
INFO - 2018-05-21 21:34:33 --> Hooks Class Initialized
DEBUG - 2018-05-21 21:34:33 --> UTF-8 Support Enabled
INFO - 2018-05-21 21:34:33 --> Utf8 Class Initialized
INFO - 2018-05-21 21:34:33 --> URI Class Initialized
INFO - 2018-05-21 21:34:33 --> Router Class Initialized
INFO - 2018-05-21 21:34:33 --> Output Class Initialized
INFO - 2018-05-21 21:34:33 --> Security Class Initialized
DEBUG - 2018-05-21 21:34:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-21 21:34:33 --> Input Class Initialized
INFO - 2018-05-21 21:34:33 --> Language Class Initialized
ERROR - 2018-05-21 21:34:33 --> 404 Page Not Found: /index
INFO - 2018-05-21 21:34:36 --> Config Class Initialized
INFO - 2018-05-21 21:34:36 --> Hooks Class Initialized
DEBUG - 2018-05-21 21:34:36 --> UTF-8 Support Enabled
INFO - 2018-05-21 21:34:36 --> Utf8 Class Initialized
INFO - 2018-05-21 21:34:36 --> URI Class Initialized
INFO - 2018-05-21 21:34:36 --> Router Class Initialized
INFO - 2018-05-21 21:34:36 --> Output Class Initialized
INFO - 2018-05-21 21:34:36 --> Security Class Initialized
DEBUG - 2018-05-21 21:34:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-21 21:34:36 --> Input Class Initialized
INFO - 2018-05-21 21:34:36 --> Language Class Initialized
INFO - 2018-05-21 21:34:36 --> Language Class Initialized
INFO - 2018-05-21 21:34:36 --> Config Class Initialized
INFO - 2018-05-21 21:34:36 --> Loader Class Initialized
DEBUG - 2018-05-21 21:34:36 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-21 21:34:36 --> Helper loaded: url_helper
INFO - 2018-05-21 21:34:36 --> Helper loaded: form_helper
INFO - 2018-05-21 21:34:36 --> Helper loaded: date_helper
INFO - 2018-05-21 21:34:36 --> Helper loaded: util_helper
INFO - 2018-05-21 21:34:36 --> Helper loaded: text_helper
INFO - 2018-05-21 21:34:36 --> Helper loaded: string_helper
INFO - 2018-05-21 21:34:36 --> Database Driver Class Initialized
DEBUG - 2018-05-21 21:34:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-21 21:34:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-21 21:34:36 --> Email Class Initialized
INFO - 2018-05-21 21:34:36 --> Controller Class Initialized
DEBUG - 2018-05-21 21:34:36 --> Home MX_Controller Initialized
DEBUG - 2018-05-21 21:34:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-21 21:34:36 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-21 21:34:36 --> Login MX_Controller Initialized
INFO - 2018-05-21 21:34:36 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-21 21:34:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-21 21:34:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-21 21:34:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-21 21:34:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-21 21:34:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-21 21:34:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-21 21:34:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-21 21:34:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-05-21 21:34:36 --> Final output sent to browser
DEBUG - 2018-05-21 21:34:36 --> Total execution time: 0.3967
INFO - 2018-05-21 21:34:37 --> Config Class Initialized
INFO - 2018-05-21 21:34:37 --> Config Class Initialized
INFO - 2018-05-21 21:34:37 --> Hooks Class Initialized
INFO - 2018-05-21 21:34:37 --> Hooks Class Initialized
DEBUG - 2018-05-21 21:34:37 --> UTF-8 Support Enabled
DEBUG - 2018-05-21 21:34:37 --> UTF-8 Support Enabled
INFO - 2018-05-21 21:34:37 --> Utf8 Class Initialized
INFO - 2018-05-21 21:34:37 --> Utf8 Class Initialized
INFO - 2018-05-21 21:34:37 --> URI Class Initialized
INFO - 2018-05-21 21:34:37 --> URI Class Initialized
INFO - 2018-05-21 21:34:37 --> Router Class Initialized
INFO - 2018-05-21 21:34:37 --> Router Class Initialized
INFO - 2018-05-21 21:34:37 --> Output Class Initialized
INFO - 2018-05-21 21:34:37 --> Output Class Initialized
INFO - 2018-05-21 21:34:37 --> Security Class Initialized
INFO - 2018-05-21 21:34:37 --> Security Class Initialized
DEBUG - 2018-05-21 21:34:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-21 21:34:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-21 21:34:37 --> Input Class Initialized
INFO - 2018-05-21 21:34:37 --> Input Class Initialized
INFO - 2018-05-21 21:34:37 --> Language Class Initialized
INFO - 2018-05-21 21:34:37 --> Language Class Initialized
ERROR - 2018-05-21 21:34:37 --> 404 Page Not Found: /index
ERROR - 2018-05-21 21:34:37 --> 404 Page Not Found: /index
INFO - 2018-05-21 21:34:37 --> Config Class Initialized
INFO - 2018-05-21 21:34:37 --> Hooks Class Initialized
DEBUG - 2018-05-21 21:34:37 --> UTF-8 Support Enabled
INFO - 2018-05-21 21:34:37 --> Utf8 Class Initialized
INFO - 2018-05-21 21:34:37 --> URI Class Initialized
INFO - 2018-05-21 21:34:37 --> Router Class Initialized
INFO - 2018-05-21 21:34:37 --> Output Class Initialized
INFO - 2018-05-21 21:34:37 --> Security Class Initialized
DEBUG - 2018-05-21 21:34:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-21 21:34:37 --> Input Class Initialized
INFO - 2018-05-21 21:34:37 --> Language Class Initialized
ERROR - 2018-05-21 21:34:37 --> 404 Page Not Found: /index
INFO - 2018-05-21 21:34:37 --> Config Class Initialized
INFO - 2018-05-21 21:34:37 --> Hooks Class Initialized
DEBUG - 2018-05-21 21:34:37 --> UTF-8 Support Enabled
INFO - 2018-05-21 21:34:37 --> Utf8 Class Initialized
INFO - 2018-05-21 21:34:37 --> URI Class Initialized
INFO - 2018-05-21 21:34:37 --> Router Class Initialized
INFO - 2018-05-21 21:34:37 --> Output Class Initialized
INFO - 2018-05-21 21:34:37 --> Security Class Initialized
DEBUG - 2018-05-21 21:34:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-21 21:34:37 --> Input Class Initialized
INFO - 2018-05-21 21:34:37 --> Language Class Initialized
ERROR - 2018-05-21 21:34:37 --> 404 Page Not Found: /index
INFO - 2018-05-21 21:34:39 --> Config Class Initialized
INFO - 2018-05-21 21:34:39 --> Hooks Class Initialized
DEBUG - 2018-05-21 21:34:39 --> UTF-8 Support Enabled
INFO - 2018-05-21 21:34:39 --> Utf8 Class Initialized
INFO - 2018-05-21 21:34:39 --> URI Class Initialized
INFO - 2018-05-21 21:34:39 --> Router Class Initialized
INFO - 2018-05-21 21:34:39 --> Output Class Initialized
INFO - 2018-05-21 21:34:39 --> Security Class Initialized
DEBUG - 2018-05-21 21:34:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-21 21:34:39 --> Input Class Initialized
INFO - 2018-05-21 21:34:39 --> Language Class Initialized
INFO - 2018-05-21 21:34:39 --> Language Class Initialized
INFO - 2018-05-21 21:34:39 --> Config Class Initialized
INFO - 2018-05-21 21:34:39 --> Loader Class Initialized
DEBUG - 2018-05-21 21:34:39 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-21 21:34:39 --> Helper loaded: url_helper
INFO - 2018-05-21 21:34:39 --> Helper loaded: form_helper
INFO - 2018-05-21 21:34:40 --> Helper loaded: date_helper
INFO - 2018-05-21 21:34:40 --> Helper loaded: util_helper
INFO - 2018-05-21 21:34:40 --> Helper loaded: text_helper
INFO - 2018-05-21 21:34:40 --> Helper loaded: string_helper
INFO - 2018-05-21 21:34:40 --> Database Driver Class Initialized
DEBUG - 2018-05-21 21:34:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-21 21:34:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-21 21:34:40 --> Email Class Initialized
INFO - 2018-05-21 21:34:40 --> Controller Class Initialized
DEBUG - 2018-05-21 21:34:40 --> Home MX_Controller Initialized
DEBUG - 2018-05-21 21:34:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-21 21:34:40 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-21 21:34:40 --> Login MX_Controller Initialized
INFO - 2018-05-21 21:34:40 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-21 21:34:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-21 21:34:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-21 21:34:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-21 21:34:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-21 21:34:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-21 21:34:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-21 21:34:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-21 21:34:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-05-21 21:34:40 --> Final output sent to browser
DEBUG - 2018-05-21 21:34:40 --> Total execution time: 0.3963
INFO - 2018-05-21 21:34:40 --> Config Class Initialized
INFO - 2018-05-21 21:34:40 --> Config Class Initialized
INFO - 2018-05-21 21:34:40 --> Hooks Class Initialized
INFO - 2018-05-21 21:34:40 --> Hooks Class Initialized
DEBUG - 2018-05-21 21:34:40 --> UTF-8 Support Enabled
DEBUG - 2018-05-21 21:34:40 --> UTF-8 Support Enabled
INFO - 2018-05-21 21:34:40 --> Utf8 Class Initialized
INFO - 2018-05-21 21:34:40 --> URI Class Initialized
INFO - 2018-05-21 21:34:40 --> Router Class Initialized
INFO - 2018-05-21 21:34:40 --> Output Class Initialized
INFO - 2018-05-21 21:34:40 --> Security Class Initialized
DEBUG - 2018-05-21 21:34:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-21 21:34:40 --> Input Class Initialized
INFO - 2018-05-21 21:34:40 --> Language Class Initialized
ERROR - 2018-05-21 21:34:40 --> 404 Page Not Found: /index
INFO - 2018-05-21 21:34:40 --> Utf8 Class Initialized
INFO - 2018-05-21 21:34:40 --> URI Class Initialized
INFO - 2018-05-21 21:34:40 --> Router Class Initialized
INFO - 2018-05-21 21:34:40 --> Output Class Initialized
INFO - 2018-05-21 21:34:40 --> Security Class Initialized
DEBUG - 2018-05-21 21:34:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-21 21:34:40 --> Input Class Initialized
INFO - 2018-05-21 21:34:40 --> Language Class Initialized
ERROR - 2018-05-21 21:34:40 --> 404 Page Not Found: /index
INFO - 2018-05-21 21:34:41 --> Config Class Initialized
INFO - 2018-05-21 21:34:41 --> Hooks Class Initialized
DEBUG - 2018-05-21 21:34:41 --> UTF-8 Support Enabled
INFO - 2018-05-21 21:34:41 --> Utf8 Class Initialized
INFO - 2018-05-21 21:34:41 --> URI Class Initialized
INFO - 2018-05-21 21:34:41 --> Router Class Initialized
INFO - 2018-05-21 21:34:41 --> Output Class Initialized
INFO - 2018-05-21 21:34:41 --> Security Class Initialized
DEBUG - 2018-05-21 21:34:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-21 21:34:41 --> Input Class Initialized
INFO - 2018-05-21 21:34:41 --> Language Class Initialized
ERROR - 2018-05-21 21:34:41 --> 404 Page Not Found: /index
INFO - 2018-05-21 21:34:41 --> Config Class Initialized
INFO - 2018-05-21 21:34:41 --> Hooks Class Initialized
DEBUG - 2018-05-21 21:34:41 --> UTF-8 Support Enabled
INFO - 2018-05-21 21:34:41 --> Utf8 Class Initialized
INFO - 2018-05-21 21:34:41 --> URI Class Initialized
INFO - 2018-05-21 21:34:41 --> Router Class Initialized
INFO - 2018-05-21 21:34:41 --> Output Class Initialized
INFO - 2018-05-21 21:34:41 --> Security Class Initialized
DEBUG - 2018-05-21 21:34:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-21 21:34:41 --> Input Class Initialized
INFO - 2018-05-21 21:34:41 --> Language Class Initialized
ERROR - 2018-05-21 21:34:41 --> 404 Page Not Found: /index
INFO - 2018-05-21 21:34:49 --> Config Class Initialized
INFO - 2018-05-21 21:34:49 --> Hooks Class Initialized
DEBUG - 2018-05-21 21:34:49 --> UTF-8 Support Enabled
INFO - 2018-05-21 21:34:49 --> Utf8 Class Initialized
INFO - 2018-05-21 21:34:49 --> URI Class Initialized
INFO - 2018-05-21 21:34:49 --> Router Class Initialized
INFO - 2018-05-21 21:34:49 --> Output Class Initialized
INFO - 2018-05-21 21:34:49 --> Security Class Initialized
DEBUG - 2018-05-21 21:34:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-21 21:34:49 --> Input Class Initialized
INFO - 2018-05-21 21:34:49 --> Language Class Initialized
INFO - 2018-05-21 21:34:49 --> Language Class Initialized
INFO - 2018-05-21 21:34:49 --> Config Class Initialized
INFO - 2018-05-21 21:34:49 --> Loader Class Initialized
DEBUG - 2018-05-21 21:34:49 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-21 21:34:49 --> Helper loaded: url_helper
INFO - 2018-05-21 21:34:49 --> Helper loaded: form_helper
INFO - 2018-05-21 21:34:49 --> Helper loaded: date_helper
INFO - 2018-05-21 21:34:49 --> Helper loaded: util_helper
INFO - 2018-05-21 21:34:49 --> Helper loaded: text_helper
INFO - 2018-05-21 21:34:49 --> Helper loaded: string_helper
INFO - 2018-05-21 21:34:49 --> Database Driver Class Initialized
DEBUG - 2018-05-21 21:34:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-21 21:34:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-21 21:34:49 --> Email Class Initialized
INFO - 2018-05-21 21:34:49 --> Controller Class Initialized
DEBUG - 2018-05-21 21:34:49 --> Login MX_Controller Initialized
INFO - 2018-05-21 21:34:49 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-21 21:34:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-21 21:34:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-21 21:34:49 --> 4 Loggedout
INFO - 2018-05-21 21:34:49 --> Config Class Initialized
INFO - 2018-05-21 21:34:49 --> Hooks Class Initialized
DEBUG - 2018-05-21 21:34:49 --> UTF-8 Support Enabled
INFO - 2018-05-21 21:34:49 --> Utf8 Class Initialized
INFO - 2018-05-21 21:34:49 --> URI Class Initialized
INFO - 2018-05-21 21:34:49 --> Router Class Initialized
INFO - 2018-05-21 21:34:49 --> Output Class Initialized
INFO - 2018-05-21 21:34:49 --> Security Class Initialized
DEBUG - 2018-05-21 21:34:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-21 21:34:49 --> Input Class Initialized
INFO - 2018-05-21 21:34:49 --> Language Class Initialized
INFO - 2018-05-21 21:34:49 --> Language Class Initialized
INFO - 2018-05-21 21:34:49 --> Config Class Initialized
INFO - 2018-05-21 21:34:49 --> Loader Class Initialized
DEBUG - 2018-05-21 21:34:49 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-21 21:34:49 --> Helper loaded: url_helper
INFO - 2018-05-21 21:34:49 --> Helper loaded: form_helper
INFO - 2018-05-21 21:34:49 --> Helper loaded: date_helper
INFO - 2018-05-21 21:34:49 --> Helper loaded: util_helper
INFO - 2018-05-21 21:34:49 --> Helper loaded: text_helper
INFO - 2018-05-21 21:34:49 --> Helper loaded: string_helper
INFO - 2018-05-21 21:34:49 --> Database Driver Class Initialized
DEBUG - 2018-05-21 21:34:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-21 21:34:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-21 21:34:49 --> Email Class Initialized
INFO - 2018-05-21 21:34:49 --> Controller Class Initialized
DEBUG - 2018-05-21 21:34:49 --> Home MX_Controller Initialized
DEBUG - 2018-05-21 21:34:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-21 21:34:49 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-21 21:34:49 --> Login MX_Controller Initialized
INFO - 2018-05-21 21:34:49 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-21 21:34:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-21 21:34:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-21 21:34:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/login.php
INFO - 2018-05-21 21:39:11 --> Config Class Initialized
INFO - 2018-05-21 21:39:11 --> Hooks Class Initialized
DEBUG - 2018-05-21 21:39:11 --> UTF-8 Support Enabled
INFO - 2018-05-21 21:39:11 --> Utf8 Class Initialized
INFO - 2018-05-21 21:39:11 --> URI Class Initialized
INFO - 2018-05-21 21:39:11 --> Router Class Initialized
INFO - 2018-05-21 21:39:11 --> Output Class Initialized
INFO - 2018-05-21 21:39:11 --> Security Class Initialized
DEBUG - 2018-05-21 21:39:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-21 21:39:11 --> Input Class Initialized
INFO - 2018-05-21 21:39:11 --> Language Class Initialized
INFO - 2018-05-21 21:39:11 --> Language Class Initialized
INFO - 2018-05-21 21:39:11 --> Config Class Initialized
INFO - 2018-05-21 21:39:11 --> Loader Class Initialized
DEBUG - 2018-05-21 21:39:11 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-21 21:39:11 --> Helper loaded: url_helper
INFO - 2018-05-21 21:39:11 --> Helper loaded: form_helper
INFO - 2018-05-21 21:39:11 --> Helper loaded: date_helper
INFO - 2018-05-21 21:39:11 --> Helper loaded: util_helper
INFO - 2018-05-21 21:39:11 --> Helper loaded: text_helper
INFO - 2018-05-21 21:39:11 --> Helper loaded: string_helper
INFO - 2018-05-21 21:39:12 --> Database Driver Class Initialized
DEBUG - 2018-05-21 21:39:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-21 21:39:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-21 21:39:12 --> Email Class Initialized
INFO - 2018-05-21 21:39:12 --> Controller Class Initialized
DEBUG - 2018-05-21 21:39:12 --> Login MX_Controller Initialized
INFO - 2018-05-21 21:39:12 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-21 21:39:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-21 21:39:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-21 21:39:12 --> Email starts for user@colin.com fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-05-21 21:39:12 --> User session created for 4
INFO - 2018-05-21 21:39:12 --> Login status user@colin.com - success
INFO - 2018-05-21 21:39:12 --> Final output sent to browser
DEBUG - 2018-05-21 21:39:12 --> Total execution time: 0.9573
INFO - 2018-05-21 21:39:12 --> Config Class Initialized
INFO - 2018-05-21 21:39:12 --> Hooks Class Initialized
DEBUG - 2018-05-21 21:39:12 --> UTF-8 Support Enabled
INFO - 2018-05-21 21:39:12 --> Utf8 Class Initialized
INFO - 2018-05-21 21:39:12 --> URI Class Initialized
INFO - 2018-05-21 21:39:12 --> Router Class Initialized
INFO - 2018-05-21 21:39:12 --> Output Class Initialized
INFO - 2018-05-21 21:39:12 --> Security Class Initialized
DEBUG - 2018-05-21 21:39:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-21 21:39:12 --> Input Class Initialized
INFO - 2018-05-21 21:39:12 --> Language Class Initialized
INFO - 2018-05-21 21:39:12 --> Language Class Initialized
INFO - 2018-05-21 21:39:12 --> Config Class Initialized
INFO - 2018-05-21 21:39:12 --> Loader Class Initialized
DEBUG - 2018-05-21 21:39:12 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-21 21:39:12 --> Helper loaded: url_helper
INFO - 2018-05-21 21:39:12 --> Helper loaded: form_helper
INFO - 2018-05-21 21:39:12 --> Helper loaded: date_helper
INFO - 2018-05-21 21:39:12 --> Helper loaded: util_helper
INFO - 2018-05-21 21:39:12 --> Helper loaded: text_helper
INFO - 2018-05-21 21:39:12 --> Helper loaded: string_helper
INFO - 2018-05-21 21:39:12 --> Database Driver Class Initialized
DEBUG - 2018-05-21 21:39:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-21 21:39:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-21 21:39:12 --> Email Class Initialized
INFO - 2018-05-21 21:39:12 --> Controller Class Initialized
DEBUG - 2018-05-21 21:39:12 --> Home MX_Controller Initialized
DEBUG - 2018-05-21 21:39:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-21 21:39:12 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-21 21:39:12 --> Login MX_Controller Initialized
INFO - 2018-05-21 21:39:12 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-21 21:39:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-21 21:39:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-21 21:39:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-21 21:39:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-21 21:39:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-21 21:39:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-21 21:39:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-21 21:39:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-05-21 21:39:12 --> Final output sent to browser
DEBUG - 2018-05-21 21:39:12 --> Total execution time: 0.5021
INFO - 2018-05-21 21:39:13 --> Config Class Initialized
INFO - 2018-05-21 21:39:13 --> Hooks Class Initialized
DEBUG - 2018-05-21 21:39:13 --> UTF-8 Support Enabled
INFO - 2018-05-21 21:39:13 --> Utf8 Class Initialized
INFO - 2018-05-21 21:39:13 --> URI Class Initialized
INFO - 2018-05-21 21:39:13 --> Router Class Initialized
INFO - 2018-05-21 21:39:13 --> Output Class Initialized
INFO - 2018-05-21 21:39:13 --> Security Class Initialized
DEBUG - 2018-05-21 21:39:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-21 21:39:13 --> Input Class Initialized
INFO - 2018-05-21 21:39:13 --> Language Class Initialized
ERROR - 2018-05-21 21:39:13 --> 404 Page Not Found: /index
INFO - 2018-05-21 21:39:13 --> Config Class Initialized
INFO - 2018-05-21 21:39:13 --> Hooks Class Initialized
DEBUG - 2018-05-21 21:39:13 --> UTF-8 Support Enabled
INFO - 2018-05-21 21:39:13 --> Utf8 Class Initialized
INFO - 2018-05-21 21:39:13 --> URI Class Initialized
INFO - 2018-05-21 21:39:13 --> Router Class Initialized
INFO - 2018-05-21 21:39:13 --> Output Class Initialized
INFO - 2018-05-21 21:39:13 --> Security Class Initialized
DEBUG - 2018-05-21 21:39:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-21 21:39:13 --> Input Class Initialized
INFO - 2018-05-21 21:39:13 --> Language Class Initialized
ERROR - 2018-05-21 21:39:13 --> 404 Page Not Found: /index
INFO - 2018-05-21 21:39:13 --> Config Class Initialized
INFO - 2018-05-21 21:39:13 --> Hooks Class Initialized
DEBUG - 2018-05-21 21:39:13 --> UTF-8 Support Enabled
INFO - 2018-05-21 21:39:13 --> Utf8 Class Initialized
INFO - 2018-05-21 21:39:13 --> URI Class Initialized
INFO - 2018-05-21 21:39:13 --> Router Class Initialized
INFO - 2018-05-21 21:39:13 --> Output Class Initialized
INFO - 2018-05-21 21:39:13 --> Security Class Initialized
DEBUG - 2018-05-21 21:39:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-21 21:39:13 --> Input Class Initialized
INFO - 2018-05-21 21:39:13 --> Language Class Initialized
ERROR - 2018-05-21 21:39:13 --> 404 Page Not Found: /index
INFO - 2018-05-21 21:44:52 --> Config Class Initialized
INFO - 2018-05-21 21:44:52 --> Hooks Class Initialized
DEBUG - 2018-05-21 21:44:52 --> UTF-8 Support Enabled
INFO - 2018-05-21 21:44:52 --> Utf8 Class Initialized
INFO - 2018-05-21 21:44:52 --> URI Class Initialized
INFO - 2018-05-21 21:44:52 --> Router Class Initialized
INFO - 2018-05-21 21:44:52 --> Output Class Initialized
INFO - 2018-05-21 21:44:52 --> Security Class Initialized
DEBUG - 2018-05-21 21:44:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-21 21:44:52 --> Input Class Initialized
INFO - 2018-05-21 21:44:52 --> Language Class Initialized
INFO - 2018-05-21 21:44:52 --> Language Class Initialized
INFO - 2018-05-21 21:44:52 --> Config Class Initialized
INFO - 2018-05-21 21:44:52 --> Loader Class Initialized
DEBUG - 2018-05-21 21:44:52 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-21 21:44:52 --> Helper loaded: url_helper
INFO - 2018-05-21 21:44:53 --> Helper loaded: form_helper
INFO - 2018-05-21 21:44:53 --> Helper loaded: date_helper
INFO - 2018-05-21 21:44:53 --> Helper loaded: util_helper
INFO - 2018-05-21 21:44:53 --> Helper loaded: text_helper
INFO - 2018-05-21 21:44:53 --> Helper loaded: string_helper
INFO - 2018-05-21 21:44:53 --> Database Driver Class Initialized
DEBUG - 2018-05-21 21:44:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-21 21:44:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-21 21:44:53 --> Email Class Initialized
INFO - 2018-05-21 21:44:53 --> Controller Class Initialized
DEBUG - 2018-05-21 21:44:53 --> Profile MX_Controller Initialized
INFO - 2018-05-21 21:44:53 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-21 21:44:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-21 21:44:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Profile_model.php
DEBUG - 2018-05-21 21:44:53 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-21 21:44:53 --> Login MX_Controller Initialized
DEBUG - 2018-05-21 21:44:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-21 21:44:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-05-21 21:44:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-05-21 21:44:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-05-21 21:44:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-05-21 21:44:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-05-21 21:44:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/admin_password.php
INFO - 2018-05-21 21:44:54 --> Final output sent to browser
DEBUG - 2018-05-21 21:44:54 --> Total execution time: 2.1879
INFO - 2018-05-21 21:46:07 --> Config Class Initialized
INFO - 2018-05-21 21:46:07 --> Hooks Class Initialized
DEBUG - 2018-05-21 21:46:07 --> UTF-8 Support Enabled
INFO - 2018-05-21 21:46:07 --> Utf8 Class Initialized
INFO - 2018-05-21 21:46:08 --> URI Class Initialized
INFO - 2018-05-21 21:46:08 --> Router Class Initialized
INFO - 2018-05-21 21:46:08 --> Output Class Initialized
INFO - 2018-05-21 21:46:08 --> Security Class Initialized
DEBUG - 2018-05-21 21:46:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-21 21:46:08 --> Input Class Initialized
INFO - 2018-05-21 21:46:08 --> Language Class Initialized
INFO - 2018-05-21 21:46:08 --> Language Class Initialized
INFO - 2018-05-21 21:46:08 --> Config Class Initialized
INFO - 2018-05-21 21:46:08 --> Loader Class Initialized
DEBUG - 2018-05-21 21:46:08 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-21 21:46:08 --> Helper loaded: url_helper
INFO - 2018-05-21 21:46:08 --> Helper loaded: form_helper
INFO - 2018-05-21 21:46:08 --> Helper loaded: date_helper
INFO - 2018-05-21 21:46:08 --> Helper loaded: util_helper
INFO - 2018-05-21 21:46:08 --> Helper loaded: text_helper
INFO - 2018-05-21 21:46:08 --> Helper loaded: string_helper
INFO - 2018-05-21 21:46:08 --> Database Driver Class Initialized
DEBUG - 2018-05-21 21:46:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-21 21:46:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-21 21:46:08 --> Email Class Initialized
INFO - 2018-05-21 21:46:08 --> Controller Class Initialized
DEBUG - 2018-05-21 21:46:08 --> videos MX_Controller Initialized
INFO - 2018-05-21 21:46:08 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-21 21:46:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-05-21 21:46:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-21 21:46:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-05-21 21:46:08 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-21 21:46:08 --> Login MX_Controller Initialized
DEBUG - 2018-05-21 21:46:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-21 21:46:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-05-21 21:46:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-05-21 21:46:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-05-21 21:46:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-05-21 21:46:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-05-21 21:46:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/videos/videos.php
INFO - 2018-05-21 21:46:08 --> Final output sent to browser
DEBUG - 2018-05-21 21:46:08 --> Total execution time: 0.7359
INFO - 2018-05-21 21:46:09 --> Config Class Initialized
INFO - 2018-05-21 21:46:09 --> Hooks Class Initialized
DEBUG - 2018-05-21 21:46:09 --> UTF-8 Support Enabled
INFO - 2018-05-21 21:46:09 --> Utf8 Class Initialized
INFO - 2018-05-21 21:46:09 --> URI Class Initialized
INFO - 2018-05-21 21:46:09 --> Router Class Initialized
INFO - 2018-05-21 21:46:09 --> Output Class Initialized
INFO - 2018-05-21 21:46:09 --> Security Class Initialized
DEBUG - 2018-05-21 21:46:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-21 21:46:09 --> Input Class Initialized
INFO - 2018-05-21 21:46:09 --> Language Class Initialized
INFO - 2018-05-21 21:46:09 --> Language Class Initialized
INFO - 2018-05-21 21:46:09 --> Config Class Initialized
INFO - 2018-05-21 21:46:09 --> Loader Class Initialized
DEBUG - 2018-05-21 21:46:09 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-21 21:46:09 --> Helper loaded: url_helper
INFO - 2018-05-21 21:46:09 --> Helper loaded: form_helper
INFO - 2018-05-21 21:46:09 --> Helper loaded: date_helper
INFO - 2018-05-21 21:46:09 --> Helper loaded: util_helper
INFO - 2018-05-21 21:46:09 --> Helper loaded: text_helper
INFO - 2018-05-21 21:46:09 --> Helper loaded: string_helper
INFO - 2018-05-21 21:46:09 --> Database Driver Class Initialized
DEBUG - 2018-05-21 21:46:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-21 21:46:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-21 21:46:09 --> Email Class Initialized
INFO - 2018-05-21 21:46:09 --> Controller Class Initialized
DEBUG - 2018-05-21 21:46:09 --> videos MX_Controller Initialized
INFO - 2018-05-21 21:46:09 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-21 21:46:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-05-21 21:46:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-21 21:46:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-05-21 21:46:09 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-21 21:46:09 --> Login MX_Controller Initialized
DEBUG - 2018-05-21 21:46:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-21 21:46:09 --> Final output sent to browser
DEBUG - 2018-05-21 21:46:09 --> Total execution time: 0.4391
INFO - 2018-05-21 21:46:11 --> Config Class Initialized
INFO - 2018-05-21 21:46:11 --> Hooks Class Initialized
DEBUG - 2018-05-21 21:46:11 --> UTF-8 Support Enabled
INFO - 2018-05-21 21:46:11 --> Utf8 Class Initialized
INFO - 2018-05-21 21:46:11 --> URI Class Initialized
INFO - 2018-05-21 21:46:11 --> Router Class Initialized
INFO - 2018-05-21 21:46:11 --> Output Class Initialized
INFO - 2018-05-21 21:46:11 --> Security Class Initialized
DEBUG - 2018-05-21 21:46:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-21 21:46:11 --> Input Class Initialized
INFO - 2018-05-21 21:46:11 --> Language Class Initialized
INFO - 2018-05-21 21:46:11 --> Language Class Initialized
INFO - 2018-05-21 21:46:11 --> Config Class Initialized
INFO - 2018-05-21 21:46:11 --> Loader Class Initialized
DEBUG - 2018-05-21 21:46:11 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-21 21:46:11 --> Helper loaded: url_helper
INFO - 2018-05-21 21:46:11 --> Helper loaded: form_helper
INFO - 2018-05-21 21:46:11 --> Helper loaded: date_helper
INFO - 2018-05-21 21:46:11 --> Helper loaded: util_helper
INFO - 2018-05-21 21:46:11 --> Helper loaded: text_helper
INFO - 2018-05-21 21:46:11 --> Helper loaded: string_helper
INFO - 2018-05-21 21:46:11 --> Database Driver Class Initialized
DEBUG - 2018-05-21 21:46:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-21 21:46:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-21 21:46:11 --> Email Class Initialized
INFO - 2018-05-21 21:46:11 --> Controller Class Initialized
DEBUG - 2018-05-21 21:46:11 --> videos MX_Controller Initialized
INFO - 2018-05-21 21:46:11 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-21 21:46:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-05-21 21:46:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-21 21:46:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-05-21 21:46:11 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-21 21:46:11 --> Login MX_Controller Initialized
DEBUG - 2018-05-21 21:46:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-21 21:46:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-05-21 21:46:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-05-21 21:46:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-05-21 21:46:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-05-21 21:46:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-05-21 21:46:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/videos/create_video.php
INFO - 2018-05-21 21:46:13 --> Final output sent to browser
DEBUG - 2018-05-21 21:46:13 --> Total execution time: 1.9555
INFO - 2018-05-21 21:46:16 --> Config Class Initialized
INFO - 2018-05-21 21:46:16 --> Hooks Class Initialized
DEBUG - 2018-05-21 21:46:16 --> UTF-8 Support Enabled
INFO - 2018-05-21 21:46:16 --> Utf8 Class Initialized
INFO - 2018-05-21 21:46:16 --> URI Class Initialized
INFO - 2018-05-21 21:46:16 --> Router Class Initialized
INFO - 2018-05-21 21:46:16 --> Output Class Initialized
INFO - 2018-05-21 21:46:16 --> Security Class Initialized
DEBUG - 2018-05-21 21:46:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-21 21:46:16 --> Input Class Initialized
INFO - 2018-05-21 21:46:16 --> Language Class Initialized
INFO - 2018-05-21 21:46:16 --> Language Class Initialized
INFO - 2018-05-21 21:46:16 --> Config Class Initialized
INFO - 2018-05-21 21:46:16 --> Loader Class Initialized
DEBUG - 2018-05-21 21:46:16 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-21 21:46:16 --> Helper loaded: url_helper
INFO - 2018-05-21 21:46:16 --> Helper loaded: form_helper
INFO - 2018-05-21 21:46:16 --> Helper loaded: date_helper
INFO - 2018-05-21 21:46:16 --> Helper loaded: util_helper
INFO - 2018-05-21 21:46:16 --> Helper loaded: text_helper
INFO - 2018-05-21 21:46:16 --> Helper loaded: string_helper
INFO - 2018-05-21 21:46:16 --> Database Driver Class Initialized
DEBUG - 2018-05-21 21:46:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-21 21:46:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-21 21:46:16 --> Email Class Initialized
INFO - 2018-05-21 21:46:16 --> Controller Class Initialized
DEBUG - 2018-05-21 21:46:16 --> videos MX_Controller Initialized
INFO - 2018-05-21 21:46:16 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-21 21:46:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-05-21 21:46:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-21 21:46:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-05-21 21:46:16 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-21 21:46:16 --> Login MX_Controller Initialized
DEBUG - 2018-05-21 21:46:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-21 21:46:18 --> Config Class Initialized
INFO - 2018-05-21 21:46:18 --> Hooks Class Initialized
DEBUG - 2018-05-21 21:46:18 --> UTF-8 Support Enabled
INFO - 2018-05-21 21:46:18 --> Utf8 Class Initialized
INFO - 2018-05-21 21:46:18 --> URI Class Initialized
INFO - 2018-05-21 21:46:18 --> Router Class Initialized
INFO - 2018-05-21 21:46:18 --> Output Class Initialized
INFO - 2018-05-21 21:46:18 --> Security Class Initialized
DEBUG - 2018-05-21 21:46:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-21 21:46:18 --> Input Class Initialized
INFO - 2018-05-21 21:46:18 --> Language Class Initialized
INFO - 2018-05-21 21:46:18 --> Language Class Initialized
INFO - 2018-05-21 21:46:18 --> Config Class Initialized
INFO - 2018-05-21 21:46:18 --> Loader Class Initialized
DEBUG - 2018-05-21 21:46:18 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-21 21:46:18 --> Helper loaded: url_helper
INFO - 2018-05-21 21:46:18 --> Helper loaded: form_helper
INFO - 2018-05-21 21:46:18 --> Helper loaded: date_helper
INFO - 2018-05-21 21:46:18 --> Helper loaded: util_helper
INFO - 2018-05-21 21:46:18 --> Helper loaded: text_helper
INFO - 2018-05-21 21:46:18 --> Helper loaded: string_helper
INFO - 2018-05-21 21:46:18 --> Database Driver Class Initialized
DEBUG - 2018-05-21 21:46:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-21 21:46:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-21 21:46:18 --> Email Class Initialized
INFO - 2018-05-21 21:46:18 --> Controller Class Initialized
DEBUG - 2018-05-21 21:46:18 --> videos MX_Controller Initialized
INFO - 2018-05-21 21:46:18 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-21 21:46:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-05-21 21:46:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-21 21:46:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-05-21 21:46:18 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-21 21:46:18 --> Login MX_Controller Initialized
DEBUG - 2018-05-21 21:46:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-21 21:46:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-05-21 21:46:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-05-21 21:46:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-05-21 21:46:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-05-21 21:46:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-05-21 21:46:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/videos/videos.php
INFO - 2018-05-21 21:46:19 --> Final output sent to browser
DEBUG - 2018-05-21 21:46:19 --> Total execution time: 0.4632
INFO - 2018-05-21 21:46:19 --> Config Class Initialized
INFO - 2018-05-21 21:46:19 --> Hooks Class Initialized
DEBUG - 2018-05-21 21:46:19 --> UTF-8 Support Enabled
INFO - 2018-05-21 21:46:19 --> Utf8 Class Initialized
INFO - 2018-05-21 21:46:19 --> URI Class Initialized
INFO - 2018-05-21 21:46:19 --> Router Class Initialized
INFO - 2018-05-21 21:46:19 --> Output Class Initialized
INFO - 2018-05-21 21:46:19 --> Security Class Initialized
DEBUG - 2018-05-21 21:46:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-21 21:46:19 --> Input Class Initialized
INFO - 2018-05-21 21:46:19 --> Language Class Initialized
INFO - 2018-05-21 21:46:19 --> Language Class Initialized
INFO - 2018-05-21 21:46:19 --> Config Class Initialized
INFO - 2018-05-21 21:46:19 --> Loader Class Initialized
DEBUG - 2018-05-21 21:46:19 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-21 21:46:19 --> Helper loaded: url_helper
INFO - 2018-05-21 21:46:19 --> Helper loaded: form_helper
INFO - 2018-05-21 21:46:19 --> Helper loaded: date_helper
INFO - 2018-05-21 21:46:19 --> Helper loaded: util_helper
INFO - 2018-05-21 21:46:19 --> Helper loaded: text_helper
INFO - 2018-05-21 21:46:19 --> Helper loaded: string_helper
INFO - 2018-05-21 21:46:19 --> Database Driver Class Initialized
DEBUG - 2018-05-21 21:46:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-21 21:46:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-21 21:46:19 --> Email Class Initialized
INFO - 2018-05-21 21:46:19 --> Controller Class Initialized
DEBUG - 2018-05-21 21:46:19 --> videos MX_Controller Initialized
INFO - 2018-05-21 21:46:19 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-21 21:46:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-05-21 21:46:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-21 21:46:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-05-21 21:46:19 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-21 21:46:19 --> Login MX_Controller Initialized
DEBUG - 2018-05-21 21:46:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-21 21:46:19 --> Final output sent to browser
DEBUG - 2018-05-21 21:46:19 --> Total execution time: 0.4797
INFO - 2018-05-21 21:46:20 --> Config Class Initialized
INFO - 2018-05-21 21:46:20 --> Hooks Class Initialized
DEBUG - 2018-05-21 21:46:20 --> UTF-8 Support Enabled
INFO - 2018-05-21 21:46:20 --> Utf8 Class Initialized
INFO - 2018-05-21 21:46:20 --> URI Class Initialized
INFO - 2018-05-21 21:46:20 --> Router Class Initialized
INFO - 2018-05-21 21:46:20 --> Output Class Initialized
INFO - 2018-05-21 21:46:20 --> Security Class Initialized
DEBUG - 2018-05-21 21:46:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-21 21:46:20 --> Input Class Initialized
INFO - 2018-05-21 21:46:20 --> Language Class Initialized
INFO - 2018-05-21 21:46:20 --> Language Class Initialized
INFO - 2018-05-21 21:46:20 --> Config Class Initialized
INFO - 2018-05-21 21:46:20 --> Loader Class Initialized
DEBUG - 2018-05-21 21:46:20 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-21 21:46:20 --> Helper loaded: url_helper
INFO - 2018-05-21 21:46:20 --> Helper loaded: form_helper
INFO - 2018-05-21 21:46:20 --> Helper loaded: date_helper
INFO - 2018-05-21 21:46:21 --> Helper loaded: util_helper
INFO - 2018-05-21 21:46:21 --> Helper loaded: text_helper
INFO - 2018-05-21 21:46:21 --> Helper loaded: string_helper
INFO - 2018-05-21 21:46:21 --> Database Driver Class Initialized
DEBUG - 2018-05-21 21:46:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-21 21:46:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-21 21:46:21 --> Email Class Initialized
INFO - 2018-05-21 21:46:21 --> Controller Class Initialized
DEBUG - 2018-05-21 21:46:21 --> Chapters MX_Controller Initialized
INFO - 2018-05-21 21:46:21 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-21 21:46:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Chapters_model.php
DEBUG - 2018-05-21 21:46:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-21 21:46:21 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-21 21:46:21 --> Login MX_Controller Initialized
DEBUG - 2018-05-21 21:46:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-21 21:46:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-05-21 21:46:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-05-21 21:46:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-05-21 21:46:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-05-21 21:46:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-05-21 21:46:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/chapters/chapters.php
INFO - 2018-05-21 21:46:21 --> Final output sent to browser
DEBUG - 2018-05-21 21:46:21 --> Total execution time: 1.3341
INFO - 2018-05-21 21:46:21 --> Config Class Initialized
INFO - 2018-05-21 21:46:21 --> Hooks Class Initialized
DEBUG - 2018-05-21 21:46:21 --> UTF-8 Support Enabled
INFO - 2018-05-21 21:46:21 --> Utf8 Class Initialized
INFO - 2018-05-21 21:46:22 --> URI Class Initialized
INFO - 2018-05-21 21:46:22 --> Router Class Initialized
INFO - 2018-05-21 21:46:22 --> Output Class Initialized
INFO - 2018-05-21 21:46:22 --> Security Class Initialized
DEBUG - 2018-05-21 21:46:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-21 21:46:22 --> Input Class Initialized
INFO - 2018-05-21 21:46:22 --> Language Class Initialized
INFO - 2018-05-21 21:46:22 --> Language Class Initialized
INFO - 2018-05-21 21:46:22 --> Config Class Initialized
INFO - 2018-05-21 21:46:22 --> Loader Class Initialized
DEBUG - 2018-05-21 21:46:22 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-21 21:46:22 --> Helper loaded: url_helper
INFO - 2018-05-21 21:46:22 --> Helper loaded: form_helper
INFO - 2018-05-21 21:46:22 --> Helper loaded: date_helper
INFO - 2018-05-21 21:46:22 --> Helper loaded: util_helper
INFO - 2018-05-21 21:46:22 --> Helper loaded: text_helper
INFO - 2018-05-21 21:46:22 --> Helper loaded: string_helper
INFO - 2018-05-21 21:46:22 --> Database Driver Class Initialized
DEBUG - 2018-05-21 21:46:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-21 21:46:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-21 21:46:22 --> Email Class Initialized
INFO - 2018-05-21 21:46:22 --> Controller Class Initialized
DEBUG - 2018-05-21 21:46:22 --> Chapters MX_Controller Initialized
INFO - 2018-05-21 21:46:22 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-21 21:46:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Chapters_model.php
DEBUG - 2018-05-21 21:46:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-21 21:46:22 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-21 21:46:22 --> Login MX_Controller Initialized
DEBUG - 2018-05-21 21:46:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-21 21:46:22 --> Final output sent to browser
DEBUG - 2018-05-21 21:46:22 --> Total execution time: 0.4114
INFO - 2018-05-21 21:46:24 --> Config Class Initialized
INFO - 2018-05-21 21:46:24 --> Hooks Class Initialized
DEBUG - 2018-05-21 21:46:24 --> UTF-8 Support Enabled
INFO - 2018-05-21 21:46:24 --> Utf8 Class Initialized
INFO - 2018-05-21 21:46:24 --> URI Class Initialized
INFO - 2018-05-21 21:46:24 --> Router Class Initialized
INFO - 2018-05-21 21:46:24 --> Output Class Initialized
INFO - 2018-05-21 21:46:24 --> Security Class Initialized
DEBUG - 2018-05-21 21:46:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-21 21:46:24 --> Input Class Initialized
INFO - 2018-05-21 21:46:24 --> Language Class Initialized
INFO - 2018-05-21 21:46:25 --> Language Class Initialized
INFO - 2018-05-21 21:46:25 --> Config Class Initialized
INFO - 2018-05-21 21:46:25 --> Loader Class Initialized
DEBUG - 2018-05-21 21:46:25 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-21 21:46:26 --> Helper loaded: url_helper
INFO - 2018-05-21 21:46:26 --> Helper loaded: form_helper
INFO - 2018-05-21 21:46:26 --> Helper loaded: date_helper
INFO - 2018-05-21 21:46:26 --> Helper loaded: util_helper
INFO - 2018-05-21 21:46:26 --> Helper loaded: text_helper
INFO - 2018-05-21 21:46:26 --> Helper loaded: string_helper
INFO - 2018-05-21 21:46:26 --> Database Driver Class Initialized
DEBUG - 2018-05-21 21:46:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-21 21:46:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-21 21:46:26 --> Email Class Initialized
INFO - 2018-05-21 21:46:26 --> Controller Class Initialized
DEBUG - 2018-05-21 21:46:26 --> Programs MX_Controller Initialized
INFO - 2018-05-21 21:46:26 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-21 21:46:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-05-21 21:46:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-21 21:46:26 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-21 21:46:26 --> Login MX_Controller Initialized
DEBUG - 2018-05-21 21:46:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-21 21:46:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-05-21 21:46:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-05-21 21:46:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-05-21 21:46:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-05-21 21:46:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-05-21 21:46:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/programs/programs.php
INFO - 2018-05-21 21:46:27 --> Final output sent to browser
DEBUG - 2018-05-21 21:46:27 --> Total execution time: 3.0150
INFO - 2018-05-21 21:46:27 --> Config Class Initialized
INFO - 2018-05-21 21:46:27 --> Hooks Class Initialized
DEBUG - 2018-05-21 21:46:27 --> UTF-8 Support Enabled
INFO - 2018-05-21 21:46:27 --> Utf8 Class Initialized
INFO - 2018-05-21 21:46:27 --> URI Class Initialized
INFO - 2018-05-21 21:46:27 --> Router Class Initialized
INFO - 2018-05-21 21:46:27 --> Output Class Initialized
INFO - 2018-05-21 21:46:27 --> Security Class Initialized
DEBUG - 2018-05-21 21:46:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-21 21:46:27 --> Input Class Initialized
INFO - 2018-05-21 21:46:27 --> Language Class Initialized
INFO - 2018-05-21 21:46:27 --> Language Class Initialized
INFO - 2018-05-21 21:46:27 --> Config Class Initialized
INFO - 2018-05-21 21:46:27 --> Loader Class Initialized
DEBUG - 2018-05-21 21:46:27 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-21 21:46:27 --> Helper loaded: url_helper
INFO - 2018-05-21 21:46:27 --> Helper loaded: form_helper
INFO - 2018-05-21 21:46:27 --> Helper loaded: date_helper
INFO - 2018-05-21 21:46:27 --> Helper loaded: util_helper
INFO - 2018-05-21 21:46:27 --> Helper loaded: text_helper
INFO - 2018-05-21 21:46:27 --> Helper loaded: string_helper
INFO - 2018-05-21 21:46:27 --> Database Driver Class Initialized
DEBUG - 2018-05-21 21:46:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-21 21:46:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-21 21:46:27 --> Email Class Initialized
INFO - 2018-05-21 21:46:27 --> Controller Class Initialized
DEBUG - 2018-05-21 21:46:27 --> Programs MX_Controller Initialized
INFO - 2018-05-21 21:46:27 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-21 21:46:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-05-21 21:46:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-21 21:46:27 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-21 21:46:27 --> Login MX_Controller Initialized
DEBUG - 2018-05-21 21:46:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-21 21:46:27 --> Final output sent to browser
DEBUG - 2018-05-21 21:46:27 --> Total execution time: 0.4538
INFO - 2018-05-21 21:46:47 --> Config Class Initialized
INFO - 2018-05-21 21:46:47 --> Hooks Class Initialized
DEBUG - 2018-05-21 21:46:47 --> UTF-8 Support Enabled
INFO - 2018-05-21 21:46:47 --> Utf8 Class Initialized
INFO - 2018-05-21 21:46:47 --> URI Class Initialized
INFO - 2018-05-21 21:46:47 --> Router Class Initialized
INFO - 2018-05-21 21:46:47 --> Output Class Initialized
INFO - 2018-05-21 21:46:47 --> Security Class Initialized
DEBUG - 2018-05-21 21:46:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-21 21:46:47 --> Input Class Initialized
INFO - 2018-05-21 21:46:47 --> Language Class Initialized
INFO - 2018-05-21 21:46:47 --> Language Class Initialized
INFO - 2018-05-21 21:46:47 --> Config Class Initialized
INFO - 2018-05-21 21:46:47 --> Loader Class Initialized
DEBUG - 2018-05-21 21:46:47 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-21 21:46:47 --> Helper loaded: url_helper
INFO - 2018-05-21 21:46:47 --> Helper loaded: form_helper
INFO - 2018-05-21 21:46:47 --> Helper loaded: date_helper
INFO - 2018-05-21 21:46:47 --> Helper loaded: util_helper
INFO - 2018-05-21 21:46:47 --> Helper loaded: text_helper
INFO - 2018-05-21 21:46:47 --> Helper loaded: string_helper
INFO - 2018-05-21 21:46:47 --> Database Driver Class Initialized
DEBUG - 2018-05-21 21:46:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-21 21:46:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-21 21:46:47 --> Email Class Initialized
INFO - 2018-05-21 21:46:47 --> Controller Class Initialized
DEBUG - 2018-05-21 21:46:48 --> Home MX_Controller Initialized
DEBUG - 2018-05-21 21:46:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-21 21:46:48 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-21 21:46:48 --> Login MX_Controller Initialized
INFO - 2018-05-21 21:46:48 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-21 21:46:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-21 21:46:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-21 21:46:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-21 21:46:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-21 21:46:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-21 21:46:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-21 21:46:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-21 21:46:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/progress.php
INFO - 2018-05-21 21:46:48 --> Final output sent to browser
DEBUG - 2018-05-21 21:46:48 --> Total execution time: 0.6038
INFO - 2018-05-21 21:46:48 --> Config Class Initialized
INFO - 2018-05-21 21:46:48 --> Hooks Class Initialized
DEBUG - 2018-05-21 21:46:48 --> UTF-8 Support Enabled
INFO - 2018-05-21 21:46:48 --> Utf8 Class Initialized
INFO - 2018-05-21 21:46:48 --> URI Class Initialized
INFO - 2018-05-21 21:46:49 --> Router Class Initialized
INFO - 2018-05-21 21:46:49 --> Output Class Initialized
INFO - 2018-05-21 21:46:49 --> Security Class Initialized
DEBUG - 2018-05-21 21:46:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-21 21:46:49 --> Input Class Initialized
INFO - 2018-05-21 21:46:49 --> Language Class Initialized
ERROR - 2018-05-21 21:46:49 --> 404 Page Not Found: /index
INFO - 2018-05-21 21:46:49 --> Config Class Initialized
INFO - 2018-05-21 21:46:49 --> Hooks Class Initialized
DEBUG - 2018-05-21 21:46:49 --> UTF-8 Support Enabled
INFO - 2018-05-21 21:46:49 --> Utf8 Class Initialized
INFO - 2018-05-21 21:46:49 --> URI Class Initialized
INFO - 2018-05-21 21:46:49 --> Router Class Initialized
INFO - 2018-05-21 21:46:49 --> Output Class Initialized
INFO - 2018-05-21 21:46:49 --> Security Class Initialized
DEBUG - 2018-05-21 21:46:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-21 21:46:49 --> Input Class Initialized
INFO - 2018-05-21 21:46:49 --> Language Class Initialized
ERROR - 2018-05-21 21:46:49 --> 404 Page Not Found: /index
INFO - 2018-05-21 21:46:49 --> Config Class Initialized
INFO - 2018-05-21 21:46:49 --> Hooks Class Initialized
DEBUG - 2018-05-21 21:46:49 --> UTF-8 Support Enabled
INFO - 2018-05-21 21:46:49 --> Utf8 Class Initialized
INFO - 2018-05-21 21:46:49 --> URI Class Initialized
INFO - 2018-05-21 21:46:49 --> Router Class Initialized
INFO - 2018-05-21 21:46:49 --> Output Class Initialized
INFO - 2018-05-21 21:46:49 --> Security Class Initialized
DEBUG - 2018-05-21 21:46:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-21 21:46:49 --> Input Class Initialized
INFO - 2018-05-21 21:46:49 --> Language Class Initialized
ERROR - 2018-05-21 21:46:49 --> 404 Page Not Found: /index
INFO - 2018-05-21 21:46:53 --> Config Class Initialized
INFO - 2018-05-21 21:46:53 --> Hooks Class Initialized
DEBUG - 2018-05-21 21:46:53 --> UTF-8 Support Enabled
INFO - 2018-05-21 21:46:53 --> Utf8 Class Initialized
INFO - 2018-05-21 21:46:53 --> URI Class Initialized
INFO - 2018-05-21 21:46:53 --> Router Class Initialized
INFO - 2018-05-21 21:46:53 --> Output Class Initialized
INFO - 2018-05-21 21:46:53 --> Security Class Initialized
DEBUG - 2018-05-21 21:46:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-21 21:46:53 --> Input Class Initialized
INFO - 2018-05-21 21:46:53 --> Language Class Initialized
INFO - 2018-05-21 21:46:54 --> Language Class Initialized
INFO - 2018-05-21 21:46:54 --> Config Class Initialized
INFO - 2018-05-21 21:46:54 --> Loader Class Initialized
DEBUG - 2018-05-21 21:46:54 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-21 21:46:54 --> Helper loaded: url_helper
INFO - 2018-05-21 21:46:54 --> Helper loaded: form_helper
INFO - 2018-05-21 21:46:54 --> Helper loaded: date_helper
INFO - 2018-05-21 21:46:54 --> Helper loaded: util_helper
INFO - 2018-05-21 21:46:54 --> Helper loaded: text_helper
INFO - 2018-05-21 21:46:54 --> Helper loaded: string_helper
INFO - 2018-05-21 21:46:54 --> Database Driver Class Initialized
DEBUG - 2018-05-21 21:46:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-21 21:46:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-21 21:46:54 --> Email Class Initialized
INFO - 2018-05-21 21:46:54 --> Controller Class Initialized
DEBUG - 2018-05-21 21:46:54 --> Profile MX_Controller Initialized
DEBUG - 2018-05-21 21:46:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-21 21:46:54 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-21 21:46:54 --> Login MX_Controller Initialized
INFO - 2018-05-21 21:46:54 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-21 21:46:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-21 21:46:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-21 21:46:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-21 21:46:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-21 21:46:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-21 21:46:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/profile_left_nav.php
DEBUG - 2018-05-21 21:46:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-21 21:46:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-21 21:46:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/profile.php
INFO - 2018-05-21 21:46:55 --> Final output sent to browser
INFO - 2018-05-21 21:46:55 --> Config Class Initialized
INFO - 2018-05-21 21:46:55 --> Hooks Class Initialized
DEBUG - 2018-05-21 21:46:55 --> Total execution time: 2.1043
DEBUG - 2018-05-21 21:46:55 --> UTF-8 Support Enabled
INFO - 2018-05-21 21:46:55 --> Utf8 Class Initialized
INFO - 2018-05-21 21:46:55 --> URI Class Initialized
INFO - 2018-05-21 21:46:56 --> Router Class Initialized
INFO - 2018-05-21 21:46:56 --> Output Class Initialized
INFO - 2018-05-21 21:46:56 --> Security Class Initialized
DEBUG - 2018-05-21 21:46:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-21 21:46:56 --> Input Class Initialized
INFO - 2018-05-21 21:46:56 --> Language Class Initialized
ERROR - 2018-05-21 21:46:56 --> 404 Page Not Found: /index
INFO - 2018-05-21 21:46:56 --> Config Class Initialized
INFO - 2018-05-21 21:46:56 --> Hooks Class Initialized
DEBUG - 2018-05-21 21:46:56 --> UTF-8 Support Enabled
INFO - 2018-05-21 21:46:56 --> Utf8 Class Initialized
INFO - 2018-05-21 21:46:56 --> URI Class Initialized
INFO - 2018-05-21 21:46:56 --> Router Class Initialized
INFO - 2018-05-21 21:46:56 --> Config Class Initialized
INFO - 2018-05-21 21:46:56 --> Hooks Class Initialized
INFO - 2018-05-21 21:46:56 --> Output Class Initialized
DEBUG - 2018-05-21 21:46:56 --> UTF-8 Support Enabled
INFO - 2018-05-21 21:46:56 --> Utf8 Class Initialized
INFO - 2018-05-21 21:46:56 --> URI Class Initialized
INFO - 2018-05-21 21:46:56 --> Router Class Initialized
INFO - 2018-05-21 21:46:56 --> Output Class Initialized
INFO - 2018-05-21 21:46:56 --> Security Class Initialized
DEBUG - 2018-05-21 21:46:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-21 21:46:56 --> Input Class Initialized
INFO - 2018-05-21 21:46:56 --> Language Class Initialized
ERROR - 2018-05-21 21:46:56 --> 404 Page Not Found: /index
INFO - 2018-05-21 21:46:56 --> Security Class Initialized
DEBUG - 2018-05-21 21:46:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-21 21:46:56 --> Input Class Initialized
INFO - 2018-05-21 21:46:56 --> Language Class Initialized
ERROR - 2018-05-21 21:46:56 --> 404 Page Not Found: /index
INFO - 2018-05-21 21:46:57 --> Config Class Initialized
INFO - 2018-05-21 21:46:57 --> Hooks Class Initialized
DEBUG - 2018-05-21 21:46:57 --> UTF-8 Support Enabled
INFO - 2018-05-21 21:46:57 --> Utf8 Class Initialized
INFO - 2018-05-21 21:46:57 --> URI Class Initialized
INFO - 2018-05-21 21:46:57 --> Router Class Initialized
INFO - 2018-05-21 21:46:57 --> Output Class Initialized
INFO - 2018-05-21 21:46:57 --> Security Class Initialized
DEBUG - 2018-05-21 21:46:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-21 21:46:57 --> Input Class Initialized
INFO - 2018-05-21 21:46:57 --> Language Class Initialized
ERROR - 2018-05-21 21:46:57 --> 404 Page Not Found: /index
INFO - 2018-05-21 21:46:57 --> Config Class Initialized
INFO - 2018-05-21 21:46:57 --> Hooks Class Initialized
DEBUG - 2018-05-21 21:46:57 --> UTF-8 Support Enabled
INFO - 2018-05-21 21:46:57 --> Utf8 Class Initialized
INFO - 2018-05-21 21:46:57 --> URI Class Initialized
INFO - 2018-05-21 21:46:57 --> Router Class Initialized
INFO - 2018-05-21 21:46:57 --> Output Class Initialized
INFO - 2018-05-21 21:46:57 --> Security Class Initialized
DEBUG - 2018-05-21 21:46:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-21 21:46:57 --> Input Class Initialized
INFO - 2018-05-21 21:46:57 --> Language Class Initialized
ERROR - 2018-05-21 21:46:57 --> 404 Page Not Found: /index
INFO - 2018-05-21 21:49:08 --> Config Class Initialized
INFO - 2018-05-21 21:49:08 --> Hooks Class Initialized
DEBUG - 2018-05-21 21:49:08 --> UTF-8 Support Enabled
INFO - 2018-05-21 21:49:08 --> Utf8 Class Initialized
INFO - 2018-05-21 21:49:08 --> URI Class Initialized
INFO - 2018-05-21 21:49:08 --> Router Class Initialized
INFO - 2018-05-21 21:49:08 --> Output Class Initialized
INFO - 2018-05-21 21:49:08 --> Security Class Initialized
DEBUG - 2018-05-21 21:49:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-21 21:49:08 --> Input Class Initialized
INFO - 2018-05-21 21:49:08 --> Language Class Initialized
INFO - 2018-05-21 21:49:08 --> Language Class Initialized
INFO - 2018-05-21 21:49:08 --> Config Class Initialized
INFO - 2018-05-21 21:49:08 --> Loader Class Initialized
DEBUG - 2018-05-21 21:49:08 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-21 21:49:08 --> Helper loaded: url_helper
INFO - 2018-05-21 21:49:08 --> Helper loaded: form_helper
INFO - 2018-05-21 21:49:08 --> Helper loaded: date_helper
INFO - 2018-05-21 21:49:08 --> Helper loaded: util_helper
INFO - 2018-05-21 21:49:08 --> Helper loaded: text_helper
INFO - 2018-05-21 21:49:08 --> Helper loaded: string_helper
INFO - 2018-05-21 21:49:08 --> Database Driver Class Initialized
DEBUG - 2018-05-21 21:49:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-21 21:49:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-21 21:49:08 --> Email Class Initialized
INFO - 2018-05-21 21:49:08 --> Controller Class Initialized
DEBUG - 2018-05-21 21:49:08 --> Profile MX_Controller Initialized
DEBUG - 2018-05-21 21:49:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-21 21:49:08 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-21 21:49:08 --> Login MX_Controller Initialized
INFO - 2018-05-21 21:49:08 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-21 21:49:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-21 21:49:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-21 21:49:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-21 21:49:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-21 21:49:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-21 21:49:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/profile_left_nav.php
DEBUG - 2018-05-21 21:49:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-21 21:49:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-21 21:49:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/reset_password.php
INFO - 2018-05-21 21:49:08 --> Final output sent to browser
DEBUG - 2018-05-21 21:49:08 --> Total execution time: 0.5569
INFO - 2018-05-21 21:49:09 --> Config Class Initialized
INFO - 2018-05-21 21:49:09 --> Hooks Class Initialized
DEBUG - 2018-05-21 21:49:09 --> UTF-8 Support Enabled
INFO - 2018-05-21 21:49:09 --> Utf8 Class Initialized
INFO - 2018-05-21 21:49:09 --> URI Class Initialized
INFO - 2018-05-21 21:49:09 --> Router Class Initialized
INFO - 2018-05-21 21:49:09 --> Output Class Initialized
INFO - 2018-05-21 21:49:09 --> Security Class Initialized
DEBUG - 2018-05-21 21:49:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-21 21:49:09 --> Input Class Initialized
INFO - 2018-05-21 21:49:09 --> Language Class Initialized
ERROR - 2018-05-21 21:49:09 --> 404 Page Not Found: /index
INFO - 2018-05-21 21:49:09 --> Config Class Initialized
INFO - 2018-05-21 21:49:09 --> Hooks Class Initialized
DEBUG - 2018-05-21 21:49:09 --> UTF-8 Support Enabled
INFO - 2018-05-21 21:49:09 --> Utf8 Class Initialized
INFO - 2018-05-21 21:49:09 --> URI Class Initialized
INFO - 2018-05-21 21:49:09 --> Router Class Initialized
INFO - 2018-05-21 21:49:09 --> Output Class Initialized
INFO - 2018-05-21 21:49:09 --> Security Class Initialized
DEBUG - 2018-05-21 21:49:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-21 21:49:09 --> Input Class Initialized
INFO - 2018-05-21 21:49:09 --> Language Class Initialized
ERROR - 2018-05-21 21:49:09 --> 404 Page Not Found: /index
INFO - 2018-05-21 21:49:09 --> Config Class Initialized
INFO - 2018-05-21 21:49:09 --> Hooks Class Initialized
DEBUG - 2018-05-21 21:49:09 --> UTF-8 Support Enabled
INFO - 2018-05-21 21:49:09 --> Utf8 Class Initialized
INFO - 2018-05-21 21:49:09 --> URI Class Initialized
INFO - 2018-05-21 21:49:09 --> Router Class Initialized
INFO - 2018-05-21 21:49:09 --> Output Class Initialized
INFO - 2018-05-21 21:49:09 --> Security Class Initialized
DEBUG - 2018-05-21 21:49:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-21 21:49:09 --> Input Class Initialized
INFO - 2018-05-21 21:49:09 --> Language Class Initialized
ERROR - 2018-05-21 21:49:09 --> 404 Page Not Found: /index
INFO - 2018-05-21 21:49:35 --> Config Class Initialized
INFO - 2018-05-21 21:49:35 --> Hooks Class Initialized
DEBUG - 2018-05-21 21:49:35 --> UTF-8 Support Enabled
INFO - 2018-05-21 21:49:35 --> Utf8 Class Initialized
INFO - 2018-05-21 21:49:35 --> URI Class Initialized
INFO - 2018-05-21 21:49:35 --> Router Class Initialized
INFO - 2018-05-21 21:49:35 --> Output Class Initialized
INFO - 2018-05-21 21:49:35 --> Security Class Initialized
DEBUG - 2018-05-21 21:49:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-21 21:49:35 --> Input Class Initialized
INFO - 2018-05-21 21:49:35 --> Language Class Initialized
INFO - 2018-05-21 21:49:35 --> Language Class Initialized
INFO - 2018-05-21 21:49:35 --> Config Class Initialized
INFO - 2018-05-21 21:49:35 --> Loader Class Initialized
DEBUG - 2018-05-21 21:49:35 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-21 21:49:35 --> Helper loaded: url_helper
INFO - 2018-05-21 21:49:35 --> Helper loaded: form_helper
INFO - 2018-05-21 21:49:35 --> Helper loaded: date_helper
INFO - 2018-05-21 21:49:35 --> Helper loaded: util_helper
INFO - 2018-05-21 21:49:35 --> Helper loaded: text_helper
INFO - 2018-05-21 21:49:35 --> Helper loaded: string_helper
INFO - 2018-05-21 21:49:35 --> Database Driver Class Initialized
DEBUG - 2018-05-21 21:49:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-21 21:49:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-21 21:49:35 --> Email Class Initialized
INFO - 2018-05-21 21:49:35 --> Controller Class Initialized
DEBUG - 2018-05-21 21:49:35 --> Profile MX_Controller Initialized
DEBUG - 2018-05-21 21:49:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-21 21:49:35 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-21 21:49:35 --> Login MX_Controller Initialized
INFO - 2018-05-21 21:49:35 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-21 21:49:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-21 21:49:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-21 21:49:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-21 21:49:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-21 21:49:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-21 21:49:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/profile_left_nav.php
DEBUG - 2018-05-21 21:49:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-21 21:49:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-21 21:49:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/reset_password.php
INFO - 2018-05-21 21:49:35 --> Final output sent to browser
DEBUG - 2018-05-21 21:49:35 --> Total execution time: 0.4511
INFO - 2018-05-21 21:49:35 --> Config Class Initialized
INFO - 2018-05-21 21:49:35 --> Hooks Class Initialized
DEBUG - 2018-05-21 21:49:35 --> UTF-8 Support Enabled
INFO - 2018-05-21 21:49:35 --> Utf8 Class Initialized
INFO - 2018-05-21 21:49:35 --> URI Class Initialized
INFO - 2018-05-21 21:49:36 --> Router Class Initialized
INFO - 2018-05-21 21:49:36 --> Output Class Initialized
INFO - 2018-05-21 21:49:36 --> Security Class Initialized
DEBUG - 2018-05-21 21:49:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-21 21:49:36 --> Input Class Initialized
INFO - 2018-05-21 21:49:36 --> Language Class Initialized
ERROR - 2018-05-21 21:49:36 --> 404 Page Not Found: /index
INFO - 2018-05-21 21:49:36 --> Config Class Initialized
INFO - 2018-05-21 21:49:36 --> Hooks Class Initialized
DEBUG - 2018-05-21 21:49:36 --> UTF-8 Support Enabled
INFO - 2018-05-21 21:49:36 --> Utf8 Class Initialized
INFO - 2018-05-21 21:49:36 --> URI Class Initialized
INFO - 2018-05-21 21:49:36 --> Router Class Initialized
INFO - 2018-05-21 21:49:36 --> Output Class Initialized
INFO - 2018-05-21 21:49:36 --> Security Class Initialized
DEBUG - 2018-05-21 21:49:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-21 21:49:36 --> Input Class Initialized
INFO - 2018-05-21 21:49:36 --> Language Class Initialized
ERROR - 2018-05-21 21:49:36 --> 404 Page Not Found: /index
INFO - 2018-05-21 21:49:36 --> Config Class Initialized
INFO - 2018-05-21 21:49:36 --> Hooks Class Initialized
DEBUG - 2018-05-21 21:49:36 --> UTF-8 Support Enabled
INFO - 2018-05-21 21:49:36 --> Utf8 Class Initialized
INFO - 2018-05-21 21:49:36 --> URI Class Initialized
INFO - 2018-05-21 21:49:36 --> Router Class Initialized
INFO - 2018-05-21 21:49:36 --> Output Class Initialized
INFO - 2018-05-21 21:49:36 --> Security Class Initialized
DEBUG - 2018-05-21 21:49:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-21 21:49:36 --> Input Class Initialized
INFO - 2018-05-21 21:49:36 --> Language Class Initialized
ERROR - 2018-05-21 21:49:36 --> 404 Page Not Found: /index
INFO - 2018-05-21 22:18:34 --> Config Class Initialized
INFO - 2018-05-21 22:18:34 --> Hooks Class Initialized
DEBUG - 2018-05-21 22:18:34 --> UTF-8 Support Enabled
INFO - 2018-05-21 22:18:34 --> Utf8 Class Initialized
INFO - 2018-05-21 22:18:34 --> URI Class Initialized
INFO - 2018-05-21 22:18:34 --> Router Class Initialized
INFO - 2018-05-21 22:18:34 --> Output Class Initialized
INFO - 2018-05-21 22:18:34 --> Security Class Initialized
DEBUG - 2018-05-21 22:18:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-21 22:18:34 --> Input Class Initialized
INFO - 2018-05-21 22:18:34 --> Language Class Initialized
INFO - 2018-05-21 22:18:34 --> Language Class Initialized
INFO - 2018-05-21 22:18:34 --> Config Class Initialized
INFO - 2018-05-21 22:18:34 --> Loader Class Initialized
DEBUG - 2018-05-21 22:18:34 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-21 22:18:34 --> Helper loaded: url_helper
INFO - 2018-05-21 22:18:34 --> Helper loaded: form_helper
INFO - 2018-05-21 22:18:34 --> Helper loaded: date_helper
INFO - 2018-05-21 22:18:34 --> Helper loaded: util_helper
INFO - 2018-05-21 22:18:34 --> Helper loaded: text_helper
INFO - 2018-05-21 22:18:34 --> Helper loaded: string_helper
INFO - 2018-05-21 22:18:34 --> Database Driver Class Initialized
DEBUG - 2018-05-21 22:18:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-21 22:18:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-21 22:18:34 --> Email Class Initialized
INFO - 2018-05-21 22:18:34 --> Controller Class Initialized
DEBUG - 2018-05-21 22:18:34 --> Home MX_Controller Initialized
DEBUG - 2018-05-21 22:18:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-21 22:18:34 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-21 22:18:34 --> Login MX_Controller Initialized
INFO - 2018-05-21 22:18:34 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-21 22:18:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-21 22:18:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-21 22:18:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-21 22:18:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-21 22:18:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-21 22:18:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-21 22:18:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-21 22:18:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-05-21 22:18:34 --> Final output sent to browser
DEBUG - 2018-05-21 22:18:34 --> Total execution time: 0.5668
INFO - 2018-05-21 22:18:35 --> Config Class Initialized
INFO - 2018-05-21 22:18:35 --> Hooks Class Initialized
DEBUG - 2018-05-21 22:18:35 --> UTF-8 Support Enabled
INFO - 2018-05-21 22:18:35 --> Utf8 Class Initialized
INFO - 2018-05-21 22:18:35 --> URI Class Initialized
INFO - 2018-05-21 22:18:35 --> Router Class Initialized
INFO - 2018-05-21 22:18:35 --> Output Class Initialized
INFO - 2018-05-21 22:18:35 --> Security Class Initialized
DEBUG - 2018-05-21 22:18:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-21 22:18:35 --> Input Class Initialized
INFO - 2018-05-21 22:18:35 --> Language Class Initialized
ERROR - 2018-05-21 22:18:35 --> 404 Page Not Found: /index
INFO - 2018-05-21 22:18:35 --> Config Class Initialized
INFO - 2018-05-21 22:18:35 --> Hooks Class Initialized
DEBUG - 2018-05-21 22:18:35 --> UTF-8 Support Enabled
INFO - 2018-05-21 22:18:35 --> Utf8 Class Initialized
INFO - 2018-05-21 22:18:35 --> URI Class Initialized
INFO - 2018-05-21 22:18:35 --> Router Class Initialized
INFO - 2018-05-21 22:18:35 --> Output Class Initialized
INFO - 2018-05-21 22:18:35 --> Security Class Initialized
DEBUG - 2018-05-21 22:18:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-21 22:18:35 --> Input Class Initialized
INFO - 2018-05-21 22:18:35 --> Language Class Initialized
ERROR - 2018-05-21 22:18:35 --> 404 Page Not Found: /index
INFO - 2018-05-21 22:18:35 --> Config Class Initialized
INFO - 2018-05-21 22:18:35 --> Hooks Class Initialized
DEBUG - 2018-05-21 22:18:35 --> UTF-8 Support Enabled
INFO - 2018-05-21 22:18:35 --> Utf8 Class Initialized
INFO - 2018-05-21 22:18:35 --> URI Class Initialized
INFO - 2018-05-21 22:18:35 --> Router Class Initialized
INFO - 2018-05-21 22:18:35 --> Output Class Initialized
INFO - 2018-05-21 22:18:35 --> Config Class Initialized
INFO - 2018-05-21 22:18:35 --> Hooks Class Initialized
INFO - 2018-05-21 22:18:35 --> Security Class Initialized
DEBUG - 2018-05-21 22:18:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-21 22:18:35 --> UTF-8 Support Enabled
INFO - 2018-05-21 22:18:35 --> Input Class Initialized
INFO - 2018-05-21 22:18:35 --> Utf8 Class Initialized
INFO - 2018-05-21 22:18:35 --> Language Class Initialized
INFO - 2018-05-21 22:18:35 --> URI Class Initialized
ERROR - 2018-05-21 22:18:35 --> 404 Page Not Found: /index
INFO - 2018-05-21 22:18:35 --> Router Class Initialized
INFO - 2018-05-21 22:18:35 --> Output Class Initialized
INFO - 2018-05-21 22:18:35 --> Security Class Initialized
DEBUG - 2018-05-21 22:18:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-21 22:18:35 --> Input Class Initialized
INFO - 2018-05-21 22:18:35 --> Language Class Initialized
INFO - 2018-05-21 22:18:35 --> Language Class Initialized
INFO - 2018-05-21 22:18:35 --> Config Class Initialized
INFO - 2018-05-21 22:18:35 --> Loader Class Initialized
DEBUG - 2018-05-21 22:18:35 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-21 22:18:35 --> Helper loaded: url_helper
INFO - 2018-05-21 22:18:35 --> Helper loaded: form_helper
INFO - 2018-05-21 22:18:35 --> Helper loaded: date_helper
INFO - 2018-05-21 22:18:35 --> Helper loaded: util_helper
INFO - 2018-05-21 22:18:35 --> Helper loaded: text_helper
INFO - 2018-05-21 22:18:35 --> Helper loaded: string_helper
INFO - 2018-05-21 22:18:35 --> Database Driver Class Initialized
DEBUG - 2018-05-21 22:18:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-21 22:18:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-21 22:18:35 --> Email Class Initialized
INFO - 2018-05-21 22:18:35 --> Controller Class Initialized
DEBUG - 2018-05-21 22:18:35 --> Home MX_Controller Initialized
DEBUG - 2018-05-21 22:18:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-21 22:18:35 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-21 22:18:35 --> Login MX_Controller Initialized
INFO - 2018-05-21 22:18:35 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-21 22:18:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-21 22:18:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-21 22:18:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-21 22:18:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-21 22:18:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-21 22:18:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-21 22:18:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-21 22:18:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/progress.php
INFO - 2018-05-21 22:18:36 --> Final output sent to browser
DEBUG - 2018-05-21 22:18:36 --> Total execution time: 0.4685
INFO - 2018-05-21 22:18:36 --> Config Class Initialized
INFO - 2018-05-21 22:18:36 --> Hooks Class Initialized
DEBUG - 2018-05-21 22:18:36 --> UTF-8 Support Enabled
INFO - 2018-05-21 22:18:36 --> Utf8 Class Initialized
INFO - 2018-05-21 22:18:36 --> URI Class Initialized
INFO - 2018-05-21 22:18:36 --> Router Class Initialized
INFO - 2018-05-21 22:18:36 --> Output Class Initialized
INFO - 2018-05-21 22:18:36 --> Security Class Initialized
DEBUG - 2018-05-21 22:18:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-21 22:18:36 --> Input Class Initialized
INFO - 2018-05-21 22:18:36 --> Language Class Initialized
ERROR - 2018-05-21 22:18:36 --> 404 Page Not Found: /index
INFO - 2018-05-21 22:18:36 --> Config Class Initialized
INFO - 2018-05-21 22:18:37 --> Hooks Class Initialized
DEBUG - 2018-05-21 22:18:37 --> UTF-8 Support Enabled
INFO - 2018-05-21 22:18:37 --> Utf8 Class Initialized
INFO - 2018-05-21 22:18:37 --> URI Class Initialized
INFO - 2018-05-21 22:18:37 --> Router Class Initialized
INFO - 2018-05-21 22:18:37 --> Output Class Initialized
INFO - 2018-05-21 22:18:37 --> Security Class Initialized
DEBUG - 2018-05-21 22:18:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-21 22:18:37 --> Input Class Initialized
INFO - 2018-05-21 22:18:37 --> Language Class Initialized
ERROR - 2018-05-21 22:18:37 --> 404 Page Not Found: /index
INFO - 2018-05-21 22:18:37 --> Config Class Initialized
INFO - 2018-05-21 22:18:37 --> Hooks Class Initialized
DEBUG - 2018-05-21 22:18:37 --> UTF-8 Support Enabled
INFO - 2018-05-21 22:18:37 --> Utf8 Class Initialized
INFO - 2018-05-21 22:18:37 --> URI Class Initialized
INFO - 2018-05-21 22:18:37 --> Router Class Initialized
INFO - 2018-05-21 22:18:37 --> Output Class Initialized
INFO - 2018-05-21 22:18:37 --> Security Class Initialized
DEBUG - 2018-05-21 22:18:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-21 22:18:37 --> Input Class Initialized
INFO - 2018-05-21 22:18:37 --> Language Class Initialized
ERROR - 2018-05-21 22:18:37 --> 404 Page Not Found: /index
INFO - 2018-05-21 22:18:46 --> Config Class Initialized
INFO - 2018-05-21 22:18:46 --> Hooks Class Initialized
DEBUG - 2018-05-21 22:18:46 --> UTF-8 Support Enabled
INFO - 2018-05-21 22:18:46 --> Utf8 Class Initialized
INFO - 2018-05-21 22:18:46 --> URI Class Initialized
INFO - 2018-05-21 22:18:46 --> Router Class Initialized
INFO - 2018-05-21 22:18:46 --> Output Class Initialized
INFO - 2018-05-21 22:18:46 --> Security Class Initialized
DEBUG - 2018-05-21 22:18:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-21 22:18:46 --> Input Class Initialized
INFO - 2018-05-21 22:18:46 --> Language Class Initialized
INFO - 2018-05-21 22:18:46 --> Language Class Initialized
INFO - 2018-05-21 22:18:46 --> Config Class Initialized
INFO - 2018-05-21 22:18:46 --> Loader Class Initialized
DEBUG - 2018-05-21 22:18:46 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-21 22:18:46 --> Helper loaded: url_helper
INFO - 2018-05-21 22:18:46 --> Helper loaded: form_helper
INFO - 2018-05-21 22:18:46 --> Helper loaded: date_helper
INFO - 2018-05-21 22:18:46 --> Helper loaded: util_helper
INFO - 2018-05-21 22:18:46 --> Helper loaded: text_helper
INFO - 2018-05-21 22:18:47 --> Helper loaded: string_helper
INFO - 2018-05-21 22:18:47 --> Database Driver Class Initialized
DEBUG - 2018-05-21 22:18:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-21 22:18:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-21 22:18:47 --> Email Class Initialized
INFO - 2018-05-21 22:18:47 --> Controller Class Initialized
DEBUG - 2018-05-21 22:18:47 --> Profile MX_Controller Initialized
DEBUG - 2018-05-21 22:18:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-21 22:18:47 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-21 22:18:47 --> Login MX_Controller Initialized
INFO - 2018-05-21 22:18:47 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-21 22:18:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-21 22:18:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-21 22:18:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-21 22:18:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-21 22:18:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-21 22:18:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/profile_left_nav.php
DEBUG - 2018-05-21 22:18:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-21 22:18:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-21 22:18:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/profile.php
INFO - 2018-05-21 22:18:47 --> Final output sent to browser
DEBUG - 2018-05-21 22:18:47 --> Total execution time: 0.4982
INFO - 2018-05-21 22:18:47 --> Config Class Initialized
INFO - 2018-05-21 22:18:47 --> Hooks Class Initialized
DEBUG - 2018-05-21 22:18:47 --> UTF-8 Support Enabled
INFO - 2018-05-21 22:18:47 --> Utf8 Class Initialized
INFO - 2018-05-21 22:18:47 --> URI Class Initialized
INFO - 2018-05-21 22:18:47 --> Router Class Initialized
INFO - 2018-05-21 22:18:47 --> Output Class Initialized
INFO - 2018-05-21 22:18:47 --> Security Class Initialized
DEBUG - 2018-05-21 22:18:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-21 22:18:47 --> Input Class Initialized
INFO - 2018-05-21 22:18:47 --> Language Class Initialized
INFO - 2018-05-21 22:18:47 --> Config Class Initialized
INFO - 2018-05-21 22:18:47 --> Hooks Class Initialized
ERROR - 2018-05-21 22:18:47 --> 404 Page Not Found: /index
DEBUG - 2018-05-21 22:18:47 --> UTF-8 Support Enabled
INFO - 2018-05-21 22:18:47 --> Config Class Initialized
INFO - 2018-05-21 22:18:47 --> Hooks Class Initialized
INFO - 2018-05-21 22:18:47 --> Utf8 Class Initialized
DEBUG - 2018-05-21 22:18:47 --> UTF-8 Support Enabled
INFO - 2018-05-21 22:18:47 --> Utf8 Class Initialized
INFO - 2018-05-21 22:18:47 --> URI Class Initialized
INFO - 2018-05-21 22:18:47 --> Router Class Initialized
INFO - 2018-05-21 22:18:47 --> Output Class Initialized
INFO - 2018-05-21 22:18:47 --> Security Class Initialized
DEBUG - 2018-05-21 22:18:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-21 22:18:47 --> Input Class Initialized
INFO - 2018-05-21 22:18:47 --> Language Class Initialized
ERROR - 2018-05-21 22:18:47 --> 404 Page Not Found: /index
INFO - 2018-05-21 22:18:47 --> URI Class Initialized
INFO - 2018-05-21 22:18:47 --> Router Class Initialized
INFO - 2018-05-21 22:18:47 --> Output Class Initialized
INFO - 2018-05-21 22:18:47 --> Security Class Initialized
DEBUG - 2018-05-21 22:18:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-21 22:18:47 --> Input Class Initialized
INFO - 2018-05-21 22:18:47 --> Language Class Initialized
ERROR - 2018-05-21 22:18:48 --> 404 Page Not Found: /index
INFO - 2018-05-21 22:18:48 --> Config Class Initialized
INFO - 2018-05-21 22:18:48 --> Hooks Class Initialized
DEBUG - 2018-05-21 22:18:48 --> UTF-8 Support Enabled
INFO - 2018-05-21 22:18:48 --> Utf8 Class Initialized
INFO - 2018-05-21 22:18:48 --> URI Class Initialized
INFO - 2018-05-21 22:18:48 --> Router Class Initialized
INFO - 2018-05-21 22:18:48 --> Output Class Initialized
INFO - 2018-05-21 22:18:48 --> Security Class Initialized
DEBUG - 2018-05-21 22:18:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-21 22:18:48 --> Input Class Initialized
INFO - 2018-05-21 22:18:48 --> Language Class Initialized
ERROR - 2018-05-21 22:18:48 --> 404 Page Not Found: /index
INFO - 2018-05-21 22:18:48 --> Config Class Initialized
INFO - 2018-05-21 22:18:48 --> Hooks Class Initialized
DEBUG - 2018-05-21 22:18:48 --> UTF-8 Support Enabled
INFO - 2018-05-21 22:18:48 --> Utf8 Class Initialized
INFO - 2018-05-21 22:18:48 --> URI Class Initialized
INFO - 2018-05-21 22:18:48 --> Router Class Initialized
INFO - 2018-05-21 22:18:48 --> Output Class Initialized
INFO - 2018-05-21 22:18:48 --> Security Class Initialized
DEBUG - 2018-05-21 22:18:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-21 22:18:48 --> Input Class Initialized
INFO - 2018-05-21 22:18:48 --> Language Class Initialized
ERROR - 2018-05-21 22:18:48 --> 404 Page Not Found: /index
INFO - 2018-05-21 22:18:51 --> Config Class Initialized
INFO - 2018-05-21 22:18:51 --> Hooks Class Initialized
DEBUG - 2018-05-21 22:18:51 --> UTF-8 Support Enabled
INFO - 2018-05-21 22:18:51 --> Utf8 Class Initialized
INFO - 2018-05-21 22:18:51 --> URI Class Initialized
INFO - 2018-05-21 22:18:51 --> Router Class Initialized
INFO - 2018-05-21 22:18:51 --> Output Class Initialized
INFO - 2018-05-21 22:18:52 --> Security Class Initialized
DEBUG - 2018-05-21 22:18:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-21 22:18:52 --> Input Class Initialized
INFO - 2018-05-21 22:18:52 --> Language Class Initialized
INFO - 2018-05-21 22:18:52 --> Language Class Initialized
INFO - 2018-05-21 22:18:52 --> Config Class Initialized
INFO - 2018-05-21 22:18:52 --> Loader Class Initialized
DEBUG - 2018-05-21 22:18:52 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-21 22:18:52 --> Helper loaded: url_helper
INFO - 2018-05-21 22:18:52 --> Helper loaded: form_helper
INFO - 2018-05-21 22:18:52 --> Helper loaded: date_helper
INFO - 2018-05-21 22:18:52 --> Helper loaded: util_helper
INFO - 2018-05-21 22:18:52 --> Helper loaded: text_helper
INFO - 2018-05-21 22:18:52 --> Helper loaded: string_helper
INFO - 2018-05-21 22:18:52 --> Database Driver Class Initialized
DEBUG - 2018-05-21 22:18:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-21 22:18:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-21 22:18:52 --> Email Class Initialized
INFO - 2018-05-21 22:18:52 --> Controller Class Initialized
DEBUG - 2018-05-21 22:18:52 --> Profile MX_Controller Initialized
DEBUG - 2018-05-21 22:18:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-21 22:18:52 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-21 22:18:52 --> Login MX_Controller Initialized
INFO - 2018-05-21 22:18:52 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-21 22:18:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-21 22:18:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-21 22:18:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-21 22:18:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-21 22:18:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-21 22:18:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/profile_left_nav.php
DEBUG - 2018-05-21 22:18:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-21 22:18:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-21 22:18:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/reset_password.php
INFO - 2018-05-21 22:18:52 --> Final output sent to browser
DEBUG - 2018-05-21 22:18:52 --> Total execution time: 0.4935
INFO - 2018-05-21 22:18:52 --> Config Class Initialized
INFO - 2018-05-21 22:18:52 --> Hooks Class Initialized
DEBUG - 2018-05-21 22:18:52 --> UTF-8 Support Enabled
INFO - 2018-05-21 22:18:52 --> Utf8 Class Initialized
INFO - 2018-05-21 22:18:52 --> URI Class Initialized
INFO - 2018-05-21 22:18:52 --> Router Class Initialized
INFO - 2018-05-21 22:18:52 --> Output Class Initialized
INFO - 2018-05-21 22:18:52 --> Security Class Initialized
DEBUG - 2018-05-21 22:18:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-21 22:18:52 --> Input Class Initialized
INFO - 2018-05-21 22:18:52 --> Language Class Initialized
ERROR - 2018-05-21 22:18:52 --> 404 Page Not Found: /index
INFO - 2018-05-21 22:18:52 --> Config Class Initialized
INFO - 2018-05-21 22:18:52 --> Hooks Class Initialized
DEBUG - 2018-05-21 22:18:52 --> UTF-8 Support Enabled
INFO - 2018-05-21 22:18:52 --> Utf8 Class Initialized
INFO - 2018-05-21 22:18:52 --> URI Class Initialized
INFO - 2018-05-21 22:18:53 --> Router Class Initialized
INFO - 2018-05-21 22:18:53 --> Output Class Initialized
INFO - 2018-05-21 22:18:53 --> Security Class Initialized
DEBUG - 2018-05-21 22:18:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-21 22:18:53 --> Input Class Initialized
INFO - 2018-05-21 22:18:53 --> Language Class Initialized
ERROR - 2018-05-21 22:18:53 --> 404 Page Not Found: /index
INFO - 2018-05-21 22:18:53 --> Config Class Initialized
INFO - 2018-05-21 22:18:53 --> Hooks Class Initialized
DEBUG - 2018-05-21 22:18:53 --> UTF-8 Support Enabled
INFO - 2018-05-21 22:18:53 --> Utf8 Class Initialized
INFO - 2018-05-21 22:18:53 --> URI Class Initialized
INFO - 2018-05-21 22:18:53 --> Router Class Initialized
INFO - 2018-05-21 22:18:53 --> Output Class Initialized
INFO - 2018-05-21 22:18:53 --> Security Class Initialized
DEBUG - 2018-05-21 22:18:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-21 22:18:53 --> Input Class Initialized
INFO - 2018-05-21 22:18:53 --> Language Class Initialized
ERROR - 2018-05-21 22:18:53 --> 404 Page Not Found: /index
INFO - 2018-05-21 22:18:56 --> Config Class Initialized
INFO - 2018-05-21 22:18:56 --> Hooks Class Initialized
DEBUG - 2018-05-21 22:18:56 --> UTF-8 Support Enabled
INFO - 2018-05-21 22:18:56 --> Utf8 Class Initialized
INFO - 2018-05-21 22:18:56 --> URI Class Initialized
INFO - 2018-05-21 22:18:56 --> Router Class Initialized
INFO - 2018-05-21 22:18:56 --> Output Class Initialized
INFO - 2018-05-21 22:18:56 --> Security Class Initialized
DEBUG - 2018-05-21 22:18:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-21 22:18:56 --> Input Class Initialized
INFO - 2018-05-21 22:18:56 --> Language Class Initialized
INFO - 2018-05-21 22:18:56 --> Language Class Initialized
INFO - 2018-05-21 22:18:56 --> Config Class Initialized
INFO - 2018-05-21 22:18:56 --> Loader Class Initialized
DEBUG - 2018-05-21 22:18:56 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-21 22:18:56 --> Helper loaded: url_helper
INFO - 2018-05-21 22:18:56 --> Helper loaded: form_helper
INFO - 2018-05-21 22:18:56 --> Helper loaded: date_helper
INFO - 2018-05-21 22:18:56 --> Helper loaded: util_helper
INFO - 2018-05-21 22:18:56 --> Helper loaded: text_helper
INFO - 2018-05-21 22:18:56 --> Helper loaded: string_helper
INFO - 2018-05-21 22:18:56 --> Database Driver Class Initialized
DEBUG - 2018-05-21 22:18:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-21 22:18:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-21 22:18:56 --> Email Class Initialized
INFO - 2018-05-21 22:18:56 --> Controller Class Initialized
DEBUG - 2018-05-21 22:18:56 --> Home MX_Controller Initialized
DEBUG - 2018-05-21 22:18:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-21 22:18:56 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-21 22:18:56 --> Login MX_Controller Initialized
INFO - 2018-05-21 22:18:56 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-21 22:18:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-21 22:18:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-21 22:18:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-21 22:18:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-21 22:18:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-21 22:18:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-21 22:18:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-21 22:18:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-05-21 22:18:56 --> Final output sent to browser
DEBUG - 2018-05-21 22:18:56 --> Total execution time: 0.4615
INFO - 2018-05-21 22:18:57 --> Config Class Initialized
INFO - 2018-05-21 22:18:57 --> Config Class Initialized
INFO - 2018-05-21 22:18:57 --> Hooks Class Initialized
INFO - 2018-05-21 22:18:57 --> Hooks Class Initialized
DEBUG - 2018-05-21 22:18:57 --> UTF-8 Support Enabled
DEBUG - 2018-05-21 22:18:57 --> UTF-8 Support Enabled
INFO - 2018-05-21 22:18:57 --> Utf8 Class Initialized
INFO - 2018-05-21 22:18:57 --> Utf8 Class Initialized
INFO - 2018-05-21 22:18:57 --> URI Class Initialized
INFO - 2018-05-21 22:18:57 --> URI Class Initialized
INFO - 2018-05-21 22:18:57 --> Router Class Initialized
INFO - 2018-05-21 22:18:57 --> Router Class Initialized
INFO - 2018-05-21 22:18:57 --> Output Class Initialized
INFO - 2018-05-21 22:18:57 --> Output Class Initialized
INFO - 2018-05-21 22:18:57 --> Security Class Initialized
INFO - 2018-05-21 22:18:57 --> Security Class Initialized
DEBUG - 2018-05-21 22:18:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-21 22:18:57 --> Input Class Initialized
DEBUG - 2018-05-21 22:18:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-21 22:18:57 --> Input Class Initialized
INFO - 2018-05-21 22:18:57 --> Language Class Initialized
INFO - 2018-05-21 22:18:57 --> Language Class Initialized
ERROR - 2018-05-21 22:18:57 --> 404 Page Not Found: /index
ERROR - 2018-05-21 22:18:57 --> 404 Page Not Found: /index
INFO - 2018-05-21 22:18:57 --> Config Class Initialized
INFO - 2018-05-21 22:18:57 --> Hooks Class Initialized
DEBUG - 2018-05-21 22:18:57 --> UTF-8 Support Enabled
INFO - 2018-05-21 22:18:57 --> Utf8 Class Initialized
INFO - 2018-05-21 22:18:57 --> URI Class Initialized
INFO - 2018-05-21 22:18:57 --> Router Class Initialized
INFO - 2018-05-21 22:18:57 --> Output Class Initialized
INFO - 2018-05-21 22:18:57 --> Security Class Initialized
DEBUG - 2018-05-21 22:18:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-21 22:18:57 --> Input Class Initialized
INFO - 2018-05-21 22:18:57 --> Language Class Initialized
ERROR - 2018-05-21 22:18:57 --> 404 Page Not Found: /index
INFO - 2018-05-21 22:18:57 --> Config Class Initialized
INFO - 2018-05-21 22:18:57 --> Hooks Class Initialized
DEBUG - 2018-05-21 22:18:57 --> UTF-8 Support Enabled
INFO - 2018-05-21 22:18:57 --> Utf8 Class Initialized
INFO - 2018-05-21 22:18:58 --> URI Class Initialized
INFO - 2018-05-21 22:18:58 --> Router Class Initialized
INFO - 2018-05-21 22:18:58 --> Output Class Initialized
INFO - 2018-05-21 22:18:58 --> Security Class Initialized
DEBUG - 2018-05-21 22:18:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-21 22:18:58 --> Input Class Initialized
INFO - 2018-05-21 22:18:58 --> Language Class Initialized
ERROR - 2018-05-21 22:18:58 --> 404 Page Not Found: /index
INFO - 2018-05-21 23:08:23 --> Config Class Initialized
INFO - 2018-05-21 23:08:23 --> Hooks Class Initialized
DEBUG - 2018-05-21 23:08:23 --> UTF-8 Support Enabled
INFO - 2018-05-21 23:08:23 --> Utf8 Class Initialized
INFO - 2018-05-21 23:08:23 --> URI Class Initialized
INFO - 2018-05-21 23:08:23 --> Router Class Initialized
INFO - 2018-05-21 23:08:23 --> Output Class Initialized
INFO - 2018-05-21 23:08:23 --> Security Class Initialized
DEBUG - 2018-05-21 23:08:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-21 23:08:23 --> Input Class Initialized
INFO - 2018-05-21 23:08:23 --> Language Class Initialized
INFO - 2018-05-21 23:08:23 --> Language Class Initialized
INFO - 2018-05-21 23:08:23 --> Config Class Initialized
INFO - 2018-05-21 23:08:23 --> Loader Class Initialized
DEBUG - 2018-05-21 23:08:23 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-21 23:08:23 --> Helper loaded: url_helper
INFO - 2018-05-21 23:08:23 --> Helper loaded: form_helper
INFO - 2018-05-21 23:08:23 --> Helper loaded: date_helper
INFO - 2018-05-21 23:08:23 --> Helper loaded: util_helper
INFO - 2018-05-21 23:08:23 --> Helper loaded: text_helper
INFO - 2018-05-21 23:08:23 --> Helper loaded: string_helper
INFO - 2018-05-21 23:08:23 --> Database Driver Class Initialized
DEBUG - 2018-05-21 23:08:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-21 23:08:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-21 23:08:23 --> Email Class Initialized
INFO - 2018-05-21 23:08:23 --> Controller Class Initialized
DEBUG - 2018-05-21 23:08:23 --> Profile MX_Controller Initialized
DEBUG - 2018-05-21 23:08:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-21 23:08:24 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-21 23:08:24 --> Login MX_Controller Initialized
INFO - 2018-05-21 23:08:24 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-21 23:08:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-21 23:08:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-21 23:08:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-21 23:08:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-21 23:08:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-21 23:08:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/profile_left_nav.php
DEBUG - 2018-05-21 23:08:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-21 23:08:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-21 23:08:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/reset_password.php
INFO - 2018-05-21 23:08:24 --> Final output sent to browser
DEBUG - 2018-05-21 23:08:24 --> Total execution time: 0.5424
INFO - 2018-05-21 23:08:24 --> Config Class Initialized
INFO - 2018-05-21 23:08:24 --> Hooks Class Initialized
DEBUG - 2018-05-21 23:08:24 --> UTF-8 Support Enabled
INFO - 2018-05-21 23:08:24 --> Utf8 Class Initialized
INFO - 2018-05-21 23:08:24 --> URI Class Initialized
INFO - 2018-05-21 23:08:24 --> Router Class Initialized
INFO - 2018-05-21 23:08:24 --> Output Class Initialized
INFO - 2018-05-21 23:08:24 --> Security Class Initialized
DEBUG - 2018-05-21 23:08:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-21 23:08:24 --> Input Class Initialized
INFO - 2018-05-21 23:08:24 --> Language Class Initialized
ERROR - 2018-05-21 23:08:24 --> 404 Page Not Found: /index
INFO - 2018-05-21 23:08:24 --> Config Class Initialized
INFO - 2018-05-21 23:08:25 --> Hooks Class Initialized
DEBUG - 2018-05-21 23:08:25 --> UTF-8 Support Enabled
INFO - 2018-05-21 23:08:25 --> Utf8 Class Initialized
INFO - 2018-05-21 23:08:25 --> URI Class Initialized
INFO - 2018-05-21 23:08:25 --> Router Class Initialized
INFO - 2018-05-21 23:08:25 --> Output Class Initialized
INFO - 2018-05-21 23:08:25 --> Security Class Initialized
DEBUG - 2018-05-21 23:08:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-21 23:08:25 --> Input Class Initialized
INFO - 2018-05-21 23:08:25 --> Language Class Initialized
ERROR - 2018-05-21 23:08:25 --> 404 Page Not Found: /index
INFO - 2018-05-21 23:08:25 --> Config Class Initialized
INFO - 2018-05-21 23:08:25 --> Hooks Class Initialized
DEBUG - 2018-05-21 23:08:25 --> UTF-8 Support Enabled
INFO - 2018-05-21 23:08:25 --> Utf8 Class Initialized
INFO - 2018-05-21 23:08:25 --> URI Class Initialized
INFO - 2018-05-21 23:08:25 --> Router Class Initialized
INFO - 2018-05-21 23:08:25 --> Output Class Initialized
INFO - 2018-05-21 23:08:25 --> Security Class Initialized
DEBUG - 2018-05-21 23:08:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-21 23:08:25 --> Input Class Initialized
INFO - 2018-05-21 23:08:25 --> Language Class Initialized
ERROR - 2018-05-21 23:08:25 --> 404 Page Not Found: /index
INFO - 2018-05-21 23:08:25 --> Config Class Initialized
INFO - 2018-05-21 23:08:25 --> Hooks Class Initialized
DEBUG - 2018-05-21 23:08:25 --> UTF-8 Support Enabled
INFO - 2018-05-21 23:08:25 --> Utf8 Class Initialized
INFO - 2018-05-21 23:08:25 --> URI Class Initialized
INFO - 2018-05-21 23:08:25 --> Router Class Initialized
INFO - 2018-05-21 23:08:25 --> Output Class Initialized
INFO - 2018-05-21 23:08:25 --> Security Class Initialized
DEBUG - 2018-05-21 23:08:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-21 23:08:25 --> Input Class Initialized
INFO - 2018-05-21 23:08:25 --> Language Class Initialized
ERROR - 2018-05-21 23:08:25 --> 404 Page Not Found: /index
INFO - 2018-05-21 23:08:25 --> Config Class Initialized
INFO - 2018-05-21 23:08:25 --> Hooks Class Initialized
DEBUG - 2018-05-21 23:08:25 --> UTF-8 Support Enabled
INFO - 2018-05-21 23:08:25 --> Utf8 Class Initialized
INFO - 2018-05-21 23:08:26 --> URI Class Initialized
INFO - 2018-05-21 23:08:26 --> Router Class Initialized
INFO - 2018-05-21 23:08:26 --> Output Class Initialized
INFO - 2018-05-21 23:08:26 --> Security Class Initialized
DEBUG - 2018-05-21 23:08:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-21 23:08:26 --> Input Class Initialized
INFO - 2018-05-21 23:08:26 --> Language Class Initialized
ERROR - 2018-05-21 23:08:26 --> 404 Page Not Found: /index
INFO - 2018-05-21 23:08:26 --> Config Class Initialized
INFO - 2018-05-21 23:08:26 --> Hooks Class Initialized
DEBUG - 2018-05-21 23:08:26 --> UTF-8 Support Enabled
INFO - 2018-05-21 23:08:26 --> Utf8 Class Initialized
INFO - 2018-05-21 23:08:26 --> URI Class Initialized
INFO - 2018-05-21 23:08:26 --> Router Class Initialized
INFO - 2018-05-21 23:08:26 --> Output Class Initialized
INFO - 2018-05-21 23:08:26 --> Security Class Initialized
DEBUG - 2018-05-21 23:08:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-21 23:08:26 --> Input Class Initialized
INFO - 2018-05-21 23:08:26 --> Language Class Initialized
ERROR - 2018-05-21 23:08:26 --> 404 Page Not Found: /index
INFO - 2018-05-21 23:08:27 --> Config Class Initialized
INFO - 2018-05-21 23:08:27 --> Hooks Class Initialized
DEBUG - 2018-05-21 23:08:27 --> UTF-8 Support Enabled
INFO - 2018-05-21 23:08:27 --> Utf8 Class Initialized
INFO - 2018-05-21 23:08:28 --> URI Class Initialized
INFO - 2018-05-21 23:08:28 --> Router Class Initialized
INFO - 2018-05-21 23:08:28 --> Output Class Initialized
INFO - 2018-05-21 23:08:28 --> Security Class Initialized
DEBUG - 2018-05-21 23:08:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-21 23:08:28 --> Input Class Initialized
INFO - 2018-05-21 23:08:28 --> Language Class Initialized
INFO - 2018-05-21 23:08:28 --> Language Class Initialized
INFO - 2018-05-21 23:08:28 --> Config Class Initialized
INFO - 2018-05-21 23:08:28 --> Loader Class Initialized
DEBUG - 2018-05-21 23:08:28 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-21 23:08:28 --> Helper loaded: url_helper
INFO - 2018-05-21 23:08:28 --> Helper loaded: form_helper
INFO - 2018-05-21 23:08:28 --> Helper loaded: date_helper
INFO - 2018-05-21 23:08:28 --> Helper loaded: util_helper
INFO - 2018-05-21 23:08:28 --> Helper loaded: text_helper
INFO - 2018-05-21 23:08:28 --> Helper loaded: string_helper
INFO - 2018-05-21 23:08:28 --> Database Driver Class Initialized
DEBUG - 2018-05-21 23:08:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-21 23:08:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-21 23:08:28 --> Email Class Initialized
INFO - 2018-05-21 23:08:28 --> Controller Class Initialized
DEBUG - 2018-05-21 23:08:28 --> Home MX_Controller Initialized
DEBUG - 2018-05-21 23:08:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-21 23:08:28 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-21 23:08:28 --> Login MX_Controller Initialized
INFO - 2018-05-21 23:08:28 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-21 23:08:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-21 23:08:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-21 23:08:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-21 23:08:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-21 23:08:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-21 23:08:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-21 23:08:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-21 23:08:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-05-21 23:08:28 --> Final output sent to browser
DEBUG - 2018-05-21 23:08:28 --> Total execution time: 0.4704
INFO - 2018-05-21 23:08:28 --> Config Class Initialized
INFO - 2018-05-21 23:08:28 --> Config Class Initialized
INFO - 2018-05-21 23:08:28 --> Hooks Class Initialized
INFO - 2018-05-21 23:08:28 --> Hooks Class Initialized
DEBUG - 2018-05-21 23:08:28 --> UTF-8 Support Enabled
DEBUG - 2018-05-21 23:08:28 --> UTF-8 Support Enabled
INFO - 2018-05-21 23:08:28 --> Utf8 Class Initialized
INFO - 2018-05-21 23:08:28 --> Utf8 Class Initialized
INFO - 2018-05-21 23:08:28 --> URI Class Initialized
INFO - 2018-05-21 23:08:28 --> Router Class Initialized
INFO - 2018-05-21 23:08:28 --> URI Class Initialized
INFO - 2018-05-21 23:08:28 --> Output Class Initialized
INFO - 2018-05-21 23:08:28 --> Router Class Initialized
INFO - 2018-05-21 23:08:28 --> Output Class Initialized
INFO - 2018-05-21 23:08:28 --> Security Class Initialized
INFO - 2018-05-21 23:08:28 --> Security Class Initialized
DEBUG - 2018-05-21 23:08:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-21 23:08:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-21 23:08:29 --> Input Class Initialized
INFO - 2018-05-21 23:08:29 --> Input Class Initialized
INFO - 2018-05-21 23:08:29 --> Language Class Initialized
INFO - 2018-05-21 23:08:29 --> Language Class Initialized
ERROR - 2018-05-21 23:08:29 --> 404 Page Not Found: /index
ERROR - 2018-05-21 23:08:29 --> 404 Page Not Found: /index
INFO - 2018-05-21 23:08:29 --> Config Class Initialized
INFO - 2018-05-21 23:08:29 --> Hooks Class Initialized
DEBUG - 2018-05-21 23:08:29 --> UTF-8 Support Enabled
INFO - 2018-05-21 23:08:29 --> Utf8 Class Initialized
INFO - 2018-05-21 23:08:29 --> URI Class Initialized
INFO - 2018-05-21 23:08:29 --> Router Class Initialized
INFO - 2018-05-21 23:08:29 --> Output Class Initialized
INFO - 2018-05-21 23:08:29 --> Security Class Initialized
DEBUG - 2018-05-21 23:08:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-21 23:08:29 --> Input Class Initialized
INFO - 2018-05-21 23:08:29 --> Language Class Initialized
ERROR - 2018-05-21 23:08:29 --> 404 Page Not Found: /index
INFO - 2018-05-21 23:08:29 --> Config Class Initialized
INFO - 2018-05-21 23:08:29 --> Hooks Class Initialized
DEBUG - 2018-05-21 23:08:29 --> UTF-8 Support Enabled
INFO - 2018-05-21 23:08:29 --> Utf8 Class Initialized
INFO - 2018-05-21 23:08:29 --> URI Class Initialized
INFO - 2018-05-21 23:08:29 --> Router Class Initialized
INFO - 2018-05-21 23:08:29 --> Output Class Initialized
INFO - 2018-05-21 23:08:29 --> Security Class Initialized
DEBUG - 2018-05-21 23:08:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-21 23:08:29 --> Input Class Initialized
INFO - 2018-05-21 23:08:29 --> Language Class Initialized
ERROR - 2018-05-21 23:08:29 --> 404 Page Not Found: /index
INFO - 2018-05-21 23:08:30 --> Config Class Initialized
INFO - 2018-05-21 23:08:30 --> Hooks Class Initialized
DEBUG - 2018-05-21 23:08:30 --> UTF-8 Support Enabled
INFO - 2018-05-21 23:08:30 --> Utf8 Class Initialized
INFO - 2018-05-21 23:08:30 --> URI Class Initialized
INFO - 2018-05-21 23:08:30 --> Router Class Initialized
INFO - 2018-05-21 23:08:30 --> Output Class Initialized
INFO - 2018-05-21 23:08:30 --> Security Class Initialized
DEBUG - 2018-05-21 23:08:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-21 23:08:30 --> Input Class Initialized
INFO - 2018-05-21 23:08:30 --> Language Class Initialized
ERROR - 2018-05-21 23:08:30 --> 404 Page Not Found: /index
INFO - 2018-05-21 23:08:30 --> Config Class Initialized
INFO - 2018-05-21 23:08:30 --> Hooks Class Initialized
DEBUG - 2018-05-21 23:08:30 --> UTF-8 Support Enabled
INFO - 2018-05-21 23:08:30 --> Utf8 Class Initialized
INFO - 2018-05-21 23:08:30 --> URI Class Initialized
INFO - 2018-05-21 23:08:30 --> Router Class Initialized
INFO - 2018-05-21 23:08:30 --> Output Class Initialized
INFO - 2018-05-21 23:08:30 --> Security Class Initialized
DEBUG - 2018-05-21 23:08:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-21 23:08:30 --> Input Class Initialized
INFO - 2018-05-21 23:08:30 --> Language Class Initialized
ERROR - 2018-05-21 23:08:30 --> 404 Page Not Found: /index
INFO - 2018-05-21 23:08:30 --> Config Class Initialized
INFO - 2018-05-21 23:08:30 --> Hooks Class Initialized
DEBUG - 2018-05-21 23:08:30 --> UTF-8 Support Enabled
INFO - 2018-05-21 23:08:30 --> Utf8 Class Initialized
INFO - 2018-05-21 23:08:30 --> URI Class Initialized
INFO - 2018-05-21 23:08:30 --> Router Class Initialized
INFO - 2018-05-21 23:08:30 --> Output Class Initialized
INFO - 2018-05-21 23:08:30 --> Security Class Initialized
DEBUG - 2018-05-21 23:08:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-21 23:08:30 --> Input Class Initialized
INFO - 2018-05-21 23:08:30 --> Language Class Initialized
ERROR - 2018-05-21 23:08:30 --> 404 Page Not Found: /index
